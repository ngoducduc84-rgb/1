﻿using OpenCvSharp.CPlusPlus;
using SvMip.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.Calibration
{    
    public partial class SvCalibrationEdit
    {
        bool IsPossibleNonlinear { get { return calibration.CalcNonlinearCalibration(); } }
        SvCalibrationData CalData 
        {
            get
            {
                if (calibration == null)
                    calibration = new SvCalibration();
                return calibration.CalData;
            }
            set
            {
                if (calibration == null)
                    calibration = new SvCalibration();

                // Nonlinear 추가
                if (value.CalDegree < (int)nud_Degree.Minimum)
                    value.CalDegree = (int)nud_Degree.Minimum;
                if (value.CalDegree > (int)nud_Degree.Maximum)
                    value.CalDegree = (int)nud_Degree.Maximum;

                if (value.UsingArea < (double)nud_UsingArea.Minimum)
                    value.UsingArea = (double)nud_UsingArea.Minimum;
                if (value.UsingArea > (double)nud_UsingArea.Maximum)
                    value.UsingArea = (double)nud_UsingArea.Maximum;

                calibration.CalData = value;

                base.NotifySubjectChanged(this, null);
            }
        
        }

        bool JobValidation(SvJob currentJob)
        {
            if (currentJob == null)
            {
                MessageBox.Show("There is no Job");
                return false;
            }

            SvAcquisition acquisitionTool = currentJob.ToolList[0] as SvAcquisition;

            if (acquisitionTool == null)
            {
                MessageBox.Show("First Tool must be 'Acquisition'!!");
                return false;
            }

            SvTemplateMatch templateMatchTool = currentJob.GetLastRunTool() as SvTemplateMatch;

            if (templateMatchTool == null)
            {
                MessageBox.Show("Last Tool must be 'PatternMatch' or 'TemplateMatching'");
                return false;
            }

            if (templateMatchTool.TemplateImage == null)
            {
                MessageBox.Show("There is not selected pattern.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        bool InitRobot()
        {
            if (robot == null)
            {
                MessageBox.Show("Selected robot is null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!robot.StartCalibration(CalData.GPNo))
            {
                MessageBox.Show("Calibration can't start.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                robot.EndCalibration();
                return false;
            }
            
            if (MessageBox.Show("Attach the Jig, and Click 'OK'", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)
                != System.Windows.Forms.DialogResult.OK)
            {
                robot.EndCalibration();
                return false;
            }
            
            return true;
        }

        public Point3d? Run(SvJob job)
        {
            job.Run(true);

            SvTemplateMatch templateMatchingTool = job.GetLastRunTool() as SvTemplateMatch;

            double score = templateMatchingTool.Score;
            Point3d result = templateMatchingTool.ResultCP;

            if (score < 0.6)
            {
                MessageBox.Show("Find position is failed\r\nScore: " + score, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }

            SvImageInfo info;

            if (job == calibrationJob)
                info = calibrationImageInfo;
            else if (job == rotationJob)
                info = rotationImageInfo;
            else throw new Exception("Job이 뭐가 들어온건데?");

            info.Image = templateMatchingTool.InputImage;
            SvImageInfo.DrwaingFunc originFunc = info.drawingFunc;
            info.drawingFunc = templateMatchingTool.imageList[1].drawingFunc;
            this.Invoke(new Action(SvDisplayViewEdit.RefreshImage));
            info.drawingFunc = originFunc;

            if (job == calibrationJob)
                CalData.CalImage = info.Image;
            else if (job == rotationJob)
                CalData.RotImage = info.Image;

            return result;
        }

        SvPoint originPoint = new SvPoint();

        bool CalibrationStart()
        {
            isStart = true;
            this.Invoke(new Action(delegate { btn_Cal_Start.Text = "Stop"; }));

            if (!JobValidation(calibrationJob)) return false;
            if (!InitRobot()) return false;

            int H = CalData.PointH;
            int V = CalData.PointV;
            double pitchH = CalData.PitchH;
            double pitchV = CalData.PitchV;

            bool bMoveOrigin2Cener = false;

            if(DialogResult.Yes == MessageBox.Show("Do You Want to Move Origin to Ceter of Display?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                //btn_OriginToCenter_Click(null, null);
                bMoveOrigin2Cener = true;
            }

            if (H % 2 == 0 || V % 2 == 0)
            {
                MessageBox.Show("Points Count must be odd.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (H < 3 || V < 3)
            {
                MessageBox.Show("Points Count too Small.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            CalData.RefPoint = new Point2d[H * V];
            CalData.RobotPoint = new Point2d[H * V];

            this.Invoke(new Action(delegate { pbar_Cal.Maximum = H * V; }));


            try
            {
                for (int i = 0; i < V; i++)
                {
                    for (int j = 0; j < H; j++)
                    {
                        if (isStart == false) throw new Exception();

                        CalData.RobotPoint[i * H + j] = new Point2d((j - (H - 1) / 2) * pitchH, (i - (V - 1) / 2) * pitchV);
                        Point2d MovePoint = CalData.RobotPoint[i * H + j] + new Point2d(CalData.CalShiftH, CalData.CalShiftV);

                        if (!robot.WriteCalOffset((float)MovePoint.X, (float)MovePoint.Y, 0.0f))
                        {
                            MessageBox.Show("Calibration Offset send failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            throw new Exception();
                        }

                        if (robot.MoveCalibration() == false)
                        {
                            MessageBox.Show(string.Format("Can't find mark {0} : Move signal send failed.).", i * H + j), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            throw new Exception();
                        }

                        Point3d? result = Run(calibrationJob);

                        if (result == null)
                            throw new Exception();

                        CalData.RefPoint[i * H + j] = new Point2d(result.Value.X, result.Value.Y);
                        this.Invoke(new Action(pbar_Cal.PerformStep));

                        //Thread.Sleep(500);
                    }
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                robot.EndCalibration();
            }

            // 가운데 점(RefPoint[(H * V - 1) / 2])을 (ImgWidth/2, ImgHeight/2)으로 Normalize한 값으로 전체 normalize
            //if (originPoint.X == 0 && originPoint.Y == 0)
            //this.Invoke(new Action(()=>btn_OriginToCenter_Click(this, null)));

            //Point2d normP = CalData.RefPoint[(H * V - 1) / 2] - new Point2d(originPoint.X, originPoint.Y);

            //for (int i = 0; i < V; i++)
            //{
            //    for (int j = 0; j < H; j++)
            //    {
            //        CalData.RefPoint[i * H + j] -= normP;
            //    }
            //}

            //Calibration Matrix(m_VtoRMatrix)를 생성한다.
            CalData.VtoRMat.Mat = Calibration.CalcCalibrationMat(CalData.RefPoint, CalData.RobotPoint);

            if (bMoveOrigin2Cener)
                ChangeOrigin(new Point2d(SvDisplayViewEdit.Display.Image.Width / 2, SvDisplayViewEdit.Display.Image.Height / 2));
            else
                ChangeOrigin(originPoint.Point2d);

            ChangeOrigin(new Point2d(SvDisplayViewEdit.Display.Image.Width / 2, SvDisplayViewEdit.Display.Image.Height / 2));

            return true;
        }

        void ChangeOrigin(Point2d _originPoint)
        {
            Mat calMat = CalData.VtoRMat.Mat;

            Point2d robotCP = calibration.VtoR_Linear(_originPoint);
            
            for (int i = 0; i < CalData.RobotPoint.Length; i++)
            {
                CalData.RobotPoint[i] -= robotCP;
            }

            CalData.VtoRMat.Mat = Calibration.CalcCalibrationMat(CalData.RefPoint, CalData.RobotPoint);
            originPoint.Point2d = _originPoint;
            //double[,] dd = SvFunc.DisplayMat(calMat);
            //double[,] ddd = SvFunc.DisplayMat(newCalMat);
            //Point2d P = calibration.VtoR_Linear(originPoint.Point2d);
        }
        
        bool RotationStart()
        {
            isStart = true;
            this.Invoke(new Action(delegate { btn_Rot_Start.Text = "Stop"; }));

            if (!JobValidation(rotationJob)) return false;
            if (!InitRobot()) return false;

            List<Point3d> resultPts = new List<Point3d>();
            List<double> listAngle = new List<double>();
            Point3d[] resultP = new Point3d[2];

            float angle;
            float angleFrom = CalData.AngleFrom;
            float angleTo = CalData.AngleTo;

            double shiftH = CalData.RotShiftH;
            double shiftV = CalData.RotShiftV;
            int rotCount = CalData.RotCount;
            
            this.Invoke(new Action(delegate { pbar_Rot.Maximum = rotCount; }));

            try
            {
                for (int i = 0; i < rotCount; i++)
                {
                    if (isStart == false) throw new Exception();

                    angle = angleFrom + (i) * (angleTo - angleFrom) / (rotCount - 1);
                    listAngle.Add(angle);

                    if (!robot.WriteCalOffset((float)shiftH, (float)shiftV, angle))
                    {
                        MessageBox.Show("Rotation Offset send failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        throw new Exception();
                    }

                    if (!robot.MoveCalibration())
                    {
                        MessageBox.Show("Rotation signal send failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        throw new Exception();
                    }

                    // 2016.03.06.ASH =====> IMI Camera의 경우 buffer내 이전 영상 남아있을 경우가 있어서... 임시로 추가함.
                    //npb_VIsion.MatImage = cam.GrabImage().Clone();
                    // 2016.03.06.ASH 

                    Point3d? result = Run(rotationJob);
                    if (result == null)
                        throw new Exception();

                    resultPts.Add(result.Value);
                    this.Invoke(new Action(pbar_Rot.PerformStep));

                    //Thread.Sleep(500);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                SvLogger.Log.Error(ex.Message);
                return false;
            }
            finally
            {
                robot.EndCalibration(); //Escape Robot Loop
            }

            //////////////////////// Check Reasonability ////////////////////////
            List<double> Length = new List<double>();
            for (int i = 0; i < rotCount - 1; i++)
            {
                double L = Point2d.Distance(new Point2d(resultPts[i].X, resultPts[i].Y), new Point2d(resultPts[i + 1].X, resultPts[i + 1].Y));
                Length.Add(L);
            }

            ////////////////////////// Calculate Center Pos. ////////////////////////
            //if (calData.RotPoints == null)
            //    calData.RotPoints = new List<Point3d>();
            //else
            //    calData.RotPoints.Clear();

            //foreach (Point3d pt in resultPts)
            //{
            //    calData.RotPoints.Add(pt);
            //}

            CalData.RotPoints = resultPts;
            CalData.RotAngles = listAngle;

            if (rotCount == 2)
            {
                double dthetaDeg = (Calibration.VtoR(resultPts[1]).Z - Calibration.VtoR(resultPts[0]).Z) * 180 / Math.PI;
                float fT = angleTo - angleFrom;
                if (Math.Abs(fT - dthetaDeg) > 1)
                {
                    string str = "Difference of Angle is too big\r\n + P0: " + Calibration.VtoR(resultPts[0]).Z + ", P1: " + Calibration.VtoR(resultPts[1]).Z;
                    MessageBox.Show(str, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else if (rotCount > 2)
            {
                double diff = Length.Max() - Length.Min();
                if (diff > 10)
                {
                    MessageBox.Show("Difference of Angle is too big", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else
                return false;

            CalData.RotCenter = Calibration.VtoR(Calibration.FindRotationCenter(resultPts)) - new Point2d(shiftH, shiftV); //회전중심 계산 후 저장

            //////////////////////// Save RobotGP Pos. ////////////////////////
            float x = 0; float y = 0; float w = 0;

            robot.ReadPosition(CalData.GPNo, out x, out y, out w);

            CalData.RobotGP = new Point2d(x, y);
            CalData.RobotGPT = w;
            return true;
        }
        
        /// <summary>
        /// 화면에 Calibration 결과를 그린다.
        /// </summary>
        void DrawCalibrationResult(SvMip.Display.SvDisplayView display)
        {
            // Test에서는 cVisionData 값을 가지고 한다.
            int H = CalData.RobotPoints_Y.Count;
            int V = CalData.RobotPoints_X.Count;
            double pitchH = CalData.PitchH;
            double pitchV = CalData.PitchV;

            if (CalData.VtoRMat == null || CalData.RefPoint == null)
            {
                //MessageBox.Show("There is not Calibraion Data.");
                return;
            }

            display.ClearImage();
            (display as Display.SvDisplayViewInteract).InteractiveGraphicsCollection.Add(originPoint);
            this.SvDisplayViewEdit.CalibrationMat = CalData.VtoRMat.Mat;
            //폼에 결과를 쓴다

            if (CalData.RobotPoint == null)
            {
                CalData.RobotPoint = new Point2d[CalData.PointV * CalData.PointH];
                for (int i = 0; i < V; i++)
                {
                    for (int j = 0; j < H; j++)
                    {
                        CalData.RobotPoint[i * H + j] = new Point2d((j - (H - 1) / 2) * pitchH, (i - (V - 1) / 2) * pitchV);
                    }
                }
            }

            gv_Cal_Result.Rows.Clear();

            for (int i = 0; i < CalData.RefPoint.Length; i++)
            {
                Point2d v = CalData.RefPoint[i];
                Point2d r = CalData.RobotPoint[i];
                {
                    gv_Cal_Result.Rows.Add(
                        i.ToString(),
                        r.X.ToString("f3"),
                        r.Y.ToString("f3"),
                        Calibration.VtoR(v).X.ToString("f3"),
                        Calibration.VtoR(v).Y.ToString("f3"),
                        (Calibration.VtoR(v) - r).X.ToString("f3"),
                        (Calibration.VtoR(v) - r).Y.ToString("f3"),
                        v.X.ToString("f3"),
                        v.Y.ToString("f3"));
                }
            }


            gv_Diff.Rows.Clear();
            List<double> diffX = new List<double>();
            List<double> diffY = new List<double>();

            for (int i = 0; i < gv_Cal_Result.RowCount - 1; i++)
            {
                diffX.Add(double.Parse(gv_Cal_Result.Rows[i].Cells[5].Value.ToString()));
                diffY.Add(double.Parse(gv_Cal_Result.Rows[i].Cells[6].Value.ToString()));
            }
            gv_Diff.Rows.Add("Diff_X", diffX.Min().ToString("f3"), diffX.Max().ToString("f3"), (3 * GetStdev(diffX)).ToString("f3"));
            gv_Diff.Rows.Add("Diff_Y", diffY.Min().ToString("f3"), diffY.Max().ToString("f3"), (3 * GetStdev(diffY)).ToString("f3"));

            // 화면에 Display
            // 마크 표시하고 박스도 그리면 좋지...
            DisplayCordinate(display);

            // Lattice 그리기
            DrawLattiec(display);

            Point2d refP;
            Font font = new Font("굴림체", 8, System.Drawing.FontStyle.Bold);

            if (calibrationImageInfo.Image == null)
            {
                if (CalData.CalImage != null)
                {
                    calibrationImageInfo.Image = CalData.CalImage;
                    SvDisplayViewEdit.RefreshImage();
                }
                else
                {
                    display.DrawString(string.Format("There is No Calibration Image"), font, Brushes.Red, new Point2d(0, 0));
                    return;
                }
            }

            double size = 5 / display.ZoomRatio;

            // mapMatrix^(-1) * (PitchH, PitchV)는 과연 어떻게 표시될 것인지 보여준다.            
            //for (int i = 0; i < V; i++)
            //{
            //    for (int j = 0; j < H; j++)
            //    {
            //        refP = new Point2d((j - (H - 1) / 2) * pitchH, (i - (V - 1) / 2) * pitchV);
            //        display.DrawString(string.Format("({0:0.000},{1:0.000})", refP.X, refP.Y),
            //                                font, Brushes.Cyan, new Point2d(Calibration.RToV(refP).X + 10.0, Calibration.RToV(refP).Y + 80.0));
            //        display.DrawCross(Pens.Cyan, Calibration.RToV(refP), 2 * size, 2 * size, 0);
            //    }
            //}

            // Vision에서 측정된 Ref. Point(Red) 그리기  
            for (int i = 0; i < CalData.RefPoint.Length; i++)
            {
                refP = CalData.RefPoint[i];
                //if (!mDrawNonlinear)
                //{
                //if (!IsPossibleNonlinear) continue;
                display.DrawString(string.Format("({0:0.00},{1:0.00})", Calibration.VtoR(refP).X, Calibration.VtoR(refP).Y),
                                        font, Brushes.Red, new Point2d(refP.X + 10.0, refP.Y - font.Size / display.ZoomRatio));
                display.DrawCross(Pens.Red, refP, 4 * size, 4 * size, 0);

                refP = CalData.RobotPoint[i];
                display.DrawString(string.Format("({0:0.00},{1:0.00})", refP.X, refP.Y),
                                        font, Brushes.Cyan, new Point2d(Calibration.RtoV(refP).X + 10.0, Calibration.RtoV(refP).Y + 0.5 * font.Size / display.ZoomRatio));
                display.DrawCross(Pens.Cyan, Calibration.RtoV(refP), 2 * size, 2 * size, 0);
            }
        }

        private double GetStdev(List<double> array)
        {
            if (array == null) return 0;
            double squareSum = 0;
            double average = array.Average();
            for (int i = 0; i < array.Count; i++)
            {
                squareSum += Math.Pow(array[i] - average, 2);
            }
            double stdev = Math.Sqrt(squareSum / (array.Count - 1));

            return stdev;
        }

        void DisplayCordinate(SvMip.Display.SvDisplayView display)
        {
            int countX = 1; int countY = 1;
            for (int i = 1; i < Calibration.CalData.RobotPoint.Length; i++)
            {
                if (Calibration.CalData.RobotPoint[0].Y != Calibration.CalData.RobotPoint[i].Y)
                {
                    countX = i;
                    countY = Calibration.CalData.RobotPoint.Length / countX;
                    break;
                }
            }

            Font font = new Font("굴림체", 10, System.Drawing.FontStyle.Bold);

            if (Calibration.GetVtoRMat() == null)
            {
                display.DrawString("No Calibration Data", font, Brushes.Red, new PointF(display.Width - 100, display.Height - 20));
                return;
            }

            double pitchH = double.MaxValue; double pitchV = double.MaxValue;
            for (int i = 0; i < calibration.CalData.RobotPoint.Length - 1; i++)
            {
                double dh = Calibration.CalData.RobotPoint[i+1].X - Calibration.CalData.RobotPoint[i].X;
                if (dh < 0.1) continue;
                if (pitchH > dh) pitchH = dh;
            }
            for (int i = 0; i < calibration.CalData.RobotPoint.Length - 1; i++)
            {
                double dh = Calibration.CalData.RobotPoint[i + 1].Y - Calibration.CalData.RobotPoint[i].Y;
                if (dh < 0.1) continue;
                if (pitchV > dh) pitchV = dh;
            }

            if (pitchH == double.MaxValue) pitchH = pitchV;
            if (pitchV == double.MaxValue) pitchV = pitchH;

            {
                PointF HSP = display.PtoP(Calibration.RtoV_Linear(new Point2d(0 * pitchH, 0)));
                PointF HEP = display.PtoP(Calibration.RtoV_Linear(new Point2d(+2 * pitchH, 0)));
                PointF VSP = display.PtoP(Calibration.RtoV_Linear(new Point2d(0, 0 * pitchV)));
                PointF VEP = display.PtoP(Calibration.RtoV_Linear(new Point2d(0, +2 * pitchV)));

                display.DrawArrow(Pens.Yellow, HSP, HEP, 20, 20);
                display.DrawArrow(Pens.Red, VSP, VEP, 20, 20);
            }
            
            display.DrawString("X", font, Brushes.Yellow, Calibration.RtoV_Linear(new Point2d(2 * pitchH, 0)));
            display.DrawString("Y", font, Brushes.Red, Calibration.RtoV_Linear(new Point2d(0, 2 * pitchV)));

            display.DrawString("X ──", font, Brushes.Yellow, new PointF(0, display.Height / 2 - font.Size / display.ZoomRatio));
            display.DrawString("Y ──", font, Brushes.Red, new PointF(0, display.Height / 2 + font.Size / display.ZoomRatio));
        }

        private void DrawLattiec(Display.SvDisplayView display, bool isNonlinear = false)
        {
            int countX = 1; int countY = 1;
            for (int i = 1; i < Calibration.CalData.RobotPoint.Length; i++)
            {
                if (Calibration.CalData.RobotPoint[0].Y != Calibration.CalData.RobotPoint[i].Y)
                {
                    countX = i;
                    countY = Calibration.CalData.RobotPoint.Length / countX;
                    break;
                }
            }

            //int pitchH = cal.CalData.PitchH; <- 이렇게 하니 Pitch값을 바꿀때마다 선 간격이 바뀌어서 기존 Point 위치와 안맞음
            //int pitchV = cal.CalData.PitchV;
            int pitchH = (int)Math.Round(Calibration.CalData.RobotPoint[1].X - Calibration.CalData.RobotPoint[0].X);
            int pitchV = (int)Math.Round(Calibration.CalData.RobotPoint[countX].Y - Calibration.CalData.RobotPoint[0].Y);

            /////// 화면에 표시할 수 있는 가장 큰 외곽선(좌표계) 그리기
            Pen pen = new Pen(Brushes.LightGreen, 2 / display.ZoomRatio);
            pen.DashStyle = DashStyle.Dash;

            double size = 1000;
            Point2d originPt = Calibration.RtoV_Linear(new Point2d(0, 0));
            Point2d widthPt = Calibration.RtoV_Linear(new Point2d(size, 0));
            Point2d heightPt = Calibration.RtoV_Linear(new Point2d(0, size));
            double scale = Math.Min(Math.Abs(Calibration.CalData.CalImage.Width / widthPt.DistanceTo(originPt)), Math.Abs(Calibration.CalData.CalImage.Height / heightPt.DistanceTo(originPt)));
            size *= scale * 0.5;

            display.DrawLine(pen, Calibration.RtoV_Linear(new Point2d(-size, size)), Calibration.RtoV_Linear(new Point2d(size, size)));
            display.DrawLine(pen, Calibration.RtoV_Linear(new Point2d(-size, -size)), Calibration.RtoV_Linear(new Point2d(size, -size)));

            display.DrawLine(pen, Calibration.RtoV_Linear(new Point2d(size, -size)), Calibration.RtoV_Linear(new Point2d(size, size)));
            display.DrawLine(pen, Calibration.RtoV_Linear(new Point2d(-size, -size)), Calibration.RtoV_Linear(new Point2d(-size, size)));

            //if (!mDrawNonlinear)
            //{
            Pen px = new Pen(Brushes.Cyan, 1 / display.ZoomRatio);
            px.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            for (int i = -countY / 2; i <= countY / 2; i++)
                display.DrawLine(px, Calibration.RtoV_Linear(new Point2d(-size, i * pitchV)), Calibration.RtoV_Linear(new Point2d(size, i * pitchV)));

            Pen py = new Pen(Brushes.Red, 1 / display.ZoomRatio);
            py.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            for (int i = -countX / 2; i <= countX / 2; i++)
                display.DrawLine(py, Calibration.RtoV_Linear(new Point2d(i * pitchH, -size)), Calibration.RtoV_Linear(new Point2d(i * pitchH, size)));
            //}

            if (IsPossibleNonlinear)
            {
                px = new Pen(Brushes.Cyan, 2 / display.ZoomRatio);
                px.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
                for (int i = -countY / 2; i <= countY / 2; i++)
                {
                    for (double x = - size; x < size; x++)
                    {
                        Point2d robotP = new Point2d(x, i * pitchV);
                        Point2d nonlinearP = Calibration.GetNonlinearValue(robotP);
                        display.DrawCross(px, Calibration.RtoV(nonlinearP), 2, 2, 0);
                    }
                }
                py = new Pen(Brushes.Red, 2 / display.ZoomRatio);
                py.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
                for (int i = -countX / 2; i <= countX / 2; i++)
                {
                    for (double y = -size; y < size; y++)
                    {
                        Point2d robotP = new Point2d(i * pitchH, y);
                        Point2d nonlinearP = Calibration.GetNonlinearValue(robotP);
                        display.DrawCross(py, Calibration.RtoV(nonlinearP), 2, 2, 0);
                    }
                }
            }

        }

        /// <summary>
        /// 화면에 this.calData를 표시한다.
        /// </summary>
        void DrawRotationResult(SvMip.Display.SvDisplayView display)
        {
            if (CalData.RotPoints == null || CalData.RotPoints.Count == 0)
            {
                //MessageBox.Show("Rotaion result data is null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Calibration.GetVtoRMat() == null)
            {
                //MessageBox.Show("Calibration result data is null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (CalData.RotAngles == null)
            {
                CalData.RotAngles = new List<double>();

                for (int i = 0; i < CalData.RotCount; i++)
                {
                    double angle = CalData.AngleFrom + (i) * (CalData.AngleTo - CalData.AngleFrom) / (CalData.RotCount - 1);
                    CalData.RotAngles.Add(angle);
                }
            }

            display.ClearImage();

            List<Point3d> resultPts = CalData.RotPoints;

            Point2d robotCP = new Point2d(CalData.RotCenter.X, CalData.RotCenter.Y);
            Point2d visionCP = Calibration.RtoV(robotCP);
            Point2d robotShiftCP = robotCP + new Point2d(CalData.RotShiftH, CalData.RotShiftV);
            Point2d visionShiftCP = Calibration.RtoV(robotShiftCP);

            float radius = (float)Math.Sqrt(Math.Pow(resultPts[0].X - visionShiftCP.X, 2) + Math.Pow(resultPts[0].Y - visionShiftCP.Y, 2)); //위에꺼랑 이거랑 같을지 모르겠음.

            //폼에 출력하기
            lbl_Rot_Origin_RLocation.Text = string.Format("({0:F3}, {1:F3})", robotCP.X, robotCP.Y);
            lbl_Rot_Origin_VLocation.Text = string.Format("({0:F3}, {1:F3})", visionCP.X, visionCP.Y);
            lbl_Rot_Origin_RadiusVision.Text = string.Format("{0:F3} px", radius);
            //lbl_RobotGPos.Text = string.Format("( {0:F3}, {1:F3}, {2:F3})", calData.RobotGP.X, calData.RobotGP.Y, calData.RobotGPT);
            nud_GP_X.Value = (decimal)CalData.RobotGP.X; nud_GP_Y.Value = (decimal)CalData.RobotGP.Y;

            Point2d P0 = new Point2d(resultPts[0].X, resultPts[0].Y);

            if (CalData.VtoRMat != null)
                lbl_Rot_Origin_RadiusRobot.Text = string.Format("{0:F3} mm", OpenCvSharp.CPlusPlus.Point.Distance(Calibration.VtoR(P0), Calibration.VtoR(visionShiftCP)));

            Font font = new Font("굴림체", 8, System.Drawing.FontStyle.Bold);
            display.ClearImage();

            Rect patternRect = CalData.RotPatternRect;
            if (patternRect.Width <= 0 || patternRect.Height <= 0)
                patternRect = new Rect(0, 0, 10, 10);

            if (rotationImageInfo.Image == null)
            {
                if (CalData.RotImage != null)
                {
                    rotationImageInfo.Image = CalData.RotImage;
                    SvDisplayViewEdit.RefreshImage();
                }
                else
                {
                    display.DrawString(string.Format("There is No RotationCenter Image"), font, new SolidBrush(Color.Red), new Point2d(0, 0));
                    return;
                }
            }

            // Display ListView
            gv_Rot_Pts.Rows.Clear();
            for (int i = 0; i < CalData.RotPoints.Count; i++)
            {
                gv_Rot_Pts.Rows.Add(new string[5] 
                { i.ToString(), CalData.RotAngles[i].ToString("f2") ,CalData.RotPoints[i].X.ToString("f3"), CalData.RotPoints[i].Y.ToString("f3"), (CalData.RotPoints[i].Z * 180 / Math.PI).ToString("f3") });
            }

            //좌표계 그리기           
            DisplayCordinate(display);

            for (int i = 0; i < CalData.RotPoints.Count; i++)
            {
                Point2d resultPt = new Point2d(resultPts[i].X, resultPts[i].Y);
                // 패턴 그리기
                display.DrawCross(Pens.Red, resultPt, patternRect.Width, patternRect.Height, resultPts[i].Z);
                display.DrawRectangle(Pens.YellowGreen, resultPt, patternRect.Width, patternRect.Height, resultPts[i].Z);

                // 좌표 그리기
                display.DrawString(string.Format("P" + i + ": ({0:0.00}, {1:0.00})\r\nT" + i + ": {2:0.0}Deg",
                    resultPts[i].X, resultPts[i].Y, resultPts[i].Z * 180 / Math.PI), font, Brushes.Gray, resultPt);
            }
            display.DrawString(string.Format("Robot : ({0:0.00}, {1:0.00})\r\nPixel : ({2:0.00}, {3:0.00})",
                robotShiftCP.X, robotShiftCP.Y, visionShiftCP.X, visionShiftCP.Y), font, Brushes.Gray, visionShiftCP);

            display.DrawString(string.Format("Robot : ({0:0.00}, {1:0.00})\r\nPixel : ({2:0.00}, {3:0.00})",
                robotCP.X, robotCP.Y, visionCP.X, visionCP.Y), font, Brushes.Red, visionCP);

            //Shift 표시
            float size = 3f / display.ZoomRatio;

            Pen p = new Pen(Color.Lime, size);
            p.DashStyle = DashStyle.Dot;
            display.DrawLine(p, visionCP, visionShiftCP);

            //회전반경 그리기
            p = new Pen(Color.Yellow, 2);
            p.DashPattern = new float[] { 2f, 1f, 1f, 1f };
            display.DrawEllipse(p, visionShiftCP, radius, radius);

            //원점 그리기
            p = new Pen(Color.Red, size);
            p.DashStyle = DashStyle.Solid;
            display.DrawEllipse(p, visionCP, 2 * size, 2 * size);

            p = new Pen(Color.Orange, size);
            p.DashStyle = DashStyle.Solid;
            display.DrawEllipse(p, visionShiftCP, 2 * size, 2 * size);
        }
    }
}
