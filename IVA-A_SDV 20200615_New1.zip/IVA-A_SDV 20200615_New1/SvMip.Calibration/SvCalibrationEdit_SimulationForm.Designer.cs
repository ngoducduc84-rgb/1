﻿namespace SvMip.Calibration
{
    partial class SvCalibrationEdit_SimulationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.simul_param = new System.Windows.Forms.TabControl();
            this.tb_Param = new System.Windows.Forms.TabPage();
            this.cb_AnimationStartEnd = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.nud_target_T = new System.Windows.Forms.NumericUpDown();
            this.nud_target_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_target_X = new System.Windows.Forms.NumericUpDown();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nud_tool_T = new System.Windows.Forms.NumericUpDown();
            this.nud_tool_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_tool_X = new System.Windows.Forms.NumericUpDown();
            this.btnMoveTarget = new System.Windows.Forms.Button();
            this.btnMoveTool = new System.Windows.Forms.Button();
            this.simulator_start = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbl_spcp_Y = new System.Windows.Forms.Label();
            this.lbl_spcp_X = new System.Windows.Forms.Label();
            this.nud_spcp_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_spcp_X = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_epT = new System.Windows.Forms.Label();
            this.lbl_epY = new System.Windows.Forms.Label();
            this.lbl_epX = new System.Windows.Forms.Label();
            this.nud_ep_T = new System.Windows.Forms.NumericUpDown();
            this.nud_ep_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_ep_X = new System.Windows.Forms.NumericUpDown();
            this.gb_SP = new System.Windows.Forms.GroupBox();
            this.lbl_spT = new System.Windows.Forms.Label();
            this.lbl_spY = new System.Windows.Forms.Label();
            this.lbl_spX = new System.Windows.Forms.Label();
            this.nud_sp_T = new System.Windows.Forms.NumericUpDown();
            this.nud_sp_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_sp_X = new System.Windows.Forms.NumericUpDown();
            this.svdisplayview_simul = new SvMip.Display.SvDisplayViewInteract();
            this.tableLayoutPanel1.SuspendLayout();
            this.simul_param.SuspendLayout();
            this.tb_Param.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_target_T)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_target_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_target_X)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tool_T)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tool_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tool_X)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_spcp_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_spcp_X)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ep_T)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ep_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ep_X)).BeginInit();
            this.gb_SP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_sp_T)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_sp_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_sp_X)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.04843F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.95157F));
            this.tableLayoutPanel1.Controls.Add(this.svdisplayview_simul, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.simul_param, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(826, 673);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // simul_param
            // 
            this.simul_param.Controls.Add(this.tb_Param);
            this.simul_param.Dock = System.Windows.Forms.DockStyle.Fill;
            this.simul_param.Location = new System.Drawing.Point(499, 3);
            this.simul_param.Multiline = true;
            this.simul_param.Name = "simul_param";
            this.simul_param.SelectedIndex = 0;
            this.simul_param.Size = new System.Drawing.Size(324, 667);
            this.simul_param.TabIndex = 4;
            // 
            // tb_Param
            // 
            this.tb_Param.Controls.Add(this.cb_AnimationStartEnd);
            this.tb_Param.Controls.Add(this.groupBox4);
            this.tb_Param.Controls.Add(this.groupBox3);
            this.tb_Param.Controls.Add(this.btnMoveTarget);
            this.tb_Param.Controls.Add(this.btnMoveTool);
            this.tb_Param.Controls.Add(this.simulator_start);
            this.tb_Param.Controls.Add(this.groupBox2);
            this.tb_Param.Controls.Add(this.groupBox1);
            this.tb_Param.Controls.Add(this.gb_SP);
            this.tb_Param.Location = new System.Drawing.Point(4, 22);
            this.tb_Param.Name = "tb_Param";
            this.tb_Param.Padding = new System.Windows.Forms.Padding(3);
            this.tb_Param.Size = new System.Drawing.Size(316, 641);
            this.tb_Param.TabIndex = 0;
            this.tb_Param.Text = "Patameter";
            this.tb_Param.UseVisualStyleBackColor = true;
            // 
            // cb_AnimationStartEnd
            // 
            this.cb_AnimationStartEnd.Appearance = System.Windows.Forms.Appearance.Button;
            this.cb_AnimationStartEnd.Location = new System.Drawing.Point(18, 452);
            this.cb_AnimationStartEnd.Name = "cb_AnimationStartEnd";
            this.cb_AnimationStartEnd.Size = new System.Drawing.Size(282, 69);
            this.cb_AnimationStartEnd.TabIndex = 41;
            this.cb_AnimationStartEnd.Text = "Animation Start";
            this.cb_AnimationStartEnd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cb_AnimationStartEnd.UseVisualStyleBackColor = true;
            this.cb_AnimationStartEnd.CheckedChanged += new System.EventHandler(this.cb_AnimationStartEnd_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.nud_target_T);
            this.groupBox4.Controls.Add(this.nud_target_Y);
            this.groupBox4.Controls.Add(this.nud_target_X);
            this.groupBox4.Location = new System.Drawing.Point(162, 260);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(139, 108);
            this.groupBox4.TabIndex = 40;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Target Move Point";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(12, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 15);
            this.label4.TabIndex = 36;
            this.label4.Text = "T :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(12, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 15);
            this.label5.TabIndex = 36;
            this.label5.Text = "Y :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(12, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 15);
            this.label6.TabIndex = 36;
            this.label6.Text = "X :";
            // 
            // nud_target_T
            // 
            this.nud_target_T.DecimalPlaces = 2;
            this.nud_target_T.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_target_T.Location = new System.Drawing.Point(42, 74);
            this.nud_target_T.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_target_T.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_target_T.Name = "nud_target_T";
            this.nud_target_T.Size = new System.Drawing.Size(80, 21);
            this.nud_target_T.TabIndex = 35;
            this.nud_target_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_target_Y
            // 
            this.nud_target_Y.DecimalPlaces = 3;
            this.nud_target_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_target_Y.Location = new System.Drawing.Point(42, 47);
            this.nud_target_Y.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_target_Y.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_target_Y.Name = "nud_target_Y";
            this.nud_target_Y.Size = new System.Drawing.Size(80, 21);
            this.nud_target_Y.TabIndex = 35;
            this.nud_target_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_target_X
            // 
            this.nud_target_X.DecimalPlaces = 3;
            this.nud_target_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_target_X.Location = new System.Drawing.Point(42, 20);
            this.nud_target_X.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_target_X.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_target_X.Name = "nud_target_X";
            this.nud_target_X.Size = new System.Drawing.Size(80, 21);
            this.nud_target_X.TabIndex = 35;
            this.nud_target_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.nud_tool_T);
            this.groupBox3.Controls.Add(this.nud_tool_Y);
            this.groupBox3.Controls.Add(this.nud_tool_X);
            this.groupBox3.Location = new System.Drawing.Point(17, 260);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(139, 108);
            this.groupBox3.TabIndex = 40;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tool Move Point";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(12, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 15);
            this.label1.TabIndex = 36;
            this.label1.Text = "T :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(12, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 15);
            this.label2.TabIndex = 36;
            this.label2.Text = "Y :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(12, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 15);
            this.label3.TabIndex = 36;
            this.label3.Text = "X :";
            // 
            // nud_tool_T
            // 
            this.nud_tool_T.DecimalPlaces = 2;
            this.nud_tool_T.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_tool_T.Location = new System.Drawing.Point(42, 74);
            this.nud_tool_T.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_tool_T.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_tool_T.Name = "nud_tool_T";
            this.nud_tool_T.Size = new System.Drawing.Size(80, 21);
            this.nud_tool_T.TabIndex = 35;
            this.nud_tool_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_tool_Y
            // 
            this.nud_tool_Y.DecimalPlaces = 3;
            this.nud_tool_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_tool_Y.Location = new System.Drawing.Point(42, 47);
            this.nud_tool_Y.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_tool_Y.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_tool_Y.Name = "nud_tool_Y";
            this.nud_tool_Y.Size = new System.Drawing.Size(80, 21);
            this.nud_tool_Y.TabIndex = 35;
            this.nud_tool_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_tool_X
            // 
            this.nud_tool_X.DecimalPlaces = 3;
            this.nud_tool_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_tool_X.Location = new System.Drawing.Point(42, 20);
            this.nud_tool_X.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_tool_X.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_tool_X.Name = "nud_tool_X";
            this.nud_tool_X.Size = new System.Drawing.Size(80, 21);
            this.nud_tool_X.TabIndex = 35;
            this.nud_tool_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnMoveTarget
            // 
            this.btnMoveTarget.Location = new System.Drawing.Point(162, 374);
            this.btnMoveTarget.Name = "btnMoveTarget";
            this.btnMoveTarget.Size = new System.Drawing.Size(138, 51);
            this.btnMoveTarget.TabIndex = 39;
            this.btnMoveTarget.Text = "Move Target";
            this.btnMoveTarget.UseVisualStyleBackColor = true;
            this.btnMoveTarget.Click += new System.EventHandler(this.Move_Target_Click);
            // 
            // btnMoveTool
            // 
            this.btnMoveTool.Location = new System.Drawing.Point(18, 374);
            this.btnMoveTool.Name = "btnMoveTool";
            this.btnMoveTool.Size = new System.Drawing.Size(138, 51);
            this.btnMoveTool.TabIndex = 39;
            this.btnMoveTool.Text = "Move Tool";
            this.btnMoveTool.UseVisualStyleBackColor = true;
            this.btnMoveTool.Click += new System.EventHandler(this.Move_Tool_Click);
            // 
            // simulator_start
            // 
            this.simulator_start.Location = new System.Drawing.Point(20, 195);
            this.simulator_start.Name = "simulator_start";
            this.simulator_start.Size = new System.Drawing.Size(280, 52);
            this.simulator_start.TabIndex = 39;
            this.simulator_start.Text = "Calculate Offset";
            this.simulator_start.UseVisualStyleBackColor = true;
            this.simulator_start.Click += new System.EventHandler(this.simulator_start_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbl_spcp_Y);
            this.groupBox2.Controls.Add(this.lbl_spcp_X);
            this.groupBox2.Controls.Add(this.nud_spcp_Y);
            this.groupBox2.Controls.Add(this.nud_spcp_X);
            this.groupBox2.Location = new System.Drawing.Point(20, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(280, 54);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rotation Center";
            // 
            // lbl_spcp_Y
            // 
            this.lbl_spcp_Y.AutoSize = true;
            this.lbl_spcp_Y.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_spcp_Y.Location = new System.Drawing.Point(161, 23);
            this.lbl_spcp_Y.Name = "lbl_spcp_Y";
            this.lbl_spcp_Y.Size = new System.Drawing.Size(25, 15);
            this.lbl_spcp_Y.TabIndex = 36;
            this.lbl_spcp_Y.Text = "Y :";
            // 
            // lbl_spcp_X
            // 
            this.lbl_spcp_X.AutoSize = true;
            this.lbl_spcp_X.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_spcp_X.Location = new System.Drawing.Point(11, 23);
            this.lbl_spcp_X.Name = "lbl_spcp_X";
            this.lbl_spcp_X.Size = new System.Drawing.Size(26, 15);
            this.lbl_spcp_X.TabIndex = 36;
            this.lbl_spcp_X.Text = "X :";
            // 
            // nud_spcp_Y
            // 
            this.nud_spcp_Y.DecimalPlaces = 3;
            this.nud_spcp_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_spcp_Y.Location = new System.Drawing.Point(191, 20);
            this.nud_spcp_Y.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_spcp_Y.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_spcp_Y.Name = "nud_spcp_Y";
            this.nud_spcp_Y.Size = new System.Drawing.Size(80, 21);
            this.nud_spcp_Y.TabIndex = 35;
            this.nud_spcp_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_spcp_X
            // 
            this.nud_spcp_X.DecimalPlaces = 3;
            this.nud_spcp_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_spcp_X.Location = new System.Drawing.Point(41, 20);
            this.nud_spcp_X.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_spcp_X.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_spcp_X.Name = "nud_spcp_X";
            this.nud_spcp_X.Size = new System.Drawing.Size(80, 21);
            this.nud_spcp_X.TabIndex = 35;
            this.nud_spcp_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl_epT);
            this.groupBox1.Controls.Add(this.lbl_epY);
            this.groupBox1.Controls.Add(this.lbl_epX);
            this.groupBox1.Controls.Add(this.nud_ep_T);
            this.groupBox1.Controls.Add(this.nud_ep_Y);
            this.groupBox1.Controls.Add(this.nud_ep_X);
            this.groupBox1.Location = new System.Drawing.Point(164, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(136, 104);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "End Point";
            // 
            // lbl_epT
            // 
            this.lbl_epT.AutoSize = true;
            this.lbl_epT.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_epT.Location = new System.Drawing.Point(17, 73);
            this.lbl_epT.Name = "lbl_epT";
            this.lbl_epT.Size = new System.Drawing.Size(25, 15);
            this.lbl_epT.TabIndex = 36;
            this.lbl_epT.Text = "T :";
            // 
            // lbl_epY
            // 
            this.lbl_epY.AutoSize = true;
            this.lbl_epY.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_epY.Location = new System.Drawing.Point(17, 48);
            this.lbl_epY.Name = "lbl_epY";
            this.lbl_epY.Size = new System.Drawing.Size(25, 15);
            this.lbl_epY.TabIndex = 36;
            this.lbl_epY.Text = "Y :";
            // 
            // lbl_epX
            // 
            this.lbl_epX.AutoSize = true;
            this.lbl_epX.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_epX.Location = new System.Drawing.Point(17, 23);
            this.lbl_epX.Name = "lbl_epX";
            this.lbl_epX.Size = new System.Drawing.Size(26, 15);
            this.lbl_epX.TabIndex = 36;
            this.lbl_epX.Text = "X :";
            // 
            // nud_ep_T
            // 
            this.nud_ep_T.DecimalPlaces = 2;
            this.nud_ep_T.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_ep_T.Location = new System.Drawing.Point(47, 70);
            this.nud_ep_T.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_ep_T.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_ep_T.Name = "nud_ep_T";
            this.nud_ep_T.Size = new System.Drawing.Size(80, 21);
            this.nud_ep_T.TabIndex = 35;
            this.nud_ep_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_ep_Y
            // 
            this.nud_ep_Y.DecimalPlaces = 3;
            this.nud_ep_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_ep_Y.Location = new System.Drawing.Point(47, 45);
            this.nud_ep_Y.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_ep_Y.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_ep_Y.Name = "nud_ep_Y";
            this.nud_ep_Y.Size = new System.Drawing.Size(80, 21);
            this.nud_ep_Y.TabIndex = 35;
            this.nud_ep_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_ep_X
            // 
            this.nud_ep_X.DecimalPlaces = 3;
            this.nud_ep_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_ep_X.Location = new System.Drawing.Point(47, 20);
            this.nud_ep_X.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_ep_X.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_ep_X.Name = "nud_ep_X";
            this.nud_ep_X.Size = new System.Drawing.Size(80, 21);
            this.nud_ep_X.TabIndex = 35;
            this.nud_ep_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gb_SP
            // 
            this.gb_SP.Controls.Add(this.lbl_spT);
            this.gb_SP.Controls.Add(this.lbl_spY);
            this.gb_SP.Controls.Add(this.lbl_spX);
            this.gb_SP.Controls.Add(this.nud_sp_T);
            this.gb_SP.Controls.Add(this.nud_sp_Y);
            this.gb_SP.Controls.Add(this.nud_sp_X);
            this.gb_SP.Location = new System.Drawing.Point(19, 85);
            this.gb_SP.Name = "gb_SP";
            this.gb_SP.Size = new System.Drawing.Size(139, 104);
            this.gb_SP.TabIndex = 36;
            this.gb_SP.TabStop = false;
            this.gb_SP.Text = "Start Point";
            // 
            // lbl_spT
            // 
            this.lbl_spT.AutoSize = true;
            this.lbl_spT.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_spT.Location = new System.Drawing.Point(12, 73);
            this.lbl_spT.Name = "lbl_spT";
            this.lbl_spT.Size = new System.Drawing.Size(25, 15);
            this.lbl_spT.TabIndex = 36;
            this.lbl_spT.Text = "T :";
            // 
            // lbl_spY
            // 
            this.lbl_spY.AutoSize = true;
            this.lbl_spY.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_spY.Location = new System.Drawing.Point(12, 48);
            this.lbl_spY.Name = "lbl_spY";
            this.lbl_spY.Size = new System.Drawing.Size(25, 15);
            this.lbl_spY.TabIndex = 36;
            this.lbl_spY.Text = "Y :";
            // 
            // lbl_spX
            // 
            this.lbl_spX.AutoSize = true;
            this.lbl_spX.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lbl_spX.Location = new System.Drawing.Point(12, 23);
            this.lbl_spX.Name = "lbl_spX";
            this.lbl_spX.Size = new System.Drawing.Size(26, 15);
            this.lbl_spX.TabIndex = 36;
            this.lbl_spX.Text = "X :";
            // 
            // nud_sp_T
            // 
            this.nud_sp_T.DecimalPlaces = 2;
            this.nud_sp_T.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_sp_T.Location = new System.Drawing.Point(42, 70);
            this.nud_sp_T.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_sp_T.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_sp_T.Name = "nud_sp_T";
            this.nud_sp_T.Size = new System.Drawing.Size(80, 21);
            this.nud_sp_T.TabIndex = 35;
            this.nud_sp_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_sp_Y
            // 
            this.nud_sp_Y.DecimalPlaces = 3;
            this.nud_sp_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_sp_Y.Location = new System.Drawing.Point(42, 45);
            this.nud_sp_Y.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_sp_Y.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_sp_Y.Name = "nud_sp_Y";
            this.nud_sp_Y.Size = new System.Drawing.Size(80, 21);
            this.nud_sp_Y.TabIndex = 35;
            this.nud_sp_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_sp_X
            // 
            this.nud_sp_X.DecimalPlaces = 3;
            this.nud_sp_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_sp_X.Location = new System.Drawing.Point(42, 20);
            this.nud_sp_X.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_sp_X.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_sp_X.Name = "nud_sp_X";
            this.nud_sp_X.Size = new System.Drawing.Size(80, 21);
            this.nud_sp_X.TabIndex = 35;
            this.nud_sp_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // svdisplayview_simul
            // 
            this.svdisplayview_simul.AutoSize = true;
            this.svdisplayview_simul.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svdisplayview_simul.Dock = System.Windows.Forms.DockStyle.Fill;
            this.svdisplayview_simul.Location = new System.Drawing.Point(3, 3);
            this.svdisplayview_simul.Name = "svdisplayview_simul";
            this.svdisplayview_simul.Size = new System.Drawing.Size(490, 667);
            this.svdisplayview_simul.TabIndex = 3;
            this.svdisplayview_simul.ZoomVisible = false;
            // 
            // SvCalibrationEdit_SimulationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 673);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "SvCalibrationEdit_SimulationForm";
            this.Text = "Simulation";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.simul_param.ResumeLayout(false);
            this.tb_Param.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_target_T)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_target_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_target_X)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tool_T)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tool_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_tool_X)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_spcp_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_spcp_X)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ep_T)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ep_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ep_X)).EndInit();
            this.gb_SP.ResumeLayout(false);
            this.gb_SP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_sp_T)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_sp_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_sp_X)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TabControl simul_param;
        private System.Windows.Forms.TabPage tb_Param;
        private System.Windows.Forms.NumericUpDown nud_sp_X;
        private System.Windows.Forms.GroupBox gb_SP;
        private System.Windows.Forms.NumericUpDown nud_sp_T;
        private System.Windows.Forms.NumericUpDown nud_sp_Y;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbl_spcp_Y;
        private System.Windows.Forms.Label lbl_spcp_X;
        private System.Windows.Forms.NumericUpDown nud_spcp_Y;
        private System.Windows.Forms.NumericUpDown nud_spcp_X;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_epT;
        private System.Windows.Forms.Label lbl_epY;
        private System.Windows.Forms.Label lbl_epX;
        private System.Windows.Forms.NumericUpDown nud_ep_T;
        private System.Windows.Forms.NumericUpDown nud_ep_Y;
        private System.Windows.Forms.NumericUpDown nud_ep_X;
        private System.Windows.Forms.Label lbl_spT;
        private System.Windows.Forms.Label lbl_spY;
        private System.Windows.Forms.Label lbl_spX;
        private System.Windows.Forms.Button simulator_start;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nud_tool_T;
        private System.Windows.Forms.NumericUpDown nud_tool_Y;
        private System.Windows.Forms.NumericUpDown nud_tool_X;
        private System.Windows.Forms.CheckBox cb_AnimationStartEnd;
        private System.Windows.Forms.Button btnMoveTool;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nud_target_T;
        private System.Windows.Forms.NumericUpDown nud_target_Y;
        private System.Windows.Forms.NumericUpDown nud_target_X;
        private System.Windows.Forms.Button btnMoveTarget;
        private Display.SvDisplayViewInteract svdisplayview_simul;



    }
}