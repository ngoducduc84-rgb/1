﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;
using SvMip.Edit;
using SvMip.Display;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using OpenCvSharp.CPlusPlus;

namespace SvMip.Calibration
{
    public partial class SvCalibrationEdit_SimulationForm : Form
    {
        Timer t;
        public SvCalibrationEdit_SimulationForm()
        {
            InitializeComponent();

            t = new Timer();
            t.Interval =10;
            t.Tick += new EventHandler(TimeRun_Tick);

            SetStyle(ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw |
                ControlStyles.UserPaint, true);

            btnMoveTool.Enabled = false;
            btnMoveTarget.Enabled = false;
            cb_AnimationStartEnd.Enabled = false;
        }

        Point3d vision_SP, vision_EP, vision_MP;
        Point2d vision_CSP, vision_CEP, vision_CMP;
        public Point3d StartPT
        {
            get 
            {
                Point3d point = new Point3d();
                point.X = (double)nud_sp_X.Value;
                point.Y = (double)nud_sp_Y.Value;
                point.Z = (double)nud_sp_T.Value;
                return point; 
            }
            set 
            {
                nud_sp_X.Value = (decimal)value.X;
                nud_sp_Y.Value = (decimal)value.Y;
                nud_sp_T.Value = (decimal)value.Z;
            }
        }

        public Point3d TargetPT
        {
            get 
            {
                Point3d point = new Point3d();
                point.X = (double)nud_ep_X.Value;
                point.Y = (double)nud_ep_Y.Value;
                point.Z = (double)nud_ep_T.Value;
                return point; 
            }
            set
            {
                nud_ep_X.Value = (decimal)value.X;
                nud_ep_Y.Value = (decimal)value.Y;
                nud_ep_T.Value = (decimal)value.Z;
            }
        }

        public Point2d centerPT
        {
            get
            {
                Point2d point = new Point2d();
                point.X = (double)nud_spcp_X.Value;
                point.Y = (double)nud_spcp_Y.Value;
                return point; 
            }
            set 
            {
                nud_spcp_X.Value = (decimal)value.X;
                nud_spcp_Y.Value = (decimal)value.Y;
            }
        }

        Point3d trgCntPT;
        public Point3d TargetcenterPT
        {
            get { return trgCntPT; }
            set { trgCntPT = value; }
        }

        Point3d MoveTargetPT;
        Point3d MoveToolPT;

        public SvImage Simul_Image
        {
            get
            {
                return svdisplayview_simul.Image;
            }
            set
            {
                svdisplayview_simul.Image = value;
            }
        }

        public Point3d ToolMovePT
        {
            get
            {
                Point3d point = new Point3d();
                point.X = (double)nud_tool_X.Value;
                point.Y = (double)nud_tool_Y.Value;
                point.Z = (double)nud_tool_T.Value;
                return point;
            }
            set
            {
                nud_tool_X.Value = (decimal)value.X;
                nud_tool_Y.Value = (decimal)value.Y;
                nud_tool_T.Value = (decimal)value.Z;
            }
        }

        public Point3d TargetMovePT
        {
            get
            {
                Point3d point = new Point3d();
                point.X = (double)nud_target_X.Value;
                point.Y = (double)nud_target_Y.Value;
                point.Z = (double)nud_target_T.Value;
                return point;
            }
            set
            {
                nud_target_X.Value = (decimal)value.X;
                nud_target_Y.Value = (decimal)value.Y;
                nud_target_T.Value = (decimal)value.Z;
            }
        }

        public string calPath;
        SvCalibration cal = new SvCalibration();
        protected SvSerializer serializer = new SvSerializer();

        double crossLength;
        float arrowsize;
        float radius;

        public void updatedisplay_simul()
        {
            //DrawCrossLine(System.Drawing.Pens.Red);

            crossLength = 30 / svdisplayview_simul.ZoomRatio;
            arrowsize = 5 / svdisplayview_simul.ZoomRatio;
            radius = 10 / svdisplayview_simul.ZoomRatio;

            DrawObject(System.Drawing.Pens.Blue, vision_SP);                        // Start Point
            DrawTool(System.Drawing.Pens.Blue, vision_SP, vision_CSP);              // Start Tool Center Point

            DrawObject(System.Drawing.Pens.Red, vision_EP);                         // End Point
            DrawTool(System.Drawing.Pens.Red, vision_EP, vision_CEP);               // End Tool Center Point

            DrawObject(System.Drawing.Pens.Green, vision_MP);                       // Move Target Point
            DrawTool(System.Drawing.Pens.Green, vision_MP, vision_CMP);             // Move Tool Center Point

            DrawResult();
        }

        public void DrawCrossLine(Pen p)
        {
            double width = svdisplayview_simul.Width / svdisplayview_simul.ZoomRatio;
            double height = svdisplayview_simul.Height / svdisplayview_simul.ZoomRatio;
            double thetaRad = 0.0;

            Point2d centerPt = new Point2d(width/2, height/2);            

            //cross
            PointF CvP1_0 = svdisplayview_simul.PtoP(centerPt + SvFunc.Rotate(new Point2d(-width / 2, 0), thetaRad));
            PointF CvP1_1 = svdisplayview_simul.PtoP(centerPt + SvFunc.Rotate(new Point2d(+width / 2, 0), thetaRad));
            PointF CvP1_2 = svdisplayview_simul.PtoP(centerPt + SvFunc.Rotate(new Point2d(0, -height / 2), thetaRad));
            PointF CvP1_3 = svdisplayview_simul.PtoP(centerPt + SvFunc.Rotate(new Point2d(0, +height / 2), thetaRad));

            Drawing drawing = new Drawing(delegate(Graphics gdi)
            {
                gdi.DrawLine(p, CvP1_0, CvP1_1);
                gdi.DrawLine(p, CvP1_2, CvP1_3);
            });

            svdisplayview_simul.GraphicsFuncCollection.Add(drawing);
        }

        public void DrawResult()
        {
            Point2d pos = new Point2d(10, 10);
            Font font = new Font("굴림체", 8, System.Drawing.FontStyle.Bold);

            Drawing drawing = new Drawing(delegate(Graphics gdi)
            {
                // Offset Point
                gdi.DrawString(string.Format("Offset:" + "P" + ": ({0:0.00}, {1:0.00})\rT" + ": {2:0.0}Deg", 
                    TargetcenterPT.X, TargetcenterPT.Y, (double)(TargetcenterPT.Z * 180 / Math.PI)), font, Brushes.LightGreen, (float)10, (float)50);

                // Target Point
                gdi.DrawString(string.Format("Target:" + "P" + ": ({0:0.00}, {1:0.00})\rT" + ": {2:0.0}Deg", 
                    MoveTargetPT.X, MoveTargetPT.Y, MoveTargetPT.Z), font, Brushes.LightBlue, (float)10, (float)150);

                // Tool Point
                gdi.DrawString(string.Format("Tool:" + "P" + ": ({0:0.00}, {1:0.00})\rT" + ": {2:0.0}Deg", 
                    MoveToolPT.X, MoveToolPT.Y, MoveToolPT.Z), font, Brushes.Red, (float)10, (float)250);
            });

            svdisplayview_simul.GraphicsFuncCollection.Add(drawing);
        }

        public void DrawObject(Pen p, Point3d centerP)
        {
            Point2d centerP2d;
            centerP2d.X = centerP.X;
            centerP2d.Y = centerP.Y;

            //cross
            PointF CvP1_0 = svdisplayview_simul.PtoP(centerP2d + SvFunc.Rotate(new Point2d(-crossLength / 2, 0), centerP.Z));
            PointF CvP1_1 = svdisplayview_simul.PtoP(centerP2d + SvFunc.Rotate(new Point2d(+crossLength / 2, 0), centerP.Z));
            PointF CvP1_2 = svdisplayview_simul.PtoP(centerP2d + SvFunc.Rotate(new Point2d(0, -crossLength / 2), centerP.Z));
            PointF CvP1_3 = svdisplayview_simul.PtoP(centerP2d + SvFunc.Rotate(new Point2d(0, +crossLength / 2), centerP.Z));

            //arrow
            float scale = arrowsize / SvFunc.getLength(CvP1_0, CvP1_1);
            PointF arrowH = SvFunc.Multiply(CvP1_1 - new SizeF(CvP1_0), scale);
            PointF arrowV = SvFunc.Rotate(arrowH, Math.PI / 2);
            arrowV = SvFunc.Multiply(arrowV, 0.8f);

            PointF arrow2 = CvP1_1 - new SizeF(arrowH) - new SizeF(arrowV);
            PointF arrow3 = CvP1_1 - new SizeF(arrowH) + new SizeF(arrowV);

            PointF[] points = new PointF[4] { CvP1_1, arrow2, arrow3, CvP1_1 };

            Font font = new Font("굴림체", 8, System.Drawing.FontStyle.Bold);

            Drawing drawing = new Drawing(delegate(Graphics gdi)
            {
                gdi.DrawLine(p, CvP1_0, CvP1_1);
                gdi.DrawLine(p, CvP1_2, CvP1_3);
                gdi.DrawPolygon(p, points);
                gdi.FillPolygon(new SolidBrush(p.Color), points);
            });

            svdisplayview_simul.GraphicsFuncCollection.Add(drawing);
        }

        public void DrawTool(Pen p, Point3d centerP, Point2d calcenterP)
        {
            Point2d centerP2d;
            centerP2d.X = centerP.X;
            centerP2d.Y = centerP.Y;

            //circle
            PointF circlepoint = svdisplayview_simul.PtoP(calcenterP) - new SizeF(radius, radius);

            Drawing drawing = new Drawing(delegate(Graphics gdi)
            {
                gdi.DrawEllipse(p, circlepoint.X, circlepoint.Y, radius * 2, radius * 2);
                gdi.DrawLine(p, svdisplayview_simul.PtoP(centerP2d), svdisplayview_simul.PtoP(calcenterP));
            });
            svdisplayview_simul.GraphicsFuncCollection.Add(drawing);
        }

        public void Move_Tool_Click(object sender, EventArgs e)
        {
            svdisplayview_simul.ClearImage();
            TransToolPos(ToolMovePT);
            updatedisplay_simul();
        }

        public void Move_Target_Click(object sender, EventArgs e)
        {
            svdisplayview_simul.ClearImage();
            TransTargetPos(TargetMovePT);
            updatedisplay_simul();
        }

        public void simulator_start_Click(object sender, EventArgs e)
        {
            svdisplayview_simul.ClearImage();
            cal.CalData = serializer.LoadCalibration(calPath);

            vision_SP = StartPT;
            vision_EP = TargetPT;
            vision_SP.Z *= (Math.PI / 180);
            vision_EP.Z *= (Math.PI / 180);
            TargetcenterPT = cal.RToT(vision_SP, vision_EP);

            // Start Point
            vision_SP = cal.RtoV(StartPT);
            vision_CSP = cal.RtoV(cal.CalData.RotCenter);

            // Target Point
            vision_EP = cal.RtoV(TargetPT);
            Point3d Offset = cal.RtoV(new Point3d(cal.CalData.RotCenter.X, cal.CalData.RotCenter.Y, 0) + TargetcenterPT);
            vision_CEP = new Point2d(Offset.X, Offset.Y);

            // Move Point Init
            vision_MP = vision_SP;
            vision_CMP = vision_CSP;

            updatedisplay_simul();

            btnMoveTool.Enabled = true;
            btnMoveTarget.Enabled = true;
            cb_AnimationStartEnd.Enabled = true;
        }

        // Tool이동에 따른 Object의 위치 변화
        private void TransToolPos(Point3d MovePT)
        {
            // 두점사이의 거리 (Object ↔ Tool)
            double R = GetDistance(new Point2d(StartPT.X, StartPT.Y), cal.CalData.RotCenter);

            // 두점사이의 각도 (Object & Tool)
            double T = GetAngle(new Point2d(StartPT.X, StartPT.Y), cal.CalData.RotCenter);

            Point2d Dir = GetDirection(T);

            // Tool기준에서의 Object 위치
            double x = R * Dir.X;
            double y = R * Dir.Y;

            // Move Tool Point
            MoveToolPT = new Point3d(cal.CalData.RotCenter.X, cal.CalData.RotCenter.Y, 0) + MovePT;
            Point3d pos0 = cal.RtoV(MoveToolPT);
            vision_CMP = new Point2d(pos0.X, pos0.Y);

            // Tool 위치이동 (원점)
            double x0 = cal.CalData.RotCenter.X + MovePT.X;
            double y0 = cal.CalData.RotCenter.Y + MovePT.Y;
            Point2d pPoint0 = new Point2d(x0, y0);

            // Object 위치이동 (시작점)
            double x1 = cal.CalData.RotCenter.X + MovePT.X + x;
            double y1 = cal.CalData.RotCenter.Y + MovePT.Y + y;
            Point2d pPoint1 = new Point2d(x1, y1);

            // Tool 회전 변환에 의한 Object 위치이동
            Point2d pPoint2 = transformation(pPoint0, pPoint1, DegreeToRadian(MovePT.Z));

            MoveTargetPT.X = pPoint2.X;
            MoveTargetPT.Y = pPoint2.Y;
            MoveTargetPT.Z = MovePT.Z;

            double dT = StartPT.Z + MovePT.Z;

            vision_MP = cal.RtoV(new Point3d(pPoint2.X, pPoint2.Y, dT));
        }

        // Object이동에 따른 Tool의 위치 변화
        private void TransTargetPos(Point3d MovePT)
        {
            // 두점사이의 거리 (Object ↔ Tool)
            double R = GetDistance(new Point2d(StartPT.X, StartPT.Y), cal.CalData.RotCenter);

            // 두점사이의 각도 (Object & Tool)
            double T = GetAngle(cal.CalData.RotCenter, new Point2d(StartPT.X, StartPT.Y));

            Point2d Dir = GetDirection(T);

            // Object기준에서의 Tool 위치
            double x = R * Dir.X;
            double y = R * Dir.Y;

            // Move Target Point
            MoveTargetPT = new Point3d(StartPT.X, StartPT.Y, StartPT.Z) + MovePT;
            vision_MP = cal.RtoV(MoveTargetPT);            

            // Object 위치이동 (원점)
            double x0 = StartPT.X + MovePT.X;
            double y0 = StartPT.Y + MovePT.Y;
            Point2d pPoint0 = new Point2d(x0, y0);

            // Object 위치이동 (시작점)
            double x1 = StartPT.X + MovePT.X + x;
            double y1 = StartPT.Y + MovePT.Y + y;
            Point2d pPoint1 = new Point2d(x1, y1);

            // Tool 회전 변환에 의한 Object 위치이동
            Point2d pPoint2 = transformation(pPoint0, pPoint1, DegreeToRadian(MovePT.Z));
            MoveToolPT.X = pPoint2.X;
            MoveToolPT.Y = pPoint2.Y;
            MoveToolPT.Z = MovePT.Z;

            vision_CMP = cal.RtoV(pPoint2);
        }

        Point3d temp;
        private void cb_AnimationStartEnd_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox cb = sender as CheckBox;

            if (cb.Checked)
            {
                bX = bY = bZ = false;
                temp = new Point3d(0, 0, 0);

                simulator_start.Enabled = false;
                btnMoveTool.Enabled = false;
                btnMoveTarget.Enabled = false;
                
                t.Start();
                cb.Text = "End";
            }
            else
            {
                simulator_start.Enabled = true;
                btnMoveTool.Enabled = true;
                btnMoveTarget.Enabled = true;

                t.Stop();
                cb.Text = "Start";
            }
        }

        bool bX = false;
        bool bY = false;
        bool bZ = false;

        // 애니메이션 모션
        void TimeRun_Tick(object sender, EventArgs e)
        {
            double dist = 4.5;
            svdisplayview_simul.ClearImage();

            Point3d MovePT = TargetPT - StartPT;

            if (bX == false && bY == false && bZ == false)
            {
                if (Math.Abs(temp.X - MovePT.X) > dist)
                {
                    if (temp.X < MovePT.X)
                        temp.X += dist;
                    else
                        temp.X -= dist;
                }                
                else
                {
                    temp.X = MovePT.X;
                    bX = true;
                }
            }

            if(bX == true && bY == false && bZ == false)
            {
                if (Math.Abs(temp.Y - MovePT.Y) > dist)
                {
                    if (temp.Y < MovePT.Y)
                        temp.Y += dist;
                    else
                        temp.Y -= dist;
                }   
                else
                {
                    temp.Y = MovePT.Y;
                    bY = true;
                }
            }


            if (bX == true && bY == true && bZ == false)
            {
                if (Math.Abs(temp.Z - MovePT.Z) > dist)
                {
                    if (temp.Z < MovePT.Z)
                        temp.Z += dist;
                    else
                        temp.Z -= dist;
                }   
                else
                {
                    temp.Z = MovePT.Z;
                    bZ = true;
                }
            }

            if (bX == true && bY == true && bZ == true)
            {
                simulator_start.Enabled = true;
                btnMoveTool.Enabled = true;
                btnMoveTarget.Enabled = true;

                t.Stop();
                cb_AnimationStartEnd.Text = "Start";
            }

            TransTargetPos(temp);

            updatedisplay_simul();
        }

        // 각도계(Degree)를 호도법(Radian)으로
        public double DegreeToRadian(double deg)
        {
            return deg * (Math.PI / 180);
        }

        // 호도법(Radian)을 각도계(Degree)로
        public double RadianToDegree(double rad)
        {
            return rad * (180 / Math.PI);
        }

        // 두 점 사이의 거리 구하기
        public double GetDistance(Point2d p1, Point2d p2)
        {
            double xdf = p2.X - p1.X;
            double ydf = p2.Y - p1.Y;
            return Math.Sqrt(Math.Pow(xdf, 2) + Math.Pow(ydf, 2));
        }

        // 두 점 사이의 각도 구하기
        public double GetAngle(Point2d p1, Point2d p2)
        {
            double xdf = p2.X - p1.X;
            double ydf = p2.Y - p1.Y;

            double ang = RadianToDegree(Math.Atan2(ydf, xdf));
            return ang + 90;
        }

        // 각도의 방향 구하기
        public Point2d GetDirection(double deg)
        {
            return new Point2d(-(Single)Math.Sin(DegreeToRadian(deg)), (Single)Math.Cos(DegreeToRadian(deg)));
        }

        // 특정좌표를 중심으로 회전변환
        public Point2d transformation(Point2d p1, Point2d p2, double rad)
        {
            double xdf = p2.X - p1.X;
            double ydf = p2.Y - p1.Y;
            double rx = xdf * Math.Cos(rad) - ydf * Math.Sin(rad) + p1.X;
            double ry = xdf * Math.Sin(rad) + ydf * Math.Cos(rad) + p1.Y;

            return new Point2d(rx, ry);
        }
    }
}