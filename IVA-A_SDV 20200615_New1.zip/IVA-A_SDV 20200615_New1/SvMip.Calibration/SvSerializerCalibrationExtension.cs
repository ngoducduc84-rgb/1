﻿using System;
using System.Linq;
using System.Data;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Windows;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using SvMip;
using System.Windows.Forms;
using SvMip.Common;

namespace SvMip.Calibration
{
    public static class SvSerializerExtension
    {
        public static bool SaveCalibration(this SvSerializer serializer, SvCalibrationData cal, string calPath)
        {
            if (cal == null) return false;

            SvImage ci = new SvImage();
            SvImage ri = new SvImage();
            
            if (cal.CalImage != null)
            {
                cal.Width = cal.CalImage.Width;
                cal.Height = cal.CalImage.Height;
                ci = cal.CalImage.Clone(true);
                cal.CalImage.Dispose(); cal.CalImage = null;
            }
            if (cal.RotImage != null)
            {
                ri = cal.RotImage.Clone(true);
                cal.RotImage.Dispose(); cal.RotImage = null;
            }

            bool isOk = serializer.Serializing(calPath, cal);

            if (ci != null) cal.CalImage = ci;
            if (ri != null) cal.RotImage = ri;
            return isOk;
        }

        public static SvCalibrationData LoadCalibration(this SvSerializer serializer, string calPath)
        {
            DateTime dt = DateTime.Now;

            SvCalibrationData cal = (SvCalibrationData)serializer.Deserializing(calPath);
            if (cal != null)
            {
                if (cal.CalImage != null && !cal.CalImage.Mat.IsDisposed)
                {
                    cal.CalImage = new SvImage(new Mat(cal.CalImage.Height, cal.CalImage.Width, MatType.CV_8UC1));
                    cal.RotImage = new SvImage(new Mat(cal.CalImage.Height, cal.CalImage.Width, MatType.CV_8UC1));
                }
                else
                {
                    cal.CalImage = new SvImage(new Mat(cal.Height, cal.Width, MatType.CV_8UC1));
                    cal.RotImage = new SvImage(new Mat(cal.Height, cal.Width, MatType.CV_8UC1));
                }
            }
            SvFunc.TimeWatch(dt, "LoadCalibration");
            return cal;
        }
    }
}
