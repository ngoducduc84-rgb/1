﻿using System.Text;
using System.IO;
using System.Runtime.InteropServices;

namespace SvMip.Common
{
    //ini파일 디폴트 설정 포함 클래스 
    public class SvIni
    {
        // INI 파일에 쓰기
        [DllImport("kernel32")]
        static extern long WritePrivateProfileString(string strSection, string strKey, string strValue, string strFilePath);

        // INI 파일을 읽기
        [DllImport("kernel32")]
        static extern int GetPrivateProfileString(string strSection, string strKey, string strDefault, StringBuilder retVal, int iSize, string strFilePath);

        public string FilePath;
        const int defaultSize = 255;

        StringBuilder sbBuffer;

        /// <summary>
        /// 생성자.
        /// </summary>
        /// <param name="filePath">ini 파일 경로</param>
        public SvIni(string filePath)
        {
            this.FilePath = filePath;
            sbBuffer = new StringBuilder(defaultSize);

            if(!File.Exists(filePath))
            {        
                string dc = Path.GetDirectoryName(filePath);
                if(!Directory.Exists(dc))
                    Directory.CreateDirectory(dc);
                using (File.Create(filePath)) { };
            }
        }                
        
        /// <summary>
        /// INI 파일에 String 쓰기 
        /// </summary>
        /// <param name="section">[SECTION]</param>
        /// <param name="key">KEY = </param>
        /// <param name="value">KEY 값</param>
        public void WriteValue(string section, string key, string value)
        {
            /// <param name="strFilePath">INI 파일 경로</param>
            WritePrivateProfileString(section, key, value, FilePath);
        }

        /// <summary>
        /// INI 파일에 Int 쓰기 
        /// </summary>
        /// <param name="section">[SECTION]</param>
        /// <param name="key">KEY = </param>
        /// <param name="value">KEY 값</param>
        public void WriteValue(string section, string key, object iValue)
        {
            WritePrivateProfileString(section, key, iValue.ToString(), FilePath);
        }

        /// <summary>
        /// INI 파일에서 string 읽기 
        /// </summary>
        /// <param name="section">[SECTION]</param>
        /// <param name="key">KEY = </param>
        /// <param name="defaultValue">SECTION과 KEY를 못 찾았을 때의 기본값</param>
        /// <returns>Key값 리턴</returns>
        public string ReadValue(string section, string key, string defaultValue)
        {
            sbBuffer.Clear();
            GetPrivateProfileString(section, key, defaultValue, sbBuffer, defaultSize, FilePath);

            return sbBuffer.ToString();
        }

        /// <summary>
        /// INI 파일에서 int 읽기 
        /// </summary>
        /// <param name="section">[SECTION]</param>
        /// <param name="key">KEY = </param>
        /// <param name="defaultValue">SECTION과 KEY를 못 찾았을 때의 기본값</param>
        /// <returns>Key값 리턴</returns>
        public double ReadValue(string section, string key, double defaultValue)
        {
            sbBuffer.Clear();
            double value;

            GetPrivateProfileString(section, key, defaultValue.ToString(), sbBuffer, defaultSize, FilePath);

            if (double.TryParse(sbBuffer.ToString(), out value))
                return value;
            else
                return -1;
        }
    }
}
