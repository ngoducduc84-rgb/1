﻿using log4net;
using System;
using System.Threading.Tasks;
using System.IO;
using System.Text;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;

namespace SvMip.Common
{
    public class SvLogger2
    {
        //public static SvLogger Log = new SvLogger();

        log4net.ILog log;
        log4net.Repository.Hierarchy.Hierarchy m_Hierarchy;

        //프로그램 켠 날짜
        DateTime m_Today_Log;
        DateTime m_Today_Image;

        //설정 멤버 변수
        //가급적 아래 AddApender 메서드에서 변경하지 말고 여기서 변경하도록 합시다. 밑에서 바꾸면 저도 햇갈림..

        public string m_strRoot = "D:\\SVL_Data";
        public string pathLog { get { return m_strLog; } set { m_strLog = value; if (!Directory.Exists(m_strLog)) Directory.CreateDirectory(m_strLog); } }
        string m_strLog;                      // 로그 루트. 이 밑에 파일저장
        public string m_strImage;                  // 이미지 루트. 이 밑에 파일저장

        public string m_strOK;                  // OK Image
        public string m_strNG;                  // NG Image
        public string m_strRE;                  // Retry Image
        public string m_strTP;                   // Tape Image

        public bool m_bSaveImageOk = true;
        public bool m_bSaveImageNg = true;
        public bool m_bSaveLog = true;
        public bool m_bSkipAlign = true;
        public bool m_bChangeTapePos = true;
        public bool m_bUseDIO = true;

        public int m_imaxDayImages = 2;                 // Image별 최대백업 날짜
        public int m_imaxDayOkImages = 2;                 // Image별 최대백업 날짜
        public int m_imaxDayNgImages = 2;                 // Image별 최대백업 날짜

        public int m_iMaxSizeSizeBackups = 0;           // 날짜별 Log를 Size(파일크기) 최대 백업로그 갯수. "날짜.번호.log" 형태로 백업로그 생성.
        // 0으로 지정시 용량오버되면 로그파일 새로만듬. 

        public int m_imaxSizeDateBackups = 2;           // 폴더별 Log를 Date(날짜) 최대 로그 갯수
        // 구조상의 문제로 +1 오차가 날 때도 있고 아닐때도 있는데.. 무시합시다....

        string m_strMaximumFileSize = "30MB";           // Log 파일 개당 최대 사이즈. 용량단위 자동파싱하니 "KB", "MB" "GB" 만 쓸것. 대소문자 구분!

        //====================================> 따라서 최대 하드 용량은. 31 X 30MB X 6 = 5.58GB

        //생성자. 초기화
        public SvLogger2(string _logPath)
        {
            m_strLog = _logPath;

            if (!Directory.Exists(m_strLog)) Directory.CreateDirectory(m_strLog);

            //if (!Directory.Exists(m_strOK)) Directory.CreateDirectory(m_strOK);
            //if (!Directory.Exists(m_strNG)) Directory.CreateDirectory(m_strNG);
            //if (!Directory.Exists(m_strRE)) Directory.CreateDirectory(m_strRE);
            //if (!Directory.Exists(m_strTP)) Directory.CreateDirectory(m_strTP);
            
            log = log4net.LogManager.GetLogger("log");

            //logger가 담긴 Repository 계층구조 가져옴.
            m_Hierarchy = (log4net.Repository.Hierarchy.Hierarchy)log4net.LogManager.GetRepository();
            m_Hierarchy.Configured = true;  //이 옵션을 켜줘야 동적생성 가능

            //logger 초기화
            AddApender(log, "%date{yyyy-MM-dd},%date{HH:mm:ss.fff},%message%newline");

            //생성할때 로그 및 이미지 폴더 정리한번 해줌
            CleanLogFolder();

            //프로그램 켠 날짜 저장.
            m_Today_Log = DateTime.Now;
            m_Today_Image = DateTime.Now;
        }

        /// <summary>
        /// 로그 초기화. 로그 기록 패턴정의.
        /// </summary>
        /// <param name="log"></param>
        /// <param name="strPattern"></param>
        void AddApender(log4net.ILog log, string strPattern)
        {
            log4net.Repository.Hierarchy.Logger logger = (log4net.Repository.Hierarchy.Logger)log.Logger;
            log4net.Appender.RollingFileAppender appender = new log4net.Appender.RollingFileAppender();

            //appender 설정
            appender.File = Path.Combine(m_strLog, "Log_.log");                 // 전체 경로에 생성할 메인 로그 파일 이름
            appender.PreserveLogFileNameExtension = true;                                               //파일 확장자를 유지할건지 아닌지 결정. true로 해야 위에서 만든 확장자 그대로.
            appender.StaticLogFileName = false;                                              //파일 이름이 고정인지 아닌지. 고정(true)면 날짜로 이름이 안바뀜.

            appender.Encoding = System.Text.Encoding.Unicode;                       //유니코드 사용
            appender.AppendToFile = true;                                               //파일에 기록한다는 옵션. 필수

            appender.LockingModel = new log4net.Appender.FileAppender.MinimalLock();    //위에서 파일에 기록할때 IO 핸들 잡는 방법. 

            // 파일 롤링 모드 정의 Date + Size
            // 이 부분이 참 뭐시기 한데.. 현재 Log4Net은 날짜별 자동삭제 기능을 제공하지 않음.
            // 자동삭제 기능 제공하는 건 SIze별로 Rolling했을 때만임
            // ex) RollingMode = Composite, size = 1KB, MaxSizeRollBackups = 5 일때
            //     1. 날짜별로 파일 생성
            //     2. 한개 날짜별 Log 파일 크기가 1KB 초과시 ~~~.1.log ~~~.2.log 식으로 5개(~~~.5.log)까지 다시 파일을 만듬
            //     3. 6개째 Size Rolling Log를 만들때는 위에서 만든 1~5번 Rolling Log의 숫자를 뒤로 하나씩 밀어서 5번을 지우고
            //        
            appender.RollingStyle = log4net.Appender.RollingFileAppender.RollingMode.Composite;

            //파일 사이즈로 Rolling 하는 부분. 
            appender.MaxSizeRollBackups = m_iMaxSizeSizeBackups; // 한 날짜당 백업하는 파일 갯수. 날짜당 로그 갯수가 초과하면 예전파일 지운다.
            appender.MaximumFileSize = m_strMaximumFileSize;  // 파일 사이즈만 가지고 파일을 백업한다. 이보다 커지면 로그파일 새로 만든다.

            //날짜 지나면 파일 새로 만든다. Rolling은 안된다
            appender.DatePattern = "yyyyMMdd"; // 날짜가 지나간 경우 이전 로그에 붙을 이름 구성 

            //Log기록하는 패턴.
            appender.Layout = new log4net.Layout.PatternLayout(strPattern);

            //Appender 활성화 및 로그에 붙이기
            appender.ActivateOptions();

            logger.AddAppender(appender);
            logger.Hierarchy = m_Hierarchy;
            logger.Level = logger.Hierarchy.LevelMap["ALL"];
        }

        //코드가 더러워도 사용의 편의성과 날짜별 Rolling을 위해 어쩔수 없음.
        //로거 추가될때마다 이 함수도 추가해야함
        //클래스 상속받을까 했는데... 그냥 이렇게 가겠음.....
        //아아.... OOP..... 지켜야되는데...
        #region 로깅 함수 리패킹.

        public enum LogType { SEQUENCE, ERROR, DEBUG, DATA, RECIPE, TACT }

        public void Sequence(string message)
        {
            //if (!m_bSaveLog) return;

            //RollOverDate(log);

            log.Debug("SEQUENCE," + message);
        }

        public void Error(string message)
        {
            if (!m_bSaveLog) return;

            RollOverDate(log);

            log.Debug("ERROR," + message);
        }

        public void Debug(string message)
        {
            if (!m_bSaveLog) return;

            RollOverDate(log);

            log.Debug("DEBUG," + message);
        }

        public void Recipe(string message)
        {
            if (!m_bSaveLog) return;

            RollOverDate(log);

            log.Debug("RECIPE," + message);
        }

        public void Data(string message, DateTime time)
        {
            if (!m_bSaveLog) return;

            RollOverDate(log);
            //log.Debug("DATA," + message + DateTime.Now.Subtract(time).TotalMilliseconds.ToString("F0"));
            log.Debug("DATA," + message);
        }

        public void Image(Mat img)
        {
            if (!m_bSaveImageOk) return;
            if (img == null) return;

            RollOverImage(m_strOK, false);
            Mat src = img.Clone();

            Task.Factory.StartNew(() => SaveImage(src, string.Format("Img_{0}.png", DateTime.Now.ToString("HHmmss.fff"))));
        }

        public void ErrorImage(Mat img)
        {
            if (!m_bSaveImageNg) return;
            if (img == null) return;

            RollOverImage(m_strNG, false);

            Mat src = img.Clone();

            Task.Factory.StartNew(() => SaveErrorImage(src, string.Format("Err_{0}.png", DateTime.Now.ToString("HHmmss.fff"))));
        }

        public void RetryImage(Mat img)
        {
            if (!m_bSaveImageNg) return;
            if (img == null) return;

            RollOverImage(m_strRE, false);

            Mat src = img.Clone();

            Task.Factory.StartNew(() => SaveRetryImage(src, string.Format("Retry_{0}.png", DateTime.Now.ToString("HHmmss.fff"))));
        }

        public void TapeImage(Mat img)
        {
            if (!m_bSaveImageNg) return;

            RollOverImage(m_strTP, false);

            Mat src = img.Clone();

            Task.Factory.StartNew(() => SaveTapeImage(src, string.Format("Tape_{0}.png", DateTime.Now.ToString("HHmmss.fff"))));
        }

        public void Image(string folderName, string fileName, Mat img)
        {
            RollOverImage(m_strOK, false);

            Mat src = img.Clone();

            Task.Factory.StartNew(() =>
            {
                try
                {
                    string ImgPath = Path.Combine(m_strOK, DateTime.Now.ToString("yyyyMMdd"), folderName);
                    if (!Directory.Exists(ImgPath))
                        Directory.CreateDirectory(ImgPath);

                    img.SaveImage(Path.Combine(ImgPath, string.Format("{0}_{1}.png", fileName, DateTime.Now.ToString("HHmmss.fff"))), new OpenCvSharp.ImageEncodingParam(OpenCvSharp.ImageEncodingID.PngCompression, 3));
                }
                catch
                {
                    log.Debug("DEBUG," + fileName);
                }
                finally
                {
                    img.Dispose();
                }
            });
        }

        public void ErrorImage(string folderName, string fileName, Mat img)
        {
            RollOverImage(m_strNG, false);

            Mat src = img.Clone();

            Task.Factory.StartNew(() =>
            {
                try
                {
                    string ImgPath = Path.Combine(m_strNG, DateTime.Now.ToString("yyyyMMdd"), folderName);
                    if (!Directory.Exists(ImgPath))
                        Directory.CreateDirectory(ImgPath);

                    img.SaveImage(Path.Combine(ImgPath, string.Format("{0}_{1}.png", fileName, DateTime.Now.ToString("HHmmss.fff"))), new OpenCvSharp.ImageEncodingParam(OpenCvSharp.ImageEncodingID.PngCompression, 3));
                }
                catch
                {
                    log.Debug("DEBUG," + fileName);
                }
                finally
                {
                    img.Dispose();
                }
            });
        }

        void SaveImage(Mat img, string fileName)
        {
            try
            {
                string ImgPath = Path.Combine(m_strOK, DateTime.Now.ToString("yyyyMMdd"));
                if (!Directory.Exists(ImgPath))
                    Directory.CreateDirectory(ImgPath);

                img.SaveImage(Path.Combine(ImgPath, fileName), new OpenCvSharp.ImageEncodingParam(OpenCvSharp.ImageEncodingID.PngCompression, 3));
            }
            catch
            {
                log.Debug("DEBUG," + fileName);
            }
            finally
            {
                img.Dispose();
            }
        }

        void SaveErrorImage(Mat img, string fileName)
        {
            try
            {
                string ImgPath = Path.Combine(m_strNG, DateTime.Now.ToString("yyyyMMdd"));
                if (!Directory.Exists(ImgPath))
                    Directory.CreateDirectory(ImgPath);

                img.SaveImage(Path.Combine(ImgPath, fileName), new OpenCvSharp.ImageEncodingParam(OpenCvSharp.ImageEncodingID.PngCompression, 3));
            }
            catch
            {
                log.Debug("DEBUG," + fileName);
            }
            finally
            {
                img.Dispose();
            }
        }

        void SaveRetryImage(Mat img, string fileName)
        {
            try
            {
                string ImgPath = Path.Combine(m_strRE, DateTime.Now.ToString("yyyyMMdd"));
                if (!Directory.Exists(ImgPath))
                    Directory.CreateDirectory(ImgPath);

                img.SaveImage(Path.Combine(ImgPath, fileName), new OpenCvSharp.ImageEncodingParam(OpenCvSharp.ImageEncodingID.PngCompression, 3));
            }
            catch
            {
                log.Debug("DEBUG," + fileName);
            }
            finally
            {
                img.Dispose();
            }
        }

        void SaveTapeImage(Mat img, string fileName)
        {
            try
            {
                string ImgPath = Path.Combine(m_strTP, DateTime.Now.ToString("yyyyMMdd"));
                if (!Directory.Exists(ImgPath))
                    Directory.CreateDirectory(ImgPath);

                img.SaveImage(Path.Combine(ImgPath, fileName), new OpenCvSharp.ImageEncodingParam(OpenCvSharp.ImageEncodingID.PngCompression, 3));
            }
            catch
            {
                log.Debug("DEBUG," + fileName);
            }
            finally
            {
                img.Dispose();
            }
        }
        #endregion

        public void RollOverLog()
        {
            RollOverDate(log, true);
        }

        /// <summary>
        /// 폴더 내의 Log 파일 최대 갯수에 맞춰서 무조건 지우기
        /// </summary>
        /// <param name="log">지울 로그 종류</param>
        void RollOverDate(ILog log)
        {
            RollOverDate(log, false);
        }

        /// <summary>
        /// 폴더 내의 Log 파일 최대 갯수에 맞춰서 지우기
        /// </summary>
        /// <param name="log">지울 로그 종류</param>
        /// <param name="bInitFlag">초기화 플래그. true면 무조건 폴더 정리. false면 날짜 바뀔때만 폴더 정리</param>
        void RollOverDate(ILog log, bool bInitFlag)
        {
            try
            {
                //날짜부터 검사. 날짜가 프로그램 켰을때랑 비교해서 안 바뀌었으면 리턴.
                //bInitFlag가 true이면 리턴 안함.

                if ((DateTime.Now.Subtract(m_Today_Log).TotalDays < 1) && !bInitFlag) return;
                // 로그 디렉토리에서 파일가져와서 갯수 구하기.
                if (!Directory.Exists(m_strLog)) return; //디렉토리가 존재 하지 않으면. 

                string[] strLogFiles = Directory.GetFiles(m_strLog);
                int iCountOfFilesInDir = strLogFiles.GetLength(0);

                //폴더에 파일 없거나 하나만 있을때 리턴.
                if (iCountOfFilesInDir <= 1) return;

                //초과한 파일 갯수
                int iOverCount = iCountOfFilesInDir - m_imaxSizeDateBackups;
                if (iOverCount > 0)
                {
                    //버블소트(아마 겟파일이 이름순으로 가져와서 정렬 되어 있을꺼라 생각.... 그러면 O(n) 복잡도임.)
                    for (int i = 0; i < iCountOfFilesInDir; i++)
                    {
                        for (int j = iCountOfFilesInDir - 1; j > i; j--)
                        {
                            if (strLogFiles[j - 1].CompareTo(strLogFiles[j]) > 0)
                            {
                                string strTemp = strLogFiles[j - 1];
                                strLogFiles[j - 1] = strLogFiles[j];
                                strLogFiles[j] = strTemp;
                            }
                        }
                    }

                    //최대 갯수에서 초과한 만큼 반복해서 삭제.
                    for (int i = 0; i < iOverCount; i++)
                    {
                        // 가장 오래된 날짜 파일 삭제
                        if (File.Exists(strLogFiles[i]))
                        {
                            System.IO.File.Delete(strLogFiles[i]);
                        }
                    }
                }

                //다 했으면 오늘 날짜 업데이트. 이 부분이 중요함.
                if (!bInitFlag)  //초기화 할때 호출한게 아닐떄
                    m_Today_Log = DateTime.Now;
            }
            catch (Exception deleteEx)
            {
                Console.WriteLine(deleteEx.ToString());
            }
        }

        /// <summary>
        /// 로그폴더에서 로그 아닌 다른 폴더/파일 삭제하기
        /// </summary>
        void CleanLogFolder()
        {
            //로그 폴더가 존재하지 않으면 폴더 생성
            if (!Directory.Exists(m_strLog)) Directory.CreateDirectory(m_strLog);

            //로그 폴더내 Sub 폴더 검색하기
            string[] strLogDirs = Directory.GetDirectories(m_strLog);

            //로그 폴더 안에 있는 Sub 폴더 삭제하기
            foreach (string strLogDir in strLogDirs)
            {
                Directory.Delete(strLogDir, true);
            }

            //로그 폴더 안에 있는 확장자가 ".log"(대소문자 구분안함)가 아닌 파일 삭제하기
            string[] strLogFiles = Directory.GetFiles(m_strLog);
            foreach (string strLogFile in strLogFiles)
            {
                string strLogFileExtension = Path.GetExtension(strLogFile);
                if (strLogFileExtension.ToLower() != ".log")
                    File.Delete(strLogFile);
            }
        }

        /// <summary>
        /// Image 폴더의 최대 갯수에 맞춰서 지우기
        /// </summary>
        public void RollOverImage()
        {
            RollOverImage(m_strOK, true);
            RollOverImage(m_strNG, true);
            RollOverImage(m_strRE, true);
            RollOverImage(m_strTP, true);
        }

        void RollOverImage(string strDir, bool bInitFlag)
        {
            try
            {
                //if ((DateTime.Now.Subtract(m_Today_Image).TotalDays < 1) && !bInitFlag) return;

                //이미지 폴더 내 Sub 폴더검색하기
                string[] strImageDirs = Directory.GetDirectories(strDir);
                int iCountOfDir = strImageDirs.GetLength(0);

                //폴더에 Sub 없거나 하나만 있을때 리턴.
                if (iCountOfDir <= 1) return;

                //초과한 Directory 갯수
                int iOverCount;
                
                if (strDir != m_strNG)
                    iOverCount = iCountOfDir - m_imaxDayOkImages;
                else
                    iOverCount = iCountOfDir - m_imaxDayNgImages;

                if (iOverCount > 0)
                {
                    //버블소트(아마 겟파일이 이름순으로 가져와서 정렬 되어 있을꺼라 생각.... 그러면 O(n) 복잡도임.)
                    for (int i = 0; i < iCountOfDir; i++)
                    {
                        for (int j = iCountOfDir - 1; j > i; j--)
                        {
                            if (strImageDirs[j - 1].CompareTo(strImageDirs[j]) > 0)
                            {
                                string strTemp = strImageDirs[j - 1];
                                strImageDirs[j - 1] = strImageDirs[j];
                                strImageDirs[j] = strTemp;
                            }
                        }
                    }

                    //최대 갯수에서 초과한 만큼 반복해서 삭제.
                    for (int i = 0; i < iOverCount; i++)
                    {
                        // 가장 오래된 날짜 폴더 삭제
                        if (Directory.Exists(strImageDirs[i]))
                        {
                            Directory.Delete(strImageDirs[i], true);
                        }
                    }
                }

                if (!bInitFlag)  //초기화 할때 호출한게 아닐떄
                    m_Today_Image = DateTime.Now;
            }
            catch (Exception deleteEx)
            {
                Console.WriteLine(deleteEx.ToString());
            }
        }

        public void SetSaveImageOkEnable(bool Enable)
        {
            m_bSaveImageOk = Enable;
        }

        public void SetSaveImageNgEnable(bool Enable)
        {
            m_bSaveImageNg = Enable;
        }

        public void SetSaveLogEnable(bool Enable)
        {
            m_bSaveLog = Enable;
        }

        public void SetSaveUseDIOEnable(bool Enable)
        {
            m_bUseDIO = Enable;
        }

        public void SetSaveSkipAlignEnable(bool Enable)
        {
            m_bSkipAlign = Enable;
        }

        public void SetChangeTapePosEnable(bool Enable)
        {
            m_bChangeTapePos = Enable;
        }

        public void SetSaveMaxImage(int max)
        {
            m_imaxDayImages = max;
        }

        public void SetSaveMaxImageOk(int max)
        {
            m_imaxDayOkImages = max;
        }

        public void SetSaveMaxImageNg(int max)
        {
            m_imaxDayNgImages = max;
        }

        public void SetSaveMaxLog(int max)
        {
            m_imaxSizeDateBackups = max;
        }
    }
}