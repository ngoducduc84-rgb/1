﻿//using OpenCvSharp.CPlusPlus;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;

//namespace SvMip.Interface.MXCom
//{
//    public class Robot_MXComponent : IRobotDevice
//    {
//        public enum DeviceOffset
//        {
//            SelectedCalibrationNo = 0,
//            CalibrationStart = 1,
//            CalibrationComplete = 2,
//            MoveStart = 3,

//            CalOffset = 10, /*Load1Offset = 16, Load2Offset = 22, UnLoadOffset = 28,*/ CurrentOffset = 94,

//            CurrntModelName = 100,
//            ModelName1 = 120, ModelName2 = 140, ModelName3 = 160, ModelName4 = 180, ModelName5 = 200,
//            ModelName6 = 220, ModelName7 = 240, ModelName8 = 260, ModelName9 = 280, ModelName10 = 300,
//            ModelName11 = 320, ModelName12 = 340, ModelName13 = 360, ModelName14 = 380, ModelName15 = 400,
//            ModelName16 = 420, ModelName17 = 440, ModelName18 = 460, ModelName19 = 480
//        }

//        const int timeout = 20000;

//        const int blockSize = 1000;

//        int mStationNumber;
//        public int StationNumber { get { return mStationNumber; } }

//        int mStartAddress;
//        public int StartAddress { get { return mStartAddress; } }

//        short[] tempDataBlock;

//        protected MXComponent mxcom;
//        public MXComponent Mxcom
//        {
//            get { return mxcom; }
//        }

//        public bool IsConnected { get { return IsOpen; } }

//        EDeviceType DeviceType;

//        public Robot_MXComponent(EDeviceType type, int stationNumber, int startAddress)
//        {
//            mxcom = new MXComponent(type, startAddress, blockSize);
//            tempDataBlock = new short[blockSize];

//            this.DeviceType = type;
//            this.mStationNumber = stationNumber;
//            mStartAddress = startAddress;
//        }

//        public Robot_MXComponent(EDeviceType type, int stationNumber, string _startAddress)
//        {
//            int startAddress;
//            if (int.TryParse(_startAddress, out startAddress)) return;
//            mxcom = new MXComponent(type, startAddress, blockSize);
//            tempDataBlock = new short[blockSize];

//            this.mStationNumber = stationNumber;
//            mStartAddress = startAddress;
//        }

//        public bool IsOpen { get { return mxcom.IsOpen; } }

//        System.Timers.Timer heartBeatTimer;

//        public bool OpenDevice()
//        {
//            if (heartBeatTimer != null)
//            {
//                heartBeatTimer.Stop();
//                heartBeatTimer.Dispose();
//                heartBeatTimer = null;
//            }

//            heartBeatTimer = new System.Timers.Timer(5000);
//            heartBeatTimer.Elapsed += heartBeatTimer_Elapsed;
//            heartBeatTimer.Start();
            
//            return mxcom.Open(mStationNumber);         
//        }

//        void heartBeatTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
//        {
//            short lData;
//            mxcom.ReadDevice("D0", out lData);
//            if (!IsOpen)
//            {
//                heartBeatTimer.Stop();
//                System.Diagnostics.Debug.WriteLine("\r\n=========================PLC is disconneted. Try to open PLC=============================\r\n");

//                mxcom.Close();
//                bool success = mxcom.Open(mStationNumber);
//                if(success)
//                    System.Diagnostics.Debug.WriteLine("\r\n=========================PLC ReOpen=============================\r\n");

//                heartBeatTimer.Start();
//            }
//        }

//        public bool StartCalibration(int index)
//        {
//            bool success = true;
                        
//            if(index > short.MaxValue || index < short.MinValue)
//                return false;

//            short sIndex = Convert.ToInt16(index);

//            success &= mxcom.WriteDevice((int)DeviceOffset.SelectedCalibrationNo, sIndex);
//            success &= mxcom.WriteDevice((int)DeviceOffset.MoveStart, 0);
//            success &= mxcom.WriteDevice((int)DeviceOffset.CalibrationComplete, 0);
//            success &= mxcom.WriteDevice((int)DeviceOffset.CalibrationStart, 1);
//            success &= WriteCalOffset(0f, 0f, 0f);

//            return success;
//        }
                
//        public bool WriteCalOffset(float x, float y, float w)
//        {
//            return WritePosition(0, x, y, w);
//        }

//        public bool MoveCalibration()
//        {

//#if !SIMULATION
//            bool success;
//            try
//            {                    
//                success = mxcom.WriteDevice((int)DeviceOffset.MoveStart, 1);
//                if (!success)
//                    throw new Exception("Communication Timeout");

//                DateTime startTime = DateTime.Now;

//                while (true)
//                {
//                    success = mxcom.UpdateData();                        
//                    if (!success)
//                        throw new Exception("Communication Timeout");
                        
//                    if (mxcom.DataBlock[(int)DeviceOffset.MoveStart] != 1)
//                        break;

//                    if (DateTime.Now.Subtract(startTime).TotalMilliseconds > timeout)
//                    {
//                        System.Diagnostics.Debug.WriteLine("[Interface] Move Timeout");
//                        return false;
//                    }
//                }
//                return true;

//            }
//            catch (Exception ex)
//            {
//                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//            }
//            return false;
//#else            
//            return true;
//#endif
//        }

//        public bool EndCalibration()
//        {
//            bool success = true;

//            success &= mxcom.WriteDevice((int)DeviceOffset.MoveStart, 0);
//            success &= mxcom.WriteDevice((int)DeviceOffset.CalibrationStart, 0);
//            success &= mxcom.WriteDevice((int)DeviceOffset.CalibrationComplete, 1);
//            return success;
//        }
                
//        public string ReadCurrentJobName()
//        {
//            bool success = mxcom.UpdateData();
//            if(!success) return null;
            
//            char[] chars = new char[40];
//            int count = 0;
//            for(int i = 0; i<20; i++)
//            {
//                char ch = Convert.ToChar(mxcom.DataBlock[(int)DeviceOffset.CurrntModelName + i]);
//                char first = (char)(ch & 0x00FF);
//                char second = (char)((ch >> 8) & 0x00FF);
//                if (first <= 0x20 || first > 0x7E)
//                    break;
//                else
//                    chars[count++] = first;

//                if (second <= 0x20 || second > 0x7E)
//                    break;
//                else
//                    chars[count++] = second;                    
//            }

//            return new string(chars, 0, count);
//        }

//        public List<RobotJob> ReadJobList()
//        {
//            bool success = mxcom.UpdateData();
//            if (!success) return null;

//            List<RobotJob> jobList = new List<RobotJob>();

//            char[] chars = new char[40];

//            for (int i = 0; i < 19; i++)
//            {                
//                int startIndex = (int)DeviceOffset.ModelName1 + i * 20;

//                int count = 0;
//                for (int j = 0; j < 20; j++)
//                {
//                    char ch = Convert.ToChar(mxcom.DataBlock[startIndex + j]);

//                    char first = (char)(ch & 0x00FF);
//                    char second = (char)((ch >> 8) & 0x00FF); ;
//                    if (first <= 0x20 || first > 0x7E)
//                        break;
//                    else
//                        chars[count++] = first;

//                    if (second <= 0x20 || second > 0x7E)
//                        break;
//                    else
//                        chars[count++] = second;
//                }

//                string name = new string(chars, 0, count);
//                if (string.IsNullOrEmpty(name)) continue;

//                RobotJob job = new RobotJob();
//                job.name = name;
//                jobList.Add(job);
//            }

//            return jobList;
//        }
        
//        int GetPositionIndex(int index)
//        {
//            if (index < 1 || index > 10)
//                throw new Exception("index range over");

//            return (index - 1) * 6 + (int)DeviceOffset.CalOffset;
//        }
//        //기존에 사용하던 코드
//        public bool WritePositions(int index, List<float[]> listPosition)
//        {
//            int size = listPosition.Count;
//            short[] tempTwoWord = new short[size * 6];

//            for (int i = 0; i < size; i++)
//            {
//                MXComponent.FloatToTwoWord(listPosition[i][0], 4, tempTwoWord, i * 6 + 0);
//                MXComponent.FloatToTwoWord(listPosition[i][1], 4, tempTwoWord, i * 6 + 2);
//                MXComponent.FloatToTwoWord(listPosition[i][2], 4, tempTwoWord, i * 6 + 4);
//            }

//            return mxcom.WriteDeviceBlock(index, tempTwoWord);
//        }

//        //통합 내재화 비젼에서 사용하는 코드
//        //index 값이 절대값으로 사용됨!!
//        public bool WritePositions(int index, List<Point3f> listPosition)
//        {
//            int size = listPosition.Count;
//            short[] tempTwoWord = new short[size * 6];

//            for (int i=0; i< size; i++)
//            {
//                MXComponent.FloatToTwoWord(listPosition[i].X, 4, tempTwoWord, i * 6 + 0);
//                MXComponent.FloatToTwoWord(listPosition[i].Y, 4, tempTwoWord, i * 6 + 2);
//                MXComponent.FloatToTwoWord(listPosition[i].Z, 4, tempTwoWord, i * 6 + 4);
//            }

//            string device = DeviceType.ToString() + index.ToString();
//            return mxcom.WriteDeviceBlock(device, tempTwoWord);

//            //return mxcom.WriteDeviceBlock(index, tempTwoWord);
//        }

//        public bool WritePosition(int index, float x, float y, float w)
//        {
//            short[] tempTwoWord = new short[6];

//            MXComponent.FloatToTwoWord(x, 4, tempTwoWord, 0);
//            MXComponent.FloatToTwoWord(y, 4, tempTwoWord, 2);
//            MXComponent.FloatToTwoWord(w, 4, tempTwoWord, 4);

//            return mxcom.WriteDeviceBlock(GetPositionIndex(index), tempTwoWord);
//        }

//        public bool WritePosition(int index, float x, float y, float z, float roll, float pitch, float yaw)
//        {
//            short[] tempTwoWord = new short[12];

//            MXComponent.FloatToTwoWord(x, 4, tempTwoWord, 0);
//            MXComponent.FloatToTwoWord(y, 4, tempTwoWord, 2);
//            MXComponent.FloatToTwoWord(z, 4, tempTwoWord, 4);
//            MXComponent.FloatToTwoWord(roll, 4, tempTwoWord, 6);
//            MXComponent.FloatToTwoWord(pitch, 4, tempTwoWord, 8);
//            MXComponent.FloatToTwoWord(yaw, 4, tempTwoWord, 10);

//            return mxcom.WriteDeviceBlock(GetPositionIndex(index), tempTwoWord);
//        }

//        [Obsolete]
//        public bool ReadPosition(int index, out float x, out float y, out float w)
//        {
//            int posIndex = GetPositionIndex(index);

//            bool success = mxcom.UpdateData();
//            x = MXComponent.TwoWordToFloat(mxcom.DataBlock, posIndex);
//            y = MXComponent.TwoWordToFloat(mxcom.DataBlock, posIndex + 2);
//            w = MXComponent.TwoWordToFloat(mxcom.DataBlock, posIndex + 4);

//            return success;
//        }

//        //11.24 구성해야함...
//        public bool ReadPositions(int index, out List<Point3f> listPosition)
//        {
//            throw new NotImplementedException();
//        }

//        public bool ReadCurrentPosition(out float x, out float y, out float w)
//        {
//            int currentPosIndex = (int)DeviceOffset.CurrentOffset;

//            bool success = mxcom.UpdateData();
//            x = MXComponent.TwoWordToFloat(mxcom.DataBlock, currentPosIndex);
//            y = MXComponent.TwoWordToFloat(mxcom.DataBlock, currentPosIndex + 2);
//            w = MXComponent.TwoWordToFloat(mxcom.DataBlock, currentPosIndex + 4);

//            return success;
//        }

//        public bool WriteSignal(string index, bool signal)
//        {
//            short sSignal = Convert.ToInt16(signal);
//            bool success = mxcom.WriteDevice(index, sSignal);

//            return success;
//        }
//        public bool ReadSignal(string index)
//        {
//            short sSignal = 0;
//            bool success = mxcom.ReadDevice(index, out sSignal);
//            if (sSignal > 1)
//            {
//                return false;
//            }
//            if (!success) return false;
//            return Convert.ToBoolean(sSignal);
//        }

//        [Obsolete]
//        public bool WriteValue(int index, int value)
//        {                
//            return mxcom.WriteDeviceBlock(index, MXComponent.IntToTwoWord(value));
//        }

//        public bool WriteValue(int index, short value)
//        {
//            return mxcom.WriteDevice(index, value);
//        }

//        [Obsolete]
//        public bool WriteValue(int index, float value)
//        {
//            return mxcom.WriteDeviceBlock(index, MXComponent.FloatToTwoWord(value));
//        }
//        [Obsolete]
//        public bool WriteValue(int index, string value)
//        {
//            throw new NotImplementedException();
//        }

//        public bool ReadValue(int index, out string value)
//        {
//            throw new NotImplementedException();
//        }


//        [Obsolete]
//        public bool ReadValue(int index, out int value)
//        {
//            bool success = mxcom.UpdateData();
//            value = MXComponent.TwoWordToInt(mxcom.DataBlock, index);
//            return success;
//        }

//        public bool ReadValue(int index, out short value)
//        {
//            bool success = mxcom.UpdateData();
//            value = mxcom.DataBlock[index];
//            return success;
//        }

//        [Obsolete]
//        public bool ReadValue(int index, out float value)
//        {
//            bool success = mxcom.UpdateData();
//            value = MXComponent.TwoWordToFloat(mxcom.DataBlock, index);
//            return success;
//        }

//        public bool CloseDevice()
//        {
//            if(IsOpen)
//                return mxcom.Close();
//            return true;
//        }

//        public void Dispose()
//        {
//            CloseDevice();
//        }
//    }
//}
