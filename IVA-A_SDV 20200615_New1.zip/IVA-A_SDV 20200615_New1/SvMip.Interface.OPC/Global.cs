﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace SvMip.Interface.OPC
{
    public static class Global
    {

        public static double[] sumTime = new double[4];
        public static double[] midTime = new double[4];
        public static double[] cycleCounter = new double[4];
        public static Stopwatch[] watch = new Stopwatch[4];

        public static List<string[]> resultStringListBigDataRead;
        public static List<string[]> resultStringListBitEventsRead;
        public static List<string[]> resultStringListBigDataWrite;
        public static List<string[]> resultStringListBitComandsWrite;


        public static String[] parseString = new String[4];
        public static String[] xmlString = new String[4];
        public static List<object> varListBigDataRead;
        public static List<object> varListBitEventsRead;
        public static List<object> varListBigDataWrite;
        public static List<object> varListBitEventsWrite;

        public static Boolean allNodesAreRegistred = false;

    }
}
