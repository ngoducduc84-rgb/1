﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SvMip.Interface.OPC
{
    public class IO_UAClient : Robot_UAClient, IIO, IRobotDevice
    {
        Thread mReadThread, mWriteThread;
        bool mThreadFlag = false;

        int mWriteStartAddress;
        int mWriteWordSize;
        int mReadStartAddress;
        int mReadWordSize;

        public Dictionary<int, bool> InIO { get { return mInIO; } }
        Dictionary<int, bool> mInIO = new Dictionary<int, bool>();

        public Dictionary<int, bool> OutIO { get { return mOutIO; } }
        Dictionary<int, bool> mOutIO = new Dictionary<int, bool>();
        bool[] ReadIO;

        public int InAddress { get { return mReadStartAddress; } set { mReadStartAddress = value; } }
        public int InLength { get { return mReadWordSize; } set { mReadWordSize = value; } }// InIO = new bool[value]; } }
        public int OutAddress { get { return mWriteStartAddress; } set { mWriteStartAddress = value; } }
        public int OutLength { get { return mWriteWordSize; } set { mWriteWordSize = value; } }// OutIO = new bool[value]; } }

        public IO_UAClient(EDeviceType type, string ipAddress, int port)
            : base(type, ipAddress, port)
        {
            //mWriteStartAddress = _writeStartAddress;
            //OutLength = _writeWordSize;
            //mReadStartAddress = _readStartAddress;
            //InLength = _readWordSize;
        }

        public void ThreadStart()
        {
            if (mThreadFlag)
            {
                ThreadStop();
                Thread.Sleep(100);
            }

            mThreadFlag = true;
            mReadThread = new Thread(new ThreadStart(GetBlockData));
            mReadThread.Start();
            // DataWrite 하나씩 쓰도록 변경 (TKL, 19.04.17)
            //mWriteThread = new Thread(new ThreadStart(SetBlockData));
            //mWriteThread.Start();
        }

        public void ThreadStop()
        {
            mThreadFlag = false;

            if (mReadThread != null)
            {
                mReadThread.Abort();
                mReadThread.Join();
            }
        }

        public bool SetOutValue(int _index, bool _value, bool _select = true)
        {
            mOutIO[_index - mWriteStartAddress] = _value;
            bool b = SetBlockData();

            return b;
        }

        public bool SetInValue(int _index, bool _value)
        {
            mInIO[_index - mReadStartAddress] = _value;
            return true;
        }

        public bool GetInValue(int _index)
        {
            return mInIO[_index - mReadStartAddress];
        }

        public bool GetOutValue(int _index)
        {
            return mOutIO[_index - mWriteStartAddress];
        }

        void GetBlockData()
        {
            while (mThreadFlag)
            {
                if (myUAClient == null) break;

                myUAClient.UpdateBitData(GetNodeID((int)Tag.PLC_Hs));

                // 고동성 책임님, 먼 훗날 사용시 수정 부탁드립니다. From A.S.H
                //ReadIO = InIO = myUAClient.bitDataBlock;

                // Monitor
                ReadIOValue(mVisionIO);

                myUAClient.UpdateBitData(GetNodeID((int)Tag.PC_Hs));
                ReadIO = myUAClient.bitDataBlock;
                ReadIOValue(mPlcIO);

                Thread.Sleep(10);
            }
        }

        public bool GetOutIOCehck()
        {
            SvMip.Common.SvLogger.Log.Error("UAClient 통신 OutIO check 기능 구현 안됨. 필요시 추가");
            return true;
        }

        // DataWrite 방식 변경 (TKL, 19.04.17)
        //void SetBlockData()
        //{
        //    while (mThreadFlag)
        //    {
        //        if (myUAClient == null) break;
        //        myUAClient.BitWriteValues(mOutIO.Values.Cast<object>().ToArray(), GetNodeID((int)Tag.PC_Hs));
        //        Thread.Sleep(10);
        //    }
        //}

        // DataWrite 전체쓰기 (TKL, 19.04.17)
        bool SetBlockData()
        {
            if (myUAClient != null)
            {
                bool b = myUAClient.BitWriteValues(mOutIO.Values.Cast<object>().ToArray(), GetNodeID((int)Tag.PC_Hs));
                Thread.Sleep(10);
                return b;
            }
            return false;
        }

        bool WriteBlockData(int _index, bool _value)
        {
            if (myUAClient != null)
            {
                bool b = myUAClient.BitWriteValues(_value, GetNodeID((int)Tag.PC_Hs));
                Thread.Sleep(10);
                return b;
            }
            return false;
        }

        public void ReadIOValue(Dictionary<string, IO> _io)
        {
            foreach (KeyValuePair<string, IO> io in _io)
            {
                io.Value.mValue = ReadIO[io.Value.mBit];
            }
        }

        public new void Dispose()
        {
            ThreadStop();
        }

        public bool WriteBit()
        {
            bool b = SetBlockData();
            return b;
        }

        public void ResetBit()
        {
            SetBlockData();
        }
    }
}
