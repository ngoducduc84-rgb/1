﻿using System;
using System.Collections.Generic;
using System.Linq;
using Opc.Ua;
using Opc.Ua.Client;
using OpenCvSharp.CPlusPlus;
using SvMip.Common;
using System.Data;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.IO;
using System.Threading;
using System.Windows;

namespace SvMip.Interface.OPC
{
    public class DefSystem
    {
        public static int DEF_SUCCESS = 1;
        public static int DEF_FAIL = 0;

        public static string PATH_BASE = "C:\\SVL_Data";
        public static string PATH_SYSTEM = "System";
        public static string FILE_INTERFACE = "Interface";
        public static string FILE_VISION_TABLE = "VisionTable";
        public static string FILE_PLC_TABLE = "PlcTable";
        public static string EXTENSION_BIN = ".bin";
    }

    // LD & UD 구분을 위해 활용
    // Loader - D
    // Unloader - ZR
    public enum EDeviceType { D, ZR }
    public class Robot_UAClient : IRobotDevice
    {
        public enum DeviceOffset
        {
            CalOffset = 10,
            Load1Offset = 16,
            Load2Offset = 22,
            UnLoadOffset = 28,
            CurrentOffset = 94,

            CurrntModelName = 100,
            ModelName1 = 120
        }

        public enum Calibration
        {
            SelectedCalibrationNo = 0,
            CalibrationStart = 1,
            CalibrationComplete = 2,
            MoveStart = 3
        }

        // 0 : address 0 - LD Object #1
        // 1 : address 6 - LD Object #2 
        // 2 : address 0 - LD Tray #1
        // 3 : address 96 - LD Tray #2

        public enum Tag
        {
            /*
             * LD PC Cal                : Calibration Signal
             * LD PC CalPos             : Calibration & Current Position
             * LD PC HS                 : Output I/O Signal
             * LD PC INFO               : Cell Exist in Tray
             * LD PC ObjOffset1         : Object 1 Offset Value
             * LD PC ObjOffset2         : Object 2 Offset Value
             * LD PC TrayOffset1        : OK Tray Offset Value
             * LD PC TrayOffset2        : NG Tray Offset Value
             * 
             * LD PLC Model             : Recipe Name List
             * LD PLC INFO              : Object, Tray Exist
             * LD PLC HS                : Input I/O Signal
             */

            PC_Cal = 10,
            PC_CalPos = 11,
            PC_Hs = 12,
            PC_Info = 13,
            PC_ObjOffset1 = 14,
            PC_ObjOffset2 = 15,
            PC_TrayOffset1 = 16,
            PC_TrayOffset2 = 17,
            PLC_Model = 18,
            PLC_Info = 19,
            PLC_Hs = 20,
        }

        public enum eIODataType
        {
            Integer,
            Boolean,
            Double,
            String,
            DataSet,
        }

        public enum eIOModeType
        {
            ReadOnly,
            WriteOnly,
            ReadWrite,
        }

        public enum eIOAssignType
        {
            Plc,
            Vision
        }

        public enum eIOOrder
        {
            ID,
            Description,
            Word,
            Qty,
            DataType,
            Bit,
            Digit,
            ModeType,
        }

        public enum eTableType
        {
            PlcTable,
            VisionTable,
        }

        public class IO
        {
            public string mID;
            public int mOffset;
            public string mDescription;
            public string mWord;
            public short mBit;
            public int mQty;
            public short mDigit;

            public eIOAssignType mIoAssignType;
            public eIOModeType mIoModeType;
            public eIODataType mIoDataType;

            public object mValue;
        }

        public Dictionary<string, IO> mPlcIO;
        public Dictionary<string, IO> mVisionIO;

        private string mPlcStartIO;
        public string PlcStartIO { get { return mPlcStartIO; } }
        private string mVisionStartIO;
        public string VisionStartIO { get { return mVisionStartIO; } }

        private int mPlcDataLenth;
        public int PlcDataLength { get { return mPlcDataLenth; } }
        private int mVisionDataLength;
        public int VisionDataLength { get { return mVisionDataLength; } }

        public DataTable mPlcTable;
        public DataTable mVisionTable;


        protected UAClient myUAClient;
        public UAClient UAClient
        {
            get { return myUAClient; }
        }

        private Session mySession;
        //private Subscription mySubscription;
        //private EndpointDescription mySelectedEndpoint;
        //private MonitoredItem myMonitoredItem;
        private Boolean mySecurity = false;
        private List<String> myNodeIdStrings;

        //System.Timers.Timer heartBeatTimer;
        //public bool IsConnected { get { return IsOpen; } }
        //public bool IsOpen { get { return myUAClient.isConnected; } }
        protected Thread mThread = null;
        public bool mThreadFlag = false;
        bool mIsConnected = false;
        public bool IsConnected { get { return mIsConnected; } }

        public bool IsOpen
        {
            get
            {
                return myUAClient.isConnected;
            }
        }

        public static string defaultIp = "192.168.0.1";
        protected string ipAddress = "192.168.0.1";
        protected int port = 4840;
        protected string endpointURL;
        const int timeout = 200000;
        static object communicationLock = new object();
        protected EDeviceType DeviceType;


        /// <summary>
        /// OPC_UAClient 생성자. 내부 변수들 초기화
        /// </summary>
        /// <param name="ipAddress">IP Address/param>
        /// <param name="port">Port Number/param>
        public Robot_UAClient(EDeviceType type, string ipAddress, int port)
        {
            mPlcTable = new DataTable();
            mVisionTable = new DataTable();

            mPlcIO = new Dictionary<string, IO>();
            mVisionIO = new Dictionary<string, IO>();

            mPlcStartIO = "";
            mVisionStartIO = "";
            mPlcDataLenth = 0;
            mVisionDataLength = 0;

            myUAClient = new UAClient();
            myNodeIdStrings = new List<String>();

            this.DeviceType = type;
            this.ipAddress = ipAddress;
            this.port = port;
            mySecurity = false;
            endpointURL = "opc.tcp://" + ipAddress.ToString() + ":" + port.ToString();

            if (!OpenDevice())
            {
                SvLogger.Log.Error("[Interface] Ethernet Port Open Fail");
            }
        }


        /// <summary>
        /// MXCom 연결하는 함수
        /// </summary>
        /// <param name="StationNumber">Open할 스테이션 번호</param>
        /// <returns></returns>
        public bool OpenDevice()
        {

            ThreadStart();

            //if (heartBeatTimer != null)
            //{
            //    heartBeatTimer.Stop();
            //    heartBeatTimer.Dispose();
            //    heartBeatTimer = null;
            //}

            //heartBeatTimer = new System.Timers.Timer(3000);
            //heartBeatTimer.Elapsed += heartBeatTimer_Elapsed;
            //heartBeatTimer.Start();


            return Open(endpointURL);
        }


        public void ThreadStart()
        {
            //SequenceLog("Auto Mode Start", SvLogger.LogType.SEQUENCE);

            if (mThreadFlag)
            {
                ThreadStop();
                Thread.Sleep(100);
            }
            mThreadFlag = true;

            mThread = new Thread(new ThreadStart(ThreadFunction_opc));
            mThread.Start();
        }

        public void ThreadStop()
        {
            //SequenceLog("Auto Mode Stop", SvLogger.LogType.SEQUENCE);

            mThreadFlag = false;

            if (mThread != null)
            {
                mThread.Abort();
                mThread.Join();
                Thread.Sleep(50);
            }
        }

        public void ThreadFunction_opc()
        {
            while (mThreadFlag)
            {
                mIsConnected = myUAClient.WriteValue(0, GetCalibrationNodeID((int)Calibration.SelectedCalibrationNo));
                // retry
                if (!IsConnected)
                {
                    Thread.Sleep(500);
                    mIsConnected = myUAClient.WriteValue(0, GetCalibrationNodeID((int)Calibration.SelectedCalibrationNo));
                }

                if (!mIsConnected)
                {

                    ThreadStop();
                    SvMip.Common.SvLogger.Log.Debug("\r\n=========================PLC is disconneted. Try to open PLC=============================\r\n");

                    mIsConnected = myUAClient.Reconnect(endpointURL, mySecurity);
                    if (mIsConnected)
                        SvMip.Common.SvLogger.Log.Debug("\r\n=========================PLC ReOpen=============================\r\n");

                    ThreadStart();
                }
                Thread.Sleep(5000);
            }
        }

        public bool Open(string endpointURL)
        {
            if (mySession != null && !mySession.Disposed)
            {
                myUAClient.Disconnect();
                mySession = myUAClient.Session;
            }
            else
            {
                try
                {
                    myUAClient.Connect(endpointURL, mySecurity);
                    mySession = myUAClient.Session;
                    myUAClient.KeepAliveNotification += new KeepAliveEventHandler(Notification_KeepAlive);
                }
                catch (Exception e)
                {
                    return false;
                }
            }

            return true;
        }
        private void Notification_KeepAlive(Session sender, KeepAliveEventArgs e)
        {
            try
            {
                // check for events from discarded sessions.
                if (!Object.ReferenceEquals(sender, mySession))
                {
                    return;
                }

                // check for disconnected session.
                if (ServiceResult.IsBad(e.Status))
                {
                    // try reconnecting using the existing session state
                    mySession.Reconnect();
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Error");
                myUAClient.Reconnect(endpointURL, mySecurity);
                MessageBox.Show("Check Interface :  Notification_KeepAlive Error, Reconnect Error", "Error");
            }
        }

        public bool CloseDevice()
        {
            if (IsConnected)
                return myUAClient.Disconnect();
            return true;
        }

        public void Dispose()
        {
            CloseDevice();
        }

        public string GetCalibrationNodeID(int index)
        {
            string NodeIdString = null;

            switch (index)
            {
                case (int)(Calibration.SelectedCalibrationNo):
                    NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"Cal\"[0]";
                    break;
                case (int)(Calibration.CalibrationStart):
                    NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"Cal\"[1]";
                    break;
                case (int)(Calibration.CalibrationComplete):
                    NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"Cal\"[2]";
                    break;
                case (int)(Calibration.MoveStart):
                    NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"Cal\"[3]";
                    break;
                default:
                    break;
            }

            return NodeIdString;
        }


        public bool StartCalibration(int index)
        {
            bool success = true;

            if (index > short.MaxValue || index < short.MinValue)
                return false;

            success &= myUAClient.WriteValue(index, GetCalibrationNodeID((int)Calibration.SelectedCalibrationNo));

            success &= myUAClient.WriteValue(0, GetCalibrationNodeID((int)Calibration.MoveStart));
            success &= myUAClient.WriteValue(0, GetCalibrationNodeID((int)Calibration.CalibrationComplete));
            success &= myUAClient.WriteValue(1, GetCalibrationNodeID((int)Calibration.CalibrationStart));
            success &= WriteCalOffset(0f, 0f, 0f);

            return success;
        }

        public bool WriteCalOffset(float x, float y, float w)
        {
            return WritePosition(0, x, y, w);
        }

        public bool MoveCalibration()
        {

#if !SIMULATION
            bool success;
            try
            {
                success = myUAClient.WriteValue(1, GetCalibrationNodeID((int)Calibration.MoveStart));
                if (!success)
                    throw new Exception("Communication Timeout");

                DateTime startTime = DateTime.Now;

                while (true)
                {
                    if ((bool)myUAClient.ReadValue(GetCalibrationNodeID((int)Calibration.MoveStart)) != true)
                        break;

                    if (DateTime.Now.Subtract(startTime).TotalMilliseconds > timeout)
                    {
                        System.Diagnostics.Debug.WriteLine("[Interface] Move Timeout");
                        return false;
                    }
                }
                return true;

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
            }
            return false;
#else            
            return true;
#endif
        }

        public bool EndCalibration()
        {
            bool success = true;

            success &= myUAClient.WriteValue(0, GetCalibrationNodeID((int)Calibration.MoveStart));
            success &= myUAClient.WriteValue(0, GetCalibrationNodeID((int)Calibration.CalibrationStart));
            success &= myUAClient.WriteValue(1, GetCalibrationNodeID((int)Calibration.CalibrationComplete));

            return success;
        }

        public string ReadCurrentJobName()
        {
            bool success = myUAClient.UpdateStringData(GetNodeID((int)Tag.PLC_Model));
            if (!success) return null;

            return (string)myUAClient.stringDataBlock[0];
        }

        public List<RobotJob> ReadJobList()
        {
            bool success = myUAClient.UpdateStringData(GetNodeID((int)Tag.PLC_Model));
            if (!success) return null;

            List<RobotJob> jobList = new List<RobotJob>();

            for (int i = 1; i < 20; i++)
            {
                string name = (string)myUAClient.stringDataBlock[i];

                if (string.IsNullOrEmpty(name)) continue;

                RobotJob job = new RobotJob();
                job.name = name;
                jobList.Add(job);
            }

            return jobList;
        }
        public string ReadCellID(int count)
        {
            throw new NotImplementedException();
        }
        public string GetNodeID(int index)
        {
            string NodeIdString = null;

            if ((int)this.DeviceType == 0)
            {
                switch (index)
                {
                    case (int)(Tag.PC_Cal):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"Cal\"";
                        break;
                    case (int)(Tag.PC_CalPos):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"CalPos\"";
                        break;
                    case (int)(Tag.PC_Hs):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"HS\"";
                        break;
                    case (int)(Tag.PC_Info):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"INFO\"";
                        break;
                    case (int)(Tag.PC_ObjOffset1):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"ObjOffset1\"";
                        break;
                    case (int)(Tag.PC_ObjOffset2):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"ObjOffset2\"";
                        break;
                    case (int)(Tag.PC_TrayOffset1):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"TrayOffset1\"";
                        break;
                    case (int)(Tag.PC_TrayOffset2):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PC\".\"TrayOffset2\"";
                        break;
                    case (int)(Tag.PLC_Model):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PLC\".\"Model\"";
                        break;
                    case (int)(Tag.PLC_Info):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PLC\".\"INFO\"";
                        break;
                    case (int)(Tag.PLC_Hs):
                        NodeIdString = "ns=3;s=\"Vision\".\"LD\".\"PLC\".\"HS\"";
                        break;
                }
            }
            else
            {
                switch (index)
                {
                    case (int)(Tag.PC_Cal):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PC\".\"Cal\"";
                        break;
                    case (int)(Tag.PC_CalPos):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PC\".\"CalPos\"";
                        break;
                    case (int)(Tag.PC_Hs):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PC\".\"HS\"";
                        break;
                    case (int)(Tag.PC_Info):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PC\".\"INFO\"";
                        break;
                    case (int)(Tag.PC_ObjOffset1):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PC\".\"ObjOffset1\"";
                        break;
                    case (int)(Tag.PC_ObjOffset2):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PC\".\"ObjOffset2\"";
                        break;
                    case (int)(Tag.PC_TrayOffset1):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PC\".\"TrayOffset1\"";
                        break;
                    case (int)(Tag.PC_TrayOffset2):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PC\".\"TrayOffset2\"";
                        break;
                    case (int)(Tag.PLC_Model):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PLC\".\"Model\"";
                        break;
                    case (int)(Tag.PLC_Info):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PLC\".\"INFO\"";
                        break;
                    case (int)(Tag.PLC_Hs):
                        NodeIdString = "ns=3;s=\"Vision\".\"UD\".\"PLC\".\"HS\"";
                        break;
                }
            }

            return NodeIdString;
        }


        //통합 내재화 비젼에서 사용하는 코드
        //index 값이 절대값으로 사용됨!!
        // Tray Offset Data 전송
        public bool WritePositions(int index, List<Point3f> listPosition)
        {
            bool success = false;
            int size = listPosition.Count;

            float[] values = null;

            if (index < 2)
                values = new float[12];
            else
                values = new float[192];

            for (int i = 0; i < size; i++)
            {
                values[i * 3 + 0] = listPosition[i].X;
                values[i * 3 + 1] = listPosition[i].Y;
                values[i * 3 + 2] = listPosition[i].Z;
            }

            switch (index)
            {
                case 0:
                    success = myUAClient.WriteValues(values.Cast<object>().ToArray(), GetNodeID((int)Tag.PC_ObjOffset1));
                    break;
                case 1:
                    success = myUAClient.WriteValues(values.Cast<object>().ToArray(), GetNodeID((int)Tag.PC_ObjOffset2));
                    break;
                case 2:
                    success = myUAClient.WriteValues(values.Cast<object>().ToArray(), GetNodeID((int)Tag.PC_TrayOffset1));
                    break;
                case 3:
                    success = myUAClient.WriteValues(values.Cast<object>().ToArray(), GetNodeID((int)Tag.PC_TrayOffset2));
                    break;
                default:
                    success = false;
                    break;
            }

            return success;
        }

        // Calibration & Current Position Data 전송용으로 활용 (Tag.PC_Cal)
        public bool WritePosition(int index, float x, float y, float w)
        {
            float[] values = new float[6];

            // 기존데이터 Read
            if (myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_CalPos)))
            {
                // 기존데이터 
                values = myUAClient.floatDataBlock;

                values[index + 0] = x;
                values[index + 1] = y;
                values[index + 2] = w;
            }

            return myUAClient.WriteValues(values.Cast<object>().ToArray(), GetNodeID((int)Tag.PC_CalPos));
        }

        public bool WritePosition(int index, float x, float y, float z, float roll, float pitch, float yaw)
        {
            return true;
            //float[] values = new float[6];

            //values[0] = x;
            //values[1] = y;
            //values[2] = z;
            //values[3] = roll;
            //values[4] = pitch;
            //values[5] = yaw;

            //return myUAClient.WriteValues(values.Cast<object>().ToArray(), GetNodeID((int)Tag.PC_CalPos));
        }

        public bool ReadPositions(int index, out float[] values)
        {
            bool success = myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_CalPos));

            switch (index)
            {
                case 0:
                    success = myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_ObjOffset1));
                    break;
                case 1:
                    success = myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_ObjOffset2));
                    break;
                case 2:
                    success = myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_TrayOffset1));
                    break;
                case 3:
                    success = myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_TrayOffset2));
                    break;
                default:
                    success = false;
                    break;
            }

            values = myUAClient.floatDataBlock;
            return success;
        }

        // Calibration & Current Position Data 읽기용으로 활용 (Tag.PC_Cal)

        public bool ReadPosition(int index, out float x, out float y, out float w)
        {
            bool success = myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_CalPos));

            x = (float)myUAClient.floatDataBlock[index + 0];
            y = (float)myUAClient.floatDataBlock[index + 1];
            w = (float)myUAClient.floatDataBlock[index + 2];

            return success;
        }

        public bool ReadCurrentPosition(out float x, out float y, out float w)
        {
            int currentPosIndex = (int)DeviceOffset.CurrentOffset;

            bool success = myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_CalPos));

            x = (float)myUAClient.floatDataBlock[currentPosIndex + 0];
            y = (float)myUAClient.floatDataBlock[currentPosIndex + 1];
            w = (float)myUAClient.floatDataBlock[currentPosIndex + 2];

            return success;
        }

        public bool WriteValue(int index, int value)
        {
            // int to obj array
            string nodeId = GetNodeID((int)Tag.PC_Info);
            object[] rst = new object[32];
            for (int i = 0; i < 32; i++)
            {
                rst[i] = (value & (1 << i)) > 0 ? true : false;
            }
            return myUAClient.BitWriteValues(rst, nodeId);
        }

        [Obsolete]
        public bool WriteValue(int index, bool value)
        {
            string nodeId = GetNodeID((int)Tag.PLC_Hs) + string.Format("[{0}]", index);
            return myUAClient.WriteValue(value, nodeId);
        }

        [Obsolete]
        public bool WriteValue(int index, float value)
        {
            string nodeId = GetNodeID((int)Tag.PC_CalPos) + string.Format("[{0}]", index);
            return myUAClient.WriteValue(value, nodeId);
        }

        [Obsolete]
        public bool WriteValue(int index, short value)
        {
            string nodeId = GetNodeID((int)Tag.PC_CalPos) + string.Format("[{0}]", index);
            return myUAClient.WriteValue(value, nodeId);
        }

        [Obsolete]
        public bool WriteValue(int index, string value)
        {
            string nodeId = GetNodeID((int)Tag.PLC_Model) + string.Format("[{0}]", index);
            return myUAClient.WriteValue(value, nodeId);
        }

        [Obsolete]
        public bool ReadValue(int index, out int value)
        {
            bool success = myUAClient.UpdateIntData(GetNodeID((int)Tag.PC_Cal));
            value = (int)myUAClient.intDataBlock[index];
            return success;
        }

        [Obsolete]
        public bool ReadValue(int index, out bool value)
        {
            bool success = myUAClient.UpdateBitData(GetNodeID((int)Tag.PLC_Hs));
            value = (bool)myUAClient.bitDataBlock[index];
            return success;
        }

        [Obsolete]
        public bool ReadValue(int index, out float value)
        {
            bool success = myUAClient.UpdateFloatData(GetNodeID((int)Tag.PC_CalPos));
            value = (float)myUAClient.floatDataBlock[index];
            return success;
        }

        [Obsolete]
        public bool ReadValue(int index, out string value)
        {
            bool success = myUAClient.UpdateStringData(GetNodeID((int)Tag.PLC_Model));
            value = (string)myUAClient.stringDataBlock[index];
            return success;
        }


        // LSH TEST
        public bool WriteValues(int index, List<float> value)
        {
            return true;
        }

        public int Initialize()
        {
            Load(eTableType.PlcTable);
            Load(eTableType.VisionTable);
            IoAssign();
            return DefSystem.DEF_SUCCESS;
        }

        /// <summary>
        /// Table을 Save 하는 함수
        /// Interface 표준화를 하였으나 확장성을 위하여 Table로 하는걸로....
        /// </summary>
        /// <param name="_tableType">PLC or Vision</param>
        /// <returns></returns>
        public int Save(eTableType _tableType)
        {
            IFormatter formatter = new BinaryFormatter();

            if (_tableType == eTableType.PlcTable)
            {
                Stream streamWrite = new FileStream(Path.ChangeExtension(Path.Combine(DefSystem.PATH_BASE, DefSystem.PATH_SYSTEM, "InterfaceTable", DefSystem.FILE_PLC_TABLE), DefSystem.EXTENSION_BIN)
                                                    , FileMode.Create, FileAccess.Write, FileShare.None);
                formatter.Serialize(streamWrite, mPlcTable);
                streamWrite.Close();
            }
            else if (_tableType == eTableType.VisionTable)
            {
                Stream streamWrite = new FileStream(Path.ChangeExtension(Path.Combine(DefSystem.PATH_BASE, DefSystem.PATH_SYSTEM, "InterfaceTable", DefSystem.FILE_VISION_TABLE), DefSystem.EXTENSION_BIN)
                                                    , FileMode.Create, FileAccess.Write, FileShare.None);
                formatter.Serialize(streamWrite, mVisionTable);
                streamWrite.Close();
            }

            return DefSystem.DEF_SUCCESS;
        }

        /// <summary>
        /// Table Load 하는 함수
        /// </summary>
        /// <param name="_tableType">PLC or Vision</param>
        /// <returns></returns>
        public int Load(eTableType _tableType)
        {
            IFormatter formatter = new BinaryFormatter();

            try
            {
                if (_tableType == eTableType.PlcTable)
                {
                    Stream streamRead = new FileStream(Path.ChangeExtension(Path.Combine(DefSystem.PATH_BASE, DefSystem.PATH_SYSTEM, "InterfaceTable", DefSystem.FILE_PLC_TABLE), DefSystem.EXTENSION_BIN)
                                                    , FileMode.Open, FileAccess.Read, FileShare.None);
                    mPlcTable = (DataTable)formatter.Deserialize(streamRead);

                    streamRead.Close();
                }
                else if (_tableType == eTableType.VisionTable)
                {

                    Stream streamRead = new FileStream(Path.ChangeExtension(Path.Combine(DefSystem.PATH_BASE, DefSystem.PATH_SYSTEM, "InterfaceTable", DefSystem.FILE_VISION_TABLE), DefSystem.EXTENSION_BIN)
                                                    , FileMode.Open, FileAccess.Read, FileShare.None);
                    mVisionTable = (DataTable)formatter.Deserialize(streamRead);
                    streamRead.Close();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

            return DefSystem.DEF_SUCCESS;
        }

        /// <summary>
        /// 각 IO Dictionary에 Table과 Assign 작업.
        /// </summary>
        /// <returns></returns>
        public int IoAssign()
        {
            object[] cellPlc = new object[mPlcTable.Columns.Count];
            DataTableReader dtrPlc = new DataTableReader(mPlcTable);

            object[] cellVision = new object[mVisionTable.Columns.Count];
            DataTableReader dtrVision = new DataTableReader(mVisionTable);

            //IO readIO = new IO();
            //IO writeIO = new IO();

            if (mPlcIO != null || mPlcIO.Count > 0)
                mPlcIO.Clear();

            while (dtrPlc.Read())
            {
                IO readIO = new IO();
                string value = dtrPlc.GetName(0);
                dtrPlc.GetValues(cellPlc);

                readIO.mIoAssignType = eIOAssignType.Plc;
                readIO.mID = (string)cellPlc[(int)eIOOrder.ID];
                readIO.mDescription = (string)cellPlc[(int)eIOOrder.Description];
                readIO.mWord = (string)cellPlc[(int)eIOOrder.Word];

                string read = "ZR3000";
                string start = "ZR2000";// mPlcStartIO;
                string device;

                if (read.ElementAt(0) == 'D')
                {
                    device = read.Substring(0, 1);
                    read = read.Remove(0, 1);
                    start = start.Remove(0, 1);
                }
                else
                {
                    device = read.Substring(0, 2);
                    read = read.Remove(0, 2);
                    start = start.Remove(0, 2);
                }

                if (device == "D" || device == "ZR")
                {
                    readIO.mOffset = Convert.ToInt32(read) - Convert.ToInt32(start);
                }
                else
                {
                    readIO.mOffset = Convert.ToInt32(read, 16) - Convert.ToInt32(start, 16);
                }

                readIO.mQty = Convert.ToInt16(cellPlc[(int)eIOOrder.Qty]);
                if ((string)cellPlc[(int)eIOOrder.DataType] == "Integer") readIO.mIoDataType = eIODataType.Integer;
                else if ((string)cellPlc[(int)eIOOrder.DataType] == "Boolean") readIO.mIoDataType = eIODataType.Boolean;
                else if ((string)cellPlc[(int)eIOOrder.DataType] == "Double") readIO.mIoDataType = eIODataType.Double;
                else if ((string)cellPlc[(int)eIOOrder.DataType] == "String") readIO.mIoDataType = eIODataType.String;
                else if ((string)cellPlc[(int)eIOOrder.DataType] == "DataSet") readIO.mIoDataType = eIODataType.DataSet;
                readIO.mBit = (short)Convert.ToInt32((string)cellPlc[(int)eIOOrder.Bit], 16);
                readIO.mDigit = (short)Convert.ToInt32((string)cellPlc[(int)eIOOrder.Digit]);

                if ((string)cellPlc[(int)eIOOrder.ModeType] == "Read_Only") readIO.mIoModeType = eIOModeType.ReadOnly;
                else if ((string)cellPlc[(int)eIOOrder.ModeType] == "Write_Only") readIO.mIoModeType = eIOModeType.WriteOnly;
                else if ((string)cellPlc[(int)eIOOrder.ModeType] == "Read/Write") readIO.mIoModeType = eIOModeType.ReadWrite;


                mPlcIO.Add(readIO.mID, readIO);
                ////dataGridView1.Rows.Add(cellValues);
            }



            if (mVisionIO != null || mVisionIO.Count > 0)
                mVisionIO.Clear();

            while (dtrVision.Read())
            {
                IO writeIO = new IO();
                string value = dtrVision.GetName(0);
                dtrVision.GetValues(cellVision);

                writeIO.mIoAssignType = eIOAssignType.Vision;
                writeIO.mID = (string)cellVision[(int)eIOOrder.ID];
                writeIO.mDescription = (string)cellVision[(int)eIOOrder.Description];
                writeIO.mWord = (string)cellVision[(int)eIOOrder.Word];

                string read = "ZR3000";//writeIO.mWord;
                string start = "ZR2000";// mVisionStartIO;
                string device;

                int deviceCodeCnt = CharCnt(read);

                device = read.Substring(0, deviceCodeCnt);
                read = read.Remove(0, deviceCodeCnt);
                start = start.Remove(0, deviceCodeCnt);

                //if (read.ElementAt(0) == 'D')
                //{
                //    device = read.Substring(0, 1);
                //    read = read.Remove(0, 1);
                //    start = start.Remove(0, 1);
                //}
                //else
                //{
                //    device = read.Substring(0, 2);
                //    read = read.Remove(0, 2);
                //    start = start.Remove(0, 2);
                //}

                switch (device)
                {
                    case "D":
                    case "M":
                    case "R":
                    case "ZR":
                        writeIO.mOffset = Convert.ToInt32(read) - Convert.ToInt32(start);
                        break;
                    case "W":
                        writeIO.mOffset = Convert.ToInt32(read, 16) - Convert.ToInt32(start, 16);
                        break;
                }

                //if (device == "D" || device == "ZR")
                //{
                //    writeIO.mOffset = Convert.ToInt32(read) - Convert.ToInt32(start);
                //}
                //else
                //{
                //    writeIO.mOffset = Convert.ToInt32(read, 16) - Convert.ToInt32(start, 16);
                //}

                if (writeIO.mOffset < 0) writeIO.mOffset = 0;       // Error Message 처리해야함..

                writeIO.mQty = Convert.ToInt16(cellVision[(int)eIOOrder.Qty]);
                if ((string)cellVision[(int)eIOOrder.DataType] == "Integer") writeIO.mIoDataType = eIODataType.Integer;
                else if ((string)cellVision[(int)eIOOrder.DataType] == "Boolean") writeIO.mIoDataType = eIODataType.Boolean;
                else if ((string)cellVision[(int)eIOOrder.DataType] == "Double") writeIO.mIoDataType = eIODataType.Double;
                else if ((string)cellVision[(int)eIOOrder.DataType] == "String") writeIO.mIoDataType = eIODataType.String;
                else if ((string)cellVision[(int)eIOOrder.DataType] == "DataSet") writeIO.mIoDataType = eIODataType.DataSet;
                writeIO.mBit = (short)Convert.ToInt32((string)cellVision[(int)eIOOrder.Bit], 16);
                writeIO.mDigit = (short)Convert.ToInt32((string)cellVision[(int)eIOOrder.Digit]);

                if ((string)cellVision[(int)eIOOrder.ModeType] == "Read_Only") writeIO.mIoModeType = eIOModeType.ReadOnly;
                else if ((string)cellVision[(int)eIOOrder.ModeType] == "Write_Only") writeIO.mIoModeType = eIOModeType.WriteOnly;
                else if ((string)cellVision[(int)eIOOrder.ModeType] == "Read/Write") writeIO.mIoModeType = eIOModeType.ReadWrite;


                mVisionIO.Add(writeIO.mID, writeIO);
                ////dataGridView1.Rows.Add(cellValues);
            }

            return DefSystem.DEF_SUCCESS;
        }

        int CharCnt(string str)
        {
            int cnt = 0;
            string cvtString = str.ToUpper();
            if (cvtString.ElementAt(0) >= 65 && cvtString.ElementAt(0) <= 90)
            {
                cnt++;
            }

            if (cvtString.ElementAt(1) >= 65 && cvtString.ElementAt(1) <= 90)
            {
                cnt++;
            }

            return cnt;
        }

        public bool ReadPositions(int index, out List<Point3f> listPosition)
        {
            throw new NotImplementedException();
        }
    }
}
