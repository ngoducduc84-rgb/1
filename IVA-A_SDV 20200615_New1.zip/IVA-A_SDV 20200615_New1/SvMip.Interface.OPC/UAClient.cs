﻿//=============================================================================
// Siemens AG
// (c)Copyright (2017) All Rights Reserved
//----------------------------------------------------------------------------- 
// Tested with: Windows 7 Ultimate x64
// Engineering: Visual Studio 2013
// Functionality: Wrapps up important classes/methods of the OPC UA .NET Stack to help
// with simple client implementation
//-----------------------------------------------------------------------------
// Change log table:
// Version Date Expert in charge Changes applied
// 01.00.00 31.08.2016 (Siemens) First released version
// 01.01.00 22.02.2017 (Siemens) Implement user authentication, SHA256 Cert, Basic256Rsa256 connection,
// Basic256Rsa256 connections, read/write structs/UDTs
//=============================================================================

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Security.Permissions;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Opc.Ua;
using Opc.Ua;
using Opc.Ua.Client;
using System.Linq;

namespace SvMip.Interface.OPC
{
    public class UAClient
    {
        #region Construction
        public UAClient()
        {
            // Creats the application configuration (containing the certificate) on construction
            mApplicationConfig = CreateClientConfiguration();
        }
        #endregion

        #region Properties
        /// <summary> 
        /// Keeps a session with an UA server. 
        /// </summary>
        private Session mSession = null;

        /// <summary> 
        /// Specifies this application 
        /// </summary>
        private ApplicationConfiguration mApplicationConfig = null;

        /// <summary>
        /// Provides the session being established with an OPC UA server.
        /// </summary>
        public Session Session
        {
            get { return mSession; }
        }

        private bool isConnect = false;
        public bool isConnected
        {
            get { return isConnect; }
        }

        static object communicationLock = new object();

        public bool[] bBlock;
        public bool[] bitDataBlock { get { return bBlock; } }

        public string[] sBlock;
        public string[] stringDataBlock { get { return sBlock; } }

        public short[] iBlock;
        public short[] intDataBlock { get { return iBlock; } }

        public float[] fBlock;
        public float[] floatDataBlock { get { return fBlock; } }

        /// <summary>
        /// Provides the event for value changes of a monitored item.
        /// </summary>
        public MonitoredItemNotificationEventHandler ItemChangedNotification = null;

        /// <summary>
        /// Provides the event for KeepAliveNotifications.
        /// </summary>
        public KeepAliveEventHandler KeepAliveNotification = null;
        #endregion

        #region Discovery
        /// <summary>Finds Servers based on a discovery url</summary>
        /// <param name="discoveryUrl">The discovery url</param>
        /// <returns>ApplicationDescriptionCollection containing found servers</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public ApplicationDescriptionCollection FindServers(string discoveryUrl)
        {
            //Create a URI using the discovery URL
            Uri uri = new Uri(discoveryUrl);
            try
            {
                //Ceate a DiscoveryClient
                DiscoveryClient client = DiscoveryClient.Create(uri);
                //Find servers
                ApplicationDescriptionCollection servers = client.FindServers(null);
                return servers;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        /// <summary>Finds Endpoints based on a server's url</summary>
        /// <param name="discoveryUrl">The server's url</param>
        /// <returns>EndpointDescriptionCollection containing found Endpoints</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public EndpointDescriptionCollection GetEndpoints(string serverUrl)
        {
            //Create a URI using the server's URL
            Uri uri = new Uri(serverUrl);
            try
            {
                //Create a DiscoveryClient
                DiscoveryClient client = DiscoveryClient.Create(uri);
                //Search for available endpoints
                EndpointDescriptionCollection endpoints = client.GetEndpoints(null);
                return endpoints;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }
        #endregion

        #region Connect/Disconnect
        /// <summary>Establishes the connection to an OPC UA server and creates a session using a server url.</summary>
        /// <param name="url">The Url of the endpoint as string.</param>
        /// <param name="localIpAddress">The ip address of the interface to connect with</param>
        /// <param name="security">Use security or not</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public Boolean Connect(string url, bool security)
        {
            try
            {
                //Secify application configuration
                ApplicationConfiguration ApplicationConfig = mApplicationConfig;

                //Hook up a validator function for a CertificateValidation event
                mApplicationConfig.CertificateValidator.CertificateValidation += Validator_CertificateValidation;

                //Create EndPoint description
                EndpointDescription EndpointDescription = CreateEndpointDescription(url, security);

                //Create EndPoint configuration
                EndpointConfiguration EndpointConfiguration = EndpointConfiguration.Create(ApplicationConfig);

                //Create an Endpoint object to connect to server
                ConfiguredEndpoint Endpoint = new ConfiguredEndpoint(null, EndpointDescription, EndpointConfiguration);

                //Create anonymous user identity
                UserIdentity UserIdentity = new UserIdentity();

                //Create and connect session
                mSession = Session.Create(
                    ApplicationConfig,
                    Endpoint,
                    true,
                    "MySession",
                    60000,
                    UserIdentity,
                    null
                    );

                mSession.KeepAlive += new KeepAliveEventHandler(Notification_KeepAlive);
                return true;
            }
            catch (Exception e)
            {
                //handle Exception here
                //throw e;
                return false;
            }
        }

        /// <summary>Establishes the connection to an OPC UA server and creates a session using a EndpointDescription.</summary>
        /// <param name="endpointDescription">The EndpointDescription of the server's endpoint</param>
        /// <param name="localIpAddress">The ip address of the interface to connect with</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public void Connect(EndpointDescription endpointDescription)
        {
            try
            {
                //Secify application configuration
                ApplicationConfiguration ApplicationConfig = mApplicationConfig;

                //Hook up a validator function for a CertificateValidation event
                ApplicationConfig.CertificateValidator.CertificateValidation += Validator_CertificateValidation;

                //Create EndPoint configuration
                EndpointConfiguration EndpointConfiguration = EndpointConfiguration.Create(ApplicationConfig);

                //Connect to server and get endpoints
                ConfiguredEndpoint mEndpoint = new ConfiguredEndpoint(null, endpointDescription, EndpointConfiguration);

                //Create the binding factory.
                BindingFactory bindingFactory = BindingFactory.Create(mApplicationConfig, ServiceMessageContext.GlobalContext);

                //Create anonymous user identity
                UserIdentity UserIdentity = new UserIdentity();

                //Create and connect session
                mSession = Session.Create(
                    ApplicationConfig,
                    mEndpoint,
                    true,
                    "MySession",
                    60000,
                    UserIdentity,
                    null
                    );

                mSession.KeepAlive += new KeepAliveEventHandler(Notification_KeepAlive);
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        /// <summary>Closes an existing session and disconnects from the server.</summary>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public Boolean Disconnect()
        {
            // Close the session.
            try
            {
                mSession.Close(10000);
                mSession.Dispose();
                return true;
            }
            catch (Exception e)
            {
                //handle Exception here
                //throw e;
                return false;
            }
        }
        public bool Reconnect(string url, bool security)
        {
            bool isSuccess = Disconnect();
            if (isSuccess)
                return Connect(url, security);
            else
                return false;


        }

        #endregion

        #region Browse
        /// <summary>Browses the root folder of an OPC UA server.</summary>
        /// <returns>ReferenceDescriptionCollection of found nodes</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public ReferenceDescriptionCollection BrowseRoot()
        {
            //Create a collection for the browse results
            ReferenceDescriptionCollection referenceDescriptionCollection;
            //Create a continuationPoint
            byte[] continuationPoint;
            try
            {
                //Browse the RootFolder for variables, objects and methods
                mSession.Browse(null, null, ObjectIds.RootFolder, 0u, BrowseDirection.Forward, ReferenceTypeIds.HierarchicalReferences, true, (uint)NodeClass.Variable | (uint)NodeClass.Object | (uint)NodeClass.Method, out continuationPoint, out referenceDescriptionCollection);
                return referenceDescriptionCollection;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }

        }

        /// <summary>Browses a node ID provided by a ReferenceDescription</summary>
        /// <param name="refDesc">The ReferenceDescription</param>
        /// <returns>ReferenceDescriptionCollection of found nodes</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public ReferenceDescriptionCollection BrowseNode(ReferenceDescription refDesc)
        {
            //Create a collection for the browse results
            ReferenceDescriptionCollection referenceDescriptionCollection;
            //Create a continuationPoint
            byte[] continuationPoint;
            //Create a NodeId using the selected ReferenceDescription as browsing starting point
            NodeId nodeId = ExpandedNodeId.ToNodeId(refDesc.NodeId, null);
            try
            {
                //Browse from starting point for all object types
                mSession.Browse(null, null, nodeId, 0u, BrowseDirection.Forward, ReferenceTypeIds.HierarchicalReferences, true, 0, out continuationPoint, out referenceDescriptionCollection);
                return referenceDescriptionCollection;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }

        }
        #endregion

        #region Subscription
        /// <summary>Creats a Subscription object to a server</summary>
        /// <param name="publishingInterval">The publishing interval</param>
        /// <returns>Subscription</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public Subscription Subscribe(int publishingInterval)
        {
            //Create a Subscription object
            Subscription subscription = new Subscription(mSession.DefaultSubscription);
            //Enable publishing
            subscription.PublishingEnabled = true;
            //Set the publishing interval
            subscription.PublishingInterval = publishingInterval;
            //Add the subscription to the session
            mSession.AddSubscription(subscription);
            try
            {
                //Create/Activate the subscription
                subscription.Create();
                return subscription;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        /// <summary>Ads a monitored item to an existing subscription</summary>
        /// <param name="subscription">The subscription</param>
        /// <param name="nodeIdString">The node Id as string</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public MonitoredItem AddMonitoredItem(Subscription subscription, string nodeIdString, int samplingInterval)
        {
            //Create a monitored item    
            MonitoredItem monitoredItem = new MonitoredItem(subscription.DefaultItem);
            //Set the NodeId of the item
            monitoredItem.StartNodeId = nodeIdString;
            //Set the attribute Id (value here)
            monitoredItem.AttributeId = Attributes.Value;
            //Set reporting mode 
            monitoredItem.MonitoringMode = MonitoringMode.Reporting;
            //Set the sampling interval (1 = fastest possible)
            monitoredItem.SamplingInterval = samplingInterval;
            //Set the queue size
            monitoredItem.QueueSize = 0;
            //Discard the oldest item after new one has been received
            monitoredItem.DiscardOldest = true;
            //Define event handler for this item and then add to monitoredItem
            monitoredItem.Notification += new MonitoredItemNotificationEventHandler(Notification_MonitoredItem);
            try
            {
                //Add the item to the subscription
                subscription.AddItem(monitoredItem);
                //Apply changes to the subscription
                subscription.ApplyChanges();
                return monitoredItem;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        /// <summary>Removs a monitored item from an existing subscription</summary>
        /// <param name="subscription">The subscription</param>
        /// <param name="monitoredItem">The item</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public MonitoredItem RemoveMonitoredItem(Subscription subscription, MonitoredItem monitoredItem)
        {
            try
            {
                //Add the item to the subscription
                subscription.RemoveItem(monitoredItem);
                //Apply changes to the subscription
                subscription.ApplyChanges();
                return null;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        /// <summary>Removes an existing Subscription</summary>
        /// <param name="subscription">The subscription</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public void RemoveSubscription(Subscription subscription)
        {
            try
            {
                //Delete the subscription and all items submitted
                subscription.Delete(true);
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }
        #endregion

        #region Read/Write
        /// <summary>Reads a node by node Id</summary>
        /// <param name="nodeIdString">The node Id as string</param>
        /// <returns>The read node</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public Node ReadNode(string nodeIdString)
        {
            //Create a nodeId using the identifier string
            NodeId nodeId = new NodeId(nodeIdString);
            //Create a node
            Node node = new Node();
            try
            {
                //Read the dataValue
                node = mSession.ReadNode(nodeId);
                return node;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        /// <summary>Writes values to  node Ids</summary>
        /// <param name="value">The values as strings</param>
        /// <param name="nodeIdString">The nodes Id as strings</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public bool BitWriteValues(object[] values, string nodeIdStrings)
        {
            //Create a collection of values to write
            WriteValueCollection valuesToWrite = new WriteValueCollection();
            //Create a collection for StatusCodes
            StatusCodeCollection result = new StatusCodeCollection();
            //Create a collection for DiagnosticInfos
            DiagnosticInfoCollection diagnostics = new DiagnosticInfoCollection();

            //Create a nodeId
            NodeId nodeId = new NodeId(nodeIdStrings);
            ////Create a dataValue
            //DataValue dataValue = new DataValue();
            ////Read the dataValue
            //try
            //{
            //    dataValue = mSession.ReadValue(nodeId);
            //}
            //catch (Exception e)
            //{
            //    //handle Exception here
            //    //throw e;
            //    isConnect = false;
            //    return false;
            //}

            //Get the data type of the read dataValue
            Variant variant = new Variant(values.Cast<bool>().ToArray());
            //Overwrite the dataValue with a new constructor using read dataType
            DataValue dataValue = new DataValue(variant);
            //Create a WriteValue using the NodeId, dataValue and attributeType
            WriteValue valueToWrite = new WriteValue();
            valueToWrite.Value = dataValue;
            valueToWrite.NodeId = nodeId;
            valueToWrite.AttributeId = Attributes.Value;
            //Add the dataValues to the collection
            valuesToWrite.Add(valueToWrite);

            try
            {
                //Write the collection to the server
                mSession.Write(null, valuesToWrite, out result, out diagnostics);
            }
            catch (Exception e)
            {
                //handle Exception here
                //throw e;
                isConnect = false;
                return false;
            }

            return true;
        }

        //Data 한개만 써주도록 추가 (TKL, 19.04.13)
        public bool BitWriteValues(bool values, string nodeIdStrings)
        {
            //Create a collection of values to write
            WriteValueCollection valuesToWrite = new WriteValueCollection();
            //Create a collection for StatusCodes
            StatusCodeCollection result = new StatusCodeCollection();
            //Create a collection for DiagnosticInfos
            DiagnosticInfoCollection diagnostics = new DiagnosticInfoCollection();

            //Create a nodeId
            NodeId nodeId = new NodeId(nodeIdStrings);
            ////Create a dataValue
            //DataValue dataValue = new DataValue();
            ////Read the dataValue
            //try
            //{
            //    dataValue = mSession.ReadValue(nodeId);
            //}
            //catch (Exception e)
            //{
            //    //handle Exception here
            //    //throw e;
            //    isConnect = false;
            //    return false;
            //}

            //Get the data type of the read dataValue
            Variant variant = new Variant(values);
            //Overwrite the dataValue with a new constructor using read dataType
            DataValue dataValue = new DataValue(variant);
            //Create a WriteValue using the NodeId, dataValue and attributeType
            WriteValue valueToWrite = new WriteValue();
            valueToWrite.Value = dataValue;
            valueToWrite.NodeId = nodeId;
            valueToWrite.AttributeId = Attributes.Value;
            //Add the dataValues to the collection
            valuesToWrite.Add(valueToWrite);

            try
            {
                //Write the collection to the server
                mSession.Write(null, valuesToWrite, out result, out diagnostics);
            }
            catch (Exception e)
            {
                //handle Exception here
                //throw e;
                isConnect = false;
                return false;
            }

            return true;
        }

        /// <summary>Writes values to  node Ids</summary>
        /// <param name="value">The values as strings</param>
        /// <param name="nodeIdString">The nodes Id as strings</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public bool WriteValues(object[] values, string nodeIdStrings)
        {
            //Create a collection of values to write
            WriteValueCollection valuesToWrite = new WriteValueCollection();
            //Create a collection for StatusCodes
            StatusCodeCollection result = new StatusCodeCollection();
            //Create a collection for DiagnosticInfos
            DiagnosticInfoCollection diagnostics = new DiagnosticInfoCollection();

            //Create a nodeId
            NodeId nodeId = new NodeId(nodeIdStrings);
            ////Create a dataValue
            //DataValue dataValue = new DataValue();
            ////Read the dataValue
            //try
            //{
            //    dataValue = mSession.ReadValue(nodeId);
            //}
            //catch (Exception e)
            //{
            //    //handle Exception here
            //    //throw e;
            //    isConnect = false;
            //    return false;
            //}

            //Get the data type of the read dataValue
            Variant variant = new Variant(values.Cast<float>().ToArray());
            //Overwrite the dataValue with a new constructor using read dataType
            DataValue dataValue = new DataValue(variant);
            //Create a WriteValue using the NodeId, dataValue and attributeType
            WriteValue valueToWrite = new WriteValue();
            valueToWrite.Value = dataValue;
            valueToWrite.NodeId = nodeId;
            valueToWrite.AttributeId = Attributes.Value;
            //Add the dataValues to the collection
            valuesToWrite.Add(valueToWrite);

            try
            {
                //Write the collection to the server
                mSession.Write(null, valuesToWrite, out result, out diagnostics);
            }
            catch (Exception e)
            {
                //handle Exception here
                //throw e;
                isConnect = false;
                return false;
            }

            return true;
        }

        /// <summary>Reads values from node Ids</summary>
        /// <param name="nodeIdStrings">The node Ids as string</param>
        /// <returns>The read values as strings</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public bool BitReadValues(string nodeIdStrings)
        {
            bBlock = new bool[200];

            List<object> values = new List<object>();
            List<NodeId> nodeIds = new List<NodeId>();
            List<Type> types = new List<Type>();
            List<ServiceResult> serviceResults = new List<ServiceResult>();

            //Create a nodeId using the identifier string and add to list
            nodeIds.Add(new NodeId(nodeIdStrings));
            //No need for types
            types.Add(null);

            try
            {
                //lock (communicationLock)
                //Read the dataValues
                mSession.ReadValues(nodeIds, types, out values, out serviceResults);

                bBlock = (bool[])values[0];

                //check ServiceResults to 
                foreach (ServiceResult svResult in serviceResults)
                {
                    if (svResult.ToString() != "Good")
                    {
                        isConnect = false;
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                isConnect = false;
                return false;
            }

            return true;
        }

        public bool IntReadValues(string nodeIdStrings)
        {
            iBlock = new short[10];

            List<object> values = new List<object>();
            List<NodeId> nodeIds = new List<NodeId>();
            List<Type> types = new List<Type>();
            List<ServiceResult> serviceResults = new List<ServiceResult>();

            //Create a nodeId using the identifier string and add to list
            nodeIds.Add(new NodeId(nodeIdStrings));
            //No need for types
            types.Add(null);

            try
            {
                //lock (communicationLock)
                //Read the dataValues
                mSession.ReadValues(nodeIds, types, out values, out serviceResults);

                iBlock = (short[])values[0];

                //check ServiceResults to 
                foreach (ServiceResult svResult in serviceResults)
                {
                    if (svResult.ToString() != "Good")
                    {
                        isConnect = false;
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                isConnect = false;
                return false;
            }

            return true;
        }

        public bool FloatReadValues(string nodeIdStrings)
        {
            fBlock = new float[200];

            List<object> values = new List<object>();
            List<NodeId> nodeIds = new List<NodeId>();
            List<Type> types = new List<Type>();
            List<ServiceResult> serviceResults = new List<ServiceResult>();

            //Create a nodeId using the identifier string and add to list
            nodeIds.Add(new NodeId(nodeIdStrings));
            //No need for types
            types.Add(null);

            try
            {
                //lock (communicationLock)
                //Read the dataValues
                mSession.ReadValues(nodeIds, types, out values, out serviceResults);

                fBlock = (float[])values[0];

                //check ServiceResults to 
                foreach (ServiceResult svResult in serviceResults)
                {
                    if (svResult.ToString() != "Good")
                    {
                        isConnect = false;
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                isConnect = false;
                return false;
            }

            return true;
        }

        public bool StringReadValues(string nodeIdStrings)
        {
            sBlock = new string[200];

            List<object> values = new List<object>();
            List<NodeId> nodeIds = new List<NodeId>();
            List<Type> types = new List<Type>();
            List<ServiceResult> serviceResults = new List<ServiceResult>();

            //Create a nodeId using the identifier string and add to list
            nodeIds.Add(new NodeId(nodeIdStrings));
            //No need for types
            types.Add(null);

            try
            {
                //lock (communicationLock)
                //Read the dataValues
                mSession.ReadValues(nodeIds, types, out values, out serviceResults);

                sBlock = (string[])values[0];

                //check ServiceResults to 
                foreach (ServiceResult svResult in serviceResults)
                {
                    if (svResult.ToString() != "Good")
                    {
                        isConnect = false;
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                isConnect = false;
                return false;
            }

            return true;
        }

        /// <summary>Writes values to  node Ids</summary>
        /// <param name="value">The values as strings</param>
        /// <param name="nodeIdString">The nodes Id as strings</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public bool WriteValue(object value, string nodeIdString)
        {
            //Create a collection of values to write
            WriteValueCollection valuesToWrite = new WriteValueCollection();
            //Create a collection for StatusCodes
            StatusCodeCollection result = new StatusCodeCollection();
            //Create a collection for DiagnosticInfos
            DiagnosticInfoCollection diagnostics = new DiagnosticInfoCollection();

            //Create a nodeId
            NodeId nodeId = new NodeId(nodeIdString);
            //Create a dataValue
            DataValue dataValue = new DataValue();
            //Read the dataValue
            try
            {
                //lock (communicationLock)
                dataValue = mSession.ReadValue(nodeId);
            }
            catch (Exception e)
            {
                isConnect = false;
                return false;
            }

            //Get the data type of the read dataValue
            //Variant variant = new Variant(value);
            Variant variant = new Variant(Convert.ChangeType(value, dataValue.Value.GetType()));
            //Overwrite the dataValue with a new constructor using read dataType
            dataValue = new DataValue(variant);
            //Create a WriteValue using the NodeId, dataValue and attributeType
            WriteValue valueToWrite = new WriteValue();
            valueToWrite.Value = dataValue;
            valueToWrite.NodeId = nodeId;
            valueToWrite.AttributeId = Attributes.Value;

            //Add the dataValues to the collection
            valuesToWrite.Add(valueToWrite);

            try
            {
                //lock (communicationLock)
                //Write the collection to the server
                mSession.Write(null, valuesToWrite, out result, out diagnostics);
            }
            catch (Exception e)
            {
                isConnect = false;
                return false;
            }

            return true;
        }

        /// <summary>Reads values from node Ids</summary>
        /// <param name="nodeIdString">The node Ids as string</param>
        /// <returns>The read values as strings</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public object ReadValue(string nodeIdString)
        {
            //Create a nodeId using the identifier string and add to list
            NodeId nodeId = new NodeId(nodeIdString);

            try
            {
                lock (communicationLock)
                    //Read the dataValues
                    return mSession.ReadValue(nodeId);
            }
            catch (Exception e)
            {
                //handle Exception here
                //throw e;
                isConnect = false;
                return null;
            }
        }

        /// <summary>
        /// PLC에서 값 읽어와서 Datablock 업데이트.
        /// </summary>
        /// <returns></returns>
        public bool UpdateBitData(string nodeId)
        {
            lock (communicationLock)
            {
                if (!BitReadValues(nodeId)) return false;
            }

            return true;
        }

        public bool UpdateIntData(string nodeId)
        {
            lock (communicationLock)
            {
                if (!IntReadValues(nodeId)) return false;
            }

            return true;
        }

        public bool UpdateFloatData(string nodeId)
        {
            lock (communicationLock)
            {
                if (!FloatReadValues(nodeId)) return false;
            }

            return true;
        }

        public bool UpdateStringData(string nodeId)
        {
            lock (communicationLock)
            {
                if (!StringReadValues(nodeId)) return false;
            }

            return true;
        }

        /// <summary>Reads values from node Ids</summary>
        /// <param name="nodeIdStrings">The node Ids as strings</param>
        /// <returns>The read values as strings</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public List<string> ReadValues(List<String> nodeIdStrings)
        {
            List<NodeId> nodeIds = new List<NodeId>();
            List<Type> types = new List<Type>();
            List<object> values = new List<object>();
            List<ServiceResult> serviceResults = new List<ServiceResult>();
            foreach (string str in nodeIdStrings)
            {
                //Create a nodeId using the identifier string and add to list
                nodeIds.Add(new NodeId(str));
                //No need for types
                types.Add(null);
            }
            try
            {
                //Read the dataValues

                mSession.ReadValues(nodeIds, types, out values, out serviceResults);

                //check ServiceResults to 
                foreach (ServiceResult svResult in serviceResults)
                {
                    if (svResult.ToString() != "Good")
                    {
                        Exception e = new Exception(svResult.ToString());
                        throw e;
                    }
                }
                List<string> resultStrings = new List<string>();
                foreach (object result in values)
                {
                    if (result != null)
                    {
                        if (result.ToString() == "System.Byte[]")
                        {
                            string str = "";
                            str = BitConverter.ToString((byte[])result).Replace("-", ";");
                            resultStrings.Add(str);
                        }
                        if (result.ToString() == "System.String[]")
                        {
                            string str = "";
                            str = String.Join(";", (string[])result);
                            resultStrings.Add(str);
                        }
                        else if (result.ToString() == "System.Boolean[]")
                        {
                            string str = "";
                            foreach (Boolean intVar in (Boolean[])result)
                            {
                                str = str + ";" + intVar.ToString();
                            }
                            str = str.Remove(0, 1);
                            resultStrings.Add(str);
                        }
                        else if (result.ToString() == "System.Int16[]")
                        {
                            string str = "";
                            foreach (Int16 intVar in (Int16[])result)
                            {
                                str = str + ";" + intVar.ToString();
                            }
                            str = str.Remove(0, 1);
                            resultStrings.Add(str);
                        }
                        else if (result.ToString() == "System.UInt16[]")
                        {
                            string str = "";
                            foreach (UInt16 intVar in (UInt16[])result)
                            {
                                str = str + ";" + intVar.ToString();
                            }
                            str = str.Remove(0, 1);
                            resultStrings.Add(str);
                        }
                        else if (result.ToString() == "System.Int64[]")
                        {
                            string str = "";
                            foreach (Int64 intVar in (Int64[])result)
                            {
                                str = str + ";" + intVar.ToString();
                            }
                            str = str.Remove(0, 1);
                            resultStrings.Add(str);
                        }
                        else if (result.ToString() == "System.Single[]")
                        {
                            string str = "";
                            foreach (float intVar in (float[])result)
                            {
                                str = str + ";" + intVar.ToString();
                            }
                            str = str.Remove(0, 1);
                            resultStrings.Add(str);
                        }
                        else if (result.ToString() == "System.Double[]")
                        {
                            string str = "";
                            foreach (double intVar in (double[])result)
                            {
                                str = str + ";" + intVar.ToString();
                            }
                            str = str.Remove(0, 1);
                            resultStrings.Add(str);
                        }
                        else
                        {
                            resultStrings.Add(result.ToString());
                        }
                    }
                    else
                    {
                        resultStrings.Add("(null)");
                    }
                }
                return resultStrings;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        /// <summary>Writes values to node Ids</summary>
        /// <param name="value">The values as strings</param>
        /// <param name="nodeIdString">The node Ids as strings</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public void WriteValues(List<String> values, List<String> nodeIdStrings)
        {
            //Create a collection of values to write
            WriteValueCollection valuesToWrite = new WriteValueCollection();
            //Create a collection for StatusCodes
            StatusCodeCollection result = new StatusCodeCollection();
            //Create a collection for DiagnosticInfos
            DiagnosticInfoCollection diagnostics = new DiagnosticInfoCollection();

            foreach (String str in nodeIdStrings)
            {
                //Create a nodeId
                NodeId nodeId = new NodeId(str);
                //Create a dataValue
                DataValue dataValue = new DataValue();
                //Read the dataValue
                try
                {
                    dataValue = mSession.ReadValue(nodeId);
                }
                catch (Exception e)
                {
                    //handle Exception here
                    throw e;
                }

                //Get the data type of the read dataValue
                //Handle Arrays here: TBD
                Variant variant = new Variant(Convert.ChangeType(values[nodeIdStrings.IndexOf(str)], dataValue.Value.GetType()));

                //Overwrite the dataValue with a new constructor using read dataType
                dataValue = new DataValue(variant);

                //Create a WriteValue using the NodeId, dataValue and attributeType
                WriteValue valueToWrite = new WriteValue();
                valueToWrite.Value = dataValue;
                valueToWrite.NodeId = nodeId;
                valueToWrite.AttributeId = Attributes.Value;

                //Add the dataValues to the collection
                valuesToWrite.Add(valueToWrite);
            }
            try
            {
                //Write the collection to the server
                mSession.Write(null, valuesToWrite, out result, out diagnostics);
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }
        #endregion

        #region Read/Write Struct/UDT


        public void DefineStrctList(String nodeIdString, int index)
        {

            if (index == 1)
            {

                //Define result list to return var name and var value
                Global.resultStringListBigDataRead = new List<string[]>();

                //Get the type dictionary of desired struct/UDT and the name of desired var to parse
                Global.xmlString[0] = GetTypeDictionary(nodeIdString, mSession, out Global.parseString[0]);

                //Parse xmlString to create objects of the struct/UDT containing var name and var data type
                Global.varListBigDataRead = new List<object>();
                Global.varListBigDataRead = ParseTypeDictionary(Global.xmlString[0], Global.parseString[0]);
            }
            else if (index == 2)
            {

                //Define result list to return var name and var value
                Global.resultStringListBitEventsRead = new List<string[]>();

                //Get the type dictionary of desired struct/UDT and the name of desired var to parse
                Global.xmlString[1] = GetTypeDictionary(nodeIdString, mSession, out Global.parseString[1]);

                //Parse xmlString to create objects of the struct/UDT containing var name and var data type
                Global.varListBitEventsRead = new List<object>();
                Global.varListBitEventsRead = ParseTypeDictionary(Global.xmlString[1], Global.parseString[1]);
            }
            else if (index == 3)
            {

                //Define result list to return var name and var value
                Global.resultStringListBigDataWrite = new List<string[]>();

                //Get the type dictionary of desired struct/UDT and the name of desired var to parse
                Global.xmlString[2] = GetTypeDictionary(nodeIdString, mSession, out Global.parseString[2]);

                //Parse xmlString to create objects of the struct/UDT containing var name and var data type
                Global.varListBigDataWrite = new List<object>();
                Global.varListBigDataWrite = ParseTypeDictionary(Global.xmlString[2], Global.parseString[2]);
            }
            else if (index == 4)
            {

                //Define result list to return var name and var value
                Global.resultStringListBitComandsWrite = new List<string[]>();

                //Get the type dictionary of desired struct/UDT and the name of desired var to parse
                Global.xmlString[3] = GetTypeDictionary(nodeIdString, mSession, out Global.parseString[3]);

                //Parse xmlString to create objects of the struct/UDT containing var name and var data type
                Global.varListBitEventsWrite = new List<object>();
                Global.varListBitEventsWrite = ParseTypeDictionary(Global.xmlString[3], Global.parseString[3]);
            }
        }


        /// <summary>Reads a struct or UDT by node Id</summary>
        /// <param name="nodeIdString">The node Id as strings</param>
        /// <returns>The read struct/UDT elements as a list of string[3]; string[0] = tag name, string[1] = value, string[2] = opc data type</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public List<string[]> ReadStructUdt(String nodeIdString, int index)
        {

            //Read the struct
            List<NodeId> nodeIds = new List<NodeId>();
            NodeId myNode = new NodeId(nodeIdString);
            nodeIds.Add(myNode);
            List<ServiceResult> serviceResults = new List<ServiceResult>();
            List<Object> values = new List<object>();
            List<Type> types = new List<Type>();
            types.Add(null);

            Global.watch[index - 1] = new Stopwatch();

            Global.watch[index - 1].Start();

            try
            {
                mSession.ReadValues(nodeIds, types, out values, out serviceResults);


            }
            catch (Exception e)
            {
                //Handle Exception here
                throw e;
            }

            //Check result codes
            foreach (ServiceResult svResult in serviceResults)
            {
                if (svResult.ToString() != "Good")
                {
                    Exception e = new Exception(svResult.ToString());
                    throw e;
                }
            }

            //Create an empty byte-array to store ExtensionObject.Body (containing the whole binary data of the desired strucht/UDT) into
            byte[] readBinaryData = null;
            foreach (object val in values)
            {
                //Cast object to ExtensionObject
                ExtensionObject encodeable = val as ExtensionObject;
                if (encodeable == null)
                {
                    ExtensionObject[] exObjArr = val as ExtensionObject[];
                    encodeable = exObjArr[0];
                }

                //Write the body of the ExtensionObject into the byte-array
                readBinaryData = (byte[])encodeable.Body;
            }

            //Check for data types and parse byte array 

            if (index == 1)
            {
                Global.resultStringListBigDataRead = ParseDataToTagsFromDictionary(Global.varListBigDataRead, readBinaryData);

            }
            if (index == 2)
            {
                Global.resultStringListBigDataRead = ParseDataToTagsFromDictionary(Global.varListBitEventsRead, readBinaryData);
            }
            if (index == 3)
            {
                Global.resultStringListBigDataRead = ParseDataToTagsFromDictionary(Global.varListBigDataWrite, readBinaryData);
            }
            if (index == 4)
            {
                Global.resultStringListBigDataRead = ParseDataToTagsFromDictionary(Global.varListBitEventsWrite, readBinaryData);
            }

            Global.watch[index - 1].Stop();
            Global.cycleCounter[index - 1]++;
            Global.sumTime[index - 1] = Global.sumTime[index - 1] + Global.watch[index - 1].Elapsed.TotalMilliseconds;
            Global.midTime[index - 1] = Global.sumTime[index - 1] / Global.cycleCounter[index - 1];

            //  MessageBox.Show("Time: " + Global.sumTime + "ms");

            // UA_Client_1500.UAClientForm


            //return result as List<string[]> (string[0]=tag name; string[1]=tag value; string[2]=tag data type
            return Global.resultStringListBigDataRead;
        }

        /// <summary>Writes data to a struct or UDT by node Id</summary>
        /// <param name="nodeIdString">The node Id as strings</param>
        /// <param name="dataToWrite">The data to write as string[3]; string[0] = tag name, string[1] = value, string[2] = opc data type</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public void WriteStructUdt(String nodeIdString, List<string[]> dataToWrite, int index)
        {
            //Create a NodeId from the NodeIdString
            NodeId nodeId = new NodeId(nodeIdString);

            //Creat a WriteValueColelction
            WriteValueCollection valuesToWrite = new WriteValueCollection();

            //Create a WriteValue
            WriteValue writevalue = new WriteValue();

            //Create a StatusCodeCollection
            StatusCodeCollection results = new StatusCodeCollection();

            //Create a DiagnosticInfoCollection
            DiagnosticInfoCollection diag = new DiagnosticInfoCollection();

            //Determine lentgh of byte array needed to contain all data
            Int64 length = GetLengthOfDataToWrite(dataToWrite);

            //Create a byte array
            byte[] bytesToWrite;

            //Parse dataToWrite to the byte array
            bytesToWrite = ParseDataToByteArray(dataToWrite, length);

            //Create an ExtensionObject from the Structure given to this function
            ExtensionObject writeExtObj = new ExtensionObject();
            writeExtObj.Body = bytesToWrite;

            //Turn the created ExtensionObject into a DataValue
            DataValue dataValue = new DataValue(writeExtObj);

            //Setup for the WriteValue
            writevalue.NodeId = nodeId;
            writevalue.Value = dataValue;
            writevalue.AttributeId = Attributes.Value;
            //Add the created value to the collection
            valuesToWrite.Add(writevalue);

            Global.watch[index - 1] = new Stopwatch();

            Global.watch[index - 1].Start();

            try
            {
                mSession.Write(null, valuesToWrite, out results, out diag);
            }
            catch (Exception e)
            {
                //Handle Exception here
                throw e;
            }

            //Check result codes
            foreach (StatusCode result in results)
            {
                if (result.ToString() != "Good")
                {
                    Exception e = new Exception(result.ToString());
                    throw e;
                }
            }

            Global.watch[index - 1].Stop();
            Global.cycleCounter[index - 1]++;
            Global.sumTime[index - 1] = Global.sumTime[index - 1] + Global.watch[index - 1].Elapsed.TotalMilliseconds;
            Global.midTime[index - 1] = Global.sumTime[index - 1] / Global.cycleCounter[index - 1];
        }
        #endregion

        #region Register/Unregister nodes Ids
        /// <summary>Registers Node Ids to the server</summary>
        /// <param name="nodeIdStrings">The node Ids as strings</param>
        /// <returns>The registered Node Ids as strings</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public List<string> RegisterNodeIds(List<String> nodeIdStrings)
        {
            NodeIdCollection nodesToRegister = new NodeIdCollection();
            NodeIdCollection registeredNodes = new NodeIdCollection();
            List<string> registeredNodeIdStrings = new List<string>();
            foreach (string str in nodeIdStrings)
            {
                //Create a nodeId using the identifier string and add to list
                nodesToRegister.Add(new NodeId(str));
            }
            try
            {
                //Register nodes
                mSession.RegisterNodes(null, nodesToRegister, out registeredNodes);

                foreach (NodeId nodeId in registeredNodes)
                {
                    registeredNodeIdStrings.Add(nodeId.ToString());
                }

                return registeredNodeIdStrings;
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        /// <summary>Unregister Node Ids to the server</summary>
        /// <param name="nodeIdStrings">The node Ids as string</param>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public void UnregisterNodeIds(List<String> nodeIdStrings)
        {
            NodeIdCollection nodesToUnregister = new NodeIdCollection();
            List<string> registeredNodeIdStrings = new List<string>();
            foreach (string str in nodeIdStrings)
            {
                //Create a nodeId using the identifier string and add to list
                nodesToUnregister.Add(new NodeId(str));
            }
            try
            {
                //Register nodes                
                mSession.UnregisterNodes(null, nodesToUnregister);
            }
            catch (Exception e)
            {
                //handle Exception here
                throw e;
            }
        }

        #endregion

        #region EventHandling
        /// <summary>Eventhandler to accept the server certificate forwards this event</summary>
        private void Validator_CertificateValidation(CertificateValidator certificate, CertificateValidationEventArgs e)
        {
            //Accept the certificate send from the server
            e.Accept = true;
        }

        /// <summary>Eventhandler for MonitoredItemNotifications forwards this event</summary>
        private void Notification_MonitoredItem(MonitoredItem monitoredItem, MonitoredItemNotificationEventArgs e)
        {
            ItemChangedNotification(monitoredItem, e);
        }

        /// <summary>Eventhandler for KeepAlive forwards this event</summary>
        private void Notification_KeepAlive(Session session, KeepAliveEventArgs e)
        {
            KeepAliveNotification(session, e);
            ServerStateChanged(e.CurrentState);
        }

        public void ServerStateChanged(ServerState state)
        {
            try
            {
                switch (state)
                {
                    case ServerState.Running:
                        isConnect = true;
                        break;
                    default:
                        //mSession.Reconnect();
                        isConnect = false;
                        break;
                }

            }
            catch (Exception e)
            {
                isConnect = false;
                //handle Exception here
                throw e;
            }
        }
        #endregion

        #region Private methods
        /// <summary>Creats a minimal required ApplicationConfiguration</summary>
        /// <param name="localIpAddress">The ip address of the interface to connect with</param>
        /// <returns>The ApplicationConfiguration</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        private static ApplicationConfiguration CreateClientConfiguration()
        {
            // The application configuration can be loaded from any file.
            // ApplicationConfiguration.Load() method loads configuration by looking up a file path in the App.config.
            // This approach allows applications to share configuration files and to update them.
            // This example creates a minimum ApplicationConfiguration using its default constructor.
            ApplicationConfiguration configuration = new ApplicationConfiguration();

            // Step 1 - Specify the client identity.        
            configuration.ApplicationName = "UA Client 1500";
            configuration.ApplicationType = ApplicationType.Client;
            configuration.ApplicationUri = "http://localhost/VendorId/ApplicationId/InstanceId";
            configuration.ProductUri = "http://VendorId/ProductId/VersionId";


            // Step 2 - Specify the client's application instance certificate.
            // Application instance certificates must be placed in a windows certficate store because that is 
            // the best way to protect the private key. Certificates in a store are identified with 4 parameters:
            // StoreLocation, StoreName, SubjectName and Thumbprint.            
            // When using StoreType = Directory you need to have the opc.ua.certificategenerator.exe installed on your machine

            configuration.SecurityConfiguration = new SecurityConfiguration();
            configuration.SecurityConfiguration.ApplicationCertificate = new CertificateIdentifier();
            configuration.SecurityConfiguration.ApplicationCertificate.StoreType = CertificateStoreType.Windows;
            configuration.SecurityConfiguration.ApplicationCertificate.StorePath = "LocalMachine\\My";
            configuration.SecurityConfiguration.ApplicationCertificate.SubjectName = configuration.ApplicationName;

            // find the client certificate in the store.
            X509Certificate2 clientCertificate = configuration.SecurityConfiguration.ApplicationCertificate.Find(true);

            // Get local interface ip addresses and DNS name
            List<string> localIps = GetLocalIPAddressAndDns();

            // create a new certificate if one not found.
            if (clientCertificate == null)
            {
                // this code would normally be called as part of the installer - called here to illustrate.
                // create a new certificate an place it in the current directory.
                clientCertificate = CertificateFactory.CreateCertificate(
                    configuration.SecurityConfiguration.ApplicationCertificate.StoreType,
                    configuration.SecurityConfiguration.ApplicationCertificate.StorePath,
                    configuration.ApplicationUri,
                    configuration.ApplicationName,
                    null,
                    localIps,
                    1024,
                    120);
            }


            // Step 3 - Specify the supported transport quotas.
            // The transport quotas are used to set limits on the contents of messages and are
            // used to protect against DOS attacks and rogue clients. They should be set to
            // reasonable values.
            configuration.TransportQuotas = new TransportQuotas();
            configuration.TransportQuotas.OperationTimeout = 360000;
            configuration.TransportQuotas.MaxStringLength = 67108864;

            // Step 4 - Specify the client specific configuration.
            configuration.ClientConfiguration = new ClientConfiguration();
            configuration.ClientConfiguration.DefaultSessionTimeout = 360000;

            // Step 5 - Validate the configuration.

            // This step checks if the configuration is consistent and assigns a few internal variables
            // that are used by the SDK. This is called automatically if the configuration is loaded from
            // a file using the ApplicationConfiguration.Load() method.          
            configuration.Validate(ApplicationType.Client);

            return configuration;
        }

        /// <summary>Creats an EndpointDescription</summary>
        /// <param name="url">The endpoint url</param>
        /// <param name="security">Use security or not</param>
        /// <returns>The EndpointDescription</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        private static EndpointDescription CreateEndpointDescription(string url, bool security)
        {
            // create the endpoint description.
            EndpointDescription endpointDescription = new EndpointDescription();

            // submit the url of the endopoint
            endpointDescription.EndpointUrl = url;

            // specify the security policy to use.
            if (security)
            {
                endpointDescription.SecurityPolicyUri = SecurityPolicies.Basic128Rsa15;
                endpointDescription.SecurityMode = MessageSecurityMode.SignAndEncrypt;
            }
            else
            {
                endpointDescription.SecurityPolicyUri = SecurityPolicies.None;
                endpointDescription.SecurityMode = MessageSecurityMode.None;
            }

            // specify the transport profile.
            endpointDescription.TransportProfileUri = Profiles.UaTcpTransport;

            return endpointDescription;
        }

        /// <summary>Gets the local IP addresses and the DNS name</summary>
        /// <returns>The list of IPs and names</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        public static List<string> GetLocalIPAddressAndDns()
        {
            List<string> localIps = new List<string>();
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    localIps.Add(ip.ToString());
                }

            }
            if (localIps.Count == 0)
            {
                throw new Exception("Local IP Address Not Found!");
            }
            localIps.Add(Dns.GetHostName());
            return localIps;
        }

        /// <summary>Parses a XML string for the a default data type</summary>
        /// <param name="xmlStringToParse">The XML string containing data type information</param>
        /// <param name="stringToParserFor">The data type as string to search for</param>
        /// <returns>The created objects after parsing for default data type</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        private static List<object> ParseTypeDictionary(String xmlStringToParse, String stringToParserFor)
        {
            List<object> varList = new List<object>();

            //Remove last XML sign and create a XML document out of the dictionary string
            xmlStringToParse = xmlStringToParse.Remove(xmlStringToParse.Length - 1);
            XmlDocument docToParse = new XmlDocument();
            docToParse.LoadXml(xmlStringToParse);

            //Get a XML node list of objectes named by "stringToParseFor"
            docToParse.GetElementsByTagName(stringToParserFor);
            XmlNodeList nodeList;
            nodeList = docToParse.GetElementsByTagName("opc:StructuredType");

            XmlNode foundNode = null;

            //search for the attribute name == "stringToParseFor"
            foreach (XmlNode node in nodeList)
            {
                if (node.Attributes["Name"].Value == stringToParserFor)
                {
                    foundNode = node;
                    break;
                }
            }

            //check if attribute name was found
            if (foundNode == null)
            {
                return null;
            }

            //get child nodes of parent node with attribute name == "stringToParseFor" and parse for var name and var type
            foreach (XmlNode node in foundNode.ChildNodes)
            {
                string[] dataReferenceStringArray = new string[2];

                dataReferenceStringArray[0] = node.Attributes["Name"].Value;
                dataReferenceStringArray[1] = node.Attributes["TypeName"].Value;

                varList.Add(dataReferenceStringArray);
            }

            //Check if result contains another struct/UDT inside and parse for var name and var type
            //Note: This check is consistent even if there are more structs/UDTs inside of structs/UDTs
            for (int count = 0; count < varList.Count; count++)
            {
                Object varObject = varList[count];
                if (((string[])varObject)[1].Contains("tns:"))
                {
                    XmlNode innerNode = null;
                    foreach (XmlNode anotherNode in nodeList)
                    {
                        if (anotherNode.Attributes["Name"].Value == ((string[])varObject)[1].Remove(0, 4))
                        {
                            innerNode = anotherNode;
                            break;
                        }
                    }

                    if (innerNode == null)
                    {
                        return null;
                    }

                    int i = 0;
                    foreach (XmlNode innerChildNode in innerNode.ChildNodes)
                    {
                        string[] innerDataReferenceStringArray = new string[2];
                        innerDataReferenceStringArray[0] = innerChildNode.Attributes["Name"].Value; ;
                        innerDataReferenceStringArray[1] = innerChildNode.Attributes["TypeName"].Value;
                        varList.Insert(varList.IndexOf(varObject) + 1 + i, innerDataReferenceStringArray);
                        i += 1;
                    }
                }
            }
            return varList;
        }

        /// <summary>Parses a byte array to objects containing tag names and tag data types</summary>
        /// <param name="varList">List of object containing tag names and tag data types</param>
        /// <param name="byteResult">A byte array to parse</param>
        /// <returns>A list of string[3]; string[0] = tag name, string[1] = value, string[2] = opc data type</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        private static List<string[]> ParseDataToTagsFromDictionary(List<Object> varList, byte[] byteResult)
        {
            //Define result list to return var name, var value and var data type
            List<string[]> resultStringList = new List<string[]>();

            //Byte decoding index
            int index = 0;

            //Int used to decode arrays
            Int32 arraylength = 0;

            //Start decoding for opc data types
            foreach (object val in varList)
            {
                string[] dataReferenceStringArray = new string[3];


                dataReferenceStringArray[0] = ((string[])val)[0];


                if (index >= byteResult.Length)
                {
                    index += 0;

                }

                if (((string[])val)[1] == "opc:Boolean" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = BitConverter.ToBoolean(byteResult, index).ToString();
                    index += 1;
                }
                else if (((string[])val)[1] == "opc:Int16" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = BitConverter.ToInt16(byteResult, index).ToString();
                    index += 2;
                }
                else if (((string[])val)[1] == "opc:Int32" && arraylength == 0 && !((string[])val)[0].Contains("_Size"))
                {
                    dataReferenceStringArray[1] = BitConverter.ToInt32(byteResult, index).ToString();
                    index += 4;
                }
                else if (((string[])val)[1] == "opc:Float" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = BitConverter.ToSingle(byteResult, index).ToString();
                    index += 4;
                }
                else if (((string[])val)[1] == "opc:Double" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = BitConverter.ToDouble(byteResult, index).ToString();
                    index += 8;
                }
                else if (((string[])val)[1] == "opc:String" && !(arraylength > 0))
                {
                    Int32 stringlength = BitConverter.ToInt32(byteResult, index);
                    index += 4;
                    if (stringlength > 0)
                    {
                        dataReferenceStringArray[1] = Encoding.UTF8.GetString(byteResult, index, stringlength);
                        index += stringlength;
                    }
                    else
                    {
                        dataReferenceStringArray[1] = "";
                    }
                }
                else if (((string[])val)[1] == "opc:CharArray")
                {
                    Int32 stringlength = BitConverter.ToInt32(byteResult, index);
                    index += 4;
                    if (stringlength > 0)
                    {
                        dataReferenceStringArray[1] = Encoding.UTF8.GetString(byteResult, index, stringlength);
                        index += stringlength;
                    }
                    else
                    {
                        dataReferenceStringArray[1] = "";
                    }
                }
                else if (((string[])val)[1] == "opc:UInt16" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = BitConverter.ToUInt16(byteResult, index).ToString();
                    index += 2;
                }
                else if (((string[])val)[1] == "opc:UInt32" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = BitConverter.ToUInt32(byteResult, index).ToString();
                    index += 4;
                }
                else if (((string[])val)[1] == "opc:Int64" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = BitConverter.ToInt64(byteResult, index).ToString();
                    index += 8;
                }
                else if (((string[])val)[1] == "opc:UInt64" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = BitConverter.ToUInt64(byteResult, index).ToString();
                    index += 8;
                }
                else if (((string[])val)[1] == "opc:Byte" && !(arraylength > 0))
                {
                    dataReferenceStringArray[1] = byteResult[index].ToString();
                    index += 1;
                }
                else if (((string[])val)[1] == "opc:Int32" && ((string[])val)[0].Contains("_Size"))
                {
                    arraylength = BitConverter.ToInt32(byteResult, index);
                    dataReferenceStringArray[1] = arraylength.ToString();
                    index += 4;
                }
                else if (((string[])val)[1] == "opc:Byte" && arraylength > 0)
                {
                    Int32[] tempArray = new Int32[arraylength];
                    for (int i = 0; i < arraylength; i++)
                    {
                        if (index >= byteResult.Length)
                        {
                            index += 0;

                        }
                        tempArray[i] = byteResult[index];


                        index += 1;
                    }
                    dataReferenceStringArray[1] = String.Join(";", tempArray);
                    dataReferenceStringArray[1] = String.Concat(dataReferenceStringArray[1], ";");
                    arraylength = 0;
                }
                else if (((string[])val)[1] == "opc:UInt32" && arraylength > 0)
                {
                    UInt32[] tempArray = new UInt32[arraylength];
                    for (int i = 0; i < arraylength; i++)
                    {
                        tempArray[i] = byteResult[index];
                        index += 4;
                    }
                    dataReferenceStringArray[1] = String.Join(";", tempArray);
                    dataReferenceStringArray[1] = String.Concat(dataReferenceStringArray[1], ";");
                    arraylength = 0;
                }
                else if (((string[])val)[1] == "opc:UInt16" && arraylength > 0)
                {
                    UInt16[] tempArray = new UInt16[arraylength];
                    for (int i = 0; i < arraylength; i++)
                    {
                        if (index >= byteResult.Length)
                        {
                            index += 0;

                        }
                        tempArray[i] = BitConverter.ToUInt16(byteResult, index);


                        index += 2;
                    }
                    dataReferenceStringArray[1] = String.Join(";", tempArray);
                    dataReferenceStringArray[1] = String.Concat(dataReferenceStringArray[1], ";");
                    arraylength = 0;
                }
                else if (((string[])val)[1] == "opc:String" && arraylength > 0)
                {
                    for (int i = 0; i < arraylength; i++)
                    {
                        if (index >= byteResult.Length)
                        {
                            index += 0;

                        }
                        Int32 stringlength = BitConverter.ToInt32(byteResult, index);
                        index += 4;
                        if (stringlength > 0)
                        {
                            if (index >= byteResult.Length)
                            {
                                index += 0;

                            }
                            dataReferenceStringArray[1] = String.Concat(dataReferenceStringArray[1], Encoding.UTF8.GetString(byteResult, index, stringlength));
                            dataReferenceStringArray[1] = String.Concat(dataReferenceStringArray[1], ";");
                            index += stringlength;
                        }
                        else
                        {
                            dataReferenceStringArray[1] = "";
                        }
                    }
                    arraylength = 0;
                }
                else if (((string[])val)[1].Contains("tns:"))
                {
                    dataReferenceStringArray[1] = "";
                }
                else
                {
                    Exception e = new Exception("Read result contains unknown or advanced binary data type.");
                    throw e;
                }
                dataReferenceStringArray[2] = ((string[])val)[1];
                resultStringList.Add(dataReferenceStringArray);
            }
            return resultStringList;
        }

        /// <summary>Parses a byte array to objects containing tag names and tag data types</summary>
        /// <param name="dataToWrite">The data to analyze</param>
        /// <returns>The length</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        private static Int64 GetLengthOfDataToWrite(List<string[]> dataToWrite)
        {
            Int64 length = 0;
            Int32 arraySize = 0;
            foreach (string[] val in dataToWrite)
            {
                if (arraySize > 0)
                {
                    arraySize = 0;
                    continue;
                }
                if (val[2] == "opc:Boolean")
                {
                    length += 1;
                }
                else if (val[2] == "opc:Int16")
                {
                    length += 2;
                }
                else if (val[2] == "opc:Float")
                {
                    length += 4;
                }
                else if (val[2] == "opc:Double")
                {
                    length += 8;
                }
                else if (val[2] == "opc:UInt16")
                {
                    length += 2;
                }
                else if (val[2] == "opc:Int32" && !(val[0].Contains("_Size")))
                {
                    length += 4;
                }
                else if (val[2] == "opc:UInt32")
                {
                    length += 4;
                }
                else if (val[2] == "opc:Int64")
                {
                    length += 8;
                }
                else if (val[2] == "opc:UInt64")
                {
                    length += 8;
                }
                else if (val[2] == "opc:Byte")
                {
                    length += 1;
                }
                else if (val[2] == "opc:String")
                {
                    length += val[1].Length + 4;
                }
                else if (val[2] == "opc:CharArray")
                {
                    length += val[1].Length + 4;
                }
                else if (val[2] == "opc:Int32" && val[0].Contains("_Size"))
                {
                    arraySize = Convert.ToInt32(val[1]);

                    if (((string[])dataToWrite[dataToWrite.IndexOf(val) + 1])[2] == "opc:String")
                    {
                        string[] tempStringArr = new string[arraySize];
                        tempStringArr = ((string[])dataToWrite[dataToWrite.IndexOf(val) + 1])[1].Split(';');
                        for (int ii = 0; ii < arraySize; ii++)
                        {
                            length += (4 + tempStringArr[ii].Length);
                        }
                        length += 4;
                    }
                    else if (((string[])dataToWrite[dataToWrite.IndexOf(val) + 1])[2] == "opc:Byte")
                    {
                        length += (4 + arraySize);
                    }
                    else if (((string[])dataToWrite[dataToWrite.IndexOf(val) + 1])[2] == "opc:UInt16")
                    {
                        length += (4 + arraySize * 2);
                    }
                    else if (((string[])dataToWrite[dataToWrite.IndexOf(val) + 1])[2] == "opc:UInt32")
                    {
                        length += (4 + arraySize * 4);
                    }
                }
                else if (val[2].Contains("tns:"))
                {
                    ;
                }
                else
                {
                    Exception e = new Exception("Unknow data type. Can't determine length of data");
                    throw e;
                }
            }
            return length;
        }

        /// <summary>Browses for the desired type dictonary to parse for containing data types</summary>
        /// <param name="nodeIdString">The node Id string</param>
        /// <param name="theSessionToBrowseIn">The current session to browse in</param>
        /// <param name="parseString">The name of the var to parse for inside of dictionary</param>
        /// <returns>The dictionary as ASCII string</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        private static String GetTypeDictionary(String nodeIdString, Session theSessionToBrowseIn, out String parseString)
        {
            //Read the desired node first and chekc if it's a variable
            Node node = theSessionToBrowseIn.ReadNode(nodeIdString);
            if (node.NodeClass == NodeClass.Variable)
            {
                //Get the node id of node's data type
                VariableNode variableNode = (VariableNode)node.DataLock;
                NodeId nodeId = new NodeId(variableNode.DataType.Identifier, variableNode.DataType.NamespaceIndex);

                //Browse for HasEncoding
                ReferenceDescriptionCollection refDescCol;
                byte[] continuationPoint;
                theSessionToBrowseIn.Browse(null, null, nodeId, 0u, BrowseDirection.Forward, ReferenceTypeIds.HasEncoding, true, 0, out continuationPoint, out refDescCol);

                //Check For found reference
                if (refDescCol.Count == 0)
                {
                    Exception ex = new Exception("No data type to encode. Could be a build-in data type you want to read.");
                    throw ex;
                }

                //Check for HasEncoding reference with name "Default Binary"
                foreach (ReferenceDescription refDesc in refDescCol)
                {
                    if (refDesc.DisplayName.Text == "Default Binary")
                    {
                        nodeId = new NodeId(refDesc.NodeId.Identifier, refDesc.NodeId.NamespaceIndex);
                    }
                    else
                    {
                        Exception ex = new Exception("No default binary data type found.");
                        throw ex;
                    }
                }

                //Browse for HasDescription
                refDescCol = null;
                theSessionToBrowseIn.Browse(null, null, nodeId, 0u, BrowseDirection.Forward, ReferenceTypeIds.HasDescription, true, 0, out continuationPoint, out refDescCol);

                //Check For found reference
                if (refDescCol.Count == 0)
                {
                    Exception ex = new Exception("No data type description found in address space.");
                    throw ex;
                }

                //Read from node id of the found description to get a value to parse for later on
                nodeId = new NodeId(refDescCol[0].NodeId.Identifier, refDescCol[0].NodeId.NamespaceIndex);
                DataValue resultValue = theSessionToBrowseIn.ReadValue(nodeId);
                parseString = resultValue.Value.ToString();

                //Browse for ComponentOf from last browsing result inversly
                refDescCol = null;
                theSessionToBrowseIn.Browse(null, null, nodeId, 0u, BrowseDirection.Inverse, ReferenceTypeIds.HasComponent, true, 0, out continuationPoint, out refDescCol);

                //Check if reference was found
                if (refDescCol.Count == 0)
                {
                    Exception ex = new Exception("Data type isn't a component of parent type in address space. Can't continue decoding.");
                    throw ex;
                }

                //Read from node id of the found HasCompoment reference to get a XML file (as HEX string) containing struct/UDT information

                nodeId = new NodeId(refDescCol[0].NodeId.Identifier, refDescCol[0].NodeId.NamespaceIndex);
                resultValue = theSessionToBrowseIn.ReadValue(nodeId);

                //Convert the HEX string to ASCII string
                String xmlString = ASCIIEncoding.ASCII.GetString((byte[])resultValue.Value);

                //Return the dictionary as ASCII string
                return xmlString;
            }
            {
                Exception ex = new Exception("No variable data type found");
                throw ex;
            }
        }

        /// <summary>Parses data to write to a byte array</summary>
        /// <param name="dataToWrite">The data to write as string[3]; string[0] = tag name, string[1] = value, string[2] = opc data type</param>
        /// <param name="dataLength">The length of the data to write</param>
        /// <returns>The parsed byte array</returns>
        /// <exception cref="Exception">Throws and forwards any exception with short error description.</exception>
        private static byte[] ParseDataToByteArray(List<string[]> dataToWrite, Int64 dataLength)
        {
            byte[] bytesToWrite = new byte[dataLength];
            Int32 convertIndex = 0;
            Int32 arraySize = 0;
            foreach (string[] val in dataToWrite)
            {
                if (val[2] == "opc:Boolean")
                {
                    Boolean tempBool = Convert.ToBoolean(val[1]);
                    bytesToWrite[convertIndex] = Convert.ToByte(tempBool);
                    convertIndex += 1;
                }
                else if (val[2] == "opc:Int16" && !(arraySize > 0))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToInt16(val[1])), 0, bytesToWrite, convertIndex, 2);
                    convertIndex += 2;
                }
                else if (val[2] == "opc:Float" && !(arraySize > 0))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToSingle(val[1])), 0, bytesToWrite, convertIndex, 4);
                    convertIndex += 4;
                }
                else if (val[2] == "opc:Double" && !(arraySize > 0))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToDouble(val[1])), 0, bytesToWrite, convertIndex, 8);
                    convertIndex += 8;
                }
                else if (val[2] == "opc:UInt16" && !(arraySize > 0))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToUInt16(val[1])), 0, bytesToWrite, convertIndex, 2);
                    convertIndex += 2;
                }
                else if (val[2] == "opc:Int32" && !(val[0].Contains("_Size")))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToUInt32(val[1])), 0, bytesToWrite, convertIndex, 4);
                    convertIndex += 4;
                }
                else if (val[2] == "opc:UInt32" && !(arraySize > 0))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToUInt32(val[1])), 0, bytesToWrite, convertIndex, 4);
                    convertIndex += 4;
                }
                else if (val[2] == "opc:Int64" && !(arraySize > 0))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToInt64(val[1])), 0, bytesToWrite, convertIndex, 8);
                    convertIndex += 8;
                }
                else if (val[2] == "opc:UInt64" && !(arraySize > 0))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToUInt64(val[1])), 0, bytesToWrite, convertIndex, 8);
                    convertIndex += 8;
                }
                else if (val[2] == "opc:Byte" && !(arraySize > 0))
                {
                    bytesToWrite[convertIndex] = Convert.ToByte(val[1]);
                    convertIndex += 1;
                }
                else if (val[2] == "opc:String" && !(arraySize > 0))
                {
                    Array.Copy(BitConverter.GetBytes(val[1].Length), 0, bytesToWrite, convertIndex, 4);
                    convertIndex += 4;
                    foreach (Char c in val[1])
                    {
                        bytesToWrite[convertIndex] = Convert.ToByte(c);
                        convertIndex += 1;
                    }
                }
                else if (val[2] == "opc:CharArray")
                {
                    Array.Copy(BitConverter.GetBytes(val[1].Length), 0, bytesToWrite, convertIndex, 4);
                    convertIndex += 4;
                    foreach (Char c in val[1])
                    {
                        bytesToWrite[convertIndex] = Convert.ToByte(c);
                        convertIndex += 1;
                    }
                }
                else if (val[2] == "opc:Int32" && val[0].Contains("_Size"))
                {
                    Array.Copy(BitConverter.GetBytes(Convert.ToUInt32(val[1])), 0, bytesToWrite, convertIndex, 4);
                    arraySize = Convert.ToInt32(val[1]);
                    convertIndex += 4;
                }
                else if (val[2] == "opc:Byte" && arraySize > 0)
                {
                    String tempString = "";
                    foreach (Char c in val[1])
                    {
                        if (c != ';')
                        {
                            tempString = String.Concat(tempString, c);
                        }
                        else
                        {
                            bytesToWrite[convertIndex] = Convert.ToByte(tempString);
                            convertIndex += 1;
                            tempString = "";
                        }
                    }
                    arraySize = 0;
                }
                else if (val[2] == "opc:UInt16" && arraySize > 0)
                {
                    string[] tempStringArr = new string[arraySize];
                    tempStringArr = val[1].Split(';');
                    for (int ii = 0; ii < arraySize; ii++)
                    {
                        if (convertIndex >= dataLength)
                        {
                            convertIndex += 0;

                        }
                        else
                        {
                            Array.Copy(BitConverter.GetBytes(Convert.ToUInt16(tempStringArr[ii])), 0, bytesToWrite, convertIndex, 2);
                            convertIndex += 2;
                        }

                    }
                    arraySize = 0;
                }

                else if (val[2] == "opc:UInt32" && arraySize > 0)
                {
                    string[] tempStringArr = new string[arraySize];
                    tempStringArr = val[1].Split(';');
                    for (int ii = 0; ii < arraySize; ii++)
                    {
                        Array.Copy(BitConverter.GetBytes(Convert.ToUInt32(tempStringArr[ii])), 0, bytesToWrite, convertIndex, 4);
                        convertIndex += 4;

                    }
                    arraySize = 0;
                }
                else if (val[2] == "opc:String" && arraySize > 0)
                {
                    string[] tempStringArr = new string[arraySize];
                    tempStringArr = val[1].Split(';');
                    for (int ii = 0; ii < arraySize; ii++)
                    {
                        Array.Copy(BitConverter.GetBytes(tempStringArr[ii].Length), 0, bytesToWrite, convertIndex, 4);
                        convertIndex += 4;
                        foreach (Char c in tempStringArr[ii])
                        {
                            bytesToWrite[convertIndex] = Convert.ToByte(c);
                            convertIndex += 1;
                        }
                    }
                    arraySize = 0;
                }
                else if (val[2].Contains("tns:"))
                {
                    ;
                }
                else
                {
                    Exception e = new Exception("Can't covert" + val[0] + ".");
                    throw e;
                }
            }
            return bytesToWrite;
        }
        #endregion
    }
}