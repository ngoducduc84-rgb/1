﻿using System;
using System.Collections.Generic;

namespace SvMip.Interface
{
    /// <summary>
    /// In-memory IO without any hardware. Used when a process is started by a TCP / serial message
    /// (SvTrigger in Tcp mode): AutoThread_Direct sets the Start / Complete bits itself, the handshake
    /// of AutoThread_Base runs unchanged on these bits.
    /// Addresses below 0 (unused signals) are accepted and ignored.
    /// </summary>
    public class IO_Virtual : IIO
    {
        readonly object mSync = new object();
        readonly Dictionary<int, bool> mIn = new Dictionary<int, bool>();
        readonly Dictionary<int, bool> mOut = new Dictionary<int, bool>();

        public bool OpenDevice() { return true; }
        public bool CloseDevice() { return true; }
        public void ThreadStart() { }
        public void ThreadStop() { }
        public bool WriteBit() { return true; }
        public bool GetOutIOCehck() { return true; }
        public bool IsConnected { get { return true; } }

        public void ResetBit()
        {
            lock (mSync)
            {
                List<int> keys = new List<int>(mIn.Keys);
                foreach (int k in keys) mIn[k] = false;
                keys = new List<int>(mOut.Keys);
                foreach (int k in keys) mOut[k] = false;
            }
        }

        public bool SetOutValue(int _index, bool _value, bool _select = true)
        {
            if (_index < 0) return true;
            lock (mSync) { mOut[_index] = _value; }
            return true;
        }

        public bool SetInValue(int _index, bool _value)
        {
            if (_index < 0) return true;
            lock (mSync) { mIn[_index] = _value; }
            return true;
        }

        public bool GetInValue(int _index)
        {
            if (_index < 0) return false;
            lock (mSync)
            {
                bool v;
                return mIn.TryGetValue(_index, out v) && v;
            }
        }

        public bool GetOutValue(int _index)
        {
            if (_index < 0) return false;
            lock (mSync)
            {
                bool v;
                return mOut.TryGetValue(_index, out v) && v;
            }
        }

        public Dictionary<int, bool> InIO { get { return mIn; } }
        public Dictionary<int, bool> OutIO { get { return mOut; } }
    }
}
