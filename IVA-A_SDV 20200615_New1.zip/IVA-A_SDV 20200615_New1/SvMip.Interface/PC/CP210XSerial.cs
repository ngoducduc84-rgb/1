﻿using System;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.IO;
using System.Collections.Generic;

namespace SvMip.Interface
{
    public class CP210XSerial : IIO
    {
        public static CP210XSerial cp210 = new CP210XSerial();

        static bool bConnectCP210X = false;
        UInt32 resp = 0xffffffff;    //Output상태

        public Dictionary<int, bool> InIO { get { return mInIO; } }
        Dictionary<int, bool> mInIO = new Dictionary<int, bool>();

        public Dictionary<int, bool> OutIO { get { return mOutIO; } }
        Dictionary<int, bool> mOutIO = new Dictionary<int, bool>();

        public bool IsConnected { get { return bConnectCP210X; } }

        //#region Functions exported from DLL.
        //[DllImport("kernel32.dll", EntryPoint = "LoadLibrary")]
        //static extern IntPtr LoadLibrary([MarshalAs(UnmanagedType.LPStr)] string lpLibFileName);
        //[DllImport("kernel32.dll", EntryPoint = "GetProcAddress", CharSet = CharSet.Ansi)]
        //static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);
        //[DllImport("kernel32.dll", EntryPoint = "FreeLibrary")]
        //static extern bool FreeLibrary(int hModule);
        //#endregion

        //[UnmanagedFunctionPointer(CallingConvention.StdCall)]
        //delegate bool InitializeYoiWinIOModule();
        //InitializeYoiWinIOModule InitC210x;
        
        #region Functions exported from DLL.
        [DllImport(@"Dll\x86\CP210X\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool InitializeYoiWinIOModule();
        [DllImport(@"Dll\x86\CP210X\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool ShutdownYoiWinIOModule();
        [DllImport(@"Dll\x86\CP210X\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetFirmwareVersion(short mode, out byte major, out byte minor, out UInt16 patch);
        [DllImport(@"Dll\x86\CP210X\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetErrorCode(out UInt32 pdwDllError, out UInt32 pdwWinError);
        [DllImport(@"Dll\x86\CP210X\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool SetOutput(UInt32 dwMask, UInt32 dwSetVal, out UInt32 pdwRspVal);
        [DllImport(@"Dll\x86\CP210X\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetOutput(out UInt32 pdwPinVal);
        [DllImport(@"Dll\x86\CP210X\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetInput(out UInt32 pdwPinVal);
        #endregion;

        public void ThreadStart() { }
        public void ThreadStop() { }

        public CP210XSerial()
        {
            //string dllPath;
            //switch (IntPtr.Size)
            //{
            //    case 4:
            //        dllPath = Path.Combine("Dll", "x86", "CP210X", "YoiWinIOx32.dll");
            //        break;
            //    case 8:
            //        dllPath = Path.Combine("Dll", "x64", "CP210X", "YoiWinIOx64.dll");
            //        break;
            //    default:
            //        throw new Exception("What the hell of this platform?");
            //}

            //InitFunc(dllPath);
            try
            {
                if (!OpenDevice())
                {
                    SvMip.Common.SvLogger.Log.Error("CP210X Lib 연결 실패");
                    return;
                }
            }
            catch (Exception ex)
            {
                //System.Windows.Forms.MessageBox.Show(ex.ToString());
                return;
            }
            bConnectCP210X = true;
        }


        //void InitFunc(string dllPath)
        //{
        //    IntPtr hModule = LoadLibrary(dllPath);
        //    IntPtr pFuncAddr = IntPtr.Zero;

        //    pFuncAddr = GetProcAddress(hModule, "InitializeYoiWinIOModule");
        //    InitC210x = (InitializeYoiWinIOModule)Marshal.GetDelegateForFunctionPointer(pFuncAddr, typeof(InitializeYoiWinIOModule));

        //}


        bool[] gpo = new bool[32];
        public bool[] GPO
        {
            get
            {
                uint ui_gpo;
                if (bConnectCP210X)
                    if (GetOutput(out ui_gpo))
                        ParsingIO(ui_gpo, ref gpo);
                return gpo;
            }
        }

        bool[] gpi = new bool[32];
        public bool[] GPI
        {
            get
            {
                uint ui_gpi;
                if (bConnectCP210X)
                    if (GetInput(out ui_gpi))
                        ParsingIO(ui_gpi, ref gpi);
                return gpi;
            }
        }
        void ParsingIO(uint value, ref bool[] io)
        {
            for (int i = 0; i < 32; i++)
            {
                io[i] = ((value >> i) & 0x00000001) == 1 ? false : true;
            }
        }

        public bool WriteGPO(int index, bool onoff)
        {
            if (!bConnectCP210X)
            {
                gpo[index] = !onoff;
                return false;
            }

            if (index < 0 || index >= 32)
                throw new Exception("GPO : 0 ~ 31");

            bool success = false;
            UInt32 TempMask = (UInt32)0x00000001 << index;
            UInt32 pinVal = 0;

            if (onoff)
            {
                if (gpo[index]) return true;
                pinVal = resp ^ TempMask;
            }
            else
            {
                pinVal = resp | TempMask;
            }

            success = SetOutput(TempMask, pinVal, out resp);
            if (success)
                gpo[index] = onoff;
            return success;
        }

        public bool OpenDevice()
        {

            if (bConnectCP210X){
                CloseDevice();
            }
            if (!InitializeYoiWinIOModule()) return false;  //Fail Connection
            bConnectCP210X = true;
            for (int i = 0; i < 32; i++) GetOutValue(i); //Output 초기값 확인
            return true;
        }
        public bool CloseDevice()
        {
            if (bConnectCP210X)
            {
                if (!ShutdownYoiWinIOModule()) return false;  //비정상종료               
            }
            bConnectCP210X = false;
            return true;    //정상종료
        }
        public bool SetOutValue(int _index, bool _value, bool _select = true)
        {
            if (_index < 0) return false;
            return WriteGPO(_index, _value);
        }
        public bool SetInValue(int _index, bool _value)
        {
            if (_index < 0) return false;
            GPI[_index] = _value;
            return true;
        }
        public bool GetInValue(int _index)
        {
            if (_index < 0) return false;
            return GPI[_index];
        }
        public bool GetOutValue(int _index)
        {
            if (_index < 0) return false;
            return GPO[_index];
        }
        public bool GetOutIOCehck()
        {
            //[hong] 이게 뭔지 모르겠는데...
            return true;
        }
        ~CP210XSerial()
        {
            try
            {
                CloseDevice();
            }
            catch (Exception)
            {
                return;
            }
        }

        public bool WriteBit()
        {
            return false;
        }

        public void ResetBit()
        {            
        }
    }
}
