﻿using System;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.IO;
using System.Collections.Generic;

namespace SvMip.Interface
{
    public class NXEWinIOx64 : IIO
    {
        public static NXEWinIOx64 nxe = new NXEWinIOx64();

        public Dictionary<int, bool> InIO { get { return mInIO; } }
        Dictionary<int, bool> mInIO = new Dictionary<int, bool>();

        public Dictionary<int, bool> OutIO { get { return mOutIO; } }
        Dictionary<int, bool> mOutIO = new Dictionary<int, bool>();

        public bool IsConnected { get { return true; } }//생성되면 열려 있는걸로...

        static object communicationLock = new object();

        public enum BrightnessDirection { B_UP = 0, B_DOWN = 1 }
        public enum ThrottleMode
        {
            THTL_DISABLED = 0,	//Throttle Disabled
            THTL_87_5_PER = 1,	//Throttle 87.5%
            THTL_75_PER = 2,	//Throttle 75%
            THTL_62_5_PER = 3,	//Throttle 62.5%
            THTL_50_PER = 4,	//Throttle 50%
            THTL_37_5_PER = 5,	//Throttle 37.5%
            THTL_25PER = 6,	//Throttle 25%
            THTL_125_PER = 7,	//Throttle 12.5%
        }

        struct CPU_SPEED_STR
        {
            //short wOrgCpuSpeed;
            //short wThrottleCPUSpeed;
        };

        public void ThreadStart() { }
        public void ThreadStop() { }

        #region Functions exported from DLL.
        [DllImport("kernel32.dll", EntryPoint = "LoadLibrary")]
        static extern IntPtr LoadLibrary([MarshalAs(UnmanagedType.LPStr)] string lpLibFileName);
        [DllImport("kernel32.dll", EntryPoint = "GetProcAddress", CharSet = CharSet.Ansi)]
        static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);
        [DllImport("kernel32.dll", EntryPoint = "FreeLibrary")]
        static extern bool FreeLibrary(int hModule);
        #endregion

        #region NXEWinIO API Functions
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool InitializeNxeWinIoApi();
        InitializeNxeWinIoApi _InitializeNxeWinIoApi;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate void ShutdownNxeWinIoApi();
        ShutdownNxeWinIoApi _ShutdownNxeWinIoApi;
        #endregion

        #region GPIO API Functions
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool _WriteGPO(byte bGpioVal);
        _WriteGPO __WriteGPO;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadGPO(out byte pbGpioVal);
        ReadGPO _ReadGPO;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadGPI(out byte pbGpioVal);
        ReadGPI _ReadGPI;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadGPIO(out byte pbGpioVal);
        ReadGPIO _ReadGPIO;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool WriteGPOMask(byte bPinMask, byte bGpioVal);
        WriteGPOMask _WriteGPOMask;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadGPOMask(byte bPinMask, out byte pbGpioVal);
        ReadGPOMask _ReadGPOMask;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadGPIMask(byte bPinMask, out byte pbGpioVal);
        ReadGPIMask _ReadGPIMask;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadGPIOMask(byte bPinMask, out byte pbGpioVal);
        ReadGPIOMask _ReadGPIOMask;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool WriteGPOPin(byte bPinNum, bool bGpioPinVal);
        WriteGPOPin _WriteGPOPin;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadGPIOPin(byte bPinNum, out bool pbGpioPinVal);
        ReadGPIOPin _ReadGPIOPin;
        #endregion

        #region WDT API Functions
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool EnableWDT(short wTimeOutVal);
        EnableWDT _EnableWDT;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool DisableWDT();
        DisableWDT _DisableWDT;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ResetWDT(short wTimeOutVal);
        ResetWDT _ResetWDT;
        #endregion

        #region HHM API Functions
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadCPUTempVal(out byte pbRegVal);
        ReadCPUTempVal _ReadCPUTempVal;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadSYSTempVal(out byte pbRegVal);
        ReadSYSTempVal _ReadSYSTempVal;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadPCHTempVal(out byte pbRegVal);
        ReadPCHTempVal _ReadPCHTempVal;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadCPUFanRPMVal(out byte pwRegVal);
        ReadCPUFanRPMVal _ReadCPUFanRPMVal;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool ReadSYSFanRPMVal(out byte pwRegVal);
        ReadSYSFanRPMVal _ReadSYSFanRPMVal;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool SetCPUFanRPMVal(byte bRPMVal);
        SetCPUFanRPMVal _SetCPUFanRPMVal;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool SetSYSFanRPMVal(byte bRPMVal);
        SetSYSFanRPMVal _SetSYSFanRPMVal;
        #endregion

        #region LCD Brightness API Functions
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool LCDBrightnessControl(BrightnessDirection bDirection);
        LCDBrightnessControl _LCDBrightnessControl;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetCurrentLCDBrightness(out byte pbLCDBrightness);
        GetCurrentLCDBrightness _GetCurrentLCDBrightness;
        #endregion

        #region CPU Throttle API Functions
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool SetCPUThrottleMode(ThrottleMode bThrottleMode);
        SetCPUThrottleMode _SetCPUThrottleMode;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetCPUThrottleMode(out ThrottleMode pbThrottleMode);
        GetCPUThrottleMode _GetCPUThrottleMode;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetThrottleCPUSpeed(out CPU_SPEED_STR strCpuSpeed);
        GetThrottleCPUSpeed _GetThrottleCPUSpeed;
        #endregion

        #region Miscellaneous API Functions
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetApiVersion(StringBuilder pszApiVersion);
        GetApiVersion _GetApiVersion;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetDriverVersion(StringBuilder pszDriverVersion);
        GetDriverVersion _GetDriverVersion;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetNxeBoardModelName(StringBuilder pszBoardModelName);
        GetNxeBoardModelName _GetNxeBoardModelName;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetBiosVersion(StringBuilder pszBiosVersion);
        GetBiosVersion _GetBiosVersion;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetPortVal(short wPortAddr, out int pdwPortVal, byte bSize);
        GetPortVal _GetPortVal;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool SetPortVal(short wPortAddr, int dwPortVal, byte bSize);
        SetPortVal _SetPortVal;
        #endregion

        #region NXE-IQM87A IO B'd API Function
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool SetGPOMask_H(byte bNum);
        SetGPOMask_H _SetGPOMask_H;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool SetGPOMask_L(byte bNum);
        SetGPOMask_L _SetGPOMask_L;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool Write_GPO_DWORD(int dwGpioVal);
        Write_GPO_DWORD _Write_GPO_DWORD;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool Read_GPO_DWORD(out uint pdwGpioVal);
        Read_GPO_DWORD _Read_GPO_DWORD;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool Read_GPI_DWORD(out uint pdwGpioVal);
        Read_GPI_DWORD _Read_GPI_DWORD;
        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        delegate bool GetGPIMask(byte bNum, out byte pbGpioVal);
        GetGPIMask _GetGPIMask;
        #endregion

        bool isInit = false;

        void InitFunc(string dllPath)
        {
            IntPtr hModule = LoadLibrary(dllPath);
            _InitializeNxeWinIoApi = (InitializeNxeWinIoApi)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "InitializeNxeWinIoApi"), typeof(InitializeNxeWinIoApi));
            _ShutdownNxeWinIoApi = (ShutdownNxeWinIoApi)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ShutdownNxeWinIoApi"), typeof(ShutdownNxeWinIoApi));
            __WriteGPO = (_WriteGPO)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "WriteGPO"), typeof(_WriteGPO));
            _ReadGPO = (ReadGPO)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadGPO"), typeof(ReadGPO));
            _ReadGPI = (ReadGPI)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadGPI"), typeof(ReadGPI));
            _ReadGPIO = (ReadGPIO)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadGPIO"), typeof(ReadGPIO));
            _WriteGPOMask = (WriteGPOMask)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "WriteGPOMask"), typeof(WriteGPOMask));
            _ReadGPOMask = (ReadGPOMask)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadGPOMask"), typeof(ReadGPOMask));
            _ReadGPIMask = (ReadGPIMask)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadGPIMask"), typeof(ReadGPIMask));
            _ReadGPIOMask = (ReadGPIOMask)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadGPIOMask"), typeof(ReadGPIOMask));
            _WriteGPOPin = (WriteGPOPin)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "WriteGPOPin"), typeof(WriteGPOPin));
            _ReadGPIOPin = (ReadGPIOPin)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadGPIOPin"), typeof(ReadGPIOPin));
            _EnableWDT = (EnableWDT)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "EnableWDT"), typeof(EnableWDT));
            _DisableWDT = (DisableWDT)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "DisableWDT"), typeof(DisableWDT));
            _ResetWDT = (ResetWDT)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ResetWDT"), typeof(ResetWDT));
            _ReadCPUTempVal = (ReadCPUTempVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadCPUTempVal"), typeof(ReadCPUTempVal));
            _ReadSYSTempVal = (ReadSYSTempVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadSYSTempVal"), typeof(ReadSYSTempVal));
            _ReadPCHTempVal = (ReadPCHTempVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadPCHTempVal"), typeof(ReadPCHTempVal));
            _ReadCPUFanRPMVal = (ReadCPUFanRPMVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadCPUFanRPMVal"), typeof(ReadCPUFanRPMVal));
            _ReadSYSFanRPMVal = (ReadSYSFanRPMVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "ReadSYSFanRPMVal"), typeof(ReadSYSFanRPMVal));

            _SetCPUFanRPMVal = (SetCPUFanRPMVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "SetCPUFanRPMVal"), typeof(SetCPUFanRPMVal));
            _SetSYSFanRPMVal = (SetSYSFanRPMVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "SetSYSFanRPMVal"), typeof(SetSYSFanRPMVal));
            _LCDBrightnessControl = (LCDBrightnessControl)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "LCDBrightnessControl"), typeof(LCDBrightnessControl));
            _GetCurrentLCDBrightness = (GetCurrentLCDBrightness)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetCurrentLCDBrightness"), typeof(GetCurrentLCDBrightness));
            _SetCPUThrottleMode = (SetCPUThrottleMode)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "SetCPUThrottleMode"), typeof(SetCPUThrottleMode));
            _GetCPUThrottleMode = (GetCPUThrottleMode)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetCPUThrottleMode"), typeof(GetCPUThrottleMode));
            _GetThrottleCPUSpeed = (GetThrottleCPUSpeed)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetThrottleCPUSpeed"), typeof(GetThrottleCPUSpeed));
            _GetApiVersion = (GetApiVersion)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetApiVersion"), typeof(GetApiVersion));
            _GetDriverVersion = (GetDriverVersion)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetDriverVersion"), typeof(GetDriverVersion));
            _GetNxeBoardModelName = (GetNxeBoardModelName)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetNxeBoardModelName"), typeof(GetNxeBoardModelName));
            _GetBiosVersion = (GetBiosVersion)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetBiosVersion"), typeof(GetBiosVersion));
            _GetPortVal = (GetPortVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetPortVal"), typeof(GetPortVal));
            _SetPortVal = (SetPortVal)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "SetPortVal"), typeof(SetPortVal));
            _SetGPOMask_H = (SetGPOMask_H)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "SetGPOMask_H"), typeof(SetGPOMask_H));
            _SetGPOMask_L = (SetGPOMask_L)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "SetGPOMask_L"), typeof(SetGPOMask_L));
            _Write_GPO_DWORD = (Write_GPO_DWORD)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "Write_GPO_DWORD"), typeof(Write_GPO_DWORD));
            _Read_GPO_DWORD = (Read_GPO_DWORD)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "Read_GPO_DWORD"), typeof(Read_GPO_DWORD));
            _Read_GPI_DWORD = (Read_GPI_DWORD)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "Read_GPI_DWORD"), typeof(Read_GPI_DWORD));
            _GetGPIMask = (GetGPIMask)Marshal.GetDelegateForFunctionPointer(GetProcAddress(hModule, "GetGPIMask"), typeof(GetGPIMask));
        }

        NXEWinIOx64()
        {
#if !SIMULATION
            if (!Environment.Is64BitOperatingSystem)
            {
                //System.Windows.Forms.MessageBox.Show("현재 x86 시스템을 사용하고 있습니다. x64 시스템에서만 IO가 작동합니다.");
                return;
            }

            string dllPath;
            switch (IntPtr.Size)
            {
                case 4:
                    dllPath = Path.Combine("Dll", "x86", "NXE", "NXEWinIOx32.dll");
                    break;
                case 8:
                    dllPath = Path.Combine("Dll", "x64", "NXE", "NXEWinIOx64.dll");
                    break;
                default:
                    throw new Exception("What the hell of this platform?");
            }

            InitFunc(dllPath);

            try
            {
                if (!_InitializeNxeWinIoApi())
                {
                    SvMip.Common.SvLogger.Log.Error("[NXE] Lib 연결 실패");
                    return;
                }
            }
            catch (Exception ex)
            {
                //System.Windows.Forms.MessageBox.Show(ex.ToString());
                return;
            }
            isInit = true;
#endif
        }

        byte cpuTemp;
        public byte CPUTemp
        {
            get
            {
                if (isInit)
                    _ReadCPUTempVal(out cpuTemp);
                return cpuTemp;
            }
        }

        byte sysTemp;
        public byte SysTemp
        {
            get
            {
                if (isInit)
                    _ReadSYSTempVal(out sysTemp);
                return sysTemp;
            }
        }

        byte chipsetTemp;
        public byte ChipsetTemp
        {
            get
            {
                if (isInit)
                    _ReadPCHTempVal(out chipsetTemp);
                return chipsetTemp;
            }
        }

        byte cpuFanRPM;
        public byte CpuFanRPM
        {
            get
            {
                if (isInit)
                    _ReadCPUFanRPMVal(out cpuFanRPM);
                return cpuFanRPM;
            }
        }

        byte sysFanRPM;
        public byte SysFanRPM
        {
            get
            {
                if (isInit)
                    _ReadSYSFanRPMVal(out sysFanRPM);
                return sysFanRPM;
            }
        }

        bool[] gpo = new bool[32];
        public bool[] GPO
        {
            get
            {
                uint ui_gpo;
                if (isInit)
                    if (_Read_GPO_DWORD(out ui_gpo))
                        ParsingIO(ui_gpo, ref gpo);
                return gpo;
            }
        }

        bool[] gpi = new bool[32];
        public bool[] GPI
        {
            get
            {
                uint ui_gpi;
                if (isInit)
                    if (_Read_GPI_DWORD(out ui_gpi))
                        ParsingIO(ui_gpi, ref gpi);
                return gpi;
            }
        }

        void ParsingIO(uint value, ref bool[] io)
        {
            for (int i = 0; i < 32; i++)
            {
                io[i] = ((value >> i) & 0x00000001) == 1 ? false : true;
            }
        }

        object interfacelock = new object();
        public bool WriteGPO(int index, bool onoff)
        {
			lock (interfacelock)
            {
	            if (!isInit)
	            {
	                gpo[index] = !onoff;
	                return false;
	            }

	            if (index < 0 || index >= 32)
	                throw new Exception("GPO : 0 ~ 31");

	            bool success;
            

                if (onoff)
                    success = _SetGPOMask_H((byte)index);
                else
                    success = _SetGPOMask_L((byte)index);

                if (success)
                    gpo[index] = onoff;
            
                return success;
            }
        }

        public bool SetCPUFanRPM(int val)
        {
            if (!isInit) return false;

            if (val < 0 || val > 127)
                throw new Exception("Fan Spd : 0 ~ 127");

            return _SetCPUFanRPMVal((byte)val);
        }

        public bool SetSYSFanRPM(int val)
        {
            if (!isInit) return false;

            if (val < 0 || val > 127)
                throw new Exception("Fan Spd : 0 ~ 127");

            return _SetSYSFanRPMVal((byte)val);
        }

        public bool SetInValue(int _index, bool _value)
        {
            if (_index < 0 || _index >= GPI.Length) return false;
            GPI[_index] = _value;
            return true;
        }

        public bool SetOutValue(int _index, bool _value, bool _select = true)
        {
            if (_index < 0 || _index >= GPO.Length) return false;
            return WriteGPO(_index, _value);
        }

        public bool GetInValue(int _index)
        {
            if (_index < 0 || _index >= GPI.Length) return false;
            return GPI[_index];
        }

        public bool GetOutValue(int _index)
        {
            if (_index < 0 || _index >= GPO.Length) return false;
            return GPO[_index];
        }
        public bool GetOutIOCehck()
        {
            //DIO는 불필요
            return true;
        }
        public bool OpenDevice()
        {
            return true;
        }

        public bool CloseDevice()
        {
            return true;
        }
        
        ~NXEWinIOx64()
        {
            try
            {
                _ShutdownNxeWinIoApi();
            }
            catch (Exception)
            {
                return;
            }
        }

        public bool WriteBit()
        {
            return false;
        }

        public void ResetBit()
        {

        }
    }
}
