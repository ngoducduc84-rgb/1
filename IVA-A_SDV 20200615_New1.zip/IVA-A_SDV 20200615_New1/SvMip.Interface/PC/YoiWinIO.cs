﻿using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace SvMip.Interface
{
    public class YoiWinIO : IIO
    {
        public static YoiWinIO yoi = new YoiWinIO();

        #region Functions exported from DLL.
        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool InitializeYoiWinIOModule();


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool ShutdownYoiWinIOModule();


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetFirmwareVersion(short mode, out byte major, out byte minor, out UInt16 patch);


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetErrorCode(out UInt32 pdwDllError, out UInt32 pdwWinError);


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool SetOutput(UInt32 dwMask, UInt32 dwSetVal, out UInt32 pdwRspVal);


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetOutput(out UInt32 pdwPinVal);


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetInput(out UInt32 pdwPinVal);



        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool RunMonitor(UInt32 dwMask, UInt32 dwSetVal, out UInt32 pdwRspVal);


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool GetTrigger(out UInt32 pdwPinVal);


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool ClearTrigger(UInt32 dwMask, UInt32 dwSetVal, out UInt32 pdwRspVal);


        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern bool ConfigTrigger(UInt32 dwMask, UInt32 dwTrgType, UInt32 dwTrgOption, out UInt32 pdwRspType, out UInt32 pdwRspOption);


        //typedef void (CALLBACK* fnTriggerCallback_t)(DWORD dwTriggered, DWORD dwPinStat);
        public delegate void fnTriggerCallback_t(byte tag, byte seq, UInt32 dwFlag, UInt32 dwValue);
        public static fnTriggerCallback_t fnTriggerCallBack;

        [DllImport(@"Dll\x86\YoiWinIO\YoiWinIOx32.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
        [return: MarshalAs(UnmanagedType.I1)]
        public static extern void RegisterTriggerCallback(fnTriggerCallback_t func);
        #endregion;

        bool isInit = false;

        bool[] gpo = new bool[32];
        public bool[] GPO
        {
            get
            {
                UInt32 pinVal;
                lock (interfacelock)
                {
                    if (isInit)
                        if (GetOutput(out pinVal))
                            ParsingIO(pinVal, ref gpo);
                }
                return gpo;
            }
        }

        bool[] gpi = new bool[32];
        public bool[] GPI
        {
            get
            {
                UInt32 inPinVal;
                lock(interfacelock)
                {
                    if (isInit)
                        if (GetInput(out inPinVal))
                            ParsingIO(inPinVal, ref gpi);
                }
                return gpi;
            }
        }
        void ParsingIO(uint value, ref bool[] io)
        {
            for (int i = 0; i < 32; i++)
            {
                io[i] = ((value >> i) & 0x00000001) == 1 ? false : true;
            }
        }
        YoiWinIO()
        {
            try
            {
                if (!OpenDevice())
                {
                    SvMip.Common.SvLogger.Log.Error("YoiIO Lib 연결 실패");
                    return;
                }
            }
            catch (Exception ex)
            {
                //System.Windows.Forms.MessageBox.Show(ex.ToString());
                return;
            }
            isInit = true;
        }
        ~YoiWinIO()
        {
            try
            {
                CloseDevice();
            }
            catch (Exception)
            {
                return;
            }
        }

        public bool OpenDevice()
        {
            if (IsConnected) CloseDevice();
            if (InitializeYoiWinIOModule())
            {
                isConnected = true;

                //fnTriggerCallBack = TriggerCallback;
                //RegisterTriggerCallback(fnTriggerCallBack);
                return true;
            }
            else
            {
                return false;
            }          
        }
        private void TriggerCallback(byte tag, byte seq, UInt32 dwFlag, UInt32 dwValue)
        {
            string time = DateTime.Now.ToString("HH:mm:ss:fff");
            try
            {
                //이거 필요하려나...
            }
            catch { }
        }

        public bool CloseDevice()
        {
            if (!IsConnected) return true;
            if (ShutdownYoiWinIOModule())
            {
                isConnected = false;
                return true;
            }
            else
                return false;
        }

        public void ThreadStart()
        {

        }
        public void ThreadStop()
        {

        }

        public bool WriteBit()
        {
            return true;
        }

        public void ResetBit()
        {
        }

        public bool SetOutValue(int _index, bool _value, bool _select = true)
        {
            if (_index < 0 || _index >= GPO.Length) return false;


            return WriteGPO(_index, _value);
        }
        object interfacelock = new object();
        public bool WriteGPO(int index, bool onoff)
        {
            if (!isInit)
            {
                gpo[index] = !onoff;
                return false;
            }

            if (index < 0 || index >= 32)
                throw new Exception("GPO : 0 ~ 31");

            bool success;

            UInt32 resp = 0; //이거 쓸지 고민 좀 해보자...쓰면 편할것 같은데...
                             //Test code_JHJ
                             //UInt32 uindex = 0;
                             //for (int i = 0; i < 16; i++)
                             //{
                             //    uindex = (UInt32)(0x01) << i;
                             //    success = SetOutput(uindex, 0xFFFFFFFF, out resp);
                             //    if (success)
                             //        gpo[index] = onoff;
                             //}
                             //return true;
            UInt32 uindex = (UInt32)(0x01) << index;
            lock (interfacelock)
            {
                if (onoff)
                {
                    success = SetOutput(uindex, 0x00000000, out resp);     // ON
                }
                else
                {
                    success = SetOutput(uindex, 0xFFFFFFFF, out resp);     // OFF : Set High
                }
            }
            if (!success)
            {
                UInt32 pdwDllError, pdwWinError;
                if (GetErrorCode(out pdwDllError, out pdwWinError)) Common.SvLogger.Log.Debug("[hong] Error code = " + pdwDllError.ToString() + ", " + pdwWinError.ToString());
                else Common.SvLogger.Log.Debug("[hong] GetErrorCode Fail");
                SvMip.Common.SvLogger.Log.Debug("YoiIO Reopen & Retry");
                lock (interfacelock)
                {
                    if (OpenDevice())
                    {
                        Common.SvLogger.Log.Debug("YOIIO ReOpen Success");
                        if (onoff)
                        {
                            success = SetOutput(uindex, 0x00000000, out resp);     // ON
                        }
                        else
                        {
                            success = SetOutput(uindex, 0xFFFFFFFF, out resp);     // OFF : Set High
                        }
                    }
                    else Common.SvLogger.Log.Debug("YOIIO ReOpen Fail");
                    if (success)
                        SvMip.Common.SvLogger.Log.Debug("YOIIO Retry Success");
                    else
                        SvMip.Common.SvLogger.Log.Debug("YOIIO Retry Fail");
                }
            }

            if (success)
                gpo[index] = onoff;

            return success;
        }
        public bool SetInValue(int _index, bool _value)
        {
            if (_index < 0 || _index >= GPI.Length) return false;
            GPI[_index] = _value;
            return true;
        }
        public bool GetInValue(int _index)
        {
            if (_index < 0 || _index >= GPI.Length) return false;
            return GPI[_index];
        }
        public bool GetOutValue(int _index)
        {
            if (_index < 0 || _index >= GPO.Length) return false;
            return GPO[_index];
        }
        public bool GetOutIOCehck()
        {
            //DIO는 불필요
            return true;
        }

        public bool IsConnected { get { return isConnected; } }
        bool isConnected;

        public Dictionary<int, bool> InIO { get { return mInIO; } }
        Dictionary<int, bool> mInIO = new Dictionary<int, bool>();

        public Dictionary<int, bool> OutIO { get { return mOutIO; } }
        Dictionary<int, bool> mOutIO = new Dictionary<int, bool>();

    }
}
