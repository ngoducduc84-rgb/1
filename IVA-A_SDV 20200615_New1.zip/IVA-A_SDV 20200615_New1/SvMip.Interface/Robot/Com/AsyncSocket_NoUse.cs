﻿//using OpenCvSharp.CPlusPlus;
//using System;
//using System.Collections.Generic;
//using System.Net;
//using System.Net.NetworkInformation;
//using System.Net.Sockets;
//using System.Threading;

//namespace SvMip.Interface.Com
//{
//    public class StateObject
//    {
//        private const int BUFFER_SIZE = 256;

//        private Socket worker;
//        private byte[] buffer;

//        public StateObject(Socket worker)
//        {
//            this.worker = worker;
//            this.buffer = new byte[BUFFER_SIZE];
//        }

//        public Socket Worker
//        {
//            get { return this.worker; }
//            set { this.worker = value; }
//        }

//        public byte[] Buffer
//        {
//            get { return this.buffer; }
//            set { this.buffer = value; }
//        }

//        public int BufferSize
//        {
//            get { return BUFFER_SIZE; }
//        }
//    } // end of class StateObject

//    /// <summary>
//    /// 비동기 소켓에서 발생한 에러 처리를 위한 이벤트 Argument Class
//    /// </summary>
//    public class AsyncSocketErrorEventArgs : EventArgs
//    {
//        private readonly Exception exception;
//        private readonly int id = 0;

//        public AsyncSocketErrorEventArgs(int id, Exception exception)
//        {
//            this.id = id;
//            this.exception = exception;
//        }

//        public Exception AsyncSocketException
//        {
//            get { return this.exception; }
//        }

//        public int ID
//        {
//            get { return this.id; }
//        }
//    }

//    /// <summary>
//    /// 비동기 소켓의 연결 및 연결해제 이벤트 처리를 위한 Argument Class
//    /// </summary>
//    public class AsyncSocketConnectionEventArgs : EventArgs
//    {
//        private readonly int id = 0;

//        public AsyncSocketConnectionEventArgs(int id)
//        {
//            this.id = id;
//        }

//        public int ID
//        {
//            get { return this.id; }
//        }
//    }

//    /// <summary>
//    /// 비동기 소캣의 데이터 전송 이벤트 처리를 위한 Argument Class
//    /// </summary>
//    public class AsyncSocketSendEventArgs : EventArgs
//    {
//        private readonly int id = 0;
//        private readonly int sendBytes;

//        public AsyncSocketSendEventArgs(int id, int sendBytes)
//        {
//            this.id = id;
//            this.sendBytes = sendBytes;
//        }

//        public int SendBytes
//        {
//            get { return this.sendBytes; }
//        }

//        public int ID
//        {
//            get { return this.id; }
//        }
//    }

//    /// <summary>
//    /// 비동기 소켓의 데이터 수신 이벤트 처리를 위한 Argument Class
//    /// </summary>
//    public class AsyncSocketReceiveEventArgs : EventArgs
//    {
//        private readonly int id = 0;
//        private readonly int receiveBytes;
//        private readonly byte[] receiveData;

//        public AsyncSocketReceiveEventArgs(int id, int receiveBytes, byte[] receiveData)
//        {
//            this.id = id;
//            this.receiveBytes = receiveBytes;
//            this.receiveData = receiveData;
//        }

//        public int ReceiveBytes
//        {
//            get { return this.receiveBytes; }
//        }

//        public byte[] ReceiveData
//        {
//            get { return this.receiveData; }
//        }

//        public int ID
//        {
//            get { return this.id; }
//        }
//    }

//    /// <summary>
//    /// 비동기 서버의 Accept 이벤트를 위한 Argument Class
//    /// </summary>
//    public class AsyncSocketAcceptEventArgs : EventArgs
//    {
//        private readonly Socket client;

//        public AsyncSocketAcceptEventArgs(Socket client)
//        {
//            this.client = client;
//        }

//        public Socket Worker
//        {
//            get { return this.client; }
//        }
//    }

//    ///
//    /// delegate 정의
//    /// 
//    public delegate void AsyncSocketErrorEventHandler(object sender, AsyncSocketErrorEventArgs e);
//    public delegate void AsyncSocketConnectEventHandler(object sender, AsyncSocketConnectionEventArgs e);
//    public delegate void AsyncSocketCloseEventHandler(object sender, AsyncSocketConnectionEventArgs e);
//    public delegate void AsyncSocketSendEventHandler(object sender, AsyncSocketSendEventArgs e);
//    public delegate void AsyncSocketReceiveEventHandler(object sender, AsyncSocketReceiveEventArgs e);
//    public delegate void AsyncSocketAcceptEventHandler(object sender, AsyncSocketAcceptEventArgs e);

//    public class AsyncSocketClass
//    {
//        protected int id;

//        int readByte;
//        public byte[] ReadPacket = new byte[256];
//        public int ReadSize;
//        object socketlock = new object();
//        public byte[] sendPacket = new byte[256];
//        public byte[] rcvPacket = new byte[256];
//        public int[] iBuffer = new int[100]; //received Int data
//        public float[] fBuffer = new float[100]; //received Float data
//        public string[] sBuffer = new string[100]; //received String data

//        // Event Handler
//        public event AsyncSocketErrorEventHandler OnError;
//        public event AsyncSocketConnectEventHandler OnConnet;
//        public event AsyncSocketCloseEventHandler OnClose;
//        public event AsyncSocketSendEventHandler OnSend;
//        public event AsyncSocketReceiveEventHandler OnReceive;
//        public event AsyncSocketAcceptEventHandler OnAccept;

//        public AsyncSocketClass()
//        {
//            this.id = -1;
//        }

//        public AsyncSocketClass(int id)
//        {
//            this.id = id;
//        }

//        public int ID
//        {
//            get { return this.id; }
//        }        

//        protected virtual void ErrorOccured(AsyncSocketErrorEventArgs e)
//        {
//            AsyncSocketErrorEventHandler handler = OnError;

//            if (handler != null)
//                handler(this, e);
//        }

//        protected virtual void Connected(AsyncSocketConnectionEventArgs e)
//        {
//            AsyncSocketConnectEventHandler handler = OnConnet;

//            if (handler != null)
//                handler(this, e);
//        }

//        protected virtual void Closed(AsyncSocketConnectionEventArgs e)
//        {
//            AsyncSocketCloseEventHandler handler = OnClose;

//            if (handler != null)
//                handler(this, e);
//        }

//        protected virtual void Sent(AsyncSocketSendEventArgs e)
//        {
//            AsyncSocketSendEventHandler handler = OnSend;

//            if (handler != null)
//                handler(this, e);
//        }

//        protected virtual void Received(AsyncSocketReceiveEventArgs e)
//        {
//            AsyncSocketReceiveEventHandler handler = OnReceive;

//            if (handler != null)
//                handler(this, e);
//        }

//        protected virtual void Accepted(AsyncSocketAcceptEventArgs e)
//        {
//            AsyncSocketAcceptEventHandler handler = OnAccept;

//            if (handler != null)
//                handler(this, e);
//        }

//        public bool CheckConnected(Socket s, string ipAddress)
//        {

//            //bool b = WriteValue(s, 50, 1);
//            //Thread.Sleep(100);
//            //return b;
//            if (s == null || ipAddress == null) return false;

//            bool ConnectionState = true;

//            // Client가 접속되어 있음.
//            if (s.Connected)
//            {
//                //Do a ping test to see if the server is reachable
//                try
//                {
//                    Ping pingTest = new Ping();
//                    PingReply reply = pingTest.Send(ipAddress);
//                    if (reply.Status != IPStatus.Success) ConnectionState = false;
//                }
//                catch (PingException) { ConnectionState = false; }

//                //See if the tcp state is ok
//                if (s.Poll(5000, SelectMode.SelectRead) && (s.Available == 0)) //에러자주나는데..
//                {
//                    ConnectionState = false;
//                }
//            }
//            // Client 접속이 되지 않지 않음.
//            else
//            {
//                // Server가 Open 되어있으면 Server는 Connect된것으로 간주함.
//                if (s.IsBound) ConnectionState = true;
//                else ConnectionState = false;
//            }

//            return ConnectionState;
//        }

//        public bool WriteValue(Socket s, int index, int value)
//        {
//            int readByte;
//            // WVI : Write Vision Integer
//            sendPacket[0] = (byte)'W';
//            sendPacket[1] = (byte)'V';
//            sendPacket[2] = (byte)'I';

//            if (index < 0 || index > 500)
//                return false;

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4) return false;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            byte[] bValue = BitConverter.GetBytes(value);
//            if (bValue.Length != 4) return false;

//            sendPacket[7] = bValue[3];
//            sendPacket[8] = bValue[2];
//            sendPacket[9] = bValue[1];
//            sendPacket[10] = bValue[0];

//            try { WriteByte(s, sendPacket, 32); }
//            catch { return false; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return false; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (readByte <= 0)
//            {
//                Console.WriteLine("[Interface] ReadByte Error");
//                return false;
//            }

//            if (rcvPacket[0] == 'O')
//                return true;

//            return false;
//        }

//        public bool WriteValue(Socket s, int index, float value)
//        {
//            int readByte;
//            // WVF : Write Vision Float
//            sendPacket[0] = (byte)'W';
//            sendPacket[1] = (byte)'V';
//            sendPacket[2] = (byte)'F';

//            if (index < 1 || index > 500)
//                throw new Exception("index : 1 ~ 500");

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4) return false;
            
//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            byte[] bValue = BitConverter.GetBytes(value);
//            if (bValue.Length != 4) return false;

//            sendPacket[7] = bValue[3];
//            sendPacket[8] = bValue[2];
//            sendPacket[9] = bValue[1];
//            sendPacket[10] = bValue[0];

//            try { WriteByte(s, sendPacket, 32); }
//            catch { return false; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return false; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (rcvPacket[0] == 'O')
//                return true;

//            return false;
//        }

//        public bool WriteValue(Socket s, int index, float x, float y, float z, float roll = 0f, float pitch = 0f, float yaw = 0f)
//        {
//            int readByte;
//            // WVP : Write Vision Position(Single)
//            sendPacket[0] = (byte)'W';
//            sendPacket[1] = (byte)'V';
//            sendPacket[2] = (byte)'P';

//            if (index < 1 || index > 16) throw new Exception("index : 1 ~ 16");

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4) return false;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            byte[] bValue;
//            bValue = BitConverter.GetBytes(x);
//            if (bValue.Length != 4) return false;

//            sendPacket[7] = bValue[3];
//            sendPacket[8] = bValue[2];
//            sendPacket[9] = bValue[1];
//            sendPacket[10] = bValue[0];

//            bValue = BitConverter.GetBytes(y);
//            if (bValue.Length != 4) return false;

//            sendPacket[11] = bValue[3];
//            sendPacket[12] = bValue[2];
//            sendPacket[13] = bValue[1];
//            sendPacket[14] = bValue[0];

//            bValue = BitConverter.GetBytes(z);
//            if (bValue.Length != 4) return false;

//            sendPacket[15] = bValue[3];
//            sendPacket[16] = bValue[2];
//            sendPacket[17] = bValue[1];
//            sendPacket[18] = bValue[0];

//            bValue = BitConverter.GetBytes(roll);
//            if (bValue.Length != 4) return false;

//            sendPacket[19] = bValue[3];
//            sendPacket[20] = bValue[2];
//            sendPacket[21] = bValue[1];
//            sendPacket[22] = bValue[0];

//            bValue = BitConverter.GetBytes(pitch);
//            if (bValue.Length != 4) return false;

//            sendPacket[23] = bValue[3];
//            sendPacket[24] = bValue[2];
//            sendPacket[25] = bValue[1];
//            sendPacket[26] = bValue[0];

//            bValue = BitConverter.GetBytes(yaw);
//            if (bValue.Length != 4) return false;

//            sendPacket[27] = bValue[3];
//            sendPacket[28] = bValue[2];
//            sendPacket[29] = bValue[1];
//            sendPacket[30] = bValue[0];

//            try { WriteByte(s, sendPacket, 32); }
//            catch { return false; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return false; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (rcvPacket[0] == 'O') return true;

//            return false;
//        }

//        public bool WriteValues(Socket s, int index, float[] listPosition)
//        {
//            int readByte;
//            // WPS : Write vision PositionS(Block)
//            sendPacket[0] = (byte)'W';
//            sendPacket[1] = (byte)'P';
//            sendPacket[2] = (byte)'S';

//            if (listPosition.Length > 16 * 3) throw new Exception("Length must be less 16");

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4) return false;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            byte[] bValue;

//            for (int i = 0; i < listPosition.Length; i++)
//            {
//                bValue = BitConverter.GetBytes(listPosition[i]);
//                for (int j = 0; j < 4; j++)
//                    sendPacket[4 * i + j + 7] = bValue[3 - j];
//            }

//            try { WriteByte(s, sendPacket, listPosition.Length * 4 + 7); }
//            catch { return false; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return false; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (rcvPacket[0] == 'O') return true;

//            return false;
//        }

//        public bool WriteValue(Socket s, int index, string value)
//        {
//            int readByte;
//            // WVS : Write Vision String
//            sendPacket[0] = (byte)'W';
//            sendPacket[1] = (byte)'V';
//            sendPacket[2] = (byte)'S';

//            if (index < 1 || index > 50)
//                throw new Exception("index : 1 ~ 500");

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4)
//                return false;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            if (value.Length > 249) throw new Exception("value : 1 ~ 255");

//            System.Text.Encoding.ASCII.GetBytes(value, 0, value.Length, sendPacket, 7);

//            try { WriteByte(s, sendPacket, 7 + value.Length); }
//            catch { return false; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return false; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (rcvPacket[0] == 'O') return true;

//            return false;
//        }

//        public bool WriteValue(Socket s, byte value)
//        {
//            sendPacket[0] = value;

//            try { WriteByte(s, sendPacket, 1); }
//            catch { return false; }

//            return true;
//        }
//        public bool WriteValues(Socket s, byte[] value)
//        {
//            try { WriteByte(s, value, value.Length); }
//            catch { return false; }

//            return true;
//        }



//        public int ReadInt(Socket s, int index)
//        {
//            if (index < 0) return int.MinValue;
//            int readByte;
//            // RVI : Read Vision Integer
//            sendPacket[0] = (byte)'R';
//            sendPacket[1] = (byte)'V';
//            sendPacket[2] = (byte)'I';

//            if (index < 0 || index > 500)
//                return int.MinValue;

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4)
//                return int.MinValue;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            try { WriteByte(s, sendPacket, 32); }
//            catch { return int.MinValue; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return int.MinValue; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (readByte != 4) return int.MinValue;

//            int readInt = BitConverter.ToInt32(Reverse(rcvPacket, 0, 4), 0);

//            return readInt;
//        }

//        public float ReadFloat(Socket s, int index)
//        {
//            int readByte;
//            // RVF : Read Vision Float
//            sendPacket[0] = (byte)'R';
//            sendPacket[1] = (byte)'V';
//            sendPacket[2] = (byte)'F';

//            if (index < 1 || index > 500)
//                throw new Exception("index : 1 ~ 500");

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4)
//                return -1;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            try { WriteByte(s, sendPacket, 32); }
//            catch { return -1; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return -1; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (readByte != 4) return -1;

//            float readFloat = BitConverter.ToSingle(Reverse(rcvPacket, 0, 4), 0);

//            return readFloat;
//        }

//        public bool ReadPoint(Socket s, int index, out float x, out float y, out float z, out float roll, out float pitch, out float yaw)
//        {
//            int readByte;

//            x = -1f; y = -1f; z = -1f; roll = -1f; pitch = -1f; yaw = -1;
//            //RVP : Read Vision Position
//            sendPacket[0] = (byte)'R';
//            sendPacket[1] = (byte)'V';
//            sendPacket[2] = (byte)'P';

//            if (index < 1 || index > 16)
//                throw new Exception("index : 1 ~ 16");

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4)
//                return false;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            try { WriteByte(s, sendPacket, 32); }
//            catch { return false; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return false; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (readByte != 24)
//                return false;

//            x = BitConverter.ToSingle(Reverse(rcvPacket, 0, 4), 0);
//            y = BitConverter.ToSingle(Reverse(rcvPacket, 4, 4), 0);
//            z = BitConverter.ToSingle(Reverse(rcvPacket, 8, 4), 0);
//            roll = BitConverter.ToSingle(Reverse(rcvPacket, 12, 4), 0);
//            pitch = BitConverter.ToSingle(Reverse(rcvPacket, 16, 4), 0);
//            yaw = BitConverter.ToSingle(Reverse(rcvPacket, 20, 4), 0);

//            return true;
//        }
//        public bool ReadPoints(Socket s, int index, out float[] listPosition)
//        {
//            int readByte;
//            listPosition = new float[20 * 3];
//            // WPS : Write vision PositionS(Block)
//            sendPacket[0] = (byte)'R';
//            sendPacket[1] = (byte)'P';
//            sendPacket[2] = (byte)'S';

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4) return false;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            try { WriteByte(s, sendPacket, 32); }
//            catch { return false; }
//            Thread.Sleep(10);

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return false; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            if (readByte > 60 * 4)
//                return false;

//            for (int i = 0; i < readByte / 4; i++)
//            {
//                listPosition[i] = BitConverter.ToSingle(Reverse(rcvPacket, i * 4, 4), 0);
//            }

//            return true;
//        }
//        public string ReadString(Socket s, int index)
//        {
//            sendPacket[0] = (byte)'R';
//            sendPacket[1] = (byte)'V';
//            sendPacket[2] = (byte)'S';

//            if (index < 1 || index > 50)
//                throw new Exception("index : 1 ~ 500");

//            byte[] bIndex = BitConverter.GetBytes(index);
//            if (bIndex.Length != 4)
//                return null;

//            sendPacket[3] = bIndex[3];
//            sendPacket[4] = bIndex[2];
//            sendPacket[5] = bIndex[1];
//            sendPacket[6] = bIndex[0];

//            WriteByte(s, sendPacket, 32);
//            Thread.Sleep(10);

//            string readString = "";

//            try { readByte = ReadByte(s, out rcvPacket); }
//            catch { return readString; }
//            ReadPacket.Initialize();
//            ReadSize = 0;

//            for (int i = 0; i < readByte; i++)
//            {
//                if (rcvPacket[i] == 0)
//                    break;

//                readString += (char)rcvPacket[i];
//            }

//            return readString;
//        }

//        void WriteByte(Socket s, byte[] packet, int size)
//        {
//            lock (socketlock)
//            {
//                try
//                {
//                    int sendByte = s.Send(packet, 0, size, SocketFlags.None);
//                    if (sendByte != size)
//                    {
//                        s.Send(packet, sendByte - 1, packet.Length - sendByte, SocketFlags.None);
//                    }
//                }
//                catch (Exception ex)
//                {
//                    Console.WriteLine(ex.ToString());
//                    throw ex;
//                }
//            }
//        }

//        int ReadByte(Socket s, out byte[] packet)
//        {
//            lock (socketlock)
//            {
//                try
//                {
//                    packet = ReadPacket;
//                    //int readByte = s.Receive(packet);
//                    //return readByte;
//                    return ReadSize;
//                }
//                catch (Exception ex)
//                {
//                    Console.WriteLine(ex.ToString());
//                    throw ex;
//                }
//            }
//        }

//        byte[] Reverse(byte[] packet, int startIndex, int length)
//        {
//            byte[] revByte = new byte[length];
//            int cnt = 0;
//            for (int i = startIndex + length - 1; i >= startIndex; i--)
//            {
//                revByte[cnt++] = packet[i];
//            }
//            return revByte;
//        }

//    } // end of class AsyncSocketClass

//    /// <summary>
//    /// 비동기 소켓
//    /// </summary>
//    public class AsyncSocketClient : AsyncSocketClass
//    {
//        // connection socket
//        private Socket conn = null;
//        const int timeout = 3000;
//        string ipAddress = null;

//        public AsyncSocketClient(int id)
//        {
//            this.id = id;
//        }

//        public AsyncSocketClient(int id, Socket conn)
//        {
//            this.id = id;
//            this.conn = conn;
//        }

//        public Socket Connection
//        {
//            get { return this.conn; }
//            set { this.conn = value; }
//        }

//        public bool IsConnected
//        {
//            get
//            {
//                return CheckConnected(this.conn, this.ipAddress); ;
//            }
//        }

//        /// <summary>
//        /// 연결을 시도한다.
//        /// </summary>
//        /// <param name="ipAddress"></param>
//        /// <param name="port"></param>
//        /// <returns></returns>
//        public bool Connect(string ipAddress, int port)
//        {
//            try
//            {
//                conn = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

//                //conn.ReceiveTimeout = timeout;
//                //conn.SendTimeout = timeout;

//                this.ipAddress = ipAddress;
//                IPAddress[] address = Dns.GetHostAddresses(ipAddress);

//                if (address.Length == 0)
//                {
//                    Console.WriteLine("IP Is Wrong");
//                    return false;
//                }

//                EndPoint endPoint = new IPEndPoint(address[0], port);
//                conn.BeginConnect(endPoint, new AsyncCallback(OnConnectCallback), conn);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);

//                return false;
//            }

//            return true;

//        }

//        public bool Reconnect(string ipAddress, int port)
//        {
//            try
//            {
//                if (!IsConnected)
//                {
//                    conn.Shutdown(SocketShutdown.Both);
//                    conn.Disconnect(true);
//                }
//                conn.Close();

//                conn = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//                conn.ReceiveTimeout = timeout;
//                conn.SendTimeout = timeout;

//                this.ipAddress = ipAddress;
//                IPAddress[] address = Dns.GetHostAddresses(ipAddress);

//                if (address.Length == 0)
//                {
//                    Console.WriteLine("IP Is Wrong");
//                    return false;
//                }

//                EndPoint endPoint = new IPEndPoint(address[0], port);
//                conn.BeginConnect(endPoint, new AsyncCallback(OnConnectCallback), conn);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);
//                ErrorOccured(eev);
//                return false;
//            }
//            return true;
//        }

//        /// <summary>
//        /// 연결 요청 처리 콜백 함수
//        /// </summary>
//        /// <param name="ar"></param>
//        private void OnConnectCallback(IAsyncResult ar)
//        {
//            try
//            {
//                conn = (Socket)ar.AsyncState;

//                // 보류 중인 연결을 완성한다.
//                conn.EndConnect(ar);

//                // 연결에 성공하였다면, 데이터 수신을 대기한다.
//                Receive();

//                // 연결 성공 이벤트를 날린다.
//                AsyncSocketConnectionEventArgs cev = new AsyncSocketConnectionEventArgs(this.id);

//                Connected(cev);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        /// <summary>
//        /// 데이터 수신을 비동기적으로 처리
//        /// </summary>
//        public void Receive()
//        {
//            try
//            {
//                StateObject so = new StateObject(conn);

//                so.Worker.BeginReceive(so.Buffer, 0, so.BufferSize, 0, new AsyncCallback(OnReceiveCallBack), so);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        /// <summary>
//        /// 데이터 수신 처리 콜백 함수
//        /// </summary>
//        /// <param name="ar"></param>
//        private void OnReceiveCallBack(IAsyncResult ar)
//        {
//            try
//            {
//                StateObject so = (StateObject)ar.AsyncState;

//                int bytesRead = so.Worker.EndReceive(ar);

//                AsyncSocketReceiveEventArgs rev = new AsyncSocketReceiveEventArgs(this.id, bytesRead, so.Buffer);

//                // 데이터 수신 이벤트를 처리한다.
//                if (bytesRead > 0)
//                {
//                    Received(rev);
//                    ReadSize = rev.ReceiveBytes;
//                    ReadPacket = rev.ReceiveData;                   
//                }

//                // 다음 읽을 데이터를 처리한다.
//                Receive();
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        /// <summary>
//        /// 데이터 송신을 비동기적으로 처리
//        /// </summary>
//        /// <param name="buffer"></param>
//        /// <returns></returns>
//        public bool Send(byte[] buffer)
//        {
//            try
//            {
//                conn.BeginSend(buffer, 0, buffer.Length, 0, new AsyncCallback(OnSendCallBack), conn);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);

//                return false;
//            }

//            return true;
//        }

//        /// <summary>
//        /// 데이터 송신 처리 콜백 함수
//        /// </summary>
//        /// <param name="ar"></param>
//        private void OnSendCallBack(IAsyncResult ar)
//        {
//            try
//            {
//                conn = (Socket)ar.AsyncState;

//                int bytesWritten = conn.EndSend(ar);

//                AsyncSocketSendEventArgs sev = new AsyncSocketSendEventArgs(this.id, bytesWritten);

//                Sent(sev);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        /// <summary>
//        /// 소켓 연결을 비동기적으로 종료
//        /// </summary>
//        public void Close()
//        {
//            try
//            {
//                conn.Shutdown(SocketShutdown.Both);
//                conn.BeginDisconnect(false, new AsyncCallback(OnCloseCallBack), conn);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        /// <summary>
//        /// 소켓 연결 종료를 처리하는 콜백 함수
//        /// </summary>
//        /// <param name="ar"></param>
//        private void OnCloseCallBack(IAsyncResult ar)
//        {
//            try
//            {
//                conn = (Socket)ar.AsyncState;

//                conn.EndDisconnect(ar);
//                conn.Close();

//                AsyncSocketConnectionEventArgs cev = new AsyncSocketConnectionEventArgs(this.id);

//                Closed(cev);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        public bool WriteValue(int index, int value)
//        {
//            return WriteValue(this.conn, index, value);
//        }

//        public bool WriteValue(int index, float value)
//        {
//            return WriteValue(this.conn, index, value);
//        }

//        public bool WriteValue(int index, float x, float y, float z, float roll = 0f, float pitch = 0f, float yaw = 0f)
//        {
//            return WriteValue(this.conn, index, x, y, z, roll, pitch, yaw);
//        }

//        public bool WriteValues(int index, float[] listPosition)
//        {
//            return WriteValues(this.conn, index, listPosition);
//        }

//        public bool WriteValue(int index, string value)
//        {
//            return WriteValue(this.conn, index, value);
//        }
//        public bool WriteValue(byte value)
//        {
//            return WriteValue(this.conn, value);
//        }
//        public bool WriteValues(byte[] value)
//        {
//            return WriteValues(this.conn, value);
//        }

//        public int ReadInt(int index)
//        {
//            return ReadInt(this.conn, index);
//        }

//        public float ReadFloat(int index)
//        {
//            return ReadFloat(this.conn, index);
//        }

//        public bool ReadPoint(int index, out float x, out float y, out float z, out float roll, out float pitch, out float yaw)
//        {
//            return ReadPoint(this.conn, index, out x, out y, out z, out roll, out pitch, out yaw);
//        }

//        public bool ReadPoints(int index, out float[] listPosition)
//        {
//            return ReadPoints(this.conn, index, out listPosition);
//        }

//        public string ReadString(int index)
//        {
//            return ReadString(this.conn, index);
//        }

//    } // end of class AsyncSocketClient

//    /// <summary>
//    /// 비동기 방식의 서버 
//    /// </summary>
//    public class AsyncSocketServer : AsyncSocketClass
//    {
//        private int port;
//        private Socket listener = null;
//        const int timeout = 2000;
//        private const int backLog = 100;
//        string ipAddress = null;
        
//        public AsyncSocketServer(int port)
//        {
//            this.port = port;
//        }

//        public int Port
//        {
//            get { return this.port; }
//        }

//        public bool IsConnected
//        {
//            get
//            {
//                return CheckConnected(listener, this.ipAddress);
//            }
//        }
        
//        public bool Connect(string ipAddress, int port)
//        {
//            try
//            {
//                this.ipAddress = ipAddress;
//                IPAddress[] address = Dns.GetHostAddresses(ipAddress);

//                if (address.Length == 0)
//                {
//                    Console.WriteLine("IP Is Wrong");
//                    return false;
//                }

//                listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//                //listener.ReceiveTimeout = timeout;
//                //listener.SendTimeout = timeout;

//                EndPoint endPoint = new IPEndPoint(address[0], port);

//                listener.Bind(endPoint);
//                listener.Listen(backLog);

//                StartAccept();
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);
//                ErrorOccured(eev);
//                return false;
//            }
//            return true;
//        }

//        public bool Reconnect(string ipAddress, int port)
//        {
//            try
//            {
//                if (!IsConnected)
//                {
//                    listener.Shutdown(SocketShutdown.Both);
//                    listener.Disconnect(true);
//                }
//                listener.Close();

//                listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//                //listener.ReceiveTimeout = timeout;
//                //listener.SendTimeout = timeout;

//                IPAddress[] address = Dns.GetHostAddresses(ipAddress);

//                if (address.Length == 0)
//                {
//                    Console.WriteLine("IP Is Wrong");
//                    return false;
//                }

//                listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//                listener.ReceiveTimeout = timeout;
//                listener.SendTimeout = timeout;

//                EndPoint endPoint = new IPEndPoint(address[0], port);

//                listener.Bind(endPoint);
//                listener.Listen(backLog);

//                StartAccept();
//            }
//            catch (Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);
//                ErrorOccured(eev);
//                return false;
//            }
//            return true;
//        }

//        /// <summary>
//        /// Client의 접속을 비동기적으로 대기한다.
//        /// </summary>
//        /// <returns></returns>
//        private void StartAccept()
//        {
//            try
//            {
//                listener.BeginAccept(new AsyncCallback(OnListenCallBack), listener);
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        /// <summary>
//        /// Client의 비동기 접속을 처리한다.
//        /// </summary>
//        /// <param name="ar"></param>
//        private void OnListenCallBack(IAsyncResult ar)
//        {
//            try
//            {
//                Socket listener = (Socket)ar.AsyncState;
//                Socket worker = listener.EndAccept(ar);

//                // Client를 Accept 했다고 Event를 발생시킨다.
//                AsyncSocketAcceptEventArgs aev = new AsyncSocketAcceptEventArgs(worker);

//                Accepted(aev);

//                // 다시 새로운 클라이언트의 접속을 기다린다.
//                StartAccept();
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        public void Stop()
//        {
//            try
//            {
//                if (listener != null)
//                {
//                    if (listener.IsBound)
//                        listener.Close(100);
//                }
//            }
//            catch (System.Exception e)
//            {
//                AsyncSocketErrorEventArgs eev = new AsyncSocketErrorEventArgs(this.id, e);

//                ErrorOccured(eev);
//            }
//        }

//        public bool WriteValue(int index, int value)
//        {
//            return WriteValue(listener, index, value);
//        }

//        public bool WriteValue(int index, float value)
//        {
//            return WriteValue(listener, index, value);
//        }

//        public bool WriteValue(int index, float x, float y, float z, float roll = 0f, float pitch = 0f, float yaw = 0f)
//        {
//            return WriteValue(listener, index, x, y, z, roll, pitch, yaw);
//        }

//        public bool WriteValues(int index, float[] listPosition)
//        {
//            return WriteValues(listener, index, listPosition);
//        }

//        public bool WriteValue(byte value)
//        {
//            return WriteValue(listener, value);
//        }
//        public bool WriteValues(byte[] value)
//        {
//            return WriteValues(listener, value);
//        }
//        public bool WriteValue(int index, string value)
//        {
//            return WriteValue(listener, index, value);
//        }

//        public int ReadInt(int index)
//        {
//            return ReadInt(listener, index);
//        }

//        public float ReadFloat(int index)
//        {
//            return ReadFloat(listener, index);
//        }

//        public bool ReadPoint(int index, out float x, out float y, out float z, out float roll, out float pitch, out float yaw)
//        {
//            return ReadPoint(listener, index, out x, out y, out z, out roll, out pitch, out yaw);
//        }
//        public bool ReadPoints(int index, out float[] listPosition)
//        {
//            return ReadPoints(listener, index, out listPosition);
//        }
//        public string ReadString(int index)
//        {
//            return ReadString(listener, index);
//        }
//    } // end of class AsyncSocketServer
//}
