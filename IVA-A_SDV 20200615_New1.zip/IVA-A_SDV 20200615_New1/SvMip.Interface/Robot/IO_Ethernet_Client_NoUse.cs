﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;

//namespace SvMip.Interface
//{
//    public class IO_Ethernet_Client : Robot_Ethernet_Client, IIO, IRobotDevice
//    {
//        //Thread mReadThread, mWriteThread;
//        //bool mThreadFlag = false;

//        int mWriteStartAddress;
//        int mWriteWordSize;
//        int mReadStartAddress;
//        int mReadWordSize;
//        string mDeviceType;

//        public Dictionary<int, bool> InIO { get { return mInIO; } }
//        Dictionary<int, bool> mInIO = new Dictionary<int, bool>();

//        public Dictionary<int, bool> OutIO { get { return mOutIO; } }
//        Dictionary<int, bool> mOutIO = new Dictionary<int, bool>();



//        //public int InAddress { get { return mReadStartAddress; } set { mReadStartAddress = value; } }
//        //public int InLength { get { return mReadWordSize; } set { mReadWordSize = value; InIO = new bool[value]; } }
//        //public int OutAddress { get { return mWriteStartAddress; } set { mWriteStartAddress = value; } }
//        //public int OutLength { get { return mWriteWordSize; } set { mWriteWordSize = value; OutIO = new bool[value]; } }
//        //public bool IsConnected { get { return ; } }

//        public IO_Ethernet_Client(string _ip, int _port)
//            : base(_ip, _port)
//        {
//            //mWriteStartAddress = _writeStartAddress;
//            //OutLength = _writeWordSize;
//            //mReadStartAddress = _readStartAddress;
//            //InLength = _readWordSize;
//            //OutIO = new bool[_writeWordSize];
//            //InIO = new bool[_readWordSize];
//        }

//        public void ThreadStart()
//        {
//            //if (mThreadFlag)
//            //{
//            //    ThreadStop();
//            //    Thread.Sleep(100);
//            //}
//            //mThreadFlag = true;
//            //mReadThread = new Thread(new ThreadStart(GetBlockData));
//            //mReadThread.Start();
//            //mWriteThread = new Thread(new ThreadStart(SetBlockData));
//            //mWriteThread.Start();
//        }

//        public void ThreadStop()
//        {
//            //mThreadFlag = false;

//            //if (mReadThread != null)
//            //{
//            //    //mReadThread.Abort();
//            //    mReadThread.Join();
//            //}
//            //if (mWriteThread != null)
//            //{
//            //    //mWriteThread.Abort();
//            //    mWriteThread.Join();
//            //}
//        }
//        public bool SetOutValue(int _index, bool _value)
//        {
//            if (_index < 0) return false;
//            mOutIO[_index] = _value;
//            WriteValue(_index, Convert.ToInt32(_value));
//            return true;
//        }

//        public bool SetInValue(int _index, bool _value)
//        {
//            if (_index < 0) return false;
//            mInIO[_index] = _value;
//            //WriteValue(_index, Convert.ToInt32(_value));
//            return true;
//        }

//        public bool GetInValue(int _index)
//        {
//            if (_index < 0) return false;
//            return mInIO[_index];
//        }

//        public bool GetOutValue(int _index)
//        {
//            if (_index < 0) return false;
//            return mOutIO[_index];
//        }
//        void GetBlockData()
//        {
//            //while (mThreadFlag)
//            //{
//            //    if (base.socket == null) continue;

//            //    int[] iii = mInIO.Keys.ToArray();

//            //    for (int index = 0; index < mInIO.Count; index++)
//            //    {
//            //        int value;
//            //        base.ReadValue(iii[index], out value);
//            //        mInIO[iii[index]] = value > 0 ? true : false;
//            //    }
//            //    Thread.Sleep(10);
//            //}
//        }

//        void SetBlockData()
//        {
//            //while (mThreadFlag)
//            //{
//            //    if (base.socket == null) continue;
//            //    for (int i = mWriteStartAddress; i < mWriteStartAddress + mWriteWordSize; i++)
//            //    {
//            //        int value = OutIO[i - mWriteStartAddress] == true ? 1 : 0;
//            //        base.WriteValue(i, value);
//            //    }
//            //    Thread.Sleep(10);
//            //}
//        }

//        public new void Dispose()
//        {
//            ThreadStop();
//        }

//    }
//}
