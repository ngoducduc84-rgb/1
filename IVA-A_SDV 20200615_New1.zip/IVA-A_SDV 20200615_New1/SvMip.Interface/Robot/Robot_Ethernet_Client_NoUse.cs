﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Timers;
//using SvMip.Interface.Com;
//using SvMip.Common;
//using OpenCvSharp.CPlusPlus;

//namespace SvMip.Interface
//{
//    public class Robot_Ethernet_Client : IRobotDevice
//    {
//        public enum CalIndex { CAM = 401, MOVE = 402, INIT = 403, END = 404, CALPOSMOVE = 406 }
//        public enum PointIndex { CAM1_ORIGIN = 1, CAM1_OFFSET = 2, CAM2_ORIGIN = 3, CAM2_OFFSET = 4, CAL_OFFSET = 5 }
//        public enum Signal { TURE = 1, FALSE = 0 }

//        protected AsyncSocketClient socket;
//        System.Timers.Timer heartBeatTimer;

//        bool isOpen = false;
//        public bool IsOpen { get { return isOpen; } }

//        object interfaceLock = new object();

//        public static string defaultIp = "192.168.1.8";
        
//        protected string ip;
//        protected int port = 48952;
//        protected int GPNo;
//        const int timeout = 20000;
//        public bool[] InIO = new bool[16];
//        public bool[] OutIO = new bool[16];

//        public Robot_Ethernet_Client() { }

//        public bool IsConnected { get { if (socket == null) return false; return socket.IsConnected; } }        

//        public Robot_Ethernet_Client(string ip, int port)
//        {
//            socket = new AsyncSocketClient(0);

//            // 이벤트 핸들러 재정의
//            socket.OnConnet += new AsyncSocketConnectEventHandler(OnConnet);
//            socket.OnClose += new AsyncSocketCloseEventHandler(OnClose);
//            socket.OnSend += new AsyncSocketSendEventHandler(OnSend);
//            socket.OnReceive += new AsyncSocketReceiveEventHandler(OnReceive);
//            socket.OnError += new AsyncSocketErrorEventHandler(OnError);

//            if (ip.Count(f => f == '.') != 3)
//            {
//                System.Diagnostics.Debug.WriteLine("[Interface]Parameter MisMatching : ip must have three '.'");
//                return;
//            }
//            this.ip = ip;
//            this.port = port;

//            if (!OpenDevice())
//            {
//                SvLogger.Log.Error("[Interface] Ethernet Port Open Fail");
//            }
//        }

//        public void setIp(string RobotIP)
//        {
//            ip = RobotIP;
//        }

//        public bool OpenDevice()
//        {
//#if !SIMULATION
//            isOpen = true;
//            if (!socket.IsConnected)
//            {
//                if (!socket.Connect(ip, port))
//                {
//                    isOpen = false;
//                    SvLogger.Log.Error("[Interface] Socket Open Fail");
//                }
//            }

//            if (heartBeatTimer != null)
//            {
//                heartBeatTimer.Stop();
//                heartBeatTimer.Dispose();
//                heartBeatTimer = null;
//            }

//            heartBeatTimer = new System.Timers.Timer(3000);
//            heartBeatTimer.Elapsed += heartBeatTimer_Elapsed;
//            heartBeatTimer.Start();
            
//            return true;
//#endif
//        }

//        void heartBeatTimer_Elapsed(object sender, ElapsedEventArgs e)
//        {
//            lock (interfaceLock)
//            {
//                isOpen = socket.IsConnected;
//            }
//            if (!isOpen)
//            {
//                if (!socket.Reconnect(ip, port))
//                    SvLogger.Log.Error("[Interface] Socket Open Fail");
//                else
//                    SvLogger.Log.Error("[Interface] Socket ReConnect Success");
//            }
//        }

//        static int CDM_CMD_SIZE = 3;

//        string GetCommand(byte[] rcvPacket)
//        {
//            string strTemp = null;

//            for (int i = 0; i < CDM_CMD_SIZE; i++)
//            {
//                if (rcvPacket[i] == 0)
//                    break;

//                strTemp += (char)rcvPacket[i];
//            }

//            return strTemp;
//        }

//        private void OnConnet(object sender, AsyncSocketConnectionEventArgs e)
//        {
//            System.Diagnostics.Debug.WriteLine("[Interface]" + "HOST -> PC: Connected ID: " + e.ID.ToString() + "\n");
//        }

//        private void OnClose(object sender, AsyncSocketConnectionEventArgs e)
//        {
//            System.Diagnostics.Debug.WriteLine("[Interface]" + "HOST -> PC: Closed ID: " + e.ID.ToString() + "\n");
//        }

//        private void OnSend(object sender, AsyncSocketSendEventArgs e)
//        {
//            System.Diagnostics.Debug.WriteLine("[Interface]" + "PC -> HOST: Send ID: " + e.ID.ToString() + " Bytes sent: " + e.SendBytes.ToString() + "\n");
//        }

//        private void OnReceive(object sender, AsyncSocketReceiveEventArgs e)
//        {
//            byte bResult = (byte)'O';
//            int index = 0;
//            int iValue = 0;
//            float fValue = 0.3f;
//            string sValue = "";
//            float[] fValues = new float[60];

//            switch (GetCommand(e.ReceiveData))
//            {
//                // Write Value Int : 특정 index에 Int 값을 저장 또는 처리
//                case "WVI":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    iValue = BitConverter.ToInt32(Reverse(e.ReceiveData, 7, 4), 0);
//                    socket.iBuffer[index] = iValue;

//                    /////////////[Issue]업체에서 사용시 In, Out IO가 혼란이 생기는것을 방지하려면 하기 코드를 수정하면 됨///////////////////////

//                    // Vision 사용 코드
//                    if (index < 16)
//                        InIO[index] = Convert.ToBoolean(iValue);
//                    else if (index > 16 && index < 32)
//                        OutIO[index - 16] = Convert.ToBoolean(iValue);

//                    // 업체 사용 코드
//                    //if (index > 16 && index < 32)
//                    //    InIO[index - 16] = Convert.ToBoolean(iValue);
//                    //else if (index < 16)
//                    //    OutIO[index] = Convert.ToBoolean(iValue);

//                    socket.WriteValue(bResult);
//                    break;

//                // Write Value Float : 특정 index에 Float 값을 저장 또는 처리
//                case "WVF":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    fValue = BitConverter.ToSingle(Reverse(e.ReceiveData, 7, 4), 0);
//                    socket.fBuffer[index] = fValue;
//                    socket.WriteValue(bResult);
//                    break;

//                // Write Value Position : 특정 index에 X, Y, T 1EA 좌표값을 저장 또는 처리
//                case "WVP":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    for (int i = 0; i < 6; i++)
//                    {
//                        fValue = BitConverter.ToSingle(Reverse(e.ReceiveData, 7 + (i * 4), 4), 0);
//                        socket.fBuffer[index + i] = fValue;
//                    }
//                    socket.WriteValue(bResult);
//                    break;

//                // 여러개의 Write Position 값들을 처리 : 특정 index에 X, Y, T 여러개의 좌표값들을 저장 또는 처리
//                case "WPS": //position data 처리
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    for (int i = 0; i < 60; i++)
//                    {
//                        socket.fBuffer[index + i] = BitConverter.ToSingle(Reverse(e.ReceiveData, 7 + (i * 4), 4), 0);

//                    }
//                    socket.WriteValue(bResult);
//                    break;

//                // Write Value String : 특정 index에 String 값을 저장 또는 처리
//                case "WVS":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    for (int i = 7; i < e.ReceiveData.Length; i++)
//                    {
//                        if (e.ReceiveData[i] == 0)
//                            break;

//                        sValue += (char)e.ReceiveData[i];
//                    }
//                    socket.sBuffer[index] = sValue;
//                    socket.WriteValue(bResult);
//                    break;

//                // Read Value Int : 특정 index의 Int 값을 반환
//                case "RVI":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    iValue = socket.iBuffer[index];
//                    byte[] bint = Reverse(BitConverter.GetBytes(iValue), 0, 4);
//                    socket.WriteValues(bint);
//                    break;

//                // Read Value Float : 특정 index의 Float 값을 반환
//                case "RVF":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    fValue = socket.fBuffer[index];
//                    byte[] bfloat = Reverse(BitConverter.GetBytes(fValue), 0, 4);
//                    socket.WriteValues(bfloat);
//                    break;

//                // Read Value Position : 특정 index에 X, Y, T 1EA 좌표값을 반환
//                case "RVP":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    byte[] bfloats = new byte[4 * 6];
//                    for (int i = 0; i < 6; i++)
//                    {
//                        fValue = socket.fBuffer[index + i];
//                        byte[] btmp = Reverse(BitConverter.GetBytes(fValue), 0, 4);
//                        for (int j = 0; j < 4; j++)
//                        {
//                            bfloats[i * 4 + j] = btmp[j];
//                        }
//                    }
//                    socket.WriteValues(bfloats);
//                    break;

//                // Read Value String : 특정 index에 String값을 반환
//                case "RVS":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    sValue = socket.sBuffer[index];
//                    byte[] bstring = new byte[256];
//                    if (socket.sBuffer[index] == null)
//                        sValue = "";
//                    System.Text.Encoding.ASCII.GetBytes(sValue, 0, sValue.Length, bstring, 0);
//                    socket.WriteValues(bstring);
//                    break;

//                // 여러개의 Read Position 값들을 반환 : 특정 index에 X, Y, T 여러개의 좌표값들을 반환
//                case "RPS":
//                    index = BitConverter.ToInt32(Reverse(e.ReceiveData, 3, 4), 0);
//                    byte[] bpoints = new byte[4 * 60];
//                    for (int i = 0; i < fValues.Length; i++)
//                    {
//                        fValues[i] = socket.fBuffer[index + i];
//                        byte[] btmp = Reverse(BitConverter.GetBytes(fValues[i]), 0, 4);
//                        for (int j = 0; j < 4; j++)
//                        {
//                            bpoints[i * 4 + j] = btmp[j];
//                        }
//                    }
//                    socket.WriteValues(bpoints);
//                    break;
//            }
//        }

//        private void OnError(object sender, AsyncSocketErrorEventArgs e)
//        {
//            System.Diagnostics.Debug.WriteLine("[Interface]" + "HOST -> PC: Error ID: " + e.ID.ToString() + " Error Message: " + e.AsyncSocketException.ToString() + "\n");
//        }

//        public bool StartCalibration(int GPNo)
//        {
//            this.GPNo = GPNo;
//            bool robotSuccess = true;
//            robotSuccess &= WriteValue((int)CalIndex.CAM, GPNo);
//            robotSuccess &= WriteValue((int)CalIndex.MOVE, (int)Signal.FALSE); // Initialize Move Signal
//            robotSuccess &= WriteValue((int)CalIndex.INIT, (int)Signal.FALSE); // Initialize Init Signal
//            robotSuccess &= WriteValue((int)CalIndex.END, (int)Signal.FALSE); // Initialize End Signal
//            robotSuccess &= WritePosition((int)PointIndex.CAL_OFFSET, 0f, 0f, 0f);

//            robotSuccess &= MoveStart((int)CalIndex.INIT);
//            return robotSuccess;
//        }

//        public bool StartCalPosMove(int GPNo)
//        {
//            bool robotSuccess = true;
//            robotSuccess &= WriteValue((int)CalIndex.CAM, GPNo);
//            robotSuccess &= WriteValue((int)CalIndex.MOVE, (int)Signal.FALSE); // Initialize Move Signal
//            robotSuccess &= WriteValue((int)CalIndex.INIT, (int)Signal.FALSE); // Initialize Init Signal
//            robotSuccess &= WriteValue((int)CalIndex.END, (int)Signal.FALSE); // Initialize End Signal
//            robotSuccess &= WritePosition((int)PointIndex.CAL_OFFSET, 0f, 0f, 0f);

//            robotSuccess &= WriteValue((int)CalIndex.CALPOSMOVE, (int)(GPNo + 1));
//            robotSuccess &= MoveStart((int)CalIndex.MOVE);
//            return robotSuccess;
//        }

//        public bool EndCalibration()
//        {
//            //StartCalPosMove(this.GPNo);
//            return WriteValue((int)CalIndex.END, (int)Signal.TURE);
//        }

//        public bool MoveCalibration()
//        {
//            return MoveStart((int)CalIndex.MOVE);
//        }

//        public bool WriteCalOffset(float x, float y, float w)
//        {
//            bool robotSuccess = WritePosition((int)PointIndex.CAL_OFFSET, x, y, w);
//            return robotSuccess;
//        }

//        public string ReadCurrentJobName()
//        {
//            string currentJobName;
//            ReadValue(1, out currentJobName);
//            return currentJobName;
//        }

//        public List<RobotJob> ReadJobList()
//        {
//            string jobNameList;
//            if(!ReadValue(2, out jobNameList)) return null;
                                    
//            List<RobotJob> list = new List<RobotJob>();
            
//            string[] jobNames = jobNameList.Split(';');
//            foreach(string jobName in jobNames)
//            {
//                RobotJob job = new RobotJob();
//                job.name = jobName;
//                list.Add(job);
//            }

//            return list;
//        }

//        public bool WritePosition(int index, float x, float y, float w)
//        {
//            return WritePosition(index, x, y, 0f, w, 0f, 0f);
//        }

//        public bool WritePosition(int index, float x, float y, float z, float roll, float pitch, float yaw)
//        {
//            lock (interfaceLock)
//            {
//                try
//                {
//                    bool success = socket.WriteValue(index, x, y, z, roll, pitch, yaw);

//                    if (!success)
//                        throw new Exception("Communication Timeout");

//                    return true;

//                }
//                catch (Exception ex)
//                {
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//        }

//        public bool ReadPosition(int index, out float x, out float y, out float w)
//        {
//            float z, pitch, yaw;
//            return ReadPosition(index, out x, out y, out z, out w, out pitch, out yaw);
//        }

//        public bool ReadPosition(int index, out float x, out float y, out float z, out float roll, out float pitch, out float yaw)
//        {
//            x = y = z = roll = pitch = yaw = -1f;
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    bool success = socket.ReadPoint(index, out x, out y, out z, out roll, out pitch, out yaw);

//                    if (!success)
//                        throw new Exception("Communication Error");

//                    return true;
//                }
//                catch (Exception ex)
//                {
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//#else
//            return true;
//#endif
//        }

//        public bool ReadCurrentPosition(out float x, out float y, out float w)
//        {
//            throw new NotImplementedException();
//            //float z, pitch, yaw;
//            //return ReadCurrentPosition(9, out x, out y, out z, out w, out pitch, out yaw);
//        }

//        public bool WriteValue(int index, int value)
//        {
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    //value = index;
//                    bool b = socket.WriteValue(index, value);
//                    return b;
//                }
//                catch (System.Reflection.TargetInvocationException ex)
//                {
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//#else
//            return true;
//#endif
//        }

//        public bool WriteValue(int index, float value)
//        {
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    return socket.WriteValue(index, value);
//                }
//                catch (System.Reflection.TargetInvocationException ex)
//                {
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//#else
//            return true;
//#endif
//        }

//        public bool WriteValue(int index, string value)
//        {
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    return socket.WriteValue(index, value);
//                }
//                catch (System.Reflection.TargetInvocationException ex)
//                {
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//#else
//            return true;
//#endif
//        }

//        public bool ReadValue(int index, out int value)
//        {
//            value = 0;
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    value = socket.ReadInt(index);

//                    if (value == int.MinValue)
//                        return false;// throw new Exception("Communication Timeout");

//                    return true;
//                }
//                catch (System.Reflection.TargetInvocationException ex)
//                {
//                    value = 0;
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//#else
//            value = 0;
//            return true;
//#endif
//        }

//        public bool ReadValue(int index, out float value)
//        {
//            value = 0;
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    value = socket.ReadFloat(index);

//                    if (value == -1)
//                        throw new Exception("Communication Timeout");

//                    return true;
//                }
//                catch (System.Reflection.TargetInvocationException ex)
//                {
//                    value = 0;
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//#else
//            value = 0;
//            return true;
//#endif
//        }

//        public bool ReadValue(int index, out string value)
//        {
//            value = null;
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    value = socket.ReadString(index);

//                    if (string.IsNullOrEmpty(value))
//                        throw new Exception("Communication Timeout");

//                    return true;
//                }
//                catch (System.Reflection.TargetInvocationException ex)
//                {
//                    value = null;
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//                catch
//                {
//                    return false;
//                }
//            }
//            return false;
//#else
//            value = 0;
//            return true;
//#endif
//        }

//        public bool MoveStart(int index, bool isWait = true)
//        {
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    bool success = socket.WriteValue(index, 1);
                    
//                    if (!success)
//                        throw new Exception("Communication Timeout");

//                    if (!isWait)
//                        return true;

//                    int signal;

//                    DateTime startTime = DateTime.Now;
                    
//                    // Wait Robot Move Complete
//                    while (true)
//                    {
//                        signal = socket.ReadInt(index);
//                        if (signal == int.MinValue)
//                            throw new Exception("Communication Timeout");
//                        else if (signal != 1)
//                            break;

//                        if (DateTime.Now.Subtract(startTime).TotalMilliseconds > timeout)
//                        {
//                            System.Diagnostics.Debug.WriteLine("[Interface] Move Timeout");
//                            SvLogger.Log.Error("[Interface] Move Timeout");
//                            return false;
//                        }
//                    }
//                    return true;

//                }
//                catch (Exception ex)
//                {
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//#else            
//            return true;
//#endif
//        }

//        public bool CloseDevice()
//        {
//            Dispose();
//            return true;
//        }

//        public void Dispose()
//        {
//            if (heartBeatTimer != null)
//            {
//                heartBeatTimer.Stop();
//                heartBeatTimer.Dispose();
//                heartBeatTimer = null;
//            }

//            if (socket != null )
//            {
//                if (socket.IsConnected)
//                {
//                    socket.Close();
//                    SvLogger.Log.Error("[Interface] Socket Disconnect");
//                }
//            }
//        }


//        public bool WritePositions(int index, List<Point3f> listPosition)
//        {
//            lock (interfaceLock)
//            {
//                try
//                {
//                    float[] tempTwoWord = new float[listPosition.Count * 3];

//                    for (int i = 0; i < listPosition.Count; i++)
//                    {
//                        tempTwoWord[i * 3 + 0] = listPosition[i].X;
//                        tempTwoWord[i * 3 + 1] = listPosition[i].Y;
//                        tempTwoWord[i * 3 + 2] = listPosition[i].Z;
//                    }
//                    return socket.WriteValues(index, tempTwoWord);
//                }
//                catch (System.Reflection.TargetInvocationException ex)
//                {
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//        }
//        public bool ReadPositions(int index, out List<Point3f> listPosition)
//        {
//            listPosition = new List<Point3f>();
//            float[] fPositions;
//            Point3f tmpPt = new Point3f();
//            lock (interfaceLock)
//            {
//                try
//                {
//                    bool bsuccess = socket.ReadPoints(index, out fPositions);

//                    if (!bsuccess)
//                        return false;// throw new Exception("Communication Timeout");
//                    for (int i = 0; i < fPositions.Length; i++)
//                    {
//                        switch (i % 3)
//                        {
//                            case 0:
//                                tmpPt.X = fPositions[i];
//                                break;
//                            case 1:
//                                tmpPt.Y = fPositions[i];
//                                break;
//                            case 2:
//                                tmpPt.Z = fPositions[i];
//                                listPosition.Add(tmpPt);
//                                break;
//                        }
//                    }
//                    return true;
//                }
//                catch (System.Reflection.TargetInvocationException ex)
//                {
//                    listPosition.Clear();
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//        }

//        byte[] Reverse(byte[] packet, int startIndex, int length)
//        {
//            byte[] revByte = new byte[length];
//            int cnt = 0;
//            for (int i = startIndex + length - 1; i >= startIndex; i--)
//            {
//                revByte[cnt++] = packet[i];
//            }
//            return revByte;
//        }
//    }
//}
