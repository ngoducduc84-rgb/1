﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using SvMip.Interface.Com;
using SvMip.Common;
using OpenCvSharp.CPlusPlus;
using System.Threading;

namespace SvMip.Interface
{
    //기존 Robot_EOTech -> RobotNachi 로 변경_18.05.28
    public class Robot_Nachi: Robot_Ethernet_Client
    {
        public Robot_Nachi(string ip, int port, int _sleep)
            : base(ip, port, _sleep)
        {
        }

//        // calibration
//        public override  bool StartCalibration(int GPNo)
//        {
//            this.GPNo = GPNo;
//            bool robotSuccess = true;
//            robotSuccess &= WriteValue((int)CalIndex.CAM, GPNo);
//            Thread.Sleep(100);
//            robotSuccess &= WriteValue((int)CalIndex.MOVE, (int)Signal.FALSE); // Initialize Move Signal
//            Thread.Sleep(100);
//            robotSuccess &= WriteValue((int)CalIndex.INIT, (int)Signal.FALSE); // Initialize Init Signal
//            Thread.Sleep(100);
//            robotSuccess &= WriteValue((int)CalIndex.END, (int)Signal.FALSE); // Initialize End Signal
//            Thread.Sleep(100);
//            robotSuccess &= WritePosition((int)PointIndex.CAL_OFFSET, 0f, 0f, 0f);
//            Thread.Sleep(100);

//            robotSuccess &= MoveStart((int)CalIndex.INIT);
//            return robotSuccess;
//        }

//        public override bool MoveStart(int index, bool isWait = true)
//        {
//#if !SIMULATION
//            lock (interfaceLock)
//            {
//                try
//                {
//                    bool success = socket.WriteValue(index, 1);

//                    if (!success)
//                        throw new Exception("Communication Timeout");

//                    if (!isWait)
//                        return true;

//                    int signal;
//                    Thread.Sleep(500);
//                    DateTime startTime = DateTime.Now;

//                    // Wait Robot Move Complete
//                    while (true)
//                    {
//                        signal = socket.ReadInt(index);
//                        if (signal == int.MinValue)
//                            throw new Exception("Communication Timeout");
//                        else if (signal != 1)
//                            break;

//                        if (DateTime.Now.Subtract(startTime).TotalMilliseconds > timeout)
//                        {
//                            System.Diagnostics.Debug.WriteLine("[Interface] Move Timeout");
//                            SvLogger.Log.Error("[Interface] Move Timeout");
//                            return false;
//                        }
//                        Thread.Sleep(100);
//                    }
//                    return true;

//                }
//                catch (Exception ex)
//                {
//                    System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
//                    SvLogger.Log.Error("[Interface] " + ex.Message);
//                }
//            }
//            return false;
//#else            
//            return true;
//#endif
//        }

        public override bool WritePositions(int index, List<Point3f> listPosition)
        {
            //lock (interfaceLock)
            //{
            //    float[] tempTwoWord = new float[listPosition.Count * 3];

            //    for (int i = 0; i < listPosition.Count; i++)
            //    {
            //        tempTwoWord[i * 3 + 0] = listPosition[i].X;
            //        tempTwoWord[i * 3 + 1] = listPosition[i].Y;
            //        tempTwoWord[i * 3 + 2] = listPosition[i].Z;
            //    }
            //    return socket.WriteValues(index, tempTwoWord);
            //}

            lock (interfaceLock)
            {
                bool b = true;
                for (int i = 0; i < listPosition.Count; i++)
                {
                    b &= WritePosition(index + i, listPosition[i].X, listPosition[i].Y, listPosition[i].Z);
                }
                return b;
            }

        }
    }
}
