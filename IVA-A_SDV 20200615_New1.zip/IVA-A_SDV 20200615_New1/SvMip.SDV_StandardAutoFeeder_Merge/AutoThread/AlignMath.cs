﻿using System;
using OpenCvSharp.CPlusPlus;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Stateless align math shared by the AutoThread classes
    /// (and later by AutoThread_Direct). No I/O, no logging, no instance state.
    /// Behaviour is identical to the former AutoThread_Base members.
    /// </summary>
    public static class AlignMath
    {
        public const double PI = Math.PI;
        public const double Rad = PI / 180;

        /// <summary>
        /// Normalize an angle (rad) into the (-45deg, +45deg] range used for 90deg-symmetric parts.
        /// Legacy code wrote "3 / 2 * Math.PI"; integer division makes that exactly Math.PI,
        /// so the same value is used here.
        /// </summary>
        public static double NormalizeTheta(double rad)
        {
            double nomalrad = rad + Math.PI;
            while (nomalrad > Math.PI / 4)
            {
                nomalrad -= Math.PI / 2;
            }
            return nomalrad;
        }

        /// <summary>
        /// target + R(theta) * offset. The offset is expressed in the part frame
        /// (X,Y in length units, Z in degrees).
        /// </summary>
        public static Point3d ApplyTargetOffset(Point3d point, Point3d offset)
        {
            Point3d applyP = new Point3d();
            applyP.Z = point.Z + offset.Z * Rad;
            double T = applyP.Z;
            applyP.X = point.X + Math.Cos(T) * offset.X - Math.Sin(T) * offset.Y;
            applyP.Y = point.Y + Math.Sin(T) * offset.X + Math.Cos(T) * offset.Y;

            return applyP;
        }

        /// <summary>
        /// Check one result point against the robot limits.
        /// When several axes violate, the message of the last violating axis (X, then Y, then T) is returned,
        /// exactly as the legacy CheckLimit did.
        /// </summary>
        public static bool CheckPointLimit(Point3f p, float xMin, float xMax, float yMin, float yMax, float tMin, float tMax, out string msg)
        {
            bool ok = true;
            msg = "";

            if (p.X < xMin || p.X > xMax)
            {
                if (p.X < xMin)
                    msg = string.Format("X MIN Limit NG : {0:f3}(Spec : {1:f3})", p.X, xMin);
                else
                    msg = string.Format("X MAX Limit NG : {0:f3}(Spec : {1:f3})", p.X, xMax);
                ok = false;
            }

            if (p.Y < yMin || p.Y > yMax)
            {
                if (p.Y < yMin)
                    msg = string.Format("Y MIN Limit NG : {0:f3}(Spec : {1:f3})", p.Y, yMin);
                else
                    msg = string.Format("Y MAX Limit NG : {0:f3}(Spec : {1:f3})", p.Y, yMax);
                ok = false;
            }

            if (p.Z < tMin || p.Z > tMax)
            {
                if (p.Z < tMin)
                    msg = string.Format("T MIN Limit NG : {0:f3}(Spec : {1:f3})", p.Z, tMin);
                else
                    msg = string.Format("T MAX Limit NG : {0:f3}(Spec : {1:f3})", p.Z, tMax);
                ok = false;
            }

            return ok;
        }
    }
}
