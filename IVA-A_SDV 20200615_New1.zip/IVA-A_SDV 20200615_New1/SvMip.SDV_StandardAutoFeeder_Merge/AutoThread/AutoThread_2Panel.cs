﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public class AutoThread_2Panel : AutoThread_Base
    {
        public AutoThread_2Panel(SystemData _system, RecipeData _recipe, Main.Process _process) : base(_system, _recipe, _process)
        {
            
        }

        public override bool Do_InitJob()
        {
            try
            {
                SetDisplayToolOn(typeof(SvTemplateMatch), 0);
                SetDisplayToolOn(typeof(SvIntersectLine), 0);
                SetDisplayToolOn(typeof(SvIntersectLine), 1);
                SetDisplayToolOn(typeof(SvFindLine), 0);
                SetDisplayToolOn(typeof(SvFindLine), 1);
                SetDisplayToolOn(typeof(SvFindLine), 2);
                SetDisplayToolOn(typeof(SvMakePoint), 0);

                SetResultPoint(typeof(SvMakePoint), 0, "OutPoint");
                return true;
            }
            catch
            {
                return false;
            }
        }

        public override bool Do_CheckVisionJob(SvJob _job)
        {
            SvRegion region = mAlignResult.JobInfo[typeof(SvRegion)][0].Toolbase as SvRegion;
            SvToolBlock toolblock = mAlignResult.JobInfo[typeof(SvToolBlock)][0].Toolbase as SvToolBlock;

            int countX = region.Count_X;
            int countY = region.Count_Y;

            bool visionResult = true;

            for (int i = 0; i < countX; i++)
            {
                for (int j = 0; j < countY; j++)
                {
                    region.Index_X = i;
                    region.Index_Y = j;

                    SvJob job = null;

                    if (i == 0 && j == 0)
                        job = mJob;
                    else
                        job = toolblock.ToolJob;

                    visionResult &= CheckVisionJob(job);
                }
            }

            return visionResult;
        }

        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                
                SvCalibration cal = mRobotData.Calibrations;

                for (int i = 0; i < mAlignResult.ResultParams.Count; i++)
                {
                    mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultParams[i] as SvPoint).Point3d);
                    //int k = i * countY + j;
                    mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d - mRobotData.AlignOffsets[i].Point3d);
                    mAlignResult.TargetRobotPoint.Add(cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true));

                    // Offset 계산
                    Point3d offsetedTarget = ApplyTargetOffset(mAlignResult.TargetRobotPoint[i], mRobotData.AlignOffsets[i].Point3d);
                    mAlignResult.TargetRevPoint.Add(cal.RToT(mRobotData.LoadPosition[i].Point3d, offsetedTarget));
                }
                return true;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }

        public override bool Do_Judgement()
        {
            ErrorMessage = "";
            bool b = CheckLimit();
            return b;
        }
    }
}
