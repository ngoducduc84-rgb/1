﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Barcode reading용
    /// </summary>
    public class AutoThread_Barcode : AutoThread_Base
    {
        public AutoThread_Barcode(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {
        
        }

        public override bool Do_InitJob()
        {
            bool initOK = true;

            initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), 0, 0);
            initOK &= SetDisplayToolOn(typeof(SvRotation), 0, 0);
            initOK &= SetDisplayToolOn(typeof(SvRegion), 0, 0);
            initOK &= SetDisplayToolOn(typeof(SvBarcode), 0, 0);

            initOK &= SetResultPoint(typeof(SvBarcode), 0, 0, "ReadingResult");

            return initOK;
        }

        // run jobs
        public override bool Do_CheckVisionJob()
        {
            bool visionResult = true;

            mJob.Run();

            visionResult &= CheckVisionJob(mJob, 0);

            return visionResult;
        }

        // calcutate robot offset position
        public override bool Do_ExecuteAlignCalc()
        {
            // no align
            return true;
        }

        public override bool Do_Judgement()
        {
            // check existence
            bool judgeOk = true;
            bool needcheck = false;

            // Barcode 결과값 저장
            mAlignResult.strBarcode = "";
            SvBarcode barcode = mAlignResult.JobInfo[0][typeof(SvBarcode)][0].Toolbase as SvBarcode;
            mAlignResult.strBarcode = barcode.ReadingResult;

            if(!barcode.lastRunSuccess)
            {
                needcheck = true;
                judgeOk = false;
            }

            //매뉴얼 창에서 사용자 결정 반영
            if (needcheck && mProcData.UseManualAlign)
            {
                // Manual Mode 추가 할 것
                // judgeOk = Do_ManualCheck();
            }

            // display 변경 : Barcode 값 보여주기
            SvAcquisition acq = mJob["Acquisition"] as SvAcquisition;
            mUpdateDisplayCode.Clear();
            mUpdateDisplayCode.Add(new Action(() =>
            {
                ViewModel.Edit.Display.GraphicsFuncCollection.Clear();
                ViewModel.Edit.Display.Image = acq.AcqusitionImage;
            }));

            // Barcode 위치 
            SvRegion region = mAlignResult.JobInfo[0][typeof(SvRegion)][0].Toolbase as SvRegion;
            SvTemplateMatch templete = mAlignResult.JobInfo[0][typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;

            // display
            string sJudge = barcode.lastRunSuccess ? "OK" : "NG";
            sJudge += string.Format(" : {0}", mAlignResult.strBarcode);

            System.Drawing.Color color = judgeOk ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Red;
            System.Drawing.Pen pen = new System.Drawing.Pen(color);
            pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);

            SvRectangle rect = region.OutputImage.RegionRect;
            System.Drawing.PointF pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);

            mUpdateDisplayCode.Add(new Action(() =>
            {
                ViewModel.Edit.Display.DrawPolyLines(pen, templete.ResultBox);
                ViewModel.Edit.Display.DrawString(sJudge, font16, brush, pnt);
                //ViewModel.Edit.Display.DrawRectangle(pen, rect.RectF);
            }));

            return judgeOk;
        }

        public override bool Do_ManualCheck()
        {
            bool isOk = true;
            SequenceLog("ManualInspection Start", Common.SvLogger.LogType.SEQUENCE);
            mIO.SetOutValue(mSystem.OPCallBit, true, false);//set op-call bit

            /*
             * Manual Mode 추가 할 것
             */
            //////////////////////////////////////////////////////////////////////////////////////////////////////
            mManualAlignDispatcher.Invoke(() =>
            {
                ManualInspection wnd = new ManualInspection();
                wnd.InitWnd(mAlignResult, mJob, mIO, mProcData.IOParam.Inputs[InSignal.Complete.ToString()]);
                isOk = wnd.ShowDialog() == true;
            });
            //////////////////////////////////////////////////////////////////////////////////////////////////////

            mIO.SetOutValue(mSystem.OPCallBit, false, false);//reset op-call bit
            SequenceLog("ManualAlign End", Common.SvLogger.LogType.SEQUENCE);
            return isOk;
        }

        public override bool Do_WriteResult()
        {
            // exist

            bool sendresult = mRobot.WriteValue(mOffsetAddr, mAlignResult.strBarcode);

            SequenceLog(mAlignResult.strBarcode, Common.SvLogger.LogType.DATA);

            return sendresult;
        }

        public override bool Do_WriteJudgement()
        {
            string msg;
            if (mAlignResult.IsJudgeOK)
            {
                msg = "JUDGE OK";
                ViewModel.Judge1 = true;
                mIO.SetOutValue(OutAddr[OutSignal.OK.ToString()], true);
            }
            else
            {
                msg = "JUDGE NG";
                ViewModel.Judge1 = false;
                mIO.SetOutValue(OutAddr[OutSignal.NG.ToString()], true);
            }
            SequenceLog(msg, Common.SvLogger.LogType.SEQUENCE);
            return true;
        }
    }
}
