﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Generic AutoThread driven only by the tools of the job:
    ///   SvTrigger / SvConnection  -> handshake and connection (applied by JobConfigBridge)
    ///   SvAlign                   -> vision points to robot corrections (same math as the legacy threads)
    ///   SvSend                    -> what is written to the PLC / robot at the end of the cycle
    /// A job without SvAlign / SvSend simply runs the tools and reports OK / NG.
    /// </summary>
    public class AutoThread_Direct : AutoThread_Base
    {
        List<SvToolBase> mAllTools = new List<SvToolBase>();
        SvAlign mAlign;
        List<SvSend> mSends = new List<SvSend>();
        SvCalibration mCalibration;
        bool mAlignOK = true;
        bool mDirectJudgeOK = false;
        bool mDryRun = false;

        // request - response trigger (SvTrigger in Tcp mode)
        SvTrigger mTrigger;
        readonly StringBuilder mRxText = new StringBuilder();
        readonly List<string> mRequests = new List<string>();
        string mRequest = "";
        bool mReplySent = true;
        DateTime mLastOpenTry = DateTime.MinValue;
        bool mTriggerConfigLogged = false;
        string mCmd = "";
        SvSend mCurSend;              // the SvSend that is being written (@v1..@v12 refer to it)
        bool mAlignCmd = true;        // false: the command only runs the tools (hand-eye, get master ...), no align / SvSend
        string mToolReply = null;     // reply set by a tool of the job (SvHandEye / SvMaster)
        string mCalSaved = null;
        bool mJobChanged = false;

        static AutoThread_Direct()
        {
            SvCalibrationService.Install();
        }

        public AutoThread_Direct(SystemData _system, RecipeData _recipe, Main.Process _process) : base(_system, _recipe, _process)
        {
        }

        // ------------------------------------------------------------------ init
        public override bool Do_InitJob()
        {
            mAllTools = new List<SvToolBase>();
            JobConfigBridge.Collect(mJob, mAllTools, 0);
            mAlign = null;
            mTrigger = null;
            mSends = new List<SvSend>();
            foreach (SvToolBase t in mAllTools)
            {
                SvAlign a = t as SvAlign;
                if (a != null && mAlign == null) { mAlign = a; continue; }
                SvSend s = t as SvSend;
                if (s != null) mSends.Add(s);
                SvTrigger trg = t as SvTrigger;
                if (trg != null && mTrigger == null) mTrigger = trg;
            }

            mRequests.Clear();
            mRxText.Length = 0;
            mRequest = "";
            mCmd = "";
            mAlignCmd = true;
            mReplySent = true;
            mTriggerConfigLogged = false;

            mCalibration = null;
            if (mAlign != null && !string.IsNullOrEmpty(mAlign.CalibrationFile))
            {
                try
                {
                    string path = Path.Combine(Main.CalibPath, mAlign.CalibrationFile);
                    SvCalibration cal = new SvCalibration();
                    cal.CalData = (new SvSerializer()).LoadCalibration(path);
                    mCalibration = cal;
                }
                catch (Exception ex)
                {
                    SequenceLog("[SvAlign] calibration load failed: " + ex.Message, Common.SvLogger.LogType.ERROR);
                }
            }

            string problem;
            if (mAlign != null && (problem = mAlign.Validate()) != "")
                SequenceLog("[SvAlign] " + problem, Common.SvLogger.LogType.ERROR);
            foreach (SvSend s in mSends)
            {
                if ((problem = s.Validate()) != "")
                    SequenceLog("[SvSend] " + problem, Common.SvLogger.LogType.ERROR);
            }

            return SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");
        }

        // ------------------------------------------------------------------ vision
        public override bool Do_CheckVisionJob()
        {
            mToolReply = null;
            mCalSaved = null;
            mJobChanged = false;
            bool tcp = IsTcpTrigger;
            if (tcp) SvRuntime.SetRequest(mRequest, mTrigger.Separator);
            try
            {
                mJob.Run();
                if (tcp)
                {
                    mToolReply = SvRuntime.TakeReply();
                    mCalSaved = SvRuntime.TakeCalibrationSaved();
                    mJobChanged = SvRuntime.TakeJobChanged();
                }
            }
            finally
            {
                SvRuntime.ClearRequest();
            }
            return CheckVisionJob(mJob, 0);
        }

        // ------------------------------------------------------------------ align
        SvCalibration GetCalibration()
        {
            if (mAlign != null && !string.IsNullOrEmpty(mAlign.CalibrationFile)) return mCalibration;
            return mRobotData.Calibrations;
        }

        public override bool Do_ExecuteAlignCalc()
        {
            mAlignOK = true;
            try
            {
                if (!mAlignCmd) return true;
                if (mAlign == null || mAlign.Points.Count == 0) return true;

                SvCalibration cal = GetCalibration();
                if (cal == null)
                {
                    SequenceLog("[SvAlign] no calibration available", Common.SvLogger.LogType.ERROR);
                    mAlignOK = false;
                    return false;
                }

                for (int i = 0; i < mAlign.Points.Count; i++)
                {
                    SvAlignPoint ap = mAlign.Points[i];
                    Point3d objRobot = new Point3d(ap.LoadX, ap.LoadY, ap.LoadT * Math.PI / 180);
                    mAlignResult.ObjectRobotPoint.Add(objRobot);

                    Point3d pix = new Point3d();
                    bool got = false;
                    object src;
                    string err;
                    if (ResolveValue(ap.Source, out src, out err))
                    {
                        got = DirectPath.TryToPoint3d(src, out pix);
                        if (!got) err = "source is not a point";
                    }
                    if (!got)
                    {
                        SequenceLog(string.Format("[SvAlign] point {0} ({1}): {2}", i + 1, ap.Name, err), Common.SvLogger.LogType.ERROR);
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        mAlignResult.TargetRobotPoint.Add(new Point3d());
                        mAlignResult.TargetRevPoint.Add(new Point3d());
                        mAlignResult.SendPoint.Add(new Point3f(mAlign.NgX, mAlign.NgY, mAlign.NgT));
                        mAlignOK = false;
                        continue;
                    }

                    mAlignResult.TargetPixelPoint.Add(pix);
                    Point3d targetRobot = cal.VtoR(pix, true, true);
                    targetRobot.Z = NormalizeTheta(targetRobot.Z);
                    mAlignResult.TargetRobotPoint.Add(targetRobot);

                    Point3d offsetedTarget = ApplyTargetOffset(targetRobot, new Point3d(ap.OffsetX, ap.OffsetY, ap.OffsetT));
                    if (cal.RotCenter.X == 0 && cal.RotCenter.Y == 0) // no T axis: only X, Y are corrected
                        offsetedTarget.Z = objRobot.Z;
                    Point3d rev = cal.RToT(objRobot, offsetedTarget);
                    mAlignResult.TargetRevPoint.Add(rev);
                    mAlignResult.SendPoint.Add(new Point3f((float)rev.X, (float)rev.Y, (float)(rev.Z * 180 / Math.PI)));
                }
                return mAlignOK;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                mAlignOK = false;
                return false;
            }
        }

        // ------------------------------------------------------------------ judgement
        public override bool Do_Judgement()
        {
            bool limitOK = true;
            try
            {
                if (mAlignCmd && mAlign != null && mAlign.UseLimit && mAlignResult.IsVisionOK && mAlignOK)
                {
                    for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
                    {
                        string msg;
                        if (!AlignMath.CheckPointLimit(mAlignResult.SendPoint[i], mAlign.XMin, mAlign.XMax, mAlign.YMin, mAlign.YMax, mAlign.TMin, mAlign.TMax, out msg))
                        {
                            SequenceLog(string.Format("[SvAlign] point {0}: {1}", i + 1, msg), Common.SvLogger.LogType.ERROR);
                            limitOK = false;
                        }
                    }
                }

                mDirectJudgeOK = mAlignResult.IsVisionOK && mAlignOK && limitOK;

                if (!mDirectJudgeOK && mAlign != null && mAlignCmd)
                {
                    // like the legacy threads: on NG the NG values are sent instead of a correction
                    for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
                        mAlignResult.SendPoint[i] = new Point3f(mAlign.NgX, mAlign.NgY, mAlign.NgT);
                }
            }
            catch (Exception ex)
            {
                SequenceLog("Judgement Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                mDirectJudgeOK = false;
            }
            return mDirectJudgeOK;
        }

        public override bool Do_ManualCheck()
        {
            return true;
        }

        // ------------------------------------------------------------------ sources
        static readonly Regex AlignRegex = new Regex(@"^@align\[(\d+)\]\.(x|y|t)$", RegexOptions.IgnoreCase);
        static readonly Regex VRegex = new Regex(@"^@v(\d+)$", RegexOptions.IgnoreCase);
        static readonly Regex RequestRegex = new Regex(@"^@request\[(\d+)\]$", RegexOptions.IgnoreCase);

        bool ResolveValue(string path, out object value, out string error)
        {
            value = null;
            error = "";
            if (string.IsNullOrEmpty(path))
            {
                error = "empty source";
                return false;
            }
            path = path.Trim();
            if (path[0] != '@')
                return DirectPath.TryGetToolValue(mAllTools, path, out value, out error);

            string key = path.ToLowerInvariant();
            switch (key)
            {
                case "@judge": value = mDirectJudgeOK; return true;
                case "@vision": value = mAlignResult.IsVisionOK; return true;
                case "@cellid": value = (cells.Count > 0) ? string.Join("", cells) : ""; return true;
                case "@recipe": value = Auto.mCurrentRecipeName; return true;
                case "@job": value = mJob.Name; return true;
                case "@time": value = DateTime.Now.ToString("yyyyMMdd_HHmmss"); return true;
                case "@request": value = mRequest; return true;
                case "@cmd":
                case "@command": value = mCmd; return true;
            }

            Match rq = RequestRegex.Match(path);
            if (rq.Success)
            {
                int ti = int.Parse(rq.Groups[1].Value);
                string[] tokens = SvRuntime.SplitRequest(mRequest, mTrigger != null ? mTrigger.Separator : ",");
                if (ti >= tokens.Length)
                {
                    error = "the request has no part " + ti + " (0 is the command)";
                    return false;
                }
                value = tokens[ti].Trim();
                return true;
            }

            Match vm = VRegex.Match(path);
            if (vm.Success)
            {
                int vn = int.Parse(vm.Groups[1].Value);
                SvSend vs = mCurSend ?? (mSends.Count > 0 ? mSends[0] : null);
                if (vs == null || !vs.TryGetValue("v" + vn, out value))
                {
                    error = "input v" + vn + " of SvSend is empty (link it or type a value)";
                    return false;
                }
                return true;
            }

            Match m = AlignRegex.Match(path);
            if (m.Success)
            {
                int idx = int.Parse(m.Groups[1].Value);
                if (idx >= mAlignResult.SendPoint.Count)
                {
                    error = "no align result with index " + idx;
                    return false;
                }
                Point3f p = mAlignResult.SendPoint[idx];
                string axis = m.Groups[2].Value.ToLowerInvariant();
                value = (axis == "x") ? p.X : (axis == "y") ? p.Y : p.Z;
                return true;
            }

            error = "unknown special source '" + path + "'";
            return false;
        }

        // ------------------------------------------------------------------ send
        class PendingValue
        {
            public int Address;
            public SvSendValueType Type;
            public double Number;
            public string Text;
        }

        bool EvalField(SvSendChannel ch, SvSendField f, out double number, out string text)
        {
            number = 0;
            text = "";
            object v;
            string err;
            if (!ResolveValue(f.Source, out v, out err))
            {
                SequenceLog(string.Format("[SvSend] {0}/{1}: {2}", ch.Name, f.Name, err), Common.SvLogger.LogType.ERROR);
                return false;
            }
            if (f.ValueType == SvSendValueType.Text)
            {
                text = Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture);
                return true;
            }
            double d;
            if (!DirectPath.TryToDouble(v, out d))
            {
                SequenceLog(string.Format("[SvSend] {0}/{1}: value is not a number", ch.Name, f.Name), Common.SvLogger.LogType.ERROR);
                return false;
            }
            number = d * f.Scale + f.Offset;
            if (double.IsNaN(number) || double.IsInfinity(number))
            {
                SequenceLog(string.Format("[SvSend] {0}/{1}: value is not finite", ch.Name, f.Name), Common.SvLogger.LogType.ERROR);
                return false;
            }
            if (f.UseRange && (number < f.Min || number > f.Max))
            {
                SequenceLog(string.Format("[SvSend] {0}/{1}: {2:f3} is outside [{3:f3}, {4:f3}]", ch.Name, f.Name, number, f.Min, f.Max), Common.SvLogger.LogType.ERROR);
                return false;
            }
            return true;
        }

        bool WriteOffsetsChannel(SvSendChannel ch)
        {
            if (mAlignResult.SendPoint.Count == 0) return true;
            if (mDryRun)
            {
                for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
                    SequenceLog(string.Format("[SvSend dry-run] {0} #{1}: ({2:f3}, {3:f3}, {4:f3})", ch.Name, i + 1, mAlignResult.SendPoint[i].X, mAlignResult.SendPoint[i].Y, mAlignResult.SendPoint[i].Z), Common.SvLogger.LogType.DATA);
                return true;
            }
            int addr = (ch.StartIndex >= 0) ? ch.StartIndex : mOffsetAddr;
            if (addr < 0)
            {
                SequenceLog(string.Format("[SvSend] {0}: no offset address (set StartIndex or SvTrigger offset start)", ch.Name), Common.SvLogger.LogType.ERROR);
                return false;
            }
            return WriteRevOffset(addr, new List<Point3f>(mAlignResult.SendPoint));
        }

        bool WritePositionChannel(SvSendChannel ch)
        {
            if (ch.Fields.Count == 0 || ch.Fields.Count % 3 != 0 || ch.StartIndex < 0)
            {
                SequenceLog(string.Format("[SvSend] {0}: Position needs a start index and fields in groups of 3", ch.Name), Common.SvLogger.LogType.ERROR);
                return false;
            }
            int groups = ch.Fields.Count / 3;
            List<Point3f> values = new List<Point3f>();
            for (int g = 0; g < groups; g++)
            {
                double x, y, t;
                string txt;
                if (!EvalField(ch, ch.Fields[g * 3], out x, out txt)) return false;
                if (!EvalField(ch, ch.Fields[g * 3 + 1], out y, out txt)) return false;
                if (!EvalField(ch, ch.Fields[g * 3 + 2], out t, out txt)) return false;
                values.Add(new Point3f((float)x, (float)y, (float)t));
            }
            if (mDryRun)
            {
                for (int g = 0; g < groups; g++)
                    SequenceLog(string.Format("[SvSend dry-run] {0} #{1}: ({2:f3}, {3:f3}, {4:f3})", ch.Name, g + 1, values[g].X, values[g].Y, values[g].Z), Common.SvLogger.LogType.DATA);
                return true;
            }
            bool ok = true;
            for (int g = 0; g < groups; g++)
            {
                SequenceLog(string.Format("[SvSend] {0} #{1}: ({2:f3}, {3:f3}, {4:f3})", ch.Name, g + 1, values[g].X, values[g].Y, values[g].Z), Common.SvLogger.LogType.DATA);
                ok &= mRobot.WritePosition(ch.StartIndex + g, values[g].X, values[g].Y, values[g].Z);
            }
            return ok;
        }

        bool WriteValuesChannel(SvSendChannel ch)
        {
            if (ch.Fields.Count == 0 || ch.StartIndex < 0)
            {
                SequenceLog(string.Format("[SvSend] {0}: Values needs a start index and at least one field", ch.Name), Common.SvLogger.LogType.ERROR);
                return false;
            }
            List<PendingValue> pending = new List<PendingValue>();
            foreach (SvSendField f in ch.Fields)
            {
                PendingValue pv = new PendingValue();
                pv.Address = ch.StartIndex + f.Address;
                pv.Type = f.ValueType;
                if (!EvalField(ch, f, out pv.Number, out pv.Text)) return false;
                pending.Add(pv);
            }
            if (mDryRun)
            {
                foreach (PendingValue pv in pending)
                    SequenceLog(string.Format("[SvSend dry-run] {0} @{1}: {2}", ch.Name, pv.Address, (pv.Type == SvSendValueType.Text) ? pv.Text : pv.Number.ToString("0.###")), Common.SvLogger.LogType.DATA);
                return true;
            }
            bool ok = true;
            foreach (PendingValue pv in pending)
            {
                switch (pv.Type)
                {
                    case SvSendValueType.Float:
                        ok &= mRobot.WriteValue(pv.Address, (float)pv.Number);
                        break;
                    case SvSendValueType.Int32:
                        ok &= mRobot.WriteValue(pv.Address, (int)Math.Round(pv.Number));
                        break;
                    case SvSendValueType.Int16:
                        ok &= mRobot.WriteValue(pv.Address, (short)Math.Round(pv.Number));
                        break;
                    default:
                        ok &= mRobot.WriteValue(pv.Address, pv.Text);
                        break;
                }
            }
            return ok;
        }

        // ------------------------------------------------------------------ stream connections (Text / Registers)
        SvConnection FindConnection(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            foreach (SvToolBase t in mAllTools)
            {
                SvConnection c = t as SvConnection;
                if (c != null && string.Equals(c.ConnName, name, StringComparison.OrdinalIgnoreCase)) return c;
            }
            return null;
        }

        bool WriteTextChannel(SvSendChannel ch)
        {
            SvConnection conn = FindConnection(ch.Connection);
            if (conn == null || !SvConnection.IsStreamType(conn.ConnType) || conn.ConnType == SvConnType.ModbusTcp)
            {
                SequenceLog(string.Format("[SvSend] {0}: connection '{1}' is not a TCP / UDP / Serial connection of this job", ch.Name, ch.Connection), Common.SvLogger.LogType.ERROR);
                return false;
            }

            Dictionary<string, object> values = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            if (mCurSend != null)
            {
                // {name}: the inputs of the SvSend (linked outputs or typed values)
                foreach (SvSendInput row in mCurSend.Inputs)
                {
                    object ov;
                    if (!mCurSend.TryGetValue(row.Name, out ov)) continue;
                    double dv;
                    if (ov is string) values[row.Name] = ov;
                    else if (DirectPath.TryToDouble(ov, out dv)) values[row.Name] = dv;
                    else values[row.Name] = Convert.ToString(ov, System.Globalization.CultureInfo.InvariantCulture);
                }
            }
            foreach (SvSendField f in ch.Fields)
            {
                double n;
                string txt;
                if (!EvalField(ch, f, out n, out txt)) return false;
                if (f.ValueType == SvSendValueType.Text) values[f.Name] = txt;
                else values[f.Name] = n;
            }

            string text;
            string ferr;
            if (!SendTemplate.TryFormat(ch.Template, values, out text, out ferr))
            {
                SequenceLog(string.Format("[SvSend] {0}: {1}", ch.Name, ferr), Common.SvLogger.LogType.ERROR);
                return false;
            }

            if (mDryRun)
            {
                SequenceLog(string.Format("[SvSend dry-run] {0} -> {1}: {2}", ch.Name, conn.ConnName, SendTemplate.Visible(text)), Common.SvLogger.LogType.DATA);
                return true;
            }

            byte[] bytes = (conn.TextEncoding == SvTextEncoding.Utf8) ? Encoding.UTF8.GetBytes(text) : Encoding.ASCII.GetBytes(text);
            string err;
            ISendTransport tr = TransportRegistry.Get(conn, out err);
            if (tr == null)
            {
                SequenceLog(string.Format("[SvSend] {0}: {1}", ch.Name, err), Common.SvLogger.LogType.ERROR);
                return false;
            }
            if (!tr.Send(bytes, out err))
            {
                SequenceLog(string.Format("[SvSend] {0}: send to '{1}' failed: {2}", ch.Name, conn.ConnName, err), Common.SvLogger.LogType.ERROR);
                return false;
            }
            SequenceLog(string.Format("[SvSend] {0} -> {1}: {2}", ch.Name, conn.ConnName, SendTemplate.Visible(text)), Common.SvLogger.LogType.DATA);

            if (!string.IsNullOrEmpty(ch.Reply) && !WaitReply(tr, ch.Reply, conn.TimeoutMs, out err))
            {
                SequenceLog(string.Format("[SvSend] {0}: {1}", ch.Name, err), Common.SvLogger.LogType.ERROR);
                return false;
            }
            return true;
        }

        bool WaitReply(ISendTransport tr, string expected, int timeoutMs, out string error)
        {
            error = "";
            if (timeoutMs <= 0) timeoutMs = 1000;
            DateTime end = DateTime.Now.AddMilliseconds(timeoutMs);
            StringBuilder received = new StringBuilder();
            while (DateTime.Now < end)
            {
                int remain = (int)end.Subtract(DateTime.Now).TotalMilliseconds;
                if (remain < 10) remain = 10;
                byte[] data;
                string rerr;
                if (tr.Receive(remain, out data, out rerr))
                {
                    received.Append(Encoding.ASCII.GetString(data));
                    if (received.ToString().IndexOf(expected, StringComparison.Ordinal) >= 0) return true;
                }
                else
                {
                    System.Threading.Thread.Sleep(5);
                }
            }
            error = string.Format("no reply containing '{0}' within {1} ms (received: '{2}')", expected, timeoutMs, SendTemplate.Visible(received.ToString()));
            return false;
        }

        bool WriteRegistersChannel(SvSendChannel ch)
        {
            SvConnection conn = FindConnection(ch.Connection);
            if (conn == null || conn.ConnType != SvConnType.ModbusTcp)
            {
                SequenceLog(string.Format("[SvSend] {0}: connection '{1}' is not a ModbusTcp connection of this job", ch.Name, ch.Connection), Common.SvLogger.LogType.ERROR);
                return false;
            }
            if (ch.Fields.Count == 0 || ch.StartIndex < 0)
            {
                SequenceLog(string.Format("[SvSend] {0}: Registers needs a first register and at least one field", ch.Name), Common.SvLogger.LogType.ERROR);
                return false;
            }

            SortedDictionary<int, ushort> regs = new SortedDictionary<int, ushort>();
            foreach (SvSendField f in ch.Fields)
            {
                double n;
                string txt;
                if (!EvalField(ch, f, out n, out txt)) return false;
                if (f.ValueType == SvSendValueType.Text)
                {
                    SequenceLog(string.Format("[SvSend] {0}/{1}: Text cannot be written to registers", ch.Name, f.Name), Common.SvLogger.LogType.ERROR);
                    return false;
                }
                if (f.ValueType == SvSendValueType.Int16)
                {
                    double r16 = Math.Round(n);
                    if (r16 < short.MinValue || r16 > short.MaxValue)
                    {
                        SequenceLog(string.Format("[SvSend] {0}/{1}: {2} does not fit in 16 bits", ch.Name, f.Name, r16), Common.SvLogger.LogType.ERROR);
                        return false;
                    }
                    regs[f.Address] = unchecked((ushort)(short)r16);
                }
                else
                {
                    uint bits;
                    if (f.ValueType == SvSendValueType.Float)
                    {
                        bits = BitConverter.ToUInt32(BitConverter.GetBytes((float)n), 0);
                    }
                    else
                    {
                        double r32 = Math.Round(n);
                        if (r32 < int.MinValue || r32 > int.MaxValue)
                        {
                            SequenceLog(string.Format("[SvSend] {0}/{1}: {2} does not fit in 32 bits", ch.Name, f.Name, r32), Common.SvLogger.LogType.ERROR);
                            return false;
                        }
                        bits = unchecked((uint)(int)r32);
                    }
                    ushort high = (ushort)(bits >> 16);
                    ushort low = (ushort)(bits & 0xFFFF);
                    if (ch.WordSwap)
                    {
                        regs[f.Address] = low;
                        regs[f.Address + 1] = high;
                    }
                    else
                    {
                        regs[f.Address] = high;
                        regs[f.Address + 1] = low;
                    }
                }
            }

            ModbusTcpTransport modbus = null;
            if (!mDryRun)
            {
                string terr;
                modbus = TransportRegistry.Get(conn, out terr) as ModbusTcpTransport;
                if (modbus == null)
                {
                    SequenceLog(string.Format("[SvSend] {0}: {1}", ch.Name, terr), Common.SvLogger.LogType.ERROR);
                    return false;
                }
            }

            // registers that are next to each other are written together; gaps are never written
            bool ok = true;
            int runFirst = 0;
            int last = int.MinValue;
            List<ushort> run = new List<ushort>();
            foreach (KeyValuePair<int, ushort> kv in regs)
            {
                if (run.Count > 0 && kv.Key != last + 1)
                {
                    ok &= FlushRegisterRun(modbus, conn, ch, runFirst, run);
                    run.Clear();
                }
                if (run.Count == 0) runFirst = kv.Key;
                run.Add(kv.Value);
                last = kv.Key;
            }
            if (run.Count > 0) ok &= FlushRegisterRun(modbus, conn, ch, runFirst, run);
            return ok;
        }

        bool FlushRegisterRun(ModbusTcpTransport modbus, SvConnection conn, SvSendChannel ch, int offset, List<ushort> values)
        {
            int start = ch.StartIndex + offset;
            if (start < 0 || start + values.Count - 1 > 65535)
            {
                SequenceLog(string.Format("[SvSend] {0}: register {1} is outside 0..65535", ch.Name, start), Common.SvLogger.LogType.ERROR);
                return false;
            }
            if (mDryRun)
            {
                StringBuilder sb = new StringBuilder();
                foreach (ushort v in values) sb.Append(v).Append(' ');
                SequenceLog(string.Format("[SvSend dry-run] {0} -> {1}: registers {2}..{3} = {4}", ch.Name, conn.ConnName, start, start + values.Count - 1, sb.ToString().TrimEnd()), Common.SvLogger.LogType.DATA);
                return true;
            }
            string err;
            if (!modbus.WriteRegisters((byte)conn.UnitId, (ushort)start, values.ToArray(), out err))
            {
                SequenceLog(string.Format("[SvSend] {0}: Modbus write of registers {1}..{2} failed: {3}", ch.Name, start, start + values.Count - 1, err), Common.SvLogger.LogType.ERROR);
                return false;
            }
            return true;
        }

        // ------------------------------------------------------------------ request - response trigger (SvTrigger, Tcp mode)
        bool IsTcpTrigger
        {
            get { return mTrigger != null && mTrigger.TriggerMode == SvTriggerMode.Tcp; }
        }

        void SetVirtualBits(bool start, bool complete)
        {
            if (mIO == null) return;
            mIO.SetInValue(InAddr[InSignal.Start.ToString()], start);
            mIO.SetInValue(InAddr[InSignal.Complete.ToString()], complete);
        }

        /// <summary>
        /// A message starts a cycle: Start is set on the internal IO and the normal handshake of the base class runs.
        /// The reply is the acknowledgement: Complete is set when the reply was sent (Do_WriteResult), or here when the cycle failed.
        /// </summary>
        protected override void OnLoopTick()
        {
            if (!IsTcpTrigger) return;
            try
            {
                eStatus st = ViewModel.Status;

                if (st == eStatus.WAIT_ALIGN_START_REQ)
                {
                    SvConnection conn;
                    ISendTransport tr = GetTriggerTransport(out conn);
                    if (tr == null) return;

                    byte[] data;
                    if (tr.Poll(out data)) CollectRequests(data, conn);

                    while (mRequests.Count > 0)
                    {
                        string msg = mRequests[0];
                        mRequests.RemoveAt(0);
                        if (!mTrigger.MatchesStart(msg))
                        {
                            SequenceLog("[Trigger] message ignored: " + SendTemplate.Visible(msg), Common.SvLogger.LogType.SEQUENCE);
                            SendUnknownReply(conn);
                            continue;
                        }
                        mRequest = msg;
                        string[] parts = SvRuntime.SplitRequest(msg, mTrigger.Separator);
                        mCmd = parts.Length > 0 ? parts[0].Trim() : "";
                        mAlignCmd = mTrigger.IsAlignCommand(mCmd);
                        mReplySent = false;
                        SequenceLog("[Trigger] request: " + SendTemplate.Visible(msg), Common.SvLogger.LogType.SEQUENCE);
                        SetVirtualBits(true, false);
                        break;
                    }
                }
                else if (st == eStatus.WAIT_ALIGN_END_ACK || st == eStatus.WAIT_ERROR_RESET_ACK)
                {
                    // normally the reply was already sent by Do_WriteResult; when the cycle failed before that, answer NG now
                    if (!mReplySent) SendTriggerReply(false);
                    SetVirtualBits(false, true);
                }
            }
            catch (Exception ex)
            {
                SequenceLog("[Trigger] exception " + ex, Common.SvLogger.LogType.ERROR);
            }
        }

        void SendUnknownReply(SvConnection conn)
        {
            try
            {
                string text = mTrigger.ReplyUnknown;
                if (string.IsNullOrEmpty(text)) return;
                text = SendTemplate.Unescape(text);
                string term = SendTemplate.Unescape(mTrigger.Terminator);
                if (!string.IsNullOrEmpty(term) && !text.EndsWith(term, StringComparison.Ordinal)) text += term;
                byte[] bytes = (conn.TextEncoding == SvTextEncoding.Utf8) ? Encoding.UTF8.GetBytes(text) : Encoding.ASCII.GetBytes(text);
                string err;
                ISendTransport tr = TransportRegistry.Get(conn, out err);
                if (tr != null) tr.Send(bytes, out err);
            }
            catch (Exception) { }
        }

        /// <summary>What the tools asked for during the cycle: a new calibration file is loaded, a changed job is saved.</summary>
        void AfterToolActions()
        {
            try
            {
                if (!string.IsNullOrEmpty(mCalSaved) && mAlign != null && string.Equals(mCalSaved, mAlign.CalibrationFile, StringComparison.OrdinalIgnoreCase))
                {
                    SvCalibration cal = new SvCalibration();
                    cal.CalData = (new SvSerializer()).LoadCalibration(SvRuntime.FullCalibrationPath(mCalSaved));
                    mCalibration = cal;
                    SequenceLog("[HandEye] calibration '" + mCalSaved + "' reloaded", Common.SvLogger.LogType.SEQUENCE);
                }
                mCalSaved = null;

                if (mJobChanged)
                {
                    mJobChanged = false;
                    string name = mJob.Name;
                    if (!string.IsNullOrEmpty(name))
                    {
                        if (!name.EndsWith(".job", StringComparison.OrdinalIgnoreCase)) name += ".job";
                        string path = Path.Combine(Main.JobPath, name);
                        try
                        {
                            if (File.Exists(path)) File.Copy(path, path + ".bak", true);
                        }
                        catch (Exception) { }
                        if ((new SvSerializer()).SaveJob(mJob, path)) SequenceLog("[Master] job saved: " + path, Common.SvLogger.LogType.SEQUENCE);
                        else SequenceLog("[Master] job NOT saved: " + path, Common.SvLogger.LogType.ERROR);
                    }
                }
            }
            catch (Exception ex)
            {
                SequenceLog("[Trigger] after-tool actions: " + ex.Message, Common.SvLogger.LogType.ERROR);
            }
        }

        /// <summary>The transport of the trigger connection; opens it when needed (at most once per second).</summary>
        ISendTransport GetTriggerTransport(out SvConnection conn)
        {
            conn = FindConnection(mTrigger.ConnectionName);
            if (conn == null || !SvConnection.IsStreamType(conn.ConnType) || conn.ConnType == SvConnType.ModbusTcp)
            {
                if (!mTriggerConfigLogged)
                {
                    mTriggerConfigLogged = true;
                    SequenceLog(string.Format("[Trigger] connection '{0}' is not a TcpServer / TcpClient / Udp / Serial connection of this job", mTrigger.ConnectionName), Common.SvLogger.LogType.ERROR);
                }
                return null;
            }
            string err;
            ISendTransport tr = TransportRegistry.Get(conn, out err);
            if (tr == null)
            {
                if (!mTriggerConfigLogged)
                {
                    mTriggerConfigLogged = true;
                    SequenceLog("[Trigger] " + err, Common.SvLogger.LogType.ERROR);
                }
                return null;
            }
            if (!tr.IsOpen && DateTime.Now.Subtract(mLastOpenTry).TotalMilliseconds >= 1000)
            {
                mLastOpenTry = DateTime.Now;
                if (!tr.Open(out err))
                    SequenceLog(string.Format("[Trigger] cannot open '{0}': {1}", conn.ConnName, err), Common.SvLogger.LogType.ERROR);
            }
            return tr;
        }

        /// <summary>Splits the received text into messages (by the terminator) and queues them.</summary>
        void CollectRequests(byte[] data, SvConnection conn)
        {
            string chunk = ((conn.TextEncoding == SvTextEncoding.Utf8) ? Encoding.UTF8 : Encoding.ASCII).GetString(data);
            string term = SendTemplate.Unescape(mTrigger.Terminator);
            if (string.IsNullOrEmpty(term))
            {
                string one = chunk.Trim();
                if (one.Length > 0) mRequests.Add(one);
                return;
            }

            mRxText.Append(chunk);
            string all = mRxText.ToString();
            int start = 0;
            int pos;
            while ((pos = all.IndexOf(term, start, StringComparison.Ordinal)) >= 0)
            {
                string msg = all.Substring(start, pos - start).Trim();
                if (msg.Length > 0) mRequests.Add(msg);
                start = pos + term.Length;
            }
            mRxText.Length = 0;
            if (start < all.Length) mRxText.Append(all.Substring(start));
            if (mRxText.Length > 4096) mRxText.Length = 0; // a sender that never sends the terminator
        }

        /// <summary>Sends the automatic reply (ReplyOk / ReplyNg of the SvTrigger) on the trigger connection.</summary>
        bool SendTriggerReply(bool ok)
        {
            mReplySent = true;
            string template = ok ? mTrigger.ReplyOk : mTrigger.ReplyNg;
            string toolReply = mToolReply;
            mToolReply = null;
            if (string.IsNullOrEmpty(template) && string.IsNullOrEmpty(toolReply)) return true;

            SvConnection conn = FindConnection(mTrigger.ConnectionName);
            if (conn == null || !SvConnection.IsStreamType(conn.ConnType) || conn.ConnType == SvConnType.ModbusTcp)
            {
                SequenceLog(string.Format("[Trigger] cannot reply: connection '{0}' is not usable", mTrigger.ConnectionName), Common.SvLogger.LogType.ERROR);
                return false;
            }

            Dictionary<string, object> values = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            values["request"] = mRequest;
            values["judge"] = ok ? "OK" : "NG";
            values["time"] = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            values["cellid"] = (cells.Count > 0) ? string.Join("", cells) : "";
            for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
            {
                Point3f p = mAlignResult.SendPoint[i];
                values["a" + i + "x"] = (double)p.X;
                values["a" + i + "y"] = (double)p.Y;
                values["a" + i + "t"] = (double)p.Z;
            }

            string text;
            string err;
            if (!string.IsNullOrEmpty(toolReply))
            {
                // the tool already formatted its answer; add the terminator when it is missing
                text = toolReply;
                string term = SendTemplate.Unescape(mTrigger.Terminator);
                if (!string.IsNullOrEmpty(term) && !text.EndsWith(term, StringComparison.Ordinal)) text += term;
            }
            else if (!SendTemplate.TryFormat(template, values, out text, out err))
            {
                SequenceLog("[Trigger] reply template: " + err, Common.SvLogger.LogType.ERROR);
                return false;
            }

            byte[] bytes = (conn.TextEncoding == SvTextEncoding.Utf8) ? Encoding.UTF8.GetBytes(text) : Encoding.ASCII.GetBytes(text);
            ISendTransport tr = TransportRegistry.Get(conn, out err);
            if (tr == null || !tr.Send(bytes, out err))
            {
                SequenceLog("[Trigger] reply failed: " + err, Common.SvLogger.LogType.ERROR);
                return false;
            }
            SequenceLog("[Trigger] reply: " + SendTemplate.Visible(text), Common.SvLogger.LogType.DATA);
            return true;
        }

        public override bool Do_WriteResult()
        {
            bool ok = true;
            try
            {
                foreach (SvSend send in (mAlignCmd ? mSends : new List<SvSend>()))
                {
                    mDryRun = send.DryRun;
                    mCurSend = send;
                    List<SvSendChannel> todo = new List<SvSendChannel>(send.Channels);
                    SvSendChannel quick = send.QuickChannel();
                    if (quick != null) todo.Add(quick);
                    foreach (SvSendChannel ch in todo)
                    {
                        if (!ch.Enabled) continue;
                        if (ch.Condition == SvSendCondition.OnlyOK && !mDirectJudgeOK) continue;
                        if (ch.Condition == SvSendCondition.OnlyNG && mDirectJudgeOK) continue;
                        bool needsRobot = (ch.Kind == SvSendKind.Offsets || ch.Kind == SvSendKind.Position || ch.Kind == SvSendKind.Values);
                        if (needsRobot && mRobot == null && !mDryRun)
                        {
                            SequenceLog("[SvSend] no robot / PLC connection", Common.SvLogger.LogType.ERROR);
                            return false;
                        }
                        switch (ch.Kind)
                        {
                            case SvSendKind.Offsets: ok &= WriteOffsetsChannel(ch); break;
                            case SvSendKind.Position: ok &= WritePositionChannel(ch); break;
                            case SvSendKind.Text: ok &= WriteTextChannel(ch); break;
                            case SvSendKind.Registers: ok &= WriteRegistersChannel(ch); break;
                            default: ok &= WriteValuesChannel(ch); break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SequenceLog("[SvSend] exception " + ex, Common.SvLogger.LogType.ERROR);
                return false;
            }
            if (IsTcpTrigger)
            {
                AfterToolActions();
                // the reply is the answer to the request and the acknowledgement of the cycle
                ok &= SendTriggerReply(mDirectJudgeOK);
                SetVirtualBits(false, true);
            }
            return ok;
        }
    }
}
