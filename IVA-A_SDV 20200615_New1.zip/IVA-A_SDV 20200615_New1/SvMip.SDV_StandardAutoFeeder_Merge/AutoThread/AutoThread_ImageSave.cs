﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Only Image Save 용도(ImageSave tool에 경로 지정 필수)
    /// </summary>
    public class AutoThread_ImageSave : AutoThread_Base
    {
        public AutoThread_ImageSave(SystemData _system, RecipeData _recipe, Main.Process _process) : base(_system, _recipe, _process)
        {
            
        }
        public override bool Do_InitJob()
        {
            return SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");
        }

        public override bool Do_CheckVisionJob()
        {
            mJob.Run();
            return CheckVisionJob(mJob, 0);
        }

        public override bool Do_ExecuteAlignCalc()
        {
            return true;
        }

        public override bool Do_Judgement()
        {
            return mAlignResult.IsVisionOK;
        }


        public override bool Do_ManualCheck()
        {
            return true;
        }

        public override bool Do_WriteResult()
        {
            return true;
        }
    }
}
