﻿using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public partial class AutoThread_LoadInspectionData : Form
    {
        SystemData mSys;
        RecipeData mRcp;

        public AutoThread_LoadInspectionData(string _recipeName, Main.Process _process, string _jobName)
        {
            mSys = new SystemData();
            mSys.LoadData();

            mRcp = new RecipeData(_recipeName, mSys);
            mRcp.LoadData(true);

            if (mRcp == null) return;
            mSerializer = new SvSerializer();
            mJobPath = Path.Combine(Main.JobPath, _jobName);
            try
            {
                mJob = mSerializer.LoadJob(mJobPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            if (mJob == null || mJob.ToolList.Count == 0) return;

            InitializeComponent();                
        }

        SvSerializer mSerializer;
        string mJobPath;
        SvJob mJob;
        double mRate;

        private void nud_Rate_ValueChanged(object sender, EventArgs e)
        {
            mRate = (double)nud_Rate.Value;
        }

        private void btn_Run_Click(object sender, EventArgs e)
        {
            SvRegion region = mAlignResult.JobInfo[typeof(SvRegion)][0].Toolbase as SvRegion;
            SvTemplateMatch template = mAlignResult.JobInfo[typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;

            float rate = (float)mRate;
            float rectwidth = region.RegionRect.Width * rate;
            float rectheight = region.RegionRect.Height * rate;
            System.Drawing.PointF cp = region.RegionRect.Center;

            Rectf patternrectf = new Rectf(cp.X - rectwidth / 2, cp.Y - rectheight / 2, rectwidth, rectheight);
            SvRectangle patternrect = new SvRectangle(patternrectf);

            mJob.Run();

            for (int i = 0; i < template.mPatternDataList.Count; i++)
                template.mPatternDataList[i].Value.Dispose();

            template.mPatternDataList.Clear();

            for (int i = 0; i < region.Count_X; i++)
            {
                for (int j = 0; j < region.Count_Y; j++)
                {
                    region.Index_X = i; region.Index_Y = j;

                    SvImage pattern = new SvImage();
                    pattern.Mat = region.InputImage.Mat[SvFunc.Rectf2Rect(patternrectf)];
                    PatternData patterndata = new PatternData();
                    patterndata.PatternImage = pattern;
                    patterndata.RefPoint = new SvPoint(rectwidth / 2, rectheight / 2);

                    string name = "pattern" + (i * region.Count_Y + j).ToString();
                    string path = Path.Combine(Main.RecipePath, Auto.mCurrentRecipeName, name);
                    path = Path.ChangeExtension(path, "pti");
                    patterndata.SavePattern(path);

                    template.mPatternDataList.Add(new System.Collections.Generic.KeyValuePair<string, PatternData>(path, patterndata));
                }
            }
        }

        private void btn_RegionSave_Click(object sender, EventArgs e)
        {
            if (mJob == null || mJob.ToolList.Count == 0) return;

            bool issave = mSerializer.SaveJob(mJob, mJobPath);

            if (issave)
                MessageBox.Show("Job Save Success!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Job Save Fail!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        AlignResult mAlignResult = new AlignResult();
        private bool GetJobInfo(SvJob _job)
        {
            if (_job == null) return false;
            try
            {
                foreach (SvToolBase toolbase in _job.ToolList)
                {
                    if (!mAlignResult.JobInfo.ContainsKey(toolbase.GetType()))
                        mAlignResult.JobInfo.Add(toolbase.GetType(), new List<sCheckToolInfo>());

                    mAlignResult.JobInfo[toolbase.GetType()].Add(new sCheckToolInfo(toolbase, false));

                    if (toolbase is SvRegion) (toolbase as SvRegion).IndexAutoChange = false;
                    if (toolbase is SvToolBlock) GetJobInfo((toolbase as SvToolBlock).ToolJob);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
