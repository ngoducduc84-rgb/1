﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// 패널 유무 검사
    /// </summary>
    public class AutoThread_Load_Insp : AutoThread_Base
    {
        public AutoThread_Load_Insp(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {

        }

        public override bool Do_InitJob()
        {
            bool initOK = true;

            // Result Image Set
            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvImageConverter)))
                initOK &= SetResultImage(typeof(SvImageConverter), 0, 0, "OutputImage");
            else
                initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            initOK &= SetDisplayToolOn(typeof(SvRegion), 1, 0);

            //if(mProcData.InspectTool == EInspectTool.Histo)
            //    initOK &= SetDisplayToolOn(typeof(SvHistogram), 1, 0);
            //else// if(mProcData.InspectType == EInspectType.Templete)
            //    initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), 1, 0);

            // Inspection Set
            if (mProcData.UseInspect)
            {
                for (int i = 0; i < mAlignResult.JobInfo.Count; i++)
                {
                    if (mProcData.InspectTool == EInspectTool.Templete)
                    {
                        if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvTemplateMatch)))
                        {
                            initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), i, 0);
                        }
                    }
                    else
                    {
                        if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvHistogram)))
                        {
                            initOK &= SetDisplayToolOn(typeof(SvHistogram), i, 0);
                        }
                    }
                }
            }


            return initOK;
        }
        // run jobs
        public override bool Do_CheckVisionJob()
        {
            try
            {
                List<SvToolBlock> listToolblock = new List<SvToolBlock>();

                foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                    listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

                // 블록 두 개짜리 Job에서 앞 쪽 Tool block만 돌리기 위함
                //SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][0].Toolbase as SvToolBlock;

                bool visionResult = true;

                // toolblock 이전까지 실행
                mJob.RunBeforeTool(listToolblock[0]);
                visionResult &= CheckVisionJob(mJob, 0);

                for (int i = 0; i < listToolblock.Count; i++)
                {
                    // toolblock inputparams link
                    listToolblock[i].GetInParams();
                    listToolblock[i].InitOutProperty();

                    SvRegion region = null;
                    region = mAlignResult.JobInfo[i + 1][typeof(SvRegion)][0].Toolbase as SvRegion;
                    SvTemplateMatch templete = null;
                    if (mProcData.InspectTool == EInspectTool.Templete)
                    {
                        templete = mAlignResult.JobInfo[i + 1][typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;
                    }

                    region.IndexXnext = 0; region.IndexYnext = 0;

                    for (int j = 0; j < region.Count_X * region.Count_Y; j++)
                    {
                        if (mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete)
                            templete.SelectedPatternIndex = j;

                        listToolblock[i].Run();
                        visionResult &= CheckVisionJob(listToolblock[i].ToolJob, i + 1);

                        //if (mProcData.UseInspect && mProcData.InspectType == EInspectType.Judgement && !visionResult)
                        //    return visionResult;

                        region.IncreaseIndex();
                    }
                }

                return visionResult;
            }
            catch (Exception e)
            {
                SequenceLog(e.ToString(), Common.SvLogger.LogType.ERROR);
                return false;
            }
        }
        // calcutate robot offset position
        public override bool Do_ExecuteAlignCalc()
        {
            // no align
            return true;
        }

        public override bool Do_Judgement()
        {
            // check existence
            bool judgeOk = true;
            bool exist = false;
            bool needcheck = false;
            double high, low;
            int idx = 0;
            List<double> specs = new List<double>();

            mAlignResult.Existences.Clear();

            if (mProcData.InspectTool == EInspectTool.Histo)
            {
                for (int i = 0; i < mAlignResult.JobInfo.Count - 1; i++)
                {
                    SvHistogram histo = mAlignResult.JobInfo[i + 1][typeof(SvHistogram)][0].Toolbase as SvHistogram;

                    for (int j = 0; j < histo.Thresholds.Count; j++)
                    {
                        //idx = i * (mAlignResult.JobInfo.Count - 1) + j;

                        idx = mAlignResult.Existences.Count;

                        if (idx >= mAlignResult.Means.Count)
                        {
                            MessageBox.Show("It's out of array index!!! pls check count of histogram threshold");
                            return false;
                        }

                        high = histo.Thresholds[j] * mModelData.ExistHigh;
                        low = histo.Thresholds[j] * mModelData.ExistLow;

                        if (mModelData.Polarity == ePolarity.High)
                        {
                            exist = mAlignResult.Means[idx] >= high;
                            specs.Add(high);
                        }
                        else
                        {
                            exist = mAlignResult.Means[idx] < low;
                            specs.Add(low);
                        }
                        needcheck |= (mAlignResult.Means[idx] < high && mAlignResult.Means[idx] >= low);
                        mAlignResult.Existences.Add(exist);

                        //if (mProcData.InspectType == EInspectType.Judgement)
                        //    judgeOk &= exist;
                    }
                }
            }
            else// if (mProcData.InspectType == EInspectType.Templete)
            {
                for (int i = 0; i < mAlignResult.Scores.Count; i++)
                {
                    high = mModelData.ExistHigh;
                    low = mModelData.ExistLow;

                    if (mModelData.Polarity == ePolarity.High)
                    {
                        exist = mAlignResult.Scores[i] >= high;
                        specs.Add(high);
                    }
                    else
                    {
                        exist = mAlignResult.Scores[i] < low;
                        specs.Add(low);
                    }
                    needcheck |= mAlignResult.Scores[i] < high && mAlignResult.Scores[i] >= low;
                    mAlignResult.Existences.Add(exist);

                    //if (mProcData.InspectType == EInspectType.Judgement)
                    //    judgeOk &= exist;
                }
            }

            if (needcheck && mProcData.UseManualAlign)
            {
                judgeOk = Do_ManualCheck();//매뉴얼 창에서 사용자 결정 반영
            }
            //// display 변경 : 패널 유무 보여주기
            //SvAcquisition acq = mJob["Acquisition"] as SvAcquisition;
            //mUpdateDisplayCode.Clear();
            //mUpdateDisplayCode.Add(new Action(() =>
            //{
            //    ViewModel.Edit.Display.GraphicsFuncCollection.Clear();
            //    ViewModel.Edit.Display.Image = acq.AcqusitionImage;
            //}));

            SvRegion region = null;
            for (int i = 0; i < mAlignResult.JobInfo.Count - 1; i++)
            {
                region = mAlignResult.JobInfo[i + 1][typeof(SvRegion)][0].Toolbase as SvRegion;
                region.IndexXnext = region.IndexYnext = 0;

                for (int j = 0; j < region.Count_X * region.Count_Y; j++)
                {
                    if (mAlignResult.Existences.Count < region.Count_X * region.Count_Y * (mAlignResult.JobInfo.Count - 1))
                    {
                        MessageBox.Show("Counts of existence are not enough !!!");
                        return false;
                    }

                    idx = i * (region.Count_X * region.Count_Y) + j;
                    // display
                    string sJudge = string.Format("{0} : ", idx + 1);
                    sJudge += mAlignResult.Existences[idx] ? "EXIST" : "NONE";

                    if (mProcData.InspectTool == EInspectTool.Histo)
                        sJudge += string.Format("\n{0:f2} \n(spec : {1:f2})", mAlignResult.Means[idx], specs[idx]);
                    else
                        sJudge += string.Format("\n{0:f2} \n(spec : {1:f2})", mAlignResult.Scores[idx], specs[idx]);

                    System.Drawing.Color color = (mAlignResult.Existences[idx]) ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Orange;
                    System.Drawing.Pen pen = new System.Drawing.Pen(color);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);

                    region.Run();

                    SvRectangle rect = region.OutputImage.RegionRect;
                    System.Drawing.PointF pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);

                    mUpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.Display.DrawString(sJudge, font08, brush, pnt);
                        ViewModel.Edit.Display.DrawRectangle(pen, rect.RectF);
                    }));
                    region.IncreaseIndex();
                }
            }
            return judgeOk;
        }

        public override bool Do_ManualCheck()
        {
            bool isOk = true;
            SequenceLog("ManualInspection Start", Common.SvLogger.LogType.SEQUENCE);
            mIO.SetOutValue(mSystem.OPCallBit, true);//set op-call bit

            mManualAlignDispatcher.Invoke(() =>
            {
                ManualInspection wnd = new ManualInspection();
                wnd.InitWnd(mAlignResult, mJob, mIO, mProcData.IOParam.Inputs[InSignal.Complete.ToString()]);
                isOk = wnd.ShowDialog() == true;
            });

            mIO.SetOutValue(mSystem.OPCallBit, false);//reset op-call bit
            SequenceLog("ManualAlign End", Common.SvLogger.LogType.SEQUENCE);
            return isOk;
        }

        public override bool Do_WriteResult()
        {
            // exist
            int sendVal = 0;
            string result = "";
            for (int i = 0; i < mAlignResult.Existences.Count; i++)
            {
                SetBit(ref sendVal, i, mAlignResult.Existences[i]);

                int slog = mAlignResult.Existences[i] == true ? 1 : 0;
                result = slog + result;
            }
            bool sendresult = mRobot.WriteValue(mRobotWriteAddress, sendVal);
            SequenceLog(result, Common.SvLogger.LogType.DATA);

            return sendresult;
        }

        public override bool Do_WriteJudgement()
        {
            string msg;
            if (mAlignResult.IsJudgeOK)/*/ && mAlignResult.IsInterfaceOK)*/
            {
                msg = "JUDGE OK";
                ViewModel.Judge1 = true;
                mIO.SetOutValue(OutAddr[OutSignal.OK.ToString()], true);
            }
            else
            {
                msg = "JUDGE NG";
                ViewModel.Judge1 = false;
                mIO.SetOutValue(OutAddr[OutSignal.NG.ToString()], true);
            }
            SequenceLog(msg, Common.SvLogger.LogType.SEQUENCE);
            return true;
        }
    }
}
