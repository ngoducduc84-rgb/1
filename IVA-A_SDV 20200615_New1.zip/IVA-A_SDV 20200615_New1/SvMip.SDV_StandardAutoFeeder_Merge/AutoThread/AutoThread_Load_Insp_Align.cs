﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// 중복아닌가요?
    /// </summary>
    public class AutoThread_Load_Insp_Align : AutoThread_Base
    {
        public AutoThread_Load_Insp_Align(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {
        
        }

        public override bool Do_InitJob()
        {
            bool initOK = true;

            // Result Image Set
            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvImageConverter)))
                initOK &= SetResultImage(typeof(SvImageConverter), 0, 0, "OutputImage");
            else
                initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            initOK &= SetDisplayToolOn(typeof(SvRegion), 1, 0);

            if(mProcData.InspectTool == EInspectTool.Histo)
                initOK &= SetDisplayToolOn(typeof(SvHistogram), 1, 0);

            initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), 1, 0);
            initOK &= SetDisplayToolOn(typeof(SvIntersectLine), 1, 0);
            initOK &= SetDisplayToolOn(typeof(SvIntersectLine), 1, 1);
            initOK &= SetDisplayToolOn(typeof(SvFindLine), 1, 0);
            initOK &= SetDisplayToolOn(typeof(SvFindLine), 1, 1);
            initOK &= SetDisplayToolOn(typeof(SvFindLine), 1, 2);
            initOK &= SetDisplayToolOn(typeof(SvMakePoint), 1, 0);
            initOK &= SetDisplayToolOn(typeof(SvMakeLine), 1, 0);

            initOK &= SetResultPoint(typeof(SvMakePoint), 1, 0, "OutPoint");

            // Panel보다 Tray에 신호가 먼저 들어올 수도 있으므로 반드시 InitJob에도 넣어준다.
            // 만약 T-FOF같이 반드시 Panel이 선행되어야(값이 변경됨) 할 경우는 아래 코드 주석처리할 것.
            mAlignResult.ObjectRobotPoint.Clear();
            for (int i = 0; i < mRobotData.LoadPosition.Length; i++)
            {
                mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
                Point3d obP = mAlignResult.ObjectRobotPoint[i];
                mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);
            }

            return initOK;
        }

        public override bool Do_CheckVisionJob()
        {
            SvRegion region = mAlignResult.JobInfo[1][typeof(SvRegion)][0].Toolbase as SvRegion;
            SvToolBlock block = mAlignResult.JobInfo[0][typeof(SvToolBlock)][0].Toolbase as SvToolBlock;

            bool visionResult = true;

            // toolblock 이전까지 실행
            mJob.RunBeforeTool(block);
            visionResult &= CheckVisionJob(mJob, 0);

            // toolblock inputparams link
            block.GetInParams();
            block.InitOutProperty();

            int countX = region.Count_X;
            int countY = region.Count_Y;

            region.IndexXnext = 0; region.IndexYnext = 0;
            int idx = 1;
            for (int i = 0; i < countX * countY; i++)
            {
                block.Run();
                visionResult &= CheckVisionJob(block.ToolJob, 1);

                if (mProcData.UseManualAlign)//메뉴얼 창에 표시할 포인터 저장
                    makeManualPoints(mJob, ref idx);

                region.IncreaseIndex();
            }

            return visionResult;
        }

        /// <summary>
        /// 메뉴얼 align 창에서 사용할 default point
        /// 첫번째 점은 좌, 상 두번째 점은 우, 하 에 표시한다
        /// </summary>
        /// <param name="job"></param>
        /// <param name="idx"></param>
        protected void makeManualPoints(SvJob job, ref int idx)
        {
            double w = 0, h = 0;
            SvPoint pt = null;
            SvIntersectLine intersect = null;

            foreach (var t in job.ToolList)
            {
                if (t is SvIntersectLine)
                {
                    intersect = t as SvIntersectLine;
                    if (intersect.lastRunSuccess)
                    {
                        pt = intersect.outParams["IntersectPoint"] as SvPoint;
                    }
                    else
                    {
                        w = intersect.InputImage.Width;
                        h = intersect.InputImage.Height;
                        if (idx % 2 == 1)//홀수
                        {
                            pt = new SvPoint(w * 0.3, h * 0.3);//좌, 상
                        }
                        else
                        {
                            pt = new SvPoint(w * 0.7, h * 0.7);//우, 하
                        }
                    }
                    mAlignResult.ManualAlignPoint.Add(pt.Point3d);
                    ++idx;
                }
                else if (t is SvToolBlock)
                {
                    foreach (var tt in ((SvToolBlock)t).ToolJob.ToolList)
                    {
                        if (tt is SvIntersectLine)
                        {
                            intersect = tt as SvIntersectLine;
                            if (intersect.lastRunSuccess)
                            {
                                pt = intersect.outParams["IntersectPoint"] as SvPoint;
                            }
                            else
                            {
                                w = intersect.InputImage.Width;
                                h = intersect.InputImage.Height;
                                if (idx % 2 == 1)//홀수
                                {
                                    pt = new SvPoint(w * 0.3, h * 0.3);//좌, 상
                                }
                                else
                                {
                                    pt = new SvPoint(w * 0.7, h * 0.7);//우, 하
                                }
                            }
                            mAlignResult.ManualAlignPoint.Add(pt.Point3d);
                            ++idx;
                        }
                    }
                }
            }
        }

        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;
                bool isAlignOK = true;

                for (int i = 0; i < mRobotData.LoadPosition.Length; i++)
                {
                    Point3d pnt = mRobotData.LoadPosition[i].Point3d;
                    mAlignResult.ObjectRobotPoint.Add(new Point3d(pnt.X, pnt.Y, DegreeToRadian(pnt.Z)));
                }

                for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
                {
                    // Target Position
                    if (mAlignResult.ResultPoints[i] == null)
                    {
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        isAlignOK = false;
                    }
                    else
                    {
                        mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    }

                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    targetRobot.Z = NormalizeTheta(targetRobot.Z);
                    mAlignResult.TargetRobotPoint.Add(targetRobot);

                    for (int j = 0; j < mAlignResult.ObjectRobotPoint.Count; j++)
                    {
                        // Offset 계산
                        Point3d offsetedTarget = ApplyTargetOffset(mAlignResult.TargetRobotPoint[i], mRobotData.AlignOffsets[j].Point3d);
                        mAlignResult.TargetRevPoint.Add(cal.RToT(mAlignResult.ObjectRobotPoint[j], offsetedTarget));

                        // Send Position
                        Point3d result3d = mAlignResult.TargetRevPoint[i * 2 + j];
                        Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
                        mAlignResult.SendPoint.Add(result3f);
                    }
                }
                return isAlignOK;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }

        public override bool Do_Judgement()
        {
            // check existence
            bool judgeOk = true;
            bool exist = false;
            bool needcheck = false;
            double high, low;
            List<double> specs = new List<double>();
            mAlignResult.Existences.Clear();
            if (mProcData.InspectTool == EInspectTool.Histo)
            {
                SvHistogram histo = mAlignResult.JobInfo[1][typeof(SvHistogram)][0].Toolbase as SvHistogram;
                for (int i = 0; i < mAlignResult.Means.Count; i++)
                {
                    high = histo.Thresholds[i] * mModelData.ExistHigh;
                    low = histo.Thresholds[i] * mModelData.ExistLow;
                    if (mModelData.Polarity == ePolarity.High)
                    {
                        exist = mAlignResult.Means[i] >= high;
                        specs.Add(high);
                    }
                    else
                    {
                        exist = mAlignResult.Means[i] < low;
                        specs.Add(low);
                    }
                    needcheck |= (mAlignResult.Means[i] < high && mAlignResult.Means[i] >= low);
                    mAlignResult.Existences.Add(exist);
                }
            }
            else// if (mProcData.InspectType == EInspectType.Templete)
            {
                for (int i = 0; i < mAlignResult.Scores.Count; i++)
                {
                    high = mModelData.ExistHigh;
                    low = mModelData.ExistLow;
                    if (mModelData.Polarity == ePolarity.High)
                    {
                        exist = mAlignResult.Scores[i] >= high;
                        specs.Add(high);
                    }
                    else
                    {
                        exist = mAlignResult.Scores[i] < low;
                        specs.Add(low);
                    }
                    needcheck |= mAlignResult.Scores[i] < high && mAlignResult.Scores[i] >= low;
                    mAlignResult.Existences.Add(exist);
                }
            }

            // 좌표 판정
            for (int i = 0; i < mAlignResult.Existences.Count; i++)
            {
                int len = mRobotData.LoadPosition.Length;
                if (!mAlignResult.Existences[i])
                {
                    for (int j = 0; j < len; j++)
                    {
                        mAlignResult.SendPoint[i * len + j] = new Point3f();//없으면 좌표는 0,0,0
                    }
                    mAlignResult.Judgements.Add(false);
                    continue;
                }

                else if (!mAlignResult.JobSuccess[i])
                {
                    for (int j = 0; j < len; j++)
                    {
                        mAlignResult.SendPoint[i * len + j] = new Point3f();//실패하면 좌표는 0,0,0
                    }
                    mAlignResult.Judgements.Add(false);
                    judgeOk = false;
                    needcheck = true;
                }
                else
                {
                    mAlignResult.Judgements.Add(true);
                }
            }

            if (needcheck && mProcData.UseManualAlign)
            {
                judgeOk = Do_ManualCheck();//매뉴얼 창에서 사용자 결정 반영
            }
            return judgeOk;
        }

        public override bool Do_ManualCheck()
        {
            bool isJudgeOK = false;
            mIO.SetOutValue(mSystem.OPCallBit, true);//op-call

            SequenceLog("ManualAlign Start", Common.SvLogger.LogType.SEQUENCE);
            mManualAlignDispatcher.Invoke(() =>
            {
                ManualInspAlign wnd = new ManualInspAlign();
                wnd.InitWnd(mAlignResult, mJob, mIO, mProcData.IOParam.Inputs[InSignal.Complete.ToString()]);
                if (wnd.ShowDialog() == true)
                {
                    isJudgeOK = true;

                    mAlignResult.ObjectRobotPoint.Clear();
                    mAlignResult.TargetPixelPoint.Clear();
                    mAlignResult.TargetRobotPoint.Clear();
                    mAlignResult.TargetRevPoint.Clear();
                    mAlignResult.SendPoint.Clear();

                    isJudgeOK &= Do_ExecuteAlignCalc();
                    isJudgeOK &= CheckLimit();

                    int toolCnt = (mProcData.FlowType == PanelFlowType.Single) ? 1 : 2;

                    for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
                    {
                        if (!mAlignResult.Judgements[i / toolCnt])
                            mAlignResult.SendPoint[i] = new Point3f();
                    }

                    int count = ViewModel.UpdateDisplayCode.Count;
                    ViewModel.UpdateDisplayCode.RemoveRange(2, count - 2);
                    ViewModel.UpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.Display.DrawString("Manual Align", font16, System.Drawing.Brushes.SkyBlue, new Point2d(50, 50));

                        for (int i = 0; i < mAlignResult.Judgements.Count; i++)
                        {
                            if (!mAlignResult.Judgements[i]) continue;
                            for (int j = 0; j < 2; j++)//interactPoint * 2
                            {
                                int idx = i * 2 + j;
                                ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.LightYellow,
                                    new Point2d(mAlignResult.ManualAlignPoint[idx].X, mAlignResult.ManualAlignPoint[idx].Y), 200, 200, mAlignResult.ManualAlignPoint[idx].Z);
                            }
                            // send point * 1
                            ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.OrangeRed,
                                new Point2d(mAlignResult.TargetPixelPoint[i].X, mAlignResult.TargetPixelPoint[i].Y), 100, 100, mAlignResult.TargetPixelPoint[i].Z);
                        }
                    }));
                }
            });
            SequenceLog("ManualAlign End", Common.SvLogger.LogType.SEQUENCE);
            mIO.SetOutValue(mSystem.OPCallBit, false);//op-call
            GC.Collect();
            return isJudgeOK;
        }

        public override bool Do_WriteResult()
        {
            // exist
            int sendVal = 0;
            string result = "";
            for (int i = 0; i < mAlignResult.Existences.Count; i++)
            {
                SetBit(ref sendVal, i, mAlignResult.Existences[i]);

                int slog = mAlignResult.Existences[i] == true ? 1 : 0;
                result = slog + result;
            }
            bool sendresult = mRobot.WriteValue(mRobotWriteAddress, sendVal);//시작지점 2word에 유무 값 write
            SequenceLog(result, Common.SvLogger.LogType.DATA);

            // position
            sendresult &= WriteRevOffset(mRobotWriteAddress + 2, mAlignResult.SendPoint);//2워드 이후부터 위치값 저장한다..
            return sendresult;
        }
    }
}
