﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// 기본 Panel Align (pick up 전 Align)
    /// </summary>
    public class AutoThread_Panel : AutoThread_Base
    {
        public AutoThread_Panel(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {

        }

        int mToolblockindex; // toolblock이 있으면 1, 없으면 0
        public override bool Do_InitJob()
        {
            mToolblockindex = mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)) ? 1 : 0;

            bool initOK = true;

            // ResultImage Setting
            mAlignResult.ResultImageList.Clear();

            initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)))
            {
                for (int i = 1; i < mAlignResult.JobInfo.Count; i++)
                {
                    //SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][i].Toolbase as SvToolBlock;

                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    {
                        SvJudgement judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][0].Toolbase as SvJudgement;
                        object obj = judge.inParams["Value"].Instance;
                        initOK &= SetResultImage(obj.GetType(), i, 0, "InputImage");
                        continue;
                    }
                    //else if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                    //{
                    //    initOK &= SetResultImage(typeof(SvMakePoint), i, 0, "InputImage");
                    //    continue;
                    //}
                }
            }

            // DisplayTool Setting
            for (int i = 0; i < mAlignResult.JobInfo.Count; i++)
            {
                SetDisplayToolOn(typeof(SvFindLine), i);
                SetDisplayToolOn(typeof(SvTemplateMatch), i);
                SetDisplayToolOn(typeof(SvBlob), i);
                SetDisplayToolOn(typeof(SvHistogram), i);
                SetDisplayToolOn(typeof(SvIntersectLine), i);
                SetDisplayToolOn(typeof(SvDistance3P), i);
                SetDisplayToolOn(typeof(SvMakeRectFromLine), i);
                SetDisplayToolOn(typeof(SvMakeLine), i);

                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                {
                    initOK &= SetDisplayToolOn(typeof(SvJudgement), i);
                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvJudgement)].Count; j++)
                    {
                        initOK &= SetResultJudgement(typeof(SvJudgement), i, j, "Judgement");
                    }
                }

                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                {
                    initOK &= SetDisplayToolOn(typeof(SvMakePoint), i);
                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvMakePoint)].Count; j++)
                    {
                        initOK &= SetResultPoint(typeof(SvMakePoint), i, j, "OutPoint");
                    }
                }
            }

            // Panel보다 Tray에 신호가 먼저 들어올 수도 있으므로 반드시 InitJob에도 넣어준다.
            // 만약 T-FOF같이 반드시 Panel이 선행되어야(값이 변경됨) 할 경우는 아래 코드 주석처리할 것.
            mAlignResult.ObjectRobotPoint.Clear();
            for (int i = 0; i < mRobotData.LoadPosition.Length; i++)
            {
                mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
                Point3d obP = mAlignResult.ObjectRobotPoint[i];
                mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);
            }

            return initOK;
        }

        public override bool Do_CheckVisionJob()
        {
            SvRegion region = mAlignResult.JobInfo[mToolblockindex][typeof(SvRegion)][0].Toolbase as SvRegion;
            SvToolBlock block = null;

            bool visionResult = true;

            // Toolblock이 있을경우 Toolblock 이전까지 실행
            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)))
                block = mAlignResult.JobInfo[0][typeof(SvToolBlock)][0].Toolbase as SvToolBlock;


            if (block != null)
            {
                // toolblock 이전까지 실행
                mJob.RunBeforeTool(block);
                visionResult &= CheckVisionJob(mJob, 0);

                // toolblock inputparams link
                block.GetInParams();
                block.InitOutProperty();
            }

            mRegionCount = region.Count_X * region.Count_Y;

            region.IndexXnext = 0; region.IndexYnext = 0;
            int idx = 1;
            for (mRegionIndex = 0; mRegionIndex < mRegionCount; mRegionIndex++)
            {
                // Toolblock이 없을경우 그냥 mJob을 돌린다.
                SvJob job = block == null ? mJob : block.ToolJob;

                // set templetematching index 
                foreach (var tool in job.ToolList)
                {
                    if (tool is SvTemplateMatch)
                    {
                        var match = tool as SvTemplateMatch;
                        if (match.mPatternDataList.Count == mRegionCount)
                        {
                            match.SelectedPatternIndex = mRegionIndex;
                        }
                    }
                }

                job.Run();
                visionResult &= CheckVisionJob(job, mToolblockindex);

                if (mSystem.DicProcess[mProcess].UseManualAlign)
                {
                    makeManualPoints(job, ref idx);
                }

                region.IncreaseIndex();
            }

            return visionResult;
        }

        protected void makeManualPoints(SvJob job, ref int idx)
        {
            double w = 0, h = 0;
            SvPoint pt = null;
            SvIntersectLine intersect = null;

            foreach (var t in job.ToolList)
            {
                if (t is SvIntersectLine)
                {
                    intersect = t as SvIntersectLine;
                    if (intersect.lastRunSuccess)
                    {
                        pt = intersect.outParams["IntersectPoint"] as SvPoint;
                    }
                    else
                    {
                        w = intersect.InputImage.Width;
                        h = intersect.InputImage.Height;
                        if (idx % 2 == 1)//홀수
                        {
                            pt = new SvPoint(w * 0.3, h * 0.3);//좌, 상
                        }
                        else
                        {
                            pt = new SvPoint(w * 0.7, h * 0.7);//우, 하
                        }
                    }

                    mAlignResult.ManualAlignPoint.Add(pt.Point3d);
                    ++idx;

                }
            }
        }

        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;
                bool isAlignOK = true;

                for (int i = 0; i < mAlignResult.ResultPoints.Count && i < mRobotData.LoadPosition.Length; i++)
                {
                    // Start Position
                    mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
                    Point3d obP = mAlignResult.ObjectRobotPoint[i];
                    mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);

                    // Target Position
                    if (mAlignResult.ResultPoints[i] == null)
                    {
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        isAlignOK = false;
                    }
                    else
                    {
                        mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    }

                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    targetRobot.Z = NormalizeTheta(targetRobot.Z);
                    mAlignResult.TargetRobotPoint.Add(targetRobot);

                    // Offset 계산
                    Point3d offsetedTarget = ApplyTargetOffset(mAlignResult.TargetRobotPoint[i], mRobotData.AlignOffsets[i].Point3d);
                    if (cal.RotCenter.X == 0 && cal.RotCenter.Y == 0) // T-축이 없을경우는 그냥 X,Y 값을 빼준다...
                        offsetedTarget.Z = mAlignResult.ObjectRobotPoint[i].Z;
                    mAlignResult.TargetRevPoint.Add(cal.RToT(mAlignResult.ObjectRobotPoint[i], offsetedTarget));

                    // Send Position
                    Point3d result3d = mAlignResult.TargetRevPoint[i];
                    Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
                    mAlignResult.SendPoint.Add(result3f);
                }
                return isAlignOK;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }

        public override bool Do_Judgement()
        {
            bool isJudgeOK = true;
            try
            {
                // 1) Align Part
                if (mProcData.UseInspect)//패널 유무 검사해서 없을 경우는 NG 처리 안함
                {
                    // check existence
                    bool exist = false;
                    bool needcheck = false;
                    double high, low;
                    List<double> specs = new List<double>();
                    mAlignResult.Existences.Clear();
                    if (mProcData.InspectTool == EInspectTool.Histo)
                    {
                        if (!mAlignResult.JobInfo[mToolblockindex].ContainsKey(typeof(SvHistogram)))
                        {
                            SequenceLog("[Histogram] No histogram tool in job.", Common.SvLogger.LogType.ERROR);
                            return false;
                        }

                        SvHistogram histo = mAlignResult.JobInfo[mToolblockindex][typeof(SvHistogram)][0].Toolbase as SvHistogram;
                        for (int i = 0; i < mAlignResult.Means.Count; i++)
                        {
                            high = mModelData.ExistHigh;
                            low = mModelData.ExistLow;
                            if (mModelData.Polarity == ePolarity.High)
                            {
                                exist = mAlignResult.Means[i] >= high;
                                specs.Add(high);
                            }
                            else
                            {
                                exist = mAlignResult.Means[i] < low;
                                specs.Add(low);
                            }
                            needcheck |= (mAlignResult.Means[i] < high && mAlignResult.Means[i] >= low);
                            mAlignResult.Existences.Add(exist);
                        }
                    }
                    else// if (mProcData.InspectType == EInspectType.Templete)
                    {
                        for (int i = 0; i < mAlignResult.Scores.Count; i++)
                        {
                            high = mModelData.ExistHigh;
                            low = mModelData.ExistLow;
                            if (mModelData.Polarity == ePolarity.High)
                            {
                                exist = mAlignResult.Scores[i] >= high;
                                specs.Add(high);
                            }
                            else
                            {
                                exist = mAlignResult.Scores[i] < low;
                                specs.Add(low);
                            }
                            needcheck |= mAlignResult.Scores[i] < high && mAlignResult.Scores[i] >= low;
                            mAlignResult.Existences.Add(exist);
                        }
                    }
                }

                if (mAlignResult.CheckJobResult.Count != mRobotData.LoadPosition.Length)
                    SequenceLog("Region Count is not same FlowType!!", Common.SvLogger.LogType.ERROR);

                for (int i = 0; i < mAlignResult.CheckJobResult.Count && i < mRobotData.LoadPosition.Length; i++)
                {
                    // 개별 판정은 Job Success와 동일하게 적용 - Dual Judgement
                    mAlignResult.AlignJudge.Add(mAlignResult.CheckJobResult[i]);
                    // 전체 판정 - Single Judgement
                    // 실패했을 경우는...
                    //if(mAlignResult.Existences[i] == false)
                    if (mAlignResult.CheckJobResult[i] == false) 
                    {
                        // 일단 결과 좌표는 0,0,0으로 리셋하고
                        if (mAlignResult.SendPoint.Count != 0)
                            mAlignResult.SendPoint[i] = new Point3f();
                        
                        // 유무검사 여부에 따라 전체 판정을 달리 가져감
                        if (mProcData.UseInspect)
                        {
                            isJudgeOK &= !mAlignResult.Existences[i];
                        }
                        else
                        {
                            isJudgeOK = false;
                        }
                    }
                }


                //리미트 체크하고
                isJudgeOK &= CheckLimit();

                //manual align
                if (isJudgeOK == false && mSystem.DicProcess[mProcess].UseManualAlign)
                {
                    isJudgeOK = Do_ManualCheck();
                }

                // 주석처리해도 문제없는지 모르겠음...2018.12.10 HOZZANG
                AlignResult.List2JudgeResult.Add(new List<bool>());
                if (mAlignResult.List2JudgeResult.Count > 0)
                    mAlignResult.List2JudgeResult[0].Add(isJudgeOK);
            }
            catch (Exception ex)
            {
                SequenceLog("Judgement Exception" + ex, Common.SvLogger.LogType.ERROR);
                return false;
            }

            return isJudgeOK;
        }

        public override bool Do_ManualCheck()
        {
            bool isJudgeOK = false;
            mIO.SetOutValue(mSystem.OPCallBit, true, false);//op-call

            SequenceLog("ManualAlign Start", Common.SvLogger.LogType.SEQUENCE);

            mManualAlignDispatcher.Invoke(() =>
            {
                ManualAlign wnd = new ManualAlign();
                wnd.InitWnd(mAlignResult, mJob, mSystem.DicProcess[mProcess].FlowType, mIO, mProcData.IOParam.Inputs[InSignal.Complete.ToString()]);
                if (wnd.ShowDialog() == true)
                {
                    isJudgeOK = true;

                    mAlignResult.ObjectRobotPoint.Clear();
                    mAlignResult.TargetPixelPoint.Clear();
                    mAlignResult.TargetRobotPoint.Clear();
                    mAlignResult.TargetRevPoint.Clear();
                    mAlignResult.SendPoint.Clear();

                    isJudgeOK &= Do_ExecuteAlignCalc();
                    isJudgeOK &= CheckLimit();

                    for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
                    {
                        if (!mAlignResult.AlignJudge[i])//judgement false이면 sendpoint 0,0,0 으로 보내준다
                            mAlignResult.SendPoint[i] = new Point3f();
                    }

                    int count = ViewModel.UpdateDisplayCode.Count;
                    ViewModel.UpdateDisplayCode.RemoveRange(2, count - 2);
                    ViewModel.UpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.Display.DrawString("Manual Align", font16, System.Drawing.Brushes.SkyBlue, new Point2d(50, 50));

                        for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
                        {
                            if (!mAlignResult.AlignJudge[i]) continue;
                            for (int j = 0; j < 2; j++)//interactPoint * 2
                            {
                                int idx = i * 2 + j;
                                ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.LightYellow,
                                    new Point2d(mAlignResult.ManualAlignPoint[idx].X, mAlignResult.ManualAlignPoint[idx].Y), 200, 200, mAlignResult.ManualAlignPoint[idx].Z);
                            }
                            // send point * 1
                            ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.OrangeRed,
                                new Point2d(mAlignResult.TargetPixelPoint[i].X, mAlignResult.TargetPixelPoint[i].Y), 100, 100, mAlignResult.TargetPixelPoint[i].Z);
                        }

                        //foreach(var pnt in mAlignResult.ManualAlignPoint)
                        //    ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.LightYellow, new Point2d(pnt.X, pnt.Y), 200, 200, pnt.Z);
                        //foreach (var pnt in mAlignResult.TargetPixelPoint)
                        //    ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.OrangeRed, new Point2d(pnt.X, pnt.Y), 100, 100, pnt.Z);
                    }));
                }
            });
			
            SequenceLog("ManualAlign End", Common.SvLogger.LogType.SEQUENCE);
            mIO.SetOutValue(mSystem.OPCallBit, false, false);//op-call
            GC.Collect();
            return isJudgeOK;
        }

        public override bool Do_WriteJudgement()
        {
            int index;
            //string msg;
            bool isWriteJudgeOk = true;

            if (mSystem.DicProcess[mProcess].JudgeType == EJudgeType.Single)
            {
                // 두 매 물류 중 Single Judge Type 처리를 개별 Judge &조건 막음 .... AMT 패널로딩 비전 적용 
                //foreach (var judge in mAlignResult.Judgements)
                //    isJudgeOk &= judge;

                //msg = isWriteJudgeOk ? "JUDGE OK" : "JUDGE NG";

                if (mAlignResult.IsJudgeOK && mAlignResult.IsInterfaceOK)
                {
                    ViewModel.Judge1 = true;
                    isWriteJudgeOk = mIO.SetOutValue(OutAddr[OutSignal.OK.ToString()], true, false);
                }
                else
                {
                    ViewModel.Judge1 = false;
                    isWriteJudgeOk = mIO.SetOutValue(OutAddr[OutSignal.NG.ToString()], true, false);
                }
                //SequenceLog(msg, Common.SvLogger.LogType.SEQUENCE);
            }
            else//dual
            {
                if (mAlignResult.AlignJudge.Count < 2)
                {
                    SequenceLog("Region Count is not 2", Common.SvLogger.LogType.ERROR);
                }

                for (int i = 0; i < mAlignResult.AlignJudge.Count; i++)
                {
                    //msg = mAlignResult.Judgements[i] ? string.Format("JUDGE{0} OK", i + 1) : string.Format("JUDGE{0} NG", i + 1);

                    if (mAlignResult.AlignJudge[i] && mAlignResult.IsInterfaceOK)
                    {
                        if (i == 0)
                        {
                            index = OutAddr[OutSignal.OK.ToString()];
                            ViewModel.Judge1 = true;
                        }
                        else
                        {
                            index = OutAddr[OutSignal.OK2.ToString()];
                            ViewModel.Judge2 = true;
                        }
                        isWriteJudgeOk &= mIO.SetOutValue(index, true, false);
                    }
                    else
                    {
                        if (i == 0)
                        {
                            index = OutAddr[OutSignal.NG.ToString()];
                            ViewModel.Judge1 = false;
                        }
                        else
                        {
                            index = OutAddr[OutSignal.NG2.ToString()];
                            ViewModel.Judge2 = false;
                        }
                        isWriteJudgeOk &= mIO.SetOutValue(index, true, false);
                    }
                    //SequenceLog(msg, Common.SvLogger.LogType.SEQUENCE);
                }
            }
            return isWriteJudgeOk;
        }

        public override bool Do_WriteResult()
        {
            bool b = WriteRevOffset(mOffsetAddr, mAlignResult.SendPoint);
            return b;
        }

        internal bool Do_ExecuteAlignCalc_NoMove()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;
                bool isAlignOK = true;

                mAlignResult.TargetRobotPoint.Clear();
                mAlignResult.ObjectRobotPoint.Clear();
                mAlignResult.SendPoint.Clear();

                for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
                {
                    //Point3d obP = mRobotData.LoadPosition[i].Point3d;
                    // Target Position
                    if (mAlignResult.ResultPoints[i] == null)
                    {
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        isAlignOK = false;
                    }
                    else
                    {
                        mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    }

                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    targetRobot.Z = NormalizeTheta(targetRobot.Z);

                    mAlignResult.TargetRobotPoint.Add(targetRobot);
                    //mAlignResult.ObjectRobotPoint.Add(targetRobot);
                    mAlignResult.TargetRevPoint.Add(new Point3d());

                    // Offset 계산
                    //Point3d offsetedTarget = ApplyTargetOffset(mAlignResult.TargetRobotPoint[i], obP);

                    mAlignResult.ObjectRobotPoint.Add(mAlignResult.TargetRobotPoint[i]);
                }

                for (int i = 0; i < mRefAutoThread.Count; i++)
                {
                    isAlignOK &= mRefAutoThread[i].Do_ExecuteAlignCalc();
                    SequenceLog(string.Format("Rev : ({0:f3}, {1:f3}, {2:f3})", 
                        mAlignResult.ObjectRobotPoint[i].X, mAlignResult.ObjectRobotPoint[i].Y, mAlignResult.ObjectRobotPoint[i].Z), Common.SvLogger.LogType.DATA);
                }

                return isAlignOK;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }

        public bool Check_Panel_Judge()
        {
            try
            {
                // 2) Inspection part
                SvRegion region = mAlignResult.JobInfo[1][typeof(SvRegion)][0].Toolbase as SvRegion;

                int toolblockindex = 1; // 상수임
                int judgeCnt = mAlignResult.JobInfo[toolblockindex][typeof(SvJudgement)].Count;
                mRegionCount = region.Count_X * region.Count_Y;

                for (int judgeIndex = 0; judgeIndex < judgeCnt; judgeIndex++)
                {
                    SvJudgement judge = mAlignResult.JobInfo[toolblockindex][typeof(SvJudgement)][judgeIndex].Toolbase as SvJudgement;
                    mAlignResult.List2JudgeResult.Add(new List<bool>());

                    for (mRegionIndex = 0; mRegionIndex < mRegionCount; mRegionIndex++)
                    {
                        // judge의 thresholds와 value를 이용해 Judgements값 계산
                        if (judge.Thresholds.Count == mRegionCount)
                            judge.Creteria = judge.Thresholds[mRegionIndex];

                        judge.Value = mAlignResult.List2JudgeValues[judgeIndex][mRegionIndex];
                        judge.Run();

                        mAlignResult.List2JudgeResult[judgeIndex].Add(judge.Judgement);

                        //// display
                        //string sJudge = string.Format("{0} : ", (judgeIndex + 1));
                        //sJudge += judge.Judgement ? "OK" : "NG";
                        //sJudge += string.Format("\n{0:f2} \n(spec : {1:f2})", judge.Value, judge.Creteria);

                        //System.Drawing.Color color = (judge.Judgement) ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Orange;
                        //System.Drawing.Pen pen = new System.Drawing.Pen(color);
                        //pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                        //System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);

                        //region.Run();

                        //SvRectangle rect = region.OutputImage.RegionRect;
                        //System.Drawing.PointF pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);

                        //mUpdateDisplayCode.Add(new Action(() =>
                        //{
                        //    ViewModel.Edit.CustomImageList[judgeIndex].drawingFunc +=
                        //    (display) =>
                        //    {
                        //        display.DrawString(sJudge, font08, brush, pnt);
                        //        display.DrawRectangle(pen, rect.RectF);
                        //    };
                        //}));

                        region.IncreaseIndex();
                    }
                }
                // Display 순서랑 맞춰주기위해 하나 강제로 추가한다.(JobInfo[0] AcquisitionImage 대응)
                mAlignResult.List2JudgeResult.Insert(0, new List<bool>());

                if (mProcData.InspectType == EInspectType.Judgement)
                {
                    for (int judgeIndex = 0; judgeIndex < ListJudgeIndex.Count; judgeIndex++)
                        if (mAlignResult.List2JudgeResult[judgeIndex].Contains(false))
                            return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                SequenceLog("Judgement Exception" + ex, Common.SvLogger.LogType.ERROR);
                return false;
            }
        }
    }
}
