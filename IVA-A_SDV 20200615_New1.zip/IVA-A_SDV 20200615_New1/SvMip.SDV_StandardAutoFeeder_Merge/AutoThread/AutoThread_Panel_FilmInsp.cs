﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using SvMip.Common;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Panel Align 및 FOD 박리 필름 
    /// </summary>
    public class AutoThread_Panel_FilmInsp : AutoThread_Panel_Total
    {
        public AutoThread_Panel_FilmInsp(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {

        }

        int mToolblockindex; // toolblock이 있으면 1, 없으면 0
        public override bool Do_InitJob()
        {
            bool initOK = true;

            // ResultImage Setting
            mAlignResult.ResultImageList.Clear();

            initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)))
            {
                for (int i = 1; i < mAlignResult.JobInfo.Count; i++)
                {
                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    {
                        SvJudgement judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][0].Toolbase as SvJudgement;

                        if (judge.inParams.ContainsKey("InputImage"))
                        {
                            initOK &= SetResultImage(typeof(SvJudgement), i, 0, "InputImage");
                        }
                        else if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvRegion)))
                        {
                            initOK &= SetResultImage(typeof(SvRegion), i, 0, "InputImage");
                        }
                        else
                        {
                            object obj = judge.inParams["Value"].Instance;
                            initOK &= SetResultImage(obj.GetType(), i, 0, "InputImage");
                        }
                        continue;
                    }

                    //if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                    //{
                    //    initOK &= SetResultImage(typeof(SvMakePoint), i, 0, "InputImage");
                    //    continue;
                    //}
                }
            }

            // DisplayTool Setting
            for (int i = 0; i < mAlignResult.JobInfo.Count; i++)
            {
                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                {
                    ListJudgeIndex.Add(i);
                    initOK &= SetDisplayToolOn(typeof(SvJudgement), i);

                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvJudgement)].Count; j++)
                    {
                        initOK &= SetResultJudgement(typeof(SvJudgement), i, j, "Judgement");
                    }
                }

                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                {
                    ListAlignIndex.Add(i);
                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvMakePoint)].Count; j++)
                    {
                        initOK &= SetResultPoint(typeof(SvMakePoint), i, j, "OutPoint");
                    }
                    initOK &= SetDisplayToolOn(typeof(SvIntersectLine), i);

                    initOK &= SetDisplayToolOn(typeof(SvMakePoint), i);
                    initOK &= SetDisplayToolOn(typeof(SvFindLine), i);
                    initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), i);
                }
            }

            // Panel보다 Tray에 신호가 먼저 들어올 수도 있으므로 반드시 InitJob에도 넣어준다.
            // 만약 T-FOF같이 반드시 Panel이 선행되어야(값이 변경됨) 할 경우는 아래 코드 주석처리할 것.
            mAlignResult.ObjectRobotPoint.Clear();

            for (int i = 0; i < mRobotData.LoadPosition.Length; i++)
            {
                mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
                Point3d obP = mAlignResult.ObjectRobotPoint[i];
                mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);
            }

            return initOK;
        }

        public override bool Do_CheckVisionJob()
        {
            try
            {
                // initialize
                bool visionResult = true;
                mAlignResult.IsInspectionOK = true;

                List<SvToolBlock> listToolblock = new List<SvToolBlock>();
                listToolblock.Add(null);
                foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                    listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

                mAlignResult.List2JudgeValues.Clear();
                mAlignResult.List2JudgeSpec.Clear();
                mAlignResult.List2JudgeResult.Clear();

                mAlignResult.List2JudgeValues.Add(new List<double>());
                mAlignResult.List2JudgeSpec.Add(new List<double>());
                mAlignResult.List2JudgeResult.Add(new List<bool>());

                mAlignResult.List2FDC_BlobReference.Clear();
                mAlignResult.List2FDC_BlobReference.Add(new List<int>());

                // toolblock 이전까지 실행
                mJob.RunBeforeTool(listToolblock[1]);
                visionResult &= CheckVisionJob(mJob, 0);

                // toolblock cnt loop
                for (int i = 1; i < listToolblock.Count; i++)
                {
                    mAlignResult.List2JudgeValues.Add(new List<double>());
                    mAlignResult.List2JudgeSpec.Add(new List<double>());
                    mAlignResult.List2JudgeResult.Add(new List<bool>());

                    mAlignResult.List2FDC_BlobReference.Add(new List<int>());

                    SvRegion region = null;

                    // region은 toolblock당 무조건 하나로!! <= 규칙 만약 없으면 Exception!!
                    region = mAlignResult.JobInfo[i][typeof(SvRegion)][0].Toolbase as SvRegion;

                    // toolblock inputparams link
                    listToolblock[i].GetInParams();
                    listToolblock[i].InitOutProperty();

                    region.IndexXnext = 0; region.IndexYnext = 0;
                    mRegionCount = region.Count_X * region.Count_Y;

                    //if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvTemplateMatch)) && mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    //    template = mAlignResult.JobInfo[i][typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;

                    int idx = 1;
                    // region cnt loop
                    for (mRegionIndex = 0; mRegionIndex < mRegionCount; mRegionIndex++)
                    {
                        listToolblock[i].Run();
                        if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)) && mAlignResult.JobInfo[i].ContainsKey(typeof(SvDistance3P)))
                        {
                            mAlignResult.IsInspectionOK &= CheckVisionJob(listToolblock[i].ToolJob, i);
                        }
                        else
                            visionResult &= CheckVisionJob(listToolblock[i].ToolJob, i);

                        if (mSystem.DicProcess[mProcess].UseManualAlign && i == 0)
                            makeManualPoints(listToolblock[i].ToolJob, ref idx);

                        region.IncreaseIndex();
                    }
                }
                return visionResult;
            }
            catch (Exception e)
            {
                SequenceLog(e.ToString(), Common.SvLogger.LogType.ERROR);
                return false;
            }
        }

        protected void makeManualPoints(SvJob job, ref int idx)
        {
            double w = 0, h = 0;
            SvPoint pt = null;
            SvIntersectLine intersect = null;

            foreach (var t in job.ToolList)
            {
                if (t is SvIntersectLine)
                {
                    intersect = t as SvIntersectLine;
                    if (intersect.lastRunSuccess)
                    {
                        if (intersect.outParams.ContainsKey("IntersectPoint"))
                            pt = intersect.outParams["IntersectPoint"] as SvPoint;

                        else continue;
                    }
                    else
                    {
                        w = intersect.InputImage.Width;
                        h = intersect.InputImage.Height;
                        if (idx % 2 == 1)//홀수
                        {
                            pt = new SvPoint(w * 0.3, h * 0.3);//좌, 상
                        }
                        else
                        {
                            pt = new SvPoint(w * 0.7, h * 0.7);//우, 하
                        }
                    }

                    mAlignResult.ManualAlignPoint.Add(pt.Point3d);
                    ++idx;
                }
                else if (t is SvToolBlock)
                {
                    foreach (var tt in ((SvToolBlock)t).ToolJob.ToolList)
                    {
                        if (tt is SvIntersectLine)
                        {
                            intersect = tt as SvIntersectLine;

                            if (intersect.toolName != "IntersectLine(Left)" && intersect.toolName != "IntersectLine(Right)") continue;

                            if (intersect.lastRunSuccess)
                            {
                                pt = intersect.outParams["IntersectPoint"] as SvPoint;
                            }
                            else
                            {
                                w = intersect.InputImage.Width;
                                h = intersect.InputImage.Height;
                                if (idx % 2 == 1)//홀수
                                {
                                    pt = new SvPoint(w * 0.3, h * 0.3);//좌, 상
                                }
                                else
                                {
                                    pt = new SvPoint(w * 0.7, h * 0.7);//우, 하
                                }
                            }

                            mAlignResult.ManualAlignPoint.Add(pt.Point3d);
                            ++idx;
                        }
                    }
                }
            }
        }

        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;
                bool isAlignOK = true;

                for (int i = 0; i < mAlignResult.ResultPoints.Count && i < mRobotData.LoadPosition.Length; i++)
                {
                    // Start Position
                    mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
                    Point3d obP = mAlignResult.ObjectRobotPoint[i];
                    mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);

                    // Target Position
                    if (mAlignResult.ResultPoints[i] == null)
                    {
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        isAlignOK = false;
                    }
                    else
                    {
                        mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    }

                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    targetRobot.Z = NormalizeTheta(targetRobot.Z);
                    mAlignResult.TargetRobotPoint.Add(targetRobot);

                    // Offset 계산
                    Point3d offsetedTarget = ApplyTargetOffset(mAlignResult.TargetRobotPoint[i], mRobotData.AlignOffsets[i].Point3d);
                    if (cal.RotCenter.X == 0 && cal.RotCenter.Y == 0) // T-축이 없을경우는 그냥 X,Y 값을 빼준다...
                        offsetedTarget.Z = mAlignResult.ObjectRobotPoint[i].Z;
                    //mAlignResult.TargetRevPoint.Add(cal.RToT(mAlignResult.ObjectRobotPoint[i], offsetedTarget));
                    mAlignResult.TargetRevPoint.Add(cal.RToT(offsetedTarget, mAlignResult.ObjectRobotPoint[i]));

                    // Send Position
                    Point3d result3d = mAlignResult.TargetRevPoint[i];
                    Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
                    mAlignResult.SendPoint.Add(result3f);
                }
                return isAlignOK;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }



        public override bool Do_Judgement()
        {
            bool isJudgeOK = true;

            isJudgeOK = base.Do_Judgement();
            //string msg = "AlignJudge ";
            //msg += isJudgeOK ? "OK" : "NG";
            //SequenceLog(msg, SvLogger.LogType.DATA);

            bool isInspOK = Do_Inspection(isJudgeOK);
            string msg = "InspectJudge ";
            msg += isInspOK ? "OK" : "NG";
            SequenceLog(msg, SvLogger.LogType.DATA);

            return isJudgeOK;
        }

        public override bool Do_ManualCheck()
        {
            bool isJudgeOK = false;
            mIO.SetOutValue(mSystem.OPCallBit, true, false);//op-call

            SequenceLog("ManualAlign Start", Common.SvLogger.LogType.SEQUENCE);

            mManualAlignDispatcher.Invoke(() =>
            {
                ManualAlign wnd = new ManualAlign();
                wnd.InitWnd(mAlignResult, mJob, mSystem.DicProcess[mProcess].FlowType, mIO, mProcData.IOParam.Inputs[InSignal.Complete.ToString()]);
                if (wnd.ShowDialog() == true)
                {
                    isJudgeOK = true;

                    mAlignResult.ObjectRobotPoint.Clear();
                    mAlignResult.TargetPixelPoint.Clear();
                    mAlignResult.TargetRobotPoint.Clear();
                    mAlignResult.TargetRevPoint.Clear();
                    mAlignResult.SendPoint.Clear();

                    isJudgeOK &= Do_ExecuteAlignCalc();
                    isJudgeOK &= CheckLimit();

                    for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
                    {
                        if (!mAlignResult.AlignJudge[i])//judgement false이면 sendpoint 0,0,0 으로 보내준다
                            mAlignResult.SendPoint[i] = new Point3f();
                    }

                    int count = ViewModel.UpdateDisplayCode.Count;
                    ViewModel.UpdateDisplayCode.RemoveRange(2, count - 2);
                    ViewModel.UpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.Display.DrawString("Manual Align", font16, System.Drawing.Brushes.SkyBlue, new Point2d(50, 50));

                        for (int i = 0; i < 1/*mAlignResult.SendPoint.Count*/; i++)
                        {
                            if (!mAlignResult.AlignJudge[i]) continue;
                            for (int j = 0; j < 2; j++)//interactPoint * 2
                            {
                                int idx = i * 2 + j;
                                ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.LightYellow,
                                    new Point2d(mAlignResult.ManualAlignPoint[idx].X, mAlignResult.ManualAlignPoint[idx].Y), 200, 200, mAlignResult.ManualAlignPoint[idx].Z);
                            }
                            // send point * 1
                            ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.OrangeRed,
                                new Point2d(mAlignResult.TargetPixelPoint[i].X, mAlignResult.TargetPixelPoint[i].Y), 100, 100, mAlignResult.TargetPixelPoint[i].Z);
                        }
                    }));
                }
            });
            SequenceLog("ManualAlign End", Common.SvLogger.LogType.SEQUENCE);
            mIO.SetOutValue(mSystem.OPCallBit, false, false);//op-call
            GC.Collect();
            return isJudgeOK;
        }

        public void SaveInspNGImage()
        {
            try
            {
                bool _state = mAlignResult.IsInspectionOK;

                if (mAlignResult.InputImage == null) return;

                string cellID = (cells.Count > 0) ? string.Join("_", cells) : "Unknown";

                // Acquisition Image Save
                if (!_state && DicLogConfig[LogKind.NGImg].IsSave)
                {
                    SvLogger.Log.ErrorImage(mAlignResult.OriginalImage.Mat, cellID, mProcess.ToString(), DicLogConfig[LogKind.NGImg].SaveCount);
                }
            }

            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
            }
        }

        public bool Do_Inspection(bool isJudgeOK)
        {
            try
            {
                // 2) Inspection Judgement part
                // toolblock cnt loop

                int blockCnt = mAlignResult.JobInfo.Count;
                SvRegion region = null;
                SvJudgement judge = null;

                for (int i = 1; i < blockCnt; i++)
                {
                    if (!mAlignResult.JobInfo[i].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    {
                        mAlignResult.List2JudgeResult[i].Add(isJudgeOK);
                        continue;
                    }

                    bool manualCheck = false;
                    region = mAlignResult.JobInfo[i][typeof(SvRegion)][0].Toolbase as SvRegion;
                    judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][0].Toolbase as SvJudgement;

                    if (mProcData.UseManualAlign && mAlignResult.List2JudgeResult[i].Contains(false))
                    {
                        //judgeOk = Do_ManualCheck(i);
                        manualCheck = true;
                    }

                    for (int j = 0; j < mAlignResult.List2JudgeValues[i].Count; j++)
                    {
                        // display
                        string cellID = (cells.Count > 0) ? string.Join("_", cells) : "Unknown";

                        if (!mAlignResult.List2JudgeResult[i][j])
                        {
                            mUpdateDisplayCode.Add(new Action(() =>
                            {
                                ViewModel.Edit.CustomImageList[1].drawingFunc +=
                                (display) =>
                                {
                                    display.DrawString(string.Format("Cell ID : {0}", cellID), font08, System.Drawing.Brushes.Cyan, new Point2d(50, 100));
                                    display.DrawString(string.Format("Inspection Fail"), font08, System.Drawing.Brushes.Red, new Point2d(50, 200));

                                };
                            }));
                        }

                        else
                        {
                            mUpdateDisplayCode.Add(new Action(() =>
                            {
                                ViewModel.Edit.CustomImageList[1].drawingFunc +=
                                (display) =>
                                {
                                    display.DrawString(string.Format("Cell ID : {0}", cellID), font08, System.Drawing.Brushes.Cyan, new Point2d(50, 100));
                                    display.DrawString(string.Format("Inspection OK"), font08, System.Drawing.Brushes.Cyan, new Point2d(50, 200));

                                };
                            }));
                        }
                        region.IncreaseIndex();
                    }
                }
                return mAlignResult.IsInspectionOK;
            }

            catch (Exception ex)
            {
                SequenceLog("DoInspection Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }
        public override bool Do_WriteJudgement()
        {
            //int index;
            //string msg;
            bool isJudgeOk = true;
            isJudgeOk &= base.Do_WriteJudgement();
            //isJudgeOk &= Do_WriteInspection();

            SaveInspNGImage();

            return isJudgeOk;
        }
        public override bool Do_WriteInspection()
        {
            string msg;

            bool isInspOk = true;
            if (mAlignResult.IsInspectionOK && mAlignResult.IsInterfaceOK)
            {
                msg = "INSPECTION OK";
                //mIO.SetOutValue(OutAddr[OutSignal.InspOK.ToString()], true);
            }
            else
            {
                msg = "INSPECTION NG";
                //bool issendOK = mIO.SetOutValue(OutAddr[OutSignal.InspNG.ToString()], true);
                //ViewModel.Judge1 = false;
                isInspOk = false;
            }
            SequenceLog(msg, Common.SvLogger.LogType.SEQUENCE);
            return isInspOk;
        }
        public override bool Do_WriteResult()
        {
            //string strHeader = "Date, Time, PPID, Job, CellID, X, Y, T";
            //string strPattern = "%newline%date{yyyy-MM-dd}, %date{HH:mm:ss.fff}, %message";
            //string strProcess = mProcess.ToString() + "_Film";
            //string cellID = (cells.Count > 0) ? string.Join("", cells) : "Unknown";
            //string msg = string.Format(Auto.mCurrentRecipeName + ", " + mJob.Name + ", " + cellID);

            //if (!Logger.Log.ContainsKey(strProcess))
            //    Logger.Log.Add(strProcess, new LogItem(strProcess, Main.RootPath + "SVL_Data\\Log\\Data\\Film", strHeader, strPattern));

            // send align result
            bool sendOk = WriteRevOffset(mOffsetAddr, mAlignResult.SendPoint);

            sendOk &= Wirte_Judge();

            // FDC Value Write
            //for (int i = 0; i < listInsp.Count; i++)
            //{
            //    sendOk &= mRobot.WriteValue(mFDCAddr, (int)(Math.Round(listInsp[i].X, 4) * 10000));
            //    sendOk &= mRobot.WriteValue(mFDCAddr + 2, (int)(Math.Round(listInsp[i].X, 4) * 10000));
            //    sendOk &= mRobot.WriteValue(mFDCAddr + 4, (int)(Math.Round(listInsp[i].X, 4) * 10000));
            //}
            return sendOk;
        }

        protected bool Wirte_Judge()
        {
            try
            {
                // inspection Result Log 생성 및 저장
                string strHeader = "Date, Time, PPID, Job, CellID, JudgeResult";
                string strPattern = "%newline%date{yyyy-MM-dd}, %date{HH:mm:ss.fff}, %message";
                string strProcess = mProcess.ToString() + "_Film";
                string cellID = (cells.Count > 0) ? string.Join("", cells) : "Unknown";
                

                if (!Logger.Log.ContainsKey(strProcess))
                    Logger.Log.Add(strProcess, new LogItem(strProcess, Main.RootPath + "SVL_Data\\Log\\Data\\Film", strHeader, strPattern));

                // send Judge Result
                int result = mAlignResult.List2JudgeResult[1][0] == true ? 1 : 0;
                string judge = mAlignResult.List2JudgeResult[1][0] == true ? "OK ": "NG";

                bool sendOk = mRobot.WriteValue(mInspectAddr, result);
                SequenceLog(result.ToString(), Common.SvLogger.LogType.DATA);

                string msg = string.Format(Auto.mCurrentRecipeName + ", " + mJob.Name + ", " + cellID + ", " + judge);
                //DataLog(result.ToString());
                WriteJudgeLog(strProcess, msg);

                return sendOk;
            }
            catch (Exception ex)
            {
                SequenceLog("Wirte_Judge Exception " + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }
    }
}
