﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using SvMip.Common;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Panel Align 및 Tape 부착 검사 추가
    /// </summary>
    public class AutoThread_Panel_Insp : AutoThread_Panel
    {
        public List<Point3f> listInsp = new List<Point3f>();

        public AutoThread_Panel_Insp(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {

        }

        int mToolblockindex; // toolblock이 있으면 1, 없으면 0
        public override bool Do_InitJob()
        {
            //bool initOK = true;

            //if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvImageConverter)))
            //    initOK &= SetResultImage(typeof(SvImageConverter), 0, 0, "OutputImage");
            //else
            //    initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");
            bool initOK = true;

            // ResultImage Setting
            mAlignResult.ResultImageList.Clear();

            initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)))
            {
                for (int i = 1; i < mAlignResult.JobInfo.Count; i++)
                {
                    //SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][i].Toolbase as SvToolBlock;

                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    {
                        SvJudgement judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][0].Toolbase as SvJudgement;
                        object obj = judge.inParams["Value"].Instance;
                        initOK &= SetResultImage(obj.GetType(), i, 0, "InputImage");
                        continue;
                    }
                    //else if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                    //{
                    //    initOK &= SetResultImage(typeof(SvMakePoint), i, 0, "InputImage");
                    //    continue;
                    //}
                }
            }

            mToolblockindex = mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)) ? 1 : 0;

            initOK &= SetDisplayToolOn(typeof(SvRegion), mToolblockindex, 0);
            initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), mToolblockindex, 0);
            initOK &= SetDisplayToolOn(typeof(SvDistance3P), mToolblockindex, 0);
            initOK &= SetDisplayToolOn(typeof(SvDistance3P), mToolblockindex, 1);
            initOK &= SetDisplayToolOn(typeof(SvMakePoint), mToolblockindex, 0);
            //initOK &= SetDisplayToolOn(typeof(SvMakePoint2), mToolblockindex, 0);

            initOK &= SetResultPoint(typeof(SvMakePoint), mToolblockindex, 0, "OutPoint");
            initOK &= SetInspResult(typeof(SvMakePoint), mToolblockindex, 1, "OutPoint");

            for (int i = 0; i < mAlignResult.JobInfo[mToolblockindex][typeof(SvFindLine)].Count; i++)
                initOK &= SetDisplayToolOn(typeof(SvFindLine), mToolblockindex, i);

            for (int j = 0; j < (mAlignResult.JobInfo[mToolblockindex][typeof(SvIntersectLine)].Count - 1); j++)
                initOK &= SetDisplayToolOn(typeof(SvIntersectLine), mToolblockindex, j);
            


            //for (int i = 0; i < mAlignResult.JobInfo.Count; i++)
            //{
            //    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvFindLine)].Count; j++)
            //        initOK &= SetDisplayToolOn(typeof(SvFindLine), i, j);

            //    if (i == 1)
            //    {
            //        if (!mAlignResult.JobInfo[i].ContainsKey(typeof(SvFindLine)))
            //        {
            //            SequenceLog("[SvFindLine] Set Display Fail", Common.SvLogger.LogType.ERROR);
            //            return false;
            //        }

            //        for (int k = 0; k < mAlignResult.JobInfo[i][typeof(SvIntersectLine)].Count; k++)
            //            initOK &= SetDisplayToolOn(typeof(SvIntersectLine), i, k);

            //        initOK &= SetDisplayToolOn(typeof(SvMakeLine), i, 0);
            //        initOK &= SetDisplayToolOn(typeof(SvMakePoint), i, 0);
            //        initOK &= SetResultPoint(typeof(SvMakePoint), i, 0, "OutPoint");
            //    }

            //    else if (i == 2)
            //    {
            //        for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvIntersectLine)].Count; j++)
            //            initOK &= SetDisplayToolOn(typeof(SvIntersectLine), i, i);

            //        initOK &= SetDisplayToolOn(typeof(SvDistance3P), i, 0);
            //        initOK &= SetDisplayToolOn(typeof(SvDistance3P), i, 1);

            //        for (int k = 0; k < mAlignResult.JobInfo[2][typeof(SvMakePoint2)].Count; k++)
            //            initOK &= SetInspResult(typeof(SvMakePoint2), i, k, "OutPoint");
            //    }

            //}

            // Panel보다 Tray에 신호가 먼저 들어올 수도 있으므로 반드시 InitJob에도 넣어준다.
            // 만약 T-FOF같이 반드시 Panel이 선행되어야(값이 변경됨) 할 경우는 아래 코드 주석처리할 것.
            mAlignResult.ObjectRobotPoint.Clear();

            for (int i = 0; i < mRobotData.LoadPosition.Length; i++)
            {
                mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
                Point3d obP = mAlignResult.ObjectRobotPoint[i];
                mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);
            }

            return initOK;
        }

        public override bool Do_CheckVisionJob()
        {
            bool visionResult = true;

            List<SvToolBlock> listToolblock = new List<SvToolBlock>();
            foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

            // toolblock 이전까지 실행
            mJob.RunBeforeTool(listToolblock[0]);
            visionResult &= CheckVisionJob(mJob, 0);

            SvRegion region = mAlignResult.JobInfo[1][typeof(SvRegion)][0].Toolbase as SvRegion;

            mRegionCount = region.Count_X * region.Count_Y;

            int idx = 1;
            // toolblock inputparams link
            for (int i = 0; i < listToolblock.Count; i++)
            {
                listToolblock[i].GetInParams();
                listToolblock[i].InitOutProperty();

                region.IndexXnext = 0; region.IndexYnext = 0;

                for (mRegionIndex = 0; mRegionIndex < mRegionCount; mRegionIndex++)
                {
                    listToolblock[i].Run();
                    visionResult &= CheckVisionJob(listToolblock[i].ToolJob, i + 1);

                    if (mSystem.DicProcess[mProcess].UseManualAlign && i == 0)
                        makeManualPoints(listToolblock[i].ToolJob, ref idx);

                    region.IncreaseIndex();
                }
            }

            return visionResult;
        }

        protected void makeManualPoints(SvJob job, ref int idx)
        {
            double w = 0, h = 0;
            SvPoint pt = null;
            SvIntersectLine intersect = null;

            foreach (var t in job.ToolList)
            {
                if (t is SvIntersectLine)
                {
                    intersect = t as SvIntersectLine;
                    if (intersect.lastRunSuccess)
                    {
                        if (intersect.outParams.ContainsKey("IntersectPoint"))
                            pt = intersect.outParams["IntersectPoint"] as SvPoint;

                        else continue;
                    }
                    else
                    {
                        w = intersect.InputImage.Width;
                        h = intersect.InputImage.Height;
                        if (idx % 2 == 1)//홀수
                        {
                            pt = new SvPoint(w * 0.3, h * 0.3);//좌, 상
                        }
                        else
                        {
                            pt = new SvPoint(w * 0.7, h * 0.7);//우, 하
                        }
                    }

                    mAlignResult.ManualAlignPoint.Add(pt.Point3d);
                    ++idx;
                }
                else if (t is SvToolBlock)
                {
                    foreach (var tt in ((SvToolBlock)t).ToolJob.ToolList)
                    {
                        if (tt is SvIntersectLine)
                        {
                            intersect = tt as SvIntersectLine;

                            if (intersect.toolName != "IntersectLine(Left)" && intersect.toolName != "IntersectLine(Right)") continue;

                            if (intersect.lastRunSuccess)
                            {
                                pt = intersect.outParams["IntersectPoint"] as SvPoint;
                            }
                            else
                            {
                                w = intersect.InputImage.Width;
                                h = intersect.InputImage.Height;
                                if (idx % 2 == 1)//홀수
                                {
                                    pt = new SvPoint(w * 0.3, h * 0.3);//좌, 상
                                }
                                else
                                {
                                    pt = new SvPoint(w * 0.7, h * 0.7);//우, 하
                                }
                            }

                            mAlignResult.ManualAlignPoint.Add(pt.Point3d);
                            ++idx;
                        }
                    }
                }
            }
        }


        public override bool Do_ExecuteAlignCalc()
        {
            if (RefAutoThread.Count == 0)
                return base.Do_ExecuteAlignCalc();
            else
                return base.Do_ExecuteAlignCalc_NoMove();
        }

        //public override bool Do_ExecuteAlignCalc()
        //{
        //    try
        //    {
        //        SvCalibration cal = mRobotData.Calibrations;
        //        bool isAlignOK = true;

        //        for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
        //        {
        //            // Start Position
        //            mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
        //            Point3d obP = mAlignResult.ObjectRobotPoint[i];
        //            mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);

        //            // Target Position
        //            if (mAlignResult.ResultPoints[i] == null)
        //            {
        //                mAlignResult.TargetPixelPoint.Add(new Point3d());
        //                isAlignOK = false;
        //            }
        //            else
        //            {
        //                mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
        //            }

        //            Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
        //            targetRobot.Z = NormalizeTheta(targetRobot.Z);
        //            mAlignResult.TargetRobotPoint.Add(targetRobot);

        //            // Offset 계산
        //            Point3d offsetedTarget = ApplyTargetOffset(mAlignResult.TargetRobotPoint[i], mRobotData.AlignOffsets[i].Point3d);
        //            mAlignResult.TargetRevPoint.Add(cal.RToT(mAlignResult.ObjectRobotPoint[i], offsetedTarget));

        //            // Send Position
        //            Point3d result3d = mAlignResult.TargetRevPoint[i];
        //            Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
        //            mAlignResult.SendPoint.Add(result3f);
        //        }

        //        return isAlignOK;
        //    }
        //    catch (Exception ex)
        //    {
        //        SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
        //        return false;
        //    }
        //}


        public override bool Do_Judgement()
        {
            bool isJudgeOK = true;

            isJudgeOK = base.Do_Judgement();
            string msg = "AlignJudge ";
            msg += isJudgeOK ? "OK" : "NG";
            SequenceLog(msg, SvLogger.LogType.DATA);

            isJudgeOK = Do_Inspection();
            msg = "TapeJudge ";
            msg += isJudgeOK ? "OK" : "NG";
            SequenceLog(msg, SvLogger.LogType.DATA);

            return isJudgeOK;


            //bool isJudgeOK = mAlignResult.IsVisionOK;
            //bool isJudgeOK = true;
            //try
            //{
            //    for (int i = 0; i < mAlignResult.CheckJobResult.Count && i < mRobotData.LoadPosition.Length; i++)
            //    {
            //        // 개별 판정은 Job Success와 동일하게 적용 - Dual Judgement
            //        mAlignResult.AlignJudge.Add(mAlignResult.CheckJobResult[i]);
            //        // 전체 판정 - Single Judgement
            //        // 실패했을 경우는...
            //        if (mAlignResult.CheckJobResult[i] == false)
            //        {
            //            // 일단 결과 좌표는 0,0,0으로 리셋하고
            //            mAlignResult.SendPoint[i] = new Point3f();
            //            //// 유무검사 여부에 따라 전체 판정을 달리 가져감
            //            //if (mProcData.UseInspect)
            //            //{
            //            //    //isJudgeOK &= !mAlignResult.Existences[i];
            //            //}
            //            //else
            //            //{
            //                isJudgeOK = false;
            //            //}
            //        }

            //        //리미트 체크하고
            //        isJudgeOK &= CheckLimit();

            //        //manual align
            //        if (isJudgeOK == false && mSystem.DicProcess[mProcess].UseManualAlign)
            //        {
            //            isJudgeOK = Do_ManualCheck();
            //        }
            //    }

            //    isJudgeOK = Do_Inspection();

            //    mAlignResult.List2JudgeResult.Add(new List<bool>());
            //    mAlignResult.List2JudgeResult[0].Add(isJudgeOK);
            //}

            //catch (Exception ex)
            //{
            //    SequenceLog("Judgement Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
            //    return false;
            //}

            //return isJudgeOK;
        }

        public override bool Do_ManualCheck()
        {
            bool isJudgeOK = false;
            mIO.SetOutValue(mSystem.OPCallBit, true, false);//op-call

            SequenceLog("ManualAlign Start", Common.SvLogger.LogType.SEQUENCE);

            mManualAlignDispatcher.Invoke(() =>
            {
                ManualAlign wnd = new ManualAlign();
                wnd.InitWnd(mAlignResult, mJob, mSystem.DicProcess[mProcess].FlowType, mIO, mProcData.IOParam.Inputs[InSignal.Complete.ToString()]);
                if (wnd.ShowDialog() == true)
                {
                    isJudgeOK = true;

                    mAlignResult.ObjectRobotPoint.Clear();
                    mAlignResult.TargetPixelPoint.Clear();
                    mAlignResult.TargetRobotPoint.Clear();
                    mAlignResult.TargetRevPoint.Clear();
                    mAlignResult.SendPoint.Clear();

                    isJudgeOK &= Do_ExecuteAlignCalc();
                    isJudgeOK &= CheckLimit();

                    for (int i = 0; i < mAlignResult.SendPoint.Count; i++)
                    {
                        if (!mAlignResult.AlignJudge[i])//judgement false이면 sendpoint 0,0,0 으로 보내준다
                            mAlignResult.SendPoint[i] = new Point3f();
                    }

                    int count = ViewModel.UpdateDisplayCode.Count;
                    ViewModel.UpdateDisplayCode.RemoveRange(2, count - 2);
                    ViewModel.UpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.Display.DrawString("Manual Align", font16, System.Drawing.Brushes.SkyBlue, new Point2d(50, 50));

                        for (int i = 0; i < 1/*mAlignResult.SendPoint.Count*/; i++)
                        {
                            if (!mAlignResult.AlignJudge[i]) continue;
                            for (int j = 0; j < 2; j++)//interactPoint * 2
                            {
                                int idx = i * 2 + j;
                                ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.LightYellow,
                                    new Point2d(mAlignResult.ManualAlignPoint[idx].X, mAlignResult.ManualAlignPoint[idx].Y), 200, 200, mAlignResult.ManualAlignPoint[idx].Z);
                            }
                            // send point * 1
                            ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.OrangeRed,
                                new Point2d(mAlignResult.TargetPixelPoint[i].X, mAlignResult.TargetPixelPoint[i].Y), 100, 100, mAlignResult.TargetPixelPoint[i].Z);
                        }

                        //foreach(var pnt in mAlignResult.ManualAlignPoint)
                        //    ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.LightYellow, new Point2d(pnt.X, pnt.Y), 200, 200, pnt.Z);
                        //foreach (var pnt in mAlignResult.TargetPixelPoint)
                        //    ViewModel.Edit.Display.DrawCross(System.Drawing.Pens.OrangeRed, new Point2d(pnt.X, pnt.Y), 100, 100, pnt.Z);
                    }));
                }
            });
            SequenceLog("ManualAlign End", Common.SvLogger.LogType.SEQUENCE);
            mIO.SetOutValue(mSystem.OPCallBit, false, false);//op-call
            GC.Collect();
            return isJudgeOK;
        }

        public override bool Do_Inspection()
        {
            bool isInspectionOK = true;

            Point3d InspResult3d = new Point3d();
            SvCalibration cal = mRobotData.Calibrations;

            if (mAlignResult.InspResultPoints.Count == 0)
            {
                isInspectionOK = false;
                return isInspectionOK;
            }

            listInsp.Clear();
            for (int i = 0; i < mAlignResult.InspResultPoints.Count; i++)
            {
                //InspResult3d = (mAlignResult.InspResultPoints[mAlignResult.InspResultPoints.Count - 1] as SvPoint).Point3d;
                InspResult3d = (mAlignResult.InspResultPoints[i] as SvPoint).Point3d;

                Point3d Temp = new Point3d(0, 0, 0);
                Temp = cal.VtoR(Temp, true, true);

                Point3d temp_X = new Point3d(InspResult3d.X, 0, 0);
                temp_X = cal.VtoR(temp_X, true, true);

                Point3d temp_Y = new Point3d(0, InspResult3d.Y, 0);
                temp_Y = cal.VtoR(temp_Y, true, true);

                InspResult3d.Z = NormalizeTheta(InspResult3d.Z);
                InspResult3d.X = Math.Abs(temp_X.X - Temp.X);
                InspResult3d.Y = Math.Abs(temp_Y.Y - Temp.Y);

                Point3f InspResult3f = new Point3f((float)InspResult3d.X, (float)InspResult3d.Y, (float)(InspResult3d.Z * 180 / Math.PI));

                float d1Max = mModelData.TapeD1 + mModelData.TapeDistTolerance;
                float d1Min = mModelData.TapeD1 - mModelData.TapeDistTolerance;
                float d2Max = mModelData.TapeD2 + mModelData.TapeDistTolerance;
                float d2Min = mModelData.TapeD2 - mModelData.TapeDistTolerance;
                float thetaMax = mModelData.TapeTheta + mModelData.TapeAngleTolerance;
                float thetaMin = mModelData.TapeTheta - mModelData.TapeAngleTolerance;

                if (InspResult3f.X > d1Max || InspResult3f.X < d1Min || InspResult3f.Y > d2Max || InspResult3f.Y < d2Min || InspResult3f.Z > thetaMax || InspResult3f.Z < thetaMin)
                {
                    isInspectionOK = false;
                    listInsp.Add(new Point3f(0, 0, 0));

                    string msg;

                    if (InspResult3f.X > d1Max || InspResult3f.X < d1Min)
                    {
                        msg = string.Format("OBJ {0}_Tape D1 NG : {1} (Spec : {2} ± {3}", i, InspResult3f.X, mModelData.TapeD1, mModelData.TapeDistTolerance);
                        SequenceLog(msg, SvLogger.LogType.ERROR);
                    }
                    if (InspResult3f.Y > d2Max || InspResult3f.Y < d2Min)
                    {
                        msg = string.Format("OBJ {0}_Tape D2 NG : {1} (Spec : {2} ± {3}", i, InspResult3f.Y, mModelData.TapeD2, mModelData.TapeDistTolerance);
                        SequenceLog(msg, SvLogger.LogType.ERROR);
                    }
                    if (InspResult3f.Z > thetaMax || InspResult3f.Z < thetaMin)
                    {
                        msg = string.Format("OBJ {0}_Tape Angle NG : {1} (Spec : {2} ± {3}", i, InspResult3f.Z, mModelData.TapeTheta, mModelData.TapeAngleTolerance);
                        SequenceLog(msg, SvLogger.LogType.ERROR);
                    }
                }

                else
                {
                    listInsp.Add(InspResult3f);
                    //mAlignResult.SendPoint.Add(InspResult3f);
                }

                mAlignResult.SendPoint.Add(listInsp[i]);
            }

            return isInspectionOK;
        }
        public override bool Do_WriteJudgement()
        {
            //int index;
            //string msg;
            bool isJudgeOk = true;
            isJudgeOk &= base.Do_WriteJudgement();
            isJudgeOk &= Do_WriteInspection();
            
            return isJudgeOk;
        }


        public override bool Do_WriteInspection()
        {
            string msg;

            bool isInspOk = true;
            
            if (mAlignResult.IsInspectionOK && mAlignResult.IsInterfaceOK)
            {
                msg = "Tape INSPECTION  OK";
                //mIO.SetOutValue(OutAddr[OutSignal.InspOK.ToString()], true);
            }
            else
            {
                msg = "Tape INSPECTION NG";
                mIO.SetOutValue(OutAddr[OutSignal.InspNG.ToString()], true, false);
                ViewModel.Judge1 = false;
                isInspOk = false;
            }
            SequenceLog(msg, Common.SvLogger.LogType.SEQUENCE);
            return isInspOk;
        }
        public override bool Do_WriteResult()
        {
            bool sendOk = mRobot.WritePositions(mOffsetAddr, mAlignResult.SendPoint);

            for (int i = 0; i < listInsp.Count; i++)
            {
                SequenceLog(string.Format("Rev: ({0:f3}, {1:f3}, {2:f3})", mAlignResult.SendPoint[i].X, mAlignResult.SendPoint[i].Y, mAlignResult.SendPoint[i].Z), SvLogger.LogType.DATA);
                DataLog(mAlignResult.SendPoint[i].X.ToString(), mAlignResult.SendPoint[i].Y.ToString(), mAlignResult.SendPoint[i].Z.ToString());

                SequenceLog(string.Format("Tape D1 : {0:f2}㎜ ", listInsp[i].X), SvLogger.LogType.DATA);
                SequenceLog(string.Format("Tape D2 : {0:f2}㎜ ", listInsp[i].Y), SvLogger.LogType.DATA);
                SequenceLog(string.Format("Tape Angle : {0:f2}˚ ", listInsp[i].Z), SvLogger.LogType.DATA);
                DataLog(listInsp[i].X.ToString(), listInsp[i].Y.ToString(), listInsp[i].Z.ToString());

                string msg = string.Format("Tape D1 : {0:F2}㎜\nTape D2 : {1:F2}㎜\nTape Angle : {2:f2}˚", listInsp[i].X, listInsp[i].Y, listInsp[i].Z);

                //int blockindex = 1;
                if (i == 0)
                {
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.CustomImageList[1].drawingFunc +=
                        (display) =>
                        {
                            display.DrawString(msg, font08, System.Drawing.Brushes.Cyan, new Point2d(50, 200));
                        };
                    }));
                }
                else
                {
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.CustomImageList[1].drawingFunc +=
                        (display) =>
                        {
                            display.DrawString(msg, font08, System.Drawing.Brushes.Cyan, new Point2d(1050, 200));
                        };
                    }));
                }

            }
            return sendOk;

        }
    }
}
