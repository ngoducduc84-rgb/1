﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using SvMip.Common;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Panel Align_Cal미사용
    /// </summary>
    public class AutoThread_Panel_NoCal : AutoThread_Panel_Total
    {
        public AutoThread_Panel_NoCal(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {

        }
        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                //resolution log남길까?? 필요할까???
                double widthlength_pixel = 0, heightlength_pixel = 0, resolution = 0;

                bool isAlignOK = true;
                SvMakeRectFromLine rect = mAlignResult.JobInfo[ListAlignIndex[0]][typeof(SvMakeRectFromLine)][0].Toolbase as SvMakeRectFromLine;
                widthlength_pixel = Point2d.Distance(new Point2d(rect.ResultPoints[0].X, rect.ResultPoints[0].Y), new Point2d(rect.ResultPoints[1].X, rect.ResultPoints[1].Y));
                heightlength_pixel = Point2d.Distance(new Point2d(rect.ResultPoints[1].X, rect.ResultPoints[1].Y), new Point2d(rect.ResultPoints[2].X, rect.ResultPoints[2].Y));
                resolution = (mRobotData.TrayWidth / widthlength_pixel + mRobotData.TrayHeight / heightlength_pixel) / 2;

                for (int i = 0; i < mAlignResult.ResultPoints.Count && i < mRobotData.LoadPosition.Length; i++)
                {
                    // Start Position
                    mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
                    Point3d obP = mAlignResult.ObjectRobotPoint[i];
                    mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);

                    // Target Position
                    if (mAlignResult.ResultPoints[i] == null)
                    {
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        isAlignOK = false;
                    }
                    else
                    {
                        mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    }

                    Point3d offsetedTarget = mAlignResult.TargetPixelPoint[i] - mAlignResult.ObjectRobotPoint[i];
                    mAlignResult.TargetRevPoint.Add(new Point3d(offsetedTarget.X * resolution, offsetedTarget.Y * resolution, offsetedTarget.Z));
                    //Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    //targetRobot.Z = NormalizeTheta(targetRobot.Z);
                    //mAlignResult.TargetRobotPoint.Add(targetRobot);

                    //// Offset 계산
                    //Point3d offsetedTarget = ApplyTargetOffset(mAlignResult.TargetRobotPoint[i], mRobotData.AlignOffsets[i].Point3d);
                    //if (cal.RotCenter.X == 0 && cal.RotCenter.Y == 0) // T-축이 없을경우는 그냥 X,Y 값을 빼준다...
                    //    offsetedTarget.Z = mAlignResult.ObjectRobotPoint[i].Z;
                    //mAlignResult.TargetRevPoint.Add(cal.RToT(mAlignResult.ObjectRobotPoint[i], offsetedTarget));

                    // Send Position
                    Point3d result3d = mAlignResult.TargetRevPoint[i];
                    Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
                    mAlignResult.SendPoint.Add(result3f);
                }
                return isAlignOK;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }

        
    }
}
