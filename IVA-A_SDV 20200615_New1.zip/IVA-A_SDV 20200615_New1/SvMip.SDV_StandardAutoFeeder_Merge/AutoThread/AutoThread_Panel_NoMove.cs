﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Robot이 Panel pick up 후 Align
    /// </summary>
    public class AutoThread_Panel_NoMove : AutoThread_Panel
    {
        public AutoThread_Panel_NoMove(SystemData _system, RecipeData _recipe, Main.Process _process) : base(_system, _recipe, _process)
        { }

        public override bool Do_ExecuteAlignCalc()
        {
            return base.Do_ExecuteAlignCalc_NoMove();
        }

        public override bool Do_WriteResult()
        {
            bool isWriteOK = true;
            for (int i = 0; i < mRefAutoThread.Count; i++)
                isWriteOK &= mRefAutoThread[i].Do_WriteResult();
				
            return isWriteOK;
        }
    }
}
