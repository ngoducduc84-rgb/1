﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Robot이 Panel pick up 후 Align
    /// </summary>
    public class AutoThread_Panel_Put : AutoThread_Panel
    {
        public AutoThread_Panel_Put(SystemData _system, RecipeData _recipe, Main.Process _process) : base(_system, _recipe, _process)
        { }

        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;
                bool isAlignOK = true;

                mAlignResult.TargetRobotPoint.Clear();
                mAlignResult.ObjectRobotPoint.Clear();
                mAlignResult.SendPoint.Clear();

                for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
                {
                    //Point3d obP = mRobotData.LoadPosition[i].Point3d;
                    // Target Position
                    if (mAlignResult.ResultPoints[i] == null)
                    {
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        isAlignOK = false;
                    }
                    else
                    {
                        mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    }

                    Point3d resultRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    resultRobot.Z = NormalizeTheta(resultRobot.Z);

                    mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d);
                    mAlignResult.TargetRobotPoint.Add(resultRobot);
                    mAlignResult.TargetRevPoint.Add(new Point3d());

                    // Offset 계산
                    //Point3d offsetedTarget = ApplyTargetOffset(mAlignResult.TargetRobotPoint[i], obP);
                }

                for (int i = 0; i < mRefAutoThread.Count; i++)
                {
                    isAlignOK &= mRefAutoThread[i].Do_ExecuteAlignCalc();
                    SequenceLog(string.Format("Rev : ({0:f3}, {1:f3}, {2:f3})",
                        mAlignResult.ObjectRobotPoint[i].X, mAlignResult.ObjectRobotPoint[i].Y, mAlignResult.ObjectRobotPoint[i].Z), Common.SvLogger.LogType.DATA);
                }

                return isAlignOK;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }

        public override bool Do_WriteResult()
        {
            bool isWriteOK = true;
            for (int i = 0; i < mRefAutoThread.Count; i++)
                isWriteOK &= mRefAutoThread[i].Do_WriteResult();
				
            return isWriteOK;
        }
    }
}
