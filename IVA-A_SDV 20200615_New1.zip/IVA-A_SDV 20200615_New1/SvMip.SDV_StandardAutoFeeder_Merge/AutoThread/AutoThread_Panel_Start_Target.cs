﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Robot이 Panel pick up 후 Align
    /// </summary>
    public class AutoThread_Panel_Start_Target : AutoThread_Panel_Total
    {
        public AutoThread_Panel_Start_Target(SystemData _system, RecipeData _recipe, Main.Process _process) : base(_system, _recipe, _process)
        { }

        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;
                bool isAlignOK = true;

                mAlignResult.TargetRobotPoint.Clear();
                mAlignResult.ObjectRobotPoint.Clear();
                mAlignResult.SendPoint.Clear();

                for (int i = 0; i < mAlignResult.ResultPoints.Count / 2; i++)
                {
                    // Target Position
                    if (mAlignResult.ResultPoints[i] == null)
                    {
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        isAlignOK = false;
                    }
                    else
                    {
                        mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    }

                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    targetRobot.Z = NormalizeTheta(targetRobot.Z);
                    mAlignResult.ObjectRobotPoint.Add(targetRobot);

                    // Send Position
                    //Point3d result3d = mAlignResult.TargetRevPoint[i];
                    //Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
                    //mAlignResult.SendPoint.Add(result3f);

                }

                for (int i = mAlignResult.ResultPoints.Count / 2; i < mAlignResult.ResultPoints.Count; i++)
                {
                    // Target Position
                    if (mAlignResult.ResultPoints[i] == null)
                    {
                        mAlignResult.TargetPixelPoint.Add(new Point3d());
                        isAlignOK = false;
                    }
                    else
                    {
                        mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    }

                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    targetRobot.Z = NormalizeTheta(targetRobot.Z);
                    mAlignResult.TargetRobotPoint.Add(targetRobot);
                }

                for (int i = 0; i < mAlignResult.ResultPoints.Count / 2; i++)
                {
                    Point3d result3d = cal.RToT(mAlignResult.ObjectRobotPoint[i], mAlignResult.TargetRobotPoint[i]);
                    mAlignResult.TargetRevPoint.Add(result3d);
                    // Send Position
                    if (result3d.Z > Math.PI) result3d.Z -= 2 * Math.PI;
                    else if (result3d.Z < -Math.PI) result3d.Z += 2 * Math.PI;

                    Point3f result3f = new Point3f((float)result3d.X + (float)mRobotData.AlignOffsets[i].Point3d.X, (float)result3d.Y + (float)mRobotData.AlignOffsets[i].Point3d.Y, (float)((result3d.Z * 180 / Math.PI)+(float)mRobotData.AlignOffsets[i].Point3d.Z));//[j];
                    mAlignResult.SendPoint.Add(result3f);
                    // Send Position
                    //Point3d result3d = mAlignResult.TargetRevPoint[i];
                    //Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
                    //mAlignResult.SendPoint.Add(result3f);

                }

                return isAlignOK;
            }
            catch (Exception ex)
            {
                SequenceLog("ExecuteAlignCalc Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }
        }

        public override bool Do_Judgement()
        {
            bool isJudgeOK = true;
            try
            {
                // 1) Align Part
                for (int i = 0; i < mAlignResult.CheckJobResult.Count; i++)
                {
                    // 개별 판정은 Job Success와 동일하게 적용 - Dual Judgement
                    mAlignResult.AlignJudge.Add(mAlignResult.CheckJobResult[i]);
                    // 전체 판정 - Single Judgement
                    // 실패했을 경우는...
                    //if(mAlignResult.Existences[i] == false)
                    if (mAlignResult.CheckJobResult[i] == false)
                    {
                        // 일단 결과 좌표는 0,0,0으로 리셋하고
                        if (mAlignResult.SendPoint.Count != 0)
                            mAlignResult.SendPoint[i] = new Point3f();

                        // 유무검사 여부에 따라 전체 판정을 달리 가져감
                        if (mProcData.UseInspect)
                        {
                            isJudgeOK &= !mAlignResult.Existences[i];
                        }
                        else
                        {
                            isJudgeOK = false;
                        }
                    }
                }


                //리미트 체크하고
                isJudgeOK &= CheckLimit();

                //manual align
                if (isJudgeOK == false && mSystem.DicProcess[mProcess].UseManualAlign)
                {
                    isJudgeOK = Do_ManualCheck();
                }
            }
            catch (Exception ex)
            {
                SequenceLog("Judgement Exception" + ex, Common.SvLogger.LogType.ERROR);
                return false;
            }

            return isJudgeOK;
        }

        //public override bool Do_WriteResult()
        //{
        //    bool isWriteOK = true;
        //    for (int i = 0; i < mRefAutoThread.Count; i++)
        //        isWriteOK &= mRefAutoThread[i].Do_WriteResult();

        //    return isWriteOK;
        //}
    }
}
