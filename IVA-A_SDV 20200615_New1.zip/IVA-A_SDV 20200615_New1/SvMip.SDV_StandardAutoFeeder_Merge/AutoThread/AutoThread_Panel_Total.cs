﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using SvMip.Common;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public class AutoThread_Panel_Total : AutoThread_Panel
    {
        public List<Point3f> listInsp = new List<Point3f>();

        public AutoThread_Panel_Total(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {

        }

        int mToolblockindex; // toolblock이 있으면 1, 없으면 0
        
        public override bool Do_InitJob()
        {
            bool initOK = true;

            // ResultImage Setting
            mAlignResult.ResultImageList.Clear();

            initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)))
            {
                for (int i = 1; i < mAlignResult.JobInfo.Count; i++)
                {
                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    {
                        for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvJudgement)].Count; j++)
                        {
                            SvJudgement judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][j].Toolbase as SvJudgement;
                            if (judge.inParams.ContainsKey("InputImage"))
                            {
                                initOK &= SetResultImage(typeof(SvJudgement), i, j, "InputImage");
                            }
                            else
                            {
                                object obj = judge.inParams["Value"].Instance;
                                initOK &= SetResultImage(obj.GetType(), i, j, "InputImage");
                            }
                            //else if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvRegion)))
                            //{
                            //    initOK &= SetResultImage(typeof(SvRegion), i, 0, "InputImage");
                            //}

                            //judgeidx++;
                        }
                    }
                    //else if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                    //{
                    //    initOK &= SetResultImage(typeof(SvMakePoint), i, 0, "InputImage");
                    //    continue;
                    //}
                }
            }

            // DisplayTool Setting
            for (int i = 0; i < mAlignResult.JobInfo.Count; i++)
            {
                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                {
					ListJudgeIndex.Add(i);
                    initOK &= SetDisplayToolOn(typeof(SvJudgement), i);
                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvJudgement)].Count; j++)
                    {
                        initOK &= SetResultJudgement(typeof(SvJudgement), i, j, "Judgement");
                    }
                }

                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                {
                    ListAlignIndex.Add(i);
                    initOK &= SetDisplayToolOn(typeof(SvMakePoint), i);
                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvMakePoint)].Count; j++)
                    {
                        initOK &= SetResultPoint(typeof(SvMakePoint), i, j, "OutPoint");
                    }
                }

                SetDisplayToolOn(typeof(SvJudgement), i);
                SetDisplayToolOn(typeof(SvFindLine), i);
                SetDisplayToolOn(typeof(SvTemplateMatch), i);
                SetDisplayToolOn(typeof(SvIntersectLine), i);
                SetDisplayToolOn(typeof(SvMakeRectFromLine), i);
                SetDisplayToolOn(typeof(SvDistance3P), i);
            }

            // Panel보다 Tray에 신호가 먼저 들어올 수도 있으므로 반드시 InitJob에도 넣어준다.
            // 만약 T-FOF같이 반드시 Panel이 선행되어야(값이 변경됨) 할 경우는 아래 코드 주석처리할 것.
            mAlignResult.ObjectRobotPoint.Clear();

            for (int i = 0; i < mRobotData.LoadPosition.Length; i++)
            {
                mAlignResult.ObjectRobotPoint.Add(mRobotData.LoadPosition[i].Point3d/* - mRobotData.AlignOffsets[i].Point3d*/);
                Point3d obP = mAlignResult.ObjectRobotPoint[i];
                mAlignResult.ObjectRobotPoint[i] = new Point3d(obP.X, obP.Y, obP.Z * PI / 180);
            }

            return initOK;
        }

        public override bool Do_CheckVisionJob()
        {
            try
            {
                // initialize
                bool visionResult = true;

                List<SvToolBlock> listToolblock = new List<SvToolBlock>();
                listToolblock.Add(null);
                foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                    listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

                mAlignResult.List2JudgeValues.Clear();
                mAlignResult.List2JudgeSpec.Clear();
                mAlignResult.List2JudgeResult.Clear();
                mAlignResult.ManualCheckJudge.Clear();

                int idx = 1;

                // toolblock 이전까지 실행
                mJob.RunBeforeTool(listToolblock[1]);
                visionResult &= CheckVisionJob(mJob, 0);

                for (int i = 1; i < listToolblock.Count; i++)
                {
                    // region은 toolblock당 무조건 하나로!! <= 규칙, 만약 없으면 Exception!!
                    SvRegion region = mAlignResult.JobInfo[i][typeof(SvRegion)][0].Toolbase as SvRegion;

                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    {
                        for (int j = 0; j <= mAlignResult.JobInfo[i][typeof(SvJudgement)].Count; j++)
                        {
                            mAlignResult.List2JudgeValues.Add(new List<double>());
                            mAlignResult.List2JudgeSpec.Add(new List<double>());
                            mAlignResult.List2JudgeResult.Add(new List<bool>());
                        }
                    }

                    // toolblock inputparams link
                    listToolblock[i].GetInParams();
                    listToolblock[i].InitOutProperty();

                    region.IndexXnext = 0; region.IndexYnext = 0;
                    mRegionCount = region.Count_X * region.Count_Y;

                    // region cnt loop
                    for (mRegionIndex = 0; mRegionIndex < mRegionCount; mRegionIndex++)
                    {
                        if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                        {
                            for (int k = 0; k < mAlignResult.JobInfo[i][typeof(SvJudgement)].Count; k++)
                            {
                                SvJudgement judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][k].Toolbase as SvJudgement;
                                if (judge != null && judge.Thresholds.Count == mRegionCount)
                                    judge.Creteria = judge.Thresholds[mRegionIndex];
                            }
                        }

                        listToolblock[i].Run();

                        if (mSystem.DicProcess[mProcess].UseManualAlign)
                            makeManualPoints(listToolblock[i].ToolJob, ref idx);

                        //if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                        //{
                        //    for (int k = 0; k < mAlignResult.JobInfo[i][typeof(SvJudgement)].Count; k++)
                        //    {
                        //        SvJudgement judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][k].Toolbase as SvJudgement;
                        visionResult &= CheckVisionJob(listToolblock[i].ToolJob, i, false);
                        //    }
                        //}
                        
                        region.IncreaseIndex();
                    }
                }
                return visionResult;
            }
            catch (Exception e)
            {
                SequenceLog(e.ToString(), Common.SvLogger.LogType.ERROR);
                return false;
            }
        }


        public override bool Do_ExecuteAlignCalc()
        {
            if (RefAutoThread.Count == 0)
                return base.Do_ExecuteAlignCalc();
            else
                return base.Do_ExecuteAlignCalc_NoMove();
        }

        //public override bool Inspection()
        //{
        //    bool isInspOK = true;

        //    //if (mProcData.InspectType == EInspectType.Judgement)
        //    {
        //        for (int i = 0; i < mAlignResult.List2JudgeResult.Count; i++)
        //        {
        //            if (mAlignResult.List2JudgeResult[i].Contains(false))
        //                isInspOK = false;
        //        }
        //    }

        //    string msg = "Inspection ";
        //    msg += isInspOK == true ? "OK" : "NG";
        //    SvLogger.LogType logtype = isInspOK == true ? SvLogger.LogType.SEQUENCE : SvLogger.LogType.ERROR;

        //    SequenceLog(msg, logtype);
        //    return isInspOK;
        //}


        public override bool Do_Judgement()
        {
            bool isJudgeOK = true;

            if (ListAlignIndex.Count > 0)
            {
                isJudgeOK = base.Do_Judgement();
                string msg = "AlignJudge ";
                msg += isJudgeOK ? "OK" : "NG";
                SequenceLog(msg, SvLogger.LogType.DATA);
            }

            //if (ListJudgeIndex.Count > 0)
            //    isJudgeOK &= Check_Panel_Judge();

            return isJudgeOK;
        }

        public override bool Do_WriteResult()
        {
            // exist
            int sendVal;
            string result = "";
            bool sendresult = true;
            int lastPos = 0;
            int blockCnt = (mAlignResult.JobInfo.Count - 1);
            // inspect
            for (int k = 1; k <= ListJudgeIndex.Count; k++)
            {
                if (!mAlignResult.JobInfo[blockCnt].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[blockCnt].ContainsKey(typeof(SvJudgement)))
                {
                    continue;
                }

                result = "";
                sendVal = 0xFFFF;
                for (int i = 0; i < mAlignResult.List2JudgeResult[k].Count; i++)
                {
                    SetBit(ref sendVal, i, mAlignResult.List2JudgeResult[k][i]);

                    int slog = mAlignResult.List2JudgeResult[k][i] == true ? 1 : 0;
                    result = slog + result;
                }

                lastPos = mInspectAddr + ((k - 1) * 2);
                sendresult &= mRobot.WriteValue(lastPos, sendVal);
                SequenceLog(result, Common.SvLogger.LogType.DATA);
                DataLog(result);
            }

            // align offset
            lastPos = mOffsetAddr;
            if (mAlignResult.SendPoint.Count > 0)
                sendresult &= WriteRevOffset(lastPos, mAlignResult.SendPoint);//2워드 이후부터 위치값 저장한다..

            return sendresult;
        }


        //public override bool Do_WriteJudgement()
        //{
        //    bool isJudgeOk = base.Do_WriteJudgement();
        //    return isJudgeOk;
        //}


        //public override bool Do_WriteInspection()
        //{
        //    string msg;
        //    if (mAlignResult.IsInspectionOK && mAlignResult.IsInterfaceOK)
        //    {
        //        msg = "Tape INSPECTION  OK";
        //        //mIO.SetOutValue(OutAddr[OutSignal.InspOK.ToString()], true);
        //    }
        //    else
        //    {
        //        msg = "Tape INSPECTION NG";
        //        mIO.SetOutValue(OutAddr[OutSignal.InspNG.ToString()], true);
        //        ViewModel.Judge1 = false;
        //    }
        //    SequenceLog(msg, Common.SvLogger.LogType.SEQUENCE);
        //    return true;
        //}
        //public override bool Do_WriteResult()
        //{
        //    bool sendOk = false;

        //    for (int i = 0; i < listInsp.Count; i++)
        //    {
        //        mAlignResult.SendPoint.Add(listInsp[i]);

        //        sendOk = mRobot.WritePositions(mRobotWriteAddress, mAlignResult.SendPoint);

        //        SequenceLog(string.Format("Rev: ({0:f3}, {1:f3}, {2:f3})", mAlignResult.SendPoint[i].X, mAlignResult.SendPoint[i].Y, mAlignResult.SendPoint[i].Z), SvLogger.LogType.DATA);
        //        DataLog(mAlignResult.SendPoint[i].X.ToString(), mAlignResult.SendPoint[i].Y.ToString(), mAlignResult.SendPoint[i].Z.ToString());

        //        SequenceLog(string.Format("Tape D1 : {0:f3}㎜ ", listInsp[i].X), SvLogger.LogType.DATA);
        //        SequenceLog(string.Format("Tape D2 : {0:f3}㎜ ", listInsp[i].Y), SvLogger.LogType.DATA);
        //        SequenceLog(string.Format("Tape Angle : {0:f2}˚ ", listInsp[i].Z), SvLogger.LogType.DATA);
        //        DataLog(listInsp[i].X.ToString(), listInsp[i].Y.ToString(), listInsp[i].Z.ToString());
        //        string msg = string.Format("Tape D1 : {0:F3}㎜\nTape D2 : {1:F3}㎜\nTape Angle : {2:f2}˚", listInsp[i].X, listInsp[i].Y, listInsp[i].Z);

        //        if (i == 0)
        //        {
        //            this.mUpdateDisplayCode.Add(new Action(() =>
        //            {
        //                ViewModel.Edit.Display.DrawString(msg, font08, System.Drawing.Brushes.Cyan, new Point2d(50, 200));
        //            }));
        //        }

        //        else
        //        {
        //            this.mUpdateDisplayCode.Add(new Action(() =>
        //            {
        //                ViewModel.Edit.Display.DrawString(msg, font08, System.Drawing.Brushes.Cyan, new Point2d(1050, 200));
        //            }));
        //        }

        //    }
        //    return sendOk;

        //}
    }
}
