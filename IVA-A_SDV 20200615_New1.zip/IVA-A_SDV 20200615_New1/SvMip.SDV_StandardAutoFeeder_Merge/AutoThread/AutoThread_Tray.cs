﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using SvMip.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Tray Align (PreAlign이 있는 경우, 즉 reference가 필요)
    /// </summary>
    public class AutoThread_Tray : AutoThread_Base
    {
        public AutoThread_Tray(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        { }

        protected double WD = 0;
        protected Point2d PerspectiveP = new Point2d();
        public override bool Do_InitJob()
        {
            bool initOK = true;

            // Toolblock check
            if (mAlignResult.JobInfo.Count < 2)
            {
                SequenceLog("There is no Toolblock!!", Common.SvLogger.LogType.ERROR);
                return false;
            }

            // Result Image Set
            if(mAlignResult.JobInfo[0].ContainsKey(typeof(SvImageConverter)))
                initOK &=SetResultImage(typeof(SvImageConverter), 0, 0,"OutputImage");
            else
                initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            // FindLine Tool Set
            if (!mAlignResult.JobInfo[0].ContainsKey(typeof(SvFindLine)))
            {
                SequenceLog("[SvFindLine] Set Display Fail", Common.SvLogger.LogType.ERROR);
                return false;
            }
            for (int i = 0; i < mAlignResult.JobInfo[0][typeof(SvFindLine)].Count; i++)
                initOK &= SetDisplayToolOn(typeof(SvFindLine), 0, i);

            // MakeRectFromLine Set
            initOK &= SetDisplayToolOn(typeof(SvMakeRectFromLine), 0, 0);

            // Inspection Set
            if (mProcData.UseInspect)
            {
                for (int i = 0; i < mAlignResult.JobInfo.Count; i++)
                {
                    if (mProcData.InspectTool == EInspectTool.Templete)
                    {
                        if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvTemplateMatch)))
                        {
                            initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), i, 0);
                        }
                    }
                    else
                    {
                        if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvHistogram)))
                        {
                            initOK &= SetDisplayToolOn(typeof(SvHistogram), i, 0);
                        }
                    }
                }
            }

            //for (int i = 0; i < mAlignResult.JobInfo.Count; i++)
            //{
            //    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvTemplateMatch)))
            //        initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), i, 0);
            //}

            // Result Tool Set
            //initOK &= SetDisplayToolOn(typeof(SvMakePoint), 1, 0);
            if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvMakePoint)))
            {
                SequenceLog("[SvMakePoint] Set Result Point Fail", Common.SvLogger.LogType.ERROR);
                return false;
            }

            ListAlignIndex.Add(1);

            for (int i = 1; i < mAlignResult.JobInfo.Count; i++)
            {
                if (!mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                    continue;

                for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvMakePoint)].Count; j++)
                {
                    initOK &= SetDisplayToolOn(typeof(SvMakePoint), i, j);
                    initOK &= SetResultPoint(typeof(SvMakePoint), i, j, "OutPoint");
                }
            }

            // tray2robot
            SvCalibration cal = mRobotData.Calibrations;

            if (mProcData.FocalLength == 0)
                SequenceLog("[SystemData] Data.FocalLengrh is 0, so cann't use Tray to Robot perspective warrping", Common.SvLogger.LogType.SEQUENCE);
            else
                cal.GetPerspectivePoint(mProcData.FocalLength, mProcData.SensorWidth, mProcData.SensorHeight, out PerspectiveP, out WD);

            return initOK;
        }

        public override bool Do_CheckVisionJob()
        {
            List<SvToolBlock> listToolblock = new List<SvToolBlock>();
            foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

            SvTemplateMatch templete = null;
            if (mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete)
            {
                if (mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete)
                    templete = mAlignResult.JobInfo[1][typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;
            }

            bool visionResult = true;

            // toolblock 이전까지 실행
            mJob.RunBeforeTool(listToolblock[0]);
            visionResult &= CheckVisionJob(mJob, 0);

            // toolblock inputparams link
            for (int i = 0; i < listToolblock.Count; i++)
            {
                for (int j = 0; j < mAlignResult.JobInfo[i + 1][typeof(SvRegion)].Count; j++)
                {
                    SvRegion region = mAlignResult.JobInfo[i + 1][typeof(SvRegion)][j].Toolbase as SvRegion;

                    listToolblock[i].GetInParams();
                    listToolblock[i].InitOutProperty();

                    mRegionCount = region.Count_X * region.Count_Y;
                    region.IndexXnext = 0; region.IndexYnext = 0;

                    for (mRegionIndex = 0; mRegionIndex < mRegionCount; mRegionIndex++)
                    {
                        if (mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete)
                            templete.SelectedPatternIndex = mRegionIndex;

                        listToolblock[i].Run();
                        visionResult &= CheckVisionJob(listToolblock[i].ToolJob, i + 1);

                        // 유무 판단은 저지먼트에서 하는 걸로 .. 중간에 비전 NG 처리 하지말자..
                        //if (mProcData.UseInspect && mProcData.InspectType == EInspectType.Judgement && !visionResult)
                        //    return visionResult;

                        region.IncreaseIndex();
                    }
                }
            }

            return visionResult;
        }
        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                // 트레이는 Job Fail이면 보정값 사용할 수 없음.. 그냥 false return
                // Inspection 사용할 경우 무조건 Job은 Success되도록 설정한 후 Do_Judgement에서 유무만 판정할 것
                if (!AlignResult.IsVisionOK) return false;

                SvCalibration cal = mRobotData.Calibrations;

                if (!GetLoadingPosition())
                {
                    SequenceLog("Get loading position Fail!!", Common.SvLogger.LogType.ERROR);
                    return false;
                }

                if (!CalculateAlignOffset())
                {
                    SequenceLog("Calculate AlignOffset Fail!!", Common.SvLogger.LogType.ERROR);
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        bool GetLoadingPosition()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;

                // 무조건 여기 있어야 함. AutoThread_Panel_NoMove가 접근해서 사용할 경우가 있다.
                mAlignResult.ObjectRobotPoint.Clear();

                for (int j = 0; j < mRefAutoThread[0].AlignResult.ObjectRobotPoint.Count; j++)//reference를 멀티로 사용
                {
                    foreach (var refThread in mRefAutoThread)
                    {
                        mAlignResult.ObjectRobotPoint.Add(refThread.AlignResult.ObjectRobotPoint[j] - refThread.AlignResult.RotCenter3d + cal.RotCenter3d);
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        protected bool CalculateAlignOffset()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;

                Mat tray2robotMat = null;
                tray2robotCal = new SvCalibration();

                mAlignResult.TargetPixelPoint.Clear();
                mAlignResult.TargetRobotPoint.Clear();
                mAlignResult.SendPoint.Clear();

                if (mProcData.FocalLength > 0 && mProcData.SensorHeight > 0 && mProcData.SensorWidth > 0)
                {
                    // Tray2Robot Warpping 적용
                    SvWarpping warp;

                    for (int j = 1; j < mAlignResult.JobInfo.Count; j++)
                    {
                        if (mAlignResult.JobInfo[j].ContainsKey(typeof(SvWarpping)))
                            warp = mAlignResult.JobInfo[j][typeof(SvWarpping)][0].Toolbase as SvWarpping;
                        else
                            continue;

                        SvPolyLine trayP = warp.OutLayoutPLine;
                        Point2d[] trayP2d = new Point2d[4];
                        for (int i = 0; i < 4; i++)
                            trayP2d[i] = cal.VtoR(new Point2d(trayP[i].X, trayP[i].Y));

                        tray2robotMat = cal.GetTray2RobotPerspectiveMatrix(trayP2d, PerspectiveP, WD, mRobotData.TrayWidth, mRobotData.TrayHeight);

                        if (tray2robotMat != null)
                            tray2robotCal.CalData.VtoRMat.Mat = tray2robotMat.Clone();
                    }
                }

                //double[,] calMat = SvFunc.DisplayMat(cal.CalData.VtoRMat.Mat);
                //double[,] tray2robot = SvFunc.DisplayMat(tray2robotMat);
                //double[,] sum = SvFunc.DisplayMat(tray2robotMat * cal.CalData.VtoRMat.Mat);

                for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
                {
                    // Target Position
                    mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    Point3d targetRobot;

                    Point2d targetRobot0;
                    Point2d targetRobot1;

                    targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    if (tray2robotMat != null)
                    {
                        Point2d target2d = new Point2d(targetRobot.X, targetRobot.Y);
                        targetRobot0 = tray2robotCal.VtoR(target2d);
                        targetRobot1 = tray2robotCal.VtoR(target2d + new Point2d(Math.Cos(targetRobot.Z), Math.Sin(targetRobot.Z)));
                        Point2d vector = targetRobot1 - targetRobot0;
                        targetRobot = new Point3d(targetRobot0.X, targetRobot0.Y, Math.Atan2(vector.Y, vector.X));
                    }

                    //targetRobot.Z = NormalizeTheta(targetRobot.Z);//노멀라이징

                    mAlignResult.TargetRobotPoint.Add(targetRobot);

                    for (int j = 0; j < mAlignResult.ObjectRobotPoint.Count; j++)//reference를 멀티로 사용
                    {
                        //foreach (var refThread in mRefAutoThread)
                        {
                            // Target Position
                            Point3d result3d = cal.RToT(mAlignResult.ObjectRobotPoint[j], mAlignResult.TargetRobotPoint[i]);
                            mAlignResult.TargetRevPoint.Add(result3d);
                            // Send Position
                            if (result3d.Z > Math.PI) result3d.Z -= 2 * Math.PI;
                            else if (result3d.Z < -Math.PI) result3d.Z += 2 * Math.PI;

                            Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
                            mAlignResult.SendPoint.Add(result3f);
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public override bool Do_Judgement()
        {
            // 트레이는 무조건 Single Judgement 타입으로 Judgements 리스트 순회할 필요 없음
            // Vision NG이면 Judgement는 그냥 NG임...
            bool isJudgeOK = AlignResult.IsVisionOK;
            try
            {
                if (isJudgeOK)
                {
                    // Tray 외곽 사이즈 체크 : 180221 추가함 ... 여기서 NG 처리될 경우 Tray size / tolerance 최적화 필요
                    isJudgeOK &= CheckTraySize();
                }

                //// Test 용 코드
                //if (isJudgeOK)
                //{
                //    // 1번 Pocket Postion을 Reference로 등록해서 Tolerence 초과시 NG
                //    isJudgeOK &= CheckPocket();
                //}

                // 여기까지는 Judgement NG이면 모든 Send point를 0,0,0으로 초기화 하기 
                if (!isJudgeOK)
                {
                    int len = AlignResult.CheckJobResult.Count;
                    AlignResult.SendPoint.Clear();
                    if (mProcData.FlowType == PanelFlowType.Dual) len *= 2;

                    for (int i = 0; i < len; i++)
                    {
                        AlignResult.SendPoint.Add(new Point3f());
                    }
                }

                if (isJudgeOK)
                {
                    // 좌표 리미트 체크 : 여기서는 리밋 초과되는 좌표만 0,0,0으로 초기화 하기
                    isJudgeOK &= CheckLimit();

                    // Tray Pocket Distance 체크 : 여기서 Pocket 거리가 Key In한 Data와 비교시 크면 NG
                    isJudgeOK &= CheckPocket();
                }

                // OK, NG 무관하게 패널 유무 검사는 한다 : Existence 리스트 생성
                if (mProcData.UseInspect)
                {
                    CheckExistPanel();
                }

                mAlignResult.List2JudgeResult.Add(new List<bool>());
                mAlignResult.List2JudgeResult[0].Add(isJudgeOK);
            }
            catch (Exception ex)
            {
                SequenceLog("Judgement Exception" + ex, Common.SvLogger.LogType.SEQUENCE);
                return false;
            }

            return isJudgeOK;
        }

        private void CheckExistPanel()
        {
            // Check Existence
            bool judgeOk = true;
            bool exist = false;
            bool needcheck = false;
            double high, low;
            int idx = 0;
            List<double> specs = new List<double>();
            mAlignResult.Existences.Clear();

            // 패널 유무 검사
            if (mProcData.InspectTool == EInspectTool.Histo)
            {
                for (int i = 0; i < mAlignResult.JobInfo.Count - 1; i++)
                {
                    if (!mAlignResult.JobInfo[i + 1].ContainsKey(typeof(SvHistogram)))
                        continue;
                    SvHistogram histo = mAlignResult.JobInfo[i+1][typeof(SvHistogram)][0].Toolbase as SvHistogram;

                    for (int j = 0; j < histo.Thresholds.Count; j++)
                    {
                        //idx = i * (mAlignResult.JobInfo.Count - 1) + j;

                        idx = mAlignResult.Existences.Count;


                        if (idx >= mAlignResult.Means.Count)
                        {
                            System.Windows.MessageBox.Show("It's out of array index!!! pls check count of histogram threshold");
                            return;
                        }

                        high = histo.Thresholds[j] * mModelData.ExistHigh;
                        low = histo.Thresholds[j] * mModelData.ExistLow;

                        if (mModelData.Polarity == ePolarity.High)
                        {
                            exist = mAlignResult.Means[idx] >= high;
                            specs.Add(high);
                        }
                        else
                        {
                            exist = mAlignResult.Means[idx] < low;
                            specs.Add(low);
                        }

                        needcheck |= (mAlignResult.Means[idx] < high && mAlignResult.Means[idx] >= low);
                        mAlignResult.Existences.Add(exist);
                    }

                    //if (mProcData.InspectType == EInspectType.Judgement)
                    //    judgeOk &= exist;
                }
            }
            else// if (mProcData.InspectType == EInspectType.Templete)
            {
                for (int i = 0; i < mAlignResult.Scores.Count; i++)
                {
                    high = mModelData.ExistHigh;
                    low = mModelData.ExistLow;

                    if (mModelData.Polarity == ePolarity.High)
                    {
                        exist = mAlignResult.Scores[i] >= high;
                        specs.Add(high);
                    }
                    else
                    {
                        exist = mAlignResult.Scores[i] < low;
                        specs.Add(low);
                    }
                    needcheck |= mAlignResult.Scores[i] < high && mAlignResult.Scores[i] >= low;
                    mAlignResult.Existences.Add(exist);
                }

                //if (mProcData.InspectType == EInspectType.Judgement)
                //    judgeOk &= exist;
            }

            SvRegion region = null;

            for (int i = 0; i < mAlignResult.JobInfo.Count - 1; i++)
            {
                region = mAlignResult.JobInfo[i + 1][typeof(SvRegion)][0].Toolbase as SvRegion;
                region.IndexXnext = region.IndexYnext = 0;

                for (int j = 0; j < region.Count_X * region.Count_Y; j++)
                {
                    idx = i * (region.Count_X * region.Count_Y) + j;

                    // display
                    string sJudge = string.Format("{0} : ", idx + 1);
                    sJudge += mAlignResult.Existences[idx] ? "EXIST" : "NONE";

                    if (mProcData.InspectTool == EInspectTool.Histo)
                        sJudge += string.Format("\n({0:F2} / {1:F2})", mAlignResult.Means[idx], specs[idx]);
                    else
                        sJudge += string.Format("\n({0:F2} / {1:F2})", mAlignResult.Scores[idx], specs[idx]);

                    System.Drawing.Color color = mAlignResult.Existences[idx] ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Orange;
                    System.Drawing.Pen pen = new System.Drawing.Pen(color);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);

                    region.Run();

                    SvRectangle rect = region.OutputImage.RegionRect;
                    SvPoint point = mAlignResult.ResultPoints[idx] as SvPoint;

                    //System.Drawing.PointF pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);
                    System.Drawing.PointF pnt = new System.Drawing.PointF(0f,0f);

                    if (point != null)
                    {
                        if (region.outParams.ContainsKey("RectLeft"))
                            pnt = new System.Drawing.PointF(point.X + 50, point.Y - 100);
                        else if (region.outParams.ContainsKey("RectRight"))
                            pnt = new System.Drawing.PointF(point.X - 550, point.Y - 100);
                        else if (region.outParams.ContainsKey("RectTop"))
                            pnt = new System.Drawing.PointF(point.X - 250, point.Y + 200);
                        else if (region.outParams.ContainsKey("RectBottom"))
                            pnt = new System.Drawing.PointF(point.X - 250, point.Y - 200);
                    }

                    mUpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.CustomImageList[0].drawingFunc +=
                        (display) =>
                        {
                            ViewModel.Edit.Display.DrawString(sJudge, font08, brush, pnt);
                            ViewModel.Edit.Display.DrawRectangle(pen, rect.RectF);
                        };
                    }));

                    region.IncreaseIndex();
                }
            }
        }
        
        object writelock = new object(); // AutoThread_Tray 는 AutoThread_Panel_NoMove가 접근해서 사용할 경우가 있다.

        public override bool Do_WriteResult()
        {
            bool writeOK = true;

            if (mProcData.UseInspect)// 패널 유무 정보(매핑)와 보정값 전달
            {
                lock (writelock)
                {
                    // exist
                    int sendVal = 0xFFFF;
                    string result = "";
                    for (int i = 0; i < mAlignResult.Existences.Count; i++)
                    {
                        SetBit(ref sendVal, i, mAlignResult.Existences[i]);

                        int slog = mAlignResult.Existences[i] == true ? 1 : 0;
                        result = slog + result;
                    }
                    writeOK &= mRobot.WriteValue(mOffsetAddr, sendVal);//시작지점 2word에 유무 값 write
                    SequenceLog(result, Common.SvLogger.LogType.DATA);
                    DataLog(result);

                    writeOK &= WriteRevOffset(mOffsetAddr + 2, mAlignResult.SendPoint);//2워드 이후부터 위치값 저장한다..
                }
            }
            else// 보정값만 전달
            {
                lock (writelock)
                {
                    writeOK &= WriteRevOffset(mOffsetAddr, mAlignResult.SendPoint);

                    if (mProcData.WriteFDC)
                    {
                        int lastPos = mFDCAddr;


                        List<float> spec = new List<float>();

                        spec.Add(mModelData.ScoreCreteria);
                        spec.Add(mModelData.FindLineDist);
                        spec.Add(mModelData.FindLineNG);
                        spec.Add((float)mRobotData.TrayWidth);
                        spec.Add((float)mRobotData.TrayHeight);
                        spec.Add((float)mRobotData.TrayTolerance);

                        writeOK &= mRobot.WriteValues(lastPos, spec);
                    }
                }
            }

            return writeOK;
        }

        protected SvCalibration tray2robotCal;

        public bool CheckTraySize()
        {
            bool isSizeOK = true;
            // warping tool 가져오기
            SvWarpping warp = mAlignResult.JobInfo[ListAlignIndex[0]][typeof(SvWarpping)][0].Toolbase as SvWarpping;
            if (warp == null)
            {
                SequenceLog("There's no Warping tool", SvLogger.LogType.ERROR);
                return false;
            }
            // calibration 가져오기
            SvCalibration calib = mRobotData.Calibrations;
            // vision to robot position
            var lefttop = calib.VtoR(new Point2d((double)warp.OutLayoutPLine[0].X, (double)warp.OutLayoutPLine[0].Y));
            var righttop = calib.VtoR(new Point2d((double)warp.OutLayoutPLine[1].X, (double)warp.OutLayoutPLine[1].Y));
            var rightbottom = calib.VtoR(new Point2d((double)warp.OutLayoutPLine[2].X, (double)warp.OutLayoutPLine[2].Y));
            var leftbottom = calib.VtoR(new Point2d((double)warp.OutLayoutPLine[3].X, (double)warp.OutLayoutPLine[3].Y));
            // robot to tray position
            lefttop = tray2robotCal.VtoR(lefttop);
            righttop = tray2robotCal.VtoR(righttop);
            rightbottom = tray2robotCal.VtoR(rightbottom);
            leftbottom = tray2robotCal.VtoR(leftbottom);
            // calc length
            double top = Point2d.Distance(lefttop, righttop);
            double bottom = Point2d.Distance(leftbottom, rightbottom);
            double left = Point2d.Distance(lefttop, leftbottom);
            double right = Point2d.Distance(righttop, rightbottom);
            // check width
            double low = mRobotData.TrayWidth - mRobotData.TrayTolerance;
            double high = mRobotData.TrayWidth + mRobotData.TrayTolerance;
            if (top < low || top > high)
            {
                SequenceLog(string.Format("Tray Top Length NG : {0} (spec : {1} ± {2})", top.ToString("f2"), mRobotData.TrayWidth.ToString("f0"), mRobotData.TrayTolerance.ToString("f0")), SvLogger.LogType.ERROR);
                isSizeOK = false;
            }
            if (bottom < low || bottom > high)
            {
                SequenceLog(string.Format("Tray Bottom Length NG : {0} (spec : {1} ± {2})", bottom.ToString("f2"), mRobotData.TrayWidth.ToString("f0"), mRobotData.TrayTolerance.ToString("f0")), SvLogger.LogType.ERROR);
                isSizeOK = false;
            }
            // check height
            low = mRobotData.TrayHeight - mRobotData.TrayTolerance;
            high = mRobotData.TrayHeight + mRobotData.TrayTolerance;
            if (left < low || left > high)
            {
                SequenceLog(string.Format("Tray Left Length NG : {0} (spec : {1} ± {2})", left.ToString("f2"), mRobotData.TrayHeight.ToString("f0"), mRobotData.TrayTolerance.ToString("f0")), SvLogger.LogType.ERROR);
                isSizeOK = false;
            }
            if (right < low || right > high)
            {
                SequenceLog(string.Format("Tray Right Length NG : {0} (spec : {1} ± {2})", right.ToString("f2"), mRobotData.TrayHeight.ToString("f0"), mRobotData.TrayTolerance.ToString("f0")), SvLogger.LogType.ERROR);
                isSizeOK = false;
            }

            if (isSizeOK)
                SequenceLog(string.Format("Tray Size OK (T,B,L,R) : {0:f2}, {1:f2}, {2:f2}, {3:f2}", top, bottom, left, right), SvLogger.LogType.DATA);

            return isSizeOK;
        }

        protected bool CheckPocket()
        {
            bool PocketDistance = true;
            string msg = "";
            float Distance_X = 0; float Distance_Y = 0;
            float Tolerence_X = 0; float Tolerence_Y = 0;
            int i = 0; int j = 0;

            //SvRegion region = null;

            i = (mAlignResult.SendPoint.Count / 2);

            if (mRobotData.LoadPosition.Length == 2)
                j = 2;
            else j = 1;

            for (int k = 1; k <= mAlignResult.JobInfo.Count - 1; k++)
            {
                if (!mAlignResult.JobInfo[k].ContainsKey(typeof(SvMakePoint)))
                    continue;
         
                SvRegion region = mAlignResult.JobInfo[k][typeof(SvRegion)][0].Toolbase as SvRegion;

                if (region.Count_X != 1)
                {
                    float x_1 = Math.Abs(mAlignResult.SendPoint[j].X - mAlignResult.SendPoint[0].X);
                    float x_2 = Math.Abs(mAlignResult.SendPoint[i].X - mAlignResult.SendPoint[0].X);

                    if (x_1 > x_2)
                        Distance_X = x_1;
                    else
                        Distance_X = x_2;

                    Tolerence_X = Math.Abs(Distance_X - mRobotData.PocketDistances.XDistance);

                    if (Tolerence_X > mRobotData.PocketDistances.XTolerence)
                    {
                        msg = string.Format("Pocket X Distnace NG : {0:f3} (Spec : {1} ± {2})", Distance_X, mRobotData.PocketDistances.XDistance, mRobotData.PocketDistances.XTolerence);
                        SequenceLog(msg, SvLogger.LogType.ERROR);
                        PocketDistance = false;
                    }
                }

                if (region.Count_Y != 1)
                {
                    float y_1 = Math.Abs(mAlignResult.SendPoint[j].Y - mAlignResult.SendPoint[0].Y);
                    float y_2 = Math.Abs(mAlignResult.SendPoint[i].Y - mAlignResult.SendPoint[0].Y);

                    if (y_1 > y_2)
                        Distance_Y = y_1;
                    else
                        Distance_Y = y_2;

                    Tolerence_Y = Math.Abs(Distance_Y - mRobotData.PocketDistances.YDistance);

                    if (Tolerence_Y > mRobotData.PocketDistances.YTolerence)
                    {
                        msg = string.Format("Pocket Y Distnace NG : {0:f3} (Spec : {1} ± {2})", Distance_Y, mRobotData.PocketDistances.YDistance, mRobotData.PocketDistances.YTolerence);
                        SequenceLog(msg, SvLogger.LogType.ERROR);
                        PocketDistance = false;
                    }
                }

                //if (region.XFirst)
                //{
                //    Distance_X = mAlignResult.SendPoint[j].X - mAlignResult.SendPoint[0].X;
                //    Distance_Y = mAlignResult.SendPoint[i].Y - mAlignResult.SendPoint[0].Y;
                //}

                //else
                //{
                //    Distance_X = mAlignResult.SendPoint[j].X - mAlignResult.SendPoint[0].X;
                //    Distance_Y = mAlignResult.SendPoint[j].Y - mAlignResult.SendPoint[0].Y;
                //}
            }

            return PocketDistance;
        }
    }
}
