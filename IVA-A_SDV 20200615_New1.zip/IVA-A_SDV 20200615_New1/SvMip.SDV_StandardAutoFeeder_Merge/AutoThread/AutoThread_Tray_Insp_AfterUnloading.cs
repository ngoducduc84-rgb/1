﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Tray 올라탐 검사
    /// For multi toolblock
    /// </summary>
    /*
    public class AutoThread_Tray_Insp_AfterUnloading : AutoThread_Base
    {
        public AutoThread_Tray_Insp_AfterUnloading(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {

        }
        public override bool Do_InitJob()
        {
            bool initOK = true;

            //initOK &= SetResultImage(typeof(SvBlob), 1, 0, "InputImage");

            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvWarpping)))
                initOK &= SetResultImage(typeof(SvWarpping), 0, 0, "OutputImage");

            else if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvImageConverter)))
                initOK &= SetResultImage(typeof(SvImageConverter), 0, 0, "OutputImage");

            else
                initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            for (int i = 1; i < mAlignResult.JobInfo.Count; i++)
            {
                //if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvFindLine)))
                //    initOK &= SetDisplayToolOn(typeof(SvFindLine), i, 0);
                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    initOK &= SetDisplayToolOn(typeof(SvJudgement), i, 0);
                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvBlob)))
                    initOK &= SetDisplayToolOn(typeof(SvBlob), i, 0);
                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvHistogram)))
                    initOK &= SetDisplayToolOn(typeof(SvHistogram), i, 0);
                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvTemplateMatch)))
                    initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), i, 0);
            }
            return initOK;
        }

        public override bool Do_CheckVisionJob()
        {
            try
            {
                List<SvToolBlock> listToolblock = new List<SvToolBlock>();

                foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                    listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

                bool visionResult = true;

                // toolblock 이전까지 실행
                mJob.RunBeforeTool(listToolblock[0]);
                visionResult &= CheckVisionJob(mJob, 0);

                // toolblock cnt loop
                for (int i = 0; i < listToolblock.Count; i++)
                {
                    // region group loop
                    for (int j = 0; j < mAlignResult.JobInfo[i + 1][typeof(SvRegion)].Count; j++)
                    {
                        SvRegion region = mAlignResult.JobInfo[i + 1][typeof(SvRegion)][j].Toolbase as SvRegion;
                        // toolblock inputparams link
                        listToolblock[i].GetInParams();
                        listToolblock[i].InitOutProperty();

                        //SvBlob blob = null;
                        //blob = mAlignResult.JobInfo[i + 1][typeof(SvBlob)][0].Toolbase as SvBlob;

                        region.IndexXnext = 0; region.IndexYnext = 0;

                        // region cnt loop
                        for (int k = 0; k < region.Count_X * region.Count_Y; k++)
                        {
                            listToolblock[i].Run();
                            visionResult &= CheckVisionJob(listToolblock[i].ToolJob, i + 1);

                            region.IncreaseIndex();
                        }
                    }
                }
                return visionResult;
            }
            catch (Exception e)
            {
                SequenceLog(e.ToString(), Common.SvLogger.LogType.ERROR);
                return false;
            }
        }

        public override bool Do_ExecuteAlignCalc()
        {
            return true;
        }

        // region과 judgement가 포함되지 않은 toolblock의 개수를 저장
        public int noJudgeCnt = 0;
        public override bool Do_Judgement()
        {
            bool judgeOk = true;
            int zeroCnt = 0;
            SvRegion region = null;
            SvJudgement judge = null;
            int blockCnt = (mAlignResult.JobInfo.Count - 1);
            int grpCnt = mAlignResult.judgeCnt / blockCnt;
            int s, e;
            // toolblock cnt loop
            for (int i = 1; i <= blockCnt; i++)
            {
                if (!mAlignResult.JobInfo[i].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                {
                    MessageBox.Show("Toolblock does not include Region or Judgement!!!");
                    return false;
                }

                region = mAlignResult.JobInfo[i][typeof(SvRegion)][0].Toolbase as SvRegion;
                judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][0].Toolbase as SvJudgement;
                s = grpCnt * (i - 1); e = s + grpCnt;
                // toolblock idx * region idx  loop  ==> 결과값을 1차 list에 저장함 (실제 값을 저장하는 checktool에서는 block 정보나 region 정보를 받지 않기 때문에 구분하려면 함수 파라메터 조작이 필요)
                for (int j = s; j < e; j++)
                {
                    // judge의 thresholds와 value를 이용해 Judgements값 계산
                    // 단일 스펙이 아닌 경우

                    if (judge.Thresholds.Count == (region.Count_X * region.Count_Y))
                    {
                        judge.Creteria = judge.Thresholds[j - grpCnt * (i - 1)];
                    }
                    judge.Value = mAlignResult.ResultValues[j];
                    judge.Run();

                    mAlignResult.Judgements.Add(judge.Judgement);
                    mAlignResult.JudgementSpec.Add(judge.Creteria);

                    if (mAlignResult.Judgements[j] == false)
                    {
                        judgeOk = false;
                        zeroCnt++;
                    }

                    // display
                    string sJudge = string.Format("{0} : ", (j + 1 - (i - 1) * grpCnt));
                    sJudge += mAlignResult.Judgements[j] ? "OK" : "NG";
                    sJudge += string.Format("\n{0:f1} \n(spec : {1:f1})", mAlignResult.ResultValues[j], mAlignResult.JudgementSpec[j]);

                    System.Drawing.Color color = (mAlignResult.Judgements[j]) ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Orange;
                    System.Drawing.Pen pen = new System.Drawing.Pen(color);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);

                    region.Run();

                    SvRectangle rect = region.OutputImage.RegionRect;
                    System.Drawing.PointF pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);

                    mUpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.Display.DrawString(sJudge, font08, brush, pnt);
                        ViewModel.Edit.Display.DrawRectangle(pen, rect.RectF);
                    }));

                    region.IncreaseIndex();
                }

            }

            //// 판정결과가 region별로 전부 일치하는 경우가 아니라면 NG 판정
            //if (judgeOk == false)
            //{
            //    if (grpCnt != zeroCnt)
            //        judgeOk = false;
            //    else
            //        judgeOk = true;
            //}

            if (mProcData.InspectType == EInspectType.Judgement)
            {
                if (judgeOk == false)
                {
                    if (grpCnt != zeroCnt)
                        judgeOk = false;
                    else
                        judgeOk = true;
                }
            }

            else
                judgeOk = true;
            // 개수 예외처리
            if (mAlignResult.Judgements.Count < region.Count_X * region.Count_Y * (mAlignResult.JobInfo.Count - 1))
            {
                MessageBox.Show("Counts of existence are not enough !!!");
                return false;
            }

            if (mProcData.InspectType == EInspectType.Mapping)
                judgeOk = true;

            return judgeOk;
        }

        //public override bool Do_ManualCheck()
        //{
        //    bool isOk = true;
        //    SequenceLog("ManualInspection Start", Common.SvLogger.LogType.SEQUENCE);
        //    mIO.SetOutValue(mSystem.OPCallBit, true);//set op-call bit

        //    dsp.Invoke(() =>
        //    {
        //        ManualInspection wnd = new ManualInspection();
        //        wnd.InitWnd(mAlignResult, mJob, mIO, mProcData.IOParam.Inputs[InSignal.Complete.ToString()]);
        //        isOk = wnd.ShowDialog() == true;
        //    });

        //    mIO.SetOutValue(mSystem.OPCallBit, false);//reset op-call bit
        //    SequenceLog("ManualAlign End", Common.SvLogger.LogType.SEQUENCE);
        //    return isOk;
        //}

        public override bool Do_WriteResult()
        {
            // exist
            int sendVal = 0;
            string result = "";
            bool sendresult = true;

            int blockCnt = (mAlignResult.JobInfo.Count - 1);
            int grpCnt = mAlignResult.Judgements.Count / blockCnt;
            int s, e;


            for (int k = 0; k < blockCnt; k++)
            {
                result = "";
                sendVal = 0;
                s = grpCnt * k; e = s + grpCnt;
                for (int i = s; i < e; i++)
                {
                    SetBit(ref sendVal, i - (grpCnt * k), mAlignResult.Judgements[i]);

                    int slog = mAlignResult.Judgements[i] == true ? 1 : 0;
                    result = slog + result;
                }
                sendresult &= mRobot.WriteValue(mRobotWriteAddress + (k * 2), sendVal);
                SequenceLog(result, Common.SvLogger.LogType.DATA);
                DataLog(result);
            }


            return sendresult;
        }

        public override bool Do_WriteJudgement()
        {
            string msg;
            if (mAlignResult.IsJudgeOK)
            {
                msg = "JUDGE OK";
                if (mAlignResult.IsInterfaceOK)
                {
                    msg += ", I/F OK";
                    ViewModel.Judge1 = true;
                }
                else
                {
                    msg += ", I/F NG";
                    ViewModel.Judge1 = false;
                }
                mIO.SetOutValue(OutAddr[OutSignal.OK.ToString()], true);
            }
            else
            {
                msg = "JUDGE NG";
                ViewModel.Judge1 = false;
                mIO.SetOutValue(OutAddr[OutSignal.NG.ToString()], true);
            }
            SequenceLog(msg, Common.SvLogger.LogType.SEQUENCE);
            return true;
        }
    }
     * */
}
