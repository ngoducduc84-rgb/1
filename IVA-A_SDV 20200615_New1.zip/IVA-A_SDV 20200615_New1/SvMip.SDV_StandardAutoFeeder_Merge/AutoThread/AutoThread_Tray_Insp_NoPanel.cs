﻿//using OpenCvSharp.CPlusPlus;
//using SvMip.Calibration;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace SvMip.SDV_StandardAutoFeeder_Merge
//{
//    /// <summary>
//    /// Object Vision이 없는 Tray Vision
//    /// </summary>
//    /// 
//    public class AutoThread_Tray_Insp_NoPanel : AutoThread_Tray_NoPanel
//    {
//        public AutoThread_Tray_Insp_NoPanel(SystemData _system, RecipeData _recipe, Main.Process _process)
//            : base(_system, _recipe, _process)
//        {

//        }

//        public override bool Do_InitJob()
//        {
//            bool initOK = true;
//            initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

//            if (!mAlignResult.JobInfo[0].ContainsKey(typeof(SvFindLine)))
//            {
//                SequenceLog("[SvFindLine] Set Display Fail", Common.SvLogger.LogType.ERROR);
//                return false;
//            }

//            for (int i = 0; i < mAlignResult.JobInfo[0][typeof(SvFindLine)].Count; i++)
//                initOK &= SetDisplayToolOn(typeof(SvFindLine), 0, i);

//            initOK &= SetDisplayToolOn(typeof(SvMakeRectFromLine), 0);
//            initOK &= SetDisplayToolOn(typeof(SvMakePoint), 0);
//            initOK &= SetResultPoint(typeof(SvMakePoint), 1, 0, "OutPoint");

//            // Tray Align & Object Exist Check 기능 추가_2018.01.03 HOZZANG
//            if (mProcData.UseInspect)
//            {
//                if (mProcData.InspectTool == EInspectTool.Templete)
//                {
//                    initOK &= SetDisplayToolOn(typeof(SvTemplateMatch), 1, 0);
//                }

//                else
//                {
//                    initOK &= SetDisplayToolOn(typeof(SvHistogram), 1, 0);
//                }
//            }

//            return initOK;
//        }

//        public override bool Do_CheckVisionJob()
//        {
//            List<SvToolBlock> listToolblock = new List<SvToolBlock>();

//            foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
//                listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

//            SvRegion region = mAlignResult.JobInfo[1][typeof(SvRegion)][0].Toolbase as SvRegion;
//            //SvToolBlock block = mAlignResult.JobInfo[typeof(SvToolBlock)][0].Toolbase as SvToolBlock;
//            SvTemplateMatch templete = null;
//            SvHistogram histo = null;

//            bool visionResult = true;

//            // Tray Align & Object Exist Check 기능 추가_2018.01.03 HOZZANG
//            if (mProcData.UseInspect)
//            {
//                if (mProcData.InspectTool == EInspectTool.Templete)
//                    templete = mAlignResult.JobInfo[1][typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;

//                else
//                    histo = mAlignResult.JobInfo[1][typeof(SvHistogram)][0].Toolbase as SvHistogram;
//            }

//            // toolblock 이전까지 실행
//            mJob.RunBeforeTool(listToolblock[0]);
//            visionResult &= CheckVisionJob(mJob);

//            for (int i = 0; i < listToolblock.Count; i++)
//            {
//                // toolblock inputparams link
//                listToolblock[i].GetInParams();
//                listToolblock[i].InitOutProperty();

//                region.IndexXnext = 0; region.IndexYnext = 0;

//                for (int j = 0; j < region.Count_X * region.Count_Y; j++)
//                {
//                    if (mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete)
//                        templete.SelectedPatternIndex = j;

//                    listToolblock[i].Run();
//                    visionResult &= CheckVisionJob(listToolblock[i].ToolJob);

//                    //if (mProcData.UseInspect && mProcData.InspectType == EInspectType.Judgement && !visionResult)
//                    //    return visionResult;

//                    region.IncreaseIndex();
//                }
//            }

//            return visionResult;
//        }

//        public override bool Do_ExecuteAlignCalc()
//        {
//            try
//            {
//                SvCalibration cal = mRobotData.Calibrations;
//                mAlignResult.ObjectRobotPoint.Clear();
//                for (int j = 0; j < mRobotData.LoadPosition.Length; j++)//reference를 멀티로 사용
//                {
//                    // Start Position, refThread.AlignResult.ObjectRobot = Loading Pos. - Offset Pos. (Z is rad)
//                    //foreach (var refThread in mRefAutoThread)
//                    Point3d p = mRobotData.LoadPosition[j].Point3d;
//                    p.Z *= Math.PI / 180;
//                    {
//                        mAlignResult.ObjectRobotPoint.Add(p);
//                    }
//                }

//                for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
//                {
//                    // Target Position
//                    mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
//                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
//                    targetRobot.Z = NormalizeTheta(targetRobot.Z);//노멀라이징
//                    mAlignResult.TargetRobotPoint.Add(targetRobot);

//                    for (int j = 0; j < mAlignResult.ObjectRobotPoint.Count; j++)//reference를 멀티로 사용
//                    {
//                        //foreach (var refThread in mRefAutoThread)
//                        {
//                            // Target Position
//                            Point3d result3d = cal.RToT(mAlignResult.ObjectRobotPoint[j], mAlignResult.TargetRobotPoint[i]);
//                            mAlignResult.TargetRevPoint.Add(result3d);
//                            // Send Position
//                            Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
//                            mAlignResult.SendPoint.Add(result3f);
//                        }
//                    }

//                }

//                return true;
//            }
//            catch (Exception ex)
//            {
//                return false;
//            }
//        }

//        public override bool Do_Judgement()
//        {
//            // check existence
//            bool isJudgeOk = true;
//            bool exist = false;
//            bool needcheck = false;
//            double high, low;
//            List<double> specs = new List<double>();
//            mAlignResult.Existences.Clear();

//            // 좌표 판정
//            for (int i = 0; i < mAlignResult.JobSuccess.Count; i++)
//            {
//                //if (!mAlignResult.JobSuccess[i])
//                //{
//                //    mAlignResult.SendPoint[i] = new Point3f();
//                //}

//                isJudgeOk &= mAlignResult.JobSuccess[i];
//                mAlignResult.Judgements.Add(mAlignResult.JobSuccess[i]);
//            }

//            // Tray Align & Object Exist Check 기능 추가_2018.01.03 HOZZANG
//            if (mProcData.UseInspect)
//            {
//                if (mProcData.InspectTool == EInspectTool.Histo)
//                {
//                    SvHistogram histo = mAlignResult.JobInfo[1][typeof(SvHistogram)][0].Toolbase as SvHistogram;

//                    for (int i = 0; i < mAlignResult.Means.Count; i++)
//                    {
//                        high = histo.Thresholds[i] * mModelData.ExistHigh;
//                        low = histo.Thresholds[i] * mModelData.ExistLow;
//                        if (mModelData.Polarity == ePolarity.High)
//                        {
//                            exist = mAlignResult.Means[i] >= high;
//                            specs.Add(high);
//                        }
//                        else
//                        {
//                            exist = mAlignResult.Means[i] < low;
//                            specs.Add(low);
//                        }
//                        needcheck |= (mAlignResult.Means[i] < high && mAlignResult.Means[i] >= low);
//                        mAlignResult.Existences.Add(exist);

//                        if (mProcData.InspectType == EInspectType.Judgement)
//                            isJudgeOk &= exist;
//                    }
//                }
//                else// if (mProcData.InspectType == EInspectType.Templete)
//                {
//                    for (int i = 0; i < mAlignResult.Scores.Count; i++)
//                    {
//                        high = mModelData.ExistHigh;
//                        low = mModelData.ExistLow;
//                        if (mModelData.Polarity == ePolarity.High)
//                        {
//                            exist = mAlignResult.Scores[i] >= high;
//                            specs.Add(high);
//                        }
//                        else
//                        {
//                            exist = mAlignResult.Scores[i] < low;
//                            specs.Add(low);
//                        }
//                        needcheck |= mAlignResult.Scores[i] < high && mAlignResult.Scores[i] >= low;
//                        mAlignResult.Existences.Add(exist);

//                        if (mProcData.InspectType == EInspectType.Judgement)
//                            isJudgeOk &= exist;
//                    }
//                }

//                // display 변경 : 패널 유무 보여주기
//                //SvAcquisition acq = mJob["Acquisition"] as SvAcquisition;
//                //mUpdateDisplayCode.Clear();
//                //mUpdateDisplayCode.Add(new Action(() =>
//                //{
//                //    ViewModel.Edit.Display.GraphicsFuncCollection.Clear();
//                //    ViewModel.Edit.Display.Image = acq.AcqusitionImage;
//                //}));

//                SvRegion region = mAlignResult.JobInfo[1][typeof(SvRegion)][0].Toolbase as SvRegion;
//                region.IndexXnext = region.IndexYnext = 0;

//                for (int i = 0; i < mAlignResult.Existences.Count; i++)
//                {
//                    // display
//                    string sJudge = string.Format("{0} : ", i + 1);
//                    sJudge += mAlignResult.Existences[i] ? "EXIST" : "NONE";
//                    if (mProcData.InspectTool == EInspectTool.Histo)
//                        sJudge += string.Format("\n({0:F2} / {1:F2})", mAlignResult.Means[i], specs[i]);
//                    else
//                        sJudge += string.Format("\n({0:F2}/{1:F2})", mAlignResult.Scores[i], specs[i]);

//                    System.Drawing.Color color = mAlignResult.Existences[i] ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Orange;
//                    System.Drawing.Pen pen = new System.Drawing.Pen(color);
//                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
//                    System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);

//                    region.Run();

//                    SvRectangle rect = region.OutputImage.RegionRect;
//                    SvPoint point = mAlignResult.ResultPoints[i] as SvPoint;

//                    System.Drawing.PointF pnt = new System.Drawing.PointF(0f, 0f);

//                    if (region.outParams.ContainsKey("RectLeft"))
//                        pnt = new System.Drawing.PointF(point.X + 50, point.Y - 100);
//                    else if (region.outParams.ContainsKey("RectRight"))
//                        pnt = new System.Drawing.PointF(point.X - 550, point.Y - 100);
//                    else if (region.outParams.ContainsKey("RectTop"))
//                        pnt = new System.Drawing.PointF(point.X - 250, point.Y + 200);
//                    else if (region.outParams.ContainsKey("RectBottom"))
//                        pnt = new System.Drawing.PointF(point.X - 250, point.Y - 200);
//                    mUpdateDisplayCode.Add(new Action(() =>
//                    {
//                        ViewModel.Edit.Display.DrawString(sJudge, font08, brush, pnt);
//                        //ViewModel.Edit.Display.DrawRectangle(pen, rect.RectF);
//                    }));
//                    region.IncreaseIndex();
//                }

//            }



//            //if (needcheck && mProcData.UseManualAlign)
//            //{
//            //    judgeOk = Do_ManualCheck();//매뉴얼 창에서 사용자 결정 반영
//            //}
//            return isJudgeOk;
//        }

//        public override bool Do_WriteResult()
//        {
//            // Tray Align & Object Exist Check 기능 추가_2018.01.03 HOZZANG
//            // exist
//            int sendVal = 0;
//            string result = "";
//            for (int i = 0; i < mAlignResult.Existences.Count; i++)
//            {
//                SetBit(ref sendVal, i, mAlignResult.Existences[i]);

//                int slog = mAlignResult.Existences[i] == true ? 1 : 0;
//                result = slog + result;
//            }
//            bool sendresult = mRobot.WriteValue(mRobotWriteAddress, sendVal);//시작지점 2word에 유무 값 write
//            SequenceLog(result, Common.SvLogger.LogType.DATA);

//            // position
//            sendresult &= WriteRevOffset(mRobotWriteAddress + 2, mAlignResult.SendPoint);//2워드 이후부터 위치값 저장한다..
//            return sendresult;
//        }

//        public override bool Do_ManualCheck()
//        {
//            return true;
//        }
//    }
//}
