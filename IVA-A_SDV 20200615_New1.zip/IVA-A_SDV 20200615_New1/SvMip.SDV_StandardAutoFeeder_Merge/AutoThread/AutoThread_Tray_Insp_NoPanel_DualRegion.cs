﻿//using OpenCvSharp.CPlusPlus;
//using SvMip.Calibration;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace SvMip.SDV_StandardAutoFeeder_Merge
//{
//    /// <summary>
//    /// Object Vision???�는 Tray Vision
//    /// </summary>
//    /// 
//    public class AutoThread_Tray_Insp_NoPanel_DualRegion : AutoThread_Tray_NoPanel
//    {
//        public AutoThread_Tray_Insp_NoPanel_DualRegion(SystemData _system, RecipeData _recipe, Main.Process _process) : base(_system, _recipe, _process)
//        {

//        }

//        public override bool Do_InitJob()
//        {
//            return base.Do_InitJob();
//        }

//        public override bool Do_CheckVisionJob()
//        {
//            List<SvToolBlock> listToolblock = new List<SvToolBlock>();

//            foreach (var toolinfo in mAlignResult.JobInfo[typeof(SvToolBlock)])
//                listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

//            SvRegion region = mAlignResult.JobInfo[typeof(SvRegion)][0].Toolbase as SvRegion;
//            SvRegion region2 = mAlignResult.JobInfo[typeof(SvRegion)][1].Toolbase as SvRegion;

//            SvTemplateMatch templete = null;
//            SvHistogram histo = null; SvHistogram histo2 = null;
//            SvJob job = null;

//            bool visionResult = true;

//            // Tray Align & Object Exist Check 기능 추가_2018.01.03 HOZZANG
//            if (mProcData.UseInspect)
//            {
//                if (mProcData.InspectTool == EInspectTool.Templete)
//                    templete = mAlignResult.JobInfo[typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;
//                else
//                {
//                    histo = mAlignResult.JobInfo[typeof(SvHistogram)][0].Toolbase as SvHistogram;
//                    histo2 = mAlignResult.JobInfo[typeof(SvHistogram)][1].Toolbase as SvHistogram;
//                }
//            }

//            // toolblock 이전까지 실행
//            mJob.RunBeforeTool(listToolblock[0]);
//            visionResult &= CheckVisionJob(mJob);

//            int countS = 0;
//            int countL = 0;

//            for (int i = 0; i < listToolblock.Count; i++)
//            {
//                region.IndexXnext = 0; region.IndexYnext = 0;
//                region2.IndexXnext = 0; region2.IndexYnext = 0;

//                if (region.Count_X == 1)
//                {
//                    countS = region.Count_X;
//                    countL = region.Count_Y;
//                }
//                else
//                {
//                    countS = region.Count_Y;
//                    countL = region.Count_X;
//                }

//                listToolblock[i].GetInParams();
//                listToolblock[i].InitOutProperty();

//                for (int j = 0; j < countL; j++)
//                {
//                    if (mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete)
//                        templete.SelectedPatternIndex = j;

//                    listToolblock[i].Run();
//                    visionResult &= CheckVisionJob(listToolblock[i].ToolJob);

//                    //    if (j == 0)
//                    //    job = mJob;

//                    //else
//                    //    job = block.ToolJob;

//                    //job.Run();
//                    //visionResult &= CheckVisionJob(job);

//                    if (mProcData.UseInspect && mProcData.InspectType == EInspectType.Judgement && !visionResult)
//                        return visionResult;

//                    region.IncreaseIndex();
//                    region2.IncreaseIndex();
//                }
//            }

//            return visionResult;
//        }

//        public override bool Do_ExecuteAlignCalc()
//        {
//            try
//            {
//                SvCalibration cal = mRobotData.Calibrations;
//                mAlignResult.ObjectRobotPoint.Clear();
//                for (int j = 0; j < mRobotData.LoadPosition.Length; j++)    //reference 멀티로 사용
//                {
//                    // Start Position, refThread.AlignResult.ObjectRobot = Loading Pos. - Offset Pos. (Z is rad)
//                    //foreach (var refThread in mRefAutoThread)
//                    Point3d p = mRobotData.LoadPosition[j].Point3d;
//                    p.Z *= Math.PI / 180;
//                    {
//                        mAlignResult.ObjectRobotPoint.Add(p);
//                    }
//                }

//                for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
//                {
//                    // Target Position
//                    mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
//                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
//                    targetRobot.Z = NormalizeTheta(targetRobot.Z); //노멀라이징
//                    mAlignResult.TargetRobotPoint.Add(targetRobot);

//                    if (i % 2 == 0)
//                    {
//                        for (int j = 0; j < mAlignResult.ObjectRobotPoint.Count; j++)   //reference 멀티로 사용
//                        {
//                            //foreach (var refThread in mRefAutoThread)
//                            {
//                                // Target Position
//                                Point3d result3d = cal.RToT(mAlignResult.ObjectRobotPoint[j], mAlignResult.TargetRobotPoint[i]);
//                                mAlignResult.TargetRevPoint.Add(result3d);
//                                // Send Position
//                                Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
//                                mAlignResult.SendPoint.Add(result3f);
//                            }
//                        }
//                    }
//                }

//                for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
//                {
//                    // Target Position
//                    mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
//                    Point3d targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
//                    targetRobot.Z = NormalizeTheta(targetRobot.Z);      // 노멀라이징
//                    mAlignResult.TargetRobotPoint.Add(targetRobot);

//                    if (i % 2 == 1)
//                    {
//                        for (int j = 0; j < mAlignResult.ObjectRobotPoint.Count; j++)   //reference 멀티로 사용
//                        {
//                            //foreach (var refThread in mRefAutoThread)
//                            {
//                                // Target Position
//                                Point3d result3d = cal.RToT(mAlignResult.ObjectRobotPoint[j], mAlignResult.TargetRobotPoint[i]);
//                                mAlignResult.TargetRevPoint.Add(result3d);
//                                // Send Position
//                                Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
//                                mAlignResult.SendPoint.Add(result3f);
//                            }
//                        }
//                    }
//                }
//                return true;
//            }
//            catch (Exception ex)
//            {
//                return false;
//            }
//        }

//        public override bool Do_Judgement()
//        {
//            // check existence
//            bool isJudgeOk = true;
//            bool exist = false;
//            bool needcheck = false;
//            double high, low;
//            List<double> specs = new List<double>();
//            mAlignResult.Existences.Clear();

//            // 좌표 
//            for (int i = 0; i < mAlignResult.JobSuccess.Count; i++)
//            {
//                //if (!mAlignResult.JobSuccess[i])
//                //{
//                //    mAlignResult.SendPoint[i] = new Point3f();
//                //}

//                isJudgeOk &= mAlignResult.JobSuccess[i];
//                mAlignResult.Judgements.Add(mAlignResult.JobSuccess[i]);
//            }

//            //isJudgeOk &= CheckLimit();

//            // Tray Align & Object Exist Check 기능 추가_2018.01.03 HOZZANG
//            if (mProcData.UseInspect)
//            {
//                if (mProcData.InspectTool == EInspectTool.Histo)
//                {
//                    SvHistogram histo = mAlignResult.JobInfo[typeof(SvHistogram)][0].Toolbase as SvHistogram;

//                    int m = 0; int k = 0; int l = 0;

//                    for (int j = 0; j < 2; j++)
//                    {
//                        if (j == 0)
//                        {
//                            m = 0; k = 0;
//                            l = mAlignResult.Means.Count / 2;
//                            //l = mAlignResult.ResultPoints.Count / 2;
//                        }

//                        else
//                        {
//                            m = mAlignResult.Means.Count / 2; k = 1;
//                            l = mAlignResult.Means.Count;

//                            //m = mAlignResult.ResultPoints.Count / 2; k = 1;
//                            //l = mAlignResult.ResultPoints.Count;

//                        }

//                        for (int i = m; i < l; i++)
//                        {
//                            try
//                            {
//                                high = histo.Thresholds[i] * mModelData.ExistHigh;
//                                low = histo.Thresholds[i] * mModelData.ExistLow;

//                                if (mModelData.Polarity == ePolarity.High)
//                                {
//                                    exist = mAlignResult.Means[k] >= high;
//                                    specs.Add(high);
//                                }
//                                else
//                                {
//                                    exist = mAlignResult.Means[k] < low;
//                                    specs.Add(low);
//                                }
//                                needcheck |= (mAlignResult.Means[k] < high && mAlignResult.Means[k] >= low);
//                                mAlignResult.Existences.Add(exist);

//                                k += 2;
//                            }

//                            catch
//                            { }
//                        }
//                    }
//                }


//                else// if (mProcData.InspectType == EInspectType.Templete)
//                {
//                    for (int i = 0; i < mAlignResult.Scores.Count; i++)
//                    {
//                        high = mModelData.ExistHigh;
//                        low = mModelData.ExistLow;
//                        if (mModelData.Polarity == ePolarity.High)
//                        {
//                            exist = mAlignResult.Scores[i] >= high;
//                            specs.Add(high);
//                        }
//                        else
//                        {
//                            exist = mAlignResult.Scores[i] < low;
//                            specs.Add(low);
//                        }
//                        needcheck |= mAlignResult.Scores[i] < high && mAlignResult.Scores[i] >= low;
//                        mAlignResult.Existences.Add(exist);
//                    }
//                }

//                // display 변경 : 패널 유무 보여주기
//                SvAcquisition acq = mJob["Acquisition"] as SvAcquisition;
//                //mUpdateDisplayCode.Clear();
//                mUpdateDisplayCode.Add(new Action(() =>
//                {
//                    //ViewModel.Edit.Display.GraphicsFuncCollection.Clear();
//                    ViewModel.Edit.Display.Image = acq.AcqusitionImage;
//                }));

//                SvRegion region;
//                SvRegion region1 = mAlignResult.JobInfo[typeof(SvRegion)][0].Toolbase as SvRegion;
//                SvRegion region2 = mAlignResult.JobInfo[typeof(SvRegion)][1].Toolbase as SvRegion;
//                SvMakePoint makepoint = mAlignResult.JobInfo[typeof(SvMakePoint)][0].Toolbase as SvMakePoint;
//                SvMakePoint makepoint2 = mAlignResult.JobInfo[typeof(SvMakePoint)][1].Toolbase as SvMakePoint;

//                region1.IndexXnext = region1.IndexYnext = 0;
//                region2.IndexXnext = region2.IndexYnext = 0;

//                int a = 1; int b = 0;/* region1.Count_Y+1;*/ int c = 0;

//                if (region1.Count_X == 1)
//                    b = region1.Count_Y + 1;
//                else
//                    b = region1.Count_X + 1;

//                for (int i = 0; i < mAlignResult.Existences.Count; i++)
//                {
//                    SvRectangle rect;
//                    string sJudge;

//                    if (i % 2 == 0)
//                    {
//                        c = a;
//                        region = region1;
//                        //rect = region.OutputImage.RegionRect;
//                        a++;
//                    }

//                    else
//                    {
//                        c = b;
//                        region = region2;
//                        //rect = region2.OutputImage.RegionRect;
//                        b++;
//                    }

//                    region.Run();

//                    // display
//                    SvPoint point = mAlignResult.ResultPoints[i] as SvPoint;
//                    sJudge = string.Format("{0} : ", c);
//                    sJudge += mAlignResult.Existences[c - 1] ? "OK" : "NG";
//                    if (mProcData.InspectTool == EInspectTool.Histo)
//                        sJudge += string.Format("\n({0:F1} / {1:F1})", mAlignResult.Means[i], specs[c - 1]);
//                    //sJudge += string.Format(" ({0:F2})\n(Spec : {1:F2})", mAlignResult.Means[i], specs[c-1]);
//                    else
//                        sJudge += string.Format("\n({0:F1}/{1:F1})", mAlignResult.Scores[i], specs[c - 1]);
//                    //sJudge += string.Format(" ({0:F2})\n(Spec : {1:F2})", mAlignResult.Scores[i], specs[c - 1]);

//                    //SequenceLog(sJudge, Common.SvLogger.LogType.DATA);

//                    System.Drawing.Color color = mAlignResult.Existences[c - 1] ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Red;
//                    System.Drawing.Pen pen = new System.Drawing.Pen(color);
//                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
//                    System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);

//                    //System.Drawing.PointF pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);
//                    System.Drawing.PointF pnt = new System.Drawing.PointF(0f, 0f);

//                    if (region.outParams.ContainsKey("RectLeft"))
//                        pnt = new System.Drawing.PointF(point.X + 50, point.Y - 100);
//                    else if (region.outParams.ContainsKey("RectRight"))
//                        pnt = new System.Drawing.PointF(point.X - 550, point.Y - 100);
//                    else if (region.outParams.ContainsKey("RectTop"))
//                        pnt = new System.Drawing.PointF(point.X - 250, point.Y + 200);
//                    else if (region.outParams.ContainsKey("RectBottom"))
//                        pnt = new System.Drawing.PointF(point.X - 250, point.Y - 200);

//                    mUpdateDisplayCode.Add(new Action(() =>
//                    {
//                        ViewModel.Edit.Display.DrawString(sJudge, font08, brush, pnt);
//                        //ViewModel.Edit.Display.DrawRectangle(pen, rect.Rect);
//                    }));
//                    region.IncreaseIndex();
//                    region2.IncreaseIndex();
//                }

//            }

//            //if (needcheck && mProcData.UseManualAlign)
//            //{
//            //    judgeOk = Do_ManualCheck();//매뉴??창에???�용??결정 반영
//            //}
//            return isJudgeOk;
//        }

//        public override bool Do_WriteResult()
//        {
//            // Tray Align & Object Exist Check 기능 추�?_2018.01.03 HOZZANG
//            // exist
//            int sendVal = 0;
//            string result = "";
//            for (int i = 0; i < mAlignResult.Existences.Count; i++)
//            {
//                SetBit(ref sendVal, i, mAlignResult.Existences[i]);

//                int slog = mAlignResult.Existences[i] == true ? 1 : 0;
//                result = slog + result;
//            }
//            bool sendresult = mRobot.WriteValue(mRobotWriteAddress, sendVal);//?�작지??2word???�무 �?write
//            SequenceLog(result, Common.SvLogger.LogType.DATA);

//            // position
//            sendresult &= WriteRevOffset(mRobotWriteAddress + 2, mAlignResult.SendPoint);//2?�드 ?�후부???�치�??�?�한??.
//            return sendresult;
//        }

//        public override bool Do_ManualCheck()
//        {
//            return true;
//        }
//    }
//}
