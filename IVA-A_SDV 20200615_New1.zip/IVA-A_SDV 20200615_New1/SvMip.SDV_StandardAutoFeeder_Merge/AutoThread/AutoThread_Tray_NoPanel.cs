﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Tray Align (PreAlign이 없는 경우, 즉 reference가 없음)
    /// </summary>
    public class AutoThread_Tray_NoPanel : AutoThread_Tray
    {
        public AutoThread_Tray_NoPanel(SystemData _system, RecipeData _recipe, Main.Process _process) : base(_system, _recipe, _process)
        {
            
        }
        public override bool Do_InitJob()
        {
            return base.Do_InitJob();
            }

        public override bool Do_CheckVisionJob()
        {
            return base.Do_CheckVisionJob();
        }

        public override bool Do_ExecuteAlignCalc()
        {
            SvCalibration cal = mRobotData.Calibrations;
            if (!GetLoadingPosition())
        {
                SequenceLog("Get loading position Fail!!", Common.SvLogger.LogType.ERROR);
                return false;
            }

            return base.CalculateAlignOffset();
        }

        bool GetLoadingPosition()
        {
            try
            {
                mAlignResult.ObjectRobotPoint.Clear();
                for (int j = 0; j < mRobotData.LoadPosition.Length; j++)//reference를 멀티로 사용
                {
                    Point3d p = mRobotData.LoadPosition[j].Point3d;
                    p.Z *= Math.PI / 180;
                    {
                        mAlignResult.ObjectRobotPoint.Add(p);
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
        
        //public override bool Do_WriteResult()
        //{
        //    bool b = WriteRevOffset(mRobotWriteAddress, mAlignResult.SendPoint);
        //    return b;
        //}

        public override bool Do_ManualCheck()
        {



            return true;
        }
    }
}
