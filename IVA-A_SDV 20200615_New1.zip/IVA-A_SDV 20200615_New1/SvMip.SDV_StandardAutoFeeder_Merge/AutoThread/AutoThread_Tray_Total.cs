﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using SvMip.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    // For multi function (Sending bool and double result)
    // Job rule
    // 1. Tools like SvAcquisition, SvFindLine, SvMakeRectFromLine put outside toolblock

    public class AutoThread_Tray_Total : AutoThread_Tray
    {
        public AutoThread_Tray_Total(SystemData _system, RecipeData _recipe, Main.Process _process)
            : base(_system, _recipe, _process)
        {

        }

        public override bool Do_InitJob()
        {
            bool initOK = true;

            // ResultImage Setting
            mAlignResult.ResultImageList.Clear();

            initOK &= SetResultImage(typeof(SvAcquisition), 0, 0, "AcqusitionImage");

            if (mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)))
            {
                for (int i = 1; i < mAlignResult.JobInfo.Count; i++)
                {
                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    {
                        SvJudgement judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][0].Toolbase as SvJudgement;
                        if (judge.inParams.ContainsKey("InputImage"))
                        {
                            initOK &= SetResultImage(typeof(SvJudgement), i, 0, "InputImage");
                        }
                        else if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvRegion)))
                        {
                            initOK &= SetResultImage(typeof(SvRegion), i, 0, "InputImage");
                        }
                        else
                        {
                            object obj = judge.inParams["Value"].Instance;
                            initOK &= SetResultImage(obj.GetType(), i, 0, "InputImage");
                        }

                        continue;
                    }
                    //else if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                    //{
                    //    initOK &= SetResultImage(typeof(SvMakePoint), i, 0, "InputImage");
                    //    continue;
                    //}
                }
            }

            // DisplayTool Setting
            for (int i = 0; i < mAlignResult.JobInfo.Count; i++)
            {
                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                {
                    ListJudgeIndex.Add(i);
                    initOK &= SetDisplayToolOn(typeof(SvJudgement), i);
                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvJudgement)].Count; j++)
                    {
                        initOK &= SetResultJudgement(typeof(SvJudgement), i, j, "Judgement");
                    }
                }

                if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvMakePoint)))
                {
                    ListAlignIndex.Add(i);
                    initOK &= SetDisplayToolOn(typeof(SvMakePoint), i);
                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvMakePoint)].Count; j++)
                    {
                        initOK &= SetResultPoint(typeof(SvMakePoint), i, j, "OutPoint");
                    }
                }

                SetDisplayToolOn(typeof(SvFindLine), 0);
                SetDisplayToolOn(typeof(SvTemplateMatch), i);
                SetDisplayToolOn(typeof(SvIntersectLine), i);
                SetDisplayToolOn(typeof(SvDistance3P), i);
                SetDisplayToolOn(typeof(SvMakeRectFromLine), 0);
                SetDisplayToolOn(typeof(SvBlob), i);
                SetDisplayToolOn(typeof(SvMorphology), i);
            }

            // tray2robot
            SvCalibration cal = mRobotData.Calibrations;

            if (mProcData.FocalLength == 0)
                SequenceLog("[SystemData] Data.FocalLengrh is 0, so cann't use Tray to Robot perspective warrping", Common.SvLogger.LogType.SEQUENCE);
            else
                cal.GetPerspectivePoint(mProcData.FocalLength, mProcData.SensorWidth, mProcData.SensorHeight, out PerspectiveP, out WD);

            return initOK;
        }


        List<float> regionWidth = new List<float>();
        List<float> regionHeight = new List<float>();

        public override bool Do_CheckVisionJob()
        {
            try
            {
                // initialize 
                bool visionResult = true;

                List<SvToolBlock> listToolblock = new List<SvToolBlock>();
                listToolblock.Add(null);
                foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                    listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

                mAlignResult.List2JudgeValues.Clear();
                mAlignResult.List2JudgeSpec.Clear();
                mAlignResult.List2JudgeResult.Clear();

                mAlignResult.List2JudgeValues.Add(new List<double>());
                mAlignResult.List2JudgeSpec.Add(new List<double>());
                mAlignResult.List2JudgeResult.Add(new List<bool>());

                mAlignResult.List2FDC_BlobReference.Clear();
                mAlignResult.List2FDC_BlobReference.Add(new List<int>());
                //mAlignResult.List2FDC_JudgeReference.Clear();
                //mAlignResult.List2FDC_JudgeReference.Add(new List<int>());

                mAlignResult.ManualCheckJudge.Clear();

                // toolblock 이전까지 실행
                mJob.RunBeforeTool(listToolblock[1]);
                visionResult &= CheckVisionJob(mJob, 0);

                // toolblock cnt loop
                for (int i = 1; i < listToolblock.Count; i++)
                {
                    mAlignResult.List2JudgeValues.Add(new List<double>());
                    mAlignResult.List2JudgeSpec.Add(new List<double>());
                    mAlignResult.List2JudgeResult.Add(new List<bool>());

                    //mAlignResult.List2FDC_JudgeReference.Add(new List<int>());
                    mAlignResult.List2FDC_BlobReference.Add(new List<int>());

                    SvJudgement judge = null;
                    //SvRegion region = null;
                    SvTemplateMatch template = null;
                    SvBlob blob = null;

                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    {
                        judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][0].Toolbase as SvJudgement;
                    }

                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvBlob)))
                        blob = mAlignResult.JobInfo[i][typeof(SvBlob)][0].Toolbase as SvBlob;


                    //// region은 toolblock당 무조건 하나로!! <= 규칙 만약 없으면 Exception!!
                    //region = mAlignResult.JobInfo[i][typeof(SvRegion)][0].Toolbase as SvRegion;

                    //// toolblock inputparams link
                    //listToolblock[i].GetInParams();
                    //listToolblock[i].InitOutProperty();

                    //region.IndexXnext = 0; region.IndexYnext = 0;
                    //mRegionCount = region.Count_X * region.Count_Y;

                    //if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvTemplateMatch)) && mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    //    template = mAlignResult.JobInfo[i][typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;

                    //// region cnt loop
                    //for (mRegionIndex = 0; mRegionIndex < mRegionCount; mRegionIndex++)
                    //{
                    //    if (template != null && template.mPatternDataList.Count == mRegionCount)
                    //        template.SelectedPatternIndex = mRegionIndex;

                    //    if (judge != null && judge.Thresholds.Count == mRegionCount)
                    //        judge.Creteria = judge.Thresholds[mRegionIndex];

                    //    if (blob != null && blob.Ranges.Count == mRegionCount)
                    //        blob.RangeLow = blob.Ranges[mRegionIndex];

                    //    listToolblock[i].Run();
                    //    visionResult &= CheckVisionJob(listToolblock[i].ToolJob, i);

                    //    region.IncreaseIndex();
                    //}

                    // 2020.04.21 A.S.H : region 1개 → List<region> 변경
                    if (!mAlignResult.JobInfo[i].ContainsKey(typeof(SvRegion)))
                        throw new Exception("There is no Region.\r\nToolblock must have more than One Resion Tool");

                    List<SvRegion> listRegion = new List<SvRegion>();

                    for (int j = 0; j < mAlignResult.JobInfo[i][typeof(SvRegion)].Count; j++)
                    {
                        listRegion.Add(mAlignResult.JobInfo[i][typeof(SvRegion)][j].Toolbase as SvRegion);

                        regionWidth.Add((float)listRegion[j].RegionRect.Width);
                        regionHeight.Add((float)listRegion[j].RegionRect.Height);

                        if (j > 0)
                        {
                            if (listRegion[j - 1].Count_X * listRegion[j - 1].Count_Y != listRegion[j].Count_X * listRegion[j].Count_Y)
                                throw new Exception("Region Count is not Same count in one ToolBlock");
                        }
                        
                    }


                    // toolblock inputparams link
                    listToolblock[i].GetInParams();
                    listToolblock[i].InitOutProperty();

                    foreach (var v in listRegion)
                    {
                        v.IndexXnext = 0; v.IndexYnext = 0;
                    }
                    mRegionCount = listRegion[0].Count_X * listRegion[0].Count_Y;

                    if (mAlignResult.JobInfo[i].ContainsKey(typeof(SvTemplateMatch)) && mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                        template = mAlignResult.JobInfo[i][typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;

                    // region cnt loop
                    for (mRegionIndex = 0; mRegionIndex < mRegionCount; mRegionIndex++)
                    {
                        if (template != null && template.mPatternDataList.Count == mRegionCount)
                            template.SelectedPatternIndex = mRegionIndex;

                        if (judge != null && judge.Thresholds.Count == mRegionCount)
                            judge.Creteria = judge.Thresholds[mRegionIndex];

                        if (blob != null && blob.Ranges.Count == mRegionCount)
                            blob.RangeLow = blob.Ranges[mRegionIndex];

                        listToolblock[i].Run();
                        visionResult &= CheckVisionJob(listToolblock[i].ToolJob, i);

                        foreach (var v in listRegion)
                        {
                            v.IncreaseIndex();
                        }
                    }
                }

                return visionResult;
            }
            catch (Exception e)
            {
                SequenceLog(e.ToString(), Common.SvLogger.LogType.ERROR);
                return false;
            }
        }

        protected double WD = 0;
        protected Point2d PerspectiveP = new Point2d();
        protected bool CalculateAlignOffset()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;

                Mat tray2robotMat = null;
                tray2robotCal = new SvCalibration();

                mAlignResult.TargetPixelPoint.Clear();
                mAlignResult.TargetRobotPoint.Clear();
                mAlignResult.SendPoint.Clear();

                if (mProcData.FocalLength > 0 && mProcData.SensorHeight > 0 && mProcData.SensorWidth > 0)
                {
                    // Tray2Robot Warpping 적용
                    SvWarpping warp;

                    for (int j = 1; j < mAlignResult.JobInfo.Count; j++)
                    {
                        if (mAlignResult.JobInfo[j].ContainsKey(typeof(SvWarpping)))
                            warp = mAlignResult.JobInfo[j][typeof(SvWarpping)][0].Toolbase as SvWarpping;
                        else
                            continue;

                        SvPolyLine trayP = warp.OutLayoutPLine;
                        Point2d[] trayP2d = new Point2d[4];
                        for (int i = 0; i < 4; i++)
                            trayP2d[i] = cal.VtoR(new Point2d(trayP[i].X, trayP[i].Y));

                        tray2robotMat = cal.GetTray2RobotPerspectiveMatrix(trayP2d, PerspectiveP, WD, mRobotData.TrayWidth, mRobotData.TrayHeight);

                        if (tray2robotMat != null)
                            tray2robotCal.CalData.VtoRMat.Mat = tray2robotMat.Clone();
                    }
                }

                //double[,] calMat = SvFunc.DisplayMat(cal.CalData.VtoRMat.Mat);
                //double[,] tray2robot = SvFunc.DisplayMat(tray2robotMat);
                //double[,] sum = SvFunc.DisplayMat(tray2robotMat * cal.CalData.VtoRMat.Mat);

                for (int i = 0; i < mAlignResult.ResultPoints.Count; i++)
                {
                    // Target Position
                    mAlignResult.TargetPixelPoint.Add((mAlignResult.ResultPoints[i] as SvPoint).Point3d);
                    Point3d targetRobot;

                    Point2d targetRobot0;
                    Point2d targetRobot1;

                    targetRobot = cal.VtoR(mAlignResult.TargetPixelPoint[i], true, true);
                    if (tray2robotMat != null)
                    {
                        Point2d target2d = new Point2d(targetRobot.X, targetRobot.Y);
                        targetRobot0 = tray2robotCal.VtoR(target2d);
                        targetRobot1 = tray2robotCal.VtoR(target2d + new Point2d(Math.Cos(targetRobot.Z), Math.Sin(targetRobot.Z)));
                        Point2d vector = targetRobot1 - targetRobot0;
                        targetRobot = new Point3d(targetRobot0.X, targetRobot0.Y, Math.Atan2(vector.Y, vector.X));
                    }

                    //targetRobot.Z = NormalizeTheta(targetRobot.Z);//노멀라이징
                    
                    // TKL : AlignOffset 적용                    
                    if (mRobotData.AlignOffsets[0].Point3d != null)
                    {
                        Point3d offsetValue = mRobotData.AlignOffsets[0].Point3d;
                        Point3d offsetedTarget = ApplyTargetOffset(targetRobot, offsetValue);
                        mAlignResult.TargetRobotPoint.Add(offsetedTarget);
                    }
                    else
                    {
                        mAlignResult.TargetRobotPoint.Add(targetRobot);
                    }
                    
                    for (int j = 0; j < mAlignResult.ObjectRobotPoint.Count; j++)//reference를 멀티로 사용
                    {
                        //foreach (var refThread in mRefAutoThread)
                        {
                            // Target Position
                            Point3d targetP = mAlignResult.TargetRobotPoint[i];
                            if (cal.RotCenter.X == 0 && cal.RotCenter.Y == 0) // T-축이 없을경우는 그냥 X,Y 값을 빼준다...
                                targetP.Z = mAlignResult.ObjectRobotPoint[i].Z;
                            Point3d result3d = cal.RToT(mAlignResult.ObjectRobotPoint[j], targetP);
                            mAlignResult.TargetRevPoint.Add(result3d);
                            // Send Position
                            if (result3d.Z > Math.PI) result3d.Z -= 2 * Math.PI;
                            else if (result3d.Z < -Math.PI) result3d.Z += 2 * Math.PI;

                            Point3f result3f = new Point3f((float)result3d.X, (float)result3d.Y, (float)(result3d.Z * 180 / Math.PI));//[j];
                            mAlignResult.SendPoint.Add(result3f);
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public override bool Do_ExecuteAlignCalc()
        {
            try
            {
                SvCalibration cal = mRobotData.Calibrations;

                // 무조건 여기 있어야 함. AutoThread_Panel_NoMove가 접근해서 사용할 경우가 있다.
                mAlignResult.ObjectRobotPoint.Clear();

                // case1) tray with reference
                if (mRefAutoThread.Count > 0)
                {
                    for (int j = 0; j < mRefAutoThread[0].AlignResult.ObjectRobotPoint.Count; j++)//reference를 멀티로 사용
                    {
                        foreach (var refThread in mRefAutoThread)
                        {
                            mAlignResult.ObjectRobotPoint.Add(refThread.AlignResult.ObjectRobotPoint[j] - refThread.AlignResult.RotCenter3d + cal.RotCenter3d);
                        }
                    }
                }
                // case2) tray without reference
                else
                {
                    for (int j = 0; j < mRobotData.LoadPosition.Length; j++)//reference를 멀티로 사용
                    {
                        Point3d p = mRobotData.LoadPosition[j].Point3d;
                        p.Z *= Math.PI / 180;
                        {
                            mAlignResult.ObjectRobotPoint.Add(p);
                        }
                    }
                }

                if (ListAlignIndex.Count > 0 && !CalculateAlignOffset())
                {
                    SequenceLog("Calculate AlignOffset Fail!!", Common.SvLogger.LogType.ERROR);
                    return false;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        bool manualCheck;


        public override bool Do_Judgement()
        {
            bool judgeOk = true;
            bool isAlignOK = false;
            //int zeroCnt = 0;
            SvRegion region = null;
            //SvJudgement judge = null;
            int blockCnt = mAlignResult.JobInfo.Count;

            // 1) Align part  
            if (ListAlignIndex.Count > 0)
            {
                // 여기까지는 Judgement NG이면 모든 Send point를 0,0,0으로 초기화 하기 
                judgeOk = AlignResult.IsVisionOK;
                if (!judgeOk)
                {
                    int len = AlignResult.CheckJobResult.Count;
                    AlignResult.SendPoint.Clear();
                    if (mProcData.FlowType == PanelFlowType.Dual) len *= 2;

                    for (int i = 0; i < len; i++)
                    {
                        AlignResult.SendPoint.Add(new Point3f());
                    }
                }
                else
                {
                    // Tray 외곽 사이즈 체크 : 여기서 NG 처리될 경우 Tray size / tolerance 최적화 필요
                    judgeOk &= CheckTraySize();

                    // 좌표 리미트 체크 : 여기서는 리밋 초과되는 좌표만 0,0,0으로 초기화 하기
                    judgeOk &= CheckLimit();

                    // Tray Pocket Distance 체크 : 여기서 Pocket 거리가 Key In한 Data와 비교시 크면 NG
                    judgeOk &= CheckPocket();
                }

                mAlignResult.List2JudgeResult[0].Add(judgeOk);
            }
            isAlignOK = judgeOk;

            // 2) Inspection part
            // toolblock cnt loop
            for (int i = 1; i < blockCnt; i++)
            {
                if (!mAlignResult.JobInfo[i].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                {
                    mAlignResult.List2JudgeResult[i].Add(isAlignOK);
                    continue;
                }

                manualCheck = false;
                region = mAlignResult.JobInfo[i][typeof(SvRegion)][0].Toolbase as SvRegion;
                //judge = mAlignResult.JobInfo[i][typeof(SvJudgement)][0].Toolbase as SvJudgement;

                if (mProcData.UseManualAlign && mAlignResult.List2JudgeResult[i].Contains(false))
                {
                    judgeOk = Do_ManualCheck(i);
                    manualCheck = true;
                }

                for (int j = 0; j < mAlignResult.List2JudgeValues[i].Count; j++)
                {
                    // display
                    string sJudge = string.Format("{0} : ", (j + 1));
                    sJudge += mAlignResult.List2JudgeResult[i][j] ? "OK" : "NG";
                    sJudge += string.Format("\n{0:f2} \n(spec : {1:f2})", mAlignResult.List2JudgeValues[i][j], mAlignResult.List2JudgeSpec[i][j]);

                    System.Drawing.Color color = (mAlignResult.List2JudgeResult[i][j]) ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Orange;
                    System.Drawing.Pen pen = new System.Drawing.Pen(color);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);

                    region.Run();

                    //SvRectangle rect = region.OutputImage.RegionRect;

                    SvRectangle rect;

                    if (region.OutputImage != null)
                        rect = region.OutputImage.RegionRect;
                    else
                    {
                        //rect = mAlignResult.InputImage.RegionRect;
                        judgeOk = false;
                        break;
                    }
                    System.Drawing.PointF pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);

                    int blockindex = i;

                    mUpdateDisplayCode.Add(new Action(() =>
                    {
                        ViewModel.Edit.CustomImageList[blockindex].drawingFunc +=
                        (display) =>
                        {
                            if (manualCheck)
                                display.DrawString("Manual Inspection", font16, System.Drawing.Brushes.SkyBlue, new Point2d(50, 50));

                            display.DrawString(sJudge, font08, brush, pnt);
                            display.DrawRectangle(pen, rect.RectF);
                        };
                    }));

                    region.IncreaseIndex();
                }

                if (mProcData.InspectType == EInspectType.Judgement && mProcData.UseInspect)
                {
                    if (mAlignResult.List2JudgeResult[i].Contains(false))
                        judgeOk = false;
                }

                mAlignResult.ManualCheckJudge.Add(manualCheck);
            }

            return judgeOk;
        }

        public override bool Do_WriteResult()
        {
            // exist
            int sendVal;
            string result = "";
            bool sendresult = true;
            int lastPos = 0;
            int judgeidx = 1;
            int blockCnt = (mAlignResult.JobInfo.Count - 1);
            //int blobSpec = 0;
            //int judgeSpec = 0;

            // Inspection
            try
            {
                // inspection Result Log 생성 및 저장
                string strInspHeader = "Data, Time, PPID, JobName, CELLID, Index, M-Check, M-CheckResult, JudgeResult";
                string strPattern = "%newline%date{yyyy-MM-dd}, %date{HH:mm:ss.ff}, %message";
                //string strPattern = "%newline%date{yyyy-MM-dd}, %date{HH:mm:ss.ff}, %logger, %message";
                string strProcess = mProcess.ToString() + "_Judge";

                if (!Logger.Log.ContainsKey(strProcess))
                    Logger.Log.Add(strProcess, new LogItem(strProcess, Main.RootPath + "SVL_Data\\Log\\Data\\Judge", strInspHeader, strPattern));

                for (int k = 1; k <= blockCnt; k++)
                {
                    if (!mAlignResult.JobInfo[k].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[k].ContainsKey(typeof(SvJudgement)))
                        continue;

                    result = "";

                    if (mProcData.InspReverse)
                        sendVal = 0xFFFF;
                    else
                        sendVal = 0x0000;

                    bool CheckResult = true;

                    for (int i = 0; i < mAlignResult.List2JudgeResult[k].Count; i++)
                    {
                        SetBit(ref sendVal, i, mAlignResult.List2JudgeResult[k][i]);

                        int slog = mAlignResult.List2JudgeResult[k][i] == true ? 1 : 0;
                        result = slog + result;
                        CheckResult &= mAlignResult.List2JudgeResult[k][i];
                    }

                    lastPos = mInspectAddr + ((judgeidx - 1) * 2);
                    sendresult &= mRobot.WriteValue(lastPos, sendVal);
                    SequenceLog(result, Common.SvLogger.LogType.DATA);
                    DataLog(result);

                    string cellID;
                    if (cells.Count != 0)
                        cellID = cells[0].ToString();
                    else
                        cellID = "Unknown";

                    int mCheck = mAlignResult.ManualCheckJudge[k-1] == true ? 1 : 0 ;
                    int mCheckResult = CheckResult == true ? 1 : 0;
                    string msg = string.Format(Auto.mCurrentRecipeName + ", " + mJob.Name + ", " + cellID + ", " + k + ", " + mCheck + ", " + mCheckResult + ", " + result);
                    WriteJudgeLog(strProcess, msg);
                    judgeidx++;
                }

                // align offset
                lastPos = mOffsetAddr;
                if (mAlignResult.SendPoint.Count > 0)
                    sendresult &= WriteRevOffset(lastPos, mAlignResult.SendPoint);//2워드 이후부터 위치값 저장한다..

                if (mProcData.WriteFDC)
                {
                    // FDC Value Write
                    //judgeSpec = mFDCAddr;
                    //blobSpec = judgeSpec + 1;
                    //double judgeValue = 0;

                    //for (int i = 1; i <= blockCnt; i++)
                    //{
                    //    if (!mAlignResult.JobInfo[i].ContainsKey(typeof(SvBlob)) || !mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                    //        continue;

                    //    for (int j = 0; j < mAlignResult.List2FDC_BlobReference[i].Count; j++)
                    //    {
                    //        if (judgeValue <= (mAlignResult.List2JudgeSpec[i][j] * 100))
                    //            judgeValue = (mAlignResult.List2JudgeSpec[i][j] * 100);

                    //        sendresult &= mRobot.WriteValue(blobSpec, (short)mAlignResult.List2FDC_BlobReference[i][j]);
                    //        blobSpec++;
                    //    }

                    //    sendresult &= mRobot.WriteValue(judgeSpec, (short)(judgeValue));
                    //}

                    // FDC Value Write 2020.05.13 _ LSH

                    lastPos = mFDCAddr;

                    //if (mAlignResult.SendPoint.Count !=0)
                    //{
                    lastPos = mFDCAddr;

                    List<float> spec = new List<float>();

                    spec.Add(mModelData.ScoreCreteria);
                    spec.Add(mModelData.FindLineDist);
                    spec.Add(mModelData.FindLineNG);
                    spec.Add((float)mRobotData.TrayWidth);
                    spec.Add((float)mRobotData.TrayHeight);
                    spec.Add((float)mRobotData.TrayTolerance);

                    sendresult &= mRobot.WriteValues(lastPos, spec);
                    //}

                    List<float> judge = new List<float>();

                    for (int i = 1; i <= blockCnt; i++)
                    {
                        if (!mAlignResult.JobInfo[i].ContainsKey(typeof(SvJudgement)))
                            continue;

                        judge.Add(regionWidth[i - 1]);
                        judge.Add(regionHeight[i - 1]);

                        for (int j = 0; j < mAlignResult.List2JudgeResult[i].Count; j++)
                        {
                            judge.Add((float)Math.Round(mAlignResult.List2JudgeValues[i][j], 3));
                            judge.Add((float)Math.Round(mAlignResult.List2JudgeSpec[i][j], 3));
                        }
                    }

                    if (judge.Count != 0)
                    {
                        lastPos = mFDCAddr + 20;
                        sendresult &= mRobot.WriteValues(lastPos, judge);
                    }
                }

                return sendresult;
            }

            catch
            {
                sendresult = false;
                return sendresult;
            }
        }

        //public override bool Do_ManualCheck(int index)
        public bool Do_ManualCheck(int index)
        {

            List<SvToolBlock> listToolblock = new List<SvToolBlock>();
            listToolblock.Add(null);

            foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                listToolblock.Add(toolinfo.Toolbase as SvToolBlock);

            bool isOk = true;
            SequenceLog("ManualInspection Start", Common.SvLogger.LogType.SEQUENCE);

            mIO.SetOutValue(mSystem.OPCallBit, true, false);//set op-call bit

            isOk &= ConnectUDP();
            SvJob manualJob = listToolblock[index].ToolJob;

            mManualAlignDispatcher.Invoke(() =>
            {
                ManualInspection wnd = new ManualInspection();
                wnd.Title = mJob.Name;
                wnd.InitWnd(mAlignResult, manualJob, mIO, mProcData.IOParam.Inputs[InSignal.Complete.ToString()], index);
                isOk &= wnd.ShowDialog() == true;
            });

            mIO.SetOutValue(mSystem.OPCallBit, false, false);//reset op-call bit
            listToolblock.Clear();
            GC.Collect();
            SequenceLog("ManualAlign End", Common.SvLogger.LogType.SEQUENCE);
            return isOk;


            //return true;
        }

        public bool ConnectUDP()
        {
            try
            {
                UDPClient udpClient = new UDPClient();
                //udpClient.DisConnect();
                udpClient.Connect(mSystem.IOCIP, mSystem.IOCPortNumber, 100, 1000);
                string msg = string.Format("{0}_{1}", mSystem.MachineNumber, mSystem.VisionIP);

                udpClient.Sendata(msg);

                udpClient.DisConnect();

                return true;
            }

            catch (Exception ex)
            {
                SequenceLog("UDP Interface Error", Common.SvLogger.LogType.ERROR);
                return false;
            }
        }

        //public override bool Do_WriteJudgement()
        //{
        //    bool isWriteJudgeOk = true;
        //    if (mAlignResult.IsJudgeOK)
        //    {
        //        isWriteJudgeOk = mIO.SetOutValue(OutAddr[OutSignal.OK.ToString()], true);
        //    }
        //    else
        //    {
        //        isWriteJudgeOk = mIO.SetOutValue(OutAddr[OutSignal.NG.ToString()], true);
        //    }
        //    return isWriteJudgeOk;
        //}
    }
}
