﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public partial class DataEdit_Base : Form
    {
        public DataEdit_Base() { }
        public DataEdit_Base(RecipeData _recipeData, Main.Process _process, string _jobName)
        {
            if (_recipeData == null) return;

            mRecipeData = _recipeData;
            mProcess = _process;
            mJobName = _jobName;

            mSerializer = new SvSerializer();
            mJobPath = Path.Combine(Main.JobPath, _jobName);
            try
            {
                mJob = mSerializer.LoadJob(mJobPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                IsPossible = false;
                return;
            }

            if (mJob == null || mJob.ToolList.Count == 0) return;

            GetJobInfo(mJob);

            InitializeComponent();
        }

        public bool IsPossible = false;
        protected SvSerializer mSerializer;
        protected string mJobPath;
        protected RecipeData mRecipeData;
        protected string mJobName;
        protected Main.Process mProcess;
        protected AlignResult mAlignResult = new AlignResult();
        protected SvJob mJob;

        //public abstract void btn_Run_Click(object sender, EventArgs e);

        //public abstract void btn_Save_Click(object sender, EventArgs e);

        public int mJobinfoIndex;
        protected bool GetJobInfo(SvJob _job, int _blockindex = 0)
        {
            if (_job == null) return false;
            try
            {
                mAlignResult.JobInfo.Add(new Dictionary<Type, List<sCheckToolInfo>>());
                foreach (SvToolBase toolbase in _job.ToolList)
                {
                    if (!mAlignResult.JobInfo[_blockindex].ContainsKey(toolbase.GetType()))
                        mAlignResult.JobInfo[_blockindex].Add(toolbase.GetType(), new List<sCheckToolInfo>());

                    mAlignResult.JobInfo[_blockindex][toolbase.GetType()].Add(new sCheckToolInfo(toolbase, false));

                    if (toolbase is SvAcquisition)
                    {
                        toolbase.InitOutProperty();
                        (toolbase as SvAcquisition).OpenDevice();

                        mAlignResult.JobInfo[_blockindex][toolbase.GetType()][0].NeedCheck = true;
                    }

                    if (toolbase is SvRegion)
                        (toolbase as SvRegion).IsAutoIndex = false;

                    if (toolbase is SvTemplateMatch)
                        (toolbase as SvTemplateMatch).IsAutoIndex = false;

                    if (toolbase is SvToolBlock)
                    {
                        GetJobInfo((toolbase as SvToolBlock).ToolJob, mAlignResult.JobInfo[_blockindex][typeof(SvToolBlock)].Count);
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        protected double NormalizeTheta(double _rad)
        {
            return AlignMath.NormalizeTheta(_rad);
        }
    }
}
