﻿using OpenCvSharp.CPlusPlus;
using SvMip.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    class DataEdit_LoadInspection : DataEdit_Base
    {
        ProcessData mProcData;

        public DataEdit_LoadInspection(ProcessData _procdata, RecipeData _recipeData, Main.Process _process, string _jobName) : base(_recipeData, _process, _jobName)
        {
            InitializeComponent();

            mProcData = _procdata;
            IsPossible = InitJob();
        }

        public bool InitJob()
        {
            // Toolblock check
            if (mAlignResult.JobInfo.Count < 2)
            {
                MessageBox.Show("There is no Toolblock Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // get region
            if (mAlignResult.JobInfo[1].ContainsKey(typeof(SvRegion)))
            {
                mRegion = mAlignResult.JobInfo[1][typeof(SvRegion)][0].Toolbase as SvRegion;
            }
            else
            {
                MessageBox.Show("There is no SvRegion Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            // get tool
            if (mProcData.InspectTool == EInspectTool.Histo)
            {
                if (mAlignResult.JobInfo[1].ContainsKey(typeof(SvHistogram)))
                {
                    mHisto = mAlignResult.JobInfo[1][typeof(SvHistogram)][0].Toolbase as SvHistogram;
                }
                else
                {
                    MessageBox.Show("There is no SvHistogram Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else//templete
            {
                if (mAlignResult.JobInfo[1].ContainsKey(typeof(SvTemplateMatch)))
                {
                    mTemplate = mAlignResult.JobInfo[1][typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;
                }
                else
                {
                    MessageBox.Show("There is no SvTemplateMatch Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
                        
            nud_Rate.Value = (decimal)mRate;            
            return true;
        }

        SvRegion mRegion;
        SvTemplateMatch mTemplate;
        SvHistogram mHisto;
        float mRate = 0.7f;
        Rectf regionRectf;
        Rectf patternRectf;

        private void nud_Rate_ValueChanged(object sender, EventArgs e)
        {
            mRate = (float)nud_Rate.Value;
            DisplayRect();
        }

        private void nud_Value_add_ValueChanged(object sender, EventArgs e)
        {
            mRegion.RegionRect.Location = new Point2f((float)(nud_StartX.Value + nud_StartX_add.Value), (float)(nud_StartY.Value + nud_StartY_add.Value));
            mRegion.Dist_X = nud_DistX.Value + nud_DistX_add.Value;
            mRegion.Dist_Y = nud_DistY.Value + nud_DistY_add.Value;
            mRegion.RegionRect.Width = (float)(nud_Width.Value) + (float)(nud_Width_add.Value);
            mRegion.RegionRect.Height = (float)(nud_Height.Value) + (float)(nud_Height_add.Value);


            DisplayRect();
        }

        private void DisplayRect()
        {
            float regionwidth = mRegion.RegionRect.Width;
            float regionheight = mRegion.RegionRect.Height;
            float patternwidth = mRegion.RegionRect.Width * mRate;
            float patternheight = mRegion.RegionRect.Height * mRate;

            System.Drawing.PointF cp = mRegion.RegionRect.Center;
            
            svDisplayView1.Image = mRegion.InputImage;

            svDisplayView1.ClearImage();
            svDisplayView1.GraphicsCollection.Clear();

            for (int i = 0; i < mRegion.Count_X; i++)
            {
                for (int j = 0; j < mRegion.Count_Y; j++)
                {
                    try
                    {
                        SvImage pattern = new SvImage();

                        regionRectf = new Rectf(cp.X - regionwidth / 2 + i * (float)mRegion.Dist_X, cp.Y - regionheight / 2 + j * (float)mRegion.Dist_Y, regionwidth, regionheight);
                        patternRectf = new Rectf(cp.X - patternwidth / 2 + i * (float)mRegion.Dist_X, cp.Y - patternheight / 2 + j * (float)mRegion.Dist_Y, patternwidth, patternheight);
                        
                        regionRect = new SvRectangle(regionRectf);
                        regionRect.Color = Color.Yellow;
                        svDisplayView1.GraphicsCollection.Add(regionRect);

                        patternRect = new SvRectangle(patternRectf);
                        patternRect.Color = Color.Red;
                        svDisplayView1.GraphicsCollection.Add(patternRect);
                    }
                    catch
                    {
                        continue;
                    }
                }
            }

        }

        SvRectangle regionRect;
        SvRectangle patternRect;

        public void btn_Run_Click(object sender, EventArgs e)
        {
            mJob.Run();

            nud_StartX.Text = (mRegion.RegionRect.Location.X).ToString("F3");
            nud_StartY.Text = (mRegion.RegionRect.Location.Y).ToString("F3");

            nud_DistX.Text = (mRegion.Dist_X).ToString("F3");
            nud_DistY.Text = (mRegion.Dist_Y).ToString("F3");

            nud_Width.Text = (mRegion.RegionRect.Width).ToString("F3");
            nud_Height.Text = (mRegion.RegionRect.Height).ToString("F3");

            nud_StartX_add.Value = 0;
            nud_StartY_add.Value = 0;

            nud_DistX_add.Value = 0;
            nud_DistY_add.Value = 0;

            nud_Width_add.Value = 0;
            nud_Height_add.Value = 0;

            DisplayRect();
        }

        public void btn_Save_Click(object sender, EventArgs e)
        {
            if (mJob == null || mJob.ToolList.Count == 0) return;
            
            string recipeName = mRecipeData.RecipeName; //이거보단 class 이름이 더 나으려나?

            if (nud_StartX_add.Value != 0)
            {
                float start_X = (float)(nud_StartX.Value + nud_StartX_add.Value);
                //SvLogger.Log.Recipe(recipeName + " X Start Offset Change : " + nud_StartX_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray X Start Point Change : " + nud_StartX.Value.ToString("F1") + " → " + start_X.ToString("F1"));
            }

            if (nud_StartY_add.Value != 0)
            {
                float start_Y = (float)(nud_StartY.Value + nud_StartY_add.Value);
                //SvLogger.Log.Recipe(recipeName + " Y Start Offset Change : " + nud_StartY_add.Value.ToString("F1"));
            }
            
            if (nud_DistX_add.Value != 0)
            {
                float offset_X = (float)(nud_DistX.Value + nud_DistX_add.Value);
                //SvLogger.Log.Recipe(recipeName + " X Distance Offset Change : " + nud_DistX_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray X Distance Change : " + nud_DistX.Value.ToString("F1") + " → " + offset_X.ToString("F1"));
            }

            if (nud_DistY_add.Value != 0)
            {
                float offset_Y = (float)(nud_DistY.Value + nud_DistY_add.Value);
                //SvLogger.Log.Recipe(recipeName + " Y Distance Offset Change : " + nud_DistY_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray Y Distance Change : " + nud_DistY.Value.ToString("F1") + " → " + offset_Y.ToString("F1"));
            }
            
            if (nud_DistX_add.Value != 0)
            {
                float offset_X = (float)(nud_Width.Value + nud_Width_add.Value);
                //SvLogger.Log.Recipe(recipeName + " X Distance Offset Change : " + nud_DistX_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray Width Change : " + nud_Width.Value.ToString("F1") + " → " + offset_X.ToString("F1"));
            }
            
            if (nud_DistY_add.Value != 0)
            {
                float offset_Y = (float)(nud_Height.Value + nud_Height_add.Value);
                //SvLogger.Log.Recipe(recipeName + " Y Distance Offset Change : " + nud_DistY_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray Height Change : " + nud_Height.Value.ToString("F1") + " → " + offset_Y.ToString("F1"));
            }

            // init list
            if (mProcData.InspectTool == EInspectTool.Histo)
            {
                mHisto.Thresholds.Clear();
            }
            else
            {
                for (int i = 0; i < mTemplate.mPatternDataList.Count; i++)
                    mTemplate.mPatternDataList[i].Value.Dispose();

                mTemplate.mPatternDataList.Clear();
            }

            float patternwidth = mRegion.RegionRect.Width * mRate;
            float patternheight = mRegion.RegionRect.Height * mRate;
            System.Drawing.PointF cp = mRegion.RegionRect.Center;

            mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

            for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
            {
                try
                {
                    mRegion.Run();

                    patternRectf = new Rectf(cp.X - patternwidth / 2 + mRegion.Index_X * (float)mRegion.Dist_X, cp.Y - patternheight / 2 + mRegion.Index_Y * (float)mRegion.Dist_Y, patternwidth, patternheight);

                    if (mProcData.InspectTool == EInspectTool.Histo)
                    {
                        mHisto.InputImage = mRegion.SubImage;
                        mHisto.Run();
                        mHisto.Thresholds.Add(Math.Round(mHisto.Mean, 2));
                    }
                    else//regist templete
                    {
                        SvImage pattern = new SvImage();

                        pattern.Mat = mRegion.InputImage.Mat[SvFunc.Rectf2Rect(patternRectf)];
                        PatternData patterndata = new PatternData(pattern);

                        string name = "pattern" + i.ToString();
                        string path = Path.Combine(Main.RecipePath, Auto.mCurrentRecipeName, name);
                        path = Path.ChangeExtension(path, "pti");
                        patterndata.SavePattern(path);

                        mTemplate.mPatternDataList.Add(new System.Collections.Generic.KeyValuePair<string, PatternData>(path, patterndata));
                    }
                    
                    mRegion.IncreaseIndex();                    
                }
                catch
                {
                    continue;
                }
            }

            bool issave = mSerializer.SaveJob(mJob, mJobPath);

            if (issave)
                MessageBox.Show("Job Save Success!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Job Save Fail!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }



        /// <summary>
        /// Designer에서 생성한 코드
        /// </summary>
        /// 
        public NumericUpDown nud_Rate;
        public Button btn_RegionSave;
        private System.ComponentModel.IContainer components;
        public Button btn_Run;
        public NumericUpDown nud_DistX_add;
        public NumericUpDown nud_DistY_add;
        public NumericUpDown nud_StartX_add;
        public NumericUpDown nud_StartY_add;
        public NumericUpDown nud_DistX;
        public NumericUpDown nud_DistY;
        public NumericUpDown nud_StartX;
        public NumericUpDown nud_StartY;
        private Label label6;
        private Label label8;
        private Label label7;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        public Display.SvDisplayViewInteract svDisplayView1;
        private Label label9;
        private Label label10;
        public NumericUpDown nud_Height;
        public NumericUpDown nud_Height_add;
        private Label label11;
        private Label label12;
        public NumericUpDown nud_Width;
        public NumericUpDown nud_Width_add;

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nud_Rate = new System.Windows.Forms.NumericUpDown();
            this.btn_RegionSave = new System.Windows.Forms.Button();
            this.btn_Run = new System.Windows.Forms.Button();
            this.nud_DistX_add = new System.Windows.Forms.NumericUpDown();
            this.nud_DistY_add = new System.Windows.Forms.NumericUpDown();
            this.nud_StartX_add = new System.Windows.Forms.NumericUpDown();
            this.nud_StartY_add = new System.Windows.Forms.NumericUpDown();
            this.nud_DistX = new System.Windows.Forms.NumericUpDown();
            this.nud_DistY = new System.Windows.Forms.NumericUpDown();
            this.nud_StartX = new System.Windows.Forms.NumericUpDown();
            this.nud_StartY = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.svDisplayView1 = new SvMip.Display.SvDisplayViewInteract();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.nud_Height = new System.Windows.Forms.NumericUpDown();
            this.nud_Height_add = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.nud_Width = new System.Windows.Forms.NumericUpDown();
            this.nud_Width_add = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Height)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Height_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Width)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Width_add)).BeginInit();
            this.SuspendLayout();
            // 
            // nud_Rate
            // 
            this.nud_Rate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_Rate.DecimalPlaces = 1;
            this.nud_Rate.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Rate.Location = new System.Drawing.Point(705, 358);
            this.nud_Rate.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            65536});
            this.nud_Rate.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Rate.Name = "nud_Rate";
            this.nud_Rate.Size = new System.Drawing.Size(97, 20);
            this.nud_Rate.TabIndex = 9;
            this.nud_Rate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Rate.Value = new decimal(new int[] {
            6,
            0,
            0,
            65536});
            this.nud_Rate.ValueChanged += new System.EventHandler(this.nud_Rate_ValueChanged);
            // 
            // btn_RegionSave
            // 
            this.btn_RegionSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_RegionSave.Location = new System.Drawing.Point(705, 435);
            this.btn_RegionSave.Name = "btn_RegionSave";
            this.btn_RegionSave.Size = new System.Drawing.Size(97, 43);
            this.btn_RegionSave.TabIndex = 8;
            this.btn_RegionSave.Text = "Save";
            this.btn_RegionSave.UseVisualStyleBackColor = true;
            this.btn_RegionSave.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Run
            // 
            this.btn_Run.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Run.Location = new System.Drawing.Point(705, 386);
            this.btn_Run.Name = "btn_Run";
            this.btn_Run.Size = new System.Drawing.Size(97, 43);
            this.btn_Run.TabIndex = 8;
            this.btn_Run.Text = "Run";
            this.btn_Run.UseVisualStyleBackColor = true;
            this.btn_Run.Click += new System.EventHandler(this.btn_Run_Click);
            // 
            // nud_DistX_add
            // 
            this.nud_DistX_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_DistX_add.DecimalPlaces = 1;
            this.nud_DistX_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_DistX_add.Location = new System.Drawing.Point(144, 457);
            this.nud_DistX_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistX_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistX_add.Name = "nud_DistX_add";
            this.nud_DistX_add.Size = new System.Drawing.Size(79, 20);
            this.nud_DistX_add.TabIndex = 48;
            this.nud_DistX_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_DistX_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_DistY_add
            // 
            this.nud_DistY_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_DistY_add.DecimalPlaces = 1;
            this.nud_DistY_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_DistY_add.Location = new System.Drawing.Point(725, 101);
            this.nud_DistY_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistY_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistY_add.Name = "nud_DistY_add";
            this.nud_DistY_add.Size = new System.Drawing.Size(76, 20);
            this.nud_DistY_add.TabIndex = 44;
            this.nud_DistY_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_DistY_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_StartX_add
            // 
            this.nud_StartX_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_StartX_add.DecimalPlaces = 1;
            this.nud_StartX_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_StartX_add.Location = new System.Drawing.Point(29, 457);
            this.nud_StartX_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartX_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartX_add.Name = "nud_StartX_add";
            this.nud_StartX_add.Size = new System.Drawing.Size(79, 20);
            this.nud_StartX_add.TabIndex = 43;
            this.nud_StartX_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_StartX_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_StartY_add
            // 
            this.nud_StartY_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_StartY_add.DecimalPlaces = 1;
            this.nud_StartY_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_StartY_add.Location = new System.Drawing.Point(725, 44);
            this.nud_StartY_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartY_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartY_add.Name = "nud_StartY_add";
            this.nud_StartY_add.Size = new System.Drawing.Size(76, 20);
            this.nud_StartY_add.TabIndex = 42;
            this.nud_StartY_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_StartY_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_DistX
            // 
            this.nud_DistX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_DistX.DecimalPlaces = 1;
            this.nud_DistX.Enabled = false;
            this.nud_DistX.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DistX.Location = new System.Drawing.Point(126, 438);
            this.nud_DistX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistX.Name = "nud_DistX";
            this.nud_DistX.ReadOnly = true;
            this.nud_DistX.Size = new System.Drawing.Size(97, 20);
            this.nud_DistX.TabIndex = 41;
            this.nud_DistX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_DistY
            // 
            this.nud_DistY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_DistY.DecimalPlaces = 1;
            this.nud_DistY.Enabled = false;
            this.nud_DistY.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DistY.Location = new System.Drawing.Point(706, 82);
            this.nud_DistY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistY.Name = "nud_DistY";
            this.nud_DistY.ReadOnly = true;
            this.nud_DistY.Size = new System.Drawing.Size(96, 20);
            this.nud_DistY.TabIndex = 40;
            this.nud_DistY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_StartX
            // 
            this.nud_StartX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_StartX.DecimalPlaces = 1;
            this.nud_StartX.Enabled = false;
            this.nud_StartX.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_StartX.Location = new System.Drawing.Point(12, 438);
            this.nud_StartX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartX.Name = "nud_StartX";
            this.nud_StartX.ReadOnly = true;
            this.nud_StartX.Size = new System.Drawing.Size(97, 20);
            this.nud_StartX.TabIndex = 39;
            this.nud_StartX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_StartY
            // 
            this.nud_StartY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_StartY.DecimalPlaces = 1;
            this.nud_StartY.Enabled = false;
            this.nud_StartY.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_StartY.Location = new System.Drawing.Point(706, 26);
            this.nud_StartY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartY.Name = "nud_StartY";
            this.nud_StartY.ReadOnly = true;
            this.nud_StartY.Size = new System.Drawing.Size(96, 20);
            this.nud_StartY.TabIndex = 47;
            this.nud_StartY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(123, 421);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 15);
            this.label6.TabIndex = 36;
            this.label6.Text = "Dist. X";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(701, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 15);
            this.label8.TabIndex = 35;
            this.label8.Text = "Dist. Y";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(701, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 34;
            this.label7.Text = "Start Y";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 421);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 33;
            this.label5.Text = "Start X";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(127, 459);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 17);
            this.label4.TabIndex = 31;
            this.label4.Text = "+";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(13, 459);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 17);
            this.label3.TabIndex = 30;
            this.label3.Text = "+";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(703, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 29;
            this.label2.Text = "+";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(703, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 32;
            this.label1.Text = "+";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // svDisplayView1
            // 
            this.svDisplayView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.svDisplayView1.AutoScroll = true;
            this.svDisplayView1.CurrentObject = null;
            this.svDisplayView1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svDisplayView1.Location = new System.Drawing.Point(12, 12);
            this.svDisplayView1.Name = "svDisplayView1";
            this.svDisplayView1.Size = new System.Drawing.Size(683, 405);
            this.svDisplayView1.TabIndex = 28;
            this.svDisplayView1.ToastVisible = true;
            this.svDisplayView1.ZoomVisible = false;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.Location = new System.Drawing.Point(705, 162);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 17);
            this.label9.TabIndex = 29;
            this.label9.Text = "+";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(703, 124);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 15);
            this.label10.TabIndex = 35;
            this.label10.Text = "Height";
            // 
            // nud_Height
            // 
            this.nud_Height.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_Height.DecimalPlaces = 1;
            this.nud_Height.Enabled = false;
            this.nud_Height.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Height.Location = new System.Drawing.Point(708, 141);
            this.nud_Height.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Height.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Height.Name = "nud_Height";
            this.nud_Height.ReadOnly = true;
            this.nud_Height.Size = new System.Drawing.Size(96, 20);
            this.nud_Height.TabIndex = 40;
            this.nud_Height.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_Height_add
            // 
            this.nud_Height_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_Height_add.DecimalPlaces = 1;
            this.nud_Height_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Height_add.Location = new System.Drawing.Point(727, 160);
            this.nud_Height_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Height_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Height_add.Name = "nud_Height_add";
            this.nud_Height_add.Size = new System.Drawing.Size(76, 20);
            this.nud_Height_add.TabIndex = 44;
            this.nud_Height_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Height_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label11.Location = new System.Drawing.Point(245, 459);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 17);
            this.label11.TabIndex = 31;
            this.label11.Text = "+";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(241, 421);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 15);
            this.label12.TabIndex = 36;
            this.label12.Text = "Width";
            // 
            // nud_Width
            // 
            this.nud_Width.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_Width.DecimalPlaces = 1;
            this.nud_Width.Enabled = false;
            this.nud_Width.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_Width.Location = new System.Drawing.Point(244, 438);
            this.nud_Width.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Width.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Width.Name = "nud_Width";
            this.nud_Width.ReadOnly = true;
            this.nud_Width.Size = new System.Drawing.Size(97, 20);
            this.nud_Width.TabIndex = 41;
            this.nud_Width.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_Width_add
            // 
            this.nud_Width_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_Width_add.DecimalPlaces = 1;
            this.nud_Width_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Width_add.Location = new System.Drawing.Point(262, 457);
            this.nud_Width_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Width_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Width_add.Name = "nud_Width_add";
            this.nud_Width_add.Size = new System.Drawing.Size(79, 20);
            this.nud_Width_add.TabIndex = 48;
            this.nud_Width_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Width_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // DataEdit_LoadInspection
            // 
            this.ClientSize = new System.Drawing.Size(814, 490);
            this.Controls.Add(this.nud_Width_add);
            this.Controls.Add(this.nud_DistX_add);
            this.Controls.Add(this.nud_Height_add);
            this.Controls.Add(this.nud_DistY_add);
            this.Controls.Add(this.nud_StartX_add);
            this.Controls.Add(this.nud_StartY_add);
            this.Controls.Add(this.nud_Width);
            this.Controls.Add(this.nud_DistX);
            this.Controls.Add(this.nud_Height);
            this.Controls.Add(this.nud_DistY);
            this.Controls.Add(this.nud_StartX);
            this.Controls.Add(this.nud_StartY);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.svDisplayView1);
            this.Controls.Add(this.nud_Rate);
            this.Controls.Add(this.btn_Run);
            this.Controls.Add(this.btn_RegionSave);
            this.Name = "DataEdit_LoadInspection";
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Height)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Height_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Width)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Width_add)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
