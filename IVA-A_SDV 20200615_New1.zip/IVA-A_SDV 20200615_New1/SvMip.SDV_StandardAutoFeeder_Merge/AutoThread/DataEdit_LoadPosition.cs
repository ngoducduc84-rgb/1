﻿using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;
using SvMip.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public class DataEdit_LoadPosition : DataEdit_Base
    {
        public DataEdit_LoadPosition(RecipeData _recipeData, Main.Process _process, string _jobName)
            : base(_recipeData, _process, _jobName)
        {
            InitializeComponent();
            IsPossible = InitJob();
        }
        System.Drawing.Font font10 = new System.Drawing.Font("Segoe UI", 10, System.Drawing.FontStyle.Bold);


        public bool InitJob()
        {
            //if (!mAlignResult.JobInfo.ContainsKey(typeof(SvWarppingPoint)))
            //{
            //    MessageBox.Show("There is no SvWarppingPoint Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return false;
            //}
            //mWarpPoint = mAlignResult.JobInfo[typeof(SvWarppingPoint)][0].Toolbase as SvWarppingPoint;

            if (!mAlignResult.JobInfo[0].ContainsKey(typeof(SvToolBlock)))
            {
                MessageBox.Show("There is no SvToolBlock Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvRegion)))
            {
                MessageBox.Show("There is no SvRegion Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            
            if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvMakePoint)))
            {
                MessageBox.Show("There is no SvMakePoint Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            //if (!mAlignResult.JobInfo.ContainsKey(typeof(SvTemplateMatch)))
            //{
            //    MessageBox.Show("There is no SvTemplateMatch Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return false;
            //}

            mRegion = mAlignResult.JobInfo[1][typeof(SvRegion)][0].Toolbase as SvRegion;
            //mTemplate = mAlignResult.JobInfo[typeof(SvTemplateMatch)][0].Toolbase as SvTemplateMatch;

            if (mRegion.Count_X * mRegion.Count_Y < mRecipeData.DicProcess[mProcess].RobotData.LoadPosition.Length)
            {
                MessageBox.Show("Selected Load Job's Region Count must be more than LoadPosition count. Check this process flow Type");
                return false;
            }
            return true;
        }

        SvRegion mRegion;
        //SvTemplateMatch mTemplate;
        //SvWarppingPoint mWarpPoint;
        public Button btn_RegionSave;
        public Display.SvDisplayView svDisplayView1;
        private System.ComponentModel.IContainer components;
        public Button btn_Run;
        public List<SvPoint> ResultPoints = new List<SvPoint>();

        public void btn_Run_Click(object sender, EventArgs e)
        {
            mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;
            ResultPoints.Clear();
            svDisplayView1.ClearImage();

            // WarppingPoint tool을 임시로 추가한다. 수정이유: 기존 사용 잡을 이용해도 측정할 수 있도록...
            SvWarppingPoint warppoint = new SvWarppingPoint();
            SvCalibrationData caldata = new SvCalibrationData();

            string calfile = mRecipeData.DicProcess[mProcess].RobotData.CalibrationNames;
            calfile = Path.Combine(Main.CalibPath, calfile);

            warppoint.CalibrationData = (new SvSerializer()).LoadCalibration(calfile);

            for (int i = 0; i < mRecipeData.DicProcess[mProcess].RobotData.LoadPosition.Length; i++)
            {
                mJob.Run();

                if (mJob.LastRunSuccess == false)
                {
                    MessageBox.Show("Job Run Fail"); return;
                }

                //double thetaRad2 = NormalizeTheta(warpPoint.OutputPoint.ThetaRad);
                //double theta2 = thetaRad2 * 180 / Math.PI;

                SvMakePoint makepoint = mAlignResult.JobInfo[1][typeof(SvMakePoint)][0].Toolbase as SvMakePoint;
                warppoint.InputImage = makepoint.InputImage;
                warppoint.InputPoint = makepoint.OutPoint;

                double normalizedTrad = GetThetaRadFromTwoLine();
                //double theta1 = normalizedTrad * 180 / Math.PI;
                
                if (normalizedTrad != double.MaxValue)
                {
                    // 각도를 makepoint output 방향으로 맞춰준다.
                    double thetarad = normalizedTrad + Math.PI * 3 / 2;
                    while (Math.Abs(thetarad - warppoint.InputPoint.ThetaRad) > Math.PI / 4)
                    {
                        thetarad -= Math.PI / 2;
                    }
                    warppoint.InputPoint.ThetaRad = thetarad;
                }
                warppoint.InitOutProperty();
                warppoint.Run();
                
                ResultPoints.Add(new SvPoint(warppoint.OutputPoint.X, warppoint.OutputPoint.Y, warppoint.OutputPoint.ThetaRad * 180 / Math.PI));

                svDisplayView1.Image = warppoint.InputImage;

                warppoint.DrawInOutPoint(svDisplayView1);

                mRegion.IncreaseIndex();
            }
        }

        private double GetThetaRadFromTwoLine()
        {
            if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvFindLine)))
                return double.MaxValue;

            if (mAlignResult.JobInfo[1][typeof(SvFindLine)].Count < 3)
                return double.MaxValue;

            List<double> angleRad = new List<double>();
            for (int i = 0; i < mAlignResult.JobInfo[1][typeof(SvFindLine)].Count; i++)
            {
                angleRad.Add((mAlignResult.JobInfo[1][typeof(SvFindLine)][i].Toolbase as SvFindLine).Line.ThetaRad);
            }

            // 각도 Normalize in +-45degree
            for (int j = 0; j < angleRad.Count; j++)
            {
                double thetarad = angleRad[j] + Math.PI * 3 / 2;
                while (thetarad > Math.PI / 4)
                {
                    thetarad -= Math.PI / 2;
                }
                angleRad[j] = thetarad;
            }

            // 각도 비교해서 불필요한 각도 제외
            List<double> finalangleRad = new List<double>();
            bool flag = false;
            for (int j = 0; j < angleRad.Count; j++)
            {
                for (int k = j + 1; k < angleRad.Count; k++)
                {
                    if (Math.Abs(angleRad[j] - angleRad[k]) < Math.PI / 180)/*1도*/
                    {
                        finalangleRad.Add(angleRad[j]);
                        finalangleRad.Add(angleRad[k]);
                        flag = true;
                    }
                    if (flag) break;
                }
                if (flag) break;
            }

            if (finalangleRad.Count == 0) return double.MaxValue;

            // 각도 Normalize
            double finalangle = 0;
            for (int j = 0; j < finalangleRad.Count; j++)
            {
                double thetarad = finalangleRad[j] + Math.PI * 3 / 2;
                while (thetarad > Math.PI / 4)
                {
                    thetarad -= Math.PI / 2;
                }
                finalangleRad[j] = thetarad;
                finalangle += thetarad;
            }

            return finalangle / finalangleRad.Count;
        }

        public void btn_Save_Click(object sender, EventArgs e)
        {
            //if (mJob == null || mJob.ToolList.Count == 0) return;

            //bool issave = mSerializer.SaveJob(mJob, mJobPath);
            try
            {
                string recipeName = mRecipeData.RecipeName;
                for (int i = 0; i < ResultPoints.Count; i++)
                {

                    SvLogger.Log.Recipe(recipeName + " Loading Pos_Panel " + i.ToString() + " X : " + mRecipeData.DicProcess[mProcess].RobotData.LoadPosition[i].X.ToString() + " → " + ResultPoints[i].X.ToString());
                    SvLogger.Log.Recipe(recipeName + " Loading Pos_Panel " + i.ToString() + " Y : " + mRecipeData.DicProcess[mProcess].RobotData.LoadPosition[i].Y.ToString() + " → " + ResultPoints[i].Y.ToString());
                    SvLogger.Log.Recipe(recipeName + " Loading Pos_Panel " + i.ToString() + " T : " + mRecipeData.DicProcess[mProcess].RobotData.LoadPosition[i].ThetaRad.ToString() + " → " + ResultPoints[i].ThetaRad.ToString());
                    mRecipeData.DicProcess[mProcess].RobotData.LoadPosition[i] = ResultPoints[i];
                }
                
                MessageBox.Show("Job Save Success!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Job Save Fail!\r\n" + ex.ToString() , "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }



        /// <summary>
        /// Designer에서 생성한 코드
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_RegionSave = new System.Windows.Forms.Button();
            this.svDisplayView1 = new SvMip.Display.SvDisplayView();
            this.btn_Run = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_RegionSave
            // 
            this.btn_RegionSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_RegionSave.Location = new System.Drawing.Point(695, 416);
            this.btn_RegionSave.Name = "btn_RegionSave";
            this.btn_RegionSave.Size = new System.Drawing.Size(97, 43);
            this.btn_RegionSave.TabIndex = 8;
            this.btn_RegionSave.Text = "Save";
            this.btn_RegionSave.UseVisualStyleBackColor = true;
            this.btn_RegionSave.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // svDisplayView1
            // 
            this.svDisplayView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.svDisplayView1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svDisplayView1.Location = new System.Drawing.Point(12, 12);
            this.svDisplayView1.Name = "svDisplayView1";
            this.svDisplayView1.Size = new System.Drawing.Size(677, 447);
            this.svDisplayView1.TabIndex = 7;
            this.svDisplayView1.ToastVisible = true;
            this.svDisplayView1.ZoomVisible = false;
            this.svDisplayView1.Auto_Fit = true;
            // 
            // btn_Run
            // 
            this.btn_Run.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Run.Location = new System.Drawing.Point(695, 367);
            this.btn_Run.Name = "btn_Run";
            this.btn_Run.Size = new System.Drawing.Size(97, 43);
            this.btn_Run.TabIndex = 8;
            this.btn_Run.Text = "Run";
            this.btn_Run.UseVisualStyleBackColor = true;
            this.btn_Run.Click += new System.EventHandler(this.btn_Run_Click);
            // 
            // DataEdit_LoadPosition
            // 
            this.ClientSize = new System.Drawing.Size(804, 471);
            this.Controls.Add(this.btn_Run);
            this.Controls.Add(this.btn_RegionSave);
            this.Controls.Add(this.svDisplayView1);
            this.Name = "DataEdit_LoadPosition";
            this.ResumeLayout(false);

        }
    }
}
