﻿//using OpenCvSharp.CPlusPlus;
//using SvMip.Common;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace SvMip.SDV_StandardAutoFeeder_Merge
//{
//    public partial class DataEdit_TrayInt : DataEdit_Base
//    {
//        public DataEdit_TrayInt(ProcessData _procdata, RecipeData _recipeData, Main.Process _process, string _jobName)
//            : base(_recipeData, _process, _jobName)
//        {
//            InitializeComponent();
//            IsPossible = InitJob();

//            foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
//                listToolblock.Add(toolinfo.Toolbase as SvToolBlock);
//        }

//        SvRegion mRegion;
//        SvJudgement mJudge;
//        int mToolblockIndex = 1;

//        public Button btn_Run;
//        private DataGridView dgvThreshold;
//        private Button btn_toolblock;
//        private Button btn_SaveImage;
//        private Button btn_LiveView;
//        private DataGridViewTextBoxColumn ColIndex;
//        private DataGridViewTextBoxColumn ColThreshold;

//        List<SvToolBlock> listToolblock = new List<SvToolBlock>();

//        //float scaleX;
//        public float ScaleX
//        {
//            get
//            {
//                if (mRegion.InputImage == null) return 0;
//                return (float)nud_TrayWidth.Value / mRegion.InputImage.Width;
//            }
//        }
//        //float scaleY;
//        public float ScaleY
//        {
//            get
//            {
//                if (mRegion.InputImage == null) return 0;
//                return (float)nud_TrayHeight.Value / mRegion.InputImage.Height;
//            }
//        }

//        private void nud_Value_add_ValueChanged(object sender, EventArgs e)
//        {
//            svDisplayView1.ClearImage();
//            svDisplayView1.GraphicsCollection.Clear();

//            float X = (float)(nud_StartX_add.Value) / ScaleX;
//            float Y = (float)(nud_StartY_add.Value) / ScaleY;
//            Point2f startP = new Point2f(X, Y);
//            mRegion.RegionRect.Location += startP;

//            mRegion.Dist_X += nud_DistX_add.Value / (decimal)ScaleX;
//            mRegion.Dist_Y += nud_DistY_add.Value / (decimal)ScaleY;

//            svDisplayView1.Image = mRegion.InputImage;
//            mRegion.DisplayRegions(svDisplayView1);

//            mRegion.RegionRect.Location -= startP;
//            mRegion.Dist_X -= nud_DistX_add.Value / (decimal)ScaleX;
//            mRegion.Dist_Y -= nud_DistY_add.Value / (decimal)ScaleY;
//        }

//        public bool InitJob()
//        {
//            try
//            {
//                // Toolblock check
//                if (mAlignResult.JobInfo.Count < 2)
//                {
//                    MessageBox.Show("There is no Toolblock Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
//                    return false;
//                }

//                if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvRegion)))
//                {
//                    MessageBox.Show("There is no SvRegion Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
//                    return false;
//                }

//                //if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvJudgement)))
//                //{
//                //    MessageBox.Show("There is no SvJudgement Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
//                //    return false;
//                //}

//                nud_TrayWidth.Text = mRecipeData.DicProcess[mProcess].RobotData.TrayWidth.ToString("F3");
//                nud_TrayHeight.Text = mRecipeData.DicProcess[mProcess].RobotData.TrayHeight.ToString("F3");

//                if (nud_TrayWidth.Value == 0)
//                    nud_TrayWidth.Value = 550;

//                if (nud_TrayHeight.Value == 0)
//                    nud_TrayHeight.Value = 450;

//                //mWarppoint = mAlignResult.JobInfo[typeof(SvWarpping)][0].Toolbase as SvWarpping;
//                //mToolblock = mAlignResult.JobInfo[typeof(SvToolBlock)][mRegionIndex].Toolbase as SvToolBlock;
//                mRegion = mAlignResult.JobInfo[mToolblockIndex][typeof(SvRegion)][0].Toolbase as SvRegion;

//                if (!GetTargetPoint()) return false;

//                if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
//                {
//                    mJudge = mAlignResult.JobInfo[mToolblockIndex][typeof(SvJudgement)][0].Toolbase as SvJudgement;


//                    int regionCnt = mRegion.Count_X * mRegion.Count_Y;
//                    dgvThreshold.Rows.Clear();
//                    dgvThreshold.Rows.Add(regionCnt);

//                    if (mJudge.Thresholds.Count != (mRegion.Count_X * mRegion.Count_Y))
//                    {
//                        for (int i = 0; i < regionCnt; i++)
//                        {
//                            dgvThreshold.Rows[i].SetValues(i + 1, mJudge.Creteria);
//                        }
//                    }
//                    else
//                    {
//                        for (int i = 0; i < regionCnt; i++)
//                        {
//                            dgvThreshold.Rows[i].SetValues(i + 1, mJudge.Thresholds[i]);
//                        }
//                    }
//                }


//                return true;
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show(ex.ToString());
//                return false;
//            }
//        }

//        private SvJudgement GetThreshold(SvToolBlock block)
//        {
//            SvJudgement judge = null;
//            foreach (var tool in block.ToolJob.ToolList)
//            {
//                if (tool is SvJudgement)
//                {
//                    judge = (SvJudgement)tool;
//                    break;
//                }
//            }
//            return judge;
//        }

//        private bool GetTargetPoint()
//        {
//            if (mRegion.outParams.ContainsKey("RectLeft"))
//                mStartP = new Point2f(mRegion.RegionRect.Left.X, mRegion.RegionRect.Left.Y);
//            else if (mRegion.outParams.ContainsKey("RectRight"))
//                mStartP = new Point2f(mRegion.RegionRect.Right.X, mRegion.RegionRect.Right.Y);
//            else if (mRegion.outParams.ContainsKey("RectTop"))
//                mStartP = new Point2f(mRegion.RegionRect.Top.X, mRegion.RegionRect.Top.Y);
//            else if (mRegion.outParams.ContainsKey("RectBottom"))
//                mStartP = new Point2f(mRegion.RegionRect.Bottom.X, mRegion.RegionRect.Bottom.Y);
//            else if (mRegion.outParams.ContainsKey("RectCenter"))
//                mStartP = new Point2f(mRegion.RegionRect.Center.X, mRegion.RegionRect.Center.Y);
//            else
//                mStartP = new Point2f(mRegion.RegionRect.Location.X, mRegion.RegionRect.Location.Y);

//            return true;
//        }




//        public void btn_Run_Click(object sender, EventArgs e)
//        {
//            mJob.Run();

//            GetTargetPoint();

//            nud_StartX.Text = (mStartP.X * ScaleX).ToString("F3");
//            nud_StartY.Text = (mStartP.Y * ScaleY).ToString("F3");

//            nud_DistX.Text = ((double)mRegion.Dist_X * ScaleX).ToString("F3");
//            nud_DistY.Text = ((double)mRegion.Dist_Y * ScaleY).ToString("F3");

//            nud_StartX_add.Value = 0;
//            nud_StartY_add.Value = 0;

//            nud_DistX_add.Value = 0;
//            nud_DistY_add.Value = 0;

//            svDisplayView1.ClearImage();
//            svDisplayView1.GraphicsCollection.Clear();

//            svDisplayView1.Image = mRegion.InputImage;
//            mRegion.DisplayRegions(svDisplayView1);

//            //btn_toolblock_Click(null, null);
//        }

//        Point2f mStartP;

//        private void btn_LiveView_Click(object sender, EventArgs e)
//        {

//        }


//        private void btn_SaveImage_Click(object sender, EventArgs e)
//        {
//            SvImage InputImage = null;
//            foreach (SvToolBase toolbase in mJob.ToolList)
//            {

//                if (toolbase is SvAcquisition)
//                {
//                    toolbase.InitOutProperty();
//                    toolbase.Run();
//                    InputImage = toolbase.imageList[0].Image;
//                    break;
//                }

//            }

//            if (InputImage == null)
//            {
//                return;
//            }

//            SaveFileDialog fd = new SaveFileDialog();
//            fd.Filter = "Image files (*.png)|*.png|All files (*.*)|*.*";
//            fd.FilterIndex = 1;
//            fd.DefaultExt = "*.png";
//            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

//            InputImage.Mat.SaveImage(fd.FileName);

//            svDisplayView1.ClearImage();
//            svDisplayView1.GraphicsCollection.Clear();

//            svDisplayView1.Image = InputImage;


//        }


//        public void btn_Save_Click(object sender, EventArgs e)
//        {
//            if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
//            {

//                mJudge.Thresholds.Clear();
//                for (int i = 0; i < dgvThreshold.RowCount - 1; i++)
//                {
//                    // 값을 object 변수에 담기
//                    object obj = dgvThreshold.Rows[i].Cells[1].Value;
//                    string str = obj.ToString();
//                    // object 변수를 형변환하게 되면 에러 발생
//                    double ddd = 0.0;
//                    if (double.TryParse(str, out ddd))
//                    {
//                        // tool 쪽으로 데이터 저장
//                        mJudge.Thresholds.Add(ddd);
//                    }
//                }
//            }


//            if (ScaleX == 0 || ScaleY == 0)
//            {
//                MessageBox.Show("Saved thresholds only!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
//                return;
//            }

//            float X = (float)(nud_StartX_add.Value) / ScaleX;
//            float Y = (float)(nud_StartY_add.Value) / ScaleY;

//            string recipeName = mRecipeData.RecipeName; //이거보단 class 이름이 더 나으려나?

//            if (nud_StartX_add.Value != 0)
//            {
//                float start_X = (float)(nud_StartX.Value + nud_StartX_add.Value);
//                SvLogger.Log.Recipe(recipeName + " X Start Offset Change : " + nud_StartX_add.Value.ToString("F1"));
//                SvLogger.Log.Recipe(recipeName + " Tray X Start Point Change : " + nud_StartX.Value.ToString("F1") + " → " + start_X.ToString("F1"));
//            }

//            if (nud_StartY_add.Value != 0)
//            {
//                float start_Y = (float)(nud_StartY.Value + nud_StartY_add.Value);
//                SvLogger.Log.Recipe(recipeName + " Y Start Offset Change : " + nud_StartY_add.Value.ToString("F1"));
//                SvLogger.Log.Recipe(recipeName + " Tray Y Start Point Change : " + nud_StartY.Value.ToString("F1") + " → " + start_Y.ToString("F1"));
//            }
//            Point2f startP = new Point2f(X, Y);

//            mRegion.RegionRect.Location += startP;

//            mRegion.Dist_X += nud_DistX_add.Value / (decimal)ScaleX;
//            if (nud_DistX_add.Value != 0)
//            {
//                float offset_X = (float)(nud_DistX.Value + nud_DistX_add.Value);
//                SvLogger.Log.Recipe(recipeName + " X Distance Offset Change : " + nud_DistX_add.Value.ToString("F1"));
//                SvLogger.Log.Recipe(recipeName + " Tray X Distance Change : " + nud_DistX.Value.ToString("F1") + " → " + offset_X.ToString("F1"));
//            }

//            mRegion.Dist_Y += nud_DistY_add.Value / (decimal)ScaleY;
//            if (nud_DistY_add.Value != 0)
//            {
//                float offset_Y = (float)(nud_DistY.Value + nud_DistY_add.Value);
//                SvLogger.Log.Recipe(recipeName + " Y Distance Offset Change : " + nud_DistY_add.Value.ToString("F1"));
//                SvLogger.Log.Recipe(recipeName + " Tray Y Distance Change : " + nud_DistY.Value.ToString("F1") + " → " + offset_Y.ToString("F1"));
//            }

//            mRecipeData.DicProcess[mProcess].RobotData.TrayWidth = (double)nud_TrayWidth.Value;
//            mRecipeData.DicProcess[mProcess].RobotData.TrayHeight = (double)nud_TrayHeight.Value;


//            mSerializer.SaveJob(mJob, mJobPath);

//            //// Tray Offset Pocket Reference Position 등록
//            //InitJob();

//            MessageBox.Show("Data saving Complete!!!");

//            Auto.IsRecipeDataChanged = true;
//        }

//        private void btn_toolblock_Click(object sender, EventArgs e)
//        {
//            // ToolblockIndex 순환
//            mToolblockIndex = (mToolblockIndex + 1) % mAlignResult.JobInfo.Count;
//            if (mToolblockIndex == 0) mToolblockIndex++;


//            if(!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion))  && !mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
//            {
//                MessageBox.Show("Toolblock does not contain Region or Judgement!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
//                return;
//            }
//            mRegion = mAlignResult.JobInfo[mToolblockIndex][typeof(SvRegion)][0].Toolbase as SvRegion;
//            SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;

//            if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
//            {
//                mJudge = mAlignResult.JobInfo[mToolblockIndex][typeof(SvJudgement)][0].Toolbase as SvJudgement;
                

//                int regionCnt = mRegion.Count_X * mRegion.Count_Y;
//                dgvThreshold.Rows.Clear();
//                dgvThreshold.Rows.Add(regionCnt);

//                if (mJudge.Thresholds.Count != (mRegion.Count_X * mRegion.Count_Y))
//                {
//                    for (int i = 0; i < regionCnt; i++)
//                    {
//                        dgvThreshold.Rows[i].SetValues(i + 1, mJudge.Creteria);
//                    }
//                }
//                else
//                {
//                    for (int i = 0; i < regionCnt; i++)
//                    {
//                        dgvThreshold.Rows[i].SetValues(i + 1, mJudge.Thresholds[i]);
//                    }
//                }
//            }
//            btn_toolblock.Text = string.Format("Toolblock #{0}", mToolblockIndex);

//            GetTargetPoint();

//            nud_StartX.Text = (mStartP.X * ScaleX).ToString("F3");
//            nud_StartY.Text = (mStartP.Y * ScaleY).ToString("F3");

//            nud_DistX.Text = ((double)mRegion.Dist_X * ScaleX).ToString("F3");
//            nud_DistY.Text = ((double)mRegion.Dist_Y * ScaleY).ToString("F3");

//            nud_StartX_add.Value = 0;
//            nud_StartY_add.Value = 0;

//            nud_DistX_add.Value = 0;
//            nud_DistY_add.Value = 0;

//            svDisplayView1.ClearImage();
//            svDisplayView1.GraphicsCollection.Clear();

//            svDisplayView1.Image = mRegion.InputImage;
//            mRegion.DisplayRegions(svDisplayView1);

//            System.Drawing.Font f = new System.Drawing.Font("굴림체", 8, System.Drawing.FontStyle.Bold);
//            System.Drawing.SolidBrush SB = new System.Drawing.SolidBrush(System.Drawing.Color.Violet);

//            mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

//            if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
//            {
//                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
//                {
//                    toolblock.ToolJob.Run();
//                    string str = string.Format("{0}. Bolb Area: {1}", i + 1, mJudge.Value);
//                    svDisplayView1.DrawString(str, f, SB, new Point2d(mRegion.OutputImage.RegionRect.Location.X, mRegion.OutputImage.RegionRect.Location.Y));
//                    mRegion.IncreaseIndex();
//                }
//            }
//        }


//        /// <summary>
//        /// Designer에서 생성한 부분
//        /// </summary>

//        public System.Windows.Forms.NumericUpDown nud_DistX_add;
//        public System.Windows.Forms.NumericUpDown nud_TrayWidth;
//        public System.Windows.Forms.NumericUpDown nud_TrayHeight;
//        public System.Windows.Forms.NumericUpDown nud_DistY_add;
//        public System.Windows.Forms.NumericUpDown nud_StartX_add;
//        public System.Windows.Forms.NumericUpDown nud_StartY_add;
//        public System.Windows.Forms.NumericUpDown nud_DistX;
//        public System.Windows.Forms.NumericUpDown nud_DistY;
//        public System.Windows.Forms.NumericUpDown nud_StartX;
//        public System.Windows.Forms.NumericUpDown nud_StartY;
//        private System.Windows.Forms.Label label10;
//        private System.Windows.Forms.Label label9;
//        private System.Windows.Forms.Label label6;
//        private System.Windows.Forms.Label label8;
//        private System.Windows.Forms.Label label7;
//        private System.Windows.Forms.Label label5;
//        public System.Windows.Forms.Button btn_RegionSave;
//        private System.Windows.Forms.Label label4;
//        private System.Windows.Forms.Label label3;
//        private System.Windows.Forms.Label label2;
//        private System.Windows.Forms.Label label1;
//        public Display.SvDisplayView svDisplayView1;
//        private System.ComponentModel.IContainer components;

//        private void InitializeComponent()
//        {
//            this.components = new System.ComponentModel.Container();
//            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
//            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
//            this.nud_DistX_add = new System.Windows.Forms.NumericUpDown();
//            this.nud_TrayWidth = new System.Windows.Forms.NumericUpDown();
//            this.nud_TrayHeight = new System.Windows.Forms.NumericUpDown();
//            this.nud_DistY_add = new System.Windows.Forms.NumericUpDown();
//            this.nud_StartX_add = new System.Windows.Forms.NumericUpDown();
//            this.nud_StartY_add = new System.Windows.Forms.NumericUpDown();
//            this.nud_DistX = new System.Windows.Forms.NumericUpDown();
//            this.nud_DistY = new System.Windows.Forms.NumericUpDown();
//            this.nud_StartX = new System.Windows.Forms.NumericUpDown();
//            this.nud_StartY = new System.Windows.Forms.NumericUpDown();
//            this.label10 = new System.Windows.Forms.Label();
//            this.label9 = new System.Windows.Forms.Label();
//            this.label6 = new System.Windows.Forms.Label();
//            this.label8 = new System.Windows.Forms.Label();
//            this.label7 = new System.Windows.Forms.Label();
//            this.label5 = new System.Windows.Forms.Label();
//            this.btn_RegionSave = new System.Windows.Forms.Button();
//            this.label4 = new System.Windows.Forms.Label();
//            this.label3 = new System.Windows.Forms.Label();
//            this.label2 = new System.Windows.Forms.Label();
//            this.label1 = new System.Windows.Forms.Label();
//            this.svDisplayView1 = new SvMip.Display.SvDisplayView();
//            this.btn_Run = new System.Windows.Forms.Button();
//            this.dgvThreshold = new System.Windows.Forms.DataGridView();
//            this.ColIndex = new System.Windows.Forms.DataGridViewTextBoxColumn();
//            this.ColThreshold = new System.Windows.Forms.DataGridViewTextBoxColumn();
//            this.btn_toolblock = new System.Windows.Forms.Button();
//            this.btn_SaveImage = new System.Windows.Forms.Button();
//            this.btn_LiveView = new System.Windows.Forms.Button();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX_add)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayWidth)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayHeight)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY_add)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX_add)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY_add)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY)).BeginInit();
//            ((System.ComponentModel.ISupportInitialize)(this.dgvThreshold)).BeginInit();
//            this.SuspendLayout();
//            // 
//            // nud_DistX_add
//            // 
//            this.nud_DistX_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.nud_DistX_add.DecimalPlaces = 1;
//            this.nud_DistX_add.Increment = new decimal(new int[] {
//            1,
//            0,
//            0,
//            65536});
//            this.nud_DistX_add.Location = new System.Drawing.Point(144, 457);
//            this.nud_DistX_add.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_DistX_add.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_DistX_add.Name = "nud_DistX_add";
//            this.nud_DistX_add.Size = new System.Drawing.Size(79, 20);
//            this.nud_DistX_add.TabIndex = 27;
//            this.nud_DistX_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            this.nud_DistX_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
//            // 
//            // nud_TrayWidth
//            // 
//            this.nud_TrayWidth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.nud_TrayWidth.DecimalPlaces = 1;
//            this.nud_TrayWidth.Increment = new decimal(new int[] {
//            1,
//            0,
//            0,
//            65536});
//            this.nud_TrayWidth.Location = new System.Drawing.Point(306, 438);
//            this.nud_TrayWidth.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_TrayWidth.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_TrayWidth.Name = "nud_TrayWidth";
//            this.nud_TrayWidth.Size = new System.Drawing.Size(97, 20);
//            this.nud_TrayWidth.TabIndex = 25;
//            this.nud_TrayWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            // 
//            // nud_TrayHeight
//            // 
//            this.nud_TrayHeight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.nud_TrayHeight.DecimalPlaces = 1;
//            this.nud_TrayHeight.Increment = new decimal(new int[] {
//            1,
//            0,
//            0,
//            65536});
//            this.nud_TrayHeight.Location = new System.Drawing.Point(739, 175);
//            this.nud_TrayHeight.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_TrayHeight.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_TrayHeight.Name = "nud_TrayHeight";
//            this.nud_TrayHeight.Size = new System.Drawing.Size(97, 20);
//            this.nud_TrayHeight.TabIndex = 24;
//            this.nud_TrayHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            // 
//            // nud_DistY_add
//            // 
//            this.nud_DistY_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.nud_DistY_add.DecimalPlaces = 1;
//            this.nud_DistY_add.Increment = new decimal(new int[] {
//            1,
//            0,
//            0,
//            65536});
//            this.nud_DistY_add.Location = new System.Drawing.Point(756, 102);
//            this.nud_DistY_add.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_DistY_add.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_DistY_add.Name = "nud_DistY_add";
//            this.nud_DistY_add.Size = new System.Drawing.Size(79, 20);
//            this.nud_DistY_add.TabIndex = 23;
//            this.nud_DistY_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            this.nud_DistY_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
//            // 
//            // nud_StartX_add
//            // 
//            this.nud_StartX_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.nud_StartX_add.DecimalPlaces = 1;
//            this.nud_StartX_add.Increment = new decimal(new int[] {
//            1,
//            0,
//            0,
//            65536});
//            this.nud_StartX_add.Location = new System.Drawing.Point(29, 457);
//            this.nud_StartX_add.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_StartX_add.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_StartX_add.Name = "nud_StartX_add";
//            this.nud_StartX_add.Size = new System.Drawing.Size(79, 20);
//            this.nud_StartX_add.TabIndex = 22;
//            this.nud_StartX_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            this.nud_StartX_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
//            // 
//            // nud_StartY_add
//            // 
//            this.nud_StartY_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.nud_StartY_add.DecimalPlaces = 1;
//            this.nud_StartY_add.Increment = new decimal(new int[] {
//            1,
//            0,
//            0,
//            65536});
//            this.nud_StartY_add.Location = new System.Drawing.Point(756, 45);
//            this.nud_StartY_add.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_StartY_add.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_StartY_add.Name = "nud_StartY_add";
//            this.nud_StartY_add.Size = new System.Drawing.Size(79, 20);
//            this.nud_StartY_add.TabIndex = 21;
//            this.nud_StartY_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            this.nud_StartY_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
//            // 
//            // nud_DistX
//            // 
//            this.nud_DistX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.nud_DistX.DecimalPlaces = 1;
//            this.nud_DistX.Enabled = false;
//            this.nud_DistX.Increment = new decimal(new int[] {
//            5,
//            0,
//            0,
//            65536});
//            this.nud_DistX.Location = new System.Drawing.Point(126, 438);
//            this.nud_DistX.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_DistX.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_DistX.Name = "nud_DistX";
//            this.nud_DistX.ReadOnly = true;
//            this.nud_DistX.Size = new System.Drawing.Size(97, 20);
//            this.nud_DistX.TabIndex = 20;
//            this.nud_DistX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            // 
//            // nud_DistY
//            // 
//            this.nud_DistY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.nud_DistY.DecimalPlaces = 1;
//            this.nud_DistY.Enabled = false;
//            this.nud_DistY.Increment = new decimal(new int[] {
//            5,
//            0,
//            0,
//            65536});
//            this.nud_DistY.Location = new System.Drawing.Point(739, 83);
//            this.nud_DistY.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_DistY.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_DistY.Name = "nud_DistY";
//            this.nud_DistY.ReadOnly = true;
//            this.nud_DistY.Size = new System.Drawing.Size(97, 20);
//            this.nud_DistY.TabIndex = 19;
//            this.nud_DistY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            // 
//            // nud_StartX
//            // 
//            this.nud_StartX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.nud_StartX.DecimalPlaces = 1;
//            this.nud_StartX.Enabled = false;
//            this.nud_StartX.Increment = new decimal(new int[] {
//            5,
//            0,
//            0,
//            65536});
//            this.nud_StartX.Location = new System.Drawing.Point(12, 438);
//            this.nud_StartX.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_StartX.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_StartX.Name = "nud_StartX";
//            this.nud_StartX.ReadOnly = true;
//            this.nud_StartX.Size = new System.Drawing.Size(97, 20);
//            this.nud_StartX.TabIndex = 18;
//            this.nud_StartX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            // 
//            // nud_StartY
//            // 
//            this.nud_StartY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.nud_StartY.DecimalPlaces = 1;
//            this.nud_StartY.Enabled = false;
//            this.nud_StartY.Increment = new decimal(new int[] {
//            5,
//            0,
//            0,
//            65536});
//            this.nud_StartY.Location = new System.Drawing.Point(739, 27);
//            this.nud_StartY.Maximum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            0});
//            this.nud_StartY.Minimum = new decimal(new int[] {
//            10000,
//            0,
//            0,
//            -2147483648});
//            this.nud_StartY.Name = "nud_StartY";
//            this.nud_StartY.ReadOnly = true;
//            this.nud_StartY.Size = new System.Drawing.Size(97, 20);
//            this.nud_StartY.TabIndex = 26;
//            this.nud_StartY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
//            // 
//            // label10
//            // 
//            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.label10.AutoSize = true;
//            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.label10.Location = new System.Drawing.Point(735, 159);
//            this.label10.Name = "label10";
//            this.label10.Size = new System.Drawing.Size(62, 15);
//            this.label10.TabIndex = 17;
//            this.label10.Text = "Tray Heiht";
//            // 
//            // label9
//            // 
//            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.label9.AutoSize = true;
//            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.label9.Location = new System.Drawing.Point(302, 421);
//            this.label9.Name = "label9";
//            this.label9.Size = new System.Drawing.Size(64, 15);
//            this.label9.TabIndex = 16;
//            this.label9.Text = "Tray Width";
//            // 
//            // label6
//            // 
//            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.label6.AutoSize = true;
//            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.label6.Location = new System.Drawing.Point(123, 421);
//            this.label6.Name = "label6";
//            this.label6.Size = new System.Drawing.Size(42, 15);
//            this.label6.TabIndex = 15;
//            this.label6.Text = "Dist. X";
//            // 
//            // label8
//            // 
//            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.label8.AutoSize = true;
//            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.label8.Location = new System.Drawing.Point(735, 66);
//            this.label8.Name = "label8";
//            this.label8.Size = new System.Drawing.Size(41, 15);
//            this.label8.TabIndex = 14;
//            this.label8.Text = "Dist. Y";
//            // 
//            // label7
//            // 
//            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.label7.AutoSize = true;
//            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.label7.Location = new System.Drawing.Point(735, 10);
//            this.label7.Name = "label7";
//            this.label7.Size = new System.Drawing.Size(42, 15);
//            this.label7.TabIndex = 13;
//            this.label7.Text = "Start Y";
//            // 
//            // label5
//            // 
//            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.label5.AutoSize = true;
//            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
//            this.label5.Location = new System.Drawing.Point(12, 421);
//            this.label5.Name = "label5";
//            this.label5.Size = new System.Drawing.Size(43, 15);
//            this.label5.TabIndex = 12;
//            this.label5.Text = "Start X";
//            // 
//            // btn_RegionSave
//            // 
//            this.btn_RegionSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
//            this.btn_RegionSave.Location = new System.Drawing.Point(739, 428);
//            this.btn_RegionSave.Name = "btn_RegionSave";
//            this.btn_RegionSave.Size = new System.Drawing.Size(96, 50);
//            this.btn_RegionSave.TabIndex = 11;
//            this.btn_RegionSave.Text = "Save";
//            this.btn_RegionSave.UseVisualStyleBackColor = true;
//            this.btn_RegionSave.Click += new System.EventHandler(this.btn_Save_Click);
//            // 
//            // label4
//            // 
//            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.label4.AutoSize = true;
//            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
//            this.label4.Location = new System.Drawing.Point(127, 459);
//            this.label4.Name = "label4";
//            this.label4.Size = new System.Drawing.Size(16, 17);
//            this.label4.TabIndex = 9;
//            this.label4.Text = "+";
//            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            // 
//            // label3
//            // 
//            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
//            this.label3.AutoSize = true;
//            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
//            this.label3.Location = new System.Drawing.Point(13, 459);
//            this.label3.Name = "label3";
//            this.label3.Size = new System.Drawing.Size(16, 17);
//            this.label3.TabIndex = 8;
//            this.label3.Text = "+";
//            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            // 
//            // label2
//            // 
//            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.label2.AutoSize = true;
//            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
//            this.label2.Location = new System.Drawing.Point(737, 104);
//            this.label2.Name = "label2";
//            this.label2.Size = new System.Drawing.Size(16, 17);
//            this.label2.TabIndex = 7;
//            this.label2.Text = "+";
//            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            // 
//            // label1
//            // 
//            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
//            this.label1.AutoSize = true;
//            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
//            this.label1.Location = new System.Drawing.Point(737, 47);
//            this.label1.Name = "label1";
//            this.label1.Size = new System.Drawing.Size(16, 17);
//            this.label1.TabIndex = 10;
//            this.label1.Text = "+";
//            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
//            // 
//            // svDisplayView1
//            // 
//            this.svDisplayView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
//            | System.Windows.Forms.AnchorStyles.Left) 
//            | System.Windows.Forms.AnchorStyles.Right)));
//            this.svDisplayView1.AutoScroll = true;
//            this.svDisplayView1.Cursor = System.Windows.Forms.Cursors.Cross;
//            this.svDisplayView1.Location = new System.Drawing.Point(12, 12);
//            this.svDisplayView1.Name = "svDisplayView1";
//            this.svDisplayView1.Size = new System.Drawing.Size(717, 406);
//            this.svDisplayView1.TabIndex = 6;
//            this.svDisplayView1.ToastVisible = true;
//            this.svDisplayView1.ZoomVisible = false;
//            // 
//            // btn_Run
//            // 
//            this.btn_Run.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
//            this.btn_Run.Location = new System.Drawing.Point(633, 428);
//            this.btn_Run.Name = "btn_Run";
//            this.btn_Run.Size = new System.Drawing.Size(96, 50);
//            this.btn_Run.TabIndex = 11;
//            this.btn_Run.Text = "Run";
//            this.btn_Run.UseVisualStyleBackColor = true;
//            this.btn_Run.Click += new System.EventHandler(this.btn_Run_Click);
//            // 
//            // dgvThreshold
//            // 
//            this.dgvThreshold.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
//            | System.Windows.Forms.AnchorStyles.Right)));
//            this.dgvThreshold.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
//            this.dgvThreshold.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
//            this.ColIndex,
//            this.ColThreshold});
//            this.dgvThreshold.Location = new System.Drawing.Point(740, 209);
//            this.dgvThreshold.Name = "dgvThreshold";
//            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
//            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
//            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
//            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
//            dataGridViewCellStyle1.NullValue = null;
//            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
//            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
//            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
//            this.dgvThreshold.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
//            this.dgvThreshold.RowHeadersVisible = false;
//            this.dgvThreshold.RowHeadersWidth = 25;
//            dataGridViewCellStyle2.NullValue = null;
//            this.dgvThreshold.RowsDefaultCellStyle = dataGridViewCellStyle2;
//            this.dgvThreshold.Size = new System.Drawing.Size(96, 209);
//            this.dgvThreshold.TabIndex = 28;
//            // 
//            // ColIndex
//            // 
//            this.ColIndex.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
//            this.ColIndex.FillWeight = 50F;
//            this.ColIndex.HeaderText = "No";
//            this.ColIndex.Name = "ColIndex";
//            this.ColIndex.Resizable = System.Windows.Forms.DataGridViewTriState.True;
//            this.ColIndex.Width = 46;
//            // 
//            // ColThreshold
//            // 
//            this.ColThreshold.FillWeight = 300F;
//            this.ColThreshold.HeaderText = "Threshold";
//            this.ColThreshold.Name = "ColThreshold";
//            this.ColThreshold.Width = 79;
//            // 
//            // btn_toolblock
//            // 
//            this.btn_toolblock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
//            this.btn_toolblock.Location = new System.Drawing.Point(524, 428);
//            this.btn_toolblock.Name = "btn_toolblock";
//            this.btn_toolblock.Size = new System.Drawing.Size(98, 49);
//            this.btn_toolblock.TabIndex = 29;
//            this.btn_toolblock.Text = "Toolblock #1";
//            this.btn_toolblock.UseVisualStyleBackColor = true;
//            this.btn_toolblock.Click += new System.EventHandler(this.btn_toolblock_Click);
//            // 
//            // btn_SaveImage
//            // 
//            this.btn_SaveImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
//            this.btn_SaveImage.Location = new System.Drawing.Point(421, 454);
//            this.btn_SaveImage.Name = "btn_SaveImage";
//            this.btn_SaveImage.Size = new System.Drawing.Size(93, 22);
//            this.btn_SaveImage.TabIndex = 30;
//            this.btn_SaveImage.Text = "Save Image";
//            this.btn_SaveImage.UseVisualStyleBackColor = true;
//            this.btn_SaveImage.Click += new System.EventHandler(this.btn_SaveImage_Click);
//            // 
//            // btn_LiveView
//            // 
//            this.btn_LiveView.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
//            this.btn_LiveView.Enabled = false;
//            this.btn_LiveView.Location = new System.Drawing.Point(421, 429);
//            this.btn_LiveView.Name = "btn_LiveView";
//            this.btn_LiveView.Size = new System.Drawing.Size(93, 22);
//            this.btn_LiveView.TabIndex = 31;
//            this.btn_LiveView.Text = "Live";
//            this.btn_LiveView.UseVisualStyleBackColor = true;
//            this.btn_LiveView.Click += new System.EventHandler(this.btn_LiveView_Click);
//            // 
//            // DataEdit_Tray_InspectionThreshold
//            // 
//            this.ClientSize = new System.Drawing.Size(848, 488);
//            this.Controls.Add(this.btn_LiveView);
//            this.Controls.Add(this.btn_SaveImage);
//            this.Controls.Add(this.btn_toolblock);
//            this.Controls.Add(this.dgvThreshold);
//            this.Controls.Add(this.nud_DistX_add);
//            this.Controls.Add(this.nud_TrayWidth);
//            this.Controls.Add(this.nud_TrayHeight);
//            this.Controls.Add(this.nud_DistY_add);
//            this.Controls.Add(this.nud_StartX_add);
//            this.Controls.Add(this.nud_StartY_add);
//            this.Controls.Add(this.nud_DistX);
//            this.Controls.Add(this.nud_DistY);
//            this.Controls.Add(this.nud_StartX);
//            this.Controls.Add(this.nud_StartY);
//            this.Controls.Add(this.label10);
//            this.Controls.Add(this.label9);
//            this.Controls.Add(this.label6);
//            this.Controls.Add(this.label8);
//            this.Controls.Add(this.label7);
//            this.Controls.Add(this.label5);
//            this.Controls.Add(this.btn_Run);
//            this.Controls.Add(this.btn_RegionSave);
//            this.Controls.Add(this.label4);
//            this.Controls.Add(this.label3);
//            this.Controls.Add(this.label2);
//            this.Controls.Add(this.label1);
//            this.Controls.Add(this.svDisplayView1);
//            this.Name = "DataEdit_Tray_InspectionThreshold";
//            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX_add)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayWidth)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayHeight)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY_add)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX_add)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY_add)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY)).EndInit();
//            ((System.ComponentModel.ISupportInitialize)(this.dgvThreshold)).EndInit();
//            this.ResumeLayout(false);
//            this.PerformLayout();

//        }






//    }
//}
