﻿using OpenCvSharp.CPlusPlus;
using SvMip.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public partial class DataEdit_TrayOffset : DataEdit_Base
    {
        public DataEdit_TrayOffset(ProcessData _procdata, RecipeData _recipeData, Main.Process _process, string _jobName)
            : base(_recipeData, _process, _jobName)
        {
            InitializeComponent();
            IsPossible = InitJob();

            foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                listToolblock.Add(toolinfo.Toolbase as SvToolBlock);
        }

        SvRegion mRegion;
        int mRegionIndex = 0;
        
        public Button btn_Run;
        private Button btn_Region;

        List<SvToolBlock> listToolblock = new List<SvToolBlock>();

        //float scaleX;
        public float ScaleX
        {
            get
            {
                if (mRegion.InputImage == null) return 0;
                return (float)nud_TrayWidth.Value / mRegion.InputImage.Width;
            }
        }
        //float scaleY;
        public float ScaleY
        {
            get
            {
                if (mRegion.InputImage == null) return 0;
                return (float)nud_TrayHeight.Value / mRegion.InputImage.Height;
            }
        }

        private void nud_Value_add_ValueChanged(object sender, EventArgs e)
        {
            svDisplayView1.GraphicsCollection.Clear();
            for (int i = 0; i < mRegion.Count_X; i++)
            {
                for (int j = 0; j < mRegion.Count_Y; j++)
                {
                    double X = (double)(nud_StartX.Value + nud_StartX_add.Value + (nud_DistX.Value + nud_DistX_add.Value) * i);
                    double Y = (double)(nud_StartY.Value + nud_StartY_add.Value + (nud_DistY.Value + nud_DistY_add.Value) * j);
                    if (ScaleX == 0 || ScaleY == 0)
                    {
                        MessageBox.Show("Scale is Zero. Input Tray Size!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SvPoint P = new SvPoint(X / ScaleX, Y / ScaleY);
                    svDisplayView1.GraphicsCollection.Add(P);
                }
            }
        }

        public bool InitJob()
        {
            try
            {
                // Toolblock check
                if (mAlignResult.JobInfo.Count < 2)
                {
                    MessageBox.Show("There is no Toolblock Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvRegion)))
                {
                    MessageBox.Show("There is no SvRegion Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvWarpping)))
                {
                    MessageBox.Show("There is no SvWarpping Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                nud_TrayWidth.Text = mRecipeData.DicProcess[mProcess].RobotData.TrayWidth.ToString("F3");
                nud_TrayHeight.Text = mRecipeData.DicProcess[mProcess].RobotData.TrayHeight.ToString("F3");

                if (nud_TrayWidth.Value == 0)
                    nud_TrayWidth.Value = 550;

                if (nud_TrayHeight.Value == 0)
                    nud_TrayHeight.Value = 450;

                //mWarppoint = mAlignResult.JobInfo[typeof(SvWarpping)][0].Toolbase as SvWarpping;
                //mToolblock = mAlignResult.JobInfo[typeof(SvToolBlock)][mRegionIndex].Toolbase as SvToolBlock;
                mRegion = mAlignResult.JobInfo[mRegionIndex+1][typeof(SvRegion)][0].Toolbase as SvRegion;

                if (!GetTargetPoint()) return false;

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        private bool GetTargetPoint()
        {
            if (mRegion.outParams.ContainsKey("RectLeft"))
                mStartP = new Point2f(mRegion.RegionRect.Left.X, mRegion.RegionRect.Left.Y);
            else if (mRegion.outParams.ContainsKey("RectRight"))
                mStartP = new Point2f(mRegion.RegionRect.Right.X, mRegion.RegionRect.Right.Y);
            else if (mRegion.outParams.ContainsKey("RectTop"))
                mStartP = new Point2f(mRegion.RegionRect.Top.X, mRegion.RegionRect.Top.Y);
            else if (mRegion.outParams.ContainsKey("RectBottom"))
                mStartP = new Point2f(mRegion.RegionRect.Bottom.X, mRegion.RegionRect.Bottom.Y);
            else
            {
                MessageBox.Show("This Region Tool don't contain OutPoint", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        public void btn_Run_Click(object sender, EventArgs e)
        {
            mJob.Run();

            GetTargetPoint();

            nud_StartX.Text = (mStartP.X * ScaleX).ToString("F3");
            nud_StartY.Text = (mStartP.Y * ScaleY).ToString("F3");

            nud_DistX.Text = ((double)mRegion.Dist_X * ScaleX).ToString("F3");
            nud_DistY.Text = ((double)mRegion.Dist_Y * ScaleY).ToString("F3");

            nud_StartX_add.Value = 0;
            nud_StartY_add.Value = 0;

            nud_DistX_add.Value = 0;
            nud_DistY_add.Value = 0;

            svDisplayView1.ClearImage();
            svDisplayView1.GraphicsCollection.Clear();

            svDisplayView1.Image = mRegion.InputImage;
            mRegion.Index_X = 0; mRegion.Index_Y = 0;
            mRegion.DisplayRegions(svDisplayView1);
        }

        Point2f mStartP;

        public void btn_Save_Click(object sender, EventArgs e)
        {
            if (ScaleX == 0 || ScaleY == 0)
            {
                MessageBox.Show("Scale is Zero. Input Tray Size!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            float X = (float)(nud_StartX_add.Value) / ScaleX;
            float Y = (float)(nud_StartY_add.Value) / ScaleY;

            string recipeName = mRecipeData.RecipeName; //이거보단 class 이름이 더 나으려나?

            if (nud_StartX_add.Value != 0)
            {
                float start_X = (float)(nud_StartX.Value + nud_StartX_add.Value);
                SvLogger.Log.Recipe(recipeName + " X Start Offset Change : " + nud_StartX_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray X Start Point Change : " + nud_StartX.Value.ToString("F1") + " → " + start_X.ToString("F1"));
            }

            if (nud_StartY_add.Value != 0)
            {
                float start_Y = (float)(nud_StartY.Value + nud_StartY_add.Value);
                SvLogger.Log.Recipe(recipeName + " Y Start Offset Change : " + nud_StartY_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray Y Start Point Change : " + nud_StartY.Value.ToString("F1") + " → " + start_Y.ToString("F1"));
            }
            Point2f startP = new Point2f(X, Y);

            mRegion.RegionRect.Location += startP;

            mRegion.Dist_X += nud_DistX_add.Value / (decimal)ScaleX;
            if (nud_DistX_add.Value != 0)
            {
                float offset_X = (float)(nud_DistX.Value + nud_DistX_add.Value);
                SvLogger.Log.Recipe(recipeName + " X Distance Offset Change : " + nud_DistX_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray X Distance Change : " + nud_DistX.Value.ToString("F1") + " → " + offset_X.ToString("F1"));
            }

            mRegion.Dist_Y += nud_DistY_add.Value / (decimal)ScaleY;
            if (nud_DistY_add.Value != 0)
            {
                float offset_Y = (float)(nud_DistY.Value + nud_DistY_add.Value);
                SvLogger.Log.Recipe(recipeName + " Y Distance Offset Change : " + nud_DistY_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray Y Distance Change : " + nud_DistY.Value.ToString("F1") + " → " + offset_Y.ToString("F1"));
            }

            mRecipeData.DicProcess[mProcess].RobotData.TrayWidth = (double)nud_TrayWidth.Value;
            mRecipeData.DicProcess[mProcess].RobotData.TrayHeight = (double)nud_TrayHeight.Value;

            mSerializer.SaveJob(mJob, mJobPath);

            //// Tray Offset Pocket Reference Position 등록
            //InitJob();

            MessageBox.Show("Data saving Complete!!!");

            Auto.IsRecipeDataChanged = true;
        }

        private void btn_Toolblock_Click(object sender, EventArgs e)
        {
            string[] strs = btn_Region.Text.Split('#');

            mRegionIndex = int.Parse(strs[strs.Length - 1]);
            //mRegionIndex = (mRegionIndex + 1) % mAlignResult.JobInfo[1][typeof(SvRegion)].Count;
            mRegionIndex = (mRegionIndex + 1) % listToolblock.Count;

            btn_Region.Text = "Region #" + mRegionIndex;

            InitJob();
            btn_Run_Click(null, null);
        }







        /// <summary>
        /// Designer에서 생성한 부분
        /// </summary>

        public System.Windows.Forms.NumericUpDown nud_DistX_add;
        public System.Windows.Forms.NumericUpDown nud_TrayWidth;
        public System.Windows.Forms.NumericUpDown nud_TrayHeight;
        public System.Windows.Forms.NumericUpDown nud_DistY_add;
        public System.Windows.Forms.NumericUpDown nud_StartX_add;
        public System.Windows.Forms.NumericUpDown nud_StartY_add;
        public System.Windows.Forms.NumericUpDown nud_DistX;
        public System.Windows.Forms.NumericUpDown nud_DistY;
        public System.Windows.Forms.NumericUpDown nud_StartX;
        public System.Windows.Forms.NumericUpDown nud_StartY;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Button btn_RegionSave;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public Display.SvDisplayView svDisplayView1;
        private System.ComponentModel.IContainer components;

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nud_DistX_add = new System.Windows.Forms.NumericUpDown();
            this.nud_TrayWidth = new System.Windows.Forms.NumericUpDown();
            this.nud_TrayHeight = new System.Windows.Forms.NumericUpDown();
            this.nud_DistY_add = new System.Windows.Forms.NumericUpDown();
            this.nud_StartX_add = new System.Windows.Forms.NumericUpDown();
            this.nud_StartY_add = new System.Windows.Forms.NumericUpDown();
            this.nud_DistX = new System.Windows.Forms.NumericUpDown();
            this.nud_DistY = new System.Windows.Forms.NumericUpDown();
            this.nud_StartX = new System.Windows.Forms.NumericUpDown();
            this.nud_StartY = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_RegionSave = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.svDisplayView1 = new SvMip.Display.SvDisplayView();
            this.btn_Run = new System.Windows.Forms.Button();
            this.btn_Region = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY)).BeginInit();
            this.SuspendLayout();
            // 
            // nud_DistX_add
            // 
            this.nud_DistX_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_DistX_add.DecimalPlaces = 1;
            this.nud_DistX_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_DistX_add.Location = new System.Drawing.Point(144, 457);
            this.nud_DistX_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistX_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistX_add.Name = "nud_DistX_add";
            this.nud_DistX_add.Size = new System.Drawing.Size(79, 20);
            this.nud_DistX_add.TabIndex = 27;
            this.nud_DistX_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_DistX_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_TrayWidth
            // 
            this.nud_TrayWidth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_TrayWidth.DecimalPlaces = 1;
            this.nud_TrayWidth.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_TrayWidth.Location = new System.Drawing.Point(306, 438);
            this.nud_TrayWidth.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_TrayWidth.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_TrayWidth.Name = "nud_TrayWidth";
            this.nud_TrayWidth.Size = new System.Drawing.Size(97, 20);
            this.nud_TrayWidth.TabIndex = 25;
            this.nud_TrayWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_TrayHeight
            // 
            this.nud_TrayHeight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_TrayHeight.DecimalPlaces = 1;
            this.nud_TrayHeight.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_TrayHeight.Location = new System.Drawing.Point(739, 175);
            this.nud_TrayHeight.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_TrayHeight.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_TrayHeight.Name = "nud_TrayHeight";
            this.nud_TrayHeight.Size = new System.Drawing.Size(97, 20);
            this.nud_TrayHeight.TabIndex = 24;
            this.nud_TrayHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_DistY_add
            // 
            this.nud_DistY_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_DistY_add.DecimalPlaces = 1;
            this.nud_DistY_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_DistY_add.Location = new System.Drawing.Point(756, 102);
            this.nud_DistY_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistY_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistY_add.Name = "nud_DistY_add";
            this.nud_DistY_add.Size = new System.Drawing.Size(79, 20);
            this.nud_DistY_add.TabIndex = 23;
            this.nud_DistY_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_DistY_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_StartX_add
            // 
            this.nud_StartX_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_StartX_add.DecimalPlaces = 1;
            this.nud_StartX_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_StartX_add.Location = new System.Drawing.Point(29, 457);
            this.nud_StartX_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartX_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartX_add.Name = "nud_StartX_add";
            this.nud_StartX_add.Size = new System.Drawing.Size(79, 20);
            this.nud_StartX_add.TabIndex = 22;
            this.nud_StartX_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_StartX_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_StartY_add
            // 
            this.nud_StartY_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_StartY_add.DecimalPlaces = 1;
            this.nud_StartY_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_StartY_add.Location = new System.Drawing.Point(756, 45);
            this.nud_StartY_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartY_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartY_add.Name = "nud_StartY_add";
            this.nud_StartY_add.Size = new System.Drawing.Size(79, 20);
            this.nud_StartY_add.TabIndex = 21;
            this.nud_StartY_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_StartY_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_DistX
            // 
            this.nud_DistX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_DistX.DecimalPlaces = 1;
            this.nud_DistX.Enabled = false;
            this.nud_DistX.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DistX.Location = new System.Drawing.Point(126, 438);
            this.nud_DistX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistX.Name = "nud_DistX";
            this.nud_DistX.ReadOnly = true;
            this.nud_DistX.Size = new System.Drawing.Size(97, 20);
            this.nud_DistX.TabIndex = 20;
            this.nud_DistX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_DistY
            // 
            this.nud_DistY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_DistY.DecimalPlaces = 1;
            this.nud_DistY.Enabled = false;
            this.nud_DistY.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DistY.Location = new System.Drawing.Point(739, 83);
            this.nud_DistY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistY.Name = "nud_DistY";
            this.nud_DistY.ReadOnly = true;
            this.nud_DistY.Size = new System.Drawing.Size(97, 20);
            this.nud_DistY.TabIndex = 19;
            this.nud_DistY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_StartX
            // 
            this.nud_StartX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_StartX.DecimalPlaces = 1;
            this.nud_StartX.Enabled = false;
            this.nud_StartX.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_StartX.Location = new System.Drawing.Point(12, 438);
            this.nud_StartX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartX.Name = "nud_StartX";
            this.nud_StartX.ReadOnly = true;
            this.nud_StartX.Size = new System.Drawing.Size(97, 20);
            this.nud_StartX.TabIndex = 18;
            this.nud_StartX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_StartY
            // 
            this.nud_StartY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_StartY.DecimalPlaces = 1;
            this.nud_StartY.Enabled = false;
            this.nud_StartY.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_StartY.Location = new System.Drawing.Point(739, 27);
            this.nud_StartY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartY.Name = "nud_StartY";
            this.nud_StartY.ReadOnly = true;
            this.nud_StartY.Size = new System.Drawing.Size(97, 20);
            this.nud_StartY.TabIndex = 26;
            this.nud_StartY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(735, 159);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 15);
            this.label10.TabIndex = 17;
            this.label10.Text = "Tray Heiht";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(302, 421);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Tray Width";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(123, 421);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Dist. X";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(735, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 15);
            this.label8.TabIndex = 14;
            this.label8.Text = "Dist. Y";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(735, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Start Y";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 421);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "Start X";
            // 
            // btn_RegionSave
            // 
            this.btn_RegionSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_RegionSave.Location = new System.Drawing.Point(739, 428);
            this.btn_RegionSave.Name = "btn_RegionSave";
            this.btn_RegionSave.Size = new System.Drawing.Size(96, 50);
            this.btn_RegionSave.TabIndex = 11;
            this.btn_RegionSave.Text = "Save";
            this.btn_RegionSave.UseVisualStyleBackColor = true;
            this.btn_RegionSave.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(127, 459);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "+";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(13, 459);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "+";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(737, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "+";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(737, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "+";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // svDisplayView1
            // 
            this.svDisplayView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.svDisplayView1.AutoScroll = true;
            this.svDisplayView1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svDisplayView1.Location = new System.Drawing.Point(12, 12);
            this.svDisplayView1.Name = "svDisplayView1";
            this.svDisplayView1.Size = new System.Drawing.Size(717, 406);
            this.svDisplayView1.TabIndex = 6;
            this.svDisplayView1.ToastVisible = true;
            this.svDisplayView1.ZoomVisible = false;
            // 
            // btn_Run
            // 
            this.btn_Run.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Run.Location = new System.Drawing.Point(740, 372);
            this.btn_Run.Name = "btn_Run";
            this.btn_Run.Size = new System.Drawing.Size(96, 50);
            this.btn_Run.TabIndex = 11;
            this.btn_Run.Text = "Run";
            this.btn_Run.UseVisualStyleBackColor = true;
            this.btn_Run.Click += new System.EventHandler(this.btn_Run_Click);
            // 
            // btn_Region
            // 
            this.btn_Region.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Region.Location = new System.Drawing.Point(738, 221);
            this.btn_Region.Name = "btn_Region";
            this.btn_Region.Size = new System.Drawing.Size(98, 46);
            this.btn_Region.TabIndex = 28;
            this.btn_Region.Text = "Region #0";
            this.btn_Region.UseVisualStyleBackColor = true;
            this.btn_Region.Click += new System.EventHandler(this.btn_Toolblock_Click);
            // 
            // DataEdit_TrayOffset
            // 
            this.ClientSize = new System.Drawing.Size(848, 488);
            this.Controls.Add(this.btn_Region);
            this.Controls.Add(this.nud_DistX_add);
            this.Controls.Add(this.nud_TrayWidth);
            this.Controls.Add(this.nud_TrayHeight);
            this.Controls.Add(this.nud_DistY_add);
            this.Controls.Add(this.nud_StartX_add);
            this.Controls.Add(this.nud_StartY_add);
            this.Controls.Add(this.nud_DistX);
            this.Controls.Add(this.nud_DistY);
            this.Controls.Add(this.nud_StartX);
            this.Controls.Add(this.nud_StartY);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_Run);
            this.Controls.Add(this.btn_RegionSave);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.svDisplayView1);
            this.Name = "DataEdit_TrayOffset";
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
