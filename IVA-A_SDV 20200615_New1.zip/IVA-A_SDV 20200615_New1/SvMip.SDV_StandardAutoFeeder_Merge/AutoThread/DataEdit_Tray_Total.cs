﻿using OpenCvSharp.CPlusPlus;
using SvMip.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public partial class DataEdit_Tray_Total : DataEdit_Base
    {
        public DataEdit_Tray_Total(ProcessData _procdata, RecipeData _recipeData, Main.Process _process, string _jobName)
            : base(_recipeData, _process, _jobName)
        {
            InitializeComponent();
            IsPossible = InitJob();

            foreach (var toolinfo in mAlignResult.JobInfo[0][typeof(SvToolBlock)])
                listToolblock.Add(toolinfo.Toolbase as SvToolBlock);
            dgv_Threshold.RowsRemoved += Dgv_Threshold_RowsRemoved;
            dgv_Threshold_Range.RowsRemoved += Dgv_Threshold_Range_RowsRemoved;
        }

        private void Dgv_Threshold_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            for (int i = 0; i < dgv_Threshold.Rows.Count; i++)
            {
                dgv_Threshold.Rows[i].Cells[0].Value = i + 1;
            }
        }
        private void Dgv_Threshold_Range_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            for (int i = 0; i < dgv_Threshold_Range.Rows.Count; i++)
            {
                dgv_Threshold_Range.Rows[i].Cells[0].Value = i + 1;
            }
        }
        SvRegion mRegion = null;
        SvMakePoint mMakePoint = null;
        SvJudgement mJudge = null;
        SvBlob mBlob = null;
        List<int> listBlobA= new List<int>();
        List<int> listBlobB= new List<int>();
        List<double> listBlobRateA = new List<double>();
        List<double> listBlobRateB = new List<double>();

        protected int mToolblockIndex = 1;
        private bool tog_EasySetting = true;
        public Button btn_Run;
        private DataGridView dgv_Threshold;
        private Button btn_toolblock;
        private Button btn_SaveImage;
        private Button btn_EasySetting;
        private Button btn_SetAll;
        private Label label11;
        private NumericUpDown nud_ThresholdOffset;
        private Button btn_ThresholdOffset;
        private SplitContainer splitContainer1;
        private DataGridView dgv_Threshold_Range;
        private DataGridViewTextBoxColumn ColIndex;
        private DataGridViewTextBoxColumn ColThreshold;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private Button btn_calcBlobRange_A;
        private Button btn_calcBlobRange_B;
        private Button btn_calcBlobRange;
        private Button btn_grab_B;
        private Button btn_calcJudgeThres_A;
        private Button btn_grab_judgeB;
        private Button btn_calcJudgeThres_B;
        private Button btn_calcJudgeThres;
        List<SvToolBlock> listToolblock = new List<SvToolBlock>();

        //float scaleX;
        public float ScaleX
        {
            get
            {
                if (mRegion.InputImage == null) return 0;
                return (float)nud_TrayWidth.Value / mRegion.InputImage.Width;
            }
        }
        //float scaleY;
        public float ScaleY
        {
            get
            {
                if (mRegion.InputImage == null) return 0;
                return (float)nud_TrayHeight.Value / mRegion.InputImage.Height;
            }
        }

        private void nud_Value_add_ValueChanged(object sender, EventArgs e)
        {
            float X = (float)(nud_StartX_add.Value) / ScaleX;
            float Y = (float)(nud_StartY_add.Value) / ScaleY;
            Point2f startP = new Point2f(X, Y);
            mRegion.RegionRect.Location += startP;

            mRegion.Dist_X += nud_DistX_add.Value / (decimal)ScaleX;
            mRegion.Dist_Y += nud_DistY_add.Value / (decimal)ScaleY;

            svDisplayView1.ClearImage();
            svDisplayView1.GraphicsCollection.Clear();

            svDisplayView1.Image = mRegion.InputImage;

            if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
            {
                DisplayJudgement();
            }

            if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvMakePoint)))
            {
                DisplayPoint();
            }

            mRegion.RegionRect.Location -= startP;
            mRegion.Dist_X -= nud_DistX_add.Value / (decimal)ScaleX;
            mRegion.Dist_Y -= nud_DistY_add.Value / (decimal)ScaleY;
        }

        public bool InitJob()
        {
            try
            {
                // Toolblock check
                if (mAlignResult.JobInfo.Count < 2)
                {
                    MessageBox.Show("There is no Toolblock Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvRegion)))
                {
                    MessageBox.Show("There is no SvRegion Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                //if (!mAlignResult.JobInfo[1].ContainsKey(typeof(SvJudgement)))
                //{
                //    MessageBox.Show("There is no SvJudgement Tool!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return false;
                //}

                nud_TrayWidth.Text = mRecipeData.DicProcess[mProcess].RobotData.TrayWidth.ToString("F3");
                nud_TrayHeight.Text = mRecipeData.DicProcess[mProcess].RobotData.TrayHeight.ToString("F3");

                if (nud_TrayWidth.Value == 0)
                    nud_TrayWidth.Value = 550;

                if (nud_TrayHeight.Value == 0)
                    nud_TrayHeight.Value = 450;

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
        }

        private SvJudgement GetThreshold(SvToolBlock block)
        {
            try
            {
                SvJudgement judge = null;
                foreach (var tool in block.ToolJob.ToolList)
                {
                    if (tool is SvJudgement)
                    {
                        judge = (SvJudgement)tool;
                        break;
                    }
                }
                return judge;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return new SvJudgement();
            }
        }

        private bool GetTargetPoint()
        {
            if (mRegion == null) return false;

            if (mRegion.outParams.ContainsKey("RectLeft"))
                mStartP = new Point2f(mRegion.RegionRect.Left.X, mRegion.RegionRect.Left.Y);
            else if (mRegion.outParams.ContainsKey("RectRight"))
                mStartP = new Point2f(mRegion.RegionRect.Right.X, mRegion.RegionRect.Right.Y);
            else if (mRegion.outParams.ContainsKey("RectTop"))
                mStartP = new Point2f(mRegion.RegionRect.Top.X, mRegion.RegionRect.Top.Y);
            else if (mRegion.outParams.ContainsKey("RectBottom"))
                mStartP = new Point2f(mRegion.RegionRect.Bottom.X, mRegion.RegionRect.Bottom.Y);
            else if (mRegion.outParams.ContainsKey("RectCenter"))
                mStartP = new Point2f(mRegion.RegionRect.Center.X, mRegion.RegionRect.Center.Y);
            else
                mStartP = new Point2f(mRegion.RegionRect.Location.X, mRegion.RegionRect.Location.Y);

            return true;
        }

        public void btn_Run_Click(object sender, EventArgs e)
        {
            try
            {
                mJob.Run();

                if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
                {
                    DisplayJudgement();
                }
                else if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvMakePoint)))
                {
                    DisplayPoint();
                }
                else
                {
                    return;
                }

                GetTargetPoint();

                nud_StartX.Text = (mStartP.X * ScaleX).ToString("F3");
                nud_StartY.Text = (mStartP.Y * ScaleY).ToString("F3");

                nud_DistX.Text = ((double)mRegion.Dist_X * ScaleX).ToString("F3");
                nud_DistY.Text = ((double)mRegion.Dist_Y * ScaleY).ToString("F3");

                nud_StartX_add.Value = 0;
                nud_StartY_add.Value = 0;

                nud_DistX_add.Value = 0;
                nud_DistY_add.Value = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        Point2f mStartP;

        private void btn_EasySetting_Click(object sender, EventArgs e)
        {
            if (tog_EasySetting)
            {
                btn_calcBlobRange_A.Visible = true;
                btn_grab_B.Visible = true;
                btn_calcBlobRange_B.Visible = true;
                btn_calcBlobRange.Visible = true;
                btn_calcJudgeThres_A.Visible = true;
                btn_grab_judgeB.Visible = true;
                btn_calcJudgeThres_B.Visible = true;
                btn_calcJudgeThres.Visible = true;

                tog_EasySetting = false;
            }
            else
            {
                btn_calcBlobRange_A.BackColor = System.Drawing.Color.Empty;
                btn_grab_B.BackColor = System.Drawing.Color.Empty;
                btn_calcBlobRange_B.BackColor = System.Drawing.Color.Empty;
                btn_calcBlobRange.BackColor = System.Drawing.Color.Empty;
                btn_calcJudgeThres_A.BackColor = System.Drawing.Color.Empty;
                btn_grab_judgeB.BackColor = System.Drawing.Color.Empty;
                btn_calcJudgeThres_B.BackColor = System.Drawing.Color.Empty;
                btn_calcJudgeThres.BackColor = System.Drawing.Color.Empty;

                btn_calcBlobRange_A.Visible = false;
                btn_grab_B.Visible = false;
                btn_calcBlobRange_B.Visible = false;
                btn_calcBlobRange.Visible = false;
                btn_calcJudgeThres_A.Visible = false;
                btn_grab_judgeB.Visible = false;
                btn_calcJudgeThres_B.Visible = false;
                btn_calcJudgeThres.Visible = false;

                tog_EasySetting = true;
            }
        }


        private void btn_SaveImage_Click(object sender, EventArgs e)
        {
            try
            {
                SvImage InputImage = null;
                foreach (SvToolBase toolbase in mJob.ToolList)
                {

                    if (toolbase is SvAcquisition)
                    {
                        toolbase.InitOutProperty();
                        toolbase.Run();
                        InputImage = toolbase.imageList[0].Image;
                        break;
                    }

                }

                if (InputImage == null)
                {
                    return;
                }

                SaveFileDialog fd = new SaveFileDialog();
                fd.Filter = "Image files (*.png)|*.png|All files (*.*)|*.*";
                fd.FilterIndex = 1;
                fd.DefaultExt = "*.png";
                if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

                InputImage.Mat.SaveImage(fd.FileName);

                svDisplayView1.ClearImage();
                svDisplayView1.GraphicsCollection.Clear();

                svDisplayView1.Image = InputImage;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }


        public void btn_Save_Click(object sender, EventArgs e)
        {
            //mJudge.Thresholds.Clear();
            //for (int i = 0; i < dgv_Threshold.RowCount - 1; i++)
            //{
            //    // 값을 object 변수에 담기
            //    object obj = dgv_Threshold.Rows[i].Cells[1].Value;
            //    string str = obj.ToString();
            //    // object 변수를 형변환하게 되면 에러 발생
            //    double ddd = 0.0;
            //    if (double.TryParse(str, out ddd))
            //    {
            //        // tool 쪽으로 데이터 저장
            //        mJudge.Thresholds.Add(ddd);
            //    }
            //}

            MessageBox.Show("If the numbers of row of DataGrid and region are not equal, first row value of DataGrid is applied to all region!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

            if (ScaleX == 0 || ScaleY == 0)
            {
                MessageBox.Show("Saved thresholds only!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            float X = (float)(nud_StartX_add.Value) / ScaleX;
            float Y = (float)(nud_StartY_add.Value) / ScaleY;

            string recipeName = mRecipeData.RecipeName; //이거보단 class 이름이 더 나으려나?

            if (nud_StartX_add.Value != 0)
            {
                float start_X = (float)(nud_StartX.Value + nud_StartX_add.Value);
                SvLogger.Log.Recipe(recipeName + " X Start Offset Change : " + nud_StartX_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray X Start Point Change : " + nud_StartX.Value.ToString("F1") + " → " + start_X.ToString("F1"));
            }

            if (nud_StartY_add.Value != 0)
            {
                float start_Y = (float)(nud_StartY.Value + nud_StartY_add.Value);
                SvLogger.Log.Recipe(recipeName + " Y Start Offset Change : " + nud_StartY_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray Y Start Point Change : " + nud_StartY.Value.ToString("F1") + " → " + start_Y.ToString("F1"));
            }
            Point2f startP = new Point2f(X, Y);

            mRegion.RegionRect.Location += startP;

            mRegion.Dist_X += nud_DistX_add.Value / (decimal)ScaleX;
            if (nud_DistX_add.Value != 0)
            {
                float offset_X = (float)(nud_DistX.Value + nud_DistX_add.Value);
                SvLogger.Log.Recipe(recipeName + " X Distance Offset Change : " + nud_DistX_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray X Distance Change : " + nud_DistX.Value.ToString("F1") + " → " + offset_X.ToString("F1"));
            }

            mRegion.Dist_Y += nud_DistY_add.Value / (decimal)ScaleY;
            if (nud_DistY_add.Value != 0)
            {
                float offset_Y = (float)(nud_DistY.Value + nud_DistY_add.Value);
                SvLogger.Log.Recipe(recipeName + " Y Distance Offset Change : " + nud_DistY_add.Value.ToString("F1"));
                SvLogger.Log.Recipe(recipeName + " Tray Y Distance Change : " + nud_DistY.Value.ToString("F1") + " → " + offset_Y.ToString("F1"));
            }

            mRecipeData.DicProcess[mProcess].RobotData.TrayWidth = (double)nud_TrayWidth.Value;
            mRecipeData.DicProcess[mProcess].RobotData.TrayHeight = (double)nud_TrayHeight.Value;


            mSerializer.SaveJob(mJob, mJobPath);

            //// Tray Offset Pocket Reference Position 등록
            //InitJob();

            MessageBox.Show("Data saving Complete!!!");

            Auto.IsRecipeDataChanged = true;
        }

        private void btn_toolblock_Click(object sender, EventArgs e)
        {
            try
            {
                // ToolblockIndex 순환
                mToolblockIndex = (mToolblockIndex + 1) % mAlignResult.JobInfo.Count;
                if (mToolblockIndex == 0) mToolblockIndex++;

                mRegion = mAlignResult.JobInfo[mToolblockIndex][typeof(SvRegion)][0].Toolbase as SvRegion;

                if (mRegion.OutputImage == null)
                {
                    MessageBox.Show("Click Run button first!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mToolblockIndex--;
                    return;
                }

                GetTargetPoint();
                btn_toolblock.Text = string.Format("Toolblock #{0}", mToolblockIndex);

                nud_StartX.Text = (mStartP.X * ScaleX).ToString("F3");
                nud_StartY.Text = (mStartP.Y * ScaleY).ToString("F3");

                nud_DistX.Text = ((double)mRegion.Dist_X * ScaleX).ToString("F3");
                nud_DistY.Text = ((double)mRegion.Dist_Y * ScaleY).ToString("F3");

                nud_StartX_add.Value = 0;
                nud_StartY_add.Value = 0;

                nud_DistX_add.Value = 0;
                nud_DistY_add.Value = 0;

                dgv_Threshold.Rows.Clear();
                dgv_Threshold_Range.Rows.Clear();

                if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
                {
                    DisplayJudgement();
                }

                if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvMakePoint)))
                {
                    DisplayPoint();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        void DisplayJudgement()
        {
            if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)))
                return;

            mRegion = mAlignResult.JobInfo[mToolblockIndex][typeof(SvRegion)][0].Toolbase as SvRegion;
            mJudge = mAlignResult.JobInfo[mToolblockIndex][typeof(SvJudgement)][0].Toolbase as SvJudgement;
            //mBlob = mAlignResult.JobInfo[mToolblockIndex][typeof(SvBlob)][0].Toolbase as SvBlob;

            int regionCnt = mRegion.Count_X * mRegion.Count_Y;
            dgv_Threshold.Rows.Add(regionCnt);
                     
            dgv_Threshold.CellValueChanged -= dgv_Threshold_CellValueChanged;
            dgv_Threshold.Rows.Clear();

            for (int i = 0; i < mJudge.Thresholds.Count; i++)
            {
                dgv_Threshold.Rows.Add(i + 1, mJudge.Thresholds[i]);
            }
            if (mJudge.Thresholds.Count == 0)
            {
                dgv_Threshold.Rows.Add(1, mJudge.Creteria);
            }
            dgv_Threshold.CellValueChanged += dgv_Threshold_CellValueChanged;

            int blobcnt = 0;

            if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
            {
                mBlob = mAlignResult.JobInfo[mToolblockIndex][typeof(SvBlob)][0].Toolbase as SvBlob;
                dgv_Threshold_Range.Rows.Add(regionCnt);
                dgv_Threshold_Range.CellValueChanged -= dgv_Threshold_Range_CellValueChanged;

                dgv_Threshold_Range.Rows.Clear();
                for (int i = 0; i < mBlob.Ranges.Count; i++)
                {
                    dgv_Threshold_Range.Rows.Add(i + 1, mBlob.Ranges[i]);
                    blobcnt++;
                }
                if (mBlob.Ranges.Count == 0)
                {
                    dgv_Threshold_Range.Rows.Add(1, mBlob.RangeLow);
                    blobcnt++;
                }
                dgv_Threshold_Range.CellValueChanged += dgv_Threshold_Range_CellValueChanged;
            }
            svDisplayView1.ClearImage();
            svDisplayView1.GraphicsCollection.Clear();
            svDisplayView1.Image = mRegion.InputImage;

            mRegion.Index_X = 0; mRegion.Index_Y = 0;
            mRegion.DisplayRegions(svDisplayView1);

            System.Drawing.Font f = new System.Drawing.Font("굴림체", 8, System.Drawing.FontStyle.Bold);
            System.Drawing.SolidBrush SB = new System.Drawing.SolidBrush(System.Drawing.Color.Violet);

            SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;

            string str=null;
            mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

            if (blobcnt != 0)
            {
                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                {
                    if (mBlob.Ranges.Count == 0)
                        mBlob.Ranges.Add(mBlob.RangeLow);
                    else if (mBlob.Ranges.Count == 1)
                        mBlob.RangeLow = mBlob.Ranges[0];
                    else
                        mBlob.RangeLow = mBlob.Ranges[i];

                    toolblock.ToolJob.Run();

                    if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                        str = string.Format("{0}. Bolb Area: {1:f3}", i + 1, mJudge.Value);
                    else
                        str = string.Format("{0}. Score: {1:f3}", i + 1, mJudge.Value);

                    svDisplayView1.DrawString(str, f, SB, new Point2d(mRegion.OutputImage.RegionRect.Location.X, mRegion.OutputImage.RegionRect.Location.Y));
                    mRegion.IncreaseIndex();
                }
            }
        }

        void DisplayPoint()
        {
            if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)))
                return;

            mRegion = mAlignResult.JobInfo[mToolblockIndex][typeof(SvRegion)][0].Toolbase as SvRegion;
            mMakePoint = mAlignResult.JobInfo[mToolblockIndex][typeof(SvMakePoint)][0].Toolbase as SvMakePoint;

            svDisplayView1.ClearImage();
            svDisplayView1.GraphicsCollection.Clear();
            svDisplayView1.Image = mRegion.InputImage;

            mRegion.Index_X = 0; mRegion.Index_Y = 0;
            mRegion.DisplayRegions(svDisplayView1);

            for (int i = 0; i < mRegion.Count_X; i++)
            {
                for (int j = 0; j < mRegion.Count_Y; j++)
                {
                    double X = (double)(nud_StartX.Value + nud_StartX_add.Value + (nud_DistX.Value + nud_DistX_add.Value) * i);
                    double Y = (double)(nud_StartY.Value + nud_StartY_add.Value + (nud_DistY.Value + nud_DistY_add.Value) * j);
                    if (ScaleX == 0 || ScaleY == 0)
                    {
                        MessageBox.Show("Scale is Zero. Input Tray Size!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    SvPoint P = new SvPoint(X / ScaleX, Y / ScaleY);
                    svDisplayView1.GraphicsCollection.Add(P);
                }
            }
        }

        private void dgv_Threshold_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement))) return;
            if (e.RowIndex < 0) return;
            double value = -1;

            try
            {
                // 값을 지웠을 경우 0.0으로 대체
                if (dgv_Threshold.Rows[e.RowIndex].Cells[1].Value == null || dgv_Threshold.Rows[e.RowIndex].Cells[1].Value == "")
                {
                    if (mJudge.Thresholds.Count > e.RowIndex)
                        mJudge.Thresholds[e.RowIndex] = 0.0;
                    return;
                }

                // double 형변환이 안될 경우, 원복
                if (!double.TryParse(dgv_Threshold.Rows[e.RowIndex].Cells[1].Value.ToString(), out value))
                {
                    if (mJudge.Thresholds.Count > e.RowIndex)
                        dgv_Threshold.Rows[e.RowIndex].Cells[1].Value = mJudge.Thresholds[e.RowIndex];
                    else
                        dgv_Threshold.Rows[e.RowIndex].Cells[1].Value = null;
                }

                // 한참 뒤에 값을 추가할 경우, 중간에 있는 값을 동일값으로 셋팅
                while (mJudge.Thresholds.Count <= e.RowIndex)
                {
                    mJudge.Thresholds.Add(value);
                    int i = mJudge.Thresholds.Count - 1;
                    dgv_Threshold.Rows[i].Cells[0].Value = i + 1;
                    dgv_Threshold.Rows[i].Cells[1].Value = value;
                }

                dgv_Threshold.Rows[e.RowIndex].Cells[0].Value = e.RowIndex + 1;
                mJudge.Thresholds[e.RowIndex] = value;

                if (e.RowIndex == 0) mJudge.Creteria = value;
            }
            finally
            {
                // trim
                for (int i = dgv_Threshold.Rows.Count - 1; i >= 0 && dgv_Threshold.Rows[i].Cells[1].Value == null; i--)
                {
                    dgv_Threshold.Rows[i].Cells[0].Value = null;
                    if (mJudge.Thresholds.Count > i)
                    {
                        mJudge.Thresholds.RemoveAt(i);
                    }
                }
            }
        }

        private void dgv_Threshold_Range_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            
            if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob))) return;
            if (e.RowIndex < 0) return;
            int value = -1;

            try
            {
                // 값을 지웠을 경우 0.0으로 대체
                if (dgv_Threshold_Range.Rows[e.RowIndex].Cells[1].Value == null || dgv_Threshold_Range.Rows[e.RowIndex].Cells[1].Value == "")
                {
             
                    if (mBlob.Ranges.Count > e.RowIndex)
                        mBlob.Ranges.RemoveAt(e.RowIndex);
                        //mBlob.Ranges[e.RowIndex] = 0;
                    return;
                }

                // double 형변환이 안될 경우, 원복
                if (!int.TryParse(dgv_Threshold_Range.Rows[e.RowIndex].Cells[1].Value.ToString(), out value))
                {
                    if (mBlob.Ranges.Count > e.RowIndex)
                        dgv_Threshold_Range.Rows[e.RowIndex].Cells[1].Value = mBlob.Ranges[e.RowIndex];
                    else
                        dgv_Threshold_Range.Rows[e.RowIndex].Cells[1].Value = null;
                }

                // 한참 뒤에 값을 추가할 경우, 중간에 있는 값을 동일값으로 셋팅
                while (mBlob.Ranges.Count <= e.RowIndex)
                {
                    mBlob.Ranges.Add(value);
                    int i = mBlob.Ranges.Count - 1;
                    dgv_Threshold_Range.Rows[i].Cells[0].Value = i + 1;
                    dgv_Threshold_Range.Rows[i].Cells[1].Value = value;
                }

                dgv_Threshold_Range.Rows[e.RowIndex].Cells[0].Value = e.RowIndex + 1;
                mBlob.Ranges[e.RowIndex] = value;

                if (e.RowIndex == 0) mBlob.RangeLow = value;
            }
            finally
            {
                // trim
                for (int i = dgv_Threshold_Range.Rows.Count - 1; i >= 0 && dgv_Threshold_Range.Rows[i].Cells[1].Value == null; i--)
                {
                    dgv_Threshold_Range.Rows[i].Cells[0].Value = null;
                    if (mBlob.Ranges.Count > i)
                    {
                        //mBlob.Ranges.RemoveAt(i);
                    }
                }
            }
        }

        private void btn_SetAll_Click(object sender, EventArgs e)
        {
            if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)))
                return;

            if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
                return;


                object cell = dgv_Threshold.SelectedRows[0].Cells[1].Value;
                double value;
                if (cell == null || !double.TryParse(cell.ToString(), out value))
                    return;

                mJudge.Thresholds.Clear();
                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                {
                    mJudge.Thresholds.Add(value);
                }
            DisplayJudgement();
        }


        private void btn_ThresholdOffset_Click(object sender, EventArgs e)
        {
            try
            {


                if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                {
                    MessageBox.Show("Need Region and Blob tool at job");
                    return;
                }

                int value;

                if (!int.TryParse(nud_ThresholdOffset.Value.ToString(), out value))
                {
                    MessageBox.Show("Input number to Blob Offset");
                    return;
                }
                if (mRegion == null)
                {
                    MessageBox.Show("Click Run button first!!");
                    return;
                }
                SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;
                mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

                DialogResult rst = MessageBox.Show("Do you want to add Blob Offset Value?", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                if (rst == DialogResult.Yes)
                {
                    if (dgv_Threshold_Range.Rows.Count != (mRegion.Count_X * mRegion.Count_Y) && (mBlob.Ranges.Count == (mRegion.Count_X * mRegion.Count_Y)))
                    {
                        dgv_Threshold_Range.Rows.Clear();
                        for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                        {
                            dgv_Threshold_Range.Rows.Add();
                        }
                    }
                    for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                    {
                        toolblock.ToolJob.Run();
                        /// 255 이상 넘을시 예외처리
                        //int val = (int)mBlob.RegionImage.Mean() + value;

                        int val = mBlob.Ranges[i] + value;

                        if (val > 255) val = 255;
                        else if (val < 0) val = 0;

                        dgv_Threshold_Range.Rows[i].Cells[1].Value = val;

                        if (mBlob.Ranges.Count == 1)
                            break;
                        else
                            mRegion.IncreaseIndex();
                    }
                }
                else if (rst == DialogResult.No)
                {
                    if (dgv_Threshold_Range.Rows.Count != (mRegion.Count_X * mRegion.Count_Y))
                    {
                        dgv_Threshold_Range.Rows.Clear();
                        for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                        {
                            dgv_Threshold_Range.Rows.Add();
                        }
                    }
                    for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                    {
                        toolblock.ToolJob.Run();

                        dgv_Threshold_Range.Rows[i].Cells[1].Value = (int)mBlob.RegionImage.Mean();

                        mRegion.IncreaseIndex();
                    }
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }

        private void btn_calcBlobRange_A_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_Threshold_Range.Rows.Clear();
                listBlobA.Clear();
                listBlobA = new List<int>();
                if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                {
                    MessageBox.Show("Need Region and Blob tool at job");
                    return;
                }
                mJob.Run();

                if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
                {
                    DisplayJudgement();
                }
                else if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvMakePoint)))
                {
                    DisplayPoint();
                }
                else
                {
                    return;
                }
                SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;
                mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;



                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                {
                    toolblock.ToolJob.Run();

                    listBlobA.Add((int)mBlob.RegionImage.Mean());

                    mRegion.IncreaseIndex();
                }
                

                btn_calcBlobRange_A.BackColor = System.Drawing.Color.Blue;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btn_grab_B_Click(object sender, EventArgs e)
        {
            try
            {
                mJob.Run();

                if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
                {
                    if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)))
                        return;

                    mRegion = mAlignResult.JobInfo[mToolblockIndex][typeof(SvRegion)][0].Toolbase as SvRegion;
                    mJudge = mAlignResult.JobInfo[mToolblockIndex][typeof(SvJudgement)][0].Toolbase as SvJudgement;

                    int regionCnt = mRegion.Count_X * mRegion.Count_Y;

                    if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                    {
                        mBlob = mAlignResult.JobInfo[mToolblockIndex][typeof(SvBlob)][0].Toolbase as SvBlob;
                    }
                    svDisplayView1.ClearImage();
                    svDisplayView1.GraphicsCollection.Clear();
                    svDisplayView1.Image = mRegion.InputImage;

                    mRegion.Index_X = 0; mRegion.Index_Y = 0;
                    mRegion.DisplayRegions(svDisplayView1);

                    System.Drawing.Font f = new System.Drawing.Font("굴림체", 8, System.Drawing.FontStyle.Bold);
                    System.Drawing.SolidBrush SB = new System.Drawing.SolidBrush(System.Drawing.Color.Violet);

                    SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;

                    string str = null;
                    mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

                    for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                    {
                        toolblock.ToolJob.Run();

                        if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                            str = string.Format("{0}. Bolb Area: {1:f3}", i + 1, mJudge.Value);
                        else
                            str = string.Format("{0}. Score: {1:f3}", i + 1, mJudge.Value);

                        svDisplayView1.DrawString(str, f, SB, new Point2d(mRegion.OutputImage.RegionRect.Location.X, mRegion.OutputImage.RegionRect.Location.Y));
                        mRegion.IncreaseIndex();
                    }
                }
                else if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvMakePoint)))
                {
                    DisplayPoint();
                }
                else
                {
                    return;
                }

                GetTargetPoint();

                nud_StartX.Text = (mStartP.X * ScaleX).ToString("F3");
                nud_StartY.Text = (mStartP.Y * ScaleY).ToString("F3");

                nud_DistX.Text = ((double)mRegion.Dist_X * ScaleX).ToString("F3");
                nud_DistY.Text = ((double)mRegion.Dist_Y * ScaleY).ToString("F3");

                nud_StartX_add.Value = 0;
                nud_StartY_add.Value = 0;

                nud_DistX_add.Value = 0;
                nud_DistY_add.Value = 0;

                btn_grab_B.BackColor = System.Drawing.Color.Blue;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_calcBlobRange_B_Click(object sender, EventArgs e)
        {
            try
            {
                listBlobB.Clear();
                listBlobB = new List<int>();
                if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                {
                    MessageBox.Show("Need Region and Blob tool at job");
                    return;
                }

                if (mRegion == null)
                {
                    MessageBox.Show("Click Run button first!!");
                    return;
                }
                SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;
                mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                {
                    toolblock.ToolJob.Run();

                    listBlobB.Add((int)mBlob.RegionImage.Mean());

                    mRegion.IncreaseIndex();
                }

                btn_calcBlobRange_B.BackColor = System.Drawing.Color.Blue;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void btn_calcBlobRange_Click(object sender, EventArgs e)
        {

            if (dgv_Threshold_Range.Rows.Count != (mRegion.Count_X * mRegion.Count_Y))
            {
                dgv_Threshold_Range.Rows.Clear();
                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                {
                    dgv_Threshold_Range.Rows.Add();
                }
            }
            for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
            {

                dgv_Threshold_Range.Rows[i].Cells[1].Value = (listBlobA[i] + listBlobB[i]) / 2;

                mRegion.IncreaseIndex();
            }
            btn_calcBlobRange.BackColor = System.Drawing.Color.Blue;


            DialogResult rst = MessageBox.Show("Do you want to save job?", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            if (rst == DialogResult.Yes)
            {
                MessageBox.Show("If the numbers of row of DataGrid and region are not equal, first row value of DataGrid is applied to all region!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (ScaleX == 0 || ScaleY == 0)
                {
                    MessageBox.Show("Saved thresholds only!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                float X = (float)(nud_StartX_add.Value) / ScaleX;
                float Y = (float)(nud_StartY_add.Value) / ScaleY;

                string recipeName = mRecipeData.RecipeName; //이거보단 class 이름이 더 나으려나?

                if (nud_StartX_add.Value != 0)
                {
                    float start_X = (float)(nud_StartX.Value + nud_StartX_add.Value);
                    SvLogger.Log.Recipe(recipeName + " X Start Offset Change : " + nud_StartX_add.Value.ToString("F1"));
                    SvLogger.Log.Recipe(recipeName + " Tray X Start Point Change : " + nud_StartX.Value.ToString("F1") + " → " + start_X.ToString("F1"));
                }

                if (nud_StartY_add.Value != 0)
                {
                    float start_Y = (float)(nud_StartY.Value + nud_StartY_add.Value);
                    SvLogger.Log.Recipe(recipeName + " Y Start Offset Change : " + nud_StartY_add.Value.ToString("F1"));
                    SvLogger.Log.Recipe(recipeName + " Tray Y Start Point Change : " + nud_StartY.Value.ToString("F1") + " → " + start_Y.ToString("F1"));
                }
                Point2f startP = new Point2f(X, Y);

                mRegion.RegionRect.Location += startP;

                mRegion.Dist_X += nud_DistX_add.Value / (decimal)ScaleX;
                if (nud_DistX_add.Value != 0)
                {
                    float offset_X = (float)(nud_DistX.Value + nud_DistX_add.Value);
                    SvLogger.Log.Recipe(recipeName + " X Distance Offset Change : " + nud_DistX_add.Value.ToString("F1"));
                    SvLogger.Log.Recipe(recipeName + " Tray X Distance Change : " + nud_DistX.Value.ToString("F1") + " → " + offset_X.ToString("F1"));
                }

                mRegion.Dist_Y += nud_DistY_add.Value / (decimal)ScaleY;
                if (nud_DistY_add.Value != 0)
                {
                    float offset_Y = (float)(nud_DistY.Value + nud_DistY_add.Value);
                    SvLogger.Log.Recipe(recipeName + " Y Distance Offset Change : " + nud_DistY_add.Value.ToString("F1"));
                    SvLogger.Log.Recipe(recipeName + " Tray Y Distance Change : " + nud_DistY.Value.ToString("F1") + " → " + offset_Y.ToString("F1"));
                }

                mRecipeData.DicProcess[mProcess].RobotData.TrayWidth = (double)nud_TrayWidth.Value;
                mRecipeData.DicProcess[mProcess].RobotData.TrayHeight = (double)nud_TrayHeight.Value;


                mSerializer.SaveJob(mJob, mJobPath);

                //// Tray Offset Pocket Reference Position 등록
                //InitJob();

                MessageBox.Show("Data saving Complete!!!");

                Auto.IsRecipeDataChanged = true;

            }
        }

        private void btn_calcJudgeThres_A_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_Threshold.Rows.Clear();
                listBlobRateA.Clear();
                listBlobRateA = new List<double>();
                if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                {
                    MessageBox.Show("Need Region and Blob tool at job");
                    return;
                }
                mJob.Run();

                if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
                {
                    DisplayJudgement();
                }
                else if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvMakePoint)))
                {
                    DisplayPoint();
                }
                else
                {
                    return;
                }
                SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;
                mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                {
                    mBlob.RangeLow = mBlob.Ranges[i];

                    toolblock.ToolJob.Run();

                    listBlobRateA.Add(mJudge.Value);

                    mRegion.IncreaseIndex();
                }

                btn_calcJudgeThres_A.BackColor = System.Drawing.Color.Blue;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_grab_judgeB_Click(object sender, EventArgs e)
        {
            try
            {
                mJob.Run();

                if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvJudgement)))
                {
                    if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)))
                        return;

                    mRegion = mAlignResult.JobInfo[mToolblockIndex][typeof(SvRegion)][0].Toolbase as SvRegion;
                    mJudge = mAlignResult.JobInfo[mToolblockIndex][typeof(SvJudgement)][0].Toolbase as SvJudgement;

                    int regionCnt = mRegion.Count_X * mRegion.Count_Y;

                    if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                    {
                        mBlob = mAlignResult.JobInfo[mToolblockIndex][typeof(SvBlob)][0].Toolbase as SvBlob;
                    }
                    svDisplayView1.ClearImage();
                    svDisplayView1.GraphicsCollection.Clear();
                    svDisplayView1.Image = mRegion.InputImage;

                    mRegion.Index_X = 0; mRegion.Index_Y = 0;
                    mRegion.DisplayRegions(svDisplayView1);

                    System.Drawing.Font f = new System.Drawing.Font("굴림체", 8, System.Drawing.FontStyle.Bold);
                    System.Drawing.SolidBrush SB = new System.Drawing.SolidBrush(System.Drawing.Color.Violet);

                    SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;

                    string str = null;
                    mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

                    for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                    {
                        mBlob.RangeLow = mBlob.Ranges[i];

                        toolblock.ToolJob.Run();

                        if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                            str = string.Format("{0}. Bolb Area: {1:f3}", i + 1, mJudge.Value);
                        else
                            str = string.Format("{0}. Score: {1:f3}", i + 1, mJudge.Value);

                        svDisplayView1.DrawString(str, f, SB, new Point2d(mRegion.OutputImage.RegionRect.Location.X, mRegion.OutputImage.RegionRect.Location.Y));
                        mRegion.IncreaseIndex();
                    }
                }
                else if (mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvMakePoint)))
                {
                    DisplayPoint();
                }
                else
                {
                    return;
                }

                GetTargetPoint();

                nud_StartX.Text = (mStartP.X * ScaleX).ToString("F3");
                nud_StartY.Text = (mStartP.Y * ScaleY).ToString("F3");


                nud_DistX.Text = ((double)mRegion.Dist_X * ScaleX).ToString("F3");
                nud_DistY.Text = ((double)mRegion.Dist_Y * ScaleY).ToString("F3");

                nud_StartX_add.Value = 0;
                nud_StartY_add.Value = 0;

                nud_DistX_add.Value = 0;
                nud_DistY_add.Value = 0;

                btn_grab_judgeB.BackColor = System.Drawing.Color.Blue;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());


            }
        }

        private void btn_calcJudgeThres_B_Click(object sender, EventArgs e)
        {
            try
            {
                dgv_Threshold.Rows.Clear();
                listBlobRateB.Clear();
                listBlobRateB = new List<double>();
                if (!mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvRegion)) || !mAlignResult.JobInfo[mToolblockIndex].ContainsKey(typeof(SvBlob)))
                {
                    MessageBox.Show("Need Region and Blob tool at job");
                    return;
                }
                if (mRegion == null)
                {
                    MessageBox.Show("Click Run button first!!");
                    return;
                }
                SvToolBlock toolblock = mAlignResult.JobInfo[0][typeof(SvToolBlock)][mToolblockIndex - 1].Toolbase as SvToolBlock;
                mRegion.IndexXnext = 0; mRegion.IndexYnext = 0;

                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                {
                    mBlob.RangeLow = mBlob.Ranges[i];

                    toolblock.ToolJob.Run();

                    listBlobRateB.Add(mJudge.Value);

                    mRegion.IncreaseIndex();
                }

                btn_calcJudgeThres_B.BackColor = System.Drawing.Color.Blue;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_calcJudgeThres_Click(object sender, EventArgs e)
        {
            if (dgv_Threshold.Rows.Count != (mRegion.Count_X * mRegion.Count_Y))
            {
                dgv_Threshold.Rows.Clear();
                for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
                {
                    dgv_Threshold.Rows.Add();
                }
            }
            for (int i = 0; i < mRegion.Count_X * mRegion.Count_Y; i++)
            {

                dgv_Threshold.Rows[i].Cells[1].Value = (listBlobRateA[i] + listBlobRateB[i]) / 2;

                mRegion.IncreaseIndex();
            }
            btn_calcJudgeThres.BackColor = System.Drawing.Color.Blue;

            DialogResult rst = MessageBox.Show("Do you want to save job?", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            if (rst == DialogResult.Yes)
            {
                MessageBox.Show("If the numbers of row of DataGrid and region are not equal, first row value of DataGrid is applied to all region!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (ScaleX == 0 || ScaleY == 0)
                {
                    MessageBox.Show("Saved thresholds only!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                float X = (float)(nud_StartX_add.Value) / ScaleX;
                float Y = (float)(nud_StartY_add.Value) / ScaleY;

                string recipeName = mRecipeData.RecipeName; //이거보단 class 이름이 더 나으려나?

                if (nud_StartX_add.Value != 0)
                {
                    float start_X = (float)(nud_StartX.Value + nud_StartX_add.Value);
                    SvLogger.Log.Recipe(recipeName + " X Start Offset Change : " + nud_StartX_add.Value.ToString("F1"));
                    SvLogger.Log.Recipe(recipeName + " Tray X Start Point Change : " + nud_StartX.Value.ToString("F1") + " → " + start_X.ToString("F1"));
                }

                if (nud_StartY_add.Value != 0)
                {
                    float start_Y = (float)(nud_StartY.Value + nud_StartY_add.Value);
                    SvLogger.Log.Recipe(recipeName + " Y Start Offset Change : " + nud_StartY_add.Value.ToString("F1"));
                    SvLogger.Log.Recipe(recipeName + " Tray Y Start Point Change : " + nud_StartY.Value.ToString("F1") + " → " + start_Y.ToString("F1"));
                }
                Point2f startP = new Point2f(X, Y);

                mRegion.RegionRect.Location += startP;

                mRegion.Dist_X += nud_DistX_add.Value / (decimal)ScaleX;
                if (nud_DistX_add.Value != 0)
                {
                    float offset_X = (float)(nud_DistX.Value + nud_DistX_add.Value);
                    SvLogger.Log.Recipe(recipeName + " X Distance Offset Change : " + nud_DistX_add.Value.ToString("F1"));
                    SvLogger.Log.Recipe(recipeName + " Tray X Distance Change : " + nud_DistX.Value.ToString("F1") + " → " + offset_X.ToString("F1"));
                }

                mRegion.Dist_Y += nud_DistY_add.Value / (decimal)ScaleY;
                if (nud_DistY_add.Value != 0)
                {
                    float offset_Y = (float)(nud_DistY.Value + nud_DistY_add.Value);
                    SvLogger.Log.Recipe(recipeName + " Y Distance Offset Change : " + nud_DistY_add.Value.ToString("F1"));
                    SvLogger.Log.Recipe(recipeName + " Tray Y Distance Change : " + nud_DistY.Value.ToString("F1") + " → " + offset_Y.ToString("F1"));
                }

                mRecipeData.DicProcess[mProcess].RobotData.TrayWidth = (double)nud_TrayWidth.Value;
                mRecipeData.DicProcess[mProcess].RobotData.TrayHeight = (double)nud_TrayHeight.Value;


                mSerializer.SaveJob(mJob, mJobPath);

                //// Tray Offset Pocket Reference Position 등록
                //InitJob();

                MessageBox.Show("Data saving Complete!!!");

                Auto.IsRecipeDataChanged = true;

            }
        }


        /// <summary>
        /// Designer에서 생성한 부분
        /// </summary>

        public System.Windows.Forms.NumericUpDown nud_DistX_add;
        public System.Windows.Forms.NumericUpDown nud_TrayWidth;
        public System.Windows.Forms.NumericUpDown nud_TrayHeight;
        public System.Windows.Forms.NumericUpDown nud_DistY_add;
        public System.Windows.Forms.NumericUpDown nud_StartX_add;
        public System.Windows.Forms.NumericUpDown nud_StartY_add;
        public System.Windows.Forms.NumericUpDown nud_DistX;
        public System.Windows.Forms.NumericUpDown nud_DistY;
        public System.Windows.Forms.NumericUpDown nud_StartX;
        public System.Windows.Forms.NumericUpDown nud_StartY;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.Button btn_RegionSave;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public Display.SvDisplayView svDisplayView1;
        private System.ComponentModel.IContainer components;

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.nud_DistX_add = new System.Windows.Forms.NumericUpDown();
            this.nud_TrayWidth = new System.Windows.Forms.NumericUpDown();
            this.nud_TrayHeight = new System.Windows.Forms.NumericUpDown();
            this.nud_DistY_add = new System.Windows.Forms.NumericUpDown();
            this.nud_StartX_add = new System.Windows.Forms.NumericUpDown();
            this.nud_StartY_add = new System.Windows.Forms.NumericUpDown();
            this.nud_DistX = new System.Windows.Forms.NumericUpDown();
            this.nud_DistY = new System.Windows.Forms.NumericUpDown();
            this.nud_StartX = new System.Windows.Forms.NumericUpDown();
            this.nud_StartY = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_RegionSave = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.svDisplayView1 = new SvMip.Display.SvDisplayView();
            this.btn_Run = new System.Windows.Forms.Button();
            this.dgv_Threshold = new System.Windows.Forms.DataGridView();
            this.ColIndex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColThreshold = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_toolblock = new System.Windows.Forms.Button();
            this.btn_SaveImage = new System.Windows.Forms.Button();
            this.btn_EasySetting = new System.Windows.Forms.Button();
            this.btn_SetAll = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.nud_ThresholdOffset = new System.Windows.Forms.NumericUpDown();
            this.btn_ThresholdOffset = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgv_Threshold_Range = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_calcBlobRange_A = new System.Windows.Forms.Button();
            this.btn_calcBlobRange_B = new System.Windows.Forms.Button();
            this.btn_calcBlobRange = new System.Windows.Forms.Button();
            this.btn_grab_B = new System.Windows.Forms.Button();
            this.btn_calcJudgeThres_A = new System.Windows.Forms.Button();
            this.btn_grab_judgeB = new System.Windows.Forms.Button();
            this.btn_calcJudgeThres_B = new System.Windows.Forms.Button();
            this.btn_calcJudgeThres = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY_add)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Threshold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ThresholdOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Threshold_Range)).BeginInit();
            this.SuspendLayout();
            // 
            // nud_DistX_add
            // 
            this.nud_DistX_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_DistX_add.DecimalPlaces = 1;
            this.nud_DistX_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_DistX_add.Location = new System.Drawing.Point(144, 457);
            this.nud_DistX_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistX_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistX_add.Name = "nud_DistX_add";
            this.nud_DistX_add.Size = new System.Drawing.Size(79, 21);
            this.nud_DistX_add.TabIndex = 27;
            this.nud_DistX_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_DistX_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_TrayWidth
            // 
            this.nud_TrayWidth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_TrayWidth.DecimalPlaces = 1;
            this.nud_TrayWidth.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_TrayWidth.Location = new System.Drawing.Point(244, 438);
            this.nud_TrayWidth.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_TrayWidth.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_TrayWidth.Name = "nud_TrayWidth";
            this.nud_TrayWidth.Size = new System.Drawing.Size(97, 21);
            this.nud_TrayWidth.TabIndex = 25;
            this.nud_TrayWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_TrayHeight
            // 
            this.nud_TrayHeight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_TrayHeight.DecimalPlaces = 1;
            this.nud_TrayHeight.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_TrayHeight.Location = new System.Drawing.Point(739, 145);
            this.nud_TrayHeight.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_TrayHeight.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_TrayHeight.Name = "nud_TrayHeight";
            this.nud_TrayHeight.Size = new System.Drawing.Size(97, 21);
            this.nud_TrayHeight.TabIndex = 24;
            this.nud_TrayHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_DistY_add
            // 
            this.nud_DistY_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_DistY_add.DecimalPlaces = 1;
            this.nud_DistY_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_DistY_add.Location = new System.Drawing.Point(756, 102);
            this.nud_DistY_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistY_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistY_add.Name = "nud_DistY_add";
            this.nud_DistY_add.Size = new System.Drawing.Size(79, 21);
            this.nud_DistY_add.TabIndex = 23;
            this.nud_DistY_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_DistY_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_StartX_add
            // 
            this.nud_StartX_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_StartX_add.DecimalPlaces = 1;
            this.nud_StartX_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_StartX_add.Location = new System.Drawing.Point(29, 457);
            this.nud_StartX_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartX_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartX_add.Name = "nud_StartX_add";
            this.nud_StartX_add.Size = new System.Drawing.Size(79, 21);
            this.nud_StartX_add.TabIndex = 22;
            this.nud_StartX_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_StartX_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_StartY_add
            // 
            this.nud_StartY_add.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_StartY_add.DecimalPlaces = 1;
            this.nud_StartY_add.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_StartY_add.Location = new System.Drawing.Point(756, 45);
            this.nud_StartY_add.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartY_add.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartY_add.Name = "nud_StartY_add";
            this.nud_StartY_add.Size = new System.Drawing.Size(79, 21);
            this.nud_StartY_add.TabIndex = 21;
            this.nud_StartY_add.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_StartY_add.ValueChanged += new System.EventHandler(this.nud_Value_add_ValueChanged);
            // 
            // nud_DistX
            // 
            this.nud_DistX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_DistX.DecimalPlaces = 1;
            this.nud_DistX.Enabled = false;
            this.nud_DistX.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DistX.Location = new System.Drawing.Point(126, 438);
            this.nud_DistX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistX.Name = "nud_DistX";
            this.nud_DistX.ReadOnly = true;
            this.nud_DistX.Size = new System.Drawing.Size(97, 21);
            this.nud_DistX.TabIndex = 20;
            this.nud_DistX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_DistY
            // 
            this.nud_DistY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_DistY.DecimalPlaces = 1;
            this.nud_DistY.Enabled = false;
            this.nud_DistY.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_DistY.Location = new System.Drawing.Point(739, 83);
            this.nud_DistY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_DistY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_DistY.Name = "nud_DistY";
            this.nud_DistY.ReadOnly = true;
            this.nud_DistY.Size = new System.Drawing.Size(97, 21);
            this.nud_DistY.TabIndex = 19;
            this.nud_DistY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_StartX
            // 
            this.nud_StartX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_StartX.DecimalPlaces = 1;
            this.nud_StartX.Enabled = false;
            this.nud_StartX.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_StartX.Location = new System.Drawing.Point(12, 438);
            this.nud_StartX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartX.Name = "nud_StartX";
            this.nud_StartX.ReadOnly = true;
            this.nud_StartX.Size = new System.Drawing.Size(97, 21);
            this.nud_StartX.TabIndex = 18;
            this.nud_StartX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_StartY
            // 
            this.nud_StartY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.nud_StartY.DecimalPlaces = 1;
            this.nud_StartY.Enabled = false;
            this.nud_StartY.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_StartY.Location = new System.Drawing.Point(739, 27);
            this.nud_StartY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_StartY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_StartY.Name = "nud_StartY";
            this.nud_StartY.ReadOnly = true;
            this.nud_StartY.Size = new System.Drawing.Size(97, 21);
            this.nud_StartY.TabIndex = 26;
            this.nud_StartY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(735, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 15);
            this.label10.TabIndex = 17;
            this.label10.Text = "Tray Heiht";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(240, 421);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Tray Width";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(123, 421);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Dist. X";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(735, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 15);
            this.label8.TabIndex = 14;
            this.label8.Text = "Dist. Y";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(735, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Start Y";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 421);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "Start X";
            // 
            // btn_RegionSave
            // 
            this.btn_RegionSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_RegionSave.Location = new System.Drawing.Point(778, 428);
            this.btn_RegionSave.Name = "btn_RegionSave";
            this.btn_RegionSave.Size = new System.Drawing.Size(64, 50);
            this.btn_RegionSave.TabIndex = 11;
            this.btn_RegionSave.Text = "Save";
            this.btn_RegionSave.UseVisualStyleBackColor = true;
            this.btn_RegionSave.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(127, 459);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "+";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(13, 459);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "+";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(737, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "+";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(737, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "+";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // svDisplayView1
            // 
            this.svDisplayView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.svDisplayView1.Auto_Fit = true;
            this.svDisplayView1.AutoScroll = true;
            this.svDisplayView1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svDisplayView1.IsDisplayCenterLine = false;
            this.svDisplayView1.IsDisplayCoordinate = false;
            this.svDisplayView1.Location = new System.Drawing.Point(12, 12);
            this.svDisplayView1.Name = "svDisplayView1";
            this.svDisplayView1.Size = new System.Drawing.Size(717, 406);
            this.svDisplayView1.TabIndex = 6;
            this.svDisplayView1.ToastVisible = true;
            this.svDisplayView1.ZoomVisible = false;
            // 
            // btn_Run
            // 
            this.btn_Run.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Run.Location = new System.Drawing.Point(710, 428);
            this.btn_Run.Name = "btn_Run";
            this.btn_Run.Size = new System.Drawing.Size(64, 50);
            this.btn_Run.TabIndex = 11;
            this.btn_Run.Text = "Run";
            this.btn_Run.UseVisualStyleBackColor = true;
            this.btn_Run.Click += new System.EventHandler(this.btn_Run_Click);
            // 
            // dgv_Threshold
            // 
            this.dgv_Threshold.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_Threshold.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Threshold.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColIndex,
            this.ColThreshold});
            this.dgv_Threshold.Location = new System.Drawing.Point(5, 3);
            this.dgv_Threshold.Name = "dgv_Threshold";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.NullValue = null;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Threshold.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Threshold.RowHeadersVisible = false;
            this.dgv_Threshold.RowHeadersWidth = 25;
            dataGridViewCellStyle2.NullValue = null;
            this.dgv_Threshold.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Threshold.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Threshold.Size = new System.Drawing.Size(102, 113);
            this.dgv_Threshold.TabIndex = 28;
            this.dgv_Threshold.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Threshold_CellValueChanged);
            // 
            // ColIndex
            // 
            this.ColIndex.FillWeight = 50F;
            this.ColIndex.HeaderText = "No";
            this.ColIndex.Name = "ColIndex";
            this.ColIndex.ReadOnly = true;
            this.ColIndex.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColIndex.Width = 30;
            // 
            // ColThreshold
            // 
            this.ColThreshold.FillWeight = 300F;
            this.ColThreshold.HeaderText = "Judgement";
            this.ColThreshold.Name = "ColThreshold";
            this.ColThreshold.Width = 65;
            // 
            // btn_toolblock
            // 
            this.btn_toolblock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_toolblock.Location = new System.Drawing.Point(613, 428);
            this.btn_toolblock.Name = "btn_toolblock";
            this.btn_toolblock.Size = new System.Drawing.Size(91, 49);
            this.btn_toolblock.TabIndex = 29;
            this.btn_toolblock.Text = "Toolblock #1";
            this.btn_toolblock.UseVisualStyleBackColor = true;
            this.btn_toolblock.Click += new System.EventHandler(this.btn_toolblock_Click);
            // 
            // btn_SaveImage
            // 
            this.btn_SaveImage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SaveImage.Enabled = false;
            this.btn_SaveImage.Location = new System.Drawing.Point(453, 454);
            this.btn_SaveImage.Name = "btn_SaveImage";
            this.btn_SaveImage.Size = new System.Drawing.Size(53, 22);
            this.btn_SaveImage.TabIndex = 30;
            this.btn_SaveImage.Text = "Save Image";
            this.btn_SaveImage.UseVisualStyleBackColor = true;
            this.btn_SaveImage.Click += new System.EventHandler(this.btn_SaveImage_Click);
            // 
            // btn_EasySetting
            // 
            this.btn_EasySetting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_EasySetting.Location = new System.Drawing.Point(512, 429);
            this.btn_EasySetting.Name = "btn_EasySetting";
            this.btn_EasySetting.Size = new System.Drawing.Size(93, 47);
            this.btn_EasySetting.TabIndex = 31;
            this.btn_EasySetting.Text = "Easy Setting";
            this.btn_EasySetting.UseVisualStyleBackColor = true;
            this.btn_EasySetting.Click += new System.EventHandler(this.btn_EasySetting_Click);
            // 
            // btn_SetAll
            // 
            this.btn_SetAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SetAll.Location = new System.Drawing.Point(453, 429);
            this.btn_SetAll.Name = "btn_SetAll";
            this.btn_SetAll.Size = new System.Drawing.Size(53, 24);
            this.btn_SetAll.TabIndex = 32;
            this.btn_SetAll.Text = "Set All";
            this.btn_SetAll.UseVisualStyleBackColor = true;
            this.btn_SetAll.Click += new System.EventHandler(this.btn_SetAll_Click);
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(351, 421);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 15);
            this.label11.TabIndex = 33;
            this.label11.Text = "Blob Offset";
            // 
            // nud_ThresholdOffset
            // 
            this.nud_ThresholdOffset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_ThresholdOffset.Location = new System.Drawing.Point(354, 437);
            this.nud_ThresholdOffset.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_ThresholdOffset.Minimum = new decimal(new int[] {
            255,
            0,
            0,
            -2147483648});
            this.nud_ThresholdOffset.Name = "nud_ThresholdOffset";
            this.nud_ThresholdOffset.Size = new System.Drawing.Size(93, 21);
            this.nud_ThresholdOffset.TabIndex = 34;
            // 
            // btn_ThresholdOffset
            // 
            this.btn_ThresholdOffset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_ThresholdOffset.Location = new System.Drawing.Point(354, 459);
            this.btn_ThresholdOffset.Name = "btn_ThresholdOffset";
            this.btn_ThresholdOffset.Size = new System.Drawing.Size(93, 23);
            this.btn_ThresholdOffset.TabIndex = 35;
            this.btn_ThresholdOffset.Text = "Blob Set";
            this.btn_ThresholdOffset.UseVisualStyleBackColor = true;
            this.btn_ThresholdOffset.Click += new System.EventHandler(this.btn_ThresholdOffset_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(735, 176);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgv_Threshold_Range);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dgv_Threshold);
            this.splitContainer1.Size = new System.Drawing.Size(110, 242);
            this.splitContainer1.SplitterDistance = 119;
            this.splitContainer1.TabIndex = 39;
            // 
            // dgv_Threshold_Range
            // 
            this.dgv_Threshold_Range.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_Threshold_Range.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Threshold_Range.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgv_Threshold_Range.Location = new System.Drawing.Point(5, 3);
            this.dgv_Threshold_Range.Name = "dgv_Threshold_Range";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.NullValue = null;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Threshold_Range.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_Threshold_Range.RowHeadersVisible = false;
            this.dgv_Threshold_Range.RowHeadersWidth = 25;
            dataGridViewCellStyle4.NullValue = null;
            this.dgv_Threshold_Range.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgv_Threshold_Range.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Threshold_Range.Size = new System.Drawing.Size(102, 113);
            this.dgv_Threshold_Range.TabIndex = 36;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 50F;
            this.dataGridViewTextBoxColumn1.HeaderText = "No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn1.Width = 30;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 300F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Blob";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 65;
            // 
            // btn_calcBlobRange_A
            // 
            this.btn_calcBlobRange_A.Location = new System.Drawing.Point(16, 16);
            this.btn_calcBlobRange_A.Name = "btn_calcBlobRange_A";
            this.btn_calcBlobRange_A.Size = new System.Drawing.Size(82, 42);
            this.btn_calcBlobRange_A.TabIndex = 40;
            this.btn_calcBlobRange_A.Text = "① A Blob";
            this.btn_calcBlobRange_A.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_calcBlobRange_A.UseVisualStyleBackColor = true;
            this.btn_calcBlobRange_A.Visible = false;
            this.btn_calcBlobRange_A.Click += new System.EventHandler(this.btn_calcBlobRange_A_Click);
            // 
            // btn_calcBlobRange_B
            // 
            this.btn_calcBlobRange_B.Location = new System.Drawing.Point(16, 108);
            this.btn_calcBlobRange_B.Name = "btn_calcBlobRange_B";
            this.btn_calcBlobRange_B.Size = new System.Drawing.Size(82, 42);
            this.btn_calcBlobRange_B.TabIndex = 41;
            this.btn_calcBlobRange_B.Text = "③ B Blob";
            this.btn_calcBlobRange_B.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_calcBlobRange_B.UseVisualStyleBackColor = true;
            this.btn_calcBlobRange_B.Visible = false;
            this.btn_calcBlobRange_B.Click += new System.EventHandler(this.btn_calcBlobRange_B_Click);
            // 
            // btn_calcBlobRange
            // 
            this.btn_calcBlobRange.Location = new System.Drawing.Point(16, 154);
            this.btn_calcBlobRange.Name = "btn_calcBlobRange";
            this.btn_calcBlobRange.Size = new System.Drawing.Size(82, 42);
            this.btn_calcBlobRange.TabIndex = 42;
            this.btn_calcBlobRange.Text = "④ Result";
            this.btn_calcBlobRange.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_calcBlobRange.UseVisualStyleBackColor = true;
            this.btn_calcBlobRange.Visible = false;
            this.btn_calcBlobRange.Click += new System.EventHandler(this.btn_calcBlobRange_Click);
            // 
            // btn_grab_B
            // 
            this.btn_grab_B.Location = new System.Drawing.Point(16, 62);
            this.btn_grab_B.Name = "btn_grab_B";
            this.btn_grab_B.Size = new System.Drawing.Size(82, 42);
            this.btn_grab_B.TabIndex = 43;
            this.btn_grab_B.Text = "② B Grab";
            this.btn_grab_B.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_grab_B.UseVisualStyleBackColor = true;
            this.btn_grab_B.Visible = false;
            this.btn_grab_B.Click += new System.EventHandler(this.btn_grab_B_Click);
            // 
            // btn_calcJudgeThres_A
            // 
            this.btn_calcJudgeThres_A.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_calcJudgeThres_A.Location = new System.Drawing.Point(15, 234);
            this.btn_calcJudgeThres_A.Name = "btn_calcJudgeThres_A";
            this.btn_calcJudgeThres_A.Size = new System.Drawing.Size(82, 42);
            this.btn_calcJudgeThres_A.TabIndex = 44;
            this.btn_calcJudgeThres_A.Text = "① A Judge";
            this.btn_calcJudgeThres_A.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_calcJudgeThres_A.UseVisualStyleBackColor = true;
            this.btn_calcJudgeThres_A.Visible = false;
            this.btn_calcJudgeThres_A.Click += new System.EventHandler(this.btn_calcJudgeThres_A_Click);
            // 
            // btn_grab_judgeB
            // 
            this.btn_grab_judgeB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_grab_judgeB.Location = new System.Drawing.Point(16, 280);
            this.btn_grab_judgeB.Name = "btn_grab_judgeB";
            this.btn_grab_judgeB.Size = new System.Drawing.Size(82, 42);
            this.btn_grab_judgeB.TabIndex = 45;
            this.btn_grab_judgeB.Text = "② B Grab";
            this.btn_grab_judgeB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_grab_judgeB.UseVisualStyleBackColor = true;
            this.btn_grab_judgeB.Visible = false;
            this.btn_grab_judgeB.Click += new System.EventHandler(this.btn_grab_judgeB_Click);
            // 
            // btn_calcJudgeThres_B
            // 
            this.btn_calcJudgeThres_B.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_calcJudgeThres_B.Location = new System.Drawing.Point(16, 326);
            this.btn_calcJudgeThres_B.Name = "btn_calcJudgeThres_B";
            this.btn_calcJudgeThres_B.Size = new System.Drawing.Size(82, 42);
            this.btn_calcJudgeThres_B.TabIndex = 46;
            this.btn_calcJudgeThres_B.Text = "③ B Judge";
            this.btn_calcJudgeThres_B.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_calcJudgeThres_B.UseVisualStyleBackColor = true;
            this.btn_calcJudgeThres_B.Visible = false;
            this.btn_calcJudgeThres_B.Click += new System.EventHandler(this.btn_calcJudgeThres_B_Click);
            // 
            // btn_calcJudgeThres
            // 
            this.btn_calcJudgeThres.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_calcJudgeThres.Location = new System.Drawing.Point(16, 372);
            this.btn_calcJudgeThres.Name = "btn_calcJudgeThres";
            this.btn_calcJudgeThres.Size = new System.Drawing.Size(82, 42);
            this.btn_calcJudgeThres.TabIndex = 47;
            this.btn_calcJudgeThres.Text = "④ Result";
            this.btn_calcJudgeThres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_calcJudgeThres.UseVisualStyleBackColor = true;
            this.btn_calcJudgeThres.Visible = false;
            this.btn_calcJudgeThres.Click += new System.EventHandler(this.btn_calcJudgeThres_Click);
            // 
            // DataEdit_Tray_Total
            // 
            this.ClientSize = new System.Drawing.Size(848, 488);
            this.Controls.Add(this.btn_calcJudgeThres);
            this.Controls.Add(this.btn_calcJudgeThres_B);
            this.Controls.Add(this.btn_grab_judgeB);
            this.Controls.Add(this.btn_calcJudgeThres_A);
            this.Controls.Add(this.btn_grab_B);
            this.Controls.Add(this.btn_calcBlobRange);
            this.Controls.Add(this.btn_calcBlobRange_B);
            this.Controls.Add(this.btn_calcBlobRange_A);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.btn_ThresholdOffset);
            this.Controls.Add(this.nud_ThresholdOffset);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btn_SetAll);
            this.Controls.Add(this.btn_EasySetting);
            this.Controls.Add(this.btn_SaveImage);
            this.Controls.Add(this.btn_toolblock);
            this.Controls.Add(this.nud_DistX_add);
            this.Controls.Add(this.nud_TrayWidth);
            this.Controls.Add(this.nud_TrayHeight);
            this.Controls.Add(this.nud_DistY_add);
            this.Controls.Add(this.nud_StartX_add);
            this.Controls.Add(this.nud_StartY_add);
            this.Controls.Add(this.nud_DistX);
            this.Controls.Add(this.nud_DistY);
            this.Controls.Add(this.nud_StartX);
            this.Controls.Add(this.nud_StartY);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_Run);
            this.Controls.Add(this.btn_RegionSave);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.svDisplayView1);
            this.Name = "DataEdit_Tray_Total";
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TrayHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY_add)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_DistY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_StartY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Threshold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_ThresholdOffset)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Threshold_Range)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


    }
}
