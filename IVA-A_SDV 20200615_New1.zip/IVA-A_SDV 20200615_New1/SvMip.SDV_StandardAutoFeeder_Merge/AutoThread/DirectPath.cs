﻿using System;
using System.Collections.Generic;
using OpenCvSharp.CPlusPlus;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Thin wrapper kept for the AutoThread_Direct code; the logic (and the source syntax documentation)
    /// lives in SvMip.SvPathResolver.
    /// Specials (@align[i].x, @judge, @vision, @cellid, @recipe, @job, @time) are handled by AutoThread_Direct.
    /// </summary>
    internal static class DirectPath
    {
        public static SvToolBase FindTool(List<SvToolBase> tools, string name)
        {
            return SvPathResolver.FindTool(tools, name);
        }

        public static bool TryGetToolValue(List<SvToolBase> tools, string path, out object value, out string error)
        {
            return SvPathResolver.TryGetToolValue(tools, path, out value, out error);
        }

        public static bool TryToPoint3d(object o, out Point3d p)
        {
            return SvPathResolver.TryToPoint3d(o, out p);
        }

        public static bool TryToDouble(object o, out double d)
        {
            return SvPathResolver.TryToDouble(o, out d);
        }
    }
}
