﻿using System;
using System.Collections.Generic;
using System.IO;
using OpenCvSharp.CPlusPlus;
using SvMip.Calibration;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Calibration math for the tools that run inside a job (SvHandEye, SvMaster). Same calculation as the Teach screen
    /// (SvCalibration.CalcCalibrationMat, origin moved to the picture centre, rotation centre), without any robot control.
    /// </summary>
    public class SvCalibrationService : ISvCalibrationService
    {
        static readonly object sLock = new object();
        static readonly Dictionary<string, KeyValuePair<DateTime, SvCalibration>> sCache = new Dictionary<string, KeyValuePair<DateTime, SvCalibration>>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Makes the service available to the tools (called once at start-up).</summary>
        public static void Install()
        {
            if (SvRuntime.Service == null) SvRuntime.Service = new SvCalibrationService();
            SvRuntime.CalibrationFolder = Main.CalibPath;
        }

        static string PathOf(string file)
        {
            return SvRuntime.FullCalibrationPath(file);
        }

        static void Backup(string path)
        {
            try
            {
                if (!File.Exists(path)) return;
                string dir = Path.Combine(Path.GetDirectoryName(path), "Backup");
                Directory.CreateDirectory(dir);
                string name = Path.GetFileNameWithoutExtension(path) + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + Path.GetExtension(path);
                File.Copy(path, Path.Combine(dir, name), true);
            }
            catch (Exception) { }
        }

        public bool SolveLinear(string file, Point2d[] pixel, Point2d[] robot, int width, int height, bool originAtCenter, double maxAllowedError, out double maxError, out double meanError, out string message)
        {
            maxError = 0;
            meanError = 0;
            message = "";
            try
            {
                if (pixel == null || robot == null || pixel.Length != robot.Length || pixel.Length < 3) { message = "at least 3 point pairs are needed"; return false; }

                Point2d[] rb = (Point2d[])robot.Clone();
                SvCalibrationData data = new SvCalibrationData();
                data.Width = width;
                data.Height = height;
                data.RefPoint = (Point2d[])pixel.Clone();
                data.RobotPoint = rb;
                data.IsPossibleNonlinear = false;
                SvCalibration cal = new SvCalibration();
                cal.CalData = data;
                data.IsPossibleNonlinear = false;

                data.VtoRMat.Mat = cal.CalcCalibrationMat(data.RefPoint, data.RobotPoint);
                if (originAtCenter)
                {
                    Point2d rc = cal.VtoR_Linear(new Point2d(width / 2.0, height / 2.0));
                    for (int i = 0; i < rb.Length; i++) rb[i] -= rc;
                    data.VtoRMat.Mat = cal.CalcCalibrationMat(data.RefPoint, data.RobotPoint);
                }

                double sum = 0;
                for (int i = 0; i < rb.Length; i++)
                {
                    Point2d r = cal.VtoR_Linear(data.RefPoint[i]);
                    double e = Math.Sqrt((r.X - rb[i].X) * (r.X - rb[i].X) + (r.Y - rb[i].Y) * (r.Y - rb[i].Y));
                    if (e > maxError) maxError = e;
                    sum += e;
                }
                meanError = sum / rb.Length;

                if (maxAllowedError > 0 && maxError > maxAllowedError)
                {
                    message = string.Format("max error {0:F3} is above the limit {1:F3}; the file was not changed", maxError, maxAllowedError);
                    return false;
                }

                string path = PathOf(file);
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                Backup(path);
                if (!(new SvSerializer()).SaveCalibration(data, path)) { message = "cannot save " + path; return false; }
                lock (sLock) { sCache.Remove(path); }
                message = string.Format("saved {0} (points {1}, max error {2:F3}, mean {3:F3})", file, rb.Length, maxError, meanError);
                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return false;
            }
        }

        public bool SolveRotation(string file, List<Point3d> pixelPoints, double markShiftX, double markShiftY, out Point2d center, out string message)
        {
            center = new Point2d();
            message = "";
            try
            {
                string path = PathOf(file);
                if (!File.Exists(path)) { message = "calibration file '" + file + "' does not exist (run the translation calibration first)"; return false; }
                SvCalibration cal = new SvCalibration();
                cal.CalData = (new SvSerializer()).LoadCalibration(path);
                Point2d c = cal.VtoR(cal.FindRotationCenter(pixelPoints)) - new Point2d(markShiftX, markShiftY);
                cal.CalData.RotPoints = new List<Point3d>(pixelPoints);
                cal.CalData.RotCenter = c;
                Backup(path);
                if (!(new SvSerializer()).SaveCalibration(cal.CalData, path)) { message = "cannot save " + path; return false; }
                lock (sLock) { sCache.Remove(path); }
                center = c;
                message = string.Format("rotation centre ({0:F3}, {1:F3}) saved in {2}", c.X, c.Y, file);
                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return false;
            }
        }

        public bool PixelToRobot(string file, Point3d pixel, out Point3d robot, out string message)
        {
            robot = new Point3d();
            message = "";
            try
            {
                string path = PathOf(file);
                if (!File.Exists(path)) { message = "calibration file '" + file + "' does not exist"; return false; }
                DateTime stamp = File.GetLastWriteTime(path);
                SvCalibration cal = null;
                lock (sLock)
                {
                    KeyValuePair<DateTime, SvCalibration> kv;
                    if (sCache.TryGetValue(path, out kv) && kv.Key == stamp) cal = kv.Value;
                }
                if (cal == null)
                {
                    cal = new SvCalibration();
                    cal.CalData = (new SvSerializer()).LoadCalibration(path);
                    lock (sLock) { sCache[path] = new KeyValuePair<DateTime, SvCalibration>(stamp, cal); }
                }
                robot = cal.VtoR(pixel, true, true);
                robot.Z = AlignMath.NormalizeTheta(robot.Z);
                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return false;
            }
        }
    }
}
