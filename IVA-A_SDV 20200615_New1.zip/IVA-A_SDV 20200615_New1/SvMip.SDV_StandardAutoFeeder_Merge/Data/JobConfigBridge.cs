﻿using System;
using System.Collections.Generic;
using System.Text;
#if PLCIF
using SvMip.Interface.MXCom;
#endif

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Lets a job carry its own process setup. When a job contains SvTrigger / SvConnection tools,
    /// their values are applied (in memory only) onto the SystemData process entry before the
    /// interfaces and AutoThreads are created, so the existing IO / robot code runs unchanged.
    /// Jobs without these tools are left completely untouched.
    /// The Common process (model change channel) always stays system-defined.
    /// </summary>
    public static class JobConfigBridge
    {
        public const string DirectThreadName = "AutoThread_Direct";

        class Baseline
        {
            public string ThreadName;
            public Main.IOtype IOtype;
            public Main.RobotType Robottype;
            public string IPAddress;
            public Dictionary<string, int> Inputs;
            public Dictionary<string, int> Outputs;
            public int OffsetStartAddress;
            public int InspectStartAddress;
            public int CellIDAddress;
            public int FDCStartAddress;
            public EJudgeType JudgeType;
            public bool UseAcqComp;
            public bool InspReverse;
        }

        static readonly object mLock = new object();
        static SystemData mSysRef;
        static readonly Dictionary<ProcessData, Baseline> mBaselines = new Dictionary<ProcessData, Baseline>();
        static int mStation;
        static int mPort;
        static int mIoSleep;
#if PLCIF
        static EDeviceType mDevice;
#endif
        static string mLastSignature;
        static bool mAutoStart;
        static readonly List<string> mInfo = new List<string>();

        /// <summary>True when a loaded job asked (SvTrigger.AutoStart) for Auto to start after saving.</summary>
        public static bool AutoStartRequested { get { return mAutoStart; } }

        /// <summary>Short description of the process setups taken from jobs during the last Apply.</summary>
        public static List<string> LastInfo { get { return new List<string>(mInfo); } }

        /// <summary>
        /// Applies the job settings of the loaded recipe onto the system data.
        /// Returns true when the connection related settings differ from the previous call
        /// (the caller must then re-create the interfaces).
        /// </summary>
        public static bool Apply(SystemData sys, RecipeData recipe, List<string> messages)
        {
            if (sys == null || recipe == null) return false;
            if (messages == null) messages = new List<string>();

            lock (mLock)
            {
                if (!object.ReferenceEquals(sys, mSysRef))
                {
                    CaptureBaseline(sys);
                    mSysRef = sys;
                    mLastSignature = null;
                }
                RestoreBaseline(sys);
                mAutoStart = false;
                mInfo.Clear();

                foreach (KeyValuePair<Main.Process, RecipeParam> kv in recipe.DicProcess)
                {
                    Main.Process proc = kv.Key;
                    if (proc == Main.Process.Common) continue;
                    ProcessData pd;
                    if (!sys.DicProcess.TryGetValue(proc, out pd) || !pd.Use) continue;
                    SvJob job = kv.Value.Job;
                    if (job == null) continue;

                    List<SvToolBase> tools = new List<SvToolBase>();
                    Collect(job, tools, 0);

                    SvTrigger trigger = null;
                    List<SvConnection> conns = new List<SvConnection>();
                    foreach (SvToolBase t in tools)
                    {
                        SvTrigger tr = t as SvTrigger;
                        if (tr != null)
                        {
                            if (trigger == null) trigger = tr;
                            else messages.Add(string.Format("[{0}] more than one SvTrigger in the job, the first one is used", pd.Name));
                            continue;
                        }
                        SvConnection cn = t as SvConnection;
                        if (cn != null) conns.Add(cn);
                    }
                    if (trigger == null && conns.Count == 0) continue; // legacy job: untouched

                    bool robotFromJob = false;
                    foreach (SvConnection cn in conns)
                    {
                        if (ApplyConnection(sys, pd, cn, messages)) robotFromJob = true;
                    }
                    if (trigger != null)
                    {
                        ApplyTrigger(sys, pd, trigger, robotFromJob, messages);
                        if (trigger.AutoStart) mAutoStart = true;
                    }
                    mInfo.Add(string.Format("[{0}] setup from job: thread={1}, IO={2}, robot={3}, ip={4}", pd.Name, pd.ThreadName, pd.IOParam.IOtype, pd.RobotParam.Robottype, pd.RobotParam.IPAddress));
                }

                string sig = BuildSignature(sys);
                bool changed = (sig != mLastSignature);
                mLastSignature = sig;
                return changed;
            }
        }

        /// <summary>
        /// Puts the original (system) values back into the system data. Call it before the system data is saved
        /// to its file, so that values taken from a job (kept in memory only) are never written to the file;
        /// call Apply again afterwards.
        /// </summary>
        public static void RestoreOverrides(SystemData sys)
        {
            if (sys == null) return;
            lock (mLock)
            {
                if (!object.ReferenceEquals(sys, mSysRef)) return;
                RestoreBaseline(sys);
            }
        }

        /// <summary>Names of the processes whose loaded job carries SvTrigger / SvConnection (i.e. is configured by the job).</summary>
        public static List<string> GetJobDrivenProcesses(RecipeData recipe)
        {
            List<string> result = new List<string>();
            if (recipe == null) return result;
            foreach (KeyValuePair<Main.Process, RecipeParam> kv in recipe.DicProcess)
            {
                if (kv.Key == Main.Process.Common) continue;
                SvJob job = kv.Value.Job;
                if (job == null) continue;
                List<SvToolBase> tools = new List<SvToolBase>();
                Collect(job, tools, 0);
                foreach (SvToolBase t in tools)
                {
                    if (t is SvTrigger || t is SvConnection)
                    {
                        result.Add(kv.Key.ToString());
                        break;
                    }
                }
            }
            return result;
        }

        public static void Collect(SvJob job, List<SvToolBase> acc, int depth)
        {
            if (job == null || depth > 8) return;
            foreach (SvToolBase t in job.ToolList)
            {
                acc.Add(t);
                SvToolBlock block = t as SvToolBlock;
                if (block != null) Collect(block.ToolJob, acc, depth + 1);
            }
        }

        static void CaptureBaseline(SystemData sys)
        {
            mBaselines.Clear();
            foreach (KeyValuePair<Main.Process, ProcessData> kv in sys.DicProcess)
            {
                if (kv.Key == Main.Process.Common) continue;
                ProcessData pd = kv.Value;
                Baseline b = new Baseline();
                b.ThreadName = pd.ThreadName;
                b.IOtype = pd.IOParam.IOtype;
                b.Robottype = pd.RobotParam.Robottype;
                b.IPAddress = pd.RobotParam.IPAddress;
                b.Inputs = (pd.IOParam.Inputs != null) ? new Dictionary<string, int>(pd.IOParam.Inputs) : null;
                b.Outputs = (pd.IOParam.Outputs != null) ? new Dictionary<string, int>(pd.IOParam.Outputs) : null;
                b.OffsetStartAddress = pd.RobotParam.OffsetStartAddress;
                b.InspectStartAddress = pd.RobotParam.InspectStartAddress;
                b.CellIDAddress = pd.RobotParam.CellIDAddress;
                b.FDCStartAddress = pd.RobotParam.FDCStartAddress;
                b.JudgeType = pd.JudgeType;
                b.UseAcqComp = pd.UseAcqComp;
                b.InspReverse = pd.InspReverse;
                mBaselines[pd] = b;
            }
            mStation = sys.StationNumber;
            mPort = sys.PortNumber;
            mIoSleep = sys.IOThreadSleep;
#if PLCIF
            mDevice = sys.DeviceType;
#endif
        }

        static void RestoreBaseline(SystemData sys)
        {
            foreach (KeyValuePair<ProcessData, Baseline> kv in mBaselines)
            {
                ProcessData pd = kv.Key;
                Baseline b = kv.Value;
                pd.ThreadName = b.ThreadName;
                pd.IOParam.IOtype = b.IOtype;
                pd.RobotParam.Robottype = b.Robottype;
                pd.RobotParam.IPAddress = b.IPAddress;
                // in place, other objects keep references to these dictionaries
                if (b.Inputs != null && pd.IOParam.Inputs != null)
                {
                    pd.IOParam.Inputs.Clear();
                    foreach (KeyValuePair<string, int> e in b.Inputs) pd.IOParam.Inputs[e.Key] = e.Value;
                }
                if (b.Outputs != null && pd.IOParam.Outputs != null)
                {
                    pd.IOParam.Outputs.Clear();
                    foreach (KeyValuePair<string, int> e in b.Outputs) pd.IOParam.Outputs[e.Key] = e.Value;
                }
                pd.RobotParam.OffsetStartAddress = b.OffsetStartAddress;
                pd.RobotParam.InspectStartAddress = b.InspectStartAddress;
                pd.RobotParam.CellIDAddress = b.CellIDAddress;
                pd.RobotParam.FDCStartAddress = b.FDCStartAddress;
                pd.JudgeType = b.JudgeType;
                pd.UseAcqComp = b.UseAcqComp;
                pd.InspReverse = b.InspReverse;
            }
            sys.StationNumber = mStation;
            sys.PortNumber = mPort;
            sys.IOThreadSleep = mIoSleep;
#if PLCIF
            sys.DeviceType = mDevice;
#endif
        }

        static void ApplyTrigger(SystemData sys, ProcessData pd, SvTrigger t, bool robotFromJob, List<string> messages)
        {
            string problem = t.Validate();
            if (problem != "")
                messages.Add(string.Format("[{0}] SvTrigger: {1}", pd.Name, problem));

            if (pd.IOParam.Inputs == null) pd.IOParam.Inputs = new Dictionary<string, int>();
            if (pd.IOParam.Outputs == null) pd.IOParam.Outputs = new Dictionary<string, int>();
            if (t.TriggerMode == SvTriggerMode.Tcp)
            {
                // The cycle is started by a message: the process gets its own in-memory IO with fixed internal
                // addresses, AutoThread_Direct sets Start / Complete on it and the usual handshake runs unchanged.
                pd.IOParam.IOtype = Main.IOtype.Virtual;
                pd.IOParam.Inputs["Start"] = 0;
                pd.IOParam.Inputs["Complete"] = 1;
                pd.IOParam.Outputs["Ready"] = 2;
                pd.IOParam.Outputs["AcqComp"] = 3;
                pd.IOParam.Outputs["OK"] = 4;
                pd.IOParam.Outputs["NG"] = 5;
                pd.IOParam.Outputs["OK2"] = 6;
                pd.IOParam.Outputs["NG2"] = 7;
                pd.IOParam.Outputs["InspNG"] = 8;
                pd.IOParam.Outputs["InspNG2"] = 9;

                // without a robot / PLC connection of its own, the process shares the one of the Common process
                // (no new device is created for it)
                ProcessData common;
                if (!robotFromJob && sys.DicProcess.TryGetValue(Main.Process.Common, out common))
                {
                    pd.RobotParam.Robottype = common.RobotParam.Robottype;
                    pd.RobotParam.IPAddress = common.RobotParam.IPAddress;
                }
            }
            else
            {
                pd.IOParam.Inputs["Start"] = t.StartAddr;
                pd.IOParam.Inputs["Complete"] = t.CompleteAddr;
                pd.IOParam.Outputs["Ready"] = t.ReadyAddr;
                pd.IOParam.Outputs["AcqComp"] = t.AcqCompAddr;
                pd.IOParam.Outputs["OK"] = t.OkAddr;
                pd.IOParam.Outputs["NG"] = t.NgAddr;
                pd.IOParam.Outputs["OK2"] = t.Ok2Addr;
                pd.IOParam.Outputs["NG2"] = t.Ng2Addr;
                pd.IOParam.Outputs["InspNG"] = t.InspNgAddr;
                pd.IOParam.Outputs["InspNG2"] = t.InspNg2Addr;
            }

            pd.RobotParam.OffsetStartAddress = t.OffsetStartAddress;
            pd.RobotParam.InspectStartAddress = t.InspectStartAddress;
            pd.RobotParam.CellIDAddress = t.CellIdAddress;
            pd.RobotParam.FDCStartAddress = t.FdcStartAddress;

            pd.JudgeType = t.DualJudge ? EJudgeType.Dual : EJudgeType.Single;
            pd.UseAcqComp = t.UseAcqComp;
            pd.InspReverse = t.InspReverse;
            pd.ThreadName = DirectThreadName;
        }

        /// <summary>Returns true when the connection set the robot / PLC type of the process.</summary>
        static bool ApplyConnection(SystemData sys, ProcessData pd, SvConnection c, List<string> messages)
        {
            string problem = c.Validate();
            if (problem != "")
                messages.Add(string.Format("[{0}] SvConnection '{1}': {2}", pd.Name, c.ConnName, problem));

            if (SvConnection.IsStreamType(c.ConnType)) return false; // TCP / UDP / Serial / Modbus are used by SvSend channels and the Tcp trigger only

            bool forIO = (c.ConnRole != SvConnRole.Robot);
            bool forRobot = (c.ConnRole != SvConnRole.IO);
            bool robotMapped = false;

            if (!string.IsNullOrEmpty(c.Host)) pd.RobotParam.IPAddress = c.Host;

            if (forIO)
            {
                Main.IOtype io;
                if (TryMapIO(c.ConnType, out io)) pd.IOParam.IOtype = io;
                else if (c.ConnRole == SvConnRole.IO)
                    messages.Add(string.Format("[{0}] SvConnection '{1}': {2} cannot be used as IO", pd.Name, c.ConnName, c.ConnType));
            }
            if (forRobot)
            {
                Main.RobotType rb;
                if (TryMapRobot(c.ConnType, out rb))
                {
                    pd.RobotParam.Robottype = rb;
                    robotMapped = true;
                }
                else if (c.ConnRole == SvConnRole.Robot)
                    messages.Add(string.Format("[{0}] SvConnection '{1}': {2} cannot be used as Robot", pd.Name, c.ConnName, c.ConnType));
            }

            // settings shared by the whole program (first job that sets them wins; later ones overwrite and are reported)
            if (c.Port >= 0) sys.PortNumber = c.Port;
            if (c.StationNumber >= 0) sys.StationNumber = c.StationNumber;
            if (c.IoThreadSleep >= 0) sys.IOThreadSleep = c.IoThreadSleep;
#if PLCIF
            if (c.DeviceType >= 0) sys.DeviceType = (EDeviceType)c.DeviceType;
#endif
            return robotMapped;
        }

        static bool TryMapIO(SvConnType t, out Main.IOtype io)
        {
            switch (t)
            {
                case SvConnType.MxCom: io = Main.IOtype.MxCom; return true;
                case SvConnType.OpcUa: io = Main.IOtype.Opc; return true;
                case SvConnType.Msg: io = Main.IOtype.Msg; return true;
                case SvConnType.SocketClient: io = Main.IOtype.Socket_Client; return true;
                case SvConnType.YoiDio: io = Main.IOtype.Yoi_DIO; return true;
                case SvConnType.NxeDio: io = Main.IOtype.DIO; return true;
            }
            io = Main.IOtype.DIO;
            return false;
        }

        static bool TryMapRobot(SvConnType t, out Main.RobotType rb)
        {
            switch (t)
            {
                case SvConnType.MxCom: rb = Main.RobotType.MxCom; return true;
                case SvConnType.OpcUa: rb = Main.RobotType.Opc; return true;
                case SvConnType.Msg: rb = Main.RobotType.Msg; return true;
                case SvConnType.SocketClient: rb = Main.RobotType.Socket_Client; return true;
                case SvConnType.RobostarSerial: rb = Main.RobotType.Robostar_Serial; return true;
            }
            rb = Main.RobotType.MxCom;
            return false;
        }

        static string BuildSignature(SystemData sys)
        {
            StringBuilder sb = new StringBuilder();
            List<Main.Process> keys = new List<Main.Process>(sys.DicProcess.Keys);
            keys.Sort();
            foreach (Main.Process k in keys)
            {
                if (k == Main.Process.Common) continue;
                ProcessData pd = sys.DicProcess[k];
                sb.Append(k).Append('|').Append(pd.Use).Append('|').Append(pd.ThreadName).Append('|')
                  .Append(pd.IOParam.IOtype).Append('|').Append(pd.RobotParam.Robottype).Append('|')
                  .Append(pd.RobotParam.IPAddress).Append('|')
                  .Append(pd.RobotParam.OffsetStartAddress).Append(',').Append(pd.RobotParam.InspectStartAddress).Append(',')
                  .Append(pd.RobotParam.CellIDAddress).Append(',').Append(pd.RobotParam.FDCStartAddress).Append('|')
                  .Append(pd.JudgeType).Append(pd.UseAcqComp).Append(pd.InspReverse).Append('|');
                AppendDictionary(sb, pd.IOParam.Inputs);
                AppendDictionary(sb, pd.IOParam.Outputs);
                sb.Append(';');
            }
            sb.Append(sys.StationNumber).Append(',').Append(sys.PortNumber).Append(',').Append(sys.IOThreadSleep);
#if PLCIF
            sb.Append(',').Append(sys.DeviceType);
#endif
            return sb.ToString();
        }

        static void AppendDictionary(StringBuilder sb, Dictionary<string, int> d)
        {
            if (d == null)
            {
                sb.Append("|");
                return;
            }
            List<string> names = new List<string>(d.Keys);
            names.Sort(StringComparer.Ordinal);
            foreach (string n in names)
                sb.Append(n).Append('=').Append(d[n]).Append(',');
            sb.Append('|');
        }
    }
}
