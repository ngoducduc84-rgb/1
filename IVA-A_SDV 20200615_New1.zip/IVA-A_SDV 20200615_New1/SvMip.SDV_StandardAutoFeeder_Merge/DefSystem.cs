﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public class DefSystem
    {
        internal const int DEF_MAX_LOAD_LOG = 10;
    }

    public static class History
    {
        static History()
        {
            InitMajor();
            InitMinor();
            InitModify();
        }

        public static string Version
        {
            get { return string.Format("{0}. {1}. {2}", Major, Minor, Modify); }
        }
        /// <summary>
        /// Platform 변경
        /// 개별 버전 - 1, 통합 버전 - 2
        /// </summary>
        private static int Major { get; set; }
        /// <summary>
        /// 핵심 구조 변경
        /// AutoThread_base
        /// </summary>
        private static int Minor { get; set; }
        /// <summary>
        /// 기능 추가
        /// </summary>
        private static int Modify { get; set; }

        private static void InitMajor()
        {
            Major = 2;//통합버전
        }

        private static void InitMinor()
        {
            Minor = 0;
            // 초기버전
            Minor = 1;
            // 통신 이슈, 멀티 block 적용,, 기타 디버깅 처리 다수 (2018/03/01 ~ 
        }

        private static void InitModify()
        {
            Modify = 171119;/* ~ 20171119 */
            Modify = 171120;
            /* 수정 : khoon
            * Manual Align 기능 보완
            *  - Theta normalizing
            *  - point간 연결선, 각도 변경 추가
            *  - AutoThread_Panel 패널 유무 기능 활성화 : 패널 체크 후 없으면 매뉴얼 창 띄우지 않음
            * History version 적용
            */
            Modify = 171121;
            /* 수정 : khoon
            * Manual Align 기능 보완
            *  - NG 상태에서 Confirm 했을 때 OK 판정 주는 부분 수정
            */
            Modify = 171122;
            /* 수정 : khoon
             * Loading position 생성자 오류 수정
             * Manual align : Center ellipes 추가
             * Model change 디버깅
             * Histogram thresholds 편집창 추가
             */
            Modify = 171123;
            /* 수정 : khoon
             * 매뉴얼 창 자동 닫힘 : PLC Complete 신호 연동
             * TACT 디스플레이 변경 : 누적 시간 
             * Autothread base : sleep 조정 100ms -> 5ms
             */
            Modify = 171128;
            /* 수정 : khoon
             * MXComponent : Stop 버튼 누를 때, heartbeat stop하도록 수정
             */
            Modify = 171129;
            /* 수정 : khoon
             * Auto.xaml.cs : InitInterface, IO buffer 만드는 부분에 OPCallBit 영역 포함시킴. 
             * (opcall bit가 update 영역에 포함되지 않으면 버퍼 사이즈가 작게 생성되어 out of bound 예외 발생함)
             */
            Modify = 171201;
            /* 수정 : khoon
             * Auto.xaml.cs : 메인 제어기 레시피 리스트와 비전 레시피 리스트 동일하게 초기화 시킴
             * 기존에 없던 레시피일 경우 레시피 폴더 & 빈 레시피 데이타 파일 생성 -> 사용자가 데이타 설정해야 함
             */
            Modify = 171203;
            /* 수정 : khoon
             * Main.cs : 프로그램 시작 시 로그파일 롤오버 동작 스킵 -> 런 중에 롤오버함
             * AutoThread_Tray_Nopanel : 패널 유무검사 사용시 비전잡 실패하면 바로 NG 처리함
             */
            Modify = 171205;
            /* 수정 : khoon
             * Autothread_base : Ready 비트 처리 수정, req 대기시 계속 On, Thread stop에 Off
             * SvToolBlockTreeView : Tool block에서 라인 이상하게 그어지는 현상 조치 -> genaso
             * AutoThread_Tray_NoPanel : 패널 유무 검사 (templetematching 실패하면 NG 처리 : 포켓 비어있는 지 확인하여 셀 있으면 알람)            
             * */
            Modify = 171207;
            /* 수정 : khoon
             * EOTech Interface 추가 : Robot_EOTech
             * WPS : Position Block 써 주는 소켓 함수 (인덱스 = 포지션 데이타 갯수)
             * RVS : String 읽어 오는 소켓 함수 (인덱스 1 = 현재 레시피, 2 = 레시피 리스트(';'로 조인할 것)         
             * */
            Modify = 171208;
            /* 수정 : genaso
             * Core, Edit 수정 : toolblocktreeview 오류 수정
             */
            Modify = 171209;
            /* 수정 : genaso
             * toolblocktreeview 11/22 버전으로 Reverting
             */
            Modify = 171211;
            /* 수정 : khoon
             * SvHistogram threshold 추가, 삭제 버튼 삭제 : 수정만 가능하게 함
             * mxcom : readcurrentrecipe, recipelist - binary값이 아스키 범위(0~127)인지 체크
             * Autothread_Panel_NoMove 추가 : cp loader 개조건
             * system process data에 InspectType 추가 : Judgement - OK, NG처리 , Mapping : tray pocket별 패널 유무 (판정은 무조건 OK)
             */
            Modify = 171213;
            /* 수정 : khoon
             * Thread_Base : Judge NG일때 포지션 초기화하는 코드 주석처리 -> Do_Judgement내에서 Judge별로 초기화 코드와 중복됨
             * 본사 서버로 통합
             */
            Modify = 171214;
            /* 수정 : khoon
             * Auto.xaml.cs : Recipe data update 안되는 문제 - "Test" 값으로만 적용됨
             * Auto화면 전환 시 현재 Recipe명 읽어오는 구문 제거 -> Robot 통신이 끊어져 있어 Test로만 로딩되는 현상
             * Recipe 읽어오는 위치 : Auto 화면 생성할 때, 모델체인지 할 때
             * Data화면 Loading 될 때 현재 레시피명 선택되어 있도록 수정함.
             */
            Modify = 17121401;
            /* 수정 : khoon
             * Limit 데이타 저장안되는 부분 디버깅 -> 초기값은 +- 100, 100, 5값으로 설정됨, 적용시 데이타 확인 필요함
             * HW Trigger Delay(nDelay) -> Delay(nDelay*2)로 변경 (IMI Sample Code 참고)
             */
            Modify = 171219;
            /* 수정 : Ko, sihong
             * OPC, Massage, Socket_server, Socket_Client추가
             * Auto.xaml에 Interface 추가 된 부분 추가하였고 Server로 시작시 Client 접속 기다리는 코드 추가
             */
            Modify = 171227;
            /* 수정 : ASH
             * Camera 위치 수정 : SvMip.Interface → SvMip
             */
            Modify = 171230;
            /* 수정 : Ko
             * QR code Reading을 위한 SvBarcode Tool 추가
             * SvTemplateMatch에 Rotatin Degree OutputParam 추가
             * SVRotation에 InputParam 추가 및 Image Region Rect 변경
             * SvMip.Interface.OPC의 OpenCvsharp.Dll 설정 위치 변경
             * SvJob RunBeforeTool(SvToolbase tool) 함수 추가 → Tray 쪽 Auto Thread를 Toolblock 이전 한번 Run() 후 Toolblock만 n회 돌리는걸로...
             * JobEdit에서 Run()시 각 tool별 성공여부 표시안되는 버그(마우스가 영역내 들어가야 표시) 수정
             * */
            Modify = 180104;
            /* 수정 : hozzang
             * Tray_Insp_NoPanel 추가
             * SDD 법인 FOD Buffer용으로 개발
             * Tray Align & 자재유무 판단 동시 진행
             * */
            Modify = 180113;
            /* 수정 : hozzang
             * Tray NG시 Tray Align Data Reset 없앰 (기존 Data 그대로...)
             * Tray_Insp_NoPanel_DualREgion 추가
             * Region 2개 사용시 적용 (1, 2열 Tray Pocket Center To Center 상이 또는 제품 언로딩 포지션 대칭형상 Like V1 OQC)
             * */
            Modify = 180129;
            /* 수정 : khoon
             * Barcode thread : display rectangle 변경 -> QR 코드와 같이 회전하게 (templete matching box)
             * Data 추가 : camera parameter(focallength, sensorwidth, sensorheight),  Tray size
             * recipe loading 완료 후 Auto 화면 활성화 되도록,,,,(로딩 전 Start button 작동하면 난감하니까..)
             * */
            Modify = 180130;
            /* 수정 : hozzang
             * Tray_Insp_NoPanel_DualREgion 수정
             * Region Count_X, Count_Y 갯수에 따른 Data Tab Tray Edit JOB 수정 적용
             **/
            Modify = 180131;
            /* 수정 : ASH
             * IO 배열에서 Dictionary<int, bool>로 변경
             * MxCom IO 사용 Test 완료
             * Robostar Serial socket 변경
			 * Tray2Robot Warpping 추가(Tray 기울어짐, 높이 대응)
             * */
            Modify = 180201;
            /* 수정 : HOZZANG
             * 동관 + 베트남 + 국내 MERGE
             * DualRegion Debugging 中
             * Tray No Panel 첫 실행시 NG 발생 (안책임 확인 필요)
             * */
            Modify = 18020500;
            /* 수정 : khoon
             * mx com 커넥션 체크 수정 : plc 읽어오기 -> 속성만 가져오기
             * EO Tech 캘리브레이션(티칭)에 추가
             * */
            Modify = 180206;
            /* 수정 : ASH             
             * [Data, Auto] 수동 Model Change 추가
             * [Data] Loading Position 구할때 기존잡도 사용할 수 있도록 수정
             *   svWarpping 없이 가능, 기준 각도 그대로 유지
             * [Data] Tray Offset 조절할때 Region 선택할 수 있도록 button 추가
             * [Auto] Menu 이동 실패할 경우 버튼 활성화 원복
             * [AutoThread] mAlignResult.JobInfo 구조 List로 변경
             *   mLingnResult.JobInfo[0] : mJob (toolblock1, toolblock2, ... 포함) 
             *   mLingnResult.JobInfo[1] : toolblock[1] Jobinfo
             *   mLingnResult.JobInfo[0] : toolblock[2] Jobinfo
             *   변경사유 : toolblock 바깥에서 region을 사용할 경우가 종종 발생하는데 region을 사용하면 순서가 다 밀림...
            * */
            Modify = 18021000;
            /* 수정 : khoon
             * camera parameter : 프로세스별로 입력/저장하도록 수정
             * nachi socket : 연결/해제 조건 테스팅 - disconnect 제거 ----------- EO 인터페이스 1차 수정
             */
            Modify = 18021001;
            /* 수정 : khoon
             * nachi socket : 연결/해제 조건 테스팅 ----------- EO 인터페이스 2차 수정
             * robot_eotech : override 함수 구현
             */
            Modify = 180212;
            /* 수정 : khoon
             * plc 연결체크 부하가 너무 커서 결과값 writing 못하는 현상 처리
             * robot_mxcom_abs : IsConnected 속성 참조값 변경 ( read func --> mIsConnected 속성 )
             * mIsConnected 속성은 heartbeat tick에서 업데이트함
             * 오토 쓰레드 term 조정 : autothread_base - 50ms, modelchange - 500ms, heartbeat - 5000ms
             */
            Modify = 180214;
            /* 수정 : khoon
             * V1 BPL 적용 버전 : MXCOM 사용 Calibration 
             * Teaching 화면 로봇 선택에 MXCOM 추가 
             * MXCOM Cal명령어 인덱스에 StartAddress 합산하도록 수정
             * Panel_Nomove 쓰레드 수정 : Align 값을 연산 후 참조 쓰레드의 Align 연산 호출, WriteResult에서는 참조 쓰레드의 결과값 써주기.... 디버깅필요_ASH 
             */
            Modify = 180216;
            /* 수정 : khoon
             * connect check function : read --> write 적용
             * 검사설비 통신 끊어짐/지연 관련 조치 : Write 실패 후 재 시도 전 Sleep(500) 추가 적용
             * heart beat Write 실패하면 재 시도 해보구 Reopen() 호출
             */
            Modify = 18021601;
            /* 수정 : khoon
             * eo portnumber sys  data에서 참조
             * modelchange error시 bit reset, comp bit  reset 하도록
             */
            Modify = 18021602;
            /* 수정 : khoon
             * read recipe 와 read current recipe 사이에 sleep 100 적용
             */
            Modify = 180219;
            /* 수정 : ASH
             * [SvMip] Fixture, TemplateMatch Scale 적용
             *    기존: original scale로 찾은 후 DFS 이용 X,Y scale 따로 추적(잘못 찾는 경우가 많아서...)
             *    변경: 걍 찾을때부터 무식하게 (대신 X,Y scale 동일값으로)
             * [SvMip] TemplateMatch Region 범위내에서만 tight하게 검색
             * [SvMip] Region내에서만 찾도록 Tight 하게 수정
             * [SvMip] Warpping에서 InputImage의 Layout을 outParam["OutLayoutPLine"]으로 내보내기 
             * [AuthThread]AutoThread_Tray內 calculate 및 WritePosition 함수를 AutoThread_Panel에서 사용하도록 수정
             */

            Modify = 180221;
            /* 수정 : khoon
             * tray size check 기능 적용 
             *  - 셋업 후 설비별로 측정되는 사이즈에 맞게 Tray Width, Height, Tolerance 설정 필요함(Calibration 상태에 따라 측정값 차이 발생함)
             *  - Findline 오인식 시 Alarm 처리를 위함 ...
             * set histo base 버튼 추가 : inspection histo 사용 시 기준(Base)값 Histo Tool에 있는 Threshold 리스트에 등록하기
             * Autothread_tray 수정 내용
             *  - Do_Judgement : Vision NG, Tray Size NG 시에 Send point는 전부 0,0,0으로 초기화해준다
             *                   Limit check는 해당 Point만 0,0,0으로 초기화함
             *                   패널 유무 판정은 OK/NG와 관계없이 처리해서 결과값 써줌... 당연히 NG 일때는 참고하면 안되겠지만
             * 그리고 일부 Interface NG인데 Judgement OK로 보내는 부분 &연산처리 추가함
             * Auto.xaml.cs 에 모델체인지 순서에서 recipelist읽어오고 현재 recipe읽어오는 사이에 sleep(500)적용 : EO Tech에서 연속 요청 처리 안되서 ㅠㅜ
             */

            Modify = 180222;
            /* 수정 : HOZZANG
             * 메시지 박스 영문표기로 변경
             * MakeRect & FindLine NG 로그 추가
             */

            Modify = 180223;
            /* 수정 : khoon
             * Loading insp debugging
             */

            Modify = 180226;
            /* 수정 : HOZZANG
             * [AutoThread_Loading_Insp / Tray]
             *  -자재 판단 유무 판단 기능 Debugging : Multi Block 적용
             *  -Image Converter 사용시 OutputImage = SvImageConverter.OuputImage 사용 적용
             * [AUtoThread_Base]
             *  -Rectangle / FindeLine NG 발생시 발생 원인 Log 표기 (사각형 각도, 길이 등)
             * [MainFrame]
             *  -PreviewKeyDown 함수 제외 : Esc 버튼 누를 경우 종료 메시지창 발생으로....
             */

            Modify = 180301;
            /* 수정 : khoon
             * recipe create, delete 기능 추가
             * threadbase checktool(templetematching) 처리 조건 수정 : 
             *  tray 유무검사에서 templete 사용한 경우는 스코어만 추가하고 true 처리하도록 함 -> do_judgement에서 최종 처리함
             * loadinspection에서 histogram에서 mean 갯수보다 index가 높은값 들어오면 메시지 띄우고 false처리 -> histo tool에 있는 threshold 갯수 안 맞음
             */

            Modify = 180302;
            /* 수정 : HOZZANG
             * DataEdit_TrayOffsets
             * Multi Block 사용시 Region 영역이 바뀌지 않는 현상 개선
             * Region 버튼 클릭시 다음 ToolBlock Region 호출
             */
            Modify = 180307;
            /* 수정 : HOZZANG
             * Autothread_ImageSave 쓰레드 추가 : V1 AMT에서 요청함
             */
            Modify = 180308;
            /* 수정 : sihong
             * Lioadingposition Log 추가
             */

            Modify = 180316;
            /* 수정 : 안책임님
             * MakeRectFromLine툴이 Tray 외곽이 아닌 내부로 잡을 경우 
             * Tray point가 MakeRectFromLine툴의 포인트가 
             * 아닌 warping 툴의 OutLayoutPLine으로 부터 가져오도록 수정
             */

            Modify = 180322;
            /* 수정 : hozzang
             * Load_Inspection 버그 수정 (판정결과 업데이트시 Index 중첩)
             * 1번 Pocket 기준 Reference를 설정하여 허용 Tolerence 초과시 Vision NG 발생 _ Test 용
             * Auto Stop시 Common Ready Bit Off
             */

            Modify = 180326;
            /* 수정 : taejun
             * Alive signal 추가 
             *  - 함수 설명 (thread 처리): 1초 간격으로 Alive bit on/off 진행             
             */

            Modify = 180401;
            /* 수정 : ASH
             * [AutoThread] AutoThread_Tray_Insp_AfterUnloading 추가
             *  - Panel Unloading 후 안착검사 Thread 추가 
             * [AutoThread] ModelChange Debugging
             *  - ModelChange후 JobInfo 누락 개선
             *  - ModelChange후 ManualAlign 창 안뜨는 현상 개선
             * [SvMip] SvJudgement, SvJudgementEdit 추가
             *  - AutoThread_Tray_Insp_AfterUnloading 결과 처리를 위한 Tool 추가
             * [SvMip] 구조 변경
             *  - 각 Tool내 있던 GetOutPram(), NotifyRan()을 Tool 외부 SvJob으로 변경
             *  - Display 좌표변환 수정
             *    . 기존: System.Form에 있는 변환은 Affine만 적용됨
             *    . 변경: Perspective 변환을 위해 좌표계 직접 계산
             */

            Modify = 180417;
            /* 수정 : ASH
             * [SvMip] InteractiveObject 구조 변경
             *  - InteractDrawObject를 Interface → abstrac class로 변경
             *  - Affine → Perspective 변경
             * [SvMip] Tool 개선
             *  - Blob 속도 개선
             *  - FindLine 이미지 외곽선도 선으로 인식하는 bug 개선
             */

            Modify = 180418;
            /* 수정 : taejun
             * [Auto] Execute EndAuto
             *  - Kill process when terminated unexpectedly
             * [AutoThread_Tray_Insp_AfterUnloading] Save tray image
             *  - Save only unless have all panels or nothing
             */


            Modify = 180423;
            /* 수정 : ASH
             * [SvCommon.SvLogger] Display Image 저장 추가
             * [Data] Recipe New/Copy/Delete 추가
             * 
             * 수정 : taejun
             * [AutoThread] Tray_Insp_AfterUnloading 개선
             *  - Data Form에 Editor 창 추가
             *    . Normal Image Save
             *    . Region Modify
             *    . Multi-Judgement 값 등록
             */

            Modify = 18042302;
            /* 수정 : Hozzang
             * Tape Inspection 관련 결과 Job 변경 및 Current Cal Data 이용 판정결과 전송
             * Tape Inspection NG 발생시 판전결과 I/O로 전송 (OK시 Panel Align 판정 OK 적용)
             * OPC Reconnect 및 Heart Beat Thread 추가
             * Panel Manualalign 기능 추가 적용
             */

            Modify = 180430;
            /* 수정 : taejun
             * [AutoThread] AutoThread_TrayInt 추가
             *  - Tray align(Tray와 Tray_NoPanel 통합) + 검사(유무/안착)
             *    . 보정량은 mRobotWriteAddress부터 저장
             *    . 검사 결과는 mRobotWriteAddress+100부터 저장
             */

            Modify = 180502;
            /* 수정 : Hozzang
             * Tape Inspection 관련 결과 Job 변경 및 Current Cal Data 이용 판정결과 전송
             * Tape Inspection NG 발생시 판전결과 I/O로 전송 (OK시 Panel Align 판정 OK 적용)
             * OPC Reconnect 및 Heart Beat Thread 추가
             * Panel Manualalign 기능 추가 적용
             */

            Modify = 180504;
            /* 수정 : ASH
             * Camera Interface 분리 : SvMip → SvMip.CameraDevice
             *  - 목적 : Camera interface를 법인에서 맘대로 추가할 수 있도록...
             * AutoThread_TrayInt → AutoThread_Tray_Total로 이름 변경
             *  - Int가 좀 약해 보여서... 변경했고, DataEdit도 DataEdit_Tray_Total로 통일
             */

            Modify = 180515;
            /* 수정 : Hozzang
             * [AutoThread] AutoThread_Base DisplayResultImage()
             * 자재유무 + Offset 사용시 Warpping NG(Warpping Image가 없을때
             * mAlignResult.ResultImage의 inputImage가 없게 되어 Exception 발생 현상 개선
             * (Warrping Image가 없을때 maalignResult.InputImage 변경
             * [AutoThread] AutoThread_Tray Do_InitJob()
             * 기존 Historam / Teamplate 사용시 Initjob False 개선
             * [AutoThread] AutoThread_Tray_Total Do_Judgement()
             * Tray Size Check는 Align Part로 이동
             * 기존 Histo/Temp 자재유무 기능 사용시 Index 부여 기준 변경
             * DataView.xaml "Tray Offset Interlock" 화면 삭제
             * [SvJudgement] Creteria 수정
             * [AutoThread] Tray_Insp_AfterUnloading / Tray_Total Judgement, Mapping 기능 적용
             * [SvLogger] Display Image 저장 파일 속성 변경 (png → jpg)
             */

            Modify = 180522;
            /* 수정 : Hozzang
             * [AutoThread] AutoThread_Base Check Limit 상세 Log 추가
             */

            Modify = 180528;
            /* 수정 : sihong
             * [IO_Ethernet_Server] 미사용으로 변경, 주석처리
             * [IO_Ethernet_Client] 미사용으로 변경, 주석처리
             * [Robot_Ethernet_Server] 미사용으로 변경, 주석처리
             * [Robot_Ethernet_Client] 미사용으로 변경, 주석처리
             * [AsyncSocket] 미사용으로 변경, 주석처리
             * 기존[IO_Robot_Nachi] -> [IO_Ethernet_Client] 변경
             * 기존[RobotNachi] -> [Robot_Ethernet_Client] 변경 : 기존 RobotNachi에서 WritePositions 함수 변경 및 Robot_EOTech에 있던 StartCalibration 의 Thread.Sleep 반영
             * 기존[Robot_EOTech] -> [RobotNachi] 로 변경 : Robot_Ethernet_Client상속 받아 WritePositions 함수만 overriding 함.
             * Calibration Robot combobox [EOTech] -> [Ethernet_Client] 변경
             * Main-RobotType, IOtype의 불필요 항목(Nachi, Socket_Server, EOTech) 제거
             * Auto.xaml 수정 : 상기내용 반영
             * AutoThread_Total : Judgement mapping시 Align Judgement의 결과로만 OK/NG 판정할수 있도록 수정
             * AutoThread_Total : Align없이 패널유무 검사만 할 시 WriteRevOffset으로 position 쓰는부분 패스할수 있도록 수정
             * EO설비, V3 G-PJT AMT 설비 업데이트시 참고([Robot_EOTech] -> [RobotNachi], [IO_Robot_Nachi] -> [IO_Ethernet_Client])
             * AutoThread_Total에서 Align data 송부시 index 계산 방식 변경 : lastPos = ((lastPos / 100) + 1) * 100; -> lastPos = mRobotWriteAddress + 100;
             * 변경전으론 계산 오류 발생 예) startaddress = 312이면 Align data는 400번지부터 써짐
             */

            Modify = 180606;
            /* 수정 : HOZZANG
             * [SystemData] Diplay Image 저장일수 저장 수정
             * [Tray_Total] Judgement 기능 사용 버그 수정
             */

            Modify = 180608;
            /* 수정 : sihong
             * [Robot_MXCom_AbsAddress] MXCom 이용 Calibration 진행 시 StartCalibration의 Robot Initial 완료 check 기능 추가
             */
            Modify = 180612;
            /* 수정 : sihong
             * [AutoTread_Tray_Total] Inspection type이 judgement일때 판정기준 수정
             * [SvJudgementEdit] Judgement UI에서 개별 threshold 제거 및 변경안되는 문제 해결
			 */

            Modify = 180616;
            /* 수정 : ASH
             * [SvMip.Display]
             *  1. Mouse 이동시 하기 Statusbar에 표기되는 좌표계 추가(Fixtue, Calibration, Pixel)
             *  2. 중앙에 CenterLine 언제나 표시할 수 있도록 변경
             * [SvMip.Tools]
             *  1. SvLine InputImage에 따른 표기 오류 수정 (Property에서 받을때 항상 InputImage 좌표계로 변경해서 사용하도록 수정)
             * [SvMip.Core] 
             *  1. Link 끌고가면 Link의 Source 끌고가는것과 동일한 효과...
             * [SvMip.Calibration] 
             *  1. 1Axis Calibration, 2Cam Calibratio 추가
             * [AutoThread]
             *  1. SystemData 위치 조절, 저장 폴더 선택할수 있도록 변경(Recipe는 메뉴얼로 변경할 것!!)
             *  2. AutoThreadViewEdit 결과표시 Toolblock별로 수정
             *  3. DisplayImage 저장 옵션 Process별 저장 및 저장폴더 분리
             */

            Modify = 180627;
            /* 수정 : ASH
             * [AutoThread]
             *  1. Robot_Socket_Clientd의 key는 IP로 수정
             *  2. Log 표시 개선
             */

            Modify = 180630;
            /* 수정 : ASH
             * [AutoThread]
             *  1. Log 표시 개선 추가(색깔, 정리/추가)
             */

            Modify = 180705;
            /* 수정 : sihong
             * [AutoThread_Base]
             *  1. 화면표시 결과값 추가
             * [AutoThread_View]
             *  1. Sequence Log tab 추가
             * [AutoThread_Total]
             *  1. Do_WriteJudgement() 주석처리 : Process에서 판정결과(OK/NG) 표기 안되는 문제가 있어서 주석처리
             */

            Modify = 180709;
            /* 수정 : sihong
             * [AutoThread_Base]
             *  1. 기존 sequence Log로 통합사용에서 DataLog분리
             * [AutoThread_View]
             *  1. Sequence Log data column 단위로 분리
             */

            Modify = 180711;
            /* 수정 : ASH
             * [SvMip]
             *  1. SvBlob AreaRate[OutputParam] 추가
             *  2. SvJudgement InputImage 추가, Binding 이상한거 수정(자꾸 원복되는 느낌...)
             * [AutoThread_Base]
             *  1. Display Image 우선순위 변경
                 - 기존 : Judge前 Tool의 InputImage
                 - 변경 : Judgement InputImage → Region InputImage → Judge前 Tool의 InputImage
             *  2. 에러이미지가 자동으로 표시되도록 수정
             *  3. RobotType에서 ABB,Nachi 제외 → Socket_Client로 통합
             */

            Modify = 180723;
            /* 수정 : ASH
             * [SvMip]
             *  1. Region에 Fixture 적용
             * [AutoThread_Base]
             *  1. AutoThread_Panel_Total 추가
             *  2. Code 정리
             *  3. 반복작업 제거
             * [AutoThread_Panel_Total] 추가
             *  1. Panel 검사 후 StartAdd +10W 에 OffsetData Write (Tray +100W)
             */

            Modify = 180725;
            /* 수정 : HOZZANG
             * [AutoThread_Tray]
             *  1. Align DisplayImage 저장 추가
             *  2. FocalLength != 0 일때 Tray2Robot Warpping 수정
             * [AutoThread_Tray_Total]
             *  1. FocalLength != 0 일때 Tray2Robot Warpping 수정
             * [SvMip.Common.SvLogger]
             *  1. 원본 Image Process별로 구분 저장
             * [SystemData]
             *  1. MessageLog 저장은 Common Process 단일화
             *     (Common에서만 MessageLog 저장일 변경)
             */

            Modify = 180727;
            /* 수정 : ASH
             * [SvMip]
             *  1. Region에 SubImage 오류 수정
             */

            Modify = 180728;
            /* 수정 : HOZZANG
             * [AutoThread_Base]
             *  1. CheckTool(SvJudgement judge, int displayindex = 0)
             *    - Tray_Total 판정결과 중복표기로 수정
             *    - Region Height가 InputImage Height와 동일할때 Display Skip
             */

            Modify = 180730;
            /* 수정 : HOZZANG
             * [AutoThread_Panel]
             *  1. Align Display Image 저장 추가
             */

            Modify = 180731;
            /* 수정 : ASH
             * [AutoThread_Base]
             *  1. AutoThread_Panel_Start_Target.cs 추가
             *    - 한번의 Grab에서 Start, Target Point 모두 나오는 경우
             *    - Target Point가 고정인 경우
             *  [SvMip.Tools]
             *  1. SvMasking : Degugging
             *    - if (Mask != ImageSize) : 예외처리
             *    - if (Mask == null) : 생성
             *    - OnMask(색칠/지우기), OnDraw(Mask에 선긋는모드/안선긋는모드), IsDisplay(Mask 투명으로 표시/안표시) 구분
             *  2. SvFixture : InputPoint [inparam]에 추가
             *  [SvMip.Object]
             *  1. svRectangle, svRotationRectangle, svEllipse, svMask 좌표변환 적용
             */

            Modify = 180801;
            /* 수정 : sihong
             * [AutoThread_Base][AutoThread_View]
             * Object Point, Target Point Log 추가
             * Log 1 sequence End 표시
             */

            Modify = 180806;
            /* 수정 : LTK
             * [SvFindLineEdit][SvFindLine]
             * Number of Ignore -> Percentage of Ignore 변경              
             */

            Modify = 180807;
            /* 수정 : HOZZANG
             * [AutoThread_PANEL_Insp] 중복 코드 삭제
             * [AutoThread_Base] Do_Inspection 삭제
             * [AutoThread_Panel_Total] 라벨검사(Judge) 판정은 설비에서 판정하는 것으로 프로그램 적용
             *                          판넬 저지먼트 사용 목적은 메뉴얼 얼라인 기능을 패스하기 위해 적용
             */

            Modify = 180809;
            /* 수정 : HOZZANG
             * [AutoThread_Base] ImageSave() 위치 변경
             * 기존 Judgement에서 이미지 저장시 이미지 놓침 발생
             * Complete 완료후 이미지 저장
             */

            Modify = 180814;
            /* 수정 : HOZZANG
             * [AutoThread_Tray_Total] Warpping Input Image Null시 프로그램 튕김 현상 개선
             * [AutoThread_Tray_Base] Image Save Try/Catch문으로 변경
             * [AutoThread_Panel] Panel 유/무 판정 버그 수정
             */

            Modify = 180829;
            /* 수정 : ASH
             * 
             */

            Modify = 180904;
            /* 수정 : LTK
             * [SvFindLineEdit/SvFindLine] Ignore number/percentage 선택 기능 추가
             *                             Use Number Of Calipers 추가 (Masking 포함하여 실제로 사용하는 Caliper 개수 표현)
             */


            Modify = 180916;
            /* 수정 : khoon
             * WriteResult 참조 Address 분리 : InspectAddress, OffsetAddress ※ panel_total과 tray_total만 적용함
             * cell id address 추가 : Panel관련 thread 에서만 cell id 읽어 옴
             * 이미지/로그 저장할 때 File명에 CellID 정보 넣기 
             * 오토화면 그룹박스 헤더 : ThreadName → JobName 변경 적용
             * 화면 최소화 이벤트 추가 : 타이틀 로고 더블클릭
             */

            Modify = 180918;
            /* 수정 : HOZZANG
             * [AutoThread_Tray_Total][AutoThread_Panel_Total] MakrPoint Result Image 삭제 
             * [IO_MXCompent] Thread Scan Time 0.05 → 0.1초 변경
             * [AutoThread_Base] CheckVisionJob() 
             * Template과 MakePoint가 없는 조건(Judgement)일 경우 Judgement.Inputimage에 TemplateMatching 결과 표기
             */

            Modify = 180919;
            /* 수정 : tj
             * * [AutoThread_Panel_FilmInsp]  Do_Inspection, do_initJob 수정
             * - read film insp spec from plc when restart (do_initJob)
             *   : plc memory addr is fixed(D43050~D43057)
             * - Added film theta data (Do_Inspection)
             * - Added minimize button
             * - Added cellID 
             * - Merged this version into newer version 
             * * */

            Modify = 180928;
            /* 수정 : tj
             * * [AutoThread_Panel_FilmInsp]  Do_Inspection, do_initJob 수정
             * - SaveInspNGImage 함수추가 (IsJudgeOK가 inspection 결과를 참조하지 않는 상황이라 base class의 SaveImage 함수를 사용하기 어려운 상황이라 별도 함수 추가)
             * - Inspection Fail시 UI상에 표시
             * - Do_Inspection try catch 적용
             * - insp result ui 를 acq img 쪽으로 이동
             * * */

            Modify = 180924;
            /* 수정 : hong
             * V2 RTP Unloader용 Panel_NoCal 추가
             * Calibration resolution 계산은 MakerectformLine에서의 width, height를 실 거리 기준으로 변환하여 resolution 계산
             */

            Modify = 181018;
            /* 수정 : hong
             * IO thread sleep data 추가
             * MXCom exception Log 삭제(특정 Log 생성시 PG 느려짐 발생)
             */

            Modify = 181024;
            /* 수정 : HOZZANG
             * [AutoThread_Tray_Total][AutoThread_Panel_Total]
             *  - WriteResult() Try / Catch 구문 추가 (Panel_NoPanel 사용시 Tray 먼저 찰상하지 않고 Panel 찰상 時 Judgement 결과값이 없어 Excpetion 발생)
             * [AutoThread_Panel] Do_ExecuteAlignCalc_NoMove()
             *  - Offset Data 반영 (LoadPosition 영역 이용)
             *  [AutoThread_Tray_Total]
             *  - FDC Write 추가 (Bolb 기준값, Judgement 판정 기준값)
             *  [Save Image 기능 추가]
             *  - Auto Display 창에서 우측 마우스 클릭시 Save Image Tool 추가
             *  - 저장된 이미지는 Iamge 폴더내 CHCEK(기존 Retry 폴더) 폴더에 저장
             */

            Modify = 181030;
            /* 수정 : HOZZANG
             * [AutoThread_Tray_Total]
             *  - FDC Write 버그 수정 (V3 라미공정 요청사항)
             *    . Judgement 기준값 1word, Pocket 별 Blob 기준값 1word (Max 8Pocket)
             *      → Blob 別 기준값 다르게 가지고 갈 수 있도록 수정 필요
             *  - Sendal Data Reverse Check 기능 추가 (V2 추가 요청사항)
             * [AutoThread_Tray]
             *  - Pokcet 간 Distance Interlock 추가
             *    . Pocket 간 거리를 key In으로 받고 tolerence에서 벗어나면 NG
             * [AutoThread_Base]
             *  - mAlignResult.InputImage = acq.AcqusitionImage; 는 Display Inex = 0일때만 저장
             */

            Modify = 181105;
            /* 수정 : HOZZANG
             * [Sv_Mip_Blob]
             *  - Blob 기준 Threshold(Range) 개별 입력 추가
             * [AutoThread_Tray_Total]
             *  - Manual Inspection 기능 추가
             */

            Modify = 181108;
            /* 수정 : HOZZANG
             * V2 IOC 연결 UDP 통신 프로그램 추가
             *  - Form -> UDP Client 추가
             *  - Data Tab에서 IOC Room IP/Port 입력, Vision PC IP 입력 추가 
             * [SvRegionEdit]
             *  - DistX = 0으로 바인딩 되는 현상 조치 (임시) → 근본적인 원인 파악 필요
             */

            Modify = 181111;
            /* 수정 : ASH
             * Camera Parameter 추가 준비(Exposure Time은 아직 못넣고 있음...)
             * Film Inspection Display 수정
             */

            Modify = 181115;
            /* 수정 : JTJ
             * 1. Data log 별도 저장 (폴더명은 JobFile명,기존 로그는 유지)
               2. RootPath D drive 저장되도록 수정
             */

            Modify = 181127;
            /* 수정 : HOZZANG
             * Judge 결과 Log 별도 저장 수정 (Align 값과 동일하게.) Data 별도 저장 폴더 자동 삭제 기능 추가 필요
             * Log 종류별(Judge/Align) 및 Process별 구분 저장(폴더명은 Process명으로 변경)
             * Data Log 형식 수정
             * Data Log 별도 저장 수정 ( Log 종류(Judge/Align) / Process 별 구분 저장)
             * FilmInspection 결과값 표기를 절대값 → 실수 값으로 표기 변경
             */

            Modify = 181201;
            /* 수정 : HOZZANG
             * [AutoThread_Panel_FilmInsp] Tape 검사 Display 표기 변경 / T축 Display 제외
             */

            Modify = 181203;
            /* 수정 : TKL
             * [FindLineTool] Percentage of Ignore 기능 복구
             * 
             * 수정 : Hong
             * 1. FindLine Tool Priority에 Position 기반 추가
             */

            Modify = 181206;
            /* 수정 : TKL, Hong
             * [FindLineTool] Line 중심 잡아서 이동 기능 추가
             */

            Modify = 181207;
            /* 수정 : HOZZANG
             * [AutoThread_Panel_FilmInsp]
             *  1. Log 저장시 CellID 추가
             *  2. Film 검출방법 변경 (Distance → 자재유무)
             * Iamge Save 이름 변경 (기존 : CellID + 날짜 → 날짜 + CellID)
             * SvImageCalculate & SvSerializer 메모리 Dispose 추가
             * [FindLine] Result 결과값 방향 변경_ASH
             */

            Modify = 181213;
            /* 수정 : HOZZANG
             * [AutoThread_Panel_FilmInsp]
             *  1. Align OK Image 저장 않되던 문제 조치
             */

            Modify = 181215;
            /* 수정 : khoon
             * [AutoThread_Panel_FilmInsp]
             * 카메라 익셉션 처리
             * writejudge exception 처리
             */

            Modify = 181217;
            /* 수정 : khoon
             * [AutoThread_Base]
             * try...catch 적용
             */

            Modify = 181219;
            /* 수정 : khoon
             * Auto 화면 Vision Result Message 추가
             * 
             * 수정 : Hong
             * Blob RectSize, RectWidth, RectHeight Result 추가 (Segmentation tab에 Calculate Blob check 박스 check 되었을때에 한함)
             * Blob Max Count 기능 추가 : 찾은 blob data 중에 우선 순이 count 갯수에 따른 결과값 반영 (Segmentation tab에 Calculate Blob check 박스 check 되었을때에 한함)
             * Blob Output Parameter 추가 : RectLengthSum(Max count 기준 RectWidth + RectHeight 값), RectAreaSum(Max count 기준 RectSize) 추가
             */

            Modify = 181221;
            /* 수정 : hozzang
             * [AutoThread_Tray_Total]
             * 1. Manual 판정 유/무를 Log 파라미터로 추가 (1 : Manual Check, 2: Auto)
             * [SvDisplayView]
             * 1. Auto Display 배율 유지
             */

            Modify = 181222;
            /* 수정 : ash
             * image 저장시 메모리 잠식 개선 : svlogger.cs (clone -> 원본) 
             */

            Modify = 181224;
            /* 수정 : khoon
             * svblob debugging : dispose 시점 변경 
             * 비전 리트라이 기능 추가 : data에서 설정, ng일 경우 ready step으로 보내서 다시 한 번 process 진행함
             */

            Modify = 181224;
            /* 수정 : TKL, hozzang
             * [Blob]
             * 1. Region 영역 변경에 따른 Histogram 변경
             * [SvDisplayViewStatusBar]
             * 1. Auto_Fit Check Box 추가
             * 2. Check Box 체크 여부에 따라서 Display Image FitWindow 실행
             */

            Modify = 181225;
            /* 수정 : ash, khoon
             * updateDisplay 오류 수정 : InputImage dispose 추가
             * Retry 기능 보완.. 
             */

            Modify = 181227;
            /* 수정 : ash, JTJ
             * [DataEdit_Tray_Total]_Blob Setting 간소화
             * 1. DataEdit창에서 Blob binary threshold 관리토록 적용
             * 2. threshold => Histogram mean value + Offset
             */

            Modify = 181229;
            /* 수정 : JTJ
             * 1. [AutoThread_Panel_FilmInsp] : Film distance 측정 제거 및 Job 정리
             * 2. BlobEdit : dgv_Range 값 갱신 조건 오류 수정
             * 3. DataEdit_Tray_Total : Toolblock button click 예외처리
             */

            Modify = 181231;
            /* 수정 : hozzang
             * 1. [SvDisplayView] : Zoom Image 처리방식 변경
             */

            Modify = 181231;
            /* 수정 : TKL
             * [SvToolBlockTreeView] TreeView에서 ToolBlock에 Parameter Drag&Drop 시 Input 생성 후 연결
             */

            Modify = 190104;
            /* 수정 : TKL / hozzang
             * [AutoThread_Panel] NoMove 사용시 AlignOffset 적용 제거
             * [AutoThread_Tray_Total] 보정치 계산시 AlignOffset 적용 (Data sheet Offset 항목 OK(X),OK(Y),OK(T) 적용)
             * [RecipeData] Tray1,2 Data sheet에서 Offset 입력 가능하도록 수정
             * [AutoTrhead_Base] Manual Start시 판정 결과 확인 1초 후 자동으로 eStatus.Complete 변경
             */

            Modify = 190108;
            /* 수정 : hozzang
             * [SvDisplayView] 최소화시 적용된 FitWinodw 주석처리
             * [AuttoThread_Base] CheckTool(Judge) Judgement Image 사라짐 현상 개선
             */

            Modify = 190110;
            /* 수정 : JTJ
             * [DataEdit_Tray_Total],[SvBlobEdit],[SvJudgementEdit]
                 : DataEdit창에서 Blob range와 Judgement creteria의 대표값 설정 가능토록 수정 (대표값 TextEditor창과 DataGrid 첫번째행 동기화함)
            */

            Modify = 190111;
            /* 수정 : hozzang
             * [AuttoThread_FilmInspection] C-Grip 부착 Tape 검사 로그 추가
             */

            Modify = 190115;
            /* 수정 : hozzang
             * [AuttoThread_Tray_Total] Tray Align Display Image 저장 추가
             */

            Modify = 190118;
            /* 수정 : JTJ
             * [MainFrame],[DataView],[SystemData] Eqp name,number display 추가
             */

            Modify = 190123;
            /* 수정 : JTJ
             * [AutoThread_Tray_Total] Data Log에 M-Check Result 추가 (Manual check 이후 최종 판정 결과, 모두 OK일때만 1)
             */

            Modify = 190124;
            /* 수정 : JTJ
             * [DataEdit_Tray_Total] Blob, Judge threshold EasySetting 기능 추가
             */

            Modify = 190218;
            /* 수정 : hozzang
             * [SvMip_Tools] Tool InputImage Dispose 적용_Vision Tab에서 Job 실행 후 메모리 삭제
             * [DataEdit_Tray_Total] Blob Offset Setting Disable 처리
             * [DataView] Align_Skip CheckBox Disable 처리
             */

            Modify = 190222;
            /* 수정 : TKL
             * [FindParallelLine] Normal,GuideLine,Parallel,Vertical Type 선택 사용 추가
             * Normal : FindLine과 동일
             * Parallel,Vertical : Ref Line과 평행/수직으로 각도 고정 후 Line Searching
             * GuideLine : Caliper Line과 평행으로 각도 고정 후 Line Searching
             */

            Modify = 190312;
            /* 수정 : hozzang
             * [AutoThread_Base] mAlignResult.IsVisionOK == false시 WriteJudgement NG로 변경
             * [SvAcquisition] Image Grab fail시 Camera Close 후 Camera 재오픈 추가 (V2 Test 필요함)
             * [Camera] Close 함수 추가 (ASH)
             * [Auto] Job / Thread Dispose 적용
             * Camera 이벤트 중복현상 개선 (LKH)
             */

            Modify = 190315;
            /* 수정 : ASH
             * [GigE_Basler] Camera Opne시 Lock 추가
             */

            Modify = 190318;
            /* 수정 : ASH
             * Camera Retry 추가
             */

            Modify = 190320;
            /* 수정 : hong
             * [MXComponent] IsOpen 내부 변수를 이용해서 mxCom.Close시 IsOpen일 상태일때만 하도록...이게 없으면 Close 상태에서 무한 루프로 연결 안됨
             * Model Change Exception Log(추후 삭제)
             * AutoThread Base Tact관련 Log 추가(추후 삭제)
             */

            Modify = 190322;
            /* 수정 : hong
             * [SvImageCalculate] Abs 처리 부활시킴
             */

            Modify = 190328;
            /* 수정 : hozzang
             * [SvBlob] Bolb Count 추가 (Double 형)
             * [SvImageConverterEdit] Contrast / Brightness Key In 적용
             */
            Modify = 190402;
            /* 수정 : hong
             * [IO_Ethernet] IO Write 실시간에서 on time으로 변경
             * [IO_MxCom] IO Write 실시간에서 on time으로 변경
             */

            Modify = 190423;
            /* 수정 : TKL 
             * [SvAcquisition] Grab Retry 추가
             * [GigE_Basler] Grab error 시 exception log 남기도록 수정, Timeout 설정              
             */

            Modify = 190425;
            /* 수정 : TKL 
             * [GigE_Basler] grabResult Dispose 추가
             */

            Modify = 190426;
            /* 수정 : hozzang
             * GigE_Basler : Image Dispose() 추가
             * 모델 Change시 메모리 증가 개선
             *  - [Auto] Auto Start 시 JobDispose추가 (Vision Tab에서 실행후 Dipose 없음)
             *  - [AutoThread_Base] ResultImage.List Clear 추가
             */

            Modify = 190430;
            /* 수정 : TKL, hong
             * BitData 써주는 방법 수정, 100ms 마다 전체 outIO write → 필요시 특정 outIO write.
             * Do_CheckVisionJob 비동기 수행으로 수정
             * [SvAcquisition] Image 사용시 한번 loading 한후 계속 사용하도록 수정
             * [AutoThread_Base] Start 시 loading 된 이미지 초기화 추가 
             * [AutoThread_Tray_Total_JetSol] Toolblock 병렬연산 하도록 수정
             */

            Modify = 190508;
            /* 수정 : TKL
             * [GigE_Basler] Grab Retry 수정, Disconnection 시 재연결, Data 처리 위치 수정
             * [MXComponent] Open 시 Retry 추가, Write 시 Retry 추가
             * [Auto] ModelChange Thread에 5초마다 전체 Bit 써주도록 추가
             * [IO_MXComponent] 불필요한 lock 제거
             * [Robot_MXCom_AbsAddress] PLC 연결 확인하는 Thread 제거
             */

            Modify = 190509;
            /* 수정 : TKL, hong
             * [SvAcquisition] Dispose 시 isLoaded false 변경 추가
             */

            Modify = 190510;
            /* 수정 : TKL
             * [SvBlob] regionImage Dispose 위치 수정
             */

            Modify = 190521;
            /* 수정 : TKL
             * [GigE_Basler] Software Trigger Mode로 수정
             */

            Modify = 190522;
            /* 수정 : TKL
             * [SvLogger] Directory Delete 비동기 / 한개씩 지우도록 수정
             */

            Modify = 190524;
            /* 수정 : khoon, TKL
             * [GigE_Basler] Camera 촬상시마다 Open / Close 진행하도록 수정
             */

            Modify = 190624;
            /* 수정 : TKL
             * [SvLogger] 폴더 없으면 만들고 저장하는 코드 위치 수정
             * [GigE_Basler] Grabbing 상태 확인 부활
             */
            Modify = 190628;
            /* 수정 : hong
             * [AutoThread_Base]Check tool morphology 추가
             * [SvBlob] Image Dispose 함수 추가
             */

            Modify = 190702;
            /* 수정 : TKL
             * [SvLogger] Save 설정 JPG 저장으로 변경 
             */
            Modify = 190703;
            /* 수정 : hong
             * [AutoThread_View]UpdateDisplay() Exception 발생 시 Log 방식 변경 (변경 사유 : UI-Auto-Log창에 장문의 빈칸 발생)
             */

            Modify = 190722;
            /* 수정 : hong
             * Yoi_DIO 추가
             */

            Modify = 190806;
            /* 수정 : HOZZANG
             * [AutoThread_Panel] Panel_NoMove Process 진행시 Process Log 창에 Panel Align Log 표기
             */

            Modify = 190814;
            /* 수정 : HOZZANG
             * [GigE_Basler] Camera Live View 기능 수정 적용
             * But [Thread was being aborted] 팦업창 생성
             * [AutoThread_Base] CheckTool(SvJudgement judge, int displayindex = 0) 함수 내
             * display.DrawString(sJudge, font08, brush, inputimage.RegionRectFPts[0]); 주석처리 (어디서 사용하는지 잘 모르겠음....)
             * 주석처리 이유는 Judgement Display시 Region 및 결과값 중첩되어서....
             */

            Modify = 190820;
            /* 수정 : HOZZANG
             * [DataEdit_Tray_Total] Easy Setting Judgement 항목중 Blob 결과값을 받을때 
             *                       각 포켓별 개별 세팅된 Blob Threshold 값 적용하도록 수정 (기존 1st 세팅값으로 Judge 판정)
             */

            Modify = 190906;
            /* 수정 : HOZZANG
             * [DataEdit_Tray_Total] 190820 버전 버그 수정 (Blob 설정값이 1개일때 Exception 되는현상 개선)
             */
            Modify = 191028;
            /* 수정 : hong
             * Acquisition Exposure Time Setting 관련 추가 - 현재 DLL SDV V2 Vision 담당자에게 전달(Hoa pro)
             */

            Modify = 191104;
            /* 수정 : ASH
             * ObjectSave, ObjectLoad Tool 추가 - V2 Vision 담당자 요청사항 (HOA 프로)
             * TemplateMatching Edge(?) 기능 추가
             */

            Modify = 191111;
            /* 수정 : HOZZANG
             * TemplateMatching Angle 소숫점 반영
             * TemplateMatching Score 음수 생성시 0으로 반영
             * ImageConvert Scrool 변경 값 Bright/Contrast Text Box 표기
             * [DataEdit_Tray_Total] mBlob_Range_Count가 0일때 예외처리 추가
             */

            Modify = 191112;
            /* 수정 : ASH
             * [SvMip] ObjectLoad, Object Save Tool 추가(Hoa)
             * [SvMip] Mask 안보이는거 개선
             * [SvMip] TemplateMatching Edge 기능 추가
             */
            Modify = 191224;
            /* 수정 : hong
             * [NachiSocket] Connecting Fail Log 추가
             * [YoiIO] Retry시 Reopen 추가
             */

            Modify = 2020108;
            /* 수정 : ASH
             * [SvMip] ImageCalculator 개선
             * [SvMip] n-Point align 추가
             */

            Modify = 2020109;
            /* 수정 : ASH
             * [SvMip] Mask Fixture 좌표계 적용
             */

            Modify = 2020203;
            /* 수정 : ASH
             * [SvMip] Mask Fixture 좌표계 보완 (Save 할때만 Mask 및 Transform Matrix 저장
             * [SvMip] Sub-Judgement Tool 추가
             */

            Modify = 2020220;
            /* 수정 : LSH
             * [SvMip] TemplateMatch Reverse Check Box 추가
             *         Check Box Check 시 기존과 동일하게 신규 등록 Mark는 Insert 되어 0번으로 등록되고 Check 해지시 신규 등록 Mark는 Add되어 순차등록됨
             * [SvMip] Object Save 시 Object Null 일경우 Return 처리
             * [SvMip.Common] Log Type 추가 (Tact), Tape/Retry Image 저장폴더 주석처리
             * [AutoThread] Image Processing NG 시 구체적인 내용으로 변경 처리 (FIND-LINE NG등)
             * [AutoThread] DataEdit_Tray_Total Blob Set All 기능 추가 _ 세팅된 Blob Range로 일괄 저장_LET 요청사항
             *              TemplateMatch로 올라탐 검사 세팅시 발생되는 팝업창 제거
             */

            Modify = 2020224;
            /* 수정 : hong
             * [YOIIO] Lib update.DIO SW PACKAGE v1.2.1 (2020-02-21) by YOI system
             *    DLL v1.2 update
             *    (수정내용: ShutdownYoiWinIOModule 수행하면, 현재 동작 중인 API 및 내부 Thread, Serial Port 정보를 모두 즉시 종료 및 해제하도록 개선)
             */

            Modify = 200330;
            /* 수정 : TKL
             * [LogView.xaml.cs] Log 창 진입시 Log 중복 기록되도록 추가되던 현상 조치
             */

            Modify = 200409;
            /* 수정 : ASH
             * [SvMip] Relative(Auto) Convert 추가
             *    Relative Option 선택시 상한(%), 하한(%)만큼 상대적인 값으로 제거하여 Image를 자동으로 선명하게 보정 (Cognex Relative Blob 참조)
             */

            Modify = 20042205;
            /* 수정 : hong
             * Version 설명 : 20년 04월 22일 5번째 Ver
             * [Interface] OutIO Read 함수 추가, Reading 후 내부 변수와 비교 Log 추가 (Only PLC - 다른 통신에서도 필요하면 구현하면 됨)
             * [MxConpenent] Writing Fail 시 mxCom reopen 추가
             * [AutoThreadBase]  OutIO Read 비교 부분 추가 ( 현재 주석처리, 필요시만 살리는게 좋을듯 합니다.)
             */
            Modify = 200422;
            /* 수정 : ASH
             * [SvMip]
             *    LineMax 개발을 위한 HoughLine Tool 개발
             * [SvCalibration]
             *    ChessBoard Calibration 추가. IVA-B+에 있었던거... ㅡ,.ㅡ
             * [AutoThread Tray_Total]
             *    Multi-Region 요청 대응 : 동일 Toolblock내 동일 Count의 Region이 있을 경우 동시에 index을 증가시키면서 SvJudgement를 실행한다.
             *    Error 발생시 Auto창 아래쪽 Error 정보에 내용 표시 추가
             */

            Modify = 200423;
            /* 수정 : KDS
             * [Auto.xaml.cs] 시간동기화 추가
             *    Start버튼 실행시 TimeSync함수 실행
             */

            Modify = 200516;
            /* 수정 : LSH
             * [AutoThread_Tray_Total] FDC 보고 항목 추가 (Judgement Value, Judgement Spec, Template-Match Score Spec, Find-line Distance Spec, Find-Line OK Count,
             *                                             Tray Height Spec, Tray Width Spec, Tray Size Tolerance)
             *[IRobotDevice] riteValues(int index, List<float> values) 추가
             *    Start버튼 실행시 TimeSync함수 실행
             */
            Modify = 200615;
            /* 수정 : HNB Overpocket using laser light
                
            */
        }
    }
}
