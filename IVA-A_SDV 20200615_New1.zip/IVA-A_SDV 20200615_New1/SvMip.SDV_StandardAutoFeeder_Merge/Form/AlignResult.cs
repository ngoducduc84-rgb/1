﻿using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public class AlignResult
    {
        public SvImage InputImage;
        public SvImage DisplayImage;
        public List<Point3d> ResultPixelPoint = new List<Point3d>();
        public List<Point3f[]> ResultPoint = new List<Point3f[]>();
        public List<Point3f> SendPoint = new List<Point3f>();
        public List<KeyValuePair<string, double>> ProcessTime;
        public bool IsVisionSuccess = false;
        public bool IsInterfaceSuccess = false;
        public bool IsAlignSuccess = false;

        // ToolType, Tool, Display 여부
        public Dictionary<Type, List<sDisplayinfo>> JobInfo;
        
        public void Clear()
        {
            for (int i = 0; i < ResultPoint.Count; i++)
            {
                ResultPoint[i][0] = new Point3f();
                ResultPoint[i][1] = new Point3f();
            }
            IsVisionSuccess = false;
            IsInterfaceSuccess = false;
            IsAlignSuccess = false;
        }

        public void MakeResultPoint(int _count)
        {
            ResultPoint = new List<Point3f[]>();
            for (int i = 0; i < _count; i++)
            {
                ResultPoint.Add(new Point3f[2]);
                ResultPoint[i][0] = new Point3f();
                ResultPoint[i][1] = new Point3f();
            }
        }
    }

    public class sDisplayinfo
    {
        public SvToolBase Toolbase;
        public bool IsDisplay;
        public sDisplayinfo(SvToolBase _tb, bool _b)
        {
            Toolbase = _tb; IsDisplay = _b;
        }
    }
}
