﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>One row of the "Needs attention" list.</summary>
    public class AttentionItem
    {
        public string ProcessName { get; set; }
        public string Message { get; set; }
        public string Process { get { return string.IsNullOrEmpty(ProcessName) ? "" : ProcessName + " \u00B7 "; } }
        public Visibility OpenVisibility { get { return string.IsNullOrEmpty(ProcessName) ? Visibility.Collapsed : Visibility.Visible; } }
        public override bool Equals(object o)
        {
            AttentionItem a = o as AttentionItem;
            return a != null && a.ProcessName == ProcessName && a.Message == Message;
        }
        public override int GetHashCode() { return (ProcessName + Message).GetHashCode(); }
    }

    /// <summary>One line of the combined log of the overview.</summary>
    public class OverviewLogItem
    {
        public string Time { get; set; }
        public string Process { get; set; }
        public string Message { get; set; }
        public Brush TextColor { get; set; }
    }

    /// <summary>
    /// Overview of all processes on the Auto screen: one card per process (state, last result, counters),
    /// totals, a short list of what needs attention and the combined log. It only reads the view models
    /// of the process views, so it can be removed without touching the rest of Auto.
    /// </summary>
    public partial class AutoOverview : UserControl
    {
        public delegate void ProcessSelectedHandler(string processName);
        public event ProcessSelectedHandler ProcessSelected;

        public static readonly DependencyProperty GridRowsProperty =
            DependencyProperty.Register("GridRows", typeof(int), typeof(AutoOverview), new PropertyMetadata(1));
        public static readonly DependencyProperty GridColumnsProperty =
            DependencyProperty.Register("GridColumns", typeof(int), typeof(AutoOverview), new PropertyMetadata(1));
        public int GridRows { get { return (int)GetValue(GridRowsProperty); } set { SetValue(GridRowsProperty, value); } }
        public int GridColumns { get { return (int)GetValue(GridColumnsProperty); } set { SetValue(GridColumnsProperty, value); } }

        const int MaxLogLines = 200;

        readonly ObservableCollection<VMAutoThread_View> cards = new ObservableCollection<VMAutoThread_View>();
        readonly ObservableCollection<OverviewLogItem> combined = new ObservableCollection<OverviewLogItem>();
        readonly ObservableCollection<AttentionItem> attention = new ObservableCollection<AttentionItem>();
        readonly List<KeyValuePair<VMAutoThread_View, NotifyCollectionChangedEventHandler>> subscriptions =
            new List<KeyValuePair<VMAutoThread_View, NotifyCollectionChangedEventHandler>>();
        readonly DispatcherTimer timer = new DispatcherTimer();

        public AutoOverview()
        {
            InitializeComponent();
            cardList.ItemsSource = cards;
            lstAttention.ItemsSource = attention;
            lstLog.ItemsSource = combined;

            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += delegate { Refresh(); };
            timer.Start();

            Loaded += delegate { HookMode(); };
        }

        /// <summary>The Auto screen sets these: start or stop every process, and tell whether it is running.</summary>
        public event Action StartRequested;
        public event Action StopRequested;
        public Func<bool> IsRunningQuery;

        void StartAll_Click(object sender, RoutedEventArgs e)
        {
            if (StartRequested != null) StartRequested();
        }

        void StopAll_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Stop all processes?", "Stop", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            if (StopRequested != null) StopRequested();
        }

        bool modeHooked;

        /// <summary>The attention list and the combined log are for engineers; operators only see the cards and the totals.</summary>
        void HookMode()
        {
            if (modeHooked) return;
            ViewModelBase o;
            VMMainFrame vm = null;
            if (Main.DicSubViews.TryGetValue(ViewName.MainFrame, out o)) vm = o as VMMainFrame;
            if (vm == null) return;
            modeHooked = true;
            ApplyMode(vm.IsEngineer);
            vm.PropertyChanged += delegate(object s, System.ComponentModel.PropertyChangedEventArgs e)
            {
                if (e.PropertyName == "IsEngineer") ApplyMode(((VMMainFrame)s).IsEngineer);
            };
        }

        void ApplyMode(bool engineer)
        {
            Visibility v = engineer ? Visibility.Visible : Visibility.Collapsed;
            bdAttention.Visibility = v;
            bdLog.Visibility = v;
        }

        /// <summary>Sets the processes shown (in display order). The grid follows the rule of the Auto screen: 1 = 1x1, 2 = 1x2, more = 2 rows.</summary>
        public void SetProcesses(List<VMAutoThread_View> views)
        {
            foreach (KeyValuePair<VMAutoThread_View, NotifyCollectionChangedEventHandler> s in subscriptions)
                s.Key.SequenceLogList.CollectionChanged -= s.Value;
            subscriptions.Clear();
            cards.Clear();
            combined.Clear();

            int count = views.Count;
            if (count <= 1) { GridRows = 1; GridColumns = 1; }
            else if (count == 2) { GridRows = 1; GridColumns = 2; }
            else { GridRows = 2; GridColumns = (count + 1) / 2; }

            foreach (VMAutoThread_View vm in views)
            {
                cards.Add(vm);
                VMAutoThread_View owner = vm;
                NotifyCollectionChangedEventHandler handler = delegate(object s, NotifyCollectionChangedEventArgs e)
                {
                    if (e.Action != NotifyCollectionChangedAction.Add || e.NewItems == null) return;
                    foreach (object o in e.NewItems)
                    {
                        SequenceLog l = o as SequenceLog;
                        if (l == null) continue;
                        OverviewLogItem item = new OverviewLogItem();
                        item.Time = l.Time + "  ";
                        item.Process = owner.ProcessName + "  ";
                        item.Message = l.Message;
                        item.TextColor = (l.TextColor != null) ? (Brush)l.TextColor : (Brush)FindResource("IvaTextBrush");
                        combined.Insert(0, item);
                    }
                    while (combined.Count > MaxLogLines) combined.RemoveAt(combined.Count - 1);
                };
                vm.SequenceLogList.CollectionChanged += handler;
                subscriptions.Add(new KeyValuePair<VMAutoThread_View, NotifyCollectionChangedEventHandler>(vm, handler));
            }
            Refresh();
        }

        void Refresh()
        {
            int ok = 0, ng = 0;
            List<AttentionItem> lines = new List<AttentionItem>();
            foreach (VMAutoThread_View vm in cards)
            {
                ok += vm.OkCount;
                ng += vm.NgCount;
                if (vm.StatusText == "ERROR") lines.Add(new AttentionItem { ProcessName = vm.ProcessName, Message = "waiting for error reset" });
                if (!vm.IOConnected) lines.Add(new AttentionItem { ProcessName = vm.ProcessName, Message = "IO is not connected" });
                if (!string.IsNullOrEmpty(vm.VisionResult) && vm.VisionResult != "Success")
                    lines.Add(new AttentionItem { ProcessName = vm.ProcessName, Message = "last result " + vm.VisionResult });
            }
            if (lines.Count == 0) lines.Add(new AttentionItem { ProcessName = "", Message = "All running processes are healthy." });

            bool running = IsRunningQuery != null && IsRunningQuery();
            btnStartAll.IsEnabled = !running;
            btnStopAll.IsEnabled = running;

            txtTotal.Text = (ok + ng).ToString();
            txtOkNg.Text = ok + " / " + ng;
            txtYield.Text = (ok + ng) == 0 ? "-" : (100.0 * ok / (ok + ng)).ToString("0.0") + "%";

            bool same = lines.Count == attention.Count;
            for (int i = 0; same && i < lines.Count; i++) same = lines[i].Equals(attention[i]);
            if (!same)
            {
                attention.Clear();
                foreach (AttentionItem l in lines) attention.Add(l);
            }
        }

        void Details_Click(object sender, RoutedEventArgs e)
        {
            FrameworkElement fe = sender as FrameworkElement;
            VMAutoThread_View vm = (fe != null) ? fe.DataContext as VMAutoThread_View : null;
            if (vm != null && ProcessSelected != null) ProcessSelected(vm.ProcessName);
        }

        void AttentionOpen_Click(object sender, RoutedEventArgs e)
        {
            FrameworkElement fe = sender as FrameworkElement;
            AttentionItem item = (fe != null) ? fe.DataContext as AttentionItem : null;
            if (item != null && !string.IsNullOrEmpty(item.ProcessName) && ProcessSelected != null) ProcessSelected(item.ProcessName);
        }

        void Card_Click(object sender, MouseButtonEventArgs e)
        {
            FrameworkElement fe = sender as FrameworkElement;
            VMAutoThread_View vm = (fe != null) ? fe.DataContext as VMAutoThread_View : null;
            if (vm != null && ProcessSelected != null) ProcessSelected(vm.ProcessName);
        }

        void Reset_Click(object sender, RoutedEventArgs e)
        {
            FrameworkElement fe = sender as FrameworkElement;
            VMAutoThread_View vm = (fe != null) ? fe.DataContext as VMAutoThread_View : null;
            if (vm == null) return;
            if (MessageBox.Show("Set the counters of " + vm.ProcessName + " to 0?", "Reset counters", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            vm.ResetCounters();
            Refresh();
        }
    }
}
