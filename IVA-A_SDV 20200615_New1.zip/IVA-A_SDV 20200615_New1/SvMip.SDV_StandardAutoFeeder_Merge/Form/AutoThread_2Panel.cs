﻿using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public class AutoThread_2Panel : AutoThread_Base
    {
        public AutoThread_2Panel(Recipe _recipe, Main.Process _process) : base(_recipe, _process)
        {
            
        }

        public override bool InitJob()
        {
            // 여기에 추가.. 이거 되나?
            InitJobBase();
            SetDisplayToolOn(typeof(SvFindLine), 0);
            SetDisplayToolOn(typeof(SvFindLine), 1);
            SetDisplayToolOn(typeof(SvFindLine), 2);
            SetDisplayToolOn(typeof(SvFindLine), 3);
            SetDisplayToolOn(typeof(SvTemplateMatch), 0);
            return true;
        }

        public override bool Do_WriteRevOffset()
        {
            //Point3f result = mAlignResult.ResultPoint[0][0];
            //mRobot.WritePosition(0, result.X, result.Y, result.Z);
            return true;
        }

        //public override bool Do_ProcessTimeLog()
        //{
        //    //foreach (ActJob actjob in mAlignParam.mAct_Object.Values)
        //    //    actjob.DrawAlignTactTime(procTime);

        //    return true;
        //}

        public override bool Do_ExecuteAlignCalc()
        {
            ErrorMessage = "";

            //계산하는 부분...
            return true;
        }
        
        public override bool Do_Judgement()
        {
            //throw new NotImplementedException();
            return true;
        }
    }
}
