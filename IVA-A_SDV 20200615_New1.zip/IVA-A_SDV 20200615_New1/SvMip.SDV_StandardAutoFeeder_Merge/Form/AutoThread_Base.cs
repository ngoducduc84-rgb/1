﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Documents;
using System.Windows.Input;
//using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static SvMip.Common.SvLogger;
using SvMip.Display;
using System.Windows.Forms.Integration;
using System.ComponentModel;
using System.Drawing;
using OpenCvSharp.CPlusPlus;
using System.Threading;
using SvMip.Interface;
using System.Windows;
using SvMip.Common;
using System.Windows.Controls;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// AutoThread_Base.xaml에 대한 상호 작용 논리
    /// </summary>
    public abstract class AutoThread_Base : IDisposable
    {
        public VMAutoThread_View ViewModel
        {
            set
            {
                mViewModel = value;
                mUpdateDisplayCode = mViewModel.UpdateDisplayCode;
            }
        }
        VMAutoThread_View mViewModel;

        #region Calculate
        protected List<Point3d> mOffsets;
        public List<Point3d> Offsets
        {
            get { return mOffsets; }
        }

        public const double PI = Math.PI;
        public const double rad = PI / 180;

        protected double GetTheta(double _x1, double _y1, double _x2, double _y2)
        {
            double X = _x2 - _x1;
            double Y = _y2 - _y1;

            if (X == 0) return Math.PI / 2;

            double _trad = Math.Atan(Y / X);
            return _trad;
        }

        protected double NomalizeTheta(double _rad)
        {
            double nomalrad = _rad + 3 / 2 * Math.PI;
            while (nomalrad > Math.PI / 4)
            {
                nomalrad -= Math.PI / 2;
            }
            return nomalrad;
        }

        protected double CrossProduct(SvPoint _point, SvPoint _lineSp, SvPoint _lineEp)
        {
            double lineL = GetLength(_lineSp, _lineEp);
            SvPoint newPoint = new SvPoint();
            newPoint.X = _point.X - _lineSp.X;
            newPoint.Y = _point.Y - _lineSp.Y;
            SvPoint eigenV = new SvPoint();

            eigenV.X = (float)((_lineEp.X - _lineSp.X) / lineL);
            eigenV.Y = (float)((_lineEp.Y - _lineSp.Y) / lineL);
            double ret = eigenV.X * newPoint.Y - eigenV.Y * newPoint.X;

            return ret;
        }

        protected double DotProduct(SvPoint _point, SvPoint _lineSp, SvPoint _lineEp)
        {
            double lineL = GetLength(_lineSp, _lineEp);
            SvPoint newPoint = new SvPoint();
            newPoint.X = _point.X - _lineSp.X;
            newPoint.Y = _point.Y - _lineSp.Y;
            SvPoint eigenV = new SvPoint();
            eigenV.X = (float)((_lineEp.X - _lineSp.X) / lineL);
            eigenV.Y = (float)((_lineEp.Y - _lineSp.Y) / lineL);
            double ret = eigenV.X * newPoint.X + eigenV.Y * newPoint.Y;
            return ret;
        }

        protected double GetLength(SvPoint _Sp, SvPoint _Ep)
        {
            double ret = Math.Sqrt((_Ep.X - _Sp.X) * (_Ep.X - _Sp.X) + (_Ep.Y - _Sp.Y) * (_Ep.Y - _Sp.Y));
            return ret;
        }

        protected double RadianToDegree(double ang)
        {
            return ang / (Math.PI / 180.0f);
        }

        protected double DegreeToRadian(double ang)
        {
            return ang * (Math.PI / 180);
        }

        protected Point3d ApplyTargetOffset(Point3d _point, Point3d _offset)
        {
            Point3d applyP = new Point3d();
            double T = _point.Z;
            applyP.X = _point.X + Math.Cos(T) * _offset.X - Math.Sin(T) * _offset.Y;
            applyP.Y = _point.Y + Math.Sin(T) * _offset.X + Math.Cos(T) * _offset.Y;
            applyP.Z = _point.Z + _offset.Z * rad;

            return applyP;
        }

        //protected Point3d ApplyTargetOffset(SvPoint _point)
        //{
        //    return ApplyTargetOffset(new Point3d(_point.X, _point.Y, _point.ThetaRad));
        //}

        //protected Point3d ApplyTargetOffset(Point2d _point1, Point2d _point2)
        //{
        //    double T = GetTheta(_point1.X, _point1.Y, _point2.X, _point2.Y);

        //    T = NomalizeTheta(T);

        //    double target1X = 0; double target1Y = 0;
        //    double target2X = 0; double target2Y = 0;
        //    Point2d center = new Point2d();

        //    switch (mOffsetType)
        //    {
        //        case eUseOffsetType.NoUse:
        //            // type이 null일 경우 PLC에서 잘못적힌 값이 있더라도 확실히 하기 위해 Offsets값을 0으로 둔다.
        //            Offsets[0] = 0; Offsets[1] = 0; Offsets[2] = 0; Offsets[3] = 0;
        //            break;

        //        case eUseOffsetType.XY:
        //            center = (_point1 + _point2) * 0.5;
        //            return ApplyTargetOffset(new Point3d(center.X, center.Y, 0));

        //        case eUseOffsetType.XYT:
        //            center = (_point1 + _point2) * 0.5;
        //            return ApplyTargetOffset(new Point3d(center.X, center.Y, T));

        //        case eUseOffsetType.XXY:
        //            target1X = _point1.X + Math.Cos(T) * Offsets[0] - Math.Sin(T) * Offsets[2];
        //            target1Y = _point1.Y + Math.Sin(T) * Offsets[0] + Math.Cos(T) * Offsets[2];
        //            target2X = _point2.X + Math.Cos(T) * Offsets[1] - Math.Sin(T) * Offsets[2];
        //            target2Y = _point2.Y + Math.Sin(T) * Offsets[1] + Math.Cos(T) * Offsets[2];
        //            break;

        //        case eUseOffsetType.XYY:
        //            target1X = _point1.X + Math.Cos(T) * Offsets[0] - Math.Sin(T) * Offsets[1];
        //            target1Y = _point1.Y + Math.Sin(T) * Offsets[0] + Math.Cos(T) * Offsets[1];
        //            target2X = _point2.X + Math.Cos(T) * Offsets[0] - Math.Sin(T) * Offsets[2];
        //            target2Y = _point2.Y + Math.Sin(T) * Offsets[0] + Math.Cos(T) * Offsets[2];
        //            break;

        //        case eUseOffsetType.XXYY:
        //            target1X = _point1.X + Math.Cos(T) * Offsets[0] - Math.Sin(T) * Offsets[2];
        //            target1Y = _point1.Y + Math.Sin(T) * Offsets[0] + Math.Cos(T) * Offsets[2];
        //            target2X = _point2.X + Math.Cos(T) * Offsets[1] - Math.Sin(T) * Offsets[3];
        //            target2Y = _point2.Y + Math.Sin(T) * Offsets[1] + Math.Cos(T) * Offsets[3];
        //            break;

        //    }


        //    Point3d applyP = new Point3d();

        //    applyP.X = (target1X + target2X) / 2;
        //    applyP.Y = (target1Y + target2Y) / 2;
        //    applyP.Z = GetTheta(target1X, target1Y, target2X, target2Y);
        //    applyP.Z = NomalizeTheta(applyP.Z);

        //    return applyP;
        //}
        #endregion

        public string ModuleName { get { return GetType().Name; } }

        protected Thread mThread = null;
        public bool mThreadFlag = false;

        Dictionary<InSignal, bool> mDicInSignal;
        public Dictionary<InSignal, bool> DicInSignal { get { return mDicInSignal; } }

        Dictionary<OutSignal, bool> mDicOutSignal;
        public Dictionary<OutSignal, bool> DicOutSignal { get { return mDicOutSignal; } }

        // Recipe 저장
        Main.Process mProcess;
        Recipe mRecipe;
        SvJob mJob;
        ModelData mModelData;
        RobotData mRobotData;

        protected AlignResult mAlignResult = new AlignResult();
        Point3f NGOffset = new Point3f();

        int regionCountX, regionCountY; //[06.08_hong] TrayData 저장 관련 수정
        bool isReadyState = false;
        const int MaxShowLogCount = 100;

        IIO mIO;
        public IIO IO { set { mIO = value; } }

        int mOutSignalStartAddress;
        public int OutSignalStartAddress
        {
            set
            {
                mOutSignalStartAddress = value;
                Out_Ready = value + (int)OutSignal.Ready;
                Out_OK = value + (int)OutSignal.OK;
                Out_NG = value + (int)OutSignal.NG;
            }
        }
        public enum OutSignal
        {
            Ready = 0, OK = 1, NG = 2
        }
        protected int Out_Ready, Out_OK, Out_NG;

        int mInSignalStartAddress;
        public int InSignalStartAddress
        {
            set
            {
                mInSignalStartAddress = value;
                In_Start = value + (int)InSignal.Start;
                In_Complete = value + (int)InSignal.Complete;
            }
        }

        public enum InSignal
        {
            Start = 0, Complete = 1
        }
        protected int In_Start, In_Complete;

        protected IRobotDevice mRobot;
        public IRobotDevice Robot
        {
            get { return mRobot; }
            set { mRobot = value; }
        }
        
        public AutoThread_Base(Recipe _recipe, Main.Process _process)
        {
            mRecipe = _recipe;
            mJob = _recipe.Job[_process];
            mModelData = _recipe.ModelData[_process];
            mRobotData = _recipe.RobotData[_process];

            mDicInSignal = new Dictionary<InSignal, bool>();
            mDicInSignal.Add(InSignal.Start, false);
            mDicInSignal.Add(InSignal.Complete, false);

            mDicOutSignal = new Dictionary<OutSignal, bool>();
            mDicOutSignal.Add(OutSignal.Ready, false);
            mDicOutSignal.Add(OutSignal.OK, false);
            mDicOutSignal.Add(OutSignal.NG, false);
        }

        private void InitInOutSignal()
        {
            foreach (InSignal v in Enum.GetValues(typeof(InSignal)))
                mDicInSignal[v] = false;
            foreach (OutSignal v in Enum.GetValues(typeof(OutSignal)))
                mDicOutSignal[v] = false;
        }

        //private void AutoThread_Base_Disposed(object sender, EventArgs e)
        //{
        //    Dispose();
        //}


        public void ThreadStart()
        {
            SequenceLog("Auto Mode Start", LogType.SEQUENCE);

            if (mThreadFlag)
            {
                ThreadStop();
                Thread.Sleep(100);
            }
            
            mThreadFlag = true;
            mThread = new Thread(new ThreadStart(ThreadFunction));
            mThread.Start();
        }

        public void ThreadStop()
        {
            SequenceLog("Auto Mode Stop", LogType.SEQUENCE);

            // 이부분 Control로 만들어서 화면에 표시
            //NXEWinIOx64.nxe.WriteGPO((int)OutSignal.Load_Align_Ready, false);
            //NXEWinIOx64.nxe.WriteGPO((int)OutSignal.UnLoad_Align_Ready, false);
            //UpdateOutputPort();
                                  
            if (mThread != null)
            {
                mThreadFlag = false;
                //mThread.Abort();
                mThread.Join();
                mThread = null;
            }
        }

        public abstract bool InitJob();

        protected bool InitJobBase()
        {
            if (mRecipe == null)
            {
                MessageBox.Show("Current Recipe is null", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                SequenceLog("Recipe Load Fail", LogType.ERROR);
                isReadyState = false;
                return false;
            }

            if (mRecipe.Job == null)
            {
                MessageBox.Show("There is No Job.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                SequenceLog("Recipe Load Fail", LogType.ERROR);
                isReadyState = false;
                return false;
            }

            mAlignResult.JobInfo = new Dictionary<Type, List<sDisplayinfo>>();
            GetJobInfo(mJob);
            //[06.08_hong] TrayData 저장 관련 수정
            //Point3f[][] unloadoffset = null;
            //if (DicResult.ContainsKey(Main.Process.Tray1))// && DicResult[Main.Process.Tray1].ResultPoint != null)
            //    unloadoffset = DicResult[Main.Process.Tray1].ResultPoint;


            // ResultRec 등록
            // CurrentJob에서 ToolBlock이 없으면 return
            //foreach (SvToolBase tb in mJob.ToolList)
            //{
            //    if (tb is SvAcquisition) tb.Run();
            //    if (tb is SvToolBlock) mJobInfo.ToolBlock = tb as SvToolBlock;
            //}
            //if (mJobInfo.ToolBlock == null) { SequenceLog("There is no ToolBlock in " + ModuleName.ToString() + "Job", LogType.ERROR); isReadyState = false; }

            //// 현재 ToolBlock에서 Region Tool이 없으면 return
            //foreach (SvToolBase tb in mJobInfo.ToolBlock.ToolJob.ToolList)
            //{
            //    if (tb is SvRegion) mJobInfo.RegionTool = tb as SvRegion;
            //    if (tb is SvMakePoint) mJobInfo.MakePoint = tb as SvMakePoint;
            //}
            //if (mJobInfo.RegionTool == null) { SequenceLog("There is no Region Tool in " + ModuleName.ToString() + "Job", LogType.ERROR); isReadyState = false; }
            //if (mJobInfo.MakePoint == null) { SequenceLog("There is no MakePoint Tool in " + ModuleName.ToString() + "Job", LogType.ERROR); isReadyState = false; }

            //mAlignResult.MakeResultPoint(8);

            //regionCountX = mJobInfo.RegionTool.Count_X; regionCountY = region.Count_Y; //Load, UnLoad에서도 같이 사용
            //bool isLoadSuccess = true;
            //mAlignResult.ResultPoint.AddRange(DataManager.Instance.LoadTrayData(region.Count_X, region.Count_Y, out isLoadSuccess));
            //if (!isLoadSuccess) MessageBox.Show("Not matching region count. \n Run Unload Job First!!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);

            // NG Offset 등록
            //NGOffset.X = 0;
            //NGOffset.Y = 0;
            //NGOffset.Z = 0;

            return true;
        }

        private void GetJobInfo(SvJob _job)
        {
            foreach (SvToolBase toolbase in _job.ToolList)
            {
                if (!mAlignResult.JobInfo.ContainsKey(toolbase.GetType()))
                    mAlignResult.JobInfo.Add(toolbase.GetType(), new List<sDisplayinfo>());

                mAlignResult.JobInfo[toolbase.GetType()].Add(new sDisplayinfo(toolbase, false));

                if (toolbase is SvAcquisition)
                {
                    toolbase.Run();
                    mAlignResult.JobInfo[toolbase.GetType()][0].IsDisplay = true;
                }
                if (toolbase is SvToolBlock) GetJobInfo((toolbase as SvToolBlock).ToolJob);
            }
        }

        public void SetDisplayToolOn(Type _type, int _index)
        {
            if (mAlignResult.JobInfo.ContainsKey(_type) && mAlignResult.JobInfo[_type].Count > _index)
                mAlignResult.JobInfo[_type][_index].IsDisplay = true;
        }

        public string ErrorMessage;

        public enum eStatus
        {
            READY = 0,
            WAIT_ALIGN_START_REQ = 1,
            START = 2,
            JUDGEMENT = 3,
            SEND_OK = 4,
            WAIT_ALIGN_END_ACK = 5,
            ERROR = 6,
            COMPLETE = 7
        }

        public void SetStauts(eStatus _status)
        {
            mViewModel.Status = _status;
            
            foreach (eStatus status in Enum.GetValues(typeof(eStatus)))
            {
                bool b = _status == status ? true : false;
                switch (status)
                {
                    case eStatus.READY:
                        mIO.SetOutValue(Out_Ready, b);
                        break;
                    case eStatus.START:
                        mIO.SetInValue(In_Start, b);
                        break;
                    case eStatus.SEND_OK:
                        mIO.SetOutValue(Out_OK, b);
                        break;
                    case eStatus.ERROR:
                        mIO.SetOutValue(Out_NG, b);
                        break;
                    case eStatus.COMPLETE:
                        mIO.SetInValue(In_Complete, b);
                        break;
                }
            }
        }

        MTickTimer chkTimer = new MTickTimer();
        MTickTimer procTimer = new MTickTimer();
        double procTime = 0.0;

        #region Thread Fuction
        public void ThreadFunction()
        {
            SetStauts(eStatus.READY);

            while (mThreadFlag)
            {
                switch (mViewModel.Status)
                {
                    case eStatus.READY:
                        // 3. Interface 초기화
                        Do_Initial();
                        
                        // 5. Timer Stop
                        chkTimer.StopTimer(); procTimer.StopTimer(); procTime = 0.0;

                        // 6. Status 변경
                        SetStauts(eStatus.WAIT_ALIGN_START_REQ);
                        break;

                    case eStatus.WAIT_ALIGN_START_REQ:
                        // 0. PLC의 Align Request를 기다림..
                        if (!mIO.GetInValue(In_Start)) break;

                        // 1. Process Timer 구동
                        procTimer.StartTimer();

                        // 2. AlignData 초기화
                        InitAlignData();

                        // 4. Status 변경
                        SetStauts(eStatus.START);
                        break;

                    case eStatus.START:
                        // 1. Job Run
                        mJob.Run();
                        
                        // 2. Calculate Align
                        if (!Do_ExecuteAlignCalc())
                            SetStauts(eStatus.ERROR);
                        else
                            SetStauts(eStatus.JUDGEMENT);

                        break;

                    case eStatus.JUDGEMENT:
                        // 1.Spec 판정
                        if (!Do_Judgement())
                            SetStauts(eStatus.ERROR);

                        // 2. Status  변경
                        SetStauts(eStatus.SEND_OK);
                        break;

                    case eStatus.SEND_OK:
                        // 1. Revision Offset, TargetPosition Write
                        if (!Do_WriteRevOffset())
                        {
                            SetStauts(eStatus.ERROR);
                            break;
                        }

                        // 3. Status 변경
                        SetStauts(eStatus.WAIT_ALIGN_END_ACK);
                        break;

                    case eStatus.WAIT_ALIGN_END_ACK:
                        // 1. Align Comp Ack를 기다린다.
                        if (!mIO.GetInValue(In_Complete)) break;
                        // 0. Display
                        //DisplayVisionJob(mJob);

                        // 3. Process Time 기록
                        procTime = procTimer.GetElapseTime();

                        // 4. Status 변경
                        SetStauts(eStatus.COMPLETE);
                        break;

                    case eStatus.ERROR:

                        // 2. PLC의 Align Reset을 기다린다.
                        if (!mIO.GetInValue(In_Complete)) break;

                        // 4. Status 변경
                        SetStauts(eStatus.COMPLETE);
                        break;

                    case eStatus.COMPLETE:
                        DisplayVisionJob(mJob);

                        mViewModel.UpdateDisplay();

                        SequenceLog();

                        ProcessTimeLog();
                        
                        SetStauts(eStatus.READY);
                        break;
                }
                Thread.Sleep(10);
            }
        }

        protected void Do_Initial()
        {
            mAlignResult.Clear();
        }

        System.Drawing.Font font08 = new System.Drawing.Font("Segoe UI", 08, System.Drawing.FontStyle.Bold);
        System.Drawing.Font font72 = new System.Drawing.Font("Segoe UI", 72, System.Drawing.FontStyle.Bold);
        
        bool DisplayVisionJob(SvJob _job)
        {
            foreach (var isdisplay in mAlignResult.JobInfo.Values)
            {
                for (int i = 0; i < isdisplay.Count; i++)
                {
                    if (isdisplay[i].IsDisplay)
                        DrawResult(isdisplay[i].Toolbase);

                    if (isdisplay[i].Toolbase.lastRunSuccess == false)
                        return false;
                }
            }
            return true;
        }

        List<Action> mUpdateDisplayCode;
        bool DrawResult(SvToolBase _tool)
        {
            if (_tool is SvAcquisition)
            {
                mAlignResult.InputImage = (mAlignResult.JobInfo[typeof(SvAcquisition)][0].Toolbase as SvAcquisition).InputImage;
                if (mAlignResult.InputImage == null || mAlignResult.InputImage.Height == 0 || mAlignResult.InputImage.Width == 0)
                    return false;
                mUpdateDisplayCode.Add(new Action(() =>
                {
                    mViewModel.Display.Image = mAlignResult.InputImage;
                }));
            }
            else if (_tool is SvTemplateMatch)
            {
                SvTemplateMatch templateMatch = _tool as SvTemplateMatch;
                Point2d TMcenter = new Point2d(templateMatch.TranslateX, templateMatch.TranslateY);

                if (templateMatch.Score <= mModelData.ScoreCreteria)
                {
                    string message = string.Format("Score NG : {0:F3} (Spec : {1:F3})", templateMatch.Score, mModelData.ScoreCreteria);
                    SequenceLog(message, LogType.ERROR);
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        mViewModel.Display.DrawString(message, font08, Brushes.Red, TMcenter);
                    }));
                    return false;
                }
                else
                {
                    string message = string.Format("Score : {0:F3}", templateMatch.Score);
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        mViewModel.Display.DrawString(message, font08, Brushes.Blue, TMcenter);
                    }));
                }
            }
            else if (_tool is SvFindLine)
            {
                SvFindLine findLine = _tool as SvFindLine;

                if (findLine.lastRunSuccess == false || findLine.Line == null)
                {
                    return false;
                }

                bool isLineOk = true;

                Point2d lineCenterPt = (findLine.Line.SP + findLine.Line.EP) * 0.5;
                double scale = 0.06;
                Point2d SP = (findLine.Line.SP - lineCenterPt) * scale + lineCenterPt;
                Point2d EP = (findLine.Line.EP - lineCenterPt) * scale + lineCenterPt;

                if (findLine.Score > mModelData.FindLineDist)
                {
                    string msessage = string.Format("Line Distance Ng : {0:F3} (Spec : {1:F3})", findLine.Score, mModelData.FindLineDist);
                    SequenceLog(msessage, LogType.ERROR);

                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        mViewModel.Display.DrawLine(Pens.Red, SP, EP);
                        mViewModel.Display.DrawString(msessage, font08, Brushes.Red, lineCenterPt + new Point2d(-150, font08.Size / mViewModel.Display.ZoomRatio / 2));
                    }));

                    isLineOk = false;
                }
                else
                {
                    string msessage = string.Format("Line Distance : {0:F3}", findLine.Score);
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        mViewModel.Display.DrawLine(Pens.YellowGreen, SP, EP);
                        mViewModel.Display.DrawString(msessage, font08, Brushes.Cyan, lineCenterPt + new Point2d(-150, font08.Size / mViewModel.Display.ZoomRatio / 2));
                    }));
                }

                int caliperCount = findLine.LineCaliper.NumberOfCaliper - findLine.NumberOfIgnore;
                int successCnt = (findLine.ResultList.FindAll(x => x.Used == "true")).Count;
                if (successCnt <= mModelData.FindLineNG)
                {
                    string msessage = string.Format("Line Count NG : {0} (Spec : {1}) / {2}", successCnt, mModelData.FindLineNG, caliperCount);
                    SequenceLog(msessage, LogType.ERROR);
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        mViewModel.Display.DrawString(msessage, font08, Brushes.Red, lineCenterPt + new Point2d(-150, -font08.Size / mViewModel.Display.ZoomRatio / 2));
                    }));

                    isLineOk = false;
                }
                else
                {
                    string msessage = string.Format("FindLine Count : {0} / {1}", successCnt, caliperCount);
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        mViewModel.Display.DrawString(msessage, font08, Brushes.Cyan, lineCenterPt + new Point2d(-150, -font08.Size / mViewModel.Display.ZoomRatio / 2));
                    }));
                }

                if (!isLineOk)
                {
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        mViewModel.Display.DrawLine(Pens.Red, SP, EP);
                    }));
                    return false;
                }
            }
            else if (_tool is SvMakePoint)
            {
                SvMakePoint makepoint = _tool as SvMakePoint;
                if (makepoint.lastRunSuccess == false || makepoint == null || makepoint.OutPoint == null)
                    return false;

                double X = makepoint.OutPoint.X;
                double Y = makepoint.OutPoint.Y;
                double T = makepoint.OutPoint.ThetaRad;
                mAlignResult.ResultPixelPoint.Add(new Point3d(makepoint.OutPoint.X, makepoint.OutPoint.Y, makepoint.OutPoint.ThetaRad));
                this.mUpdateDisplayCode.Add(new Action(() =>
                {
                    mViewModel.Display.DrawCross(Pens.Red, new Point2d(X, Y), 100, 100, T);
                }));
            }
            else if (_tool is SvMakeRectFromLine)
            {
                SvMakeRectFromLine makerect = _tool as SvMakeRectFromLine;
                if (makerect.IsRectangle == false)
                {
                    this.mUpdateDisplayCode.Add(new Action(() =>
                    {
                        mViewModel.Display.DrawPolyLines(Pens.Red, makerect.ResultPoints);
                    }));
                    return false;
                }
                this.mUpdateDisplayCode.Add(new Action(() =>
                {
                    mViewModel.Display.DrawPolyLines(Pens.YellowGreen, makerect.ResultPoints);
                }));
            }

            //if (!isSecondAlign)
            //{
            //    isVisionOk = mJob.GetLastRunTool().lastRunSuccess;
            //}

            //if (!isSecondAlign && InputImage != null)
            //{
            //    if (!isVisionOk)
            //        this.updateDisplayCode.Add(new Action(() =>
            //        {
            //            SvLogger.Log.ErrorImage(InputImage.Mat);
            //        }));
            //    else
            //        this.updateDisplayCode.Add(new Action(() =>
            //        {
            //            SvLogger.Log.Image(InputImage.Mat);
            //        }));
            //}

            return true;
        }

        abstract public bool Do_Judgement();
        abstract public bool Do_WriteRevOffset();
        public abstract bool Do_ExecuteAlignCalc();

        protected void SequenceLog() { }

        protected void ProcessTimeLog()
        {
            mViewModel.ProcessTimes = mJob.GetLastProcessTimes();
        }

        protected void InitAlignData()
        {
            mAlignResult.Clear();
        }

        protected void SequenceLog(string log, LogType type)
        {
            switch (type)
            {
                case LogType.SEQUENCE:
                    SvLogger.Log.Sequence(log);
                    break;
                case LogType.DEBUG:
                    SvLogger.Log.Debug(log);
                    break;
                case LogType.ERROR:
                    SvLogger.Log.Error(log);
                    break;
                case LogType.DATA:
                    SvLogger.Log.Data(log, DateTime.Now);
                    break;
                case LogType.RECIPE:
                    SvLogger.Log.Recipe(log);
                    break;
                default:
                    SvLogger.Log.Sequence(log);
                    break;
            }

            log = DateTime.Now.ToString("HH:mm:ss.fff: ") + log;

            mViewModel.AppendLog(log);
        }

        bool WriteOffsets(IRobotDevice robot, int index, /*Point3f[][] offsetPt,*/ Main.Process process)
        {
            System.Diagnostics.Stopwatch stop = System.Diagnostics.Stopwatch.StartNew();

            List<Point3f[]> offsetPt = mAlignResult.ResultPoint;
            for (int i = 0; i < offsetPt.Count; i++)
            {
                for (int j = 0; j < offsetPt[i].Length; j++)
                {
                    Point3f resultP = offsetPt[i][j];
                    mAlignResult.SendPoint.Add(resultP);
                }
            }

            //mAlignResult.ResultPointF = listresultf.ToArray();

            //SvMip.Interface.MXCom.Robot_MXComponent mxCom = robot as SvMip.Interface.MXCom.Robot_MXComponent;
            //if (mxCom == null) return false;

            bool isRobotOk = mRobot.WritePositions(index, mAlignResult.SendPoint);
            stop.Stop();
            System.Diagnostics.Debug.WriteLine("--------Writing PLC Time : " + stop.ElapsedMilliseconds.ToString());

            return isRobotOk;
        }
        #endregion

        public void Dispose()
        {
            ThreadStop();
        }

        
    }
}
