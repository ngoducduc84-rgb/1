﻿using OpenCvSharp.CPlusPlus;
using SvMip.Common;
using SvMip.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
//using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
//using static SvMip.Common.SvLogger;
using SvMip.Display;
using System.Windows.Forms.Integration;
using System.ComponentModel;
//using System.Drawing;
using System.Collections.ObjectModel;
using System.Windows.Threading;
using SvMip.Edit.Base;
using System.Windows.Media;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// AutoThread_Base.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class AutoThread_View : UserControl
    {
        public VMAutoThread_View ViewModel;

        public AutoThread_View(Main.Process proc, EJudgeType type)
        {
            InitializeComponent();

            ViewModel = new VMAutoThread_View(this);
            this.DataContext = ViewModel;
            //set judgement mode
            ViewModel.Process = proc;
            ViewModel.Type = type;

            //동적생성으로 붙여넣기
            ViewModel.Edit = new SvDisplayViewEdit();

            WindowsFormsHost host = new WindowsFormsHost();
            host.Child = ViewModel.Edit;
            Viewer.Child = host;

            Margin = new Thickness(0);//화면 간격을 좁히기 위해서
        }

        private void Control_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Control control = sender as Control;
            if (control != null)
                control.FontSize = control.ActualHeight / 2;
        }

        private void RadioButton_Click(object sender, RoutedEventArgs e)
        {
            RadioButton btn = sender as RadioButton;
            if (btn != null && btn.IsChecked == true)
            {
                switch (btn.ToolTip.ToString())
                {
                    case "READY":
                        ViewModel.Status = AutoThread_Base.eStatus.READY;
                        break;
                    case "REQUEST":
                        ViewModel.IsManual = true;
                        SvMip.Common.SvLogger.Log.Error("[Interface] Manual Start");
                        ViewModel.Status = AutoThread_Base.eStatus.START;
                        break;
                    case "OK":
                        ViewModel.Status = AutoThread_Base.eStatus.SEND_OK;
                        break;
                    case "NG":
                        ViewModel.Status = AutoThread_Base.eStatus.SEND_NG;
                        break;
                    case "COMPLETE":
                        SvMip.Common.SvLogger.Log.Error("[Interface] Manual Start");
                        ViewModel.Status = AutoThread_Base.eStatus.COMPLETE;
                        break;
                }
            }
        }
    }

    public class VMAutoThread_View : ViewModelBase
    {
        string mName;
        public string Name
        {
            set
            {
                if (mName == value) return;
                mName = value;
                NotifyPropertyChanged("Name");
            }
            get { return mName; }
        }

        /// <summary>Name of the process (Object1, Tray2 ...). Name changes to the job name when a job is loaded.</summary>
        public string ProcessName { get { return proc.ToString(); } }

        bool mIOConnected;
        public bool IOConnected
        {
            set
            {
                if (mIOConnected == value) return;
                mIOConnected = value;
                NotifyPropertyChanged("IOConnectedColor");
            }
            get { return mIOConnected; }
        }
        public Brush IOConnectedColor { get { return mIOConnected ? Brushes.YellowGreen : Brushes.DimGray; } }

        bool mRobotConnected;
        public bool RobotConnected
        {
            set
            {
                if (mRobotConnected == value) return;
                mRobotConnected = value;
                NotifyPropertyChanged("RobotConnectedColor");
            }
            get { return mRobotConnected; }
        }
        public Brush RobotConnectedColor { get { return mRobotConnected ? Brushes.YellowGreen : Brushes.DimGray; } }

        AutoThread_Base.eStatus mStatus;
        public AutoThread_Base.eStatus Status
        {
            set
            {
                if (mStatus == value) return;
                mStatus = value;

                NotifyPropertyChanged("Status");
                NotifyPropertyChanged("StatusText");
                NotifyPropertyChanged("StatusBrush");
                NotifyPropertyChanged("IsReady");
                NotifyPropertyChanged("IsRequest");
                NotifyPropertyChanged("IsComplete");
                NotifyPropertyChanged("Background");
                NotifyPropertyChanged("Step0Brush");
                NotifyPropertyChanged("Step1Brush");
                NotifyPropertyChanged("Step2Brush");
                NotifyPropertyChanged("Step3Brush");
            }
            get { return mStatus; }
        }

        // ---- the four steps of a cycle shown on the Auto overview card: Wait -> Inspect -> Send -> Done ----
        static readonly Brush StepPending = Freeze(new SolidColorBrush(Color.FromRgb(0x44, 0x4C, 0x56)));
        static readonly Brush StepDone = Freeze(new SolidColorBrush(Color.FromRgb(0x2E, 0x7D, 0x50)));
        static readonly Brush StepActive = Freeze(new SolidColorBrush(Color.FromRgb(0x4C, 0x9A, 0xFF)));
        static readonly Brush StepError = Freeze(new SolidColorBrush(Color.FromRgb(0xE5, 0x53, 0x4B)));

        static Brush Freeze(Brush b) { b.Freeze(); return b; }

        /// <summary>0 = waiting for a request, 1 = inspecting, 2 = sending the result, 3 = done, 4 = error (waiting for reset).</summary>
        int StepIndex
        {
            get
            {
                switch (mStatus)
                {
                    case AutoThread_Base.eStatus.START:
                    case AutoThread_Base.eStatus.JUDGEMENT: return 1;
                    case AutoThread_Base.eStatus.SEND_OK:
                    case AutoThread_Base.eStatus.SEND_NG:
                    case AutoThread_Base.eStatus.WAIT_ALIGN_END_ACK: return 2;
                    case AutoThread_Base.eStatus.COMPLETE: return 3;
                    case AutoThread_Base.eStatus.WAIT_ERROR_RESET_ACK: return 4;
                    default: return 0;
                }
            }
        }

        Brush StepBrush(int step)
        {
            int at = StepIndex;
            if (at == 4) return step == 2 ? StepError : StepPending;
            if (step < at) return StepDone;
            if (step == at) return StepActive;
            return StepPending;
        }

        public Brush Step0Brush { get { return StepBrush(0); } }
        public Brush Step1Brush { get { return StepBrush(1); } }
        public Brush Step2Brush { get { return StepBrush(2); } }
        public Brush Step3Brush { get { return StepBrush(3); } }
        public bool IsReady
        {
            get { return mStatus == AutoThread_Base.eStatus.READY || mStatus == AutoThread_Base.eStatus.WAIT_ALIGN_START_REQ; }
        }
        public bool IsRequest
        {
            get { return mStatus == AutoThread_Base.eStatus.START || mStatus == AutoThread_Base.eStatus.JUDGEMENT; }
        }

        public bool IsManual=false;

        EJudgeType type;
        public EJudgeType Type
        {
            set
            {
                if(type != value)
                {
                    type = value;
                    NotifyPropertyChanged("IsSingle");
                    NotifyPropertyChanged("IsDual");
                }
            }
        }
        Main.Process proc;
        public Main.Process Process
        {
            set
            {
                if(proc != value)
                {
                    proc = value;
                    NotifyPropertyChanged("ProcessName");
                    LoadCounters();
                    NotifyPropertyChanged("IsSingle");
                    NotifyPropertyChanged("IsDual");
                }
            }
        }

        public Visibility IsDual
        {
            get
            {
                if (type == EJudgeType.Dual) return Visibility.Visible;
                else return Visibility.Hidden;
            }
        }
        public Visibility IsSingle
        {
            get
            {
                if (type == EJudgeType.Single) return Visibility.Visible;
                else return Visibility.Hidden;
            }
        }
        bool? judge1;
        public bool? Judge1
        {
            set
            {
                if (judge1 == value) return;
                judge1 = value;
                NotifyPropertyChanged("Color1");
            }
        }
        bool? judge2;
        public bool? Judge2
        {
            set
            {
                if (judge2 == value) return;
                judge2 = value;
                NotifyPropertyChanged("Color2");
            }
        }

        // ---- cycle counters and state text (used by the Auto overview) ----
        static readonly Brush ReadyBrush = Frozen(new SolidColorBrush(Color.FromRgb(0x4C, 0xBF, 0x7A)));
        static readonly Brush RunBrush = Frozen(new SolidColorBrush(Color.FromRgb(0x4C, 0x9A, 0xFF)));
        static readonly Brush SendBrush = Frozen(new SolidColorBrush(Color.FromRgb(0xE0, 0xA0, 0x30)));
        static readonly Brush ErrorBrush = Frozen(new SolidColorBrush(Color.FromRgb(0xE5, 0x53, 0x4B)));
        static Brush Frozen(SolidColorBrush b) { b.Freeze(); return b; }

        public string StatusText
        {
            get
            {
                switch (mStatus)
                {
                    case AutoThread_Base.eStatus.READY:
                    case AutoThread_Base.eStatus.WAIT_ALIGN_START_REQ: return "READY";
                    case AutoThread_Base.eStatus.START:
                    case AutoThread_Base.eStatus.JUDGEMENT: return "RUNNING";
                    case AutoThread_Base.eStatus.SEND_OK:
                    case AutoThread_Base.eStatus.SEND_NG:
                    case AutoThread_Base.eStatus.WAIT_ALIGN_END_ACK: return "SENDING";
                    case AutoThread_Base.eStatus.WAIT_ERROR_RESET_ACK: return "ERROR";
                    case AutoThread_Base.eStatus.COMPLETE: return "DONE";
                    default: return mStatus.ToString();
                }
            }
        }
        public Brush StatusBrush
        {
            get
            {
                switch (StatusText)
                {
                    case "RUNNING": return RunBrush;
                    case "SENDING": return SendBrush;
                    case "ERROR": return ErrorBrush;
                    default: return ReadyBrush;
                }
            }
        }

        readonly object counterLock = new object();
        int mOkCount, mNgCount;
        double mLastCycleMs;
        string mLastTime = "";
        public int OkCount { get { return mOkCount; } }
        public int NgCount { get { return mNgCount; } }
        public int TotalCount { get { return mOkCount + mNgCount; } }
        public string YieldText { get { return TotalCount == 0 ? "-" : (100.0 * mOkCount / TotalCount).ToString("0.0") + "%"; } }
        public string LastCycleText { get { return string.IsNullOrEmpty(mLastTime) ? "no cycle yet" : string.Format("{0:0} ms   {1}", mLastCycleMs, mLastTime); } }
        public string LastResultText { get { return string.IsNullOrEmpty(visionResult) ? "-" : visionResult; } }

        // small picture of the last trigger, shown on the Auto overview card
        BitmapSource mThumb;
        public BitmapSource Thumbnail { get { return mThumb; } }

        /// <summary>Makes a 320 px wide copy of the image of the last cycle (called from the auto thread).</summary>
        public void SetThumbnail(OpenCvSharp.CPlusPlus.Mat mat)
        {
            try
            {
                if (mat == null || mat.IsDisposed || mat.Width == 0 || mat.Height == 0) return;
                using (System.Drawing.Bitmap full = OpenCvSharp.Extensions.BitmapConverter.ToBitmap(mat))
                {
                    int w = 320;
                    int h = Math.Max(1, (int)(full.Height * (double)w / full.Width));
                    using (System.Drawing.Bitmap small = new System.Drawing.Bitmap(w, h))
                    {
                        using (System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(small))
                        {
                            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Bilinear;
                            g.DrawImage(full, 0, 0, w, h);
                        }
                        using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                        {
                            small.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                            ms.Position = 0;
                            BitmapImage bi = new BitmapImage();
                            bi.BeginInit();
                            bi.CacheOption = BitmapCacheOption.OnLoad;
                            bi.StreamSource = ms;
                            bi.EndInit();
                            bi.Freeze();
                            mThumb = bi;
                        }
                    }
                }
                NotifyPropertyChanged("Thumbnail");
            }
            catch (Exception) { /* the picture is only a convenience; never disturb the cycle */ }
        }

        /// <summary>Called once per finished cycle.</summary>
        public void RecordCycle(bool ok, double cycleMs)
        {
            lock (counterLock)
            {
                if (ok) mOkCount++; else mNgCount++;
                mLastCycleMs = cycleMs;
                mLastTime = DateTime.Now.ToString("HH:mm:ss");
                SaveCounters();
            }
            NotifyCounters();
        }

        public void ResetCounters()
        {
            lock (counterLock)
            {
                mOkCount = 0;
                mNgCount = 0;
                SaveCounters();
            }
            NotifyCounters();
        }

        void NotifyCounters()
        {
            NotifyPropertyChanged("OkCount");
            NotifyPropertyChanged("NgCount");
            NotifyPropertyChanged("TotalCount");
            NotifyPropertyChanged("YieldText");
            NotifyPropertyChanged("LastCycleText");
        }

        // the counters survive a restart of the program (reset with the Reset button of the card)
        string CounterFile()
        {
            return System.IO.Path.Combine(Main.RootPath, "SVL_Data", "Counters", proc.ToString() + ".txt");
        }

        void LoadCounters()
        {
            try
            {
                string file = CounterFile();
                if (!System.IO.File.Exists(file)) return;
                string[] parts = System.IO.File.ReadAllText(file).Trim().Split(',');
                int ok, ng;
                if (parts.Length >= 2 && int.TryParse(parts[0], out ok) && int.TryParse(parts[1], out ng))
                {
                    mOkCount = ok;
                    mNgCount = ng;
                }
            }
            catch { }
        }

        void SaveCounters()
        {
            try
            {
                string file = CounterFile();
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(file));
                System.IO.File.WriteAllText(file, mOkCount + "," + mNgCount);
            }
            catch { }
        }

        string visionResult;
        public string VisionResult
        {
            get { return visionResult; }
            set
            {
                if (visionResult != value)
                {
                    visionResult = value;
                    NotifyPropertyChanged("VisionResult");
                    NotifyPropertyChanged("LastResultText");
                    NotifyPropertyChanged("ResultColor");
                    NotifyPropertyChanged("JudgeText");
                    NotifyPropertyChanged("JudgeBrush");
                    NotifyPropertyChanged("JudgeNote");
                }
            }
        }

        static readonly Brush JudgeOkBrush = Freeze(new SolidColorBrush(Color.FromRgb(0x4C, 0xBF, 0x7A)));
        static readonly Brush JudgeNgBrush = Freeze(new SolidColorBrush(Color.FromRgb(0xE5, 0x53, 0x4B)));
        static readonly Brush JudgeNoneBrush = Freeze(new SolidColorBrush(Color.FromRgb(0x9A, 0xA5, 0xB1)));

        /// <summary>Big text of the overview card: OK, NG, or a dash before the first cycle.</summary>
        public string JudgeText
        {
            get
            {
                if (string.IsNullOrEmpty(visionResult)) return "\u2013";
                return visionResult == "Success" ? "OK" : "NG";
            }
        }
        public Brush JudgeBrush
        {
            get
            {
                if (string.IsNullOrEmpty(visionResult)) return JudgeNoneBrush;
                return visionResult == "Success" ? JudgeOkBrush : JudgeNgBrush;
            }
        }
        /// <summary>Reason shown under an NG.</summary>
        public string JudgeNote { get { return (string.IsNullOrEmpty(visionResult) || visionResult == "Success") ? "" : visionResult; } }

        public Brush ResultColor { get { return VisionResult == "Success" ? Brushes.YellowGreen : Brushes.Red; } }

        public Brush Color1
        {
            get
            {
                if (judge1 == true) return Brushes.YellowGreen;
                else if (judge1 == false) return Brushes.Red;
                else return Brushes.Gray;
            }
        }
        public Brush Color2
        {
            get
            {
                if (judge2 == true) return Brushes.YellowGreen;
                else if (judge2 == false) return Brushes.Red;
                else return Brushes.Gray;
            }
        }
        public bool IsComplete { get { return mStatus == AutoThread_Base.eStatus.COMPLETE; } }
        bool mIsEnable;
        public bool IsEnable
        {
            set
            {
                if (mIsEnable == value) return;
                mIsEnable = value;
                NotifyPropertyChanged("IsEnable");
            }
            get { return mIsEnable; }
        }

        List<KeyValuePair<string, double>> mProcessTimes;
        public List<KeyValuePair<string, double>> ProcessTimes
        {
            set
            {
                mProcessTimes = value;
                NotifyPropertyChanged("ProcessTimes");
                dsp.BeginInvoke(new Action(() => { mView.dgTimeLog.Items.Refresh(); }));
            }
            get { return mProcessTimes; }
        }

        AutoThread_View mView;
        Dispatcher dsp = (new UIElement()).Dispatcher;
        public ObservableCollection<SequenceLog> SequenceLogList { get; set; }
        public ObservableCollection<DataLog> DataLogList { get; set; }
        public ObservableCollection<DataLog> ObjectPointLogList { get; set; }
        public ObservableCollection<DataLog> TargetPointLogList { get; set; }
        public VMAutoThread_View(AutoThread_View view)
        {
            mView = view;
            SequenceLogList = new ObservableCollection<SequenceLog>();
            DataLogList = new ObservableCollection<DataLog>();
            ObjectPointLogList = new ObservableCollection<DataLog>();
            TargetPointLogList = new ObservableCollection<DataLog>();
        }
        public void AppendLog(string time, string msg, SolidColorBrush color = null)
        {
            dsp.BeginInvoke(new Action(() =>
            {
                if (SequenceLogList.Count > 300)
                {
                    while (SequenceLogList.Count > 200)
                    {
                        SequenceLogList.RemoveAt(0);
                    }
                }

                SequenceLogList.Add(new SequenceLog(time, msg, color));
                mView.lstSequence.ScrollIntoView(mView.lstSequence.Items[SequenceLogList.Count - 1]);
            }));
        }
        public void AppendDataLog(string time, string process, string msg1, string msg2, string msg3 , SolidColorBrush color = null)
        {
            dsp.BeginInvoke(new Action(() =>
            {
                if (DataLogList.Count > 300)
                {
                    while (DataLogList.Count > 200)
                    {
                        DataLogList.RemoveAt(0);
                    }
                }

                DataLogList.Add(new DataLog(time, process, msg1, msg2, msg3, color));
                mView.lstDatalog.ScrollIntoView(mView.lstDatalog.Items[DataLogList.Count - 1]);
            }));
        }
        public void AppendObjectLog(string time, string process, string msg1, string msg2, string msg3, SolidColorBrush color = null)
        {
            dsp.BeginInvoke(new Action(() =>
            {
                if (ObjectPointLogList.Count > 300)
                {
                    while (ObjectPointLogList.Count > 200)
                    {
                        ObjectPointLogList.RemoveAt(0);
                    }
                }

                ObjectPointLogList.Add(new DataLog(time, process, msg1, msg2, msg3, color));
                mView.lstObjectlog.ScrollIntoView(mView.lstDatalog.Items[DataLogList.Count - 1]);
            }));
        }
        public void AppendTargetLog(string time, string process, string msg1, string msg2, string msg3, SolidColorBrush color = null)
        {
            dsp.BeginInvoke(new Action(() =>
            {
                if (TargetPointLogList.Count > 300)
                {
                    while (TargetPointLogList.Count > 200)
                    {
                        TargetPointLogList.RemoveAt(0);
                    }
                }

                TargetPointLogList.Add(new DataLog(time, process, msg1, msg2, msg3, color));
                mView.lstTargetlog.ScrollIntoView(mView.lstDatalog.Items[DataLogList.Count - 1]);
            }));
        }

        /// <summary>
        /// 디스플레이 객체 : handling by thread
        /// </summary>
        public SvDisplayViewEdit Edit;
        public List<Action> UpdateDisplayCode = new List<Action>();
        object Updatelock = new object();
        public void UpdateDisplay()
        {
            lock (Updatelock)
            {
                dsp.Invoke(new Action(() =>
                {
                    foreach (Action action in UpdateDisplayCode)
                    {
                        try
                        {
                            action.Invoke();
                        }
                        catch (Exception ex)
                        {
                            SvLogger.Log.Error("[UpdateDisplay fail] \r\n" + ex.ToString());
                            continue;
                        }
                    }

                    UpdateDisplayCode.Clear();

                    int i = Edit.imageListComboBox.SelectedIndex;
                    SvImageInfo imageInfo = (SvImageInfo)Edit.imageListComboBox.SelectedItem;

                    if (imageInfo != null && imageInfo.drawingFunc != null && Edit.Display.Image != null)
                        imageInfo.drawingFunc(Edit.Display);
                }));
            }
        }

        public System.Windows.Media.Brush Background
        {
            get
            {
                if (IsReady)
                    return mIsReadyState == true ? System.Windows.Media.Brushes.LightGray : System.Windows.Media.Brushes.Red;
                return System.Windows.Media.Brushes.DimGray;
            }
        }

        bool mIsReadyState;
        public bool IsReadyState
        {
            set { mIsReadyState = value; }
            get { return mIsReadyState; }
        }
    }

    public class SequenceLog
    {
        string mTime;
        public SolidColorBrush TextColor { get; set; }
        public string Time
        {
            set { mTime = value; }
            get { return mTime; }
        }
        string mMessage;
        public string Message
        {
            set { mMessage = value; }
            get { return mMessage; }
        }
        public SequenceLog(string time, string msg, SolidColorBrush color)
        {
            Time = time;
            Message = msg;
            TextColor = color;
        }
    }
    public class DataLog
    {
        string mTime;
        public SolidColorBrush TextColor { get; set; }
        public string Time
        {
            set { mTime = value; }
            get { return mTime; }
        }
        string mProcess, mResult1, mResult2, mResult3;
        public string Process
        {
            set { mProcess = value; }
            get { return mProcess; }
        }
        public string Result1
        {
            set { mResult1 = value; }
            get { return mResult1; }
        }
        public string Result2
        {
            set { mResult2 = value; }
            get { return mResult2; }
        }
        public string Result3
        {
            set { mResult3 = value; }
            get { return mResult3; }
        }
        public DataLog(string time, string process, string result1, string result2, string result3, SolidColorBrush color)
        {
            Time = time;
            mProcess = process;
            mResult1 = result1;
            mResult2 = result2;
            mResult3 = result3;
            TextColor = color;
        }
    }
}
