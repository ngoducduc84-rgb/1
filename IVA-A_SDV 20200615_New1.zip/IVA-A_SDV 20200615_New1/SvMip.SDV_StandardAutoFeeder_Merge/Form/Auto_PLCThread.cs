﻿using System;
using System.Threading;
using System.Windows.Controls;
using SvMip.Interface;
using SvMip.Common;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public partial class Auto : UserControl
    {
        static Thread plcControlThread = null;
        static bool isPLCThreadAlive = false;

        void StartPLCThread()
        {
            plcControlThread = new Thread(new ThreadStart(PlcThread));
            plcControlThread.IsBackground = true;
            plcControlThread.Start();
        }

        static void StopPLCThread()
        {
            isPLCThreadAlive = false;
            if (plcControlThread != null)
            {
                plcControlThread.Abort();
                plcControlThread.Join();
            }
        }

        void PlcThread()
        {
            while (isPLCThreadAlive)
            {
                //if (mIO.GetInValue((int)InSignal.AutoMode + mInSignalStartAddress) == true)
                //{
                //    if (mIO.GetInValue((int)InSignal.ManualMode + mInSignalStartAddress) == false)
                //    {
                //        if (!IsAutoThreadAlive)
                //        {
                //            SequenceLog("PLC send start signal", SvLogger.LogType.SEQUENCE);
                //            this.Dispatcher.BeginInvoke(new Action(delegate
                //            {
                //                //cb_AlignStartEnd.Checked = true;
                //            }));
                //        }
                //    }
                //}

                //if (mIO.GetInValue((int)InSignal.ManualMode + mInSignalStartAddress) == true)
                //{
                //    if (mIO.GetInValue((int)InSignal.AutoMode + mInSignalStartAddress) == false)
                //    {
                //        if (IsAutoThreadAlive)
                //        {
                //            SequenceLog("PLC send end signal", SvLogger.LogType.SEQUENCE);
                //            this.Dispatcher.BeginInvoke(new Action(delegate
                //            {
                //                //cb_AlignStartEnd.Checked = false;
                //            }));
                //        }
                //    }
                //}

                Thread.Sleep(100);
            }
        }

    }
}
