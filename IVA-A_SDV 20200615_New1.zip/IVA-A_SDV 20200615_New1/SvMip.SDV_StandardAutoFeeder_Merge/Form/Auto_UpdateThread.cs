﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Controls;
using System.Drawing;
using SvMip.Interface;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    //public partial class Auto : UserControl
    //{
        //    Thread updateThread = null;

        //    void StartUpdateThread()
        //    {
        //        updateThread = new Thread(new ThreadStart(UpdateThread));
        //        updateThread.IsBackground = true;
        //        updateThread.Start(); 
        //    }

        //    void StopUpdateThread()
        //    {
        //        if (updateThread != null)
        //        {
        //            updateThread.Abort();
        //            updateThread.Join();
        //        }
        //    }

        //    void UpdateThread()
        //    {
        //        while (mIsAutoThreadAlive)
        //        {
        //            try
        //            {
        //                this.Invoke(new Action(UpdateCurrentRecipe));
        //                this.Invoke(new Action(UpdateIOPort));
        //                this.Invoke(new Action(UpdataRobotStatus));
        //            }
        //            catch (ThreadInterruptedException)
        //            {
        //                System.Diagnostics.Debug.WriteLine("AutoRun Interrupted Aborted");
        //                return;
        //            }
        //            catch (ThreadAbortException)
        //            {
        //                System.Diagnostics.Debug.WriteLine("AutoRun Thread Aborted");
        //                return;
        //            }
        //            catch (Exception)
        //            {
        //                System.Diagnostics.Debug.WriteLine("AutoRun Exception");
        //                continue;
        //            }
        //            Thread.Sleep(100);
        //        }
        //    }

        //    //UpdateThread
        //    void UpdataRobotStatus()
        //    {
        //        Label label = lbl_RobotStatus_Loader;

        //        if (Main.robot.IsOpen)
        //        {
        //            label.BackColor = Color.DodgerBlue;
        //            label.ForeColor = Color.White;
        //            lbl_RobotStatus_Loader.Text = "Connected";
        //        }
        //        else
        //        {
        //            label.BackColor = Color.LightGray;
        //            label.ForeColor = Color.Black;
        //            lbl_RobotStatus_Loader.Text = "Disconnected";
        //        }
        //    }

        //    //UpdateThread
        //    void UpdateCurrentRecipe()
        //    {
        //        lbl_CurrentRecipe.Text = mCurrentRecipeName;
        //    }


        //    //Autorun
        //    void UpdateProcess(Sequence sequence, bool turnOn)
        //    {
        //        lbl_Process_Ready.BackColor = Color.White;
        //        lbl_Process_Ready.ForeColor = Color.Black;

        //        switch (sequence)
        //        {                
        //            case Sequence.ModelChange :
        //                if (turnOn)
        //                {
        //                    lbl_Process_ModelChange.BackColor = Color.DodgerBlue;
        //                    lbl_Process_ModelChange.ForeColor = Color.White;
        //                }
        //                else
        //                {
        //                    lbl_Process_ModelChange.BackColor = Color.White;
        //                    lbl_Process_ModelChange.ForeColor = Color.Black;
        //                }
        //                break;
        //        }
        //    }

        //    //UpdateThread
        //    void UpdateIOPort()
        //    {
        //        UpdateInputPort();
        //        UpdateOutputPort();
        //    }

        //    void UpdateInputPort()
        //    {
        //        mIO.GetAllValues()
        //        foreach (Main.Process process in Main.ListProcess)
        //        {
        //            foreach (var v in mDicAutoThread[process].DicInSignal.Keys)
        //                mDicAutoThread[process].DicInSignal[v] = 
        //        }
        //        //if (NXEWinIOx64.nxe.GPI[(int)InSignal.Load1_Use])
        //        //{
        //        //    lbl_Process_Load.BackColor = Color.DodgerBlue;
        //        //    lbl_Process_Load.ForeColor = Color.White;
        //        //}
        //        //else
        //        //{
        //        //    lbl_Process_Load.BackColor = Color.White;
        //        //    lbl_Process_Load.ForeColor = Color.Black;
        //        //}

        //        //if (NXEWinIOx64.nxe.GPI[(int)InSignal.Load2_Use])
        //        //{
        //        //    lbl_Process_UnLoad.BackColor = Color.DodgerBlue;
        //        //    lbl_Process_UnLoad.ForeColor = Color.White;
        //        //}    
        //        //else 
        //        //{
        //        //    lbl_Process_UnLoad.BackColor = Color.White;
        //        //    lbl_Process_UnLoad.ForeColor = Color.Black;
        //        //}

        //        if (NXEWinIOx64.nxe.GPI[(int)InSignal.Load_Align_Start])
        //        {
        //            lbl_State_Load_Start.BackColor = Color.DodgerBlue;
        //            lbl_State_Load_Start.ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            lbl_State_Load_Start.BackColor = Color.White;
        //            lbl_State_Load_Start.ForeColor = Color.Black;
        //        }

        //        if (NXEWinIOx64.nxe.GPI[(int)InSignal.Load_Align_Complete])
        //        {
        //            lbl_State_Load_Complete.BackColor = Color.DodgerBlue;
        //            lbl_State_Load_Complete.ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            lbl_State_Load_Complete.BackColor = Color.White;
        //            lbl_State_Load_Complete.ForeColor = Color.Black;
        //        }

        //        if (NXEWinIOx64.nxe.GPI[(int)InSignal.UnLoad_Align_Start])
        //        {
        //            lbl_State_UnLoad_Start.BackColor = Color.DodgerBlue;
        //            lbl_State_UnLoad_Start.ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            lbl_State_UnLoad_Start.BackColor = Color.White;
        //            lbl_State_UnLoad_Start.ForeColor = Color.Black;
        //        }

        //        if (NXEWinIOx64.nxe.GPI[(int)InSignal.UnLoad_Align_Complete])
        //        {
        //            lbl_State_UnLoad_Complete.BackColor = Color.DodgerBlue;
        //            lbl_State_UnLoad_Complete.ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            lbl_State_UnLoad_Complete.BackColor = Color.White;
        //            lbl_State_UnLoad_Complete.ForeColor = Color.Black;
        //        }

        //        if (NXEWinIOx64.nxe.GPI[(int)InSignal.ModelChange])
        //        {
        //            lbl_State_ModelChange_Start.BackColor = Color.DodgerBlue;
        //            lbl_State_ModelChange_Start.ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            lbl_State_ModelChange_Start.BackColor = Color.White;
        //            lbl_State_ModelChange_Start.ForeColor = Color.Black;
        //        }

        //        if (NXEWinIOx64.nxe.GPI[(int)InSignal.BitReset])
        //        {
        //            lbl_State_Reset.BackColor = Color.DodgerBlue;
        //            lbl_State_Reset.ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            lbl_State_Reset.BackColor = Color.White;
        //            lbl_State_Reset.ForeColor = Color.Black;
        //        }

        //        if (NXEWinIOx64.nxe.GPI[(int)InSignal.AutoMode])
        //        {
        //            lbl_State_Auto.BackColor = Color.DodgerBlue;
        //            lbl_State_Auto.ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            lbl_State_Auto.BackColor = Color.White;
        //            lbl_State_Auto.ForeColor = Color.Black;
        //        }

        //        if (NXEWinIOx64.nxe.GPI[(int)InSignal.ManualMode])
        //        {
        //            lbl_State_Manual.BackColor = Color.DodgerBlue;
        //            lbl_State_Manual.ForeColor = Color.White;
        //        }
        //        else
        //        {
        //            lbl_State_Manual.BackColor = Color.White;
        //            lbl_State_Manual.ForeColor = Color.Black;
        //        }
        //    }

        //    void UpdateOutputPort()
        //    {
        //        // Load1
        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.Load_Align_Ready])
        //        {
        //            lbl_State_Load_Ready.BackColor = Color.White;
        //            lbl_State_Load_Ready.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_Load_Ready.BackColor = Color.DodgerBlue;
        //            lbl_State_Load_Ready.ForeColor = Color.White;
        //        }

        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.Load1_Align_OK])
        //        {
        //            lbl_State_Load1_OK.BackColor = Color.White;
        //            lbl_State_Load1_OK.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_Load1_OK.BackColor = Color.DodgerBlue;
        //            lbl_State_Load1_OK.ForeColor = Color.White;
        //        }

        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.Load1_Align_NG])
        //        {
        //            lbl_State_Load1_NG.BackColor = Color.White;
        //            lbl_State_Load1_NG.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_Load1_NG.BackColor = Color.DodgerBlue;
        //            lbl_State_Load1_NG.ForeColor = Color.White;
        //        }
        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.Load2_Align_OK])
        //        {
        //            lbl_State_Load2_OK.BackColor = Color.White;
        //            lbl_State_Load2_OK.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_Load2_OK.BackColor = Color.DodgerBlue;
        //            lbl_State_Load2_OK.ForeColor = Color.White;
        //        }

        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.Load2_Align_NG])
        //        {
        //            lbl_State_Load2_NG.BackColor = Color.White;
        //            lbl_State_Load2_NG.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_Load2_NG.BackColor = Color.DodgerBlue;
        //            lbl_State_Load2_NG.ForeColor = Color.White;
        //        }

        //        // UnLoad1
        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.UnLoad_Align_Ready])
        //        {
        //            lbl_State_UnLoad_Ready.BackColor = Color.White;
        //            lbl_State_UnLoad_Ready.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_UnLoad_Ready.BackColor = Color.DodgerBlue;
        //            lbl_State_UnLoad_Ready.ForeColor = Color.White;
        //        }

        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.UnLoad_Align_OK])
        //        {
        //            lbl_State_UnLoad_OK.BackColor = Color.White;
        //            lbl_State_UnLoad_OK.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_UnLoad_OK.BackColor = Color.DodgerBlue;
        //            lbl_State_UnLoad_OK.ForeColor = Color.White;
        //        }

        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.UnLoad_Align_NG])
        //        {
        //            lbl_State_UnLoad_NG.BackColor = Color.White;
        //            lbl_State_UnLoad_NG.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_UnLoad_NG.BackColor = Color.DodgerBlue;
        //            lbl_State_UnLoad_NG.ForeColor = Color.White;
        //        }

        //        if (NXEWinIOx64.nxe.GPO[(int)OutSignal.ModelChangeComplete])
        //        {
        //            lbl_State_ModelChange_Complete.BackColor = Color.White;
        //            lbl_State_ModelChange_Complete.ForeColor = Color.Black;
        //        }
        //        else
        //        {
        //            lbl_State_ModelChange_Complete.BackColor = Color.DodgerBlue;
        //            lbl_State_ModelChange_Complete.ForeColor = Color.White;
        //        }
        //    }
    //}
}
