﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
//using OpenCvSharp.CPlusPlus;
using System.Threading;
using System.Windows.Forms.Integration;
using System.IO;
#if PLCIF
using SvMip.Interface.MXCom;
#endif


namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// DataView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class DataView : UserControl
    {
        VMDataView mVM;
        Dictionary<string, RecipeData> mRcps = new Dictionary<string, RecipeData>();
        Dictionary<string, Type> mDicTrayEditForm = new Dictionary<string, Type>();
        Dictionary<string, Type> mDicLoadingPositionEditForm = new Dictionary<string, Type>();

        public DataView()
        {
            InitializeComponent();

            mVM = new VMDataView();
            this.DataContext = mVM;

            UpdateSystemData();
            UpdateRecipeData();

            //////////////////////////////////////////////////////////////////////////////////
            //          Data 창에서 (특수한 경우) 사용할 Form을 등록해 둔다...
            //////////////////////////////////////////////////////////////////////////////////

            //mDicTrayEditForm.Add(typeof(AutoThread_Load_Insp).Name, typeof(DataEdit_LoadInspection));
            //mDicTrayEditForm.Add(typeof(AutoThread_Load_Insp_Align).Name, typeof(DataEdit_LoadInspection));
            mDicTrayEditForm.Add(typeof(AutoThread_Tray).Name, typeof(DataEdit_TrayOffset));
            mDicTrayEditForm.Add(typeof(AutoThread_Tray_NoPanel).Name, typeof(DataEdit_TrayOffset));
            //mDicTrayEditForm.Add(typeof(AutoThread_Tray_Insp_AfterUnloading).Name, typeof(DataEdit_Tray_Total));
            mDicTrayEditForm.Add(typeof(AutoThread_Tray_Total).Name, typeof(DataEdit_Tray_Total));
            //mDicTrayEditForm.Add(typeof(AutoThread_Tray_Overpocket).Name, typeof(DataEdit_Tray_Overpocket));
            //mDicTrayEditForm.Add(typeof(AutoThread_Tray_Insp_NoPanel_DualRegion).Name, typeof(DataEdit_TrayOffset_Inspection_DualRegion));
            //mDicTrayEditForm.Add(typeof(AutoThread_Tray_Insp_NoPanel).Name, typeof(DataEdit_TrayOffset_Inspection));

            mDicLoadingPositionEditForm.Add(typeof(AutoThread_Tray_NoPanel).Name, typeof(DataEdit_LoadPosition));
            mDicLoadingPositionEditForm.Add(typeof(AutoThread_Panel).Name, typeof(DataEdit_LoadPosition));
            mDicLoadingPositionEditForm.Add(typeof(AutoThread_Panel_Put).Name, typeof(DataEdit_LoadPosition));
            mDicLoadingPositionEditForm.Add(typeof(AutoThread_Tray_Total).Name, typeof(DataEdit_LoadPosition));
            //mDicLoadingPositionEditForm.Add(typeof(AutoThread_Tray_Insp_NoPanel_DualRegion).Name, typeof(DataEdit_LoadPosition));
            //mDicLoadingPositionEditForm.Add(typeof(AutoThread_Tray_Insp_NoPanel).Name, typeof(DataEdit_LoadPosition));

            //////////////////////////////////////////////////////////////////////////////////

            lstRecipe.SelectionChanged += Recipe_SelectionChanged;
            lstProcess.SelectionChanged += Process_SelectionChanged;
        }

        private void Recipe_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RecipeData recipe = lstRecipe.SelectedItem as RecipeData;
            if (recipe == null) return;

            int v = lstProcess.SelectedIndex;
            lstProcess.ItemsSource = recipe.DicProcess.Values;
            lstProcess.SelectedIndex = v;
        }

        private void Process_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RecipeParam proc = lstProcess.SelectedItem as RecipeParam;
            if (proc == null) return;

            mVM.CurrentProcess = proc;

            mVM.LoadPositions.Clear();
            mVM.AlignOffsets.Clear();

            int idx = 0;
            foreach (var pnt in proc.RobotData.LoadPosition)
                mVM.LoadPositions.Add(new STRPoint3d(string.Format("PANEL #{0}", ++idx), pnt));

            idx = 0;
            foreach (var pnt in proc.RobotData.AlignOffsets)
                mVM.AlignOffsets.Add(new STROffsetData(string.Format("PANEL #{0}", ++idx), pnt));

            // A4 Watch panel inspection용 spec 설정창
            if (mVM.System.DicProcess[proc.Process].ThreadName.Contains("Panel_Insp"))
                mVM.IsShowTapeInspection = Visibility.Visible;
            else
                mVM.IsShowTapeInspection = Visibility.Hidden;

            if (mDicTrayEditForm.ContainsKey(mVM.System.DicProcess[proc.Process].ThreadName))
                mVM.IsShowTrayEdit = Visibility.Visible;
            else
                mVM.IsShowTrayEdit = Visibility.Hidden;

            if (mDicLoadingPositionEditForm.ContainsKey(mVM.System.DicProcess[proc.Process].ThreadName))
                mVM.IsShowLoadPosEdit = Visibility.Visible;
            else
                mVM.IsShowLoadPosEdit = Visibility.Hidden;
        }

        private void UpdateSystemData()
        {
            SystemData sys = new SystemData();
            sys.LoadData();
            mVM.System = sys;
        }

        private void UpdateRecipeData()
        {
            string oldRecipeName = null;

            if (lstRecipe.SelectedValue != null) oldRecipeName = (lstRecipe.SelectedValue as RecipeData).RecipeName;
            int oldProcessIndex = lstProcess.SelectedIndex;

            mVM.RecipeDatas.Clear();
            mVM.ProcDatas.Clear();

            lstProcess.ItemsSource = null;
            lstJob.ItemsSource = SystemData.GetJobList();
            lstCalib.ItemsSource = SystemData.GetCalibList();

            RecipeData recipe = null;
            try
            {
                foreach (var name in RecipeData.GetRecipeList())
                {
                    recipe = new RecipeData(name, mVM.System);
                    recipe.LoadData(true);
                    mVM.RecipeDatas.Add(recipe);
                }

                int newIndex = Array.IndexOf(RecipeData.GetRecipeList(), oldRecipeName);
                if (newIndex > -1)
                    lstRecipe.SelectedIndex = newIndex;

                lstProcess.ItemsSource = recipe.DicProcess.Values;
                if (oldProcessIndex > -1 && oldProcessIndex < lstProcess.Items.Count)
                    lstProcess.SelectedIndex = oldProcessIndex;
            }
            catch
            {
                return;
            }
        }

        private void SaveSystem_Click(object sender, RoutedEventArgs e)
        {
            //if (MessageBox.Show("System Data를 저장하시겠습니까?", "Question", MessageBoxButton.OKCancel,

            try
            {
                if (!CheckDiplayOrder())
                {
                    MessageBox.Show("[Save Fail] DisPlay Order Not matching");
                    return;
                }

                if (!CheckIOValidate())
                {
                    MessageBox.Show("[Save Fail] IO assignment is invalidate!!!");
                    return;
                }

                if (MessageBox.Show("Would you like to save the System Data?", "Question", MessageBoxButton.OKCancel,
                    MessageBoxImage.Question) == MessageBoxResult.Cancel)
                    return;

                LoginDlg dlg = new LoginDlg();
                if (dlg.ShowDialog() == false)
                {
                    MessageBox.Show("It's wrong password!!!", "fail", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                // RootPath는 항상 Main.RootPath를 저장한다.
                // 원래 RootPath의 systemdata도 저장(이래야 껏다 켰을때 Main에서 변경된 root path가 적용됨..)
                // 그 후에 변경된 RootPath를 적용하여 저장.
                if (mVM.System.RootPath != Main.RootPath) // 만약 바뀌었으면...
                {
                    string changedPath = mVM.RootPath;
                    mVM.RootPath = Main.RootPath; // 본래 system 파일에
                    Main.RootPath = changedPath; // 바뀐 Path(string) 값을
                    mVM.System.SaveData(); // 저장하고
                    mVM.RootPath = Main.RootPath;
                }
                mVM.System.SaveData(); // 변경된 값 저장
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fail to System Data : \n" + ex.ToString());
            }

            Auto.IsSystemDataChanged = true;
            Auto.IsRecipeDataChanged = true;//recipe에도 영향을 줌

            //MessageBox.Show("Sytem Data 저장완료 !!!");
            MessageBox.Show("Sytem Data saving Complete!!!");
        }

        private void SaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (lstRecipe.SelectedItem == null)
            {
                //MessageBox.Show("선택된 Recipe가 없습니다.. 저장취소 !!!");
                MessageBox.Show("There is no selected Recipe !!!");
                return;
            }

            //if (MessageBox.Show("Recipe Data를 저장하시겠습니까?", "Question", MessageBoxButton.OKCancel,
            if (MessageBox.Show("Would you like to save Recipe Data?", "Question", MessageBoxButton.OKCancel,
                MessageBoxImage.Question) == MessageBoxResult.Cancel)
                return;

            LoginDlg dlg = new LoginDlg();
            if (dlg.ShowDialog() == false)
            {
                MessageBox.Show("It's wrong password!!!", "fail", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try { ((RecipeData)lstRecipe.SelectedItem).SaveData(); }
            catch (Exception ex) { MessageBox.Show("Fail to Recipe Data : \n" + ex.ToString()); }

            Auto.IsRecipeDataChanged = true;

            MessageBox.Show("Recipe Data saving Complete !!!");
        }

        private void ChangePassword_Click(object sender, RoutedEventArgs e)
        {

            LoginDlg dlg = new LoginDlg();
            if (dlg.ShowDialog() == false)
            {
                MessageBox.Show("It's wrong password!!!", "fail", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            PasswordDlg dlg2 = new PasswordDlg();
            if (dlg2.ShowDialog() == false)
            {
                MessageBox.Show("Password Change failed !!!", "fail", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            MessageBox.Show("Password Change Complete !!!");
        }


        private void lvProcess_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView lv = sender as ListView;
            if (lv.SelectedItem == null) return;
            ProcessDataBind pd = lv.SelectedItem as ProcessDataBind;
            lstRef.SelectedItems.Clear();
            for (int i = 0; i < pd.RefProcs.Count; i++)
                lstRef.SelectedItems.Add(pd.RefProcs[i]);
            //camera data 추가
            tbFocalLength.DataContext = pd;
            tbSensorWidth.DataContext = pd;
            tbSensorHeight.DataContext = pd;

            lvLogConfig.Items.Clear();
            foreach (var v in pd.LogConfigs)
                lvLogConfig.Items.Add(new LogConfigBind(v));
        }

        private void lstRef_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!lstRef.IsMouseOver) return;
            ListView lv = lvProcess as ListView;
            if (lv.SelectedItem == null) return;
            ProcessDataBind pd = lv.SelectedItem as ProcessDataBind;
            pd.RefProcs.Clear();
            foreach (var item in lstRef.SelectedItems)
                pd.RefProcs.Add((Main.Process)item);
        }

        private bool CheckDiplayOrder()
        {
            List<bool> check = new List<bool>();
            foreach (var pd in mVM.ProcessDatas)
            {
                if (pd.ProcessName == Main.Process.Common) continue;
                if (pd.Use == true) check.Add(false);
            }
            foreach (var pd in mVM.ProcessDatas)
            {
                if (pd.ProcessName == Main.Process.Common) continue;
                if (pd.Use != true) continue;
                if (check.Count <= pd.DisplayOrder) return false;
                if (check[pd.DisplayOrder]) return false;
                check[pd.DisplayOrder] = true;
            }
            return true;
        }

        private bool CheckIOValidate()
        {
            Dictionary<int, string> incheck = new Dictionary<int, string>();
            Dictionary<int, string> outcheck = new Dictionary<int, string>();
            foreach (var p in mVM.System.DicProcess)
            {
                if (!p.Value.Use) continue;
                // input
                foreach (var kv in p.Value.IOParam.Inputs)
                {
                    if (incheck.Keys.Contains(kv.Value)) return false;
                    incheck.Add(kv.Value, kv.Key);
                }
                // output
                if (p.Key == Main.Process.Common)
                {
                    foreach (var kv in p.Value.IOParam.Outputs)
                    {
                        if (outcheck.Keys.Contains(kv.Value)) return false;
                        outcheck.Add(kv.Value, kv.Key);
                    }
                }
                else
                {
                    //ready
                    AutoThread_Base.OutSignal tag = AutoThread_Base.OutSignal.Ready;
                    if (outcheck.Keys.Contains(p.Value.IOParam.Outputs[tag.ToString()])) return false;
                    outcheck.Add(p.Value.IOParam.Outputs[(tag.ToString())], tag.ToString());
                    //acqcomp
                    if (p.Value.UseAcqComp)
                    {
                        tag = AutoThread_Base.OutSignal.AcqComp;
                        if (outcheck.Keys.Contains(p.Value.IOParam.Outputs[tag.ToString()])) return false;
                        outcheck.Add(p.Value.IOParam.Outputs[(tag.ToString())], tag.ToString());
                    }
                    //ok, ng
                    for (int i = 0; i < 2; i++)
                    {
                        tag = AutoThread_Base.OutSignal.OK + i;
                        if (outcheck.Keys.Contains(p.Value.IOParam.Outputs[tag.ToString()])) return false;
                        outcheck.Add(p.Value.IOParam.Outputs[(tag.ToString())], tag.ToString());
                    }
                    //ok2, ng2
                    if (p.Value.JudgeType == EJudgeType.Dual)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            tag = AutoThread_Base.OutSignal.OK2 + i;
                            if (outcheck.Keys.Contains(p.Value.IOParam.Outputs[tag.ToString()])) return false;
                            outcheck.Add(p.Value.IOParam.Outputs[(tag.ToString())], tag.ToString());
                        }
                    }
                }
            }
            return true;
        }

        private void ReloadSystem_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Do you reload system data?", "Reload System", MessageBoxButton.OKCancel, MessageBoxImage.Question) == MessageBoxResult.OK)
            {
                this.DataContext = null;
                UpdateSystemData();
                MessageBox.Show("Complete reload !!!");
            }
            this.DataContext = mVM;
        }

        private void ReloadRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Do you reload recipe data?", "Reload Recipe", MessageBoxButton.OKCancel, MessageBoxImage.Question) == MessageBoxResult.OK)
            {
                this.DataContext = null;
                UpdateRecipeData();
                MessageBox.Show("Complete reload !!!");
            }
            this.DataContext = mVM;
        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            int i; double d;
            TextBox tb = sender as TextBox;
            if (tb == null) return;
            if (e.Key == Key.Up)
            {
                if (int.TryParse(tb.Text, out i))
                {
                    tb.Text = (e.KeyboardDevice.Modifiers == ModifierKeys.Control ? i + 10 : i + 1).ToString();
                }
                else if (double.TryParse(tb.Text, out d))
                {
                    tb.Text = (e.KeyboardDevice.Modifiers == ModifierKeys.Control ? d + 1.0 : d + 0.1).ToString("f3");
                }
            }
            else if (e.Key == Key.Down)
            {
                if (int.TryParse(tb.Text, out i))
                {
                    tb.Text = (e.KeyboardDevice.Modifiers == ModifierKeys.Control ? i - 10 : i - 1).ToString();
                }
                else if (double.TryParse(tb.Text, out d))
                {
                    tb.Text = (e.KeyboardDevice.Modifiers == ModifierKeys.Control ? d - 1.0 : d - 0.1).ToString("f3");
                }
            }
        }

        private void TrayJobEdit_Click(object sender, RoutedEventArgs e)
        {
            if (lstProcess.SelectedItem == null) return;
            Main.Process process = ((RecipeParam)lstProcess.SelectedItem).Process;
            //Main.Process selectedProcess = (Main.Process)Enum.Parse(typeof(Main.Process), lstProcess.SelectedItem.ToString());
            Type edittype = mDicTrayEditForm[mVM.System.DicProcess[process].ThreadName];

            DataEdit_Base edit = Activator.CreateInstance(edittype, mVM.System.DicProcess[process], (RecipeData)lstRecipe.SelectedItem, process, lstJob.SelectedItem.ToString()) as DataEdit_Base;

            if (edit.IsPossible)
            {
                edit.ShowDialog();
                edit.Dispose();
                //ReloadRecipe_Click(this, null);
            }
        }

        private void GetLoadingPos_Click(object sender, RoutedEventArgs e)
        {
            if (lstProcess.SelectedItem == null) return;
            Main.Process process = ((RecipeParam)lstProcess.SelectedItem).Process;
            RecipeData recipe = (RecipeData)lstRecipe.SelectedItem;

            RecipeData originalRecipeData = new RecipeData(recipe.RecipeName, mVM.System);
            originalRecipeData.LoadData(true);
            SvJob originalJob = originalRecipeData.DicProcess[process].Job;
            //Main.Process selectedProcess = (Main.Process)Enum.Parse(typeof(Main.Process), lstProcess.SelectedItem.ToString());

            if (!mDicLoadingPositionEditForm.ContainsKey(mVM.System.DicProcess[process].ThreadName)) return;

            Type edittype = mDicLoadingPositionEditForm[mVM.System.DicProcess[process].ThreadName];

            DataEdit_Base edit = Activator.CreateInstance(edittype, (RecipeData)lstRecipe.SelectedItem, process, lstJob.SelectedItem.ToString()) as DataEdit_Base;

            if (edit.IsPossible)
            {
                edit.ShowDialog();
                for (int i = 0; i < mVM.LoadPositions.Count; i++)
                {
                    mVM.LoadPositions[i].X = recipe.DicProcess[process].RobotData.LoadPosition[i].X.ToString("f3");
                    mVM.LoadPositions[i].Y = recipe.DicProcess[process].RobotData.LoadPosition[i].Y.ToString("f3");
                    mVM.LoadPositions[i].T = recipe.DicProcess[process].RobotData.LoadPosition[i].ThetaRad.ToString("f3");
                }
                lstJob.SelectedItem = originalJob.Name;
                //recipe.DicProcess[process].Job = originalJob;
                edit.Dispose();
                //recipe.DicProcess[process].Job = originalJob;

            }
        }

        private void Input_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ProcessDataBind pd = lvProcess.SelectedItem as ProcessDataBind;
            if (pd == null) return;
            Main.Process process = (Main.Process)((Label)sender).Tag;
            SetIODlg dlg = new SetIODlg(mVM.System.DicProcess, process, true);
            if (dlg.ShowDialog() == true)
                pd.NotifyPropertyChanged("InStartAddr");
        }

        private void Output_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ProcessDataBind pd = lvProcess.SelectedItem as ProcessDataBind;
            if (pd == null) return;
            Main.Process process = (Main.Process)((Label)sender).Tag;
            SetIODlg dlg = new SetIODlg(mVM.System.DicProcess, process, false);
            if (dlg.ShowDialog() == true)
                pd.NotifyPropertyChanged("OutStartAddr");
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (lstRecipe.Items.Count > 0)
            {
                // 현재 사용중인 레시피 선택하고 있도록
                lstRecipe.SelectedItem = mVM.RecipeDatas.Where(a => a.RecipeName == Auto.mCurrentRecipeName).First();
            }

            // processes configured by their job: the values of this screen are not used for them
            if (!mJobNoticeShown)
            {
                try
                {
                    List<string> driven = JobConfigBridge.GetJobDrivenProcesses(Auto.mCurrentRecipe);
                    if (driven.Count > 0)
                    {
                        mJobNoticeShown = true;
                        MessageBox.Show("These processes are configured by their job (SvTrigger / SvConnection / SvAlign / SvSend):\n\n"
                            + string.Join(", ", driven.ToArray())
                            + "\n\nFor them the connection, signal, robot and align values of this screen are ignored while the job runs. "
                            + "The job file of each process is still chosen here.",
                            "DATA", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        static bool mJobNoticeShown = false;

        private void SetHistoBase_Clicked(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstProcess.SelectedItem == null) return;
                // 현재 사용중인 job 객체 생성
                string jobname = lstJob.SelectedItem.ToString();
                string jobpath = System.IO.Path.Combine(Main.JobPath, jobname);
                if (!System.IO.File.Exists(jobpath)) return;
                // load job
                SvSerializer serial = new SvSerializer();
                SvJob job = serial.LoadJob(jobpath);

                if (job == null)
                {
                    MessageBox.Show("It's fail to load job !!!");
                    return;
                }

                foreach (var tool in job.ToolList)
                {
                    if (!(tool is SvToolBlock)) continue;

                    // get region tool
                    SvRegion region = GetRegion((SvToolBlock)tool);
                    if (region == null)
                    {
                        MessageBox.Show("There is no region tool !!!");
                        return;
                    }

                    // get histogram tool
                    SvHistogram histo = GetHistogram((SvToolBlock)tool);

                    if (histo == null)
                    {
                        MessageBox.Show("There is no histogram tool !!!");
                        return;
                    }

                    histo.Thresholds.Clear();

                    job.Run();//일단 전체 잡 실행 : 이미지 취득포함

                    region.IndexXnext = 0; region.IndexYnext = 0;
                    for (int i = 0; i < region.Count_X * region.Count_Y; i++)
                    {
                        region.Run();

                        histo.InputImage = region.SubImage;
                        histo.Run();
                        histo.Thresholds.Add(Math.Round(histo.Mean, 2));

                        region.IncreaseIndex();
                    }
                }

                //save
                if (serial.SaveJob(job, jobpath))
                {
                    string msg = "Success to set histogram base!!!\n";
                    MessageBox.Show(msg, "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                    MessageBox.Show("Fail to set histogram base!!!", "Failure", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private SvRegion GetRegion(SvToolBlock block)
        {
            SvRegion region = null;
            foreach (var tool in block.ToolJob.ToolList)
            {
                if (tool is SvRegion)
                {
                    region = tool as SvRegion;
                    break;
                }
            }
            return region;
        }

        private SvHistogram GetHistogram(SvToolBlock block)
        {
            SvHistogram histo = null;
            foreach (var tool in block.ToolJob.ToolList)
            {
                if (tool is SvHistogram)
                {
                    //histo = tool as SvHistogram;
                    histo = (SvHistogram)tool;
                    break;
                }
            }
            return histo;
        }

        private void RecipeCreate_Click(object sender, RoutedEventArgs e)
        {
            if (lstRecipe.SelectedItem == null) return;
            RecipeData recipe = lstRecipe.SelectedItem as RecipeData;
            if (recipe == null) return;

            var dlg = new CreateRecipeDlg(recipe.RecipeName);
            dlg.ShowDialog();

            if (dlg.DialogResult == MessageBoxResult.OK)
            {
                System.IO.Directory.CreateDirectory(dlg.NewRecipePath);

                //string src = System.IO.Path.Combine(dlg.OldRecipePath, "RecipeData.dat");
                //string des = System.IO.Path.Combine(dlg.NewRecipePath, "RecipeData.dat");

                //System.IO.File.Copy(src, des);

                UpdateRecipeData();
            }
        }

        private void RecipeCopy_Click(object sender, RoutedEventArgs e)
        {
            if (lstRecipe.SelectedItem == null) return;
            RecipeData recipe = lstRecipe.SelectedItem as RecipeData;
            if (recipe == null) return;

            var dlg = new CreateRecipeDlg(recipe.RecipeName);
            dlg.ShowDialog();

            if (dlg.DialogResult == MessageBoxResult.OK)
            {
                CopyFolder(dlg.OldRecipePath, dlg.NewRecipePath);
                UpdateRecipeData();
            }
        }
        private void RecipeDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (lstRecipe.SelectedItem == null) return;
                RecipeData recipe = lstRecipe.SelectedItem as RecipeData;
                if (recipe == null) return;

                if (recipe.RecipeName == Auto.mCurrentRecipeName)
                {
                    MessageBox.Show("It's impossible to delete current recipe!!!", "Failure", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string del = System.IO.Path.Combine(Main.RecipePath, recipe.RecipeName);
                if (!System.IO.Directory.Exists(del))
                {
                    MessageBox.Show("There are no recipe folder!!!", "Failure", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                System.IO.Directory.Delete(del, true);

                MessageBox.Show("Complete to delete recipe", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                UpdateRecipeData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void CopyFolder(string _srcPath, string _dstPath)
        {
            if (!Directory.Exists(_dstPath)) Directory.CreateDirectory(_dstPath);

            string[] files = Directory.GetFiles(_srcPath);
            string[] folders = Directory.GetDirectories(_srcPath);

            foreach (string file in files)
            {
                string name = System.IO.Path.GetFileName(file);
                string dest = System.IO.Path.Combine(_dstPath, name);
                File.Copy(file, dest);
            }
            foreach (string folder in folders)
            {
                string name = System.IO.Path.GetFileName(folder);
                string dest = System.IO.Path.Combine(_dstPath, name);
                CopyFolder(folder, dest);
            }
        }
    }

    public class VMDataView : ViewModelBase
    {
        public VMDataView()
        {
            //Recipe data
            RecipeDatas = new ObservableCollection<RecipeData>();
            ProcDatas = new ObservableCollection<RecipeParam>();

            LoadPositions = new ObservableCollection<STRPoint3d>();
            AlignOffsets = new ObservableCollection<STROffsetData>();
        }

        #region System data section
        SystemData mSystem;
        public SystemData System
        {
            set
            {
                mSystem = value;
                //System data
                ProcessDatas = new ObservableCollection<ProcessDataBind>();
                foreach (var kv in mSystem.DicProcess)
                    ProcessDatas.Add(new ProcessDataBind(kv.Key, kv.Value));
                //LogConfigs = new List<LogConfigBind>();
                //foreach (var kv in mSystem.DicLogConfig)
                //    LogConfigs.Add(new LogConfigBind(kv));
            }
            get { return mSystem; }
        }

        public ObservableCollection<ProcessDataBind> ProcessDatas { get; set; }

        //public List<LogConfigBind> LogConfigs { get; set; }

        public Array RefProcPool { get { return Enum.GetValues(typeof(Main.Process)); } }

        public int StationNo
        {
            set
            {
                if (StationNo != value)
                {
                    mSystem.StationNumber = value;
                    NotifyPropertyChanged("StationNo");
                    NotifyPropertyChanged("StationNumber");
                }
            }
            get { return mSystem.StationNumber; }
        }
        public string StationNumber
        {
            set
            {
                if (StationNumber == value) return;
                int i;
                if (int.TryParse(value, out i))
                    StationNo = i;
            }
            get { return StationNo.ToString(); }
        }

#if PLCIF
        public Array DeviceTypePool { get { return Enum.GetValues(typeof(EDeviceType)); } }

        public EDeviceType DeviceType
        {
            set
            {
                if (DeviceType != value)
                {
                    mSystem.DeviceType = value;
                    NotifyPropertyChanged("DeviceType");
                }
            }
            get { return mSystem.DeviceType; }
        }
#endif
        public int PortNo
        {
            set
            {
                if (PortNo != value)
                {
                    mSystem.PortNumber = value;
                    NotifyPropertyChanged("PortNo");
                    NotifyPropertyChanged("PortNumber");
                }
            }
            get { return mSystem.PortNumber; }
        }
        public string PortNumber
        {
            set
            {
                if (PortNumber != value)
                {
                    int i;
                    if (int.TryParse(value, out i))
                        PortNo = i;
                }
            }
            get { return PortNo.ToString(); }
        }

        public int OPCallBit
        {
            set
            {
                if (OPCallBit == value) return;
                mSystem.OPCallBit = value;
                NotifyPropertyChanged("OPCallAddr");
                NotifyPropertyChanged("OPCallAddr");
            }
            get { return mSystem.OPCallBit; }
        }
        public string OPCallAddress
        {
            set
            {
                if (OPCallAddress == value) return;
                int i;
                if (int.TryParse(value, out i))
                    OPCallBit = i;
            }
            get { return OPCallBit.ToString(); }
        }
        public int IOThreadSleep
        {
            set
            {
                if (IOThreadSleep != value)
                {
                    mSystem.IOThreadSleep = value;
                    NotifyPropertyChanged("IOThreadSleep");
                    NotifyPropertyChanged("ThreadSleep");
                }
            }
            get { return mSystem.IOThreadSleep; }
        }
        public string ThreadSleep
        {
            set
            {
                if (ThreadSleep != value)
                {
                    int i;
                    if (int.TryParse(value, out i))
                        IOThreadSleep = i;
                }
            }
            get { return IOThreadSleep.ToString(); }
        }


        public string IOCIP
        {
            set
            {
                if (IOCIP != value)
                {
                    mSystem.IOCIP = value;
                    NotifyPropertyChanged("IOCIP");
                }
            }
            get { return mSystem.IOCIP; }
        }

        public string VisionIP
        {
            set
            {
                if (VisionIP != value)
                {
                    mSystem.VisionIP = value;
                    NotifyPropertyChanged("VisionIP");
                }
            }
            get { return mSystem.VisionIP; }
        }

        public int IOCPortNo
        {
            set
            {
                if (IOCPortNo != value)
                {
                    mSystem.IOCPortNumber = value;
                    NotifyPropertyChanged("IOCPortNo");
                    NotifyPropertyChanged("IOCPortNumber");
                }
            }
            get { return mSystem.IOCPortNumber; }
        }
        public string IOCPortNumber
        {
            set
            {
                if (IOCPortNumber != value)
                {
                    int i;
                    if (int.TryParse(value, out i))
                        IOCPortNo = i;
                }
            }
            get { return IOCPortNo.ToString(); }
        }

        public int MachineNo
        {
            set
            {
                if (MachineNo != value)
                {
                    mSystem.MachineNumber = value;
                    NotifyPropertyChanged("MachineNo");
                    NotifyPropertyChanged("MachineNumber");
                }
            }
            get { return mSystem.MachineNumber; }
        }
        public string MachineNumber
        {
            set
            {
                if (MachineNumber != value)
                {
                    int i;
                    if (int.TryParse(value, out i))
                        MachineNo = i;
                }
            }
            get { return MachineNo.ToString(); }
        }

        public string MachineName
        {
            set
            {
                if (MachineName != value)
                {
                    mSystem.MachineName = value;
                    NotifyPropertyChanged("MachineName");
                }
            }
            get { return mSystem.MachineName; }
        }

        #endregion

        #region Recipe data section

        public ObservableCollection<RecipeData> RecipeDatas { get; set; }
        public ObservableCollection<RecipeParam> ProcDatas { get; set; }

        RecipeParam mCurrentProcess;
        public RecipeParam CurrentProcess
        {
            set
            {
                //if (mCurrentProcess != null && mCurrentProcess.Process == value.Process) return;
                mCurrentProcess = value;

                NotifyPropertyChanged("CurrentProcess");
                // base
                NotifyPropertyChanged("IsEnableSetting");
                NotifyPropertyChanged("IsTrayJob");
                NotifyPropertyChanged("JobName");
                NotifyPropertyChanged("IsInspect");
                // model
                NotifyPropertyChanged("Score");
                NotifyPropertyChanged("Distance");
                NotifyPropertyChanged("Count");
                NotifyPropertyChanged("Angle");
                NotifyPropertyChanged("Length");
                NotifyPropertyChanged("Tolerence");
                NotifyPropertyChanged("FindEmpty_Score");
                NotifyPropertyChanged("UseScore");
                NotifyPropertyChanged("IsHigh");
                NotifyPropertyChanged("IsLow");
                NotifyPropertyChanged("UpperRate");
                NotifyPropertyChanged("LowerRate");
                NotifyPropertyChanged("TapeD1");
                NotifyPropertyChanged("TapeD2");
                NotifyPropertyChanged("TapeDistTolerance");
                NotifyPropertyChanged("TapeTheta");
                NotifyPropertyChanged("TapeAngleTolerance");

                // robot
                NotifyPropertyChanged("CalibrationName");
                NotifyPropertyChanged("XLimitMIN");
                NotifyPropertyChanged("YLimitMIN");
                NotifyPropertyChanged("ThetaLimitMIN");
                NotifyPropertyChanged("XLimitMAX");
                NotifyPropertyChanged("YLimitMAX");
                NotifyPropertyChanged("ThetaLimitMAX");
                NotifyPropertyChanged("StrTrayWidth");
                NotifyPropertyChanged("StrTrayHeight");
                NotifyPropertyChanged("StrTrayTolerance");

                //NotifyPropertyChanged("Reference_X");
                //NotifyPropertyChanged("Reference_Y");
                //NotifyPropertyChanged("Reference_T");
                //NotifyPropertyChanged("Tolerence_X");
                //NotifyPropertyChanged("Tolerence_Y");
                //NotifyPropertyChanged("Tolerence_T");

                // Pocket Distance Interlock
                NotifyPropertyChanged("Distance_X");
                NotifyPropertyChanged("Distance_Y");
                NotifyPropertyChanged("Tolerence_X");
                NotifyPropertyChanged("Tolerence_Y");

            }
            get { return mCurrentProcess; }
        }

        Visibility mIsShowTrayEdit;
        public Visibility IsShowTrayEdit
        {
            get { return mIsShowTrayEdit; }
            set
            {
                if (mIsShowTrayEdit == value) return;
                mIsShowTrayEdit = value;
                NotifyPropertyChanged("IsShowTrayEdit");
            }
        }

        Visibility mIsShowTapeInspection;
        public Visibility IsShowTapeInspection
        {
            get { return mIsShowTapeInspection; }
            set
            {
                if (mIsShowTapeInspection == value) return;
                mIsShowTapeInspection = value;
                NotifyPropertyChanged("IsShowTapeInspection");
            }
        }

        Visibility mIsShowLoadPosEdit;
        public Visibility IsShowLoadPosEdit
        {
            get { return mIsShowLoadPosEdit; }
            set
            {
                if (mIsShowLoadPosEdit == value) return;
                mIsShowLoadPosEdit = value;
                NotifyPropertyChanged("IsShowLoadPosEdit");
            }
        }

        public bool IsEnableSetting { get { return CurrentProcess != null; } }
        public string JobName
        {
            set
            {
                if (JobName == value) return;
                if (CurrentProcess == null) return;
                CurrentProcess.Job.Name = value;
            }
            get { return (CurrentProcess == null || string.IsNullOrEmpty(CurrentProcess.Job.Name)) ? null : CurrentProcess.Job.Name; }
        }
        public string Score
        {
            set
            {
                if (Score == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.ModelData.ScoreCreteria = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.ScoreCreteria.ToString(); }
        }

        public string Distance
        {
            set
            {
                if (Distance == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.ModelData.FindLineDist = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.FindLineDist.ToString(); }
        }
        public string Count
        {
            set
            {
                if (Count == value) return;
                if (CurrentProcess == null) return;
                int i;
                if (int.TryParse(value, out i))
                    CurrentProcess.ModelData.FindLineNG = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.FindLineNG.ToString(); }
        }
        public string Angle
        {
            set
            {
                if (Angle == value) return;
                if (CurrentProcess == null) return;
                float i;
                if (float.TryParse(value, out i))
                    CurrentProcess.ModelData.IntersectLineAngle = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.IntersectLineAngle.ToString(); }
        }
        public string Length
        {
            set
            {
                if (Length == value) return;
                if (CurrentProcess == null) return;
                float i;
                if (float.TryParse(value, out i))
                    CurrentProcess.ModelData.IntersectLineLength = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.IntersectLineLength.ToString(); }
        }
        public string Tolerence
        {
            set
            {
                if (Tolerence == value) return;
                if (CurrentProcess == null) return;
                float i;
                if (float.TryParse(value, out i))
                    CurrentProcess.ModelData.LineLengthTolerence = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.LineLengthTolerence.ToString(); }
        }

        public string TapeD1
        {
            set
            {
                if (TapeD1 == value) return;
                if (CurrentProcess == null) return;
                float i;
                if (float.TryParse(value, out i))
                    CurrentProcess.ModelData.TapeD1 = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.TapeD1.ToString(); }
        }
        public string TapeD2
        {
            set
            {
                if (TapeD2 == value) return;
                if (CurrentProcess == null) return;
                float i;
                if (float.TryParse(value, out i))
                    CurrentProcess.ModelData.TapeD2 = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.TapeD2.ToString(); }
        }

        public string TapeDistTolerance
        {
            set
            {
                if (TapeDistTolerance == value) return;
                if (CurrentProcess == null) return;
                float i;
                if (float.TryParse(value, out i))
                    CurrentProcess.ModelData.TapeDistTolerance = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.TapeDistTolerance.ToString(); }
        }

        public string TapeTheta
        {
            set
            {
                if (TapeTheta == value) return;
                if (CurrentProcess == null) return;
                float i;
                if (float.TryParse(value, out i))
                    CurrentProcess.ModelData.TapeTheta = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.TapeTheta.ToString(); }
        }

        public string TapeAngleTolerance
        {
            set
            {
                if (TapeAngleTolerance == value) return;
                if (CurrentProcess == null) return;
                float i;
                if (float.TryParse(value, out i))
                    CurrentProcess.ModelData.TapeAngleTolerance = i;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.TapeAngleTolerance.ToString(); }
        }
        /* Panel Inspection Parameter */
        public Visibility IsInspect
        {
            get
            {
                return (CurrentProcess == null) ?
                    (Visibility.Hidden) :
                    (mSystem.DicProcess[CurrentProcess.Process].UseInspect ? Visibility.Visible : Visibility.Hidden);
            }
        }

        public string UpperRate
        {
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.ExistHigh.ToString("F2"); }
            set
            {
                if (UpperRate == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.ModelData.ExistHigh = f;
            }
        }

        public string LowerRate
        {
            get { return CurrentProcess == null ? "" : CurrentProcess.ModelData.ExistLow.ToString("F2"); }
            set
            {
                if (LowerRate == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.ModelData.ExistLow = f;
            }
        }

        public bool IsHigh
        {
            get
            {
                return CurrentProcess == null ? false : CurrentProcess.ModelData.Polarity == ePolarity.High;
            }
            set
            {
                if (CurrentProcess == null) return;
                CurrentProcess.ModelData.Polarity = value ? ePolarity.High : ePolarity.Low;
            }
        }
        public bool IsLow
        {
            get
            {
                return CurrentProcess == null ? false : CurrentProcess.ModelData.Polarity == ePolarity.Low;
            }
            set
            {
                if (CurrentProcess == null) return;
                CurrentProcess.ModelData.Polarity = value ? ePolarity.Low : ePolarity.High;
            }
        }


        public string CalibrationName
        {
            set
            {
                if (CalibrationName == value) return;
                if (CurrentProcess == null) return;
                CurrentProcess.RobotData.CalibrationNames = value;
            }
            get { return (CurrentProcess == null || string.IsNullOrEmpty(CurrentProcess.RobotData.CalibrationNames)) ? null : CurrentProcess.RobotData.CalibrationNames; }
        }
        public string XLimitMIN
        {
            set
            {
                if (XLimitMIN == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.LimitDatas.XLimitMIN = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.LimitDatas.XLimitMIN.ToString(); }
        }


        public string YLimitMIN
        {
            set
            {
                if (YLimitMIN == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.LimitDatas.YLimitMIN = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.LimitDatas.YLimitMIN.ToString(); }
        }
        public string ThetaLimitMIN
        {
            set
            {
                if (ThetaLimitMIN == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.LimitDatas.ThetaLimitMIN = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.LimitDatas.ThetaLimitMIN.ToString(); }
        }
        public string XLimitMAX
        {
            set
            {
                if (XLimitMAX == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.LimitDatas.XLimitMAX = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.LimitDatas.XLimitMAX.ToString(); }
        }
        public string YLimitMAX
        {
            set
            {
                if (YLimitMAX == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.LimitDatas.YLimitMAX = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.LimitDatas.YLimitMAX.ToString(); }
        }
        public string ThetaLimitMAX
        {
            set
            {
                if (ThetaLimitMAX == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.LimitDatas.ThetaLimitMAX = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.LimitDatas.ThetaLimitMAX.ToString(); }
        }


        // tray size 
        public string StrTrayWidth
        {
            set
            {
                if (StrTrayWidth == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.TrayWidth = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayWidth.ToString(); }
        }
        public string StrTrayHeight
        {
            set
            {
                if (StrTrayHeight == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.TrayHeight = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayHeight.ToString(); }
        }
        public string StrTrayTolerance
        {
            set
            {
                if (StrTrayTolerance == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.TrayTolerance = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayTolerance.ToString(); }
        }

        /// <summary>
        ///  Pocket Distance Interlock
        /// </summary>
        public string Distance_X
        {
            set
            {
                if (Distance_X == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.PocketDistances.XDistance = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.PocketDistances.XDistance.ToString(); }
        }
        
        public string Distance_Y
        {
            set
            {
                if (Distance_Y == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.PocketDistances.YDistance = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.PocketDistances.YDistance.ToString(); }
        }

        public string Tolerence_X
        {
            set
            {
                if (Tolerence_X == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.PocketDistances.XTolerence= f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.PocketDistances.XTolerence.ToString(); }
        }

        public string Tolerence_Y
        {
            set
            {
                if (Tolerence_Y == value) return;
                if (CurrentProcess == null) return;
                float f;
                if (float.TryParse(value, out f))
                    CurrentProcess.RobotData.PocketDistances.YTolerence = f;
            }
            get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.PocketDistances.YTolerence.ToString(); }
        }

        //public string Reference_X
        //{
        //    set
        //    {
        //        if (Reference_X == value) return;
        //        if (CurrentProcess == null) return;
        //        float f;
        //        if (float.TryParse(value, out f))
        //            CurrentProcess.RobotData.TrayReferences.XReference = f;
        //    }
        //    get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayReferences.XReference.ToString(); }
        //}

        //public string Reference_Y
        //{
        //    set
        //    {
        //        if (Reference_Y == value) return;
        //        if (CurrentProcess == null) return;
        //        float f;
        //        if (float.TryParse(value, out f))
        //            CurrentProcess.RobotData.TrayReferences.YReference = f;
        //    }
        //    get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayReferences.YReference.ToString(); }
        //}

        //public string Reference_T
        //{
        //    set
        //    {
        //        if (Reference_T == value) return;
        //        if (CurrentProcess == null) return;
        //        float f;
        //        if (float.TryParse(value, out f))
        //            CurrentProcess.RobotData.TrayReferences.TReference = f;
        //    }
        //    get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayReferences.TReference.ToString(); }
        //}

        //public string Tolerence_X
        //{
        //    set
        //    {
        //        if (Tolerence_X == value) return;
        //        if (CurrentProcess == null) return;
        //        float f;
        //        if (float.TryParse(value, out f))
        //            CurrentProcess.RobotData.TrayReferences.XTolerence = f;
        //    }
        //    get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayReferences.XTolerence.ToString(); }
        //}

        //public string Tolerence_Y
        //{
        //    set
        //    {
        //        if (Tolerence_Y == value) return;
        //        if (CurrentProcess == null) return;
        //        float f;
        //        if (float.TryParse(value, out f))
        //            CurrentProcess.RobotData.TrayReferences.YTolerence = f;
        //    }
        //    get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayReferences.YTolerence.ToString(); }
        //}

        //public string Tolerence_T
        //{
        //    set
        //    {
        //        if (Tolerence_T == value) return;
        //        if (CurrentProcess == null) return;
        //        float f;
        //        if (float.TryParse(value, out f))
        //            CurrentProcess.RobotData.TrayReferences.TTolerence = f;
        //    }
        //    get { return CurrentProcess == null ? "" : CurrentProcess.RobotData.TrayReferences.TTolerence.ToString(); }
        //}
        public ObservableCollection<STRPoint3d> LoadPositions { get; set; }
        public ObservableCollection<STROffsetData> AlignOffsets { get; set; }

        public string[] RootList
        {
            get { return new string[2] { "C:\\", "D:\\" }; }
        }
        public string RootPath
        {
            get { return mSystem.RootPath; } 
            set
            {
                if (mSystem.RootPath == value) return;
                mSystem.RootPath = value;
                NotifyPropertyChanged("RootPath");
            } 
        }
        #endregion
    }

    public class ProcessDataBind : BindingObject
    {
        private Main.Process name;
        private ProcessData pd;

        public ProcessDataBind(Main.Process name, ProcessData pd)
        {
            this.name = name;
            this.pd = pd;
        }

        /* binding property */
        public Main.Process ProcessName { get { return name; } }

        public bool Use
        {
            set
            {
                if (pd.Use == value) return;
                pd.Use = value;
                NotifyPropertyChanged("Use");
                NotifyPropertyChanged("IsUse_NotCommon");
                NotifyPropertyChanged("IsInspect");
            }
            get { return pd.Use; }
        }
        public bool IsNotCommon { get { return pd.Name != "Common"; } }

        public bool IsUse_NotMxCom { get { return Use && RobotType != Main.RobotType.MxCom; } }

        public int[] OrderList { get { return new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 }; } }
        public int DisplayOrder
        {
            set
            {
                if (pd.DisplayOrder == value) return;
                pd.DisplayOrder = value;
                NotifyPropertyChanged("DisplayOrder");
            }
            get { return pd.DisplayOrder; }
        }
        public bool IsUse_NotCommon { get { return Use && IsNotCommon; } }

        public Array ProcessTypes { get { return Auto.DicAutoThreadPool.Keys.ToArray(); } }
        public string ThreadName
        {
            set
            {
                if (pd.ThreadName == value) return;
                pd.ThreadName = value;
                NotifyPropertyChanged("ThreadName");
            }
            get { return pd.ThreadName; }
        }
        public bool UseInspect
        {
            set
            {
                if (pd.UseInspect == value) return;
                pd.UseInspect = value;
                NotifyPropertyChanged("UseInspect");
                NotifyPropertyChanged("IsInspect");
            }
            get { return pd.UseInspect; }
        }

        public Array InspTypes { get { return Enum.GetValues(typeof(EInspectType)); } }
        public EInspectType InspType
        {
            set
            {
                if (pd.InspectType == value) return;
                pd.InspectType = value;
                NotifyPropertyChanged("InspType");
            }
            get { return pd.InspectType; }
        }

        public Array InspTools { get { return Enum.GetValues(typeof(EInspectTool)); } }
        public EInspectTool InspTool
        {
            set
            {
                if (pd.InspectTool == value) return;
                pd.InspectTool = value;
                NotifyPropertyChanged("InspTool");
            }
            get { return pd.InspectTool; }
        }
        public bool IsInspect { get { return Use && UseInspect; } }

        public bool IsSkipAlign
        {
            set
            {
                if (pd.IsSkipAlign == value) return;
                pd.IsSkipAlign = value;
                NotifyPropertyChanged("IsSkipAlign");
            }
            get { return pd.IsSkipAlign; }
        }

        public bool WriteFDC
        {
            set
            {
                if (pd.WriteFDC == value) return;
                pd.WriteFDC = value;
                NotifyPropertyChanged("WriteFDC");
            }
            get { return pd.WriteFDC; }
        }

        public bool InspReverse
        {
            set
            {
                if (pd.InspReverse == value) return;
                pd.InspReverse = value;
                NotifyPropertyChanged("InspReverse");
            }
            get { return pd.InspReverse; }
        }


        public Array FlowTypes { get { return Enum.GetValues(typeof(PanelFlowType)); } }
        public PanelFlowType FlowType
        {
            set
            {
                if (pd.FlowType == value) return;
                pd.FlowType = value;
                NotifyPropertyChanged("FlowType");
            }
            get { return pd.FlowType; }
        }

        public Array JudgeTypes { get { return Enum.GetValues(typeof(EJudgeType)); } }
        public EJudgeType JudgeType
        {
            set
            {
                if (pd.JudgeType == value) return;
                pd.JudgeType = value;
                NotifyPropertyChanged("FlowType");
            }
            get { return pd.JudgeType; }
        }

        public bool UseAcqComp
        {
            set
            {
                if (pd.UseAcqComp == value) return;
                pd.UseAcqComp = value;
                NotifyPropertyChanged("UseAcqComp");
            }
            get { return pd.UseAcqComp; }
        }

        public bool UseManualAlign
        {
            set
            {
                if (pd.UseManualAlign == value) return;
                pd.UseManualAlign = value;
                NotifyPropertyChanged("UseManualAlign");
            }
            get { return pd.UseManualAlign; }
        }
        public bool UseVisionRetry
        {
            set
            {
                if (pd.UseVisionRetry == value) return;
                pd.UseVisionRetry = value;
                NotifyPropertyChanged("UseVisionRetry");
            }
            get { return pd.UseVisionRetry; }
        }

        // camera parameters
        public float FocalLength
        {
            set
            {
                if (FocalLength == value) return;
                pd.FocalLength = value;
                NotifyPropertyChanged("FocalLength");
                NotifyPropertyChanged("StrFocalLength");
            }
            get { return pd.FocalLength; }
        }
        public string StrFocalLength
        {
            set
            {
                if (StrFocalLength == value) return;
                float f;
                if (float.TryParse(value, out f))
                    FocalLength = f;
            }
            get { return FocalLength.ToString(); }
        }

        public float SensorWidth
        {
            set
            {
                if (SensorWidth == value) return;
                pd.SensorWidth = value;
                NotifyPropertyChanged("SensorWidth");
                NotifyPropertyChanged("StrSensorWidth");
            }
            get { return pd.SensorWidth; }
        }
        public string StrSensorWidth
        {
            set
            {
                if (StrSensorWidth == value) return;
                float f;
                if (float.TryParse(value, out f))
                    SensorWidth = f;
            }
            get { return SensorWidth.ToString(); }
        }
        public float SensorHeight
        {
            set
            {
                if (SensorHeight == value) return;
                pd.SensorHeight = value;
                NotifyPropertyChanged("SensorHeight");
                NotifyPropertyChanged("StrSensorHeight");
            }
            get { return pd.SensorHeight; }
        }
        public string StrSensorHeight
        {
            set
            {
                if (StrSensorHeight == value) return;
                float f;
                if (float.TryParse(value, out f))
                    SensorHeight = f;
            }
            get { return SensorHeight.ToString(); }
        }


        public Array IOTypes { get { return Enum.GetValues(typeof(Main.IOtype)); } }
        public Main.IOtype IOType
        {
            set
            {
                if (pd.IOParam.IOtype == value) return;
                pd.IOParam.IOtype = value;
                NotifyPropertyChanged("IOType");
            }
            get { return pd.IOParam.IOtype; }
        }

        public string InStartAddr
        {
            get { return pd.IOParam.Inputs.First().Value.ToString(); }
        }

        public string OutStartAddr
        {
            get { return pd.IOParam.Outputs.First().Value.ToString(); }
        }

        public Array RobotTypes { get { return Enum.GetValues(typeof(Main.RobotType)); } }
        public Main.RobotType RobotType
        {
            set
            {
                if (pd.RobotParam.Robottype == value) return;
                pd.RobotParam.Robottype = value;
                NotifyPropertyChanged("RobotType");
                NotifyPropertyChanged("IsUse_NotMxCom");
            }
            get { return pd.RobotParam.Robottype; }
        }
        public string IPAddr
        {
            set
            {
                if (pd.RobotParam.IPAddress == value) return;
                if (pd.RobotParam.Robottype == Main.RobotType.Robostar_Serial)
                {
                    if (!value.Contains("COM"))
                        return;
                }
                else
                {
                    if (!System.Text.RegularExpressions.Regex.IsMatch(value, @"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"))
                    {
                        if (string.IsNullOrEmpty(value)) return;
                        MessageBox.Show("Ip is wrong");
                        return;
                    }
                }
                pd.RobotParam.IPAddress = value;
                NotifyPropertyChanged("IPAddr");
            }
            get { return pd.RobotParam.IPAddress; }
        }

        public string StrInspAddr
        {
            set
            {
                if (pd.RobotParam.InspectStartAddress.ToString() == value) return;
                int i;
                if (int.TryParse(value, out i))
                {
                    pd.RobotParam.InspectStartAddress = i;
                    NotifyPropertyChanged("StrInspAddr");
                }
            }
            get { return pd.RobotParam.InspectStartAddress.ToString(); }
        }

        public string StrStartAddr
        {
            set
            {
                if (pd.RobotParam.OffsetStartAddress.ToString() == value) return;
                int i;
                if (int.TryParse(value, out i))
                {
                    pd.RobotParam.OffsetStartAddress = i;
                    NotifyPropertyChanged("StartAddr");
                }
            }
            get { return pd.RobotParam.OffsetStartAddress.ToString(); }
        }

        public string StrCellIDAddr
        {
            set
            {
                if (pd.RobotParam.CellIDAddress.ToString() == value) return;
                int i;
                if (int.TryParse(value, out i))
                {
                    pd.RobotParam.CellIDAddress = i;
                    NotifyPropertyChanged("StrCellIDAddr");
                }
            }
            get { return pd.RobotParam.CellIDAddress.ToString(); }
        }

        public string StrFDCAddr
        {
            set
            {
                if (pd.RobotParam.FDCStartAddress.ToString() == value) return;
                int i;
                if (int.TryParse(value, out i))
                {
                    pd.RobotParam.FDCStartAddress = i;
                    NotifyPropertyChanged("StrFDCAddr");
                }
            }
            get { return pd.RobotParam.FDCStartAddress.ToString(); }
        }

        public List<Main.Process> RefProcs
        {
            set { RefProcs = value; }
            get { return pd.References; }
        }

        public Dictionary<LogKind, LogConfig> LogConfigs
        {
            get
            {
                return pd.DicLogConfig;
            }
        }
    }

    public class LogConfigBind : BindingObject
    {
        private KeyValuePair<LogKind, LogConfig> kv;

        /* binding property */
        public LogKind Name { get { return kv.Key; } }
        public string StrSaveDate
        {
            set
            {
                if (kv.Value.SaveCount.ToString() == value) return;
                int n;
                if (int.TryParse(value, out n))
                {
                    kv.Value.SaveCount = n;
                    NotifyPropertyChanged("StrSaveDate");
                }

            }
            get { return kv.Value.SaveCount.ToString(); }
        }

        public bool IsSave
        {
            set
            {
                if (kv.Value.IsSave == value) return;
                kv.Value.IsSave = value;
                NotifyPropertyChanged("IsSave");
            }
            get { return kv.Value.IsSave; }
        }

        public LogConfigBind(KeyValuePair<LogKind, LogConfig> kv)
        {
            this.kv = kv;
        }

    }
    public class STRPoint3d : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        string mName;
        public string Name { get { return mName; } }

        SvPoint mPnt;
        public STRPoint3d(string name, SvPoint pnt)
        {
            mName = name;
            mPnt = pnt;
        }
        public SvPoint DBPoint { get { return mPnt; } }
        public string X
        {
            set
            {
                if (X == value) return;
                float f;
                if (float.TryParse(value, out f))
                    mPnt.X = f;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("X"));
            }
            get { return mPnt.X.ToString(); }
        }
        public string Y
        {
            set
            {
                if (Y == value) return;
                float f;
                if (float.TryParse(value, out f))
                    mPnt.Y = f;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("Y"));
            }
            get { return mPnt.Y.ToString(); }
        }
        public string T
        {
            set
            {
                if (T == value) return;
                double d;
                if (double.TryParse(value, out d))
                    mPnt.ThetaRad = d;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("T"));
            }
            get { return mPnt.ThetaRad.ToString(); }
        }
    }
    public class STROffsetData : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        string mName;
        public string Name { get { return mName; } }

        OffsetData mOfs;
        public OffsetData DBOffset { get { return mOfs; } }
        public STROffsetData(string name, OffsetData ofs)
        {
            mName = name;
            mOfs = ofs;
        }
        public string OK_X
        {
            set
            {
                if (OK_X == value) return;
                float f;
                if (float.TryParse(value, out f))
                    mOfs.XOffset = f;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("OK_X"));
            }
            get { return mOfs.XOffset.ToString(); }
        }
        public string OK_Y
        {
            set
            {
                if (OK_Y == value) return;
                float f;
                if (float.TryParse(value, out f))
                    mOfs.YOffset = f;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("OK_Y"));
            }
            get { return mOfs.YOffset.ToString(); }
        }
        public string OK_T
        {
            set
            {
                if (OK_T == value) return;
                float f;
                if (float.TryParse(value, out f))
                    mOfs.ThetaOffset = f;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("OK_T"));
            }
            get { return mOfs.ThetaOffset.ToString(); }
        }
        public string NG_X
        {
            set
            {
                if (NG_X == value) return;
                float f;
                if (float.TryParse(value, out f))
                    mOfs.NG_X_Offset = f;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("NG_X"));
            }
            get { return mOfs.NG_X_Offset.ToString(); }
        }
        public string NG_Y
        {
            set
            {
                if (NG_Y == value) return;
                float f;
                if (float.TryParse(value, out f))
                    mOfs.NG_Y_Offset = f;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("NG_Y"));
            }
            get { return mOfs.NG_Y_Offset.ToString(); }
        }
        public string NG_T
        {
            set
            {
                if (NG_T == value) return;
                float f;
                if (float.TryParse(value, out f))
                    mOfs.NG_Th_Offset = f;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("NG_T"));
            }
            get { return mOfs.NG_Th_Offset.ToString(); }
        }
    }
}
