﻿namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    partial class Log
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_Log = new System.Windows.Forms.DataGridView();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.cl_DateSelector = new System.Windows.Forms.MonthCalendar();
            this.cblSelLog = new System.Windows.Forms.CheckedListBox();
            this.dp_startDate = new System.Windows.Forms.DateTimePicker();
            this.dp_endDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Log)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dg_Log
            // 
            this.dg_Log.AllowUserToAddRows = false;
            this.dg_Log.AllowUserToDeleteRows = false;
            this.dg_Log.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dg_Log.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dg_Log.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Log.Location = new System.Drawing.Point(396, 22);
            this.dg_Log.Name = "dg_Log";
            this.dg_Log.ReadOnly = true;
            this.dg_Log.RowTemplate.Height = 23;
            this.dg_Log.Size = new System.Drawing.Size(973, 876);
            this.dg_Log.TabIndex = 0;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.Location = new System.Drawing.Point(138, 618);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(153, 42);
            this.btn_Refresh.TabIndex = 2;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = true;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // cl_DateSelector
            // 
            this.cl_DateSelector.Location = new System.Drawing.Point(87, 63);
            this.cl_DateSelector.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.cl_DateSelector.MaxSelectionCount = 32767;
            this.cl_DateSelector.Name = "cl_DateSelector";
            this.cl_DateSelector.TabIndex = 4;
            this.cl_DateSelector.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.cl_DateSelector_DateChanged);
            // 
            // cblSelLog
            // 
            this.cblSelLog.CheckOnClick = true;
            this.cblSelLog.FormattingEnabled = true;
            this.cblSelLog.Location = new System.Drawing.Point(101, 499);
            this.cblSelLog.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cblSelLog.Name = "cblSelLog";
            this.cblSelLog.Size = new System.Drawing.Size(214, 50);
            this.cblSelLog.TabIndex = 5;
            // 
            // dp_startDate
            // 
            this.dp_startDate.Location = new System.Drawing.Point(87, 383);
            this.dp_startDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dp_startDate.Name = "dp_startDate";
            this.dp_startDate.Size = new System.Drawing.Size(176, 28);
            this.dp_startDate.TabIndex = 6;
            this.dp_startDate.ValueChanged += new System.EventHandler(this.dp_Date_ValueChanged);
            // 
            // dp_endDate
            // 
            this.dp_endDate.Location = new System.Drawing.Point(139, 415);
            this.dp_endDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dp_endDate.Name = "dp_endDate";
            this.dp_endDate.Size = new System.Drawing.Size(176, 28);
            this.dp_endDate.TabIndex = 6;
            this.dp_endDate.ValueChanged += new System.EventHandler(this.dp_Date_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 346);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 18);
            this.label1.TabIndex = 7;
            this.label1.Text = "▶ 범위 지정";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 11F);
            this.label2.Location = new System.Drawing.Point(106, 415);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 22);
            this.label2.TabIndex = 7;
            this.label2.Text = "~";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "▶ 날자 선택";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(84, 476);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "▶ 로그 선택";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.dp_endDate);
            this.panel1.Controls.Add(this.dp_startDate);
            this.panel1.Controls.Add(this.cblSelLog);
            this.panel1.Controls.Add(this.cl_DateSelector);
            this.panel1.Controls.Add(this.btn_Refresh);
            this.panel1.Controls.Add(this.dg_Log);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1460, 920);
            this.panel1.TabIndex = 8;
            // 
            // Log
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.panel1);
            this.Name = "Log";
            this.Size = new System.Drawing.Size(1460, 920);
            ((System.ComponentModel.ISupportInitialize)(this.dg_Log)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_Log;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.MonthCalendar cl_DateSelector;
        private System.Windows.Forms.CheckedListBox cblSelLog;
        private System.Windows.Forms.DateTimePicker dp_startDate;
        private System.Windows.Forms.DateTimePicker dp_endDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
    }
}