﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SvMip.Common;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// LogView.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class LogView : System.Windows.Controls.UserControl
    {
        Progress pbar = new Progress();
        public ObservableCollection<CheckedListItem<Customer>> Customers { get; set; }
        string logDir;
        public LogView()
        {
            InitializeComponent();
            //SvLogger log = new SvLogger();
            logDir = SvLogger.Log.m_strLog; //Log 중복 기록 현상 조치 (TKL, 20.03.30)
            string[] strLoggerType = Enum.GetNames(typeof(SvLogger.LogType));
            Customers = new ObservableCollection<CheckedListItem<Customer>>();

            for (int i = 0; i < strLoggerType.Length; i++)
            {
                Customers.Add(new CheckedListItem<Customer>(new Customer() { Name = strLoggerType[i] }, true)); // all types are shown at first
            }

            cblSelLog.ItemsSource = Customers;

            initDatePicker();

            btn_Refresh_Click(this, null);
        }

        private void initDatePicker()
        {
            dp_startDate.SelectedDate = cl_DateSelector.DisplayDate;
            dp_endDate.SelectedDate = cl_DateSelector.DisplayDate;
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            pbar.Show();            
            mLoaded = GetLogList();
            ApplyFilter();
            pbar.pBar.Value += 1;
            pbar.Hide();
        }

        // ---- search, quick type filters and CSV export ----
        List<LogData> mLoaded = new List<LogData>();
        List<LogData> mShown = new List<LogData>();

        void ApplyFilter()
        {
            string text = (txtSearch.Text ?? "").Trim();
            if (text.Length == 0)
                mShown = mLoaded;
            else
                mShown = mLoaded.Where(d => Contains(d.Message, text) || Contains(d.Type, text) || Contains(d.Time, text) || Contains(d.Date, text)).ToList();
            dg_Log.ItemsSource = mShown;
            txtCount.Text = mShown.Count + " / " + mLoaded.Count + " lines";
        }

        static bool Contains(string s, string text)
        {
            return s != null && s.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (mLoaded == null || txtCount == null) return;
            ApplyFilter();
        }

        private void btn_ErrorsOnly_Click(object sender, RoutedEventArgs e)
        {
            foreach (CheckedListItem<Customer> c in Customers) c.IsChecked = (c.Item.Name == "ERROR");
            btn_Refresh_Click(this, null);
        }

        private void btn_AllTypes_Click(object sender, RoutedEventArgs e)
        {
            foreach (CheckedListItem<Customer> c in Customers) c.IsChecked = true;
            btn_Refresh_Click(this, null);
        }

        private void btn_Export_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "CSV files (*.csv)|*.csv";
            dlg.FileName = "log_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv";
            if (dlg.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("Date,Time,Type,Message");
                foreach (LogData d in mShown)
                    sb.AppendLine(Csv(d.Date) + "," + Csv(d.Time) + "," + Csv(d.Type) + "," + Csv(d.Message));
                File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
                System.Windows.MessageBox.Show(mShown.Count + " lines saved.", "Export", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Export", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        static string Csv(string s)
        {
            if (s == null) return "";
            if (s.IndexOfAny(new char[] { ',', '"', '\r', '\n' }) >= 0) return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }


        List<string> GetLogFileList()
        {
            if (!Directory.Exists(logDir))
                Directory.CreateDirectory(logDir);

            string[] logFiles = Directory.GetFiles(logDir, "*.log", SearchOption.TopDirectoryOnly);

            List<string> selectLogFile = new List<string>();

            for (int i = 0; i < logFiles.Length; i++)
            {
                try
                {
                    long date = long.Parse(System.IO.Path.GetFileNameWithoutExtension(logFiles[i]).Substring(4));
                    long startDate = long.Parse(dp_startDate.SelectedDate.Value.ToString("yyyyMMdd"));
                    long endDate = long.Parse(dp_endDate.SelectedDate.Value.ToString("yyyyMMdd"));
                    if (startDate <= date && endDate >= date)
                        selectLogFile.Add(logFiles[i]);
                }
                catch
                {
                    continue;
                }
            }

            return selectLogFile;
        }
        
        List<LogData> GetLogList()
        {
            List<LogData> logList = LoadLog(GetLogFileList());
            return logList;
        }

        List<LogData> LoadLog(List<string> logFile)
        {
            StringBuilder sbMessage = new StringBuilder();

            StreamReader sr = null;
            List<LogData> list = new List<LogData>();

            pbar.pBar.Maximum = logFile.Count + 1;
            pbar.pBar.Value = 0;

            int count = 0;
            for (int i = 0; i < logFile.Count; i++)
            {
                pbar.pBar.Value = i;
                using (sr = new StreamReader(new FileStream(logFile[i], FileMode.Open, FileAccess.Read, FileShare.Read)))
                {
                    while (!sr.EndOfStream)
                    {
                        try
                        {
                            string[] log = sr.ReadLine().Split(',');
                            if (log.Length < 4)
                                throw new Exception("로그 형식 잘못됨");

                            LogData data = new LogData();
                            data.No = ++count;
                            data.Date = log[0];
                            data.Time = log[1];
                            data.Type = log[2];
                            bool selectFlag = false;
                            
                            for (int k = 0; k < Customers.Count; k++)
                            {
                                //if (cblSelLog.CheckedItems[k] as string == data.Type)
                                if (Customers[k].IsChecked == true)
                                {
                                    if((Customers[k].Item.Name.ToString() as string) == data.Type)
                                    {
                                        selectFlag = true; break;
                                    }
                                }
                            }

                            if (selectFlag == false) continue;

                            for (int j = 3; j < log.Length; j++)
                            {
                                sbMessage.Append(log[j]);
                            }
                            data.Message = sbMessage.ToString();
                            sbMessage.Clear();

                            list.Add(data);
                        }
                        catch
                        {
                            continue;
                        }
                    }
                }
            }
            return list;
        }      

        class Progress : Form
        {
            public System.Windows.Forms.ProgressBar pBar = new System.Windows.Forms.ProgressBar();

            public Progress()
            {
                this.Padding = Padding.Empty;
                this.ClientSize = new System.Drawing.Size(250, 60);
                this.StartPosition = FormStartPosition.CenterScreen;
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                this.Controls.Add(pBar);
                pBar.Location = new System.Drawing.Point(0, 0);
                pBar.Size = new System.Drawing.Size(325, 60);
                pBar.Margin = Padding.Empty;
            }
        }

        List<DateTime> dtList;
        private void cl_DateSelector_DateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cl_DateSelector.SelectedDates == null || cl_DateSelector.SelectedDates.Count == 0)
                return;

            else
            {
                dtList = cl_DateSelector.SelectedDates.ToList();
                dtList.Sort((a, b) => a.Date.CompareTo(b.Date));

                dp_startDate.SelectedDate = dtList[0];
                dp_endDate.SelectedDate = dtList[dtList.Count-1];
            }
        }

        private void dp_Date_ValueChanged(object sender, SelectionChangedEventArgs e)
        {
            // start 또는 end DateTime이 없는 경우
            if (dp_startDate.SelectedDate == null || dp_endDate.SelectedDate == null) return;

            // DateTime이 존재한다면 Range 설정
            cl_DateSelector.SelectedDates.AddRange(dp_startDate.SelectedDate.Value, dp_endDate.SelectedDate.Value);
        }

        public class Customer
        {
            public string Name { get; set; }
        }

        public class CheckedListItem<T> : INotifyPropertyChanged
        {
            public event PropertyChangedEventHandler PropertyChanged;

            private bool isChecked;
            private T item;

            public CheckedListItem()
            { }

            public CheckedListItem(T item, bool isChecked = false)
            {
                this.item = item;
                this.isChecked = isChecked;
            }

            public T Item
            {
                get { return item; }
                set
                {
                    item = value;
                    if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Item"));
                }
            }

            public bool IsChecked
            {
                get { return isChecked; }
                set
                {
                    isChecked = value;
                    if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("IsChecked"));
                }
            }
        }
    }    
}
