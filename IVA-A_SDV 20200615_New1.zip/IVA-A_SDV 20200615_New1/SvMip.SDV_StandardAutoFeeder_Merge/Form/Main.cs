﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Interface;
using SvMip.Util;
using SvMip.Common;
using System.Windows.Forms.Integration;
using System.ComponentModel;
using System.IO;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public partial class Main : Form
    {
        public static bool m_bEnableBotton = false;

        public enum Process { Common, Object1, Object2, Tray1, Tray2, LoadInspection, Barcode1 };
        public enum RobotType { /*ABB, Nachi,*/ MxCom, Opc, Msg, Socket_Client, /*Socket_Server, EOTech,*/ Robostar_Serial }
        public enum IOtype { DIO, MxCom/*, Nachi*/, Opc, Msg, Socket_Client/*, Socket_Server*/ , Yoi_DIO, Virtual}

        public static Dictionary<ViewName, ViewModelBase> DicSubViews = new Dictionary<ViewName, ViewModelBase>();

        public Main()
        {
            InitializeComponent();
            //SvLogger.Log.RollOverImage();
            //SvLogger.Log.RollOverLog();
            SystemData sys = new SystemData();
            sys.LoadData(); // Root Path만 참조한다.
            LoadMainForm();
        }

        public static IntPtr MainHandle;
        public static MainFrame ucMain;
        VMMainFrame ViewModel;
        void LoadMainForm()
        {
            ucMain = new MainFrame();
            ViewModel = Main.DicSubViews[ViewName.Auto] as VMMainFrame;

            ElementHost host = new ElementHost();
            host.Dock = DockStyle.Fill;
            host.Child = ucMain;
            ContentPanel.Controls.Add(host);

            ucMain.PreviewMouseDoubleClick += UcMain_PreviewMouseDoubleClick;
        }

        private void UcMain_PreviewMouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if(e.OriginalSource is System.Windows.Controls.Image)
            {
                this.WindowState = FormWindowState.Minimized;
            }
        }

        public static void Exit()
        {
            System.Diagnostics.Process.GetCurrentProcess().Close();
            SvAcquisition.CloseCamlist();
            Application.Exit();
        }

        public static string SystemPath
        {
            get
            {
                return Path.Combine(RootPath, "SVL_Data", "System");
            }
        }
        public static string RootPath = "C:\\";

        public static string RecipePath
        {
            get
            {
                return Path.Combine(RootPath, "SVL_Data", "Recipe");
            }
        }

        public static string JobPath
        {
            get
            {
                return Path.Combine(RootPath, "SVL_Data", "Job");
            }
        }

        public static string CalibPath
        {
            get
            {
                return Path.Combine(RootPath, "SVL_Data", "Calibration");
            }
        }
    }
    
    public abstract class BindingObject : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
    }

    public class ViewModelBase : BindingObject
    {

    }

    public enum ViewName
    {
        MainFrame,
        Auto,
        Vision,
        Teaching,
        Data,
        Log,
    }
}
