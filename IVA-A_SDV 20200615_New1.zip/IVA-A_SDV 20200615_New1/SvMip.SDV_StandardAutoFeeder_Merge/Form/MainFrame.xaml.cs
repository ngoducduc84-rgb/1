﻿using SvMip.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// MainFrame.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainFrame : UserControl
    {
        VMMainFrame ViewModel;
        Auto mAutoView;
        public MainFrame()
        {
            Dispatcher.UnhandledException += Dispatcher_UnhandledException;
            Dispatcher.UnhandledExceptionFilter += Dispatcher_UnhandledExceptionFilter;

            InitializeComponent();

            ViewModel = new VMMainFrame();
            this.DataContext = ViewModel;
            Main.DicSubViews.Add(ViewName.MainFrame, ViewModel);            

            mAutoView = new Auto();
            VMAuto vm = Main.DicSubViews[ViewName.Auto] as VMAuto;
            vm.PropertyChanged += Auto_PropertyChanged;
        }
   
        private void Dispatcher_UnhandledExceptionFilter(object sender, DispatcherUnhandledExceptionFilterEventArgs e)
        {
            e.RequestCatch = true;
        }

        private void Dispatcher_UnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            string msg = string.Format("[{0}] {1}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"), e.Exception.ToString());
            //MessageBox.Show(msg, "처리되지 않은 예외발생", MessageBoxButton.OK, MessageBoxImage.Error);
            MessageBox.Show(msg, "Untreated exceptions", MessageBoxButton.OK, MessageBoxImage.Error);
            Console.WriteLine(msg);
            SvLogger.Log.Error(msg);
            e.Handled = true;
        }

        private void Auto_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "IsStart")
                ViewModel.Enable = !((VMAuto)sender).IsStart;
        }

        WindowsFormsHost host = new WindowsFormsHost();
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if ((ViewModel.IsVision || ViewModel.IsTeach) && !ViewModel.IsEngineer)
            {
                LoginDlg dlg = new LoginDlg();
                if (dlg.ShowDialog() == false)
                {
                    MessageBox.Show("It's wrong password!!!", "fail", MessageBoxButton.OK, MessageBoxImage.Error);
                    if (Middle.Child is Auto)
                        ViewModel.IsAuto = true;
                    else if (Middle.Child is VisionView)
                        ViewModel.IsVision = true;
                    else if (host.Child is Teaching)
                        ViewModel.IsTeach = true;
                    else if (Middle.Child is DataView)
                        ViewModel.IsData = true;
                    else if (Middle.Child is LogView)
                        ViewModel.IsLog = true;
                    return;
                }
            }

            if (Middle.Child is VisionView)
                ((VisionView)Middle.Child).DisposeContent();
            Middle.Child = null;
            if (host.Child is Teaching)
                ((Component)host.Child).Dispose();
            host.Child = null;

            if (ViewModel.IsAuto)
            {
                mAutoView.AutoView_Loaded();
                Middle.Child = mAutoView;
            }
            else if (ViewModel.IsVision)
            {
                Middle.Child = new VisionView();
            }
            else if (ViewModel.IsTeach)
            {
                host.Child = new Teaching();
                Middle.Child = host;
            }
            else if (ViewModel.IsData)
            {
                Middle.Child = new DataView();
            }
            else//isLog
            {
                Middle.Child = new LogView();
            }     
               
            SvLogger.Log.Debug("Screen Changed !!!");
            GC.Collect();
        }

        private void Operator_Click(object sender, RoutedEventArgs e)
        {
            SetEngineer(false);
        }

        private void Engineer_Click(object sender, RoutedEventArgs e)
        {
            SetEngineer(true);
        }

        /// <summary>Engineer mode needs the same password as VISION / TEACH used to ask for. Going back to Operator leaves those screens.</summary>
        void SetEngineer(bool on)
        {
            if (on == ViewModel.IsEngineer) return;
            if (on)
            {
                LoginDlg dlg = new LoginDlg();
                if (dlg.ShowDialog() == false)
                {
                    MessageBox.Show("It's wrong password!!!", "fail", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                ViewModel.IsEngineer = true;
            }
            else
            {
                ViewModel.IsEngineer = false;
                if (ViewModel.IsVision || ViewModel.IsTeach)
                    ViewModel.IsAuto = true;
            }
        }

        private void MainFrame_Loaded(object sender, RoutedEventArgs e)
        {
            ViewModel.IsAuto = true;
        }

        private void MainFrame_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            //if(e.Key == Key.Escape)
                //ExitButton_Click(this, null);
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("This Program Exit?.", "Exit", MessageBoxButton.OKCancel, MessageBoxImage.Question) == MessageBoxResult.OK)
            {
                Auto.EndAuto();
                Main.Exit();
            }
        }
    }

    public class VMMainFrame : ViewModelBase
    {
        bool mIsAuto;
        public bool IsAuto
        {
            set
            {
                if (mIsAuto != value)
                {
                    mIsAuto = value;
                    NotifyPropertyChanged("IsAuto");
                }
            }
            get { return mIsAuto; }
        }

        bool mIsVision;
        public bool IsVision
        {
            set
            {
                if (mIsVision != value)
                {
                    mIsVision = value;
                    NotifyPropertyChanged("IsVision");
                }
            }
            get { return mIsVision; }
        }

        bool mIsTeach;
        public bool IsTeach
        {
            set
            {
                if (mIsTeach != value)
                {
                    mIsTeach = value;
                    NotifyPropertyChanged("IsTeach");
                }
            }
            get { return mIsTeach; }
        }

        bool mIsData;
        public bool IsData
        {
            set
            {
                if (mIsData != value)
                {
                    mIsData = value;
                    NotifyPropertyChanged("IsData");
                }
            }
            get { return mIsData; }
        }

        bool mIsEngineer;
        /// <summary>false = Operator (watch and run), true = Engineer (VISION, TEACH, details).</summary>
        public bool IsEngineer
        {
            set
            {
                if (mIsEngineer != value)
                {
                    mIsEngineer = value;
                    NotifyPropertyChanged("IsEngineer");
                }
            }
            get { return mIsEngineer; }
        }

        bool mIsLog;
        public bool IsLog
        {
            set
            {
                if (mIsLog != value)
                {
                    mIsLog = value;
                    NotifyPropertyChanged("IsLog");
                }
            }
            get { return mIsLog; }
        }
        SystemData msystemData = new SystemData();
        public string Version { get { return string.Format("Ver {0}", History.Version); } }//프로그램 변경점 발생시 기록 할 것....
        public string EqpInfo { get { return string.Format("{0} #{1}", msystemData.MachineName, msystemData.MachineNumber); } }
        bool mEnable = true;
        public bool Enable
        {
            set
            {
                if (mEnable != value)
                {
                    mEnable = value;
                    NotifyPropertyChanged("Enable");
                }
            }
            get { return mEnable; }
        }

        public string Current { get { return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); } }

        DispatcherTimer mTimer;

        public VMMainFrame()
        {
            msystemData.LoadData();
            mTimer = new DispatcherTimer();
            mTimer.Interval = new TimeSpan(0, 0, 1);
            mTimer.Tick += MTimer_Tick;
            mTimer.Start();
        }

        private void MTimer_Tick(object sender, EventArgs e)
        {
            NotifyPropertyChanged("Current");
        }
    }
}
