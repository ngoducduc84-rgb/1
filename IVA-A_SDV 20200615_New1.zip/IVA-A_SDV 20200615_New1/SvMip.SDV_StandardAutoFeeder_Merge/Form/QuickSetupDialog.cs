﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Quick Setup: pick a ready made setup, fill in a few values, see what one cycle will look like,
    /// test the connection and add the tools (SvConnection / SvTrigger / SvSend) to the open job.
    /// </summary>
    public class QuickSetupDialog : Form
    {
        readonly List<QsTemplate> templates = QuickSetupTemplates.All();
        readonly ListBox lstTemplates = new ListBox();
        readonly Label lblDescription = new Label();
        readonly Panel pnlFields = new Panel();
        readonly TextBox txtPreview = new TextBox();
        readonly Label lblStatus = new Label();
        readonly Button btnTest = new Button();
        readonly Button btnCreate = new Button();
        readonly Button btnCancel = new Button();
        readonly Dictionary<string, TextBox> boxes = new Dictionary<string, TextBox>();
        QsTemplate current;

        /// <summary>The tools to add to the job (valid after DialogResult.OK).</summary>
        public List<SvToolBase> CreatedTools { get; private set; }

        public QuickSetupDialog()
        {
            AutoScaleMode = AutoScaleMode.None;
            Font = new Font("Segoe UI", 9f);
            Text = "Quick Setup";
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            MinimizeBox = false;
            MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            ClientSize = new Size(900, 640);

            Label lblList = new Label();
            lblList.Text = "Choose a setup";
            lblList.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            lblList.SetBounds(12, 10, 240, 22);

            lstTemplates.SetBounds(12, 36, 240, 200);
            lstTemplates.IntegralHeight = false;
            foreach (QsTemplate t in templates) lstTemplates.Items.Add(t.Title);
            lstTemplates.SelectedIndexChanged += delegate { SelectTemplate(lstTemplates.SelectedIndex); };

            lblDescription.SetBounds(270, 10, 618, 52);
            lblDescription.Font = new Font("Segoe UI", 9.5f);

            pnlFields.SetBounds(270, 66, 618, 300);
            pnlFields.AutoScroll = true;

            Label lblPrev = new Label();
            lblPrev.Text = "What one cycle looks like";
            lblPrev.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            lblPrev.SetBounds(12, 376, 400, 22);

            txtPreview.SetBounds(12, 400, 876, 170);
            txtPreview.Multiline = true;
            txtPreview.ReadOnly = true;
            txtPreview.ScrollBars = ScrollBars.Vertical;
            txtPreview.Font = new Font("Consolas", 9.5f);
            txtPreview.BackColor = Color.FromArgb(246, 246, 246);

            lblStatus.SetBounds(12, 578, 876, 22);
            lblStatus.Font = new Font("Segoe UI", 9f, FontStyle.Bold);

            btnTest.Text = "Test connection";
            btnTest.SetBounds(12, 604, 130, 28);
            btnTest.Click += delegate { RunTest(); };

            btnCreate.Text = "Add to job";
            btnCreate.SetBounds(668, 604, 120, 28);
            btnCreate.Click += delegate { Create(); };

            btnCancel.Text = "Cancel";
            btnCancel.SetBounds(794, 604, 94, 28);
            btnCancel.DialogResult = DialogResult.Cancel;
            CancelButton = btnCancel;

            Controls.Add(lblList);
            Controls.Add(lstTemplates);
            Controls.Add(lblDescription);
            Controls.Add(pnlFields);
            Controls.Add(lblPrev);
            Controls.Add(txtPreview);
            Controls.Add(lblStatus);
            Controls.Add(btnTest);
            Controls.Add(btnCreate);
            Controls.Add(btnCancel);

            lstTemplates.SelectedIndex = 0;
        }

        void SelectTemplate(int index)
        {
            if (index < 0 || index >= templates.Count) return;
            current = templates[index];
            lblDescription.Text = current.Description;
            lblStatus.Text = "";
            btnTest.Visible = (current.Test != QsTestKind.None);

            pnlFields.SuspendLayout();
            pnlFields.Controls.Clear();
            boxes.Clear();
            int y = 4;
            foreach (QsField f in current.Fields)
            {
                Label l = new Label();
                l.Text = f.Label + (f.Required ? " *" : "");
                l.SetBounds(0, y + 3, 180, 20);
                TextBox b = new TextBox();
                b.Text = f.Default;
                b.SetBounds(186, y, 150, 24);
                b.TextChanged += delegate { UpdatePreview(); };
                Label h = new Label();
                h.Text = f.Hint;
                h.ForeColor = Color.FromArgb(110, 110, 110);
                h.SetBounds(344, y + 3, 270, 20);
                pnlFields.Controls.Add(l);
                pnlFields.Controls.Add(b);
                pnlFields.Controls.Add(h);
                boxes[f.Key] = b;
                y += 30;
            }
            pnlFields.ResumeLayout();
            UpdatePreview();
        }

        Dictionary<string, string> Values()
        {
            Dictionary<string, string> v = new Dictionary<string, string>();
            foreach (KeyValuePair<string, TextBox> kv in boxes) v[kv.Key] = kv.Value.Text;
            return v;
        }

        void UpdatePreview()
        {
            if (current == null) return;
            try { txtPreview.Text = current.Preview(Values()); }
            catch (Exception ex) { txtPreview.Text = "(cannot show the example: " + ex.Message + ")"; }
        }

        void Create()
        {
            string problem = current.Check(Values());
            if (problem.Length > 0)
            {
                Say(problem, true);
                return;
            }
            CreatedTools = current.Build(Values());
            DialogResult = DialogResult.OK;
            Close();
        }

        void Say(string text, bool error)
        {
            lblStatus.Text = text;
            lblStatus.ForeColor = error ? Color.FromArgb(190, 40, 40) : Color.FromArgb(30, 120, 60);
        }

        // ------------------------------------------------------------ connection test
        void RunTest()
        {
            Dictionary<string, string> v = Values();
            Cursor old = Cursor;
            Cursor = Cursors.WaitCursor;
            try
            {
                switch (current.Test)
                {
                    case QsTestKind.ListenPort:
                        TestListen(QsTemplate.Int(v, "port", -1));
                        break;
                    case QsTestKind.ConnectTcp:
                        TestConnect(QsTemplate.Get(v, "host"), QsTemplate.Int(v, "port", -1));
                        break;
                    case QsTestKind.MxCom:
                        Say("MX Component cannot be tested from here. The connection is opened when Auto starts.", false);
                        break;
                }
            }
            finally { Cursor = old; }
        }

        void TestListen(int port)
        {
            if (port <= 0 || port > 65535) { Say("Port must be 1..65535", true); return; }
            TcpListener l = null;
            try
            {
                l = new TcpListener(IPAddress.Any, port);
                l.Start();
                Say("Port " + port + " is free: vision can listen on it.", false);
            }
            catch (Exception ex)
            {
                Say("Port " + port + " cannot be used (already in use, or blocked): " + ex.Message, true);
            }
            finally { if (l != null) { try { l.Stop(); } catch { } } }
        }

        void TestConnect(string host, int port)
        {
            if (host.Length == 0 || port <= 0 || port > 65535) { Say("Enter the IP address and the port first.", true); return; }
            TcpClient c = new TcpClient();
            try
            {
                IAsyncResult ar = c.BeginConnect(host, port, null, null);
                if (!ar.AsyncWaitHandle.WaitOne(1500))
                {
                    Say("No answer from " + host + ":" + port + " within 1.5 s.", true);
                    return;
                }
                c.EndConnect(ar);
                Say("Connected to " + host + ":" + port + ".", false);
            }
            catch (Exception ex)
            {
                Say("Cannot connect to " + host + ":" + port + ": " + ex.Message, true);
            }
            finally { try { c.Close(); } catch { } }
        }
    }
}
