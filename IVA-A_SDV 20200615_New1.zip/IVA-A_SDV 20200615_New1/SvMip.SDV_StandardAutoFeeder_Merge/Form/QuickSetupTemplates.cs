﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>One value the user types in the Quick Setup dialog.</summary>
    public class QsField
    {
        public string Key;
        public string Label;
        public string Default;
        public string Hint;
        public bool IsNumber;   // an integer (>= 0 unless AllowNegative)
        public bool Required;
        public QsField(string key, string label, string def, string hint, bool isNumber, bool required)
        {
            Key = key; Label = label; Default = def; Hint = hint; IsNumber = isNumber; Required = required;
        }
    }

    public enum QsTestKind { None, ListenPort, ConnectTcp, MxCom }

    /// <summary>A ready made job setup: the tools it creates and the values it needs.</summary>
    public class QsTemplate
    {
        public string Title;
        public string Description;
        public QsTestKind Test;
        public List<QsField> Fields = new List<QsField>();
        public Func<Dictionary<string, string>, List<SvToolBase>> Build;
        public Func<Dictionary<string, string>, string> Preview;

        /// <summary>Returns an empty string when the values are usable, otherwise a message.</summary>
        public string Check(Dictionary<string, string> v)
        {
            foreach (QsField f in Fields)
            {
                string s = Get(v, f.Key);
                if (f.Required && s.Length == 0) return f.Label + " is required";
                if (f.IsNumber && s.Length > 0)
                {
                    int n;
                    if (!int.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out n) || n < 0)
                        return f.Label + " must be a whole number (0 or more)";
                }
            }
            return "";
        }

        public static string Get(Dictionary<string, string> v, string key)
        {
            string s;
            return (v != null && v.TryGetValue(key, out s) && s != null) ? s.Trim() : "";
        }
        public static int Int(Dictionary<string, string> v, string key, int def)
        {
            int n;
            return int.TryParse(Get(v, key), NumberStyles.Integer, CultureInfo.InvariantCulture, out n) ? n : def;
        }
    }

    public static class QuickSetupTemplates
    {
        public static List<QsTemplate> All()
        {
            List<QsTemplate> list = new List<QsTemplate>();
            list.Add(TcpRequestReply());
            list.Add(PlcMx());
            list.Add(TextOverTcp());
            list.Add(ModbusTcp());
            return list;
        }

        // ---------------------------------------------------------------- helpers
        static void AddIoFields(QsTemplate t)
        {
            t.Fields.Add(new QsField("start", "Start bit address", "", "PLC to vision: start of a cycle", true, true));
            t.Fields.Add(new QsField("ready", "Ready bit address", "", "vision to PLC: ready for a cycle", true, true));
            t.Fields.Add(new QsField("ok", "OK bit address", "", "vision to PLC: result OK", true, true));
            t.Fields.Add(new QsField("ng", "NG bit address", "", "vision to PLC: result NG", true, true));
        }

        static SvTrigger IoTrigger(Dictionary<string, string> v)
        {
            SvTrigger tr = new SvTrigger();
            tr.TriggerMode = SvTriggerMode.Io;
            tr.StartAddr = QsTemplate.Int(v, "start", -1);
            tr.ReadyAddr = QsTemplate.Int(v, "ready", -1);
            tr.OkAddr = QsTemplate.Int(v, "ok", -1);
            tr.NgAddr = QsTemplate.Int(v, "ng", -1);
            return tr;
        }

        static string IoPreview(Dictionary<string, string> v, string where)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("One cycle:");
            sb.AppendLine("1. The PLC sets bit " + Show(v, "start") + " (Start).");
            sb.AppendLine("2. Vision takes the image, runs the job, and computes the result.");
            sb.AppendLine("3. " + where);
            sb.AppendLine("4. Vision sets bit " + Show(v, "ok") + " (OK) or bit " + Show(v, "ng") + " (NG); bit " + Show(v, "ready") + " (Ready) is set again when it can take the next start.");
            return sb.ToString();
        }

        static string Show(Dictionary<string, string> v, string key)
        {
            string s = QsTemplate.Get(v, key);
            return s.Length == 0 ? "?" : s;
        }

        // ---------------------------------------------------------------- 1. TCP request -> reply
        static QsTemplate TcpRequestReply()
        {
            QsTemplate t = new QsTemplate();
            t.Title = "TCP request / reply";
            t.Description = "A robot or PC sends a text such as RUN,12 over TCP. Vision runs one cycle and answers on the same connection.";
            t.Test = QsTestKind.ListenPort;
            t.Fields.Add(new QsField("conn", "Connection name", "Robot", "name used by the trigger", false, true));
            t.Fields.Add(new QsField("port", "Port to listen on", "5000", "vision is the TCP server", true, true));
            t.Fields.Add(new QsField("cmd", "Start command", "RUN", "a message starting with this text starts a cycle (empty = any message)", false, false));
            t.Fields.Add(new QsField("end", "Message end", "\\r\\n", "\\r \\n \\t are allowed", false, false));
            t.Fields.Add(new QsField("replyOk", "Reply when OK", "OK\\r\\n", "{judge} {request} {time} {cellid} {a0x:F3} {a0y:F3} {a0t:F3}", false, false));
            t.Fields.Add(new QsField("replyNg", "Reply when NG", "NG\\r\\n", "same placeholders", false, false));
            t.Build = delegate(Dictionary<string, string> v)
            {
                SvConnection c = new SvConnection();
                c.ConnName = QsTemplate.Get(v, "conn");
                c.ConnType = SvConnType.TcpServer;
                c.Port = QsTemplate.Int(v, "port", 5000);
                SvTrigger tr = new SvTrigger();
                tr.TriggerMode = SvTriggerMode.Tcp;
                tr.TriggerConnection = c.ConnName;
                tr.StartCommand = QsTemplate.Get(v, "cmd");
                tr.Terminator = QsTemplate.Get(v, "end");
                tr.ReplyOk = QsTemplate.Get(v, "replyOk");
                tr.ReplyNg = QsTemplate.Get(v, "replyNg");
                tr.AutoStart = true;
                return new List<SvToolBase> { c, tr };
            };
            t.Preview = delegate(Dictionary<string, string> v)
            {
                StringBuilder sb = new StringBuilder();
                string cmd = QsTemplate.Get(v, "cmd");
                string request = (cmd.Length == 0 ? "GO" : cmd) + ",12";
                sb.AppendLine("Robot sends:   " + request + SendTemplate.Visible(SendTemplate.Unescape(QsTemplate.Get(v, "end"))));
                sb.AppendLine("Vision runs one cycle, then answers on the same connection:");
                sb.AppendLine("  if OK:  " + Reply(QsTemplate.Get(v, "replyOk"), request, "OK"));
                sb.AppendLine("  if NG:  " + Reply(QsTemplate.Get(v, "replyNg"), request, "NG"));
                sb.AppendLine("Messages that do not start with '" + cmd + "' are ignored (and logged).");
                sb.AppendLine("A message that arrives during a cycle waits and is handled afterwards.");
                return sb.ToString();
            };
            return t;
        }

        static string Reply(string template, string request, string judge)
        {
            if (string.IsNullOrEmpty(template)) return "(no automatic reply)";
            Dictionary<string, object> values = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            values["request"] = request;
            values["judge"] = judge;
            values["time"] = "20260101_120000";
            values["cellid"] = "";
            values["a0x"] = 1.234; values["a0y"] = -2.5; values["a0t"] = 0.75;
            string text, err;
            if (!SendTemplate.TryFormat(template, values, out text, out err)) return "(template error: " + err + ")";
            return SendTemplate.Visible(text);
        }

        // ---------------------------------------------------------------- 2. PLC through MX Component
        static QsTemplate PlcMx()
        {
            QsTemplate t = new QsTemplate();
            t.Title = "PLC (MX Component)";
            t.Description = "Handshake bits and the align offsets go through a Mitsubishi PLC with MX Component (the classic way).";
            t.Test = QsTestKind.MxCom;
            t.Fields.Add(new QsField("conn", "Connection name", "PLC", "", false, true));
            t.Fields.Add(new QsField("station", "Logical station number", "1", "as set in MX Component", true, true));
            AddIoFields(t);
            t.Fields.Add(new QsField("offset", "Offset block start address", "", "where the align results (x, y, t ...) are written", true, true));
            t.Build = delegate(Dictionary<string, string> v)
            {
                SvConnection c = new SvConnection();
                c.ConnName = QsTemplate.Get(v, "conn");
                c.ConnType = SvConnType.MxCom;
                c.StationNumber = QsTemplate.Int(v, "station", -1);
                SvTrigger tr = IoTrigger(v);
                tr.OffsetStartAddress = QsTemplate.Int(v, "offset", -1);
                SvSend send = new SvSend();
                SvSendChannel ch = new SvSendChannel();
                ch.Name = "Offsets";
                ch.Kind = SvSendKind.Offsets;
                ch.StartIndex = -1; // use the offset start address of the trigger
                send.Channels.Add(ch);
                return new List<SvToolBase> { c, tr, send };
            };
            t.Preview = delegate(Dictionary<string, string> v)
            {
                return IoPreview(v, "Vision writes the align results to the PLC from address " + Show(v, "offset") + " (an SvAlign tool is needed for the values).");
            };
            return t;
        }

        // ---------------------------------------------------------------- 3. text over TCP
        static QsTemplate TextOverTcp()
        {
            QsTemplate t = new QsTemplate();
            t.Title = "Text over TCP";
            t.Description = "The PLC handshake stays as it is; the result is sent to a robot as a line of text over TCP.";
            t.Test = QsTestKind.ConnectTcp;
            t.Fields.Add(new QsField("conn", "Connection name", "Robot", "", false, true));
            t.Fields.Add(new QsField("host", "Robot IP address", "192.168.0.10", "", false, true));
            t.Fields.Add(new QsField("port", "Robot port", "9000", "", true, true));
            t.Fields.Add(new QsField("template", "Text template", "{x:F3},{y:F3},{t:F3}\\r\\n", "{x} {y} {t} are the fields below", false, true));
            AddIoFields(t);
            t.Build = delegate(Dictionary<string, string> v)
            {
                SvConnection c = new SvConnection();
                c.ConnName = QsTemplate.Get(v, "conn");
                c.ConnType = SvConnType.TcpClient;
                c.Host = QsTemplate.Get(v, "host");
                c.Port = QsTemplate.Int(v, "port", -1);
                SvTrigger tr = IoTrigger(v);
                SvSend send = new SvSend();
                SvSendChannel ch = new SvSendChannel();
                ch.Name = "Robot text";
                ch.Kind = SvSendKind.Text;
                ch.Connection = c.ConnName;
                ch.Template = QsTemplate.Get(v, "template");
                ch.Fields.Add(Field("x", "@align[0].x", SvSendValueType.Float, 0));
                ch.Fields.Add(Field("y", "@align[0].y", SvSendValueType.Float, 0));
                ch.Fields.Add(Field("t", "@align[0].t", SvSendValueType.Float, 0));
                send.Channels.Add(ch);
                return new List<SvToolBase> { c, tr, send };
            };
            t.Preview = delegate(Dictionary<string, string> v)
            {
                Dictionary<string, object> values = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                values["x"] = 1.234; values["y"] = -2.5; values["t"] = 0.75;
                string text, err;
                string shown = SendTemplate.TryFormat(QsTemplate.Get(v, "template"), values, out text, out err) ? SendTemplate.Visible(text) : "(template error: " + err + ")";
                return IoPreview(v, "Vision sends this text to " + QsTemplate.Get(v, "host") + ":" + QsTemplate.Get(v, "port") + " (example values):\r\n   " + shown);
            };
            return t;
        }

        // ---------------------------------------------------------------- 4. Modbus TCP
        static QsTemplate ModbusTcp()
        {
            QsTemplate t = new QsTemplate();
            t.Title = "Modbus TCP";
            t.Description = "The result is written as Modbus registers (function 16) to a PLC or controller; the handshake stays as it is.";
            t.Test = QsTestKind.ConnectTcp;
            t.Fields.Add(new QsField("conn", "Connection name", "Modbus", "", false, true));
            t.Fields.Add(new QsField("host", "Device IP address", "192.168.0.20", "", false, true));
            t.Fields.Add(new QsField("port", "Port", "502", "", true, true));
            t.Fields.Add(new QsField("unit", "Unit id", "1", "0..255", true, true));
            t.Fields.Add(new QsField("reg", "First register", "100", "x, y, t take 2 registers each (Float), judge takes 1", true, true));
            AddIoFields(t);
            t.Build = delegate(Dictionary<string, string> v)
            {
                SvConnection c = new SvConnection();
                c.ConnName = QsTemplate.Get(v, "conn");
                c.ConnType = SvConnType.ModbusTcp;
                c.Host = QsTemplate.Get(v, "host");
                c.Port = QsTemplate.Int(v, "port", 502);
                c.UnitId = QsTemplate.Int(v, "unit", 1);
                SvTrigger tr = IoTrigger(v);
                SvSend send = new SvSend();
                SvSendChannel ch = new SvSendChannel();
                ch.Name = "Registers";
                ch.Kind = SvSendKind.Registers;
                ch.Connection = c.ConnName;
                ch.StartIndex = QsTemplate.Int(v, "reg", 100);
                ch.Fields.Add(Field("x", "@align[0].x", SvSendValueType.Float, 0));
                ch.Fields.Add(Field("y", "@align[0].y", SvSendValueType.Float, 2));
                ch.Fields.Add(Field("t", "@align[0].t", SvSendValueType.Float, 4));
                SvSendField ok = Field("judge", "@judge", SvSendValueType.Int16, 6);
                ch.Fields.Add(ok);
                send.Channels.Add(ch);
                return new List<SvToolBase> { c, tr, send };
            };
            t.Preview = delegate(Dictionary<string, string> v)
            {
                int reg = QsTemplate.Int(v, "reg", 100);
                return IoPreview(v, "Vision writes registers of " + QsTemplate.Get(v, "host") + " (unit " + QsTemplate.Get(v, "unit") + "):\r\n   "
                    + reg + "-" + (reg + 1) + " = x (Float),  " + (reg + 2) + "-" + (reg + 3) + " = y (Float),  " + (reg + 4) + "-" + (reg + 5) + " = t (Float),  " + (reg + 6) + " = judge (1 = OK)");
            };
            return t;
        }

        static SvSendField Field(string name, string source, SvSendValueType type, int address)
        {
            SvSendField f = new SvSendField();
            f.Name = name;
            f.Source = source;
            f.ValueType = type;
            f.Address = address;
            return f;
        }
    }
}
