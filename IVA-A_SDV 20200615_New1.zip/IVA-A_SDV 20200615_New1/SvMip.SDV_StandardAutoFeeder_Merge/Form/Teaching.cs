﻿using System.Windows.Forms;
using SvMip.Interface;
using System;
using System.Linq;
using System.Collections.Generic;
#if PLCIF
using SvMip.Interface.MXCom;
#endif
using System.IO;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public partial class Teaching : UserControl
    {
        SystemData mSys = new SystemData();
        public Teaching()
        {
            InitializeComponent();

            Auto.CloseRobots();

            mSys.LoadData();

            cb_IP.Validating += (sender, e) =>
                {
                    ComboBox cb = sender as ComboBox;
                    if (comboBox1.Text == "Robostar_Serial")
                    {
                        if (!cb.Text.Contains("COM"))
                        {
                            if (string.IsNullOrEmpty(cb.Text)) return;
                            MessageBox.Show("COM Port is wrong");
                            e.Cancel = true;
                        }
                    }
                    else
                    {
                        if (!System.Text.RegularExpressions.Regex.IsMatch(cb.Text, @"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"))
                        {
                            if (string.IsNullOrEmpty(cb.Text)) return;
                            MessageBox.Show("Ip is wrong");
                            e.Cancel = true;      
                        }
                    }
                };

            this.Disposed += Teaching_Disposed;

            svCalibrationEdit1.Calibration = new Calibration.SvCalibration();
            svCalibrationEdit1.OnSaved += (sender, e) => { Auto.IsRecipeDataChanged = true; };
           this.Disposed += (sender, e) => { svCalibrationEdit1.Dispose(); };

            comboBox1.DataSource = null;
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Nachi");
            comboBox1.Items.Add("ABB");
            comboBox1.Items.Add("Robostar_Serial");
            comboBox1.Items.Add("Ethernet_Client");
            comboBox1.Items.Add("MXCOM");

            if (comboBox1.Items.Count <= 0) comboBox1.SelectedIndex = -1;
            else comboBox1.SelectedIndex = 0;

            RefreshCb_IPItems();

            btnDisconnect.Enabled = false;
            tbIndex.Enabled = false;
            tbValue.Enabled = false;
            btnRead.Enabled = false;
            btnWrite.Enabled = false;

            svCalibrationEdit1.PATH_JOB = Path.Combine(Main.RootPath, "SVL_Data", "Job");
            svCalibrationEdit1.PATH_CALIB = Path.Combine(Main.RootPath, "SVL_Data", "Calibration");
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (svCalibrationEdit1.Robot != null)
                svCalibrationEdit1.Robot.Dispose();
            
            switch(comboBox1.SelectedItem as string)
            {
                case "Nachi" :
                    svCalibrationEdit1.Robot = new Robot_Nachi(cb_IP.Text, 48952, mSys.IOThreadSleep);
                    break;
                case "ABB":
                    svCalibrationEdit1.Robot = new Robot_ABB(cb_IP.Text, 8090, mSys.IOThreadSleep);
                    break;
                case "Robostar_Serial":
                    svCalibrationEdit1.Robot = new Robot_Robostar_Serial(cb_IP.Text);
                    break;
                case "Ethernet_Client": //EOTech -> Ethernet_Client 변경_18.05.28
                    svCalibrationEdit1.Robot = new Robot_Ethernet_Client(cb_IP.Text, mSys.PortNumber, mSys.IOThreadSleep);
                    break;
#if PLCIF
                case "MXCOM":
                    svCalibrationEdit1.Robot = 
                        new Robot_MXCom_AbsAddress(mSys.DeviceType, mSys.StationNumber, mSys.DicProcess[Main.Process.Common].RobotParam.OffsetStartAddress, mSys.IOThreadSleep);
                    svCalibrationEdit1.Robot.OpenDevice();
                    break;
#endif
                default :
                    MessageBox.Show("robot must be selected");
                    svCalibrationEdit1.Robot = null;
                    return;
            }

            if (!svCalibrationEdit1.Robot.IsOpen)
            {
                MessageBox.Show("Robot not opened");
                svCalibrationEdit1.Robot.Dispose();
                svCalibrationEdit1.Robot = null;
                return;
            }

            btnConnect.Enabled = false;
            cb_IP.Enabled = false;
            btnDisconnect.Enabled = true;

            tbIndex.Enabled = true;
            tbValue.Enabled = true;
            btnRead.Enabled = true;
            btnWrite.Enabled = true;

            if (!cb_IP.Items.Contains(cb_IP.Text))
                cb_IP.Items.Insert(0, cb_IP.Text);
            for (int i = 0; i < cb_IP.Items.Count; i++)
            {
                if (i > 2) break;
                mSys.WriteValue("IPHistory", i.ToString(), cb_IP.Items[i].ToString());
            }
            RefreshCb_IPItems();
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (svCalibrationEdit1.Robot != null)
            {
                svCalibrationEdit1.Robot.CloseDevice();
                svCalibrationEdit1.Robot.Dispose();
                svCalibrationEdit1.Robot = null;
            }
            cb_IP.Enabled = true;
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;

            tbIndex.Enabled = false;
            tbValue.Enabled = false;
            btnRead.Enabled = false;
            btnWrite.Enabled = false;
        }

        void RefreshCb_IPItems()
        {
            cb_IP.Items.Clear();
            for (int i = 0; i < 3; i++)
            {
                string val = mSys.ReadValue("IPHistory", i.ToString(), "");
                if (val != "") cb_IP.Items.Add(val);
            }
        }

        void Teaching_Disposed(object sender, EventArgs e)
        {
            if (svCalibrationEdit1.Robot != null)
                svCalibrationEdit1.Robot.Dispose();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            if (svCalibrationEdit1.Robot == null)
            {
                MessageBox.Show("There is no available robot");
                return;
            }
            int index = 0;
            if (int.TryParse(tbIndex.Text, out index) == false)
            {
                MessageBox.Show("Index is invalid");
                return;
            }

            int value;
            if(svCalibrationEdit1.Robot.ReadValue(index, out value))
            {
                tbValue.Text = value.ToString();
                MessageBox.Show("Complete to read");
            }
            else
            {
                MessageBox.Show("Reading fail");
            }
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            if (svCalibrationEdit1.Robot == null)
            {
                MessageBox.Show("There is no available robot");
                return;
            }
            int index = 0;
            if (int.TryParse(tbIndex.Text, out index) == false)
            {
                MessageBox.Show("Index is invalid");
                return;
            }

            int value;
            if (int.TryParse(tbValue.Text, out value) == false)
            {
                MessageBox.Show("Value is invalid");
                return;
            }

            if (svCalibrationEdit1.Robot.WriteValue(index, value))
            {
                MessageBox.Show("Complete to write");
            }
            else
            {
                MessageBox.Show("Writing fail");
            }
        }
    }
}
