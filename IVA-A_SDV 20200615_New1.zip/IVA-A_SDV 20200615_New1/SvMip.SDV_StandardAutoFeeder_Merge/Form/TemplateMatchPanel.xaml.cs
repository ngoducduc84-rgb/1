using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using SvMip.Edit;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// New editor of the SvTemplateMatch tool (Pattern / Setting / Output) drawn in WPF.
    /// The WinForms editor (SvTemplateMatchEdit) stays as the engine: this panel only calls its API.
    /// </summary>
    public partial class TemplateMatchPanel : UserControl
    {
        [DllImport("gdi32.dll")]
        static extern bool DeleteObject(IntPtr handle);

        SvTemplateMatchEdit ed;
        bool built;
        bool loading;
        int tab;
        readonly List<Action> mUpdaters = new List<Action>();
        Brush mText, mMuted, mLine, mAccent, mCard, mBg;

        StackPanel mSlots;
        TextBlock mInputText, mRefText, mScoreText, mPriorityNote, mOutNote, mOutBadge;
        StackPanel mOutRows;
        StackPanel mPriorityRow;
        WindowsFormsHost mPatHost;
        Border[] mTabBorders;
        TextBlock[] mTabTexts;

        /// <summary>The Train picture must be shown (the pattern region is drawn on it).</summary>
        public event EventHandler TrainRequested;

        public TemplateMatchPanel()
        {
            InitializeComponent();
            mText = (Brush)FindResource("IvaTextBrush");
            mMuted = (Brush)FindResource("IvaMutedBrush");
            mLine = (Brush)FindResource("IvaLineBrush");
            mAccent = (Brush)FindResource("IvaAccentBrush");
            mCard = (Brush)FindResource("IvaCardBrush");
            mBg = (Brush)FindResource("IvaBgBrush");
        }

        // ------------------------------------------------------------------ connection to the editor
        public void Attach(SvTemplateMatchEdit editor)
        {
            if (ed != null) ed.PatternsChanged -= OnPatterns;
            ed = editor;
            ed.PatternsChanged += OnPatterns;
            if (!built) { built = true; Build(); }
            mPatHost.Child = ed.PatternView;
            Reload();
        }

        void OnPatterns(object sender, EventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(RefreshSlots));
        }

        public void Reload()
        {
            if (ed == null || ed.Subject == null) return;
            loading = true;
            try
            {
                foreach (Action a in mUpdaters) a();
                RefreshSlots();
                RefreshOutputs();
            }
            finally { loading = false; }
        }

        // ------------------------------------------------------------------ small builders
        TextBlock Cap(string text)
        {
            TextBlock t = new TextBlock();
            t.Text = text;
            t.FontSize = 12;
            t.Foreground = mMuted;
            t.Margin = new Thickness(0, 0, 0, 4);
            return t;
        }

        TextBlock Txt(string text, double size, Brush brush, FontWeight weight, bool mono)
        {
            TextBlock t = new TextBlock();
            t.Text = text;
            t.FontSize = size;
            t.Foreground = brush;
            t.FontWeight = weight;
            if (mono) t.FontFamily = new FontFamily("Consolas");
            return t;
        }

        Button Btn(string text, Action action)
        {
            Button b = new Button();
            b.Content = text;
            b.Click += delegate { action(); };
            return b;
        }

        Border Box(UIElement child)
        {
            Border b = new Border();
            b.Background = (Brush)new BrushConverter().ConvertFromString("#FF12151A");
            b.BorderBrush = mLine;
            b.BorderThickness = new Thickness(1);
            b.CornerRadius = new CornerRadius(8);
            b.Padding = new Thickness(10, 6, 10, 6);
            b.Child = child;
            return b;
        }

        Border Gap(double height)
        {
            Border b = new Border();
            b.Height = height;
            return b;
        }

        static string Fmt(double v, int decimals)
        {
            return v.ToString("F" + decimals, CultureInfo.InvariantCulture);
        }

        /// <summary>Check box: tick in a square and a text.</summary>
        FrameworkElement Check(string label, string note, string key)
        {
            DockPanel row = new DockPanel();
            row.Margin = new Thickness(0, 4, 0, 4);
            row.Background = Brushes.Transparent;
            row.Cursor = Cursors.Hand;
            Border box = new Border();
            box.Width = 20; box.Height = 20;
            box.CornerRadius = new CornerRadius(5);
            box.BorderThickness = new Thickness(1.5);
            box.Margin = new Thickness(0, 0, 10, 0);
            TextBlock tick = Txt("✓", 13, Brushes.White, FontWeights.Bold, false);
            tick.HorizontalAlignment = HorizontalAlignment.Center;
            box.Child = tick;
            DockPanel.SetDock(box, Dock.Left);
            row.Children.Add(box);
            StackPanel sp = new StackPanel { Orientation = Orientation.Horizontal };
            sp.Children.Add(Txt(label, 13, mText, FontWeights.Normal, false));
            if (!string.IsNullOrEmpty(note))
            {
                TextBlock n = Txt("  " + note, 12, mMuted, FontWeights.Normal, false);
                sp.Children.Add(n);
            }
            row.Children.Add(sp);

            Action update = delegate
            {
                bool on = ed.GetBool(key);
                box.Background = on ? mAccent : Brushes.Transparent;
                box.BorderBrush = on ? mAccent : mLine;
                tick.Visibility = on ? Visibility.Visible : Visibility.Hidden;
            };
            row.MouseLeftButtonUp += delegate
            {
                ed.SetBool(key, !ed.GetBool(key));
                Reload();
            };
            mUpdaters.Add(update);
            return row;
        }

        /// <summary>Label above a number box. Enter or leaving the box applies the value.</summary>
        FrameworkElement Field(string key, string label, bool lockedByAuto)
        {
            double min, max, step; int decimals;
            ed.GetNumberRange(key, out min, out max, out decimals, out step);

            StackPanel sp = new StackPanel();
            sp.Children.Add(Cap(label));
            TextBox tb = new TextBox();
            sp.Children.Add(tb);

            Action commit = delegate
            {
                if (loading) return;
                double v;
                if (double.TryParse(tb.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v))
                    ed.SetNumber(key, v);
                Reload();
            };
            tb.LostFocus += delegate { commit(); };
            tb.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; commit(); } };

            mUpdaters.Add(delegate
            {
                tb.Text = Fmt(ed.GetNumber(key), decimals);
                tb.IsReadOnly = lockedByAuto && ed.GetBool("AutoParam");
            });
            return sp;
        }

        Grid TwoColumns(params FrameworkElement[] items)
        {
            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) });
            g.ColumnDefinitions.Add(new ColumnDefinition());
            int rows = (items.Length + 1) / 2;
            for (int r = 0; r < rows; r++) g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            for (int i = 0; i < items.Length; i++)
            {
                items[i].Margin = new Thickness(0, 0, 0, 10);
                Grid.SetRow(items[i], i / 2);
                Grid.SetColumn(items[i], (i % 2) * 2);
                g.Children.Add(items[i]);
            }
            return g;
        }

        // ------------------------------------------------------------------ building the three tabs
        void Build()
        {
            BuildTabs();
            BuildPattern();
            BuildSetting();
            BuildOutput();
            ShowTab(0);
        }

        void BuildTabs()
        {
            string[] names = new string[] { "Pattern", "Setting", "Output" };
            mTabBorders = new Border[3];
            mTabTexts = new TextBlock[3];
            for (int i = 0; i < 3; i++)
            {
                int index = i;
                Border b = new Border();
                b.Padding = new Thickness(14, 10, 14, 8);
                b.Cursor = Cursors.Hand;
                b.Background = Brushes.Transparent;
                b.BorderThickness = new Thickness(0, 0, 0, 2);
                StackPanel sp = new StackPanel { Orientation = Orientation.Horizontal };
                TextBlock t = Txt(names[i], 12.5, mMuted, FontWeights.Normal, false);
                sp.Children.Add(t);
                if (i == 2)
                {
                    Border badge = new Border { CornerRadius = new CornerRadius(8), Padding = new Thickness(6, 0, 6, 0), Margin = new Thickness(6, 0, 0, 0), Background = (Brush)new BrushConverter().ConvertFromString("#FF222833") };
                    mOutBadge = Txt("0", 11, mText, FontWeights.SemiBold, false);
                    badge.Child = mOutBadge;
                    sp.Children.Add(badge);
                }
                b.Child = sp;
                b.MouseLeftButtonUp += delegate { ShowTab(index); };
                mTabBorders[i] = b;
                mTabTexts[i] = t;
                Tabs.Children.Add(b);
            }
        }

        void ShowTab(int index)
        {
            tab = index;
            PatternTab.Visibility = index == 0 ? Visibility.Visible : Visibility.Collapsed;
            SettingTab.Visibility = index == 1 ? Visibility.Visible : Visibility.Collapsed;
            OutputTab.Visibility = index == 2 ? Visibility.Visible : Visibility.Collapsed;
            for (int i = 0; i < 3; i++)
            {
                bool on = i == index;
                mTabBorders[i].BorderBrush = on ? mAccent : Brushes.Transparent;
                mTabTexts[i].Foreground = on ? mText : mMuted;
                mTabTexts[i].FontWeight = on ? FontWeights.SemiBold : FontWeights.Normal;
            }
            HintBar.Visibility = Visibility.Collapsed;
            if (index == 2) RefreshOutputs();
        }

        void ShowHint(string text)
        {
            Hint.Text = text;
            HintBar.Visibility = string.IsNullOrEmpty(text) ? Visibility.Collapsed : Visibility.Visible;
        }

        void BuildPattern()
        {
            StackPanel p = PatternTab;

            p.Children.Add(Cap("Input image"));
            mInputText = Txt("", 13, mText, FontWeights.Normal, true);
            p.Children.Add(Box(mInputText));
            p.Children.Add(Gap(14));

            DockPanel head = new DockPanel();
            Button grab = Btn("Grab", delegate
            {
                string hint = ed.GrabPattern();
                if (hint != null)
                {
                    ShowHint(hint);
                    if (TrainRequested != null) TrainRequested(this, EventArgs.Empty);
                }
                else ShowHint("Pattern taken from the region on the image.");
                RefreshSlots();
            });
            grab.Width = 70;
            grab.ToolTip = "Takes the pattern from the region drawn on the Train image";
            DockPanel.SetDock(grab, Dock.Right);
            head.Children.Add(grab);
            head.Children.Add(Cap("Patterns · click one to select it"));
            p.Children.Add(head);

            mSlots = new StackPanel { Orientation = Orientation.Horizontal };
            ScrollViewer sv = new ScrollViewer { HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = mSlots };
            p.Children.Add(sv);

            Grid buttons = new Grid { Margin = new Thickness(0, 8, 0, 0) };
            string[] names = new string[] { "Pattern Add", "Pattern Remove", "Pattern Load", "Pattern Save" };
            Action[] acts = new Action[]
            {
                delegate { ed.AddPatterns(); },
                delegate { ed.RemovePattern(); },
                delegate { ed.LoadPatterns(); },
                delegate { ed.SavePattern(); }
            };
            for (int i = 0; i < 4; i++)
            {
                buttons.ColumnDefinitions.Add(new ColumnDefinition());
                Action act = acts[i];
                Button b = Btn(names[i], delegate { act(); RefreshSlots(); });
                b.Margin = new Thickness(i == 0 ? 0 : 3, 0, i == 3 ? 0 : 3, 0);
                Grid.SetColumn(b, i);
                buttons.Children.Add(b);
            }
            p.Children.Add(buttons);
            p.Children.Add(Gap(14));

            p.Children.Add(Cap("Selected pattern · drag the reference point on it"));
            mPatHost = new WindowsFormsHost();
            Border patBox = new Border { Height = 190, Background = (Brush)new BrushConverter().ConvertFromString("#FF0B0E12"), CornerRadius = new CornerRadius(8), Child = mPatHost, ClipToBounds = true };
            p.Children.Add(patBox);
            p.Children.Add(Gap(10));

            // mask
            DockPanel mask = new DockPanel();
            Button reset = Btn("Reset Mask", delegate { ed.ResetMask(); });
            reset.Width = 96;
            DockPanel.SetDock(reset, Dock.Right);
            Button edit = Btn("Edit mask...", delegate { ed.EditMask(); });
            edit.Width = 104;
            edit.Margin = new Thickness(0, 0, 6, 0);
            DockPanel.SetDock(edit, Dock.Right);
            mask.Children.Add(reset);
            mask.Children.Add(edit);
            mask.Children.Add(Txt("Mask", 13, mText, FontWeights.Normal, false));
            p.Children.Add(mask);
            p.Children.Add(Gap(6));

            p.Children.Add(Check("Auto Index (+1)", "use the next pattern on each run", "IsAutoIndex"));

            p.Children.Add(Check("Use Edge Detect", "", "UseEdge"));
            Grid th = new Grid { Margin = new Thickness(30, 2, 0, 6) };
            th.ColumnDefinitions.Add(new ColumnDefinition());
            th.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) });
            th.ColumnDefinitions.Add(new ColumnDefinition());
            FrameworkElement low = Field("THLow", "TH Low", false);
            FrameworkElement high = Field("THHigh", "TH High", false);
            Grid.SetColumn(high, 2);
            th.Children.Add(low);
            th.Children.Add(high);
            p.Children.Add(th);

            // reference point
            DockPanel rp = new DockPanel { Margin = new Thickness(0, 6, 0, 0) };
            Button toCenter = Btn("Ref. To Center", delegate { ed.RefToCenter(); Reload(); });
            toCenter.Width = 110;
            DockPanel.SetDock(toCenter, Dock.Right);
            rp.Children.Add(toCenter);
            StackPanel arrows = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 8, 0) };
            string[] arrowText = new string[] { "◀", "▲", "▼", "▶" };
            int[,] delta = new int[,] { { -1, 0 }, { 0, -1 }, { 0, 1 }, { 1, 0 } };
            for (int i = 0; i < 4; i++)
            {
                int dx = delta[i, 0], dy = delta[i, 1];
                Button a = Btn(arrowText[i], delegate { ed.NudgeRef(dx, dy); Reload(); });
                a.Width = 30;
                a.Margin = new Thickness(0, 0, 3, 0);
                arrows.Children.Add(a);
            }
            DockPanel.SetDock(arrows, Dock.Right);
            rp.Children.Add(arrows);
            StackPanel rt = new StackPanel { Orientation = Orientation.Horizontal };
            rt.Children.Add(Txt("Reference point  ", 13, mText, FontWeights.Normal, false));
            mRefText = Txt("", 13, mMuted, FontWeights.Normal, true);
            rt.Children.Add(mRefText);
            rp.Children.Add(rt);
            p.Children.Add(rp);

            mUpdaters.Add(delegate
            {
                SvToolBase src = null;
                string field = "";
                InputParams ip;
                if (ed.Subject.inParams.TryGetValue("InputImage", out ip) && ip != null)
                {
                    src = ip.Instance as SvToolBase;
                    field = ip.FieldName;
                }
                mInputText.Text = src == null ? "(not linked)" : src.ToString() + "." + field;
                mRefText.Text = ed.RefPointText;
            });
        }

        void BuildSetting()
        {
            StackPanel p = SettingTab;

            // score threshold
            double min, max, step; int decimals;
            ed.GetNumberRange("PCreteria", out min, out max, out decimals, out step);
            DockPanel sh = new DockPanel();
            mScoreText = Txt("", 13, mText, FontWeights.Normal, true);
            DockPanel.SetDock(mScoreText, Dock.Right);
            sh.Children.Add(mScoreText);
            StackPanel st = new StackPanel { Orientation = Orientation.Horizontal };
            st.Children.Add(Txt("Score threshold ", 13, mText, FontWeights.Medium, false));
            st.Children.Add(Txt("(PCreteria)", 12, mMuted, FontWeights.Normal, false));
            sh.Children.Add(st);
            p.Children.Add(sh);
            Slider slider = new Slider();
            slider.Minimum = min;
            slider.Maximum = max;
            slider.SmallChange = step > 0 ? step : 0.01;
            slider.LargeChange = slider.SmallChange * 5;
            slider.IsMoveToPointEnabled = true;
            slider.Margin = new Thickness(0, 6, 0, 0);
            slider.ValueChanged += delegate
            {
                if (loading) return;
                double v = Math.Round(slider.Value, Math.Max(decimals, 2));
                ed.SetNumber("PCreteria", v);
                mScoreText.Text = Fmt(v, Math.Max(decimals, 2));
            };
            p.Children.Add(slider);
            mUpdaters.Add(delegate
            {
                double v = ed.GetNumber("PCreteria");
                slider.Value = v;
                mScoreText.Text = Fmt(v, Math.Max(decimals, 2));
            });
            p.Children.Add(Gap(16));

            // max count
            DockPanel mc = new DockPanel();
            TextBlock count = Txt("", 14, mText, FontWeights.Normal, true);
            count.Width = 30;
            count.TextAlignment = TextAlignment.Center;
            Button plus = Btn("+", delegate { ed.SetNumber("MaxCount", ed.GetNumber("MaxCount") + 1); Reload(); });
            plus.Width = 32; plus.Height = 32;
            Button minus = Btn("−", delegate { ed.SetNumber("MaxCount", ed.GetNumber("MaxCount") - 1); Reload(); });
            minus.Width = 32; minus.Height = 32;
            DockPanel.SetDock(plus, Dock.Right);
            DockPanel.SetDock(count, Dock.Right);
            DockPanel.SetDock(minus, Dock.Right);
            mc.Children.Add(plus);
            mc.Children.Add(count);
            mc.Children.Add(minus);
            StackPanel mct = new StackPanel { Orientation = Orientation.Horizontal };
            mct.Children.Add(Txt("Max Count ", 13, mText, FontWeights.Medium, false));
            mct.Children.Add(Txt("· how many matches to look for", 12, mMuted, FontWeights.Normal, false));
            mc.Children.Add(mct);
            p.Children.Add(mc);
            mUpdaters.Add(delegate { count.Text = ((int)ed.GetNumber("MaxCount")).ToString(); });
            p.Children.Add(Gap(16));

            // priority
            StackPanel pt = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 6) };
            pt.Children.Add(Txt("Priority ", 13, mText, FontWeights.Medium, false));
            pt.Children.Add(Txt("· which match becomes the output", 12, mMuted, FontWeights.Normal, false));
            p.Children.Add(pt);
            mPriorityRow = new StackPanel { Orientation = Orientation.Horizontal };
            Border seg = new Border { Background = (Brush)new BrushConverter().ConvertFromString("#FF12151A"), CornerRadius = new CornerRadius(8), Padding = new Thickness(3), Child = mPriorityRow };
            p.Children.Add(seg);
            mPriorityNote = new TextBlock { Style = (Style)FindResource("Mut"), Margin = new Thickness(0, 6, 0, 0) };
            p.Children.Add(mPriorityNote);
            mUpdaters.Add(RefreshPriority);
            p.Children.Add(Gap(14));
            p.Children.Add(new Border { Height = 1, Background = mLine });
            p.Children.Add(Gap(14));

            // automatic parameters
            p.Children.Add(Check("Auto Matching Parameter", "", "AutoParam"));
            p.Children.Add(new TextBlock { Text = "On: the program chooses scale, angle and steps. Off: you set them below.", Style = (Style)FindResource("Mut"), Margin = new Thickness(30, 0, 0, 10) });

            p.Children.Add(TwoColumns(
                Field("ScaleFirst", "Scale first", true),
                Field("ScaleLast", "Scale last", true),
                Field("AngleNeg", "Angle − (deg)", true),
                Field("AnglePos", "Angle + (deg)", true),
                Field("FirstStep", "First step", true),
                Field("Precision", "Precision", true),
                Field("TempScaleMin", "Template scale min", false),
                Field("TempScaleMax", "Template scale max", false)));
        }

        static readonly Dictionary<string, string> PriorityNotes = new Dictionary<string, string>
        {
            { "None", "No direction: the match with the best score is the output." },
            { "Left", "The match that is furthest to the left is the output." },
            { "Top", "The match that is highest in the image is the output." },
            { "Right", "The match that is furthest to the right is the output." },
            { "Bottom", "The match that is lowest in the image is the output." }
        };

        void RefreshPriority()
        {
            mPriorityRow.Children.Clear();
            string current = ed.GetPriority();
            foreach (string name in Enum.GetNames(typeof(SvTemplateMatch.Direction)))
            {
                string n = name;
                bool on = n == current;
                Border b = new Border();
                b.Padding = new Thickness(12, 5, 12, 5);
                b.CornerRadius = new CornerRadius(6);
                b.Cursor = Cursors.Hand;
                b.Background = on ? mAccent : Brushes.Transparent;
                b.Child = Txt(n, 12.5, on ? Brushes.White : mMuted, on ? FontWeights.SemiBold : FontWeights.Normal, false);
                b.MouseLeftButtonUp += delegate { ed.SetPriority(n); Reload(); };
                mPriorityRow.Children.Add(b);
            }
            string note;
            mPriorityNote.Text = PriorityNotes.TryGetValue(current, out note) ? note : "";
        }

        void BuildOutput()
        {
            StackPanel p = OutputTab;
            StackPanel head = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 6) };
            head.Children.Add(Txt("Outputs", 13, mText, FontWeights.SemiBold, false));
            mOutNote = Txt("  last run · click a row to copy its value", 12, mMuted, FontWeights.Normal, false);
            head.Children.Add(mOutNote);
            p.Children.Add(head);
            mOutRows = new StackPanel();
            p.Children.Add(mOutRows);
        }

        // ------------------------------------------------------------------ refreshing
        static BitmapSource ToSource(System.Drawing.Bitmap bmp)
        {
            IntPtr h = bmp.GetHbitmap();
            try
            {
                BitmapSource s = Imaging.CreateBitmapSourceFromHBitmap(h, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
                s.Freeze();
                return s;
            }
            finally { DeleteObject(h); }
        }

        void RefreshSlots()
        {
            if (ed == null || mSlots == null) return;
            mSlots.Children.Clear();
            int count = ed.PatternCount;
            if (count == 0)
            {
                mSlots.Children.Add(new TextBlock { Text = "No pattern yet. Show the Train image, draw a region on it and press Grab.", Style = (Style)FindResource("Mut"), Margin = new Thickness(0, 4, 0, 4), Width = 380 });
                return;
            }
            int selected = ed.SelectedPattern;
            for (int i = 0; i < count; i++)
            {
                int index = i;
                bool on = i == selected;
                Border slot = new Border();
                slot.Width = 62;
                slot.Margin = new Thickness(0, 0, 8, 0);
                slot.Padding = new Thickness(5, 5, 5, 4);
                slot.CornerRadius = new CornerRadius(8);
                slot.BorderThickness = new Thickness(1.5);
                slot.BorderBrush = on ? mAccent : mLine;
                slot.Background = on ? (Brush)new BrushConverter().ConvertFromString("#FF1F3550") : (Brush)new BrushConverter().ConvertFromString("#FF12151A");
                slot.Cursor = Cursors.Hand;
                StackPanel sp = new StackPanel();
                Border thumb = new Border { Width = 50, Height = 44, Background = (Brush)new BrushConverter().ConvertFromString("#FF0B0E12") };
                System.Drawing.Bitmap bmp = ed.GetPatternBitmap(i);
                if (bmp != null)
                {
                    try
                    {
                        Image img = new Image { Source = ToSource(bmp), Stretch = Stretch.Uniform };
                        thumb.Child = img;
                    }
                    finally { bmp.Dispose(); }
                }
                sp.Children.Add(thumb);
                TextBlock label = Txt((i + 1).ToString() + ". " + ed.GetPatternName(i), 11, on ? mText : mMuted, FontWeights.Normal, true);
                label.Margin = new Thickness(0, 3, 0, 0);
                label.TextTrimming = TextTrimming.CharacterEllipsis;
                sp.Children.Add(label);
                slot.Child = sp;
                slot.MouseLeftButtonUp += delegate { ed.SelectPattern(index); RefreshSlots(); mRefText.Text = ed.RefPointText; };
                mSlots.Children.Add(slot);
            }
        }

        static string TypeName(Type t)
        {
            if (t == typeof(float)) return "float";
            if (t == typeof(double)) return "double";
            if (t == typeof(int)) return "int";
            if (t == typeof(bool)) return "bool";
            return t.Name;
        }

        static string ValueText(object v)
        {
            if (v == null) return "—";
            if (v is float && float.IsNaN((float)v)) return "—";
            if (v is double && double.IsNaN((double)v)) return "—";
            IFormattable f = v as IFormattable;
            if (v is float || v is double) return f.ToString("0.###", CultureInfo.InvariantCulture);
            return v.ToString();
        }

        /// <summary>Shows the values of the outputs (call it after the tool ran).</summary>
        public void RefreshOutputs()
        {
            if (ed == null || ed.Subject == null || mOutRows == null) return;
            mOutRows.Children.Clear();
            SvTemplateMatch tool = ed.Subject;
            string[] names = tool.GetOutputParamNames();
            mOutBadge.Text = names.Length.ToString();
            foreach (string name in names)
            {
                PropertyInfo prop = tool.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public);
                object value = null;
                string type = "";
                if (prop != null)
                {
                    type = TypeName(prop.PropertyType);
                    try { value = prop.GetValue(tool, null); } catch (Exception) { value = null; }
                }
                string text = ValueText(value);

                Border row = new Border();
                row.BorderBrush = mLine;
                row.BorderThickness = new Thickness(0, 1, 0, 0);
                row.Padding = new Thickness(4, 6, 4, 6);
                row.Background = Brushes.Transparent;
                row.Cursor = Cursors.Hand;
                Grid g = new Grid();
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
                g.ColumnDefinitions.Add(new ColumnDefinition());
                TextBlock n = Txt(name, 13, mText, FontWeights.Normal, true);
                TextBlock ty = Txt(type, 12, mMuted, FontWeights.Normal, false);
                TextBlock val = Txt(text, 13, mText, FontWeights.Normal, true);
                val.HorizontalAlignment = HorizontalAlignment.Right;
                Grid.SetColumn(ty, 1);
                Grid.SetColumn(val, 2);
                g.Children.Add(n);
                g.Children.Add(ty);
                g.Children.Add(val);
                row.Child = g;
                row.MouseEnter += delegate { row.Background = (Brush)new BrushConverter().ConvertFromString("#FF222833"); };
                row.MouseLeave += delegate { row.Background = Brushes.Transparent; };
                string copyName = name, copyText = text;
                row.MouseLeftButtonUp += delegate
                {
                    try { Clipboard.SetText(copyText); mOutNote.Text = "  copied " + copyName + " = " + copyText; }
                    catch (Exception) { }
                };
                mOutRows.Children.Add(row);
            }
        }
    }
}
