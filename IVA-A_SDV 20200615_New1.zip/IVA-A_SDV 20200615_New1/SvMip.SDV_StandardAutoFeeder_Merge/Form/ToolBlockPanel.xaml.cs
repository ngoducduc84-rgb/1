﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using SvMip.Edit;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// WPF editor of a tool block: the inputs and outputs of the block, the tools inside it (the tree is hosted here) and the outputs now.
    /// </summary>
    public partial class ToolBlockPanel : UserControl
    {
        class Row
        {
            public string Name;
            public string Type;
        }

        SvToolBlockEdit ed;
        readonly List<Row> mIn = new List<Row>();
        readonly List<Row> mOut = new List<Row>();
        Brush mText, mMuted, mLine, mAccent;
        Border[] mTabBorders;
        TextBlock[] mTabTexts;
        TextBlock mBadgeInner, mBadgeOut;
        StackPanel mOutRows;
        TextBlock mOutNote;
        bool mTabsBuilt;
        int mTab;
        /// <summary>A tool inside the block is to be edited: return true when the editor column took it.</summary>
        public event Func<SvToolBase, bool> EditInnerRequested;
        ToolBlockHost mHost;
        VisionToolPanel mInner;

        public ToolBlockPanel()
        {
            InitializeComponent();
            mText = (Brush)FindResource("IvaTextBrush");
            mMuted = (Brush)FindResource("IvaMutedBrush");
            mLine = (Brush)FindResource("IvaLineBrush");
            mAccent = (Brush)FindResource("IvaAccentBrush");
            BtnLoad.Click += delegate
            {
                if (ed == null) return;
                ed.LoadFromFile();
                Attach(ed);
            };
        }

        static Brush Hex(string hex) { return (Brush)new BrushConverter().ConvertFromString(hex); }

        TextBlock Txt(string text, double size, Brush brush, FontWeight weight, bool mono)
        {
            TextBlock t = new TextBlock();
            t.Text = text;
            t.FontSize = size;
            t.Foreground = brush;
            t.FontWeight = weight;
            t.TextWrapping = TextWrapping.Wrap;
            if (mono) t.FontFamily = new FontFamily("Consolas");
            return t;
        }

        Button Btn(string text, Action action)
        {
            Button b = new Button();
            b.Content = text;
            b.Click += delegate { action(); };
            return b;
        }

        // ------------------------------------------------------------------ connection
        public void Attach(SvToolBlockEdit editor)
        {
            ed = editor;
            if (!mTabsBuilt) { BuildTabs(); mTabsBuilt = true; }
            mHost = new ToolBlockHost(ed);
            mHost.EditRequested = delegate(SvToolBase t) { return EditInnerRequested != null && EditInnerRequested(t); };
            mInner = new VisionToolPanel(mHost);
            InnerHost.Child = mInner;
            LoadRows();
            Reload();
            ShowTab(mTab);
        }

        void LoadRows()
        {
            mIn.Clear();
            mOut.Clear();
            foreach (KeyValuePair<string, string> kv in ed.GetInputRows()) mIn.Add(new Row { Name = kv.Key, Type = kv.Value });
            foreach (KeyValuePair<string, string> kv in ed.GetOutputRows()) mOut.Add(new Row { Name = kv.Key, Type = kv.Value });
        }

        public void Reload()
        {
            if (ed == null) return;
            BuildInterface();
            RefreshOutputs();
            UpdateInputInfo();
            try { ed.RefreshInnerTree(); } catch (Exception) { }
            if (mHost != null) mHost.RaiseRan();
        }

        // ------------------------------------------------------------------ tabs
        void BuildTabs()
        {
            string[] names = new string[] { "Interface", "Inner tools", "Output" };
            mTabBorders = new Border[3];
            mTabTexts = new TextBlock[3];
            for (int i = 0; i < 3; i++)
            {
                int index = i;
                Border b = new Border();
                b.Padding = new Thickness(14, 10, 14, 8);
                b.Cursor = Cursors.Hand;
                b.Background = Brushes.Transparent;
                b.BorderThickness = new Thickness(0, 0, 0, 2);
                StackPanel sp = new StackPanel { Orientation = Orientation.Horizontal };
                TextBlock t = Txt(names[i], 12.5, mMuted, FontWeights.Normal, false);
                sp.Children.Add(t);
                if (i > 0)
                {
                    Border badge = new Border { CornerRadius = new CornerRadius(8), Padding = new Thickness(6, 0, 6, 0), Margin = new Thickness(6, 0, 0, 0), Background = Hex("#FF222833") };
                    TextBlock bt = Txt("0", 11, mText, FontWeights.SemiBold, false);
                    badge.Child = bt;
                    sp.Children.Add(badge);
                    if (i == 1) mBadgeInner = bt; else mBadgeOut = bt;
                }
                b.Child = sp;
                b.MouseLeftButtonUp += delegate { ShowTab(index); };
                mTabBorders[i] = b;
                mTabTexts[i] = t;
                Tabs.Children.Add(b);
            }
        }

        void ShowTab(int index)
        {
            mTab = index;
            MainScroll.Visibility = index == 1 ? Visibility.Collapsed : Visibility.Visible;
            SettingTab.Visibility = index == 0 ? Visibility.Visible : Visibility.Collapsed;
            OutputTab.Visibility = index == 2 ? Visibility.Visible : Visibility.Collapsed;
            InnerTab.Visibility = index == 1 ? Visibility.Visible : Visibility.Collapsed;
            for (int i = 0; i < mTabBorders.Length; i++)
            {
                bool on = i == index;
                mTabBorders[i].BorderBrush = on ? mAccent : Brushes.Transparent;
                mTabTexts[i].Foreground = on ? mText : mMuted;
                mTabTexts[i].FontWeight = on ? FontWeights.SemiBold : FontWeights.Normal;
            }
            if (index == 0 && ed != null) BuildInterface();
            if (index == 1) UpdateInputInfo();
            if (index == 2) RefreshOutputs();
        }

        void Say(string text)
        {
            HintBar.Visibility = string.IsNullOrEmpty(text) ? Visibility.Collapsed : Visibility.Visible;
            Hint.Text = text ?? "";
        }

        // ------------------------------------------------------------------ inputs and outputs of the block
        void BuildInterface()
        {
            SettingTab.Children.Clear();
            SettingTab.Children.Add(BuildSection("Inputs", "What the block receives. Link each one to a value in the tool list; inside the block the tools read it from the Input node.", true, mIn));
            SettingTab.Children.Add(BuildSection("Outputs", "What the block gives back. Link each one to a value of a tool inside the block (Output node).", false, mOut));
        }

        FrameworkElement BuildSection(string title, string note, bool input, List<Row> rows)
        {
            StackPanel sp = new StackPanel { Margin = new Thickness(0, 0, 0, 16) };
            TextBlock h = Txt(title, 13, mText, FontWeights.SemiBold, false);
            h.Margin = new Thickness(0, 0, 0, 2);
            sp.Children.Add(h);
            TextBlock n = Txt(note, 12, mMuted, FontWeights.Normal, false);
            n.Margin = new Thickness(0, 0, 0, 8);
            sp.Children.Add(n);

            if (rows.Count == 0)
            {
                TextBlock none = Txt(input ? "No input." : "No output.", 12, mMuted, FontWeights.Normal, false);
                none.Margin = new Thickness(0, 0, 0, 8);
                sp.Children.Add(none);
            }
            for (int i = 0; i < rows.Count; i++) sp.Children.Add(BuildRow(rows, i, input));

            Button add = Btn(input ? "+ Add input" : "+ Add output", delegate
            {
                string baseName = input ? "Input" : "Output";
                int k = rows.Count + 1;
                string name = baseName + k;
                while (rows.Exists(r => r.Name == name)) { k++; name = baseName + k; }
                rows.Add(new Row { Name = name, Type = "Image" });
                Commit(input);
            });
            add.HorizontalAlignment = HorizontalAlignment.Left;
            add.Padding = new Thickness(12, 0, 12, 0);
            add.Margin = new Thickness(0, 4, 0, 0);
            sp.Children.Add(add);
            return sp;
        }

        FrameworkElement BuildRow(List<Row> rows, int index, bool input)
        {
            Row row = rows[index];
            DockPanel p = new DockPanel { Margin = new Thickness(0, 0, 0, 2) };

            Button del = Btn("✕", delegate { rows.Remove(row); Commit(input); });
            del.Width = 30; del.Margin = new Thickness(4, 0, 0, 0); del.ToolTip = "Delete";
            Button down = Btn("↓", delegate { Move(rows, index, 1, input); });
            down.Width = 30; down.Margin = new Thickness(4, 0, 0, 0); down.ToolTip = "Move down";
            Button up = Btn("↑", delegate { Move(rows, index, -1, input); });
            up.Width = 30; up.Margin = new Thickness(4, 0, 0, 0); up.ToolTip = "Move up";
            DockPanel.SetDock(del, Dock.Right);
            DockPanel.SetDock(down, Dock.Right);
            DockPanel.SetDock(up, Dock.Right);
            p.Children.Add(del);
            p.Children.Add(down);
            p.Children.Add(up);

            Border type = new Border();
            type.Width = 130;
            type.Margin = new Thickness(6, 0, 0, 0);
            type.Padding = new Thickness(10, 0, 8, 0);
            type.MinHeight = 30;
            type.CornerRadius = new CornerRadius(6);
            type.BorderThickness = new Thickness(1);
            type.BorderBrush = mLine;
            type.Background = Brushes.Transparent;
            type.Cursor = Cursors.Hand;
            DockPanel td = new DockPanel();
            TextBlock arrow = Txt("▾", 11, mMuted, FontWeights.Normal, false);
            DockPanel.SetDock(arrow, Dock.Right);
            td.Children.Add(arrow);
            td.Children.Add(Txt(row.Type, 12.5, mAccent, FontWeights.Normal, false));
            type.Child = td;
            type.MouseLeftButtonUp += delegate
            {
                ContextMenu menu = new ContextMenu();
                foreach (KeyValuePair<string, Type> kv in SvToolBlockEdit.InterfaceTypes())
                {
                    string name = kv.Key;
                    MenuItem mi = new MenuItem { Header = name };
                    mi.Click += delegate { row.Type = name; Commit(input); };
                    menu.Items.Add(mi);
                }
                menu.PlacementTarget = type;
                menu.IsOpen = true;
            };
            DockPanel.SetDock(type, Dock.Right);
            p.Children.Add(type);

            TextBox tb = new TextBox();
            tb.Text = row.Name;
            Action commit = delegate
            {
                string v = tb.Text.Trim();
                if (v == row.Name) return;
                row.Name = v;
                Commit(input);
            };
            tb.LostFocus += delegate { commit(); };
            tb.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; commit(); } };
            p.Children.Add(tb);

            StackPanel wrap = new StackPanel();
            wrap.Children.Add(p);
            wrap.Children.Add(StatusLine(row.Name, input));
            return wrap;
        }

        /// <summary>One small line under an input or output: where its value comes from, and the value of the last run.</summary>
        TextBlock StatusLine(string name, bool input)
        {
            TextBlock t = Txt(StatusText(name, input), 11, mMuted, FontWeights.Normal, false);
            t.Margin = new Thickness(2, 0, 0, 8);
            return t;
        }

        string StatusText(string name, bool input)
        {
            string result;
            try
            {
                SvToolBlock b = ed.Subject;
                InputParams ip = null;
                if (input) b.inParams.TryGetValue(name, out ip);
                else b.outputTool.inParams.TryGetValue(name, out ip);

                string link;
                if (ip == null) link = input ? "not linked: link it in the tool list" : "not linked: link it to a tool in the Inner tools tab";
                else
                {
                    SvToolBase src = ip.Instance as SvToolBase;
                    string srcName = src == null ? "?" : (object.ReferenceEquals(src, b.inputTool) ? "Input" : src.ToString());
                    link = "\u2190 " + srcName + "." + ip.FieldName;
                }

                object v = null;
                if (input) b.inputTool.outParams.TryGetValue(name, out v);
                else b.outParams.TryGetValue(name, out v);
                string val;
                if (v == null) val = "no value yet";
                else if (v is SvImage)
                {
                    SvImage img = (SvImage)v;
                    val = (img.Width > 0 && img.Height > 0) ? "image " + img.Width + " x " + img.Height : "EMPTY image (0 x 0): run the job, and check that the source tool really made an image";
                }
                else val = ValueText(v);
                result = link + "   \u00B7   " + val;
            }
            catch (Exception ex) { result = "status: " + ex.Message; }
            return result;
        }

        /// <summary>Under the tool list of the block: what each input holds now.</summary>
        void UpdateInputInfo()
        {
            if (ed == null || ed.Subject == null) return;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            foreach (KeyValuePair<string, string> kv in ed.GetInputRows())
            {
                if (sb.Length > 0) sb.Append("\n");
                sb.Append("Input ").Append(kv.Key).Append(":  ").Append(StatusText(kv.Key, true));
            }
            InputInfo.Text = sb.ToString();
            InputInfo.Visibility = sb.Length == 0 ? Visibility.Collapsed : Visibility.Visible;
        }

        void Move(List<Row> rows, int index, int delta, bool input)
        {
            int to = index + delta;
            if (to < 0 || to >= rows.Count) return;
            Row r = rows[index];
            rows.RemoveAt(index);
            rows.Insert(to, r);
            Commit(input);
        }

        /// <summary>Gives the rows to the block; when a name is wrong the rows stay here and the message is shown.</summary>
        void Commit(bool input)
        {
            List<Row> rows = input ? mIn : mOut;
            List<KeyValuePair<string, string>> pairs = new List<KeyValuePair<string, string>>();
            foreach (Row r in rows) pairs.Add(new KeyValuePair<string, string>(r.Name, r.Type));
            string err = ed.ApplyInterface(input, pairs);
            Say(err);
            BuildInterface();
            if (err == null)
            {
                RefreshOutputs();
                if (mHost != null) mHost.RaiseStructure();
            }
        }

        // ------------------------------------------------------------------ outputs now
        static string ValueText(object v)
        {
            if (v == null) return "—";
            if (v is float && float.IsNaN((float)v)) return "—";
            if (v is double && double.IsNaN((double)v)) return "—";
            if (v is float || v is double) return ((IFormattable)v).ToString("0.###", CultureInfo.InvariantCulture);
            if (v is bool || v is int || v is string) return v.ToString();
            return v.GetType().Name;
        }

        public void RefreshOutputs()
        {
            if (ed == null || ed.Subject == null) return;
            OutputTab.Children.Clear();
            StackPanel head = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 6) };
            head.Children.Add(Txt("Outputs", 13, mText, FontWeights.SemiBold, false));
            mOutNote = Txt("  last run · click a row to copy its value", 12, mMuted, FontWeights.Normal, false);
            head.Children.Add(mOutNote);
            OutputTab.Children.Add(head);
            mOutRows = new StackPanel();
            OutputTab.Children.Add(mOutRows);

            SvToolBlock block = ed.Subject;
            int count = 0;
            foreach (KeyValuePair<string, object> kv in new List<KeyValuePair<string, object>>(block.outParams))
            {
                count++;
                string name = kv.Key;
                string type = "";
                foreach (KeyValuePair<string, string> r in ed.GetOutputRows()) if (r.Key == name) type = r.Value;
                string text = ValueText(kv.Value);
                Border row = new Border();
                row.BorderBrush = mLine;
                row.BorderThickness = new Thickness(0, 1, 0, 0);
                row.Padding = new Thickness(4, 6, 4, 6);
                row.Background = Brushes.Transparent;
                row.Cursor = Cursors.Hand;
                Grid g = new Grid();
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(90) });
                g.ColumnDefinitions.Add(new ColumnDefinition());
                TextBlock n = Txt(name, 13, mText, FontWeights.Normal, true);
                TextBlock ty = Txt(type, 12, mMuted, FontWeights.Normal, false);
                TextBlock val = Txt(text, 13, mText, FontWeights.Normal, true);
                val.HorizontalAlignment = HorizontalAlignment.Right;
                Grid.SetColumn(ty, 1);
                Grid.SetColumn(val, 2);
                g.Children.Add(n);
                g.Children.Add(ty);
                g.Children.Add(val);
                row.Child = g;
                row.MouseEnter += delegate { row.Background = Hex("#FF222833"); };
                row.MouseLeave += delegate { row.Background = Brushes.Transparent; };
                string copyName = name, copyText = text;
                row.MouseLeftButtonUp += delegate
                {
                    try { Clipboard.SetText(copyText); mOutNote.Text = "  copied " + copyName + " = " + copyText; }
                    catch (Exception) { }
                };
                mOutRows.Children.Add(row);
            }
            if (count == 0) mOutRows.Children.Add(Txt("The block has no output. Add one in the Interface tab.", 12, mMuted, FontWeights.Normal, false));
            if (mBadgeOut != null) mBadgeOut.Text = count.ToString();
            if (mBadgeInner != null && block.ToolJob != null && block.ToolJob.ToolList != null) mBadgeInner.Text = block.ToolJob.ToolList.Count.ToString();
        }
    }
}


namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>Lets the WPF tool list work on the tools inside a tool block (with its Input and Output nodes).</summary>
    public class ToolBlockHost : SvMip.Edit.IToolListHost
    {
        readonly SvMip.Edit.SvToolBlockEdit mEd;

        public ToolBlockHost(SvMip.Edit.SvToolBlockEdit ed) { mEd = ed; }

        public Func<SvToolBase, bool> EditRequested;

        SvToolBlock Block { get { return mEd.Subject; } }

        public SvJob Job { get { return Block == null ? null : Block.ToolJob; } }
        public SvToolBase InputNode { get { return Block == null ? null : Block.inputTool; } }
        public SvToolBase OutputNode { get { return Block == null ? null : Block.outputTool; } }

        public void EditTool(SvToolBase tool)
        {
            if (tool == null || object.ReferenceEquals(tool, InputNode) || object.ReferenceEquals(tool, OutputNode)) return;
            if (EditRequested != null && EditRequested(tool)) return;
            mEd.InnerTree.RequestEdit(tool);
        }

        public void SelectTool(SvToolBase tool)
        {
            mEd.SelectInner(tool);
            if (ToolSelected != null) ToolSelected(this, new SvMip.Edit.SvToolEventArgs(tool));
        }

        public void JobStructureChanged() { mEd.RefreshInnerTree(); }

        public System.Collections.Generic.List<Type> GetToolTypes() { return mEd.InnerTree.GetToolTypes(); }

        public event EventHandler JobLoaded;
        public event EventHandler JobRan;
        public event EventHandler JobStructureEdited;
        public event EventHandler<SvMip.Edit.SvToolEventArgs> ToolSelected;

        public void RaiseRan() { if (JobRan != null) JobRan(this, EventArgs.Empty); }
        public void RaiseStructure() { if (JobStructureEdited != null) JobStructureEdited(this, EventArgs.Empty); }
        public void RaiseLoaded() { if (JobLoaded != null) JobLoaded(this, EventArgs.Empty); }
    }
}
