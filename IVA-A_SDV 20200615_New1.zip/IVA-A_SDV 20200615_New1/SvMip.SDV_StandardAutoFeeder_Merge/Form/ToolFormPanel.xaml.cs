﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using SvMip.Edit;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Generic WPF editor of a tool: the lines come from a ToolFormSpec (property, label, kind), the values are read from and
    /// written to the properties of the tool itself. The second tab shows the outputs of the tool.
    /// </summary>
    public partial class ToolFormPanel : UserControl
    {
        SvToolBase tool;
        ToolFormSpec spec;
        SvJobEdit je;
        bool loading;
        readonly List<Action> mUpdaters = new List<Action>();
        readonly List<KeyValuePair<FrameworkElement, FormItem>> mVisible = new List<KeyValuePair<FrameworkElement, FormItem>>();
        Brush mText, mMuted, mLine, mAccent, mCard;
        Border[] mTabBorders;
        TextBlock[] mTabTexts;
        TextBlock mOutBadge, mOutNote;
        StackPanel mOutRows;
        object mBuiltFor;

        public ToolFormPanel()
        {
            InitializeComponent();
            mText = (Brush)FindResource("IvaTextBrush");
            mMuted = (Brush)FindResource("IvaMutedBrush");
            mLine = (Brush)FindResource("IvaLineBrush");
            mAccent = (Brush)FindResource("IvaAccentBrush");
            mCard = (Brush)FindResource("IvaCardBrush");
        }

        // ------------------------------------------------------------------ connection
        public void Attach(SvToolBase t, ToolFormSpec s, SvJobEdit edit)
        {
            je = edit;
            if (!object.ReferenceEquals(mBuiltFor, s) || !object.ReferenceEquals(tool, t))
            {
                tool = t;
                spec = s;
                mBuiltFor = s;
                Build();
            }
            Reload();
        }

        public void Reload()
        {
            if (tool == null) return;
            loading = true;
            try
            {
                foreach (Action a in mUpdaters) a();
                foreach (KeyValuePair<FrameworkElement, FormItem> kv in mVisible)
                    kv.Key.Visibility = (kv.Value.Visible == null || kv.Value.Visible(tool)) ? Visibility.Visible : Visibility.Collapsed;
                RefreshOutputs();
            }
            finally { loading = false; }
        }

        // ------------------------------------------------------------------ reading and writing properties
        PropertyInfo Prop(object target, string name)
        {
            return target == null ? null : target.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public);
        }

        object GetVal(string name)
        {
            PropertyInfo p = Prop(tool, name);
            if (p == null) return null;
            try { return p.GetValue(tool, null); } catch (Exception) { return null; }
        }

        bool SetVal(string name, object value)
        {
            PropertyInfo p = Prop(tool, name);
            if (p == null || !p.CanWrite) return false;
            try
            {
                Type t = Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType;
                object v;
                if (t.IsEnum) v = value is string ? Enum.Parse(t, (string)value) : Enum.ToObject(t, value);
                else if (t == typeof(string)) v = value == null ? "" : value.ToString();
                else if (value is string) v = Convert.ChangeType(((string)value).Trim().Replace(',', '.'), t, CultureInfo.InvariantCulture);
                else v = Convert.ChangeType(value, t, CultureInfo.InvariantCulture);
                p.SetValue(tool, v, null);
                return true;
            }
            catch (Exception) { return false; }
        }

        static string Fmt(object v, int decimals)
        {
            if (v == null) return "";
            if (v is string) return (string)v;
            if (v is IConvertible && !(v is bool) && !v.GetType().IsEnum)
            {
                try { return Convert.ToDouble(v, CultureInfo.InvariantCulture).ToString("F" + decimals, CultureInfo.InvariantCulture); }
                catch (Exception) { }
            }
            return v.ToString();
        }

        /// <summary>After a change made here: item callback, preview of the image, redraw of the form.</summary>
        void Changed(FormItem item)
        {
            if (item.Changed != null) item.Changed(tool);
            if (item.Preview && je != null) je.PreviewTool(tool);
            Reload();
        }

        // ------------------------------------------------------------------ small builders
        TextBlock Txt(string text, double size, Brush brush, FontWeight weight, bool mono)
        {
            TextBlock t = new TextBlock();
            t.Text = text;
            t.FontSize = size;
            t.Foreground = brush;
            t.FontWeight = weight;
            t.TextWrapping = TextWrapping.Wrap;
            if (mono) t.FontFamily = new FontFamily("Consolas");
            return t;
        }

        TextBlock Cap(string text)
        {
            TextBlock t = Txt(text, 12, mMuted, FontWeights.Normal, false);
            t.Margin = new Thickness(0, 0, 0, 4);
            return t;
        }

        Button Btn(string text, Action action)
        {
            Button b = new Button();
            b.Content = text;
            b.Click += delegate { action(); };
            return b;
        }

        static Brush Hex(string hex) { return (Brush)new BrushConverter().ConvertFromString(hex); }

        // ------------------------------------------------------------------ building the form
        void Build()
        {
            mUpdaters.Clear();
            mVisible.Clear();
            SettingTab.Children.Clear();
            OutputTab.Children.Clear();
            Tabs.Children.Clear();
            BuildTabs();

            WrapPanel numbers = null;
            foreach (FormItem item in spec.Items)
            {
                if (item.Kind == FormKind.Number)
                {
                    if (numbers == null)
                    {
                        numbers = new WrapPanel();
                        SettingTab.Children.Add(numbers);
                    }
                    FrameworkElement cell = BuildNumber(item);
                    cell.Width = 212;
                    cell.Margin = new Thickness(0, 0, 10, 10);
                    numbers.Children.Add(cell);
                    Register(cell, item);
                    continue;
                }
                numbers = null;
                FrameworkElement el = BuildItem(item);
                if (el == null) continue;
                SettingTab.Children.Add(el);
                Register(el, item);
            }

            StackPanel head = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 6) };
            head.Children.Add(Txt("Outputs", 13, mText, FontWeights.SemiBold, false));
            mOutNote = Txt("  last run · click a row to copy its value", 12, mMuted, FontWeights.Normal, false);
            head.Children.Add(mOutNote);
            OutputTab.Children.Add(head);
            mOutRows = new StackPanel();
            OutputTab.Children.Add(mOutRows);

            ShowTab(0);
        }

        void Register(FrameworkElement el, FormItem item)
        {
            if (item.Visible != null) mVisible.Add(new KeyValuePair<FrameworkElement, FormItem>(el, item));
        }

        void BuildTabs()
        {
            string[] names = spec.NoOutput ? new string[] { "Setting" } : new string[] { "Setting", "Output" };
            mTabBorders = new Border[names.Length];
            mTabTexts = new TextBlock[names.Length];
            for (int i = 0; i < names.Length; i++)
            {
                int index = i;
                Border b = new Border();
                b.Padding = new Thickness(14, 10, 14, 8);
                b.Cursor = Cursors.Hand;
                b.Background = Brushes.Transparent;
                b.BorderThickness = new Thickness(0, 0, 0, 2);
                StackPanel sp = new StackPanel { Orientation = Orientation.Horizontal };
                TextBlock t = Txt(names[i], 12.5, mMuted, FontWeights.Normal, false);
                sp.Children.Add(t);
                if (i == 1)
                {
                    Border badge = new Border { CornerRadius = new CornerRadius(8), Padding = new Thickness(6, 0, 6, 0), Margin = new Thickness(6, 0, 0, 0), Background = Hex("#FF222833") };
                    mOutBadge = Txt("0", 11, mText, FontWeights.SemiBold, false);
                    badge.Child = mOutBadge;
                    sp.Children.Add(badge);
                }
                b.Child = sp;
                b.MouseLeftButtonUp += delegate { ShowTab(index); };
                mTabBorders[i] = b;
                mTabTexts[i] = t;
                Tabs.Children.Add(b);
            }
            if (mTabBorders.Length < 2) ((Border)Tabs.Parent).Visibility = Visibility.Collapsed;
            else ((Border)Tabs.Parent).Visibility = Visibility.Visible;
        }

        void ShowTab(int index)
        {
            SettingTab.Visibility = index == 0 ? Visibility.Visible : Visibility.Collapsed;
            OutputTab.Visibility = index == 1 ? Visibility.Visible : Visibility.Collapsed;
            for (int i = 0; i < mTabBorders.Length; i++)
            {
                bool on = i == index;
                mTabBorders[i].BorderBrush = on ? mAccent : Brushes.Transparent;
                mTabTexts[i].Foreground = on ? mText : mMuted;
                mTabTexts[i].FontWeight = on ? FontWeights.SemiBold : FontWeights.Normal;
            }
            if (index == 1) RefreshOutputs();
        }

        FrameworkElement BuildItem(FormItem item)
        {
            switch (item.Kind)
            {
                case FormKind.Header:
                    {
                        TextBlock h = Txt(item.Label, 13, mText, FontWeights.SemiBold, false);
                        h.Margin = new Thickness(0, 8, 0, 8);
                        return h;
                    }
                case FormKind.Note:
                    {
                        TextBlock n = Txt(item.Label, 12, mMuted, FontWeights.Normal, false);
                        n.Margin = new Thickness(0, 4, 0, 10);
                        return n;
                    }
                case FormKind.Text: return BuildText(item, false, false);
                case FormKind.Source: return BuildText(item, true, false);
                case FormKind.Folder: return BuildText(item, false, true);
                case FormKind.Check: return BuildCheck(item);
                case FormKind.Enum: return BuildChips(item, true);
                case FormKind.Choice: return BuildChips(item, false);
                case FormKind.Slider: return BuildSlider(item);
                case FormKind.Button: return BuildButton(item);
                case FormKind.Readout: return BuildReadout(item);
                case FormKind.Grid: return BuildGrid(item, null, null);
                case FormKind.ImageList: return BuildImageList(item);
            }
            return null;
        }

        FrameworkElement BuildNumber(FormItem item)
        {
            StackPanel sp = new StackPanel();
            sp.Children.Add(Cap(item.Label));
            TextBox tb = new TextBox();
            sp.Children.Add(tb);
            Action commit = delegate
            {
                if (loading) return;
                double v;
                if (double.TryParse(tb.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v))
                {
                    if (v < item.Min) v = item.Min;
                    if (v > item.Max) v = item.Max;
                    if (item.Odd && item.Decimals == 0 && ((long)Math.Round(v)) % 2 == 0) v = Math.Round(v) + 1;
                    if (item.Odd && v > item.Max) v = item.Max % 2 == 0 ? item.Max - 1 : item.Max;
                    SetVal(item.Prop, v);
                    Changed(item);
                }
                else Reload();
            };
            tb.LostFocus += delegate { commit(); };
            tb.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; commit(); } };
            // the mouse wheel and the arrow keys step the value
            tb.PreviewKeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Key != Key.Up && e.Key != Key.Down) return;
                double v;
                if (!double.TryParse(tb.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v)) return;
                v += (e.Key == Key.Up ? 1 : -1) * item.Step;
                tb.Text = Fmt(v, item.Decimals);
                e.Handled = true;
                commit();
            };
            mUpdaters.Add(delegate
            {
                PropertyInfo p = Prop(tool, item.Prop);
                tb.IsEnabled = p != null;
                tb.Text = Fmt(GetVal(item.Prop), item.Decimals);
            });
            return sp;
        }

        FrameworkElement BuildText(FormItem item, bool pickSource, bool folder)
        {
            StackPanel sp = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            sp.Children.Add(Cap(item.Label));
            DockPanel row = new DockPanel();
            TextBox tb = new TextBox();
            if (pickSource || folder)
            {
                Button pick = Btn(folder ? "Browse..." : "...", delegate
                {
                    string picked = null;
                    if (folder)
                    {
                        using (System.Windows.Forms.FolderBrowserDialog dlg = new System.Windows.Forms.FolderBrowserDialog())
                        {
                            dlg.SelectedPath = tb.Text;
                            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK) picked = dlg.SelectedPath;
                        }
                    }
                    else picked = SvSourcePickerDialog.Pick(null);
                    if (picked == null) return;
                    SetVal(item.Prop, picked);
                    Changed(item);
                });
                pick.Width = folder ? 80 : 36;
                pick.Margin = new Thickness(6, 0, 0, 0);
                DockPanel.SetDock(pick, Dock.Right);
                row.Children.Add(pick);
            }
            row.Children.Add(tb);
            sp.Children.Add(row);

            Action commit = delegate
            {
                if (loading) return;
                if (!SetVal(item.Prop, tb.Text)) { Reload(); return; }
                Changed(item);
            };
            tb.LostFocus += delegate { commit(); };
            tb.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; commit(); } };
            mUpdaters.Add(delegate
            {
                tb.IsEnabled = Prop(tool, item.Prop) != null;
                tb.Text = Fmt(GetVal(item.Prop), 3).Replace(".000", "");
            });
            return sp;
        }

        FrameworkElement BuildCheck(FormItem item)
        {
            DockPanel row = new DockPanel();
            row.Margin = new Thickness(0, 4, 0, 6);
            row.Background = Brushes.Transparent;
            row.Cursor = Cursors.Hand;
            Border box = new Border();
            box.Width = 20; box.Height = 20;
            box.CornerRadius = new CornerRadius(5);
            box.BorderThickness = new Thickness(1.5);
            box.Margin = new Thickness(0, 0, 10, 0);
            TextBlock tick = Txt("✓", 13, Brushes.White, FontWeights.Bold, false);
            tick.HorizontalAlignment = HorizontalAlignment.Center;
            box.Child = tick;
            DockPanel.SetDock(box, Dock.Left);
            row.Children.Add(box);
            row.Children.Add(Txt(item.Label + (string.IsNullOrEmpty(item.Note) ? "" : "  · " + item.Note), 13, mText, FontWeights.Normal, false));
            mUpdaters.Add(delegate
            {
                bool on = GetVal(item.Prop) is bool && (bool)GetVal(item.Prop);
                box.Background = on ? mAccent : Brushes.Transparent;
                box.BorderBrush = on ? mAccent : mLine;
                tick.Visibility = on ? Visibility.Visible : Visibility.Hidden;
            });
            row.MouseLeftButtonUp += delegate
            {
                object v = GetVal(item.Prop);
                SetVal(item.Prop, !(v is bool && (bool)v));
                Changed(item);
            };
            return row;
        }

        /// <summary>Choose one value: one chip per value (enum values, or the list the item gives).</summary>
        FrameworkElement BuildChips(FormItem item, bool isEnum)
        {
            StackPanel sp = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            sp.Children.Add(Cap(item.Label));
            WrapPanel wrap = new WrapPanel();
            sp.Children.Add(wrap);
            mUpdaters.Add(delegate
            {
                wrap.Children.Clear();
                PropertyInfo p = Prop(tool, item.Prop);
                if (p == null) return;
                IList<string> names;
                if (isEnum) names = Enum.GetNames(Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType);
                else names = item.Options(tool);
                string current = GetVal(item.Prop) == null ? "" : GetVal(item.Prop).ToString();
                foreach (string name in names)
                {
                    string n = name;
                    bool on = n == current;
                    Border chip = new Border();
                    chip.Padding = new Thickness(12, 5, 12, 5);
                    chip.Margin = new Thickness(0, 0, 6, 6);
                    chip.CornerRadius = new CornerRadius(6);
                    chip.BorderThickness = new Thickness(1);
                    chip.Cursor = Cursors.Hand;
                    chip.BorderBrush = on ? mAccent : mLine;
                    chip.Background = on ? mAccent : Brushes.Transparent;
                    chip.Child = Txt(n, 12.5, on ? Brushes.White : mMuted, on ? FontWeights.SemiBold : FontWeights.Normal, false);
                    chip.MouseLeftButtonUp += delegate
                    {
                        SetVal(item.Prop, n);
                        Changed(item);
                    };
                    wrap.Children.Add(chip);
                }
            });
            return sp;
        }

        FrameworkElement BuildSlider(FormItem item)
        {
            StackPanel sp = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
            DockPanel head = new DockPanel();
            TextBlock value = Txt("", 13, mText, FontWeights.Normal, true);
            DockPanel.SetDock(value, Dock.Right);
            head.Children.Add(value);
            head.Children.Add(Txt(item.Label, 13, mText, FontWeights.Medium, false));
            sp.Children.Add(head);
            Slider s = new Slider();
            s.Minimum = item.Min;
            s.Maximum = item.Max;
            s.SmallChange = 1;
            s.LargeChange = Math.Max(1, (item.Max - item.Min) / 40);
            s.IsMoveToPointEnabled = true;
            s.Margin = new Thickness(0, 6, 0, 0);
            s.ValueChanged += delegate
            {
                if (loading) return;
                SetVal(item.Prop, Math.Round(s.Value));
                value.Text = (s.Value / item.Scale).ToString("F" + item.Decimals, CultureInfo.InvariantCulture);
            };
            // run the tool only when the mouse is released (the run can take time)
            s.PreviewMouseLeftButtonUp += delegate { Changed(item); };
            s.KeyUp += delegate { Changed(item); };
            sp.Children.Add(s);
            mUpdaters.Add(delegate
            {
                object v = GetVal(item.Prop);
                double d = v == null ? 0 : Convert.ToDouble(v, CultureInfo.InvariantCulture);
                s.Value = d;
                value.Text = (d / item.Scale).ToString("F" + item.Decimals, CultureInfo.InvariantCulture);
            });
            return sp;
        }

        FrameworkElement BuildButton(FormItem item)
        {
            Button b = Btn(item.Label, delegate
            {
                if (item.Click != null) item.Click(tool);
                Changed(item);
            });
            b.HorizontalAlignment = HorizontalAlignment.Left;
            b.Padding = new Thickness(12, 0, 12, 0);
            b.Margin = new Thickness(0, 0, 0, 10);
            return b;
        }

        FrameworkElement BuildReadout(FormItem item)
        {
            DockPanel row = new DockPanel { Margin = new Thickness(0, 2, 0, 6) };
            TextBlock value = Txt("", 13, mText, FontWeights.SemiBold, true);
            DockPanel.SetDock(value, Dock.Right);
            row.Children.Add(value);
            row.Children.Add(Txt(item.Label, 13, mMuted, FontWeights.Normal, false));
            mUpdaters.Add(delegate
            {
                object v = GetVal(item.Prop);
                value.Text = v == null ? "—" : Fmt(v, 3).Replace(".000", "");
            });
            return row;
        }

        // ------------------------------------------------------------------ tables
        static Type ElementType(PropertyInfo p)
        {
            Type t = p.PropertyType;
            if (t.IsGenericType) return t.GetGenericArguments()[0];
            return typeof(object);
        }

        FrameworkElement BuildGrid(FormItem item, DataGrid master, Type knownType)
        {
            StackPanel sp = new StackPanel { Margin = new Thickness(0, 0, 0, 12) };
            if (!string.IsNullOrEmpty(item.Label))
            {
                TextBlock h = Txt(item.Label, 13, mText, FontWeights.SemiBold, false);
                h.Margin = new Thickness(0, 4, 0, 6);
                sp.Children.Add(h);
            }

            DataGrid g = new DataGrid();
            g.AutoGenerateColumns = false;
            g.CanUserAddRows = false;
            g.CanUserDeleteRows = false;
            g.CanUserResizeRows = false;
            g.HeadersVisibility = DataGridHeadersVisibility.Column;
            g.SelectionMode = DataGridSelectionMode.Single;
            g.SelectionUnit = DataGridSelectionUnit.FullRow;
            g.Height = item.Height;
            g.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            g.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;

            Type elementType = knownType;
            foreach (GridColumn c in item.Columns)
            {
                if (c.IsCheck)
                {
                    DataGridCheckBoxColumn col = new DataGridCheckBoxColumn();
                    col.Header = c.Header;
                    col.Width = c.Width;
                    col.Binding = new Binding(c.Prop) { Mode = BindingMode.TwoWay };
                    g.Columns.Add(col);
                }
                else if (c.IsEnum)
                {
                    DataGridTemplateColumn col = new DataGridTemplateColumn();
                    col.Header = c.Header;
                    col.Width = c.Width;
                    FrameworkElementFactory border = new FrameworkElementFactory(typeof(Border));
                    border.SetValue(Border.BackgroundProperty, Brushes.Transparent);
                    border.SetValue(FrameworkElement.CursorProperty, Cursors.Hand);
                    FrameworkElementFactory text = new FrameworkElementFactory(typeof(TextBlock));
                    text.SetBinding(TextBlock.TextProperty, new Binding(c.Prop));
                    text.SetValue(TextBlock.ForegroundProperty, mAccent);
                    text.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Left);
                    border.AppendChild(text);
                    string propName = c.Prop;
                    border.AddHandler(UIElement.MouseLeftButtonUpEvent, new MouseButtonEventHandler(delegate(object s, MouseButtonEventArgs e)
                    {
                        FrameworkElement fe = (FrameworkElement)s;
                        object row = fe.DataContext;
                        PropertyInfo rp = Prop(row, propName);
                        if (rp == null || !rp.PropertyType.IsEnum) return;
                        ContextMenu menu = new ContextMenu();
                        foreach (string name in Enum.GetNames(rp.PropertyType))
                        {
                            string n = name;
                            MenuItem mi = new MenuItem { Header = n };
                            mi.Click += delegate
                            {
                                try { rp.SetValue(row, Enum.Parse(rp.PropertyType, n), null); } catch (Exception) { }
                                g.Items.Refresh();
                            };
                            menu.Items.Add(mi);
                        }
                        menu.PlacementTarget = fe;
                        menu.IsOpen = true;
                    }));
                    col.CellTemplate = new DataTemplate { VisualTree = border };
                    g.Columns.Add(col);
                }
                else
                {
                    DataGridTextColumn col = new DataGridTextColumn();
                    col.Header = c.Header;
                    col.Width = c.Width;
                    col.Binding = new Binding(c.Prop) { Mode = BindingMode.TwoWay, ConverterCulture = CultureInfo.InvariantCulture };
                    col.EditingElementStyle = (Style)FindResource("GridEdit");
                    g.Columns.Add(col);
                }
            }
            sp.Children.Add(g);

            // buttons under the table
            StackPanel bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 0) };
            Button add = Btn("+ Add row", delegate { });
            add.Padding = new Thickness(10, 0, 10, 0);
            Button del = Btn("Delete selected", delegate { });
            del.Padding = new Thickness(10, 0, 10, 0);
            del.Margin = new Thickness(6, 0, 0, 0);
            bar.Children.Add(add);
            bar.Children.Add(del);
            if (!string.IsNullOrEmpty(item.PickProp))
            {
                Button pick = Btn("Pick source for the selected row...", delegate
                {
                    object row = g.SelectedItem;
                    if (row == null) { ShowNote("Select a row first."); return; }
                    string picked = SvSourcePickerDialog.Pick(null);
                    if (picked == null) return;
                    PropertyInfo rp = Prop(row, item.PickProp);
                    if (rp != null) rp.SetValue(row, picked, null);
                    g.Items.Refresh();
                });
                pick.Padding = new Thickness(10, 0, 10, 0);
                pick.Margin = new Thickness(6, 0, 0, 0);
                bar.Children.Add(pick);
            }
            sp.Children.Add(bar);

            // the list the table shows: a property of the tool, or of the row selected in the table above
            Func<IList> getList = delegate
            {
                object owner = master == null ? (object)tool : master.SelectedItem;
                PropertyInfo lp = Prop(owner, item.Prop);
                return lp == null ? null : lp.GetValue(owner, null) as IList;
            };
            Func<Type> getElementType = delegate
            {
                object owner = master == null ? (object)tool : master.SelectedItem;
                PropertyInfo lp = Prop(owner, item.Prop);
                if (lp != null) return ElementType(lp);
                // no row selected: the type is still known from the property of the type of the row in the table above
                return elementType;
            };

            add.Click += delegate
            {
                IList list = getList();
                Type et = getElementType();
                if (list == null || et == null || et == typeof(object)) return;
                try
                {
                    object row = Activator.CreateInstance(et);
                    list.Add(row);
                    AfterListEdit(item.Prop, g, true);
                    g.Items.Refresh();
                    g.SelectedItem = row;
                    g.ScrollIntoView(row);
                }
                catch (Exception ex) { ShowNote("Could not add a row: " + ex.Message); }
            };
            del.Click += delegate
            {
                IList list = getList();
                object row = g.SelectedItem;
                if (list == null || row == null) return;
                list.Remove(row);
                g.Items.Refresh();
                AfterListEdit(item.Prop, g, true);
            };
            g.CellEditEnding += delegate
            {
                // after the cell has been committed
                Dispatcher.BeginInvoke(new Action(delegate { AfterListEdit(item.Prop, g, false); }), System.Windows.Threading.DispatcherPriority.Background);
            };

            if (master != null)
            {
                master.SelectionChanged += delegate
                {
                    IList list = getList();
                    g.ItemsSource = list;
                    sp.IsEnabled = list != null;
                };
            }
            else
            {
                PropertyInfo lp0 = Prop(tool, item.Prop);
                if (lp0 != null) elementType = ElementType(lp0);
                mUpdaters.Add(delegate
                {
                    IList list = getList();
                    if (!object.ReferenceEquals(g.ItemsSource, list)) g.ItemsSource = list;
                    else g.Items.Refresh();
                });
            }

            if (item.Detail != null)
            {
                // the table of the row: its element type is known from the type of the rows above
                PropertyInfo mp = Prop(tool, item.Prop);
                if (mp != null)
                {
                    Type rowType = ElementType(mp);
                    PropertyInfo dp = rowType.GetProperty(item.Detail.Prop);
                    FrameworkElement detail = BuildGrid(item.Detail, g, dp == null ? null : ElementType(dp));
                    sp.Children.Add(detail);
                }
            }
            return sp;
        }

        // ------------------------------------------------------------------ list of image files
        FrameworkElement BuildImageList(FormItem item)
        {
            StackPanel sp = new StackPanel { Margin = new Thickness(0, 0, 0, 14) };
            TextBlock h = Txt(item.Label, 13, mText, FontWeights.SemiBold, false);
            h.Margin = new Thickness(0, 6, 0, 8);
            sp.Children.Add(h);

            DockPanel top = new DockPanel { Margin = new Thickness(0, 0, 0, 8) };
            TextBlock count = Txt("", 12, mMuted, FontWeights.Normal, false);
            DockPanel.SetDock(count, Dock.Right);
            top.Children.Add(count);
            Button load = Btn("Load images...", delegate { });
            load.Padding = new Thickness(12, 0, 12, 0);
            load.HorizontalAlignment = HorizontalAlignment.Left;
            top.Children.Add(load);
            sp.Children.Add(top);

            StackPanel thumbs = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 8) };
            sp.Children.Add(thumbs);

            DockPanel nav = new DockPanel();
            Button next = Btn("\u203A", delegate { });
            next.Width = 30; next.Margin = new Thickness(6, 0, 0, 0);
            Button prev = Btn("\u2039", delegate { });
            prev.Width = 30; prev.Margin = new Thickness(0, 0, 6, 0);
            DockPanel.SetDock(prev, Dock.Left);
            DockPanel.SetDock(next, Dock.Right);
            Slider slider = new Slider();
            slider.Minimum = 0;
            slider.Maximum = 0;
            slider.TickFrequency = 1;
            slider.IsSnapToTickEnabled = true;
            slider.IsMoveToPointEnabled = true;
            slider.VerticalAlignment = VerticalAlignment.Center;
            nav.Children.Add(prev);
            nav.Children.Add(next);
            nav.Children.Add(slider);
            sp.Children.Add(nav);

            TextBlock file = Txt("", 12, mMuted, FontWeights.Normal, true);
            file.Margin = new Thickness(0, 6, 0, 0);
            file.TextTrimming = TextTrimming.CharacterEllipsis;
            file.TextWrapping = TextWrapping.NoWrap;
            sp.Children.Add(file);

            Func<IList> getList = delegate { return GetVal(item.Prop) as IList; };
            Func<int> getIndex = delegate
            {
                object v = GetVal(item.PickProp);
                return v == null ? 0 : Convert.ToInt32(v, CultureInfo.InvariantCulture);
            };
            Action<int> select = delegate(int i)
            {
                IList l = getList();
                if (l == null || l.Count == 0) return;
                if (i < 0) i = 0;
                if (i > l.Count - 1) i = l.Count - 1;
                SetVal(item.PickProp, i);
                Changed(item);
            };

            load.Click += delegate
            {
                Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
                dlg.Filter = "Images|*.bmp;*.png;*.jpg;*.jpeg;*.tif;*.tiff|All files (*.*)|*.*";
                dlg.Multiselect = true;
                if (dlg.ShowDialog() != true || dlg.FileNames.Length == 0) return;
                IList l = getList();
                if (l == null) return;
                l.Clear();
                foreach (string f in dlg.FileNames) l.Add(f);
                SetVal("CameraType", "Image");
                SetVal(item.PickProp, 0);
                Changed(item);
            };
            prev.Click += delegate { select(getIndex() - 1); };
            next.Click += delegate { select(getIndex() + 1); };
            slider.ValueChanged += delegate { if (!loading) select((int)Math.Round(slider.Value)); };

            mUpdaters.Add(delegate
            {
                IList l = getList();
                int n = l == null ? 0 : l.Count;
                int cur = Math.Min(Math.Max(getIndex(), 0), Math.Max(n - 1, 0));
                count.Text = n == 0 ? "No image loaded" : (cur + 1) + " / " + n;
                slider.Maximum = Math.Max(n - 1, 0);
                slider.Value = cur;
                slider.IsEnabled = n > 1;
                prev.IsEnabled = n > 1;
                next.IsEnabled = n > 1;
                file.Text = n == 0 ? "" : System.IO.Path.GetFileName(Convert.ToString(l[cur]));
                file.ToolTip = n == 0 ? null : Convert.ToString(l[cur]);

                thumbs.Children.Clear();
                if (n == 0) return;
                int first = Math.Min(Math.Max(cur - 1, 0), Math.Max(n - 4, 0));
                for (int i = first; i < Math.Min(first + 4, n); i++)
                {
                    int index = i;
                    Border b = new Border();
                    b.Width = 92; b.Height = 70;
                    b.Margin = new Thickness(0, 0, 8, 0);
                    b.BorderThickness = new Thickness(2);
                    b.CornerRadius = new CornerRadius(4);
                    b.BorderBrush = i == cur ? mAccent : mLine;
                    b.Background = Hex("#FF12151A");
                    b.Cursor = Cursors.Hand;
                    try
                    {
                        System.Windows.Media.Imaging.BitmapImage bi = new System.Windows.Media.Imaging.BitmapImage();
                        bi.BeginInit();
                        bi.UriSource = new Uri(Convert.ToString(l[i]));
                        bi.DecodePixelWidth = 92;
                        bi.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                        bi.EndInit();
                        b.Child = new Image { Source = bi, Stretch = Stretch.Uniform };
                    }
                    catch (Exception)
                    {
                        b.Child = Txt("?", 14, mMuted, FontWeights.Normal, false);
                    }
                    b.MouseLeftButtonUp += delegate { select(index); };
                    thumbs.Children.Add(b);
                }
            });
            return sp;
        }

        void ShowNote(string text)
        {
            if (mOutNote != null) mOutNote.Text = "  " + text;
            ShowTab(0);
            HintBar.Visibility = Visibility.Visible;
            Hint.Text = text;
        }

        // ------------------------------------------------------------------ outputs
        static string TypeName(Type t)
        {
            if (t == typeof(float)) return "float";
            if (t == typeof(double)) return "double";
            if (t == typeof(int)) return "int";
            if (t == typeof(bool)) return "bool";
            return t.Name;
        }

        static string ValueText(object v)
        {
            if (v == null) return "—";
            if (v is float && float.IsNaN((float)v)) return "—";
            if (v is double && double.IsNaN((double)v)) return "—";
            if (v is float || v is double) return ((IFormattable)v).ToString("0.###", CultureInfo.InvariantCulture);
            return v.ToString();
        }

        /// <summary>
        /// A table that defines the inputs / outputs of the tool (ISvDynamicParams: the inputs of SvSend, the parts of SvSplit) was edited:
        /// the tool updates its inputs / outputs and the tool list is drawn again.
        /// </summary>
        void AfterListEdit(string listProp, DataGrid g, bool structural)
        {
            if (loading) return;
            ISvDynamicParams d = tool as ISvDynamicParams;
            if (d == null || Array.IndexOf(d.ListProperties, listProp) < 0) return;
            bool changed;
            try { changed = d.SyncParams(); }
            catch (Exception ex) { ShowNote("Could not update the inputs / outputs: " + ex.Message); return; }
            if (changed) g.Items.Refresh();
            if ((changed || structural) && je != null) je.RaiseStructureEdited();
            RefreshOutputs();
        }

        public void RefreshOutputs()
        {
            if (tool == null || mOutRows == null) return;
            mOutRows.Children.Clear();
            string[] names;
            try { names = tool.GetOutputParamNames(); } catch (Exception) { names = new string[0]; }
            if (mOutBadge != null) mOutBadge.Text = names.Length.ToString();
            if (names.Length == 0)
                mOutRows.Children.Add(Txt("This tool has no output values.", 12, mMuted, FontWeights.Normal, false));
            foreach (string name in names)
            {
                PropertyInfo prop = tool.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public);
                object value = null;
                string type = "";
                if (prop != null)
                {
                    type = TypeName(prop.PropertyType);
                    try { value = prop.GetValue(tool, null); } catch (Exception) { value = null; }
                }
                else
                {
                    // an output that the user added (SvSplit parts): the value is in outParams
                    object ov;
                    if (tool.outParams.TryGetValue(name, out ov) && ov != null) { value = ov; type = TypeName(ov.GetType()); }
                }
                string text = ValueText(value);

                Border row = new Border();
                row.BorderBrush = mLine;
                row.BorderThickness = new Thickness(0, 1, 0, 0);
                row.Padding = new Thickness(4, 6, 4, 6);
                row.Background = Brushes.Transparent;
                row.Cursor = Cursors.Hand;
                Grid g = new Grid();
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(150) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
                g.ColumnDefinitions.Add(new ColumnDefinition());
                TextBlock n = Txt(name, 13, mText, FontWeights.Normal, true);
                TextBlock ty = Txt(type, 12, mMuted, FontWeights.Normal, false);
                TextBlock val = Txt(text, 13, mText, FontWeights.Normal, true);
                val.HorizontalAlignment = HorizontalAlignment.Right;
                Grid.SetColumn(ty, 1);
                Grid.SetColumn(val, 2);
                g.Children.Add(n);
                g.Children.Add(ty);
                g.Children.Add(val);
                row.Child = g;
                row.MouseEnter += delegate { row.Background = Hex("#FF222833"); };
                row.MouseLeave += delegate { row.Background = Brushes.Transparent; };
                string copyName = name, copyText = text;
                row.MouseLeftButtonUp += delegate
                {
                    try { Clipboard.SetText(copyText); if (mOutNote != null) mOutNote.Text = "  copied " + copyName + " = " + copyText; }
                    catch (Exception) { }
                };
                mOutRows.Children.Add(row);
            }
        }
    }
}
