﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public enum FormKind { Header, Note, Number, Text, Source, Folder, Check, Enum, Choice, Slider, Button, Readout, Grid, ImageList }

    /// <summary>One column of a table in a tool form.</summary>
    public class GridColumn
    {
        public string Prop;
        public string Header;
        public int Width = 90;
        public bool IsCheck;
        public bool IsEnum;

        public static GridColumn Text(string prop, string header, int width) { return new GridColumn { Prop = prop, Header = header, Width = width }; }
        public static GridColumn Check(string prop, string header, int width) { return new GridColumn { Prop = prop, Header = header, Width = width, IsCheck = true }; }
        public static GridColumn Enum(string prop, string header, int width) { return new GridColumn { Prop = prop, Header = header, Width = width, IsEnum = true }; }
    }

    /// <summary>One line of a tool form: what it shows, which property of the tool it edits and when it is visible.</summary>
    public class FormItem
    {
        public FormKind Kind;
        public string Prop;
        public string Label;
        public string Note;
        public double Min = -1000000000, Max = 1000000000, Step = 1, Scale = 1;
        public int Decimals;
        public bool Odd;
        public bool Preview;                              // run the tool and redraw the image after a change
        public Func<SvToolBase, bool> Visible;
        public Func<SvToolBase, IList<string>> Options;   // Choice
        public Action<SvToolBase> Changed;                // after the user changed the value
        public Action<SvToolBase> Click;                  // Button
        public List<GridColumn> Columns;                  // Grid
        public string PickProp;                           // Grid: the column that "Pick source" fills
        public int Height = 150;
        public FormItem Detail;                           // Grid: table of the selected row

        public FormItem If(Func<SvToolBase, bool> visible) { Visible = visible; return this; }
        public FormItem Do(Action<SvToolBase> changed) { Changed = changed; return this; }
        public FormItem Prev() { Preview = true; return this; }
    }

    public class ToolFormSpec
    {
        public List<FormItem> Items = new List<FormItem>();
        /// <summary>The old editor has things this form does not (histogram range, result lists): offer it with a "Classic view" button.</summary>
        public bool Classic;
        public bool NoOutput;
    }

    static class F
    {
        public static FormItem Header(string text) { return new FormItem { Kind = FormKind.Header, Label = text }; }
        public static FormItem Note(string text) { return new FormItem { Kind = FormKind.Note, Label = text }; }
        public static FormItem Num(string prop, string label, double min, double max, int decimals, double step)
        {
            return new FormItem { Kind = FormKind.Number, Prop = prop, Label = label, Min = min, Max = max, Decimals = decimals, Step = step };
        }
        public static FormItem Int(string prop, string label, double min, double max) { return Num(prop, label, min, max, 0, 1); }
        public static FormItem OddInt(string prop, string label, double min, double max)
        {
            FormItem i = Num(prop, label, min, max, 0, 2);
            i.Odd = true;
            return i;
        }
        public static FormItem Text(string prop, string label) { return new FormItem { Kind = FormKind.Text, Prop = prop, Label = label }; }
        public static FormItem Source(string prop, string label) { return new FormItem { Kind = FormKind.Source, Prop = prop, Label = label }; }
        public static FormItem Folder(string prop, string label) { return new FormItem { Kind = FormKind.Folder, Prop = prop, Label = label }; }
        public static FormItem Check(string prop, string label) { return new FormItem { Kind = FormKind.Check, Prop = prop, Label = label }; }
        public static FormItem Check(string prop, string label, string note) { return new FormItem { Kind = FormKind.Check, Prop = prop, Label = label, Note = note }; }
        public static FormItem Enum(string prop, string label) { return new FormItem { Kind = FormKind.Enum, Prop = prop, Label = label }; }
        public static FormItem Choice(string prop, string label, Func<SvToolBase, IList<string>> options) { return new FormItem { Kind = FormKind.Choice, Prop = prop, Label = label, Options = options }; }
        public static FormItem Slide(string prop, string label, double min, double max, double scale, int decimals)
        {
            return new FormItem { Kind = FormKind.Slider, Prop = prop, Label = label, Min = min, Max = max, Scale = scale, Decimals = decimals };
        }
        public static FormItem Button(string text, Action<SvToolBase> click) { return new FormItem { Kind = FormKind.Button, Label = text, Click = click }; }
        /// <summary>A list of image files with "Load images", thumbnails and a slider to choose the current one.</summary>
        public static FormItem ImageList(string listProp, string indexProp, string label)
        {
            return new FormItem { Kind = FormKind.ImageList, Prop = listProp, PickProp = indexProp, Label = label, Preview = true };
        }
        public static FormItem Readout(string prop, string label) { return new FormItem { Kind = FormKind.Readout, Prop = prop, Label = label }; }
        public static FormItem Grid(string listProp, string label, int height, string pickProp, params GridColumn[] columns)
        {
            return new FormItem { Kind = FormKind.Grid, Prop = listProp, Label = label, Height = height, PickProp = pickProp, Columns = columns.ToList() };
        }

        /// <summary>Value of a property of the tool as text (for "show when" conditions).</summary>
        public static string Get(SvToolBase tool, string prop)
        {
            PropertyInfo p = tool.GetType().GetProperty(prop);
            if (p == null) return "";
            object v = p.GetValue(tool, null);
            return v == null ? "" : v.ToString();
        }

        public static void Set(SvToolBase tool, string prop, object value)
        {
            PropertyInfo p = tool.GetType().GetProperty(prop);
            if (p == null || !p.CanWrite) return;
            Type t = Nullable.GetUnderlyingType(p.PropertyType) ?? p.PropertyType;
            object v = t.IsEnum && value is string ? System.Enum.Parse(t, (string)value) : Convert.ChangeType(value, t, System.Globalization.CultureInfo.InvariantCulture);
            p.SetValue(tool, v, null);
        }
    }

    /// <summary>The forms of the tools that have a new (WPF) editor. The property names are the ones the old editors bound to.</summary>
    public static class ToolFormSpecs
    {
        static readonly Dictionary<string, ToolFormSpec> mSpecs = Build();

        public static ToolFormSpec For(string toolTypeName)
        {
            ToolFormSpec s;
            return mSpecs.TryGetValue(toolTypeName, out s) ? s : null;
        }

        static ToolFormSpec Spec(bool classic, params FormItem[] items)
        {
            ToolFormSpec s = new ToolFormSpec();
            s.Classic = classic;
            s.Items.AddRange(items);
            return s;
        }

        static Dictionary<string, ToolFormSpec> Build()
        {
            Dictionary<string, ToolFormSpec> d = new Dictionary<string, ToolFormSpec>();

            d["SvBlur"] = Spec(false,
                F.Enum("Mode", "Mode"),
                F.OddInt("KernelSize", "Kernel size (odd)", 1, 99),
                F.Num("SigmaX", "Sigma X", 0, 1000, 2, 0.1).If(t => F.Get(t, "Mode") == "Gaussian"),
                F.Num("SigmaY", "Sigma Y", 0, 1000, 2, 0.1).If(t => F.Get(t, "Mode") == "Gaussian"),
                F.Num("SigmaColor", "Sigma color", 0, 1000, 2, 0.1).If(t => F.Get(t, "Mode") == "Bilateral"),
                F.Num("SigmaSpace", "Sigma space", 0, 1000, 2, 0.1).If(t => F.Get(t, "Mode") == "Bilateral"));

            d["SvEdge"] = Spec(true,
                F.Enum("Mode", "Mode"),
                F.OddInt("KernelSize", "Kernel size (odd)", 1, 31),
                F.Int("OrderX", "Order X", 0, 2).If(t => F.Get(t, "Mode") == "Sobel"),
                F.Int("OrderY", "Order Y", 0, 2).If(t => F.Get(t, "Mode") == "Sobel"),
                F.Int("ThresholdLow", "Threshold low", 0, 255).If(t => F.Get(t, "Mode") == "Canny"),
                F.Int("ThresholdHigh", "Threshold high", 0, 255).If(t => F.Get(t, "Mode") == "Canny"),
                F.Note("To choose the threshold on the histogram of the image, use the Classic view."));

            d["SvMorphology"] = Spec(false,
                F.Enum("Operation", "Operation"),
                F.Enum("Shape", "Shape"),
                F.Int("Iteration", "Iteration", 1, 100),
                F.Int("SizeX", "Size X", 1, 99),
                F.Int("SizeY", "Size Y", 1, 99));

            d["SvRotation"] = Spec(false,
                F.Header("Rotate"),
                F.Num("RotateX", "Center X", 0, 1000000, 1, 1),
                F.Num("RotateY", "Center Y", 0, 1000000, 1, 1),
                F.Button("Center = middle of the image", delegate(SvToolBase t)
                {
                    SvRotation r = (SvRotation)t;
                    if (r.InputImage == null || r.InputImage.Mat == null) return;
                    F.Set(t, "RotateX", r.InputImage.Mat.Width / 2.0);
                    F.Set(t, "RotateY", r.InputImage.Mat.Height / 2.0);
                }),
                F.Num("RotateAngle", "Angle (deg)", -360, 360, 3, 0.1),
                F.Num("RotateScale", "Scale", 0, 100, 3, 0.01),
                F.Header("Move"),
                F.Num("TranslateX", "Move X", -1000000, 1000000, 1, 1),
                F.Num("TranslateY", "Move Y", -1000000, 1000000, 1, 1),
                F.Header("Resize (0 = keep the size)"),
                F.Int("ResizeWidth", "Width", 0, 100000),
                F.Int("ResizeHeight", "Height", 0, 100000),
                F.Button("Original size", delegate(SvToolBase t) { F.Set(t, "ResizeWidth", 0); F.Set(t, "ResizeHeight", 0); }));

            d["SvImageCalculate"] = Spec(false,
                F.Num("ImgCal_Alpha", "α (alpha)", -1000, 1000, 2, 0.1),
                F.Num("ImgCal_Beta", "β (beta)", -1000, 1000, 2, 0.1),
                F.Num("ImgCal_Gamma", "γ (gamma)", -1000, 1000, 2, 1),
                F.Check("IsAbs", "Absolute value"),
                F.Check("IsAutoSubtract", "Auto subtract"));

            d["SvEqualizer"] = Spec(false,
                F.Header("Histogram equalization"),
                F.Note("No settings. The tool equalizes the histogram of the region of the input image. Change the region on the image."));

            d["SvMeasureSharpness"] = Spec(false,
                F.Int("MaxCount", "Max Prewitt count", 0, 100000));

            d["SvImageSave"] = Spec(false,
                F.Text("SaveFileName", "File name"),
                F.Folder("SaveFilePath", "File path"));

            d["SvImageConverter"] = Spec(true,
                F.Slide("ContrastValue", "Contrast", -2000, 2000, 100, 2).Prev(),
                F.Slide("BrightnessValue", "Brightness", -25500, 25500, 100, 2).Prev(),
                F.Button("Reset", delegate(SvToolBase t) { F.Set(t, "ContrastValue", 100); F.Set(t, "BrightnessValue", 0); }),
                F.Note("Auto convert and the histogram are in the Classic view."));

            d["SvDataLog"] = Spec(true,
                F.Int("Count", "Input parameter count", 1, 1000),
                F.Check("IsDisplayType", "Show the type of each value"),
                F.Note("The table of logged values is in the Classic view."));

            d["SvJudgement"] = Spec(true,
                F.Choice("Comparison", "Comparison", t => SvJudgement.ComparisonList.Values.ToList()),
                F.Num("Creteria", "Criteria", -1000000, 1000000, 2, 0.1),
                F.Num("Creteria2", "Criteria 2 (upper limit)", -1000000, 1000000, 2, 0.1).If(t => F.Get(t, "Comparison") == "InRange"),
                F.Readout("Value", "Value now"),
                F.Readout("Judgement", "Judgement"),
                F.Note("The table of thresholds is in the Classic view."));

            d["SvBlob"] = Spec(true,
                F.Enum("Mode", "Mode").Do(delegate(SvToolBase t)
                {
                    string mode = F.Get(t, "Mode");
                    string type = F.Get(t, "Type");
                    if (mode == "Theshold" && type != "Binary" && type != "Otsu") F.Set(t, "Type", "Binary");
                    if (mode == "Adaptive" && type != "Gaussian" && type != "Mean") F.Set(t, "Type", "Gaussian");
                }),
                F.Choice("Type", "Type", delegate(SvToolBase t)
                {
                    return F.Get(t, "Mode") == "Adaptive" ? (IList<string>)new string[] { "Gaussian", "Mean" } : new string[] { "Binary", "Otsu" };
                }).If(t => F.Get(t, "Mode") == "Theshold" || F.Get(t, "Mode") == "Adaptive"),
                F.Enum("Polarity", "Polarity").If(t => F.Get(t, "Mode") == "Theshold" || F.Get(t, "Mode") == "Adaptive"),
                F.Enum("BinaryType", "Binary type").If(t => F.Get(t, "Mode") == "Theshold"),
                F.Int("RangeLow", "Range low", 0, 255).If(t => ShowsRange(t)),
                F.Int("RangeHigh", "Range high", 0, 255).If(t => F.Get(t, "Mode") == "inRange"),
                F.OddInt("KernelSize", "Block size (odd)", 1, 999).If(t => F.Get(t, "Mode") != "Theshold" && F.Get(t, "Mode") != "inRange"),
                F.Int("Constant", "Constant", -255, 255).If(t => F.Get(t, "Mode") == "Adaptive" || F.Get(t, "Mode") == "Bernsen" || F.Get(t, "Mode") == "Nick"),
                F.Num("AdequateCoefficient", "Adequate coefficient", -1000, 1000, 3, 0.01).If(t => F.Get(t, "Mode") == "Nick" || F.Get(t, "Mode") == "NiblackFast" || F.Get(t, "Mode") == "SauvolaFast"),
                F.Num("AdequateCoefficientR", "Adequate coefficient R", -1000, 1000, 3, 0.01).If(t => F.Get(t, "Mode") == "SauvolaFast"),
                F.Check("IsGetBlob", "Calculate the blobs"),
                F.Check("IsfillingHole", "Fill holes"),
                F.Enum("Priority", "Priority"),
                F.Enum("SortingOrder", "Sort by").If(t => F.Get(t, "Priority") == "None"),
                F.Check("IsSortingAscending", "Sort ascending").If(t => F.Get(t, "Priority") == "None"),
                F.Int("MaxCount", "Max result count", 0, 100000),
                F.Note("The histogram, the filter table and the list of blobs are in the Classic view."));

            d["SvIf"] = Spec(false,
                F.Source("Source", "Source (Tool.Output) - not needed when an output is linked to the Value input"),
                F.Enum("Operator", "Condition"),
                F.Text("CompareValue", "Compare value"),
                F.Text("CompareText", "Compare text (Text conditions, a|b = either; @cmd = HE)"),
                F.Text("BodyCount", "Controlled tools (next N)"),
                F.Note("The next N tools of this job run only when the condition is true; otherwise they are skipped."));

            d["SvHandEye"] = Spec(false,
                F.Enum("Mode", "Step"),
                F.Text("CalibrationFile", "Calibration file"),
                F.Source("PixelSource", "Mark position (Tool.Output)"),
                F.Text("RobotX", "Robot X (number, @request[1], Tool.Output)"),
                F.Text("RobotY", "Robot Y"),
                F.Int("MinPoints", "Solve: minimum points", 3, 100),
                F.Text("MaxError", "Solve: max error (0 = no check)"),
                F.Check("OriginAtCenter", "Origin at the picture centre"),
                F.Text("MarkShiftX", "Rotation: mark shift X"),
                F.Text("MarkShiftY", "Rotation: mark shift Y"),
                F.Text("Reply", "Reply OK ({cmd} {count} {maxerr} {meanerr} {centerx} {centery})"),
                F.Text("ReplyNg", "Reply NG ({message})"),
                F.Note("One SvHandEye per step behind an SvIf (@cmd = HEB / HE / HEE). It runs only when the robot sends the command."));

            d["SvMaster"] = Spec(false,
                F.Source("PixelSource", "Part position (Tool.Output)"),
                F.Text("CalibrationFile", "Calibration file (empty = SvAlign)"),
                F.Int("AlignPoint", "SvAlign point (0 = first)", 0, 100),
                F.Check("SaveJob", "Save the job after the master changed"),
                F.Text("Reply", "Reply OK ({cmd} {x:F3} {y:F3} {t:F3})"),
                F.Text("ReplyNg", "Reply NG ({message})"),
                F.Note("Behind an SvIf (@cmd = MS): the part position becomes the master (load position) of SvAlign."));

            d["SvFor"] = Spec(false,
                F.Int("Count", "Repeat count (0..1000)", 0, 1000),
                F.Int("BodyCount", "Repeated tools (next N)", 0, 1000),
                F.Note("The next N tools of this job run Count times. The iteration number is the output 'Index'."));

            d["SvTrigger"] = Spec(false,
                F.Header("Trigger source"),
                F.Enum("TriggerMode", "Mode (Io = PLC bits, Tcp = message)"),
                F.Text("TriggerConnection", "Tcp: connection name (or link ConnectionLink to an SvConnection)"),
                F.Text("StartCommand", "Tcp: commands that start the job (a|b|c, empty = any)"),
                F.Text("Separator", "Tcp: separator of the parts (, or ;)"),
                F.Text("AlignCommands", "Tcp: commands that align and send (a|b, empty = all)"),
                F.Text("ReplyUnknown", "Tcp: reply to an unknown command"),
                F.Text("Terminator", "Tcp: message end"),
                F.Text("ReplyOk", "Tcp: reply when OK"),
                F.Text("ReplyNg", "Tcp: reply when NG"),
                F.Header("Input signals (-1 = not used; not used in Tcp mode)"),
                F.Text("StartAddr", "Start"),
                F.Text("CompleteAddr", "Complete"),
                F.Header("Output signals"),
                F.Text("ReadyAddr", "Ready"),
                F.Text("AcqCompAddr", "AcqComp"),
                F.Text("OkAddr", "OK"),
                F.Text("NgAddr", "NG"),
                F.Text("Ok2Addr", "OK2"),
                F.Text("Ng2Addr", "NG2"),
                F.Text("InspNgAddr", "InspNG"),
                F.Text("InspNg2Addr", "InspNG2"),
                F.Header("Data areas (legacy layout)"),
                F.Text("OffsetStartAddress", "Offset start"),
                F.Text("InspectStartAddress", "Inspect start"),
                F.Text("CellIdAddress", "Cell ID"),
                F.Text("FdcStartAddress", "FDC start"),
                F.Header("Options"),
                F.Check("DualJudge", "Dual judge (OK2 / NG2)"),
                F.Check("UseAcqComp", "Use AcqComp"),
                F.Check("InspReverse", "Inspect bits reversed"),
                F.Check("AutoStart", "Start Auto automatically after saving (writes to the PLC)"));

            d["SvConnection"] = Spec(false,
                F.Text("ConnName", "Name"),
                F.Enum("ConnType", "Type"),
                F.Enum("ConnRole", "Used for"),
                F.Text("Host", "Host / IP"),
                F.Text("Port", "Port (-1 = system)"),
                F.Text("StationNumber", "Station No. (-1 = system)"),
                F.Text("DeviceType", "Device type (-1 = system)"),
                F.Text("IoThreadSleep", "IO sleep ms (-1 = system)"),
                F.Header("TCP / UDP / Serial / Modbus connections"),
                F.Text("TimeoutMs", "Timeout ms"),
                F.Enum("TextEncoding", "Text encoding"),
                F.Text("UnitId", "Modbus unit id"),
                F.Text("SerialPortName", "Serial port (COM1)"),
                F.Text("BaudRate", "Baud rate"),
                F.Enum("Parity", "Parity"),
                F.Text("DataBits", "Data bits"),
                F.Text("StopBits", "Stop bits (1 / 2)"));

            d["SvAlign"] = Spec(false,
                F.Text("CalibrationFile", "Calibration file (empty = recipe)"),
                F.Check("UseLimit", "Check limits (robot coordinates, T in degrees)"),
                F.Text("XMin", "X min"), F.Text("XMax", "X max"),
                F.Text("YMin", "Y min"), F.Text("YMax", "Y max"),
                F.Text("TMin", "T min"), F.Text("TMax", "T max"),
                F.Header("Value sent when NG"),
                F.Text("NgX", "NG X"), F.Text("NgY", "NG Y"), F.Text("NgT", "NG T"),
                F.Header("Align points (Source e.g. MakePoint1.OutPoint)"),
                F.Grid("Points", null, 190, "Source",
                    GridColumn.Text("Name", "Name", 80),
                    GridColumn.Text("Source", "Source", 140),
                    GridColumn.Text("LoadX", "Load X", 60), GridColumn.Text("LoadY", "Load Y", 60), GridColumn.Text("LoadT", "Load T", 60),
                    GridColumn.Text("OffsetX", "Off X", 55), GridColumn.Text("OffsetY", "Off Y", 55), GridColumn.Text("OffsetT", "Off T", 55)));

            FormItem fields = F.Grid("Fields", "Fields of the selected channel", 220, "Source",
                GridColumn.Text("Name", "Name", 70),
                GridColumn.Text("Source", "Source", 140),
                GridColumn.Enum("ValueType", "Type", 70),
                GridColumn.Text("Address", "Addr", 55),
                GridColumn.Text("Scale", "Scale", 55), GridColumn.Text("Offset", "Offs", 55),
                GridColumn.Check("UseRange", "Rng", 40),
                GridColumn.Text("Min", "Min", 55), GridColumn.Text("Max", "Max", 55));
            FormItem channels = F.Grid("Channels", "Channels", 150, null,
                GridColumn.Text("Name", "Name", 110),
                GridColumn.Check("Enabled", "On", 40),
                GridColumn.Enum("Kind", "Kind", 80),
                GridColumn.Text("StartIndex", "Start", 55),
                GridColumn.Enum("Condition", "When", 90),
                GridColumn.Text("Connection", "Connection", 90),
                GridColumn.Text("Template", "Template (Text)", 170),
                GridColumn.Text("Reply", "Reply contains", 100),
                GridColumn.Check("WordSwap", "Swap", 45));
            channels.Detail = fields;
            d["SvSend"] = Spec(false,
                F.Check("DryRun", "Dry run: compute and log, do not write to the PLC"),
                F.Header("Inputs: link an output to the input in the tool list, or type a value here"),
                F.Grid("Inputs", null, 170, null,
                    GridColumn.Text("Name", "Name ({name} in the message)", 170),
                    GridColumn.Text("Text", "Value when not linked", 220)),
                F.Note("+ Add row adds an input to this tool; the new input appears in the tool list, where an output can be linked to it."),
                F.Header("Message sent at the end of the cycle"),
                F.Text("Connection", "Connection name (or link the ConnectionLink input to an SvConnection)"),
                F.Text("Message", "Text ({name},{name:F3}\\r\\n ...)"),
                F.Enum("MessageWhen", "Send when"),
                F.Header("Advanced: channels (PLC / robot values, registers)"),
                channels);

            d["SvSplit"] = Spec(false,
                F.Text("SourcePath", "Text to split (when no output is linked to Source)"),
                F.Text("Separator", "Separator (, or ; or both)"),
                F.Check("Trim", "Remove spaces around each part"),
                F.Header("Outputs: one row per value you want"),
                F.Grid("Parts", null, 170, null,
                    GridColumn.Text("Name", "Output name", 150),
                    GridColumn.Text("Index", "Part (0 = first)", 100),
                    GridColumn.Check("IsNumber", "Number", 70)),
                F.Note("+ Add row adds an output to this tool. Part 0 of a robot message is the command. Count is the number of parts found."));

            // ---- tools that were still drawn by the old editor ----
            const double Big = 1000000000;
            d["SvAcquisition"] = Spec(true,
                F.Header("Camera"),
                F.Enum("CameraType", "Camera type"),
                F.ImageList("InputImageList", "CurrentImageIndex", "Images").If(t => F.Get(t, "CameraType") == "Image"),
                F.Int("CameraNumber", "Camera no", 0, 99).If(t => F.Get(t, "CameraType") != "Image"),
                F.Check("IsHwTrigger", "H/W trigger").If(t => F.Get(t, "CameraType") != "Image"),
                F.Int("ExposureTime", "Exposure time", 0, 10000000).If(t => F.Get(t, "CameraType") != "Image"),
                F.Int("BeforeGrabDelay", "Delay before grab (ms)", 0, 100000).If(t => F.Get(t, "CameraType") != "Image"),
                F.Header("Image"),
                F.Check("IsToGray", "Convert to gray"),
                F.Enum("eGrayType", "Gray type").If(t => F.Get(t, "IsToGray") == "True"),
                F.Check("IsHorizontalFilp", "Flip horizontally"),
                F.Check("IsVerticalFilp", "Flip vertically"),
                F.Enum("Rotate", "Rotate"),
                F.Readout("ImageFileName", "Image file"),
                F.Note("Camera configuration (the Camera Configure button) is in the Classic view."));

            d["SvBarcode"] = Spec(true,
                F.Enum("Type", "Barcode type"),
                F.Header("Region"),
                F.Int("RegionX", "X", -Big, Big), F.Int("RegionY", "Y", -Big, Big),
                F.Int("RegionWidth", "Width", 0, Big), F.Int("RegionHeight", "Height", 0, Big),
                F.Int("Index", "Index of the result", 0, 1000),
                F.Readout("ReadingResult", "Reading result"),
                F.Note("The list of all results is in the Classic view."));

            d["SvCameraCalibration"] = Spec(true,
                F.Header("Chessboard"),
                F.Int("ChessWidth", "Corners across", 1, 1000), F.Int("ChessHeight", "Corners down", 1, 1000),
                F.Num("ChessSize", "Square size", 0, Big, 3, 0.1),
                F.Int("ImageNum", "Number of images", 1, 1000),
                F.Header("Distortion"),
                F.Num("K1", "K1", -Big, Big, 6, 0.001), F.Num("K2", "K2", -Big, Big, 6, 0.001), F.Num("K3", "K3", -Big, Big, 6, 0.001),
                F.Num("P1", "P1", -Big, Big, 6, 0.001), F.Num("P2", "P2", -Big, Big, 6, 0.001),
                F.Header("Camera matrix"),
                F.Num("Fx", "Fx", -Big, Big, 4, 1), F.Num("Fy", "Fy", -Big, Big, 4, 1),
                F.Num("Cx", "Cx", -Big, Big, 4, 1), F.Num("Cy", "Cy", -Big, Big, 4, 1),
                F.Note("Collecting the chessboard images and calibrating are in the Classic view."));

            d["SvDataAnalysis"] = Spec(false,
                F.Header("Angle"),
                F.Num("Angle", "Angle", -360, 360, 3, 0.1),
                F.Num("AngleLow", "Low", -360, 360, 3, 0.1), F.Num("AngleHigh", "High", -360, 360, 3, 0.1),
                F.Readout("State", "Result"));

            d["SvDistance2P"] = Spec(false,
                F.Note("Link PointA and PointB in the tool list. The distance is measured between the two points."),
                F.Readout("DistanceResult", "Distance"));

            d["SvDistance3P"] = Spec(false,
                F.Note("Link the line and the points (A, B, C) in the tool list."),
                F.Readout("DistanceResult", "Distance"));

            d["SvFindLine"] = Spec(true,
                F.Enum("FittingType", "Fitting type"),
                F.Header("Points to ignore"),
                F.Choice("IgnoreType", "Ignore by", t => new string[] { "Number", "Percentage" }),
                F.Int("NumberOfIgnore", "Number of points", 0, 10000).If(t => F.Get(t, "IgnoreType") == "Number"),
                F.Int("PercentageOfIgnore", "Percentage (%)", 0, 100).If(t => F.Get(t, "IgnoreType") != "Number"),
                F.Int("UseNumberOfCalipers", "Calipers used", 1, 10000),
                F.Num("Score", "Score", -Big, Big, 3, 1),
                F.Note("The table of the caliper points is in the Classic view."));

            d["SvFindParallelLine"] = Spec(true,
                F.Enum("FittingType", "Fitting type"),
                F.Enum("ParallelOption", "Parallel option"),
                F.Num("DistanceFromRef", "Distance from the reference line", -Big, Big, 3, 1),
                F.Header("Points to ignore"),
                F.Choice("IgnoreType", "Ignore by", t => new string[] { "Number", "Percentage" }),
                F.Int("NumberOfIgnore", "Number of points", 0, 10000).If(t => F.Get(t, "IgnoreType") == "Number"),
                F.Int("PercentageOfIgnore", "Percentage (%)", 0, 100).If(t => F.Get(t, "IgnoreType") != "Number"),
                F.Int("UseNumberOfCalipers", "Calipers used", 1, 10000),
                F.Num("Score", "Score", -Big, Big, 3, 1),
                F.Note("The table of the caliper points is in the Classic view."));

            d["SvFixture"] = Spec(false,
                F.Header("Move"),
                F.Num("TranslateX", "Translate X", -Big, Big, 2, 1), F.Num("TranslateY", "Translate Y", -Big, Big, 2, 1),
                F.Header("Rotate and scale"),
                F.Num("Rotation", "Rotation (deg)", -360, 360, 2, 0.5),
                F.Num("Scale", "Scale", 0, 1000, 3, 0.01));

            d["SvHistogram"] = Spec(true,
                F.Header("Region"),
                F.Int("RegionX", "X", -Big, Big), F.Int("RegionY", "Y", -Big, Big),
                F.Int("RegionWidth", "Width", 0, Big), F.Int("RegionHeight", "Height", 0, Big),
                F.Header("Range"),
                F.Int("RangeLow", "Low", 0, 255), F.Int("RangeHigh", "High", 0, 255),
                F.Header("Result"),
                F.Readout("Minimum", "Minimum"), F.Readout("Maximum", "Maximum"),
                F.Readout("Mean", "Mean"), F.Readout("StdDev", "Std dev"),
                F.Note("The histogram graph and its table are in the Classic view."));

            d["SvIntersectLine"] = Spec(false,
                F.Note("Link LineA and LineB in the tool list."),
                F.Readout("IsIntersect", "Intersect"),
                F.Readout("Angle", "Angle"));

            d["SvMakeLattice"] = Spec(false, F.Enum("OutOption", "Output"));

            d["SvMakeLine"] = Spec(false,
                F.Note("Link the points in the tool list."),
                F.Num("LCreteria", "Length criteria", 0, Big, 3, 0.1),
                F.Readout("IsLine", "Is a line"));

            d["SvMakePoint"] = Spec(false, F.Enum("Origin", "Origin"));
            d["SvMakePoint2"] = Spec(false, F.Enum("Origin", "Origin"));

            d["SvMakeRectFromLine"] = Spec(false,
                F.Enum("LongShort", "Long / short side"),
                F.Enum("Origin", "Origin"),
                F.Num("ACreteria", "Angle criteria", 0, 360, 3, 0.1),
                F.Num("LCreteria", "Length criteria", 0, Big, 3, 0.1),
                F.Readout("IsRectangle", "Is a rectangle"));

            d["SvMakeRegions"] = Spec(false,
                F.Header("Long side"),
                F.Num("LongTrayToCell", "Tray to cell", -Big, Big, 2, 1), F.Num("LongCellToCell", "Cell to cell", -Big, Big, 2, 1),
                F.Num("LongCellArea", "Cell area", -Big, Big, 2, 1), F.Int("LongCellCount", "Cell count", 0, 10000),
                F.Header("Short side"),
                F.Num("ShortTrayToCell", "Tray to cell", -Big, Big, 2, 1), F.Num("ShortCellToCell", "Cell to cell", -Big, Big, 2, 1),
                F.Num("ShortCellArea", "Cell area", -Big, Big, 2, 1), F.Int("ShortCellCount", "Cell count", 0, 10000),
                F.Header("Mask"),
                F.Int("MaskLeft", "Left", 0, Big), F.Int("MaskRight", "Right", 0, Big),
                F.Int("MaskTop", "Top", 0, Big), F.Int("MaskBottom", "Bottom", 0, Big));

            d["SvMasking"] = Spec(true,
                F.Check("OnMask", "Draw the mask on the image"),
                F.Enum("PenType", "Pen"),
                F.Int("PenSize", "Pen size", 1, 1000));

            d["SvRegion"] = Spec(false,
                F.Header("Distance between regions"),
                F.Num("Dist_X", "X", -Big, Big, 2, 1), F.Num("Dist_Y", "Y", -Big, Big, 2, 1),
                F.Num("Dist_Xy", "Xy", -Big, Big, 2, 1), F.Num("Dist_Yx", "Yx", -Big, Big, 2, 1),
                F.Header("Count"),
                F.Int("Count_X", "Count X", 1, 10000), F.Int("Count_Y", "Count Y", 1, 10000),
                F.Header("Output index"),
                F.Check("IsAutoIndex", "Index changes automatically"),
                F.Int("Index_X", "Index X", 0, 10000), F.Int("Index_Y", "Index Y", 0, 10000),
                F.Check("XFirst", "X first"));

            d["SvResultAnalysis"] = Spec(false,
                F.Note("Link the values to judge in the tool list."),
                F.Readout("Result", "Result"));

            d["SvSharpness"] = Spec(false,
                F.Enum("Mode", "Mode"),
                F.OddInt("KernelSize", "Kernel size (odd)", 1, 31),
                F.Num("Scale", "Scale", -Big, Big, 3, 0.1), F.Num("Delta", "Delta", -Big, Big, 3, 0.1),
                F.Num("Alpha", "Alpha", -Big, Big, 3, 0.1), F.Num("Beta", "Beta", -Big, Big, 3, 0.1),
                F.Num("Gamma", "Gamma", -Big, Big, 3, 0.1));

            d["SvSubImage"] = Spec(false,
                F.Note("Draw the sub image rectangle on the image. The output is the part of the image inside the rectangle."));

            d["SvWarpping"] = Spec(true,
                F.Enum("OutOption", "Output"),
                F.Check("DontMakeOutImage", "Do not make the output image"),
                F.Note("Choosing the points on the image is in the Classic view."));

            d["SvJudgementOverpocket"] = Spec(false,
                F.Header("Condition 1  (input: Score)"),
                F.Choice("Comparison1", "Comparison", t => SvJudgementOverpocket.ComparisonList.Values.ToList()),
                F.Num("Creteria1", "Criteria", -Big, Big, 3, 0.1),
                F.Num("Creteria1_", "Criteria 2 (upper limit)", -Big, Big, 3, 0.1).If(t => F.Get(t, "Comparison1") == "InRange"),
                F.Readout("Judgement1", "Judgement"),
                F.Header("Condition 2  (input: X)"),
                F.Choice("Comparison2", "Comparison", t => SvJudgementOverpocket.ComparisonList.Values.ToList()),
                F.Num("Creteria2", "Criteria", -Big, Big, 3, 0.1),
                F.Num("Creteria2_", "Criteria 2 (upper limit)", -Big, Big, 3, 0.1).If(t => F.Get(t, "Comparison2") == "InRange"),
                F.Readout("Judgement2", "Judgement"),
                F.Header("Condition 3  (input: Y)"),
                F.Choice("Comparison3", "Comparison", t => SvJudgementOverpocket.ComparisonList.Values.ToList()),
                F.Num("Creteria3", "Criteria", -Big, Big, 3, 0.1),
                F.Num("Creteria3_", "Criteria 2 (upper limit)", -Big, Big, 3, 0.1).If(t => F.Get(t, "Comparison3") == "InRange"),
                F.Readout("Judgement3", "Judgement"),
                F.Header("Condition 4  (input: T)"),
                F.Choice("Comparison4", "Comparison", t => SvJudgementOverpocket.ComparisonList.Values.ToList()),
                F.Num("Creteria4", "Criteria", -Big, Big, 3, 0.1),
                F.Num("Creteria4_", "Criteria 2 (upper limit)", -Big, Big, 3, 0.1).If(t => F.Get(t, "Comparison4") == "InRange"),
                F.Readout("Judgement4", "Judgement"),
                F.Note("Link Score, X, Y and T in the tool list."));

            d["SvTemplateMatchOverpocket"] = Spec(true,
                F.Header("Search"),
                F.Num("PCreteria", "Score threshold", 0, 1, 3, 0.01),
                F.Int("MaxCount", "Max count", 1, 10000),
                F.Num("Precision", "Precision", 0, Big, 3, 0.1),
                F.Num("FirstStep", "First step", 0, Big, 3, 0.1),
                F.Enum("Priority", "Priority"),
                F.Header("Angle"),
                F.Int("AngleNeg", "Angle -", -360, 360), F.Int("AnglePos", "Angle +", -360, 360),
                F.Header("Scale"),
                F.Num("ScaleFirst", "Scale first", 0, 100, 3, 0.01), F.Num("ScaleLast", "Scale last", 0, 100, 3, 0.01),
                F.Num("TempScaleMin", "Template scale min", 0, 100, 3, 0.01), F.Num("TempScaleMax", "Template scale max", 0, 100, 3, 0.01),
                F.Header("Edge"),
                F.Check("UseEdge", "Use edge"),
                F.Int("THLow", "Threshold low", 0, 255).If(t => F.Get(t, "UseEdge") == "True"),
                F.Int("THHigh", "Threshold high", 0, 255).If(t => F.Get(t, "UseEdge") == "True"),
                F.Header("Options"),
                F.Check("AutoParam", "Automatic parameters"),
                F.Check("IsAutoIndex", "Automatic pattern index"),
                F.Readout("Score", "Score"),
                F.Note("The pattern list (grab, add, remove, load, save) and the mask are in the Classic view."));

            d["SvWarppingPoint"] = Spec(true,
                F.Note("Link InputPoint in the tool list. Loading the calibration data is in the Classic view."));

            return d;
        }

        static bool ShowsRange(SvToolBase t)
        {
            string mode = F.Get(t, "Mode");
            if (mode == "Nick" || mode == "NiblackFast" || mode == "SauvolaFast") return false;
            if (mode == "Theshold" && F.Get(t, "Type") == "Otsu") return false;
            return true;
        }
    }
}
