﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Diagnostics;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{    
    public class UDPClient
    {
        private UdpClient m_UdpClient;          //UDP Network Service 제공     
        private IPAddress m_IPAddress;          //IP Address 제공       
        private IPEndPoint m_IPEndPoint;        //Sending 용 Endpoint
        private IPEndPoint m_ReciveEndPoint;    //Recieve 용 Endpoint
        //byte[] sendbyte = new byte[32];        //Sending packet buffer(고정사용시)
        //byte[] recvbyte = new byte[32];         //Recieve packet buffer(고정사용시)
        public bool mThreadFlag = false;

        public UDPClient()
        {
         
        }

        public void Connect(string IP, int sendingPort, int recievePort, int TimeOut)
        {
            m_UdpClient = new UdpClient();
            m_IPAddress = IPAddress.Parse(IP);

            m_IPEndPoint = new IPEndPoint(m_IPAddress, sendingPort);
            m_ReciveEndPoint = new IPEndPoint(m_IPAddress, recievePort);
            m_UdpClient.Client.ReceiveTimeout = TimeOut;
        }
        public void DisConnect()
        {
            m_UdpClient.Close();
        }

        public void Sendata(string msg)
        {
            byte[] datagram = Encoding.UTF8.GetBytes(msg);

            m_UdpClient.Send(datagram, datagram.Length, m_IPEndPoint);

            DisConnect();
        }


    }
}
