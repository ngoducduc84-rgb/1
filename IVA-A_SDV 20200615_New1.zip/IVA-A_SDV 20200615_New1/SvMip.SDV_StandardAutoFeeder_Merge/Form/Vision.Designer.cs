﻿namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    partial class Vision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_CurrentRecipe = new System.Windows.Forms.Label();
            this.svJobEdit1 = new SvMip.Edit.SvJobEdit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(664, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "Current Recipe :";
            // 
            // lbl_CurrentRecipe
            // 
            this.lbl_CurrentRecipe.AutoSize = true;
            this.lbl_CurrentRecipe.Location = new System.Drawing.Point(783, 19);
            this.lbl_CurrentRecipe.Name = "lbl_CurrentRecipe";
            this.lbl_CurrentRecipe.Size = new System.Drawing.Size(35, 12);
            this.lbl_CurrentRecipe.TabIndex = 2;
            this.lbl_CurrentRecipe.Text = "None";
            // 
            // svJobEdit1
            // 
            this.svJobEdit1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.svJobEdit1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.svJobEdit1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.svJobEdit1.Location = new System.Drawing.Point(10, 47);
            this.svJobEdit1.Name = "svJobEdit1";
            this.svJobEdit1.Size = new System.Drawing.Size(1436, 863);
            this.svJobEdit1.TabIndex = 0;
            // 
            // Vision
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.lbl_CurrentRecipe);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.svJobEdit1);
            this.Name = "Vision";
            this.Size = new System.Drawing.Size(1460, 920);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Edit.SvJobEdit svJobEdit1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_CurrentRecipe;
    }
}