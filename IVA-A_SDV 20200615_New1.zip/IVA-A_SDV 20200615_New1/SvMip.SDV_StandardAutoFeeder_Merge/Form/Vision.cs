﻿using OpenCvSharp.CPlusPlus;
using System;
using System.IO;
using System.Windows.Forms;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    public partial class Vision : UserControl
    {
        SystemData mSys;
        RecipeData mRcp;

        /// <summary>The processes that can be edited (shown as pills in the WPF header).</summary>
        public readonly System.Collections.Generic.List<string> ProcessNames = new System.Collections.Generic.List<string>();
        public string ActiveProcess { get; private set; }
        public string CurrentRecipe { get { return Auto.mCurrentRecipeName; } }
        public string JobFile { get { return string.IsNullOrEmpty(svJobEdit1.FilePath) ? "" : Path.GetFileName(svJobEdit1.FilePath); } }
        public event EventHandler ProcessChanged;
        /// <summary>The panel in which the tool editors are shown (the WPF column at the right hosts it).</summary>
        public Panel CreateDockPanel()
        {
            Panel p = svJobEdit1.UseExternalDock();
            if (SvMip.Edit.SvDarkTheme.Enabled) SvMip.Edit.SvDarkTheme.Apply(p);
            return p;
        }

        public SvMip.Edit.SvJobEdit JobEdit { get { return svJobEdit1; } }
        public bool SaveJob(bool saveAs) { return svJobEdit1.SaveJob(saveAs); }
        public Vision()
        {
            SvCalibrationService.Install();
            InitializeComponent();

            mSys = new SystemData();
            mSys.LoadData();
            foreach (var kv in mSys.DicProcess)
            {
                if (kv.Key == Main.Process.Common) continue;
                if (!kv.Value.Use) continue;
                ProcessNames.Add(kv.Key.ToString());
            }

            this.Disposed += (a, b) => { svJobEdit1.Dispose(); };

            lbl_CurrentRecipe.Text = Auto.mCurrentRecipeName;

            svJobEdit1.OnSaved += (sender, e) => { Auto.IsRecipeDataChanged = true; Auto.AutoStartAfterSave = true; Auto.ChangedJobProcess = mEditingProcess; ShowJobWarnings(); };
            svJobEdit1.PATH_JOB = Path.Combine(Main.RootPath, "SVL_Data", "Job");

            InitJobCheckPanel();
            InitActionButtons();
            svJobEdit1.Notice += (sender, e) => SvMip.Edit.SvToast.Show(this, e.Message, e.IsError);

            // dark colours like the rest of the program (create SVL_Data\ClassicVisionTheme.flag to keep the old look)
            if (!File.Exists(Path.Combine(Main.RootPath, "SVL_Data", "ClassicVisionTheme.flag")))
                SvMip.Edit.SvDarkTheme.Apply(this);
        }

        /// <summary>The process that is being edited is shown with the accent colour.</summary>
        void HighlightProcessButton(string processName)
        {
            foreach (Control c in Controls)
            {
                Button b = c as Button;
                if (b == null || !object.Equals(b.Tag, "process")) continue;
                bool active = (b.Text == processName);
                b.FlatStyle = FlatStyle.Flat;
                b.UseVisualStyleBackColor = false;
                b.BackColor = active ? System.Drawing.Color.FromArgb(76, 154, 255) : System.Drawing.Color.FromArgb(43, 49, 56);
                b.ForeColor = active ? System.Drawing.Color.White : System.Drawing.Color.FromArgb(232, 236, 239);
                b.FlatAppearance.BorderColor = active ? System.Drawing.Color.FromArgb(76, 154, 255) : System.Drawing.Color.FromArgb(68, 76, 86);
            }
        }

        // ---- Dry run / Save as / Save / Save & Run (top right) ----
        void InitActionButtons()
        {
            // the buttons and the recipe name are in the WPF header now; the editor fills the whole control
            label1.Visible = false;
            lbl_CurrentRecipe.Visible = false;
            svJobEdit1.Location = new System.Drawing.Point(0, 0);
            svJobEdit1.Size = ClientSize;
            svJobEdit1.BorderStyle = BorderStyle.None;
            svJobEdit1.HideToolbar(); // run / auto run are in the WPF header
            svJobEdit1.HideSidePanel(); // the tool list is drawn by the WPF header/panel
        }

        /// <summary>Lists the earlier saved versions of the open job and loads the chosen one into the editor (it is not saved).</summary>
        public void DoHistory()
        {
            try
            {
                if (svJobEdit1.Job == null || string.IsNullOrEmpty(svJobEdit1.FilePath))
                {
                    SvMip.Edit.SvToast.Show(this, "Open the job of a process first.", true);
                    return;
                }
                string file = svJobEdit1.FilePath;
                string name = Path.GetFileNameWithoutExtension(file);
                using (SvMip.Edit.SvJobHistoryDialog dlg = new SvMip.Edit.SvJobHistoryDialog(name, SvMip.Edit.SvJobHistory.List(file)))
                {
                    if (dlg.ShowDialog(this) != DialogResult.OK || string.IsNullOrEmpty(dlg.SelectedFile)) return;
                    SvSerializer serializer = new SvSerializer();
                    SvJob old = serializer.LoadJob(dlg.SelectedFile);
                    if (old == null)
                    {
                        SvMip.Edit.SvToast.Show(this, "That version could not be loaded.", true);
                        return;
                    }
                    old.Name = svJobEdit1.Job.Name;
                    svJobEdit1.Job = old;
                    SvMip.Edit.SvToast.Show(this, "Older version loaded. Press Save to keep it.", false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "History", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>Opens Quick Setup and adds the chosen SvConnection / SvTrigger / SvSend to the open job.</summary>
        public void DoQuickSetup()
        {
            try
            {
                SvJob job = svJobEdit1.Job;
                if (job == null)
                {
                    SvMip.Edit.SvToast.Show(this, "Open the job of a process first (buttons at the top left).", true);
                    return;
                }

                QuickSetupDialog dlg = new QuickSetupDialog();
                if (dlg.ShowDialog(this) != DialogResult.OK || dlg.CreatedTools == null) return;

                // the job may already hold such tools: replace them, or cancel
                System.Collections.Generic.List<SvToolBase> existing = new System.Collections.Generic.List<SvToolBase>();
                foreach (SvToolBase t in job.ToolList)
                    if (t is SvConnection || t is SvTrigger || t is SvSend) existing.Add(t);
                if (existing.Count > 0)
                {
                    DialogResult r = MessageBox.Show("This job already has " + existing.Count + " SvConnection / SvTrigger / SvSend tool(s).\n\nYes = replace them with the new setup\nNo = cancel",
                        "Quick Setup", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (r != DialogResult.Yes) return;
                    foreach (SvToolBase t in existing) job.ToolList.Remove(t);
                }

                // connection and trigger come first (before the vision tools), the SvSend at the end
                int at = 0;
                foreach (SvToolBase t in dlg.CreatedTools)
                {
                    if (t is SvSend) job.ToolList.Add(t);
                    else job.ToolList.Insert(at++, t);
                }
                svJobEdit1.Job = job; // redraws the tool tree
                svJobEdit1.ShowToolByName(dlg.CreatedTools[0].ToString());
                SvMip.Edit.SvToast.Show(this, "Quick Setup added " + dlg.CreatedTools.Count + " tools. Check them, then Save.", false);
                ShowJobWarnings("Quick Setup added the tools. ");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Quick Setup", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>Runs the job once on the current image and shows what every SvSend field would send. Nothing is written.</summary>
        public void DoDryRun()
        {
            try
            {
                if (svJobEdit1.Job == null) return;
                svJobEdit1.Run();
                string title = svJobEdit1.Job.LastRunSuccess ? "Job ran OK." : "Job run FAILED (values may be missing).";
                System.Collections.Generic.List<SvDryRunRow> rows = SvDryRun.Evaluate(svJobEdit1.Job);
                using (SvMip.Edit.SvDryRunDialog dlg = new SvMip.Edit.SvDryRunDialog(title, rows))
                    dlg.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Dry run", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>Saves, checks the job and switches to the AUTO screen (which starts the job as before). Errors in the job check block the switch.</summary>
        public void DoSaveAndRun()
        {
            if (!svJobEdit1.SaveJob(false)) return;
            BindJobToProcess();
            System.Collections.Generic.List<SvJobIssue> issues = SvJobCheck.Run(svJobEdit1.Job);
            int errors = SvJobCheck.Count(issues, SvIssueLevel.Error);
            if (errors > 0)
            {
                SvMip.Edit.SvToast.Show(this, "Saved, but not started: " + errors + (errors == 1 ? " error" : " errors") + " in the job check.", true);
                return;
            }
            // leave the click handler first: switching the screen disposes this Vision control
            BeginInvoke(new Action(delegate
            {
                VMMainFrame frame = Main.DicSubViews[ViewName.MainFrame] as VMMainFrame;
                if (frame != null) frame.IsAuto = true;
            }));
        }

        // ---- Job check panel (replaces the MessageBox after saving) ----
        const int CheckPanelHeight = 170;
        SvMip.Edit.SvJobCheckPanel mCheckPanel;

        void InitJobCheckPanel()
        {
            mCheckPanel = new SvMip.Edit.SvJobCheckPanel();
            mCheckPanel.Visible = false;
            mCheckPanel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mCheckPanel.RecheckRequested += delegate { ShowJobWarnings("Checked again. "); };
            mCheckPanel.CloseRequested += delegate { SetCheckPanelVisible(false); };
            mCheckPanel.IssueActivated += delegate(object s, SvMip.Edit.SvJobIssueEventArgs a) { svJobEdit1.ShowToolByName(a.Issue.ToolName); };
            Controls.Add(mCheckPanel);
            mCheckPanel.BringToFront();
        }

        void SetCheckPanelVisible(bool show)
        {
            if (mCheckPanel == null) return;
            if (show)
            {
                mCheckPanel.SetBounds(svJobEdit1.Left, ClientSize.Height - CheckPanelHeight - 6, svJobEdit1.Width, CheckPanelHeight);
                svJobEdit1.Height = mCheckPanel.Top - 6 - svJobEdit1.Top;
                mCheckPanel.Visible = true;
                mCheckPanel.BringToFront();
            }
            else
            {
                mCheckPanel.Visible = false;
                svJobEdit1.Height = ClientSize.Height - svJobEdit1.Top;
            }
        }

        /// <summary>Shows what is wrong with the self-contained job setup (SvTrigger / SvConnection / SvAlign / SvSend).</summary>
        Main.Process? mEditingProcess = null;

        private void ShowJobWarnings()
        {
            ShowJobWarnings("The job was saved. ");
        }

        private void ShowJobWarnings(string prefix)
        {
            try
            {
                System.Collections.Generic.List<SvJobIssue> issues = SvJobCheck.Run(svJobEdit1.Job);
                if (issues.Count == 0)
                {
                    SetCheckPanelVisible(false);
                    return;
                }
                mCheckPanel.SetIssues(issues, prefix);
                SetCheckPanelVisible(true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Job check", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        /// Makes the open job the job of the process that is being edited (and saves the recipe), so that AUTO runs it
        /// without going through the DATA screen. Only for jobs inside the job folder.
        /// </summary>
        public bool BindJobToProcess()
        {
            try
            {
                string file = svJobEdit1.FilePath;
                if (svJobEdit1.Job == null || string.IsNullOrEmpty(file) || mRcp == null || mEditingProcess == null) return false;
                string dir = Path.GetDirectoryName(Path.GetFullPath(file)).TrimEnd('\\', '/');
                string jobDir = Path.GetFullPath(Main.JobPath).TrimEnd('\\', '/');
                if (!string.Equals(dir, jobDir, StringComparison.OrdinalIgnoreCase)) return false;
                string name = Path.GetFileName(file);
                if (mRcp.DicProcess[mEditingProcess.Value].Job.Name == name) return true;
                mRcp.DicProcess[mEditingProcess.Value].Job.Name = name;
                mRcp.SaveData();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void SelectProcess(string processName)
        {
            ActiveProcess = processName;
            Main.Process process = (Main.Process)Enum.Parse(typeof(Main.Process), processName);
            mEditingProcess = process;

            mRcp = new RecipeData(Auto.mCurrentRecipeName, mSys);
            mRcp.LoadData(true);
            if (mRcp == null) return;

            if (string.IsNullOrEmpty(mRcp.DicProcess[process].Job.Name)) return;
            
            SvSerializer serializer = new SvSerializer();
            try
            {
                this.svJobEdit1.Job = serializer.LoadJob(Path.Combine(Main.JobPath, mRcp.DicProcess[process].Job.Name));
                this.svJobEdit1.FilePath = Path.Combine(Main.JobPath, mRcp.DicProcess[process].Job.Name);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (ProcessChanged != null) ProcessChanged(this, EventArgs.Empty);
        }

        private void btn_UnLoadJob_Click(object sender, System.EventArgs e)
        {
            //DataManager에서 LoadRecipe를 없애면서 다시 고민해볼필요가....
            ////if (Auto.currentRecipe == null || Auto.currentRecipe.Job[Main.Process.Tray1] == null) return;
            ////this.svJobEdit1.Job = Auto.currentRecipe.Job[Main.Process.Tray1];
            //Recipe recipe = DataManager.Instance.LoadRecipe(Auto.mCurrentRecipeName);  
            //if (recipe == null) return;
            //this.svJobEdit1.Job = recipe.Job[Main.Process.Tray1];
        }
    }
}
