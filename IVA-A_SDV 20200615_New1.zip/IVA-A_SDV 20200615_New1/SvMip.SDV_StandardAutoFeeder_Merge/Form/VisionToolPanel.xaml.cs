﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using SvMip.Edit;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// The tool list of the VISION screen (WPF). It works on the job of the WinForms editor: select, open, add after the
    /// selected tool, delete, rename, move (drag), copy (Ctrl + drag), link an output to a later tool's input (drag), run times.
    /// </summary>
    public partial class VisionToolPanel : UserControl
    {
        // a tool, an input or an output of a tool, as it is carried by drag and drop
        class ParamRef
        {
            public SvToolBase Tool;
            public string Name;
            public bool IsInput;
        }

        // an output that can feed an input
        class Candidate
        {
            public SvToolBase Tool;
            public string Name;
        }

        // an input that accepts a link (kept to light up the ones that fit while an output is dragged)
        class Target
        {
            public Border Box;
            public ParamRef Ref;
        }

        class Row
        {
            public SvToolBase Tool;
            public Border Card;
            public TextBlock Time;
            public ColumnDefinition BarFill;
            public ColumnDefinition BarRest;
            public Border Bar;
            public StackPanel Params;
            public TextBlock Name;
            public bool IsNode;      // the Input or Output node of a tool block
            public string Label;
        }

        static readonly Brush InputBrush = Freeze(new SolidColorBrush(Color.FromRgb(255, 125, 125)));
        static readonly Brush OutputBrush = Freeze(new SolidColorBrush(Color.FromRgb(120, 175, 255)));
        static readonly Brush SelectedBack = Freeze(new SolidColorBrush(Color.FromRgb(31, 53, 80)));
        static readonly Brush HoverBack = Freeze(new SolidColorBrush(Color.FromRgb(34, 40, 51)));
        static readonly Brush MatchBack = Freeze(new SolidColorBrush(Color.FromRgb(74, 64, 32)));
        static readonly Brush Transparent = Brushes.Transparent;

        static Brush Freeze(SolidColorBrush b) { b.Freeze(); return b; }

        readonly IToolListHost mEdit;
        readonly List<Row> mRows = new List<Row>();
        readonly List<Target> mTargets = new List<Target>();
        ParamRef mDragSource;
        SvToolBase mSelected;
        bool mShowAllParams;
        bool mBusy;
        Point mDragStart;
        Brush mText, mMuted, mLine, mAccent, mCard, mBg, mWarn;

        public VisionToolPanel(IToolListHost edit)
        {
            InitializeComponent();
            mEdit = edit;
            mText = (Brush)FindResource("IvaTextBrush");
            mMuted = (Brush)FindResource("IvaMutedBrush");
            mLine = (Brush)FindResource("IvaLineBrush");
            mAccent = (Brush)FindResource("IvaAccentBrush");
            mCard = (Brush)FindResource("IvaCardBrush");
            mBg = (Brush)FindResource("IvaBgBrush");
            mWarn = (Brush)FindResource("IvaWarnBrush");

            edit.JobLoaded += delegate { mSelected = null; Rebuild(); };
            edit.JobStructureEdited += delegate
            {
                // the same tool stays selected (a table of its form added an input / output)
                SvToolBase keep = mSelected;
                Rebuild();
                if (keep != null && !object.ReferenceEquals(mSelected, keep)) { mSelected = keep; UpdateSelection(); }
            };
            edit.JobRan += delegate { Dispatcher.BeginInvoke(new Action(UpdateTimes)); };
            edit.ToolSelected += delegate(object s, SvToolEventArgs e)
            {
                if (mBusy) return;
                mSelected = e.Tool;
                UpdateSelection();
            };

            Search.TextChanged += delegate { MarkMatches(); };
            Search.KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Key == Key.Enter) { e.Handled = true; SelectNextMatch(); }
            };
            ParamToggle.MouseLeftButtonUp += delegate
            {
                mShowAllParams = !mShowAllParams;
                ParamToggle.Background = mShowAllParams ? SelectedBack : Transparent;
                ParamToggleText.Foreground = mShowAllParams ? mText : mMuted;
                UpdateSelection();
            };
            AddBtn.MouseLeftButtonUp += delegate { ShowAddPopup(); };
            AddBtn.MouseEnter += delegate { AddBtn.Background = SelectedBack; };
            AddBtn.MouseLeave += delegate { AddBtn.Background = Transparent; };

            // drop on the empty part of the list: move to the end
            Rows.DragOver += delegate(object s, DragEventArgs e) { if (e.Data.GetDataPresent("SvTool")) SetToolEffect(e); };
            Rows.Drop += delegate(object s, DragEventArgs e)
            {
                if (e.Handled) return;
                DropTool(e, mEdit.Job == null ? 0 : mEdit.Job.ToolList.Count);
            };
            KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Key == Key.Delete && mSelected != null && !IsNode(mSelected) && !Search.IsKeyboardFocused) { e.Handled = true; DeleteTool(mSelected); }
            };

            Rebuild();
        }

        SvJob Job { get { return mEdit.Job; } }

        bool IsNode(SvToolBase tool)
        {
            return tool != null && (object.ReferenceEquals(tool, mEdit.InputNode) || object.ReferenceEquals(tool, mEdit.OutputNode));
        }

        /// <summary>Input node, the tools, Output node: the order in which a value can be passed on.</summary>
        List<SvToolBase> Order()
        {
            List<SvToolBase> l = new List<SvToolBase>();
            if (mEdit.InputNode != null) l.Add(mEdit.InputNode);
            if (Job != null && Job.ToolList != null) l.AddRange(Job.ToolList);
            if (mEdit.OutputNode != null) l.Add(mEdit.OutputNode);
            return l;
        }

        // ---------------------------------------------------------------- building the list
        void Rebuild()
        {
            Rows.Children.Clear();
            mRows.Clear();
            mTargets.Clear();
            SvJob job = Job;
            if (job == null || job.ToolList == null) { CountText.Text = ""; UpdateAddText(); return; }

            if (mEdit.InputNode != null)
            {
                Row inRow = BuildRow(mEdit.InputNode, -1);
                mRows.Add(inRow);
                Rows.Children.Add(inRow.Card);
            }
            int toolCount = 0;
            for (int i = 0; i < job.ToolList.Count; i++)
            {
                SvToolBase tool = job.ToolList[i];
                if (tool == null) continue;
                Row row = BuildRow(tool, i);
                mRows.Add(row);
                Rows.Children.Add(row.Card);
                toolCount++;
            }
            if (mEdit.OutputNode != null)
            {
                Row outRow = BuildRow(mEdit.OutputNode, -2);
                mRows.Add(outRow);
                Rows.Children.Add(outRow.Card);
            }
            CountText.Text = toolCount + (toolCount == 1 ? " tool" : " tools");
            UpdateSelection();
            UpdateTimes();
            MarkMatches();
        }

        TextBlock Tb(string text, double size, Brush brush, FontWeight weight)
        {
            TextBlock t = new TextBlock();
            t.Text = text;
            t.FontSize = size;
            t.FontWeight = weight;
            t.Foreground = brush;
            t.HorizontalAlignment = HorizontalAlignment.Left;
            t.VerticalAlignment = VerticalAlignment.Center;
            t.TextTrimming = TextTrimming.CharacterEllipsis;
            return t;
        }

        Row BuildRow(SvToolBase tool, int index)
        {
            Row row = new Row();
            row.Tool = tool;
            row.IsNode = index < 0;
            if (row.IsNode) row.Label = index == -1 ? "Input" : "Output";

            Border card = new Border();
            card.CornerRadius = new CornerRadius(6);
            card.Margin = new Thickness(0, 0, 0, 4);
            card.Padding = new Thickness(8, 7, 8, 7);
            card.BorderThickness = new Thickness(2, 0, 0, 0);
            card.BorderBrush = Transparent;
            card.Background = Transparent;
            card.AllowDrop = true;
            card.Tag = tool;
            row.Card = card;

            StackPanel body = new StackPanel();
            card.Child = body;

            Grid head = new Grid();
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(26) });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            TextBlock no = Tb(row.IsNode ? (index == -1 ? "\u25B8" : "\u25C2") : (index + 1).ToString(), 11, mMuted, FontWeights.Normal);
            row.Name = Tb(row.IsNode ? row.Label : tool.ToString(), 13, mText, FontWeights.SemiBold);
            row.Time = Tb("", 11, mMuted, FontWeights.Normal);
            row.Time.Margin = new Thickness(8, 0, 0, 0);
            Grid.SetColumn(no, 0);
            Grid.SetColumn(row.Name, 1);
            Grid.SetColumn(row.Time, 2);
            head.Children.Add(no);
            head.Children.Add(row.Name);
            head.Children.Add(row.Time);
            body.Children.Add(head);

            // run time bar
            Grid track = new Grid();
            track.Height = 3;
            track.Margin = new Thickness(26, 5, 0, 0);
            Border trackBg = new Border { CornerRadius = new CornerRadius(1.5), Background = mLine, Opacity = 0.5 };
            track.Children.Add(trackBg);
            Grid fillGrid = new Grid();
            row.BarFill = new ColumnDefinition { Width = new GridLength(0, GridUnitType.Star) };
            row.BarRest = new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) };
            fillGrid.ColumnDefinitions.Add(row.BarFill);
            fillGrid.ColumnDefinitions.Add(row.BarRest);
            row.Bar = new Border { CornerRadius = new CornerRadius(1.5), Background = mAccent };
            fillGrid.Children.Add(row.Bar);
            track.Children.Add(fillGrid);
            body.Children.Add(track);

            // inputs and outputs
            row.Params = new StackPanel();
            row.Params.Margin = new Thickness(26, 6, 0, 0);
            foreach (string name in tool.GetInputParamNames()) row.Params.Children.Add(BuildParam(tool, name, true));
            foreach (string name in tool.GetOutputParamNames()) row.Params.Children.Add(BuildParam(tool, name, false));
            body.Children.Add(row.Params);

            WireCard(row);
            return row;
        }

        string NameOf(SvToolBase t)
        {
            if (object.ReferenceEquals(t, mEdit.InputNode)) return "Input";
            if (object.ReferenceEquals(t, mEdit.OutputNode)) return "Output";
            return t.ToString();
        }

        // ---------------------------------------------------------------- links: types, suggestions, the chip, the picker
        static readonly Brush WarnText = Freeze(new SolidColorBrush(Color.FromRgb(240, 180, 70)));
        static readonly Brush LinkBack = Freeze(new SolidColorBrush(Color.FromRgb(31, 53, 80)));

        static Type TypeOfInput(SvToolBase tool, string name)
        {
            try
            {
                PropertyInfo p = tool.GetType().GetProperty(name);
                return p == null ? null : p.PropertyType;
            }
            catch (Exception) { return null; }
        }

        static Type TypeOfOutput(SvToolBase tool, string name)
        {
            try
            {
                PropertyInfo p = tool.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public);
                if (p != null) return p.PropertyType;
                object v;
                if (tool.outParams.TryGetValue(name, out v) && v != null) return v.GetType();
            }
            catch (Exception) { }
            return null;
        }

        /// <summary>The program only accepts a link between values of exactly the same type (otherwise it shows a message and drops the link).</summary>
        static bool TypesMatch(SvToolBase src, string outName, SvToolBase dst, string inName)
        {
            Type ts = TypeOfOutput(src, outName), td = TypeOfInput(dst, inName);
            if (td == typeof(object)) return ts != typeof(SvImage); // an input that takes any value (SvIf, SvSplit ...)
            return ts == null || td == null || ts == td;
        }

        static string TypeLabel(Type t)
        {
            if (t == null || t == typeof(object)) return "Any";
            if (t == typeof(SvImage)) return "Image";
            if (t == typeof(double) || t == typeof(float) || t == typeof(int) || t == typeof(long) || t == typeof(short)) return "Number";
            if (t == typeof(bool)) return "Yes/No";
            if (t == typeof(string)) return "Text";
            return t.Name.StartsWith("Sv") ? t.Name.Substring(2) : t.Name;
        }

        /// <summary>What the output holds now, as a short text ("640 x 480", "0.953"); "no value yet" before the first run.</summary>
        static string Preview(SvToolBase src, string outName)
        {
            try
            {
                object v;
                if (!src.outParams.TryGetValue(outName, out v) || v == null) return "no value yet";
                SvImage img = v as SvImage;
                if (img != null) return img.IsNull ? "empty image" : img.Width + " \u00D7 " + img.Height;
                if (v is double) return ((double)v).ToString("0.###");
                if (v is float) return ((float)v).ToString("0.###");
                string s = v.ToString();
                return s.Length > 22 ? s.Substring(0, 22) + "\u2026" : s;
            }
            catch (Exception) { return ""; }
        }

        bool CanLink(SvToolBase srcTool, string outName, SvToolBase dstTool, string inName)
        {
            List<SvToolBase> list = Order();
            int s = list.IndexOf(srcTool), d = list.IndexOf(dstTool);
            if (s < 0 || d < 0 || s >= d) return false; // an input takes its value from an earlier tool
            return TypesMatch(srcTool, outName, dstTool, inName);
        }

        /// <summary>The outputs of the earlier tools that fit the input, the nearest tool first. hidden = how many others (another type) were left out.</summary>
        List<Candidate> Candidates(SvToolBase tool, string input, out int hidden)
        {
            hidden = 0;
            List<Candidate> good = new List<Candidate>();
            List<SvToolBase> order = Order();
            int at = order.IndexOf(tool);
            for (int i = at - 1; i >= 0; i--)
            {
                SvToolBase src = order[i];
                if (src == null) continue;
                foreach (string o in src.GetOutputParamNames())
                {
                    if (TypesMatch(src, o, tool, input)) good.Add(new Candidate { Tool = src, Name = o });
                    else hidden++;
                }
            }
            return good;
        }

        /// <summary>The obvious source: the output with the same name, or for a picture the picture of the nearest tool (its OutputImage first).</summary>
        static Candidate Suggest(SvToolBase tool, string input, List<Candidate> list)
        {
            foreach (Candidate c in list)
                if (string.Equals(c.Name, input, StringComparison.OrdinalIgnoreCase)) return c;
            if (list.Count > 0 && TypeOfInput(tool, input) == typeof(SvImage))
            {
                SvToolBase nearest = list[0].Tool;
                foreach (Candidate c in list)
                    if (object.ReferenceEquals(c.Tool, nearest) && c.Name == "OutputImage") return c;
                return list[0];
            }
            return null;
        }

        /// <summary>Links every free picture input (and every input whose name an earlier output shares) to the obvious source.</summary>
        bool AutoLink(SvToolBase tool)
        {
            bool any = false;
            foreach (string input in tool.GetInputParamNames())
            {
                InputParams cur;
                if (tool.inParams.TryGetValue(input, out cur) && cur != null) continue;
                int hidden;
                Candidate best = Suggest(tool, input, Candidates(tool, input, out hidden));
                if (best == null) continue;
                tool.inParams[input] = new InputParams(best.Tool, best.Name);
                any = true;
            }
            if (any) tool.GetInParams();
            return any;
        }

        void Unlink(SvToolBase tool, string input)
        {
            tool.inParams[input] = null;
            Commit(tool);
        }

        /// <summary>The "linked to" label of an input: click jumps to the source tool, the cross cancels the link.
        /// Null when the input is free (a free picture input gets an amber hint instead).</summary>
        UIElement BuildLinkChip(SvToolBase tool, string input)
        {
            InputParams ip;
            tool.inParams.TryGetValue(input, out ip);
            if (ip == null)
            {
                if (TypeOfInput(tool, input) != typeof(SvImage)) return null;
                TextBlock free = Tb("\u26A0 no picture linked", 11, WarnText, FontWeights.Normal);
                free.Margin = new Thickness(8, 0, 0, 0);
                return free;
            }

            List<SvToolBase> order = Order();
            SvToolBase src = null;
            foreach (SvToolBase t in order)
                if (t != null && t.HashCode == ip.InstanceHashcode) { src = t; break; }
            bool broken = src == null;
            bool later = src != null && order.IndexOf(src) >= order.IndexOf(tool);
            string text = broken ? "\u26A0 source was deleted" : (later ? "\u26A0 " + NameOf(src) + "." + ip.FieldName + " runs later" : "\u2190 " + NameOf(src) + "." + ip.FieldName);

            StackPanel chip = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(8, 0, 0, 0) };
            TextBlock label = Tb(text, 11, (broken || later) ? WarnText : mMuted, FontWeights.Normal);
            label.MaxWidth = 150;
            label.ToolTip = broken ? "The tool this input was linked to does not exist any more. Click the cross to cancel the link."
                : (later ? "The source runs after this tool, so it has no value yet. Move one of them." : "Click to show the source tool");
            if (src != null)
            {
                label.Cursor = Cursors.Hand;
                SvToolBase target = src;
                label.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e) { e.Handled = true; Select(target); };
            }
            chip.Children.Add(label);
            TextBlock x = Tb("\u2715", 10, mMuted, FontWeights.Normal);
            x.Margin = new Thickness(6, 0, 0, 0);
            x.Cursor = Cursors.Hand;
            x.ToolTip = "Cancel the link";
            x.MouseEnter += delegate { x.Foreground = mText; };
            x.MouseLeave += delegate { x.Foreground = mMuted; };
            x.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e) { e.Handled = true; Unlink(tool, input); };
            chip.Children.Add(x);
            return chip;
        }

        /// <summary>While an output is dragged, the inputs that accept it light up and the others fade.</summary>
        void HighlightTargets(bool on)
        {
            foreach (Target t in mTargets)
            {
                if (!on)
                {
                    t.Box.Opacity = 1;
                    t.Box.BorderBrush = Transparent;
                    t.Box.Background = Transparent;
                    continue;
                }
                bool fits = mDragSource != null && CanLink(mDragSource.Tool, mDragSource.Name, t.Ref.Tool, t.Ref.Name);
                t.Box.Opacity = fits ? 1 : 0.3;
                t.Box.BorderBrush = fits ? mAccent : Transparent;
                t.Box.Background = fits ? LinkBack : Transparent;
            }
        }

        /// <summary>Click on an input: a list of the outputs that fit, with what they hold now. One click links.</summary>
        void ShowLinkPicker(FrameworkElement anchor, SvToolBase tool, string input)
        {
            int hidden;
            List<Candidate> list = Candidates(tool, input, out hidden);
            Candidate best = Suggest(tool, input, list);
            InputParams current;
            tool.inParams.TryGetValue(input, out current);
            Type want = TypeOfInput(tool, input);

            Popup pop = new Popup();
            pop.PlacementTarget = anchor;
            pop.Placement = PlacementMode.Right;
            pop.StaysOpen = false;
            pop.AllowsTransparency = true;
            pop.PopupAnimation = PopupAnimation.Fade;

            Border box = new Border();
            box.Width = 340;
            box.Margin = new Thickness(10);
            box.Background = mCard;
            box.BorderBrush = mLine;
            box.BorderThickness = new Thickness(1);
            box.CornerRadius = new CornerRadius(8);
            box.Effect = new DropShadowEffect { BlurRadius = 18, ShadowDepth = 3, Opacity = 0.5 };

            StackPanel root = new StackPanel { Margin = new Thickness(12) };
            box.Child = root;
            pop.Child = box;

            // title: "Link InputImage" + the type that it takes
            DockPanel head = new DockPanel();
            Border pill = new Border { CornerRadius = new CornerRadius(9), BorderThickness = new Thickness(1), BorderBrush = mLine, Padding = new Thickness(8, 1, 8, 1), VerticalAlignment = VerticalAlignment.Center };
            pill.Child = Tb(TypeLabel(want), 11, mMuted, FontWeights.Normal);
            DockPanel.SetDock(pill, Dock.Right);
            head.Children.Add(pill);
            head.Children.Add(Tb("Link  " + input, 14, mText, FontWeights.SemiBold));
            root.Children.Add(head);
            TextBlock sub = Tb("takes its value from an output of an earlier tool", 11.5, mMuted, FontWeights.Normal);
            sub.Margin = new Thickness(0, 2, 0, 8);
            root.Children.Add(sub);

            if (current != null)
            {
                Border unlink = new Border { CornerRadius = new CornerRadius(6), BorderThickness = new Thickness(1), BorderBrush = mLine, Padding = new Thickness(10, 5, 10, 5), Margin = new Thickness(0, 0, 0, 8), Cursor = Cursors.Hand, Background = Transparent };
                unlink.Child = Tb("\u2715  Cancel the link  (" + LinkTextPlain(tool, input) + ")", 12, mText, FontWeights.Normal);
                unlink.MouseEnter += delegate { unlink.Background = HoverBack; };
                unlink.MouseLeave += delegate { unlink.Background = Transparent; };
                unlink.MouseLeftButtonUp += delegate { pop.IsOpen = false; Unlink(tool, input); };
                root.Children.Add(unlink);
            }

            StackPanel items = new StackPanel();
            ScrollViewer sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MaxHeight = 280, Content = items };
            root.Children.Add(sv);

            if (list.Count == 0)
            {
                TextBlock none = Tb("No earlier tool gives a " + TypeLabel(want).ToLower() + ". Add a tool that makes one before this tool.", 12, mMuted, FontWeights.Normal);
                none.TextWrapping = TextWrapping.Wrap;
                none.Margin = new Thickness(0, 4, 0, 4);
                items.Children.Add(none);
            }

            SvToolBase lastTool = null;
            foreach (Candidate c in list)
            {
                if (!object.ReferenceEquals(c.Tool, lastTool))
                {
                    lastTool = c.Tool;
                    TextBlock h = Tb(NameOf(c.Tool), 11.5, mMuted, FontWeights.SemiBold);
                    h.Margin = new Thickness(2, 6, 0, 3);
                    items.Children.Add(h);
                }
                bool now = current != null && current.InstanceHashcode == c.Tool.HashCode && current.FieldName == c.Name;
                Candidate cand = c;
                Border row = new Border { CornerRadius = new CornerRadius(5), Padding = new Thickness(8, 5, 8, 5), Cursor = Cursors.Hand, Background = now ? LinkBack : Transparent };
                DockPanel dp = new DockPanel();
                TextBlock tick = Tb(now ? "\u2713" : "\u25CF", now ? 12 : 8, now ? mAccent : OutputBrush, FontWeights.Normal);
                tick.Width = 18;
                DockPanel.SetDock(tick, Dock.Left);
                dp.Children.Add(tick);
                TextBlock val = Tb(Preview(c.Tool, c.Name), 11.5, mMuted, FontWeights.Normal);
                val.Margin = new Thickness(10, 0, 0, 0);
                DockPanel.SetDock(val, Dock.Right);
                dp.Children.Add(val);
                if (best != null && object.ReferenceEquals(best, c))
                {
                    Border tag = new Border { CornerRadius = new CornerRadius(8), Background = mAccent, Padding = new Thickness(7, 0, 7, 1), Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
                    tag.Child = Tb("Suggested", 10, Brushes.White, FontWeights.SemiBold);
                    DockPanel.SetDock(tag, Dock.Right);
                    dp.Children.Add(tag);
                }
                dp.Children.Add(Tb(c.Name, 12.5, mText, FontWeights.Normal));
                row.Child = dp;
                row.MouseEnter += delegate { if (!now) row.Background = HoverBack; };
                row.MouseLeave += delegate { if (!now) row.Background = Transparent; };
                row.MouseLeftButtonUp += delegate
                {
                    pop.IsOpen = false;
                    LinkParams(new ParamRef { Tool = cand.Tool, Name = cand.Name, IsInput = false }, new ParamRef { Tool = tool, Name = input, IsInput = true });
                };
                items.Children.Add(row);
            }

            string foot = "You can also drag an output onto this input.";
            if (hidden > 0) foot = hidden + (hidden == 1 ? " output of another type is hidden. " : " outputs of other types are hidden. ") + foot;
            TextBlock note = Tb(foot, 11, mMuted, FontWeights.Normal);
            note.TextWrapping = TextWrapping.Wrap;
            note.Margin = new Thickness(0, 10, 0, 0);
            root.Children.Add(note);

            pop.IsOpen = true;
        }

        string LinkTextPlain(SvToolBase tool, string input)
        {
            InputParams ip;
            if (!tool.inParams.TryGetValue(input, out ip) || ip == null) return "";
            foreach (SvToolBase t in Order())
                if (t != null && t.HashCode == ip.InstanceHashcode) return NameOf(t) + "." + ip.FieldName;
            return "";
        }

        UIElement BuildParam(SvToolBase tool, string name, bool isInput)
        {
            Border b = new Border();
            b.Padding = new Thickness(5, 2, 5, 2);
            b.CornerRadius = new CornerRadius(4);
            b.BorderThickness = new Thickness(1);
            b.BorderBrush = Transparent;
            b.Background = Transparent;
            b.AllowDrop = isInput;
            b.Tag = new ParamRef { Tool = tool, Name = name, IsInput = isInput };

            DockPanel dp = new DockPanel();
            Brush tone = isInput ? InputBrush : OutputBrush;
            TextBlock dot = Tb("●", 8, tone, FontWeights.Normal);
            dot.Margin = new Thickness(0, 0, 6, 0);
            DockPanel.SetDock(dot, Dock.Left);
            dp.Children.Add(dot);
            if (isInput)
            {
                UIElement chip = BuildLinkChip(tool, name);
                if (chip != null)
                {
                    DockPanel.SetDock(chip, Dock.Right);
                    dp.Children.Add(chip);
                }
            }
            dp.Children.Add(Tb(name, 12, tone, FontWeights.Normal));
            b.Child = dp;

            b.MouseEnter += delegate { b.Background = HoverBack; };
            b.MouseLeave += delegate { b.Background = Transparent; };

            if (!isInput)
            {
                b.Cursor = Cursors.Hand;
                b.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e) { mDragStart = e.GetPosition(this); e.Handled = true; Select(tool); };
                b.MouseMove += delegate(object s, MouseEventArgs e)
                {
                    if (e.LeftButton != MouseButtonState.Pressed) return;
                    e.Handled = true; // the tool row must not start its own drag
                    if (Moved(e))
                    {
                        mDragSource = (ParamRef)b.Tag;
                        HighlightTargets(true);
                        try { DragDrop.DoDragDrop(b, new DataObject("SvOut", b.Tag), DragDropEffects.Link); }
                        finally { mDragSource = null; HighlightTargets(false); }
                    }
                };
            }
            else
            {
                mTargets.Add(new Target { Box = b, Ref = (ParamRef)b.Tag });
                b.Cursor = Cursors.Hand;
                b.ToolTip = "Click to choose what this input takes, or drag an output here";
                b.DragOver += delegate(object s, DragEventArgs e)
                {
                    ParamRef dragged = e.Data.GetData("SvOut") as ParamRef;
                    bool fits = dragged != null && CanLink(dragged.Tool, dragged.Name, tool, name);
                    e.Effects = fits ? DragDropEffects.Link : DragDropEffects.None;
                    e.Handled = true;
                };
                b.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
                {
                    if (e.Handled) return;
                    e.Handled = true;
                    // after the selection has settled (selecting may redraw the list)
                    Dispatcher.BeginInvoke(new Action(delegate { ShowLinkPicker(b, tool, name); }), System.Windows.Threading.DispatcherPriority.Input);
                };
                b.Drop += delegate(object s, DragEventArgs e)
                {
                    e.Handled = true;
                    ParamRef src = e.Data.GetData("SvOut") as ParamRef;
                    if (src != null) LinkParams(src, (ParamRef)b.Tag);
                };
                ContextMenu menu = new ContextMenu();
                menu.Opened += delegate { BuildLinkMenu(menu, tool, name); };
                b.ContextMenu = menu;
                b.PreviewMouseLeftButtonDown += delegate { Select(tool); };
            }
            return b;
        }

        bool Moved(MouseEventArgs e)
        {
            Point p = e.GetPosition(this);
            return Math.Abs(p.X - mDragStart.X) > SystemParameters.MinimumHorizontalDragDistance
                || Math.Abs(p.Y - mDragStart.Y) > SystemParameters.MinimumVerticalDragDistance;
        }

        void WireCard(Row row)
        {
            Border card = row.Card;
            SvToolBase tool = row.Tool;

            card.MouseEnter += delegate { if (!object.ReferenceEquals(tool, mSelected) && !HasMatch(tool)) card.Background = HoverBack; };
            card.MouseLeave += delegate { if (!object.ReferenceEquals(tool, mSelected)) card.Background = HasMatch(tool) ? MatchBack : Transparent; };

            if (row.IsNode)
            {
                card.MouseLeftButtonDown += delegate { Focus(); Select(tool); };
                return;
            }
            card.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
            {
                mDragStart = e.GetPosition(this);
                Focus();
                Select(tool);
                if (e.ClickCount == 2) mEdit.EditTool(tool);
            };
            card.MouseMove += delegate(object s, MouseEventArgs e)
            {
                if (e.LeftButton == MouseButtonState.Pressed && Moved(e))
                    DragDrop.DoDragDrop(card, new DataObject("SvTool", tool), DragDropEffects.Move | DragDropEffects.Copy);
            };
            card.DragOver += delegate(object s, DragEventArgs e)
            {
                if (e.Data.GetDataPresent("SvTool")) SetToolEffect(e);
                e.Handled = true;
            };
            card.Drop += delegate(object s, DragEventArgs e)
            {
                e.Handled = true;
                if (e.Data.GetDataPresent("SvTool")) DropTool(e, Job.ToolList.IndexOf(tool));
            };

            ContextMenu menu = new ContextMenu();
            AddItem(menu, "Rename...", delegate { RenameTool(tool); });
            AddItem(menu, "Modify params...", delegate { ModifyParams(tool); });
            AddItem(menu, "Auto-link inputs", delegate { if (AutoLink(tool)) Commit(tool); });
            menu.Items.Add(new Separator());
            AddItem(menu, "Move up", delegate { MoveBy(tool, -1); });
            AddItem(menu, "Move down", delegate { MoveBy(tool, 1); });
            AddItem(menu, "Duplicate", delegate { CopyTool(tool, Job.ToolList.IndexOf(tool) + 1); });
            menu.Items.Add(new Separator());
            AddItem(menu, "Delete", delegate { DeleteTool(tool); });
            card.ContextMenu = menu;
            menu.Opened += delegate { Select(tool); };
        }

        static void AddItem(ContextMenu menu, string text, Action action)
        {
            MenuItem item = new MenuItem();
            item.Header = text;
            item.Click += delegate { action(); };
            menu.Items.Add(item);
        }

        void BuildLinkMenu(ContextMenu menu, SvToolBase tool, string input)
        {
            menu.Items.Clear();
            List<SvToolBase> order = Order();
            int at = order.IndexOf(tool);
            InputParams current;
            if (tool.inParams.TryGetValue(input, out current) && current != null)
            {
                AddItem(menu, "Cancel link", delegate
                {
                    tool.inParams[input] = null;
                    Commit(tool);
                });
            }
            MenuItem link = new MenuItem();
            link.Header = "Link to output of...";
            for (int i = 0; i < at; i++)
            {
                SvToolBase src = order[i];
                if (src == null) continue;
                string[] outs = src.GetOutputParamNames();
                if (outs.Length == 0) continue;
                MenuItem group = new MenuItem();
                group.Header = NameOf(src);
                foreach (string o in outs)
                {
                    if (!TypesMatch(src, o, tool, input)) continue;
                    SvToolBase s2 = src;
                    string name = o;
                    MenuItem item = new MenuItem();
                    item.Header = name;
                    item.Click += delegate { LinkParams(new ParamRef { Tool = s2, Name = name, IsInput = false }, new ParamRef { Tool = tool, Name = input, IsInput = true }); };
                    group.Items.Add(item);
                }
                if (group.Items.Count > 0) link.Items.Add(group);
            }
            if (link.Items.Count == 0) link.IsEnabled = false;
            menu.Items.Add(link);
        }

        // ---------------------------------------------------------------- selection, run times, search
        void Select(SvToolBase tool)
        {
            if (object.ReferenceEquals(tool, mSelected)) return;
            mSelected = tool;
            UpdateSelection();
            mBusy = true;
            try { mEdit.SelectTool(tool); } finally { mBusy = false; }
        }

        bool HasMatch(SvToolBase tool)
        {
            string text = Search.Text.Trim();
            return text.Length > 0 && tool.ToString().IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        void UpdateSelection()
        {
            foreach (Row r in mRows)
            {
                bool sel = object.ReferenceEquals(r.Tool, mSelected);
                r.Card.Background = sel ? SelectedBack : (HasMatch(r.Tool) ? MatchBack : Transparent);
                r.Card.BorderBrush = sel ? mAccent : Transparent;
                r.Params.Visibility = (sel || mShowAllParams || r.IsNode) && r.Params.Children.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            }
            UpdateAddText();
        }

        void UpdateAddText()
        {
            AddText.Text = mSelected == null ? "+ Add tool" : "+ Add tool after " + NameOf(mSelected);
        }

        void UpdateTimes()
        {
            double max = 0;
            int timed = 0;
            Row slowest = null;
            foreach (Row r in mRows)
            {
                if (r.Tool.lastProcessTime > 0) timed++;
                if (r.Tool.lastProcessTime > max) { max = r.Tool.lastProcessTime; slowest = r; }
            }
            foreach (Row r in mRows)
            {
                double t = r.Tool.lastProcessTime;
                r.Name.Text = r.IsNode ? r.Label : r.Tool.ToString();
                r.Time.Text = t > 0 ? string.Format("{0:0.0} ms", t) : "";
                double ratio = (t > 0 && max > 0) ? t / max : 0;
                r.BarFill.Width = new GridLength(ratio, GridUnitType.Star);
                r.BarRest.Width = new GridLength(1 - ratio, GridUnitType.Star);
                r.Bar.Background = (timed > 1 && object.ReferenceEquals(r, slowest)) ? mWarn : mAccent;
                r.Time.Foreground = (timed > 1 && object.ReferenceEquals(r, slowest)) ? mWarn : mMuted;
            }
        }

        void MarkMatches()
        {
            UpdateSelection();
        }

        void SelectNextMatch()
        {
            List<Row> hits = mRows.FindAll(delegate(Row r) { return HasMatch(r.Tool); });
            if (hits.Count == 0) return;
            int at = hits.FindIndex(delegate(Row r) { return object.ReferenceEquals(r.Tool, mSelected); });
            Row next = hits[(at + 1) % hits.Count];
            Select(next.Tool);
            next.Card.BringIntoView();
        }

        // ---------------------------------------------------------------- changing the job
        /// <summary>The job changed: tell the editor, redraw, and select the tool.</summary>
        void Commit(SvToolBase select)
        {
            Dispatcher.BeginInvoke(new Action(delegate
            {
                mBusy = true;
                try
                {
                    mEdit.JobStructureChanged();
                    mSelected = select;
                    Rebuild();
                    if (select != null) mEdit.SelectTool(select);
                }
                finally { mBusy = false; }
            }));
        }

        void SetToolEffect(DragEventArgs e)
        {
            bool ctrl = (e.KeyStates & DragDropKeyStates.ControlKey) != 0;
            e.Effects = ctrl ? DragDropEffects.Copy : DragDropEffects.Move;
            e.Handled = true;
        }

        void DropTool(DragEventArgs e, int targetIndex)
        {
            SvToolBase tool = e.Data.GetData("SvTool") as SvToolBase;
            if (tool == null || Job == null) return;
            bool ctrl = (e.KeyStates & DragDropKeyStates.ControlKey) != 0;
            if (ctrl) CopyTool(tool, targetIndex);
            else MoveTo(tool, targetIndex);
        }

        void MoveTo(SvToolBase tool, int targetIndex)
        {
            List<SvToolBase> list = Job.ToolList;
            int from = list.IndexOf(tool);
            if (from < 0 || targetIndex < 0) return;
            if (targetIndex >= list.Count) targetIndex = list.Count - 1;
            if (from == targetIndex) return;
            list.RemoveAt(from);
            list.Insert(targetIndex, tool);
            Commit(tool);
        }

        void MoveBy(SvToolBase tool, int delta)
        {
            int at = Job.ToolList.IndexOf(tool);
            if (at < 0) return;
            int to = at + delta;
            if (to < 0 || to >= Job.ToolList.Count) return;
            MoveTo(tool, to);
        }

        void CopyTool(SvToolBase source, int index)
        {
            try
            {
                SvToolBase copy = SvFunc.CopyTool(source, source.GetType()) as SvToolBase;
                if (copy == null) return;
                if (index < 0 || index > Job.ToolList.Count) index = Job.ToolList.Count;
                Job.ToolList.Insert(index, copy);
                foreach (KeyValuePair<string, InputParams> kv in source.inParams)
                {
                    if (kv.Value == null) continue;
                    copy.inParams[kv.Key] = new InputParams(kv.Value.Instance, kv.Value.FieldName);
                    copy.GetInParams();
                    copy.Run();
                }
                Commit(copy);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Copy tool", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        void DeleteTool(SvToolBase tool)
        {
            if (MessageBox.Show("Do you want to delete \"" + tool.ToString() + "\"?", "Delete tool", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;
            int at = Job.ToolList.IndexOf(tool);
            Job.ToolList.Remove(tool);
            SvToolBase next = null;
            if (Job.ToolList.Count > 0) next = Job.ToolList[Math.Min(Math.Max(at, 0), Job.ToolList.Count - 1)];
            Commit(next);
        }

        void RenameTool(SvToolBase tool)
        {
            string name = Prompt("Rename tool", tool.ToString());
            if (string.IsNullOrWhiteSpace(name)) return;
            tool.toolName = name.Trim();
            Commit(tool);
        }

        void ModifyParams(SvToolBase tool)
        {
            if (tool is SvToolBlock)
            {
                MessageBox.Show("[ToolBlock] tool can be modified in tool editor, not this menu.");
                return;
            }
            using (SvMip.Core.SvToolParamsEditForm form = new SvMip.Core.SvToolParamsEditForm())
            {
                form.Subject = tool;
                form.ShowDialog();
            }
            Commit(tool);
        }

        void LinkParams(ParamRef src, ParamRef dst)
        {
            if (!dst.IsInput || !CanLink(src.Tool, src.Name, dst.Tool, dst.Name)) return; // an earlier tool, and the same type
            InputParams now;
            if (dst.Tool.inParams.TryGetValue(dst.Name, out now) && now != null
                && now.InstanceHashcode == src.Tool.HashCode && now.FieldName == src.Name) return;
            dst.Tool.inParams[dst.Name] = new InputParams(src.Tool, src.Name);
            dst.Tool.GetInParams();
            Commit(dst.Tool);
        }

        /// <summary>A small dark dialog that asks for one line of text.</summary>
        string Prompt(string title, string initial)
        {
            Window w = new Window();
            w.Title = title;
            w.Width = 340;
            w.SizeToContent = SizeToContent.Height;
            w.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            w.Owner = Window.GetWindow(this);
            w.ResizeMode = ResizeMode.NoResize;
            w.ShowInTaskbar = false;
            w.Background = mCard;
            StackPanel sp = new StackPanel { Margin = new Thickness(16) };
            TextBox tb = new TextBox { Text = initial, Style = (Style)FindResource("VtSearch") };
            sp.Children.Add(tb);
            StackPanel buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
            Button ok = new Button { Content = "OK", Width = 74, Height = 28, IsDefault = true, Margin = new Thickness(0, 0, 8, 0) };
            Button cancel = new Button { Content = "Cancel", Width = 74, Height = 28, IsCancel = true };
            ok.Click += delegate { w.DialogResult = true; };
            buttons.Children.Add(ok);
            buttons.Children.Add(cancel);
            sp.Children.Add(buttons);
            w.Content = sp;
            w.Loaded += delegate { tb.Focus(); tb.SelectAll(); };
            return w.ShowDialog() == true ? tb.Text : null;
        }

        // ---------------------------------------------------------------- "+ Add tool after ..." pop-over
        void ShowAddPopup()
        {
            List<Type> types;
            try { types = mEdit.GetToolTypes(); }
            catch (Exception ex) { MessageBox.Show(ex.ToString(), "Tools", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            types.Sort(delegate(Type a, Type b) { return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase); });

            Popup pop = new Popup();
            pop.PlacementTarget = AddBtn;
            pop.Placement = PlacementMode.Top;
            pop.StaysOpen = false;
            pop.AllowsTransparency = true;
            pop.PopupAnimation = PopupAnimation.Fade;

            Border box = new Border();
            box.Width = 560;
            box.Height = 380;
            box.Margin = new Thickness(10);
            box.Background = mCard;
            box.BorderBrush = mLine;
            box.BorderThickness = new Thickness(1);
            box.CornerRadius = new CornerRadius(8);
            box.Effect = new DropShadowEffect { BlurRadius = 18, ShadowDepth = 3, Opacity = 0.5 };

            Grid g = new Grid { Margin = new Thickness(10) };
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(130) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            TextBox find = new TextBox { Style = (Style)FindResource("VtSearch"), Margin = new Thickness(0, 0, 0, 8) };
            Grid.SetColumnSpan(find, 2);
            g.Children.Add(find);

            StackPanel cats = new StackPanel { Margin = new Thickness(0, 0, 8, 0) };
            Grid.SetRow(cats, 1);
            g.Children.Add(cats);
            StackPanel list = new StackPanel();
            ScrollViewer sv = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = list };
            Grid.SetRow(sv, 1);
            Grid.SetColumn(sv, 1);
            g.Children.Add(sv);
            box.Child = g;
            pop.Child = box;

            string category = "All tools";
            Action fill = null;
            Action fillCats = null;

            fillCats = delegate
            {
                cats.Children.Clear();
                List<string> names = new List<string>();
                names.Add("All tools");
                names.AddRange(SvMip.Core.SvAddToolPopup.CategoryOrder);
                foreach (string c in names)
                {
                    string name = c;
                    bool on = name == category;
                    Border b = new Border { Padding = new Thickness(10, 6, 10, 6), CornerRadius = new CornerRadius(5), Cursor = Cursors.Hand, Background = on ? SelectedBack : Transparent };
                    b.Child = Tb(name, 12.5, on ? mText : mMuted, on ? FontWeights.SemiBold : FontWeights.Normal);
                    b.MouseLeftButtonUp += delegate { category = name; fillCats(); fill(); };
                    cats.Children.Add(b);
                }
            };

            fill = delegate
            {
                list.Children.Clear();
                string q = find.Text.Trim();
                foreach (Type t in types)
                {
                    string cat;
                    if (!SvMip.Core.SvAddToolPopup.CategoryOf.TryGetValue(t.Name, out cat)) cat = "Other";
                    string desc;
                    if (!SvMip.Core.SvAddToolPopup.DescriptionOf.TryGetValue(t.Name, out desc)) desc = "";
                    if (category != "All tools" && cat != category) continue;
                    if (q.Length > 0 && t.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) < 0 && desc.IndexOf(q, StringComparison.OrdinalIgnoreCase) < 0) continue;

                    Type type = t;
                    Border b = new Border { Padding = new Thickness(10, 6, 10, 6), CornerRadius = new CornerRadius(5), Cursor = Cursors.Hand, Background = Transparent };
                    StackPanel sp = new StackPanel();
                    sp.Children.Add(Tb(t.Name, 13, mText, FontWeights.SemiBold));
                    if (desc.Length > 0) sp.Children.Add(Tb(desc, 11, mMuted, FontWeights.Normal));
                    b.Child = sp;
                    b.MouseEnter += delegate { b.Background = HoverBack; };
                    b.MouseLeave += delegate { b.Background = Transparent; };
                    b.MouseLeftButtonUp += delegate { pop.IsOpen = false; AddTool(type); };
                    list.Children.Add(b);
                }
                if (list.Children.Count == 0) list.Children.Add(Tb("No tool found", 12, mMuted, FontWeights.Normal));
            };

            find.TextChanged += delegate { fill(); };
            find.KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Key == Key.Escape) pop.IsOpen = false;
                else if (e.Key == Key.Enter && list.Children.Count > 0)
                {
                    Border first = list.Children[0] as Border;
                    if (first != null) { pop.IsOpen = false; string n = ((TextBlock)((StackPanel)first.Child).Children[0]).Text; foreach (Type t in types) if (t.Name == n) { AddTool(t); break; } }
                }
            };
            fillCats();
            fill();
            pop.IsOpen = true;
            Dispatcher.BeginInvoke(new Action(delegate { find.Focus(); }), System.Windows.Threading.DispatcherPriority.Input);
        }

        void AddTool(Type type)
        {
            try
            {
                SvToolBase tool = Activator.CreateInstance(type) as SvToolBase;
                if (tool == null) return;
                SvJob job = Job;
                int index = job.ToolList.Count;
                if (object.ReferenceEquals(mSelected, mEdit.InputNode) && mEdit.InputNode != null) index = 0;
                else if (mSelected != null)
                {
                    int at = job.ToolList.IndexOf(mSelected);
                    if (at >= 0) index = at + 1;
                }
                job.ToolList.Insert(index, tool);
                AutoLink(tool);
                Commit(tool);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Add tool", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
