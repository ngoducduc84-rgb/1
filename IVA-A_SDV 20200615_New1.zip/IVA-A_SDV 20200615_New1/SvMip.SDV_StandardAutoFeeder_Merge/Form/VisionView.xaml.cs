﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SvMip.Edit;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// The VISION screen: a WPF header (process pills, job name, actions) above the WinForms job editor.
    /// </summary>
    public partial class VisionView : UserControl
    {
        readonly Vision mVision;

        public VisionView()
        {
            InitializeComponent();

            mVision = new Vision();
            Host.Child = mVision;
            PanelHost.Child = new VisionNodeGraphPanel(mVision.JobEdit);
            mVision.ProcessChanged += delegate { RefreshHeader(); };

            foreach (string name in mVision.ProcessNames)
            {
                Button pill = new Button();
                pill.Content = name;
                pill.Style = (Style)FindResource("VvPill");
                string captured = name;
                pill.Click += delegate { Select(captured); };
                Pills.Children.Add(pill);
            }

            // the tool editor column
            SvJobEdit je = mVision.JobEdit;
            EditorHost.Child = mVision.CreateDockPanel();
            je.DockOpened += delegate(object s, SvToolEventArgs e) { ShowEditor(e.Tool); };
            je.DockClosed += delegate { EditorCol.Visibility = Visibility.Collapsed; };
            je.DockedTabChanged += delegate { RefreshTabs(); };
            EditorClose.MouseLeftButtonUp += delegate { je.CloseDock(); };
            BtnRunTool.Click += delegate
            {
                // the inputs of this tool come from tools that were not run yet: run the whole job once so that they have a value
                if (mTool != null && je.NeedsUpstream(mTool)) { je.Run(); return; }
                SvMip.Edit.Base.SvToolEditBase ed = je.DockedEditorNow;
                if (ed != null) ed.RunTool();
                if (TmPanel.Visibility == Visibility.Visible) TmPanel.Reload();
                if (FormPanel.Visibility == Visibility.Visible) FormPanel.Reload();
                if (TbPanel.Visibility == Visibility.Visible) TbPanel.Reload();
            };
            je.JobRan += delegate
            {
                if (TbPanel.Visibility == Visibility.Visible) TbPanel.Reload();
                if (TmPanel.Visibility == Visibility.Visible) TmPanel.RefreshOutputs();
                if (FormPanel.Visibility == Visibility.Visible) FormPanel.Reload();
            };
            TbPanel.EditInnerRequested += delegate(SvToolBase inner)
            {
                SvToolBlockEdit be = je.DockedEditorNow as SvToolBlockEdit;
                if (be == null || be.Subject == null) return false;
                mOpeningFrom = be.Subject;
                try { return je.EditInnerTool(inner); }
                finally { mOpeningFrom = null; }
            };
            BtnBack.MouseLeftButtonUp += delegate
            {
                if (mBackBlock != null) je.EditTool(mBackBlock);
            };
            BtnClassic.MouseLeftButtonUp += delegate
            {
                mClassic = !mClassic;
                if (mClassic) je.RefreshDockedEditor();
                ShowEditor(mTool);
            };
            je.ImagesChanged += delegate { RefreshImageChips(); };
            TmPanel.TrainRequested += delegate { SelectImageByName("Train"); };
            InitDisplayChrome();
            BtnOpen.Click += delegate { je.OpenJobFile(); mVision.BindJobToProcess(); RefreshHeader(); };
            BtnRun.Click += delegate { je.Run(); };
            BtnAuto.Click += delegate
            {
                je.ToggleAutoRun();
                BtnAuto.Tag = object.Equals(BtnAuto.Tag, "on") ? null : "on";
            };

            BtnQuick.Click += delegate { mVision.DoQuickSetup(); };
            BtnDry.Click += delegate { mVision.DoDryRun(); };
            BtnHistory.Click += delegate { mVision.DoHistory(); RefreshHeader(); };
            BtnSaveAs.Click += delegate { if (mVision.SaveJob(true)) mVision.BindJobToProcess(); RefreshHeader(); };
            BtnSave.Click += delegate { if (mVision.SaveJob(false)) mVision.BindJobToProcess(); RefreshHeader(); };
            BtnSaveRun.Click += delegate { mVision.DoSaveAndRun(); };

            RefreshHeader();
        }

        SvToolBase mTool;
        SvToolBase mOpeningFrom;   // the tool block that is opening the editor of one of its tools
        SvToolBase mBackBlock;     // the block to go back to from the editor of an inner tool
        bool mClassic;       // the old editor is shown for a tool that has a form
        SvToolBase mClassicFor;

        void ShowEditor(SvToolBase tool)
        {
            if (!object.ReferenceEquals(tool, mClassicFor)) { mClassic = false; mClassicFor = tool; }
            mTool = tool;
            mBackBlock = mOpeningFrom;
            BtnBack.Visibility = mBackBlock == null ? Visibility.Collapsed : Visibility.Visible;
            if (mBackBlock != null) BtnBackText.Text = "\u25C0 " + mBackBlock.ToString();
            EditorTitle.Text = tool.ToString();
            string cat;
            if (!SvMip.Core.SvAddToolPopup.CategoryOf.TryGetValue(tool.GetType().Name, out cat)) cat = "Other";
            EditorCategory.Text = cat;
            EditorCol.Visibility = Visibility.Visible;

            // SvTemplateMatch has the new WPF editor; the other tools still use their own editor, with the tab strip drawn here
            SvTemplateMatchEdit tm = mVision.JobEdit.DockedEditorNow as SvTemplateMatchEdit;
            ToolFormSpec spec = ToolFormSpecs.For(tool.GetType().Name);
            bool form = false;
            FormPanel.Visibility = Visibility.Collapsed;
            TbPanel.Visibility = Visibility.Collapsed;
            SvToolBlockEdit tbe = mVision.JobEdit.DockedEditorNow as SvToolBlockEdit;
            if (tbe != null)
            {
                BtnClassic.Visibility = Visibility.Collapsed;
                TmPanel.Visibility = Visibility.Collapsed;
                EditorHost.Visibility = Visibility.Collapsed;
                ((Border)EditorTabs.Parent).Visibility = Visibility.Collapsed;
                TbPanel.Attach(tbe);
                TbPanel.Visibility = Visibility.Visible;
                RefreshImageChips();
                return;
            }
            BtnClassic.Visibility = (spec != null && spec.Classic) ? Visibility.Visible : Visibility.Collapsed;
            BtnClassicText.Text = mClassic ? "New view" : "Classic view";
            if (tm != null)
            {
                BtnClassic.Visibility = Visibility.Collapsed;
                TmPanel.Attach(tm);
                TmPanel.Visibility = Visibility.Visible;
                EditorHost.Visibility = Visibility.Collapsed;
                ((Border)EditorTabs.Parent).Visibility = Visibility.Collapsed;
                RefreshImageChips();
                return;
            }
            TmPanel.Visibility = Visibility.Collapsed;
            if (spec != null && !mClassic)
            {
                try
                {
                    FormPanel.Attach(tool, spec, mVision.JobEdit);
                    FormPanel.Visibility = Visibility.Visible;
                    form = true;
                }
                catch (Exception) { form = false; }
            }
            if (form)
            {
                EditorHost.Visibility = Visibility.Collapsed;
                ((Border)EditorTabs.Parent).Visibility = Visibility.Collapsed;
            }
            else
            {
                EditorHost.Visibility = Visibility.Visible;
                RefreshTabs();
            }
            RefreshImageChips();
        }

        // ---------------------------------------------------------------- the picture: view tools and status
        void InitDisplayChrome()
        {
            SvJobEdit je = mVision.JobEdit;
            je.HideImageSelector();
            je.UseHostChrome();
            SvMip.Display.SvDisplayViewStatusBar bar = je.DisplayBar;

            // the readout of the coordinates really follows the first entry of the list (Pixel)
            bar.CoordinateIndex = 1;
            bar.CoordinateIndex = 0;
            TgFit.IsChecked = bar.AutoFit;
            TgCenter.IsChecked = bar.CenterLine;
            TgAxis.IsChecked = bar.AxisVisible;
            TgFit.Click += delegate { bar.AutoFit = TgFit.IsChecked == true; };
            TgCenter.Click += delegate { bar.CenterLine = TgCenter.IsChecked == true; };
            TgAxis.Click += delegate { bar.AxisVisible = TgAxis.IsChecked == true; };
            BtnZoomIn.Click += delegate { bar.ZoomIn(); };
            BtnZoomOut.Click += delegate { bar.ZoomOut(); };
            BtnZoomText.Click += delegate
            {
                ContextMenu menu = new ContextMenu();
                foreach (int percent in new int[] { 10, 25, 50, 100, 200, 400, 800, 1600 })
                {
                    int p = percent;
                    MenuItem item = new MenuItem { Header = p + "%" };
                    item.Click += delegate { bar.ZoomTo(p / 100f); };
                    menu.Items.Add(item);
                }
                menu.Items.Add(new Separator());
                MenuItem fit = new MenuItem { Header = "Fit to window" };
                fit.Click += delegate { bar.FitView(); };
                menu.Items.Add(fit);
                ShowMenu(menu, BtnZoomText);
            };
            BtnCoord.Click += delegate
            {
                ContextMenu menu = new ContextMenu();
                string[] names = bar.CoordinateNames;
                for (int i = 0; i < names.Length; i++)
                {
                    int index = i;
                    MenuItem item = new MenuItem { Header = names[i], IsChecked = index == bar.CoordinateIndex };
                    item.Click += delegate { bar.CoordinateIndex = index; UpdateViewInfo(); };
                    menu.Items.Add(item);
                }
                ShowMenu(menu, BtnCoord);
            };
            bar.InfoChanged += delegate { UpdateViewInfo(); };
            je.StatusChanged += delegate { UpdateRunStatus(); };
            je.JobRan += delegate { UpdateRunStatus(); };
            UpdateViewInfo();
            UpdateRunStatus();
            RefreshImageChips();
        }

        static void ShowMenu(ContextMenu menu, FrameworkElement anchor)
        {
            menu.PlacementTarget = anchor;
            menu.Placement = System.Windows.Controls.Primitives.PlacementMode.Top;
            menu.IsOpen = true;
        }

        void UpdateViewInfo()
        {
            SvMip.Display.SvDisplayViewStatusBar bar = mVision.JobEdit.DisplayBar;
            string coord = bar.CoordinateText;
            CoordText.Text = string.IsNullOrEmpty(coord) ? "Move the mouse over the picture" : coord;
            BtnZoomText.Content = (bar.ZoomValue * 100f).ToString("F0") + "%";
            string[] names = bar.CoordinateNames;
            int index = bar.CoordinateIndex;
            BtnCoord.Content = (index >= 0 && index < names.Length ? names[index] : "Pixel") + " \u25BE";
        }

        void UpdateRunStatus()
        {
            SvJobEdit je = mVision.JobEdit;
            string time = je.StatusTimeText;
            RunTime.Text = string.IsNullOrEmpty(time) ? "0.00 ms" : time.Replace("ms", " ms");
            bool never = RunTime.Text.StartsWith("0.00");
            Color c = never ? Color.FromRgb(139, 148, 158) : (je.LastRunFailed ? Color.FromRgb(229, 72, 77) : Color.FromRgb(61, 190, 108));
            RunDot.Fill = new SolidColorBrush(c);
        }

        static readonly System.Text.RegularExpressions.Regex ToolPrefix = new System.Text.RegularExpressions.Regex(@"^\[[^\]]*\]\s*");

        /// <summary>One chip for every picture of the tool (InputImage, Train, OutputImage ...); the chosen one is shown on the image.</summary>
        void RefreshImageChips()
        {
            ImageChips.Children.Clear();
            string[] names = mVision.JobEdit.GetImageNames();
            int selected = mVision.JobEdit.SelectedImageIndex;
            ImageSize.Text = mVision.JobEdit.CurrentImageSize;
            if (names.Length == 0)
            {
                TextBlock none = new TextBlock();
                none.Text = "No picture yet \u2014 press Run job";
                none.FontSize = 12;
                none.Foreground = (Brush)FindResource("IvaMutedBrush");
                none.Margin = new Thickness(0, 0, 0, 4);
                ImageChips.Children.Add(none);
                return;
            }
            for (int i = 0; i < names.Length; i++)
            {
                int index = i;
                bool on = i == selected;
                Border chip = new Border();
                chip.Padding = new Thickness(11, 3, 11, 3);
                chip.Margin = new Thickness(0, 0, 6, 4);
                chip.CornerRadius = new CornerRadius(12);
                chip.BorderThickness = new Thickness(1);
                chip.Cursor = System.Windows.Input.Cursors.Hand;
                chip.BorderBrush = on ? (Brush)FindResource("IvaAccentBrush") : (Brush)FindResource("IvaLineBrush");
                chip.Background = on ? (Brush)FindResource("IvaAccentBrush") : Brushes.Transparent;
                TextBlock t = new TextBlock();
                t.Text = ToolPrefix.Replace(names[i], "");
                t.FontSize = 12;
                t.HorizontalAlignment = HorizontalAlignment.Left;
                t.Foreground = on ? Brushes.White : (Brush)FindResource("IvaMutedBrush");
                chip.Child = t;
                chip.MouseLeftButtonUp += delegate { mVision.JobEdit.SelectImage(index); RefreshImageChips(); };
                ImageChips.Children.Add(chip);
            }
        }

        void SelectImageByName(string part)
        {
            string[] names = mVision.JobEdit.GetImageNames();
            for (int i = 0; i < names.Length; i++)
                if (names[i].IndexOf(part, StringComparison.OrdinalIgnoreCase) >= 0) { mVision.JobEdit.SelectImage(i); break; }
            RefreshImageChips();
        }

        void RefreshTabs()
        {
            EditorTabs.Children.Clear();
            SvMip.Edit.Base.SvToolEditBase ed = mVision.JobEdit.DockedEditorNow;
            if (ed == null) return;
            string[] names = ed.GetTabNames();
            int selected = ed.SelectedTabIndex;
            for (int i = 0; i < names.Length; i++)
            {
                int index = i;
                bool on = i == selected;
                Border tab = new Border();
                tab.Padding = new Thickness(14, 10, 14, 8);
                tab.Cursor = System.Windows.Input.Cursors.Hand;
                tab.Background = Brushes.Transparent;
                tab.BorderThickness = new Thickness(0, 0, 0, 2);
                tab.BorderBrush = on ? (Brush)FindResource("IvaAccentBrush") : Brushes.Transparent;
                TextBlock t = new TextBlock();
                t.Text = names[i];
                t.FontSize = 12.5;
                t.FontWeight = on ? FontWeights.SemiBold : FontWeights.Normal;
                t.Foreground = (Brush)FindResource(on ? "IvaTextBrush" : "IvaMutedBrush");
                t.HorizontalAlignment = HorizontalAlignment.Left;
                tab.Child = t;
                tab.MouseLeftButtonUp += delegate { ed.SelectedTabIndex = index; RefreshTabs(); };
                EditorTabs.Children.Add(tab);
            }
            // one page only: no strip
            ((Border)EditorTabs.Parent).Visibility = names.Length > 1 ? Visibility.Visible : Visibility.Collapsed;
        }

        void Select(string name)
        {
            mVision.SelectProcess(name);
            RefreshHeader();
        }

        void RefreshHeader()
        {
            foreach (object o in Pills.Children)
            {
                Button b = o as Button;
                if (b != null) b.Tag = object.Equals(b.Content, mVision.ActiveProcess) ? "on" : null;
            }
            string job = mVision.JobFile;
            JobText.Text = string.IsNullOrEmpty(job) ? "No job open - choose a process" : job;
            RecipeText.Text = string.IsNullOrEmpty(mVision.CurrentRecipe) ? "" : "Recipe: " + mVision.CurrentRecipe;
        }

        /// <summary>Called before the screen is replaced; releases the WinForms editor.</summary>
        public void DisposeContent()
        {
            Host.Child = null;
            mVision.Dispose();
        }
    }
}
