﻿using SvMip.Display;
using SvMip.Edit.Base;
using SvMip.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// ManualAlign.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ManualAlign : Window
    {
        SvDisplayViewEdit mEdit;

        AlignResult mResult;
        SvJob mJob;
        VMManualAlign mVm;
        IIO mIO;
        int CompIndex;

        DispatcherTimer watcher;

        public ManualAlign()
        {
            InitializeComponent();

            Loaded += (sender, e) => { InitDisplay(); };
            Closing += (sender, e) =>
            {
                watcher.Stop();
                mEdit.Dispose();
                GC.Collect();
            };

            mEdit = new SvDisplayViewEdit();
            WindowsFormsHost host = new WindowsFormsHost();

            host.Child = mEdit;
            bdDisplay.Child = host;

            mVm = new VMManualAlign();
            this.DataContext = mVm;
            mVm.PropertyChanged += MVm_PropertyChanged;

            watcher = new DispatcherTimer();
            watcher.Interval = new TimeSpan(1000000);
            watcher.Tick += watcher_Tick;
            watcher.Start();
        }

        void watcher_Tick(object sender, EventArgs e)
        {
            if (mIO == null) return;
            if (mIO.GetInValue(CompIndex))//완료신호 켜 졌으면,,,
            {
                this.DialogResult = false;
                Close();
            }
        }

        private void MVm_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Judge")
            {
                mEdit.Display.InteractiveGraphicsCollection.Clear();
                mEdit.Display.GraphicsCollection.Clear();
                if (mVm.Judge)
                {
                    SvPoint sp, ep;
                    SvLine line;
                    SvEllipse el;

                    int idx = mVm.PanelIndex * 2;
                    //시작점
                    sp = new SvPoint(mResult.ManualAlignPoint[idx].X, mResult.ManualAlignPoint[idx].Y);
                    sp.CrossSize = mEdit.Display.Image.Width/20;
                    sp.Refresh += point_Refresh;
                    mEdit.Display.InteractiveGraphicsCollection.Add(sp);
                    //끝점
                    ep = new SvPoint(mResult.ManualAlignPoint[idx+1].X, mResult.ManualAlignPoint[idx+1].Y);
                    ep.CrossSize = mEdit.Display.Image.Width / 20;
                    ep.Refresh += point_Refresh;
                    mEdit.Display.InteractiveGraphicsCollection.Add(ep);

                    double dx = sp.X - ep.X;
                    double dy = sp.Y - ep.Y;
                    double rad = Math.Atan2(dx, -dy);

                    sp.ThetaRad = ep.ThetaRad = rad;
                    //연결선
                    line = new SvLine(sp.Point2d, ep.Point2d);
                    line.Color = System.Drawing.Color.Salmon;
                    mEdit.Display.InteractiveGraphicsCollection.Add(line);
                    //중심점
                    el = new SvEllipse(new System.Drawing.PointF((float)line.CP.X, (float)line.CP.Y), 1, 1);
                    mEdit.Display.GraphicsCollection.Add(el);
                }
            }
        }

        void point_Refresh(object sender, EventArgs arg)
        {
            if (mEdit.Display.InteractiveGraphicsCollection.Count < 3) return;
            SvPoint sp = mEdit.Display.InteractiveGraphicsCollection[0] as SvPoint;
            SvPoint ep = mEdit.Display.InteractiveGraphicsCollection[1] as SvPoint;
            SvLine line = mEdit.Display.InteractiveGraphicsCollection[2] as SvLine;
            SvEllipse el = mEdit.Display.GraphicsCollection[0] as SvEllipse;
            if (sp == null || ep == null || line == null || el == null) return;

            line.SP = sp.Point2d;
            line.EP = ep.Point2d;

            double dx = sp.X - ep.X;
            double dy = sp.Y - ep.Y;
            double rad = Math.Atan2(dx, -dy);

            sp.ThetaRad = ep.ThetaRad = rad;

            el.Center = new System.Drawing.PointF((float)line.CP.X, (float)line.CP.Y);
        }

        public void InitWnd(AlignResult result, SvJob job, PanelFlowType type, IIO io, int index)
        {
            mResult = result;
            mVm.Judgements = result.AlignJudge.ToArray();
            mJob = job;
            mVm.FlowType = type;
            mIO = io;
            CompIndex = index;
        }

        private void InitDisplay()
        {
            mEdit.Display.InteractiveGraphicsCollection.Clear();
            if (mEdit.Display.Image != null) mEdit.Display.Image.Dispose();

            SvAcquisition acq = mJob["Acquisition"] as SvAcquisition;
            if (acq != null) 
                mEdit.Display.Image = acq.AcqusitionImage as SvImage;
        }

        private bool ValidatePoint()
        {
            try
            {
                double x, y, t, dx, dy;
                mResult.ResultPoints.Clear();
                for (int i = 0; i < mResult.ManualAlignPoint.Count / 2; i++)
                {
                    mResult.AlignJudge[i] = mVm.Judgements[i];
                    if (mResult.AlignJudge[i])
                    {
                        x = ((mResult.ManualAlignPoint[i * 2]).X + (mResult.ManualAlignPoint[i * 2 + 1]).X) / 2;
                        y = ((mResult.ManualAlignPoint[i * 2]).Y + (mResult.ManualAlignPoint[i * 2 + 1]).Y) / 2;
                        dx = ((mResult.ManualAlignPoint[i * 2]).X - (mResult.ManualAlignPoint[i * 2 + 1]).X);
                        dy = ((mResult.ManualAlignPoint[i * 2]).Y - (mResult.ManualAlignPoint[i * 2 + 1]).Y);
                        t = (Math.Atan2(dx, dy));
                        mResult.ResultPoints.Add(new SvPoint(x, y, -t));
                    }
                    else
                    {
                        mResult.ResultPoints.Add(new SvPoint());
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurrence : " + ex.ToString());
                return false;
            }
        }

        private void btnInit_Click(object sender, RoutedEventArgs e)
        {
            InitDisplay();
        }

        private void btnGrab_Click(object sender, RoutedEventArgs e)
        {
            if (mEdit.Display.Image != null) 
                mEdit.Display.Image.Dispose();

            SvAcquisition acq = mJob["Acquisition"] as SvAcquisition;
            acq.Run();
            if (acq != null) 
                mEdit.Display.Image = acq.AcqusitionImage.Clone() as SvImage;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            Close();
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            SvNotifyCollection<InteractDrawObject> collection = mEdit.Display.InteractiveGraphicsCollection;
            // apply result
            if (collection.Count > 0)
            {
                for (int i = 0; i < 2; i++)
                {
                    int idx = mVm.PanelIndex * 2 + i;
                    mResult.ManualAlignPoint[idx] = ((SvPoint)collection[i]).Point3d;
                }
            }

            this.DialogResult = ValidatePoint();
            this.Close();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton btn = sender as RadioButton;
            if (btn == null) return;
            int idx;

            SvNotifyCollection<InteractDrawObject> collection = mEdit.Display.InteractiveGraphicsCollection;
            // apply result
            if (collection.Count > 0)
            {
                for (int i = 0; i < 2; i++)
                {
                    idx = mVm.PanelIndex * 2 + i;
                    mResult.ManualAlignPoint[idx] = ((SvPoint)collection[i]).Point3d;
                }
            }

            collection.Clear();

            mVm.PanelIndex = int.Parse(btn.Tag.ToString());
        }
    }

    public class VMManualAlign : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        
        int mPanelIndex;
        public int PanelIndex
        {
            set
            {
                if (mPanelIndex == value) return;
                mPanelIndex = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("PanelIndex"));
                    PropertyChanged(this, new PropertyChangedEventArgs("Judge"));
                    PropertyChanged(this, new PropertyChangedEventArgs("SJudge"));
                    PropertyChanged(this, new PropertyChangedEventArgs("CJudge"));
                }
            }
            get { return mPanelIndex; }
        }

        PanelFlowType mFlowType;
        public PanelFlowType FlowType
        {
            set
            {
                if (mFlowType == value) return;
                mFlowType = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("IsDualFlow"));
            }
        }

        public bool IsDualFlow { get { return mFlowType == PanelFlowType.Dual; } }

        public bool[] Judgements = new bool[2];

        public bool Judge
        {
            set
            {
                if (Judgements[PanelIndex] == value) return;
                Judgements[PanelIndex] = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("Judge"));
                    PropertyChanged(this, new PropertyChangedEventArgs("SJudge"));
                    PropertyChanged(this, new PropertyChangedEventArgs("CJudge"));
                }
            }
            get { return Judgements[PanelIndex]; }
        }

        public string SJudge { get { return Judgements[PanelIndex] ? "OK" : "NG"; } }
        public Brush CJudge { get { return Judgements[PanelIndex] ? Brushes.Green : Brushes.Red; } }
    }
}
