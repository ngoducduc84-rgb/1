﻿using SvMip.Display;
using SvMip.Edit.Base;
using SvMip.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// ManualAlign.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ManualInspAlign : Window
    {
        SvDisplayViewEdit mEdit;

        AlignResult mResult;
        SvJob mJob;

        IIO mIO;
        int CompIndex;
        DispatcherTimer watcher;

        List<ButtonBase> judgeButtons = new List<ButtonBase>();

        public ManualInspAlign()
        {
            InitializeComponent();

            Loaded += (sender, e) => { InitDisplay(); };
            Closed += (sender, e) =>
            {
                watcher.Stop();
                mEdit.Dispose();
                GC.Collect();
            };

            mEdit = new SvDisplayViewEdit();
            WindowsFormsHost host = new WindowsFormsHost();

            host.Child = mEdit;
            bdDisplay.Child = host;

            watcher = new DispatcherTimer();
            watcher.Interval = new TimeSpan(1000000);
            watcher.Tick += watcher_Tick;
            watcher.Start();
        }

        void watcher_Tick(object sender, EventArgs e)
        {
            if (mIO == null) return;
            if (mIO.GetInValue(CompIndex))//완료신호 켜 졌으면,,,
            {
                this.DialogResult = false;
                Close();
            }
        }

        public void InitWnd(AlignResult result, SvJob job, IIO io, int index)
        {
            mResult = result;
            mJob = job;
            mIO = io;
            CompIndex = index;
            IsExist.IsChecked = true;
        }

        System.Drawing.Font font08 = new System.Drawing.Font("Segoe UI", 08, System.Drawing.FontStyle.Bold);

        private void InitDisplay()
        {
            InitImage();
            InitJudge();

            if (IsExist.IsChecked == true)
                InitRegion();
            else
                InitPoint();
        }

        private void InitImage()
        {
            SvAcquisition acq = mJob["Acquisition"] as SvAcquisition;
            if (mEdit.Display.Image != null) 
                mEdit.Display.Image.Dispose();
            
            mEdit.Display.Image = acq.AcqusitionImage.Clone() as SvImage;
        }

        private void InitJudge()
        {
            judgeButtons.Clear();
            ugJudge.Children.Clear();
            if (IsExist.IsChecked == true)
            {
                ToggleButton btn;
                for (int i = 0; i < mResult.Existences.Count; i++)
                {
                    // judgement button
                    btn = new ToggleButton();
                    btn.IsChecked = mResult.Existences[i];
                    btn.Content = string.Format("#{0}", i + 1);
                    btn.Click += btn_Click;
                    judgeButtons.Add(btn);
                    ugJudge.Children.Add(btn);
                }
                btn = new ToggleButton();
                btn.Content = "All";
                btn.Click += All_Click;
                ugJudge.Children.Add(btn);
            }
            else// if (IsAlign.IsChecked == true)
            {
                RadioButton btn;
                for (int i = 0; i < mResult.AlignJudge.Count; i++)
                {
                    btn = new RadioButton();
                    btn.Content = string.Format("#{0}", i + 1);
                    btn.IsEnabled = mResult.Existences[i];
                    btn.Checked += btn_Checked;
                    judgeButtons.Add(btn);
                    ugJudge.Children.Add(btn);
                }
                ToggleButton tb = new ToggleButton();
                tb.Content = "Judgement";
                tb.Click += tb_Click;
            }
        }

        void tb_Click(object sender, RoutedEventArgs e)
        {
            ToggleButton btn = sender as ToggleButton;
            for (int i = 0; i < judgeButtons.Count; i++)
            {
                if (((ToggleButton)judgeButtons[i]).IsChecked == true)
                {
                    mResult.AlignJudge[i] = (btn.IsChecked == true);
                    btn.Background = mResult.AlignJudge[i] ? Brushes.YellowGreen : Brushes.Red;
                    btn.Content = mResult.AlignJudge[i] ? "OK" : "NG";
                    break;
                }
            }
        }

        int prev;

        void btn_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton btn = sender as RadioButton;
            if (btn == null) return;
            int idx;
            SvNotifyCollection<InteractDrawObject> collection = mEdit.Display.InteractiveGraphicsCollection;
            // apply change value
            if (collection.Count > 0)
            {
                for (int i = 0; i < 2; i++)
                {
                    idx = prev * 2 + i;
                    mResult.ManualAlignPoint[idx] = ((SvPoint)collection[i]).Point3d;
                }
            }
            // 현재 버튼
            prev = judgeButtons.IndexOf(btn);

            InitPoint();
        }

        void btn_Click(object sender, RoutedEventArgs e)
        {
            InitRegion();
        }

        void All_Click(object sender, RoutedEventArgs e)
        {
            ToggleButton btn = sender as ToggleButton;
            if (btn != null)
            {
                for (int i = 0; i < judgeButtons.Count; i++)
                {
                    ((ToggleButton)judgeButtons[i]).IsChecked = btn.IsChecked;
                    mResult.Existences[i] = (btn.IsChecked == true);
                }

                InitRegion();
            }
        }

        private void InitRegion()
        {
            int blockindex = mResult.JobInfo.Count == 1 ? 0 : 1;
            SvRegion region = mResult.JobInfo[blockindex][typeof(SvRegion)][0].Toolbase as SvRegion;
            region.IndexXnext = 0; region.IndexYnext = 0;

            SvRectangle rect;
            System.Drawing.Pen pen;
            System.Drawing.Color color;
            System.Drawing.Brush brush;
            System.Drawing.PointF pnt;
            string sJudge;
            int idx = 0;

            ToggleButton btn;
            for (int i = 0; i < judgeButtons.Count; i++)
            {
                btn = judgeButtons[i] as ToggleButton;
                if (btn == null) return;

                mResult.Existences[i] = (btn.IsChecked == true);
                // display
                sJudge = string.Format("{0}", ++idx);

                color = (btn.IsChecked == true) ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Red;
                pen = new System.Drawing.Pen(color);
                pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                brush = new System.Drawing.SolidBrush(color);

                region.Run();
                rect = region.OutputImage.RegionRect;
                pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);

                mEdit.Display.DrawString(sJudge, font08, brush, pnt);
                mEdit.Display.DrawRectangle(pen, rect.RectF);

                region.IncreaseIndex();
            }
        }

        private void InitPoint()//align point 추가
        {
            RadioButton btn;
            mEdit.Display.InteractiveGraphicsCollection.Clear();
            for (int i = 0; i < judgeButtons.Count; i++)
            {
                btn = judgeButtons[i] as RadioButton;
                if (btn == null) return;
                if (btn.IsChecked == true)
                {
                    SvPoint sp, ep;
                    SvLine line;
                    int idx = i * 2;
                    sp = new SvPoint(mResult.ManualAlignPoint[idx].X, mResult.ManualAlignPoint[idx].Y);
                    sp.CrossSize = mEdit.Display.Image.Width / 50;
                    sp.Refresh += point_Refresh;
                    mEdit.Display.InteractiveGraphicsCollection.Add(sp);

                    ep = new SvPoint(mResult.ManualAlignPoint[idx + 1].X, mResult.ManualAlignPoint[idx + 1].Y);
                    ep.CrossSize = mEdit.Display.Image.Width / 50;
                    ep.Refresh += point_Refresh;
                    mEdit.Display.InteractiveGraphicsCollection.Add(ep);

                    line = new SvLine(sp.Point2d, ep.Point2d);
                    mEdit.Display.InteractiveGraphicsCollection.Add(line);
                }
            }
        }

        void point_Refresh(object sender, EventArgs arg)
        {
            if (mEdit.Display.InteractiveGraphicsCollection.Count < 3) return;
            SvPoint sp = mEdit.Display.InteractiveGraphicsCollection[0] as SvPoint;
            SvPoint ep = mEdit.Display.InteractiveGraphicsCollection[1] as SvPoint;
            SvLine line = mEdit.Display.InteractiveGraphicsCollection[2] as SvLine;
            if (sp == null || ep == null || line == null) return;

            line.SP = sp.Point2d;
            line.EP = ep.Point2d;

            double dx = sp.X - ep.X;
            double dy = sp.Y - ep.Y;
            double rad = Math.Atan2(dx, -dy);

            sp.ThetaRad = ep.ThetaRad = rad;
        }

        private void btnInit_Click(object sender, RoutedEventArgs e)
        {
            InitDisplay();
        }
        
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            Close();
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (IsAlign.IsChecked == true)//마지막 변경된 좌표 적용
            {
                if (mEdit.Display.InteractiveGraphicsCollection.Count >= 2)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        int idx = prev * 2 + i;
                        mResult.ManualAlignPoint[idx] = ((SvPoint)mEdit.Display.InteractiveGraphicsCollection[i]).Point3d;
                    }
                } 
            }

            for (int i = 0; i < mResult.AlignJudge.Count; i++)
            {
                // existence == judgement
                mResult.AlignJudge[i] = mResult.Existences[i];
            }

            this.DialogResult = ValidatePoint();
            Close();
        }

        private bool ValidatePoint()
        {
            try
            {
                double x, y, t, dx, dy;
                mResult.ResultPoints.Clear();
                for (int i = 0; i < mResult.ManualAlignPoint.Count / 2; i++)
                {
                    if (mResult.AlignJudge[i])
                    {
                        x = ((mResult.ManualAlignPoint[i * 2]).X + (mResult.ManualAlignPoint[i * 2 + 1]).X) / 2;
                        y = ((mResult.ManualAlignPoint[i * 2]).Y + (mResult.ManualAlignPoint[i * 2 + 1]).Y) / 2;
                        dx = ((mResult.ManualAlignPoint[i * 2]).X - (mResult.ManualAlignPoint[i * 2 + 1]).X);
                        dy = ((mResult.ManualAlignPoint[i * 2]).Y - (mResult.ManualAlignPoint[i * 2 + 1]).Y);
                        t = (Math.Atan2(dx, -dy));
                        mResult.ResultPoints.Add(new SvPoint(x, y, t));
                    }
                    else
                    {
                        mResult.ResultPoints.Add(new SvPoint());
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occurrence : " + ex.ToString());
                return false;
            }
        }

        private void Exist_Checked(object sender, RoutedEventArgs e)
        {
            // align 정보 저장
            if (mEdit.Display.InteractiveGraphicsCollection.Count >= 2)
            {
                for (int i = 0; i < 2; i++)
                {
                    int idx = prev * 2 + i;
                    mResult.ManualAlignPoint[idx] = ((SvPoint)mEdit.Display.InteractiveGraphicsCollection[i]).Point3d;
                }
            } 

            InitDisplay();
        }

        private void Align_Checked(object sender, RoutedEventArgs e)
        {
            InitDisplay();
        }
    }
}
