﻿using SvMip.Display;
using SvMip.Edit.Base;
using SvMip.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// ManualAlign.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ManualInspection : Window
    {
        SvDisplayViewEdit mEdit;

        AlignResult mResult;
        SvJob mJob;
        
        IIO mIO;
        int CompIndex;
        int mJobindex;

        DispatcherTimer watcher;

        List<ToggleButton> judgeButtons = new List<ToggleButton>();

        public ManualInspection()
        {
            InitializeComponent();

            Loaded += (sender, e) => { InitDisplay(); };
            Closed += (sender, e) =>
            {
                watcher.Stop();
                mEdit.Dispose();
                GC.Collect();
            };

            mEdit = new SvDisplayViewEdit();
            WindowsFormsHost host = new WindowsFormsHost();

            host.Child = mEdit;
            bdDisplay.Child = host;

            watcher = new DispatcherTimer();
            watcher.Interval = new TimeSpan(1000000);
            watcher.Tick += watcher_Tick;
            watcher.Start();
        }

        void watcher_Tick(object sender, EventArgs e)
        {
            if (mIO == null) return;
            if (mIO.GetInValue(CompIndex))//완료신호 켜 졌으면,,,
            {
                this.DialogResult = false;
                Close();
            }
        }

        public void InitWnd(AlignResult result, SvJob job, IIO io, int index)
        {
            mResult = result;
            mJob = job;
            mIO = io;
            CompIndex = index;
        }

        public void InitWnd(AlignResult result, SvJob job, IIO io, int index, int i)
        {
            mResult = result;
            mJob = job;
            mIO = io;
            CompIndex = index;
            mJobindex = i;

        }

        System.Drawing.Font font08 = new System.Drawing.Font("Segoe UI", 08, System.Drawing.FontStyle.Bold);

        private void InitDisplay()
        {
            InitImage();
            InitJudge();
            InitRegion();
        }

        private void InitImage()
        {
            if (mResult.JobInfo[mJobindex].ContainsKey(typeof(SvJudgement)))
            {
                SvJudgement judge = mJob["Judgement"] as SvJudgement;
                mEdit.Display.Image = judge.InputImage;
                mEdit.Display.FitToWindow();
            }

            else
            {
                SvAcquisition acq = mJob["Acquisition"] as SvAcquisition;
                mEdit.Display.Image = acq.AcqusitionImage;
            }
            
        }

        private void InitJudge()
        {
            judgeButtons.Clear();
            ugJudge.Children.Clear();
            ToggleButton btn;

            //SvRegion region = mResult.JobInfo[mJobindex][typeof(SvRegion)][0].Toolbase as SvRegion;
            SvJudgement judge = mResult.JobInfo[mJobindex][typeof(SvJudgement)][0].Toolbase as SvJudgement;
            //for (int i = 0; i < mResult.Existences.Count; i++)
            for (int i = 0; i < mResult.List2JudgeValues[mJobindex].Count; i++)
            {
                // judgement button
                btn = new ToggleButton();
                //btn.IsChecked = mResult.Existences[i];
                btn.IsChecked = mResult.List2JudgeResult[mJobindex][i];
                btn.Content = string.Format("#{0}", i + 1);
                btn.Click += btn_Click;
                judgeButtons.Add(btn);
                ugJudge.Children.Add(btn);
            }
            btn = new ToggleButton();
            btn.Content = "All";
            btn.Click += All_Click;
            ugJudge.Children.Add(btn);
        }

        void btn_Click(object sender, RoutedEventArgs e)
        {
            InitRegion();
        }

        void All_Click(object sender, RoutedEventArgs e)
        {
            ToggleButton btn = sender as ToggleButton;
            if (btn != null)
            {
                foreach (var tb in judgeButtons)
                {
                    tb.IsChecked = btn.IsChecked;
                }
                InitRegion();
            }
        }

        private void InitRegion()
        {
            //SvRegion region = mResult.JobInfo[1][typeof(SvRegion)][0].Toolbase as SvRegion;
            SvRegion region = mResult.JobInfo[mJobindex][typeof(SvRegion)][0].Toolbase as SvRegion;
            region.IndexXnext = 0; region.IndexYnext = 0;

            SvRectangle rect;
            System.Drawing.Pen pen;
            System.Drawing.Color color;
            System.Drawing.Brush brush;
            System.Drawing.PointF pnt;
            string sJudge;
            int idx = 0;

            foreach (var btn in judgeButtons)
            {
                try
                {
                    // display
                    sJudge = string.Format("{0}", ++idx);

                    color = (btn.IsChecked == true) ? System.Drawing.Color.YellowGreen : System.Drawing.Color.Red;
                    pen = new System.Drawing.Pen(color);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    brush = new System.Drawing.SolidBrush(color);

                    region.Run();
                    rect = region.OutputImage.RegionRect;
                    pnt = new System.Drawing.PointF(rect.Location.X, rect.Location.Y);

                    mEdit.Display.DrawString(sJudge, font08, brush, pnt);
                    mEdit.Display.DrawRectangle(pen, rect.RectF);

                    region.IncreaseIndex();
                }

                catch (Exception ex)
                {
                    Common.SvLogger.Log.Error("[ManualInspection] " + ex.Message);
                }

            }
        }
        
        private void btnInit_Click(object sender, RoutedEventArgs e)
        {
            InitDisplay();
        }
        
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < judgeButtons.Count; i++)
                mResult.List2JudgeResult[mJobindex][i] = (judgeButtons[i].IsChecked == true) ? true : false;
                //mResult.Existences[i] = (judgeButtons[i].IsChecked == true) ? true : false;
            this.DialogResult = true;
            this.Close();
        }

    }
}
