﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Interaction logic for LoginDlg.xaml
    /// </summary>
    public partial class PasswordDlg : Window
    {
        SystemData msystemData = new SystemData();

        public PasswordDlg()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = ((newPW.Password == newPWCheck.Password) && (newPW.Password != ""));

            if ((newPW.Password == newPWCheck.Password) && (newPW.Password != ""))
            {
                msystemData.SetPassword(newPW.Password);
            }

            Close();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                Button_Click(sender, e);
            }
            else if (e.Key == Key.Escape)
            {
                Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.newPW.Focus();
        }
    }
}
