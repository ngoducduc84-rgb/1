﻿using System;
using System.Reflection;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using SvMip.Common;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    static class Program
    {
        /// <summary>
        /// 해당 응용 프로그램의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            if (ProcessChecker.IsOnlyProcess("Main"))
            {
                SvMip.Instance.Initialize();
                SvLogger.Log.Debug("Program Start...");
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
                AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
                Application.Run(new Main());
                Auto.EndAuto();
                SvLogger.Log.Debug("Program Exit...");
            }
        }
        static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            //MessageBox.Show(e.Exception.Message, "Unhandled Thread Exception");
            // here you can log the exception ...
            SvMip.Common.SvLogger.Log.Error("[Unhandled Thread exception] "+ e.Exception.ToString());
        }

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = e.ExceptionObject as Exception;
            SvMip.Common.SvLogger.Log.Error("[Unhandled Thread exception] " + ex.ToString());
        }
    }
}
