﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// Text template of a SvSend "Text" channel.
    ///   {Name}        value of the field with that name
    ///   {Name:F3}     with a .NET format string (numbers only), e.g. {x:F3}
    ///   {{ and }}     literal braces
    ///   \r \n \t \\   carriage return, line feed, tab, backslash
    /// Example:  {x1:F3},{y1:F3},{t1:F3}\r\n
    /// </summary>
    public static class SendTemplate
    {
        public static bool TryFormat(string template, IDictionary<string, object> values, out string result, out string error)
        {
            result = "";
            error = "";
            if (template == null) template = "";
            StringBuilder sb = new StringBuilder();
            int i = 0;
            while (i < template.Length)
            {
                char c = template[i];
                if (c == '\\' && i + 1 < template.Length)
                {
                    char n = template[i + 1];
                    if (n == 'r') { sb.Append('\r'); i += 2; continue; }
                    if (n == 'n') { sb.Append('\n'); i += 2; continue; }
                    if (n == 't') { sb.Append('\t'); i += 2; continue; }
                    if (n == '\\') { sb.Append('\\'); i += 2; continue; }
                    sb.Append(c);
                    i++;
                    continue;
                }
                if (c == '{')
                {
                    if (i + 1 < template.Length && template[i + 1] == '{')
                    {
                        sb.Append('{');
                        i += 2;
                        continue;
                    }
                    int end = template.IndexOf('}', i + 1);
                    if (end < 0)
                    {
                        error = "missing '}' in the template";
                        return false;
                    }
                    string token = template.Substring(i + 1, end - i - 1);
                    string name = token;
                    string fmt = "";
                    int colon = token.IndexOf(':');
                    if (colon >= 0)
                    {
                        name = token.Substring(0, colon);
                        fmt = token.Substring(colon + 1);
                    }
                    name = name.Trim();
                    object v;
                    if (!values.TryGetValue(name, out v))
                    {
                        error = "unknown field '" + name + "' in the template";
                        return false;
                    }
                    sb.Append(FormatValue(v, fmt));
                    i = end + 1;
                    continue;
                }
                if (c == '}')
                {
                    if (i + 1 < template.Length && template[i + 1] == '}')
                    {
                        sb.Append('}');
                        i += 2;
                        continue;
                    }
                    error = "unexpected '}' in the template";
                    return false;
                }
                sb.Append(c);
                i++;
            }
            result = sb.ToString();
            return true;
        }

        static string FormatValue(object v, string fmt)
        {
            IFormattable f = v as IFormattable;
            if (f != null && fmt.Length > 0) return f.ToString(fmt, CultureInfo.InvariantCulture);
            if (v is double) return ((double)v).ToString("0.######", CultureInfo.InvariantCulture);
            return Convert.ToString(v, CultureInfo.InvariantCulture);
        }

        /// <summary>Turns the escapes \r \n \t \\ of a typed text into the real characters.</summary>
        public static string Unescape(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Replace("\\r", "\r").Replace("\\n", "\n").Replace("\\t", "\t").Replace("\\\\", "\\");
        }

        /// <summary>Text with the control characters made visible (for logs).</summary>
        public static string Visible(string s)
        {
            if (s == null) return "";
            return s.Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
        }
    }
}
