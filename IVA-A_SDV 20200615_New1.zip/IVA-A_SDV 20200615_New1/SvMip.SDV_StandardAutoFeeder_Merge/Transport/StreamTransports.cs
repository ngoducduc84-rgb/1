﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// A byte-stream connection used by SvSend channels of kind Text / Registers.
    /// Independent of the robot / IO connections of the process (those are still created by Auto.InitInterface).
    /// </summary>
    public interface ISendTransport : IDisposable
    {
        string Name { get; }
        bool IsOpen { get; }
        bool Open(out string error);
        void Close();
        /// <summary>Opens the connection when needed (one retry) and sends the bytes.</summary>
        bool Send(byte[] data, out string error);
        /// <summary>Waits for incoming bytes. Returns false on timeout or when not supported.</summary>
        bool Receive(int timeoutMs, out byte[] data, out string error);
        /// <summary>Reads what has already arrived without waiting. Returns false when nothing is available.</summary>
        bool Poll(out byte[] data);
    }

    // ------------------------------------------------------------------ TCP client
    public class TcpClientTransport : ISendTransport
    {
        protected readonly object Sync = new object();
        protected readonly string mName;
        protected readonly string mHost;
        protected readonly int mPort;
        protected readonly int mTimeout;
        protected TcpClient mClient;
        protected NetworkStream mStream;

        public TcpClientTransport(string name, string host, int port, int timeoutMs)
        {
            mName = name;
            mHost = host;
            mPort = port;
            mTimeout = (timeoutMs > 0) ? timeoutMs : 1000;
        }

        public string Name { get { return mName; } }

        public bool IsOpen
        {
            get { lock (Sync) { return mClient != null && mClient.Connected; } }
        }

        public bool Open(out string error)
        {
            lock (Sync)
            {
                error = "";
                if (mClient != null && mClient.Connected) return true;
                CloseNoLock();
                try
                {
                    TcpClient c = new TcpClient();
                    IAsyncResult ar = c.BeginConnect(mHost, mPort, null, null);
                    if (!ar.AsyncWaitHandle.WaitOne(mTimeout))
                    {
                        c.Close();
                        error = "connect timeout (" + mHost + ":" + mPort + ")";
                        return false;
                    }
                    c.EndConnect(ar);
                    c.NoDelay = true;
                    c.SendTimeout = mTimeout;
                    c.ReceiveTimeout = mTimeout;
                    mClient = c;
                    mStream = c.GetStream();
                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    CloseNoLock();
                    return false;
                }
            }
        }

        public void Close()
        {
            lock (Sync) { CloseNoLock(); }
        }

        protected void CloseNoLock()
        {
            try { if (mStream != null) mStream.Close(); } catch (Exception) { }
            try { if (mClient != null) mClient.Close(); } catch (Exception) { }
            mStream = null;
            mClient = null;
        }

        public virtual bool Send(byte[] data, out string error)
        {
            lock (Sync)
            {
                error = "";
                for (int attempt = 0; attempt < 2; attempt++)
                {
                    if (!Open(out error)) return false;
                    try
                    {
                        mStream.Write(data, 0, data.Length);
                        mStream.Flush();
                        error = "";
                        return true;
                    }
                    catch (Exception ex)
                    {
                        error = ex.Message;
                        CloseNoLock();
                    }
                }
                return false;
            }
        }

        public bool Poll(out byte[] data)
        {
            data = null;
            lock (Sync)
            {
                if (mClient == null || mStream == null) return false;
                try
                {
                    int available = mClient.Available;
                    if (available > 0)
                    {
                        byte[] buf = new byte[available];
                        int n = mStream.Read(buf, 0, buf.Length);
                        if (n <= 0) return false;
                        data = new byte[n];
                        Array.Copy(buf, data, n);
                        return true;
                    }
                    // nothing to read: a connection closed by the peer shows up as "readable" with 0 bytes
                    if (mClient.Client.Poll(0, SelectMode.SelectRead) && mClient.Available == 0) CloseNoLock();
                    return false;
                }
                catch (Exception)
                {
                    CloseNoLock();
                    return false;
                }
            }
        }

        public bool Receive(int timeoutMs, out byte[] data, out string error)
        {
            data = null;
            error = "";
            lock (Sync)
            {
                if (mStream == null)
                {
                    error = "not connected";
                    return false;
                }
                try
                {
                    mStream.ReadTimeout = (timeoutMs > 0) ? timeoutMs : 1;
                    byte[] buf = new byte[4096];
                    int n = mStream.Read(buf, 0, buf.Length);
                    if (n <= 0)
                    {
                        error = "connection closed by the peer";
                        CloseNoLock();
                        return false;
                    }
                    data = new byte[n];
                    Array.Copy(buf, data, n);
                    return true;
                }
                catch (IOException)
                {
                    error = "timeout";
                    return false;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    CloseNoLock();
                    return false;
                }
            }
        }

        public void Dispose()
        {
            Close();
        }
    }

    // ------------------------------------------------------------------ Modbus TCP (client)
    public class ModbusTcpTransport : TcpClientTransport
    {
        ushort mTransaction = 0;

        public ModbusTcpTransport(string name, string host, int port, int timeoutMs) : base(name, host, port, timeoutMs)
        {
        }

        /// <summary>Function 16 (write multiple registers). Splits requests above 123 registers.</summary>
        public bool WriteRegisters(byte unitId, ushort start, ushort[] values, out string error)
        {
            error = "";
            if (values == null || values.Length == 0) return true;
            for (int offset = 0; offset < values.Length; offset += 123)
            {
                int qty = Math.Min(123, values.Length - offset);
                if (!WriteChunk(unitId, (ushort)(start + offset), values, offset, qty, out error)) return false;
            }
            return true;
        }

        bool WriteChunk(byte unitId, ushort address, ushort[] values, int offset, int qty, out string error)
        {
            lock (Sync)
            {
                error = "";
                for (int attempt = 0; attempt < 2; attempt++)
                {
                    if (!Open(out error)) return false;
                    try
                    {
                        mTransaction++;
                        byte[] req = new byte[13 + 2 * qty];
                        int len = 7 + 2 * qty;
                        req[0] = (byte)(mTransaction >> 8);
                        req[1] = (byte)(mTransaction & 0xFF);
                        req[2] = 0;
                        req[3] = 0;
                        req[4] = (byte)(len >> 8);
                        req[5] = (byte)(len & 0xFF);
                        req[6] = unitId;
                        req[7] = 0x10;
                        req[8] = (byte)(address >> 8);
                        req[9] = (byte)(address & 0xFF);
                        req[10] = (byte)(qty >> 8);
                        req[11] = (byte)(qty & 0xFF);
                        req[12] = (byte)(2 * qty);
                        for (int i = 0; i < qty; i++)
                        {
                            ushort v = values[offset + i];
                            req[13 + 2 * i] = (byte)(v >> 8);
                            req[14 + 2 * i] = (byte)(v & 0xFF);
                        }
                        mStream.WriteTimeout = mTimeout;
                        mStream.Write(req, 0, req.Length);
                        mStream.Flush();

                        mStream.ReadTimeout = mTimeout;
                        byte[] head = ReadExact(9);
                        if ((head[7] & 0x80) != 0)
                        {
                            error = "Modbus exception code " + head[8];
                            return false;
                        }
                        ReadExact(3); // rest of the normal response (address, quantity)
                        error = "";
                        return true;
                    }
                    catch (Exception ex)
                    {
                        error = ex.Message;
                        CloseNoLock();
                    }
                }
                return false;
            }
        }

        byte[] ReadExact(int count)
        {
            byte[] buf = new byte[count];
            int got = 0;
            while (got < count)
            {
                int n = mStream.Read(buf, got, count - got);
                if (n <= 0) throw new IOException("connection closed by the peer");
                got += n;
            }
            return buf;
        }

        public override bool Send(byte[] data, out string error)
        {
            error = "raw bytes cannot be sent on a Modbus connection (use a Registers channel)";
            return false;
        }
    }

    // ------------------------------------------------------------------ TCP server (the vision is the server)
    public class TcpServerTransport : ISendTransport
    {
        readonly object mSync = new object();
        readonly string mName;
        readonly int mPort;
        readonly int mTimeout;
        TcpListener mListener;
        Thread mAcceptThread;
        volatile bool mRunning;
        readonly List<TcpClient> mClients = new List<TcpClient>();

        public TcpServerTransport(string name, int port, int timeoutMs)
        {
            mName = name;
            mPort = port;
            mTimeout = (timeoutMs > 0) ? timeoutMs : 1000;
        }

        public string Name { get { return mName; } }

        public bool IsOpen
        {
            get { lock (mSync) { return mRunning; } }
        }

        public bool Open(out string error)
        {
            lock (mSync)
            {
                error = "";
                if (mRunning) return true;
                try
                {
                    mListener = new TcpListener(IPAddress.Any, mPort);
                    mListener.Start();
                    mRunning = true;
                    mAcceptThread = new Thread(new ThreadStart(AcceptLoop));
                    mAcceptThread.IsBackground = true;
                    mAcceptThread.Start();
                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    StopNoLock();
                    return false;
                }
            }
        }

        void AcceptLoop()
        {
            while (mRunning)
            {
                try
                {
                    TcpClient c = mListener.AcceptTcpClient();
                    c.NoDelay = true;
                    c.SendTimeout = mTimeout;
                    c.ReceiveTimeout = mTimeout;
                    lock (mClients) { mClients.Add(c); }
                }
                catch (Exception)
                {
                    if (!mRunning) break;
                    Thread.Sleep(50);
                }
            }
        }

        public void Close()
        {
            lock (mSync) { StopNoLock(); }
        }

        void StopNoLock()
        {
            mRunning = false;
            try { if (mListener != null) mListener.Stop(); } catch (Exception) { }
            mListener = null;
            lock (mClients)
            {
                foreach (TcpClient c in mClients)
                {
                    try { c.Close(); } catch (Exception) { }
                }
                mClients.Clear();
            }
        }

        /// <summary>Sends to every connected client. Fails when nobody is connected.</summary>
        public bool Send(byte[] data, out string error)
        {
            error = "";
            if (!Open(out error)) return false;
            int sent = 0;
            lock (mClients)
            {
                for (int i = mClients.Count - 1; i >= 0; i--)
                {
                    try
                    {
                        NetworkStream ns = mClients[i].GetStream();
                        ns.Write(data, 0, data.Length);
                        ns.Flush();
                        sent++;
                    }
                    catch (Exception)
                    {
                        try { mClients[i].Close(); } catch (Exception) { }
                        mClients.RemoveAt(i);
                    }
                }
            }
            if (sent == 0)
            {
                error = "no client is connected to port " + mPort;
                return false;
            }
            return true;
        }

        /// <summary>Reads what has already arrived from any connected client; closed clients are removed.</summary>
        public bool Poll(out byte[] data)
        {
            data = null;
            lock (mClients)
            {
                for (int i = 0; i < mClients.Count; i++)
                {
                    TcpClient c = mClients[i];
                    try
                    {
                        int available = c.Available;
                        if (available > 0)
                        {
                            byte[] buf = new byte[available];
                            int n = c.GetStream().Read(buf, 0, buf.Length);
                            if (n > 0)
                            {
                                data = new byte[n];
                                Array.Copy(buf, data, n);
                                return true;
                            }
                        }
                        else if (c.Client.Poll(0, SelectMode.SelectRead) && c.Available == 0)
                        {
                            try { c.Close(); } catch (Exception) { }
                            mClients.RemoveAt(i);
                            i--;
                        }
                    }
                    catch (Exception)
                    {
                        try { c.Close(); } catch (Exception) { }
                        mClients.RemoveAt(i);
                        i--;
                    }
                }
            }
            return false;
        }

        /// <summary>Reads from the first connected client.</summary>
        public bool Receive(int timeoutMs, out byte[] data, out string error)
        {
            data = null;
            error = "";
            TcpClient first = null;
            lock (mClients)
            {
                if (mClients.Count > 0) first = mClients[0];
            }
            if (first == null)
            {
                error = "no client is connected";
                return false;
            }
            try
            {
                NetworkStream ns = first.GetStream();
                ns.ReadTimeout = (timeoutMs > 0) ? timeoutMs : 1;
                byte[] buf = new byte[4096];
                int n = ns.Read(buf, 0, buf.Length);
                if (n <= 0)
                {
                    error = "client closed the connection";
                    return false;
                }
                data = new byte[n];
                Array.Copy(buf, data, n);
                return true;
            }
            catch (IOException)
            {
                error = "timeout";
                return false;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        public void Dispose()
        {
            Close();
        }
    }

    // ------------------------------------------------------------------ UDP
    public class UdpTransport : ISendTransport
    {
        readonly object mSync = new object();
        readonly string mName;
        readonly string mHost;
        readonly int mPort;
        readonly int mTimeout;
        UdpClient mUdp;

        public UdpTransport(string name, string host, int port, int timeoutMs)
        {
            mName = name;
            mHost = host;
            mPort = port;
            mTimeout = (timeoutMs > 0) ? timeoutMs : 1000;
        }

        public string Name { get { return mName; } }

        public bool IsOpen
        {
            get { lock (mSync) { return mUdp != null; } }
        }

        public bool Open(out string error)
        {
            lock (mSync)
            {
                error = "";
                if (mUdp != null) return true;
                try
                {
                    mUdp = new UdpClient();
                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    mUdp = null;
                    return false;
                }
            }
        }

        public void Close()
        {
            lock (mSync)
            {
                try { if (mUdp != null) mUdp.Close(); } catch (Exception) { }
                mUdp = null;
            }
        }

        public bool Send(byte[] data, out string error)
        {
            lock (mSync)
            {
                error = "";
                if (!Open(out error)) return false;
                try
                {
                    mUdp.Send(data, data.Length, mHost, mPort);
                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public bool Poll(out byte[] data)
        {
            data = null;
            lock (mSync)
            {
                try
                {
                    if (mUdp == null || mUdp.Available <= 0) return false;
                    IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
                    data = mUdp.Receive(ref ep);
                    return data != null && data.Length > 0;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public bool Receive(int timeoutMs, out byte[] data, out string error)
        {
            data = null;
            error = "";
            lock (mSync)
            {
                if (mUdp == null)
                {
                    error = "not open";
                    return false;
                }
                try
                {
                    mUdp.Client.ReceiveTimeout = (timeoutMs > 0) ? timeoutMs : 1;
                    IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
                    data = mUdp.Receive(ref ep);
                    return true;
                }
                catch (SocketException)
                {
                    error = "timeout";
                    return false;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public void Dispose()
        {
            Close();
        }
    }

    // ------------------------------------------------------------------ Serial
    public class SerialTransport : ISendTransport
    {
        readonly object mSync = new object();
        readonly string mName;
        readonly string mPortName;
        readonly int mBaud;
        readonly Parity mParity;
        readonly int mDataBits;
        readonly StopBits mStopBits;
        readonly int mTimeout;
        SerialPort mPort;

        public SerialTransport(string name, string portName, int baud, Parity parity, int dataBits, StopBits stopBits, int timeoutMs)
        {
            mName = name;
            mPortName = portName;
            mBaud = baud;
            mParity = parity;
            mDataBits = dataBits;
            mStopBits = stopBits;
            mTimeout = (timeoutMs > 0) ? timeoutMs : 1000;
        }

        public string Name { get { return mName; } }

        public bool IsOpen
        {
            get { lock (mSync) { return mPort != null && mPort.IsOpen; } }
        }

        public bool Open(out string error)
        {
            lock (mSync)
            {
                error = "";
                if (mPort != null && mPort.IsOpen) return true;
                CloseNoLock();
                try
                {
                    SerialPort sp = new SerialPort(mPortName, mBaud, mParity, mDataBits, mStopBits);
                    sp.ReadTimeout = mTimeout;
                    sp.WriteTimeout = mTimeout;
                    sp.Open();
                    mPort = sp;
                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    CloseNoLock();
                    return false;
                }
            }
        }

        public void Close()
        {
            lock (mSync) { CloseNoLock(); }
        }

        void CloseNoLock()
        {
            try { if (mPort != null) mPort.Close(); } catch (Exception) { }
            mPort = null;
        }

        public bool Send(byte[] data, out string error)
        {
            lock (mSync)
            {
                error = "";
                if (!Open(out error)) return false;
                try
                {
                    mPort.Write(data, 0, data.Length);
                    return true;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    CloseNoLock();
                    return false;
                }
            }
        }

        public bool Poll(out byte[] data)
        {
            data = null;
            lock (mSync)
            {
                try
                {
                    if (mPort == null || !mPort.IsOpen) return false;
                    int count = mPort.BytesToRead;
                    if (count <= 0) return false;
                    byte[] buf = new byte[count];
                    int n = mPort.Read(buf, 0, count);
                    if (n <= 0) return false;
                    data = new byte[n];
                    Array.Copy(buf, data, n);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public bool Receive(int timeoutMs, out byte[] data, out string error)
        {
            data = null;
            error = "";
            lock (mSync)
            {
                if (mPort == null || !mPort.IsOpen)
                {
                    error = "not open";
                    return false;
                }
                try
                {
                    mPort.ReadTimeout = (timeoutMs > 0) ? timeoutMs : 1;
                    byte[] buf = new byte[1024];
                    int n = mPort.Read(buf, 0, buf.Length);
                    if (n <= 0) return false;
                    data = new byte[n];
                    Array.Copy(buf, data, n);
                    return true;
                }
                catch (TimeoutException)
                {
                    error = "timeout";
                    return false;
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                    return false;
                }
            }
        }

        public void Dispose()
        {
            Close();
        }
    }
}
