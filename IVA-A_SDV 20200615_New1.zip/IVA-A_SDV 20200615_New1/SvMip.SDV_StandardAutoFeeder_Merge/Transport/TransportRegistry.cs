﻿using System;
using System.Collections.Generic;
using System.IO.Ports;

namespace SvMip.SDV_StandardAutoFeeder_Merge
{
    /// <summary>
    /// One shared transport per SvConnection name. A transport is created (and opened) when it is first used and
    /// re-created when the settings of the connection changed. CloseAll is called when Auto stops.
    /// </summary>
    public static class TransportRegistry
    {
        class Entry
        {
            public string Signature;
            public ISendTransport Transport;
        }

        static readonly object mLock = new object();
        static readonly Dictionary<string, Entry> mEntries = new Dictionary<string, Entry>(StringComparer.OrdinalIgnoreCase);

        public static ISendTransport Get(SvConnection c, out string error)
        {
            error = "";
            if (c == null)
            {
                error = "no connection";
                return null;
            }
            lock (mLock)
            {
                string sig = Signature(c);
                Entry e;
                if (mEntries.TryGetValue(c.ConnName, out e))
                {
                    if (e.Signature == sig) return e.Transport;
                    try { e.Transport.Dispose(); } catch (Exception) { }
                    mEntries.Remove(c.ConnName);
                }
                ISendTransport t = Create(c, out error);
                if (t == null) return null;
                e = new Entry();
                e.Signature = sig;
                e.Transport = t;
                mEntries[c.ConnName] = e;
                return t;
            }
        }

        public static void CloseAll()
        {
            lock (mLock)
            {
                foreach (KeyValuePair<string, Entry> kv in mEntries)
                {
                    try { kv.Value.Transport.Dispose(); } catch (Exception) { }
                }
                mEntries.Clear();
            }
        }

        static string Signature(SvConnection c)
        {
            return string.Join("|", new string[]
            {
                c.ConnType.ToString(), c.Host, c.Port.ToString(), c.SerialPortName, c.BaudRate.ToString(),
                c.Parity.ToString(), c.DataBits.ToString(), c.StopBits.ToString(), c.UnitId.ToString(), c.TimeoutMs.ToString()
            });
        }

        static ISendTransport Create(SvConnection c, out string error)
        {
            error = "";
            int timeout = (c.TimeoutMs > 0) ? c.TimeoutMs : 1000;
            switch (c.ConnType)
            {
                case SvConnType.TcpClient:
                    return new TcpClientTransport(c.ConnName, c.Host, c.Port, timeout);
                case SvConnType.TcpServer:
                    return new TcpServerTransport(c.ConnName, c.Port, timeout);
                case SvConnType.Udp:
                    return new UdpTransport(c.ConnName, c.Host, c.Port, timeout);
                case SvConnType.ModbusTcp:
                    return new ModbusTcpTransport(c.ConnName, c.Host, (c.Port > 0) ? c.Port : 502, timeout);
                case SvConnType.Serial:
                    {
                        Parity parity = Parity.None;
                        if (c.Parity == SvParity.Odd) parity = Parity.Odd;
                        else if (c.Parity == SvParity.Even) parity = Parity.Even;
                        StopBits stop = (c.StopBits == 2) ? StopBits.Two : StopBits.One;
                        int data = (c.DataBits >= 5 && c.DataBits <= 8) ? c.DataBits : 8;
                        return new SerialTransport(c.ConnName, c.SerialPortName, (c.BaudRate > 0) ? c.BaudRate : 9600, parity, data, stop, timeout);
                    }
            }
            error = "connection '" + c.ConnName + "' (" + c.ConnType + ") is not a TCP / UDP / Serial / Modbus connection";
            return null;
        }
    }
}
