﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SvMip
{
    /// <summary>
    /// 이전에 저장된 CameraType을 Deserializing 하기위한 정의. 삭제하지 말것!!
    /// </summary>
    [Serializable]
    public enum CameraType
    {
        GigE_IMITech, /*GigE_ImagingSource,*/ GigE_Basler, GigE_PointGrey, WebCam, Image, GigE_Crevis, NIK
    }
}
