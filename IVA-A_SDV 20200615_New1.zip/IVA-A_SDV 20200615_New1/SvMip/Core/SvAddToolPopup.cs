﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace SvMip.Core
{
    /// <summary>
    /// Small pop-up used by "+ Add tool after ...": search box, categories on the left, tools with a one-line
    /// description on the right. Double click or Enter picks a tool, Esc or a click outside closes it.
    /// </summary>
    public class SvAddToolPopup : Form
    {
        const string AllTools = "All tools";
        const string RecentName = "Recently used";

        public static readonly string[] CategoryOrder = new string[] { "Acquire", "Locate", "Measure", "Image", "Logic", "Communication", "Other" };

        public static readonly Dictionary<string, string> CategoryOf = new Dictionary<string, string>
        {
            { "SvAcquisition", "Acquire" }, { "SvCameraCalibration", "Acquire" },
            { "SvTemplateMatch", "Locate" }, { "SvTemplateMatchOverpocket", "Locate" }, { "SvBlob", "Locate" }, { "SvEdge", "Locate" },
            { "SvFindLine", "Locate" }, { "SvFindParallelLine", "Locate" }, { "SvBarcode", "Locate" }, { "SvCaliper", "Locate" },
            { "SvFixture", "Locate" }, { "SvRegion", "Locate" },
            { "SvDistance2P", "Measure" }, { "SvDistance3P", "Measure" }, { "SvIntersectLine", "Measure" }, { "SvMakeLine", "Measure" },
            { "SvMakePoint", "Measure" }, { "SvMakePoint2", "Measure" }, { "SvMakeRectFromLine", "Measure" }, { "SvMakeRegions", "Measure" },
            { "SvMakeLattice", "Measure" }, { "SvMeasureSharpness", "Measure" }, { "SvSharpness", "Measure" }, { "SvHistogram", "Measure" },
            { "SvBlur", "Image" }, { "SvEqualizer", "Image" }, { "SvImageCalculate", "Image" }, { "SvImageConverter", "Image" },
            { "SvImageSave", "Image" }, { "SvMasking", "Image" }, { "SvMorphology", "Image" }, { "SvRotation", "Image" },
            { "SvSubImage", "Image" }, { "SvWarpping", "Image" }, { "SvWarppingPoint", "Image" },
            { "SvIf", "Logic" }, { "SvFor", "Logic" }, { "SvJudgement", "Logic" }, { "SvJudgementOverpocket", "Logic" }, { "SvJudgment", "Logic" },
            { "SvAlign", "Logic" }, { "SvHandEye", "Communication" }, { "SvMaster", "Communication" }, { "SvSplit", "Logic" }, { "SvDataAnalysis", "Logic" }, { "SvResultAnalysis", "Logic" }, { "SvToolBlock", "Logic" },
            { "SvConnection", "Communication" }, { "SvTrigger", "Communication" }, { "SvSend", "Communication" }, { "SvDataLog", "Communication" }
        };

        public static readonly Dictionary<string, string> DescriptionOf = new Dictionary<string, string>
        {
            { "SvAcquisition", "Grab or load the image" },
            { "SvCameraCalibration", "Calibrate camera and robot coordinates" },
            { "SvTemplateMatch", "Find a taught pattern in the image" },
            { "SvTemplateMatchOverpocket", "Pattern match for over-pocket checks" },
            { "SvBlob", "Find and measure bright or dark areas" },
            { "SvEdge", "Detect edges" },
            { "SvFindLine", "Find a straight line" },
            { "SvFindParallelLine", "Find two parallel lines" },
            { "SvBarcode", "Read a barcode or QR code" },
            { "SvCaliper", "Measure along a line with a caliper" },
            { "SvFixture", "Move other tools with the part" },
            { "SvRegion", "Define a search region" },
            { "SvDistance2P", "Distance between two points" },
            { "SvDistance3P", "Distance using three points" },
            { "SvIntersectLine", "Crossing point of two lines" },
            { "SvMakeLine", "Build a line from points" },
            { "SvMakePoint", "Build a point from numbers or results" },
            { "SvMakePoint2", "Build a point (second version)" },
            { "SvMakeRectFromLine", "Build a rectangle from a line" },
            { "SvMakeRegions", "Build several regions" },
            { "SvMakeLattice", "Build a grid of points" },
            { "SvMeasureSharpness", "Measure the focus of the image" },
            { "SvSharpness", "Sharpness value of a region" },
            { "SvHistogram", "Brightness histogram of a region" },
            { "SvBlur", "Smooth the image" },
            { "SvEqualizer", "Even out the brightness" },
            { "SvImageCalculate", "Add, subtract or combine images" },
            { "SvImageConverter", "Change colour or bit depth" },
            { "SvImageSave", "Save the image to disk" },
            { "SvMasking", "Hide parts of the image" },
            { "SvMorphology", "Grow or shrink shapes" },
            { "SvRotation", "Rotate the image" },
            { "SvSubImage", "Cut out part of the image" },
            { "SvWarpping", "Straighten the image" },
            { "SvWarppingPoint", "Straighten with chosen points" },
            { "SvIf", "Run tools only when a condition is true" },
            { "SvFor", "Repeat tools several times" },
            { "SvJudgement", "OK / NG decision from results" },
            { "SvJudgementOverpocket", "OK / NG decision for over-pocket" },
            { "SvAlign", "Calculate the offset to send" },
            { "SvHandEye", "Calibrate (hand-eye) from points the robot sends" },
            { "SvMaster", "Get the master (load position) when the robot asks" },
            { "SvSplit", "Split a text (e.g. the robot message) into parts" },
            { "SvDataAnalysis", "Statistics of measured values" },
            { "SvResultAnalysis", "Summarize the results" },
            { "SvToolBlock", "Group of tools" },
            { "SvConnection", "Open a PLC / TCP / Modbus connection" },
            { "SvTrigger", "Wait for a start signal" },
            { "SvSend", "Send values and the reply" },
            { "SvDataLog", "Write results to a data log" }
        };

        // kept for the session only
        static readonly List<string> Recent = new List<string>();

        readonly List<Type> allTypes = new List<Type>();
        readonly TextBox txtSearch = new TextBox();
        readonly ListBox lstCat = new ListBox();
        readonly ListView lstTool = new ListView();
        bool closing;

        /// <summary>The tool type the user picked (null when cancelled).</summary>
        public Type SelectedType { get; private set; }

        public SvAddToolPopup(IEnumerable<SvToolBase> tools, string afterName)
        {
            foreach (SvToolBase t in tools)
            {
                Type type = t.GetType();
                if (!allTypes.Contains(type)) allTypes.Add(type);
            }
            allTypes.Sort(delegate(Type a, Type b) { return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase); });

            Text = string.IsNullOrEmpty(afterName) ? "Add tool" : "Add tool after " + afterName;
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            KeyPreview = true;
            ClientSize = new Size(580, 360);

            txtSearch.SetBounds(8, 8, 564, 24);
            txtSearch.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtSearch.HandleCreated += delegate { try { SendMessage(txtSearch.Handle, 0x1501, (IntPtr)1, "Search all tools"); } catch (Exception) { } };
            txtSearch.TextChanged += delegate { Fill(); };
            txtSearch.KeyDown += SearchKeyDown;

            lstCat.SetBounds(8, 40, 150, 312);
            lstCat.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lstCat.IntegralHeight = false;
            lstCat.SelectedIndexChanged += delegate { if (txtSearch.Text.Trim().Length == 0) Fill(); };

            lstTool.SetBounds(166, 40, 406, 312);
            lstTool.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lstTool.View = View.Details;
            lstTool.FullRowSelect = true;
            lstTool.MultiSelect = false;
            lstTool.HeaderStyle = ColumnHeaderStyle.None;
            lstTool.Columns.Add("Tool", 150);
            lstTool.Columns.Add("What it does", 230);
            lstTool.DoubleClick += delegate { Pick(); };
            lstTool.KeyDown += delegate(object s, KeyEventArgs e) { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; Pick(); } };

            Controls.Add(txtSearch);
            Controls.Add(lstCat);
            Controls.Add(lstTool);

            if (Recent.Count > 0) lstCat.Items.Add(RecentName);
            foreach (string c in CategoryOrder)
                if (allTypes.Any(t => CategoryName(t) == c)) lstCat.Items.Add(c);
            lstCat.Items.Add(AllTools);
            lstCat.SelectedIndex = Recent.Count > 0 ? 0 : (lstCat.Items.Count > 1 ? 0 : 0);
            Fill();

            Deactivate += delegate { if (!closing) { closing = true; DialogResult = DialogResult.Cancel; Close(); } };
            KeyDown += delegate(object s, KeyEventArgs e) { if (e.KeyCode == Keys.Escape) { closing = true; DialogResult = DialogResult.Cancel; Close(); } };
            Shown += delegate { txtSearch.Focus(); };
        }

        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);

        static string CategoryName(Type t)
        {
            string c;
            return CategoryOf.TryGetValue(t.Name, out c) ? c : "Other";
        }

        static string DescriptionName(Type t)
        {
            string d;
            return DescriptionOf.TryGetValue(t.Name, out d) ? d : "";
        }

        void Fill()
        {
            string text = txtSearch.Text.Trim();
            string cat = lstCat.SelectedItem as string;
            IEnumerable<Type> list;
            if (text.Length > 0)
            {
                list = allTypes.Where(t => t.Name.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0
                                        || DescriptionName(t).IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0);
            }
            else if (cat == RecentName)
            {
                List<Type> recent = new List<Type>();
                foreach (string name in Recent)
                {
                    Type t = allTypes.FirstOrDefault(x => x.Name == name);
                    if (t != null) recent.Add(t);
                }
                list = recent;
            }
            else if (cat == null || cat == AllTools)
                list = allTypes;
            else
                list = allTypes.Where(t => CategoryName(t) == cat);

            lstTool.BeginUpdate();
            lstTool.Items.Clear();
            foreach (Type t in list)
            {
                ListViewItem item = new ListViewItem(t.Name);
                item.SubItems.Add(DescriptionName(t));
                item.Tag = t;
                lstTool.Items.Add(item);
            }
            if (lstTool.Items.Count > 0) lstTool.Items[0].Selected = true;
            lstTool.EndUpdate();
        }

        void SearchKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                Pick();
            }
            else if (e.KeyCode == Keys.Down && lstTool.Items.Count > 0)
            {
                e.SuppressKeyPress = true;
                lstTool.Focus();
            }
        }

        void Pick()
        {
            if (lstTool.SelectedItems.Count == 0) return;
            Type type = lstTool.SelectedItems[0].Tag as Type;
            if (type == null) return;
            SelectedType = type;
            Recent.Remove(type.Name);
            Recent.Insert(0, type.Name);
            while (Recent.Count > 5) Recent.RemoveAt(Recent.Count - 1);
            closing = true;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
