﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;
using SvMip.Edit;

namespace SvMip.Core
{
    partial class SvToolBlockTree
    {        
        void InitToolList()
        {            
            tools = new Dictionary<SvToolBase, SvToolEditForm>();

            //*****************************************************************************
            //        #        #######      ######   
            //       ###       ##    ##   ##
            //      ## ##      ##    ##  ##
            //     #######     #######   ##            순으로 추가할것!
            //    ##     ##    ##    ##  ##
            //   ##       ##   ##    ##   ##
            //  ##         ##  #######      ######
            //*****************************************************************************

            tools.Add(new SvAcquisition(), new SvToolEditForm(new SvAcqisitionEdit()));
            tools.Add(new SvBarcode(), new SvToolEditForm(new SvBarcodeEdit()));
            tools.Add(new SvBlob(), new SvToolEditForm(new SvBlobEdit()));
            tools.Add(new SvBlur(), new SvToolEditForm(new SvBlurEdit()));
            tools.Add(new SvAlign(), new SvToolEditForm(new SvAlignEdit()));
            tools.Add(new SvConnection(), new SvToolEditForm(new SvConnectionEdit()));
            tools.Add(new SvSend(), new SvToolEditForm(new SvSendEdit()));
            //tools.Add(new SvCaliper(), new SvToolEditForm(new SvCaliperEdit())); //디버깅중_05.10_hong
            tools.Add(new SvCameraCalibration(), new SvToolEditForm(new SvCameraCalibrationEdit())); //디버깅중_05.10_hong
            tools.Add(new SvDataAnalysis(), new SvToolEditForm(new SvDataAnalysisEdit()));
            tools.Add(new SvDataLog(), new SvToolEditForm(new SvDataLogEdit()));
            tools.Add(new SvDistance2P(), new SvToolEditForm(new SvDistance2PEdit())); 
            tools.Add(new SvDistance3P(), new SvToolEditForm(new SvDistance3PEdit())); 
            tools.Add(new SvEdge(), new SvToolEditForm(new SvEdgeEdit()));
            tools.Add(new SvEqualizer(), new SvToolEditForm(new SvEqualizerEdit()));
            tools.Add(new SvFindLine(), new SvToolEditForm(new SvFindLineEdit()));
            tools.Add(new SvFindParallelLine(), new SvToolEditForm(new SvFindParallelLineEdit()));
            tools.Add(new SvFixture(), new SvToolEditForm(new SvFixtureEdit()));
            tools.Add(new SvHistogram(), new SvToolEditForm(new SvHistogramEdit()));
            tools.Add(new SvImageCalculate(), new SvToolEditForm(new SvImageCalculateEdit()));
            tools.Add(new SvImageConverter(), new SvToolEditForm(new SvImageConverterEdit()));
            tools.Add(new SvImageSave(), new SvToolEditForm(new SvImageSaveEdit()));
            tools.Add(new SvIntersectLine(), new SvToolEditForm(new SvIntersectLineEdit()));
            tools.Add(new SvJudgement(), new SvToolEditForm(new SvJudgementEdit()));
            //20200525 HNB
            tools.Add(new SvJudgementOverpocket(), new SvToolEditForm(new SvJudgementOverpocketEdit()));
            tools.Add(new SvMakeLattice(), new SvToolEditForm(new SvMakeLatticeEdit()));
            tools.Add(new SvMakeLine(), new SvToolEditForm(new SvMakeLineEdit()));
            tools.Add(new SvMakePoint(), new SvToolEditForm(new SvMakePointEdit()));
            //tools.Add(new SvMakePoint2(), new SvToolEditForm(new SvMakePoint2Edit()));      
            tools.Add(new SvMakeRectFromLine(), new SvToolEditForm(new SvMakeRectFromLineEdit()));
            tools.Add(new SvMakeRegions(), new SvToolEditForm(new SvMakeRegionsEdit())); 
            tools.Add(new SvMasking(), new SvToolEditForm(new SvMaskingEdit()));
            tools.Add(new SvMeasureSharpness(), new SvToolEditForm(new SvMeasureSharpnessEdit()));
            tools.Add(new SvMorphology(), new SvToolEditForm(new SvMorphologyEdit()));
            tools.Add(new SvRegion(), new SvToolEditForm(new SvRegionEdit()));
            tools.Add(new SvResultAnalysis(), new SvToolEditForm(new SvResultAnalysisEdit()));
            tools.Add(new SvRotation(), new SvToolEditForm(new SvRotationEdit()));
            tools.Add(new SvSubImage(), new SvToolEditForm(new SvSubImageEdit()));
            tools.Add(new SvSharpness(), new SvToolEditForm(new SvSharpnessEdit())); 
            tools.Add(new SvTemplateMatch(), new SvToolEditForm(new SvTemplateMatchEdit()));
            //20200525 HNB
            tools.Add(new SvTemplateMatchOverpocket(), new SvToolEditForm(new SvTemplateMatchOverpocketEdit()));

            tools.Add(new SvToolBlock(), new SvToolEditForm(new SvToolBlockEdit(svToolTreeView)));
            tools.Add(new SvTrigger(), new SvToolEditForm(new SvTriggerEdit()));
            tools.Add(new SvIf(), new SvToolEditForm(new SvIfEdit()));
            tools.Add(new SvHandEye(), new SvToolEditForm(new SvHandEyeEdit()));
            tools.Add(new SvMaster(), new SvToolEditForm(new SvMasterEdit()));
            tools.Add(new SvSplit(), new SvToolEditForm(new SvSplitEdit()));
            tools.Add(new SvFor(), new SvToolEditForm(new SvForEdit()));
            tools.Add(new SvWarpping(), new SvToolEditForm(new SvWarppingEdit()));
            tools.Add(new SvWarppingPoint(), new SvToolEditForm(new SvWarppingPointEdit()));
        }        
    }
}
