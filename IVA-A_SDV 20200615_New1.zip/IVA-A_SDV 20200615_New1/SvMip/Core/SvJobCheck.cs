﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SvMip
{
    public enum SvIssueLevel { Warning = 0, Error = 1 }

    /// <summary>One finding of the job check: level, tool, message and a hint how to fix it.</summary>
    public class SvJobIssue
    {
        public SvIssueLevel Level;
        public string ToolName;   // "" when the finding does not belong to one tool
        public string Message;    // without the leading "Tool: "
        public string Hint;       // may be empty
        public string FullText;   // the original text of SvJobValidator
    }

    /// <summary>
    /// Wraps SvJobValidator: the same checks, but every finding gets a level (Error / Warning), the tool it belongs to
    /// and a hint. SvJobValidator itself is not changed. Errors are the findings that make the job fail at run time
    /// (missing connection, unknown source, overlapping address ...); warnings are the ones that only change behaviour.
    /// </summary>
    public static class SvJobCheck
    {
        static readonly Regex ErrorRegex = new Regex(
            @"not found|must |cannot|needs the form|unknown|has no output|is used by|is written by|but only|there is no field|need a|is not a",
            RegexOptions.IgnoreCase);

        class HintRule
        {
            public Regex Pattern;
            public string Hint;
            public HintRule(string pattern, string hint) { Pattern = new Regex(pattern, RegexOptions.IgnoreCase); Hint = hint; }
        }

        static readonly HintRule[] HintRules = new HintRule[]
        {
            new HintRule(@"connection '.*' not found|trigger connection '.*' not found", "Add an SvConnection tool with exactly that name, or pick an existing connection name."),
            new HintRule(@"tool '.*' not found", "Check the tool name in the source (Tool.Output); it must match a tool of this job."),
            new HintRule(@"has no output", "Open the tool's Output tab and use one of the listed outputs."),
            new HintRule(@"needs the form Tool\.Output", "Write the source as Tool.Output, for example SvTemplateMatch1.TranslateX."),
            new HintRule(@"unknown special source", "Valid specials: @judge, @vision, @cellid, @recipe, @job, @time, @request, @align[n].x/y/t."),
            new HintRule(@"unknown placeholder", "Use request, judge, time, cellid, a0x, a0y, a0t, a1x ..."),
            new HintRule(@"template uses", "Add a field with that name to the channel, or remove the placeholder from the template."),
            new HintRule(@"is used by|is written by", "Change the start index / address of one of the two channels so they do not overlap."),
            new HintRule(@"Registers channels need a ModbusTcp", "Choose a ModbusTcp connection, or change the channel kind to Text."),
            new HintRule(@"Text channels cannot use a ModbusTcp", "Choose a TcpServer / TcpClient / Udp / Serial connection, or change the channel kind to Registers."),
            new HintRule(@"must be TcpServer", "Use a TcpServer, TcpClient, Udp or Serial connection for the trigger."),
            new HintRule(@"No SvTrigger", "Add an SvTrigger if this job should run by itself (self-contained job)."),
            new HintRule(@"More than one SvTrigger|More than one SvAlign", "Delete the extra tool; only the first one is used."),
            new HintRule(@"No SvAcquisition", "Add an SvAcquisition so the job has an image to run on."),
            new HintRule(@"controls \d+ tools|repeats \d+ tools", "Lower the body count, or add the missing tools after it.")
        };

        /// <summary>Runs all checks of the job. Errors first, then warnings, each in the order of SvJobValidator.</summary>
        public static List<SvJobIssue> Run(SvJob job)
        {
            List<SvJobIssue> errors = new List<SvJobIssue>();
            List<SvJobIssue> warnings = new List<SvJobIssue>();
            List<string> texts = SvJobValidator.Validate(job);
            foreach (string text in texts)
            {
                SvJobIssue issue = Parse(text);
                if (issue.Level == SvIssueLevel.Error) errors.Add(issue); else warnings.Add(issue);
            }
            errors.AddRange(warnings);
            return errors;
        }

        public static int Count(List<SvJobIssue> issues, SvIssueLevel level)
        {
            int n = 0;
            if (issues != null)
                foreach (SvJobIssue i in issues) if (i.Level == level) n++;
            return n;
        }

        static SvJobIssue Parse(string text)
        {
            SvJobIssue issue = new SvJobIssue();
            issue.FullText = text ?? "";
            issue.ToolName = "";
            issue.Message = issue.FullText;
            issue.Level = ErrorRegex.IsMatch(issue.FullText) ? SvIssueLevel.Error : SvIssueLevel.Warning;

            // "SvSend1 / Channel / Field: message" or "SvAlign1 point 1: message" -> tool = first word of the part before ": "
            int colon = issue.FullText.IndexOf(": ", StringComparison.Ordinal);
            if (colon > 0 && char.IsUpper(issue.FullText[0]))
            {
                string head = issue.FullText.Substring(0, colon);
                int slash = head.IndexOf(" / ", StringComparison.Ordinal);
                string tool = (slash >= 0) ? head.Substring(0, slash) : head;
                int space = tool.IndexOf(' ');
                if (space > 0) tool = tool.Substring(0, space);
                issue.ToolName = tool;
                issue.Message = (slash >= 0 ? head.Substring(slash + 3) + ": " : "") + issue.FullText.Substring(colon + 2);
            }

            issue.Hint = "";
            foreach (HintRule r in HintRules)
            {
                if (r.Pattern.IsMatch(issue.FullText)) { issue.Hint = r.Hint; break; }
            }
            return issue;
        }
    }
}
