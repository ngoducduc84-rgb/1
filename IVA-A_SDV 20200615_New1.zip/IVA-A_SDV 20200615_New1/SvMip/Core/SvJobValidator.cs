﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SvMip
{
    /// <summary>
    /// Checks the self-contained job setup (SvTrigger / SvConnection / SvAlign / SvSend).
    /// Returns human readable warnings; an empty list means nothing was found.
    /// Used when a job is saved, so that Auto does not start with a broken setup.
    /// </summary>
    public static class SvJobValidator
    {
        static readonly Regex SpecialRegex = new Regex(@"^@(judge|vision|cellid|recipe|job|time|cmd|command|v\d+|request(\[\d+\])?|align\[\d+\]\.(x|y|t))$", RegexOptions.IgnoreCase);

        public static List<string> Validate(SvJob job)
        {
            List<string> w = new List<string>();
            if (job == null) return w;

            List<SvToolBase> tools = new List<SvToolBase>();
            Collect(job, tools, 0);

            List<SvTrigger> triggers = new List<SvTrigger>();
            List<SvConnection> conns = new List<SvConnection>();
            List<SvAlign> aligns = new List<SvAlign>();
            List<SvSend> sends = new List<SvSend>();
            int acquisitions = 0;
            foreach (SvToolBase t in tools)
            {
                if (t is SvTrigger) triggers.Add((SvTrigger)t);
                else if (t is SvConnection) conns.Add((SvConnection)t);
                else if (t is SvAlign) aligns.Add((SvAlign)t);
                else if (t is SvSend) sends.Add((SvSend)t);
                else if (t is SvAcquisition) acquisitions++;
            }

            CheckFlow(job, tools, w, 0);

            bool selfContained = triggers.Count + conns.Count + aligns.Count + sends.Count > 0;
            if (!selfContained) return w;

            if (triggers.Count == 0) w.Add("No SvTrigger in the job: the process keeps the thread type of the system settings (AutoThread_Direct is not used).");
            if (triggers.Count > 1) w.Add("More than one SvTrigger in the job: only the first one is used.");
            if (aligns.Count > 1) w.Add("More than one SvAlign in the job: only the first one is used.");
            if (acquisitions == 0) w.Add("No SvAcquisition in the job: there is no image to run on or to show in Auto.");

            foreach (SvTrigger t in triggers)
            {
                AddIf(w, t.ToString(), t.Validate());
                if (t.TriggerMode == SvTriggerMode.Tcp) CheckTcpTrigger(t, conns, w);
            }
            foreach (SvConnection c in conns) AddIf(w, c.ToString(), c.Validate());
            foreach (SvAlign a in aligns)
            {
                AddIf(w, a.ToString(), a.Validate());
                for (int i = 0; i < a.Points.Count; i++)
                    CheckSource(tools, a.Points[i].Source, a.ToString() + " point " + (i + 1), w);
            }

            Dictionary<int, string> positionUsed = new Dictionary<int, string>();
            Dictionary<int, string> valueUsed = new Dictionary<int, string>();
            Dictionary<string, string> registerUsed = new Dictionary<string, string>();
            foreach (SvSend s in sends)
            {
                AddIf(w, s.ToString(), s.Validate());
                foreach (SvSendChannel ch in s.Channels)
                {
                    if (!ch.Enabled) continue;
                    string where = s.ToString() + " / " + ch.Name;
                    foreach (SvSendField f in ch.Fields)
                        CheckSource(tools, f.Source, where + " / " + f.Name, w);

                    if (ch.Kind == SvSendKind.Position && ch.StartIndex >= 0)
                    {
                        int groups = ch.Fields.Count / 3;
                        for (int g = 0; g < groups; g++)
                            CheckOverlap(positionUsed, ch.StartIndex + g, where, "position index", w);
                    }
                    else if (ch.Kind == SvSendKind.Values && ch.StartIndex >= 0)
                    {
                        foreach (SvSendField f in ch.Fields)
                            CheckOverlap(valueUsed, ch.StartIndex + f.Address, where, "value address", w);
                    }
                    CheckStreamChannel(ch, conns, where, registerUsed, w);
                }
                SvSendChannel quick = s.QuickChannel();
                if (quick != null) CheckStreamChannel(quick, conns, s.ToString() + " / Message", registerUsed, w);
            }
            return w;
        }

        /// <summary>SvIf / SvFor: the controlled tools must exist in the same job; the SvIf source must be valid.</summary>
        static void CheckFlow(SvJob job, List<SvToolBase> allTools, List<string> w, int depth)
        {
            if (job == null || depth > 8) return;
            List<SvToolBase> list = job.ToolList;
            for (int i = 0; i < list.Count; i++)
            {
                SvIf svIf = list[i] as SvIf;
                SvFor svFor = list[i] as SvFor;
                if (svIf != null)
                {
                    AddIf(w, svIf.ToString(), svIf.Validate());
                    if (!SvLoose.IsLinked(svIf, "Value")) CheckSource(allTools, svIf.Source, svIf.ToString(), w);
                    if (svIf.BodyCount > list.Count - i - 1)
                        w.Add(string.Format("{0}: controls {1} tools but only {2} follow it in the job", svIf, svIf.BodyCount, list.Count - i - 1));
                }
                if (svFor != null)
                {
                    AddIf(w, svFor.ToString(), svFor.Validate());
                    if (svFor.BodyCount > list.Count - i - 1)
                        w.Add(string.Format("{0}: repeats {1} tools but only {2} follow it in the job", svFor, svFor.BodyCount, list.Count - i - 1));
                }
                SvToolBlock block = list[i] as SvToolBlock;
                if (block != null) CheckFlow(block.ToolJob, allTools, w, depth + 1);
            }
        }

        /// <summary>Text / Registers channels: the connection must exist and match, template names must be fields, registers must not overlap.</summary>
        static void CheckStreamChannel(SvSendChannel ch, List<SvConnection> conns, string where, Dictionary<string, string> registerUsed, List<string> w)
        {
            if (ch.Kind != SvSendKind.Text && ch.Kind != SvSendKind.Registers) return;

            SvConnection conn = null;
            foreach (SvConnection c in conns)
            {
                if (string.Equals(c.ConnName, ch.Connection, StringComparison.OrdinalIgnoreCase)) { conn = c; break; }
            }
            if (conn == null)
                w.Add(string.Format("{0}: connection '{1}' not found (add an SvConnection with that name)", where, ch.Connection));
            else if (!SvConnection.IsStreamType(conn.ConnType))
                w.Add(string.Format("{0}: connection '{1}' is not a TCP / UDP / Serial / Modbus connection", where, conn.ConnName));
            else if (ch.Kind == SvSendKind.Registers && conn.ConnType != SvConnType.ModbusTcp)
                w.Add(string.Format("{0}: Registers channels need a ModbusTcp connection", where));
            else if (ch.Kind == SvSendKind.Text && conn.ConnType == SvConnType.ModbusTcp)
                w.Add(string.Format("{0}: Text channels cannot use a ModbusTcp connection", where));

            if (ch.Kind == SvSendKind.Text && !string.IsNullOrEmpty(ch.Template))
            {
                string t = ch.Template.Replace("{{", "").Replace("}}", "");
                foreach (Match m in Regex.Matches(t, @"\{([^{}:]+)(?::[^{}]*)?\}"))
                {
                    string name = m.Groups[1].Value.Trim();
                    bool found = false;
                    foreach (SvSendField f in ch.Fields)
                    {
                        if (string.Equals(f.Name, name, StringComparison.OrdinalIgnoreCase)) { found = true; break; }
                    }
                    if (!found && Regex.IsMatch(name, @"^v\d+$", RegexOptions.IgnoreCase)) found = true; // {v1}.. = the values of the SvSend
                    if (!found)
                        w.Add(string.Format("{0}: the template uses '{{{1}}}' but there is no field with that name", where, name));
                }
            }

            if (ch.Kind == SvSendKind.Registers && conn != null && ch.StartIndex >= 0)
            {
                foreach (SvSendField f in ch.Fields)
                {
                    int width = (f.ValueType == SvSendValueType.Int16) ? 1 : 2;
                    for (int k = 0; k < width; k++)
                    {
                        int reg = ch.StartIndex + f.Address + k;
                        string key = conn.ConnName.ToLowerInvariant() + ":" + reg;
                        string other;
                        if (registerUsed.TryGetValue(key, out other))
                            w.Add(string.Format("register {0} of '{1}' is written by '{2}' and by '{3}'", reg, conn.ConnName, other, where));
                        else
                            registerUsed[key] = where;
                    }
                }
            }
        }

        /// <summary>Tcp trigger: the connection must exist and be a message connection; reply placeholders must be known.</summary>
        static void CheckTcpTrigger(SvTrigger t, List<SvConnection> conns, List<string> w)
        {
            string who = t.ToString();
            SvConnection conn = null;
            foreach (SvConnection c in conns)
            {
                if (string.Equals(c.ConnName, t.ConnectionName, StringComparison.OrdinalIgnoreCase)) { conn = c; break; }
            }
            if (conn == null)
                w.Add(string.Format("{0}: trigger connection '{1}' not found (add an SvConnection with that name)", who, t.ConnectionName));
            else if (!SvConnection.IsStreamType(conn.ConnType) || conn.ConnType == SvConnType.ModbusTcp)
                w.Add(string.Format("{0}: trigger connection '{1}' must be TcpServer, TcpClient, Udp or Serial", who, conn.ConnName));

            CheckReplyTemplate(who + " ReplyOk", t.ReplyOk, w);
            CheckReplyTemplate(who + " ReplyNg", t.ReplyNg, w);
        }

        static void CheckReplyTemplate(string where, string template, List<string> w)
        {
            if (string.IsNullOrEmpty(template)) return;
            string t = template.Replace("{{", "").Replace("}}", "");
            foreach (Match m in Regex.Matches(t, @"\{([^{}:]+)(?::[^{}]*)?\}"))
            {
                string name = m.Groups[1].Value.Trim();
                if (!Regex.IsMatch(name, @"^(request|judge|time|cellid|a\d+[xyt])$", RegexOptions.IgnoreCase))
                    w.Add(string.Format("{0}: unknown placeholder '{{{1}}}' (use request, judge, time, cellid, a0x, a0y, a0t, a1x ...)", where, name));
            }
        }

        static void AddIf(List<string> w, string who, string problem)
        {
            if (!string.IsNullOrEmpty(problem)) w.Add(who + ": " + problem);
        }

        static void CheckOverlap(Dictionary<int, string> used, int address, string who, string what, List<string> w)
        {
            string other;
            if (used.TryGetValue(address, out other))
                w.Add(string.Format("{0} {1} is used by '{2}' and by '{3}'", what, address, other, who));
            else
                used[address] = who;
        }

        static void CheckSource(List<SvToolBase> tools, string src, string where, List<string> w)
        {
            if (string.IsNullOrEmpty(src)) return; // reported by the tool itself
            src = src.Trim();
            if (src[0] == '@')
            {
                if (!SpecialRegex.IsMatch(src)) w.Add(string.Format("{0}: unknown special source '{1}'", where, src));
                return;
            }
            string[] parts = src.Split('.');
            if (parts.Length < 2)
            {
                w.Add(string.Format("{0}: source '{1}' needs the form Tool.Output", where, src));
                return;
            }
            SvToolBase tool = null;
            foreach (SvToolBase t in tools)
            {
                if (string.Equals(t.ToString(), parts[0].Trim(), StringComparison.OrdinalIgnoreCase)) { tool = t; break; }
            }
            if (tool == null)
            {
                w.Add(string.Format("{0}: tool '{1}' not found", where, parts[0].Trim()));
                return;
            }
            string outName = parts[1];
            int b = outName.IndexOf('[');
            if (b >= 0) outName = outName.Substring(0, b);
            outName = outName.Trim();
            bool found = false;
            foreach (string key in tool.outParams.Keys)
            {
                if (string.Equals(key, outName, StringComparison.OrdinalIgnoreCase)) { found = true; break; }
            }
            if (!found) w.Add(string.Format("{0}: tool '{1}' has no output '{2}'", where, parts[0].Trim(), outName));
        }

        static void Collect(SvJob job, List<SvToolBase> acc, int depth)
        {
            if (job == null || depth > 8) return;
            foreach (SvToolBase t in job.ToolList)
            {
                acc.Add(t);
                SvToolBlock block = t as SvToolBlock;
                if (block != null) Collect(block.ToolJob, acc, depth + 1);
            }
        }
    }
}
