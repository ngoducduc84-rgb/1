﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using OpenCvSharp.CPlusPlus;

namespace SvMip
{
    /// <summary>
    /// Resolves "source" strings to values of tool outputs.
    ///
    ///   ToolName.OutputName[.Member][[index]]...
    ///     MakePoint1.OutPoint            a point
    ///     MakePoint1.OutPoint.X          a number
    ///     Blob1.Blobs[2].Centroid.Y      list index and members
    ///
    /// ToolName is the name shown in the tool tree (case-insensitive). Members are public properties or fields
    /// (case-insensitive). On an SvPoint: x, y, z (raw Point3d values) and t (z converted to degrees) are understood.
    /// Used by SvIf and by the AutoThread_Direct (SvAlign / SvSend).
    /// </summary>
    public static class SvPathResolver
    {
        public static SvToolBase FindTool(IList<SvToolBase> tools, string name)
        {
            foreach (SvToolBase t in tools)
            {
                if (string.Equals(t.ToString(), name, StringComparison.OrdinalIgnoreCase)) return t;
            }
            return null;
        }

        public static bool TryGetToolValue(IList<SvToolBase> tools, string path, out object value, out string error)
        {
            value = null;
            error = "";
            if (string.IsNullOrEmpty(path))
            {
                error = "empty source";
                return false;
            }
            if (path.TrimStart().StartsWith("@")) return SvRuntime.TryGetSpecial(path, out value, out error); // @cmd, @request[n]
            string[] parts = path.Split('.');
            if (parts.Length < 2)
            {
                error = "source '" + path + "' needs the form Tool.Output";
                return false;
            }
            SvToolBase tool = FindTool(tools, parts[0].Trim());
            if (tool == null)
            {
                error = "tool '" + parts[0].Trim() + "' not found";
                return false;
            }

            string outName;
            List<int> indexes;
            if (!ParseSegment(parts[1], out outName, out indexes))
            {
                error = "bad segment '" + parts[1] + "'";
                return false;
            }

            object cur = null;
            bool found = false;
            foreach (KeyValuePair<string, object> kv in tool.outParams)
            {
                if (string.Equals(kv.Key, outName, StringComparison.OrdinalIgnoreCase))
                {
                    cur = kv.Value;
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                error = "tool '" + parts[0].Trim() + "' has no output '" + outName + "'";
                return false;
            }
            if (!ApplyIndexes(ref cur, indexes, out error)) return false;

            for (int i = 2; i < parts.Length; i++)
            {
                string member;
                List<int> idx;
                if (!ParseSegment(parts[i], out member, out idx))
                {
                    error = "bad segment '" + parts[i] + "'";
                    return false;
                }
                if (!TryGetMember(cur, member, out cur))
                {
                    error = "member '" + member + "' not found";
                    return false;
                }
                if (!ApplyIndexes(ref cur, idx, out error)) return false;
            }
            if (cur == null)
            {
                error = "value of '" + path + "' is empty (tool not run or failed)";
                return false;
            }
            value = cur;
            return true;
        }

        static bool ParseSegment(string seg, out string name, out List<int> indexes)
        {
            indexes = new List<int>();
            seg = seg.Trim();
            int b = seg.IndexOf('[');
            if (b < 0)
            {
                name = seg;
                return name.Length > 0;
            }
            name = seg.Substring(0, b).Trim();
            string rest = seg.Substring(b);
            while (rest.Length > 0)
            {
                if (rest[0] != '[') return false;
                int e = rest.IndexOf(']');
                if (e < 0) return false;
                int n;
                if (!int.TryParse(rest.Substring(1, e - 1), out n)) return false;
                indexes.Add(n);
                rest = rest.Substring(e + 1);
            }
            return name.Length > 0;
        }

        static bool ApplyIndexes(ref object cur, List<int> indexes, out string error)
        {
            error = "";
            foreach (int n in indexes)
            {
                IList list = cur as IList;
                if (list == null)
                {
                    error = "value is not a list, cannot use index [" + n + "]";
                    return false;
                }
                if (n < 0 || n >= list.Count)
                {
                    error = "index [" + n + "] is outside the list (count " + list.Count + ")";
                    return false;
                }
                cur = list[n];
            }
            return true;
        }

        static bool TryGetMember(object o, string name, out object value)
        {
            value = null;
            if (o == null) return false;

            SvPoint sp = o as SvPoint;
            if (sp != null)
            {
                Point3d p3 = sp.Point3d;
                switch (name.ToLowerInvariant())
                {
                    case "x": value = p3.X; return true;
                    case "y": value = p3.Y; return true;
                    case "z": value = p3.Z; return true;
                    case "t": value = p3.Z * 180.0 / Math.PI; return true;
                }
            }

            BindingFlags flags = BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase;
            Type type = o.GetType();
            PropertyInfo pi = type.GetProperty(name, flags);
            if (pi != null && pi.GetIndexParameters().Length == 0)
            {
                value = pi.GetValue(o, null);
                return true;
            }
            FieldInfo fi = type.GetField(name, flags);
            if (fi != null)
            {
                value = fi.GetValue(o);
                return true;
            }
            return false;
        }

        /// <summary>SvPoint, Point3d, Point3f, Point2d or Point2f to Point3d.</summary>
        public static bool TryToPoint3d(object o, out Point3d p)
        {
            p = new Point3d();
            if (o == null) return false;
            SvPoint sp = o as SvPoint;
            if (sp != null)
            {
                p = sp.Point3d;
                return true;
            }
            if (o is Point3d)
            {
                p = (Point3d)o;
                return true;
            }
            if (o is Point3f)
            {
                Point3f f = (Point3f)o;
                p = new Point3d(f.X, f.Y, f.Z);
                return true;
            }
            if (o is Point2d)
            {
                Point2d d = (Point2d)o;
                p = new Point3d(d.X, d.Y, 0);
                return true;
            }
            if (o is Point2f)
            {
                Point2f f2 = (Point2f)o;
                p = new Point3d(f2.X, f2.Y, 0);
                return true;
            }
            return false;
        }

        public static bool TryToDouble(object o, out double d)
        {
            d = 0;
            if (o == null) return false;
            if (o is double) { d = (double)o; return true; }
            if (o is float) { d = (float)o; return true; }
            if (o is int) { d = (int)o; return true; }
            if (o is short) { d = (short)o; return true; }
            if (o is long) { d = (long)o; return true; }
            if (o is byte) { d = (byte)o; return true; }
            if (o is decimal) { d = (double)(decimal)o; return true; }
            if (o is bool) { d = ((bool)o) ? 1.0 : 0.0; return true; }
            string s = o as string;
            if (s != null) return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d);
            return false;
        }
    }
}
