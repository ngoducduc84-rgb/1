﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using OpenCvSharp.CPlusPlus;

namespace SvMip
{
    /// <summary>
    /// The calibration math (it lives in SvMip.Calibration, which this assembly cannot reference). The program installs it at start-up.
    /// </summary>
    public interface ISvCalibrationService
    {
        /// <summary>
        /// Solves pixel -> robot from the pairs, checks the error (maxAllowedError) and saves the file (the old file is kept in a Backup folder).
        /// With originAtCenter the robot coordinates are made relative to the point at the centre of the image, as the Teach screen did.
        /// </summary>
        bool SolveLinear(string file, Point2d[] pixel, Point2d[] robot, int width, int height, bool originAtCenter, double maxAllowedError,
            out double maxError, out double meanError, out string message);

        /// <summary>Finds the rotation centre from pixel points of a mark that is rotated about the tool axis and stores it in the file.</summary>
        bool SolveRotation(string file, List<Point3d> pixelPoints, double markShiftX, double markShiftY, out Point2d center, out string message);

        /// <summary>A pixel point (x, y, angle in rad) to robot coordinates (x, y, angle in rad, normalised) with the calibration of the file.</summary>
        bool PixelToRobot(string file, Point3d pixel, out Point3d robot, out string message);
    }

    /// <summary>Implemented by tools that need the other tools of the job (SvIf, SvHandEye, SvMaster); SvJob calls it before Run.</summary>
    public interface ISvContextTool
    {
        void SetContext(IList<SvToolBase> tools);
    }

    /// <summary>
    /// What the cycle that is running knows: the text the robot sent (@request, @cmd, @request[n]) and what the tools answer.
    /// The values belong to the thread that runs the job (one thread per process), so processes do not disturb each other.
    /// </summary>
    public static class SvRuntime
    {
        /// <summary>Installed by the program; null while it was not.</summary>
        public static ISvCalibrationService Service;

        /// <summary>Folder of the calibration files. Set by the program.</summary>
        public static string CalibrationFolder = "C:\\SVL_Data\\Calibration";

        [ThreadStatic] static string request;
        [ThreadStatic] static string separators;
        [ThreadStatic] static string reply;
        [ThreadStatic] static string calibrationSaved;
        [ThreadStatic] static bool jobChanged;

        public const string DefaultSeparators = ",";

        public static void SetRequest(string text, string sep)
        {
            request = text ?? "";
            separators = string.IsNullOrEmpty(sep) ? DefaultSeparators : sep;
            reply = null;
            calibrationSaved = null;
            jobChanged = false;
        }

        public static void ClearRequest()
        {
            request = null;
            separators = null;
        }

        public static string Request { get { return request ?? ""; } }
        public static bool HasRequest { get { return request != null; } }

        /// <summary>The parts of the request, split at any of the separator characters (e.g. ",;"), trimmed. Part 0 is the command.</summary>
        public static string[] Tokens
        {
            get { return SplitRequest(Request, separators); }
        }

        public static string[] SplitRequest(string text, string sep)
        {
            if (string.IsNullOrEmpty(sep)) sep = DefaultSeparators;
            string[] parts = (text ?? "").Split(sep.ToCharArray());
            for (int i = 0; i < parts.Length; i++) parts[i] = parts[i].Trim();
            return parts;
        }

        public static string Command
        {
            get
            {
                string[] t = Tokens;
                return t.Length > 0 ? t[0] : "";
            }
        }

        /// <summary>"@cmd", "@request", "@request[n]" (used by SvIf and the tools that read a number from the request).</summary>
        public static bool TryGetSpecial(string path, out object value, out string error)
        {
            value = null;
            error = "";
            string p = (path ?? "").Trim().ToLowerInvariant();
            if (p == "@cmd" || p == "@command") { value = Command; return true; }
            if (p == "@request") { value = Request; return true; }
            if (p.StartsWith("@request[") && p.EndsWith("]"))
            {
                int n;
                if (!int.TryParse(p.Substring(9, p.Length - 10), out n) || n < 0)
                {
                    error = "bad request index in '" + path + "'";
                    return false;
                }
                string[] t = Tokens;
                if (n >= t.Length || (t.Length == 1 && t[0].Length == 0))
                {
                    error = "the request has no part " + n + (Request.Length == 0 ? " (no request: test with 'Test request' or send the command)" : " (parts are separated by the separator of SvTrigger, 0 is the command)");
                    return false;
                }
                value = t[n];
                return true;
            }
            error = "unknown special source '" + path + "'";
            return false;
        }

        /// <summary>A number from a setting: a number written in the field, @request[n], or Tool.Output.</summary>
        public static bool TryGetNumber(IList<SvToolBase> tools, string source, out double number, out string error)
        {
            number = 0;
            error = "";
            string s = (source ?? "").Trim();
            if (s.Length == 0) { error = "empty source"; return false; }
            if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out number)) return true;
            object v;
            bool ok = (s[0] == '@') ? TryGetSpecial(s, out v, out error) : SvPathResolver.TryGetToolValue(tools, s, out v, out error);
            if (!ok) return false;
            if (!SvPathResolver.TryToDouble(v, out number)) { error = "'" + s + "' is not a number (" + Convert.ToString(v, CultureInfo.InvariantCulture) + ")"; return false; }
            return true;
        }

        // ---- the answer of the tools ----
        public static void SetReply(string text) { reply = text; }
        public static string TakeReply() { string r = reply; reply = null; return r; }

        /// <summary>A tool saved this calibration file: the thread that aligns must read it again.</summary>
        public static void NotifyCalibrationSaved(string file) { calibrationSaved = file; }
        public static string TakeCalibrationSaved() { string r = calibrationSaved; calibrationSaved = null; return r; }

        /// <summary>A tool changed values that are kept in the job file (the master of SvAlign): the thread saves the job.</summary>
        public static void NotifyJobChanged() { jobChanged = true; }
        public static bool TakeJobChanged() { bool r = jobChanged; jobChanged = false; return r; }

        public static string FullCalibrationPath(string file)
        {
            if (string.IsNullOrEmpty(file)) return "";
            if (System.IO.Path.IsPathRooted(file)) return file;
            return System.IO.Path.Combine(CalibrationFolder, file);
        }

        /// <summary>"{cmd},OK,{count}" with the values; {name:F3} formats numbers. Unknown names stay as they are.</summary>
        public static string Format(string template, IDictionary<string, object> values)
        {
            if (string.IsNullOrEmpty(template)) return "";
            StringBuilder sb = new StringBuilder();
            int i = 0;
            while (i < template.Length)
            {
                char c = template[i];
                if (c == '{')
                {
                    int e = template.IndexOf('}', i + 1);
                    if (e > i)
                    {
                        string inner = template.Substring(i + 1, e - i - 1);
                        string name = inner, fmt = null;
                        int colon = inner.IndexOf(':');
                        if (colon >= 0) { name = inner.Substring(0, colon); fmt = inner.Substring(colon + 1); }
                        object v;
                        if (values.TryGetValue(name.Trim().ToLowerInvariant(), out v))
                        {
                            IFormattable f = v as IFormattable;
                            sb.Append(f != null && fmt != null ? f.ToString(fmt, CultureInfo.InvariantCulture) : Convert.ToString(v, CultureInfo.InvariantCulture));
                            i = e + 1;
                            continue;
                        }
                    }
                }
                sb.Append(c);
                i++;
            }
            return sb.ToString();
        }
    }

    /// <summary>
    /// Inputs that accept any output (a number, a text, a point ...). A tool declares them with inParams.Add("Name", null)
    /// and a property of type object; the link panel then offers every output of the earlier tools for them.
    /// </summary>
    /// <summary>
    /// A tool whose inputs / outputs are defined by the user in a table of its edit form (like the inputs of a tool block).
    /// SyncParams makes inParams / outParams follow the table and returns true when they changed.
    /// </summary>
    public interface ISvDynamicParams
    {
        /// <summary>Names of the list properties (the tables) that define the inputs / outputs.</summary>
        string[] ListProperties { get; }
        bool SyncParams();
    }

    public static class SvNames
    {
        /// <summary>A name that can be used in a template: letters, digits and _ , not starting with a digit.</summary>
        public static string Clean(string name)
        {
            if (string.IsNullOrEmpty(name)) return "";
            StringBuilder sb = new StringBuilder();
            foreach (char c in name.Trim())
            {
                if (char.IsLetterOrDigit(c) || c == '_') sb.Append(c);
                else if (c == ' ' || c == '-' || c == '.') sb.Append('_');
            }
            if (sb.Length > 0 && char.IsDigit(sb[0])) sb.Insert(0, '_');
            return sb.ToString();
        }

        /// <summary>name, or name_2, name_3 ... when it is already used (the comparison ignores the case).</summary>
        public static string Unique(string name, ICollection<string> used)
        {
            string n = name;
            int k = 2;
            while (ContainsIgnoreCase(used, n)) n = name + "_" + (k++);
            return n;
        }

        static bool ContainsIgnoreCase(ICollection<string> list, string name)
        {
            foreach (string s in list) if (string.Equals(s, name, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }
    }

    public static class SvLoose
    {
        /// <summary>The tool whose output is linked to the input (null when not linked).</summary>
        public static SvToolBase LinkedTool(SvToolBase tool, string input)
        {
            InputParams ip;
            if (tool == null || !tool.inParams.TryGetValue(input, out ip) || ip == null) return null;
            try { return ip.Instance as SvToolBase; }
            catch (Exception) { return null; }
        }

        public static bool IsLinked(SvToolBase tool, string input)
        {
            InputParams ip;
            return tool != null && tool.inParams.TryGetValue(input, out ip) && ip != null;
        }

        /// <summary>The value of the output that is linked to the input (null when not linked or the source has no value yet).</summary>
        public static object Read(SvToolBase tool, string input)
        {
            InputParams ip;
            if (tool == null || !tool.inParams.TryGetValue(input, out ip) || ip == null) return null;
            try { return ip.GetValue(); }
            catch (Exception) { return null; }
        }

        /// <summary>Makes sure the inputs exist (jobs saved before the input was added do not have them).</summary>
        public static void Ensure(SvToolBase tool, params string[] inputs)
        {
            foreach (string name in inputs)
                if (!tool.inParams.ContainsKey(name)) tool.inParams[name] = null;
        }

        /// <summary>"Tool.Output" of the link, for messages.</summary>
        public static string LinkText(SvToolBase tool, string input)
        {
            InputParams ip;
            if (tool == null || !tool.inParams.TryGetValue(input, out ip) || ip == null) return "";
            return ip.Instance + "." + ip.FieldName;
        }
    }
}
