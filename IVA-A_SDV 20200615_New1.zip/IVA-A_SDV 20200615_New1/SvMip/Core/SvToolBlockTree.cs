﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;
using SvMip.Edit;

namespace SvMip.Core
{
    public partial class SvToolBlockTree : UserControl
    {
        SvToolListForm toolListForm;

        static bool isInitTool = false;

        public SvToolBlockTree()
        {
            InitializeComponent();
            InitFindBox();
            InitAddButton();
            svToolTreeView.ToolDoubleClick += svToolTree_ToolDoubleClick;
            svToolTreeView.ToolSelect += svToolTreeView_ToolSelect;
           
            this.Disposed += (sender, e) =>
                {
                    SvAcquisition.CloseCamlist();

                    if (tools != null)
                    {
                        foreach (SvToolEditForm form in tools.Values)
                        {
                            form.Close();
                            form.Dispose();
                        }
                    }

                    if(toolListForm != null)
                    {
                        toolListForm.Close();
                        toolListForm.Dispose();
                    }

                    isInitTool = false;
                };
        }
                
        void svToolTreeView_ToolSelect(object sender, SvToolBase tool)
        {
            NotifyToolSelect(sender, tool);
        }

        public delegate void ToolSelectHandler(object sender, SvToolBase tool);
        public event ToolSelectHandler ToolSelect;

        void NotifyToolSelect(object sender, SvToolBase tool)
        {
            if (ToolSelect != null)
                ToolSelect(sender, tool);
        }
        
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvJob Job
        {
            get { return svToolTreeView.Job; }
            set { svToolTreeView.Job = value; }
        }

        static Dictionary<SvToolBase, SvToolEditForm> tools;
                
        public void ShowToolList()
        {
            if (!isInitTool)
            {
                isInitTool = true;
                InitToolList();
            }

            if (toolListForm == null || toolListForm.IsDisposed)
            {
                toolListForm = new SvToolListForm(tools.Keys);
                toolListForm.svToolList.MouseDown += svToolTreeView.toolListForm_MouseDown;
            }

            if (toolListForm.Visible == true)
                toolListForm.Focus();
            else
                toolListForm.Show();
        }

        public delegate bool ToolEditRequestHandler(object sender, SvToolBase tool);

        /// <summary>Raised on a double click. A handler that returns true has opened its own editor, so no editor window is shown.</summary>
        public event ToolEditRequestHandler ToolEditRequested;

        void svToolTree_ToolDoubleClick(object sender, SvToolBase selectedTool)
        {
            if (ToolEditRequested != null && ToolEditRequested(this, selectedTool)) return;

            if (!isInitTool)
            {
                isInitTool = true;
                 InitToolList();
            }

            SvToolEditForm selectedToolEditForm = null;

            foreach (SvToolBase tool in tools.Keys)
            {
                if (tool.GetType() == selectedTool.GetType())
                {
                    selectedToolEditForm = tools[tool];
                    if (tool is SvDataLog)
                    {
                        selectedToolEditForm.Deactivate -= selectedToolEditForm_DeactivateChanged;
                        selectedToolEditForm.Deactivate += selectedToolEditForm_DeactivateChanged;
                    }
                    break;
                }
            }

            selectedToolEditForm.Subject = selectedTool;

            if (selectedToolEditForm == null || selectedToolEditForm.IsDisposed) { MessageBox.Show("이거 버그임. 고쳐야됨. 이럴리가 없는데"); return; }

            if (selectedToolEditForm.Visible == true)
                selectedToolEditForm.Focus();
            else
                selectedToolEditForm.Show();

            if (selectedToolEditForm.WindowState == FormWindowState.Minimized)
                selectedToolEditForm.WindowState = FormWindowState.Normal;
        }

        /// <summary>Opens the editor of a tool as a double click on it would (used by the WPF tool list).</summary>
        public void RequestEdit(SvToolBase tool)
        {
            if (tool != null) svToolTree_ToolDoubleClick(this, tool);
        }

        /// <summary>The types of all tools that can be added to a job.</summary>
        public List<Type> GetToolTypes()
        {
            if (!isInitTool)
            {
                isInitTool = true;
                InitToolList();
            }
            List<Type> list = new List<Type>();
            foreach (SvToolBase t in tools.Keys) list.Add(t.GetType());
            return list;
        }

        void selectedToolEditForm_DeactivateChanged(object sender, EventArgs e)
        {
            RedrawAllNode();
        }


        public void SetToolBlockInOutput(SvToolBlock toolBlock)
        {
            svToolTreeView.InputTool = toolBlock.inputTool;
            toolBlock.outputTool.outParams.Clear();
            svToolTreeView.OutputTool = toolBlock.outputTool;
            svToolTreeView.Job = toolBlock.ToolJob;
        }

        public void RedrawAllNode()
        {
            svToolTreeView.RedrawAllNode();
        }

        // ---- "+ Add tool after ..." button under the tree opens the tool pop-up ----
        Button btnAdd;

        void InitAddButton()
        {
            btnAdd = new Button();
            btnAdd.Dock = DockStyle.Bottom;
            btnAdd.Height = 32;
            btnAdd.Text = "+ Add tool";
            btnAdd.Click += delegate { ShowAddPopup(); };
            Controls.Add(btnAdd);
            Controls.SetChildIndex(svToolTreeView, 0);
            svToolTreeView.AfterSelect += delegate { UpdateAddText(); };
        }

        string SelectedToolName()
        {
            TreeNode n = svToolTreeView.SelectedNode;
            while (n != null && n.Parent != null) n = n.Parent;
            if (n == null) return "";
            return System.Text.RegularExpressions.Regex.Replace(n.Text, @"\s+\d+(\.\d+)? ms$", "");
        }

        void UpdateAddText()
        {
            string name = SelectedToolName();
            btnAdd.Text = name.Length == 0 ? "+ Add tool" : "+ Add tool after " + name;
        }

        void ShowAddPopup()
        {
            if (!isInitTool)
            {
                isInitTool = true;
                InitToolList();
            }
            using (SvAddToolPopup popup = new SvAddToolPopup(tools.Keys, SelectedToolName()))
            {
                System.Drawing.Point p = btnAdd.PointToScreen(new System.Drawing.Point(0, 0));
                popup.Location = new System.Drawing.Point(p.X, Math.Max(0, p.Y - popup.Height));
                if (popup.ShowDialog(this) != DialogResult.OK || popup.SelectedType == null) return;
                svToolTreeView.AddToolAfterSelected(popup.SelectedType);
            }
            UpdateAddText();
        }

        // ---- search box above the tree: typing marks the matching tools, Enter jumps to the next one ----
        TextBox txtFind;

        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);

        void InitFindBox()
        {
            txtFind = new TextBox();
            txtFind.Dock = DockStyle.Top;
            txtFind.HandleCreated += delegate { try { SendMessage(txtFind.Handle, 0x1501, (IntPtr)1, "Search tools in this job"); } catch (Exception) { } };
            txtFind.TextChanged += delegate { MarkMatches(); };
            txtFind.KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; SelectNextMatch(); }
            };
            Controls.Add(txtFind);
            Controls.SetChildIndex(svToolTreeView, 0); // the tree fills what the box leaves
        }

        List<TreeNode> FindMatches()
        {
            List<TreeNode> list = new List<TreeNode>();
            string text = txtFind.Text.Trim();
            if (text.Length == 0) return list;
            foreach (TreeNode root in svToolTreeView.Nodes) CollectMatches(root, text, list);
            return list;
        }

        void CollectMatches(TreeNode node, string text, List<TreeNode> list)
        {
            if (node.Text.IndexOf(text, StringComparison.OrdinalIgnoreCase) >= 0) list.Add(node);
            foreach (TreeNode child in node.Nodes) CollectMatches(child, text, list);
        }

        void ClearMarks(TreeNode node)
        {
            node.BackColor = System.Drawing.Color.Empty;
            foreach (TreeNode child in node.Nodes) ClearMarks(child);
        }

        void MarkMatches()
        {
            foreach (TreeNode root in svToolTreeView.Nodes) ClearMarks(root);
            foreach (TreeNode n in FindMatches()) n.BackColor = System.Drawing.Color.FromArgb(255, 240, 160);
        }

        void SelectNextMatch()
        {
            List<TreeNode> list = FindMatches();
            if (list.Count == 0) return;
            int at = list.IndexOf(svToolTreeView.SelectedNode);
            TreeNode next = list[(at + 1) % list.Count];
            svToolTreeView.SelectedNode = next;
            next.EnsureVisible();
        }

        public List<KeyValuePair<string, double>> GetRunTimes()
        {
            return svToolTreeView.GetRunTimes();
        }

        /// <summary>Shows the run time of each tool next to its name.</summary>
        public void ShowRunTimes()
        {
            svToolTreeView.ShowRunTimes();
        }
    }
}
