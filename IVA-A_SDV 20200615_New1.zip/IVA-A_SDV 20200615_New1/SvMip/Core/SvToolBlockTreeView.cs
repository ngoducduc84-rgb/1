﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.Core
{
    public class SvToolBlockTreeView : TreeView
    {
        public SvToolBlockTreeView()
        {            
            InitDrag();
            InitJob();
            InitContextMenu();

            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);

            this.KeyDown += SvToolBlockTreeView_KeyDown;
            this.KeyUp += SvToolBlockTreeView_KeyUp;
            this.BeforeCollapse += SvToolBlockTreeView_BeforeCollapse;
            this.ShowPlusMinus = false;
            this.ShowRootLines = false;

            this.MouseMove += SvToolBlockTreeView_MouseMove;
            this.MouseDown += SvToolBlockTreeView_MouseDown;
        }

        private void SvToolBlockTreeView_MouseMove(object sender, MouseEventArgs e)
        {
            if (ListLink == null) return;

            // 모든 Link의 IsHighLight와 IsChanged를 Update
            for (int i = 0; i < ListLink.Length; i++)
            {
                foreach (List<Link> links in ListLink[i].Values)
                {
                    for (int j = 0; j < links.Count; j++)
                        links[j].HighlightLink(e.Location);
                }
            }
            
            TreeNode hoverNode = GetNodeAt(e.Location);

            if (hoverNode == null) return;
            
            OnDrawNode(new DrawTreeNodeEventArgs(this.CreateGraphics(), hoverNode, this.Bounds, TreeNodeStates.Marked));
        }

        private void SvToolBlockTreeView_BeforeCollapse(object sender, TreeViewCancelEventArgs e)
        {
            e.Cancel = true;
        }

        public bool IsControl = false;

        void SvToolBlockTreeView_KeyUp(object sender, KeyEventArgs e)
        {
            IsControl = false;
        }

        private void SvToolBlockTreeView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                try
                {
                    TreeNode node = SelectedNode;

                    if (inputTool != null && node.Index == 0) return;
                    if (outputTool != null && node.Index == Nodes.Count - 1) return;

                    if (node.Level > 0)
                        return;
                    if (MessageBox.Show("Do You Want to delete this tool?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                    {
                        return;
                    }
                    DeleteNode(node);
                }
                finally
                {
                    this.Focus();
                }
            }
            else if ((e.KeyData & Keys.Control) == Keys.Control)
            {
                IsControl = true;
            }
        }

        public void toolListForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Clicks == 2)
            {
                SvToolList svtoollist = sender as SvToolList;
                string typeName = svtoollist.SelectedItem.GetType().ToString();

                if (string.IsNullOrEmpty(typeName)) return;

                try
                {
                    SvToolBase tool = Activator.CreateInstance(Type.GetType(typeName, null, typeResolve)) as SvToolBase;
                    int index = Nodes.Count;
                    AddNode(index, tool);
                    NotifyToolSelect(this, tool);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        #region Context
        ContextMenuStrip context;
        void InitContextMenu()
        {            
            context = new System.Windows.Forms.ContextMenuStrip();
            context.Items.Add("Cancel LInk", null, delegate
            {
                int index = Nodes.IndexOf(GetRootNode(SelectedNode));

                SvToolBase tool = JobContainInOut[index];

                if (tool.inParams.ContainsKey(SelectedNode.Text))
                    tool.inParams[SelectedNode.Text] = null;
                RedrawAllNode();
            });

            context.Items.Add("Rename", null, delegate
            {
                TreeNode node = SelectedNode;

                int index = node.Index;
                if (inputTool != null && index == 0) return;
                if (outputTool != null && index == Nodes.Count - 1) return;

                RenameForm renameForm = new RenameForm(node.Name); // node.Text may carry the run time
                
                Point pt = this.PointToScreen(this.Location);
                renameForm.StartPosition = FormStartPosition.Manual;
                renameForm.Location = new Point(pt.X + node.Bounds.Right + 10, pt.Y + node.Bounds.Top - 50);
                if (DialogResult.OK != renameForm.ShowDialog())
                    return;

                if (inputTool != null) index -= 1;
                job.ToolList[index].toolName = renameForm.newName;
                node.Text = renameForm.newName;
                node.Name = node.Text;
            });

            context.Items.Add("Modify parmas", null, delegate
            {
                TreeNode node = SelectedNode;

                if (inputTool != null && node.Index == 0) return;
                if (outputTool != null && node.Index == Nodes.Count - 1) return;

                ModifyPamams(node);
            });

            context.Items.Add("Delete", null, delegate
            {
                TreeNode node = SelectedNode;

                if (inputTool != null && node.Index == 0) return;
                if (outputTool != null && node.Index == Nodes.Count - 1) return;

                DeleteNode(node);
            });

            this.ContextMenuStrip = context;
            context.Opening += context_Opening;
                        
        }

        void context_Opening(object sender, CancelEventArgs e)
        {
            if (SelectedNode == null)
                return;

            foreach(ToolStripItem item in context.Items)
            {
                item.Visible = false;
            }
                        
            //하드코딩입니다. 이렇게 짜는거 안좋은데 나도몰라....
            if (SelectedNode.Level == 0)
            {
                context.Items[1].Visible = true;
                context.Items[2].Visible = true;
                context.Items[3].Visible = true;
            }
            if (SelectedNode.Level == 1)
            {
                context.Items[0].Visible = true;
            }
        }

        #endregion

        #region NodeAction

        TreeNode MakeNode(SvToolBase tool)
        {
            TreeNode toolNode = new TreeNode(tool.ToString());
            toolNode.Name = tool.ToString();
            foreach (string ob in tool.GetInputParamNames())
            {
                TreeNode inputNode = new TreeNode(ob);
                inputNode.Name = ob;
                inputNode.ForeColor = Color.Red;
                toolNode.Nodes.Add(inputNode);
                this.ContextMenuStrip = context;
            }

            foreach (string ob in tool.GetOutputParamNames())
            {
                TreeNode outputNode = new TreeNode(ob);
                outputNode.Name = ob;
                outputNode.ForeColor = Color.Blue;
                toolNode.Nodes.Add(outputNode);
                this.ContextMenuStrip = context;
            }

            return toolNode;
        }

        void AddNode(int index, SvToolBase tool)
        {
            TreeNode toolNode = MakeNode(tool);

            if (inputTool != null)
            {
                if (index < 1) index = 1;
                if (index >= Nodes.Count) index = Nodes.Count - 1;
            }
            Nodes.Insert(index, toolNode);

            if (inputTool != null) index -= 1;
            job.ToolList.Insert(index, tool);
            RedrawAllNode();
        }

        void DeleteNode(TreeNode node)
        {            
            int index = node.Index;
            if (inputTool != null) index -= 1;
            SvToolBase tool = job.ToolList[index];
            job.ToolList.Remove(tool);
            tool = null;

            Nodes.Remove(node);
            RedrawAllNode();
        }

        TreeNode GetRootNode(TreeNode node)
        {
            if (node == null)
                return null;

            if (node.Parent == null)
                return node;
            else
                return GetRootNode(node.Parent);
        }

        void ModifyPamams(TreeNode node)
        {
            SvToolParamsEditForm form = new SvToolParamsEditForm();

            int index = node.Index;
            if (inputTool != null) index -= 1;
            SvToolBase tool = job.ToolList[index];

            //toolBlock만 예외처리
            if (tool is SvToolBlock)
            {
                MessageBox.Show("[ToolBlock] tool can be modified in tool editor, not this menu.");
                return;
            }

            form.Subject = tool;

            form.ShowDialog();

            RedrawAllNode();

            form.Dispose();
        }

        #endregion

        #region Job_Init&Job_Select

        SvToolBlock.SvInnerToolBlock inputTool;
        SvToolBlock.SvInnerToolBlock outputTool;
        
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvToolBlock.SvInnerToolBlock InputTool
        {
            get { return inputTool; }            
            set 
            {
                inputTool = value;
                //RedrawAllNode();
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvToolBlock.SvInnerToolBlock OutputTool
        {
            get { return outputTool; }
            set
            {
                outputTool = value;
                //RedrawAllNode();
            }
        }

        void InitJob()
        {
            job = new SvJob();
            this.AfterSelect += VJobList_AfterSelect;
            this.NodeMouseDoubleClick += SvToolBlockTreeView_NodeMouseDoubleClick;
        }

        SvJob job;
        
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvJob Job
        {
            get { return job; }
            set
            {
                lock (drawLock)
                {
                    job = value;

                    if (job == null || job.ToolList == null) return;

                    job.RestoreLink();
                    RedrawAllNode();
                }
            }
        }

        void VJobList_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode selectedRoot = GetRootNode(e.Node);
            int index = selectedRoot.Index;

            SvToolBase tool;

            if (inputTool != null) index -= 1;

            if (index < 0)
                tool = InputTool;
            else if(index >= job.ToolList.Count)
                tool = OutputTool;
            else
                tool = job.ToolList[index];

            NotifyToolSelect(sender, tool);
            
        }

        public delegate void ToolSelectHandler(object sender, SvToolBase tool);
        public event ToolSelectHandler ToolSelect;

        void NotifyToolSelect(object sender, SvToolBase tool)
        {
            if (ToolSelect != null)
                ToolSelect(sender, tool);
        }

        void SvToolBlockTreeView_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            TreeNode selectedRoot = GetRootNode(SelectedNode);
            int index = selectedRoot.Index;

            if (inputTool != null) index -= 1;
            if (index < 0 || index >= job.ToolList.Count) return;
            SvToolBase tool = job.ToolList[index];

            NotifyToolDoubleClick(sender, tool);
        }

        public delegate void ToolDoubleClickHandler(object sender, SvToolBase tool);
        public event ToolDoubleClickHandler ToolDoubleClick;

        void NotifyToolDoubleClick(object sender, SvToolBase tool)
        {
            if (ToolDoubleClick != null)
                ToolDoubleClick(sender, tool);
        }

        public Dictionary<string, List<Link>>[] ListLink;
        List<SvToolBase> JobContainInOut;

        /// <summary>Name and run time (ms) of every tool that ran last time, in job order.</summary>
        public List<KeyValuePair<string, double>> GetRunTimes()
        {
            List<KeyValuePair<string, double>> list = new List<KeyValuePair<string, double>>();
            if (JobContainInOut == null) return list;
            lock (drawLock)
            {
                foreach (SvToolBase t in JobContainInOut)
                {
                    if (t == null || object.ReferenceEquals(t, inputTool) || object.ReferenceEquals(t, outputTool)) continue;
                    if (t.lastProcessTime > 0) list.Add(new KeyValuePair<string, double>(t.ToString(), t.lastProcessTime));
                }
            }
            return list;
        }

        /// <summary>Appends the run time of the last run to the tool names, e.g. "SvBlob1   12.3 ms".</summary>
        public void ShowRunTimes()
        {
            if (JobContainInOut == null) return;
            lock (drawLock)
            {
                // the slowest tool is shown in orange (only when there is something to compare)
                int slowest = -1;
                double slowestTime = 0;
                int timed = 0;
                for (int i = 0; i < Nodes.Count && i < JobContainInOut.Count; i++)
                {
                    SvToolBase t = JobContainInOut[i];
                    if (t == null || object.ReferenceEquals(t, inputTool) || object.ReferenceEquals(t, outputTool)) continue;
                    if (t.lastProcessTime > 0) timed++;
                    if (t.lastProcessTime > slowestTime) { slowestTime = t.lastProcessTime; slowest = i; }
                }
                for (int i = 0; i < Nodes.Count && i < JobContainInOut.Count; i++)
                {
                    SvToolBase t = JobContainInOut[i];
                    if (t == null || object.ReferenceEquals(t, inputTool) || object.ReferenceEquals(t, outputTool)) continue;
                    string text = t.ToString();
                    if (t.lastProcessTime > 0) text += string.Format("   {0:0.0} ms", t.lastProcessTime);
                    if (Nodes[i].Text != text) Nodes[i].Text = text;
                    System.Drawing.Color want = (timed > 1 && i == slowest) ? System.Drawing.Color.OrangeRed : System.Drawing.Color.Empty;
                    if (Nodes[i].ForeColor != want) Nodes[i].ForeColor = want;
                }
            }
        }

        public void RedrawAllNode()
        {
            int rootIndex = 0;
            int childIndex = -1;
            int topIndex = 0;
            int topChildIndex = -1;
            
            if (SelectedNode != null) // 현재 선택된 값 저장
            {
                rootIndex = GetRootNode(SelectedNode).Index;
                if (SelectedNode.Level == 1)
                    childIndex = SelectedNode.Index;
            }

            if (TopNode != null) // 현재 TopNode 저장
            {
                topIndex = GetRootNode(TopNode).Index;
                if (TopNode.Level == 1)
                    topChildIndex = TopNode.Index;
            }

            if (job == null) return;

            JobContainInOut = new List<SvToolBase>();
            if (inputTool != null) JobContainInOut.Add(inputTool);
            JobContainInOut.AddRange(job.ToolList);
            if (outputTool != null) JobContainInOut.Add(outputTool);

            if (JobContainInOut.Count == 0) return;

            ////////// Node 만들기
            List<TreeNode> listTree = new List<TreeNode>();

            foreach (SvToolBase tool in JobContainInOut)
            {
                if (tool == null) continue;
                TreeNode toolNode = MakeNode(tool);
                listTree.Add(toolNode);
            }

            if (outputTool != null)
            {
                List<TreeNode> deleteingNode = new List<TreeNode>();
                foreach (TreeNode node in listTree[listTree.Count - 1].Nodes)
                {
                    if (node.ForeColor == Color.Blue)
                        deleteingNode.Add(node);
                }

                foreach (TreeNode node in deleteingNode)
                {
                    listTree[listTree.Count - 1].Nodes.Remove(node);
                }
            }

            TreeNode[] treeArray = listTree.ToArray();
            mDrawNode = false;

            BeginUpdate();
            Nodes.Clear();
            Nodes.AddRange(treeArray);
            EndUpdate();

            ////////// LinkList 만들기
            MaxLinkWidth = 10;

            ListLink = new Dictionary<string, List<Link>>[JobContainInOut.Count];
            for (int i = 0; i < ListLink.Length; i++)
                ListLink[i] = new Dictionary<string, List<Link>>();

            for (int start = 0; start < JobContainInOut.Count; start++)
            {
                for (int end = JobContainInOut.Count - 1; end > start; end--)
                {
                    foreach (var inparam in JobContainInOut[end].inParams)
                    {
                        if (inparam.Value == null) continue;

                        SvToolBase startTool = JobContainInOut[start];
                        SvToolBase endtool = inparam.Value.Instance as SvToolBase;

                        if (!Nodes[start].Nodes.ContainsKey(inparam.Value.FieldName))
                            continue;

                        if (startTool.HashCode == inparam.Value.InstanceHashcode)// && e.Node.Name == inparam.Value.FieldName)
                        {
                            int width;
                            if (!ListLink[start].ContainsKey(inparam.Value.FieldName))
                            {
                                MaxLinkWidth += 10;
                                width = MaxLinkWidth;
                                ListLink[start].Add(inparam.Value.FieldName, new List<Link>());
                            }
                            else
                                width = ListLink[start][inparam.Value.FieldName][0].Width;

                            Link link = new Link(Nodes[start].Nodes[inparam.Value.FieldName], Nodes[end].Nodes[inparam.Key], width);
                            ListLink[start][inparam.Value.FieldName].Add(link);
                        }
                    }
                }
            }

            for (int start = 0; start < JobContainInOut.Count; start++)
            {
                foreach(var v in ListLink[start].Values)
                {
                    if (v.Count > 0) v[0].IsLast = true;
                    else v[0].IsLast = false;
                }
            }

            ////////// 기존 선택된 노드 다시 선택
            try
            {
                TreeNode selectedNode = null;
                if (Nodes.Count > 0)
                {
                    if (rootIndex < Nodes.Count)
                    {
                        selectedNode = Nodes[rootIndex];
                        if (childIndex != -1 && childIndex < selectedNode.Nodes.Count)
                            selectedNode = selectedNode.Nodes[childIndex];
                    }
                    else if (rootIndex == Nodes.Count)
                        selectedNode = Nodes[--rootIndex];
                }

                mDrawNode = true;

                if (selectedNode != null)
                    SelectedNode = selectedNode;

                if (topIndex > -1 && topIndex < Nodes.Count)
                {
                    TopNode = Nodes[topIndex];
                    if (topChildIndex > -1 && topChildIndex < TopNode.Nodes.Count)
                        TopNode = TopNode.Nodes[topChildIndex];
                }                
                
                for (int i = 0; i < ListLink.Length; i++)
                {
                    foreach (var v in ListLink[i].Values)
                    {
                        for (int j = 0; j < v.Count; j++)
                        {
                            OnDrawNode(new DrawTreeNodeEventArgs(this.CreateGraphics(), v[0].StartNode, this.Bounds, TreeNodeStates.Hot));
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return;
            }
        }

        //void RedrawAllNode(SvJob newJob)
        //{
        //    BeginUpdate();
        //    Nodes.Clear();

        //    MaxLinkWidth = 0;
        //    NodeLinkWidth = new Dictionary<string,int>[newJob.ToolList.Count + 2];
        //    for (int i = 0; i < NodeLinkWidth.Length; i++)
        //        NodeLinkWidth[i] = new Dictionary<string, int>();

        //    if (inputTool != null)
        //        Nodes.Add(MakeNode(inputTool));

        //    SelectedNode = null;    //선택된 노드 초기화해야 맨땅에서부터 그려짐.

        //    foreach (SvToolBase tool in newJob.ToolList)
        //    {
        //        if (tool == null) continue;
        //        AddNode(job.ToolList.Count,tool);
        //    }

        //    if (outputTool != null)
        //        Nodes.Add(MakeNode(outputTool));

        //    EndUpdate();
        //    Update();
        //}
        #endregion

        #region Drag&Drop Event
        void InitDrag()
        {
            this.AllowDrop = true;
            this.DrawMode = TreeViewDrawMode.OwnerDrawText;
            this.ItemDrag += NTreeView_ItemDrag;
            this.DragDrop += NTreeView_DragDrop;
            this.DragEnter += NTreeView_DragEnter;
            this.DragOver += NTreeView_DragOver;

            
            InitPen();
        }

       Pen linkPen;

        void InitPen()
        {
            linkPen = new Pen(Color.Black);
            linkPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            linkPen.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;                        
        }
        
        Dictionary<string, int>[] NodeLinkWidth;
        int MaxLinkWidth = 0;
        object drawLock = new object();

        /// <summary>Text of a node on the dark background: Blue and Red (inputs and outputs) get lighter colours so they can be read.</summary>
        void DrawDarkNodeText(DrawTreeNodeEventArgs e)
        {
            TreeNode n = e.Node;
            Rectangle b = n.Bounds;
            bool selected = object.ReferenceEquals(n, SelectedNode);
            Color back = selected ? Color.FromArgb(40, 90, 150) : (n.BackColor.IsEmpty ? BackColor : n.BackColor);
            Color fore = SvMip.Edit.SvDarkTheme.Tone(n.ForeColor.IsEmpty ? ForeColor : n.ForeColor);
            using (Brush br = new SolidBrush(back))
                e.Graphics.FillRectangle(br, b);
            TextRenderer.DrawText(e.Graphics, n.Text, n.NodeFont ?? Font, b, selected ? Color.White : fore,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.GlyphOverhangPadding);
        }

        bool mDrawNode = false;
        protected override void OnDrawNode(DrawTreeNodeEventArgs e)
        {
            if (ListLink == null) return;

            lock (drawLock)
            {
                ExpandAll();
                if (SvMip.Edit.SvDarkTheme.Enabled && e.Node.Bounds.Width > 0)
                    DrawDarkNodeText(e);
                else
                    e.DrawDefault = true;

                if (!mDrawNode) return;

                TreeNode bottom = null;
                bottom = TopNode;
                while (true)
                {
                    TreeNode newbottom = bottom.NextVisibleNode;
                    if (newbottom == null || !newbottom.IsVisible)
                        break;
                    bottom = newbottom;
                }

                if (e.Node.Level == 0)
                {
                    int ellipseSize = 7;
                    int posX = e.Node.Bounds.Location.X + e.Node.Bounds.Width + 2;
                    int posY = e.Node.Bounds.Location.Y + (e.Node.Bounds.Height - ellipseSize) / 2;

                    // IsSuccess 등록
                    if (JobContainInOut[e.Node.Index].lastRunSuccess)
                        e.Graphics.FillEllipse(Brushes.LimeGreen, posX, posY, ellipseSize, ellipseSize);
                    else
                        e.Graphics.FillEllipse(Brushes.OrangeRed, posX, posY, ellipseSize, ellipseSize);
                }

                // 깜박임 개선을 위해 System에서 호출되는 경우 중 첫번째와 마지막(Scroll 때문에...) 경우만 처리
                if (e.State == 0 && e.Node != TopNode && e.Node != bottom && !IsDragDrop)
                    return;

                for (int i = 0; i < Math.Min(Nodes.Count, JobContainInOut.Count); i++)
                {
                    foreach (List<Link> links in ListLink[i].Values)
                    {
                        if (links.FindIndex(ss => ss.IsChanged == true) < 0 && e.State == TreeNodeStates.Marked)
                            continue;

                        for (int j = 0; j < links.Count; j++)
                        {
                            links[j].IsChanged = true;
                            links[j].DrawLine(e.Graphics);
                        }
                        // HighLight 일 경우 한번 더 그려준다.
                        for (int j = 0; j < links.Count; j++)
                        {
                            if (links[j].IsHighLight)
                                links[j].DrawLine(e.Graphics);
                        }
                    }
                }
            }
        }

        private void SvToolBlockTreeView_MouseDown(object sender, MouseEventArgs e)
        {
            if (ListLink == null) return;
            for (int i = 0; i < ListLink.Length; i++)
            {
                foreach (List<Link> links in ListLink[i].Values)
                {
                    for (int j = 0; j < links.Count; j++)
                    {
                        if (links[j].IsHighLight)
                        {
                            NTreeView_ItemDrag(links[j], new ItemDragEventArgs(e.Button));
                            return;
                        }
                    }
                }
            }
        }

        void NTreeView_ItemDrag(object sender, ItemDragEventArgs e)
        {
            if (e.Item is TreeNode)
            {
                TreeNode node = e.Item as TreeNode;
                bool islinkdrag = false;
                SelectedNode = node;

                if (node.Level == 0)
                {
                    DoDragDrop(node, DragDropEffects.All);                
                }
                else if (node.Level == 1)
                {
                    if (node.ForeColor != Color.Red)
                        DoDragDrop(node, DragDropEffects.Link);
                }
                else
                    throw new Exception("노드 레벨은 0, 1이 한계. 이거 의외는 프로그래밍 에러");
            }
            else if (e.Item == null)
            {
                Link link = sender as Link;
                DoDragDrop(link, DragDropEffects.Link);
            }
        }

        void NTreeView_DragOver(object sender, DragEventArgs e)
        {
            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
            this.SelectedNode = this.GetNodeAt(ClientPoint);

            if (SelectedNode == null) return;
            int index = this.Nodes.IndexOf(GetRootNode(this.SelectedNode)) - 1;
            if (index < 0) index = 0;

            this.Nodes[index].EnsureVisible();

            if (e.Effect == DragDropEffects.All || e.Effect == DragDropEffects.Move)
            {
                if (e.KeyState == 9)
                    e.Effect = DragDropEffects.All;
                else
                    e.Effect = DragDropEffects.Move;
                OnValidated(null);
            }
        }

        bool IsDragDrop = false;
        void NTreeView_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.AllowedEffect;
            IsDragDrop = true;
            //딱히 안씀?
            //SvToolBase tool = e.Data.GetData(typeof(SvToolBase)) as SvToolBase;
        }

        void NTreeView_DragDrop(object sender, DragEventArgs e)
        {
            IsDragDrop = false;
            //BeginUpdate();
            switch (e.Effect)
            {
                case DragDropEffects.Copy:
                    AddTool(e);
                    break;
                case DragDropEffects.Move:
                    ChangeJobOrder(e);
                    break;                    
                case DragDropEffects.Link:
                    if (e.Data.GetData(typeof(TreeNode)) == null)
                    {
                        Link link = e.Data.GetData(typeof(Link)) as Link;
                        e.Data.SetData(typeof(TreeNode), link.StartNode);// = new DragEventArgs(link.StartNode, 0, e.X, e.Y, DragDropEffects.Link, DragDropEffects.Link);
                    }
                        //AddLink(e.Data.GetData(typeof(Link) as Link);

                    LinkParameters(e);
                    break;
                case DragDropEffects.All:
                    //display update 하는동안 바로 또 Drag할 때
                    //Drag&Drop effect 시작을 All로 하다보니(이렇게 하지 않으면 Mouse에 '+' 표시가 안됨)
                    //가끔 Move인데 Copy로 들어오는 경우가 있어서... -,.- 한번 더 Filtering
                    if (e.KeyState == 8)
                        CopyTool(e);
                    else
                        ChangeJobOrder(e);
                    break;
            }
        }

        private void AddLink(Link link)
        {
            throw new NotImplementedException();
        }

        Func<System.Reflection.Assembly, string, bool, Type> typeResolve = (assembly, ttypeName, isIgnore) =>
        {
            if (assembly == null)
            {
                string assemblyName = ttypeName.Substring(0, ttypeName.IndexOf('.'));

                System.Reflection.Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
                foreach (System.Reflection.Assembly assem in assemblies)
                {
                    if (assem.GetName().Name == assemblyName)
                    {
                        assembly = assem;
                        break;
                    }
                }
            }

            return assembly.GetType(ttypeName, isIgnore);
        };

        void AddTool(DragEventArgs e)
        {
            string typeName = null;
            string[] formats = e.Data.GetFormats(true);
            foreach (string format in formats)
            {
                try
                {
                    if (Type.GetType(format, null, typeResolve).BaseType == typeof(SvToolBase))
                    {
                        typeName = format;
                        break;
                    }
                }
                catch { continue; }
            }

            if (string.IsNullOrEmpty(typeName)) return;

            try
            {
                SvToolBase tool = Activator.CreateInstance(Type.GetType(typeName, null, typeResolve)) as SvToolBase;
                
                Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
                this.SelectedNode = this.GetNodeAt(ClientPoint);

                if (SelectedNode == null)
                {
                    if (job == null)
                    {
                        job = new SvJob();
                        job.ToolList.Clear();
                    }

                    int index = Nodes.Count;

                    AddNode(index, tool);
                }
                else
                {
                    int index = GetRootNode(SelectedNode).Index;

                    if (index > Nodes.Count) return;

                    AddNode(index, tool);
                }            

                NotifyToolSelect(this, tool);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        /// <summary>Adds a new tool of this type right after the selected tool (at the end when nothing is selected) and selects it.</summary>
        public void AddToolAfterSelected(Type type)
        {
            try
            {
                SvToolBase tool = Activator.CreateInstance(type) as SvToolBase;
                if (tool == null) return;
                if (job == null)
                {
                    job = new SvJob();
                    job.ToolList.Clear();
                }

                TreeNode root = GetRootNode(SelectedNode);
                int index = (root == null) ? Nodes.Count : root.Index + 1;
                if (index > Nodes.Count) index = Nodes.Count;

                AddNode(index, tool);
                NotifyToolSelect(this, tool);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        void CopyTool(DragEventArgs e)
        {
            TreeNode draggedNode = e.Data.GetData(typeof(TreeNode)) as TreeNode;
            int draggedIndex = draggedNode.Index;
            if (inputTool != null) draggedIndex -= 1;

            if (draggedIndex < 0 || draggedIndex >= job.ToolList.Count) return;
            SvToolBase draggedTool = job.ToolList[draggedIndex];

            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
            SelectedNode = this.GetNodeAt(ClientPoint);
            TreeNode selectedRoot = GetRootNode(SelectedNode);

            SvToolBase copyTool = SvFunc.CopyTool(draggedTool, draggedTool.GetType()) as SvToolBase;

            int selectedIndex;
            if (selectedRoot == null)
            {
                selectedIndex = this.GetNodeCount(false);
            }
            else
                selectedIndex = selectedRoot.Index;

            if (inputTool != null) selectedIndex -= 1;
            if (selectedIndex < 0) return;
            if (selectedIndex > job.ToolList.Count)
                selectedIndex = job.ToolList.Count - 1;

            if (inputTool != null) selectedIndex += 1;

            AddNode(selectedIndex, copyTool);
            SelectedNode = Nodes[selectedIndex];

            foreach (KeyValuePair<string, InputParams> kv in draggedTool.inParams)
            {
                if (kv.Value == null) continue;
                copyTool.inParams[kv.Key] = new InputParams(kv.Value.Instance, kv.Value.FieldName);
                copyTool.GetInParams();
                copyTool.Run();
            }

            NotifyToolSelect(this, copyTool);
            RedrawAllNode();
        }

        void ChangeJobOrder(DragEventArgs e)
        {
            TreeNode draggedNode = e.Data.GetData(typeof(TreeNode)) as TreeNode;

            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
            SelectedNode = this.GetNodeAt(ClientPoint);

            //if (SelectedNode == null) return;

            int draggedIndex = draggedNode.Index;
            if (inputTool != null) draggedIndex -= 1;

            if (draggedIndex < 0 || draggedIndex >= job.ToolList.Count) return;
            SvToolBase draggedTool = job.ToolList[draggedIndex];

            TreeNode selectedRoot = GetRootNode(SelectedNode);
            int selectedIndex;
            if (selectedRoot == null)
            {
                selectedIndex= this.GetNodeCount(false) - 1;
            }
            else 
                selectedIndex = selectedRoot.Index;

            if (inputTool != null) selectedIndex -= 1;
            if (draggedIndex == selectedIndex) return;

            if (selectedIndex < 0) return;
            if (selectedIndex >= job.ToolList.Count)
                selectedIndex = job.ToolList.Count - 1;
            SvToolBase selectedTool = job.ToolList[selectedIndex];

            if (selectedTool is SvToolBlock.SvInnerToolBlock)
                return;

            //잡체인지 먼저 해야함
            job.ToolList.Remove(draggedTool);
            job.ToolList.Insert(selectedIndex, draggedTool);
            
            //그다음에 노드 변경
            Nodes.Remove(draggedNode);
            if (inputTool != null) selectedIndex += 1;
            Nodes.Insert(selectedIndex, draggedNode);
            SelectedNode = draggedNode;

            RedrawAllNode();
        }

        
        void LinkParameters(DragEventArgs e)
        {
            TreeNode srcNode = e.Data.GetData(typeof(TreeNode)) as TreeNode;

            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
            SelectedNode = this.GetNodeAt(ClientPoint);

            if (SelectedNode == null) return;
            if (srcNode == SelectedNode) return;

            if (SelectedNode.ForeColor != Color.Red) return;
            if (GetRootNode(SelectedNode).Index <= GetRootNode(srcNode).Index)
                return;

            int SelectedNodeindex = SelectedNode.Parent.Index;
            int srcNodeindex = srcNode.Parent.Index;

            if (inputTool != null)
            {
                SelectedNodeindex -= 1;
                srcNodeindex -= 1;
            }

            SvToolBase srcTool;
            SvToolBase selectedTool;

            if (outputTool != null && SelectedNodeindex >= job.ToolList.Count)
                selectedTool = outputTool;
            else
                selectedTool = job.ToolList[SelectedNodeindex];

            if (inputTool != null && srcNodeindex < 0)
                srcTool = inputTool;
            else
                srcTool = job.ToolList[srcNodeindex];

            // 깜박임 개선
            if (selectedTool.inParams[SelectedNode.Text] != null && selectedTool.inParams[SelectedNode.Text].InstanceHashcode == srcTool.HashCode && selectedTool.inParams[SelectedNode.Text].FieldName == srcNode.Text)
                return;

            selectedTool.inParams[SelectedNode.Text] = new InputParams(srcTool, srcNode.Text);
            selectedTool.GetInParams();
            RedrawAllNode();
        }
        #endregion

        public class Link
        {
            public Link(TreeNode _startNode, TreeNode _endNode, int _width)
            {
                StartNode = _startNode; EndNode = _endNode; Width = _width;
            }

            int Margin = 10;
            public TreeNode StartNode
            {
                get { return mStartNode; }
                set { mStartNode = value; }
            }
            TreeNode mStartNode;
            public TreeNode EndNode
            {
                get { return mEndNode; }
                set { mEndNode = value; }
            }
            public TreeNode mEndNode;

            public Point SP
            {
                get
                {
                    if (mStartNode == null) return new Point();
                    return mStartNode.Bounds.Location + new Size(mStartNode.Bounds.Width + Margin, mStartNode.Bounds.Height / 2);
                }
            }
            public Point EP
            {
                get
                {
                    if (mEndNode == null) return new Point();
                    return mEndNode.Bounds.Location + new Size(mEndNode.Bounds.Width + Margin, mEndNode.Bounds.Height / 2);
                }
            }

            public Point MP1
            {
                get
                {
                    return new Point(WidthMargin + Width, SP.Y);
                }
            }

            public Point MP2
            {
                get
                {
                    return new Point(WidthMargin + Width, EP.Y);
                }
            }

            int WidthMargin = 120;

            public int Width;
            public int Height { get { return EP.Y - SP.Y + 1; } }

            public bool IsDrawVertical;
            public bool IsHighLight;
            public bool IsChanged;

            public bool IsLast;

            int gap = 8;

            public void HighlightLink(Point pt)
            {
                bool isHighLight = false;
                IsChanged = false;
                
                if (SP.X < pt.X && MP1.X > pt.X && SP.Y + gap > pt.Y && SP.Y - gap < pt.Y)
                    isHighLight = true;
                if (MP1.X - gap < pt.X && MP1.X + gap > pt.X && MP1.Y < pt.Y && MP2.Y > pt.Y)
                    isHighLight = true;
                if (EP.X < pt.X && MP2.X > pt.X && EP.Y + gap > pt.Y && EP.Y - gap < pt.Y)
                    isHighLight = true;

                if (isHighLight != IsHighLight)
                {
                    IsChanged = true;
                    IsHighLight = isHighLight;
                }
            }

            public void DrawLine(Graphics gdi)
            {
                if (!IsChanged) return;

                Pen pSurround = new Pen(Color.White);
                pSurround.EndCap = LineCap.Flat;
                pSurround.LineJoin = LineJoin.Miter;
                pSurround.CompoundArray = new float[4] { 0, 0.375f, 0.625f, 1f };
                pSurround.Width = 4;

                Pen pCenter = new Pen(Color.Blue);
                pCenter.Width = 1;

                if (IsLast)
                    IsDrawVertical = true;

                if (IsHighLight)
                {
                    pSurround.Color = Color.LightSteelBlue;
                    IsDrawVertical = true;
                }

                if (IsDrawVertical)
                {
                    gdi.DrawLine(pSurround, MP1, MP2);
                    gdi.DrawLine(pCenter, MP1, MP2);
                }

                gdi.DrawLine(pSurround, SP, MP1);
                gdi.DrawLine(pCenter, SP, MP1);

                pSurround.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                pCenter.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                gdi.DrawLine(pSurround, MP2, EP);
                gdi.DrawLine(pCenter, MP2, EP);

                //IsLast = islasttemp;
            }
        }
    }
}
