﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.Core
{
    public class SvToolList : ListBox
    {
        public SvToolList()
        {
            InitDrag();
        }

        void InitDrag()
        {
            this.AllowDrop = true;
            this.MouseDown += SvToolList_MouseDown;
            this.DragDrop += SvToolList_DragDrop;
            this.DragEnter += SvToolList_DragEnter;
            this.DragOver += SvToolList_DragOver;
        }

        void SvToolList_MouseDown(object sender, MouseEventArgs e)
        {
            if (this.SelectedIndex == -1) return;

            DoDragDrop(this.SelectedItem as SvToolBase, DragDropEffects.Copy);                
        }
                

        void SvToolList_DragOver(object sender, DragEventArgs e)
        {
            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
        }

        void SvToolList_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.AllowedEffect;

            SvToolBase tool = e.Data.GetData(typeof(SvToolBase)) as SvToolBase;
        }

        void SvToolList_DragDrop(object sender, DragEventArgs e)
        {
            TreeNode d = new TreeNode();

            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));            
        }
    }
}
