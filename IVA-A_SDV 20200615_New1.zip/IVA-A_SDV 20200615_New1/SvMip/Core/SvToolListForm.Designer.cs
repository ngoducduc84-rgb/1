﻿namespace SvMip.Core
{
    partial class SvToolListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SvToolListForm));
            this.svToolList = new SvMip.Core.SvToolList();
            this.SuspendLayout();
            // 
            // svToolList
            // 
            this.svToolList.AllowDrop = true;
            this.svToolList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.svToolList.FormattingEnabled = true;
            this.svToolList.ItemHeight = 15;
            this.svToolList.Location = new System.Drawing.Point(0, 0);
            this.svToolList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.svToolList.Name = "svToolList";
            this.svToolList.Size = new System.Drawing.Size(325, 426);
            this.svToolList.TabIndex = 0;
            // 
            // SvToolListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(325, 426);
            this.Controls.Add(this.svToolList);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "SvToolListForm";
            this.Text = "Tool List";
            this.TopMost = true;
            this.ResumeLayout(false);

        }

        #endregion

        public SvToolList svToolList;
    }
}