﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.Core
{
    public partial class SvToolListForm : Form
    {
        public SvToolListForm(IEnumerable<SvToolBase> tools)
        {
            InitializeComponent();

            svToolList.Items.Clear();
            foreach (SvToolBase tool in tools)
            {
                svToolList.Items.Add(tool);
            }
        }
    }
}
