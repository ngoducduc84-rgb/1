﻿namespace SvMip.Display
{
    partial class SvDisplayViewStatusBar
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.pn_Border = new System.Windows.Forms.Panel();
            this.ckb_AutoFit = new System.Windows.Forms.CheckBox();
            this.ckb_Axis = new System.Windows.Forms.CheckBox();
            this.ckb_drawCenter = new System.Windows.Forms.CheckBox();
            this.pn_Plus = new System.Windows.Forms.Panel();
            this.pb_Plus = new System.Windows.Forms.PictureBox();
            this.pn_Minus = new System.Windows.Forms.Panel();
            this.pb_Minus = new System.Windows.Forms.PictureBox();
            this.cb_coordinate = new System.Windows.Forms.ComboBox();
            this.cb_Zoom = new System.Windows.Forms.ComboBox();
            this.lbl_Coodination = new System.Windows.Forms.Label();
            this.pn_Border.SuspendLayout();
            this.pn_Plus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Plus)).BeginInit();
            this.pn_Minus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Minus)).BeginInit();
            this.SuspendLayout();
            // 
            // pn_Border
            // 
            this.pn_Border.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pn_Border.BackColor = System.Drawing.SystemColors.Control;
            this.pn_Border.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pn_Border.Controls.Add(this.ckb_AutoFit);
            this.pn_Border.Controls.Add(this.ckb_Axis);
            this.pn_Border.Controls.Add(this.ckb_drawCenter);
            this.pn_Border.Controls.Add(this.pn_Plus);
            this.pn_Border.Controls.Add(this.pn_Minus);
            this.pn_Border.Controls.Add(this.cb_coordinate);
            this.pn_Border.Controls.Add(this.cb_Zoom);
            this.pn_Border.Controls.Add(this.lbl_Coodination);
            this.pn_Border.Location = new System.Drawing.Point(0, 0);
            this.pn_Border.Margin = new System.Windows.Forms.Padding(0);
            this.pn_Border.Name = "pn_Border";
            this.pn_Border.Size = new System.Drawing.Size(650, 28);
            this.pn_Border.TabIndex = 3;
            // 
            // ckb_AutoFit
            // 
            this.ckb_AutoFit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ckb_AutoFit.Checked = true;
            this.ckb_AutoFit.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckb_AutoFit.Location = new System.Drawing.Point(233, 2);
            this.ckb_AutoFit.Name = "ckb_AutoFit";
            this.ckb_AutoFit.Size = new System.Drawing.Size(68, 22);
            this.ckb_AutoFit.TabIndex = 10;
            this.ckb_AutoFit.Text = "Auto-Fit";
            this.ckb_AutoFit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ckb_AutoFit.UseVisualStyleBackColor = true;
            this.ckb_AutoFit.CheckedChanged += new System.EventHandler(this.ckb_AutoFit_CheckedChanged);
            // 
            // ckb_Axis
            // 
            this.ckb_Axis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ckb_Axis.Location = new System.Drawing.Point(370, 2);
            this.ckb_Axis.Name = "ckb_Axis";
            this.ckb_Axis.Size = new System.Drawing.Size(54, 22);
            this.ckb_Axis.TabIndex = 9;
            this.ckb_Axis.Text = "Axis";
            this.ckb_Axis.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ckb_Axis.UseVisualStyleBackColor = true;
            this.ckb_Axis.CheckedChanged += new System.EventHandler(this.ckb_drawCenter_CheckedChanged);
            // 
            // ckb_drawCenter
            // 
            this.ckb_drawCenter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ckb_drawCenter.Location = new System.Drawing.Point(305, 2);
            this.ckb_drawCenter.Name = "ckb_drawCenter";
            this.ckb_drawCenter.Size = new System.Drawing.Size(63, 22);
            this.ckb_drawCenter.TabIndex = 8;
            this.ckb_drawCenter.Text = "C-Line";
            this.ckb_drawCenter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ckb_drawCenter.UseVisualStyleBackColor = true;
            this.ckb_drawCenter.CheckedChanged += new System.EventHandler(this.ckb_drawCenter_CheckedChanged);
            // 
            // pn_Plus
            // 
            this.pn_Plus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pn_Plus.BackColor = System.Drawing.Color.Gray;
            this.pn_Plus.Controls.Add(this.pb_Plus);
            this.pn_Plus.Location = new System.Drawing.Point(602, 3);
            this.pn_Plus.Name = "pn_Plus";
            this.pn_Plus.Size = new System.Drawing.Size(20, 20);
            this.pn_Plus.TabIndex = 7;
            // 
            // pb_Plus
            // 
            this.pb_Plus.BackColor = System.Drawing.Color.Gray;
            this.pb_Plus.Image = global::SvMip.Properties.Resources.plus;
            this.pb_Plus.Location = new System.Drawing.Point(0, 0);
            this.pb_Plus.Margin = new System.Windows.Forms.Padding(0);
            this.pb_Plus.Name = "pb_Plus";
            this.pb_Plus.Size = new System.Drawing.Size(20, 20);
            this.pb_Plus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Plus.TabIndex = 6;
            this.pb_Plus.TabStop = false;
            // 
            // pn_Minus
            // 
            this.pn_Minus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pn_Minus.BackColor = System.Drawing.Color.Gray;
            this.pn_Minus.Controls.Add(this.pb_Minus);
            this.pn_Minus.Location = new System.Drawing.Point(623, 3);
            this.pn_Minus.Name = "pn_Minus";
            this.pn_Minus.Size = new System.Drawing.Size(20, 20);
            this.pn_Minus.TabIndex = 7;
            // 
            // pb_Minus
            // 
            this.pb_Minus.BackColor = System.Drawing.Color.Gray;
            this.pb_Minus.Image = global::SvMip.Properties.Resources.minus;
            this.pb_Minus.Location = new System.Drawing.Point(0, 0);
            this.pb_Minus.Margin = new System.Windows.Forms.Padding(0);
            this.pb_Minus.Name = "pb_Minus";
            this.pb_Minus.Size = new System.Drawing.Size(20, 20);
            this.pb_Minus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Minus.TabIndex = 5;
            this.pb_Minus.TabStop = false;
            // 
            // cb_coordinate
            // 
            this.cb_coordinate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cb_coordinate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_coordinate.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cb_coordinate.Location = new System.Drawing.Point(426, 3);
            this.cb_coordinate.Name = "cb_coordinate";
            this.cb_coordinate.Size = new System.Drawing.Size(101, 20);
            this.cb_coordinate.TabIndex = 4;
            // 
            // cb_Zoom
            // 
            this.cb_Zoom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cb_Zoom.FormattingEnabled = true;
            this.cb_Zoom.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cb_Zoom.Location = new System.Drawing.Point(531, 3);
            this.cb_Zoom.Name = "cb_Zoom";
            this.cb_Zoom.Size = new System.Drawing.Size(68, 20);
            this.cb_Zoom.TabIndex = 4;
            // 
            // lbl_Coodination
            // 
            this.lbl_Coodination.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Coodination.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_Coodination.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Coodination.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.lbl_Coodination.Location = new System.Drawing.Point(2, 3);
            this.lbl_Coodination.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_Coodination.Name = "lbl_Coodination";
            this.lbl_Coodination.Size = new System.Drawing.Size(212, 20);
            this.lbl_Coodination.TabIndex = 3;
            // 
            // SvDisplayViewStatusBar
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.pn_Border);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "SvDisplayViewStatusBar";
            this.Size = new System.Drawing.Size(650, 28);
            this.pn_Border.ResumeLayout(false);
            this.pn_Plus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Plus)).EndInit();
            this.pn_Minus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Minus)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pn_Border;
        private System.Windows.Forms.PictureBox pb_Minus;
        private System.Windows.Forms.PictureBox pb_Plus;
        private System.Windows.Forms.ComboBox cb_Zoom;
        private System.Windows.Forms.Label lbl_Coodination;
        private System.Windows.Forms.Panel pn_Plus;
        private System.Windows.Forms.Panel pn_Minus;
        private System.Windows.Forms.CheckBox ckb_drawCenter;
        private System.Windows.Forms.ComboBox cb_coordinate;
        private System.Windows.Forms.CheckBox ckb_Axis;
        public System.Windows.Forms.CheckBox ckb_AutoFit;
    }
}
