﻿namespace SvMip.Display
{
    partial class SvHistogramBox
    {
        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // HistogramBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "HistogramBox";
            this.Size = new System.Drawing.Size(278, 154);
            this.ResumeLayout(false);

        }

        #endregion
    }
}
