﻿namespace SvMip.Edit.Base
{
    partial class SvDisplayViewEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cb_ImageList = new System.Windows.Forms.ComboBox();
            this.sdv_display = new SvMip.Display.SvDisplayViewInteract();
            this.svDisplayViewStatusBar = new SvMip.Display.SvDisplayViewStatusBar();
            this.SuspendLayout();
            // 
            // cb_ImageList
            // 
            this.cb_ImageList.Dock = System.Windows.Forms.DockStyle.Top;
            this.cb_ImageList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_ImageList.FormattingEnabled = true;
            this.cb_ImageList.Location = new System.Drawing.Point(0, 0);
            this.cb_ImageList.Name = "cb_ImageList";
            this.cb_ImageList.Size = new System.Drawing.Size(521, 20);
            this.cb_ImageList.TabIndex = 1;
            // 
            // sdv_display
            // 
            this.sdv_display.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.sdv_display.Cursor = System.Windows.Forms.Cursors.Cross;
            this.sdv_display.Location = new System.Drawing.Point(0, 21);
            this.sdv_display.Name = "sdv_display";
            this.sdv_display.Size = new System.Drawing.Size(521, 317);
            this.sdv_display.TabIndex = 0;
            this.sdv_display.ZoomVisible = false;
            // 
            // svDisplayViewStatusBar1
            // 
            this.svDisplayViewStatusBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.svDisplayViewStatusBar.Location = new System.Drawing.Point(0, 338);
            this.svDisplayViewStatusBar.Margin = new System.Windows.Forms.Padding(0);
            this.svDisplayViewStatusBar.Name = "svDisplayViewStatusBar";
            this.svDisplayViewStatusBar.Size = new System.Drawing.Size(521, 28);
            this.svDisplayViewStatusBar.TabIndex = 2;
            // 
            // SvDisplayViewEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.svDisplayViewStatusBar);
            this.Controls.Add(this.cb_ImageList);
            this.Controls.Add(this.sdv_display);
            this.Name = "SvDisplayViewEdit";
            this.Size = new System.Drawing.Size(521, 366);
            this.ResumeLayout(false);

        }

        #endregion

        private SvMip.Display.SvDisplayViewInteract sdv_display;
        private System.Windows.Forms.ComboBox cb_ImageList;
        private Display.SvDisplayViewStatusBar svDisplayViewStatusBar;
    }
}
