﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Display;
using SvMip;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;
using System.Drawing.Imaging;

namespace SvMip.Edit.Base
{
    public partial class SvDisplayViewEdit : UserControl
    {
        public SvDisplayViewEdit()
        {
            InitializeComponent();
            customImageList = new Dictionary<int, SvImageInfo>();
            svDisplayViewStatusBar.Display = sdv_display;
            cb_ImageList.Click += cb_ImageList_Click;
            cb_ImageList.SelectedValueChanged += cb_ImageList_SelectedValueChanged;
        }

        bool IsComboBoxClick = false;

        void cb_ImageList_Click(object sender, EventArgs e)
        {
            IsComboBoxClick = true;
        }

        SvToolBase subject;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvToolBase Subject
        { 
            get { return subject;}
            set
            {
                subject = value;
                RefreshImage();
                
                if (cb_ImageList.Items.Count > 0)
                    cb_ImageList.SelectedIndex = cb_ImageList.Items.Count - 1;
            }
        }

        public SvDisplayViewInteract Display
        {
            get { return sdv_display; }
        }

        int currentIndex;

        public void RefreshImage()
        {
            sdv_display.Image = null;
            currentIndex = cb_ImageList.SelectedIndex;

            cb_ImageList.Items.Clear();

            if (subject != null)
            {
                foreach (SvImageInfo info in subject.imageList)
                {
                    cb_ImageList.Items.Add(info);
                }
            }

            foreach (KeyValuePair<int, SvImageInfo> pair in customImageList)
            {                
                cb_ImageList.Items.Insert(pair.Key, pair.Value);
            }

            cb_ImageList_SelectedValueChanged(this, null);
        }

        public void ClearImage()
        {
            sdv_display.Image = null;
        }

        public void InsertCustomImage(int index, SvImageInfo info)
        {
            customImageList.Add(index, info);
        }

        public void RemoveCustomImage(int index)
        {
            customImageList.Remove(index);
        }

        public void ClearCustomImage()
        {
            customImageList.Clear();
        }

        public void SetLastImage()
        {
            if (cb_ImageList.Items.Count > 0)
                cb_ImageList.SelectedIndex = cb_ImageList.Items.Count - 1;
        }

        /// <summary>The host draws its own image selector: hide the drop-down list on top of the image.</summary>
        public void HideImageSelector()
        {
            cb_ImageList.Visible = false;
        }

        /// <summary>The bar under the image (zoom, auto-fit, coordinates); a host that draws its own bar drives it through this.</summary>
        public SvMip.Display.SvDisplayViewStatusBar StatusBar
        {
            get { return svDisplayViewStatusBar; }
        }

        /// <summary>The host draws the image selector and the tool bar itself: the image takes the whole area, on a dark background.</summary>
        public void UseHostToolbar()
        {
            cb_ImageList.Visible = false;
            svDisplayViewStatusBar.Visible = false;
            ((Control)sdv_display).BackColor = System.Drawing.Color.FromArgb(22, 26, 32);
            sdv_display.Dock = DockStyle.Fill;
            Controls.SetChildIndex(sdv_display, 0);
            if (!emptyHooked) { sdv_display.Paint += DrawEmptyText; emptyHooked = true; }
        }

        bool emptyHooked;

        /// <summary>Text in the middle of the picture area while there is no picture.</summary>
        public string EmptyText = "No picture yet\r\nRun the job (Run job) or load an image in Acquisition";

        void DrawEmptyText(object sender, PaintEventArgs e)
        {
            try
            {
                SvImage img = sdv_display.Image;
                if (img != null && !img.IsNull) return;
            }
            catch (Exception) { }
            try
            {
                // the client area can be huge or empty (zoomed / not laid out yet): GDI+ throws OverflowException then
                Rectangle area = sdv_display.ClientRectangle;
                if (area.Width <= 1 || area.Height <= 1) return;
                int w = Math.Min(area.Width, 4000);
                int h = Math.Min(area.Height, 4000);
                RectangleF box = new RectangleF(area.X, area.Y, w, h);
                using (Font font = new Font("Segoe UI", 11f))
                using (Brush brush = new SolidBrush(System.Drawing.Color.FromArgb(120, 130, 144)))
                using (StringFormat format = new StringFormat())
                {
                    format.Alignment = StringAlignment.Center;
                    format.LineAlignment = StringAlignment.Center;
                    e.Graphics.DrawString(EmptyText, font, brush, box, format);
                }
            }
            catch (Exception) { }
        }

        public string[] GetImageNames()
        {
            string[] names = new string[cb_ImageList.Items.Count];
            for (int i = 0; i < names.Length; i++) names[i] = cb_ImageList.Items[i].ToString();
            return names;
        }

        public int SelectedImageIndex { get { return cb_ImageList.SelectedIndex; } }

        /// <summary>Shows another picture of the tool (keeps zoom and position, as a click on the list does).</summary>
        public void SelectImage(int index)
        {
            if (index < 0 || index >= cb_ImageList.Items.Count || index == cb_ImageList.SelectedIndex) return;
            IsComboBoxClick = true;
            cb_ImageList.SelectedIndex = index;
        }

        public Dictionary<int, SvImageInfo> CustomImageList { get { return customImageList; } set { customImageList = value; } }
        Dictionary<int, SvImageInfo> customImageList;

        public ComboBox imageListComboBox
        {
            get { return cb_ImageList; }
        }

        void cb_ImageList_SelectedValueChanged(object sender, EventArgs e)
        {
            this.Display.ClearImage();

            float oldZoom = Display.ZoomRatio;
            System.Drawing.Point oldLocation = Display.imageLocation;

            if (cb_ImageList.SelectedItem == null)
            {
                if (currentIndex != -1 && cb_ImageList.Items.Count > currentIndex)
                    cb_ImageList.SelectedIndex = currentIndex;
                else if (cb_ImageList.Items.Count > 0)
                    cb_ImageList.SelectedIndex = cb_ImageList.Items.Count - 1;
                return;
            }
            
            SvImageInfo imageInfo = (SvImageInfo)cb_ImageList.SelectedItem;
            sdv_display.Image = imageInfo.Image;

            if (imageInfo.drawingFunc != null && sdv_display.Image != null)
                imageInfo.drawingFunc(sdv_display);

            NotifySelectedValueChanged(imageInfo);

            if (IsComboBoxClick)
            {
                Display.ZoomRatio = oldZoom;
                Display.imageLocation = oldLocation;
                IsComboBoxClick = false;
            }
        }

        public delegate void SelectedImageChangedHandler(object sender, SvImageInfo imageInfo);
        
        public event SelectedImageChangedHandler SelectedImageChanged;

        void NotifySelectedValueChanged(SvImageInfo imageInfo)
        {
            if (SelectedImageChanged != null)
            {
                SelectedImageChanged(this, imageInfo);
            }
        }

        public Mat CalibrationMat
        {
            set
            {
                // Calibration VtoR과 Fixture Image2Fixture Matrix가 서로 반대네... 젠장 바꿔야지...
                Mat transF = null;
                if (value.Type() == MatType.CV_64FC1)
                {
                    transF = new Mat(3, 3, MatType.CV_32FC1);
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            transF.Set(i, j, (float)value.At<double>(i, j));
                        }
                    }
                }
                else if (value.Type() != MatType.CV_32FC1)
                    return;

                //float[,] ff = SvFunc.DisplayMatF(transF);
                //mViewModel.Edit.Display.Transform2D = transF;

                svDisplayViewStatusBar.CalibrationMat = transF;
                if (transF != null) transF.Dispose();
            }
        }

        public Mat GetDisplayImage(int _index = 0)
        {
            SvDisplayView display = new SvDisplayView();
            display.Width = Display.Width;
            display.Height = Display.Height;
            try
            {
                display.Image = CustomImageList[_index].Image;
                customImageList[_index].drawingFunc(display);
                return display.GetDisplayImage();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[image save fail] \r\n" + ex.ToString());
                return null;
            }
            finally
            {
                display.Dispose();
            }
        }
    }
}
