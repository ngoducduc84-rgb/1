﻿namespace SvMip.Edit.Base
{
    partial class SvToolEditBase
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.tssl_SuccessImage = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssl_ProcessTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_CurrentJob = new System.Windows.Forms.Label();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsb_Run = new System.Windows.Forms.ToolStripButton();
            this.tsb_AutoRun = new System.Windows.Forms.ToolStripButton();
            this.tsb_Load = new System.Windows.Forms.ToolStripButton();
            this.tsb_Save = new System.Windows.Forms.ToolStripButton();
            this.tsb_ToolList = new System.Windows.Forms.ToolStripButton();
            this.svDisplayViewEdit = new SvMip.Edit.Base.SvDisplayViewEdit();
            this.statusStrip.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(450, 452);
            this.tabControl.TabIndex = 3;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tssl_SuccessImage,
            this.tssl_ProcessTime});
            this.statusStrip.Location = new System.Drawing.Point(0, 478);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(900, 22);
            this.statusStrip.TabIndex = 4;
            this.statusStrip.Text = "statusStrip1";
            // 
            // tssl_SuccessImage
            // 
            this.tssl_SuccessImage.BackColor = System.Drawing.SystemColors.Control;
            this.tssl_SuccessImage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tssl_SuccessImage.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.tssl_SuccessImage.Name = "tssl_SuccessImage";
            this.tssl_SuccessImage.Size = new System.Drawing.Size(0, 0);
            // 
            // tssl_ProcessTime
            // 
            this.tssl_ProcessTime.BackColor = System.Drawing.SystemColors.Control;
            this.tssl_ProcessTime.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tssl_ProcessTime.Margin = new System.Windows.Forms.Padding(3, 0, 3, 0);
            this.tssl_ProcessTime.Name = "tssl_ProcessTime";
            this.tssl_ProcessTime.Size = new System.Drawing.Size(0, 0);
            this.tssl_ProcessTime.Spring = true;
            this.tssl_ProcessTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.Controls.Add(this.tabControl);
            this.panel1.Location = new System.Drawing.Point(0, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(450, 452);
            this.panel1.TabIndex = 5;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl_CurrentJob);
            this.panel2.Controls.Add(this.toolStrip);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(900, 26);
            this.panel2.TabIndex = 6;
            // 
            // lbl_CurrentJob
            // 
            this.lbl_CurrentJob.BackColor = System.Drawing.Color.White;
            this.lbl_CurrentJob.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_CurrentJob.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbl_CurrentJob.Location = new System.Drawing.Point(750, 0);
            this.lbl_CurrentJob.Name = "lbl_CurrentJob";
            this.lbl_CurrentJob.Size = new System.Drawing.Size(150, 26);
            this.lbl_CurrentJob.TabIndex = 10;
            this.lbl_CurrentJob.Text = "Current_Job";
            this.lbl_CurrentJob.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // toolStrip
            // 
            this.toolStrip.BackColor = System.Drawing.SystemColors.Control;
            this.toolStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsb_Run,
            this.tsb_AutoRun,
            this.toolStripSeparator1,
            this.tsb_Load,
            this.tsb_Save,
            this.tsb_ToolList});
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Padding = new System.Windows.Forms.Padding(0);
            this.toolStrip.Size = new System.Drawing.Size(900, 26);
            this.toolStrip.TabIndex = 2;
            this.toolStrip.Text = "ts_ToolMenuBar";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Margin = new System.Windows.Forms.Padding(3, 1, 3, 2);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 23);
            // 
            // tsb_Run
            // 
            this.tsb_Run.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Run.Image = global::SvMip.Properties.Resources.tsb_Run_Image;
            this.tsb_Run.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Run.Margin = new System.Windows.Forms.Padding(3);
            this.tsb_Run.Name = "tsb_Run";
            this.tsb_Run.Size = new System.Drawing.Size(23, 20);
            this.tsb_Run.Text = "toolStripButton1";
            this.tsb_Run.ToolTipText = "Run";
            // 
            // tsb_AutoRun
            // 
            this.tsb_AutoRun.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_AutoRun.Image = global::SvMip.Properties.Resources.tsb_AutoRun_Image;
            this.tsb_AutoRun.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_AutoRun.Name = "tsb_AutoRun";
            this.tsb_AutoRun.Size = new System.Drawing.Size(23, 23);
            this.tsb_AutoRun.Text = "AutoRun";
            this.tsb_AutoRun.Visible = false;
            this.tsb_AutoRun.Click += new System.EventHandler(this.tsb_AutoRun_Click);
            // 
            // tsb_Load
            // 
            this.tsb_Load.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Load.Image = global::SvMip.Properties.Resources.tsb_Load_Image;
            this.tsb_Load.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Load.Margin = new System.Windows.Forms.Padding(3);
            this.tsb_Load.Name = "tsb_Load";
            this.tsb_Load.Size = new System.Drawing.Size(23, 20);
            this.tsb_Load.Text = "toolStripButton3";
            this.tsb_Load.ToolTipText = "Load";
            // 
            // tsb_Save
            // 
            this.tsb_Save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Save.Image = global::SvMip.Properties.Resources.tsb_Save_Image;
            this.tsb_Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Save.Margin = new System.Windows.Forms.Padding(3);
            this.tsb_Save.Name = "tsb_Save";
            this.tsb_Save.Size = new System.Drawing.Size(23, 20);
            this.tsb_Save.Text = "toolStripButton4";
            this.tsb_Save.ToolTipText = "Save";
            // 
            // tsb_ToolList
            // 
            this.tsb_ToolList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_ToolList.Image = global::SvMip.Properties.Resources.tsb_ToolList_Image;
            this.tsb_ToolList.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_ToolList.Margin = new System.Windows.Forms.Padding(3);
            this.tsb_ToolList.Name = "tsb_ToolList";
            this.tsb_ToolList.Size = new System.Drawing.Size(23, 20);
            this.tsb_ToolList.ToolTipText = "Tool List";
            this.tsb_ToolList.Visible = false;
            // 
            // svDisplayViewEdit
            // 
            this.svDisplayViewEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.svDisplayViewEdit.Location = new System.Drawing.Point(450, 26);
            this.svDisplayViewEdit.Name = "svDisplayViewEdit";
            this.svDisplayViewEdit.Size = new System.Drawing.Size(448, 452);
            this.svDisplayViewEdit.TabIndex = 2;
            // 
            // SvToolEditBase
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.svDisplayViewEdit);
            this.Name = "SvToolEditBase";
            this.Size = new System.Drawing.Size(900, 500);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected internal SvMip.Edit.Base.SvDisplayViewEdit svDisplayViewEdit;
        private System.Windows.Forms.StatusStrip statusStrip;
        protected internal System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ToolStripButton tsb_Run;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsb_Load;
        private System.Windows.Forms.ToolStripButton tsb_Save;
        private System.Windows.Forms.ToolStripButton tsb_ToolList;
        protected internal System.Windows.Forms.ToolStrip toolStrip;
        protected System.Windows.Forms.Label lbl_CurrentJob;
        private System.Windows.Forms.ToolStripStatusLabel tssl_ProcessTime;
        private System.Windows.Forms.ToolStripStatusLabel tssl_SuccessImage;
        private System.Windows.Forms.ToolStripButton tsb_AutoRun;
    }
}
