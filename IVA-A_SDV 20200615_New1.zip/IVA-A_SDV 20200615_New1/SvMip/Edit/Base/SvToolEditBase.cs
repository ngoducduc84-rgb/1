﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.CompilerServices;

namespace SvMip.Edit.Base
{
    public partial class SvToolEditBase : UserControl, INotifyPropertyChanged
    {
        public string PATH_JOB = "C:\\SVL_Data\\Job";
        public string PATH_CALIB = "C:\\SVL_Data\\Calibration"; 

        public SvToolEditBase()
        {
            InitializeComponent();

            this.tsb_Run.Click += tsb_Run_Click;
            this.tsb_Load.Click += tsb_Load_Click;
            this.tsb_Save.Click += tsb_Save_Click;            
            this.tsb_ToolList.Click += tsb_ToolList_Click;

            this.tabControl.KeyDown += SvToolEditBase_KeyDown;

            ToolStatusImage = global::SvMip.Properties.Resources.FailIcon;            
            ToolStatusText = string.Format("{0:F2}ms", 0);

            InitDisplayViewEdit();
        }

        void SvToolEditBase_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.F5)
            //    tsb_Run_Click(null, null);
        }

        void subject_Ran(object sender, SvToolBase tool)
        {
            float oldZoom = svDisplayViewEdit.Display.ZoomRatio;
            Point oldLocation = svDisplayViewEdit.Display.imageLocation;

            svDisplayViewEdit.SetLastImage();

            svDisplayViewEdit.Display.ZoomRatio = oldZoom;
            svDisplayViewEdit.Display.imageLocation = oldLocation;

            if (outputTab != null) outputTab.Refresh();
        }

        // "Output" tab: the outputs of the tool with the values of the last run
        SvMip.Edit.SvToolOutputTab outputTab;
        
        private SvToolBase subject;

        internal void SetSubject(SvToolBase subject)
        {
            if (this.subject != null)
                this.subject.Ran -= subject_Ran;            
            this.subject = subject;
            this.subject.Ran += subject_Ran;

            lbl_CurrentJob.Text = subject.ToString();
            UpdateStatus();

            try
            {
                if (outputTab == null) outputTab = new SvMip.Edit.SvToolOutputTab(tabControl);
                outputTab.SetTool(subject);
            }
            catch { }

            svDisplayViewEdit.Subject = subject;
            NotifySubjectChanged(this, this.subject);
        }

        internal SvToolBase GetSubject()
        {
            return this.subject;
        }

        protected delegate void SubjectChangedHandler(object sender, SvToolBase tool);
        protected event SubjectChangedHandler SubjectChanged;

        public void NotifySubjectChanged(object sender, SvToolBase tool)
        {
            if (SubjectChanged != null)
                SubjectChanged(sender, tool);
        }


        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected SvDisplayViewEdit SvDisplayViewEdit
        {
            get { return this.svDisplayViewEdit; }
            set { this.svDisplayViewEdit = value; }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected StatusStrip StatusStrip
        {
            get { return this.statusStrip; }
            set { this.statusStrip = value; }
        }

        virtual protected void InitDisplayViewEdit()
        {
            
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected bool IsAutoRunButtonVisible
        {
            get { return tsb_AutoRun.Visible; }
            set { tsb_AutoRun.Visible = value; }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected bool IsToolListButtonVisible
        {
            get { return tsb_ToolList.Visible; }
            set { tsb_ToolList.Visible = value; }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected string ToolStatusText
        {
            get { return tssl_ProcessTime.Text; }
            set
            {
                tssl_ProcessTime.Text = value;
                if (StatusChanged != null) StatusChanged(this, EventArgs.Empty);
            }
        }

        /// <summary>The run time or the result of the last run changed (a host that draws its own status bar listens to this).</summary>
        public event EventHandler StatusChanged;

        /// <summary>The last run of the tool (or job) failed.</summary>
        public bool LastRunFailed { get; protected set; }

        /// <summary>The run time of the last run, as text ("12.50ms").</summary>
        public string StatusTimeText { get { return tssl_ProcessTime.Text; } }

        /// <summary>Hides the status strip at the bottom; the image takes its place.</summary>
        public void HideStatusStrip()
        {
            statusStrip.Visible = false;
            if (svDisplayViewEdit.Dock == DockStyle.None)
            {
                svDisplayViewEdit.Dock = DockStyle.Fill;
                Controls.SetChildIndex(svDisplayViewEdit, 0);
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected Image ToolStatusImage
        {
            get { return tssl_SuccessImage.Image; }
            set { tssl_SuccessImage.Image = value; }
        }

        void UpdateStatus()
        {
            if (subject.lastRunSuccess)
                ToolStatusImage = global::SvMip.Properties.Resources.SuccessIcon;
            else
                ToolStatusImage = global::SvMip.Properties.Resources.FailIcon;

            LastRunFailed = !subject.lastRunSuccess;
            ToolStatusText = string.Format("{0:F2}ms", subject.lastProcessTime);
        }

        // ---- docked mode: the editor shows only its toolbar and tabs, the image is the one of the job editor ----
        /// <summary>Hides the small tool bar on top (run, open, save). The host draws its own buttons.</summary>
        public void HideToolbar()
        {
            if (!panel2.Visible) return;
            int h = panel2.Height;
            panel2.Visible = false;
            // controls that are placed by hand (not docked) move up into the freed space
            if (ownDisplay == null && svDisplayViewEdit.Dock == DockStyle.None) // not an editor that uses the shared image
                svDisplayViewEdit.SetBounds(svDisplayViewEdit.Left, svDisplayViewEdit.Top - h, svDisplayViewEdit.Width, svDisplayViewEdit.Height + h);
        }

        /// <summary>The tool this editor works on now.</summary>
        public SvToolBase SubjectTool { get { return GetSubject(); } }

        bool tabsHooked;

        /// <summary>The editor sits in a host that draws the tab strip (Pattern / Setting / Output): hide the own tool bar, tab headers and status bar.</summary>
        public void PrepareForExternalHost()
        {
            HideToolbar();
            statusStrip.Visible = false;
            tabControl.Appearance = TabAppearance.FlatButtons;
            tabControl.SizeMode = TabSizeMode.Fixed;
            tabControl.ItemSize = new System.Drawing.Size(1, 1);
            tabControl.Padding = new System.Drawing.Point(0, 0);
            if (!tabsHooked)
            {
                tabsHooked = true;
                tabControl.SelectedIndexChanged += delegate { if (SelectedTabChanged != null) SelectedTabChanged(this, EventArgs.Empty); };
            }
        }

        /// <summary>The selected tab changed (inside the editor or by SelectedTabIndex).</summary>
        public event EventHandler SelectedTabChanged;

        public string[] GetTabNames()
        {
            string[] names = new string[tabControl.TabPages.Count];
            for (int i = 0; i < names.Length; i++) names[i] = tabControl.TabPages[i].Text;
            return names;
        }

        public int SelectedTabIndex
        {
            get { return tabControl.SelectedIndex; }
            set { if (value >= 0 && value < tabControl.TabPages.Count) tabControl.SelectedIndex = value; }
        }

        /// <summary>Run the tool once (the Run button of the tool bar).</summary>
        public void RunTool()
        {
            tsb_Run_Click(null, null);
        }

        public void ToggleAutoRun()
        {
            tsb_AutoRun_Click(null, null);
        }

        /// <summary>Hides the left panel (tool tree); the image takes its place. Used when the tool list is drawn by the host.</summary>
        public void HideSidePanel()
        {
            panel1.Visible = false;
            svDisplayViewEdit.SetBounds(0, svDisplayViewEdit.Top, ClientSize.Width, svDisplayViewEdit.Height);
        }

        SvDisplayViewEdit ownDisplay;

        /// <summary>Makes this editor use the image view of another editor (its own view is hidden). Can be called once.</summary>
        public void UseSharedDisplay(SvDisplayViewEdit shared)
        {
            if (ownDisplay != null || shared == null) return;
            ownDisplay = svDisplayViewEdit;
            ownDisplay.Visible = false;
            panel1.Dock = DockStyle.Fill;
            Controls.SetChildIndex(panel1, 0); // fill is laid out last, so the toolbar and tab headers stay visible
            svDisplayViewEdit = shared;
            OnSharedDisplay(ownDisplay, shared);
        }

        /// <summary>Called once after the shared view is in place.</summary>
        protected virtual void OnSharedDisplay(SvDisplayViewEdit own, SvDisplayViewEdit shared)
        {
        }

        /// <summary>The docked editor is shown (true) or hidden (false): hook or unhook what it adds to the shared view.</summary>
        public virtual void SetSharedActive(bool active)
        {
        }

        virtual protected  void tsb_ToolList_Click(object sender, System.EventArgs e)
        {           
        }

        public bool DeepCopy(object origin, object src)
        {
            Type originType = origin.GetType();
            Type srcType = src.GetType();

            if (originType != srcType) return false;

            System.Reflection.FieldInfo[] originFields = originType.GetFields(System.Reflection.BindingFlags.Instance |
                                                                              System.Reflection.BindingFlags.Public | 
                                                                              System.Reflection.BindingFlags.NonPublic |
                                                                              System.Reflection.BindingFlags.Static |
                                                                              System.Reflection.BindingFlags.DeclaredOnly);

            foreach (System.Reflection.FieldInfo info in originFields)
            {
                if (info.FieldType == typeof(SvImageInfo)) continue;
                info.SetValue(origin, info.GetValue(src));
            }

            return true;
        }

        protected SvSerializer serializer = new SvSerializer();

        virtual protected void tsb_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Tool files (*.tlf)|*.tlf|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.Multiselect = false;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            this.Cursor = Cursors.WaitCursor;
            SvToolBase tool = serializer.LoadTool(fd.FileName);
            this.Cursor = Cursors.Default;

            if (tool == null)
            {
                MessageBox.Show("Tool load fail");
                return;
            }

            if (!DeepCopy(subject, tool))
            {
                MessageBox.Show(string.Format("Tool type not match.\r\nTool file type : {0}",tool.ToString()));
                return;
            }

            SetSubject(subject);
            SvDisplayViewEdit.ClearImage();

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);     
        }

        virtual protected void tsb_Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Tool files (*.tlf)|*.tlf|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.DefaultExt = "*.tlf";
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            this.Cursor = Cursors.WaitCursor;
            bool success = serializer.SaveTool(GetSubject(), fd.FileName);
            this.Cursor = Cursors.Default;

            if (!success)
                MessageBox.Show("Tool save fail");
            else
                MessageBox.Show("Tool save success");

        }

        virtual protected void tsb_Run_Click(object sender, EventArgs e)
        {
            this.Focus();
            subject.GetInParams();
            if (subject != null)
            {
                subject.InitOutProperty();
                DateTime lastProcessTimeStart = DateTime.Now;
                subject.Run(true);
                subject.OnRan();
                subject.lastProcessTime = DateTime.Now.Subtract(lastProcessTimeStart).TotalMilliseconds;
            }
            
            UpdateStatus();
            // A.S.H subject_Ran에 추가되어서 제거
            //if (subject.lastRunSuccess)
            //    svDisplayViewEdit.imageListComboBox.SelectedIndex = svDisplayViewEdit.imageListComboBox.Items.Count - 1;
            float oldZoom = svDisplayViewEdit.Display.ZoomRatio;
            Point oldLocation = svDisplayViewEdit.Display.imageLocation;

            svDisplayViewEdit.RefreshImage();

            svDisplayViewEdit.Display.ZoomRatio = oldZoom;
            svDisplayViewEdit.Display.imageLocation = oldLocation;
        }

        bool isAutoRunning = false;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected bool IsAutoRunning
        {
            get { return isAutoRunning; }
            set
            {
                isAutoRunning = value;

                if (!isAutoRunning)
                {
                    tsb_AutoRun.Image = global::SvMip.Properties.Resources.tsb_AutoRun_Image;
                }
                else
                {
                    tsb_AutoRun.Image = global::SvMip.Properties.Resources.tsb_Stop_Image;
                }
            }
        }

        System.Threading.CancellationTokenSource autoRunTokenSource = new System.Threading.CancellationTokenSource();

        virtual protected void tsb_AutoRun_Click(object sender, EventArgs e)
        {
        }        

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
