﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SvMip.Edit.Base
{
    public partial class SvToolEditForm : Form
    {
        public SvToolEditForm(SvToolEditBase toolEditBase)
        {
            InitializeComponent();

            this.toolEditBase = toolEditBase;

            this.toolEditBase.Dock = DockStyle.Fill;
            this.Controls.Add(this.toolEditBase);
            
            string[] name = this.toolEditBase.ToString().Split('.');

            this.Text = name.Last().Replace("Sv","");
        }
        
        public SvToolEditBase toolEditBase;

        public SvToolBase Subject
        {
            get { return toolEditBase.GetSubject(); }
            set { toolEditBase.SetSubject(value); }
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            if(this.Visible)
            {
                toolEditBase.tabControl.SelectedIndex = 0;
                if (toolEditBase.svDisplayViewEdit.imageListComboBox.Items.Count > 0)
                    toolEditBase.svDisplayViewEdit.imageListComboBox.SelectedIndex = 0;
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.Hide();
                return;
            }
        }
        
    }
}
