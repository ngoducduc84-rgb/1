﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Edit page of SvAlign (built in code).</summary>
    public class SvAlignEdit : SvToolEditBase
    {
        BindingSource source;
        DataGridView gridPoints;

        public SvAlignEdit()
        {
            source = new BindingSource(typeof(SvAlign), null);
            TabPage page = SvEditHelper.AddPage(this, "Align");
            int y = 10;
            SvEditHelper.AddText(page, source, "CalibrationFile", "Calibration file (empty = recipe) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddCheck(page, source, "UseLimit", "Check limits (robot coordinates, T in degrees)", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "XMin", "X min :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "XMax", "X max :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "YMin", "Y min :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "YMax", "Y max :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "TMin", "T min :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "TMax", "T max :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddHeader(page, "Value sent when NG", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "NgX", "NG X :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "NgY", "NG Y :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "NgT", "NG T :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddHeader(page, "Align points (Source e.g. MakePoint1.OutPoint)", y); y += SvEditHelper.RowHeight;

            gridPoints = SvEditHelper.AddGrid(page, y, 190);
            SvEditHelper.AddTextColumn(gridPoints, "Name", "Name", 70);
            SvEditHelper.AddTextColumn(gridPoints, "Source", "Source", 130);
            SvEditHelper.AddTextColumn(gridPoints, "LoadX", "Load X", 55);
            SvEditHelper.AddTextColumn(gridPoints, "LoadY", "Load Y", 55);
            SvEditHelper.AddTextColumn(gridPoints, "LoadT", "Load T", 55);
            SvEditHelper.AddTextColumn(gridPoints, "OffsetX", "Off X", 50);
            SvEditHelper.AddTextColumn(gridPoints, "OffsetY", "Off Y", 50);
            SvEditHelper.AddTextColumn(gridPoints, "OffsetT", "Off T", 50);
            SvEditHelper.AddPickButton(page, gridPoints, "Source", y + 196);

            this.SubjectChanged += SvAlignEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvAlign Subject
        {
            get { return base.GetSubject() as SvAlign; }
            set { base.SetSubject(value); }
        }

        void SvAlignEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
            SvAlign align = Subject;
            if (align == null) gridPoints.DataSource = null;
            else gridPoints.DataSource = new BindingList<SvAlignPoint>(align.Points);
        }
    }
}
