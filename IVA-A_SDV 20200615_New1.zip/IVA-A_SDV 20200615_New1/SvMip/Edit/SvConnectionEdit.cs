﻿using System;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Edit page of SvConnection (built in code).</summary>
    public class SvConnectionEdit : SvToolEditBase
    {
        BindingSource source;

        public SvConnectionEdit()
        {
            source = new BindingSource(typeof(SvConnection), null);
            TabPage page = SvEditHelper.AddPage(this, "Connection");
            int y = 15;
            SvEditHelper.AddText(page, source, "ConnName", "Name :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddEnum(page, source, "ConnType", "Type :", y, typeof(SvConnType)); y += SvEditHelper.RowHeight;
            SvEditHelper.AddEnum(page, source, "ConnRole", "Used for :", y, typeof(SvConnRole)); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Host", "Host / IP :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Port", "Port (-1 = system) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "StationNumber", "Station No. (-1 = system) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "DeviceType", "Device type (-1 = system) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "IoThreadSleep", "IO sleep ms (-1 = system) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddHeader(page, "TCP / UDP / Serial / Modbus connections", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "TimeoutMs", "Timeout ms :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddEnum(page, source, "TextEncoding", "Text encoding :", y, typeof(SvTextEncoding)); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "UnitId", "Modbus unit id :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "SerialPortName", "Serial port (COM1) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "BaudRate", "Baud rate :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddEnum(page, source, "Parity", "Parity :", y, typeof(SvParity)); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "DataBits", "Data bits :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "StopBits", "Stop bits (1 / 2) :", y);
            this.SubjectChanged += SvConnectionEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvConnection Subject
        {
            get { return base.GetSubject() as SvConnection; }
            set { base.SetSubject(value); }
        }

        void SvConnectionEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
    }
}
