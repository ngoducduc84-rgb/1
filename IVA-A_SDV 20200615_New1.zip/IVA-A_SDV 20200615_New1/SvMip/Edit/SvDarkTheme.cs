﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace SvMip.Edit
{
    /// <summary>
    /// Dark colours for a tree of WinForms controls (the VISION screen). Only controls that still have the system
    /// colours are changed, so colours chosen on purpose keep their look. Controls added later are themed as well.
    /// The image views are left alone.
    /// </summary>
    public static class SvDarkTheme
    {
        public static readonly Color Back = Color.FromArgb(30, 35, 40);
        public static readonly Color Panel = Color.FromArgb(43, 49, 56);
        public static readonly Color Input = Color.FromArgb(34, 40, 51);
        public static readonly Color Line = Color.FromArgb(68, 76, 86);
        public static readonly Color Text = Color.FromArgb(232, 236, 239);
        public static readonly Color Muted = Color.FromArgb(154, 165, 177);
        public static readonly Color Accent = Color.FromArgb(76, 154, 255);
        static readonly Color Selection = Color.FromArgb(40, 90, 150);

        /// <summary>True once the theme has been applied: owner drawn controls then draw their text in light colours.</summary>
        public static bool Enabled { get; private set; }

        /// <summary>Lighter version of the dark system colours that are unreadable on the dark background (Blue, Red, Black).</summary>
        public static Color Tone(Color c)
        {
            if (!Enabled) return c;
            int argb = c.ToArgb();
            if (argb == Color.Blue.ToArgb()) return Color.FromArgb(120, 175, 255);
            if (argb == Color.Red.ToArgb()) return Color.FromArgb(255, 125, 125);
            if (argb == Color.Black.ToArgb()) return Text;
            return c;
        }

        static readonly ConditionalWeakTable<Control, object> hooked = new ConditionalWeakTable<Control, object>();

        public static void Apply(Control root)
        {
            if (root == null || IsImageView(root)) return;
            Enabled = true;
            try { Style(root); } catch (Exception) { /* a control that refuses a colour keeps its own */ }
            Hook(root);
            foreach (Control child in root.Controls) Apply(child);
        }

        static void Hook(Control c)
        {
            object o;
            if (hooked.TryGetValue(c, out o)) return;
            hooked.Add(c, new object());
            c.ControlAdded += delegate(object s, ControlEventArgs e) { Apply(e.Control); };
        }

        static bool IsImageView(Control c)
        {
            if (c is PictureBox) return true;
            for (Type t = c.GetType(); t != null; t = t.BaseType)
            {
                string n = t.Name;
                if (n == "SvDisplayView" || n == "SvDisplayViewInteract" || n == "SvDisplayViewStatusBar") return true;
            }
            return false;
        }

        static void Style(Control c)
        {
            TabControl tab = c as TabControl;
            if (tab != null)
            {
                tab.DrawMode = TabDrawMode.OwnerDrawFixed;
                tab.BackColor = Back;
                if (tab.Parent != null && tab.Parent.BackColor == SystemColors.Control) tab.Parent.BackColor = Back;
                tab.DrawItem -= DrawTab;
                tab.DrawItem += DrawTab;
                tab.Invalidate();
                return;
            }

            TabPage page = c as TabPage;
            if (page != null)
            {
                page.UseVisualStyleBackColor = false;
                page.BackColor = Back;
                page.ForeColor = Text;
                return;
            }

            TreeView tree = c as TreeView;
            if (tree != null)
            {
                tree.BackColor = Input;
                tree.ForeColor = Text;
                tree.LineColor = Line;
                tree.BorderStyle = BorderStyle.None;
                return;
            }

            ListView list = c as ListView;
            if (list != null)
            {
                list.BackColor = Input;
                list.ForeColor = Text;
                list.BorderStyle = BorderStyle.None;
                return;
            }

            ListBox lb = c as ListBox;
            if (lb != null)
            {
                lb.BackColor = Input;
                lb.ForeColor = Text;
                lb.BorderStyle = BorderStyle.None;
                return;
            }

            ComboBox combo = c as ComboBox;
            if (combo != null)
            {
                combo.FlatStyle = FlatStyle.Flat;
                combo.BackColor = Input;
                combo.ForeColor = Text;
                return;
            }

            if (c is TextBoxBase || c is NumericUpDown)
            {
                c.BackColor = Input;
                c.ForeColor = Text;
                TextBox tb = c as TextBox;
                if (tb != null) tb.BorderStyle = BorderStyle.FixedSingle;
                return;
            }

            DataGridView grid = c as DataGridView;
            if (grid != null)
            {
                grid.BackgroundColor = Back;
                grid.GridColor = Line;
                grid.BorderStyle = BorderStyle.None;
                grid.EnableHeadersVisualStyles = false;
                grid.ColumnHeadersDefaultCellStyle.BackColor = Panel;
                grid.ColumnHeadersDefaultCellStyle.ForeColor = Text;
                grid.ColumnHeadersDefaultCellStyle.SelectionBackColor = Panel;
                grid.RowHeadersDefaultCellStyle.BackColor = Panel;
                grid.RowHeadersDefaultCellStyle.ForeColor = Text;
                grid.RowHeadersDefaultCellStyle.SelectionBackColor = Panel;
                grid.DefaultCellStyle.BackColor = Input;
                grid.DefaultCellStyle.ForeColor = Text;
                grid.DefaultCellStyle.SelectionBackColor = Selection;
                grid.DefaultCellStyle.SelectionForeColor = Color.White;
                return;
            }

            Button button = c as Button;
            if (button != null)
            {
                if (button.UseVisualStyleBackColor || button.FlatStyle == FlatStyle.System)
                {
                    button.FlatStyle = FlatStyle.Flat;
                    button.UseVisualStyleBackColor = false;
                    button.BackColor = Panel;
                    button.ForeColor = Text;
                    button.FlatAppearance.BorderColor = Line;
                }
                return;
            }

            ToolStrip strip = c as ToolStrip;
            if (strip != null)
            {
                strip.Renderer = new ToolStripProfessionalRenderer(new DarkColors());
                strip.BackColor = Panel;
                strip.ForeColor = Text;
                foreach (ToolStripItem item in strip.Items)
                    if (item.ForeColor == SystemColors.ControlText) item.ForeColor = Text;
                return;
            }

            Label label = c as Label;
            if (label != null && label.BackColor.ToArgb() == Color.White.ToArgb())
            {
                // white boxes with white text (for example the name of the tool)
                label.BackColor = Panel;
                label.ForeColor = Text;
                return;
            }

            SplitContainer split = c as SplitContainer;
            if (split != null) split.BackColor = Line;

            if (c.BackColor == SystemColors.Control) c.BackColor = Back;
            if (c.ForeColor == SystemColors.ControlText) c.ForeColor = Text;
        }

        static void DrawTab(object sender, DrawItemEventArgs e)
        {
            TabControl tab = (TabControl)sender;
            bool selected = (e.Index == tab.SelectedIndex);
            Rectangle r = tab.GetTabRect(e.Index);
            using (Brush back = new SolidBrush(selected ? Panel : Back))
                e.Graphics.FillRectangle(back, r);
            using (Brush fore = new SolidBrush(selected ? Text : Muted))
            using (StringFormat sf = new StringFormat())
            {
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                e.Graphics.DrawString(tab.TabPages[e.Index].Text, tab.Font, fore, r, sf);
            }
            if (selected)
                using (Pen p = new Pen(Accent, 2))
                    e.Graphics.DrawLine(p, r.Left, r.Bottom - 1, r.Right, r.Bottom - 1);
        }

        class DarkColors : ProfessionalColorTable
        {
            public override Color ToolStripGradientBegin { get { return Panel; } }
            public override Color ToolStripGradientMiddle { get { return Panel; } }
            public override Color ToolStripGradientEnd { get { return Panel; } }
            public override Color MenuStripGradientBegin { get { return Panel; } }
            public override Color MenuStripGradientEnd { get { return Panel; } }
            public override Color StatusStripGradientBegin { get { return Panel; } }
            public override Color StatusStripGradientEnd { get { return Panel; } }
            public override Color ToolStripBorder { get { return Line; } }
            public override Color ToolStripDropDownBackground { get { return Panel; } }
            public override Color ImageMarginGradientBegin { get { return Panel; } }
            public override Color ImageMarginGradientMiddle { get { return Panel; } }
            public override Color ImageMarginGradientEnd { get { return Panel; } }
            public override Color OverflowButtonGradientBegin { get { return Panel; } }
            public override Color OverflowButtonGradientMiddle { get { return Panel; } }
            public override Color OverflowButtonGradientEnd { get { return Panel; } }
            public override Color ButtonSelectedHighlight { get { return Selection; } }
            public override Color ButtonSelectedGradientBegin { get { return Selection; } }
            public override Color ButtonSelectedGradientMiddle { get { return Selection; } }
            public override Color ButtonSelectedGradientEnd { get { return Selection; } }
            public override Color ButtonPressedGradientBegin { get { return Selection; } }
            public override Color ButtonPressedGradientMiddle { get { return Selection; } }
            public override Color ButtonPressedGradientEnd { get { return Selection; } }
            public override Color ButtonCheckedGradientBegin { get { return Selection; } }
            public override Color ButtonCheckedGradientMiddle { get { return Selection; } }
            public override Color ButtonCheckedGradientEnd { get { return Selection; } }
            public override Color ButtonSelectedBorder { get { return Accent; } }
            public override Color ButtonPressedBorder { get { return Accent; } }
            public override Color ButtonCheckedHighlight { get { return Selection; } }
            public override Color MenuItemSelected { get { return Selection; } }
            public override Color MenuBorder { get { return Line; } }
            public override Color SeparatorDark { get { return Line; } }
            public override Color SeparatorLight { get { return Line; } }
        }
    }
}
