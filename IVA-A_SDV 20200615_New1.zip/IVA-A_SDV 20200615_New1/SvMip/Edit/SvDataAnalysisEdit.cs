﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Core;
using System.Reflection;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    public partial class SvDataAnalysisEdit : SvToolEditBase
    {
        SvRotationRectangle regionRect;

         public SvDataAnalysisEdit()
        {
            InitializeComponent();

            InitBinding();

            base.SubjectChanged += SvDataAnalysisEdit_SubjectChanged;

            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;

            regionRect = new SvRotationRectangle();
        }

         void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
         {
             if (imageInfo.ImageName.Contains("Input"))
             {
                 if (Subject.InputImage != null)
                 {
                     SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.RegionRect);
                     Subject.DisplayRegions(SvDisplayViewEdit.Display);
                 }
             }
             else if (imageInfo.ImageName.Contains("Output"))
             {
                 //if (Subject.OutputImage != null)
                 //{
                 //    SvDisplayViewEdit.Display.GraphicsCollection.Add(Subject.RegionRect);
                 //    Subject.DisplayRegions(SvDisplayViewEdit.Display);
                 //}
             }
         }

         void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject)
         {
             if (drawObject == Subject.RegionRect)
             {
                 RemoveRegionValueChangedEvent();

                 SvRectangle regionRect = drawObject as SvRectangle;
                 nud_Region_X.Value = (decimal)regionRect.Location.X;
                 nud_Region_Y.Value = (decimal)regionRect.Location.Y;
                 nud_Region_Width.Value = (decimal)regionRect.Width;
                 nud_Region_Height.Value = (decimal)regionRect.Height;

                 AddRegionValueChangedEvent();

                 Subject.DisplayRegions(SvDisplayViewEdit.Display);
             }

             if (drawObject == Subject.Point)
             {
                 SvPoint point = drawObject as SvPoint;

                 nud_DataAnalysis_PointA_X.Value = (decimal)point.X;
                 nud_DataAnalysis_PointA_Y.Value = (decimal)point.Y;

                 Subject.DisplayRegions(SvDisplayViewEdit.Display);
             }
         }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvDataAnalysis Subject
        {
            get { return base.GetSubject() as SvDataAnalysis; }
            set { base.SetSubject(value);}
        }

        BindingSource source;
        void SvDataAnalysisEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
            Display_DrawObjectChanged(this, Subject.RegionRect);
            Display_DrawObjectChanged(this, Subject.Point);
        }

        void InitBinding()
        {
            source = new BindingSource(typeof(SvIntersectLine), null);
            nud_DataAnalysis_Angle.DataBindings.Add("Value", source, "Angle", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Angle_Low.DataBindings.Add("Value", source, "AngleLow", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Angle_High.DataBindings.Add("Value", source, "AngleHigh", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("State", source, "State", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        [NonSerialized]
        bool state = false;

        [OutputParam]
        public bool State
        {
            get 
            { 
                return state; 
            }
            set 
            { 
                state = value;
                UpdataResultStatus(state);
                NotifyPropertyChanged(); 
            }
        }

        void UpdataResultStatus(bool Status)
        {
            if (Status)
            {
                lbl_ResultStatus.Text = "Accept";
                lbl_ResultStatus.BackColor = Color.DodgerBlue;
                lbl_ResultStatus.ForeColor = Color.White;
            }

            else
            {
                lbl_ResultStatus.Text = "Reject";
                lbl_ResultStatus.BackColor = Color.Red;
                lbl_ResultStatus.ForeColor = Color.Black;
            }
        }

        #region Region Event
        void AddRegionValueChangedEvent()
        {
            nud_Region_X.ValueChanged += nud_RegionRect_ValueChanged;
            nud_Region_Y.ValueChanged += nud_RegionRect_ValueChanged;
            nud_Region_Width.ValueChanged += nud_RegionRect_ValueChanged;
            nud_Region_Height.ValueChanged += nud_RegionRect_ValueChanged;
        }

        void RemoveRegionValueChangedEvent()
        {
            nud_Region_X.ValueChanged -= nud_RegionRect_ValueChanged;
            nud_Region_Y.ValueChanged -= nud_RegionRect_ValueChanged;
            nud_Region_Width.ValueChanged -= nud_RegionRect_ValueChanged;
            nud_Region_Height.ValueChanged -= nud_RegionRect_ValueChanged;
        }

        private void nud_RegionRect_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown nud = sender as NumericUpDown;

            if (nud == nud_Region_X || nud == nud_Region_Y)
            {
                float f = (float)nud_Region_X.Value;
                OpenCvSharp.CPlusPlus.Point2f fp = new OpenCvSharp.CPlusPlus.Point2f((float)nud_Region_X.Value, (float)nud_Region_Y.Value);
                Subject.RegionRect.Location = new OpenCvSharp.CPlusPlus.Point2f((float)nud_Region_X.Value, (float)nud_Region_Y.Value);
            }
            else if (nud == nud_Region_Height)
            {
                Subject.RegionRect.Height = (float)nud_Region_Height.Value;
            }
            else if (nud == nud_Region_Width)
            {
                Subject.RegionRect.Width = (float)nud_Region_Width.Value;
            }
            else return;
        }

        private void btn_ResetRegionRect_Click(object sender, EventArgs e)
        {
            if (Subject != null && Subject.InputImage != null)
            {
                Subject.RegionRect = new SvRectangle(0, 0, 100, 100);
                tsb_Run_Click(this, null);
                Display_DrawObjectChanged(this, Subject.RegionRect);
            }
        }
        #endregion
    }
}
