﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;

namespace SvMip.Edit
{
    public partial class SvDistance2PEdit : SvToolEditBase
    {
        public SvDistance2PEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvCaliperEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvDistance2P Subject
        {
            get { return base.GetSubject() as SvDistance2P; }
            set { base.SetSubject(value); }
        }

        void SvCaliperEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                {
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.PointA);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.PointB);
                }
            }
        }

        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject)
        {
            if (drawObject is SvPoint)
                DataBindings["PointA"].ReadValue();
            if (drawObject is SvPoint)
                DataBindings["PointB"].ReadValue();
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvDistance2P), null);
            DataBindings.Add("PointA", source, "PointA", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("PointB", source, "PointB", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("DistanceResult", source, "DistanceResult", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        public double DistanceResult
        {
            get { throw new Exception("쓰면 안됨"); }
            set { nud_Distance_Result.Value = (decimal)value; }
        }

        public SvPoint PointA
        {
            get
            {
                PointA.Point2d = new Point2d((double)nud_Distance_SPX.Value, (double)nud_Distance_SPY.Value);
                return PointA;
            }
            set
            {
                nud_Distance_SPX.Value = (decimal)value.X;
                nud_Distance_SPY.Value = (decimal)value.Y;
            }
        }

        public SvPoint PointB
        {
            get
            {
                PointB.Point2d = new Point2d((double)nud_Distance_EPX.Value, (double)nud_Distance_EPY.Value);
                return PointB;
            }
            set
            {
                nud_Distance_EPX.Value = (decimal)value.X;
                nud_Distance_EPY.Value = (decimal)value.Y;
            }
        }
    }
}
