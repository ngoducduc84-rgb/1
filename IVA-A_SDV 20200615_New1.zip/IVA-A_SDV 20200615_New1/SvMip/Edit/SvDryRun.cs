﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Drawing;
using System.Windows.Forms;

namespace SvMip
{
    public class SvDryRunRow
    {
        public string Where;   // SvSend / channel
        public string Field;
        public string Source;
        public string Value;
        public string Result;
        public bool Ok;
    }

    /// <summary>
    /// Dry run of the SvSend setup: after the job was run once in the editor, every field of every enabled
    /// SvSend channel is evaluated exactly like the Auto thread does (source, scale, offset, range) but nothing is
    /// written to a PLC / robot / connection.
    /// </summary>
    public static class SvDryRun
    {
        public static List<SvDryRunRow> Evaluate(SvJob job)
        {
            List<SvDryRunRow> rows = new List<SvDryRunRow>();
            if (job == null) return rows;

            List<SvToolBase> tools = new List<SvToolBase>();
            Collect(job, tools, 0);

            foreach (SvToolBase t in tools)
            {
                SvSend send = t as SvSend;
                if (send == null) continue;
                foreach (SvSendChannel ch in send.Channels)
                {
                    if (!ch.Enabled) continue;
                    string where = send.ToString() + " / " + ch.Name;
                    if (ch.Fields.Count == 0)
                    {
                        rows.Add(Row(where, "(" + ch.Kind + ")", "SvAlign result", "(at run time)", "uses the SvAlign result", true));
                        continue;
                    }
                    foreach (SvSendField f in ch.Fields)
                        rows.Add(EvalField(tools, where, f));
                }
            }
            return rows;
        }

        static SvDryRunRow EvalField(List<SvToolBase> tools, string where, SvSendField f)
        {
            string src = (f.Source ?? "").Trim();
            if (src.Length == 0) return Row(where, f.Name, "", "", "no source", false);
            if (src[0] == '@') return Row(where, f.Name, src, "(at run time)", "known only in Auto", true);

            object v; string err;
            if (!SvPathResolver.TryGetToolValue(tools, src, out v, out err))
                return Row(where, f.Name, src, "", err, false);

            if (f.ValueType == SvSendValueType.Text)
                return Row(where, f.Name, src, Convert.ToString(v, CultureInfo.InvariantCulture), "ok", true);

            double d;
            if (!SvPathResolver.TryToDouble(v, out d))
                return Row(where, f.Name, src, Convert.ToString(v, CultureInfo.InvariantCulture), "value is not a number", false);
            double n = d * f.Scale + f.Offset;
            string shown = n.ToString("0.####", CultureInfo.InvariantCulture);
            if (double.IsNaN(n) || double.IsInfinity(n)) return Row(where, f.Name, src, shown, "value is not finite (tool found nothing?)", false);
            if (f.UseRange && (n < f.Min || n > f.Max))
                return Row(where, f.Name, src, shown, string.Format(CultureInfo.InvariantCulture, "outside [{0}, {1}]", f.Min, f.Max), false);
            return Row(where, f.Name, src, shown, "ok", true);
        }

        static SvDryRunRow Row(string where, string field, string src, string value, string result, bool ok)
        {
            SvDryRunRow r = new SvDryRunRow();
            r.Where = where; r.Field = field; r.Source = src; r.Value = value; r.Result = result; r.Ok = ok;
            return r;
        }

        static void Collect(SvJob job, List<SvToolBase> acc, int depth)
        {
            if (job == null || depth > 8) return;
            foreach (SvToolBase t in job.ToolList)
            {
                acc.Add(t);
                SvToolBlock block = t as SvToolBlock;
                if (block != null) Collect(block.ToolJob, acc, depth + 1);
            }
        }
    }
}

namespace SvMip.Edit
{
    /// <summary>Shows the result of SvDryRun.Evaluate in a list.</summary>
    public class SvDryRunDialog : Form
    {
        public SvDryRunDialog(string title, List<SvDryRunRow> rows)
        {
            AutoScaleMode = AutoScaleMode.None;
            Font = new Font("Segoe UI", 9f);
            Text = "Dry run";
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            MinimizeBox = false;
            MaximizeBox = true;
            Size = new Size(960, 440);

            int bad = 0;
            foreach (SvDryRunRow r in rows) if (!r.Ok) bad++;

            Label head = new Label();
            head.Dock = DockStyle.Top;
            head.Height = 34;
            head.Padding = new Padding(10, 8, 10, 0);
            head.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            head.Text = title + (rows.Count == 0 ? "  No enabled SvSend channel found." : "  " + rows.Count + " values, " + bad + " problem(s). Nothing was sent.");
            head.ForeColor = (bad > 0) ? Color.FromArgb(190, 40, 40) : Color.FromArgb(30, 120, 60);

            ListView list = new ListView();
            list.Dock = DockStyle.Fill;
            list.View = View.Details;
            list.FullRowSelect = true;
            list.Columns.Add("SvSend / channel", 200);
            list.Columns.Add("Field", 110);
            list.Columns.Add("Source", 220);
            list.Columns.Add("Value", 110);
            list.Columns.Add("Result", 280);
            foreach (SvDryRunRow r in rows)
            {
                ListViewItem item = new ListViewItem(r.Where);
                item.SubItems.Add(r.Field);
                item.SubItems.Add(r.Source);
                item.SubItems.Add(r.Value);
                item.SubItems.Add(r.Result);
                if (!r.Ok) item.ForeColor = Color.FromArgb(190, 40, 40);
                list.Items.Add(item);
            }

            Button close = new Button();
            close.Text = "Close";
            close.DialogResult = DialogResult.OK;
            close.Dock = DockStyle.Bottom;
            close.Height = 30;

            Controls.Add(list);
            Controls.Add(head);
            Controls.Add(close);
            AcceptButton = close;
            CancelButton = close;
        }
    }
}
