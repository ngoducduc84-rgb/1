﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    public partial class SvEdgeEdit : SvToolEditBase
    {
        public SvEdgeEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvEdgeEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]


        public SvEdge Subject
        {
            get { return base.GetSubject() as SvEdge; }
            set { base.SetSubject(value); }
        }


        void SvEdgeEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvEdge), null);

            cb_Edge_Mode.DisplayMember = "Key"; cb_Edge_Mode.ValueMember = "Value";
            cb_Edge_Mode.DataSource = Enum.GetValues(typeof(SvEdge.EdgeMode)).Cast<SvEdge.EdgeMode>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_Edge_Mode.DataBindings.Add("SelectedValue", source, "Mode", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_Edge_KernelSize.DataBindings.Add("Value", source, "KernelSize", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Edge_DX.DataBindings.Add("Value", source, "OrderX", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Edge_DY.DataBindings.Add("Value", source, "OrderY", true, DataSourceUpdateMode.OnPropertyChanged);
            tb_Edge_ThresholdLow.DataBindings.Add("Text", source, "ThresholdLow", true, DataSourceUpdateMode.OnPropertyChanged);
            tb_Edge_ThresholdHigh.DataBindings.Add("Text", source, "ThresholdHigh", true, DataSourceUpdateMode.OnPropertyChanged);

            histBox_Edge_Range.DataBindings.Add("Image", source, "InputImage.Mat", true, DataSourceUpdateMode.Never);
        }

        private void cb_Edge_Mode_SelectedValueChanged(object sender, EventArgs e)
        {
            ComboBox cb = sender as ComboBox;

            pn_Edge_CannyThreshold.Visible = false;
            gb_Edge_SobelOrderSize.Visible = false;

            if (cb.SelectedValue == null) return;
            //(LSH) Edge -> SvEdge
            SvEdge.EdgeMode mode = (SvEdge.EdgeMode)cb.SelectedValue;
            switch (mode)
            {
                case SvEdge.EdgeMode.Canny:
                    pn_Edge_CannyThreshold.Visible = true;
                    break;
                case SvEdge.EdgeMode.Laplacian:
                    break;
                case SvEdge.EdgeMode.Sobel:
                    gb_Edge_SobelOrderSize.Visible = true;
                    break;

            }
        }

        private void tb_Edge_Threshold_TextChanged(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            //(LSH) histBox_Edge_Range --> 도구상자
            if (tb.Name == "tb_Edge_ThresholdLow")
                histBox_Edge_Range.RangeLow = int.Parse(tb_Edge_ThresholdLow.Text);
            else if (tb.Name == "tb_Edge_ThresholdHigh")
                histBox_Edge_Range.RangeHigh = int.Parse(tb_Edge_ThresholdHigh.Text);
        }

        private void histBox_Edge_Range_RangeChange(object sender, EventArgs e)
        {
            tb_Edge_ThresholdLow.Text = histBox_Edge_Range.RangeLow.ToString();
            tb_Edge_ThresholdHigh.Text = histBox_Edge_Range.RangeHigh.ToString();
        }

    }
}
