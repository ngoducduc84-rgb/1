﻿using System;
using System.Drawing;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Small helpers to build tool edit pages in code (no designer file needed).</summary>
    internal static class SvEditHelper
    {
        public const int LabelX = 18;
        public const int InputX = 200;
        public const int RowHeight = 28;

        public static TabPage AddPage(SvToolEditBase edit, string title)
        {
            TabPage page = new TabPage();
            page.Text = title;
            page.AutoScroll = true;
            page.UseVisualStyleBackColor = true;
            edit.tabControl.Controls.Add(page);
            return page;
        }

        static void AddLabel(TabPage page, string caption, int y)
        {
            Label lbl = new Label();
            lbl.AutoSize = true;
            lbl.Text = caption;
            lbl.Location = new Point(LabelX, y + 4);
            page.Controls.Add(lbl);
        }

        public static TextBox AddText(TabPage page, BindingSource src, string prop, string caption, int y)
        {
            AddLabel(page, caption, y);
            TextBox tb = new TextBox();
            tb.Location = new Point(InputX, y);
            tb.Size = new Size(190, 21);
            tb.DataBindings.Add("Text", src, prop, true, DataSourceUpdateMode.OnPropertyChanged);
            page.Controls.Add(tb);
            return tb;
        }

        public static ComboBox AddEnum(TabPage page, BindingSource src, string prop, string caption, int y, Type enumType)
        {
            AddLabel(page, caption, y);
            ComboBox cb = new ComboBox();
            cb.DropDownStyle = ComboBoxStyle.DropDownList;
            cb.Location = new Point(InputX, y);
            cb.Size = new Size(190, 21);
            cb.DataSource = Enum.GetValues(enumType);
            cb.DataBindings.Add("SelectedItem", src, prop, true, DataSourceUpdateMode.OnPropertyChanged);
            page.Controls.Add(cb);
            return cb;
        }

        public static CheckBox AddCheck(TabPage page, BindingSource src, string prop, string caption, int y)
        {
            CheckBox cb = new CheckBox();
            cb.AutoSize = true;
            cb.Text = caption;
            cb.Location = new Point(LabelX, y + 2);
            cb.DataBindings.Add("Checked", src, prop, true, DataSourceUpdateMode.OnPropertyChanged);
            page.Controls.Add(cb);
            return cb;
        }

        public static DataGridView AddGrid(TabPage page, int y, int height)
        {
            DataGridView g = new DataGridView();
            g.Location = new Point(LabelX, y);
            g.Size = new Size(400, height);
            g.AutoGenerateColumns = false;
            g.AllowUserToAddRows = true;
            g.AllowUserToDeleteRows = true;
            g.RowHeadersVisible = true;
            g.RowHeadersWidth = 24;
            g.DataError += delegate(object sender, DataGridViewDataErrorEventArgs e) { e.ThrowException = false; };
            page.Controls.Add(g);
            return g;
        }

        public static void AddTextColumn(DataGridView g, string prop, string header, int width)
        {
            DataGridViewTextBoxColumn col = new DataGridViewTextBoxColumn();
            col.DataPropertyName = prop;
            col.HeaderText = header;
            col.Width = width;
            g.Columns.Add(col);
        }

        public static void AddCheckColumn(DataGridView g, string prop, string header, int width)
        {
            DataGridViewCheckBoxColumn col = new DataGridViewCheckBoxColumn();
            col.DataPropertyName = prop;
            col.HeaderText = header;
            col.Width = width;
            g.Columns.Add(col);
        }

        public static void AddEnumColumn(DataGridView g, string prop, string header, Type enumType, int width)
        {
            DataGridViewComboBoxColumn col = new DataGridViewComboBoxColumn();
            col.DataPropertyName = prop;
            col.HeaderText = header;
            col.Width = width;
            col.ValueType = enumType;
            col.DataSource = Enum.GetValues(enumType);
            g.Columns.Add(col);
        }

        /// <summary>Button under a grid: opens the source picker and writes the chosen text into property prop of the selected row.</summary>
        public static Button AddPickButton(TabPage page, DataGridView grid, string prop, int y)
        {
            Button b = new Button();
            b.Text = "Pick source for the selected row...";
            b.Size = new Size(240, 26);
            b.Location = new Point(LabelX, y);
            b.Click += delegate
            {
                object item = (grid.CurrentRow != null) ? grid.CurrentRow.DataBoundItem : null;
                if (item == null) { MessageBox.Show("Select a row first.", "Pick source"); return; }
                string picked = SvSourcePickerDialog.Pick(b.FindForm());
                if (picked == null) return;
                System.Reflection.PropertyInfo pi = item.GetType().GetProperty(prop);
                if (pi != null) pi.SetValue(item, picked, null);
                grid.Refresh();
            };
            page.Controls.Add(b);
            return b;
        }

        /// <summary>Small "..." button next to a source text box: opens the source picker and puts the result into the box.</summary>
        public static Button AddPickButton(TabPage page, TextBox box)
        {
            Button b = new Button();
            b.Text = "...";
            b.Size = new Size(30, 23);
            b.Location = new Point(box.Right + 6, box.Top - 1);
            b.Click += delegate
            {
                string picked = SvSourcePickerDialog.Pick(b.FindForm());
                if (picked != null) box.Text = picked;
            };
            page.Controls.Add(b);
            return b;
        }

        public static void AddHeader(TabPage page, string caption, int y)
        {
            Label lbl = new Label();
            lbl.AutoSize = true;
            lbl.Font = new Font(page.Font, FontStyle.Bold);
            lbl.Text = caption;
            lbl.Location = new Point(LabelX, y + 4);
            page.Controls.Add(lbl);
        }
    }
}
