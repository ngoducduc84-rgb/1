﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;
using OpenCvSharp.CPlusPlus;

namespace SvMip.Edit
{
    public partial class SvEqualizerEdit : SvToolEditBase
    {
        public SvEqualizerEdit()
        {          
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvEqualizerEdit_SubjectChanged;
        }
        
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]

        public SvEqualizer Subject
        {
            get { return base.GetSubject() as SvEqualizer; }
            set { base.SetSubject(value); }
        }

        void SvEqualizerEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvEqualizer), null);
        }               
    }
}
