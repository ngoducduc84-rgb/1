﻿using System;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Edit page of SvFor (built in code).</summary>
    public class SvForEdit : SvToolEditBase
    {
        BindingSource source;

        public SvForEdit()
        {
            source = new BindingSource(typeof(SvFor), null);
            TabPage page = SvEditHelper.AddPage(this, "For");
            int y = 15;
            SvEditHelper.AddText(page, source, "Count", "Repeat count (0..1000) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "BodyCount", "Repeated tools (next N) :", y); y += SvEditHelper.RowHeight;
            Label note = new Label();
            note.AutoSize = false;
            note.Size = new System.Drawing.Size(400, 60);
            note.Location = new System.Drawing.Point(SvEditHelper.LabelX, y + 10);
            note.Text = "The next N tools of this job run Count times. The iteration number is the output 'Index'.";
            page.Controls.Add(note);
            this.SubjectChanged += SvForEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvFor Subject
        {
            get { return base.GetSubject() as SvFor; }
            set { base.SetSubject(value); }
        }

        void SvForEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
    }
}
