﻿using System;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Edit page of SvHandEye (built in code).</summary>
    public class SvHandEyeEdit : SvToolEditBase
    {
        BindingSource source;

        public SvHandEyeEdit()
        {
            source = new BindingSource(typeof(SvHandEye), null);
            TabPage page = SvEditHelper.AddPage(this, "Hand-eye");
            int y = 15;
            SvEditHelper.AddEnum(page, source, "Mode", "Step :", y, typeof(SvHandEyeMode)); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "CalibrationFile", "Calibration file :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "PixelSource", "Mark position (Tool.Output) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "RobotX", "Robot X (number, @request[1], Tool.Output) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "RobotY", "Robot Y :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "MinPoints", "Solve: minimum points :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "MaxError", "Solve: max error, 0 = no check :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddCheck(page, source, "OriginAtCenter", "Origin at the picture centre", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "MarkShiftX", "Rotation: mark shift X :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "MarkShiftY", "Rotation: mark shift Y :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Reply", "Reply OK ({cmd} {count} {maxerr} {meanerr} {centerx} {centery}) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "ReplyNg", "Reply NG ({message}) :", y); y += SvEditHelper.RowHeight;
            Label note = new Label();
            note.AutoSize = false;
            note.Size = new System.Drawing.Size(420, 90);
            note.Location = new System.Drawing.Point(SvEditHelper.LabelX, y + 10);
            note.Text = "Put one SvHandEye per step behind SvIf (e.g. @cmd = HEB, HE, HEE). It only runs when the robot sends a command.";
            page.Controls.Add(note);
            this.SubjectChanged += OnSubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvHandEye Subject
        {
            get { return base.GetSubject() as SvHandEye; }
            set { base.SetSubject(value); }
        }

        void OnSubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
    }
}
