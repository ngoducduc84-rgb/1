﻿using System;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Edit page of SvIf (built in code).</summary>
    public class SvIfEdit : SvToolEditBase
    {
        BindingSource source;

        public SvIfEdit()
        {
            source = new BindingSource(typeof(SvIf), null);
            TabPage page = SvEditHelper.AddPage(this, "If");
            int y = 15;
            SvEditHelper.AddText(page, source, "Source", "Source (Tool.Output) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddEnum(page, source, "Operator", "Condition :", y, typeof(SvCompare)); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "CompareValue", "Compare value :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "CompareText", "Compare text (Text conditions, a|b = either) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "BodyCount", "Controlled tools (next N) :", y); y += SvEditHelper.RowHeight;
            Label note = new Label();
            note.AutoSize = false;
            note.Size = new System.Drawing.Size(400, 60);
            note.Location = new System.Drawing.Point(SvEditHelper.LabelX, y + 10);
            note.Text = "The next N tools of this job run only when the condition is true; otherwise they are skipped.";
            page.Controls.Add(note);
            this.SubjectChanged += SvIfEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvIf Subject
        {
            get { return base.GetSubject() as SvIf; }
            set { base.SetSubject(value); }
        }

        void SvIfEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
    }
}
