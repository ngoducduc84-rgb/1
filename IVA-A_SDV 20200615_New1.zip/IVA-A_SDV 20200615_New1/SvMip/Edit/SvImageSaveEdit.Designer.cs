﻿namespace SvMip.Edit
{
    partial class SvImageSaveEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_ImageSave = new System.Windows.Forms.TabPage();
            this.btnSelectPath = new System.Windows.Forms.Button();
            this.tbSavePath = new System.Windows.Forms.TextBox();
            this.tb_ImageSave_Name = new System.Windows.Forms.TextBox();
            this.lbl_ImageSave_Path = new System.Windows.Forms.Label();
            this.lbl_ImageSave_Name = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tp_ImageSave.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_ImageSave);
            // 
            // tp_ImageSave
            // 
            this.tp_ImageSave.Controls.Add(this.btnSelectPath);
            this.tp_ImageSave.Controls.Add(this.tbSavePath);
            this.tp_ImageSave.Controls.Add(this.tb_ImageSave_Name);
            this.tp_ImageSave.Controls.Add(this.lbl_ImageSave_Path);
            this.tp_ImageSave.Controls.Add(this.lbl_ImageSave_Name);
            this.tp_ImageSave.Location = new System.Drawing.Point(4, 22);
            this.tp_ImageSave.Name = "tp_ImageSave";
            this.tp_ImageSave.Padding = new System.Windows.Forms.Padding(3);
            this.tp_ImageSave.Size = new System.Drawing.Size(442, 426);
            this.tp_ImageSave.TabIndex = 0;
            this.tp_ImageSave.Text = "ImageSave";
            this.tp_ImageSave.UseVisualStyleBackColor = true;
            // 
            // btnSelectPath
            // 
            this.btnSelectPath.Location = new System.Drawing.Point(245, 78);
            this.btnSelectPath.Name = "btnSelectPath";
            this.btnSelectPath.Size = new System.Drawing.Size(26, 20);
            this.btnSelectPath.TabIndex = 27;
            this.btnSelectPath.Text = "...";
            this.btnSelectPath.UseVisualStyleBackColor = true;
            this.btnSelectPath.Click += new System.EventHandler(this.btnSelectPath_Click);
            // 
            // tbSavePath
            // 
            this.tbSavePath.Location = new System.Drawing.Point(95, 78);
            this.tbSavePath.Name = "tbSavePath";
            this.tbSavePath.ReadOnly = true;
            this.tbSavePath.Size = new System.Drawing.Size(144, 21);
            this.tbSavePath.TabIndex = 26;
            this.tbSavePath.Text = "c:\\\\SVL_Data\\\\Image";
            // 
            // tb_ImageSave_Name
            // 
            this.tb_ImageSave_Name.Location = new System.Drawing.Point(95, 43);
            this.tb_ImageSave_Name.Name = "tb_ImageSave_Name";
            this.tb_ImageSave_Name.Size = new System.Drawing.Size(144, 21);
            this.tb_ImageSave_Name.TabIndex = 26;
            // 
            // lbl_ImageSave_Path
            // 
            this.lbl_ImageSave_Path.AutoSize = true;
            this.lbl_ImageSave_Path.Location = new System.Drawing.Point(18, 87);
            this.lbl_ImageSave_Path.Name = "lbl_ImageSave_Path";
            this.lbl_ImageSave_Path.Size = new System.Drawing.Size(62, 12);
            this.lbl_ImageSave_Path.TabIndex = 24;
            this.lbl_ImageSave_Path.Text = "File Path :";
            // 
            // lbl_ImageSave_Name
            // 
            this.lbl_ImageSave_Name.AutoSize = true;
            this.lbl_ImageSave_Name.Location = new System.Drawing.Point(18, 46);
            this.lbl_ImageSave_Name.Name = "lbl_ImageSave_Name";
            this.lbl_ImageSave_Name.Size = new System.Drawing.Size(71, 12);
            this.lbl_ImageSave_Name.TabIndex = 25;
            this.lbl_ImageSave_Name.Text = "File Name :";
            // 
            // SvImageSaveEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "SvImageSaveEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_ImageSave.ResumeLayout(false);
            this.tp_ImageSave.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_ImageSave;
        private System.Windows.Forms.TextBox tb_ImageSave_Name;
        private System.Windows.Forms.Label lbl_ImageSave_Path;
        private System.Windows.Forms.Label lbl_ImageSave_Name;
        private System.Windows.Forms.Button btnSelectPath;
        private System.Windows.Forms.TextBox tbSavePath;
    }
}
