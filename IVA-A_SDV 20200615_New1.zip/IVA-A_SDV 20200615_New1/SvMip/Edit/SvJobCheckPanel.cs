﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SvMip.Edit
{
    /// <summary>
    /// Panel that lists the findings of SvJobCheck (replaces the MessageBox after saving).
    /// Double click on a row jumps to the tool. Built in code (no designer file).
    /// </summary>
    public class SvJobCheckPanel : UserControl
    {
        readonly Label lblTitle = new Label();
        readonly Button btnRecheck = new Button();
        readonly Button btnClose = new Button();
        readonly ListView list = new ListView();
        List<SvJobIssue> issues = new List<SvJobIssue>();

        public event EventHandler RecheckRequested;
        public event EventHandler CloseRequested;
        public event EventHandler<SvJobIssueEventArgs> IssueActivated;

        static readonly Color ErrorColor = Color.FromArgb(190, 40, 40);
        static readonly Color WarningColor = Color.FromArgb(170, 110, 0);

        public SvJobCheckPanel()
        {
            AutoScaleMode = AutoScaleMode.None;
            Font = new Font("Segoe UI", 9f);
            BackColor = Color.FromArgb(248, 248, 248);
            BorderStyle = BorderStyle.FixedSingle;

            lblTitle.AutoSize = false;
            lblTitle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            lblTitle.Location = new Point(8, 6);
            lblTitle.Size = new Size(600, 22);
            lblTitle.TextAlign = ContentAlignment.MiddleLeft;

            btnClose.Text = "Hide";
            btnClose.Size = new Size(70, 24);
            btnClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnClose.Click += delegate { if (CloseRequested != null) CloseRequested(this, EventArgs.Empty); };

            btnRecheck.Text = "Check again";
            btnRecheck.Size = new Size(100, 24);
            btnRecheck.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnRecheck.Click += delegate { if (RecheckRequested != null) RecheckRequested(this, EventArgs.Empty); };

            list.View = View.Details;
            list.FullRowSelect = true;
            list.GridLines = false;
            list.HideSelection = false;
            list.MultiSelect = false;
            list.Location = new Point(8, 34);
            list.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            list.Columns.Add("Level", 70);
            list.Columns.Add("Tool", 140);
            list.Columns.Add("Problem", 480);
            list.Columns.Add("How to fix", 420);
            list.DoubleClick += list_DoubleClick;

            Controls.Add(lblTitle);
            Controls.Add(btnRecheck);
            Controls.Add(btnClose);
            Controls.Add(list);
            Resize += delegate { LayoutControls(); };
            LayoutControls();
        }

        void LayoutControls()
        {
            btnClose.Location = new Point(ClientSize.Width - btnClose.Width - 8, 5);
            btnRecheck.Location = new Point(btnClose.Left - btnRecheck.Width - 6, 5);
            lblTitle.Width = Math.Max(100, btnRecheck.Left - 12);
            list.Size = new Size(Math.Max(100, ClientSize.Width - 16), Math.Max(40, ClientSize.Height - 42));
            // the last two columns share the free width
            int free = list.ClientSize.Width - list.Columns[0].Width - list.Columns[1].Width;
            if (free > 200)
            {
                list.Columns[2].Width = free * 5 / 9;
                list.Columns[3].Width = free - list.Columns[2].Width;
            }
        }

        public int ErrorCount { get { return SvJobCheck.Count(issues, SvIssueLevel.Error); } }
        public int WarningCount { get { return SvJobCheck.Count(issues, SvIssueLevel.Warning); } }

        /// <summary>Shows the findings. prefix is put in front of the counters (for example "Job saved. ").</summary>
        public void SetIssues(List<SvJobIssue> found, string prefix)
        {
            issues = found ?? new List<SvJobIssue>();
            list.BeginUpdate();
            list.Items.Clear();
            foreach (SvJobIssue i in issues)
            {
                ListViewItem item = new ListViewItem(i.Level == SvIssueLevel.Error ? "Error" : "Warning");
                item.ForeColor = (i.Level == SvIssueLevel.Error) ? ErrorColor : WarningColor;
                item.SubItems.Add(i.ToolName);
                item.SubItems.Add(i.Message);
                item.SubItems.Add(i.Hint);
                item.Tag = i;
                list.Items.Add(item);
            }
            list.EndUpdate();

            int e = ErrorCount, w = WarningCount;
            lblTitle.Text = (prefix ?? "") + "Job check: " + e + (e == 1 ? " error, " : " errors, ") + w + (w == 1 ? " warning" : " warnings");
            lblTitle.ForeColor = (e > 0) ? ErrorColor : (w > 0 ? WarningColor : Color.FromArgb(30, 120, 60));
        }

        void list_DoubleClick(object sender, EventArgs e)
        {
            if (list.SelectedItems.Count == 0) return;
            SvJobIssue issue = list.SelectedItems[0].Tag as SvJobIssue;
            if (issue != null && IssueActivated != null) IssueActivated(this, new SvJobIssueEventArgs(issue));
        }
    }

    public class SvJobIssueEventArgs : EventArgs
    {
        public SvJobIssue Issue { get; private set; }
        public SvJobIssueEventArgs(SvJobIssue issue) { Issue = issue; }
    }
}
