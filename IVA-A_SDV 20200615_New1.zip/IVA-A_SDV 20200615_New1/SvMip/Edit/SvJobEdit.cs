﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Core;
using System.Reflection;
using SvMip.Edit.Base;
using SvMip.CameraDevice;

namespace SvMip.Edit
{
    public partial class SvJobEdit : SvToolEditBase, IToolListHost
    {
        public event EventHandler OnSaved;

        /// <summary>The main job has no input or output node (only a tool block has).</summary>
        public SvToolBase InputNode { get { return null; } }
        public SvToolBase OutputNode { get { return null; } }

        /// <summary>A job was put into the editor (Job set, or a job file loaded).</summary>
        public event EventHandler JobLoaded;
        /// <summary>The job ran (run time of the tools is up to date).</summary>
        public event EventHandler JobRan;
        /// <summary>A tool was selected in the tool list or on the image.</summary>
        public event EventHandler<SvToolEventArgs> ToolSelected;

        /// <summary>Select a tool from outside (the WPF tool list): shows it on the image and switches the docked editor.</summary>
        public void SelectTool(SvToolBase tool)
        {
            if (tool != null) svToolBlockTree_ToolSelect(this, tool);
        }

        /// <summary>Open the editor of a tool from outside (as a double click on it).</summary>
        public void EditTool(SvToolBase tool)
        {
            svToolBlockTree.RequestEdit(tool);
        }

        /// <summary>The job changed from outside (tool added, moved, deleted, linked): rebuild the hidden tree that the editors still use.</summary>
        /// <summary>The structure of the job was changed by an editor (the inputs or outputs of a tool block): the tool list must be drawn again.</summary>
        public event EventHandler JobStructureEdited;

        /// <summary>Opens the editor of a tool inside a tool block in the editor column. False: this tool has no such editor (a block inside a block): the caller uses the old window.</summary>
        public bool EditInnerTool(SvToolBase tool)
        {
            if (externalDock == null || tool == null || tool is SvToolBlock || !HasDockedEditor(tool)) return false;
            ShowDockedEditor(tool);
            return true;
        }

        /// <summary>True when an input of the tool is linked to a value that does not exist yet (the job was not run). "Run this tool" then runs the whole job once.</summary>
        public bool NeedsUpstream(SvToolBase tool)
        {
            if (tool == null) return false;
            foreach (System.Collections.Generic.KeyValuePair<string, InputParams> p in tool.inParams)
            {
                if (p.Value == null) continue;
                try
                {
                    object v = p.Value.GetValue();
                    if (v == null) return true;
                    SvImage img = v as SvImage;
                    if (img != null && (img.Width <= 0 || img.Height <= 0)) return true;
                }
                catch (Exception) { return true; }
            }
            return false;
        }

        public void JobStructureChanged()
        {
            svToolBlockTree.RedrawAllNode();
        }

        /// <summary>The inputs / outputs of a tool changed (a table of its form): the tool list of the host is drawn again.</summary>
        public void RaiseStructureEdited()
        {
            // no RedrawAllNode here: it selects the first tool again
            if (JobStructureEdited != null) JobStructureEdited(this, EventArgs.Empty);
        }

        // ---- the list of images of the selected tool (InputImage / Train / OutputImage ...), chosen by the host ----
        public event EventHandler ImagesChanged;

        public string[] GetImageNames()
        {
            System.Windows.Forms.ComboBox cb = SvDisplayViewEdit.imageListComboBox;
            string[] names = new string[cb.Items.Count];
            for (int i = 0; i < names.Length; i++) names[i] = cb.Items[i].ToString();
            return names;
        }

        public int SelectedImageIndex
        {
            get { return SvDisplayViewEdit.imageListComboBox.SelectedIndex; }
            set
            {
                System.Windows.Forms.ComboBox cb = SvDisplayViewEdit.imageListComboBox;
                if (value >= 0 && value < cb.Items.Count) cb.SelectedIndex = value;
            }
        }

        /// <summary>The image list drop-down above the image is hidden while the host shows the list itself.</summary>
        public bool ImageComboVisible
        {
            get { return SvDisplayViewEdit.imageListComboBox.Visible; }
            set { SvDisplayViewEdit.imageListComboBox.Visible = value; }
        }

        // ---- editors in a host panel of their own (the WPF column at the right) ----
        Panel externalDock;
        bool externalOpen;

        /// <summary>The tool editor is shown in the returned panel (by the host) instead of beside the image.</summary>
        public Panel UseExternalDock()
        {
            externalDock = new Panel();
            externalDock.Dock = DockStyle.Fill;
            dockHost = externalDock;
            return externalDock;
        }

        /// <summary>A docked editor was shown for this tool (or another tool was selected).</summary>
        public event EventHandler<SvToolEventArgs> DockOpened;
        public event EventHandler DockClosed;
        public event EventHandler DockedTabChanged;

        public void HideImageSelector() { SvDisplayViewEdit.HideImageSelector(); }

        /// <summary>The host draws the image selector, the tool bar under the image and the status bar: hide the ones of the editor.</summary>
        public void UseHostChrome()
        {
            SvDisplayViewEdit.UseHostToolbar();
            HideStatusStrip();
        }

        /// <summary>The bar under the image (zoom, auto-fit, coordinates) that the host drives.</summary>
        public SvMip.Display.SvDisplayViewStatusBar DisplayBar { get { return SvDisplayViewEdit.StatusBar; } }

        /// <summary>Size of the picture that is shown ("640 x 480"), empty when there is none.</summary>
        public string CurrentImageSize
        {
            get
            {
                try
                {
                    SvImage img = SvDisplayViewEdit.Display.Image;
                    if (img == null || img.IsNull || img.Width <= 0 || img.Height <= 0) return "";
                    return string.Format("{0} \u00D7 {1}", img.Width, img.Height);
                }
                catch (Exception) { return ""; }
            }
        }
        /// <summary>Shows another picture of the tool; zoom and position are kept, as with a click on the list.</summary>
        public void SelectImage(int index) { SvDisplayViewEdit.SelectImage(index); }

        public SvToolEditBase DockedEditorNow { get { return dockedEditor; } }

        /// <summary>Runs the tool shown in the docked editor (the WPF form calls this after a value changed) and redraws the image.</summary>
        public void PreviewTool(SvToolBase tool)
        {
            if (dockedEditor != null) dockedEditor.RunTool();
        }

        /// <summary>The values of the tool were changed from outside: the old editor reads them again (used when switching back to it).</summary>
        public void RefreshDockedEditor()
        {
            if (dockedEditor != null && dockedTool != null) dockedEditor.SetSubject(dockedTool);
        }

        bool DockIsOpen
        {
            get { return externalDock != null ? externalOpen : (dockHost != null && dockHost.Visible); }
        }

        public void CloseDock()
        {
            CloseDockedEditor();
        }

        public System.Collections.Generic.List<Type> GetToolTypes()
        {
            return svToolBlockTree.GetToolTypes();
        }


        /// <summary>Short messages (saved, save failed). When nobody listens a MessageBox is shown, as before.</summary>
        public event EventHandler<SvNoticeEventArgs> Notice;

        void RaiseNotice(string message, bool isError)
        {
            if (Notice != null) Notice(this, new SvNoticeEventArgs(message, isError));
            else MessageBox.Show(message);
        }

        string filePath = "";
        /// <summary>Full path of the job file that is edited. When it exists, Save writes to it without asking.</summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FilePath
        {
            get { return filePath; }
            set { filePath = value ?? ""; }
        }
        public SvJobEdit()
        {
            InitializeComponent();
            
            svToolBlockTree.ToolSelect += svToolBlockTree_ToolSelect;
            svToolBlockTree.ToolEditRequested += svToolBlockTree_ToolEditRequested;
            InitRunTimeTab();
            SvDisplayViewEdit.SelectedImageChanged += delegate { if (ImagesChanged != null) ImagesChanged(this, EventArgs.Empty); };
            this.Disposed += (a, b) => { SvDisplayViewEdit.Display.Dispose();  };
        }

        // "Run time" tab: one bar per tool
        SvRunTimePanel runTimePanel;

        void InitRunTimeTab()
        {
            runTimePanel = new SvRunTimePanel();
            TabPage page = new TabPage("Run time");
            page.Padding = new Padding(0);
            page.Controls.Add(runTimePanel);
            tabControl.TabPages.Add(page);
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            IsToolListButtonVisible = true;
            IsAutoRunButtonVisible = true;
            base.OnLayout(e);
            if (externalDock == null && dockHost != null && dockHost.Visible)
                SvDisplayViewEdit.Width = Math.Max(100, dockHost.Left - SvDisplayViewEdit.Left);
        }

        // ---- editor docked at the right of the image (Pattern / Setting / Output tabs of the tool) ----
        Panel dockHost;
        Label dockTitle;
        SvToolBase dockedTool;                             // the tool of the docked editor
        SvToolEditBase dockedEditor;                       // the editor that is shown now
        Dictionary<Type, SvToolEditBase> dockedEditors = new Dictionary<Type, SvToolEditBase>(); // one per tool type, created when first needed
        AnchorStyles savedDisplayAnchor;
        const int DockWidth = 470;

        /// <summary>Tools that have a docked editor. The others keep opening their own window.</summary>
        static readonly string[] DockedTools = new string[]
        {
            "SvHandEye", "SvMaster", "SvSplit", "SvTemplateMatch", "SvBlob", "SvBlur", "SvEdge", "SvSend", "SvTrigger", "SvConnection", "SvIf", "SvFor", "SvAlign",
            "SvDataLog", "SvImageSave", "SvRotation", "SvMorphology", "SvJudgement", "SvImageConverter", "SvImageCalculate",
            "SvMeasureSharpness",
            "SvAcquisition", "SvBarcode", "SvCameraCalibration", "SvCaliper", "SvDataAnalysis", "SvDistance2P", "SvDistance3P",
            "SvEqualizer", "SvFindLine", "SvFindParallelLine", "SvFixture", "SvHistogram", "SvIntersectLine", "SvJudgementOverpocket",
            "SvMakeLattice", "SvMakeLine", "SvMakePoint", "SvMakePoint2", "SvMakeRectFromLine", "SvMakeRegions", "SvMasking",
            "SvRegion", "SvResultAnalysis", "SvSharpness", "SvSubImage", "SvTemplateMatchOverpocket", "SvWarpping", "SvWarppingPoint", "SvToolBlock"
        };

        /// <summary>The editor class of a tool that can be docked (SvBlob -> SvBlobEdit), or null.</summary>
        static Type DockedEditorType(SvToolBase tool)
        {
            if (tool == null) return null;
            string name = tool.GetType().Name;
            if (Array.IndexOf(DockedTools, name) < 0) return null;
            string editName = name == "SvAcquisition" ? "SvAcqisitionEdit" : name + "Edit";   // the old editor of SvAcquisition is spelled SvAcqisitionEdit
            Type t = typeof(SvJobEdit).Assembly.GetType("SvMip.Edit." + editName);
            return (t != null && typeof(SvToolEditBase).IsAssignableFrom(t)) ? t : null;
        }

        static bool HasDockedEditor(SvToolBase tool)
        {
            return DockedEditorType(tool) != null;
        }

        SvToolEditBase GetDockedEditor(SvToolBase tool)
        {
            Type type = DockedEditorType(tool);
            SvToolEditBase editor;
            if (!dockedEditors.TryGetValue(type, out editor))
            {
                editor = (SvToolEditBase)Activator.CreateInstance(type);
                editor.Dock = DockStyle.Fill;
                editor.UseSharedDisplay(SvDisplayViewEdit);
                if (externalDock != null)
                {
                    editor.PrepareForExternalHost();
                    SvTemplateMatchEdit tm = editor as SvTemplateMatchEdit;
                    if (tm != null) tm.NativeUi = true; // the WPF panel draws this editor
                    SvToolBlockEdit tb = editor as SvToolBlockEdit;
                    if (tb != null) tb.InterfaceChanged += delegate { svToolBlockTree.RedrawAllNode(); if (JobStructureEdited != null) JobStructureEdited(this, EventArgs.Empty); };
                    editor.SelectedTabChanged += delegate { if (DockedTabChanged != null) DockedTabChanged(this, EventArgs.Empty); };
                }
                editor.Visible = false;
                dockHost.Controls.Add(editor);
                dockHost.Controls.SetChildIndex(editor, 0);
                dockedEditors[type] = editor;
            }
            return editor;
        }

        void ShowDockedEditor(SvToolBase tool)
        {
            SvToolEditBase editor = GetDockedEditor(tool);
            if (!object.ReferenceEquals(editor, dockedEditor))
            {
                if (dockedEditor != null)
                {
                    dockedEditor.SetSharedActive(false);
                    dockedEditor.Visible = false;
                }
                dockedEditor = editor;
                dockedEditor.Visible = true;
                dockedEditor.SetSharedActive(true);
            }
            dockedTool = tool;
            dockedEditor.SetSubject(tool);
            if (dockTitle != null) dockTitle.Text = tool.ToString();
            if (externalDock != null && DockOpened != null) DockOpened(this, new SvToolEventArgs(tool));
        }

        bool svToolBlockTree_ToolEditRequested(object sender, SvToolBase tool)
        {
            if (!HasDockedEditor(tool)) return false;
            try
            {
                OpenDockedEditor(tool);
                return true;
            }
            catch (Exception ex)
            {
                CloseDockedEditor();
                MessageBox.Show(ex.ToString(), "Tool editor", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        void BuildDockHost()
        {
            dockHost = new Panel();
            dockHost.Visible = false;
            dockHost.BorderStyle = BorderStyle.FixedSingle;

            Panel header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 26;
            header.BackColor = Color.FromArgb(30, 35, 40);

            Button close = new Button();
            close.Text = "×";
            close.Dock = DockStyle.Right;
            close.Width = 30;
            close.FlatStyle = FlatStyle.Flat;
            close.FlatAppearance.BorderSize = 0;
            close.ForeColor = Color.White;
            close.Click += delegate { CloseDockedEditor(); };

            dockTitle = new Label();
            dockTitle.Dock = DockStyle.Fill;
            dockTitle.ForeColor = Color.White;
            dockTitle.Font = new Font(Font, FontStyle.Bold);
            dockTitle.TextAlign = ContentAlignment.MiddleLeft;
            dockTitle.Padding = new Padding(6, 0, 0, 0);

            header.Controls.Add(dockTitle);
            header.Controls.Add(close);

            dockHost.Controls.Add(header);
            Controls.Add(dockHost);
        }

        void OpenDockedEditor(SvToolBase tool)
        {
            if (externalDock != null)
            {
                externalOpen = true;
                ShowDockedEditor(tool);
                return;
            }
            if (dockHost == null) BuildDockHost();
            if (!dockHost.Visible)
            {
                Control display = SvDisplayViewEdit;
                int right = display.Right;
                int width = Math.Min(DockWidth, Math.Max(300, right - display.Left - 200));
                savedDisplayAnchor = display.Anchor;
                dockHost.Anchor = AnchorStyles.Top | AnchorStyles.Left;
                dockHost.SetBounds(right - width, display.Top, width, display.Height);
                dockHost.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
                display.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
                display.Width = dockHost.Left - display.Left;
                dockHost.Visible = true;
                dockHost.BringToFront();
            }
            ShowDockedEditor(tool);
        }

        void CloseDockedEditor()
        {
            if (externalDock != null)
            {
                if (dockedEditor != null)
                {
                    dockedEditor.SetSharedActive(false);
                    dockedEditor.Visible = false;
                    dockedEditor = null;
                }
                if (externalOpen)
                {
                    externalOpen = false;
                    if (DockClosed != null) DockClosed(this, EventArgs.Empty);
                }
                SvDisplayViewEdit.RefreshImage();
                return;
            }
            if (dockHost == null || !dockHost.Visible) return;
            if (dockedEditor != null)
            {
                dockedEditor.SetSharedActive(false);
                dockedEditor.Visible = false;
                dockedEditor = null;
            }
            Control display = SvDisplayViewEdit;
            int right = dockHost.Right;
            dockHost.Visible = false;
            display.Anchor = savedDisplayAnchor;
            display.Width = right - display.Left;
            SvDisplayViewEdit.RefreshImage();
        }
        
        void svToolBlockTree_ToolSelect(object sender, SvToolBase tool)
        {
            if (DockIsOpen)
            {
                if (HasDockedEditor(tool))
                {
                    ShowDockedEditor(tool);
                }
                else
                    CloseDockedEditor();
            }
            base.SvDisplayViewEdit.Subject = tool;
            if (ToolSelected != null) ToolSelected(this, new SvToolEventArgs(tool));
        }

        protected override void tsb_ToolList_Click(object sender, EventArgs e)
        {
            svToolBlockTree.ShowToolList();
        }

        /// <summary>Shows the tool with this name in the editor (used by the job check panel). Returns false when no tool has that name.</summary>
        public bool ShowToolByName(string name)
        {
            if (string.IsNullOrEmpty(name) || Job == null) return false;
            SvToolBase found = FindTool(Job, name, 0);
            if (found == null) return false;
            base.SvDisplayViewEdit.Subject = found;
            return true;
        }

        static SvToolBase FindTool(SvJob job, string name, int depth)
        {
            if (job == null || depth > 8) return null;
            foreach (SvToolBase t in job.ToolList)
            {
                if (string.Equals(t.ToString(), name, StringComparison.OrdinalIgnoreCase)) return t;
                SvToolBlock block = t as SvToolBlock;
                if (block != null)
                {
                    SvToolBase inner = FindTool(block.ToolJob, name, depth + 1);
                    if (inner != null) return inner;
                }
            }
            return null;
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvJob Job
        {
            get { return svToolBlockTree.Job; }
            set
            {
                CloseDockedEditor(); svToolBlockTree.Job = value; SvSourceContext.Job = value; lbl_CurrentJob.Text = value.Name;
                if (JobLoaded != null) JobLoaded(this, EventArgs.Empty);
            }
        }

        /// <summary>Asks for a .job (or .tlf) file and loads it; the host calls this from its own "Open job" button.</summary>
        public void OpenJobFile()
        {
            tsb_Load_Click(this, EventArgs.Empty);
        }

        protected override void tsb_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.InitialDirectory = PATH_JOB;
            fd.Filter = "Job files (*.job)|*.job|ToolBlock files (*.tlf)|*.tlf|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.Multiselect = false;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;
            this.Cursor = Cursors.WaitCursor;
            SvJob job = null;
            SvToolBase tool;
            string extension = System.IO.Path.GetExtension(fd.FileName).ToLower();

            if (extension.Equals(".job"))
            {
                job = serializer.LoadJob(fd.FileName);
                filePath = fd.FileName;
            }
            else if (extension.Equals(".tlf"))
            {
                tool = serializer.LoadTool(fd.FileName);
                if (!(tool is SvToolBlock))
                    return;
                job = (tool as SvToolBlock).ToolJob;
                filePath = ""; // a ToolBlock file is not saved back as .tlf: Save asks for a .job file name
            }
            
            this.Cursor = Cursors.Default;

            if (job == null)
            {
                MessageBox.Show("Job load fail");
                return;
            }

            if (Job == null) Job = job;   // no job is open yet: the loaded one becomes the job
            else Job.ToolList = job.ToolList;
            svToolBlockTree.RedrawAllNode();

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);

            base.SvDisplayViewEdit.ClearImage();
            if (JobLoaded != null) JobLoaded(this, EventArgs.Empty);
        }

        protected override void tsb_Save_Click(object sender, EventArgs e)
        {
            SaveJob(false);
        }

        /// <summary>
        /// Saves the job. Without saveAs the job is written to FilePath when that file exists (no dialog);
        /// otherwise, or with saveAs, a file dialog asks for the name. Returns true when the job was saved.
        /// </summary>
        public bool SaveJob(bool saveAs)
        {
            if (Job == null) return false;

            string target = filePath;
            if (saveAs || string.IsNullOrEmpty(target) || !System.IO.File.Exists(target))
            {
                SaveFileDialog fd = new SaveFileDialog();
                fd.InitialDirectory = PATH_JOB;
                fd.FileName = lbl_CurrentJob.Text;
                fd.Filter = "Job files (*.job)|*.job|All files (*.*)|*.*";
                fd.FilterIndex = 1;
                fd.DefaultExt = "*.job";
                if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return false;
                target = fd.FileName;
            }

            string name = System.IO.Path.GetFileNameWithoutExtension(target);
            lbl_CurrentJob.Text = name;
            Job.Name = name;
            this.Cursor = Cursors.WaitCursor;
            bool success;
            SvJobHistory.Backup(target); // keep the file that is about to be replaced
            try { success = serializer.SaveJob(Job, target); }
            finally { this.Cursor = Cursors.Default; }

            if (!success)
            {
                RaiseNotice("Job save failed: " + name, true);
                return false;
            }
            filePath = target;
            RaiseNotice("Job saved: " + name, false);
            if (OnSaved != null) OnSaved(this, null);
            return true;
        }
        
        protected override void tsb_Run_Click(object sender, EventArgs e)
        {
            if (Job != null)
                Job.Run(true);

            float zoom = svDisplayViewEdit.Display.ZoomRatio;
            System.Drawing.Point location = svDisplayViewEdit.Display.imageLocation;

            UpdateDisplay();

            if (zoom != 1 || location != new System.Drawing.Point(0, 0))
            {
                svDisplayViewEdit.Display.ZoomRatio = zoom;
                svDisplayViewEdit.Display.imageLocation = location;
            }
        }
        
        void UpdateDisplay()
        {
            if (Job != null)
            {
                Job.OnRan();

                if (Job.LastRunSuccess)
                    ToolStatusImage = global::SvMip.Properties.Resources.SuccessIcon;
                else
                    ToolStatusImage = global::SvMip.Properties.Resources.FailIcon;

                LastRunFailed = !Job.LastRunSuccess;
                ToolStatusText = string.Format("{0:F2}ms", Job.LastRunTime);
            }
            
            SvDisplayViewEdit.RefreshImage();
            svToolBlockTree.ShowRunTimes();
            if (runTimePanel != null) runTimePanel.SetTimes(svToolBlockTree.GetRunTimes());
            svToolBlockTree.Refresh();
            if (JobRan != null) JobRan(this, EventArgs.Empty);
            //svToolBlockTree.RedrawAllNode();
        }

        System.Threading.CancellationTokenSource autoRunTokenSource = new System.Threading.CancellationTokenSource();

        protected override void tsb_AutoRun_Click(object sender, EventArgs e)
        {            
            if(base.IsAutoRunning)
            {
                autoRunTokenSource.Cancel(true);
                autoRunTokenSource.Dispose();
            }
            else
            {
                base.IsAutoRunning = true;
                autoRunTokenSource = new System.Threading.CancellationTokenSource();
                Task autoRunTask = Task.Factory.StartNew(()=>
                    {
                        SvAcquisition acq = Job["Acquisition"] as SvAcquisition;
                        while(true)
                        {
                            if (Job != null) Job.Run(true);
                            this.Invoke(new Action(UpdateDisplay));
                            //System.Threading.Thread.Sleep(40);

                            if (autoRunTokenSource.Token == null)
                                break;
                            if (autoRunTokenSource.Token.IsCancellationRequested)
                                autoRunTokenSource.Token.ThrowIfCancellationRequested();

                            if (acq != null && acq.CameraType == CameraType.Image && acq.CurrentImageIndex == acq.InputImageList.Count)
                                break;
                        }
                    }, autoRunTokenSource.Token).ContinueWith((task)=>
                    {
                        base.IsAutoRunning = false;
                    });                
            }
        }

        public void Run()
        {
            tsb_Run_Click(null, null);
        }
    }

    /// <summary>What the WPF tool list needs from the owner of a job: the main job editor, or the inside of a tool block.</summary>
    public interface IToolListHost
    {
        SvJob Job { get; }
        /// <summary>Tool block only: the node that gives the inputs of the block to the tools inside it, and the node that collects the outputs.</summary>
        SvToolBase InputNode { get; }
        SvToolBase OutputNode { get; }
        void EditTool(SvToolBase tool);
        void SelectTool(SvToolBase tool);
        void JobStructureChanged();
        System.Collections.Generic.List<Type> GetToolTypes();
        event EventHandler JobLoaded;
        event EventHandler JobRan;
        event EventHandler JobStructureEdited;
        event EventHandler<SvToolEventArgs> ToolSelected;
    }

    public class SvToolEventArgs : EventArgs
    {
        public SvToolEventArgs(SvToolBase tool) { Tool = tool; }
        public SvToolBase Tool { get; private set; }
    }
}
