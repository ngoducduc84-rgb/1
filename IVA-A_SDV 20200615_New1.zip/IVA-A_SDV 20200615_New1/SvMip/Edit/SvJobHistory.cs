﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SvMip.Edit
{
    public class SvJobVersion
    {
        public string File;
        public DateTime SavedAt;
        public long Size;
    }

    /// <summary>
    /// Keeps the last versions of a job file. Before a save overwrites the file, the old file is copied to
    /// "History\JobName_yyyyMMdd_HHmmss.job" next to it (only the newest 10 are kept).
    /// </summary>
    public static class SvJobHistory
    {
        public const int MaxVersions = 10;

        public static string HistoryDir(string jobFile)
        {
            return Path.Combine(Path.GetDirectoryName(jobFile), "History");
        }

        static Regex Pattern(string jobName)
        {
            return new Regex("^" + Regex.Escape(jobName) + @"_(\d{8}_\d{6})\.job$", RegexOptions.IgnoreCase);
        }

        /// <summary>Copies the existing file into the history folder. Never throws (a failed backup must not stop a save).</summary>
        public static void Backup(string jobFile)
        {
            try
            {
                if (string.IsNullOrEmpty(jobFile) || !System.IO.File.Exists(jobFile)) return;
                string dir = HistoryDir(jobFile);
                Directory.CreateDirectory(dir);
                string name = Path.GetFileNameWithoutExtension(jobFile);
                string dest = Path.Combine(dir, name + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".job");
                System.IO.File.Copy(jobFile, dest, true);

                List<SvJobVersion> all = List(jobFile);
                for (int i = MaxVersions; i < all.Count; i++)
                {
                    try { System.IO.File.Delete(all[i].File); } catch { }
                }
            }
            catch { }
        }

        /// <summary>The saved versions of a job, newest first.</summary>
        public static List<SvJobVersion> List(string jobFile)
        {
            List<SvJobVersion> list = new List<SvJobVersion>();
            try
            {
                if (string.IsNullOrEmpty(jobFile)) return list;
                string dir = HistoryDir(jobFile);
                if (!Directory.Exists(dir)) return list;
                Regex re = Pattern(Path.GetFileNameWithoutExtension(jobFile));
                foreach (string f in Directory.GetFiles(dir, "*.job"))
                {
                    Match m = re.Match(Path.GetFileName(f));
                    if (!m.Success) continue;
                    DateTime when;
                    if (!DateTime.TryParseExact(m.Groups[1].Value, "yyyyMMdd_HHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out when)) continue;
                    SvJobVersion v = new SvJobVersion();
                    v.File = f;
                    v.SavedAt = when;
                    v.Size = new FileInfo(f).Length;
                    list.Add(v);
                }
                list.Sort(delegate(SvJobVersion a, SvJobVersion b) { return b.SavedAt.CompareTo(a.SavedAt); });
            }
            catch { }
            return list;
        }
    }

    /// <summary>Lists the saved versions of a job; the chosen one is loaded into the editor (not saved).</summary>
    public class SvJobHistoryDialog : Form
    {
        readonly ListView list = new ListView();
        readonly Button btnOpen = new Button();
        readonly Button btnClose = new Button();

        public string SelectedFile { get; private set; }

        public SvJobHistoryDialog(string jobName, List<SvJobVersion> versions)
        {
            AutoScaleMode = AutoScaleMode.None;
            Font = new Font("Segoe UI", 9f);
            Text = "History of " + jobName;
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            MinimizeBox = false;
            MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            ClientSize = new Size(600, 400);

            Label note = new Label();
            note.SetBounds(10, 8, 580, 36);
            note.Text = "Each Save keeps the file it replaces here (the newest " + SvJobHistory.MaxVersions +
                        "). \"Open this version\" loads it into the editor; press Save to keep it.";

            list.SetBounds(10, 48, 580, 300);
            list.View = View.Details;
            list.FullRowSelect = true;
            list.HideSelection = false;
            list.MultiSelect = false;
            list.Columns.Add("Replaced at", 160);
            list.Columns.Add("Size", 90);
            list.Columns.Add("File", 310);
            foreach (SvJobVersion v in versions)
            {
                ListViewItem item = new ListViewItem(v.SavedAt.ToString("yyyy-MM-dd HH:mm:ss"));
                item.SubItems.Add((v.Size / 1024) + " KB");
                item.SubItems.Add(System.IO.Path.GetFileName(v.File));
                item.Tag = v.File;
                list.Items.Add(item);
            }
            if (list.Items.Count == 0)
                list.Items.Add(new ListViewItem(new string[] { "(no earlier version yet)", "", "" }));
            else
                list.Items[0].Selected = true;
            list.DoubleClick += delegate { Accept(); };

            btnOpen.Text = "Open this version";
            btnOpen.SetBounds(360, 360, 130, 28);
            btnOpen.Click += delegate { Accept(); };
            btnClose.Text = "Close";
            btnClose.SetBounds(496, 360, 94, 28);
            btnClose.DialogResult = DialogResult.Cancel;
            CancelButton = btnClose;

            Controls.Add(note);
            Controls.Add(list);
            Controls.Add(btnOpen);
            Controls.Add(btnClose);
        }

        void Accept()
        {
            if (list.SelectedItems.Count == 0) return;
            string file = list.SelectedItems[0].Tag as string;
            if (string.IsNullOrEmpty(file)) return;
            SelectedFile = file;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
