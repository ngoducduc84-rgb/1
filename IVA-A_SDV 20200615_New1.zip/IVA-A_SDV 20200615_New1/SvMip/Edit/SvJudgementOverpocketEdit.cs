﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    public partial class SvJudgementOverpocketEdit : SvToolEditBase
    {
        public SvJudgementOverpocketEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvJudgementEdit_SubjectChanged;
            //dgv_Threshold.RowsRemoved += Dgv_Threshold_RowsRemoved;

            cb_Comparison1.SelectedValueChanged += Cb_Comparison1_SelectedValueChanged;
            cb_Comparison2.SelectedValueChanged += Cb_Comparison2_SelectedValueChanged;
            cb_Comparison3.SelectedValueChanged += Cb_Comparison3_SelectedValueChanged;
            cb_Comparison4.SelectedValueChanged += Cb_Comparison4_SelectedValueChanged;
        }

        private void Cb_Comparison1_SelectedValueChanged(object sender, EventArgs e)
        {
            //SvJudgementOverpocket.eComparison aaa = (SvJudgementOverpocket.eComparison)cb_Comparison1.SelectedItem;

            nud_Creteria1_.Visible = cb_Comparison1.SelectedItem == "InRange";
        }
        private void Cb_Comparison2_SelectedValueChanged(object sender, EventArgs e)
        {
            nud_Creteria2_.Visible = cb_Comparison2.SelectedItem == "InRange";
        }
        private void Cb_Comparison3_SelectedValueChanged(object sender, EventArgs e)
        {
            nud_Creteria3_.Visible = cb_Comparison3.SelectedItem == "InRange";
        }
        private void Cb_Comparison4_SelectedValueChanged(object sender, EventArgs e)
        {
            nud_Creteria4_.Visible = cb_Comparison4.SelectedItem == "InRange";
        }

        //private void Dgv_Threshold_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        //{
        //    for (int i = 0; i < dgv_Threshold.Rows.Count; i++)
        //    {
        //        dgv_Threshold.Rows[i].Cells[0].Value = i + 1;
        //    }
        //}

        protected override void InitDisplayViewEdit()
        {

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvJudgementOverpocket Subject
        {
            get { return base.GetSubject() as SvJudgementOverpocket; }
            set { base.SetSubject(value); }
        }

        void SvJudgementEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            //dgv_Threshold.CellValueChanged -= dgv_Threshold_CellValueChanged;
            //if (Subject != null && Subject.Thresholds.Count > 0)
            //{
            //    dgv_Threshold.Rows.Clear();

            //    for (int i = 0; i < Subject.Thresholds.Count; i++)
            //    {

            //        dgv_Threshold.Rows.Add(i + 1, Subject.Thresholds[i]);

            //    }
            //}
            //dgv_Threshold.CellValueChanged += dgv_Threshold_CellValueChanged;

            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvJudgementOverpocket), null);

            //cb_Comparison.DisplayMember = "Key"; cb_Comparison.ValueMember = "Value";
            cb_Comparison1.DataSource = SvJudgementOverpocket.ComparisonList.Values.ToList();
            cb_Comparison2.DataSource = SvJudgementOverpocket.ComparisonList.Values.ToList();
            cb_Comparison3.DataSource = SvJudgementOverpocket.ComparisonList.Values.ToList();
            cb_Comparison4.DataSource = SvJudgementOverpocket.ComparisonList.Values.ToList();

            cb_Comparison1.DataBindings.Add("SelectedItem", source, "Comparison1", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_Comparison1.DataBindings.Add("SelectedValue", source, "Comparison1", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_Comparison2.DataBindings.Add("SelectedItem", source, "Comparison2", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_Comparison2.DataBindings.Add("SelectedValue", source, "Comparison2", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_Comparison3.DataBindings.Add("SelectedItem", source, "Comparison3", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_Comparison3.DataBindings.Add("SelectedValue", source, "Comparison3", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_Comparison4.DataBindings.Add("SelectedItem", source, "Comparison4", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_Comparison4.DataBindings.Add("SelectedValue", source, "Comparison4", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_Creteria1.DataBindings.Add("Value", source, "Creteria1", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Creteria1_.DataBindings.Add("Value", source, "Creteria1_", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            lb_Input1.DataBindings.Add("Text", source, "Score", true, DataSourceUpdateMode.OnPropertyChanged);
            lb_Output1.DataBindings.Add("Text", source, "Judgement1", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_Creteria2.DataBindings.Add("Value", source, "Creteria2", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Creteria2_.DataBindings.Add("Value", source, "Creteria2_", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            lb_Input2.DataBindings.Add("Text", source, "X", true, DataSourceUpdateMode.OnPropertyChanged);
            lb_Output2.DataBindings.Add("Text", source, "Judgement2", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_Creteria3.DataBindings.Add("Value", source, "Creteria3", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Creteria3_.DataBindings.Add("Value", source, "Creteria3_", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            lb_Input3.DataBindings.Add("Text", source, "Y", true, DataSourceUpdateMode.OnPropertyChanged);
            lb_Output3.DataBindings.Add("Text", source, "Judgement3", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_Creteria4.DataBindings.Add("Value", source, "Creteria4", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Creteria4_.DataBindings.Add("Value", source, "Creteria4_", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            lb_Input4.DataBindings.Add("Text", source, "T", true, DataSourceUpdateMode.OnPropertyChanged);
            lb_Output4.DataBindings.Add("Text", source, "Judgement4", true, DataSourceUpdateMode.OnPropertyChanged);

        }

        //private void dgv_Threshold_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        //{
        //    if (e.RowIndex < 0) return;
        //    double value = -1;
        //    try
        //    {
        //        // 값을 지웠을 경우 0.0으로 대체
        //        if (dgv_Threshold.Rows[e.RowIndex].Cells[1].Value == null)
        //        {
        //            if (Subject.Thresholds.Count > e.RowIndex)
        //                Subject.Thresholds[e.RowIndex] = 0.0;
        //            return;
        //        }

        //        // double 형변환이 안될 경우, 원복


        //        if (!double.TryParse(dgv_Threshold.Rows[e.RowIndex].Cells[1].Value.ToString(), out value))
        //        {
        //            dgv_Threshold.Rows[e.RowIndex].Cells[1].Value = null;
        //            return;
        //        }

        //        if (Subject.Thresholds.Count > e.RowIndex)   
        //        {
        //            if (value > 30000)
        //            {
        //                dgv_Threshold.Rows[e.RowIndex].Cells[1].Value = 30000;
        //            }

        //        }

        //        // 한참 뒤에 값을 추가할 경우, 중간에 있는 값을 동일값으로 셋팅
        //        while (Subject.Thresholds.Count <= e.RowIndex)
        //        {
        //            Subject.Thresholds.Add(value);
        //            int i = Subject.Thresholds.Count - 1;
        //            dgv_Threshold.Rows[i].Cells[0].Value = i + 1;
        //            dgv_Threshold.Rows[i].Cells[1].Value = value;
        //        }

        //        dgv_Threshold.Rows[e.RowIndex].Cells[0].Value = e.RowIndex + 1;
        //        Subject.Thresholds[e.RowIndex] = value;

        //        //if (e.RowIndex == 0) Subject.Creteria = value;
        //    }
        //    finally
        //    {
        //        // trim
        //        for (int i = dgv_Threshold.Rows.Count - 1; i >= 0 && dgv_Threshold.Rows[i].Cells[1].Value == null; i--)
        //        {
        //            dgv_Threshold.Rows[i].Cells[0].Value = null;
        //            if (Subject.Thresholds.Count > i)
        //            {
        //                Subject.Thresholds.RemoveAt(i);
        //            }
        //        }
        //    }
        //}

    }
}
