﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Text;
//using System.Windows.Forms;
//using System.Linq;

//namespace SvMip.Edit
//{
//    public partial class SvMakePoint2Edit : SvMip.Edit.Base.SvToolEditBase
//    {
//        public SvMakePoint2Edit()
//        {
//            InitializeComponent();
//            InitBinding();
//            this.SubjectChanged += SvPointMakeEdit_SubjectChanged;

//            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;

//        }

//        protected override void InitDisplayViewEdit()
//        { }

//        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
//        {
//            if (imageInfo.ImageName.Contains("Input"))
//            {
//                tabControl.SelectedTab = tb_In_Pers;
//                if (Subject.InputImage == null) return;
//                svDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.OutPoint);
//            }
//            else if (imageInfo.ImageName.Contains("Output"))
//            {
//                if (Subject.InputImage == null) return;
//                SvDisplayViewEdit.Display.Image = Subject.InputImage;
//                //SvDisplayViewEdit.Display.GraphicsCollection.Add(Subject.OutPoint);
//            }
//        }

//        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
//        public SvMakePoint2 Subject
//        {
//            get { return base.GetSubject() as SvMakePoint2; }
//            set { base.SetSubject(value); }
//        }

//        void SvPointMakeEdit_SubjectChanged(object sender, SvToolBase tool)
//        {
//            source.DataSource = Subject;
//            Subject.Ran += Subject_Ran;
//            source.ResetBindings(true);

//            Display_InDrawObjectChanged(this, Subject.X, Subject.Y, Subject.T);
//        }

//        private void Subject_Ran(object sender, SvToolBase tool)
//        {
//            Display_InDrawObjectChanged(this, Subject.X, Subject.Y, Subject.T);
//        }

//        #region InputPoints Event

//        void Display_InDrawObjectChanged(object sender, double x, double y, double t)//IInteractDrawObject drawObject)
//        {
//            if (double.IsNaN(x) || double.IsNaN(y) || double.IsNaN(t)) return;
//            Remove_In_nud_ValueChangedEvent();

//            nud_InP0_X.Value = (decimal)x;
//            nud_InP0_Y.Value = (decimal)y;
//            nud_InP0_T.Value = (decimal)t;

//            Add_In_nud_ValueChangedEvent();
//            if (Subject.OutPoint == null) return;
//            nud_OutP_X.Value = (decimal)Subject.OutPoint.X;
//            nud_OutP_Y.Value = (decimal)Subject.OutPoint.Y;
//            nud_OutP_T.Value = (decimal)(Subject.OutPoint.ThetaRad * 180 / Math.PI);


//        }

//        void Add_In_nud_ValueChangedEvent()
//        {
//            nud_InP0_X.ValueChanged += nud_InputDrawPoint_ValueChanged;
//            nud_InP0_Y.ValueChanged += nud_InputDrawPoint_ValueChanged;
//            nud_InP0_T.ValueChanged += nud_InputDrawPoint_ValueChanged;
//        }

//        void Remove_In_nud_ValueChangedEvent()
//        {
//            nud_InP0_X.ValueChanged -= nud_InputDrawPoint_ValueChanged;
//            nud_InP0_Y.ValueChanged -= nud_InputDrawPoint_ValueChanged;
//            nud_InP0_T.ValueChanged -= nud_InputDrawPoint_ValueChanged;
//        }

//        private void nud_InputDrawPoint_ValueChanged(object sender, EventArgs e)
//        {
//            NumericUpDown nud = sender as NumericUpDown;

//            Subject.X = (double)nud_InP0_X.Value;
//            Subject.Y = (double)nud_InP0_Y.Value;
//            Subject.T = (double)nud_InP0_T.Value;
//            nud_OutP_X.Value = (decimal)Subject.OutPoint.X;
//            nud_OutP_Y.Value = (decimal)Subject.OutPoint.Y;
//            nud_OutP_T.Value = (decimal)(Subject.OutPoint.ThetaRad * 180 / Math.PI);
//            SvDisplayViewEdit.Display.Invalidate();
//        }
//        #endregion

//        BindingSource source;

//        void InitBinding()
//        {
//            source = new BindingSource(typeof(SvWarpping), null);
//            cb_Origin.DisplayMember = "Key"; cb_Origin.ValueMember = "Value";
//            cb_Origin.DataSource = Enum.GetValues(typeof(OffsetControl.OriginDirection)).Cast<OffsetControl.OriginDirection>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
//            cb_Origin.DataBindings.Add("SelectedValue", source, "Origin", true, DataSourceUpdateMode.OnPropertyChanged);
//        }

//        SvImageInfo inPointsImageInfo;
//        SvImageInfo outPointsImageInfo;
//    }
//}
