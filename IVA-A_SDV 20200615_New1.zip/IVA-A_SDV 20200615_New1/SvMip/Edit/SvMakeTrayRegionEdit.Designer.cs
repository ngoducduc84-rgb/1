﻿namespace SvMip.Edit
{
    partial class SvMakeTrayRegionEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_MakeTrayRegion = new System.Windows.Forms.TabPage();
            this.gb_MakeTrayRegion = new System.Windows.Forms.GroupBox();
            this.lbl_Tray_Y = new System.Windows.Forms.Label();
            this.lbl_Tray_Point4 = new System.Windows.Forms.Label();
            this.lbl_Tray_Point3 = new System.Windows.Forms.Label();
            this.lbl_Tray_Point2 = new System.Windows.Forms.Label();
            this.lbl_Tray_Point1 = new System.Windows.Forms.Label();
            this.lbl_Tray_X = new System.Windows.Forms.Label();
            this.nud_MarkRect_P4_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_MarkRect_P4_X = new System.Windows.Forms.NumericUpDown();
            this.nud_MarkRect_P3_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_MarkRect_P3_X = new System.Windows.Forms.NumericUpDown();
            this.nud_MarkRect_P2_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_MarkRect_P2_X = new System.Windows.Forms.NumericUpDown();
            this.nud_MarkRect_P1_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_MarkRect_P1_X = new System.Windows.Forms.NumericUpDown();
            this.gb_MakeRect_Result = new System.Windows.Forms.GroupBox();
            this.nud_MakeRect_Result_Z = new System.Windows.Forms.NumericUpDown();
            this.nud_MakeRect_Result_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_MakeRect_Result_X = new System.Windows.Forms.NumericUpDown();
            this.lbl_MakeRect_Result_Z = new System.Windows.Forms.Label();
            this.lbl_MakeRect_Result_Y = new System.Windows.Forms.Label();
            this.lbl_MakeRect_Result_X = new System.Windows.Forms.Label();
            this.gb_TrayLong = new System.Windows.Forms.GroupBox();
            this.nud_Long_CellToCell = new System.Windows.Forms.NumericUpDown();
            this.nud_Long_CellArea = new System.Windows.Forms.NumericUpDown();
            this.nud_Long_TrayToCell = new System.Windows.Forms.NumericUpDown();
            this.lbl_Long_CellToCell = new System.Windows.Forms.Label();
            this.lbl_Long_CellArea = new System.Windows.Forms.Label();
            this.lbl_Long_TrayToCell = new System.Windows.Forms.Label();
            this.tp_Result = new System.Windows.Forms.TabPage();
            this.gb_TrayShort = new System.Windows.Forms.GroupBox();
            this.nud_Short_CellToCell = new System.Windows.Forms.NumericUpDown();
            this.nud_Short_CellArea = new System.Windows.Forms.NumericUpDown();
            this.nud_Short_TrayToCell = new System.Windows.Forms.NumericUpDown();
            this.lbl_Short_CellToCell = new System.Windows.Forms.Label();
            this.lbl_Short_CellArea = new System.Windows.Forms.Label();
            this.lbl_Short_TrayToCell = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tp_MakeTrayRegion.SuspendLayout();
            this.gb_MakeTrayRegion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P4_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P4_X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P3_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P3_X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P2_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P2_X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P1_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P1_X)).BeginInit();
            this.gb_MakeRect_Result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MakeRect_Result_Z)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MakeRect_Result_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MakeRect_Result_X)).BeginInit();
            this.gb_TrayLong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Long_CellToCell)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Long_CellArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Long_TrayToCell)).BeginInit();
            this.gb_TrayShort.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Short_CellToCell)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Short_CellArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Short_TrayToCell)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_MakeTrayRegion);
            this.tabControl.Controls.Add(this.tp_Result);
            // 
            // tp_MakeTrayRegion
            // 
            this.tp_MakeTrayRegion.Controls.Add(this.gb_MakeTrayRegion);
            this.tp_MakeTrayRegion.Controls.Add(this.gb_TrayShort);
            this.tp_MakeTrayRegion.Controls.Add(this.gb_TrayLong);
            this.tp_MakeTrayRegion.Controls.Add(this.gb_MakeRect_Result);
            this.tp_MakeTrayRegion.Location = new System.Drawing.Point(4, 22);
            this.tp_MakeTrayRegion.Name = "tp_MakeTrayRegion";
            this.tp_MakeTrayRegion.Padding = new System.Windows.Forms.Padding(3);
            this.tp_MakeTrayRegion.Size = new System.Drawing.Size(442, 426);
            this.tp_MakeTrayRegion.TabIndex = 0;
            this.tp_MakeTrayRegion.Text = "MakeTrayRegion";
            this.tp_MakeTrayRegion.UseVisualStyleBackColor = true;
            // 
            // gb_MakeTrayRegion
            // 
            this.gb_MakeTrayRegion.Controls.Add(this.lbl_Tray_Y);
            this.gb_MakeTrayRegion.Controls.Add(this.lbl_Tray_Point4);
            this.gb_MakeTrayRegion.Controls.Add(this.lbl_Tray_Point3);
            this.gb_MakeTrayRegion.Controls.Add(this.lbl_Tray_Point2);
            this.gb_MakeTrayRegion.Controls.Add(this.lbl_Tray_Point1);
            this.gb_MakeTrayRegion.Controls.Add(this.lbl_Tray_X);
            this.gb_MakeTrayRegion.Controls.Add(this.nud_MarkRect_P4_Y);
            this.gb_MakeTrayRegion.Controls.Add(this.nud_MarkRect_P4_X);
            this.gb_MakeTrayRegion.Controls.Add(this.nud_MarkRect_P3_Y);
            this.gb_MakeTrayRegion.Controls.Add(this.nud_MarkRect_P3_X);
            this.gb_MakeTrayRegion.Controls.Add(this.nud_MarkRect_P2_Y);
            this.gb_MakeTrayRegion.Controls.Add(this.nud_MarkRect_P2_X);
            this.gb_MakeTrayRegion.Controls.Add(this.nud_MarkRect_P1_Y);
            this.gb_MakeTrayRegion.Controls.Add(this.nud_MarkRect_P1_X);
            this.gb_MakeTrayRegion.Location = new System.Drawing.Point(6, 6);
            this.gb_MakeTrayRegion.Name = "gb_MakeTrayRegion";
            this.gb_MakeTrayRegion.Size = new System.Drawing.Size(256, 149);
            this.gb_MakeTrayRegion.TabIndex = 34;
            this.gb_MakeTrayRegion.TabStop = false;
            this.gb_MakeTrayRegion.Text = "Tray Region";
            // 
            // lbl_Tray_Y
            // 
            this.lbl_Tray_Y.AutoSize = true;
            this.lbl_Tray_Y.Location = new System.Drawing.Point(184, 16);
            this.lbl_Tray_Y.Name = "lbl_Tray_Y";
            this.lbl_Tray_Y.Size = new System.Drawing.Size(13, 12);
            this.lbl_Tray_Y.TabIndex = 52;
            this.lbl_Tray_Y.Text = "Y";
            // 
            // lbl_Tray_Point4
            // 
            this.lbl_Tray_Point4.AutoSize = true;
            this.lbl_Tray_Point4.Location = new System.Drawing.Point(14, 114);
            this.lbl_Tray_Point4.Name = "lbl_Tray_Point4";
            this.lbl_Tray_Point4.Size = new System.Drawing.Size(31, 12);
            this.lbl_Tray_Point4.TabIndex = 52;
            this.lbl_Tray_Point4.Text = "P4 : ";
            // 
            // lbl_Tray_Point3
            // 
            this.lbl_Tray_Point3.AutoSize = true;
            this.lbl_Tray_Point3.Location = new System.Drawing.Point(14, 87);
            this.lbl_Tray_Point3.Name = "lbl_Tray_Point3";
            this.lbl_Tray_Point3.Size = new System.Drawing.Size(31, 12);
            this.lbl_Tray_Point3.TabIndex = 52;
            this.lbl_Tray_Point3.Text = "P3 : ";
            // 
            // lbl_Tray_Point2
            // 
            this.lbl_Tray_Point2.AutoSize = true;
            this.lbl_Tray_Point2.Location = new System.Drawing.Point(14, 60);
            this.lbl_Tray_Point2.Name = "lbl_Tray_Point2";
            this.lbl_Tray_Point2.Size = new System.Drawing.Size(31, 12);
            this.lbl_Tray_Point2.TabIndex = 52;
            this.lbl_Tray_Point2.Text = "P2 : ";
            // 
            // lbl_Tray_Point1
            // 
            this.lbl_Tray_Point1.AutoSize = true;
            this.lbl_Tray_Point1.Location = new System.Drawing.Point(14, 33);
            this.lbl_Tray_Point1.Name = "lbl_Tray_Point1";
            this.lbl_Tray_Point1.Size = new System.Drawing.Size(31, 12);
            this.lbl_Tray_Point1.TabIndex = 52;
            this.lbl_Tray_Point1.Text = "P1 : ";
            // 
            // lbl_Tray_X
            // 
            this.lbl_Tray_X.AutoSize = true;
            this.lbl_Tray_X.Location = new System.Drawing.Point(91, 16);
            this.lbl_Tray_X.Name = "lbl_Tray_X";
            this.lbl_Tray_X.Size = new System.Drawing.Size(13, 12);
            this.lbl_Tray_X.TabIndex = 52;
            this.lbl_Tray_X.Text = "X";
            // 
            // nud_MarkRect_P4_Y
            // 
            this.nud_MarkRect_P4_Y.DecimalPlaces = 3;
            this.nud_MarkRect_P4_Y.Location = new System.Drawing.Point(143, 112);
            this.nud_MarkRect_P4_Y.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MarkRect_P4_Y.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_MarkRect_P4_Y.Name = "nud_MarkRect_P4_Y";
            this.nud_MarkRect_P4_Y.Size = new System.Drawing.Size(90, 21);
            this.nud_MarkRect_P4_Y.TabIndex = 50;
            this.nud_MarkRect_P4_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MarkRect_P4_Y.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MarkRect_P4_X
            // 
            this.nud_MarkRect_P4_X.DecimalPlaces = 3;
            this.nud_MarkRect_P4_X.Location = new System.Drawing.Point(47, 112);
            this.nud_MarkRect_P4_X.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MarkRect_P4_X.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_MarkRect_P4_X.Name = "nud_MarkRect_P4_X";
            this.nud_MarkRect_P4_X.Size = new System.Drawing.Size(90, 21);
            this.nud_MarkRect_P4_X.TabIndex = 51;
            this.nud_MarkRect_P4_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MarkRect_P4_X.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MarkRect_P3_Y
            // 
            this.nud_MarkRect_P3_Y.DecimalPlaces = 3;
            this.nud_MarkRect_P3_Y.Location = new System.Drawing.Point(143, 85);
            this.nud_MarkRect_P3_Y.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MarkRect_P3_Y.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_MarkRect_P3_Y.Name = "nud_MarkRect_P3_Y";
            this.nud_MarkRect_P3_Y.Size = new System.Drawing.Size(90, 21);
            this.nud_MarkRect_P3_Y.TabIndex = 48;
            this.nud_MarkRect_P3_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MarkRect_P3_Y.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MarkRect_P3_X
            // 
            this.nud_MarkRect_P3_X.DecimalPlaces = 3;
            this.nud_MarkRect_P3_X.Location = new System.Drawing.Point(47, 85);
            this.nud_MarkRect_P3_X.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MarkRect_P3_X.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_MarkRect_P3_X.Name = "nud_MarkRect_P3_X";
            this.nud_MarkRect_P3_X.Size = new System.Drawing.Size(90, 21);
            this.nud_MarkRect_P3_X.TabIndex = 49;
            this.nud_MarkRect_P3_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MarkRect_P3_X.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MarkRect_P2_Y
            // 
            this.nud_MarkRect_P2_Y.DecimalPlaces = 3;
            this.nud_MarkRect_P2_Y.Location = new System.Drawing.Point(143, 58);
            this.nud_MarkRect_P2_Y.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MarkRect_P2_Y.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_MarkRect_P2_Y.Name = "nud_MarkRect_P2_Y";
            this.nud_MarkRect_P2_Y.Size = new System.Drawing.Size(90, 21);
            this.nud_MarkRect_P2_Y.TabIndex = 47;
            this.nud_MarkRect_P2_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MarkRect_P2_Y.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MarkRect_P2_X
            // 
            this.nud_MarkRect_P2_X.DecimalPlaces = 3;
            this.nud_MarkRect_P2_X.Location = new System.Drawing.Point(47, 58);
            this.nud_MarkRect_P2_X.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MarkRect_P2_X.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_MarkRect_P2_X.Name = "nud_MarkRect_P2_X";
            this.nud_MarkRect_P2_X.Size = new System.Drawing.Size(90, 21);
            this.nud_MarkRect_P2_X.TabIndex = 46;
            this.nud_MarkRect_P2_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MarkRect_P2_X.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MarkRect_P1_Y
            // 
            this.nud_MarkRect_P1_Y.DecimalPlaces = 3;
            this.nud_MarkRect_P1_Y.Location = new System.Drawing.Point(143, 31);
            this.nud_MarkRect_P1_Y.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MarkRect_P1_Y.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_MarkRect_P1_Y.Name = "nud_MarkRect_P1_Y";
            this.nud_MarkRect_P1_Y.Size = new System.Drawing.Size(90, 21);
            this.nud_MarkRect_P1_Y.TabIndex = 44;
            this.nud_MarkRect_P1_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MarkRect_P1_Y.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MarkRect_P1_X
            // 
            this.nud_MarkRect_P1_X.DecimalPlaces = 3;
            this.nud_MarkRect_P1_X.Location = new System.Drawing.Point(47, 31);
            this.nud_MarkRect_P1_X.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MarkRect_P1_X.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_MarkRect_P1_X.Name = "nud_MarkRect_P1_X";
            this.nud_MarkRect_P1_X.Size = new System.Drawing.Size(90, 21);
            this.nud_MarkRect_P1_X.TabIndex = 45;
            this.nud_MarkRect_P1_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MarkRect_P1_X.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // gb_MakeRect_Result
            // 
            this.gb_MakeRect_Result.Controls.Add(this.nud_MakeRect_Result_Z);
            this.gb_MakeRect_Result.Controls.Add(this.nud_MakeRect_Result_Y);
            this.gb_MakeRect_Result.Controls.Add(this.nud_MakeRect_Result_X);
            this.gb_MakeRect_Result.Controls.Add(this.lbl_MakeRect_Result_Z);
            this.gb_MakeRect_Result.Controls.Add(this.lbl_MakeRect_Result_Y);
            this.gb_MakeRect_Result.Controls.Add(this.lbl_MakeRect_Result_X);
            this.gb_MakeRect_Result.Location = new System.Drawing.Point(268, 6);
            this.gb_MakeRect_Result.Name = "gb_MakeRect_Result";
            this.gb_MakeRect_Result.Size = new System.Drawing.Size(168, 149);
            this.gb_MakeRect_Result.TabIndex = 30;
            this.gb_MakeRect_Result.TabStop = false;
            this.gb_MakeRect_Result.Text = "Result";
            // 
            // nud_MakeRect_Result_Z
            // 
            this.nud_MakeRect_Result_Z.DecimalPlaces = 3;
            this.nud_MakeRect_Result_Z.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_MakeRect_Result_Z.Location = new System.Drawing.Point(56, 113);
            this.nud_MakeRect_Result_Z.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MakeRect_Result_Z.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_MakeRect_Result_Z.Name = "nud_MakeRect_Result_Z";
            this.nud_MakeRect_Result_Z.Size = new System.Drawing.Size(90, 21);
            this.nud_MakeRect_Result_Z.TabIndex = 18;
            this.nud_MakeRect_Result_Z.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MakeRect_Result_Z.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MakeRect_Result_Y
            // 
            this.nud_MakeRect_Result_Y.DecimalPlaces = 3;
            this.nud_MakeRect_Result_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_MakeRect_Result_Y.Location = new System.Drawing.Point(56, 78);
            this.nud_MakeRect_Result_Y.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MakeRect_Result_Y.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_MakeRect_Result_Y.Name = "nud_MakeRect_Result_Y";
            this.nud_MakeRect_Result_Y.Size = new System.Drawing.Size(90, 21);
            this.nud_MakeRect_Result_Y.TabIndex = 18;
            this.nud_MakeRect_Result_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MakeRect_Result_Y.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_MakeRect_Result_X
            // 
            this.nud_MakeRect_Result_X.DecimalPlaces = 3;
            this.nud_MakeRect_Result_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_MakeRect_Result_X.Location = new System.Drawing.Point(56, 43);
            this.nud_MakeRect_Result_X.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_MakeRect_Result_X.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_MakeRect_Result_X.Name = "nud_MakeRect_Result_X";
            this.nud_MakeRect_Result_X.Size = new System.Drawing.Size(90, 21);
            this.nud_MakeRect_Result_X.TabIndex = 18;
            this.nud_MakeRect_Result_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_MakeRect_Result_X.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // lbl_MakeRect_Result_Z
            // 
            this.lbl_MakeRect_Result_Z.AutoSize = true;
            this.lbl_MakeRect_Result_Z.Location = new System.Drawing.Point(27, 115);
            this.lbl_MakeRect_Result_Z.Name = "lbl_MakeRect_Result_Z";
            this.lbl_MakeRect_Result_Z.Size = new System.Drawing.Size(21, 12);
            this.lbl_MakeRect_Result_Z.TabIndex = 17;
            this.lbl_MakeRect_Result_Z.Text = "Z :";
            // 
            // lbl_MakeRect_Result_Y
            // 
            this.lbl_MakeRect_Result_Y.AutoSize = true;
            this.lbl_MakeRect_Result_Y.Location = new System.Drawing.Point(27, 80);
            this.lbl_MakeRect_Result_Y.Name = "lbl_MakeRect_Result_Y";
            this.lbl_MakeRect_Result_Y.Size = new System.Drawing.Size(21, 12);
            this.lbl_MakeRect_Result_Y.TabIndex = 17;
            this.lbl_MakeRect_Result_Y.Text = "Y :";
            // 
            // lbl_MakeRect_Result_X
            // 
            this.lbl_MakeRect_Result_X.AutoSize = true;
            this.lbl_MakeRect_Result_X.Location = new System.Drawing.Point(27, 45);
            this.lbl_MakeRect_Result_X.Name = "lbl_MakeRect_Result_X";
            this.lbl_MakeRect_Result_X.Size = new System.Drawing.Size(21, 12);
            this.lbl_MakeRect_Result_X.TabIndex = 17;
            this.lbl_MakeRect_Result_X.Text = "X :";
            // 
            // gb_TrayLong
            // 
            this.gb_TrayLong.Controls.Add(this.nud_Long_CellToCell);
            this.gb_TrayLong.Controls.Add(this.nud_Long_CellArea);
            this.gb_TrayLong.Controls.Add(this.nud_Long_TrayToCell);
            this.gb_TrayLong.Controls.Add(this.lbl_Long_CellToCell);
            this.gb_TrayLong.Controls.Add(this.lbl_Long_CellArea);
            this.gb_TrayLong.Controls.Add(this.lbl_Long_TrayToCell);
            this.gb_TrayLong.Location = new System.Drawing.Point(6, 161);
            this.gb_TrayLong.Name = "gb_TrayLong";
            this.gb_TrayLong.Size = new System.Drawing.Size(256, 122);
            this.gb_TrayLong.TabIndex = 30;
            this.gb_TrayLong.TabStop = false;
            this.gb_TrayLong.Text = "Tray Long";
            // 
            // nud_Long_CellToCell
            // 
            this.nud_Long_CellToCell.DecimalPlaces = 3;
            this.nud_Long_CellToCell.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Long_CellToCell.Location = new System.Drawing.Point(143, 86);
            this.nud_Long_CellToCell.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_Long_CellToCell.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_Long_CellToCell.Name = "nud_Long_CellToCell";
            this.nud_Long_CellToCell.Size = new System.Drawing.Size(90, 21);
            this.nud_Long_CellToCell.TabIndex = 18;
            this.nud_Long_CellToCell.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Long_CellToCell.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_Long_CellArea
            // 
            this.nud_Long_CellArea.DecimalPlaces = 3;
            this.nud_Long_CellArea.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Long_CellArea.Location = new System.Drawing.Point(143, 59);
            this.nud_Long_CellArea.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_Long_CellArea.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_Long_CellArea.Name = "nud_Long_CellArea";
            this.nud_Long_CellArea.Size = new System.Drawing.Size(90, 21);
            this.nud_Long_CellArea.TabIndex = 18;
            this.nud_Long_CellArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Long_CellArea.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_Long_TrayToCell
            // 
            this.nud_Long_TrayToCell.DecimalPlaces = 3;
            this.nud_Long_TrayToCell.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Long_TrayToCell.Location = new System.Drawing.Point(143, 32);
            this.nud_Long_TrayToCell.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_Long_TrayToCell.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_Long_TrayToCell.Name = "nud_Long_TrayToCell";
            this.nud_Long_TrayToCell.Size = new System.Drawing.Size(90, 21);
            this.nud_Long_TrayToCell.TabIndex = 18;
            this.nud_Long_TrayToCell.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Long_TrayToCell.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // lbl_Long_CellToCell
            // 
            this.lbl_Long_CellToCell.AutoSize = true;
            this.lbl_Long_CellToCell.Location = new System.Drawing.Point(16, 88);
            this.lbl_Long_CellToCell.Name = "lbl_Long_CellToCell";
            this.lbl_Long_CellToCell.Size = new System.Drawing.Size(80, 12);
            this.lbl_Long_CellToCell.TabIndex = 17;
            this.lbl_Long_CellToCell.Text = "Cell To Cell :";
            // 
            // lbl_Long_CellArea
            // 
            this.lbl_Long_CellArea.AutoSize = true;
            this.lbl_Long_CellArea.Location = new System.Drawing.Point(27, 61);
            this.lbl_Long_CellArea.Name = "lbl_Long_CellArea";
            this.lbl_Long_CellArea.Size = new System.Drawing.Size(65, 12);
            this.lbl_Long_CellArea.TabIndex = 17;
            this.lbl_Long_CellArea.Text = "Cell Area :";
            // 
            // lbl_Long_TrayToCell
            // 
            this.lbl_Long_TrayToCell.AutoSize = true;
            this.lbl_Long_TrayToCell.Location = new System.Drawing.Point(12, 34);
            this.lbl_Long_TrayToCell.Name = "lbl_Long_TrayToCell";
            this.lbl_Long_TrayToCell.Size = new System.Drawing.Size(84, 12);
            this.lbl_Long_TrayToCell.TabIndex = 17;
            this.lbl_Long_TrayToCell.Text = "Tray To Cell :";
            // 
            // tp_Result
            // 
            this.tp_Result.Location = new System.Drawing.Point(4, 22);
            this.tp_Result.Name = "tp_Result";
            this.tp_Result.Size = new System.Drawing.Size(442, 426);
            this.tp_Result.TabIndex = 1;
            this.tp_Result.Text = "Result";
            this.tp_Result.UseVisualStyleBackColor = true;
            // 
            // gb_TrayShort
            // 
            this.gb_TrayShort.Controls.Add(this.nud_Short_CellToCell);
            this.gb_TrayShort.Controls.Add(this.nud_Short_CellArea);
            this.gb_TrayShort.Controls.Add(this.nud_Short_TrayToCell);
            this.gb_TrayShort.Controls.Add(this.lbl_Short_CellToCell);
            this.gb_TrayShort.Controls.Add(this.lbl_Short_CellArea);
            this.gb_TrayShort.Controls.Add(this.lbl_Short_TrayToCell);
            this.gb_TrayShort.Location = new System.Drawing.Point(6, 289);
            this.gb_TrayShort.Name = "gb_TrayShort";
            this.gb_TrayShort.Size = new System.Drawing.Size(256, 122);
            this.gb_TrayShort.TabIndex = 30;
            this.gb_TrayShort.TabStop = false;
            this.gb_TrayShort.Text = "Tray Short";
            // 
            // nud_Short_CellToCell
            // 
            this.nud_Short_CellToCell.DecimalPlaces = 3;
            this.nud_Short_CellToCell.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Short_CellToCell.Location = new System.Drawing.Point(143, 86);
            this.nud_Short_CellToCell.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_Short_CellToCell.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_Short_CellToCell.Name = "nud_Short_CellToCell";
            this.nud_Short_CellToCell.Size = new System.Drawing.Size(90, 21);
            this.nud_Short_CellToCell.TabIndex = 18;
            this.nud_Short_CellToCell.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Short_CellToCell.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_Short_CellArea
            // 
            this.nud_Short_CellArea.DecimalPlaces = 3;
            this.nud_Short_CellArea.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Short_CellArea.Location = new System.Drawing.Point(143, 59);
            this.nud_Short_CellArea.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_Short_CellArea.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_Short_CellArea.Name = "nud_Short_CellArea";
            this.nud_Short_CellArea.Size = new System.Drawing.Size(90, 21);
            this.nud_Short_CellArea.TabIndex = 18;
            this.nud_Short_CellArea.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Short_CellArea.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_Short_TrayToCell
            // 
            this.nud_Short_TrayToCell.DecimalPlaces = 3;
            this.nud_Short_TrayToCell.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Short_TrayToCell.Location = new System.Drawing.Point(143, 32);
            this.nud_Short_TrayToCell.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_Short_TrayToCell.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.nud_Short_TrayToCell.Name = "nud_Short_TrayToCell";
            this.nud_Short_TrayToCell.Size = new System.Drawing.Size(90, 21);
            this.nud_Short_TrayToCell.TabIndex = 18;
            this.nud_Short_TrayToCell.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Short_TrayToCell.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // lbl_Short_CellToCell
            // 
            this.lbl_Short_CellToCell.AutoSize = true;
            this.lbl_Short_CellToCell.Location = new System.Drawing.Point(16, 88);
            this.lbl_Short_CellToCell.Name = "lbl_Short_CellToCell";
            this.lbl_Short_CellToCell.Size = new System.Drawing.Size(80, 12);
            this.lbl_Short_CellToCell.TabIndex = 17;
            this.lbl_Short_CellToCell.Text = "Cell To Cell :";
            // 
            // lbl_Short_CellArea
            // 
            this.lbl_Short_CellArea.AutoSize = true;
            this.lbl_Short_CellArea.Location = new System.Drawing.Point(27, 61);
            this.lbl_Short_CellArea.Name = "lbl_Short_CellArea";
            this.lbl_Short_CellArea.Size = new System.Drawing.Size(65, 12);
            this.lbl_Short_CellArea.TabIndex = 17;
            this.lbl_Short_CellArea.Text = "Cell Area :";
            // 
            // lbl_Short_TrayToCell
            // 
            this.lbl_Short_TrayToCell.AutoSize = true;
            this.lbl_Short_TrayToCell.Location = new System.Drawing.Point(12, 34);
            this.lbl_Short_TrayToCell.Name = "lbl_Short_TrayToCell";
            this.lbl_Short_TrayToCell.Size = new System.Drawing.Size(84, 12);
            this.lbl_Short_TrayToCell.TabIndex = 17;
            this.lbl_Short_TrayToCell.Text = "Tray To Cell :";
            // 
            // SvMakeTrayRegionEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "SvMakeTrayRegionEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_MakeTrayRegion.ResumeLayout(false);
            this.gb_MakeTrayRegion.ResumeLayout(false);
            this.gb_MakeTrayRegion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P4_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P4_X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P3_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P3_X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P2_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P2_X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P1_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MarkRect_P1_X)).EndInit();
            this.gb_MakeRect_Result.ResumeLayout(false);
            this.gb_MakeRect_Result.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MakeRect_Result_Z)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MakeRect_Result_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MakeRect_Result_X)).EndInit();
            this.gb_TrayLong.ResumeLayout(false);
            this.gb_TrayLong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Long_CellToCell)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Long_CellArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Long_TrayToCell)).EndInit();
            this.gb_TrayShort.ResumeLayout(false);
            this.gb_TrayShort.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Short_CellToCell)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Short_CellArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Short_TrayToCell)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_MakeTrayRegion;
        private System.Windows.Forms.GroupBox gb_MakeTrayRegion;
        private System.Windows.Forms.GroupBox gb_MakeRect_Result;
        private System.Windows.Forms.NumericUpDown nud_MakeRect_Result_Z;
        private System.Windows.Forms.NumericUpDown nud_MakeRect_Result_Y;
        private System.Windows.Forms.NumericUpDown nud_MakeRect_Result_X;
        private System.Windows.Forms.Label lbl_MakeRect_Result_Z;
        private System.Windows.Forms.Label lbl_MakeRect_Result_Y;
        private System.Windows.Forms.Label lbl_MakeRect_Result_X;
        private System.Windows.Forms.Label lbl_Tray_Y;
        private System.Windows.Forms.Label lbl_Tray_Point4;
        private System.Windows.Forms.Label lbl_Tray_Point3;
        private System.Windows.Forms.Label lbl_Tray_Point2;
        private System.Windows.Forms.Label lbl_Tray_Point1;
        private System.Windows.Forms.Label lbl_Tray_X;
        private System.Windows.Forms.NumericUpDown nud_MarkRect_P4_Y;
        private System.Windows.Forms.NumericUpDown nud_MarkRect_P4_X;
        private System.Windows.Forms.NumericUpDown nud_MarkRect_P3_Y;
        private System.Windows.Forms.NumericUpDown nud_MarkRect_P3_X;
        private System.Windows.Forms.NumericUpDown nud_MarkRect_P2_Y;
        private System.Windows.Forms.NumericUpDown nud_MarkRect_P2_X;
        private System.Windows.Forms.NumericUpDown nud_MarkRect_P1_Y;
        private System.Windows.Forms.NumericUpDown nud_MarkRect_P1_X;
        private System.Windows.Forms.GroupBox gb_TrayLong;
        private System.Windows.Forms.NumericUpDown nud_Long_CellToCell;
        private System.Windows.Forms.NumericUpDown nud_Long_CellArea;
        private System.Windows.Forms.NumericUpDown nud_Long_TrayToCell;
        private System.Windows.Forms.Label lbl_Long_CellToCell;
        private System.Windows.Forms.Label lbl_Long_CellArea;
        private System.Windows.Forms.Label lbl_Long_TrayToCell;
        private System.Windows.Forms.TabPage tp_Result;
        private System.Windows.Forms.GroupBox gb_TrayShort;
        private System.Windows.Forms.NumericUpDown nud_Short_CellToCell;
        private System.Windows.Forms.NumericUpDown nud_Short_CellArea;
        private System.Windows.Forms.NumericUpDown nud_Short_TrayToCell;
        private System.Windows.Forms.Label lbl_Short_CellToCell;
        private System.Windows.Forms.Label lbl_Short_CellArea;
        private System.Windows.Forms.Label lbl_Short_TrayToCell;
    }
}
