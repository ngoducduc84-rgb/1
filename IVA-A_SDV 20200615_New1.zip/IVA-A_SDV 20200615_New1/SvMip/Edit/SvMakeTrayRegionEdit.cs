﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;
using OpenCvSharp.CPlusPlus;

namespace SvMip.Edit
{
    public partial class SvMakeTrayRegionEdit : SvToolEditBase
    {
        public SvMakeTrayRegionEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvMakeRectTrayRegionEdit_SubjectChanged;

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvMakeTrayRegion Subject
        {
            get { return base.GetSubject() as SvMakeTrayRegion; }
            set { base.SetSubject(value); }
        }

        void SvMakeRectTrayRegionEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvMakeTrayRegion), null);
            DataBindings.Add("RectPoint1", source, "Point0", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("RectPoint2", source, "Point1", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("RectPoint3", source, "Point2", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("RectPoint4", source, "Point3", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("RectResult", source, "Result", true, DataSourceUpdateMode.OnPropertyChanged);

            //cb_LongShort.DataSource = Enum.GetValues(typeof(OffsetControl.LongOrShort));
            //cb_LongShort.DataBindings.Add("SelectedItem", source, "LongShort", true, DataSourceUpdateMode.OnPropertyChanged);
            //cb_Origin.DataSource = Enum.GetValues(typeof(OffsetControl.OriginDirection));
            //cb_Origin.DataBindings.Add("SelectedItem", source, "Origin", true, DataSourceUpdateMode.OnPropertyChanged);

        }

        public Point2f RectPoint1
        {
            get { return new Point2f((float)nud_MarkRect_P1_X.Value, (float)nud_MarkRect_P1_Y.Value); }
            set
            {
                nud_MarkRect_P1_X.Value = (decimal)value.X;
                nud_MarkRect_P1_Y.Value = (decimal)value.Y;
            }
        }

        public Point2f RectPoint2
        {
            get { return new Point2f((float)nud_MarkRect_P2_X.Value, (float)nud_MarkRect_P2_Y.Value); }
            set
            {
                nud_MarkRect_P2_X.Value = (decimal)value.X;
                nud_MarkRect_P2_Y.Value = (decimal)value.Y;
            }
        }

        public Point2f RectPoint3
        {
            get { return new Point2f((float)nud_MarkRect_P3_X.Value, (float)nud_MarkRect_P3_Y.Value); }
            set
            {
                nud_MarkRect_P3_X.Value = (decimal)value.X;
                nud_MarkRect_P3_Y.Value = (decimal)value.Y;
            }
        }

        public Point2f RectPoint4
        {
            get { return new Point2f((float)nud_MarkRect_P4_X.Value, (float)nud_MarkRect_P4_Y.Value); }
            set
            {
                nud_MarkRect_P4_X.Value = (decimal)value.X;
                nud_MarkRect_P4_Y.Value = (decimal)value.Y;
            }
        }


        public Point3d RectResult
        {
            get { return new Point3d((double)nud_MakeRect_Result_X.Value, (double)nud_MakeRect_Result_Y.Value, (double)nud_MakeRect_Result_Z.Value); }
            set
            {
                nud_MakeRect_Result_X.Value = (decimal)value.X;
                nud_MakeRect_Result_Y.Value = (decimal)value.Y;
                nud_MakeRect_Result_Z.Value = (decimal)value.Z;
            }
        }
    }
}
