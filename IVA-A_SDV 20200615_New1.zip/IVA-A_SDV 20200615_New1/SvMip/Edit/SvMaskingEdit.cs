﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;
using OpenCvSharp.CPlusPlus;

namespace SvMip.Edit
{
    public partial class SvMaskingEdit : SvMip.Edit.Base.SvToolEditBase
    {
        public SvMaskingEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvBlurEdit_SubjectChanged;

            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("Input"))
            {
                cb_PenType_SelectedIndexChanged(this, null);
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvMasking Subject
        {
            get { return base.GetSubject() as SvMasking; }
            set { base.SetSubject(value); }
        }

        void SvBlurEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);

            Subject.OnMask = true;
            Subject.Mask.DisplayMask = true;
            Subject.Mask.DrawMask = true;
            Subject.Mask.PenSize = (int)nud_PenSize.Value;

            Subject.RotationRect.Display = SvDisplayViewEdit.Display;
            if (Subject.Mask != null)
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.Mask);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvMasking), null);

            cb_PenType.DisplayMember = "Key"; cb_PenType.ValueMember = "Value";
            cb_PenType.DataSource = Enum.GetValues(typeof(SvMasking.ePenType)).Cast<SvMasking.ePenType>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_PenType.DataBindings.Add("SelectedValue", source, "PenType", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_PenSize.DataBindings.Add("Value", source, "PenSize", true, DataSourceUpdateMode.OnPropertyChanged, 0f);
            chb_DrawOnOff.DataBindings.Add("Checked", source, "OnMask", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void cb_PenType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Subject == null || Subject.InputImage == null) return;

            if (SvDisplayViewEdit.imageListComboBox.SelectedIndex != 0)
            {
                SvDisplayViewEdit.imageListComboBox.SelectedIndex = 0;
                SvDisplayViewEdit.RefreshImage();
            }

            SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Clear();
            SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.Mask);

            switch((SvMasking.ePenType)cb_PenType.SelectedValue)
            {
                case SvMasking.ePenType.Rect:
                    SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.RotationRect);
                    Subject.Mask.DrawMask = false;
                    break;
                case SvMasking.ePenType.Ellipse:
                    SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.Ellipse);
                    Subject.Mask.DrawMask = false;
                    break;
                default:
                    Subject.Mask.DrawMask = true;
                    break;
            }
            SvDisplayViewEdit.Display.Invalidate();
        }

        private void btn_Fill_Click(object sender, EventArgs e)
        {
            if (Subject.InputImage == null) return;

            Scalar color;
            if (chb_DrawOnOff.Checked)
                color = new Scalar(0);
            else
                color = new Scalar(255);

            switch ((SvMasking.ePenType)cb_PenType.SelectedValue) 
            {
                case SvMasking.ePenType.Rect:
                    OpenCvSharp.CPlusPlus.Point[] pts = new OpenCvSharp.CPlusPlus.Point[4];
                    
                    pts[0] = SvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(Subject.RotationRect.LeftTop.X, Subject.RotationRect.LeftTop.Y), Subject.InputImage.TransformMat);
                    pts[1] = SvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(Subject.RotationRect.RightTop.X, Subject.RotationRect.RightTop.Y), Subject.InputImage.TransformMat);
                    pts[2] = SvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(Subject.RotationRect.RightBottom.X, Subject.RotationRect.RightBottom.Y), Subject.InputImage.TransformMat);
                    pts[3] = SvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(Subject.RotationRect.LeftBottom.X, Subject.RotationRect.LeftBottom.Y), Subject.InputImage.TransformMat);
                    
                    Subject.Mask.DrawMask = true;
                    Subject.Mask.MaskMat.DrawContours(new OpenCvSharp.CPlusPlus.Point[][] { pts }, 0, color, -1);
                    Subject.Mask.DrawMask = false;
                    SvDisplayViewEdit.Display.Invalidate();
                    break;
                case SvMasking.ePenType.Ellipse:
                    SvEllipse E = Subject.Ellipse;
                    Size2f fsize = new Size2f(E.Width, E.Height);
                    OpenCvSharp.CPlusPlus.Point2f p = SvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(E.Center.X, E.Center.Y), Subject.InputImage.TransformMat);
                    RotatedRect Rrect = new RotatedRect(p, fsize, 0);
                    Subject.Mask.DrawMask = true;
                    Subject.Mask.MaskMat.Ellipse(Rrect, color, -1);
                    Subject.Mask.DrawMask = false;
                    SvDisplayViewEdit.Display.Invalidate();
                    break;                
            }
        }

        private void nud_PenSize_ValueChanged(object sender, EventArgs e)
        {
            Subject.Mask.PenSize = (int)nud_PenSize.Value;
        }

        private void chb_DrawOnOff_CheckedChanged(object sender, EventArgs e)
        {
            if (chb_DrawOnOff.Checked)
                chb_DrawOnOff.Text = "Mask On";
            else
                chb_DrawOnOff.Text = "Mask Off";
        }

        private void btn_MaskReset_Click(object sender, EventArgs e)
        {
            Subject.Mask.ResetMask();
        }
    }
}
