﻿using System;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Edit page of SvMaster (built in code).</summary>
    public class SvMasterEdit : SvToolEditBase
    {
        BindingSource source;

        public SvMasterEdit()
        {
            source = new BindingSource(typeof(SvMaster), null);
            TabPage page = SvEditHelper.AddPage(this, "Get master");
            int y = 15;
            SvEditHelper.AddText(page, source, "PixelSource", "Part position (Tool.Output) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "CalibrationFile", "Calibration file (empty = SvAlign) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "AlignPoint", "SvAlign point (0 = first) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddCheck(page, source, "SaveJob", "Save the job after the master changed", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Reply", "Reply OK ({cmd} {x:F3} {y:F3} {t:F3}) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "ReplyNg", "Reply NG ({message}) :", y); y += SvEditHelper.RowHeight;
            Label note = new Label();
            note.AutoSize = false;
            note.Size = new System.Drawing.Size(420, 90);
            note.Location = new System.Drawing.Point(SvEditHelper.LabelX, y + 10);
            note.Text = "Put it behind SvIf (e.g. @cmd = MS). The part position is converted with the calibration and stored as master of SvAlign.";
            page.Controls.Add(note);
            this.SubjectChanged += OnSubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvMaster Subject
        {
            get { return base.GetSubject() as SvMaster; }
            set { base.SetSubject(value); }
        }

        void OnSubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
    }
}
