﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;




namespace SvMip.Edit
{
    public partial class SvMeasureSharpnessEdit : SvToolEditBase
    {
        public SvMeasureSharpnessEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvImageCalculateEdit_SubjectChanged;
        }
        protected override void InitDisplayViewEdit()
        {

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvMeasureSharpness Subject
        {
            get { return base.GetSubject() as SvMeasureSharpness; }
            set { base.SetSubject(value); }
        }

        void SvImageCalculateEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvMeasureSharpness), null);
            nud_MaxPrewitCount.DataBindings.Add("Value", source, "MaxCount", true, DataSourceUpdateMode.OnPropertyChanged, 0f);
            DataBindings.Add("MeasureSum", source, "MeasureSum", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        double[] measureSum;
        public double[] MeasureSum
        {
            get
            {
                return measureSum;
            }
            set
            {
                if (value == null) return;
                measureSum = value;
                lv_Msharpness.Width = 300;
                lv_Msharpness.Items.Clear();
                lv_Msharpness.Columns.Clear();
                lv_Msharpness.Columns.Add("", 0);
                lv_Msharpness.Columns.Add("Prewitt Kernel Size", 120, HorizontalAlignment.Right);
                lv_Msharpness.Columns.Add("Measured Sum of Max Value", lv_Msharpness.Width - lv_Msharpness.Columns[1].Width, HorizontalAlignment.Right);

                for (int i = 1; i < value.Length; i++)
                {
                    string[] str = new string[] { "", (2 * i + 1).ToString(), value[i].ToString("f3") };
                    lv_Msharpness.Items.Add(new ListViewItem(str));
                }
            }
        }
    }
}
