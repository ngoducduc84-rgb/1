﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    public partial class SvMorphologyEdit : SvToolEditBase
    {
        public SvMorphologyEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvMorphologyEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]

        public SvMorphology Subject
        {
            get { return base.GetSubject() as SvMorphology; }
            set { base.SetSubject(value); }
        }

        void SvMorphologyEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;
        
        void InitBinding()
        {
            source = new BindingSource(typeof(SvMorphology), null);
            
            cb_Morph_Mode.DisplayMember = "Key"; cb_Morph_Mode.ValueMember = "Value";
            cb_Morph_Mode.DataSource = Enum.GetValues(typeof(SvMorphology.MorphOperation)).Cast<SvMorphology.MorphOperation>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_Morph_Mode.DataBindings.Add("SelectedValue", source, "Operation", true, DataSourceUpdateMode.OnPropertyChanged);
            
            cb_Morph_Shape.DisplayMember = "Key"; cb_Morph_Shape.ValueMember = "Value";
            cb_Morph_Shape.DataSource = Enum.GetValues(typeof(OpenCvSharp.CPlusPlus.StructuringElementShape)).Cast<OpenCvSharp.CPlusPlus.StructuringElementShape>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_Morph_Shape.DataBindings.Add("SelectedValue", source, "Shape", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_Morph_Iteration.DataBindings.Add("Value", source, "Iteration", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Morph_SizeX.DataBindings.Add("Value", source, "SizeX", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Morph_SizeY.DataBindings.Add("Value", source, "SizeY", true, DataSourceUpdateMode.OnPropertyChanged);

        }
    }
}
