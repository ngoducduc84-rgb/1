﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SvMip.Edit
{
    /// <summary>"Run time per tool": one horizontal bar per tool, the slowest one in orange.</summary>
    public class SvRunTimePanel : UserControl
    {
        const int RowHeight = 26;
        const int HeaderHeight = 44;

        List<KeyValuePair<string, double>> times = new List<KeyValuePair<string, double>>();

        public SvRunTimePanel()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint
                     | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint, true);
            AutoScroll = true;
            BackColor = Color.FromArgb(30, 35, 40);
            ForeColor = Color.FromArgb(232, 236, 239);
            Dock = DockStyle.Fill;
        }

        public void SetTimes(List<KeyValuePair<string, double>> list)
        {
            times = list ?? new List<KeyValuePair<string, double>>();
            AutoScrollMinSize = new Size(0, HeaderHeight + times.Count * RowHeight + 8);
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(BackColor);
            g.TranslateTransform(AutoScrollPosition.X, AutoScrollPosition.Y);

            double total = 0, max = 0;
            int slowest = -1;
            for (int i = 0; i < times.Count; i++)
            {
                total += times[i].Value;
                if (times[i].Value > max) { max = times[i].Value; slowest = i; }
            }

            using (Font bold = new Font(Font, FontStyle.Bold))
            using (Brush text = new SolidBrush(ForeColor))
            using (Brush muted = new SolidBrush(Color.FromArgb(154, 165, 177)))
            {
                g.DrawString("Run time per tool", bold, text, 8, 6);
                string sub = times.Count == 0 ? "run the job to see the times"
                                              : string.Format("last run · total {0:0.0} ms · slowest in orange", total);
                g.DrawString(sub, Font, muted, 8, 24);

                int nameWidth = Math.Min(150, Math.Max(80, ClientSize.Width / 3));
                int msWidth = 62;
                int barLeft = 8 + nameWidth + 6;
                int barWidth = Math.Max(20, ClientSize.Width - barLeft - msWidth - 24);
                StringFormat trim = new StringFormat(StringFormatFlags.NoWrap);
                trim.Trimming = StringTrimming.EllipsisCharacter;
                using (Brush track = new SolidBrush(Color.FromArgb(43, 49, 56)))
                using (Brush normal = new SolidBrush(Color.FromArgb(76, 154, 255)))
                using (Brush slow = new SolidBrush(Color.FromArgb(240, 140, 50)))
                {
                    for (int i = 0; i < times.Count; i++)
                    {
                        int y = HeaderHeight + i * RowHeight;
                        g.DrawString(times[i].Key, Font, text, new RectangleF(8, y + 4, nameWidth, RowHeight - 4), trim);
                        g.FillRectangle(track, barLeft, y + 7, barWidth, 10);
                        int w = max <= 0 ? 0 : (int)Math.Round(barWidth * times[i].Value / max);
                        if (w < 2 && times[i].Value > 0) w = 2;
                        g.FillRectangle(i == slowest ? slow : normal, barLeft, y + 7, w, 10);
                        g.DrawString(times[i].Value.ToString("0.0") + " ms", Font, muted, barLeft + barWidth + 6, y + 4);
                    }
                }
            }
        }
    }
}
