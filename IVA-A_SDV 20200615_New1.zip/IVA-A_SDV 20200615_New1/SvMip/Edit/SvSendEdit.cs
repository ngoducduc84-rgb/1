﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>
    /// Edit page of SvSend (built in code): channels on top, fields of the selected channel below.
    /// Source syntax: see the notes in DirectPath (tool outputs and @align / @judge / @vision / @cellid / @recipe / @job / @time).
    /// </summary>
    public class SvSendEdit : SvToolEditBase
    {
        BindingSource source;
        DataGridView gridChannels;
        DataGridView gridFields;
        Label lblFields;

        public SvSendEdit()
        {
            source = new BindingSource(typeof(SvSend), null);
            TabPage page = SvEditHelper.AddPage(this, "Send");
            int y = 10;
            SvEditHelper.AddCheck(page, source, "DryRun", "Dry run: compute and log, do not write to the PLC", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddHeader(page, "Channels", y); y += SvEditHelper.RowHeight;
            gridChannels = SvEditHelper.AddGrid(page, y, 140);
            SvEditHelper.AddTextColumn(gridChannels, "Name", "Name", 100);
            SvEditHelper.AddCheckColumn(gridChannels, "Enabled", "On", 35);
            SvEditHelper.AddEnumColumn(gridChannels, "Kind", "Kind", typeof(SvSendKind), 75);
            SvEditHelper.AddTextColumn(gridChannels, "StartIndex", "Start", 50);
            SvEditHelper.AddEnumColumn(gridChannels, "Condition", "When", typeof(SvSendCondition), 80);
            SvEditHelper.AddTextColumn(gridChannels, "Connection", "Connection", 80);
            SvEditHelper.AddTextColumn(gridChannels, "Template", "Template (Text)", 160);
            SvEditHelper.AddTextColumn(gridChannels, "Reply", "Reply contains", 80);
            SvEditHelper.AddCheckColumn(gridChannels, "WordSwap", "Swap", 40);
            y += 150;

            lblFields = new Label();
            lblFields.AutoSize = true;
            lblFields.Font = new System.Drawing.Font(page.Font, System.Drawing.FontStyle.Bold);
            lblFields.Text = "Fields of the selected channel";
            lblFields.Location = new System.Drawing.Point(SvEditHelper.LabelX, y + 4);
            page.Controls.Add(lblFields);
            y += SvEditHelper.RowHeight;

            gridFields = SvEditHelper.AddGrid(page, y, 230);
            SvEditHelper.AddTextColumn(gridFields, "Name", "Name", 60);
            SvEditHelper.AddTextColumn(gridFields, "Source", "Source", 120);
            SvEditHelper.AddEnumColumn(gridFields, "ValueType", "Type", typeof(SvSendValueType), 55);
            SvEditHelper.AddTextColumn(gridFields, "Address", "Addr", 40);
            SvEditHelper.AddTextColumn(gridFields, "Scale", "Scale", 45);
            SvEditHelper.AddTextColumn(gridFields, "Offset", "Offs", 45);
            SvEditHelper.AddCheckColumn(gridFields, "UseRange", "Rng", 35);
            SvEditHelper.AddTextColumn(gridFields, "Min", "Min", 45);
            SvEditHelper.AddTextColumn(gridFields, "Max", "Max", 45);
            SvEditHelper.AddPickButton(page, gridFields, "Source", y + 236);

            gridChannels.SelectionChanged += gridChannels_SelectionChanged;
            this.SubjectChanged += SvSendEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvSend Subject
        {
            get { return base.GetSubject() as SvSend; }
            set { base.SetSubject(value); }
        }

        void SvSendEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            SvSend send = Subject;
            source.DataSource = send;
            source.ResetBindings(true);
            if (send == null) gridChannels.DataSource = null;
            else gridChannels.DataSource = new BindingList<SvSendChannel>(send.Channels);
            ShowFields();
        }

        void gridChannels_SelectionChanged(object sender, EventArgs e)
        {
            ShowFields();
        }

        void ShowFields()
        {
            SvSendChannel ch = null;
            if (gridChannels.CurrentRow != null) ch = gridChannels.CurrentRow.DataBoundItem as SvSendChannel;
            if (ch == null)
            {
                gridFields.DataSource = null;
                lblFields.Text = "Fields of the selected channel";
                return;
            }
            lblFields.Text = "Fields of '" + ch.Name + "'";
            gridFields.DataSource = new BindingList<SvSendField>(ch.Fields);
        }
    }
}
