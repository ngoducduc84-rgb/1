﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    public partial class SvSharpnessEdit : SvToolEditBase
    {
        public SvSharpnessEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvSharpnessEdit_SubjectChanged;

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvSharpness Subject
        {
            get { return base.GetSubject() as SvSharpness; }
            set { base.SetSubject(value); }
        }

        void SvSharpnessEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvSharpness), null);

            cb_Sharpness_Mode.DisplayMember = "Key"; cb_Sharpness_Mode.ValueMember = "Value";
            cb_Sharpness_Mode.DataSource = Enum.GetValues(typeof(SvSharpness.SharpnessMode)).Cast<SvSharpness.SharpnessMode>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_Sharpness_Mode.DataBindings.Add("SelectedValue", source, "Mode", true, DataSourceUpdateMode.OnPropertyChanged);
            
            nud_Sharpness_Size.DataBindings.Add("Value", source, "KernelSize", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Sharpness_Scale.DataBindings.Add("Value", source, "Scale", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Sharpness_Delta.DataBindings.Add("Value", source, "Delta", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Sharpness_Alpha.DataBindings.Add("Value", source, "Alpha", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Sharpness_Beta.DataBindings.Add("Value", source, "Beta", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Sharpness_Gamma.DataBindings.Add("Value", source, "Gamma", true, DataSourceUpdateMode.OnPropertyChanged);
        }
    }
}
