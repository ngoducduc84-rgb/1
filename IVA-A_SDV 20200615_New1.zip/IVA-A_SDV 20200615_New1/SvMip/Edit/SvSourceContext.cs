﻿using System.Collections.Generic;

namespace SvMip.Edit
{
    /// <summary>The job that is open in the job editor; the source picker and the Output tab read tools from it.</summary>
    public static class SvSourceContext
    {
        public static SvJob Job;

        /// <summary>All tools of the open job, including the tools inside ToolBlocks.</summary>
        public static List<SvToolBase> AllTools()
        {
            List<SvToolBase> list = new List<SvToolBase>();
            Collect(Job, list, 0);
            return list;
        }

        static void Collect(SvJob job, List<SvToolBase> acc, int depth)
        {
            if (job == null || depth > 8) return;
            foreach (SvToolBase t in job.ToolList)
            {
                acc.Add(t);
                SvToolBlock block = t as SvToolBlock;
                if (block != null) Collect(block.ToolJob, acc, depth + 1);
            }
        }
    }
}
