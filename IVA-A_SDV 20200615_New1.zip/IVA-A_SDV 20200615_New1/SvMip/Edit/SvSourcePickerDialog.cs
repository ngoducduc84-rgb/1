﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace SvMip.Edit
{
    /// <summary>
    /// Chooses a data source (Tool.Output.Member, @judge, @align[0].x ...) from a tree instead of typing it.
    /// Members of an output are shown from its value of the last run, so run the job once first.
    /// </summary>
    public class SvSourcePickerDialog : Form
    {
        readonly TreeView tree = new TreeView();
        readonly Label lblPath = new Label();
        readonly Label lblValue = new Label();
        readonly Button btnOk = new Button();
        readonly Button btnCancel = new Button();
        readonly List<SvToolBase> tools = SvSourceContext.AllTools();

        public string SelectedPath { get; private set; }

        /// <summary>Opens the picker; returns the chosen text, or null when cancelled.</summary>
        public static string Pick(IWin32Window owner)
        {
            using (SvSourcePickerDialog dlg = new SvSourcePickerDialog())
            {
                return (dlg.ShowDialog(owner) == DialogResult.OK) ? dlg.SelectedPath : null;
            }
        }

        public SvSourcePickerDialog()
        {
            AutoScaleMode = AutoScaleMode.None;
            Font = new Font("Segoe UI", 9f);
            Text = "Pick a source";
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            MinimizeBox = false;
            MaximizeBox = false;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            ClientSize = new Size(560, 560);

            tree.SetBounds(10, 10, 540, 400);
            tree.HideSelection = false;
            tree.AfterSelect += tree_AfterSelect;
            tree.NodeMouseDoubleClick += delegate { Accept(); };

            lblPath.SetBounds(10, 418, 540, 22);
            lblPath.Font = new Font("Consolas", 10f, FontStyle.Bold);
            lblValue.SetBounds(10, 444, 540, 60);

            btnOk.Text = "Use this";
            btnOk.SetBounds(350, 520, 100, 28);
            btnOk.Enabled = false;
            btnOk.Click += delegate { Accept(); };
            btnCancel.Text = "Cancel";
            btnCancel.SetBounds(456, 520, 94, 28);
            btnCancel.DialogResult = DialogResult.Cancel;
            CancelButton = btnCancel;

            Controls.Add(tree);
            Controls.Add(lblPath);
            Controls.Add(lblValue);
            Controls.Add(btnOk);
            Controls.Add(btnCancel);

            Build();
        }

        void Build()
        {
            tree.BeginUpdate();
            TreeNode toolsRoot = new TreeNode("Tool outputs (from the open job)");
            foreach (SvToolBase t in tools)
            {
                if (t.outParams == null || t.outParams.Count == 0) continue;
                TreeNode tn = new TreeNode(t.ToString());
                foreach (KeyValuePair<string, object> kv in new Dictionary<string, object>(t.outParams))
                {
                    TreeNode on = new TreeNode(kv.Key + "    " + Short(kv.Value));
                    on.Tag = t.ToString() + "." + kv.Key;
                    AddMembers(on, (string)on.Tag, kv.Value, 1);
                    tn.Nodes.Add(on);
                }
                toolsRoot.Nodes.Add(tn);
            }
            tree.Nodes.Add(toolsRoot);

            TreeNode specials = new TreeNode("Special values (known when the job runs in Auto)");
            string[] sp = new string[] { "@judge", "@vision", "@cellid", "@recipe", "@job", "@time", "@request", "@request[0]", "@request[1]", "@request[2]",
                "@align[0].x", "@align[0].y", "@align[0].t", "@align[1].x", "@align[1].y", "@align[1].t" };
            foreach (string s in sp)
            {
                TreeNode n = new TreeNode(s);
                n.Tag = s;
                specials.Nodes.Add(n);
            }
            tree.Nodes.Add(specials);

            toolsRoot.Expand();
            tree.EndUpdate();
        }

        static readonly string[] SkipTypes = new string[] { "Mat", "MatExpr", "IplImage", "CvMat", "Bitmap", "Image", "SvImage" };

        static bool IsLeaf(Type t)
        {
            return t.IsPrimitive || t.IsEnum || t == typeof(string) || t == typeof(decimal) || t == typeof(DateTime) || Array.IndexOf(SkipTypes, t.Name) >= 0;
        }

        static string Short(object v)
        {
            string s = SvToolOutputTab.Describe(v);
            return s.Length > 50 ? s.Substring(0, 50) + "..." : s;
        }

        static void AddMembers(TreeNode parent, string path, object value, int depth)
        {
            if (value == null || depth > 3) return;
            Type t = value.GetType();
            if (IsLeaf(t)) return;

            IList list = value as IList;
            if (list != null)
            {
                for (int i = 0; i < list.Count && i < 3; i++)
                {
                    string p = path + "[" + i + "]";
                    TreeNode n = new TreeNode("[" + i + "]    " + Short(list[i]));
                    n.Tag = p;
                    AddMembers(n, p, list[i], depth + 1);
                    parent.Nodes.Add(n);
                }
                return;
            }

            if (t.Name == "Point3d" || t.Name == "Point3f")
            {
                // x, y, z are raw values; t is z converted to degrees (see SvPathResolver)
                foreach (string c in new string[] { "x", "y", "z", "t" })
                {
                    TreeNode n = new TreeNode(c);
                    n.Tag = path + "." + c;
                    parent.Nodes.Add(n);
                }
                return;
            }

            BindingFlags flags = BindingFlags.Public | BindingFlags.Instance;
            foreach (PropertyInfo pi in t.GetProperties(flags))
            {
                if (!pi.CanRead || pi.GetIndexParameters().Length > 0) continue;
                object v = null;
                try { v = pi.GetValue(value, null); } catch { continue; }
                AddMember(parent, path, pi.Name, v, depth);
            }
            foreach (FieldInfo fi in t.GetFields(flags))
            {
                object v = null;
                try { v = fi.GetValue(value); } catch { continue; }
                AddMember(parent, path, fi.Name, v, depth);
            }
        }

        static void AddMember(TreeNode parent, string path, string name, object v, int depth)
        {
            string p = path + "." + name;
            TreeNode n = new TreeNode(name + "    " + Short(v));
            n.Tag = p;
            AddMembers(n, p, v, depth + 1);
            parent.Nodes.Add(n);
        }

        void tree_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string path = e.Node.Tag as string;
            btnOk.Enabled = !string.IsNullOrEmpty(path);
            lblPath.Text = path ?? "";
            if (string.IsNullOrEmpty(path)) { lblValue.Text = ""; return; }
            if (path[0] == '@') { lblValue.Text = "Known only while the job runs in Auto."; return; }

            object v; string err;
            if (SvPathResolver.TryGetToolValue(tools, path, out v, out err))
                lblValue.Text = "Value of the last run: " + SvToolOutputTab.Describe(v);
            else
                lblValue.Text = "Cannot read this now: " + err + "  (run the job once, then pick again)";
        }

        void Accept()
        {
            string path = (tree.SelectedNode != null) ? tree.SelectedNode.Tag as string : null;
            if (string.IsNullOrEmpty(path)) return;
            SelectedPath = path;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
