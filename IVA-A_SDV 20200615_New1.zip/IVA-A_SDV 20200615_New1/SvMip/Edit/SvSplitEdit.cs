﻿using System;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Edit page of SvSplit (built in code).</summary>
    public class SvSplitEdit : SvToolEditBase
    {
        BindingSource source;

        public SvSplitEdit()
        {
            source = new BindingSource(typeof(SvSplit), null);
            TabPage page = SvEditHelper.AddPage(this, "Split");
            int y = 15;
            SvEditHelper.AddText(page, source, "SourcePath", "Text to split (when no input is linked) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Separator", "Separator (, or ; or both) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddCheck(page, source, "Trim", "Remove spaces around each part", y); y += SvEditHelper.RowHeight;
            Label note = new Label();
            note.AutoSize = false;
            note.Size = new System.Drawing.Size(420, 90);
            note.Location = new System.Drawing.Point(SvEditHelper.LabelX, y + 10);
            note.Text = "The outputs (name, position of the part, text or number) are added in the table of the VISION screen form. Count is the number of parts.";
            page.Controls.Add(note);
            this.SubjectChanged += OnSubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvSplit Subject
        {
            get { return base.GetSubject() as SvSplit; }
            set { base.SetSubject(value); }
        }

        void OnSubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
    }
}
