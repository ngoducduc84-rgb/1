﻿using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SvMip.Edit
{
    public partial class SvSubImageEdit : SvMip.Edit.Base.SvToolEditBase
    {
        SvRotationRectangle regionRect;

        public SvSubImageEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvBlurEdit_SubjectChanged;

            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;            
        }

        protected override void InitDisplayViewEdit()
        {
            //if (subImageRegionInfo != null)
            //    subImageRegionInfo.Image.Dispose();
            //subImageRegionInfo = new SvImageInfo("[SubImage] SubImage Select");
            //SvDisplayViewEdit.InsertCustomImage(1, subImageRegionInfo);
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("Input"))
            {
                if (Subject.InputImage == null) return;
                SvDisplayViewEdit.Display.Image = Subject.InputImage;
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.SubImageRegionRect);
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvSubImage Subject
        {
            get { return base.GetSubject() as SvSubImage; }
            set { base.SetSubject(value); }
        }

        void SvBlurEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);

            Subject.SubImageRegionRect.Display = SvDisplayViewEdit.Display;
            regionRect = Subject.SubImageRegionRect;

            Display_DrawObjectChanged(this, Subject.SubImageRegionRect);

        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(SvSubImage), null);
        }

        SvImageInfo subImageRegionInfo;


        #region InputPoints Event

        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject)
        {
            Remove_In_nud_ValueChangedEvent();

            nud_InP0_X.Value = (decimal)regionRect.LeftTop.X; P0.Value = (decimal)regionRect.LeftTop.Y;
            nud_InP1_X.Value = (decimal)regionRect.RightTop.X; nud_InP1_Y.Value = (decimal)regionRect.RightTop.Y;
            nud_InP2_X.Value = (decimal)regionRect.RightBottom.X; nud_InP2_Y.Value = (decimal)regionRect.RightBottom.Y;
            nud_InP3_X.Value = (decimal)regionRect.LeftBottom.X; nud_InP3_Y.Value = (decimal)regionRect.LeftBottom.Y;

            Add_In_nud_ValueChangedEvent();
        }

        void Add_In_nud_ValueChangedEvent()
        {
            nud_InP0_X.ValueChanged += nud_InputDrawPoint_ValueChanged; P0.ValueChanged += nud_InputDrawPoint_ValueChanged;
            nud_InP1_X.ValueChanged += nud_InputDrawPoint_ValueChanged; nud_InP1_Y.ValueChanged += nud_InputDrawPoint_ValueChanged;
            nud_InP2_X.ValueChanged += nud_InputDrawPoint_ValueChanged; nud_InP2_Y.ValueChanged += nud_InputDrawPoint_ValueChanged;
            nud_InP3_X.ValueChanged += nud_InputDrawPoint_ValueChanged; nud_InP3_Y.ValueChanged += nud_InputDrawPoint_ValueChanged;
        }

        void Remove_In_nud_ValueChangedEvent()
        {
            nud_InP0_X.ValueChanged -= nud_InputDrawPoint_ValueChanged; P0.ValueChanged -= nud_InputDrawPoint_ValueChanged;
            nud_InP1_X.ValueChanged -= nud_InputDrawPoint_ValueChanged; nud_InP1_Y.ValueChanged -= nud_InputDrawPoint_ValueChanged;
            nud_InP2_X.ValueChanged -= nud_InputDrawPoint_ValueChanged; nud_InP2_Y.ValueChanged -= nud_InputDrawPoint_ValueChanged;
            nud_InP3_X.ValueChanged -= nud_InputDrawPoint_ValueChanged; nud_InP3_Y.ValueChanged -= nud_InputDrawPoint_ValueChanged;
        }

        private void nud_InputDrawPoint_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown nud = sender as NumericUpDown;

            if (nud == nud_InP0_X || nud == P0)
            {
                regionRect.LeftTop = new PointF((float)nud_InP0_X.Value, (float)P0.Value);
            }
            else if (nud == nud_InP1_X || nud == nud_InP1_Y)
            {
                regionRect.RightTop = new PointF((float)nud_InP1_X.Value, (float)nud_InP1_Y.Value);
            }
            else if (nud == nud_InP2_X || nud == nud_InP2_Y)
            {
                regionRect.RightBottom = new PointF((float)nud_InP2_X.Value, (float)nud_InP2_Y.Value);
            }
            else if (nud == nud_InP3_X || nud == nud_InP3_Y)
            {
                regionRect.LeftBottom = new PointF((float)nud_InP3_X.Value, (float)nud_InP3_Y.Value);
            }

            SvDisplayViewEdit.Display.Invalidate();
        }        
        #endregion
        
    }
}
