﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Core;
using System.Reflection;
using SvMip.Edit.Base;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;
using System.IO;
using System.Runtime.Serialization;
using SvMip.Display;

namespace SvMip.Edit
{
    public partial class SvTemplateMatchEdit : SvToolEditBase
    {
        SvRotationRectangle templateRegion;

        public SvTemplateMatchEdit()
        {
            InitializeComponent();
            InitBinding();

            this.SubjectChanged += SvTMEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;

            templateRegion = new SvRotationRectangle();

            mPatternDisplayList = new List<SvDisplayViewInteract>();
            mPatternDisplayList.Add(svd_SubPattern0);
            mPatternDisplayList.Add(svd_SubPattern1);
            mPatternDisplayList.Add(svd_SubPattern2);
            mPatternDisplayList.Add(svd_SubPattern3);

            mPatternLabelList = new List<Label>();
            mPatternLabelList.Add(lb_patter0);
            mPatternLabelList.Add(lb_patter1);
            mPatternLabelList.Add(lb_patter2);
            mPatternLabelList.Add(lb_patter3);
        }

        SvImageInfo trainInfo;
        bool sharedActive;

        protected override void OnSharedDisplay(SvDisplayViewEdit own, SvDisplayViewEdit shared)
        {
            tp_Train.Text = "Pattern";
            if (own.CustomImageList.ContainsKey(1)) trainInfo = own.CustomImageList[1];
            else trainInfo = new SvImageInfo("[TemplateMatch] Train");
        }

        /// <summary>Docked mode: add the "Train" picture (where the pattern region is drawn) to the job editor's image list, or take it away.</summary>
        public override void SetSharedActive(bool active)
        {
            if (trainInfo == null || active == sharedActive) return;
            sharedActive = active;
            if (active)
            {
                SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
                if (!SvDisplayViewEdit.CustomImageList.ContainsKey(1)) SvDisplayViewEdit.InsertCustomImage(1, trainInfo);
            }
            else
            {
                SvDisplayViewEdit.SelectedImageChanged -= SvDisplayViewEdit_SelectedImageChanged;
                SvDisplayViewEdit.RemoveCustomImage(1);
            }
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("Train"))
            {
                if (Subject.InputImage == null) return;
                SvDisplayViewEdit.Display.Image = Subject.InputImage;                
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(templateRegion);
            }
            //else if (imageInfo.ImageName.Contains("OutputImage"))
            //{
            //    if (SvDisplayViewEdit.Display.Image == null) return;
            //    DrawResult(SvDisplayViewEdit.Display);
            //}
        }


        protected override void InitDisplayViewEdit()
        {
            SvDisplayViewEdit.InsertCustomImage(1, new SvImageInfo("[TemplateMatch] Train"));
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvTemplateMatch Subject
        {
            get { return base.GetSubject() as SvTemplateMatch; }
            set { base.SetSubject(value); }
        }

        void SvTMEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);

            svd_Template.Image = null;
            InitPatternList();
            SetTemplateImage(Subject.SelectedPatternIndex);

            ResetTepmplateGraphics();
        }

        void ResetTepmplateGraphics()
        {
            svd_Template.InteractiveGraphicsCollection.Clear();
            svd_Template.GraphicsCollection.Clear();

            if (Subject.TemplateImage == null)
            {
                return;
            }
            svd_Template.Image = Subject.TemplateImage;

            if (Subject.RefPoint != null)
            {
                //Subject.RefPoint.SelectionSize = (int)(10 / svd_Template.ZoomRatio);
                svd_Template.InteractiveGraphicsCollection.Add(Subject.RefPoint);
            }

            if (Subject.Mask != null && Subject.SelectedPatternIndex > -1 && Subject.mPatternDataList.Count > Subject.SelectedPatternIndex)
            {
                Subject.Mask = Subject.mPatternDataList[Subject.SelectedPatternIndex].Value.MaskImage;
                svd_Template.GraphicsCollection.Add(Subject.Mask);
                
                Subject.Mask.DrawMask = true;
                
                // 만약 Edge 사용한다면... Edge 표시
                if (chb_TempUseEdge.Checked)
                    nud_Threshold_ValueChanged(null, null);                
            }
        }

        BindingSource source;

        // ================= API for the WPF editor panel (the WinForms controls stay as the engine) =================
        /// <summary>True when the WPF panel draws the pattern list, so the small WinForms pattern views are not updated.</summary>
        public bool NativeUi;
        public event EventHandler PatternsChanged;

        void NotifyPatterns()
        {
            if (PatternsChanged != null) PatternsChanged(this, EventArgs.Empty);
        }

        /// <summary>The big view of the selected pattern (with the reference point and the mask).</summary>
        public Control PatternView { get { return svd_Template; } }

        public int PatternCount { get { return Subject == null ? 0 : Subject.mPatternDataList.Count; } }
        public int SelectedPattern { get { return Subject == null ? -1 : Subject.SelectedPatternIndex; } }

        public string GetPatternName(int index)
        {
            if (Subject == null || index < 0 || index >= Subject.mPatternDataList.Count) return "";
            string key = Subject.mPatternDataList[index].Key;
            return string.IsNullOrEmpty(key) ? "new" : Path.GetFileNameWithoutExtension(key);
        }

        public Bitmap GetPatternBitmap(int index)
        {
            try
            {
                if (Subject == null || index < 0 || index >= Subject.mPatternDataList.Count) return null;
                SvImage img = Subject.mPatternDataList[index].Value.PatternImage;
                if (img == null || img.Mat == null) return null;
                return img.Mat.ToBitmap();
            }
            catch (Exception) { return null; }
        }

        public void SelectPattern(int index)
        {
            if (Subject == null || index < 0 || index >= Subject.mPatternDataList.Count) return;
            SetTemplateImage(index);
            RefreshPatternList();
        }

        /// <summary>Takes the pattern from the region drawn on the "Train" image. Returns a hint when that is not possible.</summary>
        public string GrabPattern()
        {
            SvImageInfo info = SvDisplayViewEdit.imageListComboBox.SelectedItem as SvImageInfo;
            if (info == null || !info.ImageName.Contains("Train"))
                return "Select the Train image first, draw the pattern region on it, then press Grab.";
            btn_TemplateMatching_Grab_Click(this, EventArgs.Empty);
            return null;
        }

        public void AddPatterns() { btn_PatternAdd_Click(this, EventArgs.Empty); }
        public void RemovePattern() { btn_PatternRemove_Click(this, EventArgs.Empty); }
        public void LoadPatterns() { btn_PatternLoad_Click(this, EventArgs.Empty); }
        public void SavePattern() { btn_PatternSave_Click(this, EventArgs.Empty); }
        public void ResetMask() { btn_ResetMask_Click(this, EventArgs.Empty); }
        public void EditMask() { chb_MaskOn_CheckedChanged(this, EventArgs.Empty); }
        public void RefToCenter() { btn_RefToCenter_Click(this, EventArgs.Empty); }

        public void NudgeRef(int dx, int dy)
        {
            if (dx < 0) btn_refMark_Left_Click(this, EventArgs.Empty);
            else if (dx > 0) btn_refMark_Right_Click(this, EventArgs.Empty);
            if (dy < 0) btn_refMark_Up_Click(this, EventArgs.Empty);
            else if (dy > 0) btn_refMark_Down_Click(this, EventArgs.Empty);
        }

        public bool HasTemplate { get { return svd_Template.Image != null; } }

        public string RefPointText
        {
            get
            {
                try
                {
                    if (Subject == null || Subject.RefPoint == null || !HasTemplate) return "";
                    return string.Format("({0:0}, {1:0})", Subject.RefPoint.PointF.X, Subject.RefPoint.PointF.Y);
                }
                catch (Exception) { return ""; }
            }
        }

        NumericUpDown NumberBox(string key)
        {
            switch (key)
            {
                case "ScaleFirst": return nud_Template_ScaleFirst;
                case "ScaleLast": return nud_Template_ScaleLast;
                case "AngleNeg": return nud_Template_Method_Degree1;
                case "AnglePos": return nud_Template_Method_Degree2;
                case "MaxCount": return nud_TMmaxCount;
                case "FirstStep": return nud_FirstStep;
                case "PCreteria": return nud_templPCreteria;
                case "Precision": return nud_templPrecision;
                case "THLow": return nud_TempTHLow;
                case "THHigh": return nud_TempTHHigh;
                case "TempScaleMin": return nud_TempScaleMin;
                case "TempScaleMax": return nud_TempScaleMax;
            }
            return null;
        }

        CheckBox CheckField(string key)
        {
            switch (key)
            {
                case "UseEdge": return chb_TempUseEdge;
                case "AutoParam": return chb_AutoParam;
                case "IsAutoIndex": return chb_AutoIndex;
            }
            return null;
        }

        /// <summary>Range of a number field (taken from the WinForms control).</summary>
        public void GetNumberRange(string key, out double min, out double max, out int decimals, out double step)
        {
            NumericUpDown n = NumberBox(key);
            min = (double)n.Minimum; max = (double)n.Maximum; decimals = n.DecimalPlaces; step = (double)n.Increment;
        }

        public double GetNumber(string key)
        {
            PropertyInfo p = typeof(SvTemplateMatch).GetProperty(key);
            return Convert.ToDouble(p.GetValue(Subject, null));
        }

        public void SetNumber(string key, double value)
        {
            NumericUpDown n = NumberBox(key);
            decimal v = (decimal)value;
            if (v < n.Minimum) v = n.Minimum;
            if (v > n.Maximum) v = n.Maximum;
            try { n.Value = v; } catch (Exception) { }                      // runs the same handlers as the old editor (edge preview, limits)
            PropertyInfo p = typeof(SvTemplateMatch).GetProperty(key);
            p.SetValue(Subject, Convert.ChangeType((double)v, p.PropertyType), null); // the control may never have been shown, so its binding is not active
        }

        public bool GetBool(string key)
        {
            PropertyInfo p = typeof(SvTemplateMatch).GetProperty(key);
            return (bool)p.GetValue(Subject, null);
        }

        public void SetBool(string key, bool value)
        {
            CheckBox c = CheckField(key);
            try { c.Checked = value; } catch (Exception) { }
            PropertyInfo p = typeof(SvTemplateMatch).GetProperty(key);
            p.SetValue(Subject, value, null);
        }

        public string GetPriority() { return Subject.Priority.ToString(); }

        public void SetPriority(string name)
        {
            Subject.Priority = (SvTemplateMatch.Direction)Enum.Parse(typeof(SvTemplateMatch.Direction), name);
        }

        int mSelectedIndex;
        public int SelectedIndex
        {
            get { return mSelectedIndex; }
            set
            {
                if (mSelectedIndex == value) return;
                mSelectedIndex = value;
                SetTemplateImage(value);
                int refreshindex = value - 1;

                if (value == 0)
                    refreshindex = 0;

                RefreshPatternList(refreshindex);
            }
        }

        void InitBinding()
        {
            source = new BindingSource(typeof(SvTemplateMatch), null);
            nud_Template_ScaleFirst.DataBindings.Add("Value", source, "ScaleFirst", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_ScaleLast.DataBindings.Add("Value", source, "ScaleLast", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_Method_Degree1.DataBindings.Add("Value", source, "AngleNeg", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_Method_Degree2.DataBindings.Add("Value", source, "AnglePos", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TMmaxCount.DataBindings.Add("Value", source, "MaxCount", true, DataSourceUpdateMode.OnPropertyChanged, 1);
            nud_FirstStep.DataBindings.Add("Value", source, "FirstStep", true, DataSourceUpdateMode.OnPropertyChanged);
            
            cb_TemplPriority.DisplayMember = "Key"; cb_TemplPriority.ValueMember = "Value";
            cb_TemplPriority.DataSource = Enum.GetValues(typeof(SvTemplateMatch.Direction)).Cast<SvTemplateMatch.Direction>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_TemplPriority.DataBindings.Add("SelectedValue", source, "Priority", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_templPCreteria.DataBindings.Add("Value", source, "PCreteria", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_templPrecision.DataBindings.Add("Value", source, "Precision", true, DataSourceUpdateMode.OnPropertyChanged);
            chb_TempUseEdge.DataBindings.Add("Checked", source, "UseEdge", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempTHLow.DataBindings.Add("Value", source, "THLow", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempTHHigh.DataBindings.Add("Value", source, "THHigh", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempScaleMin.DataBindings.Add("Value", source, "TempScaleMin", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempScaleMax.DataBindings.Add("Value", source, "TempScaleMax", true, DataSourceUpdateMode.OnPropertyChanged);
            chb_AutoParam.DataBindings.Add("Checked", source, "AutoParam", true, DataSourceUpdateMode.OnPropertyChanged);

            chb_AutoIndex.DataBindings.Add("Checked", source, "IsAutoIndex", true, DataSourceUpdateMode.OnPropertyChanged);
            this.DataBindings.Add("SelectedIndex", source, "SelectedPatternIndex", true, DataSourceUpdateMode.OnPropertyChanged);

            //chb_TempUseEdge.DataBindings.Add("Checked", source, "Mask.OnMask", true, DataSourceUpdateMode.OnPropertyChanged);
        }
        
        private void btn_TemplateMatching_Grab_Click(object sender, EventArgs e)
        {            
            SvImageInfo imageInfo =  (SvImageInfo)SvDisplayViewEdit.imageListComboBox.SelectedItem;
            if (!imageInfo.ImageName.Contains("Train")) return;

            SvImage image = SvDisplayViewEdit.Display.Image;
            if (image == null) return;

            Mat templateImg = templateRegion.GetROIRegion(image.Mat);
            
            if (templateImg == null)
            {
                //MessageBox.Show("선택된 이미지 영역이 없습니다.");
                MessageBox.Show("There does not select image.");
                return;
            }

            svd_Template.Image = new SvImage(templateImg);

            PatternData patterndata = new PatternData(svd_Template.Image);

            Subject.mPatternDataList.Insert(0, new KeyValuePair<string, PatternData>("", patterndata));
            //if (Subject.mPatternDataList.Count > )
            Subject.SelectedPatternIndex = 0;

            SetTemplateImage(0);
            RefreshPatternList();
            nud_Threshold_ValueChanged(this, null);
        }

        private void chb_TempUseEdge_CheckedChanged(object sender, EventArgs e)
        {
            if (chb_TempUseEdge.Checked)
            {
                //btn_ResetMask.Enabled = true;
                //chb_MaskOn.Enabled = true;
                svd_Template.GraphicsFuncCollection.Add(DrawEdgeImage);
                nud_Threshold_ValueChanged(this, null);
            }
            else
            {
                //chb_MaskOn.Enabled = false;
                //btn_ResetMask.Enabled = false;
                svd_Template.GraphicsFuncCollection.Clear();
            }
        }

        Mat Edge;

        void DrawEdgeImage(Graphics gdi)
        {
            if (Subject.TemplateImage == null || Edge == null) return;

            Bitmap bitmap;
            Mat maskedEdge = new Mat();

            Mat mask = Subject.Mask.MaskMat;
            Mat colorEdge = new Mat(mask.Size(), MatType.CV_8UC4);
            Mat nullMat = new Mat(mask.Size(), MatType.CV_8UC1, new Scalar(0));
            
            if (Edge.Type() != MatType.CV_8UC1) return;

            if (mask != null && mask.Width != 0 && mask.Height != 0)
            {
                Edge.CopyTo(maskedEdge, mask);
                Cv2.Merge(new Mat[] { nullMat, maskedEdge, nullMat, maskedEdge }, colorEdge);
                bitmap = colorEdge.ToBitmap();
            }
            else
            {
                Cv2.Merge(new Mat[] { nullMat, Edge, nullMat, Edge }, colorEdge);
                bitmap = colorEdge.ToBitmap();
            }

            gdi.DrawImageUnscaled(bitmap, 0, 0);

            nullMat.Dispose();
            colorEdge.Dispose();
            maskedEdge.Dispose();
            bitmap.Dispose();
        }
        
        private void btn_RefToCenter_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(svd_Template.Image.Width / 2, svd_Template.Image.Height / 2);
        }

        private void btn_ResetMask_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.Mask.ResetMask();
        }

        private void nud_Threshold_ValueChanged(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;
            if (!chb_TempUseEdge.Checked) return;

            Mat src = Subject.TemplateImage.Mat;

            int minSize = Math.Min(Math.Min(src.Width, src.Height), 1000);
            Subject.GetEdge(src, minSize, out Edge, 1);
            //SvFunc.ShowTestImg(Edge, 0.25);
            //src.Dispose();

            svd_Template.Invalidate();
        }

        private void nud_TempScaleMin_ValueChanged(object sender, EventArgs e)
        {
            if (nud_TempScaleMin.Value > nud_TempScaleMax.Value)
                nud_TempScaleMin.Value = nud_TempScaleMax.Value;
        }

        private void nud_TempScaleMax_ValueChanged(object sender, EventArgs e)
        {
            if (nud_TempScaleMax.Value < nud_TempScaleMin.Value)
                nud_TempScaleMax.Value = nud_TempScaleMin.Value;
        }

        private void chb_MaskOn_CheckedChanged(object sender, EventArgs e)
        {
            //Subject.Mask.OnMask = chb_MaskOn.Checked;

            //if (chb_MaskOn.Checked)
            //    chb_MaskOn.Text = "Mask On";
            //else
            //    chb_MaskOn.Text = "Mask Off";
            if (svd_Template.Image == null) return;

            svd_Template.GraphicsCollection.Clear();
            PatternData pattern = Subject.mPatternDataList[Subject.SelectedPatternIndex].Value;
            SvMaskingEdit maskedit = new SvMaskingEdit();
            SvMasking svMask = new SvMasking();
            SvToolEditForm maskform = new SvToolEditForm(maskedit);

            //maskedit.svDisplayViewEdit.Display.Image = pattern.PatternImage;
            //maskedit.svDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(pattern.MaskImage);

            svMask.InputImage = pattern.PatternImage;
            svMask.Mask = pattern.MaskImage;
            pattern.MaskImage.DrawMask = true;

            maskedit.Subject = svMask;

            svMask.InitOutProperty();
            svMask.Run(true);
            maskform.ShowDialog();

            pattern.MaskImage.DrawMask = true;
            svd_Template.GraphicsCollection.Add(pattern.MaskImage);

            pattern.MakeMaskedPattern();
        }

        private void chb_AutoParam_CheckedChanged(object sender, EventArgs e)
        {
            bool autoCheck = chb_AutoParam.Checked;

            nud_FirstStep.ReadOnly = autoCheck;
            nud_templPrecision.ReadOnly = autoCheck;
            nud_Template_ScaleFirst.ReadOnly = autoCheck;
            nud_Template_ScaleLast.ReadOnly = autoCheck;
            nud_Template_Method_Degree1.ReadOnly = autoCheck;
            nud_Template_Method_Degree2.ReadOnly = autoCheck;
        }

        #region Pattern Save, Multi Pattern
        List<SvDisplayViewInteract> mPatternDisplayList = new List<SvDisplayViewInteract>();
        List<Label> mPatternLabelList = new List<Label>();

        private void btn_PatternSave_Click(object sender, EventArgs e)
        {
            if (svd_Template == null || svd_Template.Image == null || svd_Template.Image.Width == 0 || svd_Template.Image.Height == 0)
                return;
            //if (Subject.TemplateImage == null || Subject.TemplateImage.Mat == null || Subject.TemplateImage.Width == 0 || Subject.TemplateImage.Height == 0)
            //    return;

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            this.Cursor = Cursors.WaitCursor;
            PatternData patternData = new PatternData(Subject.TemplateImage, Subject.Mask, Subject.RefPoint);

            // File Save
            patternData.SavePattern(fd.FileName);

            // Icon 만들기
            //using (Stream IconStream = System.IO.File.OpenWrite(fd.FileName))
            //{
            //    Bitmap bitmap = Subject.TemplateImage.Mat.ToBitmap(System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            //    bitmap.SetResolution(72, 72);
            //    Icon icon = System.Drawing.Icon.FromHandle(bitmap.GetHicon());
            //    icon.Save(IconStream);
            //}
            this.Cursor = Cursors.Default;

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);
        }

        private void btn_PatternLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            fd.Multiselect = true;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            this.Cursor = Cursors.WaitCursor;
            
            for (int i = 0; i < Subject.mPatternDataList.Count; i++)
            {
                Subject.mPatternDataList[i].Value.Dispose();
            }

            Subject.mPatternDataList.Clear();
            Subject.mPatternDataList.Clear();

            foreach (string path in fd.FileNames)
            {
                Subject.mPatternDataList.Add(new KeyValuePair<string, PatternData>(path, (PatternData)serializer.Deserializing(path)));
            }
            
            InitPatternList();

            this.Cursor = Cursors.Default;

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);
        }

        private void btn_Pre_Click(object sender, EventArgs e)
        {
            //if (!lb_patter0.Text.Contains('.')) return; 
            string[] lb = lb_patter0.Text.Split('.');
            int startIndex;
            if (!int.TryParse(lb[0], out startIndex)) return;
            if (startIndex <= 0) return;
            startIndex--;

            RefreshPatternList(startIndex);
        }
        private void btn_Next_Click(object sender, EventArgs e)
        {
            if (!lb_patter0.Text.Contains('.')) return;
            string[] lb = lb_patter3.Text.Split('.');
            int endIndex;
            if (!int.TryParse(lb[0], out endIndex)) return;
            if (endIndex >= Subject.mPatternDataList.Count - 1) return;
            endIndex++;
            
            RefreshPatternList(endIndex - 3);
        }
        
        private void btn_PatternAdd_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            fd.Multiselect = true;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            foreach (string path in fd.FileNames)
            {
                if (Subject.mPatternDataList.FindIndex(x => x.Key == path) >= 0) continue;
                Subject.mPatternDataList.Add(new KeyValuePair<string, PatternData>(path, (PatternData)serializer.Deserializing(path)));
            }

            RefreshPatternList();
        }

        private void btn_PatternRemove_Click(object sender, EventArgs e)
        {
            if (Subject.mPatternDataList.Count > Subject.SelectedPatternIndex && Subject.SelectedPatternIndex >= 0)
            {
                Subject.mPatternDataList[Subject.SelectedPatternIndex].Value.Dispose();
                Subject.TemplateImage.Dispose();
                Subject.mPatternDataList.RemoveAt(Subject.SelectedPatternIndex);
            }

            if (Subject.SelectedPatternIndex >= Subject.mPatternDataList.Count)
                SetTemplateImage(Subject.mPatternDataList.Count - 1, false);

            RefreshPatternList();
        }

        private void InitPatternList()
        {
            if (!NativeUi)
                for (int i = 0; i < 4; i++)
                {
                    mPatternDisplayList[i].Image = null;
                }

            SetTemplateImage(Subject.SelectedPatternIndex, false);
            RefreshPatternList(0);
        }

        private void RefreshPatternList(int _startindex = -1)
        {
            RefreshPatternListCore(_startindex);
            NotifyPatterns();
        }

        private void RefreshPatternListCore(int _startindex)
        {
            int startindex = 0;
            if (_startindex < 0) // 동일 Index일 경우...-1, -2도 들어올 수 있음!!
            {
                if (!int.TryParse(lb_patter0.Text.Split('.')[0], out startindex))
                    _startindex = 0;
                else
                    _startindex = startindex;
            }

            for (int i = 0; i < mPatternDisplayList.Count; i++)
            {
                string labelName = (_startindex + i).ToString();
                if (_startindex + i < Subject.mPatternDataList.Count)
                    labelName += "." + System.IO.Path.GetFileNameWithoutExtension(Subject.mPatternDataList[_startindex + i].Key);
                mPatternLabelList[i].Text = labelName;
            }
            
            btn_Selected.Visible = false;

            for (int i = 0; i < mPatternDisplayList.Count && !NativeUi; i++)
            {
                //if (!lb_patter0.Text.Contains('.')) return;
                string[] lb = lb_patter0.Text.Split('.');

                int startIndex;
                if (!int.TryParse(lb[0], out startIndex)) break;
                // 패턴이 없으면 패턴리스트에서 지워준다.
                if (startIndex + i >= Subject.mPatternDataList.Count)
                {
                    mPatternDisplayList[i].Image = null;
                    continue;
                }
                
                mPatternDisplayList[i].Image = Subject.mPatternDataList[startIndex + i].Value.PatternImage;
                mPatternDisplayList[i].FitToWindow();

                // 빨간 박스 표시
                if (startIndex + i == Subject.SelectedPatternIndex)
                {
                    btn_Selected.Visible = true;
                    btn_Selected.Location = new System.Drawing.Point(mPatternDisplayList[i].Location.X - 2, mPatternDisplayList[i].Location.Y - 2);
                }
            }

            svd_Template.Image = null;

            // 처리할 항목이 없으면 리턴
            if (Subject.mPatternDataList.Count == 0) return;

            // 화면에 현재 Pattern 표시
            if (Subject.SelectedPatternIndex > -1)
                SetTemplateImage(Subject.SelectedPatternIndex);
        }

        private void svd_SubPattern_Click(object sender, EventArgs e)
        {
            int selectedDisplayIndex;
            string lbName = (sender as SvDisplayViewInteract).Name;

            selectedDisplayIndex = int.Parse(lbName.Substring(lbName.Length - 1));
            int selectedIndex = int.Parse(mPatternLabelList[selectedDisplayIndex].Text.Split('.')[0]);

            RefreshPatternList();

            if (selectedIndex == Subject.SelectedPatternIndex) return;


            SetTemplateImage(selectedIndex);
        }

        private void SetTemplateImage(int _index, bool _saveMask = true)
        {
            if (Subject.mPatternDataList.Count <= _index) return;
            if (Subject.mPatternDataList.Count == 0) return;

            Subject.SelectedPatternIndex = _index;

            // 만약 Edge 사용한다면... Edge 표시
            if (chb_TempUseEdge.Checked)
                nud_Threshold_ValueChanged(null, null);

            PatternData pattrnData;
            if (_index == -1)
                pattrnData = new PatternData(); // 모든 멤버가 null임
            else         
                pattrnData = Subject.mPatternDataList[_index].Value;

            Subject.TemplateImage = pattrnData.PatternImage;
            Subject.Mask = pattrnData.MaskImage;
            Subject.RefPoint = pattrnData.RefPoint;

            // 이코드가 있어야 현재 Subject.Refpoint를 화면에 뿌려주게 된다.
            //Subject.mPatternDataList[Subject.mSelectedPatternIndex].Value.RefPoint = Subject.RefPoint;


            ResetTepmplateGraphics();
        }

        #endregion

        private void btn_refMark_Up_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X, Subject.RefPoint.PointF.Y - 1);
        }

        private void btn_refMark_Down_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X, Subject.RefPoint.PointF.Y + 1);
        }

        private void btn_refMark_Left_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X - 1, Subject.RefPoint.PointF.Y);
        }

        private void btn_refMark_Right_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X + 1, Subject.RefPoint.PointF.Y);
        }
    }
}
