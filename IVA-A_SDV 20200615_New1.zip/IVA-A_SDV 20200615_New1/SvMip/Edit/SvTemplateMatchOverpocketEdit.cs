﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Core;
using System.Reflection;
using SvMip.Edit.Base;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;
using System.IO;
using System.Runtime.Serialization;
using SvMip.Display;

namespace SvMip.Edit
{
    public partial class SvTemplateMatchOverpocketEdit : SvToolEditBase
    {
        SvRotationRectangle templateRegion;

        public SvTemplateMatchOverpocketEdit()
        {
            InitializeComponent();
            InitBinding();

            this.SubjectChanged += SvTMEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;

            templateRegion = new SvRotationRectangle();

            mPatternDisplayList = new List<SvDisplayViewInteract>();
            mPatternDisplayList.Add(svd_SubPattern0);
            mPatternDisplayList.Add(svd_SubPattern1);
            mPatternDisplayList.Add(svd_SubPattern2);
            mPatternDisplayList.Add(svd_SubPattern3);

            mPatternLabelList = new List<Label>();
            mPatternLabelList.Add(lb_patter0);
            mPatternLabelList.Add(lb_patter1);
            mPatternLabelList.Add(lb_patter2);
            mPatternLabelList.Add(lb_patter3);
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("Train"))
            {
                if (Subject.InputImage == null) return;
                SvDisplayViewEdit.Display.Image = Subject.InputImage;
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(templateRegion);
            }
            else if (imageInfo.ImageName.Contains("OutputImage"))
            {
                if (Subject.InputImage == null) return;
                SvDisplayViewEdit.Display.Image = Subject.InputImage;
                //if (SvDisplayViewEdit.Display.Image == null) return;
                //DrawResult(SvDisplayViewEdit.Display);
            }
        }


        protected override void InitDisplayViewEdit()
        {
            SvDisplayViewEdit.InsertCustomImage(1, new SvImageInfo("[TemplateMatch] Train"));
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvTemplateMatchOverpocket Subject
        {
            get { return base.GetSubject() as SvTemplateMatchOverpocket; }
            set { base.SetSubject(value); }
        }

        void SvTMEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);

            svd_Template.Image = null;
            InitPatternList();
            SetTemplateImage(Subject.SelectedPatternIndex);

            ResetTepmplateGraphics();
        }

        void ResetTepmplateGraphics()
        {
            svd_Template.InteractiveGraphicsCollection.Clear();
            svd_Template.GraphicsCollection.Clear();

            if (Subject.TemplateImage == null)
            {
                return;
            }
            svd_Template.Image = Subject.TemplateImage;

            if (Subject.RefPoint != null)
            {
                //Subject.RefPoint.SelectionSize = (int)(10 / svd_Template.ZoomRatio);
                svd_Template.InteractiveGraphicsCollection.Add(Subject.RefPoint);
            }

            if (Subject.Mask != null && Subject.SelectedPatternIndex > -1 && Subject.mPatternDataOverpocketList.Count > Subject.SelectedPatternIndex)
            {
                Subject.Mask = Subject.mPatternDataOverpocketList[Subject.SelectedPatternIndex].Value.MaskImage;
                svd_Template.GraphicsCollection.Add(Subject.Mask);

                Subject.Mask.DrawMask = true;

                // 만약 Edge 사용한다면... Edge 표시
                if (chb_TempUseEdge.Checked)
                    nud_Threshold_ValueChanged(null, null);
            }
        }

        BindingSource source;

        int mSelectedIndex;
        public int SelectedIndex
        {
            get { return mSelectedIndex; }
            set
            {
                if (mSelectedIndex == value) return;
                mSelectedIndex = value;
                SetTemplateImage(value);
                int refreshindex = value - 1;

                if (value == 0)
                    refreshindex = 0;

                RefreshPatternList(refreshindex);
            }
        }

        void InitBinding()
        {
            source = new BindingSource(typeof(SvTemplateMatchOverpocket), null);
            nud_Template_ScaleFirst.DataBindings.Add("Value", source, "ScaleFirst", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_ScaleLast.DataBindings.Add("Value", source, "ScaleLast", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_Method_Degree1.DataBindings.Add("Value", source, "AngleNeg", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_Method_Degree2.DataBindings.Add("Value", source, "AnglePos", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TMmaxCount.DataBindings.Add("Value", source, "MaxCount", true, DataSourceUpdateMode.OnPropertyChanged, 1);
            nud_FirstStep.DataBindings.Add("Value", source, "FirstStep", true, DataSourceUpdateMode.OnPropertyChanged);

            cb_TemplPriority.DisplayMember = "Key"; cb_TemplPriority.ValueMember = "Value";
            cb_TemplPriority.DataSource = Enum.GetValues(typeof(SvTemplateMatchOverpocket.Direction)).Cast<SvTemplateMatchOverpocket.Direction>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_TemplPriority.DataBindings.Add("SelectedValue", source, "Priority", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_templPCreteria.DataBindings.Add("Value", source, "PCreteria", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_templPrecision.DataBindings.Add("Value", source, "Precision", true, DataSourceUpdateMode.OnPropertyChanged);
            chb_TempUseEdge.DataBindings.Add("Checked", source, "UseEdge", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempTHLow.DataBindings.Add("Value", source, "THLow", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempTHHigh.DataBindings.Add("Value", source, "THHigh", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempScaleMin.DataBindings.Add("Value", source, "TempScaleMin", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempScaleMax.DataBindings.Add("Value", source, "TempScaleMax", true, DataSourceUpdateMode.OnPropertyChanged);
            chb_AutoParam.DataBindings.Add("Checked", source, "AutoParam", true, DataSourceUpdateMode.OnPropertyChanged);

            chb_AutoIndex.DataBindings.Add("Checked", source, "IsAutoIndex", true, DataSourceUpdateMode.OnPropertyChanged);
            this.DataBindings.Add("SelectedIndex", source, "SelectedPatternIndex", true, DataSourceUpdateMode.OnPropertyChanged);

            //chb_TempUseEdge.DataBindings.Add("Checked", source, "Mask.OnMask", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void btn_TemplateMatching_Grab_Click(object sender, EventArgs e)
        {
            SvImageInfo imageInfo = (SvImageInfo)SvDisplayViewEdit.imageListComboBox.SelectedItem;
            if (!imageInfo.ImageName.Contains("Train")) return;

            SvImage image = SvDisplayViewEdit.Display.Image;
            if (image == null) return;

            Mat templateImg = templateRegion.GetROIRegion(image.Mat);

            if (templateImg == null)
            {
                //MessageBox.Show("선택된 이미지 영역이 없습니다.");
                MessageBox.Show("There does not select image.");
                return;
            }

            svd_Template.Image = new SvImage(templateImg);

            PatternDataOverpocket patterndata = new PatternDataOverpocket(svd_Template.Image);
            //20200514 HNB add value to MaskCenterPoint
            patterndata.MaskCenterPoint = new SvPoint(templateRegion.Center.X, templateRegion.Center.Y);
            Subject.mPatternDataOverpocketList.Insert(0, new KeyValuePair<string, PatternDataOverpocket>("", patterndata));
            //if (Subject.mPatternDataList.Count > )
            Subject.SelectedPatternIndex = 0;

            SetTemplateImage(0);
            RefreshPatternList();
            nud_Threshold_ValueChanged(this, null);
        }

        private void chb_TempUseEdge_CheckedChanged(object sender, EventArgs e)
        {
            if (chb_TempUseEdge.Checked)
            {
                //btn_ResetMask.Enabled = true;
                //chb_MaskOn.Enabled = true;
                svd_Template.GraphicsFuncCollection.Add(DrawEdgeImage);
                nud_Threshold_ValueChanged(this, null);
            }
            else
            {
                //chb_MaskOn.Enabled = false;
                //btn_ResetMask.Enabled = false;
                svd_Template.GraphicsFuncCollection.Clear();
            }
        }

        Mat Edge;

        void DrawEdgeImage(Graphics gdi)
        {
            if (Subject.TemplateImage == null || Edge == null) return;

            Bitmap bitmap;
            Mat maskedEdge = new Mat();

            Mat mask = Subject.Mask.MaskMat;
            Mat colorEdge = new Mat(mask.Size(), MatType.CV_8UC4);
            Mat nullMat = new Mat(mask.Size(), MatType.CV_8UC1, new Scalar(0));

            if (Edge.Type() != MatType.CV_8UC1) return;

            if (mask != null && mask.Width != 0 && mask.Height != 0)
            {
                Edge.CopyTo(maskedEdge, mask);
                Cv2.Merge(new Mat[] { nullMat, maskedEdge, nullMat, maskedEdge }, colorEdge);
                bitmap = colorEdge.ToBitmap();
            }
            else
            {
                Cv2.Merge(new Mat[] { nullMat, Edge, nullMat, Edge }, colorEdge);
                bitmap = colorEdge.ToBitmap();
            }

            gdi.DrawImageUnscaled(bitmap, 0, 0);

            nullMat.Dispose();
            colorEdge.Dispose();
            maskedEdge.Dispose();
            bitmap.Dispose();
        }

        private void btn_RefToCenter_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(svd_Template.Image.Width / 2, svd_Template.Image.Height / 2);
        }

        private void btn_ResetMask_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.Mask.ResetMask();
        }

        private void nud_Threshold_ValueChanged(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;
            if (!chb_TempUseEdge.Checked) return;

            Mat src = Subject.TemplateImage.Mat;

            int minSize = Math.Min(Math.Min(src.Width, src.Height), 1000);
            Subject.GetEdge(src, minSize, out Edge, 1);
            //SvFunc.ShowTestImg(Edge, 0.25);
            //src.Dispose();

            svd_Template.Invalidate();
        }

        private void nud_TempScaleMin_ValueChanged(object sender, EventArgs e)
        {
            if (nud_TempScaleMin.Value > nud_TempScaleMax.Value)
                nud_TempScaleMin.Value = nud_TempScaleMax.Value;
        }

        private void nud_TempScaleMax_ValueChanged(object sender, EventArgs e)
        {
            if (nud_TempScaleMax.Value < nud_TempScaleMin.Value)
                nud_TempScaleMax.Value = nud_TempScaleMin.Value;
        }

        private void chb_MaskOn_CheckedChanged(object sender, EventArgs e)
        {
            //Subject.Mask.OnMask = chb_MaskOn.Checked;

            //if (chb_MaskOn.Checked)
            //    chb_MaskOn.Text = "Mask On";
            //else
            //    chb_MaskOn.Text = "Mask Off";
            if (svd_Template.Image == null) return;

            svd_Template.GraphicsCollection.Clear();
            PatternDataOverpocket pattern = Subject.mPatternDataOverpocketList[Subject.SelectedPatternIndex].Value;
            SvMaskingEdit maskedit = new SvMaskingEdit();
            SvMasking svMask = new SvMasking();
            SvToolEditForm maskform = new SvToolEditForm(maskedit);

            //maskedit.svDisplayViewEdit.Display.Image = pattern.PatternImage;
            //maskedit.svDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(pattern.MaskImage);

            svMask.InputImage = pattern.PatternImage;
            svMask.Mask = pattern.MaskImage;
            pattern.MaskImage.DrawMask = true;

            maskedit.Subject = svMask;

            svMask.InitOutProperty();
            svMask.Run(true);
            maskform.ShowDialog();

            pattern.MaskImage.DrawMask = true;
            svd_Template.GraphicsCollection.Add(pattern.MaskImage);

            pattern.MakeMaskedPattern();
        }

        private void chb_AutoParam_CheckedChanged(object sender, EventArgs e)
        {
            bool autoCheck = chb_AutoParam.Checked;

            nud_FirstStep.ReadOnly = autoCheck;
            nud_templPrecision.ReadOnly = autoCheck;
            nud_Template_ScaleFirst.ReadOnly = autoCheck;
            nud_Template_ScaleLast.ReadOnly = autoCheck;
            nud_Template_Method_Degree1.ReadOnly = autoCheck;
            nud_Template_Method_Degree2.ReadOnly = autoCheck;
        }

        #region Pattern Save, Multi Pattern
        List<SvDisplayViewInteract> mPatternDisplayList = new List<SvDisplayViewInteract>();
        List<Label> mPatternLabelList = new List<Label>();

        private void btn_PatternSave_Click(object sender, EventArgs e)
        {
            if (svd_Template == null || svd_Template.Image == null || svd_Template.Image.Width == 0 || svd_Template.Image.Height == 0)
                return;
            //if (Subject.TemplateImage == null || Subject.TemplateImage.Mat == null || Subject.TemplateImage.Width == 0 || Subject.TemplateImage.Height == 0)
            //    return;

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            this.Cursor = Cursors.WaitCursor;
            PatternDataOverpocket patternData = new PatternDataOverpocket(Subject.TemplateImage, Subject.Mask, Subject.RefPoint, Subject.MaskCenterPoint);

            // File Save
            patternData.SavePattern(fd.FileName);

            // Icon 만들기
            //using (Stream IconStream = System.IO.File.OpenWrite(fd.FileName))
            //{
            //    Bitmap bitmap = Subject.TemplateImage.Mat.ToBitmap(System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            //    bitmap.SetResolution(72, 72);
            //    Icon icon = System.Drawing.Icon.FromHandle(bitmap.GetHicon());
            //    icon.Save(IconStream);
            //}
            this.Cursor = Cursors.Default;

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);
        }

        private void btn_PatternLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            fd.Multiselect = true;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            this.Cursor = Cursors.WaitCursor;

            for (int i = 0; i < Subject.mPatternDataOverpocketList.Count; i++)
            {
                Subject.mPatternDataOverpocketList[i].Value.Dispose();
            }

            Subject.mPatternDataOverpocketList.Clear();
            Subject.mPatternDataOverpocketList.Clear();

            foreach (string path in fd.FileNames)
            {
                Subject.mPatternDataOverpocketList.Add(new KeyValuePair<string, PatternDataOverpocket>(path, (PatternDataOverpocket)serializer.Deserializing(path)));
            }

            InitPatternList();

            this.Cursor = Cursors.Default;

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);
        }

        private void btn_Pre_Click(object sender, EventArgs e)
        {
            //if (!lb_patter0.Text.Contains('.')) return; 
            string[] lb = lb_patter0.Text.Split('.');
            int startIndex;
            if (!int.TryParse(lb[0], out startIndex)) return;
            if (startIndex <= 0) return;
            startIndex--;

            RefreshPatternList(startIndex);
        }
        private void btn_Next_Click(object sender, EventArgs e)
        {
            if (!lb_patter0.Text.Contains('.')) return;
            string[] lb = lb_patter3.Text.Split('.');
            int endIndex;
            if (!int.TryParse(lb[0], out endIndex)) return;
            if (endIndex >= Subject.mPatternDataOverpocketList.Count - 1) return;
            endIndex++;

            RefreshPatternList(endIndex - 3);
        }

        private void btn_PatternAdd_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            fd.Multiselect = true;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            foreach (string path in fd.FileNames)
            {
                if (Subject.mPatternDataOverpocketList.FindIndex(x => x.Key == path) >= 0) continue;
                Subject.mPatternDataOverpocketList.Add(new KeyValuePair<string, PatternDataOverpocket>(path, (PatternDataOverpocket)serializer.Deserializing(path)));
            }

            RefreshPatternList();
        }

        private void btn_PatternRemove_Click(object sender, EventArgs e)
        {
            if (Subject.mPatternDataOverpocketList.Count > Subject.SelectedPatternIndex && Subject.SelectedPatternIndex >= 0)
            {
                Subject.mPatternDataOverpocketList[Subject.SelectedPatternIndex].Value.Dispose();
                Subject.TemplateImage.Dispose();
                Subject.mPatternDataOverpocketList.RemoveAt(Subject.SelectedPatternIndex);
            }

            if (Subject.SelectedPatternIndex >= Subject.mPatternDataOverpocketList.Count)
                SetTemplateImage(Subject.mPatternDataOverpocketList.Count - 1, false);

            RefreshPatternList();
        }

        private void InitPatternList()
        {
            for (int i = 0; i < 4; i++)
            {
                mPatternDisplayList[i].Image = null;
            }

            SetTemplateImage(Subject.SelectedPatternIndex, false);
            RefreshPatternList(0);
        }

        private void RefreshPatternList(int _startindex = -1)
        {
            int startindex = 0;
            if (_startindex < 0) // 동일 Index일 경우...-1, -2도 들어올 수 있음!!
            {
                if (!int.TryParse(lb_patter0.Text.Split('.')[0], out startindex))
                    _startindex = 0;
                else
                    _startindex = startindex;
            }

            for (int i = 0; i < mPatternDisplayList.Count; i++)
            {
                string labelName = (_startindex + i).ToString();
                if (_startindex + i < Subject.mPatternDataOverpocketList.Count)
                    labelName += "." + System.IO.Path.GetFileNameWithoutExtension(Subject.mPatternDataOverpocketList[_startindex + i].Key);
                mPatternLabelList[i].Text = labelName;
            }

            btn_Selected.Visible = false;

            for (int i = 0; i < mPatternDisplayList.Count; i++)
            {
                //if (!lb_patter0.Text.Contains('.')) return;
                string[] lb = lb_patter0.Text.Split('.');

                int startIndex;
                if (!int.TryParse(lb[0], out startIndex)) break;
                // 패턴이 없으면 패턴리스트에서 지워준다.
                if (startIndex + i >= Subject.mPatternDataOverpocketList.Count)
                {
                    mPatternDisplayList[i].Image = null;
                    continue;
                }

                mPatternDisplayList[i].Image = Subject.mPatternDataOverpocketList[startIndex + i].Value.PatternImage;
                mPatternDisplayList[i].FitToWindow();

                // 빨간 박스 표시
                if (startIndex + i == Subject.SelectedPatternIndex)
                {
                    btn_Selected.Visible = true;
                    btn_Selected.Location = new System.Drawing.Point(mPatternDisplayList[i].Location.X - 2, mPatternDisplayList[i].Location.Y - 2);
                }
            }

            svd_Template.Image = null;

            // 처리할 항목이 없으면 리턴
            if (Subject.mPatternDataOverpocketList.Count == 0) return;

            // 화면에 현재 Pattern 표시
            if (Subject.SelectedPatternIndex > -1)
                SetTemplateImage(Subject.SelectedPatternIndex);
        }

        private void svd_SubPattern_Click(object sender, EventArgs e)
        {
            int selectedDisplayIndex;
            string lbName = (sender as SvDisplayViewInteract).Name;

            selectedDisplayIndex = int.Parse(lbName.Substring(lbName.Length - 1));
            int selectedIndex = int.Parse(mPatternLabelList[selectedDisplayIndex].Text.Split('.')[0]);

            RefreshPatternList();

            if (selectedIndex == Subject.SelectedPatternIndex) return;


            SetTemplateImage(selectedIndex);
        }

        private void SetTemplateImage(int _index, bool _saveMask = true)
        {
            if (Subject.mPatternDataOverpocketList.Count <= _index) return;
            if (Subject.mPatternDataOverpocketList.Count == 0) return;

            Subject.SelectedPatternIndex = _index;

            // 만약 Edge 사용한다면... Edge 표시
            if (chb_TempUseEdge.Checked)
                nud_Threshold_ValueChanged(null, null);

            PatternDataOverpocket pattrnData;
            if (_index == -1)
                pattrnData = new PatternDataOverpocket(); // 모든 멤버가 null임
            else
                pattrnData = Subject.mPatternDataOverpocketList[_index].Value;

            Subject.TemplateImage = pattrnData.PatternImage;
            Subject.Mask = pattrnData.MaskImage;
            Subject.RefPoint = pattrnData.RefPoint;
            //20200414 HNB
            Subject.MaskCenterPoint = pattrnData.MaskCenterPoint;
            // 이코드가 있어야 현재 Subject.Refpoint를 화면에 뿌려주게 된다.
            //Subject.mPatternDataList[Subject.mSelectedPatternIndex].Value.RefPoint = Subject.RefPoint;


            ResetTepmplateGraphics();
        }

        #endregion

        private void btn_refMark_Up_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X, Subject.RefPoint.PointF.Y - 1);
        }

        private void btn_refMark_Down_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X, Subject.RefPoint.PointF.Y + 1);
        }

        private void btn_refMark_Left_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X - 1, Subject.RefPoint.PointF.Y);
        }

        private void btn_refMark_Right_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X + 1, Subject.RefPoint.PointF.Y);
        }
    }
}
