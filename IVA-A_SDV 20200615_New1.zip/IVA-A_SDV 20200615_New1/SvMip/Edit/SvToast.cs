﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SvMip.Edit
{
    public class SvNoticeEventArgs : EventArgs
    {
        public string Message { get; private set; }
        public bool IsError { get; private set; }
        public SvNoticeEventArgs(string message, bool isError) { Message = message; IsError = isError; }
    }

    /// <summary>Small message that appears in a corner of a control for a few seconds (replaces "OK" message boxes).</summary>
    public static class SvToast
    {
        static Label current;
        static Timer timer;

        public static void Show(Control host, string text, bool isError)
        {
            if (host == null || host.IsDisposed) return;
            if (host.InvokeRequired)
            {
                host.BeginInvoke(new Action(delegate { Show(host, text, isError); }));
                return;
            }
            Hide();

            Label l = new Label();
            l.AutoSize = true;
            l.MaximumSize = new Size(Math.Max(200, host.ClientSize.Width / 2), 0);
            l.Padding = new Padding(12, 8, 12, 8);
            l.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            l.ForeColor = Color.White;
            l.BackColor = isError ? Color.FromArgb(190, 40, 40) : Color.FromArgb(40, 130, 70);
            l.Text = text;
            host.Controls.Add(l);
            l.PerformLayout();
            l.Location = new Point(Math.Max(0, host.ClientSize.Width - l.Width - 14), 44);
            l.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            l.BringToFront();
            current = l;

            timer = new Timer();
            timer.Interval = isError ? 6000 : 3000;
            timer.Tick += delegate { Hide(); };
            timer.Start();
        }

        public static void Hide()
        {
            if (timer != null) { timer.Stop(); timer.Dispose(); timer = null; }
            if (current != null)
            {
                if (current.Parent != null) current.Parent.Controls.Remove(current);
                current.Dispose();
                current = null;
            }
        }
    }
}
