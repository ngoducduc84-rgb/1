﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip.Core;
using System.Reflection;
using SvMip.Edit.Base;
using System.Runtime.InteropServices;

namespace SvMip.Edit
{
    public partial class SvToolBlockEdit : SvToolEditBase
    {
        SvMip.Core.SvToolBlockTreeView parentTreeView;

        public SvToolBlockEdit()
        {
            InitializeComponent();
            IsToolListButtonVisible = true;

            InitDataGrid();

            base.SubjectChanged += SvToolBlockEdit_SubjectChanged;
            svToolBlockTree.ToolSelect += svToolBlockTree_ToolSelect;
            this.Invalidated += SvToolBlockEdit_Invalidated;
        }

        void SvToolBlockEdit_Invalidated(object sender, InvalidateEventArgs e)
        {
            svToolBlockTree.Refresh();
        }

        public SvToolBlockEdit(SvMip.Core.SvToolBlockTreeView parentTreeView)
            : this()
        {
            this.parentTreeView = parentTreeView;
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            IsToolListButtonVisible = true;
            base.OnLayout(e);
        }

        protected override void tsb_Run_Click(object sender, EventArgs e)
        {
            base.tsb_Run_Click(sender, e);
            svToolBlockTree.Refresh();
        }

        protected override void tsb_ToolList_Click(object sender, EventArgs e)
        {
            svToolBlockTree.ShowToolList();
        }

        protected override void tsb_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Tool files (*.tlf)|*.tlf|Job files (*.job)|*.job|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.Multiselect = false;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            string extension = System.IO.Path.GetExtension(fd.FileName).ToLower();

            if (extension.Equals(".tlf"))
            {
                this.Cursor = Cursors.WaitCursor;
                SvToolBase tool = serializer.LoadTool(fd.FileName);
                
                this.Cursor = Cursors.Default;

                if (tool == null)
                {
                    MessageBox.Show("Tool load fail");
                    return;
                }

                if (!DeepCopy(GetSubject(), tool))
                {
                    MessageBox.Show(string.Format("Tool type not match.\r\nTool file type : {0}", tool.ToString()));
                    return;
                }

                SetSubject(GetSubject());
            }
            else if (extension.Equals(".job"))
            {
                this.Cursor = Cursors.WaitCursor;
                SvJob job = serializer.LoadJob(fd.FileName);
                this.Cursor = Cursors.Default;

                if (job == null)
                {
                    MessageBox.Show("Job load fail");
                    return;
                }

                SvToolBlock block = Subject as SvToolBlock;
                block.ToolJob.ToolList = job.ToolList;
                svToolBlockTree.RedrawAllNode();
            }
            else
            {
                MessageBox.Show(string.Format("{0} file is not properd.", fd.FileName));
                return;
            }

            SvDisplayViewEdit.ClearImage();
            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);     
        }


        // ---- the interface of the block, for a WPF panel that draws this editor ----
        /// <summary>Raised after the inputs or outputs of the block were changed from the panel.</summary>
        public event EventHandler InterfaceChanged;

        /// <summary>The tree of the tools inside the block (the panel hosts it).</summary>
        public SvMip.Core.SvToolBlockTree InnerTree { get { return svToolBlockTree; } }

        /// <summary>Shows a tool of the block (or its input / output node) on the image.</summary>
        public void SelectInner(SvToolBase tool)
        {
            if (tool != null) base.SvDisplayViewEdit.Subject = tool;
        }

        /// <summary>The types an input or an output can have: a short name and the type.</summary>
        public static List<KeyValuePair<string, Type>> InterfaceTypes()
        {
            List<KeyValuePair<string, Type>> l = new List<KeyValuePair<string, Type>>();
            l.Add(new KeyValuePair<string, Type>("Image", typeof(SvImage)));
            l.Add(new KeyValuePair<string, Type>("bool", typeof(bool)));
            l.Add(new KeyValuePair<string, Type>("int", typeof(int)));
            l.Add(new KeyValuePair<string, Type>("float", typeof(float)));
            l.Add(new KeyValuePair<string, Type>("double", typeof(double)));
            l.Add(new KeyValuePair<string, Type>("Blob", typeof(SvBlobObject)));
            l.Add(new KeyValuePair<string, Type>("Line", typeof(SvLine)));
            l.Add(new KeyValuePair<string, Type>("LineCaliper", typeof(SvLineCaliper)));
            l.Add(new KeyValuePair<string, Type>("Mask", typeof(SvMask)));
            l.Add(new KeyValuePair<string, Type>("Point", typeof(SvPoint)));
            l.Add(new KeyValuePair<string, Type>("Rectangle", typeof(SvRectangle)));
            l.Add(new KeyValuePair<string, Type>("RotationRectangle", typeof(SvRotationRectangle)));
            l.Add(new KeyValuePair<string, Type>("PolyLine", typeof(SvPolyLine)));
            return l;
        }

        static string ShortName(string fullName)
        {
            foreach (KeyValuePair<string, Type> kv in InterfaceTypes())
                if (kv.Value.FullName == fullName) return kv.Key;
            return fullName;
        }

        List<KeyValuePair<string, string>> ToRows(List<object[]> src)
        {
            List<KeyValuePair<string, string>> rows = new List<KeyValuePair<string, string>>();
            foreach (object[] o in src) rows.Add(new KeyValuePair<string, string>((string)o[0], ShortName((string)o[1])));
            return rows;
        }

        public List<KeyValuePair<string, string>> GetInputRows()
        {
            return Subject == null ? new List<KeyValuePair<string, string>>() : ToRows(Subject.GetInputs());
        }

        public List<KeyValuePair<string, string>> GetOutputRows()
        {
            return Subject == null ? new List<KeyValuePair<string, string>>() : ToRows(Subject.GetOutputs());
        }

        /// <summary>Replaces the inputs (or outputs) of the block with the rows (name, type name). Returns an error text, or null when it was applied.</summary>
        public string ApplyInterface(bool input, IList<KeyValuePair<string, string>> rows)
        {
            if (Subject == null) return "No tool block.";
            List<KeyValuePair<string, Type>> types = InterfaceTypes();
            Dictionary<string, Type> list = new Dictionary<string, Type>();
            List<string> order = new List<string>();
            foreach (KeyValuePair<string, string> row in rows)
            {
                if (string.IsNullOrEmpty(row.Key)) return "Name can not be empty.";
                if (list.ContainsKey(row.Key)) return "Name is already exist: " + row.Key;
                Type type = null;
                foreach (KeyValuePair<string, Type> t in types) if (t.Key == row.Value) type = t.Value;
                if (type == null) return "Unknown type: " + row.Value;
                list.Add(row.Key, type);
                order.Add(row.Key);
            }
            try
            {
                if (input)
                {
                    Subject.ClearInput();
                    foreach (string key in order) Subject.AddInput(key, list[key]);
                }
                else
                {
                    Subject.ClearOutput();
                    foreach (string key in order) Subject.AddOutput(key, list[key]);
                }
                Subject.RestoreTool();
                if (parentTreeView != null) parentTreeView.RedrawAllNode();
                svToolBlockTree.RedrawAllNode();
                if (InterfaceChanged != null) InterfaceChanged(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                return "Could not apply: " + ex.GetType().Name + " - " + ex.Message + "  @ " + (ex.StackTrace ?? "").Split('\n')[0].Trim();
            }
            return null;
        }

        /// <summary>Load a tool file (.tlf) or a job file (.job) into the block.</summary>
        public void LoadFromFile()
        {
            tsb_Load_Click(null, null);
            if (InterfaceChanged != null) InterfaceChanged(this, EventArgs.Empty);
        }

        /// <summary>Draw the tools inside the block again (after a run or a change from outside).</summary>
        public void RefreshInnerTree()
        {
            svToolBlockTree.Refresh();
            svToolBlockTree.RedrawAllNode();
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvToolBlock Subject
        {
            get { return base.GetSubject() as SvToolBlock; }
            set { base.SetSubject(value);}
        }

        void SvToolBlockEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            Subject.RestoreTool();

            if (parentTreeView != null)
                parentTreeView.RedrawAllNode();

            svToolBlockTree.SetToolBlockInOutput(Subject);
            UpdateDataGrid();
        }

        void UpdateDataGrid()
        {
            try
            {
                dg_Input.RowValidated -= dg_RowValidated;
                dg_Output.RowValidated -= dg_RowValidated;

                dg_Input.RowValidating -= dg_RowValidating;
                dg_Output.RowValidating -= dg_RowValidating;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            dg_Input.Rows.Clear();
            foreach(object[] obj in Subject.GetInputs())
            {
                dg_Input.Rows.Add(obj);
            }

            dg_Output.Rows.Clear();
            foreach (object[] obj in Subject.GetOutputs())
            {
                dg_Output.Rows.Add(obj);
            }

            try
            {
                dg_Input.RowValidated += dg_RowValidated;
                dg_Output.RowValidated += dg_RowValidated;

                dg_Input.RowValidating += dg_RowValidating;
                dg_Output.RowValidating += dg_RowValidating;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        void svToolBlockTree_ToolSelect(object sender, SvToolBase tool)
        {
            base.SvDisplayViewEdit.Subject = tool;            
        }

        #region DataGrid

        bool isEdit = false;
        
        void InitDataGrid()
        {
            DataGridViewComboBoxColumn column;
            column = dg_Input.Columns[1] as DataGridViewComboBoxColumn;
            column.DataSource = GetTypeList();
            column = dg_Output.Columns[1] as DataGridViewComboBoxColumn;
            column.DataSource = GetTypeList();            

            dg_Input.RowValidated += dg_RowValidated;
            dg_Output.RowValidated += dg_RowValidated;

            dg_Input.RowValidating += dg_RowValidating;
            dg_Output.RowValidating += dg_RowValidating;

            dg_Input.CellBeginEdit += (sender, e) => 
            {
                isEdit = true;
            };

            dg_Output.CellBeginEdit += (sender, e) =>
            {
                isEdit = true;
            };
        }

        List<string> GetTypeList()
        {
            List<string> typeList = new List<string>();
            typeList.Add(typeof(SvImage).FullName);
            typeList.Add(typeof(bool).FullName);
            typeList.Add(typeof(int).FullName);
            typeList.Add(typeof(float).FullName);
            typeList.Add(typeof(double).FullName);
            typeList.Add(typeof(SvBlobObject).FullName);
            typeList.Add(typeof(SvLine).FullName);
            typeList.Add(typeof(SvLineCaliper).FullName);
            typeList.Add(typeof(SvMask).FullName);
            typeList.Add(typeof(SvPoint).FullName);
            typeList.Add(typeof(SvRectangle).FullName);
            typeList.Add(typeof(SvRotationRectangle).FullName);
            typeList.Add(typeof(SvPolyLine).FullName);
            return typeList;
        }

        void dg_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            DataGridView dg = sender as DataGridView;

            if (e.ColumnIndex == 0)
            {
                string newName = dg.Rows[e.RowIndex].Cells[0].Value as string;

                if(string.IsNullOrEmpty(newName))
                {
                    MessageBox.Show("Name can not be empty");
                    e.Cancel = true;
                    return;
                }
                                
                foreach (DataGridViewRow row in dg.Rows)
                {
                    if (row.IsNewRow) continue;
                    if (e.RowIndex == row.Index) continue;
                    string name = row.Cells[0].Value as string;
                    if (name == newName)
                    {
                        MessageBox.Show("Name is already exist");
                        dg.Rows[e.RowIndex].Cells[0].Value = "";
                        e.Cancel = true;
                        return;
                    }
                }
            }
            
            if(e.ColumnIndex == 1)
            {
                object value = dg.Rows[e.RowIndex].Cells[1].Value;
                if (value == null)
                {
                    MessageBox.Show("Type can not be 'Null'");
                    e.Cancel = true;
                    return;
                }
            }
            isEdit = false;          
        }

        void dg_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView dg = sender as DataGridView;

            if (Subject == null) return;

            if(dg == dg_Input)
            {
                Subject.ClearInput();
                foreach(DataGridViewRow row in dg.Rows)
                {
                    if(row.IsNewRow) continue;
                    string name = row.Cells[0].Value as string;
                    Type type = Type.GetType(row.Cells[1].Value as string);
                    if (type == null) return;
                    Subject.AddInput(name, type);
                }
            }
            else if(dg == dg_Output)
            {
                Subject.ClearOutput();
                //List<string> notDeletingList = new List<string>();
                foreach (DataGridViewRow row in dg.Rows)
                {
                    if (row.IsNewRow) continue;
                    string name = row.Cells[0].Value as string;
                    Type type = Type.GetType(row.Cells[1].Value as string);
                    if (type == null) return;
                    //notDeletingList.Add(name); 
                    Subject.AddOutput(name, type);
                }

                //List<string> keys = Subject.outputTool.inParams.Keys.ToList();
                //foreach(string key in keys)
                //{
                //    if (!notDeletingList.Contains(key))
                //        Subject.outputTool.inParams.Remove(key);
                //}
            }

            if (parentTreeView != null)
                parentTreeView.RedrawAllNode();

            svToolBlockTree.RedrawAllNode();
        }

        private void tsb_Input_Click(object sender, EventArgs e)
        {
            ToolStripButton btn = sender as ToolStripButton;
            DataGridView dg = dg_Input;
            DataGridAction(dg, btn);
        }

        private void tsb_Output_Click(object sender, EventArgs e)
        {
            ToolStripButton btn = sender as ToolStripButton;
            DataGridView dg = dg_Output;
            DataGridAction(dg, btn);
        }
        
        void DataGridAction(DataGridView dg, ToolStripButton btn)
        {
            if (isEdit) return;

            if (btn == tsb_Input_Add || btn == tsb_Output_Add)
            {
                dg.Rows.Add(new object[2] { "", typeof(SvImage).FullName });
                dg.CurrentCell = dg.Rows[dg.Rows.Count-1].Cells[0];
                dg.BeginEdit(false);
                isEdit = true;
            }
            else if (btn == tsb_Input_Remove || btn == tsb_Output_Remove)
            {
                if (dg.SelectedRows.Count == 0 || dg.SelectedRows[0].IsNewRow) return;
                dg.Rows.Remove(dg.SelectedRows[0]);
            }
            else if (btn == tsb_Input_Up || btn == tsb_Output_Up)
            {
                if (dg.SelectedRows.Count == 0 || dg.SelectedRows[0].IsNewRow) return;
                int index = dg.Rows.IndexOf(dg.SelectedRows[0]);
                DataGridViewRow selectedRow = dg.Rows[index];
                if (index - 1 < 0) return;

                dg.RowValidated -= dg_RowValidated;
                dg.Rows.RemoveAt(index);
                dg.Rows.Insert(index - 1, selectedRow);
                dg.CurrentCell = selectedRow.Cells[0];
                dg.RowValidated += dg_RowValidated;
            }
            else if (btn == tsb_Input_Down || btn == tsb_Output_Down)
            {
                if (dg.SelectedRows.Count == 0 || dg.SelectedRows[0].IsNewRow) return;
                int index = dg.Rows.IndexOf(dg.SelectedRows[0]);
                DataGridViewRow selectedRow = dg.Rows[index];
                if (index + 1 >= dg.Rows.Count) return;

                dg.RowValidated -= dg_RowValidated;
                dg.Rows.RemoveAt(index);
                dg.Rows.Insert(index + 1, selectedRow);
                dg.CurrentCell = selectedRow.Cells[0];
                dg.RowValidated += dg_RowValidated;
            }

            dg_RowValidated(dg, null);
        }

        #endregion
    }
}
