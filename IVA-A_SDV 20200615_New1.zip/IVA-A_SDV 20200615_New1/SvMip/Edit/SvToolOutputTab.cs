﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;

namespace SvMip.Edit
{
    /// <summary>
    /// "Output" tab of a tool editor: every output of the tool with its type and the value of the last run.
    /// Double click copies the source text (Tool.Output) to the clipboard, ready for SvSend / SvAlign / SvIf.
    /// The outputs come from tool.outParams, so every tool gets the tab without code of its own.
    /// </summary>
    public class SvToolOutputTab
    {
        readonly TabPage page = new TabPage("Output");
        readonly ListView list = new ListView();
        readonly Label note = new Label();
        SvToolBase tool;

        public SvToolOutputTab(TabControl tabs)
        {
            page.UseVisualStyleBackColor = true;

            note.Dock = DockStyle.Bottom;
            note.Height = 34;
            note.Padding = new Padding(6, 4, 6, 0);
            note.Text = "Values of the last run. Double click a row to copy its source text (Tool.Output).";

            list.Dock = DockStyle.Fill;
            list.View = View.Details;
            list.FullRowSelect = true;
            list.HideSelection = false;
            list.Columns.Add("Output", 150);
            list.Columns.Add("Type", 110);
            list.Columns.Add("Value (last run)", 300);
            list.DoubleClick += delegate { CopySelected(); };

            page.Controls.Add(list);
            page.Controls.Add(note);
            tabs.TabPages.Add(page);
        }

        public void SetTool(SvToolBase subject)
        {
            tool = subject;
            Refresh();
        }

        public void Refresh()
        {
            if (page.IsDisposed) return;
            list.BeginUpdate();
            list.Items.Clear();
            if (tool != null)
            {
                Dictionary<string, object> snapshot;
                try { snapshot = new Dictionary<string, object>(tool.outParams); }
                catch { snapshot = new Dictionary<string, object>(); }
                foreach (KeyValuePair<string, object> kv in snapshot)
                {
                    ListViewItem item = new ListViewItem(kv.Key);
                    item.SubItems.Add(kv.Value == null ? "" : kv.Value.GetType().Name);
                    item.SubItems.Add(Describe(kv.Value));
                    list.Items.Add(item);
                }
                if (list.Items.Count == 0)
                    list.Items.Add(new ListViewItem(new string[] { "(this tool has no outputs)", "", "" }));
            }
            list.EndUpdate();
        }

        void CopySelected()
        {
            if (tool == null || list.SelectedItems.Count == 0) return;
            string text = tool.ToString() + "." + list.SelectedItems[0].Text;
            try { Clipboard.SetText(text); note.Text = "Copied: " + text; }
            catch { note.Text = "Could not use the clipboard. Source text: " + text; }
        }

        /// <summary>Short text for a value (numbers rounded, lists with their size, images with their size).</summary>
        public static string Describe(object v)
        {
            if (v == null) return "(none)";
            if (v is double) return ((double)v).ToString("0.######", CultureInfo.InvariantCulture);
            if (v is float) return ((float)v).ToString("0.######", CultureInfo.InvariantCulture);
            if (v is bool || v is int || v is long || v is short || v is byte) return Convert.ToString(v, CultureInfo.InvariantCulture);
            string s = v as string;
            if (s != null) return s;

            Type t = v.GetType();
            string tn = t.Name;
            if (tn == "Mat" || tn == "IplImage" || tn == "SvImage" || v is System.Drawing.Image)
                return "image";

            IList l = v as IList;
            if (l != null)
            {
                string head = "list of " + l.Count;
                if (l.Count > 0 && l[0] != null && IsSimple(l[0]))
                {
                    List<string> first = new List<string>();
                    for (int i = 0; i < l.Count && i < 3; i++) first.Add(Describe(l[i]));
                    head += ":  " + string.Join(", ", first.ToArray()) + (l.Count > 3 ? " ..." : "");
                }
                return head;
            }
            string text;
            try { text = v.ToString(); } catch { text = tn; }
            if (text == t.FullName) text = tn;
            return text.Length > 140 ? text.Substring(0, 140) + "..." : text;
        }

        static bool IsSimple(object o)
        {
            return o is double || o is float || o is int || o is bool || o is string || o is long;
        }
    }
}
