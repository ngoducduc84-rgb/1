﻿using System;
using System.Windows.Forms;
using SvMip.Edit.Base;

namespace SvMip.Edit
{
    /// <summary>Edit page of SvTrigger (built in code).</summary>
    public class SvTriggerEdit : SvToolEditBase
    {
        BindingSource source;

        public SvTriggerEdit()
        {
            source = new BindingSource(typeof(SvTrigger), null);
            TabPage page = SvEditHelper.AddPage(this, "Trigger");
            int y = 10;
            SvEditHelper.AddHeader(page, "Trigger source", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddEnum(page, source, "TriggerMode", "Mode (Io = PLC bits, Tcp = message) :", y, typeof(SvTriggerMode)); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "TriggerConnection", "Tcp: connection name :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "StartCommand", "Tcp: start commands (XT|HE|HEE, empty = any) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Separator", "Tcp: separator of the parts (, or ;) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "AlignCommands", "Tcp: commands that align and send (XT) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "ReplyUnknown", "Tcp: reply to an unknown command :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Terminator", "Tcp: message end (\\r\\n) :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "ReplyOk", "Tcp: reply when OK :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "ReplyNg", "Tcp: reply when NG :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddHeader(page, "Input signals (-1 = not used; not used in Tcp mode)", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "StartAddr", "Start :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "CompleteAddr", "Complete :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddHeader(page, "Output signals", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "ReadyAddr", "Ready :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "AcqCompAddr", "AcqComp :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "OkAddr", "OK :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "NgAddr", "NG :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Ok2Addr", "OK2 :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "Ng2Addr", "NG2 :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "InspNgAddr", "InspNG :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "InspNg2Addr", "InspNG2 :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddHeader(page, "Data areas (legacy layout)", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "OffsetStartAddress", "Offset start :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "InspectStartAddress", "Inspect start :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "CellIdAddress", "Cell ID :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddText(page, source, "FdcStartAddress", "FDC start :", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddHeader(page, "Options", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddCheck(page, source, "DualJudge", "Dual judge (OK2 / NG2)", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddCheck(page, source, "UseAcqComp", "Use AcqComp", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddCheck(page, source, "InspReverse", "Inspect bits reversed", y); y += SvEditHelper.RowHeight;
            SvEditHelper.AddCheck(page, source, "AutoStart", "Start Auto automatically after saving (writes to the PLC)", y);
            this.SubjectChanged += SvTriggerEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
        }

        public SvTrigger Subject
        {
            get { return base.GetSubject() as SvTrigger; }
            set { base.SetSubject(value); }
        }

        void SvTriggerEdit_SubjectChanged(object sender, SvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
    }
}
