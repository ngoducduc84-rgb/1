﻿using System;
using System.Linq;
using System.Reflection;
using OpenCvSharp.CPlusPlus;
using System.Collections.Generic;
using System.Drawing;

namespace SvMip
{
    // 내 능력으로 한계라 박싱 언박싱 성능 고려 안함.

    [Serializable]
    public class SvJob
    {
        List<SvToolBase> toolList = new List<SvToolBase>();

        public List<SvToolBase> ToolList
        {            
            get { return toolList; }
            set 
            {
                toolList.Clear();
                foreach(SvToolBase tool in value)
                {
                    toolList.Add(tool);
                }
            }
        }

        public SvToolBase this[string name]
        {
            get
            {
                SvToolBase selectTool = null;

                foreach (SvToolBase tool in toolList)
                {
                    if (name == tool.ToString())
                        selectTool = tool;
                }
                return selectTool;
            }
        }

        public SvJob()
        {
            
        }

        string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        bool lastRunSuccess;

        public bool LastRunSuccess { get { return lastRunSuccess; } }

        double lastRunTime;

        public double LastRunTime { get { return lastRunTime; } }

        public void RestoreLink()
        {
            foreach (SvToolBase tool in toolList)
            {
                if (tool == null) continue;
                foreach (KeyValuePair<string, InputParams> param in tool.inParams)
                {
                    InputParams dstValue = param.Value;
                    if (dstValue == null) continue;

                    foreach (SvToolBase t in toolList)
                    {
                        if (t == tool)
                            continue;
                        if (t.HashCode == dstValue.InstanceHashcode)
                        {
                            dstValue.Instance = t;
                            break;
                        }
                    }

                }
            }
        }

        public List<KeyValuePair<string, double>> GetLastProcessTimes()
        {
            //System.Collections.Generic.Dictionary<string, double> lastProcessTimes = new System.Collections.Generic.Dictionary<string, double>();
            List<KeyValuePair<string, double>> lastProcessTimes = new List<KeyValuePair<string, double>>();
            double TT = 0;
            foreach (SvToolBase tool in toolList)
            {
                lastProcessTimes.Add(new KeyValuePair<string, double>(tool.ToString(), tool.lastProcessTime));
                TT += tool.lastProcessTime;
            }
            lastProcessTimes.Insert(0, new KeyValuePair<string, double>("Total Time", TT));
            return lastProcessTimes;
        }

        public SvToolBase GetLastRunTool()
        {
            return toolList.Last();
        }

        public Dictionary<string, object> GetLastRunOutParams()
        {
            return toolList.Last().outParams;
        }

        
        public struct OutImageInfo
        {
            public OutImageInfo(string ToolName, string ImageName, Mat Image, Image overray)
            {
                this.ToolName = ToolName;
                this.ImageName = ImageName;
                this.Image = Image;
                this.overray = overray;
            }

            public readonly string ToolName;
            public readonly string ImageName;
            [NonSerialized]
            public readonly Mat Image;
            public readonly Image overray;

            public override string ToString()
            {
                return string.Format("Tool : {0,-20}Name : {1}", ToolName, ImageName);
            }
        }

        public List<OutImageInfo> GetOutImages()
        {
            List<OutImageInfo> outImages = new List<OutImageInfo>();

            foreach (SvToolBase tool in toolList)
            {
                foreach (KeyValuePair<string, object> param in tool.outParams)
                {
                    if (param.Value == null) continue;
                    //if (param.Value is Mat) ;
                    //outImages.Add(new OutImageInfo(tool.ToString(), param.Key, param.Value as Mat));
                }
            }

            return outImages;
        }

        public void Run(bool isEditMode = false)
        {
            if (toolList.Count == 0) return;

            DateTime runTimeStart = DateTime.Now;
            lastRunSuccess = true;

            RestoreLink();

            ExecuteRange(0, toolList.Count, isEditMode, false, null);

            lastRunTime = DateTime.Now.Subtract(runTimeStart).TotalMilliseconds;
            System.Diagnostics.Debug.WriteLine("Total VisionJob Time: " + lastRunTime);

            GC.Collect();
        }

        public void RunWithoutAcq()
        {
            if (toolList.Count == 0) return;

            DateTime runTimeStart = DateTime.Now;
            lastRunSuccess = true;

            RestoreLink();

            ExecuteRange(0, toolList.Count, false, true, null);

            lastRunTime = DateTime.Now.Subtract(runTimeStart).TotalMilliseconds;
            System.Diagnostics.Debug.WriteLine("Total VisionJob Time: " + lastRunTime);

            GC.Collect();
        }

        /// <summary>
        /// Runs toolList[start .. end) in order. SvIf / SvFor control the tools that follow them:
        /// SvIf skips them when its condition is false, SvFor repeats them. Without these tools this is a plain loop.
        /// </summary>
        void ExecuteRange(int start, int end, bool isEditMode, bool skipAcq, List<SvToolBase> context)
        {
            int i = start;
            while (i < end)
            {
                SvToolBase tool = toolList[i];
                if (skipAcq && tool is SvAcquisition)
                {
                    i++;
                    continue;
                }

                SvIf svIf = tool as SvIf;
                SvFor svFor = tool as SvFor;
                ISvContextTool contextTool = tool as ISvContextTool;
                if (contextTool != null)
                {
                    if (context == null) context = CollectAllTools();
                    contextTool.SetContext(context);
                }

                RunOneTool(tool, isEditMode);

                if (svIf != null || svFor != null)
                {
                    int body = (svIf != null) ? svIf.BodyCount : svFor.BodyCount;
                    if (body < 0) body = 0;
                    if (i + 1 + body > end) body = end - i - 1;
                    int bodyStart = i + 1;
                    int bodyEnd = i + 1 + body;

                    if (svIf != null)
                    {
                        if (svIf.RunBody) ExecuteRange(bodyStart, bodyEnd, isEditMode, skipAcq, context);
                        else SkipRange(bodyStart, bodyEnd);
                    }
                    else
                    {
                        int count = svFor.EffectiveCount;
                        if (count == 0)
                        {
                            SkipRange(bodyStart, bodyEnd);
                        }
                        else
                        {
                            for (int it = 0; it < count; it++)
                            {
                                svFor.SetIteration(it);
                                ExecuteRange(bodyStart, bodyEnd, isEditMode, skipAcq, context);
                            }
                        }
                    }
                    i = bodyEnd;
                    continue;
                }
                i++;
            }
        }

        void RunOneTool(SvToolBase tool, bool isEditMode)
        {
            DateTime lastProcessTimeStart = DateTime.Now;

            tool.GetInParams();
            tool.InitOutProperty();
            tool.Run(isEditMode);

            //if (tool.lastRunSuccess)
            {
                tool.GetOutParams();
                tool.OnRan();
            }

            tool.lastProcessTime = DateTime.Now.Subtract(lastProcessTimeStart).TotalMilliseconds;
            System.Diagnostics.Debug.WriteLine(tool.ToString() + " Time: " + tool.lastProcessTime);

            lastRunSuccess &= tool.lastRunSuccess;
        }

        /// <summary>Tools that were not run (SvIf false / SvFor 0 times): outputs are cleared, the tool is not a failure.</summary>
        void SkipRange(int start, int end)
        {
            for (int i = start; i < end; i++)
            {
                SvToolBase tool = toolList[i];
                tool.InitOutProperty();
                List<string> keys = new List<string>(tool.outParams.Keys);
                foreach (string key in keys) tool.outParams[key] = null;
                tool.lastRunSuccess = true;
            }
        }

        List<SvToolBase> CollectAllTools()
        {
            List<SvToolBase> all = new List<SvToolBase>();
            AddTools(this, all, 0);
            return all;
        }

        static void AddTools(SvJob job, List<SvToolBase> acc, int depth)
        {
            if (job == null || depth > 8) return;
            foreach (SvToolBase t in job.toolList)
            {
                acc.Add(t);
                SvToolBlock block = t as SvToolBlock;
                if (block != null) AddTools(block.ToolJob, acc, depth + 1);
            }
        }

        public void RunBeforeTool(SvToolBase toolbase)
        {
            try
            {
                if (toolList.Count == 0) return;
                if (toolbase == null) { Run(); return; }

                DateTime runTimeStart = DateTime.Now;
                lastRunSuccess = true;

                RestoreLink();

                foreach (SvToolBase tool in toolList)
                {
                    if (tool == toolbase) break;

                    DateTime lastProcessTimeStart = DateTime.Now;

                    tool.GetInParams();
                    tool.InitOutProperty();
                    tool.Run();

                    tool.GetOutParams();
                    tool.OnRan();

                    tool.lastProcessTime = DateTime.Now.Subtract(lastProcessTimeStart).TotalMilliseconds;
                    System.Diagnostics.Debug.WriteLine(tool.ToString() + " Time: " + tool.lastProcessTime);

                    lastRunSuccess &= tool.lastRunSuccess;
                }

                lastRunTime = DateTime.Now.Subtract(runTimeStart).TotalMilliseconds;
                System.Diagnostics.Debug.WriteLine("Total VisionJob Time: " + lastRunTime);

                GC.Collect();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return;
            }
        }
        public void OnRan()
        {
            //foreach (SvToolBase tool in toolList)
            //{
            //    tool.OnRan();
            //}

            NotifyRan(this, this);
        }

        public delegate void RanHandler(object sender, SvJob job);

        [field: NonSerialized]
        public event RanHandler Ran;

        protected void NotifyRan(object sender, SvJob job)
        {
            if (Ran != null)
                Ran(sender, job);
        }

    }
}
