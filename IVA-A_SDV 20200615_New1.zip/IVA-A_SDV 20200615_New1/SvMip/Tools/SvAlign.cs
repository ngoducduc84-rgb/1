﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;

namespace SvMip
{
    /// <summary>One align target: where to read the vision point and the robot reference / offset values.</summary>
    [Serializable]
    public class SvAlignPoint
    {
        public SvAlignPoint()
        {
            Name = "Point";
            Source = "";
        }

        public string Name { get; set; }
        /// <summary>Vision point source, e.g. "MakePoint1.OutPoint" (see DirectPath for the syntax).</summary>
        public string Source { get; set; }
        /// <summary>Reference (load) position in robot coordinates. T in degrees.</summary>
        public double LoadX { get; set; }
        public double LoadY { get; set; }
        public double LoadT { get; set; }
        /// <summary>Offset of the target in the part frame. T in degrees.</summary>
        public double OffsetX { get; set; }
        public double OffsetY { get; set; }
        public double OffsetT { get; set; }
    }

    /// <summary>
    /// Configuration-only tool: describes how the vision points are converted into robot corrections
    /// (calibration, reference position, offsets, limits). The calculation itself runs in AutoThread_Direct
    /// with the same math as the legacy AutoThread classes.
    /// </summary>
    [Serializable]
    public class SvAlign : SvToolBase
    {
        string calibrationFile = "";
        List<SvAlignPoint> points = new List<SvAlignPoint>();
        bool useLimit = true;
        float xMin = -100f;
        float xMax = 100f;
        float yMin = -100f;
        float yMax = 100f;
        float tMin = -5f;
        float tMax = 5f;
        float ngX = 0f;
        float ngY = 0f;
        float ngT = 0f;

        public SvAlign()
        {
        }
        public SvAlign(SerializationInfo info, StreamingContext context) : base(info, context) { }

        /// <summary>Calibration file name (in the Calibration folder). Empty = calibration of the recipe.</summary>
        public string CalibrationFile
        {
            get { return calibrationFile; }
            set { calibrationFile = value; NotifyPropertyChanged("CalibrationFile"); }
        }
        public List<SvAlignPoint> Points
        {
            get { return points; }
        }
        public bool UseLimit { get { return useLimit; } set { useLimit = value; NotifyPropertyChanged("UseLimit"); } }
        public float XMin { get { return xMin; } set { xMin = value; NotifyPropertyChanged("XMin"); } }
        public float XMax { get { return xMax; } set { xMax = value; NotifyPropertyChanged("XMax"); } }
        public float YMin { get { return yMin; } set { yMin = value; NotifyPropertyChanged("YMin"); } }
        public float YMax { get { return yMax; } set { yMax = value; NotifyPropertyChanged("YMax"); } }
        public float TMin { get { return tMin; } set { tMin = value; NotifyPropertyChanged("TMin"); } }
        public float TMax { get { return tMax; } set { tMax = value; NotifyPropertyChanged("TMax"); } }
        /// <summary>Values sent instead of the correction when the vision / align result is NG.</summary>
        public float NgX { get { return ngX; } set { ngX = value; NotifyPropertyChanged("NgX"); } }
        public float NgY { get { return ngY; } set { ngY = value; NotifyPropertyChanged("NgY"); } }
        public float NgT { get { return ngT; } set { ngT = value; NotifyPropertyChanged("NgT"); } }

        /// <summary>Returns an empty string when the settings are usable, otherwise a message.</summary>
        public string Validate()
        {
            if (points.Count == 0) return "No align point is defined";
            for (int i = 0; i < points.Count; i++)
            {
                if (string.IsNullOrEmpty(points[i].Source))
                    return string.Format("Align point {0} ({1}) has no source", i + 1, points[i].Name);
            }
            if (useLimit && (xMin > xMax || yMin > yMax || tMin > tMax)) return "A limit minimum is larger than its maximum";
            if (!string.IsNullOrEmpty(calibrationFile))
            {
                string path = Path.Combine("C:\\SVL_Data", "Calibration", calibrationFile);
                if (!File.Exists(path)) return "Calibration file not found: " + path;
            }
            return "";
        }

        public override void InitInParmas()
        {
        }
        public override void InitOutParmas()
        {
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
        }
        public override void Run(bool isEditMode = false)
        {
            // Configuration only. Always succeeds so that it never turns the job NG.
            lastRunSuccess = true;
        }
    }
}
