﻿using System;
using System.Runtime.Serialization;

namespace SvMip
{
    /// <summary>
    /// Kind of connection a job wants to use.
    /// MxCom .. NxeDio are the connections of the existing IO / robot code (created by Auto.InitInterface).
    /// TcpClient .. ModbusTcp are byte-stream connections used by SvSend channels of kind Text / Registers.
    /// New values are only added at the end (jobs store the numeric value).
    /// </summary>
    public enum SvConnType { MxCom, OpcUa, Msg, SocketClient, RobostarSerial, YoiDio, NxeDio, TcpClient, TcpServer, Udp, Serial, ModbusTcp }

    /// <summary>Which channel(s) of the process use the connection (existing IO / robot connections only).</summary>
    public enum SvConnRole { Both, IO, Robot }

    public enum SvParity { None, Odd, Even }

    public enum SvTextEncoding { Ascii, Utf8 }

    /// <summary>
    /// Configuration-only tool: declares a connection used by the process that runs this job.
    /// It never talks to the device itself (AutoThread_Direct / JobConfigBridge / TransportRegistry do that),
    /// so it is safe to run in edit mode. Values of -1 mean "keep the system setting" (existing IO / robot types).
    /// </summary>
    [Serializable]
    public class SvConnection : SvToolBase
    {
        string connName = "PLC";
        SvConnType connType = SvConnType.MxCom;
        SvConnRole connRole = SvConnRole.Both;
        string host = "";
        int port = -1;
        int stationNumber = -1;
        int deviceType = -1;
        int ioThreadSleep = -1;
        // byte-stream connections
        string serialPortName = "COM1";
        int baudRate = 9600;
        SvParity parity = SvParity.None;
        int dataBits = 8;
        int stopBits = 1;
        int unitId = 1;
        int timeoutMs = 1000;
        SvTextEncoding textEncoding = SvTextEncoding.Ascii;

        public SvConnection()
        {
        }
        public SvConnection(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            outParams["Connection"] = connName;
        }

        /// <summary>Output: the name of this connection. Link it to the ConnectionLink input of SvTrigger / SvSend.</summary>
        [OutputParam]
        public string Connection { get { return connName; } }

        public static bool IsStreamType(SvConnType t)
        {
            return t == SvConnType.TcpClient || t == SvConnType.TcpServer || t == SvConnType.Udp
                || t == SvConnType.Serial || t == SvConnType.ModbusTcp;
        }

        public string ConnName
        {
            get { return connName; }
            set { connName = value; if (outParams != null) outParams["Connection"] = value; NotifyPropertyChanged("ConnName"); }
        }
        public SvConnType ConnType
        {
            get { return connType; }
            set { connType = value; NotifyPropertyChanged("ConnType"); }
        }
        public SvConnRole ConnRole
        {
            get { return connRole; }
            set { connRole = value; NotifyPropertyChanged("ConnRole"); }
        }
        /// <summary>IP address / host name.</summary>
        public string Host
        {
            get { return host; }
            set { host = value; NotifyPropertyChanged("Host"); }
        }
        public int Port
        {
            get { return port; }
            set { port = value; NotifyPropertyChanged("Port"); }
        }
        /// <summary>MX Component logical station number.</summary>
        public int StationNumber
        {
            get { return stationNumber; }
            set { stationNumber = value; NotifyPropertyChanged("StationNumber"); }
        }
        /// <summary>Device type (EDeviceType) of the PLC interface.</summary>
        public int DeviceType
        {
            get { return deviceType; }
            set { deviceType = value; NotifyPropertyChanged("DeviceType"); }
        }
        public int IoThreadSleep
        {
            get { return ioThreadSleep; }
            set { ioThreadSleep = value; NotifyPropertyChanged("IoThreadSleep"); }
        }

        public string SerialPortName { get { return serialPortName; } set { serialPortName = value; NotifyPropertyChanged("SerialPortName"); } }
        public int BaudRate { get { return baudRate; } set { baudRate = value; NotifyPropertyChanged("BaudRate"); } }
        public SvParity Parity { get { return parity; } set { parity = value; NotifyPropertyChanged("Parity"); } }
        public int DataBits { get { return dataBits; } set { dataBits = value; NotifyPropertyChanged("DataBits"); } }
        /// <summary>1 or 2.</summary>
        public int StopBits { get { return stopBits; } set { stopBits = value; NotifyPropertyChanged("StopBits"); } }
        /// <summary>Modbus unit (slave) id.</summary>
        public int UnitId { get { return unitId; } set { unitId = value; NotifyPropertyChanged("UnitId"); } }
        /// <summary>Connect / send / reply timeout of the byte-stream connections.</summary>
        public int TimeoutMs { get { return timeoutMs; } set { timeoutMs = value; NotifyPropertyChanged("TimeoutMs"); } }
        public SvTextEncoding TextEncoding { get { return textEncoding; } set { textEncoding = value; NotifyPropertyChanged("TextEncoding"); } }

        /// <summary>Returns an empty string when the settings are usable, otherwise a message.</summary>
        public string Validate()
        {
            if (string.IsNullOrEmpty(connName)) return "Connection name is empty";
            switch (connType)
            {
                case SvConnType.SocketClient:
                case SvConnType.OpcUa:
                    if (string.IsNullOrEmpty(host)) return "Host (IP address) is required for " + connType;
                    break;
                case SvConnType.TcpClient:
                case SvConnType.Udp:
                    if (string.IsNullOrEmpty(host)) return "Host (IP address) is required for " + connType;
                    if (port <= 0 || port > 65535) return "Port (1..65535) is required for " + connType;
                    break;
                case SvConnType.TcpServer:
                    if (port <= 0 || port > 65535) return "Port (1..65535) is required for TcpServer";
                    break;
                case SvConnType.ModbusTcp:
                    if (string.IsNullOrEmpty(host)) return "Host (IP address) is required for ModbusTcp";
                    if (port > 65535) return "Port must not be above 65535";
                    if (unitId < 0 || unitId > 255) return "Unit id must be between 0 and 255";
                    break;
                case SvConnType.Serial:
                    if (string.IsNullOrEmpty(serialPortName)) return "Serial port name (e.g. COM1) is required";
                    if (baudRate <= 0) return "Baud rate is required";
                    if (dataBits < 5 || dataBits > 8) return "Data bits must be 5..8";
                    if (stopBits != 1 && stopBits != 2) return "Stop bits must be 1 or 2";
                    break;
            }
            return "";
        }

        public override void InitInParmas()
        {
        }
        public override void InitOutParmas()
        {
            outParams.Add("Connection", null);
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
        }
        public override void Run(bool isEditMode = false)
        {
            // Configuration only. Always succeeds so that it never turns the job NG.
            lastRunSuccess = true;
        }
    }
}
