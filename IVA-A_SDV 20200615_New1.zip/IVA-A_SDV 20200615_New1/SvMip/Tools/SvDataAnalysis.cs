﻿using OpenCvSharp.CPlusPlus;
using System;
using System.Drawing;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Linq;
using SvMip.Common;

namespace SvMip
{
    [Serializable]
    public class SvDataAnalysis : SvToolBase
    {
        public SvDataAnalysis()
        {
            regionRect = new SvRectangle();
            point = new SvPoint();
            angleLow = 0;
            angleHigh = 180;          
        }

        public SvDataAnalysis(SerializationInfo info, StreamingContext context) : base(info, context) { }

        #region InParams
        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
            inParams.Add("Point", null);
            inParams.Add("Angle", null);
        }

        [InputParam]
        public SvImage InputImage { get; set; }
        SvPoint point;
        double angle;
        double angleLow;
        double angleHigh;

        public SvPoint Point
        {
            get { return point; }
            set
            {
                if (point == null)
                    point = new SvPoint();
                if (value != null)
                {
                    point.X = value.X;
                    point.Y = value.Y;
                }
            }
        }
        
        public double Angle
        {
            get { return angle; }
            set { angle = value; }
        }

        public double AngleLow
        {
            get { return angleLow; }
            set { angleLow = value; }
        }

        public double AngleHigh
        {
            get { return angleHigh; }
            set { angleHigh = value; }
        }
        #endregion

        #region OutParams

        public override void InitOutParmas()
        {
            outParams.Add("State", null);
            outParams.Add("OutputRect", null);
//            outParams.Add("OutputImage", null);
        }

        [NonSerialized]
        bool state;

        [OutputParam]
        public bool State
        {
            get { return state; }
            set { state = value; NotifyPropertyChanged(); }
        }

        [OutputParam]
        public SvImage OutputImage { get; set; }

        [OutputParam]
        public SvRectangle OutputRect { get; set; }
     
        #endregion        

        SvRectangle regionRect;
        public SvRectangle RegionRect
        {
            get
            {
                //if (InputImage != null)
                //    regionRect.Rect = SvFunc.GetRect(InputImage.Mat, regionRect.Rect);
                return regionRect;
            }
            set
            {
                if (regionRect == null)
                    regionRect = value;
                else
                {
                    regionRect.RectF = value.RectF;
                    value = null;
                }
            }
        }

        public void DisplayRegions(SvMip.Display.SvDisplayView display)
        {
            display.GraphicsFuncCollection.Clear();

            Pen p = new Pen(Color.Yellow);
                     
            double X = RegionRect.RectF.X;
            double Y = RegionRect.RectF.Y;
            Size2f size = RegionRect.RectF.Size;
            display.DrawRectangle(p, new Point2d(X, Y), size);

            p = new Pen(Color.Red);
            double crossLength = 15 / display.ZoomRatio;
            display.DrawCross(System.Drawing.Pens.Red, Point.Point2d, crossLength, crossLength, 0);

            System.Drawing.Font font = new System.Drawing.Font("굴림체", 10, System.Drawing.FontStyle.Bold);
            System.Drawing.SolidBrush brush;
            string tmp;

            if(state == true)
            {
                brush = new System.Drawing.SolidBrush(System.Drawing.Color.Yellow);
                tmp = string.Format("P : ({0:F3}, {1:F3}, {2:F3})\n\rState : TRUE", point.X, point.Y, angle);
            }
            else
            {
                brush = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
                tmp = string.Format("P : ({0:F3}, {1:F3}, {2:F3})\n\rState : FALSE", point.X, point.Y, angle);
            }
            
            display.DrawString(tmp, font, brush, new Point2d(10, 10));
            
            display.Invalidate();
        }

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));

            outputImageInfo.drawingFunc = new SvImageInfo.DrwaingFunc((display) => { display.GraphicsCollection.Add(regionRect); });

            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            State = false;

            if (OutputImage != null) OutputImage.Dispose();
            OutputImage = null;

            if (OutputRect != null) OutputRect = null;

            GetOutParams();
        }

        public bool CheckAngleRange(double angle)
        {
            if (angle < angleLow || angle > angleHigh) return false;
            else return true;
        }

        public override void Run(bool isEditMode = false)
        {
            inputImageInfo.Image = InputImage;

            if (InputImage == null) return;

            if (OutputImage != null) OutputImage.Dispose();
            OutputImage = InputImage.Clone(true);

            SvLogger.Log.Debug(string.Format("Result : ({0:0.000}, {1:0.000}, {2:0.000})", point.Point.X, point.Point.Y, angle));

            bool bPoint = regionRect.Rect.Contains(point.Point);
            bool bAngle = CheckAngleRange(angle);

            OutputRect = new SvRectangle();
            OutputRect.Rect = new Rect(regionRect.Rect.Location, regionRect.Rect.Size);

            if (bPoint == true && bAngle == true)
                State = true;
            else
                State = false;

            outputImageInfo.Image = OutputImage;
            outputImageInfo.drawingFunc = DisplayRegions;

            lastRunSuccess = true;
        }
    }
}
