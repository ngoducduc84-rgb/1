﻿using System;
using System.Runtime.Serialization;

namespace SvMip
{
    /// <summary>
    /// Repeats the next BodyCount tools of the same job Count times (at most 1000).
    /// The current iteration is available to the body as the output "Index" (0 based).
    /// SvJob.Run does the repeating; outputs of the body keep the values of the last iteration,
    /// but the job result is NG when any iteration of any body tool failed.
    /// </summary>
    [Serializable]
    public class SvFor : SvToolBase
    {
        public const int MaxCount = 1000;

        int count = 1;
        int bodyCount = 1;

        [NonSerialized]
        int index;

        public SvFor()
        {
        }
        public SvFor(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public int Count { get { return count; } set { count = value; NotifyPropertyChanged("Count"); } }
        public int BodyCount { get { return bodyCount; } set { bodyCount = value; NotifyPropertyChanged("BodyCount"); } }

        [OutputParam]
        public int Index { get { return index; } }
        [OutputParam]
        public int Iterations { get { return count; } }

        /// <summary>Called by SvJob before every iteration of the body.</summary>
        public void SetIteration(int i)
        {
            index = i;
            GetOutParams();
        }

        public int EffectiveCount
        {
            get
            {
                if (count < 0) return 0;
                return (count > MaxCount) ? MaxCount : count;
            }
        }

        public string Validate()
        {
            if (count < 0 || count > MaxCount) return "Count must be between 0 and " + MaxCount;
            if (bodyCount < 0) return "BodyCount must not be negative";
            return "";
        }

        public override void InitInParmas()
        {
        }
        public override void InitOutParmas()
        {
            outParams.Add("Index", null);
            outParams.Add("Iterations", null);
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            index = 0;
        }

        public override void Run(bool isEditMode = false)
        {
            index = 0;
            lastRunSuccess = true;
        }
    }
}
