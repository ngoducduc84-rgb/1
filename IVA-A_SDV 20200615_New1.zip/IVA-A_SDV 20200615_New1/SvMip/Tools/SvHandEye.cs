﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.Serialization;
using OpenCvSharp.CPlusPlus;

namespace SvMip
{
    public enum SvHandEyeMode
    {
        /// <summary>Forget the points collected so far (the robot starts a calibration).</summary>
        Begin,
        /// <summary>Add one pair: the mark found in the picture and the pose the robot sent.</summary>
        AddPoint,
        /// <summary>Compute the calibration from the collected pairs and save the file.</summary>
        Solve,
        /// <summary>Add one position of the mark while the robot rotates (for the rotation centre).</summary>
        AddRotationPoint,
        /// <summary>Compute the rotation centre and store it in the calibration file.</summary>
        SolveRotation
    }

    /// <summary>
    /// Calibration driven by the robot. Put it behind an SvIf that tests the command (e.g. @cmd = HE): every time the robot
    /// sends the command with its pose (e.g. "HE,123.4,56.7,0") the tool adds a (pixel, robot) pair; the command that ends the
    /// sequence (e.g. HEE) solves the calibration and saves the file that SvAlign uses. It replaces the 9-point calibration of the Teach screen.
    /// The answer for the robot is built from the Reply text.
    /// </summary>
    [Serializable]
    public class SvHandEye : SvToolBase, ISvContextTool
    {
        SvHandEyeMode mode = SvHandEyeMode.AddPoint;
        string calibrationFile = "HandEye.cal";
        string pixelSource = "";
        string robotX = "@request[1]";
        string robotY = "@request[2]";
        int minPoints = 9;
        double maxError = 0;
        bool originAtCenter = true;
        string markShiftX = "0";
        string markShiftY = "0";
        string reply = "{cmd},OK,{count}";
        string replyNg = "{cmd},NG,{message}";

        [NonSerialized]
        IList<SvToolBase> context;
        [NonSerialized]
        string message = "";

        // the collected pairs, per calibration file (lives while the program runs)
        class Pairs
        {
            public List<Point2d> Pixel = new List<Point2d>();
            public List<Point2d> Robot = new List<Point2d>();
            public List<Point3d> Rotation = new List<Point3d>();
        }
        static readonly object sLock = new object();
        static readonly Dictionary<string, Pairs> sPairs = new Dictionary<string, Pairs>(StringComparer.OrdinalIgnoreCase);

        public SvHandEye()
        {
        }
        public SvHandEye(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public SvHandEyeMode Mode { get { return mode; } set { mode = value; NotifyPropertyChanged("Mode"); } }
        /// <summary>File in the Calibration folder (the same name goes into SvAlign).</summary>
        public string CalibrationFile { get { return calibrationFile; } set { calibrationFile = value; NotifyPropertyChanged("CalibrationFile"); } }
        /// <summary>Where the mark is in the picture, e.g. "TemplateMatch1.ResultCP".</summary>
        public string PixelSource { get { return pixelSource; } set { pixelSource = value; NotifyPropertyChanged("PixelSource"); } }
        /// <summary>The robot X of the pose: a number, @request[n] (a part of the message) or Tool.Output.</summary>
        public string RobotX { get { return robotX; } set { robotX = value; NotifyPropertyChanged("RobotX"); } }
        public string RobotY { get { return robotY; } set { robotY = value; NotifyPropertyChanged("RobotY"); } }
        /// <summary>Solve needs at least this many pairs (a 3 x 3 grid = 9).</summary>
        public int MinPoints { get { return minPoints; } set { minPoints = value; NotifyPropertyChanged("MinPoints"); } }
        /// <summary>The calibration is not saved when a point is farther than this from where the calibration puts it (0 = do not check).</summary>
        public double MaxError { get { return maxError; } set { maxError = value; NotifyPropertyChanged("MaxError"); } }
        /// <summary>Robot coordinates are relative to the centre of the picture (as the Teach screen did); off = the robot's own coordinates.</summary>
        public bool OriginAtCenter { get { return originAtCenter; } set { originAtCenter = value; NotifyPropertyChanged("OriginAtCenter"); } }
        /// <summary>Rotation: distance of the mark from the tool axis (number, @request[n] or Tool.Output).</summary>
        public string MarkShiftX { get { return markShiftX; } set { markShiftX = value; NotifyPropertyChanged("MarkShiftX"); } }
        public string MarkShiftY { get { return markShiftY; } set { markShiftY = value; NotifyPropertyChanged("MarkShiftY"); } }
        /// <summary>Answer when it worked: {cmd} {count} {maxerr} {meanerr} {centerx} {centery} {message} {request}.</summary>
        public string Reply { get { return reply; } set { reply = value; NotifyPropertyChanged("Reply"); } }
        public string ReplyNg { get { return replyNg; } set { replyNg = value; NotifyPropertyChanged("ReplyNg"); } }

        [OutputParam]
        public int Count { get { return mCount; } set { mCount = value; } }
        [NonSerialized]
        int mCount;
        [OutputParam]
        public double MaxErrorResult { get { return mMaxErrorResult; } set { mMaxErrorResult = value; } }
        [NonSerialized]
        double mMaxErrorResult;
        [OutputParam]
        public double MeanErrorResult { get { return mMeanErrorResult; } set { mMeanErrorResult = value; } }
        [NonSerialized]
        double mMeanErrorResult;
        public string Message { get { return message; } }

        public void SetContext(IList<SvToolBase> tools)
        {
            context = tools;
        }

        public string Validate()
        {
            if (string.IsNullOrEmpty(calibrationFile)) return "No calibration file name";
            if (mode == SvHandEyeMode.AddPoint || mode == SvHandEyeMode.AddRotationPoint)
            {
                if (string.IsNullOrEmpty(pixelSource)) return "No pixel source (the tool that finds the mark)";
            }
            if (mode == SvHandEyeMode.AddPoint && (string.IsNullOrEmpty(robotX) || string.IsNullOrEmpty(robotY))) return "Robot X / Y source is empty";
            if (mode == SvHandEyeMode.Solve && minPoints < 3) return "MinPoints must be at least 3";
            return "";
        }

        public override void InitInParmas()
        {
        }
        public override void InitOutParmas()
        {
            outParams.Add("Count", null);
            outParams.Add("MaxErrorResult", null);
            outParams.Add("MeanErrorResult", null);
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            Count = 0;
            MaxErrorResult = 0;
            MeanErrorResult = 0;
            message = "";
        }

        static Pairs GetPairs(string file)
        {
            lock (sLock)
            {
                Pairs p;
                if (!sPairs.TryGetValue(file, out p))
                {
                    p = new Pairs();
                    sPairs[file] = p;
                }
                return p;
            }
        }

        bool GetPixel(out Point3d pixel)
        {
            pixel = new Point3d();
            object v;
            string err;
            if (!SvPathResolver.TryGetToolValue(context, pixelSource, out v, out err)) { message = err; return false; }
            if (!SvPathResolver.TryToPoint3d(v, out pixel)) { message = "'" + pixelSource + "' is not a point (the mark was not found?)"; return false; }
            return true;
        }

        bool GetNumber(string source, out double number)
        {
            string err;
            if (!SvRuntime.TryGetNumber(context, source, out number, out err)) { message = err; return false; }
            return true;
        }

        /// <summary>The size of the first picture of the job (the centre of it is the origin of the robot coordinates).</summary>
        bool GetImageSize(out int width, out int height)
        {
            width = 0;
            height = 0;
            if (context == null) return false;
            foreach (SvToolBase t in context)
            {
                foreach (KeyValuePair<string, object> kv in t.outParams)
                {
                    SvImage img = kv.Value as SvImage;
                    if (img == null) continue;
                    try
                    {
                        if (img.IsNull || img.Width <= 0) continue;
                        width = img.Width;
                        height = img.Height;
                        return true;
                    }
                    catch (Exception) { }
                }
            }
            return false;
        }

        public override void Run(bool isEditMode = false)
        {
            lastRunSuccess = false;
            message = "";
            if (!SvRuntime.HasRequest)
            {
                // editing the job: nothing is collected without a command from the robot
                message = "runs only when the robot sends a command";
                lastRunSuccess = true;
                return;
            }

            string err = Validate();
            double centerX = 0, centerY = 0, maxE = 0, meanE = 0;
            int count = 0;
            bool ok = false;

            if (err != "") message = err;
            else if (context == null) message = "no tool list available (SvHandEye must run inside a job)";
            else if (SvRuntime.Service == null) message = "the calibration service is not installed";
            else
            {
                try
                {
                    ok = Execute(out count, out maxE, out meanE, out centerX, out centerY);
                }
                catch (Exception ex)
                {
                    message = ex.Message;
                    ok = false;
                }
            }

            Count = count;
            MaxErrorResult = maxE;
            MeanErrorResult = meanE;
            lastRunSuccess = ok;

            Dictionary<string, object> values = new Dictionary<string, object>();
            values["cmd"] = SvRuntime.Command;
            values["request"] = SvRuntime.Request;
            values["count"] = count;
            values["maxerr"] = maxE;
            values["meanerr"] = meanE;
            values["centerx"] = centerX;
            values["centery"] = centerY;
            values["message"] = message;
            string template = ok ? reply : replyNg;
            if (!string.IsNullOrEmpty(template)) SvRuntime.SetReply(SvRuntime.Format(template, values));
        }

        bool Execute(out int count, out double maxE, out double meanE, out double centerX, out double centerY)
        {
            count = 0; maxE = 0; meanE = 0; centerX = 0; centerY = 0;
            string file = calibrationFile.Trim();
            Pairs pairs = GetPairs(file);

            switch (mode)
            {
                case SvHandEyeMode.Begin:
                    lock (sLock) { pairs.Pixel.Clear(); pairs.Robot.Clear(); pairs.Rotation.Clear(); }
                    message = "cleared";
                    return true;

                case SvHandEyeMode.AddPoint:
                    {
                        Point3d pixel;
                        double rx, ry;
                        if (!GetPixel(out pixel)) return false;
                        if (!GetNumber(robotX, out rx) || !GetNumber(robotY, out ry)) return false;
                        lock (sLock)
                        {
                            pairs.Pixel.Add(new Point2d(pixel.X, pixel.Y));
                            pairs.Robot.Add(new Point2d(rx, ry));
                            count = pairs.Pixel.Count;
                        }
                        message = string.Format(CultureInfo.InvariantCulture, "point {0}: pixel ({1:F2}, {2:F2}) robot ({3:F3}, {4:F3})", count, pixel.X, pixel.Y, rx, ry);
                        return true;
                    }

                case SvHandEyeMode.Solve:
                    {
                        Point2d[] px, rb;
                        lock (sLock) { px = pairs.Pixel.ToArray(); rb = pairs.Robot.ToArray(); }
                        count = px.Length;
                        if (count < minPoints) { message = "only " + count + " points, " + minPoints + " are needed"; return false; }
                        int w, h;
                        if (!GetImageSize(out w, out h)) { w = 0; h = 0; }
                        if (originAtCenter && w <= 0) { message = "no picture in the job: the centre of the picture is not known"; return false; }
                        string msg;
                        bool ok = SvRuntime.Service.SolveLinear(file, px, rb, w, h, originAtCenter, maxError, out maxE, out meanE, out msg);
                        message = msg;
                        if (ok)
                        {
                            lock (sLock) { pairs.Pixel.Clear(); pairs.Robot.Clear(); }
                            SvRuntime.NotifyCalibrationSaved(file);
                        }
                        return ok;
                    }

                case SvHandEyeMode.AddRotationPoint:
                    {
                        Point3d pixel;
                        if (!GetPixel(out pixel)) return false;
                        lock (sLock) { pairs.Rotation.Add(pixel); count = pairs.Rotation.Count; }
                        message = string.Format(CultureInfo.InvariantCulture, "rotation point {0}: pixel ({1:F2}, {2:F2})", count, pixel.X, pixel.Y);
                        return true;
                    }

                default: // SolveRotation
                    {
                        List<Point3d> pts;
                        lock (sLock) { pts = new List<Point3d>(pairs.Rotation); }
                        count = pts.Count;
                        if (count < 3) { message = "only " + count + " rotation points, 3 are needed"; return false; }
                        double sx, sy;
                        if (!GetNumber(markShiftX, out sx) || !GetNumber(markShiftY, out sy)) return false;
                        Point2d center;
                        string msg;
                        bool ok = SvRuntime.Service.SolveRotation(file, pts, sx, sy, out center, out msg);
                        message = msg;
                        if (ok)
                        {
                            centerX = center.X;
                            centerY = center.Y;
                            lock (sLock) { pairs.Rotation.Clear(); }
                            SvRuntime.NotifyCalibrationSaved(file);
                        }
                        return ok;
                    }
            }
        }
    }
}
