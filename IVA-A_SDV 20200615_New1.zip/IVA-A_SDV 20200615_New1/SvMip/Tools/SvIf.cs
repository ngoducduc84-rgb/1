﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace SvMip
{
    public enum SvCompare
    {
        IsTrue, IsFalse, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual,
        /// <summary>Text comparisons (not case sensitive): the source is text, e.g. @cmd or @request[1].</summary>
        TextEqual, TextNotEqual, TextStartsWith, TextContains
    }

    /// <summary>
    /// Conditional execution. When the condition is true the next BodyCount tools of the same job run,
    /// otherwise they are skipped (their outputs are cleared and they do not make the job NG).
    /// The condition reads a tool output by path, e.g. "Judgement1.Judgement" (see SvPathResolver).
    /// The job (SvJob.Run) does the skipping, so SvIf only evaluates the condition.
    /// The source can also be the text the robot sent: "@cmd" (first part) or "@request[n]", compared with the Text conditions.
    /// </summary>
    [Serializable]
    public class SvIf : SvToolBase, ISvContextTool
    {
        string source = "";
        SvCompare op = SvCompare.IsTrue;
        double compareValue = 0;
        string compareText = "";
        int bodyCount = 1;

        [NonSerialized]
        bool runBody;
        [NonSerialized]
        string error = "";
        [NonSerialized]
        IList<SvToolBase> context;

        public SvIf()
        {
        }
        public SvIf(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            SvLoose.Ensure(this, "Value");
        }

        /// <summary>Input: the value to test. When an output is linked here it is used; otherwise Source (a path) is used.</summary>
        [NonSerialized]
        object value;
        public object Value { get { return value; } set { this.value = value; } }

        public override void GetInParams()
        {
            // accepts any type (the base class only accepts links of exactly the same type)
            value = SvLoose.Read(this, "Value");
        }

        /// <summary>Tool output to test, e.g. "Judgement1.Judgement".</summary>
        public string Source { get { return source; } set { source = value; NotifyPropertyChanged("Source"); } }
        public SvCompare Operator { get { return op; } set { op = value; NotifyPropertyChanged("Operator"); } }
        /// <summary>Right hand side for Equal / NotEqual / Less ... (ignored for IsTrue / IsFalse).</summary>
        public double CompareValue { get { return compareValue; } set { compareValue = value; NotifyPropertyChanged("CompareValue"); } }
        /// <summary>Right hand side of the Text conditions (TextEqual ...), e.g. HE. Several values separated by | are alternatives.</summary>
        public string CompareText { get { return compareText; } set { compareText = value; NotifyPropertyChanged("CompareText"); } }
        /// <summary>How many of the following tools are controlled by this condition.</summary>
        public int BodyCount { get { return bodyCount; } set { bodyCount = value; NotifyPropertyChanged("BodyCount"); } }

        [OutputParam]
        public bool Result { get; set; }

        /// <summary>True when the controlled tools must run (valid after Run).</summary>
        public bool RunBody { get { return runBody; } }
        public string Error { get { return error; } }

        /// <summary>Called by SvJob before Run: the tools the source path can refer to.</summary>
        public void SetContext(IList<SvToolBase> tools)
        {
            context = tools;
        }

        public string Validate()
        {
            if (string.IsNullOrEmpty(source) && !SvLoose.IsLinked(this, "Value")) return "No source is set (link the Value input or type a source)";
            if (op >= SvCompare.TextEqual && string.IsNullOrEmpty(compareText)) return "Compare text is empty";
            if (bodyCount < 0) return "BodyCount must not be negative";
            return "";
        }

        public override void InitInParmas()
        {
            inParams.Add("Value", null);
        }
        public override void InitOutParmas()
        {
            outParams.Add("Result", null);
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            Result = false;
            runBody = false;
            error = "";
        }

        public override void Run(bool isEditMode = false)
        {
            runBody = false;
            Result = false;
            error = "";

            if (context == null)
            {
                error = "no tool list available (SvIf must run inside a job)";
                lastRunSuccess = false;
                return;
            }
            object v;
            bool cond;
            bool linked = SvLoose.IsLinked(this, "Value");
            if (linked)
            {
                v = SvLoose.Read(this, "Value");
                error = "";
                if (v == null && op < SvCompare.TextEqual)
                {
                    error = "the linked input '" + SvLoose.LinkText(this, "Value") + "' has no value";
                    lastRunSuccess = false;
                    return;
                }
            }
            else if (!SvPathResolver.TryGetToolValue(context, source, out v, out error))
            {
                // a text condition on the request without a request (editing the job): false, and not an error
                if (op >= SvCompare.TextEqual && source.TrimStart().StartsWith("@") && !SvRuntime.HasRequest)
                {
                    error = "";
                    lastRunSuccess = true;
                    return;
                }
                lastRunSuccess = false;
                return;
            }
            if (op >= SvCompare.TextEqual)
            {
                string text = Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture) ?? "";
                bool hit = false;
                foreach (string alt in (compareText ?? "").Split('|'))
                {
                    string a = alt.Trim();
                    bool one;
                    switch (op)
                    {
                        case SvCompare.TextStartsWith: one = text.StartsWith(a, StringComparison.OrdinalIgnoreCase); break;
                        case SvCompare.TextContains: one = a.Length > 0 && text.IndexOf(a, StringComparison.OrdinalIgnoreCase) >= 0; break;
                        default: one = string.Equals(text, a, StringComparison.OrdinalIgnoreCase); break;
                    }
                    if (one) { hit = true; break; }
                }
                cond = (op == SvCompare.TextNotEqual) ? !hit : hit;
                Result = cond;
                runBody = cond;
                lastRunSuccess = true;
                return;
            }
            double d;
            if (!SvPathResolver.TryToDouble(v, out d))
            {
                error = "value of '" + (linked ? SvLoose.LinkText(this, "Value") : source) + "' is not a number or bool";
                lastRunSuccess = false;
                return;
            }

            switch (op)
            {
                case SvCompare.IsTrue: cond = (d != 0); break;
                case SvCompare.IsFalse: cond = (d == 0); break;
                case SvCompare.Equal: cond = (Math.Abs(d - compareValue) < 1e-9); break;
                case SvCompare.NotEqual: cond = (Math.Abs(d - compareValue) >= 1e-9); break;
                case SvCompare.Less: cond = (d < compareValue); break;
                case SvCompare.LessEqual: cond = (d <= compareValue); break;
                case SvCompare.Greater: cond = (d > compareValue); break;
                default: cond = (d >= compareValue); break;
            }
            Result = cond;
            runBody = cond;
            lastRunSuccess = true;
        }
    }
}
