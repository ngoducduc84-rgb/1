﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OpenCvSharp.CPlusPlus;
using System.Runtime.Serialization;
using System.Windows.Forms;


namespace SvMip
{
    [Serializable]
    public class SvImageSave : SvToolBase
    {
        public SvImageSave()
        { 
            saveFileName = null;
            saveFilePath = null;
        }
        public SvImageSave(SerializationInfo info, StreamingContext context) : base(info, context) { }

        #region InParams
        
        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }

        string saveFileName;

        public string SaveFileName
        {
            get { return saveFileName; }
            set
            {
                saveFileName = value;
                NotifyPropertyChanged("SaveFileName");
            }
        }

        [InputParam]
        public SvImage InputImage { get; set; }

        #endregion

        #region OutParams

        public override void InitOutParmas()
        {
        }

        string saveFilePath;


        public string SaveFilePath
        {
            get { return saveFilePath; }
            set
            {
                saveFilePath = value;
                NotifyPropertyChanged("SaveFilePath");
            }
        }

        #endregion

        SvImageInfo inputImageInfo;
        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            imageList.Add(inputImageInfo);
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;
        }

        public override void Run(bool isEditMode = false)
        {
            inputImageInfo.Image = InputImage;

            if (InputImage == null)
            {
                lastRunSuccess = false;
                return;
            }

            if (!System.IO.Directory.Exists(SaveFilePath))
            {
                lastRunSuccess = false;
                return;
            }

            //saveFilePath = System.IO.Directory.GetCurrentDirectory();

            //saveFilePath += "\\..\\Img_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_")  + saveFileName + ".bmp";

            string filename = SaveFileName + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".jpg";

            string savefile = System.IO.Path.Combine(SaveFilePath, filename);

            InputImage.Mat.SaveImage(savefile);

            lastRunSuccess = true;
        }
    }
}
