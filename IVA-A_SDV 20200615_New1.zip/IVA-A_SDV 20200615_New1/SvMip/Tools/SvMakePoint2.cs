﻿//using OpenCvSharp.CPlusPlus;
//using System;
//using System.Collections.Generic;
//using System.Drawing;
//using System.Runtime.Serialization;

//namespace SvMip
//{
//    [Serializable]
//    public class SvMakePoint2 : SvToolBase
//    {
//        public SvMakePoint2()
//        {
//            //regionRect = new SvRectangle();            
//        }

//        public SvMakePoint2(SerializationInfo info, StreamingContext context) : base(info, context) { }

//        #region InputValue

//        public override void InitInParmas()
//        {
//            inParams.Add("InputImage", null);
//            inParams.Add("X", null);
//            inParams.Add("Y", null);
//            inParams.Add("T", null);
//        }

//        [InputParam]
//        public SvImage InputImage { get; set; }

//        double x = double.NaN;
//        double y = double.NaN;
//        double t = double.NaN;
//        [InputParam]
//        public double X
//        {
//            get
//            {
//                if (double.IsNaN(x)) return double.NaN;
//                return x;
//            }
//            set
//            {
//                x = value;
//            }
//        }
//        [InputParam]
//        public double Y
//        {
//            get
//            {
//                if (double.IsNaN(y)) return double.NaN;
//                return y;
//            }
//            set
//            {
//                y = value;
//            }
//        }
//        [InputParam]
//        public double T
//        {
//            get
//            {
//                if (double.IsNaN(t)) return double.NaN;
//                return t;
//            }
//            set
//            {
//                t = value;
//            }
//        }
//        #endregion

//        #region OutputValue
//        public override void InitOutParmas()
//        {
//            outParams.Add("OutPoint", null);
//        }

//        OffsetControl cOffControl = new OffsetControl(OffsetControl.LongOrShort.Long, OffsetControl.OriginDirection.Right);

//        public OffsetControl.OriginDirection Origin
//        {
//            get { return cOffControl.Origin; }
//            set { cOffControl.Origin = value; }
//        }

//        SvPoint outPoint;
//        [OutputParam]
//        public SvPoint OutPoint
//        {
//            get
//            {
//                if (double.IsNaN(x) || double.IsNaN(y) || double.IsNaN(t)) return null;
//                //Point3d transImageP = new Point3d(InPoint.X, InPoint.Y, InPoint.ThetaRad);

//                //transImageP = SvFunc.FixtureToImage3D(transImageP, inPoint.TransformMat);

//                if (InputImage == null) return null;// && InputImage.TransformMat == null)
//                //    transImageP = SvFunc.ImageToFixture3D(transImageP, InputImage.TransformMat);
//                return outPoint;
//            }
//            set { outPoint = value; }
//        }
//        #endregion

//        SvImageInfo inputImageInfo;
//        SvImageInfo outputImageInfo;

//        public override void InitImageList()
//        {
//            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
//            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));

//            imageList.Add(inputImageInfo);
//            imageList.Add(outputImageInfo);
//        }

//        public override void InitOutProperty()
//        {
//            lastRunSuccess = false;
//            OutPoint = null;
//            GetOutParams();
//        }


//        public void DrawPoint(Display.SvDisplayView display)
//        {
//            if (display.Image == null) return;
//            //display.GraphicsFuncCollection.Clear();
//            if (OutPoint != null && InputImage != null)
//            {
//                //OutPoint.Display = display as Display.SvDisplayViewInteract;
//                //display.Image = InputImage;

//                float[,] ff = SvFunc.DisplayMatF(InputImage.TransformMat);
//                float[,] ff1 = SvFunc.DisplayMatF(outPoint.TransformMat);

//                Point2d p = SvFunc.FixtureToImage2D(outPoint.Point2d, outPoint.TransformMat);

//                outPoint.Display = display as Display.SvDisplayViewInteract;
//                display.GraphicsCollection.Add(outPoint);
//                Font f = new System.Drawing.Font("굴림", 10, System.Drawing.FontStyle.Bold);
//                SolidBrush SB = new System.Drawing.SolidBrush(Color.Cyan);
//                display.DrawString(string.Format("({0:f3}, {1:f3}, {2:f3})", outPoint.X, outPoint.Y, outPoint.ThetaRad * 180 / Math.PI), f, SB, outPoint.Point2d);
//            }
//        }

//        public override void Run(bool isEditMode = false)
//        {
//            inputImageInfo.Image = InputImage;

//            if (InputImage == null) return;
//            if (double.IsNaN(x) || double.IsNaN(y) || double.IsNaN(t)) return;

//            outputImageInfo.Image = InputImage;
//            //outputImageInfo.drawingFunc = DrawPoint;

//            Point3d P = new Point3d(x, y, t * Math.PI / 180);
//            outPoint = new SvPoint(P);


//            double Tdeg = t;
//            Tdeg += 360;

//            while (Tdeg > -45)
//            {
//                Tdeg -= 90;
//                if (Tdeg >= -45 && Tdeg < 45) break;
//            }

//            switch (Origin)
//            {
//                case OffsetControl.OriginDirection.Right:
//                    Tdeg -= 0;
//                    break;
//                case OffsetControl.OriginDirection.Bottom:
//                    Tdeg += 90;
//                    break;
//                case OffsetControl.OriginDirection.Left:
//                    if (Tdeg > 0)
//                        Tdeg -= 180;
//                    else
//                        Tdeg += 180;
//                    break;
//                case OffsetControl.OriginDirection.Top:
//                    Tdeg -= 90;
//                    break;
//            }
//            outPoint.ThetaRad = Tdeg * Math.PI / 180;


//            NotifyPropertyChanged("OutPoint");
//            GetOutParams();
//            lastRunSuccess = true;
//            NotifyRan(this, this);
//        }
//    }
//}
