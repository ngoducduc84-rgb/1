﻿using OpenCvSharp.CPlusPlus;
using System;
using System.Drawing;
using System.Runtime.Serialization;

namespace SvMip
{
    [Serializable]
    public class SvMasking : SvToolBase
    {
        public SvMasking()
        {
            rotationRect = new SvRotationRectangle();
            ellipse = new SvEllipse();
        }

        public SvMasking(SerializationInfo info, StreamingContext context) : base(info, context) { }

        #region InputValue

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }

        [InputParam]
        public SvImage InputImage { get; set; }

        #endregion

        SvRotationRectangle rotationRect;
        public SvRotationRectangle RotationRect
        {
            get { return rotationRect; }
            set
            {
                rotationRect = value.Clone();
                rotationRect.TransformMat = InputImage.TransformMat;
            }
        }

        SvEllipse ellipse;
        public SvEllipse Ellipse
        {
            get { return ellipse; }
            set 
            {
                ellipse = new SvEllipse(value.Center, value.Width, value.Height);
                ellipse.TransformMat = InputImage.TransformMat;
            }
        }

        public enum ePenType
        {
            None, Rect, Ellipse
        }
        public ePenType PenType { get; set; }

        SvMask mask;
        public SvMask Mask
        {
            get 
            {
                if (InputImage == null) return null;
                SvImage imagetemp = null;

                if (mask == null)
                {
                    mask = new SvMask(InputImage.Width, InputImage.Height);
                }
                else if (!mask.IsPossible(InputImage))
                {
                    imagetemp = new SvImage(mask.MaskMat.Clone());
                    imagetemp.TransformMat = mask.TransformMat;
                    mask.Dispose();
                    mask = new SvMask(InputImage.Width, InputImage.Height);
                }

                if (imagetemp != null)
                {
                    //SvFunc.ShowTestImg(imagetemp.Mat, 0.5);
                    Cv2.WarpPerspective(imagetemp.Mat, mask.MaskMat, Mat.Eye(3, 3, MatType.CV_32FC1), new OpenCvSharp.CPlusPlus.Size(mask.MaskMat.Width, mask.MaskMat.Height), OpenCvSharp.Interpolation.Linear, OpenCvSharp.BorderType.Constant, 255);
                    //SvFunc.ShowTestImg(mask.MaskMat, 0.5);
                    imagetemp.Dispose();
                }

                mask.DrawMask = PenType == ePenType.None;
                mask.TransformMat = InputImage.TransformMat;
                return mask; 
            }
            set
            {
                if (mask == value) return;
                mask = value;
                NotifyPropertyChanged("Mask");
            }
        }

        public bool OnMask
        {
            get 
            { 
                if (mask == null) return true;
                return mask.OnMask;
            }
            set
            {
                if (mask == null) return;
                if (mask.OnMask == value) return;
                mask.OnMask = value;
                NotifyPropertyChanged("OnMask");
            }
        }

        public int PenSize
        {
            get
            {
                if (mask == null) return 0;
                return mask.PenSize;
            }
            set
            {
                if (mask == null) return;
                if (mask.PenSize == value) return;
                mask.PenSize = value;
                NotifyPropertyChanged("PenSize");
            }
        }

        #region OutputValue
        public override void InitOutParmas()
        {
            outParams.Add("OutputImage", null);
        }

        [OutputParam]
        public SvImage OutputImage { get; set; }

        SvImage maskImage;
        [OutputParam]
        public SvImage MaskImage
        {
            get
            {
                if (maskImage == null)
                    maskImage = new SvImage(Mask.MaskMat);
                return maskImage;
            }
        }
        
        #endregion

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));

            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;

            if (OutputImage != null) OutputImage.Dispose();
            OutputImage = null;

            GetOutParams();
        }

        public override void Run(bool isEditMode = false)
        {
            inputImageInfo.Image = InputImage;

            if (InputImage == null) return;
            
            if (OutputImage != null) OutputImage.Dispose();            
            OutputImage = new SvImage();

            //if (Mask != null && !Mask.IsPossible(InputImage))
                InputImage.Mat.CopyTo(OutputImage.Mat, Mask.MaskMat);
            //else
                //OutputImage = InputImage.Clone(true);

            OutputImage.RegionRect = new SvRectangle(0, 0, OutputImage.Width, OutputImage.Height);

            outputImageInfo.Image = OutputImage;
            
            lastRunSuccess = true;
        }

    }
}
