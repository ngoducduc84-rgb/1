﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.Serialization;
using OpenCvSharp.CPlusPlus;

namespace SvMip
{
    /// <summary>
    /// "Get master" inside the job: when the robot sends the command (put the tool behind an SvIf, e.g. @cmd = MS) the mark that was
    /// found is converted with the calibration and stored as the load position (master) of a point of SvAlign.
    /// It replaces the GET LOADING POS button of the Data screen. Without a command (editing the job) it only shows the values.
    /// </summary>
    [Serializable]
    public class SvMaster : SvToolBase, ISvContextTool
    {
        string pixelSource = "";
        string calibrationFile = "";
        int alignPoint = 0;
        bool saveJob = true;
        string reply = "{cmd},OK,{x:F3},{y:F3},{t:F3}";
        string replyNg = "{cmd},NG,{message}";

        [NonSerialized]
        IList<SvToolBase> context;
        [NonSerialized]
        string message = "";

        public SvMaster()
        {
        }
        public SvMaster(SerializationInfo info, StreamingContext context) : base(info, context) { }

        /// <summary>Where the part is in the picture, e.g. "MakePoint1.OutPoint".</summary>
        public string PixelSource { get { return pixelSource; } set { pixelSource = value; NotifyPropertyChanged("PixelSource"); } }
        /// <summary>Empty = the calibration file of SvAlign.</summary>
        public string CalibrationFile { get { return calibrationFile; } set { calibrationFile = value; NotifyPropertyChanged("CalibrationFile"); } }
        /// <summary>Which point of SvAlign gets the master: 0 = the first.</summary>
        public int AlignPoint { get { return alignPoint; } set { alignPoint = value; NotifyPropertyChanged("AlignPoint"); } }
        /// <summary>Write the job file after the master changed (the previous file is kept as .bak).</summary>
        public bool SaveJob { get { return saveJob; } set { saveJob = value; NotifyPropertyChanged("SaveJob"); } }
        public string Reply { get { return reply; } set { reply = value; NotifyPropertyChanged("Reply"); } }
        public string ReplyNg { get { return replyNg; } set { replyNg = value; NotifyPropertyChanged("ReplyNg"); } }

        [OutputParam]
        public double X { get { return mX; } set { mX = value; } }
        [NonSerialized]
        double mX;
        [OutputParam]
        public double Y { get { return mY; } set { mY = value; } }
        [NonSerialized]
        double mY;
        /// <summary>Degrees.</summary>
        [OutputParam]
        public double T { get { return mT; } set { mT = value; } }
        [NonSerialized]
        double mT;
        public string Message { get { return message; } }

        public void SetContext(IList<SvToolBase> tools)
        {
            context = tools;
        }

        public string Validate()
        {
            if (string.IsNullOrEmpty(pixelSource)) return "No pixel source";
            if (alignPoint < 0) return "AlignPoint must not be negative";
            return "";
        }

        public override void InitInParmas()
        {
        }
        public override void InitOutParmas()
        {
            outParams.Add("X", null);
            outParams.Add("Y", null);
            outParams.Add("T", null);
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            X = 0;
            Y = 0;
            T = 0;
            message = "";
        }

        public override void Run(bool isEditMode = false)
        {
            lastRunSuccess = false;
            message = "";
            bool ok = false;
            bool request = SvRuntime.HasRequest;
            try
            {
                ok = Execute(request);
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }
            lastRunSuccess = ok;

            if (request)
            {
                Dictionary<string, object> values = new Dictionary<string, object>();
                values["cmd"] = SvRuntime.Command;
                values["request"] = SvRuntime.Request;
                values["x"] = X;
                values["y"] = Y;
                values["t"] = T;
                values["message"] = message;
                string template = ok ? reply : replyNg;
                if (!string.IsNullOrEmpty(template)) SvRuntime.SetReply(SvRuntime.Format(template, values));
            }
        }

        bool Execute(bool store)
        {
            string err = Validate();
            if (err != "") { message = err; return false; }
            if (context == null) { message = "no tool list available (SvMaster must run inside a job)"; return false; }
            if (SvRuntime.Service == null) { message = "the calibration service is not installed"; return false; }

            SvAlign align = null;
            foreach (SvToolBase t in context)
            {
                align = t as SvAlign;
                if (align != null) break;
            }
            string file = !string.IsNullOrEmpty(calibrationFile) ? calibrationFile : (align != null ? align.CalibrationFile : "");
            if (string.IsNullOrEmpty(file)) { message = "no calibration file (set it here or in SvAlign)"; return false; }

            object v;
            Point3d pixel;
            if (!SvPathResolver.TryGetToolValue(context, pixelSource, out v, out err)) { message = err; return false; }
            if (!SvPathResolver.TryToPoint3d(v, out pixel)) { message = "'" + pixelSource + "' is not a point (the part was not found?)"; return false; }

            Point3d robot;
            string msg;
            if (!SvRuntime.Service.PixelToRobot(file, pixel, out robot, out msg)) { message = msg; return false; }
            X = robot.X;
            Y = robot.Y;
            T = robot.Z * 180.0 / Math.PI;
            message = string.Format(CultureInfo.InvariantCulture, "master ({0:F3}, {1:F3}, {2:F3})", X, Y, T);

            if (!store) return true;   // editing the job: only show the values
            if (align == null) { message = "no SvAlign in the job to store the master"; return false; }
            if (alignPoint >= align.Points.Count) { message = "SvAlign has no point " + alignPoint; return false; }
            SvAlignPoint ap = align.Points[alignPoint];
            ap.LoadX = X;
            ap.LoadY = Y;
            ap.LoadT = T;
            if (saveJob) SvRuntime.NotifyJobChanged();
            return true;
        }
    }
}
