﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.Serialization;

namespace SvMip
{
    /// <summary>How the fields of a channel are written. New values are only added at the end.</summary>
    public enum SvSendKind
    {
        /// <summary>All align results of SvAlign, written like the legacy offset block (no fields needed).</summary>
        Offsets,
        /// <summary>Fields are taken three by three (x, y, t) and written with WritePosition(index + n).</summary>
        Position,
        /// <summary>Every field is written with WriteValue(index + field address).</summary>
        Values,
        /// <summary>A text built from Template and the fields, sent over a TCP / UDP / Serial connection (Connection).</summary>
        Text,
        /// <summary>Fields are written as Modbus registers (function 16) over a ModbusTcp connection (Connection).</summary>
        Registers
    }

    public enum SvSendCondition { Always, OnlyOK, OnlyNG }

    public enum SvSendValueType { Float, Int32, Int16, Text }

    /// <summary>One value of a channel: where it comes from and how it is converted.</summary>
    [Serializable]
    public class SvSendField
    {
        public SvSendField()
        {
            Name = "Field";
            Source = "";
            ValueType = SvSendValueType.Float;
            Scale = 1.0;
            Offset = 0.0;
        }

        public string Name { get; set; }
        /// <summary>"@align[0].x", "MakePoint1.OutPoint.X", "@judge" ... (see SvPathResolver / AutoThread_Direct for the syntax).</summary>
        public string Source { get; set; }
        public SvSendValueType ValueType { get; set; }
        /// <summary>Address relative to the channel start index (Values / Registers channels).</summary>
        public int Address { get; set; }
        /// <summary>sent value = source * Scale + Offset</summary>
        public double Scale { get; set; }
        public double Offset { get; set; }
        public bool UseRange { get; set; }
        public double Min { get; set; }
        public double Max { get; set; }
    }

    /// <summary>One input of SvSend: its name (used as {name} in the message) and the value typed when no output is linked.</summary>
    [Serializable]
    public class SvSendInput
    {
        public SvSendInput()
        {
            Name = "";
            Text = "";
            Key = "";
        }
        public string Name { get; set; }
        /// <summary>The value to send when no output is linked to the input (a number or a text).</summary>
        public string Text { get; set; }
        /// <summary>The name that inParams uses (so that a link survives a rename).</summary>
        public string Key { get; set; }
    }

    [Serializable]
    public class SvSendChannel
    {
        public SvSendChannel()
        {
            Name = "Channel";
            Enabled = true;
            Kind = SvSendKind.Position;
            StartIndex = -1;
            Condition = SvSendCondition.Always;
            Fields = new List<SvSendField>();
            Connection = "";
            Template = "";
            Reply = "";
        }

        public string Name { get; set; }
        public bool Enabled { get; set; }
        public SvSendKind Kind { get; set; }
        /// <summary>Start index (Offsets: -1 = offset start address of SvTrigger; Registers: first register).</summary>
        public int StartIndex { get; set; }
        public SvSendCondition Condition { get; set; }
        public List<SvSendField> Fields { get; set; }
        /// <summary>Name of an SvConnection (Text / Registers channels).</summary>
        public string Connection { get; set; }
        /// <summary>Text channels: e.g. {x1:F3},{y1:F3},{t1:F3}\r\n  (placeholders are field names).</summary>
        public string Template { get; set; }
        /// <summary>Text channels: when not empty, a reply containing this text must arrive within the connection timeout.</summary>
        public string Reply { get; set; }
        /// <summary>Registers channels: low word first for Int32 / Float values.</summary>
        public bool WordSwap { get; set; }
    }

    /// <summary>
    /// Configuration-only tool: describes what is sent to the PLC / robot at the end of a cycle.
    /// Writing is done by AutoThread_Direct through the connection of the process or a stream connection.
    /// </summary>
    [Serializable]
    public class SvSend : SvToolBase, ISvDynamicParams
    {
        List<SvSendChannel> channels = new List<SvSendChannel>();
        bool dryRun = false;

        public SvSend()
        {
        }
        public SvSend(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            SvLoose.Ensure(this, "ConnectionLink");
            if (inputs == null) inputs = new List<SvSendInput>();
            MigrateOldSlots();
            SyncParams();
        }

        // ---- simple sending: inputs that the user adds, and one message ----
        List<SvSendInput> inputs = new List<SvSendInput>();
        string connection = "";
        string message = "";
        SvSendCondition messageWhen = SvSendCondition.Always;
        // first version: twelve fixed values V1..V12 (only read to move them to the table)
        string[] v;

        /// <summary>The inputs (added in the edit form): each one is linked to an output or typed.</summary>
        public List<SvSendInput> Inputs { get { return inputs; } }

        /// <summary>Input: link it to the Connection output of an SvConnection instead of typing the name.</summary>
        [InputParam]
        public string ConnectionLink { get { return connectionLink; } set { connectionLink = value; } }
        [NonSerialized]
        string connectionLink;

        /// <summary>The connection (SvConnection name) of the message, typed here. The ConnectionLink input wins when it is linked.</summary>
        public string Connection { get { return connection; } set { connection = value; NotifyPropertyChanged("Connection"); } }

        /// <summary>The connection that is used: the linked SvConnection, otherwise the typed name.</summary>
        public string ConnectionName
        {
            get
            {
                SvConnection c = SvLoose.LinkedTool(this, "ConnectionLink") as SvConnection;
                return c != null ? c.ConnName : connection;
            }
        }

        /// <summary>The text that is sent at the end of the cycle, e.g. {v1},{v2:F3},{v3}\r\n. {name} is the value of the input with that name.</summary>
        public string Message { get { return message; } set { message = value; NotifyPropertyChanged("Message"); } }
        public SvSendCondition MessageWhen { get { return messageWhen; } set { messageWhen = value; NotifyPropertyChanged("MessageWhen"); } }

        void MigrateOldSlots()
        {
            if (v == null) return;
            for (int n = 1; n <= v.Length; n++)
            {
                string key = "In" + n;
                InputParams ip = null;
                bool had = inParams.TryGetValue(key, out ip);
                string text = v[n - 1];
                if (had) inParams.Remove(key);
                if (ip == null && string.IsNullOrEmpty(text)) continue;
                SvSendInput row = new SvSendInput();
                row.Name = "v" + n;
                row.Key = row.Name;
                row.Text = text ?? "";
                inputs.Add(row);
                inParams[row.Name] = ip;
            }
            v = null;
        }

        public bool HasInput(string name)
        {
            foreach (SvSendInput i in inputs)
                if (string.Equals(i.Name, name, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        // ---- the table of inputs defines the inputs of the tool ----
        public string[] ListProperties { get { return new string[] { "Inputs" }; } }

        public bool SyncParams()
        {
            bool changed = false;
            List<string> used = new List<string>();
            used.Add("ConnectionLink");
            Dictionary<string, InputParams> wanted = new Dictionary<string, InputParams>();
            for (int i = 0; i < inputs.Count; i++)
            {
                SvSendInput row = inputs[i];
                string name = SvNames.Clean(row.Name);
                if (name.Length == 0)
                {
                    int k = inputs.Count;
                    do { name = "v" + (k++); } while (used.Contains(name) || HasInputExcept(name, row));
                }
                name = SvNames.Unique(name, used);
                if (name != row.Name) { row.Name = name; changed = true; }
                used.Add(name);

                InputParams link = null;
                if (!string.IsNullOrEmpty(row.Key) && inParams.TryGetValue(row.Key, out link)) { }
                else inParams.TryGetValue(name, out link);
                wanted[name] = link;
                if (row.Key != name) { row.Key = name; changed = true; }
            }
            List<string> remove = new List<string>();
            foreach (string key in inParams.Keys)
                if (key != "ConnectionLink" && !wanted.ContainsKey(key)) remove.Add(key);
            foreach (string key in remove) { inParams.Remove(key); changed = true; }
            foreach (KeyValuePair<string, InputParams> kv in wanted)
            {
                InputParams cur;
                if (!inParams.TryGetValue(kv.Key, out cur) || !object.ReferenceEquals(cur, kv.Value))
                {
                    inParams[kv.Key] = kv.Value;
                    changed = true;
                }
            }
            return changed;
        }

        bool HasInputExcept(string name, SvSendInput except)
        {
            foreach (SvSendInput i in inputs)
                if (!object.ReferenceEquals(i, except) && string.Equals(i.Name, name, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        /// <summary>The value of the input: the output linked to it when there is one, otherwise the text typed in the table (a number stays a number).</summary>
        public bool TryGetValue(string name, out object value)
        {
            value = null;
            foreach (SvSendInput row in inputs)
            {
                if (!string.Equals(row.Name, name, StringComparison.OrdinalIgnoreCase)) continue;
                if (SvLoose.IsLinked(this, row.Name))
                {
                    value = SvLoose.Read(this, row.Name);
                    return value != null;
                }
                string text = row.Text;
                if (string.IsNullOrEmpty(text)) return false;
                double d;
                if (double.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out d)) value = d;
                else value = text;
                return true;
            }
            return false;
        }

        /// <summary>The message as a Text channel (so that the same code sends it), or null when no message is set.</summary>
        public SvSendChannel QuickChannel()
        {
            if (string.IsNullOrEmpty(message)) return null;
            SvSendChannel ch = new SvSendChannel();
            ch.Name = "Message";
            ch.Kind = SvSendKind.Text;
            ch.Connection = ConnectionName;
            ch.Template = message;
            ch.Condition = messageWhen;
            return ch;
        }

        public override void GetInParams()
        {
            // nothing to copy: the values are read when they are sent (TryGetValue)
        }


        public List<SvSendChannel> Channels
        {
            get { return channels; }
        }

        /// <summary>Compute and log what would be sent, but do not write anything to the PLC / robot.</summary>
        public bool DryRun { get { return dryRun; } set { dryRun = value; NotifyPropertyChanged("DryRun"); } }

        /// <summary>Returns an empty string when the settings are usable, otherwise a message.</summary>
        public string Validate()
        {
            if (!string.IsNullOrEmpty(message) && string.IsNullOrEmpty(ConnectionName)) return "Message: no connection (type its name or link ConnectionLink)";
            HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (SvSendInput i in inputs) if (!names.Add(i.Name)) return "Input name '" + i.Name + "' is used twice";
            for (int c = 0; c < channels.Count; c++)
            {
                SvSendChannel ch = channels[c];
                if (!ch.Enabled) continue;
                string who = string.Format("Channel '{0}': ", ch.Name);
                if (ch.Kind == SvSendKind.Position)
                {
                    if (ch.Fields.Count == 0 || ch.Fields.Count % 3 != 0) return who + "Position needs fields in groups of 3 (x, y, t)";
                    if (ch.StartIndex < 0) return who + "start index is not set";
                }
                if (ch.Kind == SvSendKind.Values)
                {
                    if (ch.Fields.Count == 0) return who + "no fields";
                    if (ch.StartIndex < 0) return who + "start index is not set";
                    HashSet<int> used = new HashSet<int>();
                    foreach (SvSendField f in ch.Fields)
                    {
                        if (!used.Add(f.Address)) return who + "address " + f.Address + " is used twice";
                    }
                }
                if (ch.Kind == SvSendKind.Text)
                {
                    if (string.IsNullOrEmpty(ch.Connection)) return who + "no connection name";
                    if (string.IsNullOrEmpty(ch.Template)) return who + "the template is empty";
                }
                if (ch.Kind == SvSendKind.Registers)
                {
                    if (string.IsNullOrEmpty(ch.Connection)) return who + "no connection name";
                    if (ch.Fields.Count == 0) return who + "no fields";
                    if (ch.StartIndex < 0) return who + "start index (first register) is not set";
                    HashSet<int> regs = new HashSet<int>();
                    foreach (SvSendField f in ch.Fields)
                    {
                        if (f.ValueType == SvSendValueType.Text) return who + "field '" + f.Name + "': Text cannot be written to registers";
                        int width = (f.ValueType == SvSendValueType.Int16) ? 1 : 2;
                        for (int k = 0; k < width; k++)
                        {
                            if (!regs.Add(f.Address + k)) return who + "register " + (f.Address + k) + " is used twice (field '" + f.Name + "')";
                        }
                    }
                }
                foreach (SvSendField f in ch.Fields)
                {
                    if (string.IsNullOrEmpty(f.Source)) return who + "field '" + f.Name + "' has no source";
                    if (f.UseRange && f.Min > f.Max) return who + "field '" + f.Name + "' has Min > Max";
                }
            }
            return "";
        }

        public override void InitInParmas()
        {
            inParams.Add("ConnectionLink", null);
        }
        public override void InitOutParmas()
        {
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
        }
        public override void Run(bool isEditMode = false)
        {
            // Configuration only. Always succeeds so that it never turns the job NG.
            lastRunSuccess = true;
        }
    }
}
