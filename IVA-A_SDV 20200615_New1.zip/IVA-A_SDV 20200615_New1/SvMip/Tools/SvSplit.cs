﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.Serialization;

namespace SvMip
{
    /// <summary>One output of SvSplit: the part of the text (Index, 0 = the first) and whether it is a number or a text.</summary>
    [Serializable]
    public class SvSplitPart
    {
        public SvSplitPart()
        {
            Name = "";
            Index = 0;
            IsNumber = false;
            Key = "";
        }
        public string Name { get; set; }
        public int Index { get; set; }
        /// <summary>true = the output is a number (0 when the part is not a number), false = the text.</summary>
        public bool IsNumber { get; set; }
        /// <summary>The name that outParams uses.</summary>
        public string Key { get; set; }
    }

    /// <summary>
    /// Splits a text into its parts (e.g. the message of the robot "HE,123.4,56.7,0"). The outputs are defined by the user in the
    /// edit form (Parts: a name, the position of the part and text / number); Count is the number of parts found.
    /// The text comes from the linked Source input, or from SourcePath (default @request).
    /// </summary>
    [Serializable]
    public class SvSplit : SvToolBase, ISvContextTool, ISvDynamicParams
    {
        string sourcePath = "@request";
        string separator = ",";
        bool trim = true;
        List<SvSplitPart> parts;

        [NonSerialized]
        IList<SvToolBase> context;
        [NonSerialized]
        object source;
        [NonSerialized]
        string error = "";
        [NonSerialized]
        int count;

        public SvSplit()
        {
            parts = DefaultParts();
            SyncParams();
        }
        public SvSplit(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            SvLoose.Ensure(this, "Source");
            if (parts == null) parts = DefaultParts();
            SyncParams();
        }

        static List<SvSplitPart> DefaultParts()
        {
            List<SvSplitPart> list = new List<SvSplitPart>();
            list.Add(new SvSplitPart { Name = "Command", Index = 0, IsNumber = false });
            list.Add(new SvSplitPart { Name = "Num1", Index = 1, IsNumber = true });
            list.Add(new SvSplitPart { Name = "Num2", Index = 2, IsNumber = true });
            list.Add(new SvSplitPart { Name = "Num3", Index = 3, IsNumber = true });
            return list;
        }

        /// <summary>Input: the text to split (any output; its text is used).</summary>
        public object Source { get { return source; } set { source = value; } }
        /// <summary>Used when no output is linked to Source: @request, @request[2], Tool.Output ...</summary>
        public string SourcePath { get { return sourcePath; } set { sourcePath = value; NotifyPropertyChanged("SourcePath"); } }
        /// <summary>Characters that separate the parts, e.g. "," or ";" or ",;" (any of them).</summary>
        public string Separator { get { return separator; } set { separator = value; NotifyPropertyChanged("Separator"); } }
        public bool Trim { get { return trim; } set { trim = value; NotifyPropertyChanged("Trim"); } }
        public string Error { get { return error; } }
        /// <summary>The outputs (added in the edit form).</summary>
        public List<SvSplitPart> Parts { get { return parts; } }

        [OutputParam]
        public int Count { get { return count; } set { count = value; } }

        public void SetContext(IList<SvToolBase> tools)
        {
            context = tools;
        }

        public override void GetInParams()
        {
            source = SvLoose.Read(this, "Source");
        }

        // ---- the table of parts defines the outputs of the tool ----
        public string[] ListProperties { get { return new string[] { "Parts" }; } }

        public bool SyncParams()
        {
            bool changed = false;
            List<string> used = new List<string>();
            used.Add("Count");
            List<string> keys = new List<string>();
            for (int i = 0; i < parts.Count; i++)
            {
                SvSplitPart p = parts[i];
                string name = SvNames.Clean(p.Name);
                if (name.Length == 0) name = "Part" + (i + 1);
                name = SvNames.Unique(name, used);
                if (name != p.Name) { p.Name = name; changed = true; }
                used.Add(name);
                keys.Add(name);
                p.Key = name;
            }
            List<string> remove = new List<string>();
            foreach (string key in outParams.Keys)
                if (key != "Count" && !keys.Contains(key)) remove.Add(key);
            foreach (string key in remove) { outParams.Remove(key); changed = true; }
            for (int i = 0; i < parts.Count; i++)
            {
                // a typed default (0 or "") so that the link panel knows whether the output is a number or a text
                object seed = parts[i].IsNumber ? (object)0.0 : "";
                object now;
                if (!outParams.TryGetValue(parts[i].Key, out now)) { outParams[parts[i].Key] = seed; changed = true; }
                else if (now == null) outParams[parts[i].Key] = seed;
                else if (now.GetType() != seed.GetType()) { outParams[parts[i].Key] = seed; changed = true; }
            }
            if (!outParams.ContainsKey("Count")) { outParams["Count"] = null; changed = true; }
            return changed;
        }

        public string Validate()
        {
            if (string.IsNullOrEmpty(separator)) return "Separator is empty (use , or ;)";
            if (string.IsNullOrEmpty(sourcePath) && !SvLoose.IsLinked(this, "Source")) return "No source (link the Source input or type a path)";
            foreach (SvSplitPart p in parts)
                if (p.Index < 0) return "Output '" + p.Name + "': the position must not be negative";
            return "";
        }

        public override void InitInParmas()
        {
            inParams.Add("Source", null);
        }
        public override void InitOutParmas()
        {
            outParams.Add("Count", null);
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            error = "";
            Fill(new string[0]);
        }

        void Fill(string[] items)
        {
            Count = items.Length;
            foreach (SvSplitPart p in parts)
            {
                string t = (p.Index >= 0 && p.Index < items.Length) ? items[p.Index] : "";
                double d = 0;
                if (p.IsNumber)
                {
                    if (!double.TryParse(t, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) d = 0;
                    outParams[p.Key] = d;
                }
                else outParams[p.Key] = t;
            }
        }

        public override void Run(bool isEditMode = false)
        {
            error = "";
            string text = null;
            if (SvLoose.IsLinked(this, "Source"))
            {
                object v = SvLoose.Read(this, "Source");
                if (v == null) { error = "the linked input '" + SvLoose.LinkText(this, "Source") + "' has no value"; Fill(new string[0]); lastRunSuccess = false; return; }
                text = Convert.ToString(v, CultureInfo.InvariantCulture) ?? "";
            }
            else
            {
                if (string.IsNullOrEmpty(sourcePath) || context == null) { error = "no source"; Fill(new string[0]); lastRunSuccess = false; return; }
                object v;
                if (!SvPathResolver.TryGetToolValue(context, sourcePath, out v, out error))
                {
                    // editing the job without a request from the robot: nothing to split, not an error
                    if (sourcePath.TrimStart().StartsWith("@") && !SvRuntime.HasRequest) { error = ""; Fill(new string[0]); lastRunSuccess = true; return; }
                    Fill(new string[0]);
                    lastRunSuccess = false;
                    return;
                }
                text = Convert.ToString(v, CultureInfo.InvariantCulture) ?? "";
            }

            string sep = string.IsNullOrEmpty(separator) ? "," : separator;
            string[] items = text.Split(sep.ToCharArray());
            if (trim) for (int i = 0; i < items.Length; i++) items[i] = items[i].Trim();
            Fill(items);
            lastRunSuccess = true;
        }
    }
}
