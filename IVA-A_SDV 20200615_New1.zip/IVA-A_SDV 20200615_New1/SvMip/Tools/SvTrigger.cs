﻿using System;
using System.Runtime.Serialization;

namespace SvMip
{
    /// <summary>Where the start request of the cycle comes from.</summary>
    public enum SvTriggerMode
    {
        /// <summary>PLC / IO bits (Start, Complete ...), as before.</summary>
        Io,
        /// <summary>A text message received on a TCP / serial / UDP connection; the reply is sent on the same connection.</summary>
        Tcp
    }

    /// <summary>
    /// Configuration-only tool: declares the handshake signals of the process that runs this job
    /// (Start / Complete in, Ready / AcqComp / OK / NG ... out) and the PLC data areas.
    /// All addresses use -1 for "not used". The presence of this tool selects AutoThread_Direct.
    /// </summary>
    [Serializable]
    public class SvTrigger : SvToolBase
    {
        // inputs
        int startAddr = -1;
        int completeAddr = -1;
        // outputs
        int readyAddr = -1;
        int acqCompAddr = -1;
        int okAddr = -1;
        int ngAddr = -1;
        int ok2Addr = -1;
        int ng2Addr = -1;
        int inspNgAddr = -1;
        int inspNg2Addr = -1;
        // data areas (legacy layout, used until SvSend takes over)
        int offsetStartAddress = -1;
        int inspectStartAddress = -1;
        int cellIdAddress = -1;
        int fdcStartAddress = -1;
        // options
        bool dualJudge = false;
        bool useAcqComp = false;
        bool inspReverse = false;
        bool autoStart = false;
        // request - response trigger (Tcp mode)
        SvTriggerMode triggerMode = SvTriggerMode.Io;
        string triggerConnection = "";
        string startCommand = "";
        string terminator = "\\r\\n";
        string replyOk = "";
        string replyNg = "";
        string separator = ",";
        string alignCommands = "";
        string replyUnknown = "";

        public SvTrigger()
        {
        }
        public SvTrigger(SerializationInfo info, StreamingContext context) : base(info, context)
        {
            SvLoose.Ensure(this, "ConnectionLink");
        }

        /// <summary>Input: link it to the Connection output of an SvConnection instead of typing the name.</summary>
        [InputParam]
        public string ConnectionLink { get { return connectionLink; } set { connectionLink = value; } }
        [NonSerialized]
        string connectionLink;

        /// <summary>The connection that carries the messages: the linked SvConnection, otherwise the typed name.</summary>
        public string ConnectionName
        {
            get
            {
                SvConnection c = SvLoose.LinkedTool(this, "ConnectionLink") as SvConnection;
                return c != null ? c.ConnName : triggerConnection;
            }
        }

        public override void GetInParams()
        {
            // nothing to copy: the connection is read when it is used (ConnectionName)
        }

        public int StartAddr { get { return startAddr; } set { startAddr = value; NotifyPropertyChanged("StartAddr"); } }
        public int CompleteAddr { get { return completeAddr; } set { completeAddr = value; NotifyPropertyChanged("CompleteAddr"); } }
        public int ReadyAddr { get { return readyAddr; } set { readyAddr = value; NotifyPropertyChanged("ReadyAddr"); } }
        public int AcqCompAddr { get { return acqCompAddr; } set { acqCompAddr = value; NotifyPropertyChanged("AcqCompAddr"); } }
        public int OkAddr { get { return okAddr; } set { okAddr = value; NotifyPropertyChanged("OkAddr"); } }
        public int NgAddr { get { return ngAddr; } set { ngAddr = value; NotifyPropertyChanged("NgAddr"); } }
        public int Ok2Addr { get { return ok2Addr; } set { ok2Addr = value; NotifyPropertyChanged("Ok2Addr"); } }
        public int Ng2Addr { get { return ng2Addr; } set { ng2Addr = value; NotifyPropertyChanged("Ng2Addr"); } }
        public int InspNgAddr { get { return inspNgAddr; } set { inspNgAddr = value; NotifyPropertyChanged("InspNgAddr"); } }
        public int InspNg2Addr { get { return inspNg2Addr; } set { inspNg2Addr = value; NotifyPropertyChanged("InspNg2Addr"); } }

        public int OffsetStartAddress { get { return offsetStartAddress; } set { offsetStartAddress = value; NotifyPropertyChanged("OffsetStartAddress"); } }
        public int InspectStartAddress { get { return inspectStartAddress; } set { inspectStartAddress = value; NotifyPropertyChanged("InspectStartAddress"); } }
        public int CellIdAddress { get { return cellIdAddress; } set { cellIdAddress = value; NotifyPropertyChanged("CellIdAddress"); } }
        public int FdcStartAddress { get { return fdcStartAddress; } set { fdcStartAddress = value; NotifyPropertyChanged("FdcStartAddress"); } }

        public bool DualJudge { get { return dualJudge; } set { dualJudge = value; NotifyPropertyChanged("DualJudge"); } }
        public bool UseAcqComp { get { return useAcqComp; } set { useAcqComp = value; NotifyPropertyChanged("UseAcqComp"); } }
        public bool InspReverse { get { return inspReverse; } set { inspReverse = value; NotifyPropertyChanged("InspReverse"); } }
        /// <summary>When the job is saved and Auto is opened, Auto is started automatically (writes to the PLC / robot!).</summary>
        public bool AutoStart { get { return autoStart; } set { autoStart = value; NotifyPropertyChanged("AutoStart"); } }

        /// <summary>Io = PLC bits, Tcp = a text message starts the cycle and the reply is sent back.</summary>
        public SvTriggerMode TriggerMode { get { return triggerMode; } set { triggerMode = value; NotifyPropertyChanged("TriggerMode"); } }
        /// <summary>Name of the SvConnection (TcpServer / TcpClient / Udp / Serial) that carries the messages.</summary>
        public string TriggerConnection { get { return triggerConnection; } set { triggerConnection = value; NotifyPropertyChanged("TriggerConnection"); } }
        /// <summary>Characters that split a message into parts, e.g. "," or ";" or ",;" (any of them). Part 0 is the command: @cmd, @request[1] ... are the others.</summary>
        public string Separator { get { return separator; } set { separator = value; NotifyPropertyChanged("Separator"); } }
        /// <summary>Commands (separated by |) that run the align and the SvSend of the job, e.g. XT. Empty = every command does. The others only run the job (and the tools it holds: SvHandEye, SvMaster ...).</summary>
        public string AlignCommands { get { return alignCommands; } set { alignCommands = value; NotifyPropertyChanged("AlignCommands"); } }
        /// <summary>Sent when a message does not start with one of the start commands. Empty = nothing is sent.</summary>
        public string ReplyUnknown { get { return replyUnknown; } set { replyUnknown = value; NotifyPropertyChanged("ReplyUnknown"); } }
        /// <summary>A message starts the cycle when it begins with one of these commands (case-insensitive); several commands are separated by |, e.g. XT|HEB|HE|HEE|MS. Empty = any message.</summary>
        public string StartCommand { get { return startCommand; } set { startCommand = value; NotifyPropertyChanged("StartCommand"); } }
        /// <summary>End of a message, e.g. \r\n (escapes \r \n \t \\ are understood). Empty = every received block is one message.</summary>
        public string Terminator { get { return terminator; } set { terminator = value; NotifyPropertyChanged("Terminator"); } }
        /// <summary>Reply when the cycle is OK. Template like SvSend Text: {judge} {request} {time} {cellid} {a0x:F3} {a0y:F3} {a0t:F3} {a1x}...  Empty = no automatic reply.</summary>
        public string ReplyOk { get { return replyOk; } set { replyOk = value; NotifyPropertyChanged("ReplyOk"); } }
        /// <summary>Reply when the cycle is NG (same placeholders as ReplyOk).</summary>
        public string ReplyNg { get { return replyNg; } set { replyNg = value; NotifyPropertyChanged("ReplyNg"); } }

        /// <summary>Returns an empty string when the settings are usable, otherwise a message.</summary>
        /// <summary>True when the command takes the normal align / send path (see AlignCommands).</summary>
        public bool IsAlignCommand(string command)
        {
            if (string.IsNullOrEmpty(alignCommands)) return true;
            foreach (string c in alignCommands.Split('|'))
                if (string.Equals(c.Trim(), command, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        /// <summary>True when the message starts a cycle (it begins with one of the start commands).</summary>
        public bool MatchesStart(string message)
        {
            if (string.IsNullOrEmpty(startCommand)) return true;
            foreach (string c in startCommand.Split('|'))
            {
                string a = c.Trim();
                if (a.Length > 0 && message.StartsWith(a, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        public string Validate()
        {
            if (triggerMode == SvTriggerMode.Tcp)
            {
                if (string.IsNullOrEmpty(separator)) return "Separator is empty (use , or ;)";
                // the handshake bits are internal in this mode, only the connection matters
                if (string.IsNullOrEmpty(ConnectionName)) return "Trigger connection is not set (type its name or link ConnectionLink to an SvConnection)";
                return "";
            }
            if (startAddr < 0) return "Start address is not set";
            if (readyAddr < 0) return "Ready address is not set";
            if (okAddr < 0 || ngAddr < 0) return "OK / NG address is not set";
            if (dualJudge && (ok2Addr < 0 || ng2Addr < 0)) return "OK2 / NG2 address is not set (dual judge)";
            if (useAcqComp && acqCompAddr < 0) return "AcqComp address is not set";
            return "";
        }

        public override void InitInParmas()
        {
            inParams.Add("ConnectionLink", null);
        }
        public override void InitOutParmas()
        {
        }
        public override void InitImageList()
        {
        }
        public override void InitOutProperty()
        {
            lastRunSuccess = false;
        }
        public override void Run(bool isEditMode = false)
        {
            // Configuration only. Always succeeds so that it never turns the job NG.
            lastRunSuccess = true;
        }
    }
}
