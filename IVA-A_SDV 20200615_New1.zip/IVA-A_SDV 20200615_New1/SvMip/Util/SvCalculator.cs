﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Collections;
using SvMip;

namespace SvMip.Util
{
    public partial class SvCalculator : Form
    {
        public SvCalculator()
        {
            InitializeComponent();
            Find_Op["+"] = 0;
            Find_Op["-"] = 0;
            Find_Op["*"] = 1;
            Find_Op["/"] = 1;
        }

        ArrayList In_list = new ArrayList();
        Hashtable Find_Op = new Hashtable();

        string temp, op, trim, A;
        int i = 0;

        public string OldNum
        {
            set
            {
                if (string.IsNullOrEmpty(value)) return;
                double dd;
                if (double.TryParse(value, out dd))
                    tb_OldNum.Text = value;
                else
                    return;
            }
        }

        private void Calculator_Load(object sender, EventArgs e)
        {
            Result = tb_OldNum.Text;
        }

        public string Result
        {
            get; set;
        }

        #region Button Event Start
        private void btn_Clear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btn_Num_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            trim = btn.Text;

            Number();
        }

       
        private void btn_Dot_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            trim = btn.Text;

            Dot();
        }

        private void btn_Oper_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            op = btn.Text;

            Operator();
        }

        private void btn_BS_Click(object sender, EventArgs e)
        {
            Back_Space();
        }

        
        private void btn_Equal_Click(object sender, EventArgs e)
        {
            Equal();
        }

        private void btn_Apply_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tb_Result.Text))
                Result = tb_OldNum.Text;
            else
                Result = tb_Result.Text;
            this.Close();

            Btn_Equal.Focus();
        }

        private void btn_Escape_Click(object sender, EventArgs e)
        {
            Result = tb_OldNum.Text;
            this.Close();

            Btn_Equal.Focus();
        }

        #endregion Button Event End

        #region Keyboard Input Start
        private void Key_Press(object sender, KeyPressEventArgs e)        // 키보드 입력 
        {
            if (char.IsDigit(e.KeyChar))
            {
                trim = e.KeyChar.ToString();
                Number();
            }

            else /*if (e.KeyChar == '*' || e.KeyChar == '/' || e.KeyChar == '+' || e.KeyChar == '-' || e.KeyChar == '(' || e.KeyChar == ')')*/
            {
                op = e.KeyChar.ToString();

                if (e.KeyChar == '*' || e.KeyChar == '/' || e.KeyChar == '+' || e.KeyChar == '-')
                    Operator();

                else
                {
                    switch (e.KeyChar)
                    {
                        case '=':
                            Equal();
                            break;

                        case '\u001b':
                            this.Close();
                            //Clear();
                            break;

                        case '\b':
                            Back_Space();
                            break;

                        case '.':
                            trim = e.KeyChar.ToString();
                            Dot();
                            break;
                    }
                }
            }
        }
        #endregion Keyboard Input End

#region Method Start
        private void Operator()
        {
            if (temp == null)
            {
                if (In_list.Count == 0)
                {
                    In_list.Add(tb_OldNum.Text);
                    tb_Equation.Text += tb_OldNum.Text + op;
                    In_list.Add(op);
                }
                else
                    MessageBox.Show("Operator Can Not Be Duplicated.", "Warning", MessageBoxButtons.OK);
            }
            else
            {
                temp = double.Parse(temp).ToString();

                if (tb_Result.Text.Length != 0)
                {
                    tb_Equation.Text = tb_Result.Text + op;
                    tb_Result.Clear();
                }
                else
                    tb_Equation.Text += op;

                In_list.Add(temp);
                In_list.Add(op);
            }
            temp = null;
            Btn_Equal.Focus();
        }
    

        private void Equal()
        {
            A = null;
            if (temp == "0" && In_list.Count == 0)
                tb_Result.Text = "0";

            else
            {
                if (temp != null)
                {
                    In_list.Add(temp);

                    while (In_list.Count != 1)
                    {
                        i = 1;


                        if ((i < In_list.Count - 2) && ((int)Find_Op[In_list[i]] < (int)Find_Op[In_list[i + 2]]))
                            i = i + 2;

                        //In_list[i - 1] = Calculation(double.Parse((string)In_list[i - 1]), double.Parse((string)In_list[i + 1]), (string)In_list[i]).ToString();
                        double result = 0;
                        if (Calculation(double.Parse((string)In_list[i - 1]), double.Parse((string)In_list[i + 1]), (string)In_list[i], ref result) == true)
                        {
                            In_list[i - 1] = result.ToString();
                            In_list.RemoveAt(i + 1);
                            In_list.RemoveAt(i);
                        }

                        else
                        {
                            if (In_list.Count != 1)
                            {
                                In_list.RemoveAt(In_list.Count - 1);
                                A = "!";
                            }

                            break;
                        }
                    }

                    if (A != "!")
                    {
                        temp = null;

                        if (In_list[0] == null)
                            tb_Equation.Text = "0";

                        else
                        {
                            tb_Result.Text = In_list[0].ToString();
                            temp = In_list[0].ToString();
                            In_list.Clear();
                        }
                    }

                    else MessageBox.Show("You Can Not Devied 0.", "Warning", MessageBoxButtons.OK);
                }
                
                else MessageBox.Show("Input is not Correct2.", "Warning", MessageBoxButtons.OK);
            }
        }
                
        private bool Calculation(double val_1, double val_2, string opt, ref double result)          // string opt에 따른 연산
        {
            switch (opt)
            {
                case "+":
                {
                    result = val_1 + val_2;
                    return true;
                }
                    
                case "-":
                {
                    result = val_1 - val_2;
                    return true;
                }
            case "*":
                {
                    result = val_1 * val_2;
                    return true;
                }
            case "/":
                if (val_2 == 0)
                    return false;
                else
                {
                    result = val_1 / val_2;
                    return true;
                }

            default:
                    return false;
            }
        }

        private void Clear()
        {
            tb_Equation.Clear();
            tb_Result.Clear();
            In_list.Clear();
            temp = null;
            Btn_Equal.Focus();
        }

        private void Number()
        {
            if (tb_Result.Text.Length != 0)
            {
                tb_Equation.Clear();
                tb_Result.Clear();
                temp = null;
            }

            temp += trim;
            tb_Equation.Text += trim;
            Btn_Equal.Focus();
        }

        private void Dot()
        {
            if (temp != null && temp.IndexOf(".") == -1)
            {
                if (tb_Result.Text.Length != 0)
                    tb_Result.Clear();

                temp += trim;
                tb_Equation.Text += trim;
            }
            else
                MessageBox.Show("'.' can not be duplicated.", "Warning", MessageBoxButtons.OK);

            Btn_Equal.Focus();
        }

        private void Back_Space()
        {
            string str;

            if (tb_Equation.Text.Length == 0) return;

            else if (tb_Result.Text.Length != 0)
                MessageBox.Show("There is Wrong Input.", "Warning", MessageBoxButtons.OK);
                //MessageBox.Show("잘못된 입력입니다.", "Warning", MessageBoxButtons.OK);

            else if (temp != null)
            {
                temp = temp.Substring(0, temp.Length - 1);

                str = tb_Equation.Text;
                tb_Equation.Text = str.Substring(0, str.Length - 1);

                if (temp == "") temp = null;
            }

            else if (temp == "" || temp == null)
            {
                In_list.RemoveAt(In_list.Count - 1);                    // Opreator Remove

                temp = In_list[In_list.Count - 1].ToString();
                In_list.RemoveAt(In_list.Count - 1);                    // Number Remove

                str = tb_Equation.Text;
                tb_Equation.Text = str.Substring(0, str.Length - 1);
            }

            Btn_Equal.Focus();

        }
        #endregion Method End
    }
}
