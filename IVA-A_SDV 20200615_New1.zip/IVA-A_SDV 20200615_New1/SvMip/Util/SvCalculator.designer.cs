﻿namespace SvMip.Util
{
    partial class SvCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_OldNum = new System.Windows.Forms.TextBox();
            this.tb_Equation = new System.Windows.Forms.TextBox();
            this.tb_Result = new System.Windows.Forms.TextBox();
            this.btn_Applay = new System.Windows.Forms.Button();
            this.btn_ESC = new System.Windows.Forms.Button();
            this.lbl_Old = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Btn_Equal = new System.Windows.Forms.Button();
            this.Btn_Minus = new System.Windows.Forms.Button();
            this.Btn_Divide = new System.Windows.Forms.Button();
            this.Btn_Dot = new System.Windows.Forms.Button();
            this.Btn_9 = new System.Windows.Forms.Button();
            this.Btn_0 = new System.Windows.Forms.Button();
            this.Btn_Plus = new System.Windows.Forms.Button();
            this.Btn_8 = new System.Windows.Forms.Button();
            this.Btn_6 = new System.Windows.Forms.Button();
            this.Btn_Multy = new System.Windows.Forms.Button();
            this.Btn_Backspace = new System.Windows.Forms.Button();
            this.Btn_Clear = new System.Windows.Forms.Button();
            this.Btn_5 = new System.Windows.Forms.Button();
            this.Btn_3 = new System.Windows.Forms.Button();
            this.Btn_7 = new System.Windows.Forms.Button();
            this.Btn_2 = new System.Windows.Forms.Button();
            this.Btn_4 = new System.Windows.Forms.Button();
            this.Btn_1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_OldNum
            // 
            this.tb_OldNum.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb_OldNum.Location = new System.Drawing.Point(83, 12);
            this.tb_OldNum.Name = "tb_OldNum";
            this.tb_OldNum.Size = new System.Drawing.Size(181, 29);
            this.tb_OldNum.TabIndex = 1;
            this.tb_OldNum.TabStop = false;
            this.tb_OldNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_Equation
            // 
            this.tb_Equation.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb_Equation.Location = new System.Drawing.Point(83, 39);
            this.tb_Equation.Multiline = true;
            this.tb_Equation.Name = "tb_Equation";
            this.tb_Equation.Size = new System.Drawing.Size(181, 37);
            this.tb_Equation.TabIndex = 0;
            this.tb_Equation.TabStop = false;
            this.tb_Equation.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tb_Equation.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // tb_Result
            // 
            this.tb_Result.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb_Result.Location = new System.Drawing.Point(83, 82);
            this.tb_Result.Name = "tb_Result";
            this.tb_Result.Size = new System.Drawing.Size(181, 29);
            this.tb_Result.TabIndex = 1;
            this.tb_Result.TabStop = false;
            this.tb_Result.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_Applay
            // 
            this.btn_Applay.BackColor = System.Drawing.Color.Aqua;
            this.btn_Applay.Font = new System.Drawing.Font("굴림", 11F);
            this.btn_Applay.Location = new System.Drawing.Point(15, 437);
            this.btn_Applay.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Applay.Name = "btn_Applay";
            this.btn_Applay.Size = new System.Drawing.Size(249, 40);
            this.btn_Applay.TabIndex = 0;
            this.btn_Applay.TabStop = false;
            this.btn_Applay.Text = "Apply";
            this.btn_Applay.UseVisualStyleBackColor = false;
            this.btn_Applay.Click += new System.EventHandler(this.btn_Apply_Click);
            // 
            // btn_ESC
            // 
            this.btn_ESC.BackColor = System.Drawing.Color.LightCoral;
            this.btn_ESC.Font = new System.Drawing.Font("굴림", 11F);
            this.btn_ESC.Location = new System.Drawing.Point(15, 393);
            this.btn_ESC.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ESC.Name = "btn_ESC";
            this.btn_ESC.Size = new System.Drawing.Size(249, 40);
            this.btn_ESC.TabIndex = 0;
            this.btn_ESC.TabStop = false;
            this.btn_ESC.Text = "Escape";
            this.btn_ESC.UseVisualStyleBackColor = false;
            this.btn_ESC.Click += new System.EventHandler(this.btn_Escape_Click);
            this.btn_ESC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // lbl_Old
            // 
            this.lbl_Old.AutoSize = true;
            this.lbl_Old.Location = new System.Drawing.Point(19, 17);
            this.lbl_Old.Name = "lbl_Old";
            this.lbl_Old.Size = new System.Drawing.Size(78, 19);
            this.lbl_Old.TabIndex = 2;
            this.lbl_Old.Text = "Old Num";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Equation";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Result";
            // 
            // Btn_Equal
            // 
            this.Btn_Equal.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_Equal.Location = new System.Drawing.Point(207, 282);
            this.Btn_Equal.Name = "Btn_Equal";
            this.Btn_Equal.Size = new System.Drawing.Size(57, 102);
            this.Btn_Equal.TabIndex = 76;
            this.Btn_Equal.TabStop = false;
            this.Btn_Equal.Text = "=";
            this.Btn_Equal.UseVisualStyleBackColor = true;
            this.Btn_Equal.Click += new System.EventHandler(this.btn_Equal_Click);
            this.Btn_Equal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_Minus
            // 
            this.Btn_Minus.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_Minus.Location = new System.Drawing.Point(206, 228);
            this.Btn_Minus.Name = "Btn_Minus";
            this.Btn_Minus.Size = new System.Drawing.Size(57, 48);
            this.Btn_Minus.TabIndex = 77;
            this.Btn_Minus.TabStop = false;
            this.Btn_Minus.Text = "-";
            this.Btn_Minus.UseVisualStyleBackColor = true;
            this.Btn_Minus.Click += new System.EventHandler(this.btn_Oper_Click);
            this.Btn_Minus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_Divide
            // 
            this.Btn_Divide.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_Divide.Location = new System.Drawing.Point(143, 120);
            this.Btn_Divide.Name = "Btn_Divide";
            this.Btn_Divide.Size = new System.Drawing.Size(57, 48);
            this.Btn_Divide.TabIndex = 72;
            this.Btn_Divide.TabStop = false;
            this.Btn_Divide.Text = "/";
            this.Btn_Divide.UseVisualStyleBackColor = true;
            this.Btn_Divide.Click += new System.EventHandler(this.btn_Oper_Click);
            this.Btn_Divide.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_Dot
            // 
            this.Btn_Dot.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_Dot.Location = new System.Drawing.Point(143, 336);
            this.Btn_Dot.Name = "Btn_Dot";
            this.Btn_Dot.Size = new System.Drawing.Size(57, 48);
            this.Btn_Dot.TabIndex = 75;
            this.Btn_Dot.TabStop = false;
            this.Btn_Dot.Text = ".";
            this.Btn_Dot.UseVisualStyleBackColor = true;
            this.Btn_Dot.Click += new System.EventHandler(this.btn_Dot_Click);
            this.Btn_Dot.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_9
            // 
            this.Btn_9.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_9.Location = new System.Drawing.Point(143, 282);
            this.Btn_9.Name = "Btn_9";
            this.Btn_9.Size = new System.Drawing.Size(57, 48);
            this.Btn_9.TabIndex = 74;
            this.Btn_9.TabStop = false;
            this.Btn_9.Text = "9";
            this.Btn_9.UseVisualStyleBackColor = true;
            this.Btn_9.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_9.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_0
            // 
            this.Btn_0.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_0.Location = new System.Drawing.Point(17, 336);
            this.Btn_0.Name = "Btn_0";
            this.Btn_0.Size = new System.Drawing.Size(120, 48);
            this.Btn_0.TabIndex = 80;
            this.Btn_0.TabStop = false;
            this.Btn_0.Text = "0";
            this.Btn_0.UseVisualStyleBackColor = true;
            this.Btn_0.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_Plus
            // 
            this.Btn_Plus.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_Plus.Location = new System.Drawing.Point(206, 174);
            this.Btn_Plus.Name = "Btn_Plus";
            this.Btn_Plus.Size = new System.Drawing.Size(57, 48);
            this.Btn_Plus.TabIndex = 81;
            this.Btn_Plus.TabStop = false;
            this.Btn_Plus.Text = "+";
            this.Btn_Plus.UseVisualStyleBackColor = true;
            this.Btn_Plus.Click += new System.EventHandler(this.btn_Oper_Click);
            this.Btn_Plus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_8
            // 
            this.Btn_8.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_8.Location = new System.Drawing.Point(80, 282);
            this.Btn_8.Name = "Btn_8";
            this.Btn_8.Size = new System.Drawing.Size(57, 48);
            this.Btn_8.TabIndex = 78;
            this.Btn_8.TabStop = false;
            this.Btn_8.Text = "8";
            this.Btn_8.UseVisualStyleBackColor = true;
            this.Btn_8.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_6
            // 
            this.Btn_6.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_6.Location = new System.Drawing.Point(143, 228);
            this.Btn_6.Name = "Btn_6";
            this.Btn_6.Size = new System.Drawing.Size(57, 48);
            this.Btn_6.TabIndex = 79;
            this.Btn_6.TabStop = false;
            this.Btn_6.Text = "6";
            this.Btn_6.UseVisualStyleBackColor = true;
            this.Btn_6.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_Multy
            // 
            this.Btn_Multy.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_Multy.Location = new System.Drawing.Point(206, 120);
            this.Btn_Multy.Name = "Btn_Multy";
            this.Btn_Multy.Size = new System.Drawing.Size(57, 48);
            this.Btn_Multy.TabIndex = 70;
            this.Btn_Multy.TabStop = false;
            this.Btn_Multy.Text = "*";
            this.Btn_Multy.UseVisualStyleBackColor = true;
            this.Btn_Multy.Click += new System.EventHandler(this.btn_Oper_Click);
            this.Btn_Multy.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_Backspace
            // 
            this.Btn_Backspace.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_Backspace.Location = new System.Drawing.Point(80, 120);
            this.Btn_Backspace.Name = "Btn_Backspace";
            this.Btn_Backspace.Size = new System.Drawing.Size(57, 48);
            this.Btn_Backspace.TabIndex = 64;
            this.Btn_Backspace.TabStop = false;
            this.Btn_Backspace.Text = "←";
            this.Btn_Backspace.UseVisualStyleBackColor = true;
            this.Btn_Backspace.Click += new System.EventHandler(this.btn_BS_Click);
            this.Btn_Backspace.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_Clear
            // 
            this.Btn_Clear.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_Clear.Location = new System.Drawing.Point(17, 120);
            this.Btn_Clear.Name = "Btn_Clear";
            this.Btn_Clear.Size = new System.Drawing.Size(57, 48);
            this.Btn_Clear.TabIndex = 65;
            this.Btn_Clear.TabStop = false;
            this.Btn_Clear.Text = "CE";
            this.Btn_Clear.UseVisualStyleBackColor = true;
            this.Btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            this.Btn_Clear.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_5
            // 
            this.Btn_5.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_5.Location = new System.Drawing.Point(80, 228);
            this.Btn_5.Name = "Btn_5";
            this.Btn_5.Size = new System.Drawing.Size(57, 48);
            this.Btn_5.TabIndex = 62;
            this.Btn_5.TabStop = false;
            this.Btn_5.Text = "5";
            this.Btn_5.UseVisualStyleBackColor = true;
            this.Btn_5.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_3
            // 
            this.Btn_3.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_3.Location = new System.Drawing.Point(143, 174);
            this.Btn_3.Name = "Btn_3";
            this.Btn_3.Size = new System.Drawing.Size(57, 48);
            this.Btn_3.TabIndex = 63;
            this.Btn_3.TabStop = false;
            this.Btn_3.Text = "3";
            this.Btn_3.UseVisualStyleBackColor = true;
            this.Btn_3.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_7
            // 
            this.Btn_7.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_7.Location = new System.Drawing.Point(17, 282);
            this.Btn_7.Name = "Btn_7";
            this.Btn_7.Size = new System.Drawing.Size(57, 48);
            this.Btn_7.TabIndex = 68;
            this.Btn_7.TabStop = false;
            this.Btn_7.Text = "7";
            this.Btn_7.UseVisualStyleBackColor = true;
            this.Btn_7.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_7.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_2
            // 
            this.Btn_2.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_2.Location = new System.Drawing.Point(80, 174);
            this.Btn_2.Name = "Btn_2";
            this.Btn_2.Size = new System.Drawing.Size(57, 48);
            this.Btn_2.TabIndex = 69;
            this.Btn_2.TabStop = false;
            this.Btn_2.Text = "2";
            this.Btn_2.UseVisualStyleBackColor = true;
            this.Btn_2.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_4
            // 
            this.Btn_4.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_4.Location = new System.Drawing.Point(17, 228);
            this.Btn_4.Name = "Btn_4";
            this.Btn_4.Size = new System.Drawing.Size(57, 48);
            this.Btn_4.TabIndex = 66;
            this.Btn_4.TabStop = false;
            this.Btn_4.Text = "4";
            this.Btn_4.UseVisualStyleBackColor = true;
            this.Btn_4.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Btn_1
            // 
            this.Btn_1.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Btn_1.Location = new System.Drawing.Point(17, 174);
            this.Btn_1.Name = "Btn_1";
            this.Btn_1.Size = new System.Drawing.Size(57, 48);
            this.Btn_1.TabIndex = 67;
            this.Btn_1.TabStop = false;
            this.Btn_1.Text = "1";
            this.Btn_1.UseVisualStyleBackColor = true;
            this.Btn_1.Click += new System.EventHandler(this.btn_Num_Click);
            this.Btn_1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(280, 490);
            this.Controls.Add(this.Btn_Equal);
            this.Controls.Add(this.Btn_Minus);
            this.Controls.Add(this.Btn_Divide);
            this.Controls.Add(this.Btn_Dot);
            this.Controls.Add(this.Btn_9);
            this.Controls.Add(this.Btn_0);
            this.Controls.Add(this.Btn_Plus);
            this.Controls.Add(this.Btn_8);
            this.Controls.Add(this.Btn_6);
            this.Controls.Add(this.Btn_Multy);
            this.Controls.Add(this.Btn_Backspace);
            this.Controls.Add(this.Btn_Clear);
            this.Controls.Add(this.Btn_5);
            this.Controls.Add(this.Btn_3);
            this.Controls.Add(this.Btn_7);
            this.Controls.Add(this.Btn_2);
            this.Controls.Add(this.Btn_4);
            this.Controls.Add(this.Btn_1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Old);
            this.Controls.Add(this.tb_Result);
            this.Controls.Add(this.tb_Equation);
            this.Controls.Add(this.tb_OldNum);
            this.Controls.Add(this.btn_ESC);
            this.Controls.Add(this.btn_Applay);
            this.Font = new System.Drawing.Font("굴림", 11F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Calculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Calculator_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Key_Press);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tb_OldNum;
        private System.Windows.Forms.TextBox tb_Equation;
        private System.Windows.Forms.TextBox tb_Result;
        private System.Windows.Forms.Button btn_Applay;
        private System.Windows.Forms.Button btn_ESC;
        private System.Windows.Forms.Label lbl_Old;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btn_Equal;
        private System.Windows.Forms.Button Btn_Minus;
        private System.Windows.Forms.Button Btn_Divide;
        private System.Windows.Forms.Button Btn_Dot;
        private System.Windows.Forms.Button Btn_9;
        private System.Windows.Forms.Button Btn_0;
        private System.Windows.Forms.Button Btn_Plus;
        private System.Windows.Forms.Button Btn_8;
        private System.Windows.Forms.Button Btn_6;
        private System.Windows.Forms.Button Btn_Multy;
        private System.Windows.Forms.Button Btn_Backspace;
        private System.Windows.Forms.Button Btn_Clear;
        private System.Windows.Forms.Button Btn_5;
        private System.Windows.Forms.Button Btn_3;
        private System.Windows.Forms.Button Btn_7;
        private System.Windows.Forms.Button Btn_2;
        private System.Windows.Forms.Button Btn_4;
        private System.Windows.Forms.Button Btn_1;
    }
}