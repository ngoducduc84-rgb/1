﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SvMip;

namespace SvMip.Util
{
    public partial class SvTextBox : UserControl
    {
        public SvTextBox()
        {
            InitializeComponent();
            btn_Calculator.Visible = UseCalculator;

            this.Click += delegate { textbox.Focus(); };
            this.DoubleClick += delegate { textbox.SelectAll(); };
            this.btn_Calculator.Click += btn_Calculator_Click;


            this.Load += delegate 
            { 
                SizeChange();
                if (onlyInt)
                    textbox.Text = "0";
                else if (onlyFloat)
                {
                    string text = "F" + DecimalPlaces;
                    textbox.Text = 0.ToString(text);                    
                }
            };

            
            this.SizeChanged += delegate { SizeChange(); };

            textbox.TextChanged += textbox_TextChanged;
            this.Validating += ATextBox_Validating;   
        
        }

        void btn_Calculator_Click(object sender, EventArgs e)
        {
            SvCalculator calculator = new SvCalculator();
            calculator.OldNum = this.Text;
            calculator.ShowDialog();
            this.textbox.Text = calculator.Result;
        }
               

        void ATextBox_Validating(object sender, CancelEventArgs e)
        {
            SvTextBox atb = sender as SvTextBox;

            if (onlyInt)
            {   
                int value;
                if(!int.TryParse(atb.Text, out value))
                {
                    e.Cancel = true;
                    atb.Text = "0";
                }
            }
            else if(onlyFloat)
            {
                float value;
                if (!float.TryParse(atb.Text, out value))
                {
                    e.Cancel = true;
                    value = 0f;
                }
                string text = "F" + DecimalPlaces;
                atb.Text = value.ToString(text);
            }
            else
                if (string.IsNullOrEmpty(atb.Text)) return;

        }

        int decimalPlaces = 3;

        [Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public int DecimalPlaces
        {
            get { return decimalPlaces; }
            set
            {
                decimalPlaces = value;
            }
        }


        bool onlyInt = false;
        bool onlyFloat = false;

        [Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool OnlyInt
        {
            get { return onlyInt; }
            set
            {
                onlyInt = value;
                if(onlyInt == true)
                {
                    OnlyFloat = false;                    
                }
            }
        }

        [Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool OnlyFloat
        {
            get { return onlyFloat; }
            set 
            {
                onlyFloat = value;
                if (onlyFloat == true)
                {
                    OnlyInt = false;
                }
            }
        }

        new public event EventHandler TextChanged;

        void textbox_TextChanged(object sender, EventArgs e)
        {
            if (TextChanged != null)
                this.TextChanged.Invoke(this, e);
        }

        void SizeChange()
        {
            int btnWidth = btn_Calculator.Width;
            if (!UseCalculator)
                btnWidth = 0;

            textbox.Size = new Size(this.Size.Width - btnWidth, textbox.Size.Height);
            textbox.Location = new Point((this.Size.Width - btnWidth - textbox.Size.Width) / 2, (this.Size.Height - textbox.Size.Height) / 2);
        }

        public override void ResetText()
        {
            textbox.ResetText();
        }


        public override System.Drawing.Color ForeColor
        {
            get
            {
                return base.ForeColor;
            }
            set
            {
                textbox.ForeColor = value;
                base.ForeColor = value;
            }
        }

        public override Color BackColor
        {
            get
            {
                return base.BackColor;
            }
            set
            {
                textbox.BackColor = value;
                base.BackColor = value;
            }
        }

        [Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public HorizontalAlignment TextAlign 
        { 
            get
            {
                return textbox.TextAlign;
            }
            set
            {
                textbox.TextAlign = value;
            }
        }

        [Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public override string Text
        {
            get
            {
                return textbox.Text;
            }
            set
            {
                if (onlyInt)
                {
                    int v;
                    if (!int.TryParse(value, out v))
                        textbox.Text = "0";
                    textbox.Text = value;
                }
                else if (onlyFloat)
                {
                    float v;
                    if (!float.TryParse(value, out v))
                        v = 0f;
                    string text = "F" + DecimalPlaces;
                    textbox.Text = v.ToString(text);
                }
            }
        }

        bool useCal = false;
        [Browsable(true), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool UseCalculator
        {
            get { return useCal; }
            set 
            {
                useCal = value;
                btn_Calculator.Visible = value;                
            }
        }
    }
}
