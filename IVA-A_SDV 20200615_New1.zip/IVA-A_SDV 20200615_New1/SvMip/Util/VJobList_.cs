﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcess
{
    public class VJobList : TreeView
    {
        public VJobList()
        {
            InitDrag();
            InitJob();
            InitContextMenu();
            this.NodeMouseClick += VJobList_NodeMouseClick;
            this.ShowPlusMinus = false;
            this.ShowRootLines = false;
        }

        void VJobList_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            SelectedNode = e.Node;
        }

        #region Context
        ContextMenuStrip context;
        void InitContextMenu()
        {            
            context = new System.Windows.Forms.ContextMenuStrip();
            context.Items.Add("Cancel LInk", null, delegate
            {
                BeginUpdate();
                job.ToolList[Nodes.IndexOf(GetRootNode(SelectedNode))].inParams[SelectedNode.Text] = null;
                EndUpdate();
            });

            context.Items.Add("Rename", null, delegate
            {
                TreeNode node = SelectedNode;

                RenameForm renameForm = new RenameForm();
                Point pt = this.PointToScreen(this.Location);
                renameForm.StartPosition = FormStartPosition.Manual;
                renameForm.Location = new Point(pt.X + node.Bounds.Right + 10, pt.Y + node.Bounds.Top - 50);
                if (DialogResult.OK != renameForm.ShowDialog())
                    return;

                job.ToolList[node.Index].toolName = renameForm.newName;
                node.Text = renameForm.newName;
                node.Name = node.Text;
            });

            context.Items.Add("Delete", null, delegate
            {
                DeleteNode(SelectedNode);
            });

            this.ContextMenuStrip = context;
            context.Opening += context_Opening;
                        
        }

        void context_Opening(object sender, CancelEventArgs e)
        {
            if (SelectedNode == null)
                return;

            foreach(ToolStripItem item in context.Items)
            {
                item.Visible = true;
            }
                        
            //하드코딩입니다. 이렇게 짜는거 안좋은데 나도몰라....
            if (SelectedNode.Level == 0)
                context.Items[0].Visible = false;
            if (SelectedNode.Level == 1)
            {
                context.Items[1].Visible = false;
                context.Items[2].Visible = false;
            }
        }

        #endregion

        #region NodeAction

        void AddNode(VisionTool tool)
        {
            TreeNode toolNode = new TreeNode(tool.ToString());
            toolNode.Name = tool.ToString();
            foreach (string ob in tool.GetInputParamNames())
            {
                TreeNode inputNode = new TreeNode(ob);
                inputNode.Name = ob;
                inputNode.ForeColor = Color.Red;
                toolNode.Nodes.Add(inputNode);
                this.ContextMenuStrip = context;
            }

            foreach (string ob in tool.GetOutputParamNames())
            {
                TreeNode outputNode = new TreeNode(ob);
                outputNode.Name = ob;
                outputNode.ForeColor = Color.Blue;
                toolNode.Nodes.Add(outputNode);
                this.ContextMenuStrip = context;
            }
            
            if (SelectedNode == null)
            {
                Nodes.Add(toolNode);
                if (job == null)
                {
                    job = new VisionJob();
                    job.ToolList.Clear();
                }
                job.ToolList.Add(tool);
            }
            else
            {
                int index = GetRootNode(SelectedNode).Index + 1;
                Nodes.Insert(index, toolNode);
                job.ToolList.Insert(index, tool);
            }            
        }
        
        void DeleteNode(TreeNode node)
        {
            VisionTool tool = job.ToolList[node.Index];
            job.ToolList.Remove(tool);
            tool = null;

            Nodes.Remove(node);            
        }

        TreeNode GetRootNode(TreeNode node)
        {
            if (node == null)
                return null;

            if (node.Parent == null)
                return node;
            else
                return GetRootNode(node.Parent);
        }

        #endregion

        #region Job_Init&Job_Select

        void InitJob()
        {
            Job = new VisionJob();
            this.AfterSelect += VJobList_AfterSelect;
        }

        VisionJob job;
        
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public VisionJob Job
        {            
            get { return job; }
            set
            {
                BeginUpdate();
                if (job != null && job.ToolList != null) job.ToolList.Clear();
                value.RestoreLink();
                RedrawAllNode(value);
                EndUpdate();
            }
        }

        public delegate void JobSelectHandler(object sender, VisionTool tool);
        public event JobSelectHandler JobSelect;

        void NotifyJobSelect(object sender, VisionTool tool)
        {
            if(JobSelect != null)
                JobSelect(sender, tool);
        }

        void VJobList_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode selectedRoot = GetRootNode(e.Node);
            VisionTool tool = job.ToolList[selectedRoot.Index];

            NotifyJobSelect(sender, tool);
        }

        void RedrawAllNode(VisionJob job)
        {
            Nodes.Clear();
                        
            SelectedNode = null;    //선택된 노드 초기화해야 맨땅에서부터 그려짐.

            foreach (VisionTool tool in job.ToolList)
            {
                if (tool == null) continue;
                AddNode(tool);
            }

            ExpandAll();
        }
        #endregion

        #region Drag&Drop Event
        void InitDrag()
        {
            this.AllowDrop = true;
            this.DrawMode = TreeViewDrawMode.OwnerDrawAll;
            this.ItemDrag += NTreeView_ItemDrag;
            this.DragDrop += NTreeView_DragDrop;
            this.DragEnter += NTreeView_DragEnter;
            this.DragOver += NTreeView_DragOver;
            
            InitPen();
        }

        Pen linkPen;

        void InitPen()
        {
            linkPen = new Pen(Color.Black);
            linkPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            linkPen.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;                        
        }

        protected override void OnDrawNode(DrawTreeNodeEventArgs e)
        {
            e.DrawDefault = true;
            int margin = 10;
            ExpandAll();

            foreach (TreeNode node in Nodes)
            {
                foreach (KeyValuePair<string, InputParams> param in job.ToolList[node.Index].inParams)
                {
                    InputParams dstValue = param.Value;
                    if (dstValue == null) continue;

                    string srcKey = dstValue.FieldName;
                    object srcInstance = dstValue.Instance;
                    
                    string dstKey = param.Key;
                    
                    VisionTool tool = srcInstance as VisionTool;

                    int toolIndex = job.ToolList.IndexOf(tool);
                    if (toolIndex == -1)
                    {
                        job.ToolList[node.Index].inParams[dstKey] = null;
                        return;
                    }

                    TreeNode srcNode = Nodes[toolIndex].Nodes[srcKey];
                    TreeNode dstNode = node.Nodes[dstKey];

                    int srcNodeIndex = Nodes.IndexOf(GetRootNode(srcNode));
                    int dstNodeIndex = Nodes.IndexOf(GetRootNode(dstNode));
                    
                    if (srcNodeIndex > dstNodeIndex)
                    {
                        job.ToolList[dstNodeIndex].inParams[dstKey] = null;
                        return;
                    }

                    DrawLine(e.Graphics, srcNode, dstNode, margin += 10);
                }
            }
        }

        void DrawLine(Graphics gdi, TreeNode strartNode, TreeNode endNode, int horizonWidth)
        {
            const int margin = 10;

            Point sp = strartNode.Bounds.Location + new Size(strartNode.Bounds.Width + margin, strartNode.Bounds.Height / 2);
            Point ep = endNode.Bounds.Location + new Size(endNode.Bounds.Width + margin, endNode.Bounds.Height / 2);

            Point mp1 = new Point(Math.Max(sp.X, ep.X) + horizonWidth, sp.Y);
            Point mp2 = new Point(Math.Max(sp.X, ep.X) + horizonWidth, ep.Y);

            Point[] linkLinePt = new Point[] { sp, mp1, mp2, ep };

            gdi.DrawLines(linkPen, linkLinePt);

        }

        void NTreeView_ItemDrag(object sender, ItemDragEventArgs e)
        {
            TreeNode node = e.Item as TreeNode;

            SelectedNode = node;

            if (node.Level == 0)
            {
                DoDragDrop(node, DragDropEffects.Move);
            }
            else if (node.Level == 1)
            {
                if (node.ForeColor != Color.Red)
                    DoDragDrop(node, DragDropEffects.Link);
            }
            else
                throw new Exception("노드 레벨은 0, 1이 한계. 이거 의외는 프로그래밍 에러");
        }

        void NTreeView_DragOver(object sender, DragEventArgs e)
        {
            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
            this.SelectedNode = this.GetNodeAt(ClientPoint);

            if (SelectedNode == null) return;
            int index = this.Nodes.IndexOf(GetRootNode(this.SelectedNode)) - 1;
            if (index < 0) index = 0;

            this.Nodes[index].EnsureVisible();
        }

        void NTreeView_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.AllowedEffect;

            //딱히 안씀?
            //VisionTool tool = e.Data.GetData(typeof(VisionTool)) as VisionTool;
        }

        void NTreeView_DragDrop(object sender, DragEventArgs e)
        {
            BeginUpdate();
            switch (e.Effect)
            {
                case DragDropEffects.Copy:
                    AddTool(e);
                    break;
                case DragDropEffects.Move :
                    ChangeJobOrder(e);
                    break;
                case DragDropEffects.Link:
                    LinkParameters(e);
                    break;
            }            
            EndUpdate();
        }

        void AddTool(DragEventArgs e)
        {
            string typeName = null;
            string[] formats = e.Data.GetFormats(true);
            foreach (string format in formats)
            {
                try
                {
                    if (Type.GetType(format).BaseType == typeof(VisionTool))
                    {
                        typeName = format;
                        break;
                    }
                }
                catch { continue; }
            }

            if (string.IsNullOrEmpty(typeName)) return;

            try
            {
                VisionTool tool = Activator.CreateInstance(Type.GetType(typeName)) as VisionTool;
                
                Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
                this.SelectedNode = this.GetNodeAt(ClientPoint);
                AddNode(tool);
                NotifyJobSelect(this, tool);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        void ChangeJobOrder(DragEventArgs e)
        {
            TreeNode draggedNode = e.Data.GetData(typeof(TreeNode)) as TreeNode;

            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
            SelectedNode = this.GetNodeAt(ClientPoint);

            if (SelectedNode == null) return;

            int draggedIndex = draggedNode.Index;
            VisionTool draggedTool = job.ToolList[draggedIndex];

            TreeNode selectedRoot = GetRootNode(SelectedNode);
            int selectedIndex = selectedRoot.Index;
            VisionTool selectedTool = job.ToolList[selectedIndex];

            //if (draggedIndex > selectedIndex)
            //{
            //    List<string> keyList = draggedTool.inParams.Keys.ToList<string>();
            //    foreach(string key in keyList)
            //    {
            //        draggedTool.inParams[key] = null;
            //    }
            //}

            //foreach (VisionTool tool in job.ToolList)
            //{
            //    foreach(InputParams param in tool.inParams.Values)
            //    {
            //        if (param == null) continue;
            //        if(param.Instance == draggedTool)
            //        {
                            
            //        }
            //    }
            //}

            //잡체인지 먼저 해야함
            job.ToolList.Remove(draggedTool);
            job.ToolList.Insert(selectedIndex, draggedTool);
            
            //그다음에 노드 변경
            Nodes.Remove(draggedNode);
            Nodes.Insert(selectedIndex, draggedNode);
        }

        void LinkParameters(DragEventArgs e)
        {
            TreeNode srcNode = e.Data.GetData(typeof(TreeNode)) as TreeNode;

            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
            SelectedNode = this.GetNodeAt(ClientPoint);

            if (SelectedNode == null) return;

            if (SelectedNode.ForeColor != Color.Red) return;
            if (GetRootNode(SelectedNode).Index <= GetRootNode(srcNode).Index)
                return;

            job.ToolList[SelectedNode.Parent.Index].inParams[SelectedNode.Text] = new InputParams(job.ToolList[srcNode.Parent.Index], srcNode.Text);
            job.ToolList[SelectedNode.Parent.Index].GetInParams();
        }
        #endregion

    }
}
