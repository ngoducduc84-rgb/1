﻿using Iva.Bplus.Enums;
using Iva.Bplus.Windows;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Navigation;
using System.Windows.Threading;

namespace Iva.Bplus.Designer.Debug
{
    /// <summary>
    /// App.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class App : System.Windows.Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            Iva.Bplus.Main.Designer.MainWindow mainWindow = new Iva.Bplus.Main.Designer.MainWindow();
            mainWindow.Show();      
        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);

        }

        protected override void OnExit(ExitEventArgs e)
        {
            base.OnExit(e);
        }


        protected override void OnLoadCompleted(NavigationEventArgs e)
        {
            base.OnLoadCompleted(e);
        }

        public delegate void PureCallHandler();

        [DllImport("msvcr100.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern PureCallHandler _set_purecall_handler(PureCallHandler handler);

        //private readonly IList<Window> _windows = new List<Window>();
        protected override void OnStartup(StartupEventArgs e)
        {
            PureCallHandler handler = new PureCallHandler(handle_pure_virtual_function_call);
            _set_purecall_handler(handle_pure_virtual_function_call);

            SystemFunc.SetApp(this);
            
            //System.Windows.Application app = new System.Windows.Application();
            this.Dispatcher.UnhandledException += new DispatcherUnhandledExceptionEventHandler(Dispatcher_UnhandledException);
            this.Dispatcher.UnhandledExceptionFilter += new DispatcherUnhandledExceptionFilterEventHandler(Dispatcher_UnhandledExceptionFilter);
            Iva.Bplus.Instance.Initialize();

            base.OnStartup(e);

        }

        static void handle_pure_virtual_function_call()
        {
            RaiseException(null, 0, 0, null);
        }


        private static void RaiseException(object eXCEPTION_ACCESS_VIOLATION, int v1, int v2, object nULL)
        {
            throw new NotImplementedException();
        }

        static void Dispatcher_UnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            WriteExceptionTotalLog(e.ToString());
            System.Windows.MessageBox.Show(e.ToString());
            e.Handled = true;
        }

        void Dispatcher_UnhandledExceptionFilter(object sender, DispatcherUnhandledExceptionFilterEventArgs e)
        {            
            WriteExceptionTotalLog(e.ToString());
            System.Windows.MessageBox.Show(e.ToString());
            e.RequestCatch = true;
        }

        static void WriteExceptionTotalLog(string msg)
        {
            SystemLogger.WriteExceptionLog(msg);
        }
    }
}
