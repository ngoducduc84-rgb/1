﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo1PointGet
{
    [SerializableAttribute]
    public class Algo1PointGetInputParams : InputParams
    {
        #region Input P1, P2
        public IPointResult Tar_P1 { get; set; }
        public IPointResult Tar_P2 { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion

    }
}
