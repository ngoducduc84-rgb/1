﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo1PointGet
{
    [SerializableAttribute]
    public class Algo1PointGetModelParams : AlgoParams
    {
        private AlgoParam limit1_X;
        private AlgoParam limit1_Y;
        private AlgoParam limit1_T;
        private AlgoParam limit2_X;
        private AlgoParam limit2_Y;
        private AlgoParam limit2_T;
        public AlgoParam Limit1_X { get { return limit1_X; } set { if (limit1_X == value) return; limit1_X = value; this.OnPropertyChanged(nameof(Limit1_X)); } }
        public AlgoParam Limit1_Y { get { return limit1_Y; } set { if (limit1_Y == value) return; limit1_Y = value; this.OnPropertyChanged(nameof(Limit1_Y)); } }
        public AlgoParam Limit1_T { get { return limit1_T; } set { if (limit1_T == value) return; limit1_T = value; this.OnPropertyChanged(nameof(Limit1_T)); } }
        public AlgoParam Limit2_X { get { return limit2_X; } set { if (limit2_X == value) return; limit2_X = value; this.OnPropertyChanged(nameof(Limit2_X)); } }
        public AlgoParam Limit2_Y { get { return limit2_Y; } set { if (limit2_Y == value) return; limit2_Y = value; this.OnPropertyChanged(nameof(Limit2_Y)); } }
        public AlgoParam Limit2_T { get { return limit2_T; } set { if (limit2_T == value) return; limit2_T = value; this.OnPropertyChanged(nameof(Limit2_T)); } }

        public Algo1PointGetModelParams()
        {
            Limit1_Y = new AlgoParam("Limit1_Y", "mm", typeof(double), 0.0, "Revision Offset Limit1 Y", (double)-5.0, (double)5.0);
            Limit1_X = new AlgoParam("Limit1_X", "mm", typeof(double), 0.0, "Revision Offset Limit1 X", (double)-5.0, (double)5.0);
            Limit1_T = new AlgoParam("Limit1_T", "deg", typeof(double), 0.0, "Revision Offset Limit1 T", (double)-5.0, (double)5.0);
            Limit2_X = new AlgoParam("Limit2_X", "mm", typeof(double), 0.0, "Revision Offset Limit2 X", (double)-5.0, (double)5.0);
            Limit2_Y = new AlgoParam("Limit2_Y", "mm", typeof(double), 0.0, "Revision Offset Limit2 Y", (double)-5.0, (double)5.0);
            Limit2_T = new AlgoParam("Limit2_T", "deg", typeof(double), 0.0, "Revision Offset Limit2 T", (double)-5.0, (double)5.0);
        }
        //public Algo1PointGetModelParams(double targetX, double targetY)
        //{
        //    TargetX = new AlgoParam("TargetX", "mm", typeof(double), targetX, "Target X Shift", -10.0, 10.0);
        //    TargetY = new AlgoParam("TargetY", "mm", typeof(double), targetY, "Target Y Shift", -10.0, 10.0);
        //}
    }
}
