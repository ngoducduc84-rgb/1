﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;
using OpenCvSharp;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
//using Iva.Bplus.Modules.CogDisplay;
using System.Reflection;
using Iva.Bplus.Enums;
using Cognex.VisionPro;

namespace Iva.Bplus.Modules.Algo1PointGet
{
    [SerializableAttribute]
    public class Algo1PointGetObject : AlgoObjectBase
    {
        #region [Fields]
        #region  Selected Caldata Name
        private string calData;
        private string display;
        private Flow useFlowType = Flow.Dual;
        [field: NonSerialized]
        protected DoubleFlowPLCTable doubleFlowPLCIO;
        #endregion

        #region etc
        private ThetaDirection thetaDirection = ThetaDirection.Normal;
        #endregion

        #region Align결과 관련
        XYT revAlign1 = new XYT();
        XYT revAlign2 = new XYT();   
        #endregion
        #endregion
        #region [properties]
        #region  Selected Caldata Name
        public Flow UseFlowType
        {
            get { return useFlowType; }
            set { if (useFlowType == value) return; useFlowType = value; this.OnPropertyChanged(nameof(UseFlowType)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string CalData
        {
            get { return calData; }
            set { if (calData == value) return; calData = value; this.OnPropertyChanged(nameof(CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string Display
        {
            get { return display; }
            set { if (display == value) return; display = value; this.OnPropertyChanged(nameof(Display)); }
        }



        public CalDataObject CalDataObj
        {
            get { return SystemObject_Common.GetObject(calData) as CalDataObject; }
        }
        //안쓰는것 같아서 삭제
        //public CogDisplayObject DisplayObj
        //{
        //    get { return SystemObject_Display.GetObject(display) as CogDisplayObject; }
        //}
        #endregion

        #region etc
        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign1 { get { return revAlign1; } }
        public XYT RevAlign2 { get { return revAlign2; } }
        #endregion
        #endregion

        #region[Construct]

        public Algo1PointGetObject()
            : base()
        {
            //target = new XYT();
            //Results = new MatchingRstData();

            List<string> lst = SystemObject_Device.GetEachObjectName(typeof(MitsubishiPLCObject));

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo1PointGetModelParams());
            }

            CurParams = ModelParams[SystemModel.GetCurModel()];

            //CommObj = lst.Count != 0 ? lst[0] : "";

            //successToolName = "";

        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            if (useFlowType == Flow.Single)
                return AlignCalc();
            else
                return DualAlignCalc();
        }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        #region [Dual Calc]
        private bool DualAlignCalc()
        {
            AlgoRst = new Algo1PointGetResult(); //Link 안되었을때 또는 처음 Mark 실패했을 경우 Exception 방지용

            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
            AssignPLCData_doubleFlow();
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            var Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
            var Mark_Tar2 = InputValues["Tar_P2"] as IPointResult;
            if (Mark_Tar1 == null || Mark_Tar2 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            var Chk_Tar1 = InputValues["Tar_P1"] as IClear;
            var Chk_Tar2 = InputValues["Tar_P2"] as IClear;
            if (Chk_Tar1.FindCnt == 0 && Chk_Tar2.FindCnt == 0)
            {
                // Mark Data가 Null임
                errorCode = Algo1PointGetAction.Err_Mark_NG;
                return false;
            }

            bool chkTar1 = Chk_Tar1.FindCnt == 0 ? false : true;
            bool chkTar2 = Chk_Tar2.FindCnt == 0 ? false : true;

            if (Chk_Tar1.FindCnt == 0)
                errorCode = Algo1PointGetAction.Err_Mark1_NG;
            else if (Chk_Tar2.FindCnt == 0)
                errorCode = Algo1PointGetAction.Err_Mark2_NG;
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                return false;
            }

            var Robot_Tar1 = chkTar1 ? CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y)) : new XY();
            var Robot_Tar2 = chkTar2 ? CalDataObj.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y)) : new XY();

            var refTar1_Ref = chkTar1 ? CalDataObj.GetV2R(model, new XY(Mark_Tar1.RefPoints[0].X, Mark_Tar1.RefPoints[0].Y)) : new XY();
            var refTar2_Ref = chkTar2 ? CalDataObj.GetV2R(model, new XY(Mark_Tar2.RefPoints[0].X, Mark_Tar2.RefPoints[0].Y)) : new XY();

            var Coord_Tar1 = Robot_Tar1 + CalDataObj.GetRotateCenter(model);
            var Coord_Tar2 = Robot_Tar2 + CalDataObj.GetRotateCenter(model);

            var Coord_Ref1 = refTar1_Ref + CalDataObj.GetRotateCenter(model);
            var Coord_Ref2 = refTar2_Ref + CalDataObj.GetRotateCenter(model);

            var Coord_Tar1_Rev_T = chkTar1 ? NormalizeTheta(Mark_Tar1.OutputXYT.T) - NormalizeTheta(Mark_Tar1.RefPoints[0].T) : new double();
            var Coord_Tar2_Rev_T = chkTar2 ? NormalizeTheta(Mark_Tar2.OutputXYT.T) - NormalizeTheta(Mark_Tar2.RefPoints[0].T) : new double();

            var Tar1_Rev = new XYT(Coord_Tar1.X, Coord_Tar1.Y, Coord_Tar1_Rev_T);
            var Tar2_Rev = new XYT(Coord_Tar2.X, Coord_Tar2.Y, Coord_Tar2_Rev_T);
            #endregion

            #region Model Data prepare
            //[hong] Refpoint로 TargetX,Y를 대신함
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo1PointGetModelParams;
            var limit1_X = (double)mParams.Limit1_X.Value;
            var limit1_Y = (double)mParams.Limit1_Y.Value;
            var limit1_T = (double)mParams.Limit1_T.Value;
            var limit1 = new XYT(limit1_X, limit1_Y, limit1_T);
            var limit2_X = (double)mParams.Limit2_X.Value;
            var limit2_Y = (double)mParams.Limit2_Y.Value;
            var limit2_T = (double)mParams.Limit2_T.Value;
            var limit2 = new XYT(limit2_X, limit2_Y, limit2_T);
            #endregion

            #region Calc Rev Offset
            #region Offset 적용
            // 기존 PLC Offset값 저장.
            var alignOffset1 = doubleFlowPLCIO.Offset1XYT;
            Tar1_Rev = ApplyTargetOffset(Tar1_Rev, alignOffset1);

            var alignOffset2 = doubleFlowPLCIO.Offset2XYT;
            Tar2_Rev = ApplyTargetOffset(Tar2_Rev, alignOffset2);
            #endregion

            Tar1_Rev.T = NormalizeTheta(Tar1_Rev.T);
            Tar2_Rev.T = NormalizeTheta(Tar2_Rev.T);

            //Robot Pickup Position Drift계산
            //var T1_PickPos = CalDataObj.GetRotateCenter(model) + T1_Target;
            //var T2_PickPos = CalDataObj.GetRotateCenter(model) + T2_Target;

            var T1_PickPos = /*CalDataObj.GetRotateCenter(model) + */Coord_Ref1;
            var T2_PickPos = /*CalDataObj.GetRotateCenter(model) + */Coord_Ref2;

            double DriftX1, DriftY1, DriftX2, DriftY2;
            DriftX1 = Math.Cos(Tar1_Rev.T) * T1_PickPos.X - Math.Sin(Tar1_Rev.T) * T1_PickPos.Y;
            DriftY1 = Math.Sin(Tar1_Rev.T) * T1_PickPos.X + Math.Cos(Tar1_Rev.T) * T1_PickPos.Y;

            DriftX2 = Math.Cos(Tar2_Rev.T) * T2_PickPos.X - Math.Sin(Tar2_Rev.T) * T2_PickPos.Y;
            DriftY2 = Math.Sin(Tar2_Rev.T) * T2_PickPos.X + Math.Cos(Tar2_Rev.T) * T2_PickPos.Y;

            revAlign1 = new XYT();
            revAlign2 = new XYT();

            revAlign1.X = Tar1_Rev.X - DriftX1;
            revAlign1.Y = Tar1_Rev.Y - DriftY1;
            if (ThetaDirection == ThetaDirection.Normal)
                revAlign1.T = Tar1_Rev.T / rad;
            else
                revAlign1.T = Tar1_Rev.T / rad * -1;

            revAlign2.X = Tar2_Rev.X - DriftX2;
            revAlign2.Y = Tar2_Rev.Y - DriftY2;
            if (ThetaDirection == ThetaDirection.Normal)
                revAlign2.T = Tar2_Rev.T / rad;
            else
                revAlign2.T = Tar2_Rev.T / rad * -1;
            #endregion

            revAlign1 = chkTar1 ? revAlign1 : new XYT();
            revAlign2 = chkTar2 ? revAlign2 : new XYT();

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo1PointGetResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Offset1X = Math.Round(revAlign1.X, 3),
                Offset1Y = Math.Round(revAlign1.Y, 3),
                Offset1T = Math.Round(revAlign1.T, 3),

                Offset2X = Math.Round(revAlign2.X, 3),
                Offset2Y = Math.Round(revAlign2.Y, 3),
                Offset2T = Math.Round(revAlign2.T, 3),

                Result = true,
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Confirm Result
            if (!ConfirmResult(revAlign1, limit1, 1) || !ConfirmResult(revAlign2, limit2, 2))
                return false;
            #endregion

            //#region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, revUnload, sourceID);
            //#endregion
            return errorCode == 0 ? true : false;

        }
        #endregion
        #region [Single Calc]
        private bool AlignCalc()
        {
            AlgoRst = new Algo1PointGetResult(); //Link 안되었을때 또는 처음 Mark 실패했을 경우 Exception 방지용

            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
            AssignPLCData_doubleFlow();
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Tar_P1"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            var Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
            if (Mark_Tar1 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            var Chk_Tar1 = InputValues["Tar_P1"] as IClear;
            if (Chk_Tar1.FindCnt == 0)
            {
                errorCode = Algo1PointGetAction.Err_PMAlignProperty_NG;
                return false;
            }
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                return false;
            }
            var Robot_Tar1 = CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));
            var refTar1_Ref = CalDataObj.GetV2R(model, new XY(Mark_Tar1.RefPoints[0].X, Mark_Tar1.RefPoints[0].Y));

            var Coord_Tar1 = Robot_Tar1 + CalDataObj.GetRotateCenter(model);
            //var Coord_Tar1_T = NormalizeTheta(Mark_Tar1.OutputXYT.T);
            var Coord_Ref1 = refTar1_Ref + CalDataObj.GetRotateCenter(model);
            var Coord_Tar1_Rev_T = NormalizeTheta(Mark_Tar1.OutputXYT.T) - NormalizeTheta(Mark_Tar1.RefPoints[0].T);

            var Tar1_Rev = new XYT(Coord_Tar1.X, Coord_Tar1.Y, Coord_Tar1_Rev_T);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo1PointGetModelParams;

            if (mParams.Limit1_X == null) 
                mParams.Limit1_X = new AlgoParam("Limit1_Y", "mm", typeof(double), 0.0, "Revision Offset Limit1 Y", (double)-5.0, (double)5.0);
            if (mParams.Limit1_Y == null) 
                mParams.Limit1_Y = new AlgoParam("Limit1_X", "mm", typeof(double), 0.0, "Revision Offset Limit1 X", (double)-5.0, (double)5.0);
            if (mParams.Limit1_T == null) 
                mParams.Limit1_T = new AlgoParam("Limit1_T", "deg", typeof(double), 0.0, "Revision Offset Limit1 T", (double)-5.0, (double)5.0);

            var limit1_X = (double)mParams.Limit1_X.Value;
            var limit1_Y = (double)mParams.Limit1_Y.Value;
            var limit1_T = (double)mParams.Limit1_T.Value;
            var limit1 = new XYT(limit1_X, limit1_Y, limit1_T);
            #endregion

            #region Calc Rev Offset
            #region Offset 적용
            // 기존 PLC Offset값 저장.
            var alignOffset1 = doubleFlowPLCIO.Offset1XYT;
            Tar1_Rev = ApplyTargetOffset(Tar1_Rev, alignOffset1);
            #endregion

            revAlign1 = new XYT();

            //Robot Pickup Position Drift계산
            var T1_PickPos = /*CalDataObj.GetRotateCenter(model) +*/ Coord_Ref1;

            double DriftX1, DriftY1;
            DriftX1 = Math.Cos(Tar1_Rev.T) * T1_PickPos.X - Math.Sin(Tar1_Rev.T) * T1_PickPos.Y;
            DriftY1 = Math.Sin(Tar1_Rev.T) * T1_PickPos.X + Math.Cos(Tar1_Rev.T) * T1_PickPos.Y;

            revAlign1.X = Tar1_Rev.X - DriftX1;
            revAlign1.Y = Tar1_Rev.Y - DriftY1;
            if (ThetaDirection == ThetaDirection.Normal)
                revAlign1.T = Tar1_Rev.T / rad;
            else
                revAlign1.T = Tar1_Rev.T / rad * -1;

            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo1PointGetResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Offset1X = Math.Round(revAlign1.X, 3),
                Offset1Y = Math.Round(revAlign1.Y, 3),
                Offset1T = Math.Round(revAlign1.T, 3),

                Offset2X = Math.Round(0.0, 3),
                Offset2Y = Math.Round(0.0, 3),
                Offset2T = Math.Round(0.0, 3),

                Result = true,
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Confirm Result
            if (!ConfirmResult(revAlign1, limit1, 1))
                return false;
            #endregion

            //#region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, revUnload, sourceID);
            //#endregion
            return true;

        }
        #endregion


        public void WriteVisionIO(object rev1, object rev2, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
            VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
            VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
            VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
            VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
            VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

            VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            // report matching score to fdc
            var Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
            VisionValues["Score_Object"].NextValue = Mark_Tar1.Score; IOs.Add(VisionValues["Score_Object"]);

            CommodObject.SetVisionValues(IOs);
        }
        protected bool ConfirmResult(XYT revAlign, XYT limit, int index)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                if (index == 1)
                    errorCode = Algo1PointGetAction.Err_Mark1_Limit_Exceeded;
                else if(index ==2)
                    errorCode = Algo1PointGetAction.Err_Mark2_Limit_Exceeded;
                return false;
            }
            else
                return true;
        }
        protected void AssignPLCData_doubleFlow()
        {
            UpdatePLCIOs();

            doubleFlowPLCIO = new DoubleFlowPLCTable();

            doubleFlowPLCIO.UnitNo = (int)PlcValues["UnitNo"].CurValue;
            doubleFlowPLCIO.OptionNo = (int)PlcValues["OptionNo"].CurValue;
            doubleFlowPLCIO.Offset1 = (double)PlcValues["Offset#1"].CurValue;
            doubleFlowPLCIO.Offset2 = (double)PlcValues["Offset#2"].CurValue;
            doubleFlowPLCIO.Offset3 = (double)PlcValues["Offset#3"].CurValue;


            doubleFlowPLCIO.CurPos1 = (double)PlcValues["CurPos#1"].CurValue;
            doubleFlowPLCIO.CurPos2 = (double)PlcValues["CurPos#2"].CurValue;
            doubleFlowPLCIO.CurPos3 = (double)PlcValues["CurPos#3"].CurValue;
            doubleFlowPLCIO.CurPos4 = (double)PlcValues["CurPos#4"].CurValue;

            doubleFlowPLCIO.Teach1_Pos1 = (double)PlcValues["Teach#1_Pos#1"].CurValue;
            doubleFlowPLCIO.Teach1_Pos2 = (double)PlcValues["Teach#1_Pos#2"].CurValue;
            doubleFlowPLCIO.Teach1_Pos3 = (double)PlcValues["Teach#1_Pos#3"].CurValue;
            doubleFlowPLCIO.Teach1_Pos4 = (double)PlcValues["Teach#1_Pos#4"].CurValue;

            doubleFlowPLCIO.Teach2_Pos1 = (double)PlcValues["Teach#2_Pos#1"].CurValue;
            doubleFlowPLCIO.Teach2_Pos2 = (double)PlcValues["Teach#2_Pos#2"].CurValue;
            doubleFlowPLCIO.Teach2_Pos3 = (double)PlcValues["Teach#2_Pos#3"].CurValue;
            doubleFlowPLCIO.Teach2_Pos4 = (double)PlcValues["Teach#2_Pos#4"].CurValue;

            doubleFlowPLCIO.Offset2_X = PlcValues.ContainsKey("Offset#2_X") ? (double)PlcValues["Offset#2_X"].CurValue : 0.0;
            doubleFlowPLCIO.Offset2_Y = PlcValues.ContainsKey("Offset#2_Y") ? (double)PlcValues["Offset#2_Y"].CurValue : 0.0;
            doubleFlowPLCIO.Offset2_T = PlcValues.ContainsKey("Offset#2_T") ? (double)PlcValues["Offset#2_T"].CurValue : 0.0;
            doubleFlowPLCIO.SourceID = (string)PlcValues["SourceID"].CurValue;
            doubleFlowPLCIO.TargetID = (string)PlcValues["TargetID"].CurValue;
            doubleFlowPLCIO.CamPosX1 = (double)PlcValues["CamPosX#1"].CurValue;
            doubleFlowPLCIO.CamPosX2 = (double)PlcValues["CamPosX#2"].CurValue;
            doubleFlowPLCIO.CamPosY = (double)PlcValues["CamPosY"].CurValue;

            if (!string.IsNullOrEmpty(doubleFlowPLCIO.SourceID))
                SourceID = doubleFlowPLCIO.SourceID;
        }
        #endregion

    }
}
