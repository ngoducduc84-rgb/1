﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using OpenCvSharp;
using SvMip;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo1PointGet
{
    [SerializableAttribute]
    public class Algo1PointGetResult : AlgoResultBase
    {
        private double offset1X;
        private double offset1Y;
        private double offset1T;

        private double offset2X;
        private double offset2Y;
        private double offset2T;
        private bool result;

        public Algo1PointGetResult()
        {
        }

        #region [Properties]  
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public double Offset1X
        {
            get { return Math.Round(offset1X, 3); }
            set
            {
                if (value == offset1X) return;
                offset1X = value;

                OnPropertyChanged(nameof(Offset1X));
            }
        }

        public double Offset1Y
        {
            get { return Math.Round(offset1Y, 3); }
            set
            {
                if (value == offset1Y) return;
                offset1Y = value;

                OnPropertyChanged(nameof(Offset1Y));
            }
        }

        public double Offset1T
        {
            get { return Math.Round(offset1T, 3); }
            set
            {
                if (value == offset1T) return;
                offset1T = value;

                OnPropertyChanged(nameof(Offset1T));
            }
        }

        public double Offset2X
        {
            get { return Math.Round(offset2X, 3); }
            set
            {
                if (value == offset2X) return;
                offset2X = value;

                OnPropertyChanged(nameof(Offset2X));
            }
        }

        public double Offset2Y
        {
            get { return Math.Round(offset2Y, 3); }
            set
            {
                if (value == offset2Y) return;
                offset2Y = value;

                OnPropertyChanged(nameof(Offset2Y));
            }
        }

        public double Offset2T
        {
            get { return Math.Round(offset2T, 3); }
            set
            {
                if (value == offset2T) return;
                offset2T = value;

                OnPropertyChanged(nameof(Offset2T));
            }
        }
        #endregion


        public override string ToString()
        {
            //return string.Format("{0} :\n " +
            //                      "curDate: {1}\n, " +
            //                      "curTime: {2}\n," +
            //                      "product ID: {3}" +
            //                      "revX: {4}\n," +
            //                      "revY: {5}\n" +
            //                      "revT: {6}\n," +
            //                      "offsetX: {7}\n" +
            //                      "offsetY: {8}\n" +
            //                      "offsetT: {9}\n" +
            //                      "modelX: {10}\n" +
            //                      "modelY: {11}\n" +
            //                      "productPosX: {12}\n" +
            //                      "productPosY: {13}\n" +
            //                      "productPosT: {14}\n" +
            //                      "isExistID: {15}\n" +
            //                      "isJudgement: {16}\n"
            //                      , typeof(Algo1PointGetResult).ToString()
            //                      , curDate
            //                      , curTime
            //                      , productID
            //                      , revX
            //                      , revY
            //                      , revT
            //                      , offsetX
            //                      , offsetY
            //                      , offsetT
            //                      , modelX
            //                      , modelY
            //                      , productPosX
            //                      , productPosY
            //                      , productPosY
            //                      , isExistID
            //                      , isJudgement
            //                      );
            return "";

        }

    }
}
