﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using Iva.Bplus.Views;
using SvMip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace Iva.Bplus.Modules.Algo1PointGet
{
    [SerializableAttribute]
    public partial class Algo1PointGetShape : ModuleBase
    {
        #region [Construct]
        public Algo1PointGetShape()
            : base()
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;
        }

        public Algo1PointGetShape(SystemCanvasViewModel parent, string name)
            : base(parent, name)
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;           
            
            base.InitItem(null, name, SettingShapeType.Algo);

            var action = base.modAction as SystemActionBase;
            base.SetConnectors(action.InputParams, action.OutputParams);

            ModAction.ModObject.PropertyChanged += ModObject_PropertyChanged;

        }
        #endregion

        #region [override method]
        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string _source)
        {
            base.parent = parent;
            base.InitItem(obj, _source, SettingShapeType.Algo);
            var action = base.modAction as SystemActionBase;

            ModAction.ModObject.PropertyChanged += ModObject_PropertyChanged;

            base.Geometry = SystemImage.TOOL_SEQUENCE_ICON;
        }
        private void ModObject_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            var obj = sender as Algo1PointGetObject;
            if (e.PropertyName == "UseFlowType")
            {
                switch (obj.UseFlowType)
                {
                    case Flow.Single:
                        if (base.inputConnectors.Count != 3)
                        {
                            base.DetachConections(base.InputConnectors);
                            base.inputConnectors.Clear();
                            base.InputConnectors_ItemAdd(new ConnectorViewModel("Tar_P1", typeof(IPointResult)));
                            base.InputConnectors_ItemAdd(new ConnectorViewModel("Trigger", typeof(CalcTrigger)));
                        }
                        else
                        {
                            base.DetachConection(base.inputConnectors[1]);
                            base.InputConnectors_ItemRemoveAt(1);
                        }
                        break;
                    case Flow.Dual:
                        if (base.inputConnectors.Count != 2)
                        {
                            base.DetachConections(base.InputConnectors);
                            base.inputConnectors.Clear();
                            base.InputConnectors_ItemAdd(new ConnectorViewModel("Tar_P1", typeof(IPointResult)));
                            base.InputConnectors_ItemAdd(new ConnectorViewModel("Tar_P2", typeof(IPointResult)));
                            base.InputConnectors_ItemAdd(new ConnectorViewModel("Trigger", typeof(CalcTrigger)));
                        }
                        else
                        {
                            base.InputConnectors_ItemInsert(1, new ConnectorViewModel("Tar_P2", typeof(IPointResult)));
                        }
                        break;
                }
            }
        }
        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion



    }
}
