﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo1PointGet
{
    [Serializable]
    public class DoubleFlowPLCTable : StdPLCTable
    {
        #region [Feilds]
        public double Offset2_X { get; set; }
        public double Offset2_Y { get; set; }
        public double Offset2_T { get; set; }


        public XYT Offset1XYT { get { return new XYT(Offset1, Offset2, Offset3); } }
        
        public XYT Offset2XYT { get { return new XYT(Offset2_X, Offset2_Y, Offset2_T); } }


        #endregion

        #region [Construct]
        public DoubleFlowPLCTable() { }
        #endregion
    }
}
