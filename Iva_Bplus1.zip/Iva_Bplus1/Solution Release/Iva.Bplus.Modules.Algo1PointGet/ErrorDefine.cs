﻿using Iva.Bplus.Utils;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo1PointGet
{
    public partial class Algo1PointGetAction
    {
        #region [Error Script] Algo1PointGetAction : 15101 ~ 15200
        static public int Err_Mark1_NG = 15101; public string E15101_Err_Mark1_NG = "PMAling  Mark1 NG";
        static public int Err_Mark2_NG = 15102; public string E15102_Err_Mark2_NG = "PMAling  Mark2 NG";
        static public int Err_Mark_NG = 15103; public string E15103_Err_Mark_NG = "PMAling Mark1,2 NG";
        static public int Err_PMAlignProperty_NG = 15104; public string E15104_Err_PMAlignProperty_NG = "PMAling Property Setting NG";
        static public int Err_Mark1_Limit_Exceeded = 15105; public string E15105_Err_Mark1_Limit_Exceeded = "Mark1 Offset Exceed Limit";
        static public int Err_Mark2_Limit_Exceeded = 15106; public string E15106_Err_Mark2_Limit_Exceeded = "Mark2 Offset Exceed Limit";

        public override void ErrorDefine()
        {
            base.ErrorDefine();
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Mark1_NG, ErrorType.Warning, E15101_Err_Mark1_NG, "PMAlign 1번 Mark를 찾을수 없습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Mark2_NG, ErrorType.Warning, E15102_Err_Mark2_NG, "PMAlign 2번 Mark를 찾을수 없습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Mark_NG, ErrorType.ErrorStop, E15103_Err_Mark_NG, "PMAlign 모든 Mark를 찾을수 없습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_PMAlignProperty_NG, ErrorType.ErrorStop, E15104_Err_PMAlignProperty_NG, "PMAlign Poperty 세팅이 잘 못 되었습니다.(Single Flow에선 Skip 미사용)"));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Mark1_Limit_Exceeded, ErrorType.ErrorStop, E15105_Err_Mark1_Limit_Exceeded, "Mark1 결과값이 Limit를 초과하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Mark2_Limit_Exceeded, ErrorType.ErrorStop, E15106_Err_Mark2_Limit_Exceeded, "Mark2 결과값이 Limit를 초과하였습니다."));
        }
        #endregion
    }
}
