﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo2PAlign
{
    [SerializableAttribute]
    class Algo2PAlignInputParams : InputParams
    {
        #region Input P1, P2
        public IPointResult P1 { get; set; }
        public IPointResult P2 { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
