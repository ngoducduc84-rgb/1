﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo2PAlign
{
    [SerializableAttribute]

    public partial class Algo2PAlignAlignModelParams : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        private AlgoParam spec_Length;
        private AlgoParam tor_Length;
        private AlgoParam scale_Length;
        // Retry Sepc
        private AlgoParam retry_X;
        private AlgoParam retry_Y;
        private AlgoParam retry_T;
        //Mark Score
        private AlgoParam mark_P1_Score;
        private AlgoParam mark_P2_Score;

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        public AlgoParam Spec_Length { get { return spec_Length; } set { if (spec_Length == value) return; spec_Length = value; this.OnPropertyChanged(nameof(Spec_Length)); } }
        public AlgoParam Tor_Length { get { return tor_Length; } set { if (tor_Length == value) return; tor_Length = value; this.OnPropertyChanged(nameof(Tor_Length)); } }
        public AlgoParam Scale_Length { get { return scale_Length; } set { if (scale_Length == value) return; scale_Length = value; this.OnPropertyChanged(nameof(Scale_Length)); } }

        public AlgoParam RetryX { get { return retry_X; } set { if (retry_X == value) return; retry_X = value; this.OnPropertyChanged(nameof(RetryX)); } }
        public AlgoParam RetryY { get { return retry_Y; } set { if (retry_Y == value) return; retry_Y = value; this.OnPropertyChanged(nameof(RetryY)); } }
        public AlgoParam RetryT { get { return retry_T; } set { if (retry_T == value) return; retry_T = value; this.OnPropertyChanged(nameof(RetryT)); } }

        public AlgoParam Mark_P1_Score { get { return mark_P1_Score; } set { if (mark_P1_Score == value) return; mark_P1_Score = value; this.OnPropertyChanged(nameof(Mark_P1_Score)); } }
        public AlgoParam Mark_P2_Score { get { return mark_P2_Score; } set { if (mark_P2_Score == value) return; mark_P2_Score = value; this.OnPropertyChanged(nameof(Mark_P2_Score)); } }


        public Algo2PAlignAlignModelParams()
            : base()
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);
            Spec_Length = new AlgoParam("Spec_Length", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)100);
            Tor_Length = new AlgoParam("Tor_Length", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)1);
            Scale_Length = new AlgoParam("Scale_Length", "mm", typeof(double), 0.0, "Length Scale", (double)0.5, (double)3);

            RetryX = new AlgoParam("RetryX", "mm", typeof(double), 0.0, "Retry Limit X", (double)-0.5, (double)0.5);
            RetryY = new AlgoParam("RetryY", "mm", typeof(double), 0.0, "Retry Limit Y", (double)-0.5, (double)0.5);
            RetryT = new AlgoParam("RetryT", "deg", typeof(double), 0.0, "Retry Limit T", (double)-0.5, (double)0.5);

            Mark_P1_Score = new AlgoParam("Mark_P1_Score", "%", typeof(double), 0.0, "Mark Point1 Score", (double)0.0, (double)100.0);
            Mark_P2_Score = new AlgoParam("Mark_P2_Score", "%", typeof(double), 0.0, "Mark Point2 Score", (double)0.0, (double)100.0);
        }
    }
}
