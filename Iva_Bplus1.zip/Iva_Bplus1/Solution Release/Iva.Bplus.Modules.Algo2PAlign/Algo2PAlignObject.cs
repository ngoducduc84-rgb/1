﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo2PAlign
{
    [SerializableAttribute]
    public partial class Algo2PAlignObject : AlgoObjectBase
    {
        #region [Fields]
        #region  Selected Caldata Name
        private string p1_CalData;
        private string p2_CalData;
        private string p1_Display;
        private string p2_Display;
        #endregion

        #region etc
        private CalcType calcType;
        private ThetaDirection thetaDirection;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        private MachineType machineType = MachineType.Normal;
        #endregion

        #region Align관련 Data
        private XYT revAlign = new XYT();
        private XYT revUnload = new XYT();
        private double length = 0.0;
        private bool lastJudgement = true;
        private double score_P1 = 0;
        private double score_P2 = 0;

        [NonSerialized]
        IPointResult Mark_Obj1;
        [NonSerialized]
        IPointResult Mark_Obj2;

        XYXY VirtualTarget { get; set; } = new XYXY();
        #endregion
        public string schName = "";
        #endregion

        #region [properties]
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P1_CalData
        {
            get { return p1_CalData; }
            set { if (p1_CalData == value) return; p1_CalData = value; this.OnPropertyChanged(nameof(P1_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P2_CalData
        {
            get { return p2_CalData; }
            set { if (p2_CalData == value) return; p2_CalData = value; this.OnPropertyChanged(nameof(P2_CalData)); }
        }

        public CalDataObject P1_CalDataObj
        {
            get { return SystemObject_Common.GetObject(p1_CalData) as CalDataObject; }
        }

        public CalDataObject P2_CalDataObj
        {
            get { return SystemObject_Common.GetObject(p2_CalData) as CalDataObject; }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P2_Display
        {
            get { return p2_Display; }
            set { if (p2_Display == value) return; p2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
        }
        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }
        public CogDisplayObject P2_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p2_Display) as CogDisplayObject; }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }

        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }
        public MachineType MachineType
        {
            get { return machineType; }
            set { Set<MachineType>(ref machineType, value, nameof(MachineType)); }
        }

        public ObservableCollection<string> CalDataList
        {
            get
            {

                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }

        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        public double Length { get { return length; } }
        public bool LastJudgement { get { return lastJudgement; } }
        #endregion
        #endregion

        #region[Construct]
        public Algo2PAlignObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo2PAlignAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool AlignCalc()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudgement = true;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Mark Data Read& Confirm
            // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
            if (!InputValues.ContainsKey("P1") || !InputValues.ContainsKey("P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            // 2020.03.31 hdy MatchingRstData -> IPointResult로 변경
            Mark_Obj1 = InputValues["P1"] as IPointResult;
            Mark_Obj2 = InputValues["P2"] as IPointResult;
            if (Mark_Obj1 == null || Mark_Obj2 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            if (Mark_Obj1.RefPoints == null)
            {
                Mark_Obj1.RefPoints = new List<XYT>();
                Mark_Obj1.RefPoints.Add(new XYT(0, 0, 0));
            }
            if (Mark_Obj2.RefPoints == null)
            {
                Mark_Obj2.RefPoints = new List<XYT>();
                Mark_Obj2.RefPoints.Add(new XYT(0, 0, 0));
            }

            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null || P2_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                // Calibration 설정 안됨.
                return false;
            }
            var Robot_P1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));
            var Robot_P2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));

            var Robot_CAM_P1 = new XY(0, 0);
            var Robot_CAM_P2 = new XY(0, 0);

            // 2020.04.22 hdy 같은 화면일 경우,, case 수정,,
            XY Robot_Ref_P1; XY Robot_Ref_P2;
			//2020.09.02 Ref 안써서 둘 다 0일 경우 제외 
            if (Mark_Obj1.RefPoints[0].X == Mark_Obj2.RefPoints[0].X && Mark_Obj1.RefPoints[0].X != 0)        // 같은 이미지일 경우,,
            {
                Robot_Ref_P1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Obj1.RefPoints[0].X, Mark_Obj1.RefPoints[0].Y));
                Robot_Ref_P2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Obj2.RefPoints[1].X, Mark_Obj2.RefPoints[1].Y));
            }
            else
            {
                Robot_Ref_P1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Obj1.RefPoints[0].X, Mark_Obj1.RefPoints[0].Y));
                Robot_Ref_P2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Obj2.RefPoints[0].X, Mark_Obj2.RefPoints[0].Y));
            }

            var Coord_P1 = Robot_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_P2 = Robot_P2 + P2_CalDataObj.GetRotateCenter(model);
             
            var Coord_CAM_P1 = Robot_CAM_P1 + P1_CalDataObj.GetRotateCenter(model); 
            var Coord_CAM_P2 = Robot_CAM_P2 + P2_CalDataObj.GetRotateCenter(model);
             
            var Coord_Ref_P1 = Robot_Ref_P1 + P1_CalDataObj.GetRotateCenter(model); 
            var Coord_Ref_P2 = Robot_Ref_P2 + P2_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo2PAlignAlignModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            var Limit = new XYT(limitX, limitY, limitT);
            var spec_Length = (double)mParams.Spec_Length.Value;
            var tor_Length = (double)mParams.Tor_Length.Value;
            var scale_Length = (double)mParams.Scale_Length.Value;

            var score_Mark1Point = (double)mParams.Mark_P1_Score.Value;
            var score_Mark2Point = (double)mParams.Mark_P2_Score.Value;

            var retryX = (double)mParams.RetryX?.Value;
            var retryY = (double)mParams.RetryY?.Value;
            var retryT = (double)mParams.RetryT?.Value;

            #endregion

            #region Calc Rev Offset

            // 단변
            double camT = GetThetaColumn(Coord_CAM_P1.X, Coord_CAM_P2.X, Coord_CAM_P1.Y, Coord_CAM_P2.Y); 
            double refT = GetThetaColumn(Coord_Ref_P1.X, Coord_Ref_P2.X, Coord_Ref_P1.Y, Coord_Ref_P2.Y);
            double pnlT = GetThetaColumn(Coord_P1.X, Coord_P2.X, Coord_P1.Y, Coord_P2.Y); 

            pnlT -= camT;
            refT -= camT;
            camT = 0;

            var camTar = (Coord_CAM_P1 + Coord_CAM_P2) / 2;    
            var refTar = (Coord_Ref_P1 + Coord_Ref_P2) / 2; 
            var pnlObj = (Coord_P1 + Coord_P2) / 2;    

            var alignOffset = CvtPLCIO.OffsetXYT;

            var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
            var refTarxyt = new XYT(refTar.X, refTar.Y, refT); 
            var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
            var camTarxyt_Un = new XYT(camTar.X, camTar.Y, camT);

            revAlign = new XYT();
            revUnload = new XYT();
            double radT, DriftX, DriftY;

            if (CalcType == CalcType.Center)
            {
                // Attach 위치 보정값 계산. 
                camTarxyt = ApplyTargetOffset(camTarxyt, alignOffset);
                radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revAlign.X = camTarxyt.X - DriftX;
                revAlign.Y = camTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else //역방향
                    revAlign.T = (radT / rad) * -1;

                // Unload 위치 보정값 계산 // 얘는 오프셋없음.    
                camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revUnload.X = camTarxyt_Un.X - DriftX;
                revUnload.Y = camTarxyt_Un.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revUnload.T = radT / rad;
                else //역방향
                    revUnload.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.Reference)
            {
                // Attach 위치 보정값 계산. 
                refTarxyt = ApplyTargetOffset(refTarxyt, alignOffset);
                radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revAlign.X = refTarxyt.X - DriftX;
                revAlign.Y = refTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else  //역방향
                    revAlign.T = (radT / rad) * -1;

                // Unload 위치 보정값 계산 // 얘는 오프셋없음.    //CamCenter위치로
                camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revUnload.X = camTarxyt_Un.X - DriftX;
                revUnload.Y = camTarxyt_Un.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revUnload.T = radT / rad;
                else  //역방향
                    revUnload.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.PickUp)   //Target: 자재, Object: Reference
            {
                pnlObjxyt = ApplyTargetOffset(pnlObjxyt, alignOffset);
                radT = NormalizeTheta(pnlObjxyt.T - refTarxyt.T);
                DriftX = Math.Cos(radT) * refTarxyt.X - Math.Sin(radT) * refTarxyt.Y;
                DriftY = Math.Sin(radT) * refTarxyt.X + Math.Cos(radT) * refTarxyt.Y;
                revAlign.X = pnlObjxyt.X - DriftX;
                revAlign.Y = pnlObjxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else  //역방향
                    revAlign.T = (radT / rad) * -1;

            }
            #endregion

            #region VirtualMark
            if (MachineType == MachineType.Bending || MachineType == MachineType.Attach) 
            {
                var rst1 = Mark_Obj1.OutputXYT.ToXY();
                var rst2 = Mark_Obj2.OutputXYT.ToXY();

                var vl = GetApplyRev(P1_CalDataObj, rst1, revAlign);
                var vr = GetApplyRev(P2_CalDataObj, rst2, revAlign);
                VirtualTarget = new XYXY(vl.X, vl.Y, vr.X, vr.Y);
            }
            #endregion

            #region Confirm Result (Align Spec Over Check)
            
            #region retry spec over
            
            if (!(retryX == 0.0 && retryY == 0.0 && retryT == 0.0)
                && (Math.Abs(revAlign.X) > retryX || Math.Abs(revAlign.Y) > retryY || Math.Abs(revAlign.T) > retryT))
            {
                P1_DisplayObj.Judgement = (uint)Judgement.Warning;
                P2_DisplayObj.Judgement = (uint)Judgement.Warning;
                errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                lastJudgement = false;
            }
            
            #endregion

            #region limit spec over
            if (!ConfirmResult(revAlign, Limit))
            {
                P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                P2_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                lastJudgement = false;
            }
            #endregion

            #endregion


            #region Calc Length & Confirm (Length Check)
            length = GetLength(Coord_P1, Coord_P2);
            if (tor_Length != 0)
            {
                if (Math.Abs(spec_Length - length) > tor_Length)
                {
                    lastJudgement = false;
                    errorCode = AlgoActionBase.Err_Length_Check;
                    P1_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    P2_DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }
            #endregion

            //Chang_20200409 : 아래는 Score_Spec Ng 비교처리 구문은 Foldable CIC에서 반영함.
            #region Score_Spec Ng            
            if (score_Mark1Point != 0)
            {
                if (Mark_Obj1.Score < score_Mark1Point)
                {
                    lastJudgement = false;
                    errorCode = AlgoActionBase.Err_Mark_Score_Check;
                    P1_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                    P2_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                }
            }
            if (score_Mark2Point != 0)
            {
                if (Mark_Obj2.Score < score_Mark2Point)
                {
                    lastJudgement = false;
                    errorCode = AlgoActionBase.Err_Mark_Score_Check;
                    P1_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                    P2_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;

                }
            }            
            #endregion

            #region Inspection Result Image Save (L_Check)
            if (P1_DisplayObj.Judgement != (uint)Judgement.OK && P1_DisplayObj.Judgement != (uint)Judgement.None)
            {
                string _sourceID = DeepClone(sourceID);
                DateTime dateTime = DateTime.Now;
                string _judgement = "";

                foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
                {
                    if (P1_DisplayObj.Judgement == (uint)j)
                    {
                        _judgement = j.ToString();
                        break;
                    }
                }

                object obj = (Bitmap)P1_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                P1_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true, ErrorCode);

                object obj2 = (Bitmap)P2_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                P2_DisplayObj.SaveImage(dateTime, obj2, _judgement, schName, _sourceID, true, ErrorCode);                

                object obj3 = P1_DisplayObj.GetCurImage();
                P1_DisplayObj.SaveImage(dateTime, obj3, _judgement, schName, _sourceID, false, ErrorCode);

                object obj4 = P2_DisplayObj.GetCurImage();
                P2_DisplayObj.SaveImage(dateTime, obj4, _judgement, schName, _sourceID, false, ErrorCode);                
            }
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo2PAlignResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Offset1X = Math.Round(revAlign.X, 3),
                Offset1Y = Math.Round(revAlign.Y, 3),
                Offset1T = Math.Round(revAlign.T, 3),

                Offset2X = Math.Round(revUnload.X, 3),
                Offset2Y = Math.Round(revUnload.Y, 3),
                Offset2T = Math.Round(revUnload.T, 3),

                Length = Math.Round(length, 3),
                Result = lastJudgement,

                P1_X = Math.Round(Mark_Obj1.OutputXYT.X, 3),  //Mark Pixel 좌표
                P1_Y = Math.Round(Mark_Obj1.OutputXYT.Y, 3),
                P2_X = Math.Round(Mark_Obj2.OutputXYT.X, 3),
                P2_Y = Math.Round(Mark_Obj2.OutputXYT.Y, 3),

                C1_X = Math.Round(Coord_P1.X, 3),
                C1_Y = Math.Round(Coord_P1.Y, 3),
                C2_X = Math.Round(Coord_P2.X, 3),
                C2_Y = Math.Round(Coord_P2.Y, 3),

                Type = CalcType.ToString(),
                Pnl_T = Math.Round(pnlT / rad, 3),
                Ref_T = Math.Round(refT / rad, 3),
                Cam_T = Math.Round(camT / rad, 3),    //camT=0인데 의미가 있나

                PLCOffset_X = alignOffset.X,
                PLCOffset_Y = alignOffset.Y,
                PLCOffset_T = alignOffset.T,

                Score_P1 = Math.Round(Mark_Obj1.Score, 2),
                Score_P2 = Math.Round(Mark_Obj2.Score, 2),
            };
            #endregion
            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            //#endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO(revAlign, revUnload, "");
            #endregion
            return lastJudgement;
        }       

        private XY GetApplyRev(CalDataObject cal, XY mark, XYT rev)
        {
            var model = SystemModel.GetCurModel();
            var rc = cal.GetRotateCenter(model);
            var rp = cal.GetV2R(model, mark);

            double r = rev.T * PI / 180;
            var a = Math.Cos(r) * (rev.X + rc.X);
            var b = -Math.Sin(r) * (rev.Y + rc.Y);

            double x = rev.X + Math.Cos(r) * (rp.X + rc.X) - Math.Sin(r) * (rp.Y + rc.Y) - rc.X;
            double y = rev.Y + Math.Sin(r) * (rp.X + rc.X) + Math.Cos(r) * (rp.Y + rc.Y) - rc.Y;

            return cal.GetR2V(model, new XY(x, y)).ToXY();
        }

        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }
            else
                return true;
        }

        public override void AssignPLCData()
        {
            switch (machineType)
            {
                case MachineType.Normal:
                    base.AssignPLCData();
                    break;
                case MachineType.Bending:
                    AssignPLCData_Bending();
                    break;
                case MachineType.Attach:
                    {
                        base.AssignPLCData();
                    }
                    break;
                default:
                    base.AssignPLCData();
                    break;
            }
        }

        private void AssignPLCData_Bending()
        {
            UpdatePLCIOs();

            CvtPLCIO = new StdPLCTable();

            CvtPLCIO.Offset1 = (double)PlcValues["Offset_X_X1"].CurValue;
            CvtPLCIO.Offset2 = (double)PlcValues["Offset_Y_X2"].CurValue;
            CvtPLCIO.Offset3 = (double)PlcValues["Offset_T_Y1"].CurValue;
            CvtPLCIO.Offset4 = (double)PlcValues["Offset_Y2"].CurValue;

            CvtPLCIO.CurPos1 = (double)PlcValues["Cur_Position_X1_U_X"].CurValue;
            CvtPLCIO.CurPos2 = (double)PlcValues["Cur_Position_X2_V_Y"].CurValue;
            CvtPLCIO.CurPos3 = (double)PlcValues["Cur_Position_Y1_W_T"].CurValue;
            CvtPLCIO.CurPos4 = (double)PlcValues["Cur_Position_Y2"].CurValue;

            CvtPLCIO.Teach1_Pos1 = (double)PlcValues["Teacing_Position_X1_U_X"].CurValue;
            CvtPLCIO.Teach1_Pos2 = (double)PlcValues["Teacing_Position_X2_V_Y"].CurValue;
            CvtPLCIO.Teach1_Pos3 = (double)PlcValues["Teacing_Position_Y1_W_T"].CurValue;
            CvtPLCIO.Teach1_Pos4 = (double)PlcValues["Teacing_Position_Y2"].CurValue;

            CvtPLCIO.SourceID = (string)PlcValues["Source_ID"].CurValue;

            if (!string.IsNullOrEmpty(CvtPLCIO.SourceID))
                SourceID = CvtPLCIO.SourceID;
        }

        public void WriteVisionIO(object rev1, object rev2, string ID) 
        {
            if (MachineType == MachineType.Bending)
            {
                WriteVisionIO_Bending(rev1, rev2, ID);
                return;
            }

            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch(alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                    VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                    VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                    VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                    VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                    VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X;     IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y;     IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T;     IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0;        IOs.Add(VisionValues["Tar#1_Pos#4"]);
                    VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X;     IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y;     IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T;     IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0;        IOs.Add(VisionValues["Tar#2_Pos#4"]);

                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    break;

            }

            if (MachineType == MachineType.CSpacer)
            {
                // report matching score to fdc
                VisionValues["Score_Object_L"].NextValue = Mark_Obj1.Score; IOs.Add(VisionValues["Score_Object_L"]);
                VisionValues["Score_Object_R"].NextValue = Mark_Obj2.Score; IOs.Add(VisionValues["Score_Object_R"]);
            }
            else if (MachineType == MachineType.FCIC)
            {
                // report matching score to fdc

                //Score 는 *100 , 나머지 가중치는 어케 댐??
                VisionValues["FDC_Obj_Mark_1_X"].NextValue = (double)Math.Round(Mark_Obj1.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Obj_Mark_1_X"]);
                VisionValues["FDC_Obj_Mark_1_Y"].NextValue = (double)Math.Round(Mark_Obj1.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Obj_Mark_1_Y"]);
                //PLC에서 소수점 두자리 까지 Int형으로 받음. 우리는 소수점 2자리까지 살린 후 * 100 , ex) 99.9877 -> 9998로 올려야함?
                VisionValues["FDC_Obj_Mark_1_S"].NextValue = (int)(Math.Round(Mark_Obj1.Score, 2) * 100); IOs.Add(VisionValues["FDC_Obj_Mark_1_S"]);

                VisionValues["FDC_Obj_Mark_2_X"].NextValue = (double)Math.Round(Mark_Obj2.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Obj_Mark_2_X"]);
                VisionValues["FDC_Obj_Mark_2_Y"].NextValue = (double)Math.Round(Mark_Obj2.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Obj_Mark_2_Y"]);
                VisionValues["FDC_Obj_Mark_2_S"].NextValue = (int)(Math.Round(Mark_Obj2.Score, 2) * 100); IOs.Add(VisionValues["FDC_Obj_Mark_2_S"]);
            }
            else if (MachineType == MachineType.Attach)
            {

                // virtual mark
                VisionValues["VirtualTarget_LX"].NextValue = (double)VirtualTarget.Lx; IOs.Add(VisionValues["VirtualTarget_LX"]);
                VisionValues["VirtualTarget_LY"].NextValue = (double)VirtualTarget.Ly; IOs.Add(VisionValues["VirtualTarget_LY"]);
                VisionValues["VirtualTarget_RX"].NextValue = (double)VirtualTarget.Rx; IOs.Add(VisionValues["VirtualTarget_RX"]);
                VisionValues["VirtualTarget_RY"].NextValue = (double)VirtualTarget.Ry; IOs.Add(VisionValues["VirtualTarget_RY"]);
            }
                       
            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }
        private void WriteVisionIO_Bending(object rev1, object rev2, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["Rev_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev_X"]);
                    VisionValues["Rev_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev_Y"]);
                    VisionValues["Rev_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    VisionValues["Tar_Position_X1_U_X"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar_Position_X1_U_X"]);
                    VisionValues["Tar_Position_X2_V_Y"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar_Position_X2_V_Y"]);
                    VisionValues["Tar_Position_Y1_W_T"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar_Position_Y1_W_T"]);
                    VisionValues["Tar_Position_Y2"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar_Position_Y2"]);

                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    break;
            }

            // virtual mark
            VisionValues["VirtualTarget_LX"].NextValue = (double)VirtualTarget.Lx; IOs.Add(VisionValues["VirtualTarget_LX"]);
            VisionValues["VirtualTarget_LY"].NextValue = (double)VirtualTarget.Ly; IOs.Add(VisionValues["VirtualTarget_LY"]);
            VisionValues["VirtualTarget_RX"].NextValue = (double)VirtualTarget.Rx; IOs.Add(VisionValues["VirtualTarget_RX"]);
            VisionValues["VirtualTarget_RY"].NextValue = (double)VirtualTarget.Ry; IOs.Add(VisionValues["VirtualTarget_RY"]);

            // report matching score to fdc
            VisionValues["MatchingScore_L"].NextValue = Mark_Obj1.Score; IOs.Add(VisionValues["MatchingScore_L"]);
            VisionValues["MatchingScore_R"].NextValue = Mark_Obj2.Score; IOs.Add(VisionValues["MatchingScore_R"]);

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }
        #endregion

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            //if (cogDisp == null) return;
            //Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }
    }
}

