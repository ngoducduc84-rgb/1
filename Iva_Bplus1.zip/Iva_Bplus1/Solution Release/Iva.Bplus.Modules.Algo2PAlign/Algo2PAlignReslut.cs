﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAlign
{
    [SerializableAttribute]
    public class Algo2PAlignResult : AlgoResultBase
    {
        #region [fiedls]
        private string type;
        private double pnl_T;
        private double ref_T;
        private double cam_T;

        private double offset1X;
        private double offset1Y;
        private double offset1T;

        private double offset2X;
        private double offset2Y;
        private double offset2T;

        private double length;
        private bool result;

        private double p1_X;
        private double p1_Y;
        private double p2_X;
        private double p2_Y;

        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;

        // twim 김윤동 추가
        private double plcOffset_X;
        private double plcOffset_Y;
        private double plcOffset_T;

        private double score_p1;
        private double score_p2;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string Type
        {
            get { return type; }
            set { if (value == type) return; type = value; OnPropertyChanged(nameof(Type)); }
        }

        public double Score_P1
        {
            get { return score_p1; }
            set { if (value == score_p1) return; score_p1 = value; OnPropertyChanged(nameof(Score_P1)); }
        }

        public double Score_P2
        {
            get { return score_p2; }
            set { if (value == score_p2) return; score_p2 = value; OnPropertyChanged(nameof(Score_P2)); }
        }

        public double Pnl_T
        {
            get { return pnl_T; }
            set { if (value == pnl_T) return; pnl_T = value; OnPropertyChanged(nameof(Pnl_T)); }
        }
        public double Ref_T
        {
            get { return ref_T; }
            set { if (value == ref_T) return; ref_T = value; OnPropertyChanged(nameof(Ref_T)); }
        }
        public double Cam_T
        {
            get { return cam_T; }
            set { if (value == cam_T) return; cam_T = value; OnPropertyChanged(nameof(Cam_T)); }
        } 
        public double Offset1X
        {
            get { return offset1X; }
            set { if (value == offset1X) return; offset1X = value; OnPropertyChanged(nameof(Offset1X)); }
        }
        public double Offset1Y
        {
            get { return offset1Y; }
            set { if (value == offset1Y) return; offset1Y = value; OnPropertyChanged(nameof(Offset1Y)); }
        }
        public double Offset1T
        {
            get { return offset1T; }
            set { if (value == offset1T) return; offset1T = value; OnPropertyChanged(nameof(Offset1T)); }
        }

        public double Offset2X
        {
            get { return offset2X; }
            set { if (value == offset2X) return; offset2X = value; OnPropertyChanged(nameof(Offset2X)); }
        }
        public double Offset2Y
        {
            get { return offset2Y; }
            set { if (value == offset2Y) return; offset2Y = value; OnPropertyChanged(nameof(Offset2Y)); }
        }
        public double Offset2T
        {
            get { return offset2T; }
            set { if (value == offset2T) return; offset2T = value; OnPropertyChanged(nameof(Offset2T)); }
        }
        public double Length
        {
            get { return length; }
            set { if (value == length) return; length = value; OnPropertyChanged(nameof(Length)); }
        }

        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }
        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }
        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }
        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }
        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }
        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }
        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }
        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }

        public double PLCOffset_X
        {
            get { return plcOffset_X; }
            set { if (value == plcOffset_X) return; plcOffset_X = value; OnPropertyChanged(nameof(PLCOffset_X)); }
        }
        public double PLCOffset_Y
        {
            get { return plcOffset_Y; }
            set { if (value == plcOffset_Y) return; plcOffset_Y = value; OnPropertyChanged(nameof(plcOffset_Y)); }
        }
        public double PLCOffset_T
        {
            get { return plcOffset_T; }
            set { if (value == plcOffset_T) return; plcOffset_T = value; OnPropertyChanged(nameof(plcOffset_T)); }
        }
        #endregion


        public Algo2PAlignResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "offset1X: {3},\noffset1Y: {4},\noffset1T: {5},\n" +
                                  "offset2X: {6},\noffset2Y: {7},\noffset2T: {8},\n" +
                                  "Length: {9},\nResult: {10},\n" +
                                  "P1_X: {11},\nP1_Y: {12},\nP2_X: {13},\nP2_Y: {14},\n" +
                                  "C1_X: {15},\nC1_Y: {16},\nC2_X: {17},\nC2_Y: {18},\n" +
                                  "Type: {19},\nPnl_T: {20},\nRef_T: {21},\nCam_T: {22},\n"
                                  , typeof(Algo2PAlignResult).ToString(), curTime, curDate
                                  , offset1X, offset1Y, offset1T
                                  , offset2X, offset2Y, offset2T
                                  , length, result
                                  , p1_X, p1_Y, p2_X, p2_Y
                                  , c1_X, c1_Y, c2_X, c2_Y
                                  , type, pnl_T, ref_T, cam_T
                                  );
        }

    }
}
