﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Diagram.Items;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAlignFCIC
{
    [SerializableAttribute]
    public partial class Algo2PAlignFCICAction : AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private bool useUnloadOffset;
        [field: NonSerialized]
        private double cur_Length;

        [field: NonSerialized]
        private bool judge_Length;

        [field: NonSerialized]
        private AlgoParam temp_Length;

        #endregion

        #region [Properties]   
        public bool UseUnloadOffset { get { return useUnloadOffset; } set { if (useUnloadOffset == value) return; useUnloadOffset = value; this.OnPropertyChanged(nameof(UseUnloadOffset)); } }
        public double Cur_Length { get { return cur_Length; } set { if (cur_Length == value) return; cur_Length = value; this.OnPropertyChanged(nameof(Cur_Length)); } }

        public bool Judge_Length { get { return judge_Length; } set { if (judge_Length == value) return; judge_Length = value; this.OnPropertyChanged(nameof(Judge_Length)); } }

        public AlgoParam Temp_Length { get { return temp_Length; } set { if (temp_Length == value) return; temp_Length = value; this.OnPropertyChanged(nameof(Temp_Length)); } }
        #endregion

        #region [Construct]
        public Algo2PAlignFCICAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo2PAlignFCICInputParams();
            OutputParams = new Algo2PAlignFCICOutputParams();

            var obj = _object as Algo2PAlignFCICObject;
            obj.ModelParamType = typeof(Algo2PAlignFCICAlignModelParams);
            var param = obj.CurParams as Algo2PAlignFCICAlignModelParams;

            ChildSettingView = new AlignSetting();
            ChildSettingView.DataContext = this;

            temp_Length = new AlgoParam(param.Scale_Length);
            temp_Length.Value = 0.0;
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as Algo2PAlignFCICObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();

                var connection = this.parent.GetInputConnector("Trigger");
                Obj.schName = (connection.AttachedConnections[0].SourceConnector.ParentItem.ModAction as SchedulerActionBase).Name;

                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                DateTime dateTime = DateTime.Now;
                if (!Obj.Run())
                {
                    // 기존값들 초기화 필요함.                    
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    if (Obj.Left_DisplayObj.Judgement == (uint)Judgement.OK)
                    {
                        Obj.Left_DisplayObj.Judgement = (uint)Judgement.Error;
                        Obj.Right_DisplayObj.Judgement = (uint)Judgement.Error;
                    }

                    return OccurError(Obj.ErrorCode);
                }
                else
                {                    
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    Obj.AppendMessage(Name, "Caluration Complete");
                }
                #endregion
            }

            return End();
        }

        public override bool Reset()
        {
            if (!base.Reset()) return false;

            return true;
        }

        #endregion

        #region [Command]
        [field: NonSerialized]
        private DelegateCommand scaleResetCommand;
        public DelegateCommand ScaleResetCommand
        {
            get
            {
                return scaleResetCommand = scaleResetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo2PAlignFCICAlignModelParams;

                    Cur_Length /= (double)tmp.Scale_Length.Value;

                    tmp.Scale_Length.Value = (double)1.0;

                    Obj.UpdateTempValues();

                    //var Obj = modObject as AlgoObjectBase;
                    //var tmp = Obj.TempParams as Algo2PAlignFCICInspectModelParams;
                    //var cur = Obj.ModelParams[SystemModel.GetCurModel()] as Algo2PAlignFCICInspectModelParams;

                    //tmp.Scale_UpperLx.Value = (double)1.0;
                    //tmp.Scale_UpperLy.Value = (double)1.0;
                    //tmp.Scale_LowerLx.Value = (double)1.0;
                    //tmp.Scale_LowerLy.Value = (double)1.0;
                    //tmp.Scale_LowerRx.Value = (double)1.0;
                    //tmp.Scale_LowerRy.Value = (double)1.0;


                    //cur_UpperLx /= (double)cur.Scale_UpperLx.Value;
                    //cur_UpperLy /= (double)cur.Scale_UpperLy.Value;
                    //cur_LowerLx /= (double)cur.Scale_LowerLx.Value;
                    //cur_LowerLy /= (double)cur.Scale_LowerLy.Value;
                    //cur_LowerRx /= (double)cur.Scale_LowerRx.Value;
                    //cur_LowerRy /= (double)cur.Scale_LowerRy.Value;

                    //Obj.UpdateTempValues();

                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand scaleCalcCommand;
        public DelegateCommand ScaleCalcCommand
        {
            get
            {
                return scaleCalcCommand = scaleCalcCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo2PAlignFCICAlignModelParams;

                    var tempLength = (double)temp_Length.Value;

                    //현재값을 원래 대로
                    Cur_Length /= (double)tmp.Scale_Length.Value;

                    // 스케일 계산
                    tmp.Scale_Length.Value = tempLength / Cur_Length;

                    // 재계산.
                    Cur_Length *= (double)tmp.Scale_Length.Value;

                    // 업뎃
                    Obj.UpdateTempValues();


                    //var Obj = modObject as AlgoObjectBase;
                    //var tmp = Obj.TempParams as Algo2PAlignFCICInspectModelParams;

                    //var upperLx = (double)temp_UpperLx.Value;
                    //var upperLy = (double)temp_UpperLy.Value;
                    //var lowerLx = (double)temp_LowerLx.Value;
                    //var lowerLy = (double)temp_LowerLy.Value;
                    //var lowerRx = (double)temp_LowerRx.Value;
                    //var lowerRy = (double)temp_LowerRy.Value;

                    //var spec_upperLx = (double)tmp.Spec_UpperLx.Value;
                    //var spec_upperLy = (double)tmp.Spec_UpperLy.Value;
                    //var spec_lowerLx = (double)tmp.Spec_LowerLx.Value;
                    //var spec_lowerLy = (double)tmp.Spec_LowerLy.Value;
                    //var spec_lowerRx = (double)tmp.Spec_LowerRx.Value;
                    //var spec_lowerRy = (double)tmp.Spec_LowerRy.Value;

                    //double range = 2;
                    //if (!AlgoObjectBase.ConfirmTempValue(upperLx, spec_upperLx, range)) { RadWindow.Alert(string.Format("Check input value![UpperLx :{0}][Range {1} ~ {2}]", upperLx, spec_upperLx - range, spec_upperLx + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(upperLy, spec_upperLy, range)) { RadWindow.Alert(string.Format("Check input value![UpperLy :{0}][Range {1} ~ {2}]", upperLy, spec_upperLy - range, spec_upperLy + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(lowerLx, spec_lowerLx, range)) { RadWindow.Alert(string.Format("Check input value![LowerLx :{0}][Range {1} ~ {2}]", lowerLx, spec_lowerLx - range, spec_lowerLx + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(lowerLy, spec_lowerLy, range)) { RadWindow.Alert(string.Format("Check input value![LowerLy :{0}][Range {1} ~ {2}]", lowerLy, spec_lowerLy - range, spec_lowerLy + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(lowerRx, spec_lowerRx, range)) { RadWindow.Alert(string.Format("Check input value![LowerRx :{0}][Range {1} ~ {2}]", lowerRx, spec_lowerRx - range, spec_lowerRx + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(lowerRy, spec_lowerRy, range)) { RadWindow.Alert(string.Format("Check input value![LowerRy :{0}][Range {1} ~ {2}]", lowerRy, spec_lowerRy - range, spec_lowerRy + range)); return; }

                    //tmp.Scale_UpperLx.Value = upperLx / cur_UpperLx;
                    //tmp.Scale_UpperLy.Value = upperLy / cur_UpperLy;
                    //tmp.Scale_LowerLx.Value = lowerLx / cur_LowerLx;
                    //tmp.Scale_LowerLy.Value = lowerLy / cur_LowerLy;
                    //tmp.Scale_LowerRx.Value = lowerRx / cur_LowerRx;
                    //tmp.Scale_LowerRy.Value = lowerRy / cur_LowerRy;

                    //Obj.UpdateTempValues();


                    //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
                    //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
                    //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
                    //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
                    //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
                    //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;


                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand reMeasureCommand;
        public DelegateCommand ReMeasureCommand
        {
            get
            {
                return reMeasureCommand = reMeasureCommand ?? new DelegateCommand(obj =>
                {
                    //var Obj = ModObject as AlgoObjectBase;
                    //var cur = Obj.ModelParams[SystemModel.GetCurModel()] as Algo2PAlignFCICInspectModelParams;
                    //var tmp = Obj.ChangeParams as Algo2PAlignFCICInspectModelParams;

                    //cur_UpperLx /= (double)cur.Scale_UpperLx.Value;
                    //cur_UpperLy /= (double)cur.Scale_UpperLy.Value;
                    //cur_LowerLx /= (double)cur.Scale_LowerLx.Value;
                    //cur_LowerLy /= (double)cur.Scale_LowerLy.Value;
                    //cur_LowerRx /= (double)cur.Scale_LowerRx.Value;
                    //cur_LowerRy /= (double)cur.Scale_LowerRy.Value;

                    //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
                    //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
                    //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
                    //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
                    //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
                    //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;


                });

            }
        }
        #endregion


        #region [Override]
        public override void PrepareSave()
        {
            base.PrepareSave();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion


    }
}
