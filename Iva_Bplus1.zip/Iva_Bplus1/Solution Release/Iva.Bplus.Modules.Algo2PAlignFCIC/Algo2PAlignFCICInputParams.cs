﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo2PAlignFCIC
{
    [SerializableAttribute]
    class Algo2PAlignFCICInputParams : InputParams
    {
        #region Input P1, P2
        public IPointResult T1_L { get; set; }
        public IPointResult T1_R { get; set; }
        public IPointResult T2_L { get; set; }
        public IPointResult T2_R { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
