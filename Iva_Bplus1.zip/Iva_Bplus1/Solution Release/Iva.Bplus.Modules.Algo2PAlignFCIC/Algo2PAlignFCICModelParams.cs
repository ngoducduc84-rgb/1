﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo2PAlignFCIC
{
    [SerializableAttribute]

    public partial class Algo2PAlignFCICAlignModelParams : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        private AlgoParam t1_spec_Length;
        private AlgoParam t1_tor_Length;
        private AlgoParam t2_spec_Length;
        private AlgoParam t2_tor_Length;
        private AlgoParam scale_Length;

        //Mark Score
        private AlgoParam mark_P1_Score;
        private AlgoParam mark_P2_Score;

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        public AlgoParam T1_Spec_Length { get { return t1_spec_Length; } set { if (t1_spec_Length == value) return; t1_spec_Length = value; this.OnPropertyChanged(nameof(T1_Spec_Length)); } }
        public AlgoParam T1_Tor_Length { get { return t1_tor_Length; } set { if (t1_tor_Length == value) return; t1_tor_Length = value; this.OnPropertyChanged(nameof(T1_Tor_Length)); } }
        public AlgoParam T2_Spec_Length { get { return t2_spec_Length; } set { if (t2_spec_Length == value) return; t2_spec_Length = value; this.OnPropertyChanged(nameof(T2_Spec_Length)); } }
        public AlgoParam T2_Tor_Length { get { return t2_tor_Length; } set { if (t2_tor_Length == value) return; t2_tor_Length = value; this.OnPropertyChanged(nameof(T2_Tor_Length)); } }
        public AlgoParam Scale_Length { get { return scale_Length; } set { if (scale_Length == value) return; scale_Length = value; this.OnPropertyChanged(nameof(Scale_Length)); } }
        
        public AlgoParam Mark_P1_Score
        {
            get { return mark_P1_Score; }
            set { if (mark_P1_Score == value) return; mark_P1_Score = value;
                this.OnPropertyChanged(nameof(Mark_P1_Score));
            }
        }
        public AlgoParam Mark_P2_Score
        {
            get { return mark_P2_Score; }
            set { if (mark_P2_Score == value) return; mark_P2_Score = value;
                this.OnPropertyChanged(nameof(Mark_P2_Score));
            }
        }

        public Algo2PAlignFCICAlignModelParams()
            : base()
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);
            T1_Spec_Length = new AlgoParam("T1_Spec_Length", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)100);
            T1_Tor_Length = new AlgoParam("T1_Tor_Length", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)1);
            T2_Spec_Length = new AlgoParam("T2_Spec_Length", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)100);
            T2_Tor_Length = new AlgoParam("T2_Tor_Length", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)1);
            Scale_Length = new AlgoParam("Scale_Length", "mm", typeof(double), 0.0, "Length Scale", (double)0.5, (double)3);


            Mark_P1_Score = new AlgoParam("Mark_P1_Score", "%", typeof(double), 0.0, "Mark Point1 Score", (double)0.0, (double)100.0);
            Mark_P2_Score = new AlgoParam("Mark_P2_Score", "%", typeof(double), 0.0, "Mark Point2 Score", (double)0.0, (double)100.0);
        }
    }
}
