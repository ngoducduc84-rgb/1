﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo2PAlignFCIC
{
    [SerializableAttribute]
    public partial class Algo2PAlignFCICObject : AlgoObjectBase
    {
        #region [Fields]
        #region  Selected Caldata Name
        private string left_CalData;
        private string right_CalData;
        private string left_Display;
        private string right_Display;
        #endregion

        #region etc
        private CalcType calcType;
        private ThetaDirection thetaDirection;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        #endregion

        #region Align관련 Data
        private IPointResult markLeft;
        private IPointResult markRight;

        //private MatchingRstData markLeft;
        //private MatchingRstData markRight;
        private int typeIndex = 0;
        private XYT revAlign = new XYT();
        private XYT revUnload = new XYT();
        private double length = 0.0;
        private bool lastJudgement = true;
        #endregion
        public string schName = "";
        #endregion

        #region [properties]
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Left_CalData
        {
            get { return left_CalData; }
            set { if (left_CalData == value) return; left_CalData = value; this.OnPropertyChanged(nameof(Left_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Right_CalData
        {
            get { return right_CalData; }
            set { if (right_CalData == value) return; right_CalData = value; this.OnPropertyChanged(nameof(Right_CalData)); }
        }

        public CalDataObject Left_CalDataObj
        {
            get { return SystemObject_Common.GetObject(left_CalData) as CalDataObject; }
        }

        public CalDataObject Right_CalDataObj
        {
            get { return SystemObject_Common.GetObject(right_CalData) as CalDataObject; }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string Left_Display
        {
            get { return left_Display; }
            set { if (left_Display == value) return; left_Display = value; this.OnPropertyChanged(nameof(Left_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string Right_Display
        {
            get { return right_Display; }
            set { if (right_Display == value) return; right_Display = value; this.OnPropertyChanged(nameof(Right_Display)); }
        }
        public CogDisplayObject Left_DisplayObj
        {
            get { return SystemObject_Display.GetObject(Left_Display) as CogDisplayObject; }
        }
        public CogDisplayObject Right_DisplayObj
        {
            get { return SystemObject_Display.GetObject(right_Display) as CogDisplayObject; }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }

        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }


        public ObservableCollection<string> CalDataList
        {
            get
            {

                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }

        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        public double Length { get { return length; } }
        public bool LastJudgement { get { return lastJudgement; } }
        #endregion
        #endregion

        #region[Construct]
        public Algo2PAlignFCICObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo2PAlignFCICAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        //Line을 사용하기 위해서 추가. 하지만 IPointResult(?)
        public IPointResult GetRstData(string key)
        {
            IPointResult Rst = null;

            if (!InputValues.ContainsKey(key)) return Rst;

            if (InputValues[key] is MatchingRstData)
                Rst = InputValues[key] as MatchingRstData;
            else if (InputValues[key] is LineCrossRstData)
                Rst = InputValues[key] as LineCrossRstData;
            return Rst;
        }


        #region [Private Method]
        private bool AlignCalc()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudgement = true;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Mark Data Read& Confirm
            // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
            if (!InputValues.ContainsKey("T1_L") || !InputValues.ContainsKey("T1_R"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            //var Mark_T1L = InputValues["T1_L"] as MatchingRstData;
            //var Mark_T1R = InputValues["T1_R"] as MatchingRstData;
            //var Mark_T2L = InputValues["T2_L"] as MatchingRstData;
            //var Mark_T2R = InputValues["T2_R"] as MatchingRstData;

            //Line, Mark 어떤것을 사용할지 몰라 변경....
            var Mark_T1L = GetRstData("T1_L");
            var Mark_T1R = GetRstData("T1_R");
            var Mark_T2L = GetRstData("T2_L");
            var Mark_T2R = GetRstData("T2_R");



            // Type2는 없으면 무시
            if (Mark_T1L == null || Mark_T1R == null)
            {
             
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            if (Mark_T1L.RefPoints == null)
            {
                Mark_T1L.RefPoints = new List<XYT>();
                Mark_T1L.RefPoints.Add(new XYT(0, 0, 0));
            }
            if (Mark_T1R.RefPoints == null)
            {
                Mark_T1R.RefPoints = new List<XYT>();
                Mark_T1R.RefPoints.Add(new XYT(0, 0, 0));
            }
            if (Mark_T2L != null && Mark_T2L.RefPoints == null)
            {
                Mark_T2L.RefPoints = new List<XYT>();
                Mark_T2L.RefPoints.Add(new XYT(0, 0, 0));
            }
            if (Mark_T2R != null && Mark_T2R.RefPoints == null)
            {
                Mark_T2R.RefPoints = new List<XYT>();
                Mark_T2R.RefPoints.Add(new XYT(0, 0, 0));
            }
            #endregion

            #region Tape Type Selection
            // 혹시 모르니 일단 초기화
            markLeft = null;
            markRight = null;
            typeIndex = 0;

            // Type 1이 있으면 무조건 1 넣어라, 없으면 Type 2 확인, 그것도 없으면 Error
            if (Mark_T1L.SuccessIndex != -1 && Mark_T1R.SuccessIndex != -1)
            {
                markLeft = Mark_T1L;
                markRight = Mark_T1R;
                typeIndex = 1;
            }
            else if (Mark_T2L.SuccessIndex != -1 && Mark_T2R.SuccessIndex != -1)
            {
                markLeft = Mark_T2L;
                markRight = Mark_T2R;
                typeIndex = 2;
            }
            else            
            {
                errorCode = AlgoActionBase.Err_Mark_Not_Find;
                return false;
            }
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (Left_CalDataObj == null || Right_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                // Calibration 설정 안됨.
                return false;
            }
            var Robot_Left = Left_CalDataObj.GetV2R(model, new XY(markLeft.OutputXYT.X, markLeft.OutputXYT.Y));
            var Robot_Right = Right_CalDataObj.GetV2R(model, new XY(markRight.OutputXYT.X, markRight.OutputXYT.Y));

            var Robot_CAM_Left = new XY(0, 0);
            var Robot_CAM_Right = new XY(0, 0);

            var Robot_Ref_Left = Left_CalDataObj.GetV2R(model, new XY(markLeft.RefPoints[0].X, markLeft.RefPoints[0].Y));
            var Robot_Ref_Right = Right_CalDataObj.GetV2R(model, new XY(markRight.RefPoints[0].X, markRight.RefPoints[0].Y));

            var Coord_Left = Robot_Left + Left_CalDataObj.GetRotateCenter(model);
            var Coord_Right = Robot_Right + Right_CalDataObj.GetRotateCenter(model);

            var Coord_CAM_Left = Robot_CAM_Left + Left_CalDataObj.GetRotateCenter(model);
            var Coord_CAM_Right = Robot_CAM_Right + Right_CalDataObj.GetRotateCenter(model);

            var Coord_Ref_Left = Robot_Ref_Left + Left_CalDataObj.GetRotateCenter(model);
            var Coord_Ref_Right = Robot_Ref_Right + Right_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo2PAlignFCICAlignModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            var Limit = new XYT(limitX, limitY, limitT);
            var T1_spec_Length = (double)mParams.T1_Spec_Length.Value;
            var T1_tor_Length = (double)mParams.T1_Tor_Length.Value;
            var T2_spec_Length = (double)mParams.T2_Spec_Length.Value;
            var T2_tor_Length = (double)mParams.T2_Tor_Length.Value;
            var scale_Length = (double)mParams.Scale_Length.Value;

            var score_Mark1Point = (double)mParams.Mark_P1_Score.Value;
            var score_Mark2Point = (double)mParams.Mark_P2_Score.Value;

            #endregion

            #region Calc Rev Offset
            // 단변
            double camT = GetThetaColumn(Coord_CAM_Left.X, Coord_CAM_Right.X, Coord_CAM_Left.Y, Coord_CAM_Right.Y);
            double refT = GetThetaColumn(Coord_Ref_Left.X, Coord_Ref_Right.X, Coord_Ref_Left.Y, Coord_Ref_Right.Y);
            double pnlT = GetThetaColumn(Coord_Left.X, Coord_Right.X, Coord_Left.Y, Coord_Right.Y);

            pnlT -= camT;
            refT -= camT;
            camT = 0;

            var camTar = (Coord_CAM_Left + Coord_CAM_Right) / 2;
            var refTar = (Coord_Ref_Left + Coord_Ref_Right) / 2;
            var pnlObj = (Coord_Left + Coord_Right) / 2;

            var alignOffset = CvtPLCIO.OffsetXYT;

            var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
            var refTarxyt = new XYT(refTar.X, refTar.Y, refT);
            var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
            var camTarxyt_Un = new XYT(camTar.X, camTar.Y, camT);

            revAlign = new XYT();
            revUnload = new XYT();
            double radT, DriftX, DriftY;

            if (CalcType == CalcType.Center)
            {
                // Attach 위치 보정값 계산. 
                camTarxyt = ApplyTargetOffset(camTarxyt, alignOffset);
                radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revAlign.X = camTarxyt.X - DriftX;
                revAlign.Y = camTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else //역방향
                    revAlign.T = (radT / rad) * -1;

                // Unload 위치 보정값 계산 // 얘는 오프셋없음.    
                camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revUnload.X = camTarxyt_Un.X - DriftX;
                revUnload.Y = camTarxyt_Un.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revUnload.T = radT / rad;
                else //역방향
                    revUnload.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.Reference)
            {
                // Attach 위치 보정값 계산. 
                refTarxyt = ApplyTargetOffset(refTarxyt, alignOffset);
                radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revAlign.X = (refTarxyt.X - DriftX) * -1;
                revAlign.Y = (refTarxyt.Y - DriftY) * -1;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else  //역방향
                    revAlign.T = (radT / rad) * -1;

                // Unload 위치 보정값 계산 // 얘는 오프셋없음.    //CamCenter위치로
                camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revUnload.X = camTarxyt_Un.X - DriftX;
                revUnload.Y = camTarxyt_Un.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revUnload.T = radT / rad;
                else  //역방향
                    revUnload.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.PickUp)   //Target: 자재, Object: Reference
            {
                pnlObjxyt = ApplyTargetOffset(pnlObjxyt, alignOffset);
                radT = NormalizeTheta(pnlObjxyt.T - refTarxyt.T);
                DriftX = Math.Cos(radT) * refTarxyt.X - Math.Sin(radT) * refTarxyt.Y;
                DriftY = Math.Sin(radT) * refTarxyt.X + Math.Cos(radT) * refTarxyt.Y;
                revAlign.X = pnlObjxyt.X - DriftX;
                revAlign.Y = pnlObjxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else  //역방향
                    revAlign.T = (radT / rad) * -1;

            }
            #endregion

            #region Confirm Result (Align Spec Over Check)
            if (!ConfirmResult(revAlign, Limit))
            {
                Left_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Right_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                lastJudgement = false;
            }
            #endregion

            #region Calc Length & Confirm (Length Check)
            length = GetLength(Coord_Left, Coord_Right);
            if (typeIndex == 1)
            {
                if (T1_spec_Length != 0)
                {
                    if (Math.Abs(T1_spec_Length - length) > T1_tor_Length)
                    {
                        lastJudgement = false;
                        errorCode = AlgoActionBase.Err_Length_Check;
                        Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    }
                }
            }
            else
            {
                if (T2_spec_Length != 0)
                {
                    if (Math.Abs(T2_spec_Length - length) > T2_tor_Length)
                    {
                        lastJudgement = false;
                        errorCode = AlgoActionBase.Err_Length_Check;
                        Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    }
                }
            }
            #endregion

            #region Score_Spec Ng Score는동일한기준이여서 T1,T2 구분안함
            if (score_Mark1Point != 0)
            {
                if (Mark_T1L.Score < score_Mark1Point || Mark_T2L.Score < score_Mark1Point)
                {
                    lastJudgement = false;
                    errorCode = AlgoActionBase.Err_Mark_Score_Check;
                    Left_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                    Right_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                }
            }
            if (score_Mark2Point != 0)
            {
                if (Mark_T1R.Score < score_Mark2Point || Mark_T2R.Score < score_Mark2Point)
                {
                    lastJudgement = false;
                    errorCode = AlgoActionBase.Err_Mark_Score_Check;
                    Left_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                    Right_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                }
            }
            #endregion


            #region Inspection Result Image Save (L_Check)
            if (Left_DisplayObj.Judgement != (uint)Judgement.OK && Left_DisplayObj.Judgement != (uint)Judgement.None) //LeftDisplay 로만 비교... Score도 Left,RightDISP Judgement 판단
            {
                Task.Factory.StartNew(() =>
                {
                    string _sourceID = DeepClone(sourceID);
                    DateTime dateTime = DateTime.Now;
                    string _judgement = "";

                    foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
                    {
                        if (Left_DisplayObj.Judgement == (uint)j)
                        {
                            _judgement = j.ToString();
                            break;
                        }
                    }

                    object obj = (Bitmap)Left_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                    Left_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);
                    object obj2 = (Bitmap)Right_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                    Right_DisplayObj.SaveImage(dateTime, obj2, _judgement, schName, _sourceID, true);

                    object obj3 = Left_DisplayObj.GetCurImage();
                    Left_DisplayObj.SaveImage(dateTime, obj3, _judgement, schName, _sourceID, false);
                    object obj4 = Right_DisplayObj.GetCurImage();
                    Right_DisplayObj.SaveImage(dateTime, obj4, _judgement, schName, _sourceID, false);
                });
            }
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo2PAlignFCICResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Offset1X = Math.Round(revAlign.X, 3),
                Offset1Y = Math.Round(revAlign.Y, 3),
                Offset1T = Math.Round(revAlign.T, 3),

                Offset2X = Math.Round(revUnload.X, 3),
                Offset2Y = Math.Round(revUnload.Y, 3),
                Offset2T = Math.Round(revUnload.T, 3),

                TypeIndex = typeIndex,
                Length = Math.Round(length, 3),
                Result = lastJudgement,
                
                PL_X = Math.Round(markLeft.OutputXYT.X, 3),  //Mark Pixel 좌표
                PL_Y = Math.Round(markLeft.OutputXYT.Y, 3),
                PR_X = Math.Round(markRight.OutputXYT.X, 3),
                PR_Y = Math.Round(markRight.OutputXYT.Y, 3),
                
                CL_X = Math.Round(Coord_Left.X, 3),
                CL_Y = Math.Round(Coord_Left.Y, 3),
                CR_X = Math.Round(Coord_Right.X, 3),
                CR_Y = Math.Round(Coord_Right.Y, 3),

                Type = CalcType.ToString(),
                Pnl_T = Math.Round(pnlT, 3),
                Ref_T = Math.Round(refT, 3),
                Cam_T = Math.Round(camT, 3),    //camT=0인데 의미가 있나

                PLC_OffsetX = alignOffset.X,
                PLC_OffsetY = alignOffset.Y,
                PLC_OffsetT = alignOffset.T,

                Score_P1 = Math.Round(markLeft.Score, 2),
                Score_P2 = Math.Round(markRight.Score, 2),
            };
            #endregion
            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            //#endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO(revAlign, revUnload, typeIndex, "", markLeft , markRight);
            #endregion
            return lastJudgement;
        }


        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }
            else
                return true;
        }
        public void WriteVisionIO(object rev1, object rev2, int _typeIndex, string ID, IPointResult _Mark_P1, IPointResult _Mark_P2)
        {

            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["Tape_T"].NextValue = _typeIndex; IOs.Add(VisionValues["Tape_T"]);
                    VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                    VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                    VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                    VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                    VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                    VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                    VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);

    
                    VisionValues["FDC_Obj_Mark_1_X"].NextValue = (double)Math.Round(markLeft.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Obj_Mark_1_X"]);
                    VisionValues["FDC_Obj_Mark_1_Y"].NextValue = (double)Math.Round(markLeft.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Obj_Mark_1_Y"]);
                    VisionValues["FDC_Obj_Mark_1_S"].NextValue = (int)(Math.Round(markLeft.Score, 2) * 100); IOs.Add(VisionValues["FDC_Obj_Mark_1_S"]);

                    VisionValues["FDC_Obj_Mark_2_X"].NextValue = (double)Math.Round(markRight.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Obj_Mark_2_X"]);
                    VisionValues["FDC_Obj_Mark_2_Y"].NextValue = (double)Math.Round(markRight.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Obj_Mark_2_Y"]);
                    VisionValues["FDC_Obj_Mark_2_S"].NextValue = (int)(Math.Round(markRight.Score, 2) * 100); IOs.Add(VisionValues["FDC_Obj_Mark_2_S"]); 


                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    break;

            }

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }
        #endregion
    }
}

