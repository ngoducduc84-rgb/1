﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo2PAlignFCIC
{
    class Algo2PAlignFCICOutputParams : OutputParams
    {
        #region Convert
        public object ConvertXYT { get; set; }

        #endregion


        #region Logging
        public object Result { get; set; }
        #endregion
    }
}
