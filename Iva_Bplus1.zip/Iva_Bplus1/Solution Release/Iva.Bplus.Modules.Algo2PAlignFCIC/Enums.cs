﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo2PAlignFCIC
{
    public enum CalcType { Center, Reference, PickUp }
    public enum ThetaDirection { Normal, Reverse }
    public enum GrabPos { P1, P2 }
}

