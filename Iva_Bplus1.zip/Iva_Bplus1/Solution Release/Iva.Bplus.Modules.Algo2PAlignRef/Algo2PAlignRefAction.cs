﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo2PAlignRef;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAlignRef
{
    [SerializableAttribute]
    public partial class Algo2PAlignRefAction : AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private bool useUnloadOffset;
        [field: NonSerialized]
        private double cur_UpperLx;
        [field: NonSerialized]
        private double cur_UpperLy;
        [field: NonSerialized]
        private double cur_LowerLx;
        [field: NonSerialized]
        private double cur_LowerLy;
        [field: NonSerialized]
        private double cur_LowerRx;
        [field: NonSerialized]
        private double cur_LowerRy;

        [field: NonSerialized]
        private bool judge_UpperLx;
        [field: NonSerialized]
        private bool judge_UpperLy;
        [field: NonSerialized]
        private bool judge_LowerLx;
        [field: NonSerialized]
        private bool judge_LowerLy;
        [field: NonSerialized]
        private bool judge_LowerRx;
        [field: NonSerialized]
        private bool judge_LowerRy;
        [field: NonSerialized]
        private bool judge_Upper;
        [field: NonSerialized]
        private bool judge_Right;

        [field: NonSerialized]
        private AlgoParam temp_UpperLx;
        [field: NonSerialized]
        private AlgoParam temp_UpperLy;
        [field: NonSerialized]
        private AlgoParam temp_LowerLx;
        [field: NonSerialized]
        private AlgoParam temp_LowerLy;
        [field: NonSerialized]
        private AlgoParam temp_LowerRx;
        [field: NonSerialized]
        private AlgoParam temp_LowerRy;
        #endregion

        #region [Properties]   
        public bool UseUnloadOffset { get { return useUnloadOffset; } set { if (useUnloadOffset == value) return; useUnloadOffset = value; this.OnPropertyChanged(nameof(UseUnloadOffset)); } }
        public double Cur_UpperLx { get { return cur_UpperLx; } set { if (cur_UpperLx == value) return; cur_UpperLx = value; this.OnPropertyChanged(nameof(Cur_UpperLx)); } }
        public double Cur_UpperLy { get { return cur_UpperLy; } set { if (cur_UpperLy == value) return; cur_UpperLy = value; this.OnPropertyChanged(nameof(Cur_UpperLy)); } }
        public double Cur_LowerLx { get { return cur_LowerLx; } set { if (cur_LowerLx == value) return; cur_LowerLx = value; this.OnPropertyChanged(nameof(Cur_LowerLx)); } }
        public double Cur_LowerLy { get { return cur_LowerLy; } set { if (cur_LowerLy == value) return; cur_LowerLy = value; this.OnPropertyChanged(nameof(Cur_LowerLy)); } }
        public double Cur_LowerRx { get { return cur_LowerRx; } set { if (cur_LowerRx == value) return; cur_LowerRx = value; this.OnPropertyChanged(nameof(Cur_LowerRx)); } }
        public double Cur_LowerRy { get { return cur_LowerRy; } set { if (cur_LowerRy == value) return; cur_LowerRy = value; this.OnPropertyChanged(nameof(Cur_LowerRy)); } }
        public bool Judge_UpperLx { get { return judge_UpperLx; } set { if (judge_UpperLx == value) return; judge_UpperLx = value; this.OnPropertyChanged(nameof(Judge_UpperLx)); } }
        public bool Judge_UpperLy { get { return judge_UpperLy; } set { if (judge_UpperLy == value) return; judge_UpperLy = value; this.OnPropertyChanged(nameof(Judge_UpperLy)); } }
        public bool Judge_LowerLx { get { return judge_LowerLx; } set { if (judge_LowerLx == value) return; judge_LowerLx = value; this.OnPropertyChanged(nameof(Judge_LowerLx)); } }
        public bool Judge_LowerLy { get { return judge_LowerLy; } set { if (judge_LowerLy == value) return; judge_LowerLy = value; this.OnPropertyChanged(nameof(Judge_LowerLy)); } }
        public bool Judge_LowerRx { get { return judge_LowerRx; } set { if (judge_LowerRx == value) return; judge_LowerRx = value; this.OnPropertyChanged(nameof(Judge_LowerRx)); } }
        public bool Judge_LowerRy { get { return judge_LowerRy; } set { if (judge_LowerRy == value) return; judge_LowerRy = value; this.OnPropertyChanged(nameof(Judge_LowerRy)); } }
        public bool Judge_Upper { get { return judge_Upper; } set { if (judge_Upper == value) return; judge_Upper = value; this.OnPropertyChanged(nameof(Judge_Upper)); } }
        public bool Judge_Right { get { return judge_Right; } set { if (judge_Right == value) return; judge_Right = value; this.OnPropertyChanged(nameof(Judge_Right)); } }


        public AlgoParam Temp_UpperLx { get { return temp_UpperLx; } set { if (temp_UpperLx == value) return; temp_UpperLx = value; this.OnPropertyChanged(nameof(Temp_UpperLx)); } }
        public AlgoParam Temp_UpperLy { get { return temp_UpperLy; } set { if (temp_UpperLy == value) return; temp_UpperLy = value; this.OnPropertyChanged(nameof(Temp_UpperLy)); } }
        public AlgoParam Temp_LowerLx { get { return temp_LowerLx; } set { if (temp_LowerLx == value) return; temp_LowerLx = value; this.OnPropertyChanged(nameof(Temp_LowerLx)); } }
        public AlgoParam Temp_LowerLy { get { return temp_LowerLy; } set { if (temp_LowerLy == value) return; temp_LowerLy = value; this.OnPropertyChanged(nameof(Temp_LowerLy)); } }
        public AlgoParam Temp_LowerRx { get { return temp_LowerRx; } set { if (temp_LowerRx == value) return; temp_LowerRx = value; this.OnPropertyChanged(nameof(Temp_LowerRx)); } }
        public AlgoParam Temp_LowerRy { get { return temp_LowerRy; } set { if (temp_LowerRy == value) return; temp_LowerRy = value; this.OnPropertyChanged(nameof(Temp_LowerRy)); } }

        #endregion

        #region [Construct]
        public Algo2PAlignRefAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo2PAlignRefInputParams();
            OutputParams = new Algo2PAlignRefOutputParams();

            var obj = _object as Algo2PAlignRefObject;
            obj.ModelParamType = typeof(Algo2PAlignRefAlignModelParams);
            var param = obj.CurParams as Algo2PAlignRefAlignModelParams;

            //ChildSettingView = new AlignSetting();
            //ChildSettingView.DataContext = this;
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as Algo2PAlignRefObject;


            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                bool bRst = Obj.Run();

                OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                Obj.WriteVisionIO(Obj.RevAlign, GetImageID());

                if (!bRst)
                    OccurError(Obj.ErrorCode);

                Obj.AppendMessage(Name, "Caluration Complete");
                #endregion
                StopTimer();
            }
            return End(false);
        }

        #endregion

        #region [Command]
        [field: NonSerialized]
        private DelegateCommand scaleResetCommand;
        public DelegateCommand ScaleResetCommand
        {
            get
            {
                return scaleResetCommand = scaleResetCommand ?? new DelegateCommand(obj =>
                {
                    //var Obj = modObject as AlgoObjectBase;
                    //var tmp = Obj.TempParams as Algo2PAlignInspectModelParams;
                    //var cur = Obj.ModelParams[SystemModel.GetCurModel()] as Algo2PAlignInspectModelParams;

                    //tmp.Scale_UpperLx.Value = (double)1.0;
                    //tmp.Scale_UpperLy.Value = (double)1.0;
                    //tmp.Scale_LowerLx.Value = (double)1.0;
                    //tmp.Scale_LowerLy.Value = (double)1.0;
                    //tmp.Scale_LowerRx.Value = (double)1.0;
                    //tmp.Scale_LowerRy.Value = (double)1.0;


                    //cur_UpperLx /= (double)cur.Scale_UpperLx.Value;
                    //cur_UpperLy /= (double)cur.Scale_UpperLy.Value;
                    //cur_LowerLx /= (double)cur.Scale_LowerLx.Value;
                    //cur_LowerLy /= (double)cur.Scale_LowerLy.Value;
                    //cur_LowerRx /= (double)cur.Scale_LowerRx.Value;
                    //cur_LowerRy /= (double)cur.Scale_LowerRy.Value;

                    //Obj.UpdateTempValues();

                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand scaleCalcCommand;
        public DelegateCommand ScaleCalcCommand
        {
            get
            {
                return scaleCalcCommand = scaleCalcCommand ?? new DelegateCommand(obj =>
                {
                    //var Obj = modObject as AlgoObjectBase;
                    //var tmp = Obj.TempParams as Algo2PAlignInspectModelParams;

                    //var upperLx = (double)temp_UpperLx.Value;
                    //var upperLy = (double)temp_UpperLy.Value;
                    //var lowerLx = (double)temp_LowerLx.Value;
                    //var lowerLy = (double)temp_LowerLy.Value;
                    //var lowerRx = (double)temp_LowerRx.Value;
                    //var lowerRy = (double)temp_LowerRy.Value;

                    //var spec_upperLx = (double)tmp.Spec_UpperLx.Value;
                    //var spec_upperLy = (double)tmp.Spec_UpperLy.Value;
                    //var spec_lowerLx = (double)tmp.Spec_LowerLx.Value;
                    //var spec_lowerLy = (double)tmp.Spec_LowerLy.Value;
                    //var spec_lowerRx = (double)tmp.Spec_LowerRx.Value;
                    //var spec_lowerRy = (double)tmp.Spec_LowerRy.Value;

                    //double range = 2;
                    //if (!AlgoObjectBase.ConfirmTempValue(upperLx, spec_upperLx, range)) { RadWindow.Alert(string.Format("Check input value![UpperLx :{0}][Range {1} ~ {2}]", upperLx, spec_upperLx - range, spec_upperLx + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(upperLy, spec_upperLy, range)) { RadWindow.Alert(string.Format("Check input value![UpperLy :{0}][Range {1} ~ {2}]", upperLy, spec_upperLy - range, spec_upperLy + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(lowerLx, spec_lowerLx, range)) { RadWindow.Alert(string.Format("Check input value![LowerLx :{0}][Range {1} ~ {2}]", lowerLx, spec_lowerLx - range, spec_lowerLx + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(lowerLy, spec_lowerLy, range)) { RadWindow.Alert(string.Format("Check input value![LowerLy :{0}][Range {1} ~ {2}]", lowerLy, spec_lowerLy - range, spec_lowerLy + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(lowerRx, spec_lowerRx, range)) { RadWindow.Alert(string.Format("Check input value![LowerRx :{0}][Range {1} ~ {2}]", lowerRx, spec_lowerRx - range, spec_lowerRx + range)); return; }
                    //if (!AlgoObjectBase.ConfirmTempValue(lowerRy, spec_lowerRy, range)) { RadWindow.Alert(string.Format("Check input value![LowerRy :{0}][Range {1} ~ {2}]", lowerRy, spec_lowerRy - range, spec_lowerRy + range)); return; }

                    //tmp.Scale_UpperLx.Value = upperLx / cur_UpperLx;
                    //tmp.Scale_UpperLy.Value = upperLy / cur_UpperLy;
                    //tmp.Scale_LowerLx.Value = lowerLx / cur_LowerLx;
                    //tmp.Scale_LowerLy.Value = lowerLy / cur_LowerLy;
                    //tmp.Scale_LowerRx.Value = lowerRx / cur_LowerRx;
                    //tmp.Scale_LowerRy.Value = lowerRy / cur_LowerRy;

                    //Obj.UpdateTempValues();


                    //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
                    //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
                    //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
                    //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
                    //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
                    //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;


                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand reMeasureCommand;
        public DelegateCommand ReMeasureCommand
        {
            get
            {
                return reMeasureCommand = reMeasureCommand ?? new DelegateCommand(obj =>
                {
                    //var Obj = ModObject as AlgoObjectBase;
                    //var cur = Obj.ModelParams[SystemModel.GetCurModel()] as Algo2PAlignInspectModelParams;
                    //var tmp = Obj.ChangeParams as Algo2PAlignInspectModelParams;

                    //cur_UpperLx /= (double)cur.Scale_UpperLx.Value;
                    //cur_UpperLy /= (double)cur.Scale_UpperLy.Value;
                    //cur_LowerLx /= (double)cur.Scale_LowerLx.Value;
                    //cur_LowerLy /= (double)cur.Scale_LowerLy.Value;
                    //cur_LowerRx /= (double)cur.Scale_LowerRx.Value;
                    //cur_LowerRy /= (double)cur.Scale_LowerRy.Value;

                    //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
                    //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
                    //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
                    //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
                    //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
                    //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;


                });

            }
        }
        #endregion


        #region [Override]
        public override void PrepareSave()
        {
            base.PrepareSave();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion

    }
}
