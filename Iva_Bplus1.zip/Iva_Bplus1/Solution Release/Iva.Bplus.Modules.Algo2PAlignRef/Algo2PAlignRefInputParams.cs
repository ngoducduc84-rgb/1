﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo2PAlignRef
{
    [SerializableAttribute]
    class Algo2PAlignRefInputParams : InputParams
    {
        #region Input Buffer_P1, Buffer_P2, JIG_P1, JIG_P2
        public IPointResult Buffer_P1 { get; set; }
        public IPointResult Buffer_P2 { get; set; }
        public IPointResult JIG_P1 { get; set; }
        public IPointResult JIG_P2 { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
