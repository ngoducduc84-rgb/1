﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo2PAlignRef
{
    [SerializableAttribute]

    public partial class Algo2PAlignRefAlignModelParams : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        private AlgoParam spec_bufLength;
        private AlgoParam tor_bufLength;
        private AlgoParam scale_bufLength;
        private AlgoParam spec_jigLength;
        private AlgoParam tor_jigLength;
        private AlgoParam scale_jigLength;
        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        public AlgoParam Spec_BufLength { get { return spec_bufLength; } set { if (spec_bufLength == value) return; spec_bufLength = value; this.OnPropertyChanged(nameof(Spec_BufLength)); } }
        public AlgoParam Tor_BufLength { get { return tor_bufLength; } set { if (tor_bufLength == value) return; tor_bufLength = value; this.OnPropertyChanged(nameof(Tor_BufLength)); } }
        public AlgoParam Scale_BufLength { get { return scale_bufLength; } set { if (scale_bufLength == value) return; scale_bufLength = value; this.OnPropertyChanged(nameof(Scale_BufLength)); } }
        public AlgoParam Spec_JigLength { get { return spec_jigLength; } set { if (spec_jigLength == value) return; spec_jigLength = value; this.OnPropertyChanged(nameof(Spec_JigLength)); } }
        public AlgoParam Tor_JigLength { get { return tor_jigLength; } set { if (tor_jigLength == value) return; tor_jigLength = value; this.OnPropertyChanged(nameof(Tor_JigLength)); } }
        public AlgoParam Scale_JigLength { get { return scale_jigLength; } set { if (scale_jigLength == value) return; scale_jigLength = value; this.OnPropertyChanged(nameof(Scale_JigLength)); } }


        public Algo2PAlignRefAlignModelParams()
            : base()
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);
            Spec_BufLength = new AlgoParam("Spec_BufLength", "mm", typeof(double), 0.0, "Length_Buffer Spec(Mark To Mark)", (double)0, (double)1000);
            Tor_BufLength = new AlgoParam("Tor_BufLength", "mm", typeof(double), 0.0, "Length_Buffer Tolerance", (double)0, (double)5);
            Scale_BufLength = new AlgoParam("Scale_BufLength", "mm", typeof(double), 0.0, "Length_Buffer Scale", (double)0, (double)5);
            Spec_JigLength = new AlgoParam("Spec_JigLength", "mm", typeof(double), 0.0, "Length_Jig Spec(Mark To Mark)", (double)0, (double)1000);
            Tor_JigLength = new AlgoParam("Tor_JigLength", "mm", typeof(double), 0.0, "Length_Jig Tolerance", (double)0, (double)5);
            Scale_JigLength = new AlgoParam("Scale_JigLength", "mm", typeof(double), 0.0, "Length_Jig Scale", (double)0, (double)5);
        }
    }
}
