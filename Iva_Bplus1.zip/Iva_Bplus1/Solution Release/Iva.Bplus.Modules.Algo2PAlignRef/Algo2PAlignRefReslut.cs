﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAlignRef
{
    [SerializableAttribute]
    public class Algo2PAlignRefResult : AlgoResultBase
    {
        #region [fiedls]
        private double offset1X;
        private double offset1Y;
        private double offset1T;

        private double FPCBlength;
        private double Jiglength;
        private double spec_FPCBlength;
        private double spec_Jiglength;
        private double tor_FPCBlength;
        private double tor_Jiglength;
        private bool result;
        private int unitNumber;
        private int jigRefNumber;

        private double bufferPosX;
        private double bufferPosY;
        private double bufferPosT;
                   
        private double bufferPosRefX;
        private double bufferPosRefY;
        private double bufferPosRefT;

        private double jigPosX;
        private double jigPosY;
        private double jigPosT;
                       
        private double jigPosRefX;
        private double jigPosRefY;
        private double jigPosRefT;

        private double p1_X_Tar;
        private double p1_Y_Tar;
        private double p2_X_Tar;
        private double p2_Y_Tar;

        private double p1_X_Obj;
        private double p1_Y_Obj;
        private double p2_X_Obj;
        private double p2_Y_Obj;

        private double driftX;
        private double driftY;



        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double Offset1X
        {
            get { return offset1X; }
            set { if (value == offset1X) return; offset1X = value; OnPropertyChanged(nameof(Offset1X)); }
        }
        public double Offset1Y
        {
            get { return offset1Y; }
            set { if (value == offset1Y) return; offset1Y = value; OnPropertyChanged(nameof(Offset1Y)); }
        }
        public double Offset1T
        {
            get { return offset1T; }
            set { if (value == offset1T) return; offset1T = value; OnPropertyChanged(nameof(Offset1T)); }
        }
        public double FPCBLength
        {
            get { return FPCBlength; }
            set { if (value == FPCBlength) return; FPCBlength = value; OnPropertyChanged(nameof(FPCBLength)); }
        }
        public double JigLength
        {
            get { return Jiglength; }
            set { if (value == Jiglength) return; Jiglength = value; OnPropertyChanged(nameof(JigLength)); }
        }
        public double Spec_FPCBLength
        {
            get { return spec_FPCBlength; }
            set { if (value == spec_FPCBlength) return; spec_FPCBlength = value; OnPropertyChanged(nameof(Spec_FPCBLength)); }
        }
        public double Spec_JigLength
        {
            get { return spec_Jiglength; }
            set { if (value == spec_Jiglength) return; spec_Jiglength = value; OnPropertyChanged(nameof(Spec_JigLength)); }
        }
        public double Tor_FPCBLength
        {
            get { return tor_FPCBlength; }
            set { if (value == tor_FPCBlength) return; tor_FPCBlength = value; OnPropertyChanged(nameof(Tor_FPCBLength)); }
        }
        public double Tor_JigLength
        {
            get { return tor_Jiglength; }
            set { if (value == tor_Jiglength) return; tor_Jiglength = value; OnPropertyChanged(nameof(Tor_JigLength)); }
        }

        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public int UnitNumber
        {
            get { return unitNumber; }
            set { if (value == unitNumber) return; unitNumber = value; OnPropertyChanged(nameof(UnitNumber)); }
        }
        public int JigRefNumber
        {
            get { return jigRefNumber; }
            set { if (value == jigRefNumber) return; jigRefNumber = value; OnPropertyChanged(nameof(JigRefNumber)); }
        }
        public double BufferPosX
        {
            get { return bufferPosX; }
            set { if (value == bufferPosX) return; bufferPosX = value; OnPropertyChanged(nameof(BufferPosX)); }
        }
        public double BufferPosY
        {
            get { return bufferPosY; }
            set { if (value == bufferPosY) return; bufferPosY = value; OnPropertyChanged(nameof(BufferPosY)); }
        }
        public double BufferPosT
        {
            get { return bufferPosT; }
            set { if (value == bufferPosT) return; bufferPosT = value; OnPropertyChanged(nameof(BufferPosT)); }
        }
        public double BufferPosRefX
        {
            get { return bufferPosRefX; }
            set { if (value == bufferPosRefX) return; bufferPosRefX = value; OnPropertyChanged(nameof(BufferPosRefX)); }
        }
        public double BufferPosRefY
        {
            get { return bufferPosRefY; }
            set { if (value == bufferPosRefY) return; bufferPosRefY = value; OnPropertyChanged(nameof(BufferPosRefY)); }
        }
        public double BufferPosRefT
        {
            get { return bufferPosRefT; }
            set { if (value == bufferPosRefT) return; bufferPosRefT = value; OnPropertyChanged(nameof(BufferPosRefT)); }
        }
        public double JigPosX
        {
            get { return jigPosX; }
            set { if (value == jigPosX) return; jigPosX = value; OnPropertyChanged(nameof(JigPosX)); }
        }
        public double JigPosY
        {
            get { return jigPosY; }
            set { if (value == jigPosY) return; jigPosY = value; OnPropertyChanged(nameof(JigPosY)); }
        }
        public double JigPosT
        {
            get { return jigPosT; }
            set { if (value == jigPosT) return; jigPosT = value; OnPropertyChanged(nameof(JigPosT)); }
        }
        public double JigPosRefX
        {
            get { return jigPosRefX; }
            set { if (value == jigPosRefX) return; jigPosRefX = value; OnPropertyChanged(nameof(JigPosRefX)); }
        }
        public double JigPosRefY
        {
            get { return jigPosRefY; }
            set { if (value == jigPosRefY) return; jigPosRefY = value; OnPropertyChanged(nameof(JigPosRefY)); }
        }
        public double JigPosRefT
        {
            get { return jigPosRefT; }
            set { if (value == jigPosRefT) return; jigPosRefT = value; OnPropertyChanged(nameof(JigPosRefT)); }
        }
        public double P1_X_Tar
        {
            get { return p1_X_Tar; }
            set { if (value == p1_X_Tar) return; p1_X_Tar = value; OnPropertyChanged(nameof(P1_X_Tar)); }
        }
        public double P1_Y_Tar
        {
            get { return p1_Y_Tar; }
            set { if (value == p1_Y_Tar) return; p1_Y_Tar = value; OnPropertyChanged(nameof(P1_Y_Tar)); }
        }
        public double P2_X_Tar
        {
            get { return p2_X_Tar; }
            set { if (value == p2_X_Tar) return; p2_X_Tar = value; OnPropertyChanged(nameof(P2_X_Tar)); }
        }
        public double P2_Y_Tar
        {
            get { return p2_Y_Tar; }
            set { if (value == p2_Y_Tar) return; p2_Y_Tar = value; OnPropertyChanged(nameof(P2_Y_Tar)); }
        }
        public double P1_X_Obj
        {
            get { return p1_X_Obj; }
            set { if (value == p1_X_Obj) return; p1_X_Obj = value; OnPropertyChanged(nameof(P1_X_Obj)); }
        }
        public double P1_Y_Obj
        {
            get { return p1_Y_Obj; }
            set { if (value == p1_Y_Obj) return; p1_Y_Obj = value; OnPropertyChanged(nameof(P1_Y_Obj)); }
        }
        public double P2_X_Obj
        {
            get { return p2_X_Obj; }
            set { if (value == p2_X_Obj) return; p2_X_Obj = value; OnPropertyChanged(nameof(P2_X_Obj)); }
        }
        public double P2_Y_Obj
        {
            get { return p2_Y_Obj; }
            set { if (value == p2_Y_Obj) return; p2_Y_Obj = value; OnPropertyChanged(nameof(P2_Y_Obj)); }
        }
        public double DriftX
        {
            get { return driftX; }
            set { if (value == driftX) return; driftX = value; OnPropertyChanged(nameof(DriftX)); }
        }
        public double DriftY
        {
            get { return driftY; }
            set { if (value == driftY) return; driftY = value; OnPropertyChanged(nameof(DriftY)); }
        }
        #endregion


        public Algo2PAlignRefResult() : base() { }

        public override string ToString()
        {
            //return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
            //                      "offset1X: {3},\noffset1Y: {4},\noffset1T: {5},\n" +
            //                      "offset2X: {6},\noffset2Y: {7},\nFPCBlength: {8},\n" +
            //                      "Jiglength: {9},\nResult: {10},\n" +
            //                      "bufferPosX: {11},\nbufferPosY: {12},\nbufferPosT: {13},\nbufferPosRefX: {14},\n" +
            //                      "bufferPosRefY: {15},\nbufferPosRefT: {16},\njigPosX: {17},\njigPosY: {18},\n" +
            //                      "jigPosT: {19},\njigPosRefX: {20},\njigPosRefY: {21},\njigPosRefT: {22},\n" +
            //                      "p1_X_Tar: {23},\np1_Y_Tar: {24},\np2_X_Tar: {25},\np2_Y_Tar: {26},\n" +
            //                      "p1_X_Obj: {27},\np1_Y_Obj: {28},\np2_X_Obj: {29},\np2_Y_Obj: {30},\n" +
            //                      "type: {31}\n"
            //                      , typeof(Algo2PAlignRefResult).ToString(), curTime, curDate
            //                      , offset1X, offset1Y, offset1T
            //                      , FPCBlength, Jiglength
            //                      , result
            //                      , bufferPosX, bufferPosY, bufferPosT
            //                      , bufferPosRefX, bufferPosRefY, bufferPosRefT
            //                      , jigPosX, jigPosY, jigPosT
            //                      , jigPosRefX, jigPosRefY, jigPosRefT
            //                      , p1_X_Tar, p1_Y_Tar, p2_X_Tar, p2_Y_Tar
            //                      , p1_X_Obj, p1_Y_Obj, p2_X_Obj, p2_Y_Obj
            //                      );
            return "";
        }

    }
}
