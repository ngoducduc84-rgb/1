﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo2PAlignRef_IT
{
    [SerializableAttribute]
    public partial class Algo2PAlignRef_ITObject : AlgoObjectBase
    {
        #region [Fields]      
        private ONOFF isSkipError = ONOFF.OFF;
        //private RefIndexType refindexType = RefIndexType.UnitNum;
        private ThetaDirection thetaDirection;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;

        #region  recent Caldata Name
        private MatchingRstData recentMark1_Tar;
        private MatchingRstData recentMark2_Tar;
        private CalDataObject recentJigCalData;
        #endregion

        #region  Selected Caldata Name
        private string buffer_CalData;
        private string jig_CalData;
        #endregion

        #region Seleced Caldata Object
        private CalDataObject buffer_CalDataObj;
        private CalDataObject jig_CalDataObj;
        #endregion

        #region Align관련 Data
        XYT revAlign = new XYT();
        XYT revUnload = new XYT();
        double FPCBlength = 0.0;
        double Jiglength = 0.0;
        //int unitNum = 0;
        //int jigUnitNum = 0;
        #endregion

        #endregion

        #region [properties]
        public MatchingRstData RecentMark1_Tar
        {
            get
            {
                if (recentMark1_Tar == null)
                {
                    recentMark1_Tar = new MatchingRstData();
                }
                return recentMark1_Tar;
            }
            set
            {
                recentMark1_Tar = value;
            }
        }
        public MatchingRstData RecentMark2_Tar
        {
            get
            {
                if (recentMark2_Tar == null)
                {
                    recentMark2_Tar = new MatchingRstData();
                }
                return recentMark2_Tar;
            }
            set
            {
                recentMark2_Tar = value;
            }
        }

        //Jig Mark Error에 대한 recent value 사용 여부 function
        public ONOFF IsSkipError
        {
            get { return isSkipError; }
            set { if (isSkipError == value) return; isSkipError = value; this.OnPropertyChanged(nameof(IsSkipError)); }
        }
        #region etc
        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }
        //public RefIndexType RefindexType
        //{
        //    get { return refindexType; }
        //    set { if (refindexType == value) return; refindexType = value; this.OnPropertyChanged(nameof(RefindexType)); }
        //}

        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Buffer_CalData
        {
            get { return buffer_CalData; }
            set
            {
                buffer_CalData = value;
                buffer_CalDataObj = SystemObject_Common.GetObject(buffer_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Buffer_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Jig_CalData
        {
            get { return jig_CalData; }
            set
            {
                jig_CalData = value;
                jig_CalDataObj = SystemObject_Common.GetObject(jig_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Jig_CalData));
            }
        }
        #endregion

        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        public double FPCBLength { get { return FPCBlength; } }
        public double JigLength { get { return Jiglength; } }
        #endregion
        #endregion

        #region[Construct]
        public Algo2PAlignRef_ITObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));
            recentJigCalData = new CalDataObject();

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo2PAlignRef_ITAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool AlignCalc()
        {
            AlgoRst = new Algo2PAlignRef_ITResult(); //Link 안되었을때 또는 처음 Mark 실패했을 경우 Exception 방지용

            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
            AssignPLCData();
            sourceID = "U" + CvtPLCIO.UnitNo.ToString() + "_" + sourceID;
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Buffer_P1") || !InputValues.ContainsKey("Buffer_P2") || !InputValues.ContainsKey("JIG_P1") || !InputValues.ContainsKey("JIG_P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            var Mark_P1_Tar = InputValues["JIG_P1"] as IPointResult;
            var Mark_P2_Tar = InputValues["JIG_P2"] as IPointResult;
            var Mark_P1_Obj = InputValues["Buffer_P1"] as IPointResult;
            var Mark_P2_Obj = InputValues["Buffer_P2"] as IPointResult;

            //jigUnitNum = 0; //초기화
            //unitNum = CvtPLCIO.UnitNo - 1;  //PLC에서 보내는 Unit Number 받아오기
            //unitNum = 0;//임시코드
            //if (refindexType == RefIndexType.UnitNum)
            //    jigUnitNum = unitNum;
            //if (unitNum < 0 || unitNum > 3) //Unit Number는 #1~# 4이므로
            //{
            //    errorCode = Algo2PAlignRef_ITAction.Err_UnitNum_NG;
            //    return false;
            //}

            if (Mark_P1_Tar == null || Mark_P2_Tar == null || Mark_P1_Obj == null || Mark_P2_Obj == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            var Chk_Obj1 = InputValues["Buffer_P1"] as IClear;
            var Chk_Obj2 = InputValues["Buffer_P2"] as IClear;
            var Chk_Tar1 = InputValues["JIG_P1"] as IClear;
            var Chk_Tar2 = InputValues["JIG_P2"] as IClear;

            bool chkObj1 = Chk_Obj1.FindCnt == 0 ? false : true;
            bool chkObj2 = Chk_Obj2.FindCnt == 0 ? false : true;
            bool chkTar1 = Chk_Tar1.FindCnt == 0 ? false : true;
            bool chkTar2 = Chk_Tar2.FindCnt == 0 ? false : true;

            // jig에서 mark NG가 날 경우, 이전 데이터를 활용해서 찾는 기능. 베트남에서 사용.
            if (IsSkipError == ONOFF.ON)
            {
                if(!chkObj1 || !chkObj2)
                {
                    errorCode = Algo2PAlignRef_ITAction.Err_PMAlignProperty_NG;
                    return false;
                }
                if (!chkTar1)
                    errorCode = Algo2PAlignRef_ITAction.Err_JIGMark1_NG;
                else if (!chkTar2)
                    errorCode = Algo2PAlignRef_ITAction.Err_JIGMark2_NG;
                else
                {
                    RecentMark1_Tar = DeepClone<MatchingRstData>(Mark_P1_Tar as MatchingRstData);
                    RecentMark2_Tar = DeepClone<MatchingRstData>(Mark_P2_Tar as MatchingRstData);
                    recentJigCalData = Mark_P1_Tar.CalData as CalDataObject; //[hong]Deep copy로 바꿔야 할지 테스트 해보고 결정
                }
                if(errorCode != 0)
                {
                    Mark_P1_Tar = RecentMark1_Tar as IPointResult;
                    Mark_P2_Tar = RecentMark2_Tar as IPointResult;
                    Mark_P1_Tar.CalData = recentJigCalData;
                }
            }
            else if (!chkObj1 || !chkObj2 || !chkTar1 || !chkTar2)
            {
                errorCode = Algo2PAlignRef_ITAction.Err_PMAlignProperty_NG;
                return false;
            }
        
            if (Mark_P1_Tar.RefPoints == null || Mark_P2_Tar.RefPoints == null || Mark_P1_Obj.RefPoints == null  || Mark_P2_Obj.RefPoints == null || 
                Mark_P1_Tar.RefPoints[0].X == 0 || Mark_P1_Tar.RefPoints[0].Y == 0 ||
                Mark_P2_Tar.RefPoints[0].X == 0 || Mark_P2_Tar.RefPoints[0].Y == 0 ||
                Mark_P1_Obj.RefPoints[0].X == 0 || Mark_P1_Obj.RefPoints[0].Y == 0 ||
                Mark_P2_Obj.RefPoints[0].X == 0 || Mark_P2_Obj.RefPoints[0].Y == 0)
            {
                errorCode = Algo2PAlignRef_ITAction.Err_ReferenceValue_NG;
                return false;
            }
            #endregion

            #region CalData Cofirm
            if (buffer_CalDataObj == null || jig_CalDataObj == null)
            {
                errorCode = Algo2PAlignRef_ITAction.Err_CalData_NG;
                return false;
            }
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo2PAlignRef_ITAlignModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            var limit = new XYT(limitX, limitY, limitT);
            var spec_BufLength = (double)mParams.Spec_BufLength.Value;
            var tor_BufLength = (double)mParams.Tor_BufLength.Value;
            var scale_BufLength = (double)mParams.Scale_BufLength.Value;
            var spec_JigLength = (double)mParams.Spec_JigLength.Value;
            var tor_JigLength = (double)mParams.Tor_JigLength.Value;
            var scale_JigLength = (double)mParams.Scale_JigLength.Value;
            #endregion

            #region Target
            //Target Jig
            var rP1_Tar = jig_CalDataObj.GetV2R(model, new XY(Mark_P1_Tar.OutputXYT.X, Mark_P1_Tar.OutputXYT.Y));
            var rP2_Tar = jig_CalDataObj.GetV2R(model, new XY(Mark_P2_Tar.OutputXYT.X, Mark_P2_Tar.OutputXYT.Y));
            var rP1_Tar_Ref = jig_CalDataObj.GetV2R(model, new XY(Mark_P1_Tar.RefPoints[0].X, Mark_P1_Tar.RefPoints[0].Y));
            var rP2_Tar_Ref = jig_CalDataObj.GetV2R(model, new XY(Mark_P2_Tar.RefPoints[0].X, Mark_P2_Tar.RefPoints[0].Y));

            //Jig Offset
            var JigPos = new XY(((rP1_Tar.X + rP2_Tar.X) / 2), ((rP1_Tar.Y + rP2_Tar.Y) / 2));  //로봇좌표
            var JigPosT = GetThetaColumn(rP1_Tar.X, rP2_Tar.X, rP1_Tar.Y, rP2_Tar.Y);
            var JigPos_Ref = new XY(((rP1_Tar_Ref.X + rP2_Tar_Ref.X) / 2), ((rP1_Tar_Ref.Y + rP2_Tar_Ref.Y) / 2));
            var JigPosT_Ref = GetThetaColumn(rP1_Tar_Ref.X, rP2_Tar_Ref.X, rP1_Tar_Ref.Y, rP2_Tar_Ref.Y);  
         
            var JigPos_Rev = new XY(JigPos - JigPos_Ref);
            var JigPosT_Rev = JigPosT - JigPosT_Ref;
            #endregion

            #region Object
            var rP1_Obj = buffer_CalDataObj.GetV2R(model, new XY(Mark_P1_Obj.OutputXYT.X, Mark_P1_Obj.OutputXYT.Y));
            var rP2_Obj = buffer_CalDataObj.GetV2R(model, new XY(Mark_P2_Obj.OutputXYT.X, Mark_P2_Obj.OutputXYT.Y));
            var rP1_Obj_Ref = buffer_CalDataObj.GetV2R(model, new XY(Mark_P1_Obj.RefPoints[0].X, Mark_P1_Obj.RefPoints[0].Y));
            var rP2_Obj_Ref = buffer_CalDataObj.GetV2R(model, new XY(Mark_P2_Obj.RefPoints[0].X, Mark_P2_Obj.RefPoints[0].Y));

            //Buffer Offset
            var BufferPos = new XY(((rP1_Obj.X + rP2_Obj.X) / 2), ((rP1_Obj.Y + rP2_Obj.Y) / 2));
            var BufferPosT = GetThetaColumn(rP1_Obj.X, rP2_Obj.X, rP1_Obj.Y, rP2_Obj.Y);  
            var BufferPos_Ref = new XY(((rP1_Obj_Ref.X + rP2_Obj_Ref.X) / 2), ((rP1_Obj_Ref.Y + rP2_Obj_Ref.Y) / 2));
            var BufferPosT_Ref = GetThetaColumn(rP1_Obj_Ref.X, rP2_Obj_Ref.X, rP1_Obj_Ref.Y, rP2_Obj_Ref.Y);   
            
            var BufferPos_Rev = new XY(BufferPos - BufferPos_Ref);
            var BufferPosT_Rev = BufferPosT - BufferPosT_Ref;
            #endregion

            #region Align Calculate
            var cJigPos_Rev = JigPos_Rev + jig_CalDataObj.GetRotateCenter(model);    //coordinate 좌표
            var cJigPosT_Rev = JigPosT_Rev;
            var cJigPosxyt_Rev = new XYT(cJigPos_Rev.X, cJigPos_Rev.Y, cJigPosT_Rev);

            #region Calc Rev Offset
            var alignOffset = /*new XYT(1, 1, 1);*/CvtPLCIO.OffsetXYT;
            cJigPosxyt_Rev = ApplyTargetOffset(cJigPosxyt_Rev, alignOffset);
            #endregion

            var cBufferPos_Rev = BufferPos_Rev + jig_CalDataObj.GetRotateCenter(model);
            var cBufferPosT_Rev = cJigPosxyt_Rev.T - BufferPosT_Rev;
            cBufferPosT_Rev = NormalizeTheta(cBufferPosT_Rev);
            //double aa = cBufferPosT_Rev / rad;
            double DriftX = Math.Cos(cBufferPosT_Rev) * cBufferPos_Rev.X - Math.Sin(cBufferPosT_Rev) * cBufferPos_Rev.Y;
            double DriftY = Math.Sin(cBufferPosT_Rev) * cBufferPos_Rev.X + Math.Cos(cBufferPosT_Rev) * cBufferPos_Rev.Y;

            revAlign.X = cJigPosxyt_Rev.X - DriftX;
            revAlign.Y = cJigPosxyt_Rev.Y - DriftY;
            revAlign.T = cBufferPosT_Rev / rad;
            #endregion

            #region Calc Length
            FPCBlength = GetLength(rP1_Obj, rP2_Obj);
            Jiglength = GetLength(rP1_Tar, rP2_Tar);
            FPCBlength *= scale_BufLength;
            Jiglength *= scale_JigLength;

            //Lengh check해서 warning 띄우는 코드 추가 필요
            #endregion

            #region Confirm Result
            ConfirmResult(revAlign, limit);
            //ConfirmLength(FPCBlength, spec_BufLength, tor_BufLength, Jiglength, spec_JigLength, tor_JigLength);
            if (!ConfirmLength(FPCBlength, spec_BufLength, tor_BufLength))
            {
                Mark_P1_Obj.Tool.ProcMode = ProcessMode.Manual; Mark_P2_Obj.Tool.ProcMode = ProcessMode.Manual;
            }
            if (!ConfirmLength(Jiglength, spec_JigLength, tor_JigLength))
            {
                Mark_P1_Tar.Tool.ProcMode = ProcessMode.Manual; Mark_P2_Tar.Tool.ProcMode = ProcessMode.Manual;
            }

            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo2PAlignRef_ITResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Offset1X = Math.Round(revAlign.X, 3),
                Offset1Y = Math.Round(revAlign.Y, 3),
                Offset1T = Math.Round(revAlign.T, 3),

                //Length
                FPCBLength = Math.Round(FPCBlength, 3),
                JigLength = Math.Round(Jiglength, 3),
                Spec_FPCBLength = Math.Round(spec_BufLength, 3),
                Spec_JigLength = Math.Round(spec_JigLength, 3),
                Tor_FPCBLength = Math.Round(tor_BufLength, 3),
                Tor_JigLength = Math.Round(tor_JigLength, 3),


                Result = true,
                //UnitNumber = unitNum + 1,
                //JigRefNumber = jigUnitNum + 1,

                //FPCB 위치
                BufferPosX = Math.Round(BufferPos.X, 3),
                BufferPosY = Math.Round(BufferPos.Y, 3),
                BufferPosT = Math.Round(BufferPosT, 3),

                //FPCB Reference 위치
                BufferPosRefX = Math.Round(BufferPos_Ref.X, 3),
                BufferPosRefY = Math.Round(BufferPos_Ref.Y, 3),
                BufferPosRefT = Math.Round(BufferPosT_Ref, 3),

                //JIG 위치
                JigPosX = Math.Round(JigPos.X, 3),
                JigPosY = Math.Round(JigPos.Y, 3),
                JigPosT = Math.Round(JigPosT, 3),

                //JIG Reference 위치
                JigPosRefX = Math.Round(JigPos_Ref.X, 3),
                JigPosRefY = Math.Round(JigPos_Ref.Y, 3),
                JigPosRefT = Math.Round(JigPosT_Ref, 3),

                P1_X_Tar = Math.Round(Mark_P1_Tar.OutputXYT.X, 3),
                P1_Y_Tar = Math.Round(Mark_P1_Tar.OutputXYT.Y, 3),
                P2_X_Tar = Math.Round(Mark_P2_Tar.OutputXYT.X, 3),
                P2_Y_Tar = Math.Round(Mark_P2_Tar.OutputXYT.Y, 3),

                P1_X_Obj = Math.Round(Mark_P1_Obj.OutputXYT.X, 3),
                P1_Y_Obj = Math.Round(Mark_P1_Obj.OutputXYT.Y, 3),
                P2_X_Obj = Math.Round(Mark_P2_Obj.OutputXYT.X, 3),
                P2_Y_Obj = Math.Round(Mark_P2_Obj.OutputXYT.Y, 3),

                DriftX = Math.Round(DriftX, 3),
                DriftY = Math.Round(DriftY, 3),
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, revUnload, sourceID);      
            #endregion
            return errorCode == 0 ? true : false; ;
        }


        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = Algo2PAlignRef_ITAction.Err_Limit_Exceeded;
                return false;
            }
            else
                return true;
        }
        protected bool ConfirmLength(double objLength, double objspec, double objTor, double tarLength,double tarSpec, double tarTor)
        {
            if (!ConfirmSpecMinMax(objLength, objspec + objTor * (-1), objspec + objTor) ||
                !ConfirmSpecMinMax(tarLength, tarSpec + tarTor * (-1), tarSpec + tarTor))
            {
                errorCode = Algo2PAlignRef_ITAction.Err_Length_Check_NG;
                return false;
            }

            return true;
        }
        protected bool ConfirmLength(double objLength, double objspec, double objTor)
        {
            if (!ConfirmSpecMinMax(objLength, objspec + objTor * (-1), objspec + objTor))
            {
                errorCode = Algo2PAlignRef_ITAction.Err_Length_Check_NG;
                return false;
            }

            return true;
        }
        public void WriteVisionIO(object rev1, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
            VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
            VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);

            // 아이디 확인.
            VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            // report matching score to fdc
            var Mark_P1_Tar = InputValues["JIG_P1"] as IPointResult;
            var Mark_P2_Tar = InputValues["JIG_P2"] as IPointResult;
            var Mark_P1_Obj = InputValues["Buffer_P1"] as IPointResult;
            var Mark_P2_Obj = InputValues["Buffer_P2"] as IPointResult;

            VisionValues["Score_Buffer1"].NextValue = Mark_P1_Obj.Score; IOs.Add(VisionValues["Score_Buffer1"]);
            VisionValues["Score_Buffer2"].NextValue = Mark_P2_Obj.Score; IOs.Add(VisionValues["Score_Buffer2"]);
            VisionValues["Score_JIG1"].NextValue = Mark_P1_Tar.Score; IOs.Add(VisionValues["Score_JIG1"]);
            VisionValues["Score_JIG2"].NextValue = Mark_P2_Tar.Score; IOs.Add(VisionValues["Score_JIG2"]);

            CommodObject.SetVisionValues(IOs);
        }
        #endregion
    }
}

