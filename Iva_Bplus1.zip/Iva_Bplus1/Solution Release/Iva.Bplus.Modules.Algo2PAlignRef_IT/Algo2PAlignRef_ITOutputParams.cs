﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo2PAlignRef_IT
{
    class Algo2PAlignRef_ITOutputParams : OutputParams
    {
        #region Convert
        public object ConvertXYT { get; set; }

        #endregion


        #region Logging
        public object Result { get; set; }
        #endregion
    }
}
