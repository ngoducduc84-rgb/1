﻿using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo2PAlignRef_IT
{
    public partial class Algo2PAlignRef_ITAction
    {
        #region [Error Script] Algo2PAlignRef_ITAction: 16201 ~ 16300
        static public int Err_JIGMark1_NG = 16201; public string E16201_Err_JIGMark1_NG = "PMAling  Mark1 NG";
        static public int Err_JIGMark2_NG = 16202; public string E16202_Err_JIGMark2_NG = "PMAling  Mark2 NG";
        static public int Err_ReferenceValue_NG = 16203; public string E16203_Err_ReferenceValue_NG = "Reference Point NG";
        static public int Err_CalData_NG = 16204; public string E16204_Err_CalData_NG = "Cal Data NG";
        static public int Err_UnitNum_NG = 16205; public string E16205_Err_UnitNum_NG = "Unit Number NG";
        static public int Err_PMAlignProperty_NG = 16206; public string E16206_Err_PMAlignProperty_NG = "PMAling the Whole Mark NG";
        static public int Err_Limit_Exceeded = 16207; public string E16207_Err_Limit_Exceeded = "Align Data Limit NG";
        static public int Err_Length_Check_NG = 16208; public string E16208_Err_Length_Check_NG = "Length Check NG";
        public override void ErrorDefine()
        {
            base.ErrorDefine();
            errorInfos.Add(new ErrorInfo(this.Parent, Err_JIGMark1_NG, ErrorType.Warning, E16201_Err_JIGMark1_NG, "JIG PMAlign 1번 Mark를 찾을수 없습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_JIGMark2_NG, ErrorType.Warning, E16202_Err_JIGMark2_NG, "JIG PMAlign 2번 Mark를 찾을수 없습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_ReferenceValue_NG, ErrorType.ErrorStop, E16203_Err_ReferenceValue_NG, "Reference 값 세팅이 되어 있지 않습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_CalData_NG, ErrorType.ErrorStop, E16204_Err_CalData_NG, "Cal Data 세팅이 되어 있지 않습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_UnitNum_NG, ErrorType.ErrorStop, E16205_Err_UnitNum_NG, "Unit number의 값이 범위를 벗어났습니다. (range :1~4)"));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_PMAlignProperty_NG, ErrorType.ErrorStop, E16206_Err_PMAlignProperty_NG, "PMAlign Poperty 세팅이 잘 못 되었습니다.(JIG Skip모드 OFF시에선 PM Align Skip 미사용)"));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Limit_Exceeded, ErrorType.ErrorStop, E16207_Err_Limit_Exceeded, "Align Data가 Limit값을 벗어났습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Length_Check_NG, ErrorType.ErrorStop, E16208_Err_Length_Check_NG, "Mark간 Length 값이 범위를 벗어났습니다."));
        }
        #endregion
    }
}
