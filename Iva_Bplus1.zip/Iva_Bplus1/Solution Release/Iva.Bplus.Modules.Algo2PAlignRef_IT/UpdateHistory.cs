﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo2PAlignRef_IT
{
    public partial class Algo2PAlignRef_ITShape
    {
        public override void UpdateHistory()
        {
            // ModuleBase Update History Loading
            base.UpdateHistory();

            /* Sample */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "First Release Version",                            // Update Title
                Version = new Version(1, 0, 0, 0),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>          // Update Item List
                {
                   "1. None",
                   "2. None",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2019, 4, 4, 17, 0, 0),                  // year, month, day, hour, minute, second
            });

            /* Additional Update History */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "Source Property 삭제",                             // Update Title
                Version = new Version(1, 0, 0, 1),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "Source Property 삭제",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 1, 10, 10, 0, 0),                  // year, month, day, hour, minute, second
            });
        }
    }
}
