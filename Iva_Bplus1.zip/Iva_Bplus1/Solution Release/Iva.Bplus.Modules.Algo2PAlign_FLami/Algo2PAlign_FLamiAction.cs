﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo2PAlign_FLami;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAlign_FLami
{
    [SerializableAttribute]
    public partial class Algo2PAlign_FLamiAction : Lami90AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private bool useUnloadOffset;
        [field: NonSerialized]
        private double cur_Length;

        [field: NonSerialized]
        private bool judge_Length;

        [field: NonSerialized]
        private AlgoParam temp_Length;

        #endregion

        #region [Properties]   
        public bool UseUnloadOffset { get { return useUnloadOffset; } set { if (useUnloadOffset == value) return; useUnloadOffset = value; this.OnPropertyChanged(nameof(UseUnloadOffset)); } }

        public double Cur_Length { get { return cur_Length; } set { if (cur_Length == value) return; cur_Length = value; this.OnPropertyChanged(nameof(Cur_Length)); } }
        public bool Judge_Length { get { return judge_Length; } set { if (judge_Length == value) return; judge_Length = value; this.OnPropertyChanged(nameof(Judge_Length)); } }

        #endregion

        #region [Construct]
        public Algo2PAlign_FLamiAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo2PAlign_FLamiInputParams();
            OutputParams = new Algo2PAlign_FLamiOutputParams();

            var obj = _object as Algo2PAlign_FLamiObject;
            obj.ModelParamType = typeof(Algo2PAlign_FLamiAlignModelParams);
            var param = obj.CurParams as Algo2PAlign_FLamiAlignModelParams;

            ChildSettingView = new AlignSetting();
            ChildSettingView.DataContext = this;

            temp_Length = new AlgoParam(param.Scale_Length);
            temp_Length.Value = 0.0;
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as Algo2PAlign_FLamiObject;


            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                foreach (ConnectorViewModel connector in parent.InputConnectors)
                {
                    if (connector.AttachedConnections[0].ConnectionState == ConnectionStatus.Executing || connector.AttachedConnections[0].ConnectionState == ConnectionStatus.Success)
                    {
                        continue;
                    }
                    Obj.ErrorCode = Err_InputData_Info_Missing;
                    return OccurError(Obj.ErrorCode);
                }

                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                DateTime dateTime = DateTime.Now;
                if (!Obj.Run())
                {
                    Cur_Length = Obj.Length;
                    // 기존값들 초기화 필요함.
                    SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    //Obj.ImageSave(Obj.P1_DisplayObj, dateTime, "NG", name, Obj.SourceID);
                    return OccurError(Obj.ErrorCode);
                }
                else
                {
                    Cur_Length = Obj.Length;
                    SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    //Obj.ImageSave(Obj.P1_DisplayObj, dateTime, "OK", name, Obj.SourceID);
                    Obj.WriteVisionIO(Obj.RevAlign, Obj.RevUnload, "", Obj.Score);

                    Obj.AppendMessage(Name, "Caluration Complete");
                    StopTimer();

                }

                #endregion
            }

            return End(false);
        }

        public override bool Reset()
        {
            if (!base.Reset()) return false;

            return true;
        }

        #endregion

        #region [Command]
        [field: NonSerialized]
        private DelegateCommand scaleCalcCommand;
        public DelegateCommand ScaleCalcCommand
        {
            get
            {
                return scaleCalcCommand = scaleCalcCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo2PAlign_FLamiAlignModelParams;

                    var tempLength = (double)temp_Length.Value;

                    tmp.Scale_Length.Value = (double)tmp.Spec_Length.Value / Cur_Length;

                    // 업뎃
                    Obj.UpdateTempValues();
                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand reMeasureCommand;
        public DelegateCommand ReMeasureCommand
        {
            get
            {
                return reMeasureCommand = reMeasureCommand ?? new DelegateCommand(obj =>
                {
                    //var Obj = ModObject as AlgoObjectBase;
                    //var cur = Obj.ModelParams[SystemModel.GetCurModel()] as Algo2PAlignInspectModelParams;
                    //var tmp = Obj.ChangeParams as Algo2PAlignInspectModelParams;

                    //cur_UpperLx /= (double)cur.Scale_UpperLx.Value;
                    //cur_UpperLy /= (double)cur.Scale_UpperLy.Value;
                    //cur_LowerLx /= (double)cur.Scale_LowerLx.Value;
                    //cur_LowerLy /= (double)cur.Scale_LowerLy.Value;
                    //cur_LowerRx /= (double)cur.Scale_LowerRx.Value;
                    //cur_LowerRy /= (double)cur.Scale_LowerRy.Value;

                    //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
                    //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
                    //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
                    //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
                    //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
                    //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;


                });

            }
        }
        #endregion

        #region [Override]
        public override void PrepareSave()
        {
            base.PrepareSave();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion

    }
}
