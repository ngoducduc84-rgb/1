﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo2PAlign_FLami
{
    [SerializableAttribute]
    public partial class Algo2PAlign_FLamiObject : AlgoObjectBase
    {
        #region [Fields]
        #region  Selected Caldata Name
        private string p1_CalData;
        private string p2_CalData;
        private string p1_Display;
        private string p2_Display;
        #endregion

        #region etc
        private CalcType calcType;
        private ThetaDirection thetaDirection;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        #endregion

        #region Align관련 Data
        XYT revAlign = new XYT();
        XYT revUnload = new XYT();
        XY score = new XY();
        double length = 0.0;

        #endregion
        [field: NonSerialized]
        FLami_PLCTable cvtPLCIO;
        #endregion

        #region [properties]
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P1_CalData
        {
            get { return p1_CalData; }
            set { if (p1_CalData == value) return; p1_CalData = value; this.OnPropertyChanged(nameof(P1_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P2_CalData
        {
            get { return p2_CalData; }
            set { if (p2_CalData == value) return; p2_CalData = value; this.OnPropertyChanged(nameof(P2_CalData)); }
        }

        public CalDataObject P1_CalDataObj
        {
            get { return SystemObject_Common.GetObject(p1_CalData) as CalDataObject; }
        }

        public CalDataObject P2_CalDataObj
        {
            get { return SystemObject_Common.GetObject(p2_CalData) as CalDataObject; }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P2_Display
        {
            get { return p2_Display; }
            set { if (p2_Display == value) return; p2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
        }
        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }
        public CogDisplayObject P2_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p2_Display) as CogDisplayObject; }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }

        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }


        public ObservableCollection<string> CalDataList
        {
            get
            {

                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }

        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        public XY Score { get { return score; } }
        public double Length { get { return length; } }
        #endregion
        #endregion

        #region[Construct]
        public Algo2PAlign_FLamiObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo2PAlign_FLamiAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool AlignCalc()
        {
            bool bResult = true;
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
           // AssignPLCData();
            AssignPLCData_FLami();    //Lami용
            #endregion

            #region Mark Data Read& Confirm
            // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
            if (!InputValues.ContainsKey("P1") || !InputValues.ContainsKey("P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            var Mark_P1 = InputValues["P1"] as LineCrossRstData;
            var Mark_P2 = InputValues["P2"] as LineCrossRstData;
            //score.X = Mark_P1.Score;    //FDC
            //score.Y = Mark_P2.Score;    //FDC
            if (Mark_P1 == null || Mark_P2 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            if (Mark_P1.RefPoints == null)
            {
                Mark_P1.RefPoints = new List<XYT>();
                Mark_P1.RefPoints.Add(new XYT(0, 0, 0));
            }
            if (Mark_P2.RefPoints == null)
            {
                Mark_P2.RefPoints = new List<XYT>();
                Mark_P2.RefPoints.Add(new XYT(0, 0, 0));
            }

            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null || P2_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                // Calibration 설정 안됨.
                return false;
            }
            var Robot_P1 = P1_CalDataObj.GetV2R(model, new XY(Mark_P1.OutputXYT.X, Mark_P1.OutputXYT.Y));
            var Robot_P2 = P2_CalDataObj.GetV2R(model, new XY(Mark_P2.OutputXYT.X, Mark_P2.OutputXYT.Y));

            var Robot_CAM_P1 = new XY(0, 0);
            var Robot_CAM_P2 = new XY(0, 0);

            XY ref1; XY ref2;
            if ((CalcType == CalcType.Reference|| CalcType == CalcType.PickUp) && Mark_P1.RefPoints.Count > 1 && Mark_P2.RefPoints.Count > 1)
            {
                ref1 = new XY(Mark_P1.RefPoints[0].X, Mark_P1.RefPoints[0].Y);
                ref2 = new XY(Mark_P2.RefPoints[1].X, Mark_P2.RefPoints[1].Y);
            }
            else
            {
                ref1 = new XY(0.0, 0.0);
                ref2 = new XY(0.0, 0.0);
            }

            var Robot_Ref_P1 = P1_CalDataObj.GetV2R(model, ref1);
            var Robot_Ref_P2 = P2_CalDataObj.GetV2R(model, ref2);

            var Coord_P1 = Robot_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_P2 = Robot_P2 + P2_CalDataObj.GetRotateCenter(model);

            var Coord_CAM_P1 = Robot_CAM_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_CAM_P2 = Robot_CAM_P2 + P2_CalDataObj.GetRotateCenter(model);

            var Coord_Ref_P1 = Robot_Ref_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_Ref_P2 = Robot_Ref_P2 + P2_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo2PAlign_FLamiAlignModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            var limit = new XYT(limitX, limitY, limitT);
            var spec_Length = (double)mParams.Spec_Length.Value;
            var tor_Length = (double)mParams.Tor_Length.Value;
            var scale_Length = (double)mParams.Scale_Length.Value;

            #endregion

            #region Calc Rev Offset

            // 단변
            double camT = GetThetaColumn(Coord_CAM_P1.X, Coord_CAM_P2.X, Coord_CAM_P1.Y, Coord_CAM_P2.Y);
            double refT = GetThetaColumn(Coord_Ref_P1.X, Coord_Ref_P2.X, Coord_Ref_P1.Y, Coord_Ref_P2.Y);
            double pnlT = GetThetaColumn(Coord_P1.X, Coord_P2.X, Coord_P1.Y, Coord_P2.Y);

            pnlT -= camT;
            refT -= camT;
            camT = 0;

            var camTar = (Coord_CAM_P1 + Coord_CAM_P2) / 2;
            var refTar = (Coord_Ref_P1 + Coord_Ref_P2) / 2;
            var pnlObj = (Coord_P1 + Coord_P2) / 2;

            var alignOffset = new XYT(cvtPLCIO.OffsetX, cvtPLCIO.OffsetY, cvtPLCIO.OffsetT);

            var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
            var refTarxyt = new XYT(refTar.X, refTar.Y, refT);
            var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
            var camTarxyt_Un = new XYT(camTar.X, camTar.Y, camT);

            revAlign = new XYT();
            revUnload = new XYT();
            double radT, DriftX, DriftY;

            if (CalcType == CalcType.Center)
            {
                // Attach 위치 보정값 계산. 
                camTarxyt = ApplyTargetOffset(camTarxyt, alignOffset);
                radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revAlign.X = camTarxyt.X - DriftX;
                revAlign.Y = camTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else //역방향
                    revAlign.T = (radT / rad) * -1;

                // Unload 위치 보정값 계산 // 얘는 오프셋없음.    
                camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revUnload.X = camTarxyt_Un.X - DriftX;
                revUnload.Y = camTarxyt_Un.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revUnload.T = radT / rad;
                else //역방향
                    revUnload.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.Reference)
            {
                // Attach 위치 보정값 계산. 
                refTarxyt = ApplyTargetOffset(refTarxyt, alignOffset);
                radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revAlign.X = refTarxyt.X - DriftX;
                revAlign.Y = refTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else  //역방향
                    revAlign.T = (radT / rad) * -1;

                // Unload 위치 보정값 계산 // 얘는 오프셋없음.    //CamCenter위치로
                camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                revUnload.X = camTarxyt_Un.X - DriftX;
                revUnload.Y = camTarxyt_Un.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revUnload.T = radT / rad;
                else  //역방향
                    revUnload.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.PickUp)   //Target: 자재, Object: Reference
            {
                pnlObjxyt = ApplyTargetOffset(pnlObjxyt, alignOffset);
                radT = NormalizeTheta(pnlObjxyt.T - refTarxyt.T);
                DriftX = Math.Cos(radT) * refTarxyt.X - Math.Sin(radT) * refTarxyt.Y;
                DriftY = Math.Sin(radT) * refTarxyt.X + Math.Cos(radT) * refTarxyt.Y;
                revAlign.X = pnlObjxyt.X - DriftX;
                revAlign.Y = pnlObjxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else  //역방향
                    revAlign.T = (radT / rad) * -1;

            }
            #endregion

            #region Calc Length
            string strRst = string.Empty;

            length = GetLength(Coord_P1, Coord_P2);
            if(!GetLCheck(length * scale_Length, spec_Length, tor_Length))
            {
                ErrorCode = Algo2PAlign_FLamiAction.Err_Lower_Length_Check;
                SetLCheckJudgeStatus();
                bResult = false;
                strRst = "LCheckNG";
            }
            #endregion

            #region Confirm Result
            if (!ConfirmResult(revAlign, limit))
            {
                bResult = false;
                SetLimtJudgeStatus();
                strRst = "LimitNG";
            }
            #endregion

            #region Result Data Update(DataGridView Insert)
            if (string.IsNullOrEmpty(strRst))
            {
                if (!bResult) strRst = "NG";
                else strRst = "OK";
            }

            AlgoRst = new Algo2PAlign_FLamiResult
            {
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Name = name,
                ID = sourceID,

                Result = strRst,

                RevX = Math.Round(revAlign.X, 3),
                RevY = Math.Round(revAlign.Y, 3),
                RevT = Math.Round(revAlign.T, 3),

                OffsetX = Math.Round(cvtPLCIO.OffsetX, 3),
                OffsetY = Math.Round(cvtPLCIO.OffsetY, 3),
                OffsetT = Math.Round(cvtPLCIO.OffsetT, 3),

                RevX_UL = Math.Round(revUnload.X, 3),
                RevY_UL = Math.Round(revUnload.Y, 3),
                RevT_UL = Math.Round(revUnload.T, 3),

                Length = Math.Round(length * scale_Length, 3),

                P1_X = Math.Round(Mark_P1.OutputXYT.X, 3),  //Mark Pixel 좌표
                P1_Y = Math.Round(Mark_P1.OutputXYT.Y, 3),
                P2_X = Math.Round(Mark_P2.OutputXYT.X, 3),
                P2_Y = Math.Round(Mark_P2.OutputXYT.Y, 3),

                C1_X = Math.Round(Coord_P1.X, 3),
                C1_Y = Math.Round(Coord_P1.Y, 3),
                C2_X = Math.Round(Coord_P2.X, 3),
                C2_Y = Math.Round(Coord_P2.Y, 3),

                Type = CalcType.ToString(),
                Pnl_T = Math.Round(pnlT, 3),
                Ref_T = Math.Round(refT, 3),
                Cam_T = Math.Round(camT, 3),    //camT=0인데 의미가 있나
            };
            #endregion
            //SystemLogger.WriteAlignDBLog(name, AlgoRst);
            //#endregion           

            if (!bResult)
            {
                return false;
            }

            #region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, revUnload, sourceID);
            #endregion
            return true;
        }

        public void SetLimtJudgeStatus()
        {
            var Mark_P1 = InputValues["P1"] as LineCrossRstData;
            var Mark_P2 = InputValues["P2"] as LineCrossRstData;

            System.Threading.Thread.Sleep(500);

            Mark_P1.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            Mark_P2.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
        }

        public void SetLCheckJudgeStatus()
        {
            var Mark_P1 = InputValues["P1"] as LineCrossRstData;
            var Mark_P2 = InputValues["P2"] as LineCrossRstData;

            System.Threading.Thread.Sleep(500);

            Mark_P1.DisplayObj.Judgement = (uint)Judgement.L_Check;
            Mark_P2.DisplayObj.Judgement = (uint)Judgement.L_Check;
        }

        #region PLC Update
        void AssignPLCData_FLami()
        {
            UpdatePLCIOs();

            cvtPLCIO = new FLami_PLCTable();

            cvtPLCIO.CurrentPosX = (double)PlcValues["CurrentPosX"].CurValue;
            cvtPLCIO.CurrentPosY = (double)PlcValues["CurrentPosY"].CurValue;
            cvtPLCIO.CurrentPosT = (double)PlcValues["CurrentPosT"].CurValue;
            
            cvtPLCIO.OffsetX = (double)PlcValues["OffsetX"].CurValue;
            cvtPLCIO.OffsetY = (double)PlcValues["OffsetY"].CurValue;
            cvtPLCIO.OffsetT = (double)PlcValues["OffsetT"].CurValue;
            
            cvtPLCIO.CellID = (string)PlcValues["CellID"].CurValue;
            SourceID = cvtPLCIO.CellID;
        }
        #endregion

        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = Lami90AlgoActionBase.Err_Limit_Over;
                return false;
            }
            else
                return true;
        }
        public void WriteVisionIO(object rev1, object rev2, string ID, object score )
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    //Lami
                    VisionValues["TargetPosX1"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["TargetPosX1"]);
                    VisionValues["TargetPosX2"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["TargetPosX2"]);
                    VisionValues["TargetPosY1"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["TargetPosY1"]);

                    //XYT tar1 = CvtPLCIO.OffsetXYT + (rev1 as XYT);
                    VisionValues["FinalTargetX"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["FinalTargetX"]);
                    VisionValues["FinalTargetY"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["FinalTargetY"]);
                    VisionValues["FinalTargetT"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["FinalTargetT"]);
                    //FDC
                    VisionValues["FDC_Score_P1"].NextValue = 100.0d; IOs.Add(VisionValues["FDC_Score_P1"]);
                    VisionValues["FDC_Score_P2"].NextValue = 100.0d; IOs.Add(VisionValues["FDC_Score_P2"]);
                    VisionValues["FDC_TargetPosX"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["FDC_TargetPosX"]);
                    VisionValues["FDC_TargetPosY"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["FDC_TargetPosY"]);
                    VisionValues["FDC_TargetPosT"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["FDC_TargetPosT"]);
                    VisionValues["FDC_ResultRevX"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["FDC_ResultRevX"]);
                    VisionValues["FDC_ResultRevY"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["FDC_ResultRevY"]);
                    VisionValues["FDC_ResultRevT"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["FDC_ResultRevT"]);
                    
                    //VisionValues["FDC_LCheckSpecX"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_LCheckSpecX"]);
                    //VisionValues["FDC_LCheckSpecY"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_LCheckSpecY"]);
                    //VisionValues["FDC_LCheckSpecT"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_LCheckSpecT"]);
                    //VisionValues["FDC_MarkIdx_P1"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_MarkIdx_P1"]);
                    //VisionValues["FDC_MarkIdx_P2"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_MarkIdx_P2"]);
                    //VisionValues["FDC_UseLCheck"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_UseLCheck"]);         
                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    break;

            }

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);
            CommodObject.SetVisionValues(IOs);
        }
        #endregion

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (cogDisp == null) return;
            Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }
    }
}

