﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAlign_FLami
{
    [SerializableAttribute]
    public class Algo2PAlign_FLamiResult : AlgoResultBase
    {
        #region [fiedls]
        private string type;

        private double pnl_T;
        private double ref_T;
        private double cam_T;

        private double revX;
        private double revY;
        private double revT;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        private double revX_UL;
        private double revY_UL;
        private double revT_UL;

        private double length;
        private string result;

        private double p1_X;
        private double p1_Y;
        private double p2_X;
        private double p2_Y;

        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;
        #endregion

        #region [Properties]
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public double RevX
        {
            get { return revX; }
            set { if (value == revX) return; revX = value; OnPropertyChanged(nameof(RevX)); }
        }
        public double RevY
        {
            get { return revY; }
            set { if (value == revY) return; revY = value; OnPropertyChanged(nameof(RevY)); }
        }
        public double RevT
        {
            get { return revT; }
            set { if (value == revT) return; revT = value; OnPropertyChanged(nameof(RevT)); }
        }

        public double RevX_UL
        {
            get { return revX_UL; }
            set { if (value == revX_UL) return; revX_UL = value; OnPropertyChanged(nameof(RevX_UL)); }
        }
        public double RevY_UL
        {
            get { return revY_UL; }
            set { if (value == revY_UL) return; revY_UL = value; OnPropertyChanged(nameof(RevY_UL)); }
        }
        public double RevT_UL
        {
            get { return revT_UL; }
            set { if (value == revT_UL) return; revT_UL = value; OnPropertyChanged(nameof(RevT_UL)); }
        }
        public string Type
        {
            get { return type; }
            set { if (value == type) return; type = value; OnPropertyChanged(nameof(Type)); }
        }
        public double Pnl_T
        {
            get { return pnl_T; }
            set { if (value == pnl_T) return; pnl_T = value; OnPropertyChanged(nameof(Pnl_T)); }
        }
        public double Ref_T
        {
            get { return ref_T; }
            set { if (value == ref_T) return; ref_T = value; OnPropertyChanged(nameof(Ref_T)); }
        }
        public double Cam_T
        {
            get { return cam_T; }
            set { if (value == cam_T) return; cam_T = value; OnPropertyChanged(nameof(Cam_T)); }
        }

        public double Length
        {
            get { return length; }
            set { if (value == length) return; length = value; OnPropertyChanged(nameof(Length)); }
        }

        public string Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }
        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }
        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }
        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }
        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }
        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }
        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }
        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }
        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                if (value == offsetX) return;
                offsetX = value;

                OnPropertyChanged("OffsetX");
            }
        }
        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                if (value == offsetY) return;
                offsetY = value;

                OnPropertyChanged("OffsetY");
            }
        }
        public double OffsetT
        {
            get { return offsetT; }
            set
            {
                if (value == offsetT) return;
                offsetT = value;

                OnPropertyChanged("OffsetT");
            }
        }
        #endregion



        public Algo2PAlign_FLamiResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "offset1X: {3},\noffset1Y: {4},\noffset1T: {5},\n" +
                                  "offset2X: {6},\noffset2Y: {7},\noffset2T: {8},\n" +
                                  "Length: {9},\nResult: {10},\n" +
                                  "P1_X: {11},\nP1_Y: {12},\nP2_X: {13},\nP2_Y: {14},\n" +
                                  "C1_X: {15},\nC1_Y: {16},\nC2_X: {17},\nC2_Y: {18},\n" +
                                  "Type: {19},\nPnl_T: {20},\nRef_T: {21},\nCam_T: {22},\n"
                                  , typeof(Algo2PAlign_FLamiResult).ToString(), curTime, curDate
                                  , revX, revY, revT
                                  , revX_UL, revY_UL, revT_UL
                                  , length, result
                                  , p1_X, p1_Y, p2_X, p2_Y
                                  , c1_X, c1_Y, c2_X, c2_Y
                                  , type, pnl_T, ref_T, cam_T
                                  );
        }

    }
}
