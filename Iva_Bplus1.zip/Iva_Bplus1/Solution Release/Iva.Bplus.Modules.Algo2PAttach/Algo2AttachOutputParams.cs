﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo2PAttach
{
    class Algo2PAttachOutputParams : OutputParams
    {
        #region Logging
        public object Result { get; set; }
        #endregion
    }
}
