﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo2PAttach
{
    [SerializableAttribute]

    public partial class Algo2PAttachAlignModelParams : AlgoParams
    {
        //2P
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        private AlgoParam spec_Length_Target;
        private AlgoParam tor_Length_Target;
        private AlgoParam spec_Length_Object;
        private AlgoParam tor_Length_Object;
        private AlgoParam scale_Length;

        private AlgoParam isPanelMove;
        private AlgoParam sensorSize_W;
        private AlgoParam pixel_Count_W;
        private AlgoParam lens_Mag;
        private AlgoParam panelmarkdistance;

        // Distance Lx, Ly, Rx, Ry : Mark To Mark 거리임.
        private AlgoParam spec_Lx;
        private AlgoParam spec_Ly;
        private AlgoParam spec_Rx;
        private AlgoParam spec_Ry;

        // Scale Lx, Ly, Rx, Ry : 검사기와 정합성을 맞춰주기 위한 Factor임.
        private AlgoParam scale_Lx;
        private AlgoParam scale_Ly;
        private AlgoParam scale_Rx;
        private AlgoParam scale_Ry;
       
        // Range X,Y : Distance +- Range, Min Max임.
        private AlgoParam tor_Lx;
        private AlgoParam tor_Ly;
        private AlgoParam tor_Rx;
        private AlgoParam tor_Ry;

        // Retry Sepc
        private AlgoParam retry_X;
        private AlgoParam retry_Y;
        private AlgoParam retry_T;

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        public AlgoParam Spec_Length_Target { get { return spec_Length_Target; } set { if (spec_Length_Target == value) return; spec_Length_Target = value; this.OnPropertyChanged(nameof(Spec_Length_Target)); } }
        public AlgoParam Tor_Length_Target { get { return tor_Length_Target; } set { if (tor_Length_Target == value) return; tor_Length_Target = value; this.OnPropertyChanged(nameof(Tor_Length_Target)); } }
        public AlgoParam Spec_Length_Object { get { return spec_Length_Object; } set { if (spec_Length_Object == value) return; spec_Length_Object = value; this.OnPropertyChanged(nameof(Spec_Length_Object)); } }
        public AlgoParam Tor_Length_Object { get { return tor_Length_Object; } set { if (tor_Length_Object == value) return; tor_Length_Object = value; this.OnPropertyChanged(nameof(Tor_Length_Object)); } }
        public AlgoParam Scale_Length { get { return scale_Length; } set { if (scale_Length == value) return; scale_Length = value; this.OnPropertyChanged(nameof(Scale_Length)); } }

        public AlgoParam IsPanelMove { get { return isPanelMove; } set { if (isPanelMove == value) return; isPanelMove = value; this.OnPropertyChanged(nameof(IsPanelMove)); } }
        public AlgoParam SensorSize_W { get { return sensorSize_W; } set { if (sensorSize_W == value) return; sensorSize_W = value; this.OnPropertyChanged(nameof(SensorSize_W)); } }
        public AlgoParam Pixel_Count_W { get { return pixel_Count_W; } set { if (pixel_Count_W == value) return; pixel_Count_W = value; this.OnPropertyChanged(nameof(Pixel_Count_W)); } }
        public AlgoParam Lens_Mag { get { return lens_Mag; } set { if (lens_Mag == value) return; lens_Mag = value; this.OnPropertyChanged(nameof(Lens_Mag)); } }
        public AlgoParam PanelMarkDistance { get { return panelmarkdistance; } set { if (panelmarkdistance == value) return; panelmarkdistance = value; this.OnPropertyChanged(nameof(PanelMarkDistance)); } }
        public AlgoParam Spec_Lx { get { return spec_Lx; } set { if (spec_Lx == value) return; spec_Lx = value; this.OnPropertyChanged(nameof(Spec_Lx)); } }
        public AlgoParam Spec_Ly { get { return spec_Ly; } set { if (spec_Ly == value) return; spec_Ly = value; this.OnPropertyChanged(nameof(Spec_Ly)); } }
        public AlgoParam Spec_Rx { get { return spec_Rx; } set { if (spec_Rx == value) return; spec_Rx = value; this.OnPropertyChanged(nameof(Spec_Rx)); } }
        public AlgoParam Spec_Ry { get { return spec_Ry; } set { if (spec_Ry == value) return; spec_Ry = value; this.OnPropertyChanged(nameof(Spec_Ry)); } }

        public AlgoParam Scale_Lx { get { return scale_Lx; } set { if (scale_Lx == value) return; scale_Lx = value; this.OnPropertyChanged(nameof(Scale_Lx)); } }
        public AlgoParam Scale_Ly { get { return scale_Ly; } set { if (scale_Ly == value) return; scale_Ly = value; this.OnPropertyChanged(nameof(Scale_Ly)); } }
        public AlgoParam Scale_Rx { get { return scale_Rx; } set { if (scale_Rx == value) return; scale_Rx = value; this.OnPropertyChanged(nameof(Scale_Rx)); } }
        public AlgoParam Scale_Ry { get { return scale_Ry; } set { if (scale_Ry == value) return; scale_Ry = value; this.OnPropertyChanged(nameof(Scale_Ry)); } }


        public AlgoParam Tor_Lx { get { return tor_Lx; } set { if (tor_Lx == value) return; tor_Lx = value; this.OnPropertyChanged(nameof(Tor_Lx)); } }
        public AlgoParam Tor_Ly { get { return tor_Ly; } set { if (tor_Ly == value) return; tor_Ly = value; this.OnPropertyChanged(nameof(Tor_Ly)); } }
        public AlgoParam Tor_Rx { get { return tor_Rx; } set { if (tor_Rx == value) return; tor_Rx = value; this.OnPropertyChanged(nameof(Tor_Rx)); } }
        public AlgoParam Tor_Ry { get { return tor_Ry; } set { if (tor_Ry == value) return; tor_Ry = value; this.OnPropertyChanged(nameof(Tor_Ry)); } }

        public AlgoParam RetryX { get { return retry_X; } set { if (retry_X == value) return; retry_X = value; this.OnPropertyChanged(nameof(RetryX)); } }
        public AlgoParam RetryY { get { return retry_Y; } set { if (retry_Y == value) return; retry_Y = value; this.OnPropertyChanged(nameof(RetryY)); } }
        public AlgoParam RetryT { get { return retry_T; } set { if (retry_T == value) return; retry_T = value; this.OnPropertyChanged(nameof(RetryT)); } }

        public Algo2PAttachAlignModelParams()
            : base()
        {

            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);

            IsPanelMove = new AlgoParam("IsPanelMove", "-", typeof(bool), true, "Panel Move for Alignment", null, null);
            SensorSize_W = new AlgoParam("SensorSize_W", "mm", typeof(double), 9.2, "SenserSize Wide", (double)0.0, (double)10);
            Pixel_Count_W = new AlgoParam("Pixel_Count_W", "EA", typeof(double), 1920.0, "PixelCount", (double)0.0, (double)5000);
            Lens_Mag = new AlgoParam("Lens_Mag", "mm", typeof(double), 0.8, "Magnification", (double)0.0, (double)2);
            PanelMarkDistance = new AlgoParam("PanelMarkDistance", "mm", typeof(double), 200, "PanelMarkDistance", (double)80, (double)2000);

            Spec_Length_Target = new AlgoParam("Spec_Length_Target", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)1000);
            Tor_Length_Target = new AlgoParam("Tor_Length_Target", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)2);
            Spec_Length_Object = new AlgoParam("Spec_Length_Object", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)1000);
            Tor_Length_Object = new AlgoParam("Tor_Length_Object", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)2);
            Scale_Length = new AlgoParam("Scale_Length", "mm", typeof(double), 0.0, "Length Scale", (double)0, (double)2);

            Spec_Lx = new AlgoParam("Spec_Lx", "mm", typeof(double), 0.0, "Attach Spec_Lx", (double)-100, (double)100.0);
            Spec_Ly = new AlgoParam("Spec_Ly", "mm", typeof(double), 0.0, "Attach Spec_Ly", (double)-100, (double)100.0);
            Spec_Rx = new AlgoParam("Spec_Rx", "mm", typeof(double), 0.0, "Attach Spec_Rx", (double)-100, (double)100.0);
            Spec_Ry = new AlgoParam("Spec_Ry", "mm", typeof(double), 0.0, "Attach Spec_Ry", (double)-100, (double)100.0);

            Scale_Lx = new AlgoParam("Scale_Lx", "mm", typeof(double), 1.0, "Attach Distance Scale_Lx", (double)0.5, (double)3);
            Scale_Ly = new AlgoParam("Scale_Ly", "mm", typeof(double), 1.0, "Attach Distance Scale_Ly", (double)0.5, (double)3);
            Scale_Rx = new AlgoParam("Scale_Rx", "mm", typeof(double), 1.0, "Attach Distance Scale_Rx", (double)0.5, (double)3);
            Scale_Ry = new AlgoParam("Scale_Ry", "mm", typeof(double), 1.0, "Attach Distance Scale_Lx", (double)0.5, (double)3);

            Tor_Lx = new AlgoParam("Tor_Lx", "mm", typeof(double),0.0, "Attach Spec Tor_Lx", (double)0.0, (double)1);
            Tor_Ly = new AlgoParam("Tor_Ly", "mm", typeof(double),0.0, "Attach Spec Tor_Ly", (double)0.0, (double)1);
            Tor_Rx = new AlgoParam("Tor_Rx", "mm", typeof(double),0.0, "Attach Spec Tor_Rx", (double)0.0, (double)1);
            Tor_Ry = new AlgoParam("Tor_Ry", "mm", typeof(double),0.0, "Attach Spec Tor_Lx", (double)0.0, (double)1);

            RetryX = new AlgoParam("RetryX", "mm", typeof(double), 0.0, "Retry Limit X", (double)-0.5, (double)0.5);
            RetryY = new AlgoParam("RetryY", "mm", typeof(double), 0.0, "Retry Limit Y", (double)-0.5, (double)0.5);
            RetryT = new AlgoParam("RetryT", "deg", typeof(double), 0.0, "Retry Limit T", (double)-0.5, (double)0.5);
        }
    }
}
