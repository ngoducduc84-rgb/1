﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo2PAttach
{
        [SerializableAttribute]
        public partial class Algo2PAttachObject : AlgoObjectBase
        {
                #region [Fields]
                Algo2PAttachAlignModelParams mParams;
                #region  Selected Caldata Name
                private string p1_CalData;
                private string p2_CalData;
                private string p1_Display;
                private string p2_Display;
                #endregion

                #region etc
                private CalcType calcType = CalcType.Inspection;
                private ThetaDirection thetaDirection = ThetaDirection.Normal;
                private AlignMotionType alignMotionType = AlignMotionType.XYT;
                private Direction x1Direction = Direction.Reverse;
                private Direction x2Direction = Direction.Normal;
                private Direction y1Direction = Direction.Normal;
                private Direction y2Direction = Direction.Normal;
                private OffsetType offsetType = OffsetType.XYXY;
                private MachineType machineType = MachineType.Normal;
                private bool isVirtualTarget;
                private RetryJudgement retryJudgement = RetryJudgement.Alignment;
                #endregion

                #region Align결과 관련
                [NonSerialized]
                IPointResult Mark_Tar1;
                [NonSerialized]
                IPointResult Mark_Tar2;
                [NonSerialized]
                IPointResult Mark_Obj1;
                [NonSerialized]
                IPointResult Mark_Obj2;

                XYT revAlign = new XYT();
                XYT revUnload = new XYT();
                double length_obj = 0.0;
                double length_tar = 0.0;
                XYXY inspResult = new XYXY();
                bool lastJudge = true;
                #endregion

                #region Coordinate 관련
                XY Robot_Tar1 = new XY();
                XY Robot_Tar2 = new XY();
                XY Robot_Obj1 = new XY();
                XY Robot_Obj2 = new XY();
                XY Coord_Tar1 = new XY();
                XY Coord_Tar2 = new XY();
                XY Coord_Obj1 = new XY();
                XY Coord_Obj2 = new XY();
                XY Mark_Tar1_XY = new XY();
                XY Mark_Tar2_XY = new XY();
                XY Mark_Obj1_XY = new XY();
                XY Mark_Obj2_XY = new XY();

                XY Mark_Panel1 = new XY();
                XY Mark_Panel2 = new XY();
                XY Mark_notPanel1 = new XY();
                XY Mark_notPanel2 = new XY();
                XY Robot_notPanel1 = new XY();
                XY Robot_notPanel2 = new XY();
                XY Robot_Panel1 = new XY();
                XY Robot_Panel2 = new XY();

                XYT TarCenter = new XYT();
                double panelangle_rad = 0;
                object alignOffset;
                object Offsets;
                #endregion

                public string schName = null;
                string model = null;
                #endregion

                #region [properties]
                #region  Selected Caldata Name
                [Browsable(true)]
                [TypeConverter(typeof(CalDataListConverter))]
                public string P1_CalData
                {
                        get { return p1_CalData; }
                        set { if (p1_CalData == value) return; p1_CalData = value; this.OnPropertyChanged(nameof(P1_CalData)); }
                }

                [Browsable(true)]
                [TypeConverter(typeof(CalDataListConverter))]
                public string P2_CalData
                {
                        get { return p2_CalData; }
                        set { if (p2_CalData == value) return; p2_CalData = value; this.OnPropertyChanged(nameof(P2_CalData)); }
                }
                [Browsable(true)]
                [TypeConverter(typeof(DisplayListConverter))]
                public string P1_Display
                {
                        get { return p1_Display; }
                        set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
                }

                [Browsable(true)]
                [TypeConverter(typeof(DisplayListConverter))]
                public string P2_Display
                {
                        get { return p2_Display; }
                        set { if (p2_Display == value) return; p2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
                }

                public CalDataObject P1_CalDataObj
                {
                        get { return SystemObject_Common.GetObject(p1_CalData) as CalDataObject; }
                }

                public CalDataObject P2_CalDataObj
                {
                        get { return SystemObject_Common.GetObject(p2_CalData) as CalDataObject; }
                }

                public CogDisplayObject P1_DisplayObj
                {
                        get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
                }

                public CogDisplayObject P2_DisplayObj
                {
                        get { return SystemObject_Display.GetObject(p2_Display) as CogDisplayObject; }
                }
                #endregion

                #region etc
                public CalcType CalcType
                {
                        get { return calcType; }
                        set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
                }
                public ThetaDirection ThetaDirection
                {
                        get { return thetaDirection; }
                        set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
                }
                public AlignMotionType AlignMotionType
                {
                        get { return alignMotionType; }
                        set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
                }
                public MachineType MachineType
                {
                        get { return machineType; }
                        set { Set<MachineType>(ref machineType, value, nameof(MachineType)); }
                }
                public bool IsVirtualTarget
                {
                        get { return isVirtualTarget; }
                        set { Set<bool>(ref isVirtualTarget, value, nameof(IsVirtualTarget)); }
                }
                public RetryJudgement RetryJudgement
                {
                        get { return retryJudgement; }
                        set { Set<RetryJudgement>(ref retryJudgement, value, nameof(RetryJudgement)); }
                }
                public Direction X1Direction
                {
                        get { return x1Direction; }
                        set { if (x1Direction == value) return; x1Direction = value; this.OnPropertyChanged(nameof(X1Direction)); }
                }
                public Direction X2Direction
                {
                        get { return x2Direction; }
                        set { if (x2Direction == value) return; x2Direction = value; this.OnPropertyChanged(nameof(X2Direction)); }
                }
                public Direction Y1Direction
                {
                        get { return y1Direction; }
                        set { if (y1Direction == value) return; y1Direction = value; this.OnPropertyChanged(nameof(Y1Direction)); }
                }
                public Direction Y2Direction
                {
                        get { return y2Direction; }
                        set { if (y2Direction == value) return; y2Direction = value; this.OnPropertyChanged(nameof(Y2Direction)); }
                }
                public OffsetType OffsetType
                {
                        get { return offsetType; }
                        set { if (offsetType == value) return; offsetType = value; this.OnPropertyChanged(nameof(OffsetType)); }
                }
                #endregion

                #region Align관련 Data
                public XYT RevAlign { get { return revAlign; } }
                public XYT RevUnload { get { return revUnload; } }
                public double Length_obj { get { return length_obj; } }
                public double Length_tar { get { return length_tar; } }
                public XYXY InspResult { get { return inspResult; } }
                XYXY VirtualTarget { get; set; } = new XYXY();

                #endregion
                #endregion

                #region[Construct]
                public Algo2PAttachObject()
                    : base()
                {
                        List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

                        //CommObj = lst.Count != 0 ? lst[0] : "";

                        foreach (var model in SystemModel.GetModels())
                        {
                                if (!ModelParams.ContainsKey(model))
                                        ModelParams.Add(model, new Algo2PAttachAlignModelParams());
                        }
                        CurParams = ModelParams[SystemModel.GetCurModel()];
                }
                #endregion

                #region [override methode]
                public override bool Run()
                {
                        if (calcType == CalcType.Align)
                                return AlignCalc();
                        else
                                return InspectionCalc();
                }
                public override void ObjectInitialize() { base.ObjectInitialize(); }
                public override void DefaultIOSet() { base.DefaultIOSet(); }
                public override void Dispose() { base.Dispose(); }
                #endregion

                #region [Private Method]
                private bool AlignCalc()
                {
                        model = SystemModel.GetCurModel();
                        errorCode = 0;
                        lastJudge = true;

                        #region PLC IOs Update
                        AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
                        #endregion

                        #region Model Data prepare
                        AlgoParams modelParams;
                        if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                        mParams = modelParams as Algo2PAttachAlignModelParams;
                        double limitX = (double)mParams.LimitX.Value;
                        double limitY = (double)mParams.LimitY.Value;
                        double limitT = (double)mParams.LimitT.Value;

                        double sensorsizeW = (double)mParams.SensorSize_W.Value;
                        double pixelcountW = (double)mParams.Pixel_Count_W.Value;
                        double lensMag = (double)mParams.Lens_Mag.Value;
                        double panelmarkdistance = (double)mParams.PanelMarkDistance.Value;
                        double scale_Lx = (double)mParams.Scale_Lx.Value;
                        double scale_Ly = (double)mParams.Scale_Ly.Value;
                        double scale_Rx = (double)mParams.Scale_Rx.Value;
                        double scale_Ry = (double)mParams.Scale_Ry.Value;
                        double spec_Lx = (double)mParams.Spec_Lx.Value;
                        double spec_Ly = (double)mParams.Spec_Ly.Value;
                        double spec_Rx = (double)mParams.Spec_Rx.Value;
                        double spec_Ry = (double)mParams.Spec_Ry.Value;
                        double tor_Lx = (double)mParams.Tor_Lx.Value;
                        double tor_Ly = (double)mParams.Tor_Ly.Value;
                        double tor_Rx = (double)mParams.Tor_Rx.Value;
                        double tor_Ry = (double)mParams.Tor_Ry.Value;

                        double spec_Length_Target = (double)mParams.Spec_Length_Target.Value;
                        double tor_Length_Target = (double)mParams.Tor_Length_Target.Value;
                        double spec_Length_Object = (double)mParams.Spec_Length_Object.Value;
                        double tor_Length_Object = (double)mParams.Tor_Length_Object.Value;
                        double scale_Length = (double)mParams.Scale_Length.Value;

                        double retryX = (double)mParams.RetryX?.Value;
                        double retryY = (double)mParams.RetryY?.Value;
                        double retryT = (double)mParams.RetryT?.Value;

                        XYT Limit = new XYT(limitX, limitY, limitT);
                        XYXY Scale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
                        XYXY Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
                        XYXY Tor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);

                        //bool isPanelMove = (bool)mParams.IsPanelMove.Value;
                        //double resolution = GetResolution(sensorsizeW, pixelcountW, lensMag);
                        #endregion

                        #region Mark Data Read& Confirm

                        // object
                        if (!InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
                        {
                                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                return false;
                        }

                        Mark_Obj1 = InputValues["Obj_P1"] as IPointResult;
                        Mark_Obj2 = InputValues["Obj_P2"] as IPointResult;
                        if (Mark_Obj1 == null || Mark_Obj2 == null)
                        {
                                // Mark Data가 Null임
                                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                return false;
                        }
                        Mark_Obj1_XY = Mark_Obj1.OutputXYT.ToXY();
                        Mark_Obj2_XY = Mark_Obj2.OutputXYT.ToXY();

                        // target
                        Mark_Tar1 = Mark_Tar2 = null;
                        if (IsVirtualTarget)
                        {
                                if (VirtualTarget.Lx == 0 || VirtualTarget.Ly == 0 || VirtualTarget.Rx == 0 || VirtualTarget.Ry == 0)
                                {
                                        errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                        return false;
                                }

                                Mark_Tar1_XY = new XY(VirtualTarget.Lx, VirtualTarget.Ly);
                                Mark_Tar2_XY = new XY(VirtualTarget.Rx, VirtualTarget.Ry);

                                Mark_Tar1 = new MatchingRstData() { OutputXYT = new XYT(Mark_Tar1_XY), Score = 100 };
                                Mark_Tar2 = new MatchingRstData() { OutputXYT = new XYT(Mark_Tar2_XY), Score = 100 };
                        }
                        else
                        {
                                if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2"))
                                {
                                        errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                        return false;
                                }

                                Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
                                Mark_Tar2 = InputValues["Tar_P2"] as IPointResult;
                                if (Mark_Tar1 == null || Mark_Tar2 == null)
                                {
                                        // Mark Data가 Null임
                                        errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                        return false;
                                }
                                Mark_Tar1_XY = Mark_Tar1.OutputXYT.ToXY();
                                Mark_Tar2_XY = Mark_Tar2.OutputXYT.ToXY();
                        }
                        #endregion

                        #region Coordinate Pos Calc & CalData Cofirm
                        if (P1_CalDataObj == null || P2_CalDataObj == null) //CalData는 2개, 카메라 왼쪽, 오른쪽
                        {
                                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                                // Calibration 설정 안됨.
                                return false;
                        }
                        Robot_Tar1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));   //Film(T)
                        Robot_Tar2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y));   //Film(T)

                        Robot_Obj1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));   //PNL(O)
                        Robot_Obj2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));   //PNL(O)

                        XY RotCent1 = P1_CalDataObj.GetRotateCenter(model);
                        XY RotCent2 = P2_CalDataObj.GetRotateCenter(model);

                        Coord_Tar1 = Robot_Tar1 + RotCent1;
                        Coord_Tar2 = Robot_Tar2 + RotCent2;

                        Coord_Obj1 = Robot_Obj1 + RotCent1;
                        Coord_Obj2 = Robot_Obj2 + RotCent2;
                        #endregion

                        #region Calc Rev Offset
                        #region Offset 적용
                        Offsets = null;
                        alignOffset = null;
                        if (OffsetType == OffsetType.XYT)
                        {
                                Offsets = CvtPLCIO.OffsetXYT;  //Log찍게
                                alignOffset = CvtPLCIO.OffsetXYT;

                                double Theta = GetTheta(Coord_Tar1, Coord_Tar2);
                                Theta = NormalizeTheta(Theta);

                                Spec.Lx = X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                                Spec.Ly = Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                                Spec.Rx = X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                                Spec.Ry = Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                                XY Coord_Tar1_Temp = new XY();
                                XY Coord_Tar2_Temp = new XY();

                                Coord_Tar1_Temp.X = Coord_Tar1.X + Math.Cos(Theta) * Spec.Lx - Math.Sin(Theta) * Spec.Ly;
                                Coord_Tar1_Temp.Y = Coord_Tar1.Y + Math.Sin(Theta) * Spec.Lx + Math.Cos(Theta) * Spec.Ly;
                                Coord_Tar2_Temp.X = Coord_Tar2.X + Math.Cos(Theta) * Spec.Rx - Math.Sin(Theta) * Spec.Ry;
                                Coord_Tar2_Temp.Y = Coord_Tar2.Y + Math.Sin(Theta) * Spec.Rx + Math.Cos(Theta) * Spec.Ry;

                                (alignOffset as XYT).X /= scale_Lx;
                                (alignOffset as XYT).Y /= scale_Ly;
                                (alignOffset as XYT).T /= scale_Rx;

                                TarCenter = ApplyTargetOffset(Coord_Tar1_Temp, Coord_Tar2_Temp, alignOffset);
                        }
                        else
                        {
                                // 기존 PLC Offset값 저장.
                                Offsets = CvtPLCIO.OffsetXYXY;  //Log찍게
                                alignOffset = CvtPLCIO.OffsetXYXY;

                                //Distance Spec 누적
                                (alignOffset as XYXY).Lx += X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                                (alignOffset as XYXY).Ly += Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                                (alignOffset as XYXY).Rx += X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                                (alignOffset as XYXY).Ry += Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                                //Scale적용
                                (alignOffset as XYXY).Lx /= scale_Lx;
                                (alignOffset as XYXY).Ly /= scale_Ly;
                                (alignOffset as XYXY).Rx /= scale_Rx;
                                (alignOffset as XYXY).Ry /= scale_Ry;

                                TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);
                        }
                        #endregion

                        revAlign = new XYT();
                        double radT, DriftX, DriftY;

                        // Attach 위치 보정값 계산.             
                        XY ObjXY = (Coord_Obj1 + Coord_Obj2) / 2;
                        double T = GetTheta(Coord_Obj1, Coord_Obj2);
                        T = NormalizeTheta(T);
                        XYT ObjCenter = new XYT(ObjXY.X, ObjXY.Y, T);

                        radT = TarCenter.T - ObjCenter.T;

                        DriftX = Math.Cos(radT) * ObjCenter.X - Math.Sin(radT) * ObjCenter.Y;
                        DriftY = Math.Sin(radT) * ObjCenter.X + Math.Cos(radT) * ObjCenter.Y;

                        revAlign.X = TarCenter.X - DriftX;
                        revAlign.Y = TarCenter.Y - DriftY;
                        if (ThetaDirection == ThetaDirection.Normal)    //정방향
                                revAlign.T = radT / rad;
                        else //역방향
                                revAlign.T = (radT / rad) * -1;

                        #endregion

                        #region Cal Inspection
                        InspectionCalc_(); // Align을 pixel CalData로 할 리가 없다.
                        P1_DisplayObj.Judgement = (uint)Judgement.InspOK;
                        P2_DisplayObj.Judgement = (uint)Judgement.InspOK;
                        #endregion

                        #region Confirm Result (Align Spec Over Check)

                        #region retry spec over
                        switch (retryJudgement)
                        {
                                case RetryJudgement.Alignment:
                                        if (!(retryX == 0.0 && retryY == 0.0 && retryT == 0.0)
                                            && (Math.Abs(revAlign.X) > retryX || Math.Abs(revAlign.Y) > retryY || Math.Abs(revAlign.T) > retryT))
                                        {
                                                P1_DisplayObj.Judgement = (uint)Judgement.Warning;
                                                P2_DisplayObj.Judgement = (uint)Judgement.Warning;
                                                errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                                                lastJudge = false;
                                        }
                                        break;
                                case RetryJudgement.Distance:
                                        if (!(Spec.Ly == 0.0 && Tor.Ly == 0.0 && Spec.Ly == 0.0 && Tor.Ly == 0.0)
                                            && (inspResult.Ly > Spec.Ly + Tor.Ly || inspResult.Ly < Spec.Ly - Tor.Ly || inspResult.Ry > Spec.Ry + Tor.Ry || inspResult.Ly < Spec.Ry - Tor.Ry))
                                        {
                                                P1_DisplayObj.Judgement = (uint)Judgement.Warning;
                                                P2_DisplayObj.Judgement = (uint)Judgement.Warning;
                                                errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                                                lastJudge = false;
                                        }
                                        break;
                        }
                        #endregion

                        #region Calc Length
                        length_tar = GetLength(Coord_Tar1, Coord_Tar2);
                        length_obj = GetLength(Coord_Obj1, Coord_Obj2);
                        if (!ConfirmLength(length_tar, spec_Length_Target, tor_Length_Target) || !ConfirmLength(length_obj, spec_Length_Object, tor_Length_Object))
                        {
                                P1_DisplayObj.Judgement = (uint)Judgement.L_Check;
                                P2_DisplayObj.Judgement = (uint)Judgement.L_Check;
                                errorCode = AlgoActionBase.Err_Length_Check;

                                lastJudge = false;
                        }
                        #endregion

                        #region limit spec over
                        if (!ConfirmResult(revAlign, Limit))
                        {
                                P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                                P2_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                                lastJudge = false;
                        }
                        #endregion

                        #endregion


                        #region DrawOverlay & ImageSave
                        Task.Factory.StartNew(() => DrawLineLabel_L(model, Mark_Tar1, Mark_Obj1));
                        Task.Factory.StartNew(() => DrawLineLabel_R(model, Mark_Tar2, Mark_Obj2));
                        #endregion

                        #region Result Data Update(DataGridView Insert)
                        if (OffsetType == OffsetType.XYT)
                        {
                                AlgoRst = new Algo2PAttachResult
                                {
                                        Name = name,
                                        ID = sourceID,

                                        CurTime = DateTime.Now.ToString("HH:mm:ss"),
                                        CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                                        Lx = Math.Round(inspResult.Lx, 3),
                                        Ly = Math.Round(inspResult.Ly, 3),
                                        Rx = Math.Round(inspResult.Rx, 3),
                                        Ry = Math.Round(inspResult.Ry, 3),

                                        Offset1X = Math.Round(revAlign.X, 3),
                                        Offset1Y = Math.Round(revAlign.Y, 3),
                                        Offset1T = Math.Round(revAlign.T, 3),

                                        Length_tar = Math.Round(length_tar, 3),
                                        Length_obj = Math.Round(length_obj, 3),
                                        Result = true,

                                        P1_X = Math.Round(Coord_Tar1.X, 3),  //Mark Pixel 좌표
                                        P1_Y = Math.Round(Coord_Tar1.Y, 3),
                                        P2_X = Math.Round(Coord_Tar2.X, 3),
                                        P2_Y = Math.Round(Coord_Tar2.Y, 3),

                                        C1_X = Math.Round(Coord_Obj1.X, 3),
                                        C1_Y = Math.Round(Coord_Obj1.Y, 3),
                                        C2_X = Math.Round(Coord_Obj2.X, 3),
                                        C2_Y = Math.Round(Coord_Obj2.Y, 3),

                                        PlcOffset_Lx = Math.Round((Offsets as XYT).X, 3),
                                        PlcOffset_Ly = Math.Round((Offsets as XYT).Y, 3),
                                        PlcOffset_Rx = Math.Round((Offsets as XYT).T, 3),
                                };
                        }
                        else
                        {
                                AlgoRst = new Algo2PAttachResult
                                {
                                        Name = name,
                                        ID = sourceID,

                                        CurTime = DateTime.Now.ToString("HH:mm:ss"),
                                        CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                                        Lx = Math.Round(inspResult.Lx, 3),
                                        Ly = Math.Round(inspResult.Ly, 3),
                                        Rx = Math.Round(inspResult.Rx, 3),
                                        Ry = Math.Round(inspResult.Ry, 3),

                                        Offset1X = Math.Round(revAlign.X, 3),
                                        Offset1Y = Math.Round(revAlign.Y, 3),
                                        Offset1T = Math.Round(revAlign.T, 3),

                                        Length_tar = Math.Round(length_tar, 3),
                                        Length_obj = Math.Round(length_obj, 3),
                                        Result = true,

                                        P1_X = Math.Round(Coord_Tar1.X, 3),  //Mark Pixel 좌표
                                        P1_Y = Math.Round(Coord_Tar1.Y, 3),
                                        P2_X = Math.Round(Coord_Tar2.X, 3),
                                        P2_Y = Math.Round(Coord_Tar2.Y, 3),

                                        C1_X = Math.Round(Coord_Obj1.X, 3),
                                        C1_Y = Math.Round(Coord_Obj1.Y, 3),
                                        C2_X = Math.Round(Coord_Obj2.X, 3),
                                        C2_Y = Math.Round(Coord_Obj2.Y, 3),

                                        PlcOffset_Lx = Math.Round((Offsets as XYXY).Lx, 3),
                                        PlcOffset_Ly = Math.Round((Offsets as XYXY).Ly, 3),
                                        PlcOffset_Rx = Math.Round((Offsets as XYXY).Rx, 3),
                                        PlcOffset_Ry = Math.Round((Offsets as XYXY).Ry, 3),
                                };
                        }

                        SystemLogger.WriteAlignDBLog(name, AlgoRst);
                        #endregion

                        #region Vision Write (Result & FDC)
                        WriteVisionIO(revAlign, revUnload, inspResult, "", calcType);
                        #endregion
                        return lastJudge;
                }

                private bool InspectionCalc()
                {
                        model = SystemModel.GetCurModel();
                        errorCode = 0;
                        lastJudge = true;

                        #region PLC IOs Update
                        AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
                        #endregion

                        #region Mark Data Read& Confirm
                        // object
                        if (!InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
                        {
                                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                return false;
                        }

                        Mark_Obj1 = InputValues["Obj_P1"] as IPointResult;
                        Mark_Obj2 = InputValues["Obj_P2"] as IPointResult;
                        if (Mark_Obj1 == null || Mark_Obj2 == null)
                        {
                                // Mark Data가 Null임
                                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                return false;
                        }
                        Mark_Obj1_XY = Mark_Obj1.OutputXYT.ToXY();
                        Mark_Obj2_XY = Mark_Obj2.OutputXYT.ToXY();

                        // target
                        Mark_Tar1 = Mark_Tar2 = null;
                        if (IsVirtualTarget)
                        {
                                if (VirtualTarget.Lx == 0 || VirtualTarget.Ly == 0 || VirtualTarget.Rx == 0 || VirtualTarget.Ry == 0)
                                {
                                        errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                        return false;
                                }

                                Mark_Tar1_XY = new XY(VirtualTarget.Lx, VirtualTarget.Ly);
                                Mark_Tar2_XY = new XY(VirtualTarget.Rx, VirtualTarget.Ry);

                                Mark_Tar1 = new MatchingRstData() { OutputXYT = new XYT(Mark_Tar1_XY) };
                                Mark_Tar2 = new MatchingRstData() { OutputXYT = new XYT(Mark_Tar2_XY) };
                        }
                        else
                        {
                                if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2"))
                                {
                                        errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                        return false;
                                }

                                Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
                                Mark_Tar2 = InputValues["Tar_P2"] as IPointResult;
                                if (Mark_Tar1 == null || Mark_Tar2 == null)
                                {
                                        // Mark Data가 Null임
                                        errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                                        return false;
                                }
                                Mark_Tar1_XY = Mark_Tar1.OutputXYT.ToXY();
                                Mark_Tar2_XY = Mark_Tar2.OutputXYT.ToXY();
                        }
                        #endregion

                        #region Model Data prepare
                        AlgoParams modelParams;
                        if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                        mParams = modelParams as Algo2PAttachAlignModelParams;
                        double limitX = (double)mParams.LimitX.Value;
                        double limitY = (double)mParams.LimitY.Value;
                        double limitT = (double)mParams.LimitT.Value;

                        double sensorsizeW = (double)mParams.SensorSize_W.Value;
                        double pixelcountW = (double)mParams.Pixel_Count_W.Value;
                        double lensMag = (double)mParams.Lens_Mag.Value;
                        double panelmarkdistance = (double)mParams.PanelMarkDistance.Value;
                        double scale_Lx = (double)mParams.Scale_Lx.Value;
                        double scale_Ly = (double)mParams.Scale_Ly.Value;
                        double scale_Rx = (double)mParams.Scale_Rx.Value;
                        double scale_Ry = (double)mParams.Scale_Ry.Value;
                        double spec_Lx = (double)mParams.Spec_Lx.Value;
                        double spec_Ly = (double)mParams.Spec_Ly.Value;
                        double spec_Rx = (double)mParams.Spec_Rx.Value;
                        double spec_Ry = (double)mParams.Spec_Ry.Value;
                        double tor_Lx = (double)mParams.Tor_Lx.Value;
                        double tor_Ly = (double)mParams.Tor_Ly.Value;
                        double tor_Rx = (double)mParams.Tor_Rx.Value;
                        double tor_Ry = (double)mParams.Tor_Ry.Value;

                        double spec_Length_Target = (double)mParams.Spec_Length_Target.Value;
                        double tor_Length_Target = (double)mParams.Tor_Length_Target.Value;
                        double spec_Length_Object = (double)mParams.Spec_Length_Object.Value;
                        double tor_Length_Object = (double)mParams.Tor_Length_Object.Value;
                        double scale_Length = (double)mParams.Scale_Length.Value;
                        XYT Limit = new XYT(limitX, limitY, limitT);
                        XYXY Scale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
                        XYXY Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
                        XYXY Tor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);
                        #endregion

                        #region Coordinate Pos Calc & CalData Cofirm
                        if (P1_CalDataObj == null || P2_CalDataObj == null) //CalData는 2개, 카메라 왼쪽, 오른쪽
                        {
                                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                                // Calibration 설정 안됨.
                                return false;
                        }

                        Robot_Tar1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));   //Film(T)
                        Robot_Tar2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y));   //Film(T)

                        Robot_Obj1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));   //PNL(O)
                        Robot_Obj2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));   //PNL(O)

                        Coord_Tar1 = Robot_Tar1 + P1_CalDataObj.GetRotateCenter(model);
                        Coord_Tar2 = Robot_Tar2 + P2_CalDataObj.GetRotateCenter(model);

                        Coord_Obj1 = Robot_Obj1 + P1_CalDataObj.GetRotateCenter(model);
                        Coord_Obj2 = Robot_Obj2 + P2_CalDataObj.GetRotateCenter(model);
                        #endregion

                        #region Calc Rev Offset
                        #region Offset 적용            
                        alignOffset = new XYXY();
                        //Distance Spec 누적
                        (alignOffset as XYXY).Lx += X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                        (alignOffset as XYXY).Ly += Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                        (alignOffset as XYXY).Rx += X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                        (alignOffset as XYXY).Ry += Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                        TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);
                        #endregion

                        revAlign = new XYT();
                        double radT, DriftX, DriftY;

                        // Attach 위치 보정값 계산.             
                        XY ObjXY = (Coord_Obj1 + Coord_Obj2) / 2;
                        double T = GetTheta(Coord_Obj1, Coord_Obj2);
                        T = NormalizeTheta(T);
                        XYT ObjCenter = new XYT(ObjXY.X, ObjXY.Y, T);

                        radT = TarCenter.T - ObjCenter.T;

                        DriftX = Math.Cos(radT) * ObjCenter.X - Math.Sin(radT) * ObjCenter.Y;
                        DriftY = Math.Sin(radT) * ObjCenter.X + Math.Cos(radT) * ObjCenter.Y;

                        revAlign.X = TarCenter.X - DriftX;
                        revAlign.Y = TarCenter.Y - DriftY;
                        if (ThetaDirection == ThetaDirection.Normal)    //정방향
                                revAlign.T = radT / rad;
                        else //역방향
                                revAlign.T = (radT / rad) * -1;
                        #endregion

                        #region Resolution
                        //double resolution = GetResolution(sensorsizeW, pixelcountW, lensMag);
                        #endregion

                        #region Cal Inspection
                        InspectionCalc_();
                        P1_DisplayObj.Judgement = (uint)Judgement.InspOK;
                        P2_DisplayObj.Judgement = (uint)Judgement.InspOK;
                        #endregion

                        #region Confirm Result (Inspection Spec Over Check)
                        if (!ConfirmResult2(inspResult, Spec, Tor))
                        {
                                P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                                P2_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                                lastJudge = false;
                        }
                        #endregion

                        #region Calc Length & Confirm (Length Check)
                        length_tar = GetLength(Coord_Tar1, Coord_Tar2);
                        length_obj = GetLength(Coord_Obj1, Coord_Obj2);
                        if (!ConfirmLength(length_tar, spec_Length_Target, tor_Length_Target) || !ConfirmLength(length_obj, spec_Length_Object, tor_Length_Object))
                        {
                                P1_DisplayObj.Judgement = (uint)Judgement.L_Check;
                                P2_DisplayObj.Judgement = (uint)Judgement.L_Check;
                                lastJudge = false;
                        }
                        #endregion

                        #region DrawOverlay & ImageSave
                        Task.Factory.StartNew(() => DrawLineLabel_L(model, Mark_Tar1, Mark_Obj1));
                        Task.Factory.StartNew(() => DrawLineLabel_R(model, Mark_Tar2, Mark_Obj2));
                        #endregion

                        #region Result Data Update(DataGridView Insert)
                        AlgoRst = new Algo2PAttachResult
                        {
                                Name = name,
                                ID = sourceID,

                                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                                Lx = Math.Round(inspResult.Lx, 3),
                                Ly = Math.Round(inspResult.Ly, 3),
                                Rx = Math.Round(inspResult.Rx, 3),
                                Ry = Math.Round(inspResult.Ry, 3),

                                Offset1X = Math.Round(revAlign.X, 3),
                                Offset1Y = Math.Round(revAlign.Y, 3),
                                Offset1T = Math.Round(revAlign.T, 3),

                                Length_tar = Math.Round(length_tar, 3),
                                Length_obj = Math.Round(length_obj, 3),
                                Result = lastJudge,

                                P1_X = Math.Round(Coord_Tar1.X, 3),  //Mark Pixel 좌표
                                P1_Y = Math.Round(Coord_Tar1.Y, 3),
                                P2_X = Math.Round(Coord_Tar2.X, 3),
                                P2_Y = Math.Round(Coord_Tar2.Y, 3),

                                C1_X = Math.Round(Coord_Obj1.X, 3),
                                C1_Y = Math.Round(Coord_Obj1.Y, 3),
                                C2_X = Math.Round(Coord_Obj2.X, 3),
                                C2_Y = Math.Round(Coord_Obj2.Y, 3),
                        };

                        SystemLogger.WriteAlignDBLog(name, AlgoRst);
                        #endregion

                        #region Vision Write (Result & FDC)
                        WriteVisionIO(revAlign, revUnload, inspResult, "", calcType);
                        #endregion

                        return lastJudge;
                }

                private void InspectionCalc_()
                {
                        inspResult = new XYXY();
                        inspResult.Lx = GetDotDistance(Coord_Obj1, Coord_Tar1, Coord_Tar2);
                        inspResult.Ly = GetCrossDistance(Coord_Obj1, Coord_Tar1, Coord_Tar2);
                        inspResult.Rx = GetDotDistance(Coord_Obj2, Coord_Tar2, Coord_Tar1);
                        inspResult.Ry = GetCrossDistance(Coord_Obj2, Coord_Tar2, Coord_Tar1);

                        // Scale Apply
                        inspResult.Lx *= (double)mParams.Scale_Lx.Value;
                        inspResult.Ly *= (double)mParams.Scale_Ly.Value;
                        inspResult.Rx *= (double)mParams.Scale_Rx.Value;
                        inspResult.Ry *= (double)mParams.Scale_Ry.Value;
                }

                private XY GetV2R(XY xY, double resolution)
                {
                        XY robot = new XY(xY.X * resolution, xY.Y * -resolution);
                        return robot;
                }

                private double GetResolution(double sensorW, double pixelW, double lensMag)
                {
                        double Resolution = (sensorW / pixelW) / lensMag;
                        return Resolution;
                }

                protected bool ConfirmResult(XYXY revAlign, XYXY limit)
                {
                        if (!ConfirmSpecMinMax(revAlign.Lx, revAlign.Lx + limit.Lx * (-1), revAlign.Lx + limit.Lx) ||
                            !ConfirmSpecMinMax(revAlign.Ly, revAlign.Ly + limit.Ly * (-1), revAlign.Ly + limit.Ly) ||
                            !ConfirmSpecMinMax(revAlign.Rx, revAlign.Rx + limit.Rx * (-1), revAlign.Rx + limit.Rx) ||
                            !ConfirmSpecMinMax(revAlign.Ry, revAlign.Ry + limit.Ry * (-1), revAlign.Ry + limit.Ry))
                        {
                                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                                return false;
                        }

                        return true;
                }
                protected bool ConfirmResult2(XYXY rst, XYXY spec, XYXY tor)
                {
                        if (!ConfirmSpecMinMax(rst.Lx, Math.Abs(spec.Lx) + tor.Lx * (-1), Math.Abs(spec.Lx) + tor.Lx) ||
                            !ConfirmSpecMinMax(rst.Ly, Math.Abs(spec.Ly) + tor.Ly * (-1), Math.Abs(spec.Ly) + tor.Ly) ||
                            !ConfirmSpecMinMax(rst.Rx, Math.Abs(spec.Rx) + tor.Rx * (-1), Math.Abs(spec.Rx) + tor.Rx) ||
                            !ConfirmSpecMinMax(rst.Ry, Math.Abs(spec.Ry) + tor.Ry * (-1), Math.Abs(spec.Ry) + tor.Ry))
                        {
                                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                                return false;
                        }

                        return true;
                }

                protected bool ConfirmResult(XYT revAlign, XYT limit)
                {
                        if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                            !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                            !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
                        {
                                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                                return false;
                        }

                        return true;
                }

                protected bool ConfirmLength(double _length, double _spec, double _tor)
                {
                        if (_tor == 0) return true;

                        if (Math.Abs(_length - _spec) > _tor)
                        {
                                errorCode = AlgoActionBase.Err_Length_Check;
                                return false;
                        }

                        return true;
                }

                public override void AssignPLCData()
                {
                        if (MachineType == MachineType.Bending)
                        {
                                AssignPLCData_Bending();
                                return;
                        }
                        if (MachineType == MachineType.Attach)
                        {
                                AssignPLCData_Attach();
                                return;
                        }
                        // normal
                        base.AssignPLCData();
                }

                private void AssignPLCData_Bending()
                {
                        UpdatePLCIOs();

                        CvtPLCIO = new StdPLCTable();

                        CvtPLCIO.Offset1 = (double)PlcValues["Offset_X_X1"].CurValue;
                        CvtPLCIO.Offset2 = (double)PlcValues["Offset_Y_X2"].CurValue;
                        CvtPLCIO.Offset3 = (double)PlcValues["Offset_T_Y1"].CurValue;
                        CvtPLCIO.Offset4 = (double)PlcValues["Offset_Y2"].CurValue;

                        CvtPLCIO.CurPos1 = (double)PlcValues["Cur_Position_X1_U_X"].CurValue;
                        CvtPLCIO.CurPos2 = (double)PlcValues["Cur_Position_X2_V_Y"].CurValue;
                        CvtPLCIO.CurPos3 = (double)PlcValues["Cur_Position_Y1_W_T"].CurValue;
                        CvtPLCIO.CurPos4 = (double)PlcValues["Cur_Position_Y2"].CurValue;

                        CvtPLCIO.Teach1_Pos1 = (double)PlcValues["Teacing_Position_X1_U_X"].CurValue;
                        CvtPLCIO.Teach1_Pos2 = (double)PlcValues["Teacing_Position_X2_V_Y"].CurValue;
                        CvtPLCIO.Teach1_Pos3 = (double)PlcValues["Teacing_Position_Y1_W_T"].CurValue;
                        CvtPLCIO.Teach1_Pos4 = (double)PlcValues["Teacing_Position_Y2"].CurValue;

                        if (IsVirtualTarget)
                        {
                                VirtualTarget.Lx = (double)PlcValues["VirtualTarget_LX"].CurValue;
                                VirtualTarget.Ly = (double)PlcValues["VirtualTarget_LY"].CurValue;
                                VirtualTarget.Rx = (double)PlcValues["VirtualTarget_RX"].CurValue;
                                VirtualTarget.Ry = (double)PlcValues["VirtualTarget_RY"].CurValue;
                        }

                        CvtPLCIO.SourceID = (string)PlcValues["Source_ID"].CurValue;

                        if (!string.IsNullOrEmpty(CvtPLCIO.SourceID))
                                SourceID = CvtPLCIO.SourceID;
                }

                private void AssignPLCData_Attach()
                {
                        UpdatePLCIOs();

                        CvtPLCIO = new StdPLCTable();

                        CvtPLCIO.UnitNo = (int)PlcValues["UnitNo"].CurValue;
                        CvtPLCIO.OptionNo = (int)PlcValues["OptionNo"].CurValue;
                        CvtPLCIO.Offset1 = (double)PlcValues["Offset#1"].CurValue;
                        CvtPLCIO.Offset2 = (double)PlcValues["Offset#2"].CurValue;
                        CvtPLCIO.Offset3 = (double)PlcValues["Offset#3"].CurValue;
                        CvtPLCIO.Offset4 = (double)PlcValues["Offset#4"].CurValue;

                        CvtPLCIO.CurPos1 = (double)PlcValues["CurPos#1"].CurValue;
                        CvtPLCIO.CurPos2 = (double)PlcValues["CurPos#2"].CurValue;
                        CvtPLCIO.CurPos3 = (double)PlcValues["CurPos#3"].CurValue;
                        CvtPLCIO.CurPos4 = (double)PlcValues["CurPos#4"].CurValue;

                        CvtPLCIO.Teach1_Pos1 = (double)PlcValues["Teach#1_Pos#1"].CurValue;
                        CvtPLCIO.Teach1_Pos2 = (double)PlcValues["Teach#1_Pos#2"].CurValue;
                        CvtPLCIO.Teach1_Pos3 = (double)PlcValues["Teach#1_Pos#3"].CurValue;
                        CvtPLCIO.Teach1_Pos4 = (double)PlcValues["Teach#1_Pos#4"].CurValue;

                        CvtPLCIO.Teach2_Pos1 = (double)PlcValues["Teach#2_Pos#1"].CurValue;
                        CvtPLCIO.Teach2_Pos2 = (double)PlcValues["Teach#2_Pos#2"].CurValue;
                        CvtPLCIO.Teach2_Pos3 = (double)PlcValues["Teach#2_Pos#3"].CurValue;
                        CvtPLCIO.Teach2_Pos4 = (double)PlcValues["Teach#2_Pos#4"].CurValue;

                        CvtPLCIO.CamPosX1 = (double)PlcValues["CamPosX#1"].CurValue;
                        CvtPLCIO.CamPosX2 = (double)PlcValues["CamPosX#2"].CurValue;
                        CvtPLCIO.CamPosY = (double)PlcValues["CamPosY"].CurValue;
                        CvtPLCIO.SourceID = (string)PlcValues["SourceID"].CurValue;
                        CvtPLCIO.TargetID = (string)PlcValues["TargetID"].CurValue;


                        if (!string.IsNullOrEmpty(CvtPLCIO.SourceID))
                                SourceID = CvtPLCIO.SourceID;


                        if (IsVirtualTarget)
                        {
                                VirtualTarget.Lx = (double)PlcValues["VirtualTarget_LX"].CurValue;
                                VirtualTarget.Ly = (double)PlcValues["VirtualTarget_LY"].CurValue;
                                VirtualTarget.Rx = (double)PlcValues["VirtualTarget_RX"].CurValue;
                                VirtualTarget.Ry = (double)PlcValues["VirtualTarget_RY"].CurValue;
                        }

                }

                public void WriteVisionIO(XYT rev1, XYT rev2, XYXY insp, string ID, CalcType calcType = CalcType.Align)
                {
                        if (MachineType == MachineType.Bending)
                        {
                                WriteVisionIO_Bending(rev1, rev2, insp, ID, calcType);
                                return;
                        }

                        // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
                        var IOs = new List<IOStruct>();

                        if (calcType == CalcType.Align)
                        {
                                switch (alignMotionType)
                                {
                                        case AlignMotionType.XY:
                                        case AlignMotionType.XYT:
                                                VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                                                VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                                                VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                                                VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                                                VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                                                VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                                                XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                                                XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                                                VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                                                VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                                                VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                                                VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                                                VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                                                VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                                                VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                                                VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                                                break;
                                        case AlignMotionType.UVW:
                                                break;
                                        case AlignMotionType.UVRW:
                                                break;

                                }
                        }
                        else
                        {
                                VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                                VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                                VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                                VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                                VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                                VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                                var io = new IOStruct();
                                if (VisionValues.ContainsKey("InspectionLx")) { VisionValues["InspectionLx"].NextValue = (double)insp.Lx; IOs.Add(VisionValues["InspectionLx"]); }
                                if (VisionValues.ContainsKey("InspectionLy")) { VisionValues["InspectionLy"].NextValue = (double)insp.Ly; IOs.Add(VisionValues["InspectionLy"]); }
                                if (VisionValues.ContainsKey("InspectionRx")) { VisionValues["InspectionRx"].NextValue = (double)insp.Rx; IOs.Add(VisionValues["InspectionRx"]); }
                                if (VisionValues.ContainsKey("InspectionRy")) { VisionValues["InspectionRy"].NextValue = (double)insp.Ry; IOs.Add(VisionValues["InspectionRy"]); }
                        }

                        if (MachineType == MachineType.CSpacer)
                        {
                                // report matching score to fdc
                                VisionValues["Score_Target_L"].NextValue = Mark_Tar1.Score; IOs.Add(VisionValues["Score_Target_L"]);
                                VisionValues["Score_Target_R"].NextValue = Mark_Tar2.Score; IOs.Add(VisionValues["Score_Target_R"]);
                                VisionValues["Score_Object_L"].NextValue = Mark_Obj1.Score; IOs.Add(VisionValues["Score_Object_L"]);
                                VisionValues["Score_Object_R"].NextValue = Mark_Obj2.Score; IOs.Add(VisionValues["Score_Object_R"]);
                        }
                        //2020.09.04 jhj 천안2단밴딩 Attach 부, PLC에서 Spec In 판단 기준
                        if (MachineType == MachineType.Attach)
                        {
                                VisionValues["InspectionLx"].NextValue = insp.Lx; IOs.Add(VisionValues["InspectionLx"]);
                                VisionValues["InspectionLy"].NextValue = insp.Ly; IOs.Add(VisionValues["InspectionLy"]);
                                VisionValues["InspectionRx"].NextValue = insp.Rx; IOs.Add(VisionValues["InspectionRx"]);
                                VisionValues["InspectionRy"].NextValue = insp.Ry; IOs.Add(VisionValues["InspectionRy"]);
                        }

                        //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

                        CommodObject.SetVisionValues(IOs);
                }

                private void WriteVisionIO_Bending(XYT rev1, XYT rev2, XYXY insp, string iD, CalcType calcType)
                {
                        // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
                        var IOs = new List<IOStruct>();

                        if (calcType == CalcType.Align)
                        {
                                switch (alignMotionType)
                                {
                                        case AlignMotionType.XY:
                                        case AlignMotionType.XYT:
                                                // rev
                                                VisionValues["Rev_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev_X"]);
                                                VisionValues["Rev_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev_Y"]);
                                                VisionValues["Rev_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev_T"]);

                                                // length
                                                VisionValues["Distance_X1"].NextValue = insp.Lx; IOs.Add(VisionValues["Distance_X1"]);
                                                VisionValues["Distance_Y1"].NextValue = insp.Ly; IOs.Add(VisionValues["Distance_Y1"]);
                                                VisionValues["Distance_X3"].NextValue = insp.Rx; IOs.Add(VisionValues["Distance_X3"]);
                                                VisionValues["Distance_Y3"].NextValue = insp.Ry; IOs.Add(VisionValues["Distance_Y3"]);

                                                // target
                                                XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                                                VisionValues["Tar_Position_X1_U_X"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar_Position_X1_U_X"]);
                                                VisionValues["Tar_Position_X2_V_Y"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar_Position_X2_V_Y"]);
                                                VisionValues["Tar_Position_Y1_W_T"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar_Position_Y1_W_T"]);
                                                VisionValues["Tar_Position_Y2"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar_Position_Y2"]);
                                                break;
                                        case AlignMotionType.UVW:
                                                break;
                                        case AlignMotionType.UVRW:
                                                break;

                                }

                                // report matching score to fdc
                                if (VisionValues.ContainsKey("MatchingScore_L")) { VisionValues["MatchingScore_L"].NextValue = Mark_Obj1.Score; IOs.Add(VisionValues["MatchingScore_L"]); }
                                if (VisionValues.ContainsKey("MatchingScore_R")) { VisionValues["MatchingScore_R"].NextValue = Mark_Obj2.Score; IOs.Add(VisionValues["MatchingScore_R"]); }
                                if (VisionValues.ContainsKey("MatchingScore_L_Target")) { VisionValues["MatchingScore_L_Target"].NextValue = Mark_Tar1.Score; IOs.Add(VisionValues["MatchingScore_L_Target"]); }
                                if (VisionValues.ContainsKey("MatchingScore_R_Target")) { VisionValues["MatchingScore_R_Target"].NextValue = Mark_Tar2.Score; IOs.Add(VisionValues["MatchingScore_R_Target"]); }
                        }
                        else // inspection
                        {
                                var io = new IOStruct();
                                if (VisionValues.ContainsKey("Distance_X1")) { VisionValues["Distance_X1"].NextValue = (double)insp.Lx; IOs.Add(VisionValues["Distance_X1"]); }
                                if (VisionValues.ContainsKey("Distance_Y1")) { VisionValues["Distance_Y1"].NextValue = (double)insp.Ly; IOs.Add(VisionValues["Distance_Y1"]); }
                                if (VisionValues.ContainsKey("Distance_X3")) { VisionValues["Distance_X3"].NextValue = (double)insp.Rx; IOs.Add(VisionValues["Distance_X3"]); }
                                if (VisionValues.ContainsKey("Distance_Y3")) { VisionValues["Distance_Y3"].NextValue = (double)insp.Ry; IOs.Add(VisionValues["Distance_Y3"]); }
                        }


                        //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

                        CommodObject.SetVisionValues(IOs);
                }

                //protected void DrawLineLabel_L(Iva.Bplus.Interface.IPointResult Mark_Tar, Iva.Bplus.Interface.IPointResult Mark_Obj, 
                //                             double resolution, double panelangle_rad, CogColorConstants color)
                protected void DrawLineLabel_L(string _model, Iva.Bplus.Interface.IPointResult _target, Iva.Bplus.Interface.IPointResult _object)
                {
                        string _sourceID = DeepClone(sourceID);
                        DateTime dateTime = DateTime.Now;
                        string model = _model;

                        #region Draw Results
                        if (IsVirtualTarget)
                        {
                                // draw virtual point
                                CogDrawMarkerInfo vm = new CogDrawMarkerInfo();
                                vm.Color = CogColorConstants.White;
                                vm.SizeInScreenPixels = 50;
                                vm.Offset = _target.OutputXYT;
                                P1_DisplayObj.DrawMaker(vm);
                        }

                        // Draw Overlay (Maker) // 걍..크로스포인트
                        CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
                        makerInfo.Color = CogColorConstants.Red;
                        var crossPoint_P1 = new XYT() + GetCrossPoint(Coord_Obj1, Coord_Tar1, Coord_Tar2) - P1_CalDataObj.GetRotateCenter(model);
                        crossPoint_P1 = P1_CalDataObj.GetR2V(model, crossPoint_P1);
                        makerInfo.Offset = crossPoint_P1;
                        P1_DisplayObj.DrawMaker(makerInfo);

                        // Draw Overlay (Line)
                        CogDrawLineInfo lineInfo = new CogDrawLineInfo();
                        lineInfo.LineWidthInScreenPixels = 2;
                        lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
                        lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
                        lineInfo.Color = CogColorConstants.Red;
                        lineInfo.Start = Mark_Tar1_XY;
                        lineInfo.End = crossPoint_P1.ToXY();
                        P1_DisplayObj.DrawLine(lineInfo);
                        lineInfo.Start = Mark_Obj1_XY;
                        lineInfo.End = crossPoint_P1.ToXY();
                        P1_DisplayObj.DrawLine(lineInfo);

                        // Draw Overlay (Label)
                        CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
                        labelInfo.UseBackColor = true;
                        labelInfo.BackColor = CogColorConstants.White;
                        labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Obj1_XY) / 2;
                        labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                        labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ly);
                        P1_DisplayObj.DrawLabel(labelInfo);
                        labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Tar1_XY) / 2;
                        labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                        labelInfo.Text = string.Format("{0:f2}mm", inspResult.Lx);
                        P1_DisplayObj.DrawLabel(labelInfo);
                        #endregion

                        string _judgement = "";
                        foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
                        {
                                if (P1_DisplayObj.Judgement == (uint)j)
                                {
                                        _judgement = j.ToString();
                                        break;
                                }
                        }

                        object obj = (Bitmap)P1_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                        P1_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);

                        if (P1_DisplayObj.Judgement != (uint)Judgement.InspOK && P1_DisplayObj.Judgement != (uint)Judgement.None)
                        {
                                object obj1 = P1_DisplayObj.GetCurImage();
                                P1_DisplayObj.SaveImage(dateTime, obj1, _judgement, schName, _sourceID, false);
                        }
                }
                protected void DrawLineLabel_R(string _model, Iva.Bplus.Interface.IPointResult _target, Iva.Bplus.Interface.IPointResult _object)
                {
                        string _sourceID = DeepClone(sourceID);
                        DateTime dateTime = DateTime.Now;
                        string model = _model;

                        #region Draw Results
                        if (IsVirtualTarget)
                        {
                                // draw virtual point
                                CogDrawMarkerInfo vm = new CogDrawMarkerInfo();
                                vm.Color = CogColorConstants.White;
                                vm.SizeInScreenPixels = 50;
                                vm.Offset = _target.OutputXYT;
                                P2_DisplayObj.DrawMaker(vm);
                        }
                        // Draw Overlay (Maker) // 걍..크로스포인트
                        CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
                        makerInfo.Color = CogColorConstants.Red;
                        var crossPoint_P2 = new XYT() + GetCrossPoint(Coord_Obj2, Coord_Tar2, Coord_Tar1) - P2_CalDataObj.GetRotateCenter(model);
                        crossPoint_P2 = P2_CalDataObj.GetR2V(model, crossPoint_P2);
                        makerInfo.Offset = crossPoint_P2;
                        P2_DisplayObj.DrawMaker(makerInfo);

                        // Draw Overlay (Line)
                        CogDrawLineInfo lineInfo = new CogDrawLineInfo();
                        lineInfo.LineWidthInScreenPixels = 2;
                        lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
                        lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
                        lineInfo.Color = CogColorConstants.Red;
                        lineInfo.Start = Mark_Tar2_XY;
                        lineInfo.End = crossPoint_P2.ToXY();
                        P2_DisplayObj.DrawLine(lineInfo);
                        lineInfo.Start = Mark_Obj2_XY;
                        lineInfo.End = crossPoint_P2.ToXY();
                        P2_DisplayObj.DrawLine(lineInfo);

                        // Draw Overlay (Label)
                        CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
                        labelInfo.UseBackColor = true;
                        labelInfo.BackColor = CogColorConstants.White;
                        labelInfo.Offset = (crossPoint_P2.ToXY() + Mark_Obj2_XY) / 2;
                        labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                        labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ry);
                        P2_DisplayObj.DrawLabel(labelInfo);
                        labelInfo.Offset = (crossPoint_P2.ToXY() + Mark_Tar2_XY) / 2;
                        labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                        labelInfo.Text = string.Format("{0:f2}mm", inspResult.Rx);
                        P2_DisplayObj.DrawLabel(labelInfo);
                        #endregion

                        string _judgement = "";
                        foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
                        {
                                if (P2_DisplayObj.Judgement == (uint)j)
                                {
                                        _judgement = j.ToString();
                                        break;
                                }
                        }

                        object obj = (Bitmap)P2_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                        P2_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);

                        if (P2_DisplayObj.Judgement != (uint)Judgement.InspOK && P2_DisplayObj.Judgement != (uint)Judgement.None)
                        {
                                object obj1 = P2_DisplayObj.GetCurImage();
                                P2_DisplayObj.SaveImage(dateTime, obj1, _judgement, schName, _sourceID, false);
                        }
                }

                protected void DrawInspResult(string _model, Iva.Bplus.Interface.IPointResult _target1, Iva.Bplus.Interface.IPointResult _target2, Iva.Bplus.Interface.IPointResult _object1, Iva.Bplus.Interface.IPointResult _object2)
                {
                        string model = _model;

                        #region Draw Results
                        // Draw Overlay (Maker) // 걍..크로스포인트
                        CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
                        makerInfo.Color = CogColorConstants.Red;
                        var crossPoint_P1 = new XYT() + GetCrossPoint(Coord_Obj1, Coord_Tar1, Coord_Tar2) - P1_CalDataObj.GetRotateCenter(model);
                        crossPoint_P1 = P1_CalDataObj.GetR2V(model, crossPoint_P1);
                        makerInfo.Offset = crossPoint_P1;
                        P1_DisplayObj.DrawMaker(makerInfo);
                        var crossPoint_P2 = new XYT() + GetCrossPoint(Coord_Obj2, Coord_Tar2, Coord_Tar1) - P2_CalDataObj.GetRotateCenter(model);
                        crossPoint_P2 = P2_CalDataObj.GetR2V(model, crossPoint_P2);
                        makerInfo.Offset = crossPoint_P2;
                        P2_DisplayObj.DrawMaker(makerInfo);

                        // Draw Overlay (Line)
                        CogDrawLineInfo lineInfo = new CogDrawLineInfo();
                        lineInfo.LineWidthInScreenPixels = 2;
                        lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
                        lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
                        lineInfo.Color = CogColorConstants.Red;
                        lineInfo.Start = Mark_Tar1.OutputXYT.ToXY();
                        lineInfo.End = crossPoint_P1.ToXY();
                        P1_DisplayObj.DrawLine(lineInfo);
                        lineInfo.Start = Mark_Obj1.OutputXYT.ToXY();
                        lineInfo.End = crossPoint_P1.ToXY();
                        P1_DisplayObj.DrawLine(lineInfo);
                        lineInfo.Start = Mark_Tar2.OutputXYT.ToXY();
                        lineInfo.End = crossPoint_P2.ToXY();
                        P2_DisplayObj.DrawLine(lineInfo);
                        lineInfo.Start = Mark_Obj2.OutputXYT.ToXY();
                        lineInfo.End = crossPoint_P2.ToXY();
                        P2_DisplayObj.DrawLine(lineInfo);

                        // Draw Overlay (Label)
                        CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
                        labelInfo.UseBackColor = true;
                        labelInfo.BackColor = CogColorConstants.White;
                        labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Obj1.OutputXYT.ToXY()) / 2;
                        labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                        labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ly);
                        P1_DisplayObj.DrawLabel(labelInfo);
                        labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Tar1.OutputXYT.ToXY()) / 2;
                        labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                        labelInfo.Text = string.Format("{0:f2}mm", inspResult.Lx);
                        P1_DisplayObj.DrawLabel(labelInfo);
                        labelInfo.Offset = (crossPoint_P2.ToXY() + Mark_Obj2.OutputXYT.ToXY()) / 2;
                        labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                        labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ry);
                        P2_DisplayObj.DrawLabel(labelInfo);
                        labelInfo.Offset = (crossPoint_P2.ToXY() + Mark_Tar2.OutputXYT.ToXY()) / 2;
                        labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                        labelInfo.Text = string.Format("{0:f2}mm", inspResult.Rx);
                        P2_DisplayObj.DrawLabel(labelInfo);
                        #endregion
                }


                public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
                {
                        Task task = Task.Factory.StartNew(() =>
                        cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true
                        ));
                }
                #endregion


        }
}

