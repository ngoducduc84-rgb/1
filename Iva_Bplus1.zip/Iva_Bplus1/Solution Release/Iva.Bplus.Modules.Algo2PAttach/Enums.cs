﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo2PAttach
{
    public enum CalcType { Align, Inspection }
    public enum ThetaDirection { Normal, Reverse }
    public enum Direction { Normal, Reverse }
    public enum GrabPos { P1, P2 }
    public enum OffsetType { XYT, XYXY }
    public enum MachineType { Normal, Bending, CSpacer, Attach}
    public enum RetryJudgement { Alignment, Distance } // alignment : rev x,y,t ; distance : Ly, Ry spec
}

