﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo2PAttach
{
    public partial class Algo2PAttachShape
    {
        public override void UpdateHistory()
        {
            // ModuleBase Update History Loading
            base.UpdateHistory();

            /* Sample */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "First Release Version",                            // Update Title
                Version = new Version(1, 0, 0, 0),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>          // Update Item List
                {
                   "1. None",
                   "2. None",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2019, 4, 4, 17, 0, 0),                  // year, month, day, hour, minute, second
            });
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "Anmicorn Version",                            // Update Title
                Version = new Version(1, 0, 0, 0917),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>          // Update Item List
                {
                   "표준시편 검사 추가", "Spec NG 時 Image Error로 저장"
                },
                Author = "Taekyong Lee",                                     // Author Name
                Email = "taekyong.lee@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2019, 9, 17, 13, 0, 0),                  // year, month, day, hour, minute, second
            });

            /* Additional Update History */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "Source Property 삭제",                             // Update Title
                Version = new Version(1, 0, 0, 1),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "Source Property 삭제",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 1, 10, 10, 0, 0),                  // year, month, day, hour, minute, second
            });
        }
    }
}
