﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo2PAttachMXN
{
    [SerializableAttribute]
    public partial class Algo2PAttachMXNObject : AlgoObjectBase
    {
        #region [Fields]
        Algo2PAttachMXNAlignModelParams mParams;
        #region  Selected Caldata Name
        private string p1_CalData;
        private string p2_CalData;
        private string p1_Display;
        private string p2_Display;
        #endregion

        #region etc
        private CalcType calcType = CalcType.Inspection;
        private ThetaDirection thetaDirection = ThetaDirection.Normal;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        private Direction x1Direction = Direction.Reverse;
        private Direction x2Direction = Direction.Normal;
        private Direction y1Direction = Direction.Normal;
        private Direction y2Direction = Direction.Normal;
        private OffsetType offsetType = OffsetType.XYXY;
        //에러코드관련
        XY errOffset = new XY(5,60);
        CogColorConstants errColor = CogColorConstants.Orange;
        #endregion

        #region Align결과 관련
        XYT revAlign = new XYT();
        XYT revUnload = new XYT();
        double length_obj = 0.0;
        double length_tar = 0.0;
        XYXY inspResult = new XYXY();
        #endregion

        #region Coordinate 관련
        XY Robot_Tar1 = new XY();
        XY Robot_Tar2 = new XY();
        XY Robot_Obj1 = new XY();
        XY Robot_Obj2 = new XY();
        XY Coord_Tar1 = new XY();
        XY Coord_Tar2 = new XY();
        XY Coord_Obj1 = new XY();
        XY Coord_Obj2 = new XY();

        XY Mark_Panel1 = new XY();
        XY Mark_Panel2 = new XY();
        XY Mark_notPanel1 = new XY();
        XY Mark_notPanel2 = new XY();
        XY Robot_notPanel1 = new XY();
        XY Robot_notPanel2 = new XY();
        XY Robot_Panel1 = new XY();
        XY Robot_Panel2 = new XY();

        double panelangle_rad = 0;
        object alignOffset;
        object Offsets;
        #endregion
        #endregion

        #region [properties]
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P1_CalData
        {
            get { return p1_CalData; }
            set { if (p1_CalData == value) return; p1_CalData = value; this.OnPropertyChanged(nameof(P1_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P2_CalData
        {
            get { return p2_CalData; }
            set { if (p2_CalData == value) return; p2_CalData = value; this.OnPropertyChanged(nameof(P2_CalData)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P2_Display
        {
            get { return p2_Display; }
            set { if (p2_Display == value) return; p2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
        }

        public CalDataObject P1_CalDataObj
        {
            get { return SystemObject_Common.GetObject(p1_CalData) as CalDataObject; }
        }

        public CalDataObject P2_CalDataObj
        {
            get { return SystemObject_Common.GetObject(p2_CalData) as CalDataObject; }
        }

        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P2_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p2_Display) as CogDisplayObject; }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }
        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }

        public Direction X1Direction
        {
            get { return x1Direction; }
            set { if (x1Direction == value) return; x1Direction = value; this.OnPropertyChanged(nameof(X1Direction)); }
        }
        public Direction X2Direction
        {
            get { return x2Direction; }
            set { if (x2Direction == value) return; x2Direction = value; this.OnPropertyChanged(nameof(X2Direction)); }
        }
        public Direction Y1Direction
        {
            get { return y1Direction; }
            set { if (y1Direction == value) return; y1Direction = value; this.OnPropertyChanged(nameof(Y1Direction)); }
        }
        public Direction Y2Direction
        {
            get { return y2Direction; }
            set { if (y2Direction == value) return; y2Direction = value; this.OnPropertyChanged(nameof(Y2Direction)); }
        }
        public OffsetType OffsetType
        {
            get { return offsetType; }
            set { if (offsetType == value) return; offsetType = value; this.OnPropertyChanged(nameof(OffsetType)); }
        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        public double Length_obj { get { return length_obj; } }
        public double Length_tar { get { return length_tar; } }
        public XYXY InspResult { get { return inspResult; } }

        #endregion
        #endregion

        #region[Construct]
        public Algo2PAttachMXNObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo2PAttachMXNAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            if (calcType == CalcType.Align)
                return AlignCalc();
            else
                return InspectionCalc();
        }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool AlignCalc()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            mParams = modelParams as Algo2PAttachMXNAlignModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;

            var sensorsizeW = (double)mParams.SensorSize_W.Value;
            var pixelcountW = (double)mParams.Pixel_Count_W.Value;
            var lensMag = (double)mParams.Lens_Mag.Value;
            var panelmarkdistance = (double)mParams.PanelMarkDistance.Value;
            var scale_Lx = (double)mParams.Scale_Lx.Value;
            var scale_Ly = (double)mParams.Scale_Ly.Value;
            var scale_Rx = (double)mParams.Scale_Rx.Value;
            var scale_Ry = (double)mParams.Scale_Ry.Value;
            var spec_Lx = (double)mParams.Spec_Lx.Value;
            var spec_Ly = (double)mParams.Spec_Ly.Value;
            var spec_Rx = (double)mParams.Spec_Rx.Value;
            var spec_Ry = (double)mParams.Spec_Ry.Value;
            var tor_Lx = (double)mParams.Tor_Lx.Value;
            var tor_Ly = (double)mParams.Tor_Ly.Value;
            var tor_Rx = (double)mParams.Tor_Rx.Value;
            var tor_Ry = (double)mParams.Tor_Ry.Value;

            var spec_Length = (double)mParams.Spec_Length.Value;
            var tor_Length = (double)mParams.Tor_Length.Value;
            var scale_Length = (double)mParams.Scale_Length.Value;
            var Limit = new XYT(limitX, limitY, limitT);
            var Scale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
            var Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
            var Tor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);

            var isPanelMove = (bool)mParams.IsPanelMove.Value;
            double resolution = GetResolution(sensorsizeW, pixelcountW, lensMag);
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2") || !InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }
           
            var Mark_Tar1 = InputValues["Tar_P1"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Tar2 = InputValues["Tar_P2"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Obj1 = InputValues["Obj_P1"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Obj2 = InputValues["Obj_P2"] as Iva.Bplus.Interface.IPointResult;
            if (Mark_Tar1 == null || Mark_Tar2 == null || Mark_Obj1 == null || Mark_Obj2 == null) 
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null || P2_CalDataObj == null) //CalData는 2개, 카메라 왼쪽, 오른쪽
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_CalData_Is_Null");
                // Calibration 설정 안됨.
                return false;
            }
            Robot_Tar1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));   //Film(T)
            Robot_Tar2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y));   //Film(T)

            Robot_Obj1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));   //PNL(O)
            Robot_Obj2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));   //PNL(O)

            Coord_Tar1 = Robot_Tar1 + P1_CalDataObj.GetRotateCenter(model);
            Coord_Tar2 = Robot_Tar2 + P2_CalDataObj.GetRotateCenter(model);

            Coord_Obj1 = Robot_Obj1 + P1_CalDataObj.GetRotateCenter(model);
            Coord_Obj2 = Robot_Obj2 + P2_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Calc Rev Offset
            #region Offset 적용
            Offsets = null;
            alignOffset = null;
            if (OffsetType == OffsetType.XYT)
            {
                var Offsets_temp = CvtPLCIO.OffsetXYT;  //Log찍게
                var alignOffset_temp = CvtPLCIO.OffsetXYT;
                Offsets = Offsets_temp;
                alignOffset = alignOffset_temp;

                (alignOffset as XYT).X /= scale_Lx;
                (alignOffset as XYT).Y /= scale_Ly;
                (alignOffset as XYT).T /= scale_Rx;
            }
            else
            {
                // 기존 PLC Offset값 저장.
                var Offsets_temp = CvtPLCIO.OffsetXYXY;  //Log찍게
                var alignOffset_temp = CvtPLCIO.OffsetXYXY;
                Offsets = Offsets_temp;
                alignOffset = alignOffset_temp;
                //Distance Spec 누적
                (alignOffset as XYXY).Lx += X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                (alignOffset as XYXY).Ly += Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                (alignOffset as XYXY).Rx += X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                (alignOffset as XYXY).Ry += Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                //Scale적용
                (alignOffset as XYXY).Lx /= scale_Lx;
                (alignOffset as XYXY).Ly /= scale_Ly;
                (alignOffset as XYXY).Rx /= scale_Rx;
                (alignOffset as XYXY).Ry /= scale_Ry;
            }
            
            #endregion

            revAlign = new XYT();
            revUnload = new XYT();

            double radT, DriftX, DriftY;
        
            // Attach 위치 보정값 계산. 
            XYT TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);    // 일단 정리 필요하네...혼란하다..ㅋ
            XY ObjXY = (Coord_Obj1 + Coord_Obj2) / 2;
            double T = GetTheta(Coord_Obj1, Coord_Obj2);
            T = NormalizeTheta(T);
            XYT ObjCenter = new XYT(ObjXY.X, ObjXY.Y,T);

            radT = TarCenter.T - ObjCenter.T;
            
            DriftX = Math.Cos(radT) * ObjCenter.X - Math.Sin(radT) * ObjCenter.Y;
            DriftY = Math.Sin(radT) * ObjCenter.X + Math.Cos(radT) * ObjCenter.Y;

            revAlign.X = TarCenter.X - DriftX;
            revAlign.Y = TarCenter.Y - DriftY;
            if (ThetaDirection == ThetaDirection.Normal)    //정방향
                revAlign.T = radT / rad;
            else //역방향
                revAlign.T = (radT / rad) * -1;

            #endregion

            #region Cal Inspection
            InspectionCalc_(isPanelMove, 0, panelmarkdistance); // Align을 pixel CalData로 할 리가 없다.

            DrawLineLabel_L(model, Robot_notPanel1, Robot_Panel1, panelangle_rad, CogColorConstants.Red);
            DrawLineLabel_R(model, Robot_notPanel2, Robot_Panel2, panelangle_rad, CogColorConstants.Red);
            #endregion



            #region Calc Length
            var length_tar = GetLength(Coord_Tar1, Coord_Tar2);
            var length_obj = GetLength(Coord_Obj1, Coord_Obj2);
            #endregion


            #region 센터가 목표인 얼라인 추가 부분
            var robot_Tar1 = new XY(0, 0);   //Film(T)
            var robot_Tar2 = new XY(0, 0);   //Film(T)

            //Robot_Obj1 = P1_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));   //PNL(O)
            //Robot_Obj2 = P2_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));   //PNL(O)

            var coord_Tar1 = robot_Tar1 + P1_CalDataObj.GetRotateCenter(model);
            var coord_Tar2 = robot_Tar2 + P2_CalDataObj.GetRotateCenter(model);

            //Coord_Obj1 = Robot_Obj1 + P1_CalDataObj.GetRotateCenter(model);
            //Coord_Obj2 = Robot_Obj2 + P2_CalDataObj.GetRotateCenter(model);

            //TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);    // 일단 정리 필요하네...혼란하다..ㅋ
            double camT = GetThetaColumn(coord_Tar1.X, coord_Tar2.X, coord_Tar1.Y, coord_Tar2.Y);
            var camTar = (coord_Tar1 + coord_Tar2) / 2;
            var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
            var tarCenter = ApplyTargetOffset(camTarxyt, new XYT(0,0,0));

            var objXY = (Coord_Obj1 + Coord_Obj2) / 2;
            var t = GetTheta(Coord_Obj1, Coord_Obj2);
            t = NormalizeTheta(t);
            var objCenter = new XYT(objXY.X, objXY.Y, t);

            var radT_ = tarCenter.T - objCenter.T;

            var driftX = Math.Cos(radT_) * objCenter.X - Math.Sin(radT_) * objCenter.Y;
            var driftY = Math.Sin(radT_) * objCenter.X + Math.Cos(radT_) * objCenter.Y;

            revUnload.X = tarCenter.X - driftX;
            revUnload.Y = tarCenter.Y - driftY;
            if (ThetaDirection == ThetaDirection.Normal)    //정방향
                revUnload.T = radT_ / rad;
            else //역방향
                revUnload.T = (radT_ / rad) * -1;
            #endregion


            #region Result Data Update(DataGridView Insert)
            if (OffsetType == OffsetType.XYT)
            {
                AlgoRst = new Algo2PAttachMXNResult
                {
                    Name = name,
                    ID = sourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    Lx = Math.Round(inspResult.Lx, 3),
                    Ly = Math.Round(inspResult.Ly, 3),
                    Rx = Math.Round(inspResult.Rx, 3),
                    Ry = Math.Round(inspResult.Ry, 3),

                    Offset1X = Math.Round(revAlign.X, 3),
                    Offset1Y = Math.Round(revAlign.Y, 3),
                    Offset1T = Math.Round(revAlign.T, 3),

                    Offset2X = Math.Round(revUnload.X, 3),
                    Offset2Y = Math.Round(revUnload.Y, 3),
                    Offset2T = Math.Round(revUnload.T, 3),

                    Length_tar = Math.Round(length_tar, 3),
                    Length_obj = Math.Round(length_obj, 3),
                    Result = true,

                    PlcOffset_Lx = Math.Round((Offsets as XYT).X, 3),
                    PlcOffset_Ly = Math.Round((Offsets as XYT).Y, 3),
                    PlcOffset_Rx = Math.Round((Offsets as XYT).T, 3),

                    //좌표 정보 로그 추가
                    Mark_Panel_L_X = Math.Round(Mark_Obj1.OutputXYT.X, 3),
                    Mark_Panel_L_Y = Math.Round(Mark_Obj1.OutputXYT.Y, 3),
                    Mark_Panel_R_X = Math.Round(Mark_Obj2.OutputXYT.X, 3),
                    Mark_Panel_R_Y = Math.Round(Mark_Obj2.OutputXYT.Y, 3),

                    Mark_notPanel_L_X = Math.Round(Mark_Tar1.OutputXYT.X, 3),
                    Mark_notPanel_L_Y = Math.Round(Mark_Tar1.OutputXYT.Y, 3),
                    Mark_notPanel_R_X = Math.Round(Mark_Tar2.OutputXYT.X, 3),
                    Mark_notPanel_R_Y = Math.Round(Mark_Tar2.OutputXYT.Y, 3),

                    Robot_Panel_L_X = Math.Round(Coord_Obj1.X, 3),
                    Robot_Panel_L_Y = Math.Round(Coord_Obj1.Y, 3),
                    Robot_Panel_R_X = Math.Round(Coord_Obj2.X, 3),
                    Robot_Panel_R_Y = Math.Round(Coord_Obj2.Y, 3),

                    Robot_notPanel_L_X = Math.Round(Coord_Tar1.X, 3),
                    Robot_notPanel_L_Y = Math.Round(Coord_Tar1.Y, 3),
                    Robot_notPanel_R_X = Math.Round(Coord_Tar2.X, 3),
                    Robot_notPanel_R_Y = Math.Round(Coord_Tar2.Y, 3),
                };
            }
            else
            {
                AlgoRst = new Algo2PAttachMXNResult
                {
                    Name = name,
                    ID = sourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    Lx = Math.Round(inspResult.Lx, 3),
                    Ly = Math.Round(inspResult.Ly, 3),
                    Rx = Math.Round(inspResult.Rx, 3),
                    Ry = Math.Round(inspResult.Ry, 3),

                    Offset1X = Math.Round(revAlign.X, 3),
                    Offset1Y = Math.Round(revAlign.Y, 3),
                    Offset1T = Math.Round(revAlign.T, 3),

                    Offset2X = Math.Round(revUnload.X, 3),
                    Offset2Y = Math.Round(revUnload.Y, 3),
                    Offset2T = Math.Round(revUnload.T, 3),

                    Length_tar = Math.Round(length_tar, 3),
                    Length_obj = Math.Round(length_obj, 3),
                    Result = true,

                    PlcOffset_Lx = Math.Round((Offsets as XYXY).Lx, 3),
                    PlcOffset_Ly = Math.Round((Offsets as XYXY).Ly, 3),
                    PlcOffset_Rx = Math.Round((Offsets as XYXY).Rx, 3),
                    PlcOffset_Ry = Math.Round((Offsets as XYXY).Ry, 3),

                    //좌표 정보 로그 추가
                    Mark_Panel_L_X = Math.Round(Mark_Obj1.OutputXYT.X, 3),
                    Mark_Panel_L_Y = Math.Round(Mark_Obj1.OutputXYT.Y, 3),
                    Mark_Panel_R_X = Math.Round(Mark_Obj2.OutputXYT.X, 3),
                    Mark_Panel_R_Y = Math.Round(Mark_Obj2.OutputXYT.Y, 3),

                    Mark_notPanel_L_X = Math.Round(Mark_Tar1.OutputXYT.X, 3),
                    Mark_notPanel_L_Y = Math.Round(Mark_Tar1.OutputXYT.Y, 3),
                    Mark_notPanel_R_X = Math.Round(Mark_Tar2.OutputXYT.X, 3),
                    Mark_notPanel_R_Y = Math.Round(Mark_Tar2.OutputXYT.Y, 3),

                    Robot_Panel_L_X = Math.Round(Coord_Obj1.X, 3),
                    Robot_Panel_L_Y = Math.Round(Coord_Obj1.Y, 3),
                    Robot_Panel_R_X = Math.Round(Coord_Obj2.X, 3),
                    Robot_Panel_R_Y = Math.Round(Coord_Obj2.Y, 3),

                    Robot_notPanel_L_X = Math.Round(Coord_Tar1.X, 3),
                    Robot_notPanel_L_Y = Math.Round(Coord_Tar1.Y, 3),
                    Robot_notPanel_R_X = Math.Round(Coord_Tar2.X, 3),
                    Robot_notPanel_R_Y = Math.Round(Coord_Tar2.Y, 3),
                };
            }

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Confirm Result
            //if (!ConfirmResult(revAlign, limit))
            //    return false;
            #endregion

            //#region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, revUnload, sourceID);
            //#endregion
            return true;
        }

        private bool InspectionCalc()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2") || !InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            var Mark_Tar1 = InputValues["Tar_P1"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Tar2 = InputValues["Tar_P2"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Obj1 = InputValues["Obj_P1"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Obj2 = InputValues["Obj_P2"] as Iva.Bplus.Interface.IPointResult;
            if (Mark_Tar1 == null || Mark_Tar2 == null || Mark_Obj1 == null || Mark_Obj2 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null || P2_CalDataObj == null) //CalData는 2개, 카메라 왼쪽, 오른쪽
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_CalData_Is_Null");
                // Calibration 설정 안됨.
                return false;
            }
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            mParams = modelParams as Algo2PAttachMXNAlignModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            var isPanelMove = (bool)mParams.IsPanelMove.Value;
            var sensorsizeW = (double)mParams.SensorSize_W.Value;
            var pixelcountW = (double)mParams.Pixel_Count_W.Value;
            var lensMag = (double)mParams.Lens_Mag.Value;

            var panelmarkdistance = (double)mParams.PanelMarkDistance.Value;
            var scale_Lx = (double)mParams.Scale_Lx.Value;
            var scale_Ly = (double)mParams.Scale_Ly.Value;
            var scale_Rx = (double)mParams.Scale_Rx.Value;
            var scale_Ry = (double)mParams.Scale_Ry.Value;
            var spec_Lx = (double)mParams.Spec_Lx.Value;
            var spec_Ly = (double)mParams.Spec_Ly.Value;
            var spec_Rx = (double)mParams.Spec_Rx.Value;
            var spec_Ry = (double)mParams.Spec_Ry.Value;
            var tor_Lx = (double)mParams.Tor_Lx.Value;
            var tor_Ly = (double)mParams.Tor_Ly.Value;
            var tor_Rx = (double)mParams.Tor_Rx.Value;
            var tor_Ry = (double)mParams.Tor_Ry.Value;

            var spec_Length = (double)mParams.Spec_Length.Value;
            var tor_Length = (double)mParams.Tor_Length.Value;
            var scale_Length = (double)mParams.Scale_Length.Value;
            var Limit = new XYT(limitX, limitY, limitT);
            var Scale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
            var Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
            var Tor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);

            // 2021.02.06 JSH Rev 계산 Option 변경
            bool Sel_Rev_Image_Center = (bool)mParams.Sel_Rev_Image_Center.Value;
            #endregion

            #region Resolution
            double resolution = GetResolution(sensorsizeW, pixelcountW, lensMag);
            #endregion

            #region Cal Inspection
            InspectionCalc_(isPanelMove, 0, panelmarkdistance);
			
            //두 매칭 결과간의 길이정보 표시
            DrawLineLabel_L(model, Robot_notPanel1, Robot_Panel1, panelangle_rad, CogColorConstants.Red);
            DrawLineLabel_R(model, Robot_notPanel2, Robot_Panel2, panelangle_rad, CogColorConstants.Red);

            revAlign = new XYT();
            revAlign.X = Robot_Panel1.X;
            revAlign.Y = Robot_Panel1.Y;
            revAlign.T = RadianToDegree(panelangle_rad);

            revUnload = new XYT();
            double camDistance = panelmarkdistance * Math.Cos(panelangle_rad) + Robot_Panel1.X - Robot_Panel2.X;
            revUnload.X = Robot_Panel2.X + camDistance;
            revUnload.Y = Robot_Panel2.Y;
            revUnload.T = RadianToDegree(panelangle_rad);

            //InspectionCalc_()에서 계산함
            //// Scale Apply
            //inspResult.Lx *= scale_Lx;
            //inspResult.Ly *= scale_Ly;
            //inspResult.Rx *= scale_Rx;
            //inspResult.Ry *= scale_Ry;
            #endregion

            var dist_R = Math.Sqrt(Math.Pow(inspResult.Rx, 2) + Math.Pow(inspResult.Ry, 2));
            var dist_L = Math.Sqrt(Math.Pow(inspResult.Lx, 2) + Math.Pow(inspResult.Ly, 2));

            // 2021.02.06 JSH Inspection Revision X,Y 기준 변경 (Image Origin -> Image Center)
            double Robot_RevX = 0.0, Robot_RevY = 0.0;
            if (Sel_Rev_Image_Center)
            {
                XY Image1_Center = new XY();
                XY Robot_Image1_Center = new XY();

                Image1_Center.X = P1_DisplayObj.CogDs.Image.Width / 2.0 - 1.0;
                Image1_Center.Y = P1_DisplayObj.CogDs.Image.Height / 2.0 - 1.0;
                Robot_Image1_Center = P1_CalDataObj.GetV2R(model, Image1_Center, true, true);   //PNL(O)
                Robot_RevX = Robot_Panel1.X - Robot_Image1_Center.X;
                Robot_RevY = Robot_Panel1.Y - Robot_Image1_Center.Y;
            }
            else
            {
                Robot_RevX = Robot_Panel1.X;
                Robot_RevY = Robot_Panel1.Y;
            }

            #region Result Data Update(DataGridView Insert)
            // 2021.02.06 JSH Rev 계산 Option 변경
            AlgoRst = new Algo2PAttachMXNResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Lx = Math.Round(inspResult.Lx, 3),
                Ly = Math.Round(inspResult.Ly, 3),
                Rx = Math.Round(inspResult.Rx, 3),
                Ry = Math.Round(inspResult.Ry, 3),

                RevX = Math.Round(Robot_RevX, 3)/*2021.02.06 JSH 변경*/,
                RevY = Math.Round(Robot_RevY, 3)/*2021.02.06 JSH 변경*/,
                //RevX = Math.Round(Robot_Panel1.X, 3),
                //RevY = Math.Round(Robot_Panel1.Y, 3),
                RevT = Math.Round(RadianToDegree(panelangle_rad), 3),

                Length_tar = Math.Round(length_tar, 3),
                Length_obj = Math.Round(length_obj, 3),
                Result = true,

                //좌표 정보 로그 추가
                Mark_Panel_L_X = Math.Round(Mark_Panel1.X, 3),
                Mark_Panel_L_Y = Math.Round(Mark_Panel1.Y, 3),
                Mark_Panel_R_X = Math.Round(Mark_Panel2.X, 3),
                Mark_Panel_R_Y = Math.Round(Mark_Panel2.Y, 3),

                Mark_notPanel_L_X = Math.Round(Mark_notPanel1.X, 3),
                Mark_notPanel_L_Y = Math.Round(Mark_notPanel1.Y, 3),
                Mark_notPanel_R_X = Math.Round(Mark_notPanel2.X, 3),
                Mark_notPanel_R_Y = Math.Round(Mark_notPanel2.Y, 3),

                Robot_Panel_L_X = Math.Round(Robot_Panel1.X, 3),
                Robot_Panel_L_Y = Math.Round(Robot_Panel1.Y, 3),
                Robot_Panel_R_X = Math.Round(Robot_Panel2.X, 3),
                Robot_Panel_R_Y = Math.Round(Robot_Panel2.Y, 3),

                Robot_notPanel_L_X = Math.Round(Robot_notPanel1.X, 3),
                Robot_notPanel_L_Y = Math.Round(Robot_notPanel1.Y, 3),
                Robot_notPanel_R_X = Math.Round(Robot_notPanel2.X, 3),
                Robot_notPanel_R_Y = Math.Round(Robot_notPanel2.Y, 3),

                //두점간의 거리  L, R
                Distance = string.Format("{0:f4}, {1:f4}", Math.Round(dist_L, 3), Math.Round(dist_R, 3)),

            };
            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Confirm Result
            if (calcType == CalcType.Align)
            {
                if (!ConfirmResult(revAlign, Limit))
                    return false;
            }
            else
            {
                if (!ConfirmResult2(inspResult, Spec, Tor))
                    return false;
            }
            #endregion

            //#region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, revUnload, sourceID);
            //#endregion

            return true;
        }

        private void InspectionCalc_(bool isPanelMove, double resolution = 0, double panelmarkdistance = 0)
        {
            string model = SystemModel.GetCurModel();

            var mark_Tar1 = InputValues["Tar_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Tar2 = InputValues["Tar_P2"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj1 = InputValues["Obj_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj2 = InputValues["Obj_P2"] as Iva.Bplus.Interface.IPointResult;

            // Distance Calc
            if (isPanelMove) // Object is Panel
            {
                Mark_Panel1 = new XY(mark_Obj1.OutputXYT.X, mark_Obj1.OutputXYT.Y);
                Mark_Panel2 = new XY(mark_Obj2.OutputXYT.X, mark_Obj2.OutputXYT.Y);
                Mark_notPanel1 = new XY(mark_Tar1.OutputXYT.X, mark_Tar1.OutputXYT.Y);
                Mark_notPanel2 = new XY(mark_Tar2.OutputXYT.X, mark_Tar2.OutputXYT.Y);

            }
            else // Target is Panel
            {
                Mark_Panel1 = new XY(mark_Tar1.OutputXYT.X, mark_Tar1.OutputXYT.Y);
                Mark_Panel2 = new XY(mark_Tar2.OutputXYT.X, mark_Tar2.OutputXYT.Y);
                Mark_notPanel1 = new XY(mark_Obj1.OutputXYT.X, mark_Obj1.OutputXYT.Y);
                Mark_notPanel2 = new XY(mark_Obj2.OutputXYT.X, mark_Obj2.OutputXYT.Y);
            }

            Robot_notPanel1 = new XY();
            Robot_notPanel2 = new XY();
            Robot_Panel1 = new XY();
            Robot_Panel2 = new XY();

            if (resolution == 0) // CalData 사용
            {
                Robot_notPanel1 = P1_CalDataObj.GetV2R(model, Mark_notPanel1, true, true);   //Film(T)
                Robot_notPanel2 = P2_CalDataObj.GetV2R(model, Mark_notPanel2, true, true);   //Film(T)

                Robot_Panel1 = P1_CalDataObj.GetV2R(model, Mark_Panel1, true, true);   //PNL(O)
                Robot_Panel2 = P2_CalDataObj.GetV2R(model, Mark_Panel2, true, true);   //PNL(O)
            }
            else // PixelData 사용
            {
                Robot_notPanel1 = GetV2R(Mark_notPanel1, resolution);   //Film(T)
                Robot_notPanel2 = GetV2R(Mark_notPanel2, resolution);   //Film(T)
                Robot_Panel1 = GetV2R(Mark_Panel1, resolution);   //PNL(O)
                Robot_Panel2 = GetV2R(Mark_Panel2, resolution);   //PNL(O)
            }

            panelangle_rad = Math.Asin((Robot_Panel2.Y - Robot_Panel1.Y) / panelmarkdistance);
            double camDistance = panelmarkdistance * Math.Cos(panelangle_rad) + Robot_Panel1.X - Robot_Panel2.X;

            XY Cood_Panel2 = new XY(Robot_Panel2.X + camDistance, Robot_Panel2.Y);
            XY Cood_notPanel2 = new XY(Robot_notPanel2.X + camDistance, Robot_notPanel2.Y);
            // Robot_Tar1.X + (panelmarkdistance-5.65) * Math.Cos(panelangle_rad);

            //XY eigenVector = new XY(Math.Cos(panelangle_rad), Math.Sin(panelangle_rad));

            //XY Vector1 = new XY(Robot_Tar1.X - Robot_Obj1.X, Robot_Tar1.Y - Robot_Obj1.Y);
            //XY Vector2 = new XY(Robot_Tar2.X - Robot_Obj2.X, Robot_Tar2.Y - Robot_Obj2.Y);
            inspResult = new XYXY();
            inspResult.Lx = GetDotDistance(Robot_notPanel1, Robot_Panel1, Cood_Panel2);
            inspResult.Ly = GetCrossDistance(Robot_notPanel1, Robot_Panel1, Cood_Panel2);
            inspResult.Rx = GetDotDistance(Cood_notPanel2, Cood_Panel2, Robot_Panel1);
            inspResult.Ry = GetCrossDistance(Cood_notPanel2, Cood_Panel2, Robot_Panel1);

            // Scale Apply
            inspResult.Lx *= (double)mParams.Scale_Lx.Value;
            inspResult.Ly *= (double)mParams.Scale_Ly.Value;
            inspResult.Rx *= (double)mParams.Scale_Rx.Value;
            inspResult.Ry *= (double)mParams.Scale_Ry.Value;
        }

        private XY GetV2R(XY xY, double resolution)
        {
            XY robot = new XY(xY.X * resolution, xY.Y * -resolution);
            return robot;
        }

        private double GetResolution(double sensorW, double pixelW, double lensMag)
        {
            double Resolution = (sensorW / pixelW) / lensMag;
            return Resolution;
        }

        protected bool ConfirmResult(XYXY revAlign, XYXY limit)
        {
            if (!ConfirmSpecMinMax(revAlign.Lx, revAlign.Lx + limit.Lx * (-1), revAlign.Lx + limit.Lx) ||
                !ConfirmSpecMinMax(revAlign.Ly, revAlign.Ly + limit.Ly * (-1), revAlign.Ly + limit.Ly) ||
                !ConfirmSpecMinMax(revAlign.Rx, revAlign.Rx + limit.Rx * (-1), revAlign.Rx + limit.Rx) ||
                !ConfirmSpecMinMax(revAlign.Ry, revAlign.Ry + limit.Ry * (-1), revAlign.Ry + limit.Ry))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Tolerance_Exceeded");
                return false;
            }

            return true;
        }
        protected bool ConfirmResult2(XYXY rst, XYXY spec, XYXY tor)
        {
            if (!ConfirmSpecMinMax(rst.Lx, spec.Lx + tor.Lx * (-1), spec.Lx + tor.Lx) ||
                !ConfirmSpecMinMax(rst.Ly, spec.Ly + tor.Ly * (-1), spec.Ly + tor.Ly) ||
                !ConfirmSpecMinMax(rst.Rx, spec.Rx + tor.Rx * (-1), spec.Rx + tor.Rx) ||
                !ConfirmSpecMinMax(rst.Ry, spec.Ry + tor.Ry * (-1), spec.Ry + tor.Ry))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                //디스플레이에 에러코드 보여줌
                //DrawErrDisp("Err_Tolerance_Exceeded");
                return false;
            }

            return true;
        }

        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T) )
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Tolerance_Exceeded");
                return false;
            }

            return true;
        }


        public void WriteVisionIO(XYT rev1, XYT rev2, XYXY insp, string ID, CalcType calcType = CalcType.Align)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            if (calcType == CalcType.Align)
            {
                switch (alignMotionType)
                {
                    case AlignMotionType.XY:
                    case AlignMotionType.XYT:
                        VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                        VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                        VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                        VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                        VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                        VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                        XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                        XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                        VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                        VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                        VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                        VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                        VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                        VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                        VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                        VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);

                        VisionValues["InspectionLx"].NextValue = (double)insp.Lx; IOs.Add(VisionValues["InspectionLx"]);
                        VisionValues["InspectionLy"].NextValue = (double)insp.Ly; IOs.Add(VisionValues["InspectionLy"]);
                        VisionValues["InspectionRx"].NextValue = (double)insp.Rx; IOs.Add(VisionValues["InspectionRx"]);
                        VisionValues["InspectionRy"].NextValue = (double)insp.Ry; IOs.Add(VisionValues["InspectionRy"]);
                        break;
                    case AlignMotionType.UVW:
                        break;
                    case AlignMotionType.UVRW:
                        break;

                }
            }
            else
            {
                VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                VisionValues["InspectionLx"].NextValue = (double)insp.Lx; IOs.Add(VisionValues["InspectionLx"]);
                VisionValues["InspectionLy"].NextValue = (double)insp.Ly; IOs.Add(VisionValues["InspectionLy"]);
                VisionValues["InspectionRx"].NextValue = (double)insp.Rx; IOs.Add(VisionValues["InspectionRx"]);
                VisionValues["InspectionRy"].NextValue = (double)insp.Ry; IOs.Add(VisionValues["InspectionRy"]);
            }

            // report matching score to fdc
            var Mark_Tar1 = InputValues["Tar_P1"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Tar2 = InputValues["Tar_P2"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Obj1 = InputValues["Obj_P1"] as Iva.Bplus.Interface.IPointResult;
            var Mark_Obj2 = InputValues["Obj_P2"] as Iva.Bplus.Interface.IPointResult;
            VisionValues["Score_Target_L"].NextValue = Mark_Tar1.Score; IOs.Add(VisionValues["Score_Target_L"]);
            VisionValues["Score_Target_R"].NextValue = Mark_Tar2.Score; IOs.Add(VisionValues["Score_Target_R"]);
            VisionValues["Score_Object_L"].NextValue = Mark_Obj1.Score; IOs.Add(VisionValues["Score_Object_L"]);
            VisionValues["Score_Object_R"].NextValue = Mark_Obj2.Score; IOs.Add(VisionValues["Score_Object_R"]);

            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }
        

        //protected void DrawLineLabel_L(Iva.Bplus.Interface.IPointResult Mark_Tar, Iva.Bplus.Interface.IPointResult Mark_Obj, 
        //                             double resolution, double panelangle_rad, CogColorConstants color)
        protected void DrawLineLabel_L(string model, XY Robot1_, XY Robot2_, double panelangle_rad, CogColorConstants color, bool mode=true)
        {
            XY Robot1 = new XY();
            XY Robot2 = new XY();
            if (Robot1_.Y > Robot2_.Y)
            {
                Robot1 = Robot1_;
                Robot2 = Robot2_;
            }
            else
            {
                Robot1 = Robot2_;
                Robot2 = Robot1_;
            }

            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = color;
            XYT P1 = P1_CalDataObj.GetR2V(model, Robot1);
            XY P = new XY(0, 0);
            P.X += Robot1.X - inspResult.Ly * Math.Sin(panelangle_rad);
            P.Y += Robot1.Y - inspResult.Ly * Math.Cos(panelangle_rad);
            XYT P2 = P1_CalDataObj.GetR2V(model, P);
            lineInfo.Start.X = P1.X;
            lineInfo.Start.Y = P1.Y;
            lineInfo.End.X = P2.X;
            lineInfo.End.Y = P2.Y;
            if(mode)
                P1_DisplayObj.DrawLine(lineInfo);
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (lineInfo.End + P1.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ly);
            if (mode)
                P1_DisplayObj.DrawLabel(labelInfo);            

            XYT P1_ = P1_CalDataObj.GetR2V(model, Robot2);
            XY P_ = new XY(0, 0);
            if(Robot2.X > Robot1.X)
            {
                P_.X += Robot2.X - inspResult.Lx * Math.Cos(panelangle_rad);
                P_.Y += Robot2.Y - inspResult.Lx * Math.Sin(panelangle_rad);
            }
            else
            {
                P_.X += Robot2.X + inspResult.Lx * Math.Cos(panelangle_rad);
                P_.Y += Robot2.Y + inspResult.Lx * Math.Sin(panelangle_rad);
            }
            
            XYT P2_ = P1_CalDataObj.GetR2V(model, P_);
            lineInfo.Start.X = P1_.X;
            lineInfo.Start.Y = P1_.Y;
            lineInfo.End.X = P2_.X;
            lineInfo.End.Y = P2_.Y;
            if (mode)
                P1_DisplayObj.DrawLine(lineInfo);
            labelInfo.Offset = (lineInfo.End + P1_.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Lx);
            if (mode)
                P1_DisplayObj.DrawLabel(labelInfo);

            if (!mode)
            {
                lineInfo.Start.X = P1.X;
                lineInfo.Start.Y = P1.Y;
                lineInfo.End.X = P1_.X;
                lineInfo.End.Y = P1_.Y;
                P1_DisplayObj.DrawLine(lineInfo);

                labelInfo.Offset = (lineInfo.End + lineInfo.Start) / 2;
                labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                var dist = Math.Sqrt(Math.Pow(inspResult.Lx,2) + Math.Pow(inspResult.Ly, 2));
                labelInfo.Text = string.Format("{0:f4}mm", dist);
                P1_DisplayObj.DrawLabel(labelInfo);
            }
        }

        protected void DrawLineLabel_R(string model, XY Robot1_, XY Robot2_, double panelangle_rad, CogColorConstants color, bool mode = true)
        {
            XY Robot1 = new XY();
            XY Robot2 = new XY();
            if (Robot1_.Y > Robot2_.Y)
            {
                Robot1 = Robot1_;
                Robot2 = Robot2_;
            }
            else
            {
                Robot1 = Robot2_;
                Robot2 = Robot1_;
            }

            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = color;
            XYT P1 = P2_CalDataObj.GetR2V(model, Robot1);
            XY P = new XY(0, 0);
            P.X += Robot1.X - inspResult.Ry * Math.Sin(panelangle_rad);
            P.Y += Robot1.Y - inspResult.Ry * Math.Cos(panelangle_rad);
            XYT P2 = P2_CalDataObj.GetR2V(model, P);
            lineInfo.Start.X = P1.X;
            lineInfo.Start.Y = P1.Y;
            lineInfo.End.X = P2.X;
            lineInfo.End.Y = P2.Y;
            if (mode)
                P2_DisplayObj.DrawLine(lineInfo);
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (lineInfo.End + P1.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ry);
            if (mode)
                P2_DisplayObj.DrawLabel(labelInfo);

            XYT P1_ = P2_CalDataObj.GetR2V(model, Robot2);
            XY P_ = new XY(0, 0);
            if (Robot2.X > Robot1.X)
            {
                P_.X += Robot2.X - inspResult.Rx * Math.Cos(panelangle_rad);
                P_.Y += Robot2.Y - inspResult.Rx * Math.Sin(panelangle_rad);
            }
            else
            {
                P_.X += Robot2.X + inspResult.Rx * Math.Cos(panelangle_rad);
                P_.Y += Robot2.Y + inspResult.Rx * Math.Sin(panelangle_rad);
            }
            XYT P2_ = P2_CalDataObj.GetR2V(model, P_);
            lineInfo.Start.X = P1_.X;
            lineInfo.Start.Y = P1_.Y;
            lineInfo.End.X = P2_.X;
            lineInfo.End.Y = P2_.Y;
            if (mode)
                P2_DisplayObj.DrawLine(lineInfo);
            labelInfo.Offset = (lineInfo.End + P1_.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Rx);
            if (mode)
                P2_DisplayObj.DrawLabel(labelInfo);

            if (!mode)
            {
                lineInfo.Start.X = P1.X;
                lineInfo.Start.Y = P1.Y;
                lineInfo.End.X = P1_.X;
                lineInfo.End.Y = P1_.Y;
                P2_DisplayObj.DrawLine(lineInfo);

                labelInfo.Offset = (lineInfo.End + lineInfo.Start) / 2;
                labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
                var dist = Math.Sqrt(Math.Pow(inspResult.Rx, 2) + Math.Pow(inspResult.Ry, 2));
                labelInfo.Text = string.Format("{0:f4}mm", dist);
                P2_DisplayObj.DrawLabel(labelInfo);
            }
        }
		
		public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            Task task = Task.Factory.StartNew(() =>
            cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true
            ));
		}

        void DrawErrDisp( string errStr)
        {
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = errColor;
            labelInfo.Offset = errOffset;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format(errStr);
            P1_DisplayObj.DrawLabel(labelInfo);
            P2_DisplayObj.DrawLabel(labelInfo);
        }
        #endregion


    }
}

