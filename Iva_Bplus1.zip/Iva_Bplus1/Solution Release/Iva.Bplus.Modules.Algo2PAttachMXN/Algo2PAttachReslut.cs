﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAttachMXN
{
    [SerializableAttribute]
    public class Algo2PAttachMXNResult : AlgoResultBase
    {
        #region [fiedls]
        private double lx;
        private double ly;
        private double rx;
        private double ry;

        private double revX;
        private double revY;
        private double revT;

        private double offset1X;
        private double offset1Y;
        private double offset1T;

        private double offset2X;
        private double offset2Y;
        private double offset2T;

        private double length_tar;
        private double length_obj;
        private bool result;

        private double plcOffset_Lx;
        private double plcOffset_Ly;
        private double plcOffset_Rx;
        private double plcOffset_Ry;

        private double mark_Panel_L_X;
        private double mark_Panel_L_Y;
        private double mark_Panel_R_X;
        private double mark_Panel_R_Y;

        private double mark_notPanel_L_X;
        private double mark_notPanel_L_Y;
        private double mark_notPanel_R_X;
        private double mark_notPanel_R_Y;

        private double robot_Panel_L_X;
        private double robot_Panel_L_Y;
        private double robot_Panel_R_X;
        private double robot_Panel_R_Y;

        private double robot_notPanel_L_X;
        private double robot_notPanel_L_Y;
        private double robot_notPanel_R_X;
        private double robot_notPanel_R_Y;

        //두점간의 거리  L, R
        private string distance;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double Lx
        {
            get { return lx; }
            set { if (value == lx) return; lx = value; OnPropertyChanged(nameof(Lx)); }
        }
        public double Ly
        {
            get { return ly; }
            set { if (value == ly) return; ly = value; OnPropertyChanged(nameof(Ly)); }
        }
        public double Rx
        {
            get { return rx; }
            set { if (value == rx) return; rx = value; OnPropertyChanged(nameof(Rx)); }
        }
        public double Ry
        {
            get { return ry; }
            set { if (value == ry) return; ry = value; OnPropertyChanged(nameof(Ry)); }
        }

        public double RevX
        {
            get { return revX; }
            set { if (value == revX) return; revX = value; OnPropertyChanged(nameof(RevX)); }
        }
        public double RevY
        {
            get { return revY; }
            set { if (value == revY) return; revY = value; OnPropertyChanged(nameof(RevY)); }
        }
        public double RevT
        {
            get { return revT; }
            set { if (value == revT) return; revT = value; OnPropertyChanged(nameof(RevT)); }
        }

        public double Offset1X
        {
            get { return offset1X; }
            set { if (value == offset1X) return; offset1X = value; OnPropertyChanged(nameof(Offset1X)); }
        }
        public double Offset1Y
        {
            get { return offset1Y; }
            set { if (value == offset1Y) return; offset1Y = value; OnPropertyChanged(nameof(Offset1Y)); }
        }
        public double Offset1T
        {
            get { return offset1T; }
            set { if (value == offset1T) return; offset1T = value; OnPropertyChanged(nameof(Offset1T)); }
        }

        public double Offset2X
        {
            get { return offset2X; }
            set { if (value == offset2X) return; offset2X = value; OnPropertyChanged(nameof(Offset2X)); }
        }
        public double Offset2Y
        {
            get { return offset2Y; }
            set { if (value == offset2Y) return; offset2Y = value; OnPropertyChanged(nameof(Offset2Y)); }
        }
        public double Offset2T
        {
            get { return offset2T; }
            set { if (value == offset2T) return; offset2T = value; OnPropertyChanged(nameof(Offset2T)); }
        }
        public double Length_tar
        {
            get { return length_tar; }
            set { if (value == length_tar) return; length_tar = value; OnPropertyChanged(nameof(Length_tar)); }
        }
        public double Length_obj
        {
            get { return length_obj; }
            set { if (value == length_obj) return; length_obj = value; OnPropertyChanged(nameof(Length_obj)); }
        }

        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        
		public double PlcOffset_Lx
        {
            get { return plcOffset_Lx; }
            set { if (value == plcOffset_Lx) return; plcOffset_Lx = value; OnPropertyChanged(nameof(PlcOffset_Lx)); }
        }
        public double PlcOffset_Ly
        {
            get { return plcOffset_Ly; }
            set { if (value == plcOffset_Ly) return; plcOffset_Ly = value; OnPropertyChanged(nameof(PlcOffset_Ly)); }
        }
        public double PlcOffset_Rx
        {
            get { return plcOffset_Rx; }
            set { if (value == plcOffset_Rx) return; plcOffset_Rx = value; OnPropertyChanged(nameof(PlcOffset_Rx)); }
        }
        public double PlcOffset_Ry
        {
            get { return plcOffset_Ry; }
            set { if (value == plcOffset_Ry) return; plcOffset_Ry = value; OnPropertyChanged(nameof(PlcOffset_Ry)); }
        }

        public double Mark_Panel_L_X
        {
            get { return mark_Panel_L_X; }
            set { if (value == mark_Panel_L_X) return; mark_Panel_L_X = value; OnPropertyChanged(nameof(Mark_Panel_L_X)); }
        }
        public double Mark_Panel_L_Y
        {
            get { return mark_Panel_L_Y; }
            set { if (value == mark_Panel_L_Y) return; mark_Panel_L_Y = value; OnPropertyChanged(nameof(Mark_Panel_L_Y)); }
        }
        public double Mark_Panel_R_X
        {
            get { return mark_Panel_R_X; }
            set { if (value == mark_Panel_R_X) return; mark_Panel_R_X = value; OnPropertyChanged(nameof(Mark_Panel_R_X)); }
        }
        public double Mark_Panel_R_Y
        {
            get { return mark_Panel_R_Y; }
            set { if (value == mark_Panel_R_Y) return; mark_Panel_R_Y = value; OnPropertyChanged(nameof(Mark_Panel_L_X)); }
        }

        public double Mark_notPanel_L_X
        {
            get { return mark_notPanel_L_X; }
            set { if (value == mark_notPanel_L_X) return; mark_notPanel_L_X = value; OnPropertyChanged(nameof(Mark_notPanel_L_X)); }
        }
        public double Mark_notPanel_L_Y
        {
            get { return mark_notPanel_L_Y; }
            set { if (value == mark_notPanel_L_Y) return; mark_notPanel_L_Y = value; OnPropertyChanged(nameof(Mark_notPanel_L_Y)); }
        }
        public double Mark_notPanel_R_X
        {
            get { return mark_notPanel_R_X; }
            set { if (value == mark_notPanel_R_X) return; mark_notPanel_R_X = value; OnPropertyChanged(nameof(Mark_notPanel_R_X)); }
        }
        public double Mark_notPanel_R_Y
        {
            get { return mark_notPanel_R_Y; }
            set { if (value == mark_notPanel_R_Y) return; mark_notPanel_R_Y = value; OnPropertyChanged(nameof(Mark_notPanel_L_X)); }
        }

        public double Robot_Panel_L_X
        {
            get { return robot_Panel_L_X; }
            set { if (value == robot_Panel_L_X) return; robot_Panel_L_X = value; OnPropertyChanged(nameof(Robot_Panel_L_X)); }
        }
        public double Robot_Panel_L_Y
        {
            get { return robot_Panel_L_Y; }
            set { if (value == robot_Panel_L_Y) return; robot_Panel_L_Y = value; OnPropertyChanged(nameof(Robot_Panel_L_Y)); }
        }
        public double Robot_Panel_R_X
        {
            get { return robot_Panel_R_X; }
            set { if (value == robot_Panel_R_X) return; robot_Panel_R_X = value; OnPropertyChanged(nameof(Robot_Panel_R_X)); }
        }
        public double Robot_Panel_R_Y
        {
            get { return robot_Panel_R_Y; }
            set { if (value == robot_Panel_R_Y) return; robot_Panel_R_Y = value; OnPropertyChanged(nameof(Robot_Panel_L_X)); }
        }

        public double Robot_notPanel_L_X
        {
            get { return robot_notPanel_L_X; }
            set { if (value == robot_notPanel_L_X) return; robot_notPanel_L_X = value; OnPropertyChanged(nameof(Robot_notPanel_L_X)); }
        }
        public double Robot_notPanel_L_Y
        {
            get { return robot_notPanel_L_Y; }
            set { if (value == robot_notPanel_L_Y) return; robot_notPanel_L_Y = value; OnPropertyChanged(nameof(Robot_notPanel_L_Y)); }
        }
        public double Robot_notPanel_R_X
        {
            get { return robot_notPanel_R_X; }
            set { if (value == robot_notPanel_R_X) return; robot_notPanel_R_X = value; OnPropertyChanged(nameof(Robot_notPanel_R_X)); }
        }
        public double Robot_notPanel_R_Y
        {
            get { return robot_notPanel_R_Y; }
            set { if (value == robot_notPanel_R_Y) return; robot_notPanel_R_Y = value; OnPropertyChanged(nameof(Robot_notPanel_L_X)); }
        }

        //두점간의 거리  L, R
        public string Distance
        {
            get { return distance; }
            set { if (value == distance) return; distance = value; OnPropertyChanged(nameof(Distance)); }
        }
        #endregion


        public Algo2PAttachMXNResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "offset1X: {3},\noffset1Y: {4},\noffset1T: {5},\n" +
                                  "offset2X: {6},\noffset2Y: {7},\noffset2T: {8},\n" +
                                  "LengthTarget: {9},\nResult: {10},\n" +
                                  "Mark_Panel_L_X: {11},\nMark_Panel_L_Y: {12},\nMark_Panel_R_X: {13},\nMark_Panel_R_Y: {14},\n" +
                                  "Mark_notPanel_L_X: {15},\nMark_notPanel_L_Y: {16},\nMark_notPanel_R_X: {17},\nMark_notPanel_R_Y: {18},\n"
                                  , typeof(Algo2PAttachMXNResult).ToString(), curTime, curDate
                                  , offset1X, offset1Y, offset1T
                                  , offset2X, offset2Y, offset2T
                                  , length_tar, result
                                  , mark_Panel_L_X, mark_Panel_L_Y, mark_Panel_R_X, mark_Panel_R_Y
                                  , mark_notPanel_L_X, mark_notPanel_L_Y, mark_notPanel_R_X, mark_notPanel_R_Y
                                  );
            //return "";
        }

    }
}
