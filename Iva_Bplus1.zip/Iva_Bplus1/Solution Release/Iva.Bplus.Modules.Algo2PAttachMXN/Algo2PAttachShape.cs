﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using Iva.Bplus.Views;
using SvMip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace Iva.Bplus.Modules.Algo2PAttachMXN
{
    [SerializableAttribute]
    public partial class Algo2PAttachMXNShape : ModuleBase
    {
        #region [Construct]
        public Algo2PAttachMXNShape()
            : base()
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;
        }

        public Algo2PAttachMXNShape(SystemCanvasViewModel parent, string name)
            : base(parent, name)
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;

            base.InitItem(null, name, SettingShapeType.Algo);

            var action = base.modAction as SystemActionBase;
            base.SetConnectors(action.InputParams, action.OutputParams);
        }
        #endregion

        #region [override method]
        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string _source)
        {
            base.parent = parent;
            base.InitItem(obj, _source, SettingShapeType.Algo);
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion
    }
}
