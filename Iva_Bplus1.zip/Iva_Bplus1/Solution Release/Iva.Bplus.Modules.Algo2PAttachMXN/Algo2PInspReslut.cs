﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAttachMXN
{
    [SerializableAttribute]
    public class Algo2PAttachMXNInspResult : AlgoResultBase
    {
        #region [fiedls]
        private double lx;
        private double ly;
        private double rx;
        private double ry;

        private double length_tar;
        private double length_obj;
        private bool result;

        private double p1_X;
        private double p1_Y;
        private double p2_X;
        private double p2_Y;

        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double Lx
        {
            get { return lx; }
            set { if (value == lx) return; lx = value; OnPropertyChanged(nameof(Lx)); }
        }
        public double Ly
        {
            get { return ly; }
            set { if (value == ly) return; ly = value; OnPropertyChanged(nameof(Ly)); }
        }
        public double Rx
        {
            get { return rx; }
            set { if (value == rx) return; rx = value; OnPropertyChanged(nameof(Rx)); }
        }
        public double Ry
        {
            get { return ry; }
            set { if (value == ry) return; ry = value; OnPropertyChanged(nameof(Ry)); }
        }
    
        public double Length_tar
        {
            get { return length_tar; }
            set { if (value == length_tar) return; length_tar = value; OnPropertyChanged(nameof(Length_tar)); }
        }
        public double Length_obj
        {
            get { return length_obj; }
            set { if (value == length_obj) return; length_obj = value; OnPropertyChanged(nameof(Length_obj)); }
        }

        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }
        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }
        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }
        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }
        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }
        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }
        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }
        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }
        #endregion


        public Algo2PAttachMXNInspResult() : base() { }

        public override string ToString()
        {
            //return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
            //                      "offset1X: {3},\noffset1Y: {4},\noffset1T: {5},\n" +
            //                      "offset2X: {6},\noffset2Y: {7},\noffset2T: {8},\n" +
            //                      "Length: {9},\nResult: {10},\n" +
            //                      "P1_X: {11},\nP1_Y: {12},\nP2_X: {13},\nP2_Y: {14},\n" +
            //                      "C1_X: {15},\nC1_Y: {16},\nC2_X: {17},\nC2_Y: {18},\n"
            //                      , typeof(Algo2PInspAlignResult).ToString(), curTime, curDate
            //                      , offset1X, offset1Y, offset1T
            //                      , offset2X, offset2Y, offset2T
            //                      , length, result
            //                      , p1_X, p1_Y, p2_X, p2_Y
            //                      , c1_X, c1_Y, c2_X, c2_Y
            //                      );
            return "";
        }

    }
}
