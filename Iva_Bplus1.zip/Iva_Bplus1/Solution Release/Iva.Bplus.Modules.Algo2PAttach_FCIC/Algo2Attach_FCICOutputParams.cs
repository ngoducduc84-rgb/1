﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo2PAttach_FCIC
{
    class Algo2PAttachFCICOutputParams : OutputParams
    {
        #region Logging
        public object Result { get; set; }
        #endregion
    }
}
