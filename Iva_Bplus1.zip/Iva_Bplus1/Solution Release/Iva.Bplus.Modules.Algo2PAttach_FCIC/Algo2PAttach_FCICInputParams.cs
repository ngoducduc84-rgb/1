﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;
using System;

namespace Iva.Bplus.Modules.Algo2PAttach_FCIC
{
    [SerializableAttribute]
    class Algo2PAttach_FCICInputParams : InputParams
    {
        #region Input
        public IPointResult Obj_P1 { get; set; }
        public IPointResult Tar_P1 { get; set; }
        public IPointResult Obj_P2 { get; set; }
        public IPointResult Tar_P2 { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
