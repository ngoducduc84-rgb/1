﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo2PAttach_FCIC
{
    [SerializableAttribute]
    public partial class Algo2PAttach_FCICObject : AlgoObjectBase
    {
        #region [Fields]
        Algo2PAttachFCICAlignModelParams mParams;
        #region  Selected Caldata Name
        private string t_Left_CalData;
        private string t_Right_CalData;
        private string o_Left_CalData;
        private string o_Right_CalData;
        private string t_Left_Display;
        private string t_Right_Display;
        private string o_Left_Display;
        private string o_Right_Display;
        #endregion

        #region etc
        private CalcType calcType = CalcType.Inspection;
        private ThetaDirection thetaDirection = ThetaDirection.Normal;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        //private Direction x1Direction = Direction.Reverse;
        //private Direction x2Direction = Direction.Normal;
        //private Direction y1Direction = Direction.Normal;
        //private Direction y2Direction = Direction.Normal;
        private OffsetType offsetType = OffsetType.XYXY;
        private InspManualCheck inspManualCheck = InspManualCheck.Unuse;
        #endregion

        #region Align결과 관련
        XYT revAlign = new XYT();
        XYT revUnload = new XYT();
        double length_obj = 0.0;
        double length_tar = 0.0;
        XYXY inspResult = new XYXY();
        bool lastJudge = true;
        #endregion

        #region Coordinate 관련
        XY Robot_Tar1 = new XY();
        XY Robot_Tar2 = new XY();
        XY Robot_Obj1 = new XY();
        XY Robot_Obj2 = new XY();
        XY Coord_Tar1 = new XY();
        XY Coord_Tar2 = new XY();
        XY Coord_Obj1 = new XY();
        XY Coord_Obj2 = new XY();
        XY Mark_Tar1_XY = new XY();
        XY Mark_Tar2_XY = new XY();
        XY Mark_Obj1_XY = new XY();
        XY Mark_Obj2_XY = new XY();

        XY Mark_Panel1 = new XY();
        XY Mark_Panel2 = new XY();
        XY Mark_notPanel1 = new XY();
        XY Mark_notPanel2 = new XY();
        XY Robot_notPanel1 = new XY();
        XY Robot_notPanel2 = new XY();
        XY Robot_Panel1 = new XY();
        XY Robot_Panel2 = new XY();

        XY Mark_Tar1 = new XY();
        XY Mark_Tar2 = new XY();
        XY Mark_Obj1 = new XY();
        XY Mark_Obj2 = new XY();

        XYT TarCenter = new XYT();
        double panelangle_rad = 0;
        object alignOffset;
        object Offsets;
        #endregion

        public string schName = null;
        string model = null;
        #endregion

        #region [properties]
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string T_Left_CalData
        {
            get { return t_Left_CalData; }
            set { if (t_Left_CalData == value) return; t_Left_CalData = value; this.OnPropertyChanged(nameof(T_Left_CalData)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string T_Right_CalData
        {
            get { return t_Right_CalData; }
            set { if (t_Right_CalData == value) return; t_Right_CalData = value; this.OnPropertyChanged(nameof(T_Right_CalData)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string O_Left_CalData
        {
            get { return o_Left_CalData; }
            set { if (o_Left_CalData == value) return; o_Left_CalData = value; this.OnPropertyChanged(nameof(O_Left_CalData)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string O_Right_CalData
        {
            get { return o_Right_CalData; }
            set { if (o_Right_CalData == value) return; o_Right_CalData = value; this.OnPropertyChanged(nameof(O_Right_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string T_Left_Display
        {
            get { return t_Left_Display; }
            set { if (t_Left_Display == value) return; t_Left_Display = value; this.OnPropertyChanged(nameof(T_Left_Display)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string T_Right_Display
        {
            get { return t_Right_Display; }
            set { if (t_Right_Display == value) return; t_Right_Display = value; this.OnPropertyChanged(nameof(T_Right_Display)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string O_Left_Display
        {
            get { return o_Left_Display; }
            set { if (o_Left_Display == value) return; o_Left_Display = value; this.OnPropertyChanged(nameof(O_Left_Display)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string O_Right_Display
        {
            get { return o_Right_Display; }
            set { if (o_Right_Display == value) return; o_Right_Display = value; this.OnPropertyChanged(nameof(O_Right_Display)); }
        }

        public CalDataObject T_Left_CalDataObj
        {
            get { return SystemObject_Common.GetObject(t_Left_CalData) as CalDataObject; }
        }
        public CalDataObject T_Right_CalDataObj
        {
            get { return SystemObject_Common.GetObject(t_Right_CalData) as CalDataObject; }
        }
        public CalDataObject O_Left_CalDataObj
        {
            get { return SystemObject_Common.GetObject(o_Left_CalData) as CalDataObject; }
        }
        public CalDataObject O_Right_CalDataObj
        {
            get { return SystemObject_Common.GetObject(o_Right_CalData) as CalDataObject; }
        }

        public CogDisplayObject T_Left_DisplayObj
        {
            get { return SystemObject_Display.GetObject(t_Left_Display) as CogDisplayObject; }
        }
        public CogDisplayObject T_Right_DisplayObj
        {
            get { return SystemObject_Display.GetObject(t_Right_Display) as CogDisplayObject; }
        }
        public CogDisplayObject O_Left_DisplayObj
        {
            get { return SystemObject_Display.GetObject(o_Left_Display) as CogDisplayObject; }
        }
        public CogDisplayObject O_Right_DisplayObj
        {
            get { return SystemObject_Display.GetObject(o_Right_Display) as CogDisplayObject; }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }
        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }

        //public Direction X1Direction
        //{
        //    get { return x1Direction; }
        //    set { if (x1Direction == value) return; x1Direction = value; this.OnPropertyChanged(nameof(X1Direction)); }
        //}
        //public Direction X2Direction
        //{
        //    get { return x2Direction; }
        //    set { if (x2Direction == value) return; x2Direction = value; this.OnPropertyChanged(nameof(X2Direction)); }
        //}
        //public Direction Y1Direction
        //{
        //    get { return y1Direction; }
        //    set { if (y1Direction == value) return; y1Direction = value; this.OnPropertyChanged(nameof(Y1Direction)); }
        //}
        //public Direction Y2Direction
        //{
        //    get { return y2Direction; }
        //    set { if (y2Direction == value) return; y2Direction = value; this.OnPropertyChanged(nameof(Y2Direction)); }
        //}
        public OffsetType OffsetType
        {
            get { return offsetType; }
            set { if (offsetType == value) return; offsetType = value; this.OnPropertyChanged(nameof(OffsetType)); }
        }
        public InspManualCheck InspManualCheck
        {
            get { return inspManualCheck; }
            set { if (inspManualCheck == value) return; inspManualCheck = value; this.OnPropertyChanged(nameof(InspManualCheck)); }
        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        public double Length_obj { get { return length_obj; } }
        public double Length_tar { get { return length_tar; } }
        public XYXY InspResult { get { return inspResult; } }

        #endregion
        #endregion

        #region[Construct]
        public Algo2PAttach_FCICObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo2PAttachFCICAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            if (calcType == CalcType.Align)
                return AlignCalc();
            else
                return InspectionCalc();
        }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool AlignCalc()
        {
            model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudge = true;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            mParams = modelParams as Algo2PAttachFCICAlignModelParams;
            double limitX = (double)mParams.LimitX.Value;
            double limitY = (double)mParams.LimitY.Value;
            double limitT = (double)mParams.LimitT.Value;

            double sensorsizeW = (double)mParams.SensorSize_W.Value;
            double pixelcountW = (double)mParams.Pixel_Count_W.Value;
            double lensMag = (double)mParams.Lens_Mag.Value;
            double panelmarkdistance = (double)mParams.PanelMarkDistance.Value;
            double scale_Lx = (double)mParams.Scale_Lx.Value;
            double scale_Ly = (double)mParams.Scale_Ly.Value;
            double scale_Rx = (double)mParams.Scale_Rx.Value;
            double scale_Ry = (double)mParams.Scale_Ry.Value;
            double spec_Lx = (double)mParams.Spec_Lx.Value;
            double spec_Ly = (double)mParams.Spec_Ly.Value;
            double spec_Rx = (double)mParams.Spec_Rx.Value;
            double spec_Ry = (double)mParams.Spec_Ry.Value;
            double tor_Lx = (double)mParams.Tor_Lx.Value;
            double tor_Ly = (double)mParams.Tor_Ly.Value;
            double tor_Rx = (double)mParams.Tor_Rx.Value;
            double tor_Ry = (double)mParams.Tor_Ry.Value;

            double spec_Length_Target = (double)mParams.Spec_Length_Target.Value;
            double tor_Length_Target = (double)mParams.Tor_Length_Target.Value;
            double spec_Length_Object = (double)mParams.Spec_Length_Object.Value;
            double tor_Length_Object = (double)mParams.Tor_Length_Object.Value;
            double scale_Length = (double)mParams.Scale_Length.Value;
            XYT Limit = new XYT(limitX, limitY, limitT);
            XYXY Scale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
            XYXY Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
            XYXY Tor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);

            //bool isPanelMove = (bool)mParams.IsPanelMove.Value;
            //double resolution = GetResolution(sensorsizeW, pixelcountW, lensMag);
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2") || !InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            var Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
            var Mark_Tar2 = InputValues["Tar_P2"] as IPointResult;
            var Mark_Obj1 = InputValues["Obj_P1"] as IPointResult;
            var Mark_Obj2 = InputValues["Obj_P2"] as IPointResult;
            if (Mark_Tar1 == null || Mark_Tar2 == null || Mark_Obj1 == null || Mark_Obj2 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            Mark_Tar1_XY = Mark_Tar1.OutputXYT.ToXY();
            Mark_Tar2_XY = Mark_Tar2.OutputXYT.ToXY();
            Mark_Obj1_XY = Mark_Obj1.OutputXYT.ToXY();
            Mark_Obj2_XY = Mark_Obj2.OutputXYT.ToXY();
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (T_Left_CalDataObj == null || T_Right_CalDataObj == null) //CalData는 2개, 카메라 왼쪽, 오른쪽
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                // Calibration 설정 안됨.
                return false;
            }
            Robot_Tar1 = T_Left_CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));   //PNL(T)
            Robot_Tar2 = T_Right_CalDataObj.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y));   //PNL(T)

            Robot_Obj1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));   //Film(O)
            Robot_Obj2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));   //Film(O)

            XY T_Left_RotCent = T_Left_CalDataObj.GetRotateCenter(model);
            XY T_Right_RotCent = T_Right_CalDataObj.GetRotateCenter(model);
            XY O_Left_RotCent = O_Left_CalDataObj.GetRotateCenter(model);
            XY O_Right_RotCent = O_Right_CalDataObj.GetRotateCenter(model);

            Coord_Tar1 = Robot_Tar1 + T_Left_RotCent;
            Coord_Tar2 = Robot_Tar2 + T_Right_RotCent;
            Coord_Obj1 = Robot_Obj1 + O_Left_RotCent;
            Coord_Obj2 = Robot_Obj2 + O_Right_RotCent;
            #endregion

            #region Calc Rev Offset
            #region Offset 적용
            Offsets = null;
            alignOffset = null;
            if (OffsetType == OffsetType.XYT)
            {
                Offsets = CvtPLCIO.OffsetXYT;  //Log찍게
                alignOffset = CvtPLCIO.OffsetXYT;

                double Theta = GetTheta(Coord_Tar1, Coord_Tar2);
                Theta = NormalizeTheta(Theta);
                
                //Spec.Lx = X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                //Spec.Ly = Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                //Spec.Rx = X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                //Spec.Ry = Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                XY Coord_Tar1_Temp = new XY();
                XY Coord_Tar2_Temp = new XY();

                Coord_Tar1_Temp.X = Coord_Tar1.X + Math.Cos(Theta) * Spec.Lx - Math.Sin(Theta) * Spec.Ly;
                Coord_Tar1_Temp.Y = Coord_Tar1.Y + Math.Sin(Theta) * Spec.Lx + Math.Cos(Theta) * Spec.Ly;
                Coord_Tar2_Temp.X = Coord_Tar2.X + Math.Cos(Theta) * Spec.Rx - Math.Sin(Theta) * Spec.Ry;
                Coord_Tar2_Temp.Y = Coord_Tar2.Y + Math.Sin(Theta) * Spec.Rx + Math.Cos(Theta) * Spec.Ry;

                (alignOffset as XYT).X /= scale_Lx;
                (alignOffset as XYT).Y /= scale_Ly;
                (alignOffset as XYT).T /= scale_Rx;

                TarCenter = ApplyTargetOffset(Coord_Tar1_Temp, Coord_Tar2_Temp, alignOffset);
            }
            else
            {
                // 기존 PLC Offset값 저장.
                Offsets = CvtPLCIO.OffsetXYXY;  //Log찍게
                alignOffset = CvtPLCIO.OffsetXYXY;

                //Distance Spec 누적
                //(alignOffset as XYXY).Lx += X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                //(alignOffset as XYXY).Ly += Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                //(alignOffset as XYXY).Rx += X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                //(alignOffset as XYXY).Ry += Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                //Scale적용
                (alignOffset as XYXY).Lx /= scale_Lx;
                (alignOffset as XYXY).Ly /= scale_Ly;
                (alignOffset as XYXY).Rx /= scale_Rx;
                (alignOffset as XYXY).Ry /= scale_Ry;

                TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);
            }
            #endregion

            revAlign = new XYT();
            double radT, DriftX, DriftY;

            // Attach 위치 보정값 계산.             
            XY ObjXY = (Coord_Obj1 + Coord_Obj2) / 2;
            double T = GetTheta(Coord_Obj1, Coord_Obj2);
            T = NormalizeTheta(T);
            XYT ObjCenter = new XYT(ObjXY.X, ObjXY.Y, T);

            radT = TarCenter.T - ObjCenter.T;

            DriftX = Math.Cos(radT) * ObjCenter.X - Math.Sin(radT) * ObjCenter.Y;
            DriftY = Math.Sin(radT) * ObjCenter.X + Math.Cos(radT) * ObjCenter.Y;

            revAlign.X = TarCenter.X - DriftX;
            revAlign.Y = TarCenter.Y - DriftY;
            if (ThetaDirection == ThetaDirection.Normal)    //정방향
                revAlign.T = radT / rad;
            else //역방향
                revAlign.T = (radT / rad) * -1;
            #endregion

            #region Cal Inspection
            InspectionCalc_(); // Align을 pixel CalData로 할 리가 없다.
            T_Left_DisplayObj.Judgement = (uint)Judgement.InspOK;
            T_Right_DisplayObj.Judgement = (uint)Judgement.InspOK;
            #endregion

            #region Confirm Result (Align Spec Over Check)
            if (!ConfirmResult(revAlign, Limit))
            {
                T_Left_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                T_Right_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                lastJudge = false;
            }
            #endregion

            #region Calc Length
            length_tar = GetLength(Coord_Tar1, Coord_Tar2);
            length_obj = GetLength(Coord_Obj1, Coord_Obj2);
            if (!ConfirmLength(length_tar, spec_Length_Target, tor_Length_Target) || !ConfirmLength(length_obj, spec_Length_Object, tor_Length_Object))
            {
                T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
              
                lastJudge = false;
            }
            #endregion

            #region DrawOverlay & ImageSave
            //Task.Factory.StartNew(() => DrawLineLabel_L(model, Mark_Tar1, Mark_Obj1));
            //Task.Factory.StartNew(() => DrawLineLabel_R(model, Mark_Tar2, Mark_Obj2));
            #endregion            

            #region Result Data Update(DataGridView Insert)
            if (OffsetType == OffsetType.XYT)
            {
                AlgoRst = new Algo2PAttachFCICResult
                {
                    Name = name,
                    ID = sourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    Lx = Math.Round(inspResult.Lx, 3),
                    Ly = Math.Round(inspResult.Ly, 3),
                    Rx = Math.Round(inspResult.Rx, 3),
                    Ry = Math.Round(inspResult.Ry, 3),

                    Offset1X = Math.Round(revAlign.X, 3),
                    Offset1Y = Math.Round(revAlign.Y, 3),
                    Offset1T = Math.Round(revAlign.T, 3),

                    Length_tar = Math.Round(length_tar, 3),
                    Length_obj = Math.Round(length_obj, 3),
                    Result = lastJudge,

                    //Panel Mark pixel
                    P1_X = Math.Round(Mark_Tar1.OutputXYT.X, 3),
                    P1_Y = Math.Round(Mark_Tar1.OutputXYT.Y, 3),
                    P2_X = Math.Round(Mark_Tar2.OutputXYT.X, 3),
                    P2_Y = Math.Round(Mark_Tar2.OutputXYT.Y, 3),

                    //Tape Mark pixel
                    T1_X = Math.Round(Mark_Obj1.OutputXYT.X, 3),
                    T1_Y = Math.Round(Mark_Obj1.OutputXYT.Y, 3),
                    T2_X = Math.Round(Mark_Obj2.OutputXYT.X, 3),
                    T2_Y = Math.Round(Mark_Obj2.OutputXYT.Y, 3),

                    //Robot Panel 좌표
                    CP1_X = Math.Round(Coord_Tar1.X, 3),
                    CP1_Y = Math.Round(Coord_Tar1.Y, 3),
                    CP2_X = Math.Round(Coord_Tar2.X, 3),
                    CP2_Y = Math.Round(Coord_Tar2.Y, 3),

                    //Robot Tape 좌표
                    CT1_X = Math.Round(Coord_Obj1.X, 3),
                    CT1_Y = Math.Round(Coord_Obj1.Y, 3),
                    CT2_X = Math.Round(Coord_Obj2.X, 3),
                    CT2_Y = Math.Round(Coord_Obj2.Y, 3),

                    PlcOffset_Lx = Math.Round((Offsets as XYT).X, 3),
                    PlcOffset_Ly = Math.Round((Offsets as XYT).Y, 3),
                    PlcOffset_Rx = Math.Round((Offsets as XYT).T, 3),

                    Score_P1_Tar = Math.Round(Mark_Tar1.Score, 2),
                    Score_P2_Tar = Math.Round(Mark_Tar2.Score, 2),

                    Score_P1_Obj = Math.Round(Mark_Obj1.Score, 2),
                    Score_P2_Obj = Math.Round(Mark_Obj2.Score, 2),
                    
                    
                    
                };
            }
            else
            {
                AlgoRst = new Algo2PAttachFCICResult
                {
                    Name = name,
                    ID = sourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    Lx = Math.Round(inspResult.Lx, 3),
                    Ly = Math.Round(inspResult.Ly, 3),
                    Rx = Math.Round(inspResult.Rx, 3),
                    Ry = Math.Round(inspResult.Ry, 3),

                    Offset1X = Math.Round(revAlign.X, 3),
                    Offset1Y = Math.Round(revAlign.Y, 3),
                    Offset1T = Math.Round(revAlign.T, 3),

                    Length_tar = Math.Round(length_tar, 3),
                    Length_obj = Math.Round(length_obj, 3),
                    Result = true,

                    //Panel Mark pixel
                    P1_X = Math.Round(Mark_Tar1.OutputXYT.X, 3),
                    P1_Y = Math.Round(Mark_Tar1.OutputXYT.Y, 3),
                    P2_X = Math.Round(Mark_Tar2.OutputXYT.X, 3),
                    P2_Y = Math.Round(Mark_Tar2.OutputXYT.Y, 3),

                    //Tape Mark pixel
                    T1_X = Math.Round(Mark_Obj1.OutputXYT.X, 3),
                    T1_Y = Math.Round(Mark_Obj1.OutputXYT.Y, 3),
                    T2_X = Math.Round(Mark_Obj2.OutputXYT.X, 3),
                    T2_Y = Math.Round(Mark_Obj2.OutputXYT.Y, 3),

                    //Robot Panel 좌표
                    CP1_X = Math.Round(Coord_Tar1.X, 3),
                    CP1_Y = Math.Round(Coord_Tar1.Y, 3),
                    CP2_X = Math.Round(Coord_Tar2.X, 3),
                    CP2_Y = Math.Round(Coord_Tar2.Y, 3),

                    //Robot Tape 좌표
                    CT1_X = Math.Round(Coord_Obj1.X, 3),
                    CT1_Y = Math.Round(Coord_Obj1.Y, 3),
                    CT2_X = Math.Round(Coord_Obj2.X, 3),
                    CT2_Y = Math.Round(Coord_Obj2.Y, 3),

                    PlcOffset_Lx = Math.Round((Offsets as XYXY).Lx, 3),
                    PlcOffset_Ly = Math.Round((Offsets as XYXY).Ly, 3),
                    PlcOffset_Rx = Math.Round((Offsets as XYXY).Rx, 3),
                    PlcOffset_Ry = Math.Round((Offsets as XYXY).Ry, 3),


                    Score_P1_Tar = Math.Round(Mark_Tar1.Score, 2),
                    Score_P2_Tar = Math.Round(Mark_Tar2.Score, 2),

                    Score_P1_Obj = Math.Round(Mark_Obj1.Score, 2),
                    Score_P2_Obj = Math.Round(Mark_Obj2.Score, 2),
                };
            }

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO(revAlign, revUnload, inspResult, "", calcType, Mark_Tar1 , Mark_Tar2, Mark_Obj1, Mark_Obj2);
            #endregion
            return lastJudge;
        }

        private bool InspectionCalc()
        {
            model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudge = true;
            //Chang_ 20200430 : Manual Check
            bool bManualCheck = false;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2") || !InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            var Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
            var Mark_Tar2 = InputValues["Tar_P2"] as IPointResult;
            var Mark_Obj1 = InputValues["Obj_P1"] as IPointResult;
            var Mark_Obj2 = InputValues["Obj_P2"] as IPointResult;
            if (Mark_Tar1 == null || Mark_Tar2 == null || Mark_Obj1 == null || Mark_Obj2 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            Mark_Tar1_XY = Mark_Tar1.OutputXYT.ToXY();
            Mark_Tar2_XY = Mark_Tar2.OutputXYT.ToXY();
            Mark_Obj1_XY = Mark_Obj1.OutputXYT.ToXY();
            Mark_Obj2_XY = Mark_Obj2.OutputXYT.ToXY();
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            mParams = modelParams as Algo2PAttachFCICAlignModelParams;
            double limitX = (double)mParams.LimitX.Value;
            double limitY = (double)mParams.LimitY.Value;
            double limitT = (double)mParams.LimitT.Value;

            double sensorsizeW = (double)mParams.SensorSize_W.Value;
            double pixelcountW = (double)mParams.Pixel_Count_W.Value;
            double lensMag = (double)mParams.Lens_Mag.Value;
            double panelmarkdistance = (double)mParams.PanelMarkDistance.Value;
            double scale_Lx = (double)mParams.Scale_Lx.Value;
            double scale_Ly = (double)mParams.Scale_Ly.Value;
            double scale_Rx = (double)mParams.Scale_Rx.Value;
            double scale_Ry = (double)mParams.Scale_Ry.Value;
            double spec_Lx = (double)mParams.Spec_Lx.Value;
            double spec_Ly = (double)mParams.Spec_Ly.Value;
            double spec_Rx = (double)mParams.Spec_Rx.Value;
            double spec_Ry = (double)mParams.Spec_Ry.Value;
            double tor_Lx = (double)mParams.Tor_Lx.Value;
            double tor_Ly = (double)mParams.Tor_Ly.Value;
            double tor_Rx = (double)mParams.Tor_Rx.Value;
            double tor_Ry = (double)mParams.Tor_Ry.Value;

            double spec_Length_Target = (double)mParams.Spec_Length_Target.Value;
            double tor_Length_Target = (double)mParams.Tor_Length_Target.Value;
            double spec_Length_Object = (double)mParams.Spec_Length_Object.Value;
            double tor_Length_Object = (double)mParams.Tor_Length_Object.Value;
            double scale_Length = (double)mParams.Scale_Length.Value;

            var score_TargetMark1Point = (double)mParams.Mark_P1_Score_Target.Value;
            var score_ObjectMark1Point = (double)mParams.Mark_P1_Score_Object.Value;
            var score_TargetMark2Point = (double)mParams.Mark_P2_Score_Target.Value;
            var score_ObjectMark2Point = (double)mParams.Mark_P2_Score_Object.Value;

            XYT Limit = new XYT(limitX, limitY, limitT);
            XYXY Scale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
            XYXY Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
            XYXY Tor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (T_Left_CalDataObj == null || T_Right_CalDataObj == null) //CalData는 2개, 카메라 왼쪽, 오른쪽
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                // Calibration 설정 안됨.
                return false;
            }

            Robot_Tar1 = T_Left_CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));   //Film(T)
            Robot_Tar2 = T_Right_CalDataObj.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y));   //Film(T)

            Robot_Obj1 = T_Left_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));   //PNL(O)
            Robot_Obj2 = T_Right_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));   //PNL(O)
            #endregion

            #region Calc Rev Offset
            //#region Offset 적용            
            //alignOffset = new XYXY();
            ////Distance Spec 누적
            ////(alignOffset as XYXY).Lx += X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
            ////(alignOffset as XYXY).Ly += Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
            ////(alignOffset as XYXY).Rx += X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
            ////(alignOffset as XYXY).Ry += Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

            //TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);
            //#endregion

            //revAlign = new XYT();
            //double radT, DriftX, DriftY;

            //// Attach 위치 보정값 계산.             
            //XY ObjXY = (Coord_Obj1 + Coord_Obj2) / 2;
            //double T = GetTheta(Coord_Obj1, Coord_Obj2);
            //T = NormalizeTheta(T);
            //XYT ObjCenter = new XYT(ObjXY.X, ObjXY.Y, T);

            //radT = TarCenter.T - ObjCenter.T;

            //DriftX = Math.Cos(radT) * ObjCenter.X - Math.Sin(radT) * ObjCenter.Y;
            //DriftY = Math.Sin(radT) * ObjCenter.X + Math.Cos(radT) * ObjCenter.Y;

            //revAlign.X = TarCenter.X - DriftX;
            //revAlign.Y = TarCenter.Y - DriftY;
            //if (ThetaDirection == ThetaDirection.Normal)    //정방향
            //    revAlign.T = radT / rad;
            //else //역방향
            //    revAlign.T = (radT / rad) * -1;
            #endregion

            #region Cal Inspection
            InspCalc(); //Theta 반영하여 Distance 거리 
            T_Left_DisplayObj.Judgement = (uint)Judgement.InspOK;
            T_Right_DisplayObj.Judgement = (uint)Judgement.InspOK;
            #endregion

            #region Confirm Result (Inspection Spec Over Check)
            //Chang_ 20200430 : Inspection Manual Check (StdScheduler의 LCheckManualMark 옵션과 함께 사용 필요)
            if (InspManualCheck.Use == inspManualCheck)
            {
                if (false == ConfirmSpecMinMax(inspResult.Lx, Math.Abs(Spec.Lx) + Tor.Lx * (-1), Math.Abs(Spec.Lx) + Tor.Lx) ||
                    false == ConfirmSpecMinMax(inspResult.Ly, Math.Abs(Spec.Ly) + Tor.Ly * (-1), Math.Abs(Spec.Ly) + Tor.Ly))
                {
                    errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                    T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    lastJudge = false;

                    Mark_Tar1.Tool.ProcMode = ProcessMode.Manual;
                    Mark_Obj1.Tool.ProcMode = ProcessMode.Manual;
                    bManualCheck = true;
                }

                if (false == ConfirmSpecMinMax(inspResult.Rx, Math.Abs(Spec.Rx) + Tor.Rx * (-1), Math.Abs(Spec.Rx) + Tor.Rx) ||
                    false == ConfirmSpecMinMax(inspResult.Ry, Math.Abs(Spec.Ry) + Tor.Ry * (-1), Math.Abs(Spec.Ry) + Tor.Ry))
                {
                    errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                    T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    lastJudge = false;

                    Mark_Tar2.Tool.ProcMode = ProcessMode.Manual;
                    Mark_Obj2.Tool.ProcMode = ProcessMode.Manual;
                    bManualCheck = true;
                }
            }
            else    //InspManualCheck.Unuse : 기존
            {
                if (!ConfirmResult2(inspResult, Spec, Tor))
                {
                    T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    lastJudge = false;
                }
            }

            #endregion

            #region Calc Length & Confirm (Length Check)
            length_tar = GetLength(Coord_Tar1, Coord_Tar2);
            length_obj = GetLength(Coord_Obj1, Coord_Obj2);
            if (!ConfirmLength(length_tar, spec_Length_Target, tor_Length_Target) || !ConfirmLength(length_obj, spec_Length_Object, tor_Length_Object))
            {
                T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                lastJudge = false;
            }

            #endregion

            #region Score 
            if (score_TargetMark1Point != 0 && Mark_Tar1.Score < score_TargetMark1Point)
            {
                T_Left_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                errorCode = AlgoActionBase.Err_Mark_Score_Check;
                lastJudge = false;
            }
            if (score_ObjectMark1Point != 0 && Mark_Obj1.Score < score_ObjectMark1Point)
            {
                O_Left_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                errorCode = AlgoActionBase.Err_Mark_Score_Check; 
                lastJudge = false;
            }
            if (score_TargetMark2Point != 0 && Mark_Tar2.Score < score_TargetMark2Point)
            {
                T_Right_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                errorCode = AlgoActionBase.Err_Mark_Score_Check;
                lastJudge = false;
            }
            if (score_ObjectMark2Point != 0 && Mark_Obj2.Score < score_ObjectMark2Point)
            {
                O_Right_DisplayObj.Judgement = (uint)Judgement.Mark_Score_Check;
                errorCode = AlgoActionBase.Err_Mark_Score_Check;
                lastJudge = false;
            }
            #endregion


            #region DrawOverlay & ImageSave
            //Chang_ 20200430 : Inspection Manual Check
            if (false == bManualCheck)
            {
                Task.Factory.StartNew(() => DrawInspResult(model, Robot_Tar1, Robot_Tar2, Robot_Obj1, Robot_Obj2));
                //Task.Factory.StartNew(() => DrawLineLabel_R(model, Mark_Tar2, Mark_Obj2));
            }
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo2PAttachFCICResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                //1Cell 물류시 사용. 
                UnitNo = CvtPLCIO.UnitNo,

                Lx = Math.Round(inspResult.Lx, 3),
                Ly = Math.Round(inspResult.Ly, 3),
                Rx = Math.Round(inspResult.Rx, 3),
                Ry = Math.Round(inspResult.Ry, 3),

                Offset1X = Math.Round(revAlign.X, 3),
                Offset1Y = Math.Round(revAlign.Y, 3),
                Offset1T = Math.Round(revAlign.T, 3),

                Length_tar = Math.Round(length_tar, 3),
                Length_obj = Math.Round(length_obj, 3),
                Result = lastJudge,

                //Panel Mark pixel
                P1_X =  Math.Round(Mark_Tar1.OutputXYT.X, 3),
                P1_Y =  Math.Round(Mark_Tar1.OutputXYT.Y, 3),
                P2_X =  Math.Round(Mark_Tar2.OutputXYT.X, 3),
                P2_Y =  Math.Round(Mark_Tar2.OutputXYT.Y, 3),

                //Tape Mark pixel
                T1_X =  Math.Round(Mark_Obj1.OutputXYT.X, 3),
                T1_Y =  Math.Round(Mark_Obj1.OutputXYT.Y, 3),
                T2_X =  Math.Round(Mark_Obj2.OutputXYT.X, 3),
                T2_Y =  Math.Round(Mark_Obj2.OutputXYT.Y, 3),

                //Robot Panel 좌표
                CP1_X = Math.Round(Coord_Tar1.X, 3),
                CP1_Y = Math.Round(Coord_Tar1.Y, 3),
                CP2_X = Math.Round(Coord_Tar2.X, 3),
                CP2_Y = Math.Round(Coord_Tar2.Y, 3),

                //Robot Tape 좌표
                CT1_X = Math.Round(Coord_Obj1.X, 3),
                CT1_Y = Math.Round(Coord_Obj1.Y, 3),
                CT2_X = Math.Round(Coord_Obj2.X, 3),
                CT2_Y = Math.Round(Coord_Obj2.Y, 3),

                Score_P1_Tar = Math.Round(Mark_Tar1.Score, 2),
                Score_P2_Tar = Math.Round(Mark_Tar2.Score, 2),

                Score_P1_Obj = Math.Round(Mark_Obj1.Score, 2),
                Score_P2_Obj = Math.Round(Mark_Obj2.Score, 2),
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO(revAlign, revUnload, inspResult, "", calcType, Mark_Tar1, Mark_Tar2, Mark_Obj1, Mark_Obj2);
            #endregion

            return lastJudge;
        }

        private void InspCalc()
        {
            var mark_Tar1 = InputValues["Tar_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Tar2 = InputValues["Tar_P2"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj1 = InputValues["Obj_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj2 = InputValues["Obj_P2"] as Iva.Bplus.Interface.IPointResult;

            Mark_Panel1 = new XY(mark_Tar1.OutputXYT.X, mark_Tar1.OutputXYT.Y);
            Mark_Panel2 = new XY(mark_Tar2.OutputXYT.X, mark_Tar2.OutputXYT.Y);
            Mark_notPanel1 = new XY(mark_Obj1.OutputXYT.X, mark_Obj1.OutputXYT.Y);
            Mark_notPanel2 = new XY(mark_Obj2.OutputXYT.X, mark_Obj2.OutputXYT.Y);

            Robot_notPanel1 = new XY();
            Robot_notPanel2 = new XY();
            Robot_Panel1 = new XY();
            Robot_Panel2 = new XY();

            var InspTeachingPos1X = CvtPLCIO.CamPosX1;
            var InspTeachingPos2X = CvtPLCIO.CamPosX2;

            Robot_notPanel1 = T_Left_CalDataObj.GetV2R(model, Mark_notPanel1, true, true);   //Film(T)
            Robot_notPanel2 = T_Right_CalDataObj.GetV2R(model, Mark_notPanel2, true, true);   //Film(T)
            Robot_Panel1 = T_Left_CalDataObj.GetV2R(model, Mark_Panel1, true, true);   //PNL(O)
            Robot_Panel2 = T_Right_CalDataObj.GetV2R(model, Mark_Panel2, true, true);   //PNL(O)

            var InspCoordTarPos1 = new XY(InspTeachingPos1X, 0) + Robot_Panel1;
            var InspCoordTarPos2 = new XY(InspTeachingPos2X, 0) + Robot_Panel2;
            var InspCoordObjPos1 = new XY(InspTeachingPos1X, 0) + Robot_notPanel1;
            var InspCoordObjPos2 = new XY(InspTeachingPos2X, 0) + Robot_notPanel2;

            double targetT = GetTheta(InspCoordTarPos1, InspCoordTarPos2);
            double objectT = GetTheta(InspCoordObjPos1, InspCoordObjPos2);

            double radT = GetTheta(InspCoordTarPos1, InspCoordTarPos2);

            revAlign.X = double.NaN;
            revAlign.Y = double.NaN;
            revAlign.T = (targetT - objectT) / rad; // Theta보정은 맞춰서 준다. Attach의 회전각을 모르기 때문에 XY보정치는 맞지않아 쓰지 않는다.

            var CoordObjPos1DriftX = Math.Cos(-radT) * InspCoordObjPos1.X - Math.Sin(-radT) * InspCoordObjPos1.X;
            var CoordObjPos1DriftY = Math.Sin(-radT) * InspCoordObjPos1.Y + Math.Cos(-radT) * InspCoordObjPos1.Y;
            var CoordObjPos2DriftX = Math.Cos(-radT) * InspCoordObjPos2.X - Math.Sin(-radT) * InspCoordObjPos2.X;
            var CoordObjPos2DriftY = Math.Sin(-radT) * InspCoordObjPos2.Y + Math.Cos(-radT) * InspCoordObjPos2.Y;

            var CoordTarPos1DriftX = Math.Cos(-radT) * InspCoordTarPos1.X - Math.Sin(-radT) * InspCoordTarPos1.X;
            var CoordTarPos1DriftY = Math.Sin(-radT) * InspCoordTarPos1.Y + Math.Cos(-radT) * InspCoordTarPos1.Y;
            var CoordTarPos2DriftX = Math.Cos(-radT) * InspCoordTarPos2.X - Math.Sin(-radT) * InspCoordTarPos2.X;
            var CoordTarPos2DriftY = Math.Sin(-radT) * InspCoordTarPos2.Y + Math.Cos(-radT) * InspCoordTarPos2.Y;


            inspResult = new XYXY();
            inspResult.Lx = Math.Abs(CoordObjPos1DriftX - CoordTarPos1DriftX);
            inspResult.Ly = Math.Abs(CoordObjPos1DriftY - CoordTarPos1DriftY);
            inspResult.Rx = Math.Abs(CoordObjPos2DriftX - CoordTarPos2DriftX);
            inspResult.Ry = Math.Abs(CoordObjPos2DriftY - CoordTarPos2DriftY);
            //inspResult.Lx = Math.Abs(Robot_notPanel1.X - Robot_Panel1.X);
            //inspResult.Ly = Math.Abs(Robot_notPanel1.Y - Robot_Panel1.Y);
            //inspResult.Rx = Math.Abs(Robot_notPanel2.X - Robot_Panel2.X);
            //inspResult.Ry = Math.Abs(Robot_notPanel2.Y - Robot_Panel2.Y);

            // Scale Apply
            inspResult.Lx *= (double)mParams.Scale_Lx.Value;
            inspResult.Ly *= (double)mParams.Scale_Ly.Value;
            inspResult.Rx *= (double)mParams.Scale_Rx.Value;
            inspResult.Ry *= (double)mParams.Scale_Ry.Value;
        }

        private void InspectionCalc_(double _panelmarkdistance = 0)
        {
            var mark_Tar1 = InputValues["Tar_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Tar2 = InputValues["Tar_P2"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj1 = InputValues["Obj_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj2 = InputValues["Obj_P2"] as Iva.Bplus.Interface.IPointResult;

            Mark_Panel1 = new XY(mark_Tar1.OutputXYT.X, mark_Tar1.OutputXYT.Y);
            Mark_Panel2 = new XY(mark_Tar2.OutputXYT.X, mark_Tar2.OutputXYT.Y);
            Mark_notPanel1 = new XY(mark_Obj1.OutputXYT.X, mark_Obj1.OutputXYT.Y);
            Mark_notPanel2 = new XY(mark_Obj2.OutputXYT.X, mark_Obj2.OutputXYT.Y);

            Robot_notPanel1 = new XY();
            Robot_notPanel2 = new XY();
            Robot_Panel1 = new XY();
            Robot_Panel2 = new XY();

            Robot_notPanel1 = T_Left_CalDataObj.GetV2R(model, Mark_notPanel1, true, true);   //Film(T)
            Robot_notPanel2 = T_Right_CalDataObj.GetV2R(model, Mark_notPanel2, true, true);   //Film(T)
            Robot_Panel1 = T_Left_CalDataObj.GetV2R(model, Mark_Panel1, true, true);   //PNL(O)
            Robot_Panel2 = T_Right_CalDataObj.GetV2R(model, Mark_Panel2, true, true);   //PNL(O)

            panelangle_rad = Math.Asin((Robot_Panel2.Y - Robot_Panel1.Y) / _panelmarkdistance);
            double camDistance = _panelmarkdistance * Math.Cos(panelangle_rad) + Robot_Panel1.X - Robot_Panel2.X;

            XY Cood_Panel2 = new XY(Robot_Panel2.X + camDistance, Robot_Panel2.Y);
            XY Cood_notPanel2 = new XY(Robot_notPanel2.X + camDistance, Robot_notPanel2.Y);

            inspResult = new XYXY();
            inspResult.Lx = GetDotDistance(Robot_notPanel1, Robot_Panel1, Cood_Panel2);
            inspResult.Ly = GetCrossDistance(Robot_notPanel1, Robot_Panel1, Cood_Panel2);
            inspResult.Rx = GetDotDistance(Cood_notPanel2, Cood_Panel2, Robot_Panel1);
            inspResult.Ry = GetCrossDistance(Cood_notPanel2, Cood_Panel2, Robot_Panel1);

            // Scale Apply
            inspResult.Lx *= (double)mParams.Scale_Lx.Value;
            inspResult.Ly *= (double)mParams.Scale_Ly.Value;
            inspResult.Rx *= (double)mParams.Scale_Rx.Value;
            inspResult.Ry *= (double)mParams.Scale_Ry.Value;
        }

        private XY GetV2R(XY xY, double resolution)
        {
            XY robot = new XY(xY.X * resolution, xY.Y * -resolution);
            return robot;
        }

        private double GetResolution(double sensorW, double pixelW, double lensMag)
        {
            double Resolution = (sensorW / pixelW) / lensMag;
            return Resolution;
        }

        protected bool ConfirmResult(XYXY revAlign, XYXY limit)
        {
            if (!ConfirmSpecMinMax(revAlign.Lx, revAlign.Lx + limit.Lx * (-1), revAlign.Lx + limit.Lx) ||
                !ConfirmSpecMinMax(revAlign.Ly, revAlign.Ly + limit.Ly * (-1), revAlign.Ly + limit.Ly) ||
                !ConfirmSpecMinMax(revAlign.Rx, revAlign.Rx + limit.Rx * (-1), revAlign.Rx + limit.Rx) ||
                !ConfirmSpecMinMax(revAlign.Ry, revAlign.Ry + limit.Ry * (-1), revAlign.Ry + limit.Ry))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }

            return true;
        }
        protected bool ConfirmResult2(XYXY rst, XYXY spec, XYXY tor)
        {
            if (!ConfirmSpecMinMax(rst.Lx, Math.Abs(spec.Lx) + tor.Lx * (-1), Math.Abs(spec.Lx) + tor.Lx) ||
                !ConfirmSpecMinMax(rst.Ly, Math.Abs(spec.Ly) + tor.Ly * (-1), Math.Abs(spec.Ly) + tor.Ly) ||
                !ConfirmSpecMinMax(rst.Rx, Math.Abs(spec.Rx) + tor.Rx * (-1), Math.Abs(spec.Rx) + tor.Rx) ||
                !ConfirmSpecMinMax(rst.Ry, Math.Abs(spec.Ry) + tor.Ry * (-1), Math.Abs(spec.Ry) + tor.Ry))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }

            return true;
        }

        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }

            return true;
        }

        protected bool ConfirmLength(double _length, double _spec, double _tor)
        {
            if (_tor == 0) return true;

            if (Math.Abs(_length - _spec) > _tor)
            {
                errorCode = AlgoActionBase.Err_Length_Check;
                return false;
            }

            return true;
        }


        public void WriteVisionIO(XYT rev1, XYT rev2, XYXY insp, string ID, CalcType calcType , IPointResult Mark_tar1, IPointResult Mark_tar2, IPointResult Mark_obj1, IPointResult Mark_obj2 ) 
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();
           
            if (calcType == CalcType.Align)
            {
                switch (alignMotionType)
                {
                    case AlignMotionType.XY:
                    case AlignMotionType.XYT:
                        VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                        VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                        VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                        VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                        VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                        VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                        XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                        XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                        VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                        VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                        VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                        VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                        VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                        VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                        VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                        VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);




                        VisionValues["FDC_Obj_Mark_1_X"].NextValue = (double)Math.Round(Mark_obj1.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Obj_Mark_1_X"]);
                        VisionValues["FDC_Obj_Mark_1_Y"].NextValue = (double)Math.Round(Mark_obj1.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Obj_Mark_1_Y"]);
                        VisionValues["FDC_Obj_Mark_1_S"].NextValue = (int)(Math.Round(Mark_obj1.Score, 2) * 100); IOs.Add(VisionValues["FDC_Obj_Mark_1_S"]);

                        VisionValues["FDC_Obj_Mark_2_X"].NextValue = (double)Math.Round(Mark_obj2.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Obj_Mark_2_X"]);
                        VisionValues["FDC_Obj_Mark_2_Y"].NextValue = (double)Math.Round(Mark_obj2.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Obj_Mark_2_Y"]);
                        VisionValues["FDC_Obj_Mark_2_S"].NextValue = (int)(Math.Round(Mark_obj2.Score, 2) * 100); IOs.Add(VisionValues["FDC_Obj_Mark_2_S"]);
                        
                        VisionValues["FDC_Tar_Mark_1_X"].NextValue = (double)Math.Round(Mark_tar1.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Tar_Mark_1_X"]);
                        VisionValues["FDC_Tar_Mark_1_Y"].NextValue = (double)Math.Round(Mark_tar1.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Tar_Mark_1_Y"]);
                        VisionValues["FDC_Tar_Mark_1_S"].NextValue = (int)(Math.Round(Mark_tar1.Score, 2) * 100); IOs.Add(VisionValues["FDC_Tar_Mark_1_S"]);

                        VisionValues["FDC_Tar_Mark_2_X"].NextValue = (double)Math.Round(Mark_tar2.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Tar_Mark_2_X"]);
                        VisionValues["FDC_Tar_Mark_2_Y"].NextValue = (double)Math.Round(Mark_tar2.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Tar_Mark_2_Y"]);
                        VisionValues["FDC_Tar_Mark_2_S"].NextValue = (int)(Math.Round(Mark_tar2.Score, 2) * 100); IOs.Add(VisionValues["FDC_Tar_Mark_2_S"]);


                        break;
                    case AlignMotionType.UVW:
                        break;
                    case AlignMotionType.UVRW:
                        break;

                }
            }
            else
            {
                VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                VisionValues["FDC_Obj_Mark_1_X"].NextValue = (double)Math.Round(Mark_obj1.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Obj_Mark_1_X"]);
                VisionValues["FDC_Obj_Mark_1_Y"].NextValue = (double)Math.Round(Mark_obj1.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Obj_Mark_1_Y"]);
                VisionValues["FDC_Obj_Mark_1_S"].NextValue = (int)(Math.Round(Mark_obj1.Score, 2) * 100); IOs.Add(VisionValues["FDC_Obj_Mark_1_S"]);

                VisionValues["FDC_Obj_Mark_2_X"].NextValue = (double)Math.Round(Mark_obj2.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Obj_Mark_2_X"]);
                VisionValues["FDC_Obj_Mark_2_Y"].NextValue = (double)Math.Round(Mark_obj2.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Obj_Mark_2_Y"]);
                VisionValues["FDC_Obj_Mark_2_S"].NextValue = (int)(Math.Round(Mark_obj2.Score, 2) * 100); IOs.Add(VisionValues["FDC_Obj_Mark_2_S"]);

                VisionValues["FDC_Tar_Mark_1_X"].NextValue = (double)Math.Round(Mark_tar1.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Tar_Mark_1_X"]);
                VisionValues["FDC_Tar_Mark_1_Y"].NextValue = (double)Math.Round(Mark_tar1.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Tar_Mark_1_Y"]);
                VisionValues["FDC_Tar_Mark_1_S"].NextValue = (int)(Math.Round(Mark_tar1.Score, 2) * 100); IOs.Add(VisionValues["FDC_Tar_Mark_1_S"]);

                VisionValues["FDC_Tar_Mark_2_X"].NextValue = (double)Math.Round(Mark_tar2.OutputXYT.X, 3); IOs.Add(VisionValues["FDC_Tar_Mark_2_X"]);
                VisionValues["FDC_Tar_Mark_2_Y"].NextValue = (double)Math.Round(Mark_tar2.OutputXYT.Y, 3); IOs.Add(VisionValues["FDC_Tar_Mark_2_Y"]);
                VisionValues["FDC_Tar_Mark_2_S"].NextValue = (int)(Math.Round(Mark_tar2.Score, 2) * 100); IOs.Add(VisionValues["FDC_Tar_Mark_2_S"]);



                if (VisionValues.ContainsKey("InspectionLx")) { VisionValues["InspectionLx"].NextValue = (double)insp.Lx; IOs.Add(VisionValues["InspectionLx"]); }
                if (VisionValues.ContainsKey("InspectionLy")) { VisionValues["InspectionLy"].NextValue = (double)insp.Ly; IOs.Add(VisionValues["InspectionLy"]); }
                if (VisionValues.ContainsKey("InspectionRx")) { VisionValues["InspectionRx"].NextValue = (double)insp.Rx; IOs.Add(VisionValues["InspectionRx"]); }
                if (VisionValues.ContainsKey("InspectionRy")) { VisionValues["InspectionRy"].NextValue = (double)insp.Ry; IOs.Add(VisionValues["InspectionRy"]); }
            }


            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }


        //protected void DrawLineLabel_L(Iva.Bplus.Interface.IPointResult Mark_Tar, Iva.Bplus.Interface.IPointResult Mark_Obj, 
        //                             double resolution, double panelangle_rad, CogColorConstants color)
        protected void DrawLineLabel_L(string _model, Iva.Bplus.Interface.IPointResult _target, Iva.Bplus.Interface.IPointResult _object)
        {
            string _sourceID = DeepClone(sourceID);
            DateTime dateTime = DateTime.Now;
            string model = _model;

            #region Draw Results
            // Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
            makerInfo.Color = CogColorConstants.Red;
            var crossPoint_P1 = new XYT() + GetCrossPoint(Coord_Obj1, Coord_Tar1, Coord_Tar2) - T_Left_CalDataObj.GetRotateCenter(model);
            crossPoint_P1 = T_Left_CalDataObj.GetR2V(model, crossPoint_P1);
            makerInfo.Offset = crossPoint_P1;
            T_Left_DisplayObj.DrawMaker(makerInfo);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = CogColorConstants.Red;
            lineInfo.Start = Mark_Tar1_XY;
            lineInfo.End = crossPoint_P1.ToXY();
            T_Left_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = Mark_Obj1_XY;
            lineInfo.End = crossPoint_P1.ToXY();
            T_Left_DisplayObj.DrawLine(lineInfo);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Obj1_XY) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ly);
            T_Left_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Tar1_XY) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Lx);
            T_Left_DisplayObj.DrawLabel(labelInfo);
            #endregion

            string _judgement = "";
            foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
            {
                if (T_Left_DisplayObj.Judgement == (uint)j)
                {
                    _judgement = j.ToString();
                    break;
                }
            }

            object obj = (Bitmap)T_Left_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
            T_Left_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);

            if (T_Left_DisplayObj.Judgement != (uint)Judgement.InspOK && T_Left_DisplayObj.Judgement != (uint)Judgement.None)
            {
                object obj1 = T_Left_DisplayObj.GetCurImage();
                T_Left_DisplayObj.SaveImage(dateTime, obj1, _judgement, schName, _sourceID, false);
            }
        }
        protected void DrawLineLabel_R(string _model, Iva.Bplus.Interface.IPointResult _target, Iva.Bplus.Interface.IPointResult _object)
        {
            string _sourceID = DeepClone(sourceID);
            DateTime dateTime = DateTime.Now;
            string model = _model;

            #region Draw Results
            // Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
            makerInfo.Color = CogColorConstants.Red;
            var crossPoint_P2 = new XYT() + GetCrossPoint(Coord_Obj2, Coord_Tar2, Coord_Tar1) - T_Right_CalDataObj.GetRotateCenter(model);
            crossPoint_P2 = T_Right_CalDataObj.GetR2V(model, crossPoint_P2);
            makerInfo.Offset = crossPoint_P2;
            T_Right_DisplayObj.DrawMaker(makerInfo);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = CogColorConstants.Red;
            lineInfo.Start = Mark_Tar2_XY;
            lineInfo.End = crossPoint_P2.ToXY();
            T_Right_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = Mark_Obj2_XY;
            lineInfo.End = crossPoint_P2.ToXY();
            T_Right_DisplayObj.DrawLine(lineInfo);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (crossPoint_P2.ToXY() + Mark_Obj2_XY) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ry);
            T_Right_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (crossPoint_P2.ToXY() + Mark_Tar2_XY) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Rx);
            T_Right_DisplayObj.DrawLabel(labelInfo);
            #endregion

            string _judgement = "";
            foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
            {
                if (T_Right_DisplayObj.Judgement == (uint)j)
                {
                    _judgement = j.ToString();
                    break;
                }
            }

            object obj = (Bitmap)T_Right_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
            T_Right_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);

            if (T_Right_DisplayObj.Judgement != (uint)Judgement.InspOK && T_Right_DisplayObj.Judgement != (uint)Judgement.None)
            {
                object obj1 = T_Right_DisplayObj.GetCurImage();
                T_Right_DisplayObj.SaveImage(dateTime, obj1, _judgement, schName, _sourceID, false);
            }
        }

        protected void DrawInspResult(string _model, XY _target1, XY _target2, XY _object1, XY _object2)
        {
            string model = _model;
            Mark_Tar1 = _target1;
            Mark_Tar2 = _target2;
            Mark_Obj1 = _object1;
            Mark_Obj2 = _object2;

            #region Draw Results
            // Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
            makerInfo.Color = CogColorConstants.Red;
            var crossPoint_P1 = new XYT(Mark_Tar1.X, Mark_Obj1.Y, 0);
            crossPoint_P1 = T_Left_CalDataObj.GetR2V(model, crossPoint_P1);
            makerInfo.Offset = crossPoint_P1;
            T_Left_DisplayObj.DrawMaker(makerInfo);
            var crossPoint_P2 = new XYT(Mark_Tar2.X, Mark_Obj2.Y, 0);
            crossPoint_P2 = T_Right_CalDataObj.GetR2V(model, crossPoint_P2);
            makerInfo.Offset = crossPoint_P2;
            T_Right_DisplayObj.DrawMaker(makerInfo);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = CogColorConstants.Red;
            lineInfo.Start = T_Left_CalDataObj.GetR2V(model, new XYT(Mark_Tar1)).ToXY();
            lineInfo.End = crossPoint_P1.ToXY();
            T_Left_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = T_Left_CalDataObj.GetR2V(model, new XYT(Mark_Obj1)).ToXY();
            lineInfo.End = crossPoint_P1.ToXY();
            T_Left_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = T_Right_CalDataObj.GetR2V(model, new XYT(Mark_Tar2)).ToXY();
            lineInfo.End = crossPoint_P2.ToXY();
            T_Right_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = T_Right_CalDataObj.GetR2V(model, new XYT(Mark_Obj2)).ToXY();
            lineInfo.End = crossPoint_P2.ToXY();
            T_Right_DisplayObj.DrawLine(lineInfo);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (T_Left_CalDataObj.GetR2V(model, new XYT(Mark_Tar1)).ToXY() + crossPoint_P1.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ly);
            T_Left_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (T_Left_CalDataObj.GetR2V(model, new XYT(Mark_Obj1)).ToXY() + crossPoint_P1.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Lx);
            T_Left_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (T_Right_CalDataObj.GetR2V(model, new XYT(Mark_Tar2)).ToXY() + crossPoint_P2.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ry);
            T_Right_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (T_Right_CalDataObj.GetR2V(model, new XYT(Mark_Obj2)).ToXY() + crossPoint_P2.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Rx);
            T_Right_DisplayObj.DrawLabel(labelInfo);
            #endregion
        }


        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            Task task = Task.Factory.StartNew(() =>
            cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true
            ));
        }
        #endregion


    }
}

