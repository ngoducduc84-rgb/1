﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PAttach_FCIC
{
    [SerializableAttribute]
    public class Algo2PAttachFCICResult : AlgoResultBase
    {
        #region [fiedls]
        private int unitNo;  // 1Cell 물류시 Inspection 에서 Attach 유닛 구분

        private double lx;
        private double ly;
        private double rx;
        private double ry;

        private double revX;
        private double revY;
        private double revT;

        private double offset1X;
        private double offset1Y;
        private double offset1T;

        private double offset2X;
        private double offset2Y;
        private double offset2T;

        private double length_tar;
        private double length_obj;
        private bool result;
        
        //Mark
        private double p1_X; //Panel
        private double p1_Y;
        private double p2_X;
        private double p2_Y;

        private double t1_X; //Tape
        private double t1_Y;
        private double t2_X;
        private double t2_Y;

        //Robot
        private double cP1_X; //panel
        private double cP1_Y;
        private double cP2_X; 
        private double cP2_Y;

        private double cT1_X; //Tape
        private double cT1_Y;
        private double cT2_X;
        private double cT2_Y;

        private double plcOffset_Lx;
        private double plcOffset_Ly;
        private double plcOffset_Rx;
        private double plcOffset_Ry;

        private double score_p1_tar;
        private double score_p2_tar;

        private double score_p1_obj;
        private double score_p2_obj;

        #endregion


        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }

        public int UnitNo
        {
            get { return unitNo; }
            set { if (value == unitNo) return; unitNo = value; OnPropertyChanged(nameof(UnitNo)); }
        }

        public double Lx
        {
            get { return lx; }
            set { if (value == lx) return; lx = value; OnPropertyChanged(nameof(Lx)); }
        }
        public double Ly
        {
            get { return ly; }
            set { if (value == ly) return; ly = value; OnPropertyChanged(nameof(Ly)); }
        }
        public double Rx
        {
            get { return rx; }
            set { if (value == rx) return; rx = value; OnPropertyChanged(nameof(Rx)); }
        }
        public double Ry
        {
            get { return ry; }
            set { if (value == ry) return; ry = value; OnPropertyChanged(nameof(Ry)); }
        }
        public double Score_P1_Tar
        {
            get { return score_p1_tar; }
            set { if (value == score_p1_tar) return; score_p1_tar = value; OnPropertyChanged(nameof(Score_P1_Tar)); }
        }

        public double Score_P2_Tar
        {
            get { return score_p2_tar ; }
            set { if (value == score_p2_tar) return; score_p2_tar = value; OnPropertyChanged(nameof(Score_P2_Tar)); }
        }
        public double Score_P1_Obj
        {
            get { return score_p1_obj; }
            set { if (value == score_p1_obj) return; score_p1_obj = value; OnPropertyChanged(nameof(Score_P1_Obj)); }
        }

        public double Score_P2_Obj
        {
            get { return score_p2_obj; }
            set { if (value == score_p2_obj) return; score_p2_obj = value; OnPropertyChanged(nameof(Score_P2_Obj)); }
        }

        public double RevX
        {
            get { return revX; }
            set { if (value == revX) return; revX = value; OnPropertyChanged(nameof(RevX)); }
        }
        public double RevY
        {
            get { return revY; }
            set { if (value == revY) return; revY = value; OnPropertyChanged(nameof(RevY)); }
        }
        public double RevT
        {
            get { return revT; }
            set { if (value == revT) return; revT = value; OnPropertyChanged(nameof(RevT)); }
        }

        public double Offset1X
        {
            get { return offset1X; }
            set { if (value == offset1X) return; offset1X = value; OnPropertyChanged(nameof(Offset1X)); }
        }
        public double Offset1Y
        {
            get { return offset1Y; }
            set { if (value == offset1Y) return; offset1Y = value; OnPropertyChanged(nameof(Offset1Y)); }
        }
        public double Offset1T
        {
            get { return offset1T; }
            set { if (value == offset1T) return; offset1T = value; OnPropertyChanged(nameof(Offset1T)); }
        }

        public double Offset2X
        {
            get { return offset2X; }
            set { if (value == offset2X) return; offset2X = value; OnPropertyChanged(nameof(Offset2X)); }
        }
        public double Offset2Y
        {
            get { return offset2Y; }
            set { if (value == offset2Y) return; offset2Y = value; OnPropertyChanged(nameof(Offset2Y)); }
        }
        public double Offset2T
        {
            get { return offset2T; }
            set { if (value == offset2T) return; offset2T = value; OnPropertyChanged(nameof(Offset2T)); }
        }





        public double Length_tar
        {
            get { return length_tar; }
            set { if (value == length_tar) return; length_tar = value; OnPropertyChanged(nameof(Length_tar)); }
        }
        public double Length_obj
        {
            get { return length_obj; }
            set { if (value == length_obj) return; length_obj = value; OnPropertyChanged(nameof(Length_obj)); }
        }

        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }

        //Mark Panel
        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }
        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }
        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }
        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }

        //Mark Tape
        public double T1_X
        {
            get { return t1_X; }
            set { if (value == t1_X) return; t1_X = value; OnPropertyChanged(nameof(T1_X)); }
        }
        public double T1_Y
        {
            get { return t1_Y; }
            set { if (value == t1_Y) return; t1_Y = value; OnPropertyChanged(nameof(T1_Y)); }
        }
        public double T2_X
        {
            get { return t2_X; }
            set { if (value == t2_X) return; t2_X = value; OnPropertyChanged(nameof(T2_X)); }
        }
        public double T2_Y
        {
            get { return t2_Y; }
            set { if (value == t2_Y) return; t2_Y = value; OnPropertyChanged(nameof(T2_Y)); }
        }


        //Robot Panel
        public double CP1_X
        {
            get { return cP1_X; }
            set { if (value == cP1_X) return; cP1_X = value; OnPropertyChanged(nameof(CP1_X)); }
        }
        public double CP1_Y
        {
            get { return cP1_Y; }
            set { if (value == cP1_Y) return; cP1_Y = value; OnPropertyChanged(nameof(CP1_Y)); }
        }
        public double CP2_X
        {
            get { return cP2_X; }
            set { if (value == cP2_X) return; cP2_X = value; OnPropertyChanged(nameof(CP2_X)); }
        }
        public double CP2_Y
        {
            get { return cP2_Y; }
            set { if (value == cP2_Y) return; cP2_Y = value; OnPropertyChanged(nameof(CP2_Y)); }
        }
        //Robot Tape
        public double CT1_X
        {
            get { return cT1_X; }
            set { if (value == cT1_X) return; cT1_X = value; OnPropertyChanged(nameof(CT1_X)); }
        }
        public double CT1_Y
        {
            get { return cT1_Y; }
            set { if (value == cT1_Y) return; cT1_Y = value; OnPropertyChanged(nameof(CT1_Y)); }
        }
        public double CT2_X
        {
            get { return cT2_X; }
            set { if (value == cT2_X) return; cT2_X = value; OnPropertyChanged(nameof(CT2_X)); }
        }
        public double CT2_Y
        {
            get { return cT2_Y; }
            set { if (value == cT2_Y) return; cT2_Y = value; OnPropertyChanged(nameof(CT2_Y)); }
        }

        public double PlcOffset_Lx
        {
            get { return plcOffset_Lx; }
            set { if (value == plcOffset_Lx) return; plcOffset_Lx = value; OnPropertyChanged(nameof(PlcOffset_Lx)); }
        }
        public double PlcOffset_Ly
        {
            get { return plcOffset_Ly; }
            set { if (value == plcOffset_Ly) return; plcOffset_Ly = value; OnPropertyChanged(nameof(PlcOffset_Ly)); }
        }
        public double PlcOffset_Rx
        {
            get { return plcOffset_Rx; }
            set { if (value == plcOffset_Rx) return; plcOffset_Rx = value; OnPropertyChanged(nameof(PlcOffset_Rx)); }
        }
        public double PlcOffset_Ry
        {
            get { return plcOffset_Ry; }
            set { if (value == plcOffset_Ry) return; plcOffset_Ry = value; OnPropertyChanged(nameof(PlcOffset_Ry)); }
        }
        #endregion


        public Algo2PAttachFCICResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "offset1X: {3},\noffset1Y: {4},\noffset1T: {5},\n" +
                                  "offset2X: {6},\noffset2Y: {7},\noffset2T: {8},\n" +
                                  "LengthTarget: {9},\nResult: {10},\n" +
                                  "P1_X: {11},\nP1_Y: {12},\nP2_X: {13},\nP2_Y: {14},\n" +
                                  "T1_X: {15},\nT1_Y: {16},\nT2_X: {17},\nT2_Y: {18},\n" +
                                  "CP1_X: {19},\nCP1_Y: {20},\nCP2_X: {21},\nCP2_Y: {22},\n" +
                                  "CT1_X: {23},\nCT1_Y: {24},\nCT2_X: {25},\nCT2_Y: {26},\n"
                                  , typeof(Algo2PAttachFCICResult).ToString(), curTime, curDate
                                  , offset1X, offset1Y, offset1T
                                  , offset2X, offset2Y, offset2T
                                  , length_tar, result
                                  , p1_X, p1_Y, p2_X, p2_Y
                                  , t1_X, t1_Y, t2_X, t2_Y
                                  , cP1_X, cP1_Y, cP2_X, cP2_Y
                                  , cT1_X, cT1_Y, cT2_X, cT2_Y
                                  );
            //return "";
        }

    }
}
