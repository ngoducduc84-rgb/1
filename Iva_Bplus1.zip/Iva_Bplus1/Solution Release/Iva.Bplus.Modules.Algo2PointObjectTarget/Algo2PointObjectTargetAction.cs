﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo90SubLami;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;

namespace Iva.Bplus.Modules.Algo2PointObjectTarget
{
    [SerializableAttribute]
    public partial class Algo2PointObjectTargetAction : AlgoActionBase
    {
        #region [Fields]
        #endregion

        #region [Properties]   
        #endregion

        #region[Command]
        #endregion

        #region [Construct]

        public Algo2PointObjectTargetAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            inputParams = new Algo2PointObjectTargetInputParams();
            OutputParams = new Algo2PointObjectTargetOutputParams();

            CalcType type = (_object as Algo2PointObjectTargetObject).CalcType;
            if (type == CalcType.Align)
            {
                var obj = _object as Algo2PointObjectTargetObject;
                obj.ModelParamType = typeof(Algo2PointObjectTargetModelParams);
                var param = obj.CurParams as Algo2PointObjectTargetModelParams;

                ChildSettingView = new AlignSetting();
                ChildSettingView.DataContext = this;
            }
            else if (type == CalcType.Inspection)
            {
                var obj = _object as Algo2PointObjectTargetObject;
                obj.ModelParamType = typeof(Algo2PointObjectTargetModelParams);
                var param = obj.CurParams as Algo2PointObjectTargetModelParams;

                ChildSettingView = new InspectionSetting();
                ChildSettingView.DataContext = this;
            }

            ModObject.PropertyChanged += ModObject_PropertyChanged;
        }
        #endregion
        
        #region [override method]

        private void ModObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            var obj = sender as Algo2PointObjectTargetObject;
            if (e.PropertyName == "CalcType")
            {
                if (obj.CalcType == CalcType.Align)
                {
                    obj.ModelParamType = typeof(Algo2PointObjectTargetModelParams);
                    var param = obj.CurParams as Algo2PointObjectTargetModelParams;

                    ChildSettingView = new AlignSetting();
                    ChildSettingView.DataContext = this;
                }
                else if (obj.CalcType == CalcType.Inspection)
                {
                    obj.ModelParamType = typeof(Algo2PointObjectTargetModelParams);
                    var param = obj.CurParams as Algo2PointObjectTargetModelParams;

                    ChildSettingView = new InspectionSetting();
                    ChildSettingView.DataContext = this;
                }
            }
        }

        public override List<CommandReplyArgs> Play(ModuleActionBase _obj, CmdReqArgs _args)
        {
            string InputName = Start(_obj, _args, false);
            var Obj = modObject as Algo2PointObjectTargetObject;

            var InParams = InputParams as Algo2PointObjectTargetInputParams;
            var OutParams = OutputParams as Algo2PointObjectTargetOutputParams;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                #region Step1 : Calc
                    Obj.Name = name;    // 이름 넣어주기.
                    Obj.SourceID = ObjectID;
                if (!Obj.Run())
                {
                    OutputPlay("LogResult", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                    return OccurError(Obj.ErrorCode);
                }
                #endregion

                #region Step2 : Result Data Show
                    ReplyArgs = OutputPlay("LogResult", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                #endregion

                Obj.AppendMessage(Name, "Caluration Complete");
                StopTimer();
            }

            return End(false);
        }

        public override void Dispose()
        {
            ModObject.PropertyChanged -= ModObject_PropertyChanged;
            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion
    }
}
