﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo2PointObjectTarget
{
    [SerializableAttribute]
    public class Algo2PointObjectTargetInputParams : InputParams
    {
        #region input Objct0~1, Target0~1
        private MatchingRstData Object0 { get; set; }
        private MatchingRstData Object1 { get; set; }
        private MatchingRstData Target0 { get; set; }
        private MatchingRstData Target1 { get; set; }
        #endregion

        public CalcTrigger Trigger { get; set; }

    }
}
