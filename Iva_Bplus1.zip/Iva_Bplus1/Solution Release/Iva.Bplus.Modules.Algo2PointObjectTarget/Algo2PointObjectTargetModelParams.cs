﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo2PointObjectTarget
{
    [SerializableAttribute]
    public class Algo2PointObjectTargetModelParams : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }


        public Algo2PointObjectTargetModelParams()
            :base()
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", -10.0, 10.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", -10.0, 10.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", 0, (double)5.0);
        }

        public Algo2PointObjectTargetModelParams(double limitX, double limitY, double limitT)
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), limitX, "Revision Offset Limit X", 0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), limitY, "Revision Offset Limit Y", 0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), limitT, "Revision Offset Limit T", 0, (double)5.0);
        }
    }
}
