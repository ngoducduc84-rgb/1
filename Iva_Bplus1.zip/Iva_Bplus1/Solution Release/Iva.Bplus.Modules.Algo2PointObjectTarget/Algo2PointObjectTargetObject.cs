﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;

namespace Iva.Bplus.Modules.Algo2PointObjectTarget
{
    [SerializableAttribute]
    public class Algo2PointObjectTargetObject : AlgoObjectBase
    {
        #region [Fields]

        #region  Selected Caldata Name
        private string object_1st_L_CalData;
        private string object_1st_R_CalData;
        private string target_1st_L_CalData;
        private string target_1st_R_CalData;
        #endregion

        #region Seleced Caldata Object
        [NonSerialized]
        private CalDataObject object_1st_L_CalDataObj;
        [NonSerialized]
        private CalDataObject object_1st_R_CalDataObj;
        [NonSerialized]
        private CalDataObject target_1st_L_CalDataObj;
        [NonSerialized]
        private CalDataObject target_1st_R_CalDataObj;
        #endregion

        #region etc
        private CalcType calcType;
        private DirectionType dirType;
        #endregion

        #endregion

        #region [properties]

        #region  Selected Caldata Name

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Object_1st_L_CalData
        {
            get { return object_1st_L_CalData; }
            set
            {
                object_1st_L_CalData = value;
                object_1st_L_CalDataObj = SystemObject_Common.GetObject(object_1st_L_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Object_1st_L_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Object_1st_R_CalData
        {
            get { return object_1st_R_CalData; }
            set
            {
                object_1st_R_CalData = value;
                object_1st_R_CalDataObj = SystemObject_Common.GetObject(object_1st_R_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Object_1st_R_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Target_1st_L_CalData
        {
            get { return target_1st_L_CalData; }
            set
            {
                target_1st_L_CalData = value;
                target_1st_L_CalDataObj = SystemObject_Common.GetObject(target_1st_L_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Target_1st_L_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Target_1st_R_CalData
        {
            get { return target_1st_R_CalData; }
            set
            {
                target_1st_R_CalData = value;
                target_1st_R_CalDataObj = SystemObject_Common.GetObject(target_1st_R_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Target_1st_R_CalData));
            }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set
            {
                if (calcType == value) return;
                calcType = value;
                ModelParams.Clear();

                switch (calcType)
                {

                    case CalcType.Align:
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                                ModelParams.Add(model, new Algo2PointObjectTargetModelParams());

                        }
                        break;
                    case CalcType.Inspection:
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                                ModelParams.Add(model, new Algo2PointObjectTargetModelParams());
                        }
                        break;

                }
                CurParams = ModelParams[SystemModel.GetCurModel()];

                this.OnPropertyChanged(nameof(CalcType));
            }
        }

        public DirectionType DirType
        {
            get { return dirType; }
            set
            {
                if (dirType == value) return;
                dirType = value;

                this.OnPropertyChanged(nameof(DirType));
            }
        }

        public ObservableCollection<string> CalDataList
        {
            get
            {
                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));
            }
        }
        #endregion

        #endregion

        #region[Construct]

        public Algo2PointObjectTargetObject()
            : base()
        {
            List<string> lst = SystemObject_Device.GetEachObjectName(typeof(MitsubishiPLCObject));

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo2PointObjectTargetModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            if (CalcType == CalcType.Inspection) return InspectCalc();
            else return AlignCalc();
        }

        public override void ObjectInitialize()
        {
            base.ObjectInitialize();

            Object_1st_L_CalData = object_1st_L_CalData;
            Object_1st_R_CalData = object_1st_R_CalData;
            Target_1st_L_CalData = target_1st_L_CalData;
            Target_1st_R_CalData = target_1st_R_CalData;
        }

        public override void DefaultIOSet()
        {
            base.DefaultIOSet();

            Object_1st_L_CalData = object_1st_L_CalData;
            Object_1st_R_CalData = object_1st_R_CalData;
            Target_1st_L_CalData = target_1st_L_CalData;
            Target_1st_R_CalData = target_1st_R_CalData;
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion

        #region [Private Method]

        private bool AlignCalc()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
            UpdatePLCIOs();

            var x = (double)PlcValues["CurrentPosX"].CurValue;
            var y = (double)PlcValues["CurrentPosY"].CurValue;
            var t = (double)PlcValues["CurrentPosT"].CurValue;
            var curPos = new XYT(x, y, t);

            x = (double)PlcValues["OffsetX"].CurValue;
            y = (double)PlcValues["OffsetY"].CurValue;
            t = (double)PlcValues["OffsetT"].CurValue;
            var offset = new XYT(x, y, t);
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Object_1st_L") || !InputValues.ContainsKey("Object_1st_R") ||
                !InputValues.ContainsKey("Target_1st_L") || !InputValues.ContainsKey("Target_1st_R"))
            {
                // Mark Info가 없음.
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            var Object_1st_L = InputValues["Object_1st_L"] as MatchingRstData;
            var Object_1st_R = InputValues["Object_1st_R"] as MatchingRstData;
            var Target_1st_L = InputValues["Target_1st_L"] as MatchingRstData;
            var Target_1st_R = InputValues["Target_1st_R"] as MatchingRstData;

            if (Object_1st_L == null || Object_1st_R == null ||
                Target_1st_L == null || Target_1st_R == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            #endregion

            #region Coordnate Pos Calc & CalData Cofirm
            if (object_1st_L_CalDataObj == null || object_1st_R_CalDataObj == null ||
                target_1st_L_CalDataObj == null || target_1st_R_CalDataObj == null)
            {
                // Calibration 설정 안됨.
                errorCode = AlgoActionBase.Err_CalData_Is_Null;                
                return false;
            }

            var rObject_1st_L = object_1st_L_CalDataObj.GetV2R(model, new XY(Object_1st_L.OutputXYT.X, Object_1st_L.OutputXYT.Y));
            var rObject_1st_R = object_1st_R_CalDataObj.GetV2R(model, new XY(Object_1st_R.OutputXYT.X, Object_1st_R.OutputXYT.Y));

            var rTarget_1st_L = target_1st_L_CalDataObj.GetV2R(model, new XY(Target_1st_L.OutputXYT.X, Target_1st_L.OutputXYT.Y));
            var rTarget_1st_R = target_1st_R_CalDataObj.GetV2R(model, new XY(Target_1st_R.OutputXYT.X, Target_1st_R.OutputXYT.Y));

            var cObject_1st_L = rObject_1st_L + object_1st_L_CalDataObj.GetRotateCenter(model);
            var cObject_1st_R = rObject_1st_R + object_1st_R_CalDataObj.GetRotateCenter(model);

            var cTarget_1st_L = rTarget_1st_L + target_1st_L_CalDataObj.GetRotateCenter(model);
            var cTarget_1st_R = rTarget_1st_R + target_1st_R_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo2PointObjectTargetModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            #endregion

            #region Calc Rev Offset

            // 단변
            double objectT = GetThetaColumn(cObject_1st_L.X, cObject_1st_R.X, cObject_1st_L.Y, cObject_1st_R.Y);
            double targetT = GetThetaColumn(cTarget_1st_L.X, cTarget_1st_R.X, cTarget_1st_L.Y, cTarget_1st_R.Y);

            var objectTar = (cObject_1st_L + cObject_1st_R) / 2;
            var targetObj = (cTarget_1st_L + cTarget_1st_R) / 2;

            var alignOffset = offset;
            var objectTarxyt = new XYT(objectTar.X, objectTar.Y, objectT);
            var targetObjxyt = new XYT(targetObj.X, targetObj.Y, targetT);

            // Align 위치 보정값 계산.
            var revAlign = new XYT();
            targetObjxyt = ApplyTargetOffset(targetObjxyt, alignOffset);

            double radT = NormalizeTheta(targetObjxyt.T - objectTarxyt.T);

            double DriftX = Math.Cos(radT) * objectTarxyt.X - Math.Sin(radT) * objectTarxyt.Y;
            double DriftY = Math.Sin(radT) * objectTarxyt.X + Math.Cos(radT) * objectTarxyt.Y;

            revAlign.X = targetObjxyt.X - DriftX;
            revAlign.Y = targetObjxyt.Y - DriftY;

            if (DirType == DirectionType.Normal)
                revAlign.T = radT / rad;
            else
                revAlign.T = (radT / rad) * -1;
            #endregion

            #region Calc Length
            var object01 = GetLength(cObject_1st_L, cObject_1st_R);
            var target01 = GetLength(cTarget_1st_L, cTarget_1st_R);
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo2PointObjectTargetResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                RevX = Math.Round(revAlign.X, 3),
                RevY = Math.Round(revAlign.Y, 3),
                RevT = Math.Round(revAlign.T, 3),

                OffsetX = Math.Round(alignOffset.X, 3),
                OffsetY = Math.Round(alignOffset.Y, 3),
                OffsetT = Math.Round(alignOffset.T, 3),

                Object_1st_Lx = Math.Round(cObject_1st_L.X, 3),
                Object_1st_Ly = Math.Round(cObject_1st_L.Y, 3),
                Object_1st_Rx = Math.Round(cObject_1st_R.X, 3),
                Object_1st_Ry = Math.Round(cObject_1st_R.Y, 3),

                Target_1st_Lx = Math.Round(cTarget_1st_L.X, 3),
                Target_1st_Ly = Math.Round(cTarget_1st_L.Y, 3),
                Target_1st_Rx = Math.Round(cTarget_1st_R.X, 3),
                Target_1st_Ry = Math.Round(cTarget_1st_R.Y, 3),
            };
            #endregion

            #region Confirm Result
            if (!ConfirmSpecMinMax(revAlign.X, limitX * (-1), limitX) ||
                !ConfirmSpecMinMax(revAlign.Y, limitY * (-1), limitY) ||
                !ConfirmSpecMinMax(revAlign.T, limitT * (-1), limitT))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }
            #endregion

            #region Vision Write (Result & FDC)
            var IOs = new List<IOStruct>();
            VisionValues["TargetPosX"].NextValue = (double)revAlign.X; IOs.Add(VisionValues["TargetPosX"]);
            VisionValues["TargetPosY"].NextValue = (double)revAlign.Y; IOs.Add(VisionValues["TargetPosY"]);
            VisionValues["TargetPosT"].NextValue = (double)revAlign.T; IOs.Add(VisionValues["TargetPosT"]);

            CommodObject.SetVisionValues(IOs);
            #endregion
            return true;
        }

        private bool InspectCalc()
        {
            return true;
        }

        #endregion

        #region [Public Method]
        public XYT GetCurrentPos(GrabPos pos)
        {
            var IOs = new List<IOStruct>();
            IOs.Add(PlcValues["CurrentPosX"]);
            IOs.Add(PlcValues["CurrentPosY"]);
            IOs.Add(PlcValues["CurrentPosT"]);

            CommodObject.UpdatePlcValues(IOs);

            var curPos = new XYT();

            curPos.X = (double)PlcValues["CurrentPosX"].CurValue;
            curPos.Y = (double)PlcValues["CurrentPosY"].CurValue;
            curPos.T = (double)PlcValues["CurrentPosT"].CurValue;

            return curPos;
        }

        #endregion
    }
}
