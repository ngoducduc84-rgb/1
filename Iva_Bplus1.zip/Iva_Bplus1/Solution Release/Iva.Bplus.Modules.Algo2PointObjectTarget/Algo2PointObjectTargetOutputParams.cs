﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using SvMip;
using System;

namespace Iva.Bplus.Modules.Algo2PointObjectTarget
{
    [SerializableAttribute]
    public class Algo2PointObjectTargetOutputParams : OutputParams
    {
        public object LogResult { get; set; }
    }
}
