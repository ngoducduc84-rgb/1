﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using OpenCvSharp;
using SvMip;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo2PointObjectTarget
{
    [SerializableAttribute]
    public class Algo2PointObjectTargetResult : AlgoResultBase
    {
        #region [fiedls]
        private double revX;
        private double revY;
        private double revT;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        private double object_1st_Lx;
        private double object_1st_Ly;
        private double object_1st_Rx;
        private double object_1st_Ry;

        private double target_1st_Lx;
        private double target_1st_Ly;
        private double target_1st_Rx;
        private double target_1st_Ry;
        #endregion

        #region[Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double RevX
        {
            get { return revX; }
            set { if (value == revX) return; revX = value; OnPropertyChanged(nameof(RevX)); }
        }

        public double RevY
        {
            get { return revY; }
            set { if (value == revY) return; revY = value; OnPropertyChanged(nameof(RevY)); }
        }

        public double RevT
        {
            get { return revT; }
            set { if (value == revT) return; revT = value; OnPropertyChanged(nameof(RevT)); }
        }

        public double OffsetX
        {
            get { return offsetX; }
            set { if (value == offsetX) return; offsetX = value; OnPropertyChanged(nameof(OffsetX)); }
        }

        public double OffsetY
        {
            get { return offsetY; }
            set { if (value == offsetY) return; offsetY = value; OnPropertyChanged(nameof(OffsetY)); }
        }

        public double OffsetT
        {
            get { return offsetT; }
            set { if (value == offsetT) return; offsetT = value; OnPropertyChanged(nameof(OffsetT)); }
        }

        public double Object_1st_Lx
        {
            get { return object_1st_Lx; }
            set { if (value == object_1st_Lx) return; object_1st_Lx = value; OnPropertyChanged(nameof(Object_1st_Lx)); }
        }

        public double Object_1st_Ly
        {
            get { return object_1st_Ly; }
            set { if (value == object_1st_Ly) return; object_1st_Ly = value; OnPropertyChanged(nameof(Object_1st_Ly)); }
        }

        public double Object_1st_Rx
        {
            get { return object_1st_Rx; }
            set { if (value == object_1st_Rx) return; object_1st_Rx = value; OnPropertyChanged(nameof(Object_1st_Rx)); }
        }

        public double Object_1st_Ry
        {
            get { return object_1st_Ry; }
            set { if (value == object_1st_Ry) return; object_1st_Ry = value; OnPropertyChanged(nameof(Object_1st_Ry)); }
        }

        public double Target_1st_Lx
        {
            get { return target_1st_Lx; }
            set { if (value == target_1st_Lx) return; target_1st_Lx = value; OnPropertyChanged(nameof(Target_1st_Lx)); }
        }

        public double Target_1st_Ly
        {
            get { return target_1st_Ly; }
            set { if (value == target_1st_Ly) return; target_1st_Ly = value; OnPropertyChanged(nameof(Target_1st_Ly)); }
        }

        public double Target_1st_Rx
        {
            get { return target_1st_Rx; }
            set { if (value == target_1st_Rx) return; target_1st_Rx = value; OnPropertyChanged(nameof(Target_1st_Rx)); }
        }

        public double Target_1st_Ry
        {
            get { return target_1st_Ry; }
            set { if (value == target_1st_Ry) return; target_1st_Ry = value; OnPropertyChanged(nameof(Target_1st_Ry)); }
        }
        #endregion

        public Algo2PointObjectTargetResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1}\n,curTime: {2}\n, " +
                                  "revX: {3}\n,revY: {4}\n,revT: {5}\n" +
                                  "offsetX: {9}\n,offsetY: {10}\n,offsetT: {11}\n"
                                  , typeof(Algo2PointObjectTargetResult).ToString(), curTime, curDate
                                  , RevX, RevY, RevT
                                  , offsetX, offsetY, offsetT
                                  );
        }
    }
}
