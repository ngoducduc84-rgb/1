﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo2PointObjectTarget
{
    public enum DirectionType { Normal, Reverse }
    public enum CalcType { Align, Inspection }
    public enum GrabPos { Obect_1st, Obect_2st, Target_1st, Target_2st }
    public enum MeasurePos { UpperLx, UpperLy, UpperRx, UpperRy, LowerLx, LowerLy, LowerRx, LowerRy }

}

