﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo2PointObjectTarget
{
    public partial class Algo2PointObjectTargetAction
    {
        #region [Error Script] Algo1PointGetAction : 15101 ~ 15200
        //static public int Err_Sample = 00000; public string E00000_Sample = "Sample Title";
        public override void ErrorDefine()
        {
            base.ErrorDefine();
            //errorInfos.Add(new ErrorInfo(this.Parent, Err_Sample, ErrorType.ErrorStop, E00000_Sample, "Error Define Sample입니다."));
        }
        #endregion
    }
}
