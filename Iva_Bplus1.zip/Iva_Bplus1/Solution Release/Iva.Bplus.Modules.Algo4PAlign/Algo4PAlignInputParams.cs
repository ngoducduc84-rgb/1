﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo4PAlign
{
    [SerializableAttribute]
    class Algo4PAlignInputParams : InputParams
    {
        #region Input P1, P2, P3, P4
        public object P1 { get; set; }
        public object P2 { get; set; }
        public object P3 { get; set; }
        public object P4 { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
