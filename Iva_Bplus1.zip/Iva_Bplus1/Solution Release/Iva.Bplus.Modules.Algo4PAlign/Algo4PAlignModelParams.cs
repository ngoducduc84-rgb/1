﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo4PAlign
{
    [SerializableAttribute]

    public partial class Algo4PAlignModelParams : AlgoParams
    {
        #region Lenght Center       
        private AlgoParam objLength1;
        private AlgoParam objLength2;
        private AlgoParam objLength3;
        private AlgoParam objLength4;
        #endregion

        #region Length Rage
        private AlgoParam lengthTor;
        #endregion

        #region Align Limit
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        #endregion

        public AlgoParam ObjLength1 { get { return objLength1; } set { if (objLength1 == value) return; objLength1 = value; this.OnPropertyChanged(nameof(ObjLength1)); } }
        public AlgoParam ObjLength2 { get { return objLength2; } set { if (objLength2 == value) return; objLength2 = value; this.OnPropertyChanged(nameof(ObjLength2)); } }
        public AlgoParam ObjLength3 { get { return objLength3; } set { if (objLength3 == value) return; objLength3 = value; this.OnPropertyChanged(nameof(ObjLength3)); } }
        public AlgoParam ObjLength4 { get { return objLength4; } set { if (objLength4 == value) return; objLength4 = value; this.OnPropertyChanged(nameof(ObjLength4)); } }

        public AlgoParam LengthTor { get { return lengthTor; } set { if (lengthTor == value) return; lengthTor = value; this.OnPropertyChanged(nameof(LengthTor)); } }

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }


        public Algo4PAlignModelParams()
            : base()
        {
            ObjLength1 = new AlgoParam("ObjLength1", "mm", typeof(double), 0.0, "Obj Point0 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);
            ObjLength2 = new AlgoParam("ObjLength2", "mm", typeof(double), 0.0, "Obj Point1 <-> Obj Point2 Dist", (double)0.0, (double)1000.0);
            ObjLength3 = new AlgoParam("ObjLength3", "mm", typeof(double), 0.0, "Obj Point2 <-> Obj Point3 Dist", (double)0.0, (double)1000.0);
            ObjLength4 = new AlgoParam("ObjLength4", "mm", typeof(double), 0.0, "Obj Point3 <-> Obj Point0 Dist", (double)0.0, (double)1000.0);

            LengthTor = new AlgoParam("LengthTor", "mm", typeof(double), 0.0, "L Check Tolerance Value", (double)0.0, (double)1.0);

            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);
        }
    }
}
