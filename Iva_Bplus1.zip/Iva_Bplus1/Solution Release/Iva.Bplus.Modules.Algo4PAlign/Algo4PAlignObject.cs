﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo4PAlign
{
    public enum eAlignPosition
    {
        Panel_Pre, Window_Pre, Ch_Panel_Pre
    }

    [SerializableAttribute]
    public partial class Algo4PAlignObject : AlgoObjectBase
    {
        #region [Fields]
        private string p_CalData1;
        private string p_CalData2;
        private string p_CalData3;
        private string p_CalData4;
        private string imageName = "Panel_Pre.PNG";
        [field: NonSerialized]
        IPointResult[] rstData;
        [field: NonSerialized]
        CalDataObject[] calDataObj;
        [field: NonSerialized]
        XY[] objRobotPos;
        [field: NonSerialized]
        XY[] tarRobotPos;
        [field: NonSerialized]
        XY[] refRobotPos;
        [field: NonSerialized]
        XY[] objCoorPos;
        [field: NonSerialized]
        XY[] tarCoorPos;
        [field: NonSerialized]
        XY[] refCoorPos;
        [field: NonSerialized]
        public double[] objLineTheta;
        [field: NonSerialized]
        public double[] tarLineTheta;
        [field: NonSerialized]
        public double[] refLineTheta;
        [field: NonSerialized]
        public XYT objRevPos;
        [field: NonSerialized]
        public XYT tarRevPos;
        [field: NonSerialized]
        public XYT refRevPos;
        [field: NonSerialized]
        double[] objLength;
        [field: NonSerialized]
        double[] refLength;
        [field: NonSerialized]
        double[] tarLength;
        [field: NonSerialized]
        bool[] bObjLength = new bool[4] { false, false, false, false };        
        #endregion

        #region etc
        private CalcPoint calcPoint;
        private CalcType calcType;
        private ThetaCalType thetaCalType;
        private ThetaDirection thetaDirection;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        private eAlignPosition alignPos = eAlignPosition.Panel_Pre;
        #endregion

        #region Align관련 Data
        [field: NonSerialized]
        XYT revAlign = new XYT();
        [field: NonSerialized]
        XYT revUnload = new XYT();
        #endregion

        #region [properties]
        public string ImageName
        {
            get { return imageName; }
            set
            {
                if (imageName == value) return;
                imageName = value;
                this.OnPropertyChanged(nameof(ImageName));
            }
        }

        public eAlignPosition AlignPos
        {
            get { return alignPos; }
            set 
            { 
                if (alignPos == value) return; 
                alignPos = value;

                switch (alignPos)
                {
                    case eAlignPosition.Panel_Pre:
                        ImageName = "Panel_Pre.PNG";
                        break;
                    case eAlignPosition.Window_Pre:
                        ImageName = "Window_Pre.PNG";
                        break;
                    case eAlignPosition.Ch_Panel_Pre:
                        ImageName = "Ch_Panel_Pre.PNG";
                        break;
                    default:
                        ImageName = "Panel_Pre.PNG";
                        break;
                }
                this.OnPropertyChanged(nameof(AlignPos)); 
            }
        }
        public double[] ObjectLength
        {
            get { return objLength; }
            set { if (objLength == value) return; objLength = value; this.OnPropertyChanged(nameof(ObjectLength)); }
        }

        public IPointResult[] ResultData
        {
            get { return rstData; }
            set { if (rstData == value) return; rstData = value; this.OnPropertyChanged(nameof(ResultData)); }
        }
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P1_CalData
        {
            get { return p_CalData1; }
            set { if (p_CalData1 == value) return; p_CalData1 = value; this.OnPropertyChanged(nameof(P1_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P2_CalData
        {
            get { return p_CalData2; }
            set { if (p_CalData2 == value) return; p_CalData2 = value; this.OnPropertyChanged(nameof(P2_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P3_CalData
        {
            get { return p_CalData3; }
            set { if (p_CalData3 == value) return; p_CalData3 = value; this.OnPropertyChanged(nameof(P3_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P4_CalData
        {
            get { return p_CalData4; }
            set { if (p_CalData4 == value) return; p_CalData4 = value; this.OnPropertyChanged(nameof(P4_CalData)); }
        }
        #endregion

        #region etc
        public CalcPoint CalcPoint
        {
            get { return calcPoint; }
            set { if (calcPoint == value) return; calcPoint = value; this.OnPropertyChanged(nameof(CalcPoint)); }
        }
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }
        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public ThetaCalType ThetaCalType
        {
            get { return thetaCalType; }
            set { if (thetaCalType == value) return; thetaCalType = value; OnPropertyChanged("ThetaCalType"); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }
        public ObservableCollection<string> CalDataList
        {
            get
            {
                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }
        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        #endregion

        public bool[] TarLength { get { return bObjLength; } }

        #endregion

        #region[Construct]
        public Algo4PAlignObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));
            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo4PAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private string lastResult;

        /// <summary>
        /// 
        /// </summary>
        void Initialize()
        {
            rstData = new IPointResult[4];
            calDataObj = new CalDataObject[4];
            objRobotPos = new XY[4];
            tarRobotPos = new XY[4];
            refRobotPos = new XY[4];
            objCoorPos = new XY[4];
            tarCoorPos = new XY[4];
            refCoorPos = new XY[4];
            objLineTheta = new double[4];
            tarLineTheta = new double[4];
            refLineTheta = new double[4];
            objRevPos = new XYT();
            tarRevPos = new XYT();
            refRevPos = new XYT();

            objLength = new double[4];
            tarLength = new double[4];
            refLength = new double[4];
        }


        //  0 ------------------ 1 
        //    l [Left]          l [Right]       : 1st
        //    |                 l    
        //    l                 l     ^         
        //    |                 |     |
        //    l                 l     |    theta, Length 계산 방향(반시계)
        //    l                 l     |    
        //    l                 l         
        //    l                 l         
        //    l [Left]          l [Right]       : 2nd
        //  2 ------------------ 3
        //        -------->   theta, Length 계산 방향(반시계)
        //            ↑ 투입 방향    
        //            ↑ 
        //            ↑ 

        private bool AlignCalc()
        {
            #region Initialize
            bool bResult = true;
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            Initialize();
            int iCnt = (int)calcPoint;
            if (iCnt == 0) iCnt = 4;
            #endregion

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            //#region Mark Data Read& Confirm
            string[] pCalData = new string[4] { p_CalData1, p_CalData2, p_CalData3, p_CalData4 };

            // 귀찮아서 그냥 loop 돌린다.
            for (int i = 0; i < iCnt; i++)
            {
                #region InputData, RefData Set
                // Input Data Check
                if (!InputValues.ContainsKey("P" + (i + 1).ToString()))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                rstData[i] = InputValues["P" + (i + 1).ToString()] as IPointResult;
                if (rstData[i] == null)
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                // Ref Point 설정
                if (rstData[i].RefPoints == null)
                {
                    rstData[i].RefPoints = new List<XYT>();
                    rstData[i].RefPoints.Add(new XYT(0, 0, 0));
                }

                #region Coordinate Pos Calc & CalData Cofirm
                // Cal Data 설정
                calDataObj[i] = SystemObject_Common.GetObject(pCalData[i]) as CalDataObject;
                if (calDataObj[i] == null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    return false;
                }

                // Obj Robot Pos
                objRobotPos[i] = calDataObj[i].GetV2R(model, new XY(rstData[i].OutputXYT.X, rstData[i].OutputXYT.Y));
                // Camera Robot Pos
                tarRobotPos[i] = new XY(0, 0);
                // Reference Robot Pos
                refRobotPos[i] = calDataObj[i].GetV2R(model, new XY(rstData[i].RefPoints[0].X, rstData[i].RefPoints[0].Y));

                // Camera Coordination Pos
                objCoorPos[i] = objRobotPos[i] + calDataObj[i].GetRotateCenter(model);
                // Camera Coordination Pos
                tarCoorPos[i] = tarRobotPos[i] + calDataObj[i].GetRotateCenter(model);
                // Ref Coordination Robot Pos
                refCoorPos[i] = refRobotPos[i] + calDataObj[i].GetRotateCenter(model);
                #endregion
            }
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo4PAlignModelParams;

            double[] objLengthSpec = new double[4];
            double LengthTor;

            CheckParamSet(mParams);

            objLengthSpec[0] = (double)mParams.ObjLength1.Value;
            objLengthSpec[1] = (double)mParams.ObjLength2.Value;
            objLengthSpec[2] = (double)mParams.ObjLength3.Value;
            objLengthSpec[3] = (double)mParams.ObjLength4.Value;
            LengthTor = (double)mParams.LengthTor.Value;

            double limitX = (double)mParams.LimitX.Value;
            double limitY = (double)mParams.LimitY.Value;
            double limitT = (double)mParams.LimitT.Value;
            #endregion

            #region Get X, Y, T
            if (calcPoint == CalcPoint.Obj_3P)
            {
                // 일단 비워둠,,,
            }
            else
            {
                // Get Line Theta
                objLineTheta[0] = GetThetaColumn(objCoorPos[0].X, objCoorPos[1].X, objCoorPos[0].Y, objCoorPos[1].Y);
                objLineTheta[1] = GetThetaColumn(objCoorPos[1].X, objCoorPos[3].X, objCoorPos[1].Y, objCoorPos[3].Y);
                objLineTheta[2] = GetThetaColumn(objCoorPos[3].X, objCoorPos[2].X, objCoorPos[3].Y, objCoorPos[2].Y);
                objLineTheta[3] = GetThetaColumn(objCoorPos[2].X, objCoorPos[0].X, objCoorPos[2].Y, objCoorPos[0].Y);

                refLineTheta[0] = GetThetaColumn(refCoorPos[0].X, refCoorPos[1].X, refCoorPos[0].Y, refCoorPos[1].Y);
                refLineTheta[1] = GetThetaColumn(refCoorPos[1].X, refCoorPos[3].X, refCoorPos[1].Y, refCoorPos[3].Y);
                refLineTheta[2] = GetThetaColumn(refCoorPos[3].X, refCoorPos[2].X, refCoorPos[3].Y, refCoorPos[2].Y);
                refLineTheta[3] = GetThetaColumn(refCoorPos[2].X, refCoorPos[0].X, refCoorPos[2].Y, refCoorPos[0].Y);

                tarLineTheta[0] = GetThetaColumn(tarCoorPos[0].X, tarCoorPos[1].X, tarCoorPos[0].Y, tarCoorPos[1].Y);
                tarLineTheta[1] = GetThetaColumn(tarCoorPos[1].X, tarCoorPos[3].X, tarCoorPos[1].Y, tarCoorPos[3].Y);
                tarLineTheta[2] = GetThetaColumn(tarCoorPos[3].X, tarCoorPos[2].X, tarCoorPos[3].Y, tarCoorPos[2].Y);
                tarLineTheta[3] = GetThetaColumn(tarCoorPos[2].X, tarCoorPos[0].X, tarCoorPos[2].Y, tarCoorPos[0].Y);

                // Get Theta Result
                switch (ThetaCalType)
                {
                    case ThetaCalType.UseShort_2L:
                        objRevPos.T = (objLineTheta[0] + objLineTheta[2]) * 0.5;
                        refRevPos.T = (refLineTheta[0] + refLineTheta[2]) * 0.5;
                        tarRevPos.T = (tarLineTheta[0] + tarLineTheta[2]) * 0.5;
                        break;

                    case ThetaCalType.UseLong_2L:
                        objRevPos.T = (objLineTheta[1] + objLineTheta[3]) * 0.5;
                        refRevPos.T = (refLineTheta[1] + refLineTheta[3]) * 0.5;
                        tarRevPos.T = (tarLineTheta[1] + tarLineTheta[3]) * 0.5;  
                        break;

                    case ThetaCalType.Use_4L:
                        objRevPos.T = (objLineTheta[0] + objLineTheta[1] + objLineTheta[2] + objLineTheta[3]) * 0.25;
                        refRevPos.T = (refLineTheta[0] + refLineTheta[1] + refLineTheta[2] + refLineTheta[3]) * 0.25;
                        tarRevPos.T = (tarLineTheta[0] + tarLineTheta[1] + tarLineTheta[2] + tarLineTheta[3]) * 0.25;
                        break;
                }

                // Get X, Y Result
                objRevPos.X = (objCoorPos[0].X + objCoorPos[1].X + objCoorPos[2].X + objCoorPos[3].X) / 4;
                objRevPos.Y = (objCoorPos[0].Y + objCoorPos[1].Y + objCoorPos[2].Y + objCoorPos[3].Y) / 4;

                refRevPos.X = (refCoorPos[0].X + refCoorPos[1].X + refCoorPos[2].X + refCoorPos[3].X) / 4;
                refRevPos.Y = (refCoorPos[0].Y + refCoorPos[1].Y + refCoorPos[2].Y + refCoorPos[3].Y) / 4;

                tarRevPos.X = (tarCoorPos[0].X + tarCoorPos[1].X + tarCoorPos[2].X + tarCoorPos[3].X) / 4;
                tarRevPos.Y = (tarCoorPos[0].Y + tarCoorPos[1].Y + tarCoorPos[2].Y + tarCoorPos[3].Y) / 4;

                #region Calc Length
                objLength[0] = GetLength(objCoorPos[0], objCoorPos[1]);
                objLength[1] = GetLength(objCoorPos[1], objCoorPos[3]);
                objLength[2] = GetLength(objCoorPos[3], objCoorPos[2]);
                objLength[3] = GetLength(objCoorPos[2], objCoorPos[0]);

                refLength[0] = GetLength(refCoorPos[0], refCoorPos[1]);
                refLength[1] = GetLength(refCoorPos[1], refCoorPos[3]);
                refLength[2] = GetLength(refCoorPos[3], refCoorPos[2]);
                refLength[3] = GetLength(refCoorPos[2], refCoorPos[0]);

                tarLength[0] = GetLength(tarCoorPos[0], tarCoorPos[1]);
                tarLength[1] = GetLength(tarCoorPos[1], tarCoorPos[3]);
                tarLength[2] = GetLength(tarCoorPos[3], tarCoorPos[2]);
                tarLength[3] = GetLength(tarCoorPos[2], tarCoorPos[0]);
                #endregion
            }
            #endregion

            #region Calc Rev Offset
            var alignOffset = CvtPLCIO.OffsetXYT;

            var Tarxyt = new XYT(tarRevPos.X, tarRevPos.Y, tarRevPos.T);
            var Refxyt = new XYT(refRevPos.X, refRevPos.Y, refRevPos.T);
            var Objxyt = new XYT(objRevPos.X, objRevPos.Y, objRevPos.T);
            var camTarxyt_Un = new XYT(tarRevPos.X, tarRevPos.Y, tarRevPos.T);

            revAlign = new XYT();
            revUnload = new XYT();
            double radT, DriftX, DriftY;

            if(calcType == CalcType.Center)
            {
                // Attach 위치 보정값 계산. 
                Tarxyt = ApplyTargetOffset(Tarxyt, alignOffset);
                radT = NormalizeTheta(Tarxyt.T - Objxyt.T);
                DriftX = Math.Cos(radT) * Objxyt.X - Math.Sin(radT) * Objxyt.Y;
                DriftY = Math.Sin(radT) * Objxyt.X + Math.Cos(radT) * Objxyt.Y;
                revAlign.X = Tarxyt.X - DriftX;
                revAlign.Y = Tarxyt.Y - DriftY;

                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else  //역방향
                    revAlign.T = (radT / rad) * -1;                
            }
            else if (calcType == CalcType.Reference)
            {
                // Attach 위치 보정값 계산. 
                Refxyt = ApplyTargetOffset(Refxyt, alignOffset);
                radT = NormalizeTheta(Refxyt.T - Objxyt.T);
                DriftX = Math.Cos(radT) * Objxyt.X - Math.Sin(radT) * Objxyt.Y;
                DriftY = Math.Sin(radT) * Objxyt.X + Math.Cos(radT) * Objxyt.Y;
                revAlign.X = Refxyt.X - DriftX;
                revAlign.Y = Refxyt.Y - DriftY;

                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = radT / rad;
                else //역방향
                    revAlign.T = (radT / rad) * -1;
            }

            // revUnload
            //radT = NormalizeTheta(camTarxyt_Un.T - Refxyt.T);
            //DriftX = Math.Cos(radT) * Refxyt.X - Math.Sin(radT) * Refxyt.Y;
            //DriftY = Math.Sin(radT) * Refxyt.X + Math.Cos(radT) * Refxyt.Y;
            //revUnload.X = camTarxyt_Un.X - DriftX;
            //revUnload.Y = camTarxyt_Un.Y - DriftY;
            //if (ThetaDirection == ThetaDirection.Normal)    //정방향
            //{
            //    revUnload.T = radT / rad;
            //}
            //else //역방향
            //{
            //    revUnload.T = (radT / rad) * -1;
            //}
            #endregion

            #region Confirm Result
            string strRst = string.Empty;
            // limit check
            var limit = new XYT(limitX, limitY, limitT);
            if (!ConfirmResult(revAlign, limit))
            {
                bResult = false;
                strRst = "LimitNG";
                for(int i = 0; i < 4; i++)
                {
                    rstData[i].DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                }
            }

            // length check
            bObjLength = new bool[4];
            //bResult = ConfirmLengthResult(tarLength, tarLengthSpec, LengthTor, bTarLength);
            if (!ConfirmLengthResult(objLength, objLengthSpec, LengthTor, bObjLength))
            {
                bResult = false;
                strRst = "LCheckNG";

                if (!bObjLength[0]) { rstData[0].Tool.ProcMode = ProcessMode.Manual; rstData[1].Tool.ProcMode = ProcessMode.Manual; }
                if (!bObjLength[1]) { rstData[1].Tool.ProcMode = ProcessMode.Manual; rstData[3].Tool.ProcMode = ProcessMode.Manual; }
                if (!bObjLength[2]) { rstData[3].Tool.ProcMode = ProcessMode.Manual; rstData[2].Tool.ProcMode = ProcessMode.Manual; }
                if (!bObjLength[3]) { rstData[2].Tool.ProcMode = ProcessMode.Manual; rstData[0].Tool.ProcMode = ProcessMode.Manual; }

                if (!bObjLength[0] || !bObjLength[1] || !bObjLength[2] || !bObjLength[3])
                {
                    errorCode = AlgoActionBase.Err_Length_Check;
                    for (int i = 0; i < 4; i++)
                    {
                        rstData[i].DisplayObj.Judgement = (uint)Judgement.L_Check;
                    }
                }
            }
            #endregion

            #region Result Data Update(DataGridView Insert)
            if(string.IsNullOrEmpty(strRst))
            {
                if (!bResult) strRst = "NG";
                else strRst = "OK";
            }

            AlgoRst = new Algo4PAlignResult
            {
                Name = name,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Result = strRst,

                RevX = Math.Round(revAlign.X, 3),
                RevY = Math.Round(revAlign.Y, 3),
                RevT = Math.Round(revAlign.T, 3),

                OffsetX = Math.Round(CvtPLCIO.Offset1, 3),
                OffsetY = Math.Round(CvtPLCIO.Offset2, 3),
                OffsetT = Math.Round(CvtPLCIO.Offset3, 3),

                TargetLength1 = Math.Round(tarLength[0], 3),
                TargetLength2 = Math.Round(tarLength[1], 3),
                TargetLength3 = Math.Round(tarLength[2], 3),
                TargetLength4 = Math.Round(tarLength[3], 3),

                ObjectLength1 = Math.Round(objLength[0], 3),
                ObjectLength2 = Math.Round(objLength[1], 3),
                ObjectLength3 = Math.Round(objLength[2], 3),
                ObjectLength4 = Math.Round(objLength[3], 3),

                TargetTheta1 = Math.Round(tarLineTheta[0], 3),
                TargetTheta2 = Math.Round(tarLineTheta[1], 3),
                TargetTheta3 = Math.Round(tarLineTheta[2], 3),
                TargetTheta4 = Math.Round(tarLineTheta[3], 3),

                ObjectTheta1 = Math.Round(objLineTheta[0], 3),
                ObjectTheta2 = Math.Round(objLineTheta[1], 3),
                ObjectTheta3 = Math.Round(objLineTheta[2], 3),
                ObjectTheta4 = Math.Round(objLineTheta[3], 3),

                Pnl_1st_px_Lx = Math.Round(rstData[0].OutputXYT.X, 3),
                Pnl_1st_px_Ly = Math.Round(rstData[0].OutputXYT.Y, 3),
                Pnl_1st_px_Rx = Math.Round(rstData[1].OutputXYT.X, 3),
                Pnl_1st_px_Ry = Math.Round(rstData[1].OutputXYT.Y, 3),
                Pnl_2nd_px_Lx = Math.Round(rstData[2].OutputXYT.X, 3),
                Pnl_2nd_px_Ly = Math.Round(rstData[2].OutputXYT.Y, 3),
                Pnl_2nd_px_Rx = Math.Round(rstData[3].OutputXYT.X, 3),
                Pnl_2nd_px_Ry = Math.Round(rstData[3].OutputXYT.Y, 3),

                Pnl_1st_rt_Lx = Math.Round(objRobotPos[0].X, 3),
                Pnl_1st_rt_Ly = Math.Round(objRobotPos[0].Y, 3),
                Pnl_1st_rt_Rx = Math.Round(objRobotPos[1].X, 3),
                Pnl_1st_rt_Ry = Math.Round(objRobotPos[1].Y, 3),
                Pnl_2nd_rt_Lx = Math.Round(objRobotPos[2].X, 3),
                Pnl_2nd_rt_Ly = Math.Round(objRobotPos[2].Y, 3),
                Pnl_2nd_rt_Rx = Math.Round(objRobotPos[3].X, 3),
                Pnl_2nd_rt_Ry = Math.Round(objRobotPos[3].Y, 3),

                ID = sourceID,
            };
            #endregion
            //SystemLogger.WriteAlignDBLog(name, AlgoRst);

            if(!bResult) return false;

            #region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, sourceID);
            #endregion
            return true;
        }

        void CheckParamSet(Algo4PAlignModelParams mParams)
        {
            if (mParams.ObjLength1 == null)
                mParams.ObjLength1 = new AlgoParam("ObjLength1", "mm", typeof(double), 0.0, "Obj Point0 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);
            if (mParams.ObjLength2 == null)
                mParams.ObjLength2 = new AlgoParam("ObjLength2", "mm", typeof(double), 0.0, "Obj Point1 <-> Obj Point2 Dist", (double)0.0, (double)1000.0);
            if (mParams.ObjLength3 == null)
                mParams.ObjLength3 = new AlgoParam("ObjLength3", "mm", typeof(double), 0.0, "Obj Point2 <-> Obj Point3 Dist", (double)0.0, (double)1000.0);
            if (mParams.ObjLength4 == null)
                mParams.ObjLength4 = new AlgoParam("ObjLength4", "mm", typeof(double), 0.0, "Obj Point3 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);
        }
        #endregion

        #region Public Method
        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }
            else
                return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objLengthRst"></param>
        /// <param name="objLengthRst"></param>
        /// <param name="objSpec"></param>
        /// <param name="objLengthSpec"></param>
        /// <param name="lengthTor"></param>
        /// <returns></returns>
        protected bool ConfirmLengthResult(double[] objLengthRst, double[] objLengthSpec, double lengthTor, bool[] LCheckNG)
        {
            bool bLCheckRst = true;
            for(int i = 0; i < objLengthRst.Length; i++)
            {
                bObjLength[i] = true;
                if (objLengthSpec[i] == 0.0 || lengthTor == 0.0) continue;

                if (!ConfirmSpecMinMax(objLengthRst[i], objLengthSpec[i] - lengthTor, objLengthSpec[i] + lengthTor))
                {
                    bObjLength[i] = false;
                    bLCheckRst = false;
                }
            }

            return bLCheckRst;
        }

        public void WriteVisionIO(object rev1, object rev2, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                    VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                    VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                    VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                    VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                    VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                    VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)(rev1 as XXYY).X1; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)(rev1 as XXYY).X2; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)(rev1 as XXYY).Y1; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)(rev1 as XXYY).Y2; IOs.Add(VisionValues["Tar#1_Pos#4"]);

                    VisionValues["Tar#2_Pos#1"].NextValue = (double)(rev2 as XXYY).X1; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)(rev2 as XXYY).X2; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)(rev2 as XXYY).Y1; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)(rev2 as XXYY).Y2; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                    break;
            }

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (cogDisp == null) return;
            Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }

        public void ImageSave(DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (rst == null || rst.Length == 0) return;
            for(int i = 0; i < rstData.Length; i++)
            {
                if(rstData[i] != null && rstData[i].DisplayObj != null)
                {
                    ImageSave(rstData[i].DisplayObj as CogDisplayObject, dateTime, rst, strPath);
                }
            }
        }

        #endregion
    }
}

