﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4PAlign
{
    [SerializableAttribute]
    public class Algo4PAlignResult : AlgoResultBase
    {
        #region [fiedls]     
        private string result;

        private double revX;
        private double revY;
        private double revT;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        private double dObjectLength1;
        private double dObjectLength2;
        private double dObjectLength3;
        private double dObjectLength4;

        private double dTargetLength1;
        private double dTargetLength2;
        private double dTargetLength3;
        private double dTargetLength4;

        private double dTargetTheta1;
        private double dTargetTheta2;
        private double dTargetTheta3;
        private double dTargetTheta4;

        private double dObjectTheta1;
        private double dObjectTheta2;
        private double dObjectTheta3;
        private double dObjectTheta4;

        private double dPnl_1st_px_Lx;
        private double dPnl_1st_px_Ly;
        private double dPnl_1st_px_Rx;
        private double dPnl_1st_px_Ry;
        private double dPnl_2nd_px_Lx;
        private double dPnl_2nd_px_Ly;
        private double dPnl_2nd_px_Rx;
        private double dPnl_2nd_px_Ry;

        private double dPnl_1st_rt_Lx;
        private double dPnl_1st_rt_Ly;
        private double dPnl_1st_rt_Rx;
        private double dPnl_1st_rt_Ry;
        private double dPnl_2nd_rt_Lx;
        private double dPnl_2nd_rt_Ly;
        private double dPnl_2nd_rt_Rx;
        private double dPnl_2nd_rt_Ry;

        #endregion

        #region [Properties]
        #region 기본 property
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        #endregion

        #region Judge Result
        public string Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        #endregion

        #region 최종 결과 값
        public double RevX
        {
            get { return revX; }
            set
            {
                if (value == revX) return;
                revX = value;
                this.OnPropertyChanged(nameof(RevX));
            }
        }

        public double RevY
        {
            get { return revY; }
            set
            {
                if (value == revY) return;
                revY = value;
                this.OnPropertyChanged(nameof(RevY));
            }
        }

        public double RevT
        {
            get { return revT; }
            set
            {
                if (value == revT) return;
                revT = value;
                this.OnPropertyChanged(nameof(RevT));
            }
        }
        #endregion

        #region offset Info
        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                if (value == offsetX) return;
                offsetX = value;

                OnPropertyChanged("OffsetX");
            }
        }

        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                if (value == offsetY) return;
                offsetY = value;

                OnPropertyChanged("OffsetY");
            }
        }

        public double OffsetT
        {
            get { return offsetT; }
            set
            {
                if (value == offsetT) return;
                offsetT = value;

                OnPropertyChanged("OffsetT");
            }
        }
        #endregion

        #region Length Info
        public double TargetLength1
        {
            get { return dTargetLength1; }
            set
            {
                if (value == dTargetLength1) return;
                dTargetLength1 = value;
                this.OnPropertyChanged(nameof(TargetLength1));
            }
        }
        public double TargetLength2
        {
            get { return dTargetLength2; }
            set
            {
                if (value == dTargetLength2) return;
                dTargetLength2 = value;
                this.OnPropertyChanged(nameof(TargetLength2));
            }
        }

        public double TargetLength3
        {
            get { return dTargetLength3; }
            set
            {
                if (value == dTargetLength3) return;
                dTargetLength3 = value;
                this.OnPropertyChanged(nameof(TargetLength3));
            }
        }

        public double TargetLength4
        {
            get { return dTargetLength4; }
            set
            {
                if (value == dTargetLength4) return;
                dTargetLength4 = value;
                this.OnPropertyChanged(nameof(TargetLength4));
            }
        }
        public double ObjectLength1
        {
            get { return dObjectLength1; }
            set
            {
                if (value == dObjectLength1) return;
                dObjectLength1 = value;
                this.OnPropertyChanged(nameof(ObjectLength1));
            }
        }
        public double ObjectLength2
        {
            get { return dObjectLength2; }
            set
            {
                if (value == dObjectLength2) return;
                dObjectLength2 = value;
                this.OnPropertyChanged(nameof(ObjectLength2));
            }
        }

        public double ObjectLength3
        {
            get { return dObjectLength3; }
            set
            {
                if (value == dObjectLength3) return;
                dObjectLength3 = value;
                this.OnPropertyChanged(nameof(ObjectLength3));
            }
        }

        public double ObjectLength4
        {
            get { return dObjectLength4; }
            set
            {
                if (value == dObjectLength4) return;
                dObjectLength4 = value;
                this.OnPropertyChanged(nameof(ObjectLength4));
            }
        }

        #endregion

        #region 각 성분의 Theta값
        public double TargetTheta1
        {
            get { return dTargetTheta1; }
            set
            {
                if (value == dTargetTheta1) return;
                dTargetTheta1 = value;
                this.OnPropertyChanged(nameof(TargetTheta1));
            }
        }

        public double TargetTheta2
        {
            get { return dTargetTheta2; }
            set
            {
                if (value == dTargetTheta2) return;
                dTargetTheta2 = value;
                this.OnPropertyChanged(nameof(TargetTheta2));
            }
        }

        public double TargetTheta3
        {
            get { return dTargetTheta3; }
            set
            {
                if (value == dTargetTheta3) return;
                dTargetTheta3 = value;
                this.OnPropertyChanged(nameof(TargetTheta3));
            }
        }

        public double TargetTheta4
        {
            get { return dTargetTheta4; }
            set
            {
                if (value == dTargetTheta4) return;
                dTargetTheta4 = value;
                this.OnPropertyChanged(nameof(TargetTheta4));
            }
        }
        public double ObjectTheta1
        {
            get { return dObjectTheta1; }
            set
            {
                if (value == dObjectTheta1) return;
                dObjectTheta1 = value;
                this.OnPropertyChanged(nameof(ObjectTheta1));
            }
        }

        public double ObjectTheta2
        {
            get { return dObjectTheta2; }
            set
            {
                if (value == dObjectTheta2) return;
                dObjectTheta2 = value;
                this.OnPropertyChanged(nameof(ObjectTheta2));
            }
        }

        public double ObjectTheta3
        {
            get { return dObjectTheta3; }
            set
            {
                if (value == dObjectTheta3) return;
                dObjectTheta3 = value;
                this.OnPropertyChanged(nameof(ObjectTheta3));
            }
        }

        public double ObjectTheta4
        {
            get { return dObjectTheta4; }
            set
            {
                if (value == dObjectTheta4) return;
                dObjectTheta4 = value;
                this.OnPropertyChanged(nameof(ObjectTheta4));
            }
        }
        #endregion

        #region pixel
        public double Pnl_1st_px_Lx
        {
            get { return dPnl_1st_px_Lx; }
            set { if (value == dPnl_1st_px_Lx) return; dPnl_1st_px_Lx = value; this.OnPropertyChanged(nameof(Pnl_1st_px_Lx)); }
        }
        public double Pnl_1st_px_Ly
        {
            get { return dPnl_1st_px_Ly; }
            set { if (value == dPnl_1st_px_Ly) return; dPnl_1st_px_Ly = value; this.OnPropertyChanged(nameof(Pnl_1st_px_Ly)); }
        }
        public double Pnl_1st_px_Rx
        {
            get { return dPnl_1st_px_Rx; }
            set { if (value == dPnl_1st_px_Rx) return; dPnl_1st_px_Rx = value; this.OnPropertyChanged(nameof(Pnl_1st_px_Rx)); }
        }
        public double Pnl_1st_px_Ry
        {
            get { return dPnl_1st_px_Ry; }
            set { if (value == dPnl_1st_px_Ry) return; dPnl_1st_px_Ry = value; this.OnPropertyChanged(nameof(Pnl_1st_px_Ry)); }
        }
        public double Pnl_2nd_px_Lx
        {
            get { return dPnl_2nd_px_Lx; }
            set { if (value == dPnl_2nd_px_Lx) return; dPnl_2nd_px_Lx = value; this.OnPropertyChanged(nameof(Pnl_2nd_px_Lx)); }
        }
        public double Pnl_2nd_px_Ly
        {
            get { return dPnl_2nd_px_Ly; }
            set { if (value == dPnl_2nd_px_Ly) return; dPnl_2nd_px_Ly = value; this.OnPropertyChanged(nameof(Pnl_2nd_px_Ly)); }
        }
        public double Pnl_2nd_px_Rx
        {
            get { return dPnl_2nd_px_Rx; }
            set { if (value == dPnl_2nd_px_Rx) return; dPnl_2nd_px_Rx = value; this.OnPropertyChanged(nameof(Pnl_2nd_px_Rx)); }
        }
        public double Pnl_2nd_px_Ry
        {
            get { return dPnl_2nd_px_Ry; }
            set { if (value == dPnl_2nd_px_Ry) return; dPnl_2nd_px_Ry = value; this.OnPropertyChanged(nameof(Pnl_2nd_px_Ry)); }
        }        
        #endregion

        #region robot
        public double Pnl_1st_rt_Lx
        {
            get { return dPnl_1st_rt_Lx; }
            set { if (value == dPnl_1st_rt_Lx) return; dPnl_1st_rt_Lx = value; this.OnPropertyChanged(nameof(Pnl_1st_rt_Lx)); }
        }
        public double Pnl_1st_rt_Ly
        {
            get { return dPnl_1st_rt_Ly; }
            set { if (value == dPnl_1st_rt_Ly) return; dPnl_1st_rt_Ly = value; this.OnPropertyChanged(nameof(Pnl_1st_rt_Ly)); }
        }
        public double Pnl_1st_rt_Rx
        {
            get { return dPnl_1st_rt_Rx; }
            set { if (value == dPnl_1st_rt_Rx) return; dPnl_1st_rt_Rx = value; this.OnPropertyChanged(nameof(Pnl_1st_rt_Rx)); }
        }
        public double Pnl_1st_rt_Ry
        {
            get { return dPnl_1st_rt_Ry; }
            set { if (value == dPnl_1st_rt_Ry) return; dPnl_1st_rt_Ry = value; this.OnPropertyChanged(nameof(Pnl_1st_rt_Ry)); }
        }
        public double Pnl_2nd_rt_Lx
        {
            get { return dPnl_2nd_rt_Lx; }
            set { if (value == dPnl_2nd_rt_Lx) return; dPnl_2nd_rt_Lx = value; this.OnPropertyChanged(nameof(Pnl_2nd_rt_Lx)); }
        }
        public double Pnl_2nd_rt_Ly
        {
            get { return dPnl_2nd_rt_Ly; }
            set { if (value == dPnl_2nd_rt_Ly) return; dPnl_2nd_rt_Ly = value; this.OnPropertyChanged(nameof(Pnl_2nd_rt_Ly)); }
        }
        public double Pnl_2nd_rt_Rx
        {
            get { return dPnl_2nd_rt_Rx; }
            set { if (value == dPnl_2nd_rt_Rx) return; dPnl_2nd_rt_Rx = value; this.OnPropertyChanged(nameof(Pnl_2nd_rt_Rx)); }
        }
        public double Pnl_2nd_rt_Ry
        {
            get { return dPnl_2nd_rt_Ry; }
            set { if (value == dPnl_2nd_rt_Ry) return; dPnl_2nd_rt_Ry = value; this.OnPropertyChanged(nameof(Pnl_2nd_rt_Ry)); }
        }

        #endregion



        #endregion
        public Algo4PAlignResult() : base() { }
        public override string ToString()
        {
            // 수정할 것,,
            return string.Format("");
        }

    }
}
