﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4PAlign_FLami
{
    [SerializableAttribute]
    public partial class Algo4PAlign_FLamiAction : Lami90AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private double objLengthUpper;
        [field: NonSerialized]
        private double objLengthLower;
        [field: NonSerialized]
        private double objLengthLeft;
        [field: NonSerialized]
        private double objLengthRight;

        #endregion

        #region [Properties]   
        public double ObjLengthUpper { get { return objLengthUpper; } set { if (objLengthUpper == value) return; objLengthUpper = value; this.OnPropertyChanged(nameof(ObjLengthUpper)); } }
        public double ObjLengthLower { get { return objLengthLower; } set { if (objLengthLower == value) return; objLengthLower = value; this.OnPropertyChanged(nameof(ObjLengthLower)); } }
        public double ObjLengthLeft { get { return objLengthLeft; } set { if (objLengthLeft == value) return; objLengthLeft = value; this.OnPropertyChanged(nameof(ObjLengthLeft)); } }
        public double ObjLengthRight { get { return objLengthRight; } set { if (objLengthRight == value) return; objLengthRight = value; this.OnPropertyChanged(nameof(ObjLengthRight)); } }

        #endregion

        #region [Construct]
        public Algo4PAlign_FLamiAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo4PAlign_FLamiInputParams();
            OutputParams = new Algo4PAlign_FLamiOutputParams();

            var obj = _object as Algo4PAlign_FLamiObject;
            obj.ModelParamType = typeof(Algo4PAlign_FLamiModelParams);
            var param = obj.CurParams as Algo4PAlign_FLamiModelParams;

            ChildSettingView = new AlignSetting();
            ChildSettingView.DataContext = this;
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as Algo4PAlign_FLamiObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                DateTime dateTime = DateTime.Now;

                if (!Obj.Run())
                {
                    //Length data 업데이트
                    ObjLengthUpper = Obj.objLength["Obj_Upper"];
                    ObjLengthLower = Obj.objLength["Obj_Lower"];
                    ObjLengthLeft = Obj.objLength["Obj_Left"];
                    ObjLengthRight = Obj.objLength["Obj_Right"];
                    // 기존값들 초기화 필요함.
                    SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                    return OccurError(Obj.ErrorCode);
                }
                else
                {
                    //Length data 업데이트
                    ObjLengthUpper = Obj.objLength["Obj_Upper"];
                    ObjLengthLower = Obj.objLength["Obj_Lower"];
                    ObjLengthLeft = Obj.objLength["Obj_Left"];
                    ObjLengthRight = Obj.objLength["Obj_Right"];

                    SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                    Obj.WriteVisionIO(Obj.RevAlign, Obj.RevUnload, "");

                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    //Obj.ImageSave(dateTime, "OK", name, Obj.SourceID);

                    Obj.AppendMessage(Name, "Caluration Complete");
                }

                #endregion
                StopTimer();
            }

            return End();
        }

        #endregion

        #region [Command]
        [field: NonSerialized]
        private DelegateCommand lengthSetCommand;
        public DelegateCommand LengthSetCommand
        {
            get
            {
                return lengthSetCommand = lengthSetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo4PAlign_FLamiModelParams;

                    tmp.ObjLengthLower_Offset.Value = Math.Round((double)tmp.ObjLengthLower.Value - ObjLengthLower, 4);
                    tmp.ObjLengthUpper_Offset.Value = Math.Round((double)tmp.ObjLengthUpper.Value - ObjLengthUpper, 4);
                    tmp.ObjLengthLeft_Offset.Value = Math.Round((double)tmp.ObjLengthLeft.Value - ObjLengthLeft, 4);
                    tmp.ObjLengthRight_Offset.Value = Math.Round((double)tmp.ObjLengthRight.Value - ObjLengthRight, 4);
                    Obj.UpdateTempValues();

                });

            }
        }
        #endregion

        #region [Override]
        public override void PrepareSave()
        {
            base.PrepareSave();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion

    }
}
