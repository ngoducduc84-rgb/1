﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo4PAlign_FLami
{
    [SerializableAttribute]
    class Algo4PAlign_FLamiInputParams : InputParams
    {
        #region Input P1, P2, P3, P4
        //public IPointResult P1 { get; set; }
        //public IPointResult P2 { get; set; }
        //public IPointResult P3 { get; set; }
        //public IPointResult P4 { get; set; }
        public object P1 { get; set; }
        public object P2 { get; set; }
        public object P3 { get; set; }
        public object P4 { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
