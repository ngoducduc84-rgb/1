﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo4PAlign_FLami
{
    [SerializableAttribute]

    public partial class Algo4PAlign_FLamiModelParams : AlgoParams
    {
        #region Lenght Center       
        private AlgoParam objLengthLower;
        private AlgoParam objLengthUpper;
        private AlgoParam objLengthLeft;
        private AlgoParam objLengthRight;
        private AlgoParam objLengthLower_Offset;
        private AlgoParam objLengthUpper_Offset;
        private AlgoParam objLengthLeft_Offset;
        private AlgoParam objLengthRight_Offset;

        #endregion

        #region Length Rage
        private AlgoParam lengthTor;
        #endregion

        #region Align Limit
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        #endregion

        public AlgoParam ObjLengthLower { get { return objLengthLower; } set { if (objLengthLower == value) return; objLengthLower = value; this.OnPropertyChanged(nameof(ObjLengthLower)); } }
        public AlgoParam ObjLengthUpper { get { return objLengthUpper; } set { if (objLengthUpper == value) return; objLengthUpper = value; this.OnPropertyChanged(nameof(ObjLengthUpper)); } }
        public AlgoParam ObjLengthLeft { get { return objLengthLeft; } set { if (objLengthLeft == value) return; objLengthLeft = value; this.OnPropertyChanged(nameof(ObjLengthLeft)); } }
        public AlgoParam ObjLengthRight { get { return objLengthRight; } set { if (objLengthRight == value) return; objLengthRight = value; this.OnPropertyChanged(nameof(ObjLengthRight)); } }

        public AlgoParam ObjLengthLeft_Offset { get { return objLengthLeft_Offset; } set { if (objLengthLeft_Offset == value) return; objLengthLeft_Offset = value; this.OnPropertyChanged(nameof(ObjLengthLeft_Offset)); } }
        public AlgoParam ObjLengthRight_Offset { get { return objLengthRight_Offset; } set { if (objLengthRight_Offset == value) return; objLengthRight_Offset = value; this.OnPropertyChanged(nameof(ObjLengthRight_Offset)); } }
        public AlgoParam ObjLengthUpper_Offset { get { return objLengthUpper_Offset; } set { if (objLengthUpper_Offset == value) return; objLengthUpper_Offset = value; this.OnPropertyChanged(nameof(ObjLengthUpper_Offset)); } }
        public AlgoParam ObjLengthLower_Offset { get { return objLengthLower_Offset; } set { if (objLengthLower_Offset == value) return; objLengthLower_Offset = value; this.OnPropertyChanged(nameof(ObjLengthLower_Offset)); } }


        public AlgoParam LengthTor { get { return lengthTor; } set { if (lengthTor == value) return; lengthTor = value; this.OnPropertyChanged(nameof(LengthTor)); } }

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }


        public Algo4PAlign_FLamiModelParams()
            : base()
        {
            ObjLengthLower = new AlgoParam("ObjLengthLower", "mm", typeof(double), 0.0, "Obj Point0 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);
            ObjLengthUpper = new AlgoParam("ObjLengthUpper", "mm", typeof(double), 0.0, "Obj Point1 <-> Obj Point2 Dist", (double)0.0, (double)1000.0);
            ObjLengthLeft = new AlgoParam("ObjLengthLeft", "mm", typeof(double), 0.0, "Obj Point2 <-> Obj Point3 Dist", (double)0.0, (double)1000.0);
            ObjLengthRight = new AlgoParam("ObjLengthRight", "mm", typeof(double), 0.0, "Obj Point3 <-> Obj Point0 Dist", (double)0.0, (double)1000.0);

            ObjLengthLower_Offset = new AlgoParam("ObjLengthLower_Offset", "mm", typeof(double), 0.0, "Obj Legnth Offset", (double)-100, (double)100);
            ObjLengthUpper_Offset = new AlgoParam("ObjLengthUpper_Offset", "mm", typeof(double), 0.0, "Obj Legnth Offset", (double)-100, (double)100);
            ObjLengthLeft_Offset = new AlgoParam("ObjLengthLeft_Offset", "mm", typeof(double), 0.0, "Obj Legnth Offset", (double)-100, (double)100);
            ObjLengthRight_Offset = new AlgoParam("ObjLengthRight_Offset", "mm", typeof(double), 0.0, "Obj Legnth Offset", (double)-100, (double)100);

            LengthTor = new AlgoParam("LengthTor", "mm", typeof(double), 0.0, "L Check Tolerance Value", (double)0.0, (double)1.0);

            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);
        }
    }

    [Serializable]
    public class LamiSub_PLCTable
    {
        #region [Feilds]
        //public string UnitNo { get; set; }
        //public int OptionNo { get; set; }

        public double Cur1_PosX1 { get; set; }
        public double Cur1_PosX2 { get; set; }
        public double Cur1_PosY1 { get; set; }
        public double Cur1_PosY2 { get; set; }
        public double Cur2_PosX1 { get; set; }
        public double Cur2_PosX2 { get; set; }
        public double Cur2_PosY1 { get; set; }
        public double Cur2_PosY2 { get; set; }

        public double CamPos1_X { get; set; }
        public double CamPos1_Y { get; set; }
        public double CamPos2_X { get; set; }
        public double CamPos2_Y { get; set; }

        public double Teach1_PosX1 { get; set; }
        public double Teach1_PosY1 { get; set; }
        public double Teach1_PosY2 { get; set; }
        public double Teach2_PosX1 { get; set; }
        public double Teach2_PosY1 { get; set; }
        public double Teach2_PosY2 { get; set; }
        public double Teach3_PosX1 { get; set; }
        public double Teach3_PosY1 { get; set; }
        public double Teach3_PosY2 { get; set; }

        public double Offset1_X { get; set; }
        public double Offset1_Y { get; set; }
        public double Offset1_T { get; set; }

        public double Offset2_X { get; set; }
        public double Offset2_Y { get; set; }
        public double Offset2_T { get; set; }
        public string SourceID { get; set; }
        #endregion

        #region [Construct]
        public LamiSub_PLCTable() { }
        #endregion
    }

}
