﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo4PAlign_FLami
{
    [SerializableAttribute]
    public partial class Algo4PAlign_FLamiObject : AlgoObjectBase
    {
        #region [Fields]
        private string p_CalData1;
        private string p_CalData2;
        private string p_CalData3;
        private string p_CalData4;
        [field: NonSerialized]
        LamiSub_PLCTable cvtPLCIO;
        [field: NonSerialized]
        LineCrossRstData[] lineRstData;
        [field: NonSerialized]
        MatchingRstData[] matchRstData;
        [field: NonSerialized]
        IPointResult[] rstData;
        [field: NonSerialized]
        CalDataObject[] calDataObj;
        [field: NonSerialized]
        XY[] objRobotPos;
        [field: NonSerialized]
        XY[] tarRobotPos;
        [field: NonSerialized]
        XY[] refRobotPos;
        [field: NonSerialized]
        XY[] objCoorPos;
        [field: NonSerialized]
        XY[] tarCoorPos;
        [field: NonSerialized]
        XY[] refCoorPos;
        [field: NonSerialized]
        public double[] objLineTheta;
        [field: NonSerialized]
        public double[] tarLineTheta;
        [field: NonSerialized]
        public double[] refLineTheta;
        [field: NonSerialized]
        public XYT objRevPos;
        [field: NonSerialized]
        public XYT tarRevPos;
        [field: NonSerialized]
        public XYT refRevPosT;
        [field: NonSerialized]
        public Dictionary<string, double> objLength;
        [field: NonSerialized]
        bool[] bLengthCheck;
        [field: NonSerialized]
        public Dictionary<string, double> objLengthSpec;
        [field: NonSerialized]
        public Dictionary<string, double> LengthOffset;
        #endregion

        #region etc
        private CalcType calcType;
        private ThetaCalType thetaCalType;
        private ThetaDirection thetaDirection;
        private Material mat;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;


        #endregion

        #region Align관련 Data
        [field: NonSerialized]
        XYT revAlign = new XYT();
        //[field: NonSerialized]
        XYT revUnload = new XYT();
        #endregion

        #region [properties]
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P1_CalData
        {
            get
            {
                return p_CalData1;
            }
            set
            {
                if (p_CalData1 == value) return; p_CalData1 = value; this.OnPropertyChanged(nameof(P1_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P2_CalData
        {
            get
            {
                return p_CalData2;
            }
            set
            {
                if (p_CalData2 == value) return; p_CalData2 = value; this.OnPropertyChanged(nameof(P2_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P3_CalData
        {
            get
            {
                return p_CalData3;
            }
            set
            {
                if (p_CalData3 == value) return; p_CalData3 = value; this.OnPropertyChanged(nameof(P3_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P4_CalData
        {
            get
            {
                return p_CalData4; 
            }
            set
            {
                if (p_CalData4 == value) return; p_CalData4 = value; this.OnPropertyChanged(nameof(P4_CalData));
            }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }
        public ThetaCalType ThetaCalType
        {
            get { return thetaCalType; }
            set { if (thetaCalType == value) return; thetaCalType = value; OnPropertyChanged("ThetaCalType"); }
        }
        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }
        public Material Mat
        {
            get { return mat; }
            set { if (mat == value) return; mat = value; this.OnPropertyChanged(nameof(Mat)); }
        }
        public ObservableCollection<string> CalDataList
        {
            get
            {
                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }

        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        #endregion

        //public bool[] ObjLength { get { return bObjLength; } }
        public bool[] TarLength { get { return bLengthCheck; } }

        #endregion

        #region[Construct]
        public Algo4PAlign_FLamiObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));
            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo4PAlign_FLamiModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private string lastResult;

        /// <summary>
        /// 
        /// </summary>
        void Initialize()
        {
            //p_CalData = new string[4];
            rstData = new IPointResult[4];
            calDataObj = new CalDataObject[4];
            objRobotPos = new XY[4];
            tarRobotPos = new XY[4];
            refRobotPos = new XY[4];
            objCoorPos = new XY[4];
            tarCoorPos = new XY[4];
            refCoorPos = new XY[4];
            objLineTheta = new double[4];
            tarLineTheta = new double[4];
            refLineTheta = new double[4];
            objRevPos = new XYT();
            tarRevPos = new XYT();
            refRevPosT = new XYT();
            bLengthCheck = new bool[4] { false, false, false, false };
            objLength = new Dictionary<string, double>();
            LengthOffset = new Dictionary<string, double>();
            objLengthSpec = new Dictionary<string, double>();
        }

    /// <summary>
    /// 
    /// </summary>
    void AssignPLCData()
        {
            UpdatePLCIOs();

            cvtPLCIO = new LamiSub_PLCTable();

            if (mat == Material.Material)
            {
                cvtPLCIO.Cur1_PosX1 = (double)PlcValues["CurrentPosX1_Mat"].CurValue;
                cvtPLCIO.Cur1_PosX2 = (double)PlcValues["CurrentPosX2_Mat"].CurValue;
                cvtPLCIO.Cur1_PosY1 = (double)PlcValues["CurrentPosY1_Mat"].CurValue;
                cvtPLCIO.Cur1_PosY2 = (double)PlcValues["CurrentPosY2_Mat"].CurValue;

                cvtPLCIO.CamPos1_X = (double)PlcValues["CurrentCamX_Mat"].CurValue;
                cvtPLCIO.CamPos1_Y = (double)PlcValues["CurrentCamY_Mat"].CurValue;

                cvtPLCIO.Teach1_PosX1 = (double)PlcValues["TeachPosCamX_Mat"].CurValue;
                cvtPLCIO.Teach1_PosY1 = (double)PlcValues["TeachPosCamY_1st_Mat"].CurValue;
                cvtPLCIO.Teach1_PosY2 = (double)PlcValues["TeachPosCamY_2nd_Mat"].CurValue;

                cvtPLCIO.Offset1_X = (double)PlcValues["OffsetX_Mat"].CurValue;
                cvtPLCIO.Offset1_Y = (double)PlcValues["OffsetY_Mat"].CurValue;
                cvtPLCIO.Offset1_T = (double)PlcValues["OffsetT_Mat"].CurValue;
            }
            else
            {
                cvtPLCIO.Cur1_PosX1 = (double)PlcValues["CurrentPosX1_Prd"].CurValue;
                cvtPLCIO.Cur1_PosX2 = (double)PlcValues["CurrentPosX2_Prd"].CurValue;
                cvtPLCIO.Cur1_PosY1 = (double)PlcValues["CurrentPosY1_Prd"].CurValue;
                cvtPLCIO.Cur1_PosY2 = (double)PlcValues["CurrentPosY2_Prd"].CurValue;

                cvtPLCIO.CamPos1_X = (double)PlcValues["CurrentCamX_Prd"].CurValue;
                cvtPLCIO.CamPos1_Y = (double)PlcValues["CurrentCamY_Prd"].CurValue;

                cvtPLCIO.Teach1_PosX1 = (double)PlcValues["TeachPosCamX_Prd"].CurValue;
                cvtPLCIO.Teach1_PosY1 = (double)PlcValues["TeachPosCamY_1st_Prd"].CurValue;
                cvtPLCIO.Teach1_PosY2 = (double)PlcValues["TeachPosCamY_2nd_Prd"].CurValue;

                cvtPLCIO.Offset1_X = (double)PlcValues["OffsetX_Prd"].CurValue;
                cvtPLCIO.Offset1_Y = (double)PlcValues["OffsetY_Prd"].CurValue;
                cvtPLCIO.Offset1_T = (double)PlcValues["OffsetT_Prd"].CurValue;
            }

            cvtPLCIO.SourceID = (string)PlcValues["CellID"].CurValue;
            SourceID = cvtPLCIO.SourceID;
        }


        // OCA

        //  0 ------------------ 1 
        //    l [Left]          l [Right]       : 1st
        //    |                 l    
        //    l                 l     ^         
        //    |                 |     |
        //    l                 l     |    theta, Length 계산 방향(반시계)
        //    l                 l     |    
        //    l                 l         
        //    l                 l         
        //    l [Left]          l [Right]       : 2nd
        //  2 ------------------ 3
        //        -------->   theta, Length 계산 방향(반시계)

        //            ↑ 투입 방향    
        //            ↑ 
        //            ↑ 



        // Panel

        //            ↓ 투입 방향    
        //            ↓ 
        //            ↓ 

        //  2 ------------------ 3 
        //    l [Left]          l [Right]       : 2nd
        //    |                 l    
        //    l                 l     ^         
        //    |                 |     |
        //    l                 l     |    theta, Length 계산 방향(반시계)
        //    l                 l     |    
        //    l                 l         
        //    l                 l         
        //    l [Left]          l [Right]       : 1st
        //  0 ------------------ 1
        //        -------->   theta, Length 계산 방향(반시계)



        private bool AlignCalc()
        {
            #region Initialize
            bool bResult = true;
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            Initialize();
            int iCnt = (int)calcType;
            #endregion

            #region PLC IOs Update
            AssignPLCData();
            #endregion

            //#region Mark Data Read& Confirm
            // 순서를 맞춰 준다.
            string[] pCalData = new string[4] { p_CalData1, p_CalData2, p_CalData3, p_CalData4 };

            // 귀찮아서 그냥 loop 돌린다.
            for (int i = 0; i < iCnt; i++)
            {
                #region InputData, RefData Set
                // Input Data Check
                if (!InputValues.ContainsKey("P" + (i + 1).ToString()))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                rstData[i] = InputValues["P" + (i + 1).ToString()] as IPointResult;

                if (rstData[i] == null)
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                // Ref Point 설정
                if (rstData[i].RefPoints == null)
                {
                    rstData[i].RefPoints = new List<XYT>();
                    rstData[i].RefPoints.Add(new XYT(0, 0, 0));
                }

                #region Coordinate Pos Calc & CalData Cofirm
                // Cal Data 설정
                calDataObj[i] = SystemObject_Common.GetObject(pCalData[i]) as CalDataObject;
                if (calDataObj[i] == null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    return false;
                }

                // Obj Robot Pos
                objRobotPos[i] = calDataObj[i].GetV2R(model, new XY(rstData[i].OutputXYT.X, rstData[i].OutputXYT.Y));
                // Camera Robot Pos
                tarRobotPos[i] = new XY(0, 0);
                // Reference Robot Pos
                refRobotPos[i] = calDataObj[i].GetV2R(model, new XY(rstData[i].RefPoints[0].X, rstData[i].RefPoints[0].Y));

                // Camera Coordination Pos
                objCoorPos[i] = objRobotPos[i] + calDataObj[i].GetRotateCenter(model);
                // Camera Coordination Pos
                tarCoorPos[i] = tarRobotPos[i] + calDataObj[i].GetRotateCenter(model);
                // Ref Coordination Robot Pos
                refCoorPos[i] = refRobotPos[i] + calDataObj[i].GetRotateCenter(model);
                #endregion
            }
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo4PAlign_FLamiModelParams;

            objLengthSpec.Add("Obj_Upper", (double)mParams.ObjLengthUpper.Value);
            objLengthSpec.Add("Obj_Lower", (double)mParams.ObjLengthLower.Value);
            objLengthSpec.Add("Obj_Left",  (double)mParams.ObjLengthLeft.Value);
            objLengthSpec.Add("Obj_Right", (double)mParams.ObjLengthRight.Value);

            LengthOffset.Add("Obj_Upper", (double)mParams.ObjLengthUpper_Offset.Value);
            LengthOffset.Add("Obj_Lower",  (double)mParams.ObjLengthLower_Offset.Value);
            LengthOffset.Add("Obj_Left", (double)mParams.ObjLengthLeft_Offset.Value);
            LengthOffset.Add("Obj_Right", (double)mParams.ObjLengthRight_Offset.Value);

            double LengthTor = (double)mParams.LengthTor.Value;

            double limitX = (double)mParams.LimitX.Value;
            double limitY = (double)mParams.LimitY.Value;
            double limitT = (double)mParams.LimitT.Value;
            #endregion

            #region Get X, Y, T
            if (calcType == CalcType.Obj_3P)
            {
                double objT = GetThetaColumn(objCoorPos[0].X, objCoorPos[0].Y, objCoorPos[1].X, objCoorPos[1].Y);
                double tarT = GetThetaColumn(tarCoorPos[0].X, tarCoorPos[0].Y, tarCoorPos[1].X, tarCoorPos[1].Y);

                objRevPos.X = (objCoorPos[2].X + objCoorPos[0].X) / 2;
                objRevPos.Y = (objCoorPos[2].Y + objCoorPos[0].Y) / 2;
                objRevPos.T = objT;

                tarRevPos.X = (tarCoorPos[2].X + tarCoorPos[0].X) / 2;
                tarRevPos.Y = (tarCoorPos[2].Y + tarCoorPos[0].Y) / 2;
                tarRevPos.T = tarT;

                #region Calc Length
                objLength.Add("Obj_Lower", GetLength(objCoorPos[0], objCoorPos[1]));
                objLength.Add("Obj_Left" , GetLength(objCoorPos[0], objCoorPos[2]));
                objLength.Add("Obj_Upper", GetLength(objCoorPos[0], objCoorPos[1]));
                objLength.Add("Obj_Right" ,GetLength(objCoorPos[0], objCoorPos[2]));
                #endregion


            }
            else
            {
                // Get Line Theta
                objLineTheta[0] = GetThetaColumn(objCoorPos[0].X, objCoorPos[1].X, objCoorPos[0].Y, objCoorPos[1].Y);
                objLineTheta[1] = GetThetaColumn(objCoorPos[1].X, objCoorPos[3].X, objCoorPos[1].Y, objCoorPos[3].Y);
                objLineTheta[2] = GetThetaColumn(objCoorPos[3].X, objCoorPos[2].X, objCoorPos[3].Y, objCoorPos[2].Y);
                objLineTheta[3] = GetThetaColumn(objCoorPos[2].X, objCoorPos[0].X, objCoorPos[2].Y, objCoorPos[0].Y);

                tarLineTheta[0] = GetThetaColumn(tarCoorPos[0].X, tarCoorPos[1].X, tarCoorPos[0].Y, tarCoorPos[1].Y);
                tarLineTheta[1] = GetThetaColumn(tarCoorPos[1].X, tarCoorPos[3].X, tarCoorPos[1].Y, tarCoorPos[3].Y);
                tarLineTheta[2] = GetThetaColumn(tarCoorPos[3].X, tarCoorPos[2].X, tarCoorPos[3].Y, tarCoorPos[2].Y);
                tarLineTheta[3] = GetThetaColumn(tarCoorPos[2].X, tarCoorPos[0].X, tarCoorPos[2].Y, tarCoorPos[0].Y);

                // Get Theta Result
                switch (ThetaCalType)
                {
                    case ThetaCalType.UseShort_2L:
                        objRevPos.T = (objLineTheta[0] + objLineTheta[2]) * 0.5;
                        tarRevPos.T = (tarLineTheta[0] + tarLineTheta[2]) * 0.5;
                        break;

                    case ThetaCalType.UseLong_2L:
                        objRevPos.T = (objLineTheta[1] + objLineTheta[3]) * 0.5; // DesignValue값을 변경 안하면 '무조건' 상/하 단변을 theta로 사용해야 함.    
                        tarRevPos.T = (tarLineTheta[1] + tarLineTheta[3]) * 0.5; // DesignValue값을 변경 안하면 '무조건' 상/하 단변을 theta로 사용해야 함.    
                        break;

                    case ThetaCalType.Use_4L:
                        objRevPos.T = (objLineTheta[0] + objLineTheta[1] + objLineTheta[2] + objLineTheta[3]) * 0.25;
                        tarRevPos.T = (tarLineTheta[0] + tarLineTheta[1] + tarLineTheta[2] + tarLineTheta[3]) * 0.25;
                        break;
                }

                // Get X, Y Result
                objRevPos.X = (objCoorPos[0].X + objCoorPos[1].X + objCoorPos[2].X + objCoorPos[3].X) / 4;
                objRevPos.Y = (objCoorPos[0].Y + objCoorPos[1].Y + objCoorPos[2].Y + objCoorPos[3].Y) / 4;

                tarRevPos.X = (tarCoorPos[0].X + tarCoorPos[1].X + tarCoorPos[2].X + tarCoorPos[3].X) / 4;
                tarRevPos.Y = (tarCoorPos[0].Y + tarCoorPos[1].Y + tarCoorPos[2].Y + tarCoorPos[3].Y) / 4;

                #region Calc Length
                objLength.Add("Obj_Lower", GetLength(objCoorPos[0], objCoorPos[1]));
                objLength.Add("Obj_Left", GetLength(objCoorPos[0], objCoorPos[2]));
                objLength.Add("Obj_Upper", GetLength(objCoorPos[2], objCoorPos[3]));
                objLength.Add("Obj_Right", GetLength(objCoorPos[1], objCoorPos[3]));
                #endregion


            }
            #endregion

            #region Calc Rev Offset
            var alignOffset = new XYT(cvtPLCIO.Offset1_X, cvtPLCIO.Offset1_Y, cvtPLCIO.Offset1_T);

            var camTarxyt = new XYT(tarRevPos.X, tarRevPos.Y, tarRevPos.T);
            var pnlObjxyt = new XYT(objRevPos.X, objRevPos.Y, objRevPos.T);
            var camTarxyt_Un = new XYT(tarRevPos.X, tarRevPos.Y, tarRevPos.T);

            revAlign = new XYT();
            revUnload = new XYT();
            double radT, DriftX, DriftY;

            // Attach 위치 보정값 계산. 
            camTarxyt = ApplyTargetOffset(camTarxyt, alignOffset);
            radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
            DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
            DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
            revAlign.X = camTarxyt.X - DriftX;
            revAlign.Y = camTarxyt.Y - DriftY;
            if (ThetaDirection == ThetaDirection.Normal)    //정방향
            {
                revAlign.T = radT / rad;
            }
            else //역방향
            {
                revAlign.T = (radT / rad) * -1;
            }

            // revUnload
            radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
            DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
            DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
            revUnload.X = camTarxyt_Un.X - DriftX;
            revUnload.Y = camTarxyt_Un.Y - DriftY;
            if (ThetaDirection == ThetaDirection.Normal)    //정방향
            {
                revUnload.T = radT / rad;
            }
            else //역방향
            {
                revUnload.T = (radT / rad) * -1;
            }

            #endregion

            #region Calc Length & Check
            string strRst = string.Empty;

            // length check 
            //bResult = ConfirmLengthResult(objLength, objLengthSpec,  LengthTor, ref bLengthCheck);
            bLengthCheck[0] = GetLCheck(objLength["Obj_Lower"] + LengthOffset["Obj_Lower"], objLengthSpec["Obj_Lower"], LengthTor);
            bLengthCheck[1] = GetLCheck(objLength["Obj_Right"] + LengthOffset["Obj_Right"], objLengthSpec["Obj_Right"], LengthTor);
            bLengthCheck[2] = GetLCheck(objLength["Obj_Upper"] + LengthOffset["Obj_Upper"], objLengthSpec["Obj_Upper"], LengthTor);
            bLengthCheck[3] = GetLCheck(objLength["Obj_Left"] + LengthOffset["Obj_Left"], objLengthSpec["Obj_Left"], LengthTor);

            

            if (!bLengthCheck[0]) { rstData[0].Tool.ProcMode = ProcessMode.Manual; rstData[1].Tool.ProcMode = ProcessMode.Manual; }
            if (!bLengthCheck[1]) { rstData[1].Tool.ProcMode = ProcessMode.Manual; rstData[3].Tool.ProcMode = ProcessMode.Manual; }
            if (!bLengthCheck[2]) { rstData[3].Tool.ProcMode = ProcessMode.Manual; rstData[2].Tool.ProcMode = ProcessMode.Manual; }
            if (!bLengthCheck[3]) { rstData[2].Tool.ProcMode = ProcessMode.Manual; rstData[0].Tool.ProcMode = ProcessMode.Manual; }

            if (!bLengthCheck[0] || !bLengthCheck[1] || !bLengthCheck[2] || !bLengthCheck[3])
            {
                errorCode = AlgoActionBase.Err_Lower_Length_Check;
                SetLCheckJudgeStatus();
                bResult = false;
                strRst = "LCheckNG";
            }
            #endregion

            #region Confirm Result
            
            // limit check
            var limit = new XYT(limitX, limitY, limitT);
            if(!ConfirmResult(revAlign, limit))
            {
                SetLimtJudgeStatus();
                bResult = false;
                strRst = "LimitNG";
            }
            #endregion

            #region Result Data Update(DataGridView Insert)
            if (string.IsNullOrEmpty(strRst))
            {
                if (!bResult) strRst = "NG";
                else strRst = "OK";
            }

            AlgoRst = new Algo4PAlign_FLamiResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Result = strRst,

                RevX = Math.Round(revAlign.X, 3),
                RevY = Math.Round(revAlign.Y, 3),
                RevT = Math.Round(revAlign.T, 3),

                OffsetX = Math.Round(cvtPLCIO.Offset1_X, 3),
                OffsetY = Math.Round(cvtPLCIO.Offset1_Y, 3),
                OffsetT = Math.Round(cvtPLCIO.Offset1_T, 3),

                ObjectLengthLower = Math.Round(objLength["Obj_Lower"] + LengthOffset["Obj_Lower"], 3),
                ObjectLengthUpper = Math.Round(objLength["Obj_Upper"] + LengthOffset["Obj_Upper"], 3),
                ObjectLengthLeft = Math.Round(objLength["Obj_Left"] + LengthOffset["Obj_Left"], 3),
                ObjectLengthRight = Math.Round(objLength["Obj_Right"] + LengthOffset["Obj_Right"], 3),

                TargetTheta1 = Math.Round(tarLineTheta[0], 3),
                TargetTheta2 = Math.Round(tarLineTheta[1], 3),
                TargetTheta3 = Math.Round(tarLineTheta[2], 3),
                TargetTheta4 = Math.Round(tarLineTheta[3], 3),

                ObjectTheta1 = Math.Round(objLineTheta[0], 3),
                ObjectTheta2 = Math.Round(objLineTheta[1], 3),
                ObjectTheta3 = Math.Round(objLineTheta[2], 3),
                ObjectTheta4 = Math.Round(objLineTheta[3], 3),
            };
            #endregion
            //SystemLogger.WriteAlignDBLog(name, AlgoRst);

            if(!bResult)
            {
                return false;
            }

            #region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, sourceID);
            #endregion
            return true;
        }
        #endregion

        #region Public Method
        public void SetLCheckJudgeStatus()
        {
            var Obj_Lower = InputValues["P1"] as IPointResult;
            var Obj_Right = InputValues["P2"] as IPointResult;
            var Obj_Upper = InputValues["P3"] as IPointResult;
            var Obj_Left = InputValues["P4"] as IPointResult;

            System.Threading.Thread.Sleep(500);

            Obj_Lower.DisplayObj.Judgement = (uint)Judgement.L_Check;
            Obj_Right.DisplayObj.Judgement = (uint)Judgement.L_Check;
            Obj_Upper.DisplayObj.Judgement = (uint)Judgement.L_Check;
            Obj_Left.DisplayObj.Judgement = (uint)Judgement.L_Check;
        }

        public void SetLimtJudgeStatus()
        {
            var Obj_Lower = InputValues["P1"] as IPointResult;
            var Obj_Right = InputValues["P2"] as IPointResult;
            var Obj_Upper = InputValues["P3"] as IPointResult;
            var Obj_Left = InputValues["P4"] as IPointResult;

            System.Threading.Thread.Sleep(500);

            Obj_Lower.DisplayObj.Judgement  = (uint)Judgement.Tor_Exceed;
            Obj_Right.DisplayObj.Judgement  = (uint)Judgement.Tor_Exceed;
            Obj_Upper.DisplayObj.Judgement  = (uint)Judgement.Tor_Exceed;
            Obj_Left.DisplayObj.Judgement   = (uint)Judgement.Tor_Exceed;
        }

        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = Lami90AlgoActionBase.Err_Limit_Over;
                return false;
            }
            else
                return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objLength"></param>
        /// <param name="tarLength"></param>
        /// <param name="objSpec"></param>
        /// <param name="tarSpec"></param>
        /// <param name="lengthTor"></param>
        /// <returns></returns>
        protected bool ConfirmLengthResult(Dictionary<string, double> objLength, Dictionary<string, double> objSpec, double lengthTor, ref bool[] LCheckNG)
        {
            bool bLCheckRst = true;
            if (objLength["Obj_Lower"] > objSpec["Obj_Lower"] + lengthTor || objLength["Obj_Lower"] < objSpec["Obj_Lower"] - lengthTor)
            {
                LCheckNG[0] = false;
                bLCheckRst = false;
            }
            if (objLength["Obj_Right"] > objSpec["Obj_Right"] + lengthTor || objLength["Obj_Right"] < objSpec["Obj_Right"] - lengthTor)
            {
                LCheckNG[1] = false;
                bLCheckRst = false;
            }
            if (objLength["Obj_Upper"] > objSpec["Obj_Upper"] + lengthTor || objLength["Obj_Upper"] < objSpec["Obj_Upper"] - lengthTor)
            {
                LCheckNG[2] = false;
                bLCheckRst = false;
            }
            if (objLength["Obj_Left"]  > objSpec["Obj_Left"]  + lengthTor || objLength["Obj_Left"]  < objSpec["Obj_Left"]  - lengthTor)
            {
                LCheckNG[3] = false;
                bLCheckRst = false;
            }
            
            return bLCheckRst;
        }

        public void WriteVisionIO(object rev1, object rev2, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:

                    if (mat == Material.Material)
                    {
                        VisionValues["TargetPosX1_Mat"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["TargetPosX1_Mat"]);
                        VisionValues["TargetPosX2_Mat"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["TargetPosX2_Mat"]);
                        VisionValues["TargetPosY1_Mat"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["TargetPosY1_Mat"]);
                    }
                    else
                    {
                        VisionValues["TargetPosX1_Prd"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["TargetPosX1_Prd"]);
                        VisionValues["TargetPosX2_Prd"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["TargetPosX2_Prd"]);
                        VisionValues["TargetPosY1_Prd"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["TargetPosY1_Prd"]);

                        VisionValues["PureRevX"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["PureRevX"]);
                        VisionValues["PureRevY"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["PureRevY"]);
                        VisionValues["PureRevT"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["PureRevT"]);
                    }
                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    break;

            }

            // write fdc data : 2019.10.19, khoon, system qual 대응
            // rev xyt
            var result = AlgoRst as Algo4PAlign_FLamiResult;
            if (result != null)
            {
                if (mat == Material.Material)
                {
                    VisionValues["FinalTargetX_Mat"].NextValue = result.RevX; IOs.Add(VisionValues["FinalTargetX_Mat"]);
                    VisionValues["FinalTargetY_Mat"].NextValue = result.RevY; IOs.Add(VisionValues["FinalTargetY_Mat"]);
                    VisionValues["FinalTargetT_Mat"].NextValue = result.RevT; IOs.Add(VisionValues["FinalTargetT_Mat"]);

                    VisionValues["FDC_TargetPosX_Mat"].NextValue = result.RevX; IOs.Add(VisionValues["FDC_TargetPosX_Mat"]);
                    VisionValues["FDC_TargetPosY_Mat"].NextValue = result.RevY; IOs.Add(VisionValues["FDC_TargetPosY_Mat"]);
                    VisionValues["FDC_TargetPosT_Mat"].NextValue = result.RevT; IOs.Add(VisionValues["FDC_TargetPosT_Mat"]);

                    VisionValues["FDC_ResultRevX_Mat"].NextValue = result.RevX; IOs.Add(VisionValues["FDC_ResultRevX_Mat"]);
                    VisionValues["FDC_ResultRevY_Mat"].NextValue = result.RevY; IOs.Add(VisionValues["FDC_ResultRevY_Mat"]);
                    VisionValues["FDC_ResultRevT_Mat"].NextValue = result.RevT; IOs.Add(VisionValues["FDC_ResultRevT_Mat"]);
                } 
                else
                {
                    VisionValues["FinalTargetX_Prd"].NextValue = result.RevX; IOs.Add(VisionValues["FinalTargetX_Prd"]);
                    VisionValues["FinalTargetY_Prd"].NextValue = result.RevY; IOs.Add(VisionValues["FinalTargetY_Prd"]);
                    VisionValues["FinalTargetT_Prd"].NextValue = result.RevT; IOs.Add(VisionValues["FinalTargetT_Prd"]);

                    VisionValues["FDC_TargetPosX_Prd"].NextValue = result.RevX; IOs.Add(VisionValues["FDC_TargetPosX_Prd"]);
                    VisionValues["FDC_TargetPosY_Prd"].NextValue = result.RevY; IOs.Add(VisionValues["FDC_TargetPosY_Prd"]);
                    VisionValues["FDC_TargetPosT_Prd"].NextValue = result.RevT; IOs.Add(VisionValues["FDC_TargetPosT_Prd"]);

                    VisionValues["FDC_ResultRevX_Prd"].NextValue = result.RevX; IOs.Add(VisionValues["FDC_ResultRevX_Prd"]);
                    VisionValues["FDC_ResultRevY_Prd"].NextValue = result.RevY; IOs.Add(VisionValues["FDC_ResultRevY_Prd"]);
                    VisionValues["FDC_ResultRevT_Prd"].NextValue = result.RevT; IOs.Add(VisionValues["FDC_ResultRevT_Prd"]);
                }

                VisionValues["InspectRevX"].NextValue = result.RevX; IOs.Add(VisionValues["InspectRevX"]);
                VisionValues["InspectRevY"].NextValue = result.RevY; IOs.Add(VisionValues["InspectRevY"]);
                VisionValues["InspectRevT"].NextValue = result.RevT; IOs.Add(VisionValues["InspectRevT"]);

                VisionValues["InspectRev_X"].NextValue = result.RevX; IOs.Add(VisionValues["InspectRev_X"]);
                VisionValues["InspectRev_Y"].NextValue = result.RevY; IOs.Add(VisionValues["InspectRev_Y"]);
                VisionValues["InspectRev_T"].NextValue = result.RevT; IOs.Add(VisionValues["InspectRev_T"]);
            }

            // score
            if (mat == Material.Material)
            {
                VisionValues["FDC_Score_P1_Mat"].NextValue = (InputValues["P1"] as IPointResult).Score; IOs.Add(VisionValues["FDC_Score_P1_Mat"]);
                VisionValues["FDC_Score_P2_Mat"].NextValue = (InputValues["P2"] as IPointResult).Score; IOs.Add(VisionValues["FDC_Score_P2_Mat"]);
                VisionValues["FDC_Score_P3_Mat"].NextValue = (InputValues["P3"] as IPointResult).Score; IOs.Add(VisionValues["FDC_Score_P3_Mat"]);
                VisionValues["FDC_Score_P4_Mat"].NextValue = (InputValues["P4"] as IPointResult).Score; IOs.Add(VisionValues["FDC_Score_P4_Mat"]);
            }
            else
            {
                VisionValues["FDC_Score_P1_Prd"].NextValue = (InputValues["P1"] as IPointResult).Score; IOs.Add(VisionValues["FDC_Score_P1_Prd"]);
                VisionValues["FDC_Score_P2_Prd"].NextValue = (InputValues["P2"] as IPointResult).Score; IOs.Add(VisionValues["FDC_Score_P2_Prd"]);
                VisionValues["FDC_Score_P3_Prd"].NextValue = (InputValues["P3"] as IPointResult).Score; IOs.Add(VisionValues["FDC_Score_P3_Prd"]);
                VisionValues["FDC_Score_P4_Prd"].NextValue = (InputValues["P4"] as IPointResult).Score; IOs.Add(VisionValues["FDC_Score_P4_Prd"]);
            }
               

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (cogDisp == null) return;
            Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }

        public void ImageSave(DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (rst == null || rst.Length == 0) return;
            for(int i = 0; i < rstData.Length; i++)
            {
                if(rstData[i] != null && rstData[i].DisplayObj != null)
                {
                    ImageSave(rstData[i].DisplayObj as CogDisplayObject, dateTime, rst, strPath);
                }
            }
        }

        protected bool GetLCheck(double Length, double LengSpec, double LengthTor)
        {
            if (LengSpec == 0.0 || LengthTor == 0.0) return true;

            if (Length > (LengSpec + LengthTor) || Length < (LengSpec - LengthTor))
            {
                errorCode = AlgoActionBase.Err_Length_Check;
                return false;
            }
            return true;
        }

        #endregion
    }
}

