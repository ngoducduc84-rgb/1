﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4PAlign_FLami
{
    [SerializableAttribute]
    public class Algo4PAlign_FLamiResult : AlgoResultBase
    {
        #region [fiedls]     
        private string result;

        private double revX;
        private double revY;
        private double revT;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        private double dObjectLengthLower;
        private double dObjectLengthUpper;
        private double dObjectLengthLeft;
        private double dObjectLengthRight;

        private double dTargetLength1;
        private double dTargetLength2;
        private double dTargetLength3;
        private double dTargetLength4;

        private double dTargetTheta1;
        private double dTargetTheta2;
        private double dTargetTheta3;
        private double dTargetTheta4;

        private double dObjectTheta1;
        private double dObjectTheta2;
        private double dObjectTheta3;
        private double dObjectTheta4;

        /*
        private double dFix_1st_rt_Lx;
        private double dFix_1st_rt_Ly;
        private double dFix_1st_rt_Rx;
        private double dFix_1st_rt_Ry;
        private double dFix_2nd_rt_Lx;
        private double dFix_2nd_rt_Ly;
        private double dFix_2nd_rt_Rx;
        private double dFix_2nd_rt_Ry;

        private double dObj_1st_rt_Lx;
        private double dObj_1st_rt_Ly;
        private double dObj_1st_rt_Rx;
        private double dObj_1st_rt_Ry;
        private double dObj_2nd_rt_Lx;
        private double dObj_2nd_rt_Ly;
        private double dObj_2nd_rt_Rx;
        private double dObj_2nd_rt_Ry;

        private double dTar_1st_rt_Lx;
        private double dTar_1st_rt_Ly;
        private double dTar_1st_rt_Rx;
        private double dTar_1st_rt_Ry;
        private double dTar_2nd_rt_Lx;
        private double dTar_2nd_rt_Ly;
        private double dTar_2nd_rt_Rx;
        private double dTar_2nd_rt_Ry;
        */
        #endregion

        #region [Properties]
        #region 기본 property
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        #endregion

        #region Judge Result
        public string Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        #endregion

        #region 최종 결과 값
        public double RevX
        {
            get { return revX; }
            set
            {
                if (value == revX) return;
                revX = value;
                this.OnPropertyChanged(nameof(RevX));
            }
        }

        public double RevY
        {
            get { return revY; }
            set
            {
                if (value == revY) return;
                revY = value;
                this.OnPropertyChanged(nameof(RevY));
            }
        }

        public double RevT
        {
            get { return revT; }
            set
            {
                if (value == revT) return;
                revT = value;
                this.OnPropertyChanged(nameof(RevT));
            }
        }
        #endregion

        #region offset Info
        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                if (value == offsetX) return;
                offsetX = value;

                OnPropertyChanged("OffsetX");
            }
        }

        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                if (value == offsetY) return;
                offsetY = value;

                OnPropertyChanged("OffsetY");
            }
        }

        public double OffsetT
        {
            get { return offsetT; }
            set
            {
                if (value == offsetT) return;
                offsetT = value;

                OnPropertyChanged("OffsetT");
            }
        }
        #endregion

        #region Length Info
        public double ObjectLengthLower
        {
            get { return dObjectLengthLower; }
            set
            {
                if (value == dObjectLengthLower) return;
                dObjectLengthLower = value;
                this.OnPropertyChanged(nameof(ObjectLengthLower));
            }
        }
        public double ObjectLengthUpper
        {
            get { return dObjectLengthUpper; }
            set
            {
                if (value == dObjectLengthUpper) return;
                dObjectLengthUpper = value;
                this.OnPropertyChanged(nameof(ObjectLengthUpper));
            }
        }

        public double ObjectLengthLeft
        {
            get { return dObjectLengthLeft; }
            set
            {
                if (value == dObjectLengthLeft) return;
                dObjectLengthLeft = value;
                this.OnPropertyChanged(nameof(ObjectLengthLeft));
            }
        }

        public double ObjectLengthRight
        {
            get { return dObjectLengthRight; }
            set
            {
                if (value == dObjectLengthRight) return;
                dObjectLengthRight = value;
                this.OnPropertyChanged(nameof(ObjectLengthRight));
            }
        }

        #endregion

        #region 각 성분의 Theta값
        public double TargetTheta1
        {
            get { return dTargetTheta1; }
            set
            {
                if (value == dTargetTheta1) return;
                dTargetTheta1 = value;
                this.OnPropertyChanged(nameof(TargetTheta1));
            }
        }

        public double TargetTheta2
        {
            get { return dTargetTheta2; }
            set
            {
                if (value == dTargetTheta2) return;
                dTargetTheta2 = value;
                this.OnPropertyChanged(nameof(TargetTheta2));
            }
        }

        public double TargetTheta3
        {
            get { return dTargetTheta3; }
            set
            {
                if (value == dTargetTheta3) return;
                dTargetTheta3 = value;
                this.OnPropertyChanged(nameof(TargetTheta3));
            }
        }

        public double TargetTheta4
        {
            get { return dTargetTheta4; }
            set
            {
                if (value == dTargetTheta4) return;
                dTargetTheta4 = value;
                this.OnPropertyChanged(nameof(TargetTheta4));
            }
        }
        public double ObjectTheta1
        {
            get { return dObjectTheta1; }
            set
            {
                if (value == dObjectTheta1) return;
                dObjectTheta1 = value;
                this.OnPropertyChanged(nameof(ObjectTheta1));
            }
        }

        public double ObjectTheta2
        {
            get { return dObjectTheta2; }
            set
            {
                if (value == dObjectTheta2) return;
                dObjectTheta2 = value;
                this.OnPropertyChanged(nameof(ObjectTheta2));
            }
        }

        public double ObjectTheta3
        {
            get { return dObjectTheta3; }
            set
            {
                if (value == dObjectTheta3) return;
                dObjectTheta3 = value;
                this.OnPropertyChanged(nameof(ObjectTheta3));
            }
        }

        public double ObjectTheta4
        {
            get { return dObjectTheta4; }
            set
            {
                if (value == dObjectTheta4) return;
                dObjectTheta4 = value;
                this.OnPropertyChanged(nameof(ObjectTheta4));
            }
        }
        #endregion

        /*
        #region robot Data
        public double Obj_1st_rt_Lx
        {
            get { return dObj_1st_rt_Lx; }
            set { if (value == dObj_1st_rt_Lx) return; dObj_1st_rt_Lx = value; this.OnPropertyChanged(nameof(Obj_1st_rt_Lx)); }
        }
        public double Obj_1st_rt_Ly
        {
            get { return dObj_1st_rt_Ly; }
            set { if (value == dObj_1st_rt_Ly) return; dObj_1st_rt_Ly = value; this.OnPropertyChanged(nameof(Obj_1st_rt_Ly)); }
        }
        public double Obj_1st_rt_Rx
        {
            get { return dObj_1st_rt_Rx; }
            set { if (value == dObj_1st_rt_Rx) return; dObj_1st_rt_Rx = value; this.OnPropertyChanged(nameof(Obj_1st_rt_Rx)); }
        }
        public double Obj_1st_rt_Ry
        {
            get { return dObj_1st_rt_Ry; }
            set { if (value == dObj_1st_rt_Ry) return; dObj_1st_rt_Ry = value; this.OnPropertyChanged(nameof(Obj_1st_rt_Ry)); }
        }
        public double Obj_2nd_rt_Lx
        {
            get { return dObj_2nd_rt_Lx; }
            set { if (value == dObj_2nd_rt_Lx) return; dObj_2nd_rt_Lx = value; this.OnPropertyChanged(nameof(Obj_2nd_rt_Lx)); }
        }
        public double Obj_2nd_rt_Ly
        {
            get { return dObj_2nd_rt_Ly; }
            set { if (value == dObj_2nd_rt_Ly) return; dObj_2nd_rt_Ly = value; this.OnPropertyChanged(nameof(Obj_2nd_rt_Ly)); }
        }
        public double Obj_2nd_rt_Rx
        {
            get { return dObj_2nd_rt_Rx; }
            set { if (value == dObj_2nd_rt_Rx) return; dObj_2nd_rt_Rx = value; this.OnPropertyChanged(nameof(Obj_2nd_rt_Rx)); }
        }
        public double Obj_2nd_rt_Ry
        {
            get { return dObj_2nd_rt_Ry; }
            set { if (value == dObj_2nd_rt_Ry) return; dObj_2nd_rt_Ry = value; this.OnPropertyChanged(nameof(Obj_2nd_rt_Ry)); }
        }

        public double Tar_1st_rt_Lx
        {
            get { return dTar_1st_rt_Lx; }
            set { if (value == dTar_1st_rt_Lx) return; dTar_1st_rt_Lx = value; this.OnPropertyChanged(nameof(Tar_1st_rt_Lx)); }
        }
        public double Tar_1st_rt_Ly
        {
            get { return dTar_1st_rt_Ly; }
            set { if (value == dTar_1st_rt_Ly) return; dTar_1st_rt_Ly = value; this.OnPropertyChanged(nameof(Tar_1st_rt_Ly)); }
        }
        public double Tar_1st_rt_Rx
        {
            get { return dTar_1st_rt_Rx; }
            set { if (value == dTar_1st_rt_Rx) return; dTar_1st_rt_Rx = value; this.OnPropertyChanged(nameof(Tar_1st_rt_Rx)); }
        }
        public double Tar_1st_rt_Ry
        {
            get { return dTar_1st_rt_Ry; }
            set { if (value == dTar_1st_rt_Ry) return; dTar_1st_rt_Ry = value; this.OnPropertyChanged(nameof(Tar_1st_rt_Ry)); }
        }
        public double Tar_2nd_rt_Lx
        {
            get { return dTar_2nd_rt_Lx; }
            set { if (value == dTar_2nd_rt_Lx) return; dTar_2nd_rt_Lx = value; this.OnPropertyChanged(nameof(Tar_2nd_rt_Lx)); }
        }
        public double Tar_2nd_rt_Ly
        {
            get { return dTar_2nd_rt_Ly; }
            set { if (value == dTar_2nd_rt_Ly) return; dTar_2nd_rt_Ly = value; this.OnPropertyChanged(nameof(Tar_2nd_rt_Ly)); }
        }
        public double Tar_2nd_rt_Rx
        {
            get { return dTar_2nd_rt_Rx; }
            set { if (value == dTar_2nd_rt_Rx) return; dTar_2nd_rt_Rx = value; this.OnPropertyChanged(nameof(Tar_2nd_rt_Rx)); }
        }
        public double Tar_2nd_rt_Ry
        {
            get { return dTar_2nd_rt_Ry; }
            set { if (value == dTar_2nd_rt_Ry) return; dTar_2nd_rt_Ry = value; this.OnPropertyChanged(nameof(Tar_2nd_rt_Ry)); }
        }

        public double Fix_1st_rt_Lx
        {
            get { return dFix_1st_rt_Lx; }
            set { if (value == dFix_1st_rt_Lx) return; dFix_1st_rt_Lx = value; this.OnPropertyChanged(nameof(Fix_1st_rt_Lx)); }
        }
        public double Fix_1st_rt_Ly
        {
            get { return dFix_1st_rt_Ly; }
            set { if (value == dFix_1st_rt_Ly) return; dFix_1st_rt_Ly = value; this.OnPropertyChanged(nameof(Fix_1st_rt_Ly)); }
        }
        public double Fix_1st_rt_Rx
        {
            get { return dFix_1st_rt_Rx; }
            set { if (value == dFix_1st_rt_Rx) return; dFix_1st_rt_Rx = value; this.OnPropertyChanged(nameof(Fix_1st_rt_Rx)); }
        }
        public double Fix_1st_rt_Ry
        {
            get { return dFix_1st_rt_Ry; }
            set { if (value == dFix_1st_rt_Ry) return; dFix_1st_rt_Ry = value; this.OnPropertyChanged(nameof(Fix_1st_rt_Ry)); }
        }
        public double Fix_2nd_rt_Lx
        {
            get { return dFix_2nd_rt_Lx; }
            set { if (value == dFix_2nd_rt_Lx) return; dFix_2nd_rt_Lx = value; this.OnPropertyChanged(nameof(Fix_2nd_rt_Lx)); }
        }
        public double Fix_2nd_rt_Ly
        {
            get { return dFix_2nd_rt_Ly; }
            set { if (value == dFix_2nd_rt_Ly) return; dFix_2nd_rt_Ly = value; this.OnPropertyChanged(nameof(Fix_2nd_rt_Ly)); }
        }
        public double Fix_2nd_rt_Rx
        {
            get { return dFix_2nd_rt_Rx; }
            set { if (value == dFix_2nd_rt_Rx) return; dFix_2nd_rt_Rx = value; this.OnPropertyChanged(nameof(Fix_2nd_rt_Rx)); }
        }
        public double Fix_2nd_rt_Ry
        {
            get { return dFix_2nd_rt_Ry; }
            set { if (value == dFix_2nd_rt_Ry) return; dFix_2nd_rt_Ry = value; this.OnPropertyChanged(nameof(Fix_2nd_rt_Ry)); }
        }
        #endregion
        */

        #endregion
        public Algo4PAlign_FLamiResult() : base() { }
        public override string ToString()
        {
            // 수정할 것,,
            return string.Format("");
        }

    }
}
