﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;
using System;
using System.Collections.Generic;

namespace Iva.Bplus.Modules.Algo4PInsp_FLami
{
    [SerializableAttribute]
    class Algo4PInsp_FLamiInputParams : InputParams
    {
        // Align 방식 
        //  (X1,Y1) -----------------------(X4,Y4)
        //    |                               l
        //    |                               l
        //    l                               l
        //    |                               |        Lower 찍고, Upper로 이동!
        //    l                               l         
        //    l                               l
        //  (X2,Y2) -----------------------(X3,Y3)
        //     '작업자' 방향
        //

        /// <summary>
        /// Object : 측정 시 제품 각도 반영되는 대상체 (ex, M Insp = Metal)
        /// Target : Object 기준 측정 대상체 (ex, M Insp = Panel)
        /// </summary>
        public object Object_1 { get; set; }
        public object Object_2 { get; set; }
        public object Object_3 { get; set; }
        public object Object_4 { get; set; }
        public object Target_1 { get; set; }
        public object Target_2 { get; set; }
        public object Target_3 { get; set; }
        public object Target_4 { get; set; }

        public CalcTrigger Trigger { get; set; }
    }
}
