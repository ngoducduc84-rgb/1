﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo4PInsp_FLami
{
    [SerializableAttribute]

    public partial class Algo4PInsp_FLamiModelParams : AlgoParams
    {
        #region [field]

        #region Dis 진/가성 판정 field
        // ex) 측정(Dis1 + Dis4) -  이상적(Dis1 + Dis4) > '_JudgeTh' ---> 'NG'
        private AlgoParam _AccuracyTh;
        #endregion

        #region Resolution
        private AlgoParam _Resolution;
        private AlgoParam _MarkDistance;
        private AlgoParam _MarkDistance_V;
        #endregion

        #region Scale
        private AlgoParam _Pos1ScaleX;
        private AlgoParam _Pos1ScaleY;
        private AlgoParam _Pos2ScaleX;
        private AlgoParam _Pos2ScaleY;
        private AlgoParam _Pos3ScaleX;
        private AlgoParam _Pos3ScaleY;
        private AlgoParam _Pos4ScaleX;
        private AlgoParam _Pos4ScaleY;
        #endregion

        #region Each Position Distance Spec  
        private AlgoParam _DisX1;
        private AlgoParam _DisX2;
        private AlgoParam _DisX3;
        private AlgoParam _DisX4;
        private AlgoParam _DisY1;
        private AlgoParam _DisY2;
        private AlgoParam _DisY3;
        private AlgoParam _DisY4;
        #endregion

        #region Spec & Tol
        private AlgoParam _UpperCenter;
        private AlgoParam _LowerCenter;
        private AlgoParam _LeftCenter ;
        private AlgoParam _RightCenter;

        private AlgoParam _UpperTol;
        private AlgoParam _LowerTol;
        private AlgoParam _LeftTol ;
        private AlgoParam _RightTol;

        //private AlgoParam _Cpk;
        private AlgoParam _MeasureDistanceShift_H;
        private AlgoParam _MeasureDistanceShift_V;
        //private AlgoParam _Inspection_Offset_H;
        //private AlgoParam _Inspection_Offset_V;


        private AlgoParam _Inspection_Offset_X1;
        private AlgoParam _Inspection_Offset_Y1;
        private AlgoParam _Inspection_Offset_X2;
        private AlgoParam _Inspection_Offset_Y2;
        private AlgoParam _Inspection_Offset_X3;
        private AlgoParam _Inspection_Offset_Y3;
        private AlgoParam _Inspection_Offset_X4;
        private AlgoParam _Inspection_Offset_Y4;
        #endregion
        #endregion

        #region[Properties]
        #region Dis 진/가성 판정 Properties
        public AlgoParam AccuracyTh
        {
            get { return _AccuracyTh; }
            set
            {
                if (_AccuracyTh == value) return;
                _AccuracyTh = value;
                this.OnPropertyChanged(nameof(AccuracyTh));
            }
        }
        #endregion

        #region Resolution Properties
        public AlgoParam Resolution
        {
            get { return _Resolution; }
            set
            {
                if (_Resolution == value) return;
                _Resolution = value;
                this.OnPropertyChanged(nameof(Resolution));
            }
        }

        public AlgoParam MarkDistance
        {
            get { return _MarkDistance; }
            set
            {
                if (_MarkDistance == value) return;
                _MarkDistance = value;
                this.OnPropertyChanged(nameof(_MarkDistance));
            }
        }

        public AlgoParam MarkDistance_V
        {
            get { return _MarkDistance_V; }
            set
            {
                if (_MarkDistance_V == value) return;
                _MarkDistance_V = value;
                this.OnPropertyChanged(nameof(_MarkDistance_V));
            }
        }

        //public AlgoParam ScaleX1 { get; }
        #endregion

        #region Scale Properties
        public AlgoParam ScaleX1
        {
            get { return _Pos1ScaleX; }
            set
            {
                if (_Pos1ScaleX == value) return;
                _Pos1ScaleX = value;
                this.OnPropertyChanged(nameof(ScaleX1));
            }
        }
        public AlgoParam ScaleY1
        {
            get { return _Pos1ScaleY; }
            set
            {
                if (_Pos1ScaleY == value) return;
                _Pos1ScaleY = value;
                this.OnPropertyChanged(nameof(ScaleY1));
            }
        }
        public AlgoParam ScaleX2
        {
            get { return _Pos2ScaleX; }
            set
            {
                if (_Pos2ScaleX == value) return;
                _Pos2ScaleX = value;
                this.OnPropertyChanged(nameof(ScaleX2));
            }
        }
        public AlgoParam ScaleY2
        {
            get { return _Pos2ScaleY; }
            set
            {
                if (_Pos2ScaleY == value) return;
                _Pos2ScaleY = value;
                this.OnPropertyChanged(nameof(ScaleY2));
            }
        }
        public AlgoParam ScaleX3
        {
            get { return _Pos3ScaleX; }
            set
            {
                if (_Pos3ScaleX == value) return;
                _Pos3ScaleX = value;
                this.OnPropertyChanged(nameof(ScaleX3));
            }
        }
        public AlgoParam ScaleY3
        {
            get { return _Pos3ScaleY; }
            set
            {
                if (_Pos3ScaleY == value) return;
                _Pos3ScaleY = value;
                this.OnPropertyChanged(nameof(ScaleY3));
            }
        }
        public AlgoParam ScaleX4
        {
            get { return _Pos4ScaleX; }
            set
            {
                if (_Pos4ScaleX == value) return;
                _Pos4ScaleX = value;
                this.OnPropertyChanged(nameof(ScaleX4));
            }
        }
        public AlgoParam ScaleY4
        {
            get { return _Pos4ScaleY; }
            set
            {
                if (_Pos4ScaleY == value) return;
                _Pos4ScaleY = value;
                this.OnPropertyChanged(nameof(ScaleY4));
            }
        }
        #endregion

        #region Each Position Distance Spec  Properties
        public AlgoParam DisX1
        {
            get { return _DisX1; }
            set
            {
                if (_DisX1 == value) return;
                _DisX1 = value;
                this.OnPropertyChanged(nameof(DisX1));
            }
        }
        public AlgoParam DisX2
        {
            get { return _DisX2; }
            set
            {
                if (_DisX2 == value) return;
                _DisX2 = value;
                this.OnPropertyChanged(nameof(DisX2));
            }
        }
        public AlgoParam DisX3
        {
            get { return _DisX3; }
            set
            {
                if (_DisX3 == value) return;
                _DisX3 = value;
                this.OnPropertyChanged(nameof(DisX3));
            }
        }
        public AlgoParam DisX4
        {
            get { return _DisX4; }
            set
            {
                if (_DisX4 == value) return;
                _DisX4 = value;
                this.OnPropertyChanged(nameof(DisX4));
            }
        }
        public AlgoParam DisY1
        {
            get { return _DisY1; }
            set
            {
                if (_DisY1 == value) return;
                _DisY1 = value;
                this.OnPropertyChanged(nameof(DisY1));
            }
        }
        public AlgoParam DisY2
        {
            get { return _DisY2; }
            set
            {
                if (_DisY2 == value) return;
                _DisY2 = value;
                this.OnPropertyChanged(nameof(DisY2));
            }
        }
        public AlgoParam DisY3
        {
            get { return _DisY3; }
            set
            {
                if (_DisY3 == value) return;
                _DisY3 = value;
                this.OnPropertyChanged(nameof(DisY3));
            }
        }
        public AlgoParam DisY4
        {
            get { return _DisY4; }
            set
            {
                if (_DisY4 == value) return;
                _DisY4 = value;
                this.OnPropertyChanged(nameof(DisY4));
            }
        }
        #endregion

        #region Spec & Tol  Properties
        public AlgoParam UpperCenter
        {
            get { return _UpperCenter; }
            set
            {
                if (_UpperCenter == value) return;
                _UpperCenter = value;
                this.OnPropertyChanged(nameof(UpperCenter));
            }
        }
        public AlgoParam LowerCenter
        {
            get { return _LowerCenter; }
            set
            {
                if (_LowerCenter == value) return;
                _LowerCenter = value;
                this.OnPropertyChanged(nameof(LowerCenter));
            }
        }
        public AlgoParam LeftCenter
        {
            get { return _LeftCenter; }
            set
            {
                if (_LeftCenter == value) return;
                _LeftCenter = value;
                this.OnPropertyChanged(nameof(LeftCenter));
            }
        }
        public AlgoParam RightCenter
        {
            get { return _RightCenter; }
            set
            {
                if (_RightCenter == value) return;
                _RightCenter = value;
                this.OnPropertyChanged(nameof(RightCenter));
            }
        }

        public AlgoParam UpperTol
        {
            get { return _UpperTol; }
            set
            {
                if (_UpperTol == value) return;
                _UpperTol = value;
                this.OnPropertyChanged(nameof(UpperTol));
            }
        }
        public AlgoParam LowerTol
        {
            get { return _LowerTol; }
            set
            {
                if (_LowerTol == value) return;
                _LowerTol = value;
                this.OnPropertyChanged(nameof(LowerTol));
            }
        }
        public AlgoParam LeftTol
        {
            get { return _LeftTol; }
            set
            {
                if (_LeftTol == value) return;
                _LeftTol = value;
                this.OnPropertyChanged(nameof(LeftTol));
            }
        }
        public AlgoParam RightTol
        {
            get { return _RightTol; }
            set
            {
                if (_RightTol == value) return;
                _RightTol = value;
                this.OnPropertyChanged(nameof(RightTol));
            }
        }

        //public AlgoParam Cpk
        //{
        //    get { return _Cpk; }
        //    set
        //    {
        //        if (_Cpk == value) return;
        //        _Cpk = value;
        //        this.OnPropertyChanged(nameof(Cpk));
        //    }
        //}
        public AlgoParam MeasureDistanceShift_H
        {
            get { return _MeasureDistanceShift_H; }
            set
            {
                if (_MeasureDistanceShift_H == value) return;
                _MeasureDistanceShift_H = value;
                this.OnPropertyChanged(nameof(MeasureDistanceShift_H));
            }
        }

        public AlgoParam MeasureDistanceShift_V
        {
            get { return _MeasureDistanceShift_V; }
            set
            {
                if (_MeasureDistanceShift_V == value) return;
                _MeasureDistanceShift_V = value;
                this.OnPropertyChanged(nameof(MeasureDistanceShift_V));
            }
        }

        //public AlgoParam Inspection_Offset_H
        //{
        //    get { return _Inspection_Offset_H; }
        //    set
        //    {
        //        if (_Inspection_Offset_H == value) return;
        //        _Inspection_Offset_H = value;
        //        this.OnPropertyChanged(nameof(Inspection_Offset_H));
        //    }
        //}

        //public AlgoParam Inspection_Offset_V
        //{
        //    get { return _Inspection_Offset_V; }
        //    set
        //    {
        //        if (_Inspection_Offset_V == value) return;
        //        _Inspection_Offset_V = value;
        //        this.OnPropertyChanged(nameof(Inspection_Offset_V));
        //    }
        //}

        public AlgoParam Inspection_Offset_X1
        {
            get { return _Inspection_Offset_X1; }
            set
            {
                if (_Inspection_Offset_X1 == value) return;
                _Inspection_Offset_X1 = value;
                this.OnPropertyChanged(nameof(Inspection_Offset_X1));
            }
        }

        public AlgoParam Inspection_Offset_Y1
        {
            get { return _Inspection_Offset_Y1; }
            set
            {
                if (_Inspection_Offset_Y1 == value) return;
                _Inspection_Offset_Y1 = value;
                this.OnPropertyChanged(nameof(Inspection_Offset_Y1));
            }
        }

        public AlgoParam Inspection_Offset_X2
        {
            get { return _Inspection_Offset_X2; }
            set
            {
                if (_Inspection_Offset_X2 == value) return;
                _Inspection_Offset_X2 = value;
                this.OnPropertyChanged(nameof(Inspection_Offset_X2));
            }
        }

        public AlgoParam Inspection_Offset_Y2
        {
            get { return _Inspection_Offset_Y2; }
            set
            {
                if (_Inspection_Offset_Y2 == value) return;
                _Inspection_Offset_Y2 = value;
                this.OnPropertyChanged(nameof(Inspection_Offset_Y2));
            }
        }
        
        public AlgoParam Inspection_Offset_X3
        {
            get { return _Inspection_Offset_X3; }
            set
            {
                if (_Inspection_Offset_X3 == value) return;
                _Inspection_Offset_X3 = value;
                this.OnPropertyChanged(nameof(Inspection_Offset_X3));
            }
        }

        public AlgoParam Inspection_Offset_Y3
        {
            get { return _Inspection_Offset_Y3; }
            set
            {
                if (_Inspection_Offset_Y3 == value) return;
                _Inspection_Offset_Y3 = value;
                this.OnPropertyChanged(nameof(Inspection_Offset_Y3));
            }
        }

        public AlgoParam Inspection_Offset_X4
        {
            get { return _Inspection_Offset_X4; }
            set
            {
                if (_Inspection_Offset_X4 == value) return;
                _Inspection_Offset_X4 = value;
                this.OnPropertyChanged(nameof(Inspection_Offset_X4));
            }
        }

        public AlgoParam Inspection_Offset_Y4
        {
            get { return _Inspection_Offset_Y4; }
            set
            {
                if (_Inspection_Offset_Y4 == value) return;
                _Inspection_Offset_Y4 = value;
                this.OnPropertyChanged(nameof(Inspection_Offset_Y4));
            }
        }

        #endregion

        #endregion

        public Algo4PInsp_FLamiModelParams()
        {
            // Judgement Threshold값 - 0920 주석 제거
            AccuracyTh = new AlgoParam("AccuracyTh", "mm", typeof(double), 0.5, "가성 Data 판단 Thrshold", 0, 5);
            // Resolution
            Resolution = new AlgoParam("Resolution", "mm", typeof(double), 0.005, "Camera Resolution Spec", 0, 1);
            MarkDistance = new AlgoParam("MarkDistance", "mm", typeof(double), 145.25, "distance of object mark", 0, 200);
            MarkDistance_V = new AlgoParam("MarkDistance_V", "mm", typeof(double), 300, "distance of object mark Vertical", 0, 500);

            // Scale값
            ScaleX1 = new AlgoParam("ScaleX1", "um", typeof(double), 1.0, "Pos X1의Scale 적용 값", 0.5, 1.5);
            ScaleY1 = new AlgoParam("ScaleY1", "um", typeof(double), 1.0, "Pos Y1의Scale 적용 값", 0.5, 1.5);
            ScaleX2 = new AlgoParam("ScaleX2", "um", typeof(double), 1.0, "Pos X2의Scale 적용 값", 0.5, 1.5);
            ScaleY2 = new AlgoParam("ScaleY2", "um", typeof(double), 1.0, "Pos Y2의Scale 적용 값", 0.5, 1.5);
            ScaleX3 = new AlgoParam("ScaleX3", "um", typeof(double), 1.0, "Pos X3의Scale 적용 값", 0.5, 1.5);
            ScaleY3 = new AlgoParam("ScaleY3", "um", typeof(double), 1.0, "Pos Y3의Scale 적용 값", 0.5, 1.5);
            ScaleX4 = new AlgoParam("ScaleX4", "um", typeof(double), 1.0, "Pos X4의Scale 적용 값", 0.5, 1.5);
            ScaleY4 = new AlgoParam("ScaleY4", "um", typeof(double), 1.0, "Pos Y4의Scale 적용 값", 0.5, 1.5);

            // Dist Spec
            DisX1 = new AlgoParam("DisX1", "mm", typeof(double), 1.0, "설계치", 0.0, 2.0);
            DisX2 = new AlgoParam("DisX2", "mm", typeof(double), 1.0, "설계치", 0.0, 2.0);
            DisX3 = new AlgoParam("DisX3", "mm", typeof(double), 1.0, "설계치", 0.0, 2.0);
            DisX4 = new AlgoParam("DisX4", "mm", typeof(double), 1.0, "설계치", 0.0, 2.0);

            DisY1 = new AlgoParam("DisY1", "mm", typeof(double), 1.0, "설계치", 0.0, 2.0);
            DisY2 = new AlgoParam("DisY2", "mm", typeof(double), 1.0, "설계치", 0.0, 2.0);
            DisY3 = new AlgoParam("DisY3", "mm", typeof(double), 1.0, "설계치", 0.0, 2.0);
            DisY4 = new AlgoParam("DisY4", "mm", typeof(double), 1.0, "설계치", 0.0, 2.0);

            UpperCenter = new AlgoParam("UpperCenter", "mm", typeof(double), 0, "Upper CenterAlign의 중심값", -0.5, 0.5);
            LowerCenter = new AlgoParam("LowerCenter", "mm", typeof(double), 0, "Lower CenterAlign의 중심값", -0.5, 0.5);
            LeftCenter  = new AlgoParam("LeftCenter" , "mm", typeof(double), 0, "Left  CenterAlign의 중심값", -0.5, 0.5);
            RightCenter = new AlgoParam("RightCenter", "mm", typeof(double), 0, "Right CenterAlign의 중심값", -0.5, 0.5);
            // Center Dist Tor
            UpperTol = new AlgoParam("UpperTol", "mm", typeof(double), 0.125, "Upper CenterAlign의 Tolerance값", 0.0, 0.5);
            LowerTol = new AlgoParam("LowerTol", "mm", typeof(double), 0.125, "Lower CenterAlign의 Tolerance값", 0.0, 0.5);
            LeftTol  = new AlgoParam("LeftTol" , "mm", typeof(double), 0.125, "Left  CenterAlign의 Tolerance값", 0.0, 0.5);
            RightTol = new AlgoParam("RightTol", "mm", typeof(double), 0.125, "Right CenterAlign의 Tolerance값", 0.0, 0.5);
            // Center Dist Tor
            //Cpk = new AlgoParam("Cpk Value", "mm", typeof(double), 1.0, "검사 Cpk 기준", 0.0, 2.0);

            MeasureDistanceShift_H = new AlgoParam("MeasureDistanceShift_H", "mm", typeof(double), 0.0, "MeasureDistance", -10.0, 10.0);
            MeasureDistanceShift_V = new AlgoParam("MeasureDistanceShift_V", "mm", typeof(double), 0.0, "MeasureDistance", -10.0, 10.0);
            //Inspection_Offset_H = new AlgoParam("Inspection_Offset_H", "mm", typeof(double), 0.0, "Inspection_Offset_H", -0.5, 0.5);
            //Inspection_Offset_V = new AlgoParam("Inspection_Offset_V", "mm", typeof(double), 0.0, "Inspection_Offset_V", -0.5, 0.5);

            Inspection_Offset_X1 = new AlgoParam("Inspection_Offset_X1", "mm", typeof(double), 0.0, "Inspection_Offset_X1", -0.5, 0.5);
            Inspection_Offset_Y1 = new AlgoParam("Inspection_Offset_Y1", "mm", typeof(double), 0.0, "Inspection_Offset_Y1", -0.5, 0.5);
            Inspection_Offset_X2 = new AlgoParam("Inspection_Offset_X2", "mm", typeof(double), 0.0, "Inspection_Offset_X2", -0.5, 0.5);
            Inspection_Offset_Y2 = new AlgoParam("Inspection_Offset_Y2", "mm", typeof(double), 0.0, "Inspection_Offset_Y2", -0.5, 0.5);
            Inspection_Offset_X3 = new AlgoParam("Inspection_Offset_X3", "mm", typeof(double), 0.0, "Inspection_Offset_X3", -0.5, 0.5);
            Inspection_Offset_Y3 = new AlgoParam("Inspection_Offset_Y3", "mm", typeof(double), 0.0, "Inspection_Offset_Y3", -0.5, 0.5);
            Inspection_Offset_X4 = new AlgoParam("Inspection_Offset_X4", "mm", typeof(double), 0.0, "Inspection_Offset_X4", -0.5, 0.5);
            Inspection_Offset_Y4 = new AlgoParam("Inspection_Offset_Y4", "mm", typeof(double), 0.0, "Inspection_Offset_Y4", -0.5, 0.5);
        }
    }

    [Serializable]
    public class LamiInsp_PLCTable
    {
        #region [Feilds]
        public string SourceID { get; set; }

        public int Main_CHNo { get; set; }
        #endregion

        #region [Construct]
        public LamiInsp_PLCTable() { }
        #endregion
    }
}
