﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;

using Cognex.VisionPro.Dimensioning;
using Cognex.VisionPro;
using Iva.Bplus.Modules.CogDisplay;
using Iva.Bplus.Interface;

namespace Iva.Bplus.Modules.Algo4PInsp_FLami
{
    public enum InspectionType { D_Lami_Sub, D_Lami_Main, M_Lami_Sub, M_Lami_Main }
    public enum InspectionTool { PointToPoint, LineToLine, LineToPoint, }

    [SerializableAttribute]
    public partial class Algo4PInsp_FLamiObject : AlgoObjectBase
    {
        #region [Fields]
        [field: NonSerialized]
        XY[] scaleParam = new XY[4];
        [field: NonSerialized]
        XY[] distParam = new XY[4];
        [field: NonSerialized]
        XY[] distResult = new XY[4];
        [field: NonSerialized]
        XY[] distXStart = new XY[4];
        [field: NonSerialized]
        XY[] distXEnd = new XY[4];
        [field: NonSerialized]
        XY[] distYStart = new XY[4];
        [field: NonSerialized]
        XY[] distYEnd = new XY[4];
        [field: NonSerialized]
        LineCrossRstData[] LineRst = new LineCrossRstData[4];
        [field: NonSerialized]
        IPointResult[] pointRst = new IPointResult[4];
        [field: NonSerialized]
        IPointResult[] TargetRst;
        [field: NonSerialized]
        IPointResult[] ObjectRst;
        [field: NonSerialized]
        CogDistancePointLineTool calcTool = new CogDistancePointLineTool();
        [field: NonSerialized]
        XYT revAlign = new XYT();
        [field: NonSerialized]
        double[] px = new double[4];
        [field: NonSerialized]
        double[] py = new double[4];
        // Result Data
        [field: NonSerialized]
        Algo4PInsp_FLamiModelParams mParams;
        private Algo4PInsp_FLamiResult inspRst;
        [field: NonSerialized]
        LamiInsp_PLCTable cvtPLCIO;

        private string calData_Left;
        private string calData_Right;

        private string p1_Display;
        private string p2_Display;
        private string p3_Display;
        private string p4_Display;

        private InspectionType insType;
        private InspectionTool insTool = InspectionTool.LineToLine;
        private string insImageName;
        private UseDistRevision distRevision;
        public Dictionary<string, bool> errCode;
        public Dictionary<string, object> InputData = new Dictionary<string, object>();

        int Main_CHNo;

        #endregion

        #region [properties]
        public CalDataObject CalDataObj_Left
        {
            get { return SystemObject_Common.GetObject(CalData_Left) as CalDataObject; }
        }

        public CalDataObject CalDataObj_Right
        {
            get { return SystemObject_Common.GetObject(CalData_Right) as CalDataObject; }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string CalData_Left
        {
            get { return calData_Left; }
            set { if (calData_Left == value) return; calData_Left = value; this.OnPropertyChanged(nameof(CalData_Left)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string CalData_Right
        {
            get { return calData_Right; }
            set { if (calData_Right == value) return; calData_Right = value; this.OnPropertyChanged(nameof(CalData_Right)); }
        }



        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P2_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p2_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P3_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p3_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P4_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p4_Display) as CogDisplayObject; }
        }


        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P2_Display
        {
            get { return p2_Display; }
            set { if (p2_Display == value) return; p2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P3_Display
        {
            get { return p3_Display; }
            set { if (p3_Display == value) return; p3_Display = value; this.OnPropertyChanged(nameof(P3_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P4_Display
        {
            get { return p4_Display; }
            set { if (p4_Display == value) return; p4_Display = value; this.OnPropertyChanged(nameof(P4_Display)); }
        }

        public Algo4PInsp_FLamiResult InspRst
        {
            get { return inspRst; }
            set
            {
                if (inspRst == value) return;
                inspRst = value;

                this.OnPropertyChanged(nameof(InspRst));
            }
        }
        public XYT RevAlign { get { return revAlign; } }
        public XY[] InspResult { get { return distResult; } }

        public double[] Px { get { return px; } }
        public double[] Py { get { return py; } }
        public UseDistRevision DistRevision
        {
            get { return distRevision; }
            set
            {
                if (distRevision == value) return;

                distRevision = value;
                OnPropertyChanged("DistRevision");
            }
        }

        public Dictionary<string, bool> ErrCode
        {
            get { return errCode; }
            set
            {
                if (errCode == value) return;

                errCode = value;
                OnPropertyChanged("ErrCode");
            }
        }

        public InspectionType InsType
        {
            get { return insType; }
            set
            {
                if (insType == value) return;
                insType = value;

                switch (insType)
                {
                    case InspectionType.D_Lami_Sub:
                        InsImageName = "D_Lami_Sub.PNG";
                        break;
                    case InspectionType.D_Lami_Main:
                        InsImageName = "D_Lami_Main.PNG";
                        break;
                    case InspectionType.M_Lami_Sub:
                        InsImageName = "M_Lami_Sub.PNG";
                        break;
                    case InspectionType.M_Lami_Main:
                        InsImageName = "M_Lami_Main.PNG";
                        break;
                }
                OnPropertyChanged("InsType");
            }
        }

        public InspectionTool InsTool
        {
            get { return insTool; }
            set
            {
                if (insTool == value) return;
                insTool = value;
                this.OnPropertyChanged(nameof(InspectionTool));
            }
        }
       
        public string InsImageName
        {
            get { return insImageName; }
            set
            {
                if (insImageName == value) return;
                insImageName = value;
                OnPropertyChanged("InsImageName");
            }
        }


        #endregion

        #region [private method]
        #endregion

        #region [public method]
        #endregion

        #region[Construct]
        public Algo4PInsp_FLamiObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo4PInsp_FLamiModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion


        protected void AssignPLCData()
        {
            UpdatePLCIOs();

            SourceID = (string)PlcValues["CellID"].CurValue;  
            Main_CHNo = PlcValues.ContainsKey("MainChamberNo") ? (int)PlcValues["MainChamberNo"].CurValue : 0; //D68139
        }

        void Initialize()
        {
            scaleParam = new XY[4];
            distParam = new XY[4];
            distResult = new XY[4];
            distXStart = new XY[4];
            distXEnd = new XY[4];
            distYStart = new XY[4];
            distYEnd = new XY[4];
            LineRst = new LineCrossRstData[4];
            pointRst = new IPointResult[4];
            revAlign = new XYT();
            calcTool = new CogDistancePointLineTool();
            TargetRst = new IPointResult[4];
            ObjectRst = new IPointResult[4];
            px = new double[4];
            py = new double[4];

            for (int i = 0; i < 4; i++)
            {
                scaleParam[i] = new XY(0.0, 0.0);
                distParam[i] = new XY(0.0, 0.0);
                distResult[i] = new XY(0.0, 0.0);

                distXStart[i] = new XY();
                distXEnd[i] = new XY();
                distYStart[i] = new XY();
                distYEnd[i] = new XY();
            }
            Main_CHNo = 0;
        }

        #region [override methode]
        public override bool Run()
        {
            StartTimer();

            #region Initialize 
            string model = SystemModel.GetCurModel();
            errCode = new Dictionary<string, bool>();
            InitInsp_Err(ref errCode);
            errorCode = SystemActionBase.No_Error;
            Initialize();
            #endregion

            #region PLC IOs Update
            AssignPLCData();
           
            #endregion

            #region Mark Data Read& Confirm
            XY[] objectPoints = new XY[4];
            XY[] targetPoints = new XY[4];
            switch (InsTool)
            {
                case InspectionTool.PointToPoint://obj point * 4 + tar point * 4
                    for (int i = 0; i < 4; i++)
                    {
                        // get object points
                        string key = $"Object_{i + 1}";
                        var pnt = InputValues[key] as IPointResult;
                        if (pnt == null)
                        {
                            errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                            return false;
                        }
                        objectPoints[i] = new XY(pnt.OutputXYT.X, pnt.OutputXYT.Y);

                        // get target points
                        key = $"Target_{i + 1}";
                        pnt = InputValues[key] as IPointResult;
                        if (pnt == null)
                        {
                            errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                            return false;
                        }
                        targetPoints[i] = new XY(pnt.OutputXYT.X, pnt.OutputXYT.Y);
                    }
                    break;
                case InspectionTool.LineToLine://obj line * 8 + tar line * 8
                case InspectionTool.LineToPoint://obj line * 8 + tar point * 8
                default:
                    // not define
                    return false;
            }

            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            mParams = modelParams as Algo4PInsp_FLamiModelParams;
            var AccuracyTh = (double)mParams.AccuracyTh.Value;
            var Resolution = (double)mParams.Resolution.Value;

            var UpperCenter = (double)mParams.UpperCenter.Value;
            var LowerCenter = (double)mParams.LowerCenter.Value;
            var LeftCenter = (double)mParams.LeftCenter.Value;
            var RightCenter = (double)mParams.RightCenter.Value;

            var UpperTol = (double)mParams.UpperTol.Value;
            var LowerTol = (double)mParams.LowerTol.Value;
            var LeftTol = (double)mParams.LeftTol.Value;
            var RightTol = (double)mParams.RightTol.Value;

            scaleParam[0].X = (double)mParams.ScaleX1.Value;
            scaleParam[0].Y = (double)mParams.ScaleY1.Value;
            scaleParam[1].X = (double)mParams.ScaleX2.Value;
            scaleParam[1].Y = (double)mParams.ScaleY2.Value;
            scaleParam[2].X = (double)mParams.ScaleX3.Value;
            scaleParam[2].Y = (double)mParams.ScaleY3.Value;
            scaleParam[3].X = (double)mParams.ScaleX4.Value;
            scaleParam[3].Y = (double)mParams.ScaleY4.Value;
            
            #endregion

            #region Mark To Point, Distance 측정하는 부분 

            switch (InsTool)
            {
                case InspectionTool.PointToPoint:
                    if (!CalcDistanceP2P(model, objectPoints, targetPoints))
                    {
                        errorCode = AlgoActionBase.Err_Failed_To_Calculate_Distance;
                        return false;
                    }
                    break;
                case InspectionTool.LineToLine:
                case InspectionTool.LineToPoint:
                default:
                    // not define
                    return false;
            }
            #endregion

            #region 6) Inspection Data 정합성 Judgement & Needs -> Revision
            bool alteredData = false;
            string alterArea = "";
            string tempArea = "";
            if (DistRevision == UseDistRevision.Use)
            {
                if (InsType == InspectionType.D_Lami_Sub)
                {
                    distParam[2].X = (double)mParams.DisX1.Value;
                    distParam[2].Y = (double)mParams.DisY1.Value;
                    distParam[3].X = (double)mParams.DisX2.Value;
                    distParam[3].Y = (double)mParams.DisY2.Value;
                    distParam[0].X = (double)mParams.DisX3.Value;
                    distParam[0].Y = (double)mParams.DisY3.Value;
                    distParam[1].X = (double)mParams.DisX4.Value;
                    distParam[1].Y = (double)mParams.DisY4.Value;
                }
                else if (InsType == InspectionType.M_Lami_Main)
                {
                    distParam[0].Y = (double)mParams.DisX1.Value;
                    distParam[0].X = (double)mParams.DisY1.Value;
                    distParam[3].Y = (double)mParams.DisX2.Value;
                    distParam[3].X = (double)mParams.DisY2.Value;
                    distParam[2].Y = (double)mParams.DisX3.Value;
                    distParam[2].X = (double)mParams.DisY3.Value;
                    distParam[1].Y = (double)mParams.DisX4.Value;
                    distParam[1].X = (double)mParams.DisY4.Value;
                }
                else    //D_Lami_Main, M_Lami_Sub
                {
                    distParam[1].Y = (double)mParams.DisX1.Value;
                    distParam[1].X = (double)mParams.DisY1.Value;
                    distParam[2].Y = (double)mParams.DisX2.Value;
                    distParam[2].X = (double)mParams.DisY2.Value;
                    distParam[3].Y = (double)mParams.DisX3.Value;
                    distParam[3].X = (double)mParams.DisY3.Value;
                    distParam[0].Y = (double)mParams.DisX4.Value;
                    distParam[0].X = (double)mParams.DisY4.Value;
                }

                for (int i = 0; i < 4; i++)
                {
                    if (objectPoints[i].X == 0 || targetPoints[i].X == 0)
                    {
                        distResult[i] = new XY(0, 0);

                        distXStart[i] = new XY(0, 0);
                        distXEnd[i] = new XY(0, 0);
                        distYStart[i] = new XY(0, 0);
                        distYEnd[i] = new XY(0, 0);
                    }
                }

                // (1) Vision 좌표: X1 ~ X4
                if (AccuracyCheck_Dis(distParam[0].X + distParam[3].X, distResult[0].X + distResult[3].X, AccuracyTh) != true || distResult[0].X==0 || distResult[3].X==0)
                {
                    CompensateData(distParam[0].X, distParam[3].X, distResult[0].X, distResult[3].X,
                        ref tempArea, "X1_X4", distXStart[0], distXEnd[0], distXStart[3], distXEnd[3]);

                    switch (InsType)
                    {
                        case InspectionType.D_Lami_Sub:
                            alterArea += "X3_X2" + tempArea + ",";
                            break;
                        case InspectionType.M_Lami_Main:
                            alterArea += "Y1_Y2" + tempArea + ",";
                            break;
                        default:    //D_Lami_Main, M_Lami_Sub
                            alterArea += "Y4_Y3" + tempArea + ",";
                            break;
                    }
                };

                // (2) Vision 좌표: X2 ~ X3
                if (AccuracyCheck_Dis(distParam[1].X + distParam[2].X, distResult[1].X + distResult[2].X, AccuracyTh) != true || distResult[1].X==0 || distResult[2].X==0)
                {
                    CompensateData(distParam[1].X, distParam[2].X, distResult[1].X, distResult[2].X,
                        ref tempArea, "X2_X3", distXStart[1], distXEnd[2], distXStart[1], distXEnd[2]);

                    switch (InsType)
                    {
                        case InspectionType.D_Lami_Sub:
                            alterArea += "X4_X1" + tempArea + ",";
                            break;
                        case InspectionType.M_Lami_Main:
                            alterArea += "Y4_Y3" + tempArea + ",";
                            break;
                        default:    //D_Lami_Main, M_Lami_Sub
                            alterArea += "Y1_Y2" + tempArea + ",";
                            break;
                    }
                };

                // (3) Vision 좌표: Y1 ~ Y2
                if (AccuracyCheck_Dis(distParam[0].Y + distParam[1].Y, distResult[0].Y + distResult[1].Y, AccuracyTh) != true || distResult[0].Y==0 || distResult[1].Y==0)
                {
                    CompensateData(distParam[0].Y, distParam[1].Y, distResult[0].Y, distResult[1].Y,
                        ref tempArea, "Y1_Y2", distYStart[0], distYEnd[1], distYStart[0], distYEnd[1]);

                    switch (InsType)
                    {
                        case InspectionType.D_Lami_Sub:
                            alterArea += "Y3_Y4" + tempArea + ",";
                            break;
                        case InspectionType.M_Lami_Main:
                            alterArea += "X1_X4" + tempArea + ",";
                            break;
                        default:    //D_Lami_Main, M_Lami_Sub
                            alterArea += "X4_X1" + tempArea + ",";
                            break;
                    }
                };

                // (4) Vision 좌표: Y3 ~ Y4
                if (AccuracyCheck_Dis(distParam[2].Y + distParam[3].Y, distResult[2].Y + distResult[3].Y, AccuracyTh) != true || distResult[2].Y==0||distResult[3].Y==0)
                {
                    CompensateData(distParam[2].Y, distParam[3].Y, distResult[2].Y, distResult[3].Y,
                        ref tempArea, "Y3_Y4", distYStart[2], distYEnd[3], distYStart[2], distYEnd[3]);

                    switch (InsType)
                    {
                        case InspectionType.D_Lami_Sub:
                            alterArea += "Y1_Y2" + tempArea + ",";
                            break;
                        case InspectionType.M_Lami_Main:
                            alterArea += "X3_X2" + tempArea + ",";
                            break;
                        default:    //D_Lami_Main, M_Lami_Sub
                            alterArea += "X2_X3" + tempArea + ",";
                            break;
                    }
                };
            }
            #endregion

            #region 7) Center Align에 대한 판정
            bool bResult = true;
            double tempInspDistance = 0.0;

            //아래는 Vision 화면 기준으로 그리는 표시하는 구간임. (변수구분을 위해 Vision이라고 naming 들어갔으니 구분할 것.)

            //(Vision 화면 기준) 보상 적용된 CenterAlign 변수
            double inspVisionUpperCenter = 0.0;
            double inspVisionLowerCenter = 0.0;
            double inspVisionLeftCenter = 0.0;
            double inspVisionRightCenter = 0.0;

            //(Vision 화면 기준) CenterAlign Spec
            double specVisionUpper = 0.0;
            double specVisionLower = 0.0;
            double specVisionLeft = 0.0;
            double specVisionRight = 0.0;

            //(Vision 화면 기준) CenterAlign Tolerance
            double tolVisionUpper = 0.0;
            double tolVisionLower = 0.0;
            double tolVisionLeft = 0.0;
            double tolVisionRight = 0.0;


            //Inspection Type별로 Model패러미터 분기 적용
            if (InsType == InspectionType.D_Lami_Sub)
            {
                specVisionUpper = LowerCenter;
                specVisionLower = UpperCenter;
                specVisionLeft = RightCenter;
                specVisionRight = LeftCenter;

                tolVisionUpper = LowerTol;
                tolVisionLower = UpperTol;
                tolVisionLeft = RightCenter;
                tolVisionRight = LeftCenter;
            }
            else if (InsType == InspectionType.M_Lami_Main)
            {
                specVisionUpper = LeftCenter;
                specVisionLower = RightCenter;
                specVisionLeft = UpperCenter;
                specVisionRight = LowerCenter;

                tolVisionUpper = LeftTol;
                tolVisionLower = RightTol;
                tolVisionLeft = UpperTol;
                tolVisionRight = LowerTol;
            }
            else    //D_Lami_Main, M_Lami_Sub
            {
                specVisionUpper = RightCenter;
                specVisionLower = LeftCenter;
                specVisionLeft = UpperCenter;
                specVisionRight = LowerCenter;

                tolVisionUpper = RightTol;
                tolVisionLower = LeftTol;
                tolVisionLeft = UpperTol;
                tolVisionRight = LowerTol;
            }

            // #1. Vision 화면 상단 Center
            if (InsType == InspectionType.D_Lami_Sub)
            {
                F_Judgement(distResult[3].X, distResult[0].X, tolVisionUpper, specVisionUpper, ref inspVisionUpperCenter);
            }
            else if (InsType == InspectionType.M_Lami_Main)
            {
                F_Judgement(distResult[0].X, distResult[3].X, tolVisionUpper, specVisionUpper, ref inspVisionUpperCenter);
            }
            else     //D_Lami_Main, M_Lami_Sub
            {
                F_Judgement(distResult[0].X, distResult[3].X, tolVisionUpper, specVisionUpper, ref inspVisionUpperCenter);
            }

            if (Math.Abs(inspVisionUpperCenter - specVisionUpper) > tolVisionUpper)
            {
                if (distXStart[0].X != 0)
                {
                    DrawLineLabel(P1_DisplayObj, distXStart[0], distXEnd[0], distResult[0].X, CogColorConstants.Red, true, true);
                }
                if (distXStart[3].X != 0)
                {
                    DrawLineLabel(P4_DisplayObj, distXStart[3], distXEnd[3], distResult[3].X, CogColorConstants.Red, true, true);
                }

                bResult = false;
            }
            else
            {
                if (distXStart[0].X != 0)
                {
                    DrawLineLabel(P1_DisplayObj, distXStart[0], distXEnd[0], distResult[0].X, CogColorConstants.Cyan, true, true);
                }
                if (distXStart[3].X != 0)
                {
                    DrawLineLabel(P4_DisplayObj, distXStart[3], distXEnd[3], distResult[3].X, CogColorConstants.Cyan, true, true);
                }
            }

            // #2. Vision 화면 하단 Center
            if (InsType == InspectionType.D_Lami_Sub)
            {
                F_Judgement(distResult[2].X, distResult[1].X, tolVisionLower, specVisionLower, ref inspVisionLowerCenter);
            }
            else if (InsType == InspectionType.M_Lami_Main)
            {
                F_Judgement(distResult[1].X, distResult[2].X, tolVisionLower, specVisionLower, ref inspVisionLowerCenter);
            }
            else     //D_Lami_Main, M_Lami_Sub
            {
                F_Judgement(distResult[1].X, distResult[2].X, tolVisionLower, specVisionLower, ref inspVisionLowerCenter);
            }
            
            if (Math.Abs(inspVisionLowerCenter - specVisionLower) > tolVisionLower)
            {
                if (distXStart[1].X != 0)
                {
                    DrawLineLabel(P2_DisplayObj, distXStart[1], distXEnd[1], distResult[1].X, CogColorConstants.Red, true, true);
                }
                if (distXStart[2].X != 0)
                {
                    DrawLineLabel(P3_DisplayObj, distXStart[2], distXEnd[2], distResult[2].X, CogColorConstants.Red, true, true);
                }
                bResult = false;
            }
            else
            {
                if (distXStart[1].X != 0)
                {
                    DrawLineLabel(P2_DisplayObj, distXStart[1], distXEnd[1], distResult[1].X, CogColorConstants.Cyan, true, true);
                }
                if (distXStart[2].X != 0)
                {
                    DrawLineLabel(P3_DisplayObj, distXStart[2], distXEnd[2], distResult[2].X, CogColorConstants.Cyan, true, true);
                }
            }

            // #3. Vision 화면 좌측 Center
            if (InsType == InspectionType.D_Lami_Sub)
            {
                F_Judgement(distResult[1].Y, distResult[0].Y, tolVisionLeft, specVisionLeft, ref inspVisionLeftCenter);
            }
            else if (InsType == InspectionType.M_Lami_Main)
            {
                F_Judgement(distResult[0].Y, distResult[1].Y, tolVisionLeft, specVisionLeft, ref inspVisionLeftCenter);
            }
            else     //D_Lami_Main, M_Lami_Sub
            {
                F_Judgement(distResult[1].Y, distResult[0].Y, tolVisionLeft, specVisionLeft, ref inspVisionLeftCenter);
            }            

            if (Math.Abs(inspVisionLeftCenter - specVisionLeft) > tolVisionLeft)
            {
                if (distYStart[0].Y != 0)
                {
                    DrawLineLabel(P1_DisplayObj, distYStart[0], distYEnd[0], distResult[0].Y, CogColorConstants.Red, true, true);
                }
                if (distYStart[1].Y != 0)
                {
                    DrawLineLabel(P2_DisplayObj, distYStart[1], distYEnd[1], distResult[1].Y, CogColorConstants.Red, true, true);
                }
                bResult = false;
            }
            else
            {
                if (distYStart[0].Y != 0)
                {
                    DrawLineLabel(P1_DisplayObj, distYStart[0], distYEnd[0], distResult[0].Y, CogColorConstants.Cyan, true, true);
                }
                if (distYStart[1].Y != 0)
                {
                    DrawLineLabel(P2_DisplayObj, distYStart[1], distYEnd[1], distResult[1].Y, CogColorConstants.Cyan, true, true);
                }
            }

            // #4. Vision 화면 우측 Center
            if (InsType == InspectionType.D_Lami_Sub)
            {
                F_Judgement(distResult[2].Y, distResult[3].Y, tolVisionRight, specVisionRight, ref inspVisionRightCenter);
            }
            else if (InsType == InspectionType.M_Lami_Main)
            {
                F_Judgement(distResult[3].Y, distResult[2].Y, tolVisionRight, specVisionRight, ref inspVisionRightCenter);
            }
            else     //D_Lami_Main, M_Lami_Sub
            {
                F_Judgement(distResult[2].Y, distResult[3].Y, tolVisionRight, specVisionRight, ref inspVisionRightCenter);
            }
            
            if (Math.Abs(inspVisionRightCenter - specVisionRight) > tolVisionRight)
            {
                if (distYStart[2].Y != 0)
                {
                    DrawLineLabel(P3_DisplayObj, distYStart[2], distYEnd[2], distResult[2].Y, CogColorConstants.Red, true, true);
                }
                if (distYStart[3].Y != 0)
                {
                    DrawLineLabel(P4_DisplayObj, distYStart[3], distYEnd[3], distResult[3].Y, CogColorConstants.Red, true, true);
                }
                bResult = false;
            }
            else
            {
                if (distYStart[2].Y != 0)
                {
                    DrawLineLabel(P3_DisplayObj, distYStart[2], distYEnd[2], distResult[2].Y, CogColorConstants.Cyan, true, true);
                }
                if (distYStart[3].Y != 0)
                {
                    DrawLineLabel(P4_DisplayObj, distYStart[3], distYEnd[3], distResult[3].Y, CogColorConstants.Cyan, true, true);
                }
            }

            if(bResult==false)
            {
                
                errorCode = Algo4PInsp_FLamiAction.Err_Inspection_Spec_Over;
            }
            #endregion

            #region 8) Log 및 결과값

            AlgoRst = new Algo4PInsp_FLamiResult
            {
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                CurTime = DateTime.Now.ToString("HH:mm:ss"),

                //Name = name,
                ID = sourceID,
                Result = bResult ? "OK" : "NG",
                MainCH = Main_CHNo,
                AlterData = alteredData,
                AlterArea = alterArea,
               
            };

            Algo4PInsp_FLamiResult AlgoResult = AlgoRst as Algo4PInsp_FLamiResult;

            
            if (InsType == InspectionType.D_Lami_Sub)
            {
                // vision -> plc index 맞춰주기
                AlgoResult.Dis3_X = Math.Round(distResult[0].X, 3);
                AlgoResult.Dis3_Y = Math.Round(distResult[0].Y, 3);
                AlgoResult.Dis4_X = Math.Round(distResult[1].X, 3);
                AlgoResult.Dis4_Y = Math.Round(distResult[1].Y, 3);
                AlgoResult.Dis1_X = Math.Round(distResult[2].X, 3);
                AlgoResult.Dis1_Y = Math.Round(distResult[2].Y, 3);
                AlgoResult.Dis2_X = Math.Round(distResult[3].X, 3);
                AlgoResult.Dis2_Y = Math.Round(distResult[3].Y, 3);

                //AlgoResult.UpperCAlign = Math.Round((AlgoResult.Dis1_X - AlgoResult.Dis4_X) / 2.0, 3);
                //AlgoResult.LowerCAlign = Math.Round((AlgoResult.Dis2_X - AlgoResult.Dis3_X) / 2.0, 3);
                //AlgoResult.LeftCAlign = Math.Round((AlgoResult.Dis1_Y - AlgoResult.Dis2_Y) / 2.0, 3);
                //AlgoResult.RightCAlign = Math.Round((AlgoResult.Dis4_Y - AlgoResult.Dis3_Y) / 2.0, 3);

                AlgoResult.UpperCAlign = Math.Round(inspVisionLowerCenter, 3);
                AlgoResult.LowerCAlign = Math.Round(inspVisionUpperCenter, 3);
                AlgoResult.LeftCAlign = Math.Round(inspVisionRightCenter, 3);
                AlgoResult.RightCAlign = Math.Round(inspVisionLeftCenter, 3);
            }
            else if (InsType == InspectionType.M_Lami_Main)
            {
                // vision -> plc index 맞춰주기
                AlgoResult.Dis1_Y = Math.Round(distResult[0].X, 3);
                AlgoResult.Dis1_X = Math.Round(distResult[0].Y, 3);
                AlgoResult.Dis4_Y = Math.Round(distResult[1].X, 3);
                AlgoResult.Dis4_X = Math.Round(distResult[1].Y, 3);
                AlgoResult.Dis3_Y = Math.Round(distResult[2].X, 3);
                AlgoResult.Dis3_X = Math.Round(distResult[2].Y, 3);
                AlgoResult.Dis2_Y = Math.Round(distResult[3].X, 3);
                AlgoResult.Dis2_X = Math.Round(distResult[3].Y, 3);

                //AlgoResult.UpperCAlign = Math.Round((AlgoResult.Dis1_X - AlgoResult.Dis4_X) / 2.0, 3);
                //AlgoResult.LowerCAlign = Math.Round((AlgoResult.Dis2_X - AlgoResult.Dis3_X) / 2.0, 3);
                //AlgoResult.LeftCAlign = Math.Round((AlgoResult.Dis1_Y - AlgoResult.Dis2_Y) / 2.0, 3);
                //AlgoResult.RightCAlign = Math.Round((AlgoResult.Dis4_Y - AlgoResult.Dis3_Y) / 2.0, 3);

                AlgoResult.UpperCAlign = Math.Round(inspVisionLeftCenter, 3);
                AlgoResult.LowerCAlign = Math.Round(inspVisionRightCenter, 3);
                AlgoResult.LeftCAlign = Math.Round(inspVisionUpperCenter, 3);
                AlgoResult.RightCAlign = Math.Round(inspVisionLowerCenter, 3);
            }
            else    //D_Lami_Main, M_Lami_Sub
            {
                // vision -> plc index 맞춰주기
                AlgoResult.Dis4_Y = Math.Round(distResult[0].X, 3);
                AlgoResult.Dis4_X = Math.Round(distResult[0].Y, 3);
                AlgoResult.Dis1_Y = Math.Round(distResult[1].X, 3);
                AlgoResult.Dis1_X = Math.Round(distResult[1].Y, 3);
                AlgoResult.Dis2_Y = Math.Round(distResult[2].X, 3);
                AlgoResult.Dis2_X = Math.Round(distResult[2].Y, 3);
                AlgoResult.Dis3_Y = Math.Round(distResult[3].X, 3);
                AlgoResult.Dis3_X = Math.Round(distResult[3].Y, 3);

                //AlgoResult.UpperCAlign = Math.Round((AlgoResult.Dis1_X - AlgoResult.Dis4_X) / 2.0, 3);
                //AlgoResult.LowerCAlign = Math.Round((AlgoResult.Dis2_X - AlgoResult.Dis3_X) / 2.0, 3);
                //AlgoResult.LeftCAlign = Math.Round((AlgoResult.Dis1_Y - AlgoResult.Dis2_Y) / 2.0, 3);
                //AlgoResult.RightCAlign = Math.Round((AlgoResult.Dis4_Y - AlgoResult.Dis3_Y) / 2.0, 3);

                AlgoResult.UpperCAlign = Math.Round(inspVisionLeftCenter, 3);
                AlgoResult.LowerCAlign = Math.Round(inspVisionRightCenter, 3);
                AlgoResult.LeftCAlign = Math.Round(inspVisionLowerCenter, 3);
                AlgoResult.RightCAlign = Math.Round(inspVisionUpperCenter, 3);
            }

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region 10) FDC Inspection Data Upload 
            //WriteVisionIO() 에서 처리함.
            #endregion

            StopTimer();

            return errorCode == 0 ? true :false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="point"></param>
        /// <param name="edgeRst"></param>
        /// <param name="distRst"></param>
        void CalcDistance(XYT[] point, LineCrossRstData[] edgeRst, ref XY[] distRst)
        {
            //bool bResult = true;
            for (int i = 0; i < 4; i++)
            {
                if ((edgeRst[i].OutputXYT.X == 0 && edgeRst[i].OutputXYT.Y == 0) || (point[i].X == 0 && point[i].Y == 0))
                {
                    distRst[i].X = 0.0;
                    distXStart[i] = new XY(0.0, 0.0);
                    distXEnd[i] = new XY(0.0, 0.0);

                }
                else
                {
                    calcTool.InputImage = edgeRst[i].OutputImage as ICogImage;
                    calcTool.X = point[i].X;
                    calcTool.Y = point[i].Y;
                    //if (edgeRst[i].Lines.Count == 0) return false;

                    calcTool.Line = edgeRst[i].Lines[0] as CogLine;
                    calcTool.Run();

                    if (calcTool.RunStatus.Result == CogToolResultConstants.Accept)
                    {
                        distRst[i].X = calcTool.Distance;
                        distXStart[i] = new XY(calcTool.X, calcTool.Y); // MarkPos
                        distXEnd[i] = new XY(calcTool.LineX, calcTool.LineY); // 접점Pos
                    }
                    else
                    {
                        distRst[i].X = 0.0;
                        distXStart[i] = new XY(0.0, 0.0);
                        distXEnd[i] = new XY(0.0, 0.0);
                    }


                    calcTool.Line = edgeRst[i].Lines[1] as CogLine;
                    calcTool.Run();
                    if (calcTool.RunStatus.Result == CogToolResultConstants.Accept)
                    {
                        distRst[i].Y = calcTool.Distance;
                        distYStart[i] = new XY(calcTool.X, calcTool.Y);
                        distYEnd[i] = new XY(calcTool.LineX, calcTool.LineY);
                    }
                    else
                    {
                        distRst[i].Y = 0.0;
                        distYStart[i] = new XY(0.0, 0.0);
                        distYEnd[i] = new XY(0.0, 0.0);
                    }
                }
            }
        }

        bool CalcDistancePtoP(XYT[] InsideP, XYT[] OutSideP, ref XY[] disRst)
        {
            bool bResult = false;
            if (InsideP.Count() == 4 && OutSideP.Count() == 4)
            {
                if (!(InsideP[0].X == 0 && InsideP[0].Y == 0) && !(OutSideP[0].X == 0 && OutSideP[0].Y == 0))
                {
                    disRst[0].X = InsideP[0].X - OutSideP[0].X;
                    disRst[0].Y = OutSideP[0].Y - InsideP[0].Y;
                }
                if (!(InsideP[1].X == 0 && InsideP[1].Y == 0) && !(OutSideP[1].X == 0 && OutSideP[1].Y == 0))
                {
                    disRst[1].X = InsideP[1].X - OutSideP[1].X;
                    disRst[1].Y = InsideP[1].Y - OutSideP[1].Y;
                }
                if (!(InsideP[2].X == 0 && InsideP[2].Y == 0) && !(OutSideP[2].X == 0 && OutSideP[2].Y == 0))
                {
                    disRst[2].X = OutSideP[2].X - InsideP[2].X;
                    disRst[2].Y = InsideP[2].Y - OutSideP[2].Y;
                }
                if (!(InsideP[3].X == 0 && InsideP[3].Y == 0) && !(OutSideP[3].X == 0 && OutSideP[3].Y == 0))
                {
                    disRst[3].X = OutSideP[3].X - InsideP[3].X;
                    disRst[3].Y = OutSideP[3].Y - InsideP[3].Y;
                }
                for (int i = 0; i < 4; i++)
                {
                    if (!(InsideP[i].X == 0 && InsideP[i].Y == 0) && !(OutSideP[i].X == 0 && OutSideP[i].Y == 0))
                    {
                        distXStart[i].X = InsideP[i].X;
                        distXStart[i].Y = InsideP[i].Y;
                        distXEnd[i].X = OutSideP[i].X;
                        distXEnd[i].Y = InsideP[i].Y;

                        distYStart[i].X = OutSideP[i].X;
                        distYStart[i].Y = InsideP[i].Y;
                        distYEnd[i].X = OutSideP[i].X;
                        distYEnd[i].Y = OutSideP[i].Y;
                    }
                }
                bResult = true;
            }
            else bResult = false;

            return bResult;
        }


        public void F_Judgement(double Num1, double Num2, double Tol, double Center, ref double Result)
        {
            if (Num1 == 0 && Num2 == 0)         //마주보고 있는 마크 모두 못찾아서 NG 해야 하는 경우임.
            {
                // 바라보고 있는 Mark 모두 못찾았으니, Distance는 0이고, 이경우 CenterAlign 계산하면 중심값인 0에 들어옴.
                // <Tol + Center>까지의 값은 허용수치이므로, 임의로 +0.1하여 상위 시스템에서 인지하여 인터락 반영할 수 있도록 했음.
                Result = Tol + Center + 0.1;
            }
            else
            {
                Result = (Num1 - Num2) / 2;
            }
        }


        /// <summary>
        /// calculate point to point
        /// by khoon for m lami main inspection
        /// </summary>
        private bool CalcDistanceP2P(string model, XY[] obj, XY[] tar)
        {
            XY[] objRbt = new XY[4];//metal
            XY[] tarRbt = new XY[4];//panel
            CalDataObject calib = null;

            for (int i = 0; i < 4; i++)
            {
                // vision -> robot
                if (i == 0 || i == 1) calib = CalDataObj_Left;
                else calib = CalDataObj_Right;

                objRbt[i] = calib.GetV2R(model, obj[i], true, true);
                tarRbt[i] = calib.GetV2R(model, tar[i], true, true);
                // overlay 
                //distXStart[i].X = tar[i].X;//panel
                //distXStart[i].Y = obj[i].Y;//metal
                //distXEnd[i].X = obj[i].X;
                //distXEnd[i].Y = obj[i].Y;

                //distYStart[i].X = tar[i].X;//panel
                //distYStart[i].Y = obj[i].Y;//metal
                //distYEnd[i].X = tar[i].X;
                //distYEnd[i].Y = tar[i].Y;
            }
            // calc coord position
            var measureDistanceShift_H = (double)mParams.MeasureDistanceShift_H.Value;
            var measureDistanceShift_V = (double)mParams.MeasureDistanceShift_V.Value;

            //var offset_H = (double)mParams.Inspection_Offset_H.Value;
            //var offset_V = (double)mParams.Inspection_Offset_V.Value;

            double markDist_H = System.Convert.ToDouble(mParams.MarkDistance.Value);
            double markDist_V = System.Convert.ToDouble(mParams.MarkDistance_V.Value);
            if (CalDataObj_Left.GetV2R(model, new XY(0, 0)).X < 0)
                markDist_H *= -1;
            if (CalDataObj_Left.GetV2R(model, new XY(0, 0)).Y >= 0)
                markDist_V *= -1;

            double radH = Math.Asin((objRbt[0].Y - objRbt[3].Y) / markDist_H);
            double camDistH = markDist_H * Math.Cos(radH) + objRbt[3].X - objRbt[0].X;

            double radV = Math.Asin((objRbt[2].X - objRbt[3].X) / markDist_V);
            double camDistV = markDist_V * Math.Cos(radV) + objRbt[3].Y - objRbt[2].Y;
            //
            //  1. 제품이 아래에 붙어있을때      2. 제품이 위에 붙어있을때
            //                        X ←┐                            
            //   0┌─────────┐3 ↓      0┌─────────┐3 
            //    │                  │   Y       │                  │   Y
            //    │                  │           │                  │
            //    │                  │           │                  │
            //    │                  │           │                  │
            //   1└─────────┘2         1└─────────┘2  ↑Y
            //                                                          X ←┘


            XY[] objCoord = new XY[4];
            
            objCoord[0] = new XY(objRbt[0].X + camDistH, objRbt[0].Y);
            objCoord[1] = new XY(objRbt[1].X + camDistH, objRbt[1].Y + camDistV);
            objCoord[2] = new XY(objRbt[2].X, objRbt[2].Y + camDistV);
            objCoord[3] = new XY(objRbt[3].X, objRbt[3].Y);

            XY[] tarCoord = new XY[4];
            tarCoord[0] = new XY(tarRbt[0].X + camDistH, tarRbt[0].Y);
            tarCoord[1] = new XY(tarRbt[1].X + camDistH, tarRbt[1].Y + camDistV);
            tarCoord[2] = new XY(tarRbt[2].X, tarRbt[2].Y + camDistV);
            tarCoord[3] = new XY(tarRbt[3].X, tarRbt[3].Y);


            // Left
            XY tvec = XY.Normalize(tarCoord[1] - tarCoord[0]) * measureDistanceShift_V;
            distResult[0].X = GetCrossDistance(tarCoord[0] + tvec, objCoord[0], objCoord[1]);// + offset_H;
            distResult[1].X = GetCrossDistance(tarCoord[1] - tvec, objCoord[1], objCoord[0]);// + offset_H;

            XY ovec = XY.Normalize(objCoord[1] - objCoord[0]) * DotProduct(tarCoord[0] + tvec, objCoord[0], objCoord[1]);
            distXStart[0] = CalDataObj_Left.GetR2V2d(model, objCoord[0] + ovec - new XY(camDistH, 0));
            distXEnd[0] = CalDataObj_Left.GetR2V2d(model, tarCoord[0] + tvec - new XY(camDistH, 0));

            ovec = XY.Normalize(objCoord[1] - objCoord[0]) * DotProduct(tarCoord[1] - tvec, objCoord[1], objCoord[0]);
            distXStart[1] = CalDataObj_Left.GetR2V2d(model, objCoord[1] - ovec - new XY(camDistH, camDistV));
            distXEnd[1] = CalDataObj_Left.GetR2V2d(model, tarCoord[1] - tvec - new XY(camDistH, camDistV));

            // Bottom
            tvec = XY.Normalize(tarCoord[1] - tarCoord[2]) * measureDistanceShift_H;
            distResult[2].Y = GetCrossDistance(tarCoord[2] + tvec, objCoord[2], objCoord[1]);// + offset_V;
            distResult[1].Y = GetCrossDistance(tarCoord[1] - tvec, objCoord[1], objCoord[2]);// + offset_V;

            ovec = XY.Normalize(objCoord[1] - objCoord[2]) * DotProduct(tarCoord[2] + tvec, objCoord[2], objCoord[1]);
            distYStart[2] = CalDataObj_Right.GetR2V2d(model, objCoord[2] + ovec - new XY(0, camDistV));
            distYEnd[2] = CalDataObj_Right.GetR2V2d(model, tarCoord[2] + tvec - new XY(0, camDistV));

            ovec = XY.Normalize(objCoord[1] - objCoord[2]) * DotProduct(tarCoord[1] - tvec, objCoord[1], objCoord[2]);
            distYStart[1] = CalDataObj_Left.GetR2V2d(model, objCoord[1] - ovec - new XY(camDistH, camDistV));
            distYEnd[1] = CalDataObj_Left.GetR2V2d(model, tarCoord[1] - tvec - new XY(camDistH, camDistV));

            // Right
            tvec = XY.Normalize(tarCoord[2] - tarCoord[3]) * measureDistanceShift_V;
            distResult[3].X = GetCrossDistance(tarCoord[3] + tvec, objCoord[3], objCoord[2]);// + offset_H;
            distResult[2].X = GetCrossDistance(tarCoord[2] - tvec, objCoord[2], objCoord[3]);// + offset_H;

            ovec = XY.Normalize(objCoord[2] - objCoord[3]) * DotProduct(tarCoord[3] + tvec, objCoord[3], objCoord[2]);
            distXStart[3] = CalDataObj_Right.GetR2V2d(model, objCoord[3] + ovec - new XY(0, 0));
            distXEnd[3] = CalDataObj_Right.GetR2V2d(model, tarCoord[3] + tvec - new XY(0, 0));

            ovec = XY.Normalize(objCoord[2] - objCoord[3]) * DotProduct(tarCoord[2] - tvec, objCoord[2], objCoord[3]);
            distXStart[2] = CalDataObj_Right.GetR2V2d(model, objCoord[2] - ovec - new XY(0, camDistV));
            distXEnd[2] = CalDataObj_Right.GetR2V2d(model, tarCoord[2] - tvec - new XY(0, camDistV));

            // Upper
            tvec = XY.Normalize(tarCoord[0] - tarCoord[3]) * measureDistanceShift_H;
            distResult[3].Y = GetCrossDistance(tarCoord[3] + tvec, objCoord[3], objCoord[0]);// + offset_V;
            distResult[0].Y = GetCrossDistance(tarCoord[0] - tvec, objCoord[0], objCoord[3]);// + offset_V;
            
            ovec = XY.Normalize(objCoord[0] - objCoord[3]) * DotProduct(tarCoord[3] + tvec, objCoord[3], objCoord[0]);
            distYStart[3] = CalDataObj_Right.GetR2V2d(model, objCoord[3] + ovec - new XY(0, 0));
            distYEnd[3] = CalDataObj_Right.GetR2V2d(model, tarCoord[3] + tvec - new XY(0, 0));
            ovec = XY.Normalize(objCoord[0] - objCoord[3]) * DotProduct(tarCoord[0] - tvec, objCoord[0], objCoord[3]);
            distYStart[0] = CalDataObj_Left.GetR2V2d(model, objCoord[0] - ovec - new XY(camDistH, 0));
            distYEnd[0] = CalDataObj_Left.GetR2V2d(model, tarCoord[0] - tvec - new XY(camDistH, 0));

            // apply scale
            //for (int i = 0; i < 4; i++)
            //{
            //    distResult[i].X *= scaleParam[i].X;
            //    distResult[i].Y *= scaleParam[i].Y;
            //}

            var offset_X1 = (double)mParams.Inspection_Offset_X1.Value;
            var offset_Y1 = (double)mParams.Inspection_Offset_Y1.Value;
            var offset_X2 = (double)mParams.Inspection_Offset_X2.Value;
            var offset_Y2 = (double)mParams.Inspection_Offset_Y2.Value;
            var offset_X3 = (double)mParams.Inspection_Offset_X3.Value;
            var offset_Y3 = (double)mParams.Inspection_Offset_Y3.Value;
            var offset_X4 = (double)mParams.Inspection_Offset_X4.Value;
            var offset_Y4 = (double)mParams.Inspection_Offset_Y4.Value;

            // apply scale : 자재 기준으로 Scale패러미터 순서 변경
            if (InsType == InspectionType.D_Lami_Sub)
            {
                distResult[2].X *= scaleParam[0].X;
                distResult[2].Y *= scaleParam[0].Y;
                distResult[3].X *= scaleParam[1].X;
                distResult[3].Y *= scaleParam[1].Y;
                distResult[0].X *= scaleParam[2].X;
                distResult[0].Y *= scaleParam[2].Y;
                distResult[1].X *= scaleParam[3].X;
                distResult[1].Y *= scaleParam[3].Y;

                distResult[2].X += offset_X1;
                distResult[2].Y += offset_Y1;
                distResult[3].X += offset_X2;
                distResult[3].Y += offset_Y2;
                distResult[0].X += offset_X3;
                distResult[0].Y += offset_Y3;
                distResult[1].X += offset_X4;
                distResult[1].Y += offset_Y4;
            }
            else if (InsType == InspectionType.M_Lami_Main)
            {
                distResult[0].Y *= scaleParam[0].X;
                distResult[0].X *= scaleParam[0].Y;
                distResult[3].Y *= scaleParam[1].X;
                distResult[3].X *= scaleParam[1].Y;
                distResult[2].Y *= scaleParam[2].X;
                distResult[2].X *= scaleParam[2].Y;
                distResult[1].Y *= scaleParam[3].X;
                distResult[1].X *= scaleParam[3].Y;

                distResult[0].Y += offset_X1;
                distResult[0].X += offset_Y1;
                distResult[3].Y += offset_X2;
                distResult[3].X += offset_Y2;
                distResult[2].Y += offset_X3;
                distResult[2].X += offset_Y3;
                distResult[1].Y += offset_X4;
                distResult[1].X += offset_Y4;
            }
            else    //D_Lami_Main, M_Lami_Sub
            {
                distResult[1].Y *= scaleParam[0].X;
                distResult[1].X *= scaleParam[0].Y;
                distResult[2].Y *= scaleParam[1].X;
                distResult[2].X *= scaleParam[1].Y;
                distResult[3].Y *= scaleParam[2].X;
                distResult[3].X *= scaleParam[2].Y;
                distResult[0].Y *= scaleParam[3].X;
                distResult[0].X *= scaleParam[3].Y;

                distResult[1].Y += offset_X1;
                distResult[1].X += offset_Y1;
                distResult[2].Y += offset_X2;
                distResult[2].X += offset_Y2;
                distResult[3].Y += offset_X3;
                distResult[3].X += offset_Y3;
                distResult[0].Y += offset_X4;
                distResult[0].X += offset_Y4;
            }

            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Robot1_"></param>
        /// <param name="Robot2_"></param>
        /// <param name="panelangle_rad"></param>
        /// <param name="color"></param>
        /// <param name="mode"></param>
        protected void DrawLineLabel(CogDisplayObject P_DisplayObj, XY P1, XY P2, double distRst, CogColorConstants color = CogColorConstants.Cyan, bool bLine = true, bool bLable = true)
        {
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.None;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = color;
            lineInfo.Start.X = P1.X;
            lineInfo.Start.Y = P1.Y;
            lineInfo.End.X = P2.X;
            lineInfo.End.Y = P2.Y;
            //lineInfo.Start += (lineInfo.Start - lineInfo.End);
            //lineInfo.End += (lineInfo.End - lineInfo.Start);
            //if (bLine)
            //    P_DisplayObj.DrawLine(lineInfo);

            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (lineInfo.End + lineInfo.Start) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f3}mm", distRst);
            labelInfo.Color = color;
            if (bLable)
                P_DisplayObj.DrawLabel(labelInfo);
        }

        protected void DrawLineLabel(CogDisplayObject P_DisplayObj, double StartX, double StartY, double EndX, double EndY, double distRst, CogColorConstants color = CogColorConstants.Cyan, bool bLine = true, bool bLable = true)
        {
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidCircle;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = color;
            lineInfo.Start.X = StartX;
            lineInfo.Start.Y = StartY;
            lineInfo.End.X = EndX;
            lineInfo.End.Y = EndY;
            if (bLine)
                P_DisplayObj.DrawLine(lineInfo);


            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (lineInfo.End + lineInfo.Start) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", distRst);
            if (bLable)
                P_DisplayObj.DrawLabel(labelInfo);
        }


        #endregion

        #region Side Methode
        public void UploadFDCdata(Dictionary<string, DisRstData> DisRsts, Dictionary<string, double> RstCenterAlign)
        {
            visionValues["InspectionRev_X"].NextValue = RstCenterAlign["UpperCenterAlign"];
            visionValues["InspectionRev_Y"].NextValue = RstCenterAlign["LowerCenterAlign"];
            visionValues["InspectionRev_T"].NextValue = RstCenterAlign["LeftCenterAlign"];
            visionValues["InspectionRev"].NextValue   = RstCenterAlign["RightCenterAlign"];

            foreach (var _disRst in DisRsts)
            {
                switch(_disRst.Key)
                {
                    case "InsArea1":
                        visionValues["InspDistX1"].NextValue = _disRst.Value.RstDistance.X as object;
                        visionValues["InspDistY1"].NextValue = _disRst.Value.RstDistance.Y as object;
                        break;
                    case "InsArea2":
                        visionValues["InspDistX2"].NextValue = _disRst.Value.RstDistance.X as object;
                        visionValues["InspDistY2"].NextValue = _disRst.Value.RstDistance.Y as object;
                        break;
                    case "InsArea3":
                        visionValues["InspDistX3"].NextValue = _disRst.Value.RstDistance.X as object;
                        visionValues["InspDistY3"].NextValue = _disRst.Value.RstDistance.Y as object;
                        break;
                    case "InsArea4":
                        visionValues["InspDistX4"].NextValue = _disRst.Value.RstDistance.X as object;
                        visionValues["InspDistY4"].NextValue = _disRst.Value.RstDistance.Y as object;
                        break;
                }
            }
        }

        public void CompensateData_X(string _key1, string _key2, ref Dictionary<string, DisRstData> DisRsts, ref bool AlteredData, ref string AlterArea)
        {
            //* Diff = Abs(실제Dis - 이상치 거리) 
            double DiffKey1 = Math.Abs(DisRsts[_key1].RstDistance.X - DisRsts[_key1].DisXY.X);
            double DiffKey2 = Math.Abs(DisRsts[_key2].RstDistance.X - DisRsts[_key2].DisXY.X);
            double RealSumDisXY = DisRsts[_key1].DisXY.X + DisRsts[_key2].DisXY.X;
            if (DiffKey1 > DiffKey2) //* 이상치 대비 큰 쪽을 수정해 줌.
            {
                DisRsts[_key1].RstDistance.X = RealSumDisXY - DisRsts[_key2].RstDistance.X;
                AlteredData = true;
                AlterArea += "(" + _key1 + "_X)";
            }
            else
            {
                DisRsts[_key2].RstDistance.X = RealSumDisXY - DisRsts[_key1].RstDistance.X;
                AlteredData = true;
                AlterArea += "(" + _key2 + "_X)";
            }
        }
        public void CompensateData(double designDis_1, double designDis_2, double resultDis_1, double resultDis_2, ref string AlterArea, string Area,
                                   XY start_L, XY end_L, XY start_R, XY end_R)
        {
            //* Diff = Abs(실제Dis - 이상치 거리) 
            double DiffKey1 = Math.Abs(resultDis_1 - designDis_1);
            double DiffKey2 = Math.Abs(resultDis_2 - designDis_2);
            double designSumDis = designDis_1 + designDis_2;

            string Pos_H = "";
            string Pos_V = "";

            //InspectionType 별로 Label X,Y 표기 맞추기
            switch (InsType)
            {
                case InspectionType.D_Lami_Sub:
                    Pos_H = "Comp.X";
                    Pos_V = "Comp.Y";
                    break;
                case InspectionType.M_Lami_Main:
                    Pos_H = "Comp.Y";
                    Pos_V = "Comp.X";
                    break;
                default:    //D_Lami_Main, M_Lami_Sub
                    Pos_H = "Comp.Y";
                    Pos_V = "Comp.X";
                    break;
            }

            if (resultDis_1 == 0 && resultDis_2 == 0) // 운이 더러워서 마주보는 Dis를 모두 못찾음 '0'이 결과...
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult[0].X = 0;
                        DrawLineLabel_NG(Pos_H, P1_DisplayObj, new XY(1200, 500), distResult[0].X, CogColorConstants.Red, true, true);
                        distResult[3].X = 0;
                        DrawLineLabel_NG(Pos_H, P4_DisplayObj, new XY(1200, 500), distResult[3].X, CogColorConstants.Red, true, true);
                        break;

                    case "X2_X3":
                        distResult[1].X = 0;
                        DrawLineLabel_NG(Pos_H, P2_DisplayObj, new XY(1200, 500), distResult[1].X, CogColorConstants.Red, true, true);
                        distResult[2].X = 0;
                        DrawLineLabel_NG(Pos_H, P3_DisplayObj, new XY(1200, 500), distResult[2].X, CogColorConstants.Red, true, true);
                        break;

                    case "Y1_Y2":
                        distResult[0].Y = 0;
                        DrawLineLabel_NG(Pos_V, P1_DisplayObj, new XY(1200, 700), distResult[0].Y, CogColorConstants.Red, true, true);
                        distResult[1].Y = 0;
                        DrawLineLabel_NG(Pos_V, P2_DisplayObj, new XY(1200, 700), distResult[1].Y, CogColorConstants.Red, true, true);
                        break;

                    case "Y3_Y4":
                        distResult[2].Y = 0;
                        DrawLineLabel_NG(Pos_V, P3_DisplayObj, new XY(1200, 700), distResult[2].Y, CogColorConstants.Red, true, true);
                        distResult[3].Y = 0;
                        DrawLineLabel_NG(Pos_V, P4_DisplayObj, new XY(1200, 700), distResult[3].Y, CogColorConstants.Red, true, true);
                        break;
                }
            }
            else if (DiffKey1 > DiffKey2) //* 이상치 대비 큰 쪽을 수정해 줌.
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult[0].X = designSumDis - distResult[3].X;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            DrawLineLabel_NG(Pos_H, P1_DisplayObj, new XY(1200, 500), distResult[0].X, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "X2_X3":
                        distResult[1].X = designSumDis - distResult[2].X;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            DrawLineLabel_NG(Pos_H, P2_DisplayObj, new XY(1200, 500), distResult[1].X, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "Y1_Y2":
                        distResult[0].Y = designSumDis - distResult[1].Y;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            DrawLineLabel_NG(Pos_V, P1_DisplayObj, new XY(1200, 700), distResult[0].Y, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "Y3_Y4":
                        distResult[2].Y = designSumDis - distResult[3].Y;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            DrawLineLabel_NG(Pos_V, P3_DisplayObj, new XY(1200, 700), distResult[2].Y, CogColorConstants.Red, true, true);
                        }
                        break;
                }
                AlterArea = "(>)";
            }

            else if (DiffKey1 < DiffKey2)
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult[3].X = designSumDis - distResult[0].X;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            DrawLineLabel_NG(Pos_H, P4_DisplayObj, new XY(1200, 500), distResult[3].X, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "X2_X3":
                        distResult[2].X = designSumDis - distResult[1].X;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            DrawLineLabel_NG(Pos_H, P3_DisplayObj, new XY(1200, 500), distResult[2].X, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "Y1_Y2":
                        distResult[1].Y = designSumDis - distResult[0].Y;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            DrawLineLabel_NG(Pos_V, P2_DisplayObj, new XY(1200, 700), distResult[1].Y, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "Y3_Y4":
                        distResult[3].Y = designSumDis - distResult[2].Y;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            DrawLineLabel_NG(Pos_V, P4_DisplayObj, new XY(1200, 700), distResult[2].Y, CogColorConstants.Red, true, true);
                        }
                        break;
                }
                AlterArea = "(<)";
            }
        }
        public void CompensateData_Y(string _key1, string _key2, ref Dictionary<string, DisRstData> DisRsts, ref bool AlteredData, ref string AlterArea)
        {
            double DiffKey1 = Math.Abs(DisRsts[_key1].RstDistance.Y - DisRsts[_key1].DisXY.Y);
            double DiffKey2 = Math.Abs(DisRsts[_key2].RstDistance.Y - DisRsts[_key2].DisXY.Y);
            double RealSumDisXY = DisRsts[_key1].DisXY.Y + DisRsts[_key2].DisXY.Y;
            if (DiffKey1 > DiffKey2)
            {
                DisRsts[_key1].RstDistance.Y = RealSumDisXY - DisRsts[_key2].RstDistance.Y;
                AlteredData = true;
                AlterArea += "(" + _key1 + "_Y)";
            }
            else
            {
                DisRsts[_key2].RstDistance.Y = RealSumDisXY - DisRsts[_key1].RstDistance.Y;
                AlteredData = true;
                AlterArea += "(" + _key1 + "_Y)";
            }
        }

        public bool JudgeInspection(string _key1, string _key2, Dictionary<string, DisRstData> DisRsts, Dictionary<string, double> CenterSpec, Dictionary<string, double> TolSpec, ref Dictionary<string, double> RstCenterAlign)
        {
            string sumKey = _key1 + "_" + _key2;
            double CAlignValue = 0;
            switch (sumKey)
            {
                case "InsArea1_InsArea4":
                    CAlignValue = (DisRsts[_key1].RstDistance.X - DisRsts[_key2].RstDistance.X) / 2;
                    RstCenterAlign.Add("UpperCenterAlign", CAlignValue);
                    if ((CAlignValue > CenterSpec["UpperCenter"] + TolSpec["UpperTol"]) ||
                         CAlignValue < CenterSpec["UpperCenter"] - TolSpec["UpperTol"]) { return false; }
                    break;
                case "InsArea2_InsArea3":
                    CAlignValue = (DisRsts[_key1].RstDistance.X - DisRsts[_key2].RstDistance.X) / 2;
                    RstCenterAlign.Add("LowerCenterAlign", CAlignValue);
                    if ((CAlignValue > CenterSpec["LowerCenter"] + TolSpec["LowerTol"]) ||
                         CAlignValue < CenterSpec["LowerCenter"] - TolSpec["LowerTol"]) { return false; }
                    break;
                case "InsArea1_InsArea2":
                    CAlignValue = (DisRsts[_key1].RstDistance.Y - DisRsts[_key2].RstDistance.Y) / 2;
                    RstCenterAlign.Add("LeftCenterAlign", CAlignValue);
                    if ((CAlignValue > CenterSpec["LeftCenter"] + TolSpec["LeftTol"]) ||
                         CAlignValue < CenterSpec["LeftCenter"] - TolSpec["LeftTol"]) { return false; }
                    break;
                case "InsArea4_InsArea3":
                    CAlignValue = (DisRsts[_key1].RstDistance.Y - DisRsts[_key2].RstDistance.Y) / 2;
                    RstCenterAlign.Add("RightCenterAlign", CAlignValue);
                    if ((CAlignValue > CenterSpec["RightCenter"] + TolSpec["RightTol"]) ||
                         CAlignValue < CenterSpec["RightCenter"] - TolSpec["RightTol"]) { return false; }
                    break;
            }

            return true;
        }


        protected void DrawLineLabel_NG(string Pos_XY, CogDisplayObject P_DisplayObj, XY Pos, double distRst, CogColorConstants color = CogColorConstants.Cyan, bool bLine = true, bool bLable = true)
        {
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = Pos;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = Pos_XY + ":" + string.Format("{0:f3}mm", distRst);
            if (bLable)
                P_DisplayObj.DrawLabel(labelInfo);
        }

        public bool AccuracyCheck_DisX(string _key1, string _key2, Dictionary<string, DisRstData> DisRsts, double AccuracyTh)
        {
            double sumDis = DisRsts[_key1].RstDistance.X + DisRsts[_key2].RstDistance.X; //* 실제sum
            double sumDesignDis = DisRsts[_key1].DisXY.X + DisRsts[_key2].DisXY.X;       //* 이상sum
            if(Math.Abs(sumDis - sumDesignDis) > AccuracyTh) { return false; }
            return true;
        }

        public bool AccuracyCheck_Dis(double designSum, double disSum, double AccuracyTh)
        {
            // double sumDis = DisRsts[_key1].RstDistance.X + DisRsts[_key2].RstDistance.X; //* 실제sum
            // double sumDesignDis = DisRsts[_key1].DisXY.X + DisRsts[_key2].DisXY.X;       //* 이상sum
            if (Math.Abs(disSum - designSum) > AccuracyTh) { return false; }
            return true;
        }

        public bool AccuracyCheck_DisY(string _key1, string _key2, Dictionary<string, DisRstData> DisRsts, double AccuracyTh)
        {
            double sumDis = DisRsts[_key1].RstDistance.Y + DisRsts[_key2].RstDistance.Y; //* 실제sum
            double sumDesignDis = DisRsts[_key1].DisXY.Y + DisRsts[_key2].DisXY.Y;       //* 이상sum
            if (Math.Abs(sumDis - sumDesignDis) > AccuracyTh) { return false; }
            return true;
        }

        public void WriteLabel(XY Point, ref CogDrawLabelInfo labelInfo, XY _location, string _name)
        {
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Color = CogColorConstants.Black;
            //labelInfo.Offset = Point + new XY(20,20);
            labelInfo.Offset = _location;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format(_name + "({0:f2},{0:f2})", Point.X, Point.Y);
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineLeft;
        }

        public void WriteLabel(XY startPoint, XY endPoint, double Dis, ref CogDrawLabelInfo labelInfo, XY _location, string _name)
        {            
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Color = CogColorConstants.Red;
            labelInfo.Offset = new XY((startPoint+ endPoint)/2) + _location;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("Dis" + _name + ": {0:f2}um", Dis);
        }

        public void LineDraw(XY startPoint, XY endPoint, ref CogDrawLineInfo DisLine)
        {
            DisLine.LineWidthInScreenPixels = 2;
            DisLine.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            DisLine.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            DisLine.Color = CogColorConstants.Red;
            DisLine.Start = startPoint;
            DisLine.End = endPoint;
        }
        public void MarkDraw(XYT Point, ref CogDrawMarkerInfo ContactPoint)
        {
            // Contact Point_X    
            ContactPoint.SizeInScreenPixels = 2;
            ContactPoint.Color = CogColorConstants.Purple;
            ContactPoint.Offset = Point;
        }

        protected bool InitInsp_Err(ref Dictionary<string, bool> errCode)
        {
            errCode.Add("Err_Obtain_InputData", true);
            errCode.Add("Err_Cal_MarkToLine", true);
            return true;
        }


        public override void DefaultIOSet()
        {
            base.DefaultIOSet();

            plcValues = new Dictionary<string, IOStruct>();
            visionValues = new Dictionary<string, IOStruct>();



            // 해당 하는 io를 가져온다.
            //PlcIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();
            //VisionIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();

            plcValues.Clear();
            visionValues.Clear();


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    PlcIOs.Add(item);
                    plcValues.Add(item.Key, item);
                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if ((item.Type.Name != "Boolean" && !item.Key.Contains("Reserve")) || item.Key.Contains("InspectionOK") || item.Key.Contains("InspectionNG"))
                {
                    VisionIOs.Add(item);
                    visionValues.Add(item.Key, item);
                }
            }
        }
        public override void ObjectInitialize()
        {
            base.ObjectInitialize();

            if (AlignTableObject == null) return;


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    if (!plcValues.ContainsKey(item.Key))
                    {
                        plcValues.Add(item.Key, item);
                    }

                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if ((item.Type.Name != "Boolean" && !item.Key.Contains("Reserve")) || item.Key.Contains("InspectionOK") || item.Key.Contains("InspectionNG"))
                {
                    if (!visionValues.ContainsKey(item.Key))
                    {
                        visionValues.Add(item.Key, item);
                    }
                }
            }
        }

        protected bool InputDataConfirm(ref Dictionary<string, object> InputData, ref Dictionary<string, bool> errCode)
        {
            try
            {
                InputData["InsArea1"] = InputValues["InsArea1"] as Dictionary<string, object>;
                InputData["InsArea2"] = InputValues["InsArea2"] as Dictionary<string, object>;
                InputData["InsArea3"] = InputValues["InsArea3"] as Dictionary<string, object>;
                InputData["InsArea4"] = InputValues["InsArea4"] as Dictionary<string, object>;

                foreach (var pair in InputData)
                {
                    if (pair.Value == null)
                    {
                        errCode["Err_Obtain_InputData"] = false;
                        return false;
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                errCode["Err_Obtain_InputData"] = false;
                return false;
            }
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void ObjectUpdate()
        {
            base.ObjectUpdate();

            PlcIOsListConverter.Module = CommObj;
            VisionIOsListConverter.Module = CommObj;
        }

        public void WriteVisionIO(XYT rev1, XY[] insp, string ID)
        {
            var IOs = new List<IOStruct>();

            // 미사용 - 기존 관리항목이라 유지함
            VisionValues["InspectRev_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["InspectRev_X"]);
            VisionValues["InspectRev_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["InspectRev_Y"]);
            VisionValues["InspectRev_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["InspectRev_T"]);

            var algoRst = AlgoRst as Algo4PInsp_FLamiResult;

            VisionValues["Align_Upper_X"].NextValue = algoRst.UpperCAlign; IOs.Add(VisionValues["Align_Upper_X"]);
            VisionValues["Align_Lower_X"].NextValue = algoRst.LowerCAlign; IOs.Add(VisionValues["Align_Lower_X"]);
            VisionValues["Align_Left_Y"].NextValue = algoRst.LeftCAlign; IOs.Add(VisionValues["Align_Left_Y"]);
            VisionValues["Align_Right_Y"].NextValue = algoRst.RightCAlign; IOs.Add(VisionValues["Align_Right_Y"]);

            VisionValues["InspDistX1"].NextValue = algoRst.Dis1_X; IOs.Add(VisionValues["InspDistX1"]);
            VisionValues["InspDistY1"].NextValue = algoRst.Dis1_Y; IOs.Add(VisionValues["InspDistY1"]);
            VisionValues["InspDistX2"].NextValue = algoRst.Dis2_X; IOs.Add(VisionValues["InspDistX2"]);
            VisionValues["InspDistY2"].NextValue = algoRst.Dis2_Y; IOs.Add(VisionValues["InspDistY2"]);
            VisionValues["InspDistX3"].NextValue = algoRst.Dis3_X; IOs.Add(VisionValues["InspDistX3"]);
            VisionValues["InspDistY3"].NextValue = algoRst.Dis3_Y; IOs.Add(VisionValues["InspDistY3"]);
            VisionValues["InspDistX4"].NextValue = algoRst.Dis4_X; IOs.Add(VisionValues["InspDistX4"]);
            VisionValues["InspDistY4"].NextValue = algoRst.Dis4_Y; IOs.Add(VisionValues["InspDistY4"]);

            //if(algoRst.BResult)
            //{
            //    VisionValues["InspectionOK"].NextValue = true; IOs.Add(VisionValues["InspectionOK"]);
            //    VisionValues["InspectionNG"].NextValue = false; IOs.Add(VisionValues["InspectionNG"]);
            //}
            //else
            //{
            //    VisionValues["InspectionOK"].NextValue = false; IOs.Add(VisionValues["InspectionOK"]);
            //    VisionValues["InspectionNG"].NextValue = true; IOs.Add(VisionValues["InspectionNG"]);
            //}

            CommodObject.SetVisionValues(IOs);
        }

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (cogDisp == null) return;
            Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }

        public void ImageSave(DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (pointRst == null || pointRst.Length == 0) return;
            for (int i = 0; i < pointRst.Length; i++)
            {
                if(pointRst[i] != null && pointRst[i].DisplayObj != null)
                {
                    ImageSave(pointRst[i].DisplayObj as CogDisplayObject, dateTime, rst, strPath);
                }
            }
        }



        #endregion
    }
}
