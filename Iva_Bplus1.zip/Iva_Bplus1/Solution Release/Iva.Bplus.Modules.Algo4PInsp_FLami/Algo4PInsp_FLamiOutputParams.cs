﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo4PInsp_FLami
{
    class Algo4PInsp_FLamiOutputParams : OutputParams
    {
        public object LogResult { get; set; }
    }
}
