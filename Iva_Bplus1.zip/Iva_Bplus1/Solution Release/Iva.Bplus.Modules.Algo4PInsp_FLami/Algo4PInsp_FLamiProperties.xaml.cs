﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Iva.Bplus.Modules.Algo4PInsp_FLami // Algo90DBendedLami_4P_
{
    /// <summary>
    /// CameraProperties.xaml에 대한 상호 작용 논리
    /// </summary>
    /// 

    public partial class Algo4PInsp_FLamiProperties : UserControl
    {
        public Algo4PInsp_FLamiProperties()
        {
            InitializeComponent();
        }

    }
}

