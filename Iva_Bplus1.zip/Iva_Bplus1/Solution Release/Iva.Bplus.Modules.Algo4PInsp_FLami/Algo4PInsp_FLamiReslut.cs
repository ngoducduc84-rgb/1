﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4PInsp_FLami
{
    [SerializableAttribute]
    public class Algo4PInsp_FLamiResult : AlgoResultBase
    {
        //private string productID;
        #region [field]
        private string _rst;
        private bool _bResult;
        private double _upperCAlign;
        private double _lowerCAlign;
        private double _leftCAlign;
        private double _rightCAlign;

        private double _dis1_X;
        private double _dis1_Y;
        private double _dis2_X;
        private double _dis2_Y;
        private double _dis3_X;
        private double _dis3_Y;
        private double _dis4_X;
        private double _dis4_Y;

        //private double _dis1_X_test;
        //private double _dis1_Y_test;
        //private double _dis2_X_test;
        //private double _dis2_Y_test;
        //private double _dis3_X_test;
        //private double _dis3_Y_test;
        //private double _dis4_X_test;
        //private double _dis4_Y_test;

        private bool   _alterData;
        private string _alterArea;
        private int _mainCH;
        #endregion

        #region Default properties
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }

        public bool BResult
        {
            get { return _bResult; }
            set { if (value == _bResult) return; _bResult = value; OnPropertyChanged(nameof(BResult)); }
        }
        #endregion

        #region Result Property
        public string Result
        {
            get { return _rst; }
            set
            {
                if (value == _rst) return;
                _rst = value;
                OnPropertyChanged("Result");
            }
        }
        public int MainCH
        {
            get { return _mainCH; }
            set
            {
                if (value == _mainCH) return;
                _mainCH = value;
                this.OnPropertyChanged(nameof(MainCH));
            }
        }
        #endregion

        #region CenterAlign
        public double UpperCAlign
        {
            get { return _upperCAlign; }
            set
            {
                if (value == _upperCAlign) return;
                _upperCAlign = value;
                OnPropertyChanged("UpperCAlign");
            }
        }

        public double LowerCAlign
        {
            get { return _lowerCAlign; }
            set
            {
                if (value == _lowerCAlign) return;
                _lowerCAlign = value;
                OnPropertyChanged("LowerCAlign");
            }
        }

        public double LeftCAlign
        {
            get { return _leftCAlign; }
            set
            {
                if (value == _leftCAlign) return;
                _leftCAlign = value;

                OnPropertyChanged("LeftCAlign");
            }
        }

        public double RightCAlign
        {
            get { return _rightCAlign; }
            set
            {
                if (value == _rightCAlign) return;
                _rightCAlign = value;

                OnPropertyChanged("RightCAlign");
            }
        }
        #endregion

        #region Target RevX,Y,T 
        public double Dis1_X
        {
            get { return _dis1_X; }
            set
            {
                if (value == _dis1_X) return;
                _dis1_X = value;
                this.OnPropertyChanged(nameof(Dis1_X));
            }
        }

        public double Dis1_Y
        {
            get { return _dis1_Y; }
            set
            {
                if (value == _dis1_Y) return;
                _dis1_Y = value;
                this.OnPropertyChanged(nameof(Dis1_Y));
            }
        }

        public double Dis2_X
        {
            get { return _dis2_X; }
            set
            {
                if (value == _dis2_X) return;
                _dis2_X = value;
                this.OnPropertyChanged(nameof(Dis2_X));
            }
        }

        public double Dis2_Y
        {
            get { return _dis2_Y; }
            set
            {
                if (value == _dis2_Y) return;
                _dis2_Y = value;
                this.OnPropertyChanged(nameof(Dis2_Y));
            }
        }

        public double Dis3_X
        {
            get { return _dis3_X; }
            set
            {
                if (value == _dis3_X) return;
                _dis3_X = value;
                this.OnPropertyChanged(nameof(Dis3_X));
            }
        }

        public double Dis3_Y
        {
            get { return _dis3_Y; }
            set
            {
                if (value == _dis3_Y) return;
                _dis3_Y = value;
                this.OnPropertyChanged(nameof(Dis3_Y));
            }
        }

        public double Dis4_X
        {
            get { return _dis4_X; }
            set
            {
                if (value == _dis4_X) return;
                _dis4_X = value;
                this.OnPropertyChanged(nameof(Dis4_X));
            }
        }

        public double Dis4_Y
        {
            get { return _dis4_Y; }
            set
            {
                if (value == _dis4_Y) return;
                _dis4_Y = value;
                this.OnPropertyChanged(nameof(Dis4_Y));
            }
        }





        //public double Dis1_X_test
        //{
        //    get { return _dis1_X_test; }
        //    set
        //    {
        //        if (value == _dis1_X_test) return;
        //        _dis1_X_test = value;
        //        this.OnPropertyChanged(nameof(Dis1_X_test));
        //    }
        //}

        //public double Dis1_Y_test
        //{
        //    get { return _dis1_Y_test; }
        //    set
        //    {
        //        if (value == _dis1_Y_test) return;
        //        _dis1_Y_test = value;
        //        this.OnPropertyChanged(nameof(Dis1_Y_test));
        //    }
        //}

        //public double Dis2_X_test
        //{
        //    get { return _dis2_X_test; }
        //    set
        //    {
        //        if (value == _dis2_X_test) return;
        //        _dis2_X_test = value;
        //        this.OnPropertyChanged(nameof(Dis2_X_test));
        //    }
        //}

        //public double Dis2_Y_test
        //{
        //    get { return _dis2_Y_test; }
        //    set
        //    {
        //        if (value == _dis2_Y_test) return;
        //        _dis2_Y_test = value;
        //        this.OnPropertyChanged(nameof(Dis2_Y_test));
        //    }
        //}

        //public double Dis3_X_test
        //{
        //    get { return _dis3_X_test; }
        //    set
        //    {
        //        if (value == _dis3_X_test) return;
        //        _dis3_X_test = value;
        //        this.OnPropertyChanged(nameof(Dis3_X_test));
        //    }
        //}

        //public double Dis3_Y_test
        //{
        //    get { return _dis3_Y_test; }
        //    set
        //    {
        //        if (value == _dis3_Y_test) return;
        //        _dis3_Y_test = value;
        //        this.OnPropertyChanged(nameof(Dis3_Y_test));
        //    }
        //}

        //public double Dis4_X_test
        //{
        //    get { return _dis4_X_test; }
        //    set
        //    {
        //        if (value == _dis4_X_test) return;
        //        _dis4_X_test = value;
        //        this.OnPropertyChanged(nameof(Dis4_X_test));
        //    }
        //}

        //public double Dis4_Y_test
        //{
        //    get { return _dis4_Y_test; }
        //    set
        //    {
        //        if (value == _dis4_Y_test) return;
        //        _dis4_Y_test = value;
        //        this.OnPropertyChanged(nameof(Dis4_Y_test));
        //    }
        //}
        #endregion


        #region Alter Data,Area
        public bool AlterData
        {
            get { return _alterData; }
            set
            {
                if (value == _alterData) return;
                _alterData = value;
                this.OnPropertyChanged(nameof(AlterData));
            }
        }

        public string AlterArea
        {
            get { return _alterArea; }
            set
            {
                if (value == _alterArea) return;
                _alterArea = value;
                this.OnPropertyChanged(nameof(AlterArea));
            }
        }

       
        #endregion


        public Algo4PInsp_FLamiResult()
        {
        }

        #region [Properties]   
        #endregion

        public override string ToString()
        {
            return string.Format("{0} :\n "             +
                                  "curDate: {1}\n, "    +
                                  "curTime: {2}\n,"     +
                                  "productID: {3}\n,"   +
                                  "Result:{4}\n,"       +
                                   "CHNo: {5}\n,"       +
                                  "UpperCAlign: {6}\n," +
                                  "LowerCAlign: {7}\n," +
                                  "LeftCAlign: {8}\n," +
                                  "RightCAlign: {9}\n," +

                                  "dis1_X: {10}\n,"  +
                                  "dis1_Y: {11}\n,"  +
                                  "dis2_X: {12}\n," +
                                  "dis2_Y: {13}\n," +
                                  "dis3_X: {14}\n," +
                                  "dis3_Y: {15}\n," +
                                  "dis4_X: {16}\n," +
                                  "dis4_Y: {17}\n," +
                                  
                                  "AlterData: {18}\n" +
                                  "AlterArea: {19}\n," 
                                 
                                  , typeof(Algo4PInsp_FLamiResult).ToString()
                                  , curDate
                                  , curTime
                                  , id
                                  , _bResult
                                  , _mainCH
                                  , _upperCAlign
                                  , _lowerCAlign
                                  , _leftCAlign
                                  , _rightCAlign 

                                  , _dis1_X
                                  , _dis1_Y
                                  , _dis2_X
                                  , _dis2_Y
                                  , _dis3_X
                                  , _dis3_Y
                                  , _dis4_X
                                  , _dis4_Y
                                  , _alterData
                                  , _alterArea
                                  
                                  );
        }
    }
}
