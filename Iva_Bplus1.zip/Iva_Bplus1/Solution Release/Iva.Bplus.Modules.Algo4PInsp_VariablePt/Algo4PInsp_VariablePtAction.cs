﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo4PInsp_VariablePt;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4PInsp_VariablePt
{
    [SerializableAttribute]
    public partial class Algo4PInsp_VariablePtAction : AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private double cur_X1;
        [field: NonSerialized]
        private double cur_X2;
        [field: NonSerialized]
        private double cur_X3;
        [field: NonSerialized]
        private double cur_X4;
        [field: NonSerialized]
        private double cur_Y1;
        [field: NonSerialized]
        private double cur_Y2;
        [field: NonSerialized]
        private double cur_Y3;
        [field: NonSerialized]
        private double cur_Y4;

        [field: NonSerialized]
        private double mea_X1;
        [field: NonSerialized]
        private double mea_X2;
        [field: NonSerialized]
        private double mea_X3;
        [field: NonSerialized]
        private double mea_X4;
        [field: NonSerialized]
        private double mea_Y1;
        [field: NonSerialized]
        private double mea_Y2;
        [field: NonSerialized]
        private double mea_Y3;
        [field: NonSerialized]
        private double mea_Y4;
        #endregion

        #region [Properties]  
        public double CurX1 { get { return cur_X1; } set { if (cur_X1 == value) return; cur_X1 = value; this.OnPropertyChanged(nameof(CurX1)); } }
        public double CurX2 { get { return cur_X2; } set { if (cur_X2 == value) return; cur_X2 = value; this.OnPropertyChanged(nameof(CurX2)); } }
        public double CurX3 { get { return cur_X3; } set { if (cur_X3 == value) return; cur_X3 = value; this.OnPropertyChanged(nameof(CurX3)); } }
        public double CurX4 { get { return cur_X4; } set { if (cur_X4 == value) return; cur_X4 = value; this.OnPropertyChanged(nameof(CurX4)); } }
        public double CurY1 { get { return cur_Y1; } set { if (cur_Y1 == value) return; cur_Y1 = value; this.OnPropertyChanged(nameof(CurY1)); } }
        public double CurY2 { get { return cur_Y2; } set { if (cur_Y2 == value) return; cur_Y2 = value; this.OnPropertyChanged(nameof(CurY2)); } }
        public double CurY3 { get { return cur_Y3; } set { if (cur_Y3 == value) return; cur_Y3 = value; this.OnPropertyChanged(nameof(CurY3)); } }
        public double CurY4 { get { return cur_Y4; } set { if (cur_Y4 == value) return; cur_Y4 = value; this.OnPropertyChanged(nameof(CurY4)); } }

        public double MeaX1 { get { return mea_X1; } set { if (mea_X1 == value) return; mea_X1 = value; this.OnPropertyChanged(nameof(MeaX1)); } }
        public double MeaX2 { get { return mea_X2; } set { if (mea_X2 == value) return; mea_X2 = value; this.OnPropertyChanged(nameof(MeaX2)); } }
        public double MeaX3 { get { return mea_X3; } set { if (mea_X3 == value) return; mea_X3 = value; this.OnPropertyChanged(nameof(MeaX3)); } }
        public double MeaX4 { get { return mea_X4; } set { if (mea_X4 == value) return; mea_X4 = value; this.OnPropertyChanged(nameof(MeaX4)); } }
        public double MeaY1 { get { return mea_Y1; } set { if (mea_Y1 == value) return; mea_Y1 = value; this.OnPropertyChanged(nameof(MeaY1)); } }
        public double MeaY2 { get { return mea_Y2; } set { if (mea_Y2 == value) return; mea_Y2 = value; this.OnPropertyChanged(nameof(MeaY2)); } }
        public double MeaY3 { get { return mea_Y3; } set { if (mea_Y3 == value) return; mea_Y3 = value; this.OnPropertyChanged(nameof(MeaY3)); } }
        public double MeaY4 { get { return mea_Y4; } set { if (mea_Y4 == value) return; mea_Y4 = value; this.OnPropertyChanged(nameof(MeaY4)); } }
        #endregion

        #region [Construct]

        public Algo4PInsp_VariablePtAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo4PInsp_VariablePtInputParams();
            OutputParams = new Algo4PInsp_VariablePtOutputParams();

            var obj = _object as Algo4PInsp_VariablePtObject;
            obj.ModelParamType = typeof(Algo4PInsp_VariablePtModelParams);
            var param = obj.CurParams as Algo4PInsp_VariablePtModelParams;

            ChildSettingView = new ModelParams_Setting();
            ChildSettingView.DataContext = ModObject;

            ChildSettingView = new ModelParams_Setting();
            ChildSettingView.DataContext = this;
        }
        #endregion

        private void ModObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
        }

        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args);

            var Obj = modObject as Algo4PInsp_VariablePtObject;

            if (InputName.Equals("Trigger") || InputName.Equals(""))
            {
                StartTimer();

                #region Step1 : Calc
                Obj.Name = name;
                Obj.SourceID = ObjectID;
                DateTime dateTime = DateTime.Now;

                //ReplyArgs.Clear();

                if (!Obj.Run())
                {
                    // 기존값들 초기화 필요함.
                    //SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);

                    //Inspection 일때 NG 치면 로그 안써줌...15022 알람인경우 로그도 남겨주자.. 왜이렇게 해야 되지... 
                    if (Obj.ErrorCode == 15022)
                        ReplyArgs = OutputPlay("LogResult", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait); // Log에 대한 DataGridView에 넘겨줌    
                    else
                        OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    return OccurError(Obj.ErrorCode);
                }
                else
                {
                    ReplyArgs = OutputPlay("LogResult", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait); // Log에 대한 DataGridView에 넘겨줌    

                    Obj.AppendMessage(Name, "Inspection Complete");
                }
                #endregion
                StopTimer();
            }

            return End(false);
        }

        public void classifyErrCode(Dictionary<string, bool> ErrCode)
        {
            foreach (KeyValuePair<string, bool> pair in ErrCode)
            {
                if (pair.Value == false)
                {
                    switch (pair.Key)
                    {
                        case "Err_Obtain_InputData":
                            //ReplyArgs.AddRange(OccurError(E15414_Failed_Obtain_InsInputData_Value));
                            break;
                        case "Err_Cal_MarkToLine":
                            //ReplyArgs.AddRange(OccurError(E15415_Failed_Calculate_Distance));
                            break;
                    }
                }
            }
        }

        [field: NonSerialized]
        private DelegateCommand scaleResetCommand;
        public DelegateCommand ScaleResetCommand
        {
            get
            {
                return scaleResetCommand = scaleResetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo4PInsp_VariablePtModelParams;

                    tmp.ScaleX1.Value = (double)1.0;
                    tmp.ScaleX2.Value = (double)1.0;
                    tmp.ScaleX3.Value = (double)1.0;
                    tmp.ScaleX4.Value = (double)1.0;

                    tmp.ScaleY1.Value = (double)1.0;
                    tmp.ScaleY2.Value = (double)1.0;
                    tmp.ScaleY3.Value = (double)1.0;
                    tmp.ScaleY4.Value = (double)1.0;

                    Obj.UpdateTempValues();

                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand scaleCalcCommand;
        public DelegateCommand ScaleCalcCommand
        {
            get
            {
                return scaleCalcCommand = scaleCalcCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo4PInsp_VariablePtModelParams;

                    tmp.ScaleX1.Value = (double)(mea_X1 / cur_X1);
                    tmp.ScaleX2.Value = (double)(mea_X2 / cur_X2);
                    tmp.ScaleX3.Value = (double)(mea_X3 / cur_X3);
                    tmp.ScaleX4.Value = (double)(mea_X4 / cur_X4);

                    tmp.ScaleY1.Value = (double)(mea_Y1 / cur_Y1);
                    tmp.ScaleY2.Value = (double)(mea_Y2 / cur_Y2);
                    tmp.ScaleY3.Value = (double)(mea_Y3 / cur_Y3);
                    tmp.ScaleY4.Value = (double)(mea_Y4 / cur_Y4);

                    CurX1 *= (double)tmp.ScaleX1.Value;
                    CurX2 *= (double)tmp.ScaleX2.Value;
                    CurX3 *= (double)tmp.ScaleX3.Value;
                    CurX4 *= (double)tmp.ScaleX4.Value;

                    CurY1 *= (double)tmp.ScaleY1.Value;
                    CurY2 *= (double)tmp.ScaleY2.Value;
                    CurY3 *= (double)tmp.ScaleY3.Value;
                    CurY4 *= (double)tmp.ScaleY4.Value;

                    // 업뎃
                    Obj.UpdateTempValues();
                });

            }
        }

        public override void Dispose()
        {
            base.Dispose();
        }

    }
}
