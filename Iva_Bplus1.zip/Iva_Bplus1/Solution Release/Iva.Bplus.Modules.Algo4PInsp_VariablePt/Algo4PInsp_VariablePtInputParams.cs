﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;
using System;
using System.Collections.Generic;


namespace Iva.Bplus.Modules.Algo4PInsp_VariablePt
{

    [SerializableAttribute]
    class Algo4PInsp_VariablePtInputParams : InputParams
    {
        // Align 방식 
        //  (X1,Y1) -----------------------(X4,Y4)
        //    |                               l
        //    |                               l
        //    l                               l
        //    |                               |        Lower 찍고, Upper로 이동!
        //    l                               l         
        //    l                               l
        //  (X2,Y2) -----------------------(X3,Y3)
        //     '작업자' 방향

        //public object Out_1 { get; set; }
        //public object  In_1 { get; set; }
        //public object Out_2 { get; set; }
        //public object  In_2 { get; set; }
        //public object Out_3 { get; set; }
        //public object  In_3 { get; set; }
        //public object Out_4 { get; set; }
        //public object  In_4{ get; set; }

        private object _out_Fnt_L;
        public object Out_Frnt_L
        {
            get { return _out_Fnt_L;  }
            set { _out_Fnt_L = value; }
        }

        private object _in_Fnt_L;
        public object In_Frnt_L
        {
            get { return _in_Fnt_L; }
            set { _in_Fnt_L = value; }
        }

        private object _out_Fnt_R;
        public object Out_Frnt_R
        {
            get { return _out_Fnt_R; }
            set { _out_Fnt_R = value; }
        }

        private object _in_Fnt_R;
        public object In_Frnt_R
        {
            get { return _in_Fnt_R; }
            set { _in_Fnt_R = value; }
        }

        private object _out_Rear_L;
        public object Out_Rear_L
        {
            get { return _out_Rear_L; }
            set { _out_Rear_L = value; }
        }

        private object _in_Rear_L;
        public object In_Rear_L
        {
            get { return _in_Rear_L; }
            set { _in_Rear_L = value; }
        }

        private object _out_Rear_R;
        public object Out_Rear_R
        {
            get { return _out_Rear_R; }
            set { _out_Rear_R = value; }
        }

        private object _in_Rear_R;
        public object In_Rear_R
        {
            get { return _in_Rear_R; }
            set { _in_Rear_R = value; }
        }

        public CalcTrigger Trigger { get; set; }
    }
}
