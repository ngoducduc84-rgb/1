﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo4PInsp_VariablePt
{
    [SerializableAttribute]

    public partial class Algo4PInsp_VariablePtModelParams : AlgoParams
    {
        #region [field]

        #region Dis 진/가성 판정 field
        private AlgoParam _DisInterval;
        // ex) 측정(Dis1 + Dis4) -  이상적(Dis1 + Dis4) > '_JudgeTh' ---> 'NG'
        private AlgoParam _AccuracyTh;
        #endregion

        #region Resolution
        private AlgoParam _Resolution;
        #endregion

        #region Scale
        private AlgoParam _Pos1ScaleX;
        private AlgoParam _Pos1ScaleY;
        private AlgoParam _Pos2ScaleX;
        private AlgoParam _Pos2ScaleY;
        private AlgoParam _Pos3ScaleX;
        private AlgoParam _Pos3ScaleY;
        private AlgoParam _Pos4ScaleX;
        private AlgoParam _Pos4ScaleY;
        #endregion

        #region Param(New)
        private AlgoParam _Pos1OffsetX;
        private AlgoParam _Pos1OffsetY;
        private AlgoParam _Pos2OffsetX;
        private AlgoParam _Pos2OffsetY;
        private AlgoParam _Pos3OffsetX;
        private AlgoParam _Pos3OffsetY;
        private AlgoParam _Pos4OffsetX;
        private AlgoParam _Pos4OffsetY;
        #endregion

        #region Each Position Distance Spec  
        private AlgoParam _DisX1;
        private AlgoParam _DisX2;
        private AlgoParam _DisX3;
        private AlgoParam _DisX4;
        private AlgoParam _DisY1;
        private AlgoParam _DisY2;
        private AlgoParam _DisY3;
        private AlgoParam _DisY4;
        #endregion

        #region Spec & Tol
        private AlgoParam _UpperCenter;
        private AlgoParam _LowerCenter;
        private AlgoParam _LeftCenter;
        private AlgoParam _RightCenter;

        private AlgoParam _UpperTol;
        private AlgoParam _LowerTol;
        private AlgoParam _LeftTol;
        private AlgoParam _RightTol;

        //private AlgoParam _Cpk;
        #endregion
        #endregion

        #region[Properties]
        #region Dis 진/가성 판정 Properties
        public AlgoParam DisInterval
        {
            get { return _DisInterval; }
            set
            {
                if (_DisInterval == value) return;
                _DisInterval = value;
                this.OnPropertyChanged(nameof(_DisInterval));
            }
        }

        public AlgoParam AccuracyTh
        {
            get { return _AccuracyTh; }
            set
            {
                if (_AccuracyTh == value) return;
                _AccuracyTh = value;
                this.OnPropertyChanged(nameof(AccuracyTh));
            }
        }
        #endregion

        #region Resolution Properties
        public AlgoParam Resolution
        {
            get { return _Resolution; }
            set
            {
                if (_Resolution == value) return;
                _Resolution = value;
                this.OnPropertyChanged(nameof(Resolution));
            }
        }

        //public AlgoParam ScaleX1 { get; }
        #endregion

        #region Scale Properties
        public AlgoParam ScaleX1
        {
            get { return _Pos1ScaleX; }
            set
            {
                if (_Pos1ScaleX == value) return;
                _Pos1ScaleX = value;
                this.OnPropertyChanged(nameof(ScaleX1));
            }
        }
        public AlgoParam ScaleY1
        {
            get { return _Pos1ScaleY; }
            set
            {
                if (_Pos1ScaleY == value) return;
                _Pos1ScaleY = value;
                this.OnPropertyChanged(nameof(ScaleY1));
            }
        }
        public AlgoParam ScaleX2
        {
            get { return _Pos2ScaleX; }
            set
            {
                if (_Pos2ScaleX == value) return;
                _Pos2ScaleX = value;
                this.OnPropertyChanged(nameof(ScaleX2));
            }
        }
        public AlgoParam ScaleY2
        {
            get { return _Pos2ScaleY; }
            set
            {
                if (_Pos2ScaleY == value) return;
                _Pos2ScaleY = value;
                this.OnPropertyChanged(nameof(ScaleY2));
            }
        }
        public AlgoParam ScaleX3
        {
            get { return _Pos3ScaleX; }
            set
            {
                if (_Pos3ScaleX == value) return;
                _Pos3ScaleX = value;
                this.OnPropertyChanged(nameof(ScaleX3));
            }
        }
        public AlgoParam ScaleY3
        {
            get { return _Pos3ScaleY; }
            set
            {
                if (_Pos3ScaleY == value) return;
                _Pos3ScaleY = value;
                this.OnPropertyChanged(nameof(ScaleY3));
            }
        }
        public AlgoParam ScaleX4
        {
            get { return _Pos4ScaleX; }
            set
            {
                if (_Pos4ScaleX == value) return;
                _Pos4ScaleX = value;
                this.OnPropertyChanged(nameof(ScaleX4));
            }
        }
        public AlgoParam ScaleY4
        {
            get { return _Pos4ScaleY; }
            set
            {
                if (_Pos4ScaleY == value) return;
                _Pos4ScaleY = value;
                this.OnPropertyChanged(nameof(ScaleY4));
            }
        }
        #endregion

        #region _Offset Properties(New)
        public AlgoParam Pos1OffsetX
        {
            get { return _Pos1OffsetX; }
            set
            {
                if (_Pos1OffsetX == value) return;
                _Pos1OffsetX = value;
                this.OnPropertyChanged(nameof(Pos1OffsetX));
            }
        }
        public AlgoParam Pos1OffsetY
        {
            get { return _Pos1OffsetY; }
            set
            {
                if (_Pos1OffsetY == value) return;
                _Pos1OffsetY = value;
                this.OnPropertyChanged(nameof(Pos1OffsetY));
            }
        }
        public AlgoParam Pos2OffsetX
        {
            get { return _Pos2OffsetX; }
            set
            {
                if (_Pos2OffsetX == value) return;
                _Pos2OffsetX = value;
                this.OnPropertyChanged(nameof(Pos2OffsetX));
            }
        }
        public AlgoParam Pos2OffsetY
        {
            get { return _Pos2OffsetY; }
            set
            {
                if (_Pos2OffsetY == value) return;
                _Pos2OffsetY = value;
                this.OnPropertyChanged(nameof(Pos2OffsetY));
            }
        }
        public AlgoParam Pos3OffsetX
        {
            get { return _Pos3OffsetX; }
            set
            {
                if (_Pos3OffsetX == value) return;
                _Pos3OffsetX = value;
                this.OnPropertyChanged(nameof(Pos3OffsetX));
            }
        }
        public AlgoParam Pos3OffsetY
        {
            get { return _Pos3OffsetY; }
            set
            {
                if (_Pos3OffsetY == value) return;
                _Pos3OffsetY = value;
                this.OnPropertyChanged(nameof(Pos3OffsetY));
            }
        }
        public AlgoParam Pos4OffsetX
        {
            get { return _Pos4OffsetX; }
            set
            {
                if (_Pos4OffsetX == value) return;
                _Pos4OffsetX = value;
                this.OnPropertyChanged(nameof(Pos4OffsetX));
            }
        }
        public AlgoParam Pos4OffsetY
        {
            get { return _Pos4OffsetY; }
            set
            {
                if (_Pos4OffsetY == value) return;
                _Pos4OffsetY = value;
                this.OnPropertyChanged(nameof(Pos4OffsetY));
            }
        }
        #endregion

        #region Each Position Distance Spec  Properties
        public AlgoParam DisX1
        {
            get { return _DisX1; }
            set
            {
                if (_DisX1 == value) return;
                _DisX1 = value;
                this.OnPropertyChanged(nameof(DisX1));
            }
        }
        public AlgoParam DisX2
        {
            get { return _DisX2; }
            set
            {
                if (_DisX2 == value) return;
                _DisX2 = value;
                this.OnPropertyChanged(nameof(DisX2));
            }
        }
        public AlgoParam DisX3
        {
            get { return _DisX3; }
            set
            {
                if (_DisX3 == value) return;
                _DisX3 = value;
                this.OnPropertyChanged(nameof(DisX3));
            }
        }
        public AlgoParam DisX4
        {
            get { return _DisX4; }
            set
            {
                if (_DisX4 == value) return;
                _DisX4 = value;
                this.OnPropertyChanged(nameof(DisX4));
            }
        }
        public AlgoParam DisY1
        {
            get { return _DisY1; }
            set
            {
                if (_DisY1 == value) return;
                _DisY1 = value;
                this.OnPropertyChanged(nameof(DisY1));
            }
        }
        public AlgoParam DisY2
        {
            get { return _DisY2; }
            set
            {
                if (_DisY2 == value) return;
                _DisY2 = value;
                this.OnPropertyChanged(nameof(DisY2));
            }
        }
        public AlgoParam DisY3
        {
            get { return _DisY3; }
            set
            {
                if (_DisY3 == value) return;
                _DisY3 = value;
                this.OnPropertyChanged(nameof(DisY3));
            }
        }
        public AlgoParam DisY4
        {
            get { return _DisY4; }
            set
            {
                if (_DisY4 == value) return;
                _DisY4 = value;
                this.OnPropertyChanged(nameof(DisY4));
            }
        }
        #endregion

        #region Spec & Tol  Properties
        public AlgoParam UpperCenter
        {
            get { return _UpperCenter; }
            set
            {
                if (_UpperCenter == value) return;
                _UpperCenter = value;
                this.OnPropertyChanged(nameof(UpperCenter));
            }
        }
        public AlgoParam LowerCenter
        {
            get { return _LowerCenter; }
            set
            {
                if (_LowerCenter == value) return;
                _LowerCenter = value;
                this.OnPropertyChanged(nameof(LowerCenter));
            }
        }
        public AlgoParam LeftCenter
        {
            get { return _LeftCenter; }
            set
            {
                if (_LeftCenter == value) return;
                _LeftCenter = value;
                this.OnPropertyChanged(nameof(LeftCenter));
            }
        }
        public AlgoParam RightCenter
        {
            get { return _RightCenter; }
            set
            {
                if (_RightCenter == value) return;
                _RightCenter = value;
                this.OnPropertyChanged(nameof(RightCenter));
            }
        }

        public AlgoParam UpperTol
        {
            get { return _UpperTol; }
            set
            {
                if (_UpperTol == value) return;
                _UpperTol = value;
                this.OnPropertyChanged(nameof(UpperTol));
            }
        }
        public AlgoParam LowerTol
        {
            get { return _LowerTol; }
            set
            {
                if (_LowerTol == value) return;
                _LowerTol = value;
                this.OnPropertyChanged(nameof(LowerTol));
            }
        }
        public AlgoParam LeftTol
        {
            get { return _LeftTol; }
            set
            {
                if (_LeftTol == value) return;
                _LeftTol = value;
                this.OnPropertyChanged(nameof(LeftTol));
            }
        }
        public AlgoParam RightTol
        {
            get { return _RightTol; }
            set
            {
                if (_RightTol == value) return;
                _RightTol = value;
                this.OnPropertyChanged(nameof(RightTol));
            }
        }

        //public AlgoParam Cpk
        //{
        //    get { return _Cpk; }
        //    set
        //    {
        //        if (_Cpk == value) return;
        //        _Cpk = value;
        //        this.OnPropertyChanged(nameof(Cpk));
        //    }
        //}
        #endregion
        #endregion

        public Algo4PInsp_VariablePtModelParams()
        {
            DisInterval = new AlgoParam("DisInterval", "mm", typeof(double), 0.001, "CrossPoint에서 '라인 위의' (DisInterval)만큼 떨어진 Pos 산출", 0, 20);
            // Judgement Threshold값 - 0920 주석 제거
            AccuracyTh = new AlgoParam("AccuracyTh", "mm", typeof(double), 0.5, "가성 Data 판단 Thrshold", 0, 5);
            // Resolution
            Resolution = new AlgoParam("Resolution", "um", typeof(double), 0.5, "Camera Resolution Spec", 0, 1);
            // Scale값
            ScaleX1 = new AlgoParam("ScaleX1", "um", typeof(double), 1.0, "Sub: ScaleX3, Main: ScaleY4(Log 찍히는 X3, Y4)", 0.5, 1.5);
            ScaleY1 = new AlgoParam("ScaleY1", "um", typeof(double), 1.0, "Sub: ScaleY3, Main: ScaleX4(Log 찍히는 Y3, X4)", 0.5, 1.5);
            ScaleX2 = new AlgoParam("ScaleX2", "um", typeof(double), 1.0, "Sub: ScaleX4, Main: ScaleY1(Log 찍히는 X4, Y1)", 0.5, 1.5);
            ScaleY2 = new AlgoParam("ScaleY2", "um", typeof(double), 1.0, "Sub: ScaleY4, Main: ScaleX1(Log 찍히는 Y4, X1)", 0.5, 1.5);
            ScaleX3 = new AlgoParam("ScaleX3", "um", typeof(double), 1.0, "Sub: ScaleX1, Main: ScaleY2(Log 찍히는 X1, Y2)", 0.5, 1.5);
            ScaleY3 = new AlgoParam("ScaleY3", "um", typeof(double), 1.0, "Sub: ScaleY1, Main: ScaleX2(Log 찍히는 Y1, X2)", 0.5, 1.5);
            ScaleX4 = new AlgoParam("ScaleX4", "um", typeof(double), 1.0, "Sub: ScaleX2, Main: ScaleY3(Log 찍히는 X2, Y3)", 0.5, 1.5);
            ScaleY4 = new AlgoParam("ScaleY4", "um", typeof(double), 1.0, "Sub: ScaleY2, Main: ScaleX3(Log 찍히는 Y2, X3)", 0.5, 1.5);
            
            // Dist Spec
            DisX1 = new AlgoParam("DisX1", "mm", typeof(double), 1.0, "Sub: DesignX3, Main: DesignY4, 각 Line간의 설계치", -2.0, 2.0);
            DisX2 = new AlgoParam("DisX2", "mm", typeof(double), 1.0, "Sub: DesignY3, Main: DesignX4, 각 Line간의 설계치", -2.0, 2.0);
            DisX3 = new AlgoParam("DisX3", "mm", typeof(double), 1.0, "Sub: DesignX4, Main: DesignY1, 각 Line간의 설계치", -2.0, 2.0);
            DisX4 = new AlgoParam("DisX4", "mm", typeof(double), 1.0, "Sub: DesignY4, Main: DesignX1, 각 Line간의 설계치", -2.0, 2.0);
            DisY1 = new AlgoParam("DisY1", "mm", typeof(double), 1.0, "Sub: DesignX1, Main: DesignY2, 각 Line간의 설계치", -2.0, 2.0);
            DisY2 = new AlgoParam("DisY2", "mm", typeof(double), 1.0, "Sub: DesignY1, Main: DesignX2, 각 Line간의 설계치", -2.0, 2.0);
            DisY3 = new AlgoParam("DisY3", "mm", typeof(double), 1.0, "Sub: DesignX2, Main: DesignY3, 각 Line간의 설계치", -2.0, 2.0);
            DisY4 = new AlgoParam("DisY4", "mm", typeof(double), 1.0, "Sub: DesignY2, Main: DesignX3, 각 Line간의 설계치", -2.0, 2.0);
            
            // Center Dist Spec
            UpperCenter = new AlgoParam("UpperCenter" , "mm", typeof(double), 0, "Sub:LowerCenter, Main:RightCenter 중심치", -2.0, 0.5);
            LowerCenter = new AlgoParam("LowerCenter" , "mm", typeof(double), 0, "Sub:UpperCenter, Main:LeftCenter  중심치", -2.0, 0.5);
            LeftCenter  = new AlgoParam("LeftCenter"  , "mm", typeof(double), 0, "Sub:RightCenter, Main:UpperCenter 중심치", -2.0, 0.5);
            RightCenter = new AlgoParam("RightCenter" , "mm", typeof(double), 0, "Sub:LeftCenter , Main:LowerCenter 중심치", -2.0, 0.5);
            
            // Center Dist Tor           
            UpperTol = new AlgoParam("UpperTol" , "mm", typeof(double), 0.125, "Sub:Lower , Main: Right - Tolerance값", 0.0, 0.5);
            LowerTol = new AlgoParam("LowerTol" , "mm", typeof(double), 0.125, "Sub:Upper , Main: Left  - Tolerance값", 0.0, 0.5);
            LeftTol  = new AlgoParam("LeftTol"  , "mm", typeof(double), 0.125, "Sub:Right , Main: Upper - Tolerance값", 0.0, 0.5);
            RightTol = new AlgoParam("RightTol" , "mm", typeof(double), 0.125, "Sub:Left  , Main: Lower - Tolerance값", 0.0, 0.5);

            // Offset
            Pos1OffsetX = new AlgoParam("Pos1OffsetX", "mm", typeof(double), 0.0, "Sub:Lower , Main: Right Inspection Off-Set", -2.0, 2.0);
            Pos1OffsetY = new AlgoParam("Pos1OffsetY", "mm", typeof(double), 0.0, "Sub:Upper , Main: Left  Inspection Off-Set", -2.0, 2.0);
            Pos2OffsetX = new AlgoParam("Pos2OffsetX", "mm", typeof(double), 0.0, "Sub:Right , Main: Upper Inspection Off-Set", -2.0, 2.0);
            Pos2OffsetY = new AlgoParam("Pos2OffsetY", "mm", typeof(double), 0.0, "Sub:Left  , Main: Lower Inspection Off-Set", -2.0, 2.0);
            Pos3OffsetX = new AlgoParam("Pos3OffsetX", "mm", typeof(double), 0.0, "Sub:Lower , Main: Right Inspection Off-Set", -2.0, 2.0);
            Pos3OffsetY = new AlgoParam("Pos3OffsetY", "mm", typeof(double), 0.0, "Sub:Upper , Main: Left  Inspection Off-Set", -2.0, 2.0);
            Pos4OffsetX = new AlgoParam("Pos4OffsetX", "mm", typeof(double), 0.0, "Sub:Right , Main: Upper Inspection Off-Set", -2.0, 2.0);
            Pos4OffsetY = new AlgoParam("Pos4OffsetY", "mm", typeof(double), 0.0, "Sub:Left  , Main: Lower Inspection Off-Set", -2.0, 2.0);
            //Cpk = new AlgoParam("Cpk Value", "mm", typeof(double), 1.0, "검사 Cpk 기준", 0.0, 2.0);
        }
    }
}
