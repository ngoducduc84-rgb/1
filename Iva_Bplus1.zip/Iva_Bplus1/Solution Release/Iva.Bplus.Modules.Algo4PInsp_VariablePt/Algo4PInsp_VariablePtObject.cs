﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;

using Cognex.VisionPro.Dimensioning;
using Cognex.VisionPro;
using Iva.Bplus.Modules.CogDisplay;
using Iva.Bplus.Interface;

namespace Iva.Bplus.Modules.Algo4PInsp_VariablePt
{
    public enum InspectionPos { Frnt_L, Rear_L, Rear_R, Frnt_R }

    [SerializableAttribute]
    public partial class Algo4PInsp_VariablePtObject : AlgoObjectBase
    {
        #region [Fields]
        [field: NonSerialized]
        double disInterval = new double();

        // LineCross에서 (Line 위의) 특정 지점 Point  
        // cPointX: X Dist, cPointY: Y Dist. 측정~
        [field: NonSerialized]
        Dictionary<string, XY> pointBeyondLineX = new Dictionary<string, XY>();
        [field: NonSerialized]
        Dictionary<string, XY> pointBeyondLineY = new Dictionary<string, XY>();

        [field: NonSerialized]
        Dictionary<string, XY> scaleParam = new Dictionary<string, XY>();
        [field: NonSerialized]
        Dictionary<string, XY> distParam = new Dictionary<string, XY>();

        [field: NonSerialized] //(New)
        Dictionary<string, XY> offset = new Dictionary<string, XY>();

        [field: NonSerialized]
        Dictionary<string, XY> distResult = new Dictionary<string, XY>();

        // New
        [field: NonSerialized]
        Dictionary<string, XY> cPointInLineX = new Dictionary<string, XY>();
        [field: NonSerialized]
        Dictionary<string, XY> cPointInLineY = new Dictionary<string, XY>();
        [field: NonSerialized]
        Dictionary<string, XY> OutLineToInLineDis = new Dictionary<string, XY>();

        [field: NonSerialized]
        XY[] fitLineAngle = new XY[4];

        [field: NonSerialized]
        Dictionary<string, XY> distXStart = new Dictionary<string, XY>();
        [field: NonSerialized]
        Dictionary<string, XY> distXEnd = new Dictionary<string, XY>();
        [field: NonSerialized]
        Dictionary<string, XY> distYStart = new Dictionary<string, XY>();
        [field: NonSerialized]
        Dictionary<string, XY> distYEnd = new Dictionary<string, XY>();


        [field: NonSerialized]
        Dictionary<string, LineCrossRstData> OutLineDicRst = new Dictionary<string, LineCrossRstData>();
        LineCrossRstData[] OutLineRst = new LineCrossRstData[4];

        [field: NonSerialized]
        Dictionary<string, LineCrossRstData> InLineDicRst = new Dictionary<string, LineCrossRstData>();
        LineCrossRstData[] InLineRst = new LineCrossRstData[4];
        // IPointResult[] pointRst = new IPointResult[4];



        [field: NonSerialized]
        CogDistancePointLineTool calcTool = new CogDistancePointLineTool();
        [field: NonSerialized]
        XYT revAlign = new XYT();
        
        // Result Data
        //[field: NonSerialized]
        Algo4PInsp_VariablePtModelParams mParams;
        private Algo4PInsp_VariablePtResult inspRst;

        private string p1_Display;
        private string p2_Display;
        private string p3_Display;
        private string p4_Display;

        //[^^]private InspectionType insType;
        private string insImageName;
        private UseDistRevision distRevision;
        private UseMachineSort machineSort;
        public Dictionary<string, bool> errCode;
        public Dictionary<string, object> InputData = new Dictionary<string, object>();

        int Main_CHNo = 0;

        #endregion

        #region [properties]
        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P2_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p2_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P3_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p3_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P4_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p4_Display) as CogDisplayObject; }
        }


        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P2_Display
        {
            get { return p2_Display; }
            set { if (p2_Display == value) return; p2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P3_Display
        {
            get { return p3_Display; }
            set { if (p3_Display == value) return; p3_Display = value; this.OnPropertyChanged(nameof(P3_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P4_Display
        {
            get { return p4_Display; }
            set { if (p4_Display == value) return; p4_Display = value; this.OnPropertyChanged(nameof(P4_Display)); }
        }

        public Algo4PInsp_VariablePtResult InspRst
        {
            get { return inspRst; }
            set
            {
                if (inspRst == value) return;
                inspRst = value;

                this.OnPropertyChanged(nameof(InspRst));
            }
        }
        public XYT RevAlign { get { return revAlign; } }
        public Dictionary<string, XY> InspResult { get { return distResult; } }


        public UseMachineSort MachineSort
        {
            get { return machineSort; }
            set
            {
                if (machineSort == value) return;

                machineSort = value;
                OnPropertyChanged("MachineSort");
            }
        }

        public UseDistRevision DistRevision
        {
            get { return distRevision; }
            set
            {
                if (distRevision == value) return;

                distRevision = value;
                OnPropertyChanged("DistRevision");
            }
        }

        public Dictionary<string, bool> ErrCode
        {
            get { return errCode; }
            set
            {
                if (errCode == value) return;

                errCode = value;
                OnPropertyChanged("ErrCode");
            }
        }


        public string InsImageName
        {
            get { return insImageName; }
            set
            {
                if (insImageName == value) return;
                insImageName = value;
                OnPropertyChanged("InsImageName");
            }
        }

        #endregion

        #region [private method]
        #endregion

        #region [public method]
        #endregion

        #region[Construct]
        public Algo4PInsp_VariablePtObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo4PInsp_VariablePtModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion


        protected void AssignPLCData()
        {
            UpdatePLCIOs();
            
            SourceID = (string)PlcValues["CellID"].CurValue;
            Main_CHNo = PlcValues.ContainsKey("MainChamberNo") ? (int)PlcValues["MainChamberNo"].CurValue : 0; //D68139

        }

        void Initialize()
        {
            errorCode = SystemActionBase.No_Error;
            pointBeyondLineX = new Dictionary<string, XY>();
            pointBeyondLineY = new Dictionary<string, XY>();

            cPointInLineX = new Dictionary<string, XY>();
            cPointInLineY = new Dictionary<string, XY>();
            OutLineToInLineDis = new Dictionary<string, XY>();

            fitLineAngle = new XY[4];

            OutLineDicRst = new Dictionary<string, LineCrossRstData>();
            OutLineRst = new LineCrossRstData[4];

            InLineDicRst = new Dictionary<string, LineCrossRstData>();
            InLineRst = new LineCrossRstData[4];
 
            scaleParam = new Dictionary<string, XY>();
            distParam = new Dictionary<string, XY>();
            distResult = new Dictionary<string, XY>();

            offset = new Dictionary<string, XY>(); 

            distXStart = new Dictionary<string, XY>();
            distXEnd = new Dictionary<string, XY>();

            distYStart = new Dictionary<string, XY>();
            distYEnd = new Dictionary<string, XY>();

            revAlign = new XYT();
            calcTool = new CogDistancePointLineTool();

            foreach (var i in Enum.GetValues(typeof(InspectionPos)))
            {
                scaleParam[i.ToString()] = new XY(0.0, 0.0);
                distParam[i.ToString()] = new XY(0.0, 0.0);
                distResult[i.ToString()] = new XY(0.0, 0.0);
                offset[i.ToString()] = new XY(0.0, 0.0);

                distXStart[i.ToString()] = new XY();
                distXEnd[i.ToString()] = new XY();
                distYStart[i.ToString()] = new XY();
                distYEnd[i.ToString()] = new XY();
            }
            Main_CHNo = 0;
        }

        #region [override methode]
        public override bool Run()
        {
            StartTimer();

            #region 1> Initialize 
            string model = SystemModel.GetCurModel();
            errCode = new Dictionary<string, bool>();
            InitInsp_Err(ref errCode);
            Initialize();
            #endregion

            #region 2> PLC IOs Update
            AssignPLCData();
            #endregion         
            
            #region 3> Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            mParams = modelParams as Algo4PInsp_VariablePtModelParams;

            var DisInterval = (double)mParams.DisInterval.Value;

            var AccuracyTh = (double)mParams.AccuracyTh.Value;
            var Resolution = (double)mParams.Resolution.Value;

            var UpperCenter = (double)mParams.UpperCenter.Value;
            var LowerCenter = (double)mParams.LowerCenter.Value;
            var LeftCenter = (double)mParams.LeftCenter.Value;
            var RightCenter = (double)mParams.RightCenter.Value;

            var UpperTol = (double)mParams.UpperTol.Value;
            var LowerTol = (double)mParams.LowerTol.Value;
            var LeftTol = (double)mParams.LeftTol.Value;
            var RightTol = (double)mParams.RightTol.Value;

            scaleParam["Frnt_L"].X = (double)mParams.ScaleX1.Value;
            scaleParam["Frnt_L"].Y = (double)mParams.ScaleY1.Value;
            scaleParam["Rear_L"].X = (double)mParams.ScaleX2.Value;
            scaleParam["Rear_L"].Y = (double)mParams.ScaleY2.Value;
            scaleParam["Rear_R"].X = (double)mParams.ScaleX3.Value;
            scaleParam["Rear_R"].Y = (double)mParams.ScaleY3.Value;
            scaleParam["Frnt_R"].X = (double)mParams.ScaleX4.Value;
            scaleParam["Frnt_R"].Y = (double)mParams.ScaleY4.Value;

            distParam["Frnt_L"].X = (double)mParams.DisX1.Value;
            distParam["Frnt_L"].Y = (double)mParams.DisY1.Value;
            distParam["Rear_L"].X = (double)mParams.DisX2.Value;
            distParam["Rear_L"].Y = (double)mParams.DisY2.Value;
            distParam["Rear_R"].X = (double)mParams.DisX3.Value;
            distParam["Rear_R"].Y = (double)mParams.DisY3.Value;
            distParam["Frnt_R"].X = (double)mParams.DisX4.Value;
            distParam["Frnt_R"].Y = (double)mParams.DisY4.Value;

            offset["Frnt_L"].X = (double)mParams.Pos1OffsetX.Value;
            offset["Frnt_L"].Y = (double)mParams.Pos1OffsetY.Value;
            offset["Rear_L"].X = (double)mParams.Pos2OffsetX.Value;
            offset["Rear_L"].Y = (double)mParams.Pos2OffsetY.Value;
            offset["Rear_R"].X = (double)mParams.Pos3OffsetX.Value;
            offset["Rear_R"].Y = (double)mParams.Pos3OffsetY.Value;
            offset["Frnt_R"].X = (double)mParams.Pos4OffsetX.Value;
            offset["Frnt_R"].Y = (double)mParams.Pos4OffsetY.Value;
            #endregion

            #region 4> Mark Data Read & Confirm
            Type type = typeof(Algo4PInsp_VariablePtInputParams);
            MemberInfo[] Properties = type.GetProperties();
            ;
            foreach (var Property in Properties)
            {
                string[] titleName = Property.ToString().Split(new string[] { "_", " " }, StringSplitOptions.None);

                switch (titleName[1])
                {
                    case "Out":
                        OutLineDicRst[Property.Name] = InputValues[Property.Name] as LineCrossRstData;
                        break;

                    case "In":
                        InLineDicRst[Property.Name] = InputValues[Property.Name] as LineCrossRstData;
                        break;
                }

                if (!InputValues.ContainsKey(Property.Name))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
            }

            double fixDisInterval = DisInterval;
            #endregion

            // Inspection 방식 (Numbering 참조 필요!)
            // Out_Fnt_L(0) -----------------------Out_Fnt_R(3)
            //    |                               l
            //    |                               l
            //    l                               l
            //    |                               |        Lower 찍고, Upper로 이동!
            //    l                               l         
            //    l                               l
            // Out_Rear_L(1)-----------------------Out_Rear_R(2)

            // '작업자' 방향

            #region 5> Inspection 계산        
            foreach (var elem in Enum.GetValues(typeof(InspectionPos)))
            {
                Resolution = 0.005;
                DisInterval = fixDisInterval;
                string grabPos = elem.ToString();

                if (OutLineDicRst["Out_"+grabPos].IsIntersect == false || InLineDicRst["In_"+grabPos].IsIntersect == false)
                {
                    distResult[grabPos].X = 0;
                    distResult[grabPos].Y = 0;
                }
                #region 정상 처리
                else
                {
                    // 5-1> OutLine(Theta 기준) Cross Point에서 (Line 위의) 특정 위치의 점, 산출  
                    CalPointBeyondLine(grabPos, DisInterval, Resolution, ref pointBeyondLineX, ref pointBeyondLineY);
                    distXStart[grabPos] = pointBeyondLineX[grabPos]; distYStart[grabPos] = pointBeyondLineY[grabPos];

                    // 5-2> (외곽 자재 Theta기준) OutLinePoint ~ InLine간 Line 생성
                    ICogImage fitImage = InLineDicRst["In_" + grabPos].OutputImage as ICogImage;
                    XY InPosX = new XY(0, 0);
                    XY InPosY = new XY(0, 0);
                    CalcFitLinePoint(grabPos, pointBeyondLineX[grabPos], pointBeyondLineY[grabPos], fitImage, ref InPosX, ref InPosY);

                    // 위에서 fail하면 Start와 End값을 같게 만들어 Dis.를 '0'으로 만듬
                    distXEnd[grabPos] = InPosX; distYEnd[grabPos] = InPosY;

                    // 5-3> 최종 거리 산출
                    double disX = 0; double disY = 0;

                    #region X,Y Dis 최종 산출 
                    // X성분 Dis
                    if (distXStart[grabPos] == distXEnd[grabPos])
                    {
                        distResult[grabPos].X = 0.0;
                    }
                    else if (CalcFinalDis_Rev(distXStart[grabPos], distXEnd[grabPos], scaleParam[grabPos].X, scaleParam[grabPos].Y, ref disX) == true)
                    {
                        distResult[grabPos].X = disX * Resolution;
                        distResult[grabPos].X += offset[grabPos].X;
                    }
                    else
                    {
                        distResult[grabPos].X = 0.0;
                    }

                    // Y성분 Dis
                    if (distYStart[grabPos] == distYEnd[grabPos])
                    {
                        distResult[grabPos].Y = 0.0;
                    }
                    else if (CalcFinalDis_Rev(distYStart[grabPos], distYEnd[grabPos], scaleParam[grabPos].X, scaleParam[grabPos].Y, ref disY) == true)
                    {
                        distResult[grabPos].Y = disY * Resolution;
                        distResult[grabPos].Y += offset[grabPos].Y;
                    }
                    else
                    {
                        distResult[grabPos].Y = 0.0;
                    }
                    #endregion
                }
                #endregion
            }
            #endregion

            #region 6) Inspection Data 정합성 Judgement & Needs -> Revision
            string alterArea = "";


            if (DistRevision == UseDistRevision.Use)
            {
                switch (MachineSort)
                {
                    case UseMachineSort.D_Sub:
                        // X1 ~ X4               
                        if (AccuracyCheck_Dis(
                            distParam["Frnt_L"].X + distParam["Frnt_R"].X,
                            distResult["Frnt_L"].X + distResult["Frnt_R"].X, AccuracyTh) != true || distResult["Frnt_L"].X == 0 || distResult["Frnt_R"].X == 0)
                        {
                            CompensateData(
                                distParam["Frnt_L"].X, distParam["Frnt_R"].X,
                                distResult["Frnt_L"].X, distResult["Frnt_R"].X, ref alterArea, "X1_X4",
                                distXStart["Frnt_L"], distXEnd["Frnt_L"], distXStart["Frnt_R"], distXEnd["Frnt_R"]
                                );
                        };

                        // X2 ~ X3
                        if (AccuracyCheck_Dis(
                            distParam["Rear_L"].X + distParam["Rear_R"].X,
                            distResult["Rear_L"].X + distResult["Rear_R"].X, AccuracyTh) != true || distResult["Rear_L"].X == 0 || distResult["Rear_R"].X==0)
                        {
                            CompensateData(
                                distParam["Rear_L"].X, distParam["Rear_R"].X,
                                distResult["Rear_L"].X, distResult["Rear_R"].X, ref alterArea, "X2_X3",
                                distXStart["Rear_L"], distXEnd["Rear_L"], distXStart["Rear_R"], distXEnd["Rear_R"]
                                );
                        };
                        break;


                    case UseMachineSort.D_Main:
                        //FDC Test
                        distResult["Frnt_L"].X = distResult["Frnt_L"].X * -1;
                        distResult["Rear_L"].X = distResult["Rear_L"].X * -1;
                        // X1 ~ X4               
                        if (AccuracyCheck_Dis_D_Main(
                            distResult["Frnt_L"].X, distParam["Frnt_L"].X,
                            distResult["Frnt_R"].X, distParam["Frnt_R"].X, AccuracyTh) != true || distResult["Frnt_L"].X==0 || distResult["Frnt_R"].X==0)
                        {
                            CompensateData_D_Main(
                                distParam["Frnt_L"].X, distParam["Frnt_R"].X,
                                distResult["Frnt_L"].X, distResult["Frnt_R"].X, ref alterArea, "X1_X4",
                                distXStart["Frnt_L"], distXEnd["Frnt_L"], distXStart["Frnt_R"], distXEnd["Frnt_R"]
                                );
                        };

                        // X2 ~ X3
                        if (AccuracyCheck_Dis_D_Main(
                            distResult["Rear_L"].X, distParam["Rear_L"].X,
                            distResult["Rear_R"].X, distParam["Rear_R"].X, AccuracyTh) != true || distResult["Rear_L"].X == 0 || distResult["Rear_R"].X == 0)
                        {
                            CompensateData_D_Main(
                                distParam["Rear_L"].X, distParam["Rear_R"].X,
                                distResult["Rear_L"].X, distResult["Rear_R"].X, ref alterArea, "X2_X3",
                                distXStart["Rear_L"], distXEnd["Rear_L"], distXStart["Rear_R"], distXEnd["Rear_R"]
                                );
                        };
                        break;
                }

                //Y는 Sub=Main
                // Y1 ~ Y2
                if (AccuracyCheck_Dis(
                    distParam["Frnt_L"].Y + distParam["Rear_L"].Y,
                    distResult["Frnt_L"].Y + distResult["Rear_L"].Y, AccuracyTh) != true || distResult["Frnt_L"].Y == 0|| distResult["Rear_L"].Y==0 )
                {
                    CompensateData(
                        distParam["Frnt_L"].Y, distParam["Rear_L"].Y,
                        distResult["Frnt_L"].Y, distResult["Rear_L"].Y, ref alterArea, "Y1_Y2",
                        distXStart["Frnt_L"], distXEnd["Frnt_L"], distXStart["Rear_L"], distXEnd["Rear_L"]
                        );
                };

                // Y3 ~ Y4
                if (AccuracyCheck_Dis(
                    distParam["Rear_R"].Y + distParam["Frnt_R"].Y,
                    distResult["Rear_R"].Y + distResult["Frnt_R"].Y, AccuracyTh) != true || distResult["Rear_R"].Y==0 || distResult["Frnt_R"].Y==0)
                {
                    CompensateData(
                        distParam["Rear_R"].Y, distParam["Frnt_R"].Y,
                        distResult["Rear_R"].Y, distResult["Frnt_R"].Y,  ref alterArea, "Y3_Y4",
                        distXStart["Rear_R"], distXEnd["Rear_R"], distXStart["Frnt_R"], distXEnd["Frnt_R"]
                        );
                };
            }
            #endregion

            #region 7) Center Align에 대한 판정
            Dictionary<string, double> RstCenterAlign = new Dictionary<string, double>();                        
            bool bResult = true;
            //FDC Test
            
            // 1> low
            double lowerRstCenter = 0;
            if(UseMachineSort.D_Sub == MachineSort)
            {
                F_Judgement(distResult["Rear_L"].X, distResult["Rear_R"].X, LowerTol, LowerCenter, ref lowerRstCenter);
            }
            else
            {
                //FDC Test
                F_Judgement(distResult["Rear_L"].X, distResult["Rear_R"].X, LowerTol, LowerCenter, ref lowerRstCenter);
                //F_Judgement_D_Main(distResult["Rear_L"].X, distParam["Rear_L"].X, distResult["Rear_R"].X, distParam["Rear_R"].X, ref lowerRstCenter, UpperTol);
            }
            RstCenterAlign["LowerCenterAlign"] = lowerRstCenter;
          
            if (Math.Abs(lowerRstCenter - LowerCenter) > LowerTol)  //center align spec over 
            { 
               if (distXStart["Rear_L"].X != 0)
               {
                   DrawLineLabel(P3_DisplayObj, distXStart["Rear_L"], distXEnd["Rear_L"], distResult["Rear_L"].X, CogColorConstants.Red, true, true);
               }
               bResult = false;
               if (distXStart["Rear_R"].X != 0)
               {
                   DrawLineLabel(P4_DisplayObj, distXStart["Rear_R"], distXEnd["Rear_R"], distResult["Rear_R"].X, CogColorConstants.Red, true, true);
               }
            }
            else
            {
                if (distXStart["Rear_L"].X != 0)
                {
                    DrawLineLabel(P3_DisplayObj, distXStart["Rear_L"], distXEnd["Rear_L"], distResult["Rear_L"].X, CogColorConstants.Blue, true, true);
                }
                if (distXStart["Rear_R"].X != 0)
                {
                    DrawLineLabel(P4_DisplayObj, distXStart["Rear_R"], distXEnd["Rear_R"], distResult["Rear_R"].X, CogColorConstants.Blue, true, true);
                }
            }
 

            // 2> upper
            double upperRstCenter = 0;
            if (UseMachineSort.D_Sub == MachineSort)
            {
                F_Judgement(distResult["Frnt_L"].X, distResult["Frnt_R"].X, UpperTol, UpperCenter, ref upperRstCenter);
            }
            else
            {
                // each line -> Calc Center_Align
                //FDC Test
                F_Judgement(distResult["Frnt_L"].X, distResult["Frnt_R"].X, UpperTol, UpperCenter, ref upperRstCenter);
                //F_Judgement_D_Main(distResult["Frnt_L"].X, distParam["Frnt_L"].X, distResult["Frnt_R"].X, distParam["Frnt_R"].X, ref upperRstCenter, LowerTol);
            }

            RstCenterAlign["UpperCenterAlign"] = upperRstCenter;
            if (Math.Abs(upperRstCenter - UpperCenter) > UpperTol)
            {
               if(distXStart["Frnt_L"].X != 0)
               {
                   DrawLineLabel(P1_DisplayObj, distXStart["Frnt_L"], distXEnd["Frnt_L"], distResult["Frnt_L"].X, CogColorConstants.Red, true, true);
               }
               if(distYStart["Frnt_R"].X != 0)
               {
                   DrawLineLabel(P2_DisplayObj, distXStart["Frnt_R"], distXEnd["Frnt_R"], distResult["Frnt_R"].X, CogColorConstants.Red, true, true);
               }
               bResult = false;
            }
            else
            {
                if (distXStart["Frnt_L"].X != 0)
                {
                    DrawLineLabel(P1_DisplayObj, distXStart["Frnt_L"], distXEnd["Frnt_L"], distResult["Frnt_L"].X, CogColorConstants.Blue, true, true);
                }
                if (distXStart["Frnt_R"].X != 0)
                {
                    DrawLineLabel(P2_DisplayObj, distXStart["Frnt_R"], distXEnd["Frnt_R"], distResult["Frnt_R"].X, CogColorConstants.Blue, true, true);
                }
            }


            // 3> left
            double leftRstCenter = 0;
            F_Judgement(distResult["Rear_L"].Y, distResult["Frnt_L"].Y, LeftTol, LeftCenter, ref leftRstCenter);
            RstCenterAlign["LeftCenterAlign"] = leftRstCenter;
            if (Math.Abs(leftRstCenter - LeftCenter) > LeftTol)
            {            
                if (distYStart["Frnt_L"].X != 0)
                {
                    DrawLineLabel(P1_DisplayObj, distYStart["Frnt_L"], distYEnd["Frnt_L"], distResult["Frnt_L"].Y, CogColorConstants.Red, true, true);
                }
                if (distYStart["Rear_L"].X != 0)
                {
                    DrawLineLabel(P3_DisplayObj, distYStart["Rear_L"], distYEnd["Rear_L"], distResult["Rear_L"].Y, CogColorConstants.Red, true, true);
                }
                bResult = false;
            }
            else
            {
                if (distYStart["Frnt_L"].X != 0)
                {
                    DrawLineLabel(P1_DisplayObj, distYStart["Frnt_L"], distYEnd["Frnt_L"], distResult["Frnt_L"].Y, CogColorConstants.Blue, true, true);
                }
                if (distYStart["Rear_L"].X != 0)
                {
                    DrawLineLabel(P3_DisplayObj, distYStart["Rear_L"], distYEnd["Rear_L"], distResult["Rear_L"].Y, CogColorConstants.Blue, true, true);
                }
            }


            //4 right
            double rightRstCenter = 0;
            F_Judgement(distResult["Rear_R"].Y, distResult["Frnt_R"].Y, RightTol, RightCenter, ref rightRstCenter);
            RstCenterAlign["RightCenterAlign"] = rightRstCenter;
            if (Math.Abs(rightRstCenter - RightCenter) > RightTol)
            {
                if (distYStart["Frnt_R"].X != 0)
                {
                    DrawLineLabel(P2_DisplayObj, distYStart["Frnt_R"], distYEnd["Frnt_R"], distResult["Frnt_R"].Y, CogColorConstants.Red, true, true);
                }
                if (distYStart["Rear_R"].X != 0)
                {
                    DrawLineLabel(P4_DisplayObj, distYStart["Rear_R"], distYEnd["Rear_R"], distResult["Rear_R"].Y, CogColorConstants.Red, true, true);
                }
                bResult = false;
            }
            else
            {
                if (distXStart["Frnt_R"].X != 0)
                {
                    DrawLineLabel(P2_DisplayObj, distYStart["Frnt_R"], distYEnd["Frnt_R"], distResult["Frnt_R"].Y, CogColorConstants.Blue, true, true);
                }
                if (distYStart["Rear_R"].X != 0)
                {
                    DrawLineLabel(P4_DisplayObj, distYStart["Rear_R"], distYEnd["Rear_R"], distResult["Rear_R"].Y, CogColorConstants.Blue, true, true);
                }
            }

            if (bResult == false)
            {
                errorCode = Algo4PInsp_VariablePtAction.Err_Inspection_Spec_Over;
            }
            #endregion


            #region 8) D-Sub/D-Main의 Point에 따라 맞춰주는 부분
            double[] tempDisX = new double[4];
            double[] tempDisY = new double[4];

            double tempUpper = upperRstCenter;
            double tempLower = lowerRstCenter;
            double tempLeft = leftRstCenter;
            double tempRight = rightRstCenter;

            tempDisX[0] = Math.Round(distResult["Frnt_L"].X, 3);
            tempDisY[0] = Math.Round(distResult["Frnt_L"].Y, 3);

            tempDisX[1] = Math.Round(distResult["Rear_L"].X, 3);
            tempDisY[1] = Math.Round(distResult["Rear_L"].Y, 3);

            tempDisX[2] = Math.Round(distResult["Rear_R"].X, 3);
            tempDisY[2] = Math.Round(distResult["Rear_R"].Y, 3);

            tempDisX[3] = Math.Round(distResult["Frnt_R"].X, 3);
            tempDisY[3] = Math.Round(distResult["Frnt_R"].Y, 3);

            Dictionary<string, double> fdcCenterAlign = new Dictionary<string, double>();

            if (UseMachineSort.D_Sub == MachineSort)
            {
                UpperCenter = tempLower;
                fdcCenterAlign["UpperCenterAlign"] = UpperCenter;
                LowerCenter = tempUpper;
                fdcCenterAlign["LowerCenterAlign"] = LowerCenter;
                LeftCenter = tempRight;
                fdcCenterAlign["LeftCenterAlign"] = LeftCenter;
                RightCenter = tempLeft;
                fdcCenterAlign["RightCenterAlign"] = RightCenter;

                distResult["Frnt_L"].X = tempDisX[2];
                distResult["Frnt_L"].Y = tempDisY[2];
                distResult["Rear_L"].X = tempDisX[3];
                distResult["Rear_L"].Y = tempDisY[3];
                distResult["Rear_R"].X = tempDisX[0];
                distResult["Rear_R"].Y = tempDisY[0];
                distResult["Frnt_R"].X = tempDisX[1];
                distResult["Frnt_R"].Y = tempDisY[1];
            }
            else if (UseMachineSort.D_Main == MachineSort)
            {
                UpperCenter = -1 * tempLeft;
                fdcCenterAlign["UpperCenterAlign"] = UpperCenter;
                LowerCenter = -1 * tempRight;
                fdcCenterAlign["LowerCenterAlign"] = LowerCenter;
                LeftCenter = tempLower;
                fdcCenterAlign["LeftCenterAlign"]  = LeftCenter;
                RightCenter = tempUpper;
                fdcCenterAlign["RightCenterAlign"] = RightCenter;

                distResult["Frnt_L"].X = tempDisY[1];
                distResult["Frnt_L"].Y = tempDisX[1];
                distResult["Rear_L"].X = tempDisY[2];
                distResult["Rear_L"].Y = tempDisX[2];
                distResult["Rear_R"].X = tempDisY[3];
                distResult["Rear_R"].Y = tempDisX[3];
                distResult["Frnt_R"].X = tempDisY[0];
                distResult["Frnt_R"].Y = tempDisX[0];
            }

            #endregion

            #region 9) Log 및 결과값 
            AlgoRst = new Algo4PInsp_VariablePtResult
            {
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Name = name,
                ID = sourceID,

                Result = bResult ? "OK" : "NG",
                MainCH = Main_CHNo,
                UpperCAlign = Math.Round(UpperCenter, 3),
                LowerCAlign = Math.Round(LowerCenter, 3),
                LeftCAlign = Math.Round(LeftCenter, 3),
                RightCAlign = Math.Round(RightCenter, 3),

                Dis1_X = Math.Round(distResult["Frnt_L"].X, 3),
                Dis1_Y = Math.Round(distResult["Frnt_L"].Y, 3),
                Dis2_X = Math.Round(distResult["Rear_L"].X, 3),
                Dis2_Y = Math.Round(distResult["Rear_L"].Y, 3),
                Dis3_X = Math.Round(distResult["Rear_R"].X, 3),
                Dis3_Y = Math.Round(distResult["Rear_R"].Y, 3),
                Dis4_X = Math.Round(distResult["Frnt_R"].X, 3),
                Dis4_Y = Math.Round(distResult["Frnt_R"].Y, 3),

                AlterArea = alterArea,
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region 10) FDC Inspection Data Upload 
            UploadFDCdata(distResult, fdcCenterAlign, bResult);
            #endregion

            StopTimer();
            return errorCode == 0 ? true : false;
        }


        public void F_Judgement(double Num1, double Num2, double Tol, double Center, ref double Result)
        {
            if (Num1 == 0 && Num2 == 0)
            {
                Result = Tol + Center + 0.02;
            }
            else
            {
                Result = (Num1 - Num2) / 2;  // lower center
            }
        }


        public void F_Judgement_D_Main(double distResult_1, double distParam_1, double distResult_2, double distParam_2, ref double Result, double tol)
        {
            if(distResult_1 == 0 && distResult_2 == 0)
            {
                Result = (distParam_1 - distParam_2) /2 + (tol + 0.02);
            }
            else
            {
                double result_1 = 0; double result_2 = 0;

                result_1 = distResult_1 - distParam_1;
                result_2 = distResult_2 - distParam_2;
                Result = (result_1 + result_2) / 2;
                Result += (distParam_1 - distParam_2) / 2;
            }
        }


        public void CalPointBeyondLine(string _grabPos, double _measurePos, double Resolution, ref Dictionary<string, XY> PosBeyondLineX, ref Dictionary<string, XY> PosBeyondLineY)
        {
            // 각 X(Hori-), Y(Verti) Line
            CogLine OutLine_calcX = OutLineDicRst["Out_" + _grabPos].Lines[0] as CogLine;
            CogLine OutLine_calcY = OutLineDicRst["Out_" + _grabPos].Lines[1] as CogLine;

            XY direction = new XY();

            switch (_grabPos)
            {
                case "Frnt_L":
                    direction = new XY(PI, 0);
                    break;

                case "Frnt_R":
                    direction = new XY(PI, PI);
                    break;

                case "Rear_L":
                    direction = new XY(0, 0);
                    break;

                case "Rear_R":
                    direction = new XY(0, PI);
                    break;
            }

            PosBeyondLineX[_grabPos] = new XY(0, 0);
            PosBeyondLineY[_grabPos] = new XY(0, 0);

            // 'DisInterval'를 Pixel(Vision 좌표 기준)로 산출 
            // Resolution과 Scale 고려하여... 원길이 / Scale / Resolution = Pixel수
            XY LineX = new XY(0, 0); XY LineY = new XY(0, 0); // Line위의 점 구할 시 (LineCross ~ Line 위점)에서의 각각의 X,Y 성분 

            _measurePos /= Resolution; //얼마나 떨어진 곳 '픽셀수'

            // Verti- Line 위의 Point
            LineX.X = (Math.Cos(OutLine_calcX.Rotation + direction.X)) * _measurePos / scaleParam[_grabPos].X;
            LineX.Y = (Math.Sin(OutLine_calcX.Rotation + direction.X)) * _measurePos / scaleParam[_grabPos].X;

            PosBeyondLineX[_grabPos].X = OutLineDicRst["Out_" + _grabPos].OutputXYT.X + LineX.X;
            PosBeyondLineX[_grabPos].Y = OutLineDicRst["Out_" + _grabPos].OutputXYT.Y + LineX.Y;

            CogDrawMarkerInfo drawPointX = new CogDrawMarkerInfo();
            MarkDrawTest(new XYT(PosBeyondLineX[_grabPos].X, PosBeyondLineX[_grabPos].Y, 0), ref drawPointX);

            // Hori- Line 위의 Point
            LineY.X = (Math.Cos(OutLine_calcY.Rotation + direction.Y)) * _measurePos / scaleParam[_grabPos].Y; //LineY.X /= Resolution;
            LineY.Y = (Math.Sin(OutLine_calcY.Rotation + direction.Y)) * _measurePos / scaleParam[_grabPos].Y; //LineY.Y /= Resolution;

            PosBeyondLineY[_grabPos].X = OutLineDicRst["Out_" + _grabPos].OutputXYT.X + LineY.X;
            PosBeyondLineY[_grabPos].Y = OutLineDicRst["Out_" + _grabPos].OutputXYT.Y + LineY.Y;

            CogDrawMarkerInfo drawPointY = new CogDrawMarkerInfo();
            MarkDrawTest(new XYT(PosBeyondLineY[_grabPos].X, PosBeyondLineY[_grabPos].Y, 0), ref drawPointY);

            switch (_grabPos)
            {
                case "Frnt_L":
                    P1_DisplayObj.DrawMaker(drawPointX);
                    P1_DisplayObj.DrawMaker(drawPointY);
                    break;
                case "Frnt_R":
                    P2_DisplayObj.DrawMaker(drawPointX);
                    P2_DisplayObj.DrawMaker(drawPointY);
                    break;
                case "Rear_L":
                    P3_DisplayObj.DrawMaker(drawPointX);
                    P3_DisplayObj.DrawMaker(drawPointY);
                    break;
                case "Rear_R":
                    P4_DisplayObj.DrawMaker(drawPointX);
                    P4_DisplayObj.DrawMaker(drawPointY);
                    break;
            }
        }



        protected bool CalcFinalDis_Rev(XY startPos, XY endPos, double scaleX, double scaleY, ref double dis)
        {
            try
            {
                dis = Math.Sqrt(Math.Pow((startPos.X - endPos.X) * scaleX, 2) + Math.Pow((startPos.Y - endPos.Y) * scaleY, 2));
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        protected void CalcFitLinePoint(string grabPos, XY outXpoint, XY outYpoint, ICogImage tempImage, ref XY InPosX, ref XY InPosY)
        {
            CogCreateLineTool creatLineX = new CogCreateLineTool();
            CogCreateLineTool creatLineY = new CogCreateLineTool();

            // LineX
            try
            {
                // 외곽 자재에 'X' 대한 외곽 성분
                creatLineX.InputImage = tempImage;
                creatLineX.Line.X = outXpoint.X;
                creatLineX.Line.Y = outXpoint.Y;
                creatLineX.Line.Rotation = (OutLineDicRst["Out_" + grabPos].Lines[1] as CogLine).Rotation; // 외곽(기준) Line으로 Theta 성분 산출
                creatLineX.Run();

                if (creatLineX.RunStatus.Result == CogToolResultConstants.Accept)
                {

                    CogIntersectLineLineTool makePointX = new CogIntersectLineLineTool();
                    makePointX.InputImage = tempImage;
                    makePointX.LineA = creatLineX.GetOutputLine();
                    makePointX.LineB = InLineDicRst["In_" + grabPos].Lines[0] as CogLine;
                    makePointX.Run();

                    if (makePointX.RunStatus.Result == CogToolResultConstants.Accept)
                    {
                        InPosX = new XY(makePointX.X, makePointX.Y);
                    }
                    else
                    {
                        InPosX = outXpoint;
                    }
                }
                else
                {
                    InPosX = outXpoint;
                }
            }

            catch (Exception e)
            {
                InPosX = outXpoint; // for Start와 End Point 동일하게 하여 측정 길이 '0'
            }


            // LineY
            try
            {
                // 외곽 자재에 'Y' 대한 외곽 성분
                creatLineY.InputImage = tempImage;
                creatLineY.Line.X = outYpoint.X;
                creatLineY.Line.Y = outYpoint.Y;
                creatLineY.Line.Rotation = (OutLineDicRst["Out_" + grabPos].Lines[0] as CogLine).Rotation;
                creatLineY.Run();

                if (creatLineY.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    CogIntersectLineLineTool makePointY = new CogIntersectLineLineTool();
                    makePointY.InputImage = tempImage;
                    makePointY.LineA = creatLineY.GetOutputLine();
                    makePointY.LineB = InLineDicRst["In_" + grabPos].Lines[1] as CogLine;
                    makePointY.Run();

                    if (makePointY.RunStatus.Result == CogToolResultConstants.Accept)
                    {
                        InPosY = new XY(makePointY.X, makePointY.Y);
                    }
                    else
                    {
                        InPosY = outYpoint;
                    }
                }
                else
                {
                    InPosY = outYpoint;
                }
            }

            catch (Exception e)
            {
                InPosY = outYpoint;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Robot1_"></param>
        /// <param name="Robot2_"></param>
        /// <param name="panelangle_rad"></param>
        /// <param name="color"></param>
        /// <param name="mode"></param>
        protected void DrawLineLabel(CogDisplayObject P_DisplayObj, XY P1, XY P2, double distRst, CogColorConstants color = CogColorConstants.Cyan, bool bLine = true, bool bLable = true)
        {
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = color;
            lineInfo.Start.X = P1.X;
            lineInfo.Start.Y = P1.Y;
            lineInfo.End.X = P2.X;
            lineInfo.End.Y = P2.Y;
            if (bLine)
                P_DisplayObj.DrawLine(lineInfo);

            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            XY Shift = new XY(0, -200);
            labelInfo.Offset = (lineInfo.End + lineInfo.Start) / 2 + Shift;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Color = color;
            labelInfo.Text = string.Format("{0:f3}mm", distRst);
            if (bLable)
                P_DisplayObj.DrawLabel(labelInfo);
        }
        protected void DrawLineLabel_NG(string Pos_XY, CogDisplayObject P_DisplayObj, XY Pos, double distRst, CogColorConstants color = CogColorConstants.Cyan, bool bLine = true, bool bLable = true)
        {
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.Yellow;
            labelInfo.Offset = Pos;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = "Compensated Data" + Pos_XY + ":" + string.Format("{0:f3}mm", distRst);
            if (bLable)
                P_DisplayObj.DrawLabel(labelInfo);
        }
        #endregion

        #region Side Methode
        public void UploadFDCdata(Dictionary<string, XY> DisRsts, Dictionary<string, double> RstCenterAlign, bool bResult)
        {
            var IOs = new List<IOStruct>(); 

            visionValues["Align_Upper_X"].NextValue = RstCenterAlign["UpperCenterAlign"]; IOs.Add(VisionValues["Align_Upper_X"]);
            visionValues["Align_Lower_X"].NextValue = RstCenterAlign["LowerCenterAlign"]; IOs.Add(VisionValues["Align_Lower_X"]);
            visionValues["Align_Left_Y"].NextValue  = RstCenterAlign["LeftCenterAlign"];   IOs.Add(VisionValues["Align_Left_Y"]);
            visionValues["Align_Right_Y"].NextValue = RstCenterAlign["RightCenterAlign"]; IOs.Add(VisionValues["Align_Right_Y"]);

            foreach (var _disRst in DisRsts)
            {
                switch (_disRst.Key)
                {
                    case "Frnt_L":
                        visionValues["InspDistX1"].NextValue = _disRst.Value.X as object; IOs.Add(VisionValues["InspDistX1"]);
                        visionValues["InspDistY1"].NextValue = _disRst.Value.Y as object; IOs.Add(VisionValues["InspDistY1"]);
                        break;
                    case "Rear_L":
                        visionValues["InspDistX2"].NextValue = _disRst.Value.X as object; IOs.Add(VisionValues["InspDistX2"]);
                        visionValues["InspDistY2"].NextValue = _disRst.Value.Y as object; IOs.Add(VisionValues["InspDistY2"]);
                        break;
                    case "Rear_R":
                        visionValues["InspDistX3"].NextValue = _disRst.Value.X as object; IOs.Add(VisionValues["InspDistX3"]);
                        visionValues["InspDistY3"].NextValue = _disRst.Value.Y as object; IOs.Add(VisionValues["InspDistY3"]);
                        break;
                    case "Frnt_R":
                        visionValues["InspDistX4"].NextValue = _disRst.Value.X as object; IOs.Add(VisionValues["InspDistX4"]);
                        visionValues["InspDistY4"].NextValue = _disRst.Value.Y as object; IOs.Add(VisionValues["InspDistY4"]);
                        break;
                }
            }

            CommodObject.SetVisionValues(IOs);
        }
        public void CompensateData(double designDis_1, double designDis_2, double resultDis_1, double resultDis_2, ref string AlterArea, string Area, 
                                   XY start_L, XY end_L, XY start_R, XY end_R)
        {
            //* Diff = Abs(실제Dis - 이상치 거리) 
            double DiffKey1 = Math.Abs(resultDis_1 - designDis_1);
            double DiffKey2 = Math.Abs(resultDis_2 - designDis_2);
            double designSumDis = designDis_1 + designDis_2;

            string Pos_XY = "";
            if(resultDis_1 == 0 && resultDis_2 == 0) // 운이 더러워서 마주보는 Dis를 모두 못찾음 '0'이 결과...
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult["Frnt_L"].X = 0;
                        distResult["Frnt_R"].X = 0;
                        Pos_XY = "X";
                        DrawLineLabel_NG(Pos_XY, P1_DisplayObj, new XY(1200, 500), distResult["Frnt_L"].X, CogColorConstants.Red, true, true);
                        DrawLineLabel_NG(Pos_XY, P2_DisplayObj, new XY(1200, 500), distResult["Frnt_R"].X, CogColorConstants.Red, true, true);
                        break;

                    case "X2_X3":
                        distResult["Rear_L"].X = 0;
                        distResult["Rear_R"].X = 0;
                        Pos_XY = "X";
                        DrawLineLabel_NG(Pos_XY, P3_DisplayObj, new XY(1200, 500), distResult["Rear_L"].X, CogColorConstants.Red, true, true);
                        DrawLineLabel_NG(Pos_XY, P4_DisplayObj, new XY(1200, 500), distResult["Rear_R"].X, CogColorConstants.Red, true, true);
                        break;

                    case "Y1_Y2":
                        distResult["Frnt_L"].Y = 0;
                        distResult["Rear_L"].Y = 0;
                        Pos_XY = "Y";
                        DrawLineLabel_NG(Pos_XY, P1_DisplayObj, new XY(1200, 700), distResult["Frnt_L"].Y, CogColorConstants.Red, true, true);
                        DrawLineLabel_NG(Pos_XY, P2_DisplayObj, new XY(1200, 700), distResult["Frnt_R"].Y, CogColorConstants.Red, true, true);
                        break;

                    case "Y3_Y4":
                        distResult["Frnt_R"].Y = 0;
                        distResult["Rear_R"].Y = 0;
                        Pos_XY = "Y";
                        DrawLineLabel_NG(Pos_XY, P2_DisplayObj, new XY(1200, 700), distResult["Frnt_R"].Y, CogColorConstants.Red, true, true);
                        DrawLineLabel_NG(Pos_XY, P4_DisplayObj, new XY(1200, 700), distResult["Rear_R"].Y, CogColorConstants.Red, true, true);
                        break;
                }
            }
            else if (DiffKey1 > DiffKey2) //* 이상치 대비 큰 쪽을 수정해 줌.
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult["Frnt_L"].X = designSumDis - distResult["Frnt_R"].X;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "X";
                            DrawLineLabel_NG(Pos_XY, P1_DisplayObj, new XY(1200,500), distResult["Frnt_L"].X, CogColorConstants.Red, true, true);
                        }              
                        break;


                    case "X2_X3":
                        distResult["Rear_L"].X = designSumDis - distResult["Rear_R"].X;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "X";
                            DrawLineLabel_NG(Pos_XY, P3_DisplayObj, new XY(1200, 500), distResult["Rear_L"].X, CogColorConstants.Red, true, true);
                        }
                        break;


                    case "Y1_Y2":
                        distResult["Frnt_L"].Y = designSumDis - distResult["Rear_L"].Y;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "Y";
                            DrawLineLabel_NG(Pos_XY, P1_DisplayObj, new XY(1200, 700), distResult["Frnt_L"].Y, CogColorConstants.Red, true, true);
                        }
                        break;


                    case "Y3_Y4":
                        distResult["Rear_R"].Y = designSumDis - distResult["Frnt_R"].Y;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "Y";
                            DrawLineLabel_NG(Pos_XY, P4_DisplayObj, new XY(1200, 700), distResult["Rear_R"].Y, CogColorConstants.Red, true, true);
                        }
                        break;
                }
                AlterArea += "(" + Area + ">)";
            }

            else if (DiffKey1 < DiffKey2)
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult["Frnt_R"].X = designSumDis - distResult["Frnt_L"].X;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "X";
                            DrawLineLabel_NG(Pos_XY, P2_DisplayObj, new XY(1200, 500), distResult["Frnt_R"].X, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "X2_X3":
                        distResult["Rear_R"].X = designSumDis - distResult["Rear_L"].X;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "X";
                            DrawLineLabel_NG(Pos_XY, P4_DisplayObj, new XY(1200, 500), distResult["Rear_R"].X, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "Y1_Y2":
                        distResult["Rear_L"].Y = designSumDis - distResult["Frnt_L"].Y;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "Y";
                            DrawLineLabel_NG(Pos_XY, P3_DisplayObj, new XY(1200, 700), distResult["Rear_L"].Y, CogColorConstants.Red, true, true);
                        }
                        break;

                    case "Y3_Y4":
                        distResult["Frnt_R"].Y = designSumDis - distResult["Rear_R"].Y;
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "Y";
                            DrawLineLabel_NG(Pos_XY, P2_DisplayObj, new XY(1200, 700), distResult["Frnt_R"].Y, CogColorConstants.Red, true, true);
                        }
                        break;
                }
                AlterArea += "(" + Area + "<)";
            }          
        }

        public void CompensateData_D_Main(double designDis_1, double designDis_2, double resultDis_1, double resultDis_2, ref string AlterArea, string Area, XY start_L, XY end_L, XY start_R, XY end_R)
        {
            //* Diff = Abs(실제Dis - 이상치 거리) 
            double DiffKey1 = Math.Abs(resultDis_1 - designDis_1);
            double DiffKey2 = Math.Abs(resultDis_2 - designDis_2);

            string Pos_XY = "";

            if(resultDis_1 ==0 && resultDis_2 == 0) // 운이 더러워서 마주보는 Dis를 모두 못찾음 '0'이 결과...
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult["Frnt_L"].X = 0;
                        distResult["Frnt_R"].X = 0;
                        break;

                    case "X2_X3":
                        distResult["Rear_L"].X = 0;
                        distResult["Rear_R"].X = 0;
                        break;
                }
                AlterArea += "(" + Area + ")=";
            }

            else if (DiffKey1 > DiffKey2) //* 이상치 대비 큰 쪽을 수정해 줌.
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult["Frnt_L"].X = designDis_1 - (designDis_2 - distResult["Frnt_R"].X);
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "X";
                            DrawLineLabel_NG(Pos_XY, P1_DisplayObj, new XY(1200, 500), distResult["Frnt_L"].X, CogColorConstants.Red, true, true);
                        }
                        break;


                    case "X2_X3":
                        distResult["Rear_L"].X = designDis_1 - (designDis_2 - distResult["Rear_R"].X);
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "X";
                            DrawLineLabel_NG(Pos_XY, P3_DisplayObj, new XY(1200, 500), distResult["Rear_L"].X, CogColorConstants.Red, true, true);
                        }
                        break;
                }
                AlterArea += "(" + Area + ")>";
            }

            else if (DiffKey1 < DiffKey2)
            {
                switch (Area)
                {
                    case "X1_X4":
                        distResult["Frnt_R"].X = designDis_2 - (designDis_1 - distResult["Frnt_L"].X);
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "X";
                            DrawLineLabel_NG(Pos_XY, P2_DisplayObj, new XY(1200, 500), distResult["Frnt_R"].X, CogColorConstants.Red, true, true);
                        }
                        break;


                    case "X2_X3":
                        distResult["Rear_R"].X = designDis_2 - (designDis_1 - distResult["Rear_L"].X);
                        if (resultDis_1 == 0 || resultDis_2 == 0)   //라인 못찾았을 때
                        {
                            Pos_XY = "X";
                            DrawLineLabel_NG(Pos_XY, P4_DisplayObj, new XY(1200, 500), distResult["Rear_R"].X, CogColorConstants.Red, true, true);
                        }
                        break;
                }
                AlterArea += "(" + Area + ")<";
            }
        }
            
        public bool AccuracyCheck_Dis(double designSum, double disSum, double AccuracyTh)
        {
            //AccuracyTh = 0.1;
            if (disSum == 0) return true;
            if (Math.Abs(disSum - designSum) > AccuracyTh) { return false; }
            return true;
        }

        public bool AccuracyCheck_Dis_D_Main(
            double distResult_1, double distParam_1, double distResult_2, double distParam_2, double AccuracyTh)
        {
            double CAlignValue_1 = distResult_1 - distParam_1;
            double CAlignValue_2 = distResult_2 - distParam_2;

            if (Math.Abs(CAlignValue_1 - CAlignValue_2) > AccuracyTh) {
                return false;
            }

            if ((distResult_1 + distResult_2) == 0) {
                return true;
            }

            return true;
        }

        public void MarkDrawTest(XYT Point, ref CogDrawMarkerInfo ContactPoint)
        {
            // Contact Point_X    
            ContactPoint.SizeInScreenPixels = 50;
            ContactPoint.Color = CogColorConstants.Orange;
            ContactPoint.Offset = Point;
        }

        protected bool InitInsp_Err(ref Dictionary<string, bool> errCode)
        {
            errCode.Add("Err_Obtain_InputData", true);
            errCode.Add("Err_Cal_MarkToLine", true);
            return true;
        }

        public override void DefaultIOSet()
        {
            base.DefaultIOSet();

            plcValues = new Dictionary<string, IOStruct>();
            visionValues = new Dictionary<string, IOStruct>();



            // 해당 하는 io를 가져온다.
            //PlcIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();
            //VisionIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();

            plcValues.Clear();
            visionValues.Clear();


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    PlcIOs.Add(item);
                    plcValues.Add(item.Key, item);
                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if ((item.Type.Name != "Boolean" && !item.Key.Contains("Reserve")) || item.Key.Contains("InspectionOK") || item.Key.Contains("InspectionNG"))
                //if (!item.Key.Contains("Reserve"))
                    {
                    VisionIOs.Add(item);
                    visionValues.Add(item.Key, item);
                }
            }
        }
        public override void ObjectInitialize()
        {
            base.ObjectInitialize();

            if (AlignTableObject == null) return;


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    if (!plcValues.ContainsKey(item.Key))
                    {
                        plcValues.Add(item.Key, item);
                    }

                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                //if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                // if (!item.Key.Contains("Reserve"))
                if ((item.Type.Name != "Boolean" && !item.Key.Contains("Reserve")) || item.Key.Contains("InspectionOK") || item.Key.Contains("InspectionNG"))
                {
                    if (!visionValues.ContainsKey(item.Key))
                    {
                        visionValues.Add(item.Key, item);
                    }
                }
            }
        }
        
        public override void Dispose()
        {
            base.Dispose();
        }

        public override void ObjectUpdate()
        {
            base.ObjectUpdate();

            PlcIOsListConverter.Module = CommObj;
            VisionIOsListConverter.Module = CommObj;
        }

        public void WriteVisionIO(XYT rev1, Dictionary<string, XY> insp, string ID)
        {
            var IOs = new List<IOStruct>();

            VisionValues["InspectRev_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["InspectRev_X"]);
            VisionValues["InspectRev_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["InspectRev_Y"]);
            VisionValues["InspectRev_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["InspectRev_T"]);

            foreach (int i in Enum.GetValues(typeof(InspectionPos)))
            {
                string pos = "";
                switch (i)
                {
                    case 0:
                        pos = "Out_Fnt_L";
                        break;
                    case 1:
                        pos = "Out_Rear_L";
                        break;
                    case 2:
                        pos = "Out_Rear_R";
                        break;
                    case 3:
                        pos = "Out_Fnt_R";
                        break;
                }
                VisionValues["InspDistX" + (i + 1).ToString()].NextValue = (double)insp[pos].X;
                IOs.Add(VisionValues["InspDistX" + (i + 1).ToString()]);

                VisionValues["InspDistY" + (i + 1).ToString()].NextValue = (double)insp[pos].Y;
                IOs.Add(VisionValues["InspDistY" + (i + 1).ToString()]);
            }
            CommodObject.SetVisionValues(IOs);
        }

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (cogDisp == null) return;
            Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }
        #endregion
    }
}
