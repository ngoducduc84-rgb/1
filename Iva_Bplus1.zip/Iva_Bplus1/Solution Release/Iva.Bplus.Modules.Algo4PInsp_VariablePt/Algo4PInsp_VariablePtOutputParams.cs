﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo4PInsp_VariablePt
{
    class Algo4PInsp_VariablePtOutputParams : OutputParams
    {
        public object LogResult { get; set; }
    }
}
