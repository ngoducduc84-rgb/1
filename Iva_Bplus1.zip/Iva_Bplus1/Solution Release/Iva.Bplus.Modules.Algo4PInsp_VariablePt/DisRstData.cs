﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using System.Drawing;
using Cognex.VisionPro;
using SvMip;

namespace Iva.Bplus.Struct
{
    public enum UseMachineSort { D_Sub, D_Main };

    [SerializableAttribute]
    public class DisRstData : OutputParams, IDisposable // ,IPointResult
    {
        #region [Construct]
        public DisRstData()
        {
            // new 
            scales = new XY(0, 0);
            disXY = new XY(0, 0);
            contactPointX = new XY(0, 0); // X Line 접점 Point 
            contactPointY = new XY(0, 0); // Y Line 접점 Point 
            outputXYT = new XYT(0, 0, 0);

            angle = 0;
            outputImage = null;
            resultGraphics = null;

            lines = new List<object>();
            rstDistance = new XY(0, 0);
        }

        public DisRstData(XY _contactPointX, XY _contactPointY, XYT _outputXYT, double _angle)
        {
            scales = new XY(0, 0);
            disXY = new XY(0, 0);
            contactPointX = _contactPointX;
            contactPointY = _contactPointY;
            outputXYT = _outputXYT;
            angle = Angle;
            lines = new List<object>();
        }
        public DisRstData(XY _contactPointX, XY _contactPointY, XYT _outputXYT, double _angle, object _outImg, List<object> _lines, XY _rstDistance)
        {
            scales = new XY(0, 0);
            disXY = new XY(0, 0);
            contactPointX = _contactPointX;
            contactPointY = _contactPointY;

            outputXYT = _outputXYT;

            angle = _angle;
            outputImage = _outImg;
            resultGraphics = null;
            lines = _lines;
            rstDistance = _rstDistance;
        }
        #endregion

        #region [Fields]
        [field: NonSerialized]
        private List<object> lines;
        [field: NonSerialized]
        private XYT outputXYT;
        [field: NonSerialized]
        private double angle;
        [field: NonSerialized]
        private object outputImage;
        [field: NonSerialized]
        private object resultGraphics;
        [field: NonSerialized]
        private List<XYT> refPoints;
        [field: NonSerialized]
        private string message;
        [field: NonSerialized]
        private XY rstDistance;

        // New
        [field: NonSerialized]
        private XY contactPointX;
        [field: NonSerialized]
        private XY contactPointY;
        [field: NonSerialized]
        private XY scales;
        [field: NonSerialized]
        private XY disXY;

        #endregion

        // New

        public XY DisXY
        {
            get { return disXY; }
            set { if (disXY == value) return; disXY = value; this.OnPropertyChanged(nameof(DisXY)); }
        }
        public XY Scales
        {
            get { return scales; }
            set { if (scales == value) return; scales = value; this.OnPropertyChanged(nameof(Scales)); }
        }

        public XY RstDistance
        {
            get { return rstDistance; }
            set { if (rstDistance == value) return; rstDistance = value; this.OnPropertyChanged(nameof(RstDistance)); }
        }


        /// <summary>
        /// Mark 또는 Cross Point 정보
        /// </summary>
        public List<object> Lines
        {
            get { return lines; }
            set { if (lines == value) return; lines = value; this.OnPropertyChanged(nameof(Lines)); }
        }


        /// <summary>
        /// Mark 또는 Cross Point 정보
        /// </summary>
        /// private XY
        /// 
        public XYT OutputXYT
        {
            get { return outputXYT; }
            set { if (outputXYT == value) return; outputXYT = value; this.OnPropertyChanged(nameof(OutputXYT)); }
        }
        public XY ContactPointX
        {
            get { return contactPointX; }
            set { if (contactPointX == value) return; contactPointX = value; this.OnPropertyChanged(nameof(ContactPointX)); }
        }

        public XY ContactPointY
        {
            get { return contactPointY; }
            set { if (contactPointY == value) return; contactPointY = value; this.OnPropertyChanged(nameof(ContactPointY)); }
        }

        /// <summary>
        /// Cross Poinst 각도
        /// </summary>
        public double Angle
        {
            get { return angle; }
            set { if (angle == value) return; angle = value; this.OnPropertyChanged(nameof(Angle)); }
        }

        public List<XYT> RefPoints
        {
            get { return refPoints; }
            set { if (refPoints == value) return; refPoints = value; this.OnPropertyChanged(nameof(RefPoints)); }
        }

        /// <summary>
        /// 결과 이미지
        /// </summary>
        public object OutputImage
        {
            get { return outputImage; }
            set { if (outputImage == value) return; outputImage = value; this.OnPropertyChanged(nameof(OutputImage)); }
        }

        /// <summary>
        /// 결과 그래픽
        /// </summary>
        public object ResultGraphics
        {
            get { return resultGraphics; }
            set { if (resultGraphics == value) return; resultGraphics = value; this.OnPropertyChanged(nameof(ResultGraphics)); }
        }

        /// <summary>
        /// 이미지 중심위치
        /// </summary>
        public XY CenterPoint
        {
            get
            {
                if (outputImage == null) return new XY();

                XY ret = new XY();
                if (OutputImage is ICogImage)
                {
                    ret.X = (OutputImage as ICogImage).Width / 2;
                    ret.Y = (OutputImage as ICogImage).Height / 2;
                }
                else if (OutputImage is SvImage)
                {
                    ret.X = (OutputImage as ICogImage).Width / 2;
                    ret.Y = (OutputImage as ICogImage).Height / 2;
                }

                return ret;
            }
        }



        public string Message { get { return message; }set { if (message == value) return; message = value; this.OnPropertyChanged(nameof(Message)); } }

        public object CalData
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public override string ToString()
        {
            // return string.Format("{0} :\n X: {1:F2}\n Y: {2:F2}\n T: {3:F5}\n", typeof(DisRstData).ToString(), outputXYT.X, outputXYT.Y, outputXYT.T);
            return string.Format("{0} :\n DistX: {1:F2}\n DisY: {2:F2}\n", typeof(DisRstData).ToString(), RstDistance.X, RstDistance.Y);
        }

        public void Dispose()
        {
            
        }

        public DisplayObjectBase DisplayObj { get; set; }

    }
}
