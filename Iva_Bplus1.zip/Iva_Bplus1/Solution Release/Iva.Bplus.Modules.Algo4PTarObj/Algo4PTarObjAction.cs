﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4PTarObj
{
    [SerializableAttribute]
    public partial class Algo4PTarObjAction : Lami90AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private double objLengthUpper;
        [field: NonSerialized]
        private double objLengthLower;
        [field: NonSerialized]
        private double objLengthLeft;
        [field: NonSerialized]
        private double objLengthRight;
        [field: NonSerialized]
        private double tarLengthUpper;
        [field: NonSerialized]
        private double tarLengthLower;
        [field: NonSerialized]
        private double tarLengthLeft;
        [field: NonSerialized]
        private double tarLengthRight;

        #endregion

        #region [Properties]   
        public double ObjLengthUpper { get { return objLengthUpper; } set { if (objLengthUpper == value) return; objLengthUpper = value; this.OnPropertyChanged(nameof(ObjLengthUpper)); } }
        public double ObjLengthLower { get { return objLengthLower; } set { if (objLengthLower == value) return; objLengthLower = value; this.OnPropertyChanged(nameof(ObjLengthLower)); } }
        public double ObjLengthLeft { get { return objLengthLeft; } set { if (objLengthLeft == value) return; objLengthLeft = value; this.OnPropertyChanged(nameof(ObjLengthLeft)); } }
        public double ObjLengthRight { get { return objLengthRight; } set { if (objLengthRight == value) return; objLengthRight = value; this.OnPropertyChanged(nameof(ObjLengthRight)); } }

        public double TarLengthUpper { get { return tarLengthUpper; } set { if (tarLengthUpper == value) return; tarLengthUpper = value; this.OnPropertyChanged(nameof(TarLengthUpper)); } }
        public double TarLengthLower { get { return tarLengthLower; } set { if (tarLengthLower == value) return; tarLengthLower = value; this.OnPropertyChanged(nameof(TarLengthLower)); } }
        public double TarLengthLeft { get { return tarLengthLeft; } set { if (tarLengthLeft == value) return; tarLengthLeft = value; this.OnPropertyChanged(nameof(TarLengthLeft)); } }
        public double TarLengthRight { get { return tarLengthRight; } set { if (tarLengthRight == value) return; tarLengthRight = value; this.OnPropertyChanged(nameof(TarLengthRight)); } }

        #endregion

        #region [Construct]
        public Algo4PTarObjAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo4PTarObjInputParams();
            OutputParams = new Algo4PTarObjOutputParams();

            var obj = _object as Algo4PTarObjObject;
            obj.ModelParamType = typeof(Algo4PTarObjModelParams);
            var param = obj.CurParams as Algo4PTarObjModelParams;

            ChildSettingView = new AlignSetting();
            ChildSettingView.DataContext = this;

            (_object as ModuleObjectBase).AddValidationSkipProperty("Obj_1st_L");
            (_object as ModuleObjectBase).AddValidationSkipProperty("Obj_1st_R");
            (_object as ModuleObjectBase).AddValidationSkipProperty("Obj_2st_L");
            (_object as ModuleObjectBase).AddValidationSkipProperty("Obj_2st_R");

            (_object as ModuleObjectBase).AddValidationSkipProperty("Tar_1st_L");
            (_object as ModuleObjectBase).AddValidationSkipProperty("Tar_1st_R");
            (_object as ModuleObjectBase).AddValidationSkipProperty("Tar_2st_L");
            (_object as ModuleObjectBase).AddValidationSkipProperty("Tar_2st_R");

            if (obj.Options == null) obj.Options = new Algo4PTarObjModelOptions();
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args);
            var Obj = modObject as Algo4PTarObjObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                var algoCmd = _args.Value as AlgoCommandInfo;

                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                DateTime dateTime = DateTime.Now;

                if (Obj.InputValues.Count == 0)
                {
                    Obj.InputValues = InputValues;
                }

                Obj.Run();

                InsertErrorCode(Obj.errorCodeLami);
                
                //Length data 업데이트
                if (Obj.Length.Count == 8)
                {
                    ObjLengthUpper = Obj.Length["Obj_Upper"];
                    ObjLengthLower = Obj.Length["Obj_Lower"];
                    ObjLengthLeft = Obj.Length["Obj_Left"];
                    ObjLengthRight = Obj.Length["Obj_Right"];
                    TarLengthUpper = Obj.Length["Tar_Upper"];
                    TarLengthLower = Obj.Length["Tar_Lower"];
                    TarLengthLeft = Obj.Length["Tar_Left"];
                    TarLengthRight = Obj.Length["Tar_Right"];
                }

                // 1> Data 저장 (정상적으로 동작 시 )
                SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);

                // 2> Connector에 Data 옮기는 부분
                XYT results = new XYT();
                SetResult(ref results);

                // 3> UVW 변환 부분을 Return하는 부분
                List<CommandReplyArgs> rply = OutputPlay("ConvertXYT", Obj.RevAlign, CmdRequest.Play, CmdMode.Link, CmdWait.Last_Wait);
                XXYY value = rply[0].ReturnValue as XXYY;
                Obj.WriteVisionIO(value, "");

                // 4> Log에 대한 DataGridView에 넘겨줌
                OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                // 5> Error 보고
                if (!ConfirmReplayArgs(ReplyArgs)) { return OccurError(); }

                // 6) 보정값이 0이면 에러발생
                if (results.X == 0 && results.Y == 0 && results.T == 0) return OccurError(Lami90AlgoActionBase.E15025_0_REVOFFSET);

                Obj.AppendMessage(Name, "Caluration Complete");
                StopTimer();
            }

            return End();
        }

        #endregion

        #region [Command]
        private void SetResult(ref XYT results)
        {
            var param = OutputParams as Algo4PTarObjOutputParams;
            var obj = ModObject as Algo4PTarObjObject;

            // UVW 활용
            results.X = (obj.AlgoRst as Algo4PTarObjResult).RevX;
            results.Y = (obj.AlgoRst as Algo4PTarObjResult).RevY;
            results.T = (obj.AlgoRst as Algo4PTarObjResult).RevT;

            param.Result = results;

            base.UpdateResult();

            OnOutputChanged(param);
        }

        [field: NonSerialized]
        private DelegateCommand lengthSetCommand;
        public DelegateCommand LengthSetCommand
        {
            get
            {
                return lengthSetCommand = lengthSetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo4PTarObjModelParams;

                    tmp.ObjLengthLower_Offset.Value = Math.Round((double)tmp.ObjLengthLower.Value- ObjLengthLower, 4);
                    tmp.ObjLengthUpper_Offset.Value = Math.Round((double)tmp.ObjLengthUpper.Value- ObjLengthUpper, 4);
                    tmp.ObjLengthLeft_Offset.Value  = Math.Round((double)tmp.ObjLengthLeft.Value- ObjLengthLeft, 4);
                    tmp.ObjLengthRight_Offset.Value = Math.Round((double)tmp.ObjLengthRight.Value- ObjLengthRight, 4);
                    tmp.TarLengthLower_Offset.Value = Math.Round((double)tmp.TarLengthLower.Value- TarLengthLower, 4);
                    tmp.TarLengthUpper_Offset.Value = Math.Round((double)tmp.TarLengthUpper.Value- TarLengthUpper, 4);
                    tmp.TarLengthLeft_Offset.Value  = Math.Round((double)tmp.TarLengthLeft.Value- TarLengthLeft, 4);
                    tmp.TarLengthRight_Offset.Value = Math.Round((double)tmp.TarLengthRight.Value- TarLengthRight, 4);
                    Obj.UpdateTempValues();

                });

            }
        }
        #endregion

        #region [Override]
        public override void PrepareSave()
        {
            base.PrepareSave();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion

    }
}
