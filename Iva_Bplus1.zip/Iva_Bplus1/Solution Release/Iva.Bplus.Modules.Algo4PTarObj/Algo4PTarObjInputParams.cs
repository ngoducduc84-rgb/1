﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo4PTarObj
{
    [SerializableAttribute]
    class Algo4PTarObjInputParams : InputParams
    {
        #region Input P1, P2, P3, P4
        public IPointResult Tar_1st_L { get; set; }
        public IPointResult Tar_1st_R { get; set; }
        public IPointResult Tar_2st_L { get; set; }
        public IPointResult Tar_2st_R { get; set; }

        public IPointResult Obj_1st_L { get; set; }
        public IPointResult Obj_1st_R { get; set; }
        public IPointResult Obj_2st_L { get; set; }
        public IPointResult Obj_2st_R { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
