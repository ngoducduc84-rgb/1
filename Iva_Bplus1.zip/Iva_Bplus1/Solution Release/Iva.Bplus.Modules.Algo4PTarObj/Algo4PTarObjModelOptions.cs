﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Iva.Bplus.Enums;
using Telerik.Windows.Data;

namespace Iva.Bplus.Modules.Algo4PTarObj
{
    [SerializableAttribute, DataContract]
    class Algo4PTarObjModelOptions : AlgoOptions
    {
        private AlgoOption useWindow3PointAlign;
        private AlgoOption usePanel3PointAlign;
        public AlgoOption UsePanel3PointAlign { get { return usePanel3PointAlign; } set { if (usePanel3PointAlign == value) return; usePanel3PointAlign = value; this.OnPropertyChanged(nameof(usePanel3PointAlign)); } }
        public AlgoOption UseWindow3PointAlign { get { return useWindow3PointAlign; } set { if (useWindow3PointAlign == value) return; useWindow3PointAlign = value; this.OnPropertyChanged(nameof(useWindow3PointAlign)); } }

        public Algo4PTarObjModelOptions()
        {
            UsePanel3PointAlign = new AlgoOption("Use Panel 3Point Align", OnOff.Off, "Use Panel 3Point Align : Off - Only 4Point Align, On - 4 & 3Point Align");
            UseWindow3PointAlign = new AlgoOption("Use Window 3Point Align", OnOff.Off, "Use Panel Window Align : Off - Only 4Point Align, On - 4 & 3Point Align");
        }
    }
}
