﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo4PTarObj
{
    [SerializableAttribute]

    public partial class Algo4PTarObjModelParams : AlgoParams
    {
        #region Lenght Center/Tor -> OK      
        private AlgoParam objLengthLower;
        private AlgoParam objLengthLeft;
        private AlgoParam objLengthUpper;
        private AlgoParam objLengthRight;

        private AlgoParam objLengthLower_Offset;
        private AlgoParam objLengthLeft_Offset;
        private AlgoParam objLengthUpper_Offset;
        private AlgoParam objLengthRight_Offset;

        private AlgoParam tarLengthLower;
        private AlgoParam tarLengthLeft;
        private AlgoParam tarLengthUpper;
        private AlgoParam tarLengthRight;

        private AlgoParam tarLengthLower_Offset;
        private AlgoParam tarLengthLeft_Offset;
        private AlgoParam tarLengthUpper_Offset;
        private AlgoParam tarLengthRight_Offset;

        private AlgoParam objLengthTor;
        private AlgoParam tarLengthTor;

        #endregion

        #region Align Limit
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        #endregion

        #region Angle Center
        private AlgoParam angleCenter;
        private AlgoParam angleTor;
        #endregion


        #region Length Properties -> OK
        public AlgoParam ObjLengthLeft { get { return objLengthLeft; } set { if (objLengthLeft == value) return; objLengthLeft = value; this.OnPropertyChanged(nameof(ObjLengthLeft)); } }
        public AlgoParam ObjLengthRight { get { return objLengthRight; } set { if (objLengthRight == value) return; objLengthRight = value; this.OnPropertyChanged(nameof(ObjLengthRight)); } }
        public AlgoParam ObjLengthUpper { get { return objLengthUpper; } set { if (objLengthUpper == value) return; objLengthUpper = value; this.OnPropertyChanged(nameof(ObjLengthUpper)); } }
        public AlgoParam ObjLengthLower { get { return objLengthLower; } set { if (objLengthLower == value) return; objLengthLower = value; this.OnPropertyChanged(nameof(ObjLengthLower)); } }
        public AlgoParam ObjLengthLeft_Offset { get { return objLengthLeft_Offset; } set { if (objLengthLeft_Offset == value) return; objLengthLeft_Offset = value; this.OnPropertyChanged(nameof(ObjLengthLeft_Offset)); } }
        public AlgoParam ObjLengthRight_Offset { get { return objLengthRight_Offset; } set { if (objLengthRight_Offset == value) return; objLengthRight_Offset = value; this.OnPropertyChanged(nameof(ObjLengthRight_Offset)); } }
        public AlgoParam ObjLengthUpper_Offset { get { return objLengthUpper_Offset; } set { if (objLengthUpper_Offset == value) return; objLengthUpper_Offset = value; this.OnPropertyChanged(nameof(ObjLengthUpper_Offset)); } }
        public AlgoParam ObjLengthLower_Offset { get { return objLengthLower_Offset; } set { if (objLengthLower_Offset == value) return; objLengthLower_Offset = value; this.OnPropertyChanged(nameof(ObjLengthLower_Offset)); } }

        public AlgoParam TarLengthLeft { get { return tarLengthLeft; } set { if (tarLengthLeft == value) return; tarLengthLeft = value; this.OnPropertyChanged(nameof(TarLengthLeft)); } }
        public AlgoParam TarLengthRight { get { return tarLengthRight; } set { if (tarLengthRight == value) return; tarLengthRight = value; this.OnPropertyChanged(nameof(TarLengthRight)); } }
        public AlgoParam TarLengthUpper { get { return tarLengthUpper; } set { if (tarLengthUpper == value) return; tarLengthUpper = value; this.OnPropertyChanged(nameof(TarLengthUpper)); } }
        public AlgoParam TarLengthLower { get { return tarLengthLower; } set { if (tarLengthLower == value) return; tarLengthLower = value; this.OnPropertyChanged(nameof(TarLengthLower)); } }
        public AlgoParam TarLengthLeft_Offset { get { return tarLengthLeft_Offset; } set { if (tarLengthLeft_Offset == value) return; tarLengthLeft_Offset = value; this.OnPropertyChanged(nameof(TarLengthLeft_Offset)); } }
        public AlgoParam TarLengthRight_Offset { get { return tarLengthRight_Offset; } set { if (tarLengthRight_Offset == value) return; tarLengthRight_Offset = value; this.OnPropertyChanged(nameof(TarLengthRight_Offset)); } }
        public AlgoParam TarLengthUpper_Offset { get { return tarLengthUpper_Offset; } set { if (tarLengthUpper_Offset == value) return; tarLengthUpper_Offset = value; this.OnPropertyChanged(nameof(TarLengthUpper_Offset)); } }
        public AlgoParam TarLengthLower_Offset { get { return tarLengthLower_Offset; } set { if (tarLengthLower_Offset == value) return; tarLengthLower_Offset = value; this.OnPropertyChanged(nameof(TarLengthLower_Offset)); } }


        public AlgoParam ObjLengthTor { get { return objLengthTor; } set { if (objLengthTor == value) return; objLengthTor = value; this.OnPropertyChanged(nameof(ObjLengthTor)); } }
        public AlgoParam TarLengthTor { get { return tarLengthTor; } set { if (tarLengthTor == value) return; tarLengthTor = value; this.OnPropertyChanged(nameof(TarLengthTor)); } }
        #endregion

        #region Align Limit Properties
        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        #endregion

        #region Angle Center/Tor Properties
        public AlgoParam AngleCenter { get { return angleCenter; } set { if (angleCenter == value) return; angleCenter = value; this.OnPropertyChanged(nameof(AngleCenter)); } }
        public AlgoParam AngleTor { get { return angleTor; } set { if (angleTor == value) return; angleTor = value; this.OnPropertyChanged(nameof(AngleTor)); } }
        #endregion

        public Algo4PTarObjModelParams()
            : base()
        {
            ObjLengthLower = new AlgoParam("ObjLengthLower", "mm", typeof(double), 0.0, "Obj Point0 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);
            ObjLengthUpper = new AlgoParam("ObjLengthUpper", "mm", typeof(double), 0.0, "Obj Point2 <-> Obj Point3 Dist", (double)0.0, (double)1000.0);
            ObjLengthLeft = new AlgoParam("ObjLengthLeft ", "mm", typeof(double), 0.0, "Obj Point1 <-> Obj Point2 Dist", (double)0.0, (double)1000.0);
            ObjLengthRight = new AlgoParam("ObjLengthRight", "mm", typeof(double), 0.0, "Obj Point3 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);
                                                                                                                                              
            TarLengthLower = new AlgoParam("TarLengthLower", "mm", typeof(double), 0.0, "Tar Point0 <-> Tar Point1 Dist", (double)0.0, (double)1000.0);
            TarLengthUpper = new AlgoParam("TarLengthUpper", "mm", typeof(double), 0.0, "Tar Point2 <-> Tar Point3 Dist", (double)0.0, (double)1000.0);
            TarLengthLeft = new AlgoParam("TarLengthLeft ", "mm", typeof(double), 0.0, "Tar Point1 <-> Tar Point2 Dist", (double)0.0, (double)1000.0);
            TarLengthRight = new AlgoParam("TarLengthRight", "mm", typeof(double), 0.0, "Tar Point3 <-> Tar Point1 Dist", (double)0.0, (double)1000.0);

            ObjLengthLower_Offset = new AlgoParam("ObjLengthLower_Offset","mm" ,typeof(double), 0.0, "Obj Legnth Offset", (double)-100, (double)100);
            ObjLengthUpper_Offset = new AlgoParam("ObjLengthUpper_Offset", "mm", typeof(double), 0.0, "Obj Legnth Offset", (double)-100, (double)100);
            ObjLengthLeft_Offset = new AlgoParam("ObjLengthLeft_Offset", "mm", typeof(double), 0.0, "Obj Legnth Offset", (double)-100, (double)100);
            ObjLengthRight_Offset = new AlgoParam("ObjLengthRight_Offset", "mm", typeof(double), 0.0, "Obj Legnth Offset", (double)-100, (double)100);
            TarLengthLower_Offset = new AlgoParam("TarLengthLower_Offset", "mm", typeof(double), 0.0, "Tar Legnth Offset", (double)-100, (double)100);
            TarLengthUpper_Offset = new AlgoParam("TarLengthUpper_Offset", "mm", typeof(double), 0.0, "Tar Legnth Offset", (double)-100, (double)100);
            TarLengthLeft_Offset = new AlgoParam("TarLengthLeft_Offset", "mm", typeof(double), 0.0, "Tar Legnth Offset", (double)-100, (double)100);
            TarLengthRight_Offset = new AlgoParam("TarLengthRight_Offset", "mm", typeof(double), 0.0, "Tar Legnth Offset", (double)-100, (double)100);

            ObjLengthTor = new AlgoParam("ObjLengthTor", "mm", typeof(double), 0.0, "L_Check Tar_Tolerance Value", (double)0.0, (double)100.0);
            TarLengthTor = new AlgoParam("TarLengthTor", "mm", typeof(double), 0.0, "L_Check Obj_Tolerance Value", (double)0.0, (double)100.0);

            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);

            AngleCenter = new AlgoParam("AngleCenter", "deg", typeof(double), 90.0, "LineCross Angle Center" , (double)-95.0, (double)95.0);
            AngleTor    = new AlgoParam("AngleTor"   , "deg", typeof(double),  5.0, "Revision Offset Limit T", (double)  0.0, (double) 5.0);
        }
    }

    [Serializable]
    public class LamiMain_PLCTable
    {
        #region [Feilds]
        //public string UnitNo { get; set; }
        //public int OptionNo { get; set; }

        public double CurPosX1 { get; set; }
        public double CurPosX2 { get; set; }
        public double CurPosY1 { get; set; }
        public double CurPosY2 { get; set; }

        public double CamPos { get; set; }
        public double CurCamX { get; set; }
        public double CurCamY { get; set; }

        public double TeachPosCamX { get; set; }
        public double TeachPosCamY_1st { get; set; }
        public double TeachPosCamY_2nd { get; set; }

        public double OffsetX { get; set; }
        public double OffsetY { get; set; }
        public double OffsetT { get; set; }

        public string CellID { get; set; }
        #endregion

        #region [Construct]
        public LamiMain_PLCTable() { }
        #endregion
    }

}
