﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Drawing;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.Algo4PTarObj;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo4PTarObj
{
    public enum eObjPos
    {
        Lower = 0,
        Upper,
        Left,
        Right
    }
    public enum eTarPos
    {
        Lower = 0,
        Upper,
        Left,
        Right
    }

    //            ↓ 투입 방향    
    //            ↓ 

    // Align 방식  <Lower>
    //  0 --------------------- 1 
    //    l [Left]             l [Right]       : 1st
    //    |                    l
    //    l                    l
    //    |                    |  
    //    l                    l         
    //    l                    l         
    //    l                    l         
    //    l                    l         
    //    l [Left]             l [Right]       : 2nd
    //  2 --------------------- 3


    [SerializableAttribute]
    public partial class Algo4PTarObjObject : Lami90AlgoObjectBase
    {
        #region [Fields]  
        [field: NonSerialized]
        public Dictionary<string, bool> errorCodeLami;
        [field: NonSerialized]
        Dictionary<string, IPointResult> InputData;                // new 
        [field: NonSerialized]
        public IPointResult[] TargetPos = new IPointResult[4];
        [field: NonSerialized]
        public IPointResult[] ObjectPos = new IPointResult[4];
        [field: NonSerialized]
        Dictionary<string, XY> RobotPos;
        [field: NonSerialized]
        Dictionary<string, XY> CoorPos;
        [field: NonSerialized]
        Dictionary<string, XY> FixPos;
        [field: NonSerialized]
        public Dictionary<string, double> LineTheta;
        [field: NonSerialized]
        public Dictionary<string, double> Angle;
        [field: NonSerialized]
        CalDataObject[] calDataObj; // 추가 생성
        [field: NonSerialized]
        CalDataObject[] calDataTar; // new       
        [field: NonSerialized]
        XY[] tarRobotPos = new XY[4];
        [field: NonSerialized]
        XY[] tarCoorPos = new XY[4];
        [field: NonSerialized]
        XY[] refCoorPos = new XY[4];
        [field: NonSerialized]
        public double[] refLineTheta = new double[4];
        [field: NonSerialized]
        public XYT objRevPos = new XYT(); // use
        [field: NonSerialized]
        public XYT tarRevPos = new XYT(); // use
        [field: NonSerialized]
        double[] objLength = new double[4];
        [field: NonSerialized]
        double[] tarLength = new double[4];
        [field: NonSerialized]
        public Dictionary<string, double> Length;
        [field: NonSerialized]
        public Dictionary<string, double> LengthOffset;
        private string[] tar_CalData = new string[4]; // new
        private string[] obj_CalData = new string[4]; // new

        [field: NonSerialized]
        LamiMain_PLCTable cvtPLCIO;

        #region Length Check 데이터
        private bool dObjectLength_01_judge;
        private bool dObjectLength_23_judge;
        private bool dObjectLength_02_judge;
        private bool dObjectLength_13_judge;

        private bool dTargetLength_01_judge;
        private bool dTargetLength_23_judge;
        private bool dTargetLength_02_judge;
        private bool dTargetLength_13_judge;
        #endregion

        #endregion

        #region etc
        private CalcType calcType;
        private ThetaCalType thetaCalType;
        private ThetaDirection thetaDirection;
        private UseMaterCalJig useMasterCalJig;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        #endregion

        #region Align관련 Data
        [field: NonSerialized]
        XYT revAlign = new XYT();
        [field: NonSerialized]
        UVRW revXXYY = new UVRW();
        #endregion        

        #region [properties]

        public Dictionary<string, bool> ErrorCodeLami
        {
            get { return errorCodeLami; }
            set
            {
                if (errorCodeLami == value) return;

                errorCodeLami = value;
                OnPropertyChanged("ErrorCodeLami");
            }
        }

        public UVRW RevXXYY { get { return revXXYY; } set { revXXYY = value; } }
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Tar_1st_L
        {
            get { return tar_CalData[0]; }
            set { if (tar_CalData[0] == value) return; tar_CalData[0] = value; this.OnPropertyChanged(nameof(Tar_1st_L)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Tar_1st_R
        {
            get { return tar_CalData[1]; }
            set { if (tar_CalData[1] == value) return; tar_CalData[1] = value; this.OnPropertyChanged(nameof(Tar_1st_R)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Tar_2st_L
        {
            get { return tar_CalData[2]; }
            set { if (tar_CalData[2] == value) return; tar_CalData[2] = value; this.OnPropertyChanged(nameof(Tar_2st_L)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Tar_2st_R
        {
            get { return tar_CalData[3]; }
            set { if (tar_CalData[3] == value) return; tar_CalData[3] = value; this.OnPropertyChanged(nameof(Tar_2st_R)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Obj_1st_L
        {
            get { return obj_CalData[0]; }
            set { if (obj_CalData[0] == value) return; obj_CalData[0] = value; this.OnPropertyChanged(nameof(Obj_1st_L)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Obj_1st_R
        {
            get { return obj_CalData[1]; }
            set { if (obj_CalData[1] == value) return; obj_CalData[1] = value; this.OnPropertyChanged(nameof(Obj_1st_R)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Obj_2st_L
        {
            get { return obj_CalData[2]; }
            set { if (obj_CalData[2] == value) return; obj_CalData[2] = value; this.OnPropertyChanged(nameof(Obj_2st_L)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Obj_2st_R
        {
            get { return obj_CalData[3]; }
            set { if (obj_CalData[3] == value) return; obj_CalData[3] = value; this.OnPropertyChanged(nameof(Obj_2st_R)); }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }
        public ThetaCalType ThetaCalType
        {
            get { return thetaCalType; }
            set { if (thetaCalType == value) return; thetaCalType = value; OnPropertyChanged("ThetaCalType"); }
        }
        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }
        public UseMaterCalJig UseMaterCalJig
        {
            get { return useMasterCalJig; }
            set { if (useMasterCalJig == value) return; useMasterCalJig = value; this.OnPropertyChanged(nameof(UseMaterCalJig)); }
        }

        public bool DObjectLength_01_judge
        {
            get { return dObjectLength_01_judge; }
            set { if (dObjectLength_01_judge == value) return; dObjectLength_01_judge = value; this.OnPropertyChanged(nameof(DObjectLength_01_judge)); }
        }
        public bool DObjectLength_23_judge
        {
            get { return dObjectLength_23_judge; }
            set { if (dObjectLength_23_judge == value) return; dObjectLength_23_judge = value; this.OnPropertyChanged(nameof(DObjectLength_23_judge)); }
        }
        public bool DObjectLength_02_judge
        {
            get { return dObjectLength_02_judge; }
            set { if (dObjectLength_02_judge == value) return; dObjectLength_02_judge = value; this.OnPropertyChanged(nameof(DObjectLength_02_judge)); }
        }
        public bool DObjectLength_13_judge
        {
            get { return dObjectLength_13_judge; }
            set { if (dObjectLength_13_judge == value) return; dObjectLength_13_judge = value; this.OnPropertyChanged(nameof(DObjectLength_13_judge)); }
        }

        public bool DTargetLength_01_judge
        {
            get { return dTargetLength_01_judge; }
            set { if (dTargetLength_01_judge == value) return; dTargetLength_01_judge = value; this.OnPropertyChanged(nameof(DObjectLength_01_judge)); }
        }
        public bool DTargetLength_23_judge
        {
            get { return dTargetLength_23_judge; }
            set { if (dTargetLength_23_judge == value) return; dTargetLength_23_judge = value; this.OnPropertyChanged(nameof(DObjectLength_23_judge)); }
        }
        public bool DTargetLength_02_judge
        {
            get { return dTargetLength_02_judge; }
            set { if (dTargetLength_02_judge == value) return; dTargetLength_02_judge = value; this.OnPropertyChanged(nameof(DObjectLength_02_judge)); }
        }
        public bool DTargetLength_13_judge
        {
            get { return dTargetLength_13_judge; }
            set { if (dTargetLength_13_judge == value) return; dTargetLength_13_judge = value; this.OnPropertyChanged(nameof(DObjectLength_13_judge)); }
        }

        public ObservableCollection<string> CalDataList
        {
            get
            {
                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }

        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        //public XYT RevUnload { get { return revUnload; } }
        #endregion

        #endregion

        #region[Construct]
        public Algo4PTarObjObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));
            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo4PTarObjModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];

            Options = new Algo4PTarObjModelOptions();
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion


        #region 3PAlign 관련
        [field: NonSerialized]
        XY adjustObjPixel;
        [field: NonSerialized]
        XY adjustTarPixel;

        public XY AdjustObjPixel
        {
            get
            {
                if (adjustObjPixel == null)
                    adjustObjPixel = new XY();
                return adjustObjPixel;
            }
            set
            {
                if (adjustObjPixel == value) return;

                adjustObjPixel = value;
                this.OnPropertyChanged(nameof(AdjustObjPixel));
            }
        }
        public XY AdjustTarPixel
        {
            get
            {
                if (adjustTarPixel == null)
                    adjustTarPixel = new XY();
                return adjustTarPixel;
            }
            set
            {
                if (adjustTarPixel == value) return;

                adjustTarPixel = value;
                this.OnPropertyChanged(nameof(AdjustTarPixel));
            }
        }

        [field: NonSerialized]
        private ObservableCollection<XY> adjustObjPixels;
        [field: NonSerialized]
        private ObservableCollection<XY> adjustTarPixels;

        public ObservableCollection<XY> AdjustObjPixels
        {
            get { return adjustObjPixels; }
            set
            {
                if (adjustObjPixels == value) return;
                adjustObjPixels = value;
                this.OnPropertyChanged(nameof(AdjustObjPixels));
            }
        }
        public ObservableCollection<XY> AdjustTarPixels
        {
            get { return adjustTarPixels; }
            set
            {
                if (adjustTarPixels == value) return;
                adjustTarPixels = value;
                this.OnPropertyChanged(nameof(AdjustTarPixels));
            }
        }

        [field: NonSerialized]
        int setObjCount;
        private void SetAdjustObjPixel(XY px)
        {
            if (adjustObjPixels == null) adjustObjPixels = new ObservableCollection<XY>();

            SystemFunc.GetApp().Dispatcher.Invoke(new Action(delegate
            {
                // 리스트에 추가
                adjustObjPixels.Insert(0, px);

                // 최근 열개만 하자
                if (adjustObjPixels.Count > 10)
                    adjustObjPixels.Remove(adjustObjPixels.Last());

            }));

            // 평균값 계산
            XY sum = new XY();
            foreach (var xy in adjustObjPixels)
            {
                sum.X += xy.X;
                sum.Y += xy.Y;
            }

            AdjustObjPixel = sum / adjustObjPixels.Count;


            setObjCount++;
            // 매 10회마다 한번씩 저장한다.
            if (setObjCount > 10)
            {
                setObjCount = 0;
                this.SaveObject();
            }
            this.OnPropertyChanged(nameof(AdjustObjPixels));
        }

        [field: NonSerialized]
        int setTarCount;
        private void SetAdjustTarPixel(XY px)
        {
            if (adjustTarPixels == null) adjustTarPixels = new ObservableCollection<XY>();

            SystemFunc.GetApp().Dispatcher.Invoke(new Action(delegate
            {
                // 리스트에 추가
                adjustTarPixels.Insert(0, px);

                // 최근 열개만 하자
                if (adjustTarPixels.Count > 10)
                    adjustTarPixels.Remove(adjustTarPixels.Last());

            }));


            // 평균값 계산
            XY sum = new XY();
            foreach (var xy in adjustTarPixels)
            {
                sum.X += xy.X;
                sum.Y += xy.Y;
            }

            AdjustTarPixel = sum / adjustTarPixels.Count;


            setTarCount++;
            // 매 10회마다 한번씩 저장한다.
            if (setTarCount > 10)
            {
                setTarCount = 0;
                this.SaveObject();
            }

            this.OnPropertyChanged(nameof(AdjustTarPixels));
        }

        public void ClearAdJustPixel()
        {
            if (adjustObjPixels != null) adjustObjPixels.Clear();
            if (adjustTarPixels != null) adjustTarPixels.Clear();
            AdjustObjPixel = new XY();
            AdjustTarPixel = new XY();
            this.OnPropertyChanged(nameof(AdjustObjPixels));
            this.OnPropertyChanged(nameof(AdjustTarPixels));
        }
        private XY GetVirtualMarkPos(int idx, XY opposite, XY gap, XY adjust)
        {
            switch (idx)
            {
                case 0: // 1st-L
                    return opposite - gap - adjust;
                case 1: // 1st-R
                    return opposite + gap + adjust;
                case 2: // 2nd-L
                    return opposite + gap - adjust;
                case 3: // 2nd-R
                    return opposite - gap + adjust;
            }
            return new XY();
        }

        private bool CheckManualMark()
        {
            int ngObjMax = useObj3P ? 2 : 1;
            int ngTarMax = useTar3P ? 2 : 1;

            bool[] checkObjMark = new bool[4];
            int ngObjCnt = 0;
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { checkObjMark[i] = false; ngObjCnt++; }
                else checkObjMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngObjCnt >= ngObjMax)
            {
                // 여기들어오면....바꿔야함...이미지 누락된다잉
                System.Threading.Thread.Sleep(500);

                for (int i = 0; i < 4; i++)
                {
                    // NG가 난 툴을 메뉴얼로 바꿔놓는다....
                    if (!checkObjMark[i])
                    {
                        ObjectPos[i].Tool.ProcMode = ProcessMode.Manual;
                        ObjectPos[i].DisplayObj.Judgement = (uint)Judgement.OpCall;
                        (ObjectPos[i].Tool.ModObject as ToolObjectBase).DispayMessage("OpCall", System.Drawing.Color.Red);
                    }
                }

                errorCodeLami["Err_Mark_NG"] = false;
            }

            bool[] checkTarMark = new bool[4];
            int ngTarCnt = 0;
            for (int i = 0; i < TargetPos.Count(); i++)
            {
                if (TargetPos[i].SuccessIndex == -1) { checkTarMark[i] = false; ngTarCnt++; }
                else checkTarMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngTarCnt >= ngTarMax)
            {
                // 여기들어오면....바꿔야함...이미지 누락된다잉
                System.Threading.Thread.Sleep(500);

                for (int i = 0; i < 4; i++)
                {
                    // NG가 난 툴을 메뉴얼로 바꿔놓는다....
                    if (!checkTarMark[i])
                    {
                        TargetPos[i].Tool.ProcMode = ProcessMode.Manual;
                        TargetPos[i].DisplayObj.Judgement = (uint)Judgement.OpCall;
                        (TargetPos[i].Tool.ModObject as ToolObjectBase).DispayMessage("OpCall", System.Drawing.Color.Red);
                    }
                }

                errorCodeLami["Err_Mark_NG"] = false;
            }

            // 너무 일찍 나가니깐 저장된 이미지에 그려지지 않는다 비정상 케이스니 넣어두자
            if (!errorCodeLami["Err_Mark_NG"]) System.Threading.Thread.Sleep(100);

            // 위에서 한군대라도 들어가면 False 임.
            return errorCodeLami["Err_Mark_NG"];    
        }

        [field: NonSerialized]
        int ngPos = -1;
        private void Check3PAligObject()
        {

            bool[] checkMark = new bool[4];
            int ngCnt = 0;
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { checkMark[i] = false; ngCnt++; }
                else checkMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngCnt == 1)
            {
                XY virtualXY = new XY();
                ngPos = -1;
                // 1st두개 다 찾았을때
                if (checkMark[0] && checkMark[1])
                {
                    XY gap = new XY();
                    gap.X = ObjectPos[1].OutputXYT.X - ObjectPos[0].OutputXYT.X;
                    gap.Y = ObjectPos[1].OutputXYT.Y - ObjectPos[0].OutputXYT.Y;

                    if (!checkMark[2]) { ngPos = 2; virtualXY = GetVirtualMarkPos(2, ObjectPos[3].OutputXYT.ToXY(), gap, AdjustObjPixel); }
                    else if (!checkMark[3]) { ngPos = 3; virtualXY = GetVirtualMarkPos(3, ObjectPos[2].OutputXYT.ToXY(), gap, AdjustObjPixel); }
                }
                // 2nd 두개 다 찾았을때
                else
                {
                    XY gap = new XY();
                    gap.X = ObjectPos[2].OutputXYT.X - ObjectPos[3].OutputXYT.X;
                    gap.Y = ObjectPos[2].OutputXYT.Y - ObjectPos[3].OutputXYT.Y;

                    if (!checkMark[0]) { ngPos = 0; virtualXY = GetVirtualMarkPos(0, ObjectPos[1].OutputXYT.ToXY(), gap, AdjustObjPixel); }
                    else if (!checkMark[1]) { ngPos = 1; virtualXY = GetVirtualMarkPos(1, ObjectPos[0].OutputXYT.ToXY(), gap, AdjustObjPixel); }
                }

                // 값을 바꿔주므니다.
                ObjectPos[ngPos].OutputXYT.X = virtualXY.X;
                ObjectPos[ngPos].OutputXYT.Y = virtualXY.Y;

                if (ObjectPos[ngPos].Tool != null)
                    (ObjectPos[ngPos].Tool.ModObject as ToolObjectBase).CreatSkipResultGraphics(virtualXY);
            }
        }
        private void Check3PAligTarget()
        {
            bool[] checkMark = new bool[4];
            int ngCnt = 0;
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < TargetPos.Count(); i++)
            {
                if (TargetPos[i].SuccessIndex == -1) { checkMark[i] = false; ngCnt++; }
                else checkMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngCnt == 1)
            {
                XY virtualXY = new XY();
                ngPos = -1;
                // 1st두개 다 찾았을때
                if (checkMark[0] && checkMark[1])
                {
                    XY gap = new XY();
                    gap.X = TargetPos[1].OutputXYT.X - TargetPos[0].OutputXYT.X;
                    gap.Y = TargetPos[1].OutputXYT.Y - TargetPos[0].OutputXYT.Y;

                    if (!checkMark[2]) { ngPos = 2; virtualXY = GetVirtualMarkPos(2, TargetPos[3].OutputXYT.ToXY(), gap, AdjustTarPixel); }
                    else if (!checkMark[3]) { ngPos = 3; virtualXY = GetVirtualMarkPos(3, TargetPos[2].OutputXYT.ToXY(), gap, AdjustTarPixel); }
                }
                // 2nd 두개 다 찾았을때
                else
                {
                    XY gap = new XY();
                    gap.X = TargetPos[2].OutputXYT.X - TargetPos[3].OutputXYT.X;
                    gap.Y = TargetPos[2].OutputXYT.Y - TargetPos[3].OutputXYT.Y;

                    if (!checkMark[0]) { ngPos = 0; virtualXY = GetVirtualMarkPos(0, TargetPos[1].OutputXYT.ToXY(), gap, AdjustTarPixel); }
                    else if (!checkMark[1]) { ngPos = 1; virtualXY = GetVirtualMarkPos(1, TargetPos[0].OutputXYT.ToXY(), gap, AdjustTarPixel); }
                }

                // 값을 바꿔주므니다.
                TargetPos[ngPos].OutputXYT.X = virtualXY.X;
                TargetPos[ngPos].OutputXYT.Y = virtualXY.Y;

                if (TargetPos[ngPos].Tool != null)
                    (TargetPos[ngPos].Tool.ModObject as ToolObjectBase).CreatSkipResultGraphics(virtualXY);
            }
        }
        private bool CheckLCheckObjProcess()
        {
            /* 대칭으로 못찾은건 메뉴얼 마크 띄워야함. */
            if ((!DObjectLength_01_judge && !DObjectLength_23_judge) || (!DObjectLength_02_judge && !DObjectLength_13_judge)) { SetToolManualStatus(); return false; }
            /* 포인트가 겹치는 경우는 그 포인트를 가상으로 돌려서 재계산 */
            else if (!DObjectLength_01_judge && !DObjectLength_02_judge) { ObjectPos[0].SuccessIndex = -1; errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DObjectLength_01_judge && !DObjectLength_13_judge) { ObjectPos[1].SuccessIndex = -1; errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DObjectLength_23_judge && !DObjectLength_02_judge) { ObjectPos[2].SuccessIndex = -1; errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DObjectLength_23_judge && !DObjectLength_13_judge) { ObjectPos[3].SuccessIndex = -1; errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            /* 한라인이면 애매하므로 ConfirmRemovePoint함수에서 정해서 재계산*/
            else if (!DObjectLength_01_judge) { ConfirmRemoveObjPoint(0, 1); errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DObjectLength_02_judge) { ConfirmRemoveObjPoint(0, 2); errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DObjectLength_13_judge) { ConfirmRemoveObjPoint(1, 3); errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DObjectLength_23_judge) { ConfirmRemoveObjPoint(2, 3); errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcAlgoProcess(); }

            return true;
        }
        private bool CheckLCheckTarProcess()
        {
            /* 대칭으로 못찾은건 메뉴얼 마크 띄워야함. */
            if ((!DTargetLength_01_judge && !DTargetLength_23_judge) || (!DTargetLength_02_judge && !DTargetLength_13_judge)) { SetToolManualStatus(); return false; }
            /* 포인트가 겹치는 경우는 그 포인트를 가상으로 돌려서 재계산 */
            else if (!DTargetLength_01_judge && !DTargetLength_02_judge) { TargetPos[0].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DTargetLength_01_judge && !DTargetLength_13_judge) { TargetPos[1].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DTargetLength_02_judge && !DTargetLength_23_judge) { TargetPos[2].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DTargetLength_23_judge && !DTargetLength_13_judge) { TargetPos[3].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            /* 한라인이면 애매하므로 ConfirmRemovePoint함수에서 정해서 재계산*/
            else if (!DTargetLength_01_judge) { ConfirmRemoveTarPoint(0, 1); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DTargetLength_02_judge) { ConfirmRemoveTarPoint(0, 2); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DTargetLength_13_judge) { ConfirmRemoveTarPoint(1, 3); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcAlgoProcess(); }
            else if (!DTargetLength_23_judge) { ConfirmRemoveTarPoint(2, 3); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcAlgoProcess(); }

            return true;
        }
        public void SetToolManualStatus()
        {
            var Obj_1st_L = InputValues["Obj_1st_L"] as IPointResult;
            var Obj_1st_R = InputValues["Obj_1st_R"] as IPointResult;
            var Obj_2st_L = InputValues["Obj_2st_L"] as IPointResult;
            var Obj_2st_R = InputValues["Obj_2st_R"] as IPointResult;

            var Tar_1st_L = InputValues["Tar_1st_L"] as IPointResult;
            var Tar_1st_R = InputValues["Tar_1st_R"] as IPointResult;
            var Tar_2st_L = InputValues["Tar_2st_L"] as IPointResult;
            var Tar_2st_R = InputValues["Tar_2st_R"] as IPointResult;

            if (!(DObjectLength_01_judge && DObjectLength_02_judge && DObjectLength_23_judge && DObjectLength_13_judge &&
                DTargetLength_01_judge && DTargetLength_02_judge && DTargetLength_23_judge && DTargetLength_13_judge))
            {
                System.Threading.Thread.Sleep(500);

                Obj_1st_L.DisplayObj.Judgement = (uint)Judgement.None;
                Obj_1st_R.DisplayObj.Judgement = (uint)Judgement.None;
                Obj_2st_L.DisplayObj.Judgement = (uint)Judgement.None;
                Obj_2st_R.DisplayObj.Judgement = (uint)Judgement.None;

                Tar_1st_L.DisplayObj.Judgement = (uint)Judgement.None;
                Tar_1st_R.DisplayObj.Judgement = (uint)Judgement.None;
                Tar_2st_L.DisplayObj.Judgement = (uint)Judgement.None;
                Tar_2st_R.DisplayObj.Judgement = (uint)Judgement.None;
            }
            else if (DObjectLength_01_judge && DObjectLength_02_judge && DObjectLength_23_judge && DObjectLength_13_judge &&
              DTargetLength_01_judge && DTargetLength_02_judge && DTargetLength_23_judge && DTargetLength_13_judge)
            {
                // 다 성공이니깐 Return
                return;
            }

            // Object Length Judge에 대한 Display 처리
            if (!DObjectLength_01_judge)
            {
                Obj_1st_L.Tool.ProcMode = ProcessMode.Manual; (Obj_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Obj_1st_R.Tool.ProcMode = ProcessMode.Manual; (Obj_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Obj_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                Obj_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                errorCodeLami["Err_PNL_LENGTH_NG"] = false;
            }
            if (!DObjectLength_02_judge)
            {
                Obj_1st_L.Tool.ProcMode = ProcessMode.Manual; (Obj_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Obj_2st_L.Tool.ProcMode = ProcessMode.Manual; (Obj_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Obj_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                Obj_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                errorCodeLami["Err_PNL_LENGTH_NG"] = false;
            }

            if (!DObjectLength_23_judge)
            {
                Obj_2st_L.Tool.ProcMode = ProcessMode.Manual; (Obj_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Obj_2st_R.Tool.ProcMode = ProcessMode.Manual; (Obj_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Obj_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                Obj_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                errorCodeLami["Err_PNL_LENGTH_NG"] = false;
            }

            if (!DObjectLength_13_judge)
            {
                Obj_1st_R.Tool.ProcMode = ProcessMode.Manual; (Obj_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Obj_2st_R.Tool.ProcMode = ProcessMode.Manual; (Obj_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Obj_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                Obj_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                errorCodeLami["Err_PNL_LENGTH_NG"] = false;
            }

            // Target Length Judge에 대한 Display 처리
            if (!DTargetLength_01_judge)
            {
                Tar_1st_L.Tool.ProcMode = ProcessMode.Manual; (Tar_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Tar_1st_R.Tool.ProcMode = ProcessMode.Manual; (Tar_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Tar_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                Tar_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                errorCodeLami["Err_WND_LENGTH_NG"] = false;
            }
            if (!DTargetLength_02_judge)
            {
                Tar_1st_L.Tool.ProcMode = ProcessMode.Manual; (Tar_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Tar_2st_L.Tool.ProcMode = ProcessMode.Manual; (Tar_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Tar_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                Tar_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                errorCodeLami["Err_WND_LENGTH_NG"] = false;
            }

            if (!DTargetLength_23_judge)
            {
                Tar_2st_L.Tool.ProcMode = ProcessMode.Manual; (Tar_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Tar_2st_R.Tool.ProcMode = ProcessMode.Manual; (Tar_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Tar_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                Tar_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                errorCodeLami["Err_WND_LENGTH_NG"] = false;
            }

            if (!DTargetLength_13_judge)
            {
                Tar_1st_R.Tool.ProcMode = ProcessMode.Manual; (Tar_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Tar_2st_R.Tool.ProcMode = ProcessMode.Manual; (Tar_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                Tar_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                Tar_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                errorCodeLami["Err_WND_LENGTH_NG"] = false;
            }
        }
        private int GetVirtualObjIndex()
        {
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { return i; }
            }

            return -1;
        }
        private int GetVirtualTarIndex()
        {
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < TargetPos.Count(); i++)
            {
                if (TargetPos[i].SuccessIndex == -1) { return i; }
            }

            return -1;
        }
        private void ConfirmRemoveObjPoint(int a, int b)
        {
            /* 첫번째 마크면 첫번째꺼, 둘다 첫번째 마크면 인식율로, ㅇㅋ? */

            // 일단 작은놈이 승자
            if (ObjectPos[a].SuccessIndex < ObjectPos[b].SuccessIndex) ObjectPos[b].SuccessIndex = -1;
            else if (ObjectPos[a].SuccessIndex > ObjectPos[b].SuccessIndex) ObjectPos[a].SuccessIndex = -1;
            // 같으면 스코어 높은 놈이승자
            else
            {
                if (ObjectPos[a].Score > ObjectPos[b].Score) ObjectPos[b].SuccessIndex = -1;
                else ObjectPos[a].SuccessIndex = -1;
            }
        }
        private void ConfirmRemoveTarPoint(int a, int b)
        {
            /* 첫번째 마크면 첫번째꺼, 둘다 첫번째 마크면 인식율로, ㅇㅋ? */

            // 일단 작은놈이 승자
            if (TargetPos[a].SuccessIndex < TargetPos[b].SuccessIndex) TargetPos[b].SuccessIndex = -1;
            else if (TargetPos[a].SuccessIndex > TargetPos[b].SuccessIndex) TargetPos[a].SuccessIndex = -1;
            // 같으면 스코어 높은 놈이승자
            else
            {
                if (TargetPos[a].Score > TargetPos[b].Score) TargetPos[b].SuccessIndex = -1;
                else TargetPos[a].SuccessIndex = -1;
            }
        }
        #endregion

        #region [Private Method]
        bool AssignPLCData()
        {
            try
            {
                UpdatePLCIOs();
                cvtPLCIO = new LamiMain_PLCTable();

                cvtPLCIO.CurPosX1 = (double)PlcValues["CurrentPosX1"].CurValue;
                cvtPLCIO.CurPosX2 = (double)PlcValues["CurrentPosX2"].CurValue;
                cvtPLCIO.CurPosY1 = (double)PlcValues["CurrentPosY1"].CurValue;
                cvtPLCIO.CurPosY2 = (double)PlcValues["CurrentPosY2"].CurValue;

                cvtPLCIO.CamPos = (double)PlcValues["CameraPos"].CurValue;
                cvtPLCIO.CurCamX = (double)PlcValues["CurrentCamX"].CurValue;
                cvtPLCIO.CurCamY = (double)PlcValues["CurrentCamY"].CurValue;

                cvtPLCIO.TeachPosCamX = (double)PlcValues["TeachPosCamX"].CurValue;
                cvtPLCIO.TeachPosCamY_1st = (double)PlcValues["TeachPosCamY_1st"].CurValue;
                cvtPLCIO.TeachPosCamY_2nd = (double)PlcValues["TeachPosCamY_2nd"].CurValue;

                cvtPLCIO.OffsetX = (double)PlcValues["OffsetX"].CurValue;
                cvtPLCIO.OffsetY = (double)PlcValues["OffsetY"].CurValue;
                cvtPLCIO.OffsetT = (double)PlcValues["OffsetT"].CurValue;

                cvtPLCIO.CellID = (string)PlcValues["CellID"].CurValue;
                SourceID = cvtPLCIO.CellID;

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        void Initialize()
        {
            InputData = new Dictionary<string, IPointResult>();
            TargetPos = new IPointResult[4];
            ObjectPos = new IPointResult[4];
            RobotPos = new Dictionary<string, XY>();
            FixPos = new Dictionary<string, XY>();
            CoorPos = new Dictionary<string, XY>();
            LineTheta = new Dictionary<string, double>();
            Length = new Dictionary<string, double>();
            LengthOffset = new Dictionary<string, double>();
            Angle = new Dictionary<string, double>();

            calDataObj = new CalDataObject[4];
            calDataTar = new CalDataObject[4];
        }

        [field: NonSerialized]
        double limitX;
        [field: NonSerialized]
        double limitY;
        [field: NonSerialized]
        double limitT;

        private bool CalcAlgoProcess()
        {
            if (useObj3P) Check3PAligObject();
            if (useTar3P) Check3PAligTarget();

            #region 1> CalData Cofirm
            string model = SystemModel.GetCurModel();
            int calTarCnt = 0; int calObjCnt = 0;
            Struct.CalData calibData = new Struct.CalData();
            XY camMoving = new XY();

            XY[] tarCenterPos = new XY[4];
            XY[] objCenterPos = new XY[4];

            for (int i = 0; i < 4; i++)
            {
                calDataTar[i] = SystemObject_Common.GetObject(tar_CalData[i]) as CalDataObject;
                tarCenterPos[i] = calDataTar[i].GetRotateCenter(model);

                calDataObj[i] = SystemObject_Common.GetObject(obj_CalData[i]) as CalDataObject;
                objCenterPos[i] = calDataObj[i].GetRotateCenter(model);
            }
            #endregion

            #region 2> Model Data Preparing
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo4PTarObjModelParams;

            double ObjLengthLeftSpec = (double)mParams.ObjLengthLeft.Value;
            double ObjLengthRightSpec = (double)mParams.ObjLengthRight.Value;
            double ObjLengthLowerSpec = (double)mParams.ObjLengthLower.Value;
            double ObjLengthUpperSpec = (double)mParams.ObjLengthUpper.Value;
            double TarLengthLeftSpec = (double)mParams.TarLengthLeft.Value;
            double TarLengthRightSpec = (double)mParams.TarLengthRight.Value;
            double TarLengthLowerSpec = (double)mParams.TarLengthLower.Value;
            double TarLengthUpperSpec = (double)mParams.TarLengthUpper.Value;

            LengthOffset.Clear();
            LengthOffset.Add("Obj_Upper", (double)mParams.ObjLengthUpper_Offset.Value);
            LengthOffset.Add("Obj_Lower", (double)mParams.ObjLengthLower_Offset.Value);
            LengthOffset.Add("Obj_Left", (double)mParams.ObjLengthLeft_Offset.Value);
            LengthOffset.Add("Obj_Right", (double)mParams.ObjLengthRight_Offset.Value);
            LengthOffset.Add("Tar_Upper", (double)mParams.TarLengthUpper_Offset.Value);
            LengthOffset.Add("Tar_Lower", (double)mParams.TarLengthLower_Offset.Value);
            LengthOffset.Add("Tar_Left", (double)mParams.TarLengthLeft_Offset.Value);
            LengthOffset.Add("Tar_Right", (double)mParams.TarLengthRight_Offset.Value);

            if (mParams.ObjLengthTor == null)
                mParams.ObjLengthTor = new AlgoParam("ObjLengthTor", "mm", typeof(double), 0.0, "L_Check Obj_Tolerance Value", (double)0.0, (double)100.0);
            if (mParams.TarLengthTor == null)
                mParams.TarLengthTor = new AlgoParam("TarLengthTor", "mm", typeof(double), 0.0, "L_Check Tar_Tolerance Value", (double)0.0, (double)100.0);
            double ObjLengthTor = (double)mParams.ObjLengthTor.Value;
            double TarLengthTor = (double)mParams.TarLengthTor.Value;

            limitX = (double)mParams.LimitX.Value;
            limitY = (double)mParams.LimitY.Value;
            limitT = (double)mParams.LimitT.Value;

            double AngleCenter = (double)mParams.AngleCenter.Value;
            double AngleTor = (double)mParams.AngleTor.Value;
            #endregion

            #region 3> Robot, FixPos, CoorPos 계산
            InputData.Clear();
            InputData.Add("Obj_1st_L", ObjectPos[0]);
            InputData.Add("Obj_1st_R", ObjectPos[1]);
            InputData.Add("Obj_2st_L", ObjectPos[2]);
            InputData.Add("Obj_2st_R", ObjectPos[3]);

            InputData.Add("Tar_1st_L", TargetPos[0]);
            InputData.Add("Tar_1st_R", TargetPos[1]);
            InputData.Add("Tar_2st_L", TargetPos[2]);
            InputData.Add("Tar_2st_R", TargetPos[3]);

            Type type = typeof(Algo4PTarObjInputParams);
            FieldInfo[] fields = type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);

            RobotPos.Clear();
            FixPos.Clear();
            CoorPos.Clear();
            foreach (var field in fields)
            {
                string[] splitName = field.Name.Split(new string[] { "<", ">" }, StringSplitOptions.None);
                string fieldName = splitName[1];
                string[] tarOrobjArr = fieldName.Split(new string[] { "_" }, StringSplitOptions.None);
                string tarOrobj = tarOrobjArr[0];

                if (fieldName == "Trigger") continue;
                try
                {
                    switch (tarOrobj)
                    {
                        case "Tar":
                            if (calDataTar[calTarCnt] == null)
                            {
                                errorCodeLami["Err_obtain_CalData_Value"] = false;
                                return false;
                            }
                            // Robot Pos 계산
                            RobotPos.Add(fieldName, calDataTar[calTarCnt].GetV2R(model, new XY(InputData[fieldName].OutputXYT.X, InputData[fieldName].OutputXYT.Y)));

                            camMoving = new XY(0.0, 0.0);
                            // FixPosition Pos 계산
                            //FixPos.Add(fieldName, calDataTar[calTarCnt].GetRotateCenter(model) + camMoving);
                            FixPos.Add(fieldName, tarCenterPos[calTarCnt] + camMoving);
                            // Coordination Pos 계산
                            CoorPos.Add(fieldName, RobotPos[fieldName] + FixPos[fieldName]);

                            calTarCnt++;
                            break;

                        case "Obj":
                            if (calDataTar[calObjCnt] == null)
                            {
                                errorCodeLami["Err_obtain_CalData_Value"] = false;
                                return false;
                            }
                            // Robot Pos 계산
                            RobotPos.Add(fieldName, calDataObj[calObjCnt].GetV2R(model, new XY(InputData[fieldName].OutputXYT.X, InputData[fieldName].OutputXYT.Y)));

                            camMoving = new XY(0.0, 0.0);
                            // FixPosition Pos 계산
                            FixPos.Add(fieldName, objCenterPos[calObjCnt] + camMoving);
                            // Coordination Pos 계산
                            CoorPos.Add(fieldName, RobotPos[fieldName] + FixPos[fieldName]);

                            calObjCnt++;
                            break;
                    }
                }
                catch (Exception e)
                {
                    errorCodeLami["Err_obtain_CalData_Value"] = false;
                    return false;
                }
            }
            #endregion

            #region 4> Rev X, Y, T 계산
            // CalTheta
            CalLineTheta(CoorPos, ref LineTheta);
            CalRevT(thetaCalType, LineTheta, ref objRevPos, ref tarRevPos);
            CalRevXY(CoorPos, ref objRevPos, ref tarRevPos);
            #endregion

            #region 5> Calc Rev Offset
            var alignOffset = new XYT();
            if (ThetaDirection == ThetaDirection.Normal)    //정방향
            {
                alignOffset = new XYT(cvtPLCIO.OffsetX, cvtPLCIO.OffsetY, cvtPLCIO.OffsetT);
            }
            else //역방향
            {
                alignOffset = new XYT(cvtPLCIO.OffsetX, cvtPLCIO.OffsetY, -cvtPLCIO.OffsetT);
            }
            var tarxyt = new XYT(tarRevPos.X, tarRevPos.Y, tarRevPos.T);
            var objxyt = new XYT(objRevPos.X, objRevPos.Y, objRevPos.T);

            revAlign = new XYT();
            double radT, DriftX, DriftY;

            tarRevPos = ApplyTargetOffset(tarxyt, alignOffset);
            // FDC Upload
            radT = NormalizeTheta(tarRevPos.T - objxyt.T);

            // PI* rad = 180도, 1 rad = 180 / PI
            DriftX = Math.Cos(radT) * objxyt.X - Math.Sin(radT) * objxyt.Y;
            DriftY = Math.Sin(radT) * objxyt.X + Math.Cos(radT) * objxyt.Y;

            revAlign.X = tarRevPos.X - DriftX;
            revAlign.Y = tarRevPos.Y - DriftY;
            if (ThetaDirection == ThetaDirection.Normal)    //정방향
            {
                revAlign.T = radT / rad;
            }
            else //역방향
            {
                revAlign.T = (radT / rad) * -1;
            }

            //revAlign = new XYT(1, 2, -0.021);
            #endregion

            #region 6> Calc Length & Check

            MakeLength(CoorPos, ref Length);

            var bObjLength = new bool[4];
            var bTarLength = new bool[4];

            DObjectLength_01_judge = bObjLength[(int)eObjPos.Lower] = GetLCheck(Length["Obj_Lower"] + LengthOffset["Obj_Lower"],    ObjLengthLowerSpec, ObjLengthTor);
            DObjectLength_23_judge = bObjLength[(int)eObjPos.Upper] = GetLCheck(Length["Obj_Upper"] + LengthOffset["Obj_Upper"],    ObjLengthUpperSpec, ObjLengthTor);
            DObjectLength_02_judge = bObjLength[(int)eObjPos.Left]  = GetLCheck(Length["Obj_Left"]  + LengthOffset["Obj_Left"],     ObjLengthLeftSpec,  ObjLengthTor);
            DObjectLength_13_judge = bObjLength[(int)eObjPos.Right] = GetLCheck(Length["Obj_Right"] + LengthOffset["Obj_Right"],    ObjLengthRightSpec, ObjLengthTor);

            DTargetLength_01_judge = bTarLength[(int)eTarPos.Lower] = GetLCheck(Length["Tar_Lower"] + LengthOffset["Tar_Lower"],    TarLengthLowerSpec, TarLengthTor);
            DTargetLength_23_judge = bTarLength[(int)eTarPos.Upper] = GetLCheck(Length["Tar_Upper"] + LengthOffset["Tar_Upper"],    TarLengthUpperSpec, TarLengthTor);
            DTargetLength_02_judge = bTarLength[(int)eTarPos.Left]  = GetLCheck(Length["Tar_Left"]  + LengthOffset["Tar_Left"],     TarLengthLeftSpec,  TarLengthTor);
            DTargetLength_13_judge = bTarLength[(int)eTarPos.Right] = GetLCheck(Length["Tar_Right"] + LengthOffset["Tar_Right"],    TarLengthRightSpec, TarLengthTor);
            #endregion

            return true;
        }

        public IPointResult CreateValues(string key)
        {
            IPointResult result = null;

            if (!InputValues.ContainsKey(key))
            {
                return result;
            }

            if (InputValues[key] is MatchingRstData)
            {
                result = new MatchingRstData();
            }
            else if (InputValues[key] is LineCrossRstData)
            {
                result = new LineCrossRstData();
            }

            return result;
        }

        public IPointResult GetRstData(string key)
        {
            IPointResult Rst = null;

            if (!InputValues.ContainsKey(key)) return Rst;

            if (InputValues[key] is MatchingRstData)
                Rst = InputValues[key] as MatchingRstData;
            else if (InputValues[key] is LineCrossRstData)
                Rst = InputValues[key] as LineCrossRstData;
            return Rst;
        }

        protected bool PosConfirm(ref IPointResult[] TargetPos, ref IPointResult[] ObjectPos, ref Dictionary<string, bool> errorCode)
        {
            try
            {
                ObjectPos[0] = GetRstData("Obj_1st_L");
                ObjectPos[1] = GetRstData("Obj_1st_R");
                ObjectPos[2] = GetRstData("Obj_2st_L");
                ObjectPos[3] = GetRstData("Obj_2st_R");

                TargetPos[0] = GetRstData("Tar_1st_L");
                TargetPos[1] = GetRstData("Tar_1st_R");
                TargetPos[2] = GetRstData("Tar_2st_L");
                TargetPos[3] = GetRstData("Tar_2st_R");

                Angle.Clear();
                Angle.Add("Obj_1st_L", Math.Abs((ObjectPos[0].OutputXYT.T)));
                Angle.Add("Obj_1st_R", Math.Abs((ObjectPos[1].OutputXYT.T)));
                Angle.Add("Obj_2st_L", Math.Abs((ObjectPos[2].OutputXYT.T)));
                Angle.Add("Obj_2st_R", Math.Abs((ObjectPos[3].OutputXYT.T)));

                Angle.Add("Tar_1st_L", Math.Abs((TargetPos[0].OutputXYT.T)));
                Angle.Add("Tar_1st_R", Math.Abs((TargetPos[1].OutputXYT.T)));
                Angle.Add("Tar_2st_L", Math.Abs((TargetPos[2].OutputXYT.T)));
                Angle.Add("Tar_2st_R", Math.Abs((TargetPos[3].OutputXYT.T)));

                for (int cnt = 0; cnt < TargetPos.Length; cnt++)
                {
                    if (ObjectPos[cnt] == null || TargetPos[cnt] == null)
                    {
                        errorCodeLami["Err_obtain_VisionPos_Value"] = false;
                        return false;
                    }
                }

                return true;
            }
            catch (Exception e)
            {
                errorCodeLami["Err_obtain_VisionPos_Value"] = false;
                return false;
            }
        }

        [field: NonSerialized]
        bool useObj3P;
        [field: NonSerialized]
        bool useTar3P;
        [field: NonSerialized]
        OnOff usePNL3P;
        [field: NonSerialized]
        OnOff useWND3P;

        private bool AlignCalc()
        {
            #region 1> Initialize
            bool bResult = true;

            errorCode = 0;
            Initialize();
            #endregion

            #region 2> PLC IOs Update
            if (!AssignPLCData())
            {
                errorCode = AlgoActionBase.Err_Failed_PLC_Area_Update;
                return false;
            }
            #endregion

            #region 3> Algorithm Error Define
            // AlgoError 초기화
            errorCodeLami = new Dictionary<string, bool>();
            InitDefinedError(ref errorCodeLami);
            #endregion

            #region 4> Obj/Tar Vision Position Data 유,무 확인

            for (int temp = 0; temp < 4; temp++)
            {
                TargetPos[temp] = CreateValues("Tar_1st_L");
                ObjectPos[temp] = CreateValues("Obj_1st_L");

                if (TargetPos[temp] == null || ObjectPos[temp] == null)
                {
                    errorCodeLami["Err_obtain_VisionPos_Value"] = false;
                    return false;
                }
            }

            if (!PosConfirm(ref TargetPos, ref ObjectPos, ref errorCodeLami)) return false;

            #endregion

            #region 3Point 관련 추가.... kds
            // 옵션 가지고 오기
            var algoOption = Options as Algo4PTarObjModelOptions;
            usePNL3P = (OnOff)algoOption.UsePanel3PointAlign.Value;
            useWND3P = (OnOff)algoOption.UseWindow3PointAlign.Value;
            useObj3P = usePNL3P == OnOff.On ? true : false;
            useTar3P = useWND3P == OnOff.On ? true : false;

            // 메뉴얼 마크 찍고 한번 돌고 오면 SuccessIndex == 0 이 되어서 온담..
            // Mark NG일때 False

            if (!CheckManualMark()) return false;

            // 연산하는코드가 다 들어가있다....3P도 첫줄에 넣어놓음.
            // 입력데이터에 이상이 있는 경우 False
            if (!CalcAlgoProcess()) return false;

            bool objRst = useObj3P ? CheckLCheckObjProcess() : true;
            bool tarRst = useTar3P ? CheckLCheckTarProcess() : true;

            // 3-Point Align이 불가능한 Mark NG일때 False
            if (!objRst || !tarRst) return false;

            // 마지막으로 L-Check 함 더 한다.(이거 왜 했더라???기어기가 안난다...오늘한건데..)
            SetToolManualStatus();
            #endregion

            #region Virtual Point
            string strRst = string.Empty;
            int idxObj = GetVirtualObjIndex();
            int idxTar = GetVirtualTarIndex();

            if (idxObj == -1 && idxTar == -1)
            {
                strRst = "4P";
            }
            else if (idxObj == -1)
            {
                if (AdjustTarPixel.X == 0 && AdjustTarPixel.Y == 0)
                    errorCodeLami["AdjustValueNotEnough"] = false;
                else
                    errorCodeLami["3PAlign"] = false;
                strRst = string.Format("3P({0}{1} Skip)", "Target", idxTar);
            }
            else if (idxTar == -1)
            {
                if (AdjustObjPixel.X == 0 && AdjustObjPixel.Y == 0)
                    errorCodeLami["AdjustValueNotEnough"] = false;
                else
                    errorCodeLami["3PAlign"] = false;

                strRst = string.Format("3P({0}{1} Skip)", "Object", idxObj);
            }
            else
            {
                if ((AdjustTarPixel.X == 0 && AdjustTarPixel.Y == 0) || (AdjustObjPixel.X == 0 && AdjustObjPixel.Y == 0))
                    errorCodeLami["AdjustValueNotEnough"] = false;
                else
                    errorCodeLami["3PAlign"] = false;

                strRst = string.Format("3P({0}{1},{2}{3} Skip)", "Target", idxTar, "Object", idxObj);
            }
            #endregion

            AlgoRst = new Algo4PTarObjResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Result = strRst,

                RevX = Math.Round(revAlign.X, 3),
                RevY = Math.Round(revAlign.Y, 3),
                RevT = Math.Round(revAlign.T, 3),

                OffsetX = Math.Round(cvtPLCIO.OffsetX, 3),
                OffsetY = Math.Round(cvtPLCIO.OffsetY, 3),
                OffsetT = Math.Round(cvtPLCIO.OffsetT, 3),

                Tar_revX = Math.Round(tarRevPos.X, 3),
                Tar_revY = Math.Round(tarRevPos.Y, 3),
                Tar_revT = Math.Round(tarRevPos.T / rad, 3),

                Obj_revX = Math.Round(objRevPos.X, 3),
                Obj_revY = Math.Round(objRevPos.Y, 3),
                Obj_revT = Math.Round(objRevPos.T / rad, 3),

                ObjLength_Left = Math.Round(Length["Obj_Left"] + LengthOffset["Obj_Left"], 3),
                ObjLength_Right = Math.Round(Length["Obj_Right"] + LengthOffset["Obj_Right"], 3),
                ObjLength_Upper = Math.Round(Length["Obj_Upper"] + LengthOffset["Obj_Upper"], 3),
                ObjLength_Lower = Math.Round(Length["Obj_Lower"] + LengthOffset["Obj_Lower"], 3),

                TarLength_Left = Math.Round(Length["Tar_Left"] + LengthOffset["Tar_Left"], 3),
                TarLength_Right = Math.Round(Length["Tar_Right"] + LengthOffset["Tar_Right"], 3),
                TarLength_Upper = Math.Round(Length["Tar_Upper"] + LengthOffset["Tar_Upper"], 3),
                TarLength_Lower = Math.Round(Length["Tar_Lower"] + LengthOffset["Tar_Lower"], 3),

                ObjTh_Lower = Math.Round(LineTheta["Obj_Lower"], 3),
                ObjTh_Upper = Math.Round(LineTheta["Obj_Upper"], 3),
                ObjTh_Left = Math.Round(LineTheta["Obj_Left"], 3),
                ObjTh_Right = Math.Round(LineTheta["Obj_Right"], 3),

                TarTh_Lower = Math.Round(LineTheta["Tar_Lower"], 3),
                TarTh_Upper = Math.Round(LineTheta["Tar_Upper"], 3),
                TarTh_Left = Math.Round(LineTheta["Tar_Left"], 3),
                TarTh_Right = Math.Round(LineTheta["Tar_Right"], 3),

                ObjAngle_1st_L = Math.Round(Angle["Obj_1st_L"], 3),
                ObjAngle_1st_R = Math.Round(Angle["Obj_1st_R"], 3),
                ObjAngle_2st_L = Math.Round(Angle["Obj_2st_L"], 3),
                ObjAngle_2st_R = Math.Round(Angle["Obj_2st_R"], 3),

                TarAngle_1st_L = Math.Round(Angle["Tar_1st_L"], 3),
                TarAngle_1st_R = Math.Round(Angle["Tar_1st_R"], 3),
                TarAngle_2st_L = Math.Round(Angle["Tar_2st_L"], 3),
                TarAngle_2st_R = Math.Round(Angle["Tar_2st_R"], 3),
            };

            #region L-Check
            if (errorCodeLami["Err_PNL_LENGTH_NG"] == false || errorCodeLami["Err_WND_LENGTH_NG"] == false) return false;
            #endregion

            #region 8> Confirm Result
            // limit check
            var limit = new XYT(limitX, limitY, limitT);
            if (!ConfirmResult(revAlign, limit))
            {
                SetLimtJudgeStatus();
                return false;
            }
            #endregion

            // 4P Align을 했으면 추가 보정량을 계산해서 넣어둔다. jyh
            if (GetVirtualObjIndex() == -1)
            {
                XY xy1st = new XY();
                XY xy2nd = new XY();
                xy1st.X = ObjectPos[0].OutputXYT.X - ObjectPos[1].OutputXYT.X;
                xy1st.Y = ObjectPos[0].OutputXYT.Y - ObjectPos[1].OutputXYT.Y;
                xy2nd.X = ObjectPos[3].OutputXYT.X - ObjectPos[2].OutputXYT.X;
                xy2nd.Y = ObjectPos[3].OutputXYT.Y - ObjectPos[2].OutputXYT.Y;
                SetAdjustObjPixel(xy2nd - xy1st);
            }
            if (GetVirtualTarIndex() == -1)
            {
                XY xy1st = new XY();
                XY xy2nd = new XY();
                xy1st.X = TargetPos[0].OutputXYT.X - TargetPos[1].OutputXYT.X;
                xy1st.Y = TargetPos[0].OutputXYT.Y - TargetPos[1].OutputXYT.Y;
                xy2nd.X = TargetPos[3].OutputXYT.X - TargetPos[2].OutputXYT.X;
                xy2nd.Y = TargetPos[3].OutputXYT.Y - TargetPos[2].OutputXYT.Y;
                SetAdjustTarPixel(xy2nd - xy1st);
            }

            return true;
        }

        public void SetLimtJudgeStatus()
        {
            var Obj_1st_L = InputData["Obj_1st_L"] as IPointResult;
            var Obj_1st_R = InputData["Obj_1st_R"] as IPointResult;
            var Obj_2st_L = InputData["Obj_2st_L"] as IPointResult;
            var Obj_2st_R = InputData["Obj_2st_R"] as IPointResult;

            var Tar_1st_L = InputData["Tar_1st_L"] as IPointResult;
            var Tar_1st_R = InputData["Tar_1st_R"] as IPointResult;
            var Tar_2st_L = InputData["Tar_2st_L"] as IPointResult;
            var Tar_2st_R = InputData["Tar_2st_R"] as IPointResult;

            System.Threading.Thread.Sleep(500);

            Obj_1st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            Obj_1st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            Obj_2st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            Obj_2st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;

            Tar_1st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            Tar_1st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            Tar_2st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            Tar_2st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
        }        

        protected bool GetAngleCheck(double Angle, double AngleCenter, double AngleTor)
        {
            if (Angle > (AngleCenter + AngleTor) || Angle < (AngleCenter - AngleTor))
            {
                errorCode = AlgoActionBase.Err_Angle_Tolerance_Exceeded;
                return false;
            }
            return true;
        }

        void MakeLength(Dictionary<string, XY> Pos, ref Dictionary<string, double> Length) 
        {
            Length.Clear();
            Length.Add("Tar_Lower", GetLength(CoorPos["Tar_1st_L"], CoorPos["Tar_1st_R"]));// + LengthOffset["TarLower"]) ;
            Length.Add("Tar_Upper", GetLength(CoorPos["Tar_2st_L"], CoorPos["Tar_2st_R"]));// + LengthOffset["TarUpper"]);
            Length.Add("Tar_Left",  GetLength(CoorPos["Tar_1st_L"], CoorPos["Tar_2st_L"]));// + LengthOffset["TarLeft"]);
            Length.Add("Tar_Right", GetLength(CoorPos["Tar_1st_R"], CoorPos["Tar_2st_R"]));// + LengthOffset["TarRight"]);

            Length.Add("Obj_Lower", GetLength(CoorPos["Obj_1st_L"], CoorPos["Obj_1st_R"]));// + LengthOffset["ObjLower"]);
            Length.Add("Obj_Upper", GetLength(CoorPos["Obj_2st_L"], CoorPos["Obj_2st_R"]));// + LengthOffset["ObjUpper"]);
            Length.Add("Obj_Left" , GetLength(CoorPos["Obj_1st_L"], CoorPos["Obj_2st_L"]));// + LengthOffset["ObjLeft"]);
            Length.Add("Obj_Right", GetLength(CoorPos["Obj_1st_R"], CoorPos["Obj_2st_R"]));// + LengthOffset["ObjRight"]);
        }

        void CalLineTheta(Dictionary<string, XY> Pos, ref Dictionary<string, double> LineTheta)
        {
            LineTheta.Clear();
            LineTheta.Add("Tar_Lower", GetThetaColumn(Pos["Tar_1st_L"].X, Pos["Tar_1st_R"].X, Pos["Tar_1st_L"].Y, Pos["Tar_1st_R"].Y));
            LineTheta.Add("Tar_Upper", GetThetaColumn(Pos["Tar_2st_L"].X, Pos["Tar_2st_R"].X, Pos["Tar_2st_L"].Y, Pos["Tar_2st_R"].Y)); 
            LineTheta.Add("Tar_Left" , GetThetaColumn(Pos["Tar_1st_L"].X, Pos["Tar_2st_L"].X, Pos["Tar_1st_L"].Y, Pos["Tar_2st_L"].Y));
            LineTheta.Add("Tar_Right", GetThetaColumn(Pos["Tar_1st_R"].X, Pos["Tar_2st_R"].X, Pos["Tar_1st_R"].Y, Pos["Tar_2st_R"].Y));
            LineTheta.Add("Obj_Lower", GetThetaColumn(Pos["Obj_1st_L"].X, Pos["Obj_1st_R"].X, Pos["Obj_1st_L"].Y, Pos["Obj_1st_R"].Y));
            LineTheta.Add("Obj_Upper", GetThetaColumn(Pos["Obj_2st_L"].X, Pos["Obj_2st_R"].X, Pos["Obj_2st_L"].Y, Pos["Obj_2st_R"].Y));
            LineTheta.Add("Obj_Left" , GetThetaColumn(Pos["Obj_1st_L"].X, Pos["Obj_2st_L"].X, Pos["Obj_1st_L"].Y, Pos["Obj_2st_L"].Y));
            LineTheta.Add("Obj_Right", GetThetaColumn(Pos["Obj_1st_R"].X, Pos["Obj_2st_R"].X, Pos["Obj_1st_R"].Y, Pos["Obj_2st_R"].Y));            
        }        

        public void CalRevT(ThetaCalType TCalType, Dictionary<string, double> LineTheta, ref XYT objRevPos, ref XYT tarRevPos)
        {
            objRevPos = new XYT();
            tarRevPos = new XYT();
            switch (TCalType)
            {
                case ThetaCalType.UseShort_2L:
                    objRevPos.T = (LineTheta["Obj_Lower"] + LineTheta["Obj_Upper"]) / 2;
                    tarRevPos.T = (LineTheta["Tar_Lower"] + LineTheta["Tar_Upper"]) / 2;
                    break;

                case ThetaCalType.UseLong_2L:
                    objRevPos.T = (LineTheta["Obj_Left"] + LineTheta["Obj_Right"]) / 2;
                    tarRevPos.T = (LineTheta["Tar_Left"] + LineTheta["Tar_Right"]) / 2;
                    break;

                case ThetaCalType.Use_4L:
                   foreach (var theta in LineTheta.Keys)
                    {
                        string[] splitKey = theta .Split(new string[] { "_" }, StringSplitOptions.None);
                        string tarOrobj = splitKey[0];

                        switch (tarOrobj)
                        {
                            case "Tar":
                                tarRevPos.T += LineTheta[theta];
                                break;

                            case "Obj":
                                objRevPos.T += LineTheta[theta];
                                break;
                        }
                    }
                    tarRevPos.T /= 4;
                    objRevPos.T /= 4;
                    break;
            }
        }

        public void CalRevXY(Dictionary<string, XY> Pos, ref XYT objRevPos, ref XYT tarRevPos)
        {
            XY sumTar = new XY(0,0);
            XY sumObj = new XY(0,0);

            foreach(var key in Pos.Keys)
            {
                string[] splitKey = key.Split(new string[] { "_" }, StringSplitOptions.None);
                string tarOrobj = splitKey[0];

                switch(tarOrobj)
                {
                    case "Tar":
                        sumTar += Pos[key];
                        break;
                    case "Obj":
                        sumObj += Pos[key];
                        break;
                }
            }

            objRevPos.X = sumObj.X / 4; objRevPos.Y = sumObj.Y / 4;
            tarRevPos.X = sumTar.X / 4; tarRevPos.Y = sumTar.Y / 4;
        }

        #region Public Method
        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (limit.X == 0.0 || limit.Y == 0.0 || limit.T == 0.0) return true;

            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCodeLami["Err_Limit_Over"] = false;
                return false;
            }
            else
                return true;
        }

        public void WriteVisionIO(object rev1, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["TargetPosX1"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["TargetPosX1"]);
                    VisionValues["TargetPosX2"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["TargetPosX2"]);
                    VisionValues["TargetPosY1"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["TargetPosY1"]);
                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:

                    VisionValues["TargetPosX1"].NextValue = (double)(rev1 as XXYY).X1; IOs.Add(VisionValues["TargetPosX1"]);
                    VisionValues["TargetPosX2"].NextValue = (double)(rev1 as XXYY).X2; IOs.Add(VisionValues["TargetPosX2"]);
                    VisionValues["TargetPosY1"].NextValue = (double)(rev1 as XXYY).Y1; IOs.Add(VisionValues["TargetPosY1"]);
                    VisionValues["TargetPosY2"].NextValue = (double)(rev1 as XXYY).Y2; IOs.Add(VisionValues["TargetPosY2"]);
                    break;
            }

            // write fdc data : 2019.10.19, khoon, system qual 대응
            // rev xyt
            var result = AlgoRst as Algo4PTarObjResult;
            if (result != null)
            {
                VisionValues["FinalTargetX"].NextValue = result.RevX; IOs.Add(VisionValues["FinalTargetX"]);
                VisionValues["FinalTargetY"].NextValue = result.RevY; IOs.Add(VisionValues["FinalTargetY"]);
                VisionValues["FinalTargetT"].NextValue = result.RevT; IOs.Add(VisionValues["FinalTargetT"]);

                VisionValues["TargetPosX"].NextValue = result.Tar_revX; IOs.Add(VisionValues["TargetPosX"]);
                VisionValues["TargetPosY"].NextValue = result.Tar_revY; IOs.Add(VisionValues["TargetPosY"]);
                VisionValues["TargetPosT"].NextValue = result.Tar_revT; IOs.Add(VisionValues["TargetPosT"]);

                VisionValues["ResultRevX"].NextValue = result.Obj_revX; IOs.Add(VisionValues["ResultRevX"]);
                VisionValues["ResultRevY"].NextValue = result.Obj_revY; IOs.Add(VisionValues["ResultRevY"]);
                VisionValues["ResultRevT"].NextValue = result.Obj_revT; IOs.Add(VisionValues["ResultRevT"]);
            }
            // score

            if (InputData != null && InputData.Count != 0)
            {
                VisionValues["Score_P1_Upper"].NextValue = InputData["Tar_1st_L"].Score; IOs.Add(VisionValues["Score_P1_Upper"]);
                VisionValues["Score_P2_Upper"].NextValue = InputData["Tar_2st_L"].Score; IOs.Add(VisionValues["Score_P2_Upper"]);
                VisionValues["Score_P3_Upper"].NextValue = InputData["Tar_2st_R"].Score; IOs.Add(VisionValues["Score_P3_Upper"]);
                VisionValues["Score_P4_Upper"].NextValue = InputData["Tar_1st_R"].Score; IOs.Add(VisionValues["Score_P4_Upper"]);
                VisionValues["Score_P1_Lower"].NextValue = InputData["Obj_1st_L"].Score; IOs.Add(VisionValues["Score_P1_Lower"]);
                VisionValues["Score_P2_Lower"].NextValue = InputData["Obj_2st_L"].Score; IOs.Add(VisionValues["Score_P2_Lower"]);
                VisionValues["Score_P3_Lower"].NextValue = InputData["Obj_2st_R"].Score; IOs.Add(VisionValues["Score_P3_Lower"]);
                VisionValues["Score_P4_Lower"].NextValue = InputData["Obj_1st_R"].Score; IOs.Add(VisionValues["Score_P4_Lower"]);
            }

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);
            CommodObject.SetVisionValues(IOs);
        }

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (cogDisp == null) return;
            Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }

        public void ImageSave(DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (InputData == null || InputData.Count == 0) return;
            foreach (var item in InputData)
            {
                if (item.Value != null && item.Value.DisplayObj != null)
                {
                    ImageSave(item.Value.DisplayObj as CogDisplayObject, dateTime, rst, strPath);
                }
            }
        }

        #endregion  
    }
    #endregion
}