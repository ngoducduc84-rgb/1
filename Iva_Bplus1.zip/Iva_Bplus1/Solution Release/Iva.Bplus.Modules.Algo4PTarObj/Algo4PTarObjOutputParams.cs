﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo4PTarObj
{
    class Algo4PTarObjOutputParams : OutputParams
    {
        #region Convert
        public XYT ConvertXYT { get; set; }
        #endregion

        #region Logging
        public object Result { get; set; }
        #endregion
    }
}
