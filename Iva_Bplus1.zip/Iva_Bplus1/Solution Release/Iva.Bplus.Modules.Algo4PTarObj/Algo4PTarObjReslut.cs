﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4PTarObj
{
    [SerializableAttribute]
    public class Algo4PTarObjResult : AlgoResultBase
    {
        #region [fiedls]    
        private string result;

        private double revX;
        private double revY;
        private double revT;

        private double tar_revX;
        private double tar_revY;
        private double tar_revT;

        private double obj_revX;
        private double obj_revY;
        private double obj_revT;

        // Lenth
        private double objLength_Left;
        private double objLength_Right;
        private double objLength_Upper;
        private double objLength_Lower;

        private double tarLength_Left;
        private double tarLength_Right;
        private double tarLength_Upper;
        private double tarLength_Lower;

        // Line Theta
        private double objTh_Lower;
        private double objTh_Upper;
        private double objTh_Left;
        private double objTh_Right;

        private double tarTh_Lower;
        private double tarTh_Upper;
        private double tarTh_Left;
        private double tarTh_Right;

        // Line Cross Angle 
        private double tarAngle_1st_L;
        private double tarAngle_1st_R;
        private double tarAngle_2st_L;
        private double tarAngle_2st_R;

        private double objAngle_1st_L;
        private double objAngle_1st_R;
        private double objAngle_2st_L;
        private double objAngle_2st_R;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        //private bool islcheckJudgement;
        #endregion

        #region [Properties]
        #region 기본 property
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        #endregion

        #region Judge Result
        public string Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        //public bool IslcheckJudgement
        //{
        //    get { return islcheckJudgement; }
        //    set { if (value == islcheckJudgement) return; islcheckJudgement = value; OnPropertyChanged(nameof(IslcheckJudgement)); }
        //}
        #endregion

        #region 최종 결과 값
        public double RevX
        {
            get { return revX; }
            set
            {
                if (value == revX) return;
                revX = value;
                this.OnPropertyChanged(nameof(RevX));
            }
        }

        public double RevY
        {
            get { return revY; }
            set
            {
                if (value == revY) return;
                revY = value;
                this.OnPropertyChanged(nameof(RevY));
            }
        }

        public double RevT
        {
            get { return revT; }
            set
            {
                if (value == revT) return;
                revT = value;
                this.OnPropertyChanged(nameof(RevT));
            }
        }

        public double Tar_revX
        {
            get { return tar_revX; }
            set
            {
                if (value == tar_revX) return;
                tar_revX = value;
                this.OnPropertyChanged(nameof(Tar_revX));
            }
        }

        public double Tar_revY
        {
            get { return tar_revY; }
            set
            {
                if (value == tar_revY) return;
                tar_revY = value;
                this.OnPropertyChanged(nameof(Tar_revY));
            }
        }

        public double Tar_revT
        {
            get { return tar_revT; }
            set
            {
                if (value == tar_revT) return;
                tar_revT = value;
                this.OnPropertyChanged(nameof(Tar_revT));
            }
        }

        public double Obj_revX
        {
            get { return obj_revX; }
            set
            {
                if (value == obj_revX) return;
                obj_revX = value;
                this.OnPropertyChanged(nameof(Obj_revX));
            }
        }

        public double Obj_revY
        {
            get { return obj_revY; }
            set
            {
                if (value == obj_revY) return;
                obj_revY = value;
                this.OnPropertyChanged(nameof(Obj_revY));
            }
        }

        public double Obj_revT
        {
            get { return obj_revT; }
            set
            {
                if (value == obj_revT) return;
                obj_revT = value;
                this.OnPropertyChanged(nameof(Obj_revT));
            }
        }
        #endregion

        #region offset Info
        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                if (value == offsetX) return;
                offsetX = value;

                OnPropertyChanged("OffsetX");
            }
        }

        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                if (value == offsetY) return;
                offsetY = value;

                OnPropertyChanged("OffsetY");
            }
        }

        public double OffsetT
        {
            get { return offsetT; }
            set
            {
                if (value == offsetT) return;
                offsetT = value;

                OnPropertyChanged("OffsetT");
            }
        }
        #endregion

        #region Length Info
        public double ObjLength_Left
        {
            get { return objLength_Left; }
            set
            {
                if (value == objLength_Left) return;
                objLength_Left = value;
                this.OnPropertyChanged(nameof(ObjLength_Left));
            }
        }
        public double ObjLength_Right
        {
            get { return objLength_Right; }
            set
            {
                if (value == objLength_Right) return;
                objLength_Right = value;
                this.OnPropertyChanged(nameof(ObjLength_Right));
            }
        }

        public double ObjLength_Upper
        {
            get { return objLength_Upper; }
            set
            {
                if (value == objLength_Upper) return;
                objLength_Upper = value;
                this.OnPropertyChanged(nameof(ObjLength_Upper));
            }
        }

        public double ObjLength_Lower
        {
            get { return objLength_Lower; }
            set
            {
                if (value == objLength_Lower) return;
                objLength_Lower = value;
                this.OnPropertyChanged(nameof(ObjLength_Lower));
            }
        }
        public double TarLength_Left
        {
            get { return tarLength_Left; }
            set
            {
                if (value == tarLength_Left) return;
                tarLength_Left = value;
                this.OnPropertyChanged(nameof(TarLength_Left));
            }
        }
        public double TarLength_Right
        {
            get { return tarLength_Right; }
            set
            {
                if (value == tarLength_Right) return;
                tarLength_Right = value;
                this.OnPropertyChanged(nameof(TarLength_Right));
            }
        }

        public double TarLength_Upper
        {
            get { return tarLength_Upper; }
            set
            {
                if (value == tarLength_Upper) return;
                tarLength_Upper = value;
                this.OnPropertyChanged(nameof(TarLength_Upper));
            }
        }

        public double TarLength_Lower
        {
            get { return tarLength_Lower; }
            set
            {
                if (value == tarLength_Lower) return;
                tarLength_Lower = value;
                this.OnPropertyChanged(nameof(TarLength_Lower));
            }
        }

        #endregion

        #region 각 성분의 Theta값
        // obj의 점간 theta성분
        public double ObjTh_Lower
        {
            get { return objTh_Lower; }
            set
            {
                if (value == objTh_Lower) return;
                objTh_Lower = value;
                this.OnPropertyChanged(nameof(ObjTh_Lower));
            }
        }

        public double ObjTh_Upper
        {
            get { return objTh_Upper; }
            set
            {
                if (value == objTh_Upper) return;
                objTh_Upper = value;
                this.OnPropertyChanged(nameof(ObjTh_Upper));
            }
        }

        public double ObjTh_Left
        {
            get { return objTh_Left; }
            set
            {
                if (value == objTh_Left) return;
                objTh_Left = value;
                this.OnPropertyChanged(nameof(ObjTh_Left));
            }
        }

        public double ObjTh_Right
        {
            get { return objTh_Right; }
            set
            {
                if (value == objTh_Right) return;
                objTh_Right = value;
                this.OnPropertyChanged(nameof(ObjTh_Right));
            }
        }


        // tar의 점간 theta성분
        public double TarTh_Lower
        {
            get { return tarTh_Lower; }
            set
            {
                if (value == tarTh_Lower) return;
                tarTh_Lower = value;
                this.OnPropertyChanged(nameof(TarTh_Lower));
            }
        }

        public double TarTh_Upper
        {
            get { return tarTh_Upper; }
            set
            {
                if (value == tarTh_Upper) return;
                tarTh_Upper = value;
                this.OnPropertyChanged(nameof(TarTh_Upper));
            }
        }

        public double TarTh_Left
        {
            get { return tarTh_Left; }
            set
            {
                if (value == tarTh_Left) return;
                tarTh_Left = value;
                this.OnPropertyChanged(nameof(TarTh_Left));
            }
        }

        public double TarTh_Right
        {
            get { return tarTh_Right; }
            set
            {
                if (value == tarTh_Right) return;
                tarTh_Right = value;
                this.OnPropertyChanged(nameof(TarTh_Right));
            }
        }
        #endregion

        #region 각 Line Cross의 Angle
        public double TarAngle_1st_L
        {
            get { return tarAngle_1st_L; }
            set { if (value == tarAngle_1st_L) return; tarAngle_1st_L = value; this.OnPropertyChanged(nameof(TarAngle_1st_L)); }
        }
        public double TarAngle_1st_R
        {
            get { return tarAngle_1st_R; }
            set { if (value == tarAngle_1st_R) return; tarAngle_1st_R = value; this.OnPropertyChanged(nameof(TarAngle_1st_R)); }
        }
        public double TarAngle_2st_L
        {
            get { return tarAngle_2st_L; }
            set { if (value == tarAngle_2st_L) return; tarAngle_2st_L = value; this.OnPropertyChanged(nameof(TarAngle_2st_L)); }
        }
        public double TarAngle_2st_R
        {
            get { return tarAngle_2st_R; }
            set { if (value == tarAngle_2st_R) return; tarAngle_2st_R = value; this.OnPropertyChanged(nameof(TarAngle_2st_R)); }
        }

        public double ObjAngle_1st_L
        {
            get { return objAngle_1st_L; }
            set { if (value == objAngle_1st_L) return; objAngle_1st_L = value; this.OnPropertyChanged(nameof(ObjAngle_1st_L)); }
        }
        public double ObjAngle_1st_R
        {
            get { return objAngle_1st_R; }
            set { if (value == objAngle_1st_R) return; objAngle_1st_R = value; this.OnPropertyChanged(nameof(ObjAngle_1st_R)); }
        }
        public double ObjAngle_2st_L
        {
            get { return objAngle_2st_L; }
            set { if (value == objAngle_2st_L) return; objAngle_2st_L = value; this.OnPropertyChanged(nameof(ObjAngle_2st_L)); }
        }
        public double ObjAngle_2st_R
        {
            get { return objAngle_2st_R; }
            set { if (value == objAngle_2st_R) return; objAngle_2st_R = value; this.OnPropertyChanged(nameof(ObjAngle_2st_R)); }
        }

        //public double Tar_1st_rt_Lx
        //{
        //    get { return dTar_1st_rt_Lx; }
        //    set { if (value == dTar_1st_rt_Lx) return; dTar_1st_rt_Lx = value; this.OnPropertyChanged(nameof(Tar_1st_rt_Lx)); }
        //}
        //public double Tar_1st_rt_Ly
        //{
        //    get { return dTar_1st_rt_Ly; }
        //    set { if (value == dTar_1st_rt_Ly) return; dTar_1st_rt_Ly = value; this.OnPropertyChanged(nameof(Tar_1st_rt_Ly)); }
        //}
        //public double Tar_1st_rt_Rx
        //{
        //    get { return dTar_1st_rt_Rx; }
        //    set { if (value == dTar_1st_rt_Rx) return; dTar_1st_rt_Rx = value; this.OnPropertyChanged(nameof(Tar_1st_rt_Rx)); }
        //}
        //public double Tar_1st_rt_Ry
        //{
        //    get { return dTar_1st_rt_Ry; }
        //    set { if (value == dTar_1st_rt_Ry) return; dTar_1st_rt_Ry = value; this.OnPropertyChanged(nameof(Tar_1st_rt_Ry)); }
        //}
        //public double Tar_2nd_rt_Lx
        //{
        //    get { return dTar_2nd_rt_Lx; }
        //    set { if (value == dTar_2nd_rt_Lx) return; dTar_2nd_rt_Lx = value; this.OnPropertyChanged(nameof(Tar_2nd_rt_Lx)); }
        //}
        //public double Tar_2nd_rt_Ly
        //{
        //    get { return dTar_2nd_rt_Ly; }
        //    set { if (value == dTar_2nd_rt_Ly) return; dTar_2nd_rt_Ly = value; this.OnPropertyChanged(nameof(Tar_2nd_rt_Ly)); }
        //}
        //public double Tar_2nd_rt_Rx
        //{
        //    get { return dTar_2nd_rt_Rx; }
        //    set { if (value == dTar_2nd_rt_Rx) return; dTar_2nd_rt_Rx = value; this.OnPropertyChanged(nameof(Tar_2nd_rt_Rx)); }
        //}
        //public double Tar_2nd_rt_Ry
        //{
        //    get { return dTar_2nd_rt_Ry; }
        //    set { if (value == dTar_2nd_rt_Ry) return; dTar_2nd_rt_Ry = value; this.OnPropertyChanged(nameof(Tar_2nd_rt_Ry)); }
        //}
        #endregion


        #endregion
        public Algo4PTarObjResult() : base() { }
        public override string ToString()
        {
            return string.Format("{0} :\n " +
                                  "curDate: {1}\n, " +
                                  "curTime: {2}\n," +

                                  "RevX : {3}\n" +
                                  "RevY : {4}\n" +
                                  "RevT : {5}\n" +

                                  "TarRev.X: {6}\n," +
                                  "TarRev.Y: {7}\n," +
                                  "TarRev.T: {8}\n," +

                                  "ObjRev.X: {9}\n," +
                                  "ObjRev.Y: {10}\n," +
                                  "ObjRev.T: {11}\n," +

                                  "objLength_Left  : {12}\n," +
                                  "objLength_Right : {13}\n" +
                                  "objLength_Upper : {14}\n," +
                                  "objLength_Lower : {15}\n" +

                                  "tarLength_Left  : {16}\n," +
                                  "tarLength_Right  : {17}\n" +
                                  "tarLength_Upper  : {18}\n," +
                                  "tarLength_Lower  : {19}\n" +

                                  // line theta
                                  "objTh_1st_L  : {20}\n," +
                                  "objTh_1st_R  : {21}\n" +
                                  "objTh_2st_L  : {22}\n," +
                                  "objTh_2st_R  : {23}\n" +

                                  "tarTh_1st_L   : {24}\n," +
                                  "tarTh_1st_R   : {25}\n" +
                                  "tarTh_2st_L   : {26}\n," +
                                  "tarTh_2st_R   : {27}\n" +

                                  // line cross angle
                                  "tarAngle_1st_L   : {28}\n," +
                                  "tarAngle_1st_R   : {29}\n" +
                                  "tarAngle_2st_L   : {30}\n," +
                                  "tarAngle_2st_R   : {31}\n" +

                                  "objAngle_1st_L    : {32}\n," +
                                  "objAngle_1st_R    : {33}\n" +
                                  "objAngle_2st_L    : {34}\n," +
                                  "objAngle_2st_R    : {35}\n" +

                                  "offsetX: {36}\n" +
                                  "offsetY: {37}\n" +
                                  "offsetT: {38}\n" +

                                  "islcheckJudgement: {39}\n"
                                  //"isJudgement: {41}\n"

                                  , typeof(Algo4PTarObjResult).ToString()
                                  , curTime
                                  , curDate
                                  , id

                                  , revX
                                  , revY
                                  , revT

                                  ,tar_revX
                                  ,tar_revY
                                  ,tar_revT
                                  
                                  ,obj_revX
                                  ,obj_revY
                                  ,obj_revT                                   
                                  
                                  ,objLength_Left
                                  ,objLength_Right
                                  ,objLength_Upper
                                  ,objLength_Lower 
                                  
                                  ,tarLength_Left
                                  ,tarLength_Right
                                  ,tarLength_Upper
                                  ,tarLength_Lower

                                  ,objTh_Lower
                                  ,objTh_Upper
                                  ,objTh_Left
                                  ,objTh_Right
                                  
                                  ,tarTh_Lower
                                  ,tarTh_Upper
                                  ,tarTh_Left
                                  ,tarTh_Right                                         
  
                                  ,tarAngle_1st_L
                                  ,tarAngle_1st_R
                                  ,tarAngle_2st_L
                                  ,tarAngle_2st_R
                                  
                                  ,objAngle_1st_L
                                  ,objAngle_1st_R
                                  ,objAngle_2st_L
                                  ,objAngle_2st_R

                                  ,offsetX
                                  ,offsetY
                                  ,offsetT
                                  
                                  ,result
                                  );
        }

    }
}
