﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo4PTarObj
{
    public enum ThetaDirection { Normal, Reverse }
    public enum UseMaterCalJig { Use, Unuse }
    public enum CalcType { Obj_3P = 3, Obj_4P = 4 }
}

