﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4PTarObjAttach
{
    [SerializableAttribute]
    public partial class Algo4PTarObjAttachAction : AlgoActionBase
    {
        #region [Fields]

        #endregion

        #region [Properties]   

        #endregion

        #region [Construct]
        public Algo4PTarObjAttachAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo4PTarObjAttachInputParams();
            OutputParams = new Algo4PTarObjAttachOutputParams();

            var obj = _object as Algo4PTarObjAttachObject;
            obj.ModelParamType = typeof(Algo4PTarObjAttachModelParams);
            var param = obj.CurParams as Algo4PTarObjAttachModelParams;

            ChildSettingView = new AlignSetting();
            ChildSettingView.DataContext = this;
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as Algo4PTarObjAttachObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                DateTime dateTime = DateTime.Now;

                if (!Obj.Run())
                {
                    // 기존값들 초기화 필요함.
                    SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                    if(Obj.TarRstData[0].DisplayObj.Judgement == (uint)Judgement.OK)
                    {
                        for(int i = 0; i < 4; i++)
                        {
                            Obj.TarRstData[i].DisplayObj.Judgement = (uint)Judgement.Error;
                            Obj.ObjRstData[i].DisplayObj.Judgement = (uint)Judgement.Error;
                        }
                    }
                    return OccurError(Obj.ErrorCode);
                }
                else
                {
                    SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);

                    switch (Obj.AlignMotionType)
                    {
                        case AlignMotionType.XY:
                            break;
                        case AlignMotionType.XYT:
                            Obj.WriteVisionIO(Obj.RevAlign, null, "");
                            break;
                        case AlignMotionType.UVW:
                            break;
                        case AlignMotionType.UVRW:

                            ReplyArgs = OutputPlay("ConvertXYT", Obj.RevAlign, CmdRequest.Play, CmdMode.Link, CmdWait.Last_Wait);
                            if (!ConfirmReplayArgs(ReplyArgs)) { return OccurError(); }

                            XXYY value = ReplyArgs[0].ReturnValue as XXYY;
                            Obj.WriteVisionIO(value, null, "");
                            break;
                    }

                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    Obj.AppendMessage(Name, "Caluration Complete");
                }

                #endregion
                StopTimer();
            }

            return End();
        }

        #endregion

        #region [Command]
        AlgoParams m_CurParam;

        [field: NonSerialized]
        private DelegateCommand lengthSetCommand;
        public DelegateCommand LengthSetCommand
        {
            get
            {
                return lengthSetCommand = lengthSetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    m_CurParam = DeepClone<AlgoParams>(Obj.CurParams);

                    var tmpParam = Obj.TempParams as Algo4PTarObjAttachModelParams;
                    var modObj = ModObject as Algo4PTarObjAttachObject;

                    tmpParam.ObjLength1.Value = modObj.ObjectLength[0];
                    tmpParam.ObjLength2.Value = modObj.ObjectLength[1];
                    tmpParam.ObjLength3.Value = modObj.ObjectLength[2];
                    tmpParam.ObjLength4.Value = modObj.ObjectLength[3];

                    tmpParam.TarLength1.Value = modObj.TargetLength[0];
                    tmpParam.TarLength2.Value = modObj.TargetLength[1];
                    tmpParam.TarLength3.Value = modObj.TargetLength[2];
                    tmpParam.TarLength4.Value = modObj.TargetLength[3];

                    Obj.UpdateTempValues();
                });
            }
        }


        [field: NonSerialized]
        private DelegateCommand lengthReloadCommand;
        public DelegateCommand LengthReloadCommand
        {
            get
            {
                return lengthReloadCommand = lengthReloadCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;

                    var tmp = Obj.TempParams as Algo4PTarObjAttachModelParams;
                    var cur = m_CurParam as Algo4PTarObjAttachModelParams;

                    tmp.ObjLength1.Value = cur.ObjLength1.Value;
                    tmp.ObjLength2.Value = cur.ObjLength2.Value;
                    tmp.ObjLength3.Value = cur.ObjLength3.Value;
                    tmp.ObjLength4.Value = cur.ObjLength4.Value;

                    tmp.TarLength1.Value = cur.TarLength1.Value;
                    tmp.TarLength2.Value = cur.TarLength2.Value;
                    tmp.TarLength3.Value = cur.TarLength3.Value;
                    tmp.TarLength4.Value = cur.TarLength4.Value;

                    Obj.UpdateTempValues();
                });
            }
        }
        #endregion

        #region [Override]
        public override void PrepareSave()
        {
            base.PrepareSave();
        }

        public override void Dispose()
        {
            base.Dispose();
        }
        #endregion

    }
}
