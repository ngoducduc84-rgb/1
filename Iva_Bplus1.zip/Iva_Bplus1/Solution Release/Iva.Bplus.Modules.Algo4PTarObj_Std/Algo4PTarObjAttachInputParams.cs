﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo4PTarObjAttach
{
    [SerializableAttribute]
    class Algo4PTarObjAttachInputParams : InputParams
    {
        #region Input P1, P2, P3, P4
        public object TAR1 { get; set; }
        public object TAR2 { get; set; }
        public object TAR3 { get; set; }
        public object TAR4 { get; set; }
        public object OBJ1 { get; set; }
        public object OBJ2 { get; set; }
        public object OBJ3 { get; set; }
        public object OBJ4 { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
