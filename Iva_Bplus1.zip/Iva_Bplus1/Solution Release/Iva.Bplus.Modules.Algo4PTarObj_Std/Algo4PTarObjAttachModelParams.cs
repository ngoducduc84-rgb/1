﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo4PTarObjAttach
{
    [SerializableAttribute]

    public partial class Algo4PTarObjAttachModelParams : AlgoParams
    {
        #region Lenght Center      
        private AlgoParam objLength1;
        private AlgoParam objLength2;
        private AlgoParam objLength3;
        private AlgoParam objLength4;

        private AlgoParam tarLength1;
        private AlgoParam tarLength2;
        private AlgoParam tarLength3;
        private AlgoParam tarLength4;
        #endregion

        #region Length Rage
        private AlgoParam lengthTorObj;
        private AlgoParam lengthTorTar;
        #endregion

        #region Align Limit
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        #endregion

        public AlgoParam ObjLength1 { get { return objLength1; } set { if (objLength1 == value) return; objLength1 = value; this.OnPropertyChanged(nameof(ObjLength1)); } }
        public AlgoParam ObjLength2 { get { return objLength2; } set { if (objLength2 == value) return; objLength2 = value; this.OnPropertyChanged(nameof(ObjLength2)); } }
        public AlgoParam ObjLength3 { get { return objLength3; } set { if (objLength3 == value) return; objLength3 = value; this.OnPropertyChanged(nameof(ObjLength3)); } }
        public AlgoParam ObjLength4 { get { return objLength4; } set { if (objLength4 == value) return; objLength4 = value; this.OnPropertyChanged(nameof(ObjLength4)); } }

        public AlgoParam TarLength1 { get { return tarLength1; } set { if (tarLength1 == value) return; tarLength1 = value; this.OnPropertyChanged(nameof(TarLength1)); } }
        public AlgoParam TarLength2 { get { return tarLength2; } set { if (tarLength2 == value) return; tarLength2 = value; this.OnPropertyChanged(nameof(TarLength2)); } }
        public AlgoParam TarLength3 { get { return tarLength3; } set { if (tarLength3 == value) return; tarLength3 = value; this.OnPropertyChanged(nameof(TarLength3)); } }
        public AlgoParam TarLength4 { get { return tarLength4; } set { if (tarLength4 == value) return; tarLength4 = value; this.OnPropertyChanged(nameof(TarLength4)); } }

        public AlgoParam LengthTorObj { get { return lengthTorObj; } set { if (lengthTorObj == value) return; lengthTorObj = value; this.OnPropertyChanged(nameof(LengthTorObj)); } }
        public AlgoParam LengthTorTar { get { return lengthTorTar; } set { if (lengthTorTar == value) return; lengthTorTar = value; this.OnPropertyChanged(nameof(LengthTorTar)); } }

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }


        public Algo4PTarObjAttachModelParams()
            : base()
        {
            ObjLength1 = new AlgoParam("ObjLength1", "mm", typeof(double), 0.0, "Obj Point0 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);
            ObjLength2 = new AlgoParam("ObjLength2", "mm", typeof(double), 0.0, "Obj Point1 <-> Obj Point2 Dist", (double)0.0, (double)1000.0);
            ObjLength3 = new AlgoParam("ObjLength3", "mm", typeof(double), 0.0, "Obj Point2 <-> Obj Point3 Dist", (double)0.0, (double)1000.0);
            ObjLength4 = new AlgoParam("ObjLength4", "mm", typeof(double), 0.0, "Obj Point3 <-> Obj Point0 Dist", (double)0.0, (double)1000.0);

            TarLength1 = new AlgoParam("TarLength1", "mm", typeof(double), 0.0, "Tar Point0 <-> Tar Point1 Dist", (double)0.0, (double)1000.0);
            TarLength2 = new AlgoParam("TarLength2", "mm", typeof(double), 0.0, "Tar Point1 <-> Tar Point2 Dist", (double)0.0, (double)1000.0);
            TarLength3 = new AlgoParam("TarLength3", "mm", typeof(double), 0.0, "Tar Point2 <-> Tar Point3 Dist", (double)0.0, (double)1000.0);
            TarLength4 = new AlgoParam("TarLength4", "mm", typeof(double), 0.0, "Tar Point3 <-> Tar Point0 Dist", (double)0.0, (double)1000.0);

            LengthTorObj = new AlgoParam("LengthTorObj", "mm", typeof(double), 0.0, "Obj L-Check Tolerance Value", (double)0.0, (double)1.0);
            LengthTorTar = new AlgoParam("LengthTorTar", "mm", typeof(double), 0.0, "Tar L-Check Tolerance Value", (double)0.0, (double)1.0);

            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);
        }
    }
}
