﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo4PTarObjAttach
{
    [SerializableAttribute]
    public partial class Algo4PTarObjAttachObject : AlgoObjectBase
    {
        #region [Fields]
        //
        string[] tarCalData = new string[4];
        //
        string[] objCalData = new string[4];

        private string imageName = "Chamber_Main.PNG";
        [field: NonSerialized]
        IPointResult[] tarRstData;
        [field: NonSerialized]
        IPointResult[] objRstData;
        [field: NonSerialized]
        CalDataObject[] tarCalDataObj;
        [field: NonSerialized]
        CalDataObject[] objCalDataObj;
        [field: NonSerialized]
        XY[] objRobotPos;
        [field: NonSerialized]
        XY[] tarRobotPos;
        [field: NonSerialized]
        XY[] objCoorPos;
        [field: NonSerialized]
        XY[] tarCoorPos;
        [field: NonSerialized]
        public double[] objLineTheta;
        [field: NonSerialized]
        public double[] tarLineTheta;
        [field: NonSerialized]
        public XYT objRevPos;
        [field: NonSerialized]
        public XYT tarRevPos;
        [field: NonSerialized]
        double[] objLength;
        [field: NonSerialized]
        double[] tarLength;
        [field: NonSerialized]
        bool[] bObjLength;
        [field: NonSerialized]
        bool[] bTarLength;
        #endregion

        #region etc
        private CalcPoint calcPoint = CalcPoint.Obj_4P;
        private CalcType calcType;
        private ThetaCalType thetaCalType;
        private ThetaDirection thetaDirection;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        #endregion

        #region Align관련 Data
        [field: NonSerialized]
        XYT revAlign = new XYT();
        #endregion

        #region [properties]
        public string ImageName
        {
            get { return imageName; }
            set
            {
                if (imageName == value) return;
                imageName = value;
                this.OnPropertyChanged(nameof(ImageName));
            }
        }
        public double[] ObjectLength
        {
            get { return objLength; }
            set { if (objLength == value) return; objLength = value; this.OnPropertyChanged(nameof(ObjectLength)); }
        }
        public double[] TargetLength
        {
            get { return tarLength; }
            set { if (tarLength == value) return; tarLength = value; this.OnPropertyChanged(nameof(TargetLength)); }
        }
        public IPointResult[] TarRstData
        {
            get { return tarRstData; }
            set { if (tarRstData == value) return; tarRstData = value; this.OnPropertyChanged(nameof(TarRstData)); }
        }
        public IPointResult[] ObjRstData
        {
            get { return objRstData; }
            set { if (objRstData == value) return; objRstData = value; this.OnPropertyChanged(nameof(ObjRstData)); }
        }

        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Tar_1st_L
        {
            get { return tarCalData[0]; }
            set { if (tarCalData[0] == value) return; tarCalData[0] = value; this.OnPropertyChanged(nameof(Tar_1st_L)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Tar_1st_R
        {
            get { return tarCalData[1]; }
            set { if (tarCalData[1] == value) return; tarCalData[1] = value; this.OnPropertyChanged(nameof(Tar_1st_R)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Tar_2nd_L
        {
            get { return tarCalData[2]; }
            set { if (tarCalData[2] == value) return; tarCalData[2] = value; this.OnPropertyChanged(nameof(Tar_2nd_L)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Tar_2nd_R
        {
            get { return tarCalData[3]; }
            set { if (tarCalData[3] == value) return; tarCalData[3] = value; this.OnPropertyChanged(nameof(Tar_2nd_R)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Obj_1st_L
        {
            get { return objCalData[0]; }
            set { if (objCalData[0] == value) return; objCalData[0] = value; this.OnPropertyChanged(nameof(Obj_1st_L)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Obj_1st_R
        {
            get { return objCalData[1]; }
            set { if (objCalData[1] == value) return; objCalData[1] = value; this.OnPropertyChanged(nameof(Obj_1st_R)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Obj_2nd_L
        {
            get { return objCalData[2]; }
            set { if (objCalData[2] == value) return; objCalData[2] = value; this.OnPropertyChanged(nameof(Obj_2nd_L)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Obj_2nd_R
        {
            get { return objCalData[3]; }
            set { if (objCalData[3] == value) return; objCalData[3] = value; this.OnPropertyChanged(nameof(Obj_2nd_R)); }
        }
        #endregion

        #region etc
        public CalcPoint CalcPoint
        {
            get { return calcPoint; }
            set { if (calcPoint == value) return; calcPoint = value; this.OnPropertyChanged(nameof(CalcPoint)); }
        }
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }
        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public ThetaCalType ThetaCalType
        {
            get { return thetaCalType; }
            set { if (thetaCalType == value) return; thetaCalType = value; OnPropertyChanged("ThetaCalType"); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }
        public ObservableCollection<string> CalDataList
        {
            get
            {
                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }
        }
        #endregion

        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        #endregion

        #region[Construct]
        public Algo4PTarObjAttachObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));
            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo4PTarObjAttachModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private string lastResult;

        void Initialize()
        {
            tarRstData = new IPointResult[4];
            objRstData = new IPointResult[4];

            tarCalDataObj = new CalDataObject[4];
            objCalDataObj = new CalDataObject[4];

            objRobotPos = new XY[4];
            tarRobotPos = new XY[4];

            objCoorPos = new XY[4];
            tarCoorPos = new XY[4];

            objLineTheta = new double[4];
            tarLineTheta = new double[4];

            objRevPos = new XYT();
            tarRevPos = new XYT();

            objLength = new double[4];
            tarLength = new double[4];

            bObjLength = new bool[4];
            bTarLength = new bool[4];
        }


        //  0 ------------------ 1 
        //    l [Left]          l [Right]       : 1st
        //    |                 l    
        //    l                 l     ^         
        //    |                 |     |
        //    l                 l     |    theta, Length 계산 방향(반시계)
        //    l                 l     |    
        //    l                 l         
        //    l                 l         
        //    l [Left]          l [Right]       : 2nd
        //  2 ------------------ 3
        //        -------->   theta, Length 계산 방향(반시계)

        //            ↑ 투입 방향    
        //            ↑ 
        //            ↑ 

        private bool AlignCalc()
        {
            #region Initialize
            bool bResult = true;
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            Initialize();
            int iCnt = (int)calcPoint;
            #endregion

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Mark Data Read& Confirm
            for (int i = 0; i < iCnt; i++)
            {
                #region InputData, RefData Set
                // Input Data Check
                if (!InputValues.ContainsKey("TAR" + (i + 1).ToString()) || !InputValues.ContainsKey("OBJ" + (i + 1).ToString()))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                tarRstData[i] = InputValues["TAR" + (i + 1).ToString()] as IPointResult;
                objRstData[i] = InputValues["OBJ" + (i + 1).ToString()] as IPointResult;
                if (tarRstData[i] == null || objRstData[i] == null)
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                #endregion

                #region Coordinate Pos Calc & CalData Cofirm
                // Cal Data 설정
                tarCalDataObj[i] = SystemObject_Common.GetObject(tarCalData[i]) as CalDataObject;
                objCalDataObj[i] = SystemObject_Common.GetObject(objCalData[i]) as CalDataObject;
                if (tarCalDataObj[i] == null || objCalDataObj[i] == null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    return false;
                }
                // Obj Robot Pos
                objRobotPos[i] = objCalDataObj[i].GetV2R(model, new XY(objRstData[i].OutputXYT.X, objRstData[i].OutputXYT.Y));
                // Camera Robot Pos
                tarRobotPos[i] = tarCalDataObj[i].GetV2R(model, new XY(tarRstData[i].OutputXYT.X, tarRstData[i].OutputXYT.Y));
                // Camera Coordination Pos
                objCoorPos[i] = objRobotPos[i] + objCalDataObj[i].GetRotateCenter(model);
                // Camera Coordination Pos
                tarCoorPos[i] = tarRobotPos[i] + tarCalDataObj[i].GetRotateCenter(model);
                #endregion
            }
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo4PTarObjAttachModelParams;

            double[] objLengthSpec = new double[4];
            double[] tarLengthSpec = new double[4];
            double LengthTorObj;
            double LengthTorTar;

            CheckParamSet(mParams);

            objLengthSpec[0] = (double)mParams.ObjLength1.Value;
            objLengthSpec[1] = (double)mParams.ObjLength2.Value;
            objLengthSpec[2] = (double)mParams.ObjLength3.Value;
            objLengthSpec[3] = (double)mParams.ObjLength4.Value;

            tarLengthSpec[0] = (double)mParams.TarLength1.Value;
            tarLengthSpec[1] = (double)mParams.TarLength2.Value;
            tarLengthSpec[2] = (double)mParams.TarLength3.Value;
            tarLengthSpec[3] = (double)mParams.TarLength4.Value;

            LengthTorObj = (double)mParams.LengthTorObj.Value;
            LengthTorTar = (double)mParams.LengthTorTar.Value;

            double limitX = (double)mParams.LimitX.Value;
            double limitY = (double)mParams.LimitY.Value;
            double limitT = (double)mParams.LimitT.Value;
            #endregion

            #region Get X, Y, T
            // Get Line Theta
            objLineTheta[0] = GetThetaColumn(objCoorPos[0].X, objCoorPos[1].X, objCoorPos[0].Y, objCoorPos[1].Y);
            objLineTheta[1] = GetThetaColumn(objCoorPos[1].X, objCoorPos[3].X, objCoorPos[1].Y, objCoorPos[3].Y);
            objLineTheta[2] = GetThetaColumn(objCoorPos[3].X, objCoorPos[2].X, objCoorPos[3].Y, objCoorPos[2].Y);
            objLineTheta[3] = GetThetaColumn(objCoorPos[2].X, objCoorPos[0].X, objCoorPos[2].Y, objCoorPos[0].Y);

            tarLineTheta[0] = GetThetaColumn(tarCoorPos[0].X, tarCoorPos[1].X, tarCoorPos[0].Y, tarCoorPos[1].Y);
            tarLineTheta[1] = GetThetaColumn(tarCoorPos[1].X, tarCoorPos[3].X, tarCoorPos[1].Y, tarCoorPos[3].Y);
            tarLineTheta[2] = GetThetaColumn(tarCoorPos[3].X, tarCoorPos[2].X, tarCoorPos[3].Y, tarCoorPos[2].Y);
            tarLineTheta[3] = GetThetaColumn(tarCoorPos[2].X, tarCoorPos[0].X, tarCoorPos[2].Y, tarCoorPos[0].Y);

            // Get Theta Result
            switch (ThetaCalType)
            {
                case ThetaCalType.UseShort_2L:
                    objRevPos.T = (objLineTheta[0] + objLineTheta[2]) * 0.5;
                    tarRevPos.T = (tarLineTheta[0] + tarLineTheta[2]) * 0.5;
                    break;

                case ThetaCalType.UseLong_2L:
                    objRevPos.T = (objLineTheta[1] + objLineTheta[3]) * 0.5;
                    tarRevPos.T = (tarLineTheta[1] + tarLineTheta[3]) * 0.5;
                    break;

                case ThetaCalType.Use_4L:
                    objRevPos.T = (objLineTheta[0] + objLineTheta[1] + objLineTheta[2] + objLineTheta[3]) * 0.25;
                    tarRevPos.T = (tarLineTheta[0] + tarLineTheta[1] + tarLineTheta[2] + tarLineTheta[3]) * 0.25;
                    break;
            }

            // Get X, Y Result
            objRevPos.X = (objCoorPos[0].X + objCoorPos[1].X + objCoorPos[2].X + objCoorPos[3].X) / 4;
            objRevPos.Y = (objCoorPos[0].Y + objCoorPos[1].Y + objCoorPos[2].Y + objCoorPos[3].Y) / 4;
            tarRevPos.X = (tarCoorPos[0].X + tarCoorPos[1].X + tarCoorPos[2].X + tarCoorPos[3].X) / 4;
            tarRevPos.Y = (tarCoorPos[0].Y + tarCoorPos[1].Y + tarCoorPos[2].Y + tarCoorPos[3].Y) / 4;
            #endregion

            #region Calc Length
            objLength[0] = GetLength(objCoorPos[0], objCoorPos[1]);
            objLength[1] = GetLength(objCoorPos[1], objCoorPos[3]);
            objLength[2] = GetLength(objCoorPos[3], objCoorPos[2]);
            objLength[3] = GetLength(objCoorPos[2], objCoorPos[0]);

            tarLength[0] = GetLength(tarCoorPos[0], tarCoorPos[1]);
            tarLength[1] = GetLength(tarCoorPos[1], tarCoorPos[3]);
            tarLength[2] = GetLength(tarCoorPos[3], tarCoorPos[2]);
            tarLength[3] = GetLength(tarCoorPos[2], tarCoorPos[0]);
            #endregion

            #region Calc Rev Offset
            var alignOffset = CvtPLCIO.OffsetXYT;

            var Tarxyt = new XYT(tarRevPos.X, tarRevPos.Y, tarRevPos.T);
            var Objxyt = new XYT(objRevPos.X, objRevPos.Y, objRevPos.T);

            revAlign = new XYT();
            double radT, DriftX, DriftY;

            // Attach 위치 보정값 계산. 
            Tarxyt = ApplyTargetOffset(Tarxyt, alignOffset);
            radT = NormalizeTheta(Tarxyt.T - Objxyt.T);
            DriftX = Math.Cos(radT) * Objxyt.X - Math.Sin(radT) * Objxyt.Y;
            DriftY = Math.Sin(radT) * Objxyt.X + Math.Cos(radT) * Objxyt.Y;
            revAlign.X = Tarxyt.X - DriftX;
            revAlign.Y = Tarxyt.Y - DriftY;

            if (ThetaDirection == ThetaDirection.Normal)    //정방향
                revAlign.T = radT / rad;
            else //역방향
                revAlign.T = (radT / rad) * -1;

            #endregion

            #region Confirm Result
            string strRst = string.Empty;
            // limit check
            var limit = new XYT(limitX, limitY, limitT);
            if (!ConfirmResult(revAlign, limit))
            {
                bResult = false; strRst = "LimitNG";
                for (int i = 0; i < 4; i++)
                {
                    tarRstData[i].DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    objRstData[i].DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                }
            }

            // length check
            if (!ConfirmLengthResult(objLength, tarLength, objLengthSpec, tarLengthSpec, LengthTorObj, LengthTorTar, bObjLength, bTarLength))
            {
                bResult = false;  strRst = "LCheckNG";
                errorCode = AlgoActionBase.Err_Length_Check;

                for (int i = 0; i < 4; i++)
                {
                    tarRstData[i].DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    objRstData[i].DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                }
            }

            if (!bTarLength[0]) { tarRstData[0].Tool.ProcMode = ProcessMode.Manual; tarRstData[1].Tool.ProcMode = ProcessMode.Manual; }
            if (!bTarLength[1]) { tarRstData[1].Tool.ProcMode = ProcessMode.Manual; tarRstData[3].Tool.ProcMode = ProcessMode.Manual; }
            if (!bTarLength[2]) { tarRstData[3].Tool.ProcMode = ProcessMode.Manual; tarRstData[2].Tool.ProcMode = ProcessMode.Manual; }
            if (!bTarLength[3]) { tarRstData[2].Tool.ProcMode = ProcessMode.Manual; tarRstData[0].Tool.ProcMode = ProcessMode.Manual; }

            if (!bObjLength[0]) { objRstData[0].Tool.ProcMode = ProcessMode.Manual; objRstData[1].Tool.ProcMode = ProcessMode.Manual; }
            if (!bObjLength[1]) { objRstData[1].Tool.ProcMode = ProcessMode.Manual; objRstData[3].Tool.ProcMode = ProcessMode.Manual; }
            if (!bObjLength[2]) { objRstData[3].Tool.ProcMode = ProcessMode.Manual; objRstData[2].Tool.ProcMode = ProcessMode.Manual; }
            if (!bObjLength[3]) { objRstData[2].Tool.ProcMode = ProcessMode.Manual; objRstData[0].Tool.ProcMode = ProcessMode.Manual; }

            #endregion

            #region Result Data Update(DataGridView Insert)
            if (string.IsNullOrEmpty(strRst))
            {
                if (!bResult) strRst = "NG";
                else strRst = "OK";
            }

            AlgoRst = new Algo4PTarObjAttachResult
            {
                Name = name,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Result = strRst,

                RevX = Math.Round(revAlign.X, 3),
                RevY = Math.Round(revAlign.Y, 3),
                RevT = Math.Round(revAlign.T, 3),

                OffsetX = Math.Round(CvtPLCIO.Offset1, 3),
                OffsetY = Math.Round(CvtPLCIO.Offset2, 3),
                OffsetT = Math.Round(CvtPLCIO.Offset3, 3),

                TargetLength1 = Math.Round(tarLength[0], 3),
                TargetLength2 = Math.Round(tarLength[1], 3),
                TargetLength3 = Math.Round(tarLength[2], 3),
                TargetLength4 = Math.Round(tarLength[3], 3),

                ObjectLength1 = Math.Round(objLength[0], 3),
                ObjectLength2 = Math.Round(objLength[1], 3),
                ObjectLength3 = Math.Round(objLength[2], 3),
                ObjectLength4 = Math.Round(objLength[3], 3),

                TargetTheta1 = Math.Round(tarLineTheta[0], 3),
                TargetTheta2 = Math.Round(tarLineTheta[1], 3),
                TargetTheta3 = Math.Round(tarLineTheta[2], 3),
                TargetTheta4 = Math.Round(tarLineTheta[3], 3),

                ObjectTheta1 = Math.Round(objLineTheta[0], 3),
                ObjectTheta2 = Math.Round(objLineTheta[1], 3),
                ObjectTheta3 = Math.Round(objLineTheta[2], 3),
                ObjectTheta4 = Math.Round(objLineTheta[3], 3),

                Pnl_1st_px_Lx = Math.Round(objRstData[0].OutputXYT.X, 3),
                Pnl_1st_px_Ly = Math.Round(objRstData[0].OutputXYT.Y, 3),
                Pnl_1st_px_Rx = Math.Round(objRstData[1].OutputXYT.X, 3),
                Pnl_1st_px_Ry = Math.Round(objRstData[1].OutputXYT.Y, 3),
                Pnl_2nd_px_Lx = Math.Round(objRstData[2].OutputXYT.X, 3),
                Pnl_2nd_px_Ly = Math.Round(objRstData[2].OutputXYT.Y, 3),
                Pnl_2nd_px_Rx = Math.Round(objRstData[3].OutputXYT.X, 3),
                Pnl_2nd_px_Ry = Math.Round(objRstData[3].OutputXYT.Y, 3),

                Wnd_1st_px_Lx = Math.Round(tarRstData[0].OutputXYT.X, 3),
                Wnd_1st_px_Ly = Math.Round(tarRstData[0].OutputXYT.Y, 3),
                Wnd_1st_px_Rx = Math.Round(tarRstData[1].OutputXYT.X, 3),
                Wnd_1st_px_Ry = Math.Round(tarRstData[1].OutputXYT.Y, 3),
                Wnd_2nd_px_Lx = Math.Round(tarRstData[2].OutputXYT.X, 3),
                Wnd_2nd_px_Ly = Math.Round(tarRstData[2].OutputXYT.Y, 3),
                Wnd_2nd_px_Rx = Math.Round(tarRstData[3].OutputXYT.X, 3),
                Wnd_2nd_px_Ry = Math.Round(tarRstData[3].OutputXYT.Y, 3),

                Pnl_1st_rt_Lx = Math.Round(objRobotPos[0].X, 3),
                Pnl_1st_rt_Ly = Math.Round(objRobotPos[0].Y, 3),
                Pnl_1st_rt_Rx = Math.Round(objRobotPos[1].X, 3),
                Pnl_1st_rt_Ry = Math.Round(objRobotPos[1].Y, 3),
                Pnl_2nd_rt_Lx = Math.Round(objRobotPos[2].X, 3),
                Pnl_2nd_rt_Ly = Math.Round(objRobotPos[2].Y, 3),
                Pnl_2nd_rt_Rx = Math.Round(objRobotPos[3].X, 3),
                Pnl_2nd_rt_Ry = Math.Round(objRobotPos[3].Y, 3),

                Wnd_1st_rt_Lx = Math.Round(tarRobotPos[0].X, 3),
                Wnd_1st_rt_Ly = Math.Round(tarRobotPos[0].Y, 3),
                Wnd_1st_rt_Rx = Math.Round(tarRobotPos[1].X, 3),
                Wnd_1st_rt_Ry = Math.Round(tarRobotPos[1].Y, 3),
                Wnd_2nd_rt_Lx = Math.Round(tarRobotPos[2].X, 3),
                Wnd_2nd_rt_Ly = Math.Round(tarRobotPos[2].Y, 3),
                Wnd_2nd_rt_Rx = Math.Round(tarRobotPos[3].X, 3),
                Wnd_2nd_rt_Ry = Math.Round(tarRobotPos[3].Y, 3),


                ID = sourceID,
            };
            #endregion
            //SystemLogger.WriteAlignDBLog(name, AlgoRst);

            if(!bResult) return false;

            #region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, sourceID);
            #endregion
            return true;
        }

        void CheckParamSet(Algo4PTarObjAttachModelParams mParams)
        {
            if (mParams.ObjLength1 == null)
                mParams.ObjLength1 = new AlgoParam("ObjLength1", "mm", typeof(double), 0.0, "Obj Point0 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);
            if (mParams.ObjLength2 == null)
                mParams.ObjLength2 = new AlgoParam("ObjLength2", "mm", typeof(double), 0.0, "Obj Point1 <-> Obj Point2 Dist", (double)0.0, (double)1000.0);
            if (mParams.ObjLength3 == null)
                mParams.ObjLength3 = new AlgoParam("ObjLength3", "mm", typeof(double), 0.0, "Obj Point2 <-> Obj Point3 Dist", (double)0.0, (double)1000.0);
            if (mParams.ObjLength4 == null)
                mParams.ObjLength4 = new AlgoParam("ObjLength4", "mm", typeof(double), 0.0, "Obj Point3 <-> Obj Point1 Dist", (double)0.0, (double)1000.0);

            if (mParams.TarLength1 == null)
                mParams.TarLength1 = new AlgoParam("TarLength1", "mm", typeof(double), 0.0, "Tar Point0 <-> Tar Point1 Dist", (double)0.0, (double)1000.0);
            if (mParams.TarLength2 == null)
                mParams.TarLength2 = new AlgoParam("TarLength2", "mm", typeof(double), 0.0, "Tar Point1 <-> Tar Point2 Dist", (double)0.0, (double)1000.0);
            if (mParams.TarLength3 == null)
                mParams.TarLength3 = new AlgoParam("TarLength3", "mm", typeof(double), 0.0, "Tar Point2 <-> Tar Point3 Dist", (double)0.0, (double)1000.0);
            if (mParams.TarLength4 == null)
                mParams.TarLength4 = new AlgoParam("TarLength4", "mm", typeof(double), 0.0, "Tar Point3 <-> Tar Point0 Dist", (double)0.0, (double)1000.0);

            if (mParams.LengthTorObj == null)
                mParams.LengthTorObj = new AlgoParam("LengthTorObj", "mm", typeof(double), 0.0, "Obj L-Check Tolerance Value", (double)0.0, (double)1.0);
            if (mParams.LengthTorTar == null)
                mParams.LengthTorTar = new AlgoParam("LengthTorTar", "mm", typeof(double), 0.0, "Tar L-Check Tolerance Value", (double)0.0, (double)1.0);
        }

        #endregion

        #region Public Method
        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }
            else
                return true;
        }

        protected bool ConfirmLengthResult(double[] objLength, double[] tarLength, double[] objSpec, double[] tarSpec, double lengthTorObj, double lengthTorTar, bool[] objResult, bool[] tarResult)
        {
            bool bLCheckRst = true;

            for (int i = 0; i < objLength.Length; i++)
            {
                objResult[i] = true;
                if (objSpec[i] == 0.0 || lengthTorObj == 0.0) continue;

                if (!ConfirmSpecMinMax(objLength[i], objSpec[i] - lengthTorObj, objSpec[i] + lengthTorObj))
                {
                    objResult[i] = false;
                    bLCheckRst = false;
                }
            }

            for (int i = 0; i < tarLength.Length; i++)
            {
                tarResult[i] = true;
                if (tarSpec[i] == 0.0 || lengthTorTar == 0.0) continue;

                if (!ConfirmSpecMinMax(tarLength[i], tarSpec[i] - lengthTorTar, tarSpec[i] + lengthTorTar))
                {
                    tarResult[i] = false;
                    bLCheckRst = false;
                }
            }

            return bLCheckRst;
        }

        protected bool ConfirmLengthResult(double[] objLength, double[] tarLength, double[] objSpec, double[] tarSpec, double lengthTor, bool[] objResult, bool[] tarResult)
        {
            bool bLCheckRst = true;

            for (int i = 0; i < objLength.Length; i++)
            {
                objResult[i] = true; 
                if (objSpec[i] == 0.0 || lengthTor == 0.0) continue;

                if (!ConfirmSpecMinMax(objLength[i], objSpec[i] - lengthTor, objSpec[i] + lengthTor))
                {
                    objResult[i] = false;
                    bLCheckRst = false;
                }
            }

            for (int i = 0; i < tarLength.Length; i++)
            {
                tarResult[i] = true;
                if (tarSpec[i] == 0.0 || lengthTor == 0.0) continue;

                if (!ConfirmSpecMinMax(tarLength[i], tarSpec[i] - lengthTor, tarSpec[i] + lengthTor))
                {
                    tarResult[i] = false;
                    bLCheckRst = false;
                }
            }

            return bLCheckRst;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objLength"></param>
        /// <param name="tarLength"></param>
        /// <param name="objSpec"></param>
        /// <param name="tarSpec"></param>
        /// <param name="lengthTor"></param>
        /// <returns></returns>
        protected bool ConfirmLengthResult(double[] tarLength, double[] tarSpec, double lengthTor, bool[] LCheckNG)
        {
            bool bLCheckRst = true;
            for(int i = 0; i < tarLength.Length; i++)
            {
                bTarLength[i] = true;
                if (tarSpec[i] == 0.0 || lengthTor == 0.0) continue;

                if (!ConfirmSpecMinMax(tarLength[i], tarSpec[i] - lengthTor, tarSpec[i] + lengthTor))
                {
                    bTarLength[i] = false;
                    bLCheckRst = false;
                }
            }

            return bLCheckRst;
        }

        public void WriteVisionIO(object rev1, object rev2, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                    VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                    VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                    //VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                    //VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                    //VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                    VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)(rev1 as XXYY).X1; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)(rev1 as XXYY).X2; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)(rev1 as XXYY).Y1; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)(rev1 as XXYY).Y2; IOs.Add(VisionValues["Tar#1_Pos#4"]);

                    VisionValues["Tar#2_Pos#1"].NextValue = (double)(rev2 as XXYY).X1; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)(rev2 as XXYY).X2; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)(rev2 as XXYY).Y1; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)(rev2 as XXYY).Y2; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                    break;
            }

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (cogDisp == null) return;
            Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }

        public void ImageSave(DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            if (rst == null || rst.Length == 0) return;
            for(int i = 0; i < tarRstData.Length; i++)
            {
                if(tarRstData[i] != null && tarRstData[i].DisplayObj != null)
                {
                    ImageSave(tarRstData[i].DisplayObj as CogDisplayObject, dateTime, rst, strPath);
                }
                if (objRstData[i] != null && objRstData[i].DisplayObj != null)
                {
                    ImageSave(objRstData[i].DisplayObj as CogDisplayObject, dateTime, rst, strPath);
                }
            }
        }

        #endregion
    }
}

