﻿using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo4PTarObjAttach
{
    public partial class Algo4PTarObjAttachAction
    {
        #region [Error Script] Algo4PTarObjAttachAction: 16001 ~ 16100

        public override void ErrorDefine()
        {
            base.ErrorDefine();
        }
        #endregion
    }
}
