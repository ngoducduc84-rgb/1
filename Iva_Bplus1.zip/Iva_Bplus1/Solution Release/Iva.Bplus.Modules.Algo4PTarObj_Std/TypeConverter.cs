﻿using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo4PTarObjAttach
{
    public class CalDataListConverter : System.ComponentModel.TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Common.GetEachObjectName(typeof(CalDataObject)));
        }
    }
}
