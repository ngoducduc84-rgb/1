﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo90DBendedLami_3P_CenterAlign;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_CenterAlign
{
    [SerializableAttribute]
    public class Algo90DBendedLami_3P_CenterAlignAction : AlgoActionBase
    {
        #region [Fields]
        #endregion

        #region [Properties]   
        #endregion

        #region[Command]
        #endregion

        #region [Construct]

        public Algo90DBendedLami_3P_CenterAlignAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo90DBendedLami_3P_CenterAlignInputParams();
            OutputParams = new Algo90DBendedLami_3P_CenterAlignOutputParams();

            _object.AddValidationSkipProperty("PSourceID");
            _object.AddValidationSkipProperty("POffsetX");
            _object.AddValidationSkipProperty("POffsetY");
            _object.AddValidationSkipProperty("POffsetT");

            _object.AddValidationSkipProperty("PCurPosXIO");
            _object.AddValidationSkipProperty("PCurPosYIO");
            _object.AddValidationSkipProperty("VResultReply");
            _object.AddValidationSkipProperty("VRevOffsetX");
            _object.AddValidationSkipProperty("VRevOffsetY");
            _object.AddValidationSkipProperty("VRevOffsetT");
            _object.AddValidationSkipProperty("PSourceIDIO");


            _object.AddValidationSkipProperty("POffsetXIO");
            _object.AddValidationSkipProperty("POffsetYIO");
            _object.AddValidationSkipProperty("POffsetTIO");

            _object.AddValidationSkipProperty("VResultReplyIO");

            _object.AddValidationSkipProperty("VRevOffsetXIO");
            _object.AddValidationSkipProperty("VRevOffsetYIO");
            _object.AddValidationSkipProperty("VRevOffsetTIO");
            _object.AddValidationSkipProperty("LastResult");
            _object.AddValidationSkipProperty("ListDispName");
            _object.AddValidationSkipProperty("AlgoRst");
            //_object.AddValidationSkipProperty("VRevOffsetXIO");

            _object.AddValidationSkipProperty("VRevOffsetXIO");



        }
        #endregion


        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CommandRequestArgs args)
        {
            string InputName = Start(obj, args);

            var Obj = modObject as Algo90DBendedLami_3P_CenterAlignObject;

            var InParams = InputParams as Algo90DBendedLami_3P_CenterAlignInputParams;
            var OutParams = OutputParams as Algo90DBendedLami_3P_CenterAlignOutputParams;

            if (InputName.Equals("InputXY_Obj0"))
            {
                Obj.ObjPoint0 = (PositionXYT)args.Value;
                InParams.InputXYT_Obj0 = (PositionXYT)args.Value;

                OnInputChanged(InParams);
                replyType = CommandReplyType.Complete;
            }
            else if (InputName.Equals("InputXYT_Obj1"))
            {
                Obj.ObjPoint1 = (PositionXYT)args.Value;
                InParams.InputXYT_Obj1 = (PositionXYT)args.Value;

                OnInputChanged(InParams);
                replyType = CommandReplyType.Complete;
            }
            else if (InputName.Equals("InputXYT_Obj2"))
            {
                Obj.ObjPoint2 = (PositionXYT)args.Value;
                InParams.InputXYT_Obj2 = (PositionXYT)args.Value;
            }
            else if (InputName.Equals("Trigger") || InputName.Equals(""))
            {

                StartTimer();
                if (IsAuto)
                {
                    Type type = Obj.CommodObject.GetType();
                    dynamic comm = Convert(Obj.CommodObject, type);

                    List<IOObject> UpdateIOs = new List<IOObject>();

                    UpdateIOs.Add(Obj.PSourceIDIO);
                    UpdateIOs.Add(Obj.POffsetXIO);
                    UpdateIOs.Add(Obj.POffsetYIO);
                    UpdateIOs.Add(Obj.POffsetTIO);
                    comm.Device.GetDevices(ref UpdateIOs);

                    // 이게 업데이트
                    Obj.PlcIOs = null;
                }

                replyType = Obj.Run() == true ? CommandReplyType.Complete : CommandReplyType.Error;

                Obj.AppendMessage(Name, "Caluration Complete");
                ReplyArgs = OutputPlay("Result", CommandRequestType.Play, Obj.AlgoRst, false);

                SetResult();

                StopTimer();
            }

            return ReplyArgs;
        }
        private void SetResult()
        {
            var param = OutputParams as Algo90DBendedLami_3P_CenterAlignOutputParams;

            var obj = ModObject as Algo90DBendedLami_3P_CenterAlignObject;

            param.Result = obj.AlgoRst;

            base.UpdateResult();

            OnOutputChanged(param);
        }

        public override void Dispose()
        {
            base.Dispose();
        }

    }
}
