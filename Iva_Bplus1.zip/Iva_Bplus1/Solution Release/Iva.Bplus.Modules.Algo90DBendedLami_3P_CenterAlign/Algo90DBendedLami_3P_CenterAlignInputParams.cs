﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_CenterAlign
{
    [SerializableAttribute]
    class Algo90DBendedLami_3P_CenterAlignInputParams : InputParams
    {
        // Object XYT_Obj0~Obj2
        private PositionXYT inputXYT_Obj0;
        public PositionXYT InputXYT_Obj0
        {
            get { return inputXYT_Obj0; }
            set
            {
                if (inputXYT_Obj0 == value) return;
                inputXYT_Obj0 = value;
                this.OnPropertyChanged("InputXYT_ObjO");
            }
        }

        private PositionXYT inputXYT_Obj1;
        public PositionXYT InputXYT_Obj1
        {
            get { return inputXYT_Obj1; }
            set
            {
                if (inputXYT_Obj1 == value) return;
                inputXYT_Obj1 = value;
                this.OnPropertyChanged("InputXYT_Obj1");
            }
        }

        private PositionXYT inputXYT_Obj2;
        public PositionXYT InputXYT_Obj2
        {
            get { return inputXYT_Obj2; }
            set
            {
                if (inputXYT_Obj2 == value) return;
                inputXYT_Obj2 = value;
                this.OnPropertyChanged("InputXYT_Obj2");
            }
        }

        public ToolWorkTrigger Trigger { get; set; }
    }
}
