﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_CenterAlign
{
    [SerializableAttribute]
    public class Algo90DBendedLami_3P_CenterAlignModelParams : AlgoParams
    {
        public AlgoParam PosOffSetX { get; set; }
        public AlgoParam PosOffSetY { get; set; }

        //public AlgoParam ReverseX { get; set; }
        //public AlgoParam ReverseY { get; set; }
        //public AlgoParam ReverseT { get; set; }

        #region Lenght Center
        public AlgoParam mLengthUpper_Object { get; set; }
        public AlgoParam mLengthLower_Object { get; set; }
        public AlgoParam mLengthLeft_Object { get; set; }
        public AlgoParam mLengthRight_Object { get; set; }
        #endregion

        #region Length Range
        public AlgoParam mLengthRangeUpper_Object { get; set; }
        public AlgoParam mLengthRangeLower_Object { get; set; }
        public AlgoParam mLengthRangeLeft_Object { get; set; }
        public AlgoParam mLengthRangeRight_Object { get; set; }

        #endregion

        #region DesignValue

        public AlgoParam mDesignValuePlus_Obj_X_0 { get; set; }
        public AlgoParam mDesignValuePlus_Obj_X_1 { get; set; }
        public AlgoParam mDesignValuePlus_Obj_X_2 { get; set; }
        public AlgoParam mDesignValuePlus_Obj_X_3 { get; set; }
                                               
        public AlgoParam mDesignValuePlus_Obj_Y_0 { get; set; }
        public AlgoParam mDesignValuePlus_Obj_Y_1 { get; set; }
        public AlgoParam mDesignValuePlus_Obj_Y_2 { get; set; }
        public AlgoParam mDesignValuePlus_Obj_Y_3 { get; set; }
        #endregion

        public Algo90DBendedLami_3P_CenterAlignModelParams()
        {
            PosOffSetX = new AlgoParam("PosOffSetX", typeof(double), 0.0, "PosOffSet X Shift", -10.0, 10.0);
            PosOffSetY = new AlgoParam("PosOffSetY", typeof(double), 0.0, "PosOffSet Y Shift", -10.0, 10.0);

            //ReverseX = new AlgoParam("ReverseX", typeof(double), 1.0, "ReverseX/-1:Left(+),+1:Right(+)", -1.0, 1.0);
            //ReverseY = new AlgoParam("ReverseY", typeof(double), 1.0, "ReverseY/-1:Upper(+),+1:Lower(+)", -1.0, 1.0);
            //ReverseT = new AlgoParam("ReverseT", typeof(double), 1.0, "ReverseT/-1:시계(+),+1:반시계(+)", -1.0, 1.0);

            mLengthUpper_Object = new AlgoParam("mLengthUpper_Object", typeof(double), 0.0, "Upper Object's L-Check Center Value", -10.0, 10.0);
            mLengthLower_Object = new AlgoParam("mLengthLower_Object", typeof(double), 0.0, "Lower Object's L-Check Center Value", -10.0, 10.0);
            mLengthLeft_Object = new AlgoParam("mLengthLeft_Object", typeof(double), 0.0, " Left Object's L-Check Center Value", -10.0, 10.0);
            mLengthRight_Object = new AlgoParam("mLengthRight_Object", typeof(double), 0.0, "Right Object's L-Check Center Value", -10.0, 10.0);

            mLengthRangeUpper_Object = new AlgoParam("mLengthRangeUpper_Object", typeof(double), 0.0, "Upper Object's L-Check Range Value", -10.0, 10.0);
            mLengthRangeLower_Object = new AlgoParam("mLengthRangeLower_Object", typeof(double), 0.0, "Lower Object's L-Check Range Value", -10.0, 10.0);
            mLengthRangeLeft_Object = new AlgoParam("mLengthRangeLeft_Object", typeof(double), 0.0, " Left Object's L-Check Range Value", -10.0, 10.0);
            mLengthRangeRight_Object = new AlgoParam("mLengthRangeRight_Object", typeof(double), 0.0, "Right Object's L-Check Range Value", -10.0, 10.0);

            mDesignValuePlus_Obj_X_0 = new AlgoParam("mDesignValuePlus_Obj_X0", typeof(double), 0.0, "mDesignValuePlus_Obj_X0", -10.0, 10.0);
            mDesignValuePlus_Obj_X_1 = new AlgoParam("mDesignValuePlus_Obj_X1", typeof(double), 0.0, "mDesignValuePlus_Obj_X1", -10.0, 10.0);
            mDesignValuePlus_Obj_X_2 = new AlgoParam("mDesignValuePlus_Obj_X2", typeof(double), 0.0, "mDesignValuePlus_Obj_X2", -10.0, 10.0);
            mDesignValuePlus_Obj_X_3 = new AlgoParam("mDesignValuePlus_Obj_X3", typeof(double), 0.0, "mDesignValuePlus_Obj_X3", -10.0, 10.0);
                                  
            mDesignValuePlus_Obj_Y_0 = new AlgoParam("mDesignValuePlus_Obj_Y0", typeof(double), 0.0, "mDesignValuePlus_Obj_Y0", -10.0, 10.0);
            mDesignValuePlus_Obj_Y_1 = new AlgoParam("mDesignValuePlus_Obj_Y1", typeof(double), 0.0, "mDesignValuePlus_Obj_Y1", -10.0, 10.0);
            mDesignValuePlus_Obj_Y_2 = new AlgoParam("mDesignValuePlus_Obj_Y2", typeof(double), 0.0, "mDesignValuePlus_Obj_Y2", -10.0, 10.0);
            mDesignValuePlus_Obj_Y_3 = new AlgoParam("mDesignValuePlus_Obj_Y3", typeof(double), 0.0, "mDesignValuePlus_Obj_Y3", -10.0, 10.0);
        }
    }
}
