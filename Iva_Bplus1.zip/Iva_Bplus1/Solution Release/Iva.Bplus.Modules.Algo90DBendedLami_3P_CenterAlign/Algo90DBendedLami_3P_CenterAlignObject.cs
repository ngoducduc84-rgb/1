﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_CenterAlign
{
    [SerializableAttribute]
    public partial class Algo90DBendedLami_3P_CenterAlignObject : AlgoObjectBase
    {
        #region [Fields]

        #region 제품 설계치에 대한 Off-Set
        double sDesignValuePlus_Obj_X_0;
        double sDesignValuePlus_Obj_X_1;
        double sDesignValuePlus_Obj_X_2;
        double sDesignValuePlus_Obj_X_3;
                                     
        double sDesignValuePlus_Obj_Y_0;
        double sDesignValuePlus_Obj_Y_1;
        double sDesignValuePlus_Obj_Y_2;
        double sDesignValuePlus_Obj_Y_3;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        private Dictionary<string, IOStruct> m_dicPlcValues; // = new Dictionary<string, IOStruct>();
        /// <summary>
        /// 
        /// </summary>
        private Dictionary<string, IOStruct> m_dicVisionValues; // = new Dictionary<string, IOStruct>();


        #region obj Point0~2
        // ObjectPoint0~4(Window)
        [field: NonSerialized]
        private PositionXYT objPoint0;
        [field: NonSerialized]
        private PositionXYT objPoint1;
        [field: NonSerialized]
        private PositionXYT objPoint2;
        #endregion

        #region  obj CalData 0~2
        private string objCalData0;
        private string objCalData1;
        private string objCalData2;
        #endregion

        #region calDataModObject/Target0~3
        private CalDataObject calDataModObject0;
        private CalDataObject calDataModObject1;
        private CalDataObject calDataModObject2;
        #endregion

        #region vRevOffset, pCurPos, pOffset, pSourceID
        private string pSourceID;
        private string pOffsetX;
        private string pOffsetY;

        private string pCurPosX;
        private string pCurPosY;

        private string pOffsetT;
        private string vResultReply;
        private string vRevOffsetX;
        private string vRevOffsetY;
        private string vRevOffsetT;
        #endregion

        #region Length Check 데이터
        private double dObjectLength_01;
        private double dObjectLength_12;
        private double dObjectLength_23;
        private double dObjectLength_03;
        #endregion

        #region L-Check 데이터 판정
        private bool bObject_LCheck_01;
        private bool bObject_LCheck_12;
        private bool bObject_LCheck_23;
        private bool bObject_LCheck_03;
        #endregion

        #region I/O에 대한 Field값
        [field: NonSerialized]
        private IOObject pSourceIDIO;
        [field: NonSerialized]
        private IOObject pOffsetXIO;
        [field: NonSerialized]
        private IOObject pOffsetYIO;
        [field: NonSerialized]
        private IOObject pOffsetTIO;

        [field: NonSerialized]
        private IOObject pCurPosXIO;
        [field: NonSerialized]
        private IOObject pCurPosYIO;

        [field: NonSerialized]
        private IOObject vResultReplyIO;
        [field: NonSerialized]
        private IOObject vRevOffsetXIO;
        [field: NonSerialized]
        private IOObject vRevOffsetYIO;
        [field: NonSerialized]
        private IOObject vRevOffsetTIO;
        #endregion

        private string lastResult;

        #region Properties 사용 field값
        private ThetaCalType thetaCalType;

        private AxisDirection axisXDirection;
        private AxisDirection axisYDirection;
        private AxisDirection axisTDirection;
        #endregion

        #region 각종 Code 사용 Field값
        // Result Data
        [field: NonSerialized]
        private AlgoVariablePointAlignResult algoRst;

        // Target Line Theta (Window)
        public double[] tarLineTheta = new double[4];

        // Object Line Theta (Panel)
        public double[] objLineTheta = new double[4];

        // Obj,Tar Rev X,Y
        public PositionXYT[] TargetPos = new PositionXYT[4];
        public PositionXYT[] ObjectPos = new PositionXYT[4];

        public XYT TarRevPos = new XYT();
        public XYT ObjRevPos = new XYT();
        public XYT RevPos = new XYT();

        public XY[] tarfixPos = new XY[4];
        public XY[] objfixPos = new XY[4];

        public XY[] tarCoorPos = new XY[4];
        public XY[] objCoorPos = new XY[4];

        public bool JudgeMent;
        #endregion
        #endregion

        #region [properties]
        public AlgoVariablePointAlignResult AlgoRst
        {
            get { return algoRst; }
            set
            {
                if (algoRst == value) return;
                algoRst = value;

                this.OnPropertyChanged(nameof(AlgoRst));
            }
        }

        #region objPoint0~3 Properties
        // Object X,Y,T(Panel)
        public PositionXYT ObjPoint0
        {
            get { return objPoint0; }
            set
            {
                if (objPoint0 == value) return;
                objPoint0 = value;

                OnPropertyChanged("ObjPoint0");
            }
        }

        public PositionXYT ObjPoint1
        {
            get { return objPoint1; }
            set
            {
                if (objPoint1 == value) return;
                objPoint1 = value;

                OnPropertyChanged("ObjPoint1");
            }
        }

        public PositionXYT ObjPoint2
        {
            get { return objPoint2; }
            set
            {
                if (objPoint2 == value) return;
                objPoint2 = value;

                OnPropertyChanged("ObjPoint2");
            }
        }
        #endregion

        #region object CalData Properties
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string ObjCalData0
        {
            get
            {
                return objCalData0;
            }
            set
            {
                if (objCalData0 == value) return;
                objCalData0 = value;

                this.OnPropertyChanged("ObjCalData0");

                calDataModObject0 = SystemObject_Common.GetObject(objCalData0) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string ObjCalData1
        {
            get
            {
                return objCalData1;
            }
            set
            {
                if (objCalData1 == value) return;
                objCalData1 = value;

                this.OnPropertyChanged("ObjCalData1");

                calDataModObject1 = SystemObject_Common.GetObject(objCalData1) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string ObjCalData2
        {
            get
            {
                return objCalData2;
            }
            set
            {
                if (objCalData2 == value) return;
                objCalData2 = value;

                this.OnPropertyChanged("ObjCalData2");

                calDataModObject2 = SystemObject_Common.GetObject(objCalData2) as CalDataObject;
            }
        }
        #endregion


        #region ThetaCalType / AxisDirection Properties
        public ThetaCalType ThetaCalType
        {
            get { return thetaCalType; }
            set
            {
                if (thetaCalType == value) return;

                thetaCalType = value;
                OnPropertyChanged("ThetaCalType");
            }
        }

        public AxisDirection AxisXDirection
        {
            get { return axisXDirection; }
            set
            {
                if (axisXDirection == value) return;

                axisXDirection = value;
                OnPropertyChanged("AxisXDirection");
            }
        }
        public AxisDirection AxisYDirection
        {
            get { return axisYDirection; }
            set
            {
                if (axisYDirection == value) return;

                axisYDirection = value;
                OnPropertyChanged("AxisYDirection");
            }
        }

        public AxisDirection AxisTDirection
        {
            get { return axisTDirection; }
            set
            {
                if (axisTDirection == value) return;

                axisTDirection = value;
                OnPropertyChanged("AxisTDirection");
            }
        }
        #endregion

        #region PLC-Vision Interface Data Properties
        [Browsable(true)]
        [TypeConverter(typeof(PlcIOsListConverter))]
        public string PSourceID
        {
            get { return pSourceID; }
            set
            {
                if (pSourceID == value)
                {
                    //SetIO(Enums.IOType.PLC, pSourceID, ref pSourceIDIO);
                    return;
                }
                pSourceID = value;

                //pSourceIDIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.PLC][pSourceID];


                this.OnPropertyChanged("PSourceID");
            }
        }
        [Browsable(true)]
        [TypeConverter(typeof(PlcIOsListConverter))]
        public string POffsetX
        {
            get { return pOffsetX; }
            set
            {
                if (pOffsetX == value)
                {
                    //SetIO(Enums.IOType.PLC, pOffsetX, ref pOffsetXIO);
                    return;
                }
                pOffsetX = value;

                //pOffsetXIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.PLC][pOffsetX];

                this.OnPropertyChanged("POffsetX");
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(PlcIOsListConverter))]
        public string POffsetY
        {
            get { return pOffsetY; }
            set
            {
                if (pOffsetY == value)
                {
                    //SetIO(Enums.IOType.PLC, pOffsetY, ref pOffsetYIO);
                    return;
                }
                pOffsetY = value;

                //pOffsetYIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.PLC][pOffsetY];

                this.OnPropertyChanged("POffsetY");
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(PlcIOsListConverter))]
        public string POffsetT
        {
            get { return pOffsetT; }
            set
            {
                if (pOffsetT == value)
                {
                    //SetIO(Enums.IOType.PLC, pOffsetT, ref pOffsetTIO);
                    return;
                }
                pOffsetT = value;

                //pOffsetTIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.PLC][pOffsetT];

                this.OnPropertyChanged("POffsetT");
            }
        }

        // Camera Setting Pos
        [Browsable(true)]
        [TypeConverter(typeof(PlcIOsListConverter))]
        public string PCurPosXIO
        {
            get { return pCurPosX; }
            set
            {
                if (pCurPosX == value)
                {
                    //SetIO(Enums.IOType.PLC, pOffsetT, ref pOffsetTIO);
                    return;
                }
                pCurPosX = value;

                //pOffsetTIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.PLC][pOffsetT];

                this.OnPropertyChanged("PCurPosX");
            }
        }


        [Browsable(true)]
        [TypeConverter(typeof(PlcIOsListConverter))]
        public string PCurPosYIO
        {
            get { return pCurPosY; }
            set
            {
                if (pCurPosY == value)
                {
                    //SetIO(Enums.IOType.PLC, pOffsetT, ref pOffsetTIO);
                    return;
                }
                pCurPosY = value;

                //pCurPosYIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.PLC][pOffsetT];

                this.OnPropertyChanged("PCurPosY");
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(VisionIOsListConverter))]
        public string VResultReply
        {
            get { return vResultReply; }
            set
            {
                if (vResultReply == value)
                {
                    //SetIO(Enums.IOType.VISION, vResultReply, ref vResultReplyIO);
                    return;
                }
                vResultReply = value;

                //vResultReplyIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.VISION][vResultReply];

                this.OnPropertyChanged("VResultReply");
            }
        }
        [Browsable(true)]
        [TypeConverter(typeof(VisionIOsListConverter))]
        public string VRevOffsetX
        {
            get { return vRevOffsetX; }
            set
            {
                if (vRevOffsetX == value)
                {
                    //SetIO(Enums.IOType.VISION, vRevOffsetX, ref vRevOffsetXIO);
                    return;
                }
                vRevOffsetX = value;

                //vRevOffsetXIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.VISION][vRevOffsetX];

                this.OnPropertyChanged("VRevOffsetX");
            }
        }
        [Browsable(true)]
        [TypeConverter(typeof(VisionIOsListConverter))]
        public string VRevOffsetY
        {
            get { return vRevOffsetY; }
            set
            {
                if (vRevOffsetY == value)
                {
                    //SetIO(Enums.IOType.VISION, vRevOffsetY, ref vRevOffsetYIO);
                    return;
                }
                vRevOffsetY = value;

                //vRevOffsetYIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.VISION][vRevOffsetY];

                this.OnPropertyChanged("VRevOffsetY");
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(VisionIOsListConverter))]
        public string VRevOffsetT
        {
            get { return vRevOffsetT; }
            set
            {
                if (vRevOffsetT == value)
                {
                    //SetIO(Enums.IOType.VISION, vRevOffsetT, ref vRevOffsetTIO);
                    return;
                }
                vRevOffsetT = value;

                //vRevOffsetTIO = (SystemObject.GetModuleObject(commObj) as MitsubishiPLCObject).IOs[Enums.IOType.VISION][vRevOffsetT];

                this.OnPropertyChanged("VRevOffsetT");
            }
        }

        public IOObject PSourceIDIO
        {
            get { return pSourceIDIO; }
            set
            {
                if (pSourceIDIO == value) return;
                pSourceIDIO = value;
                //comModObject.AddRealTimeUpdateIOs(pSourceIDIO);
                this.OnPropertyChanged("PSourceIDIO");
            }
        }

        // 촬상Pos에서의 위치 (IO_PLC에서 받음)
        public IOObject POffsetXIO
        {
            get { return pOffsetXIO; }
            set
            {
                if (pOffsetXIO == value) return;
                pOffsetXIO = value;
                //comModObject.AddRealTimeUpdateIOs(pOffsetXIO);
                this.OnPropertyChanged("POffsetXIO");
            }
        }

        public IOObject POffsetYIO
        {
            get { return pOffsetYIO; }
            set
            {
                if (pOffsetYIO == value) return;
                pOffsetYIO = value;
                //comModObject.AddRealTimeUpdateIOs(pOffsetYIO);
                this.OnPropertyChanged("POffsetYIO");
            }
        }

        public IOObject POffsetTIO
        {
            get { return pOffsetTIO; }
            set
            {
                if (pOffsetTIO == value) return;
                pOffsetTIO = value;
                //comModObject.AddRealTimeUpdateIOs(pOffsetTIO);
                this.OnPropertyChanged("POffsetTIO");
            }
        }



        public IOObject VResultReplyIO
        {
            get { return vResultReplyIO; }
            set
            {
                if (vResultReplyIO == value) return;
                vResultReplyIO = value;
                //comModObject.AddRealTimeUpdateIOs(vResultReplyIO);
                this.OnPropertyChanged("VResultReplyIO");
            }
        }

        public IOObject VRevOffsetXIO
        {
            get { return vRevOffsetXIO; }
            set
            {
                if (vRevOffsetXIO == value) return;
                vRevOffsetXIO = value;
                //comModObject.AddRealTimeUpdateIOs(vRevOffsetXIO);
                this.OnPropertyChanged("VRevOffsetXIO");
            }
        }

        public IOObject VRevOffsetYIO
        {
            get { return vRevOffsetYIO; }
            set
            {
                if (vRevOffsetYIO == value) return;
                vRevOffsetYIO = value;
                //comModObject.AddRealTimeUpdateIOs(vRevOffsetYIO);
                this.OnPropertyChanged("VRevOffsetYIO");
            }
        }

        public IOObject VRevOffsetTIO
        {
            get { return vRevOffsetTIO; }
            set
            {
                if (vRevOffsetTIO == value) return;
                vRevOffsetTIO = value;
                //comModObject.AddRealTimeUpdateIOs(vRevOffsetTIO);
                this.OnPropertyChanged("VRevOffsetTIO");
            }
        }
        #endregion
        #endregion

        public string LastResult
        {
            get { return lastResult; }
            set
            {
                if (lastResult == value) return;
                lastResult = value;
                this.OnPropertyChanged("LastResult");
            }
        }




        #region [private method]
        #endregion

        #region [public method]
        public void SetInfomation()
        {
        }
        #endregion





        #region[Construct]

        public Algo90DBendedLami_3P_CenterAlignObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            CommObj = lst.Count != 0 ? lst[0] : "";
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            StartTimer();

            // 현재 모델명 가지고 오기
            string model = SystemModel.GetCurModel();
            string targetID = string.Empty;
            // string productID = string.Empty;


            if (m_dicPlcValues.ContainsKey("CellID"))
            {
                //targetID = PSourceIDIO.CurValue.ToString();
                targetID = (string)m_dicPlcValues["CellID"].CurValue;
            }
            else
            {
                // Warning
            }


            //if (PSourceID != null)
            //    productID = PSourceIDIO.Value.ToString();
            //else
            //{
            //    // [Do] Error Code + PLC에 Write
            //}

            Array.Clear(TargetPos, 0, TargetPos.Length); Array.Clear(ObjectPos, 0, ObjectPos.Length);

            // '알고리즘' 구분 Code
            Type type = typeof(Algo90DBendedLami_3P_CenterAlignObject);
            bool UseTarget = false; // TarObj 알고리즘
            int CountPos = 3; int InsertPos = 4; // <- for 90D의 3Point에서 Tar: 4Point, Obj: 3Point Use

            // (Debug용 Code)
            //----------------------------------------------------------------------
            objPoint0 = new PositionXYT(0, 0, 0, 0, 0, Position.Obj0);
            objPoint1 = new PositionXYT(2, 8, 0, 0, 0, Position.Obj1);
            objPoint2 = new PositionXYT(6, 8, 0, 0, 0, Position.Obj2);
            //----------------------------------------------------------------------

            // 1) obj,tar Point별 Array에 투입
            // ObjPoint이 null 여부만 확인!, 내부(구조체) '비어있는' 항목에 대해서는 Non-Check!
            if (PosConfirm(type, UseTarget, CountPos, InsertPos, ref TargetPos, ref ObjectPos) == false) return false;

            if (PSourceID != null)
                targetID = PSourceIDIO.Value.ToString();
            else
            {
                // [Do] Error Code 정리
            }

            bool existID = true;

            if (targetID == string.Empty)
            {
                existID = false;
                //없으니 가상아이디 10자리 만들자.
                targetID = GetMakeID(10);
            }

            // 2) CalData 유/무 확인 -> 내부 Data가 없으면 Error 처리 <- 앞 Module에서 처리 (있으면 주석 처리 하자!)
            object[] ObjCalData = new object[4]; object[] TarCalData = new object[4];
            // [Do] Validation서 작업!
            bool CalConfirm = CalDataConfirm(type, UseTarget, CountPos, InsertPos, ref ObjCalData, ref TarCalData);
            if (CalConfirm == false) return false;

            // 3) ModelData 가져오기 !!! 보자 !!!
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo90DBendedLami_3P_CenterAlignModelParams;

            // 4) (각 Point에 대한) Vision좌표, Cal시 Pos, 현 Cam Pos에 대한 데이터 받기!
            // 4-1) 'Vision 좌표계' 투입용. for 'GetV2R()' 매개변수 투입용   
            XY[] TempObjPos = new XY[4]; XY[] TempTarPos = new XY[4];// method Base Code 사용하기 위한 것 (Non_Use)
            Array.Clear(TempObjPos, 0, TempObjPos.Length); Array.Clear(TempTarPos, 0, TempTarPos.Length);
            ArrayVisionPos(InsertPos, CountPos, UseTarget, TargetPos, ObjectPos, ref TempTarPos, ref TempObjPos);

            // 4-2) 'Cal Pos' 투입용
            //* [Do] CalData에서 'Cal간 Cam'의 Position을 가져옴 <- ('CalData'에서 받아서)구현하자!, 임시 Code <- 수정하면됨.
            XY[] ObjCalPos = new XY[4];
            XY[] TarCalPos = new XY[4]; // method 공용 사용하기 위한 것 (Non_Use)
            ArrayCalPos(InsertPos, CountPos, UseTarget, ref TarCalPos, ref ObjCalPos);

            // 4-3) '현 Cur Pos' 투입용
            //* [Do] 촬상Pos의 X,Y값을 IO(PLC)에서 받아옴. (임시 Code -> 추후 작성 필요)
            XY[] ObjCurGrabPos = new XY[4]; XY[] TarCurGrabPos = new XY[4];// <- IO값 넣자!
            ArrayCurGrabPos(InsertPos, CountPos, UseTarget, ref TarCurGrabPos, ref ObjCurGrabPos);


            // 5) CoorPos(+ FixPos 계산), Object(Window) / Target(Panel)    
            XY[] ObjDesignVal = new XY[4];
            XY[] TarDesignVal = new XY[4]; // Non_Use
            #region 제품 DesignValue에 대한 Off-Set               
            double.TryParse(mParams.mDesignValuePlus_Obj_X_0.Value.ToString(), out sDesignValuePlus_Obj_X_0);
            double.TryParse(mParams.mDesignValuePlus_Obj_X_1.Value.ToString(), out sDesignValuePlus_Obj_X_1);
            double.TryParse(mParams.mDesignValuePlus_Obj_X_2.Value.ToString(), out sDesignValuePlus_Obj_X_2);
            double.TryParse(mParams.mDesignValuePlus_Obj_X_3.Value.ToString(), out sDesignValuePlus_Obj_X_3);
                                                                                                        
            double.TryParse(mParams.mDesignValuePlus_Obj_Y_0.Value.ToString(), out sDesignValuePlus_Obj_Y_0);
            double.TryParse(mParams.mDesignValuePlus_Obj_Y_1.Value.ToString(), out sDesignValuePlus_Obj_Y_1);
            double.TryParse(mParams.mDesignValuePlus_Obj_Y_2.Value.ToString(), out sDesignValuePlus_Obj_Y_2);
            double.TryParse(mParams.mDesignValuePlus_Obj_Y_3.Value.ToString(), out sDesignValuePlus_Obj_Y_3);
            #endregion

            ArrayDesignValue(type, ref TarDesignVal, ref ObjDesignVal);


            CalCoorPos(model, ref tarCoorPos, ref objCoorPos,
                        TempObjPos,       // Vision 좌표계 
                        ObjCurGrabPos, ObjCalPos,     // Cal 진행 Pos
                        ObjDesignVal);  // 자재 Design Off-set

            for (int temp = 0; temp < tarLineTheta.Length; temp++)
            {
                tarLineTheta[temp] = 0; objLineTheta[temp] = 0;
            }

            // 6) Object, Target에 대한 X,Y,T 산출
            // 6-1) 각 '변'의 Theta성분 
            AlignType AlignMode = AlignType.Obj_3P; //
            CalRevTheta(AlignMode, tarCoorPos, objCoorPos, ref tarLineTheta, ref objLineTheta);

            // 6-2) Theta 성분 산출,  X(Left+), Y(Lower+), T(시계+)
            CalRevTheta(AlignMode, ThetaCalType, tarLineTheta, objLineTheta, ref ObjRevPos, ref TarRevPos);

            // 6-3) X,Y 성분 산출
            CalRevXY(AlignMode, CountPos, tarCoorPos, objCoorPos, ref ObjRevPos, ref TarRevPos);

            // 7) Off-Set 계산, [Do] PLC에서 Off-Set 받아오는 것!
            XYT offset = new XYT(0, 0, 0);
            offset = CalTargetPos(POffsetXIO, POffsetYIO, POffsetTIO);

            // 8) Off-set 반영, Target Pos 계산 -> OffSet 고려한 Target Pos 계산
            TarRevPos = ApplyTargetOffset(TarRevPos, offset);

            // 9) RevT산출
            RevPos.T = TarRevPos.T - ObjRevPos.T;

            // 10) DriftXY 산출
            double DriftX = Math.Cos(RevPos.T) * ObjRevPos.X - Math.Sin(RevPos.T) * ObjRevPos.Y;
            double DriftY = Math.Sin(RevPos.T) * ObjRevPos.X + Math.Cos(RevPos.T) * ObjRevPos.Y;

            // 11) 최종 RevPos산출, PI * rad = 180도, 1 rad = 180 / PI 
            RevPos.X = TarRevPos.X - DriftX;
            RevPos.Y = TarRevPos.Y - DriftY;
            RevPos.T = RevPos.T / rad;

            // 12) L-Check (Obj/Tar)
            L_Check(ref dObjectLength_01, ref dObjectLength_12, ref dObjectLength_23, ref dObjectLength_03);

            // L-Check
            bool judgeObject = ObjectLCheck(model, dObjectLength_01, dObjectLength_12, dObjectLength_23, dObjectLength_03);

            // Judgement 결과
            if (!judgeObject)
                JudgeMent = false;
            else
                JudgeMent = true;

            // 13) 최종 결과 
            XYT retVal = new XYT
            {
                X = (double)AxisXDirection * RevPos.X,
                Y = (double)AxisYDirection * RevPos.Y,
                T = (double)AxisTDirection * (RevPos.T),
            };

            // 이건 모지?
            //bool judgement = false;
            //{
            //    // 판정
            //}

            AlgoRst = new AlgoVariablePointAlignResult
            {
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                ProductID = targetID,

                // 최종 결과 값
                RevOffsetX = RevPos.X,
                RevOffsetY = RevPos.Y,
                RevOffsetT = RevPos.T,

                // Target 결과 값 
                Target_PosX = TarRevPos.X,
                Target_PosY = TarRevPos.Y,
                Target_PosT = TarRevPos.T,

                // Object 결과 값
                Object_PosX = ObjRevPos.X,
                Object_PosY = ObjRevPos.Y,
                Object_PosT = ObjRevPos.T,

                // 각 성분의 Theta값 
                //T01_TargetTheta = tarLineTheta[0],
                //T23_TargetTheta = tarLineTheta[2],
                //T12_TargetTheta = tarLineTheta[1],
                //T03_TargetTheta = tarLineTheta[3],

                T01_ObjectTheta = objLineTheta[0],
                T23_ObjectTheta = objLineTheta[2],
                T12_ObjectTheta = objLineTheta[1],
                T03_ObjectTheta = objLineTheta[3],

                DObjectLength_01 = dObjectLength_01,
                DObjectLength_12 = dObjectLength_12,
                DObjectLength_23 = dObjectLength_23,
                DObjectLength_03 = dObjectLength_03,

                BObject_LCheck_01 = bObject_LCheck_01,
                BObject_LCheck_12 = bObject_LCheck_12,
                BObject_LCheck_23 = bObject_LCheck_23,
                BObject_LCheck_03 = bObject_LCheck_03,

                // PLC Off-Set값 
                OffsetX = 0,
                OffsetY = 0,
                OffsetT = 0,

                IsExistID = existID,
                IsJudgement = JudgeMent,
            };

            StopTimer();

            return true;
        }



        public void L_Check( ref double dObjectLength_01, ref double dObjectLength_12, ref double dObjectLength_23, ref double dObjectLength_03)
        {
            dObjectLength_01 = GetLength(objCoorPos[0], objCoorPos[1]);
            dObjectLength_03 = GetLength(objCoorPos[0], objCoorPos[3]);
            dObjectLength_23 = GetLength(objCoorPos[2], objCoorPos[3]);
            dObjectLength_12 = GetLength(objCoorPos[1], objCoorPos[2]);
        }

        #endregion
 

    // Align 방식 
    //  1 -------------------------------- 2 [Upper, Right]
    //    |                               l
    //    |                               l
    //    l                               l
    //    |                               |        Lower 찍고, Upper로 이동!
    //    l                               l         
    //    l                               l
    //  0 -------------------------------- 3 [Lower, Right]
    //     '작업자' 방향

    // Th01 == tarLineTheta[0]
    // Th12 == tarLineTheta[1]
    // Th23 == tarLineTheta[2]
    // Th30 == tarLineTheta[3]
    //}


    public XYT CalTargetPos(IOObject POffsetXIO, IOObject POffsetYIO, IOObject POffsetTIO)
        {
            XYT tempOffset = new XYT(0, 0, 0);

            if (POffsetXIO != null)
                tempOffset.X = (double)POffsetXIO.Value;
            else
            {
                // Warning
            }

            if (POffsetYIO != null)
                tempOffset.Y = (double)POffsetYIO.Value;
            else
            {
                // Warning
            }

            if (POffsetTIO != null)
                tempOffset.T = (double)POffsetTIO.Value;
            else
            {
                // Warning
            }

            return tempOffset;
        }

        #region ObjeckLCheck
        public bool ObjectLCheck(string model, double dObjectLength_01, double dObjectLength_12, double dObjectLength_23, double dObjectLength_03)
        {
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo90DBendedLami_3P_CenterAlignModelParams;

            double sLength_Upper_Object;
            double sLength_Lower_Object;
            double sLength_Right_Object;
            double sLength_Left_Object;

            double sLengthRange_Upper_Object;
            double sLengthRange_Lower_Object;
            double sLengthRange_Right_Object;
            double sLengthRange_Left_Object;

            double.TryParse(mParams.mLengthUpper_Object.Value.ToString(), out sLength_Upper_Object);
            double.TryParse(mParams.mLengthLower_Object.Value.ToString(), out sLength_Lower_Object);
            double.TryParse(mParams.mLengthLeft_Object.Value.ToString(), out sLength_Right_Object);
            double.TryParse(mParams.mLengthRight_Object.Value.ToString(), out sLength_Left_Object);

            double.TryParse(mParams.mLengthRangeUpper_Object.Value.ToString(), out sLengthRange_Upper_Object);
            double.TryParse(mParams.mLengthRangeLower_Object.Value.ToString(), out sLengthRange_Lower_Object);
            double.TryParse(mParams.mLengthRangeLeft_Object.Value.ToString(), out sLengthRange_Right_Object);
            double.TryParse(mParams.mLengthRangeRight_Object.Value.ToString(), out sLengthRange_Left_Object);


            // 0bject L_Check
            if (sLength_Upper_Object != 0 && sLengthRange_Upper_Object != 0)
            {
                if ((dObjectLength_23 > sLength_Upper_Object - sLengthRange_Upper_Object
                 && dObjectLength_23 < sLength_Upper_Object + sLengthRange_Upper_Object)
                 || dObjectLength_23 == 0)
                {
                    bObject_LCheck_23 = true;
                }
                else
                {
                    bObject_LCheck_23 = false;
                }
            }
            else
            {
                bObject_LCheck_01 = true;
            }

            if (sLength_Lower_Object != 0 && sLengthRange_Lower_Object != 0)
            {
                if ((dObjectLength_01 > sLength_Lower_Object - sLengthRange_Lower_Object
                  && dObjectLength_01 < sLength_Lower_Object + sLengthRange_Lower_Object)
                  || dObjectLength_01 == 0)
                {
                    bObject_LCheck_01 = true;
                }
                else
                {
                    bObject_LCheck_01 = false;
                }
            }
            else
            {
                bObject_LCheck_01 = true;
            }

            if (sLength_Right_Object != 0 && sLengthRange_Right_Object != 0)
            {
                if ((dObjectLength_12 > sLength_Right_Object - sLengthRange_Right_Object
                  && dObjectLength_12 < sLength_Right_Object + sLengthRange_Right_Object)
                  || dObjectLength_12 == 0)
                {
                    bObject_LCheck_12 = true;
                }
                else
                {
                    bObject_LCheck_12 = false;
                }
            }
            else
            {
                bObject_LCheck_12 = true;
            }

            if (sLength_Left_Object != 0 && sLengthRange_Left_Object != 0)
            {
                if ((dObjectLength_03 > sLength_Left_Object - sLengthRange_Left_Object
                  && dObjectLength_03 < sLength_Left_Object + sLengthRange_Left_Object)
                  || dObjectLength_03 == 0)
                {
                    bObject_LCheck_03 = true;
                }
                else
                {
                    bObject_LCheck_03 = false;
                }
            }
            else
            {
                bObject_LCheck_03 = true;
            }
            return true;
        }
        #endregion
  
        // [Do] GetV2R과 GetRotateCenter -> Coding할 것!
        public void CalCoorPos(string model, ref XY[] tarCoorPos, ref XY[] objCoorPos,
                               XY[] ObjectPos, XY[] ObjCurGrabPos, XY[] ObjCalPos, XY[] ObjDesignVal)
        {
            //[임시] tarCoorPos, objCoorPos 초기화
            Array.Clear(objCoorPos, 0, tarCoorPos.Length);
            Array.Clear(tarCoorPos, 0, tarCoorPos.Length);

            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                Type type = typeof(Algo90DBendedLami_3P_CenterAlignObject);
                FieldInfo[] fields = type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var field in fields)
                {
                    if (field.Name == ("calDataModObject" + Pos.ToString()) || field.Name == ("calDataModTarget" + Pos.ToString()))
                    {
                        string[] nameSplit = field.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = field.GetValue(this);

                        CalDataObject CalData = (CalDataObject)CalValue;

                        switch (nameSplit[1])
                        {
                            case "Obj":  // Object(Window,상부)
                                if (Pos != 3 && CalData != null)
                                {
                                    //objfixPos[Pos] = new XY(0, 0);
                                    objfixPos[Pos] = CalData.GetRotateCenter(model) - ObjCurGrabPos[Pos] + ObjCalPos[Pos]; // (Cal, CurGrab)Pos 고려한 FixPos 계산
                                    objCoorPos[Pos] = objfixPos[Pos] + CalData.GetV2R(model, ObjectPos[Pos], true, true) + ObjDesignVal[Pos]; // 자재 Design 설계치 삽입

                                    tarCoorPos[Pos] = CalData.GetRotateCenter(model); // CamCentere
                                }
                                else
                                {
                                    // [Do] Error 처리
                                }
                                break;
                        }
                    }
                }
            }

            // 가상 4번째 Point 만들기!
            objCoorPos[3] = objCoorPos[0] + objCoorPos[2] - objCoorPos[1];
            tarCoorPos[3] = tarCoorPos[0] + tarCoorPos[2] - tarCoorPos[1];



        }

        public void ClassificationType(AlignType AlignMode, ref bool UseTarget, ref int CountPos)
        {
            string stringAlignMode = AlignMode.ToString();
            string[] splitAlignType = stringAlignMode.Split(new char[] { '_' });
            string[] splitCount = stringAlignMode.Split(new string[] { "_", "Obj", "Tar", "P" }, StringSplitOptions.None);
            for (int temp = 0; temp < splitCount.Length; temp++)
            {
                if (splitCount[temp] != "") CountPos = int.Parse(splitCount[temp]);
            }

            if (splitAlignType[0] == "Tar") { UseTarget = true; }
        }
        public override void Dispose()
        {
            base.Dispose();
        }

        public override void DefaultIOSet()
        {
            //PSourceID = "SourceID";
            //POffsetX = "Offset_1";
            //POffsetY = "Offset_2";
            //POffsetT = "Offset_3";
            //VResultReply = "AlignRst";
            //VRevOffsetX = "RevX";
            //VRevOffsetY = "RevY";
            //VRevOffsetT = "RevT";
           //m_dicPlcValues = new Dictionary<string, IOStruct>();
           // m_dicVisionValues = new Dictionary<string, IOStruct>();

            base.DefaultIOSet();

            // 해당 하는 io를 가져온다.
            //PlcIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();
            //VisionIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();

            m_dicPlcValues.Clear();
            m_dicVisionValues.Clear();


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    // PlcIOs.Add(item);
                    m_dicPlcValues.Add(item.Key, item);
                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    //VisionIOs.Add(item);
                    m_dicVisionValues.Add(item.Key, item);
                }
            }
        }


        public override void ObjectInitialize()
        {
            m_dicPlcValues = new Dictionary<string, IOStruct>();
            m_dicVisionValues = new Dictionary<string, IOStruct>();

            if (AlignTableObject == null) return;

            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    m_dicPlcValues.Add(item.Key, item);
                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    m_dicVisionValues.Add(item.Key, item);
                }
            }
        }

        public override void ObjectUpdate()
        {
            base.ObjectUpdate();

            PlcIOsListConverter.Module = CommObj;
            VisionIOsListConverter.Module = CommObj;
        } 
    }
}
