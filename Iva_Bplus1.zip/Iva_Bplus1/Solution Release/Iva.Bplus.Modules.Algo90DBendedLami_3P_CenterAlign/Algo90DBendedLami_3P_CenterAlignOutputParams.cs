﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_CenterAlign
{
    class Algo90DBendedLami_3P_CenterAlignOutputParams : OutputParams
    {
        public object Result { get; set; }
    }
}
