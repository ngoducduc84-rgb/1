﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_CenterAlign
{
    public class AlgoVariablePointAlignResult : ViewModelBase
    {
        private string curDate;
        private string curTime;
        private string productID;

        private double revX;
        private double revY;
        private double revT;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        private double modelX;
        private double modelY;

        private double t01_TargetTheta;
        private double t23_TargetTheta;
        private double t01_ObjectTheta;
        private double t23_ObjectTheta;

        private double t12_TargetTheta;
        private double t03_TargetTheta;
        private double t12_ObjectTheta;
        private double t03_ObjectTheta;

        private double productPosX;
        private double productPosY;
        private double productPosT;

        private double revOffsetX;
        private double revOffsetY;
        private double revOffsetT;

        private double target_PosX;
        private double target_PosY;
        private double target_PosT;

        private double object_PosX;
        private double object_PosY;
        private double object_PosT;

        //private double dTargetLength_01;
        //private double dTargetLength_12;
        //private double dTargetLength_23;
        //private double dTargetLength_03;

        //private bool bTarget_LCheck_01;
        //private bool bTarget_LCheck_12;
        //private bool bTarget_LCheck_23;
        //private bool bTarget_LCheck_03;

        private double dObjectLength_01;
        private double dObjectLength_12;
        private double dObjectLength_23;
        private double dObjectLength_03;

        private bool bObject_LCheck_01;
        private bool bObject_LCheck_12;
        private bool bObject_LCheck_23;
        private bool bObject_LCheck_03;

        private bool isExistID;
        private bool isJudgement;


        public string CurDate
        {
            get { return curDate; }
            set
            {
                if (value == curDate) return;
                curDate = value;
                OnPropertyChanged("CurDate");
            }
        }

        public string CurTime
        {
            get { return curTime; }
            set
            {
                if (value == curTime) return;
                curTime = value;
                OnPropertyChanged("CurTime");
            }
        }

        #region 각 성분의 Theta값
        //public double T01_TargetTheta
        //{
        //    get { return t01_TargetTheta; }
        //    set
        //    {
        //        if (value == t01_TargetTheta) return;
        //        t01_TargetTheta = value;
        //        this.OnPropertyChanged(nameof(T01_TargetTheta));
        //    }
        //}

        //public double T23_TargetTheta
        //{
        //    get { return t23_TargetTheta; }
        //    set
        //    {
        //        if (value == t23_TargetTheta) return;
        //        t23_TargetTheta = value;
        //        this.OnPropertyChanged(nameof(T23_TargetTheta));
        //    }
        //}

        //public double T12_TargetTheta
        //{
        //    get { return t12_TargetTheta; }
        //    set
        //    {
        //        if (value == t12_TargetTheta) return;
        //        t12_TargetTheta = value;
        //        this.OnPropertyChanged(nameof(T12_TargetTheta));
        //    }
        //}

        //public double T03_TargetTheta
        //{
        //    get { return t03_TargetTheta; }
        //    set
        //    {
        //        if (value == t03_TargetTheta) return;
        //        t03_TargetTheta = value;
        //        this.OnPropertyChanged(nameof(T03_TargetTheta));
        //    }
        //}
        public double T01_ObjectTheta
        {
            get { return t01_ObjectTheta; }
            set
            {
                if (value == t01_ObjectTheta) return;
                t01_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T01_ObjectTheta));
            }
        }

        public double T23_ObjectTheta
        {
            get { return t23_ObjectTheta; }
            set
            {
                if (value == t23_ObjectTheta) return;
                t23_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T23_ObjectTheta));
            }
        }

        public double T12_ObjectTheta
        {
            get { return t12_ObjectTheta; }
            set
            {
                if (value == t12_ObjectTheta) return;
                t12_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T12_ObjectTheta));
            }
        }

        public double T03_ObjectTheta
        {
            get { return t03_ObjectTheta; }
            set
            {
                if (value == t03_ObjectTheta) return;
                t03_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T03_ObjectTheta));
            }
        }
        #endregion

        #region 최종 결과 값
        public double RevOffsetX
        {
            get { return revOffsetX; }
            set
            {
                if (value == revOffsetX) return;
                revOffsetX = value;
                this.OnPropertyChanged(nameof(RevOffsetX));
            }
        }

        public double RevOffsetY
        {
            get { return revOffsetY; }
            set
            {
                if (value == revOffsetY) return;
                revOffsetY = value;
                this.OnPropertyChanged(nameof(RevOffsetY));
            }
        }

        public double RevOffsetT
        {
            get { return revOffsetT; }
            set
            {
                if (value == revOffsetT) return;
                revOffsetT = value;
                this.OnPropertyChanged(nameof(RevOffsetT));
            }
        }
        #endregion

        public string ProductID
        {
            get { return productID; }
            set
            {
                if (value == productID) return;
                productID = value;
                OnPropertyChanged("ProduectID");
            }
        }


        //public double DTargetLength_01
        //{
        //    get { return dTargetLength_01; }
        //    set
        //    {
        //        if (value == dTargetLength_01) return;
        //        dTargetLength_01 = value;
        //        this.OnPropertyChanged(nameof(DTargetLength_01));
        //    }
        //}
        //public double DTargetLength_12
        //{
        //    get { return dTargetLength_12; }
        //    set
        //    {
        //        if (value == dTargetLength_12) return;
        //        dTargetLength_12 = value;
        //        this.OnPropertyChanged(nameof(DTargetLength_12));
        //    }
        //}

        //public double DTargetLength_23
        //{
        //    get { return dTargetLength_23; }
        //    set
        //    {
        //        if (value == dTargetLength_23) return;
        //        dTargetLength_23 = value;
        //        this.OnPropertyChanged(nameof(DTargetLength_23));
        //    }
        //}

        //public double DTargetLength_03
        //{
        //    get { return dTargetLength_03; }
        //    set
        //    {
        //        if (value == dTargetLength_03) return;
        //        dTargetLength_03 = value;
        //        this.OnPropertyChanged(nameof(DTargetLength_03));
        //    }
        //}

        //public bool BTarget_LCheck_01
        //{
        //    get { return bTarget_LCheck_01; }
        //    set
        //    {
        //        if (value == bTarget_LCheck_01) return;
        //        bTarget_LCheck_01 = value;
        //        this.OnPropertyChanged(nameof(BTarget_LCheck_01));
        //    }
        //}

        //public bool BTarget_LCheck_12
        //{
        //    get { return bTarget_LCheck_12; }
        //    set
        //    {
        //        if (value == bTarget_LCheck_12) return;
        //        bTarget_LCheck_12 = value;
        //        this.OnPropertyChanged(nameof(BTarget_LCheck_12));
        //    }
        //}

        //public bool BTarget_LCheck_23
        //{
        //    get { return bTarget_LCheck_23; }
        //    set
        //    {
        //        if (value == bTarget_LCheck_23) return;
        //        bTarget_LCheck_23 = value;
        //        this.OnPropertyChanged(nameof(BTarget_LCheck_23));
        //    }
        //}

        //public bool BTarget_LCheck_03
        //{
        //    get { return bTarget_LCheck_03; }
        //    set
        //    {
        //        if (value == bTarget_LCheck_03) return;
        //        bTarget_LCheck_03 = value;
        //        this.OnPropertyChanged(nameof(BTarget_LCheck_03));
        //    }
        //}

        public double DObjectLength_01
        {
            get { return dObjectLength_01; }
            set
            {
                if (value == dObjectLength_01) return;
                dObjectLength_01 = value;
                this.OnPropertyChanged(nameof(DObjectLength_01));
            }
        }
        public double DObjectLength_12
        {
            get { return dObjectLength_12; }
            set
            {
                if (value == dObjectLength_12) return;
                dObjectLength_12 = value;
                this.OnPropertyChanged(nameof(DObjectLength_12));
            }
        }

        public double DObjectLength_23
        {
            get { return dObjectLength_23; }
            set
            {
                if (value == dObjectLength_23) return;
                dObjectLength_23 = value;
                this.OnPropertyChanged(nameof(DObjectLength_23));
            }
        }

        public double DObjectLength_03
        {
            get { return dObjectLength_03; }
            set
            {
                if (value == dObjectLength_03) return;
                dObjectLength_03 = value;
                this.OnPropertyChanged(nameof(DObjectLength_03));
            }
        }

        public bool BObject_LCheck_01
        {
            get { return bObject_LCheck_01; }
            set
            {
                if (value == bObject_LCheck_01) return;
                bObject_LCheck_01 = value;
                this.OnPropertyChanged(nameof(BObject_LCheck_01));
            }
        }

        public bool BObject_LCheck_12
        {
            get { return bObject_LCheck_12; }
            set
            {
                if (value == bObject_LCheck_12) return;
                bObject_LCheck_12 = value;
                this.OnPropertyChanged(nameof(BObject_LCheck_12));
            }
        }

        public bool BObject_LCheck_23
        {
            get { return bObject_LCheck_23; }
            set
            {
                if (value == bObject_LCheck_23) return;
                bObject_LCheck_23 = value;
                this.OnPropertyChanged(nameof(BObject_LCheck_23));
            }
        }

        public bool BObject_LCheck_03
        {
            get { return bObject_LCheck_03; }
            set
            {
                if (value == bObject_LCheck_03) return;
                bObject_LCheck_03 = value;
                this.OnPropertyChanged(nameof(BObject_LCheck_03));
            }
        }


        public double RevX
        {
            get { return revX; }
            set
            {
                if (value == revX) return;
                revX = value;
                OnPropertyChanged("RevX");
            }
        }

        public double RevY
        {
            get { return revY; }
            set
            {
                if (value == revY) return;
                revY = value;
                OnPropertyChanged("RevY");
            }
        }

        public double RevT
        {
            get { return revT; }
            set
            {
                if (value == revT) return;
                revT = value;

                OnPropertyChanged("RevT");
            }
        }


        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                if (value == offsetX) return;
                offsetX = value;

                OnPropertyChanged("OffsetX");
            }
        }

        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                if (value == offsetY) return;
                offsetY = value;

                OnPropertyChanged("OffsetY");
            }
        }

        public double OffsetT
        {
            get { return offsetT; }
            set
            {
                if (value == offsetT) return;
                offsetT = value;

                OnPropertyChanged("OffsetT");
            }
        }

        public double ModelX
        {
            get { return modelX; }
            set
            {
                if (value == modelX) return;
                modelX = value;

                OnPropertyChanged("ModelX");
            }
        }

        public double ModelY
        {
            get { return modelY; }
            set
            {
                if (value == modelY) return;
                modelY = value;

                OnPropertyChanged("ModelY");
            }
        }

        #region Target 결과 값 
        public double Target_PosX
        {
            get { return target_PosX; }
            set
            {
                if (value == target_PosX) return;
                target_PosX = value;
                this.OnPropertyChanged(nameof(Target_PosX));
            }
        }

        public double Target_PosY
        {
            get { return target_PosY; }
            set
            {
                if (value == target_PosY) return;
                target_PosY = value;
                this.OnPropertyChanged(nameof(Target_PosY));
            }
        }

        public double Target_PosT
        {
            get { return target_PosT; }
            set
            {
                if (value == target_PosT) return;
                target_PosT = value;
                this.OnPropertyChanged(nameof(target_PosT));
            }
        }
        #endregion

        #region Object 결과 값 
        public double Object_PosX
        {
            get { return object_PosX; }
            set
            {
                if (value == object_PosX) return;
                object_PosX = value;
                this.OnPropertyChanged(nameof(Object_PosX));
            }
        }

        public double Object_PosY
        {
            get { return object_PosY; }
            set
            {
                if (value == object_PosY) return;
                object_PosY = value;
                this.OnPropertyChanged(nameof(Object_PosY));
            }
        }

        public double Object_PosT
        {
            get { return object_PosT; }
            set
            {
                if (value == object_PosT) return;
                object_PosT = value;
                this.OnPropertyChanged(nameof(Object_PosT));
            }
        }
        #endregion

        public double ProductPosX
        {
            get { return productPosX; }
            set
            {
                if (value == productPosX) return;
                productPosX = value;

                OnPropertyChanged("ProductPosX");
            }
        }

        public double ProductPosY
        {
            get { return productPosY; }
            set
            {
                if (value == productPosY) return;
                productPosY = value;

                OnPropertyChanged("ProductPosY");
            }
        }

        public double ProductPosT
        {
            get { return productPosT; }
            set
            {
                if (value == productPosT) return;
                productPosT = value;

                OnPropertyChanged("ProductPosT");
            }
        }


        public bool IsExistID
        {
            get { return isExistID; }
            set
            {
                if (value == isExistID) return;
                isExistID = value;

                OnPropertyChanged("IsExistID");
            }
        }

        public bool IsJudgement
        {
            get { return isJudgement; }
            set
            {
                if (value == isJudgement) return;
                isJudgement = value;

                OnPropertyChanged("IsJudgement");
            }
        }


        public AlgoVariablePointAlignResult()
        {
        }

        #region [Properties]   
        #endregion

        public override string ToString()
        {
            return string.Format("{0} :\n " +
                                  "curDate: {1}\n, " +
                                  "curTime: {2}\n," +

                                  "TarRev.X: {3}\n," +
                                  "TarRev.Y: {4}\n," +
                                  "TarRev.T: {5}\n," +

                                  "ObjRev.X: {6}\n," +
                                  "ObjRev.Y: {7}\n," +
                                  "ObjRev.T: {8}\n," +

                                  "RevOffsetX : {9}\n" +
                                  "RevOffsetY : {10}\n" +
                                  "RevOffsetT : {11}\n" +

                                  "T01_TargetTheta : {12}\n," +
                                  "T23_TargetTheta : {13}\n" +
                                  "T12_TargetTheta : {14}\n," + "revX: {3}\n," +
                                  "T03_TargetTheta : {15}\n" +

                                  "T01_ObjectTheta  : {16}\n," +
                                  "T23_ObjectTheta  : {17}\n" +
                                  "T12_ObjectTheta  : {18}\n," +
                                  "T03_ObjectTheta  : {19}\n" +

                                  "DTargetLength_01  : {20}\n," +
                                  "DTargetLength_12  : {21}\n" +
                                  "DTargetLength_23  : {22}\n," +
                                  "DTargetLength_03  : {23}\n" +

                                  //"BTarget_LCheck_01   : {24}\n," +
                                  //"BTarget_LCheck_12   : {25}\n" +
                                  //"BTarget_LCheck_23   : {26}\n," +
                                  //"BTarget_LCheck_03   : {27}\n" +

                                  //"DObjectLength_01   : {28}\n," +
                                  //"DObjectLength_12   : {29}\n" +
                                  //"DObjectLength_23   : {30}\n," +
                                  //"DObjectLength_03   : {31}\n" +

                                  "BObject_LCheck_01    : {24}\n," +
                                  "BObject_LCheck_12    : {25}\n" +
                                  "BObject_LCheck_23    : {26}\n," +
                                  "BObject_LCheck_03    : {27}\n" +

                                  "offsetX: {28}\n" +
                                  "offsetY: {29}\n" +
                                  "offsetT: {30}\n" +

                                  "isExistID: {31}\n" +
                                  "isJudgement: {32}\n"
                                  , typeof(AlgoVariablePointAlignResult).ToString()
                                  , curTime
                                  , curDate
                                  , productID

                                  , target_PosX
                                  , target_PosY
                                  , target_PosT

                                  , object_PosX
                                  , object_PosY
                                  , object_PosT

                                  , t01_TargetTheta
                                  , t23_TargetTheta
                                  , t12_TargetTheta
                                  , t03_TargetTheta

                                  , t01_ObjectTheta
                                  , t23_ObjectTheta
                                  , t12_ObjectTheta
                                  , t03_ObjectTheta

                                  //, dTargetLength_01
                                  //, dTargetLength_12
                                  //, dTargetLength_23
                                  //, dTargetLength_03

                                  //, bTarget_LCheck_01
                                  //, bTarget_LCheck_12
                                  //, bTarget_LCheck_23
                                  //, bTarget_LCheck_03

                                  , dObjectLength_01
                                  , dObjectLength_12
                                  , dObjectLength_23
                                  , dObjectLength_03

                                  , bObject_LCheck_01
                                  , bObject_LCheck_12
                                  , bObject_LCheck_23
                                  , bObject_LCheck_03

                                  , revX
                                  , revY
                                  , revT

                                  , offsetX
                                  , offsetY
                                  , offsetT

                                  , isExistID
                                  , isJudgement
                                  );
        }
    }
}
