﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo90DBendedLami_3P_TarObj;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_TarObj
{
    [SerializableAttribute]
    public partial class Algo90DBendedLami_3P_TarObjAction : AlgoActionBase
    {
        #region [Fields]
        #endregion

        #region [Properties]   
        #endregion

        #region[Command]
        #endregion

        #region [Construct]

        public Algo90DBendedLami_3P_TarObjAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo90DBendedLami_3P_TarObjInputParams();
            OutputParams = new Algo90DBendedLami_3P_TarObjOutputParams();

            _object.AddValidationSkipProperty("PSourceID");
            _object.AddValidationSkipProperty("POffsetX");
            _object.AddValidationSkipProperty("POffsetY");
            _object.AddValidationSkipProperty("POffsetT");

            _object.AddValidationSkipProperty("PCurPosXIO");
            _object.AddValidationSkipProperty("PCurPosYIO");
            _object.AddValidationSkipProperty("VResultReply");
            _object.AddValidationSkipProperty("VRevOffsetX");
            _object.AddValidationSkipProperty("VRevOffsetY");
            _object.AddValidationSkipProperty("VRevOffsetT");
            _object.AddValidationSkipProperty("PSourceIDIO");


            _object.AddValidationSkipProperty("POffsetXIO");
            _object.AddValidationSkipProperty("POffsetYIO");
            _object.AddValidationSkipProperty("POffsetTIO");

            _object.AddValidationSkipProperty("VResultReplyIO");

            _object.AddValidationSkipProperty("VRevOffsetXIO");
            _object.AddValidationSkipProperty("VRevOffsetYIO");
            _object.AddValidationSkipProperty("VRevOffsetTIO");
            _object.AddValidationSkipProperty("LastResult");
            _object.AddValidationSkipProperty("ListDispName");
            _object.AddValidationSkipProperty("AlgoRst");
            //_object.AddValidationSkipProperty("VRevOffsetXIO");

            _object.AddValidationSkipProperty("VRevOffsetXIO");



        }
        #endregion


        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args);

            var Obj = modObject as Algo90DBendedLami_3P_TarObjObject;

            var InParams = InputParams as Algo90DBendedLami_3P_TarObjInputParams;
            var OutParams = OutputParams as Algo90DBendedLami_3P_TarObjOutputParams;

            //if (InputName.Equals("InputXY_Tar0"))
            //{
            //    Obj.TarPoint0 = (MatchingRstData)_args.Value;
            //    InParams.InputXYT_Tar0 = (MatchingRstData)_args.Value;

            //    OnInputChanged(InParams);
            //    replyType = CmdReply.Complete;
            //}
            if (InputName.Equals("OCA_2st_L"))
            {
                Obj.TarPoint1 = (MatchingRstData)_args.Value;
                //InParams.OCA_2st_L = (MatchingRstData)_args.Value;

                //OnInputChanged(InParams);
                replyType = CmdReply.Complete;
            }
            else if (InputName.Equals("OCA_1st_L"))
            {
                Obj.TarPoint2 = (MatchingRstData)_args.Value;
                //InParams.OCA_1st_L = (MatchingRstData)_args.Value;

                //OnInputChanged(InParams);
                replyType = CmdReply.Complete;
            }
            else if (InputName.Equals("OCA_1st_R"))
            {
                Obj.TarPoint3 = (MatchingRstData)_args.Value;
                InParams.OCA_1st_R = (MatchingRstData)_args.Value;

                OnInputChanged(InParams);
                replyType = CmdReply.Complete;
            }
            else if (InputName.Equals("PNL_2st_R"))
            {
                Obj.ObjPoint0 = (MatchingRstData)_args.Value;
                InParams.PNL_2st_R = (MatchingRstData)_args.Value;

                OnInputChanged(InParams);
                replyType = CmdReply.Complete;
            }
            else if (InputName.Equals("PNL_2st_L"))
            {
                Obj.ObjPoint1 = (MatchingRstData)_args.Value;
                InParams.PNL_2st_L = (MatchingRstData)_args.Value;

                OnInputChanged(InParams);
                replyType = CmdReply.Complete;
            }
            else if (InputName.Equals("PNL_1st_L"))
            {
                Obj.ObjPoint2 = (MatchingRstData)_args.Value;
                InParams.PNL_1st_L = (MatchingRstData)_args.Value;
            }
            else if (InputName.Equals("Calc") || InputName.Equals("Trigger") || InputName.Equals(""))
            {

                StartTimer();

                //[문의] 하기는 IO를 '초기화'시 받아오니 필요없다?*****
                if (IsAuto)
                {
                    Type type = Obj.CommodObject.GetType();
                    dynamic comm = Convert(Obj.CommodObject, type);

                    List<IOObject> UpdateIOs = new List<IOObject>();

                    //UpdateIOs.Add(Obj.PSourceIDIO);
                    //UpdateIOs.Add(Obj.POffsetXIO);
                    //UpdateIOs.Add(Obj.POffsetYIO);
                    //UpdateIOs.Add(Obj.POffsetTIO);
                    comm.Device.GetDevices(ref UpdateIOs);

                    // 이게 업데이트
                    //Obj.PlcIOs = null;
                }
                //*****************************************************

                // 1. Algorithm 객체 받아옴.
                var algoIFObject = ModObject as Algo90DBendedLami_3P_TarObjObject;
                return new List<CommandReplyArgs>(); // Dry Run을 위한 임시 Test
                replyType = Obj.Run() == true ? CmdReply.Complete : CmdReply.Error;

                // (Algorithm 모두 돌릴시 문제 시 된) Error Code 검색
                foreach (KeyValuePair<string, bool> pair in algoIFObject.errorCode)
                {
                    if (pair.Value == false)
                    {
                        switch (pair.Key)
                        {
                            case "Err_Obtain_Coordinate_Value":
                                ReplyArgs.Add(OccurError(E15401_Failed_To_Obtain_Coordinate_Value));
                                break;
                            case "Err_Upload_VisionPos_Value, True":
                                ReplyArgs.Add(OccurError(E15402__Failed_To_Upload_VisionPos_Value));
                                break;
                            case "Err_FDC_Data_Pos":
                                ReplyArgs.Add(OccurError(E15403_Failed_To_Upload_FDC_Data_Pos));
                                break;
                            case "Err_FDC_Data_LCheck":
                                ReplyArgs.Add(OccurError(E15404_Failed_To_Upload_FDC_Data_LCheck));
                                break;
                            case "Err_FDC_Data_TarRevPos":
                                ReplyArgs.Add(OccurError(E15405_Failed_To_Upload_FDC_Data_TarRevPos));
                                break;
                            case "Err_FDC_Data_RevPos":
                                ReplyArgs.Add(OccurError(E15406_Failed_To_Upload_FDC_Data_RevPos));
                                break;
                            case "Err_obtain_VisionPos_Value":
                                ReplyArgs.Add(OccurError(E15407_Failed_To_Obtain_VisionPos_Value));
                                break;
                            case "Err_obtain_CalData_Value":
                                ReplyArgs.Add(OccurError(E15408_Failed_To_Obtain_CalData_Value));
                                break;
                            case "Err_obtain_CalPosition_Value":
                                ReplyArgs.Add(OccurError(E15409_Failed_To_Obtain_CalPosition_Value));
                                break;
                            case "Err_obtain_CurPosition_Value":
                                ReplyArgs.Add(OccurError(E15410_Failed_To_Obtain_CurPosition_Value));
                                break;
                            case "Err_obtain_Offset_Value":
                                ReplyArgs.Add(OccurError(E15411_Failed_To_Obtain_Offset_Value));
                                break;
                            case "Err_LCheck_Spec_Out":
                                ReplyArgs.Add(OccurError(E15412_Failed_To_Obtain_Offset_Value));
                                break;
                            case "Err_Obtain_Camera_CalPos_Value":
                                ReplyArgs.Add(OccurError(E15413_Obtain_Camera_CalPos_Value));
                                break;
                        }
                    }
                }

                // Run을 돌리고, 내부에 'Error'가 발생하면 return ReplyArgs함.
                foreach (CommandReplyArgs arg in ReplyArgs)
                {
                    if (arg.ReplyType == CmdReply.Error)
                        return ReplyArgs;
                }

                // 2. PLC Update하는 부분
                var vIO_data = algoIFObject.M_dicVisionValues;
                var vIO_obj = algoIFObject.CommodObject;
                vIO_obj.SetPlcValues(vIO_data.Values.ToList());

                // 3. Log에 대한 DataGridView에 넘겨줌      
                ReplyArgs = OutputPlay("LogResult", algoIFObject.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                Obj.AppendMessage(Name, "Caluration Complete");



                StopTimer();
            }

            return ReplyArgs;
            //    var algoIFObject = ModObject as Algo90DBendedLami_3P_TarObjObject;
            //    var vIO_data = algoIFObject.M_dicVisionValues;
            //    var vIO_obj = algoIFObject.CommodObject;
            //    //List<IOStruct> temp = vision_io.Values.ToList();
            //    vIO_obj.SetPlcValues(vIO_data.Values.ToList());

            //    // Log에 대한 DataGridView에 넘겨줌      
            //    ReplyArgs = OutputPlay("LogResult", algoIFObject.AlgoRst, CmdRequest.Play, _args.Mode, false);

            //    Obj.AppendMessage(Name, "Caluration Complete");
            //    //ReplyArgs = OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, false);

            //    SetResult();

            //    StopTimer();
            //}

            //return ReplyArgs;
        }
        private void SetResult()
        {
            var param = OutputParams as Algo90DBendedLami_3P_TarObjOutputParams;

            var obj = ModObject as Algo90DBendedLami_3P_TarObjObject;

            //param.Result = obj.AlgoRst;

            base.UpdateResult();

            OnOutputChanged(param);
        }

        public override void Dispose()
        {
            base.Dispose();
        }

    }
}
