﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_TarObj
{
    [SerializableAttribute]
    class Algo90DBendedLami_3P_TarObjInputParams : InputParams
    {
        #region Input Tar0~4(OCA), Obj0~3(Panel)
        public MatchingRstData OCA_1st_L { get; set; }
        public MatchingRstData OCA_1st_R { get; set; }
        public MatchingRstData OCA_2st_L { get; set; }
        public MatchingRstData PNL_1st_L { get; set; }
        public MatchingRstData PNL_2st_L { get; set; }
        public MatchingRstData PNL_2st_R { get; set; }

        #endregion

        public CalcTrigger Trigger { get; set; }
    }
}
