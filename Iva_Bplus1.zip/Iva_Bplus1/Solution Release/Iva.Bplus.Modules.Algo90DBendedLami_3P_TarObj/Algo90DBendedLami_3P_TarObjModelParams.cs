﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_TarObj
{
    [SerializableAttribute]

    public partial class Algo90DBendedLami_3P_TarObjModelParams : AlgoParams
    {
        #region Lenght Center

        private AlgoParam _LengthCenter_01_Target;
        private AlgoParam _LengthCenter_12_Target;
        private AlgoParam _LengthCenter_23_Target;
        private AlgoParam _LengthCenter_30_Target;

        private AlgoParam _LengthCenter_01_Object;
        private AlgoParam _LengthCenter_12_Object;
        private AlgoParam _LengthCenter_23_Object;
        private AlgoParam _LengthCenter_30_Object;
        #endregion

        #region LengthCenter Properties
        public AlgoParam LengthCenter_01_Target
        {
            get { return _LengthCenter_01_Target; }
            set { _LengthCenter_01_Target = value; }
        }
        public AlgoParam LengthCenter_12_Target
        {
            get { return _LengthCenter_12_Target; }
            set { _LengthCenter_12_Target = value; }
        }
        public AlgoParam LengthCenter_23_Target
        {
            get { return _LengthCenter_23_Target; }
            set { _LengthCenter_23_Target = value; }
        }
        public AlgoParam LengthCenter_30_Target
        {
            get { return _LengthCenter_30_Target; }
            set { _LengthCenter_30_Target = value; }
        }


        public AlgoParam LengthCenter_01_Object
        {
            get { return _LengthCenter_01_Object; }
            set { _LengthCenter_01_Object = value; }
        }
        public AlgoParam LengthCenter_12_Object
        {
            get { return _LengthCenter_12_Object; }
            set { _LengthCenter_12_Object = value; }
        }
        public AlgoParam LengthCenter_23_Object
        {
            get { return _LengthCenter_23_Object; }
            set { _LengthCenter_23_Object = value; }
        }
        public AlgoParam LengthCenter_30_Object
        {
            get { return _LengthCenter_30_Object; }
            set { _LengthCenter_30_Object = value; }
        }
        #endregion

        #region Length Rage
        private AlgoParam _LengthRange_01_Target;
        private AlgoParam _LengthRange_12_Target;
        private AlgoParam _LengthRange_23_Target;
        private AlgoParam _LengthRange_30_Target;

        private AlgoParam _LengthRange_01_Object;
        private AlgoParam _LengthRange_12_Object;
        private AlgoParam _LengthRange_23_Object;
        private AlgoParam _LengthRange_30_Object;
        #endregion

        #region LengthRange Properties
        public AlgoParam LengthRange_01_Target
        {
            get { return _LengthRange_01_Target; }
            set { _LengthRange_01_Target = value; }
        }
        public AlgoParam LengthRange_12_Target
        {
            get { return _LengthRange_12_Target; }
            set { _LengthRange_12_Target = value; }
        }
        public AlgoParam LengthRange_23_Target
        {
            get { return _LengthRange_23_Target; }
            set { _LengthRange_23_Target = value; }
        }
        public AlgoParam LengthRange_30_Target
        {
            get { return _LengthRange_30_Target; }
            set { _LengthRange_30_Target = value; }
        }

        public AlgoParam LengthRange_01_Object
        {
            get { return _LengthRange_01_Object; }
            set { _LengthRange_01_Object = value; }
        }
        public AlgoParam LengthRange_12_Object
        {
            get { return _LengthRange_12_Object; }
            set { _LengthRange_12_Object = value; }
        }
        public AlgoParam LengthRange_23_Object
        {
            get { return _LengthRange_23_Object; }
            set { _LengthRange_23_Object = value; }
        }
        public AlgoParam LengthRange_30_Object
        {
            get { return _LengthRange_30_Object; }
            set { _LengthRange_30_Object = value; }
        }
        #endregion

        private AlgoParam _CenterOffsetX;

        //public AlgoParam CenterOffsetX
        //{
        //    get { return _CenterOffsetX; }
        //    set { _CenterOffsetX = value; }
        //}

        //private AlgoParam _CenterOffsetY;

        //public AlgoParam CenterOffsetY
        //{
        //    get { return _CenterOffsetY; }
        //    set { _CenterOffsetY = value; }
        //}




        #region DesignValue
        private AlgoParam _DesignValuePlus_Obj_X_0;
        public AlgoParam DesignValuePlus_Obj_X_0
        {
            get { return _DesignValuePlus_Obj_X_0; }
            set { _DesignValuePlus_Obj_X_0 = value; }
        }

        private AlgoParam _DesignValuePlus_Obj_X_1;
        public AlgoParam DesignValuePlus_Obj_X_1
        {
            get { return _DesignValuePlus_Obj_X_1; }
            set { _DesignValuePlus_Obj_X_1 = value; }
        }

        private AlgoParam _DesignValuePlus_Obj_X_2;
        public AlgoParam DesignValuePlus_Obj_X_2
        {
            get { return _DesignValuePlus_Obj_X_2; }
            set { _DesignValuePlus_Obj_X_2 = value; }
        }

        private AlgoParam _DesignValuePlus_Obj_X_3;
        public AlgoParam DesignValuePlus_Obj_X_3
        {
            get { return _DesignValuePlus_Obj_X_3; }
            set { _DesignValuePlus_Obj_X_3 = value; }
        }


        private AlgoParam _DesignValuePlus_Obj_Y_0;
        public AlgoParam DesignValuePlus_Obj_Y_0
        {
            get { return _DesignValuePlus_Obj_Y_0; }
            set { _DesignValuePlus_Obj_Y_0 = value; }
        }

        private AlgoParam _DesignValuePlus_Obj_Y_1;
        public AlgoParam DesignValuePlus_Obj_Y_1
        {
            get { return _DesignValuePlus_Obj_Y_1; }
            set { _DesignValuePlus_Obj_Y_1 = value; }
        }

        private AlgoParam _DesignValuePlus_Obj_Y_2;
        public AlgoParam DesignValuePlus_Obj_Y_2
        {
            get { return _DesignValuePlus_Obj_Y_2; }
            set { _DesignValuePlus_Obj_Y_2 = value; }
        }

        private AlgoParam _DesignValuePlus_Obj_Y_3;
        public AlgoParam DesignValuePlus_Obj_Y_3
        {
            get { return _DesignValuePlus_Obj_Y_3; }
            set { _DesignValuePlus_Obj_Y_3 = value; }
        }
        #endregion

        public Algo90DBendedLami_3P_TarObjModelParams()
        {
            LengthCenter_01_Object = new AlgoParam("LengthCenter_01_Object",  "mm",typeof(double), 0.0, "Object의 Pos0과 Pos1의 L-Check 중심치", -10.0, 10.0);
            LengthCenter_12_Object = new AlgoParam("LengthCenter_12_Object",  "mm",typeof(double), 0.0, "Object의 Pos1과 Pos2의 L-Check 중심치", -10.0, 10.0);
            LengthCenter_23_Object = new AlgoParam("LengthCenter_23_Object",  "mm",typeof(double), 0.0, "Object의 Pos2과 Pos3의 L-Check 중심치", -10.0, 10.0);
            LengthCenter_30_Object = new AlgoParam("LengthCenter_30_Object", "mm", typeof(double), 0.0, "Object의 Pos3과 Pos0의 L-Check 중심치", -10.0, 10.0);

            LengthRange_01_Object = new AlgoParam("LengthRange_01_Object",  "mm",typeof(double), 0.0, "Object의 Pos0과 Pos1의 L-Check (중심치에서의) +/- Spec", -10.0, 10.0);
            LengthRange_12_Object = new AlgoParam("LengthRange_12_Object",  "mm",typeof(double), 0.0, "Object의 Pos1과 Pos2의 L-Check (중심치에서의) +/- Spec", -10.0, 10.0);
            LengthRange_23_Object = new AlgoParam("LengthRange_23_Object",  "mm",typeof(double), 0.0, "Object의 Pos2과 Pos3의 L-Check (중심치에서의) +/- Spec", -10.0, 10.0);
            LengthRange_30_Object = new AlgoParam("LengthRange_30_Object", "mm", typeof(double), 0.0, "Object의 Pos3과 Pos0의 L-Check (중심치에서의) +/- Spec", -10.0, 10.0);

            LengthCenter_01_Target = new AlgoParam("LengthCenter_01_Target",  "mm",typeof(double), 0.0, "Target의 Pos0과 Pos1의 L-Check 중심치", -10.0, 10.0);
            LengthCenter_12_Target = new AlgoParam("LengthCenter_12_Target",  "mm",typeof(double), 0.0, "Target의 Pos1과 Pos2의 L-Check 중심치", -10.0, 10.0);
            LengthCenter_23_Target = new AlgoParam("LengthCenter_23_Target",  "mm",typeof(double), 0.0, "Target의 Pos2과 Pos3의 L-Check 중심치", -10.0, 10.0);
            LengthCenter_30_Target = new AlgoParam("LengthCenter_30_Target", "mm", typeof(double), 0.0, "Target의 Pos3과 Pos0의 L-Check 중심치", -10.0, 10.0);

            LengthRange_01_Target = new AlgoParam("LengthRange_01_Target",  "mm",typeof(double), 0.0, "Target의 Pos0과 Pos1의 L-Check (중심치에서의) +/- Spec", -10.0, 10.0);
            LengthRange_12_Target = new AlgoParam("LengthRange_12_Target",  "mm",typeof(double), 0.0, "Target의 Pos1과 Pos2의 L-Check (중심치에서의) +/- Spec", -10.0, 10.0);
            LengthRange_23_Target = new AlgoParam("LengthRange_23_Target",  "mm",typeof(double), 0.0, "Target의 Pos2과 Pos3의 L-Check (중심치에서의) +/- Spec", -10.0, 10.0);
            LengthRange_30_Target = new AlgoParam("LengthRange_30_Target", "mm", typeof(double), 0.0, "Target의 Pos3과 Pos0의 L-Check (중심치에서의) +/- Spec", -10.0, 10.0);


            DesignValuePlus_Obj_X_0 = new AlgoParam("DesignValuePlus_Obj_X_0",  "mm",typeof(double), 0.0, "mDesignValuePlus_Tar_X_0", -10.0, 10.0);
            DesignValuePlus_Obj_X_1 = new AlgoParam("DesignValuePlus_Obj_X_1",  "mm",typeof(double), 0.0, "mDesignValuePlus_Tar_X_1", -10.0, 10.0);
            DesignValuePlus_Obj_X_2 = new AlgoParam("DesignValuePlus_Obj_X_2",  "mm",typeof(double), 0.0, "mDesignValuePlus_Tar_X_2", -10.0, 10.0);
            DesignValuePlus_Obj_X_3 = new AlgoParam("DesignValuePlus_Obj_X_3", "mm", typeof(double), 0.0, "mDesignValuePlus_Tar_X_3", -10.0, 10.0);
                                                                     
            DesignValuePlus_Obj_Y_0 = new AlgoParam("DesignValuePlus_Obj_Y_0",  "mm",typeof(double), 0.0, "mDesignValuePlus_Tar_Y_0", -10.0, 10.0);
            DesignValuePlus_Obj_Y_1 = new AlgoParam("DesignValuePlus_Obj_Y_1",  "mm",typeof(double), 0.0, "mDesignValuePlus_Tar_Y_1", -10.0, 10.0);
            DesignValuePlus_Obj_Y_2 = new AlgoParam("DesignValuePlus_Obj_Y_2",  "mm",typeof(double), 0.0, "mDesignValuePlus_Tar_Y_2", -10.0, 10.0);
            DesignValuePlus_Obj_Y_3 = new AlgoParam("DesignValuePlus_Obj_Y_3", "mm", typeof(double), 0.0, "mDesignValuePlus_Tar_Y_3", -10.0, 10.0);
        }
    }
}
