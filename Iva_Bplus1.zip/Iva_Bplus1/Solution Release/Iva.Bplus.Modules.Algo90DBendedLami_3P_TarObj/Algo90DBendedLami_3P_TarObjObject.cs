﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_TarObj
{
    [SerializableAttribute]
    public partial class Algo90DBendedLami_3P_TarObjObject : AlgoObjectBase
    {
        #region [Fields]
        public bool UseTarget;
        public Dictionary<string, bool> errorCode;
        //public UseDesignValue UseDesignValue_tar;
        //public UseDesignValue UseDesignValue_obj;

        #region 제품 설계치에 대한 Off-Set (Obj == PNL)
        double sDesignValuePlus_Obj_X_0;
        double sDesignValuePlus_Obj_X_1;
        double sDesignValuePlus_Obj_X_2;
        double sDesignValuePlus_Obj_X_3;

        double sDesignValuePlus_Obj_Y_0;
        double sDesignValuePlus_Obj_Y_1;
        double sDesignValuePlus_Obj_Y_2;
        double sDesignValuePlus_Obj_Y_3;
        #endregion

        #region objPoint(PNL)0~2, tarPoint(OCA)1~3
        // ObjectPoint0~4(PNL)
        [field: NonSerialized]
        private MatchingRstData objPoint0;
        [field: NonSerialized]
        private MatchingRstData objPoint1;
        [field: NonSerialized]
        private MatchingRstData objPoint2;

        // TargetPoint1~3(OCA)
        [field: NonSerialized]
        private MatchingRstData tarPoint1;
        [field: NonSerialized]
        private MatchingRstData tarPoint2;
        [field: NonSerialized]
        private MatchingRstData tarPoint3;
        #endregion

        #region  tar,obj CalData Obj 0~2, Tar 1~4
        private string objCalData0;
        private string objCalData1;
        private string objCalData2;

        private string tarCalData1;
        private string tarCalData2;
        private string tarCalData3;
        #endregion

        #region calDataModObject0~2 / Target1~3
        private CalDataObject calDataModObject0;
        private CalDataObject calDataModObject1;
        private CalDataObject calDataModObject2;

        private CalDataObject calDataModTarget1;
        private CalDataObject calDataModTarget2;
        private CalDataObject calDataModTarget3;
        #endregion

        #region Length Check 데이터
        private double dTargetLength_01;
        private double dTargetLength_12;
        private double dTargetLength_23;
        private double dTargetLength_30;

        private double dObjectLength_01;
        private double dObjectLength_12;
        private double dObjectLength_23;
        private double dObjectLength_30;
        #endregion

        #region L-Check 데이터 판정
        public Dictionary<string, bool> Judgement_LCheck;
        #endregion

        private string lastResult;

        #region thetaCalType / useDesignValue
        private ThetaCalType thetaCalType;
        private UseDesignValue useDesignValue_obj;
        //private AxisDirection axisXDirection;
        //private AxisDirection axisYDirection;
        //private AxisDirection axisTDirection;

        //private AxisDirection calXDirection; // DesignValue를 넣을때(=Cal)의 좌표계 방향
        //private AxisDirection calYDirection;
        //private AxisDirection plcXDirection; // PLC(Cam or Cal Position)에서 던져주는 좌표계 방향
        //private AxisDirection plcYDirection;

        #endregion

        #region 각종 '좌표계' 계산 Field값
        // Result Data
        [field: NonSerialized]
        private Algo90DBendedLami_3P_TarObjResult algoRst;

        // Obj(PNL), Tar(OCA) Line Theta 
        public double[] tarLineTheta = new double[4];
        public double[] objLineTheta = new double[4];

        public XYT TarRevPos_TarObj = new XYT(); public XYT ObjRevPos_TarObj = new XYT();
        public XYT TarRevPos_Center = new XYT(); public XYT ObjRevPos_Center = new XYT();

        public XYT RevPos_TarObj = new XYT();
        public XYT RevPos_Center = new XYT();

        public XY[] tarfixPos = new XY[4];
        public XY[] objfixPos = new XY[4];

        public XY[] tarCoorPos = new XY[4];
        public XY[] objCoorPos = new XY[4];

        public bool l_Check_JudgeMent;
        public bool JudgeMent;
        #endregion
        #endregion

        #region [properties]
        public Algo90DBendedLami_3P_TarObjResult AlgoRst
        {
            get { return algoRst; }
            set
            {
                if (algoRst == value) return;
                algoRst = value;

                this.OnPropertyChanged(nameof(AlgoRst));
            }
        }

        #region 'Action'에서 가져 올 PLC, Vision Table Properties
        public Dictionary<string, IOStruct> M_dicVisionValues
        {
            get { return m_dicVisionValues; }
            set
            {
                if (m_dicVisionValues == value) return;
                m_dicVisionValues = value;

                OnPropertyChanged("M_dicVisionValues");
            }
        }
        #endregion

        #region tarPoint(OCA) 0~3 Properties
        public MatchingRstData TarPoint1
        {
            get { return tarPoint1; }
            set
            {
                if (tarPoint1 == value) return;
                tarPoint1 = value;

                OnPropertyChanged("TarPoint1");
            }
        }

        public MatchingRstData TarPoint2
        {
            get { return tarPoint2; }
            set
            {
                if (tarPoint2 == value) return;
                tarPoint2 = value;

                OnPropertyChanged("TarPoint2");
            }
        }

        public MatchingRstData TarPoint3
        {
            get { return tarPoint3; }
            set
            {
                if (tarPoint3 == value) return;
                tarPoint3 = value;

                OnPropertyChanged("TarPoint3");
            }
        }
        #endregion 

        #region objPoint0~2 Properties
        // Object X,Y,T(Panel)
        public MatchingRstData ObjPoint0
        {
            get { return objPoint0; }
            set
            {
                if (objPoint0 == value) return;
                objPoint0 = value;

                OnPropertyChanged("ObjPoint0");
            }
        }

        public MatchingRstData ObjPoint1
        {
            get { return objPoint1; }
            set
            {
                if (objPoint1 == value) return;
                objPoint1 = value;

                OnPropertyChanged("ObjPoint1");
            }
        }

        public MatchingRstData ObjPoint2
        {
            get { return objPoint2; }
            set
            {
                if (objPoint2 == value) return;
                objPoint2 = value;

                OnPropertyChanged("ObjPoint2");
            }
        }
        #endregion

        #region object CalData 0~2 Properties
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string PNL_2st_R
        {
            get
            {
                return objCalData0;
            }
            set
            {
                if (objCalData0 == value) return;
                objCalData0 = value;

                this.OnPropertyChanged("PNL_2st_R");

                calDataModObject0 = SystemObject_Common.GetObject(objCalData0) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string PNL_2st_L
        {
            get
            {
                return objCalData1;
            }
            set
            {
                if (objCalData1 == value) return;
                objCalData1 = value;

                this.OnPropertyChanged("PNL_2st_L");

                calDataModObject1 = SystemObject_Common.GetObject(objCalData1) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string PNL_1st_L
        {
            get
            {
                return objCalData2;
            }
            set
            {
                if (objCalData2 == value) return;
                objCalData2 = value;

                this.OnPropertyChanged("PNL_1st_L");

                calDataModObject2 = SystemObject_Common.GetObject(objCalData2) as CalDataObject;
            }
        }
        #endregion

        #region target CalData 1~3 Properties
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string OCA_2st_L
        {
            get
            {
                return tarCalData1;
            }
            set
            {
                if (tarCalData1 == value) return;
                tarCalData1 = value;

                this.OnPropertyChanged("OCA_2st_L");

                calDataModTarget1 = SystemObject_Common.GetObject(tarCalData1) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string OCA_1st_L
        {
            get
            {
                return tarCalData2;
            }
            set
            {
                if (tarCalData2 == value) return;
                tarCalData2 = value;

                this.OnPropertyChanged("OCA_1st_L");

                calDataModTarget2 = SystemObject_Common.GetObject(tarCalData2) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string OCA_1st_R
        {
            get
            {
                return tarCalData3;
            }
            set
            {
                if (tarCalData3 == value) return;
                tarCalData3 = value;

                this.OnPropertyChanged("OCA_1st_R");

                calDataModTarget3 = SystemObject_Common.GetObject(tarCalData3) as CalDataObject;
            }
        }
        #endregion

        #region ThetaCalType/ ErroCode / UseDesignValue  Properties
        public ThetaCalType ThetaCalType
        {
            get { return thetaCalType; }
            set
            {
                if (thetaCalType == value) return;

                thetaCalType = value;
                OnPropertyChanged("ThetaCalType");
            }
        }

        public UseDesignValue UseDesignValue_obj
        {
            get { return useDesignValue_obj; }
            set
            {
                if (useDesignValue_obj == value) return;

                useDesignValue_obj = value;
                OnPropertyChanged("UseDesignValue_obj");
            }
        }

        public Dictionary<string, bool> ErrorCode
        {
            get { return errorCode; }
            set
            {
                if (errorCode == value) return;

                errorCode = value;
                OnPropertyChanged("ErrorCode");
            }
        }
        #endregion
        #endregion

        #region [private method]
        #endregion

        #region [public method]
        public void SetInfomation()
        {
        }
        #endregion

        #region[Construct]

        public Algo90DBendedLami_3P_TarObjObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            CommObj = lst.Count != 0 ? lst[0] : "";
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            StartTimer();
            AlignType AlignMode = AlignType.Tar_Obj_3P;
            string[] AlignModeSplit = AlignMode.ToString().Split(new string[] { "_" }, StringSplitOptions.None);

            UseTarget = false;
            for (int cnt = 0; cnt < AlignModeSplit.Length; cnt++)
            {
                if (AlignModeSplit[cnt] == "Tar")
                {
                    UseTarget = true;
                }
            }
            int CntPos = int.Parse(Regex.Replace(AlignMode.ToString(), @"\D", ""));
            string model = SystemModel.GetCurModel();
            // Sub에서는'productID' Reading 안함

            Type type = typeof(Algo90DBendedLami_3P_TarObjObject);

            // (Debug용 Code)
            //----------------------------------------------------------------------
            tarPoint1 = new MatchingRstData(-2.0, 0.0, 0, 0, 0);
            tarPoint2 = new MatchingRstData(0.0, 2.0, 0, 0, 0);
            tarPoint3 = new MatchingRstData(2.0, 0.0, 0, 0, 0);

            objPoint0 = new MatchingRstData(0.0, -2.0, 0, 0, 0);
            objPoint1 = new MatchingRstData(-2.0, 0.0, 0, 0, 0);
            objPoint2 = new MatchingRstData(0.0, 2.0, 0, 0, 0);
            //----------------------------------------------------------------------

            // AlgoError 초기화
            errorCode = new Dictionary<string, bool>();
            InitDefinedError(ref errorCode);

            // 1-1> Obj/Tar 유,무 확인 + array 투입 
            MatchingRstData[] TargetPos = new MatchingRstData[4]; // OCA,   3_Point <- array에서 'Non_Use' Point는 비우거나, '0'으로 초기화 시킴!
            MatchingRstData[] ObjectPos = new MatchingRstData[4]; // Panel, 3_Point
            CntPos += 1; // <- 이건 가상(4Point) 사용하기 위한 트릭!
            if (PosConfirm(type, UseTarget, CntPos, ref TargetPos, ref ObjectPos, ref errorCode) == false) return false;

            // 1-2> Upload_FDC Data(Vision좌표계) + FDC 'Key'없음 Error 처리
            if (UploadFDCdata_Pos(AlignMode, UseTarget, TargetPos, ObjectPos, M_dicVisionValues, ref errorCode) == false) return false;
            
            // 2> CalData 유/무 확인 -> 내부 Data가 없으면 Error 처리 <- [고려] 앞 Module에서 처리 (있으면 주석 처리 하자!)
            object[] ObjCalData = new object[4];
            object[] TarCalData = new object[4];
            if (!CalDataConfirm(type, UseTarget, CntPos, ref ObjCalData, ref TarCalData, ref errorCode)) return false;

            // 3> ModelData Data 가져오기!
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo90DBendedLami_3P_TarObjModelParams;

            // 4-1> 'Vision 좌표계' 투입용. for 'GetV2R()' 매개변수 투입용, Object(PNL) / Target(OCA)     
            XY[] OCA_Pos = new XY[4];
            XY[] PNL_Pos = new XY[4];
            ArrayVisionPos(AlignMode, CntPos, UseTarget, TargetPos, ObjectPos, ref OCA_Pos, ref PNL_Pos);

            // 4-2> 'CurGrab Pos' 투입용?
            // [질문] 우선, PLC에서 받는 것을 어떻게 활용하는지 알고서 작성하자!            
            XY[] TarCurGrabPos = new XY[4];
            XY[] ObjCurGrabPos = new XY[4];
            Array.Clear(TarCurGrabPos, 0, TarCurGrabPos.Length);
            Array.Clear(TarCurGrabPos, 0, TarCurGrabPos.Length);

            for (int temp = 0; temp < TarCurGrabPos.Length; temp++)
            {
                TarCurGrabPos[temp] = new XY(0, 0);
                TarCurGrabPos[temp] = new XY(0, 0);
            }
            // (하기 ArrayCurGrabPos) 'method'는 PLC Key가 타 Chamber와 다르므로 활용하기 힘들듯...
            // ArrayCurGrabPos(AlignMode, CntPos, UseTarget, ref TarCurGrabPos, ref ObjCurGrabPos, m_dicPlcValues);

            #region 제품 DesignValue에 대한 Off-Set               
            double.TryParse(mParams.DesignValuePlus_Obj_X_0.Value.ToString(), out sDesignValuePlus_Obj_X_0);
            double.TryParse(mParams.DesignValuePlus_Obj_X_1.Value.ToString(), out sDesignValuePlus_Obj_X_1);
            double.TryParse(mParams.DesignValuePlus_Obj_X_2.Value.ToString(), out sDesignValuePlus_Obj_X_2);
            double.TryParse(mParams.DesignValuePlus_Obj_X_3.Value.ToString(), out sDesignValuePlus_Obj_X_3);

            double.TryParse(mParams.DesignValuePlus_Obj_Y_0.Value.ToString(), out sDesignValuePlus_Obj_Y_0);
            double.TryParse(mParams.DesignValuePlus_Obj_Y_1.Value.ToString(), out sDesignValuePlus_Obj_Y_1);
            double.TryParse(mParams.DesignValuePlus_Obj_Y_2.Value.ToString(), out sDesignValuePlus_Obj_Y_2);
            double.TryParse(mParams.DesignValuePlus_Obj_Y_3.Value.ToString(), out sDesignValuePlus_Obj_Y_3);
            #endregion

            // 5> CoorPos(+ FixPos 계산), Object(Panel) / Target(OCA)    
            XY[] TarDesignVal = new XY[4];
            XY[] ObjDesignVal = new XY[4];
            Array.Clear(TarDesignVal, 0, TarDesignVal.Length);
            Array.Clear(ObjDesignVal, 0, ObjDesignVal.Length);

            ArrayDesignValue(type, UseTarget, ref ObjDesignVal);

            if (!CalCoorPos(model, ref tarCoorPos, ref objCoorPos, OCA_Pos, PNL_Pos, ObjCurGrabPos, TarCurGrabPos)) 
            {
                errorCode["Err_obtain_CalPosition_Value"] = false;
                return false;
            }

            // L-Check 계산 시 Target에 대한 좌표 담는 것!
            XY[] tarCoorPos_tarobj = new XY[4];
            for(int cnt = 0; cnt < tarCoorPos_tarobj.Length; cnt++)
            {
                tarCoorPos_tarobj[cnt] = new XY(tarCoorPos[cnt].X, tarCoorPos[cnt].Y);
            }

            for (int temp = 0; temp < tarLineTheta.Length; temp++)
            {
                tarLineTheta[temp] = 0; objLineTheta[temp] = 0;
            }

            // DesignValue값 적용 (실제 Mark Position에서 적용)
            ThetaCalType tempCalType = ThetaCalType.UseShort_2L; // Panel은 '사다리꼴'로 무조건 단축으로 계산!
            if (UseDesignValue_obj == UseDesignValue.Use)
            {
                CalTheta(AlignMode, objCoorPos, ref objLineTheta); // object에 대한 theta 구현
                AddDisignValue(ObjDesignVal, objLineTheta, ref objCoorPos);
            }

            // 6> ***** Sub Lami에 대한 tarobj 계산 *****
            // 6-1> 각 '변'의 Theta성분 -----------------------------> PNL New Coor(설계치로 '직사각형' 만든 좌표)로 Theta 산출
            CalTheta(AlignMode, objCoorPos, ref objLineTheta); 
            CalTheta(AlignMode, tarCoorPos, ref tarLineTheta);

            // 6-2> Theta 성분 산출,  X(Left+), Y(Lower+), T(시계+)
            // 해당 Method에 OCA 뒤짚을 때의 부호 반대를 반영함.
            TarRevPos_TarObj = new XYT(0, 0, 0); // TarObj 사용(Sub Lami)
            ObjRevPos_TarObj = new XYT(0, 0, 0);
            CalRevTheta(AlignMode, ThetaCalType, objLineTheta, ref ObjRevPos_TarObj);
            CalRevTheta(AlignMode, tempCalType,  tarLineTheta, ref TarRevPos_TarObj);

            // CalRevTheta(AlignMode, ThetaCalType, tarLineTheta, objLineTheta, ref ObjRevPos_TarObj, ref TarRevPos_TarObj);

            // 6-3> X,Y 성분 산출
            CalRevXY(AlignMode, CntPos, tarCoorPos, objCoorPos, ref ObjRevPos_TarObj, ref TarRevPos_TarObj);

            // 6-4> Off-Set 계산, [Do] PLC에서 Off-Set 받아오는 것!
            XYT offset = new XYT(0, 0, 0);
            if (!GainOffSet(m_dicPlcValues, ref offset))
            {
                errorCode["Err_obtain_Offset_Value"] = false;
                return false;
            }

            // 6-5> Target(OCA)는 뒤짚기 전에 Target, Off-Set의 Y,T 반전 ---> '반전' OCA 특화
            TarRevPos_TarObj.Y *= -1; TarRevPos_TarObj.T *= -1;

            // 6-6> Off-set 반영, Target Pos 계산 -> OffSet 고려한 Target Pos 계산
            TarRevPos_TarObj = ApplyTargetOffset(TarRevPos_TarObj, offset);
            UploadFDCdata_tar(TarRevPos_TarObj, errorCode); // <- 이건 보자!

            // 6-7> RevT산출 
            RevPos_TarObj = new XYT();
            RevPos_TarObj.T = TarRevPos_TarObj.T - ObjRevPos_TarObj.T;

            // 6-8> DriftXY 산출
            double DriftX = Math.Cos(RevPos_TarObj.T) * ObjRevPos_TarObj.X - Math.Sin(RevPos_TarObj.T) * ObjRevPos_TarObj.Y;
            double DriftY = Math.Sin(RevPos_TarObj.T) * ObjRevPos_TarObj.X + Math.Cos(RevPos_TarObj.T) * ObjRevPos_TarObj.Y;

            // <6-9> 최종 RevPos산출, PI * rad = 180도, 1 rad = 180 / PI 
            RevPos_TarObj.X = ObjRevPos_TarObj.X - DriftX;
            RevPos_TarObj.Y = ObjRevPos_TarObj.Y - DriftY;
            RevPos_TarObj.T = NormalizeTheta(RevPos_TarObj.T / rad);

            UploadFDCdata_rev(RevPos_TarObj, errorCode);


            // 7> ***** Cam 대비 PNL의 CenterAlign 알고리즘 ******
            // (초기 받은 Coor부터 계산 시작 -> Why? 아니면 target coordinate를 만드는 method을 또 만들어야 함)
            UseTarget = false;
            XY[] Cam_Pos = new XY[4]; // Cam_Pos <- Cam 기준 '초기화'
            for (int temp = 0; temp < Cam_Pos.Length; temp++)
            {
                Cam_Pos[temp] = new XY();
            }

            if (!CalCoorPos(model, ref tarCoorPos, ref objCoorPos, Cam_Pos, PNL_Pos, ObjCurGrabPos, TarCurGrabPos)) 
            {
                errorCode["Err_obtain_CalPosition_Value"] = false;
                return false;
            }

            for (int temp = 0; temp < tarLineTheta.Length; temp++)
            {
                tarLineTheta[temp] = 0; objLineTheta[temp] = 0;
            }

            // DesignValue값 적용 
            if (UseDesignValue_obj == UseDesignValue.Use)
            {
                CalTheta(AlignMode, objCoorPos, ref objLineTheta); // object에 대한 theta 구현
                AddDisignValue(ObjDesignVal, objLineTheta, ref objCoorPos);
            }

            // 7-1> 각 '변'의 Theta성분 
            CalTheta(AlignMode, objCoorPos, ref objLineTheta);
            CalTheta(AlignMode, tarCoorPos, ref tarLineTheta);

            // 7-2> Theta 성분 산출,  X(Left+), Y(Lower+), T(시계+)
            ObjRevPos_Center = new XYT(0, 0, 0);
            TarRevPos_Center = new XYT(0, 0, 0);
            CalRevTheta(AlignMode, tempCalType, objLineTheta, ref ObjRevPos_Center);
            CalRevTheta(AlignMode, ThetaCalType, tarLineTheta, ref TarRevPos_Center);

            // 7-3> X,Y 성분 산출
            CalRevXY(AlignMode, CntPos, tarCoorPos, objCoorPos, ref ObjRevPos_Center, ref TarRevPos_Center);
            
            //[확인] Off-Set 계산 -> 3P CenterAlign은 OffSet 없이 Teaching으로 감!
            //offset = new XYT(0, 0, 0);
            //offset = CalTargetPos(POffsetXIO, POffsetYIO, POffsetTIO);

            // 7-4> Off-set 반영, Target Pos 계산 -> OffSet 고려한 Target Pos 계산
            TarRevPos_Center = ApplyTargetOffset(TarRevPos_Center, offset);

            // 7-5> RevT산출 
            RevPos_Center = new XYT();
            RevPos_Center.T = TarRevPos_Center.T - ObjRevPos_Center.T;

            // 7-6> DriftXY 산출
            DriftX = Math.Cos(RevPos_Center.T) * ObjRevPos_Center.X - Math.Sin(RevPos_Center.T) * ObjRevPos_Center.Y;
            DriftY = Math.Sin(RevPos_Center.T) * ObjRevPos_Center.X + Math.Cos(RevPos_Center.T) * ObjRevPos_Center.Y;

            // 7-7> 최종 RevPos산출, PI * rad = 180도, 1 rad = 180 / PI 
            // Tar(OCA) 기준 Stage가 Moving되므로 다시 빼줌 <- 재 확인 필요
            RevPos_Center.X = TarRevPos_Center.X - DriftX;
            RevPos_Center.Y = TarRevPos_Center.Y - DriftY;
            RevPos_Center.T = NormalizeTheta(RevPos_Center.T / rad); // - RevPos_TarObj.T); // <- Sub에서 Stage 움직인만큼 다시 보정??? (현장 확인 필요)
                                                                  
            // 8> [하기 Method 사용법] (Coordinate 좌표, 구하고자하는 길이의 각 포인트를 이름의 마지막에 넣음) <- ex) point0, point1과의 길이 xxxxx01
            Judgement_LCheck = new Dictionary<string, bool>();
            dTargetLength_01 = L_Check(tarCoorPos_tarobj, nameof(dTargetLength_01)); Judgement_LCheck[nameof(dTargetLength_01) + "_Judgement"] = true;
            dTargetLength_12 = L_Check(tarCoorPos_tarobj, nameof(dTargetLength_12)); Judgement_LCheck[nameof(dTargetLength_12) + "_Judgement"] = true;
            dTargetLength_23 = L_Check(tarCoorPos_tarobj, nameof(dTargetLength_23)); Judgement_LCheck[nameof(dTargetLength_23) + "_Judgement"] = true;
            dTargetLength_30 = L_Check(tarCoorPos_tarobj, nameof(dTargetLength_30)); Judgement_LCheck[nameof(dTargetLength_30) + "_Judgement"] = true;

            dObjectLength_01 = L_Check(objCoorPos, nameof(dObjectLength_01)); Judgement_LCheck[nameof(dObjectLength_01) + "_Judgement"] = true;
            dObjectLength_12 = L_Check(objCoorPos, nameof(dObjectLength_12)); Judgement_LCheck[nameof(dObjectLength_12) + "_Judgement"] = true;
            dObjectLength_23 = L_Check(objCoorPos, nameof(dObjectLength_23)); Judgement_LCheck[nameof(dObjectLength_23) + "_Judgement"] = true;
            dObjectLength_30 = L_Check(objCoorPos, nameof(dObjectLength_30)); Judgement_LCheck[nameof(dObjectLength_30) + "_Judgement"] = true;

            Type ModelParamType = typeof(Algo90DBendedLami_3P_TarObjModelParams);
           
            // 9> Target에 대한 L-Check 판정            
            if (!L_Check_Judgement(ModelParamType, model, nameof(dTargetLength_01), dTargetLength_01, Judgement_LCheck, errorCode)) return false;
            if (!L_Check_Judgement(ModelParamType, model, nameof(dTargetLength_12), dTargetLength_12, Judgement_LCheck, errorCode)) return false;
            if (!L_Check_Judgement(ModelParamType, model, nameof(dTargetLength_23), dTargetLength_23, Judgement_LCheck, errorCode)) return false;
            if (!L_Check_Judgement(ModelParamType, model, nameof(dTargetLength_30), dTargetLength_30, Judgement_LCheck, errorCode)) return false;


            // 10> Object에 대한 L-Check
            if (!L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_01), dObjectLength_01, Judgement_LCheck, errorCode)) return false;
            if (!L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_12), dObjectLength_23, Judgement_LCheck, errorCode)) return false;
            if (!L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_23), dObjectLength_23, Judgement_LCheck, errorCode)) return false;
            if (!L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_30), dObjectLength_30, Judgement_LCheck, errorCode)) return false;

            AlgoRst = new Algo90DBendedLami_3P_TarObjResult
            {
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                // ProductID = productID, -> Sub에서는 Non_Use

                // TarObj의 X,Y,T값 최종 결과 값
                RevX_TarObj = RevPos_TarObj.X,
                RevY_TarObj = RevPos_TarObj.Y,
                RevT_TarObj = RevPos_TarObj.T,

                // CenterAlign의 X,Y,T값 최종 결과 값
                RevX_Center = RevPos_Center.X,
                RevY_Center = RevPos_Center.Y,
                RevT_Center = RevPos_Center.T,

                // TarObj의 Tar/Obj Rev
                TarRevX_TarObj = TarRevPos_TarObj.X,
                TarRevY_TarObj = TarRevPos_TarObj.Y,
                TarRevT_TarObj = TarRevPos_TarObj.T,

                ObjRevX_TarObj = ObjRevPos_TarObj.X,
                ObjRevY_TarObj = ObjRevPos_TarObj.Y,
                ObjRevT_TarObj = ObjRevPos_TarObj.T,

                // TarObj의 각 성분의 Theta값 
                T01_TargetTheta = tarLineTheta[0],
                T23_TargetTheta = tarLineTheta[2],
                T12_TargetTheta = tarLineTheta[1],
                T03_TargetTheta = tarLineTheta[3],

                T01_ObjectTheta = objLineTheta[0],
                T23_ObjectTheta = objLineTheta[2],
                T12_ObjectTheta = objLineTheta[1],
                T03_ObjectTheta = objLineTheta[3],

                // TarObj의 L_Check 수치

                DTargetLength_01 = dTargetLength_01,
                DTargetLength_12 = dTargetLength_12,
                DTargetLength_23 = dTargetLength_23,
                DTargetLength_30 = dTargetLength_30,

                BTarget_LCheck_01 = Judgement_LCheck[nameof(dTargetLength_01) + "_Judgement"],
                BTarget_LCheck_12 = Judgement_LCheck[nameof(dTargetLength_12) + "_Judgement"],
                BTarget_LCheck_23 = Judgement_LCheck[nameof(dTargetLength_23) + "_Judgement"],
                BTarget_LCheck_30 = Judgement_LCheck[nameof(dTargetLength_30) + "_Judgement"],

                DObjectLength_01 = dObjectLength_01,
                DObjectLength_12 = dObjectLength_12,
                DObjectLength_23 = dObjectLength_23,
                DObjectLength_30 = dObjectLength_30,

                BObject_LCheck_01 = Judgement_LCheck[nameof(dObjectLength_01) + "_Judgement"],
                BObject_LCheck_12 = Judgement_LCheck[nameof(dObjectLength_12) + "_Judgement"],
                BObject_LCheck_23 = Judgement_LCheck[nameof(dObjectLength_23) + "_Judgement"],
                BObject_LCheck_30 = Judgement_LCheck[nameof(dObjectLength_30) + "_Judgement"],

                // PLC Off-Set값 
                OffsetX = offset.X,
                OffsetY = offset.Y,
                OffsetT = offset.T,

                //IsExistID = existID,
                IsJudgement = JudgeMent,
            };

            // Vision -> PLC Write
            m_dicVisionValues["TargetPosX"].NextValue = RevPos_TarObj.X;
            m_dicVisionValues["TargetPosY"].NextValue = RevPos_TarObj.Y;
            m_dicVisionValues["TargetPosT"].NextValue = RevPos_TarObj.T;

            m_dicVisionValues["TargetUnloadPosX"].NextValue = RevPos_Center.X;
            m_dicVisionValues["TargetUnloadPosY"].NextValue = RevPos_Center.Y;
            m_dicVisionValues["TargetUnloadPosT"].NextValue = RevPos_Center.T;

            StopTimer();

            return true;
        }

        public bool CalCoorPos(string model, ref XY[] tarCoorPos, ref XY[] objCoorPos,
                                XY[] TargetPos, XY[] ObjectPos, XY[] ObjCurGrabPos, XY[] TarCurGrabPos)
        {
            //[임시] tarCoorPos, objCoorPos 초기화
            Array.Clear(objCoorPos, 0, tarCoorPos.Length);
            Array.Clear(tarCoorPos, 0, tarCoorPos.Length);

            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                objfixPos[Pos] = new XY(); objCoorPos[Pos] = new XY();
                tarfixPos[Pos] = new XY(); tarCoorPos[Pos] = new XY();

                ObjCurGrabPos[Pos] = new XY(); // <-(임시 Code) 'CurPos'가 들어옴 지우자**********

                Type type = typeof(Algo90DBendedLami_3P_TarObjObject);
                FieldInfo[] fields = type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var field in fields)
                {
                    if (field.Name == ("calDataModObject" + Pos.ToString()) || field.Name == ("calDataModTarget" + Pos.ToString()))
                    {
                        string[] nameSplit = field.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = field.GetValue(this);

                        CalDataObject CalData = (CalDataObject)CalValue;

                        // *************** 임시 Debug Code ***************
                        //XY temp;
                        //temp = CalData.GetCameraPosition(model);
                        //temp = new XY(0, 0);// Test Code
                        // ***********************************************

                        switch (nameSplit[1])
                        {
                            case "Obj":  // Object(PNL)
                                if (CalData.GetCameraPosition(model) != null) // <- 실제 Code (지우지 말자!)
                                // ***** if (temp != null) // <- 임시 Code
                                {
                                    switch (Pos)
                                    {
                                        case 0:
                                        case 1:
                                            objfixPos[Pos].X = CalData.GetRotateCenter(model).X - (ObjCurGrabPos[Pos].X - CalData.GetCameraPosition(model).X);
                                            // objfixPos[Pos].X = CalData.GetRotateCenter(model).X - (ObjCurGrabPos[Pos].X - temp.X);
                                            objCoorPos[Pos].X = objfixPos[Pos].X + CalData.GetV2R(model, ObjectPos[Pos], true, true).X;

                                            objfixPos[Pos].Y = CalData.GetRotateCenter(model).Y - (ObjCurGrabPos[Pos].Y - CalData.GetCameraPosition(model).Y); // * (double)PlcYDirection);
                                            // objfixPos[Pos].Y = CalData.GetRotateCenter(model).Y - (ObjCurGrabPos[Pos].Y - temp.Y);
                                            objCoorPos[Pos].Y = objfixPos[Pos].Y + CalData.GetV2R(model, ObjectPos[Pos], true, true).Y;
                                            break;

                                        case 2:
                                        case 3:
                                            objfixPos[Pos].X = CalData.GetRotateCenter(model).X - (ObjCurGrabPos[Pos].X - CalData.GetCameraPosition(model).X);
                                            // objfixPos[Pos].X = CalData.GetRotateCenter(model).X - (ObjCurGrabPos[Pos].X - temp.X);
                                            objCoorPos[Pos].X = objfixPos[Pos].X + CalData.GetV2R(model, ObjectPos[Pos], true, true).X;

                                            objfixPos[Pos].Y = CalData.GetRotateCenter(model).Y - (CalData.GetCameraPosition(model).Y - ObjCurGrabPos[Pos].Y); // * (double)PlcYDirection);
                                            // objfixPos[Pos].Y = CalData.GetRotateCenter(model).Y - (temp.Y - ObjCurGrabPos[Pos].Y);
                                            objCoorPos[Pos].Y = objfixPos[Pos].Y + CalData.GetV2R(model, ObjectPos[Pos], true, true).Y;
                                            break;
                                    }
                                }
                                else
                                {
                                    errorCode["Err_Obtain_Camera_CalPos_Value"] = false;
                                    return false;
                                }
                                break;

                            case "Tar": // Target(OCA), (Debug용 Code)
                                if (CalData.GetCameraPosition(model) != null) // <- 실제 Code (지우지 말자!)
                                // if (temp != null) // <- 임시 Code
                                {
                                    switch (Pos)
                                    {
                                        case 0:
                                        case 1:
                                            tarfixPos[Pos].X = CalData.GetRotateCenter(model).X - (TarCurGrabPos[Pos].X - CalData.GetCameraPosition(model).X);
                                            // tarfixPos[Pos].X = CalData.GetRotateCenter(model).X - (TarCurGrabPos[Pos].X - temp.X);
                                            tarCoorPos[Pos].X = tarfixPos[Pos].X + CalData.GetV2R(model, TargetPos[Pos], true, true).X;

                                            tarfixPos[Pos].Y = CalData.GetRotateCenter(model).Y - (TarCurGrabPos[Pos].Y - CalData.GetCameraPosition(model).Y); // * (double)PlcYDirection);
                                            // tarfixPos[Pos].Y = CalData.GetRotateCenter(model).Y - (TarCurGrabPos[Pos].Y - temp.Y);
                                            tarCoorPos[Pos].Y = tarfixPos[Pos].Y + CalData.GetV2R(model, TargetPos[Pos], true, true).Y;
                                            break;

                                        case 2:
                                        case 3:
                                            // tarfixPos[Pos].X = CalData.GetRotateCenter(model).X - (TarCurGrabPos[Pos].X - temp.X);
                                            tarfixPos[Pos].X = CalData.GetRotateCenter(model).X - (TarCurGrabPos[Pos].X - CalData.GetCameraPosition(model).X);
                                            tarCoorPos[Pos].X = tarfixPos[Pos].X + CalData.GetV2R(model, TargetPos[Pos], true, true).X;

                                            tarfixPos[Pos].Y = CalData.GetRotateCenter(model).Y - (CalData.GetCameraPosition(model).Y - TarCurGrabPos[Pos].Y); // * (double)PlcYDirection);
                                            // tarfixPos[Pos].Y = CalData.GetRotateCenter(model).Y - (temp.Y - TarCurGrabPos[Pos].Y);
                                            tarCoorPos[Pos].Y = tarfixPos[Pos].Y + CalData.GetV2R(model, TargetPos[Pos], true, true).Y;
                                            break;
                                    }
                                }
                                else
                                {
                                    errorCode["Err_Obtain_Camera_CalPos_Value"] = false;
                                    return false;
                                }
                                break;
                        }
                    }
                }
            }
            objCoorPos[3] = objCoorPos[0] + objCoorPos[2] - objCoorPos[1];
            tarCoorPos[0] = tarCoorPos[1] + tarCoorPos[3] - tarCoorPos[2];
            return true;
        }


        public void CalCoorPos(string model, ref XY[] tarCoorPos, ref XY[] objCoorPos,
                               XY[] TargetPos, XY[] ObjectPos, XY[] ObjCurGrabPos, XY[] ObjCalPos, XY[] TarCurGrabPos, XY[] TarCalPos, XY[] TarDesignVal, XY[] ObjDesignVal)
        {
            //[임시] tarCoorPos, objCoorPos 초기화
            Array.Clear(objCoorPos, 0, tarCoorPos.Length); Array.Clear(tarCoorPos, 0, tarCoorPos.Length);

            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                Type type = typeof(Algo90DBendedLami_3P_TarObjObject);
                FieldInfo[] fields = type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var field in fields)
                {
                    if (field.Name == ("calDataModObject" + Pos.ToString()) || field.Name == ("calDataModTarget" + Pos.ToString()))
                    {
                        string[] nameSplit = field.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = field.GetValue(this);

                        CalDataObject CalData = (CalDataObject)CalValue;

                        switch (nameSplit[1])
                        {
                            case "Obj":  // Object(Panel, 하부)
                                if (Pos != 3 && CalData != null)
                                {
                                    // (Cal, CurGrab)Pos 고려한 FixPos 계산
                                    objfixPos[Pos] = CalData.GetRotateCenter(model) - ObjCurGrabPos[Pos] + ObjCalPos[Pos];
                                    // 자재 Design 설계치 삽입
                                    objCoorPos[Pos] = objfixPos[Pos] + CalData.GetV2R(model, ObjectPos[Pos], true, true) + ObjDesignVal[Pos]; 
                                }
                                else if (Pos == 3 && CalData != null)
                                {
                                    // Obj의 Object3는 미 사용하므로... 
                                }
                                else
                                {
                                    // [Do] Error 처리
                                }
                                break;

                            case "Tar": // Target(OCA, 상부)
                                if (CalData != null)
                                {
                                    // (Cal, CurGrab)Pos 고려한 FixPos 계산
                                    tarfixPos[Pos] = CalData.GetRotateCenter(model) - TarCurGrabPos[Pos] + TarCalPos[Pos];
                                    // 자재 Design 설계치 삽입
                                    tarCoorPos[Pos] = tarfixPos[Pos] + CalData.GetV2R(model, TargetPos[Pos], true, true) + TarDesignVal[Pos]; 
                                }
                                else
                                {
                                    // [Do] Error 처리
                                }
                                break;
                        }
                    }
                }
            }
            objCoorPos[3] = objCoorPos[0] + objCoorPos[2] - objCoorPos[1];
        }

        public override void DefaultIOSet()
        {
            //PSourceID = "SourceID";
            //POffsetX = "Offset_1";
            //POffsetY = "Offset_2";
            //POffsetT = "Offset_3";
            //VResultReply = "AlignRst";
            //VRevOffsetX = "RevX";
            //VRevOffsetY = "RevY";
            //VRevOffsetT = "RevT";
            //m_dicPlcValues = new Dictionary<string, IOStruct>();
            // m_dicVisionValues = new Dictionary<string, IOStruct>();

            base.DefaultIOSet();

            // 해당 하는 io를 가져온다.
            //PlcIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();
            //VisionIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();

            m_dicPlcValues.Clear();
            m_dicVisionValues.Clear();


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    PlcIOs.Add(item);
                    if (m_dicPlcValues.ContainsKey(item.Key) == true) { } // 중복된 Key 있으면 Skip
                    else
                    {
                        m_dicPlcValues.Add(item.Key, item);
                    }
                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    VisionIOs.Add(item);
                    if(m_dicVisionValues.ContainsKey(item.Key) == true) { } // 중복된 Key 있으면 Skip
                    else
                    {
                        m_dicVisionValues.Add(item.Key, item);
                    }
                }
            }
        }


        public override void ObjectInitialize()
        {
            base.ObjectInitialize();
            //m_dicPlcValues = new Dictionary<string, IOStruct>();
            //m_dicVisionValues = new Dictionary<string, IOStruct>();

            if (AlignTableObject == null) return;

            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    if (!m_dicPlcValues.ContainsKey(item.Key))
                    {
                        m_dicPlcValues.Add(item.Key, item);
                    }
                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    if (!m_dicVisionValues.ContainsKey(item.Key))
                    {
                        m_dicVisionValues.Add(item.Key, item);
                    }
                }
            }
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void ObjectUpdate()
        {
            base.ObjectUpdate();

            PlcIOsListConverter.Module = CommObj;
            VisionIOsListConverter.Module = CommObj;
        }
        #endregion
    }
}

