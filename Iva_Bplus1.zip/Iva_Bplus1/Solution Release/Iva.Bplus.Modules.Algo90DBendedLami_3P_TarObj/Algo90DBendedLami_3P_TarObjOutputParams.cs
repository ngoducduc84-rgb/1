﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_TarObj
{
    class Algo90DBendedLami_3P_TarObjOutputParams : OutputParams
    {
        public object LogResult { get; set; }
    }
}
