﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_TarObj
{
    public class Algo90DBendedLami_3P_TarObjResult : ViewModelBase
    {
        private string curDate;
        private string curTime;
        // private string productID;

        private double revX_TarObj;
        private double revY_TarObj;
        private double revT_TarObj;

        private double revX_Center;
        private double revY_Center;
        private double revT_Center;

        private double tarRevX_TarObj;
        private double tarRevY_TarObj;
        private double tarRevT_TarObj;

        private double objRevX_TarObj;
        private double objRevY_TarObj;
        private double objRevT_TarObj;

        private double t01_TargetTheta;
        private double t23_TargetTheta;
        private double t01_ObjectTheta;
        private double t23_ObjectTheta;

        private double t12_TargetTheta;
        private double t03_TargetTheta;
        private double t12_ObjectTheta;
        private double t03_ObjectTheta;

        private double dTargetLength_01;
        private double dTargetLength_12;
        private double dTargetLength_23;
        private double dTargetLength_30;

        private bool bTarget_LCheck_01;
        private bool bTarget_LCheck_12;
        private bool bTarget_LCheck_23;
        private bool bTarget_LCheck_30;

        private double dObjectLength_01;
        private double dObjectLength_12;
        private double dObjectLength_23;
        private double dObjectLength_30;

        private bool bObject_LCheck_01;
        private bool bObject_LCheck_12;
        private bool bObject_LCheck_23;
        private bool bObject_LCheck_30;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        //private double modelX;
        //private double modelY;

        //private double productPosX;
        //private double productPosY;
        //private double productPosT;

        //private double revOffsetX;
        //private double revOffsetY;
        //private double revOffsetT;

        //private double target_PosX;
        //private double target_PosY;
        //private double target_PosT;

        //private double object_PosX;
        //private double object_PosY;
        //private double object_PosT;

        private bool isExistID;
        private bool isJudgement;


        public string CurDate
        {
            get { return curDate; }
            set
            {
                if (value == curDate) return;
                curDate = value;
                OnPropertyChanged("CurDate");
            }
        }

        public string CurTime
        {
            get { return curTime; }
            set
            {
                if (value == curTime) return;
                curTime = value;
                OnPropertyChanged("CurTime");
            }
        }

        #region 각 성분의 Theta값
        public double T01_TargetTheta
        {
            get { return t01_TargetTheta; }
            set
            {
                if (value == t01_TargetTheta) return;
                t01_TargetTheta = value;
                this.OnPropertyChanged(nameof(T01_TargetTheta));
            }
        }

        public double T23_TargetTheta
        {
            get { return t23_TargetTheta; }
            set
            {
                if (value == t23_TargetTheta) return;
                t23_TargetTheta = value;
                this.OnPropertyChanged(nameof(T23_TargetTheta));
            }
        }

        public double T12_TargetTheta
        {
            get { return t12_TargetTheta; }
            set
            {
                if (value == t12_TargetTheta) return;
                t12_TargetTheta = value;
                this.OnPropertyChanged(nameof(T12_TargetTheta));
            }
        }

        public double T03_TargetTheta
        {
            get { return t03_TargetTheta; }
            set
            {
                if (value == t03_TargetTheta) return;
                t03_TargetTheta = value;
                this.OnPropertyChanged(nameof(T03_TargetTheta));
            }
        }
        public double T01_ObjectTheta
        {
            get { return t01_ObjectTheta; }
            set
            {
                if (value == t01_ObjectTheta) return;
                t01_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T01_ObjectTheta));
            }
        }

        public double T23_ObjectTheta
        {
            get { return t23_ObjectTheta; }
            set
            {
                if (value == t23_ObjectTheta) return;
                t23_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T23_ObjectTheta));
            }
        }

        public double T12_ObjectTheta
        {
            get { return t12_ObjectTheta; }
            set
            {
                if (value == t12_ObjectTheta) return;
                t12_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T12_ObjectTheta));
            }
        }

        public double T03_ObjectTheta
        {
            get { return t03_ObjectTheta; }
            set
            {
                if (value == t03_ObjectTheta) return;
                t03_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T03_ObjectTheta));
            }
        }
        #endregion

        #region L_Check 관련 
        public double DTargetLength_01
        {
            get { return dTargetLength_01; }
            set
            {
                if (value == dTargetLength_01) return;
                dTargetLength_01 = value;
                this.OnPropertyChanged(nameof(DTargetLength_01));
            }
        }
        public double DTargetLength_12
        {
            get { return dTargetLength_12; }
            set
            {
                if (value == dTargetLength_12) return;
                dTargetLength_12 = value;
                this.OnPropertyChanged(nameof(DTargetLength_12));
            }
        }

        public double DTargetLength_23
        {
            get { return dTargetLength_23; }
            set
            {
                if (value == dTargetLength_23) return;
                dTargetLength_23 = value;
                this.OnPropertyChanged(nameof(DTargetLength_23));
            }
        }

        public double DTargetLength_30
        {
            get { return dTargetLength_30; }
            set
            {
                if (value == dTargetLength_30) return;
                dTargetLength_30 = value;
                this.OnPropertyChanged(nameof(DTargetLength_30));
            }
        }

        public bool BTarget_LCheck_01
        {
            get { return bTarget_LCheck_01; }
            set
            {
                if (value == bTarget_LCheck_01) return;
                bTarget_LCheck_01 = value;
                this.OnPropertyChanged(nameof(BTarget_LCheck_01));
            }
        }

        public bool BTarget_LCheck_12
        {
            get { return bTarget_LCheck_12; }
            set
            {
                if (value == bTarget_LCheck_12) return;
                bTarget_LCheck_12 = value;
                this.OnPropertyChanged(nameof(BTarget_LCheck_12));
            }
        }

        public bool BTarget_LCheck_23
        {
            get { return bTarget_LCheck_23; }
            set
            {
                if (value == bTarget_LCheck_23) return;
                bTarget_LCheck_23 = value;
                this.OnPropertyChanged(nameof(BTarget_LCheck_23));
            }
        }

        public bool BTarget_LCheck_30
        {
            get { return bTarget_LCheck_30; }
            set
            {
                if (value == bTarget_LCheck_30) return;
                bTarget_LCheck_30 = value;
                this.OnPropertyChanged(nameof(BTarget_LCheck_30));
            }
        }

        public double DObjectLength_01
        {
            get { return dObjectLength_01; }
            set
            {
                if (value == dObjectLength_01) return;
                dObjectLength_01 = value;
                this.OnPropertyChanged(nameof(DObjectLength_01));
            }
        }
        public double DObjectLength_12
        {
            get { return dObjectLength_12; }
            set
            {
                if (value == dObjectLength_12) return;
                dObjectLength_12 = value;
                this.OnPropertyChanged(nameof(DObjectLength_12));
            }
        }

        public double DObjectLength_23
        {
            get { return dObjectLength_23; }
            set
            {
                if (value == dObjectLength_23) return;
                dObjectLength_23 = value;
                this.OnPropertyChanged(nameof(DObjectLength_23));
            }
        }

        public double DObjectLength_30
        {
            get { return dObjectLength_30; }
            set
            {
                if (value == dObjectLength_30) return;
                dObjectLength_30 = value;
                this.OnPropertyChanged(nameof(DObjectLength_30));
            }
        }

        public bool BObject_LCheck_01
        {
            get { return bObject_LCheck_01; }
            set
            {
                if (value == bObject_LCheck_01) return;
                bObject_LCheck_01 = value;
                this.OnPropertyChanged(nameof(BObject_LCheck_01));
            }
        }

        public bool BObject_LCheck_12
        {
            get { return bObject_LCheck_12; }
            set
            {
                if (value == bObject_LCheck_12) return;
                bObject_LCheck_12 = value;
                this.OnPropertyChanged(nameof(BObject_LCheck_12));
            }
        }

        public bool BObject_LCheck_23
        {
            get { return bObject_LCheck_23; }
            set
            {
                if (value == bObject_LCheck_23) return;
                bObject_LCheck_23 = value;
                this.OnPropertyChanged(nameof(BObject_LCheck_23));
            }
        }

        public bool BObject_LCheck_30
        {
            get { return bObject_LCheck_30; }
            set
            {
                if (value == bObject_LCheck_30) return;
                bObject_LCheck_30 = value;
                this.OnPropertyChanged(nameof(BObject_LCheck_30));
            }
        }
        #endregion

        #region off-set
        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                if (value == offsetX) return;
                offsetX = value;

                OnPropertyChanged("OffsetX");
            }
        }

        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                if (value == offsetY) return;
                offsetY = value;

                OnPropertyChanged("OffsetY");
            }
        }

        public double OffsetT
        {
            get { return offsetT; }
            set
            {
                if (value == offsetT) return;
                offsetT = value;

                OnPropertyChanged("OffsetT");
            }
        }
        #endregion

        #region Rev_TarObj
        public double RevX_TarObj
        {
            get { return Math.Round(revX_TarObj, 3); }
            set
            {
                if (value == revX_TarObj) return;
                revX_TarObj = value;
                OnPropertyChanged(nameof(RevX_TarObj));
            }
        }

        public double RevY_TarObj
        {
            get { return Math.Round(revY_TarObj, 3); }
            set
            {
                if (value == revY_TarObj) return;
                revY_TarObj = value;
                OnPropertyChanged(nameof(RevY_TarObj));
            }
        }

        public double RevT_TarObj
        {
            get { return Math.Round(revT_TarObj, 3); }
            set
            {
                if (value == revT_TarObj) return;
                revT_TarObj = value;

                OnPropertyChanged(nameof(RevT_TarObj));
            }
        }
        #endregion

        #region Rev_Center
        public double RevX_Center
        {
            get { return Math.Round(revX_Center, 3); }
            set
            {
                if (value == revX_Center) return;
                revX_Center = value;
                OnPropertyChanged(nameof(RevX_Center));
            }
        }

        public double RevY_Center
        {
            get { return Math.Round(revY_Center, 3); }
            set
            {
                if (value == revY_Center) return;
                revY_Center = value;
                OnPropertyChanged(nameof(RevY_Center));
            }
        }

        public double RevT_Center
        {
            get { return Math.Round(revT_Center, 3); }
            set
            {
                if (value == revT_Center) return;
                revT_Center = value;

                OnPropertyChanged(nameof(RevT_Center));
            }
        }
        #endregion

        #region tarRev_TarObj
        public double TarRevX_TarObj
        {
            get { return Math.Round(tarRevX_TarObj, 3); }
            set
            {
                if (value == tarRevX_TarObj) return;
                tarRevX_TarObj = value;
                OnPropertyChanged(nameof(TarRevX_TarObj));
            }
        }

        public double TarRevY_TarObj
        {
            get { return Math.Round(tarRevY_TarObj, 3); }
            set
            {
                if (value == tarRevY_TarObj) return;
                tarRevY_TarObj = value;
                OnPropertyChanged(nameof(TarRevY_TarObj));
            }
        }

        public double TarRevT_TarObj
        {
            get { return Math.Round(tarRevT_TarObj, 3); }
            set
            {
                if (value == tarRevT_TarObj) return;
                tarRevT_TarObj = value;
                OnPropertyChanged(nameof(TarRevT_TarObj));
            }
        }
        #endregion

        #region objRev_TarObj
        public double ObjRevX_TarObj
        {
            get { return Math.Round(objRevX_TarObj, 3); }
            set
            {
                if (value == objRevX_TarObj) return;
                objRevX_TarObj = value;
                OnPropertyChanged(nameof(ObjRevX_TarObj));
            }
        }

        public double ObjRevY_TarObj
        {
            get { return Math.Round(objRevY_TarObj, 3); }
            set
            {
                if (value == objRevY_TarObj) return;
                objRevY_TarObj = value;
                OnPropertyChanged(nameof(ObjRevY_TarObj));
            }
        }

        public double ObjRevT_TarObj
        {
            get { return Math.Round(objRevT_TarObj, 3); }
            set
            {
                if (value == objRevT_TarObj) return;
                objRevT_TarObj = value;
                OnPropertyChanged(nameof(ObjRevT_TarObj));
            }
        }
        #endregion

        #region 짬
        //public double Target_PosX
        //{
        //    get { return target_PosX; }
        //    set
        //    {
        //        if (value == target_PosX) return;
        //        target_PosX = value;
        //        this.OnPropertyChanged(nameof(Target_PosX));
        //    }
        //}

        //public double Target_PosY
        //{
        //    get { return target_PosY; }
        //    set
        //    {
        //        if (value == target_PosY) return;
        //        target_PosY = value;
        //        this.OnPropertyChanged(nameof(Target_PosY));
        //    }
        //}

        //public double Target_PosT
        //{
        //    get { return target_PosT; }
        //    set
        //    {
        //        if (value == target_PosT) return;
        //        target_PosT = value;
        //        this.OnPropertyChanged(nameof(target_PosT));
        //    }
        //}

        //public double Object_PosX
        //{
        //    get { return object_PosX; }
        //    set
        //    {
        //        if (value == object_PosX) return;
        //        object_PosX = value;
        //        this.OnPropertyChanged(nameof(Object_PosX));
        //    }
        //}

        //public double Object_PosY
        //{
        //    get { return object_PosY; }
        //    set
        //    {
        //        if (value == object_PosY) return;
        //        object_PosY = value;
        //        this.OnPropertyChanged(nameof(Object_PosY));
        //    }
        //}

        //public double Object_PosT
        //{
        //    get { return object_PosT; }
        //    set
        //    {
        //        if (value == object_PosT) return;
        //        object_PosT = value;
        //        this.OnPropertyChanged(nameof(Object_PosT));
        //    }
        //}


        //public double ProductPosX
        //{
        //    get { return productPosX; }
        //    set
        //    {
        //        if (value == productPosX) return;
        //        productPosX = value;

        //        OnPropertyChanged("ProductPosX");
        //    }
        //}

        //public double ProductPosY
        //{
        //    get { return productPosY; }
        //    set
        //    {
        //        if (value == productPosY) return;
        //        productPosY = value;

        //        OnPropertyChanged("ProductPosY");
        //    }
        //}

        //public double ProductPosT
        //{
        //    get { return productPosT; }
        //    set
        //    {
        //        if (value == productPosT) return;
        //        productPosT = value;

        //        OnPropertyChanged("ProductPosT");
        //    }
        //}
        #endregion

        #region 짬
        //public double RevOffsetX
        //{
        //    get { return revOffsetX; }
        //    set
        //    {
        //        if (value == revOffsetX) return;
        //        revOffsetX = value;
        //        this.OnPropertyChanged(nameof(RevOffsetX));
        //    }
        //}

        //public double RevOffsetY
        //{
        //    get { return revOffsetY; }
        //    set
        //    {
        //        if (value == revOffsetY) return;
        //        revOffsetY = value;
        //        this.OnPropertyChanged(nameof(RevOffsetY));
        //    }
        //}

        //public double RevOffsetT
        //{
        //    get { return revOffsetT; }
        //    set
        //    {
        //        if (value == revOffsetT) return;
        //        revOffsetT = value;
        //        this.OnPropertyChanged(nameof(RevOffsetT));
        //    }
        //}

        //public string ProductID
        //{
        //    get { return productID; }
        //    set
        //    {
        //        if (value == productID) return;
        //        productID = value;
        //        OnPropertyChanged("ProduectID");
        //    }
        //}
        #endregion
        public bool IsExistID
        {
            get { return isExistID; }
            set
            {
                if (value == isExistID) return;
                isExistID = value;

                OnPropertyChanged("IsExistID");
            }
        }

        public bool IsJudgement
        {
            get { return isJudgement; }
            set
            {
                if (value == isJudgement) return;
                isJudgement = value;

                OnPropertyChanged("IsJudgement");
            }
        }


        public Algo90DBendedLami_3P_TarObjResult()
        {
        }

        #region [Properties]   
        #endregion

        public override string ToString()
        {
            return string.Format("{0} :\n " +
                                  "curDate: {1}\n, " +
                                  "curTime: {2}\n," +

                                  "RevX_TarObj: {3}\n," +
                                  "RevY_TarObj: {4}\n," +
                                  "RevT_TarObj: {5}\n," +

                                  "RevX_Center: {6}\n," +
                                  "RevY_Center: {7}\n," +
                                  "RevT_Center: {8}\n," +

                                  "TarRevX_TarObj: {9}\n," +
                                  "TarRevY_TarObj: {10}\n," +
                                  "TarRevT_TarObj: {11}\n," +

                                  "ObjRevX_TarObj: {12}\n," +
                                  "ObjRevY_TarObj: {13}\n," +
                                  "ObjRevT_TarObj: {14}\n," +

                                  "T01_TargetTheta : {15}\n," +
                                  "T23_TargetTheta : {16}\n" +
                                  "T12_TargetTheta : {17}\n," +
                                  "T03_TargetTheta : {18}\n" +

                                  "T01_ObjectTheta  : {19}\n," +
                                  "T23_ObjectTheta  : {20}\n" +
                                  "T12_ObjectTheta  : {21}\n," +
                                  "T03_ObjectTheta  : {22}\n" +

                                  "DTargetLength_01  : {22}\n," +
                                  "DTargetLength_12  : {23}\n" +
                                  "DTargetLength_23  : {24}\n," +
                                  "DTargetLength_03  : {25}\n" +

                                  "BTarget_LCheck_01   : {26}\n," +
                                  "BTarget_LCheck_12   : {27}\n" +
                                  "BTarget_LCheck_23   : {28}\n," +
                                  "BTarget_LCheck_03   : {29}\n" +

                                  "DObjectLength_01   : {30}\n," +
                                  "DObjectLength_12   : {31}\n" +
                                  "DObjectLength_23   : {32}\n," +
                                  "DObjectLength_03   : {33}\n" +

                                  "BObject_LCheck_01    : {34}\n," +
                                  "BObject_LCheck_12    : {35}\n" +
                                  "BObject_LCheck_23    : {36}\n," +
                                  "BObject_LCheck_03    : {37}\n" +

                                  "offsetX: {38}\n" +
                                  "offsetY: {39}\n" +
                                  "offsetT: {40}\n" +

                                  // "isExistID: {39}\n" +
                                  "isJudgement: {41}\n"
                                  , typeof(Algo90DBendedLami_3P_TarObjResult).ToString()
                                  , curTime
                                  , curDate
                                  //, productID

                                  , revX_TarObj
                                  , revY_TarObj
                                  , revT_TarObj

                                  , revX_Center
                                  , revY_Center
                                  , revT_Center

                                  , tarRevX_TarObj
                                  , tarRevY_TarObj
                                  , tarRevT_TarObj
                             
                                  , objRevX_TarObj
                                  , objRevY_TarObj
                                  , objRevT_TarObj

                                  , t01_TargetTheta
                                  , t23_TargetTheta
                                  , t12_TargetTheta
                                  , t03_TargetTheta

                                  , t01_ObjectTheta
                                  , t23_ObjectTheta
                                  , t12_ObjectTheta
                                  , t03_ObjectTheta

                                  , dTargetLength_01
                                  , dTargetLength_12
                                  , dTargetLength_23
                                  , dTargetLength_30

                                  , bTarget_LCheck_01
                                  , bTarget_LCheck_12
                                  , bTarget_LCheck_23
                                  , bTarget_LCheck_30

                                  , dObjectLength_01
                                  , dObjectLength_12
                                  , dObjectLength_23
                                  , dObjectLength_30

                                  , bObject_LCheck_01
                                  , bObject_LCheck_12
                                  , bObject_LCheck_23
                                  , bObject_LCheck_30

                                  , offsetX
                                  , offsetY
                                  , offsetT

                                  // , isExistID
                                  , isJudgement


                                  );
        }
    }
}
