﻿using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo90DBendedLami_3P_TarObj
{
    public partial class Algo90DBendedLami_3P_TarObjAction
    {
        #region [Construct]
        #endregion

        #region [Error Script] Algo90DBendedLami_4P_TarObj: 15401 ~ 15500
        static public int Err_Failed_To_Obtain_Coordinate_Value = 015401; public string E15401_Failed_To_Obtain_Coordinate_Value = "Failed to obtain Coordinate value.";
        static public int Err_Failed_To_Upload_VisionPos_Value = 015402; public string E15402__Failed_To_Upload_VisionPos_Value = "Failed to upload FDC VisionPos_Value.";
        static public int Err_Failed_To_Upload_FDC_Data_Pos = 015403; public string E15403_Failed_To_Upload_FDC_Data_Pos = "Failed to upload FDC Data value(position).";
        static public int Err_Failed_To_Upload_FDC_Data_L_Check = 015404; public string E15404_Failed_To_Upload_FDC_Data_LCheck = "Failed to upload L_Check Data value.";
        static public int Err_Failed_To_Upload_FDC_Data_TarRevPos = 015405; public string E15405_Failed_To_Upload_FDC_Data_TarRevPos = "Failed to upload L_Check Data value.";
        static public int Err_Failed_To_Upload_FDC_Data_RevPos = 015406; public string E15406_Failed_To_Upload_FDC_Data_RevPos = "Failed to upload L_Check Data value.";
        static public int Err_Failed_To_Obtain_VisionPos_Value = 015407; public string E15407_Failed_To_Obtain_VisionPos_Value = "Failed to obtain VisionPos value.";
        static public int Err_Failed_To_Obtain_CalData_Value = 015408; public string E15408_Failed_To_Obtain_CalData_Value = "Failed to obtain CalData value.";
        static public int Err_Failed_To_Obtain_CalPos_Value = 015409; public string E15409_Failed_To_Obtain_CalPosition_Value = "Failed to obtain CalData value.";
        static public int Err_Failed_To_Obtain_CurPos_Value = 015410; public string E15410_Failed_To_Obtain_CurPosition_Value = "Failed to obtain CurData value.";
        static public int Err_Failed_To_Obtain_Offset_Value = 015411; public string E15411_Failed_To_Obtain_Offset_Value = "Failed to obtain CurData value.";
        static public int Err_Failed_To_Obtain_LCheck_Spec_Out = 015412; public string E15412_Failed_To_Obtain_Offset_Value = "Failed to obtain LCheck Spec In value.";
        static public int Err_Obtain_Camera_CalPos_Value = 015413; public string E15413_Obtain_Camera_CalPos_Value = "Failed to obtain Camera CalPos Value.";

        public override void ErrorDefine()
        {
            base.ErrorDefine();
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Obtain_Coordinate_Value, ErrorType.ErrorStop, E15401_Failed_To_Obtain_Coordinate_Value, "각 Coordinate 좌표의 값을 읽어오는데 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Upload_VisionPos_Value, ErrorType.ErrorStop, E15402__Failed_To_Upload_VisionPos_Value, "각 FDC VisionPos를 업로드하는데 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Upload_FDC_Data_Pos, ErrorType.Warning, E15403_Failed_To_Upload_FDC_Data_Pos, "각 Position에 대한 FDC 데이터 업로드에 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Upload_FDC_Data_L_Check, ErrorType.Warning, E15404_Failed_To_Upload_FDC_Data_LCheck, "각 L_Check 대한 FDC 데이터 업로드에 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Upload_FDC_Data_TarRevPos, ErrorType.Warning, E15405_Failed_To_Upload_FDC_Data_TarRevPos, "각 TarRevPos 대한 FDC 데이터 업로드에 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Upload_FDC_Data_RevPos, ErrorType.Warning, E15406_Failed_To_Upload_FDC_Data_RevPos, "각 RevPos 대한 FDC 데이터 업로드에 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Obtain_VisionPos_Value, ErrorType.ErrorStop, E15407_Failed_To_Obtain_VisionPos_Value, "각 Camera Vision 좌표 값을 읽어오는데 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Obtain_CalData_Value, ErrorType.ErrorStop, E15408_Failed_To_Obtain_CalData_Value, "각 Camera의 Cal 데이터 값을 읽어오는데 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Obtain_CalPos_Value, ErrorType.ErrorStop, E15409_Failed_To_Obtain_CalPosition_Value, "각 Camera의 'Calibration' Position 값을 읽어오는데 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Obtain_CurPos_Value, ErrorType.ErrorStop, E15410_Failed_To_Obtain_CurPosition_Value, "각 Camera의 'Current' Position 값을 읽어오는데 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Obtain_Offset_Value, ErrorType.ErrorStop, E15411_Failed_To_Obtain_Offset_Value, "Offset 값을 읽어오는데 실패하였습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Failed_To_Obtain_LCheck_Spec_Out, ErrorType.ErrorStop, E15412_Failed_To_Obtain_Offset_Value, "L-Check Spec Out입니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Obtain_Camera_CalPos_Value, ErrorType.ErrorStop, E15413_Obtain_Camera_CalPos_Value, "Calibraion에서 Cam CalPos Value를 읽어오는데 실패했습니다."));
        }
        #endregion
    }
}
