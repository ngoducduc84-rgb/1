﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_CenterAlign
{
    [SerializableAttribute]
    public partial class Algo90DBendedLami_4P_CenterAlignAction : Lami90AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private AlgoParam l_ChkCenter01_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter12_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter23_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter30_PNL;

        [field: NonSerialized]
        private AlgoParam l_ChkRange01_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkRange12_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkRange23_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkRange30_PNL;

        [field: NonSerialized]
        private AlgoParam designValuePlus_X;
        [field: NonSerialized]
        private AlgoParam designValuePlus_Y;

        private AlgoParam modelParam;

        #endregion

        #region [Properties]  
        public AlgoParam ModelParam { get { return modelParam; } set { if (modelParam == value) return; modelParam = value; this.OnPropertyChanged(nameof(ModelParam)); } }

        // L-Check Range+Center 
        public AlgoParam L_ChkCenter01_PNL { get { return l_ChkCenter01_PNL; } set { if (l_ChkCenter01_PNL == value) return; l_ChkCenter01_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter01_PNL)); } }
        public AlgoParam L_ChkCenter12_PNL { get { return l_ChkCenter12_PNL; } set { if (l_ChkCenter12_PNL == value) return; l_ChkCenter12_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter12_PNL)); } }
        public AlgoParam L_ChkCenter23_PNL { get { return l_ChkCenter23_PNL; } set { if (l_ChkCenter23_PNL == value) return; l_ChkCenter23_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter23_PNL)); } }
        public AlgoParam L_ChkCenter30_PNL { get { return l_ChkCenter30_PNL; } set { if (l_ChkCenter30_PNL == value) return; l_ChkCenter30_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter30_PNL)); } }

        public AlgoParam L_ChkRange01_PNL { get { return l_ChkRange01_PNL; } set { if (l_ChkRange01_PNL == value) return; l_ChkRange01_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange01_PNL)); } }
        public AlgoParam L_ChkRange12_PNL { get { return l_ChkRange12_PNL; } set { if (l_ChkRange12_PNL == value) return; l_ChkRange12_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange12_PNL)); } }
        public AlgoParam L_ChkRange23_PNL { get { return l_ChkRange23_PNL; } set { if (l_ChkRange23_PNL == value) return; l_ChkRange23_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange23_PNL)); } }
        public AlgoParam L_ChkRange30_PNL { get { return l_ChkRange30_PNL; } set { if (l_ChkRange30_PNL == value) return; l_ChkRange30_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange30_PNL)); } }

        // 비대칭 -> 직사각형 변경을 위한 Proper-
        public AlgoParam DesignValuePlus_X { get { return designValuePlus_X; } set { if (designValuePlus_X == value) return; designValuePlus_X = value; this.OnPropertyChanged(nameof(DesignValuePlus_X)); } }
        public AlgoParam DesignValuePlus_Y { get { return designValuePlus_Y; } set { if (designValuePlus_Y == value) return; designValuePlus_Y = value; this.OnPropertyChanged(nameof(DesignValuePlus_Y)); } }

        #endregion

        #region [Construct]

        public Algo90DBendedLami_4P_CenterAlignAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo90DBendedLami_4P_CenterAlignInputParams();
            OutputParams = new Algo90DBendedLami_4P_CenterAlignOutputParams();

            var obj = _object as Algo90DBendedLami_4P_CenterAlignObject;
            obj.ModelParamType = typeof(Algo90DBendedLami_4P_CenterAlignModelParams);
            var param = obj.CurParams as Algo90DBendedLami_4P_CenterAlignModelParams;

            ChildSettingView = new ModelParams_Setting();
            ChildSettingView.DataContext = ModObject;

            l_ChkCenter01_PNL = new AlgoParam(param.LengthCenter_01_Object);
            l_ChkCenter12_PNL = new AlgoParam(param.LengthCenter_12_Object);
            l_ChkCenter23_PNL = new AlgoParam(param.LengthCenter_23_Object);
            l_ChkCenter30_PNL = new AlgoParam(param.LengthCenter_30_Object);

            l_ChkRange01_PNL = new AlgoParam(param.LengthRange_01_Object);
            l_ChkRange12_PNL = new AlgoParam(param.LengthRange_12_Object);
            l_ChkRange23_PNL = new AlgoParam(param.LengthRange_23_Object);
            l_ChkRange30_PNL = new AlgoParam(param.LengthRange_30_Object);

            designValuePlus_X = new AlgoParam(param.DesignValuePlus_Obj_X);
            designValuePlus_X = new AlgoParam(param.DesignValuePlus_Obj_Y);

            ChildSettingView = new ModelParams_Setting();
            ChildSettingView.DataContext = this;
            //ModObject.PropertyChanged += ModObject_PropertyChanged;

            if (obj.Options == null) obj.Options = new Algo90DBendedLami_4P_CenterAlignModelOptions();
        }
        #endregion

        private void ModObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
        }

        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);

            var Obj = modObject as Algo90DBendedLami_4P_CenterAlignObject;
            
            if (InputName.Equals("Trigger") || InputName.Equals(""))
            {
                StartTimer();

                Obj.Name = name;    // 이름 넣어주기.
                //Obj.SourceID = ObjectID;

                Obj.Run();

                InsertErrorCode(Obj.errorCodeLami);    // Error Code 분류
               
                XYT results = new XYT(); // Connector에 Data 옮기는 부분
                SetResult(ref results);

                List<CommandReplyArgs> rply = OutputPlay("Result", results, CmdRequest.Play, CmdMode.Link, CmdWait.Last_Wait); // UVW 구동하여 Reutrn하는 부분

                for (int cnt = 0; cnt < rply.Count; cnt++)
                {
                    if (rply[cnt].ReplyType != CmdReply.Error)
                    {
                        if (rply[cnt].ReturnValue != null)
                        {
                            object objReturn = rply[cnt].ReturnValue;
                            var re = objReturn.GetType().GetProperties();

                            foreach (PropertyInfo p in re)
                            {
                                string strtemp = p.GetValue(rply[cnt].ReturnValue, null).ToString();

                                switch (p.Name)
                                {
                                    case "X1":
                                        Obj.M_dicVisionValues["TargetPosX1"].NextValue = double.Parse(strtemp) + Obj.StagePosX1; 
                                        break;
                                    case "X2":
                                        Obj.M_dicVisionValues["TargetPosX2"].NextValue = double.Parse(strtemp) + Obj.StagePosX2;
                                        break;
                                    case "Y1":
                                        Obj.M_dicVisionValues["TargetPosY1"].NextValue = double.Parse(strtemp) + Obj.StagePosY1;
                                        break;
                                    case "Y2":
                                        Obj.M_dicVisionValues["TargetPosY2"].NextValue = double.Parse(strtemp) + Obj.StagePosY2;
                                        break;
                                }
                            }
                        }
                    }
                }

                var vIO_data = Obj.M_dicVisionValues; // PLC Update
                var vIO_obj = Obj.CommodObject;
                vIO_obj.SetPlcValues(vIO_data.Values.ToList());

                // 일단 NG도 올려주자...
                OutputPlay("LogResult", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait); // Log에 대한 DataGridView에 넘겨줌      

                if (!ConfirmReplayArgs(ReplyArgs)) { return OccurError(); }  // 할꺼다하고 에러 있으면 에러보고.

                // 보정값이 0이면 이상하다....
                if (results.X == 0 && results.Y == 0 && results.T == 0) return OccurError(Lami90AlgoActionBase.E15025_0_REVOFFSET);

                Obj.AppendMessage(Name, "Caluration Complete");

                StopTimer();
            }
            return End(false);
        }


        private void SetResult(ref XYT results)
        {
            var param = OutputParams as Algo90DBendedLami_4P_CenterAlignOutputParams;
            var obj = ModObject as Algo90DBendedLami_4P_CenterAlignObject;

            if (obj.AlgoRst != null)
            {
                // UVW 활용
                results.X = (obj.AlgoRst as Algo90DBendedLami_4PCenterAlignResult).RevOffsetX;
                results.Y = (obj.AlgoRst as Algo90DBendedLami_4PCenterAlignResult).RevOffsetY;
                results.T = (obj.AlgoRst as Algo90DBendedLami_4PCenterAlignResult).RevOffsetT;
            }
            else
            {
                //obj.AlgoRst = new Algo90DBendedLami_4PTarObjResult();

                obj.AlgoRst = new Algo90DBendedLami_4PCenterAlignResult
                {
                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                    Name = name,
                    ID = obj.SourceID,
                };
            }
                //param.Result = results;
                //base.UpdateResult();

                OnOutputChanged(param);
        }

        public override void Dispose()
        {
            base.Dispose();
        }
        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            var Obj = ModObject as Algo90DBendedLami_4P_CenterAlignObject;
            Obj.ClearAdJustPixel();

            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }

        AlgoParams m_CurParam;

        [field: NonSerialized]
        private DelegateCommand lengthSetCommand;
        public DelegateCommand LengthSetCommand
        {
            get
            {
                return lengthSetCommand = lengthSetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    m_CurParam = DeepClone<AlgoParams>(Obj.CurParams);

                    var tmpParam = Obj.TempParams as Algo90DBendedLami_4P_CenterAlignModelParams;
                    var modObj = ModObject as Algo90DBendedLami_4P_CenterAlignObject;

                    tmpParam.LengthCenter_01_Object.Value = modObj.DObjectLength_01_rst;
                    tmpParam.LengthCenter_12_Object.Value = modObj.DObjectLength_12_rst;
                    tmpParam.LengthCenter_23_Object.Value = modObj.DObjectLength_23_rst;
                    tmpParam.LengthCenter_30_Object.Value = modObj.DObjectLength_30_rst;

                    Obj.UpdateTempValues();
                });
            }
        }

        [field: NonSerialized]
        private DelegateCommand lengthReloadCommand;
        public DelegateCommand LengthReloadCommand
        {
            get
            {
                return lengthReloadCommand = lengthReloadCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo90DBendedLami_4P_CenterAlignModelParams;
                    var cur = m_CurParam as Algo90DBendedLami_4P_CenterAlignModelParams;

                    tmp.LengthCenter_01_Object.Value = cur.LengthCenter_01_Object.Value;
                    tmp.LengthCenter_12_Object.Value = cur.LengthCenter_12_Object.Value;
                    tmp.LengthCenter_23_Object.Value = cur.LengthCenter_23_Object.Value;
                    tmp.LengthCenter_30_Object.Value = cur.LengthCenter_30_Object.Value;

                    Obj.UpdateTempValues();
                });
            }
        }



    }
}
