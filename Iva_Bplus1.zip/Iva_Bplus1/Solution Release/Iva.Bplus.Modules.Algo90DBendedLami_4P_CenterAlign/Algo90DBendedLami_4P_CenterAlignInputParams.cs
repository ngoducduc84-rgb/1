﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_CenterAlign
{
    [SerializableAttribute]
    class Algo90DBendedLami_4P_CenterAlignInputParams : InputParams
    {
        public MatchingRstData PNL_1st_L { get; set; }
        public MatchingRstData PNL_1st_R { get; set; }
        public MatchingRstData PNL_2st_L { get; set; }
        public MatchingRstData PNL_2st_R { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
}
