﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_CenterAlign
{
    [SerializableAttribute]

    public partial class Algo90DBendedLami_4P_CenterAlignModelParams : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;

        private AlgoParam _vOffSet_X;
        private AlgoParam _vOffSet_Y;
        private AlgoParam _vOffSet_T;

        #region Lenght Center        
        private AlgoParam _LengthCenter_01_Object;
        private AlgoParam _LengthCenter_12_Object;
        private AlgoParam _LengthCenter_23_Object;
        private AlgoParam _LengthCenter_30_Object;
        #endregion

        #region Length Rage
        private AlgoParam _LengthRange_01_Object;
        private AlgoParam _LengthRange_12_Object;
        private AlgoParam _LengthRange_23_Object;
        private AlgoParam _LengthRange_30_Object;
        #endregion

        #region DesignPlus
        private AlgoParam _DesignValuePlus_Obj_X;
        private AlgoParam _DesignValuePlus_Obj_Y;
        #endregion

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }


        #region Vision Off-Set
        public AlgoParam vOffSet_X
        {
            get { return _vOffSet_X; }
            set { _vOffSet_X = value; }
        }

        public AlgoParam vOffSet_Y
        {
            get { return _vOffSet_Y; }
            set { _vOffSet_Y = value; }
        }

        public AlgoParam vOffSet_T
        {
            get { return _vOffSet_T; }
            set { _vOffSet_T = value; }
        }
        #endregion

        #region LengthCenter Properties
        public AlgoParam LengthCenter_01_Object
        {
            get { return _LengthCenter_01_Object; }
            set
            {
                if (_LengthCenter_01_Object == value) return;
                _LengthCenter_01_Object = value;
                this.OnPropertyChanged(nameof(LengthCenter_01_Object));
            }
        }
        public AlgoParam LengthCenter_12_Object
        {
            get { return _LengthCenter_12_Object; }
            set
            {
                if (_LengthCenter_12_Object == value) return;
                _LengthCenter_12_Object = value;
                this.OnPropertyChanged(nameof(LengthCenter_12_Object));
            }
        }
        public AlgoParam LengthCenter_23_Object
        {
            get { return _LengthCenter_23_Object; }
            set
            {
                if (_LengthCenter_23_Object == value) return;
                _LengthCenter_23_Object = value;
                this.OnPropertyChanged(nameof(LengthCenter_23_Object));
            }
        }
        public AlgoParam LengthCenter_30_Object
        {
            get { return _LengthCenter_30_Object; }
            set
            {
                if (_LengthCenter_30_Object == value) return;
                _LengthCenter_30_Object = value;
                this.OnPropertyChanged(nameof(LengthCenter_30_Object));
            }
        }
        #endregion

        #region LengthRange Properties

        public AlgoParam LengthRange_01_Object
        {
            get { return _LengthRange_01_Object; }
            set
            {
                if (_LengthRange_01_Object == value) return;
                _LengthRange_01_Object = value;
                this.OnPropertyChanged(nameof(LengthRange_01_Object));
            }
        }
        public AlgoParam LengthRange_12_Object
        {
            get { return _LengthRange_12_Object; }
            set
            {
                if (_LengthRange_12_Object == value) return;
                _LengthRange_12_Object = value;
                this.OnPropertyChanged(nameof(LengthRange_12_Object));
            }
        }
        public AlgoParam LengthRange_23_Object
        {
            get { return _LengthRange_23_Object; }
            set
            {
                if (_LengthRange_23_Object == value) return;
                _LengthRange_23_Object = value;
                this.OnPropertyChanged(nameof(LengthRange_23_Object));
            }
        }
        public AlgoParam LengthRange_30_Object
        {
            get { return _LengthRange_30_Object; }
            set
            {
                if (_LengthRange_30_Object == value) return;
                _LengthRange_30_Object = value;
                this.OnPropertyChanged(nameof(LengthRange_30_Object));
            }
        }
        #endregion

        #region DesignValue
        public AlgoParam DesignValuePlus_Obj_X
        {
            get { return _DesignValuePlus_Obj_X; }
            set
            {
                if (_DesignValuePlus_Obj_X == value) return;
                _DesignValuePlus_Obj_X = value;
                this.OnPropertyChanged(nameof(DesignValuePlus_Obj_X));
            }
        }

        public AlgoParam DesignValuePlus_Obj_Y
        {
            get { return _DesignValuePlus_Obj_Y; }
            set
            {
                if (_DesignValuePlus_Obj_Y == value) return;
                _DesignValuePlus_Obj_Y = value;
                this.OnPropertyChanged(nameof(DesignValuePlus_Obj_Y));
            }
        }

        #endregion

        public Algo90DBendedLami_4P_CenterAlignModelParams()
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)+5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)+5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)+5.0);

            // Vision Off-Set
            vOffSet_X = new AlgoParam("vOffSet_X", "mm", typeof(double), 0.0, "(자재 비대칭형에 따른) Vision Off-Set X", -3.0, 3.0);
            vOffSet_Y = new AlgoParam("vOffSet_Y", "mm", typeof(double), 0.0, "(자재 비대칭형에 따른) Vision Off-Set Y", -3.0, 3.0);
            vOffSet_T = new AlgoParam("vOffSet_T", "mm", typeof(double), 0.0, "(자재 비대칭형에 따른) Vision Off-Set T", -3.0, 3.0);

            LengthCenter_01_Object = new AlgoParam("LengthCenter_01_Object", "mm", typeof(double),  50, "Panel의 Mark0과 Mark1간의 L-Check 중심치", 0,200);
            LengthCenter_12_Object = new AlgoParam("LengthCenter_12_Object", "mm", typeof(double), 150, "Panel의 Mark1과 Mark2간의 L-Check 중심치", 0,200);
            LengthCenter_23_Object = new AlgoParam("LengthCenter_23_Object", "mm", typeof(double), 150, "Panel의 Mark2과 Mark3간의 L-Check 중심치", 0,200);
            LengthCenter_30_Object = new AlgoParam("LengthCenter_30_Object", "mm", typeof(double), 100, "Panel의 Mark3과 Mark0간의 L-Check 중심치", 0,200);

            LengthRange_01_Object = new AlgoParam("LengthRange_01_Object", "mm", typeof(double), 100.0, "Panel의 Mark0과 Mark1간의 L-Check 범위", 0,200);
            LengthRange_12_Object = new AlgoParam("LengthRange_12_Object", "mm", typeof(double), 100.0, "Panel의 Mark1과 Mark2간의 L-Check 범위", 0,200);
            LengthRange_23_Object = new AlgoParam("LengthRange_23_Object", "mm", typeof(double), 100.0, "Panel의 Mark2과 Mark3간의 L-Check 범위", 0,200);
            LengthRange_30_Object = new AlgoParam("LengthRange_30_Object", "mm", typeof(double), 100.0, "Panel의 Mark3과 Mark0간의 L-Check 범위", 0,200);

            DesignValuePlus_Obj_X = new AlgoParam("DesignValuePlus_Obj_X", "mm", typeof(double), 0.0, "(Mark간 직사각형을 만들기 위한) 제품 설계치 X", -10.0, 10.0);
            DesignValuePlus_Obj_Y = new AlgoParam("DesignValuePlus_Obj_Y", "mm", typeof(double), 0.0, "(Mark간 직사각형을 만들기 위한) 제품 설계치 Y", -10.0, 10.0);
        }
    }
}
