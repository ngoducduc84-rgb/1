﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_CenterAlign
{
    [SerializableAttribute]
    public partial class Algo90DBendedLami_4P_CenterAlignObject : Lami90AlgoObjectBase
    {
        #region [Fields]
        #region 각종 '좌표계' 계산 Field값
        // Result Data
        //[field: NonSerialized]
        //private Algo90DBendedLami_4PTarObjResult algoRst;

        public bool UseTarget;
        public Dictionary<string, bool> errorCodeLami;        // ErrorCode
        public Dictionary<string, bool> Judgement_LCheck; // L-Check 판정 

        private ThetaCalType thetaCalType;                // ThetaCalType
        private UseDesignValue useDesignValue_obj;        // DisignValue 사용여부
        private string lastResult;

        // Obj(Panel), Tar(CamCenter) Line Theta 
        [field: NonSerialized]
        public double[] tarLineTheta = new double[4];
        [field: NonSerialized]
        public double[] objLineTheta = new double[4];

        // 앞단에서 받은 Vision_Pos
        [field: NonSerialized]
        public MatchingRstData[] TargetPos = new MatchingRstData[4];
        [field: NonSerialized]
        public MatchingRstData[] ObjectPos = new MatchingRstData[4];

        // CalData 저장
        [field: NonSerialized]
        object[] ObjCalData = new object[4];
        [field: NonSerialized]
        object[] TarCalData = new object[4];

        // 제품 Design Offset Value 
        [field: NonSerialized]
        XY[] ObjDesignVal = new XY[4];

        // 촬상 CurPos
        [field: NonSerialized]
        XY[] TarCurGrabPos = new XY[4];
        [field: NonSerialized]
        XY[] ObjCurGrabPos = new XY[4];

        // (MatchingRstData -> XY) Vision_Pos
        [field: NonSerialized]
        XY[] PNL_Pos = new XY[4];
        [field: NonSerialized]
        XY[] Cam_Pos = new XY[4];
        [field: NonSerialized]
        public XYT TarRevPos = new XYT();
        [field: NonSerialized]
        public XYT ObjRevPos = new XYT();
        [field: NonSerialized]
        public XYT RevPos = new XYT();

        [field: NonSerialized]
        public XY[] tarfixPos = new XY[4];
        [field: NonSerialized]
        public XY[] objfixPos = new XY[4];
        [field: NonSerialized]
        public XY[] tarCoorPos = new XY[4];
        [field: NonSerialized]
        public XY[] objCoorPos = new XY[4];

        public double V_Offset_X;
        public double V_Offset_Y;
        public double V_Offset_T;

        public bool l_Check_JudgeMent;
        public bool JudgeMent;
        #endregion

        #region 제품 설계치에 대한 DesignOffset (마름모 -> 직사각형)
        double sDesignValuePlus_Obj_X;
        double sDesignValuePlus_Obj_Y;
        #endregion

        #region  Object CalData 0~4
        private string objCalData0;
        private string objCalData1;
        private string objCalData2;
        private string objCalData3;
        #endregion

        #region CalDataModTarget0~3
        private CalDataObject calDataModObject0 { get { return SystemObject_Common.GetObject(objCalData0) as CalDataObject; } }
        private CalDataObject calDataModObject1 { get { return SystemObject_Common.GetObject(objCalData1) as CalDataObject; } }
        private CalDataObject calDataModObject2 { get { return SystemObject_Common.GetObject(objCalData2) as CalDataObject; } }
        private CalDataObject calDataModObject3 { get { return SystemObject_Common.GetObject(objCalData3) as CalDataObject; } }
        #endregion

        #region Length Check 데이터
        private double dObjectLength_01;
        private double dObjectLength_12;
        private double dObjectLength_23;
        private double dObjectLength_30;

        private double dObjectLength_01_rst;
        private double dObjectLength_12_rst;
        private double dObjectLength_23_rst;
        private double dObjectLength_30_rst;

        private bool dObjectLength_01_judge;
        private bool dObjectLength_12_judge;
        private bool dObjectLength_23_judge;
        private bool dObjectLength_30_judge;
        #endregion
        #endregion

        #region [properties]

        //public Algo90DBendedLami_4PTarObjResult AlgoRst
        //{
        //    get { return algoRst; }
        //    set
        //    {
        //        if (algoRst == value) return;
        //        algoRst = value;

        //        this.OnPropertyChanged(nameof(AlgoRst));
        //    }
        //}

        #region 'Action'에서 가져 올 PLC, Vision Table Properties
        public Dictionary<string, IOStruct> M_dicVisionValues
        {
            get { return visionValues; }
            set
            {
                if (visionValues == value) return;
                visionValues = value;

                OnPropertyChanged("M_dicVisionValues");
            }
        }
        #endregion
        
        #region object CalData Properties
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string PNL_1st_R_CalData
        {
            get
            {
                return objCalData0;
            }
            set
            {
                if (objCalData0 == value) return;
                objCalData0 = value;

                this.OnPropertyChanged(nameof(PNL_1st_R_CalData));

                //calDataModObject0 = SystemObject_Common.GetObject(objCalData0) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string PNL_1st_L_CalData
        {
            get
            {
                return objCalData1;
            }
            set
            {
                if (objCalData1 == value) return;
                objCalData1 = value;

                this.OnPropertyChanged("PNL_1st_L_CalData");

                //calDataModObject1 = SystemObject_Common.GetObject(objCalData1) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string PNL_2st_L_CalData
        {
            get
            {
                return objCalData2;
            }
            set
            {
                if (objCalData2 == value) return;
                objCalData2 = value;

                this.OnPropertyChanged("PNL_2st_L_CalData");

                //calDataModObject2 = SystemObject_Common.GetObject(objCalData2) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string PNL_2st_R_CalData
        {
            get
            {
                return objCalData3;
            }
            set
            {
                if (objCalData3 == value) return;
                objCalData3 = value;

                this.OnPropertyChanged("PNL_2st_R_CalData");

                //calDataModObject3 = SystemObject_Common.GetObject(objCalData3) as CalDataObject;
            }
        }
        #endregion


        #region ThetaCalType/ ErroCode / UseDesignValue Properties
        public ThetaCalType ThetaCalType
        {
            get { return thetaCalType; }
            set
            {
                if (thetaCalType == value) return;

                thetaCalType = value;
                OnPropertyChanged("ThetaCalType");
            }
        }

        public UseDesignValue UseDesignValue_obj
        {
            get { return useDesignValue_obj; }
            set
            {
                if (useDesignValue_obj == value) return;

                useDesignValue_obj = value;
                OnPropertyChanged("UseDesignValue_obj");
            }
        }
        public Dictionary<string, bool> ErrorCodeLami
        {
            get { return errorCodeLami; }
            set
            {
                if (errorCodeLami == value) return;

                errorCodeLami = value;
                OnPropertyChanged("ErrorCodeLami");
            }
        }
        #endregion

        #region stage current Position
        public double StagePosX1
        {
            get
            {
                if (plcValues.ContainsKey("CurrentPosX1") && plcValues["CurrentPosX1"].CurValue != null)
                {
                    return (double)plcValues["CurrentPosX1"].CurValue;
                }
                else
                {
                    return 0.0;
                }
            }
        }
        public double StagePosX2
        {
            get
            {
                if (plcValues.ContainsKey("CurrentPosX2") && plcValues["CurrentPosX2"].CurValue != null)
                {
                    return (double)plcValues["CurrentPosX2"].CurValue;
                }
                else
                {
                    return 0.0;
                }
            }
        }
        public double StagePosY1
        {
            get
            {
                if (plcValues.ContainsKey("CurrentPosY1") && plcValues["CurrentPosY1"].CurValue != null)
                {
                    return (double)plcValues["CurrentPosY1"].CurValue;
                }
                else
                {
                    return 0.0;
                }
            }
        }
        public double StagePosY2
        {
            get
            {
                if (plcValues.ContainsKey("CurrentPosY2") && plcValues["CurrentPosY2"].CurValue != null)
                {
                    return (double)plcValues["CurrentPosY2"].CurValue;
                }
                else
                {
                    return 0.0;
                }
            }
        }
        #endregion


        public double DObjectLength_01_rst
        {
            get { return dObjectLength_01_rst; }
            set { if (dObjectLength_01_rst == value) return; dObjectLength_01_rst = value; this.OnPropertyChanged(nameof(DObjectLength_01_rst)); }
        }
        public double DObjectLength_12_rst
        {
            get { return dObjectLength_12_rst; }
            set { if (dObjectLength_12_rst == value) return; dObjectLength_12_rst = value; this.OnPropertyChanged(nameof(DObjectLength_12_rst)); }
        }
        public double DObjectLength_23_rst
        {
            get { return dObjectLength_23_rst; }
            set { if (dObjectLength_23_rst == value) return; dObjectLength_23_rst = value; this.OnPropertyChanged(nameof(DObjectLength_23_rst)); }
        }
        public double DObjectLength_30_rst
        {
            get { return dObjectLength_30_rst; }
            set { if (dObjectLength_30_rst == value) return; dObjectLength_30_rst = value; this.OnPropertyChanged(nameof(DObjectLength_30_rst)); }
        }
        public bool DObjectLength_01_judge
        {
            get { return dObjectLength_01_judge; }
            set { if (dObjectLength_01_judge == value) return; dObjectLength_01_judge = value; this.OnPropertyChanged(nameof(DObjectLength_01_judge)); }
        }
        public bool DObjectLength_12_judge
        {
            get { return dObjectLength_12_judge; }
            set { if (dObjectLength_12_judge == value) return; dObjectLength_12_judge = value; this.OnPropertyChanged(nameof(DObjectLength_12_judge)); }
        }
        public bool DObjectLength_23_judge
        {
            get { return dObjectLength_23_judge; }
            set { if (dObjectLength_23_judge == value) return; dObjectLength_23_judge = value; this.OnPropertyChanged(nameof(DObjectLength_23_judge)); }
        }
        public bool DObjectLength_30_judge
        {
            get { return dObjectLength_30_judge; }
            set { if (dObjectLength_30_judge == value) return; dObjectLength_30_judge = value; this.OnPropertyChanged(nameof(DObjectLength_30_judge)); }
        }

        public string LastResult
        {
            get { return lastResult; }
            set
            {
                if (lastResult == value) return;
                lastResult = value;
                this.OnPropertyChanged("LastResult");
            }
        }
        #endregion

        #region [private method]
        #endregion

        #region [public method]
        public void SetInfomation()
        {
        }
        #endregion

        #region[Construct]
        public Algo90DBendedLami_4P_CenterAlignObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo90DBendedLami_4P_CenterAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];

            Options = new Algo90DBendedLami_4P_CenterAlignModelOptions();
        }
        #endregion

        #region [override methode]

        #region 3PAlign 관련 jyh
        //[field: NonSerialized]
        XY adjustPixel;
        public XY AdjustPixel
        {
            get 
            {
                if (adjustPixel == null) 
                    adjustPixel = new XY(); 
                return adjustPixel; }
            set
            {
                if (adjustPixel == value) return;

                adjustPixel = value;
                this.OnPropertyChanged(nameof(AdjustPixel));
            }
        }
        ObservableCollection<XY> adjustPixels;
        public ObservableCollection<XY> AdjustPixels
        {
            get { return adjustPixels; }
            set
            {
                if (adjustPixels == value) return;
                adjustPixels = value;
                this.OnPropertyChanged(nameof(AdjustPixels));
            }
        }

        [NonSerialized]
        int setCount = 0;
        private void SetAdjustPixel(XY px)
        {
            if (adjustPixels == null) adjustPixels = new ObservableCollection<XY>();

            // 리스트에 추가
            //adjustPixels.Insert(0, px);

            SystemFunc.GetApp().Dispatcher.Invoke(new Action(delegate
            {
                // 리스트에 추가
                adjustPixels.Insert(0, px);

                // 최근 열개만 하자
                if (adjustPixels.Count > 10)
                    adjustPixels.Remove(adjustPixels.Last());

            }));

            // 평균값 계산
            XY sum = new XY();
            foreach(var xy in adjustPixels)
            {
                sum.X += xy.X;
                sum.Y += xy.Y;
            }

            AdjustPixel = sum / adjustPixels.Count;

            setCount++;
            // 매 10회마다 한번씩 저장한다.
            if(setCount > 10)
            {
                setCount = 0;
                this.SaveObject();
            }
            this.OnPropertyChanged(nameof(AdjustPixels));
        }

        public void ClearAdJustPixel()
        {
            if (adjustPixels != null) adjustPixels.Clear();
            AdjustPixel = new XY();

            this.OnPropertyChanged(nameof(AdjustPixels));
        }


        private XY GetVirtualMarkPos(int idx, XY opposite, XY gap, XY adjust)
        {
            switch(idx)
            {
                case 0: // 1st-L
                    return opposite - gap - adjust;
                case 1: // 1st-R
                    return opposite + gap + adjust;
                case 2: // 2nd-L
                    return opposite + gap - adjust;
                case 3: // 2nd-R
                    return opposite - gap + adjust;
            }
            return new XY();
        }

        private bool CheckManualMark()
        {
            int ngObjMax = useObj3P ? 2 : 1;

            bool[] checkMark = new bool[4];
            int ngCnt = 0;
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { checkMark[i] = false; ngCnt++; }
                else checkMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngCnt >= ngObjMax)
            {
                // 여기들어오면....바꿔야함...이미지 누락된다잉
                System.Threading.Thread.Sleep(500);

                for (int i = 0; i < 4; i++)
                {
                    // NG가 난 툴을 메뉴얼로 바꿔놓는다....
                    if (!checkMark[i])
                    {
                        ObjectPos[i].Tool.ProcMode = ProcessMode.Manual;
                        ObjectPos[i].DisplayObj.Judgement = (uint)Judgement.OpCall;
                        (ObjectPos[i].Tool.ModObject as ToolObjectBase).DispayMessage("OpCall", System.Drawing.Color.Red);
                    }
                }

                errorCodeLami["Err_Mark_NG"] = false;
            }

            // 너무 일찍 나가니깐 저장된 이미지에 그려지지 않는다 비정상 케이스니 넣어두자
            if (!errorCodeLami["Err_Mark_NG"]) System.Threading.Thread.Sleep(100);

            return errorCodeLami["Err_Mark_NG"];
        }
        int ngPos = -1;
        private void Check3PAlign()
        {
            bool[] checkMark = new bool[4];
            int ngCnt = 0;
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { checkMark[i] = false; ngCnt++; }
                else checkMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngCnt == 1)
            {
                XY virtualXY = new XY();
                ngPos = -1;
                // 1st두개 다 찾았을때
                if (checkMark[0] && checkMark[1])
                {
                    XY gap = new XY();
                    gap.X = ObjectPos[1].OutputXYT.X - ObjectPos[0].OutputXYT.X;
                    gap.Y = ObjectPos[1].OutputXYT.Y - ObjectPos[0].OutputXYT.Y;

                    if (!checkMark[2]) { ngPos = 2; virtualXY = GetVirtualMarkPos(2, ObjectPos[3].OutputXYT.ToXY(), gap, AdjustPixel); }
                    else if (!checkMark[3]) { ngPos = 3; virtualXY = GetVirtualMarkPos(3, ObjectPos[2].OutputXYT.ToXY(), gap, AdjustPixel); }
                }
                // 2nd 두개 다 찾았을때
                else
                {
                    XY gap = new XY();
                    gap.X = ObjectPos[2].OutputXYT.X - ObjectPos[3].OutputXYT.X;
                    gap.Y = ObjectPos[2].OutputXYT.Y - ObjectPos[3].OutputXYT.Y;

                    if (!checkMark[0]) { ngPos = 0; virtualXY = GetVirtualMarkPos(0, ObjectPos[1].OutputXYT.ToXY(), gap, AdjustPixel); }
                    else if (!checkMark[1]) { ngPos = 1; virtualXY = GetVirtualMarkPos(1, ObjectPos[0].OutputXYT.ToXY(), gap, AdjustPixel); }
                }

                // 값을 바꿔주므니다.
                ObjectPos[ngPos].OutputXYT.X = virtualXY.X;
                ObjectPos[ngPos].OutputXYT.Y = virtualXY.Y;

                if (ObjectPos[ngPos].Tool != null) 
                    (ObjectPos[ngPos].Tool.ModObject as ToolObjectBase).CreatSkipResultGraphics(virtualXY);
            }
        }

        private bool CheckLCheckProcess()
        {

            /* 대칭으로 못찾은건 메뉴얼 마크 띄워야함. */
            if ((!DObjectLength_01_judge && !DObjectLength_23_judge) || (!DObjectLength_12_judge && !DObjectLength_30_judge)) { SetToolManualStatus(); return false; }
            /* 포인트가 겹치는 경우는 그 포인트를 가상으로 돌려서 재계산 */
            else if (!DObjectLength_01_judge && !DObjectLength_30_judge) { ObjectPos[0].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_01_judge && !DObjectLength_12_judge) { ObjectPos[1].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_23_judge && !DObjectLength_12_judge) { ObjectPos[2].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_23_judge && !DObjectLength_30_judge) { ObjectPos[3].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            /* 한라인이면 애매하므로 ConfirmRemovePoint함수에서 정해서 재계산*/
            else if (!DObjectLength_01_judge) { ConfirmRemovePoint(0, 1); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_12_judge) { ConfirmRemovePoint(1, 2); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_23_judge) { ConfirmRemovePoint(2, 3); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_30_judge) { ConfirmRemovePoint(3, 0); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }

            return true;
        }

        public void SetToolManualStatus()
        {
            var PNL_1st_L = InputValues["PNL_1st_L"] as MatchingRstData;
            var PNL_1st_R = InputValues["PNL_1st_R"] as MatchingRstData;
            var PNL_2st_L = InputValues["PNL_2st_L"] as MatchingRstData;
            var PNL_2st_R = InputValues["PNL_2st_R"] as MatchingRstData;

            // 하나라도 Ng이면 좀 천천히....바꿔야함...이미지 누락된다잉
            if (!(DObjectLength_01_judge && DObjectLength_23_judge && DObjectLength_12_judge && DObjectLength_30_judge))
            {
                System.Threading.Thread.Sleep(500);
                PNL_1st_L.DisplayObj.Judgement = (uint)Judgement.None;
                PNL_1st_R.DisplayObj.Judgement = (uint)Judgement.None;
                PNL_2st_L.DisplayObj.Judgement = (uint)Judgement.None;
                PNL_2st_R.DisplayObj.Judgement = (uint)Judgement.None;
            }
            else if (DObjectLength_01_judge && DObjectLength_23_judge && DObjectLength_12_judge && DObjectLength_30_judge)
            {
                // 다 성공이니깐 Return
                return;
            }


             if (!DObjectLength_01_judge)
            {
                PNL_1st_R.Tool.ProcMode = ProcessMode.Manual; (PNL_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                PNL_1st_L.Tool.ProcMode = ProcessMode.Manual; (PNL_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);

                PNL_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check; 
                PNL_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
            }
            if (!DObjectLength_12_judge)
            {
                PNL_1st_L.Tool.ProcMode = ProcessMode.Manual; (PNL_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                PNL_2st_L.Tool.ProcMode = ProcessMode.Manual; (PNL_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);

                PNL_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                PNL_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
            }
            if (!DObjectLength_23_judge)
            {
                PNL_2st_L.Tool.ProcMode = ProcessMode.Manual; (PNL_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                PNL_2st_R.Tool.ProcMode = ProcessMode.Manual; (PNL_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);

                PNL_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                PNL_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
            }
            if (!DObjectLength_30_judge)
            {
                PNL_2st_R.Tool.ProcMode = ProcessMode.Manual; (PNL_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                PNL_1st_R.Tool.ProcMode = ProcessMode.Manual; (PNL_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);

                PNL_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                PNL_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
            }
            System.Threading.Thread.Sleep(100);
        }

        private int GetVirtualIndex()
        {
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { return i; }
            }

            return -1;
        }

        private void ConfirmRemovePoint(int a, int b)
        {
            /* 첫번째 마크면 첫번째꺼, 둘다 첫번째 마크면 인식율로, ㅇㅋ? */

            // 일단 작은놈이 승자
            if (ObjectPos[a].SuccessIndex < ObjectPos[b].SuccessIndex) ObjectPos[b].SuccessIndex = -1;
            else if (ObjectPos[a].SuccessIndex > ObjectPos[b].SuccessIndex) ObjectPos[a].SuccessIndex = -1;
            // 같으면 스코어 높은 놈이승자
            else
            {
                if (ObjectPos[a].Score > ObjectPos[b].Score) ObjectPos[b].SuccessIndex = -1;
                else ObjectPos[a].SuccessIndex = -1;
            }
        }

        [field:NonSerialized]
        double limitX;
        [field: NonSerialized]
        double limitY;
        [field: NonSerialized]
        double limitT;
        [field: NonSerialized]
        XYT offset;

        [field: NonSerialized]
        string beforeCellID;
        private bool CalcLJWProcess()
        {
            if (useObj3P) Check3PAlign();

            AlignType AlignMode = AlignType.Obj_4P; // (공용 사용 시) 'properties'에 넣으면 됨
            string[] AlignModeSplit = AlignMode.ToString().Split(new string[] { "_" }, StringSplitOptions.None);
            Type type = typeof(Algo90DBendedLami_4P_CenterAlignObject);
            UseTarget = false;
            string model = SystemModel.GetCurModel();
            offset = new XYT(0, 0, 0);

            for (int cnt = 0; cnt < AlignModeSplit.Length; cnt++) // 나중 공용 목적
            {
                if (AlignModeSplit[cnt] == "Tar")
                {
                    UseTarget = true;
                }
            }
            int CntPos = int.Parse(Regex.Replace(AlignMode.ToString(), @"\D", ""));

            for (int cnt = 0; cnt < 4; cnt++)
            {
                Console.WriteLine("ObjectPos " + cnt.ToString() + " X :" + ObjectPos[cnt].OutputXYT.X.ToString() + "  Y : " + ObjectPos[cnt].OutputXYT.Y.ToString());
            }

            for (int Pos = 0; Pos < TargetPos.Length; Pos++) // Target값은 없으므로 '초기화'
            {
                TargetPos[Pos] = new MatchingRstData();
            }

            // 1-2> UploadFDC(Vision좌표계) + FDC 'Key'없음 Error 처리
            if (UploadFDCdata_Pos(AlignMode, UseTarget, TargetPos, ObjectPos, M_dicVisionValues, ref errorCodeLami) == false) return false;

            // 2> CalData 유/무 확인 -> 내부 Data가 없으면 Error 처리 <- 앞 Module에서 처리 (있으면 주석 처리 하자!)
            if (!CalDataConfirm(type, UseTarget, CntPos, ref ObjCalData, ref TarCalData, ref errorCodeLami)) return false;

            // 3> ModelData 가져오기(각종 Vision에서 Setting할 값들)
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo90DBendedLami_4P_CenterAlignModelParams;
            if (mParams.LimitX == null)
                mParams.LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)+5.0);
            if (mParams.LimitY == null)
                mParams.LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)+5.0);
            if (mParams.LimitT == null)
                mParams.LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)+5.0);

            limitX = (double)mParams.LimitX.Value;
            limitY = (double)mParams.LimitY.Value;
            limitT = (double)mParams.LimitT.Value;

            // 4-1> 'Vision 좌표계' 투입용. for 'GetV2R()' 매개변수 투입용   
            ArrayVisionPos(AlignMode, CntPos, UseTarget, TargetPos, ObjectPos, ref Cam_Pos, ref PNL_Pos);

            // 4-2> '현 Cur Pos' 투입용
            ArrayCurGrabPos(AlignMode, CntPos, UseTarget, ref TarCurGrabPos, ref ObjCurGrabPos, plcValues);

            // 제품 DesignValue에 대한 Off-Set               
            double.TryParse(mParams.DesignValuePlus_Obj_X.Value.ToString(), out sDesignValuePlus_Obj_X);
            double.TryParse(mParams.DesignValuePlus_Obj_Y.Value.ToString(), out sDesignValuePlus_Obj_Y);
            #endregion

            #region Coordinate계산, 직사각형 좌표 산출
            XY[] PnlDesignVal = new XY[4];
            XY[] CamDesignVal = new XY[4]; // -> 'ArrayDesignValue'함수 공용으로 쓰기 위해서 작성
            ArrayDesignValue(type, UseTarget, ref PnlDesignVal, ref CamDesignVal); // <- TarDesignVal를 ObjDesignVal로 바꿀것!


            // 5> CoorPos(+ FixPos 계산), Object(Panel) / Target(CamCenter)   
            if (!CalCoorPos(model, ref tarCoorPos, ref objCoorPos, PNL_Pos, ObjCurGrabPos)) //<- Test 꼭 하자!
            {
                errorCodeLami["Err_obtain_CalPosition_Value"] = false;
                return false;
            }

            for (int temp = 0; temp < objLineTheta.Length; temp++)
            {
                objLineTheta[temp] = 0;
            }

            // DesignValue값 적용 
            ThetaCalType trapeoidCalType = ThetaCalType.UseShort_2L; // Panel은 '사다리꼴'로 무조건 단축으로 계산!
            if (UseDesignValue_obj == UseDesignValue.Use)
            {
                CalTheta(AlignMode, objCoorPos, ref objLineTheta); // object에 대한 theta 구현
                AddDisignValue(ObjDesignVal, objLineTheta, ref objCoorPos);
            }
            #endregion

            #region RevX,Y,T 계산
            // 6> Object, Target에 대한 X,Y,T 산출
            // 6-1> 각 '변'의 Theta성분 
            CalTheta(AlignMode, objCoorPos, ref objLineTheta);
            CalTheta(AlignMode, tarCoorPos, ref tarLineTheta);

            // 6-2> Theta 성분 산출,  X(Left+), Y(Lower+), T(시계+)
            CalRevTheta(AlignMode, trapeoidCalType, objLineTheta, ref ObjRevPos); // '사다리꼴'로 무조건 단축 계산
            CalRevTheta(AlignMode, ThetaCalType, tarLineTheta, ref TarRevPos);

            // 6-3> X,Y 성분 산출
            CalRevXY(AlignMode, CntPos, tarCoorPos, objCoorPos, ref ObjRevPos, ref TarRevPos);
            Console.WriteLine("Obj X : " + ObjRevPos.X.ToString() + " / Y : " + ObjRevPos.Y.ToString() + " / Z : " + ObjRevPos.T.ToString());

            // 7) Off-Set 계산
         
            // Vision Off-Set
            double.TryParse(mParams.vOffSet_X.Value.ToString(), out V_Offset_X);
            double.TryParse(mParams.vOffSet_X.Value.ToString(), out V_Offset_Y);
            double.TryParse(mParams.vOffSet_X.Value.ToString(), out V_Offset_T);

            if (!GainOffSet(plcValues, ref offset))
            {
                errorCodeLami["Err_obtain_Offset_Value"] = false;
                return false;
            }
            else
            {
                // Vision Off-Set 추가 
                offset.X += V_Offset_X;
                offset.Y += V_Offset_Y;
                offset.T += V_Offset_T;
            }

            // 8> Off-set 반영, Target Pos 계산 -> OffSet 고려한 Target Pos 계산
            TarRevPos = ApplyTargetOffset(TarRevPos, offset);
            UploadFDCdata_tar(TarRevPos, errorCodeLami);

            // 9> RevT산출
            RevPos.T = 0;
            RevPos.T = TarRevPos.T - ObjRevPos.T;

            // 10> DriftXY 산출
            double DriftX = Math.Cos(RevPos.T) * ObjRevPos.X - Math.Sin(RevPos.T) * ObjRevPos.Y;
            double DriftY = Math.Sin(RevPos.T) * ObjRevPos.X + Math.Cos(RevPos.T) * ObjRevPos.Y;

            // 11> 최종 RevPos산출, PI * rad = 180도, 1 rad = 180 / PI 
            RevPos.X = TarRevPos.X - DriftX;
            RevPos.Y = TarRevPos.Y - DriftY;
            RevPos.T = NormalizeTheta(RevPos.T) / rad;

            #region FDC TarOffset, RevOffset (TarOffset이 최종 Offset, RevOffset이 순수 Vision Offset)
            // 20200430
            var fdcRev = RevPos - offset;
            //UploadFDCdata_rev(RevPos, errorCodeLami);
            UploadFDCdata_OnlyVisionRev(fdcRev);
            if (uploadFDCdata_Tar() == false) return false;
            #endregion

            #endregion

            #region L-Check
            // 12> L-Check
            Judgement_LCheck = new Dictionary<string, bool>();
            DObjectLength_01_rst = dObjectLength_01 = L_Check(objCoorPos, nameof(dObjectLength_01)); Judgement_LCheck[nameof(dObjectLength_01) + "_Judgement"] = true;
            DObjectLength_12_rst = dObjectLength_12 = L_Check(objCoorPos, nameof(dObjectLength_12)); Judgement_LCheck[nameof(dObjectLength_12) + "_Judgement"] = true;
            DObjectLength_23_rst = dObjectLength_23 = L_Check(objCoorPos, nameof(dObjectLength_23)); Judgement_LCheck[nameof(dObjectLength_23) + "_Judgement"] = true;
            DObjectLength_30_rst = dObjectLength_30 = L_Check(objCoorPos, nameof(dObjectLength_30)); Judgement_LCheck[nameof(dObjectLength_30) + "_Judgement"] = true;

            // 13> FDC L-Check Upload -> fail시 Waning 처리
            UploadFDCdata_Pitch_obj(AlignMode, dObjectLength_01, dObjectLength_12, dObjectLength_23, dObjectLength_30, errorCodeLami);

            Type ModelParamType = typeof(Algo90DBendedLami_4P_CenterAlignModelParams);

            // 14> Object에 대한 L-Check
            //if (!L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_01), dObjectLength_01, Judgement_LCheck, errorCodeLami)) return false;
            //if (!L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_12), dObjectLength_23, Judgement_LCheck, errorCodeLami)) return false;
            //if (!L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_23), dObjectLength_23, Judgement_LCheck, errorCodeLami)) return false;
            //if (!L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_30), dObjectLength_30, Judgement_LCheck, errorCodeLami)) return false;

            DObjectLength_01_judge = L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_01), dObjectLength_01, Judgement_LCheck, errorCodeLami);
            DObjectLength_12_judge = L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_12), dObjectLength_12, Judgement_LCheck, errorCodeLami);
            DObjectLength_23_judge = L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_23), dObjectLength_23, Judgement_LCheck, errorCodeLami);
            DObjectLength_30_judge = L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_30), dObjectLength_30, Judgement_LCheck, errorCodeLami);

            // Align 방식 
            // [Upper, Left]                      [Upper, right]
            //  2 -------------------------------- 3 
            //    |                               l
            //    |                               l
            //    l                               l
            //    |                               |        Lower 찍고, Upper로 이동!
            //    l                               l         
            //    l                               l
            //  1 -------------------------------- 0 
            //  [Lower, Left]                     [Lower, Right]
            //     '작업자' 방향

            #endregion
            return true;
        }

        private bool uploadFDCdata_Tar()
        {

            string keyT_PosX = "FDC_TargetPosX";
            string keyT_PosY = "FDC_TargetPosY";
            string keyT_PosT = "FDC_TargetPosT";

            M_dicVisionValues[keyT_PosX].NextValue = (double)Math.Round(RevPos.X, 3);
            M_dicVisionValues[keyT_PosY].NextValue = (double)Math.Round(RevPos.Y, 3);
            M_dicVisionValues[keyT_PosT].NextValue = (double)Math.Round(RevPos.T, 3);
            return true;
        }

        protected void UploadFDCdata_OnlyVisionRev(XYT rev)
        {
            VisionValues["FDC_ResultRevX"].NextValue = (double)Math.Round(rev.X, 3);
            VisionValues["FDC_ResultRevY"].NextValue = (double)Math.Round(rev.Y, 3);
            VisionValues["FDC_ResultRevT"].NextValue = (double)Math.Round(rev.T, 3);
        }



        bool useObj3P;
        OnOff usePNL3P;
        public override bool Run()
        {
            #region Algo 초기 작업
            MakeArray();
            // Mark간 Spec: 50, 62.7268, 150.6125f
            UpdatePLCIOs();

            string strPos = "Left";

            if(PlcValues.ContainsKey("InputPos"))
            {
                strPos = (bool)PlcValues["InputPos"].CurValue ? "Right" : "Left";
            }

            StartTimer();
            AlignType AlignMode = AlignType.Obj_4P; // (공용 사용 시) 'properties'에 넣으면 됨
            string[] AlignModeSplit = AlignMode.ToString().Split(new string[] { "_" }, StringSplitOptions.None);
            UseTarget = false;

            for (int cnt = 0; cnt < AlignModeSplit.Length; cnt++) // 나중 공용 목적
            {
                if (AlignModeSplit[cnt] == "Tar")
                {
                    UseTarget = true;
                }
            }
            int CntPos = int.Parse(Regex.Replace(AlignMode.ToString(), @"\D", ""));

            string productID = string.Empty;
            string model = SystemModel.GetCurModel();
            bool existID = true;

            //if (plcValues.ContainsKey("CellID"))
            //{
            //    sourceID = (string)plcValues["CellID"].CurValue;
            //}
            //else
            //{
            //    existID = false;
            //    productID = GetMakeID(10);
            //}

            // AlgoError 초기화
            errorCodeLami = new Dictionary<string, bool>();

            // errorCode.Add("Err_Obtain_Coordinate_Value", true); <- 설비별 신규 Error 정의 방법, ErrorDefine에 추가 정의 필요
            InitDefinedError(ref errorCodeLami);
            #endregion

            #region Vision좌표,CalData,CurPos + 사다리꼴 -> 직사각형 MedelData 투입
            // 1> obj,tar Point별 array에 투입
            // 1-1> Obj/TarPos 유,무 확인 + array 투입 
            if (PosConfirm(AlignMode, ref TargetPos, ref ObjectPos, ref errorCodeLami) == false) return false; // PosConfirm <- 개별 분리 시킴
            #endregion

            #region 3Point 관련 추가.... jyh
            // 옵션 가지고 오기
            var algoOption = Options as Algo90DBendedLami_4P_CenterAlignModelOptions;
            usePNL3P = (OnOff)algoOption.UsePanel3PointAlign.Value;
            useObj3P = usePNL3P == OnOff.On ? true : false;

            // 못찾은 마크가 너무 많으면 메뉴얼 마크 띄워주는게 마즘마즘
            // 메뉴얼 마크 찍고 한번 돌고 오면 SuccessIndex == 0 이 되어서 온담..
            if (!CheckManualMark()) return false;

            // 연산하는코드가 다 들어가있다....3P도 첫줄에 넣어놓음.
            if (!CalcLJWProcess()) return false;

            // 길이 체크하는 코드임..3P로 바꾸거나 메뉴얼 마크로 바까부림
            // 메뉴얼 마크 찍고 한번 돌고 온거면 그냥 에러를 친다...어떻할까?또 리트라이해야함?
            // 작업자가 잘못찍은건딩 안들어오것지...???
            if (useObj3P ? !CheckLCheckProcess() : false) return false;

            // 마지막으로 L-Check 함 더 한다.(이거 왜 했더라???기어기가 안난다...오늘한건데..)
            SetToolManualStatus();
            #endregion

            #region Log 및 결과값
            // 15> 최종 결과 
            XYT retVal = new XYT
            {
                X = RevPos.X,
                Y = RevPos.Y,
                T = RevPos.T,

            };// 
            // 50, 62.7268, 150.6125

            string proc = string.Empty;
            int idx = GetVirtualIndex();
            if (idx == -1) proc = "4P";
            else
            {
                if (AdjustPixel.X == 0 && AdjustPixel.Y == 0)
                    errorCodeLami["AdjustValueNotEnough"] = false;
                else
                    errorCodeLami["3PAlign"] = false;

                proc = string.Format("3P(P{0} Skip)", idx);
            }

            l_Check_JudgeMent = true;   // 안쓰는데 로그가 빨개요
            // log 때문에 수정함. 정리한 번 해야 한다.
            AlgoRst = new Algo90DBendedLami_4PCenterAlignResult
            {
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Name = name,
                ID = SourceID,
                InputPos = strPos,
                AlgoProc = proc,
                //ProductID = productID,

                // 최종 결과 값
                RevOffsetX = Math.Round(retVal.X, 3),
                RevOffsetY = Math.Round(retVal.Y, 3),
                RevOffsetT = Math.Round(retVal.T, 3),

                // Target 결과 값 
                Target_PosX = Math.Round(TarRevPos.X, 3),
                Target_PosY = Math.Round(TarRevPos.Y, 3),
                Target_PosT = Math.Round(TarRevPos.T, 3),

                // Object 결과 값                      
                Object_PosX = Math.Round(ObjRevPos.X, 3),
                Object_PosY = Math.Round(ObjRevPos.Y, 3),
                Object_PosT = Math.Round(ObjRevPos.T, 3),

                // 각 성분의 Theta값 
                T01_TargetTheta = Math.Round(tarLineTheta[0] / rad, 3),
                T23_TargetTheta = Math.Round(tarLineTheta[2] / rad, 3),
                T12_TargetTheta = Math.Round(tarLineTheta[1] / rad, 3),
                T03_TargetTheta = Math.Round(tarLineTheta[3] / rad, 3),

                T01_ObjectTheta = Math.Round(objLineTheta[0] / rad, 3),
                T23_ObjectTheta = Math.Round(objLineTheta[2] / rad, 3),
                T12_ObjectTheta = Math.Round(objLineTheta[1] / rad, 3),
                T03_ObjectTheta = Math.Round(objLineTheta[3] / rad, 3),

                DTargetLength_01 = 0.0,
                DTargetLength_12 = 0.0,
                DTargetLength_23 = 0.0,
                DTargetLength_30 = 0.0,

                DObjectLength_01 = Math.Round(dObjectLength_01, 3),
                DObjectLength_12 = Math.Round(dObjectLength_12, 3),
                DObjectLength_23 = Math.Round(dObjectLength_23, 3),
                DObjectLength_30 = Math.Round(dObjectLength_30, 3),

                //BObject_LCheck_01 = Judgement_LCheck[nameof(dObjectLength_01) + "_Judgement"],
                //BObject_LCheck_12 = Judgement_LCheck[nameof(dObjectLength_12) + "_Judgement"],
                //BObject_LCheck_23 = Judgement_LCheck[nameof(dObjectLength_23) + "_Judgement"],
                //BObject_LCheck_03 = Judgement_LCheck[nameof(dObjectLength_30) + "_Judgement"],

                // PLC Off-Set값 
                OffsetX = Math.Round(offset.X, 3),
                OffsetY = Math.Round(offset.Y, 3),
                OffsetT = Math.Round(offset.T, 3),

                IsExistID = existID,
                IslcheckJudgement = l_Check_JudgeMent,

                Pnl_1st_px_Lx = Math.Round(ObjectPos[1].OutputXYT.X, 3),
                Pnl_1st_px_Ly = Math.Round(ObjectPos[1].OutputXYT.Y, 3),
                Pnl_1st_px_Rx = Math.Round(ObjectPos[0].OutputXYT.X, 3),
                Pnl_1st_px_Ry = Math.Round(ObjectPos[0].OutputXYT.Y, 3),
                Pnl_2nd_px_Lx = Math.Round(ObjectPos[2].OutputXYT.X, 3),
                Pnl_2nd_px_Ly = Math.Round(ObjectPos[2].OutputXYT.Y, 3),
                Pnl_2nd_px_Rx = Math.Round(ObjectPos[3].OutputXYT.X, 3),
                Pnl_2nd_px_Ry = Math.Round(ObjectPos[3].OutputXYT.Y, 3),
                Wnd_1st_px_Lx = 0.0,
                Wnd_1st_px_Ly = 0.0,
                Wnd_1st_px_Rx = 0.0,
                Wnd_1st_px_Ry = 0.0,
                Wnd_2nd_px_Lx = 0.0,
                Wnd_2nd_px_Ly = 0.0,
                Wnd_2nd_px_Rx = 0.0,
                Wnd_2nd_px_Ry = 0.0,

                Pnl_1st_rt_Lx = Math.Round(tarCoorPos[1].X, 3),
                Pnl_1st_rt_Ly = Math.Round(tarCoorPos[1].Y, 3),
                Pnl_1st_rt_Rx = Math.Round(tarCoorPos[0].X, 3),
                Pnl_1st_rt_Ry = Math.Round(tarCoorPos[0].Y, 3),
                Pnl_2nd_rt_Lx = Math.Round(tarCoorPos[2].X, 3),
                Pnl_2nd_rt_Ly = Math.Round(tarCoorPos[2].Y, 3),
                Pnl_2nd_rt_Rx = Math.Round(tarCoorPos[3].X, 3),
                Pnl_2nd_rt_Ry = Math.Round(tarCoorPos[3].Y, 3),

                Wnd_1st_rt_Lx = Math.Round(objCoorPos[1].X, 3),
                Wnd_1st_rt_Ly = Math.Round(objCoorPos[1].Y, 3),
                Wnd_1st_rt_Rx = Math.Round(objCoorPos[0].X, 3),
                Wnd_1st_rt_Ry = Math.Round(objCoorPos[0].Y, 3),
                Wnd_2nd_rt_Lx = Math.Round(objCoorPos[2].X, 3),
                Wnd_2nd_rt_Ly = Math.Round(objCoorPos[2].Y, 3),
                Wnd_2nd_rt_Rx = Math.Round(objCoorPos[3].X, 3),
                Wnd_2nd_rt_Ry = Math.Round(objCoorPos[3].Y, 3),

                Diff_1st_Lx = Math.Round(tarCoorPos[1].X - objCoorPos[1].X, 3),
                Diff_1st_Ly = Math.Round(tarCoorPos[1].Y - objCoorPos[1].Y, 3),
                Diff_1st_Rx = Math.Round(tarCoorPos[0].X - objCoorPos[0].X, 3),
                Diff_1st_Ry = Math.Round(tarCoorPos[0].Y - objCoorPos[0].Y, 3),
                Diff_2nd_Lx = Math.Round(tarCoorPos[2].X - objCoorPos[2].X, 3),
                Diff_2nd_Ly = Math.Round(tarCoorPos[2].Y - objCoorPos[2].Y, 3),
                Diff_2nd_Rx = Math.Round(tarCoorPos[3].X - objCoorPos[3].X, 3),
                Diff_2nd_Ry = Math.Round(tarCoorPos[3].Y - objCoorPos[3].Y, 3),
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);

            // 할당 m_DicVisionValue -> Action의 Properties, for M_DicVisionValue에 할당
            visionValues["TargetPosX1"].NextValue = 0;
            visionValues["TargetPosX2"].NextValue = 0;
            visionValues["TargetPosY1"].NextValue = 0;
            visionValues["TargetPosY2"].NextValue = 0;
            #endregion

            StopTimer();

            if (errorCodeLami["Err_PNL_LENGTH_NG"] == false || errorCodeLami["Err_WND_LENGTH_NG"] == false) return false;


            if (!ConfirmSpecMinMax(retVal.X, limitX * (-1), limitX) ||
            !ConfirmSpecMinMax(retVal.Y, limitY * (-1), limitY) ||
            !ConfirmSpecMinMax(retVal.T, limitT * (-1), limitT))
            {
                errorCodeLami["Err_Limit_Over"] = false;

                var PNL_1st_L = InputValues["PNL_1st_L"] as MatchingRstData;
                var PNL_1st_R = InputValues["PNL_1st_R"] as MatchingRstData;
                var PNL_2st_L = InputValues["PNL_2st_L"] as MatchingRstData;
                var PNL_2st_R = InputValues["PNL_2st_R"] as MatchingRstData;


                PNL_1st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                PNL_1st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                PNL_2st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                PNL_2st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;

                return false;
            }


            // 4P Align을 했으면 추가 보정량을 계산해서 넣어둔다. jyh
            if (GetVirtualIndex() == -1)
            {
                XY xy1st = new XY();
                XY xy2nd = new XY();
                xy1st.X = ObjectPos[0].OutputXYT.X - ObjectPos[1].OutputXYT.X;
                xy1st.Y = ObjectPos[0].OutputXYT.Y - ObjectPos[1].OutputXYT.Y;
                xy2nd.X = ObjectPos[3].OutputXYT.X - ObjectPos[2].OutputXYT.X;
                xy2nd.Y = ObjectPos[3].OutputXYT.Y - ObjectPos[2].OutputXYT.Y;
                SetAdjustPixel(xy2nd - xy1st);
            }
            return true;
        }

        private void MakeArray()
        {
            tarLineTheta = new double[4];
            objLineTheta = new double[4];

            TargetPos = new MatchingRstData[4];
            ObjectPos = new MatchingRstData[4];

            ObjCalData = new object[4];
            TarCalData = new object[4];

            ObjDesignVal = new XY[4];

            TarCurGrabPos = new XY[4];
            ObjCurGrabPos = new XY[4];

            PNL_Pos = new XY[4];
            Cam_Pos = new XY[4];

            TarRevPos = new XYT();
            ObjRevPos = new XYT();
            RevPos = new XYT();

            tarfixPos = new XY[4];
            objfixPos = new XY[4];

            tarCoorPos = new XY[4];
            objCoorPos = new XY[4];
        }

        // Align 방식 
        //  1 -------------------------------- 2 [Upper, Right]
        //    |                               l
        //    |                               l
        //    l                               l
        //    |                               |        Lower 찍고, Upper로 이동!
        //    l                               l         
        //    l                               l
        //  0 -------------------------------- 3 [Lower, Right]
        //     '작업자' 방향

        // Th01 == tarLineTheta[0]
        // Th12 == tarLineTheta[1]
        // Th23 == tarLineTheta[2]
        // Th30 == tarLineTheta[3]


        public override void DefaultIOSet()
        {
            base.DefaultIOSet();

            /*plcValues = new Dictionary<string, IOStruct>();
            visionValues = new Dictionary<string, IOStruct>();

            plcValues.Clear();
            visionValues.Clear();


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    PlcIOs.Add(item);
                    plcValues.Add(item.Key, item);
                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    VisionIOs.Add(item);
                    visionValues.Add(item.Key, item);
                }
            }*/
        }


        public override void ObjectInitialize()
        {
            base.ObjectInitialize();

            if (AlignTableObject == null) return;

            PNL_1st_R_CalData = objCalData0;
            PNL_1st_L_CalData = objCalData1;
            PNL_2st_L_CalData = objCalData2;
            PNL_2st_R_CalData = objCalData3;

            //foreach (var item in AlignTableObject.Plc.IOs)
            //{
            //    if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
            //    {
            //        if (!plcValues.ContainsKey(item.Key))
            //        {
            //            plcValues.Add(item.Key, item);
            //        }

            //    }
            //}
            //foreach (var item in AlignTableObject.Vision.IOs)
            //{
            //    if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
            //    {
            //        if (!visionValues.ContainsKey(item.Key))
            //        {
            //            visionValues.Add(item.Key, item);
            //        }
            //    }
            //}
        }

        public bool CalCoorPos(string model, ref XY[] tarCoorPos, ref XY[] objCoorPos, XY[] ObjectPos, XY[] ObjCurGrabPos)
        {
            //[임시] tarCoorPos, objCoorPos 초기화
            Array.Clear(objCoorPos, 0, tarCoorPos.Length);
            Array.Clear(tarCoorPos, 0, tarCoorPos.Length);

            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                tarfixPos[Pos] = new Struct.XY();
                objfixPos[Pos] = new Struct.XY();
                objCoorPos[Pos] = new XY();
                objCoorPos[Pos] = new XY();

                Type type = typeof(Algo90DBendedLami_4P_CenterAlignObject);
                //FieldInfo[] fields = type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                PropertyInfo[] props = type.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var prop in props)
                {
                    if (prop.Name == ("calDataModObject" + Pos.ToString()) || prop.Name == ("calDataModTarget" + Pos.ToString()))
                    {
                        string[] nameSplit = prop.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = prop.GetValue(this);

                        CalDataObject CalData = (CalDataObject)CalValue;

                        switch (nameSplit[1])
                        {
                            case "Obj":  // Object(Window,상부)
                                Struct.CalData calibData = new Struct.CalData();
                                CalData.LoadCalDataWithoutImg(model, ref calibData);
                                if (calibData.RotInfo.ExeCamPosition != null)
                                {
                                    tarCoorPos[Pos] = objfixPos[Pos] = CalData.GetRotateCenter(model);
                                    objCoorPos[Pos] = objfixPos[Pos] + CalData.GetV2R(model, ObjectPos[Pos], true, true);
                                }
                                else
                                {
                                    errorCodeLami["Err_Obtain_Camera_CalPos_Value"] = false;
                                    return false;
                                }
                                break;
                        }
                    }
                }
            }
            return true;
        }

        new protected bool ArrayCurGrabPos(AlignType AlignMode, int InsertPos, bool UseTarget,
                                ref XY[] TarCurGrabPos, ref XY[] ObjCurGrabPos, Dictionary<string, IOStruct> plcValues)
        {
            for (int temp = 0; temp < InsertPos; temp++)
            {
                TarCurGrabPos[temp] = new XY();
                ObjCurGrabPos[temp] = new XY();

                switch (AlignMode)
                {
                    // 90도 'Sub'에서는 굳이 배열로 선언안해도 되나...(각 동일한 CurrentPosX,Y,T)를 갖으므로... 그냥 통일 위해서 정의!
                    case AlignType.Tar_Obj_3P:
                        try
                        {
                            if (plcValues.ContainsKey("CurrentPosX") && plcValues.ContainsKey("CurrentPosY"))
                            {
                                // Sub의 ObjPoint3는 사용을 안해도 넣자!
                                TarCurGrabPos[temp].X = (double)plcValues["UnloadPosX"].CurValue;
                                ObjCurGrabPos[temp].X = (double)plcValues["UnloadPosX"].CurValue;
                                TarCurGrabPos[temp].Y = (double)plcValues["UnloadPosY"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["UnloadPosY"].CurValue;
                            }
                            else
                            {
                                // 값이 없으면 '0'으로 초기화!
                                TarCurGrabPos[temp].X = 0;
                                ObjCurGrabPos[temp].X = 0;
                                TarCurGrabPos[temp].Y = 0;
                                ObjCurGrabPos[temp].Y = 0;
                            }
                            break;
                        }
                        catch (Exception e)
                        {
                            return false;
                        }

                    case AlignType.Tar_Obj_4P:
                        try
                        {
                            if ((temp == 0 || temp == 1) &&
                                plcValues.ContainsKey("UpperCamX2") && plcValues.ContainsKey("LowerCamX2") &&
                                plcValues.ContainsKey("UpperCamY2") && plcValues.ContainsKey("LowerCamY2"))
                            {
                                TarCurGrabPos[temp].X = (double)plcValues["LowerCamX2"].CurValue;
                                TarCurGrabPos[temp].Y = (double)plcValues["LowerCamY2"].CurValue;

                                ObjCurGrabPos[temp].X = (double)plcValues["UpperCamX2"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["UpperCamY2"].CurValue;
                            }
                            else if ((temp == 2 || temp == 3) &&
                                plcValues.ContainsKey("UpperCamX1") && plcValues.ContainsKey("LowerCamX1") &&
                                plcValues.ContainsKey("UpperCamY1") && plcValues.ContainsKey("LowerCamY1"))
                            {
                                TarCurGrabPos[temp].X = (double)plcValues["LowerCamX1"].CurValue;
                                TarCurGrabPos[temp].Y = (double)plcValues["LowerCamY1"].CurValue;

                                ObjCurGrabPos[temp].X = (double)plcValues["UpperCamX1"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["UpperCamY1"].CurValue;
                            }
                            break;
                        }
                        catch (Exception e)
                        {
                            return false;
                        }

                    case AlignType.Obj_4P:
                        try
                        {
                            if ((temp == 0 || temp == 1) &&
                                plcValues.ContainsKey("LowerCamX1") && plcValues.ContainsKey("LowerCamY1"))
                            {
                                TarCurGrabPos[temp].X = 0;
                                TarCurGrabPos[temp].Y = 0;

                                ObjCurGrabPos[temp].X = (double)plcValues["LowerCamX1"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["LowerCamY1"].CurValue;
                            }
                            else if ((temp == 2 || temp == 3) &&
                                plcValues.ContainsKey("LowerCamX2") && plcValues.ContainsKey("LowerCamY2"))
                            {
                                TarCurGrabPos[temp].X = 0;
                                TarCurGrabPos[temp].Y = 0;

                                ObjCurGrabPos[temp].X = (double)plcValues["LowerCamX2"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["LowerCamY2"].CurValue;
                            }
                            break;
                        }
                        catch (Exception e)
                        {
                            return false;
                        }
                }
            }
            return true;
        }

        protected bool PosConfirm(AlignType AlignMode, ref MatchingRstData[] TargetPos, ref MatchingRstData[] ObjectPos, ref Dictionary<string, bool> errorCode)
        {
            bool tempJuge = true;

            switch (AlignMode)
            {
                case AlignType.Obj_4P:
                    ObjectPos[0] = InputValues["PNL_1st_R"] as MatchingRstData;
                    ObjectPos[1] = InputValues["PNL_1st_L"] as MatchingRstData;
                    ObjectPos[2] = InputValues["PNL_2st_L"] as MatchingRstData;
                    ObjectPos[3] = InputValues["PNL_2st_R"] as MatchingRstData;

                    for (int cnt = 0; cnt < TargetPos.Length; cnt++)
                    {
                        TargetPos[cnt] = new MatchingRstData();
                        if (ObjectPos[cnt] == null)
                        {
                            errorCode["Err_obtain_VisionPos_Value"] = false;
                            tempJuge = false;
                            break;
                        }
                    }

                    break;

                case AlignType.Tar_Obj_4P:
                    ObjectPos[0] = InputValues["WND_1st_R"] as MatchingRstData;
                    ObjectPos[1] = InputValues["WND_1st_L"] as MatchingRstData;
                    ObjectPos[2] = InputValues["WND_2st_L"] as MatchingRstData;
                    ObjectPos[3] = InputValues["WND_2st_R"] as MatchingRstData;

                    TargetPos[0] = InputValues["PNL_1st_R"] as MatchingRstData;
                    TargetPos[1] = InputValues["PNL_1st_L"] as MatchingRstData;
                    TargetPos[2] = InputValues["PNL_2st_L"] as MatchingRstData;
                    TargetPos[3] = InputValues["PNL_2st_R"] as MatchingRstData;

                    for (int cnt = 0; cnt < TargetPos.Length; cnt++)
                    {
                        if (ObjectPos[cnt] == null || TargetPos[cnt] == null)
                        {
                            errorCode["Err_obtain_VisionPos_Value"] = false;
                            tempJuge = false;
                            break;
                        }
                    }
                    break;
            }
            return tempJuge;
        }




        new protected bool UploadFDCdata_Pos(AlignType AlignMode, bool UseTarget, MatchingRstData[] TargetPos, MatchingRstData[] ObjectPos, Dictionary<string, IOStruct> M_dicVisionValues, ref Dictionary<string, bool> errorCode)
        {
            string syntax_tar = "";
            string syntax_obj = "";

            switch (AlignMode)
            {
                case AlignType.Tar_Obj_4P:
                    syntax_tar = "P";
                    syntax_obj = "W";
                    break;
                case AlignType.Obj_4P:
                    syntax_obj = "P";
                    break;

                case AlignType.Tar_Obj_3P:
                    syntax_tar = "W";
                    syntax_obj = "P";
                    break;
            }

            for (int Pos = 0; Pos < ObjectPos.Length; Pos++)
            {
                if (UseTarget == true)
                {
                    string keyX_P = "FDC_" + syntax_tar + Pos.ToString() + "X";
                    string keyY_P = "FDC_" + syntax_tar + Pos.ToString() + "Y";
                    string keyS_P = "FDC_" + syntax_tar + Pos.ToString() + "Score";

                    if (M_dicVisionValues.ContainsKey(keyX_P) == false || M_dicVisionValues.ContainsKey(keyY_P) == false || M_dicVisionValues.ContainsKey(keyS_P) == false)
                    {
                        errorCode["Err_Upload_VisionPos_Value"] = false;
                        return false;
                    }
                    // P1X, P1Y, P3X, P3Y 일때 안들어옴??? 
                    else if (AlignMode == AlignType.Tar_Obj_3P && Pos == 0) { } // 90도 Sub_라미 특화
                    else
                    {
                        M_dicVisionValues[keyX_P].NextValue = TargetPos[Pos].OutputXYT.X as object;
                        M_dicVisionValues[keyY_P].NextValue = TargetPos[Pos].OutputXYT.Y as object;
                        M_dicVisionValues[keyS_P].NextValue = TargetPos[Pos].Score as object;
                    }
                }

                string keyX_W = "FDC_" + syntax_obj + Pos.ToString() + "X";
                string keyY_W = "FDC_" + syntax_obj + Pos.ToString() + "Y";
                string keyS_W = "FDC_" + syntax_obj + Pos.ToString() + "Score";

                if (M_dicVisionValues.ContainsKey(keyX_W) == false || M_dicVisionValues.ContainsKey(keyY_W) == false || M_dicVisionValues.ContainsKey(keyS_W) == false)
                {
                    errorCode["Err_Upload_VisionPos_Value"] = false;
                    return false;
                }
                else if (AlignMode == AlignType.Tar_Obj_3P && Pos == 3) { } // 90도 Sub_라미 특화
                else
                {
                    M_dicVisionValues[keyX_W].NextValue = (int)Math.Round(ObjectPos[Pos].OutputXYT.X, 2);
                    M_dicVisionValues[keyY_W].NextValue = (int)Math.Round(ObjectPos[Pos].OutputXYT.Y, 2);
                    M_dicVisionValues[keyS_W].NextValue = (int)Math.Round(ObjectPos[Pos].Score, 2);
                }
            }
            return true;
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void ObjectUpdate()
        {
            base.ObjectUpdate();

            PlcIOsListConverter.Module = CommObj;
            VisionIOsListConverter.Module = CommObj;
        }
        #endregion
    }
}
