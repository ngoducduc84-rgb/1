﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_CenterAlign
{
    class Algo90DBendedLami_4P_CenterAlignOutputParams : OutputParams
    {
        public XYT Result { get; set; }

        public object LogResult { get; set; }
    }
}
