﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_CenterAlign
{
    public class Algo90DBendedLami_4PCenterAlignResult : AlgoResultBase
    {
        private string algoProc;
        private string inputPos;
        private double revX;
        private double revY;
        private double revT;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        private double modelX;
        private double modelY;

        private double t01_TargetTheta;
        private double t23_TargetTheta;
        private double t01_ObjectTheta;
        private double t23_ObjectTheta;

        private double t12_TargetTheta;
        private double t03_TargetTheta;
        private double t12_ObjectTheta;
        private double t03_ObjectTheta;

        private double revOffsetX;
        private double revOffsetY;
        private double revOffsetT;

        private double target_PosX;
        private double target_PosY;
        private double target_PosT;

        private double object_PosX;
        private double object_PosY;
        private double object_PosT;

        private double dTargetLength_01;
        private double dTargetLength_12;
        private double dTargetLength_23;
        private double dTargetLength_30;

        //private bool bTarget_LCheck_01;
        //private bool bTarget_LCheck_12;
        //private bool bTarget_LCheck_23;
        //private bool bTarget_LCheck_30;

        private double dObjectLength_01;
        private double dObjectLength_12;
        private double dObjectLength_23;
        private double dObjectLength_30;

        //private bool bObject_LCheck_01;
        //private bool bObject_LCheck_12;
        //private bool bObject_LCheck_23;
        //private bool bObject_LCheck_30;

        private bool isExistID;
        private bool islcheckJudgement;
        //private bool isJudgement;

        private double dPnl_1st_px_Lx;
        private double dPnl_1st_px_Ly;
        private double dPnl_1st_px_Rx;
        private double dPnl_1st_px_Ry;
        private double dPnl_2nd_px_Lx;
        private double dPnl_2nd_px_Ly;
        private double dPnl_2nd_px_Rx;
        private double dPnl_2nd_px_Ry;
        private double dWnd_1st_px_Lx;
        private double dWnd_1st_px_Ly;
        private double dWnd_1st_px_Rx;
        private double dWnd_1st_px_Ry;
        private double dWnd_2nd_px_Lx;
        private double dWnd_2nd_px_Ly;
        private double dWnd_2nd_px_Rx;
        private double dWnd_2nd_px_Ry;

        private double dPnl_1st_rt_Lx;
        private double dPnl_1st_rt_Ly;
        private double dPnl_1st_rt_Rx;
        private double dPnl_1st_rt_Ry;
        private double dPnl_2nd_rt_Lx;
        private double dPnl_2nd_rt_Ly;
        private double dPnl_2nd_rt_Rx;
        private double dPnl_2nd_rt_Ry;
        private double dWnd_1st_rt_Lx;
        private double dWnd_1st_rt_Ly;
        private double dWnd_1st_rt_Rx;
        private double dWnd_1st_rt_Ry;
        private double dWnd_2nd_rt_Lx;
        private double dWnd_2nd_rt_Ly;
        private double dWnd_2nd_rt_Rx;
        private double dWnd_2nd_rt_Ry;

        private double dDiff_1st_Lx;
        private double dDiff_1st_Ly;
        private double dDiff_1st_Rx;
        private double dDiff_1st_Ry;
        private double dDiff_2nd_Lx;
        private double dDiff_2nd_Ly;
        private double dDiff_2nd_Rx;
        private double dDiff_2nd_Ry;

        #region 기본 property
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string InputPos
        {
            get { return inputPos; }
            set { if (value == inputPos) return; inputPos = value; OnPropertyChanged(nameof(InputPos)); }
        }
        public string AlgoProc
        {
            get { return algoProc; }
            set { if (value == algoProc) return; algoProc = value; OnPropertyChanged(nameof(AlgoProc)); }
        }
        #endregion

        #region 최종 결과 값
        public double RevOffsetX
        {
            get { return revOffsetX; }
            set
            {
                if (value == revOffsetX) return;
                revOffsetX = value;
                this.OnPropertyChanged(nameof(revOffsetX));
            }
        }

        public double RevOffsetY
        {
            get { return revOffsetY; }
            set
            {
                if (value == revOffsetY) return;
                revOffsetY = value;
                this.OnPropertyChanged(nameof(RevOffsetY));
            }
        }

        public double RevOffsetT
        {
            get { return revOffsetT; }
            set
            {
                if (value == revOffsetT) return;
                revOffsetT = value;
                this.OnPropertyChanged(nameof(RevOffsetT));
            }
        }
        #endregion

        #region offset Info
        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                if (value == offsetX) return;
                offsetX = value;

                OnPropertyChanged("OffsetX");
            }
        }

        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                if (value == offsetY) return;
                offsetY = value;

                OnPropertyChanged("OffsetY");
            }
        }

        public double OffsetT
        {
            get { return offsetT; }
            set
            {
                if (value == offsetT) return;
                offsetT = value;

                OnPropertyChanged("OffsetT");
            }
        }
        #endregion

        #region Length Info
        public double DTargetLength_01
        {
            get { return dTargetLength_01; }
            set
            {
                if (value == dTargetLength_01) return;
                dTargetLength_01 = value;
                this.OnPropertyChanged(nameof(DTargetLength_01));
            }
        }
        public double DTargetLength_12
        {
            get { return dTargetLength_12; }
            set
            {
                if (value == dTargetLength_12) return;
                dTargetLength_12 = value;
                this.OnPropertyChanged(nameof(DTargetLength_12));
            }
        }

        public double DTargetLength_23
        {
            get { return dTargetLength_23; }
            set
            {
                if (value == dTargetLength_23) return;
                dTargetLength_23 = value;
                this.OnPropertyChanged(nameof(DTargetLength_23));
            }
        }

        public double DTargetLength_30
        {
            get { return dTargetLength_30; }
            set
            {
                if (value == dTargetLength_30) return;
                dTargetLength_30 = value;
                this.OnPropertyChanged(nameof(DTargetLength_30));
            }
        }

        //public bool BTarget_LCheck_01
        //{
        //    get { return bTarget_LCheck_01; }
        //    set
        //    {
        //        if (value == bTarget_LCheck_01) return;
        //        bTarget_LCheck_01 = value;
        //        this.OnPropertyChanged(nameof(BTarget_LCheck_01));
        //    }
        //}

        //public bool BTarget_LCheck_12
        //{
        //    get { return bTarget_LCheck_12; }
        //    set
        //    {
        //        if (value == bTarget_LCheck_12) return;
        //        bTarget_LCheck_12 = value;
        //        this.OnPropertyChanged(nameof(BTarget_LCheck_12));
        //    }
        //}

        //public bool BTarget_LCheck_23
        //{
        //    get { return bTarget_LCheck_23; }
        //    set
        //    {
        //        if (value == bTarget_LCheck_23) return;
        //        bTarget_LCheck_23 = value;
        //        this.OnPropertyChanged(nameof(BTarget_LCheck_23));
        //    }
        //}

        //public bool BTarget_LCheck_30
        //{
        //    get { return bTarget_LCheck_30; }
        //    set
        //    {
        //        if (value == bTarget_LCheck_30) return;
        //        bTarget_LCheck_30 = value;
        //        this.OnPropertyChanged(nameof(BTarget_LCheck_30));
        //    }
        //}

        public double DObjectLength_01
        {
            get { return dObjectLength_01; }
            set
            {
                if (value == dObjectLength_01) return;
                dObjectLength_01 = value;
                this.OnPropertyChanged(nameof(DObjectLength_01));
            }
        }
        public double DObjectLength_12
        {
            get { return dObjectLength_12; }
            set
            {
                if (value == dObjectLength_12) return;
                dObjectLength_12 = value;
                this.OnPropertyChanged(nameof(DObjectLength_12));
            }
        }

        public double DObjectLength_23
        {
            get { return dObjectLength_23; }
            set
            {
                if (value == dObjectLength_23) return;
                dObjectLength_23 = value;
                this.OnPropertyChanged(nameof(DObjectLength_23));
            }
        }

        public double DObjectLength_30
        {
            get { return dObjectLength_30; }
            set
            {
                if (value == dObjectLength_30) return;
                dObjectLength_30 = value;
                this.OnPropertyChanged(nameof(DObjectLength_30));
            }
        }

        //public bool BObject_LCheck_01
        //{
        //    get { return bObject_LCheck_01; }
        //    set
        //    {
        //        if (value == bObject_LCheck_01) return;
        //        bObject_LCheck_01 = value;
        //        this.OnPropertyChanged(nameof(BObject_LCheck_01));
        //    }
        //}

        //public bool BObject_LCheck_12
        //{
        //    get { return bObject_LCheck_12; }
        //    set
        //    {
        //        if (value == bObject_LCheck_12) return;
        //        bObject_LCheck_12 = value;
        //        this.OnPropertyChanged(nameof(BObject_LCheck_12));
        //    }
        //}

        //public bool BObject_LCheck_23
        //{
        //    get { return bObject_LCheck_23; }
        //    set
        //    {
        //        if (value == bObject_LCheck_23) return;
        //        bObject_LCheck_23 = value;
        //        this.OnPropertyChanged(nameof(BObject_LCheck_23));
        //    }
        //}

        //public bool BObject_LCheck_30
        //{
        //    get { return bObject_LCheck_30; }
        //    set
        //    {
        //        if (value == bObject_LCheck_30) return;
        //        bObject_LCheck_30 = value;
        //        this.OnPropertyChanged(nameof(BObject_LCheck_30));
        //    }
        //}

        #endregion

        #region 각 성분의 Theta값
        public double T01_TargetTheta
        {
            get { return t01_TargetTheta; }
            set
            {
                if (value == t01_TargetTheta) return;
                t01_TargetTheta = value;
                this.OnPropertyChanged(nameof(T01_TargetTheta));
            }
        }

        public double T23_TargetTheta
        {
            get { return t23_TargetTheta; }
            set
            {
                if (value == t23_TargetTheta) return;
                t23_TargetTheta = value;
                this.OnPropertyChanged(nameof(T23_TargetTheta));
            }
        }

        public double T12_TargetTheta
        {
            get { return t12_TargetTheta; }
            set
            {
                if (value == t12_TargetTheta) return;
                t12_TargetTheta = value;
                this.OnPropertyChanged(nameof(T12_TargetTheta));
            }
        }

        public double T03_TargetTheta
        {
            get { return t03_TargetTheta; }
            set
            {
                if (value == t03_TargetTheta) return;
                t03_TargetTheta = value;
                this.OnPropertyChanged(nameof(T03_TargetTheta));
            }
        }
        public double T01_ObjectTheta
        {
            get { return t01_ObjectTheta; }
            set
            {
                if (value == t01_ObjectTheta) return;
                t01_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T01_ObjectTheta));
            }
        }

        public double T23_ObjectTheta
        {
            get { return t23_ObjectTheta; }
            set
            {
                if (value == t23_ObjectTheta) return;
                t23_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T23_ObjectTheta));
            }
        }

        public double T12_ObjectTheta
        {
            get { return t12_ObjectTheta; }
            set
            {
                if (value == t12_ObjectTheta) return;
                t12_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T12_ObjectTheta));
            }
        }

        public double T03_ObjectTheta
        {
            get { return t03_ObjectTheta; }
            set
            {
                if (value == t03_ObjectTheta) return;
                t03_ObjectTheta = value;
                this.OnPropertyChanged(nameof(T03_ObjectTheta));
            }
        }
        #endregion

        #region Target 결과 값 
        public double Target_PosX
        {
            get { return target_PosX; }
            set
            {
                if (value == target_PosX) return;
                target_PosX = value;
                this.OnPropertyChanged(nameof(Target_PosX));
            }
        }

        public double Target_PosY
        {
            get { return target_PosY; }
            set
            {
                if (value == target_PosY) return;
                target_PosY = value;
                this.OnPropertyChanged(nameof(Target_PosY));
            }
        }

        public double Target_PosT
        {
            get { return target_PosT; }
            set
            {
                if (value == target_PosT) return;
                target_PosT = value;
                this.OnPropertyChanged(nameof(target_PosT));
            }
        }
        #endregion

        #region Object 결과 값 
        public double Object_PosX
        {
            get { return object_PosX; }
            set
            {
                if (value == object_PosX) return;
                object_PosX = value;
                this.OnPropertyChanged(nameof(Object_PosX));
            }
        }

        public double Object_PosY
        {
            get { return object_PosY; }
            set
            {
                if (value == object_PosY) return;
                object_PosY = value;
                this.OnPropertyChanged(nameof(Object_PosY));
            }
        }

        public double Object_PosT
        {
            get { return object_PosT; }
            set
            {
                if (value == object_PosT) return;
                object_PosT = value;
                this.OnPropertyChanged(nameof(Object_PosT));
            }
        }
        #endregion

        public bool IsExistID
        {
            get { return isExistID; }
            set
            {
                if (value == isExistID) return;
                isExistID = value;

                OnPropertyChanged("IsExistID");
            }
        }

        public bool IslcheckJudgement
        {
            get { return islcheckJudgement; }
            set
            {
                if (value == islcheckJudgement) return;
                islcheckJudgement = value;

                OnPropertyChanged("IslcheckJudgement");
            }
        }

        //public bool IsJudgement
        //{
        //    get { return isJudgement; }
        //    set
        //    {
        //        if (value == isJudgement) return;
        //        isJudgement = value;

        //        OnPropertyChanged("IsJudgement");
        //    }
        //}

        #region pixel
        public double Pnl_1st_px_Lx
        {
            get { return dPnl_1st_px_Lx; }
            set { if (value == dPnl_1st_px_Lx) return; dPnl_1st_px_Lx = value; this.OnPropertyChanged(nameof(Pnl_1st_px_Lx)); }
        }
        public double Pnl_1st_px_Ly
        {
            get { return dPnl_1st_px_Ly; }
            set { if (value == dPnl_1st_px_Ly) return; dPnl_1st_px_Ly = value; this.OnPropertyChanged(nameof(Pnl_1st_px_Ly)); }
        }
        public double Pnl_1st_px_Rx
        {
            get { return dPnl_1st_px_Rx; }
            set { if (value == dPnl_1st_px_Rx) return; dPnl_1st_px_Rx = value; this.OnPropertyChanged(nameof(Pnl_1st_px_Rx)); }
        }
        public double Pnl_1st_px_Ry
        {
            get { return dPnl_1st_px_Ry; }
            set { if (value == dPnl_1st_px_Ry) return; dPnl_1st_px_Ry = value; this.OnPropertyChanged(nameof(Pnl_1st_px_Ry)); }
        }
        public double Pnl_2nd_px_Lx
        {
            get { return dPnl_2nd_px_Lx; }
            set { if (value == dPnl_2nd_px_Lx) return; dPnl_2nd_px_Lx = value; this.OnPropertyChanged(nameof(Pnl_2nd_px_Lx)); }
        }
        public double Pnl_2nd_px_Ly
        {
            get { return dPnl_2nd_px_Ly; }
            set { if (value == dPnl_2nd_px_Ly) return; dPnl_2nd_px_Ly = value; this.OnPropertyChanged(nameof(Pnl_2nd_px_Ly)); }
        }
        public double Pnl_2nd_px_Rx
        {
            get { return dPnl_2nd_px_Rx; }
            set { if (value == dPnl_2nd_px_Rx) return; dPnl_2nd_px_Rx = value; this.OnPropertyChanged(nameof(Pnl_2nd_px_Rx)); }
        }
        public double Pnl_2nd_px_Ry
        {
            get { return dPnl_2nd_px_Ry; }
            set { if (value == dPnl_2nd_px_Ry) return; dPnl_2nd_px_Ry = value; this.OnPropertyChanged(nameof(Pnl_2nd_px_Ry)); }
        }

        public double Wnd_1st_px_Lx
        {
            get { return dWnd_1st_px_Lx; }
            set { if (value == dWnd_1st_px_Lx) return; dWnd_1st_px_Lx = value; this.OnPropertyChanged(nameof(Wnd_1st_px_Lx)); }
        }
        public double Wnd_1st_px_Ly
        {
            get { return dWnd_1st_px_Ly; }
            set { if (value == dWnd_1st_px_Ly) return; dWnd_1st_px_Ly = value; this.OnPropertyChanged(nameof(Wnd_1st_px_Ly)); }
        }
        public double Wnd_1st_px_Rx
        {
            get { return dWnd_1st_px_Rx; }
            set { if (value == dWnd_1st_px_Rx) return; dWnd_1st_px_Rx = value; this.OnPropertyChanged(nameof(Wnd_1st_px_Rx)); }
        }
        public double Wnd_1st_px_Ry
        {
            get { return dWnd_1st_px_Ry; }
            set { if (value == dWnd_1st_px_Ry) return; dWnd_1st_px_Ry = value; this.OnPropertyChanged(nameof(Wnd_1st_px_Ry)); }
        }
        public double Wnd_2nd_px_Lx
        {
            get { return dWnd_2nd_px_Lx; }
            set { if (value == dWnd_2nd_px_Lx) return; dWnd_2nd_px_Lx = value; this.OnPropertyChanged(nameof(Wnd_2nd_px_Lx)); }
        }
        public double Wnd_2nd_px_Ly
        {
            get { return dWnd_2nd_px_Ly; }
            set { if (value == dWnd_2nd_px_Ly) return; dWnd_2nd_px_Ly = value; this.OnPropertyChanged(nameof(Wnd_2nd_px_Ly)); }
        }
        public double Wnd_2nd_px_Rx
        {
            get { return dWnd_2nd_px_Rx; }
            set { if (value == dWnd_2nd_px_Rx) return; dWnd_2nd_px_Rx = value; this.OnPropertyChanged(nameof(Wnd_2nd_px_Rx)); }
        }
        public double Wnd_2nd_px_Ry
        {
            get { return dWnd_2nd_px_Ry; }
            set { if (value == dWnd_2nd_px_Ry) return; dWnd_2nd_px_Ry = value; this.OnPropertyChanged(nameof(Wnd_2nd_px_Ry)); }
        }



        #endregion

        #region robot
        public double Pnl_1st_rt_Lx
        {
            get { return dPnl_1st_rt_Lx; }
            set { if (value == dPnl_1st_rt_Lx) return; dPnl_1st_rt_Lx = value; this.OnPropertyChanged(nameof(Pnl_1st_rt_Lx)); }
        }
        public double Pnl_1st_rt_Ly
        {
            get { return dPnl_1st_rt_Ly; }
            set { if (value == dPnl_1st_rt_Ly) return; dPnl_1st_rt_Ly = value; this.OnPropertyChanged(nameof(Pnl_1st_rt_Ly)); }
        }
        public double Pnl_1st_rt_Rx
        {
            get { return dPnl_1st_rt_Rx; }
            set { if (value == dPnl_1st_rt_Rx) return; dPnl_1st_rt_Rx = value; this.OnPropertyChanged(nameof(Pnl_1st_rt_Rx)); }
        }
        public double Pnl_1st_rt_Ry
        {
            get { return dPnl_1st_rt_Ry; }
            set { if (value == dPnl_1st_rt_Ry) return; dPnl_1st_rt_Ry = value; this.OnPropertyChanged(nameof(Pnl_1st_rt_Ry)); }
        }
        public double Pnl_2nd_rt_Lx
        {
            get { return dPnl_2nd_rt_Lx; }
            set { if (value == dPnl_2nd_rt_Lx) return; dPnl_2nd_rt_Lx = value; this.OnPropertyChanged(nameof(Pnl_2nd_rt_Lx)); }
        }
        public double Pnl_2nd_rt_Ly
        {
            get { return dPnl_2nd_rt_Ly; }
            set { if (value == dPnl_2nd_rt_Ly) return; dPnl_2nd_rt_Ly = value; this.OnPropertyChanged(nameof(Pnl_2nd_rt_Ly)); }
        }
        public double Pnl_2nd_rt_Rx
        {
            get { return dPnl_2nd_rt_Rx; }
            set { if (value == dPnl_2nd_rt_Rx) return; dPnl_2nd_rt_Rx = value; this.OnPropertyChanged(nameof(Pnl_2nd_rt_Rx)); }
        }
        public double Pnl_2nd_rt_Ry
        {
            get { return dPnl_2nd_rt_Ry; }
            set { if (value == dPnl_2nd_rt_Ry) return; dPnl_2nd_rt_Ry = value; this.OnPropertyChanged(nameof(Pnl_2nd_rt_Ry)); }
        }

        public double Wnd_1st_rt_Lx
        {
            get { return dWnd_1st_rt_Lx; }
            set { if (value == dWnd_1st_rt_Lx) return; dWnd_1st_rt_Lx = value; this.OnPropertyChanged(nameof(Wnd_1st_rt_Lx)); }
        }
        public double Wnd_1st_rt_Ly
        {
            get { return dWnd_1st_rt_Ly; }
            set { if (value == dWnd_1st_rt_Ly) return; dWnd_1st_rt_Ly = value; this.OnPropertyChanged(nameof(Wnd_1st_rt_Ly)); }
        }
        public double Wnd_1st_rt_Rx
        {
            get { return dWnd_1st_rt_Rx; }
            set { if (value == dWnd_1st_rt_Rx) return; dWnd_1st_rt_Rx = value; this.OnPropertyChanged(nameof(Wnd_1st_rt_Rx)); }
        }
        public double Wnd_1st_rt_Ry
        {
            get { return dWnd_1st_rt_Ry; }
            set { if (value == dWnd_1st_rt_Ry) return; dWnd_1st_rt_Ry = value; this.OnPropertyChanged(nameof(Wnd_1st_rt_Ry)); }
        }
        public double Wnd_2nd_rt_Lx
        {
            get { return dWnd_2nd_rt_Lx; }
            set { if (value == dWnd_2nd_rt_Lx) return; dWnd_2nd_rt_Lx = value; this.OnPropertyChanged(nameof(Wnd_2nd_rt_Lx)); }
        }
        public double Wnd_2nd_rt_Ly
        {
            get { return dWnd_2nd_rt_Ly; }
            set { if (value == dWnd_2nd_rt_Ly) return; dWnd_2nd_rt_Ly = value; this.OnPropertyChanged(nameof(Wnd_2nd_rt_Ly)); }
        }
        public double Wnd_2nd_rt_Rx
        {
            get { return dWnd_2nd_rt_Rx; }
            set { if (value == dWnd_2nd_rt_Rx) return; dWnd_2nd_rt_Rx = value; this.OnPropertyChanged(nameof(Wnd_2nd_rt_Rx)); }
        }
        public double Wnd_2nd_rt_Ry
        {
            get { return dWnd_2nd_rt_Ry; }
            set { if (value == dWnd_2nd_rt_Ry) return; dWnd_2nd_rt_Ry = value; this.OnPropertyChanged(nameof(Wnd_2nd_rt_Ry)); }
        }



        #endregion

        #region Diff
        public double Diff_1st_Lx
        {
            get { return dDiff_1st_Lx; }
            set { if (value == dDiff_1st_Lx) return; dDiff_1st_Lx = value; this.OnPropertyChanged(nameof(Diff_1st_Lx)); }
        }
        public double Diff_1st_Ly
        {
            get { return dDiff_1st_Ly; }
            set { if (value == dDiff_1st_Ly) return; dDiff_1st_Ly = value; this.OnPropertyChanged(nameof(Diff_1st_Ly)); }
        }
        public double Diff_1st_Rx
        {
            get { return dDiff_1st_Rx; }
            set { if (value == dDiff_1st_Rx) return; dDiff_1st_Rx = value; this.OnPropertyChanged(nameof(Diff_1st_Rx)); }
        }
        public double Diff_1st_Ry
        {
            get { return dDiff_1st_Ry; }
            set { if (value == dDiff_1st_Ry) return; dDiff_1st_Ry = value; this.OnPropertyChanged(nameof(Diff_1st_Ry)); }
        }
        public double Diff_2nd_Lx
        {
            get { return dDiff_2nd_Lx; }
            set { if (value == dDiff_2nd_Lx) return; dDiff_2nd_Lx = value; this.OnPropertyChanged(nameof(Diff_2nd_Lx)); }
        }
        public double Diff_2nd_Ly
        {
            get { return dDiff_2nd_Ly; }
            set { if (value == dDiff_2nd_Ly) return; dDiff_2nd_Ly = value; this.OnPropertyChanged(nameof(Diff_2nd_Ly)); }
        }
        public double Diff_2nd_Rx
        {
            get { return dDiff_2nd_Rx; }
            set { if (value == dDiff_2nd_Rx) return; dDiff_2nd_Rx = value; this.OnPropertyChanged(nameof(Diff_2nd_Rx)); }
        }
        public double Diff_2nd_Ry
        {
            get { return dDiff_2nd_Ry; }
            set { if (value == dDiff_2nd_Ry) return; dDiff_2nd_Ry = value; this.OnPropertyChanged(nameof(Diff_2nd_Ry)); }
        }
        #endregion


        public Algo90DBendedLami_4PCenterAlignResult()
        {
        }

        #region [Properties]   
        #endregion

        public override string ToString()
        {
            return string.Format("{0} :\n " +
                                  "curDate: {1}\n, " +
                                  "curTime: {2}\n," +

                                  "RevOffsetX : {3}\n" +
                                  "RevOffsetY : {4}\n" +
                                  "RevOffsetT : {5}\n" +

                                  "TarRev.X: {6}\n," +
                                  "TarRev.Y: {7}\n," +
                                  "TarRev.T: {8}\n," +

                                  "ObjRev.X: {9}\n," +
                                  "ObjRev.Y: {10}\n," +
                                  "ObjRev.T: {11}\n," +

                                  "T01_TargetTheta : {12}\n," +
                                  "T23_TargetTheta : {13}\n" +
                                  "T12_TargetTheta : {14}\n," +
                                  "T03_TargetTheta : {15}\n" +

                                  "T01_ObjectTheta  : {16}\n," +
                                  "T23_ObjectTheta  : {17}\n" +
                                  "T12_ObjectTheta  : {18}\n," +
                                  "T03_ObjectTheta  : {19}\n" +

                                  "DTargetLength_01  : {20}\n," +
                                  "DTargetLength_12  : {21}\n" +
                                  "DTargetLength_23  : {22}\n," +
                                  "DTargetLength_03  : {23}\n" +

                                  //"BTarget_LCheck_01   : {24}\n," +
                                  //"BTarget_LCheck_12   : {25}\n" +
                                  //"BTarget_LCheck_23   : {26}\n," +
                                  //"BTarget_LCheck_03   : {27}\n" +

                                  "DObjectLength_01   : {24}\n," +
                                  "DObjectLength_12   : {25}\n" +
                                  "DObjectLength_23   : {26}\n," +
                                  "DObjectLength_03   : {27}\n" +

                                  //"BObject_LCheck_01    : {32}\n," +
                                  //"BObject_LCheck_12    : {33}\n" +
                                  //"BObject_LCheck_23    : {34}\n," +
                                  //"BObject_LCheck_03    : {35}\n" +

                                  "offsetX: {28}\n" +
                                  "offsetY: {29}\n" +
                                  "offsetT: {30}\n" +

                                  "isExistID: {31}\n" +
                                  "islcheckJudgement: {32}\n"
                                  //"isJudgement: {41}\n"

                                  , typeof(Algo90DBendedLami_4PCenterAlignResult).ToString()
                                  , curTime
                                  , curDate
                                  , id

                                  , revX
                                  , revY
                                  , revT

                                  , target_PosX
                                  , target_PosY
                                  , target_PosT

                                  , object_PosX
                                  , object_PosY
                                  , object_PosT

                                  , t01_TargetTheta
                                  , t23_TargetTheta
                                  , t12_TargetTheta
                                  , t03_TargetTheta

                                  , t01_ObjectTheta
                                  , t23_ObjectTheta
                                  , t12_ObjectTheta
                                  , t03_ObjectTheta

                                  , dTargetLength_01
                                  , dTargetLength_12
                                  , dTargetLength_23
                                  , dTargetLength_30

                                  //, bTarget_LCheck_01
                                  //, bTarget_LCheck_12
                                  //, bTarget_LCheck_23
                                  //, bTarget_LCheck_30

                                  , dObjectLength_01
                                  , dObjectLength_12
                                  , dObjectLength_23
                                  , dObjectLength_30

                                  //, bObject_LCheck_01
                                  //, bObject_LCheck_12
                                  //, bObject_LCheck_23
                                  //, bObject_LCheck_30

                                  , offsetX
                                  , offsetY
                                  , offsetT

                                  , isExistID
                                  , islcheckJudgement
                                  //, isJudgement
                                  );
        }
    }
}
