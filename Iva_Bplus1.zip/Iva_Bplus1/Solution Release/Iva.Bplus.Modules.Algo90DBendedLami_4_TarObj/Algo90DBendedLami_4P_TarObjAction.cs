﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo90DBendedLami_4P_TarObj;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using System.Collections.ObjectModel;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_TarObj
{

    [SerializableAttribute]
    public partial class Algo90DBendedLami_4P_TarObjAction : Lami90AlgoActionBase
    {
        #region [Fields]
        // PNL의 Temp_Center
        [field: NonSerialized]
        private AlgoParam l_ChkCenter01_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter12_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter23_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter30_PNL;

        [field: NonSerialized]
        private AlgoParam l_ChkRange01_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkRange12_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkRange23_PNL;
        [field: NonSerialized]
        private AlgoParam l_ChkRange30_PNL;

        // WND의 Temp_Center
        [field: NonSerialized]
        private AlgoParam l_ChkCenter01_WND;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter12_WND;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter23_WND;
        [field: NonSerialized]
        private AlgoParam l_ChkCenter30_WND;

        [field: NonSerialized]
        private AlgoParam l_ChkRange01_WND;
        [field: NonSerialized]
        private AlgoParam l_ChkRange12_WND;
        [field: NonSerialized]
        private AlgoParam l_ChkRange23_WND;
        [field: NonSerialized]
        private AlgoParam l_ChkRange30_WND;

        [field: NonSerialized]
        private AlgoParam designValuePlus_X;
        [field: NonSerialized]
        private AlgoParam designValuePlus_Y;

        private AlgoParam modelParam;
        #endregion

        #region [Properties]   
        public AlgoParam ModelParam { get { return modelParam; } set { if (modelParam == value) return; modelParam = value; this.OnPropertyChanged(nameof(ModelParam)); } }

        // PNL L-Check Range+Center 
        public AlgoParam L_ChkCenter01_PNL { get { return l_ChkCenter01_PNL; } set { if (l_ChkCenter01_PNL == value) return; l_ChkCenter01_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter01_PNL)); } }
        public AlgoParam L_ChkCenter12_PNL { get { return l_ChkCenter12_PNL; } set { if (l_ChkCenter12_PNL == value) return; l_ChkCenter12_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter12_PNL)); } }
        public AlgoParam L_ChkCenter23_PNL { get { return l_ChkCenter23_PNL; } set { if (l_ChkCenter23_PNL == value) return; l_ChkCenter23_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter23_PNL)); } }
        public AlgoParam L_ChkCenter30_PNL { get { return l_ChkCenter30_PNL; } set { if (l_ChkCenter30_PNL == value) return; l_ChkCenter30_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter30_PNL)); } }

        public AlgoParam L_ChkRange01_PNL { get { return l_ChkRange01_PNL; } set { if (l_ChkRange01_PNL == value) return; l_ChkRange01_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange01_PNL)); } }
        public AlgoParam L_ChkRange12_PNL { get { return l_ChkRange12_PNL; } set { if (l_ChkRange12_PNL == value) return; l_ChkRange12_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange12_PNL)); } }
        public AlgoParam L_ChkRange23_PNL { get { return l_ChkRange23_PNL; } set { if (l_ChkRange23_PNL == value) return; l_ChkRange23_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange23_PNL)); } }
        public AlgoParam L_ChkRange30_PNL { get { return l_ChkRange30_PNL; } set { if (l_ChkRange30_PNL == value) return; l_ChkRange30_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange30_PNL)); } }


        // WND L-Check Range+Center
        public AlgoParam L_ChkCenter01_WND { get { return l_ChkCenter01_WND; } set { if (l_ChkCenter01_WND == value) return; l_ChkCenter01_WND = value; this.OnPropertyChanged(nameof(L_ChkCenter01_WND)); } }
        public AlgoParam L_ChkCenter12_WND { get { return l_ChkCenter12_WND; } set { if (l_ChkCenter12_WND == value) return; l_ChkCenter12_WND = value; this.OnPropertyChanged(nameof(L_ChkCenter12_WND)); } }
        public AlgoParam L_ChkCenter23_WND { get { return l_ChkCenter23_WND; } set { if (l_ChkCenter23_WND == value) return; l_ChkCenter23_WND = value; this.OnPropertyChanged(nameof(L_ChkCenter23_WND)); } }
        public AlgoParam L_ChkCenter30_WND { get { return l_ChkCenter30_WND; } set { if (l_ChkCenter30_WND == value) return; l_ChkCenter30_WND = value; this.OnPropertyChanged(nameof(L_ChkCenter30_WND)); } }

        public AlgoParam L_ChkRange01_WND { get { return l_ChkRange01_WND; } set { if (l_ChkRange01_WND == value) return; l_ChkRange01_WND = value; this.OnPropertyChanged(nameof(L_ChkRange01_WND)); } }
        public AlgoParam L_ChkRange12_WND { get { return l_ChkRange12_WND; } set { if (l_ChkRange12_WND == value) return; l_ChkRange12_WND = value; this.OnPropertyChanged(nameof(L_ChkRange12_WND)); } }
        public AlgoParam L_ChkRange23_WND { get { return l_ChkRange23_WND; } set { if (l_ChkRange23_WND == value) return; l_ChkRange23_WND = value; this.OnPropertyChanged(nameof(L_ChkRange23_WND)); } }
        public AlgoParam L_ChkRange30_WND { get { return l_ChkRange30_WND; } set { if (l_ChkRange30_WND == value) return; l_ChkRange30_WND = value; this.OnPropertyChanged(nameof(L_ChkRange30_WND)); } }

        // 비대칭 -> 직사각형 변경을 위한 Proper-
        public AlgoParam DesignValuePlus_X { get { return designValuePlus_X; } set { if (designValuePlus_X == value) return; designValuePlus_X = value; this.OnPropertyChanged(nameof(DesignValuePlus_X)); } }
        public AlgoParam DesignValuePlus_Y { get { return designValuePlus_Y; } set { if (designValuePlus_Y == value) return; designValuePlus_Y = value; this.OnPropertyChanged(nameof(DesignValuePlus_Y)); } }

        #endregion

        #region[Command]
        #endregion

        #region [Construct]


        public Algo90DBendedLami_4P_TarObjAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo90DBendedLami_4P_TarObjInputParams();
            OutputParams = new Algo90DBendedLami_4P_TarObjOutputParams();

            var obj = _object as Algo90DBendedLami_4P_TarObjObject;
            obj.ModelParamType = typeof(Algo90DBendedLami_4P_TarObjModelParams);
            var param = obj.CurParams as Algo90DBendedLami_4P_TarObjModelParams;

            ChildSettingView = new ModelParams_Setting();
            ChildSettingView.DataContext = this;

            l_ChkCenter01_PNL = new AlgoParam(param.LengthCenter_01_Object);
            l_ChkCenter12_PNL = new AlgoParam(param.LengthCenter_12_Object);
            l_ChkCenter23_PNL = new AlgoParam(param.LengthCenter_23_Object);
            l_ChkCenter30_PNL = new AlgoParam(param.LengthCenter_30_Object);

            l_ChkRange01_PNL = new AlgoParam(param.LengthRange_01_Object);
            l_ChkRange12_PNL = new AlgoParam(param.LengthRange_12_Object);
            l_ChkRange23_PNL = new AlgoParam(param.LengthRange_23_Object);
            l_ChkRange30_PNL = new AlgoParam(param.LengthRange_30_Object);


            l_ChkCenter01_WND = new AlgoParam(param.LengthCenter_01_Target);
            l_ChkCenter12_WND = new AlgoParam(param.LengthCenter_12_Target);
            l_ChkCenter23_WND = new AlgoParam(param.LengthCenter_23_Target);
            l_ChkCenter30_WND = new AlgoParam(param.LengthCenter_30_Target);

            l_ChkRange01_WND = new AlgoParam(param.LengthRange_01_Target);
            l_ChkRange12_WND = new AlgoParam(param.LengthRange_12_Target);
            l_ChkRange23_WND = new AlgoParam(param.LengthRange_23_Target);
            l_ChkRange30_WND = new AlgoParam(param.LengthRange_30_Target);

            designValuePlus_X = new AlgoParam(param.DesignValuePlus_Tar_X);
            designValuePlus_X = new AlgoParam(param.DesignValuePlus_Tar_Y);

            if (obj.Options == null) obj.Options = new Algo90DBendedLami_4P_TarObjModelOptions();

            SystemInfo.SetEPLabel("내재화 DL 적용 Version");

        }
        #endregion


        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);

            var Obj = modObject as Algo90DBendedLami_4P_TarObjObject;


            if (InputName.Equals("Trigger") || InputName.Equals(""))
            {
                StartTimer();
                // return new List<CommandReplyArgs>(); // Dry Run을 위한 임시 Test
                Obj.Name = name;    // 이름 넣어주기.
                //Obj.SourceID = ObjectID;

                Obj.Run();

                InsertErrorCode(Obj.errorCodeLami);

                // 2. Connector에 Data 옮기는 부분
                XYT results = new XYT();
                SetResult(ref results);

                //3. UVW 구동하여 Reutrn하는 부분
                //GPL(Upper구동) / Clamp(Lower구동) 공용화 사용시 plc 신호에 따라 구동부 정보 변경토록 처리 (19.12.07 JTJ)
                List<CommandReplyArgs> rply;
                if (Obj.useStagePos == UseStagePos.UpperUse)
                {
                    rply = OutputPlay("Result", results, CmdRequest.Play, CmdMode.Link, CmdWait.Last_Wait); // UVW 구동하여 Reutrn하는 부분
                }
                else
                {
                    rply = OutputPlay("Result_Clamp", results, CmdRequest.Play, CmdMode.Link, CmdWait.Last_Wait); // UVW 구동하여 Reutrn하는 부분
                }


                for (int cnt = 0; cnt < rply.Count; cnt++)
                {
                    if (rply[cnt].ReplyType != CmdReply.Error)
                    {
                        if (rply[cnt].ReturnValue != null)
                        {
                            object objReturn = rply[cnt].ReturnValue;
                            var re = objReturn.GetType().GetProperties();

                            foreach (PropertyInfo p in re)
                            {
                                string strtemp = p.GetValue(rply[cnt].ReturnValue, null).ToString();

                                switch (p.Name)
                                {
                                    case "X1":
                                        Obj.M_dicVisionValues["TargetPosX1"].NextValue = double.Parse(strtemp) + Obj.StagePosX1; 
                                        break;
                                    case "X2":
                                        Obj.M_dicVisionValues["TargetPosX2"].NextValue = double.Parse(strtemp) + Obj.StagePosX2;
                                        break;
                                    case "Y1":
                                        Obj.M_dicVisionValues["TargetPosY1"].NextValue = double.Parse(strtemp) + Obj.StagePosY1;
                                        break;
                                    case "Y2":
                                        Obj.M_dicVisionValues["TargetPosY2"].NextValue = double.Parse(strtemp) + Obj.StagePosY2;
                                        break;
                                }
                            }
                        }
                    }
                }

                // 4. PLC Update하는 부분
                var vIO_data = Obj.M_dicVisionValues;
                var vIO_obj = Obj.CommodObject;
                vIO_obj.SetPlcValues(vIO_data.Values.ToList());

                // 5. Log에 대한 DataGridView에 넘겨줌      
                OutputPlay("LogResult", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                if (!ConfirmReplayArgs(ReplyArgs)) { return OccurError(); }  // 할꺼다하고 에러 있으면 에러보고.

                // 보정값이 0이면 이상하다....
                if (results.X == 0 && results.Y == 0 && results.T == 0) return OccurError(Lami90AlgoActionBase.E15025_0_REVOFFSET);

                Obj.AppendMessage(Name, "Caluration Complete");
                StopTimer();
            }

            return End(false);
        }

        private void SetResult(ref XYT results)
        {
            var param = OutputParams as Algo90DBendedLami_4P_TarObjOutputParams;
            var obj = ModObject as Algo90DBendedLami_4P_TarObjObject;

            if (obj.AlgoRst != null)
            {
                // UVW 활용
                results.X = (obj.AlgoRst as Algo90DBendedLami_4PTarObjResult).RevOffsetX;
                results.Y = (obj.AlgoRst as Algo90DBendedLami_4PTarObjResult).RevOffsetY;
                results.T = (obj.AlgoRst as Algo90DBendedLami_4PTarObjResult).RevOffsetT;
            }
            else
            {
                //obj.AlgoRst = new Algo90DBendedLami_4PTarObjResult();
                obj.AlgoRst = new Algo90DBendedLami_4PTarObjResult
                {
                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                    Name = name,
                    ID = obj.SourceID,
                };
            }
            //param.Result = results;

            //base.UpdateResult();

            OnOutputChanged(param);
        }

        public override void Dispose()
        {
            base.Dispose();
        }
        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            var Obj = ModObject as Algo90DBendedLami_4P_TarObjObject;
            Obj.ClearAdJustPixel();

            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        AlgoParams m_CurParam;

        [field: NonSerialized]
        private DelegateCommand lengthSetCommand;
        public DelegateCommand LengthSetCommand
        {
            get
            {
                return lengthSetCommand = lengthSetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    m_CurParam = DeepClone<AlgoParams>(Obj.CurParams);

                    var tmpParam = Obj.TempParams as Algo90DBendedLami_4P_TarObjModelParams;
                    var modObj = ModObject as Algo90DBendedLami_4P_TarObjObject;

                    tmpParam.LengthCenter_01_Object.Value = modObj.DObjectLength_01_rst;
                    tmpParam.LengthCenter_12_Object.Value = modObj.DObjectLength_12_rst;
                    tmpParam.LengthCenter_23_Object.Value = modObj.DObjectLength_23_rst;
                    tmpParam.LengthCenter_30_Object.Value = modObj.DObjectLength_30_rst;

                    tmpParam.LengthCenter_01_Target.Value = modObj.DTargetLength_01_rst;
                    tmpParam.LengthCenter_12_Target.Value = modObj.DTargetLength_12_rst;
                    tmpParam.LengthCenter_23_Target.Value = modObj.DTargetLength_23_rst;
                    tmpParam.LengthCenter_30_Target.Value = modObj.DTargetLength_30_rst;

                    Obj.UpdateTempValues();
                });
            }
        }


        [field: NonSerialized]
        private DelegateCommand lengthReloadCommand;
        public DelegateCommand LengthReloadCommand
        {
            get
            {
                return lengthReloadCommand = lengthReloadCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;

                    var tmp = Obj.TempParams as Algo90DBendedLami_4P_TarObjModelParams;
                    var cur = m_CurParam as Algo90DBendedLami_4P_TarObjModelParams;

                    tmp.LengthCenter_01_Object.Value = cur.LengthCenter_01_Object.Value;
                    tmp.LengthCenter_12_Object.Value = cur.LengthCenter_12_Object.Value;
                    tmp.LengthCenter_23_Object.Value = cur.LengthCenter_23_Object.Value;
                    tmp.LengthCenter_30_Object.Value = cur.LengthCenter_30_Object.Value;

                    tmp.LengthCenter_01_Target.Value = cur.LengthCenter_01_Target.Value;
                    tmp.LengthCenter_12_Target.Value = cur.LengthCenter_12_Target.Value;
                    tmp.LengthCenter_23_Target.Value = cur.LengthCenter_23_Target.Value;
                    tmp.LengthCenter_30_Target.Value = cur.LengthCenter_30_Target.Value;

                    Obj.UpdateTempValues();
                });
            }
        }



    }
}
