﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_TarObj
{
    [SerializableAttribute]
    class Algo90DBendedLami_4P_TarObjInputParams : InputParams
    {
        //public MatchingRstData Lower_1st_L { get; set; }
        //public MatchingRstData Lower_1st_R { get; set; }
        //public MatchingRstData Lower_2st_L { get; set; }
        //public MatchingRstData Lower_2st_R { get; set; }
        //public MatchingRstData Upper_1st_L { get; set; }
        //public MatchingRstData Upper_1st_R { get; set; }
        //public MatchingRstData Upper_2st_L { get; set; }
        //public MatchingRstData Upper_2st_R { get; set; }

        public object Lower_1st_L { get; set; }
        public object Lower_1st_R { get; set; }
        public object Lower_2st_L { get; set; }
        public object Lower_2st_R { get; set; }

        public object Upper_1st_L { get; set; }
        public object Upper_1st_R { get; set; }
        public object Upper_2st_L { get; set; }
        public object Upper_2st_R { get; set; }

        public CalcTrigger Trigger { get; set; }
    }
}
