﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Iva.Bplus.Enums;
using Telerik.Windows.Data;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_TarObj
{
    [SerializableAttribute, DataContract]

    public partial class Algo90DBendedLami_4P_TarObjModelOptions : AlgoOptions
    {
        //private AlgoOption alignMode;
        //public AlgoOption AlignMode { get { return alignMode; } set { if (alignMode == value) return; alignMode = value; this.OnPropertyChanged(nameof(AlignMode)); } }
        private AlgoOption useWindow3PointAlign;
        private AlgoOption usePanel3PointAlign;
        public AlgoOption UsePanel3PointAlign { get { return usePanel3PointAlign; } set { if (usePanel3PointAlign == value) return; usePanel3PointAlign = value; this.OnPropertyChanged(nameof(usePanel3PointAlign)); } }
        public AlgoOption UseWindow3PointAlign { get { return useWindow3PointAlign; } set { if (useWindow3PointAlign == value) return; useWindow3PointAlign = value; this.OnPropertyChanged(nameof(useWindow3PointAlign)); } }

        public Algo90DBendedLami_4P_TarObjModelOptions()
        {
            //AlignMode = new AlgoOption("AlignMode", OnOff.Off, "Use Panel 3Point Align : Off - Only 4Point Align, On - 4 & 3Point Align");
            UsePanel3PointAlign = new AlgoOption("Use Panel 3Point Align", OnOff.Off, "Use Panel 3Point Align : Off - Only 4Point Align, On - 4 & 3Point Align");
            UseWindow3PointAlign = new AlgoOption("Use Window 3Point Align", OnOff.Off, "Use Panel Window Align : Off - Only 4Point Align, On - 4 & 3Point Align");
        }
    }
}
