﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Iva.Bplus.Enums;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_TarObj
{
    [SerializableAttribute, DataContract]

    public partial class Algo90DBendedLami_4P_TarObjModelParams : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;

        private AlgoParam _vOffSet_X;
        private AlgoParam _vOffSet_Y;
        private AlgoParam _vOffSet_T;
        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }

        #region Vision Off-Set
        public AlgoParam vOffSet_X
        {
            get { return _vOffSet_X; }
            set { _vOffSet_X = value; }
        }

        public AlgoParam vOffSet_Y
        {
            get { return _vOffSet_Y; }
            set { _vOffSet_Y = value; }
        }

        public AlgoParam vOffSet_T
        {
            get { return _vOffSet_T; }
            set { _vOffSet_T = value; }
        }
        #endregion

        #region Lenght Center

        private AlgoParam _LengthCenter_01_Target;
        private AlgoParam _LengthCenter_12_Target;
        private AlgoParam _LengthCenter_23_Target;
        private AlgoParam _LengthCenter_30_Target;

        private AlgoParam _LengthCenter_01_Object;
        private AlgoParam _LengthCenter_12_Object;
        private AlgoParam _LengthCenter_23_Object;
        private AlgoParam _LengthCenter_30_Object;
        #endregion

        #region LengthCenter Properties
        public AlgoParam LengthCenter_01_Target
        {
            get { return _LengthCenter_01_Target; }
            set { _LengthCenter_01_Target = value; }
        }
        public AlgoParam LengthCenter_12_Target
        {
            get { return _LengthCenter_12_Target; }
            set { _LengthCenter_12_Target = value; }
        }
        public AlgoParam LengthCenter_23_Target
        {
            get { return _LengthCenter_23_Target; }
            set { _LengthCenter_23_Target = value; }
        }
        public AlgoParam LengthCenter_30_Target
        {
            get { return _LengthCenter_30_Target; }
            set { _LengthCenter_30_Target = value; }
        }


        public AlgoParam LengthCenter_01_Object
        {
            get { return _LengthCenter_01_Object; }
            set { _LengthCenter_01_Object = value; }
        }
        public AlgoParam LengthCenter_12_Object
        {
            get { return _LengthCenter_12_Object; }
            set { _LengthCenter_12_Object = value; }
        }
        public AlgoParam LengthCenter_23_Object
        {
            get { return _LengthCenter_23_Object; }
            set { _LengthCenter_23_Object = value; }
        }
        public AlgoParam LengthCenter_30_Object
        {
            get { return _LengthCenter_30_Object; }
            set { _LengthCenter_30_Object = value; }
        }
        #endregion

        #region Length Rage
        private AlgoParam _LengthRange_01_Target;
        private AlgoParam _LengthRange_12_Target;
        private AlgoParam _LengthRange_23_Target;
        private AlgoParam _LengthRange_30_Target;

        private AlgoParam _LengthRange_01_Object;
        private AlgoParam _LengthRange_12_Object;
        private AlgoParam _LengthRange_23_Object;
        private AlgoParam _LengthRange_30_Object;
        #endregion

        #region LengthRange Properties
        public AlgoParam LengthRange_01_Target
        {
            get { return _LengthRange_01_Target; }
            set { _LengthRange_01_Target = value; }
        }
        public AlgoParam LengthRange_12_Target
        {
            get { return _LengthRange_12_Target; }
            set { _LengthRange_12_Target = value; }
        }
        public AlgoParam LengthRange_23_Target
        {
            get { return _LengthRange_23_Target; }
            set { _LengthRange_23_Target = value; }
        }
        public AlgoParam LengthRange_30_Target
        {
            get { return _LengthRange_30_Target; }
            set { _LengthRange_30_Target = value; }
        }

        public AlgoParam LengthRange_01_Object
        {
            get { return _LengthRange_01_Object; }
            set { _LengthRange_01_Object = value; }
        }
        public AlgoParam LengthRange_12_Object
        {
            get { return _LengthRange_12_Object; }
            set { _LengthRange_12_Object = value; }
        }
        public AlgoParam LengthRange_23_Object
        {
            get { return _LengthRange_23_Object; }
            set { _LengthRange_23_Object = value; }
        }
        public AlgoParam LengthRange_30_Object
        {
            get { return _LengthRange_30_Object; }
            set { _LengthRange_30_Object = value; }
        }
        #endregion

        #region DesignValue
        private AlgoParam _DesignValuePlus_Tar_X;
        public AlgoParam DesignValuePlus_Tar_X
        {
            get { return _DesignValuePlus_Tar_X; }
            set { _DesignValuePlus_Tar_X = value; }
        }

        private AlgoParam _DesignValuePlus_Tar_Y;
        public AlgoParam DesignValuePlus_Tar_Y
        {
            get { return _DesignValuePlus_Tar_Y; }
            set { _DesignValuePlus_Tar_Y = value; }
        }
        #endregion

        public Algo90DBendedLami_4P_TarObjModelParams()
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)+5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)+5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)+5.0);

            vOffSet_X = new AlgoParam("vOffSet_X", "mm", typeof(double), 0.0, "(자재 비대칭형에 따른) Vision Off-Set X", -3.0, 3.0);
            vOffSet_Y = new AlgoParam("vOffSet_Y", "mm", typeof(double), 0.0, "(자재 비대칭형에 따른) Vision Off-Set Y", -3.0, 3.0);
            vOffSet_T = new AlgoParam("vOffSet_T", "mm", typeof(double), 0.0, "(자재 비대칭형에 따른) Vision Off-Set T", -3.0, 3.0);

            LengthCenter_01_Object = new AlgoParam("LengthCenter_01_Object", "mm", typeof(double),  50.0, "Window의 Mark0과 Mark1간의 L-Check 중심치", 0, 200);
            LengthCenter_12_Object = new AlgoParam("LengthCenter_12_Object", "mm", typeof(double), 150.0, "Window의 Mark1과 Mark2간의 L-Check 중심치", 0, 200);
            LengthCenter_23_Object = new AlgoParam("LengthCenter_23_Object", "mm", typeof(double), 150.0, "Window의 Mark2과 Mark3간의 L-Check 중심치", 0, 200);
            LengthCenter_30_Object = new AlgoParam("LengthCenter_30_Object", "mm", typeof(double), 100.0, "Window의 Mark3과 Mark0간의 L-Check 중심치", 0, 200);

            LengthRange_01_Object = new AlgoParam("LengthRange_01_Object", "mm", typeof(double),  50.0, "Window의 Mark0과 Mark1간의 L-Check 범위", 0, 200);
            LengthRange_12_Object = new AlgoParam("LengthRange_12_Object", "mm", typeof(double), 150.0, "Window의 Mark1과 Mark2간의 L-Check 범위", 0, 200);
            LengthRange_23_Object = new AlgoParam("LengthRange_23_Object", "mm", typeof(double), 150.0, "Window의 Mark2과 Mark3간의 L-Check 범위", 0, 200);
            LengthRange_30_Object = new AlgoParam("LengthRange_30_Object", "mm", typeof(double), 100.0, "Window의 Mark3과 Mark0간의 L-Check 범위", 0, 200);

            LengthCenter_01_Target = new AlgoParam("LengthCenter_01_Target", "mm", typeof(double),  50.0, "Panel의 Mark0과 Mark1간의 L-Check 중심치", 0, 200);
            LengthCenter_12_Target = new AlgoParam("LengthCenter_12_Target", "mm", typeof(double), 150.0, "Panel의 Mark1과 Mark2간의 L-Check 중심치", 0, 200);
            LengthCenter_23_Target = new AlgoParam("LengthCenter_23_Target", "mm", typeof(double), 150.0, "Panel의 Mark2과 Mark3간의 L-Check 중심치", 0, 200);
            LengthCenter_30_Target = new AlgoParam("LengthCenter_30_Target", "mm", typeof(double), 100.0, "Panel의 Mark3과 Mark0간의 L-Check 중심치", 0, 200);

            LengthRange_01_Target = new AlgoParam("LengthRange_01_Target", "mm", typeof(double),  50.0, "Panel의 Mark0과 Mark1간의 L-Check 범위", 0, 200);
            LengthRange_12_Target = new AlgoParam("LengthRange_12_Target", "mm", typeof(double), 150.0, "Panel의 Mark1과 Mark2간의 L-Check 범위", 0, 200);
            LengthRange_23_Target = new AlgoParam("LengthRange_23_Target", "mm", typeof(double), 150.0, "Panel의 Mark2과 Mark3간의 L-Check 범위", 0, 200);
            LengthRange_30_Target = new AlgoParam("LengthRange_30_Target", "mm", typeof(double), 100.0, "Panel의 Mark3과 Mark0간의 L-Check 범위", 0, 200);

            DesignValuePlus_Tar_X = new AlgoParam("DesignValuePlus_Tar_X", "mm", typeof(double), 0.0, "(Mark간 직사각형을 만들기 위한) 제품 설계치 X", -10.0, 10.0);
            DesignValuePlus_Tar_Y = new AlgoParam("DesignValuePlus_Tar_Y", "mm", typeof(double), 0.0, "(Mark간 직사각형을 만들기 위한) 제품 설계치 Y", -10.0, 10.0);
        }
    }
}
