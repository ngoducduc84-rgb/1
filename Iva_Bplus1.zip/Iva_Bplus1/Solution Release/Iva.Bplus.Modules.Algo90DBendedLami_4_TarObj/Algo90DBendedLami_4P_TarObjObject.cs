﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using Iva.Bplus.Interface;
using System.Collections.ObjectModel;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_TarObj
{
    public enum UseStagePos { UpperUse, LowerUse }

    [SerializableAttribute]
    public partial class Algo90DBendedLami_4P_TarObjObject : Lami90AlgoObjectBase
    {
        #region [Fields]
        public bool UseTarget;

        public UseStagePos useStagePos;

        // 제품 설계치에 대한 DesignOffset (Tar == PNL)
        public double sDesignValuePlus_Tar_X;
        public double sDesignValuePlus_Tar_Y;

        [field: NonSerialized]
        public Dictionary<string, bool> Judgement_LCheck;
        [field: NonSerialized]
        public Dictionary<string, bool> errorCodeLami;

        // obj/tar 에서 upper/lower로 이름 변경 (19.12.07 JTJ)
        // up,low CalData 0~4
        private string strUpperCalData0;
        private string strUpperCalData1;
        private string strUpperCalData2;
        private string strUpperCalData3;

        private string strLowerCalData0;
        private string strLowerCalData1;
        private string strLowerCalData2;
        private string strLowerCalData3;

        // obj/tar 에서 upper/lower로 이름 변경 (19.12.07 JTJ)
        // calDataModObject/Target0~3
        private CalDataObject calDataModObject0 { get { if (useStagePos == UseStagePos.UpperUse) return SystemObject_Common.GetObject(strUpperCalData0) as CalDataObject; else return SystemObject_Common.GetObject(strLowerCalData0) as CalDataObject; } }
        private CalDataObject calDataModObject1 { get { if (useStagePos == UseStagePos.UpperUse) return SystemObject_Common.GetObject(strUpperCalData1) as CalDataObject; else return SystemObject_Common.GetObject(strLowerCalData1) as CalDataObject; } }
        private CalDataObject calDataModObject2 { get { if (useStagePos == UseStagePos.UpperUse) return SystemObject_Common.GetObject(strUpperCalData2) as CalDataObject; else return SystemObject_Common.GetObject(strLowerCalData2) as CalDataObject; } }
        private CalDataObject calDataModObject3 { get { if (useStagePos == UseStagePos.UpperUse) return SystemObject_Common.GetObject(strUpperCalData3) as CalDataObject; else return SystemObject_Common.GetObject(strLowerCalData3) as CalDataObject; } }

        private CalDataObject calDataModTarget0 { get { if (useStagePos == UseStagePos.UpperUse) return SystemObject_Common.GetObject(strLowerCalData0) as CalDataObject; else return SystemObject_Common.GetObject(strUpperCalData0) as CalDataObject; } }
        private CalDataObject calDataModTarget1 { get { if (useStagePos == UseStagePos.UpperUse) return SystemObject_Common.GetObject(strLowerCalData1) as CalDataObject; else return SystemObject_Common.GetObject(strUpperCalData1) as CalDataObject; } }
        private CalDataObject calDataModTarget2 { get { if (useStagePos == UseStagePos.UpperUse) return SystemObject_Common.GetObject(strLowerCalData2) as CalDataObject; else return SystemObject_Common.GetObject(strUpperCalData2) as CalDataObject; } }
        private CalDataObject calDataModTarget3 { get { if (useStagePos == UseStagePos.UpperUse) return SystemObject_Common.GetObject(strLowerCalData3) as CalDataObject; else return SystemObject_Common.GetObject(strUpperCalData3) as CalDataObject; } }



        public double V_Offset_X;
        public double V_Offset_Y;
        public double V_Offset_T;

        //Length Check 데이터
        private double dTargetLength_01;
        private double dTargetLength_12;
        private double dTargetLength_23;
        private double dTargetLength_30;

        private double dObjectLength_01;
        private double dObjectLength_12;
        private double dObjectLength_23;
        private double dObjectLength_30;

        private double dTargetLength_01_rst;
        private double dTargetLength_12_rst;
        private double dTargetLength_23_rst;
        private double dTargetLength_30_rst;

        private double dObjectLength_01_rst;
        private double dObjectLength_12_rst;
        private double dObjectLength_23_rst;
        private double dObjectLength_30_rst;

        private bool dTargetLength_01_judge;
        private bool dTargetLength_12_judge;
        private bool dTargetLength_23_judge;
        private bool dTargetLength_30_judge;

        private bool dObjectLength_01_judge;
        private bool dObjectLength_12_judge;
        private bool dObjectLength_23_judge;
        private bool dObjectLength_30_judge;

        private string lastResult;

        // thetaCalType
        private ThetaCalType thetaCalType;

        // DisignValue 사용여부
        private UseDesignValue useDesignValue_tar;

        #region 각종 '좌표계' 계산 Field값
        // Result Data
        [field: NonSerialized]
        private Algo90DBendedLami_4PTarObjResult algoRst;

        // Obj(WND), Tar(PNL) Line Theta 
        public double[] tarLineTheta = new double[4];
        public double[] objLineTheta = new double[4];

        // 앞단에서 받은 Vision_Pos
        [field: NonSerialized]
        public IPointResult[] TargetPos = new IPointResult[4];
        [field: NonSerialized]
        public IPointResult[] ObjectPos = new IPointResult[4];

        // CalData 저장
        [field: NonSerialized]
        public object[] ObjCalData = new object[4];
        [field: NonSerialized]
        public object[] TarCalData = new object[4];

        // 촬상 CurPos
        [field: NonSerialized]
        public XY[] TarCurGrabPos = new XY[4];
        [field: NonSerialized]
        public XY[] ObjCurGrabPos = new XY[4];

        // (MatchingRstData -> XY) Vision_Pos
        [field: NonSerialized]
        XY[] PNL_Pos = new XY[4];
        [field: NonSerialized]
        XY[] WND_Pos = new XY[4];

        [field: NonSerialized]
        public XYT TarRevPos = new XYT();
        [field: NonSerialized]
        public XYT ObjRevPos = new XYT();
        [field: NonSerialized]
        public XYT RevPos = new XYT();
        [field: NonSerialized]
        public XY[] tarfixPos = new XY[4];
        [field: NonSerialized]
        public XY[] objfixPos = new XY[4];
        [field: NonSerialized]
        public XY[] tarCoorPos = new XY[4];
        [field: NonSerialized]
        public XY[] objCoorPos = new XY[4];

        public bool l_Check_JudgeMent;
        public bool JudgeMent;
        #endregion
        #endregion

        #region [properties]
        //public Algo90DBendedLami_4PTarObjResult AlgoRst
        //{
        //    get { return algoRst; }
        //    set
        //    {
        //        if (algoRst == value) return;
        //        algoRst = value;

        //        this.OnPropertyChanged(nameof(AlgoRst));
        //    }
        //}

        #region 'Action'에서 가져 올 PLC, Vision Table Properties

        public Dictionary<string, IOStruct> M_dicVisionValues
        {
            get { return visionValues; }
            set
            {
                if (visionValues == value) return;
                visionValues = value;

                OnPropertyChanged("M_dicVisionValues");
            }
        }
        #endregion

        #region object CalData Properties
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Lower_1st_R
        {
            get
            {
                    return strLowerCalData0;
            }
            set
            {

                if (strLowerCalData0 == value) return;
                strLowerCalData0 = value;

                this.OnPropertyChanged("Lower_1st_R");
              
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Lower_1st_L
        {
            get
            {

                return strLowerCalData1;

            }
            set
            {

                if (strLowerCalData1 == value) return;
                strLowerCalData1 = value;

                this.OnPropertyChanged("Lower_1st_L");

                //calDataModObject1 = SystemObject_Common.GetObject(objCalData1) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Lower_2st_L
        {
            get
            {

                return strLowerCalData2;

            }
            set
            {

                if (strLowerCalData2 == value) return;
                strLowerCalData2 = value;


                this.OnPropertyChanged("Lower_2st_L");

                //calDataModObject2 = SystemObject_Common.GetObject(objCalData2) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Lower_2st_R
        {
            get
            {

                return strLowerCalData3;

            }
            set
            {

                if (strLowerCalData3 == value) return;
                strLowerCalData3 = value;


                this.OnPropertyChanged("Lower_2st_R");

                //calDataModObject3 = SystemObject_Common.GetObject(objCalData3) as CalDataObject;
            }
        }
        #endregion

        #region target CalData Properties
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Upper_1st_R
        {
            get
            {
                    return strUpperCalData0;

            }
            set
            {

                    if (strUpperCalData0 == value) return;
                strUpperCalData0 = value;

                this.OnPropertyChanged("Upper_1st_R");

                //calDataModTarget0 = SystemObject_Common.GetObject(tarCalData0) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Upper_1st_L
        {
            get
            {
                return strUpperCalData1;

            }
            set
            {

                if (strUpperCalData1 == value) return;
                strUpperCalData1 = value;

                this.OnPropertyChanged("Upper_1st_L");

                //calDataModTarget1 = SystemObject_Common.GetObject(tarCalData1) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Upper_2st_L
        {
            get
            {

                    return strUpperCalData2;

            }
            set
            {
                    if (strUpperCalData2 == value) return;
                strUpperCalData2 = value;

                this.OnPropertyChanged("Upper_2st_L");

                //calDataModTarget2 = SystemObject_Common.GetObject(tarCalData2) as CalDataObject;
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Upper_2st_R
        {
            get
            {

                    return strUpperCalData3;

            }
            set
            {

                    if (strUpperCalData3 == value) return;
                strUpperCalData3 = value;

                this.OnPropertyChanged("Upper_2st_R");

                //calDataModTarget3 = SystemObject_Common.GetObject(tarCalData3) as CalDataObject;
            }
        }
        #endregion

        #region ThetaCalType/ ErroCode / UseDesignValue  Properties
        public ThetaCalType ThetaCalType
        {
            get { return thetaCalType; }
            set
            {
                if (thetaCalType == value) return;

                thetaCalType = value;
                OnPropertyChanged("ThetaCalType");
            }
        }

        public UseDesignValue UseDesignValue_tar
        {
            get { return useDesignValue_tar; }
            set
            {
                if (useDesignValue_tar == value) return;

                useDesignValue_tar = value;
                OnPropertyChanged("UseDesignValue_tar");
            }
        }

        public Dictionary<string, bool> ErrorCode
        {
            get { return errorCodeLami; }
            set
            {
                if (errorCodeLami == value) return;

                errorCodeLami = value;
                OnPropertyChanged("ErrorCode");
            }
        }
        #endregion

        public string LastResult
        {
            get { return lastResult; }
            set
            {
                if (lastResult == value) return;
                lastResult = value;
                this.OnPropertyChanged("LastResult");
            }
        }

        // Stage 사용 Pos에 따른...
        public UseStagePos UseStagePos
        {
            get { return useStagePos; }
            set { if (useStagePos == value) return; useStagePos = value; this.OnPropertyChanged(nameof(UseStagePos)); }
        }

        #region stage current Position
        public double StagePosX1
        {
            get
            {
                if (plcValues["CurrentPosX1"].CurValue != null)
                {
                    return (double)plcValues["CurrentPosX1"].CurValue;
                }
                else
                {
                    return 0.0;
                }
            }
        }
        public double StagePosX2
        {
            get
            {
                if (plcValues["CurrentPosX2"].CurValue != null)
                {
                    return (double)plcValues["CurrentPosX2"].CurValue;
                }
                else
                {
                    return 0.0;
                }
            }
        }
        public double StagePosY1
        {
            get
            {
                if (plcValues["CurrentPosY1"].CurValue != null)
                {
                    return (double)plcValues["CurrentPosY1"].CurValue;
                }
                else
                {
                    return 0.0;
                }
            }
        }
        public double StagePosY2
        {
            get
            {
                if (plcValues["CurrentPosY2"].CurValue != null)
                {
                    return (double)plcValues["CurrentPosY2"].CurValue;
                }
                else
                {
                    return 0.0;
                }
            }
        }
        #endregion



        public double DTargetLength_01_rst
        {
            get { return dTargetLength_01_rst; }
            set { if (dTargetLength_01_rst == value) return; dTargetLength_01_rst = value; this.OnPropertyChanged(nameof(DTargetLength_01_rst)); }
        }
        public double DTargetLength_12_rst
        {
            get { return dTargetLength_12_rst; }
            set { if (dTargetLength_12_rst == value) return; dTargetLength_12_rst = value; this.OnPropertyChanged(nameof(DTargetLength_12_rst)); }
        }
        public double DTargetLength_23_rst
        {
            get { return dTargetLength_23_rst; }
            set { if (dTargetLength_23_rst == value) return; dTargetLength_23_rst = value; this.OnPropertyChanged(nameof(DTargetLength_23_rst)); }
        }
        public double DTargetLength_30_rst
        {
            get { return dTargetLength_30_rst; }
            set { if (dTargetLength_30_rst == value) return; dTargetLength_30_rst = value; this.OnPropertyChanged(nameof(DTargetLength_30_rst)); }
        }

        public double DObjectLength_01_rst
        {
            get { return dObjectLength_01_rst; }
            set { if (dObjectLength_01_rst == value) return; dObjectLength_01_rst = value; this.OnPropertyChanged(nameof(DObjectLength_01_rst)); }
        }
        public double DObjectLength_12_rst
        {
            get { return dObjectLength_12_rst; }
            set { if (dObjectLength_12_rst == value) return; dObjectLength_12_rst = value; this.OnPropertyChanged(nameof(DObjectLength_12_rst)); }
        }
        public double DObjectLength_23_rst
        {
            get { return dObjectLength_23_rst; }
            set { if (dObjectLength_23_rst == value) return; dObjectLength_23_rst = value; this.OnPropertyChanged(nameof(DObjectLength_23_rst)); }
        }
        public double DObjectLength_30_rst
        {
            get { return dObjectLength_30_rst; }
            set { if (dObjectLength_30_rst == value) return; dObjectLength_30_rst = value; this.OnPropertyChanged(nameof(DObjectLength_30_rst)); }
        }

        public bool DTargetLength_01_judge
        {
            get { return dTargetLength_01_judge; }
            set { if (dTargetLength_01_judge == value) return; dTargetLength_01_judge = value; this.OnPropertyChanged(nameof(DTargetLength_01_judge)); }
        }
        public bool DTargetLength_12_judge
        {
            get { return dTargetLength_12_judge; }
            set { if (dTargetLength_12_judge == value) return; dTargetLength_12_judge = value; this.OnPropertyChanged(nameof(DTargetLength_12_judge)); }
        }
        public bool DTargetLength_23_judge
        {
            get { return dTargetLength_23_judge; }
            set { if (dTargetLength_23_judge == value) return; dTargetLength_23_judge = value; this.OnPropertyChanged(nameof(DTargetLength_23_judge)); }
        }
        public bool DTargetLength_30_judge
        {
            get { return dTargetLength_30_judge; }
            set { if (dTargetLength_30_judge == value) return; dTargetLength_30_judge = value; this.OnPropertyChanged(nameof(DTargetLength_30_judge)); }
        }

        public bool DObjectLength_01_judge
        {
            get { return dObjectLength_01_judge; }
            set { if (dObjectLength_01_judge == value) return; dObjectLength_01_judge = value; this.OnPropertyChanged(nameof(DObjectLength_01_judge)); }
        }
        public bool DObjectLength_12_judge
        {
            get { return dObjectLength_12_judge; }
            set { if (dObjectLength_12_judge == value) return; dObjectLength_12_judge = value; this.OnPropertyChanged(nameof(DObjectLength_12_judge)); }
        }
        public bool DObjectLength_23_judge
        {
            get { return dObjectLength_23_judge; }
            set { if (dObjectLength_23_judge == value) return; dObjectLength_23_judge = value; this.OnPropertyChanged(nameof(DObjectLength_23_judge)); }
        }
        public bool DObjectLength_30_judge
        {
            get { return dObjectLength_30_judge; }
            set { if (dObjectLength_30_judge == value) return; dObjectLength_30_judge = value; this.OnPropertyChanged(nameof(DObjectLength_30_judge)); }
        }
        #endregion

        #region [private method]
        #endregion

        #region [public method]
        public void SetInfomation()
        {
        }
        #endregion

        #region[Construct]

        public Algo90DBendedLami_4P_TarObjObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo90DBendedLami_4P_TarObjModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion


        #region 3PAlign 관련 jyh
        //[field: NonSerialized]
        XY adjustObjPixel;
        XY adjustTarPixel;
        public XY AdjustObjPixel
        {
            get
            {
                if (adjustObjPixel == null)
                    adjustObjPixel = new XY();
                return adjustObjPixel;
            }
            set
            {
                if (adjustObjPixel == value) return;

                adjustObjPixel = value;
                this.OnPropertyChanged(nameof(AdjustObjPixel));
            }
        }
        public XY AdjustTarPixel
        {
            get
            {
                if (adjustTarPixel == null)
                    adjustTarPixel = new XY();
                return adjustTarPixel;
            }
            set
            {
                if (adjustTarPixel == value) return;

                adjustTarPixel = value;
                this.OnPropertyChanged(nameof(AdjustTarPixel));
            }
        }

        private ObservableCollection<XY> adjustObjPixels;
        private ObservableCollection<XY> adjustTarPixels;

        public ObservableCollection<XY> AdjustObjPixels
        {
            get { return adjustObjPixels; }
            set
            {
                if (adjustObjPixels == value) return;
                adjustObjPixels = value;
                this.OnPropertyChanged(nameof(AdjustObjPixels));
            }
        }
        public ObservableCollection<XY> AdjustTarPixels
        {
            get { return adjustTarPixels; }
            set
            {
                if (adjustTarPixels == value) return;
                adjustTarPixels = value;
                this.OnPropertyChanged(nameof(AdjustTarPixels));
            }
        }

        [NonSerialized]
        int setObjCount;
        private void SetAdjustObjPixel(XY px)
        {
            if (adjustObjPixels == null) adjustObjPixels = new ObservableCollection<XY>();

            SystemFunc.GetApp().Dispatcher.Invoke(new Action(delegate
            {
                // 리스트에 추가
                adjustObjPixels.Insert(0, px);

                // 최근 열개만 하자
                if (adjustObjPixels.Count > 10)
                    adjustObjPixels.Remove(adjustObjPixels.Last());

            }));

            // 평균값 계산
            XY sum = new XY();
            foreach (var xy in adjustObjPixels)
            {
                sum.X += xy.X;
                sum.Y += xy.Y;
            }

            AdjustObjPixel = sum / adjustObjPixels.Count;


            setObjCount++;
            // 매 10회마다 한번씩 저장한다.
            if (setObjCount > 10)
            {
                setObjCount = 0;
                this.SaveObject();
            }
            this.OnPropertyChanged(nameof(AdjustObjPixels));
        }

        [NonSerialized]
        int setTarCount;
        private void SetAdjustTarPixel(XY px)
        {
            if (adjustTarPixels == null) adjustTarPixels = new ObservableCollection<XY>();

            SystemFunc.GetApp().Dispatcher.Invoke(new Action(delegate
            {
                // 리스트에 추가
                adjustTarPixels.Insert(0, px);

                // 최근 열개만 하자
                if (adjustTarPixels.Count > 10)
                    adjustTarPixels.Remove(adjustTarPixels.Last());

            }));


            // 평균값 계산
            XY sum = new XY();
            foreach (var xy in adjustTarPixels)
            {
                sum.X += xy.X;
                sum.Y += xy.Y;
            }

            AdjustTarPixel = sum / adjustTarPixels.Count;


            setTarCount++;
            // 매 10회마다 한번씩 저장한다.
            if (setTarCount > 10)
            {
                setTarCount = 0;
                this.SaveObject();
            }

            this.OnPropertyChanged(nameof(AdjustTarPixels));
        }

        public void ClearAdJustPixel()
        {
            if (adjustObjPixels != null) adjustObjPixels.Clear();
            if (adjustTarPixels != null) adjustTarPixels.Clear();
            AdjustObjPixel = new XY();
            AdjustTarPixel = new XY();
            this.OnPropertyChanged(nameof(AdjustObjPixels));
            this.OnPropertyChanged(nameof(AdjustTarPixels));
        }


        private XY GetVirtualMarkPos(int idx, XY opposite, XY gap, XY adjust)
        {
            switch (idx)
            {
                case 0: // 1st-L
                    return opposite - gap - adjust;
                case 1: // 1st-R
                    return opposite + gap + adjust;
                case 2: // 2nd-L
                    return opposite + gap - adjust;
                case 3: // 2nd-R
                    return opposite - gap + adjust;
            }
            return new XY();
        }

        private bool CheckManualMark()
        {
            int ngObjMax = useObj3P ? 2 : 1;
            int ngTarMax = useTar3P ? 2 : 1;

            bool[] checkObjMark = new bool[4];
            int ngObjCnt = 0;
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { checkObjMark[i] = false; ngObjCnt++; }
                else checkObjMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngObjCnt >= ngObjMax)
            {
                // 여기들어오면....바꿔야함...이미지 누락된다잉
                System.Threading.Thread.Sleep(500);

                for (int i = 0; i < 4; i++)
                {
                    // NG가 난 툴을 메뉴얼로 바꿔놓는다....
                    if (!checkObjMark[i])
                    {
                        ObjectPos[i].Tool.ProcMode = ProcessMode.Manual;
                        ObjectPos[i].DisplayObj.Judgement = (uint)Judgement.OpCall;
                        (ObjectPos[i].Tool.ModObject as ToolObjectBase).DispayMessage("OpCall", System.Drawing.Color.Red);
                    }
                }

                errorCodeLami["Err_Mark_NG"] = false;
            }

            bool[] checkTarMark = new bool[4];
            int ngTarCnt = 0;
            for (int i = 0; i < TargetPos.Count(); i++)
            {
                if (TargetPos[i].SuccessIndex == -1) { checkTarMark[i] = false; ngTarCnt++; }
                else checkTarMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngTarCnt >= ngTarMax)
            {
                // 여기들어오면....바꿔야함...이미지 누락된다잉
                System.Threading.Thread.Sleep(500);

                for (int i = 0; i < 4; i++)
                {
                    // NG가 난 툴을 메뉴얼로 바꿔놓는다....
                    if (!checkTarMark[i])
                    {
                        TargetPos[i].Tool.ProcMode = ProcessMode.Manual;
                        TargetPos[i].DisplayObj.Judgement = (uint)Judgement.OpCall;
                        (TargetPos[i].Tool.ModObject as ToolObjectBase).DispayMessage("OpCall", System.Drawing.Color.Red);
                    }
                }

                errorCodeLami["Err_Mark_NG"] = false;
            }

            // 너무 일찍 나가니깐 저장된 이미지에 그려지지 않는다 비정상 케이스니 넣어두자
            if (!errorCodeLami["Err_Mark_NG"]) System.Threading.Thread.Sleep(100);   

            return errorCodeLami["Err_Mark_NG"];    // 위에서 한군대라도 들어가면 false겠지비
        }
        int ngPos = -1;
        private void Check3PAligObject()
        {

            bool[] checkMark = new bool[4];
            int ngCnt = 0;
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { checkMark[i] = false; ngCnt++; }
                else checkMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngCnt == 1)
            {
                XY virtualXY = new XY();
                ngPos = -1;
                // 1st두개 다 찾았을때
                if (checkMark[0] && checkMark[1])
                {
                    XY gap = new XY();
                    gap.X = ObjectPos[1].OutputXYT.X - ObjectPos[0].OutputXYT.X;
                    gap.Y = ObjectPos[1].OutputXYT.Y - ObjectPos[0].OutputXYT.Y;

                    if (!checkMark[2]) { ngPos = 2; virtualXY = GetVirtualMarkPos(2, ObjectPos[3].OutputXYT.ToXY(), gap, AdjustObjPixel); }
                    else if (!checkMark[3]) { ngPos = 3; virtualXY = GetVirtualMarkPos(3, ObjectPos[2].OutputXYT.ToXY(), gap, AdjustObjPixel); }
                }
                // 2nd 두개 다 찾았을때
                else
                {
                    XY gap = new XY();
                    gap.X = ObjectPos[2].OutputXYT.X - ObjectPos[3].OutputXYT.X;
                    gap.Y = ObjectPos[2].OutputXYT.Y - ObjectPos[3].OutputXYT.Y;

                    if (!checkMark[0]) { ngPos = 0; virtualXY = GetVirtualMarkPos(0, ObjectPos[1].OutputXYT.ToXY(), gap, AdjustObjPixel); }
                    else if (!checkMark[1]) { ngPos = 1; virtualXY = GetVirtualMarkPos(1, ObjectPos[0].OutputXYT.ToXY(), gap, AdjustObjPixel); }
                }

                // 값을 바꿔주므니다.
                ObjectPos[ngPos].OutputXYT.X = virtualXY.X;
                ObjectPos[ngPos].OutputXYT.Y = virtualXY.Y;

                if (ObjectPos[ngPos].Tool != null)
                    (ObjectPos[ngPos].Tool.ModObject as ToolObjectBase).CreatSkipResultGraphics(virtualXY);
            }
        }

        private void Check3PAligTarget()
        {
            if (useStagePos == UseStagePos.UpperUse) { if (usePNL3P == OnOff.Off) return; }
            else { if (useWND3P == OnOff.Off) return; }


            bool[] checkMark = new bool[4];
            int ngCnt = 0;
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < TargetPos.Count(); i++)
            {
                if (TargetPos[i].SuccessIndex == -1) { checkMark[i] = false; ngCnt++; }
                else checkMark[i] = true;
            }
            // ng가 2개 이상이면 Manual Mark 발생
            if (ngCnt == 1)
            {
                XY virtualXY = new XY();
                ngPos = -1;
                // 1st두개 다 찾았을때
                if (checkMark[0] && checkMark[1])
                {
                    XY gap = new XY();
                    gap.X = TargetPos[1].OutputXYT.X - TargetPos[0].OutputXYT.X;
                    gap.Y = TargetPos[1].OutputXYT.Y - TargetPos[0].OutputXYT.Y;

                    if (!checkMark[2]) { ngPos = 2; virtualXY = GetVirtualMarkPos(2, TargetPos[3].OutputXYT.ToXY(), gap, AdjustTarPixel); }
                    else if (!checkMark[3]) { ngPos = 3; virtualXY = GetVirtualMarkPos(3, TargetPos[2].OutputXYT.ToXY(), gap, AdjustTarPixel); }
                }
                // 2nd 두개 다 찾았을때
                else
                {
                    XY gap = new XY();
                    gap.X = TargetPos[2].OutputXYT.X - TargetPos[3].OutputXYT.X;
                    gap.Y = TargetPos[2].OutputXYT.Y - TargetPos[3].OutputXYT.Y;

                    if (!checkMark[0]) { ngPos = 0; virtualXY = GetVirtualMarkPos(0, TargetPos[1].OutputXYT.ToXY(), gap, AdjustTarPixel); }
                    else if (!checkMark[1]) { ngPos = 1; virtualXY = GetVirtualMarkPos(1, TargetPos[0].OutputXYT.ToXY(), gap, AdjustTarPixel); }
                }

                // 값을 바꿔주므니다.
                TargetPos[ngPos].OutputXYT.X = virtualXY.X;
                TargetPos[ngPos].OutputXYT.Y = virtualXY.Y;

                if (TargetPos[ngPos].Tool != null)
                    (TargetPos[ngPos].Tool.ModObject as ToolObjectBase).CreatSkipResultGraphics(virtualXY);
            }
        }


        private bool CheckLCheckObjProcess()
        {

            /* 대칭으로 못찾은건 메뉴얼 마크 띄워야함. */
            if ((!DObjectLength_01_judge && !DObjectLength_23_judge) || (!DObjectLength_12_judge && !DObjectLength_30_judge)) { SetToolManualStatus(); return false; }
            /* 포인트가 겹치는 경우는 그 포인트를 가상으로 돌려서 재계산 */
            else if (!DObjectLength_01_judge && !DObjectLength_30_judge) { ObjectPos[0].SuccessIndex = -1; errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_01_judge && !DObjectLength_12_judge) { ObjectPos[1].SuccessIndex = -1; errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_23_judge && !DObjectLength_12_judge) { ObjectPos[2].SuccessIndex = -1; errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_23_judge && !DObjectLength_30_judge) { ObjectPos[3].SuccessIndex = -1; errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcLJWProcess(); }
            /* 한라인이면 애매하므로 ConfirmRemovePoint함수에서 정해서 재계산*/
            else if (!DObjectLength_01_judge) { ConfirmRemoveObjPoint(0, 1); errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_12_judge) { ConfirmRemoveObjPoint(1, 2); errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_23_judge) { ConfirmRemoveObjPoint(2, 3); errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DObjectLength_30_judge) { ConfirmRemoveObjPoint(3, 0); errorCodeLami["Err_WND_LENGTH_NG"] = true; return CalcLJWProcess(); }

            return true;
        }

        private bool CheckLCheckTarProcess()
        {
            /* 대칭으로 못찾은건 메뉴얼 마크 띄워야함. */
            if ((!DTargetLength_01_judge && !DTargetLength_23_judge) || (!DTargetLength_12_judge && !DTargetLength_30_judge)) { SetToolManualStatus(); return false; }
            /* 포인트가 겹치는 경우는 그 포인트를 가상으로 돌려서 재계산 */
            else if (!DTargetLength_01_judge && !DTargetLength_30_judge) { TargetPos[0].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DTargetLength_01_judge && !DTargetLength_12_judge) { TargetPos[1].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DTargetLength_23_judge && !DTargetLength_12_judge) { TargetPos[2].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DTargetLength_23_judge && !DTargetLength_30_judge) { TargetPos[3].SuccessIndex = -1; errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            /* 한라인이면 애매하므로 ConfirmRemovePoint함수에서 정해서 재계산*/
            else if (!DTargetLength_01_judge) { ConfirmRemoveTarPoint(0, 1); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DTargetLength_12_judge) { ConfirmRemoveTarPoint(1, 2); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DTargetLength_23_judge) { ConfirmRemoveTarPoint(2, 3); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }
            else if (!DTargetLength_30_judge) { ConfirmRemoveTarPoint(3, 0); errorCodeLami["Err_PNL_LENGTH_NG"] = true; return CalcLJWProcess(); }

            return true;
        }

        public void SetToolManualStatus()
        {
            var Lower_1st_L = InputValues["Lower_1st_L"] as IPointResult;
            var Lower_1st_R = InputValues["Lower_1st_R"] as IPointResult;
            var Lower_2st_L = InputValues["Lower_2st_L"] as IPointResult;
            var Lower_2st_R = InputValues["Lower_2st_R"] as IPointResult;

            var Upper_1st_L = InputValues["Upper_1st_L"] as IPointResult;
            var Upper_1st_R = InputValues["Upper_1st_R"] as IPointResult;
            var Upper_2st_L = InputValues["Upper_2st_L"] as IPointResult;
            var Upper_2st_R = InputValues["Upper_2st_R"] as IPointResult;

            if (!(DObjectLength_01_judge && DObjectLength_23_judge && DObjectLength_12_judge && DObjectLength_30_judge &&
                DTargetLength_01_judge && DTargetLength_23_judge && DTargetLength_12_judge && DTargetLength_30_judge))
            {
                System.Threading.Thread.Sleep(500);

                Lower_1st_L.DisplayObj.Judgement = (uint)Judgement.None;
                Lower_1st_R.DisplayObj.Judgement = (uint)Judgement.None;
                Lower_2st_L.DisplayObj.Judgement = (uint)Judgement.None;
                Lower_2st_R.DisplayObj.Judgement = (uint)Judgement.None;

                Upper_1st_L.DisplayObj.Judgement = (uint)Judgement.None;
                Upper_1st_R.DisplayObj.Judgement = (uint)Judgement.None;
                Upper_2st_L.DisplayObj.Judgement = (uint)Judgement.None;
                Upper_2st_R.DisplayObj.Judgement = (uint)Judgement.None;
            }
            else if (DObjectLength_01_judge && DObjectLength_23_judge && DObjectLength_12_judge && DObjectLength_30_judge &&
              DTargetLength_01_judge && DTargetLength_23_judge && DTargetLength_12_judge && DTargetLength_30_judge)
            {
                // 다 성공이니깐 Return
                return;
            }

            // kds delete 2019.11.04 : InputValues의 Type입에 따라 Tool이 null 
            // 처리로직 및 기능 재확인 필요함.
            if (!DObjectLength_01_judge)
            {
                if (useStagePos == UseStagePos.UpperUse)
                {
                    Upper_1st_R.Tool.ProcMode = ProcessMode.Manual; (Upper_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_1st_L.Tool.ProcMode = ProcessMode.Manual; (Upper_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Upper_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                else
                {
                    Lower_1st_R.Tool.ProcMode = ProcessMode.Manual; (Lower_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_1st_L.Tool.ProcMode = ProcessMode.Manual; (Lower_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Lower_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }
            if (!DObjectLength_12_judge)
            {
                if (useStagePos == UseStagePos.UpperUse)
                {
                    Upper_1st_L.Tool.ProcMode = ProcessMode.Manual; (Upper_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_2st_L.Tool.ProcMode = ProcessMode.Manual; (Upper_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Upper_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                else
                {
                    Lower_1st_L.Tool.ProcMode = ProcessMode.Manual; (Lower_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_2st_L.Tool.ProcMode = ProcessMode.Manual; (Lower_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Lower_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }
            if (!DObjectLength_23_judge)
            {
                if (useStagePos == UseStagePos.UpperUse)
                {
                    Upper_2st_L.Tool.ProcMode = ProcessMode.Manual; (Upper_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_2st_R.Tool.ProcMode = ProcessMode.Manual; (Upper_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Upper_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                else
                {
                    Lower_2st_L.Tool.ProcMode = ProcessMode.Manual; (Lower_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_2st_R.Tool.ProcMode = ProcessMode.Manual; (Lower_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Lower_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }
            if (!DObjectLength_30_judge)
            {
                if (useStagePos == UseStagePos.UpperUse)
                {
                    Upper_2st_R.Tool.ProcMode = ProcessMode.Manual; (Upper_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_1st_R.Tool.ProcMode = ProcessMode.Manual; (Upper_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Upper_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                else
                {
                    Lower_2st_R.Tool.ProcMode = ProcessMode.Manual; (Lower_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_1st_R.Tool.ProcMode = ProcessMode.Manual; (Lower_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Lower_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }

            if (!DTargetLength_01_judge)
            {
                if (useStagePos == UseStagePos.LowerUse)
                {
                    Upper_1st_R.Tool.ProcMode = ProcessMode.Manual; (Upper_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_1st_L.Tool.ProcMode = ProcessMode.Manual; (Upper_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Upper_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                else
                {
                    Lower_1st_R.Tool.ProcMode = ProcessMode.Manual; (Lower_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_1st_L.Tool.ProcMode = ProcessMode.Manual; (Lower_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Lower_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }
            if (!DTargetLength_12_judge)
            {
                if (useStagePos == UseStagePos.LowerUse)
                {
                    Upper_1st_L.Tool.ProcMode = ProcessMode.Manual; (Upper_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_2st_L.Tool.ProcMode = ProcessMode.Manual; (Upper_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Upper_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                else
                {
                    Lower_1st_L.Tool.ProcMode = ProcessMode.Manual; (Lower_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_2st_L.Tool.ProcMode = ProcessMode.Manual; (Lower_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Lower_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }
            if (!DTargetLength_23_judge)
            {
                if (useStagePos == UseStagePos.LowerUse)
                {
                    Upper_2st_L.Tool.ProcMode = ProcessMode.Manual; (Upper_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_2st_R.Tool.ProcMode = ProcessMode.Manual; (Upper_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Upper_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                else
                {
                    Lower_2st_L.Tool.ProcMode = ProcessMode.Manual; (Lower_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_2st_R.Tool.ProcMode = ProcessMode.Manual; (Lower_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Lower_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }
            if (!DTargetLength_30_judge)
            {
                if (useStagePos == UseStagePos.LowerUse)
                {
                    Upper_2st_R.Tool.ProcMode = ProcessMode.Manual; (Upper_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_1st_R.Tool.ProcMode = ProcessMode.Manual; (Upper_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Upper_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Upper_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                else
                {
                    Lower_2st_R.Tool.ProcMode = ProcessMode.Manual; (Lower_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_1st_R.Tool.ProcMode = ProcessMode.Manual; (Lower_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    Lower_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Lower_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }

        }

        private int GetVirtualObjIndex()
        {
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < ObjectPos.Count(); i++)
            {
                if (ObjectPos[i].SuccessIndex == -1) { return i; }
            }

            return -1;
        }
        private int GetVirtualTarIndex()
        {
            // 일단 스킵으로 들어온거 확인.
            for (int i = 0; i < TargetPos.Count(); i++)
            {
                if (TargetPos[i].SuccessIndex == -1) { return i; }
            }

            return -1;
        }

        private void ConfirmRemoveObjPoint(int a, int b)
        {
            /* 첫번째 마크면 첫번째꺼, 둘다 첫번째 마크면 인식율로, ㅇㅋ? */

            // 일단 작은놈이 승자
            if (ObjectPos[a].SuccessIndex < ObjectPos[b].SuccessIndex) ObjectPos[b].SuccessIndex = -1;
            else if (ObjectPos[a].SuccessIndex > ObjectPos[b].SuccessIndex) ObjectPos[a].SuccessIndex = -1;
            // 같으면 스코어 높은 놈이승자
            else
            {
                if (ObjectPos[a].Score > ObjectPos[b].Score) ObjectPos[b].SuccessIndex = -1;
                else ObjectPos[a].SuccessIndex = -1;
            }
        }

        private void ConfirmRemoveTarPoint(int a, int b)
        {
            /* 첫번째 마크면 첫번째꺼, 둘다 첫번째 마크면 인식율로, ㅇㅋ? */

            // 일단 작은놈이 승자
            if (TargetPos[a].SuccessIndex < TargetPos[b].SuccessIndex) TargetPos[b].SuccessIndex = -1;
            else if (TargetPos[a].SuccessIndex > TargetPos[b].SuccessIndex) TargetPos[a].SuccessIndex = -1;
            // 같으면 스코어 높은 놈이승자
            else
            {
                if (TargetPos[a].Score > TargetPos[b].Score) TargetPos[b].SuccessIndex = -1;
                else TargetPos[a].SuccessIndex = -1;
            }
        }

        [field: NonSerialized]
        double limitX;
        [field: NonSerialized]
        double limitY;
        [field: NonSerialized]
        double limitT;
        [field: NonSerialized]
        XYT offset;

        [field: NonSerialized]
        string beforeCellID;
        private bool CalcLJWProcess()
        {
            if (useObj3P) Check3PAligObject();
            if (useTar3P) Check3PAligTarget();

            AlignType AlignMode = AlignType.Tar_Obj_4P; // 추후 타 Align에서 '이 부분' 수정하여 분기 가능!
            string[] AlignModeSplit = AlignMode.ToString().Split(new string[] { "_" }, StringSplitOptions.None);
            Type type = typeof(Algo90DBendedLami_4P_TarObjObject);
            UseTarget = false;
            string model = SystemModel.GetCurModel();
            offset = new XYT(0, 0, 0);

            for (int cnt = 0; cnt < AlignModeSplit.Length; cnt++) // 나중 공용 목적
            {
                if (AlignModeSplit[cnt] == "Tar")
                {
                    UseTarget = true;
                }
            }

            int CntPos = int.Parse(Regex.Replace(AlignMode.ToString(), @"\D", ""));

            #region 3> UploadFDC(Vision좌표계) + FDC 'Key'없음 Error 처리
            if (UploadFDCdata_Pos(AlignMode, UseTarget, TargetPos, ObjectPos, M_dicVisionValues, ref errorCodeLami) == false) return false;
            #endregion

            #region 4> CalDataConfirm -> 내부 Data가 없으면 Error 처리 -> Lower/Upper Stage에 따른 처리.
            if (!CalDataConfirm(type, UseTarget, CntPos, ref ObjCalData, ref TarCalData, ref errorCodeLami)) return false;
            #endregion

            #region 5> ModelData 가져오기
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo90DBendedLami_4P_TarObjModelParams;
            if (mParams.LimitX == null)
                mParams.LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)+5.0);
            if (mParams.LimitY == null)
                mParams.LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)+5.0);
            if (mParams.LimitT == null)
                mParams.LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)+5.0);

            limitX = (double)mParams.LimitX.Value;
            limitY = (double)mParams.LimitY.Value;
            limitT = (double)mParams.LimitT.Value;
            #endregion

            #region 6> 'Vision 좌표계' 투입용. for 'GetV2R()' 매개변수 투입용 
            // 임시 '생성자'
            //TargetPos = new MatchingRstData[4];
            //ObjectPos = new MatchingRstData[4];

            //for (int temp = 0; temp < 4; temp++)
            //{
            //    TargetPos[temp] = new MatchingRstData();
            //    ObjectPos[temp] = new MatchingRstData();

            //    TargetPos[temp].OutputXYT = new XYT();
            //    ObjectPos[temp].OutputXYT = new XYT(0, 0, 0);
            //}

            // PNL_Pos: Target, WND_Pos: Object
            ArrayVisionPos(AlignMode, CntPos, UseTarget, TargetPos, ObjectPos, ref PNL_Pos, ref WND_Pos);
            #endregion

            #region 7> '촬상 CurPos' 투입용
            if (!ArrayCurGrabPos(AlignMode, CntPos, UseTarget, ref TarCurGrabPos, ref ObjCurGrabPos, plcValues, ref errorCodeLami)) return false;
            #endregion

            #region 직사각형 좌표 산출 준비
            // 5> CoorPos(+ FixPos 계산)
            // 제품 DesignValue에 대한 Off-Set(Obj==PNL) <- 사용하지 않아도 넣자! '0'이라도 Coor에서 계산하므로...
            double.TryParse(mParams.DesignValuePlus_Tar_X.Value.ToString(), out sDesignValuePlus_Tar_X);
            double.TryParse(mParams.DesignValuePlus_Tar_Y.Value.ToString(), out sDesignValuePlus_Tar_Y);

            // 제품 Design Offset Value 
            XY[] PnlDesignVal = new XY[4];
            XY[] WndDesignVal = new XY[4];
            ArrayDesignValue(type, UseTarget, ref WndDesignVal, ref PnlDesignVal);
            #endregion

            #region 8> Coordinate계산
            if (!ReCalCoorPos(model, ref tarCoorPos, ref objCoorPos, PNL_Pos, WND_Pos, ObjCurGrabPos, TarCurGrabPos, UseStagePos)) //<- Test 꼭 하자!
            {
                errorCodeLami["Err_obtain_CalPosition_Value"] = false;
                return false;
            }

            for (int temp = 0; temp < tarLineTheta.Length; temp++)
            {
                tarLineTheta[temp] = 0; objLineTheta[temp] = 0;
            }

            // DesignValue값 적용 
            //ThetaCalType trapeoidCalType = ThetaCalType.UseShort_2L; // Panel은 '사다리꼴'로 무조건 단축으로 계산!
            if (UseDesignValue_tar == UseDesignValue.Use)
            {
                CalTheta(AlignMode, tarCoorPos, ref tarLineTheta); // object에 대한 theta 구현
                AddDisignValue(PnlDesignVal, tarLineTheta, ref tarCoorPos);
            }
            #endregion

            #region 9> RevX,Y,T 계산
            // Object, Target에 대한 X,Y,T 산출
            // 각 '변'의 Theta성분 
            CalTheta(AlignMode, objCoorPos, ref objLineTheta); // obj의 theta 성분.
            CalTheta(AlignMode, tarCoorPos, ref tarLineTheta); // tar의 theta 성분.

            // Theta 성분 산출
            CalRevTheta(AlignMode, ThetaCalType, objLineTheta, ref ObjRevPos);
            CalRevTheta(AlignMode, ThetaCalType /*trapeoidCalType*/, tarLineTheta, ref TarRevPos); // '사다리꼴'은 무조건 단축 Theta

            // X,Y 성분 산출
            CalRevXY(AlignMode, CntPos, tarCoorPos, objCoorPos, ref ObjRevPos, ref TarRevPos);

            // Off-Set 계산, [Do] PLC에서 Off-Set 받아오는 것!
            double.TryParse(mParams.vOffSet_X.Value.ToString(), out V_Offset_X);
            double.TryParse(mParams.vOffSet_X.Value.ToString(), out V_Offset_Y);
            double.TryParse(mParams.vOffSet_X.Value.ToString(), out V_Offset_T);

            if (!GainOffSet(plcValues, ref offset))
            {
                errorCodeLami["Err_obtain_Offset_Value"] = false;
                return false;
            }
            else
            {
                // Vision Off-Set 추가 
                offset.X += V_Offset_X;
                offset.Y += V_Offset_Y;
                offset.T += V_Offset_T;
            }

            // Off-set 반영, Target Pos 계산 -> OffSet 고려한 Target Pos 계산
            TarRevPos = ApplyTargetOffset(TarRevPos, offset);
            UploadFDCdata_tar(TarRevPos, errorCodeLami);

            // RevT산출
            RevPos.T = TarRevPos.T - ObjRevPos.T;

            // DriftXY 산출
            double DriftX = Math.Cos(RevPos.T) * ObjRevPos.X - Math.Sin(RevPos.T) * ObjRevPos.Y;
            double DriftY = Math.Sin(RevPos.T) * ObjRevPos.X + Math.Cos(RevPos.T) * ObjRevPos.Y;

            // 최종 RevPos산출, PI * rad = 180도, 1 rad = 180 / PI 
            RevPos.X = TarRevPos.X - DriftX;
            RevPos.Y = TarRevPos.Y - DriftY;
            RevPos.T = NormalizeTheta(RevPos.T) / rad;
            RevPos.T *= -1;
            if (UseStagePos.LowerUse == UseStagePos)
            {
                RevPos.T *= -1;
            }
            #endregion

            #region 10> FDC Upload
            var fdcRev = RevPos - offset;
            //UploadFDCdata_rev(RevPos, errorCodeLami);
            UploadFDCdata_OnlyVisionRev(fdcRev);
            if (uploadFDCdata_Temp() == false) return false;
            #endregion

            #region 11> L-Check
            // [하기 Method 사용법] (Coordinate 좌표, 구하고자하는 길이의 각 포인트를 이름의 마지막에 넣음) <- ex) point0, point1과의 길이 xxxxx01
            Judgement_LCheck = new Dictionary<string, bool>();
            DTargetLength_01_rst = dTargetLength_01 = L_Check(tarCoorPos, nameof(dTargetLength_01)); Judgement_LCheck[nameof(dTargetLength_01) + "_Judgement"] = true;
            DTargetLength_12_rst = dTargetLength_12 = L_Check(tarCoorPos, nameof(dTargetLength_12)); Judgement_LCheck[nameof(dTargetLength_12) + "_Judgement"] = true;
            DTargetLength_23_rst = dTargetLength_23 = L_Check(tarCoorPos, nameof(dTargetLength_23)); Judgement_LCheck[nameof(dTargetLength_23) + "_Judgement"] = true;
            DTargetLength_30_rst = dTargetLength_30 = L_Check(tarCoorPos, nameof(dTargetLength_30)); Judgement_LCheck[nameof(dTargetLength_30) + "_Judgement"] = true;

            DObjectLength_01_rst = dObjectLength_01 = L_Check(objCoorPos, nameof(dObjectLength_01)); Judgement_LCheck[nameof(dObjectLength_01) + "_Judgement"] = true;
            DObjectLength_12_rst = dObjectLength_12 = L_Check(objCoorPos, nameof(dObjectLength_12)); Judgement_LCheck[nameof(dObjectLength_12) + "_Judgement"] = true;
            DObjectLength_23_rst = dObjectLength_23 = L_Check(objCoorPos, nameof(dObjectLength_23)); Judgement_LCheck[nameof(dObjectLength_23) + "_Judgement"] = true;
            DObjectLength_30_rst = dObjectLength_30 = L_Check(objCoorPos, nameof(dObjectLength_30)); Judgement_LCheck[nameof(dObjectLength_30) + "_Judgement"] = true;

            // 13> FDC L-Check Upload -> fail시 Waning 처리
            UploadFDCdata_Pitch_tar(AlignMode, dTargetLength_01, dTargetLength_12, dTargetLength_23, dTargetLength_30, errorCodeLami);
            UploadFDCdata_Pitch_obj(AlignMode, dObjectLength_01, dObjectLength_12, dObjectLength_23, dObjectLength_30, errorCodeLami);

            // L-Check
            Type ModelParamType = typeof(Algo90DBendedLami_4P_TarObjModelParams);

            DObjectLength_01_judge = L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_01), dObjectLength_01, Judgement_LCheck, errorCodeLami, false);
            DObjectLength_12_judge = L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_12), dObjectLength_12, Judgement_LCheck, errorCodeLami, false);
            DObjectLength_23_judge = L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_23), dObjectLength_23, Judgement_LCheck, errorCodeLami, false);
            DObjectLength_30_judge = L_Check_Judgement(ModelParamType, model, nameof(dObjectLength_30), dObjectLength_30, Judgement_LCheck, errorCodeLami, false);

            DTargetLength_01_judge = L_Check_Judgement(ModelParamType, model, nameof(dTargetLength_01), dTargetLength_01, Judgement_LCheck, errorCodeLami);
            DTargetLength_12_judge = L_Check_Judgement(ModelParamType, model, nameof(dTargetLength_12), dTargetLength_12, Judgement_LCheck, errorCodeLami);
            DTargetLength_23_judge = L_Check_Judgement(ModelParamType, model, nameof(dTargetLength_23), dTargetLength_23, Judgement_LCheck, errorCodeLami);
            DTargetLength_30_judge = L_Check_Judgement(ModelParamType, model, nameof(dTargetLength_30), dTargetLength_30, Judgement_LCheck, errorCodeLami);


            // Align 방식 
            // [Upper, Left]                      [Upper, right]
            //  2 -------------------------------- 3 
            //    | [Left]                        l
            //    |                               l
            //    l                               l
            //    |    --> (WND 투입)              |  <-- (PNL 투입)
            //    l                               l         
            //    l [Right]                       l
            //  1 -------------------------------- 0 
            //  [Lower, Left]                     [Lower, Right]
            //     '작업자' 방향

            #endregion

            return true;
        }
        #endregion

        #region [override methode]

        public IPointResult CreateValues(string key)
        {
            IPointResult result = null;

            if (!InputValues.ContainsKey(key))
            {
                return result;
            }

            if (InputValues[key] is MatchingRstData)
            {
                result = new MatchingRstData();
            }
            else if (InputValues[key] is LineCrossRstData)
            {
                result = new LineCrossRstData();
            }

            return result;
        }
        bool useObj3P;
        bool useTar3P;
        OnOff usePNL3P;
        OnOff useWND3P;
        public override bool Run()
        {
            #region 뭔지 몰라도 주석이네...왜 안써...
            //9000.A   common
            //9001.3   ch1
            //9002.3   ch2
            //0: clamp
            //1: gpl
            // GPL(Upper구동) / Clamp(Lower구동) 공용화 사용시 plc 신호에 따라 구동부 정보 변경토록 처리 (19.12.07 JTJ)
            // 전체 호기에 적용하게 되면 사용. 이거 적용하게 되면 Properties 에서 UseStagePos binding 주석처리할것.
            //if ((bool)plcValues["Gpl"].CurValue == false)
            //{
            //    UseStagePos = UseStagePos.LowerUse;
            //}
            //else if ((bool)plcValues["Gpl"].CurValue == true)
            //{
            //    UseStagePos = UseStagePos.UpperUse;
            //}
            #endregion

            #region 1> Algorithm 초기 작업
            MakeArray();
            UpdatePLCIOs();
            StartTimer();

            string strPos = "Left";
            
            if (PlcValues.ContainsKey("InputPos"))
            {
                strPos = (bool)PlcValues["InputPos"].CurValue ? "Right" : "Left";
            }


            AlignType AlignMode = AlignType.Tar_Obj_4P; // 추후 타 Align에서 '이 부분' 수정하여 분기 가능!
            string[] AlignModeSplit = AlignMode.ToString().Split(new string[] { "_" }, StringSplitOptions.None);
            UseTarget = false;

            for (int cnt = 0; cnt < AlignModeSplit.Length; cnt++) // 나중 공용 목적
            {
                if (AlignModeSplit[cnt] == "Tar")
                {
                    UseTarget = true;
                }
            }

            int CntPos = int.Parse(Regex.Replace(AlignMode.ToString(), @"\D", ""));

            // From PLC, 'productID' 
            string productID = "0";
            string model = SystemModel.GetCurModel();
            bool existID = true;

            //if (plcValues.ContainsKey("CellID"))
            //{
            //    sourceID = (string)plcValues["CellID"].CurValue;
            //}
            //else
            //{
            //    existID = false;
            //    productID = GetMakeID(10);
            //}

            Type type = typeof(Algo90DBendedLami_4P_TarObjObject);

            // AlgoError 초기화
            errorCodeLami = new Dictionary<string, bool>();
            InitDefinedError(ref errorCodeLami);
            #endregion

            #region 2> Obj/Tar 유,무 확인 + array 투입 
            //  kds Insert 2019.11.04 : InputValues의 Type입에 따라 ObjectPos & TargetPos 변경
            //  ljw Insert 2019.11.28 : 상부 or 하부 stage 사용하느냐? Why? Rotation Center 공유... 따라서 Tar/Obj 구분 작업 


            for (int temp = 0; temp < 4; temp++)
            {
                switch (useStagePos)
                {
                    case UseStagePos.UpperUse:
                        TargetPos[temp] = CreateValues("Lower_1st_R");
                        ObjectPos[temp] = CreateValues("Upper_1st_R");

                        if (TargetPos[temp] == null || ObjectPos[temp] == null) // ljw(2019.11.28), key값이 없을때의 예외 처리 안함으로 추가
                        {
                            errorCodeLami["Err_obtain_VisionPos_Value"] = false;
                            return false;
                        }

                        break;

                    case UseStagePos.LowerUse:
                        TargetPos[temp] = CreateValues("Upper_1st_R");
                        ObjectPos[temp] = CreateValues("Lower_1st_R");

                        if (TargetPos[temp] == null || ObjectPos[temp] == null) // ljw(2019.11.28), key값이 없을때의 예외 처리 안함으로 추가
                        {
                            errorCodeLami["Err_obtain_VisionPos_Value"] = false;
                            return false;
                        }
                        break;
                }
            }

            if (PosConfirm(AlignMode, ref TargetPos, ref ObjectPos, ref errorCodeLami, useStagePos) == false) return false;
            #endregion

            #region 3Point 관련 추가.... jyh

            // 옵션 가지고 오기
            var algoOption = Options as Algo90DBendedLami_4P_TarObjModelOptions;
            usePNL3P = (OnOff)algoOption.UsePanel3PointAlign.Value;
            useWND3P = (OnOff)algoOption.UseWindow3PointAlign.Value;

            if (useStagePos == UseStagePos.UpperUse)
            {
                useObj3P = useWND3P == OnOff.On ? true : false;
                useTar3P = usePNL3P == OnOff.On ? true : false;
            }
            else
            {
                useObj3P = usePNL3P == OnOff.On ? true : false;
                useTar3P = useWND3P == OnOff.On ? true : false;
            }

            // 못찾은 마크가 너무 많으면 메뉴얼 마크 띄워주는게 마즘마즘
            // 메뉴얼 마크 찍고 한번 돌고 오면 SuccessIndex == 0 이 되어서 온담..
            if (!CheckManualMark()) return false;

            // 연산하는코드가 다 들어가있다....3P도 첫줄에 넣어놓음.
            if (!CalcLJWProcess()) return false;

            // 길이 체크하는 코드임..3P로 바꾸거나 메뉴얼 마크로 바까부림
            // 메뉴얼 마크 찍고 한번 돌고 온거면 그냥 에러를 친다...어떻할까?또 리트라이해야함?
            // 작업자가 잘못찍은건딩 안들어오것지...???
            // 귀찮타...그냥 계산 두번 하게 하자...



            bool objRst = useObj3P ? CheckLCheckObjProcess() : true;
            bool tarRst = useTar3P ? CheckLCheckTarProcess() : true;

            if (!objRst || !tarRst) return false;

            // 마지막으로 L-Check 함 더 한다.(이거 왜 했더라???기어기가 안난다...오늘한건데..)
            SetToolManualStatus();
            #endregion

            #region 12> Log 및 결과값
            // 15> 최종 결과 
            XYT retVal = new XYT
            {
                X = RevPos.X,
                Y = RevPos.Y,
                T = (RevPos.T),
            };


            string proc = string.Empty;
            int idxObj = GetVirtualObjIndex();
            int idxTar = GetVirtualTarIndex();

            if (idxObj == -1 && idxTar == -1) proc = "4P";
            else if (idxObj == -1)
            {
                if (AdjustTarPixel.X == 0 && AdjustTarPixel.Y == 0)
                    errorCodeLami["AdjustValueNotEnough"] = false;
                else
                    errorCodeLami["3PAlign"] = false;
                proc = string.Format("3P({0}{1} Skip)", useStagePos == UseStagePos.UpperUse ? "P" : "W", idxTar);
            }
            else if (idxTar == -1)
            {
                if (AdjustObjPixel.X == 0 && AdjustObjPixel.Y == 0)
                    errorCodeLami["AdjustValueNotEnough"] = false;
                else
                    errorCodeLami["3PAlign"] = false;

                proc = string.Format("3P({0}{1} Skip)", useStagePos == UseStagePos.UpperUse ? "W" : "P", idxObj);
            }
            else
            {
                if ((AdjustTarPixel.X == 0 && AdjustTarPixel.Y == 0 ) || (AdjustObjPixel.X == 0 && AdjustObjPixel.Y == 0))
                    errorCodeLami["AdjustValueNotEnough"] = false;
                else
                    errorCodeLami["3PAlign"] = false;

                proc = string.Format("3P({0}{1},{2}{3} Skip)", useStagePos == UseStagePos.UpperUse ? "P" : "W", idxTar, useStagePos == UseStagePos.UpperUse ? "W" : "P", idxObj);
            }


            l_Check_JudgeMent = true;   // 안쓰는데 로그가 빨개요
            AlgoRst = new Algo90DBendedLami_4PTarObjResult
            {
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Name = name,
                ID = SourceID,
                InputPos = strPos,
                AlgoProc = proc,

                // 최종 결과 값
                RevOffsetX = Math.Round(retVal.X, 3),
                RevOffsetY = Math.Round(retVal.Y, 3),
                RevOffsetT = Math.Round(retVal.T, 3),

                // Target 결과 값 
                Target_PosX = Math.Round(TarRevPos.X, 3),
                Target_PosY = Math.Round(TarRevPos.Y, 3),
                Target_PosT = Math.Round(NormalizeTheta(TarRevPos.T) / rad, 3),

                // Object 결과 값
                Object_PosX = Math.Round(ObjRevPos.X, 3),
                Object_PosY = Math.Round(ObjRevPos.Y, 3),
                Object_PosT = Math.Round(NormalizeTheta(ObjRevPos.T) / rad, 3),

                // 각 성분의 Theta값 
                T01_TargetTheta = Math.Round(tarLineTheta[0] / rad, 3),
                T23_TargetTheta = Math.Round(tarLineTheta[2] / rad, 3),
                T12_TargetTheta = Math.Round(tarLineTheta[1] / rad, 3),
                T03_TargetTheta = Math.Round(tarLineTheta[3] / rad, 3),

                T01_ObjectTheta = Math.Round(objLineTheta[0] / rad, 3),
                T23_ObjectTheta = Math.Round(objLineTheta[2] / rad, 3),
                T12_ObjectTheta = Math.Round(objLineTheta[1] / rad, 3),
                T03_ObjectTheta = Math.Round(objLineTheta[3] / rad, 3),

                DTargetLength_01 = Math.Round(dTargetLength_01, 3),
                DTargetLength_12 = Math.Round(dTargetLength_12, 3),
                DTargetLength_23 = Math.Round(dTargetLength_23, 3),
                DTargetLength_30 = Math.Round(dTargetLength_30, 3),

                DObjectLength_01 = Math.Round(dObjectLength_01, 3),
                DObjectLength_12 = Math.Round(dObjectLength_12, 3),
                DObjectLength_23 = Math.Round(dObjectLength_23, 3),
                DObjectLength_30 = Math.Round(dObjectLength_30, 3),

                // PLC Off-Set값 
                OffsetX = Math.Round(offset.X, 3),
                OffsetY = Math.Round(offset.Y, 3),
                OffsetT = Math.Round(offset.T, 3),

                IsExistID = existID,
                IslcheckJudgement = l_Check_JudgeMent,
                //IsJudgement = JudgeMent,

                Pnl_1st_px_Lx = Math.Round(TargetPos[1].OutputXYT.X, 3),
                Pnl_1st_px_Ly = Math.Round(TargetPos[1].OutputXYT.Y, 3),
                Pnl_1st_px_Rx = Math.Round(TargetPos[0].OutputXYT.X, 3),
                Pnl_1st_px_Ry = Math.Round(TargetPos[0].OutputXYT.Y, 3),
                Pnl_2nd_px_Lx = Math.Round(TargetPos[2].OutputXYT.X, 3),
                Pnl_2nd_px_Ly = Math.Round(TargetPos[2].OutputXYT.Y, 3),
                Pnl_2nd_px_Rx = Math.Round(TargetPos[3].OutputXYT.X, 3),
                Pnl_2nd_px_Ry = Math.Round(TargetPos[3].OutputXYT.Y, 3),

                Wnd_1st_px_Lx = Math.Round(ObjectPos[1].OutputXYT.X, 3),
                Wnd_1st_px_Ly = Math.Round(ObjectPos[1].OutputXYT.Y, 3),
                Wnd_1st_px_Rx = Math.Round(ObjectPos[0].OutputXYT.X, 3),
                Wnd_1st_px_Ry = Math.Round(ObjectPos[0].OutputXYT.Y, 3),
                Wnd_2nd_px_Lx = Math.Round(ObjectPos[2].OutputXYT.X, 3),
                Wnd_2nd_px_Ly = Math.Round(ObjectPos[2].OutputXYT.Y, 3),
                Wnd_2nd_px_Rx = Math.Round(ObjectPos[3].OutputXYT.X, 3),
                Wnd_2nd_px_Ry = Math.Round(ObjectPos[3].OutputXYT.Y, 3),

                Pnl_1st_rt_Lx = Math.Round(tarCoorPos[1].X, 3),
                Pnl_1st_rt_Ly = Math.Round(tarCoorPos[1].Y, 3),
                Pnl_1st_rt_Rx = Math.Round(tarCoorPos[0].X, 3),
                Pnl_1st_rt_Ry = Math.Round(tarCoorPos[0].Y, 3),
                Pnl_2nd_rt_Lx = Math.Round(tarCoorPos[2].X, 3),
                Pnl_2nd_rt_Ly = Math.Round(tarCoorPos[2].Y, 3),
                Pnl_2nd_rt_Rx = Math.Round(tarCoorPos[3].X, 3),
                Pnl_2nd_rt_Ry = Math.Round(tarCoorPos[3].Y, 3),

                Wnd_1st_rt_Lx = Math.Round(objCoorPos[1].X, 3),
                Wnd_1st_rt_Ly = Math.Round(objCoorPos[1].Y, 3),
                Wnd_1st_rt_Rx = Math.Round(objCoorPos[0].X, 3),
                Wnd_1st_rt_Ry = Math.Round(objCoorPos[0].Y, 3),
                Wnd_2nd_rt_Lx = Math.Round(objCoorPos[2].X, 3),
                Wnd_2nd_rt_Ly = Math.Round(objCoorPos[2].Y, 3),
                Wnd_2nd_rt_Rx = Math.Round(objCoorPos[3].X, 3),
                Wnd_2nd_rt_Ry = Math.Round(objCoorPos[3].Y, 3),

                Diff_1st_Lx = Math.Round(tarCoorPos[1].X - objCoorPos[1].X, 3),
                Diff_1st_Ly = Math.Round(tarCoorPos[1].Y - objCoorPos[1].Y, 3),
                Diff_1st_Rx = Math.Round(tarCoorPos[0].X - objCoorPos[0].X, 3),
                Diff_1st_Ry = Math.Round(tarCoorPos[0].Y - objCoorPos[0].Y, 3),
                Diff_2nd_Lx = Math.Round(tarCoorPos[2].X - objCoorPos[2].X, 3),
                Diff_2nd_Ly = Math.Round(tarCoorPos[2].Y - objCoorPos[2].Y, 3),
                Diff_2nd_Rx = Math.Round(tarCoorPos[3].X - objCoorPos[3].X, 3),
                Diff_2nd_Ry = Math.Round(tarCoorPos[3].Y - objCoorPos[3].Y, 3),
            };

            StopTimer();

            SystemLogger.WriteAlignDBLog(name, AlgoRst);

            // 할당 m_DicVisionValue -> Action의 Properties, for M_DicVisionValue에 할당
            visionValues["TargetPosX1"].NextValue = 0;
            visionValues["TargetPosX2"].NextValue = 0;
            visionValues["TargetPosY1"].NextValue = 0;
            visionValues["TargetPosY2"].NextValue = 0;
            #endregion


            for (int i = 0; i < 4; i++)
            {
                string key = string.Format("FDC_GRAY_{0}", i);
                if (M_dicVisionValues.ContainsKey(key))
                {
                    if (ObjectPos[i] is LineCrossRstData)
                    {
                        var rst = ObjectPos[i] as LineCrossRstData;
                        double gray = (double)Math.Round(rst.AvgThreshold, 2);
                        M_dicVisionValues[key].NextValue = gray == 0 ? 91 : gray;
                    }
                }
            }

            if (errorCodeLami["Err_LCheck_Spec_Out"] == false || errorCodeLami["Err_PNL_LENGTH_NG"] == false || errorCodeLami["Err_WND_LENGTH_NG"] == false)
                return false;
             

            if (!ConfirmSpecMinMax(retVal.X, limitX * (-1), limitX) ||
            !ConfirmSpecMinMax(retVal.Y, limitY * (-1), limitY) ||
            !ConfirmSpecMinMax(retVal.T, limitT * (-1), limitT))
            {
                errorCodeLami["Err_Limit_Over"] = false;

                var Lower_1st_L = InputValues["Lower_1st_L"] as IPointResult;
                var Lower_1st_R = InputValues["Lower_1st_R"] as IPointResult;
                var Lower_2st_L = InputValues["Lower_2st_L"] as IPointResult;
                var Lower_2st_R = InputValues["Lower_2st_R"] as IPointResult;

                var Upper_1st_L = InputValues["Upper_1st_L"] as IPointResult;
                var Upper_1st_R = InputValues["Upper_1st_R"] as IPointResult;
                var Upper_2st_L = InputValues["Upper_2st_L"] as IPointResult;
                var Upper_2st_R = InputValues["Upper_2st_R"] as IPointResult;
                
                Lower_1st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Lower_1st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Lower_2st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Lower_2st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;

                Upper_1st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Upper_1st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Upper_2st_L.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Upper_2st_R.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;

                return false;
            }

            // 4P Align을 했으면 추가 보정량을 계산해서 넣어둔다. jyh
            if (GetVirtualObjIndex() == -1)
            {
                XY xy1st = new XY();
                XY xy2nd = new XY();
                xy1st.X = ObjectPos[0].OutputXYT.X - ObjectPos[1].OutputXYT.X;
                xy1st.Y = ObjectPos[0].OutputXYT.Y - ObjectPos[1].OutputXYT.Y;
                xy2nd.X = ObjectPos[3].OutputXYT.X - ObjectPos[2].OutputXYT.X;
                xy2nd.Y = ObjectPos[3].OutputXYT.Y - ObjectPos[2].OutputXYT.Y;
                SetAdjustObjPixel(xy2nd - xy1st);
            }
            if (GetVirtualTarIndex() == -1)
            {
                XY xy1st = new XY();
                XY xy2nd = new XY();
                xy1st.X = TargetPos[0].OutputXYT.X - TargetPos[1].OutputXYT.X;
                xy1st.Y = TargetPos[0].OutputXYT.Y - TargetPos[1].OutputXYT.Y;
                xy2nd.X = TargetPos[3].OutputXYT.X - TargetPos[2].OutputXYT.X;
                xy2nd.Y = TargetPos[3].OutputXYT.Y - TargetPos[2].OutputXYT.Y;
                SetAdjustTarPixel(xy2nd - xy1st);
            }
            return true;
        }
        #endregion

        private void MakeArray()
        {
            tarLineTheta = new double[4];
            objLineTheta = new double[4];

            TargetPos = new IPointResult[4];
            ObjectPos = new IPointResult[4];

            ObjCalData = new object[4];
            TarCalData = new object[4];

            TarCurGrabPos = new XY[4];
            ObjCurGrabPos = new XY[4];

            PNL_Pos = new XY[4];
            WND_Pos = new XY[4];
            TarRevPos = new XYT();
            ObjRevPos = new XYT();
            RevPos = new XYT();
            tarfixPos = new XY[4];
            objfixPos = new XY[4];
            tarCoorPos = new XY[4];
            objCoorPos = new XY[4];
        }

        // Align 방식 
        //  2 -------------------------------- 3 
        //    | [Left]                        l
        //    |                               l
        //    l                               l
        //    |    --> (WND 투입)              |  <-- (PNL 투입)
        //    l                               l         
        //    l [Right]                       l
        //  1 -------------------------------- 0 [Lower, Right]
        //     '작업자' 방향

        // Th01 == tarLineTheta[0]
        // Th12 == tarLineTheta[1]
        // Th23 == tarLineTheta[2]
        // Th30 == tarLineTheta[3]

        public override void DefaultIOSet()
        {
            base.DefaultIOSet();

            // 해당 하는 io를 가져온다.
            //PlcIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();
            //VisionIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();

            //plcValues.Clear();
            //visionValues.Clear();


            //foreach (var item in AlignTableObject.Plc.IOs)
            //{
            //    if ((item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))|| item.Key.Contains("Gpl"))
            //    {
            //        PlcIOs.Add(item);
            //        plcValues.Add(item.Key, item);
            //    }
            //}
            //foreach (var item in AlignTableObject.Vision.IOs)
            //{
            //    if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
            //    {
            //        VisionIOs.Add(item);
            //        visionValues.Add(item.Key, item);
            //    }
            //}
        }

        #region
        public override void ObjectInitialize()
        {
            base.ObjectInitialize();

            //if (useStagePos == UseStagePos.LowerUse)
            //{
            //    Upper_1st_R = tarCalData0;
            //    Upper_1st_L = tarCalData1;
            //    Upper_2st_L = tarCalData2;
            //    Upper_2st_R = tarCalData3;

            //    Lower_1st_R = objCalData0;
            //    Lower_1st_L = objCalData1;
            //    Lower_2st_L = objCalData2;
            //    Lower_2st_R = objCalData3;
            //}
            //else
            //{
            //    Upper_1st_R = objCalData0;
            //    Upper_1st_L = objCalData1;
            //    Upper_2st_L = objCalData2;
            //    Upper_2st_R = objCalData3;

            //    Lower_1st_R = tarCalData0;
            //    Lower_1st_L = tarCalData1;
            //    Lower_2st_L = tarCalData2;
            //    Lower_2st_R = tarCalData3;
            //}
            //plcValues = new Dictionary<string, IOStruct>();
            //visionValues = new Dictionary<string, IOStruct>();

            //if (AlignTableObject == null) return;

            //foreach (var item in AlignTableObject.Plc.IOs)
            //{
            //    if ((item.Type.Name != "Boolean" && !item.Key.Contains("Reserve")) || item.Key.Contains("Gpl"))
            //    {
            //        if (!plcValues.ContainsKey(item.Key))
            //        {
            //            plcValues.Add(item.Key, item);
            //        }
            //    }
            //}
            //foreach (var item in AlignTableObject.Vision.IOs)
            //{
            //    if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
            //    {
            //        if (!visionValues.ContainsKey(item.Key))
            //        {
            //            visionValues.Add(item.Key, item);
            //        }
            //    }
            //}
        }

        #endregion

        public bool CalCoorPos(string model, ref XY[] tarCoorPos, ref XY[] objCoorPos,
                               XY[] TargetPos, XY[] ObjectPos, XY[] ObjCurGrabPos, XY[] TarCurGrabPos)
        {
            SystemLogger.WriteAlignTestLog("***************************************************");           
            
            //[임시] tarCoorPos, objCoorPos 초기화
            Array.Clear(objCoorPos, 0, tarCoorPos.Length);
            Array.Clear(tarCoorPos, 0, tarCoorPos.Length);

            XY[] ObjRotateCenter = new XY[4];
            XY[] CalCamPos = new XY[4];
            Struct.CalData calibData = new Struct.CalData();

            // 상부 Rotation Center를 미리 저장하기 위해서 사용
            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                objfixPos[Pos] = new XY(); objCoorPos[Pos] = new XY();
                tarfixPos[Pos] = new XY(); tarCoorPos[Pos] = new XY();

                Type type = typeof(Algo90DBendedLami_4P_TarObjObject);
                //FieldInfo[] fields = type.GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                PropertyInfo[] props = type.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var prop in props) // 우선 obj(WND)의 Rotation Center만 추출
                {
                    if (prop.Name == ("calDataModObject" + Pos.ToString()))
                    {
                        string[] nameSplit = prop.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = prop.GetValue(this);
                        CalDataObject CalData = (CalDataObject)CalValue;
                        CalData.LoadCalData(model, ref calibData);
                        // Obj에서의 (RotCenter + CalCamPos)
                        ObjRotateCenter[Pos] = CalData.GetRotateCenter(model); // 상부 WND의 RotationCenter를 하부 활용하기 위해서 미리 저장 
                        // CalCamPos[Pos] = CalData.GetCameraPosition(model);
                        CalCamPos[Pos] = calibData.RotInfo.ExeCamPosition;
                    }
                }
            }

            XY[] objfixPos0 = new XY[4];
            XY[] tarfixPos0 = new XY[4];

            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                objfixPos[Pos] = new XY(); 
                objCoorPos[Pos] = new XY();
                objfixPos0[Pos] = new XY();

                Type type = typeof(Algo90DBendedLami_4P_TarObjObject);
                PropertyInfo[] props = type.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var prop in props)
                {
                    if (prop.Name == ("calDataModObject" + Pos.ToString()) || prop.Name == ("calDataModTarget" + Pos.ToString()))
                    {
                        string[] nameSplit = prop.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = prop.GetValue(this);

                        CalDataObject CalData = (CalDataObject)CalValue;

                        switch (nameSplit[1])
                        {
                            case "Obj":  // Object(Window,상부)

                                if (calibData.RotInfo.ExeCamPosition != null || calibData.RotInfo.ExeCamPosition.X == 0 || calibData.RotInfo.ExeCamPosition.Y == 0)
                                {

                                    XY ObjCamMoving = CalCamPos[Pos] - ObjCurGrabPos[Pos];
                                    objfixPos0[Pos] = CalData.GetRotateCenter(model);

                                    switch (Pos)
                                    {
                                        // 타 설비에서 사용 가능. 그대로 둠.                             
                                        case 0:
                                            
                                            break;
                                        case 1:
                                            ObjCamMoving.X *= -1;
                                            break;
                                        case 2:
                                            ObjCamMoving.X *= -1;
                                            break;
                                        case 3:
                                            break;
                                    }

                                    objfixPos[Pos] = objfixPos0[Pos] - ObjCamMoving;
                                    XY robotPos = CalData.GetV2R(model, ObjectPos[Pos], true, true);
                                    objCoorPos[Pos] = objfixPos[Pos] + robotPos;

                                    string str_log = "Object" + Pos.ToString() + ", Mod_0, Theta_Type , " + ThetaCalType.ToString() +  ", Fix0_X , " + objfixPos0[Pos].X.ToString("0.000") + ", Fix0_Y , " + objfixPos0[Pos].Y.ToString("0.000");
                                    str_log += ", CamMove_X , " + ObjCamMoving.X.ToString("0.000") + ",CamMove_Y , " + ObjCamMoving.Y.ToString("0.000");
                                    str_log += ", Fix1_X , " + objfixPos[Pos].X.ToString("0.000") + ", Fix1_Y , " + objfixPos[Pos].Y.ToString("0.000");
                                    str_log += ", Robot_X , " + robotPos.X.ToString("0.000") + ", Robot_Y , " + robotPos.Y.ToString("0.000");
                                    str_log += ", Coord_X , " + objCoorPos[Pos].X.ToString("0.000") + ", Coord_Y , " + objCoorPos[Pos].Y.ToString("0.000");

                                    //Console.WriteLine(str_log);
                                    SystemLogger.WriteAlignTestLog(str_log);
                                }
                                else
                                {
                                    errorCodeLami["Err_Obtain_Camera_CalPos_Value"] = false;
                                    return false;
                                }
                                break;
                        }
                    }
                }
            }

            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                tarfixPos[Pos] = new XY();
                tarCoorPos[Pos] = new XY();
                tarfixPos0[Pos] = new XY();

                Type type = typeof(Algo90DBendedLami_4P_TarObjObject);
                PropertyInfo[] props = type.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var prop in props)
                {
                    if (prop.Name == ("calDataModObject" + Pos.ToString()) || prop.Name == ("calDataModTarget" + Pos.ToString()))
                    {
                        string[] nameSplit = prop.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = prop.GetValue(this);

                        CalDataObject CalData = (CalDataObject)CalValue;

                        switch (nameSplit[1])
                        {
                            case "Tar": // Target(PNL)
                                if (calibData.RotInfo.ExeCamPosition != null || calibData.RotInfo.ExeCamPosition.X == 0 || calibData.RotInfo.ExeCamPosition.Y == 0)
                                {

                                    XY TarCamMoving = CalCamPos[Pos] - TarCurGrabPos[Pos];
                                    tarfixPos0[Pos] = ObjRotateCenter[Pos];

                                    switch (Pos)
                                    {
                                        case 0:
                                            break;
                                        case 1:
                                            TarCamMoving.X *= -1;
                                            break;
                                        case 2:
                                            TarCamMoving.X *= -1;
                                            break;
                                        case 3:
                                            break;
                                    }


                                    tarfixPos[Pos] = tarfixPos0[Pos] - TarCamMoving;
                                    XY robotPos = CalData.GetV2R(model, TargetPos[Pos], true, true);
                                    tarCoorPos[Pos] = tarfixPos[Pos] + robotPos;

                                    string str_log = "Target" + Pos.ToString() + ", Mod_0, Theta_Type , " + ThetaCalType.ToString() + ", Fix0_X , " + tarfixPos0[Pos].X.ToString("0.000") + ", Fix0_Y , " + tarfixPos0[Pos].Y.ToString("0.000");
                                    str_log += ", CamMove_X , " + TarCamMoving.X.ToString("0.000") + ",CamMove_Y , " + TarCamMoving.Y.ToString("0.000");
                                    str_log += ", Fix1_X , " + tarfixPos[Pos].X.ToString("0.000") + ", Fix1_Y , " + tarfixPos[Pos].Y.ToString("0.000");
                                    str_log += ", Robot_X , " + robotPos.X.ToString("0.000") + ", Robot_Y , " + robotPos.Y.ToString("0.000");
                                    str_log += ", Coord_X , " + tarCoorPos[Pos].X.ToString("0.000") + ", Coord_Y , " + tarCoorPos[Pos].Y.ToString("0.000");

                                    SystemLogger.WriteAlignTestLog(str_log);

                                }
                                else
                                {
                                    errorCodeLami["Err_Obtain_Camera_CalPos_Value"] = false;
                                    return false;
                                }
                                break;
                        }
                    }
                }
            }
            return true;
        }

        public bool ReCalCoorPos(string model, ref XY[] tarCoorPos, ref XY[] objCoorPos,
                       XY[] TargetPos, XY[] ObjectPos, XY[] ObjCurGrabPos, XY[] TarCurGrabPos, UseStagePos useStagePos)
        {
            SystemLogger.WriteAlignTestLog("***************************************************");
            //[임시] tarCoorPos, objCoorPos 초기화
            Array.Clear(objCoorPos, 0, tarCoorPos.Length);
            Array.Clear(tarCoorPos, 0, tarCoorPos.Length);

            XY[] ObjRotateCenter = new XY[4];
            XY[] CalCamPos = new XY[4];
            Struct.CalData calibData = new Struct.CalData();

            // tar(PNL)
            // 상부 Rotation Center를 미리 저장하기 위해서 사용
            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                objfixPos[Pos] = new XY(); objCoorPos[Pos] = new XY();
                tarfixPos[Pos] = new XY(); tarCoorPos[Pos] = new XY();

                Type type = typeof(Algo90DBendedLami_4P_TarObjObject);
                PropertyInfo[] props = type.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var prop in props) // 우선 obj(WND)의 Rotation Center만 추출
                {
                    if (prop.Name == ("calDataModObject" + Pos.ToString()))
                    {
                        string[] nameSplit = prop.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = prop.GetValue(this);
                        CalDataObject CalData = (CalDataObject)CalValue;
                        CalData.LoadCalDataWithoutImg(model, ref calibData);

                        // Obj에서의 (RotCenter + CalCamPos)
                        ObjRotateCenter[Pos] = CalData.GetRotateCenter(model); // 상부 WND의 RotationCenter를 하부 활용하기 위해서 미리 저장 
                        // CalCamPos[Pos] = CalData.GetCameraPosition(model);
                        CalCamPos[Pos] = calibData.RotInfo.ExeCamPosition;
                    }
                }
            }

            XY[] objfixPos0 = new XY[4];
            XY[] tarfixPos0 = new XY[4];

            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                objfixPos[Pos] = new XY();  
                objCoorPos[Pos] = new XY(); 
                objfixPos0[Pos] = new XY();   

                Type type = typeof(Algo90DBendedLami_4P_TarObjObject);
                PropertyInfo[] props = type.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var prop in props)
                {
                    if (prop.Name == ("calDataModObject" + Pos.ToString()) || prop.Name == ("calDataModTarget" + Pos.ToString()))
                    {
                        string[] nameSplit = prop.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = prop.GetValue(this);

                        CalDataObject CalData = (CalDataObject)CalValue;

                        switch (nameSplit[1])
                        {
                            case "Obj":  // Object(Window,상부)

                                if (calibData.RotInfo.ExeCamPosition != null || calibData.RotInfo.ExeCamPosition.X == 0 || calibData.RotInfo.ExeCamPosition.Y == 0)
                                {
                                    // 현재값이 0나오니깐 무쟈게 이상한값나와서 일단 현재값 안들어올때는 0처리...
                                    // 시뮬레이션때 이상해서....설비에서는 되니깐 쓰고있는거겠쥐비...
                                    if (ObjCurGrabPos[Pos].X == 0 && ObjCurGrabPos[Pos].Y == 0)
                                    {
                                        CalCamPos[Pos].X = 0; CalCamPos[Pos].Y = 0;
                                    }
                                    XY ObjCamMoving = ObjCurGrabPos[Pos] - CalCamPos[Pos];
                                    objfixPos0[Pos] = CalData.GetRotateCenter(model); //ObjRotateCenter[Pos];                      

                                    switch (Pos)
                                    {
                                        // 타 설비에서 사용 가능. 그대로 둠.                             
                                        case 0: // (+, -)
                                            if (!(objfixPos0[Pos].X > 0)) objfixPos0[Pos].X *= -1;
                                            if (!(objfixPos0[Pos].Y < 0)) objfixPos0[Pos].Y *= -1;
                                            ObjCamMoving.X *= -1;
                                            break;
                                        case 1: // (-, -)
                                            if (!(objfixPos0[Pos].X < 0)) objfixPos0[Pos].X *= -1;
                                            if (!(objfixPos0[Pos].Y < 0)) objfixPos0[Pos].Y *= -1;
                                            break;
                                        case 2: // (-, +)
                                            if (!(objfixPos0[Pos].X < 0)) objfixPos0[Pos].X *= -1;
                                            if (!(objfixPos0[Pos].Y > 0)) objfixPos0[Pos].Y *= -1;
                                            break;
                                        case 3: // (+, +)
                                            if (!(objfixPos0[Pos].X > 0)) objfixPos0[Pos].X *= -1;
                                            if (!(objfixPos0[Pos].Y > 0)) objfixPos0[Pos].Y *= -1;
                                            ObjCamMoving.X *= -1;
                                            break;
                                    }
                              
                                    objfixPos[Pos] = objfixPos0[Pos] + ObjCamMoving;
                                    objCoorPos[Pos] = objfixPos[Pos] + CalData.GetV2R(model, ObjectPos[Pos], true, true);

                                    string str_log = "Object" + Pos.ToString() + ", Mod_1, Theta_Type  , " + ThetaCalType.ToString() + ", Fix0_X , " + objfixPos0[Pos].X.ToString("0.000") + ", Fix0_Y , " + objfixPos0[Pos].Y.ToString("0.000");
                                    str_log += ", CamMove_X , " + ObjCamMoving.X.ToString("0.000") + ",CamMove_Y , " + ObjCamMoving.Y.ToString("0.000");
                                    str_log += ", Fix1_X , " + objfixPos[Pos].X.ToString("0.000") + ", Fix1_Y , " + objfixPos[Pos].Y.ToString("0.000");
                                    str_log += ", Robot_X , " + CalData.GetV2R(model, ObjectPos[Pos], true, true).X.ToString("0.000") + ", Robot_Y , " + CalData.GetV2R(model, ObjectPos[Pos], true, true).Y.ToString("0.000");
                                    str_log += ", Coord_X , " + objCoorPos[Pos].X.ToString("0.000") + ", Coord_Y , " + objCoorPos[Pos].Y.ToString("0.000");

                                    SystemLogger.WriteAlignTestLog(str_log);
                                }
                                else
                                {
                                    errorCodeLami["Err_Obtain_Camera_CalPos_Value"] = false;
                                    return false;
                                }
                                break;
                        }
                    }
                }
            }


            for (int Pos = 0; Pos < tarCoorPos.Length; Pos++)
            {
                tarfixPos[Pos] = new XY();
                tarCoorPos[Pos] = new XY();
                tarfixPos0[Pos] = new XY();

                Type type = typeof(Algo90DBendedLami_4P_TarObjObject);
                PropertyInfo[] props = type.GetProperties(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var prop in props)
                {
                    if (prop.Name == ("calDataModObject" + Pos.ToString()) || prop.Name == ("calDataModTarget" + Pos.ToString()))
                    {
                        string[] nameSplit = prop.Name.Split(new string[] { "calDataMod", "get", "ect" }, StringSplitOptions.None);
                        object CalValue = prop.GetValue(this);

                        CalDataObject CalData = (CalDataObject)CalValue;

                        switch (nameSplit[1])
                        {
                            case "Tar": // Target(PNL)
                                if (calibData.RotInfo.ExeCamPosition != null || calibData.RotInfo.ExeCamPosition.X == 0 || calibData.RotInfo.ExeCamPosition.Y == 0)
                                {
                                    // 현재값이 0나오니깐 무쟈게 이상한값나와서 일단 현재값 안들어올때는 0처리...
                                    // 시뮬레이션때 이상해서....설비에서는 되니깐 쓰고있는거겠쥐비...
                                    if (TarCurGrabPos[Pos].X == 0 && CalCamPos[Pos].Y == 0)
                                    {
                                        CalCamPos[Pos].X = 0; CalCamPos[Pos].Y = 0;
                                    }

                                    XY TarCamMoving = TarCurGrabPos[Pos] - CalCamPos[Pos]; // Moving X +, Moving Y +
                                    tarfixPos0[Pos] = ObjRotateCenter[Pos];  

                                    switch (Pos)
                                    {
                                        // 타 설비에서 사용 가능. 그대로 둠.                             
                                        case 0: // (+, -)
                                            if (!(tarfixPos0[Pos].X > 0)) tarfixPos0[Pos].X *= -1;
                                            if (!(tarfixPos0[Pos].Y < 0)) tarfixPos0[Pos].Y *= -1;
                                            TarCamMoving.X *= -1;
                                            break;
                                        case 1: // (-, -) 
                                            if (!(tarfixPos0[Pos].X < 0)) tarfixPos0[Pos].X *= -1;
                                            if (!(tarfixPos0[Pos].Y < 0)) tarfixPos0[Pos].Y *= -1;
                                            break;
                                        case 2: // (-, +)
                                            if (!(tarfixPos0[Pos].X < 0)) tarfixPos0[Pos].X *= -1;
                                            if (!(tarfixPos0[Pos].Y > 0)) tarfixPos0[Pos].Y *= -1;
                                            break;
                                        case 3: // (+, +)
                                            if (!(tarfixPos0[Pos].X > 0)) tarfixPos0[Pos].X *= -1;
                                            if (!(tarfixPos0[Pos].Y > 0)) tarfixPos0[Pos].Y *= -1;
                                            TarCamMoving.X *= -1;
                                            break;
                                    }

                                    tarfixPos[Pos] = tarfixPos0[Pos] + TarCamMoving;
                                    tarCoorPos[Pos] = tarfixPos[Pos] + CalData.GetV2R(model, TargetPos[Pos], true, true);

                                    string str_log = "Target" + Pos.ToString() + ", Mode_1, Theta_Type , " + ThetaCalType.ToString() + ", Fix0_X , " + tarfixPos0[Pos].X.ToString("0.000") + ", Fix0_Y , " + tarfixPos0[Pos].Y.ToString("0.000");
                                    str_log += ", CamMove_X , " + TarCamMoving.X.ToString("0.000") + ",CamMove_Y , " + TarCamMoving.Y.ToString("0.000");
                                    str_log += ", Fix1_X , " + tarfixPos[Pos].X.ToString("0.000") + ", Fix1_Y , " + tarfixPos[Pos].Y.ToString("0.000");
                                    str_log += ", Robot_X , " + CalData.GetV2R(model, TargetPos[Pos], true, true).X.ToString("0.000") + ", Robot_Y , " + CalData.GetV2R(model, TargetPos[Pos], true, true).Y.ToString("0.000");
                                    str_log += ", Coord_X , " + tarCoorPos[Pos].X.ToString("0.000") + ", Coord_Y , " + tarCoorPos[Pos].Y.ToString("0.000");

                                    SystemLogger.WriteAlignTestLog(str_log);

                                }
                                else
                                {
                                    errorCodeLami["Err_Obtain_Camera_CalPos_Value"] = false;
                                    return false;
                                }
                                break;
                        }
                    }
                }
            }
            return true;
        }


        new protected bool ArrayCurGrabPos(AlignType AlignMode, int InsertPos, bool UseTarget,
                                ref XY[] TarCurGrabPos, ref XY[] ObjCurGrabPos, Dictionary<string, IOStruct> plcValues)
        {
            for (int temp = 0; temp < InsertPos; temp++)
            {
                TarCurGrabPos[temp] = new XY();
                ObjCurGrabPos[temp] = new XY();

                switch (AlignMode)
                {
                    // 90도 'Sub'에서는 굳이 배열로 선언안해도 되나...(각 동일한 CurrentPosX,Y,T)를 갖으므로... 그냥 통일 위해서 정의!
                    case AlignType.Tar_Obj_3P:
                        try
                        {
                            if (plcValues.ContainsKey("CurrentPosX") && plcValues.ContainsKey("CurrentPosY"))
                            {
                                // Sub의 ObjPoint3는 사용을 안해도 넣자!
                                TarCurGrabPos[temp].X = (double)plcValues["UnloadPosX"].CurValue;
                                ObjCurGrabPos[temp].X = (double)plcValues["UnloadPosX"].CurValue;
                                TarCurGrabPos[temp].Y = (double)plcValues["UnloadPosY"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["UnloadPosY"].CurValue;
                            }
                            else
                            {
                                // 값이 없으면 '0'으로 초기화!
                                TarCurGrabPos[temp].X = 0;
                                ObjCurGrabPos[temp].X = 0;
                                TarCurGrabPos[temp].Y = 0;
                                ObjCurGrabPos[temp].Y = 0;
                            }
                            break;
                        }
                        catch (Exception e)
                        {
                            return false;
                        }

                    case AlignType.Tar_Obj_4P:
                        try
                        {
                            if ((temp == 0 || temp == 1) &&
                                plcValues.ContainsKey("UpperCamX2") && plcValues.ContainsKey("LowerCamX2") &&
                                plcValues.ContainsKey("UpperCamY2") && plcValues.ContainsKey("LowerCamY2"))
                            {
                                TarCurGrabPos[temp].X = (double)plcValues["LowerCamX2"].CurValue;
                                TarCurGrabPos[temp].Y = (double)plcValues["LowerCamY2"].CurValue;

                                ObjCurGrabPos[temp].X = (double)plcValues["UpperCamX2"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["UpperCamY2"].CurValue;
                            }
                            else if ((temp == 2 || temp == 3) &&
                                plcValues.ContainsKey("UpperCamX1") && plcValues.ContainsKey("LowerCamX1") &&
                                plcValues.ContainsKey("UpperCamY1") && plcValues.ContainsKey("LowerCamY1"))
                            {
                                TarCurGrabPos[temp].X = (double)plcValues["LowerCamX1"].CurValue;
                                TarCurGrabPos[temp].Y = (double)plcValues["LowerCamY1"].CurValue;

                                ObjCurGrabPos[temp].X = (double)plcValues["UpperCamX1"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["UpperCamY1"].CurValue;
                            }
                            break;
                        }
                        catch (Exception e)
                        {
                            return false;
                        }

                    case AlignType.Obj_4P:
                        try
                        {
                            if ((temp == 0 || temp == 1) &&
                                plcValues.ContainsKey("LowerCamX1") && plcValues.ContainsKey("LowerCamY1"))
                            {
                                TarCurGrabPos[temp].X = 0;
                                TarCurGrabPos[temp].Y = 0;

                                ObjCurGrabPos[temp].X = (double)plcValues["LowerCamX1"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["LowerCamY1"].CurValue;
                            }
                            else if ((temp == 2 || temp == 3) &&
                                plcValues.ContainsKey("LowerCamX2") && plcValues.ContainsKey("LowerCamY2"))
                            {
                                TarCurGrabPos[temp].X = 0;
                                TarCurGrabPos[temp].Y = 0;

                                ObjCurGrabPos[temp].X = (double)plcValues["LowerCamX2"].CurValue;
                                ObjCurGrabPos[temp].Y = (double)plcValues["LowerCamY2"].CurValue;
                            }
                            break;
                        }
                        catch (Exception e)
                        {
                            return false;
                        }
                }
            }
            return true;
        }


        /*InterLock 발생하여 FDC TargetP0s....................... */
        new protected bool uploadFDCdata_Temp()
        {

            string keyT_PosX = "FDC_TargetPosX";
            string keyT_PosY = "FDC_TargetPosY";
            string keyT_PosT = "FDC_TargetPosT";

            M_dicVisionValues[keyT_PosX].NextValue = (double) Math.Round(RevPos.X , 3) ;
            M_dicVisionValues[keyT_PosY].NextValue = (double)Math.Round(RevPos.Y, 3);
            M_dicVisionValues[keyT_PosT].NextValue = (double)Math.Round(RevPos.T, 3);

 
            
            /*W,P Distance FDC 공간   */
            //M_dicVisionValues[].NextValue = dTargetLength_01;
            //M_dicVisionValues[].NextValue = dTargetLength_12;
            //M_dicVisionValues[].NextValue = dTargetLength_23;
            //M_dicVisionValues[].NextValue = dTargetLength_30;
            //M_dicVisionValues[].NextValue = (double)Math.Round(RevPos.Y, 3);
            //M_dicVisionValues[].NextValue = (double)Math.Round(RevPos.T, 3);
            //M_dicVisionValues[].NextValue = (double)Math.Round(RevPos.X, 3);
            //M_dicVisionValues[].NextValue = (double)Math.Round(RevPos.X, 3);



            return true;
        }

        protected void UploadFDCdata_OnlyVisionRev(XYT rev)
        {
                VisionValues["FDC_ResultRevX"].NextValue = (double)Math.Round(rev.X, 3);
                VisionValues["FDC_ResultRevY"].NextValue = (double)Math.Round(rev.Y, 3);
                VisionValues["FDC_ResultRevT"].NextValue = (double)Math.Round(rev.T, 3);
        }
        
        protected bool UploadFDCdata_Pos(AlignType AlignMode, bool UseTarget, IPointResult[] TargetPos, IPointResult[] ObjectPos, Dictionary<string, IOStruct> M_dicVisionValues, ref Dictionary<string, bool> errorCode)
        {
            string syntax_tar = "";
            string syntax_obj = "";

            switch (AlignMode)
            {
                case AlignType.Tar_Obj_4P:
                    syntax_tar = "P";
                    syntax_obj = "W";
                    break;
                case AlignType.Obj_4P:
                    syntax_obj = "P";
                    break;

                case AlignType.Tar_Obj_3P:
                    syntax_tar = "W";
                    syntax_obj = "P";
                    break;
            }


            /*Object */
            for (int Pos = 0; Pos < ObjectPos.Length; Pos++)
            {
                if (UseTarget == true)
                {
                    string keyX_P = "FDC_" + syntax_tar + Pos.ToString() + "X";
                    string keyY_P = "FDC_" + syntax_tar + Pos.ToString() + "Y";
                    string keyS_P = "FDC_" + syntax_tar + Pos.ToString() + "Score";

                    if (M_dicVisionValues.ContainsKey(keyX_P) == false || M_dicVisionValues.ContainsKey(keyY_P) == false || M_dicVisionValues.ContainsKey(keyS_P) == false)
                    {
                        errorCode["Err_Upload_VisionPos_Value"] = false;
                        return false;
                    }
                    // P1X, P1Y, P3X, P3Y 일때 안들어옴??? 
                    else if (AlignMode == AlignType.Tar_Obj_3P && Pos == 0) { } // 90도 Sub_라미 특화
                    else
                    {
                        M_dicVisionValues[keyX_P].NextValue = (int)Math.Round(TargetPos[Pos].OutputXYT.X , 2);
                        M_dicVisionValues[keyY_P].NextValue = (int)Math.Round(TargetPos[Pos].OutputXYT.Y, 2);

                        //if(TargetPos[Pos] is MatchingRstData)
                            M_dicVisionValues[keyS_P].NextValue = (int)Math.Round(TargetPos[Pos].Score, 2) * 10;
                        //else if (TargetPos[Pos] is LineCrossRstData)
                        //    M_dicVisionValues[keyS_P].NextValue = (int)Math.Round((TargetPos[Pos] as LineCrossRstData).AvgThreshold, 2) * 10;
                    }
                }

                string keyX_W = "FDC_" + syntax_obj + Pos.ToString() + "X";
                string keyY_W = "FDC_" + syntax_obj + Pos.ToString() + "Y";
                string keyS_W = "FDC_" + syntax_obj + Pos.ToString() + "Score";

                if (M_dicVisionValues.ContainsKey(keyX_W) == false || M_dicVisionValues.ContainsKey(keyY_W) == false || M_dicVisionValues.ContainsKey(keyS_W) == false)
                {
                    errorCode["Err_Upload_VisionPos_Value"] = false;
                    return false;
                }
                else if (AlignMode == AlignType.Tar_Obj_3P && Pos == 3) { } // 90도 Sub_라미 특화
                else
                {
                    M_dicVisionValues[keyX_W].NextValue = (int)Math.Round(ObjectPos[Pos].OutputXYT.X, 2);
                    M_dicVisionValues[keyY_W].NextValue = (int)Math.Round(ObjectPos[Pos].OutputXYT.Y, 2);
                    //if (TargetPos[Pos] is MatchingRstData)
                        M_dicVisionValues[keyS_W].NextValue = (int)Math.Round(ObjectPos[Pos].Score, 2) * 10;
                    //else if (TargetPos[Pos] is LineCrossRstData)
                    //    M_dicVisionValues[keyS_W].NextValue = (int)Math.Round((ObjectPos[Pos] as LineCrossRstData).AvgThreshold, 2) * 10;

                }
            }
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        ToolActionBase[] objTool = new ToolActionBase[4];
        /// <summary>
        /// 
        /// </summary>
        ToolActionBase[] tarTool = new ToolActionBase[4];

        protected bool PosConfirm(AlignType AlignMode, ref IPointResult[] TargetPos, ref IPointResult[] ObjectPos, ref Dictionary<string, bool> errorCode, UseStagePos useStagePos)
        {
            try
            {
                switch (AlignMode)
                {
                    case AlignType.Obj_4P: // <- Shape를 변경해서 해야함 추후 ^^;
                        // kds Insert 2019.11.04 : LineCrossRstData 및 MatchingRstData 동시 사용을 위해 추가
                        // ljw Insert 2019.11.28 : Stage 사용에 따른 구분
                        
                        if (useStagePos == UseStagePos.UpperUse)
                        {
                            ObjectPos[0] = GetRstData("Upper_1st_R");
                            ObjectPos[1] = GetRstData("Upper_1st_L");
                            ObjectPos[2] = GetRstData("Upper_2st_L");
                            ObjectPos[3] = GetRstData("Upper_2st_R");
                        }
                        else
                        {
                            ObjectPos[0] = GetRstData("Lower_1st_R");
                            ObjectPos[1] = GetRstData("Lower_1st_L");
                            ObjectPos[2] = GetRstData("Lower_2st_L");
                            ObjectPos[3] = GetRstData("Lower_2st_R");
                        }

                        //ObjectPos[0] = InputValues["PNL_1st_R"] as IPointResult;
                        //ObjectPos[1] = InputValues["PNL_1st_L"] as IPointResult;
                        //ObjectPos[2] = InputValues["PNL_2st_L"] as IPointResult;
                        //ObjectPos[3] = InputValues["PNL_2st_R"] as IPointResult;

                        // L Check NG 처리를 위해 추가 : HDY
                        for (int i = 0; i < 4; i++)
                        {
                            objTool[i] = (ObjectPos[i] as IPointResult).Tool;
                        }

                        for (int cnt = 0; cnt < TargetPos.Length; cnt++)
                        {
                            TargetPos[cnt] = new MatchingRstData();
                            if (ObjectPos[cnt] == null)
                            {
                                errorCode["Err_obtain_VisionPos_Value"] = false;
                                return false;
                            }
                        }
                        break;

                    case AlignType.Tar_Obj_4P:
                        // kds Insert 2019.11.04 : LineCrossRstData 및 MatchingRstData 동시사용을 위해 추가함.
                        // ljw Insert 2019.11.28 : Stage 사용에 따른 구분
                        if (useStagePos == UseStagePos.UpperUse)
                        {
                            ObjectPos[0] = GetRstData("Upper_1st_R");
                            ObjectPos[1] = GetRstData("Upper_1st_L");
                            ObjectPos[2] = GetRstData("Upper_2st_L");
                            ObjectPos[3] = GetRstData("Upper_2st_R");

                            TargetPos[0] = GetRstData("Lower_1st_R");
                            TargetPos[1] = GetRstData("Lower_1st_L");
                            TargetPos[2] = GetRstData("Lower_2st_L");
                            TargetPos[3] = GetRstData("Lower_2st_R");
                        }
                        else
                        {
                            ObjectPos[0] = GetRstData("Lower_1st_R");
                            ObjectPos[1] = GetRstData("Lower_1st_L");
                            ObjectPos[2] = GetRstData("Lower_2st_L");
                            ObjectPos[3] = GetRstData("Lower_2st_R");

                            TargetPos[0] = GetRstData("Upper_1st_R");
                            TargetPos[1] = GetRstData("Upper_1st_L");
                            TargetPos[2] = GetRstData("Upper_2st_L");
                            TargetPos[3] = GetRstData("Upper_2st_R");
                        }

                        //ObjectPos[0] = GetRstData("WND_1st_R");
                        //ObjectPos[1] = GetRstData("WND_1st_L");
                        //ObjectPos[2] = GetRstData("WND_2st_L");
                        //ObjectPos[3] = GetRstData("WND_2st_R");

                        //TargetPos[0] = GetRstData("PNL_1st_R");
                        //TargetPos[1] = GetRstData("PNL_1st_L");
                        //TargetPos[2] = GetRstData("PNL_2st_L");
                        //TargetPos[3] = GetRstData("PNL_2st_R");

                        //ObjectPos[0] = InputValues["WND_1st_R"] as IPointResult;
                        //ObjectPos[1] = InputValues["WND_1st_L"] as IPointResult;
                        //ObjectPos[2] = InputValues["WND_2st_L"] as IPointResult;
                        //ObjectPos[3] = InputValues["WND_2st_R"] as IPointResult;

                        //TargetPos[0] = InputValues["PNL_1st_R"] as IPointResult;
                        //TargetPos[1] = InputValues["PNL_1st_L"] as IPointResult;
                        //TargetPos[2] = InputValues["PNL_2st_L"] as IPointResult;
                        //TargetPos[3] = InputValues["PNL_2st_R"] as IPointResult;

                        for (int cnt = 0; cnt < TargetPos.Length; cnt++)
                        {
                            if (ObjectPos[cnt] == null || TargetPos[cnt] == null)
                            {
                                errorCode["Err_obtain_VisionPos_Value"] = false;
                                return false;
                            }
                        }
                        break;
                }
                return true;
            }
            catch(Exception e)
            {
                errorCode["Err_obtain_VisionPos_Value"] = false;
                return false;
            }
        }

        /// <summary>
        /// IPointResult Interface 사용 GetRstData 
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public IPointResult GetRstData(string key)
        {
            IPointResult Rst = null;

            if (!InputValues.ContainsKey(key)) return Rst;

            if (InputValues[key] is MatchingRstData)
                Rst = InputValues[key] as MatchingRstData;
            else if (InputValues[key] is LineCrossRstData)
                Rst = InputValues[key] as LineCrossRstData;
            return Rst;
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void ObjectUpdate()
        {
            base.ObjectUpdate();

            PlcIOsListConverter.Module = CommObj;
            VisionIOsListConverter.Module = CommObj;
        }
    }

}
