﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using Iva.Bplus.Views;
using SvMip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_TarObj
{
    [SerializableAttribute]
    public partial class Algo90DBendedLami_4P_TarObjShape : ModuleBase
    {
        #region [Fields]        
        #endregion

        #region [Construct]
        public Algo90DBendedLami_4P_TarObjShape()
            : base()
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;
        }

        public Algo90DBendedLami_4P_TarObjShape(SystemCanvasViewModel parent, string name)
            : base(parent, name)
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;

            base.InitItem(null, name, SettingShapeType.Algo);

            var action = base.modAction as SystemActionBase;
            base.SetConnectors(action.InputParams, action.OutputParams);
        }
        #endregion

        #region [override method]
        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string _source)
        {
            base.parent = parent;
            base.InitItem(obj, _source, SettingShapeType.Algo);

            base.Geometry = SystemImage.TOOLS_ICON;

            //UpdateShape();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void UpdateShape()
        {
            var Time = this.ReleaseNote.GetLastUpdateTime();
            if (this.LastUpdateTime < Time)
            {
                var PNL_1st_L = this.GetInputConnector("PNL_1st_L");
                if (PNL_1st_L != null) { PNL_1st_L.Name = "Lower_1st_L"; PNL_1st_L.Update();}

                 var PNL_1st_R = this.GetInputConnector("PNL_1st_R");
                if (PNL_1st_R != null) { PNL_1st_R.Name = "Lower_1st_R"; PNL_1st_R.Update(); }

                var PNL_2st_L = this.GetInputConnector("PNL_2st_L");
                if (PNL_2st_L != null) {PNL_2st_L.Name = "Lower_2st_L"; PNL_2st_L.Update(); }

                var PNL_2st_R = this.GetInputConnector("PNL_2st_R");
                if (PNL_2st_R != null) {PNL_2st_R.Name = "Lower_2st_R"; PNL_2st_R.Update(); }

                var WND_1st_L = this.GetInputConnector("WND_1st_L");
                if (WND_1st_L != null) {WND_1st_L.Name = "Upper_1st_L"; WND_1st_L.Update(); WND_1st_L.DetailType = typeof(LineCrossRstData); }

                var WND_1st_R = this.GetInputConnector("WND_1st_R");
                if (WND_1st_R != null) {WND_1st_R.Name = "Upper_1st_R"; WND_1st_R.Update(); WND_1st_L.DetailType = typeof(LineCrossRstData); }

                var WND_2st_L = this.GetInputConnector("WND_2st_L");
                if (WND_2st_L != null) {WND_2st_L.Name = "Upper_2st_L"; WND_2st_L.Update(); WND_1st_L.DetailType = typeof(LineCrossRstData); }

                var WND_2st_R = this.GetInputConnector("WND_2st_R");
                if (WND_2st_R != null) {WND_2st_R.Name = "Upper_2st_R"; WND_2st_R.Update(); WND_1st_L.DetailType = typeof(LineCrossRstData); }

                this.LastUpdateTime = Time;
            }
        }

        #endregion
    }
}
