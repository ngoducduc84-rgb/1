﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo90DBendedLami_4P_TarObj
{ 
    public partial class Algo90DBendedLami_4P_TarObjShape
    {
        public override void UpdateHistory()
        {
            // ModuleBase Update History Loading
            base.UpdateHistory();

            /* Sample */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "First Release Version",                            // Update Title
                Version = new Version(1, 0, 0, 0),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>          // Update Item List
                {
                   "1. None",
                   "2. None",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2019, 4, 4, 17, 0, 0),                  // year, month, day, hour, minute, second
            });

            /* Additional Update History */
			ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "3Point Align 반영",                            // Update Title
                Version = new Version(1, 0, 0, 1),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "3Point Align Code 추가",
                   "Input Connector 명칭 변경으로 인한 Update",
                   "Option(기능OnOff)에 대한 내용 추가",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 1, 4, 0, 0, 0),                   // year, month, day, hour, minute, second
            });

            /* Additional Update History */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "Source Property 삭제",                             // Update Title
                Version = new Version(1, 0, 0, 2),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "Source Property 삭제",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 1, 10, 10, 0, 0),                  // year, month, day, hour, minute, second
            });

            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "Theta Log Deg값으로 변경",                         // Update Title
                Version = new Version(1, 0, 0, 3),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "1. Theta Log Deg값으로 변경",
                   "2. Image Save 관련 분류",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 1, 14, 10, 0, 0),                  // year, month, day, hour, minute, second
            });
			
			ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "Manual Mark시 Disply에 Message 표시",                         // Update Title
                Version = new Version(1, 0, 0, 4),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "냉무",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 1, 21, 10, 0, 0),                  // year, month, day, hour, minute, second
            });
			ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "3P Align Warning Code Return",                         // Update Title
                Version = new Version(1, 0, 0, 5),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "냉무",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 1, 28, 16, 0, 0),                  // year, month, day, hour, minute, second
            });
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "Window쪽 Fine Line Gray값 보고",                     // Update Title
                Version = new Version(1, 0, 0, 5),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "D52000부터 Double로 쭈욱~",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 4, 26, 10, 0, 0),                 // year, month, day, hour, minute, second
            });
        }
    }
}
