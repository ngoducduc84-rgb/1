﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo90SubLami;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]
    public partial class Algo90SubLamiAction : Lami90AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private bool useUnloadOffset;

        #region Inspection
        [field: NonSerialized]
        private double cur_UpperLx;
        [field: NonSerialized]
        private double cur_UpperLy;
        [field: NonSerialized]
        private double cur_LowerLx;
        [field: NonSerialized]
        private double cur_LowerLy;
        [field: NonSerialized]
        private double cur_LowerRx;
        [field: NonSerialized]
        private double cur_LowerRy;

        [field: NonSerialized]
        private bool judge_UpperLx;
        [field: NonSerialized]
        private bool judge_UpperLy;
        [field: NonSerialized]
        private bool judge_LowerLx;
        [field: NonSerialized]
        private bool judge_LowerLy;
        [field: NonSerialized]
        private bool judge_LowerRx;
        [field: NonSerialized]
        private bool judge_LowerRy;
        [field: NonSerialized]
        private bool judge_Upper;
        [field: NonSerialized]
        private bool judge_Right;

        [field: NonSerialized]
        private AlgoParam temp_UpperLx;
        [field: NonSerialized]
        private AlgoParam temp_UpperLy;
        [field: NonSerialized]
        private AlgoParam temp_LowerLx;
        [field: NonSerialized]
        private AlgoParam temp_LowerLy;
        [field: NonSerialized]
        private AlgoParam temp_LowerRx;
        [field: NonSerialized]
        private AlgoParam temp_LowerRy;
        #endregion

        #region Align
        [field: NonSerialized]
        private double pnl34_spec;
        [field: NonSerialized]
        private double pnl14_spec;
        [field: NonSerialized]
        private double oca34_spec;
        [field: NonSerialized]
        private double oca14_spec;

        [field: NonSerialized]
        private double pnl34_tor;
        [field: NonSerialized]
        private double pnl14_tor;
        [field: NonSerialized]
        private double oca34_tor;
        [field: NonSerialized]
        private double oca14_tor;

        #endregion
        #endregion

        #region [Properties]   
        public bool UseUnloadOffset { get { return useUnloadOffset; } set { if (useUnloadOffset == value) return; useUnloadOffset = value; this.OnPropertyChanged(nameof(UseUnloadOffset)); } }
        #region Inspectoin
        public double Cur_UpperLx { get { return cur_UpperLx; } set { if (cur_UpperLx == value) return; cur_UpperLx = value; this.OnPropertyChanged(nameof(Cur_UpperLx)); } }
        public double Cur_UpperLy { get { return cur_UpperLy; } set { if (cur_UpperLy == value) return; cur_UpperLy = value; this.OnPropertyChanged(nameof(Cur_UpperLy)); } }
        public double Cur_LowerLx { get { return cur_LowerLx; } set { if (cur_LowerLx == value) return; cur_LowerLx = value; this.OnPropertyChanged(nameof(Cur_LowerLx)); } }
        public double Cur_LowerLy { get { return cur_LowerLy; } set { if (cur_LowerLy == value) return; cur_LowerLy = value; this.OnPropertyChanged(nameof(Cur_LowerLy)); } }
        public double Cur_LowerRx { get { return cur_LowerRx; } set { if (cur_LowerRx == value) return; cur_LowerRx = value; this.OnPropertyChanged(nameof(Cur_LowerRx)); } }
        public double Cur_LowerRy { get { return cur_LowerRy; } set { if (cur_LowerRy == value) return; cur_LowerRy = value; this.OnPropertyChanged(nameof(Cur_LowerRy)); } }
        public bool Judge_UpperLx { get { return judge_UpperLx; } set { if (judge_UpperLx == value) return; judge_UpperLx = value; this.OnPropertyChanged(nameof(Judge_UpperLx)); } }
        public bool Judge_UpperLy { get { return judge_UpperLy; } set { if (judge_UpperLy == value) return; judge_UpperLy = value; this.OnPropertyChanged(nameof(Judge_UpperLy)); } }
        public bool Judge_LowerLx { get { return judge_LowerLx; } set { if (judge_LowerLx == value) return; judge_LowerLx = value; this.OnPropertyChanged(nameof(Judge_LowerLx)); } }
        public bool Judge_LowerLy { get { return judge_LowerLy; } set { if (judge_LowerLy == value) return; judge_LowerLy = value; this.OnPropertyChanged(nameof(Judge_LowerLy)); } }
        public bool Judge_LowerRx { get { return judge_LowerRx; } set { if (judge_LowerRx == value) return; judge_LowerRx = value; this.OnPropertyChanged(nameof(Judge_LowerRx)); } }
        public bool Judge_LowerRy { get { return judge_LowerRy; } set { if (judge_LowerRy == value) return; judge_LowerRy = value; this.OnPropertyChanged(nameof(Judge_LowerRy)); } }
        public bool Judge_Upper { get { return judge_Upper; } set { if (judge_Upper == value) return; judge_Upper = value; this.OnPropertyChanged(nameof(Judge_Upper)); } }
        public bool Judge_Right { get { return judge_Right; } set { if (judge_Right == value) return; judge_Right = value; this.OnPropertyChanged(nameof(Judge_Right)); } }
        public AlgoParam Temp_UpperLx { get { return temp_UpperLx; } set { if (temp_UpperLx == value) return; temp_UpperLx = value; this.OnPropertyChanged(nameof(Temp_UpperLx)); } }
        public AlgoParam Temp_UpperLy { get { return temp_UpperLy; } set { if (temp_UpperLy == value) return; temp_UpperLy = value; this.OnPropertyChanged(nameof(Temp_UpperLy)); } }
        public AlgoParam Temp_LowerLx { get { return temp_LowerLx; } set { if (temp_LowerLx == value) return; temp_LowerLx = value; this.OnPropertyChanged(nameof(Temp_LowerLx)); } }
        public AlgoParam Temp_LowerLy { get { return temp_LowerLy; } set { if (temp_LowerLy == value) return; temp_LowerLy = value; this.OnPropertyChanged(nameof(Temp_LowerLy)); } }
        public AlgoParam Temp_LowerRx { get { return temp_LowerRx; } set { if (temp_LowerRx == value) return; temp_LowerRx = value; this.OnPropertyChanged(nameof(Temp_LowerRx)); } }
        public AlgoParam Temp_LowerRy { get { return temp_LowerRy; } set { if (temp_LowerRy == value) return; temp_LowerRy = value; this.OnPropertyChanged(nameof(Temp_LowerRy)); } }
        #endregion

        #region Align

        public double Pnl34_spec { get { return pnl34_spec; } set { if (pnl34_spec == value) return; pnl34_spec = value; this.OnPropertyChanged(nameof(Pnl34_spec)); } }
        public double Pnl14_spec { get { return pnl14_spec; } set { if (pnl14_spec == value) return; pnl14_spec = value; this.OnPropertyChanged(nameof(Pnl14_spec)); } }
        public double Oca34_spec { get { return oca34_spec; } set { if (oca34_spec == value) return; oca34_spec = value; this.OnPropertyChanged(nameof(Oca34_spec)); } }
        public double Oca14_spec { get { return oca14_spec; } set { if (oca14_spec == value) return; oca14_spec = value; this.OnPropertyChanged(nameof(Oca14_spec)); } }

        public double Pnl34_tor { get { return pnl34_tor; } set { if (pnl34_tor == value) return; pnl34_tor = value; this.OnPropertyChanged(nameof(Pnl34_tor)); } }
        public double Pnl14_tor { get { return pnl14_tor; } set { if (pnl14_tor == value) return; pnl14_tor = value; this.OnPropertyChanged(nameof(Pnl14_tor)); } }
        public double Oca34_tor { get { return oca34_tor; } set { if (oca34_tor == value) return; oca34_tor = value; this.OnPropertyChanged(nameof(Oca34_tor)); } }
        public double Oca14_tor { get { return oca14_tor; } set { if (oca14_tor == value) return; oca14_tor = value; this.OnPropertyChanged(nameof(Oca14_tor)); } }

        #endregion

        #endregion

        #region [Construct]
        public Algo90SubLamiAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {

            InputParams = new Algo90SubLamiInputParams();
            OutputParams = new Algo90SubLamiOutputParams();

            CalcType type = (_object as Algo90SubLamiObject).CalcType;
            if (type == CalcType.Align)
            {
                var obj = _object as Algo90SubLamiObject;
                obj.ModelParamType = typeof(Algo90SubLamiAlignModelParams);
                obj.CreateParams();
                var param = obj.CurParams as Algo90SubLamiAlignModelParams;

                ChildSettingView = new AlignSetting();
                ChildSettingView.DataContext = this;
            }
            else if (type == CalcType.Inspection)
            {
                ChildSettingView = new InspectionSetting();
                ChildSettingView.DataContext = this;

                var obj = _object as Algo90SubLamiObject;
                obj.ModelParamType = typeof(Algo90SubLamiInspectModelParams);
                obj.CreateParams();

                var param = obj.CurParams as Algo90SubLamiInspectModelParams;

                temp_UpperLx = new AlgoParam(param.Scale_UpperLx);
                temp_UpperLx.Value = 0.0;
                temp_UpperLy = new AlgoParam(param.Scale_UpperLy);
                temp_UpperLy.Value = 0.0;
                temp_LowerLx = new AlgoParam(param.Scale_LowerLx);
                temp_LowerLx.Value = 0.0;
                temp_LowerLy = new AlgoParam(param.Scale_LowerLy);
                temp_LowerLy.Value = 0.0;
                temp_LowerRx = new AlgoParam(param.Scale_LowerRx);
                temp_LowerRx.Value = 0.0;
                temp_LowerRy = new AlgoParam(param.Scale_LowerRy);
                temp_LowerRy.Value = 0.0;
            }

            ModObject.PropertyChanged += ModObject_PropertyChanged;
        }
        #endregion


        #region [override method]
        private void ModObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            var obj = sender as Algo90SubLamiObject;
            if (e.PropertyName == "CalcType")
            {
                if(obj.CalcType == CalcType.Align)
                {
                    obj.ModelParamType = typeof(Algo90SubLamiAlignModelParams);
                    var param = obj.CurParams as Algo90SubLamiAlignModelParams;

                    ChildSettingView = new AlignSetting();
                    ChildSettingView.DataContext = this;
                }
                else if(obj.CalcType == CalcType.Inspection)
                {
                    obj.ModelParamType = typeof(Algo90SubLamiInspectModelParams);
                    var param = obj.CurParams as Algo90SubLamiInspectModelParams;

                    ChildSettingView = new InspectionSetting();
                    ChildSettingView.DataContext = this;
                }
            }
        }


        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as Algo90SubLamiObject;
            

            if (InputName.Equals("OCA_1st_L") && Obj.CalcType == CalcType.Inspection) Obj.GetCurrentPos(GrabPos.OCA_1st);
            else if (InputName.Equals("OCA_2st_L") && Obj.CalcType == CalcType.Inspection) Obj.GetCurrentPos(GrabPos.OCA_2st);
            else if (InputName.Equals("PNL_1st_L") && Obj.CalcType == CalcType.Inspection) Obj.GetCurrentPos(GrabPos.PNL_1st);
            else if (InputName.Equals("PNL_2st_L") && Obj.CalcType == CalcType.Inspection) Obj.GetCurrentPos(GrabPos.PNL_2st);

            else if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                //Obj.SourceID = ObjectID;
                if (!Obj.Run(useUnloadOffset))
                {
                    OutputPlay("LogResult", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                    // Length Check일때는 메뉴얼마크 후 다시 계산할수 있도록 한다.
                    if (Obj.ErrorCode == Algo90SubLamiAction.Err_Length_Check)
                    {
                        ReplyArgs.Clear();

                        if (!Obj.Pnl34_judge || !Obj.Pnl14_judge)
                        {
                            var error = SystemInfo.GetErrorInfo(Err_PNL_LENGTH_NG);
                            error.Owner = this.Parent; // Error Owner가 이상하게 올라오고 있었음 뜨아~
                            ReplyArgs.Add(new CommandReplyArgs(this.Parent, CmdReply.Error, error, null));
                        }
                        if (!Obj.Oca34_judge || !Obj.Oca14_judge)
                        {
                            var error = SystemInfo.GetErrorInfo(Err_OCA_LENGTH_NG);
                            error.Owner = this.Parent; // Error Owner가 이상하게 올라오고 있었음 뜨아~
                            ReplyArgs.Add(new CommandReplyArgs(this.Parent, CmdReply.Error, error, null));
                        }

                        return End();
                    }

                    return OccurError(Obj.ErrorCode);
                }
                else
                {
                    if (Obj.CalcType == CalcType.Inspection)
                    {
                        var rst = Obj.AlgoRst as Algo90SubLamiInspectResult;
                        Cur_UpperLx = rst.UpperLx;
                        Cur_UpperLy = rst.UpperLy;
                        Cur_LowerLx = rst.LowerLx;
                        Cur_LowerLy = rst.LowerLy;
                        Cur_LowerRx = rst.LowerRx;
                        Cur_LowerRy = rst.LowerRy;
                    }

                }
                #endregion

                #region Step2 : Result Data Show
                ReplyArgs = OutputPlay("LogResult", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                #endregion

                Obj.AppendMessage(Name, "Caluration Complete");
                StopTimer();
            }

            return End(false);
        }


        #region [Command]
        [field:NonSerialized]
        private DelegateCommand scaleResetCommand;
        public DelegateCommand ScaleResetCommand
        {
            get
            {
                return scaleResetCommand = scaleResetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo90SubLamiInspectModelParams;
                    var cur = Obj.ModelParams[SystemModel.GetCurModel()] as Algo90SubLamiInspectModelParams;

                    tmp.Scale_UpperLx.Value = (double)1.0;
                    tmp.Scale_UpperLy.Value = (double)1.0;
                    tmp.Scale_LowerLx.Value = (double)1.0;
                    tmp.Scale_LowerLy.Value = (double)1.0;
                    tmp.Scale_LowerRx.Value = (double)1.0;
                    tmp.Scale_LowerRy.Value = (double)1.0;


                    //cur_UpperLx /= (double)cur.Scale_UpperLx.Value;
                    //cur_UpperLy /= (double)cur.Scale_UpperLy.Value;
                    //cur_LowerLx /= (double)cur.Scale_LowerLx.Value;
                    //cur_LowerLy /= (double)cur.Scale_LowerLy.Value;
                    //cur_LowerRx /= (double)cur.Scale_LowerRx.Value;
                    //cur_LowerRy /= (double)cur.Scale_LowerRy.Value;

                    Obj.UpdateTempValues();

                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand scaleCalcCommand;
        public DelegateCommand ScaleCalcCommand
        {
            get
            {
                return scaleCalcCommand = scaleCalcCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as Algo90SubLamiInspectModelParams;

                    var upperLx = (double)temp_UpperLx.Value;
                    var upperLy = (double)temp_UpperLy.Value;
                    var lowerLx = (double)temp_LowerLx.Value;
                    var lowerLy = (double)temp_LowerLy.Value;
                    var lowerRx = (double)temp_LowerRx.Value;
                    var lowerRy = (double)temp_LowerRy.Value;

                    var spec_upperLx = (double)tmp.Spec_UpperLx.Value;
                    var spec_upperLy = (double)tmp.Spec_UpperLy.Value;
                    var spec_lowerLx = (double)tmp.Spec_LowerLx.Value;
                    var spec_lowerLy = (double)tmp.Spec_LowerLy.Value;
                    var spec_lowerRx = (double)tmp.Spec_LowerRx.Value;
                    var spec_lowerRy = (double)tmp.Spec_LowerRy.Value;

                    double range = 2;
                    if (!AlgoObjectBase.ConfirmTempValue(upperLx, spec_upperLx, range)) { RadWindow.Alert(string.Format("Check input value![UpperLx :{0}][Range {1} ~ {2}]", upperLx, spec_upperLx - range, spec_upperLx + range)); return; }
                    if (!AlgoObjectBase.ConfirmTempValue(upperLy, spec_upperLy, range)) { RadWindow.Alert(string.Format("Check input value![UpperLy :{0}][Range {1} ~ {2}]", upperLy, spec_upperLy - range, spec_upperLy + range)); return; }
                    if (!AlgoObjectBase.ConfirmTempValue(lowerLx, spec_lowerLx, range)) { RadWindow.Alert(string.Format("Check input value![LowerLx :{0}][Range {1} ~ {2}]", lowerLx, spec_lowerLx - range, spec_lowerLx + range)); return; }
                    if (!AlgoObjectBase.ConfirmTempValue(lowerLy, spec_lowerLy, range)) { RadWindow.Alert(string.Format("Check input value![LowerLy :{0}][Range {1} ~ {2}]", lowerLy, spec_lowerLy - range, spec_lowerLy + range)); return; }
                    if (!AlgoObjectBase.ConfirmTempValue(lowerRx, spec_lowerRx, range)) { RadWindow.Alert(string.Format("Check input value![LowerRx :{0}][Range {1} ~ {2}]", lowerRx, spec_lowerRx - range, spec_lowerRx + range)); return; }
                    if (!AlgoObjectBase.ConfirmTempValue(lowerRy, spec_lowerRy, range)) { RadWindow.Alert(string.Format("Check input value![LowerRy :{0}][Range {1} ~ {2}]", lowerRy, spec_lowerRy - range, spec_lowerRy + range)); return; }

                    tmp.Scale_UpperLx.Value = upperLx / cur_UpperLx;
                    tmp.Scale_UpperLy.Value = upperLy / cur_UpperLy;
                    tmp.Scale_LowerLx.Value = lowerLx / cur_LowerLx;
                    tmp.Scale_LowerLy.Value = lowerLy / cur_LowerLy;
                    tmp.Scale_LowerRx.Value = lowerRx / cur_LowerRx;
                    tmp.Scale_LowerRy.Value = lowerRy / cur_LowerRy;

                    Obj.UpdateTempValues();


                    //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
                    //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
                    //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
                    //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
                    //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
                    //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;


                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand reMeasureCommand;
        public DelegateCommand ReMeasureCommand
        {
            get
            {
                return reMeasureCommand = reMeasureCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = ModObject as Algo90SubLamiObject;
                    var cur = Obj.ModelParams[SystemModel.GetCurModel()] as Algo90SubLamiInspectModelParams;
                    var tmp = Obj.ChangeParams as Algo90SubLamiInspectModelParams;

                    //cur_UpperLx /= (double)cur.Scale_UpperLx.Value;
                    //cur_UpperLy /= (double)cur.Scale_UpperLy.Value;
                    //cur_LowerLx /= (double)cur.Scale_LowerLx.Value;
                    //cur_LowerLy /= (double)cur.Scale_LowerLy.Value;
                    //cur_LowerRx /= (double)cur.Scale_LowerRx.Value;
                    //cur_LowerRy /= (double)cur.Scale_LowerRy.Value;

                    //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
                    //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
                    //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
                    //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
                    //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
                    //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;


                    Obj.Name = name;    // 이름 넣어주기.
                                        //Obj.SourceID = ObjectID;
                    Obj.InspectCalc(true);

                    var rst = Obj.AlgoRst as Algo90SubLamiInspectResult;
                    Cur_UpperLx = rst.UpperLx;
                    Cur_UpperLy = rst.UpperLy;
                    Cur_LowerLx = rst.LowerLx;
                    Cur_LowerLy = rst.LowerLy;
                    Cur_LowerRx = rst.LowerRx;
                    Cur_LowerRy = rst.LowerRy;
          

                });

            }
        }
        #endregion


        public override void PrepareSave()
        {
            base.PrepareSave();

            //var obj = ModObject as AlgoObjectBase;
            //var cur = obj.ModelParams[SystemModel.GetCurModel()] as Algo90SubLamiInspectModelParams;
            //var tmp = obj.TempParams as Algo90SubLamiInspectModelParams;

            //cur_UpperLx /= (double)cur.Scale_UpperLx.Value;
            //cur_UpperLy /= (double)cur.Scale_UpperLy.Value;
            //cur_LowerLx /= (double)cur.Scale_LowerLx.Value;
            //cur_LowerLy /= (double)cur.Scale_LowerLy.Value;
            //cur_LowerRx /= (double)cur.Scale_LowerRx.Value;
            //cur_LowerRy /= (double)cur.Scale_LowerRy.Value;

            //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
            //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
            //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
            //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
            //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
            //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;


        }

        public override void Object_Saved()
        {
            string model = SystemModel.GetCurModel();
            var obj = ModObject as Algo90SubLamiObject;
            AlgoParams modelParams;
            if (!obj.ModelParams.TryGetValue(model, out modelParams)) return;

            var mParams = modelParams as Algo90SubLamiAlignModelParams;

            if (mParams == null) return;
            Pnl34_spec = (double)mParams.Pnl34.Value;
            Pnl14_spec = (double)mParams.Pnl14.Value;
            Oca34_spec = (double)mParams.Oca34.Value;
            Oca14_spec = (double)mParams.Oca14.Value;

            Pnl34_tor = (double)mParams.Pnl34_tor.Value;
            Pnl14_tor = (double)mParams.Pnl14_tor.Value;
            Oca34_tor = (double)mParams.Oca34_tor.Value;
            Oca14_tor = (double)mParams.Oca14_tor.Value;

            base.Object_Saved();
        }

        public override void Dispose()
        {
            ModObject.PropertyChanged -= ModObject_PropertyChanged;

            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion


        #region Command
        AlgoParams m_CurParam;
        [field: NonSerialized]
        private DelegateCommand panelLengthSetCommand;
        public DelegateCommand PanelLengthSetCommand
        {
            get
            {
                return panelLengthSetCommand = panelLengthSetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = ModObject as Algo90SubLamiObject;
                    var tmpParam = Obj.TempParams as Algo90SubLamiAlignModelParams;
                    m_CurParam = DeepClone<AlgoParams>(Obj.CurParams);

                    tmpParam.Pnl14.Value = Obj.Pnl14_rst;
                    tmpParam.Pnl34.Value = Obj.Pnl34_rst;
                    Pnl14_spec = Obj.Pnl14_rst;
                    Pnl34_spec = Obj.Pnl34_rst;

                    Obj.UpdateTempValues();
                });
            }
        }

        [field: NonSerialized]
        private DelegateCommand panelLengthReloadCommand;
        public DelegateCommand PanelLengthReloadCommand
        {
            get
            {
                return panelLengthReloadCommand = panelLengthReloadCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = ModObject as Algo90SubLamiObject;
                    var tmp = Obj.TempParams as Algo90SubLamiAlignModelParams;
                    var cur = m_CurParam as Algo90SubLamiAlignModelParams;

                    tmp.Pnl14.Value = cur.Pnl14.Value;
                    tmp.Pnl34.Value = cur.Pnl34.Value;
                    Pnl14_spec = (double)cur.Pnl14.Value;
                    Pnl34_spec = (double)cur.Pnl34.Value;

                    Obj.UpdateTempValues();
                });
            }
        }

        [field: NonSerialized]
        private DelegateCommand ocaLengthSetCommand;
        public DelegateCommand OcaLengthSetCommand
        {
            get
            {
                return ocaLengthSetCommand = ocaLengthSetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = ModObject as Algo90SubLamiObject;
                    var tmpParam = Obj.TempParams as Algo90SubLamiAlignModelParams;
                    m_CurParam = DeepClone<AlgoParams>(Obj.CurParams);

                    tmpParam.Oca14.Value = Obj.Oca14_rst;
                    tmpParam.Oca34.Value = Obj.Oca34_rst;
                    Oca14_spec = Obj.Oca14_rst;
                    Oca34_spec = Obj.Oca34_rst;

                    Obj.UpdateTempValues();

 

                });
            }
        }

        [field: NonSerialized]
        private DelegateCommand ocaLengthReloadCommand;
        public DelegateCommand OcaLengthReloadCommand
        {
            get
            {
                return ocaLengthReloadCommand = ocaLengthReloadCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = ModObject as Algo90SubLamiObject;
                    var tmp = Obj.TempParams as Algo90SubLamiAlignModelParams;
                    var cur = m_CurParam as Algo90SubLamiAlignModelParams;

                    tmp.Oca14.Value = cur.Oca14.Value;
                    tmp.Oca34.Value = cur.Oca34.Value;
                    Oca14_spec = (double)cur.Oca14.Value;
                    Oca34_spec = (double)cur.Oca34.Value;

                    Obj.UpdateTempValues();
                });
            }
        }
        #endregion
    }
}
