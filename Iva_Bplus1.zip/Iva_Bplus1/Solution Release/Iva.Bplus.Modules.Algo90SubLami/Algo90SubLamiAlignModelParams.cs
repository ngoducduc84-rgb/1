﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]

    public partial class Algo90SubLamiAlignModelParams : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        private AlgoParam pnl34;
        private AlgoParam pnl14;
        private AlgoParam oca34;
        private AlgoParam oca14;

        private AlgoParam pnl34_tor;
        private AlgoParam pnl14_tor;
        private AlgoParam oca34_tor;
        private AlgoParam oca14_tor;

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        public AlgoParam Pnl34 { get { return pnl34; } set { if (pnl34 == value) return; pnl34 = value; this.OnPropertyChanged(nameof(Pnl34)); } }
        public AlgoParam Pnl14 { get { return pnl14; } set { if (pnl14 == value) return; pnl14 = value; this.OnPropertyChanged(nameof(Pnl14)); } }
        public AlgoParam Oca34 { get { return oca34; } set { if (oca34 == value) return; oca34 = value; this.OnPropertyChanged(nameof(Oca34)); } }
        public AlgoParam Oca14 { get { return oca14; } set { if (oca14 == value) return; oca14 = value; this.OnPropertyChanged(nameof(Oca14)); } }
        public AlgoParam Pnl34_tor { get { return pnl34_tor; } set { if (pnl34_tor == value) return; pnl34_tor = value; this.OnPropertyChanged(nameof(Pnl34_tor)); } }
        public AlgoParam Pnl14_tor { get { return pnl14_tor; } set { if (pnl14_tor == value) return; pnl14_tor = value; this.OnPropertyChanged(nameof(Pnl14_tor)); } }
        public AlgoParam Oca34_tor { get { return oca34_tor; } set { if (oca34_tor == value) return; oca34_tor = value; this.OnPropertyChanged(nameof(Oca34_tor)); } }
        public AlgoParam Oca14_tor { get { return oca14_tor; } set { if (oca14_tor == value) return; oca14_tor = value; this.OnPropertyChanged(nameof(Oca14_tor)); } }
        public Algo90SubLamiAlignModelParams()
            :base()
        {
            LimitX      = new AlgoParam("LimitX",      "mm",   typeof(double), 0.0,        "Revision Offset Limit X",      (double)-5.0,       (double)+5.0     );
            LimitY      = new AlgoParam("LimitY",      "mm",   typeof(double), 0.0,        "Revision Offset Limit Y",      (double)-5.0,       (double)+5.0     );
            LimitT      = new AlgoParam("LimitT",      "deg",  typeof(double), 0.0,        "Revision Offset Limit T",      (double)-5.0,       (double)+5.0     );

            Pnl34       = new AlgoParam("Pnl34",       "mm",   typeof(double), 0.0,        "Panel Length 3 to 4",          (double)0.0,        (double)+1000.0  );
            Pnl14       = new AlgoParam("Pnl14",       "mm",   typeof(double), 0.0,        "Panel Length 1 to 4",          (double)0.0,        (double)+1000.0  );
            Oca34       = new AlgoParam("Oca34",       "mm",   typeof(double), 0.0,        "OCA Length 3 to 4",            (double)0.0,        (double)+1000.0  );
            Oca14       = new AlgoParam("Oca14",       "mm",   typeof(double), 0.0,        "OCA Length 1 to 4",            (double)0.0,        (double)+1000.0  );


            Pnl34_tor   = new AlgoParam("Pnl34_tor",   "mm",   typeof(double), 0.0,        "Panel Length 3 to 4",          (double)0.0,        (double)+5.0  );
            Pnl14_tor   = new AlgoParam("Pnl14_tor",   "mm",   typeof(double), 0.0,        "Panel Length 1 to 4",          (double)0.0,        (double)+5.0  );
            Oca34_tor   = new AlgoParam("Oca34_tor",   "mm",   typeof(double), 0.0,        "OCA Length 3 to 4",            (double)0.0,        (double)+5.0  );
            Oca14_tor   = new AlgoParam("Oca14_tor",   "mm",   typeof(double), 0.0,        "OCA Length 1 to 4",            (double)0.0,        (double)+5.0  );

        }
    }
}
