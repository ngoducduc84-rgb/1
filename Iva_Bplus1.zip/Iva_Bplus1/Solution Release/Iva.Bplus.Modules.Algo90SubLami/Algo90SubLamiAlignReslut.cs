﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]
    public class Algo90SubLamiAlignResult : AlgoResultBase
    {
        #region [fiedls]
        private double attachRevX;
        private double attachRevY;
        private double attachRevT;

        private double unloadRevX;
        private double unloadRevY;
        private double unloadRevT;

        private double offsetX;
        private double offsetY;
        private double offsetT;

        private double oca_1st_Lx;
        private double oca_1st_Ly;
        private double oca_1st_Rx;
        private double oca_1st_Ry;
        private double oca_2st_Lx;
        private double oca_2st_Ly;

        private double pnl_1st_Lx;
        private double pnl_1st_Ly;
        private double pnl_2st_Lx;   
        private double pnl_2st_Ly;
        private double pnl_2st_Rx;
        private double pnl_2st_Ry;

        private double oca_1st_Lx_px;
        private double oca_1st_Ly_px;
        private double oca_1st_Rx_px;
        private double oca_1st_Ry_px;
        private double oca_2st_Lx_px;
        private double oca_2st_Ly_px;
                                
        private double pnl_1st_Lx_px;
        private double pnl_1st_Ly_px;
        private double pnl_2st_Lx_px;
        private double pnl_2st_Ly_px;
        private double pnl_2st_Rx_px;
        private double pnl_2st_Ry_px;

        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double AttachRevX
        {
            get { return attachRevX; }
            set { if (value == attachRevX) return; attachRevX = value; OnPropertyChanged(nameof(AttachRevX)); }
        }
        public double AttachRevY
        {
            get { return attachRevY; }
            set { if (value == attachRevY) return; attachRevY = value; OnPropertyChanged(nameof(AttachRevY)); }
        }
        public double AttachRevT
        {
            get { return attachRevT; }
            set { if (value == attachRevT) return; attachRevT = value; OnPropertyChanged(nameof(AttachRevT)); }
        }
        public double UnloadRevX
        {
            get { return unloadRevX; }
            set { if (value == unloadRevX) return; unloadRevX = value; OnPropertyChanged(nameof(UnloadRevX)); }
        }
        public double UnloadRevY
        {
            get { return unloadRevY; }
            set { if (value == unloadRevY) return; unloadRevY = value; OnPropertyChanged(nameof(UnloadRevY)); }
        }
        public double UnloadRevT
        {
            get { return unloadRevT; }
            set { if (value == unloadRevT) return; unloadRevT = value; OnPropertyChanged(nameof(UnloadRevT)); }
        }
        public double OffsetX
        {
            get { return offsetX; }
            set { if (value == offsetX) return; offsetX = value; OnPropertyChanged(nameof(OffsetX)); }
        }
        public double OffsetY
        {
            get { return offsetY; }
            set { if (value == offsetY) return; offsetY = value; OnPropertyChanged(nameof(OffsetY)); }
        }
        public double OffsetT
        {
            get { return offsetT; }
            set { if (value == offsetT) return; offsetT = value; OnPropertyChanged(nameof(OffsetT)); }
        }

        public double Oca_1st_Lx
        {
            get { return oca_1st_Lx; }
            set { if (value == oca_1st_Lx) return; oca_1st_Lx = value; OnPropertyChanged(nameof(Oca_1st_Lx)); }
        }
        public double Oca_1st_Ly
        {
            get { return oca_1st_Ly; }
            set { if (value == oca_1st_Ly) return; oca_1st_Ly = value; OnPropertyChanged(nameof(Oca_1st_Ly)); }
        }
        
        public double Oca_1st_Rx
        {
            get { return oca_1st_Rx; }
            set { if (value == oca_1st_Rx) return; oca_1st_Rx = value; OnPropertyChanged(nameof(Oca_1st_Rx)); }
        }

        public double Oca_1st_Ry
        {
            get { return oca_1st_Ry; }
            set { if (value == oca_1st_Ry) return; oca_1st_Ry = value; OnPropertyChanged(nameof(Oca_1st_Ry)); }
        }
        
        public double Oca_2st_Lx
        {
            get { return oca_2st_Lx; }
            set { if (value == oca_2st_Lx) return; oca_2st_Lx = value; OnPropertyChanged(nameof(Oca_2st_Lx)); }
        }

        public double Oca_2st_Ly
        {
            get { return oca_2st_Ly; }
            set { if (value == oca_2st_Ly) return; oca_2st_Ly = value; OnPropertyChanged(nameof(Oca_2st_Ly)); }
        }    
        
        public double Pnl_1st_Lx
        {
            get { return pnl_1st_Lx; }
            set { if (value == pnl_1st_Lx) return; pnl_1st_Lx = value; OnPropertyChanged(nameof(Pnl_1st_Lx)); }
        }
        public double Pnl_1st_Ly
        {
            get { return pnl_1st_Ly; }
            set { if (value == pnl_1st_Ly) return; pnl_1st_Ly = value; OnPropertyChanged(nameof(Pnl_1st_Ly)); }
        }

        public double Pnl_2st_Lx
        {
            get { return pnl_2st_Lx; }
            set { if (value == pnl_2st_Lx) return; pnl_2st_Lx = value; OnPropertyChanged(nameof(Pnl_2st_Lx)); }
        }
        public double Pnl_2st_Ly
        {
            get { return pnl_2st_Ly; }
            set { if (value == pnl_2st_Ly) return; pnl_2st_Ly = value; OnPropertyChanged(nameof(Pnl_2st_Ly)); }
        }

        public double Pnl_2st_Rx
        {
            get { return pnl_2st_Rx; }
            set { if (value == pnl_2st_Rx) return; pnl_2st_Rx = value; OnPropertyChanged(nameof(Pnl_2st_Rx)); }
        }
        
        public double Pnl_2st_Ry
        {
            get { return pnl_2st_Ry; }
            set { if (value == pnl_2st_Ry) return; pnl_2st_Ry = value; OnPropertyChanged(nameof(Pnl_2st_Ry)); }
        }

        public double Oca_1st_Lx_px
        {
            get { return oca_1st_Lx_px; }
            set { if (value == oca_1st_Lx_px) return; oca_1st_Lx_px = value; OnPropertyChanged(nameof(Oca_1st_Lx)); }
        }
        public double Oca_1st_Ly_px
        {
            get { return oca_1st_Ly_px; }
            set { if (value == oca_1st_Ly_px) return; oca_1st_Ly_px = value; OnPropertyChanged(nameof(Oca_1st_Ly)); }
        }

        public double Oca_1st_Rx_px
        {
            get { return oca_1st_Rx; }
            set { if (value == oca_1st_Rx) return; oca_1st_Rx = value; OnPropertyChanged(nameof(Oca_1st_Rx)); }
        }

        public double Oca_1st_Ry_px
        {
            get { return oca_1st_Ry_px; }
            set { if (value == oca_1st_Ry_px) return; oca_1st_Ry_px = value; OnPropertyChanged(nameof(Oca_1st_Ry)); }
        }

        public double Oca_2st_Lx_px
        {
            get { return oca_2st_Lx_px; }
            set { if (value == oca_2st_Lx_px) return; oca_2st_Lx_px = value; OnPropertyChanged(nameof(Oca_2st_Lx)); }
        }

        public double Oca_2st_Ly_px
        {
            get { return oca_2st_Ly_px; }
            set { if (value == oca_2st_Ly_px) return; oca_2st_Ly_px = value; OnPropertyChanged(nameof(Oca_2st_Ly)); }
        }

        public double Pnl_1st_Lx_px
        {
            get { return pnl_1st_Lx_px; }
            set { if (value == pnl_1st_Lx_px) return; pnl_1st_Lx_px = value; OnPropertyChanged(nameof(Pnl_1st_Lx)); }
        }
        public double Pnl_1st_Ly_px
        {
            get { return pnl_1st_Ly_px; }
            set { if (value == pnl_1st_Ly_px) return; pnl_1st_Ly_px = value; OnPropertyChanged(nameof(Pnl_1st_Ly)); }
        }

        public double Pnl_2st_Lx_px
        {
            get { return pnl_2st_Lx_px; }
            set { if (value == pnl_2st_Lx_px) return; pnl_2st_Lx_px = value; OnPropertyChanged(nameof(Pnl_2st_Lx)); }
        }
        public double Pnl_2st_Ly_px
        {
            get { return pnl_2st_Ly_px; }
            set { if (value == pnl_2st_Ly_px) return; pnl_2st_Ly_px = value; OnPropertyChanged(nameof(Pnl_2st_Ly)); }
        }

        public double Pnl_2st_Rx_px
        {
            get { return pnl_2st_Rx_px; }
            set { if (value == pnl_2st_Rx_px) return; pnl_2st_Rx_px = value; OnPropertyChanged(nameof(Pnl_2st_Rx)); }
        }

        public double Pnl_2st_Ry_px
        {
            get { return pnl_2st_Ry_px; }
            set { if (value == pnl_2st_Ry_px) return; pnl_2st_Ry_px = value; OnPropertyChanged(nameof(Pnl_2st_Ry)); }
        }
        #endregion


        public Algo90SubLamiAlignResult() : base() { }
        
        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1}\n,curTime: {2}\n, " +
                                  "attachRevX: {3}\n,attachRevY: {4}\n,attachRevT: {5}\n" +
                                  "unloadRevX: {6}\n,unloadRevY: {7}\n,unloadRevT: {8}\n" +
                                  "offsetX: {9}\n,offsetY: {10}\n,offsetT: {11}\n"
                                  , typeof(Algo90SubLamiAlignResult).ToString(), curTime, curDate
                                  , attachRevX, attachRevY, attachRevT
                                  , unloadRevX, unloadRevY, unloadRevT
                                  , offsetX, offsetY, offsetT
                                  );
        }
    }
}
