﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]

    public partial class Algo90SubLamiInspectModelParams : AlgoParams
    {
        private AlgoParam scale_UpperLx;
        private AlgoParam scale_UpperLy;
        private AlgoParam scale_LowerLx;
        private AlgoParam scale_LowerLy;
        private AlgoParam scale_LowerRx;
        private AlgoParam scale_LowerRy;

        private AlgoParam spec_UpperLx;
        private AlgoParam spec_UpperLy;
        private AlgoParam spec_LowerLx;
        private AlgoParam spec_LowerLy;
        private AlgoParam spec_LowerRx;
        private AlgoParam spec_LowerRy;

        private AlgoParam judge_Upper_Center;
        //private AlgoParam judge_Lower_Center;
        //private AlgoParam judge_Left_Center;
        private AlgoParam judge_Right_Center;

        private AlgoParam judge_Upper_Range;
        //private AlgoParam judge_Lower_Range;
        //private AlgoParam judge_Left_Range;
        private AlgoParam judge_Right_Range;

        public AlgoParam Scale_UpperLx { get { return scale_UpperLx; } set { if (scale_UpperLx == value) return; scale_UpperLx = value; this.OnPropertyChanged(nameof(Scale_UpperLx)); } }
        public AlgoParam Scale_UpperLy { get { return scale_UpperLy; } set { if (scale_UpperLy == value) return; scale_UpperLy = value; this.OnPropertyChanged(nameof(Scale_UpperLy)); } }
        public AlgoParam Scale_LowerLx { get { return scale_LowerLx; } set { if (scale_LowerLx == value) return; scale_LowerLx = value; this.OnPropertyChanged(nameof(Scale_LowerLx)); } }
        public AlgoParam Scale_LowerLy { get { return scale_LowerLy; } set { if (scale_LowerLy == value) return; scale_LowerLy = value; this.OnPropertyChanged(nameof(Scale_LowerLy)); } }
        public AlgoParam Scale_LowerRx { get { return scale_LowerRx; } set { if (scale_LowerRx == value) return; scale_LowerRx = value; this.OnPropertyChanged(nameof(Scale_LowerRx)); } }
        public AlgoParam Scale_LowerRy { get { return scale_LowerRy; } set { if (scale_LowerRy == value) return; scale_LowerRy = value; this.OnPropertyChanged(nameof(Scale_LowerRy)); } }
        public AlgoParam Spec_UpperLx { get { return spec_UpperLx; } set { if (spec_UpperLx == value) return; spec_UpperLx = value; this.OnPropertyChanged(nameof(Spec_UpperLx)); } }
        public AlgoParam Spec_UpperLy { get { return spec_UpperLy; } set { if (spec_UpperLy == value) return; spec_UpperLy = value; this.OnPropertyChanged(nameof(Spec_UpperLy)); } }
        public AlgoParam Spec_LowerLx { get { return spec_LowerLx; } set { if (spec_LowerLx == value) return; spec_LowerLx = value; this.OnPropertyChanged(nameof(Spec_LowerLx)); } }
        public AlgoParam Spec_LowerLy { get { return spec_LowerLy; } set { if (spec_LowerLy == value) return; spec_LowerLy = value; this.OnPropertyChanged(nameof(Spec_LowerLy)); } }
        public AlgoParam Spec_LowerRx { get { return spec_LowerRx; } set { if (spec_LowerRx == value) return; spec_LowerRx = value; this.OnPropertyChanged(nameof(Spec_LowerRx)); } }
        public AlgoParam Spec_LowerRy { get { return spec_LowerRy; } set { if (spec_LowerRy == value) return; spec_LowerRy = value; this.OnPropertyChanged(nameof(Spec_LowerRy)); } }
        public AlgoParam Judge_Upper_Center { get { return judge_Upper_Center; } set { if (judge_Upper_Center == value) return; judge_Upper_Center = value; this.OnPropertyChanged(nameof(Judge_Upper_Center)); } }
        //public AlgoParam Judge_Lower_Center { get { return judge_Lower_Center; } set { if (judge_Lower_Center == value) return; judge_Lower_Center = value; this.OnPropertyChanged(nameof(Judge_Lower_Center)); } }
        //public AlgoParam Judge_Left_Center { get { return judge_Left_Center; } set { if (judge_Left_Center == value) return; judge_Left_Center = value; this.OnPropertyChanged(nameof(Judge_Left_Center)); } }
        public AlgoParam Judge_Right_Center { get { return judge_Right_Center; } set { if (judge_Right_Center == value) return; judge_Right_Center = value; this.OnPropertyChanged(nameof(Judge_Right_Center)); } }
        public AlgoParam Judge_Upper_Range { get { return judge_Upper_Range; } set { if (judge_Upper_Range == value) return; judge_Upper_Range = value; this.OnPropertyChanged(nameof(Judge_Upper_Range)); } }
        //public AlgoParam Judge_Lower_Range { get { return judge_Lower_Range; } set { if (judge_Lower_Range == value) return; judge_Lower_Range = value; this.OnPropertyChanged(nameof(Judge_Lower_Range)); } }
        //public AlgoParam Judge_Left_Range { get { return judge_Left_Range; } set { if (judge_Left_Range == value) return; judge_Left_Range = value; this.OnPropertyChanged(nameof(Judge_Left_Range)); } }
        public AlgoParam Judge_Right_Range { get { return judge_Right_Range; } set { if (judge_Right_Range == value) return; judge_Right_Range = value; this.OnPropertyChanged(nameof(Judge_Right_Range)); } }


        public Algo90SubLamiInspectModelParams()
            :base()
        {

            Scale_UpperLx = new AlgoParam("Scale_UpperLx", "rate", typeof(double), (double)1.0, "Scale Upper Left Width", (double)0.5, (double)2.0);
            Scale_UpperLy = new AlgoParam("Scale_UpperLy", "rate", typeof(double), (double)1.0, "Scale Upper Left Height", (double)0.5, (double)2.0);
            Scale_LowerLx = new AlgoParam("Scale_LowerLx", "rate", typeof(double), (double)1.0, "Scale Lower Left Width", (double)0.5, (double)2.0);
            Scale_LowerLy = new AlgoParam("Scale_LowerLy", "rate", typeof(double), (double)1.0, "Scale Lower Left Height", (double)0.5, (double)2.0);
            Scale_LowerRx = new AlgoParam("Scale_LowerRx", "rate", typeof(double), (double)1.0, "Scale Lower Right Width", (double)0.5, (double)2.0);
            Scale_LowerRy = new AlgoParam("Scale_LowerRy", "rate", typeof(double), (double)1.0, "Scale Lower Right Height", (double)0.5, (double)2.0);


            Spec_UpperLx = new AlgoParam("Spec_UpperLx", "mm", typeof(double), (double)0, "Spec Upper Left Width (X3)", (double)0.001, (double)1000);
            Spec_UpperLy = new AlgoParam("Spec_UpperLy", "mm", typeof(double), (double)0, "Spec Upper Left Height (Y3)", (double)0.001, (double)1000);
            Spec_LowerLx = new AlgoParam("Spec_LowerLx", "mm", typeof(double), (double)0, "Spec Lower Left Width (X4)", (double)0.001, (double)1000);
            Spec_LowerLy = new AlgoParam("Spec_LowerLy", "mm", typeof(double), (double)0, "Spec Lower Left Height (Y4)", (double)0.001, (double)1000);
            Spec_LowerRx = new AlgoParam("Spec_LowerRx", "mm", typeof(double), (double)0, "Spec Lower Right Width (X1)", (double)0.001, (double)1000);
            Spec_LowerRy = new AlgoParam("Spec_LowerRy", "mm", typeof(double), (double)0, "Spec Lower Right Height (Y1)", (double)0.001, (double)1000);

            Judge_Upper_Center = new AlgoParam("Judge_Upper_Center", "mm", typeof(double), (double)0, "상변 판정 기준의 중심값 ((x4-x1)/2)", (double)0.0, (double)1.0);
            //Judge_Lower_Center = new AlgoParam("Judge_Lower_Center", "mm", typeof(double), (double)0, "하변 판정 기준의 중심값 ((x3-x2)/2)", (double)0.0, (double)1.0);
            //Judge_Left_Center = new AlgoParam("Judge_Left_Center", "mm", typeof(double), (double)0, "좌변 판정 기준의 중심값 ((y1-y2)/2)", (double)0.0, (double)1.0);
            Judge_Right_Center = new AlgoParam("Judge_Right_Center", "mm", typeof(double), (double)0, "우변 판정 기준의 중심값 ((y4-y3)/2)", (double)0.0, (double)1.0);

            Judge_Upper_Range = new AlgoParam("Judge_Upper_Range", "mm", typeof(double), (double)0, "상변 판정 범위 (Center ± Range)", (double)0.0, (double)1.0);
            //Judge_Lower_Range = new AlgoParam("Judge_Lower_Range", "mm", typeof(double), (double)0, "하변 판정 범위 (Center ± Range)", (double)0.0, (double)1.0);
            //Judge_Left_Range = new AlgoParam("Judge_Left_Range", "mm", typeof(double), (double)0, "좌변 판정 범위 (Center ± Range)", (double)0.0, (double)1.0);
            Judge_Right_Range = new AlgoParam("Judge_Right_Range", "mm", typeof(double), (double)0, "우변 판정 범위 (Center ± Range)", (double)0.0, (double)1.0);


        }
    }
}
