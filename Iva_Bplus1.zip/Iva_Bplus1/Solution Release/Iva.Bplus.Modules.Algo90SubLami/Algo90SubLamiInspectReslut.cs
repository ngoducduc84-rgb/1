﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]
    public class Algo90SubLamiInspectResult : AlgoResultBase
    {
        #region [fiedls]
        private double revX;
        private double revY;
        private double revT;
        private double upperLx;
        private double upperLy;
        private double lowerLx;
        private double lowerLy;
        private double lowerRx;
        private double lowerRy;
        private double lower;
        private double right;

        private bool judge_UpperLx;
        private bool judge_UpperLy;
        private bool judge_LowerLx;
        private bool judge_LowerLy;
        private bool judge_LowerRx;
        private bool judge_LowerRy;
        private bool judge_Upper;
        private bool judge_Right;

        private double oca_1st_Lx;
        private double oca_1st_Ly;
        private double oca_2st_Lx;
        private double oca_2st_Ly;
        private double oca_2st_Rx;
        private double oca_2st_Ry;

        private double pnl_1st_Lx;
        private double pnl_1st_Ly;
        private double pnl_2st_Lx;
        private double pnl_2st_Ly;
        private double pnl_2st_Rx;
        private double pnl_2st_Ry;

        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double RevX
        {
            get { return revX; }
            set { if (value == revX) return; revX = value; OnPropertyChanged(nameof(RevX)); }
        }
        public double RevY
        {
            get { return revY; }
            set { if (value == revY) return; revY = value; OnPropertyChanged(nameof(RevY)); }
        }
        public double RevT
        {
            get { return revT; }
            set { if (value == revT) return; revT = value; OnPropertyChanged(nameof(RevT)); }
        }

        public double UpperLx
        {
            get { return upperLx; }
            set { if (value == upperLx) return; upperLx = value; OnPropertyChanged(nameof(UpperLx)); }
        }
        public double UpperLy
        {
            get { return upperLy; }
            set { if (value == upperLy) return; upperLy = value; OnPropertyChanged(nameof(UpperLy)); }
        }
        public double LowerLx
        {
            get { return lowerLx; }
            set { if (value == lowerLx) return; lowerLx = value; OnPropertyChanged(nameof(LowerLx)); }
        }
        public double LowerLy
        {
            get { return lowerLy; }
            set { if (value == lowerLy) return; lowerLy = value; OnPropertyChanged(nameof(LowerLy)); }
        }
        public double LowerRx
        {
            get { return lowerRx; }
            set { if (value == lowerRx) return; lowerRx = value; OnPropertyChanged(nameof(LowerRx)); }
        }
        public double LowerRy
        {
            get { return lowerRy; }
            set { if (value == lowerRy) return; lowerRy = value; OnPropertyChanged(nameof(LowerRy)); }
        }

        public double Lower
        {
            get { return lower; }
            set { if (value == lower) return; lower = value; OnPropertyChanged(nameof(Lower)); }
        }
        public double Right
        {
            get { return right; }
            set { if (value == right) return; right = value; OnPropertyChanged(nameof(Right)); }
        }



        public bool Judge_UpperLx
        {
            get { return judge_UpperLx; }
            set { if (value == judge_UpperLx) return; judge_UpperLx = value; OnPropertyChanged(nameof(Judge_UpperLx)); }
        }
        public bool Judge_UpperLy
        {
            get { return judge_UpperLy; }
            set { if (value == judge_UpperLy) return; judge_UpperLy = value; OnPropertyChanged(nameof(Judge_UpperLy)); }
        }
        public bool Judge_LowerLx
        {
            get { return judge_LowerLx; }
            set { if (value == judge_LowerLx) return; judge_LowerLx = value; OnPropertyChanged(nameof(Judge_LowerLx)); }
        }
        public bool Judge_LowerLy
        {
            get { return judge_LowerLy; }
            set { if (value == judge_LowerLy) return; judge_LowerLy = value; OnPropertyChanged(nameof(Judge_LowerLy)); }
        }
        public bool Judge_LowerRx
        {
            get { return judge_LowerRx; }
            set { if (value == judge_LowerRx) return; judge_LowerRx = value; OnPropertyChanged(nameof(Judge_LowerRx)); }
        }
        public bool Judge_LowerRy
        {
            get { return judge_LowerRy; }
            set { if (value == judge_LowerRy) return; judge_LowerRy = value; OnPropertyChanged(nameof(Judge_LowerRy)); }
        }
        public bool Judge_Upper
        {
            get { return judge_Upper; }
            set { if (value == judge_Upper) return; judge_Upper = value; OnPropertyChanged(nameof(Judge_Upper)); }
        }
        public bool Judge_Right
        {
            get { return judge_Right; }
            set { if (value == judge_Right) return; judge_Right = value; OnPropertyChanged(nameof(Judge_Right)); }
        }

        public double Oca_1st_Lx
        {
            get { return oca_1st_Lx; }
            set { if (value == oca_1st_Lx) return; oca_1st_Lx = value; OnPropertyChanged(nameof(Oca_1st_Lx)); }
        }
        public double Oca_1st_Ly
        {
            get { return oca_1st_Ly; }
            set { if (value == oca_1st_Ly) return; oca_1st_Ly = value; OnPropertyChanged(nameof(Oca_1st_Ly)); }
        }
        public double Oca_2st_Lx
        {
            get { return oca_2st_Lx; }
            set { if (value == oca_2st_Lx) return; oca_2st_Lx = value; OnPropertyChanged(nameof(Oca_2st_Lx)); }
        }
        public double Oca_2st_Ly
        {
            get { return oca_2st_Ly; }
            set { if (value == oca_2st_Ly) return; oca_2st_Ly = value; OnPropertyChanged(nameof(Oca_2st_Ly)); }
        }
        public double Oca_2st_Rx
        {
            get { return oca_2st_Rx; }
            set { if (value == oca_2st_Rx) return; oca_2st_Rx = value; OnPropertyChanged(nameof(Oca_2st_Rx)); }
        }
        public double Oca_2st_Ry
        {
            get { return oca_2st_Ry; }
            set { if (value == oca_2st_Ry) return; oca_2st_Ry = value; OnPropertyChanged(nameof(Oca_2st_Ry)); }
        }

        public double Pnl_1st_Lx
        {
            get { return pnl_1st_Lx; }
            set { if (value == pnl_1st_Lx) return; pnl_1st_Lx = value; OnPropertyChanged(nameof(Pnl_1st_Lx)); }
        }
        public double Pnl_1st_Ly
        {
            get { return pnl_1st_Ly; }
            set { if (value == pnl_1st_Ly) return; pnl_1st_Ly = value; OnPropertyChanged(nameof(Pnl_1st_Ly)); }
        }
        public double Pnl_2st_Lx
        {
            get { return pnl_2st_Lx; }
            set { if (value == pnl_2st_Lx) return; pnl_2st_Lx = value; OnPropertyChanged(nameof(Pnl_2st_Lx)); }
        }
        public double Pnl_2st_Ly
        {
            get { return pnl_2st_Ly; }
            set { if (value == pnl_2st_Ly) return; pnl_2st_Ly = value; OnPropertyChanged(nameof(Pnl_2st_Ly)); }
        }
        public double Pnl_2st_Rx
        {
            get { return pnl_2st_Rx; }
            set { if (value == pnl_2st_Rx) return; pnl_2st_Rx = value; OnPropertyChanged(nameof(Pnl_2st_Rx)); }
        }
        public double Pnl_2st_Ry
        {
            get { return pnl_2st_Ry; }
            set { if (value == pnl_2st_Ry) return; pnl_2st_Ry = value; OnPropertyChanged(nameof(Pnl_2st_Ry)); }
        }

        #endregion


        public Algo90SubLamiInspectResult() : base() {}


        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1}\n,curTime: {2}\n, " +
                                  "U_Lx: {3}\n,U_Ly: {4}\n,L_Lx: {5}\n,L_Ly: {6}\n,L_Rx: {7}\n,L_Ry: {8}\n" +
                                  "RevX: {9}\n,RevY: {10}\n,RevT: {11}\n"
                                  , typeof(Algo90SubLamiAlignResult).ToString(), curTime, curDate
                                  ,UpperLx, UpperLy, LowerLx, LowerLy, LowerRx, LowerRy
                                  , RevX, RevY, RevT
                                  );
        }
    }
}
