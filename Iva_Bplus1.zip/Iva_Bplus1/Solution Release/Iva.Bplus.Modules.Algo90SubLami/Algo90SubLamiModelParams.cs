﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]

    public partial class Algo90SubLamiModelParams : AlgoParams
    {
        public AlgoParam LimitX { get; set; }
        public AlgoParam LimitY { get; set; }
        public AlgoParam LimitT { get; set; }
        

        public Algo90SubLamiModelParams()
        {
            LimitX = new AlgoParam("LimitX", typeof(double), 0.0, "Revision Offset Limit X", 0, (double)5.0);
            LimitY = new AlgoParam("LimitY", typeof(double), 0.0, "Revision Offset Limit Y", 0, (double)5.0);
            LimitT = new AlgoParam("LimitT", typeof(double), 0.0, "Revision Offset Limit T", 0, (double)5.0);
        }
    }
}
