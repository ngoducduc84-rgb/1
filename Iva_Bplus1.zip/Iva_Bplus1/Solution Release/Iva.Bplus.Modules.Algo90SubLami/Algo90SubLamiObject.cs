﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Interface;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]
    public partial class Algo90SubLamiObject : AlgoObjectBase
    {
        #region [Fields]
        #region  Selected Caldata Name
        private string pnl_1st_L_CalData;
        private string pnl_2st_L_CalData;
        private string pnl_2st_R_CalData;
        #endregion

        #region Seleced Caldata Object
        [NonSerialized]
        private CalDataObject pnl_1st_L_CalDataObj;
        [NonSerialized]
        private CalDataObject pnl_2st_L_CalDataObj;
        [NonSerialized]
        private CalDataObject pnl_2st_R_CalDataObj;
        #endregion

        #region Inspection Calc Fields
        [NonSerialized]
        private XYT CurPos_OCA_1st;
        [NonSerialized]
        private XYT CurPos_OCA_2st;
        [NonSerialized]
        private XYT CurPos_PNL_1st;
        [NonSerialized]
        private XYT CurPos_PNL_2st;
        [NonSerialized]
        private XYT UpperGap;
        [NonSerialized]
        private XYT LowerGap;

        #endregion

        #region etc
        private CalcType calcType;
        [field: NonSerialized]
        private bool pnl34_judge;
        [field: NonSerialized]
        private bool pnl14_judge;
        [field: NonSerialized]
        private bool oca34_judge;
        [field: NonSerialized]
        private bool oca14_judge;
        [field: NonSerialized]
        private double pnl34_rst;
        [field: NonSerialized]
        private double pnl14_rst;
        [field: NonSerialized]
        private double oca34_rst;
        [field: NonSerialized]
        private double oca14_rst;
        #endregion
        #endregion

        #region [properties]
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Pnl_1st_L_CalData
        {
            get { return pnl_1st_L_CalData; }
            set
            {
                //if (pnl_1st_L_CalData == value) return; 
                pnl_1st_L_CalData = value;
                pnl_1st_L_CalDataObj = SystemObject_Common.GetObject(pnl_1st_L_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Pnl_1st_L_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Pnl_2st_L_CalData
        {
            get { return pnl_2st_L_CalData; }
            set
            {
                //if (pnl_2st_L_CalData == value) return; 
                pnl_2st_L_CalData = value;
                pnl_2st_L_CalDataObj = SystemObject_Common.GetObject(pnl_2st_L_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Pnl_2st_L_CalData));
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Pnl_2st_R_CalData
        {
            get { return pnl_2st_R_CalData; }
            set
            {
                //if (pnl_2st_R_CalData == value) return; 
                pnl_2st_R_CalData = value;
                pnl_2st_R_CalDataObj = SystemObject_Common.GetObject(pnl_2st_R_CalData) as CalDataObject;
                this.OnPropertyChanged(nameof(Pnl_2st_R_CalData));
            }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set
            {
                if (calcType == value) return;
                calcType = value;
                ModelParams.Clear();

                switch (calcType)
                {
                    
                    case CalcType.Align:
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                                ModelParams.Add(model, new Algo90SubLamiAlignModelParams());

                        }
                        break;
                    case CalcType.Inspection:
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                                ModelParams.Add(model, new Algo90SubLamiInspectModelParams());
                        }
                        break;

                }
                CurParams = ModelParams[SystemModel.GetCurModel()];

                this.OnPropertyChanged(nameof(CalcType));
            }
        }

        public ObservableCollection<string> CalDataList
        {
            get
            {

                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }

        }

        public bool Pnl34_judge
        {
            get { return pnl34_judge; }
            set { if (pnl34_judge == value) return; pnl34_judge = value; this.OnPropertyChanged(nameof(Pnl34_judge)); }
        }
        public bool Pnl14_judge
        {
            get { return pnl14_judge; }
            set { if (pnl14_judge == value) return; pnl14_judge = value; this.OnPropertyChanged(nameof(Pnl14_judge)); }
        }
        public bool Oca34_judge
        {
            get { return oca34_judge; }
            set { if (oca34_judge == value) return; oca34_judge = value; this.OnPropertyChanged(nameof(Oca34_judge)); }
        }
        public bool Oca14_judge
        {
            get { return oca14_judge; }
            set { if (oca14_judge == value) return; oca14_judge = value; this.OnPropertyChanged(nameof(Oca14_judge)); }
        }
        public double Pnl34_rst
        {
            get { return pnl34_rst; }
            set { if (pnl34_rst == value) return; pnl34_rst = value; this.OnPropertyChanged(nameof(Pnl34_rst)); }
        }
        public double Pnl14_rst
        {
            get { return pnl14_rst; }
            set { if (pnl14_rst == value) return; pnl14_rst = value; this.OnPropertyChanged(nameof(Pnl14_rst)); }
        }
        public double Oca34_rst
        {
            get { return oca34_rst; }
            set { if (oca34_rst == value) return; oca34_rst = value; this.OnPropertyChanged(nameof(Oca34_rst)); }
        }
        public double Oca14_rst
        {
            get { return oca14_rst; }
            set { if (oca14_rst == value) return; oca14_rst = value; this.OnPropertyChanged(nameof(Oca14_rst)); }
        }
        #endregion
        #endregion

        #region[Construct]
        public Algo90SubLamiObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo90SubLamiAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            #region PLC IOs Update
            UpdatePLCIOs();

            #endregion

            if (CalcType == CalcType.Inspection) return InspectCalc();
            else return AlignCalc();
        }

        public bool Run(bool bUnloadWrite)
        {
            #region PLC IOs Update
            UpdatePLCIOs();
            #endregion

            bool isSkip = false;
            if (PlcValues.ContainsKey("SkipMode"))
            {
                isSkip = (bool)PlcValues["SkipMode"].CurValue;
                bUnloadWrite = isSkip;
            }

      

            if (CalcType == CalcType.Inspection) return InspectCalc();
            else return AlignCalc(bUnloadWrite);
        }
        public override void ObjectInitialize()
        {
            base.ObjectInitialize();

            Pnl_1st_L_CalData = pnl_1st_L_CalData;
            Pnl_2st_L_CalData = pnl_2st_L_CalData;
            Pnl_2st_R_CalData = pnl_2st_R_CalData;
        }

        public override void DefaultIOSet()
        {
            base.DefaultIOSet();

            Pnl_1st_L_CalData = pnl_1st_L_CalData;
            Pnl_2st_L_CalData = pnl_2st_L_CalData;
            Pnl_2st_R_CalData = pnl_2st_R_CalData;
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion

        #region [Private Method]
        private bool CheckManualMark(IPointResult rst)
        {
            if (rst == null) return false;

            if (rst.SuccessIndex == -1)
            {
                //if (CalcType == CalcType.Align)
                {
                    rst.Tool.ProcMode = ProcessMode.Manual;
                    rst.DisplayObj.Judgement = (uint)Judgement.OpCall;
                    (rst.Tool.ModObject as ToolObjectBase).DispayMessage("OpCall", System.Drawing.Color.Red);
                }
                return false;
            }

            return true;
        }

        private bool AlignCalc(bool useUnloadWrite = false)
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            //string cellID;
            //if (plcValues.ContainsKey("CellID"))
            //{
            //    sourceID = (string)plcValues["CellID"].CurValue;
            //}
            //else
            //{
            //    cellID = GetMakeID(10);
            //}

            //errorCode = Algo90SubLamiAction.Err_Limit_Over;
            //return false;

            //#region PLC IOs Update
            //UpdatePLCIOs();
            //#endregion

            #region Mark Data Read& Confirm
            var x = (double)PlcValues["CurrentPosX"].CurValue;
            var y = (double)PlcValues["CurrentPosY"].CurValue;
            var t = (double)PlcValues["CurrentPosT"].CurValue;
            var curPos = new XYT(x, y, t);

            x = (double)PlcValues["OffsetX"].CurValue;
            y = (double)PlcValues["OffsetY"].CurValue;
            t = (double)PlcValues["OffsetT"].CurValue;
            var offset = new XYT(x, y, t);

            x = (double)PlcValues["UnloadPosX"].CurValue;
            y = (double)PlcValues["UnloadPosY"].CurValue;
            t = (double)PlcValues["UnloadPosT"].CurValue;
            var unloadPos = new XYT(x, y, t);
            #endregion

            #region Mark Data Read& Confirm
            // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
            MatchingRstData OCA_1st_L;
            MatchingRstData OCA_1st_R;
            MatchingRstData OCA_2st_L;
            MatchingRstData PNL_1st_L;
            MatchingRstData PNL_2st_L;
            MatchingRstData PNL_2st_R;

            if (useUnloadWrite)
            {
                if (!InputValues.ContainsKey("PNL_1st_L") || !InputValues.ContainsKey("PNL_2st_L") || !InputValues.ContainsKey("PNL_2st_R"))
                {
                    SetZeroAlignResult(useUnloadWrite);
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                OCA_1st_L = new MatchingRstData();
                OCA_1st_R = new MatchingRstData();
                OCA_2st_L = new MatchingRstData();
                PNL_1st_L = InputValues["PNL_1st_L"] as MatchingRstData;
                PNL_2st_L = InputValues["PNL_2st_L"] as MatchingRstData;
                PNL_2st_R = InputValues["PNL_2st_R"] as MatchingRstData;

                bool bPNL_1st_L = CheckManualMark(PNL_1st_L);
                bool bPNL_2st_L = CheckManualMark(PNL_2st_L);
                bool bPNL_2st_R = CheckManualMark(PNL_2st_R);
                if (!bPNL_1st_L || !bPNL_2st_L || !bPNL_2st_R)
                {
                    // Mark Data가 Null임
                    SetZeroAlignResult(useUnloadWrite);
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
            }
            else
            {
                if (!InputValues.ContainsKey("OCA_1st_L") || !InputValues.ContainsKey("OCA_1st_R") || !InputValues.ContainsKey("OCA_2st_L") ||
                    !InputValues.ContainsKey("PNL_1st_L") || !InputValues.ContainsKey("PNL_2st_L") || !InputValues.ContainsKey("PNL_2st_R"))
                {
                    SetZeroAlignResult(useUnloadWrite);
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                OCA_1st_L = InputValues["OCA_1st_L"] as MatchingRstData;
                OCA_1st_R = InputValues["OCA_1st_R"] as MatchingRstData;
                OCA_2st_L = InputValues["OCA_2st_L"] as MatchingRstData;
                PNL_1st_L = InputValues["PNL_1st_L"] as MatchingRstData;
                PNL_2st_L = InputValues["PNL_2st_L"] as MatchingRstData;
                PNL_2st_R = InputValues["PNL_2st_R"] as MatchingRstData;

                bool bOCA_1st_L = CheckManualMark(OCA_1st_L);
                bool bOCA_1st_R = CheckManualMark(OCA_1st_R);
                bool bOCA_2st_L = CheckManualMark(OCA_2st_L);
                bool bPNL_1st_L = CheckManualMark(PNL_1st_L);
                bool bPNL_2st_L = CheckManualMark(PNL_2st_L);
                bool bPNL_2st_R = CheckManualMark(PNL_2st_R);
                if (!bPNL_1st_L || !bPNL_2st_L || !bPNL_2st_R || !bOCA_1st_L || !bOCA_1st_R || !bOCA_2st_L)
                {
                    // Mark Data가 Null임
                    SetZeroAlignResult(useUnloadWrite);
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
            }

            if (OCA_1st_L.SuccessIndex == -1)
            {
                OCA_1st_L.Tool.ProcMode = ProcessMode.Manual;
                OCA_1st_L.DisplayObj.Judgement = (uint)Judgement.OpCall;
                (OCA_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("OpCall", System.Drawing.Color.Red);
            }

            #endregion

            #region Coordnate Pos Calc & CalData Cofirm
            if (pnl_1st_L_CalDataObj == null || pnl_2st_L_CalDataObj == null || pnl_2st_R_CalDataObj == null)
            {
                SetZeroAlignResult(useUnloadWrite);
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                // Calibration 설정 안됨.
                return false;
            }
            var rPNL_1st_L = pnl_1st_L_CalDataObj.GetV2R(model, new XY(PNL_1st_L.OutputXYT.X, PNL_1st_L.OutputXYT.Y));
            var rPNL_2st_L = pnl_2st_L_CalDataObj.GetV2R(model, new XY(PNL_2st_L.OutputXYT.X, PNL_2st_L.OutputXYT.Y));
            var rPNL_2st_R = pnl_2st_R_CalDataObj.GetV2R(model, new XY(PNL_2st_R.OutputXYT.X, PNL_2st_R.OutputXYT.Y));

            var rOCA_1st_L = pnl_2st_L_CalDataObj.GetV2R(model, new XY(OCA_1st_L.OutputXYT.X, OCA_1st_L.OutputXYT.Y)) * new XY(1, -1);
            var rOCA_1st_R = pnl_2st_R_CalDataObj.GetV2R(model, new XY(OCA_1st_R.OutputXYT.X, OCA_1st_R.OutputXYT.Y)) * new XY(1, -1);
            var rOCA_2st_L = pnl_1st_L_CalDataObj.GetV2R(model, new XY(OCA_2st_L.OutputXYT.X, OCA_2st_L.OutputXYT.Y)) * new XY(1, -1);

            var rCAM_1st_L = new XY(0, 0);
            var rCAM_2st_L = new XY(0, 0);
            var rCAM_2st_R = new XY(0, 0);
       
            var cPNL_1st_L = rPNL_1st_L + pnl_1st_L_CalDataObj.GetRotateCenter(model);
            var cPNL_2st_L = rPNL_2st_L + pnl_2st_L_CalDataObj.GetRotateCenter(model);
            var cPNL_2st_R = rPNL_2st_R + pnl_2st_R_CalDataObj.GetRotateCenter(model);

            var cOCA_1st_L = rOCA_1st_L + pnl_2st_L_CalDataObj.GetRotateCenter(model);
            var cOCA_1st_R = rOCA_1st_R + pnl_2st_R_CalDataObj.GetRotateCenter(model);
            var cOCA_2st_L = rOCA_2st_L + pnl_1st_L_CalDataObj.GetRotateCenter(model);

            var cCAM_1st_L = rCAM_1st_L + pnl_1st_L_CalDataObj.GetRotateCenter(model);
            var cCAM_2st_L = rCAM_2st_L + pnl_2st_L_CalDataObj.GetRotateCenter(model);
            var cCAM_2st_R = rCAM_2st_R + pnl_2st_R_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams))
            { SetZeroAlignResult(useUnloadWrite); return false; }
            var mParams = modelParams as Algo90SubLamiAlignModelParams;
            if (mParams.LimitX == null)
                mParams.LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)+5.0);
            if (mParams.LimitY == null)
                mParams.LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)+5.0);
            if (mParams.LimitT == null)
                mParams.LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)+5.0);

            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;

            var pnl34_spec = (double)mParams.Pnl34.Value;
            var pnl14_spec = (double)mParams.Pnl14.Value;
            var oca34_spec = (double)mParams.Oca34.Value;
            var oca14_spec = (double)mParams.Oca14.Value;

            var pnl34_tor = (double)mParams.Pnl34_tor.Value;
            var pnl14_tor = (double)mParams.Pnl14_tor.Value;
            var oca34_tor = (double)mParams.Oca34_tor.Value;
            var oca14_tor = (double)mParams.Oca14_tor.Value;

            #endregion

            #region Calc Rev Offset

            // 단변
            double ocaT = GetThetaColumn(cOCA_1st_L.X, cOCA_1st_R.X, rOCA_1st_L.Y, rOCA_1st_R.Y); // 
            double camT = GetThetaColumn(cCAM_2st_L.X, cCAM_2st_R.X, rCAM_2st_L.Y, rCAM_2st_R.Y); //
            double pnlT = GetThetaColumn(cPNL_2st_L.X, cPNL_2st_R.X, rPNL_2st_L.Y, rPNL_2st_R.Y); //
            ocaT -= camT;
            pnlT -= camT;
            camT = 0;

            var ocaTar = (cOCA_2st_L + cOCA_1st_R) / 2;    // 대각선 두개 포인트만 쓰고 있음.
            var camTar = (cCAM_1st_L + cCAM_2st_R) / 2;    // 
            var pnlObj = (cPNL_1st_L + cPNL_2st_R) / 2;    //

            var attachOffset = offset;
            var unloadOffset = new XYT(0, 0, 0);    //  Unload Offset은 없다.
            var ocaTarxyt = new XYT(ocaTar.X, ocaTar.Y, ocaT);
            var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
            var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);

            // Attach 위치 보정값 계산.
            var revAttach = new XYT();
            ocaTarxyt = ApplyTargetOffset(ocaTarxyt, attachOffset);

            double radT = NormalizeTheta(ocaTarxyt.T - pnlObjxyt.T);

            double DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
            double DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
            revAttach.X = ocaTarxyt.X - DriftX;
            revAttach.Y = ocaTarxyt.Y - DriftY;
            revAttach.T = radT / rad;   // 부호 확인 필요.

            // Unload 위치 보정값 계산
            var revUnload = new XYT();
            camTarxyt = ApplyTargetOffset(camTarxyt, unloadOffset);

            radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
            DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
            DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
            revUnload.X = camTarxyt.X - DriftX;
            revUnload.Y = camTarxyt.Y - DriftY;
            revUnload.T = radT / rad;   // 부호 확인 필요.
            #endregion

            #region Calc Length
            var pnl12 = 0.0;// GetLength(cPNL_1st_L, cPNL_1st_R);
            var pnl34 = GetLength(cPNL_1st_L, cPNL_2st_L);
            var pnl13 = GetLength(cPNL_2st_R, cPNL_1st_L);
            var pnl24 = 0.0;// GetLength(cPNL_1st_R, cPNL_2st_R);
            var pnl14 = GetLength(cPNL_2st_R, cPNL_2st_L);
            var pnl23 = 0.0;// GetLength(cPNL_1st_R, cPNL_2st_L);

            var oca12 = 0.0;
            var oca34 = GetLength(cOCA_2st_L, cOCA_1st_L);
            var oca13 = GetLength(cOCA_1st_R, cOCA_2st_L);
            var oca24 = 0.0;// GetLength(cOCA_1st_R, cOCA_2st_R);
            var oca14 = GetLength(cOCA_1st_R, cOCA_1st_L);
            var oca23 = 0.0;


            Pnl34_rst = pnl34;
            Pnl14_rst = pnl14;
            Oca34_rst = oca13;
            Oca14_rst = oca14;
            Pnl34_judge = ConfirmSpecRange(Pnl34_rst, pnl34_spec, pnl34_tor);
            Pnl14_judge = ConfirmSpecRange(Pnl14_rst, pnl14_spec, pnl14_tor);
            Oca34_judge = ConfirmSpecRange(Oca34_rst, oca34_spec, oca34_tor);
            Oca14_judge = ConfirmSpecRange(Oca14_rst, oca14_spec, oca14_tor);

            if(!Pnl34_judge && !Pnl14_judge)
            {
                PNL_2st_L.Tool.ProcMode = ProcessMode.Manual; (PNL_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                PNL_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
            }
            else
            {
                if (!Pnl34_judge)
                {
                    PNL_1st_L.Tool.ProcMode = ProcessMode.Manual; (PNL_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    PNL_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    PNL_2st_L.Tool.ProcMode = ProcessMode.Manual; (PNL_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    PNL_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                if (!Pnl14_judge)
                {
                    PNL_2st_L.Tool.ProcMode = ProcessMode.Manual; (PNL_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    PNL_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    PNL_2st_R.Tool.ProcMode = ProcessMode.Manual; (PNL_2st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    PNL_2st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }

            if (!Oca34_judge && !Oca14_judge)
            {
                OCA_1st_L.Tool.ProcMode = ProcessMode.Manual; (OCA_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                OCA_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
            }
            else
            {
                if (!Oca34_judge)
                {
                    OCA_1st_L.Tool.ProcMode = ProcessMode.Manual; (OCA_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    OCA_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    OCA_2st_L.Tool.ProcMode = ProcessMode.Manual; (OCA_2st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    OCA_2st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
                if (!Oca14_judge)
                {
                    OCA_1st_L.Tool.ProcMode = ProcessMode.Manual; (OCA_1st_L.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    OCA_1st_L.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    OCA_1st_R.Tool.ProcMode = ProcessMode.Manual; (OCA_1st_R.Tool.ModObject as ToolObjectBase).DispayMessage("L_Check", System.Drawing.Color.Red);
                    OCA_1st_R.DisplayObj.Judgement = (uint)Judgement.L_Check;
                }
            }

            if (!Pnl34_judge || !Pnl14_judge || !Oca34_judge || !Oca14_judge)
            {
                errorCode = Algo90SubLamiAction.Err_Length_Check;
                System.Threading.Thread.Sleep(100);
                return false;
            }

            #endregion

            #region Result Data Update(DataGridView Insert)

            if (useUnloadWrite)
            {
                AlgoRst = new Algo90SubLamiAlignResult
                {
                    Name = name,
                    ID = SourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    AttachRevX = Math.Round(0.0, 3),
                    AttachRevY = Math.Round(0.0, 3),
                    AttachRevT = Math.Round(0.0, 3),

                    UnloadRevX = Math.Round(revUnload.X, 3),
                    UnloadRevY = Math.Round(revUnload.Y, 3),
                    UnloadRevT = Math.Round(revUnload.T, 3),

                    OffsetX = Math.Round(0.0, 3),
                    OffsetY = Math.Round(0.0, 3),
                    OffsetT = Math.Round(0.0, 3),

                    Oca_1st_Lx = Math.Round(0.0, 3),
                    Oca_1st_Ly = Math.Round(0.0, 3),
                    Oca_1st_Rx = Math.Round(0.0, 3),
                    Oca_1st_Ry = Math.Round(0.0, 3),
                    Oca_2st_Lx = Math.Round(0.0, 3),
                    Oca_2st_Ly = Math.Round(0.0, 3),

                    Pnl_1st_Lx = Math.Round(cPNL_1st_L.X, 3),
                    Pnl_1st_Ly = Math.Round(cPNL_1st_L.Y, 3),
                    Pnl_2st_Lx = Math.Round(cPNL_2st_L.X, 3),
                    Pnl_2st_Ly = Math.Round(cPNL_2st_L.Y, 3),
                    Pnl_2st_Rx = Math.Round(cPNL_2st_R.X, 3),
                    Pnl_2st_Ry = Math.Round(cPNL_2st_R.Y, 3),

                    Oca_1st_Lx_px = Math.Round(0.0, 3),
                    Oca_1st_Ly_px = Math.Round(0.0, 3),
                    Oca_1st_Rx_px = Math.Round(0.0, 3),
                    Oca_1st_Ry_px = Math.Round(0.0, 3),
                    Oca_2st_Lx_px = Math.Round(0.0, 3),
                    Oca_2st_Ly_px = Math.Round(0.0, 3),

                    Pnl_1st_Lx_px = Math.Round(PNL_1st_L.OutputXYT.X, 3),
                    Pnl_1st_Ly_px = Math.Round(PNL_1st_L.OutputXYT.Y, 3),
                    Pnl_2st_Lx_px = Math.Round(PNL_2st_L.OutputXYT.X, 3),
                    Pnl_2st_Ly_px = Math.Round(PNL_2st_L.OutputXYT.Y, 3),
                    Pnl_2st_Rx_px = Math.Round(PNL_2st_R.OutputXYT.X, 3),
                    Pnl_2st_Ry_px = Math.Round(PNL_2st_R.OutputXYT.Y, 3),
                };
            }
            else
            {
                AlgoRst = new Algo90SubLamiAlignResult
                {
                    Name = name,
                    ID = SourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    AttachRevX = Math.Round(revAttach.X, 3),
                    AttachRevY = Math.Round(revAttach.Y, 3),
                    AttachRevT = Math.Round(revAttach.T, 3),

                    UnloadRevX = Math.Round(revUnload.X, 3),
                    UnloadRevY = Math.Round(revUnload.Y, 3),
                    UnloadRevT = Math.Round(revUnload.T, 3),

                    OffsetX = Math.Round(attachOffset.X, 3),
                    OffsetY = Math.Round(attachOffset.Y, 3),
                    OffsetT = Math.Round(attachOffset.T, 3),

                    Oca_1st_Lx = Math.Round(cOCA_1st_L.X, 3),
                    Oca_1st_Ly = Math.Round(cOCA_1st_L.Y, 3),
                    Oca_1st_Rx = Math.Round(cOCA_1st_R.X, 3),
                    Oca_1st_Ry = Math.Round(cOCA_1st_R.Y, 3),
                    Oca_2st_Lx = Math.Round(cOCA_2st_L.X, 3),
                    Oca_2st_Ly = Math.Round(cOCA_2st_L.Y, 3),

                    Pnl_1st_Lx = Math.Round(cPNL_1st_L.X, 3),
                    Pnl_1st_Ly = Math.Round(cPNL_1st_L.Y, 3),
                    Pnl_2st_Lx = Math.Round(cPNL_2st_L.X, 3),
                    Pnl_2st_Ly = Math.Round(cPNL_2st_L.Y, 3),
                    Pnl_2st_Rx = Math.Round(cPNL_2st_R.X, 3),
                    Pnl_2st_Ry = Math.Round(cPNL_2st_R.Y, 3),

                    Oca_1st_Lx_px = Math.Round(OCA_1st_L.OutputXYT.X, 3),
                    Oca_1st_Ly_px = Math.Round(OCA_1st_L.OutputXYT.Y, 3),
                    Oca_1st_Rx_px = Math.Round(OCA_1st_L.OutputXYT.X, 3),
                    Oca_1st_Ry_px = Math.Round(OCA_1st_L.OutputXYT.Y, 3),
                    Oca_2st_Lx_px = Math.Round(OCA_2st_L.OutputXYT.X, 3),
                    Oca_2st_Ly_px = Math.Round(OCA_2st_L.OutputXYT.Y, 3),

                    Pnl_1st_Lx_px = Math.Round(PNL_1st_L.OutputXYT.X, 3),
                    Pnl_1st_Ly_px = Math.Round(PNL_1st_L.OutputXYT.Y, 3),
                    Pnl_2st_Lx_px = Math.Round(PNL_2st_L.OutputXYT.X, 3),
                    Pnl_2st_Ly_px = Math.Round(PNL_2st_L.OutputXYT.Y, 3),
                    Pnl_2st_Rx_px = Math.Round(PNL_2st_R.OutputXYT.X, 3),
                    Pnl_2st_Ry_px = Math.Round(PNL_2st_R.OutputXYT.Y, 3),
                };
            }

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Confirm Result
            if (!ConfirmSpecMinMax(revAttach.X, limitX * (-1), limitX) ||
                !ConfirmSpecMinMax(revAttach.Y, limitY * (-1), limitY) ||
                !ConfirmSpecMinMax(revAttach.T, limitT * (-1), limitT))
            {
                errorCode = Algo90SubLamiAction.Err_Limit_Over;
                return false;
            }
            #endregion

            #region Vision Write (Result & FDC)
            // 12는 1st 단변, 34는 2st 단변, 13은 왼쪽 장변, 24는 오른쪽 장변

            var IOs = new List<IOStruct>();
            if (!useUnloadWrite)
            {
                VisionValues["TargetPosX"].NextValue = (double)/*curPos.X + */revAttach.X;                          IOs.Add(VisionValues["TargetPosX"]);
                VisionValues["TargetPosY"].NextValue = (double)/*curPos.Y + */revAttach.Y;                          IOs.Add(VisionValues["TargetPosY"]);
                VisionValues["TargetPosT"].NextValue = (double)/*curPos.T + */revAttach.T;                          IOs.Add(VisionValues["TargetPosT"]);
            }
            else
            {
                VisionValues["TargetPosX"].NextValue = (double)/*curPos.X + */revUnload.X;                          IOs.Add(VisionValues["TargetPosX"]);
                VisionValues["TargetPosY"].NextValue = (double)/*curPos.Y + */revUnload.Y;                          IOs.Add(VisionValues["TargetPosY"]);
                VisionValues["TargetPosT"].NextValue = (double)/*curPos.T + */revUnload.T;                          IOs.Add(VisionValues["TargetPosT"]);
            }

            VisionValues["InspectionX"].NextValue = (double)0.0;                                                    IOs.Add(VisionValues["InspectionX"]);
            VisionValues["InspectionY"].NextValue = (double)0.0;                                                    IOs.Add(VisionValues["InspectionY"]);
            VisionValues["InspectionT"].NextValue = (double)0.0;                                                    IOs.Add(VisionValues["InspectionT"]);
            VisionValues["TargetUnloadPosX"].NextValue = (double)/*unloadPos.X + */revUnload.X;                     IOs.Add(VisionValues["TargetUnloadPosX"]);
            VisionValues["TargetUnloadPosY"].NextValue = (double)/*unloadPos.Y + */revUnload.Y;                     IOs.Add(VisionValues["TargetUnloadPosY"]);
            VisionValues["TargetUnloadPosT"].NextValue = (double)/*unloadPos.T + */revUnload.T;                     IOs.Add(VisionValues["TargetUnloadPosT"]);

            // UnloadWrite 기능을 쓸때는 테스트모드 또는 정상이 아니므로 FDC 보고 하지 않음.
            if (!useUnloadWrite)
            {
                VisionValues["FDC_P0X"].NextValue = (int)Math.Round(PNL_1st_L.OutputXYT.X, 2);                 IOs.Add(VisionValues["FDC_P0X"]);
                VisionValues["FDC_P0Y"].NextValue = (int)Math.Round(PNL_1st_L.OutputXYT.Y, 2) ;                 IOs.Add(VisionValues["FDC_P0Y"]);
                VisionValues["FDC_P0Score"].NextValue = (int)Math.Round(PNL_1st_L.Score , 2) *10;             IOs.Add(VisionValues["FDC_P0Score"]);
                VisionValues["FDC_P1X"].NextValue = (int)0;                                                         IOs.Add(VisionValues["FDC_P1X"]);
                VisionValues["FDC_P1Y"].NextValue = (int)0;                                                         IOs.Add(VisionValues["FDC_P1Y"]);
                VisionValues["FDC_P1Score"].NextValue = (int)100 * 10 ;                                              IOs.Add(VisionValues["FDC_P1Score"]);
                VisionValues["FDC_P2X"].NextValue = (int)Math.Round(PNL_2st_L.OutputXYT.X, 2);                 IOs.Add(VisionValues["FDC_P2X"]);
                VisionValues["FDC_P2Y"].NextValue = (int)Math.Round(PNL_2st_L.OutputXYT.Y, 2);                 IOs.Add(VisionValues["FDC_P2Y"]);
                VisionValues["FDC_P2Score"].NextValue = (int)Math.Round(PNL_2st_L.Score , 2) * 10 ;             IOs.Add(VisionValues["FDC_P2Score"]);
                VisionValues["FDC_P3X"].NextValue = (int)Math.Round(PNL_2st_R.OutputXYT.X, 2) ;                 IOs.Add(VisionValues["FDC_P3X"]);
                VisionValues["FDC_P3Y"].NextValue = (int)Math.Round(PNL_2st_R.OutputXYT.Y, 2) ;                 IOs.Add(VisionValues["FDC_P3Y"]);
                VisionValues["FDC_P3Score"].NextValue = (int)Math.Round(PNL_2st_R.Score, 2) * 10;                   IOs.Add(VisionValues["FDC_P3Score"]);

                VisionValues["FDC_W0X"].NextValue = (int)Math.Round(OCA_1st_L.OutputXYT.X, 2);                 IOs.Add(VisionValues["FDC_W0X"]);
                VisionValues["FDC_W0Y"].NextValue = (int)Math.Round(OCA_1st_L.OutputXYT.Y, 2);                 IOs.Add(VisionValues["FDC_W0Y"]);
                VisionValues["FDC_W0Score"].NextValue = (int)Math.Round(OCA_1st_L.Score, 2) * 10;             IOs.Add(VisionValues["FDC_W0Score"]);
                VisionValues["FDC_W1X"].NextValue = (int)Math.Round(OCA_1st_R.OutputXYT.X, 2);                 IOs.Add(VisionValues["FDC_W1X"]);
                VisionValues["FDC_W1Y"].NextValue = (int)Math.Round(OCA_1st_R.OutputXYT.Y, 2);                 IOs.Add(VisionValues["FDC_W1Y"]);
                VisionValues["FDC_W1Score"].NextValue = (int)Math.Round(OCA_1st_R.Score , 2) * 10;             IOs.Add(VisionValues["FDC_W1Score"]);
                VisionValues["FDC_W2X"].NextValue = (int)Math.Round(OCA_2st_L.OutputXYT.X, 2);                 IOs.Add(VisionValues["FDC_W2X"]);
                VisionValues["FDC_W2Y"].NextValue = (int)Math.Round(OCA_2st_L.OutputXYT.Y, 2);                 IOs.Add(VisionValues["FDC_W2Y"]);
                VisionValues["FDC_W2Score"].NextValue = (int)Math.Round(OCA_2st_L.Score, 2) * 10;             IOs.Add(VisionValues["FDC_W2Score"]);
                VisionValues["FDC_W3X"].NextValue = (int)0;                                                         IOs.Add(VisionValues["FDC_W3X"]);
                VisionValues["FDC_W3Y"].NextValue = (int)0;                                                         IOs.Add(VisionValues["FDC_W3Y"]);
                VisionValues["FDC_W3Score"].NextValue = (int)100 * 10;                                              IOs.Add(VisionValues["FDC_W3Score"]);

                VisionValues["FDC_PitchP12"].NextValue = (double)pnl12;                                             IOs.Add(VisionValues["FDC_PitchP12"]);
                VisionValues["FDC_PitchP34"].NextValue = (double)pnl34;                                             IOs.Add(VisionValues["FDC_PitchP34"]);
                VisionValues["FDC_PitchP13"].NextValue = (double)pnl13;                                             IOs.Add(VisionValues["FDC_PitchP13"]);
                VisionValues["FDC_PitchP14"].NextValue = (double)pnl14;                                             IOs.Add(VisionValues["FDC_PitchP14"]);
                VisionValues["FDC_PitchW12"].NextValue = (double)oca12;                                             IOs.Add(VisionValues["FDC_PitchW12"]);
                VisionValues["FDC_PitchW34"].NextValue = (double)oca34;                                             IOs.Add(VisionValues["FDC_PitchW34"]);
                VisionValues["FDC_PitchW13"].NextValue = (double)oca13;                                             IOs.Add(VisionValues["FDC_PitchW13"]);
                VisionValues["FDC_PitchW14"].NextValue = (double)oca23;                                             IOs.Add(VisionValues["FDC_PitchW14"]); // 확인 필요..14가 아니고 맵상은 24로 되어있음..2,3이되어야 할것같긴한데...?

                VisionValues["FDC_TargetPosX"].NextValue = (double)/*curPos.X*/ + revAttach.X;                          IOs.Add(VisionValues["FDC_TargetPosX"]);
                VisionValues["FDC_TargetPosY"].NextValue = (double)/*curPos.Y*/ + revAttach.Y;                          IOs.Add(VisionValues["FDC_TargetPosY"]);
                VisionValues["FDC_TargetPosT"].NextValue = (double)/*curPos.T*/ + revAttach.T;                          IOs.Add(VisionValues["FDC_TargetPosT"]);
                VisionValues["FDC_ResultRevX"].NextValue = (double)revAttach.X;                                     IOs.Add(VisionValues["FDC_ResultRevX"]);
                VisionValues["FDC_ResultRevY"].NextValue = (double)revAttach.Y;                                     IOs.Add(VisionValues["FDC_ResultRevY"]);
                VisionValues["FDC_ResultRevT"].NextValue = (double)revAttach.T;                                     IOs.Add(VisionValues["FDC_ResultRevT"]);
            }

            CommodObject.SetVisionValues(IOs);
            #endregion
            return true;
        }

        public bool InspectCalc(bool isRecalc = false)
        {

            // Upper(1st)Left (3번)
            // Lower(2st)Right (1번)
            // Lower(2st)Left (4번)
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            //string cellID;
            //if (plcValues.ContainsKey("CellID"))
            //{
            //    sourceID = (string)plcValues["CellID"].CurValue;
            //}
            //else
            //{
            //    cellID = GetMakeID(10);
            //}
            //#region PLC IOs Update
            //UpdatePLCIOs();
            //#endregion

            #region Mark Data Read& Confirm
            var OCA_1st_L = InputValues["OCA_1st_L"] as MatchingRstData;
            var OCA_2st_L = InputValues["OCA_2st_L"] as MatchingRstData;
            var OCA_2st_R = InputValues["OCA_2st_R"] as MatchingRstData;
            var PNL_1st_L = InputValues["PNL_1st_L"] as MatchingRstData;
            var PNL_2st_L = InputValues["PNL_2st_L"] as MatchingRstData;
            var PNL_2st_R = InputValues["PNL_2st_R"] as MatchingRstData;

            bool bOCA_1st_L = isRecalc ? true : CheckManualMark(OCA_1st_L);
            bool bOCA_2st_L = isRecalc ? true : CheckManualMark(OCA_2st_L);
            bool bOCA_2st_R = isRecalc ? true : CheckManualMark(OCA_2st_R);
            bool bPNL_1st_L = isRecalc ? true : CheckManualMark(PNL_1st_L);
            bool bPNL_2st_L = isRecalc ? true : CheckManualMark(PNL_2st_L);
            bool bPNL_2st_R = isRecalc ? true : CheckManualMark(PNL_2st_R);
            if (!bPNL_1st_L || !bPNL_2st_L || !bPNL_2st_R || !bOCA_1st_L || !bOCA_2st_L || !bOCA_2st_R)
            {
                SetZeroInspectResult();
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            //if (OCA_1st_L == null || OCA_2st_L == null || OCA_2st_R == null ||
            //    PNL_1st_L == null || PNL_2st_L == null || PNL_2st_R == null)
            //{
            //    // Mark Data가 Null임
            //    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
            //    return false;
            //}
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams))
            { SetZeroInspectResult(); return false; }
            if (!ModelParams.TryGetValue(model, out modelParams))
            { SetZeroInspectResult(); return false; }

            var mParams = modelParams as Algo90SubLamiInspectModelParams;
            var Spec_Upper_L = new XY((double)mParams.Spec_UpperLx.Value, (double)mParams.Spec_UpperLy.Value);
            var Spec_Lower_L = new XY((double)mParams.Spec_LowerLx.Value, (double)mParams.Spec_LowerLy.Value);
            var Spec_Lower_R = new XY((double)mParams.Spec_LowerRx.Value, (double)mParams.Spec_LowerRy.Value);

            var Scale_Upper_L = new XY((double)mParams.Scale_UpperLx.Value, (double)mParams.Scale_UpperLy.Value);
            var Scale_Lower_L = new XY((double)mParams.Scale_LowerLx.Value, (double)mParams.Scale_LowerLy.Value);
            var Scale_Lower_R = new XY((double)mParams.Scale_LowerRx.Value, (double)mParams.Scale_LowerRy.Value);

            var Judge_Upper_Center = (double)mParams.Judge_Upper_Center.Value;
            var Judge_Right_Center = (double)mParams.Judge_Right_Center.Value;

            var Judge_Upper_Range = (double)mParams.Judge_Upper_Range.Value;
            var Judge_Right_Range = (double)mParams.Judge_Right_Range.Value;
            #endregion

            #region Coordnate Pos Calc & CalData Cofirm
            if (pnl_1st_L_CalDataObj == null || pnl_2st_L_CalDataObj == null || pnl_2st_R_CalDataObj == null)
            {
                SetZeroInspectResult();
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                // Calibration 설정 안됨.
                return false;
            }

            CalcGap();

            var rPNL_1st_L = pnl_1st_L_CalDataObj.GetV2R(model, new XY(PNL_1st_L.OutputXYT.X, PNL_1st_L.OutputXYT.Y));
            var rPNL_2st_L = pnl_2st_L_CalDataObj.GetV2R(model, new XY(PNL_2st_L.OutputXYT.X, PNL_2st_L.OutputXYT.Y));
            var rPNL_2st_R = pnl_2st_R_CalDataObj.GetV2R(model, new XY(PNL_2st_R.OutputXYT.X, PNL_2st_R.OutputXYT.Y));

            var rOCA_1st_L = pnl_1st_L_CalDataObj.GetV2R(model, new XY(OCA_1st_L.OutputXYT.X, OCA_1st_L.OutputXYT.Y));
            var rOCA_2st_L = pnl_2st_L_CalDataObj.GetV2R(model, new XY(OCA_2st_L.OutputXYT.X, OCA_2st_L.OutputXYT.Y));
            var rOCA_2st_R = pnl_2st_R_CalDataObj.GetV2R(model, new XY(OCA_2st_R.OutputXYT.X, OCA_2st_R.OutputXYT.Y));

            string msg = string.Format("{0:f4},{1:f4},{2:f4},{3:f4},{4:f4},{5:f4}", PNL_1st_L.OutputXYT.X, PNL_1st_L.OutputXYT.Y, PNL_2st_L.OutputXYT.X, PNL_2st_L.OutputXYT.Y, PNL_2st_R.OutputXYT.X, PNL_2st_R.OutputXYT.Y);
            SystemLogger.WriteDebuggingLog(msg);
            msg = string.Format("{0:f4},{1:f4},{2:f4},{3:f4},{4:f4},{5:f4}", OCA_1st_L.OutputXYT.X, OCA_1st_L.OutputXYT.Y, OCA_2st_L.OutputXYT.X, OCA_2st_L.OutputXYT.Y, OCA_2st_R.OutputXYT.X, OCA_2st_R.OutputXYT.Y);
            SystemLogger.WriteDebuggingLog(msg);

            var fixPNL_1st_L = pnl_1st_L_CalDataObj.GetRotateCenter(model);
            var fixPNL_2st_L = pnl_2st_L_CalDataObj.GetRotateCenter(model);
            var fixPNL_2st_R = pnl_2st_R_CalDataObj.GetRotateCenter(model);

            fixPNL_1st_L = new XY(fixPNL_2st_L.X, fixPNL_1st_L.Y);
            fixPNL_2st_L = new XY(fixPNL_2st_L.X, fixPNL_2st_L.Y);
            fixPNL_2st_R = new XY(fixPNL_2st_R.X, fixPNL_2st_L.Y);

            var cPNL_1st_L = rPNL_1st_L +/* pnl_1st_L_CalDataObj.GetRotateCenter(model)*/fixPNL_1st_L;
            var cPNL_2st_L = rPNL_2st_L + /*pnl_2st_L_CalDataObj.GetRotateCenter(model)*/fixPNL_2st_L;
            var cPNL_2st_R = rPNL_2st_R + /*pnl_2st_R_CalDataObj.GetRotateCenter(model)*/fixPNL_2st_R;

            var cOCA_1st_L = rOCA_1st_L + /*pnl_1st_L_CalDataObj.GetRotateCenter(model)*/fixPNL_1st_L + UpperGap.ToXY();
            var cOCA_2st_L = rOCA_2st_L + /*pnl_2st_L_CalDataObj.GetRotateCenter(model)*/fixPNL_2st_L - LowerGap.ToXY();
            var cOCA_2st_R = rOCA_2st_R + /*pnl_2st_R_CalDataObj.GetRotateCenter(model)*/fixPNL_2st_R - LowerGap.ToXY();

            var rCAM_1st_L = new XY(0, 0);
            var rCAM_2st_L = new XY(0, 0);
            var rCAM_2st_R = new XY(0, 0);

            var cCAM_1st_L = rCAM_1st_L + /*pnl_1st_L_CalDataObj.GetRotateCenter(model)*/fixPNL_1st_L;
            var cCAM_2st_L = rCAM_2st_L + /*pnl_2st_L_CalDataObj.GetRotateCenter(model)*/fixPNL_2st_L;
            var cCAM_2st_R = rCAM_2st_R + /*pnl_2st_R_CalDataObj.GetRotateCenter(model)*/fixPNL_2st_R;

            var adjOCA_1st_L = cOCA_1st_L - cPNL_1st_L;
            var adjOCA_2st_L = cOCA_2st_L - cPNL_2st_L;
            var adjOCA_2st_R = cOCA_2st_R - cPNL_2st_R;

            adjOCA_1st_L /= Scale_Upper_L;
            adjOCA_2st_L /= Scale_Lower_L;
            adjOCA_2st_R /= Scale_Lower_R;

            double ocaT = GetThetaColumn(cOCA_2st_L.X, cOCA_2st_R.X, rOCA_2st_L.Y, rOCA_2st_R.Y); // 
            double camT = GetThetaColumn(cCAM_2st_L.X, cCAM_2st_R.X, rCAM_2st_L.Y, rCAM_2st_R.Y); //
            double pnlT = GetThetaColumn(cPNL_2st_L.X, cPNL_2st_R.X, rPNL_2st_L.Y, rPNL_2st_R.Y); //

            adjOCA_1st_L += cPNL_1st_L;
            adjOCA_2st_L += cPNL_2st_L;
            adjOCA_2st_R += cPNL_2st_R;
            #endregion

            #region Calc Align


            var x = (double)PlcValues["OffsetX"].CurValue;
            var y = (double)PlcValues["OffsetY"].CurValue;
            var t = (double)PlcValues["OffsetT"].CurValue;
            var offset = new XYT(x, y, t);

            //double ocaT = GetThetaColumn(adjOCA_2st_L.X, adjOCA_2st_R.X, adjOCA_2st_L.Y, adjOCA_2st_R.Y); // 
            //double camT = GetThetaColumn(cCAM_2st_L.X, cCAM_2st_R.X, rCAM_2st_L.Y, rCAM_2st_R.Y); //
            //double pnlT = GetThetaColumn(cPNL_2st_L.X, cPNL_2st_R.X, rPNL_2st_L.Y, rPNL_2st_R.Y); //

            var ocaDeg = ocaT / rad;
            var pnlTDeg = pnlT / rad;
            var camTDeg = camT / rad;


            ocaT -= camT;
            pnlT -= camT;
            camT = 0;

            var ocaTar = (adjOCA_1st_L + adjOCA_2st_R) / 2;    // 대각선 두개 포인트만 쓰고 있음.
            var camTar = (cCAM_1st_L + cCAM_2st_R) / 2;    // 
            var pnlObj = (cPNL_1st_L + cPNL_2st_R) / 2;    //
            var pnlUld = (cPNL_1st_L + cPNL_2st_R) / 2;    //


            //var attachOffset = offset;
            //var attachOffset = new XYT(0, 0, 0);    //  최종합친 잔여보정량이 아닌 현재 기준 보정량이란다....보정되어야할 양인지 틀어진 양인지(부호반대) 설비에서 확인 필요하다.
            // Spec_Upper_L 위치는 다 + 위치임. 예를 들어 Y가 Spec이 13.4(upper), 13(lower)라면 (13.4 - 13) / 2 = + 중심에서 0.2의 위치에 붙여야한다.
            var sub = (Spec_Lower_R - Spec_Upper_L);
            var attachOffset = sub.ToXYT();         // 
            var unloadOffset = new XYT(0, 0, 0);    //  Unload Offset은 없다.
            var ocaTarxyt = new XYT(ocaTar.X, ocaTar.Y, ocaT);
            var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
            var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
            var pnlUldxyt = new XYT(pnlUld.X, pnlUld.Y, pnlT);

            // Attach 위치 보정값 계산.
            var revAttach = new XYT();
            ocaTarxyt = ApplyTargetOffset(ocaTarxyt, attachOffset);

            double radT = NormalizeTheta(ocaTarxyt.T - pnlObjxyt.T);

            double DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
            double DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
            revAttach.X = ocaTarxyt.X - DriftX;
            revAttach.Y = ocaTarxyt.Y - DriftY;
            revAttach.T = radT / rad;   // 부호 확인 필요.

            // Unload 위치 보정값 계산.
            // 연산은 해보지만 Plc에는 업데이트 안한다..기존값 써져잇을끼다
            var revUnload = new XYT();
            camTarxyt = ApplyTargetOffset(camTarxyt, unloadOffset);

            radT = NormalizeTheta(camTarxyt.T - pnlUldxyt.T);
            DriftX = Math.Cos(radT) * pnlUldxyt.X - Math.Sin(radT) * pnlUldxyt.Y;
            DriftY = Math.Sin(radT) * pnlUldxyt.X + Math.Cos(radT) * pnlUldxyt.Y;
            revUnload.X = camTarxyt.X - DriftX;
            revUnload.Y = camTarxyt.Y - DriftY;
            revUnload.T = radT / rad;   // 부호 확인 필요.
            #endregion

            #region Calc Inspection
            double ocaLongT = GetThetaColumn(rOCA_1st_L.X, rOCA_2st_L.X, cOCA_1st_L.Y, cOCA_2st_L.Y);
            double ocaShortT = GetThetaColumn(cOCA_2st_L.X, cOCA_2st_R.X, rOCA_2st_L.Y, rOCA_2st_R.Y);
            double pnlLongT = GetThetaColumn(rPNL_1st_L.X, rPNL_2st_L.X, cPNL_1st_L.Y, cPNL_2st_L.Y);
            double pnlShortT = GetThetaColumn(cPNL_2st_L.X, cPNL_2st_R.X, rPNL_2st_L.Y, rPNL_2st_R.Y);


            double lowerLx = (double)Math.Abs(DotProduct(cOCA_2st_L, cPNL_2st_L, cPNL_2st_R));
            double lowerLy = Math.Abs(CrossProduct(cOCA_2st_L, cPNL_2st_L, cPNL_2st_R));
            double lowerRx = Math.Abs(DotProduct(cOCA_2st_R, cPNL_2st_R, cPNL_2st_L));
            double lowerRy = Math.Abs(CrossProduct(cOCA_2st_R, cPNL_2st_R, cPNL_2st_L));



            double upperLx = Math.Abs(CrossProduct(cOCA_1st_L, cPNL_2st_L, cPNL_1st_L));
            double upperLy = Math.Abs(DotProduct(cOCA_1st_L, cPNL_1st_L, cPNL_2st_L ));            

            lowerLx *= Scale_Lower_L.X;
            lowerLy *= Scale_Lower_L.Y;
            lowerRx *= Scale_Lower_R.X;
            lowerRy *= Scale_Lower_R.Y;
            upperLx *= Scale_Upper_L.X;
            upperLy *= Scale_Upper_L.Y;

            bool bULx = ConfirmSpecRange(upperLx, Spec_Upper_L.X, Judge_Upper_Range);
            bool bULy = ConfirmSpecRange(upperLy, Spec_Upper_L.Y, Judge_Right_Range);
            bool bLLx = ConfirmSpecRange(lowerLx, Spec_Lower_L.X, Judge_Upper_Range);
            bool bLLy = ConfirmSpecRange(lowerLy, Spec_Lower_L.Y, Judge_Right_Range);
            bool bLRx = ConfirmSpecRange(lowerRx, Spec_Lower_R.X, Judge_Upper_Range);
            bool bLRy = ConfirmSpecRange(lowerRy, Spec_Lower_R.Y, Judge_Right_Range);

            double judge_Upper_value = (lowerRx - lowerLx) / 2;
            double judge_Right_value = (lowerLy - upperLy) / 2;

            bool bU = ConfirmSpecRange(judge_Upper_value, Judge_Upper_Center, Judge_Upper_Range);
            bool bR = ConfirmSpecRange(judge_Right_value, Judge_Right_Center, Judge_Right_Range);

            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo90SubLamiInspectResult
            {
                Name = name,
                ID = SourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                UpperLx = Math.Round(upperLx, 4),
                UpperLy = Math.Round(upperLy, 4),
                LowerLx = Math.Round(lowerLx, 4),
                LowerLy = Math.Round(lowerLy, 4),
                LowerRx = Math.Round(lowerRx, 4),
                LowerRy = Math.Round(lowerRy, 4),

                Lower = Math.Round(judge_Upper_value, 4),
                Right = Math.Round(judge_Right_value, 4),

                Judge_UpperLx = bULx,
                Judge_UpperLy = bULy,
                Judge_LowerLx = bLLx,
                Judge_LowerLy = bLLy,
                Judge_LowerRx = bLRx,
                Judge_LowerRy = bLRy,

                Judge_Upper = bU,
                Judge_Right = bR,

                RevX = Math.Round(revAttach.X, 3),
                RevY = Math.Round(revAttach.Y, 3),
                RevT = Math.Round(revAttach.T, 3),

                Oca_1st_Lx = Math.Round(cOCA_1st_L.X, 4),
                Oca_1st_Ly = Math.Round(cOCA_1st_L.Y, 4),
                Oca_2st_Lx = Math.Round(cOCA_2st_L.X, 4),
                Oca_2st_Ly = Math.Round(cOCA_2st_L.Y, 4),
                Oca_2st_Rx = Math.Round(cOCA_2st_R.X, 4),
                Oca_2st_Ry = Math.Round(cOCA_2st_R.Y, 4),

                Pnl_1st_Lx = Math.Round(cPNL_1st_L.X, 4),
                Pnl_1st_Ly = Math.Round(cPNL_1st_L.Y, 4),
                Pnl_2st_Lx = Math.Round(cPNL_2st_L.X, 4),
                Pnl_2st_Ly = Math.Round(cPNL_2st_L.Y, 4),
                Pnl_2st_Rx = Math.Round(cPNL_2st_R.X, 4),
                Pnl_2st_Ry = Math.Round(cPNL_2st_R.Y, 4),
            };

            if(!isRecalc)
                SystemLogger.WriteAlignDBLog(name, AlgoRst);

            #endregion

            #region Confirm Result
            //if (!ConfirmSpec(revAttach.X, limitX * (-1), limitX) ||
            //    !ConfirmSpec(revAttach.Y, limitY * (-1), limitY) ||
            //    !ConfirmSpec(revAttach.T, limitT * (-1), limitT))
            //{
            //    errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
            //    return false;
            //}
            #endregion

            #region Vision Write (Result & FDC)
            if (!isRecalc)
            {
                var IOs = new List<IOStruct>();
                VisionValues["InspectionX"].NextValue = (double)revAttach.X; IOs.Add(VisionValues["InspectionX"]);
                VisionValues["InspectionY"].NextValue = (double)revAttach.Y; IOs.Add(VisionValues["InspectionY"]);
                VisionValues["InspectionT"].NextValue = (double)revAttach.T; IOs.Add(VisionValues["InspectionT"]);



                if (VisionValues.ContainsKey("Inspection0X"))
                    VisionValues["Inspection0X"].NextValue = (double)lowerRx; IOs.Add(VisionValues["Inspection0X"]);
                if (VisionValues.ContainsKey("Inspection0Y"))
                    VisionValues["Inspection0Y"].NextValue = (double)lowerRy; IOs.Add(VisionValues["Inspection0Y"]);
                if (VisionValues.ContainsKey("Inspection1X"))
                    VisionValues["Inspection1X"].NextValue = (double)lowerLx; IOs.Add(VisionValues["Inspection1X"]);
                if (VisionValues.ContainsKey("Inspection1Y"))
                    VisionValues["Inspection1Y"].NextValue = (double)lowerLy; IOs.Add(VisionValues["Inspection1Y"]);
                if (VisionValues.ContainsKey("Inspection2X"))
                    VisionValues["Inspection2X"].NextValue = (double)upperLx; IOs.Add(VisionValues["Inspection2X"]);
                if (VisionValues.ContainsKey("Inspection2Y"))
                    VisionValues["Inspection2Y"].NextValue = (double)upperLy; IOs.Add(VisionValues["Inspection2Y"]);
                if (VisionValues.ContainsKey("Inspection3X"))
                    VisionValues["Inspection3X"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection3X"]);
                if (VisionValues.ContainsKey("Inspection3Y"))
                    VisionValues["Inspection3Y"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection3Y"]);



                CommodObject.SetVisionValues(IOs);
            }
            #endregion

            return true;
        }

        private void SetZeroInspectResult()
        {
            AlgoRst = new Algo90SubLamiInspectResult
            {
                Name = name,
                ID = SourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                UpperLx = 0,
                UpperLy = 0,
                LowerLx = 0,
                LowerLy = 0,
                LowerRx = 0,
                LowerRy = 0,

                Lower = 0,
                Right = 0,

                Judge_UpperLx = false,
                Judge_UpperLy = false,
                Judge_LowerLx = false,
                Judge_LowerLy = false,
                Judge_LowerRx = false,
                Judge_LowerRy = false,

                Judge_Upper = false,
                Judge_Right = false,

                RevX = 0,
                RevY = 0,
                RevT = 0,

                Oca_1st_Lx = 0,
                Oca_1st_Ly = 0,
                Oca_2st_Lx = 0,
                Oca_2st_Ly = 0,
                Oca_2st_Rx = 0,
                Oca_2st_Ry = 0,

                Pnl_1st_Lx = 0,
                Pnl_1st_Ly = 0,
                Pnl_2st_Lx = 0,
                Pnl_2st_Ly = 0,
                Pnl_2st_Rx = 0,
                Pnl_2st_Ry = 0,
            };

            var IOs = new List<IOStruct>();
            VisionValues["InspectionX"].NextValue = (double)0; IOs.Add(VisionValues["InspectionX"]);
            VisionValues["InspectionY"].NextValue = (double)0; IOs.Add(VisionValues["InspectionY"]);
            VisionValues["InspectionT"].NextValue = (double)0; IOs.Add(VisionValues["InspectionT"]);
            
            if (VisionValues.ContainsKey("Inspection0X"))
                VisionValues["Inspection0X"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection0X"]);
            if (VisionValues.ContainsKey("Inspection0Y"))
                VisionValues["Inspection0Y"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection0Y"]);
            if (VisionValues.ContainsKey("Inspection1X"))
                VisionValues["Inspection1X"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection1X"]);
            if (VisionValues.ContainsKey("Inspection1Y"))
                VisionValues["Inspection1Y"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection1Y"]);
            if (VisionValues.ContainsKey("Inspection2X"))
                VisionValues["Inspection2X"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection2X"]);
            if (VisionValues.ContainsKey("Inspection2Y"))
                VisionValues["Inspection2Y"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection2Y"]);
            if (VisionValues.ContainsKey("Inspection3X"))
                VisionValues["Inspection3X"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection3X"]);
            if (VisionValues.ContainsKey("Inspection3Y"))
                VisionValues["Inspection3Y"].NextValue = (double)0.0; IOs.Add(VisionValues["Inspection3Y"]);
            
            CommodObject.SetVisionValues(IOs);

        }
        private void SetZeroAlignResult(bool useUnloadWrite)
        {
            if (useUnloadWrite)
            {
                AlgoRst = new Algo90SubLamiAlignResult
                {
                    Name = name,
                    ID = SourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    AttachRevX = 0.0,
                    AttachRevY = 0.0,
                    AttachRevT = 0.0,

                    UnloadRevX = 0.0,
                    UnloadRevY = 0.0,
                    UnloadRevT = 0.0,

                    OffsetX = 0.0,
                    OffsetY = 0.0,
                    OffsetT = 0.0,

                    Oca_1st_Lx = 0.0,
                    Oca_1st_Ly = 0.0,
                    Oca_1st_Rx = 0.0,
                    Oca_1st_Ry = 0.0,
                    Oca_2st_Lx = 0.0,
                    Oca_2st_Ly = 0.0,

                    Pnl_1st_Lx = 0.0,
                    Pnl_1st_Ly = 0.0,
                    Pnl_2st_Lx = 0.0,
                    Pnl_2st_Ly = 0.0,
                    Pnl_2st_Rx = 0.0,
                    Pnl_2st_Ry = 0.0,

                    Oca_1st_Lx_px = 0.0,
                    Oca_1st_Ly_px = 0.0,
                    Oca_1st_Rx_px = 0.0,
                    Oca_1st_Ry_px = 0.0,
                    Oca_2st_Lx_px = 0.0,
                    Oca_2st_Ly_px = 0.0,

                    Pnl_1st_Lx_px = 0.0,
                    Pnl_1st_Ly_px = 0.0,
                    Pnl_2st_Lx_px = 0.0,
                    Pnl_2st_Ly_px = 0.0,
                    Pnl_2st_Rx_px = 0.0,
                    Pnl_2st_Ry_px = 0.0,
                };
            }
            else
            {
                AlgoRst = new Algo90SubLamiAlignResult
                {
                    Name = name,
                    ID = SourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    AttachRevX =0.0,
                    AttachRevY =0.0,
                    AttachRevT =0.0,

                    UnloadRevX = 0.0,
                    UnloadRevY = 0.0,
                    UnloadRevT = 0.0,

                    OffsetX = 0.0,
                    OffsetY = 0.0,
                    OffsetT = 0.0,

                    Oca_1st_Lx = 0.0,
                    Oca_1st_Ly = 0.0,
                    Oca_1st_Rx = 0.0,
                    Oca_1st_Ry = 0.0,
                    Oca_2st_Lx = 0.0,
                    Oca_2st_Ly = 0.0,

                    Pnl_1st_Lx = 0.0,
                    Pnl_1st_Ly = 0.0,
                    Pnl_2st_Lx = 0.0,
                    Pnl_2st_Ly = 0.0,
                    Pnl_2st_Rx = 0.0,
                    Pnl_2st_Ry = 0.0,

                    Oca_1st_Lx_px = 0.0,
                    Oca_1st_Ly_px = 0.0,
                    Oca_1st_Rx_px = 0.0,
                    Oca_1st_Ry_px = 0.0,
                    Oca_2st_Lx_px = 0.0,
                    Oca_2st_Ly_px = 0.0,

                    Pnl_1st_Lx_px = 0.0,
                    Pnl_1st_Ly_px = 0.0,
                    Pnl_2st_Lx_px = 0.0,
                    Pnl_2st_Ly_px = 0.0,
                    Pnl_2st_Rx_px = 0.0,
                    Pnl_2st_Ry_px = 0.0,
                };
            }


            var IOs = new List<IOStruct>();
            if (!useUnloadWrite)
            {
                VisionValues["TargetPosX"].NextValue = (double)/*curPos.X + */0.0; IOs.Add(VisionValues["TargetPosX"]);
                VisionValues["TargetPosY"].NextValue = (double)/*curPos.Y + */0.0; IOs.Add(VisionValues["TargetPosY"]);
                VisionValues["TargetPosT"].NextValue = (double)/*curPos.T + */0.0; IOs.Add(VisionValues["TargetPosT"]);
            }
            else
            {
                VisionValues["TargetPosX"].NextValue = (double)/*curPos.X + */0.0; IOs.Add(VisionValues["TargetPosX"]);
                VisionValues["TargetPosY"].NextValue = (double)/*curPos.Y + */0.0; IOs.Add(VisionValues["TargetPosY"]);
                VisionValues["TargetPosT"].NextValue = (double)/*curPos.T + */0.0; IOs.Add(VisionValues["TargetPosT"]);
            }

            VisionValues["InspectionX"].NextValue = (double)0.0; IOs.Add(VisionValues["InspectionX"]);
            VisionValues["InspectionY"].NextValue = (double)0.0; IOs.Add(VisionValues["InspectionY"]);
            VisionValues["InspectionT"].NextValue = (double)0.0; IOs.Add(VisionValues["InspectionT"]);
            VisionValues["TargetUnloadPosX"].NextValue = (double)/*unloadPos.X + */0.0; IOs.Add(VisionValues["TargetUnloadPosX"]);
            VisionValues["TargetUnloadPosY"].NextValue = (double)/*unloadPos.Y + */0.0; IOs.Add(VisionValues["TargetUnloadPosY"]);
            VisionValues["TargetUnloadPosT"].NextValue = (double)/*unloadPos.T + */0.0; IOs.Add(VisionValues["TargetUnloadPosT"]);

            // UnloadWrite 기능을 쓸때는 테스트모드 또는 정상이 아니므로 FDC 보고 하지 않음.
            if (!useUnloadWrite)
            {
                VisionValues["FDC_P0X"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P0X"]);
                VisionValues["FDC_P0Y"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P0Y"]);
                VisionValues["FDC_P0Score"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P0Score"]);
                VisionValues["FDC_P1X"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P1X"]);
                VisionValues["FDC_P1Y"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P1Y"]);
                VisionValues["FDC_P1Score"].NextValue = (int)100 * 10; IOs.Add(VisionValues["FDC_P1Score"]);
                VisionValues["FDC_P2X"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P2X"]);
                VisionValues["FDC_P2Y"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P2Y"]);
                VisionValues["FDC_P2Score"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P2Score"]);
                VisionValues["FDC_P3X"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P3X"]);
                VisionValues["FDC_P3Y"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P3Y"]);
                VisionValues["FDC_P3Score"].NextValue = (int)0; IOs.Add(VisionValues["FDC_P3Score"]);

                VisionValues["FDC_W0X"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W0X"]);
                VisionValues["FDC_W0Y"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W0Y"]);
                VisionValues["FDC_W0Score"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W0Score"]);
                VisionValues["FDC_W1X"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W1X"]);
                VisionValues["FDC_W1Y"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W1Y"]);
                VisionValues["FDC_W1Score"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W1Score"]);
                VisionValues["FDC_W2X"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W2X"]);
                VisionValues["FDC_W2Y"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W2Y"]);
                VisionValues["FDC_W2Score"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W2Score"]);
                VisionValues["FDC_W3X"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W3X"]);
                VisionValues["FDC_W3Y"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W3Y"]);
                VisionValues["FDC_W3Score"].NextValue = (int)0; IOs.Add(VisionValues["FDC_W3Score"]);

                VisionValues["FDC_PitchP12"].NextValue = (double)0; IOs.Add(VisionValues["FDC_PitchP12"]);
                VisionValues["FDC_PitchP34"].NextValue = (double)0; IOs.Add(VisionValues["FDC_PitchP34"]);
                VisionValues["FDC_PitchP13"].NextValue = (double)0; IOs.Add(VisionValues["FDC_PitchP13"]);
                VisionValues["FDC_PitchP14"].NextValue = (double)0; IOs.Add(VisionValues["FDC_PitchP14"]);
                VisionValues["FDC_PitchW12"].NextValue = (double)0; IOs.Add(VisionValues["FDC_PitchW12"]);
                VisionValues["FDC_PitchW34"].NextValue = (double)0; IOs.Add(VisionValues["FDC_PitchW34"]);
                VisionValues["FDC_PitchW13"].NextValue = (double)0; IOs.Add(VisionValues["FDC_PitchW13"]);
                VisionValues["FDC_PitchW14"].NextValue = (double)0; IOs.Add(VisionValues["FDC_PitchW14"]); // 확인 필요..14가 아니고 맵상은 24로 되어있음..2,3이되어야 할것같긴한데...?

                VisionValues["FDC_TargetPosX"].NextValue = (double)/*curPos.X*/ 0.0; IOs.Add(VisionValues["FDC_TargetPosX"]);
                VisionValues["FDC_TargetPosY"].NextValue = (double)/*curPos.Y*/ 0.0; IOs.Add(VisionValues["FDC_TargetPosY"]);
                VisionValues["FDC_TargetPosT"].NextValue = (double)/*curPos.T*/ 0.0; IOs.Add(VisionValues["FDC_TargetPosT"]);
                VisionValues["FDC_ResultRevX"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_ResultRevX"]);
                VisionValues["FDC_ResultRevY"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_ResultRevY"]);
                VisionValues["FDC_ResultRevT"].NextValue = (double)0.0; IOs.Add(VisionValues["FDC_ResultRevT"]);
            }

            CommodObject.SetVisionValues(IOs);
        }
        private void CalcGap()
        {
            UpperGap = CurPos_PNL_1st - CurPos_OCA_1st; // +
            LowerGap = CurPos_OCA_2st - CurPos_PNL_2st; // -
        }
        #endregion

        #region [Public Method]
        public XYT GetCurrentPos(GrabPos pos)
        {
            var IOs = new List<IOStruct>();
            IOs.Add(PlcValues["CurrentPosX"]);
            IOs.Add(PlcValues["CurrentPosY"]);
            IOs.Add(PlcValues["CurrentPosT"]);
             
            CommodObject.UpdatePlcValues(IOs);

            var curPos = new XYT();

            curPos.X = (double)PlcValues["CurrentPosX"].CurValue;
            curPos.Y = (double)PlcValues["CurrentPosY"].CurValue;
            curPos.T = (double)PlcValues["CurrentPosT"].CurValue;

            if (pos == GrabPos.OCA_1st)
            { CurPos_OCA_1st = curPos; SystemLogger.WriteDebuggingLog(string.Format("CurPos_OCA_1st - {0},{1},{2}", curPos.X, curPos.Y, curPos.T)); }
            //{ CurPos_OCA_1st = new XYT(0, 471.8871, 90); }
            else if (pos == GrabPos.OCA_2st)
            { CurPos_OCA_2st = curPos; SystemLogger.WriteDebuggingLog(string.Format("CurPos_OCA_2st - {0},{1},{2}", curPos.X, curPos.Y, curPos.T)); }
            //{ CurPos_OCA_2st = new XYT(0, 623.7475, 90); ; }
            else if (pos == GrabPos.PNL_1st)
            { CurPos_PNL_1st = curPos; SystemLogger.WriteDebuggingLog(string.Format("CurPos_PNL_1st - {0},{1},{2}", curPos.X, curPos.Y, curPos.T)); }
            //{ CurPos_PNL_1st = new XYT(0, 478.9815, 90); ; }
            else if (pos == GrabPos.PNL_2st)
            { CurPos_PNL_2st = curPos; SystemLogger.WriteDebuggingLog(string.Format("CurPos_PNL_2st - {0},{1},{2}", curPos.X, curPos.Y, curPos.T)); }
            //{ CurPos_PNL_2st = new XYT(0, 616.2426, 90); ; }

            return curPos;
        }

        #endregion

    }
}













