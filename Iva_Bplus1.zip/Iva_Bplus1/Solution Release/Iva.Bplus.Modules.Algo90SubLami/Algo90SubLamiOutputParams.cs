﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo90SubLami
{
    class Algo90SubLamiOutputParams : OutputParams
    {
        public object LogResult { get; set; }
    }
}
