﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]
    public class Algo90SubLamiResult : ViewModelBase
    {
        #region [fiedls]
        private string name;
        private string id;

        private string curDate;
        private string curTime;

        private double attachRevX;
        private double attachRevY;
        private double attachRevT;

        private double unloadRevX;
        private double unloadRevY;
        private double unloadRevT;

        private double offsetX;
        private double offsetY;
        private double offsetT;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double AttachRevX
        {
            get { return attachRevX; }
            set { if (value == attachRevX) return; attachRevX = value; OnPropertyChanged(nameof(AttachRevX)); }
        }
        public double AttachRevY
        {
            get { return attachRevY; }
            set { if (value == attachRevY) return; attachRevY = value; OnPropertyChanged(nameof(AttachRevY)); }
        }
        public double AttachRevT
        {
            get { return attachRevT; }
            set { if (value == attachRevT) return; attachRevT = value; OnPropertyChanged(nameof(AttachRevT)); }
        }
        public double UnloadRevX
        {
            get { return unloadRevX; }
            set { if (value == unloadRevX) return; unloadRevX = value; OnPropertyChanged(nameof(UnloadRevX)); }
        }
        public double UnloadRevY
        {
            get { return unloadRevY; }
            set { if (value == unloadRevY) return; unloadRevY = value; OnPropertyChanged(nameof(UnloadRevY)); }
        }
        public double UnloadRevT
        {
            get { return unloadRevT; }
            set { if (value == unloadRevT) return; unloadRevT = value; OnPropertyChanged(nameof(UnloadRevT)); }
        }
        public double OffsetX
        {
            get { return offsetX; }
            set { if (value == offsetX) return; offsetX = value; OnPropertyChanged(nameof(OffsetX)); }
        }
        public double OffsetY
        {
            get { return offsetY; }
            set { if (value == offsetY) return; offsetY = value; OnPropertyChanged(nameof(OffsetY)); }
        }
        public double OffsetT
        {
            get { return offsetT; }
            set { if (value == offsetT) return; offsetT = value; OnPropertyChanged(nameof(OffsetT)); }
        }
        #endregion


        public Algo90SubLamiResult()
        {
        }


        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1}\n,curTime: {2}\n, " +
                                  "attachRevX: {3}\n,attachRevY: {4}\n,attachRevT: {5}\n" +
                                  "unloadRevX: {6}\n,unloadRevY: {7}\n,unloadRevT: {8}\n" +
                                  "offsetX: {9}\n,offsetY: {10}\n,offsetT: {11}\n"
                                  , typeof(Algo90SubLamiResult).ToString(), curTime, curDate
                                  , attachRevX, attachRevY, attachRevT
                                  , unloadRevX, unloadRevY, unloadRevT
                                  , offsetX, offsetY, offsetT
                                  );
        }
    }
}
