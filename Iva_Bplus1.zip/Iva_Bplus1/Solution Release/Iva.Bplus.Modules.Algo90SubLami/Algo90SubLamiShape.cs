﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using Iva.Bplus.Views;
using SvMip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace Iva.Bplus.Modules.Algo90SubLami
{
    [SerializableAttribute]
    public partial class Algo90SubLamiShape : ModuleBase
    {
        #region [Construct]
        public Algo90SubLamiShape()
            : base()
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;
        }

        public Algo90SubLamiShape(SystemCanvasViewModel parent, string name)
            : base(parent, name)
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;

            base.InitItem(null, name, SettingShapeType.Algo);

            var action = base.modAction as SystemActionBase;
            base.SetConnectors(action.InputParams, action.OutputParams);

            ModAction.ModObject.PropertyChanged += ModObject_PropertyChanged;
        }
        #endregion

        #region [override method]
        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string _source)
        {
            base.parent = parent;
            base.InitItem(obj, _source, SettingShapeType.Algo);

            ModAction.ModObject.PropertyChanged += ModObject_PropertyChanged;

            base.Geometry = SystemImage.TOOLS_ICON;
        }

        private void ModObject_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            var obj = sender as Algo90SubLamiObject;
            if (e.PropertyName == "CalcType")
            {
                int connectorCnt = InputConnectors.Count();

                switch (obj.CalcType)
                {
                    case CalcType.Align:
                        base.InputConnectors_ItemRemoveAt(0);
                        base.InputConnectors_ItemRemoveAt(0);
                        base.InputConnectors_ItemRemoveAt(0);
                        base.InputConnectors_ItemInsert(0, new ConnectorViewModel("OCA_1st_L", typeof(MatchingRstData)));
                        base.InputConnectors_ItemInsert(1, new ConnectorViewModel("OCA_1st_R", typeof(MatchingRstData)));
                        base.InputConnectors_ItemInsert(2, new ConnectorViewModel("OCA_2st_L", typeof(MatchingRstData)));
                        break;
                    case CalcType.Inspection:
                        base.InputConnectors_ItemRemoveAt(0);
                        base.InputConnectors_ItemRemoveAt(0);
                        base.InputConnectors_ItemRemoveAt(0);
                        base.InputConnectors_ItemInsert(0, new ConnectorViewModel("OCA_1st_L", typeof(MatchingRstData)));
                        base.InputConnectors_ItemInsert(1, new ConnectorViewModel("OCA_2st_L", typeof(MatchingRstData)));
                        base.InputConnectors_ItemInsert(2, new ConnectorViewModel("OCA_2st_R", typeof(MatchingRstData)));
                        break;
                }
            }

        }

        public override void Dispose()
        {
            ModAction.ModObject.PropertyChanged -= ModObject_PropertyChanged;

            base.Dispose();
        }

        #endregion
    }
}
