﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    public enum CalcType { Align, Inspection}
    public enum GrabPos { OCA_1st, OCA_2st, PNL_1st, PNL_2st}
    public enum MeasurePos { UpperLx, UpperLy, LowerLx, LowerLy, LowerRx, LowerRy }

}

