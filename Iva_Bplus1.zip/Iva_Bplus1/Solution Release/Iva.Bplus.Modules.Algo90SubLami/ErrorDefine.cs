﻿using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo90SubLami
{
    public partial class Algo90SubLamiAction
    {
        #region [Error Script] Algo90SubLamiAction: 16001 ~ 16100
   
        public override void ErrorDefine()
        {
            base.ErrorDefine();
        }
        #endregion
    }
}
