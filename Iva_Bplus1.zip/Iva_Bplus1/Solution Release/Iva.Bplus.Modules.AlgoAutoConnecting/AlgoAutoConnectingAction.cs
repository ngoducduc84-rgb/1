﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.MultiIndexScheduler;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{

    [SerializableAttribute]
    public class AlgoAutoConnectingAction : AlgoActionBase
    {
        static public int WRN_CNT_OPEN  = 16601; static public string E16601_WARNING_CNT_OPEN   = "WARNING_CNT_OPEN";
        static public int WRN_CNT_CLOSE = 16602; static public string E16602_WARNING_CNT_CLOSE = "WARNING_CNT_CLOSE";
        public override void ErrorDefine()
        {
            base.ErrorDefine();
            errorInfos.Add(new ErrorInfo(this.Parent, WRN_CNT_OPEN,     ErrorType.Warning, E16601_WARNING_CNT_OPEN,     "Connector Open State"));
            errorInfos.Add(new ErrorInfo(this.Parent, WRN_CNT_CLOSE,    ErrorType.Warning, E16602_WARNING_CNT_CLOSE,    "Connector Close State"));
        }

        #region 생성자
        public AlgoAutoConnectingAction(ShapeBase _parent, string _name, string _source, AlgoObjectBase _object)
           : base(_parent, _name, _source, _object)
        {
            if (_object is AlgoAutoConnectingObject obj)
            {
                switch (obj.WorkType)
                {
                    case WorkType.ALIGN_FFC:
                    //case WorkType.ALIGN_CONNECTOR:
                        InputParams = new AlgoRefAlignInputParams(); // Input 파라메타 할당
                        obj.ModelParamType = typeof(AlgoAlignModelParams);// 모델 파라메타 타입 지정
                        ChildSettingView = new AlgoAlignSetting();// 세팅 뷰 생성
                        break;
                    case WorkType.ALIGN_INSERT:
                        InputParams = new AlgoTarObjAlignInputParams(); // Input 파라메타 할당
                        obj.ModelParamType = typeof(TarObjModelParams);// 모델 파라메타 타입 지정
                        ChildSettingView = new AlgoAlignSetting();// 세팅 뷰 생성
                        break;
                    //case WorkType.MEASURE_FFC_GRIP:
                    //case WorkType.MEASURE_FLIP_FINGER:
                    //    InputParams = new AlgoMeasureInputParams(); // Input 파라메타 할당
                    //    obj.ModelParamType = typeof(AlgoMeasureModelParams);// 모델 파라메타 타입 지정
                    //    ChildSettingView = new AlgoMeasureSetting();// 세팅 뷰 생성
                        //break;
                    case WorkType.INSPECT_OPEN_CLOSE:
                        InputParams = new AlgoInspectInputParams(); // Input 파라메타 할당
                        obj.ModelParamType = typeof(AlgoOpenCloseInspModelParams);// 모델 파라메타 타입 지정
                        ChildSettingView = new AlgoInspectSetting();// 세팅 뷰 생성
                        break;
                    //case WorkType.INSPECT_FLIP_CLOSE:
                    ////case WorkType.INSPECT_BROKEN:
                    //    InputParams = new AlgoInspectInputParams(); // Input 파라메타 할당
                    //    obj.ModelParamType = typeof(AlgoOpenCloseInspModelParams);// 모델 파라메타 타입 지정
                    //    ChildSettingView = new AlgoInspectSetting();// 세팅 뷰 생성
                    //break;
                    case WorkType.INSPECT_INSERT:
                        InputParams = new AlgoInspectInputParams(); // Input 파라메타 할당
                        obj.ModelParamType = typeof(AlgoMeasureInspectModelParams);// 모델 파라메타 타입 지정
                        ChildSettingView = new AlgoInspectSetting();// 세팅 뷰 생성
                        break;
                    case WorkType.INSPECT_INSERT_MARK:
                        InputParams = new AlgoTarObjAlignInputParams(); // Input 파라메타 할당
                        obj.ModelParamType = typeof(AlgoMeasureInspectMarkModelParams);// 모델 파라메타 타입 지정
                        ChildSettingView = new AlgoInspectSetting();// 세팅 뷰 생성
                        break;
                    default:
                        break;
                }
                var param = obj.CurParams;
            }

            OutputParams = new AlgoAutoConnectingOutputParams();

            if (ChildSettingView == null) return;
            ChildSettingView.DataContext = this;
        }
        #endregion

        #region 공용 함수
        public override List<CommandReplyArgs> Play(ModuleActionBase _act, CmdReqArgs _args)
        {
            // 1. 커넥터 이름 가져오기
            string connName = Start(_act, _args, false);

            if (connName.Equals("Trigger") || string.IsNullOrEmpty(connName))
            {
                StartTimer();

                var Obj = ModObject as AlgoAutoConnectingObject;
                Obj.SchedulerAction = _args.Value as MultiIndexSchedulerAction;
                
                // 2. 내부 객체 실행
                var result = Obj.Run();
                // 3. 하위 모듈(그리드 뷰 기록)은 무조건 실행
               // ReplyArgs = OutputPlay("Result", obj.AlgoRst, Enums.CmdRequest.Play, _args.Mode, Enums.CmdWait.No_Wait);

                if (!result)
                    return OccurError(Obj.ErrorCode);

                StopTimer();
            }
            // 4. 완료 처리
            return End();
        }
        #endregion
    }
}
