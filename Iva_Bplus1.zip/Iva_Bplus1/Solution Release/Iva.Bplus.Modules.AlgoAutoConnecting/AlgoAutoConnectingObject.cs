﻿using Cognex.VisionPro;
using Cognex.VisionPro.Blob;
using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.CogDisplay;
using Iva.Bplus.Modules.GridViewDisplay;
using Iva.Bplus.Modules.InspectionChart;
using Iva.Bplus.Modules.MultiIndexScheduler;
using Iva.Bplus.Modules.ProcLogDisplay;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    public enum WorkType
    {
        ALIGN_FFC,// 2p ref - Rbt1
        //ALIGN_CONNECTOR,// 2p ref - Rbt1 & Rbt2
        ALIGN_INSERT,// 2p tarobj - Rbt1

        //MEASURE_FFC_GRIP,// ffc edge ~ tool(gripper) - Rbt1
        //MEASURE_FLIP_FINGER,// flip ~ finger tool - Rbt2

        INSPECT_INSERT,// ffc marking line ~ flip 거리 판정 - Rbt1
        INSPECT_INSERT_MARK,// fpc marke ~ flip 거리 판정 - Rbt1
        //INSPECT_BROKEN,// 조립 후 flip broken, cnt 변형 검사 - Rbt1
        INSPECT_OPEN_CLOSE,// open 여부 검사 (ok - open, ng - not open) - Rbt2
        //INSPECT_FLIP_CLOSE,// close 여부 검사 (ok - close, ng - not close) - Rbt1
    }

    sealed class Key
    {
        #region 상수 정의
        // plc data key
        public static string OFFSET_X = "Offset_X";
        public static string OFFSET_Y = "Offset_Y";
        public static string OFFSET_T = "Offset_T";
        public static string R1_CURRENT_X = "CurPos#1";
        public static string R1_CURRENT_Y = "CurPos#2";
        public static string R1_CURRENT_T = "CurPos#3";
        public static string R2_CURRENT_X = "CamPosX#1";
        public static string R2_CURRENT_Y = "CamPosX#2";
        public static string R2_CURRENT_T = "CamPosY";
        public static string SRC_ID = "SourceID";
        // input data key
        public static string OBJECT1 = "Object1";
        public static string OBJECT2 = "Object2";
        public static string TARGET1 = "Target1";
        public static string TARGET2 = "Target2";
        public static string TOOLRESULT = "ToolResult";
        // vision data key

        public static string REV_X = "Rev#1_X";
        public static string REV_Y = "Rev#1_Y";
        public static string REV_T = "Rev#1_T";

        public static string TAR_X = "Tar#1_Pos#1";
        public static string TAR_Y = "Tar#1_Pos#2";
        public static string TAR_T = "Tar#1_Pos#3";

        public static string JUDGE1 = "Judgement#1";
        public static string JUDGE2 = "Judgement#2";
        public static string JUDGE3 = "Judgement#3";
        public static string JUDGE4 = "Judgement#4";

        public static string RESULT1 = "Result#1";
        public static string RESULT2 = "Result#2";
        public static string RESULT3 = "Result#3";
        public static string RESULT4 = "Result#4";

        public static string T1SCORE = "Tar1Score";
        public static string T2SCORE = "Tar2Score";
        public static string O1SCORE = "Obj1Score";
        public static string O2SCORE = "Obj2Score";
        #endregion
    }

    [SerializableAttribute]
    public partial class AlgoAutoConnectingObject : AlgoObjectBase
    {
        

        #region 변수 & 속성

        string _displayName;
        [Browsable(true)]
        [TypeConverter(typeof(CogDispListConverter))]
        public string DisplayName
        {
            get { return _displayName; }
            set { Set<string>(ref _displayName, value, nameof(DisplayName)); }
        }
        private CogDisplayObject Display
        {
            get
            {
                return SystemObject_Display.GetObject(DisplayName) as CogDisplayObject;
            }
        }

        string _calibName;
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string CalibName
        {
            get { return _calibName; }
            set { Set<string>(ref _calibName, value, nameof(CalibName)); }
        }
        private CalDataObject Calib
        {
            get
            {
                return SystemObject_Common.GetObject(CalibName) as CalDataObject;
            }
        }

        WorkType _workType;
        public WorkType WorkType
        {
            get { return _workType; }
            set
            {
                if(Set<WorkType>(ref _workType, value, nameof(WorkType)))
                {
                    InitModelParams();
                }
            }
        }

        private string resultGrid;
        private string dspChart;
        [Browsable(true)]
        [TypeConverter(typeof(GridViewListConverter))]
        public string ResultGrid
        {
            get { return resultGrid; }
            set { if (resultGrid == value) return; resultGrid = value; this.OnPropertyChanged(nameof(ResultGrid)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(ChartListConverter))]
        public string DspChart
        {
            get { return dspChart; }
            set { if (dspChart == value) return; dspChart = value; this.OnPropertyChanged(nameof(DspChart)); }
        }
        public GridViewDisplayObject GridViewObject
        {
            get { return SystemObject_Display.GetObject(ResultGrid) as GridViewDisplayObject; }
        }
        public InspectionChartObject ChartObject
        {
            get { return SystemObject_Display.GetObject(DspChart) as InspectionChartObject; }
        }
        public MultiIndexSchedulerAction SchedulerAction { get; set; }

        #endregion

        #region 생성자
        public AlgoAutoConnectingObject() : base()
        {
            InitModelParams();
        }

        private void InitModelParams()
        {
            
            ModelParams.Clear();
            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                {
                    switch (WorkType)
                    {
                        case WorkType.ALIGN_FFC:
                            ModelParams.Add(model, new AlgoAlignModelParams());
                            break;
                        case WorkType.ALIGN_INSERT:
                            ModelParams.Add(model, new TarObjModelParams());
                            break;
                        //case WorkType.MEASURE_FFC_GRIP:
                        //case WorkType.MEASURE_FLIP_FINGER:
                        //    ModelParams.Add(model, new AlgoMeasureModelParams());
                        //    break;
                        case WorkType.INSPECT_INSERT:
                            ModelParams.Add(model, new AlgoMeasureInspectModelParams());
                            break;
                        //case WorkType.INSPECT_BROKEN:
                        case WorkType.INSPECT_INSERT_MARK:
                            ModelParams.Add(model, new AlgoMeasureInspectMarkModelParams());
                            break;
                        case WorkType.INSPECT_OPEN_CLOSE:
                            //case WorkType.INSPECT_FLIP_CLOSE:
                            ModelParams.Add(model, new AlgoOpenCloseInspModelParams());
                            break;
                        default:
                            break;
                    }
                }
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region 공용 함수
        public override bool Run()
        {
            // 1. PLC Data 읽어오기
            var schedulerObj = SchedulerAction.ModObject as MultiIndexSchedulerObject;
            var workIdx = schedulerObj.RcvWorkIndex;

            AssignPLCData();
            bool result = true;
            switch (WorkType)
            {
                case WorkType.ALIGN_FFC:
                case WorkType.ALIGN_INSERT:
                    result = AlignCalc(workIdx);
                    break;
                case WorkType.INSPECT_INSERT:
                    result = InspectionInsert(workIdx);
                    break;
                case WorkType.INSPECT_INSERT_MARK:
                    result = InspectionInsertMark(workIdx);
                    break;
                case WorkType.INSPECT_OPEN_CLOSE:
                    result = InspectOpenClose(workIdx);
                    break;
                default:
                    return false;
            }
            // write vision value to plc memory
            result &= CommodObject.SetVisionValues(VisionValues.Values.ToList());
           
            return result;
        }
        public override void AssignPLCData()
        {
            // plc data 읽어오기 : plc align table 전체
            UpdatePLCIOs();
            // 구조체에 할당하기 : 실제 알고리즘에 사용할 데이터
            CvtPLCIO = new StdPLCTable();
            // cell id
            CvtPLCIO.SourceID = System.Convert.ToString(PlcValues[Key.SRC_ID].CurValue);
            // align offset
            CvtPLCIO.Offset1 = System.Convert.ToDouble(PlcValues[Key.OFFSET_X].CurValue);
            CvtPLCIO.Offset2 = System.Convert.ToDouble(PlcValues[Key.OFFSET_Y].CurValue);
            CvtPLCIO.Offset3 = System.Convert.ToDouble(PlcValues[Key.OFFSET_T].CurValue);
            // Robot#1 current position
            CvtPLCIO.CurPos1 = System.Convert.ToDouble(PlcValues[Key.R1_CURRENT_X].CurValue);
            CvtPLCIO.CurPos2 = System.Convert.ToDouble(PlcValues[Key.R1_CURRENT_Y].CurValue);
            CvtPLCIO.CurPos3 = System.Convert.ToDouble(PlcValues[Key.R1_CURRENT_T].CurValue);
            // Robot#2 current position
            CvtPLCIO.Teach1_Pos1 = System.Convert.ToDouble(PlcValues[Key.R2_CURRENT_X].CurValue);
            CvtPLCIO.Teach1_Pos2 = System.Convert.ToDouble(PlcValues[Key.R2_CURRENT_Y].CurValue);
            CvtPLCIO.Teach1_Pos3 = System.Convert.ToDouble(PlcValues[Key.R2_CURRENT_T].CurValue);
        }

        #endregion

        #region 내부 함수
        private void WriteLog(MsgType type, string msg)
        {
            if (SchedulerAction != null)
            {
                SchedulerAction.WriteLog(new ProcMsg(type, msg));
            }
        }

        private XYT GetCenterPoint(XY p1, XY p2)
        {
            return new XYT()
            {
                X = (p2.X + p1.X) / 2,
                Y = (p2.Y + p1.Y) / 2,
                T = GetTheta(p1, p2),
            };
        }

        private XY GetRotateCenter(string model)
        {
            var origin = Calib.GetStagePosition(model);
            var current = CvtPLCIO.CurPosXYT;
            var diff = current - origin;

            return Calib.GetRotateCenter(model) + diff.ToXY();
        }

        private bool CheckLength(double length, double spec, double tolerence)
        {
            if (tolerence == 0) return true;
            return spec - tolerence <= length && length <= spec + tolerence;
        }
        private bool CheckSpec(double length, double spec, double tolerence)
        {
            if (tolerence == 0) return true;
            return spec - tolerence <= length && length <= spec + tolerence;
        }


        private bool CheckLimit(XYT rev, XYT limit)
        {
            return Math.Abs(rev.X) <= limit.X && Math.Abs(rev.Y) <= limit.Y && Math.Abs(rev.T) <= limit.T;
        }
        /// <summary>
        /// Set Revision Values
        /// </summary>
        private void SetVisionValues(AlgoResultBase result)
        {
            try
            {
                if(result is AlgoAlignResult align)
                {
                    // revision value
                    VisionValues[Key.REV_X].NextValue = align.RevX;
                    VisionValues[Key.REV_Y].NextValue = align.RevY;
                    VisionValues[Key.REV_T].NextValue = align.RevT;

                    // target value : current + rev
                    var tar = CvtPLCIO.CurPosXYT + new XYT(align.RevX,align.RevY, align.RevT);

                    VisionValues[Key.TAR_X].NextValue = tar.X;
                    VisionValues[Key.TAR_Y].NextValue = tar.Y;
                    VisionValues[Key.TAR_T].NextValue = tar.T;
                    // score
                    //VisionValues[Key.T1SCORE].NextValue = align.ScoreT1;
                    //VisionValues[Key.T2SCORE].NextValue = align.ScoreT2;
                    //VisionValues[Key.O1SCORE].NextValue = align.ScoreO1;
                    //VisionValues[Key.O2SCORE].NextValue = align.ScoreO2;
                }
                //else if (result is AlgoMeasurementResult measure)
                //{
                //    // distance 만?
                //    VisionValues[Key.RESULT1].NextValue = measure.Distance;
                //    // score
                //    VisionValues[Key.T1SCORE].NextValue = measure.ScoreT1;
                //    VisionValues[Key.T2SCORE].NextValue = measure.ScoreT2;
                //    VisionValues[Key.O1SCORE].NextValue = measure.ScoreO1;
                //    VisionValues[Key.O2SCORE].NextValue = measure.ScoreO2;
                //}
                else if (result is AlgoInspectOpenCloseResult insp)
                {
                    // judgement
                    //VisionValues[Key.JUDGE1].NextValue = insp.Result == "OPENED" ? 1 : 2;//1: open, 2: close
                    // values
                }
            }
            catch(Exception ex)
            {
                SystemLogger.WriteExceptionLog(ex.ToString());
            }
        }

        private void DrawResult(AlgoResultBase algoRst, AlgoParams param)
        {
            Display.ClearLabels();

            if (algoRst is AlgoAlignResult align)
            {
                CogColorConstants color = align.Result == "OK" ? CogColorConstants.Green : CogColorConstants.Red;
                // Align Result
                XY offset = new XY(20, 10);
                string text = $"[{align.Result}]";
                Display.DrawLabel(new CogDrawLabelInfo(offset, text) { Color = color, FontSize = 13 });
                // Tool Result : Target
                offset = new XY(20, 170);
                text = $"Target - Length : {align.TarLen:F2} mm"; //Score1 : {align.ScoreT1:F1} %, Score2 : {align.ScoreT2:F1} %";
                Display.DrawLabel(new CogDrawLabelInfo(offset, text) { Color = color, FontSize = 10 });
                // Tool Result : Object
                offset = new XY(20, 300);
                text = $"Object - Length : {align.ObjLen:F2} mm";  //Score1 : {align.ScoreO1:F1} %, Score2 : {align.ScoreO2:F1} %";
                Display.DrawLabel(new CogDrawLabelInfo(offset, text) { Color = color, FontSize = 10 });
            }
            //else if (algoRst is AlgoMeasurementResult measure)
            //{
            //    CogColorConstants color = measure.Result == "OK" ? CogColorConstants.Green : CogColorConstants.Red;
            //    // Measurement Result
            //    XY offset = new XY(20, 10);
            //    string text = $"[{measure.Result}]";
            //    Display.DrawLabel(new CogDrawLabelInfo(offset, text) { Color = color, FontSize = 13 });
            //    // Tool Result : Target
            //    offset = new XY(20, 170);
            //    text = $"Target - Length : {measure.TarLen:F2} mm, Angle : {measure.TarAngle:F2} deg, Score : ({measure.ScoreT1:F1}, {measure.ScoreT2:F1}) %";
            //    Display.DrawLabel(new CogDrawLabelInfo(offset, text) { Color = color, FontSize = 10 });
            //    // Tool Result : Object
            //    offset = new XY(20, 300);
            //    text = $"Object - Length : {measure.ObjLen:F2} mm, Angle : {measure.ObjAngle:F2} deg, Score1 : ({measure.ScoreO1:F1}, {measure.ScoreO2:F1}) %";
            //    Display.DrawLabel(new CogDrawLabelInfo(offset, text) { Color = color, FontSize = 10 });

            //    // draw overlay line
            //    // target line
            //    var tar1 = (InputValues[Key.TARGET1] as IPointResult).OutputXYT.ToXY();
            //    var tar2 = (InputValues[Key.TARGET2] as IPointResult).OutputXYT.ToXY();
            //    Display.DrawLine(new CogDrawLineInfo() { Color = CogColorConstants.Red, Start = tar1, End = tar2, });

            //    // object line
            //    var obj1 = (InputValues[Key.OBJECT1] as IPointResult).OutputXYT.ToXY();
            //    var obj2 = (InputValues[Key.OBJECT2] as IPointResult).OutputXYT.ToXY();
            //    Display.DrawLine(new CogDrawLineInfo() { Color = CogColorConstants.Red, Start = obj1, End = obj2, });

            //    // arrow
            //    var center = GetCenterPoint(obj1, obj2).ToXY();
            //    var cross = GetCrossPoint(center, tar1, tar2);
            //    Display.DrawLine(new CogDrawLineInfo()
            //    {
            //        Color = CogColorConstants.Red,
            //        Start = center,
            //        End = cross,
            //        StartPointAdornment = CogLineSegmentAdornmentConstants.Arrow,
            //        EndPointAdornment = CogLineSegmentAdornmentConstants.Arrow
            //    });

            //    offset = (center + cross) / 2;
            //    text = $"{measure.Distance} mm";
            //    Display.DrawLabel(new CogDrawLabelInfo(offset, text) { Color = CogColorConstants.Red, FontSize = 10 });
            //}
            else if (algoRst is AlgoInspectOpenCloseResult insp)
            {

                var mparam = param as AlgoOpenCloseInspModelParams;
                var color = CogColorConstants.Green;
                // Align Result
                XY offset = new XY(20, 10);
                string text = $"[{insp.Work} ({insp.Result})]";

                Display.DrawLabel(new CogDrawLabelInfo(offset, text) { Color = color, FontSize = 13 });
            }
        }

        #endregion
    }
  
   
    
    public class AlgoAutoConnectingOutputParams : OutputParams
    {
        public object Result { get; set; }
    }
}
