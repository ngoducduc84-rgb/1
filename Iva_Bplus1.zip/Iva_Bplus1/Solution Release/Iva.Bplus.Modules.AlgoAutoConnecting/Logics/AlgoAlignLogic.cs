﻿using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.MultiIndexScheduler;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    public partial class AlgoAutoConnectingObject
    {
        #region local field for align

        #endregion

        private bool AlignCalc(WorkIndex Idx)
        {
            try
            {
                // 1. Model Param 가져오기
                var model = SystemModel.GetCurModel();
                if (!ModelParams.ContainsKey(model))
                {
                    ErrorCode = AlgoActionBase.Err_ModelData_Info_Missing;
                    return false;
                }

                // 2. Input Param 가져오기 : mark
                if (!InputValues.ContainsKey(Key.OBJECT1) || !InputValues.ContainsKey(Key.OBJECT2))
                {
                    ErrorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                switch (WorkType)
                {
                    case WorkType.ALIGN_FFC:
                        return GetAlign(model, Idx);
                    case WorkType.ALIGN_INSERT:
                        return TarObjAlign(model, Idx);
                    //case WorkType.ALIGN_CONNECTOR:
                    //    return PutAlign(model);
                }

            }
            catch(Exception)
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }

            ErrorCode = AlgoActionBase.Err_InputData_Info_Missing;
            return false;

        }
        string model = null;
        TarObjModelParams mTarObjParams;
        bool lastJudge = true;

        XY Robot_Tar1 = new XY();
        XY Robot_Tar2 = new XY();
        XY Robot_Obj1 = new XY();
        XY Robot_Obj2 = new XY();
        XY Coord_Tar1 = new XY();
        XY Coord_Tar2 = new XY();
        XY Coord_Obj1 = new XY();
        XY Coord_Obj2 = new XY();
        XY Mark_Tar1_XY = new XY();
        XY Mark_Tar2_XY = new XY();
        XY Mark_Obj1_XY = new XY();
        XY Mark_Obj2_XY = new XY();
        [NonSerialized]
        IPointResult Mark_Tar1;
        [NonSerialized]
        IPointResult Mark_Tar2;
        [NonSerialized]
        IPointResult Mark_Obj1;
        [NonSerialized]
        IPointResult Mark_Obj2;
        object alignOffset;
        object Offsets;
        XYT TarCenter = new XYT();
        XYT revAlign = new XYT();
        XYXY inspResult = new XYXY();
        private bool TarObjAlign(string _model, WorkIndex Idx)
        {
            try
            {

                model = SystemModel.GetCurModel();
                errorCode = 0;
                lastJudge = true;

                #region Model Data prepare
                AlgoParams modelParams;
                if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                mTarObjParams = modelParams as TarObjModelParams;
                //double limitX = (double)mTarObjParams.LimitX.Value;
                //double limitY = (double)mTarObjParams.LimitY.Value;
                //double limitT = (double)mTarObjParams.LimitT.Value;

                double spec_Lx = (double)mTarObjParams.Spec_Lx.Value;
                double spec_Ly = (double)mTarObjParams.Spec_Ly.Value;
                double spec_Rx = (double)mTarObjParams.Spec_Rx.Value;
                double spec_Ry = (double)mTarObjParams.Spec_Ry.Value;

                double tor_X = (double)mTarObjParams.Tor_X.Value;
                double tor_Y = (double)mTarObjParams.Tor_Y.Value;
                double tor_T = (double)mTarObjParams.Tor_T.Value;
                //double tor_Ry = (double)mTarObjParams.Tor_Ry.Value;

                //double spec_Length_Target = (double)mTarObjParams.Spec_Length_Target.Value;
                //double tor_Length_Target = (double)mTarObjParams.Tor_Length_Target.Value;
                //double spec_Length_Object = (double)mTarObjParams.Spec_Length_Object.Value;
                //double tor_Length_Object = (double)mTarObjParams.Tor_Length_Object.Value;

                //double last_offsetX = (double)mTarObjParams.Last_offsetX?.Value;
                double last_offsetY = (double)mTarObjParams.Last_offsetY?.Value;
                //double last_offsetT = (double)mTarObjParams.Last_offsetT?.Value;

                //XYT Limit = new XYT(limitX, limitY, limitT);
                XYXY Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
                XYT Tor = new XYT(tor_X, tor_Y, tor_T);
                #endregion

                #region Mark Data Read& Confirm
                var origin = Calib.GetStagePosition(model);
                var current = CvtPLCIO.CurPosXYT;
                var diff = current - origin;


                // object
                if (!InputValues.ContainsKey(Key.OBJECT1) || !InputValues.ContainsKey(Key.OBJECT2))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                Mark_Obj1 = InputValues[Key.OBJECT1] as IPointResult;
                Mark_Obj2 = InputValues[Key.OBJECT2] as IPointResult;
                if (Mark_Obj1 == null || Mark_Obj2 == null || XYT.Equal(Mark_Obj1.OutputXYT, new XYT()) || XYT.Equal(Mark_Obj2.OutputXYT, new XYT()))
                {
                    // Mark Data가 Null임
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                Mark_Obj1_XY = Mark_Obj1.OutputXYT.ToXY();
                Mark_Obj2_XY = Mark_Obj2.OutputXYT.ToXY();

                // target
                Mark_Tar1 = Mark_Tar2 = null;

                if (!InputValues.ContainsKey(Key.TARGET1) || !InputValues.ContainsKey(Key.TARGET2))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                Mark_Tar1 = InputValues[Key.TARGET1] as IPointResult;
                Mark_Tar2 = InputValues[Key.TARGET2] as IPointResult;
                if (Mark_Tar1 == null || Mark_Tar2 == null || XYT.Equal(Mark_Tar1.OutputXYT, new XYT()) || XYT.Equal(Mark_Tar2.OutputXYT, new XYT()))
                {
                    // Mark Data가 Null임
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                Mark_Tar1_XY = Mark_Tar1.OutputXYT.ToXY();
                Mark_Tar2_XY = Mark_Tar2.OutputXYT.ToXY();

                #endregion

                #region Coordinate Pos Calc & CalData Cofirm
                if (Calib == null ) //CalData는 2개, 카메라 왼쪽, 오른쪽
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    // Calibration 설정 안됨.
                    return false;
                }
                Robot_Tar1 = Calib.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));
                Robot_Tar2 = Calib.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y));

                Robot_Obj1 = Calib.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));
                Robot_Obj2 = Calib.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));

                XY RotCent1 = Calib.GetRotateCenter(model)+ diff.ToXY();
                XY RotCent2 = Calib.GetRotateCenter(model) + diff.ToXY();

                Coord_Tar1 = Robot_Tar1 + RotCent1;
                Coord_Tar2 = Robot_Tar2 + RotCent2;

                Coord_Obj1 = Robot_Obj1 + RotCent1;
                Coord_Obj2 = Robot_Obj2 + RotCent2;
                #endregion


                #region Calc Rev Offset
                #region Offset 적용
                Offsets = null;
                alignOffset = new XYXY(0, 0, 0, 0);

                if (Idx == WorkIndex.CAM1_INSERT_ALIGN || Idx == WorkIndex.CAM1_CNT_OPEN_AlIGN_1 ||
                    Idx == WorkIndex.CAM2_INSERT_ALIGN || Idx == WorkIndex.CAM2_CNT_OPEN_AlIGN_1)
                {
                    //Distance Spec 누적
                    (alignOffset as XYXY).Lx += spec_Lx * (-1);
                    (alignOffset as XYXY).Ly += spec_Ly * (-1);
                    (alignOffset as XYXY).Rx += spec_Rx * (+1);
                    (alignOffset as XYXY).Ry += spec_Ry * (-1);
                }
                // 201221 kcm FA 체결 자동화用
                //else if (Idx == WorkIndex.CAM1_CNT_OPEN_AlIGN_2 || Idx == WorkIndex.CAM2_CNT_OPEN_AlIGN_2)
                //{
                //    //Distance Spec 누적
                //    (alignOffset as XYXY).Lx += spec_Lx * (-1);
                //    (alignOffset as XYXY).Ly += spec_Ly * (-1);
                //    (alignOffset as XYXY).Rx += spec_Rx * (+1);
                //    (alignOffset as XYXY).Ry += spec_Ry * (-1);
                //}
                TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);          
                #endregion

                revAlign = new XYT();
                double radT, DriftX, DriftY;

                // Attach 위치 보정값 계산.             
                XY ObjXY = (Coord_Obj1 + Coord_Obj2) / 2;
                double T = GetTheta(Coord_Obj1, Coord_Obj2);
                T = NormalizeTheta(T);
                XYT ObjCenter = new XYT(ObjXY.X, ObjXY.Y, T);

                radT = TarCenter.T - ObjCenter.T;
                DriftX = Math.Cos(radT) * ObjCenter.X - Math.Sin(radT) * ObjCenter.Y;
                DriftY = Math.Sin(radT) * ObjCenter.X + Math.Cos(radT) * ObjCenter.Y;

                revAlign.X = TarCenter.X - DriftX;
                revAlign.Y = TarCenter.Y - DriftY;
                revAlign.T = radT / rad;
                #endregion

                #region Cal Inspection
                InspectionCalc(); // Align을 pixel CalData로 할 리가 없다.
                                  //P1_DisplayObj.Judgement = (uint)Judgement.InspOK;
                #endregion

                #region Confirm Result (Align Spec Over Check)


                #region retry spec over
                // 보정값 기준
                //if (!(retryX == 0.0 && retryY == 0.0 && retryT == 0.0)
                //   && (Math.Abs(revAlign.X) > retryX || Math.Abs(revAlign.Y) > retryY || Math.Abs(revAlign.T) > retryT))
                //{
                //    Display.Judgement = (uint)Judgement.Warning;;
                //    errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                //    lastJudge = false;
                //}
                //double x = 0.0;
                //double y = 0.0;
                //double t = 0.0;
                //if (Idx == WorkIndex.CAM1_INSERT_ALIGN || Idx == WorkIndex.CAM2_INSERT_ALIGN)
                //{
                //    x = 0.1; y = 0.2; t = 0.1;
                //}
                //else if (Idx == WorkIndex.CAM1_CNT_OPEN_AlIGN_2 || Idx == WorkIndex.CAM2_CNT_OPEN_AlIGN_2)
                //{
                //    x = 0.5; y = 0.2; t = 0.1;
                //}

                if (!CheckSpec(inspResult.Ly, Spec.Ly, Tor.Y) || !CheckSpec(inspResult.Ry, Spec.Ry, Tor.Y) ||
                    !CheckSpec(inspResult.Lx, Spec.Lx, Tor.X) || !CheckSpec(inspResult.Rx, Spec.Rx, Tor.X) ||
                    !CheckSpec(revAlign.X, 0, Tor.X) || !CheckSpec(revAlign.Y, 0, Tor.Y) || !CheckSpec(revAlign.T, 0, Tor.T))
                {
                    Display.Judgement = (uint)Judgement.Warning;
                    errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                    lastJudge = false;
                    WriteLog(MsgType.Important, string.Format("{0}", AlgoActionBase.E15030_Retry_Spec_Over));
                }
                else
                {
                    if (DspChart != "" || DspChart != null)
                    {
                        //var eLx = new Iva.Bplus.Struct.InspElement { Value = inspResult.Lx, Spec = spec_Lx, LSL = spec_Lx - Tor.X, USL = spec_Lx + Tor.X };
                        //var eLy = new Iva.Bplus.Struct.InspElement { Value = inspResult.Ly, Spec = spec_Ly, LSL = spec_Ly - Tor.Y, USL = spec_Ly + Tor.Y };
                        //var eRx = new Iva.Bplus.Struct.InspElement { Value = inspResult.Rx, Spec = spec_Rx, LSL = spec_Rx - Tor.X, USL = spec_Rx + Tor.X };
                        //var eRy = new Iva.Bplus.Struct.InspElement { Value = inspResult.Ry, Spec = spec_Ry, LSL = spec_Ry - Tor.Y, USL = spec_Ry + Tor.Y };

                        //var eObjLength = new Iva.Bplus.Struct.InspElement { Value = ObjLength, Spec = spec_Length_Object, LSL = spec_Length_Object - tor_Length_Object, USL = spec_Length_Object + tor_Length_Object };
                        //var eTarLength = new Iva.Bplus.Struct.InspElement { Value = TarLength, Spec = spec_Length_Target, LSL = spec_Length_Target - tor_Length_Target, USL = spec_Length_Target + tor_Length_Target };

                        //InputChart(name, SourceID, string.Empty, eLx, eLy, eRx, eRy);
                        //InputChart_Length(name, SourceID, string.Empty, eObjLength, eTarLength);
                    }


                    if (Idx == WorkIndex.CAM1_INSERT_ALIGN || Idx == WorkIndex.CAM1_CNT_OPEN_AlIGN_1 ||
                        Idx == WorkIndex.CAM2_INSERT_ALIGN || Idx == WorkIndex.CAM2_CNT_OPEN_AlIGN_1)
                    {
                        //revAlign.Y = last_offsetY * (-1);
                    }
                    // 201221 kcm FA 체결 자동화用
                    //else if (Idx == WorkIndex.CAM1_CNT_OPEN_AlIGN_2 || Idx == WorkIndex.CAM2_CNT_OPEN_AlIGN_2)
                    //{
                    //    revAlign.Y = last_offsetY;
                    //}

                    //revAlign.X = 0;
                    //revAlign.T = 0;
                    lastJudge = true;
                }


                #endregion

                #region Calc Length
                //length_tar = GetLength(Coord_Tar1, Coord_Tar2);
                //length_obj = GetLength(Coord_Obj1, Coord_Obj2);
                //if (!ConfirmLength(length_tar, spec_Length_Target, tor_Length_Target) || !ConfirmLength(length_obj, spec_Length_Object, tor_Length_Object))
                //{
                //    P1_DisplayObj.Judgement = (uint)Judgement.L_Check;
                //    P2_DisplayObj.Judgement = (uint)Judgement.L_Check;
                //    errorCode = AlgoActionBase.Err_Length_Check;

                //    lastJudge = false;
                //}
                #endregion

                #region limit spec over
                //if (!ConfirmResult(revAlign, Limit))
                //{
                //    P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                //    P2_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                //    errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                //    lastJudge = false;
                //}
                #endregion

                #endregion

                Task.Factory.StartNew(() => DrawLineLabel(model, Mark_Tar1, Mark_Obj1, Mark_Tar2, Mark_Obj2));
                WriteLog(MsgType.Important, string.Format("{0:F2},{1:F2},{2:F2}", revAlign.X, revAlign.Y, revAlign.T));
                // 7. 보정값 처리
                var now = DateTime.Now;
                AlgoRst = new AlgoAlignResult()
                {
                    Name = this.Name,
                    ID = this.SourceID,
                    CurDate = now.ToString("yyyy-MM-dd"),
                    CurTime = now.ToString("HH:mm:ss"),
                    Work = Idx.ToString(),

                    Result = lastJudge ? "OK" : $"NG - {SystemInfo.GetErrorInfo(ErrorCode).Title}",
                    Judgement = lastJudge,

                    RevX = Math.Round(revAlign.X, 3),
                    RevY = Math.Round(revAlign.Y, 3),
                    RevT = Math.Round(revAlign.T, 3),

                    //ScoreT1 = markTar1 == null ? 100.0 : Math.Round(markTar1.Score, 1),
                    //ScoreT2 = markTar2 == null ? 100.0 : Math.Round(markTar2.Score, 1),
                    //ScoreO1 = markObj1 == null ? 100.0 : Math.Round(markObj1.Score, 1),
                    //ScoreO2 = markObj2 == null ? 100.0 : Math.Round(markObj2.Score, 1),

                    //TarLen = Math.Round(tarLength, 3),
                    //ObjLen = Math.Round(objLength, 3),

                    T1X = Math.Round(Robot_Tar1.X, 3),
                    T1Y = Math.Round(Robot_Tar1.Y, 3),
                    T2X = Math.Round(Robot_Tar2.X, 3),
                    T2Y = Math.Round(Robot_Tar2.Y, 3),

                    O1X = Math.Round(Robot_Obj1.X, 3),
                    O1Y = Math.Round(Robot_Obj1.Y, 3),
                    O2X = Math.Round(Robot_Obj2.X, 3),
                    O2Y = Math.Round(Robot_Obj2.Y, 3),

                    CalX = Math.Round(origin.X, 3),
                    CalY = Math.Round(origin.Y, 3),
                    CurX = Math.Round(current.X, 3),
                    CurY = Math.Round(current.Y, 3),

                    Lx = Math.Round(inspResult.Lx, 3),
                    Ly = Math.Round(inspResult.Ly, 3),
                    Rx = Math.Round(inspResult.Rx, 3),
                    Ry = Math.Round(inspResult.Ry, 3),
                };

                GridViewObject.SetResult(AlgoRst);
                SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

                // 8. PLC Data 쓰기
                SetVisionValues(AlgoRst);

                return lastJudge;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }

        void InputChart(string u_ID, string o_ID, string t_ID, InspElement Lx, InspElement Ly, InspElement Rx, InspElement Ry)
        {
            var InputValue = new InspectionData();
            InputValue.U_ID = u_ID;
            InputValue.O_ID = u_ID == string.Empty ? SystemFunc.GetMakeID(7) : o_ID;
            InputValue.T_ID = t_ID == string.Empty ? SystemFunc.GetMakeID(7) : t_ID;
            InputValue.No = 1;
            InputValue.Time = DateTime.Now;

            InputValue.U_Lx.Value = Lx.Value;
            InputValue.U_Ly.Value = Ly.Value;
            InputValue.U_Rx.Value = Rx.Value;
            InputValue.U_Ry.Value = Ry.Value;

            InputValue.U_Lx.Spec = Lx.Spec;
            InputValue.U_Ly.Spec = Ly.Spec;
            InputValue.U_Rx.Spec = Rx.Spec;
            InputValue.U_Ry.Spec = Ry.Spec;

            InputValue.U_Lx.LSL = Lx.LSL;
            InputValue.U_Ly.LSL = Ly.LSL;
            InputValue.U_Rx.LSL = Rx.LSL;
            InputValue.U_Ry.LSL = Ry.LSL;

            InputValue.U_Lx.USL = Lx.USL;
            InputValue.U_Ly.USL = Ly.USL;
            InputValue.U_Rx.USL = Rx.USL;
            InputValue.U_Ry.USL = Ry.USL;


            ChartObject.InsertInspectionData(InputValue);
        }

        void InputChart_Length(string u_ID, string o_ID, string t_ID, InspElement obj, InspElement tar)
        {
            ChartObject.InsertObjectLength(obj);
            ChartObject.InsertTargetLength(tar);
        }

        protected void DrawLineLabel(string _model, IPointResult _target1, IPointResult _object1, IPointResult _target2, IPointResult _object2)
        {
            Display.ClearLabels();
            string model = _model;

            #region Draw Results 1

            //// Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
            makerInfo.Color = CogColorConstants.Red;
            var crossPoint_P1 = new XYT() + GetCrossPoint(Mark_Obj1_XY, Mark_Tar1_XY, Mark_Tar2_XY) /*+ Calib.GetRotateCenter(model)*/;
            //crossPoint_P1 = Calib.GetR2V(model, crossPoint_P1);
            makerInfo.Offset = crossPoint_P1;
            Display.DrawMaker(makerInfo);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = CogColorConstants.Red;
            lineInfo.Start = Mark_Tar1_XY;
            lineInfo.End = crossPoint_P1.ToXY();
            Display.DrawLine(lineInfo);
            lineInfo.Start = Mark_Obj1_XY;
            lineInfo.End = crossPoint_P1.ToXY();
            Display.DrawLine(lineInfo);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Obj1_XY) / 2 + new XY(0,0);
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BottomLeft;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ly);
            Display.DrawLabel(labelInfo);
            labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Tar1_XY) / 2 + new XY(0, 0);
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.TopRight;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Lx);
            Display.DrawLabel(labelInfo);
            #endregion

            #region Draw Results 2
            // Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo2 = new CogDrawMarkerInfo();
            makerInfo2.Color = CogColorConstants.Red;
            var crossPoint_P2 = new XYT() + GetCrossPoint(Mark_Obj2_XY, Mark_Tar2_XY, Mark_Tar1_XY)/* - Calib.GetRotateCenter(model)*/;
            //crossPoint_P2 = Calib.GetR2V(model, crossPoint_P2);
            makerInfo2.Offset = crossPoint_P2;
            Display.DrawMaker(makerInfo2);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo2 = new CogDrawLineInfo();
            lineInfo2.LineWidthInScreenPixels = 2;
            lineInfo2.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo2.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo2.Color = CogColorConstants.Red;
            lineInfo2.Start = Mark_Tar2_XY;
            lineInfo2.End = crossPoint_P2.ToXY();
            Display.DrawLine(lineInfo2);
            lineInfo2.Start = Mark_Obj2_XY;
            lineInfo2.End = crossPoint_P2.ToXY();
            Display.DrawLine(lineInfo2);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo2 = new CogDrawLabelInfo();
            labelInfo2.UseBackColor = true;
            labelInfo2.BackColor = CogColorConstants.White;
            labelInfo2.Offset = (crossPoint_P2.ToXY() + Mark_Obj2_XY) / 2 + new XY(0, 0);
            labelInfo2.Alignment = CogGraphicLabelAlignmentConstants.BottomRight;
            labelInfo2.Text = string.Format("{0:f2}mm", inspResult.Ry);
            Display.DrawLabel(labelInfo2);
            labelInfo2.Offset = (crossPoint_P2.ToXY() + Mark_Tar2_XY) / 2 + new XY(0, 0);
            labelInfo2.Alignment = CogGraphicLabelAlignmentConstants.TopLeft;
            labelInfo2.Text = string.Format("{0:f2}mm", inspResult.Rx);
            Display.DrawLabel(labelInfo2);
            #endregion
        }


        private void InspectionCalc()
        {
            inspResult = new XYXY();
            inspResult.Lx = GetDotDistance(Coord_Obj1, Coord_Tar1, Coord_Tar2);
            inspResult.Ly = GetCrossDistance(Coord_Obj1, Coord_Tar1, Coord_Tar2);
            inspResult.Rx = GetDotDistance(Coord_Obj2, Coord_Tar2, Coord_Tar1);
            inspResult.Ry = GetCrossDistance(Coord_Obj2, Coord_Tar2, Coord_Tar1);
        }

        private bool GetAlign(string _model, WorkIndex Idx)
        {
            try
            {
                // 3. 실제 좌표로 변환
                // 3-1. object
                var markTar1 = InputValues[Key.OBJECT1] as IPointResult;
                var markTar2 = InputValues[Key.OBJECT2] as IPointResult;
                // 회전 중심 보정 : current teaching 기준 위치 반영
                var origin = Calib.GetStagePosition(_model);
                var current = CvtPLCIO.CurPosXYT;
                // 20201209 kcm AG&보정검사用
                if (Idx == WorkIndex.CAM1_CNT_CLOSE_ALIGN   || Idx == WorkIndex.CAM2_CNT_CLOSE_ALIGN ||
                    Idx == WorkIndex.CAM1_CNT_CLOSE_AlIGN_2 || Idx == WorkIndex.CAM2_CNT_CLOSE_AlIGN_2)
                { current = CvtPLCIO.TeachPos1XYT; }
                var diff = current - origin;

                var rCenter = Calib.GetRotateCenter(_model) + diff.ToXY(); 

                var rbtTar1 = Calib.GetV2R(_model, markTar1.RefPoints[0].ToXY());
                var rbtTar2 = Calib.GetV2R(_model, markTar2.RefPoints[0].ToXY());
                var centerTar = GetCenterPoint(rbtTar1, rbtTar2);

                var coordTar = rCenter + centerTar;

                // 3-2. target
                XY rbtObj1, rbtObj2;
                //IPointResult markObject1 = null, markObject2 = null;

                rbtObj1 = Calib.GetV2R(_model, markTar1.OutputXYT.ToXY());
                rbtObj2 = Calib.GetV2R(_model, markTar2.OutputXYT.ToXY());


                var centerObj = GetCenterPoint(rbtObj1, rbtObj2);
                var coordObj = rCenter + centerObj;

                // 4. Target 연산 : offset 반영
                var newTarget = ApplyTargetOffset(coordTar, CvtPLCIO.OffsetXYT);

                // 5. 보정값 연산
                var rad = NormalizeTheta(newTarget.T - coordObj.T);
                var dx = Math.Cos(rad) * coordObj.X - Math.Sin(rad) * coordObj.Y;
                var dy = Math.Sin(rad) * coordObj.X + Math.Cos(rad) * coordObj.Y;

                var rev = new XYT()
                {
                    X = coordTar.X - dx,
                    Y = coordTar.Y - dy,
                    T = RadianToDegree(rad),
                };

                var mparam = ModelParams[_model] as AlgoAlignModelParams;

                // 5-1 보정값 + offSet
                XYT offSet = new XYT((double)mparam.OffSetX.Value, (double)mparam.OffSetY.Value, (double)mparam.OffSetT.Value);
                rev += offSet;

                // 6. 판정 : Length, Limit
                bool alignResult = true;

                // 6-1. check object length
                var tarLength = GetLength(rbtTar1, rbtTar2);
                var objLength = GetLength(rbtObj1, rbtObj2);

                ////if (alignResult && !CheckLength(objLength, tarLength, (double)mparam.LCheckTolerance.Value))
                ////{
                ////    ErrorCode = AlgoActionBase.Err_Lower_Length_Check;// error -> errorstate
                ////    Display.Judgement = (uint)Judgement.L_Check;
                ////    alignResult = false;
                ////}

                // 6-2. check limit
                XYT limit = new XYT((double)mparam.LimitX.Value, (double)mparam.LimitY.Value, (double)mparam.LimitT.Value);
                if (alignResult && !CheckLimit(rev, limit))
                {
                    ErrorCode = AlgoActionBase.Err_Limit_Over;// error -> errorstate
                    Display.Judgement = (uint)Judgement.Tor_Exceed;
                    alignResult = false;
                }

                // 7. 보정값 처리
                var now = DateTime.Now;
                AlgoRst = new AlgoAlignResult()
                {
                    Name = this.Name,
                    ID = this.SourceID,
                    CurDate = now.ToString("yyyy-MM-dd"),
                    CurTime = now.ToString("HH:mm:ss"),
                    Work = Idx.ToString(),
                    Result = alignResult ? "OK" : $"NG - {SystemInfo.GetErrorInfo(ErrorCode).Title}",
                    Judgement = alignResult,

                    RevX = Math.Round(rev.X, 3),
                    RevY = Math.Round(rev.Y, 3),
                    RevT = Math.Round(rev.T, 3),

                    //ScoreT1 = markObject1 == null ? 100.0 : Math.Round(markObject1.Score, 1),
                    //ScoreT2 = markObject2 == null ? 100.0 : Math.Round(markObject2.Score, 1),
                    //ScoreO1 = markTar1 == null ? 100.0 : Math.Round(markTar1.Score, 1),
                    //ScoreO2 = markTar2 == null ? 100.0 : Math.Round(markTar2.Score, 1),

                    TarLen = Math.Round(tarLength, 3),
                    ObjLen = Math.Round(objLength, 3),

                    T1X = Math.Round(rbtTar1.X, 3),
                    T1Y = Math.Round(rbtTar1.Y, 3),
                    T2X = Math.Round(rbtTar2.X, 3),
                    T2Y = Math.Round(rbtTar2.Y, 3),

                    O1X = Math.Round(rbtObj1.X, 3),
                    O1Y = Math.Round(rbtObj1.Y, 3),
                    O2X = Math.Round(rbtObj2.X, 3),
                    O2Y = Math.Round(rbtObj2.Y, 3),

                    CalX = Math.Round(origin.X, 3),
                    CalY = Math.Round(origin.Y, 3),
                    CurX = Math.Round(current.X, 3),
                    CurY = Math.Round(current.Y, 3),
                };

                GridViewObject.SetResult(AlgoRst);
                SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

                // 8. PLC Data 쓰기
                SetVisionValues(AlgoRst);

                // 9. 마무리 작업 : 결과값 화면(display) 표시
                Task.Factory.StartNew(() => { DrawResult(AlgoRst, mparam); });

                return alignResult;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }
        #region PutAlign (미사용)
        //private bool PutAlign(string _model)
        //{
        //    try
        //    {
        //        // 3. 실제 좌표로 변환
        //        // 3-1. object
        //        var markObj1 = InputValues[Key.OBJECT1] as IPointResult;
        //        var markObj2 = InputValues[Key.OBJECT2] as IPointResult;
        //        // 회전 중심 보정 : current teaching 기준 위치 반영
        //        var origin = Calib.GetStagePosition(_model);
        //        var current = CvtPLCIO.CurPosXYT;
        //        var diff = current - origin;

        //        //var rCenter = Calib.GetRotateCenter(model) + diff.ToXY();
        //        var rCenter = Calib.GetRotateCenter(_model)/* + diff.ToXY()*/;   // 4번 임시 Test


        //        var robotObj1 = Calib.GetV2R(_model, markObj1.OutputXYT.ToXY());
        //        var robotObj2 = Calib.GetV2R(_model, markObj2.OutputXYT.ToXY());
        //        var centerObj = GetCenterPoint(robotObj1, robotObj2);

        //        var coordObj = rCenter + centerObj;

        //        // 3-2. target
        //        XY robotTar1, robotTar2;
        //        IPointResult markTar1 = null, markTar2 = null;
        //        robotTar1 = Calib.GetV2R(_model, markObj1.RefPoints[0].ToXY());
        //        robotTar2 = Calib.GetV2R(_model, markObj2.RefPoints[1].ToXY());

        //        var centerTar = GetCenterPoint(robotTar1, robotTar2);
        //        var coordTar = rCenter + centerTar;

        //        // 4. Target 연산 : offset 반영
        //        var newTarget = ApplyTargetOffset(coordTar, CvtPLCIO.OffsetXYT);

        //        // 5. 보정값 연산
        //        var rad = NormalizeTheta(newTarget.T - coordObj.T);
        //        var dx = Math.Cos(rad) * coordObj.X - Math.Sin(rad) * coordObj.Y;
        //        var dy = Math.Sin(rad) * coordObj.X + Math.Cos(rad) * coordObj.Y;

        //        var rev = new XYT()
        //        {
        //            X = coordTar.X - dx,
        //            Y = coordTar.Y - dy,
        //            T = RadianToDegree(rad),
        //        };

        //        // 6. 판정 : Length, Limit
        //        bool alignResult = true;
        //        var mparam = ModelParams[_model] as AlgoAlignModelParams;

        //        // 6-1. check object length
        //        var tarLength = GetLength(robotTar1, robotTar2);
        //        var objLength = GetLength(robotObj1, robotObj2);
        //        if (WorkType == WorkType.ALIGN_INSERT)// tar - obj align
        //        {
        //            // target length
        //            if (alignResult && !CheckLength(tarLength, (double)mparam.TargetLength.Value, (double)mparam.LCheckTolerance.Value))
        //            {
        //                ErrorCode = AlgoActionBase.Err_Upper_Length_Check;// error -> errorstate
        //                Display.Judgement = (uint)Judgement.L_Check;
        //                alignResult = false;
        //            }

        //            // object length
        //            if (alignResult && !CheckLength(objLength, (double)mparam.ObjectLength.Value, (double)mparam.LCheckTolerance.Value))
        //            {
        //                ErrorCode = AlgoActionBase.Err_Lower_Length_Check;// error -> errorstate
        //                Display.Judgement = (uint)Judgement.L_Check;
        //                alignResult = false;
        //            }
        //        }
        //        else// reference align
        //        {
        //            if (alignResult && !CheckLength(objLength, tarLength, (double)mparam.LCheckTolerance.Value))
        //            {
        //                ErrorCode = AlgoActionBase.Err_Lower_Length_Check;// error -> errorstate
        //                Display.Judgement = (uint)Judgement.L_Check;
        //                alignResult = false;
        //            }
        //        }

        //        // 6-2. check limit
        //        XYT limit = new XYT((double)mparam.LimitX.Value, (double)mparam.LimitY.Value, (double)mparam.LimitT.Value);
        //        if (alignResult && !CheckLimit(rev, limit))
        //        {
        //            ErrorCode = AlgoActionBase.Err_Angle_Tolerance_Exceeded;// error -> errorstate
        //            Display.Judgement = (uint)Judgement.Tor_Exceed;
        //            alignResult = false;
        //        }
        //        // 7. 보정값 처리
        //        var now = DateTime.Now;
        //        AlgoRst = new AlgoAlignResult()
        //        {
        //            Name = this.Name,
        //            ID = this.SourceID,
        //            CurDate = now.ToString("yyyy-MM-dd"),
        //            CurTime = now.ToString("HH:mm:ss"),

        //            Result = alignResult ? "OK" : $"NG - {SystemInfo.GetErrorInfo(ErrorCode).Title}",
        //            Judgement = alignResult,

        //            RevX = Math.Round(rev.X, 3),
        //            RevY = Math.Round(rev.Y, 3),
        //            RevT = Math.Round(rev.T, 3),

        //            //ScoreT1 = markTar1 == null ? 100.0 : Math.Round(markTar1.Score, 1),
        //            //ScoreT2 = markTar2 == null ? 100.0 : Math.Round(markTar2.Score, 1),
        //            //ScoreO1 = markObj1 == null ? 100.0 : Math.Round(markObj1.Score, 1),
        //            //ScoreO2 = markObj2 == null ? 100.0 : Math.Round(markObj2.Score, 1),

        //            TarLen = Math.Round(tarLength, 3),
        //            ObjLen = Math.Round(objLength, 3),

        //            T1X = Math.Round(robotTar1.X, 3),
        //            T1Y = Math.Round(robotTar1.Y, 3),
        //            T2X = Math.Round(robotTar2.X, 3),
        //            T2Y = Math.Round(robotTar2.Y, 3),

        //            O1X = Math.Round(robotObj1.X, 3),
        //            O1Y = Math.Round(robotObj1.Y, 3),
        //            O2X = Math.Round(robotObj2.X, 3),
        //            O2Y = Math.Round(robotObj2.Y, 3),

        //            CalX = Math.Round(origin.X, 3),
        //            CalY = Math.Round(origin.Y, 3),
        //            CurX = Math.Round(current.X, 3),
        //            CurY = Math.Round(current.Y, 3),
        //        };

        //        GridViewObject.SetResult(AlgoRst);
        //        SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

        //        // 8. PLC Data 쓰기
        //        SetVisionValues(AlgoRst);

        //        // 9. 마무리 작업 : 결과값 화면(display) 표시
        //        Task.Factory.StartNew(() => { DrawResult(AlgoRst, mparam); });

        //        return alignResult;
        //    }
        //    catch
        //    {
        //        ErrorCode = AlgoActionBase.Err_Exception_Module;
        //        return false;
        //    }
        //}
        #endregion
    }



    #region Parameters
    [SerializableAttribute]
    public class AlgoAlignModelParams : AlgoParams
    {
        #region Limit
        private AlgoParam limitX = new AlgoParam(nameof(LimitX), "mm", typeof(double), 1.0, "Revision X Limit", 0.0, 50.0);
        public AlgoParam LimitX
        {
            get { return limitX; }
            set { Set<AlgoParam>(ref limitX, value, nameof(LimitX)); }
        }

        private AlgoParam limitY = new AlgoParam(nameof(LimitY), "mm", typeof(double), 1.0, "Revision Y Limit", 0.0, 50.0);
        public AlgoParam LimitY
        {
            get { return limitY; }
            set { Set<AlgoParam>(ref limitY, value, nameof(LimitY)); }
        }

        private AlgoParam limitT = new AlgoParam(nameof(LimitT), "mm", typeof(double), 1.0, "Revision T Limit", 0.0, 50.0);
        public AlgoParam LimitT
        {
            get { return limitT; }
            set { Set<AlgoParam>(ref limitT, value, nameof(LimitT)); }
        }
        #endregion

        #region L-Check Tolerence
        //private AlgoParam _tarLength = new AlgoParam(nameof(TargetLength), "mm", typeof(double), 80.0, "Target Length Spec", 0.1, 1000.0);
        //public AlgoParam TargetLength
        //{
        //    get { return _tarLength; }
        //    set { Set<AlgoParam>(ref _tarLength, value, nameof(TargetLength)); }
        //}

        //private AlgoParam _objLength = new AlgoParam(nameof(ObjectLength), "mm", typeof(double), 80.0, "Object Length", 0.1, 1000.0);
        //public AlgoParam ObjectLength
        //{
        //    get { return _objLength; }
        //    set { Set<AlgoParam>(ref _objLength, value, nameof(ObjectLength)); }
        //}

        //private AlgoParam _lCheckTolerance = new AlgoParam(nameof(LCheckTolerance), "mm", typeof(double), 0.05, "L-Check Tolerence", 0.0, 1.0);
        //public AlgoParam LCheckTolerance
        //{
        //    get { return _lCheckTolerance; }
        //    set { Set<AlgoParam>(ref _lCheckTolerance, value, nameof(LCheckTolerance)); }
        //}
        #endregion

        private AlgoParam offSetX = new AlgoParam(nameof(OffSetX), "mm", typeof(double), 0.0, "Align Revision X Offset", -10.0, 10.0);
        public AlgoParam OffSetX
        {
            get { return offSetX; }
            set { Set<AlgoParam>(ref offSetX, value, nameof(OffSetX)); }
        }

        private AlgoParam offSetY = new AlgoParam(nameof(OffSetY), "mm", typeof(double), 0.0, "Align Revision Y Offset", -10.0, 10.0);
        public AlgoParam OffSetY
        {
            get { return offSetY; }
            set { Set<AlgoParam>(ref offSetY, value, nameof(OffSetY)); }
        }

        private AlgoParam offSetT = new AlgoParam(nameof(OffSetT), "mm", typeof(double), 0.0, "Align Revision T Offset", -10.0, 10.0);
        public AlgoParam OffSetT
        {
            get { return offSetT; }
            set { Set<AlgoParam>(ref offSetT, value, nameof(OffSetT)); }
        }
    }

    public class AlgoRefAlignInputParams : InputParams
    {
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoTarObjAlignInputParams : InputParams
    {
        public IPointResult Target1 { get; set; }
        public IPointResult Target2 { get; set; }
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoAlignResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion
        public string Work { get; set; }
        public string Result { get; set; }// ok, ng - reason
        public bool Judgement { get; set; }

        #region ToolResult
        //public double ScoreT1 { get; set; }// target1 matching score
        //public double ScoreT2 { get; set; }// target2 matching score
        //public double ScoreO1 { get; set; }// object1 matching score
        //public double ScoreO2 { get; set; }// object2 matching score
        #endregion

        #region Revision Value
        public double RevX { get; set; }// revision x
        public double RevY { get; set; }// revision y
        public double RevT { get; set; }// revision t

        public double TarLen { get; set; }// target length
        public double ObjLen { get; set; }// object length
        #endregion

        #region Target Positions
        public double T1X { get; set; }//target1 X
        public double T1Y { get; set; }//target1 Y
        public double T2X { get; set; }//target2 X
        public double T2Y { get; set; }//target2 Y
        #endregion

        #region Object Positions
        public double O1X { get; set; }//object1 X
        public double O1Y { get; set; }//object1 Y
        public double O2X { get; set; }//object2 X
        public double O2Y { get; set; }//object2 Y
        #endregion

        #region calibration info
        public double CalX { get; set; }//calibration origin x
        public double CalY { get; set; }//calibration origin y
        public double CurX { get; set; }//current teaching x
        public double CurY { get; set; }//current teaching y
        #endregion

        #region Inspection info
        public double Lx { get; set; }
        public double Ly { get; set; }
        public double Rx { get; set; }
        public double Ry { get; set; }
        #endregion
    }
    #endregion
}
