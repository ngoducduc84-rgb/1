﻿using Cognex.VisionPro.Blob;
using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    public partial class AlgoAutoConnectingObject
    {
        #region local field for align
        readonly string MATCH_SCORE = "MatchScore";
        readonly string LEFT_RESULT = "LeftResult";
        readonly string RIGHT_RESULT = "RightResult";
        #endregion

        private bool InspectCalc()
        {
            try
            {
                // 1. Model Param 가져오기
                var model = SystemModel.GetCurModel();
                if (!ModelParams.ContainsKey(model))
                {
                    ErrorCode = AlgoActionBase.Err_ModelData_Info_Missing;
                    return false;
                }

                // 2. Input Param 가져오기 : mark
                var toolResults = InputValues[Key.TOOLRESULT] as Dictionary<string, object>;
                if (!toolResults.ContainsKey(MATCH_SCORE) || !toolResults.ContainsKey(LEFT_RESULT) || !toolResults.ContainsKey(RIGHT_RESULT))
                {
                    ErrorCode = AlgoActionBase.Err_InputData_Info_Missing;
                    Display.Judgement = (uint)Judgement.Fail;
                    return false;
                }
                var score = System.Convert.ToDouble(toolResults[MATCH_SCORE]) * 100;
                var leftBlobs = toolResults[LEFT_RESULT] as CogBlobResults;
                var rightBlobs = toolResults[RIGHT_RESULT] as CogBlobResults;
                if (leftBlobs == null || leftBlobs.GetBlobs().Count == 0 ||
                    rightBlobs == null || rightBlobs.GetBlobs().Count == 0)
                {
                    ErrorCode = AlgoActionBase.Err_InputData_Info_Missing;
                    Display.Judgement = (uint)Judgement.Fail;
                    return false;
                }

                var left = leftBlobs.GetBlobs()[0] as CogBlobResult;
                var right = rightBlobs.GetBlobs()[0] as CogBlobResult;

                // 3. Result : Open / Close
                var mparam = ModelParams[model] as AlgoInspectModelParams;
                bool judge = left.Area <= (int)mparam.LeftTolerance.Value && right.Area <= (int)mparam.RightTolerance.Value;
                if(!judge)
                {
                    ErrorCode = AlgoActionBase.Err_Inspection_Detect_NG;//warning -> result NG + Comp
                    Display.Judgement = (uint)Judgement.NG;
                    return false;
                }

                var now = DateTime.Now;
                AlgoRst = new AlgoInspectResult()
                {
                    Name = this.Name,
                    ID = this.SourceID,
                    CurDate = now.ToString("yyyy-MM-dd"),
                    CurTime = now.ToString("HH:mm:ss"),

                    Result = judge.ToString(),

                    MatchScore = Math.Round(score, 1),
                    LeftArea = (int)left.Area,
                    RightArea = (int)right.Area,
                };

                SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

                // 8. PLC Data 쓰기
                SetVisionValues(AlgoRst);

                // 9. 마무리 작업 : 결과값 화면(display) 표시
                Task.Factory.StartNew(() => { DrawResult(AlgoRst, mparam, left, right); });

                return true;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }
    }

    #region Parameters
    [SerializableAttribute]
    public class AlgoInspectModelParams : AlgoParams
    {
        private AlgoParam _leftTolerance = new AlgoParam(nameof(LeftTolerance), "pxl", typeof(int), 3000, "Left Area Tolerance", 0, 50000);
        public AlgoParam LeftTolerance
        {
            get { return _leftTolerance; }
            set { Set<AlgoParam>(ref _leftTolerance, value, nameof(LeftTolerance)); }
        }

        private AlgoParam _rightTolerance = new AlgoParam(nameof(RightTolerance), "pxl", typeof(int), 3000, "Left Area Tolerance", 0, 50000);
        public AlgoParam RightTolerance
        {
            get { return _rightTolerance; }
            set { Set<AlgoParam>(ref _rightTolerance, value, nameof(RightTolerance)); }
        }
    }

    public class AlgoInspectInputParams : InputParams
    {
        public object ToolResult { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoInspectResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion
        public string Result { get; set; }// Open, Close

        #region ToolResult
        public double MatchScore { get; set; }// matching score
        public int LeftArea { get; set; }// blob count in left area
        public int RightArea { get; set; }// blob count in right area
        #endregion
    }
    #endregion
}
