﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    public partial class AlgoAutoConnectingObject
    {
        #region local field for measure
   
        #endregion

        private bool MeasureCalc()
        {
            try
            {
                // 1. Model Param 가져오기
                var model = SystemModel.GetCurModel();
                if (!ModelParams.ContainsKey(model))
                {
                    ErrorCode = AlgoActionBase.Err_ModelData_Info_Missing;
                    Display.Judgement = (uint)Judgement.Fail;
                    return false;
                }

                // 2. Input Param 가져오기 : mark
                if (!InputValues.ContainsKey(Key.TARGET1) || !InputValues.ContainsKey(Key.TARGET2) ||
                    !InputValues.ContainsKey(Key.OBJECT1) || !InputValues.ContainsKey(Key.OBJECT2))
                {
                    ErrorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    Display.Judgement = (uint)Judgement.Fail;
                    return false;
                }

                // 3. 실제 좌표로 변환
                // 3-1. object
                var markTar1 = InputValues[Key.TARGET1] as IPointResult;
                var markTar2 = InputValues[Key.TARGET2] as IPointResult;
                var markObj1 = InputValues[Key.OBJECT1] as IPointResult;
                var markObj2 = InputValues[Key.OBJECT2] as IPointResult;

                var robotTar1 = Calib.GetV2R(model, markTar1.OutputXYT.ToXY());
                var robotTar2 = Calib.GetV2R(model, markTar2.OutputXYT.ToXY());
                var tarAngle = RadianToDegree(GetTheta(robotTar1, robotTar2));

                var robotObj1 = Calib.GetV2R(model, markObj1.OutputXYT.ToXY());
                var robotObj2 = Calib.GetV2R(model, markObj2.OutputXYT.ToXY());
                var objAngle = RadianToDegree(GetTheta(robotObj1, robotObj2));

                var centerObj = GetCenterPoint(robotObj1, robotObj2);

                // 4. calculate distance : point to line
                var distance = GetCrossDistance(centerObj.ToXY(), robotTar1, robotTar2);

                // 5. 판정 : Length
                bool measureResult = true;
                var mparam = ModelParams[model] as AlgoMeasureModelParams;

                // 5-1. check object length
                var tarLength = GetLength(robotTar1, robotTar2);
                var objLength = GetLength(robotObj1, robotObj2);
                // target length
                if (measureResult && !CheckLength(tarLength, (double)mparam.TargetLength.Value, (double)mparam.LCheckTolerance.Value))
                {
                    ErrorCode = AlgoActionBase.Err_Upper_Length_Check;// error -> errorstate
                    Display.Judgement = (uint)Judgement.L_Check;
                    measureResult = false;
                }

                // object length
                if (measureResult && !CheckLength(objLength, (double)mparam.ObjectLength.Value, (double)mparam.LCheckTolerance.Value))
                {
                    ErrorCode = AlgoActionBase.Err_Lower_Length_Check;// error -> errorstate
                    Display.Judgement = (uint)Judgement.L_Check;
                    measureResult = false;
                }

                // 5-2. check angle
                if(measureResult && Math.Abs( tarAngle - objAngle) > (double)mparam.AngleTolerance.Value)
                {
                    ErrorCode = AlgoActionBase.Err_Angle_Tolerance_Exceeded;// error -> errorstate
                    Display.Judgement = (uint)Judgement.NG;
                    measureResult = false;
                }

                // 6. Result
                var now = DateTime.Now;
                AlgoRst = new AlgoMeasurementResult()
                {
                    Name = this.Name,
                    ID = this.SourceID,
                    CurDate = now.ToString("yyyy-MM-dd"),
                    CurTime = now.ToString("HH:mm:ss"),

                    Result = measureResult ? "OK" : $"NG - {SystemInfo.GetErrorInfo(ErrorCode).Title}",

                    Distance = Math.Round(distance, 3),

                    ScoreT1 = markTar1 == null ? 100.0 : Math.Round(markTar1.Score, 1),
                    ScoreT2 = markTar2 == null ? 100.0 : Math.Round(markTar2.Score, 1),
                    ScoreO1 = markObj1 == null ? 100.0 : Math.Round(markObj1.Score, 1),
                    ScoreO2 = markObj2 == null ? 100.0 : Math.Round(markObj2.Score, 1),

                    TarLen = Math.Round(tarLength, 2),
                    ObjLen = Math.Round(objLength, 2),

                    TarAngle = Math.Round(tarAngle, 2),
                    ObjAngle = Math.Round(objAngle, 2),
                };

                SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

                // 8. PLC Data 쓰기
                SetVisionValues(AlgoRst);

                // 9. 마무리 작업 : 결과값 화면(display) 표시
                Task.Factory.StartNew(() => { DrawResult(AlgoRst, mparam); });

                return measureResult;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }
    }

    #region Parameters
    [SerializableAttribute]
    public class AlgoMeasureModelParams : AlgoParams
    {
        #region L-Check
        private AlgoParam _tarLength = new AlgoParam(nameof(TargetLength), "mm", typeof(double), 80.0, "Target Length Spec", 0.1, 1000.0);
        public AlgoParam TargetLength
        {
            get { return _tarLength; }
            set { Set<AlgoParam>(ref _tarLength, value, nameof(TargetLength)); }
        }

        private AlgoParam _objLength = new AlgoParam(nameof(ObjectLength), "mm", typeof(double), 80.0, "Object Length", 0.1, 1000.0);
        public AlgoParam ObjectLength
        {
            get { return _objLength; }
            set { Set<AlgoParam>(ref _objLength, value, nameof(ObjectLength)); }
        }

        private AlgoParam _lCheckTolerance = new AlgoParam(nameof(LCheckTolerance), "mm", typeof(double), 0.05, "L-Check Tolerence", 0.0, 1.0);
        public AlgoParam LCheckTolerance
        {
            get { return _lCheckTolerance; }
            set { Set<AlgoParam>(ref _lCheckTolerance, value, nameof(LCheckTolerance)); }
        }
        #endregion

        #region Angle
        private AlgoParam _angleTolerance = new AlgoParam(nameof(AngleTolerance), "deg", typeof(double), 1.0, "Angle Tolerence", 0.0, 5.0);
        public AlgoParam AngleTolerance
        {
            get { return _angleTolerance; }
            set { Set<AlgoParam>(ref _angleTolerance, value, nameof(AngleTolerance)); }
        }
        #endregion
    }

    public class AlgoMeasureInputParams : InputParams
    {
        public IPointResult Target1 { get; set; }
        public IPointResult Target2 { get; set; }
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoMeasurementResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion
        public string Result { get; set; }// ok, ng - reason

        #region ToolResult
        public double ScoreT1 { get; set; }// target1 matching score
        public double ScoreT2 { get; set; }// target2 matching score
        public double ScoreO1 { get; set; }// object1 matching score
        public double ScoreO2 { get; set; }// object2 matching score
        #endregion

        #region Measurement
        public double TarLen { get; set; }
        public double TarAngle { get; set; }
        public double ObjLen { get; set; }
        public double ObjAngle { get; set; }
        public double Distance { get; set; }
        #endregion
    }
    #endregion
}
