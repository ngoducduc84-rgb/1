﻿using Cognex.VisionPro.Blob;
using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.MultiIndexScheduler;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    public partial class AlgoAutoConnectingObject
    {
        #region Algorithm
        private bool InspectOpenClose(WorkIndex Idx)
        {
            try
            {
                //bool isOpenInsp =   Idx == WorkIndex.CAM1_OPEN_INSPECT_1 || Idx == WorkIndex.CAM1_CLOSE_INSPECT ||
                //                    Idx == WorkIndex.CAM2_OPEN_INSPECT_1 || Idx == WorkIndex.CAM2_CLOSE_INSPECT ? true : false;

                // 1. Model Param 가져오기
                var model = SystemModel.GetCurModel();
                if (!ModelParams.ContainsKey(model))
                {
                    ErrorCode = AlgoActionBase.Err_ModelData_Info_Missing;
                    return false;
                }

                // 2. Input Param 가져오기 : mark
                var toolResults = InputValues[Key.TOOLRESULT] as IPointResult;
                bool isClose = false;

                // 3. Mark를 찾으면 닫힌거임
                // 못찾은거
                if (toolResults.SuccessIndex == -1) 
                    isClose = false;
                // 찾은거
                else 
                    isClose = true;

                bool judge = false;
                //isClose = true;
                //isClose = false;
                if (isClose)
                {
                    ErrorCode = AlgoAutoConnectingAction.WRN_CNT_CLOSE;
                    WriteLog(MsgType.Warning, AlgoAutoConnectingAction.E16602_WARNING_CNT_CLOSE);
                }
                //else if (!isOpenInsp && !isClose)
                //{
                //    ErrorCode = AlgoAutoConnectingAction.WRN_CNT_OPEN;
                //    WriteLog(MsgType.Warning, AlgoAutoConnectingAction.E16601_WARNING_CNT_OPEN);
                //}
                else
                {
                    judge = true;
                    WriteLog(MsgType.Important, string.Format("{0} ({1})", Idx.ToString(), isClose == true ? "Close" : "Open"));
                }

                var now = DateTime.Now;
                AlgoRst = new AlgoAlignResult()
                {
                    Name = this.Name,
                    ID = this.SourceID,
                    CurDate = now.ToString("yyyy-MM-dd"),
                    CurTime = now.ToString("HH:mm:ss"),
                    Work= Idx.ToString(),
                    Result = isClose == true ? "Close" : "Open",
                    Judgement = judge,
                };

                GridViewObject.SetResult(AlgoRst);
                SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

                // 8. PLC Data 쓰기
                SetVisionValues(AlgoRst);

                // 9. 마무리 작업 : 결과값 화면(display) 표시
                Task.Factory.StartNew(() => { DrawResult(AlgoRst, null); });

                return judge;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }
        #endregion
    }

    #region Parameters
    [SerializableAttribute]
    public class AlgoOpenCloseInspModelParams : AlgoParams
    {
      
    }

    public class AlgoInspectInputParams : InputParams
    {
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public object ToolResult { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoInspectOpenCloseResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion
        public string Work { get; set; }
        public string State { get; set; }
        public bool Result { get; set; }
    }
    #endregion
}
