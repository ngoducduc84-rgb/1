﻿using Cognex.VisionPro.Dimensioning;
using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.MultiIndexScheduler;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    public partial class AlgoAutoConnectingObject
    {
        #region local field for measure

        #endregion

        AlgoMeasureInspectModelParams mInspectionParams;
        private bool InspectionInsert(WorkIndex Idx)
        {
            try
            {
                if (!(Idx == WorkIndex.CAM1_CLOSE_INSPECT || Idx == WorkIndex.CAM2_CLOSE_INSPECT))
                {
                    return true;
                }
                // 1. Model Param 가져오기
                var model = SystemModel.GetCurModel();
                if (!ModelParams.ContainsKey(model))
                {
                    ErrorCode = AlgoActionBase.Err_ModelData_Info_Missing;
                    Display.Judgement = (uint)Judgement.Fail;
                    return false;
                }

                // 2. Input Param 가져오기 : mark
                if (!InputValues.ContainsKey(Key.TOOLRESULT))
                {
                    ErrorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    Display.Judgement = (uint)Judgement.Fail;
                    return false;
                }

                // 3. 실제 좌표로 변환
                // 3-1. object
                var toolResult = InputValues[Key.TOOLRESULT] as Dictionary<string, object>;


                AlgoParams modelParams;
                if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                mInspectionParams = modelParams as AlgoMeasureInspectModelParams;
                double distLx = (double)mInspectionParams.DistLx.Value;
                double distLy = (double)mInspectionParams.DistLy.Value;
                double distRx = (double)mInspectionParams.DistRx.Value;
                double distRy = (double)mInspectionParams.DistRy.Value;
                double distTor = (double)mInspectionParams.DistTolerence.Value;

                lastJudge = true;

                var dsp = toolResult["Display"] as CogDisplay.CogDisplayObject;
                //var left = toolResult["CaliperResult_0"] as Cognex.VisionPro.Caliper.CogCaliperResult;
                //var right = toolResult["CaliperResult_1"] as Cognex.VisionPro.Caliper.CogCaliperResult;
                var upperLine = toolResult["UpperLine"] as Cognex.VisionPro.CogLine;
                var lowerLine = toolResult["LowerLine"] as Cognex.VisionPro.CogLine;
                var Mark_Obj1 = InputValues[Key.OBJECT1] as IPointResult;
                var Mark_Obj2 = InputValues[Key.OBJECT2] as IPointResult;

                var image = dsp.GetCurImage() as Cognex.VisionPro.ICogImage;
                var topLeft = new XY();
                var topRight = new XY();
                var bottomLeft = new XY();
                topLeft = Calib.GetV2R(model, new XY(0, 0));
                topRight = Calib.GetV2R(model, new XY(0, image.Width));
                bottomLeft = Calib.GetV2R(model, new XY(0, image.Height));

                double fovX = GetLength(topLeft, topRight);
                double fovY = GetLength(topLeft, bottomLeft);

                double pxX = fovX / image.Width;
                double pxY = fovY / image.Height;
                double pxC = (pxX + pxY) / 2;


                //if (left == null || right == null)
                //{
                //    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //    return false;
                //}

                //var RbtLeftEdge0 = Calib.GetV2R(model, new XY(left.Edge0.PositionX, left.Edge0.PositionY));
                //var RbtLeftEdge1 = Calib.GetV2R(model, new XY(left.Edge1.PositionX, left.Edge1.PositionY));
                //var RbtRightEdge0 = Calib.GetV2R(model, new XY(right.Edge0.PositionX, right.Edge0.PositionY));
                //var RbtRightEdge1 = Calib.GetV2R(model, new XY(right.Edge1.PositionX, right.Edge1.PositionY));

                //double dist_0 = GetLength(new XY(RbtLeftEdge0.X, RbtLeftEdge0.Y), new XY(RbtLeftEdge1.X, RbtLeftEdge1.Y));
                //double dist_1 = GetLength(new XY(RbtRightEdge0.X, RbtRightEdge0.Y), new XY(RbtRightEdge1.X, RbtRightEdge1.Y));

                //var upperDist = upperLine.DistanceToPoint(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y) * pxC;
                //var lowerDist = lowerLine.DistanceToPoint(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y) * pxC;

                var upperPLTool = new CogDistancePointLineTool();
                upperPLTool.InputImage = image;
                upperPLTool.Line = upperLine;
                upperPLTool.X = Mark_Obj2.OutputXYT.X;
                upperPLTool.Y = Mark_Obj2.OutputXYT.Y;
                upperPLTool.Run();
                var upperDist = upperPLTool.Distance * pxC;

                var lowerPLTool = new CogDistancePointLineTool();
                lowerPLTool.InputImage = image;
                lowerPLTool.Line = lowerLine;
                lowerPLTool.X = Mark_Obj1.OutputXYT.X;
                lowerPLTool.Y = Mark_Obj1.OutputXYT.Y;
                lowerPLTool.Run();
                var lowerDist = lowerPLTool.Distance * pxC;

                var RbtUpperPoint = Calib.GetV2R(model, new XY(upperPLTool.LineX, upperPLTool.LineY));
                var RbtLowerPoint = Calib.GetV2R(model, new XY(lowerPLTool.LineX, lowerPLTool.LineY));
                var RbtMarkObj1 = Calib.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));
                var RbtMarkObj2 = Calib.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));

                var RbtLowerDist = GetLength(new XY(RbtMarkObj1.X, RbtMarkObj1.Y), new XY(RbtLowerPoint.X, RbtLowerPoint.Y));
                var RbtUpperDist = GetLength(new XY(RbtMarkObj2.X, RbtMarkObj2.Y), new XY(RbtUpperPoint.X, RbtUpperPoint.Y));


                if (/*!CheckSpec(dist_0, distLy, distTor)       || !CheckSpec(dist_1, distRy, distTor) ||*/
                    !CheckSpec(RbtLowerDist, distLx, distTor) || !CheckSpec(RbtUpperDist, distRx, distTor))
                {
                    Display.Judgement = (uint)Judgement.Warning;
                    errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                    lastJudge = false;
                    WriteLog(MsgType.Important, string.Format("{0}", AlgoActionBase.E15030_Retry_Spec_Over));
                }
                else
                {
                    lastJudge = true;
                }

                #region Draw Line, Label
                //var leftDrawLine = new CogDrawLineInfo(
                //    new XY(left.Edge0.PositionX, left.Edge0.PositionY),
                //    new XY(left.Edge1.PositionX, left.Edge1.PositionY),
                //    2,
                //    Cognex.VisionPro.CogColorConstants.Orange,
                //    Cognex.VisionPro.CogLineSegmentAdornmentConstants.Arrow,
                //    Cognex.VisionPro.CogLineSegmentAdornmentConstants.Arrow);
                //var rightDrawLine = new CogDrawLineInfo(
                //    new XY(right.Edge0.PositionX, right.Edge0.PositionY),
                //    new XY(right.Edge1.PositionX, right.Edge1.PositionY),
                //    2,
                //    Cognex.VisionPro.CogColorConstants.Orange,
                //    Cognex.VisionPro.CogLineSegmentAdornmentConstants.Arrow,
                //    Cognex.VisionPro.CogLineSegmentAdornmentConstants.Arrow);
                var upperDrawLine = new CogDrawLineInfo(
                    new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y),
                    new XY(upperPLTool.LineX, upperPLTool.LineY),
                    2,
                    Cognex.VisionPro.CogColorConstants.Orange,
                    Cognex.VisionPro.CogLineSegmentAdornmentConstants.Arrow,
                    Cognex.VisionPro.CogLineSegmentAdornmentConstants.Arrow);
                var lowerDrawLine = new CogDrawLineInfo(
                    new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y),
                    new XY(lowerPLTool.LineX, lowerPLTool.LineY),
                    2,
                    Cognex.VisionPro.CogColorConstants.Orange,
                    Cognex.VisionPro.CogLineSegmentAdornmentConstants.Arrow,
                    Cognex.VisionPro.CogLineSegmentAdornmentConstants.Arrow);

                //var leftDrawLabel = new CogDrawLabelInfo();
                //    leftDrawLabel.FontSize = 12;
                //    leftDrawLabel.UseBackColor = true;
                //    leftDrawLabel.Color = Cognex.VisionPro.CogColorConstants.Purple;
                //    leftDrawLabel.BackColor = Cognex.VisionPro.CogColorConstants.White;
                //    leftDrawLabel.Alignment = Cognex.VisionPro.CogGraphicLabelAlignmentConstants.BaselineLeft;
                //    leftDrawLabel.Style = System.Drawing.FontStyle.Bold;
                //    leftDrawLabel.Offset = new XY(left.Edge1.PositionX, left.Edge1.PositionY) + new XY(0, 10);
                //    leftDrawLabel.Text = string.Format("{0:F3} mm", dist_0);
                //var rightDrawLabel = new CogDrawLabelInfo();
                //    rightDrawLabel.FontSize = 12;
                //    rightDrawLabel.UseBackColor = true;
                //    rightDrawLabel.Color = Cognex.VisionPro.CogColorConstants.Purple;
                //    rightDrawLabel.BackColor = Cognex.VisionPro.CogColorConstants.White;
                //    rightDrawLabel.Alignment = Cognex.VisionPro.CogGraphicLabelAlignmentConstants.BottomLeft;
                //    rightDrawLabel.Style = System.Drawing.FontStyle.Bold;
                //    rightDrawLabel.Offset = new XY(right.Edge1.PositionX, right.Edge1.PositionY) + new XY(0, 10);
                //    rightDrawLabel.Text = string.Format("{0:F3} mm", dist_1);
                var uppwerDrawLabel = new CogDrawLabelInfo();
                    uppwerDrawLabel.FontSize = 12;
                    uppwerDrawLabel.UseBackColor = true;
                    uppwerDrawLabel.Color = Cognex.VisionPro.CogColorConstants.Purple;
                    uppwerDrawLabel.BackColor = Cognex.VisionPro.CogColorConstants.White;
                    uppwerDrawLabel.Alignment = Cognex.VisionPro.CogGraphicLabelAlignmentConstants.TopLeft;
                    uppwerDrawLabel.Style = System.Drawing.FontStyle.Bold;
                    uppwerDrawLabel.Offset = new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y) + new XY(0, -50);
                    uppwerDrawLabel.Text = string.Format("{0:F3} mm", RbtUpperDist);
                var lowerDrawLabel = new CogDrawLabelInfo();
                    lowerDrawLabel.FontSize = 12;
                    lowerDrawLabel.UseBackColor = true;
                    lowerDrawLabel.Color = Cognex.VisionPro.CogColorConstants.Purple;
                    lowerDrawLabel.BackColor = Cognex.VisionPro.CogColorConstants.White;
                    lowerDrawLabel.Alignment = Cognex.VisionPro.CogGraphicLabelAlignmentConstants.TopRight;
                    lowerDrawLabel.Style = System.Drawing.FontStyle.Bold;
                    lowerDrawLabel.Offset = new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y) + new XY(0, -50);
                    lowerDrawLabel.Text = string.Format("{0:F3} mm", RbtLowerDist);

                //dsp.DrawLine(leftDrawLine);
                //dsp.DrawLine(rightDrawLine);
                dsp.DrawLine(upperDrawLine);
                dsp.DrawLine(lowerDrawLine);
                //dsp.DrawLabel(leftDrawLabel);
                //dsp.DrawLabel(rightDrawLabel);
                dsp.DrawLabel(uppwerDrawLabel);
                dsp.DrawLabel(lowerDrawLabel);
                #endregion



                //string msg = string.Format("[{0}], {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}", DateTime.Now ,Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y, Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y, upperPLTool.LineX, upperPLTool.LineY, lowerPLTool.LineX, lowerPLTool.LineY);
                //WriteFileLog(msg);




                //if (measureResult && !CheckLength(tarLength, (double)mparam.TargetLength.Value, (double)mparam.LCheckTolerance.Value))
                //{
                //    ErrorCode = AlgoActionBase.Err_Upper_Length_Check;// error -> errorstate
                //    Display.Judgement = (uint)Judgement.L_Check;
                //    measureResult = false;
                //}

                //// object length
                //if (measureResult && !CheckLength(objLength, (double)mparam.ObjectLength.Value, (double)mparam.LCheckTolerance.Value))
                //{
                //    ErrorCode = AlgoActionBase.Err_Lower_Length_Check;// error -> errorstate
                //    Display.Judgement = (uint)Judgement.L_Check;
                //    measureResult = false;
                //}

                //// 5-2. check angle
                //if(measureResult && Math.Abs( tarAngle - objAngle) > (double)mparam.AngleTolerance.Value)
                //{
                //    ErrorCode = AlgoActionBase.Err_Angle_Tolerance_Exceeded;// error -> errorstate
                //    Display.Judgement = (uint)Judgement.Tor_Exceed;
                //    measureResult = false;
                //}

                //// 5-3. judgement
                //if (measureResult &&
                //    (!CheckLength(ly, (double)mparam.DistLy.Value, (double)mparam.DistTolerence.Value)
                //    || !CheckLength(ry, (double)mparam.DistRy.Value, (double)mparam.DistTolerence.Value)))
                //{
                //    ErrorCode = AlgoActionBase.Err_Inspection_Spec_Over;//warning -> result NG + Comp
                //    Display.Judgement = (uint)Judgement.NG;
                //    measureResult = false;
                //}

                // 6. ResultAlgoAlignResult
                var now = DateTime.Now;
                AlgoRst = new AlgoAlignResult()
                {
                    Name = this.Name,
                    ID = this.SourceID,
                    CurDate = now.ToString("yyyy-MM-dd"),
                    CurTime = now.ToString("HH:mm:ss"),
                    Work = Idx.ToString(),

                    Result = lastJudge ? "OK" : $"NG - {SystemInfo.GetErrorInfo(ErrorCode).Title}",
                    Judgement = lastJudge,

                    T1X = Math.Round(Mark_Obj1.OutputXYT.X,3),
                    T1Y = Math.Round(Mark_Obj1.OutputXYT.Y,3),
                    T2X = Math.Round(Mark_Obj2.OutputXYT.X,3),
                    T2Y = Math.Round(Mark_Obj2.OutputXYT.Y,3),

                    O1X = Math.Round(upperPLTool.LineX, 3),
                    O1Y = Math.Round(upperPLTool.LineY,3),
                    O2X = Math.Round(lowerPLTool.LineX,3),
                    O2Y = Math.Round(lowerPLTool.LineY,3),

                    Lx = Math.Round(RbtLowerDist, 3),
                    //Ly = Math.Round(dist_0, 3),
                    Rx = Math.Round(RbtUpperDist, 3),
                    //Ry = Math.Round(dist_1, 3),
                };

                GridViewObject.SetResult(AlgoRst);
                SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

                // 8. PLC Data 쓰기
                SetVisionValues(AlgoRst);

                // 9. 마무리 작업 : 결과값 화면(display) 표시
                //Task.Factory.StartNew(() => { DrawResult(AlgoRst, mparam); });

                return lastJudge;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return lastJudge;
                //return false;
            }
        }
    }

    #region Parameters
    [SerializableAttribute]
    public class AlgoMeasureInspectModelParams : AlgoParams
    {
        #region L-Check
        //private AlgoParam _tarLength = new AlgoParam(nameof(TargetLength), "mm", typeof(double), 80.0, "Target Length Spec", 0.1, 1000.0);
        //public AlgoParam TargetLength
        //{
        //    get { return _tarLength; }
        //    set { Set<AlgoParam>(ref _tarLength, value, nameof(TargetLength)); }
        //}

        //private AlgoParam _objLength = new AlgoParam(nameof(ObjectLength), "mm", typeof(double), 80.0, "Object Length", 0.1, 1000.0);
        //public AlgoParam ObjectLength
        //{
        //    get { return _objLength; }
        //    set { Set<AlgoParam>(ref _objLength, value, nameof(ObjectLength)); }
        //}

        //private AlgoParam _lCheckTolerance = new AlgoParam(nameof(LCheckTolerance), "mm", typeof(double), 0.05, "L-Check Tolerence", 0.0, 1.0);
        //public AlgoParam LCheckTolerance
        //{
        //    get { return _lCheckTolerance; }
        //    set { Set<AlgoParam>(ref _lCheckTolerance, value, nameof(LCheckTolerance)); }
        //}
        #endregion

        #region Angle
        //private AlgoParam _angleTolerance = new AlgoParam(nameof(AngleTolerance), "deg", typeof(double), 1.0, "Angle Tolerence", 0.0, 5.0);
        //public AlgoParam AngleTolerance
        //{
        //    get { return _angleTolerance; }
        //    set { Set<AlgoParam>(ref _angleTolerance, value, nameof(AngleTolerance)); }
        //}
        #endregion

        #region Judgement
        private AlgoParam _distLx = new AlgoParam(nameof(DistLx), "mm", typeof(double), 1.0, "base distance of left side x", 0.0, 5.0);
        public AlgoParam DistLx
        {
            get { return _distLx; }
            set { Set<AlgoParam>(ref _distLx, value, nameof(DistLx)); }
        }

        private AlgoParam _distLy = new AlgoParam(nameof(DistLy), "mm", typeof(double), 1.0, "base distance of left side y", 0.0, 5.0);
        public AlgoParam DistLy
        {
            get { return _distLy; }
            set { Set<AlgoParam>(ref _distLy, value, nameof(DistLy)); }
        }

        private AlgoParam _distRx = new AlgoParam(nameof(DistRx), "mm", typeof(double), 1.0, "base distance of right side x", 0.0, 5.0);
        public AlgoParam DistRx
        {
            get { return _distRx; }
            set { Set<AlgoParam>(ref _distRx, value, nameof(DistRx)); }
        }

        private AlgoParam _distRy = new AlgoParam(nameof(DistRy), "mm", typeof(double), 1.0, "base distance of right side y", 0.0, 5.0);
        public AlgoParam DistRy
        {
            get { return _distRy; }
            set { Set<AlgoParam>(ref _distRy, value, nameof(DistRy)); }
        }

        private AlgoParam _distTol = new AlgoParam(nameof(DistTolerence), "mm", typeof(double), 0.1, "base distance of right side", 0.0, 1.0);
        public AlgoParam DistTolerence
        {
            get { return _distTol; }
            set { Set<AlgoParam>(ref _distTol, value, nameof(DistTolerence)); }
        }
        #endregion
    }

    public class AlgoMeasureInspectInputParams : InputParams
    {
        public IPointResult Target1 { get; set; }
        public IPointResult Target2 { get; set; }
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoMeasurementInspectResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion
        public string Result { get; set; }// ok, ng - reason

        #region ToolResult
        public double ScoreT1 { get; set; }// target1 matching score
        public double ScoreT2 { get; set; }// target2 matching score
        public double ScoreO1 { get; set; }// object1 matching score
        public double ScoreO2 { get; set; }// object2 matching score
        #endregion

        #region Measurement
        public double TarLen { get; set; }
        public double TarAngle { get; set; }
        public double ObjLen { get; set; }
        public double ObjAngle { get; set; }
        
        public double DistLx { get; set; }
        public double DistLy { get; set; }
        public double DistRx { get; set; }
        public double DistRy { get; set; }
        #endregion
    }
    #endregion
}
