﻿using Cognex.VisionPro;
using Cognex.VisionPro.Dimensioning;
using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.MultiIndexScheduler;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    public partial class AlgoAutoConnectingObject
    {
        #region local field for measure
        XYXY inspMarkResult = new XYXY();
        XY leftCrossPoint = new XY();
        XY rightCrossPoint = new XY();
        private XYT crossPoint_L = new XYT();
        private XYT crossPoint_R = new XYT();
        #endregion

        AlgoMeasureInspectMarkModelParams mInspectionMarkParams;
        private bool InspectionInsertMark(WorkIndex Idx)
        {
            try
            {
                // 1. Model Param 가져오기
                var model = SystemModel.GetCurModel();
                if (!ModelParams.ContainsKey(model))
                {
                    ErrorCode = AlgoActionBase.Err_ModelData_Info_Missing;
                    Display.Judgement = (uint)Judgement.Fail;
                    return false;
                }


                // 2. Input Param 가져오기 : mark
                var Mark_Tar1 = InputValues[Key.TARGET1] as IPointResult;
                var Mark_Tar2 = InputValues[Key.TARGET2] as IPointResult;
                var Mark_Obj1 = InputValues[Key.OBJECT1] as IPointResult;
                var Mark_Obj2 = InputValues[Key.OBJECT2] as IPointResult;

                if (Mark_Tar1 == null || Mark_Tar2 == null || Mark_Obj1 == null || Mark_Obj2 == null)
                {
                    // Mark Data가 Null임
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }


                // 3. 실제 좌표로 변환
                AlgoParams modelParams;
                if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                mInspectionMarkParams = modelParams as AlgoMeasureInspectMarkModelParams;
                double distLx = (double)mInspectionMarkParams.DistLx.Value;
                double distLy = (double)mInspectionMarkParams.DistLy.Value;
                double distRx = (double)mInspectionMarkParams.DistRx.Value;
                double distRy = (double)mInspectionMarkParams.DistRy.Value;
                double distTor = (double)mInspectionMarkParams.DistTolerence.Value;

                lastJudge = true;

                var Tar_P1 = new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y);
                var Tar_P2 = new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y);
                var Obj_P1 = new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y);
                var Obj_P2 = new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y);

                var Rbt_Tar_P1 = Calib.GetV2R(model, Tar_P1);
                var Rbt_Tar_P2 = Calib.GetV2R(model, Tar_P2);
                var Rbt_Obj_P1 = Calib.GetV2R(model, Obj_P1);
                var Rbt_Obj_P2 = Calib.GetV2R(model, Obj_P2);

                XY RotCent1 = Calib.GetRotateCenter(model);
                XY RotCent2 = Calib.GetRotateCenter(model);

                var Coord_Tar1 = Rbt_Tar_P1 + RotCent1;
                var Coord_Tar2 = Rbt_Tar_P2 + RotCent2;
                var Coord_Obj1 = Rbt_Obj_P1 + RotCent1;
                var Coord_Obj2 = Rbt_Obj_P2 + RotCent2;

                inspMarkResult = new XYXY();
                inspMarkResult.Lx = GetDotDistance(Coord_Obj1, Coord_Tar1, Coord_Tar2);
                inspMarkResult.Ly = GetCrossDistance(Coord_Obj1, Coord_Tar1, Coord_Tar2);
                inspMarkResult.Rx = GetDotDistance(Coord_Obj2, Coord_Tar2, Coord_Tar1);
                inspMarkResult.Ry = GetCrossDistance(Coord_Obj2, Coord_Tar2, Coord_Tar1);

                leftCrossPoint = new XY();
                rightCrossPoint = new XY();
                leftCrossPoint = GetCrossPoint(Coord_Obj1, Coord_Tar1, Coord_Tar2) - Calib.GetRotateCenter(model);
                crossPoint_L = Calib.GetR2V(model, leftCrossPoint);
                rightCrossPoint = GetCrossPoint(Coord_Obj2, Coord_Tar2, Coord_Tar1) - Calib.GetRotateCenter(model);
                crossPoint_R = Calib.GetR2V(model, rightCrossPoint);

                if (!CheckSpec(inspMarkResult.Ly, distLy, distTor) || !CheckSpec(inspMarkResult.Ry, distRy, distTor) ||
                    !CheckSpec(inspMarkResult.Lx, distLx, distTor) || !CheckSpec(inspMarkResult.Rx, distRx, distTor))
                {
                    Display.Judgement = (uint)Judgement.Warning;
                    errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                    lastJudge = false;
                    WriteLog(MsgType.Important, string.Format("{0}", AlgoActionBase.E15030_Retry_Spec_Over));
                }
                else
                {
                    lastJudge = true;
                }



                #region Draw Line, Label
                var lxDrawLine = new CogDrawLineInfo(
                   new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y),
                   new XY(crossPoint_L.X, crossPoint_L.Y),
                   2,
                   CogColorConstants.Orange,
                   CogLineSegmentAdornmentConstants.Arrow,
                   CogLineSegmentAdornmentConstants.Arrow);
                var rxDrawLine = new CogDrawLineInfo(
                    new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y),
                    new XY(crossPoint_R.X, crossPoint_R.Y),
                    2,
                    CogColorConstants.Orange,
                    CogLineSegmentAdornmentConstants.Arrow,
                    CogLineSegmentAdornmentConstants.Arrow);
                var lyDrawLine = new CogDrawLineInfo(
                    new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y),
                    new XY(crossPoint_L.X, crossPoint_L.Y),
                    2,
                    CogColorConstants.Orange,
                    CogLineSegmentAdornmentConstants.Arrow,
                    CogLineSegmentAdornmentConstants.Arrow);
                var ryDrawLine = new CogDrawLineInfo(
                    new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y),
                    new XY(crossPoint_R.X, crossPoint_R.Y),
                    2,
                    CogColorConstants.Orange,
                    CogLineSegmentAdornmentConstants.Arrow,
                    CogLineSegmentAdornmentConstants.Arrow);

                var lxDrawLabel = new CogDrawLabelInfo();
                    lxDrawLabel.FontSize = 12;
                    lxDrawLabel.UseBackColor = true;
                    lxDrawLabel.Color = CogColorConstants.Purple;
                    lxDrawLabel.BackColor = CogColorConstants.White;
                    lxDrawLabel.Alignment = CogGraphicLabelAlignmentConstants.TopRight;
                    lxDrawLabel.Style = System.Drawing.FontStyle.Bold;
                    lxDrawLabel.Offset = new XY(Tar_P1) + new XY(0, 10);
                    lxDrawLabel.Text = string.Format("{0:F3} mm", inspMarkResult.Lx);
                var rxDrawLabel = new CogDrawLabelInfo();
                    rxDrawLabel.FontSize = 12;
                    rxDrawLabel.UseBackColor = true;
                    rxDrawLabel.Color = CogColorConstants.Purple;
                    rxDrawLabel.BackColor = CogColorConstants.White;
                    rxDrawLabel.Alignment = CogGraphicLabelAlignmentConstants.TopLeft;
                    rxDrawLabel.Style = System.Drawing.FontStyle.Bold;
                    rxDrawLabel.Offset = new XY(Tar_P2) + new XY(0, 10);
                    rxDrawLabel.Text = string.Format("{0:F3} mm", inspMarkResult.Rx);
                var lyDrawLabel = new CogDrawLabelInfo();
                    lyDrawLabel.FontSize = 12;
                    lyDrawLabel.UseBackColor = true;
                    lyDrawLabel.Color = CogColorConstants.Purple;
                    lyDrawLabel.BackColor = CogColorConstants.White;
                    lyDrawLabel.Alignment = CogGraphicLabelAlignmentConstants.BottomLeft;
                    lyDrawLabel.Style = System.Drawing.FontStyle.Bold;
                    lyDrawLabel.Offset = new XY(Obj_P1) + new XY(0, 10);
                    lyDrawLabel.Text = string.Format("{0:F3} mm", inspMarkResult.Ly);
                var ryDrawLabel = new CogDrawLabelInfo();
                    ryDrawLabel.FontSize = 12;
                    ryDrawLabel.UseBackColor = true;
                    ryDrawLabel.Color = CogColorConstants.Purple;
                    ryDrawLabel.BackColor = CogColorConstants.White;
                    ryDrawLabel.Alignment = CogGraphicLabelAlignmentConstants.BottomRight;
                    ryDrawLabel.Style = System.Drawing.FontStyle.Bold;
                    ryDrawLabel.Offset = new XY(Obj_P2) + new XY(0, 10);
                    ryDrawLabel.Text = string.Format("{0:F3} mm", inspMarkResult.Ry);

                Display.DrawLine(ryDrawLine);
                Display.DrawLine(lyDrawLine);
                Display.DrawLine(rxDrawLine);
                Display.DrawLine(lxDrawLine);
                Display.DrawLabel(ryDrawLabel);
                Display.DrawLabel(lyDrawLabel);
                Display.DrawLabel(rxDrawLabel);
                Display.DrawLabel(lxDrawLabel);
                #endregion



                //string msg = string.Format("[{0}], {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}", DateTime.Now ,Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y, Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y, upperPLTool.LineX, upperPLTool.LineY, lowerPLTool.LineX, lowerPLTool.LineY);
                //WriteFileLog(msg);




                //if (measureResult && !CheckLength(tarLength, (double)mparam.TargetLength.Value, (double)mparam.LCheckTolerance.Value))
                //{
                //    ErrorCode = AlgoActionBase.Err_Upper_Length_Check;// error -> errorstate
                //    Display.Judgement = (uint)Judgement.L_Check;
                //    measureResult = false;
                //}

                //// object length
                //if (measureResult && !CheckLength(objLength, (double)mparam.ObjectLength.Value, (double)mparam.LCheckTolerance.Value))
                //{
                //    ErrorCode = AlgoActionBase.Err_Lower_Length_Check;// error -> errorstate
                //    Display.Judgement = (uint)Judgement.L_Check;
                //    measureResult = false;
                //}

                //// 5-2. check angle
                //if(measureResult && Math.Abs( tarAngle - objAngle) > (double)mparam.AngleTolerance.Value)
                //{
                //    ErrorCode = AlgoActionBase.Err_Angle_Tolerance_Exceeded;// error -> errorstate
                //    Display.Judgement = (uint)Judgement.Tor_Exceed;
                //    measureResult = false;
                //}

                //// 5-3. judgement
                //if (measureResult &&
                //    (!CheckLength(ly, (double)mparam.DistLy.Value, (double)mparam.DistTolerence.Value)
                //    || !CheckLength(ry, (double)mparam.DistRy.Value, (double)mparam.DistTolerence.Value)))
                //{
                //    ErrorCode = AlgoActionBase.Err_Inspection_Spec_Over;//warning -> result NG + Comp
                //    Display.Judgement = (uint)Judgement.NG;
                //    measureResult = false;
                //}

                var mparam = ModelParams[model] as AlgoMeasureInspectMarkModelParams;

                // 6. ResultAlgoAlignResult
                var now = DateTime.Now;
                AlgoRst = new AlgoAlignResult()
                {
                    Name = this.Name,
                    ID = this.SourceID,
                    CurDate = now.ToString("yyyy-MM-dd"),
                    CurTime = now.ToString("HH:mm:ss"),
                    Work = Idx.ToString(),

                    Result = lastJudge ? "OK" : $"NG - {SystemInfo.GetErrorInfo(ErrorCode).Title}",
                    Judgement = lastJudge,

                    T1X = Math.Round(Mark_Tar1.OutputXYT.X,3),
                    T1Y = Math.Round(Mark_Tar1.OutputXYT.Y,3),
                    T2X = Math.Round(Mark_Tar2.OutputXYT.X,3),
                    T2Y = Math.Round(Mark_Tar2.OutputXYT.Y,3),

                    O1X = Math.Round(Mark_Obj1.OutputXYT.X,3),
                    O1Y = Math.Round(Mark_Obj1.OutputXYT.Y,3),
                    O2X = Math.Round(Mark_Obj2.OutputXYT.X,3),
                    O2Y = Math.Round(Mark_Obj2.OutputXYT.Y, 3),

                    Lx = Math.Round(inspMarkResult.Lx, 3),
                    Ly = Math.Round(inspMarkResult.Ly, 3),
                    Rx = Math.Round(inspMarkResult.Rx, 3),
                    Ry = Math.Round(inspMarkResult.Ry, 3),
                };

                GridViewObject.SetResult(AlgoRst);
                SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

                // 8. PLC Data 쓰기
                SetVisionValues(AlgoRst);

                // 9. 마무리 작업 : 결과값 화면(display) 표시
                //Task.Factory.StartNew(() => { DrawResult(AlgoRst, mparam); });

                return lastJudge;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }
    }

    #region Parameters
    [SerializableAttribute]
    public class AlgoMeasureInspectMarkModelParams : AlgoParams
    {
        #region L-Check
        //private AlgoParam _tarLength = new AlgoParam(nameof(TargetLength), "mm", typeof(double), 80.0, "Target Length Spec", 0.1, 1000.0);
        //public AlgoParam TargetLength
        //{
        //    get { return _tarLength; }
        //    set { Set<AlgoParam>(ref _tarLength, value, nameof(TargetLength)); }
        //}

        //private AlgoParam _objLength = new AlgoParam(nameof(ObjectLength), "mm", typeof(double), 80.0, "Object Length", 0.1, 1000.0);
        //public AlgoParam ObjectLength
        //{
        //    get { return _objLength; }
        //    set { Set<AlgoParam>(ref _objLength, value, nameof(ObjectLength)); }
        //}

        //private AlgoParam _lCheckTolerance = new AlgoParam(nameof(LCheckTolerance), "mm", typeof(double), 0.05, "L-Check Tolerence", 0.0, 1.0);
        //public AlgoParam LCheckTolerance
        //{
        //    get { return _lCheckTolerance; }
        //    set { Set<AlgoParam>(ref _lCheckTolerance, value, nameof(LCheckTolerance)); }
        //}
        #endregion

        #region Angle
        //private AlgoParam _angleTolerance = new AlgoParam(nameof(AngleTolerance), "deg", typeof(double), 1.0, "Angle Tolerence", 0.0, 5.0);
        //public AlgoParam AngleTolerance
        //{
        //    get { return _angleTolerance; }
        //    set { Set<AlgoParam>(ref _angleTolerance, value, nameof(AngleTolerance)); }
        //}
        #endregion

        #region Judgement
        private AlgoParam _distLx = new AlgoParam(nameof(DistLx), "mm", typeof(double), 1.0, "base distance of left side x", 0.0, 5.0);
        public AlgoParam DistLx
        {
            get { return _distLx; }
            set { Set<AlgoParam>(ref _distLx, value, nameof(DistLx)); }
        }

        private AlgoParam _distLy = new AlgoParam(nameof(DistLy), "mm", typeof(double), 1.0, "base distance of left side y", 0.0, 5.0);
        public AlgoParam DistLy
        {
            get { return _distLy; }
            set { Set<AlgoParam>(ref _distLy, value, nameof(DistLy)); }
        }

        private AlgoParam _distRx = new AlgoParam(nameof(DistRx), "mm", typeof(double), 1.0, "base distance of right side x", 0.0, 5.0);
        public AlgoParam DistRx
        {
            get { return _distRx; }
            set { Set<AlgoParam>(ref _distRx, value, nameof(DistRx)); }
        }

        private AlgoParam _distRy = new AlgoParam(nameof(DistRy), "mm", typeof(double), 1.0, "base distance of right side y", 0.0, 5.0);
        public AlgoParam DistRy
        {
            get { return _distRy; }
            set { Set<AlgoParam>(ref _distRy, value, nameof(DistRy)); }
        }

        private AlgoParam _distTol = new AlgoParam(nameof(DistTolerence), "mm", typeof(double), 0.1, "base distance of right side", 0.0, 1.0);
        public AlgoParam DistTolerence
        {
            get { return _distTol; }
            set { Set<AlgoParam>(ref _distTol, value, nameof(DistTolerence)); }
        }
        #endregion
    }
    
    public class AlgoMeasureInspectMarkInputParams : InputParams
    {
        public IPointResult Target1 { get; set; }
        public IPointResult Target2 { get; set; }
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoMeasurementInspectMarkResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion
        public string Result { get; set; }// ok, ng - reason

        #region ToolResult
        public double ScoreT1 { get; set; }// target1 matching score
        public double ScoreT2 { get; set; }// target2 matching score
        public double ScoreO1 { get; set; }// object1 matching score
        public double ScoreO2 { get; set; }// object2 matching score
        #endregion

        #region Measurement
        public double TarLen { get; set; }
        public double TarAngle { get; set; }
        public double ObjLen { get; set; }
        public double ObjAngle { get; set; }
        
        public double DistLx { get; set; }
        public double DistLy { get; set; }
        public double DistRx { get; set; }
        public double DistRy { get; set; }
        #endregion
    }
    #endregion
}
