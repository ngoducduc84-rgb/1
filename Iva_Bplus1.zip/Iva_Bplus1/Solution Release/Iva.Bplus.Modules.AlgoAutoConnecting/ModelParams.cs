﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    [SerializableAttribute]

    public partial class TarObjModelParams : AlgoParams
    {
        //2P
        //private AlgoParam limitX;
        //private AlgoParam limitY;
        //private AlgoParam limitT;

        //private AlgoParam spec_Length_Target;
        //private AlgoParam tor_Length_Target;
        //private AlgoParam spec_Length_Object;
        //private AlgoParam tor_Length_Object;

        // Distance Lx, Ly, Rx, Ry : Mark To Mark 거리임.
        private AlgoParam spec_Lx;
        private AlgoParam spec_Ly;
        private AlgoParam spec_Rx;
        private AlgoParam spec_Ry;

        // Range X,Y : Distance +- Range, Min Max임.
        private AlgoParam tor_X;
        private AlgoParam tor_Y;
        private AlgoParam tor_T;
        //private AlgoParam tor_Ry;

        //private AlgoParam last_offsetX;
        private AlgoParam last_offsetY;
        //private AlgoParam last_offsetT;


        //public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        //public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        //public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }

        //public AlgoParam Spec_Length_Target { get { return spec_Length_Target; } set { if (spec_Length_Target == value) return; spec_Length_Target = value; this.OnPropertyChanged(nameof(Spec_Length_Target)); } }
        //public AlgoParam Tor_Length_Target { get { return tor_Length_Target; } set { if (tor_Length_Target == value) return; tor_Length_Target = value; this.OnPropertyChanged(nameof(Tor_Length_Target)); } }
        //public AlgoParam Spec_Length_Object { get { return spec_Length_Object; } set { if (spec_Length_Object == value) return; spec_Length_Object = value; this.OnPropertyChanged(nameof(Spec_Length_Object)); } }
        //public AlgoParam Tor_Length_Object { get { return tor_Length_Object; } set { if (tor_Length_Object == value) return; tor_Length_Object = value; this.OnPropertyChanged(nameof(Tor_Length_Object)); } }

        public AlgoParam Spec_Lx { get { return spec_Lx; } set { if (spec_Lx == value) return; spec_Lx = value; this.OnPropertyChanged(nameof(Spec_Lx)); } }
        public AlgoParam Spec_Ly { get { return spec_Ly; } set { if (spec_Ly == value) return; spec_Ly = value; this.OnPropertyChanged(nameof(Spec_Ly)); } }
        public AlgoParam Spec_Rx { get { return spec_Rx; } set { if (spec_Rx == value) return; spec_Rx = value; this.OnPropertyChanged(nameof(Spec_Rx)); } }
        public AlgoParam Spec_Ry { get { return spec_Ry; } set { if (spec_Ry == value) return; spec_Ry = value; this.OnPropertyChanged(nameof(Spec_Ry)); } }

        public AlgoParam Tor_X { get { return tor_X; } set { if (tor_X == value) return; tor_X = value; this.OnPropertyChanged(nameof(Tor_X)); } }
        public AlgoParam Tor_Y { get { return tor_Y; } set { if (tor_Y == value) return; tor_Y = value; this.OnPropertyChanged(nameof(Tor_Y)); } }
        public AlgoParam Tor_T { get { return tor_T; } set { if (tor_T == value) return; tor_T = value; this.OnPropertyChanged(nameof(Tor_T)); } }
        //public AlgoParam Tor_Ry { get { return tor_Ry; } set { if (tor_Ry == value) return; tor_Ry = value; this.OnPropertyChanged(nameof(Tor_Ry)); } }

        //public AlgoParam Last_offsetX { get { return last_offsetX; } set { if (last_offsetX == value) return; last_offsetX = value; this.OnPropertyChanged(nameof(Last_offsetX)); } }
        public AlgoParam Last_offsetY { get { return last_offsetY; } set { if (last_offsetY == value) return; last_offsetY = value; this.OnPropertyChanged(nameof(Last_offsetY)); } }
        //public AlgoParam Last_offsetT { get { return last_offsetT; } set { if (last_offsetT == value) return; last_offsetT = value; this.OnPropertyChanged(nameof(Last_offsetT)); } }

        public TarObjModelParams()
            : base()
        {

            //LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            //LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            //LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);

            //Spec_Length_Target = new AlgoParam("Spec_Length_Target", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)1000);
            //Tor_Length_Target = new AlgoParam("Tor_Length_Target", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)2);
            //Spec_Length_Object = new AlgoParam("Spec_Length_Object", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)1000);
            //Tor_Length_Object = new AlgoParam("Tor_Length_Object", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)2);

            Spec_Lx = new AlgoParam("Spec_Lx", "mm", typeof(double), 0.0, "Attach Spec_Lx", (double)-100, (double)100.0);
            Spec_Ly = new AlgoParam("Spec_Ly", "mm", typeof(double), 0.0, "Attach Spec_Ly", (double)-100, (double)100.0);
            Spec_Rx = new AlgoParam("Spec_Rx", "mm", typeof(double), 0.0, "Attach Spec_Rx", (double)-100, (double)100.0);
            Spec_Ry = new AlgoParam("Spec_Ry", "mm", typeof(double), 0.0, "Attach Spec_Ry", (double)-100, (double)100.0);


            Tor_X = new AlgoParam("Tor_X", "mm", typeof(double),0.0, "Position Spec Tor_X", (double)0.0, (double)1);
            Tor_Y = new AlgoParam("Tor_Y", "mm", typeof(double),0.0, "Position Spec Tor_Y", (double)0.0, (double)1);
            Tor_T = new AlgoParam("Tor_T", "mm", typeof(double),0.0, "Position Spec Tor_T", (double)0.0, (double)1);
            //Tor_Ry = new AlgoParam("Tor_Ry", "mm", typeof(double),0.0, "Position Spec Tor_Ry", (double)0.0, (double)1);

            //Last_offsetX = new AlgoParam("Last_offsetX", "mm", typeof(double), 0.0, "Insert Last_offset X", (double)0.0, (double)10);
            Last_offsetY = new AlgoParam("Last_offsetY", "mm", typeof(double), 0.0, "Insert Last_offset Y", (double)0.0, (double)10);
            //Last_offsetT = new AlgoParam("Last_offsetT", "mm", typeof(double), 0.0, "Insert Last_offset T", (double)0.0, (double)10);
        }
    }
}
