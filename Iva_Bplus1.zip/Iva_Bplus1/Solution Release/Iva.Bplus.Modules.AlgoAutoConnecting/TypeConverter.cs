﻿using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.GridViewDisplay;
using Iva.Bplus.Modules.CogDisplay;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Iva.Bplus.Modules.InspectionChart;

namespace Iva.Bplus.Modules.AlgoAutoConnecting
{
    public class CalDataListConverter : TypeConverter
    {
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Common.GetEachObjectName(typeof(CalDataObject)));
        }
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }
    }

    public class CogDispListConverter : TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Display.GetEachObjectName(typeof(CogDisplayObject)));
        }
    }
    public class GridViewListConverter : System.ComponentModel.TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Display.GetEachObjectName(typeof(GridViewDisplayObject)));
        }
    }

    public class ChartListConverter : System.ComponentModel.TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Display.GetEachObjectName(typeof(InspectionChartObject)));
        }
    }
}
