﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.AlgoBlobInspect;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;
using Iva.Bplus.Modules.CogDisplay;

namespace Iva.Bplus.Modules.AlgoBlobInspect
{
    [SerializableAttribute]
    public partial class AlgoBlobInspectAction : AlgoActionBase
    {
        #region [Fields]     
        #endregion

        #region [Properties]   
        #endregion

        #region [Construct]
        public AlgoBlobInspectAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new AlgoBlobInspectInputParams();
            OutputParams = new AlgoBlobInspectOutputParams();

            var obj = _object as AlgoBlobInspectObject;
            obj.ModelParamType = typeof(AlgoBlobInspectAlignModelParams);
            var param = obj.CurParams as AlgoBlobInspectAlignModelParams;
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as AlgoBlobInspectObject;

            CogDisplayObject cogDsp = Obj.P1_DisplayObj as CogDisplayObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                if (!Obj.Run())
                {
                    //191008 JSH
                    cogDsp.Judgement = (uint)Judgement.NG;

                    // 기존값들 초기화 필요함.
                    SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);

                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    return OccurError(Obj.ErrorCode, true);
                }
                else
                {
                    SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                    Obj.AppendMessage(Name, "Inspection Complete");
                }

                #endregion
                StopTimer();

            }

            return End(false);
        }
        public override void PrepareSave() { base.PrepareSave(); }
        public override void Dispose() { base.Dispose(); }
        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion



    }
}
