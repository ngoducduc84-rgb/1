﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;

namespace Iva.Bplus.Modules.AlgoBlobInspect
{
    [SerializableAttribute]
    class AlgoBlobInspectInputParams : InputParams
    {
        #region Inputs
        public Dictionary<string, object> Inputs { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
