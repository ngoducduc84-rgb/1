﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.AlgoBlobInspect
{
    [SerializableAttribute]

    public partial class AlgoBlobInspectAlignModelParams : AlgoParams
    {
        private AlgoParam areaRate1;
        private AlgoParam areaRate2;
        private AlgoParam areaRate3;
        
        public AlgoParam AreaRate1 { get { return areaRate1; } set { if (areaRate1 == value) return; areaRate1 = value; this.OnPropertyChanged(nameof(AreaRate1)); } }
        public AlgoParam AreaRate2 { get { return areaRate2; } set { if (areaRate2 == value) return; areaRate2 = value; this.OnPropertyChanged(nameof(AreaRate2)); } }
        public AlgoParam AreaRate3 { get { return areaRate3; } set { if (areaRate3 == value) return; areaRate3 = value; this.OnPropertyChanged(nameof(AreaRate3)); } }


        public AlgoBlobInspectAlignModelParams()
            : base()
        {
            AreaRate1 = new AlgoParam("AreaRate1", "%", typeof(double), 0.0, "Blob or Hole Total Area ", (double)0, (double)1);
            AreaRate2 = new AlgoParam("AreaRate2", "%", typeof(double), 0.0, "Blob or Hole Total Area ", (double)0, (double)1);
            AreaRate3 = new AlgoParam("AreaRate3", "%", typeof(double), 0.0, "Blob or Hole Total Area ", (double)0, (double)1);
        }
    }
}
