﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Cognex.VisionPro.ToolBlock;
using Cognex.VisionPro.Blob;
using Cognex.VisionPro;

using System.Diagnostics;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.AlgoBlobInspect
{
    [SerializableAttribute]
    public partial class AlgoBlobInspectObject : AlgoObjectBase
    {
        #region [Fields]
        private CogBlobLabelConstants checkLabel = CogBlobLabelConstants.Hole;
        //2019.10.11 JSH Image 판정 오류 추가
        private string p1_Display;
        #endregion

        #region [properties]
        public CogBlobLabelConstants CheckLabel
        {
            get { return checkLabel; }
            set { if (checkLabel == value) return; checkLabel = value; this.OnPropertyChanged(nameof(CheckLabel)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }
        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }
        #endregion

        #region[Construct]
        public AlgoBlobInspectObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new AlgoBlobInspectAlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return Inspection(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool Inspection()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근 // 사실상 Cell ID 또는 옵션만 가져오면 되나 귀찮으니 걍 업데이트
            #endregion

            #region InputData Data Read& Confirm
            // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
            if (!InputValues.ContainsKey("Inputs"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            var Inputs = InputValues["Inputs"] as Dictionary<string, object>;

            if (Inputs == null)
            {
                // InputData Data가 Null임
                errorCode = AlgoActionBase.Err_InputData_Info_Missing;
                return false;
            }

            //갯수,이름 상관없이 Blob데이터 확인
            List<string> listInputKey = new List<string>(Inputs.Keys);

            int nInputCount = listInputKey.Count;

            for (int i = 0; i < nInputCount; i++)
            {
                string name = listInputKey[i];

                if (!(Inputs[name] is CogBlobResults))
                {
                    Inputs.Remove(name);
                    //errorCode = AlgoBlobInspectAction.Err_InputData_Type_Missing;
                    //return false;
                }
            }
            /////////

            //if (!Inputs.ContainsKey("Results") || !Inputs.ContainsKey("Results1") || !Inputs.ContainsKey("Results2"))
            //{
            //    errorCode = AlgoBlobInspectAction.Err_InputData_Name_Missing;
            //    return false;
            //}

            //if(!(Inputs["Results"] is CogBlobResults) || !(Inputs["Results1"] is CogBlobResults)|| !(Inputs["Results2"] is CogBlobResults))
            //{
            //    errorCode = AlgoBlobInspectAction.Err_InputData_Type_Missing;
            //    return false;
            //}
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as AlgoBlobInspectAlignModelParams;
            List<double> listareaRateSpecs = new List<double>();
            listareaRateSpecs.Add((double)mParams.AreaRate1.Value);
            listareaRateSpecs.Add((double)mParams.AreaRate2.Value);
            listareaRateSpecs.Add((double)mParams.AreaRate3.Value);
            #endregion

            #region Blob Result prepare
            List<CogBlobResults> listBlobResults = new List<CogBlobResults>();
            //List<>
            foreach (var blobresult in Inputs)
            {
                listBlobResults.Add(blobresult.Value as CogBlobResults);
            }

            List<double> listArea = new List<double>();
            List<double> listResion = new List<double>();
            List<double> listAreaRate = new List<double>();
            List<bool> listResult = new List<bool>();
            
            for (int i = 0; i < listBlobResults.Count; i++)
            {
                double area = 0;
                //double region = 0;
                double rate_ = 0;
                //listBlobResults이 null일때 예외처리
                if (listBlobResults[i] == null)
                {
                    listArea.Add(1);
                    listResion.Add(1000);

                    rate_ = 1 / 1000;
                    listAreaRate.Add(rate_);
                    listResult.Add(rate_ < listareaRateSpecs[i]);

                    continue;
                }

                var collection = listBlobResults[i].GetBlobs();
                if (collection == null) continue;

                foreach (CogBlobResult blob in collection)
                {
                    //region += blob.Area;
                    if (blob.Label == CogBlobLabelConstants.Blob)
                        area += blob.Area;
                }
                int aaa = listBlobResults[i].CreateBlobImage().Width * listBlobResults[i].CreateBlobImage().Height;
                listArea.Add(area);
                listResion.Add(aaa);

                double rate = area / aaa;
                listAreaRate.Add(rate);
                listResult.Add(rate < listareaRateSpecs[i]);
            }
            #endregion

            bool result = listResult.FindIndex(x => x == false) < 0;

            string strResult = "NG";
            if (result == true) strResult = "OK";

            #region Result Data Update(DataGridView Insert)
            //로그 때문에 문제가 되서 무조껀 3개로 만들어 준다
            if (listBlobResults.Count < 3)
            {
                int addCount = 3 - listBlobResults.Count;

                for (int i = 0; i < addCount; i++)
                {
                    listAreaRate.Add(0);
                    listareaRateSpecs.Add(0);
                }
            }

            AlgoRst = new AlgoBlobInspectAlignResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                LastConfirm = strResult,
                AreaRate1 = Math.Round(listAreaRate[0], 3),
                AreaRate2 = Math.Round(listAreaRate[1], 3),
                AreaRate3 = Math.Round(listAreaRate[2], 3),
                RateSpec1 = Math.Round(listareaRateSpecs[0], 3),
                RateSpec2 = Math.Round(listareaRateSpecs[1], 3),
                RateSpec3 = Math.Round(listareaRateSpecs[2], 3),
                //RateSpec3 = Math.Round((double)sw.ElapsedMilliseconds, 4),
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Blob or Hole Check
            if (!result)
            {
                errorCode = 16104;
            }
            #endregion
            return errorCode == 0 ? true : false; ;
        }


        private bool CheckCount(int cnt, int totalCount)
        {
            if (totalCount == 0) return true;
            if (cnt == totalCount) return true;
            else return false;
        }
        //private bool CheckArea(double total, double rateSpec, int tor_Area)
        //{
        //    if (totalArea == 0) return true;
        //    if (tor_Area == 0) return true;
        //    double confirmValue = total / totalArea * 100;
        //    if (confirmValue < (100 + tor_Area) || confirmValue > (100 - tor_Area)) return true;
        //    else return false;
        //}

        private bool CheckLastResult(bool chkCount, bool chkArea)
        {
            if (chkCount && chkArea) return true;
            else if (!chkCount && chkArea)
            {
                errorCode = AlgoBlobInspectAction.Err_Blob_Count_NG;
                return false;
            }
            else if (chkCount && !chkArea)
            {
                errorCode = AlgoBlobInspectAction.Err_Blob_Area_NG;
                return false;
            }
            else if (!chkCount && !chkArea)
            {
                errorCode = AlgoBlobInspectAction.Err_Blob_Count_Area_NG;
                return false;
            }
            return true;
        }
        #endregion
    }
}

