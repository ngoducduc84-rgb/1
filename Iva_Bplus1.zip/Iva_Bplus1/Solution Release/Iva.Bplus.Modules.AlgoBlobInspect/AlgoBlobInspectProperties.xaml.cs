﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Iva.Bplus.Modules.AlgoBlobInspect
{
    /// <summary>
    /// CameraProperties.xaml에 대한 상호 작용 논리
    /// </summary>
    /// 

    public partial class AlgoBlobInspectProperties : UserControl
    {
        public AlgoBlobInspectProperties()
        {
            InitializeComponent();
        }

    }
}

// x:Class="Iva.Bplus.Modules.Algo90DBendedLami_4PTarObj.Algo90DBendedLami_4P_TarObjProperties"