﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.AlgoBlobInspect
{
    [SerializableAttribute]
    public class AlgoBlobInspectAlignResult : AlgoResultBase
    {
        #region [fiedls]
        private double rateSpec1;
        private double rateSpec2;
        private double rateSpec3;
        private string lastConfirm;
        private double areaRate1;
        private double areaRate2;
        private double areaRate3; 
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string LastConfirm
        {
            get { return lastConfirm; }
            set { if (value == lastConfirm) return; lastConfirm = value; OnPropertyChanged(nameof(LastConfirm)); }
        }
        public double AreaRate1
        {
            get { return areaRate1; }
            set { if (value == areaRate1) return; areaRate1 = value; OnPropertyChanged(nameof(AreaRate1)); }
        }
        public double AreaRate2
        {
            get { return areaRate2; }
            set { if (value == areaRate2) return; areaRate2 = value; OnPropertyChanged(nameof(AreaRate2)); }
        }
        public double AreaRate3
        {
            get { return areaRate3; }
            set { if (value == areaRate3) return; areaRate3 = value; OnPropertyChanged(nameof(AreaRate3)); }
        }
        public double RateSpec1
        {
            get { return rateSpec1; }
            set { if (value == rateSpec1) return; rateSpec1 = value; OnPropertyChanged(nameof(RateSpec1)); }
        }
        public double RateSpec2
        {
            get { return rateSpec2; }
            set { if (value == rateSpec2) return; rateSpec2 = value; OnPropertyChanged(nameof(RateSpec2)); }
        }
        public double RateSpec3
        {
            get { return rateSpec3; }
            set { if (value == rateSpec3) return; rateSpec3 = value; OnPropertyChanged(nameof(RateSpec3)); }
        }        
        #endregion


        public AlgoBlobInspectAlignResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n Confirm : {3},\n AreaRate1 : {4},\n AreaRate2 : {5}\n AreaRate3 :{6}\n RateSpec1 :{7}\n RateSpec2 :{8}\n RateSpec3 : {9}",

                                 typeof(AlgoBlobInspectAlignResult).ToString(), curDate, curTime, lastConfirm, areaRate1, areaRate2, areaRate3, RateSpec1, RateSpec2, RateSpec3 );
        }

    }
}
