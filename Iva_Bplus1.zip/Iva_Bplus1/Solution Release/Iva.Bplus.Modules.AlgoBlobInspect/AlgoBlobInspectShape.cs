﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using Iva.Bplus.Views;
using SvMip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace Iva.Bplus.Modules.AlgoBlobInspect
{
    [SerializableAttribute]
    public partial class AlgoBlobInspectShape : ModuleBase
    {
        #region [Construct]
        public AlgoBlobInspectShape()
            : base()
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;
        }

        public AlgoBlobInspectShape(SystemCanvasViewModel parent, string name)
            : base(parent, name)
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;

            base.InitItem(null, name, SettingShapeType.Algo);

            var action = base.modAction as SystemActionBase;
            base.SetConnectors(action.InputParams, action.OutputParams);
        }
        #endregion

        #region [override method]
        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string _source)
        {
            base.parent = parent;
            base.InitItem(obj, _source, SettingShapeType.Algo);

            base.Geometry = SystemImage.TOOLS_ICON;
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion
    }
}
