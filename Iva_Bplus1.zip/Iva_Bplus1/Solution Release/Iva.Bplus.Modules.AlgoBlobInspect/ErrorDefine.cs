﻿using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoBlobInspect
{
    public partial class AlgoBlobInspectAction
    {
        #region [Error Script] AlgoBlobInspectAction: 16101 ~ 16200
        static public int Err_InputData_Name_Missing = 16101; public string E16101_Err_InputData_Name_Missing = "InputData Name Missing(BlobResults)";
        static public int Err_InputData_Type_Missing = 16102; public string E16102_Err_InputData_Type_Missing = "InputData Type Missing(CogBlobResults)";
        static public int Err_Blob_Count_NG = 16103;          public string E16103_Err_Blob_Count_NG = "Blob Count NG";
        static public int Err_Blob_Area_NG = 16104;           public string E16104_Err_Blob_Area_NG = "Blob Area NG";
        static public int Err_Blob_Count_Area_NG = 16105;     public string E16105_Err_Blob_Count_Area_NG = "Blob Count & Blob Area NG";
        public override void ErrorDefine()
        {
            base.ErrorDefine();

            errorInfos.Add(new ErrorInfo(this.Parent, Err_InputData_Name_Missing, ErrorType.Warning, E16101_Err_InputData_Name_Missing, "InputData에서 BlobResult를 찾을수 없습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_InputData_Name_Missing, ErrorType.Warning, E16102_Err_InputData_Type_Missing, "InputData에서 CogBlobResults Type을 찾을수 없습니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Blob_Count_NG, ErrorType.Warning, E16103_Err_Blob_Count_NG, "Blob 또는 Hole의 개수가 스펙미달입니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Blob_Area_NG, ErrorType.Warning, E16104_Err_Blob_Area_NG, "Blob 또는 Hole의 전체 영역 크기가 스펙 미달입니다."));
            errorInfos.Add(new ErrorInfo(this.Parent, Err_Blob_Count_Area_NG, ErrorType.Warning, E16105_Err_Blob_Count_Area_NG, "Blob 또는 Hole의 개수 및 전체 영역 크기가 스펙 미달입니다.."));
        }
        #endregion
    }
}
