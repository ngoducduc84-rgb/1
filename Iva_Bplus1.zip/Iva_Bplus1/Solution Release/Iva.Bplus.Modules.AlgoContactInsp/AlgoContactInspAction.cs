﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using OpenCvSharp;
using SvMip;
using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.Integration;
using Iva.Bplus.Database;

namespace Iva.Bplus.Modules.AlgoContactInsp
{
    [SerializableAttribute]
    public partial class AlgoContactInspAction : AlgoActionBase
    {
        #region [Construct]
        public AlgoContactInspAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            inputParams = new AlgoContactInspInputParams();
            OutputParams = new AlgoContactInspOutputParams();
        }

        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase _obj, CmdReqArgs _args)
        {
            string InputName = Start(_obj, _args, false);
            var Obj = modObject as AlgoContactInspObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                var algoCmd = _args.Value as AlgoCommandInfo;

                if(isAuto) Obj.WriteVisionIO(ObjectID);

                StopTimer();
            }
            return End(false);

        }

        public override void Dispose(){ base.Dispose(); }
        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion

    }
}
