﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.AlgoContactInsp
{
    [SerializableAttribute]
    public class AlgoContactInspInputParams : InputParams
    {
        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion

    }
}
