﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoContactInsp
{
    [SerializableAttribute]
    public class AlgoContactInspModelParams : AlgoParams
    {
      
        public AlgoContactInspModelParams()
        {
        }
       
    }
}
