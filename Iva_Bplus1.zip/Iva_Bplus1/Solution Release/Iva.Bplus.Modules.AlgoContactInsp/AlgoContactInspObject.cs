﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;
using OpenCvSharp;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
//using Iva.Bplus.Modules.CogDisplay;
using System.Reflection;
using Iva.Bplus.Enums;

namespace Iva.Bplus.Modules.AlgoContactInsp
{
    [SerializableAttribute]
    public class AlgoContactInspObject : AlgoObjectBase
    {
        #region[Construct]
        public AlgoContactInspObject()
            : base()
        {
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            return true;
        }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [public method]
        public void WriteVisionIO(string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }    
        #endregion

    }
}
