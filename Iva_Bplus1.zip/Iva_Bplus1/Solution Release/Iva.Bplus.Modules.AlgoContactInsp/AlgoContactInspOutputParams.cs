﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using SvMip;
using System;

namespace Iva.Bplus.Modules.AlgoContactInsp
{
    [SerializableAttribute]
    public class AlgoContactInspOutputParams : OutputParams
    {
        #region Logging
        #endregion
    }
}
