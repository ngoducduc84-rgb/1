﻿using Iva.Bplus.Utils;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoContactInsp
{
    public partial class AlgoContactInspAction
    {
        #region [Error Script] AlgoContactInspAction : 
    
        public override void ErrorDefine()
        {
            base.ErrorDefine();
        }
        #endregion
    }
}
