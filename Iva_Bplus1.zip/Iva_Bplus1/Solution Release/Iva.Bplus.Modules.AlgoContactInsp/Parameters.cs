﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Struct;

namespace Iva.Bplus.Modules.AlgoContactInsp
{
    public class Parameters : AlgoParams
    {
     
        public Parameters()
           : base()
        {
        }
    }
}
