﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo4P_Dist_Inspection;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo4P_Dist_Inspection
{
    [SerializableAttribute]
    public partial class Algo4P_Dist_InspectionAction : AlgoActionBase
    {
        #region [Fields]
        #region fields 필요 없음 지울 것!
        //[field: NonSerialized]
        //private AlgoParam l_ChkCenter01_PNL;
        //[field: NonSerialized]
        //private AlgoParam l_ChkCenter12_PNL;
        //[field: NonSerialized]
        //private AlgoParam l_ChkCenter23_PNL;
        //[field: NonSerialized]
        //private AlgoParam l_ChkCenter30_PNL;

        //[field: NonSerialized]
        //private AlgoParam l_ChkRange01_PNL;
        //[field: NonSerialized]
        //private AlgoParam l_ChkRange12_PNL;
        //[field: NonSerialized]
        //private AlgoParam l_ChkRange23_PNL;
        //[field: NonSerialized]
        //private AlgoParam l_ChkRange30_PNL;

        //[field: NonSerialized]
        //private AlgoParam designValuePlus_X;
        //[field: NonSerialized]
        //private AlgoParam designValuePlus_Y;
        //private AlgoParam modelParam;
        #endregion
        #endregion

        #region [Properties]  
        #region properties 필요 없음 지울 것!
        //public AlgoParam ModelParam { get { return modelParam; } set { if (modelParam == value) return; modelParam = value; this.OnPropertyChanged(nameof(ModelParam)); } }

        //// L-Check Range+Center 
        //public AlgoParam L_ChkCenter01_PNL { get { return l_ChkCenter01_PNL; } set { if (l_ChkCenter01_PNL == value) return; l_ChkCenter01_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter01_PNL)); } }
        //public AlgoParam L_ChkCenter12_PNL { get { return l_ChkCenter12_PNL; } set { if (l_ChkCenter12_PNL == value) return; l_ChkCenter12_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter12_PNL)); } }
        //public AlgoParam L_ChkCenter23_PNL { get { return l_ChkCenter23_PNL; } set { if (l_ChkCenter23_PNL == value) return; l_ChkCenter23_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter23_PNL)); } }
        //public AlgoParam L_ChkCenter30_PNL { get { return l_ChkCenter30_PNL; } set { if (l_ChkCenter30_PNL == value) return; l_ChkCenter30_PNL = value; this.OnPropertyChanged(nameof(L_ChkCenter30_PNL)); } }

        //public AlgoParam L_ChkRange01_PNL { get { return l_ChkRange01_PNL; } set { if (l_ChkRange01_PNL == value) return; l_ChkRange01_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange01_PNL)); } }
        //public AlgoParam L_ChkRange12_PNL { get { return l_ChkRange12_PNL; } set { if (l_ChkRange12_PNL == value) return; l_ChkRange12_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange12_PNL)); } }
        //public AlgoParam L_ChkRange23_PNL { get { return l_ChkRange23_PNL; } set { if (l_ChkRange23_PNL == value) return; l_ChkRange23_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange23_PNL)); } }
        //public AlgoParam L_ChkRange30_PNL { get { return l_ChkRange30_PNL; } set { if (l_ChkRange30_PNL == value) return; l_ChkRange30_PNL = value; this.OnPropertyChanged(nameof(L_ChkRange30_PNL)); } }

        //// 비대칭 -> 직사각형 변경을 위한 Proper-
        //public AlgoParam DesignValuePlus_X { get { return designValuePlus_X; } set { if (designValuePlus_X == value) return; designValuePlus_X = value; this.OnPropertyChanged(nameof(DesignValuePlus_X)); } }
        //public AlgoParam DesignValuePlus_Y { get { return designValuePlus_Y; } set { if (designValuePlus_Y == value) return; designValuePlus_Y = value; this.OnPropertyChanged(nameof(DesignValuePlus_Y)); } }
        #endregion
        #endregion

        #region [Construct]

        public Algo4P_Dist_InspectionAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo4P_Dist_InspectionInputParams();
            OutputParams = new Algo4P_Dist_InspectionOutputParams();

            var obj = _object as Algo4P_Dist_InspectionObject;
            obj.ModelParamType = typeof(Algo4P_Dist_InspectionModelParams);
            var param = obj.CurParams as Algo4P_Dist_InspectionModelParams;

            ChildSettingView = new ModelParams_Setting();
            ChildSettingView.DataContext = ModObject;

            //l_ChkCenter01_PNL = new AlgoParam(param.LengthCenter_01_Object);
            //l_ChkCenter12_PNL = new AlgoParam(param.LengthCenter_12_Object);
            //l_ChkCenter23_PNL = new AlgoParam(param.LengthCenter_23_Object);
            //l_ChkCenter30_PNL = new AlgoParam(param.LengthCenter_30_Object);

            //l_ChkRange01_PNL = new AlgoParam(param.LengthRange_01_Object);
            //l_ChkRange12_PNL = new AlgoParam(param.LengthRange_12_Object);
            //l_ChkRange23_PNL = new AlgoParam(param.LengthRange_23_Object);
            //l_ChkRange30_PNL = new AlgoParam(param.LengthRange_30_Object);

            //designValuePlus_X = new AlgoParam(param.DesignValuePlus_Obj_X);
            //designValuePlus_X = new AlgoParam(param.DesignValuePlus_Obj_Y);

            ChildSettingView = new ModelParams_Setting();
            ChildSettingView.DataContext = this;
            //ModObject.PropertyChanged += ModObject_PropertyChanged;
        }
        #endregion

        private void ModObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
        }

        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args);

            var Obj = modObject as Algo4P_Dist_InspectionObject;

            if (InputName.Equals("Trigger") || InputName.Equals(""))
            {
                StartTimer();
                var InspObj = ModObject as Algo4P_Dist_InspectionObject;

                InspObj.Name = name;  
                InspObj.SourceID = ObjectID;

                replyType = Obj.Run() == true ? CmdReply.Complete : CmdReply.Error;
                classifyErrCode(InspObj.errCode);           // Error Code 분류

                foreach (CommandReplyArgs arg in ReplyArgs) // Run 후 'Error' 발생 판단
                {
                    if (arg.ReplyType == CmdReply.Error)
                        return ReplyArgs;
                }

                var vIO_data = InspObj.M_dicVisionValues; // PLC Update
                var vIO_obj  = InspObj.CommodObject;
                vIO_obj.SetPlcValues(vIO_data.Values.ToList());

                ReplyArgs = OutputPlay("LogResult", InspObj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait); // Log에 대한 DataGridView에 넘겨줌      

                Obj.AppendMessage(Name, "Inspection Complete");

                StopTimer();
            }
            return ReplyArgs;
        }

        public void classifyErrCode(Dictionary<string, bool> ErrCode)
        {
            foreach (KeyValuePair<string, bool> pair in ErrCode)
            {
                if (pair.Value == false)
                {
                    switch (pair.Key)
                    {
                        case "Err_Obtain_InputData":
                            ReplyArgs.AddRange(OccurError(E15414_Failed_Obtain_InsInputData_Value));
                            break;
                        case "Err_Cal_MarkToLine":
                            ReplyArgs.AddRange(OccurError(E15415_Failed_Calculate_Distance));
                            break;
                    }
                }
            }
        }

        public override void Dispose()
        {
            base.Dispose();
        }

    }
}
