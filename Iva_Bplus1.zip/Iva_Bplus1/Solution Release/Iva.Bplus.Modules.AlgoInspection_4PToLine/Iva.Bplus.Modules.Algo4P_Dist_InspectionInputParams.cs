﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;
using System;
using System.Collections.Generic;

namespace Iva.Bplus.Modules.Algo4P_Dist_Inspection
{
    [SerializableAttribute]
    class Algo4P_Dist_InspectionInputParams : InputParams
    {
        // Align 방식 
        //  (X1,Y1) -----------------------(X4,Y4)
        //    |                               l
        //    |                               l
        //    l                               l
        //    |                               |        Lower 찍고, Upper로 이동!
        //    l                               l         
        //    l                               l
        //  (X2,Y2) -----------------------(X3,Y3)
        //     '작업자' 방향
        
        public Dictionary<string, object> InsArea1 { get; set; }
        public Dictionary<string, object> InsArea2 { get; set; }
        public Dictionary<string, object> InsArea3 { get; set; }
        public Dictionary<string, object> InsArea4 { get; set; }
        //public Dictionary<string, object>  InsArea3_CrossPoint { get; set; }
        //public Dictionary<string, object>  InsArea3_LineXY { get; set; }
        //public Dictionary<string, object>  InsArea4_CrossPoint { get; set; }
        //public Dictionary<string, object> InsArea4_LineXY { get; set; }
          
        //public IPointResult InsArea1_CrossPoint { get; set; }
        //public IPointResult InsArea1_LineXY { get; set; }
        //public IPointResult InsArea2_CrossPoint { get; set; }
        //public IPointResult InsArea2_LineXY { get; set; }
        //public IPointResult InsArea3_CrossPoint { get; set; }
        //public IPointResult InsArea3_LineXY { get; set; }
        //public IPointResult InsArea4_CrossPoint { get; set; }
        //public IPointResult InsArea4_LineXY { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
}
