﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo4P_Dist_Inspection
{
    [SerializableAttribute]

    public partial class Algo4P_Dist_InspectionModelParams : AlgoParams
    {
        #region [field]

        #region Dis 진/가성 판정 field
        // ex) 측정(Dis1 + Dis4) -  이상적(Dis1 + Dis4) > '_JudgeTh' ---> 'NG'
        private AlgoParam _AccuracyTh;       

        #endregion

        #region (Resolution) X (Scale)
        private AlgoParam _Pos1ScaleX;
        private AlgoParam _Pos1ScaleY;
        private AlgoParam _Pos2ScaleX;
        private AlgoParam _Pos2ScaleY;
        private AlgoParam _Pos3ScaleX;
        private AlgoParam _Pos3ScaleY;
        private AlgoParam _Pos4ScaleX;
        private AlgoParam _Pos4ScaleY;
        #endregion

        #region Each Position Distance Spec  
        private AlgoParam _DisX1;
        private AlgoParam _DisX2;
        private AlgoParam _DisX3;
        private AlgoParam _DisX4;

        private AlgoParam _DisY1;
        private AlgoParam _DisY2;
        private AlgoParam _DisY3;
        private AlgoParam _DisY4;
        #endregion

        #region Spec & Tol
        private AlgoParam _UpperCenter;
        private AlgoParam _LowerCenter;
        private AlgoParam _LeftCenter;
        private AlgoParam _RightCenter;

        private AlgoParam _UpperTol;
        private AlgoParam _LowerTol;
        private AlgoParam _LeftTol;
        private AlgoParam _RightTol;
        #endregion
        #endregion

        #region[Properties]
        #region Dis 진/가성 판정 Properties
        public AlgoParam AccuracyTh
        {
            get { return _AccuracyTh; }
            set
            {
                if (_AccuracyTh == value) return;
                _AccuracyTh = value;
                this.OnPropertyChanged(nameof(AccuracyTh));
            }
        }
        #endregion
        #region (Resolution) X (Scale) Properties
        public AlgoParam Pos1ScaleX
        {
            get { return _Pos1ScaleX; }
            set
            {
                if (_Pos1ScaleX == value) return;
                _Pos1ScaleX = value;
                this.OnPropertyChanged(nameof(Pos1ScaleX));
            }
        }
        public AlgoParam Pos1ScaleY
        {
            get { return _Pos1ScaleY; }
            set
            {
                if (_Pos1ScaleY == value) return;
                _Pos1ScaleY = value;
                this.OnPropertyChanged(nameof(Pos1ScaleY));
            }
        }
        public AlgoParam Pos2ScaleX
        {
            get { return _Pos2ScaleX; }
            set
            {
                if (_Pos2ScaleX == value) return;
                _Pos2ScaleX = value;
                this.OnPropertyChanged(nameof(Pos2ScaleX));
            }
        }
        public AlgoParam Pos2ScaleY
        {
            get { return _Pos2ScaleY; }
            set
            {
                if (_Pos2ScaleY == value) return;
                _Pos2ScaleY = value;
                this.OnPropertyChanged(nameof(Pos2ScaleY));
            }
        }
        public AlgoParam Pos3ScaleX
        {
            get { return _Pos3ScaleX; }
            set
            {
                if (_Pos3ScaleX == value) return;
                _Pos3ScaleX = value;
                this.OnPropertyChanged(nameof(Pos3ScaleX));
            }
        }
        public AlgoParam Pos3ScaleY
        {
            get { return _Pos3ScaleY; }
            set
            {
                if (_Pos3ScaleY == value) return;
                _Pos3ScaleY = value;
                this.OnPropertyChanged(nameof(Pos3ScaleY));
            }
        }
        public AlgoParam Pos4ScaleX
        {
            get { return _Pos4ScaleX; }
            set
            {
                if (_Pos4ScaleX == value) return;
                _Pos4ScaleX = value;
                this.OnPropertyChanged(nameof(Pos4ScaleX));
            }
        }
        public AlgoParam Pos4ScaleY
        {
            get { return _Pos4ScaleY; }
            set
            {
                if (_Pos4ScaleY == value) return;
                _Pos4ScaleY = value;
                this.OnPropertyChanged(nameof(Pos4ScaleY));
            }
        }
        #endregion

        #region Each Position Distance Spec  Properties
        public AlgoParam DisX1
        {
            get { return _DisX1; }
            set
            {
                if (_DisX1 == value) return;
                _DisX1 = value;
                this.OnPropertyChanged(nameof(DisX1));
            }
        }
        public AlgoParam DisX2
        {
            get { return _DisX2; }
            set
            {
                if (_DisX2 == value) return;
                _DisX2 = value;
                this.OnPropertyChanged(nameof(DisX2));
            }
        }
        public AlgoParam DisX3
        {
            get { return _DisX3; }
            set
            {
                if (_DisX3 == value) return;
                _DisX3 = value;
                this.OnPropertyChanged(nameof(DisX3));
            }
        }
        public AlgoParam DisX4
        {
            get { return _DisX4; }
            set
            {
                if (_DisX4 == value) return;
                _DisX4 = value;
                this.OnPropertyChanged(nameof(DisX4));
            }
        }
        public AlgoParam DisY1
        {
            get { return _DisY1; }
            set
            {
                if (_DisY1 == value) return;
                _DisY1 = value;
                this.OnPropertyChanged(nameof(DisY1));
            }
        }
        public AlgoParam DisY2
        {
            get { return _DisY2; }
            set
            {
                if (_DisY2 == value) return;
                _DisY2 = value;
                this.OnPropertyChanged(nameof(DisY2));
            }
        }
        public AlgoParam DisY3
        {
            get { return _DisY3; }
            set
            {
                if (_DisY3 == value) return;
                _DisY3 = value;
                this.OnPropertyChanged(nameof(DisY3));
            }
        }
        public AlgoParam DisY4
        {
            get { return _DisY4; }
            set
            {
                if (_DisY4 == value) return;
                _DisY4 = value;
                this.OnPropertyChanged(nameof(DisY4));
            }
        }
        #endregion

        #region Spec & Tol  Properties
        public AlgoParam UpperCenter
        {
            get { return _UpperCenter; }
            set
            {
                if (_UpperCenter == value) return;
                _UpperCenter = value;
                this.OnPropertyChanged(nameof(UpperCenter));
            }
        }
        public AlgoParam LowerCenter
        {
            get { return _LowerCenter; }
            set
            {
                if (_LowerCenter == value) return;
                _LowerCenter = value;
                this.OnPropertyChanged(nameof(LowerCenter));
            }
        }
        public AlgoParam LeftCenter
        {
            get { return _LeftCenter; }
            set
            {
                if (_LeftCenter == value) return;
                _LeftCenter = value;
                this.OnPropertyChanged(nameof(LeftCenter));
            }
        }
        public AlgoParam RightCenter
        {
            get { return _RightCenter; }
            set
            {
                if (_RightCenter == value) return;
                _RightCenter = value;
                this.OnPropertyChanged(nameof(RightCenter));
            }
        }

        public AlgoParam UpperTol
        {
            get { return _UpperTol; }
            set
            {
                if (_UpperTol == value) return;
                _UpperTol = value;
                this.OnPropertyChanged(nameof(UpperTol));
            }
        }
        public AlgoParam LowerTol
        {
            get { return _LowerTol; }
            set
            {
                if (_LowerTol == value) return;
                _LowerTol = value;
                this.OnPropertyChanged(nameof(LowerTol));
            }
        }
        public AlgoParam LeftTol
        {
            get { return _LeftTol; }
            set
            {
                if (_LeftTol == value) return;
                _LeftTol = value;
                this.OnPropertyChanged(nameof(LeftTol));
            }
        }
        public AlgoParam RightTol
        {
            get { return _RightTol; }
            set
            {
                if (_RightTol == value) return;
                _RightTol = value;
                this.OnPropertyChanged(nameof(RightTol));
            }
        }
        #endregion
        #endregion

        public Algo4P_Dist_InspectionModelParams()
        {
            // Judgement Threshold값
            AccuracyTh = new AlgoParam("AccuracyTh", "um", typeof(double), 0.5, "Pos1의 (ResolutionX) X (ScaleX) 적용 값", 0, 1);

            // Resolution x Scale값
            Pos1ScaleX = new AlgoParam("Pos1ScaleX", "um", typeof(double), 5.0, "Pos1의 (ResolutionX) X (ScaleX) 적용 값", 3, 7);
            Pos1ScaleY = new AlgoParam("Pos1ScaleY", "um", typeof(double), 5.0, "Pos1의 (ResolutionY) X (ScaleY) 적용 값", 3, 7);
            Pos2ScaleX = new AlgoParam("Pos2ScaleX", "um", typeof(double), 5.0, "Pos2의 (ResolutionX) X (ScaleX) 적용 값", 3, 7);
            Pos2ScaleY = new AlgoParam("Pos2ScaleY", "um", typeof(double), 5.0, "Pos2의 (ResolutionY) X (ScaleY) 적용 값", 3, 7);
            Pos3ScaleX = new AlgoParam("Pos3ScaleX", "um", typeof(double), 5.0, "Pos3의 (ResolutionX) X (ScaleX) 적용 값", 3, 7);
            Pos3ScaleY = new AlgoParam("Pos3ScaleY", "um", typeof(double), 5.0, "Pos3의 (ResolutionY) X (ScaleY) 적용 값", 3, 7);
            Pos4ScaleX = new AlgoParam("Pos4ScaleX", "um", typeof(double), 5.0, "Pos4의 (ResolutionX) X (ScaleX) 적용 값", 3, 7);
            Pos4ScaleY = new AlgoParam("Pos4ScaleY", "um", typeof(double), 5.0, "Pos4의 (ResolutionY) X (ScaleY) 적용 값", 3, 7);

            DisX1 = new AlgoParam("DisX1", "mm", typeof(double), 0.2, "내부자재 LineCross Point와 외부 자재 Line간 (최단=법선) 거리", 0.1, 0.5);
            DisX2 = new AlgoParam("DisX2", "mm", typeof(double), 0.2, "내부자재 LineCross Point와 외부 자재 Line간 (최단=법선) 거리", 0.1, 0.5);
            DisX3 = new AlgoParam("DisX3", "mm", typeof(double), 0.2, "내부자재 LineCross Point와 외부 자재 Line간 (최단=법선) 거리", 0.1, 0.5);
            DisX4 = new AlgoParam("DisX4", "mm", typeof(double), 0.2, "내부자재 LineCross Point와 외부 자재 Line간 (최단=법선) 거리", 0.1, 0.5);
            DisY1 = new AlgoParam("DisY1", "mm", typeof(double), 0.2, "내부자재 LineCross Point와 외부 자재 Line간 (최단=법선) 거리", 0.1, 0.5);
            DisY2 = new AlgoParam("DisY2", "mm", typeof(double), 0.2, "내부자재 LineCross Point와 외부 자재 Line간 (최단=법선) 거리", 0.1, 0.5);
            DisY3 = new AlgoParam("DisY3", "mm", typeof(double), 0.2, "내부자재 LineCross Point와 외부 자재 Line간 (최단=법선) 거리", 0.1, 0.5);
            DisY4 = new AlgoParam("DisY4", "mm", typeof(double), 0.2, "내부자재 LineCross Point와 외부 자재 Line간 (최단=법선) 거리", 0.1, 0.5);

            UpperCenter = new AlgoParam("UpperCenter", "mm", typeof(double), 0.2, "Upper CenterAlign의 중심값", 0.1, 0.5);
            LowerCenter = new AlgoParam("LowerCenter", "mm", typeof(double), 0.2, "Lower CenterAlign의 중심값", 0.1, 0.5);
            LeftCenter  = new AlgoParam("LeftCenter" , "mm", typeof(double), 0.2, "Left  CenterAlign의 중심값", 0.1, 0.5);
            RightCenter = new AlgoParam("RightCenter", "mm", typeof(double), 0.2, "Right CenterAlign의 중심값", 0.1, 0.5);

            UpperTol = new AlgoParam("UpperTol", "mm", typeof(double), 0.2, "Upper CenterAlign의 Tolerance값", 0.1, 0.5);
            LowerTol = new AlgoParam("LowerTol", "mm", typeof(double), 0.2, "Lower CenterAlign의 Tolerance값", 0.1, 0.5);
            LeftTol  = new AlgoParam("LeftTol" , "mm", typeof(double), 0.2, "Left  CenterAlign의 Tolerance값", 0.1, 0.5);
            RightTol = new AlgoParam("RightTol", "mm", typeof(double), 0.2, "Right CenterAlign의 Tolerance값", 0.1, 0.5);
        }
    }
}
