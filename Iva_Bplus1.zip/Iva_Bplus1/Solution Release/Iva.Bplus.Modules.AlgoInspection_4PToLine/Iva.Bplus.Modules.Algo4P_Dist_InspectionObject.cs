﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;

using Cognex.VisionPro.Dimensioning;
using Cognex.VisionPro;
using Iva.Bplus.Modules.CogDisplay;


namespace Iva.Bplus.Modules.Algo4P_Dist_Inspection
{
    [SerializableAttribute]
    public partial class Algo4P_Dist_InspectionObject : AlgoObjectBase
    {
        #region [Fields]
        // Result Data
        [field: NonSerialized]
        private Algo4P_Dist_InspectionResult inspRst;

        private string p1_Display;
        private string p2_Display;
        private string p3_Display;
        private string p4_Display;

        private UseDistRevision distRevision;
        public Dictionary<string, bool> errCode;
        public Dictionary<string, object> InputData = new Dictionary<string, object>(); 
        #endregion

        #region [properties]
        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P2_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p2_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P3_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p3_Display) as CogDisplayObject; }
        }

        public CogDisplayObject P4_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p4_Display) as CogDisplayObject; }
        }


        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P2_Display
        {
            get { return p2_Display; }
            set { if (p2_Display == value) return; p2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P3_Display
        {
            get { return p3_Display; }
            set { if (p3_Display == value) return; p3_Display = value; this.OnPropertyChanged(nameof(P3_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P4_Display
        {
            get { return p4_Display; }
            set { if (p4_Display == value) return; p4_Display = value; this.OnPropertyChanged(nameof(P4_Display)); }
        }


        public Algo4P_Dist_InspectionResult InspRst
        {
            get { return inspRst; }
            set
            {
                if (inspRst == value) return;
                inspRst = value;

                this.OnPropertyChanged(nameof(InspRst));
            }
        }

        public Dictionary<string, IOStruct> M_dicVisionValues
        {
            get { return visionValues; }
            set
            {
                if (visionValues == value) return;
                visionValues = value;

                OnPropertyChanged("M_dicVisionValues");
            }
        }

        public UseDistRevision DistRevision
        {
            get { return distRevision; }
            set
            {
                if (distRevision == value) return;

                distRevision = value;
                OnPropertyChanged("DistRevision");
            }
        }

        public Dictionary<string, bool> ErrCode
        {
            get { return errCode; }
            set
            {
                if (errCode == value) return;

                errCode = value;
                OnPropertyChanged("ErrCode");
            }
        }
        #endregion

        #region [private method]
        #endregion

        #region [public method]
        #endregion

        #region[Construct]
        public Algo4P_Dist_InspectionObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo4P_Dist_InspectionModelParams());

                CurParams = ModelParams[SystemModel.GetCurModel()];

            }
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            #region 1) Inspection 초기 간단 작업 
            //UpdatePLCIOs();
            StartTimer();

            string productID = string.Empty;
            string model = SystemModel.GetCurModel();
            bool existID = true;

            if (plcValues.ContainsKey("CellID"))
            {
                productID = (string)plcValues["CellID"].CurValue;
            }
            else
            {
                existID = false;
                productID = GetMakeID(10);
            }

            // Inspection Err Initial
            errCode = new Dictionary<string, bool>();
            InitInsp_Err(ref errCode);
            #endregion

            //* 'DisRst'란?
            //* InputValue, ResultValue, ModelParams 등 All Data Save
            Dictionary<string, DisRstData> DisRsts = new Dictionary<string, DisRstData>(); //* 전 Code에서 사용

            #region 2) InputData -> 'DisRst'에 Input Value 담기
            if (InputDataConfirm(ref InputData, ref errCode) != true) return false;

            foreach(var eachData in InputData)
            {
                string[] keySplit = eachData.Key.Split(new string[] { "InsArea" }, StringSplitOptions.None);
                string InsArea = keySplit[1];         
   
                //* 각 Area의 저장 Dictionary 생성
                if(DisRsts.ContainsKey("InsArea" + InsArea) == false) {
                    DisRstData tempRst = new DisRstData();
                    DisRsts.Add("InsArea" + InsArea, tempRst); 
                    DisRsts["InsArea" + InsArea].OutputImage = new CogImage8Grey(5000, 5000); 
                }

                //* Input(CrossPoint/Angle+Line x 2)을 하나의 Area에 Save(정리)
                foreach(var data in eachData.Value as Dictionary<string, object>)
                { 
                    switch(data.Key)
                    {
                        case "CrossX":
                            DisRsts["InsArea" + InsArea].OutputXYT.X = double.Parse(data.Value.ToString());
                            break;
                        case "CrossY":
                            DisRsts["InsArea" + InsArea].OutputXYT.Y = double.Parse(data.Value.ToString());
                            break;
                        case "CrossAngle":
                            DisRsts["InsArea" + InsArea].Angle = double.Parse(data.Value.ToString());
                            break;
                        case "Get_XLine":
                        case "Get_YLine":
                            DisRsts["InsArea" + InsArea].Lines.Add(data.Value); // X,Y는 각각 1->2 Line으로 들어감!
                            break;
                    }                    
                }
            }
            #endregion

            #region 3) All ModelParam 'DisRsts'와 'CenterSpec'/ 'TolSpec'에 저장
            Algo4P_Dist_InspectionModelParams objModelParams = new Algo4P_Dist_InspectionModelParams();
            Type ModelType = typeof(Algo4P_Dist_InspectionModelParams);
            PropertyInfo[] pProperties= ModelType.GetProperties();

            //* CenterAling Spec + Tol
            Dictionary<string, double> CenterSpec = new Dictionary<string, double>();
            Dictionary<string, double>    TolSpec = new Dictionary<string, double>();
            double AccuracyTh = 0;
            string ownParm = null;
            MatchCollection ownParmCnt;
            foreach (var pProperty in pProperties) // 25개의 Data
            {                
                object obj = pProperty.GetValue(objModelParams);
                AlgoParam InsParam = (AlgoParam)obj;

                string tempplpp = pProperty.Name.ToString();
                string AreaPos = Regex.Replace(pProperty.Name.ToString(), @"\D", "");

                if (Regex.Matches(pProperty.Name, "Tol").Count != 0)             { ownParm = "Tol"; }
                else if (Regex.Matches(pProperty.Name, "Center").Count != 0)     { ownParm = "Center"; }
                else if (Regex.Matches(pProperty.Name, "ScaleX").Count != 0)     { ownParm = "ScaleX"; }
                else if (Regex.Matches(pProperty.Name, "ScaleY").Count != 0)     { ownParm = "ScaleY"; }
                else if (Regex.Matches(pProperty.Name, "DisX").Count != 0)       { ownParm = "DisX"; }
                else if (Regex.Matches(pProperty.Name, "DisY").Count != 0)       { ownParm = "DisY"; }
                else if (Regex.Matches(pProperty.Name, "AccuracyTh").Count != 0) { ownParm = "AccuracyTh"; }
                     
                string tempppp = pProperty.GetValue(objModelParams).ToString();
                switch (ownParm)
                {
                    case "Center":
                        CenterSpec.Add(pProperty.Name, double.Parse(InsParam.Value.ToString()));
                        break;
                    case "Tol":
                        TolSpec.Add(pProperty.Name, double.Parse(InsParam.Value.ToString()));
                        break;
                    case "ScaleX":
                        DisRsts["InsArea" + AreaPos].Scales.X = double.Parse(InsParam.Value.ToString());
                        break;
                    case "ScaleY":
                        DisRsts["InsArea" + AreaPos].Scales.Y = double.Parse(InsParam.Value.ToString());
                        break;
                    case "DisX":
                        DisRsts["InsArea" + AreaPos].DisXY.X = double.Parse(InsParam.Value.ToString());
                        break;
                    case "DisY":
                        DisRsts["InsArea" + AreaPos].DisXY.Y = double.Parse(InsParam.Value.ToString());
                        break;
                    case "AccuracyTh":
                        AccuracyTh = double.Parse(InsParam.Value.ToString());
                        break;

                }
            }
            #endregion

            #region [쓰레기 Code] ModelParam Data Save -> 여기까지가 'Inspection'을 돌리기 위한 Data Merge 
            //bool ownScalePam = false; bool ownDisPam = false;
            //bool ownXPam = false;

            //foreach (var DisRst in DisRsts) //* '대빵 저장고' DisRsts (key: InsArea_1~4)
            //{
            //    foreach(var pProperty in pProperties) //* ModelParams의 Properties
            //    {
            //        object obj = pProperty.GetValue(objModelParams);
            //        AlgoParam InsParam = (AlgoParam)obj;

            //        //* 문자열 내부 "Scale", "Dis"의 유/무 여부로 구분
            //        MatchCollection matchesScale = Regex.Matches(pProperty.Name, "Scale"); ownScalePam = false;
            //        if (matchesScale.Count != 0) { ownScalePam = true; }
            //        MatchCollection matchesDis = Regex.Matches(pProperty.Name, "Dis"); ownDisPam = false;
            //        if (matchesDis.Count != 0) { ownDisPam = true; }

            //        //* Pos?Scal? or Dis? 형식의 Params만 Save
            //        if (ownScalePam == true)
            //        {
            //            // X,Y 성분 구분                        
            //            MatchCollection matchesX = Regex.Matches(pProperty.Name, "X"); ownXPam = false;
            //            if (matchesX.Count != 0) { ownXPam = true; }
            //            switch (ownXPam)
            //            {                            
            //                case true:
            //                    DisRsts[DisRst.Key].Scales.X = double.Parse(InsParam.Value.ToString());
            //                    break;
            //                case false:
            //                    DisRsts[DisRst.Key].Scales.Y = double.Parse(InsParam.Value.ToString());
            //                    break;
            //            }
            //        }
            //        else if(ownDisPam == true)
            //        {
            //            MatchCollection matchesX = Regex.Matches(pProperty.Name, "X"); ownXPam = false;
            //            if (matchesX.Count != 0) { ownXPam = true; }
            //            switch (ownXPam)
            //            {
            //                case true:
            //                    DisRsts[DisRst.Key].DisXY.X = double.Parse(InsParam.Value.ToString());
            //                    break;
                                
            //                case false:
            //                    DisRsts[DisRst.Key].DisXY.Y = double.Parse(InsParam.Value.ToString());
            //                    break;
            //            }
            //        }
            //    }
            //}
            #endregion

            #region 4) Mark To Point, Distance 측정하는 부분 
            CogDistancePointLineTool PointToLine = new CogDistancePointLineTool();
            foreach (var pair in DisRsts)
            {
                for (int cnt=0; cnt < pair.Value.Lines.Count(); cnt++) // 첫번째는 X성분, 두번째는 Y성분
                {
                    PointToLine.Line = pair.Value.Lines[cnt] as CogLine; 
                    PointToLine.X = pair.Value.OutputXYT.X;
                    PointToLine.Y = pair.Value.OutputXYT.Y;
                    PointToLine.InputImage = new CogImage8Grey(5000, 5000); 
                    PointToLine.Run();

                    ICogRunStatus ResultStatus = PointToLine.RunStatus;
                    if (ResultStatus.Result == CogToolResultConstants.Accept)
                    {
                        //* PointToLine.LineX: X성분 Dis.의 접점, ContactY: Y성분 Dis.의 접점
                        if (cnt == 0) 
                        {
                            DisRsts[pair.Key].ContactPointX = new XY((double)PointToLine.LineX, (double)PointToLine.LineY);

                            XY StartPoint = new XY((double)PointToLine.LineX * DisRsts[pair.Key].Scales.X,
                                                   (double)PointToLine.LineY * DisRsts[pair.Key].Scales.Y);

                            XY EndPoint = new XY(DisRsts[pair.Key].OutputXYT.X * DisRsts[pair.Key].Scales.X, 
                                                 DisRsts[pair.Key].OutputXYT.Y * DisRsts[pair.Key].Scales.Y) ;
                            DisRsts[pair.Key].RstDistance.X = GetLength(StartPoint, EndPoint);
                        }
                        else
                        {
                            DisRsts[pair.Key].ContactPointY = new XY((double)PointToLine.LineX, (double)PointToLine.LineY);

                            XY StartPoint = new XY((double)PointToLine.LineX * DisRsts[pair.Key].Scales.X,
                                                   (double)PointToLine.LineY * DisRsts[pair.Key].Scales.Y);

                            XY EndPoint = new XY(DisRsts[pair.Key].OutputXYT.X * DisRsts[pair.Key].Scales.X,
                                                 DisRsts[pair.Key].OutputXYT.Y * DisRsts[pair.Key].Scales.Y);
                            DisRsts[pair.Key].RstDistance.Y = GetLength(StartPoint, EndPoint);
                        }
                    }
                    else
                    {
                        errCode["Err_Cal_MarkToLine"] = false;
                        return false;
                    }
                }
            }
            #endregion

            #region 5) Inspection 측정 성분들 Draw

            foreach (var elementDraw in DisRsts)
            {
                // ContactPoint_X + Label
                CogDrawMarkerInfo ContactPointX = new CogDrawMarkerInfo();
                MarkDraw(new XYT(elementDraw.Value.ContactPointX.X, elementDraw.Value.ContactPointX.Y, 0), ref ContactPointX);
                CogDrawLabelInfo labelCpX = new CogDrawLabelInfo();                

                // ContactPoint_Y + Label
                CogDrawMarkerInfo ContactPointY = new CogDrawMarkerInfo();
                MarkDraw(new XYT(elementDraw.Value.ContactPointY.X, elementDraw.Value.ContactPointY.Y, 0), ref ContactPointY);
                CogDrawLabelInfo labelCpY = new CogDrawLabelInfo();

                // Line Cross Mark + Label
                CogDrawMarkerInfo CrossMark = new CogDrawMarkerInfo();
                MarkDraw(elementDraw.Value.OutputXYT, ref CrossMark);
                CogDrawLabelInfo labelCpMark = new CogDrawLabelInfo();                

                // LineX + Label
                CogDrawLineInfo DisLineX = new CogDrawLineInfo();
                LineDraw(elementDraw.Value.ContactPointX, elementDraw.Value.OutputXYT.ToXY(), ref DisLineX);
                CogDrawLabelInfo labelDisLineX = new CogDrawLabelInfo();
               
                // LineY + Label
                CogDrawLineInfo DisLineY = new CogDrawLineInfo();
                LineDraw(elementDraw.Value.ContactPointY, elementDraw.Value.OutputXYT.ToXY(), ref DisLineY);
                CogDrawLabelInfo labelDisLineY = new CogDrawLabelInfo();
              
                switch (elementDraw.Key)
                {
                    case "InsArea1":
                        P1_DisplayObj.DrawMaker(ContactPointX);
                        WriteLabel(elementDraw.Value.ContactPointX, ref labelCpX, new XY(10,40), "ContactPointX");
                        P1_DisplayObj.DrawLabel(labelCpX);

                        P1_DisplayObj.DrawMaker(ContactPointY);
                        WriteLabel(elementDraw.Value.ContactPointY, ref labelCpY, new XY(10,70), "ContactPointY");
                        P1_DisplayObj.DrawLabel(labelCpY);

                        P1_DisplayObj.DrawMaker(CrossMark);
                        WriteLabel(elementDraw.Value.OutputXYT.ToXY(), ref labelCpMark, new XY(10,100), "CrossMark");
                        P1_DisplayObj.DrawLabel(labelCpMark);

                        P1_DisplayObj.DrawLine(DisLineX);
                        WriteLabel(elementDraw.Value.ContactPointX, elementDraw.Value.OutputXYT.ToXY(), 
                                   elementDraw.Value.RstDistance.X, ref labelDisLineX, new XY(0, 100), "X");
                        P1_DisplayObj.DrawLabel(labelDisLineX);

                        P1_DisplayObj.DrawLine(DisLineY);
                        WriteLabel(elementDraw.Value.ContactPointY, elementDraw.Value.OutputXYT.ToXY(), 
                                   elementDraw.Value.RstDistance.Y, ref labelDisLineY, new XY(150, 0), "Y");
                        P1_DisplayObj.DrawLabel(labelDisLineY);
                        break;

                    case "InsArea2":
                        P2_DisplayObj.DrawMaker(ContactPointX);
                        WriteLabel(elementDraw.Value.ContactPointX, ref labelCpX, new XY(10,40), "ContactPointX");
                        P2_DisplayObj.DrawLabel(labelCpX);

                        P2_DisplayObj.DrawMaker(ContactPointY);
                        WriteLabel(elementDraw.Value.ContactPointY, ref labelCpY, new XY(10, 70), "ContactPointY");
                        P2_DisplayObj.DrawLabel(labelCpY);

                        P2_DisplayObj.DrawMaker(CrossMark);
                        WriteLabel(elementDraw.Value.OutputXYT.ToXY(), ref labelCpMark, new XY(10, 100), "CrossMark");
                        P2_DisplayObj.DrawLabel(labelCpMark);

                        P2_DisplayObj.DrawLine(DisLineX);
                        WriteLabel(elementDraw.Value.ContactPointX, elementDraw.Value.OutputXYT.ToXY(), 
                                   elementDraw.Value.RstDistance.X, ref labelDisLineX, new XY(10, -150), "X");
                        P2_DisplayObj.DrawLabel(labelDisLineX);

                        P2_DisplayObj.DrawLine(DisLineY);
                        WriteLabel(elementDraw.Value.ContactPointY, elementDraw.Value.OutputXYT.ToXY(), 
                                   elementDraw.Value.RstDistance.Y, ref labelDisLineY, new XY(150, 00), "Y");
                        P2_DisplayObj.DrawLabel(labelDisLineY);
                        break;

                    case "InsArea3":
                        P3_DisplayObj.DrawMaker(ContactPointX);
                        WriteLabel(elementDraw.Value.ContactPointX, ref labelCpX, new XY(10, 40), "ContactPointX");
                        P3_DisplayObj.DrawLabel(labelCpX);

                        P3_DisplayObj.DrawMaker(ContactPointY);
                        WriteLabel(elementDraw.Value.ContactPointY, ref labelCpY, new XY(10, 70), "ContactPointY");
                        P3_DisplayObj.DrawLabel(labelCpY);

                        P3_DisplayObj.DrawMaker(CrossMark);
                        WriteLabel(elementDraw.Value.OutputXYT.ToXY(), ref labelCpMark, new XY(10, 100), "CrossMark");
                        P3_DisplayObj.DrawLabel(labelCpMark);

                        P3_DisplayObj.DrawLine(DisLineX);
                        WriteLabel(elementDraw.Value.ContactPointX, elementDraw.Value.OutputXYT.ToXY(), 
                                   elementDraw.Value.RstDistance.X, ref labelDisLineX, new XY(0, -150), "X");
                        P3_DisplayObj.DrawLabel(labelDisLineX);

                        P3_DisplayObj.DrawLine(DisLineY);
                        WriteLabel(elementDraw.Value.ContactPointY, elementDraw.Value.OutputXYT.ToXY(), 
                                   elementDraw.Value.RstDistance.Y, ref labelDisLineY, new XY(-150, 0), "Y");
                        P3_DisplayObj.DrawLabel(labelDisLineY);
                        break;
                    case "InsArea4":
                        P4_DisplayObj.DrawMaker(ContactPointX);
                        WriteLabel(elementDraw.Value.ContactPointX, ref labelCpX, new XY(10, 40), "ContactPointX");
                        P4_DisplayObj.DrawLabel(labelCpX);

                        P4_DisplayObj.DrawMaker(ContactPointY);
                        WriteLabel(elementDraw.Value.ContactPointY, ref labelCpY, new XY(10, 70), "ContactPointY");
                        P4_DisplayObj.DrawLabel(labelCpY);

                        P4_DisplayObj.DrawMaker(CrossMark);
                        WriteLabel(elementDraw.Value.OutputXYT.ToXY(), ref labelCpMark, new XY(10, 100), "CrossMark");
                        P4_DisplayObj.DrawLabel(labelCpMark);

                        P4_DisplayObj.DrawLine(DisLineX);
                        WriteLabel(elementDraw.Value.ContactPointX, elementDraw.Value.OutputXYT.ToXY(), 
                                   elementDraw.Value.RstDistance.X, ref labelDisLineX, new XY(0, 150), "X");
                        P4_DisplayObj.DrawLabel(labelDisLineX);

                        P4_DisplayObj.DrawLine(DisLineY);
                        WriteLabel(elementDraw.Value.ContactPointY, elementDraw.Value.OutputXYT.ToXY(), 
                                   elementDraw.Value.RstDistance.Y, ref labelDisLineY, new XY(150, 0), "Y");
                        P4_DisplayObj.DrawLabel(labelDisLineY);
                        break;
                }

                #region 짬
                //// ContactPoint_X + Label
                //CogDrawMarkerInfo ContactPointX = new CogDrawMarkerInfo();
                //MarkDraw(new XYT(elementDraw.Value.ContactPointX.X, elementDraw.Value.ContactPointX.Y, 0), ref ContactPointX);
                //CogDrawLabelInfo labelCpX = new CogDrawLabelInfo();
                //WriteLabel(elementDraw.Value.ContactPointX, ref labelCpX);

                //// ContactPoint_Y + Label
                //CogDrawMarkerInfo ContactPointY = new CogDrawMarkerInfo();
                //MarkDraw(new XYT(elementDraw.Value.ContactPointY.X, elementDraw.Value.ContactPointY.Y, 0), ref ContactPointY);
                //CogDrawLabelInfo labelCpY = new CogDrawLabelInfo();
                //WriteLabel(elementDraw.Value.ContactPointY, ref labelCpY);

                //// Line Cross Mark + Label
                //CogDrawMarkerInfo CrossMark = new CogDrawMarkerInfo();
                //MarkDraw(elementDraw.Value.OutputXYT, ref CrossMark);
                //CogDrawLabelInfo labelCpMark = new CogDrawLabelInfo();
                //WriteLabel(elementDraw.Value.OutputXYT.ToXY(), ref labelCpMark);

                //// LineX + Label
                //CogDrawLineInfo DisLineX = new CogDrawLineInfo();
                //LineDraw(elementDraw.Value.ContactPointX, elementDraw.Value.OutputXYT.ToXY(), ref DisLineX);
                //CogDrawLabelInfo labelDisLineX = new CogDrawLabelInfo();
                //WriteLabel(elementDraw.Value.ContactPointX, elementDraw.Value.OutputXYT.ToXY(), elementDraw.Value.RstDistance.X, ref labelDisLineX);

                //// LineY + Label
                //CogDrawLineInfo DisLineY = new CogDrawLineInfo();
                //LineDraw(elementDraw.Value.ContactPointY, elementDraw.Value.OutputXYT.ToXY(), ref DisLineY);
                //CogDrawLabelInfo labelDisLineY = new CogDrawLabelInfo();
                //WriteLabel(elementDraw.Value.ContactPointY, elementDraw.Value.OutputXYT.ToXY(), elementDraw.Value.RstDistance.Y, ref labelDisLineY);

                //switch (elementDraw.Key)
                //{
                //    case "InsArea1":
                //        P1_DisplayObj.DrawMaker(ContactPointX);
                //        P1_DisplayObj.DrawLabel(labelCpX);
                //        P1_DisplayObj.DrawMaker(ContactPointY);
                //        P1_DisplayObj.DrawLabel(labelCpY);
                //        P1_DisplayObj.DrawMaker(CrossMark);
                //        P1_DisplayObj.DrawLabel(labelCpMark);
                //        P1_DisplayObj.DrawLine(DisLineX);
                //        P1_DisplayObj.DrawLabel(labelDisLineX);
                //        P1_DisplayObj.DrawLine(DisLineY);                        
                //        P1_DisplayObj.DrawLabel(labelDisLineY);
                //        break;
                //    case "InsArea2":
                //        P2_DisplayObj.DrawMaker(ContactPointX);
                //        P2_DisplayObj.DrawLabel(labelCpX);
                //        P2_DisplayObj.DrawMaker(ContactPointY);
                //        P2_DisplayObj.DrawLabel(labelCpY);
                //        P2_DisplayObj.DrawMaker(CrossMark);
                //        P2_DisplayObj.DrawLabel(labelCpMark);
                //        P2_DisplayObj.DrawLine(DisLineX);
                //        P2_DisplayObj.DrawLabel(labelDisLineX);
                //        P2_DisplayObj.DrawLine(DisLineY);
                //        P2_DisplayObj.DrawLabel(labelDisLineY);
                //        break;
                //    case "InsArea3":
                //        P3_DisplayObj.DrawMaker(ContactPointX);
                //        P3_DisplayObj.DrawLabel(labelCpX);
                //        P3_DisplayObj.DrawMaker(ContactPointY);
                //        P3_DisplayObj.DrawLabel(labelCpY);
                //        P3_DisplayObj.DrawMaker(CrossMark);
                //        P3_DisplayObj.DrawLabel(labelCpMark);
                //        P3_DisplayObj.DrawLine(DisLineX);
                //        P3_DisplayObj.DrawLabel(labelDisLineX);
                //        P3_DisplayObj.DrawLine(DisLineY);
                //        P3_DisplayObj.DrawLabel(labelDisLineY);
                //        break;
                //    case "InsArea4":
                //        P4_DisplayObj.DrawMaker(ContactPointX);
                //        P4_DisplayObj.DrawLabel(labelCpX);
                //        P4_DisplayObj.DrawMaker(ContactPointY);
                //        P4_DisplayObj.DrawLabel(labelCpY);
                //        P4_DisplayObj.DrawMaker(CrossMark);
                //        P4_DisplayObj.DrawLabel(labelCpMark);
                //        P4_DisplayObj.DrawLine(DisLineX);
                //        P4_DisplayObj.DrawLabel(labelDisLineX);
                //        P4_DisplayObj.DrawLine(DisLineY);
                //        P4_DisplayObj.DrawLabel(labelDisLineY);
                //        break;
                //}
                #endregion
            }
            #endregion

            #region 6) Inspection Data 정합성 Judgement & Needs -> Revision
            bool alteredData = false;
            string alterArea = ""; 
            if (DistRevision == UseDistRevision.Use)
            {
                if (AccuracyCheck_DisX("InsArea1", "InsArea4", DisRsts, AccuracyTh) != true) { CompensateData_X("InsArea1", "InsArea4", ref DisRsts, ref alteredData, ref alterArea); }; // InsX1<->InsX4간 정합성 검증, 문제 시 수정!
                if (AccuracyCheck_DisX("InsArea2", "InsArea3", DisRsts, AccuracyTh) != true) { CompensateData_X("InsArea2", "InsArea3", ref DisRsts, ref alteredData, ref alterArea); };
                if (AccuracyCheck_DisY("InsArea1", "InsArea2", DisRsts, AccuracyTh) != true) { CompensateData_Y("InsArea1", "InsArea2", ref DisRsts, ref alteredData, ref alterArea); };
                if (AccuracyCheck_DisY("InsArea4", "InsArea3", DisRsts, AccuracyTh) != true) { CompensateData_Y("InsArea4", "InsArea3", ref DisRsts, ref alteredData, ref alterArea); };
            }
            #endregion

            #region 7) Center Align에 대한 판정
            Dictionary<string, double> RstCenterAlign = new Dictionary<string, double>();
            //if (JudgeInspection("InsArea1", "InsArea4", DisRsts, CenterSpec, TolSpec, ref RstCenterAlign) != true) { return false; } // <- errCode 심을 것
            //if (JudgeInspection("InsArea2", "InsArea3", DisRsts, CenterSpec, TolSpec, ref RstCenterAlign) != true) { return false; }
            //if (JudgeInspection("InsArea1", "InsArea2", DisRsts, CenterSpec, TolSpec, ref RstCenterAlign) != true) { return false; }
            //if (JudgeInspection("InsArea4", "InsArea3", DisRsts, CenterSpec, TolSpec, ref RstCenterAlign) != true) { return false; }

            if (JudgeInspection("InsArea1", "InsArea4", DisRsts, CenterSpec, TolSpec, ref RstCenterAlign) != true) { bool a = false; } // <- return으로 넣을 것, 지금은 Test 
            if (JudgeInspection("InsArea2", "InsArea3", DisRsts, CenterSpec, TolSpec, ref RstCenterAlign) != true) { bool b = false; }
            if (JudgeInspection("InsArea1", "InsArea2", DisRsts, CenterSpec, TolSpec, ref RstCenterAlign) != true) { bool c = false; }
            if (JudgeInspection("InsArea4", "InsArea3", DisRsts, CenterSpec, TolSpec, ref RstCenterAlign) != true) { bool d = false; }
            #endregion

            #region 8) Log 및 결과값 
            AlgoRst = new Algo4P_Dist_InspectionResult
            {
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                ID = productID,

                UpperCAlign = RstCenterAlign["UpperCenterAlign"],
                LowerCAlign = RstCenterAlign["LowerCenterAlign"],
                LeftCAlign  = RstCenterAlign["LeftCenterAlign"],
                RightCAlign = RstCenterAlign["RightCenterAlign"],

                Dis1_X = DisRsts["InsArea1"].RstDistance.X,
                Dis1_Y = DisRsts["InsArea1"].RstDistance.Y,
                Dis2_X = DisRsts["InsArea2"].RstDistance.X,
                Dis2_Y = DisRsts["InsArea2"].RstDistance.Y,
                Dis3_X = DisRsts["InsArea3"].RstDistance.X,
                Dis3_Y = DisRsts["InsArea3"].RstDistance.Y,
                Dis4_X = DisRsts["InsArea4"].RstDistance.X,
                Dis4_Y = DisRsts["InsArea4"].RstDistance.Y,

                AlterData = alteredData,
                AlterArea = alterArea
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region 10) FDC Inspection Data Upload 
            // UploadFDCdata(DisRsts, RstCenterAlign);
            #endregion

            StopTimer();

            return true;
        }
        #endregion

        #region Side Methode
        public void UploadFDCdata(Dictionary<string, DisRstData> DisRsts, Dictionary<string, double> RstCenterAlign)
        {
            visionValues["InspectionRev_X"].NextValue = RstCenterAlign["UpperCenterAlign"];
            visionValues["InspectionRev_Y"].NextValue = RstCenterAlign["LowerCenterAlign"];
            visionValues["InspectionRev_T"].NextValue = RstCenterAlign["LeftCenterAlign"];
            visionValues["InspectionRev"].NextValue   = RstCenterAlign["RightCenterAlign"];

            foreach (var _disRst in DisRsts)
            {
                switch(_disRst.Key)
                {
                    case "InsArea1":
                        visionValues["InspDistX1"].NextValue = _disRst.Value.RstDistance.X as object;
                        visionValues["InspDistY1"].NextValue = _disRst.Value.RstDistance.Y as object;
                        break;
                    case "InsArea2":
                        visionValues["InspDistX2"].NextValue = _disRst.Value.RstDistance.X as object;
                        visionValues["InspDistY2"].NextValue = _disRst.Value.RstDistance.Y as object;
                        break;
                    case "InsArea3":
                        visionValues["InspDistX3"].NextValue = _disRst.Value.RstDistance.X as object;
                        visionValues["InspDistY3"].NextValue = _disRst.Value.RstDistance.Y as object;
                        break;
                    case "InsArea4":
                        visionValues["InspDistX4"].NextValue = _disRst.Value.RstDistance.X as object;
                        visionValues["InspDistY4"].NextValue = _disRst.Value.RstDistance.Y as object;
                        break;
                }
            }
        }

        public void CompensateData_X(string _key1, string _key2, ref Dictionary<string, DisRstData> DisRsts, ref bool AlteredData, ref string AlterArea)
        {
            //* Diff = Abs(실제Dis - 이상치 거리) 
            double DiffKey1 = Math.Abs(DisRsts[_key1].RstDistance.X - DisRsts[_key1].DisXY.X);
            double DiffKey2 = Math.Abs(DisRsts[_key2].RstDistance.X - DisRsts[_key2].DisXY.X);
            double RealSumDisXY = DisRsts[_key1].DisXY.X + DisRsts[_key2].DisXY.X;
            if (DiffKey1 > DiffKey2) //* 이상치 대비 큰 쪽을 수정해 줌.
            {
                DisRsts[_key1].RstDistance.X = RealSumDisXY - DisRsts[_key2].RstDistance.X;
                AlteredData = true;
                AlterArea += "(" + _key1 + "_X)";
            }
            else
            {
                DisRsts[_key2].RstDistance.X = RealSumDisXY - DisRsts[_key1].RstDistance.X;
                AlteredData = true;
                AlterArea += "(" + _key2 + "_X)";
            }
        }

        public void CompensateData_Y(string _key1, string _key2, ref Dictionary<string, DisRstData> DisRsts, ref bool AlteredData, ref string AlterArea)
        {
            double DiffKey1 = Math.Abs(DisRsts[_key1].RstDistance.Y - DisRsts[_key1].DisXY.Y);
            double DiffKey2 = Math.Abs(DisRsts[_key2].RstDistance.Y - DisRsts[_key2].DisXY.Y);
            double RealSumDisXY = DisRsts[_key1].DisXY.Y + DisRsts[_key2].DisXY.Y;
            if (DiffKey1 > DiffKey2)
            {
                DisRsts[_key1].RstDistance.Y = RealSumDisXY - DisRsts[_key2].RstDistance.Y;
                AlteredData = true;
                AlterArea += "(" + _key1 + "_Y)";
            }
            else
            {
                DisRsts[_key2].RstDistance.Y = RealSumDisXY - DisRsts[_key1].RstDistance.Y;
                AlteredData = true;
                AlterArea += "(" + _key1 + "_Y)";
            }
        }

        public bool JudgeInspection(string _key1, string _key2, Dictionary<string, DisRstData> DisRsts, Dictionary<string, double> CenterSpec, Dictionary<string, double> TolSpec, ref Dictionary<string, double> RstCenterAlign)
        {
            string sumKey = _key1 + "_" + _key2;
            double CAlignValue = 0;
            switch (sumKey)
            {
                case "InsArea1_InsArea4":
                    CAlignValue = (DisRsts[_key1].RstDistance.X - DisRsts[_key2].RstDistance.X) / 2;
                    RstCenterAlign.Add("UpperCenterAlign", CAlignValue);
                    if ((CAlignValue > CenterSpec["UpperCenter"] + TolSpec["UpperTol"]) ||
                         CAlignValue < CenterSpec["UpperCenter"] - TolSpec["UpperTol"]) { return false; }
                    break;
                case "InsArea2_InsArea3":
                    CAlignValue = (DisRsts[_key1].RstDistance.X - DisRsts[_key2].RstDistance.X) / 2;
                    RstCenterAlign.Add("LowerCenterAlign", CAlignValue);
                    if ((CAlignValue > CenterSpec["LowerCenter"] + TolSpec["LowerTol"]) ||
                         CAlignValue < CenterSpec["LowerCenter"] - TolSpec["LowerTol"]) { return false; }
                    break;
                case "InsArea1_InsArea2":
                    CAlignValue = (DisRsts[_key1].RstDistance.Y - DisRsts[_key2].RstDistance.Y) / 2;
                    RstCenterAlign.Add("LeftCenterAlign", CAlignValue);
                    if ((CAlignValue > CenterSpec["LeftCenter"] + TolSpec["LeftTol"]) ||
                         CAlignValue < CenterSpec["LeftCenter"] - TolSpec["LeftTol"]) { return false; }
                    break;
                case "InsArea4_InsArea3":
                    CAlignValue = (DisRsts[_key1].RstDistance.Y - DisRsts[_key2].RstDistance.Y) / 2;
                    RstCenterAlign.Add("RightCenterAlign", CAlignValue);
                    if ((CAlignValue > CenterSpec["RightCenter"] + TolSpec["RightTol"]) ||
                         CAlignValue < CenterSpec["RightCenter"] - TolSpec["RightTol"]) { return false; }
                    break;
            }

            return true;
        }

        public bool AccuracyCheck_DisX(string _key1, string _key2, Dictionary<string, DisRstData> DisRsts, double AccuracyTh)
        {
            double sumDis = DisRsts[_key1].RstDistance.X + DisRsts[_key2].RstDistance.X; //* 실제sum
            double sumDesignDis = DisRsts[_key1].DisXY.X + DisRsts[_key2].DisXY.X;       //* 이상sum
            if(Math.Abs(sumDis - sumDesignDis) > AccuracyTh) { return false; }
            return true;
        }

        public bool AccuracyCheck_DisY(string _key1, string _key2, Dictionary<string, DisRstData> DisRsts, double AccuracyTh)
        {
            double sumDis = DisRsts[_key1].RstDistance.Y + DisRsts[_key2].RstDistance.Y; //* 실제sum
            double sumDesignDis = DisRsts[_key1].DisXY.Y + DisRsts[_key2].DisXY.Y;       //* 이상sum
            if (Math.Abs(sumDis - sumDesignDis) > AccuracyTh) { return false; }
            return true;
        }

        public void WriteLabel(XY Point, ref CogDrawLabelInfo labelInfo, XY _location, string _name)
        {
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Color = CogColorConstants.Black;
            //labelInfo.Offset = Point + new XY(20,20);
            labelInfo.Offset = _location;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format(_name + "({0:f2},{0:f2})", Point.X, Point.Y);
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineLeft;
        }

        public void WriteLabel(XY startPoint, XY endPoint, double Dis, ref CogDrawLabelInfo labelInfo, XY _location, string _name)
        {            
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Color = CogColorConstants.Red;
            labelInfo.Offset = new XY((startPoint+ endPoint)/2) + _location;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("Dis" + _name + ": {0:f2}um", Dis);
        }

        public void LineDraw(XY startPoint, XY endPoint, ref CogDrawLineInfo DisLine)
        {
            DisLine.LineWidthInScreenPixels = 2;
            DisLine.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            DisLine.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            DisLine.Color = CogColorConstants.Red;
            DisLine.Start = startPoint;
            DisLine.End = endPoint;
        }
        public void MarkDraw(XYT Point, ref CogDrawMarkerInfo ContactPoint)
        {
            // Contact Point_X    
            ContactPoint.SizeInScreenPixels = 2;
            ContactPoint.Color = CogColorConstants.Purple;
            ContactPoint.Offset = Point;
        }

        protected bool InitInsp_Err(ref Dictionary<string, bool> errCode)
        {
            errCode.Add("Err_Obtain_InputData", true);
            errCode.Add("Err_Cal_MarkToLine", true);
            return true;
        }


        public override void DefaultIOSet()
        {
            base.DefaultIOSet();

            plcValues = new Dictionary<string, IOStruct>();
            visionValues = new Dictionary<string, IOStruct>();



            // 해당 하는 io를 가져온다.
            //PlcIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();
            //VisionIOs = new System.Collections.ObjectModel.ObservableCollection<IOStruct>();

            plcValues.Clear();
            visionValues.Clear();


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    PlcIOs.Add(item);
                    plcValues.Add(item.Key, item);
                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    VisionIOs.Add(item);
                    visionValues.Add(item.Key, item);
                }
            }
        }
        public override void ObjectInitialize()
        {
            base.ObjectInitialize();

            if (AlignTableObject == null) return;


            foreach (var item in AlignTableObject.Plc.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    if (!plcValues.ContainsKey(item.Key))
                    {
                        plcValues.Add(item.Key, item);
                    }

                }
            }
            foreach (var item in AlignTableObject.Vision.IOs)
            {
                if (item.Type.Name != "Boolean" && !item.Key.Contains("Reserve"))
                {
                    if (!visionValues.ContainsKey(item.Key))
                    {
                        visionValues.Add(item.Key, item);
                    }
                }
            }
        }

        protected bool InputDataConfirm(ref Dictionary<string, object> InputData, ref Dictionary<string, bool> errCode)
        {
            try
            {
                InputData["InsArea1"] = InputValues["InsArea1"] as Dictionary<string, object>;
                InputData["InsArea2"] = InputValues["InsArea2"] as Dictionary<string, object>;
                InputData["InsArea3"] = InputValues["InsArea3"] as Dictionary<string, object>;
                InputData["InsArea4"] = InputValues["InsArea4"] as Dictionary<string, object>;

                foreach (var pair in InputData)
                {
                    if (pair.Value == null)
                    {
                        errCode["Err_Obtain_InputData"] = false;
                        return false;
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                errCode["Err_Obtain_InputData"] = false;
                return false;
            }
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void ObjectUpdate()
        {
            base.ObjectUpdate();

            PlcIOsListConverter.Module = CommObj;
            VisionIOsListConverter.Module = CommObj;
        }
        #endregion
    }
}
