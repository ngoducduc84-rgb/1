﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.Algo4P_Dist_Inspection
{
    class Algo4P_Dist_InspectionOutputParams : OutputParams
    {
        public object LogResult { get; set; }
    }
}
