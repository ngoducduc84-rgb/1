﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.AlgoMeasure_LJ_V7000;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.AlgoMeasure_LJ_V7000
{
    [SerializableAttribute]
    public partial class AlgoMeasure_LJ_V7000Action : AlgoActionBase
    {
        #region [Fields]      
        #endregion

        #region [Properties]   
        #endregion

        #region [Construct]
        public AlgoMeasure_LJ_V7000Action(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new AlgoMeasure_LJ_V7000InputParams();
            OutputParams = new AlgoMeasure_LJ_V7000OutputParams();

            var obj = _object as AlgoMeasure_LJ_V7000Object;
            obj.ModelParamType = typeof(AlgoMeasure_LJ_V7000AlignModelParams);
            var param = obj.CurParams as AlgoMeasure_LJ_V7000AlignModelParams;

        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as AlgoMeasure_LJ_V7000Object;


            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                if (!Obj.Run())
                {
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                    return OccurError(Obj.ErrorCode);
                }
                #endregion

                #region Step2 : Result Data Show
                ReplyArgs = OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                #endregion

                Obj.AppendMessage(Name, "Caluration Complete");
                StopTimer();
            }

            return End(false);
        }
        public override void PrepareSave() { base.PrepareSave(); }
        public override void Dispose() { base.Dispose(); }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion

        #region [Command]
        #endregion


    }
}
