﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.AlgoMeasure_LJ_V7000
{
    [SerializableAttribute]
    class AlgoMeasure_LJ_V7000InputParams : InputParams
    {
        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
