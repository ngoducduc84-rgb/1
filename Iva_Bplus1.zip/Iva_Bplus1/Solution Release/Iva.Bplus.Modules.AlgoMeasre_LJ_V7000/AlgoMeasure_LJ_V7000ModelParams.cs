﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.AlgoMeasure_LJ_V7000
{
    [SerializableAttribute]

    public partial class AlgoMeasure_LJ_V7000AlignModelParams : AlgoParams
    {
        //private AlgoParam limitX;
        //private AlgoParam limitY;
        //private AlgoParam limitT;
        //private AlgoParam spec_Length;
        //private AlgoParam tor_Length;
        //private AlgoParam scale_Length;
        //public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        //public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        //public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        //public AlgoParam Spec_Length { get { return spec_Length; } set { if (spec_Length == value) return; spec_Length = value; this.OnPropertyChanged(nameof(Spec_Length)); } }
        //public AlgoParam Tor_Length { get { return tor_Length; } set { if (tor_Length == value) return; tor_Length = value; this.OnPropertyChanged(nameof(Tor_Length)); } }
        //public AlgoParam Scale_Length { get { return scale_Length; } set { if (scale_Length == value) return; scale_Length = value; this.OnPropertyChanged(nameof(Scale_Length)); } }


        public AlgoMeasure_LJ_V7000AlignModelParams()
            : base()
        {
            //LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            //LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            //LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);
            //Spec_Length = new AlgoParam("Spec_Length", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)1000);
            //Tor_Length = new AlgoParam("Tor_Length", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)2);
            //Scale_Length = new AlgoParam("Scale_Length", "mm", typeof(double), 0.0, "Length Scale", (double)0, (double)2);
        }
    }
}
