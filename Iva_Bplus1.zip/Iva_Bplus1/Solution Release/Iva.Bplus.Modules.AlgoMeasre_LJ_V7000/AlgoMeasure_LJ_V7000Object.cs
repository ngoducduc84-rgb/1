﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.LJ_V7000_Sensor;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.AlgoMeasure_LJ_V7000
{
    [SerializableAttribute]
    public partial class AlgoMeasure_LJ_V7000Object : AlgoObjectBase
    {
        #region [Fields]
        private string sensorContollor;
        private int deviceNo;
        #endregion

        #region [properties]
        public LJ_V7000_SensorObject SensorObject
        {
            get { return SystemObject_Device.GetObject(sensorContollor) as LJ_V7000_SensorObject; }
        }
        public string SensorContollor
        {
            get { return sensorContollor; }
            set { if (sensorContollor == value) return; sensorContollor = value; this.OnPropertyChanged(nameof(SensorContollor)); }
        }
        public int DeviceNo
        {
            get { return deviceNo; }
            set { if (deviceNo == value) return; deviceNo = value; this.OnPropertyChanged(nameof(DeviceNo)); }
        }

        public ObservableCollection<string> SensorContollorList
        {
            get
            {
                ObservableCollection<string> lst = new ObservableCollection<string>();
                var canvas = SystemObject_Device.GetCanvas();
                foreach(var shape in canvas.System.Items)
                {
                    if(shape.ModAction is LJ_V7000_SensorAction)
                        lst.Add(shape.ModAction.Name);
                }
                return lst;
            }
        }
        #endregion

        #region[Construct]
        public AlgoMeasure_LJ_V7000Object()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new AlgoMeasure_LJ_V7000AlignModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run()
        {
            CommodObject.GetPlcValue(PlcValues["OptionNo"]);
            int option = (int)PlcValues["OptionNo"].CurValue;

            if ((CommandType)option != CommandType.Logging)
                return Measure();
            else
                return Logging();
        }
        public override void ObjectInitialize()
        {
            SensorEthernetOpen();

            base.ObjectInitialize();
        }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool Measure()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            // 1~12 두께 측정 위치
            // 20 로그 저장.
            int option = (int)PlcValues["OptionNo"].CurValue;

            #region Model Data prepare ( 일단 없다.)
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as AlgoMeasure_LJ_V7000AlignModelParams;
            #endregion

            #region Sensor Measurement
            
            // 시나리오 확인 필요함...
            // 이게 아닌듯...?ㅋ
            // 시나리오 확인 필요함...
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new AlgoMeasure_LJ_V7000AlignResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Type = CommandType.Measure.ToString(),
                Thickness1 = Math.Round(0.0, 3),
                Thickness2 = Math.Round(0.0, 3),
                Thickness3 = Math.Round(0.0, 3),
                Thickness4 = Math.Round(0.0, 3),
                Thickness5 = Math.Round(0.0, 3),
                Thickness6 = Math.Round(0.0, 3),
                Thickness7 = Math.Round(0.0, 3),
                Thickness8 = Math.Round(0.0, 3),
                Thickness9 = Math.Round(0.0, 3),
                Thickness10 = Math.Round(0.0, 3),
                Thickness11 = Math.Round(0.0, 3),
                Thickness12 = Math.Round(0.0, 3),
                Thickness13 = Math.Round(0.0, 3),
                Thickness14 = Math.Round(0.0, 3),
                Thickness15 = Math.Round(0.0, 3),
                Thickness16 = Math.Round(0.0, 3),
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO();
            #endregion
            return true;
        }

        private bool Logging()
        {
            UpdatePLCIOs();

            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region Model Data prepare ( 일단 없다.)
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as AlgoMeasure_LJ_V7000AlignModelParams;
            #endregion


            double thickness1 = (double)PlcValues["Thickness#1"].CurValue;
            double thickness2 = (double)PlcValues["Thickness#2"].CurValue;
            double thickness3 = (double)PlcValues["Thickness#3"].CurValue;
            double thickness4 = (double)PlcValues["Thickness#4"].CurValue;
            double thickness5 = (double)PlcValues["Thickness#5"].CurValue;
            double thickness6 = (double)PlcValues["Thickness#6"].CurValue;
            double thickness7 = (double)PlcValues["Thickness#7"].CurValue;
            double thickness8 = (double)PlcValues["Thickness#8"].CurValue;
            double thickness9 = (double)PlcValues["Thickness#9"].CurValue;
            double thickness10 = (double)PlcValues["Thickness#10"].CurValue;
            double thickness11 = (double)PlcValues["Thickness#11"].CurValue;
            double thickness12 = (double)PlcValues["Thickness#12"].CurValue;
            double thickness13 = (double)PlcValues["Thickness#13"].CurValue;
            double thickness14 = (double)PlcValues["Thickness#14"].CurValue;
            double thickness15 = (double)PlcValues["Thickness#15"].CurValue;
            double thickness16 = (double)PlcValues["Thickness#16"].CurValue;

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new AlgoMeasure_LJ_V7000AlignResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Type = CommandType.Logging.ToString(),
                Thickness1 = Math.Round(thickness1, 3),
                Thickness2 = Math.Round(thickness2, 3),
                Thickness3 = Math.Round(thickness3, 3),
                Thickness4 = Math.Round(thickness4, 3),
                Thickness5 = Math.Round(thickness5, 3),
                Thickness6 = Math.Round(thickness6, 3),
                Thickness7 = Math.Round(thickness7, 3),
                Thickness8 = Math.Round(thickness8, 3),
                Thickness9 = Math.Round(thickness9, 3),
                Thickness10 = Math.Round(thickness10, 3),
                Thickness11 = Math.Round(thickness11, 3),
                Thickness12 = Math.Round(thickness12, 3),
                Thickness13 = Math.Round(thickness13, 3),
                Thickness14 = Math.Round(thickness14, 3),
                Thickness15 = Math.Round(thickness15, 3),
                Thickness16 = Math.Round(thickness16, 3),
            };

            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO();
            #endregion
            return true;
        }
        #endregion

        #region public method
        public void WriteVisionIO()
        {
            var IOs = new List<IOStruct>();

            VisionValues["Thickness#1"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#1"]);
            VisionValues["Thickness#2"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#2"]);
            VisionValues["Thickness#3"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#3"]);
            VisionValues["Thickness#4"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#4"]);
            VisionValues["Thickness#5"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#5"]);
            VisionValues["Thickness#6"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#6"]);
            VisionValues["Thickness#7"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#7"]);
            VisionValues["Thickness#8"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#8"]);
            VisionValues["Thickness#9"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#9"]);
            VisionValues["Thickness#10"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#10"]);
            VisionValues["Thickness#11"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#11"]);
            VisionValues["Thickness#12"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#12"]);
            VisionValues["Thickness#13"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#13"]);
            VisionValues["Thickness#14"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#14"]);
            VisionValues["Thickness#15"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#15"]);
            VisionValues["Thickness#16"].NextValue = (double)0; IOs.Add(VisionValues["Thickness#16"]);
            CommodObject.SetVisionValues(IOs);
        }

        public bool SensorEthernetOpen()
        {
            LJV7IF_ETHERNET_CONFIG ethernetConfig = new LJV7IF_ETHERNET_CONFIG();
            ethernetConfig.abyIpAddress = new byte[4];
            ethernetConfig.abyIpAddress[0] = 192;
            ethernetConfig.abyIpAddress[1] = 168;
            ethernetConfig.abyIpAddress[2] = 0;
            ethernetConfig.abyIpAddress[3] = 1;
            ethernetConfig.wPortNo = 24691;
            return SensorObject.EthernetOpen(deviceNo, ethernetConfig);
        }
        #endregion

    }
}

