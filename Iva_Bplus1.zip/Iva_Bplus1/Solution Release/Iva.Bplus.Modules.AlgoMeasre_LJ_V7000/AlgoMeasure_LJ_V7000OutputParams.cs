﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.AlgoMeasure_LJ_V7000
{
    class AlgoMeasure_LJ_V7000OutputParams : OutputParams
    {
        #region Logging
        public object Result { get; set; }
        #endregion
    }
}
