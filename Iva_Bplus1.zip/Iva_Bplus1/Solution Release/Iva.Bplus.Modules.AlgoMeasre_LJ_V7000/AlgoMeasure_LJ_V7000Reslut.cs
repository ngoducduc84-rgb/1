﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.AlgoMeasure_LJ_V7000
{
    [SerializableAttribute]
    public class AlgoMeasure_LJ_V7000AlignResult : AlgoResultBase
    {
        #region [fiedls]
        private string type;
        private double thickness1;
        private double thickness2;
        private double thickness3;
        private double thickness4;
        private double thickness5;
        private double thickness6;
        private double thickness7;
        private double thickness8;
        private double thickness9;
        private double thickness10;
        private double thickness11;
        private double thickness12;
        private double thickness13;
        private double thickness14;
        private double thickness15;
        private double thickness16;

        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string Type
        {
            get { return type; }
            set { if (value == type) return; type = value; OnPropertyChanged(nameof(Type)); }
        }

        public double Thickness1
        {
            get { return thickness1; }
            set { if (value == thickness1) return; thickness1 = value; OnPropertyChanged(nameof(Thickness1)); }
        }
        public double Thickness2
        {
            get { return thickness2; }
            set { if (value == thickness2) return; thickness2 = value; OnPropertyChanged(nameof(Thickness2)); }
        }
        public double Thickness3
        {
            get { return thickness3; }
            set { if (value == thickness3) return; thickness3 = value; OnPropertyChanged(nameof(Thickness3)); }
        }
        public double Thickness4
        {
            get { return thickness4; }
            set { if (value == thickness4) return; thickness4 = value; OnPropertyChanged(nameof(Thickness4)); }
        }
        public double Thickness5
        {
            get { return thickness5; }
            set { if (value == thickness5) return; thickness5 = value; OnPropertyChanged(nameof(Thickness5)); }
        }
        public double Thickness6
        {
            get { return thickness6; }
            set { if (value == thickness6) return; thickness6 = value; OnPropertyChanged(nameof(Thickness6)); }
        }
        public double Thickness7
        {
            get { return thickness7; }
            set { if (value == thickness7) return; thickness7 = value; OnPropertyChanged(nameof(Thickness7)); }
        }
        public double Thickness8
        {
            get { return thickness8; }
            set { if (value == thickness8) return; thickness8 = value; OnPropertyChanged(nameof(Thickness8)); }
        }
        public double Thickness9
        {
            get { return thickness9; }
            set { if (value == thickness9) return; thickness9 = value; OnPropertyChanged(nameof(Thickness9)); }
        }
        public double Thickness10
        {
            get { return thickness10; }
            set { if (value == thickness10) return; thickness10 = value; OnPropertyChanged(nameof(Thickness10)); }
        }
        public double Thickness11
        {
            get { return thickness11; }
            set { if (value == thickness11) return; thickness11 = value; OnPropertyChanged(nameof(Thickness11)); }
        }
        public double Thickness12
        {
            get { return thickness12; }
            set { if (value == thickness12) return; thickness12 = value; OnPropertyChanged(nameof(Thickness12)); }
        }
        public double Thickness13
        {
            get { return thickness13; }
            set { if (value == thickness13) return; thickness13 = value; OnPropertyChanged(nameof(Thickness13)); }
        }
        public double Thickness14
        {
            get { return thickness14; }
            set { if (value == thickness14) return; thickness14 = value; OnPropertyChanged(nameof(Thickness14)); }
        }

        public double Thickness15
        {
            get { return thickness15; }
            set { if (value == thickness15) return; thickness15 = value; OnPropertyChanged(nameof(Thickness15)); }
        }
        public double Thickness16
        {
            get { return thickness16; }
            set { if (value == thickness16) return; thickness16 = value; OnPropertyChanged(nameof(Thickness16)); }
        }
        #endregion


        public AlgoMeasure_LJ_V7000AlignResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n "
                                  , typeof(AlgoMeasure_LJ_V7000AlignResult).ToString(), curTime, curDate
                                  );
        }

    }
}
