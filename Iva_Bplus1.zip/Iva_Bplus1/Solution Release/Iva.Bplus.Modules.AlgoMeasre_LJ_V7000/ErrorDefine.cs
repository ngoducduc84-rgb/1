﻿using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoMeasure_LJ_V7000
{
    public partial class AlgoMeasure_LJ_V7000Action
    {
        #region [Error Script] AlgoMeasure_LJ_V7000Action: 16001 ~ 16100

        public override void ErrorDefine()
        {
            base.ErrorDefine();
        }
        #endregion
    }
}
