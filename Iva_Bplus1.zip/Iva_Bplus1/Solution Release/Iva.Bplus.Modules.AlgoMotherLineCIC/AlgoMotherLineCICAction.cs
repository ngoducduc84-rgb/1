﻿using Cognex.VisionPro.Display;
using Cognex.VisionPro.ImageFile;

using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.AlgoMotherLineCIC;
using Iva.Bplus.Modules.CogDisplay;
using Iva.Bplus.Struct;

//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using Telerik.Windows.Controls;

//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    [SerializableAttribute]
    public partial class AlgoMotherLineCICAction : AlgoActionBase
    {
        #region [Fields]

        [field: NonSerialized]
        private double cur_Lx;

        [field: NonSerialized]
        private double cur_Ly;

        [field: NonSerialized]
        private double cur_Rx;

        [field: NonSerialized]
        private double cur_Ry;

        [field: NonSerialized]
        private double cur_Length;

        [field: NonSerialized]
        private bool judge_Lx;

        [field: NonSerialized]
        private bool judge_Ly;

        [field: NonSerialized]
        private bool judge_Rx;

        [field: NonSerialized]
        private bool judge_Ry;

        [field: NonSerialized]
        private bool judge_Length;

        [field: NonSerialized]
        private AlgoParam temp_Lx;

        [field: NonSerialized]
        private AlgoParam temp_Ly;

        [field: NonSerialized]
        private AlgoParam temp_Rx;

        [field: NonSerialized]
        private AlgoParam temp_Ry;

        [field: NonSerialized]
        private AlgoParam temp_Length;

        //2Point Align
        [field: NonSerialized]
        private bool useUnloadOffset;

        #endregion [Fields]

        #region [Properties]

        public double Cur_Lx { get { return cur_Lx; } set { if (cur_Lx == value) return; cur_Lx = value; this.OnPropertyChanged(nameof(Cur_Lx)); } }
        public double Cur_Ly { get { return cur_Ly; } set { if (cur_Ly == value) return; cur_Ly = value; this.OnPropertyChanged(nameof(Cur_Ly)); } }
        public double Cur_Rx { get { return cur_Rx; } set { if (cur_Rx == value) return; cur_Rx = value; this.OnPropertyChanged(nameof(Cur_Rx)); } }
        public double Cur_Ry { get { return cur_Ry; } set { if (cur_Ry == value) return; cur_Ry = value; this.OnPropertyChanged(nameof(Cur_Ry)); } }
        public bool Judge_Lx { get { return judge_Lx; } set { if (judge_Lx == value) return; judge_Lx = value; this.OnPropertyChanged(nameof(Judge_Lx)); } }
        public bool Judge_Ly { get { return judge_Ly; } set { if (judge_Ly == value) return; judge_Ly = value; this.OnPropertyChanged(nameof(Judge_Ly)); } }
        public bool Judge_Rx { get { return judge_Rx; } set { if (judge_Rx == value) return; judge_Rx = value; this.OnPropertyChanged(nameof(Judge_Rx)); } }
        public bool Judge_Ry { get { return judge_Ry; } set { if (judge_Ry == value) return; judge_Ry = value; this.OnPropertyChanged(nameof(Judge_Ry)); } }

        public double Cur_Length { get { return cur_Length; } set { if (cur_Length == value) return; cur_Length = value; this.OnPropertyChanged(nameof(Cur_Length)); } }
        public bool Judge_Length { get { return judge_Length; } set { if (judge_Length == value) return; judge_Length = value; this.OnPropertyChanged(nameof(Judge_Length)); } }

        public AlgoParam Temp_Lx { get { return temp_Lx; } set { if (temp_Lx == value) return; temp_Lx = value; this.OnPropertyChanged(nameof(Temp_Lx)); } }
        public AlgoParam Temp_Ly { get { return temp_Ly; } set { if (temp_Ly == value) return; temp_Ly = value; this.OnPropertyChanged(nameof(Temp_Ly)); } }
        public AlgoParam Temp_Rx { get { return temp_Rx; } set { if (temp_Rx == value) return; temp_Rx = value; this.OnPropertyChanged(nameof(Temp_Rx)); } }
        public AlgoParam Temp_Ry { get { return temp_Ry; } set { if (temp_Ry == value) return; temp_Ry = value; this.OnPropertyChanged(nameof(Temp_Ry)); } }
        public AlgoParam Temp_Length { get { return temp_Ry; } set { if (temp_Ry == value) return; temp_Ry = value; this.OnPropertyChanged(nameof(Temp_Length)); } }

        //2Point Align
        public bool UseUnloadOffset { get { return useUnloadOffset; } set { if (useUnloadOffset == value) return; useUnloadOffset = value; this.OnPropertyChanged(nameof(UseUnloadOffset)); } }

        #endregion [Properties]

        #region [Construct]

        public AlgoMotherLineCICAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new AlgoMotherLineCICInputParams();
            var obj = _object as AlgoMotherLineCICObject;

            #region Process Tyep  으로 구별

            ProcessType type = obj.ProcessType;

            if (type == ProcessType.PanelPreAlign || type == ProcessType.TapePreAlign)
            {
                OutputParams = new AlogMotherLineCIC2PointOuputParams();
                obj.ModelParamType = typeof(AlogMotherLineCIC2PointModelParams);
                obj.CreateParams();
                var param = obj.CurParams as AlogMotherLineCIC2PointModelParams;

                ChildSettingView = new Model2PointSetting();
                ChildSettingView.DataContext = this;

                temp_Length = new AlgoParam(param.Scale_Length);
                temp_Length.Value = 0.0;
            }
            else if (type == ProcessType.MainAlign || type == ProcessType.Inspection)
            {
                OutputParams = new AlgoMotherLineCICOutputParams();
                obj.ModelParamType = typeof(AlgoMotherLineCICModelParams);
                obj.CreateParams();
                var param = obj.CurParams as AlgoMotherLineCICModelParams;

                ChildSettingView = new AlignSetting();
                ChildSettingView.DataContext = this;

                temp_Lx = new AlgoParam(param.Scale_Lx);
                temp_Lx.Value = 0.0;
                temp_Ly = new AlgoParam(param.Scale_Ly);
                temp_Ly.Value = 0.0;
                temp_Rx = new AlgoParam(param.Scale_Rx);
                temp_Rx.Value = 0.0;
                temp_Ry = new AlgoParam(param.Scale_Ry);
                temp_Ry.Value = 0.0;
            }

            #endregion Process Tyep  으로 구별

            ModObject.PropertyChanged += ModObjct_PropertyChanged;
            SystemInfo.SetEPLabel("test");
        }

        #endregion [Construct]

        /// <summary>
        /// Type 에 따라서 Porperties 및 setting 변경을 위한 Event 모듈
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ModObjct_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            var obj = sender as AlgoMotherLineCICObject;

            #region Process Type 으로 구별

            if (e.PropertyName == "ProcessType")
            {
                obj.PropertiesChange(obj.ProcessType);

                if (obj.ProcessType == ProcessType.PanelPreAlign)
                {
                    OutputParams = new AlogMotherLineCIC2PointOuputParams();
                    obj.ModelParamType = typeof(AlogMotherLineCIC2PointModelParams);
                    var param = obj.CurParams as AlogMotherLineCIC2PointModelParams;

                    ChildSettingView = new Model2PointSetting();
                    ChildSettingView.DataContext = this;
                }
                else if (obj.ProcessType == ProcessType.TapePreAlign)
                {
                    //todo : Tape Align 을 2Point 로 변경 할 경우 아래 로직을 상단 if 로 이동 시키십시오
                    OutputParams = new AlogMotherLineCIC2PointOuputParams();
                    obj.ModelParamType = typeof(AlgoMotherLineCICTape2PointModelParams);
                    var param = obj.CurParams as AlgoMotherLineCICTape2PointModelParams;

                    ChildSettingView = new Model2PointSetting();
                    ChildSettingView.DataContext = this;
                }
                else if (obj.ProcessType == ProcessType.MainAlign || obj.ProcessType == ProcessType.Inspection)
                {
                    OutputParams = new AlgoMotherLineCICOutputParams();
                    obj.ModelParamType = typeof(AlgoMotherLineCICModelParams);
                    var param = obj.CurParams as AlgoMotherLineCICModelParams;

                    ChildSettingView = new AlignSetting();
                    ChildSettingView.DataContext = this;
                }
            }

            #endregion Process Type 으로 구별
        }

        #region [override method]

        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as AlgoMotherLineCICObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();

                var connection = this.parent.GetInputConnector("Trigger");
                Obj.schName = (connection.AttachedConnections[0].SourceConnector.ParentItem.ModAction as SchedulerActionBase).Name;

                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc

                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                DateTime dateTime = DateTime.Now;
                if (!Obj.Run())
                {
                    switch (Obj.ProcessType)
                    {
                        case ProcessType.PanelPreAlign:
                        case ProcessType.TapePreAlign:
                        case ProcessType.MainAlign:
                            // 기존값들 초기화 필요함.
                            //SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                            OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                            //if (Obj.T_Left_DisplayObj.Judgement == (uint)Judgement.OK)
                            //{
                            //    Obj.T_Left_DisplayObj.Judgement = (uint)Judgement.Error;
                            //    Obj.T_Right_DisplayObj.Judgement = (uint)Judgement.Error;
                            //}
                            break;

                        case ProcessType.Inspection:
                            // 기존값들 초기화 필요함.
                            OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                            if (Obj.T_Left_DisplayObj.Judgement == (uint)Judgement.OK)
                            {
                                Obj.T_Left_DisplayObj.Judgement = (uint)Judgement.Error;
                                Obj.T_Right_DisplayObj.Judgement = (uint)Judgement.Error;
                                Obj.O_Left_DisplayObj.Judgement = (uint)Judgement.Error;
                                Obj.O_Right_DisplayObj.Judgement = (uint)Judgement.Error;
                            }
                            break;
                    }
                    return OccurError(Obj.ErrorCode);
                }
                else
                {
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);

                    if (Obj.ProcessType == ProcessType.MainAlign || Obj.ProcessType == ProcessType.Inspection)
                    {
                        Cur_Lx = Obj.InspResult.Lx;
                        Cur_Ly = Obj.InspResult.Ly;
                        Cur_Rx = Obj.InspResult.Rx;
                        Cur_Ry = Obj.InspResult.Ry;
                    }

                    Obj.AppendMessage(Name, "Caluration Complete");
                }

                #endregion Step1 : Calc
            }

            return End();
        }

        public override bool Reset()
        {
            if (!base.Reset()) return false;

            return true;
        }

        #region [Command]

        [field: NonSerialized]
        private DelegateCommand scaleResetCommand;

        public DelegateCommand ScaleResetCommand
        {
            get
            {
                return scaleResetCommand = scaleResetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as AlgoMotherLineCICModelParams;

                    Cur_Lx /= (double)tmp.Scale_Lx.Value;
                    Cur_Ly /= (double)tmp.Scale_Ly.Value;
                    Cur_Rx /= (double)tmp.Scale_Rx.Value;
                    Cur_Ry /= (double)tmp.Scale_Ry.Value;

                    tmp.Scale_Lx.Value = (double)1.0;
                    tmp.Scale_Ly.Value = (double)1.0;
                    tmp.Scale_Rx.Value = (double)1.0;
                    tmp.Scale_Ry.Value = (double)1.0;

                    Obj.UpdateTempValues();
                });
            }
        }

        [field: NonSerialized]
        private DelegateCommand scaleCalcCommand;

        public DelegateCommand ScaleCalcCommand
        {
            get
            {
                return scaleCalcCommand = scaleCalcCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as AlgoObjectBase;
                    var tmp = Obj.TempParams as AlgoMotherLineCICModelParams;

                    var tempLx = (double)temp_Lx.Value;
                    var tempLy = (double)temp_Ly.Value;
                    var tempRx = (double)temp_Rx.Value;
                    var tempRy = (double)temp_Ry.Value;

                    //현재값을 원래 대로
                    Cur_Lx /= (double)tmp.Scale_Lx.Value;
                    Cur_Ly /= (double)tmp.Scale_Ly.Value;
                    Cur_Rx /= (double)tmp.Scale_Rx.Value;
                    Cur_Ry /= (double)tmp.Scale_Ry.Value;

                    // 스케일 계산
                    tmp.Scale_Lx.Value = tempLx / Cur_Lx;
                    tmp.Scale_Ly.Value = tempLy / Cur_Ly;
                    tmp.Scale_Rx.Value = tempRx / Cur_Rx;
                    tmp.Scale_Ry.Value = tempRy / Cur_Ry;

                    // 재계산.
                    Cur_Lx *= (double)tmp.Scale_Lx.Value;
                    Cur_Ly *= (double)tmp.Scale_Ly.Value;
                    Cur_Rx *= (double)tmp.Scale_Rx.Value;
                    Cur_Ry *= (double)tmp.Scale_Ry.Value;

                    // 업뎃
                    Obj.UpdateTempValues();

                    //Cur_UpperLx *= (double)tmp.Scale_UpperLx.Value;
                    //Cur_UpperLy *= (double)tmp.Scale_UpperLy.Value;
                    //Cur_LowerLx *= (double)tmp.Scale_LowerLx.Value;
                    //Cur_LowerLy *= (double)tmp.Scale_LowerLy.Value;
                    //Cur_LowerRx *= (double)tmp.Scale_LowerRx.Value;
                    //Cur_LowerRy *= (double)tmp.Scale_LowerRy.Value;
                });
            }
        }

        [field: NonSerialized]
        private DelegateCommand reMeasureCommand;

        public DelegateCommand ReMeasureCommand
        {
            get
            {
                return reMeasureCommand = reMeasureCommand ?? new DelegateCommand(obj =>
                {
                    if (!IsCanExecute) return;

                    if (isAuto) return;

                    Task task = Task.Run(() =>
                    {
                        CmdReqArgs args = new CmdReqArgs(null, Parent, null, null, Parent.GetInputConnector(CustumTriggerName), CmdRequest.Play, CmdMode.Link);
                        Task<List<CommandReplyArgs>>.Factory.StartNew(() => Execute(this, args));
                    });

                    //task.Wait();
                });
            }
        }

        #endregion [Command]

        public override void PrepareSave()
        {
            base.PrepareSave();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }

        #endregion [override method]
    }
}