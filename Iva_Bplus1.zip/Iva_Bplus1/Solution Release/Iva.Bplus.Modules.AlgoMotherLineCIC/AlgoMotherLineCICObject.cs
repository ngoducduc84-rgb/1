﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;
using System.Windows.Data;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    [SerializableAttribute]
    public partial class AlgoMotherLineCICObject : AlgoObjectBase
    {
        #region [Fields]
        private AlgoMotherLineCICModelParams mParams;
        #region Selected Caldata Name
        private string t_Left_CalData;
        private string t_Right_CalData;
        private string o_Left_CalData;
        private string o_Right_CalData;
        private string t_Left_Display;
        private string t_Right_Display;
        private string o_Left_Display;
        private string o_Right_Display;

        #endregion Selected Caldata Name

        #region etc
        private CalcType calcType;
        private ProcessType processType = ProcessType.Inspection;
        private ThetaDirection thetaDirection = ThetaDirection.Normal;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        private MachineType machineType = MachineType.Normal;

        //private Direction x1Direction = Direction.Reverse;
        //private Direction x2Direction = Direction.Normal;
        //private Direction y1Direction = Direction.Normal;
        //private Direction y2Direction = Direction.Normal;
        private OffsetType offsetType = OffsetType.XYXY;

        #endregion etc

        #region Align결과 관련
        private XYT revAlign = new XYT();
        private XYT revUnload = new XYT();
        private double length_obj = 0.0;
        private double length_tar = 0.0;
        private XYXY inspResult = new XYXY();
        private bool lastJudge = true;

        //2Point Align
        private bool lastJudgement;

        private XYXY VirtualTarget { get; set; } = new XYXY();
        private double length = 0.0;

        #endregion Align결과 관련

        #region Coordinate 관련
        private XY Robot_Tar1 = new XY();
        private XY Robot_Tar2 = new XY();
        private XY Robot_Obj1 = new XY();
        private XY Robot_Obj2 = new XY();
        private XY Coord_Tar1 = new XY();
        private XY Coord_Tar2 = new XY();
        private XY Coord_Obj1 = new XY();
        private XY Coord_Obj2 = new XY();
        private XY Mark_Tar1_XY = new XY();
        private XY Mark_Tar2_XY = new XY();
        private XY Mark_Obj1_XY = new XY();
        private XY Mark_Obj2_XY = new XY();

        private XY Mark_Panel1 = new XY();
        private XY Mark_Panel2 = new XY();
        private XY Mark_notPanel1 = new XY();
        private XY Mark_notPanel2 = new XY();
        private XY Robot_notPanel1 = new XY();
        private XY Robot_notPanel2 = new XY();
        private XY Robot_Panel1 = new XY();
        private XY Robot_Panel2 = new XY();

        private XY Mark_Tar1 = new XY();
        private XY Mark_Tar2 = new XY();
        private XY Mark_Obj1 = new XY();
        private XY Mark_Obj2 = new XY();

        private XYT TarCenter = new XYT();
        private double panelangle_rad = 0;
        private object alignOffset;
        private object Offsets;
        #endregion Coordinate 관련

        public string schName = null;
        private string model = null;
        #endregion [Fields]

        #region [properties]

        #region Selected Caldata Name

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string T_Left_CalData
        {
            get { return t_Left_CalData; }
            set { if (t_Left_CalData == value) return; t_Left_CalData = value; this.OnPropertyChanged(nameof(T_Left_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string T_Right_CalData
        {
            get { return t_Right_CalData; }
            set { if (t_Right_CalData == value) return; t_Right_CalData = value; this.OnPropertyChanged(nameof(T_Right_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string O_Left_CalData
        {
            get { return o_Left_CalData; }
            set { if (o_Left_CalData == value) return; o_Left_CalData = value; this.OnPropertyChanged(nameof(O_Left_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string O_Right_CalData
        {
            get { return o_Right_CalData; }
            set { if (o_Right_CalData == value) return; o_Right_CalData = value; this.OnPropertyChanged(nameof(O_Right_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string T_Left_Display
        {
            get { return t_Left_Display; }
            set { if (t_Left_Display == value) return; t_Left_Display = value; this.OnPropertyChanged(nameof(T_Left_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string T_Right_Display
        {
            get { return t_Right_Display; }
            set { if (t_Right_Display == value) return; t_Right_Display = value; this.OnPropertyChanged(nameof(T_Right_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string O_Left_Display
        {
            get { return o_Left_Display; }
            set { if (o_Left_Display == value) return; o_Left_Display = value; this.OnPropertyChanged(nameof(O_Left_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string O_Right_Display
        {
            get { return o_Right_Display; }
            set { if (o_Right_Display == value) return; o_Right_Display = value; this.OnPropertyChanged(nameof(O_Right_Display)); }
        }

        public CalDataObject T_Left_CalDataObj
        {
            get { return SystemObject_Common.GetObject(t_Left_CalData) as CalDataObject; }
        }

        public CalDataObject T_Right_CalDataObj
        {
            get { return SystemObject_Common.GetObject(t_Right_CalData) as CalDataObject; }
        }

        public CalDataObject O_Left_CalDataObj
        {
            get { return SystemObject_Common.GetObject(o_Left_CalData) as CalDataObject; }
        }

        public CalDataObject O_Right_CalDataObj
        {
            get { return SystemObject_Common.GetObject(o_Right_CalData) as CalDataObject; }
        }

        public CogDisplayObject T_Left_DisplayObj
        {
            get { return SystemObject_Display.GetObject(t_Left_Display) as CogDisplayObject; }
        }

        public CogDisplayObject T_Right_DisplayObj
        {
            get { return SystemObject_Display.GetObject(t_Right_Display) as CogDisplayObject; }
        }

        public CogDisplayObject O_Left_DisplayObj
        {
            get { return SystemObject_Display.GetObject(o_Left_Display) as CogDisplayObject; }
        }

        public CogDisplayObject O_Right_DisplayObj
        {
            get { return SystemObject_Display.GetObject(o_Right_Display) as CogDisplayObject; }
        }

        public MachineType MachineType
        {
            get { return machineType; }
            set { Set<MachineType>(ref machineType, value, nameof(MachineType)); }
        }

        #endregion Selected Caldata Name

        #region etc

        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }

        public ProcessType ProcessType
        {
            get { return processType; }
            set
            {
                if (processType == value)
                    return;
                processType = value;

                switch (processType)
                {
                    case ProcessType.PanelPreAlign:
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                            {
                                ModelParams.Remove(model);
                                ModelParams.Add(model, new AlogMotherLineCIC2PointModelParams());
                            }
                        }
                        break;

                    case ProcessType.TapePreAlign:
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                            {
                                ModelParams.Remove(model);
                                ModelParams.Add(model, new AlgoMotherLineCICTape2PointModelParams());
                            }
                        }
                        break;

                    case ProcessType.MainAlign:
                    case ProcessType.Inspection:
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                            {
                                ModelParams.Remove(model);
                                ModelParams.Add(model, new AlgoMotherLineCICModelParams());
                            }
                        }
                        break;
                }

                this.OnPropertyChanged(nameof(ProcessType));
            }
        }

        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }

        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }

        //public Direction X1Direction
        //{
        //    get { return x1Direction; }
        //    set { if (x1Direction == value) return; x1Direction = value; this.OnPropertyChanged(nameof(X1Direction)); }
        //}
        //public Direction X2Direction
        //{
        //    get { return x2Direction; }
        //    set { if (x2Direction == value) return; x2Direction = value; this.OnPropertyChanged(nameof(X2Direction)); }
        //}
        //public Direction Y1Direction
        //{
        //    get { return y1Direction; }
        //    set { if (y1Direction == value) return; y1Direction = value; this.OnPropertyChanged(nameof(Y1Direction)); }
        //}
        //public Direction Y2Direction
        //{
        //    get { return y2Direction; }
        //    set { if (y2Direction == value) return; y2Direction = value; this.OnPropertyChanged(nameof(Y2Direction)); }
        //}
        public OffsetType OffsetType
        {
            get { return offsetType; }
            set { if (offsetType == value) return; offsetType = value; this.OnPropertyChanged(nameof(OffsetType)); }
        }

        #endregion etc

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        public double Length_obj { get { return length_obj; } }
        public double Length_tar { get { return length_tar; } }
        public XYXY InspResult { get { return inspResult; } }

        public double Length { get { return length; } }

        #endregion Align관련 Data
        #endregion [properties]

        #region[Construct]

        public AlgoMotherLineCICObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new AlgoMotherLineCICModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }

        #endregion

        /// <summary>
        /// Properties 속성을 ProcessType 에 따라 변경
        /// </summary>
        /// <param name="processType"></param>
        public void PropertiesChange(ProcessType processType)
        {
        }

        /// <summary>
        /// Process Type 에 따라서 실행 알고리즘 분기 추가
        /// </summary>
        /// <returns></returns>
        #region [override methode]

        public override bool Run()
        {
            switch (ProcessType)
            {
                case ProcessType.PanelPreAlign:
                    return PanelPreAlignRun();

                case ProcessType.TapePreAlign:
                    //todo : Tape Pre Align 을 2Point 로 변경시 아래 구문을 주석 처리 하십시오.
                    //return TapePreAlignRun();
                    return TapePreAlign2PointRun();

                case ProcessType.MainAlign:
                    return MainAlignRun();

                case ProcessType.Inspection:
                    return InspectionRun();
            }

            return false;
        }

        public override void ObjectInitialize()
        {
            base.ObjectInitialize();
        }

        public override void DefaultIOSet()
        {
            base.DefaultIOSet();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion

        #region [Private Method]

        private XY GetV2R(XY xY, double resolution)
        {
            XY robot = new XY(xY.X * resolution, xY.Y * -resolution);
            return robot;
        }

        private double GetResolution(double sensorW, double pixelW, double lensMag)
        {
            double Resolution = (sensorW / pixelW) / lensMag;
            return Resolution;
        }

        protected bool ConfirmResult(XYXY revAlign, XYXY limit)
        {
            if (!ConfirmSpecMinMax(revAlign.Lx, revAlign.Lx + limit.Lx * (-1), revAlign.Lx + limit.Lx) ||
                !ConfirmSpecMinMax(revAlign.Ly, revAlign.Ly + limit.Ly * (-1), revAlign.Ly + limit.Ly) ||
                !ConfirmSpecMinMax(revAlign.Rx, revAlign.Rx + limit.Rx * (-1), revAlign.Rx + limit.Rx) ||
                !ConfirmSpecMinMax(revAlign.Ry, revAlign.Ry + limit.Ry * (-1), revAlign.Ry + limit.Ry))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }

            return true;
        }

        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }

            return true;
        }

        protected bool ConfirmLength(double _length, double _spec, double _tor)
        {
            if (_tor == 0) return true;

            if (Math.Abs(_length - _spec) > _tor)
            {
                errorCode = AlgoActionBase.Err_Length_Check;
                return false;
            }

            return true;
        }

        public void WriteVisionIO(XYT rev1, XYT rev2, XYXY insp, IPointResult Omark1, IPointResult Omark2, IPointResult Tmark1, IPointResult Tmark2, string ID, ProcessType processType = ProcessType.PanelPreAlign)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            if (processType == ProcessType.PanelPreAlign || processType == ProcessType.MainAlign)
            {
                switch (alignMotionType)
                {
                    case AlignMotionType.XY:
                    case AlignMotionType.XYT:
                        VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                        VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                        VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                        VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                        VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                        VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                        XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                        XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                        VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                        VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                        VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                        VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                        VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                        VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                        VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                        VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                        break;

                    case AlignMotionType.UVW:
                        break;

                    case AlignMotionType.UVRW:
                        break;
                }

                VisionValues["FDC_Obj_Mark_1_X"].NextValue = Omark1.OutputXYT.X; IOs.Add(VisionValues["FDC_Obj_Mark_1_X"]);
                VisionValues["FDC_Obj_Mark_1_Y"].NextValue = Omark1.OutputXYT.Y; IOs.Add(VisionValues["FDC_Obj_Mark_1_Y"]);
                VisionValues["FDC_Obj_Mark_1_S"].NextValue = (int)Omark1.Score; IOs.Add(VisionValues["FDC_Obj_Mark_1_S"]);

                VisionValues["FDC_Obj_Mark_2_X"].NextValue = Omark2.OutputXYT.X; IOs.Add(VisionValues["FDC_Obj_Mark_2_X"]);
                VisionValues["FDC_Obj_Mark_2_Y"].NextValue = Omark2.OutputXYT.Y; IOs.Add(VisionValues["FDC_Obj_Mark_2_Y"]);
                VisionValues["FDC_Obj_Mark_2_S"].NextValue = (int)Omark2.Score; IOs.Add(VisionValues["FDC_Obj_Mark_2_S"]);

                VisionValues["FDC_Tar_Mark_1_X"].NextValue = Tmark1.OutputXYT.X; IOs.Add(VisionValues["FDC_Tar_Mark_1_X"]);
                VisionValues["FDC_Tar_Mark_1_Y"].NextValue = Tmark1.OutputXYT.Y; IOs.Add(VisionValues["FDC_Tar_Mark_1_Y"]);
                VisionValues["FDC_Tar_Mark_1_S"].NextValue = (int)Tmark1.Score; IOs.Add(VisionValues["FDC_Tar_Mark_1_S"]);

                VisionValues["FDC_Tar_Mark_2_X"].NextValue = Tmark2.OutputXYT.X; IOs.Add(VisionValues["FDC_Tar_Mark_2_X"]);
                VisionValues["FDC_Tar_Mark_2_Y"].NextValue = Tmark2.OutputXYT.Y; IOs.Add(VisionValues["FDC_Tar_Mark_2_Y"]);
                VisionValues["FDC_Tar_Mark_2_S"].NextValue = (int)Tmark2.Score; IOs.Add(VisionValues["FDC_Tar_Mark_2_S"]);
            }
            else if(processType == ProcessType.Inspection)
            {
                VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                var io = new IOStruct();
                if (VisionValues.ContainsKey("InspectionLx")) { VisionValues["InspectionLx"].NextValue = (double)insp.Lx; IOs.Add(VisionValues["InspectionLx"]); }
                if (VisionValues.ContainsKey("InspectionLy")) { VisionValues["InspectionLy"].NextValue = (double)insp.Ly; IOs.Add(VisionValues["InspectionLy"]); }
                if (VisionValues.ContainsKey("InspectionRx")) { VisionValues["InspectionRx"].NextValue = (double)insp.Rx; IOs.Add(VisionValues["InspectionRx"]); }
                if (VisionValues.ContainsKey("InspectionRy")) { VisionValues["InspectionRy"].NextValue = (double)insp.Ry; IOs.Add(VisionValues["InspectionRy"]); }

                VisionValues["FDC_Obj_Mark_1_X"].NextValue = Omark1.OutputXYT.X; IOs.Add(VisionValues["FDC_Obj_Mark_1_X"]);
                VisionValues["FDC_Obj_Mark_1_Y"].NextValue = Omark1.OutputXYT.Y; IOs.Add(VisionValues["FDC_Obj_Mark_1_Y"]);
                VisionValues["FDC_Obj_Mark_1_S"].NextValue = (int)Omark1.Score; IOs.Add(VisionValues["FDC_Obj_Mark_1_S"]);

                VisionValues["FDC_Obj_Mark_2_X"].NextValue = Omark2.OutputXYT.X; IOs.Add(VisionValues["FDC_Obj_Mark_2_X"]);
                VisionValues["FDC_Obj_Mark_2_Y"].NextValue = Omark2.OutputXYT.Y; IOs.Add(VisionValues["FDC_Obj_Mark_2_Y"]);
                VisionValues["FDC_Obj_Mark_2_S"].NextValue = (int)Omark2.Score; IOs.Add(VisionValues["FDC_Obj_Mark_2_S"]);

                VisionValues["FDC_Tar_Mark_1_X"].NextValue = Tmark1.OutputXYT.X; IOs.Add(VisionValues["FDC_Tar_Mark_1_X"]);
                VisionValues["FDC_Tar_Mark_1_Y"].NextValue = Tmark1.OutputXYT.Y; IOs.Add(VisionValues["FDC_Tar_Mark_1_Y"]);
                VisionValues["FDC_Tar_Mark_1_S"].NextValue = (int)Tmark1.Score; IOs.Add(VisionValues["FDC_Tar_Mark_1_S"]);

                VisionValues["FDC_Tar_Mark_2_X"].NextValue = Tmark2.OutputXYT.X; IOs.Add(VisionValues["FDC_Tar_Mark_2_X"]);
                VisionValues["FDC_Tar_Mark_2_Y"].NextValue = Tmark2.OutputXYT.Y; IOs.Add(VisionValues["FDC_Tar_Mark_2_Y"]);
                VisionValues["FDC_Tar_Mark_2_S"].NextValue = (int)Tmark2.Score; IOs.Add(VisionValues["FDC_Tar_Mark_2_S"]);
            }

            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }

        //protected void DrawLineLabel_L(Iva.Bplus.Interface.IPointResult Mark_Tar, Iva.Bplus.Interface.IPointResult Mark_Obj,
        //                             double resolution, double panelangle_rad, CogColorConstants color)
        protected void DrawLineLabel_L(string _model, Iva.Bplus.Interface.IPointResult _target, Iva.Bplus.Interface.IPointResult _object)
        {
            string _sourceID = DeepClone(sourceID);
            DateTime dateTime = DateTime.Now;
            string model = _model;

            #region Draw Results
            // Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
            makerInfo.Color = CogColorConstants.Red;
            var crossPoint_P1 = new XYT() + GetCrossPoint(Coord_Obj1, Coord_Tar1, Coord_Tar2) - T_Left_CalDataObj.GetRotateCenter(model);
            crossPoint_P1 = T_Left_CalDataObj.GetR2V(model, crossPoint_P1);
            makerInfo.Offset = crossPoint_P1;
            T_Left_DisplayObj.DrawMaker(makerInfo);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = CogColorConstants.Red;
            lineInfo.Start = Mark_Tar1_XY;
            lineInfo.End = crossPoint_P1.ToXY();
            T_Left_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = Mark_Obj1_XY;
            lineInfo.End = crossPoint_P1.ToXY();
            T_Left_DisplayObj.DrawLine(lineInfo);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Obj1_XY) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ly);
            T_Left_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (crossPoint_P1.ToXY() + Mark_Tar1_XY) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Lx);
            T_Left_DisplayObj.DrawLabel(labelInfo);
            #endregion

            string _judgement = "";
            foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
            {
                if (T_Left_DisplayObj.Judgement == (uint)j)
                {
                    _judgement = j.ToString();
                    break;
                }
            }

            object obj = (Bitmap)T_Left_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
            T_Left_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);

            if (T_Left_DisplayObj.Judgement != (uint)Judgement.OK && T_Left_DisplayObj.Judgement != (uint)Judgement.None)
            {
                object obj1 = T_Left_DisplayObj.GetCurImage();
                T_Left_DisplayObj.SaveImage(dateTime, obj1, _judgement, schName, _sourceID, false);
            }
        }

        protected void DrawLineLabel_R(string _model, Iva.Bplus.Interface.IPointResult _target, Iva.Bplus.Interface.IPointResult _object)
        {
            string _sourceID = DeepClone(sourceID);
            DateTime dateTime = DateTime.Now;
            string model = _model;

            #region Draw Results
            // Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
            makerInfo.Color = CogColorConstants.Red;
            var crossPoint_P2 = new XYT() + GetCrossPoint(Coord_Obj2, Coord_Tar2, Coord_Tar1) - T_Right_CalDataObj.GetRotateCenter(model);
            crossPoint_P2 = T_Right_CalDataObj.GetR2V(model, crossPoint_P2);
            makerInfo.Offset = crossPoint_P2;
            T_Right_DisplayObj.DrawMaker(makerInfo);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = CogColorConstants.Red;
            lineInfo.Start = Mark_Tar2_XY;
            lineInfo.End = crossPoint_P2.ToXY();
            T_Right_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = Mark_Obj2_XY;
            lineInfo.End = crossPoint_P2.ToXY();
            T_Right_DisplayObj.DrawLine(lineInfo);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (crossPoint_P2.ToXY() + Mark_Obj2_XY) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ry);
            T_Right_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (crossPoint_P2.ToXY() + Mark_Tar2_XY) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Rx);
            T_Right_DisplayObj.DrawLabel(labelInfo);
            #endregion

            string _judgement = "";
            foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
            {
                if (T_Right_DisplayObj.Judgement == (uint)j)
                {
                    _judgement = j.ToString();
                    break;
                }
            }

            object obj = (Bitmap)T_Right_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
            T_Right_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);

            if (T_Right_DisplayObj.Judgement != (uint)Judgement.OK && T_Right_DisplayObj.Judgement != (uint)Judgement.None)
            {
                object obj1 = T_Right_DisplayObj.GetCurImage();
                T_Right_DisplayObj.SaveImage(dateTime, obj1, _judgement, schName, _sourceID, false);
            }
        }

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            Task task = Task.Factory.StartNew(() =>
            cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true
            ));
        }

        #endregion
    }
}