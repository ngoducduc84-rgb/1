﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using Iva.Bplus.Views;

using SvMip;

using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    [SerializableAttribute]
    public partial class AlgoMotherLineCICShape : ModuleBase
    {
        #region [Construct]

        public AlgoMotherLineCICShape()
            : base()
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;
        }

        public AlgoMotherLineCICShape(SystemCanvasViewModel parent, string name)
            : base(parent, name)
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;

            base.InitItem(null, name, SettingShapeType.Algo);

            var action = base.modAction as SystemActionBase;
            base.SetConnectors(action.InputParams, action.OutputParams);

            //프로그램에서 새로 생성시 Event 등록이 되지 않기 때문에 생성자에서 이벤트 등록 을 하도록 함.
            ModAction.ModObject.PropertyChanged += ModObject_PropertyChanged;
        }

        #endregion [Construct]

        #region [override method]

        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string _source)
        {
            base.parent = parent;
            base.InitItem(obj, _source, SettingShapeType.Algo);

            //초기화시 강제로 In/Out put 을 변경
            var Obj = obj as AlgoMotherLineCICObject;
            ProcessChange(Obj.ProcessType);

            ModAction.ModObject.PropertyChanged += ModObject_PropertyChanged;

            base.Geometry = SystemImage.TOOL_SEQUENCE_ICON;
        }

        /// <summary>
        /// Property 가 변경될 경우 함수가 호출 됩니다.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="s"></param>
        public void ModObject_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            var obj = sender as AlgoMotherLineCICObject;

            if (e.PropertyName == "ProcessType")
            {
                ProcessChange(obj.ProcessType);
            }
        }

        /// <summary>
        /// Process Type 에 따라서 각 In/Output 을 변경.
        /// </summary>
        /// <param name="processType"></param>
        private void ProcessChange(ProcessType processType)
        {
            var action = base.modAction as SystemActionBase;
            base.SetConnectors(action.InputParams, action.OutputParams);

            base.DetachConections(base.InputConnectors);
            base.InputConnectors.Clear();

            switch (processType)
            {
                //todo : Tape Pre Align 을 2Point 로 변경시 아래 case 에 Tape Pre Align  case 를 추가 하십시오
                case ProcessType.PanelPreAlign:
                case ProcessType.TapePreAlign:
                    base.InputConnectors_ItemAdd(new ConnectorViewModel("Obj_P1", typeof(IPointResult)));
                    base.InputConnectors_ItemAdd(new ConnectorViewModel("Obj_P2", typeof(IPointResult)));
                    base.InputConnectors_ItemAdd(new ConnectorViewModel("Trigger", typeof(CalcTrigger)));
                    break;

                case ProcessType.MainAlign:
                case ProcessType.Inspection:
                    base.InputConnectors_ItemAdd(new ConnectorViewModel("Obj_P1", typeof(IPointResult)));
                    base.InputConnectors_ItemAdd(new ConnectorViewModel("Tar_P1", typeof(IPointResult)));
                    base.InputConnectors_ItemAdd(new ConnectorViewModel("Obj_P2", typeof(IPointResult)));
                    base.InputConnectors_ItemAdd(new ConnectorViewModel("Tar_P2", typeof(IPointResult)));
                    base.InputConnectors_ItemAdd(new ConnectorViewModel("Trigger", typeof(CalcTrigger)));
                    break;
            }
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion [override method]
    }
}