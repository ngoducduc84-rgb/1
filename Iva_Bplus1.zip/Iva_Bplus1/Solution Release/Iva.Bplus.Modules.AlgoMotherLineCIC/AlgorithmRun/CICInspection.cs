﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    public partial class AlgoMotherLineCICObject
    {
        /// <summary>
        /// Inspection 알고리즘 실행 모듈
        /// </summary>
        /// <returns></returns>
        private bool InspectionRun()
        {
            try
            {
                model = SystemModel.GetCurModel();
                errorCode = 0;
                lastJudge = true;

                #region PLC IOs Update

                AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근

                #endregion PLC IOs Update

                #region Mark Data Read& Confirm

                if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2") || !InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                var Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
                var Mark_Tar2 = InputValues["Tar_P2"] as IPointResult;
                var Mark_Obj1 = InputValues["Obj_P1"] as IPointResult;
                var Mark_Obj2 = InputValues["Obj_P2"] as IPointResult;
                if (Mark_Tar1 == null || Mark_Tar2 == null || Mark_Obj1 == null || Mark_Obj2 == null)
                {
                    // Mark Data가 Null임
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                Mark_Tar1_XY = Mark_Tar1.OutputXYT.ToXY();
                Mark_Tar2_XY = Mark_Tar2.OutputXYT.ToXY();
                Mark_Obj1_XY = Mark_Obj1.OutputXYT.ToXY();
                Mark_Obj2_XY = Mark_Obj2.OutputXYT.ToXY();

                #endregion Mark Data Read& Confirm

                #region Model Data prepare

                AlgoParams modelParams;
                if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                mParams = modelParams as AlgoMotherLineCICModelParams;
                double limitX = (double)mParams.LimitX.Value;
                double limitY = (double)mParams.LimitY.Value;
                double limitT = (double)mParams.LimitT.Value;

                double sensorsizeW = (double)mParams.SensorSize_W.Value;
                double pixelcountW = (double)mParams.Pixel_Count_W.Value;
                double lensMag = (double)mParams.Lens_Mag.Value;
                double panelmarkdistance = (double)mParams.PanelMarkDistance.Value;
                double scale_Lx = (double)mParams.Scale_Lx.Value;
                double scale_Ly = (double)mParams.Scale_Ly.Value;
                double scale_Rx = (double)mParams.Scale_Rx.Value;
                double scale_Ry = (double)mParams.Scale_Ry.Value;
                double spec_Lx = (double)mParams.Spec_Lx.Value;
                double spec_Ly = (double)mParams.Spec_Ly.Value;
                double spec_Rx = (double)mParams.Spec_Rx.Value;
                double spec_Ry = (double)mParams.Spec_Ry.Value;
                double tor_Lx = (double)mParams.Tor_Lx.Value;
                double tor_Ly = (double)mParams.Tor_Ly.Value;
                double tor_Rx = (double)mParams.Tor_Rx.Value;
                double tor_Ry = (double)mParams.Tor_Ry.Value;
                double tar1_score = Mark_Tar1.Score;
                double tar2_score = Mark_Tar2.Score;
                double obj1_score = Mark_Obj1.Score;
                double obj2_score = Mark_Obj2.Score;

                double spec_Length_Target = (double)mParams.Spec_Length_Target.Value;
                double tor_Length_Target = (double)mParams.Tor_Length_Target.Value;
                double spec_Length_Object = (double)mParams.Spec_Length_Object.Value;
                double tor_Length_Object = (double)mParams.Tor_Length_Object.Value;
                double scale_Length = (double)mParams.Scale_Length.Value;
                XYT Limit = new XYT(limitX, limitY, limitT);
                XYXY Scale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
                XYXY Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
                XYXY Tor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);

                #endregion Model Data prepare

                #region Coordinate Pos Calc & CalData Cofirm

                if (T_Left_CalDataObj == null || T_Right_CalDataObj == null) //CalData는 2개, 카메라 왼쪽, 오른쪽
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    // Calibration 설정 안됨.
                    return false;
                }

                Robot_Tar1 = T_Left_CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));   //Film(T)
                Robot_Tar2 = T_Right_CalDataObj.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y));   //Film(T)

                Robot_Obj1 = T_Left_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));   //PNL(O)
                Robot_Obj2 = T_Right_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));   //PNL(O)

                #endregion Coordinate Pos Calc & CalData Cofirm

                #region Calc Rev Offset

                //#region Offset 적용
                //alignOffset = new XYXY();
                ////Distance Spec 누적
                ////(alignOffset as XYXY).Lx += X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                ////(alignOffset as XYXY).Ly += Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                ////(alignOffset as XYXY).Rx += X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                ////(alignOffset as XYXY).Ry += Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                //TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);
                //#endregion

                //revAlign = new XYT();
                //double radT, DriftX, DriftY;

                //// Attach 위치 보정값 계산.
                //XY ObjXY = (Coord_Obj1 + Coord_Obj2) / 2;
                //double T = GetTheta(Coord_Obj1, Coord_Obj2);
                //T = NormalizeTheta(T);
                //XYT ObjCenter = new XYT(ObjXY.X, ObjXY.Y, T);

                //radT = TarCenter.T - ObjCenter.T;

                //DriftX = Math.Cos(radT) * ObjCenter.X - Math.Sin(radT) * ObjCenter.Y;
                //DriftY = Math.Sin(radT) * ObjCenter.X + Math.Cos(radT) * ObjCenter.Y;

                //revAlign.X = TarCenter.X - DriftX;
                //revAlign.Y = TarCenter.Y - DriftY;
                //if (ThetaDirection == ThetaDirection.Normal)    //정방향
                //    revAlign.T = radT / rad;
                //else //역방향
                //    revAlign.T = (radT / rad) * -1;

                #endregion Calc Rev Offset

                #region Cal Inspection

                InspCalc();
                T_Left_DisplayObj.Judgement = (uint)Judgement.OK;
                T_Right_DisplayObj.Judgement = (uint)Judgement.OK;

                #endregion Cal Inspection

                #region Confirm Result (Inspection Spec Over Check)

                //if (!ConfirmResult2(inspResult, Spec, Tor))
                //{
                //    T_Left_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                //    T_Right_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                //    lastJudge = false;
                //}

                #endregion Confirm Result (Inspection Spec Over Check)

                #region Calc Length & Confirm (Length Check)

                length_tar = GetLength(Mark_Tar1_XY, Mark_Tar2_XY);
                length_obj = GetLength(Mark_Obj1_XY, Mark_Obj2_XY);
                if (!ConfirmLength(length_tar, spec_Length_Target, tor_Length_Target) )
                {
                    errorCode = AlgoActionBase.Err_Length_Check;
                    T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Mark_Tar1.Tool.ProcMode = ProcessMode.Manual;
                    Mark_Tar2.Tool.ProcMode = ProcessMode.Manual;
                    lastJudge = false;
                }

                if (!ConfirmLength(length_obj, spec_Length_Object, tor_Length_Object))
                {
                    errorCode = AlgoActionBase.Err_Length_Check;
                    O_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    O_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Mark_Obj1.Tool.ProcMode = ProcessMode.Manual;
                    Mark_Obj2.Tool.ProcMode = ProcessMode.Manual;
                    lastJudge = false;
                }

                #endregion Calc Length & Confirm (Length Check)

                #region DrawOverlay & ImageSave

                Task.Factory.StartNew(() => DrawInspResult(model, Robot_Tar1, Robot_Tar2, Robot_Obj1, Robot_Obj2));
                //Task.Factory.StartNew(() => DrawLineLabel_R(model, Mark_Tar2, Mark_Obj2));

                #endregion DrawOverlay & ImageSave

                #region Result Data Update(DataGridView Insert)

                AlgoRst = new AlgoMotherLineCICInspectionResult
                {
                    Name = name,
                    ID = sourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    Lx = Math.Round(inspResult.Lx, 3),
                    Ly = Math.Round(inspResult.Ly, 3),
                    Rx = Math.Round(inspResult.Rx, 3),
                    Ry = Math.Round(inspResult.Ry, 3),

                    //Offset1X = Math.Round(revAlign.X, 3),
                    //Offset1Y = Math.Round(revAlign.Y, 3),
                    //Offset1T = Math.Round(revAlign.T, 3),

                    Length_tar = Math.Round(length_tar, 3),
                    Length_obj = Math.Round(length_obj, 3),
                    Result = lastJudge,

                    Target_P1_X = Math.Round(Mark_Tar1_XY.X, 3),  //Mark Pixel 좌표
                    Target_P1_Y = Math.Round(Mark_Tar1_XY.Y, 3),
                    Target_P2_X = Math.Round(Mark_Tar2_XY.X, 3),
                    Target_P2_Y = Math.Round(Mark_Tar2_XY.Y, 3),

                    //C1_X = Math.Round(Mark_Obj1_XY.X, 3),
                    //C1_Y = Math.Round(Mark_Obj1_XY.Y, 3),
                    //C2_X = Math.Round(Mark_Obj2_XY.X, 3),
                    //C2_Y = Math.Round(Mark_Obj2_XY.Y, 3),

                    Object_P1_X = Math.Round(Mark_Obj1_XY.X, 3),
                    Object_P1_Y = Math.Round(Mark_Obj1_XY.Y, 3),
                    Object_P2_X = Math.Round(Mark_Obj2_XY.X, 3),
                    Object_P2_Y = Math.Round(Mark_Obj2_XY.Y, 3),

                    Target_P1_Score = Math.Round(tar1_score,3),
                    Target_P2_Score = Math.Round(tar2_score,3),
                    Object_P1_Score = Math.Round(obj1_score,3),
                    Object_P2_Score = Math.Round(obj2_score,3),


                };

                SystemLogger.WriteAlignDBLog(name, AlgoRst);

                #endregion Result Data Update(DataGridView Insert)

                #region Vision Write (Result & FDC)

                WriteVisionIO(revAlign, revUnload, inspResult, Mark_Obj1, Mark_Obj2, Mark_Tar1, Mark_Tar2, "", processType);

                #endregion Vision Write (Result & FDC)
            }
            catch (Exception ex)
            {
            }

            return lastJudge;
        }

        private void InspCalc()
        {
           double _panelmarkdistance = 0;
            var mark_Tar1 = InputValues["Tar_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Tar2 = InputValues["Tar_P2"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj1 = InputValues["Obj_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj2 = InputValues["Obj_P2"] as Iva.Bplus.Interface.IPointResult;

            Mark_Panel1 = new XY(mark_Tar1.OutputXYT.X, mark_Tar1.OutputXYT.Y);
            Mark_Panel2 = new XY(mark_Tar2.OutputXYT.X, mark_Tar2.OutputXYT.Y);
            Mark_notPanel1 = new XY(mark_Obj1.OutputXYT.X, mark_Obj1.OutputXYT.Y);
            Mark_notPanel2 = new XY(mark_Obj2.OutputXYT.X, mark_Obj2.OutputXYT.Y);

            Robot_notPanel1 = new XY();
            Robot_notPanel2 = new XY();
            Robot_Panel1 = new XY();
            Robot_Panel2 = new XY();

            Robot_notPanel1 = T_Left_CalDataObj.GetV2R(model, Mark_notPanel1, true, true);   //Film(T)
            Robot_notPanel2 = T_Right_CalDataObj.GetV2R(model, Mark_notPanel2, true, true);   //Film(T)
            Robot_Panel1 = T_Left_CalDataObj.GetV2R(model, Mark_Panel1, true, true);   //PNL(O)
            Robot_Panel2 = T_Right_CalDataObj.GetV2R(model, Mark_Panel2, true, true);   //PNL(O)

            //panelangle_rad = Math.Asin((Robot_Panel2.Y - Robot_Panel1.Y) / _panelmarkdistance);
            //double camDistance = _panelmarkdistance * Math.Cos(panelangle_rad) + Robot_Panel1.X - Robot_Panel2.X;

            //XY Cood_Panel1 = new XY(Robot_Panel1.X+27.4, Robot_Panel1.Y+117.6);
            //XY Cood_notPanel1 = new XY(Robot_notPanel1.X+27.4, Robot_notPanel1.Y+117.6);

            //XY Cood_Panel2 = new XY(Robot_Panel2.X-26, Robot_Panel2.Y+117.8);
            //XY Cood_notPanel2 = new XY(Robot_notPanel2.X-26, Robot_notPanel2.Y+117.8);

            //inspResult = new XYXY();
            //inspResult.Lx = GetDotDistance(Cood_notPanel1, Cood_Panel1, Cood_Panel2);
            //inspResult.Ly = GetCrossDistance(Cood_notPanel1, Cood_Panel1, Cood_Panel2);
            //inspResult.Rx = GetDotDistance(Cood_notPanel2, Cood_Panel2, Cood_Panel1);
            //inspResult.Ry = GetCrossDistance(Cood_notPanel2, Cood_Panel2, Cood_Panel1);


            inspResult = new XYXY();
            inspResult.Lx = Math.Abs(Robot_notPanel1.X - Robot_Panel1.X);
            inspResult.Ly = Math.Abs(Robot_notPanel1.Y - Robot_Panel1.Y);
            inspResult.Rx = Math.Abs(Robot_notPanel2.X - Robot_Panel2.X);
            inspResult.Ry = Math.Abs(Robot_notPanel2.Y - Robot_Panel2.Y);

            // Scale Apply
            inspResult.Lx *= (double)mParams.Scale_Lx.Value;
            inspResult.Ly *= (double)mParams.Scale_Ly.Value;
            inspResult.Rx *= (double)mParams.Scale_Rx.Value;
            inspResult.Ry *= (double)mParams.Scale_Ry.Value;
        }

        private void InspectionCalc_(double _panelmarkdistance = 0)
        {
            var mark_Tar1 = InputValues["Tar_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Tar2 = InputValues["Tar_P2"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj1 = InputValues["Obj_P1"] as Iva.Bplus.Interface.IPointResult;
            var mark_Obj2 = InputValues["Obj_P2"] as Iva.Bplus.Interface.IPointResult;

            Mark_Panel1 = new XY(mark_Tar1.OutputXYT.X, mark_Tar1.OutputXYT.Y);
            Mark_Panel2 = new XY(mark_Tar2.OutputXYT.X, mark_Tar2.OutputXYT.Y);
            Mark_notPanel1 = new XY(mark_Obj1.OutputXYT.X, mark_Obj1.OutputXYT.Y);
            Mark_notPanel2 = new XY(mark_Obj2.OutputXYT.X, mark_Obj2.OutputXYT.Y);

            Robot_notPanel1 = new XY();
            Robot_notPanel2 = new XY();
            Robot_Panel1 = new XY();
            Robot_Panel2 = new XY();

            Robot_notPanel1 = T_Left_CalDataObj.GetV2R(model, Mark_notPanel1, true, true);   //Film(T)
            Robot_notPanel2 = T_Right_CalDataObj.GetV2R(model, Mark_notPanel2, true, true);   //Film(T)
            Robot_Panel1 = T_Left_CalDataObj.GetV2R(model, Mark_Panel1, true, true);   //PNL(O)
            Robot_Panel2 = T_Right_CalDataObj.GetV2R(model, Mark_Panel2, true, true);   //PNL(O)

            panelangle_rad = Math.Asin((Robot_Panel2.Y - Robot_Panel1.Y) / _panelmarkdistance);
            double camDistance = _panelmarkdistance * Math.Cos(panelangle_rad) + Robot_Panel1.X - Robot_Panel2.X;

            XY Cood_Panel1 = new XY(Robot_Panel1.X + camDistance, Robot_Panel1.Y);
            XY Cood_notPanel1 = new XY(Robot_notPanel1.X + camDistance, Robot_notPanel1.Y);

            XY Cood_Panel2 = new XY(Robot_Panel2.X + camDistance, Robot_Panel2.Y);
            XY Cood_notPanel2 = new XY(Robot_notPanel2.X + camDistance, Robot_notPanel2.Y);

            inspResult = new XYXY();
            inspResult.Lx = GetDotDistance(Cood_notPanel1, Cood_Panel1, Cood_Panel2);
            inspResult.Ly = GetCrossDistance(Cood_notPanel1, Cood_Panel1, Cood_Panel2);
            inspResult.Rx = GetDotDistance(Cood_notPanel2, Cood_Panel2, Cood_Panel1);
            inspResult.Ry = GetCrossDistance(Cood_notPanel2, Cood_Panel2, Cood_Panel1);

            //inspResult = new XYXY();
            //inspResult.Lx = GetDotDistance(Robot_notPanel1, Robot_Panel1, Cood_Panel2);
            //inspResult.Ly = GetCrossDistance(Robot_notPanel1, Robot_Panel1, Cood_Panel2);
            //inspResult.Rx = GetDotDistance(Cood_notPanel2, Cood_Panel2, Robot_Panel1);
            //inspResult.Ry = GetCrossDistance(Cood_notPanel2, Cood_Panel2, Robot_Panel1);

            // Scale Apply
            inspResult.Lx *= (double)mParams.Scale_Lx.Value;
            inspResult.Ly *= (double)mParams.Scale_Ly.Value;
            inspResult.Rx *= (double)mParams.Scale_Rx.Value;
            inspResult.Ry *= (double)mParams.Scale_Ry.Value;
        }

        protected bool ConfirmResult2(XYXY rst, XYXY spec, XYXY tor)
        {
            if (!ConfirmSpecMinMax(rst.Lx, Math.Abs(spec.Lx) + tor.Lx * (-1), Math.Abs(spec.Lx) + tor.Lx) ||
                !ConfirmSpecMinMax(rst.Ly, Math.Abs(spec.Ly) + tor.Ly * (-1), Math.Abs(spec.Ly) + tor.Ly) ||
                !ConfirmSpecMinMax(rst.Rx, Math.Abs(spec.Rx) + tor.Rx * (-1), Math.Abs(spec.Rx) + tor.Rx) ||
                !ConfirmSpecMinMax(rst.Ry, Math.Abs(spec.Ry) + tor.Ry * (-1), Math.Abs(spec.Ry) + tor.Ry))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }

            return true;
        }

        protected void DrawInspResult(string _model, XY _target1, XY _target2, XY _object1, XY _object2)
        {
            string model = _model;
            Mark_Tar1 = _target1;
            Mark_Tar2 = _target2;
            Mark_Obj1 = _object1;
            Mark_Obj2 = _object2;

            #region Draw Results

            // Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo = new CogDrawMarkerInfo();
            makerInfo.Color = CogColorConstants.Red;
            var crossPoint_P1 = new XYT(Mark_Tar1.X, Mark_Obj1.Y, 0);
            crossPoint_P1 = T_Left_CalDataObj.GetR2V(model, crossPoint_P1);
            makerInfo.Offset = crossPoint_P1;
            T_Left_DisplayObj.DrawMaker(makerInfo);
            var crossPoint_P2 = new XYT(Mark_Tar2.X, Mark_Obj2.Y, 0);
            crossPoint_P2 = T_Right_CalDataObj.GetR2V(model, crossPoint_P2);
            makerInfo.Offset = crossPoint_P2;
            T_Right_DisplayObj.DrawMaker(makerInfo);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = CogColorConstants.Red;
            lineInfo.Start = T_Left_CalDataObj.GetR2V(model, new XYT(Mark_Tar1)).ToXY();
            lineInfo.End = crossPoint_P1.ToXY();
            T_Left_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = T_Left_CalDataObj.GetR2V(model, new XYT(Mark_Obj1)).ToXY();
            lineInfo.End = crossPoint_P1.ToXY();
            T_Left_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = T_Right_CalDataObj.GetR2V(model, new XYT(Mark_Tar2)).ToXY();
            lineInfo.End = crossPoint_P2.ToXY();
            T_Right_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = T_Right_CalDataObj.GetR2V(model, new XYT(Mark_Obj2)).ToXY();
            lineInfo.End = crossPoint_P2.ToXY();
            T_Right_DisplayObj.DrawLine(lineInfo);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = (T_Left_CalDataObj.GetR2V(model, new XYT(Mark_Tar1)).ToXY() + crossPoint_P1.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ly);
            T_Left_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (T_Left_CalDataObj.GetR2V(model, new XYT(Mark_Obj1)).ToXY() + crossPoint_P1.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Lx);
            T_Left_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (T_Right_CalDataObj.GetR2V(model, new XYT(Mark_Tar2)).ToXY() + crossPoint_P2.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Ry);
            T_Right_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = (T_Right_CalDataObj.GetR2V(model, new XYT(Mark_Obj2)).ToXY() + crossPoint_P2.ToXY()) / 2;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", inspResult.Rx);
            T_Right_DisplayObj.DrawLabel(labelInfo);

            #endregion Draw Results
        }
    }
}