﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    public partial class AlgoMotherLineCICObject
    {
        /// <summary>
        /// Main Align 알고리즘 실행 모듈
        /// </summary>
        /// <returns></returns>
        private bool MainAlignRun()
        {
            try
            {
                model = SystemModel.GetCurModel();
                errorCode = 0;
                lastJudge = true;

                #region PLC IOs Update

                AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근

                #endregion PLC IOs Update

                #region Model Data prepare

                AlgoParams modelParams;
                if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                mParams = modelParams as AlgoMotherLineCICModelParams;
                double limitX = (double)mParams.LimitX.Value;
                double limitY = (double)mParams.LimitY.Value;
                double limitT = (double)mParams.LimitT.Value;

                double sensorsizeW = (double)mParams.SensorSize_W.Value;
                double pixelcountW = (double)mParams.Pixel_Count_W.Value;
                double lensMag = (double)mParams.Lens_Mag.Value;
                double panelmarkdistance = (double)mParams.PanelMarkDistance.Value;
                double scale_Lx = (double)mParams.Scale_Lx.Value;
                double scale_Ly = (double)mParams.Scale_Ly.Value;
                double scale_Rx = (double)mParams.Scale_Rx.Value;
                double scale_Ry = (double)mParams.Scale_Ry.Value;
                double spec_Lx = (double)mParams.Spec_Lx.Value;
                double spec_Ly = (double)mParams.Spec_Ly.Value;
                double spec_Rx = (double)mParams.Spec_Rx.Value;
                double spec_Ry = (double)mParams.Spec_Ry.Value;
                double tor_Lx = (double)mParams.Tor_Lx.Value;
                double tor_Ly = (double)mParams.Tor_Ly.Value;
                double tor_Rx = (double)mParams.Tor_Rx.Value;
                double tor_Ry = (double)mParams.Tor_Ry.Value;

                double spec_Length_Target = (double)mParams.Spec_Length_Target.Value;
                double tor_Length_Target = (double)mParams.Tor_Length_Target.Value;
                double spec_Length_Object = (double)mParams.Spec_Length_Object.Value;
                double tor_Length_Object = (double)mParams.Tor_Length_Object.Value;
                double scale_Length = (double)mParams.Scale_Length.Value;
                XYT Limit = new XYT(limitX, limitY, limitT);
                XYXY Scale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
                XYXY Spec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
                XYXY Tor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);

                //bool isPanelMove = (bool)mParams.IsPanelMove.Value;
                //double resolution = GetResolution(sensorsizeW, pixelcountW, lensMag);

                #endregion Model Data prepare

                #region Mark Data Read& Confirm

                if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2") || !InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                var Mark_Tar1 = InputValues["Tar_P1"] as IPointResult;
                var Mark_Tar2 = InputValues["Tar_P2"] as IPointResult;
                var Mark_Obj1 = InputValues["Obj_P1"] as IPointResult;
                var Mark_Obj2 = InputValues["Obj_P2"] as IPointResult;
                if (Mark_Tar1 == null || Mark_Tar2 == null || Mark_Obj1 == null || Mark_Obj2 == null)
                {
                    // Mark Data가 Null임
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                Mark_Tar1_XY = Mark_Tar1.OutputXYT.ToXY();
                Mark_Tar2_XY = Mark_Tar2.OutputXYT.ToXY();
                Mark_Obj1_XY = Mark_Obj1.OutputXYT.ToXY();
                Mark_Obj2_XY = Mark_Obj2.OutputXYT.ToXY();

                var Robot_CAM_Tar_P1 = new XY(0, 0);
                var Robot_CAM_Tar_P2 = new XY(0, 0);
                var Robot_CAM_Obj_P1 = new XY(0, 0);
                var Robot_CAM_obj_P2 = new XY(0, 0);
                if (Mark_Tar1.RefPoints == null)
                {
                    Mark_Tar1.RefPoints = new List<XYT>();
                    Mark_Tar1.RefPoints.Add(new XYT(0, 0, 0));
                }
                if (Mark_Tar2.RefPoints == null)
                {
                    Mark_Tar2.RefPoints = new List<XYT>();
                    Mark_Tar2.RefPoints.Add(new XYT(0, 0, 0));
                }
                if (Mark_Obj1.RefPoints == null)
                {
                    Mark_Obj1.RefPoints = new List<XYT>();
                    Mark_Obj1.RefPoints.Add(new XYT(0, 0, 0));
                }
                if (Mark_Obj2.RefPoints == null)
                {
                    Mark_Obj2.RefPoints = new List<XYT>();
                    Mark_Obj2.RefPoints.Add(new XYT(0, 0, 0));
                }

                #endregion Mark Data Read& Confirm

                #region Coordinate Pos Calc & CalData Cofirm

                if (T_Left_CalDataObj == null || T_Right_CalDataObj == null) //CalData는 2개, 카메라 왼쪽, 오른쪽
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    // Calibration 설정 안됨.
                    return false;
                }


                XY Robot_Ref_Tar_P1; XY Robot_Ref_Tar_P2;
                XY Robot_Ref_Obj_P1; XY Robot_Ref_Obj_P2;
                if (Mark_Tar1.RefPoints[0].X == Mark_Tar2.RefPoints[0].X)        // 같은 이미지일 경우,,
                {
                    Robot_Ref_Tar_P1 = T_Left_CalDataObj.GetV2R(model, new XY(Mark_Tar1.RefPoints[0].X, Mark_Tar1.RefPoints[0].Y));
                    Robot_Ref_Tar_P2 = T_Right_CalDataObj.GetV2R(model, new XY(Mark_Tar2.RefPoints[1].X, Mark_Tar2.RefPoints[1].Y));
                }
                else
                {
                    Robot_Ref_Tar_P1 = T_Left_CalDataObj.GetV2R(model, new XY(Mark_Tar1.RefPoints[0].X, Mark_Tar1.RefPoints[0].Y));
                    Robot_Ref_Tar_P2 = T_Right_CalDataObj.GetV2R(model, new XY(Mark_Tar2.RefPoints[0].X, Mark_Tar2.RefPoints[0].Y));
                }
                if (Mark_Obj1.RefPoints[0].X == Mark_Obj2.RefPoints[0].X)        // 같은 이미지일 경우,,
                {
                    Robot_Ref_Obj_P1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_Obj1.RefPoints[0].X, Mark_Obj1.RefPoints[0].Y));
                    Robot_Ref_Obj_P2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_Obj2.RefPoints[1].X, Mark_Obj2.RefPoints[1].Y));
                }
                else
                {
                    Robot_Ref_Obj_P1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_Obj1.RefPoints[0].X, Mark_Obj1.RefPoints[0].Y));
                    Robot_Ref_Obj_P2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_Obj2.RefPoints[0].X, Mark_Obj2.RefPoints[0].Y));
                }


                var Coord_CAM_Tar_P1 = Robot_CAM_Tar_P1 + T_Left_CalDataObj.GetRotateCenter(model);
                var Coord_CAM_Tar_P2 = Robot_CAM_Tar_P2 + T_Right_CalDataObj.GetRotateCenter(model);
                var Coord_CAM_Obj_P1 = Robot_CAM_Obj_P1 + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_CAM_Obj_P2 = Robot_CAM_obj_P2 + O_Right_CalDataObj.GetRotateCenter(model);

                Robot_Tar1 = T_Left_CalDataObj.GetV2R(model, new XY(Mark_Tar1.OutputXYT.X, Mark_Tar1.OutputXYT.Y));   //PNL(T)
                Robot_Tar2 = T_Right_CalDataObj.GetV2R(model, new XY(Mark_Tar2.OutputXYT.X, Mark_Tar2.OutputXYT.Y));   //PNL(T)

                Robot_Obj1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_Obj1.OutputXYT.X, Mark_Obj1.OutputXYT.Y));   //Film(O)
                Robot_Obj2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_Obj2.OutputXYT.X, Mark_Obj2.OutputXYT.Y));   //Film(O)


                var Coord_Ref_Tar_P1 = Robot_Ref_Tar_P1 + T_Left_CalDataObj.GetRotateCenter(model);
                var Coord_Ref_Tar_P2 = Robot_Ref_Tar_P2 + T_Right_CalDataObj.GetRotateCenter(model);

                var Coord_Ref_Obj_P1 = Robot_Ref_Obj_P1 + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_Ref_Obj_P2 = Robot_Ref_Obj_P2 + O_Right_CalDataObj.GetRotateCenter(model);

                XY T_Left_RotCent = T_Left_CalDataObj.GetRotateCenter(model);
                XY T_Right_RotCent = T_Right_CalDataObj.GetRotateCenter(model);
                XY O_Left_RotCent = O_Left_CalDataObj.GetRotateCenter(model);
                XY O_Right_RotCent = O_Right_CalDataObj.GetRotateCenter(model);

                Coord_Tar1 = Robot_Tar1 + T_Left_RotCent;
                Coord_Tar2 = Robot_Tar2 + T_Right_RotCent;
                //Coord_Tar2.X += CvtPLCIO.CamPosX2 - CvtPLCIO.CamPosX1;


                Coord_Obj1 = Robot_Obj1 + O_Left_RotCent;
                Coord_Obj2 = Robot_Obj2 + O_Right_RotCent;
                #endregion Coordinate Pos Calc & CalData Cofirm

                #region Calc Rev Offset

                #region Offset 적용

                Offsets = null;
                alignOffset = null;
                var alignOffset1 = CvtPLCIO.OffsetXYT;
                if (OffsetType == OffsetType.XYT)
                {
                    Offsets = CvtPLCIO.OffsetXYT;  //Log찍게
                    alignOffset = CvtPLCIO.OffsetXYT;

                    double Theta = GetTheta(Coord_Tar1, Coord_Tar2);
                    Theta = NormalizeTheta(Theta);

                    //Spec.Lx = X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                    //Spec.Ly = Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                    //Spec.Rx = X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                    //Spec.Ry = Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                    XY Coord_Tar1_Temp = new XY();
                    XY Coord_Tar2_Temp = new XY();

                    Coord_Tar1_Temp.X = Coord_Tar1.X + Math.Cos(Theta) * Spec.Lx - Math.Sin(Theta) * Spec.Ly;
                    Coord_Tar1_Temp.Y = Coord_Tar1.Y + Math.Sin(Theta) * Spec.Lx + Math.Cos(Theta) * Spec.Ly;
                    Coord_Tar2_Temp.X = Coord_Tar2.X + Math.Cos(Theta) * Spec.Rx - Math.Sin(Theta) * Spec.Ry;
                    Coord_Tar2_Temp.Y = Coord_Tar2.Y + Math.Sin(Theta) * Spec.Rx + Math.Cos(Theta) * Spec.Ry;

                    (alignOffset as XYT).X /= scale_Lx;
                    (alignOffset as XYT).Y /= scale_Ly;
                    (alignOffset as XYT).T /= scale_Rx;


                    TarCenter = ApplyTargetOffset(Coord_Tar1_Temp, Coord_Tar2_Temp, alignOffset);
                }
                else
                {
                    // 기존 PLC Offset값 저장.
                    Offsets = CvtPLCIO.OffsetXYXY;  //Log찍게
                    alignOffset = CvtPLCIO.OffsetXYXY;

                    //Distance Spec 누적
                    //(alignOffset as XYXY).Lx += X1Direction == Direction.Normal ? spec_Lx : (spec_Lx * (-1));
                    //(alignOffset as XYXY).Ly += Y1Direction == Direction.Normal ? spec_Ly : (spec_Ly * (-1));
                    //(alignOffset as XYXY).Rx += X2Direction == Direction.Normal ? spec_Rx : (spec_Rx * (-1));
                    //(alignOffset as XYXY).Ry += Y2Direction == Direction.Normal ? spec_Ry : (spec_Ry * (-1));

                    //Scale적용
                    (alignOffset as XYXY).Lx /= scale_Lx;
                    (alignOffset as XYXY).Ly /= scale_Ly;
                    (alignOffset as XYXY).Rx /= scale_Rx;
                    (alignOffset as XYXY).Ry /= scale_Ry;

                    TarCenter = ApplyTargetOffset(Coord_Tar1, Coord_Tar2, alignOffset);
                }

                #endregion Offset 적용

                revAlign = new XYT();
                double radT_Obj, DriftX_Obj, DriftY_Obj;
                double radT_Tar, DriftX_Tar, DriftY_Tar;

                double camT_Tar = GetThetaColumn(Coord_CAM_Tar_P1.X, Coord_CAM_Tar_P2.X, Coord_CAM_Tar_P1.Y, Coord_CAM_Tar_P2.Y);
                double camT_Obj = GetThetaColumn(Coord_CAM_Obj_P1.X, Coord_CAM_Obj_P2.X, Coord_CAM_Obj_P1.Y, Coord_CAM_Obj_P2.Y);

                double refT_Obj = GetThetaColumn(Coord_Ref_Obj_P1.X, Coord_Ref_Obj_P2.X, Coord_Ref_Obj_P1.Y, Coord_Ref_Obj_P2.Y);
                double refT_Tar = GetThetaColumn(Coord_Ref_Tar_P1.X, Coord_Ref_Tar_P2.X, Coord_Ref_Tar_P1.Y, Coord_Ref_Tar_P2.Y);
                double pnlT_Tar = GetThetaColumn(Coord_Tar1.X, Coord_Tar2.X, Coord_Tar1.Y, Coord_Tar2.Y);
                double pnlT_Obj = GetThetaColumn(Coord_Obj1.X, Coord_Obj2.X, Coord_Obj1.Y, Coord_Obj2.Y);

                pnlT_Obj -= camT_Obj;
                refT_Obj -= camT_Obj;

                pnlT_Tar -= camT_Tar;
                refT_Tar -= camT_Tar;


                // Attach 위치 보정값 계산.
                XY ObjXY = (Coord_Obj1 + Coord_Obj2) / 2;
                XY tarXY = (Coord_Tar1 + Coord_Tar2) / 2;
                var refTar = (Coord_Ref_Tar_P1 + Coord_Ref_Tar_P2) / 2;
                var refObj = (Coord_Ref_Obj_P1 + Coord_Ref_Obj_P2) / 2;


                var refTarxyt_Tar = new XYT(refTar.X, refTar.Y, refT_Tar);
                var refTarxyt_Obj = new XYT(refObj.X, refObj.Y, refT_Obj);
                var pnlObjxyt_Tar = new XYT(tarXY.X, tarXY.Y, pnlT_Tar);
                var pnlObjxyt_Obj = new XYT(ObjXY.X, ObjXY.Y, pnlT_Obj);


                //double T = GetTheta(Coord_Obj1, Coord_Obj2);
                //double TT = GetTheta(Coord_Tar1 , Coord_Tar2);
                //TT = NormalizeTheta(TT);
                //T = NormalizeTheta(T);
                //XYT ObjCenter = new XYT(ObjXY.X, ObjXY.Y, T);

                //XYT TarCenter2 = new XYT(tarXY.X, tarXY.Y,TT);

                //ObjCenter = ApplyTargetOffset(ObjCenter, alignOffset1);
                //radT = -TarCenter2.T - ObjCenter.T;
                refTarxyt_Tar = ApplyTargetOffset(refTarxyt_Tar, alignOffset1);
                //refTarxyt_Obj = ApplyTargetOffset(refTarxyt_Obj, alignOffset1);
                radT_Tar = NormalizeTheta(refTarxyt_Tar.T - pnlObjxyt_Tar.T);
                radT_Obj = NormalizeTheta(refTarxyt_Obj.T - pnlObjxyt_Obj.T);




                //Tar
                DriftX_Tar = Math.Cos(radT_Tar) * pnlObjxyt_Tar.X - Math.Sin(radT_Tar) * pnlObjxyt_Tar.Y;
                DriftY_Tar = Math.Sin(radT_Tar) * pnlObjxyt_Tar.X + Math.Cos(radT_Tar) * pnlObjxyt_Tar.Y;
                //Obj
                DriftX_Obj = Math.Cos(radT_Obj) * pnlObjxyt_Obj.X - Math.Sin(radT_Obj) * pnlObjxyt_Obj.Y;
                DriftY_Obj = Math.Sin(radT_Obj) * pnlObjxyt_Obj.X + Math.Cos(radT_Obj) * pnlObjxyt_Obj.Y;

                revAlign.X = -(((refTarxyt_Tar.X - DriftX_Tar)-(refTarxyt_Obj.X - DriftX_Obj)));
                revAlign.Y = -((refTarxyt_Tar.Y - DriftY_Tar) - (refTarxyt_Obj.Y - DriftY_Obj));

                //revAlign.X = TarCenter2.X - DriftX;
                //revAlign.Y = TarCenter2.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    revAlign.T = (radT_Tar / rad)-(radT_Obj / rad);
                else //역방향
                    revAlign.T = ((radT_Tar / rad) - (radT_Obj / rad)) * -1;

                #endregion Calc Rev Offset

                #region Cal Inspection

                InspectionCalc_(); // Align을 pixel CalData로 할 리가 없다.
                T_Left_DisplayObj.Judgement = (uint)Judgement.OK;
                T_Right_DisplayObj.Judgement = (uint)Judgement.OK;

                O_Left_DisplayObj.Judgement = (uint)Judgement.OK;
                O_Right_DisplayObj.Judgement = (uint)Judgement.OK;

                #endregion Cal Inspection

                #region Confirm Result (Align Spec Over Check)

                if (!ConfirmResult(revAlign, Limit))
                {
                    T_Left_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    lastJudge = false;
                }

                #endregion Confirm Result (Align Spec Over Check)

                #region Calc Length

                length_tar = GetLength(Coord_Tar1, Coord_Tar2);
                length_obj = GetLength(Coord_Obj1, Coord_Obj2);
                if (!ConfirmLength(length_tar, spec_Length_Target, tor_Length_Target))
                {
                    ErrorCode = AlgoActionBase.Err_Length_Check;
                    T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    lastJudge = false;
                    Mark_Tar1.Tool.ProcMode = ProcessMode.Manual;
                    Mark_Tar2.Tool.ProcMode = ProcessMode.Manual;
                }

                if (!ConfirmLength(length_obj, spec_Length_Object, tor_Length_Object))
                {
                    ErrorCode = AlgoActionBase.Err_Length_Check;
                    O_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    O_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                    lastJudge = false;
                    Mark_Obj1.Tool.ProcMode = ProcessMode.Manual;
                    Mark_Obj2.Tool.ProcMode = ProcessMode.Manual;
                }

                #endregion Calc Length

                #region DrawOverlay & ImageSave

                //Task.Factory.StartNew(() => DrawLineLabel_L(model, Mark_Tar1, Mark_Obj1));
                //Task.Factory.StartNew(() => DrawLineLabel_R(model, Mark_Tar2, Mark_Obj2));

                #endregion DrawOverlay & ImageSave

                #region Result Data Update(DataGridView Insert)

                if (OffsetType == OffsetType.XYT)
                {
                    AlgoRst = new AlgoMotherLineCICMainAlignResult
                    {
                        Name = name,
                        ID = sourceID,

                        CurTime = DateTime.Now.ToString("HH:mm:ss"),
                        CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                        //Lx = Math.Round(inspResult.Lx, 3),
                        //Ly = Math.Round(inspResult.Ly, 3),
                        //Rx = Math.Round(inspResult.Rx, 3),
                        //Ry = Math.Round(inspResult.Ry, 3),

                        Rev1X = Math.Round(revAlign.X, 3),
                        Rev1Y = Math.Round(revAlign.Y, 3),
                        Rev1T = Math.Round(revAlign.T, 3),

                        Rev2X = Math.Round(revUnload.X, 3),
                        Rev2Y = Math.Round(revUnload.Y, 3),
                        Rev2T = Math.Round(revUnload.T, 3),

                        Tar_Score1 = Math.Round(Mark_Tar1.Score, 3),
                        Tar_Score2 = Math.Round(Mark_Tar2.Score, 3),
                        Obj_Score1 = Math.Round(Mark_Obj1.Score, 3),
                        Obj_Score2 = Math.Round(Mark_Obj2.Score, 3),

                        Length_tar = Math.Round(length_tar, 3),
                        Length_obj = Math.Round(length_obj, 3),
                        Result = lastJudge,

                        P1_X = Math.Round(Coord_Tar1.X, 3),  //Mark Pixel 좌표
                        P1_Y = Math.Round(Coord_Tar1.Y, 3),
                        P2_X = Math.Round(Coord_Tar2.X, 3),
                        P2_Y = Math.Round(Coord_Tar2.Y, 3),

                        C1_X = Math.Round(Coord_Obj1.X, 3),
                        C1_Y = Math.Round(Coord_Obj1.Y, 3),
                        C2_X = Math.Round(Coord_Obj2.X, 3),
                        C2_Y = Math.Round(Coord_Obj2.Y, 3),

                        PlcOffset_Lx = Math.Round((Offsets as XYT).X, 3),
                        PlcOffset_Ly = Math.Round((Offsets as XYT).Y, 3),
                        PlcOffset_Rx = Math.Round((Offsets as XYT).T, 3),
                    };
                }
                else
                {
                    AlgoRst = new AlgoMotherLineCICMainAlignResult
                    {
                        Name = name,
                        ID = sourceID,

                        CurTime = DateTime.Now.ToString("HH:mm:ss"),
                        CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                        //Lx = Math.Round(inspResult.Lx, 3),
                        //Ly = Math.Round(inspResult.Ly, 3),
                        //Rx = Math.Round(inspResult.Rx, 3),
                        //Ry = Math.Round(inspResult.Ry, 3),

                        Rev1X = Math.Round(revAlign.X, 3),
                        Rev1Y = Math.Round(revAlign.Y, 3),
                        Rev1T = Math.Round(revAlign.T, 3),

                        Length_tar = Math.Round(length_tar, 3),
                        Length_obj = Math.Round(length_obj, 3),
                        Result = true,

                        P1_X = Math.Round(Coord_Tar1.X, 3),  //Mark Pixel 좌표
                        P1_Y = Math.Round(Coord_Tar1.Y, 3),
                        P2_X = Math.Round(Coord_Tar2.X, 3),
                        P2_Y = Math.Round(Coord_Tar2.Y, 3),

                        C1_X = Math.Round(Coord_Obj1.X, 3),
                        C1_Y = Math.Round(Coord_Obj1.Y, 3),
                        C2_X = Math.Round(Coord_Obj2.X, 3),
                        C2_Y = Math.Round(Coord_Obj2.Y, 3),

                        PlcOffset_Lx = Math.Round((Offsets as XYXY).Lx, 3),
                        PlcOffset_Ly = Math.Round((Offsets as XYXY).Ly, 3),
                        PlcOffset_Rx = Math.Round((Offsets as XYXY).Rx, 3),
                        PlcOffset_Ry = Math.Round((Offsets as XYXY).Ry, 3),
                    };
                }

                SystemLogger.WriteAlignDBLog(name, AlgoRst);

                #endregion Result Data Update(DataGridView Insert)

                #region Vision Write (Result & FDC)

                WriteVisionIO(revAlign, revUnload, inspResult, Mark_Obj1, Mark_Obj2, Mark_Tar1, Mark_Tar2, "", processType);

                #endregion Vision Write (Result & FDC)
            }
            catch (Exception ex)
            {
            }
            return lastJudge;
        }
    }
}