﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;
using System.Windows.Media;
using System.Security.Permissions;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    public partial class AlgoMotherLineCICObject
    {
        /// <summary>
        /// 2Point PreAlign 알고리즘 실행 모듈
        /// </summary>
        /// <returns></returns>
        private bool PanelPreAlignRun()
        {
            try
            {
                string model = SystemModel.GetCurModel();
                errorCode = 0;
                lastJudgement = true;

                #region PLC IOs Update

                AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근

                #endregion PLC IOs Update

                #region Mark Data Read& Confirm

                // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
                if (!InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                // 2020.03.31 hdy MatchingRstData -> IPointResult로 변경
                var Mark_P1 = InputValues["Obj_P1"] as IPointResult;
                var Mark_P2 = InputValues["Obj_P2"] as IPointResult;
                if (Mark_P1 == null || Mark_P2 == null)
                {
                    // Mark Data가 Null임
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                if (Mark_P1.RefPoints == null)
                {
                    Mark_P1.RefPoints = new List<XYT>();
                    Mark_P1.RefPoints.Add(new XYT(0, 0, 0));
                }
                if (Mark_P2.RefPoints == null)
                {
                    Mark_P2.RefPoints = new List<XYT>();
                    Mark_P2.RefPoints.Add(new XYT(0, 0, 0));
                }

                #endregion Mark Data Read& Confirm

                #region Coordinate Pos Calc & CalData Cofirm

                //if (P1_CalDataObj == null || P2_CalDataObj == null)
                //{
                //    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                //    // Calibration 설정 안됨.
                //    return false;
                //}
                if (O_Left_CalDataObj == null || O_Right_CalDataObj == null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    // Calibration 설정 안됨.
                    return false;
                }

                var Robot_P1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_P1.OutputXYT.X, Mark_P1.OutputXYT.Y));
                var Robot_P2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_P2.OutputXYT.X, Mark_P2.OutputXYT.Y));

                var Robot_CAM_P1 = new XY(0, 0);
                var Robot_CAM_P2 = new XY(0, 0);

                // 2020.04.22 hdy 같은 화면일 경우,, case 수정,,
                XY Robot_Ref_P1; XY Robot_Ref_P2;
                if (Mark_P1.RefPoints[0].X == Mark_P2.RefPoints[0].X)        // 같은 이미지일 경우,,
                {
                    Robot_Ref_P1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_P1.RefPoints[0].X, Mark_P1.RefPoints[0].Y));
                    Robot_Ref_P2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_P2.RefPoints[1].X, Mark_P2.RefPoints[1].Y));
                }
                else
                {
                    Robot_Ref_P1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_P1.RefPoints[0].X, Mark_P1.RefPoints[0].Y));
                    Robot_Ref_P2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_P2.RefPoints[0].X, Mark_P2.RefPoints[0].Y));
                }

                var Coord_P1 = Robot_P1 + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_P2 = Robot_P2 + O_Right_CalDataObj.GetRotateCenter(model);

                var Coord_CAM_P1 = Robot_CAM_P1 + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_CAM_P2 = Robot_CAM_P2 + O_Right_CalDataObj.GetRotateCenter(model);

                var Coord_Ref_P1 = Robot_Ref_P1 + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_Ref_P2 = Robot_Ref_P2 + O_Right_CalDataObj.GetRotateCenter(model);

                #endregion Coordinate Pos Calc & CalData Cofirm

                #region Model Data prepare

                AlgoParams modelParams;
                if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                var mParams = modelParams as AlogMotherLineCIC2PointModelParams;
                var limitX = (double)mParams.LimitX.Value;
                var limitY = (double)mParams.LimitY.Value;
                var limitT = (double)mParams.LimitT.Value;
                var Limit = new XYT(limitX, limitY, limitT);
                var spec_Length = (double)mParams.Spec_Length.Value;
                var tor_Length = (double)mParams.Tor_Length.Value;
                var scale_Length = (double)mParams.Scale_Length.Value;

                var retryX = (double)mParams.RetryX?.Value;
                var retryY = (double)mParams.RetryY?.Value;
                var retryT = (double)mParams.RetryT?.Value;

                #endregion Model Data prepare

                #region Calc Rev Offset

                // 단변
                double camT = GetThetaColumn(Coord_CAM_P1.X, Coord_CAM_P2.X, Coord_CAM_P1.Y, Coord_CAM_P2.Y);
                double refT = GetThetaColumn(Coord_Ref_P1.X, Coord_Ref_P2.X, Coord_Ref_P1.Y, Coord_Ref_P2.Y);
                double pnlT = GetThetaColumn(Coord_P1.X, Coord_P2.X, Coord_P1.Y, Coord_P2.Y);

                pnlT -= camT;
                refT -= camT;
                camT = 0;

                var camTar = (Coord_CAM_P1 + Coord_CAM_P2) / 2;
                var refTar = (Coord_Ref_P1 + Coord_Ref_P2) / 2;
                var pnlObj = (Coord_P1 + Coord_P2) / 2;

                var alignOffset = CvtPLCIO.OffsetXYT;

                var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
                var refTarxyt = new XYT(refTar.X, refTar.Y, refT);
                var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
                var camTarxyt_Un = new XYT(camTar.X, camTar.Y, camT);

                revAlign = new XYT();
                revUnload = new XYT();
                double radT, DriftX, DriftY;

                if (CalcType == CalcType.Center)
                {
                    // Attach 위치 보정값 계산.
                    camTarxyt = ApplyTargetOffset(camTarxyt, alignOffset);
                    radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revAlign.X = camTarxyt.X - DriftX;
                    revAlign.Y = camTarxyt.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else //역방향
                        revAlign.T = (radT / rad) * -1;

                    // Unload 위치 보정값 계산 // 얘는 오프셋없음.
                    camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                    radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revUnload.X = camTarxyt_Un.X - DriftX;
                    revUnload.Y = camTarxyt_Un.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revUnload.T = radT / rad;
                    else //역방향
                        revUnload.T = (radT / rad) * -1;
                }
                else if (CalcType == CalcType.Reference)
                {
                    // Attach 위치 보정값 계산.
                    refTarxyt = ApplyTargetOffset(refTarxyt, alignOffset);
                    radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revAlign.X = refTarxyt.X - DriftX;
                    revAlign.Y = refTarxyt.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else  //역방향
                        revAlign.T = (radT / rad) * -1;

                    // Unload 위치 보정값 계산 // 얘는 오프셋없음.    //CamCenter위치로
                    camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                    radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revUnload.X = camTarxyt_Un.X - DriftX;
                    revUnload.Y = camTarxyt_Un.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revUnload.T = radT / rad;
                    else  //역방향
                        revUnload.T = (radT / rad) * -1;
                }
                else if (CalcType == CalcType.PickUp)   //Target: 자재, Object: Reference
                {
                    pnlObjxyt = ApplyTargetOffset(pnlObjxyt, alignOffset);
                    radT = NormalizeTheta(pnlObjxyt.T - refTarxyt.T);
                    DriftX = Math.Cos(radT) * refTarxyt.X - Math.Sin(radT) * refTarxyt.Y;
                    DriftY = Math.Sin(radT) * refTarxyt.X + Math.Cos(radT) * refTarxyt.Y;
                    revAlign.X = pnlObjxyt.X - DriftX;
                    revAlign.Y = pnlObjxyt.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else  //역방향
                        revAlign.T = (radT / rad) * -1;
                }

                #endregion Calc Rev Offset

                #region VirtualMark

                if (MachineType == MachineType.Bending)
                {
                    MatchingRstData rst1 = Mark_P1 as MatchingRstData;
                    MatchingRstData rst2 = Mark_P2 as MatchingRstData;

                    var vl = GetApplyRev(O_Left_CalDataObj, rst1, revAlign);
                    var vr = GetApplyRev(O_Right_CalDataObj, rst2, revAlign);
                    VirtualTarget = new XYXY(vl.X, vl.Y, vr.X, vr.Y);
                }

                #endregion VirtualMark

                #region Confirm Result (Align Spec Over Check)

                #region retry spec over

                if (!(retryX == 0.0 && retryY == 0.0 && retryT == 0.0)
                    && (Math.Abs(revAlign.X) > retryX || Math.Abs(revAlign.Y) > retryY || Math.Abs(revAlign.T) > retryT))
                {
                    T_Left_DisplayObj.Judgement = (uint)Judgement.Warning;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.Warning;
                    errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                    lastJudgement = false;
                }

                #endregion retry spec over

                #region limit spec over

                if (!ConfirmResult(revAlign, Limit))
                {
                    T_Left_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                    lastJudgement = false;
                }

                #endregion limit spec over

                #endregion Confirm Result (Align Spec Over Check)

                #region Calc Length & Confirm (Length Check)

                length = GetLength(Coord_P1, Coord_P2);
                if (tor_Length != 0)
                {
                    if (Math.Abs(spec_Length - length) > tor_Length)
                    {
                        lastJudgement = false;
                        errorCode = AlgoActionBase.Err_Length_Check;
                        T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        Mark_P1.Tool.ProcMode = ProcessMode.Manual;
                        Mark_P2.Tool.ProcMode = ProcessMode.Manual;
                    }
                }

                #endregion Calc Length & Confirm (Length Check)

                #region Inspection Result Image Save (L_Check) Inspection이 아니기 때문에 주석 처리 됨.

                //if (T_Left_DisplayObj.Judgement != (uint)Judgement.OK && T_Right_DisplayObj.Judgement != (uint)Judgement.None)
                //{
                //    string _sourceID = DeepClone(sourceID);
                //    DateTime dateTime = DateTime.Now;
                //    string _judgement = "";

                //    foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
                //    {
                //        if (T_Left_DisplayObj.Judgement == (uint)j)
                //        {
                //            _judgement = j.ToString();
                //            break;
                //        }
                //    }

                //    object obj = (Bitmap)T_Left_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                //    T_Left_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true, ErrorCode);

                //    object obj2 = (Bitmap)T_Right_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                //    T_Right_DisplayObj.SaveImage(dateTime, obj2, _judgement, schName, _sourceID, true, ErrorCode);

                //    object obj3 = T_Left_DisplayObj.GetCurImage();
                //    T_Left_DisplayObj.SaveImage(dateTime, obj3, _judgement, schName, _sourceID, false, ErrorCode);

                //    object obj4 = T_Right_DisplayObj.GetCurImage();
                //    T_Right_DisplayObj.SaveImage(dateTime, obj4, _judgement, schName, _sourceID, false, ErrorCode);
                //}

                #endregion Inspection Result Image Save (L_Check) Inspection이 아니기 때문에 주석 처리 됨.

                #region Result Data Update(DataGridView Insert)

                AlgoRst = new AlogMotherLineCICPreAlignResult
                {
                    Name = name,
                    ID = sourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    Ref1X = Math.Round(revAlign.X, 3),
                    Ref1Y = Math.Round(revAlign.Y, 3),
                    Ref1T = Math.Round(revAlign.T, 3),

                    Ref2X = Math.Round(revUnload.X, 3),
                    Ref2Y = Math.Round(revUnload.Y, 3),
                    Ref2T = Math.Round(revUnload.T, 3),

                    Length = Math.Round(length, 3),

                    ScoreX = Math.Round(Mark_P1.Score, 3),
                    ScoreY = Math.Round(Mark_P2.Score, 3),

                    Result = lastJudgement,

                    P1_X = Math.Round(Mark_P1.OutputXYT.X, 3),  //Mark Pixel 좌표
                    P1_Y = Math.Round(Mark_P1.OutputXYT.Y, 3),
                    P2_X = Math.Round(Mark_P2.OutputXYT.X, 3),
                    P2_Y = Math.Round(Mark_P2.OutputXYT.Y, 3),

                    C1_X = Math.Round(Coord_P1.X, 3),
                    C1_Y = Math.Round(Coord_P1.Y, 3),
                    C2_X = Math.Round(Coord_P2.X, 3),
                    C2_Y = Math.Round(Coord_P2.Y, 3),

                    Type = CalcType.ToString(),
                    Pnl_T = Math.Round(pnlT / rad, 3),
                    Ref_T = Math.Round(refT / rad, 3),
                    Cam_T = Math.Round(camT / rad, 3),    //camT=0인데 의미가 있나

                    PLCOffset_X = alignOffset.X,
                    PLCOffset_Y = alignOffset.Y,
                    PLCOffset_T = alignOffset.T,
                };

                #endregion Result Data Update(DataGridView Insert)

                SystemLogger.WriteAlignDBLog(name, AlgoRst);
                //#endregion

                #region Vision Write (Result & FDC)

                WriteVisionIO(revAlign, revUnload, Mark_P1, Mark_P2, "");

                #endregion Vision Write (Result & FDC)
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
            }

            return lastJudgement;
        }

        private XY GetApplyRev(CalDataObject cal, MatchingRstData mark, XYT rev)
        {
            var model = SystemModel.GetCurModel();
            var rc = cal.GetRotateCenter(model);
            var rp = cal.GetV2R(model, mark.OutputXYT.ToXY());

            double r = rev.T * PI / 180;
            var a = Math.Cos(r) * (rev.X + rc.X);
            var b = -Math.Sin(r) * (rev.Y + rc.Y);

            double x = rev.X + Math.Cos(r) * (rp.X + rc.X) - Math.Sin(r) * (rp.Y + rc.Y) - rc.X;
            double y = rev.Y + Math.Sin(r) * (rp.X + rc.X) + Math.Cos(r) * (rp.Y + rc.Y) - rc.Y;

            return cal.GetR2V(model, new XY(x, y)).ToXY();
        }

        //public void WriteVisionFDCIO(XYT Mark1, XYT Mark2, int Score1, int Score2)
        //{
        //    try
        //    {
        //        #region FDC Write
        //        VisionValues["FDC_Obj_Mark_1_X"].NextValue = Mark1.X;

        //        #endregion
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine(ex.StackTrace);
        //    }
        //}

        public void WriteVisionIO(object rev1, object rev2, IPointResult mark1, IPointResult mark2, string ID, int typeindex = -1)
        {
            if (MachineType == MachineType.Bending)
            {
                WriteVisionIO_Bending(rev1, rev2, ID);
                return;
            }

            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    if (ProcessType == ProcessType.TapePreAlign)
                    {
                        VisionValues["TapeType"].NextValue = typeindex; IOs.Add(VisionValues["TapeType"]);
                    }
                    VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                    VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                    VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                    VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                    VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                    VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                    VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);

                    #region FDC Write

                    VisionValues["FDC_Obj_Mark_1_X"].NextValue = mark1.OutputXYT.X; IOs.Add(VisionValues["FDC_Obj_Mark_1_X"]);
                    VisionValues["FDC_Obj_Mark_1_Y"].NextValue = mark1.OutputXYT.Y; IOs.Add(VisionValues["FDC_Obj_Mark_1_Y"]);
                    VisionValues["FDC_Obj_Mark_1_S"].NextValue = (int)mark1.Score; IOs.Add(VisionValues["FDC_Obj_Mark_1_S"]);

                    VisionValues["FDC_Obj_Mark_2_X"].NextValue = mark2.OutputXYT.X; IOs.Add(VisionValues["FDC_Obj_Mark_2_X"]);
                    VisionValues["FDC_Obj_Mark_2_Y"].NextValue = mark2.OutputXYT.Y; IOs.Add(VisionValues["FDC_Obj_Mark_2_Y"]);
                    VisionValues["FDC_Obj_Mark_2_S"].NextValue = (int)mark2.Score; IOs.Add(VisionValues["FDC_Obj_Mark_2_S"]);

                    #endregion FDC Write

                    break;

                case AlignMotionType.UVW:
                    break;

                case AlignMotionType.UVRW:
                    break;
            }

            if (MachineType == MachineType.CSpacer)
            {
                // report matching score to fdc
                var Mark_Obj1 = InputValues["P1"] as IPointResult;
                var Mark_Obj2 = InputValues["P2"] as IPointResult;
                VisionValues["Score_Object_L"].NextValue = Mark_Obj1.Score; IOs.Add(VisionValues["Score_Object_L"]);
                VisionValues["Score_Object_R"].NextValue = Mark_Obj2.Score; IOs.Add(VisionValues["Score_Object_R"]);
            }

            // 아이디 확인.
            VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }

        private void WriteVisionIO_Bending(object rev1, object rev2, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["Rev_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev_X"]);
                    VisionValues["Rev_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev_Y"]);
                    VisionValues["Rev_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    VisionValues["Tar_Position_X1_U_X"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar_Position_X1_U_X"]);
                    VisionValues["Tar_Position_X2_V_Y"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar_Position_X2_V_Y"]);
                    VisionValues["Tar_Position_Y1_W_T"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar_Position_Y1_W_T"]);
                    VisionValues["Tar_Position_Y2"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar_Position_Y2"]);

                    break;

                case AlignMotionType.UVW:
                    break;

                case AlignMotionType.UVRW:
                    break;
            }

            // virtual mark
            VisionValues["VirtualTarget_LX"].NextValue = (double)VirtualTarget.Lx; IOs.Add(VisionValues["VirtualTarget_LX"]);
            VisionValues["VirtualTarget_LY"].NextValue = (double)VirtualTarget.Ly; IOs.Add(VisionValues["VirtualTarget_LY"]);
            VisionValues["VirtualTarget_RX"].NextValue = (double)VirtualTarget.Rx; IOs.Add(VisionValues["VirtualTarget_RX"]);
            VisionValues["VirtualTarget_RY"].NextValue = (double)VirtualTarget.Ry; IOs.Add(VisionValues["VirtualTarget_RY"]);

            // report matching score to fdc
            var Mark_Obj1 = InputValues["P1"] as IPointResult;
            var Mark_Obj2 = InputValues["P2"] as IPointResult;
            VisionValues["MatchingScore_L"].NextValue = Mark_Obj1.Score; IOs.Add(VisionValues["MatchingScore_L"]);
            VisionValues["MatchingScore_R"].NextValue = Mark_Obj2.Score; IOs.Add(VisionValues["MatchingScore_R"]);

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }
    }
}