﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    public partial class AlgoMotherLineCICObject
    {
        /// <summary>
        /// Tape Pre Align 알고리즘 실행 모듈
        /// </summary>
        /// <returns></returns>
        private bool TapePreAlignRun()
        {
            try
            {
                string model = SystemModel.GetCurModel();
                errorCode = 0;
                lastJudgement = true;

                #region PLC IOs Update

                AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근

                #endregion PLC IOs Update

                #region Mark Data Read& Confirm

                // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
                if (!InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                var Mark_T1L = InputValues["Tar_P1"] as MatchingRstData;
                var Mark_T1R = InputValues["Tar_P2"] as MatchingRstData;
                var Mark_T2L = InputValues["Obj_P1"] as MatchingRstData;
                var Mark_T2R = InputValues["Obj_P2"] as MatchingRstData;

                // Type2는 없으면 무시
                if (Mark_T1L == null || Mark_T1R == null)
                {
                    // Mark Data가 Null임
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                if (Mark_T1L.RefPoints == null)
                {
                    Mark_T1L.RefPoints = new List<XYT>();
                    Mark_T1L.RefPoints.Add(new XYT(0, 0, 0));
                }
                if (Mark_T1R.RefPoints == null)
                {
                    Mark_T1R.RefPoints = new List<XYT>();
                    Mark_T1R.RefPoints.Add(new XYT(0, 0, 0));
                }
                if (Mark_T2L != null && Mark_T2L.RefPoints == null)
                {
                    Mark_T2L.RefPoints = new List<XYT>();
                    Mark_T2L.RefPoints.Add(new XYT(0, 0, 0));
                }
                if (Mark_T2R != null && Mark_T2R.RefPoints == null)
                {
                    Mark_T2R.RefPoints = new List<XYT>();
                    Mark_T2R.RefPoints.Add(new XYT(0, 0, 0));
                }

                #endregion Mark Data Read& Confirm

                #region Tape Type Selection

                // 혹시 모르니 일단 초기화
                MatchingRstData markLeft = null;
                MatchingRstData markRight = null;

                int typeIndex = 0;

                // Type 1이 있으면 무조건 1 넣어라, 없으면 Type 2 확인, 그것도 없으면 Error
                if (Mark_T1L.SuccessIndex != -1 && Mark_T1R.SuccessIndex != -1)
                {
                    markLeft = Mark_T1L;
                    markRight = Mark_T1R;
                    typeIndex = 1;
                }
                else if (Mark_T2L.SuccessIndex != -1 && Mark_T2R.SuccessIndex != -1)
                {
                    markLeft = Mark_T2L;
                    markRight = Mark_T2R;
                    typeIndex = 2;
                }
                else
                {
                    errorCode = AlgoActionBase.Err_Mark_Not_Find;
                    return false;
                }

                #endregion Tape Type Selection

                #region Coordinate Pos Calc & CalData Cofirm

                if (O_Left_CalDataObj == null || O_Right_CalDataObj == null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    // Calibration 설정 안됨.
                    return false;
                }
                var Robot_Left = O_Left_CalDataObj.GetV2R(model, new XY(markLeft.OutputXYT.X, markLeft.OutputXYT.Y));
                var Robot_Right = O_Right_CalDataObj.GetV2R(model, new XY(markRight.OutputXYT.X, markRight.OutputXYT.Y));

                var Robot_CAM_Left = new XY(0, 0);
                var Robot_CAM_Right = new XY(0, 0);

                var Robot_Ref_Left = O_Left_CalDataObj.GetV2R(model, new XY(markLeft.RefPoints[0].X, markLeft.RefPoints[0].Y));
                var Robot_Ref_Right = O_Right_CalDataObj.GetV2R(model, new XY(markRight.RefPoints[0].X, markRight.RefPoints[0].Y));

                var Coord_Left = Robot_Left + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_Right = Robot_Right + O_Right_CalDataObj.GetRotateCenter(model);

                var Coord_CAM_Left = Robot_CAM_Left + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_CAM_Right = Robot_CAM_Right + O_Right_CalDataObj.GetRotateCenter(model);

                var Coord_Ref_Left = Robot_Ref_Left + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_Ref_Right = Robot_Ref_Right + O_Right_CalDataObj.GetRotateCenter(model);

                #endregion Coordinate Pos Calc & CalData Cofirm

                #region Model Data prepare

                AlgoParams modelParams;
                if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                var mParams = modelParams as AlgoMotherLineCICTape2PointModelParams;
                var limitX = (double)mParams.LimitX.Value;
                var limitY = (double)mParams.LimitY.Value;
                var limitT = (double)mParams.LimitT.Value;
                var Limit = new XYT(limitX, limitY, limitT);
                var T1_spec_Length = (double)mParams.T1_Spec_Length.Value;
                var T1_tor_Length = (double)mParams.T1_Tor_Length.Value;
                var T2_spec_Length = (double)mParams.T2_Spec_Length.Value;
                var T2_tor_Length = (double)mParams.T2_Tor_Length.Value;
                var scale_Length = (double)mParams.Scale_Length.Value;

                #endregion Model Data prepare

                #region Calc Rev Offset

                // 단변
                double camT = GetThetaColumn(Coord_CAM_Left.X, Coord_CAM_Right.X, Coord_CAM_Left.Y, Coord_CAM_Right.Y);
                double refT = GetThetaColumn(Coord_Ref_Left.X, Coord_Ref_Right.X, Coord_Ref_Left.Y, Coord_Ref_Right.Y);
                double pnlT = GetThetaColumn(Coord_Left.X, Coord_Right.X, Coord_Left.Y, Coord_Right.Y);

                pnlT -= camT;
                refT -= camT;
                camT = 0;

                var camTar = (Coord_CAM_Left + Coord_CAM_Right) / 2;
                var refTar = (Coord_Ref_Left + Coord_Ref_Right) / 2;
                var pnlObj = (Coord_Left + Coord_Right) / 2;

                var alignOffset = CvtPLCIO.OffsetXYT;

                var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
                var refTarxyt = new XYT(refTar.X, refTar.Y, refT);
                var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
                var camTarxyt_Un = new XYT(camTar.X, camTar.Y, camT);

                revAlign = new XYT();
                revUnload = new XYT();
                double radT, DriftX, DriftY;

                if (CalcType == CalcType.Center)
                {
                    // Attach 위치 보정값 계산.
                    camTarxyt = ApplyTargetOffset(camTarxyt, alignOffset);
                    radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revAlign.X = camTarxyt.X - DriftX;
                    revAlign.Y = camTarxyt.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else //역방향
                        revAlign.T = (radT / rad) * -1;

                    // Unload 위치 보정값 계산 // 얘는 오프셋없음.
                    camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                    radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revUnload.X = camTarxyt_Un.X - DriftX;
                    revUnload.Y = camTarxyt_Un.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revUnload.T = radT / rad;
                    else //역방향
                        revUnload.T = (radT / rad) * -1;
                }
                else if (CalcType == CalcType.Reference)
                {
                    // Attach 위치 보정값 계산.
                    refTarxyt = ApplyTargetOffset(refTarxyt, alignOffset);
                    radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revAlign.X = (refTarxyt.X - DriftX) * -1;
                    revAlign.Y = (refTarxyt.Y - DriftY) * -1;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else  //역방향
                        revAlign.T = (radT / rad) * -1;

                    // Unload 위치 보정값 계산 // 얘는 오프셋없음.    //CamCenter위치로
                    camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                    radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revUnload.X = camTarxyt_Un.X - DriftX;
                    revUnload.Y = camTarxyt_Un.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revUnload.T = radT / rad;
                    else  //역방향
                        revUnload.T = (radT / rad) * -1;
                }
                else if (CalcType == CalcType.PickUp)   //Target: 자재, Object: Reference
                {
                    pnlObjxyt = ApplyTargetOffset(pnlObjxyt, alignOffset);
                    radT = NormalizeTheta(pnlObjxyt.T - refTarxyt.T);
                    DriftX = Math.Cos(radT) * refTarxyt.X - Math.Sin(radT) * refTarxyt.Y;
                    DriftY = Math.Sin(radT) * refTarxyt.X + Math.Cos(radT) * refTarxyt.Y;
                    revAlign.X = pnlObjxyt.X - DriftX;
                    revAlign.Y = pnlObjxyt.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else  //역방향
                        revAlign.T = (radT / rad) * -1;
                }

                #endregion Calc Rev Offset

                #region Confirm Result (Align Spec Over Check)

                if (!ConfirmResult(revAlign, Limit))
                {
                    T_Left_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    lastJudgement = false;
                }

                #endregion Confirm Result (Align Spec Over Check)

                #region Calc Length & Confirm (Length Check)

                length = GetLength(Coord_Left, Coord_Right);
                if (typeIndex == 1)
                {
                    if (T1_spec_Length != 0)
                    {
                        if (Math.Abs(T1_spec_Length - length) > T1_tor_Length)
                        {
                            lastJudgement = false;
                            errorCode = AlgoActionBase.Err_Length_Check;
                            T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                            T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        }
                    }
                }
                else
                {
                    if (T2_spec_Length != 0)
                    {
                        if (Math.Abs(T2_spec_Length - length) > T2_tor_Length)
                        {
                            lastJudgement = false;
                            errorCode = AlgoActionBase.Err_Length_Check;
                            T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                            T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        }
                    }
                }

                #endregion Calc Length & Confirm (Length Check)

                #region Inspection Result Image Save (L_Check)

                if (T_Left_DisplayObj.Judgement != (uint)Judgement.OK && T_Right_DisplayObj.Judgement != (uint)Judgement.None)
                {
                    Task.Factory.StartNew(() =>
                    {
                        string _sourceID = DeepClone(sourceID);
                        DateTime dateTime = DateTime.Now;
                        string _judgement = "";

                        foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
                        {
                            if (T_Left_DisplayObj.Judgement == (uint)j)
                            {
                                _judgement = j.ToString();
                                break;
                            }
                        }

                        object obj = (Bitmap)T_Left_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                        T_Left_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);
                        object obj2 = (Bitmap)T_Right_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                        T_Right_DisplayObj.SaveImage(dateTime, obj2, _judgement, schName, _sourceID, true);

                        object obj3 = T_Left_DisplayObj.GetCurImage();
                        T_Left_DisplayObj.SaveImage(dateTime, obj3, _judgement, schName, _sourceID, false);
                        object obj4 = T_Right_DisplayObj.GetCurImage();
                        T_Right_DisplayObj.SaveImage(dateTime, obj4, _judgement, schName, _sourceID, false);
                    });
                }

                #endregion Inspection Result Image Save (L_Check)

                #region Result Data Update(DataGridView Insert)

                AlgoRst = new AlgoMotherLineCICTapePreAlignResult
                {
                    Name = name,
                    ID = sourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    Rev1X = Math.Round(revAlign.X, 3),
                    Rev1Y = Math.Round(revAlign.Y, 3),
                    Rev1T = Math.Round(revAlign.T, 3),

                    Rev2X = Math.Round(revUnload.X, 3),
                    Rev2Y = Math.Round(revUnload.Y, 3),
                    Rev2T = Math.Round(revUnload.T, 3),

                    TypeIndex = typeIndex,
                    Length = Math.Round(length, 3),
                    Result = lastJudgement,

                    PL_X = Math.Round(markLeft.OutputXYT.X, 3),  //Mark Pixel 좌표
                    PL_Y = Math.Round(markLeft.OutputXYT.Y, 3),
                    PR_X = Math.Round(markRight.OutputXYT.X, 3),
                    PR_Y = Math.Round(markRight.OutputXYT.Y, 3),

                    CL_X = Math.Round(Coord_Left.X, 3),
                    CL_Y = Math.Round(Coord_Left.Y, 3),
                    CR_X = Math.Round(Coord_Right.X, 3),
                    CR_Y = Math.Round(Coord_Right.Y, 3),

                    Type = CalcType.ToString(),
                    Pnl_T = Math.Round(pnlT, 3),
                    Ref_T = Math.Round(refT, 3),
                    Cam_T = Math.Round(camT, 3),    //camT=0인데 의미가 있나

                    PLC_OffsetX = alignOffset.X,
                    PLC_OffsetY = alignOffset.Y,
                    PLC_OffsetT = alignOffset.T,
                };

                #endregion Result Data Update(DataGridView Insert)

                SystemLogger.WriteAlignDBLog(name, AlgoRst);
                //#endregion

                #region Vision Write (Result & FDC)

                WriteVisionIO(revAlign, revUnload, typeIndex, "");

                #endregion Vision Write (Result & FDC)

                return lastJudgement;
            }
            catch (Exception ex)
            {
            }
            return lastJudgement;
        }

        /// <summary>
        /// Tape Align 은 WriteVisionID 를 별도로 호출
        /// </summary>
        /// <param name="rev1"></param>
        /// <param name="rev2"></param>
        /// <param name="_typeIndex"></param>
        /// <param name="ID"></param>
        public void WriteVisionIO(object rev1, object rev2, int _typeIndex, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["TapeType"].NextValue = _typeIndex; IOs.Add(VisionValues["TapeType"]);
                    VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                    VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                    VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                    VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                    VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                    VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                    VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                    break;

                case AlignMotionType.UVW:
                    break;

                case AlignMotionType.UVRW:
                    break;
            }

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }
    }
}