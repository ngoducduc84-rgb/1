﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;
using System.Windows.Media;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    public partial class AlgoMotherLineCICObject
    {
        private bool TapePreAlign2PointRun()
        {
            try
            {
                string model = SystemModel.GetCurModel();
                errorCode = 0;

                lastJudgement = true;

                #region PLC IOs Update

                AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근

                #endregion PLC IOs Update

                #region Mark Data Read& Confirm

                // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
                if (!InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                // 2020.03.31 hdy MatchingRstData -> IPointResult로 변경
                var Mark_P1 = InputValues["Obj_P1"] as IPointResult;
                var Mark_P2 = InputValues["Obj_P2"] as IPointResult;
                if (Mark_P1 == null || Mark_P2 == null)
                {
                    // Mark Data가 Null임
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                if (Mark_P1.RefPoints == null)
                {
                    Mark_P1.RefPoints = new List<XYT>();
                    Mark_P1.RefPoints.Add(new XYT(0, 0, 0));
                }
                if (Mark_P2.RefPoints == null)
                {
                    Mark_P2.RefPoints = new List<XYT>();
                    Mark_P2.RefPoints.Add(new XYT(0, 0, 0));
                }

                #endregion Mark Data Read& Confirm

                #region Coordinate Pos Calc & CalData Cofirm

                int typeIndex = 0;

                //// Type 1이 있으면 무조건 1 넣어라, 없으면 Type 2 확인, 그것도 없으면 Error
                //if (Mark_P1.SuccessIndex != -1)
                //{
                //    typeIndex = 1;
                //}
                //else if (Mark_P2.SuccessIndex != -1)
                //{
                //    typeIndex = 2;
                //}
                //else
                //{
                //    ErrorCode = AlgoActionBase.Err_Mark_Not_Find;
                //    return false;
                //}

                if (O_Left_CalDataObj == null || O_Right_CalDataObj == null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    // Calibration 설정 안됨.
                    return false;
                }

                var Robot_P1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_P1.OutputXYT.X, Mark_P1.OutputXYT.Y));
                var Robot_P2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_P2.OutputXYT.X, Mark_P2.OutputXYT.Y));

                var Robot_CAM_P1 = new XY(0, 0);
                var Robot_CAM_P2 = new XY(0, 0);

                // 2020.04.22 hdy 같은 화면일 경우,, case 수정,,
                XY Robot_Ref_P1; XY Robot_Ref_P2;
                if (Mark_P1.RefPoints[0].X == Mark_P2.RefPoints[0].X)        // 같은 이미지일 경우,,
                {
                    Robot_Ref_P1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_P1.RefPoints[0].X, Mark_P1.RefPoints[0].Y));
                    Robot_Ref_P2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_P2.RefPoints[1].X, Mark_P2.RefPoints[1].Y));
                }
                else
                {
                    Robot_Ref_P1 = O_Left_CalDataObj.GetV2R(model, new XY(Mark_P1.RefPoints[0].X, Mark_P1.RefPoints[0].Y));
                    Robot_Ref_P2 = O_Right_CalDataObj.GetV2R(model, new XY(Mark_P2.RefPoints[0].X, Mark_P2.RefPoints[0].Y));
                }

                var Coord_P1 = Robot_P1 + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_P2 = Robot_P2 + O_Right_CalDataObj.GetRotateCenter(model);

                var Coord_CAM_P1 = Robot_CAM_P1 + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_CAM_P2 = Robot_CAM_P2 + O_Right_CalDataObj.GetRotateCenter(model);

                var Coord_Ref_P1 = Robot_Ref_P1 + O_Left_CalDataObj.GetRotateCenter(model);
                var Coord_Ref_P2 = Robot_Ref_P2 + O_Right_CalDataObj.GetRotateCenter(model);

                #endregion Coordinate Pos Calc & CalData Cofirm

                #region Model Data prepare

                AlgoParams modelParams;
                if (!ModelParams.TryGetValue(model, out modelParams)) return false;
                var mParams = modelParams as AlogMotherLineCIC2PointModelParams;
                var limitX = (double)mParams.LimitX.Value;
                var limitY = (double)mParams.LimitY.Value;
                var limitT = (double)mParams.LimitT.Value;
                var Limit = new XYT(limitX, limitY, limitT);
                var spec_Length = (double)mParams.Spec_Length.Value;
                var tor_Length = (double)mParams.Tor_Length.Value;
                var scale_Length = (double)mParams.Scale_Length.Value;

                var retryX = (double)mParams.RetryX?.Value;
                var retryY = (double)mParams.RetryY?.Value;
                var retryT = (double)mParams.RetryT?.Value;

                #endregion Model Data prepare

                #region Calc Rev Offset

                // 단변
                double camT = GetThetaColumn(Coord_CAM_P1.X, Coord_CAM_P2.X, Coord_CAM_P1.Y, Coord_CAM_P2.Y);
                double refT = GetThetaColumn(Coord_Ref_P1.X, Coord_Ref_P2.X, Coord_Ref_P1.Y, Coord_Ref_P2.Y);
                double pnlT = GetThetaColumn(Coord_P1.X, Coord_P2.X, Coord_P1.Y, Coord_P2.Y);

                pnlT -= camT;
                refT -= camT;
                camT = 0;

                var camTar = (Coord_CAM_P1 + Coord_CAM_P2) / 2;
                var refTar = (Coord_Ref_P1 + Coord_Ref_P2) / 2;
                var pnlObj = (Coord_P1 + Coord_P2) / 2;

                var alignOffset = CvtPLCIO.OffsetXYT;

                var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
                var refTarxyt = new XYT(refTar.X, refTar.Y, refT);
                var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
                var camTarxyt_Un = new XYT(camTar.X, camTar.Y, camT);

                revAlign = new XYT();
                revUnload = new XYT();
                double radT, DriftX, DriftY;

                if (CalcType == CalcType.Center)
                {
                    // Attach 위치 보정값 계산.
                    camTarxyt = ApplyTargetOffset(camTarxyt, alignOffset);
                    radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revAlign.X = camTarxyt.X - DriftX;
                    revAlign.Y = camTarxyt.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else //역방향
                        revAlign.T = (radT / rad) * -1;

                    // Unload 위치 보정값 계산 // 얘는 오프셋없음.
                    camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                    radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revUnload.X = camTarxyt_Un.X - DriftX;
                    revUnload.Y = camTarxyt_Un.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revUnload.T = radT / rad;
                    else //역방향
                        revUnload.T = (radT / rad) * -1;
                }
                else if (CalcType == CalcType.Reference)
                {
                    // Attach 위치 보정값 계산.
                    refTarxyt = ApplyTargetOffset(refTarxyt, alignOffset);
                    radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revAlign.X = refTarxyt.X - DriftX;
                    revAlign.Y = refTarxyt.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else  //역방향
                        revAlign.T = (radT / rad) * -1;

                    // Unload 위치 보정값 계산 // 얘는 오프셋없음.    //CamCenter위치로
                    camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                    radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                    DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                    DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                    revUnload.X = camTarxyt_Un.X - DriftX;
                    revUnload.Y = camTarxyt_Un.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revUnload.T = radT / rad;
                    else  //역방향
                        revUnload.T = (radT / rad) * -1;
                }
                else if (CalcType == CalcType.PickUp)   //Target: 자재, Object: Reference
                {
                    pnlObjxyt = ApplyTargetOffset(pnlObjxyt, alignOffset);
                    radT = NormalizeTheta((pnlObjxyt.T) - refTarxyt.T);
                    DriftX = Math.Cos(radT) * refTarxyt.X - Math.Sin(radT) * refTarxyt.Y;
                    DriftY = Math.Sin(radT) * refTarxyt.X + Math.Cos(radT) * refTarxyt.Y;
                    revAlign.X = pnlObjxyt.X - DriftX;
                    revAlign.Y = pnlObjxyt.Y - DriftY;
                    if (ThetaDirection == ThetaDirection.Normal)    //정방향
                        revAlign.T = radT / rad;
                    else  //역방향
                        revAlign.T = (radT / rad) * -1;
                }

                #endregion Calc Rev Offset

                #region VirtualMark

                if (MachineType == MachineType.Bending)
                {
                    MatchingRstData rst1 = Mark_P1 as MatchingRstData;
                    MatchingRstData rst2 = Mark_P2 as MatchingRstData;

                    var vl = GetApplyRev(O_Left_CalDataObj, rst1, revAlign);
                    var vr = GetApplyRev(O_Right_CalDataObj, rst2, revAlign);
                    VirtualTarget = new XYXY(vl.X, vl.Y, vr.X, vr.Y);
                }

                #endregion VirtualMark

                #region Confirm Result (Align Spec Over Check)

                #region retry spec over

                if (!(retryX == 0.0 && retryY == 0.0 && retryT == 0.0)
                    && (Math.Abs(revAlign.X) > retryX || Math.Abs(revAlign.Y) > retryY || Math.Abs(revAlign.T) > retryT))
                {
                    O_Left_DisplayObj.Judgement = (uint)Judgement.Warning;
                    O_Right_DisplayObj.Judgement = (uint)Judgement.Warning;
                    errorCode = AlgoActionBase.Err_Retry_Spec_Over;
                    lastJudgement = false;
                }

                #endregion retry spec over

                #region limit spec over

                if (!ConfirmResult(revAlign, Limit))
                {
                    T_Left_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    T_Right_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                    errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                    lastJudgement = false;
                }

                #endregion limit spec over

                #endregion Confirm Result (Align Spec Over Check)

                #region Calc Length & Confirm (Length Check)

                length = GetLength(Coord_P1, Coord_P2);
                if (tor_Length != 0)
                {
                    if (Math.Abs(spec_Length - length) > tor_Length)
                    {
                        lastJudgement = false;
                        errorCode = AlgoActionBase.Err_Length_Check;
                        O_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        O_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        Mark_P1.Tool.ProcMode = ProcessMode.Manual;
                        Mark_P2.Tool.ProcMode = ProcessMode.Manual;
                    }
                }

                if (typeIndex == 1)
                {
                    if (spec_Length != 0)
                    {
                        //todo : 이 코드는 4점 얼라인을 토대로 추가 되었음.
                        if (Math.Abs(spec_Length - length) > tor_Length)
                        {
                            errorCode = AlgoActionBase.Err_Length_Check;
                            T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                            T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        }
                    }
                }
                else
                {
                    if (scale_Length != 0)
                    {
                        //todo : 이 코드는 4점 얼라인을 토대로 추가 되었음.
                        if (Math.Abs(scale_Length - length) > tor_Length)
                        {
                            ErrorCode = AlgoActionBase.Err_Length_Check;
                            T_Left_DisplayObj.Judgement = (uint)Judgement.L_Check;
                            T_Right_DisplayObj.Judgement = (uint)Judgement.L_Check;
                        }
                    }
                }

                #endregion Calc Length & Confirm (Length Check)

                #region Result Data Update(DataGridView Insert)

                AlgoRst = new AlogMotherLineCICPreAlignResult
                {
                    Name = name,
                    ID = sourceID,

                    CurTime = DateTime.Now.ToString("HH:mm:ss"),
                    CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                    Ref1X = Math.Round(revAlign.X, 3),
                    Ref1Y = Math.Round(revAlign.Y, 3),
                    Ref1T = Math.Round(revAlign.T, 3),

                    Ref2X = Math.Round(revUnload.X, 3),
                    Ref2Y = Math.Round(revUnload.Y, 3),
                    Ref2T = Math.Round(revUnload.T, 3),

                    ScoreX = Math.Round(Mark_P1.Score, 3),
                    ScoreY = Math.Round(Mark_P2.Score, 3),

                    Length = Math.Round(length, 3),
                    Result = lastJudgement,

                    P1_X = Math.Round(Mark_P1.OutputXYT.X, 3),  //Mark Pixel 좌표
                    P1_Y = Math.Round(Mark_P1.OutputXYT.Y, 3),
                    P2_X = Math.Round(Mark_P2.OutputXYT.X, 3),
                    P2_Y = Math.Round(Mark_P2.OutputXYT.Y, 3),

                    C1_X = Math.Round(Coord_P1.X, 3),
                    C1_Y = Math.Round(Coord_P1.Y, 3),
                    C2_X = Math.Round(Coord_P2.X, 3),
                    C2_Y = Math.Round(Coord_P2.Y, 3),

                    Type = CalcType.ToString(),
                    Pnl_T = Math.Round(pnlT / rad, 3),
                    Ref_T = Math.Round(refT / rad, 3),
                    Cam_T = Math.Round(camT / rad, 3),    //camT=0인데 의미가 있나

                    PLCOffset_X = alignOffset.X,
                    PLCOffset_Y = alignOffset.Y,
                    PLCOffset_T = alignOffset.T,
                };

                #endregion Result Data Update(DataGridView Insert)

                SystemLogger.WriteAlignDBLog(name, AlgoRst);
                //#endregion

                #region Vision Write (Result & FDC)

                WriteVisionIO(revAlign, revUnload, Mark_P1, Mark_P2, "", typeIndex);

                #endregion Vision Write (Result & FDC)
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                return false;
            }

            return lastJudgement;
        }
    }
}