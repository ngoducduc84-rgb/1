﻿using Iva.Bplus.Utils;

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    public enum CalcType { Center, Reference, PickUp }
    public enum ProcessType { PanelPreAlign, TapePreAlign,MainAlign, Inspection }
    public enum ThetaDirection { Normal, Reverse }
    public enum Direction { Normal, Reverse }
    public enum GrabPos { P1, P2 }
    public enum OffsetType { XYT, XYXY }
    public enum MachineType { Normal, Bending, CSpacer }
}

