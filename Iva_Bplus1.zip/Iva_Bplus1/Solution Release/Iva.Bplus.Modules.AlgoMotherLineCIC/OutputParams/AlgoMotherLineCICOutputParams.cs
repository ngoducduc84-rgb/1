﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;


namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    class AlgoMotherLineCICOutputParams : OutputParams
    {
        #region Logging
        public object Result { get; set; }
        #endregion
    }
}
