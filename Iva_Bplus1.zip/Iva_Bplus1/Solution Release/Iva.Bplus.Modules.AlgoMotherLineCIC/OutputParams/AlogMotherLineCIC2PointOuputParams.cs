﻿using Iva.Bplus.Abstract;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    internal class AlogMotherLineCIC2PointOuputParams : OutputParams
    {
        #region Logging

        public object Result { get; set; }

        #endregion Logging
    }
}