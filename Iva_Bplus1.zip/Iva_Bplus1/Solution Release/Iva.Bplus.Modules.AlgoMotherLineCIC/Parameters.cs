﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Struct;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    public class Parameters : AlgoParams
    {
        public AlgoParam TargetX;
        public AlgoParam TargetY;

        public Parameters()
           : base()
        {
            TargetX = new AlgoParam();
            TargetY = new AlgoParam();
        }
    }
}
