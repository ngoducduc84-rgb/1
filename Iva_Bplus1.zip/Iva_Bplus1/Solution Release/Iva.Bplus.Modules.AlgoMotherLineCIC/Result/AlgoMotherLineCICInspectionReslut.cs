﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    [SerializableAttribute]
    public class AlgoMotherLineCICInspectionResult : AlgoResultBase
    {
        #region [fiedls]

        private double lx;
        private double ly;
        private double rx;
        private double ry;

        private double revX;
        private double revY;
        private double revT;

        private double offset1X;
        private double offset1Y;
        private double offset1T;

        private double offset2X;
        private double offset2Y;
        private double offset2T;

        private double length_tar;
        private double length_obj;
        private bool result;

        private double target_P1_X;
        private double target_P1_Y;
        private double target_P2_X;
        private double target_P2_Y;

        private double object_P1_X;
        private double object_P1_Y;
        private double object_P2_X;
        private double object_P2_Y;


        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;

        private double targetp1Score;
        private double targetp2Score;
        private double objectp1Score;
        private double objectp2Score;

        private double plcOffset_Lx;
        private double plcOffset_Ly;
        private double plcOffset_Rx;
        private double plcOffset_Ry;

        //2Point Align
        private double lenght = 0.0;

        private string type;
        private double pnl_T;
        private double ref_T;
        private double cam_T;

        // twim 김윤동 추가
        private double plcOffset_X;

        private double plcOffset_Y;
        private double plcOffset_T;

        #endregion [fiedls]

        #region [Properties]

        #region 2Point Align

        //public double Length
        //{
        //    get { return lenght; }
        //    set { if (value == lenght) return; lenght = value; OnPropertyChanged(nameof(Length)); }
        //}

        public string Type
        {
            get { return type; }
            set { if (value == type) return; type = value; OnPropertyChanged(nameof(Type)); }
        }

        //public double Pnl_T
        //{
        //    get { return pnl_T; }
        //    set { if (value == pnl_T) return; pnl_T = value; OnPropertyChanged(nameof(Pnl_T)); }
        //}

        //public double Ref_T
        //{
        //    get { return ref_T; }
        //    set { if (value == ref_T) return; ref_T = value; OnPropertyChanged(nameof(Ref_T)); }
        //}

        //public double Cam_T
        //{
        //    get { return cam_T; }
        //    set { if (value == cam_T) return; cam_T = value; OnPropertyChanged(nameof(Cam_T)); }
        //}

        //public double PLCOffset_X
        //{
        //    get { return plcOffset_X; }
        //    set { if (value == plcOffset_X) return; plcOffset_X = value; OnPropertyChanged(nameof(PLCOffset_X)); }
        //}

        //public double PLCOffset_Y
        //{
        //    get { return plcOffset_Y; }
        //    set { if (value == plcOffset_Y) return; plcOffset_Y = value; OnPropertyChanged(nameof(plcOffset_Y)); }
        //}

        //public double PLCOffset_T
        //{
        //    get { return plcOffset_T; }
        //    set { if (value == plcOffset_T) return; plcOffset_T = value; OnPropertyChanged(nameof(plcOffset_T)); }
        //}

        #endregion 2Point Align

        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }

        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }

        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }

        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }

        public double Lx
        {
            get { return lx; }
            set { if (value == lx) return; lx = value; OnPropertyChanged(nameof(Lx)); }
        }

        public double Ly
        {
            get { return ly; }
            set { if (value == ly) return; ly = value; OnPropertyChanged(nameof(Ly)); }
        }

        public double Rx
        {
            get { return rx; }
            set { if (value == rx) return; rx = value; OnPropertyChanged(nameof(Rx)); }
        }

        public double Ry
        {
            get { return ry; }
            set { if (value == ry) return; ry = value; OnPropertyChanged(nameof(Ry)); }
        }

        //public double RevX
        //{
        //    get { return revX; }
        //    set { if (value == revX) return; revX = value; OnPropertyChanged(nameof(RevX)); }
        //}

        //public double RevY
        //{
        //    get { return revY; }
        //    set { if (value == revY) return; revY = value; OnPropertyChanged(nameof(RevY)); }
        //}

        //public double RevT
        //{
        //    get { return revT; }
        //    set { if (value == revT) return; revT = value; OnPropertyChanged(nameof(RevT)); }
        //}

        //public double Offset1X
        //{
        //    get { return offset1X; }
        //    set { if (value == offset1X) return; offset1X = value; OnPropertyChanged(nameof(Offset1X)); }
        //}

        //public double Offset1Y
        //{
        //    get { return offset1Y; }
        //    set { if (value == offset1Y) return; offset1Y = value; OnPropertyChanged(nameof(Offset1Y)); }
        //}

        //public double Offset1T
        //{
        //    get { return offset1T; }
        //    set { if (value == offset1T) return; offset1T = value; OnPropertyChanged(nameof(Offset1T)); }
        //}

        //public double Offset2X
        //{
        //    get { return offset2X; }
        //    set { if (value == offset2X) return; offset2X = value; OnPropertyChanged(nameof(Offset2X)); }
        //}

        //public double Offset2Y
        //{
        //    get { return offset2Y; }
        //    set { if (value == offset2Y) return; offset2Y = value; OnPropertyChanged(nameof(Offset2Y)); }
        //}

        //public double Offset2T
        //{
        //    get { return offset2T; }
        //    set { if (value == offset2T) return; offset2T = value; OnPropertyChanged(nameof(Offset2T)); }
        //}

        public double Length_tar
        {
            get { return length_tar; }
            set { if (value == length_tar) return; length_tar = value; OnPropertyChanged(nameof(Length_tar)); }
        }

        public double Length_obj
        {
            get { return length_obj; }
            set { if (value == length_obj) return; length_obj = value; OnPropertyChanged(nameof(Length_obj)); }
        }

        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }

        public double Target_P1_X
        {
            get { return target_P1_X; }
            set { if (value == target_P1_X) return; target_P1_X = value; OnPropertyChanged(nameof(Target_P1_X)); }
        }

        public double Target_P1_Y
        {
            get { return target_P1_Y; }
            set { if (value == target_P1_Y) return; target_P1_Y = value; OnPropertyChanged(nameof(Target_P1_Y)); }
        }

        public double Target_P2_X
        {
            get { return target_P2_X; }
            set { if (value == target_P2_X) return; target_P2_X = value; OnPropertyChanged(nameof(Target_P2_X)); }
        }

        public double Target_P2_Y
        {
            get { return target_P2_Y; }
            set { if (value == target_P2_Y) return; target_P2_Y = value; OnPropertyChanged(nameof(Target_P2_Y)); }
        }

        public double Object_P1_X
        {
            get { return object_P1_X; }
            set { if (value == object_P1_X) return; object_P1_X = value; OnPropertyChanged(nameof(Object_P1_X)); }
        }

        public double Object_P1_Y
        {
            get { return object_P1_Y; }
            set { if (value == object_P1_Y) return; object_P1_Y = value; OnPropertyChanged(nameof(Object_P1_Y)); }
        }

        public double Object_P2_X
        {
            get { return object_P2_X; }
            set { if (value == object_P2_X) return; object_P2_X = value; OnPropertyChanged(nameof(Object_P2_X)); }
        }

        public double Object_P2_Y
        {
            get { return object_P2_Y; }
            set { if (value == object_P2_Y) return; object_P2_Y = value; OnPropertyChanged(nameof(Object_P2_Y)); }
        }

        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }

        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }

        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }

        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }




        //private double targetp1Score;
        //private double targetp2Score;
        //private double objectp1Score;
        //private double objectp2Score;

        public double Target_P1_Score
        {
            get { return targetp1Score; }
            set { if (value == targetp1Score) return; targetp1Score = value; OnPropertyChanged(nameof(Target_P1_Score)); }
        }

        public double Target_P2_Score
        {
            get { return targetp2Score; }
            set { if (value == targetp2Score) return; targetp2Score = value; OnPropertyChanged(nameof(Target_P2_Score)); }
        }

        public double Object_P1_Score
        {
            get { return objectp1Score; }
            set { if (value == objectp1Score) return; objectp1Score = value; OnPropertyChanged(nameof(Object_P1_Score)); }
        }

        public double Object_P2_Score
        {
            get { return objectp2Score; }
            set { if (value == objectp2Score) return; objectp2Score = value; OnPropertyChanged(nameof(Object_P2_Score)); }
        }


        //public double PlcOffset_Lx
        //{
        //    get { return plcOffset_Lx; }
        //    set { if (value == plcOffset_Lx) return; plcOffset_Lx = value; OnPropertyChanged(nameof(PlcOffset_Lx)); }
        //}

        //public double PlcOffset_Ly
        //{
        //    get { return plcOffset_Ly; }
        //    set { if (value == plcOffset_Ly) return; plcOffset_Ly = value; OnPropertyChanged(nameof(PlcOffset_Ly)); }
        //}

        //public double PlcOffset_Rx
        //{
        //    get { return plcOffset_Rx; }
        //    set { if (value == plcOffset_Rx) return; plcOffset_Rx = value; OnPropertyChanged(nameof(PlcOffset_Rx)); }
        //}

        //public double PlcOffset_Ry
        //{
        //    get { return plcOffset_Ry; }
        //    set { if (value == plcOffset_Ry) return; plcOffset_Ry = value; OnPropertyChanged(nameof(PlcOffset_Ry)); }
        //}

        #endregion [Properties]

        public AlgoMotherLineCICInspectionResult() : base()
        {
        }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "Lx: {3},\nLy: {4},\n" +
                                  "Rx: {5},\noRy: {6},\n" +
                                  "LengthTarget: {7},\nResult: {8},\n" +
                                  "Target_P1_X: {9},\nTarget_P2_Y: {10},\nTarget_P2_X: {11},\nTarget_P2_Y: {12},\n" +
                                  "Object_P1_X: {13},\nObject_P2_Y: {14},\nObject_P2_X: {15},\nObject_P2_Y: {16},\n" +
                                  "C1_X: {17},\nC1_Y: {18},\nC2_X: {19},\nC2_Y: {20}," +
                                  "\nTarget_P1_Score: {21}\nTarget_P2_Score: {22}\nObject_P1_Score: {23}\nObject_P2_Score: {24}\n"
                                  , typeof(AlgoMotherLineCICInspectionResult).ToString(), curDate, curTime
                                  , Lx, Ly
                                  , Rx, Ry
                                  , length_tar, result
                                  , target_P1_X, target_P1_Y, target_P2_X, target_P2_Y
                                  , object_P1_X, object_P1_Y, object_P2_X, object_P2_Y
                                  , c1_X, c1_Y, c2_X, c2_Y
                                  , targetp1Score, targetp2Score, Object_P2_Score, Object_P2_Score
                                  );
            //return "";
        }
    }
}