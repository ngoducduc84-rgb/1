﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    [SerializableAttribute]
    internal class AlgoMotherLineCICMainAlignResult : AlgoResultBase
    {
        #region [fiedls]

        //private double lx;
        //private double ly;
        //private double rx;
        //private double ry;

        //private double revX;
        //private double revY;
        //private double revT;

        private double Rev1x;
        private double Rev1y;
        private double Rev1t;

        private double Rev2x;
        private double Rev2y;
        private double Rev2t;

        private double length_tar;
        private double length_obj;
        private bool result;

        private double p1_X;
        private double p1_Y;
        private double p2_X;
        private double p2_Y;

        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;

        private double plcOffset_Lx;
        private double plcOffset_Ly;
        private double plcOffset_Rx;
        private double plcOffset_Ry;

        private double tar_score1;
        private double tar_score2;
        private double obj_score1;
        private double obj_score2;

        #endregion [fiedls]

        #region [Properties]

        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }

        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }

        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }

        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }

        //public double Lx
        //{
        //    get { return lx; }
        //    set { if (value == lx) return; lx = value; OnPropertyChanged(nameof(Lx)); }
        //}

        //public double Ly
        //{
        //    get { return ly; }
        //    set { if (value == ly) return; ly = value; OnPropertyChanged(nameof(Ly)); }
        //}

        //public double Rx
        //{
        //    get { return rx; }
        //    set { if (value == rx) return; rx = value; OnPropertyChanged(nameof(Rx)); }
        //}

        //public double Ry
        //{
        //    get { return ry; }
        //    set { if (value == ry) return; ry = value; OnPropertyChanged(nameof(Ry)); }
        //}

        //public double RevX
        //{
        //    get { return revX; }
        //    set { if (value == revX) return; revX = value; OnPropertyChanged(nameof(RevX)); }
        //}

        //public double RevY
        //{
        //    get { return revY; }
        //    set { if (value == revY) return; revY = value; OnPropertyChanged(nameof(RevY)); }
        //}

        //public double RevT
        //{
        //    get { return revT; }
        //    set { if (value == revT) return; revT = value; OnPropertyChanged(nameof(RevT)); }
        //}

        public double Rev1X
        {
            get { return Rev1x; }
            set { if (value == Rev1x) return; Rev1x = value; OnPropertyChanged(nameof(Rev1X)); }
        }

        public double Rev1Y
        {
            get { return Rev1y; }
            set { if (value == Rev1y) return; Rev1y = value; OnPropertyChanged(nameof(Rev1Y)); }
        }

        public double Rev1T
        {
            get { return Rev1t; }
            set { if (value == Rev1t) return; Rev1t = value; OnPropertyChanged(nameof(Rev1T)); }
        }

        public double Rev2X
        {
            get { return Rev2x; }
            set { if (value == Rev2x) return; Rev2x = value; OnPropertyChanged(nameof(Rev2X)); }
        }

        public double Rev2Y
        {
            get { return Rev2y; }
            set { if (value == Rev2y) return; Rev2y = value; OnPropertyChanged(nameof(Rev2Y)); }
        }

        public double Rev2T
        {
            get { return Rev2t; }
            set { if (value == Rev2t) return; Rev2t = value; OnPropertyChanged(nameof(Rev2T)); }
        }

        public double Tar_Score1
        {
            get { return tar_score1; }
            set { if (value == tar_score1) return; tar_score1 = value; OnPropertyChanged(nameof(Tar_Score1)); }
        }

        public double Tar_Score2
        {
            get { return tar_score2; }
            set { if (value == tar_score2) return; tar_score2 = value; OnPropertyChanged(nameof(Tar_Score2)); }
        }

        public double Obj_Score1
        {
            get { return obj_score1; }
            set { if (value == obj_score1) return; obj_score1 = value; OnPropertyChanged(nameof(Obj_Score1)); }
        }

        public double Obj_Score2
        {
            get { return obj_score2; }
            set { if (value == obj_score2) return; obj_score2 = value; OnPropertyChanged(nameof(Obj_Score2)); }
        }

        public double Length_tar
        {
            get { return length_tar; }
            set { if (value == length_tar) return; length_tar = value; OnPropertyChanged(nameof(Length_tar)); }
        }

        public double Length_obj
        {
            get { return length_obj; }
            set { if (value == length_obj) return; length_obj = value; OnPropertyChanged(nameof(Length_obj)); }
        }

        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }

        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }

        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }

        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }

        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }

        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }

        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }

        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }

        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }

        public double PlcOffset_Lx
        {
            get { return plcOffset_Lx; }
            set { if (value == plcOffset_Lx) return; plcOffset_Lx = value; OnPropertyChanged(nameof(PlcOffset_Lx)); }
        }

        public double PlcOffset_Ly
        {
            get { return plcOffset_Ly; }
            set { if (value == plcOffset_Ly) return; plcOffset_Ly = value; OnPropertyChanged(nameof(PlcOffset_Ly)); }
        }

        public double PlcOffset_Rx
        {
            get { return plcOffset_Rx; }
            set { if (value == plcOffset_Rx) return; plcOffset_Rx = value; OnPropertyChanged(nameof(PlcOffset_Rx)); }
        }

        public double PlcOffset_Ry
        {
            get { return plcOffset_Ry; }
            set { if (value == plcOffset_Ry) return; plcOffset_Ry = value; OnPropertyChanged(nameof(PlcOffset_Ry)); }
        }

        #endregion [Properties]

        public AlgoMotherLineCICMainAlignResult() : base()
        {
        }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "Rev1X: {3},\nRev1Y: {4},\noRev1T: {5},\n" +
                                  "Rev2X: {6},\nRev2Y: {7},\nRev2T: {8},\n" +
                                  "LengthTarget: {9},\nResult: {10},\n" +
                                  "P1_X: {11},\nP1_Y: {12},\nP2_X: {13},\nP2_Y: {14},\n" +
                                  "C1_X: {15},\nC1_Y: {16},\nC2_X: {17},\nC2_Y: {18},\nTar_Score X: {19},\nTar_Score Y: {20},\nObj_Scroe{21},\nObj_Score{22},\n"
                                  , typeof(AlgoMotherLineCICMainAlignResult).ToString(), curTime, curDate
                                  , Rev1x, Rev1y, Rev1t
                                  , Rev2x, Rev2y, Rev2t
                                  , length_tar, result
                                  , p1_X, p1_Y, p2_X, p2_Y
                                  , c1_X, c1_Y, c2_X, c2_Y
                                  , Tar_Score1, Tar_Score2
                                  , Obj_Score1, Obj_Score2
                                  );
            //return "";
        }
    }
}