﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    [SerializableAttribute]
    class AlgoMotherLineCICTapePreAlignResult : AlgoResultBase
    {
        #region [fiedls]
        private string type;
        private double pnl_T;
        private double ref_T;
        private double cam_T;

        private double Rev1x;
        private double Rev1y;
        private double Rev1t;

        private double Rev2x;
        private double Rev2y;
        private double Rev2t;

        private int typeIndex;
        private double length;
        private bool result;

        private double pL_X;
        private double pL_Y;
        private double pR_X;
        private double pR_Y;

        private double cL_X;
        private double cL_Y;
        private double cR_X;
        private double cR_Y;

        //twim김윤동 PLCOffset추가
        private double plcOffset_X;
        private double plcOffset_Y;
        private double plcOffset_T;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string Type
        {
            get { return type; }
            set { if (value == type) return; type = value; OnPropertyChanged(nameof(Type)); }
        }
        public double Pnl_T
        {
            get { return pnl_T; }
            set { if (value == pnl_T) return; pnl_T = value; OnPropertyChanged(nameof(Pnl_T)); }
        }
        public double Ref_T
        {
            get { return ref_T; }
            set { if (value == ref_T) return; ref_T = value; OnPropertyChanged(nameof(Ref_T)); }
        }
        public double Cam_T
        {
            get { return cam_T; }
            set { if (value == cam_T) return; cam_T = value; OnPropertyChanged(nameof(Cam_T)); }
        }
        public double Rev1X
        {
            get { return Rev1x; }
            set { if (value == Rev1x) return; Rev1x = value; OnPropertyChanged(nameof(Rev1X)); }
        }
        public double Rev1Y
        {
            get { return Rev1y; }
            set { if (value == Rev1y) return; Rev1y = value; OnPropertyChanged(nameof(Rev1Y)); }
        }
        public double Rev1T
        {
            get { return Rev1t; }
            set { if (value == Rev1t) return; Rev1t = value; OnPropertyChanged(nameof(Rev1T)); }
        }

        public double Rev2X
        {
            get { return Rev2x; }
            set { if (value == Rev2x) return; Rev2x = value; OnPropertyChanged(nameof(Rev2X)); }
        }
        public double Rev2Y
        {
            get { return Rev2y; }
            set { if (value == Rev2y) return; Rev2y = value; OnPropertyChanged(nameof(Rev2Y)); }
        }
        public double Rev2T
        {
            get { return Rev2t; }
            set { if (value == Rev2t) return; Rev2t = value; OnPropertyChanged(nameof(Rev2T)); }
        }
        public int TypeIndex
        {
            get { return typeIndex; }
            set { if (value == typeIndex) return; typeIndex = value; OnPropertyChanged(nameof(TypeIndex)); }
        }
        public double Length
        {
            get { return length; }
            set { if (value == length) return; length = value; OnPropertyChanged(nameof(Length)); }
        }
        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public double PL_X
        {
            get { return pL_X; }
            set { if (value == pL_X) return; pL_X = value; OnPropertyChanged(nameof(PL_X)); }
        }
        public double PL_Y
        {
            get { return pL_Y; }
            set { if (value == pL_Y) return; pL_Y = value; OnPropertyChanged(nameof(PL_Y)); }
        }
        public double PR_X
        {
            get { return pR_X; }
            set { if (value == pR_X) return; pR_X = value; OnPropertyChanged(nameof(PR_X)); }
        }
        public double PR_Y
        {
            get { return pR_Y; }
            set { if (value == pR_Y) return; pR_Y = value; OnPropertyChanged(nameof(PR_Y)); }
        }
        public double CL_X
        {
            get { return cL_X; }
            set { if (value == cL_X) return; cL_X = value; OnPropertyChanged(nameof(CL_X)); }
        }
        public double CL_Y
        {
            get { return cL_Y; }
            set { if (value == cL_Y) return; cL_Y = value; OnPropertyChanged(nameof(CL_Y)); }
        }
        public double CR_X
        {
            get { return cR_X; }
            set { if (value == cR_X) return; cR_X = value; OnPropertyChanged(nameof(CR_X)); }
        }
        public double CR_Y
        {
            get { return cR_Y; }
            set { if (value == cR_Y) return; cR_Y = value; OnPropertyChanged(nameof(CR_Y)); }
        }
        //twim김윤동 PLCOffset추가
        public double PLC_OffsetX
        {
            get { return plcOffset_X; }
            set { if (value == plcOffset_X) return; plcOffset_X = value; OnPropertyChanged(nameof(plcOffset_X)); }
        }
        public double PLC_OffsetY
        {
            get { return plcOffset_X; }
            set { if (value == plcOffset_Y) return; plcOffset_Y = value; OnPropertyChanged(nameof(plcOffset_Y)); }
        }
        public double PLC_OffsetT
        {
            get { return plcOffset_T; }
            set { if (value == plcOffset_T) return; plcOffset_T = value; OnPropertyChanged(nameof(plcOffset_T)); }
        }
        #endregion


        public AlgoMotherLineCICTapePreAlignResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "Rev1X: {3},\nRev1Y: {4},\nRev1T: {5},\n" +
                                  "Rev2X: {6},\nRev2Y: {7},\nRev2T: {8},\n" +
                                  "TypeIndex: {9},\nResult: {10},\n" +
                                  "PL_X: {11},\nPL_Y: {12},\nPR_X: {13},\nPR_Y: {14},\n" +
                                  "CL_X: {15},\nCL_Y: {16},\nCR_X: {17},\nCR_Y: {18},\n" +
                                  "Type: {19},\nPnl_T: {20},\nRef_T: {21},\nCam_T: {22},\n" +
                                  "PLCOffsetX: {23}\n,PLCOffsetX: {24}\n,PLCOffsetX: {25},\n"
                                  , typeof(AlgoMotherLineCICTapePreAlignResult).ToString(), curTime, curDate
                                  , Rev1x, Rev1y, Rev1t
                                  , Rev2x, Rev2y, Rev2t
                                  , typeIndex, result
                                  , pL_X, pL_Y, pR_X, pR_Y
                                  , cL_X, cL_Y, cR_X, cR_Y
                                  , type, pnl_T, ref_T, cam_T
                                  , plcOffset_X, plcOffset_Y, plcOffset_T
                                  );
        }

    }

}
