﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoMotherLineCIC
{
    [SerializableAttribute]
    class AlogMotherLineCICPreAlignResult : AlgoResultBase
    {
        #region [fiedls]
        private string type;
        private double pnl_T;
        private double ref_T;
        private double cam_T;

        private double Rev1X;
        private double Rev1Y;
        private double Rev1T;

        private double Rev2X;
        private double Rev2Y;
        private double Rev2T;

        private double length;
        private bool result;

        private double p1_X;
        private double p1_Y;
        private double p2_X;
        private double p2_Y;

        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;

        // twim 김윤동 추가
        private double plcOffset_X;
        private double plcOffset_Y;
        private double plcOffset_T;

        private double scoreX;
        private double scoreY;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public string Type
        {
            get { return type; }
            set { if (value == type) return; type = value; OnPropertyChanged(nameof(Type)); }
        }
        public double Pnl_T
        {
            get { return pnl_T; }
            set { if (value == pnl_T) return; pnl_T = value; OnPropertyChanged(nameof(Pnl_T)); }
        }
        public double Ref_T
        {
            get { return ref_T; }
            set { if (value == ref_T) return; ref_T = value; OnPropertyChanged(nameof(Ref_T)); }
        }
        public double Cam_T
        {
            get { return cam_T; }
            set { if (value == cam_T) return; cam_T = value; OnPropertyChanged(nameof(Cam_T)); }
        } 
        public double Ref1X
        {
            get { return Rev1X; }
            set { if (value == Rev1X) return; Rev1X = value; OnPropertyChanged(nameof(Ref1X)); }
        }
        public double Ref1Y
        {
            get { return Rev1Y; }
            set { if (value == Rev1Y) return; Rev1Y = value; OnPropertyChanged(nameof(Ref1Y)); }
        }
        public double Ref1T
        {
            get { return Rev1T; }
            set { if (value == Rev1T) return; Rev1T = value; OnPropertyChanged(nameof(Ref1T)); }
        }

        public double Ref2X
        {
            get { return Rev2X; }
            set { if (value == Rev2X) return; Rev2X = value; OnPropertyChanged(nameof(Ref2X)); }
        }
        public double Ref2Y
        {
            get { return Rev2Y; }
            set { if (value == Rev2Y) return; Rev2Y = value; OnPropertyChanged(nameof(Ref2Y)); }
        }
        public double Ref2T
        {
            get { return Rev2T; }
            set { if (value == Rev2T) return; Rev2T = value; OnPropertyChanged(nameof(Ref2T)); }
        }
        public double Length
        {
            get { return length; }
            set { if (value == length) return; length = value; OnPropertyChanged(nameof(Length)); }
        }
        public double ScoreX
        {
            get { return scoreX; }
            set { if (value == scoreX) return; scoreX = value; OnPropertyChanged(nameof(ScoreX)); }
        }
        public double ScoreY
        {
            get { return scoreY; }
            set { if (value == scoreY) return; scoreY = value; OnPropertyChanged(nameof(ScoreY)); }
        }

        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }
        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }
        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }
        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }
        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }
        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }
        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }
        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }

        public double PLCOffset_X
        {
            get { return plcOffset_X; }
            set { if (value == plcOffset_X) return; plcOffset_X = value; OnPropertyChanged(nameof(PLCOffset_X)); }
        }
        public double PLCOffset_Y
        {
            get { return plcOffset_Y; }
            set { if (value == plcOffset_Y) return; plcOffset_Y = value; OnPropertyChanged(nameof(plcOffset_Y)); }
        }
        public double PLCOffset_T
        {
            get { return plcOffset_T; }
            set { if (value == plcOffset_T) return; plcOffset_T = value; OnPropertyChanged(nameof(plcOffset_T)); }
        }
        #endregion


        public AlogMotherLineCICPreAlignResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "Rev1X: {3},\nRev1Y: {4},\nRev1T: {5},\n" +
                                  "Rev2X: {6},\nRev2Y: {7},\nRev2T: {8},\n" +
                                  "Length: {9},\nResult: {10},\n" +
                                  "P1_X: {11},\nP1_Y: {12},\nP2_X: {13},\nP2_Y: {14},\n" +
                                  "C1_X: {15},\nC1_Y: {16},\nC2_X: {17},\nC2_Y: {18},\n" +
                                  "Type: {19},\nPnl_T: {20},\nRef_T: {21},\nCam_T: {22},\nScoreX: {23},\nScoreY: {24},\n"
                                  , typeof(AlogMotherLineCICPreAlignResult).ToString(), curTime, curDate
                                  , Rev1X, Rev1Y, Rev1T
                                  , Rev2X, Rev2Y, Rev2T
                                  , length, result
                                  , p1_X, p1_Y, p2_X, p2_Y
                                  , c1_X, c1_Y, c2_X, c2_Y
                                  , type, pnl_T, ref_T, cam_T
                                  , ScoreX, ScoreY
                                  );
        }
    }
}
