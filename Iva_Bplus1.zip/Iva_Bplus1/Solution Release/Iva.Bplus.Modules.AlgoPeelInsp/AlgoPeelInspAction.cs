﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;

namespace Iva.Bplus.Modules.AlgoPeelInsp
{
    [SerializableAttribute]
    public partial class AlgoPeelInspAction : AlgoActionBase
    {
        #region [Fields]     
        #endregion

        #region [Properties]   
        #endregion

        #region [Construct]
        public AlgoPeelInspAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new AlgoPeelInspInputParams();
            OutputParams = new AlgoPeelInspOutputParams();

            var obj = _object as AlgoPeelInspObject;
            obj.ModelParamType = typeof(AlgoPeelInspModelParams);
            var param = obj.CurParams as AlgoPeelInspModelParams;
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args,false);
            var Obj = modObject as AlgoPeelInspObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();

                var connection = this.parent.GetInputConnector("Trigger");
                Obj.schName = (connection.AttachedConnections[0].SourceConnector.ParentItem.ModAction as SchedulerActionBase).Name;

                var algoCmd = _args.Value as AlgoCommandInfo;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                DateTime dateTime = DateTime.Now;
                if (!Obj.Run())
                {
                    // 기존값들 초기화 필요함.
                    //SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    if(Obj.P1_DisplayObj.Judgement == (uint)Judgement.OK)
                        Obj.P1_DisplayObj.Judgement = (uint)Judgement.Error;
                    return OccurError(Obj.ErrorCode);
                }
                else
                {
                    //SystemLogger.WriteAlignDBLog(name, Obj.AlgoRst);
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    
                    Obj.AppendMessage(Name, "Inspection Complete");
                }
                #endregion
            }
            return End();
        }
        public override void PrepareSave() { base.PrepareSave(); }
        public override void Dispose() { base.Dispose(); }

        public override bool Reset()
        {
            if (!base.Reset()) return false;

            return true;
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion
    }
}
