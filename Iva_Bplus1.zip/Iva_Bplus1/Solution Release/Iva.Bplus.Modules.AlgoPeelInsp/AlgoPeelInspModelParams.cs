﻿using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.AlgoPeelInsp
{
    [SerializableAttribute]
    public partial class AlgoPeelInspModelParams : AlgoParams
    {
        private AlgoParam totalArea;
        private AlgoParam totalCount;
        private AlgoParam tor_Area;
        public AlgoParam TotalArea { get { return totalArea; } set { if (totalArea == value) return; totalArea = value; this.OnPropertyChanged(nameof(TotalArea)); } }
        public AlgoParam TotalCount { get { return totalCount; } set { if (totalCount == value) return; totalCount = value; this.OnPropertyChanged(nameof(TotalCount)); } }
        public AlgoParam Tor_Area { get { return tor_Area; } set { if (tor_Area == value) return; tor_Area = value; this.OnPropertyChanged(nameof(Tor_Area)); } }


        public AlgoPeelInspModelParams()
            : base()
        {
            TotalArea = new AlgoParam("TotalArea", "px", typeof(double), 0.0, "Blob or Hole Total Area ", (double)0, (double)10000000);
            TotalCount = new AlgoParam("TotalCount", "ea", typeof(int), 0, "Blob or Hole Total Count", (int)0, (int)100);
            Tor_Area = new AlgoParam("Tor_Area", "%", typeof(int), 0, "Blob or Hole Area Tolerence", (int)0, (int)100);
        }
    }
}
