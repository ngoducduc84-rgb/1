﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Cognex.VisionPro.ToolBlock;
using Cognex.VisionPro.Blob;
using Cognex.VisionPro;
using Iva.Bplus.Modules.CogDisplay;
using System.Drawing;
using Cognex.VisionPro.Display;

namespace Iva.Bplus.Modules.AlgoPeelInsp
{
    [SerializableAttribute]
    public partial class AlgoPeelInspObject : AlgoObjectBase
    {
        #region [Fields]
        private CogBlobLabelConstants checkLabel = CogBlobLabelConstants.Blob;
        private string p1_Display;
        public string schName = "";
        #endregion

        #region [properties]
        public CogBlobLabelConstants CheckLabel
        {
            get { return checkLabel; }
            set { if (checkLabel == value) return; checkLabel = value; this.OnPropertyChanged(nameof(CheckLabel)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }
        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }
        #endregion

        #region[Construct]
        public AlgoPeelInspObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new AlgoPeelInspModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return Inspection(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool Inspection()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근 // 사실상 Cell ID 또는 옵션만 가져오면 되나 귀찮으니 걍 업데이트
            #endregion

            #region InputData Data Read& Confirm
            // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
            if (!InputValues.ContainsKey("Inputs"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            var Inputs = InputValues["Inputs"] as Dictionary<string, object>;

            if (Inputs == null)
            {
                // InputData Data가 Null임
                errorCode = AlgoActionBase.Err_InputData_Info_Missing;
                return false;
            }

            if (!Inputs.ContainsKey("Results") || !Inputs.ContainsKey("Results1") || !Inputs.ContainsKey("Results2") || !Inputs.ContainsKey("Results3"))
            {
                errorCode = AlgoPeelInspAction.Err_InputData_Name_Missing;
                return false;
            }

            if (!(Inputs["Results"] is CogBlobResults) || !(Inputs["Results1"] is CogBlobResults) || !(Inputs["Results2"] is CogBlobResults) || !(Inputs["Results3"] is CogBlobResults))
            {
                errorCode = AlgoPeelInspAction.Err_InputData_Type_Missing;
                return false;
            }

            if (!Inputs.ContainsKey("Region") || !Inputs.ContainsKey("Region1") || !Inputs.ContainsKey("Region2") || !Inputs.ContainsKey("Region3"))
            {
                errorCode = AlgoPeelInspAction.Err_InputData_Name_Missing;
                return false;
            }
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as AlgoPeelInspModelParams;
            //var totalArea = (double)mParams.TotalArea.Value;
            //var totalCount = (int)mParams.TotalCount.Value;
            var tor_Area = (int)mParams.Tor_Area.Value;
            #endregion

            #region Blob Result prepare
            var BlobResults1 = Inputs["Results"] as CogBlobResults;
            var collection1 = BlobResults1.GetBlobs();
            var BlobResults2 = Inputs["Results1"] as CogBlobResults;
            var collection2 = BlobResults2.GetBlobs();
            var BlobResults3 = Inputs["Results2"] as CogBlobResults;
            var collection3 = BlobResults3.GetBlobs();
            var BlobResults4 = Inputs["Results3"] as CogBlobResults;
            var collection4 = BlobResults4.GetBlobs();

            double total1 = 0;
            foreach (CogBlobResult blob in collection1)
            {
                if (blob.Label == checkLabel)
                {
                    //cnt++;
                    total1 += blob.Area;
                }
            }

            double total2 = 0;
            foreach (CogBlobResult blob in collection2)
            {
                if (blob.Label == checkLabel)
                {
                    //cnt++;
                    total2 += blob.Area;
                }
            }

            double total3 = 0;
            foreach (CogBlobResult blob in collection3)
            {
                if (blob.Label == checkLabel)
                {
                    //cnt++;
                    total3 += blob.Area;
                }
            }

            double total4 = 0;
            foreach (CogBlobResult blob in collection4)
            {
                if (blob.Label == checkLabel)
                {
                    //cnt++;
                    total4 += blob.Area;
                }
            }
            #endregion

            #region Blob or Hole Check
            bool lastJudge = true;
            double matchingRate1 = 0;
            double matchingRate2 = 0;
            double matchingRate3 = 0;
            double matchingRate4 = 0;
            double totalArea = 0;

            if (Inputs["Region"] is CogRectangle)
            {
                totalArea = (Inputs["Region"] as CogRectangle).Width * (Inputs["Region"] as CogRectangle).Height;
            }
            else if (Inputs["Region"] is CogPolygon)
            {
                totalArea = (Inputs["Region"] as CogPolygon).Area;
            }
            else
            {
                errorCode = AlgoPeelInspAction.Err_InputData_Type_Missing;
                return false;
            }

            if (!PeelInsp(total1, totalArea, tor_Area, out matchingRate1))
            {
                errorCode = AlgoPeelInspAction.Err_Tolerance_Exceeded;
                P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                lastJudge = false;
            }

            if (Inputs["Region1"] is CogRectangle)
            {
                totalArea = (Inputs["Region1"] as CogRectangle).Width * (Inputs["Region1"] as CogRectangle).Height;
            }
            else if (Inputs["Region1"] is CogPolygon)
            {
                totalArea = (Inputs["Region1"] as CogPolygon).Area;
            }
            else
            {
                errorCode = AlgoPeelInspAction.Err_InputData_Type_Missing;
                return false;
            }

            if (!PeelInsp(total2, totalArea, tor_Area, out matchingRate2))
            {
                errorCode = AlgoPeelInspAction.Err_Tolerance_Exceeded;
                P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                lastJudge = false;
            }

            if (Inputs["Region2"] is CogRectangle)
            {
                totalArea = (Inputs["Region2"] as CogRectangle).Width * (Inputs["Region2"] as CogRectangle).Height;
            }
            else if (Inputs["Region2"] is CogPolygon)
            {
                totalArea = (Inputs["Region2"] as CogPolygon).Area;
            }
            else
            {
                errorCode = AlgoPeelInspAction.Err_InputData_Type_Missing;
                return false;
            }

            if (!PeelInsp(total3, totalArea, tor_Area, out matchingRate3))
            {
                errorCode = AlgoPeelInspAction.Err_Tolerance_Exceeded;
                P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                lastJudge = false;
            }

            if (Inputs["Region3"] is CogRectangle)
            {
                totalArea = (Inputs["Region3"] as CogRectangle).Width * (Inputs["Region3"] as CogRectangle).Height;
            }
            else if (Inputs["Region3"] is CogPolygon)
            {
                totalArea = (Inputs["Region3"] as CogPolygon).Area;
            }
            else
            {
                errorCode = AlgoPeelInspAction.Err_InputData_Type_Missing;
                return false;
            }

            if (!PeelInsp(total4, totalArea, tor_Area, out matchingRate4))
            {
                errorCode = AlgoPeelInspAction.Err_Tolerance_Exceeded;
                P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                lastJudge = false;
            }
            #endregion

            #region Inspection Result Image Save (Tor_Exceed)
            if (P1_DisplayObj.Judgement != (uint)Judgement.OK && P1_DisplayObj.Judgement != (uint)Judgement.None)
            {
                string _sourceID = DeepClone(sourceID);
                DateTime dateTime = DateTime.Now;
                string _judgement = "";

                foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
                {
                    if (P1_DisplayObj.Judgement == (uint)j)
                    {
                        _judgement = j.ToString();
                        break;
                    }
                }

                object obj = (Bitmap)P1_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                P1_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);                    
                
                object obj2 = P1_DisplayObj.GetCurImage();
                P1_DisplayObj.SaveImage(dateTime, obj2, _judgement, schName, _sourceID, false);                
            }
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new AlgoPeelInspResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                MatchingRate_1 = Math.Round(matchingRate1, 2),
                MatchingRate_2 = Math.Round(matchingRate2, 2),
                MatchingRate_3 = Math.Round(matchingRate3, 2),
                MatchingRate_4 = Math.Round(matchingRate4, 2),
                Tolerence = tor_Area,
                LastConfirm = lastJudge,
            };
            #endregion
            WriteVisionIO(matchingRate1, matchingRate2, matchingRate3, matchingRate4, "");
            SystemLogger.WriteAlignDBLog(name, AlgoRst);

            //#endregion

            return lastJudge;
        }

        private bool PeelInsp(double _areaSum, double _totalArea, double _spec, out double _matRate)
        {
            _matRate = _areaSum / _totalArea * 200;
            if (_matRate > 100) _matRate = 100;

            if (_spec == 0) return true;            
            if (_matRate >= _spec) return false;
            return true;
        }
        private bool CheckCount(int cnt, int totalCount)
        {
            if (totalCount == 0) return true;
            if (cnt == totalCount) return true;
            else return false;
        }
        private bool CheckArea(double total, double totalArea, int tor_Area)
        {
            if (totalArea == 0) return true;
            if (tor_Area == 0) return true;
            double confirmValue = total / totalArea * 100;
            if (confirmValue < (100 + tor_Area) || confirmValue > (100 - tor_Area)) return true;
            else return false;
        }

        private bool CheckLastResult(bool chkCount, bool chkArea)
        {
            if (chkCount && chkArea) return true;
            else if (!chkCount && chkArea)
            {
                errorCode = AlgoPeelInspAction.Err_Blob_Count_NG;
                return false;
            }
            else if (chkCount && !chkArea)
            {
                errorCode = AlgoPeelInspAction.Err_Blob_Area_NG;
                return false;
            }
            else if (!chkCount && !chkArea)
            {
                errorCode = AlgoPeelInspAction.Err_Blob_Count_Area_NG;
                return false;
            }
            return true;
        }
        #endregion

        public void WriteVisionIO(double _a, double _b, double _c, double _d, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();
            
            VisionValues["Tar#1_Pos#1"].NextValue = _a; IOs.Add(VisionValues["Tar#1_Pos#1"]);
            VisionValues["Tar#1_Pos#2"].NextValue = _b; IOs.Add(VisionValues["Tar#1_Pos#2"]);
            VisionValues["Tar#1_Pos#3"].NextValue = _a; IOs.Add(VisionValues["Tar#1_Pos#3"]);
            VisionValues["Tar#1_Pos#4"].NextValue = _b; IOs.Add(VisionValues["Tar#1_Pos#4"]);

            CommodObject.SetVisionValues(IOs);
        }

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            //Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }
    }
}
