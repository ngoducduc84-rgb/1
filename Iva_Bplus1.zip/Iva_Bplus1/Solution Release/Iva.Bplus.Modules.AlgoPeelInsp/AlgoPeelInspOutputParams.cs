﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using SvMip;
using System;

namespace Iva.Bplus.Modules.AlgoPeelInsp
{
    class AlgoPeelInspOutputParams : OutputParams
    {
        #region Logging
        public object Result { get; set; }
        #endregion
    }
}
