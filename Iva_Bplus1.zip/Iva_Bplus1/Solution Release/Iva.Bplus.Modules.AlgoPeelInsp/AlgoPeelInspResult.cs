﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.AlgoPeelInsp
{
    [SerializableAttribute]
    public class AlgoPeelInspResult : AlgoResultBase
    {
        #region [fiedls]
        private double matchingRate1;
        private double matchingRate2;
        private double matchingRate3;
        private double matchingRate4;
        private int tolerence;
        private int count;
        private bool judgeCount;
        private bool judgeArea;
        private bool lastConfirm;
        private double area;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double MatchingRate_1
        {
            get { return matchingRate1; }
            set { if (value == matchingRate1) return; matchingRate1 = value; OnPropertyChanged(nameof(MatchingRate_1)); }
        }
        public double MatchingRate_2
        {
            get { return matchingRate2; }
            set { if (value == matchingRate2) return; matchingRate2 = value; OnPropertyChanged(nameof(MatchingRate_2)); }
        }
        public double MatchingRate_3
        {
            get { return matchingRate3; }
            set { if (value == matchingRate3) return; matchingRate3 = value; OnPropertyChanged(nameof(MatchingRate_3)); }
        }
        public double MatchingRate_4
        {
            get { return matchingRate4; }
            set { if (value == matchingRate4) return; matchingRate4 = value; OnPropertyChanged(nameof(MatchingRate_4)); }
        }
        public int Tolerence
        {
            get { return tolerence; }
            set { if (value == tolerence) return; tolerence = value; OnPropertyChanged(nameof(Tolerence)); }
        }

        public int Count
        {
            get { return count; }
            set { if (value == count) return; count = value; OnPropertyChanged(nameof(Count)); }
        }

        public bool JudgeCount
        {
            get { return judgeCount; }
            set { if (value == judgeCount) return; judgeCount = value; OnPropertyChanged(nameof(JudgeCount)); }
        }

        public bool JudgeArea
        {
            get { return judgeArea; }
            set { if (value == judgeArea) return; judgeArea = value; OnPropertyChanged(nameof(JudgeArea)); }
        }

        public bool LastConfirm
        {
            get { return lastConfirm; }
            set { if (value == lastConfirm) return; lastConfirm = value; OnPropertyChanged(nameof(LastConfirm)); }
        }

        public double Area
        {
            get { return area; }
            set { if (value == area) return; area = value; OnPropertyChanged(nameof(Area)); }
        }
        #endregion


        public AlgoPeelInspResult() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n MatchingRate_1 : {3:00.00}\n MatchingRate_2 : {4:00.00}\n Tolerence : {5}\n Confirm : {6}",

                                 typeof(AlgoPeelInspResult).ToString(), curDate, curTime, matchingRate1, matchingRate2, tolerence, lastConfirm);
        }

    }
}
