﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;

namespace Iva.Bplus.Modules.AlgoSmartLoader
{
    [SerializableAttribute]
    public class AlgoSmartLoaderAction : AlgoActionBase
    {
        #region 생성자
        public AlgoSmartLoaderAction(ShapeBase _parent, string _name, string _source, AlgoObjectBase _object)
           : base(_parent, _name, _source, _object)
        {
            if (_object is AlgoSmartLoaderObject obj)
            {
                switch (obj.WorkType)
                {
                    case WorkType.ALIGN:
                        InputParams = new AlgoAlignInputParams(); // Input 파라메타 할당
                        obj.ModelParamType = typeof(AlgoAlignModelParams);// 모델 파라메타 타입 지정
                        ChildSettingView = new AlgoAlignSetting();// 세팅 뷰 생성
                        break;
                    case WorkType.MEASURE:
                        InputParams = new AlgoMeasureInputParams(); // Input 파라메타 할당
                        obj.ModelParamType = typeof(AlgoMeasureModelParams);// 모델 파라메타 타입 지정
                        ChildSettingView = new AlgoMeasureSetting();// 세팅 뷰 생성
                        break;
                    case WorkType.INSPECT:
                        InputParams = new AlgoInspectInputParams(); // Input 파라메타 할당
                        obj.ModelParamType = typeof(AlgoInspectModelParams);// 모델 파라메타 타입 지정
                        ChildSettingView = new AlgoInspectSetting();// 세팅 뷰 생성
                        break;
                    default:
                        break;
                }
                // 어이가 없네 ~~
                var param = obj.CurParams;
            }

            OutputParams = new AlgoAutoConnectingOutputParams();

            ChildSettingView.DataContext = this;
        }
        #endregion

        #region 공용 함수
        public override List<CommandReplyArgs> Play(ModuleActionBase _act, CmdReqArgs _args)
        {
            // 1. 커넥터 이름 가져오기
            string connName = Start(_act, _args, false);

            if (connName.Equals("Trigger") || string.IsNullOrEmpty(connName))
            {
                StartTimer();

                AlgoSmartLoaderObject obj = ModObject as AlgoSmartLoaderObject;
                // 2. 내부 객체 실행
                var result = obj.Run();
                // 3. 하위 모듈(그리드 뷰 기록)은 무조건 실행
                ReplyArgs = OutputPlay("Result", obj.AlgoRst, Enums.CmdRequest.Play, _args.Mode, Enums.CmdWait.No_Wait);

                if (!result)
                    return OccurError(obj.ErrorCode);

                StopTimer();
            }
            // 4. 완료 처리
            return End();
        }
        #endregion
    }
}
