﻿using Cognex.VisionPro;
using Cognex.VisionPro.Blob;
using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.CogDisplay;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoSmartLoader
{
    public enum WorkType
    {
        ALIGN,//2p center
        INSPECT,//??
        MEASURE,//??
    }

    sealed class Key
    {
        #region 상수 정의
        // plc data key
        public static string OFFSET_X = "Offset#1";
        public static string OFFSET_Y = "Offset#2";
        public static string OFFSET_T = "Offset#3";

        public static string CURRENT_X = "CurPos#1";
        public static string CURRENT_Y = "CurPos#2";
        public static string CURRENT_T = "CurPos#3";

        public static string SRC_ID = "SourceID";
        // input data key
        public static string OBJECT1 = "Object1";
        public static string OBJECT2 = "Object2";
        public static string TOOLRESULT = "ToolResult";

        // vision data key
        public static string REV_X = "Rev#1_X";
        public static string REV_Y = "Rev#1_Y";
        public static string REV_T = "Rev#1_T";

        public static string TAR_X = "Tar#1_Pos#1";
        public static string TAR_Y = "Tar#1_Pos#2";
        public static string TAR_T = "Tar#1_Pos#3";

        public static string JUDGE1 = "Judgement#1";
        public static string JUDGE2 = "Judgement#2";
        public static string JUDGE3 = "Judgement#3";
        public static string JUDGE4 = "Judgement#4";

        public static string RESULT1 = "Result#1";
        public static string RESULT2 = "Result#2";
        public static string RESULT3 = "Result#3";
        public static string RESULT4 = "Result#4";

        public static string SCORE1 = "Score1";
        public static string SCORE2 = "Score2";
        #endregion
    }

    [SerializableAttribute]
    public partial class AlgoSmartLoaderObject : AlgoObjectBase
    {


        #region 변수 & 속성

        string _display1Name;
        [Browsable(true)]
        [TypeConverter(typeof(CogDispListConverter))]
        public string Display1Name
        {
            get { return _display1Name; }
            set { Set<string>(ref _display1Name, value, nameof(Display1Name)); }
        }
        private CogDisplayObject Display1
        {
            get
            {
                return SystemObject_Display.GetObject(Display1Name) as CogDisplayObject;
            }
        }

        string _display2Name;
        [Browsable(true)]
        [TypeConverter(typeof(CogDispListConverter))]
        public string Display2Name
        {
            get { return _display2Name; }
            set { Set<string>(ref _display2Name, value, nameof(Display2Name)); }
        }
        private CogDisplayObject Display2
        {
            get
            {
                return SystemObject_Display.GetObject(Display2Name) as CogDisplayObject;
            }
        }

        string _calib1Name;
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Calib1Name
        {
            get { return _calib1Name; }
            set { Set<string>(ref _calib1Name, value, nameof(Calib1Name)); }
        }
        private CalDataObject Calib1
        {
            get
            {
                return SystemObject_Common.GetObject(Calib1Name) as CalDataObject;
            }
        }

        string _calib2Name;
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Calib2Name
        {
            get { return _calib2Name; }
            set { Set<string>(ref _calib2Name, value, nameof(Calib2Name)); }
        }
        private CalDataObject Calib2
        {
            get
            {
                return SystemObject_Common.GetObject(Calib2Name) as CalDataObject;
            }
        }

        WorkType _workType;
        public WorkType WorkType
        {
            get { return _workType; }
            set
            {
                if (Set<WorkType>(ref _workType, value, nameof(WorkType)))
                {
                    InitModelParams();
                }
            }
        }

        #endregion

        #region 생성자
        public AlgoSmartLoaderObject() : base()
        {
            InitModelParams();
        }

        private void InitModelParams()
        {
            ModelParams.Clear();
            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                {
                    switch (WorkType)
                    {
                        case WorkType.ALIGN:
                            ModelParams.Add(model, new AlgoAlignModelParams());
                            break;
                        case WorkType.MEASURE:
                            ModelParams.Add(model, new AlgoMeasureModelParams());
                            break;
                        case WorkType.INSPECT:
                            ModelParams.Add(model, new AlgoInspectModelParams());
                            break;
                        default:
                            break;
                    }
                }
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region 공용 함수
        public override bool Run()
        {
            // 1. PLC Data 읽어오기
            AssignPLCData();
            bool result = true;
            switch (WorkType)
            {
                case WorkType.ALIGN:
                    result = AlignCalc();
                    break;
                case WorkType.MEASURE:
                    result = MeasureCalc();
                    break;
                case WorkType.INSPECT:
                    result = InspectCalc();
                    break;
                default:
                    return false;
            }
            // write vision value to plc memory
            result &= CommodObject.SetVisionValues(VisionValues.Values.ToList());

            return result;
        }
        public override void AssignPLCData()
        {
            // plc data 읽어오기 : plc align table 전체
            UpdatePLCIOs();
            // 구조체에 할당하기 : 실제 알고리즘에 사용할 데이터
            CvtPLCIO = new StdPLCTable();
            // cell id
            CvtPLCIO.SourceID = System.Convert.ToString(PlcValues[Key.SRC_ID].CurValue);
            // align offset
            CvtPLCIO.Offset1 = System.Convert.ToDouble(PlcValues[Key.OFFSET_X].CurValue);
            CvtPLCIO.Offset2 = System.Convert.ToDouble(PlcValues[Key.OFFSET_Y].CurValue);
            CvtPLCIO.Offset3 = System.Convert.ToDouble(PlcValues[Key.OFFSET_T].CurValue);
            // current position
            CvtPLCIO.CurPos1 = System.Convert.ToDouble(PlcValues[Key.CURRENT_X].CurValue);
            CvtPLCIO.CurPos2 = System.Convert.ToDouble(PlcValues[Key.CURRENT_Y].CurValue);
            CvtPLCIO.CurPos3 = System.Convert.ToDouble(PlcValues[Key.CURRENT_T].CurValue);
        }

        #endregion

        #region 내부 함수
        private XYT GetCenterPoint(XY p1, XY p2)
        {
            return new XYT()
            {
                X = (p2.X + p1.X) / 2,
                Y = (p2.Y + p1.Y) / 2,
                T = GetTheta(p1, p2),
            };
        }

        private bool CheckLength(double length, double spec, double tolerence)
        {
            return spec - tolerence <= length && length <= spec + tolerence;
        }

        private bool CheckLimit(XYT rev, XYT limit)
        {
            return Math.Abs(rev.X) <= limit.X && Math.Abs(rev.Y) <= limit.Y && Math.Abs(rev.T) <= limit.T;
        }
        /// <summary>
        /// Set Revision Values
        /// </summary>
        private void SetVisionValues(AlgoResultBase result)
        {
            try
            {
                if (result is AlgoAlignResult align)
                {
                    // revision value
                    VisionValues[Key.REV_X].NextValue = align.RevX;
                    VisionValues[Key.REV_Y].NextValue = align.RevY;
                    VisionValues[Key.REV_T].NextValue = align.RevT;
                    // target value : current + rev
                    var tar = CvtPLCIO.CurPosXYT + new XYT(align.RevX, align.RevY, align.RevT);

                    VisionValues[Key.TAR_X].NextValue = tar.X;
                    VisionValues[Key.TAR_Y].NextValue = tar.Y;
                    VisionValues[Key.TAR_T].NextValue = tar.T;
                    // score
                    VisionValues[Key.SCORE1].NextValue = align.Score1;
                    VisionValues[Key.SCORE2].NextValue = align.Score2;
                }
                else if (result is AlgoMeasurementResult measure)
                {

                }
                else if (result is AlgoInspectResult insp)
                {

                }
            }
            catch (Exception ex)
            {
                SystemLogger.WriteExceptionLog(ex.ToString());
            }
        }

        private void DrawResult(AlgoResultBase algoRst, AlgoParams param, CogBlobResult left = null, CogBlobResult right = null)
        {
            if (algoRst is AlgoAlignResult align)
            {
               
            }
            else if (algoRst is AlgoMeasurementResult measure)
            {
                
            }
            else if (algoRst is AlgoInspectResult insp)
            {
               
            }
        }

        #endregion
    }



    public class AlgoAutoConnectingOutputParams : OutputParams
    {
        public object Result { get; set; }
    }
}
