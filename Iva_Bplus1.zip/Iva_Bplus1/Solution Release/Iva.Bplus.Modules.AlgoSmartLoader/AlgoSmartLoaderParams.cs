﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.CogDisplay;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoSmartLoader
{


    #region Converters
    internal class CalDataListConverter : TypeConverter
    {
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Common.GetEachObjectName(typeof(CalDataObject)));
        }
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }
    }

    public class CogDispListConverter : TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Display.GetEachObjectName(typeof(CogDisplayObject)));
        }
    }
    #endregion

}
