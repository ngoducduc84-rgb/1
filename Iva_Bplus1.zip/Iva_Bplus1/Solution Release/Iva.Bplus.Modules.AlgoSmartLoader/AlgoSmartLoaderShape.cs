﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoSmartLoader
{
    [SerializableAttribute]
    public class AlgoSmartLoaderShape : ModuleBase
    {
        #region 생성자
        /// <summary>
        /// 기본 생성자
        /// </summary>
        public AlgoSmartLoaderShape() : base()
        {
            // 기본 설정
            ShapeType = ShapeType.Algorithm;
            Geometry = SystemImage.TOOL_ALGORITHM_ICON;
        }
        /// <summary>
        /// 모듈 신규 생성할 때 호출되는 생성자 
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="name"></param>
        public AlgoSmartLoaderShape(SystemCanvasViewModel parent, string name) : base(parent, name)
        {
            // 기본 설정
            ShapeType = ShapeType.Algorithm;
            Geometry = SystemImage.TOOL_ALGORITHM_ICON;
            // 상위 모듈 생성
            InitItem(null, name, SettingShapeType.Algo);
            // 커넥터 설정
            SetConnectors();

            ModAction.ModObject.PropertyChanged += ModAction_PropertyChanged;
        }
        #endregion

        #region 공용 함수
        /// <summary>
        /// File에서 객체 불러온(Deserialize) 후 호출되는 함수
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="obj"></param>
        /// <param name="name"></param>
        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string name)
        {
            // 기본 설정
            ShapeType = ShapeType.Algorithm;
            Geometry = SystemImage.TOOL_ALGORITHM_ICON;
            // 캔버스 할당
            Parent = parent;
            // 상위 모듈 생성
            InitItem(obj, name, SettingShapeType.Algo);

            ModAction.ModObject.PropertyChanged += ModAction_PropertyChanged;
        }
        #endregion

        #region 내부 함수
        private void ModAction_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName != "WorkType") return;

            if (ModAction.ModObject is AlgoSmartLoaderObject obj)
            {
                base.DetachConections(base.InputConnectors);
                base.inputConnectors.Clear();

                switch (obj.WorkType)
                {
                    case WorkType.ALIGN:
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Object1", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Object2", typeof(IPointResult)));
                        break;
                    case WorkType.MEASURE:
                        break;
                    case WorkType.INSPECT:
                        break;
                    default:
                        break;
                }

                base.InputConnectors_ItemAdd(new ConnectorViewModel("Trigger", typeof(CalcTrigger)));
            }
        }
        #endregion
    }
}
