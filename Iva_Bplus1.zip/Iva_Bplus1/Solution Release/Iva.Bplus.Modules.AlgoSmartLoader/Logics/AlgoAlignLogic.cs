﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoSmartLoader
{
    public partial class AlgoSmartLoaderObject
    {
        #region local field for align

        #endregion

        private bool AlignCalc()
        {
            try
            {
                // 1. Model Param 가져오기
                var model = SystemModel.GetCurModel();
                if (!ModelParams.ContainsKey(model))
                {
                    ErrorCode = AlgoActionBase.Err_ModelData_Info_Missing;
                    return false;
                }

                // 2. Input Param 가져오기 : mark
                if (!InputValues.ContainsKey(Key.OBJECT1) || !InputValues.ContainsKey(Key.OBJECT2))
                {
                    ErrorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                // 3. 실제 좌표로 변환
                // 3-1. object
                var markObj1 = InputValues[Key.OBJECT1] as IPointResult;
                var markObj2 = InputValues[Key.OBJECT2] as IPointResult;

                /* 회전 중심 자동보정 기능 : 캘리브레이션 기준 좌표 생성 필요..
                var origin = Calib.GetStagePosition(model);
                var current = CvtPLCIO.CurPosXYT;
                var diff = current - origin;
                 */

                var rCenter1 = Calib1.GetRotateCenter(model);// + diff;
                var rCenter2 = Calib2.GetRotateCenter(model);// + diff;

                var robotObj1 = Calib1.GetV2R(model, markObj1.OutputXYT.ToXY());
                var robotObj2 = Calib2.GetV2R(model, markObj2.OutputXYT.ToXY());

                var coordObj1 = rCenter1 + robotObj1;
                var coordObj2 = rCenter2 + robotObj2;

                var centerObj = GetCenterPoint(coordObj1, coordObj2);


                // 3-2. target
                XY robotTar1 = Calib1.GetCameraPosition(model);
                XY robotTar2 = Calib2.GetCameraPosition(model);

                var centerTar = GetCenterPoint(robotTar1, robotTar2);

                // 4. Target 연산 : offset 반영
                var newTarget = ApplyTargetOffset(centerTar, CvtPLCIO.OffsetXYT);

                // 5. 보정값 연산
                var rad = NormalizeTheta(newTarget.T - centerObj.T);
                var dx = Math.Cos(rad) * centerObj.X - Math.Sin(rad) * centerObj.Y;
                var dy = Math.Sin(rad) * centerObj.X + Math.Cos(rad) * centerObj.Y;

                var rev = new XYT()
                {
                    X = newTarget.X - dx,
                    Y = newTarget.Y - dy,
                    T = RadianToDegree(rad),
                };

                // 6. 판정 : Length, Limit
                bool alignResult = true;
                var mparam = ModelParams[model] as AlgoAlignModelParams;

                // 6-1. check object length
                var objLength = GetLength(robotObj1, robotObj2);
                // object length
                if (alignResult && !CheckLength(objLength, (double)mparam.ObjectLength.Value, (double)mparam.LCheckTolerance.Value))
                {
                    ErrorCode = AlgoActionBase.Err_Length_Check;
                    Display1.Judgement = (uint)Judgement.L_Check;
                    Display2.Judgement = (uint)Judgement.L_Check;
                    alignResult = false;
                }

                // 6-2. check limit
                XYT limit = new XYT((double)mparam.LimitX.Value, (double)mparam.LimitY.Value, (double)mparam.LimitT.Value);
                if (alignResult && !CheckLimit(rev, limit))
                {
                    ErrorCode = AlgoActionBase.Err_Limit_Over;
                    Display1.Judgement = (uint)Judgement.NG;
                    Display2.Judgement = (uint)Judgement.NG;
                    alignResult = false;
                }
                // 7. 보정값 처리
                var now = DateTime.Now;
                AlgoRst = new AlgoAlignResult()
                {
                    Name = this.Name,
                    ID = this.SourceID,
                    CurDate = now.ToString("yyyy-MM-dd"),
                    CurTime = now.ToString("HH:mm:ss"),

                    Result = alignResult ? "OK" : $"NG - {SystemInfo.GetErrorInfo(ErrorCode).Title}",

                    RevX = Math.Round(rev.X, 3),
                    RevY = Math.Round(rev.Y, 3),
                    RevT = Math.Round(rev.T, 3),

                    Score1 = (markObj1 == null) ? 100.0 : Math.Round(markObj1.Score, 1),
                    Score2 = (markObj2 == null) ? 100.0 : Math.Round(markObj2.Score, 1),

                    Length = Math.Round(objLength, 3),

                    X1 = Math.Round(robotObj1.X, 3),
                    Y1 = Math.Round(robotObj1.Y, 3),
                    X2 = Math.Round(robotObj2.X, 3),
                    Y2 = Math.Round(robotObj2.Y, 3),
                };

                SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

                // 8. PLC Data 쓰기
                SetVisionValues(AlgoRst);

                // 9. 마무리 작업 : 결과값 화면(display) 표시
                Task.Factory.StartNew(() => { DrawResult(AlgoRst, mparam); });

                return alignResult;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }
    }

    #region Parameters
    [SerializableAttribute]
    public class AlgoAlignModelParams : AlgoParams
    {
        #region Limit
        private AlgoParam limitX = new AlgoParam(nameof(LimitX), "mm", typeof(double), 1.0, "Revision X Limit", 0.0, 10.0);
        public AlgoParam LimitX
        {
            get { return limitX; }
            set { Set<AlgoParam>(ref limitX, value, nameof(LimitX)); }
        }

        private AlgoParam limitY = new AlgoParam(nameof(LimitY), "mm", typeof(double), 1.0, "Revision Y Limit", 0.0, 10.0);
        public AlgoParam LimitY
        {
            get { return limitY; }
            set { Set<AlgoParam>(ref limitY, value, nameof(LimitY)); }
        }

        private AlgoParam limitT = new AlgoParam(nameof(LimitT), "mm", typeof(double), 1.0, "Revision T Limit", 0.0, 10.0);
        public AlgoParam LimitT
        {
            get { return limitT; }
            set { Set<AlgoParam>(ref limitT, value, nameof(LimitT)); }
        }
        #endregion

        #region L-Check Tolerence
        private AlgoParam _tarLength = new AlgoParam(nameof(TargetLength), "mm", typeof(double), 80.0, "Target Length Spec", 0.1, 1000.0);
        public AlgoParam TargetLength
        {
            get { return _tarLength; }
            set { Set<AlgoParam>(ref _tarLength, value, nameof(TargetLength)); }
        }

        private AlgoParam _objLength = new AlgoParam(nameof(ObjectLength), "mm", typeof(double), 80.0, "Object Length", 0.1, 1000.0);
        public AlgoParam ObjectLength
        {
            get { return _objLength; }
            set { Set<AlgoParam>(ref _objLength, value, nameof(ObjectLength)); }
        }

        private AlgoParam _lCheckTolerance = new AlgoParam(nameof(LCheckTolerance), "mm", typeof(double), 0.05, "L-Check Tolerence", 0.0, 1.0);
        public AlgoParam LCheckTolerance
        {
            get { return _lCheckTolerance; }
            set { Set<AlgoParam>(ref _lCheckTolerance, value, nameof(LCheckTolerance)); }
        }
        #endregion
    }

    public class AlgoAlignInputParams : InputParams
    {
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    
    public class AlgoAlignResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion

        public string Result { get; set; }// ok, ng - reason

        #region ToolResult
        public double Score1 { get; set; }// matching score 1
        public double Score2 { get; set; }// matching score 2
        #endregion

        #region Revision Value
        public double RevX { get; set; }// revision x
        public double RevY { get; set; }// revision y
        public double RevT { get; set; }// revision t

        public double Length { get; set; }// object length
        #endregion
        
        #region Object Positions
        public double X1 { get; set; }//object1 X
        public double Y1 { get; set; }//object1 Y
        public double X2 { get; set; }//object1 X
        public double Y2 { get; set; }//object1 Y
        #endregion
    }
    #endregion
}
