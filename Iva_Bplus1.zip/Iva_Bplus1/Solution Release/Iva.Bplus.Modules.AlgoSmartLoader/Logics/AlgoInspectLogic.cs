﻿using Cognex.VisionPro.Blob;
using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoSmartLoader
{
    public partial class AlgoSmartLoaderObject
    {
        #region local field for align
        readonly string MATCH_SCORE = "MatchScore";
        readonly string LEFT_RESULT = "LeftResult";
        readonly string RIGHT_RESULT = "RightResult";
        #endregion

        private bool InspectCalc()
        {
            try
            {
                // 미정의

                return true;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }
    }

    #region Parameters
    [SerializableAttribute]
    public class AlgoInspectModelParams : AlgoParams
    {
        private AlgoParam _leftTolerance = new AlgoParam(nameof(LeftTolerance), "pxl", typeof(int), 3000, "Left Area Tolerance", 0, 50000);
        public AlgoParam LeftTolerance
        {
            get { return _leftTolerance; }
            set { Set<AlgoParam>(ref _leftTolerance, value, nameof(LeftTolerance)); }
        }

        private AlgoParam _rightTolerance = new AlgoParam(nameof(RightTolerance), "pxl", typeof(int), 3000, "Left Area Tolerance", 0, 50000);
        public AlgoParam RightTolerance
        {
            get { return _rightTolerance; }
            set { Set<AlgoParam>(ref _rightTolerance, value, nameof(RightTolerance)); }
        }
    }

    public class AlgoInspectInputParams : InputParams
    {
        public object ToolResult { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoInspectResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion
        public string Result { get; set; }// Open, Close

        #region ToolResult
        public double MatchScore { get; set; }// matching score
        public int LeftArea { get; set; }// blob count in left area
        public int RightArea { get; set; }// blob count in right area
        #endregion
    }
    #endregion
}
