﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoSmartLoader
{
    public partial class AlgoSmartLoaderObject
    {
        #region local field for measure

        #endregion

        private bool MeasureCalc()
        {
            try
            {
                // 미정의

                return true;
            }
            catch
            {
                ErrorCode = AlgoActionBase.Err_Exception_Module;
                return false;
            }
        }
    }

    #region Parameters
    [SerializableAttribute]
    public class AlgoMeasureModelParams : AlgoParams
    {
        #region L-Check
        private AlgoParam _tarLength = new AlgoParam(nameof(TargetLength), "mm", typeof(double), 80.0, "Target Length Spec", 0.1, 1000.0);
        public AlgoParam TargetLength
        {
            get { return _tarLength; }
            set { Set<AlgoParam>(ref _tarLength, value, nameof(TargetLength)); }
        }

        private AlgoParam _objLength = new AlgoParam(nameof(ObjectLength), "mm", typeof(double), 80.0, "Object Length", 0.1, 1000.0);
        public AlgoParam ObjectLength
        {
            get { return _objLength; }
            set { Set<AlgoParam>(ref _objLength, value, nameof(ObjectLength)); }
        }

        private AlgoParam _lCheckTolerance = new AlgoParam(nameof(LCheckTolerance), "mm", typeof(double), 0.05, "L-Check Tolerence", 0.0, 1.0);
        public AlgoParam LCheckTolerance
        {
            get { return _lCheckTolerance; }
            set { Set<AlgoParam>(ref _lCheckTolerance, value, nameof(LCheckTolerance)); }
        }
        #endregion

        #region Angle
        private AlgoParam _angleTolerance = new AlgoParam(nameof(AngleTolerance), "deg", typeof(double), 1.0, "Angle Tolerence", 0.0, 5.0);
        public AlgoParam AngleTolerance
        {
            get { return _angleTolerance; }
            set { Set<AlgoParam>(ref _angleTolerance, value, nameof(AngleTolerance)); }
        }
        #endregion
    }

    public class AlgoMeasureInputParams : InputParams
    {
        public IPointResult Target1 { get; set; }
        public IPointResult Target2 { get; set; }
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public CalcTrigger Trigger { get; set; }
    }
    public class AlgoMeasurementResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion
        public string Result { get; set; }// ok, ng - reason

        #region ToolResult
        public double ScoreT1 { get; set; }// target1 matching score
        public double ScoreT2 { get; set; }// target2 matching score
        public double ScoreO1 { get; set; }// object1 matching score
        public double ScoreO2 { get; set; }// object2 matching score
        #endregion

        #region Measurement
        public double TarLen { get; set; }
        public double TarAngle { get; set; }
        public double ObjLen { get; set; }
        public double ObjAngle { get; set; }
        public double Distance { get; set; }
        #endregion
    }
    #endregion
}
