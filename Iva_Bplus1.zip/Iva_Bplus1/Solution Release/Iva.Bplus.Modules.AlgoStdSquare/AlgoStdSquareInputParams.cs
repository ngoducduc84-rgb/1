﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using System;

namespace Iva.Bplus.Modules.AlgoStdSquare
{
    [SerializableAttribute]
    class AlgoStdSquareInputParams : InputParams
    {
        #region Input 4 point
        public IPointResult Top_Left { get; set; }
        public IPointResult Top_Right { get; set; }
        public IPointResult Bottom_Left { get; set; }
        public IPointResult Bottom_Right { get; set; }
        #endregion

        #region Trigers
        public CalcTrigger Trigger { get; set; }
        #endregion
    }
}
