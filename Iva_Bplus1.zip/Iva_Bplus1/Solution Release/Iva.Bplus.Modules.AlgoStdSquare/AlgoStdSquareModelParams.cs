﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.AlgoStdSquare
{
    [SerializableAttribute]

    public partial class AlgoStdSquareModelParams : AlgoParams
    {
        private AlgoParam scaleX;
        private AlgoParam scaleY;
        //private AlgoParam limitT;
        //private AlgoParam spec_Length;
        //private AlgoParam tor_Length;
        //private AlgoParam scale_Length;
        public AlgoParam ScaleX { get { return scaleX; } set { if (scaleX == value) return; scaleX = value; this.OnPropertyChanged(nameof(ScaleX)); } }
        public AlgoParam ScaleY { get { return scaleY; } set { if (scaleY == value) return; scaleY = value; this.OnPropertyChanged(nameof(ScaleY)); } }
        //public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        //public AlgoParam Spec_Length { get { return spec_Length; } set { if (spec_Length == value) return; spec_Length = value; this.OnPropertyChanged(nameof(Spec_Length)); } }
        //public AlgoParam Tor_Length { get { return tor_Length; } set { if (tor_Length == value) return; tor_Length = value; this.OnPropertyChanged(nameof(Tor_Length)); } }
        //public AlgoParam Scale_Length { get { return scale_Length; } set { if (scale_Length == value) return; scale_Length = value; this.OnPropertyChanged(nameof(Scale_Length)); } }


        public AlgoStdSquareModelParams()
            : base()
        {
            ScaleX = new AlgoParam("ScaleX", "mm", typeof(double), 1.0, "Length Scale X", (double)-0.5, (double)3);
            ScaleY = new AlgoParam("ScaleY", "mm", typeof(double), 1.0, "Length Scale Y", (double)-0.5, (double)3);
            //LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);
            //Spec_Length = new AlgoParam("Spec_Length", "mm", typeof(double), 0.0, "Length Spec(Mark To Mark)", (double)0, (double)100);
            //Tor_Length = new AlgoParam("Tor_Length", "mm", typeof(double), 0.0, "Length Tolerance", (double)0, (double)1);
            //Scale_Length = new AlgoParam("Scale_Length", "mm", typeof(double), 0.0, "Length Scale", (double)0.5, (double)3);
        }
    }
}
