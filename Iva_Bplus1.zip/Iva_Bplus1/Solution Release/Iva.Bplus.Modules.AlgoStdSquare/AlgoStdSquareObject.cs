﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro.Display;
using System.Drawing;
using Cognex.VisionPro;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.AlgoStdSquare
{
    [SerializableAttribute]
    public partial class AlgoStdSquareObject : AlgoObjectBase
    {
        #region [Fields]
        #region  Selected Caldata Name
        private string p1_CalData;
        private string p2_CalData;
        private string p1_Display;
        private string p2_Display;
        #endregion

        #region etc
        private CalcType calcType;
        private ThetaDirection thetaDirection;
        private AlignMotionType alignMotionType = AlignMotionType.XYT;
        #endregion

        #region Align관련 Data
        private XYT revAlign = new XYT();
        private XYT revUnload = new XYT();
        private double length = 0.0;
        private bool lastJudgement = true;
        #endregion
        public string schName = "";
        #endregion

        #region [properties]
        #region  Selected Caldata Name
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P1_CalData
        {
            get { return p1_CalData; }
            set { if (p1_CalData == value) return; p1_CalData = value; this.OnPropertyChanged(nameof(P1_CalData)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P2_CalData
        {
            get { return p2_CalData; }
            set { if (p2_CalData == value) return; p2_CalData = value; this.OnPropertyChanged(nameof(P2_CalData)); }
        }

        public CalDataObject P1_CalDataObj
        {
            get { return SystemObject_Common.GetObject(p1_CalData) as CalDataObject; }
        }

        public CalDataObject P2_CalDataObj
        {
            get { return SystemObject_Common.GetObject(p2_CalData) as CalDataObject; }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return p1_Display; }
            set { if (p1_Display == value) return; p1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }

        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P2_Display
        {
            get { return p2_Display; }
            set { if (p2_Display == value) return; p2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
        }
        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p1_Display) as CogDisplayObject; }
        }
        public CogDisplayObject P2_DisplayObj
        {
            get { return SystemObject_Display.GetObject(p2_Display) as CogDisplayObject; }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return calcType; }
            set { if (calcType == value) return; calcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }

        public ThetaDirection ThetaDirection
        {
            get { return thetaDirection; }
            set { if (thetaDirection == value) return; thetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return alignMotionType; }
            set { if (alignMotionType == value) return; alignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }


        public ObservableCollection<string> CalDataList
        {
            get
            {

                SystemObject_Common.GetEachObjectName(typeof(CalDataObject));
                return null;
            }
            set
            {
                this.OnPropertyChanged(nameof(CalDataList));

            }

        }
        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return revAlign; } }
        public XYT RevUnload { get { return revUnload; } }
        public double Length { get { return length; } }
        public bool LastJudgement { get { return lastJudgement; } }
        #endregion
        #endregion

        #region[Construct]
        public AlgoStdSquareObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            //CommObj = lst.Count != 0 ? lst[0] : "";

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new AlgoStdSquareModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }
        #endregion

        #region [Private Method]
        private bool AlignCalc()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudgement = true;

            #region PLC IOs Update
            //AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Mark Data Read& Confirm
            // P/G 최초실행시 입력이 한번이라도 들어와야지 Dictionary가 생성이 된다.
            if (!InputValues.ContainsKey("Top_Left") || !InputValues.ContainsKey("Top_Right") || !InputValues.ContainsKey("Bottom_Left") || !InputValues.ContainsKey("Bottom_Right"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            LineCrossRstData Top_Left = InputValues["Top_Left"] as LineCrossRstData;
            LineCrossRstData Top_Right = InputValues["Top_Right"] as LineCrossRstData;
            LineCrossRstData Bottom_Left = InputValues["Bottom_Left"] as LineCrossRstData;
            LineCrossRstData Bottom_Right = InputValues["Bottom_Right"] as LineCrossRstData;
            if (Top_Left == null || Top_Right == null || Bottom_Left == null || Bottom_Right == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                // Calibration 설정 안됨.
                return false;
            }
            XY Robot_TL = P1_CalDataObj.GetV2R(model, new XY(Top_Left.OutputXYT.X, Top_Left.OutputXYT.Y));
            XY Robot_TR = P1_CalDataObj.GetV2R(model, new XY(Top_Right.OutputXYT.X, Top_Right.OutputXYT.Y));
            XY Robot_BL = P1_CalDataObj.GetV2R(model, new XY(Bottom_Left.OutputXYT.X, Bottom_Left.OutputXYT.Y));

            //XY Coord_TL = Robot_TL + P1_CalDataObj.GetRotateCenter(model);
            //XY Coord_TR = Robot_TR + P1_CalDataObj.GetRotateCenter(model);
            //XY Coord_BL = Robot_BL + P1_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as AlgoStdSquareModelParams;
            double scaleX = (double)mParams.ScaleX.Value;
            double scaleY = (double)mParams.ScaleY.Value;
            #endregion

            #region Calc Rev Offset
            double Length_H = GetLength(Robot_TL, Robot_TR) * scaleX;
            double Length_V = GetLength(Robot_TL, Robot_BL) * scaleY;
            DrawLineLabel(Top_Left, Top_Right, Bottom_Left, Length_H, Length_V);
            #endregion

            #region Confirm Result (Align Spec Over Check)
            //if (!ConfirmResult(revAlign, Limit))
            //{
            //    P1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            //    P2_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
            //    lastJudgement = false;
            //}
            #endregion

            #region Calc Length & Confirm (Length Check)
            //length = GetLength(Coord_P1, Coord_P2);
            //if (tor_Length != 0)
            //{
            //    if (Math.Abs(spec_Length - length) > tor_Length)
            //    {
            //        lastJudgement = false;
            //        errorCode = AlgoActionBase.Err_Length_Check;
            //        P1_DisplayObj.Judgement = (uint)Judgement.L_Check;
            //        P2_DisplayObj.Judgement = (uint)Judgement.L_Check;
            //    }
            //}
            #endregion

            #region Inspection Result Image Save (L_Check)
            //if (P1_DisplayObj.Judgement != (uint)Judgement.OK && P1_DisplayObj.Judgement != (uint)Judgement.None)
            //{
            //string _sourceID = DeepClone(sourceID);
            DateTime dateTime = DateTime.Now;
            //    string _judgement = "";

            //    foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
            //    {
            //        if (P1_DisplayObj.Judgement == (uint)j)
            //        {
            //            _judgement = j.ToString();
            //            break;
            //        }
            //    }

            object obj = (Bitmap)P1_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
            P1_DisplayObj.SaveImage(dateTime, obj, "OK", schName, "Square", true);
            //    object obj2 = (Bitmap)P2_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
            //    P2_DisplayObj.SaveImage(dateTime, obj2, _judgement, schName, _sourceID, true);

            //object obj3 = P1_DisplayObj.GetCurImage();
            //P1_DisplayObj.SaveImage(dateTime, obj3, "OK", schName, _sourceID, false);
            //    object obj4 = P2_DisplayObj.GetCurImage();
            //    P2_DisplayObj.SaveImage(dateTime, obj4, _judgement, schName, _sourceID, false);
            //}
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new AlgoStdSquareResult
            {
                Name = name,
                ID = sourceID,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Length_H = Math.Round(Length_H, 3),
                Length_V = Math.Round(Length_V, 3),

                P1_X = Math.Round(Top_Left.OutputXYT.X, 3),  //Mark Pixel 좌표
                P1_Y = Math.Round(Top_Left.OutputXYT.Y, 3),
                P2_X = Math.Round(Top_Right.OutputXYT.X, 3),
                P2_Y = Math.Round(Top_Right.OutputXYT.Y, 3),
                P3_X = Math.Round(Bottom_Left.OutputXYT.X, 3),
                P3_Y = Math.Round(Bottom_Left.OutputXYT.Y, 3),
            };
            #endregion
            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            //#endregion

            #region Vision Write (Result & FDC)
            //WriteVisionIO(revAlign, revUnload, "");
            #endregion
            return lastJudgement;
        }

        protected void DrawLineLabel(Interface.IPointResult _top_Left, Interface.IPointResult _Top_Right, Interface.IPointResult _Bottom_Left, double _LengthH, double _LengthV)
        {
            //string _sourceID = DeepClone(sourceID);
            //DateTime dateTime = DateTime.Now;

            #region Draw Results
            // Draw Overlay (Maker) // 걍..크로스포인트
            CogDrawMarkerInfo makerInfo_L = new CogDrawMarkerInfo();
            makerInfo_L.Color = CogColorConstants.Red;
            makerInfo_L.Offset = _top_Left.OutputXYT;
            P1_DisplayObj.DrawMaker(makerInfo_L);
            CogDrawMarkerInfo makerInfo_R = new CogDrawMarkerInfo();
            makerInfo_R.Color = CogColorConstants.Red;
            makerInfo_R.Offset = _Top_Right.OutputXYT;
            P1_DisplayObj.DrawMaker(makerInfo_R);
            CogDrawMarkerInfo makerInfo_B = new CogDrawMarkerInfo();
            makerInfo_B.Color = CogColorConstants.Red;
            makerInfo_B.Offset = _Bottom_Left.OutputXYT;
            P1_DisplayObj.DrawMaker(makerInfo_B);

            // Draw Overlay (Line)
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = CogColorConstants.Red;
            lineInfo.Start = new XY(_top_Left.OutputXYT.X, _top_Left.OutputXYT.Y);
            lineInfo.End = new XY(_Top_Right.OutputXYT.X, _Top_Right.OutputXYT.Y);
            P1_DisplayObj.DrawLine(lineInfo);
            lineInfo.Start = new XY(_top_Left.OutputXYT.X, _top_Left.OutputXYT.Y);
            lineInfo.End = new XY(_Bottom_Left.OutputXYT.X, _Bottom_Left.OutputXYT.Y);
            P1_DisplayObj.DrawLine(lineInfo);

            // Draw Overlay (Label)
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = new XY((_top_Left.OutputXYT.X + _Top_Right.OutputXYT.X) / 2, (_top_Left.OutputXYT.Y + _Top_Right.OutputXYT.Y) / 2);
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", _LengthH);
            P1_DisplayObj.DrawLabel(labelInfo);
            labelInfo.Offset = new XY((_top_Left.OutputXYT.X + _Bottom_Left.OutputXYT.X) / 2, (_top_Left.OutputXYT.Y + _Bottom_Left.OutputXYT.Y) / 2);
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BaselineCenter;
            labelInfo.Text = string.Format("{0:f2}mm", _LengthV);
            P1_DisplayObj.DrawLabel(labelInfo);
            #endregion

            //string _judgement = "";
            //foreach (Judgement j in Enum.GetValues(typeof(Judgement)))
            //{
            //    if (P1_DisplayObj.Judgement == (uint)j)
            //    {
            //        _judgement = j.ToString();
            //        break;
            //    }
            //}

            //object obj = (Bitmap)P1_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
            //P1_DisplayObj.SaveImage(dateTime, obj, _judgement, schName, _sourceID, true);

            //if (P1_DisplayObj.Judgement != (uint)Judgement.InspOK && P1_DisplayObj.Judgement != (uint)Judgement.None)
            //{
            //    object obj1 = P1_DisplayObj.GetCurImage();
            //    P1_DisplayObj.SaveImage(dateTime, obj1, _judgement, schName, _sourceID, false);
            //}
        }
        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }
            else
                return true;
        }
        public void WriteVisionIO(object rev1, object rev2, string ID)
        {

            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (alignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                    VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                    VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                    VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                    VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                    VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                    VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    break;

            }

            // 아이디 확인.
            //VisionValues["ImageID"].NextValue = (string)ID; IOs.Add(VisionValues["ImageID"]);

            CommodObject.SetVisionValues(IOs);
        }
        #endregion

        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            //if (cogDisp == null) return;
            //Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }
    }
}

