﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.AlgoStdSquare
{
    [SerializableAttribute]
    public class AlgoStdSquareResult : AlgoResultBase
    {
        #region [fiedls]        
        private double length_H;
        private double length_V;

        private double p1_X;
        private double p1_Y;
        private double p2_X;
        private double p2_Y;
        private double p3_X;
        private double p3_Y;

        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;
        private double c3_X;
        private double c3_Y;

        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public double Length_H
        {
            get { return length_H; }
            set { if (value == length_H) return; length_H = value; OnPropertyChanged(nameof(Length_H)); }
        }
        public double Length_V
        {
            get { return length_V; }
            set { if (value == length_V) return; length_V = value; OnPropertyChanged(nameof(Length_V)); }
        }
        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }
        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }
        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }
        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }
        public double P3_X
        {
            get { return p3_X; }
            set { if (value == p3_X) return; p3_X = value; OnPropertyChanged(nameof(P3_X)); }
        }
        public double P3_Y
        {
            get { return p3_Y; }
            set { if (value == p3_Y) return; p3_Y = value; OnPropertyChanged(nameof(P3_Y)); }
        }
        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }
        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }
        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }
        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }
        public double C3_X
        {
            get { return c3_X; }
            set { if (value == c3_X) return; c3_X = value; OnPropertyChanged(nameof(C3_X)); }
        }
        public double C3_Y
        {
            get { return c3_Y; }
            set { if (value == c3_Y) return; c3_Y = value; OnPropertyChanged(nameof(C3_Y)); }
        }
        #endregion


        public AlgoStdSquareResult() : base() { }

        public override string ToString()
        {
            return string.Format("");
        }

    }
}
