﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;

namespace Iva.Bplus.Modules.AlgoTemplete
{
    [SerializableAttribute]
    public class AlgoTempleteAction : AlgoActionBase
    {
        #region 생성자
        public AlgoTempleteAction(ShapeBase _parent, string _name, string _source, AlgoObjectBase _object)
           : base(_parent, _name, _source, _object)
        {
            // 파라메타 할당
            InputParams = new AlgoTempleteInputParams();
            OutputParams = new AlgoTempleteOutputParams();
            // 모델 파라메타 타입 지정
            _object.ModelParamType = typeof(AlgoTempleteModelParams);
            var cur = _object.CurParams;
            // 세팅 뷰 생성
            ChildSettingView = new AlgoTempleteSetting();
            ChildSettingView.DataContext = this;
        }
        #endregion

        #region 공용 함수
        public override List<CommandReplyArgs> Play(ModuleActionBase _act, CmdReqArgs _args)
        {
            // 1. 커넥터 이름 가져오기
            string connName = Start(_act, _args, false);

            if (connName.Equals("Trigger") || string.IsNullOrEmpty(connName))
            {
                StartTimer();
                
                AlgoTempleteObject obj = ModObject as AlgoTempleteObject;
                // 2. 내부 객체 실행
                var rst = obj.Run();// 
                // 3. 하위 모듈 실행
                ReplyArgs = OutputPlay("Result", obj.AlgoRst, Enums.CmdRequest.Play, _args.Mode, Enums.CmdWait.No_Wait);
                // 4. Error 처리
                if(!rst)
                    return OccurError(obj.ErrorCode);

                StopTimer();
            }
            // 5. 완료 처리
            return End();
        }
        #endregion
        public DelegateCommand ScaleResetCmd
        {
            get
            {
                return new DelegateCommand(a =>
                {
                    var obj = ModObject as AlgoTempleteObject;
                    var mparam = obj.TempParams as AlgoTempleteModelParams;
                    // 측정값에서 scale factor 제거
                    obj.TargetLength /= System.Convert.ToDouble(mparam.ScaleFactor.Value);
                    // scale factor 초기화 : 1.0
                    mparam.ScaleFactor.Value = 1.0;
                    // 업데이트 : 화면 갱신이지..
                    obj.UpdateTempValues();
                });
            }
        }
        public DelegateCommand ScaleCalcCmd
        {
            get
            {
                return new DelegateCommand(a =>
                {
                    var obj = ModObject as AlgoTempleteObject;
                    var mparam = obj.TempParams as AlgoTempleteModelParams;
                    // 측정값에서 scale factor 제거
                    obj.TargetLength /= System.Convert.ToDouble(mparam.ScaleFactor.Value);
                    // scale factor 연산하기
                    mparam.ScaleFactor.Value = Math.Round( obj.MeasureLength / obj.TargetLength, 4);
                    // scale factor 적용하기
                    obj.TargetLength *= System.Convert.ToDouble(mparam.ScaleFactor.Value);
                    // 업데이트 : 화면 갱신이지..
                    obj.UpdateTempValues();
                });
            }
        }
        #region 내부 함수

        #endregion
    }
}
