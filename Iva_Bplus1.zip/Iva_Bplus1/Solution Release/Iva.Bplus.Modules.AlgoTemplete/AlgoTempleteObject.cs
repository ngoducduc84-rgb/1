﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoTemplete
{
    [SerializableAttribute]
    public class AlgoTempleteObject : AlgoObjectBase
    {
        #region 상수 정의
        // plc data key
        readonly string SRC_ID = "Source_ID";
        readonly string OFFSET_X = "Offset_X_X1";
        readonly string OFFSET_Y = "Offset_Y_X2";
        readonly string OFFSET_T = "Offset_T_Y1";
        readonly string CURRENT_X = "Cur_Position_X1_U_X";
        readonly string CURRENT_Y = "Cur_Position_X2_V_Y";
        readonly string CURRENT_T = "Cur_Position_Y1_W_T";
        // input data key
        readonly string OBJECT1 = "Object1";
        readonly string OBJECT2 = "Object2";
        readonly string TARGET1 = "Target1";
        readonly string TARGET2 = "Target2";
        // vision data key
        readonly string REV_X = "Rev_X";
        readonly string REV_Y = "Rev_Y";
        readonly string REV_T = "Rev_T";
        readonly string TAR_X = "Tar_Position_X1_U_X";
        readonly string TAR_Y = "Tar_Position_X2_V_Y";
        readonly string TAR_T = "Tar_Position_Y1_W_T";
        #endregion

        #region 변수 & 속성
        string _calib1Name;
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Calib1Name
        {
            get { return _calib1Name; }
            set { Set<string>(ref _calib1Name, value, nameof(Calib1Name)); }
        }
        private CalDataObject Calib1
        {
            get
            {
                return SystemObject_Common.GetObject(Calib1Name) as CalDataObject;
            }
        }

        string _calib2Name;
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string Calib2Name
        {
            get { return _calib2Name; }
            set { Set<string>(ref _calib2Name, value, nameof(Calib2Name)); }
        }
        private CalDataObject Calib2
        {
            get
            {
                return SystemObject_Common.GetObject(Calib2Name) as CalDataObject;
            }
        }
        [NonSerialized]
        double measureLength;
        public double MeasureLength//for calc scale
        {
            get { return measureLength; }
            set { Set<double>(ref measureLength, value, nameof(MeasureLength)); }
        }
        [NonSerialized]
        double targetLength;
        public double TargetLength//for calc scale
        {
            get { return targetLength; }
            set { Set<double>(ref targetLength, value, nameof(TargetLength), nameof(LCheck)); }
        }
        public bool LCheck//for calc scale
        {
            get
            {
                var mparam = TempParams as AlgoTempleteModelParams;
                return CheckTargetLength(mparam, TargetLength);
            }
        }
        public double ObjectLength { get; set; }//not use
        #endregion

        #region 생성자
        public AlgoTempleteObject() : base()
        {
            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new AlgoTempleteModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region 공용 함수
        public override bool Run()
        {
            // 1. PLC Data 읽어오기
            AssignPLCData();

            // 2. Model Param 가져오기
            var model = SystemModel.GetCurModel();
            if (!ModelParams.ContainsKey(model))
            {
                ErrorCode = AlgoActionBase.Err_ModelData_Info_Missing;
                return false;
            }

            // 3. Input Param 가져오기 : mark
            if (!InputValues.ContainsKey(TARGET1) || !InputValues.ContainsKey(TARGET2) || 
                !InputValues.ContainsKey(OBJECT1) || !InputValues.ContainsKey(OBJECT2))
            {
                ErrorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            var markTar1 = InputValues[TARGET1] as IPointResult;
            var markTar2 = InputValues[TARGET2] as IPointResult;
            var markObj1 = InputValues[OBJECT1] as IPointResult;
            var markObj2 = InputValues[OBJECT2] as IPointResult;

            // 4. 실제 좌표로 변환
            var rCenter1 = Calib1.GetRotateCenter(model);
            var rCenter2 = Calib2.GetRotateCenter(model);

            var robotTar1 = Calib1.GetV2R(model, markTar1.OutputXYT.ToXY());
            var robotTar2 = Calib2.GetV2R(model, markTar2.OutputXYT.ToXY());
            var robotObj1 = Calib1.GetV2R(model, markObj1.OutputXYT.ToXY());
            var robotObj2 = Calib2.GetV2R(model, markObj2.OutputXYT.ToXY());

            var coordTar1 = rCenter1 + robotTar1;
            var coordTar2 = rCenter2 + robotTar2;
            var coordObj1 = rCenter1 + robotObj1;
            var coordObj2 = rCenter2 + robotObj2;

            // 5. Target 연산
            var centerTarget = ApplyTargetOffset(coordTar1, coordTar2, CvtPLCIO.OffsetXYT);
            var centerObject = GetCenterPoint(coordObj1, coordObj2);

            // 6. 보정값 연산
            var rad = NormalizeTheta(centerTarget.T - centerObject.T);
            var dx = Math.Cos(rad) * centerObject.X - Math.Sin(rad) * centerObject.Y;
            var dy = Math.Sin(rad) * centerObject.X + Math.Cos(rad) * centerObject.Y;

            var rev = new XYT()
            {
                X = centerTarget.X - dx,
                Y = centerTarget.Y - dy,
                T = RadianToDegree(rad),
            };
            
            // 7. 보정값 판정 : Length, Limit, Retry
            bool algoResult = true;
            var mparam = ModelParams[model] as AlgoTempleteModelParams;
            var scale = System.Convert.ToDouble(mparam.ScaleFactor.Value);
            // check target length
            TargetLength = MeasureLength = GetLength(coordTar1, coordTar2) * scale;
            if (algoResult && !CheckTargetLength(mparam, TargetLength))
            {
                ErrorCode = AlgoActionBase.Err_Length_Check;
                algoResult = false;
            }
            // check object length
            ObjectLength = GetLength(coordObj1, coordObj2) * scale;
            if (algoResult && !CheckObjectLength(mparam, ObjectLength))
            {
                ErrorCode = AlgoActionBase.Err_Length_Check;
                algoResult = false;
            }
            // check limit
            if (algoResult && !CheckLimit(mparam, rev))
            {
                ErrorCode = AlgoActionBase.Err_Limit_Over;
                algoResult = false;
            }
            // check retry
            if (algoResult && !CheckRetry(mparam, rev))
            {
                ErrorCode = AlgoActionBase.Err_Retry_Spec_Over;
                algoResult = false;
            }
            // 8. 보정값 처리
            var now = DateTime.Now;
            AlgoRst = new AlgoTempleteResult()
            {
                Name = this.Name,
                ID = this.SourceID,
                CurDate = now.ToString("yyyy-MM-dd"),
                CurTime = now.ToString("HH:mm:ss"),

                RevX = rev.X,
                RevY = rev.Y,
                RevT = rev.T,

                TarLength = TargetLength,
                ObjLength = ObjectLength,

                Tar1X = coordTar1.X,
                Tar1Y = coordTar1.Y,
                Tar2X = coordTar2.X,
                Tar2Y = coordTar2.Y,

                Obj1X = coordObj1.X,
                Obj1Y = coordObj1.Y,
                Obj2X = coordObj2.X,
                Obj2Y = coordObj2.Y,
            };

            SystemLogger.WriteAlignDBLog(this.Name, AlgoRst);

            // 9. PLC Data 쓰기
            algoResult &= WritePLCData(rev);

            // 10. 마무리 작업 : 결과값 화면(display) 표시

            return algoResult;
        }
        public override void AssignPLCData()
        {
            // plc data 읽어오기 : plc align table 전체
            UpdatePLCIOs();
            // 구조체에 할당하기 : 실제 알고리즘에 사용할 데이터
            CvtPLCIO = new StdPLCTable();
            // cell id
            CvtPLCIO.SourceID = System.Convert.ToString(PlcValues[SRC_ID].CurValue);
            // align offset
            CvtPLCIO.Offset1 = System.Convert.ToDouble(PlcValues[OFFSET_X].CurValue);
            CvtPLCIO.Offset2 = System.Convert.ToDouble(PlcValues[OFFSET_Y].CurValue);
            CvtPLCIO.Offset3 = System.Convert.ToDouble(PlcValues[OFFSET_T].CurValue);
            // current position
            CvtPLCIO.CurPos1 = System.Convert.ToDouble(PlcValues[CURRENT_X].CurValue);
            CvtPLCIO.CurPos2 = System.Convert.ToDouble(PlcValues[CURRENT_Y].CurValue);
            CvtPLCIO.CurPos3 = System.Convert.ToDouble(PlcValues[CURRENT_T].CurValue);
        }
        #endregion

        #region 내부 함수
        private XYT GetCenterPoint(XY p1, XY p2)
        {
            return new XYT()
            {
                X = (p2.X + p1.X) / 2,
                Y = (p2.Y + p1.Y) / 2,
                T = GetTheta(p1, p2),
            };
        }
        private bool CheckTargetLength(AlgoTempleteModelParams mparam, double tarLen)
        {
            var spec = System.Convert.ToDouble(mparam.TargetLength.Value);
            var tol = System.Convert.ToDouble(mparam.LengthTolerance.Value);
            if (tarLen < spec - tol || tarLen > spec + tol)
                return false;

            return true;
        }

        private bool CheckObjectLength(AlgoTempleteModelParams mparam, double objLen)
        {
            var spec = System.Convert.ToDouble(mparam.ObjectLength.Value);
            var tol = System.Convert.ToDouble(mparam.LengthTolerance.Value);
            if (objLen < spec - tol || objLen > spec + tol)
                return false;

            return true;
        }

        private bool CheckLimit(AlgoTempleteModelParams mparam, XYT rev)
        {
            // rev x
            var limit = System.Convert.ToDouble(mparam.LimitX.Value);
            if (Math.Abs(rev.X) > limit)
                return false;
            // rev y
            limit = System.Convert.ToDouble(mparam.LimitY.Value);
            if (Math.Abs(rev.Y) > limit)
                return false;
            // rev t
            limit = System.Convert.ToDouble(mparam.LimitT.Value);
            if (Math.Abs(rev.T) > limit)
                return false;

            return true;
        }

        private bool CheckRetry(AlgoTempleteModelParams mparam, XYT rev)
        {
            // retry x
            var spec = System.Convert.ToDouble(mparam.RetryX.Value);
            if (Math.Abs(rev.X) > spec)
                return false;
            // retry y
            spec = System.Convert.ToDouble(mparam.RetryY.Value);
            if (Math.Abs(rev.Y) > spec)
                return false;
            // retry t
            spec = System.Convert.ToDouble(mparam.RetryT.Value);
            if (Math.Abs(rev.T) > spec)
                return false;

            return true;
        }
        private bool WritePLCData(XYT rev)
        {
            try
            {
                // revision value
                VisionValues[REV_X].NextValue = rev.X;
                VisionValues[REV_Y].NextValue = rev.Y;
                VisionValues[REV_T].NextValue = rev.T;
                // target value : current + rev
                var tar = CvtPLCIO.CurPosXYT + rev;

                VisionValues[TAR_X].NextValue = tar.X;
                VisionValues[TAR_Y].NextValue = tar.Y;
                VisionValues[TAR_T].NextValue = tar.T;
                // write
                return CommodObject.SetVisionValues(VisionValues.Values.ToList());
            }
            catch
            {
                return false;
            }
        }

        #endregion
    }
}
