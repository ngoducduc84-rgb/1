﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoTemplete
{
    [SerializableAttribute]
    public class AlgoTempleteModelParams : AlgoParams
    {
        #region Limit
        private AlgoParam limitX = new AlgoParam(nameof(LimitX), "mm", typeof(double), 1.0, "Revision X Limit", 0.0, 10.0);
        public AlgoParam LimitX
        {
            get { return limitX; }
            set { Set<AlgoParam>(ref limitX, value, nameof(LimitX)); }
        }

        private AlgoParam limitY = new AlgoParam(nameof(LimitY), "mm", typeof(double), 1.0, "Revision Y Limit", 0.0, 10.0);
        public AlgoParam LimitY
        {
            get { return limitY; }
            set { Set<AlgoParam>(ref limitY, value, nameof(LimitY)); }
        }

        private AlgoParam limitT = new AlgoParam(nameof(LimitT), "mm", typeof(double), 1.0, "Revision T Limit", 0.0, 10.0);
        public AlgoParam LimitT
        {
            get { return limitT; }
            set { Set<AlgoParam>(ref limitT, value, nameof(LimitT)); }
        }
        #endregion

        #region Retry
        private AlgoParam retryX = new AlgoParam(nameof(RetryX), "mm", typeof(double), 0.03, "Retry Spec X", 0.0, 0.5);
        public AlgoParam RetryX
        {
            get { return retryX; }
            set { Set<AlgoParam>(ref retryX, value, nameof(RetryX)); }
        }

        private AlgoParam retryY = new AlgoParam(nameof(RetryY), "mm", typeof(double), 0.03, "Retry Spec Y", 0.0, 0.5);
        public AlgoParam RetryY
        {
            get { return retryY; }
            set { Set<AlgoParam>(ref retryY, value, nameof(RetryY)); }
        }

        private AlgoParam retryT = new AlgoParam(nameof(RetryT), "mm", typeof(double), 0.03, "Retry Spec T", 0.0, 0.5);
        public AlgoParam RetryT
        {
            get { return retryT; }
            set { Set<AlgoParam>(ref retryT, value, nameof(RetryT)); }
        }
        #endregion

        #region Length
        private AlgoParam objectLength = new AlgoParam(nameof(ObjectLength), "mm", typeof(double), 10.0, "Object Length", 0.0, 100.0);
        public AlgoParam ObjectLength
        {
            get { return objectLength; }
            set { Set<AlgoParam>(ref objectLength, value, nameof(ObjectLength)); }
        }

        private AlgoParam targetLength = new AlgoParam(nameof(TargetLength), "mm", typeof(double), 10.0, "Target Length", 0.0, 100.0);
        public AlgoParam TargetLength
        {
            get { return targetLength; }
            set { Set<AlgoParam>(ref targetLength, value, nameof(TargetLength)); }
        }

        private AlgoParam lengthTolerance = new AlgoParam(nameof(LengthTolerance), "mm", typeof(double), 0.05, "Target Length", 0.0, 1.0);
        public AlgoParam LengthTolerance
        {
            get { return lengthTolerance; }
            set { Set<AlgoParam>(ref lengthTolerance, value, nameof(LengthTolerance)); }
        }

        private AlgoParam scaleFactor = new AlgoParam(nameof(ScaleFactor), "", typeof(double), 1.0, "scale factor for measurement", 0.0, 2.0);
        public AlgoParam ScaleFactor
        {
            get { return scaleFactor; }
            set { Set<AlgoParam>(ref scaleFactor, value, nameof(ScaleFactor)); }
        }
        #endregion
    }

    public class AlgoTempleteInputParams : InputParams
    {
        public IPointResult Target1 { get; set; }
        public IPointResult Target2 { get; set; }
        public IPointResult Object1 { get; set; }
        public IPointResult Object2 { get; set; }
        public CalcTrigger Trigger { get; set; }
    }

    public class AlgoTempleteOutputParams : OutputParams
    {
        public object Result { get; set; }
    }
 
    public class AlgoTempleteResult : AlgoResultBase
    {
        #region Common
        public override string Name
        {
            get { return name; }
            set { Set<string>(ref name, value, nameof(Name)); }
        }

        public override string ID
        {
            get { return id; }
            set { Set<string>(ref id, value, nameof(ID)); }
        }

        public override string CurDate
        {
            get { return curDate; }
            set { Set<string>(ref curDate, value, nameof(CurDate)); }
        }

        public override string CurTime
        {
            get { return curTime; }
            set { Set<string>(ref curTime, value, nameof(CurTime)); }
        }
        #endregion

        #region Revision Value
        private double revX;
        public double RevX
        {
            get { return revX; }
            set { Set<double>(ref revX, Math.Round(value, 3), nameof(RevX)); }
        }

        private double revY;
        public double RevY
        {
            get { return revY; }
            set { Set<double>(ref revY, Math.Round(value, 3), nameof(RevY)); }
        }

        private double revT;
        public double RevT
        {
            get { return revT; }
            set { Set<double>(ref revT, Math.Round(value, 3), nameof(RevT)); }
        }

        private double tarLength;
        public double TarLength
        {
            get { return tarLength; }
            set { Set<double>(ref tarLength, Math.Round(value, 3), nameof(TarLength)); }
        }

        private double objLength;
        public double ObjLength
        {
            get { return objLength; }
            set { Set<double>(ref objLength, Math.Round(value, 3), nameof(ObjLength)); }
        }

        #endregion

        #region Target Positions
        private double tar1X;
        public double Tar1X
        {
            get { return tar1X; }
            set { Set<double>(ref tar1X, Math.Round(value, 3), nameof(Tar1X)); }
        }

        private double tar1Y;
        public double Tar1Y
        {
            get { return tar1Y; }
            set { Set<double>(ref tar1Y, Math.Round(value, 3), nameof(Tar1Y)); }
        }

        private double tar2X;
        public double Tar2X
        {
            get { return tar2X; }
            set { Set<double>(ref tar2X, Math.Round(value, 3), nameof(Tar2X)); }
        }

        private double tar2Y;
        public double Tar2Y
        {
            get { return tar2Y; }
            set { Set<double>(ref tar2Y, Math.Round(value, 3), nameof(Tar2Y)); }
        }
        #endregion

        #region Object Positions
        private double obj1X;
        public double Obj1X
        {
            get { return obj1X; }
            set { Set<double>(ref obj1X, Math.Round(value, 3), nameof(Obj1X)); }
        }

        private double obj1Y;
        public double Obj1Y
        {
            get { return obj1Y; }
            set { Set<double>(ref obj1Y, Math.Round(value, 3), nameof(Obj1Y)); }
        }

        private double obj2X;
        public double Obj2X
        {
            get { return obj2X; }
            set { Set<double>(ref obj2X, Math.Round(value, 3), nameof(Obj2X)); }
        }

        private double obj2Y;
        public double Obj2Y
        {
            get { return obj2Y; }
            set { Set<double>(ref obj2Y, Math.Round(value, 3), nameof(Obj2Y)); }
        }
        #endregion
    }

    #region Converters
    internal class CalDataListConverter : TypeConverter
    {
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Common.GetEachObjectName(typeof(CalDataObject)));
        }
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }
    }
    #endregion

}
