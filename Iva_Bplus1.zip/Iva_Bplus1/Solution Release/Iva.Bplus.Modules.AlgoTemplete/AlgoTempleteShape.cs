﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.AlgoTemplete
{
    [SerializableAttribute]
    public class AlgoTempleteShape : ModuleBase
    {
        #region 생성자
        /// <summary>
        /// 기본 생성자
        /// </summary>
        public AlgoTempleteShape() : base()
        {
            // 기본 설정
            ShapeType = ShapeType.Algorithm;
            Geometry = SystemImage.TOOL_ALGORITHM_ICON;
        }
        /// <summary>
        /// 모듈 신규 생성할 때 호출되는 생성자 
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="name"></param>
        public AlgoTempleteShape(SystemCanvasViewModel parent, string name) : base(parent, name)
        {
            // 기본 설정
            ShapeType = ShapeType.Algorithm;
            Geometry = SystemImage.TOOL_ALGORITHM_ICON;
            // 상위 모듈 생성
            InitItem(null, name, SettingShapeType.Algo);
            // 커넥터 설정
            SetConnectors();
        }
        #endregion

        #region 공용 함수
        /// <summary>
        /// File에서 객체 불러온(Deserialize) 후 호출되는 함수
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="obj"></param>
        /// <param name="name"></param>
        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string name)
        {
            // 기본 설정
            ShapeType = ShapeType.Algorithm;
            Geometry = SystemImage.TOOL_ALGORITHM_ICON;
            // 캔버스 할당
            Parent = parent;
            // 상위 모듈 생성
            InitItem(obj, name, SettingShapeType.Algo);
        }
        #endregion

        #region 내부 함수
        #endregion
    }
}
