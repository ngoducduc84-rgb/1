﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Diagram.Items;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.Algo_C_PanelAttach;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telerik.Windows.Controls;
//using System.Windows.Forms.Integration;

using System.Drawing;
using System.IO;
using System.Windows.Forms.Integration;
using Cognex.VisionPro;
using System.Windows;

using Iva.Bplus.Modules.StdScheduler;
using Iva.Bplus.Modules.SubCogAcqFifo;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    //    AMB623TS01(Hubble X1)
    //1. PNL mark간 거리 : 50.45mm
    //2. C-PNL 노치간 거리 : 49.45mm

    //        AMB667UM06(A71)
    //1. PNL mark간 거리 : 58.33mm
    //2. C-PNL 노치간 거리 : 57.43mm

    [SerializableAttribute]
    public partial class Algo_C_PanelAttachAction : AlgoActionBase
    {
        #region [Fields]
        [field: NonSerialized]
        private ObservableCollection<ScaleParamsSet> insItems;
        [field: NonSerialized]
        private ObservableCollection<LengthParamsSet> alignItems;
        [field: NonSerialized]
        protected Visibility histoVisibility;


        [field: NonSerialized]
        protected WindowsFormsHost displayL;
        [field: NonSerialized]
        protected WindowsFormsHost displayR;
        [field: NonSerialized]
        protected WindowsFormsHost displayH;

        public WindowsFormsHost DisplayL
        {
            get { return displayL; }
            set { displayL = value; this.OnPropertyChanged(nameof(DisplayL)); }
        }
        public WindowsFormsHost DisplayR
        {
            get { return displayR; }
            set { displayR = value; this.OnPropertyChanged(nameof(DisplayR)); }
        }
        public WindowsFormsHost DisplayH
        {
            get { return displayH; }
            set { displayH = value; this.OnPropertyChanged(nameof(DisplayH)); }
        }

        public Visibility HistoVisibility
        {
            get { return histoVisibility; }
            set { histoVisibility = value; this.OnPropertyChanged(nameof(HistoVisibility)); }
        }
        #endregion

        #region [Properties]   
        public ObservableCollection<ScaleParamsSet> InsItems
        {
            get { return this.insItems; }
            set { if (insItems == value) return; insItems = value; this.OnPropertyChanged(nameof(InsItems)); }
        }
        public ObservableCollection<LengthParamsSet> AlignItems
        {
            get { return this.alignItems; }
            set { if (alignItems == value) return; alignItems = value; this.OnPropertyChanged(nameof(AlignItems)); }
        }
        #endregion

        #region [Construct]
        public Algo_C_PanelAttachAction(ModuleBase _parent, string _name, string _source, AlgoObjectBase _object)
            : base(_parent, _name, _source, _object)
        {
            InputParams = new Algo_C_PanelAttachInputParams();
            OutputParams = new Algo_C_PanelAttachOutputParams();

            var obj = _object as Algo_C_PanelAttachObject;
            HistoVisibility = Visibility.Collapsed;

            if (obj.ProcessType == ProcessType.PRE)
            {
                obj.ModelParamType = typeof(Algo_C_PanelAttachModelParams);
                obj.CreateParams();
                var param = obj.CurParams as Algo_C_PanelAttachModelParams;

                ChildSettingView = new AlignSetting();
                ChildSettingView.DataContext = this;

                if (obj.Options == null)
                {
                    obj.Options = new Algo_C_PanelAttachDefaultOptions();
                    // 2021.04.05 jyh 고객님께서 무주건 L-Check를 사용하고 싶다고 하신다.
                    //(obj.Options as Algo_C_PanelAttachDefaultOptions).UseLCheck.Value = obj.LCheckUse ? OnOff.On : OnOff.Off;
                    obj.LCheckUse = true;
                    obj.SaveObject();
                }
            }
            else if (obj.ProcessType == ProcessType.MAIN || obj.ProcessType == ProcessType.TAPE || obj.ProcessType == ProcessType.PANEL)
            {
                obj.ModelParamType = typeof(Algo_C_PanelAttachModelParams);
                obj.CreateParams();
                var param = obj.CurParams as Algo_C_PanelAttachModelParams;

                ChildSettingView = new AlignSetting();
                ChildSettingView.DataContext = this;

                if (obj.Options == null)
                {
                    obj.Options = new Algo_C_PanelAttachModelOptions();
                    // 2021.04.05 jyh 고객님께서 무주건 L-Check를 사용하고 싶다고 하신다.
                    //(obj.Options as Algo_C_PanelAttachModelOptions).UseLCheck.Value = obj.LCheckUse ? OnOff.On : OnOff.Off; obj.LCheckUse
                    obj.LCheckUse = true;
                    obj.SaveObject();
                }

                if (obj.ProcessType == ProcessType.MAIN)
                {
                    obj.CogDsL = new Cognex.VisionPro.CogRecordDisplay();
                    displayL = new WindowsFormsHost()
                    {
                        Child = obj.CogDsL
                    };
                    obj.CogDsR = new Cognex.VisionPro.CogRecordDisplay();
                    displayR = new WindowsFormsHost()
                    {
                        Child = obj.CogDsR
                    };
                    obj.CogDsL.CreateControl();
                    obj.CogDsL.VerticalScrollBar = false;
                    obj.CogDsL.HorizontalScrollBar = false;
                    obj.CogDsL.AutoFit = true;
                    obj.CogDsR.CreateControl();
                    obj.CogDsR.VerticalScrollBar = false;
                    obj.CogDsR.HorizontalScrollBar = false;
                    obj.CogDsR.AutoFit = true;


                    obj.AreaL.Changed -= obj.AreaL_Changed;
                    obj.AreaL.Changed += obj.AreaL_Changed;
                    obj.AreaL.DraggingStopped -= obj.AreaL_DraggingStopped;
                    obj.AreaL.DraggingStopped += obj.AreaL_DraggingStopped;

                    obj.AreaL.Interactive = true;
                    obj.AreaL.GraphicDOFEnable = CogRectangleDOFConstants.All;
                    obj.AreaL.LineStyle = CogGraphicLineStyleConstants.Solid;
                    //obj.AreaL.LineWidthInScreenPixels = 2;
                    obj.AreaL.Color = CogColorConstants.Blue;

                    obj.AreaR.Changed -= obj.AreaR_Changed;
                    obj.AreaR.Changed += obj.AreaR_Changed;
                    obj.AreaR.DraggingStopped -= obj.AreaR_DraggingStopped;
                    obj.AreaR.DraggingStopped += obj.AreaR_DraggingStopped;
                    obj.AreaR.X = 0;
                    obj.AreaR.Y = 0;
                    obj.AreaR.Width = 500;
                    obj.AreaR.Height = 200;

                    obj.AreaR.Interactive = true;
                    obj.AreaR.GraphicDOFEnable = CogRectangleDOFConstants.All;
                    obj.AreaR.LineStyle = CogGraphicLineStyleConstants.Solid;
                    //obj.AreaR.LineWidthInScreenPixels = 2;
                    obj.AreaR.Color = CogColorConstants.Blue;

                    obj.CogDsL.InteractiveGraphics.Add(obj.AreaL, "AreaL", true);
                    obj.CogDsR.InteractiveGraphics.Add(obj.AreaR, "AreaR", true);
                    HistoVisibility = Visibility.Visible;

                }

            }
            else if (obj.ProcessType == ProcessType.H2H)
            {
                obj.ModelParamType = typeof(Algo_C_PanelAttachModelParamsH2H);
                obj.CreateParams();
                var param = obj.CurParams as Algo_C_PanelAttachModelParamsH2H;

                ChildSettingView = new H2HSetting();
                ChildSettingView.DataContext = this;
                obj.CogDsH = new Cognex.VisionPro.CogRecordDisplay();
                displayH = new WindowsFormsHost()
                {
                    Child = obj.CogDsH
                };
                obj.CogDsH.CreateControl();
                obj.CogDsH.VerticalScrollBar = false;
                obj.CogDsH.HorizontalScrollBar = false;
                obj.CogDsH.AutoFit = true;
             

                obj.AreaH.Changed -= obj.AreaH_Changed;
                obj.AreaH.Changed += obj.AreaH_Changed;
                obj.AreaH.DraggingStopped -= obj.AreaH_DraggingStopped;
                obj.AreaH.DraggingStopped += obj.AreaH_DraggingStopped;

                obj.AreaH.Interactive = true;
                obj.AreaH.GraphicDOFEnable = CogRectangleDOFConstants.All;
                obj.AreaH.LineStyle = CogGraphicLineStyleConstants.Solid;
                //obj.AreaL.LineWidthInScreenPixels = 2;
                obj.AreaH.Color = CogColorConstants.Blue;

                obj.CogDsH.InteractiveGraphics.Add(obj.AreaH, "AreaH", true);
                HistoVisibility = Visibility.Visible;
            }
            else
            {
                obj.ModelParamType = typeof(Algo_C_PanelAttachModelParamsIns);
                obj.CreateParams();
                var param = obj.CurParams as Algo_C_PanelAttachModelParamsIns;

                ChildSettingView = new InspectSetting();
                ChildSettingView.DataContext = this;

                if (obj.Options == null)
                {
                    obj.Options = new Algo_C_PanelAttachDefaultOptions();
                    // 2021.04.05 jyh 고객님께서 무주건 L-Check를 사용하고 싶다고 하신다.
                    //(obj.Options as Algo_C_PanelAttachDefaultOptions).UseLCheck.Value = obj.LCheckUse ? OnOff.On : OnOff.Off;
                    obj.LCheckUse = true;
                    obj.SaveObject();
                }

            }

            ModObject.PropertyChanged += ModObject_PropertyChanged;

            //SystemInfo.SetEPLabel("jintech_20201110");
            //SystemInfo.SetEPLabel("jintech_20201111");//rdp filename change
            //SystemInfo.SetEPLabel("jintech_20201114");//hole dist logic change
            //SystemInfo.SetEPLabel("jintech_20201124");//change folder name (2digit)
            //SystemInfo.SetEPLabel("jintech_20201126");// ng일때 D/L 실행해서 체크해 보기
            //SystemInfo.SetEPLabel("jintech_20201203");// Recipe 저장 시 Key 값에 일시 반영되게 적용, H2H J/C Exception 처리
            //SystemInfo.SetEPLabel("jintech_20201211");// Log 경로 변경 시 자동삭제 경로도 연동되게 : D: -> SystemDir.LogRoot
            //SystemInfo.SetEPLabel("jintech_20201212");// Image File 만 자동삭제.. (빈 폴더는 프로그램 재 시작시 정리)
            SystemInfo.SetEPLabel("sdc_20210118");// Image File 만 자동삭제.. (빈 폴더는 프로그램 재 시작시 정리)
            SystemInfo.SetEPLabel("sdc_20210126");
            SystemInfo.SetEPLabel("sdc_20210211"); // H2H D/L 적용.

            SystemInfo.SetEPLabel("sdc_20210405"); // L-Check 기능 무조껀 사용하도록..

        }

        private void Algo_C_PanelAttachAction_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            var obj = ModObject as Algo_C_PanelAttachObject;

            

        }

        private void ModObject_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            var obj = sender as Algo_C_PanelAttachObject;

            if (e.PropertyName == "ProcessType")
            {
                if (obj.ProcessType == ProcessType.PRE)
                {
                    obj.ModelParamType = typeof(Algo_C_PanelAttachModelParams);
                    var param = obj.CurParams as Algo_C_PanelAttachModelParams;

                    ChildSettingView = new AlignSetting();
                    ChildSettingView.DataContext = this;
                }

                else if (obj.ProcessType == ProcessType.MAIN || obj.ProcessType == ProcessType.TAPE || obj.ProcessType == ProcessType.PANEL)
                {
                    obj.ModelParamType = typeof(Algo_C_PanelAttachModelParams);
                    var param = obj.CurParams as Algo_C_PanelAttachModelParams;

                    ChildSettingView = new AlignSetting();
                    ChildSettingView.DataContext = this;
                }

                else if (obj.ProcessType == ProcessType.INSPECT)
                {
                    obj.ModelParamType = typeof(Algo_C_PanelAttachModelParamsIns);
                    var param = obj.CurParams as Algo_C_PanelAttachModelParamsIns;

                    ChildSettingView = new InspectSetting();
                    ChildSettingView.DataContext = this;
                }
                else if (obj.ProcessType == ProcessType.H2H)
                {
                    obj.ModelParamType = typeof(Algo_C_PanelAttachModelParamsH2H);
                    var param = obj.CurParams as Algo_C_PanelAttachModelParamsH2H;

                    ChildSettingView = new InspectSetting();
                    ChildSettingView.DataContext = this;
                }
            }
        }
        #endregion

        #region [override method]
        public override List<CommandReplyArgs> Play(ModuleActionBase obj, CmdReqArgs _args)
        {
            string InputName = Start(obj, _args, false);
            var Obj = modObject as Algo_C_PanelAttachObject;

            if (InputName.Equals("Trigger") || InputName == string.Empty)
            {
                StartTimer();
                var algoCmd = _args.Value as AlgoCommandInfo;

                // 2021.04.06 hdy 이미지 저장을 위해 설정
                var connection = this.parent.GetInputConnector("Trigger");
                Obj.schName = (connection.AttachedConnections[0].SourceConnector.ParentItem.ModAction as SchedulerActionBase).Name;
                Obj.bConfirm = algoCmd.ManualConfirm;

                #region Step1 : Calc
                Obj.Name = name;    // 이름 넣어주기.
                Obj.SourceID = ObjectID;
                Obj.DestID = DestID;
                DateTime dateTime = DateTime.Now;

                SetCPNLFlowAutoSetting(); // 그냥 첫장은 버리더라도 한번 들어오면 설정하게 하자

                if(Obj.ProcessType == ProcessType.H2H)
                {
                    SetCPNLH2HAcqAutoSetting();
                }

                if (!Obj.Run())
                {
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    if (Obj.P1_DisplayObj.Judgement == (uint)Judgement.OK || Obj.P1_DisplayObj.Judgement == (uint)Judgement.None)
                    {
                        Obj.P1_DisplayObj.Judgement = (uint)Judgement.Error;
                        Obj.P2_DisplayObj.Judgement = (uint)Judgement.Error;
                        Obj.H1_DisplayObj.Judgement = (uint)Judgement.Error;
                    }

                    /////////////////////////////////////////////////////////
                    // PSJ
                    /////////////////////////////////////////////////////////
                    Obj.ScreenCapture();

                    if (InputValues.ContainsKey("P1"))
                        InputValues["P1"] = null;
                    if (InputValues.ContainsKey("P2"))
                        InputValues["P2"] = null;
                    if (InputValues.ContainsKey("H1"))
                        InputValues["H1"] = null;
                    if (InputValues.ContainsKey("Tar_P1"))
                        InputValues["Tar_P1"] = null;
                    if (InputValues.ContainsKey("Tar_P2"))
                        InputValues["Tar_P2"] = null;
                    if (InputValues.ContainsKey("Obj_P1"))
                        InputValues["Obj_P1"] = null;
                    if (InputValues.ContainsKey("Obj_P2"))
                        InputValues["Obj_P2"] = null;
                    if (InputValues.ContainsKey("Outputs"))
                        InputValues["Outputs"] = null;

                    /////////////////////////////////////////////////////////
                    /////////////////////////////////////////////////////////
                    /////////////////////////////////////////////////////////

                    //SetParams(Obj);
                    return OccurError(Obj.ErrorCode);
                }
                else
                {
                    OutputPlay("Result", Obj.AlgoRst, CmdRequest.Play, _args.Mode, CmdWait.No_Wait);
                    Obj.AppendMessage(Name, "Caluration Complete");

                    SetParams(Obj);


                    /////////////////////////////////////////////////////////
                    // PSJ
                    /////////////////////////////////////////////////////////
                    Obj.ScreenCapture();

                    if (InputValues.ContainsKey("P1"))
                        InputValues["P1"] = null;
                    if (InputValues.ContainsKey("P2"))
                        InputValues["P2"] = null;
                    if (InputValues.ContainsKey("H1"))
                        InputValues["H1"] = null;
                    if (InputValues.ContainsKey("Tar_P1"))
                        InputValues["Tar_P1"] = null;
                    if (InputValues.ContainsKey("Tar_P2"))
                        InputValues["Tar_P2"] = null;
                    if (InputValues.ContainsKey("Obj_P1"))
                        InputValues["Obj_P1"] = null;
                    if (InputValues.ContainsKey("Obj_P2"))
                        InputValues["Obj_P2"] = null;
                    if (InputValues.ContainsKey("Outputs"))
                        InputValues["Outputs"] = null;
                    /////////////////////////////////////////////////////////
                    /////////////////////////////////////////////////////////
                    /////////////////////////////////////////////////////////
                    //return End();
                }

                #endregion
            }

            return End();
        }

        private void SetCPNLFlowAutoSetting()
        {
            var owner = SystemObject_System.GetOwnerSchedulerModule(this.name);

            if (owner == null) return;

            var act = owner.ModAction as StdSchedulerAction;
            var obj = act.ModObject as StdSchedulerObject;

            obj.UseNGImageSave = true;
            obj.UseOKImageSave = true;
            obj.UseAutoCapture = true;
            obj.UseOriginImage = true;
            obj.UseOverlayImage = true;
        }

        private void SetCPNLH2HAcqAutoSetting()
        {
            var owner = SystemObject_System.GetOwnerModule(this.name, typeof(SubCogAcqFifoAction));

            if (owner == null) return;

            var act = owner.ModAction as SubCogAcqFifoAction;
            var obj = act.ModObject as SubCogAcqFifoObject;

            obj.RunLastImage = OnOff.On;
            obj.SimulationMode = OnOff.On;

            
        }



        public override bool Reset()
        {
            if (!base.Reset()) return false;

            return true;
        }

        void SetParams(Algo_C_PanelAttachObject Obj)
        {
            if (Obj.ProcessType == ProcessType.INSPECT)
            {
                var cur = Obj.TempParams as Algo_C_PanelAttachModelParamsIns;
                SetScaleParams(cur, Obj);
                SetLengthParams(cur, Obj);
            }
            else if (Obj.ProcessType == ProcessType.H2H)
            {
                ;
            }
            else
            {
                var cur = Obj.TempParams as Algo_C_PanelAttachModelParams;
                SetLengthParams1(cur, Obj);
            }
        }

        #endregion

        #region [Command]
        [field: NonSerialized]
        AlgoParams m_CurParamScale;

        [field: NonSerialized]
        private DelegateCommand scaleResetCommand;
        public DelegateCommand ScaleResetCommand
        {
            get
            {
                return scaleResetCommand = scaleResetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as Algo_C_PanelAttachObject;
                    var tmp = Obj.TempParams as Algo_C_PanelAttachModelParamsIns;

                    if (m_CurParamScale == null) m_CurParamScale = tmp;
                    var cur = m_CurParamScale as Algo_C_PanelAttachModelParamsIns;

                    SetScaleParams(cur, Obj, true);

                    tmp.Scale_Lx.Value = (double)1.0;
                    tmp.Scale_Ly.Value = (double)1.0;
                    tmp.Scale_Rx.Value = (double)1.0;
                    tmp.Scale_Ry.Value = (double)1.0;
                    tmp.Scale_HoleX.Value = (double)1.0;
                    tmp.Scale_HoleY.Value = (double)1.0;

                    Obj.UpdateTempValues();
                    this.OnPropertyChanged(nameof(InsItems));
                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand scaleCalcCommand;
        public DelegateCommand ScaleCalcCommand
        {
            get
            {
                return scaleCalcCommand = scaleCalcCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as Algo_C_PanelAttachObject;
                    var tmp = Obj.TempParams as Algo_C_PanelAttachModelParamsIns;

                    m_CurParamScale = DeepClone<AlgoParams>(Obj.CurParams);
                    var cur = m_CurParamLength as Algo_C_PanelAttachModelParamsIns;

                    if (insItems == null)
                    {
                        SetScaleParams(cur, Obj);
                    }

                    if (insItems == null || insItems.Count == 0) return;

                    insItems[0].Scale = Math.Round(insItems[0].Measure / insItems[0].CurValue, 3);
                    insItems[1].Scale = Math.Round(insItems[1].Measure / insItems[1].CurValue, 3);
                    insItems[2].Scale = Math.Round(insItems[2].Measure / insItems[2].CurValue, 3);
                    insItems[3].Scale = Math.Round(insItems[3].Measure / insItems[3].CurValue, 3);
                    insItems[4].Scale = Math.Round(insItems[4].Measure / insItems[4].CurValue, 3);
                    insItems[5].Scale = Math.Round(insItems[5].Measure / insItems[5].CurValue, 3);

                    insItems[0].Scale = insItems[0].Scale == 0 ? 1 : insItems[0].Scale;
                    insItems[1].Scale = insItems[1].Scale == 0 ? 1 : insItems[1].Scale;
                    insItems[2].Scale = insItems[2].Scale == 0 ? 1 : insItems[2].Scale;
                    insItems[3].Scale = insItems[3].Scale == 0 ? 1 : insItems[3].Scale;
                    insItems[4].Scale = insItems[4].Scale == 0 ? 1 : insItems[4].Scale;
                    insItems[5].Scale = insItems[5].Scale == 0 ? 1 : insItems[5].Scale;

                    insItems[0].CurValue *= insItems[0].Scale;
                    insItems[1].CurValue *= insItems[1].Scale;
                    insItems[2].CurValue *= insItems[2].Scale;
                    insItems[3].CurValue *= insItems[3].Scale;
                    insItems[4].CurValue *= insItems[4].Scale;
                    insItems[5].CurValue *= insItems[5].Scale;

                    tmp.Spec_Lx.Value = insItems[0].Spec;
                    tmp.Spec_Ly.Value = insItems[1].Spec;
                    tmp.Spec_Rx.Value = insItems[2].Spec;
                    tmp.Spec_Ry.Value = insItems[3].Spec;
                    tmp.Spec_HoleX.Value = insItems[4].Spec;
                    tmp.Spec_HoleY.Value = insItems[5].Spec;

                    tmp.Tor_Lx.Value = insItems[0].Tor;
                    tmp.Tor_Ly.Value = insItems[1].Tor;
                    tmp.Tor_Rx.Value = insItems[2].Tor;
                    tmp.Tor_Ry.Value = insItems[3].Tor;
                    tmp.Tor_HoleX.Value = insItems[4].Tor;
                    tmp.Tor_HoleY.Value = insItems[5].Tor;

                    tmp.Scale_Lx.Value = insItems[0].Scale;
                    tmp.Scale_Ly.Value = insItems[1].Scale;
                    tmp.Scale_Rx.Value = insItems[2].Scale;
                    tmp.Scale_Ry.Value = insItems[3].Scale;
                    tmp.Scale_HoleX.Value = insItems[4].Scale;
                    tmp.Scale_HoleY.Value = insItems[5].Scale;

                    // 업뎃
                    Obj.UpdateTempValues();
                    this.OnPropertyChanged(nameof(InsItems));
                });

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cur"></param>
        /// <param name="Obj"></param>
        void SetScaleParams(Algo_C_PanelAttachModelParamsIns cur, Algo_C_PanelAttachObject Obj, bool bInit = false)
        {
            if (insItems != null) insItems = null;

            insItems = new ObservableCollection<ScaleParamsSet>();

            if (bInit)
            {
                insItems.Add(new ScaleParamsSet("Lx", (double)cur.Spec_Lx.Value, (double)cur.Tor_Lx.Value, Math.Round(Obj.InspResult.Lx, 3), 0.0, 1.0));
                insItems.Add(new ScaleParamsSet("Ly", (double)cur.Spec_Ly.Value, (double)cur.Tor_Ly.Value, Math.Round(Obj.InspResult.Ly, 3), 0.0, 1.0));
                insItems.Add(new ScaleParamsSet("Rx", (double)cur.Spec_Rx.Value, (double)cur.Tor_Rx.Value, Math.Round(Obj.InspResult.Rx, 3), 0.0, 1.0));
                insItems.Add(new ScaleParamsSet("Ry", (double)cur.Spec_Ry.Value, (double)cur.Tor_Ry.Value, Math.Round(Obj.InspResult.Ry, 3), 0.0, 1.0));
                insItems.Add(new ScaleParamsSet("Hx", (double)cur.Spec_HoleX.Value, (double)cur.Tor_HoleX.Value, Math.Round(Obj.ObjToTapeDist.X, 3), 0.0, 1.0));
                insItems.Add(new ScaleParamsSet("Hy", (double)cur.Spec_HoleY.Value, (double)cur.Tor_HoleY.Value, Math.Round(Obj.ObjToTapeDist.Y, 3), 0.0, 1.0));
            }
            else
            {
                insItems.Add(new ScaleParamsSet("Lx", (double)cur.Spec_Lx.Value, (double)cur.Tor_Lx.Value, Math.Round(Obj.InspResult.Lx, 3), 0.0, (double)cur.Scale_Lx.Value));
                insItems.Add(new ScaleParamsSet("Ly", (double)cur.Spec_Ly.Value, (double)cur.Tor_Ly.Value, Math.Round(Obj.InspResult.Ly, 3), 0.0, (double)cur.Scale_Ly.Value));
                insItems.Add(new ScaleParamsSet("Rx", (double)cur.Spec_Rx.Value, (double)cur.Tor_Rx.Value, Math.Round(Obj.InspResult.Rx, 3), 0.0, (double)cur.Scale_Rx.Value));
                insItems.Add(new ScaleParamsSet("Ry", (double)cur.Spec_Ry.Value, (double)cur.Tor_Ry.Value, Math.Round(Obj.InspResult.Ry, 3), 0.0, (double)cur.Scale_Ry.Value));
                insItems.Add(new ScaleParamsSet("Hx", (double)cur.Spec_HoleX.Value, (double)cur.Tor_HoleX.Value, Math.Round(Obj.ObjToTapeDist.X, 3), 0.0, (double)cur.Scale_HoleX.Value));
                insItems.Add(new ScaleParamsSet("Hy", (double)cur.Spec_HoleY.Value, (double)cur.Tor_HoleY.Value, Math.Round(Obj.ObjToTapeDist.Y, 3), 0.0, (double)cur.Scale_HoleY.Value));
            }

            this.OnPropertyChanged(nameof(InsItems));
        }

        [field: NonSerialized]
        private DelegateCommand reMeasureCommand;
        public DelegateCommand ReMeasureCommand
        {
            get
            {
                return reMeasureCommand = reMeasureCommand ?? new DelegateCommand(obj =>
                {
                    //if (!IsCanExecute) return;
                    //if (isAuto) return;

                    Task task = Task.Run(() =>
                    {
                        CmdReqArgs args = new CmdReqArgs(null, Parent, null, null, Parent.GetInputConnector(CustumTriggerName), CmdRequest.Play, CmdMode.Link);
                        Task<List<CommandReplyArgs>>.Factory.StartNew(() => Execute(this, args));
                    });
                });

            }
        }

        [field: NonSerialized]
        AlgoParams m_CurParamLength;

        [field: NonSerialized]
        private DelegateCommand lengthReloadCommand;
        public DelegateCommand LengthReloadCommand
        {
            get
            {
                return lengthReloadCommand = lengthReloadCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as Algo_C_PanelAttachObject;
                    var tmp = Obj.TempParams as Algo_C_PanelAttachModelParamsIns;

                    if (m_CurParamLength == null) m_CurParamLength = tmp;
                    var cur = m_CurParamLength as Algo_C_PanelAttachModelParamsIns;

                    SetLengthParams(cur, Obj);
                    //alignItems = new ObservableCollection<LengthParamsSet>();
                    //alignItems.Add(new LengthParamsSet("Length_Obj", (double)cur.Length_Obj.Value, (double)cur.Tor_Obj.Value, Math.Round(Obj.LengthObj, 3)));
                    //alignItems.Add(new LengthParamsSet("Length_Tar", (double)cur.Length_Tar.Value, (double)cur.Tor_Tar.Value, Math.Round(Obj.LengthTar, 3)));

                    tmp.Length_Obj.Value = cur.Length_Obj.Value;
                    tmp.Length_Tar.Value = cur.Length_Tar.Value;

                    Obj.UpdateTempValues();
                    this.OnPropertyChanged(nameof(AlignItems));
                });
            }
        }

        [field: NonSerialized]
        private DelegateCommand lengthSetCommand;
        public DelegateCommand LengthSetCommand
        {
            get
            {
                return lengthSetCommand = lengthSetCommand ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as Algo_C_PanelAttachObject;
                    var tmp = Obj.TempParams as Algo_C_PanelAttachModelParamsIns;

                    m_CurParamLength = DeepClone<AlgoParams>(Obj.CurParams);
                    var cur = m_CurParamLength as Algo_C_PanelAttachModelParamsIns;

                    if (alignItems == null)
                    {
                        SetLengthParams(cur, Obj);
                        //alignItems = new ObservableCollection<LengthParamsSet>();
                        //alignItems.Add(new LengthParamsSet("Length_Obj", (double)cur.Length_Obj.Value, (double)cur.Tor_Obj.Value, Math.Round(Obj.LengthObj, 3)));
                        //alignItems.Add(new LengthParamsSet("Length_Tar", (double)cur.Length_Tar.Value, (double)cur.Tor_Tar.Value, Math.Round(Obj.LengthTar, 3)));
                    }

                    tmp.Length_Obj.Value = alignItems[0].Spec = alignItems[0].CurValue = Math.Round(Obj.LengthObj, 3);
                    tmp.Length_Tar.Value = alignItems[1].Spec = alignItems[1].CurValue = Math.Round(Obj.LengthTar, 3);

                    tmp.Tor_Obj.Value = alignItems[0].Tor;
                    tmp.Tor_Tar.Value = alignItems[1].Tor;

                    Obj.UpdateTempValues();
                    this.OnPropertyChanged(nameof(AlignItems));
                });
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cur"></param>
        /// <param name="Obj"></param>
        void SetLengthParams(Algo_C_PanelAttachModelParamsIns cur, Algo_C_PanelAttachObject Obj)
        {
            if (alignItems == null)
            {
                alignItems = new ObservableCollection<LengthParamsSet>();
                alignItems.Add(new LengthParamsSet("Length_Obj", 0.0, 0.0, 0.0));
                alignItems.Add(new LengthParamsSet("Length_Tar", 0.0, 0.0, 0.0));
            }

            if ((double)cur.Tor_Obj.Value == 0.0) cur.Tor_Obj.Value = 0.3;
            if ((double)cur.Tor_Tar.Value == 0.0) cur.Tor_Tar.Value = 0.3;

            if (alignItems == null || alignItems.Count < 2) return;

            alignItems[0].Spec = (double)cur.Length_Obj.Value;
            alignItems[0].Tor = (double)cur.Tor_Obj.Value;
            alignItems[0].CurValue = Math.Round(Obj.LengthObj, 3);
            alignItems[1].Spec = (double)cur.Length_Tar.Value;
            alignItems[1].Tor = (double)cur.Tor_Tar.Value;
            alignItems[1].CurValue = Math.Round(Obj.LengthTar, 3);

            if (Obj.UseAutoLengthSet == OnOff.Off) return;

            var tmp = Obj.TempParams as Algo_C_PanelAttachModelParamsIns;
            if (Math.Abs((double)tmp.Length_Obj.Value - Obj.LengthObj) < (double)tmp.Tor_Obj.Max)
            {
                tmp.Length_Obj.Value = alignItems[0].Spec = alignItems[0].CurValue = Math.Round(Obj.LengthObj, 3);
                tmp.Tor_Obj.Value = alignItems[0].Tor;
            }
            if (Math.Abs((double)tmp.Length_Tar.Value - Obj.LengthTar) < (double)tmp.Tor_Tar.Max)
            {
                tmp.Length_Tar.Value = alignItems[1].Spec = alignItems[1].CurValue = Math.Round(Obj.LengthTar, 3);
                tmp.Tor_Tar.Value = alignItems[1].Tor;
            }
            Obj.UpdateTempValues();
            this.OnPropertyChanged(nameof(AlignItems));
        }


        [field: NonSerialized]
        AlgoParams m_CurParamLength1;

        [field: NonSerialized]
        private DelegateCommand lengthReloadCommand1;
        public DelegateCommand LengthReloadCommand1
        {
            get
            {
                return lengthReloadCommand1 = lengthReloadCommand1 ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as Algo_C_PanelAttachObject;
                    var tmp = Obj.TempParams as Algo_C_PanelAttachModelParams;

                    if (m_CurParamLength1 == null) m_CurParamLength1 = tmp;
                    var cur = m_CurParamLength1 as Algo_C_PanelAttachModelParams;

                    SetLengthParams1(cur, Obj);
                    tmp.Length_Obj.Value = Math.Round((double)cur.Length_Obj.Value, 3);

                    Obj.UpdateTempValues();
                    this.OnPropertyChanged(nameof(AlignItems));
                });
            }

        }

        [field: NonSerialized]
        private DelegateCommand lengthSetCommand1;
        public DelegateCommand LengthSetCommand1
        {
            get
            {
                return lengthSetCommand1 = lengthSetCommand1 ?? new DelegateCommand(obj =>
                {
                    var Obj = modObject as Algo_C_PanelAttachObject;
                    var tmp = Obj.TempParams as Algo_C_PanelAttachModelParams;

                    m_CurParamLength1 = DeepClone<AlgoParams>(Obj.CurParams);
                    var cur = m_CurParamLength1 as Algo_C_PanelAttachModelParams;

                    if (alignItems == null)
                    {
                        SetLengthParams1(cur, Obj);
                    }

                    tmp.Length_Obj.Value = alignItems[0].Spec = alignItems[0].CurValue = Math.Round(Obj.LengthObj, 3);
                    tmp.Tor_Obj.Value = alignItems[0].Tor;

                    Obj.UpdateTempValues();
                    this.OnPropertyChanged(nameof(AlignItems));
                });
            }
        }

        void SetLengthParams1(Algo_C_PanelAttachModelParams cur, Algo_C_PanelAttachObject Obj)
        {
            if (alignItems == null)
            {
                alignItems = new ObservableCollection<LengthParamsSet>();
                alignItems.Add(new LengthParamsSet("Length_Obj", 0.0, 0.0, 0.0));
            }

            if ((double)cur.Tor_Obj.Value == 0.0) cur.Tor_Obj.Value = 0.3;
            if (alignItems == null || alignItems.Count < 1) return;

            alignItems[0].Spec = (double)cur.Length_Obj.Value;
            alignItems[0].Tor = (double)cur.Tor_Obj.Value;
            alignItems[0].CurValue = Math.Round(Obj.LengthObj, 3);

            if (Obj.UseAutoLengthSet == OnOff.Off) return;
            var tmp = Obj.TempParams as Algo_C_PanelAttachModelParams;
            if (Math.Abs((double)tmp.Length_Obj.Value - Obj.LengthObj) < (double)tmp.Tor_Obj.Max)
            {
                tmp.Length_Obj.Value = alignItems[0].Spec = alignItems[0].CurValue = Math.Round(Obj.LengthObj, 3);
                tmp.Tor_Obj.Value = alignItems[0].Tor;
                Obj.UpdateTempValues();
            }
            this.OnPropertyChanged(nameof(AlignItems));
        }



        [field: NonSerialized]
        private DelegateCommand directionLCommand;
        public DelegateCommand DirectionLCommand
        {
            get
            {
                return directionLCommand = directionLCommand ?? new DelegateCommand(obj =>
                {
                    DirectionChangeL();
                });

            }
        }
        [field: NonSerialized]
        private DelegateCommand directionRCommand;
        public DelegateCommand DirectionRCommand
        {
            get
            {
                return directionRCommand = directionRCommand ?? new DelegateCommand(obj =>
                {
                    DirectionChangeR();
                });

            }
        }

        private string directionL;
        private string directionR;
        public string DirectionL
        {
            get
            {
                var obj = ModObject as Algo_C_PanelAttachObject;

                return obj.IsLessThan_L ? "<" : ">";
            }
        }
        public string DirectionR
        {
            get
            {
                var obj = ModObject as Algo_C_PanelAttachObject;

                return obj.IsLessThan_R ? "<" : ">";
            }
        }
        public void DirectionChangeL()
        {
            var obj = ModObject as Algo_C_PanelAttachObject;
            obj.IsLessThan_L = !obj.IsLessThan_L;
            this.OnPropertyChanged(nameof(DirectionL));
        }

        public void DirectionChangeR()
        {
            var obj = ModObject as Algo_C_PanelAttachObject;
            obj.IsLessThan_R = !obj.IsLessThan_R;
            this.OnPropertyChanged(nameof(DirectionR));
        }



        [field: NonSerialized]
        private DelegateCommand dspTestCommand;
        public DelegateCommand DspTestCommand
        {
            get
            {
                return dspTestCommand = dspTestCommand ?? new DelegateCommand(obj =>
                {
                    TestFunc();
                });

            }
        }

        [field: NonSerialized]
        private DelegateCommand holeTestCommand;
        public DelegateCommand HoleTestCommand
        {
            get
            {
                return holeTestCommand = holeTestCommand ?? new DelegateCommand(obj =>
                {
                    HoleGreyTestFunc();
                });

            }
        }


        public void TestFunc()
        {
            
            var obj = ModObject as Algo_C_PanelAttachObject;
            obj.TestCPNLAttached();

        }

        public void HoleGreyTestFunc()
        {
            var obj = ModObject as Algo_C_PanelAttachObject;
            obj.HoleGreyTest();
        }


        #endregion

        #region [Override]
        public override void PrepareSave()
        {
            base.PrepareSave();
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        public override void SystemModel_ModelChangeRequest(string oldModel, string newModel)
        {
            base.SystemModel_ModelChangeRequest(oldModel, newModel);
        }

        public override void SystemModel_ModelCreateRequest(string curModel, string newModel)
        {
            base.SystemModel_ModelCreateRequest(curModel, newModel);
        }

        public override void SystemModel_ModelDeleteRequest(string delModel)
        {
            base.SystemModel_ModelDeleteRequest(delModel);
        }
        #endregion

    }
}
