﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;
using Cognex.VisionPro.Display;
using System.Drawing;
using Iva.Bplus.Interface;
using Cognex.VisionPro;
using Cognex.VisionPro.Dimensioning;
using Iva.Bplus.Modules.InspectionChart;

using System.IO;
using Iva.Bplus.Diagram;
using Iva.Bplus.Modules.MultiGridViewDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]
    public partial class Algo_C_PanelAttachObject : AlgoObjectBase
    {
        //#region 2020.04.03 jyh 
        //[Browsable(true)]
        //[TypeConverter(typeof(VisionReportListConverter))]
        //public string VisionReport
        //{
        //    get { return visionReport; }
        //    set { if (visionReport == value) return; visionReport = value; this.OnPropertyChanged(nameof(VisionReport)); }
        //}
        //public VisionReportObject ReportObject { get { return SystemObject_Display.GetObject(visionReport) as VisionReportObject; } }
        //#endregion

          

        #region Vision IOs
        public IOStruct VReady { get { return GetVisionIO("Ready"); } }
        public IOStruct VStartAck { get { return GetVisionIO("StartAck"); } }
        public IOStruct VComp { get { return GetVisionIO("Comp"); } }
        //public IOStruct VReserve3 { get { return GetVisionIO("Reserve#3"); } }
        public IOStruct VResultOK { get { return GetVisionIO("ResultOK"); } }
        public IOStruct VResultNG { get { return GetVisionIO("ResultNG"); } }
        public IOStruct VGrabAck1 { get { return GetVisionIO("GrabAck#1"); } }
        public IOStruct VGrabAck2 { get { return GetVisionIO("GrabAck#2"); } }
        public IOStruct VGrabAck3 { get { return GetVisionIO("GrabAck#3"); } }
        public IOStruct VGrabAck4 { get { return GetVisionIO("GrabAck#4"); } }
        //public IOStruct VCalStartReq { get { return GetVisionIO("CalStartReq"); } }
        //public IOStruct VMoveCmdReq { get { return GetVisionIO("MoveCmdReq"); } }
        //public IOStruct VMoveDoneAck { get { return GetVisionIO("MoveDoneAck"); } }
        //public IOStruct VCalEndReq { get { return GetVisionIO("CalEndReq"); } }
        public IOStruct VOpCall { get { return GetVisionIO("OpCall"); } }
        public IOStruct VErrorState { get { return GetVisionIO("ErrorState"); } }
        //public IOStruct VReserve16 { get { return GetVisionIO("Reserve#16"); } }
        public IOStruct VAlarmCode { get { return GetVisionIO("AlarmCode"); } }
        //public IOStruct VReserve18 { get { return GetVisionIO("Reserve#18"); } }
        //public IOStruct VReserve19 { get { return GetVisionIO("Reserve#19"); } }
        public IOStruct VDummyImageID { get { return GetVisionIO("DummyImageID"); } }
        #endregion

        #region PLC IOs
        public IOStruct PReset { get { return GetPLCIO("Reset"); } }
        public IOStruct PStartReq { get { return GetPLCIO("StartReq"); } }
        public IOStruct PCompAck { get { return GetPLCIO("CompAck"); } }
        public IOStruct PType { get { return GetPLCIO("Type"); } }
        public IOStruct PLightOff { get { return GetPLCIO("LightOff"); } }
        public IOStruct PLightOn { get { return GetPLCIO("LightOn"); } }
        public IOStruct PGrabReq1 { get { return GetPLCIO("GrabReq#1"); } }
        public IOStruct PGrabReq2 { get { return GetPLCIO("GrabReq#2"); } }
        public IOStruct PGrabReq3 { get { return GetPLCIO("GrabReq#3"); } }
        public IOStruct PGrabReq4 { get { return GetPLCIO("GrabReq#4"); } }
        //public IOStruct PCalStartAck { get { return GetPLCIO("CalStartAck"); } }
        //public IOStruct PMoveCmdAck { get { return GetPLCIO("MoveCmdAck"); } }
        //public IOStruct PMoveDone { get { return GetPLCIO("MoveDone"); } }
        //public IOStruct PCalEndAck { get { return GetPLCIO("CalEndAck"); } }
        //public IOStruct Reserve14 { get { return GetPLCIO("Reserve#14"); } }
        public IOStruct PAbort { get { return GetPLCIO("Abort"); } }
        //public IOStruct Reserve16 { get { return GetPLCIO("Reserve#16"); } }
        public IOStruct PUnitNo { get { return GetPLCIO("UnitNo"); } }
        public IOStruct POptionNo { get { return GetPLCIO("OptionNo"); } }
        //public IOStruct Reserve19 { get { return GetPLCIO("Reserve#19"); } }
        public IOStruct PSourceID { get { return GetPLCIO("SourceID"); } }
        public IOStruct PTargetID { get { return GetPLCIO("TargetID"); } }
        public IOStruct PIsDigitizer { get { return GetPLCIO("IsDigitizer"); } }
        public IOStruct PInspectionResultPass { get { return GetPLCIO("InspectionResultPass"); } }

        #endregion

        #region [Fields]

        #region  Selected Caldata
        private string mP1_CalData;
        private string mP2_CalData;
        private string mH1_CalData;
        #endregion

        #region  Selected Display
        private string mP1_Display;
        private string mP2_Display;
        private string mH1_Display;
        private bool mUseLCheckFunc;
        #endregion

        #region  Inspection Tool
        CogDistancePointLineTool mCalcP2LineTool = new CogDistancePointLineTool();
        CogIntersectLineCircleTool mIntersectLToC = new CogIntersectLineCircleTool();
        #endregion

        #region 2020.05.09 inspection chart 
        private string dspChart;
        /// 2020.12.17 hdy multi grid 설정용,,
        private string multiGridName;
        private string multiGridObj;
        #endregion

        #region etc
        private bool useAutoCapture = true;
        private CalcType mCalcType;
        private ThetaDirection mThetaDirection;
        private AlignMotionType mAlignMotionType = AlignMotionType.XYT;
        private ProcessType mProcessType = ProcessType.INSPECT;
        CogColorConstants mErrColor = CogColorConstants.Orange;
        XY mErrOffset = new XY(5, 100);
        private HoleCalcType mHoleType = HoleCalcType.PanelToTape;
        private LineCalcType mMarkCalcType = LineCalcType.P2Line;
        private int calcOffsetNum = 5;
        private int calcOffsetRange = 200;
        private CalcAngle3P angleType = CalcAngle3P.Use2P;
        private OnOff useAutoLengthSet = OnOff.Off;


        [NonSerialized]
        bool mbAlign2P = true;
        [NonSerialized]
        bool mbAlign3P = true;

        [field: NonSerialized]
        private Cognex.VisionPro.CogRecordDisplay cogDsL;
        [field: NonSerialized]
        private Cognex.VisionPro.CogRecordDisplay cogDsR;
        [field: NonSerialized]
        private Cognex.VisionPro.CogRecordDisplay cogDsH;
        [field: NonSerialized]
        private double histoValue_L = 0;
        [field: NonSerialized]
        private double histoValue_R = 0;
        [field: NonSerialized]
        private double histoValue_H = 0;
        [field: NonSerialized]
        private bool judgeHisto_L = false;
        [field: NonSerialized]
        private bool judgeHisto_R = false;

        private double specValue_L = 100;
        private double specValue_R = 100;
        private bool isLessThan_L = false;
        private bool isLessThan_R = false;

        #endregion

        #region Align Result Data
        [NonSerialized]
        private XY mP1Moving = new XY();
        [NonSerialized]
        private XY mP2Moving = new XY();
        [NonSerialized]
        private XY mH1Moving = new XY();
        [NonSerialized]
        private XYT mRevAlign = new XYT();
        [NonSerialized]
        private XYT mRevUnload = new XYT();
        [NonSerialized]
        private double mLengthTar = 0.0;
        [NonSerialized]
        private double mLengthObj = 0.0;
        [NonSerialized]
        private bool lastJudgement = true;
        [NonSerialized]
        XYXY mInspResult = new XYXY();
        [NonSerialized]
        XYXY mInspResult_APC = new XYXY();
        [NonSerialized]
        XYXY mInspResultOrg = new XYXY();

        [NonSerialized]
        XY mObjToTapeXY = new XY();
        [NonSerialized]
        XY mObjToTapeXYOrg = new XY();
        /// <summary>
        /// 21.05.28 hdy edge inspection 시, 부호 판단을 위해 추가
        /// </summary>
        [NonSerialized]
        XY mObjToTapeXY_APC = new XY();
        [NonSerialized]
        double mObjToTapeD = 0.0;
        [NonSerialized]
        double mObjToTapeDOrg = 0.0;
        [NonSerialized]
        double[] mCircleToCircle = new double[4];
        [NonSerialized]
        string mCircleToCircle_result = string.Empty;

        [NonSerialized]
        double panelHoleMarkScore = 0.0;
        [NonSerialized]
        double windowHoleMarkScore = 0.0;
        //[NonSerialized]
        //double holeDSpec = 0.0;

        [NonSerialized]
        double holeXTor = 0.0;
        [NonSerialized]
        double holeYTor = 0.0;
        [NonSerialized]
        double holeDTor = 0.0;
        //[NonSerialized]
        //double dl_holeDTor = 0.0;

        [NonSerialized]
        XY mRobot_Tar_P1 = new XY();
        [NonSerialized]
        XY mRobot_Tar_P2 = new XY();
        [NonSerialized]
        XY mRobot_Tar_H1 = new XY();
        [NonSerialized]
        XY mRobot_Obj_P1 = new XY();
        [NonSerialized]
        XY mRobot_Obj_P2 = new XY();
        [NonSerialized]
        XY mRobot_Obj_H1 = new XY();

        [NonSerialized]
        XY mRobot_Panel_H = new XY();
        [NonSerialized]
        XY mRobot_Tape_H = new XY();
        [NonSerialized]
        XY mRobot_Window_H = new XY();

        [NonSerialized]
        XYXY mMarkScale = new XYXY();
        [NonSerialized]
        XYXY mMarkSpec = new XYXY();
        [NonSerialized]
        XYXY mMarkTor = new XYXY();

        [NonSerialized]
        XY mHoleScale = new XY();
        [NonSerialized]
        XY mHoleSpec = new XY();
        [NonSerialized]
        XY mHoleTor = new XY();

        [NonSerialized]
        XYXY mMarkDiff = new XYXY();
        [NonSerialized]
        XY mHoleDiff = new XY();
        [NonSerialized]
        double mHoleDiff_R = 0.0;
        [NonSerialized]
        Queue<double> mQDiffMarkLx = new Queue<double>();
        [NonSerialized]
        Queue<double> mQDiffMarkLy = new Queue<double>();
        [NonSerialized]
        Queue<double> mQDiffMarkRx = new Queue<double>();
        [NonSerialized]
        Queue<double> mQDiffMarkRy = new Queue<double>();
        [NonSerialized]
        Queue<double> mQDiffHoleX = new Queue<double>();
        [NonSerialized]
        Queue<double> mQDiffHoleY = new Queue<double>();
        [NonSerialized]
        XYXY mMarkOffset = new XYXY();
        [NonSerialized]
        XY mHoleOffset = new XY();
        [NonSerialized]
        double mThetaRst = 0.0;

        [NonSerialized]
        MarkRstInfo mTar_Mark1 = new MarkRstInfo();
        [NonSerialized]
        MarkRstInfo mTar_Mark2 = new MarkRstInfo();
        [NonSerialized]
        MarkRstInfo mTar_Mark3 = new MarkRstInfo();
        [NonSerialized]
        MarkRstInfo mObj_Mark1 = new MarkRstInfo();
        [NonSerialized]
        MarkRstInfo mObj_Mark2 = new MarkRstInfo();
        [NonSerialized]
        MarkRstInfo mObj_Mark3 = new MarkRstInfo();
        #endregion

        #region Manual Confirm Option
        bool useManualConfirm;
        bool useOriginImage;
        bool useOverlayImage;
        #endregion

        #region Inspection Type
        InspType mInspType = InspType.Hole;
        #endregion

        #endregion

        #region [properties]
        [Browsable(true)]
        [TypeConverter(typeof(ChartListConverter))]
        public string DspChart
        {
            get { return dspChart; }
            set { if (dspChart == value) return; dspChart = value; this.OnPropertyChanged(nameof(DspChart)); }
        }
        public InspectionChartObject ChartObject
        {
            get { return SystemObject_Display.GetObject(DspChart) as InspectionChartObject; }
        }

        #region MultiGrid 설정 부분

        public string MultiGridName
        {
            get { return multiGridName; }
            set 
            {
                if (multiGridName == value) return;

                string preName = multiGridName;

                multiGridName = value; 
                this.OnPropertyChanged(nameof(MultiGridName));

                if (MultiGridViewObject != null)
                    MultiGridViewObject.SetTabsHeader(preName, this.multiGridName);
            }
        }

        [Browsable(true)]
        [TypeConverter(typeof(MultiGridViewListConverter))]
        public string MultiGridObj
        {
            get { return multiGridObj; }
            set 
            {
                if (multiGridObj == value) return;

                if (MultiGridViewObject != null)
                    MultiGridViewObject.RemoveItemEvent(this.multiGridName);

                multiGridObj = value;
                this.OnPropertyChanged(nameof(MultiGridObj));

                if (MultiGridViewObject != null)
                    MultiGridViewObject.AddItemEvent(this.multiGridName);
            }
        }

        public MultiGridViewDisplayObject MultiGridViewObject
        {
            get { return SystemObject_Display.GetObject(MultiGridObj) as MultiGridViewDisplayObject; }
        }
        #endregion

        #region etc
        public CalcType CalcType
        {
            get { return mCalcType; }
            set { if (mCalcType == value) return; mCalcType = value; this.OnPropertyChanged(nameof(CalcType)); }
        }
        public ThetaDirection ThetaDirection
        {
            get { return mThetaDirection; }
            set { if (mThetaDirection == value) return; mThetaDirection = value; this.OnPropertyChanged(nameof(ThetaDirection)); }
        }
        public AlignMotionType AlignMotionType
        {
            get { return mAlignMotionType; }
            set { if (mAlignMotionType == value) return; mAlignMotionType = value; this.OnPropertyChanged(nameof(AlignMotionType)); }
        }
        public HoleCalcType HoleType
        {
            get { return mHoleType; }
            set { if (mHoleType == value) return; mHoleType = value; this.OnPropertyChanged(nameof(HoleType)); }
        }
        public LineCalcType LineEdgeType
        {
            get { return mMarkCalcType; }
            set { if (mMarkCalcType == value) return; mMarkCalcType = value; this.OnPropertyChanged(nameof(LineEdgeType)); }
        }
        public bool LCheckUse
        {
            get 
            {
                mUseLCheckFunc = true;  // 2021.04.05 jyh 고객님께서 무주건 L-Check를 사용하고 싶다고 하신다.
                return mUseLCheckFunc; 
            }
            set
            {
                if (mUseLCheckFunc == value) return;
                mUseLCheckFunc = value;
                //(Options as Algo_C_PanelAttachModelOptions).UseLCheck.Value = mUseLCheckFunc ? OnOff.On : OnOff.Off;
                this.OnPropertyChanged(nameof(LCheckUse));
            }
        }
        public InspType InspType
        {
            get { return mInspType; }
            set { if (mInspType == value) return; mInspType = value; this.OnPropertyChanged(nameof(InspType)); }
        }
        public bool UseAutoCapture
        {
            get { return useAutoCapture; }
            set { Set<bool>(ref useAutoCapture, value, nameof(UseAutoCapture)); }
        }

        public ProcessType ProcessType
        {
            get { return mProcessType; }
            set
            {
                if (mProcessType == value) return;
                mProcessType = value;

                ModelParams.Clear();
                switch (mProcessType)
                {
                    case ProcessType.PRE:
                        Align2P = true; Align3P = false;
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                                ModelParams.Add(model, new Algo_C_PanelAttachModelParams());
                        }
                        break;
                    case ProcessType.TAPE:
                    case ProcessType.PANEL:
                    case ProcessType.MAIN:
                        Align2P = false; Align3P = true;
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                                ModelParams.Add(model, new Algo_C_PanelAttachModelParams());
                        }
                        break;
                    case ProcessType.INSPECT:
                        Align2P = false; Align3P = false;
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                                ModelParams.Add(model, new Algo_C_PanelAttachModelParamsIns());
                        }
                        break;
                    case ProcessType.H2H:
                        Align2P = false; Align3P = false;
                        foreach (var model in SystemModel.GetModels())
                        {
                            if (!ModelParams.ContainsKey(model))
                                ModelParams.Add(model, new Algo_C_PanelAttachModelParamsH2H());
                        }
                        break;
                }
                CurParams = ModelParams[SystemModel.GetCurModel()];
                //ActionObj.SetModelParams(this);

                this.OnPropertyChanged(nameof(ProcessType));
            }
        }
        public bool Align2P
        {
            get { return mbAlign2P; }
            set { if (mbAlign2P == value) return; mbAlign2P = value; this.OnPropertyChanged(nameof(Align2P)); }
        }
        public bool Align3P
        {
            get { return mbAlign3P; }
            set { if (mbAlign3P == value) return; mbAlign3P = value; this.OnPropertyChanged(nameof(Align3P)); }
        }
        public int CalcOffsetNum
        {
            get { return calcOffsetNum; }
            set { Set<int>(ref calcOffsetNum, value, nameof(CalcOffsetNum)); }
            //set { if (calcOffsetNum == value) return; calcOffsetNum = value; this.OnPropertyChanged(nameof(CalcOffsetNum)); }
        }
        public int CalcOffsetRange
        {
            get { return calcOffsetRange; }
            set { if (calcOffsetRange == value) return; calcOffsetRange = value; this.OnPropertyChanged(nameof(CalcOffsetRange)); }
        }
        public CalcAngle3P AngleType
        {
            get { return angleType; }
            set { if (angleType == value) return; angleType = value; this.OnPropertyChanged(nameof(AngleType)); }
        }
        public OnOff UseAutoLengthSet
        {
            get { return useAutoLengthSet; }
            set { if (useAutoLengthSet == value) return; useAutoLengthSet = value; this.OnPropertyChanged(nameof(UseAutoLengthSet)); }
        }

        public Cognex.VisionPro.CogRecordDisplay CogDsL
        {
            get { return cogDsL; }
            set { cogDsL = value; this.OnPropertyChanged(nameof(CogDsL)); }
        }
        public Cognex.VisionPro.CogRecordDisplay CogDsR
        {
            get { return cogDsR; }
            set { cogDsR = value; this.OnPropertyChanged(nameof(CogDsR)); }
        }
        public Cognex.VisionPro.CogRecordDisplay CogDsH
        {
            get { return cogDsH; }
            set { cogDsH = value; this.OnPropertyChanged(nameof(CogDsH)); }
        }



        public double HistoValue_L
        {
            get { return histoValue_L; }
            set { if (histoValue_L == value) return; histoValue_L = value; this.OnPropertyChanged(nameof(HistoValue_L)); }
        }
        public double HistoValue_R
        {
            get { return histoValue_R; }
            set { if (histoValue_R == value) return; histoValue_R = value; this.OnPropertyChanged(nameof(HistoValue_R)); }
        }
        public double HistoValue_H
        {
            get { return histoValue_H; }
            set { if (histoValue_H == value) return; histoValue_H = value; this.OnPropertyChanged(nameof(HistoValue_H)); }
        }
        public bool JudgeHisto_L
        {
            get { return judgeHisto_L; }
            set { if (judgeHisto_L == value) return; judgeHisto_L = value; this.OnPropertyChanged(nameof(JudgeHisto_L)); }
        }
        public bool JudgeHisto_R
        {
            get { return judgeHisto_R; }
            set { if (judgeHisto_R == value) return; judgeHisto_R = value; this.OnPropertyChanged(nameof(JudgeHisto_R)); }
        }

        public double SpecValue_L
        {
            get { return specValue_L; }
            set { if (specValue_L == value) return; specValue_L = value; this.OnPropertyChanged(nameof(SpecValue_L)); }
        }
        public double SpecValue_R
        {
            get { return specValue_R; }
            set { if (specValue_R == value) return; specValue_R = value; this.OnPropertyChanged(nameof(SpecValue_R)); }
        }
        public bool IsLessThan_L
        {
            get { return isLessThan_L; }
            set { if (isLessThan_L == value) return; isLessThan_L = value; this.OnPropertyChanged(nameof(IsLessThan_L)); }
        }
        public bool IsLessThan_R
        {
            get { return isLessThan_R; }
            set { if (isLessThan_R == value) return; isLessThan_R = value; this.OnPropertyChanged(nameof(IsLessThan_R)); }
        }

        #endregion

        #region Align관련 Data
        public XYT RevAlign { get { return mRevAlign; } }
        public XYT RevUnload { get { return mRevUnload; } }
        public bool LastJudgement { get { return lastJudgement; } }
        public XYXY InspResult { get { return mInspResultOrg; } }
        public XY ObjToTapeDist { get { return mObjToTapeXYOrg; } }
        public double LengthTar { get { return mLengthTar; } }
        public double LengthObj { get { return mLengthObj; } }
        #endregion

        #region CalData
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P1_CalData
        {
            get { return mP1_CalData; }
            set { if (mP1_CalData == value) return; mP1_CalData = value; this.OnPropertyChanged(nameof(P1_CalData)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string P2_CalData
        {
            get { return mP2_CalData; }
            set { if (mP2_CalData == value) return; mP2_CalData = value; this.OnPropertyChanged(nameof(P2_CalData)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(CalDataListConverter))]
        public string H1_CalData
        {
            get { return mH1_CalData; }
            set { if (mH1_CalData == value) return; mH1_CalData = value; this.OnPropertyChanged(nameof(H1_CalData)); }
        }
        public CalDataObject P1_CalDataObj
        {
            get { return SystemObject_Common.GetObject(mP1_CalData) as CalDataObject; }
        }
        public CalDataObject P2_CalDataObj
        {
            get { return SystemObject_Common.GetObject(mP2_CalData) as CalDataObject; }
        }
        public CalDataObject H1_CalDataObj
        {
            get { return SystemObject_Common.GetObject(mH1_CalData) as CalDataObject; }
        }
        #endregion

        #region Display
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P1_Display
        {
            get { return mP1_Display; }
            set { if (mP1_Display == value) return; mP1_Display = value; this.OnPropertyChanged(nameof(P1_Display)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string P2_Display
        {
            get { return mP2_Display; }
            set { if (mP2_Display == value) return; mP2_Display = value; this.OnPropertyChanged(nameof(P2_Display)); }
        }
        [Browsable(true)]
        [TypeConverter(typeof(DisplayListConverter))]
        public string H1_Display
        {
            get { return mH1_Display; }
            set { if (mH1_Display == value) return; mH1_Display = value; this.OnPropertyChanged(nameof(H1_Display)); }
        }
        public CogDisplayObject P1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(mP1_Display) as CogDisplayObject; }
        }
        public CogDisplayObject P2_DisplayObj
        {
            get { return SystemObject_Display.GetObject(mP2_Display) as CogDisplayObject; }
        }
        public CogDisplayObject H1_DisplayObj
        {
            get { return SystemObject_Display.GetObject(mH1_Display) as CogDisplayObject; }
        }
        #endregion

        #region Manual Confirm Option
        public bool UseManualConfirm
        {
            get { return useManualConfirm; }
            set { Set<bool>(ref useManualConfirm, value, nameof(UseManualConfirm)); }
        }
        public bool UseOriginImage
        {
            get { return useOriginImage; }
            set { Set<bool>(ref useOriginImage, value, nameof(UseOriginImage)); }
        }
        public bool UseOverlayImage
        {
            get { return useOverlayImage; }
            set { Set<bool>(ref useOverlayImage, value, nameof(UseOverlayImage)); }
        }
        #endregion

        #endregion

        #region[Construct]
        public Algo_C_PanelAttachObject()
            : base()
        {
            List<string> lst = SystemObject_Common.GetEachObjectName(typeof(MitsubishiPLCObject));

            foreach (var model in SystemModel.GetModels())
            {
                if (!ModelParams.ContainsKey(model))
                    ModelParams.Add(model, new Algo_C_PanelAttachModelParams());
            }
            CurParams = ModelParams[SystemModel.GetCurModel()];
        }
        #endregion

        #region [override methode]
        public override bool Run() { return AlignCalc(); }
        public override void ObjectInitialize() { base.ObjectInitialize(); }
        public override void DefaultIOSet() { base.DefaultIOSet(); }
        public override void Dispose() { base.Dispose(); }

        /// <summary>
        /// 2020.05.29 hdy  시간이 많이 걸려서 필요한 것만 읽어온다.
        /// </summary>
        public override void AssignPLCData()
        {
            var commObj = CommodObject;
            var IOs = new List<IOStruct>();

            // offset data 확인
            IOs.Add(PlcValues["Offset#1"]);
            IOs.Add(PlcValues["Offset#2"]);
            IOs.Add(PlcValues["Offset#3"]);
            IOs.Add(PlcValues["Offset#4"]);
            // c-panel 用
            if (PlcValues.ContainsKey("Offset#5")) IOs.Add(PlcValues["Offset#5"]);
            if (PlcValues.ContainsKey("Offset#6")) IOs.Add(PlcValues["Offset#6"]);
            // current position 확인
            IOs.Add(PlcValues["CurPos#1"]);
            IOs.Add(PlcValues["CurPos#2"]);
            IOs.Add(PlcValues["CurPos#3"]);
            IOs.Add(PlcValues["CurPos#4"]);
            // cam pos 확인
            IOs.Add(PlcValues["CamPosX#1"]);
            IOs.Add(PlcValues["CamPosX#2"]);
            IOs.Add(PlcValues["CamPosY"]);
            // c-panel 用
            if (PlcValues.ContainsKey("RobotDirection")) IOs.Add(PlcValues["RobotDirection"]);
            if (PlcValues.ContainsKey("PickupLift")) IOs.Add(PlcValues["PickupLift"]);

            commObj.UpdatePlcValues(IOs);

            CvtPLCIO = new StdPLCTable();

            CvtPLCIO.Offset1 = (double)PlcValues["Offset#1"].CurValue;
            CvtPLCIO.Offset2 = (double)PlcValues["Offset#2"].CurValue;
            CvtPLCIO.Offset3 = (double)PlcValues["Offset#3"].CurValue;
            CvtPLCIO.Offset4 = (double)PlcValues["Offset#4"].CurValue;

            CvtPLCIO.CurPos1 = (double)PlcValues["CurPos#1"].CurValue;
            CvtPLCIO.CurPos2 = (double)PlcValues["CurPos#2"].CurValue;
            CvtPLCIO.CurPos3 = (double)PlcValues["CurPos#3"].CurValue;
            CvtPLCIO.CurPos4 = (double)PlcValues["CurPos#4"].CurValue;

            CvtPLCIO.CamPosX1 = (double)PlcValues["CamPosX#1"].CurValue;
            CvtPLCIO.CamPosX2 = (double)PlcValues["CamPosX#2"].CurValue;
            CvtPLCIO.CamPosY = (double)PlcValues["CamPosY"].CurValue;
        }

        #endregion

        private CogRectangle areaL;
        private CogRectangle areaR;
        private CogRectangle areaH;

        public CogRectangle AreaL
        {
            get
            {
                if (areaL == null)
                {
                    areaL = new CogRectangle();
                    AreaL.X = 0;
                    AreaL.Y = 0;
                    AreaL.Width = 500;
                    AreaL.Height = 200;
                }

                return areaL;
            }
            set { if (areaL == value) return; areaL = value; this.OnPropertyChanged(nameof(AreaL)); }
        }
        public CogRectangle AreaR
        {
            get
            {
                if(areaR == null)
                {
                    areaR = new CogRectangle();
                    areaR.X = 0;
                    areaR.Y = 0;
                    areaR.Width = 1000;
                    areaR.Height = 200;
                }
                return areaR;
            }
            set { if (areaR == value) return; areaR = value; this.OnPropertyChanged(nameof(AreaR)); }
        }
        public CogRectangle AreaH
        {
            get
            {
                if (areaH == null)
                {
                    areaH = new CogRectangle();
                    areaH.X = 0;
                    areaH.Y = 0;
                    areaH.Width = 500;
                    areaH.Height = 200;
                }

                return areaH;
            }
            set { if (areaH == value) return; areaH = value; this.OnPropertyChanged(nameof(AreaH)); }
        }


        #region [Private Method]
        private bool AlignCalc()
        {
            switch (mProcessType)
            {
                case ProcessType.PRE:
                    lastJudgement = AlignCalc2P();
                    break;
                case ProcessType.TAPE:
                case ProcessType.PANEL:
                case ProcessType.MAIN:
                    lastJudgement = AlignCalc3P();
                    break;
                case ProcessType.INSPECT:
                    lastJudgement = Inspection();
                    break;
                case ProcessType.H2H:
                    lastJudgement = H2H();
                    break;
            }
            return errorCode == 0 ? true : false; ;
        }

        /// <summary>
        /// cam or stage moving 량을 회전중심에 반영
        /// </summary>
        /// <param name="calObj"></param>
        /// <param name="camX"></param>
        /// <param name="camY"></param>
        /// <param name="stageX"></param>
        /// <param name="stageY"></param>
        /// <returns></returns>
        public XY GetRotateCenter(CalDataObject calObj, XYDirection camX, XYDirection camY, XYDirection stageX, XYDirection stageY)
        {
            string model = SystemModel.GetCurModel();

            double dMoveCamX = (CvtPLCIO.CamPosX1 + calObj.GetCameraPosition(model).X) * (int)camX;
            double dMoveCamY = (CvtPLCIO.CamPosY + calObj.GetCameraPosition(model).Y) * (int)camY;

            double dMoveStageX = (CvtPLCIO.CurPos1 + calObj.GetStagePosition(model).X) * (int)stageX;
            double dMoveStageY = (CvtPLCIO.CurPos2 + calObj.GetStagePosition(model).Y) * (int)stageY;

            double dCenterX = calObj.GetRotateCenter(model).X + dMoveCamX + dMoveStageX;
            double dCenterY = calObj.GetRotateCenter(model).Y + dMoveCamY + dMoveStageY;

            return new XY(dCenterX, dCenterY);
        }

        private bool IsTargetLeftNG, IsTargetRightNG, IsTargetHoleNG;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rst"></param>
        /// <param name="spec"></param>
        /// <param name="tor"></param>
        /// <returns></returns>
        protected bool ConfirmResult2(XYXY rst, XYXY spec, XYXY tor)
        {
            //if (spec.Lx == 0.0 || spec.Ly == 0.0 || spec.Rx == 0.0 || spec.Ry == 0.0) return true;
            if (tor.Lx == 0.0 || tor.Ly == 0.0 || tor.Rx == 0.0 || tor.Ry == 0.0) return true;

            IsTargetLeftNG = !ConfirmSpecMinMax(rst.Lx, spec.Lx + tor.Lx * (-1), spec.Lx + tor.Lx) || !ConfirmSpecMinMax(rst.Ly, spec.Ly + tor.Ly * (-1), spec.Ly + tor.Ly);
            IsTargetRightNG = !ConfirmSpecMinMax(rst.Rx, spec.Rx + tor.Rx * (-1), spec.Rx + tor.Rx) || !ConfirmSpecMinMax(rst.Ry, spec.Ry + tor.Ry * (-1), spec.Ry + tor.Ry);

            if(IsTargetLeftNG || IsTargetRightNG)
            {
                errorCode = AlgoActionBase.Err_Inspection_Spec_Over;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Inspection_Spec_Over");
                return false;
            }

            return true;
        }
        protected bool ConfirmResult2(double rst, double spec, double tor)
        {
            if (tor == 0.0) return true;

            if (!ConfirmSpecMinMax(rst, spec + tor * (-1), spec + tor))
            {
                IsTargetLeftNG = IsTargetRightNG = true;
                errorCode = AlgoActionBase.Err_Inspection_Spec_Over;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Inspection_Spec_Over");
                return false;
            }
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rst"></param>
        /// <param name="spec"></param>
        /// <param name="tor"></param>
        /// <returns></returns>
        protected bool ConfirmResultHole(XY rst, XY spec, XY tor)
        {
            if (tor.X == 0.0 && tor.Y == 0.0) return true;

            IsTargetHoleNG = !ConfirmSpecRange(rst.X, spec.X, tor.X) || !ConfirmSpecRange(rst.Y, spec.Y, tor.Y);
            if (IsTargetHoleNG)
            {
                errorCode = AlgoActionBase.Err_Inspection_Spec_Over;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Inspection_Spec_Over");
                return false;
            }
            return true;
        }
        protected bool ConfirmResultHole(double rst, double spec, double tor)
        {
            if (tor == 0.0) return true;
            IsTargetHoleNG = !ConfirmSpecRange(rst, spec, tor);

            if (IsTargetHoleNG)
            {
                errorCode = AlgoActionBase.Err_Inspection_Spec_Over;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Inspection_Spec_Over");
                return false;
            }
            return true;
        }

        protected bool ConfirmResultHole_Panel(double rst, double spec, double tor)
        {
            if (tor == 0.0) return true;

            if (!ConfirmSpecRange(rst, spec, tor))
                return false;

            return true;
        }

        private XY GetApplyRev(CalDataObject cal, MatchingRstData mark, XYT rev)
        {
            var model = SystemModel.GetCurModel();
            var rc = cal.GetRotateCenter(model);
            var rp = cal.GetV2R(model, mark.OutputXYT.ToXY());

            double r = rev.T * PI / 180;
            var a = Math.Cos(r) * (rev.X + rc.X);
            var b = -Math.Sin(r) * (rev.Y + rc.Y);

            double x = rev.X + Math.Cos(r) * (rp.X + rc.X) - Math.Sin(r) * (rp.Y + rc.Y) - rc.X;
            double y = rev.Y + Math.Sin(r) * (rp.X + rc.X) + Math.Cos(r) * (rp.Y + rc.Y) - rc.Y;

            return cal.GetR2V(model, new XY(x, y)).ToXY();
        }

        protected bool ConfirmResult(XYT revAlign, XYT limit)
        {
            if (!ConfirmSpecMinMax(revAlign.X, limit.X * (-1), limit.X) ||
                !ConfirmSpecMinMax(revAlign.Y, limit.Y * (-1), limit.Y) ||
                !ConfirmSpecMinMax(revAlign.T, limit.T * (-1), limit.T))
            {
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                return false;
            }
            else
                return true;
        }
        public void WriteVisionIO(object rev1, object rev2, string ID)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            switch (mAlignMotionType)
            {
                case AlignMotionType.XY:
                case AlignMotionType.XYT:
                    VisionValues["Rev#1_X"].NextValue = (double)(rev1 as XYT).X; IOs.Add(VisionValues["Rev#1_X"]);
                    VisionValues["Rev#1_Y"].NextValue = (double)(rev1 as XYT).Y; IOs.Add(VisionValues["Rev#1_Y"]);
                    VisionValues["Rev#1_T"].NextValue = (double)(rev1 as XYT).T; IOs.Add(VisionValues["Rev#1_T"]);
                    VisionValues["Rev#2_X"].NextValue = (double)(rev2 as XYT).X; IOs.Add(VisionValues["Rev#2_X"]);
                    VisionValues["Rev#2_Y"].NextValue = (double)(rev2 as XYT).Y; IOs.Add(VisionValues["Rev#2_Y"]);
                    VisionValues["Rev#2_T"].NextValue = (double)(rev2 as XYT).T; IOs.Add(VisionValues["Rev#2_T"]);

                    XYT tar1 = CvtPLCIO.TeachPos1XYT + (rev1 as XYT);
                    XYT tar2 = CvtPLCIO.TeachPos2XYT + (rev2 as XYT);
                    VisionValues["Tar#1_Pos#1"].NextValue = (double)tar1.X; IOs.Add(VisionValues["Tar#1_Pos#1"]);
                    VisionValues["Tar#1_Pos#2"].NextValue = (double)tar1.Y; IOs.Add(VisionValues["Tar#1_Pos#2"]);
                    VisionValues["Tar#1_Pos#3"].NextValue = (double)tar1.T; IOs.Add(VisionValues["Tar#1_Pos#3"]);
                    VisionValues["Tar#1_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#1_Pos#4"]);
                    VisionValues["Tar#2_Pos#1"].NextValue = (double)tar2.X; IOs.Add(VisionValues["Tar#2_Pos#1"]);
                    VisionValues["Tar#2_Pos#2"].NextValue = (double)tar2.Y; IOs.Add(VisionValues["Tar#2_Pos#2"]);
                    VisionValues["Tar#2_Pos#3"].NextValue = (double)tar2.T; IOs.Add(VisionValues["Tar#2_Pos#3"]);
                    VisionValues["Tar#2_Pos#4"].NextValue = (double)0.0; IOs.Add(VisionValues["Tar#2_Pos#4"]);
                    break;
                case AlignMotionType.UVW:
                    break;
                case AlignMotionType.UVRW:
                    break;
            }

            //SetMarkScore(IOs);

            CommodObject.SetVisionValues(IOs);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rst"></param>
        /// <param name="pt"></param>
        void SetMarkInfo(ref MarkRstInfo rst, IPointResult pt)
        {
            if (rst == null) rst = new MarkRstInfo();
            if (pt is LineCrossRstData) return;

            rst.Score = pt.Score;
            rst.MatchingSpec = pt.MatchingSpec;
            rst.SuccessIndex = pt.SuccessIndex;
        }

        public void WriteVisionIO(object _rst)
        {
            // 모션타입별 리비젼,타겟값 스위치하여 써줘야함..
            var IOs = new List<IOStruct>();

            if (_rst is Algo_C_PanelAttachResult2P)
            {
                Algo_C_PanelAttachResult2P algoRst = _rst as Algo_C_PanelAttachResult2P;
                VisionValues["Rev#1_X"].NextValue = (double)algoRst.Rev1X; IOs.Add(VisionValues["Rev#1_X"]);
                VisionValues["Rev#1_Y"].NextValue = (double)algoRst.Rev1Y; IOs.Add(VisionValues["Rev#1_Y"]);
                VisionValues["Rev#1_T"].NextValue = (double)algoRst.Rev1T; IOs.Add(VisionValues["Rev#1_T"]);

                //VisionValues["Rev#2_X"].NextValue = (double)algoRst.Rev2X; IOs.Add(VisionValues["Rev#2_X"]);
                //VisionValues["Rev#2_Y"].NextValue = (double)algoRst.Rev2Y; IOs.Add(VisionValues["Rev#2_Y"]);
                //VisionValues["Rev#2_T"].NextValue = (double)algoRst.Rev2T; IOs.Add(VisionValues["Rev#2_T"]);
                // mark score write
                VisionValues["Obj_P1_Mark_Score"].NextValue = (double)mObj_Mark1.Score; IOs.Add(VisionValues["Obj_P1_Mark_Score"]);
                VisionValues["Obj_P2_Mark_Score"].NextValue = (double)mObj_Mark2.Score; IOs.Add(VisionValues["Obj_P2_Mark_Score"]);
            }
            else if (_rst is Algo_C_PanelAttachResult3P)
            {
                Algo_C_PanelAttachResult3P algoRst = _rst as Algo_C_PanelAttachResult3P;
                VisionValues["Rev#1_X"].NextValue = (double)algoRst.Rev1X; IOs.Add(VisionValues["Rev#1_X"]);
                VisionValues["Rev#1_Y"].NextValue = (double)algoRst.Rev1Y; IOs.Add(VisionValues["Rev#1_Y"]);
                VisionValues["Rev#1_T"].NextValue = (double)algoRst.Rev1T; IOs.Add(VisionValues["Rev#1_T"]);

                // Tape 쪽은 랜덤 ID를 써준다.
                VisionValues["ImageID"].NextValue = algoRst.ID; IOs.Add(VisionValues["ImageID"]);

                //VisionValues["Rev#2_X"].NextValue = (double)algoRst.Rev2X; IOs.Add(VisionValues["Rev#2_X"]);
                //VisionValues["Rev#2_Y"].NextValue = (double)algoRst.Rev2Y; IOs.Add(VisionValues["Rev#2_Y"]);
                //VisionValues["Rev#2_T"].NextValue = (double)algoRst.Rev2T; IOs.Add(VisionValues["Rev#2_T"]);

                // mark score write
                VisionValues["Obj_P1_Mark_Score"].NextValue = (double)mObj_Mark1.Score; IOs.Add(VisionValues["Obj_P1_Mark_Score"]);
                VisionValues["Obj_P2_Mark_Score"].NextValue = (double)mObj_Mark2.Score; IOs.Add(VisionValues["Obj_P2_Mark_Score"]);
                VisionValues["Obj_P3_Mark_Score"].NextValue = (double)mObj_Mark3.Score; IOs.Add(VisionValues["Obj_P3_Mark_Score"]);
            }
            else if (_rst is Algo_C_PanelAttachReslutIns)
            {
                Algo_C_PanelAttachReslutIns algoRst = _rst as Algo_C_PanelAttachReslutIns;

                VisionValues["Rev#1_X"].NextValue = (double)algoRst.Rev1X; IOs.Add(VisionValues["Rev#1_X"]);
                VisionValues["Rev#1_Y"].NextValue = (double)algoRst.Rev1Y; IOs.Add(VisionValues["Rev#1_Y"]);
                VisionValues["Rev#1_T"].NextValue = (double)algoRst.Rev1T; IOs.Add(VisionValues["Rev#1_T"]);

                // inspection result write
                VisionValues["MarkDist_X1"].NextValue = (double)algoRst.Lx; IOs.Add(VisionValues["MarkDist_X1"]);
                VisionValues["MarkDist_Y1"].NextValue = (double)algoRst.Ly; IOs.Add(VisionValues["MarkDist_Y1"]);
                VisionValues["MarkDist_X2"].NextValue = (double)algoRst.Rx; IOs.Add(VisionValues["MarkDist_X2"]);
                VisionValues["MarkDist_Y2"].NextValue = (double)algoRst.Ry; IOs.Add(VisionValues["MarkDist_Y2"]);
                VisionValues["HoleDist_X1"].NextValue = (double)algoRst.Hx; IOs.Add(VisionValues["HoleDist_X1"]);
                VisionValues["HoleDist_Y1"].NextValue = (double)algoRst.Hy; IOs.Add(VisionValues["HoleDist_Y1"]);
                VisionValues["HoleDist_Top"].NextValue = (double)algoRst.H_Top; IOs.Add(VisionValues["HoleDist_Top"]);
                VisionValues["HoleDist_Bottom"].NextValue = (double)algoRst.H_Bottom; IOs.Add(VisionValues["HoleDist_Bottom"]);
                VisionValues["HoleDist_Left"].NextValue = (double)algoRst.H_Left; IOs.Add(VisionValues["HoleDist_Left"]);
                VisionValues["HoleDist_Right"].NextValue = (double)algoRst.H_Right; IOs.Add(VisionValues["HoleDist_Right"]);
                VisionValues["HoleDist_D"].NextValue = (double)algoRst.Hd; IOs.Add(VisionValues["HoleDist_D"]);
                // mark score write
                VisionValues["Tar_P1_Mark_Score"].NextValue = (double)mTar_Mark1.Score; IOs.Add(VisionValues["Tar_P1_Mark_Score"]);
                VisionValues["Tar_P2_Mark_Score"].NextValue = (double)mTar_Mark2.Score; IOs.Add(VisionValues["Tar_P2_Mark_Score"]);
                VisionValues["Obj_P1_Mark_Score"].NextValue = (double)mObj_Mark1.Score; IOs.Add(VisionValues["Obj_P1_Mark_Score"]);
                VisionValues["Obj_P2_Mark_Score"].NextValue = (double)mObj_Mark2.Score; IOs.Add(VisionValues["Obj_P2_Mark_Score"]);
				// 예외 처리 할 것..
                VisionValues["MarkDist_X1_APC"].NextValue = (double)algoRst.Lx_APC; IOs.Add(VisionValues["MarkDist_X1_APC"]);
                VisionValues["MarkDist_Y1_APC"].NextValue = (double)algoRst.Ly_APC; IOs.Add(VisionValues["MarkDist_Y1_APC"]);
                VisionValues["MarkDist_X2_APC"].NextValue = (double)algoRst.Rx_APC; IOs.Add(VisionValues["MarkDist_X2_APC"]);
                VisionValues["MarkDist_Y2_APC"].NextValue = (double)algoRst.Ry_APC; IOs.Add(VisionValues["MarkDist_Y2_APC"]);

            }
            else if (_rst is Algo_C_PanelAttachResultH2H)
            {
                Algo_C_PanelAttachResultH2H algoRst = _rst as Algo_C_PanelAttachResultH2H;

                VisionValues["HoleDist_X1"].NextValue = (double)algoRst.Hx; IOs.Add(VisionValues["HoleDist_X1"]);
                VisionValues["HoleDist_Y1"].NextValue = (double)algoRst.Hy; IOs.Add(VisionValues["HoleDist_Y1"]);
                VisionValues["HoleDist_Top"].NextValue = (double)algoRst.H_Top; IOs.Add(VisionValues["HoleDist_Top"]);
                VisionValues["HoleDist_Bottom"].NextValue = (double)algoRst.H_Bottom; IOs.Add(VisionValues["HoleDist_Bottom"]);
                VisionValues["HoleDist_Left"].NextValue = (double)algoRst.H_Left; IOs.Add(VisionValues["HoleDist_Left"]);
                VisionValues["HoleDist_Right"].NextValue = (double)algoRst.H_Right; IOs.Add(VisionValues["HoleDist_Right"]);
                VisionValues["HoleDist_D"].NextValue = (double)algoRst.Hd; IOs.Add(VisionValues["HoleDist_D"]);
                //VisionValues["HoleDist_Result"].NextValue = algoRst.H_Result == "Hole OK" ? 1 : 2; ; IOs.Add(VisionValues["HoleDist_Result"]);
                VisionValues["PanelHole_Mark_Score"].NextValue = (double)algoRst.Panel_H_Score; IOs.Add(VisionValues["PanelHole_Mark_Score"]);
                VisionValues["WindowHole_Mark_Score"].NextValue = (double)algoRst.Window_H_Score; IOs.Add(VisionValues["WindowHole_Mark_Score"]);
                VisionValues["HoleDist_X_Tor"].NextValue = (double)algoRst.Hole_X_Tor; IOs.Add(VisionValues["HoleDist_X_Tor"]);
                VisionValues["HoleDist_Y_Tor"].NextValue = (double)algoRst.Hole_Y_Tor; IOs.Add(VisionValues["HoleDist_Y_Tor"]);
                VisionValues["HoleDist_D_Tor"].NextValue = (double)algoRst.Hole_D_Tor; IOs.Add(VisionValues["HoleDist_D_Tor"]);

                if (VisionValues.ContainsKey("Grey"))
                { VisionValues["Grey"].NextValue = (int)HistoValue_H; IOs.Add(VisionValues["Grey"]); }
            }
            CommodObject.SetVisionValues(IOs);
        }

        #endregion


        public void ImageSave(CogDisplayObject cogDisp, DateTime dateTime, string rst, string strPath, string cellid = "")
        {
            //if (cogDisp == null) return;
            //Task task = Task.Factory.StartNew(() => cogDisp.SaveImage(dateTime, cogDisp.GetCurImage(), rst, strPath, cellid, true));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="errStr"></param>
        void DrawErrDisp(string errStr)
        {
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = mErrColor;
            labelInfo.Offset = new XY(5, 150); // mErrOffset;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.TopLeft;
            labelInfo.Text = string.Format(errStr);

            P1_DisplayObj?.DrawLabel(labelInfo);
            P2_DisplayObj?.DrawLabel(labelInfo);
            H1_DisplayObj?.DrawLabel(labelInfo);
            labelInfo = null;
        }

        void DrawCPNLAttached(CogDisplayObject dspObject, CogRectangle Area, double val, double spec)
        {
            Area.Color = CogColorConstants.Purple;
            dspObject?.CogDs.StaticGraphics.Add(Area, "Area");
            int x = (int)dspObject?.CogDs.Image.Width;
            int y = (int)dspObject?.CogDs.Image.Height;

            string msg = string.Format("Spec : {0:F2}, Value : {1:F2}", spec, val);
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();

            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = new XY(0, y - 100); // mErrOffset;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.BottomLeft;
            labelInfo.Text = string.Format(msg);

            dspObject?.DrawLabel(labelInfo);
            //P2_DisplayObj?.DrawLabel(labelInfo);
            //H1_DisplayObj?.DrawLabel(labelInfo);
            labelInfo = null;
        }


        /// <summary>
        /// 개별로 표시하고 싶을 때,,,
        /// </summary>
        /// <param name="errStr"></param>
        /// <param name="dsp"></param>
        void DrawErrDisp(string errStr, CogDisplayObject dsp)
        {
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();
            labelInfo.UseBackColor = true;
            labelInfo.BackColor = mErrColor;
            labelInfo.Offset = new XY(5, 150); // mErrOffset;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.TopLeft;
            labelInfo.Text = string.Format(errStr);

            dsp?.DrawLabel(labelInfo);
            labelInfo = null;

        }


        int GetImageHeight(CogDisplayObject obj)
        {
            if (obj == null) return -1;
            CogImage8Grey img = obj.GetCurImage() as CogImage8Grey;

            if (img != null) return img.Height;
            else return -1;
        }

        int GetImageWidth(CogDisplayObject obj)
        {
            if (obj == null) return -1;
            CogImage8Grey img = obj.GetCurImage() as CogImage8Grey;

            if (img != null) return img.Width;
            else return -1;
        }





        /////////////////////////////////////////////////////////
        // PSJ
        /////////////////////////////////////////////////////////
        public void ScreenCapture()
        {
            if (!UseAutoCapture) return;

            try
            {
                System.IO.DirectoryInfo di;
                string sDirPath = string.Empty;

                switch (mProcessType)
                {
                    case ProcessType.PRE:
                        if (lastJudgement)
                            sDirPath = SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\PREALIGN\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\OK";
                        else
                            sDirPath = SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\PREALIGN\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\NG";
                        break;
                    case ProcessType.MAIN:
                        if (lastJudgement)
                            sDirPath = SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\MAIN\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\OK";
                        else
                            sDirPath = SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\MAIN\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\NG";
                        break;
                    case ProcessType.INSPECT:
                        if (lastJudgement)
                            sDirPath = SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\INSPECTION\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\OK";
                        else
                            sDirPath = SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\INSPECTION\\" + DateTime.Now.ToString("yyyy-MM-dd") + "\\NG";
                        break;
                    default:
                        break;
                }

                Bitmap SaveBit = new Bitmap(1920, 1080, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                using (Graphics g = Graphics.FromImage(SaveBit))
                {
                    g.CopyFromScreen(0, 0, 0, 0, new System.Drawing.Size(1920, 1080));
                }

                di = new System.IO.DirectoryInfo(sDirPath);
                if (di.Exists == false)
                {
                    di.Create();
                }

                SaveBit.Save(sDirPath + "\\" + DateTime.Now.ToString("HH-mm-ss_") + algoRst.ID + ".bmp");

                SaveBit.Dispose();
                //GC.Collect();

                Del_Log(SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\", SystemDir.Iva_Log + "\\C-PanelAttach\\ExeptionLog\\");
                Del_Images(SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\PREALIGN\\", SystemDir.Iva_Log + "\\C-PanelAttach\\ExeptionLog\\");
                Del_Images(SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\MAIN\\", SystemDir.Iva_Log + "\\C-PanelAttach\\ExeptionLog\\");
                Del_Images(SystemDir.Iva_Log + "\\C-PanelAttach\\ScreenCapture\\INSPECTION\\", SystemDir.Iva_Log + "\\C-PanelAttach\\ExeptionLog\\");
            }
            catch (Exception ex)
            {
                ;
            }
        }

        void Del_Log(string dirname, string dirname_exception)
        {
            if (!Directory.Exists(dirname)) return;

            System.IO.DirectoryInfo LogFolder = new System.IO.DirectoryInfo(dirname);
            try
            {
                foreach (System.IO.FileInfo fi in LogFolder.GetFiles())
                {
                    if (fi.CreationTime < DateTime.Now.AddDays(-30))
                        fi.Delete();
                }
            }

            catch (Exception ex)
            {
                SaveLog(dirname_exception, "Algorithm.txt", ex.ToString());
            }
        }

        void Del_Images(string dirname, string dirname_exception)
        {
            if (!Directory.Exists(dirname)) return;

            System.IO.DirectoryInfo bmpFolder = new System.IO.DirectoryInfo(dirname);
            try
            {
                foreach (System.IO.DirectoryInfo dir in bmpFolder.GetDirectories())
                {
                    if (dir.CreationTime < DateTime.Now.AddDays(-30))
                        dir.Delete(true);
                }
            }
            catch (Exception ex)
            {
                SaveLog(dirname_exception, "Algorithm.txt", ex.ToString());
            }
        }

        void SaveLog(string dirname, string filename, string text)
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(dirname);
                if (dir.Exists == false)
                {
                    dir.Create();
                }

                FileInfo file = new FileInfo(dirname + DateTime.Now.ToString("yyyy-MM-dd_") + filename);
                if (!file.Exists)
                {
                    FileStream fs = file.Create();
                    fs.Close();
                }

                File.AppendAllText(dirname + DateTime.Now.ToString("yyyy-MM-dd_") + filename, DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss_") + text + "\r\n");
            }
            catch (Exception ex)
            {
                ;
            }
        }




        public bool InspectionResultPass()
        {
            if (mProcessType == ProcessType.INSPECT)
            {
                int Pass = PlcValues.ContainsKey("InspectionResultPass") ? (int)PlcValues["InspectionResultPass"].CurValue : 0;

                if(Pass == 2)
                    return true;
            }

            return false;
        }

    }

    public class MarkRstInfo
    {
        public double Score;
        public double MatchingSpec;
        public double SuccessIndex;
    }

}

