﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Telerik.Windows.Controls.Data.PropertyGrid;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    /// <summary>
    /// CameraProperties.xaml에 대한 상호 작용 논리
    /// </summary>
    /// 

    public partial class Algo_C_PanelAttachProperties : UserControl
    {
        public Algo_C_PanelAttachProperties()
        {
            InitializeComponent();
        }

        private void PropertyGrid1_Loaded(object sender, RoutedEventArgs e)
        {
            //BindingOperations.SetBinding(PropertyGrid1.PropertyDefinitions[2], PropertyDefinition.VisibilityProperty, new Binding("ModObject.Align2P") { Source = PropertyGrid1.DataContext, Converter = new Telerik.Windows.Controls.BooleanToVisibilityConverter() });
            //BindingOperations.SetBinding(PropertyGrid1.PropertyDefinitions[3], PropertyDefinition.VisibilityProperty, new Binding("ModObject.Align3P") { Source = PropertyGrid1.DataContext, Converter = new Telerik.Windows.Controls.BooleanToVisibilityConverter() });
        }
    }
}
