﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Diagram;
using Iva.Bplus.Enums;
using Iva.Bplus.Interface;
using Iva.Bplus.Struct;
using Iva.Bplus.Views;
using SvMip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]
    public partial class Algo_C_PanelAttachShape : ModuleBase
    {
        #region [Construct]
        public Algo_C_PanelAttachShape()
            : base()
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;
        }

        public Algo_C_PanelAttachShape(SystemCanvasViewModel parent, string name)
            : base(parent, name)
        {
            ShapeType = ShapeType.Algorithm;
            base.Geometry = SystemImage.TOOLS_ICON;

            base.InitItem(null, name, SettingShapeType.Algo);

            var action = base.modAction as SystemActionBase;
            base.SetConnectors(action.InputParams, action.OutputParams);

            ModAction.ModObject.PropertyChanged += ModObject_PropertyChanged;
        }
        #endregion

        #region [override method]
        public override void AssembleItem(SystemCanvasViewModel parent, ModuleObjectBase obj, string _source)
        {
            base.parent = parent;
            base.InitItem(obj, _source, SettingShapeType.Algo);

            ModAction.ModObject.PropertyChanged += ModObject_PropertyChanged;

            base.Geometry = SystemImage.TOOL_SEQUENCE_ICON;
        }
        private void ModObject_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            var obj = sender as Algo_C_PanelAttachObject;
            if (e.PropertyName == "ProcessType")
            {
                int connectorCnt = inputConnectors.Count();

                // 확인해서 기존꺼랑 같으면 그냥 넘어간다..
                switch (obj.ProcessType)
                {
                    case ProcessType.PRE:
                        if (base.InputConnectors.Count == 3) return;
                        break;
                    case ProcessType.TAPE:
                    case ProcessType.PANEL:
                    case ProcessType.MAIN:
                        if (base.InputConnectors.Count == 4) return;
                        break;
                    case ProcessType.INSPECT:
                        if (base.InputConnectors.Count == 6) return;
                        break;
                    case ProcessType.H2H:
                        if (base.InputConnectors.Count == 2) return;
                        break;
                }

                // input connector 수정,,
                base.InputConnectors.Clear();
                switch (obj.ProcessType)
                {
                    case ProcessType.PRE:
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("P1", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("P2", typeof(IPointResult)));
                        break;
                    case ProcessType.TAPE:
                    case ProcessType.PANEL:
                    case ProcessType.MAIN:
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("P1", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("P2", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("H1", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Outputs", typeof(Dictionary<string, object>)));
                        break;
                    case ProcessType.INSPECT:
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Tar_P1", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Tar_P2", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Obj_P1", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Obj_P2", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Hc_Panel", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Outputs_Panel", typeof(Dictionary<string, object>)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Hc_Tape", typeof(IPointResult)));
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Outputs_Tape", typeof(Dictionary<string, object>)));
                        break;
                    case ProcessType.H2H:
                        base.InputConnectors_ItemAdd(new ConnectorViewModel("Outputs_H2H", typeof(Dictionary<string, object>)));
                        break;
                    default:
                        break;
                }

                base.InputConnectors_ItemAdd(new ConnectorViewModel("Trigger", typeof(CalcTrigger)));
            }
        }

        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion
    }
}
