﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Iva.Bplus.Struct;
using Iva.Bplus.Enums;
using Cognex.VisionPro;
using Cognex.VisionPro.ImageProcessing;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public partial class Algo_C_PanelAttachObject : AlgoObjectBase
    {
        bool IsDigitizer()
        {
            int marker_ng_count = 0;

            int Digitizer = PlcValues.ContainsKey("IsDigitizer") ? (int)PlcValues["IsDigitizer"].CurValue : 0;

            if (Digitizer == 2)
            {
                if (InputValues.ContainsKey("P1"))
                {
                    var Obj_P1 = InputValues["P1"] as IPointResult;
                    if (Obj_P1 == null)
                        marker_ng_count++;
                }
                else
                    marker_ng_count++;

                if (InputValues.ContainsKey("P2"))
                {
                    var Obj_P2 = InputValues["P2"] as IPointResult;
                    if (Obj_P2 == null)
                        marker_ng_count++;
                }
                else
                    marker_ng_count++;
                
                if (marker_ng_count == 2)
                {
                    //errorCode = AlgoActionBase.Err_Both_Mark_Not_Find;
                    return true;
                }
            }

            return false;
        }




        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool AlignCalc2P()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudgement = true;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            //if(IsDigitizer())
            //    return false;

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("P1") || !InputValues.ContainsKey("P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }


            var Obj_P1 = InputValues["P1"] as IPointResult;
            var Obj_P2 = InputValues["P2"] as IPointResult;
            if (Obj_P1 == null || Obj_P2 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            SetMarkInfo(ref mObj_Mark1, Obj_P1);
            SetMarkInfo(ref mObj_Mark2, Obj_P2);

            if (Obj_P1.RefPoints == null)
            {
                Obj_P1.RefPoints = new List<XYT>();
                Obj_P1.RefPoints.Add(new XYT(0, 0, 0));
            }
            if (Obj_P2.RefPoints == null)
            {
                Obj_P2.RefPoints = new List<XYT>();
                Obj_P2.RefPoints.Add(new XYT(0, 0, 0));
            }
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null || P2_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                DrawErrDisp("Err_CalData_Is_Null");
                return false;
            }

            var Robot_P1 = P1_CalDataObj.GetV2R(model, new XY(Obj_P1.OutputXYT.X, Obj_P1.OutputXYT.Y));
            var Robot_P2 = P2_CalDataObj.GetV2R(model, new XY(Obj_P2.OutputXYT.X, Obj_P2.OutputXYT.Y));

            var Robot_CAM_P1 = new XY(0, 0);
            var Robot_CAM_P2 = new XY(0, 0);

            XY Robot_Ref_P1; XY Robot_Ref_P2;
            Robot_Ref_P1 = P1_CalDataObj.GetV2R(model, new XY(Obj_P1.RefPoints[0].X, Obj_P1.RefPoints[0].Y));
            Robot_Ref_P2 = P2_CalDataObj.GetV2R(model, new XY(Obj_P2.RefPoints[0].X, Obj_P2.RefPoints[0].Y));

            // 2020.06.03 hdy cam 및 stage moving 량 회전 중심 반영 : 테스트 필요
            //var RotCenter_P1 = GetRotateCenter(P1_CalDataObj, XYDirection.Plus, XYDirection.Plus, XYDirection.Minus, XYDirection.Minus);
            //var RotCenter_P2 = GetRotateCenter(P2_CalDataObj, XYDirection.Plus, XYDirection.Plus, XYDirection.Minus, XYDirection.Minus);

            var Coord_P1 = Robot_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_P2 = Robot_P2 + P2_CalDataObj.GetRotateCenter(model);

            var Coord_CAM_P1 = Robot_CAM_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_CAM_P2 = Robot_CAM_P2 + P2_CalDataObj.GetRotateCenter(model);

            var Coord_Ref_P1 = Robot_Ref_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_Ref_P2 = Robot_Ref_P2 + P2_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            var Limit = new XYT(limitX, limitY, limitT);
            var spec_Length = (double)mParams.Length_Obj.Value;
            var tor_Length = (double)mParams.Tor_Obj.Value;
            var scale_Length = (double)mParams.Scale_Length.Value;

            //var retryX = (double)mParams.RetryX?.Value;
            //var retryY = (double)mParams.RetryY?.Value;
            //var retryT = (double)mParams.RetryT?.Value;
            #endregion

            #region Calc Rev Offset

            // 단변
            double camT = GetTheta(Coord_CAM_P1.X, Coord_CAM_P1.Y, Coord_CAM_P2.X, Coord_CAM_P2.Y);
            double refT = GetTheta(Coord_Ref_P1.X, Coord_Ref_P1.Y, Coord_Ref_P2.X, Coord_Ref_P2.Y);
            double pnlT = GetTheta(Coord_P1.X, Coord_P1.Y, Coord_P2.X, Coord_P2.Y);

            //pnlT -= camT;
            //refT -= camT;
            //camT = 0;

            var camTar = (Coord_CAM_P1 + Coord_CAM_P2) / 2;
            var refTar = (Coord_Ref_P1 + Coord_Ref_P2) / 2;
            var pnlObj = (Coord_P1 + Coord_P2) / 2;

            var alignOffset = CvtPLCIO.OffsetXYT;

            var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
            var refTarxyt = new XYT(refTar.X, refTar.Y, refT);
            var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
            var camTarxyt_Un = new XYT(camTar.X, camTar.Y, camT);

            mRevAlign = new XYT();
            mRevUnload = new XYT();
            double radT, DriftX, DriftY;

            if (CalcType == CalcType.Center_2P)
            {
                // Attach 위치 보정값 계산. 
                camTarxyt = ApplyTargetOffset(camTarxyt, alignOffset);
                radT = NormalizeTheta(camTarxyt.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                mRevAlign.X = camTarxyt.X - DriftX;
                mRevAlign.Y = camTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else //역방향
                    mRevAlign.T = (radT / rad) * -1;

                // Unload 위치 보정값 계산 // 얘는 오프셋없음.    
                camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                mRevUnload.X = camTarxyt_Un.X - DriftX;
                mRevUnload.Y = camTarxyt_Un.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevUnload.T = radT / rad;
                else //역방향
                    mRevUnload.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.Reference_2P)
            {
                // Attach 위치 보정값 계산. 
                refTarxyt = ApplyTargetOffset(refTarxyt, alignOffset);
                radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                mRevAlign.X = refTarxyt.X - DriftX;
                mRevAlign.Y = refTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else  //역방향
                    mRevAlign.T = (radT / rad) * -1;

                // Unload 위치 보정값 계산 // 얘는 오프셋없음.    //CamCenter위치로
                camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
                radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                mRevUnload.X = camTarxyt_Un.X - DriftX;
                mRevUnload.Y = camTarxyt_Un.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevUnload.T = radT / rad;
                else  //역방향
                    mRevUnload.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.PickUp_2P)   //Target: 자재, Object: Reference
            {
                pnlObjxyt = ApplyTargetOffset(pnlObjxyt, alignOffset);
                radT = NormalizeTheta(pnlObjxyt.T - refTarxyt.T);
                DriftX = Math.Cos(radT) * refTarxyt.X - Math.Sin(radT) * refTarxyt.Y;
                DriftY = Math.Sin(radT) * refTarxyt.X + Math.Cos(radT) * refTarxyt.Y;
                mRevAlign.X = pnlObjxyt.X - DriftX;
                mRevAlign.Y = pnlObjxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else  //역방향
                    mRevAlign.T = (radT / rad) * -1;

            }
            #endregion

            #region Confirm Result (Align Spec Over Check)
            #region 중복부착
            if (!CheckCPNLAttached())
            {
                lastJudgement = false;
            }
            #endregion

            #region retry spec over
            //if (!(retryX == 0.0 && retryY == 0.0 && retryT == 0.0)
            //    && (Math.Abs(mRevAlign.X) > retryX || Math.Abs(mRevAlign.Y) > retryY || Math.Abs(mRevAlign.T) > retryT))
            //{
            //    Obj_P1.DisplayObj.Judgement = (uint)Judgement.Warning;
            //    Obj_P2.DisplayObj.Judgement = (uint)Judgement.Warning;
            //    errorCode = AlgoActionBase.Err_Retry_Spec_Over;
            //    DrawErrDisp("Err_Retry_Spec_Over");
            //    lastJudgement = false;
            //}
            #endregion

            #region limit spec over
            if (!ConfirmResult(mRevAlign, Limit) && lastJudgement)
            {
                Obj_P1.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Obj_P2.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;

                DrawErrDisp("Err_Tolerance_Exceeded", P1_DisplayObj);
                DrawErrDisp("Err_Tolerance_Exceeded", P2_DisplayObj);
                lastJudgement = false;
            }
            #endregion
            #endregion

            #region Calc Length & Confirm (Length Check)
            mLengthObj = GetLength(Coord_P1, Coord_P2);
            // 2021.04.05 jyh 고객님께서 무주건 L-Check를 사용하고 싶다고 하신다.
            //var use = (Options as Algo_C_PanelAttachDefaultOptions).UseLCheck.Value;
            var use = OnOff.On;

            if(spec_Length == 0 || tor_Length == 0)
            {
                lastJudgement = false;
                errorCode = AlgoActionBase.Err_LCheck_Info_Missing;
                return lastJudgement;
            }

            if (use == OnOff.On && spec_Length != 0 && tor_Length != 0 && lastJudgement)
            {
                if (Math.Abs(spec_Length - mLengthObj) > tor_Length)
                {
                    lastJudgement = false;
                    errorCode = AlgoActionBase.Err_Length_Check;
                    Obj_P1.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Obj_P2.DisplayObj.Judgement = (uint)Judgement.L_Check;

                    DrawErrDisp("Err_Length_Check", P1_DisplayObj);
                    DrawErrDisp("Err_Length_Check", P2_DisplayObj);

                    Obj_P1.Tool.ProcMode = ProcessMode.Manual; Obj_P2.Tool.ProcMode = ProcessMode.Manual;
                }
            }
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo_C_PanelAttachResult2P
            {
                Name = name,
                ID = sourceID,
                Result = lastJudgement,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Rev1X = Math.Round(mRevAlign.X, 3),
                Rev1Y = Math.Round(mRevAlign.Y, 3),
                Rev1T = Math.Round(mRevAlign.T, 3),

                //Rev2X = Math.Round(mRevUnload.X, 3),
                //Rev2Y = Math.Round(mRevUnload.Y, 3),
                //Rev2T = Math.Round(mRevUnload.T, 3),

                PLCOffset_X = alignOffset.X,
                PLCOffset_Y = alignOffset.Y,
                PLCOffset_T = alignOffset.T,

                Length = Math.Round(mLengthObj, 3),

                P1_X = Math.Round(Obj_P1.OutputXYT.X, 3),  //Mark Pixel 좌표
                P1_Y = Math.Round(Obj_P1.OutputXYT.Y, 3),
                P2_X = Math.Round(Obj_P2.OutputXYT.X, 3),
                P2_Y = Math.Round(Obj_P2.OutputXYT.Y, 3),

                C1_X = Math.Round(Coord_P1.X, 3),
                C1_Y = Math.Round(Coord_P1.Y, 3),
                C2_X = Math.Round(Coord_P2.X, 3),
                C2_Y = Math.Round(Coord_P2.Y, 3),

                Type = CalcType.ToString(),
                Pnl_T = Math.Round(pnlT / rad, 3),
                Ref_T = Math.Round(refT / rad, 3),
                Cam_T = Math.Round(camT / rad, 3),    //camT=0인데 의미가 있나

                HistL = HistoValue_L,
                HistR = HistoValue_R
            };
            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            #endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO(AlgoRst);
            #endregion
            return lastJudgement;
        }

        public bool CheckCPNLAttached()
        {
            if (ProcessType == ProcessType.PRE) return true;

            var Obj_P1 = InputValues["P1"] as IImageResult;
            var Obj_P2 = InputValues["P2"] as IImageResult;


            var Obj_P3 = InputValues["P1"] as IPointResult;
            var Obj_P4 = InputValues["P2"] as IPointResult;


            CogDsL.Image = null;
            CogDsR.Image = null;

            CogDsL.Image = Obj_P1.OutputImage as Cognex.VisionPro.ICogImage;
            CogDsR.Image = Obj_P2.OutputImage as Cognex.VisionPro.ICogImage;

            var tool = new CogHistogramTool();
            tool.InputImage = CogDsL.Image;
            tool.Region = AreaL;
            tool.Run();

            HistoValue_L = tool.Result != null ? (double)tool.Result.Mean : 0;

            HistoValue_L /= 255;
            HistoValue_L *= 1000;
            HistoValue_L = Math.Round(HistoValue_L, 2);
            tool.InputImage = CogDsR.Image;
            tool.Region = AreaR;
            tool.Run();
            HistoValue_R = tool.Result != null ? (double)tool.Result.Mean : 0;
            HistoValue_R /= 255;
            HistoValue_R *= 1000;
            HistoValue_R = Math.Round(HistoValue_R, 2);

            var option = Options as Algo_C_PanelAttachModelOptions;

            if (IsLessThan_L && HistoValue_L < SpecValue_L) JudgeHisto_L = true;
            else if (!IsLessThan_L && HistoValue_L > SpecValue_L) JudgeHisto_L = true;
            else { JudgeHisto_L = false; }

            if (IsLessThan_R && HistoValue_R < SpecValue_R) JudgeHisto_R = true;
            else if (!IsLessThan_R && HistoValue_R > SpecValue_R) JudgeHisto_R = true;
            else { JudgeHisto_R = false; }

            if(option.UseCheckAssemble_L.Value == OnOff.On)
                DrawCPNLAttached(P1_DisplayObj, AreaL, HistoValue_L, SpecValue_L);
            if (option.UseCheckAssemble_R.Value == OnOff.On)
                DrawCPNLAttached(P2_DisplayObj, AreaR, HistoValue_R, SpecValue_R);

            SystemLogger.WriteProductDefectLog(string.Format("{0}, {1}, {2}, {3}, {4}, {5}, {6}", SourceID, SpecValue_L, SpecValue_R, HistoValue_L, HistoValue_R, judgeHisto_L, judgeHisto_R));

            ///return true;
            if (option.UseCheckAssemble_L.Value == OnOff.On && !judgeHisto_L)
            {
                errorCode = AlgoActionBase.Err_Inspection_Detect_NG;
                DrawErrDisp("Already Attached");
                return false;
            }

            if (option.UseCheckAssemble_R.Value == OnOff.On && !judgeHisto_R)
            {
                errorCode = AlgoActionBase.Err_Inspection_Detect_NG;
                DrawErrDisp("Already Attached");
                return false;
            }

            return true;
        }

        public void TestCPNLAttached()
        {

            if (CogDsL.Image == null) return;
            if (CogDsR.Image == null) return;

            var tool = new CogHistogramTool();
            tool.InputImage = CogDsL.Image;
            tool.Region = AreaL;
            tool.Run();

            HistoValue_L = tool.Result != null ? (double)tool.Result.Mean : 0;
            HistoValue_L /= 255;
            HistoValue_L *= 1000;
            HistoValue_L = Math.Round(HistoValue_L, 2);

            tool.InputImage = CogDsR.Image;
            tool.Region = AreaR;
            tool.Run();
            HistoValue_R = tool.Result != null ? (double)tool.Result.Mean : 0;
            HistoValue_R /= 255;
            HistoValue_R *= 1000;
            HistoValue_R = Math.Round(HistoValue_R, 2);

            var option = Options as Algo_C_PanelAttachModelOptions;

            if (IsLessThan_L && HistoValue_L < SpecValue_L) JudgeHisto_L = true;
            else if (!IsLessThan_L && HistoValue_L > SpecValue_L) JudgeHisto_L = true;
            else { JudgeHisto_L = false; }

            if (IsLessThan_R && HistoValue_R < SpecValue_R) JudgeHisto_R = true;
            else if (!IsLessThan_R && HistoValue_R > SpecValue_R) JudgeHisto_R = true;
            else { JudgeHisto_R = false; }
        }

        public void AreaL_DraggingStopped(object sender, CogDraggingEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public void AreaL_Changed(object sender, CogChangedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public void AreaR_DraggingStopped(object sender, CogDraggingEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public void AreaR_Changed(object sender, CogChangedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public void AreaH_DraggingStopped(object sender, CogDraggingEventArgs e)
        {
            //throw new NotImplementedException();
        }

        public void AreaH_Changed(object sender, CogChangedEventArgs e)
        {
            //throw new NotImplementedException();
        }
    }
}
