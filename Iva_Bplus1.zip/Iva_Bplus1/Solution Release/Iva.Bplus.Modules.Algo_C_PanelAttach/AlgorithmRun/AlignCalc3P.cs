﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Iva.Bplus.Struct;
using Iva.Bplus.Enums;

using Cognex.VisionPro;
using System.Windows.Forms;


namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public partial class Algo_C_PanelAttachObject : AlgoObjectBase
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool AlignCalc3P(bool bWrite = true)
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudgement = true;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            int Is2PointAlign = PlcValues.ContainsKey("Is_2Point_Align") ? (int)PlcValues["Is_2Point_Align"].CurValue : 0;

            #region Mark Data Read& Confirm 
            if (Is2PointAlign != 2)
            {
                if (!InputValues.ContainsKey("P1") || !InputValues.ContainsKey("P2") || !InputValues.ContainsKey("H1"))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
            }
            else
            {
                if (!InputValues.ContainsKey("P1") || !InputValues.ContainsKey("P2"))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
            }

            var Obj_P1 = InputValues["P1"] as IPointResult;
            var Obj_P2 = InputValues["P2"] as IPointResult;
            var Obj_H1 = InputValues["P2"] as IPointResult;
            if (Is2PointAlign != 2) Obj_H1 = InputValues["H1"] as IPointResult;

            if (Obj_P1 == null || Obj_P2 == null || Obj_H1 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            SetMarkInfo(ref mObj_Mark1, Obj_P1);
            SetMarkInfo(ref mObj_Mark2, Obj_P2);
            SetMarkInfo(ref mObj_Mark3, Obj_H1);

            if (Obj_P1.RefPoints == null)
            {
                Obj_P1.RefPoints = new List<XYT>();
                Obj_P1.RefPoints.Add(new XYT(0, 0, 0));
            }
            if (Obj_P2.RefPoints == null)
            {
                Obj_P2.RefPoints = new List<XYT>();
                Obj_P2.RefPoints.Add(new XYT(0, 0, 0));
            }
            if (Obj_H1.RefPoints == null)
            {
                Obj_H1.RefPoints = new List<XYT>();
                Obj_H1.RefPoints.Add(new XYT(0, 0, 0));
            }
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null || P2_CalDataObj == null || H1_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                DrawErrDisp("Err_CalData_Is_Null");
                return false;
            }

            var Robot_P1 = P1_CalDataObj.GetV2R(model, new XY(Obj_P1.OutputXYT.X, Obj_P1.OutputXYT.Y));
            var Robot_P2 = P2_CalDataObj.GetV2R(model, new XY(Obj_P2.OutputXYT.X, Obj_P2.OutputXYT.Y));
            var Robot_H1 = H1_CalDataObj.GetV2R(model, new XY(Obj_H1.OutputXYT.X, Obj_H1.OutputXYT.Y));

            var Robot_CAM_P1 = new XY(0, 0);
            var Robot_CAM_P2 = new XY(0, 0);
            var Robot_CAM_H1 = new XY(0, 0);

            XY Robot_Ref_P1; XY Robot_Ref_P2;
            Robot_Ref_P1 = P1_CalDataObj.GetV2R(model, new XY(Obj_P1.RefPoints[0].X, Obj_P1.RefPoints[0].Y));
            Robot_Ref_P2 = P2_CalDataObj.GetV2R(model, new XY(Obj_P2.RefPoints[0].X, Obj_P2.RefPoints[0].Y));
            var Robot_Ref_H1 = H1_CalDataObj.GetV2R(model, new XY(Obj_H1.RefPoints[0].X, Obj_H1.RefPoints[0].Y));

            // 2020.06.03 hdy cam 및 stage moving 량 회전 중심 반영 : 테스트 필요
            //var RotCenter_P1 = GetRotateCenter(P1_CalDataObj, XYDirection.Plus, XYDirection.Plus, XYDirection.Minus, XYDirection.Minus);
            //var RotCenter_P2 = GetRotateCenter(P2_CalDataObj, XYDirection.Plus, XYDirection.Plus, XYDirection.Minus, XYDirection.Minus);
            //var RotCenter_H1 = GetRotateCenter(H1_CalDataObj, XYDirection.Plus, XYDirection.Plus, XYDirection.Minus, XYDirection.Minus);

            var Coord_P1 = Robot_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_P2 = Robot_P2 + P2_CalDataObj.GetRotateCenter(model);
            var Coord_H1 = Robot_H1 + H1_CalDataObj.GetRotateCenter(model);

            var Coord_CAM_P1 = Robot_CAM_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_CAM_P2 = Robot_CAM_P2 + P2_CalDataObj.GetRotateCenter(model);
            var Coord_CAM_H1 = Robot_CAM_H1 + H1_CalDataObj.GetRotateCenter(model);

            var Coord_Ref_P1 = Robot_Ref_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_Ref_P2 = Robot_Ref_P2 + P2_CalDataObj.GetRotateCenter(model);
            var Coord_Ref_H1 = Robot_Ref_H1 + H1_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            var Limit = new XYT(limitX, limitY, limitT);
            var spec_Length = (double)mParams.Length_Obj.Value;
            var tor_Length = (double)mParams.Tor_Obj.Value;
            var scale_Length = (double)mParams.Scale_Length.Value;

            var weightP1 = (double)mParams.WeightP1.Value;
            var weightP2 = (double)mParams.WeightP2.Value;
            var weightH1 = (double)mParams.WeightH1.Value;
            #endregion

            #region Calc Rev Offset

            // 단변
            double camT = GetTheta(Coord_CAM_P1.X, Coord_CAM_P1.Y, Coord_CAM_P2.X, Coord_CAM_P2.Y);
            double refT = GetTheta(Coord_Ref_P1.X, Coord_Ref_P1.Y, Coord_Ref_P2.X, Coord_Ref_P2.Y);
            double pnlT = GetTheta(Coord_P1.X, Coord_P1.Y, Coord_P2.X, Coord_P2.Y);

            //pnlT -= camT;
            //refT -= camT;
            //camT = 0;

            var camTar = (Coord_CAM_P1 + Coord_CAM_P2 + Coord_CAM_H1) / 3;
            var refTar = (Coord_Ref_P1 + Coord_Ref_P2 + Coord_Ref_H1) / 3;
            var pnlObj = (Coord_P1 + Coord_P2 + Coord_H1) / 3;

            //var alignOffset = CvtPLCIO.OffsetXYT;

            var camTarxyt = new XYT(camTar.X, camTar.Y, camT);
            var refTarxyt = new XYT(refTar.X, refTar.Y, refT);
            var pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);
            var camTarxyt_Un = new XYT(camTar.X, camTar.Y, camT);

            mRevAlign = new XYT();
            mRevUnload = new XYT();
            double radT, DriftX, DriftY;

            if (mMarkScale == null) mMarkScale = new XYXY(1.0, 1.0, 1.0, 1.0);
            if (mHoleScale == null) mHoleScale = new XY(1.0, 1.0);

            XY markLOffset = new XY(); XY markROffset = new XY(); XY holeOffset = new XY();
            XYT offset = new XYT();

            if (ProcessType == ProcessType.TAPE)
            {
                offset = new XYT(CvtPLCIO.OffsetXYT.X, CvtPLCIO.OffsetXYT.Y, CvtPLCIO.OffsetXYT.T);
                markLOffset.X = CvtPLCIO.OffsetXYT.X;
                markLOffset.Y = CvtPLCIO.OffsetXYT.Y;
                markROffset.X = CvtPLCIO.OffsetXYT.T;
                refTarxyt = ApplyTargetOffset(offset, ref Coord_Ref_P1, ref Coord_Ref_P2, ref Coord_Ref_H1);
            }
            else
            {
                markLOffset.X = CvtPLCIO.OffsetXYXY.Lx;
                markLOffset.Y = CvtPLCIO.OffsetXYXY.Ly;
                markROffset.X = CvtPLCIO.OffsetXYXY.Rx;
                markROffset.Y = CvtPLCIO.OffsetXYXY.Ry;
                holeOffset.X = PlcValues.ContainsKey("Offset#5") ? (double)PlcValues["Offset#5"].CurValue : 0.0;
                holeOffset.Y = PlcValues.ContainsKey("Offset#6") ? (double)PlcValues["Offset#6"].CurValue : 0.0;

                //Scale적용
                markLOffset.X /= mMarkScale.Lx;
                markLOffset.Y /= mMarkScale.Ly;
                markROffset.X /= mMarkScale.Rx;
                markROffset.Y /= mMarkScale.Ry;
                holeOffset.X /= mHoleScale.X;
                holeOffset.Y /= mHoleScale.Y;

                //markLOffset = new XY(0.0, 0.0);
                //markROffset = new XY(0.0, 0.0);
                //holeOffset = new XY(0.0, 0.0);

                refTarxyt = ApplyTargetOffset(markLOffset, markROffset, holeOffset, ref Coord_Ref_P1, ref Coord_Ref_P2, ref Coord_Ref_H1);
            }

            if (AngleType == CalcAngle3P.Use2P)
            {
                radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);
            }
            else
            {
                radT = Get3PTheta(Coord_Ref_P1, Coord_Ref_P2, Coord_Ref_H1, Coord_P1, Coord_P2, Coord_H1);
            }

            if (CalcType == CalcType.Reference_2P)
            {
                var alignOffset = CvtPLCIO.OffsetXYXY;

                if (mMarkScale == null) mMarkScale = new XYXY(1.0, 1.0, 1.0, 1.0);
                //Scale적용
                alignOffset.Lx /= mMarkScale.Lx;
                alignOffset.Ly /= mMarkScale.Ly;
                alignOffset.Rx /= mMarkScale.Rx;
                alignOffset.Ry /= mMarkScale.Ry;

                refTar = (Coord_Ref_P1 + Coord_Ref_P2) / 2;
                pnlObj = (Coord_P1 + Coord_P2) / 2;

                refTarxyt = new XYT(refTar.X, refTar.Y, refT);
                pnlObjxyt = new XYT(pnlObj.X, pnlObj.Y, pnlT);

                // Attach 위치 보정값 계산. 
                refTarxyt = ApplyTargetOffset(Coord_Ref_P1, Coord_Ref_P2, alignOffset);
                radT = NormalizeTheta(refTarxyt.T - pnlObjxyt.T);

                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                mRevAlign.X = refTarxyt.X - DriftX;
                mRevAlign.Y = refTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else //역방향
                    mRevAlign.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.Hole_3P)
            {
                // Attach 위치 보정값 계산. 
                DriftX = Math.Cos(radT) * Coord_H1.X - Math.Sin(radT) * Coord_H1.Y;
                DriftY = Math.Sin(radT) * Coord_H1.X + Math.Cos(radT) * Coord_H1.Y;
                mRevAlign.X = Coord_Ref_H1.X - DriftX;
                mRevAlign.Y = Coord_Ref_H1.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else  //역방향
                    mRevAlign.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.Center_3P)
            {
                // Attach 위치 보정값 계산. 
                DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
                DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
                mRevAlign.X = refTarxyt.X - DriftX;
                mRevAlign.Y = refTarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else  //역방향
                    mRevAlign.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.Moving_3P)
            {
                // 포인트별 이동량 평균으로 XY 이동량을 정한다.
                // P1번 포인트 Drift 량, 차이값
                DriftX = Math.Cos(radT) * Coord_P1.X - Math.Sin(radT) * Coord_P1.Y;
                DriftY = Math.Sin(radT) * Coord_P1.X + Math.Cos(radT) * Coord_P1.Y;
                mP1Moving = new XY(Coord_Ref_P1.X - DriftX, Coord_Ref_P1.Y - DriftY);

                // P2번 포인트 Drift 량, 차이값
                DriftX = Math.Cos(radT) * Coord_P2.X - Math.Sin(radT) * Coord_P2.Y;
                DriftY = Math.Sin(radT) * Coord_P2.X + Math.Cos(radT) * Coord_P2.Y;
                mP2Moving = new XY(Coord_Ref_P2.X - DriftX, Coord_Ref_P2.Y - DriftY);

                // H1번 포인트 Drift 량, 차이값
                DriftX = Math.Cos(radT) * Coord_H1.X - Math.Sin(radT) * Coord_H1.Y;
                DriftY = Math.Sin(radT) * Coord_H1.X + Math.Cos(radT) * Coord_H1.Y;
                mH1Moving = new XY(Coord_Ref_H1.X - DriftX, Coord_Ref_H1.Y - DriftY);

                int point_count = 3;
                if (Is2PointAlign == 2)
                {
                    weightH1 = 0;
                    point_count = 2;
                }

                mRevAlign.X = (weightP1 * mP1Moving.X + weightP2 * mP2Moving.X + weightH1 * mH1Moving.X) / point_count;
                mRevAlign.Y = (weightP1 * mP1Moving.Y + weightP2 * mP2Moving.Y + weightH1 * mH1Moving.Y) / point_count;

                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else  //역방향
                    mRevAlign.T = (radT / rad) * -1;
            }

            //AlignSimulation(CalcType, radT, Coord_Ref_P1, Coord_Ref_P2, Coord_Ref_H1, Coord_P1, Coord_P2, Coord_H1);

            // Unload 위치 보정값 계산 // 얘는 오프셋없음.    //CamCenter위치로
            camTarxyt_Un = ApplyTargetOffset(camTarxyt_Un, new XYT());
            radT = NormalizeTheta(camTarxyt_Un.T - pnlObjxyt.T);
            DriftX = Math.Cos(radT) * pnlObjxyt.X - Math.Sin(radT) * pnlObjxyt.Y;
            DriftY = Math.Sin(radT) * pnlObjxyt.X + Math.Cos(radT) * pnlObjxyt.Y;
            mRevUnload.X = camTarxyt_Un.X - DriftX;
            mRevUnload.Y = camTarxyt_Un.Y - DriftY;
            if (ThetaDirection == ThetaDirection.Normal)    //정방향
                mRevUnload.T = radT / rad;
            else  //역방향
                mRevUnload.T = (radT / rad) * -1;

            #endregion

            #region Confirm Result (Align Spec Over Check)
            #region 중복부착
            if (!CheckCPNLAttached())
            {
                lastJudgement = false;
            }
            #endregion

            #region retry spec over
            //if (!(retryX == 0.0 && retryY == 0.0 && retryT == 0.0)
            //    && (Math.Abs(mRevAlign.X) > retryX || Math.Abs(mRevAlign.Y) > retryY || Math.Abs(mRevAlign.T) > retryT))
            //{
            //    Obj_P1.DisplayObj.Judgement = (uint)Judgement.Warning;
            //    Obj_P2.DisplayObj.Judgement = (uint)Judgement.Warning;
            //    errorCode = AlgoActionBase.Err_Retry_Spec_Over;
            //    DrawErrDisp("Err_Retry_Spec_Over");
            //    lastJudgement = false;
            //}
            #endregion

            #region limit spec over
            if (!ConfirmResult(mRevAlign, Limit) && lastJudgement)
            {
                Obj_P1.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                Obj_P2.DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                DrawErrDisp("Err_Tolerance_Exceeded");
                lastJudgement = false;
            }
            #endregion
            #endregion

            #region Calc Length & Confirm (Length Check)
            mLengthObj = GetLength(Coord_P1, Coord_P2);
            // 2021.04.05 jyh 고객님께서 무주건 L-Check를 사용하고 싶다고 하신다.
            //var use = (Options as Algo_C_PanelAttachDefaultOptions).UseLCheck.Value;
            var use = OnOff.On;

            if (spec_Length == 0 || tor_Length == 0)
            {
                lastJudgement = false;
                errorCode = AlgoActionBase.Err_LCheck_Info_Missing;
                return lastJudgement;
            }

            if (use == OnOff.On&& spec_Length != 0 && tor_Length != 0 && lastJudgement)
            {
                if (Math.Abs(spec_Length - mLengthObj) > tor_Length)
                {
                    lastJudgement = false;
                    errorCode = AlgoActionBase.Err_Length_Check;

                    DrawErrDisp("Err_Length_Check", P1_DisplayObj);
                    DrawErrDisp("Err_Length_Check", P2_DisplayObj);
                    Obj_P1.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Obj_P2.DisplayObj.Judgement = (uint)Judgement.L_Check;

                    Obj_P1.Tool.ProcMode = ProcessMode.Manual; Obj_P2.Tool.ProcMode = ProcessMode.Manual;
                }
            }
            #endregion


            #region Draw Label
            DrawMainLabel();
            #endregion




            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo_C_PanelAttachResult3P
            {
                Name = name,
                ID = sourceID,
                Result = lastJudgement,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Rev1X = Math.Round(mRevAlign.X, 3),
                Rev1Y = Math.Round(mRevAlign.Y, 3),
                Rev1T = Math.Round(mRevAlign.T, 3),

                //Rev2X = Math.Round(mRevUnload.X, 3),
                //Rev2Y = Math.Round(mRevUnload.Y, 3),
                //Rev2T = Math.Round(mRevUnload.T, 3),

                PlcOffset1 = markLOffset.X,
                PLCOffset2 = markLOffset.Y,
                PLCOffset3 = markROffset.X,
                PLCOffset4 = markROffset.Y,
                PLCOffset5 = holeOffset.X,
                PLCOffset6 = holeOffset.Y,

                Length = Math.Round(mLengthObj, 3),

                P1_X = Math.Round(Obj_P1.OutputXYT.X, 3),  //Mark Pixel 좌표
                P1_Y = Math.Round(Obj_P1.OutputXYT.Y, 3),
                P2_X = Math.Round(Obj_P2.OutputXYT.X, 3),
                P2_Y = Math.Round(Obj_P2.OutputXYT.Y, 3),
                P3_X = Math.Round(Obj_H1.OutputXYT.X, 3),
                P3_Y = Math.Round(Obj_H1.OutputXYT.Y, 3),

                C1_X = Math.Round(Coord_P1.X, 3),
                C1_Y = Math.Round(Coord_P1.Y, 3),
                C2_X = Math.Round(Coord_P2.X, 3),
                C2_Y = Math.Round(Coord_P2.Y, 3),
                C3_X = Math.Round(Coord_H1.X, 3),
                C3_Y = Math.Round(Coord_H1.Y, 3),

                Type = CalcType.ToString(),
                Pnl_T = Math.Round(pnlT / rad, 3),
                Ref_T = Math.Round(refT / rad, 3),
                Cam_T = Math.Round(camT / rad, 3),    //camT=0인데 의미가 있나

                HistL = HistoValue_L,
                HistR = HistoValue_R
            };

            /// 2020.12.17 hdy multi grid 설정용,,
            MultiGridViewObject?.SetResult(this.multiGridName, AlgoRst); //이게 맞는지 확인필요
            #endregion
            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            //#endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO(AlgoRst);
            #endregion
            return lastJudgement;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Coord_Ref_P1"></param>
        /// <param name="Coord_Ref_P2"></param>
        /// <param name="Coord_Ref_H1"></param>
        /// <param name="Coord_P1"></param>
        /// <param name="Coord_P2"></param>
        /// <param name="Coord_H1"></param>
        /// <returns></returns>
        double Get3PTheta(XY Coord_Ref_P1, XY Coord_Ref_P2, XY Coord_Ref_H1, XY Coord_P1, XY Coord_P2, XY Coord_H1)
        {
            var refT1 = GetThetaColumn(Coord_Ref_P1.X, Coord_Ref_P2.X, Coord_Ref_P1.Y, Coord_Ref_P2.Y);
            var refT2 = GetThetaColumn(Coord_Ref_P2.X, Coord_Ref_H1.X, Coord_Ref_P2.Y, Coord_Ref_H1.Y);
            var refT3 = GetThetaColumn(Coord_Ref_H1.X, Coord_Ref_P1.X, Coord_Ref_H1.Y, Coord_Ref_P1.Y);

            var pnlT1 = GetThetaColumn(Coord_P1.X, Coord_P2.X, Coord_P1.Y, Coord_P2.Y);
            var pnlT2 = GetThetaColumn(Coord_P2.X, Coord_H1.X, Coord_P2.Y, Coord_H1.Y);
            var pnlT3 = GetThetaColumn(Coord_H1.X, Coord_P1.X, Coord_H1.Y, Coord_P1.Y);

            var refT = (refT1 + refT2 + refT3) / 3;
            var pnlT = (pnlT1 + pnlT2 + pnlT3) / 3;

            return NormalizeTheta(refT - pnlT);
        }

        [NonSerialized]
        List<double> mP1GapX = new List<double>();
        [NonSerialized]
        List<double> mP1GapY = new List<double>();
        [NonSerialized]
        List<double> mP2GapX = new List<double>();
        [NonSerialized]
        List<double> mP2GapY = new List<double>();
        [NonSerialized]
        List<double> mH1GapX = new List<double>();
        [NonSerialized]
        List<double> mH1GapY = new List<double>();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool AlignSimulation(CalcType calcType, double radT, XY Coord_Ref_P1, XY Coord_Ref_P2, XY Coord_Ref_H1, XY Coord_P1, XY Coord_P2, XY Coord_H1)
        {
            // P1번 포인트 Drift 량, 차이값
            var DriftX_P1 = Math.Cos(radT) * Coord_P1.X - Math.Sin(radT) * Coord_P1.Y;
            var DriftY_P1 = Math.Sin(radT) * Coord_P1.X + Math.Cos(radT) * Coord_P1.Y;

            // P2번 포인트 Drift 량, 차이값
            var DriftX_P2 = Math.Cos(radT) * Coord_P2.X - Math.Sin(radT) * Coord_P2.Y;
            var DriftY_P2 = Math.Sin(radT) * Coord_P2.X + Math.Cos(radT) * Coord_P2.Y;

            // H1번 포인트 Drift 량, 차이값
            var DriftX_H1 = Math.Cos(radT) * Coord_H1.X - Math.Sin(radT) * Coord_H1.Y;
            var DriftY_H1 = Math.Sin(radT) * Coord_H1.X + Math.Cos(radT) * Coord_H1.Y;

            var P1Move = new XY(DriftX_P1 + mRevAlign.X, DriftY_P1 + mRevAlign.Y);
            var P2Move = new XY(DriftX_P2 + mRevAlign.X, DriftY_P2 + mRevAlign.Y);
            var H1Move = new XY(DriftX_H1 + mRevAlign.X, DriftY_H1 + mRevAlign.Y);

            var P1Diff = Coord_Ref_P1 - P1Move;
            var P2Diff = Coord_Ref_P2 - P2Move;
            //var H1Diff = new XY(Math.Abs(Coord_Ref_H1.X - H1Move.X), Math.Abs(Coord_Ref_H1.Y - H1Move.Y));
            var H1Diff = Coord_Ref_H1 - H1Move;

            if (mP1GapX == null)
            {
                mP1GapX = new List<double>();
                mP1GapY = new List<double>();
                mP2GapX = new List<double>();
                mP2GapY = new List<double>();
                mH1GapX = new List<double>();
                mH1GapY = new List<double>();
            }

            mP1GapX.Add(P1Diff.X); mP1GapY.Add(P1Diff.Y);
            mP2GapX.Add(P2Diff.X); mP2GapY.Add(P2Diff.Y);
            mH1GapX.Add(H1Diff.X); mH1GapY.Add(H1Diff.Y);

            var p1MinMax_X = mP1GapX.Max() - mP1GapX.Min();
            var p1MinMax_Y = mP1GapY.Max() - mP1GapY.Min();
            var p2MinMax_X = mP2GapX.Max() - mP2GapX.Min();
            var p2MinMax_Y = mP2GapY.Max() - mP2GapY.Min();
            var h1MinMax_X = mH1GapX.Max() - mH1GapX.Min();
            var h1MinMax_Y = mH1GapY.Max() - mH1GapY.Min();

            Console.WriteLine("********** Type : " + calcType.ToString() + " / Count : " + mP1GapX.Count.ToString());

            Console.WriteLine("P1_Gap X : " + P1Diff.X.ToString() + " Y : " + P1Diff.Y.ToString());
            Console.WriteLine("P2_Gap X : " + P2Diff.X.ToString() + " Y : " + P2Diff.Y.ToString());
            Console.WriteLine("H1_Gap X : " + H1Diff.X.ToString() + " Y : " + H1Diff.Y.ToString());

            Console.WriteLine("P1_MinMax X : " + p1MinMax_X.ToString() + " Y : " + p1MinMax_Y.ToString());
            Console.WriteLine("P2_MinMax X : " + p2MinMax_X.ToString() + " Y : " + p2MinMax_Y.ToString());
            Console.WriteLine("H1_MinMax X : " + h1MinMax_X.ToString() + " Y : " + h1MinMax_Y.ToString());

            return true;
        }


        /// <summary>
        /// 
        /// </summary>
        bool DrawMainLabel()
        {
            if (PlcValues.ContainsKey("RobotDirection") && PlcValues.ContainsKey("PickupLift"))
            {
                string temp_robot = string.Format("{0} Lift - {1}", PlcValues["PickupLift"].CurValue, (int)PlcValues["RobotDirection"].CurValue == 2 ? "180deg" : "0deg");

                SystemFunc.GetApp().Dispatcher.BeginInvoke(new Action(delegate
                {
                    DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 50), string.Format(" Lift {0} - {1}", PlcValues["PickupLift"].CurValue, (int)PlcValues["RobotDirection"].CurValue == 2 ? "180deg" : "0deg"));
                }));
            }


            double offset1 = PlcValues.ContainsKey("Offset#1") ? (double)PlcValues["Offset#1"].CurValue : 0.0;
            double offset2 = PlcValues.ContainsKey("Offset#2") ? (double)PlcValues["Offset#2"].CurValue : 0.0;
            double offset3 = PlcValues.ContainsKey("Offset#3") ? (double)PlcValues["Offset#3"].CurValue : 0.0;
            double offset4 = PlcValues.ContainsKey("Offset#4") ? (double)PlcValues["Offset#4"].CurValue : 0.0;
            double offset5 = PlcValues.ContainsKey("Offset#5") ? (double)PlcValues["Offset#5"].CurValue : 0.0;
            double offset6 = PlcValues.ContainsKey("Offset#6") ? (double)PlcValues["Offset#6"].CurValue : 0.0;

            if(!(offset1 == 0 && offset2 == 0 && offset3 == 0 && offset4 == 0 && offset5 == 0 && offset6 == 0))
            {
                SystemFunc.GetApp().Dispatcher.BeginInvoke(new Action(delegate
                {
                    DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 50), string.Format("Offset Lx : {0:f3}mm, Ly : {1:f3}mm", offset1, offset2));
                    //DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 50), string.Format("Offset Ly : {0:f3}mm", offset2));
                    DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P2_DisplayObj) - 50), string.Format("Offset Rx : {0:f3}mm, Ry : {1:f3}mm", offset3, offset4));
                    //DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P2_DisplayObj) - 50), string.Format("Offset Ry : {0:f3}mm", offset4));
                    DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 150), string.Format("Offset Hx : {0:f3}mm, Hy : {1:f3}mm", offset5, offset6));
                    //DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 150), string.Format("Offset Hy : {0:f3}mm", offset6));
                }));
            }

            return true;
        }

    }

}
