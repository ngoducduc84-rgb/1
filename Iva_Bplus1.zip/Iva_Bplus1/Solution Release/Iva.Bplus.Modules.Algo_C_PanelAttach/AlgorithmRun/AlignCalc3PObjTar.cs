﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Iva.Bplus.Struct;
using Iva.Bplus.Enums;
using Cognex.VisionPro;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public partial class Algo_C_PanelAttachObject : AlgoObjectBase
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool AlignCalc3PObjTar()
        {
            string model = SystemModel.GetCurModel();
            //errorCode = 0;
            lastJudgement = true;

            #region PLC IOs Update
            AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2") || !InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2") || !InputValues.ContainsKey("Outputs"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            var Tar_P1 = InputValues["Tar_P1"] as IPointResult;
            var Tar_P2 = InputValues["Tar_P2"] as IPointResult;
            var Obj_P1 = InputValues["Obj_P1"] as IPointResult;
            var Obj_P2 = InputValues["Obj_P2"] as IPointResult;

            Dictionary<string, object> Outputs = InputValues["Outputs"] as Dictionary<string, object>;
            var PanelHole = Outputs["PanelHole"] as CogCircle;
            var TapeHole = Outputs["TapleHole"] as CogCircle;

            if (Tar_P1 == null || Tar_P2 == null || Obj_P1 == null || Obj_P2 == null || PanelHole == null || TapeHole == null)
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }
            #endregion

            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null || P2_CalDataObj == null || H1_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                DrawErrDisp("Err_CalData_Is_Null");
                return false;
            }

            mRobot_Tar_P1 = P1_CalDataObj.GetV2R(model, new XY(Tar_P1.OutputXYT.X, Tar_P1.OutputXYT.Y));
            mRobot_Tar_P2 = P2_CalDataObj.GetV2R(model, new XY(Tar_P2.OutputXYT.X, Tar_P2.OutputXYT.Y));
            mRobot_Obj_P1 = P1_CalDataObj.GetV2R(model, new XY(Obj_P1.OutputXYT.X, Obj_P1.OutputXYT.Y));
            mRobot_Obj_P2 = P2_CalDataObj.GetV2R(model, new XY(Obj_P2.OutputXYT.X, Obj_P2.OutputXYT.Y));
            mRobot_Panel_H = H1_CalDataObj.GetV2R(model, new XY(PanelHole.CenterX, PanelHole.CenterY));
            mRobot_Tape_H = H1_CalDataObj.GetV2R(model, new XY(TapeHole.CenterX, TapeHole.CenterY));


            var Coord_Tar_P1 = mRobot_Tar_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_Tar_P2 = mRobot_Tar_P2 + P2_CalDataObj.GetRotateCenter(model);
            var Coord_Tar_H1 = mRobot_Tape_H + H1_CalDataObj.GetRotateCenter(model);

            var Coord_Obj_P1 = mRobot_Obj_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_Obj_P2 = mRobot_Obj_P2 + P2_CalDataObj.GetRotateCenter(model);
            var Coord_Obj_H1 = mRobot_Panel_H + H1_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            #endregion

            #region Calc Rev Offset
            double tarT = GetThetaColumn(Coord_Tar_P1.X, Coord_Tar_P2.X, Coord_Tar_P1.Y, Coord_Tar_P2.Y);
            double objT = GetThetaColumn(Coord_Obj_P1.X, Coord_Obj_P2.X, Coord_Obj_P1.Y, Coord_Obj_P2.Y);

            var tarP = (Coord_Tar_P1 + Coord_Tar_P2) / 2;
            var objP = (Coord_Obj_P1 + Coord_Obj_P2) / 2;

            var alignOffset = CvtPLCIO.OffsetXYT;

            var tarxyt = new XYT(tarP.X, tarP.Y, tarT);
            var objxyt = new XYT(objP.X, objP.Y, objT);

            mRevAlign = new XYT();
            mRevUnload = new XYT();
            double radT, DriftX, DriftY;

            if (CalcType == CalcType.Hole_3P)
            {
                // Attach 위치 보정값 계산. 
                tarxyt = ApplyTargetOffset(alignOffset, ref Coord_Tar_P1, ref Coord_Tar_P2, ref Coord_Tar_H1);
                radT = NormalizeTheta(tarxyt.T - objxyt.T);

                DriftX = Math.Cos(radT) * Coord_Obj_H1.X - Math.Sin(radT) * Coord_Obj_H1.Y;
                DriftY = Math.Sin(radT) * Coord_Obj_H1.X + Math.Cos(radT) * Coord_Obj_H1.Y;
                mRevAlign.X = Coord_Tar_H1.X - DriftX;
                mRevAlign.Y = Coord_Tar_H1.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else  //역방향
                    mRevAlign.T = (radT / rad) * -1;
            }
            else if (CalcType == CalcType.Center_3P)
            {
                // Attach 위치 보정값 계산. 
                tarxyt = ApplyTargetOffset(alignOffset, ref Coord_Tar_P1, ref Coord_Tar_P2, ref Coord_Tar_H1);
                radT = NormalizeTheta(tarxyt.T - objxyt.T);

                DriftX = Math.Cos(radT) * objP.X - Math.Sin(radT) * objP.Y;
                DriftY = Math.Sin(radT) * objP.X + Math.Cos(radT) * objP.Y;
                mRevAlign.X = tarxyt.X - DriftX;
                mRevAlign.Y = tarxyt.Y - DriftY;
                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else  //역방향
                    mRevAlign.T = (radT / rad) * -1;
            }
            else if(CalcType == CalcType.Moving_3P)
            {
                // Attach 위치 보정값 계산. 
                tarxyt = ApplyTargetOffset(alignOffset, ref Coord_Tar_P1, ref Coord_Tar_P2, ref Coord_Tar_H1);
                radT = NormalizeTheta(tarxyt.T - objxyt.T);

                // 포인트별 이동량 평균으로 XY 이동량을 정한다.
                // P1번 포인트 Drift 량, 차이값
                DriftX = Math.Cos(radT) * Coord_Obj_P1.X - Math.Sin(radT) * Coord_Obj_P1.Y;
                DriftY = Math.Sin(radT) * Coord_Obj_P1.X + Math.Cos(radT) * Coord_Obj_P1.Y;
                mP1Moving = new XY(Coord_Tar_P1.X - DriftX, Coord_Tar_P1.Y - DriftY);

                // P2번 포인트 Drift 량, 차이값
                DriftX = Math.Cos(radT) * Coord_Obj_P2.X - Math.Sin(radT) * Coord_Obj_P2.Y;
                DriftY = Math.Sin(radT) * Coord_Obj_P2.X + Math.Cos(radT) * Coord_Obj_P2.Y;
                mP2Moving = new XY(Coord_Tar_P2.X - DriftX, Coord_Tar_P2.Y - DriftY);

                // H1번 포인트 Drift 량, 차이값
                DriftX = Math.Cos(radT) * Coord_Obj_H1.X - Math.Sin(radT) * Coord_Obj_H1.Y;
                DriftY = Math.Sin(radT) * Coord_Obj_H1.X + Math.Cos(radT) * Coord_Obj_H1.Y;
                mH1Moving = new XY(Coord_Obj_H1.X - DriftX, Coord_Obj_H1.Y - DriftY);

                mRevAlign.X = (1 * mP1Moving.X + 1 * mP1Moving.X + 1 * mP1Moving.X) / 3;
                mRevAlign.Y = (1 * mP1Moving.Y + 1 * mP1Moving.Y + 1 * mP1Moving.Y) / 3;

                if (ThetaDirection == ThetaDirection.Normal)    //정방향
                    mRevAlign.T = radT / rad;
                else  //역방향
                    mRevAlign.T = (radT / rad) * -1;
            }

            #endregion

            #region Confirm Result (Align Spec Over Check)
            #endregion

            #region Calc Length & Confirm (Length Check)
            #endregion

            #region Result Data Update(DataGridView Insert)
            #endregion
            //#endregion

            #region Vision Write (Result & FDC)
            #endregion

            return lastJudgement;
        }

    }
}
