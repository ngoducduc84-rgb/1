﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Iva.Bplus.Struct;
using Iva.Bplus.Enums;
using Cognex.VisionPro;
using System.Windows;
using Iva.Bplus.Modules.CogDisplay;
using Telerik.Windows.Controls;
using Cognex.VisionPro.ToolBlock;
using System.Runtime.InteropServices;
using Iva.Bplus.ViewModels;
using System.Drawing;
using Cognex.VisionPro.Display;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public partial class Algo_C_PanelAttachObject : AlgoObjectBase
    {
        #region 2021.04.01 hdy  confirm 창 관련 추가
        [field: NonSerialized]
        public bool bConfirm = false;
        [field: NonSerialized]
        public string schName = "";
        [field: NonSerialized]
        bool bLMarkConfirm = false;
        [field: NonSerialized]
        bool bRMarkConfirm = false;
        [field: NonSerialized]
        bool bHoleConfirm = false;
        [field: NonSerialized]
        IPointResult mTar_P1;
        [field: NonSerialized]
        IPointResult mTar_P2;
        [field: NonSerialized]
        IPointResult mObj_P1;
        [field: NonSerialized]
        IPointResult mObj_P2;
        [field: NonSerialized]
        CogCircle mPanelHole;
        [field: NonSerialized]
        CogCircle mTapeHole;
        // 21.05.25 hdy hole 대신 edge 정보를 사용할 경우..
        [field: NonSerialized]
        IPointResult mPanel_Edge;
        [field: NonSerialized]
        IPointResult mTape_Edge;

        ManualConfirmMark panelConfirm_L = new ManualConfirmMark();
        ManualConfirmMark tapeConfirm_L = new ManualConfirmMark();
        ManualConfirmMark panelConfirm_R = new ManualConfirmMark();
        ManualConfirmMark tapeConfirm_R = new ManualConfirmMark();
        ManualConfirmMark panelConfirm_H = new ManualConfirmMark();
        ManualConfirmMark tapeConfirm_H = new ManualConfirmMark();
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool Inspection()
        {
            string model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudgement = true;
            // 2021.04.06 hdy 메뉴얼 컨펌 유무 체크
            bLMarkConfirm = bRMarkConfirm = bHoleConfirm = false;

            #region PLC IOs Update
            //AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            int Is2PointAlign = PlcValues.ContainsKey("Is_2Point_Align") ? (int)PlcValues["Is_2Point_Align"].CurValue : 0;

            #region Inspection Mark
            InspectionMark();
            #endregion

            #region Inspection Hole To Hole
            mObjToTapeXY_APC = new XY();
            mObjToTapeXY_APC.X = mObjToTapeXY_APC.Y = 1;

            if (Is2PointAlign != 2 && mInspType == InspType.Hole)
                InspectionHole();
            else if (Is2PointAlign != 2 && mInspType == InspType.Edge)
                InspectionEdge();
            else
                InspectionHole_Init();
            #endregion

            #region Manual Confirm Process
            ManualConfrimProcess();
            #endregion

            #region Inspection chart Set
            InsertResultData(mMarkSpec, mMarkTor, mHoleSpec, mHoleTor);
            #endregion

            #region Inspection Hole To Hole
            //AlignCalc3PObjTar();
            #endregion

            lastJudgement = errorCode == 0 ? true : false;
            //#endregion

            #region Calc Offset
            GetOffsetVAlue();
            #endregion

            #region Draw Label
            DrawResultLabel();
            #endregion

            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo_C_PanelAttachReslutIns
            {
                Name = name,
                ID = sourceID,
                T_ID = destID,

                Result = lastJudgement,
                // 2021.04.06 hdy 메뉴얼 컨펌 유무 체크
                NotConfirm = !bLMarkConfirm && !bRMarkConfirm && !bHoleConfirm,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Lx = Math.Round(mInspResult.Lx, 3),
                Ly = Math.Round(mInspResult.Ly, 3),
                Rx = Math.Round(mInspResult.Rx, 3),
                Ry = Math.Round(mInspResult.Ry, 3),
                T = Math.Round(mThetaRst, 3),

                Lx_APC = Math.Round(mInspResult.Lx * mInspResult_APC.Lx, 3),
                Ly_APC = Math.Round(mInspResult.Ly * mInspResult_APC.Ly, 3),
                Rx_APC = Math.Round(mInspResult.Rx * mInspResult_APC.Rx, 3),
                Ry_APC = Math.Round(mInspResult.Ry * mInspResult_APC.Ry, 3),

                Hx = Math.Round(mObjToTapeXY.X - mHoleSpec.X, 3),
                Hy = Math.Round(mObjToTapeXY.Y - mHoleSpec.Y, 3),
                Hd = Math.Round(mObjToTapeD, 3),

                LxDiff = Math.Round(mMarkDiff.Lx, 3),
                LyDiff = Math.Round(mMarkDiff.Ly, 3),
                RxDiff = Math.Round(mMarkDiff.Rx, 3),
                RyDiff = Math.Round(mMarkDiff.Ry, 3),
                HxDiff = Math.Round(mHoleDiff.X, 3),
                HyDiff = Math.Round(mHoleDiff.Y, 3),
                LxOffset = Math.Round(mMarkOffset.Lx, 3),
                LyOffset = Math.Round(mMarkOffset.Ly, 3),
                RxOffset = Math.Round(mMarkOffset.Rx, 3),
                RyOffset = Math.Round(mMarkOffset.Ry, 3),
                HxOffset = Math.Round(mHoleOffset.X, 3),
                HyOffset = Math.Round(mHoleOffset.Y, 3),

                H_Top = Math.Round(mCircleToCircle[(int)ePos.Top], 3),
                H_Bottom = Math.Round(mCircleToCircle[(int)ePos.Bottom], 3),
                H_Left = Math.Round(mCircleToCircle[(int)ePos.Left], 3),
                H_Right = Math.Round(mCircleToCircle[(int)ePos.Right], 3),

                Length_tar = Math.Round(mLengthTar, 3),
                Length_obj = Math.Round(mLengthObj, 3),

                Obj_Rt_X1 = Math.Round(mRobot_Obj_P1.X, 3),
                Obj_Rt_Y1 = Math.Round(mRobot_Obj_P1.Y, 3),
                Tar_Rt_X1 = Math.Round(mRobot_Tar_P1.X, 3),
                Tar_Rt_Y1 = Math.Round(mRobot_Tar_P1.Y, 3),

                Obj_Rt_X2 = Math.Round(mRobot_Obj_P2.X, 3),
                Obj_Rt_Y2 = Math.Round(mRobot_Obj_P2.Y, 3),
                Tar_Rt_X2 = Math.Round(mRobot_Tar_P2.X, 3),
                Tar_Rt_Y2 = Math.Round(mRobot_Tar_P2.Y, 3),

                ObjHole_Rt_X = Math.Round(mRobot_Panel_H.X, 3),
                ObjHole_Rt_Y = Math.Round(mRobot_Panel_H.Y, 3),
                TarHole_Rt_X = Math.Round(mRobot_Tape_H.X, 3),
                TarHole_Rt_Y = Math.Round(mRobot_Tape_H.Y, 3),
            };

            #endregion
            SystemLogger.WriteAlignDBLog(name, AlgoRst);

            #region Vision Write (Result & FDC)
            WriteVisionIO(AlgoRst);
            #endregion

            return lastJudgement;
        }

        /// <summary>
        /// offset을 모아서 계산한다.
        /// </summary>
        bool GetOffsetVAlue()
        {
            if (mQDiffMarkLx == null) mQDiffMarkLx = new Queue<double>();
            if (mQDiffMarkLy == null) mQDiffMarkLy = new Queue<double>();
            if (mQDiffMarkRx == null) mQDiffMarkRx = new Queue<double>();
            if (mQDiffMarkRy == null) mQDiffMarkRy = new Queue<double>();
            if (mQDiffHoleX == null) mQDiffHoleX = new Queue<double>();
            if (mQDiffHoleY == null) mQDiffHoleY = new Queue<double>();
            if (mMarkOffset == null) mMarkOffset = new XYXY();
            if (mHoleOffset == null) mHoleOffset = new XY();
            mMarkOffset.Lx = CalcOffset(mQDiffMarkLx, CalcOffsetNum, CalcOffsetRange, mMarkDiff.Lx);
            mMarkOffset.Ly = CalcOffset(mQDiffMarkLy, CalcOffsetNum, CalcOffsetRange, mMarkDiff.Ly);
            mMarkOffset.Rx = CalcOffset(mQDiffMarkRx, CalcOffsetNum, CalcOffsetRange, mMarkDiff.Rx);
            mMarkOffset.Ry = CalcOffset(mQDiffMarkRy, CalcOffsetNum, CalcOffsetRange, mMarkDiff.Ry);
            mHoleOffset.X = CalcOffset(mQDiffHoleX, CalcOffsetNum, CalcOffsetRange, mHoleDiff.X);
            mHoleOffset.Y = CalcOffset(mQDiffHoleY, CalcOffsetNum, CalcOffsetRange, mHoleDiff.Y);

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="queue"></param>
        /// <param name="num"></param>
        /// <param name="range"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        double CalcOffset(Queue<double> queue, int num, int range, double value)
        {
            //
            if (num == 0) return value;
            //
            //if (queue == null) queue = new Queue<double>();
            //
            if (lastJudgement) queue.Enqueue(value);
            //
            if (queue.Count > num) queue.Dequeue();
            //
            if (queue.Count == 0) return value;
            return queue.Average();
        }

        /// <summary>
        /// 
        /// </summary>
        bool DrawResultLabel()
        {
            string model = SystemModel.GetCurModel();

            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsIns;

            var tor_Lx = (double)mParams.Tor_Lx.Value;
            var tor_Ly = (double)mParams.Tor_Ly.Value;
            var tor_Rx = (double)mParams.Tor_Rx.Value;
            var tor_Ry = (double)mParams.Tor_Ry.Value;
            var tor_T = (double)mParams.Tor_T.Value;
            var tor_Hx = (double)mParams.Tor_HoleX.Value;
            var tor_Hy = (double)mParams.Tor_HoleY.Value;
            var tor_Hd = (double)mParams.Tor_HoleD.Value;

            SystemFunc.GetApp().Dispatcher.BeginInvoke(new Action(delegate
            {
                // 2021.04.06 hdy 컨펌 유무 화면 표시
                if (bLMarkConfirm)
                {
                    DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 250), string.Format("L Mark Manual Confirm"), CogGraphicLabelAlignmentConstants.TopLeft, CogColorConstants.Red);
                }
                if (bRMarkConfirm)
                {
                    DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P2_DisplayObj) - 250), string.Format("R Mark Manual Confirm"), CogGraphicLabelAlignmentConstants.TopLeft, CogColorConstants.Red);
                }
                DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 150), string.Format("Lx : {0:f3}mm ({1:f3}mm, avg: {2:f3}mm)", mInspResult.Lx, mMarkDiff.Lx, mMarkOffset.Lx), mMarkDiff.Lx, tor_Lx);
                DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 100), string.Format("Ly : {0:f3}mm ({1:f3}mm, avg: {2:f3}mm)", mInspResult.Ly, mMarkDiff.Ly, mMarkOffset.Ly), mMarkDiff.Ly, tor_Ly);
                DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P2_DisplayObj) - 150), string.Format("Rx : {0:f3}mm ({1:f3}mm, avg: {2:f3}mm)", mInspResult.Rx, mMarkDiff.Rx, mMarkOffset.Rx), mMarkDiff.Rx, tor_Rx);
                DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P2_DisplayObj) - 100), string.Format("Ry : {0:f3}mm ({1:f3}mm, avg: {2:f3}mm)", mInspResult.Ry, mMarkDiff.Ry, mMarkOffset.Ry), mMarkDiff.Ry, tor_Ry);
                DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 50), string.Format("T : {0:f3}Deg", mThetaRst), mThetaRst, tor_T);
                // Hole Result
                if(bHoleConfirm)
                {
                    DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 800), string.Format("Hole Mark Manual Confirm"), CogGraphicLabelAlignmentConstants.TopLeft, CogColorConstants.Red);
                }
                //DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 500), string.Format("X : {0:f3}mm ({1:f3}mm, avg: {2:f3}mm)", mObjToTapeXY.X, mHoleDiff.X, mHoleOffset.X), mHoleDiff.X, tor_Hx);
                //DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 350), string.Format("Y : {0:f3}mm ({1:f3}mm, avg: {2:f3}mm)", mObjToTapeXY.Y, mHoleDiff.Y, mHoleOffset.Y), mHoleDiff.Y, tor_Hy);
                DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 500), string.Format("X : {0:f3}mm ({1:f3}mm, avg: {2:f3}mm)", mObjToTapeXY.X, mObjToTapeXY.X - mHoleSpec.X, mHoleOffset.X), mObjToTapeXY.X - mHoleSpec.X, tor_Hx);
                DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 350), string.Format("Y : {0:f3}mm ({1:f3}mm, avg: {2:f3}mm)", mObjToTapeXY.Y, mObjToTapeXY.Y - mHoleSpec.Y, mHoleOffset.Y), mObjToTapeXY.X - mHoleSpec.Y, tor_Hy);
                if (mInspType != InspType.Edge)
                    DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 200), string.Format("D : {0:f3}mm", mObjToTapeD), mObjToTapeD, tor_Hd);
            }));

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool InspectionMark()
        {
            string model = SystemModel.GetCurModel();

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Tar_P1") || !InputValues.ContainsKey("Tar_P2") || !InputValues.ContainsKey("Obj_P1") || !InputValues.ContainsKey("Obj_P2"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            var Tar_P1 = InputValues["Tar_P1"] as IPointResult;
            var Tar_P2 = InputValues["Tar_P2"] as IPointResult;
            var Obj_P1 = InputValues["Obj_P1"] as IPointResult;
            var Obj_P2 = InputValues["Obj_P2"] as IPointResult;

            if (Tar_P1 == null || Tar_P2 == null || Obj_P1 == null || Obj_P2 == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            // 2021.04.06 hdy manual confirm 용..
            mTar_P1 = Tar_P1;
            mTar_P2 = Tar_P2;
            mObj_P1 = Obj_P1;
            mObj_P2 = Obj_P2;

            SetMarkInfo(ref mTar_Mark1, Tar_P1);
            SetMarkInfo(ref mTar_Mark2, Tar_P2);
            SetMarkInfo(ref mObj_Mark1, Obj_P1);
            SetMarkInfo(ref mObj_Mark2, Obj_P2);
            #endregion

            // spec NG일 경우 해당 tape(target) mark deep learning 요청하여 재 시도 해본다..
            if (!AttachInspection(model, Tar_P1, Tar_P2, Obj_P1, Obj_P2))
            {
                XYT rstXYT;
                Rect rstRect;
                string err;
                bool needRework = false;

                if (IsTargetLeftNG)
                {
                    // find d/l tar_p1 
                    var tool = Tar_P1.Tool.ModObject as ToolObjectBase;
                    // request d/l search
                    if (tool.FindSDC_DL(Name, SourceID, tool.InputImage, out rstXYT, out rstRect, out err))
                    {
                        tool.DisplayObj.DrawDLOverlay(rstXYT, rstRect);
                        P1_DisplayObj.ClearOverlay();
                        // set target pos
                        Tar_P1.OutputXYT = rstXYT;
                        needRework = true;
                    } 
                }

                if (IsTargetRightNG)
                {
                    // find d/l tar_p2 
                    var tool = Tar_P2.Tool.ModObject as ToolObjectBase;
                    // request d/l search
                    if (tool.FindSDC_DL(Name, SourceID, tool.InputImage, out rstXYT, out rstRect, out err))
                    {
                        tool.DisplayObj.DrawDLOverlay(rstXYT, rstRect);
                        P2_DisplayObj.ClearOverlay();
                        // set target pos
                        Tar_P2.OutputXYT = rstXYT;
                        needRework = true;
                    }
                }

                if (needRework)
                {
                    ErrorCode = 0;
                    P1_DisplayObj.ClearLabels();
                    P2_DisplayObj.ClearLabels();
                    H1_DisplayObj.ClearLabels();

                    return AttachInspection(model, Tar_P1, Tar_P2, Obj_P1, Obj_P2);
                }
            }
            else
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 컨펌창 확인 후 재 계산 로직..
        /// </summary>
        /// <returns></returns>
        private bool ConfirmInspectionMark()
        {
            string model = SystemModel.GetCurModel();

            P1_DisplayObj.ClearGraphic();
            P2_DisplayObj.ClearGraphic();

            if(tapeConfirm_L != null && tapeConfirm_L.Result != null) mTar_P1.OutputXYT = new XYT(tapeConfirm_L.Result);
            if (tapeConfirm_R != null && tapeConfirm_R.Result != null) mTar_P2.OutputXYT = new XYT(tapeConfirm_R.Result);
            if (panelConfirm_L != null && panelConfirm_L.Result != null) mObj_P1.OutputXYT = new XYT(panelConfirm_L.Result);
            if (panelConfirm_R != null && panelConfirm_R.Result != null) mObj_P2.OutputXYT = new XYT(panelConfirm_R.Result);

            P1_DisplayObj.DrawMaker(new CogDrawMarkerInfo(mTar_P1.OutputXYT));
            P1_DisplayObj.DrawMaker(new CogDrawMarkerInfo(mObj_P1.OutputXYT));
            P2_DisplayObj.DrawMaker(new CogDrawMarkerInfo(mTar_P2.OutputXYT));
            P2_DisplayObj.DrawMaker(new CogDrawMarkerInfo(mObj_P2.OutputXYT));

            return AttachInspection(model, mTar_P1, mTar_P2, mObj_P1, mObj_P2);
        }

        /// <summary>
        /// 컨펌 시 이미지 save 진행
        /// </summary>
        /// <param name="name"></param>
        /// <param name="leftNG"></param>
        /// <param name="rightNG"></param>
        /// <param name="holeNG"></param>
        void SaveImageOrigin(string name, bool leftNG, bool rightNG, bool holeNG)
        {
            string _sourceID = DeepClone(sourceID);
            DateTime dateTime = DateTime.Now;

            if (leftNG)
            {
                if (useOriginImage)
                {
                    object obj1 = P1_DisplayObj.GetCurImage();
                    P1_DisplayObj.SaveImage(dateTime, obj1, name, schName, _sourceID, false, ErrorCode, ImageSaveMode.Cam);
                }
            }
            if (rightNG)
            {
                if (useOriginImage)
                {
                    object obj2 = P2_DisplayObj.GetCurImage();
                    P2_DisplayObj.SaveImage(dateTime, obj2, name, schName, _sourceID, false, ErrorCode, ImageSaveMode.Cam);
                }
            }
            if (holeNG)
            {
                if (useOriginImage)
                {
                    object obj3 = H1_DisplayObj.GetCurImage();
                    H1_DisplayObj.SaveImage(dateTime, obj3, name, schName, _sourceID, false, ErrorCode, ImageSaveMode.Cam);
                }
            }
        }

        /// <summary>
        /// 컨펌 시 overlay 이미지 save
        /// </summary>
        /// <param name="name"></param>
        /// <param name="leftNG"></param>
        /// <param name="rightNG"></param>
        /// <param name="holeNG"></param>
        void SaveImageOverlay(string name, bool leftNG, bool rightNG, bool holeNG)
        {
            string _sourceID = DeepClone(sourceID);
            DateTime dateTime = DateTime.Now;

            if (leftNG)
            {
                if(useOverlayImage)
                {
                    object obj1 = (Bitmap)P1_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                    P1_DisplayObj.SaveImage(dateTime, obj1, name, schName, _sourceID, true, ErrorCode, ImageSaveMode.Cam);
                }
            }
            if (rightNG)
            {
                if (useOverlayImage)
                {
                    object obj2 = (Bitmap)P2_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                    P2_DisplayObj.SaveImage(dateTime, obj2, name, schName, _sourceID, true, ErrorCode, ImageSaveMode.Cam);
                }
            }
            if (holeNG)
            {
                if (useOverlayImage)
                {
                    object obj3 = (Bitmap)H1_DisplayObj.CogDs.CreateContentBitmap(CogDisplayContentBitmapConstants.Image, null, 0);
                    H1_DisplayObj.SaveImage(dateTime, obj3, name, schName, _sourceID, true, ErrorCode, ImageSaveMode.Cam);
                }
            }
        }
        
        /// <summary>
        /// opcall 발생
        /// </summary>
        /// <param name="errorCode"></param>
        /// <returns></returns>
        private bool SetOPCallToPLC(int errorCode)
        {
            var commObj = this.CommodObject;
            var IOs = new List<IOStruct>();

            VAlarmCode.NextValue = errorCode;   IOs.Add(VAlarmCode);
            VOpCall.NextValue = true;           IOs.Add(VOpCall);
            VErrorState.NextValue = false;      IOs.Add(VErrorState);
            commObj.SetVisionValues(IOs);

            return true;
        }

        /// <summary>
        /// opcall reset
        /// </summary>
        /// <returns></returns>
        private bool ResetOPCallToPLC()
        {
            var commObj = this.CommodObject;
            var IOs = new List<IOStruct>();

            VAlarmCode.NextValue = 0;       IOs.Add(VAlarmCode);
            VOpCall.NextValue = false;      IOs.Add(VOpCall);
            VErrorState.NextValue = false;  IOs.Add(VErrorState);
            commObj.SetVisionValues(IOs);

            return true;
        }


        /// <summary>
        /// 메뉴얼 컨펌 프로세스...
        /// </summary>
        private void ManualConfrimProcess()
        {
            // 검사 NG 시에만 진행함..
            if (errorCode != AlgoActionBase.Err_Inspection_Spec_Over) return;
            if (!IsTargetLeftNG && !IsTargetRightNG && !IsTargetHoleNG) return;
            if (!bConfirm || !useManualConfirm) return;

            SetOPCallToPLC(errorCode);

            SaveImageOrigin("Confirm_Origin", IsTargetLeftNG, IsTargetRightNG, IsTargetHoleNG);
            SaveImageOverlay("Confirm_Before", IsTargetLeftNG, IsTargetRightNG, IsTargetHoleNG);
            SystemFunc.GetApp().Dispatcher.Invoke(new Action(delegate
            {
                errorCode = 0;
                eConfirmType holeRst = eConfirmType.Cancel;
                eConfirmType LMarkRst = eConfirmType.Cancel;
                eConfirmType RMarkRst = eConfirmType.Cancel;

                if (IsTargetLeftNG)
                {
                    bLMarkConfirm = true;
                    if (panelConfirm_L == null)
                    {
                        panelConfirm_L = new ManualConfirmMark();
                        panelConfirm_L.MarkName = "Panel_L";
                    }
                    panelConfirm_L.IntiPos = mObj_P1.OutputXYT;
                    panelConfirm_L.Image = P1_DisplayObj.GetCurImage();
                    panelConfirm_L.AlgoObject = this;
                    panelConfirm_L.UseCircle = false;

                    if (tapeConfirm_L == null)
                    {
                        tapeConfirm_L = new ManualConfirmMark();
                        tapeConfirm_L.MarkName = "C_Panel_L";
                    }
                    tapeConfirm_L.IntiPos = mTar_P1.OutputXYT;
                    tapeConfirm_L.Image = P1_DisplayObj.GetCurImage();
                    tapeConfirm_L.AlgoObject = this;
                    tapeConfirm_L.UseCircle = false;

                    LMarkRst = ManualMarkProcess("Left Mark", panelConfirm_L, tapeConfirm_L);
                }

                if (IsTargetRightNG)
                {
                    bRMarkConfirm = true;

                    if (panelConfirm_R == null)
                    {
                        panelConfirm_R = new ManualConfirmMark();
                        panelConfirm_R.MarkName = "Panel_R";
                    }
                    panelConfirm_R.IntiPos = mObj_P2.OutputXYT;
                    panelConfirm_R.Image = P2_DisplayObj.GetCurImage();
                    panelConfirm_R.AlgoObject = this;
                    panelConfirm_R.UseCircle = false;

                    if (tapeConfirm_R == null)
                    {
                        tapeConfirm_R = new ManualConfirmMark();
                        tapeConfirm_R.MarkName = "C_Panel_R";
                    }
                    tapeConfirm_R.IntiPos = mTar_P2.OutputXYT;
                    tapeConfirm_R.Image = P2_DisplayObj.GetCurImage();
                    tapeConfirm_R.AlgoObject = this;
                    tapeConfirm_R.UseCircle = false;

                    RMarkRst = ManualMarkProcess("Right Mark", panelConfirm_R, tapeConfirm_R);                    
                }

                if (IsTargetHoleNG)
                {
                    bHoleConfirm = true;

                    if(mInspType == InspType.Hole)
                    {
                        if (panelConfirm_H == null)
                        {
                            panelConfirm_H = new ManualConfirmMark();
                            panelConfirm_H.MarkName = "Panel_Hole";
                        }

                        panelConfirm_H.IntiPos = new XYT(mPanelHole.CenterX, mPanelHole.CenterY);
                        panelConfirm_H.Image = H1_DisplayObj.GetCurImage();
                        panelConfirm_H.AlgoObject = this;
                        panelConfirm_H.UseCircle = true;
                        panelConfirm_H.Radius = mPanelHole.Radius;

                        if (tapeConfirm_H == null)
                        {
                            tapeConfirm_H = new ManualConfirmMark();
                            tapeConfirm_H.MarkName = "C_Panel_Hole";
                        }
                        tapeConfirm_H.IntiPos = new XYT(mTapeHole.CenterX, mTapeHole.CenterY);
                        tapeConfirm_H.Image = H1_DisplayObj.GetCurImage();
                        tapeConfirm_H.AlgoObject = this;
                        tapeConfirm_H.UseCircle = true;
                        tapeConfirm_H.Radius = mTapeHole.Radius;
                    }
                    else
                    {
                        if (panelConfirm_H == null)
                        {
                            panelConfirm_H = new ManualConfirmMark();
                            panelConfirm_H.MarkName = "Panel_Edge";
                        }

                        panelConfirm_H.IntiPos = mPanel_Edge.OutputXYT;
                        panelConfirm_H.Image = H1_DisplayObj.GetCurImage();
                        panelConfirm_H.AlgoObject = this;
                        panelConfirm_H.UseCircle = false;

                        if (tapeConfirm_H == null)
                        {
                            tapeConfirm_H = new ManualConfirmMark();
                            tapeConfirm_H.MarkName = "C_Panel_Edge";
                        }
                        tapeConfirm_H.IntiPos = mTape_Edge.OutputXYT;
                        tapeConfirm_H.Image = H1_DisplayObj.GetCurImage();
                        tapeConfirm_H.AlgoObject = this;
                        tapeConfirm_H.UseCircle = false;
                    }

                    holeRst = ManualMarkProcess("Hole", panelConfirm_H, tapeConfirm_H);
                }

                if (holeRst == eConfirmType.ManualConfirm || LMarkRst == eConfirmType.ManualConfirm || RMarkRst == eConfirmType.ManualConfirm)
                {
                    P1_DisplayObj.ClearLabels();
                    P2_DisplayObj.ClearLabels();
                    H1_DisplayObj.ClearLabels();

                    if (holeRst == eConfirmType.ManualConfirm && mInspType == InspType.Hole)
                    {
                        IsTargetHoleNG = false;
                        ConfirmInspectionHole();
                    }
                    if (holeRst == eConfirmType.ManualConfirm && mInspType == InspType.Edge)
                    {
                        IsTargetHoleNG = false;
                        ConfirmInspectionEdge();
                    }
                    if (LMarkRst == eConfirmType.ManualConfirm || RMarkRst == eConfirmType.ManualConfirm)
                    {
                        IsTargetLeftNG = false;
                        IsTargetRightNG = false;
                        ConfirmInspectionMark();
                    }
                }
                SaveImageOverlay("Confirm_After", bLMarkConfirm, bRMarkConfirm, bHoleConfirm);
            }));

            ResetOPCallToPLC();
        }

        private bool AttachInspection(string model, IPointResult Tar_P1, IPointResult Tar_P2, IPointResult Obj_P1, IPointResult Obj_P2)
        {
            #region Coordinate Pos Calc & CalData Cofirm
            if (P1_CalDataObj == null || P2_CalDataObj == null || H1_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                DrawErrDisp("Err_CalData_Is_Null");
                return false;
            }

            var pTar_P1 = new XY(Tar_P1.OutputXYT.X, Tar_P1.OutputXYT.Y);
            var pTar_P2 = new XY(Tar_P2.OutputXYT.X, Tar_P2.OutputXYT.Y);
            var pObj_P1 = new XY(Obj_P1.OutputXYT.X, Obj_P1.OutputXYT.Y);
            var pObj_P2 = new XY(Obj_P2.OutputXYT.X, Obj_P2.OutputXYT.Y);

            // 2021.03.03 PSJ APC용 부호 적용
            if (mInspResult_APC == null) mInspResult_APC = new XYXY();
            mInspResult_APC.Lx = pTar_P1.X > pObj_P1.X ? 1 : -1;
            mInspResult_APC.Ly = pTar_P1.Y < pObj_P1.Y ? 1 : -1;
            mInspResult_APC.Rx = pTar_P2.X > pObj_P2.X ? 1 : -1;
            mInspResult_APC.Ry = pTar_P2.Y < pObj_P2.Y ? 1 : -1;

            mRobot_Tar_P1 = P1_CalDataObj.GetV2R(model, pTar_P1);
            mRobot_Tar_P2 = P2_CalDataObj.GetV2R(model, pTar_P2);
            mRobot_Obj_P1 = P1_CalDataObj.GetV2R(model, pObj_P1);
            mRobot_Obj_P2 = P2_CalDataObj.GetV2R(model, pObj_P2);

            // 2020.06.03 hdy cam 및 stage moving 량 회전 중심 반영 : 테스트 필요
            //var RotCenter_P1 = GetRotateCenter(P1_CalDataObj, XYDirection.Plus, XYDirection.Plus, XYDirection.Minus, XYDirection.Minus);
            //var RotCenter_P2 = GetRotateCenter(P2_CalDataObj, XYDirection.Plus, XYDirection.Plus, XYDirection.Minus, XYDirection.Minus);

            var Coord_Tar_P1 = mRobot_Tar_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_Tar_P2 = mRobot_Tar_P2 + P2_CalDataObj.GetRotateCenter(model);
            var Coord_Obj_P1 = mRobot_Obj_P1 + P1_CalDataObj.GetRotateCenter(model);
            var Coord_Obj_P2 = mRobot_Obj_P2 + P2_CalDataObj.GetRotateCenter(model);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsIns;
            //var limitX = (double)mParams.LimitX.Value;
            //var limitY = (double)mParams.LimitY.Value;
            //var limitT = (double)mParams.LimitT.Value;

            var scale_Lx = (double)mParams.Scale_Lx.Value;
            var scale_Ly = (double)mParams.Scale_Ly.Value;
            var scale_Rx = (double)mParams.Scale_Rx.Value;
            var scale_Ry = (double)mParams.Scale_Ry.Value;
            var scale_T = (double)mParams.Scale_T.Value;
            var spec_Lx = (double)mParams.Spec_Lx.Value;
            var spec_Ly = (double)mParams.Spec_Ly.Value;
            var spec_Rx = (double)mParams.Spec_Rx.Value;
            var spec_Ry = (double)mParams.Spec_Ry.Value;
            var spec_T = (double)mParams.Spec_T.Value;
            var tor_Lx = (double)mParams.Tor_Lx.Value;
            var tor_Ly = (double)mParams.Tor_Ly.Value;
            var tor_Rx = (double)mParams.Tor_Rx.Value;
            var tor_Ry = (double)mParams.Tor_Ry.Value;
            var tor_T = (double)mParams.Tor_T.Value;

            var length_Obj = (double)mParams.Length_Obj.Value;
            var tor_Obj = (double)mParams.Tor_Obj.Value;
            var length_Tar = (double)mParams.Length_Tar.Value;
            var tor_Tar = (double)mParams.Tor_Tar.Value;
            //var Limit = new XYT(limitX, limitY, limitT);
            mMarkScale = new XYXY(scale_Lx, scale_Ly, scale_Rx, scale_Ry);
            mMarkSpec = new XYXY(spec_Lx, spec_Ly, spec_Rx, spec_Ry);
            mMarkTor = new XYXY(tor_Lx, tor_Ly, tor_Rx, tor_Ry);
            #endregion

            #region Cal Inspection
            if (mMarkDiff == null) mMarkDiff = new XYXY();
            if (Tar_P1 is MatchingRstData)
            {
                if (!CalcDistanceP2P(model, Coord_Tar_P1, Coord_Tar_P2, Coord_Obj_P1, Coord_Obj_P2))
                {
                    errorCode = AlgoActionBase.Err_Failed_To_Calculate_Distance;
                    return false;
                }
                //DrawLineP2P(model, mRobot_Tar_P1, mRobot_Tar_P2, mRobot_Obj_P1, mRobot_Obj_P2);
                MultiplyScale();

                double pnlT = GetTheta(Coord_Obj_P1.X, Coord_Obj_P1.Y, Coord_Obj_P2.X, Coord_Obj_P2.Y);
                double tapeT = GetTheta(Coord_Tar_P1.X, Coord_Tar_P1.Y, Coord_Tar_P2.X, Coord_Tar_P2.Y);
                DrawLineLabel_L(model, mRobot_Tar_P1, mRobot_Obj_P1, pnlT, tapeT, CogColorConstants.Red);
                DrawLineLabel_R(model, mRobot_Tar_P2, mRobot_Obj_P2, pnlT, CogColorConstants.Red);
            }
            else
            {
                if (LineEdgeType == LineCalcType.P2P)
                {
                    if (!CalcDistanceP2P(model, Coord_Tar_P1, Coord_Tar_P2, Coord_Obj_P1, Coord_Obj_P2))
                    {
                        errorCode = AlgoActionBase.Err_Failed_To_Calculate_Distance;
                        return false;
                    }
                    //DrawLineP2P(model, mRobot_Tar_P1, mRobot_Tar_P2, mRobot_Obj_P1, mRobot_Obj_P2);
                    MultiplyScale();

                    double pnlT = GetTheta(Coord_Obj_P1.X, Coord_Obj_P1.Y, Coord_Obj_P2.X, Coord_Obj_P2.Y);
                    double tapeT = GetTheta(Coord_Tar_P1.X, Coord_Tar_P1.Y, Coord_Tar_P2.X, Coord_Tar_P2.Y);
                    DrawLineLabel_L(model, mRobot_Tar_P1, mRobot_Obj_P1, pnlT, tapeT, CogColorConstants.Red);
                    DrawLineLabel_R(model, mRobot_Tar_P2, mRobot_Obj_P2, pnlT, CogColorConstants.Red);
                }
                else if (LineEdgeType == LineCalcType.P2Line)
                {
                    if (!CalcDistanceP2Line(model, Tar_P1, Tar_P2, Obj_P1, Obj_P2))
                    {
                        errorCode = AlgoActionBase.Err_Failed_To_Calculate_Distance;
                        return false;
                    }

                    MultiplyScale();

                    double pnlT = GetTheta(Coord_Obj_P1.X, Coord_Obj_P1.Y, Coord_Obj_P2.X, Coord_Obj_P2.Y);
                    double tapeT = GetTheta(Coord_Tar_P1.X, Coord_Tar_P1.Y, Coord_Tar_P2.X, Coord_Tar_P2.Y);
                    DrawLabelOfUseLine(pnlT, tapeT);
                }
            }

            // 

            #endregion

            #region Calc Length & Confirm (Length Check)
            mLengthTar = GetLength(Coord_Tar_P1, Coord_Tar_P2);
            mLengthObj = GetLength(Coord_Obj_P1, Coord_Obj_P2);
            // 2021.04.05 jyh 고객님께서 무주건 L-Check를 사용하고 싶다고 하신다.
            //var use = (Options as Algo_C_PanelAttachDefaultOptions).UseLCheck.Value;
            var use = OnOff.On;

            if (length_Tar == 0 || length_Obj == 0 || tor_Tar == 0 || tor_Obj == 0)
            {
                lastJudgement = false;
                errorCode = AlgoActionBase.Err_LCheck_Info_Missing;
                return lastJudgement;
            }

            try
            {
                if (use == OnOff.On && !GetLCheck(mLengthTar, length_Tar, tor_Tar))
                {
                    errorCode = AlgoActionBase.Err_Length_Check;
                    Tar_P1.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Tar_P2.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    DrawErrDisp("Err_Tar_Length_Check", P1_DisplayObj);
                    DrawErrDisp("Err_Tar_Length_Check", P2_DisplayObj);

                    Tar_P1.Tool.ProcMode = ProcessMode.Manual; Tar_P2.Tool.ProcMode = ProcessMode.Manual;
                    IsTargetLeftNG = IsTargetRightNG = true;
                    return false;
                }
                if (use == OnOff.On && !GetLCheck(mLengthObj, length_Obj, tor_Obj))
                {
                    errorCode = AlgoActionBase.Err_Length_Check;
                    Obj_P1.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    Obj_P2.DisplayObj.Judgement = (uint)Judgement.L_Check;
                    DrawErrDisp("Err_Obj_Length_Check", P1_DisplayObj);
                    DrawErrDisp("Err_Obj_Length_Check", P2_DisplayObj);

                    Obj_P1.Tool.ProcMode = ProcessMode.Manual; Obj_P2.Tool.ProcMode = ProcessMode.Manual;
                    return false;
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show(e.ToString());
                return false;
            }
            #endregion

            //InsertResultData(Spec, Tor);
            if (!ConfirmResult2(mInspResult, mMarkSpec, mMarkTor))
            {
                return false;
            }

            if (!ConfirmResult2(mThetaRst, spec_T, tor_T))
                return false;

            return true;
        }



        /// <summary>
        /// 
        /// </summary>
        void MultiplyScale()
        {
            if (mInspResultOrg == null) mInspResultOrg = new XYXY();

            // 일단 값을 담아둔다.
            mInspResultOrg.Lx = mInspResult.Lx;
            mInspResultOrg.Ly = mInspResult.Ly;
            mInspResultOrg.Rx = mInspResult.Rx;
            mInspResultOrg.Ry = mInspResult.Ry;

            // scale 값을 적용한다.
            mInspResult.Lx *= mMarkScale.Lx;
            mInspResult.Ly *= mMarkScale.Ly;
            mInspResult.Rx *= mMarkScale.Rx;
            mInspResult.Ry *= mMarkScale.Ry;
        }

        private InspectionData testValue;
        public InspectionData TestValue
        {
            get
            {
                if (testValue == null)
                    testValue = new InspectionData();

                return testValue;
            }
            set { testValue = value; OnPropertyChanged(nameof(TestValue)); }
        }

        /// <summary>
        /// Insepction Chart 설정
        /// </summary>
        /// <param name="spec"></param>
        /// <param name="tor"></param>
        public void InsertResultData(XYXY spec, XYXY tor, XY spec1, XY tor1)
        {
            var rst = new InspectionData();

            rst.Time = DateTime.Now;
            rst.O_ID = SourceID;
            rst.T_ID = SourceID;

            SetInsData(rst.U_Lx, rst.U_Ly, new XY(spec.Lx, spec.Ly), new XY(tor.Lx, tor.Ly), new XY(mInspResult.Lx, mInspResult.Ly));
            SetInsData(rst.U_Rx, rst.U_Ry, new XY(spec.Rx, spec.Ry), new XY(tor.Rx, tor.Ry), new XY(mInspResult.Rx, mInspResult.Ry));
            SetInsData(rst.L_Lx, rst.L_Ly, new XY(spec1.X, spec1.Y), new XY(tor1.X, tor1.Y), new XY(mObjToTapeXY.X, mObjToTapeXY.Y));

            if (ChartObject != null)
            {
                ChartObject.ProcType = InspectionChart.ProcType.CPanel;
                ChartObject.Name = new string[4] { "Lx, Ly", "Rx, Ry", "HoleX, HoleY", "" };
                ChartObject.InsertInspectionData(rst);
            }
        }

        /// <summary>
        /// Insepction Chart Data 설정
        /// </summary>
        /// <param name="inspX"></param>
        /// <param name="inspY"></param>
        /// <param name="spec"></param>
        /// <param name="tor"></param>
        /// <param name="val"></param>
        void SetInsData(InspElement inspX, InspElement inspY, XY spec, XY tor, XY val)
        {
            inspX.USL = spec.X + tor.X; inspY.USL = spec.Y + tor.Y;
            inspX.LSL = spec.X - tor.X; inspY.LSL = spec.Y - tor.Y;
            inspX.Spec = spec.X;        inspY.Spec = spec.Y;
            inspX.Value = val.X;        inspY.Value = val.Y;

            spec = null; tor = null; val = null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        bool InspectionHole()
        {
            string model = SystemModel.GetCurModel();

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Hc_Panel") || !InputValues.ContainsKey("Hc_Tape"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            var Hc_Panel = InputValues["Hc_Panel"] as IPointResult;
            var Hc_Tape = InputValues["Hc_Tape"] as IPointResult;


            if (Hc_Panel == null || Hc_Tape == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }


            CogCircle PanelHole = new CogCircle();
            CogCircle TapeHole = new CogCircle();

            if (!InputValues.ContainsKey("Outputs_Panel") || !InputValues.ContainsKey("Outputs_Tape"))
            {
                PanelHole.SetCenterRadius(Hc_Panel.OutputXYT.X, Hc_Panel.OutputXYT.Y, 100);
                TapeHole.SetCenterRadius(Hc_Tape.OutputXYT.X, Hc_Tape.OutputXYT.Y, 100);
            }
            else
            {
                Dictionary<string, object> Outputs_Panel = InputValues["Outputs_Panel"] as Dictionary<string, object>;
                Dictionary<string, object> Outputs_Tape = InputValues["Outputs_Tape"] as Dictionary<string, object>;

                var output_terminal_panel = Outputs_Panel["Hole"] as CogToolBlockTerminal;
                var output_terminal_tape = Outputs_Tape["Hole"] as CogToolBlockTerminal;

                PanelHole = output_terminal_panel.Value as CogCircle;
                TapeHole = output_terminal_tape.Value as CogCircle;

                if (PanelHole == null || TapeHole == null)
                {
                    PanelHole.SetCenterRadius(Hc_Panel.OutputXYT.X, Hc_Panel.OutputXYT.Y, 100);
                    TapeHole.SetCenterRadius(Hc_Tape.OutputXYT.X, Hc_Tape.OutputXYT.Y, 100);
                }
            }




            var pPanel_H = new XY(PanelHole.CenterX, PanelHole.CenterY);
            var pTape_H = new XY(TapeHole.CenterX, TapeHole.CenterY);


            mRobot_Panel_H = H1_CalDataObj.GetV2R(model, pPanel_H);
            mRobot_Tape_H = H1_CalDataObj.GetV2R(model, pTape_H);
            //mRobot_Window_H = H1_CalDataObj.GetV2R(model, pWindow_H);
            #endregion

            #region Draw Hole Graphic
            // add circle graphic
            PanelHole.LineWidthInScreenPixels = 2;
            TapeHole.LineWidthInScreenPixels = 2;
            //WindowHole.LineWidthInScreenPixels = 2;

            PanelHole.Color = CogColorConstants.Orange;
            TapeHole.Color = CogColorConstants.Yellow;
            //WindowHole.Color = CogColorConstants.Blue;


            H1_DisplayObj.AddGraphic(PanelHole as ICogGraphic, "PanelHole");
            H1_DisplayObj.AddGraphic(TapeHole as ICogGraphic, "TapeHole");
            //H1_DisplayObj.AddGraphic(WindowHole as ICogGraphic, "WindowHole");

            // add circle center mark
            CogDrawMarkerInfo PanelMark = new CogDrawMarkerInfo(new XYT(PanelHole.CenterX, PanelHole.CenterY, 0), 100, CogColorConstants.Orange);
            CogDrawMarkerInfo tapeMark = new CogDrawMarkerInfo(new XYT(TapeHole.CenterX, TapeHole.CenterY, 0), 100, CogColorConstants.Yellow);
            //CogDrawMarkerInfo windowMark = new CogDrawMarkerInfo(new XYT(WindowHole.CenterX, WindowHole.CenterY, 0), 10, CogColorConstants.Blue);
            H1_DisplayObj.DrawMaker(PanelMark);
            H1_DisplayObj.DrawMaker(tapeMark);
            //H1_DisplayObj.DrawMaker(windowMark);
            #endregion
            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsIns;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;

            var specX = (double)mParams.Spec_HoleX.Value;
            var specY = (double)mParams.Spec_HoleY.Value;
            var specD = (double)mParams.Spec_HoleD.Value;
            var torX = (double)mParams.Tor_HoleX.Value;
            var torY = (double)mParams.Tor_HoleY.Value;
            var torD = (double)mParams.Tor_HoleD.Value;
            var ScaleX = (double)mParams.Scale_HoleX.Value;
            var ScaleY = (double)mParams.Scale_HoleY.Value;
            var ScaleD = (double)mParams.Scale_HoleD.Value;

            mHoleSpec = new XY(specX, specY);
            mHoleTor = new XY(torX, torY);
            mHoleScale = new XY(ScaleX, ScaleY);
            #endregion

            #region Calc Hole to Hole

            if (mHoleDiff == null) mHoleDiff = new XY();

            CalcHoleLength(pPanel_H, pTape_H, mRobot_Panel_H, mRobot_Tape_H);
            //
            CircleToCircleDistance(model, PanelHole, TapeHole);

            //switch (HoleType)
            //{
            //    case HoleCalcType.PanelToTape:
            //        //
            //        CalcHoleLength(pPanel_H, pTape_H, mRobot_Panel_H, mRobot_Tape_H);
            //        //
            //        CircleToCircleDistance(model, PanelHole, TapeHole);
            //        break;
            //    case HoleCalcType.WindowToTape:
            //        //
            //        CalcHoleLength(pWindow_H, pTape_H, mRobot_Window_H, mRobot_Tape_H);
            //        //
            //        CircleToCircleDistance(model, WindowHole, TapeHole);
            //        break;
            //}
            #endregion

            //if (ScaleX == 0) ScaleX = 1;
            //if (ScaleY == 0) ScaleY = 1;
            //mObjToTapeXY.X *= ScaleX;
            //mObjToTapeXY.Y *= ScaleY;

            // 2021.04.06 hdy  메뉴얼 컨펌용..
            mPanelHole = new CogCircle(PanelHole);
            mTapeHole = new CogCircle(TapeHole);

            #region Check Spec
            if (!ConfirmResultHole(mObjToTapeD, specD, torD))
            {
                lastJudgement = false;
                H1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                return false;
            }
            #endregion

            PanelHole = null; TapeHole = null;
            //WindowHole = null;
            //TapeHoleLineV = null; TapeHoleLineH = null;
            PanelMark = null; tapeMark = null;
            //windowMark = null;

            return true;
        }

        bool InspectionEdge()
        {
            string model = SystemModel.GetCurModel();

            #region Mark Data Read& Confirm
            if (!InputValues.ContainsKey("Hc_Panel") || !InputValues.ContainsKey("Hc_Tape"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            var Hc_Panel = InputValues["Hc_Panel"] as IPointResult;
            var Hc_Tape = InputValues["Hc_Tape"] as IPointResult;

            mPanel_Edge = Hc_Panel;
            mTape_Edge = Hc_Tape;

            if (Hc_Panel == null || Hc_Tape == null)
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                //디스플레이에 에러코드 보여줌
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }

            var pPanel_H = new XY(Hc_Panel.OutputXYT.X, Hc_Panel.OutputXYT.Y);
            var pTape_H = new XY(Hc_Tape.OutputXYT.X, Hc_Tape.OutputXYT.Y);

            mRobot_Panel_H = H1_CalDataObj.GetV2R(model, pPanel_H);
            mRobot_Tape_H = H1_CalDataObj.GetV2R(model, pTape_H);
            #endregion

            #region Draw Mark Graphic
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsIns;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;

            var specX = (double)mParams.Spec_HoleX.Value;
            var specY = (double)mParams.Spec_HoleY.Value;
            var specD = (double)mParams.Spec_HoleD.Value;
            var torX = (double)mParams.Tor_HoleX.Value;
            var torY = (double)mParams.Tor_HoleY.Value;
            var torD = (double)mParams.Tor_HoleD.Value;
            var ScaleX = (double)mParams.Scale_HoleX.Value;
            var ScaleY = (double)mParams.Scale_HoleY.Value;
            var ScaleD = (double)mParams.Scale_HoleD.Value;

            mHoleSpec = new XY(specX, specY);
            mHoleTor = new XY(torX, torY);
            mHoleScale = new XY(ScaleX, ScaleY);
            #endregion

            #region Calc Hole to Hole
            if (mHoleDiff == null) mHoleDiff = new XY();
            CalcHoleLength(pPanel_H, pTape_H, mRobot_Panel_H, mRobot_Tape_H);
            mCircleToCircle = new double[4] { 0.0, 0.0, 0.0, 0.0 };

            mObjToTapeXY_APC.X = pTape_H.X < pPanel_H.X ? -1 : 1;
            mObjToTapeXY_APC.Y = pTape_H.Y > pPanel_H.Y ? -1 : 1;

            mObjToTapeXY = mObjToTapeXY * mObjToTapeXY_APC;
            #endregion

            #region Check Spec
            if (!ConfirmResultHole(mObjToTapeXY, mHoleSpec, mHoleTor))
            {
                lastJudgement = false;
                H1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                return false;
            }
            #endregion

            //PanelMark = null; tapeMark = null;
            return true;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        bool InspectionHole_Init()
        {
            string model = SystemModel.GetCurModel();

            #region Mark Data Read& Confirm
            CogCircle PanelHole = new CogCircle();
            CogCircle TapeHole = new CogCircle();
            CogCircle WindowHole = new CogCircle();

            PanelHole.SetCenterRadius(0, 0, 60);
            TapeHole.SetCenterRadius(0, 0, 50);
            WindowHole.SetCenterRadius(0, 0, 10);

            var pPanel_H = new XY(PanelHole.CenterX, PanelHole.CenterY);
            var pTape_H = new XY(TapeHole.CenterX, TapeHole.CenterY);
            var pWindow_H = new XY(WindowHole.CenterX, WindowHole.CenterY);

            mRobot_Panel_H = H1_CalDataObj.GetV2R(model, pPanel_H);
            mRobot_Tape_H = H1_CalDataObj.GetV2R(model, pTape_H);
            mRobot_Window_H = H1_CalDataObj.GetV2R(model, pWindow_H);
            #endregion


            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsIns;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;

            var specX = (double)mParams.Spec_HoleX.Value;
            var specY = (double)mParams.Spec_HoleY.Value;
            var torX = 10000;
            var torY = 10000;
            var ScaleX = (double)mParams.Scale_HoleX.Value;
            var ScaleY = (double)mParams.Scale_HoleY.Value;

            mHoleSpec = new XY(specX, specY);
            mHoleTor = new XY(torX, torY);
            mHoleScale = new XY(ScaleX, ScaleY);
            #endregion

            #region Calc Hole to Hole

            if (mHoleDiff == null) mHoleDiff = new XY();
            switch (HoleType)
            {
                case HoleCalcType.PanelToTape:
                    //
                    CalcHoleLength(pPanel_H, pTape_H, mRobot_Panel_H, mRobot_Tape_H);
                    //
                    CircleToCircleDistance(model, PanelHole, TapeHole);
                    break;
                case HoleCalcType.WindowToTape:
                    //
                    CalcHoleLength(pWindow_H, pTape_H, mRobot_Window_H, mRobot_Tape_H);
                    //
                    CircleToCircleDistance(model, WindowHole, TapeHole);
                    break;
            }
            #endregion

            // 2021.04.06 hdy  메뉴얼 컨펌용..
            mPanelHole = new CogCircle(PanelHole);
            mTapeHole = new CogCircle(TapeHole);

            return true;
        }

        /// <summary>
        /// 메뉴얼 컨펌 후 홀 거리 재 계산..
        /// </summary>
        /// <returns></returns>
        bool ConfirmInspectionHole()
        {
            H1_DisplayObj.ClearGraphic();
            string model = SystemModel.GetCurModel();

            #region Mark Data Read& Confirm
            CogCircle PanelHole = panelConfirm_H.Circle;
            CogCircle TapeHole = tapeConfirm_H.Circle;

            var pPanel_H = new XY(PanelHole.CenterX, PanelHole.CenterY);
            var pTape_H = new XY(TapeHole.CenterX, TapeHole.CenterY);

            mRobot_Panel_H = H1_CalDataObj.GetV2R(model, pPanel_H);
            mRobot_Tape_H = H1_CalDataObj.GetV2R(model, pTape_H);
            //mRobot_Window_H = H1_CalDataObj.GetV2R(model, pWindow_H);
            #endregion

            #region Draw Hole Graphic
            // add circle graphic
            PanelHole.LineWidthInScreenPixels = 2;
            TapeHole.LineWidthInScreenPixels = 2;
            //WindowHole.LineWidthInScreenPixels = 2;

            PanelHole.Color = CogColorConstants.Orange;
            TapeHole.Color = CogColorConstants.Yellow;
            //WindowHole.Color = CogColorConstants.Blue;

            H1_DisplayObj.AddGraphic(PanelHole as ICogGraphic, "PanelHole");
            H1_DisplayObj.AddGraphic(TapeHole as ICogGraphic, "TapeHole");
            //H1_DisplayObj.AddGraphic(WindowHole as ICogGraphic, "WindowHole");

            // add circle center mark
            CogDrawMarkerInfo PanelMark = new CogDrawMarkerInfo(new XYT(PanelHole.CenterX, PanelHole.CenterY, 0), 100, CogColorConstants.Orange);
            CogDrawMarkerInfo tapeMark = new CogDrawMarkerInfo(new XYT(TapeHole.CenterX, TapeHole.CenterY, 0), 100, CogColorConstants.Yellow);
            //CogDrawMarkerInfo windowMark = new CogDrawMarkerInfo(new XYT(WindowHole.CenterX, WindowHole.CenterY, 0), 10, CogColorConstants.Blue);
            H1_DisplayObj.DrawMaker(PanelMark);
            H1_DisplayObj.DrawMaker(tapeMark);
            //H1_DisplayObj.DrawMaker(windowMark);

            #endregion
            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsIns;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;

            var specX = (double)mParams.Spec_HoleX.Value;
            var specY = (double)mParams.Spec_HoleY.Value;
            var specD = (double)mParams.Spec_HoleD.Value;
            var torX = (double)mParams.Tor_HoleX.Value;
            var torY = (double)mParams.Tor_HoleY.Value;
            var torD = (double)mParams.Tor_HoleD.Value;
            var ScaleX = (double)mParams.Scale_HoleX.Value;
            var ScaleY = (double)mParams.Scale_HoleY.Value;
            var ScaleD = (double)mParams.Scale_HoleD.Value;

            mHoleSpec = new XY(specX, specY);
            mHoleTor = new XY(torX, torY);
            mHoleScale = new XY(ScaleX, ScaleY);
            #endregion

            #region Calc Hole to Hole
            if (mHoleDiff == null) mHoleDiff = new XY();
            CalcHoleLength(pPanel_H, pTape_H, mRobot_Panel_H, mRobot_Tape_H);
            CircleToCircleDistance(model, PanelHole, TapeHole);
            #endregion

            #region Check Spec
            if (!ConfirmResultHole(mObjToTapeD, specD, torD))
            {
                lastJudgement = false;
                H1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                return false;
            }
            #endregion

            return true;
        }


        bool ConfirmInspectionEdge()
        {
            H1_DisplayObj.ClearGraphic();
            string model = SystemModel.GetCurModel();

            #region Mark Data Read& Confirm
            var pPanel_H = new XY(mPanel_Edge.OutputXYT.X, mPanel_Edge.OutputXYT.Y);
            var pTape_H = new XY(mTape_Edge.OutputXYT.X, mTape_Edge.OutputXYT.Y);

            mRobot_Panel_H = H1_CalDataObj.GetV2R(model, pPanel_H);
            mRobot_Tape_H = H1_CalDataObj.GetV2R(model, pTape_H);
            #endregion

            #region Draw Mark Graphic
            CogDrawMarkerInfo PanelMark = new CogDrawMarkerInfo(new XYT(mPanel_Edge.OutputXYT.X, mPanel_Edge.OutputXYT.Y, 0), 100, CogColorConstants.Orange);
            CogDrawMarkerInfo tapeMark = new CogDrawMarkerInfo(new XYT(mTape_Edge.OutputXYT.X, mTape_Edge.OutputXYT.Y, 0), 100, CogColorConstants.Yellow);
            H1_DisplayObj.DrawMaker(PanelMark);
            H1_DisplayObj.DrawMaker(tapeMark);
            #endregion

            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsIns;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;

            var specX = (double)mParams.Spec_HoleX.Value;
            var specY = (double)mParams.Spec_HoleY.Value;
            var specD = (double)mParams.Spec_HoleD.Value;
            var torX = (double)mParams.Tor_HoleX.Value;
            var torY = (double)mParams.Tor_HoleY.Value;
            var torD = (double)mParams.Tor_HoleD.Value;
            var ScaleX = (double)mParams.Scale_HoleX.Value;
            var ScaleY = (double)mParams.Scale_HoleY.Value;
            var ScaleD = (double)mParams.Scale_HoleD.Value;

            mHoleSpec = new XY(specX, specY);
            mHoleTor = new XY(torX, torY);
            mHoleScale = new XY(ScaleX, ScaleY);
            #endregion

            #region Calc Hole to Hole
            if (mHoleDiff == null) mHoleDiff = new XY();
            CalcHoleLength(pPanel_H, pTape_H, mRobot_Panel_H, mRobot_Tape_H);
            mCircleToCircle = new double[4] { 0.0, 0.0, 0.0, 0.0 };

            mObjToTapeXY_APC.X = pTape_H.X < pPanel_H.X ? -1 : 1;
            mObjToTapeXY_APC.Y = pTape_H.Y > pPanel_H.Y ? -1 : 1;

            mObjToTapeXY = mObjToTapeXY * mObjToTapeXY_APC;
            #endregion

            #region Check Spec
            if (!ConfirmResultHole(mObjToTapeD, specD, torD))
            {
                lastJudgement = false;
                H1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                return false;
            }
            #endregion

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        void CalcHoleLength(XY pObj, XY pTape, XY rObjPos, XY rTapePos, bool bEdge = false)
        {
            if (mObjToTapeXYOrg == null) mObjToTapeXYOrg = new XY();
            if (mObjToTapeXY == null) mObjToTapeXY = new XY();
            if (mHoleScale == null) mHoleScale = new XY(1.0, 1.0);

            // Panel Circle to Tape Circle Distance XY
            mHoleDiff.X = rObjPos.X - rTapePos.X;
            mHoleDiff.Y = rObjPos.Y - rTapePos.Y;

            mObjToTapeXY.X = Math.Abs(mHoleDiff.X);
            mObjToTapeXY.Y = Math.Abs(mHoleDiff.Y);

            // 일단 값을 담는다.
            mObjToTapeXYOrg.X = Math.Abs(mObjToTapeXY.X);
            mObjToTapeXYOrg.Y = Math.Abs(mObjToTapeXY.Y);
            mObjToTapeDOrg = mObjToTapeD;

            // scale 추가
            mObjToTapeXY.X *= mHoleScale.X;
            mObjToTapeXY.Y *= mHoleScale.Y;
            mHoleDiff.X *= mHoleScale.X;
            mHoleDiff.Y *= mHoleScale.Y;
            mObjToTapeD = Math.Sqrt(Math.Pow(mObjToTapeXY.X, 2) + Math.Pow(mObjToTapeXY.Y, 2));

            XY start = pObj; XY end = new XY(pObj.X, pTape.Y);
            CogDrawLineInfo lineInfo = new CogDrawLineInfo(start, end, 1, CogColorConstants.Cyan, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
            H1_DisplayObj.DrawLine(lineInfo);

            start = pTape; end = new XY(pObj.X, pTape.Y);
            lineInfo = new CogDrawLineInfo(start, end, 1, CogColorConstants.Magenta, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
            H1_DisplayObj.DrawLine(lineInfo);

            // 결과 표시
            //string strDirectX = rObjPos.X < rTapePos.X ? "+" : "-";
            //mHoleDiff.X = strDirectX == "-" ? -mObjToTapeXY.X : mObjToTapeXY.X;

            //string strDirectY = rObjPos.Y < rTapePos.Y ? "+" : "-";
            //mHoleDiff.Y = strDirectY == "-" ? -mObjToTapeXY.Y : mObjToTapeXY.Y;

            //mHoleDiff -= mHoleSpec;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="lineV"></param>
        /// <param name="lineH"></param>
        /// <param name="hole1"></param>
        /// <param name="hole2"></param>
        void CircleToCircleDistance(string model, CogLine lineV, CogLine lineH, CogCircle hole1, CogCircle hole2)
        {
            try
            {
                mCircleToCircle = new double[4] { 0.0, 0.0, 0.0, 0.0 };

                XY[] pHole1EdgePoint = new XY[4];
                XY[] pHole2EdgePoint = new XY[4];

                XY[] rHole1EdgePoint = new XY[4];
                XY[] rHole2EdgePoint = new XY[4];

                // 1. hole 1 Up, Down Edge Search
                mIntersectLToC.InputImage = H1_DisplayObj.CogDs.Image as ICogImage;
                mIntersectLToC.Line = lineV;
                mIntersectLToC.InputCircle = hole1;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole1EdgePoint[(int)ePos.Top] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole1EdgePoint[(int)ePos.Bottom] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole1EdgePoint[(int)ePos.Top] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Top]);
                    rHole1EdgePoint[(int)ePos.Bottom] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Bottom]);
                }

                // 2. hole 2 Up, Down Edge Searchb
                mIntersectLToC.Line = lineV;
                mIntersectLToC.InputCircle = hole2;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole2EdgePoint[(int)ePos.Top] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole2EdgePoint[(int)ePos.Bottom] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole2EdgePoint[(int)ePos.Top] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Top]);
                    rHole2EdgePoint[(int)ePos.Bottom] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Bottom]);
                }

                // 3. hole 1 Left, Down Right Search
                mIntersectLToC.Line = lineH;
                mIntersectLToC.InputCircle = hole1;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole1EdgePoint[(int)ePos.Left] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole1EdgePoint[(int)ePos.Right] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole1EdgePoint[(int)ePos.Left] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Left]);
                    rHole1EdgePoint[(int)ePos.Right] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Right]);
                }


                // 4. hole 2 Left, Down Right Search
                mIntersectLToC.Line = lineH;
                mIntersectLToC.InputCircle = hole2;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole2EdgePoint[(int)ePos.Left] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole2EdgePoint[(int)ePos.Right] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole2EdgePoint[(int)ePos.Left] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Left]);
                    rHole2EdgePoint[(int)ePos.Right] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Right]);
                }

                // 5. Calc Distance
                if (rHole1EdgePoint[(int)ePos.Top] == null || rHole1EdgePoint[(int)ePos.Bottom] == null || rHole1EdgePoint[(int)ePos.Left] == null || rHole1EdgePoint[(int)ePos.Right] == null
                    || rHole2EdgePoint[(int)ePos.Top] == null || rHole2EdgePoint[(int)ePos.Bottom] == null || rHole2EdgePoint[(int)ePos.Left] == null || rHole2EdgePoint[(int)ePos.Right] == null
                    )
                {
                    mCircleToCircle[(int)ePos.Top] = 0.0;
                    mCircleToCircle[(int)ePos.Bottom] = 0.0;
                    mCircleToCircle[(int)ePos.Left] = 0.0;
                    mCircleToCircle[(int)ePos.Right] = 0.0;
                }
                else
                {
                    mCircleToCircle[(int)ePos.Top] = GetLength(rHole1EdgePoint[(int)ePos.Top], rHole2EdgePoint[(int)ePos.Top]);
                    mCircleToCircle[(int)ePos.Bottom] = GetLength(rHole1EdgePoint[(int)ePos.Bottom], rHole2EdgePoint[(int)ePos.Bottom]);
                    mCircleToCircle[(int)ePos.Left] = GetLength(rHole1EdgePoint[(int)ePos.Left], rHole2EdgePoint[(int)ePos.Left]);
                    mCircleToCircle[(int)ePos.Right] = GetLength(rHole1EdgePoint[(int)ePos.Right], rHole2EdgePoint[(int)ePos.Right]);

                    // scale 추가
                    mCircleToCircle[(int)ePos.Top] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Bottom] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Left] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Right] *= mHoleScale.Y;
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }


        void CircleToCircleDistance(string model, CogCircle hole1, CogCircle hole2)
        {
            try
            {
                mCircleToCircle = new double[4] { 0.0, 0.0, 0.0, 0.0 };

                XY[] pHole1EdgePoint = new XY[4];
                XY[] pHole2EdgePoint = new XY[4];

                XY[] rHole1EdgePoint = new XY[4];
                XY[] rHole2EdgePoint = new XY[4];

                XY panelHoleXY = new XY(hole1.CenterX, hole1.CenterY);

                CogLine panelHoleLineV = new CogLine();
                CogLine panelHoleLineH = new CogLine();

                panelHoleLineV.SetFromStartXYEndXY(panelHoleXY.X, 0, panelHoleXY.X, panelHoleXY.Y + hole1.Radius * 2);
                panelHoleLineH.SetFromStartXYEndXY(0, panelHoleXY.Y, panelHoleXY.X + hole1.Radius * 2, panelHoleXY.Y);

                // 1. hole 1 Up, Down Edge Search
                mIntersectLToC.InputImage = H1_DisplayObj.CogDs.Image as ICogImage;
                mIntersectLToC.Line = panelHoleLineV;
                mIntersectLToC.InputCircle = hole1;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole1EdgePoint[(int)ePos.Top] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole1EdgePoint[(int)ePos.Bottom] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole1EdgePoint[(int)ePos.Top] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Top]);
                    rHole1EdgePoint[(int)ePos.Bottom] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Bottom]);
                }

                // 2. hole 2 Up, Down Edge Searchb
                mIntersectLToC.Line = panelHoleLineV;
                mIntersectLToC.InputCircle = hole2;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole2EdgePoint[(int)ePos.Top] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole2EdgePoint[(int)ePos.Bottom] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole2EdgePoint[(int)ePos.Top] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Top]);
                    rHole2EdgePoint[(int)ePos.Bottom] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Bottom]);
                }

                // 3. hole 1 Left, Down Right Search
                mIntersectLToC.Line = panelHoleLineH;
                mIntersectLToC.InputCircle = hole1;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole1EdgePoint[(int)ePos.Left] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole1EdgePoint[(int)ePos.Right] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole1EdgePoint[(int)ePos.Left] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Left]);
                    rHole1EdgePoint[(int)ePos.Right] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Right]);
                }


                // 4. hole 2 Left, Down Right Search
                mIntersectLToC.Line = panelHoleLineH;
                mIntersectLToC.InputCircle = hole2;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole2EdgePoint[(int)ePos.Left] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole2EdgePoint[(int)ePos.Right] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole2EdgePoint[(int)ePos.Left] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Left]);
                    rHole2EdgePoint[(int)ePos.Right] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Right]);
                }

                // 5. Calc Distance
                if (rHole1EdgePoint[(int)ePos.Top] == null || rHole1EdgePoint[(int)ePos.Bottom] == null || rHole1EdgePoint[(int)ePos.Left] == null || rHole1EdgePoint[(int)ePos.Right] == null
                    || rHole2EdgePoint[(int)ePos.Top] == null || rHole2EdgePoint[(int)ePos.Bottom] == null || rHole2EdgePoint[(int)ePos.Left] == null || rHole2EdgePoint[(int)ePos.Right] == null
                    )
                {
                    mCircleToCircle[(int)ePos.Top] = 0.0;
                    mCircleToCircle[(int)ePos.Bottom] = 0.0;
                    mCircleToCircle[(int)ePos.Left] = 0.0;
                    mCircleToCircle[(int)ePos.Right] = 0.0;
                }
                else
                {
                    mCircleToCircle[(int)ePos.Top] = GetLength(rHole1EdgePoint[(int)ePos.Top], rHole2EdgePoint[(int)ePos.Top]);
                    mCircleToCircle[(int)ePos.Bottom] = GetLength(rHole1EdgePoint[(int)ePos.Bottom], rHole2EdgePoint[(int)ePos.Bottom]);
                    mCircleToCircle[(int)ePos.Left] = GetLength(rHole1EdgePoint[(int)ePos.Left], rHole2EdgePoint[(int)ePos.Left]);
                    mCircleToCircle[(int)ePos.Right] = GetLength(rHole1EdgePoint[(int)ePos.Right], rHole2EdgePoint[(int)ePos.Right]);

                    // scale 추가
                    mCircleToCircle[(int)ePos.Top] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Bottom] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Left] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Right] *= mHoleScale.Y;
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        /// <summary>
        /// liine 표시 함수
        /// </summary>
        /// <param name="dispObj"></param>
        /// <param name="P1"></param>
        /// <param name="P2"></param>
        /// <param name="color"></param>
        void DrawLine(CogDisplayObject dispObj, XYT P1, XYT P2, CogColorConstants color)
        {
            CogDrawLineInfo lineInfo = new CogDrawLineInfo();
            lineInfo.LineWidthInScreenPixels = 2;
            lineInfo.StartPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.EndPointAdornment = CogLineSegmentAdornmentConstants.SolidArrow;
            lineInfo.Color = color;
            lineInfo.Start.X = P1.X;
            lineInfo.Start.Y = P1.Y;
            lineInfo.End.X = P2.X;
            lineInfo.End.Y = P2.Y;
            dispObj.DrawLine(lineInfo);

            lineInfo = null;
            P1 = null; P2 = null;
        }


        /// <summary>bbbbb
        /// ㅣLabel 표시 함수
        /// </summary>
        /// <param name="Offset"></param>
        /// <param name="text"></param>
        /// <param name="dispObj"></param>
        void DrawLabel(CogDisplayObject dispObj, XY Offset, string text,
            CogGraphicLabelAlignmentConstants alignment = CogGraphicLabelAlignmentConstants.TopLeft,
            CogColorConstants backColor = CogColorConstants.White, bool bBackColor = true)
        {
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();

            labelInfo.FontSize = 10;
            labelInfo.UseBackColor = bBackColor;
            labelInfo.BackColor = backColor;
            labelInfo.Alignment = alignment;
            labelInfo.Offset = Offset;
            labelInfo.Text = text;
            dispObj.DrawLabel(labelInfo);

            Offset = null;
            labelInfo = null;
        }

        void DrawLabel(CogDisplayObject dispObj, XY Offset, string text, double diff, double tor,
            CogGraphicLabelAlignmentConstants alignment = CogGraphicLabelAlignmentConstants.TopLeft,
            CogColorConstants backColor = CogColorConstants.White, bool bBackColor = true)
        {
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();

            labelInfo.FontSize = 10;
            labelInfo.UseBackColor = bBackColor;
            labelInfo.BackColor = Math.Abs(diff) >= tor ? CogColorConstants.Red : backColor;
            labelInfo.Alignment = alignment;
            labelInfo.Offset = Offset;
            labelInfo.Text = text;
            dispObj.DrawLabel(labelInfo);

            Offset = null;
            labelInfo = null;
        }

        /// <summary>
        /// 거리 계산 : Point To Point
        /// </summary>
        /// <param name="model"></param>
        /// <param name="Tar_P1"></param>
        /// <param name="Tar_P2"></param>
        /// <param name="Obj_P1"></param>
        /// <param name="Obj_P2"></param>
        bool CalcDistanceP2P(string model, XY rTar_P1, XY rTar_P2, XY rObj_P1, XY rObj_P2)
        {
            if (mInspResult == null) mInspResult = new XYXY();
            mInspResult.Lx = GetDotDistance(rTar_P1, rObj_P1, rObj_P2);
            mInspResult.Ly = GetCrossDistance(rTar_P1, rObj_P1, rObj_P2);
            mInspResult.Rx = GetDotDistance(rTar_P2, rObj_P2, rObj_P1);
            mInspResult.Ry = GetCrossDistance(rTar_P2, rObj_P2, rObj_P1);

            // 결과 표시 추가할 것
            return true;
        }

        /// <summary>
        /// Line Drawing : Point to Point
        /// </summary>
        /// <param name="model"></param>
        /// <param name="pTar_P1"></param>
        /// <param name="pTar_P2"></param>
        /// <param name="pObj_P1"></param>
        /// <param name="pObj_P2"></param>
        void DrawLineP2P(string model, XY rTar_P1, XY rTar_P2, XY rObj_P1, XY rObj_P2)
        {
            XY startPx = new XY();
            XY endPx = new XY();

            // 1. Ly Line
            P1_CalDataObj.GetR2V(model, rTar_P1, ref startPx);
            P1_CalDataObj.GetR2V(model, GetCrossPoint(rTar_P1, rObj_P1, rObj_P2), ref endPx);

            CogDrawLineInfo lineInfo = new CogDrawLineInfo(startPx, endPx, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
            P1_DisplayObj.DrawLine(lineInfo);

            double dDiff = rTar_P1.Y > rObj_P1.Y ? (mInspResult.Ly - mMarkSpec.Ly) : (mInspResult.Ly - mMarkSpec.Ly) * -1;
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo(new XY(5, GetImageHeight(P1_DisplayObj) - 100), string.Format("Ly : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Ly, dDiff));
            P1_DisplayObj.DrawLabel(labelInfo);

            // 2. Lx Line
            P1_CalDataObj.GetR2V(model, rTar_P1, ref rObj_P1);

            lineInfo = new CogDrawLineInfo(startPx, endPx, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
            P1_DisplayObj.DrawLine(lineInfo);

            dDiff = rTar_P1.X < rObj_P1.X ? (mInspResult.Lx - mMarkSpec.Lx) : (mInspResult.Lx - mMarkSpec.Lx) * -1;
            labelInfo = new CogDrawLabelInfo(new XY(5, GetImageHeight(P1_DisplayObj) - 150), string.Format("Lx : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Lx, dDiff));
            P1_DisplayObj.DrawLabel(labelInfo);

            //// 3. Ry Line
            P2_CalDataObj.GetR2V(model, rTar_P2, ref startPx);
            P2_CalDataObj.GetR2V(model, GetCrossPoint(rTar_P2, rObj_P2, rObj_P1), ref endPx);

            lineInfo = new CogDrawLineInfo(startPx, endPx, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
            P2_DisplayObj.DrawLine(lineInfo);

            dDiff = rTar_P2.Y > rObj_P2.Y ? (mInspResult.Ry - mMarkSpec.Ry) : (mInspResult.Ry - mMarkSpec.Ry) * -1;
            labelInfo = new CogDrawLabelInfo(new XY(5, GetImageHeight(P2_DisplayObj) - 100), string.Format("Ry : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Ry, dDiff));
            P2_DisplayObj.DrawLabel(labelInfo);

            //// 4. Rx Line
            P2_CalDataObj.GetR2V(model, rTar_P2, ref startPx);
            lineInfo = new CogDrawLineInfo(startPx, endPx, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
            P2_DisplayObj.DrawLine(lineInfo);

            dDiff = rTar_P2.X < rObj_P2.X ? (mInspResult.Rx - mMarkSpec.Rx) : (mInspResult.Rx - mMarkSpec.Rx) * -1;
            labelInfo = new CogDrawLabelInfo(new XY(5, GetImageHeight(P2_DisplayObj) - 150), string.Format("Rx : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Rx, dDiff));
            P2_DisplayObj.DrawLabel(labelInfo);

            // 5. 각도 표시
            double pnlT = GetTheta(rObj_P1.X, rObj_P1.Y, rObj_P2.X, rObj_P2.Y);
            double tapeT = GetTheta(rTar_P1.X, rTar_P1.Y, rTar_P2.X, rTar_P2.Y);
            double T = (tapeT - pnlT) / rad;
            labelInfo = new CogDrawLabelInfo(new XY(5, GetImageHeight(P2_DisplayObj) - 50), string.Format("T : {0:f3}Deg", T));
            P1_DisplayObj.DrawLabel(labelInfo);
        }

        protected void DrawLineLabel_L(string model, XY Robot1_, XY Robot2_, double panelAngle_rad, double tapeAngle_rad, CogColorConstants color, bool mode = true)
        {
            XY Robot1 = new XY();
            XY Robot2 = new XY();
            if (Robot1_.Y > Robot2_.Y)
            {
                Robot1 = Robot1_;
                Robot2 = Robot2_;
                // 라인 draw
            }
            else
            {
                Robot1 = Robot2_;
                Robot2 = Robot1_;
            }

            XYT P1 = P1_CalDataObj.GetR2V(model, Robot1);
            XY P = new XY(0, 0);
            P.X += Robot1.X - mInspResultOrg.Ly * Math.Sin(panelAngle_rad);
            P.Y += Robot1.Y - mInspResultOrg.Ly * Math.Cos(panelAngle_rad);
            XYT P2 = P1_CalDataObj.GetR2V(model, P);

            // Ly Line 표시
            DrawLine(P1_DisplayObj, P1, P2, color);
            // Ly Label 표시
            double dDiff = Robot1.Y > P.Y ? (mInspResult.Ly - mMarkSpec.Ly) : (mInspResult.Ly - mMarkSpec.Ly) * -1;
            //DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 100), string.Format("Ly : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Ly, dDiff));
            mMarkDiff.Ly = dDiff;

            XYT P1_ = P1_CalDataObj.GetR2V(model, Robot2);
            XY P_ = new XY(0, 0);
            if (Robot2.X > Robot1.X)
            {
                P_.X += Robot2.X - mInspResultOrg.Lx * Math.Cos(panelAngle_rad);
                P_.Y += Robot2.Y - mInspResultOrg.Lx * Math.Sin(panelAngle_rad);
            }
            else
            {
                P_.X += Robot2.X + mInspResultOrg.Lx * Math.Cos(panelAngle_rad);
                P_.Y += Robot2.Y + mInspResultOrg.Lx * Math.Sin(panelAngle_rad);
            }
            XYT P2_ = P1_CalDataObj.GetR2V(model, P_);

            // Lx Line 표시
            DrawLine(P1_DisplayObj, P1_, P2_, color);
            // Lx Label 표시
            dDiff = Robot2.X < P_.X ? (mInspResult.Lx - mMarkSpec.Lx) : (mInspResult.Lx - mMarkSpec.Lx) * -1;
            //DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 150), string.Format("Lx : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Lx, dDiff));
            mMarkDiff.Lx = dDiff;

            // 각도 Label 표시
            double T = (tapeAngle_rad - panelAngle_rad) / rad;
            mThetaRst = T;
            //DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 50), string.Format("T : {0:f3}Deg", T));
        }

        protected void DrawLineLabel_R(string model, XY Robot1_, XY Robot2_, double panelangle_rad, CogColorConstants color, bool mode = true)
        {
            XY Robot1 = new XY();
            XY Robot2 = new XY();
            if (Robot1_.Y > Robot2_.Y)
            {
                Robot1 = Robot1_;
                Robot2 = Robot2_;
            }
            else
            {
                Robot1 = Robot2_;
                Robot2 = Robot1_;
            }

            XYT P1 = P2_CalDataObj.GetR2V(model, Robot1);
            XY P = new XY(0, 0);
            P.X += Robot1.X - mInspResultOrg.Ry * Math.Sin(panelangle_rad);
            P.Y += Robot1.Y - mInspResultOrg.Ry * Math.Cos(panelangle_rad);
            XYT P2 = P2_CalDataObj.GetR2V(model, P);

            // Ry line
            DrawLine(P2_DisplayObj, P1, P2, color);
            // Ry label
            double dDiff = Robot1.Y > P.Y ? (mInspResult.Ry - mMarkSpec.Ry) : (mInspResult.Ry - mMarkSpec.Ry) * -1;
            //DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 100), string.Format("Ry : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Ry, dDiff));
            mMarkDiff.Ry = dDiff;

            XYT P1_ = P2_CalDataObj.GetR2V(model, Robot2);
            XY P_ = new XY(0, 0);
            if (Robot2.X > Robot1.X)
            {
                P_.X += Robot2.X - mInspResultOrg.Rx * Math.Cos(panelangle_rad);
                P_.Y += Robot2.Y - mInspResultOrg.Rx * Math.Sin(panelangle_rad);
            }
            else
            {
                P_.X += Robot2.X + mInspResultOrg.Rx * Math.Cos(panelangle_rad);
                P_.Y += Robot2.Y + mInspResultOrg.Rx * Math.Sin(panelangle_rad);
            }
            XYT P2_ = P2_CalDataObj.GetR2V(model, P_);

            // Rx line
            DrawLine(P2_DisplayObj, P1_, P2_, color);
            // Rx Label
            dDiff = Robot2.X < P_.X ? (mInspResult.Rx - mMarkSpec.Rx) : (mInspResult.Rx - mMarkSpec.Rx) * -1;
            //DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 150), string.Format("Rx : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Rx, dDiff));
            mMarkDiff.Rx = dDiff;
        }

        void DrawLabelOfUseLine(double panelAngle_rad, double tapeAngle_rad)
        {
            double dDiff = mRobot_Obj_P1.Y > mRobot_Tar_P1.Y ? (mInspResult.Ly - mMarkSpec.Ly) : (mInspResult.Ly - mMarkSpec.Ly) * -1;
            DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 100), string.Format("Ly : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Ly, dDiff));
            mMarkDiff.Ly = dDiff;

            dDiff = mRobot_Obj_P1.X < mRobot_Tar_P1.X ? (mInspResult.Lx - mMarkSpec.Lx) : (mInspResult.Lx - mMarkSpec.Lx) * -1;
            DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 150), string.Format("Lx : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Lx, dDiff));
            mMarkDiff.Lx = dDiff;
            double T = (tapeAngle_rad - panelAngle_rad) / rad;
            DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 50), string.Format("T : {0:f3}Deg", T));
            dDiff = mRobot_Obj_P2.Y > mRobot_Tar_P2.Y ? (mInspResult.Ry - mMarkSpec.Ry) : (mInspResult.Ry - mMarkSpec.Ry) * -1;
            DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 100), string.Format("Ry : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Ry, dDiff));
            mMarkDiff.Ry = dDiff;
            dDiff = mRobot_Obj_P2.X < mRobot_Tar_P2.X ? (mInspResult.Rx - mMarkSpec.Rx) : (mInspResult.Rx - mMarkSpec.Rx) * -1;
            DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 150), string.Format("Rx : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Rx, dDiff));
            mMarkDiff.Rx = dDiff;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="Tar_P1"></param>
        /// <param name="Tar_P2"></param>
        /// <param name="Obj_P1"></param>
        /// <param name="Obj_P2"></param>
        /// <returns></returns>
        bool CalcDistanceP2Line(string model, IPointResult Tar_P1, IPointResult Tar_P2, IPointResult Obj_P1, IPointResult Obj_P2)
        {
            if (mInspResult == null) mInspResult = new XYXY();

            XY startPx; ; XY endPx;
            XY startRt; ; XY endRt;

            LineCrossRstData tar1 = Tar_P1 as LineCrossRstData;
            LineCrossRstData tar2 = Tar_P2 as LineCrossRstData;

            mCalcP2LineTool.InputImage = tar1.OutputImage as ICogImage;

            // 1. Lx Length
            mCalcP2LineTool.X = Obj_P1.OutputXYT.X;
            mCalcP2LineTool.Y = Obj_P1.OutputXYT.Y;
            mCalcP2LineTool.Line = tar1.Lines[0] as CogLine;
            mCalcP2LineTool.Run();

            if (mCalcP2LineTool.RunStatus.Result == CogToolResultConstants.Accept)
            {
                startPx = new XY(Obj_P1.OutputXYT.X, Obj_P1.OutputXYT.Y);
                endPx = new XY(mCalcP2LineTool.LineX, mCalcP2LineTool.LineY);
                startRt = P1_CalDataObj.GetV2R(model, startPx);
                endRt = P1_CalDataObj.GetV2R(model, endPx);

                mInspResult.Ly = GetLength(startRt, endRt);

                CogDrawLineInfo lineInfo = new CogDrawLineInfo(startPx, endPx, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
                P1_DisplayObj.DrawLine(lineInfo);

                // Ly Label 표시
                //double dDiff = mRobot_Obj_P1.Y > mRobot_Tar_P1.Y ? (mInspResult.Ly - mMarkSpec.Ly) : (mInspResult.Ly - mMarkSpec.Ly) * -1;
                //DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 100), string.Format("Ly : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Ly, dDiff));
                //CogDrawLabelInfo labelInfo = new CogDrawLabelInfo((lineInfo.Start + lineInfo.End) / 2 + new XY(20, 0), string.Format("{0:f2}mm", mInspResult.Ly));
                //P1_DisplayObj.DrawLabel(labelInfo);
                //mMarkDiff.Ly = dDiff;

            }

            // 2. Ly Length
            mCalcP2LineTool.X = Obj_P1.OutputXYT.X;
            mCalcP2LineTool.Y = Obj_P1.OutputXYT.Y;
            mCalcP2LineTool.Line = tar1.Lines[1] as CogLine;
            mCalcP2LineTool.Run();

            if (mCalcP2LineTool.RunStatus.Result == CogToolResultConstants.Accept)
            {
                startPx = new XY(Obj_P1.OutputXYT.X, Obj_P1.OutputXYT.Y);
                endPx = new XY(mCalcP2LineTool.LineX, mCalcP2LineTool.LineY);
                startRt = P1_CalDataObj.GetV2R(model, startPx);
                endRt = P1_CalDataObj.GetV2R(model, endPx);

                mInspResult.Lx = GetLength(startRt, endRt);

                CogDrawLineInfo lineInfo = new CogDrawLineInfo(startPx, endPx, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
                P1_DisplayObj.DrawLine(lineInfo);

                //double dDiff = mRobot_Obj_P1.X < mRobot_Tar_P1.X ? (mInspResult.Lx - mMarkSpec.Lx) : (mInspResult.Lx - mMarkSpec.Lx) * -1;
                //DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 150), string.Format("Lx : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Lx, dDiff));
                // 각도 Label 표시
                //CogDrawLabelInfo labelInfo = new CogDrawLabelInfo((lineInfo.Start + lineInfo.End) / 2 + new XY(0, 20), string.Format("{0:f2}mm", mInspResult.Lx));
                //P1_DisplayObj.DrawLabel(labelInfo);
                //mMarkDiff.Lx = dDiff;
            }

            // 각도 Label 표시
            //double T = (tapeAngle_rad - panelAngle_rad) / rad;
            //DrawLabel(P1_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 50), string.Format("T : {0:f3}Deg", T));

            // 3. Rx Length
            mCalcP2LineTool.X = Obj_P2.OutputXYT.X;
            mCalcP2LineTool.Y = Obj_P2.OutputXYT.Y;
            mCalcP2LineTool.Line = tar2.Lines[0] as CogLine;
            mCalcP2LineTool.Run();

            if (mCalcP2LineTool.RunStatus.Result == CogToolResultConstants.Accept)
            {
                startPx = new XY(Obj_P2.OutputXYT.X, Obj_P2.OutputXYT.Y);
                endPx = new XY(mCalcP2LineTool.LineX, mCalcP2LineTool.LineY);
                startRt = P2_CalDataObj.GetV2R(model, startPx);
                endRt = P2_CalDataObj.GetV2R(model, endPx);

                mInspResult.Ry = GetLength(startRt, endRt);
                CogDrawLineInfo lineInfo = new CogDrawLineInfo(startPx, endPx, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
                P2_DisplayObj.DrawLine(lineInfo);

                // Ry label
                //double dDiff = mRobot_Obj_P2.Y > mRobot_Tar_P2.Y ? (mInspResult.Ry - mMarkSpec.Ry) : (mInspResult.Ry - mMarkSpec.Ry) * -1;
                //DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 100), string.Format("Ry : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Ry, dDiff));
                //CogDrawLabelInfo labelInfo = new CogDrawLabelInfo((lineInfo.Start + lineInfo.End) / 2 + new XY(20, 0), string.Format("{0:f2}mm", mInspResult.Ry));
                //P2_DisplayObj.DrawLabel(labelInfo);
                //mMarkDiff.Ry = dDiff;
            }

            // 3. Ry Length
            mCalcP2LineTool.X = Obj_P2.OutputXYT.X;
            mCalcP2LineTool.Y = Obj_P2.OutputXYT.Y;
            mCalcP2LineTool.Line = tar2.Lines[1] as CogLine;
            mCalcP2LineTool.Run();

            if (mCalcP2LineTool.RunStatus.Result == CogToolResultConstants.Accept)
            {
                startPx = new XY(Obj_P2.OutputXYT.X, Obj_P2.OutputXYT.Y);
                endPx = new XY(mCalcP2LineTool.LineX, mCalcP2LineTool.LineY);
                startRt = P2_CalDataObj.GetV2R(model, startPx);
                endRt = P2_CalDataObj.GetV2R(model, endPx);

                mInspResult.Rx = GetLength(startRt, endRt);
                CogDrawLineInfo lineInfo = new CogDrawLineInfo(startPx, endPx, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
                P2_DisplayObj.DrawLine(lineInfo);

                // Rx Label
                //double dDiff = mRobot_Obj_P2.X < mRobot_Tar_P2.X ? (mInspResult.Rx - mMarkSpec.Rx) : (mInspResult.Rx - mMarkSpec.Rx) * -1;
                //DrawLabel(P2_DisplayObj, new XY(5, GetImageHeight(P1_DisplayObj) - 150), string.Format("Rx : {0:f3}mm ( Diff : {1:f3}mm )", mInspResult.Rx, dDiff));
                //CogDrawLabelInfo labelInfo = new CogDrawLabelInfo((lineInfo.Start + lineInfo.End) / 2 + new XY(0, 20), string.Format("{0:f2}mm", mInspResult.Rx));
                //P2_DisplayObj.DrawLabel(labelInfo);
                //mMarkDiff.Rx = dDiff;

            }

            return true;
        }

    }
}
