﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.Windows.Forms;
using System.IO;

using Iva.Bplus.Struct;
using Iva.Bplus.Enums;
using Iva.Bplus.Abstract;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CogDisplay;

using Cognex.VisionPro;
using Cognex.VisionPro.ImageProcessing;

using Telerik.Windows.Controls;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public enum RunDLType
    {
        None, RB_Fail, SpecOver,
    }
    public enum Result
    {
        NONE, RB_OK, RB_NG, DL_OK, DL_NG, ALL_NG
    }
    public partial class Algo_C_PanelAttachObject : AlgoObjectBase
    {
        RunDLType RunType;
        Result Rst;
        double RBx = 0.0;
        double RBy = 0.0;
        double RBd = 0.0;
        double DLx = 0.0;
        double DLy = 0.0;
        double DLd = 0.0;
        int greyValue = 0;

        #region RDP Path field
        private bool saveRDPLog = false;
        public bool SaveRDPLog
        {
            get { return saveRDPLog; }
            set { Set<bool>(ref saveRDPLog, value, nameof(SaveRDPLog)); }
        }

        private string rdpIP = "192.168.10.203";
        public string RDPIP
        {
            get { return rdpIP; }
            set { Set<string>(ref rdpIP, value, nameof(RDPIP)); }
        }

        private string networkFolder;
        public string NetworkFolder
        {
            get { return networkFolder; }
            set { Set<string>(ref networkFolder, value, nameof(NetworkFolder)); }
        }

        private string userID;
        public string UserID
        {
            get { return userID; }
            set { Set<string>(ref userID, value, nameof(UserID)); }
        }

        private string password;
        public string Password
        {
            get { return password; }
            set { Set<string>(ref password, value, nameof(Password)); }
        }

        private string rdpLogPath = "";
        public string RDPLogPath
        {
            get { return rdpLogPath; }
            set { Set<string>(ref rdpLogPath, value, nameof(RDPLogPath)); }
        }

        public DelegateCommand SetRDPPath
        {
            get
            {
                return new DelegateCommand(obj =>
                {
                    FolderBrowserDialog dlg = new FolderBrowserDialog();
                    if (NetworkInterface.GetIsNetworkAvailable())
                    {
                        Ping pingSender = new Ping();
                        PingReply reply = pingSender.Send(RDPIP, 300);
                        if (reply.Status == IPStatus.Success)
                        {
                            dlg.SelectedPath = $"\\\\{RDPIP}\\";
                        }
                    }

                    if (dlg.ShowDialog() == DialogResult.OK)
                    {
                        RDPLogPath = dlg.SelectedPath;
                    }
                });
            }
        }

        #endregion
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        
        bool useDL = false;
        CogCircle PanelHole;
        CogCircle WindowHole;
        Dictionary<string, object> Outputs;

        [NonSerialized]
        NetworkConnector nc;
        private bool H2H(bool bWrite = true)
        {
            Rst = Result.NONE;
            RunType = RunDLType.None;
            RBx = 0.0;
            RBy = 0.0;
            RBd = 0.0;
            DLx = 0.0;
            DLy = 0.0;
            DLd = 0.0;
            greyValue = 0;

            string model = SystemModel.GetCurModel();
            errorCode = 0;
            lastJudgement = true;

            #region PLC IOs Update
            //AssignPLCData();    // 요렇게 하면 PLCValue.솰라솰라로 접근
            #endregion

            #region Inspection PANEL Hole
            if (!InputValues.ContainsKey("Outputs_H2H"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            PanelHole = new CogCircle();
            WindowHole = new CogCircle();


            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsH2H;

            //var specX = (double)mParams.Spec_HoleX.Value;
            //var specY = (double)mParams.Spec_HoleY.Value;
            //var specD = (double)mParams.Spec_HoleD.Value;
            var torX = (double)mParams.Tor_HoleX.Value;
            var torY = (double)mParams.Tor_HoleY.Value;
            var torD = (double)mParams.Tor_HoleD.Value;
            //var DL_torD = (double)mParams.Tor_DL_HoleD.Value;
            var ScaleX = (double)mParams.Scale_HoleX.Value;
            var ScaleY = (double)mParams.Scale_HoleY.Value;
            var ScaleD = (double)mParams.Scale_HoleD.Value;
            #endregion


            //mHoleSpec = new XY(specX, specY);
            mHoleTor = new XY(torX, torY);
            mHoleScale = new XY(ScaleX, ScaleY);

            holeXTor = torX;
            holeYTor = torY;
            holeDTor = torD;
            //dl_holeDTor = DL_torD;

            Outputs = InputValues["Outputs_H2H"] as Dictionary<string, object>;

            //200903 kcm SimpleTool NG Skip 추가
            if(Outputs.ContainsKey("NGSkip"))
                if (Outputs["NGSkip"] == null) return false;

            if (!Outputs.ContainsKey("PanelHole") || !Outputs.ContainsKey("WindowHole") || !Outputs.ContainsKey("PanelHoleMarkScore") || !Outputs.ContainsKey("WindowHoleMarkScore"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }

            if(!H2HProcCalc(model))  return false;

            #region Check hole inspection Spec

            // 타원형 spec 공식 : 조립기술 엄성일 프로 제공 수식 적용, khoon 20201127
            double spec = torD;

            // DL_torD가 0이나 Spec보다 클때는 Spec과 동일하게 하여 오버시에만 DL을 돌린다.
            //if (DL_torD == 0 || DL_torD > spec) DL_torD = spec;

            // Result OK, DL NotUse
            if (mObjToTapeD < spec && !useDL)
            {
                RBx = mObjToTapeXY.X;   RBy = mObjToTapeXY.Y;   RBd = mObjToTapeD;
                DLx = 0.0;              DLy = 0.0;              DLd = 0.0;

                Rst = Result.RB_OK;
                mCircleToCircle_result = "Hole OK";
            }
            // Result NG, DL USE
            else if (mObjToTapeD > spec && useDL)
            {
                RBx = 0.0;              RBy = 0.0;              RBd = 0.0;
                DLx = mObjToTapeXY.X;   DLy = mObjToTapeXY.Y;   DLd = mObjToTapeD;

                Rst = Result.DL_NG;
                mCircleToCircle_result = "Hole NG";
                lastJudgement = false;
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                H1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                //return false;
            }
            // Result NG, DL Not Use
            else if (mObjToTapeD > spec && !useDL) 
            {
                RunType = RunDLType.SpecOver;

                RBx = mObjToTapeXY.X; RBy = mObjToTapeXY.Y;     RBd = mObjToTapeD;
                /*DL 돌려 다시 계산*/

                if (!H2HProcCalc(model, true) || mObjToTapeD > spec)
                {
                    DLx = mObjToTapeXY.X; DLy = mObjToTapeXY.Y;     DLd = mObjToTapeD;
                    Rst = Result.ALL_NG;
                    mCircleToCircle_result = "Hole NG";
                    lastJudgement = false;
                    errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                    H1_DisplayObj.Judgement = (uint)Judgement.Tor_Exceed;
                }
                else
                {
                    DLx = mObjToTapeXY.X; DLy = mObjToTapeXY.Y; DLd = mObjToTapeD;
                    Rst = Result.DL_OK; mCircleToCircle_result = "Hole OK";
                }

            }
            // Result OK, DL Use
            else
            {
                RBx = 0.0; RBy = 0.0; RBd = 0.0;
                DLx = mObjToTapeXY.X; DLy = mObjToTapeXY.Y; DLd = mObjToTapeD;

                Rst = Result.DL_OK;
                mCircleToCircle_result = "Hole OK";
               
            }

            CheckGrey();

            string msg = string.Format("{0},{1:F3},{2:F3},{3:F3},{4:F3},{5:F3},{6:F3},{7},{8},{9},{10}ms", SourceID, RBx, RBy, RBd, DLx, DLy, DLd, RunType.ToString(), Rst.ToString(), HistoValue_H, stopwatch == null ? 0 : stopwatch.ElapsedMilliseconds);
            SystemLogger.WriteRunDL_H2H(msg);
            //SystemLogger.WriteRunDL_H2H(string.Empty);
            #endregion

            #region RDP Log Save
            // request by xiaomi
            if (SaveRDPLog)
            {
                var dt = DateTime.Now;
                //if (nc == null) nc = new NetworkConnector();
                // connect to network folder
                //string addr = $"\\\\{RDPIP}\\{NetworkFolder}";
                //int state = nc.TryConnectNetwork(addr, UserID, Password);
                if(/*state == 0 &&*/ Directory.Exists(RDPLogPath))
                {
                    if (string.IsNullOrEmpty(SourceID))
                        SourceID = "Nothing";
                    var subpath = $"{dt.Year}/{dt.Month:d2}/{dt.Day:d2}/{dt.Hour:d2}/{dt.Minute:d2}/{SourceID}";
                    var path = Path.Combine(RDPLogPath, subpath);
                    if (!Directory.Exists(path)) Directory.CreateDirectory(path);
                    // file name    
                    string judgement = LastJudgement ? "OK" : "NG";
                    string filename = $"{judgement}.jpg";
                    string file = Path.Combine(path, filename);
                    if (!File.Exists(file))
                    {
                        // save
                        if (!H1_DisplayObj.SaveDLRanOverlayImage(file))
                        {
                            SystemLogger.WriteExceptionLog("It's fail to save RDP Image Log");
                        }
                    }
                }
                else
                {
                    SystemLogger.WriteExceptionLog("It's invalid RDP Log path");
                }
            }

            #endregion

            //SaveLog("D:\\HoleAlgorithmTest\\", "a.csv", string.Format(", {0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}",
            //    mCircleToCircle_result, Math.Round(mObjToTapeXY.X, 3), Math.Round(mObjToTapeXY.Y, 3), Math.Round(mObjToTapeD, 3),
            //    Math.Round(mCircleToCircle[(int)ePos.Top], 3), Math.Round(mCircleToCircle[(int)ePos.Bottom], 3), Math.Round(mCircleToCircle[(int)ePos.Left], 3), Math.Round(mCircleToCircle[(int)ePos.Right], 3)));

            #endregion


            #region Result Data Update(DataGridView Insert)
            AlgoRst = new Algo_C_PanelAttachResultH2H
            {
                Name = name,
                ID = sourceID,

                H_Result = mCircleToCircle_result,

                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),

                Hx = Math.Round(mObjToTapeXY.X, 3),
                Hy = Math.Round(mObjToTapeXY.Y, 3),
                Hd = Math.Round(mObjToTapeD, 3),

                H_Top = Math.Round(mCircleToCircle[(int)ePos.Top], 3),
                H_Bottom = Math.Round(mCircleToCircle[(int)ePos.Bottom], 3),
                H_Left = Math.Round(mCircleToCircle[(int)ePos.Left], 3),
                H_Right = Math.Round(mCircleToCircle[(int)ePos.Right], 3),


                Panel_H_Score = panelHoleMarkScore,
                Window_H_Score = windowHoleMarkScore,
                Hole_X_Tor = holeXTor,
                Hole_Y_Tor = holeYTor,
                Hole_D_Tor = holeDTor,

            };
            #endregion
            SystemLogger.WriteAlignDBLog(name, AlgoRst);
            //#endregion

            #region Vision Write (Result & FDC)
            WriteVisionIO(AlgoRst);
            #endregion
            return lastJudgement;
        }

        public void CheckGrey()
        {

            var dspObj = Outputs["Display"] as Iva.Bplus.Modules.CogDisplay.CogDisplayObject;

            CogDsH.Image = null;

            CogDsH.Image = dspObj.CogDs.Image as Cognex.VisionPro.ICogImage;
            

            var tool = new CogHistogramTool();
            tool.InputImage = CogDsH.Image;
            tool.Region = AreaH;
            tool.Run();

            HistoValue_H = tool.Result != null ? (double)tool.Result.Mean : 0;

            HistoValue_H = Math.Round(HistoValue_H, 2);

            DrawGray(H1_DisplayObj, AreaH, HistoValue_H);
        }
        public void HoleGreyTest()
        {

            if (CogDsH.Image == null) return;

            var tool = new CogHistogramTool();
            tool.InputImage = CogDsH.Image;
            tool.Region = AreaH;
            tool.Run();

            HistoValue_H = tool.Result != null ? (double)tool.Result.Mean : 0;
            HistoValue_H = Math.Round(HistoValue_H, 2);
        }

        void DrawGray(CogDisplayObject dspObject, CogRectangle Area, double val)
        {
            Area.Color = CogColorConstants.Purple;
            dspObject?.CogDs.StaticGraphics.Add(Area, "Area");
            int x = (int)dspObject?.CogDs.Image.Width;
            int y = (int)dspObject?.CogDs.Image.Height;

            string msg = string.Format("Value : {0:F2}", val);
            CogDrawLabelInfo labelInfo = new CogDrawLabelInfo();

            labelInfo.UseBackColor = true;
            labelInfo.BackColor = CogColorConstants.White;
            labelInfo.Offset = new XY(Area.X, Area.Y + Area.Height); // mErrOffset;
            labelInfo.Alignment = CogGraphicLabelAlignmentConstants.TopLeft;
            labelInfo.Text = string.Format(msg);

            dspObject?.DrawLabel(labelInfo);
 
            labelInfo = null;
        }
        bool H2HProcCalc(string _model, bool reconfirm = false)
        {
            double[] c2c = new double[4];
            double[] r2c = new double[4];
            //if (reconfirm)
            //{
            H1_DisplayObj?.CogDs.InteractiveGraphics.Clear();
                H1_DisplayObj?.CogDs.StaticGraphics.Clear();
            //}
            #region Model Data prepare
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(_model, out modelParams)) return false;
            var mParams = modelParams as Algo_C_PanelAttachModelParamsH2H;

            var torX = (double)mParams.Tor_HoleX.Value;
            var torY = (double)mParams.Tor_HoleY.Value;
            var torD = (double)mParams.Tor_HoleD.Value;
            //var DL_torD = (double)mParams.Tor_DL_HoleD.Value;

            #endregion

            useDL = false;
            PanelHole = Outputs["PanelHole"] as CogCircle;
            WindowHole = Outputs["WindowHole"] as CogCircle;
            windowHoleMarkScore = Math.Round((double)Outputs["WindowHoleMarkScore"] * 100, 2);
            panelHoleMarkScore = Math.Round((double)Outputs["PanelHoleMarkScore"] * 100, 2);

            XY pPanel_H;
            XY pWindow_H;
            if (WindowHole == null || double.IsNaN(windowHoleMarkScore))
            {
                // Mark Data가 Null임
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                DrawErrDisp("Err_Mark_Info_Missing");
                return false;
            }
            else
            {
                pWindow_H = new XY(WindowHole.CenterX, WindowHole.CenterY);
                WindowHole.LineWidthInScreenPixels = 2;
                WindowHole.Color = CogColorConstants.Blue;
                /* Window Draw */
                H1_DisplayObj.AddGraphic(WindowHole as ICogGraphic, "WindowHole");
                CogDrawMarkerInfo windowMark = new CogDrawMarkerInfo(new XYT(WindowHole.CenterX, WindowHole.CenterY, 0), 100, CogColorConstants.Blue);
                H1_DisplayObj.DrawMaker(windowMark);
            }

            System.Windows.Rect rect = new System.Windows.Rect();
            if (PanelHole == null || double.IsNaN(panelHoleMarkScore) || reconfirm)
            {
                // Mark Data가 Null임
                var dspObj = Outputs["Display"] as Iva.Bplus.Modules.CogDisplay.CogDisplayObject;

                var Panel_DL_Hole = FindDL(out rect);

                if (!reconfirm) { RunType = RunDLType.RB_Fail; }
                
                if (Panel_DL_Hole == null)
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    DrawErrDisp("Err_Mark_Info_Missing");
                    return false;
                }
                pPanel_H = Panel_DL_Hole;
                CogDrawMarkerInfo PanelMark = new CogDrawMarkerInfo(new XYT(pPanel_H.X, pPanel_H.Y, 0), 100, CogColorConstants.Orange);
                H1_DisplayObj.DrawMaker(PanelMark);
                useDL = true;
            }
            else
            {
                pPanel_H = new XY(PanelHole.CenterX, PanelHole.CenterY);
                PanelHole.LineWidthInScreenPixels = 2;
                PanelHole.Color = CogColorConstants.Orange;
                H1_DisplayObj.AddGraphic(PanelHole as ICogGraphic, "PanelHole");
                CogDrawMarkerInfo PanelMark = new CogDrawMarkerInfo(new XYT(pPanel_H.X, pPanel_H.Y, 0), 100, CogColorConstants.Orange);
                H1_DisplayObj.DrawMaker(PanelMark);
            }

            mRobot_Panel_H = H1_CalDataObj.GetV2R(_model, pPanel_H);
            mRobot_Window_H = H1_CalDataObj.GetV2R(_model, pWindow_H);

            CalcHoleLength_PANEL(pWindow_H, pPanel_H, mRobot_Window_H, mRobot_Panel_H);


            if (!useDL)
            {
                CircleToCircleDistance_PANEL(_model, WindowHole, PanelHole);

                c2c[0] = mCircleToCircle[0];
                c2c[1] = mCircleToCircle[1];
                c2c[2] = mCircleToCircle[2];
                c2c[3] = mCircleToCircle[3];
            }
            else
            {
                RectangleToCircleDistance_PANEL(_model, WindowHole, rect);
                r2c[0] = mCircleToCircle[0];
                r2c[1] = mCircleToCircle[1];
                r2c[2] = mCircleToCircle[2];
                r2c[3] = mCircleToCircle[3];
            }


            
            #region Draw Label
            DrawResultLabel_Panel();
            #endregion

            // 타원형 spec 공식 : 조립기술 엄성일 프로 제공 수식 적용, khoon 20201127
            double a = torX;
            double b = torY;
            double spec = torD;
            double x = mObjToTapeXY.X;
            double y = mObjToTapeXY.Y;

            if (a != 0 && b != 0)
            {
                double a1 = Math.Pow(spec / a * x, 2);
                double b1 = Math.Pow(spec / b * y, 2);
                mObjToTapeD = Math.Sqrt(a1 + b1);
            }


            return true;
        }

        [field:NonSerialized]
        Stopwatch stopwatch = new Stopwatch(); 
        XY FindDL(out System.Windows.Rect rect)
        {

            if (stopwatch == null) stopwatch = new Stopwatch();

            stopwatch.Reset();
            stopwatch.Start();

            var owner = SystemObject_System.GetOwnerModule(this.name, typeof(ToolActionBase));
            var act = owner.ModAction as ToolActionBase;
            var obj = act.ModObject as ToolObjectBase;

            XYT rstXYT;
            System.Windows.Rect rstRect;
            string err;

            if (obj.FindSDC_DL(Name, SourceID, obj.InputImage, out rstXYT, out rstRect, out err))
            {
                obj.DisplayObj.DrawDLOverlay(rstXYT, rstRect, false);
                rect = rstRect;
                return new XY(rstXYT.X, rstXYT.Y);
            }
            stopwatch.Stop();
            rect = rstRect;
            return null;
        }

        void CalcHoleLength_PANEL(XY pObj, XY pTape, XY rObjPos, XY rTapePos)
        {
            string model = SystemModel.GetCurModel();

            if (mObjToTapeXYOrg == null) mObjToTapeXYOrg = new XY();
            if (mObjToTapeXY == null) mObjToTapeXY = new XY();
            if (mHoleScale == null) mHoleScale = new XY(1.0, 1.0);


            // Panel Circle to Tape Circle Distance XY
            if (P1_CalDataObj == null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                DrawErrDisp("Err_CalData_Is_Null");

                P1_CalDataObj.GetRotateCenter(model).X = 0;
            }

            if (P1_CalDataObj.GetRotateCenter(model).X > 0)
                mObjToTapeXY.X = rObjPos.X - rTapePos.X;
            else
                mObjToTapeXY.X = rTapePos.X - rObjPos.X;

            mObjToTapeXY.Y = rTapePos.Y - rObjPos.Y;

            // 일단 값을 담는다.
            mObjToTapeXYOrg.X = mObjToTapeXY.X;
            mObjToTapeXYOrg.Y = mObjToTapeXY.Y;

            // scale 추가
            mObjToTapeXY.X *= mHoleScale.X;
            mObjToTapeXY.Y *= mHoleScale.Y;

            XY start = pObj; XY end = new XY(pObj.X, pTape.Y);
            CogDrawLineInfo lineInfo = new CogDrawLineInfo(start, end, 1, CogColorConstants.Orange, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
            H1_DisplayObj.DrawLine(lineInfo);

            start = pTape; end = new XY(pObj.X, pTape.Y);
            lineInfo = new CogDrawLineInfo(start, end, 1, CogColorConstants.Blue, CogLineSegmentAdornmentConstants.SolidArrow, CogLineSegmentAdornmentConstants.SolidArrow);
            H1_DisplayObj.DrawLine(lineInfo);
        }

        void CircleToCircleDistance_PANEL(string model, CogCircle hole1, CogCircle hole2)
        {
            try
            {
                mCircleToCircle = new double[4] { 0.0, 0.0, 0.0, 0.0 };

                XY[] pHole1EdgePoint = new XY[4];
                XY[] pHole2EdgePoint = new XY[4];

                XY[] rHole1EdgePoint = new XY[4];
                XY[] rHole2EdgePoint = new XY[4];

                XY panelHoleXY = new XY(hole1.CenterX, hole1.CenterY);

                CogLine panelHoleLineV = new CogLine();
                CogLine panelHoleLineH = new CogLine();

                panelHoleLineV.SetFromStartXYEndXY(panelHoleXY.X, 0, panelHoleXY.X, panelHoleXY.Y + hole1.Radius * 2);
                panelHoleLineH.SetFromStartXYEndXY(0, panelHoleXY.Y, panelHoleXY.X + hole1.Radius * 2, panelHoleXY.Y);

                // 1. hole 1 Up, Down Edge Search
                mIntersectLToC.InputImage = H1_DisplayObj.CogDs.Image as ICogImage;
                mIntersectLToC.Line = panelHoleLineV;
                mIntersectLToC.InputCircle = hole1;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole1EdgePoint[(int)ePos.Top] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole1EdgePoint[(int)ePos.Bottom] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole1EdgePoint[(int)ePos.Top] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Top]);
                    rHole1EdgePoint[(int)ePos.Bottom] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Bottom]);
                }

                // 2. hole 2 Up, Down Edge Searchb
                mIntersectLToC.Line = panelHoleLineV;
                mIntersectLToC.InputCircle = hole2;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole2EdgePoint[(int)ePos.Top] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole2EdgePoint[(int)ePos.Bottom] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole2EdgePoint[(int)ePos.Top] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Top]);
                    rHole2EdgePoint[(int)ePos.Bottom] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Bottom]);
                }

                // 3. hole 1 Left, Down Right Search
                mIntersectLToC.Line = panelHoleLineH;
                mIntersectLToC.InputCircle = hole1;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole1EdgePoint[(int)ePos.Left] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole1EdgePoint[(int)ePos.Right] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole1EdgePoint[(int)ePos.Left] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Left]);
                    rHole1EdgePoint[(int)ePos.Right] = H1_CalDataObj.GetV2R(model, pHole1EdgePoint[(int)ePos.Right]);
                }


                // 4. hole 2 Left, Down Right Search
                mIntersectLToC.Line = panelHoleLineH;
                mIntersectLToC.InputCircle = hole2;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pHole2EdgePoint[(int)ePos.Left] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pHole2EdgePoint[(int)ePos.Right] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rHole2EdgePoint[(int)ePos.Left] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Left]);
                    rHole2EdgePoint[(int)ePos.Right] = H1_CalDataObj.GetV2R(model, pHole2EdgePoint[(int)ePos.Right]);
                }

                // 5. Calc Distance
                if (rHole1EdgePoint[(int)ePos.Top] == null || rHole1EdgePoint[(int)ePos.Bottom] == null || rHole1EdgePoint[(int)ePos.Left] == null || rHole1EdgePoint[(int)ePos.Right] == null
                    || rHole2EdgePoint[(int)ePos.Top] == null || rHole2EdgePoint[(int)ePos.Bottom] == null || rHole2EdgePoint[(int)ePos.Left] == null || rHole2EdgePoint[(int)ePos.Right] == null
                    )
                {
                    mCircleToCircle[(int)ePos.Top] = 0.0;
                    mCircleToCircle[(int)ePos.Bottom] = 0.0;
                    mCircleToCircle[(int)ePos.Left] = 0.0;
                    mCircleToCircle[(int)ePos.Right] = 0.0;
                }
                else
                {
                    mCircleToCircle[(int)ePos.Top] = GetLength(rHole1EdgePoint[(int)ePos.Top], rHole2EdgePoint[(int)ePos.Top]);
                    mCircleToCircle[(int)ePos.Bottom] = GetLength(rHole1EdgePoint[(int)ePos.Bottom], rHole2EdgePoint[(int)ePos.Bottom]);
                    mCircleToCircle[(int)ePos.Left] = GetLength(rHole1EdgePoint[(int)ePos.Left], rHole2EdgePoint[(int)ePos.Left]);
                    mCircleToCircle[(int)ePos.Right] = GetLength(rHole1EdgePoint[(int)ePos.Right], rHole2EdgePoint[(int)ePos.Right]);

                    // scale 추가
                    mCircleToCircle[(int)ePos.Top] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Bottom] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Left] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Right] *= mHoleScale.Y;
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        void RectangleToCircleDistance_PANEL(string model, CogCircle hole, System.Windows.Rect rect)
        {
            try
            {
                mCircleToCircle = new double[4] { 0.0, 0.0, 0.0, 0.0 };

                XY[] pRect1EdgePoint = new XY[4];
                XY[] pRect2EdgePoint = new XY[4];

                XY[] rRect1EdgePoint = new XY[4];
                XY[] rHole2EdgePoint = new XY[4];

                XY panelHoleXY = new XY(rect.X + rect.Width / 2, rect.Y + rect.Height / 2);

                CogLine panelHoleLineV = new CogLine();
                CogLine panelHoleLineH = new CogLine();

                panelHoleLineV.SetFromStartXYEndXY(panelHoleXY.X, 0, panelHoleXY.X, panelHoleXY.Y + rect.Height);
                panelHoleLineH.SetFromStartXYEndXY(0, panelHoleXY.Y, panelHoleXY.X + rect.Width, panelHoleXY.Y);

                // 1. hole 1 Up, Down Edge Search
                mIntersectLToC.InputImage = H1_DisplayObj.CogDs.Image as ICogImage;
                mIntersectLToC.Line = panelHoleLineV;
                mIntersectLToC.InputCircle = hole;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pRect1EdgePoint[(int)ePos.Top] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pRect1EdgePoint[(int)ePos.Bottom] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rRect1EdgePoint[(int)ePos.Top] = H1_CalDataObj.GetV2R(model, pRect1EdgePoint[(int)ePos.Top]);
                    rRect1EdgePoint[(int)ePos.Bottom] = H1_CalDataObj.GetV2R(model, pRect1EdgePoint[(int)ePos.Bottom]);
                }

                // 2. hole 2 Up, Down Edge Searchb

                pRect2EdgePoint[(int)ePos.Top] = new XY(rect.X + rect.Width / 2, rect.Y);
                pRect2EdgePoint[(int)ePos.Bottom] = new XY(rect.X + rect.Width / 2, rect.Y + rect.Height);
                rHole2EdgePoint[(int)ePos.Top] = H1_CalDataObj.GetV2R(model, pRect2EdgePoint[(int)ePos.Top]);
                rHole2EdgePoint[(int)ePos.Bottom] = H1_CalDataObj.GetV2R(model, pRect2EdgePoint[(int)ePos.Bottom]);
   
                // 3. hole 1 Left, Down Right Search
                mIntersectLToC.Line = panelHoleLineH;
                mIntersectLToC.InputCircle = hole;
                mIntersectLToC.Run();
                if (mIntersectLToC.RunStatus.Result == CogToolResultConstants.Accept)
                {
                    pRect1EdgePoint[(int)ePos.Left] = new XY(mIntersectLToC.X0, mIntersectLToC.Y0);
                    pRect1EdgePoint[(int)ePos.Right] = new XY(mIntersectLToC.X1, mIntersectLToC.Y1);
                    rRect1EdgePoint[(int)ePos.Left] = H1_CalDataObj.GetV2R(model, pRect1EdgePoint[(int)ePos.Left]);
                    rRect1EdgePoint[(int)ePos.Right] = H1_CalDataObj.GetV2R(model, pRect1EdgePoint[(int)ePos.Right]);
                }


                // 4. hole 2 Left, Down Right Search

                pRect2EdgePoint[(int)ePos.Left] = new XY(rect.X, rect.Y + rect.Height / 2);
                pRect2EdgePoint[(int)ePos.Right] = new XY(rect.X + rect.Width, rect.Y + rect.Height / 2);
                rHole2EdgePoint[(int)ePos.Left] = H1_CalDataObj.GetV2R(model, pRect2EdgePoint[(int)ePos.Left]);
                rHole2EdgePoint[(int)ePos.Right] = H1_CalDataObj.GetV2R(model, pRect2EdgePoint[(int)ePos.Right]);
   
                // 5. Calc Distance
                if (rRect1EdgePoint[(int)ePos.Top] == null || rRect1EdgePoint[(int)ePos.Bottom] == null || rRect1EdgePoint[(int)ePos.Left] == null || rRect1EdgePoint[(int)ePos.Right] == null
                    || rHole2EdgePoint[(int)ePos.Top] == null || rHole2EdgePoint[(int)ePos.Bottom] == null || rHole2EdgePoint[(int)ePos.Left] == null || rHole2EdgePoint[(int)ePos.Right] == null
                    )
                {
                    mCircleToCircle[(int)ePos.Top] = 0.0;
                    mCircleToCircle[(int)ePos.Bottom] = 0.0;
                    mCircleToCircle[(int)ePos.Left] = 0.0;
                    mCircleToCircle[(int)ePos.Right] = 0.0;
                }
                else
                {
                    mCircleToCircle[(int)ePos.Top] = GetLength(rRect1EdgePoint[(int)ePos.Top], rHole2EdgePoint[(int)ePos.Top]);
                    mCircleToCircle[(int)ePos.Bottom] = GetLength(rRect1EdgePoint[(int)ePos.Bottom], rHole2EdgePoint[(int)ePos.Bottom]);
                    mCircleToCircle[(int)ePos.Left] = GetLength(rRect1EdgePoint[(int)ePos.Left], rHole2EdgePoint[(int)ePos.Left]);
                    mCircleToCircle[(int)ePos.Right] = GetLength(rRect1EdgePoint[(int)ePos.Right], rHole2EdgePoint[(int)ePos.Right]);

                    // scale 추가
                    mCircleToCircle[(int)ePos.Top] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Bottom] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Left] *= mHoleScale.Y;
                    mCircleToCircle[(int)ePos.Right] *= mHoleScale.Y;
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        bool DrawResultLabel_Panel()
        {
            SystemFunc.GetApp().Dispatcher.BeginInvoke(new Action(delegate
            {
                // Hole Result
                DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 200), string.Format("X : {0:f3}mm", mObjToTapeXY.X));
                DrawLabel(H1_DisplayObj, new XY(700, GetImageHeight(H1_DisplayObj) - 200), string.Format("Y : {0:f3}mm", mObjToTapeXY.Y));
                DrawLabel(H1_DisplayObj, new XY(5, GetImageHeight(H1_DisplayObj) - 100), string.Format("D : {0:f3}mm", mObjToTapeD));
            }));

            return true;
        }

    }

}
