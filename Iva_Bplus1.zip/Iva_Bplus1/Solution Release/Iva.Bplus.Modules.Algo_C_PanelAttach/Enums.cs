﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public enum ProcessType { PRE, MAIN, INSPECT, TAPE, PANEL, H2H}
    public enum CalcType { Center_2P, Reference_2P, PickUp_2P, Hole_3P, Center_3P, Moving_3P }
    public enum ThetaDirection { Normal, Reverse }
    public enum ePos { Top = 0, Bottom, Left, Right }
    public enum HoleCalcType { PanelToTape, WindowToTape }
    public enum LineCalcType { P2P, P2Line }
    public enum XYDirection { Plus = 1, Minus = -1 }
    public enum CalcAngle3P { Use2P, Use3P }
    public enum InspType { Hole, Edge, }

}

