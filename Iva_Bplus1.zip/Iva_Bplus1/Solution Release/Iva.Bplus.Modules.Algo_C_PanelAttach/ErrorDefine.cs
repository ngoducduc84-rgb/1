﻿using Iva.Bplus.Enums;
using Iva.Bplus.Struct;

using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public partial class Algo_C_PanelAttachAction
    {
        #region [Error Script] Algo2PAlignAction: 16001 ~ 16100

        public override void ErrorDefine()
        {
            base.ErrorDefine();
        }
        #endregion
    }
}
