﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Iva.Bplus.Enums;
using Telerik.Windows.Data;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]

    public partial class Algo_C_PanelAttachDefaultOptions : AlgoOptions
    {
        // 2021.04.05 jyh 고객님께서 무주건 L-Check를 사용하고 싶다고 하신다.
        //protected AlgoOption useLCheck;
        //public AlgoOption UseLCheck { get { return useLCheck; } set { if (useLCheck == value) return; useLCheck = value; this.OnPropertyChanged(nameof(UseLCheck)); } }
        //public Algo_C_PanelAttachDefaultOptions()
        //{
        //    //AlignMode = new AlgoOption("AlignMode", OnOff.Off, "Use Panel 3Point Align : Off - Only 4Point Align, On - 4 & 3Point Align");
        //    UseLCheck = new AlgoOption("Use L Check", OnOff.Off, "Off - Use L-Check, On - Use L-Check");
        //}
    }
    [SerializableAttribute]
    public partial class Algo_C_PanelAttachModelOptions : Algo_C_PanelAttachDefaultOptions
    {
        private AlgoOption useCheckAssemble_L;
        private AlgoOption useCheckAssemble_R;
        public AlgoOption UseCheckAssemble_L { get { return useCheckAssemble_L; } set { if (useCheckAssemble_L == value) return; useCheckAssemble_L = value; this.OnPropertyChanged(nameof(UseCheckAssemble_L)); } }
        public AlgoOption UseCheckAssemble_R { get { return useCheckAssemble_R; } set { if (useCheckAssemble_R == value) return; useCheckAssemble_R = value; this.OnPropertyChanged(nameof(UseCheckAssemble_L)); } }

        public Algo_C_PanelAttachModelOptions()
            :base()
        {
            //AlignMode = new AlgoOption("AlignMode", OnOff.Off, "Use Panel 3Point Align : Off - Only 4Point Align, On - 4 & 3Point Align");
            UseCheckAssemble_L = new AlgoOption("Use Left Check Assemble", OnOff.Off, "Off - Skip, On - Use Left Check Assembled");
            UseCheckAssemble_R = new AlgoOption("Use Right Check Assemble", OnOff.Off, "Off - Skip, On - Use Right Check Assembled");
        }
    }

}
