﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]

    public partial class Algo_C_PanelAttachModelParams : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        private AlgoParam length_Obj;
        private AlgoParam tor_Obj;
        private AlgoParam scale_Length;
        private AlgoParam weightP1;
        private AlgoParam weightP2;
        private AlgoParam weightH1;


        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        public AlgoParam Length_Obj { get { return length_Obj; } set { if (length_Obj == value) return; length_Obj = value; this.OnPropertyChanged(nameof(Length_Obj)); } }
        public AlgoParam Tor_Obj { get { return tor_Obj; } set { if (tor_Obj == value) return; tor_Obj = value; this.OnPropertyChanged(nameof(Tor_Obj)); } }
        public AlgoParam Scale_Length { get { return scale_Length; } set { if (scale_Length == value) return; scale_Length = value; this.OnPropertyChanged(nameof(Scale_Length)); } }

        public AlgoParam WeightP1 { get { return weightP1; } set { if (weightP1 == value) return; weightP1 = value; this.OnPropertyChanged(nameof(WeightP1)); } }
        public AlgoParam WeightP2 { get { return weightP2; } set { if (weightP2 == value) return; weightP2 = value; this.OnPropertyChanged(nameof(WeightP2)); } }
        public AlgoParam WeightH1 { get { return weightH1; } set { if (weightH1 == value) return; weightH1 = value; this.OnPropertyChanged(nameof(WeightH1)); } }



        public Algo_C_PanelAttachModelParams()
           : base()
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);

            Length_Obj = new AlgoParam("Length_Obj", "mm", typeof(double), 0.0, "Glass Length Spec(Mark To Mark)", (double)0, (double)100);
            Tor_Obj = new AlgoParam("Tor_Obj", "mm", typeof(double), 0.0, "Glass Length Tolerance", (double)0, (double)1);
            Scale_Length = new AlgoParam("Scale_Length", "mm", typeof(double), 0.0, "Length Scale", (double)0.5, (double)3);

            WeightP1 = new AlgoParam("WeightP1", "mm", typeof(double), 1.0, "Hole align Param : Moveing Weight P1", (double)0, (double)100);
            WeightP2 = new AlgoParam("WeightP2", "mm", typeof(double), 1.0, "Hole align Param : Moveing Weight P2", (double)0, (double)100);
            WeightH1 = new AlgoParam("WeightH1", "mm", typeof(double), 1.0, "Hole align Param : Moveing Weight H1", (double)0, (double)100);
        }
    }

    [SerializableAttribute]
    public class ScaleParamsSet : AlgoParams
    {
        #region [fiedls]
        private string name;
        private double spec;
        private double tor;
        private double curValue;
        private double measure;
        private double scaleValue;

        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public double Spec
        {
            get { return spec; }
            set { if (value == spec) return; spec = value; OnPropertyChanged(nameof(Spec)); }
        }
        public double Tor
        {
            get { return tor; }
            set { if (value == tor) return; tor = value; OnPropertyChanged(nameof(Tor)); }
        }
        public double CurValue
        {
            get { return curValue; }
            set { if (value == curValue) return; curValue = value; OnPropertyChanged(nameof(CurValue)); }
        }
        public double Measure
        {
            get { return measure; }
            set { if (value == measure) return; measure = value; OnPropertyChanged(nameof(Measure)); }
        }
        public double Scale
        {
            get { return scaleValue; }
            set { if (value == scaleValue) return; scaleValue = value; OnPropertyChanged(nameof(Scale)); }
        }
        #endregion


        public ScaleParamsSet() : base() { }
        public ScaleParamsSet(string _name, double _spec, double _tor, double _value, double _measure, double _scale)
            : base() 
        {
            name = _name;
            spec = _spec;
            tor = _tor;
            curValue = _value;
            measure = _measure;
            scaleValue = _scale;
        }
    }


    [SerializableAttribute]
    public class LengthParamsSet : AlgoParams
    {
        #region [fiedls]
        private string name;
        private double spec;
        private double tor;
        private double curValue;

        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public double Spec
        {
            get { return spec; }
            set { if (value == spec) return; spec = value; OnPropertyChanged(nameof(Spec)); }
        }
        public double Tor
        {
            get { return tor; }
            set { if (value == tor) return; tor = value; OnPropertyChanged(nameof(Tor)); }
        }
        public double CurValue
        {
            get { return curValue; }
            set { if (value == curValue) return; curValue = value; OnPropertyChanged(nameof(CurValue)); }
        }
        #endregion


        public LengthParamsSet() : base() { }
        public LengthParamsSet(string _name, double _spec, double _tor, double _value)
           : base()
        {
            name = _name;
            spec = _spec;
            tor = _tor;
            curValue = _value;
        }
    }

}
