﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]

    public partial class Algo_C_PanelAttachModelParamsH2H : AlgoParams
    {
        //
        //private AlgoParam spec_HoleX;
        //private AlgoParam spec_HoleY;
        //private AlgoParam spec_HoleD;
        private AlgoParam tor_HoleX;
        private AlgoParam tor_HoleY;
        private AlgoParam tor_HoleD;
        //private AlgoParam tor_DL_HoleD;
        private AlgoParam scale_HoleX;
        private AlgoParam scale_HoleY;
        private AlgoParam scale_HoleD;

        //public AlgoParam Spec_HoleX { get { return spec_HoleX; } set { if (spec_HoleX == value) return; spec_HoleX = value; this.OnPropertyChanged(nameof(Spec_HoleX)); } }
        public AlgoParam Tor_HoleX { get { return tor_HoleX; } set { if (tor_HoleX == value) return; tor_HoleX = value; this.OnPropertyChanged(nameof(Tor_HoleX)); } }
        //public AlgoParam Spec_HoleY { get { return spec_HoleY; } set { if (spec_HoleY == value) return; spec_HoleY = value; this.OnPropertyChanged(nameof(Spec_HoleY)); } }
        public AlgoParam Tor_HoleY { get { return tor_HoleY; } set { if (tor_HoleY == value) return; tor_HoleY = value; this.OnPropertyChanged(nameof(Tor_HoleY)); } }

        //public AlgoParam Spec_HoleD { get { return spec_HoleD; } set { if (spec_HoleD == value) return; spec_HoleD = value; this.OnPropertyChanged(nameof(Spec_HoleD)); } }
        public AlgoParam Tor_HoleD { get { return tor_HoleD; } set { if (tor_HoleD == value) return; tor_HoleD = value; this.OnPropertyChanged(nameof(Tor_HoleD)); } }
        //public AlgoParam Tor_DL_HoleD { get { return tor_DL_HoleD; } set { if (tor_DL_HoleD == value) return; tor_DL_HoleD = value; this.OnPropertyChanged(nameof(Tor_DL_HoleD)); } }

        public AlgoParam Scale_HoleX { get { return scale_HoleX; } set { if (scale_HoleX == value) return; scale_HoleX = value; this.OnPropertyChanged(nameof(Scale_HoleX)); } }
        public AlgoParam Scale_HoleY { get { return scale_HoleY; } set { if (scale_HoleY == value) return; scale_HoleY = value; this.OnPropertyChanged(nameof(Scale_HoleY)); } }
        public AlgoParam Scale_HoleD { get { return scale_HoleD; } set { if (scale_HoleD == value) return; scale_HoleD = value; this.OnPropertyChanged(nameof(Scale_HoleD)); } }




        public Algo_C_PanelAttachModelParamsH2H()
           : base()
        {
            //Spec_HoleX = new AlgoParam("Spec_HoleX", "mm", typeof(double), 0.0, "HoleToHole Spec X ", (double)0.0, (double)1);
            Tor_HoleX = new AlgoParam("Tor_HoleX", "mm", typeof(double), 0.0, "HoleToHole Spec Tor x", (double)0.0, (double)1);
            //Spec_HoleY = new AlgoParam("Spec_HoleY", "mm", typeof(double), 0.0, "HoleToHole Spec Y ", (double)0.0, (double)1);
            Tor_HoleY = new AlgoParam("Tor_HoleY", "mm", typeof(double), 0.0, "HoleToHole Spec Tor Y", (double)0.0, (double)1);
            //Spec_HoleD = new AlgoParam("Spec_HoleD", "mm", typeof(double), 0.0, "HoleToHole Spec D ", (double)0.0, (double)1);
            Tor_HoleD = new AlgoParam("Tor_HoleD", "mm", typeof(double), 0.0, "HoleToHole Spec Tor D", (double)0.0, (double)1);
            //Tor_DL_HoleD = new AlgoParam("Tor_DL_HoleD", "mm", typeof(double), 0.0, "D/L Run Spec Tor D", (double)0.0, (double)1);
            Scale_HoleX = new AlgoParam("Scale_HoleX", "mm", typeof(double), 1.0, "Attach Distance Hole X", (double)0.0, (double)1);
            Scale_HoleY = new AlgoParam("Scale_HoleY", "mm", typeof(double), 1.0, "Attach Distance Hole Y", (double)0.0, (double)1);
            Scale_HoleD = new AlgoParam("Scale_HoleD", "mm", typeof(double), 1.0, "Attach Distance Hole D", (double)0.0, (double)1);
        }
    }
}
