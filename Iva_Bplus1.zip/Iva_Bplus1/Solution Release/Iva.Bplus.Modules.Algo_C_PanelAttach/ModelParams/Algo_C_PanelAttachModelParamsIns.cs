﻿
using Iva.Bplus.Struct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]

    public partial class Algo_C_PanelAttachModelParamsIns : AlgoParams
    {
        private AlgoParam limitX;
        private AlgoParam limitY;
        private AlgoParam limitT;
        private AlgoParam length_Obj;
        private AlgoParam tor_Obj;
        private AlgoParam length_Tar;
        private AlgoParam tor_Tar;
        private AlgoParam scale_Length;

        // Distance Lx, Ly, Rx, Ry : Mark To Mark 거리임.
        private AlgoParam spec_Lx;
        private AlgoParam spec_Ly;
        private AlgoParam spec_Rx;
        private AlgoParam spec_Ry;
        private AlgoParam spec_T;

        // Scale Lx, Ly, Rx, Ry : 검사기와 정합성을 맞춰주기 위한 Factor임.
        private AlgoParam scale_Lx;
        private AlgoParam scale_Ly;
        private AlgoParam scale_Rx;
        private AlgoParam scale_Ry;
        private AlgoParam scale_T;

        // Range X,Y : Distance +- Range, Min Max임.
        private AlgoParam tor_Lx;
        private AlgoParam tor_Ly;
        private AlgoParam tor_Rx;
        private AlgoParam tor_Ry;
        private AlgoParam tor_T;

        //
        private AlgoParam spec_HoleX;
        private AlgoParam spec_HoleY;
        private AlgoParam spec_HoleD;
        private AlgoParam tor_HoleX;
        private AlgoParam tor_HoleY;
        private AlgoParam tor_HoleD;
        private AlgoParam scale_HoleX;
        private AlgoParam scale_HoleY;
        private AlgoParam scale_HoleD;

        public AlgoParam LimitX { get { return limitX; } set { if (limitX == value) return; limitX = value; this.OnPropertyChanged(nameof(LimitX)); } }
        public AlgoParam LimitY { get { return limitY; } set { if (limitY == value) return; limitY = value; this.OnPropertyChanged(nameof(LimitY)); } }
        public AlgoParam LimitT { get { return limitT; } set { if (limitT == value) return; limitT = value; this.OnPropertyChanged(nameof(LimitT)); } }
        public AlgoParam Length_Obj { get { return length_Obj; } set { if (length_Obj == value) return; length_Obj = value; this.OnPropertyChanged(nameof(Length_Obj)); } }
        public AlgoParam Tor_Obj { get { return tor_Obj; } set { if (tor_Obj == value) return; tor_Obj = value; this.OnPropertyChanged(nameof(Tor_Obj)); } }
        public AlgoParam Length_Tar { get { return length_Tar; } set { if (length_Tar == value) return; length_Tar = value; this.OnPropertyChanged(nameof(Length_Tar)); } }
        public AlgoParam Tor_Tar { get { return tor_Tar; } set { if (tor_Tar == value) return; tor_Tar = value; this.OnPropertyChanged(nameof(Tor_Tar)); } }
        public AlgoParam Scale_Length { get { return scale_Length; } set { if (scale_Length == value) return; scale_Length = value; this.OnPropertyChanged(nameof(Scale_Length)); } }

        public AlgoParam Spec_Lx { get { return spec_Lx; } set { if (spec_Lx == value) return; spec_Lx = value; this.OnPropertyChanged(nameof(Spec_Lx)); } }
        public AlgoParam Spec_Ly { get { return spec_Ly; } set { if (spec_Ly == value) return; spec_Ly = value; this.OnPropertyChanged(nameof(Spec_Ly)); } }
        public AlgoParam Spec_Rx { get { return spec_Rx; } set { if (spec_Rx == value) return; spec_Rx = value; this.OnPropertyChanged(nameof(Spec_Rx)); } }
        public AlgoParam Spec_Ry { get { return spec_Ry; } set { if (spec_Ry == value) return; spec_Ry = value; this.OnPropertyChanged(nameof(Spec_Ry)); } }
        public AlgoParam Spec_T { get { return spec_T; } set { if (spec_T == value) return; spec_T = value; this.OnPropertyChanged(nameof(Spec_T)); } }

        public AlgoParam Scale_Lx { get { return scale_Lx; } set { if (scale_Lx == value) return; scale_Lx = value; this.OnPropertyChanged(nameof(Scale_Lx)); } }
        public AlgoParam Scale_Ly { get { return scale_Ly; } set { if (scale_Ly == value) return; scale_Ly = value; this.OnPropertyChanged(nameof(Scale_Ly)); } }
        public AlgoParam Scale_Rx { get { return scale_Rx; } set { if (scale_Rx == value) return; scale_Rx = value; this.OnPropertyChanged(nameof(Scale_Rx)); } }
        public AlgoParam Scale_Ry { get { return scale_Ry; } set { if (scale_Ry == value) return; scale_Ry = value; this.OnPropertyChanged(nameof(Scale_Ry)); } }
        public AlgoParam Scale_T { get { return scale_T; } set { if (scale_T == value) return; scale_T = value; this.OnPropertyChanged(nameof(Scale_T)); } }

        public AlgoParam Tor_Lx { get { return tor_Lx; } set { if (tor_Lx == value) return; tor_Lx = value; this.OnPropertyChanged(nameof(Tor_Lx)); } }
        public AlgoParam Tor_Ly { get { return tor_Ly; } set { if (tor_Ly == value) return; tor_Ly = value; this.OnPropertyChanged(nameof(Tor_Ly)); } }
        public AlgoParam Tor_Rx { get { return tor_Rx; } set { if (tor_Rx == value) return; tor_Rx = value; this.OnPropertyChanged(nameof(Tor_Rx)); } }
        public AlgoParam Tor_Ry { get { return tor_Ry; } set { if (tor_Ry == value) return; tor_Ry = value; this.OnPropertyChanged(nameof(Tor_Ry)); } }
        public AlgoParam Tor_T { get { return tor_T; } set { if (tor_T == value) return; tor_T = value; this.OnPropertyChanged(nameof(Tor_T)); } }

        public AlgoParam Spec_HoleX { get { return spec_HoleX; } set { if (spec_HoleX == value) return; spec_HoleX = value; this.OnPropertyChanged(nameof(Spec_HoleX)); } }
        public AlgoParam Tor_HoleX { get { return tor_HoleX; } set { if (tor_HoleX == value) return; tor_HoleX = value; this.OnPropertyChanged(nameof(Tor_HoleX)); } }
        public AlgoParam Spec_HoleY { get { return spec_HoleY; } set { if (spec_HoleY == value) return; spec_HoleY = value; this.OnPropertyChanged(nameof(Spec_HoleY)); } }
        public AlgoParam Tor_HoleY { get { return tor_HoleY; } set { if (tor_HoleY == value) return; tor_HoleY = value; this.OnPropertyChanged(nameof(Tor_HoleY)); } }

        public AlgoParam Spec_HoleD { get { return spec_HoleD; } set { if (spec_HoleD == value) return; spec_HoleD = value; this.OnPropertyChanged(nameof(Spec_HoleD)); } }
        public AlgoParam Tor_HoleD { get { return tor_HoleD; } set { if (tor_HoleD == value) return; tor_HoleD = value; this.OnPropertyChanged(nameof(Tor_HoleD)); } }

        public AlgoParam Scale_HoleX { get { return scale_HoleX; } set { if (scale_HoleX == value) return; scale_HoleX = value; this.OnPropertyChanged(nameof(Scale_HoleX)); } }
        public AlgoParam Scale_HoleY { get { return scale_HoleY; } set { if (scale_HoleY == value) return; scale_HoleY = value; this.OnPropertyChanged(nameof(Scale_HoleY)); } }
        public AlgoParam Scale_HoleD { get { return scale_HoleD; } set { if (scale_HoleD == value) return; scale_HoleD = value; this.OnPropertyChanged(nameof(Scale_HoleD)); } }

        public Algo_C_PanelAttachModelParamsIns()
           : base()
        {
            LimitX = new AlgoParam("LimitX", "mm", typeof(double), 0.0, "Revision Offset Limit X", (double)-5.0, (double)5.0);
            LimitY = new AlgoParam("LimitY", "mm", typeof(double), 0.0, "Revision Offset Limit Y", (double)-5.0, (double)5.0);
            LimitT = new AlgoParam("LimitT", "deg", typeof(double), 0.0, "Revision Offset Limit T", (double)-5.0, (double)5.0);

            Length_Obj = new AlgoParam("Length_Obj", "mm", typeof(double), 0.0, "Glass Length Spec(Mark To Mark)", (double)0, (double)100);
            Tor_Obj = new AlgoParam("Tor_Obj", "mm", typeof(double), 0.0, "Glass Length Tolerance", (double)0, (double)1);
            Length_Tar = new AlgoParam("Length_Tar", "mm", typeof(double), 0.0, "Tape Length Spec(Mark To Mark)", (double)0, (double)1000);
            Tor_Tar = new AlgoParam("Tor_Tar", "mm", typeof(double), 0.0, "Tape Length Tolerance", (double)0, (double)1);
            Scale_Length = new AlgoParam("Scale_Length", "mm", typeof(double), 0.0, "Length Scale", (double)0.5, (double)3);

            Spec_Lx = new AlgoParam("Spec_Lx", "mm", typeof(double), 0.0, "Attach Spec_Lx", (double)-100, (double)100.0);
            Spec_Ly = new AlgoParam("Spec_Ly", "mm", typeof(double), 0.0, "Attach Spec_Ly", (double)-100, (double)100.0);
            Spec_Rx = new AlgoParam("Spec_Rx", "mm", typeof(double), 0.0, "Attach Spec_Rx", (double)-100, (double)100.0);
            Spec_Ry = new AlgoParam("Spec_Ry", "mm", typeof(double), 0.0, "Attach Spec_Ry", (double)-100, (double)100.0);
            Spec_T = new AlgoParam("Spec_T", "mm", typeof(double), 0.0, "Attach Spec_T", (double)-100, (double)100.0);

            Scale_Lx = new AlgoParam("Scale_Lx", "mm", typeof(double), 1.0, "Attach Distance Scale_Lx", (double)0.5, (double)3);
            Scale_Ly = new AlgoParam("Scale_Ly", "mm", typeof(double), 1.0, "Attach Distance Scale_Ly", (double)0.5, (double)3);
            Scale_Rx = new AlgoParam("Scale_Rx", "mm", typeof(double), 1.0, "Attach Distance Scale_Rx", (double)0.5, (double)3);
            Scale_Ry = new AlgoParam("Scale_Ry", "mm", typeof(double), 1.0, "Attach Distance Scale_Ry", (double)0.5, (double)3);
            Scale_T = new AlgoParam("Scale_T", "mm", typeof(double), 1.0, "Attach Distance Scale_T", (double)0.5, (double)3);

            Tor_Lx = new AlgoParam("Tor_Lx", "mm", typeof(double), 0.0, "Attach Spec Tor_Lx", (double)0.0, (double)1);
            Tor_Ly = new AlgoParam("Tor_Ly", "mm", typeof(double), 0.0, "Attach Spec Tor_Ly", (double)0.0, (double)1);
            Tor_Rx = new AlgoParam("Tor_Rx", "mm", typeof(double), 0.0, "Attach Spec Tor_Rx", (double)0.0, (double)1);
            Tor_Ry = new AlgoParam("Tor_Ry", "mm", typeof(double), 0.0, "Attach Spec Tor_Ry", (double)0.0, (double)1);
            Tor_T = new AlgoParam("Tor_T", "mm", typeof(double), 0.0, "Attach Spec Tor_T", (double)0.0, (double)1);

            Spec_HoleX = new AlgoParam("Spec_HoleX", "mm", typeof(double), 0.0, "HoleToHole Spec X ", (double)-2, (double)2);
            Tor_HoleX = new AlgoParam("Tor_HoleX", "mm", typeof(double), 0.0, "HoleToHole Spec Tor X", (double)0.0, (double)1);
            Spec_HoleY = new AlgoParam("Spec_HoleY", "mm", typeof(double), 0.0, "HoleToHole Spec Y ", (double)-2, (double)2);
            Tor_HoleY = new AlgoParam("Tor_HoleY", "mm", typeof(double), 0.0, "HoleToHole Spec Tor Y", (double)0.0, (double)1);
            Spec_HoleD = new AlgoParam("Spec_HoleD", "mm", typeof(double), 0.0, "HoleToHole Spec D ", (double)0.0, (double)2);
            Tor_HoleD = new AlgoParam("Tor_HoleD", "mm", typeof(double), 0.0, "HoleToHole Spec Tor D", (double)0.0, (double)1);
            Scale_HoleX = new AlgoParam("Scale_HoleX", "mm", typeof(double), 1.0, "Attach Distance Hole X", (double)0.0, (double)1);
            Scale_HoleY = new AlgoParam("Scale_HoleY", "mm", typeof(double), 1.0, "Attach Distance Hole Y", (double)0.0, (double)1);
            Scale_HoleD = new AlgoParam("Scale_HoleD", "mm", typeof(double), 1.0, "Attach Distance Hole D", (double)0.0, (double)1);
        }
    }
}
