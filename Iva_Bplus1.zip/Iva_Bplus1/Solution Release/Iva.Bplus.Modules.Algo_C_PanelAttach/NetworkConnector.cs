﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public class NetworkConnector
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct NETRESOURCE
        {
            public uint dwScope;
            public uint dwType;
            public uint dwDisplayType;
            public uint dwUsage;
            public string lpLocalName;
            public string lpRemoteName;
            public string lpComment;
            public string lpProvider;
        }

        public NETRESOURCE NetResource = new NETRESOURCE();

        [DllImport("mpr.dll", CharSet = CharSet.Auto)]
        public static extern int WNetUseConnection(IntPtr hwndOwner,
            [MarshalAs(UnmanagedType.Struct)] ref NETRESOURCE lpNetResource,
            string lpPassword,
            string lpUserID,
            uint dwFlags,
            StringBuilder lpAccessName,
            ref int lpBufferSize,
            out uint lpResult);

        [DllImport("mpr.dll", EntryPoint = "WNetCancelConnection2", CharSet = CharSet.Auto)]
        public static extern int WNetCancelConnection2A(string lpName, int dwFlags, int fForce);

        public int TryConnectNetwork(string remotePath, string userID, string pwd)
        {
            int capacity = 1028;
            uint flags = 0;
            StringBuilder sb = new StringBuilder(capacity);
            uint lpResult;

            NetResource.dwType = 1;
            NetResource.lpLocalName = null;
            NetResource.lpRemoteName = remotePath;
            NetResource.lpProvider = null;
            int result = WNetUseConnection(IntPtr.Zero, ref NetResource, pwd, userID, flags, sb, ref capacity, out lpResult);

            return result;
        }

        public void DisconnectNetwork()
        {
            WNetCancelConnection2A(NetResource.lpRemoteName, 1, 0);
        }
    }
}
