﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]
    public class Algo_C_PanelAttachResult2P : AlgoResultBase
    {
        #region [fiedls]
        private string type;

        private bool result;

        private double rev1X;
        private double rev1Y;
        private double rev1T;

        //private double rev2X;
        //private double rev2Y;
        //private double rev2T;

        // twim 김윤동 추가
        private double plcOffset_X;
        private double plcOffset_Y;
        private double plcOffset_T;
        private double pnl_T;
        private double ref_T;
        private double cam_T;

        private double length;

        private double p1_X;
        private double p1_Y;
        private double p2_X;
        private double p2_Y;

        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;

        private double histL;
        private double histR;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public double Rev1X
        {
            get { return rev1X; }
            set { if (value == rev1X) return; rev1X = value; OnPropertyChanged(nameof(Rev1X)); }
        }
        public double Rev1Y
        {
            get { return rev1Y; }
            set { if (value == rev1Y) return; rev1Y = value; OnPropertyChanged(nameof(Rev1Y)); }
        }
        public double Rev1T
        {
            get { return rev1T; }
            set { if (value == rev1T) return; rev1T = value; OnPropertyChanged(nameof(Rev1T)); }
        }
        //public double Rev2X
        //{
        //    get { return rev2X; }
        //    set { if (value == rev2X) return; rev2X = value; OnPropertyChanged(nameof(Rev2X)); }
        //}
        //public double Rev2Y
        //{
        //    get { return rev2Y; }
        //    set { if (value == rev2Y) return; rev2Y = value; OnPropertyChanged(nameof(Rev2Y)); }
        //}
        //public double Rev2T
        //{
        //    get { return rev2T; }
        //    set { if (value == rev2T) return; rev2T = value; OnPropertyChanged(nameof(Rev2T)); }
        //}
        public double PLCOffset_X
        {
            get { return plcOffset_X; }
            set { if (value == plcOffset_X) return; plcOffset_X = value; OnPropertyChanged(nameof(PLCOffset_X)); }
        }
        public double PLCOffset_Y
        {
            get { return plcOffset_Y; }
            set { if (value == plcOffset_Y) return; plcOffset_Y = value; OnPropertyChanged(nameof(plcOffset_Y)); }
        }
        public double PLCOffset_T
        {
            get { return plcOffset_T; }
            set { if (value == plcOffset_T) return; plcOffset_T = value; OnPropertyChanged(nameof(plcOffset_T)); }
        }
        public double Length
        {
            get { return length; }
            set { if (value == length) return; length = value; OnPropertyChanged(nameof(Length)); }
        }
        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }
        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }
        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }
        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }
        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }
        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }
        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }
        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }
        public string Type
        {
            get { return type; }
            set { if (value == type) return; type = value; OnPropertyChanged(nameof(Type)); }
        }
        public double Pnl_T
        {
            get { return pnl_T; }
            set { if (value == pnl_T) return; pnl_T = value; OnPropertyChanged(nameof(Pnl_T)); }
        }
        public double Ref_T
        {
            get { return ref_T; }
            set { if (value == ref_T) return; ref_T = value; OnPropertyChanged(nameof(Ref_T)); }
        }
        public double Cam_T
        {
            get { return cam_T; }
            set { if (value == cam_T) return; cam_T = value; OnPropertyChanged(nameof(Cam_T)); }
        }

        public double HistL
        {
            get { return histL; }
            set { if (value == histL) return; histL = value; OnPropertyChanged(nameof(HistL)); }
        }
        public double HistR
        {
            get { return histR; }
            set { if (value == histR) return; histR = value; OnPropertyChanged(nameof(HistR)); }
        }
        #endregion


        public Algo_C_PanelAttachResult2P() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "offset1X: {3},\noffset1Y: {4},\noffset1T: {5},\n" +
                                  "offset2X: {6},\noffset2Y: {7},\noffset2T: {8},\n" +
                                  "Length: {9},\nResult: {10},\n" +
                                  "P1_X: {11},\nP1_Y: {12},\nP2_X: {13},\nP2_Y: {14},\n" +
                                  "C1_X: {15},\nC1_Y: {16},\nC2_X: {17},\nC2_Y: {18},\n" +
                                  "Type: {19},\nPnl_T: {20},\nRef_T: {21},\nCam_T: {22},\n"
                                  , typeof(Algo_C_PanelAttachResult2P).ToString(), curTime, curDate
                                  , rev1X, rev1Y, rev1T
                                  , 0.0, 0.0, 0.0
                                  , length, result
                                  , p1_X, p1_Y, p2_X, p2_Y
                                  , c1_X, c1_Y, c2_X, c2_Y
                                  , type, pnl_T, ref_T, cam_T
                                  , histL, histR);
        }

    }
}
