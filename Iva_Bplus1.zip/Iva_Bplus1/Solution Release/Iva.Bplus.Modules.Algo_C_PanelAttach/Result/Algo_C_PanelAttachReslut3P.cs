﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]
    public class Algo_C_PanelAttachResult3P : AlgoResultBase
    {
        #region [fiedls]
        private string type;

        private bool result;

        private double rev1X;
        private double rev1Y;
        private double rev1T;

        //private double rev2X;
        //private double rev2Y;
        //private double rev2T;

        // twim 김윤동 추가
        private double plcOffset1;
        private double plcOffset2;
        private double plcOffset3;
        private double plcOffset4;
        private double plcOffset5;
        private double plcOffset6;

        private double pnl_T;
        private double ref_T;
        private double cam_T;

        private double length;

        private double p1_X;
        private double p1_Y;
        private double p2_X;
        private double p2_Y;
        private double p3_X;
        private double p3_Y;

        private double c1_X;
        private double c1_Y;
        private double c2_X;
        private double c2_Y;
        private double c3_X;
        private double c3_Y;

        private double histL;
        private double histR;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }

        public double Rev1X
        {
            get { return rev1X; }
            set { if (value == rev1X) return; rev1X = value; OnPropertyChanged(nameof(Rev1X)); }
        }
        public double Rev1Y
        {
            get { return rev1Y; }
            set { if (value == rev1Y) return; rev1Y = value; OnPropertyChanged(nameof(Rev1Y)); }
        }
        public double Rev1T
        {
            get { return rev1T; }
            set { if (value == rev1T) return; rev1T = value; OnPropertyChanged(nameof(Rev1T)); }
        }
        //public double Rev2X
        //{
        //    get { return rev2X; }
        //    set { if (value == rev2X) return; rev2X = value; OnPropertyChanged(nameof(Rev2X)); }
        //}
        //public double Rev2Y
        //{
        //    get { return rev2Y; }
        //    set { if (value == rev2Y) return; rev2Y = value; OnPropertyChanged(nameof(Rev2Y)); }
        //}
        //public double Rev2T
        //{
        //    get { return rev2T; }
        //    set { if (value == rev2T) return; rev2T = value; OnPropertyChanged(nameof(Rev2T)); }
        //}


        public double PlcOffset1
        {
            get { return plcOffset1; }
            set { if (value == plcOffset1) return; plcOffset1 = value; OnPropertyChanged(nameof(PlcOffset1)); }
        }
        public double PLCOffset2
        {
            get { return plcOffset2; }
            set { if (value == plcOffset2) return; plcOffset2 = value; OnPropertyChanged(nameof(plcOffset2)); }
        }
        public double PLCOffset3
        {
            get { return plcOffset3; }
            set { if (value == plcOffset3) return; plcOffset3 = value; OnPropertyChanged(nameof(PLCOffset3)); }
        }
        public double PLCOffset4
        {
            get { return plcOffset4; }
            set { if (value == plcOffset4) return; plcOffset4 = value; OnPropertyChanged(nameof(PLCOffset4)); }
        }
        public double PLCOffset5
        {
            get { return plcOffset5; }
            set { if (value == plcOffset5) return; plcOffset5 = value; OnPropertyChanged(nameof(PLCOffset5)); }
        }
        public double PLCOffset6
        {
            get { return plcOffset6; }
            set { if (value == plcOffset6) return; plcOffset6 = value; OnPropertyChanged(nameof(PLCOffset6)); }
        }



        public double Length
        {
            get { return length; }
            set { if (value == length) return; length = value; OnPropertyChanged(nameof(Length)); }
        }
        public double P1_X
        {
            get { return p1_X; }
            set { if (value == p1_X) return; p1_X = value; OnPropertyChanged(nameof(P1_X)); }
        }
        public double P1_Y
        {
            get { return p1_Y; }
            set { if (value == p1_Y) return; p1_Y = value; OnPropertyChanged(nameof(P1_Y)); }
        }
        public double P2_X
        {
            get { return p2_X; }
            set { if (value == p2_X) return; p2_X = value; OnPropertyChanged(nameof(P2_X)); }
        }
        public double P2_Y
        {
            get { return p2_Y; }
            set { if (value == p2_Y) return; p2_Y = value; OnPropertyChanged(nameof(P2_Y)); }
        }
        public double P3_X
        {
            get { return p3_X; }
            set { if (value == p3_X) return; p3_X = value; OnPropertyChanged(nameof(P3_X)); }
        }
        public double P3_Y
        {
            get { return p3_Y; }
            set { if (value == p3_Y) return; p3_Y = value; OnPropertyChanged(nameof(P3_Y)); }
        }
        public double C1_X
        {
            get { return c1_X; }
            set { if (value == c1_X) return; c1_X = value; OnPropertyChanged(nameof(C1_X)); }
        }
        public double C1_Y
        {
            get { return c1_Y; }
            set { if (value == c1_Y) return; c1_Y = value; OnPropertyChanged(nameof(C1_Y)); }
        }
        public double C2_X
        {
            get { return c2_X; }
            set { if (value == c2_X) return; c2_X = value; OnPropertyChanged(nameof(C2_X)); }
        }
        public double C2_Y
        {
            get { return c2_Y; }
            set { if (value == c2_Y) return; c2_Y = value; OnPropertyChanged(nameof(C2_Y)); }
        }
        public double C3_X
        {
            get { return c3_X; }
            set { if (value == c3_X) return; c3_X = value; OnPropertyChanged(nameof(C3_X)); }
        }
        public double C3_Y
        {
            get { return c3_Y; }
            set { if (value == c3_Y) return; c3_Y = value; OnPropertyChanged(nameof(C3_Y)); }
        }
        public string Type
        {
            get { return type; }
            set { if (value == type) return; type = value; OnPropertyChanged(nameof(Type)); }
        }
        public double Pnl_T
        {
            get { return pnl_T; }
            set { if (value == pnl_T) return; pnl_T = value; OnPropertyChanged(nameof(Pnl_T)); }
        }
        public double Ref_T
        {
            get { return ref_T; }
            set { if (value == ref_T) return; ref_T = value; OnPropertyChanged(nameof(Ref_T)); }
        }
        public double Cam_T
        {
            get { return cam_T; }
            set { if (value == cam_T) return; cam_T = value; OnPropertyChanged(nameof(Cam_T)); }
        }

        public double HistL
        {
            get { return histL; }
            set { if (value == histL) return; histL = value; OnPropertyChanged(nameof(HistL)); }
        }
        public double HistR
        {
            get { return histR; }
            set { if (value == histR) return; histR = value; OnPropertyChanged(nameof(HistR)); }
        }
        #endregion


        public Algo_C_PanelAttachResult3P() : base() { }

        public override string ToString()
        {
            return string.Format("{0} :\n curDate: {1},\ncurTime: {2},\n " +
                                  "offset1X: {3},\noffset1Y: {4},\noffset1T: {5},\n" +
                                  "offset2X: {6},\noffset2Y: {7},\noffset2T: {8},\n" +
                                  "Length: {9},\nResult: {10},\n" +
                                  "P1_X: {11},\nP1_Y: {12},\nP2_X: {13},\nP2_Y: {14},\n" +
                                  "C1_X: {15},\nC1_Y: {16},\nC2_X: {17},\nC2_Y: {18},\n" +
                                  "Type: {19},\nPnl_T: {20},\nRef_T: {21},\nCam_T: {22},\n"
                                  , typeof(Algo_C_PanelAttachResult3P).ToString(), curTime, curDate
                                  , rev1X, rev1Y, rev1T
                                  , 0.0, 0.0, 0.0
                                  , length, result
                                  , p1_X, p1_Y, p2_X, p2_Y
                                  , c1_X, c1_Y, c2_X, c2_Y
                                  , type, pnl_T, ref_T, cam_T
                                  , histL, histR);
        }

    }
}
