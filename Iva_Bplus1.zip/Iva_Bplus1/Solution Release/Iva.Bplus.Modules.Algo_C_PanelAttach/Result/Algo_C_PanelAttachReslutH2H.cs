﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]
    public class Algo_C_PanelAttachResultH2H : AlgoResultBase
    {
        #region [fiedls]
        private string type;

        private string holeToHoleResult;

        private double hx;
        private double hy;
        private double hd;

        private double holeToHoleTop;
        private double holeToHoleBottom;
        private double holeToHoleLeft;
        private double holeToHoleRight;


        private double panelHoleMarkScore;
        private double windowHoleMarkScore;
        private double hxTor;
        private double hyTor;
        private double hdTor;


        #endregion

        #region [Properties]

        public string H_Result
        {
            get { return holeToHoleResult; }
            set { if (value == holeToHoleResult) return; holeToHoleResult = value; OnPropertyChanged(nameof(H_Result)); }
        }
        public double Hx
        {
            get { return hx; }
            set { if (value == hx) return; hx = value; OnPropertyChanged(nameof(Hx)); }
        }
        public double Hy
        {
            get { return hy; }
            set { if (value == hy) return; hy = value; OnPropertyChanged(nameof(Hy)); }
        }
        public double Hd
        {
            get { return hd; }
            set { if (value == hd) return; hd = value; OnPropertyChanged(nameof(Hd)); }
        }



        public double H_Top
        {
            get { return holeToHoleTop; }
            set { if (value == holeToHoleTop) return; holeToHoleTop = value; OnPropertyChanged(nameof(H_Top)); }
        }
        public double H_Right
        {
            get { return holeToHoleRight; }
            set { if (value == holeToHoleRight) return; holeToHoleRight = value; OnPropertyChanged(nameof(H_Right)); }
        }

        public double H_Bottom
        {
            get { return holeToHoleBottom; }
            set { if (value == holeToHoleBottom) return; holeToHoleBottom = value; OnPropertyChanged(nameof(H_Bottom)); }
        }
        public double H_Left
        {
            get { return holeToHoleLeft; }
            set { if (value == holeToHoleLeft) return; holeToHoleLeft = value; OnPropertyChanged(nameof(H_Left)); }
        }

        public double Panel_H_Score
        {
            get { return panelHoleMarkScore; }
            set { if (value == panelHoleMarkScore) return; panelHoleMarkScore = value; OnPropertyChanged(nameof(Panel_H_Score)); }
        }

        public double Window_H_Score
        {
            get { return windowHoleMarkScore; }
            set { if (value == windowHoleMarkScore) return; windowHoleMarkScore = value; OnPropertyChanged(nameof(Window_H_Score)); }
        }

        public double Hole_X_Tor
        {
            get { return hxTor; }
            set { if (value == hxTor) return; hxTor = value; OnPropertyChanged(nameof(Hole_X_Tor)); }
        }
        public double Hole_Y_Tor
        {
            get { return hyTor; }
            set { if (value == hyTor) return; hyTor = value; OnPropertyChanged(nameof(Hole_Y_Tor)); }
        }
        public double Hole_D_Tor
        {
            get { return hdTor; }
            set { if (value == hdTor) return; hdTor = value; OnPropertyChanged(nameof(Hole_D_Tor)); }
        }

        #endregion


        public Algo_C_PanelAttachResultH2H() : base() { }

    }
}
