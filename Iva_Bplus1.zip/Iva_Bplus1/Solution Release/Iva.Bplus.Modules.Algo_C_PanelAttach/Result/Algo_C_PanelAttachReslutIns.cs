﻿using Iva.Bplus.Abstract;
using Iva.Bplus.Enums;
using Iva.Bplus.Struct;
//using OpenCvSharp;
//using SvMip;
//using SvMip.Calibration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms.Integration;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    [SerializableAttribute]
    public class Algo_C_PanelAttachReslutIns : AlgoResultBase
    {
        #region [fiedls]
        private string tarId;
        private bool result;
        // 2021.04.06 hdy 컨펌 유무 로그 표시..
        private bool notConfirm;

        private double lx;
        private double ly;
        private double rx;
        private double ry;
        private double t;

        private double lx_apc;
        private double ly_apc;
        private double rx_apc;
        private double ry_apc;

        private double holeToHoleDistX1;
        private double holeToHoleDistY1;
        private double holeToHoleDistD;

        //private double holeToHoleDistX2;
        //private double holeToHoleDistY2;

        private double lxDiff;
        private double lyDiff;
        private double rxDiff;
        private double ryDiff;
        private double hxDiff;
        private double hyDiff;
        private double lxOffset;
        private double lyOffset;
        private double rxOffset;
        private double ryOffset;
        private double hxOffset;
        private double hyOffset;

        private double holeToHoleTop;
        private double holeToHoleBottom;
        private double holeToHoleLeft;
        private double holeToHoleRight;

        private double rev1X;
        private double rev1Y;
        private double rev1T;

        private double length_tar;
        private double length_obj;

        private double obj_Rt_X1;
        private double obj_Rt_Y1;
        private double tar_Rt_X1;
        private double tar_Rt_Y1;

        private double obj_Rt_X2;
        private double obj_Rt_Y2;
        private double tar_Rt_X2;
        private double tar_Rt_Y2;

        private double objHole_Rt_X;
        private double objHole_Rt_Y;
        private double tarHole_Rt_X;
        private double tarHole_Rt_Y;
        #endregion

        #region [Properties]
        public string Name
        {
            get { return name; }
            set { if (value == name) return; name = value; OnPropertyChanged(nameof(Name)); }
        }
        public string ID
        {
            get { return id; }
            set { if (value == id) return; id = value; OnPropertyChanged(nameof(ID)); }
        }
        public string T_ID
        {
            get { return tarId; }
            set { if (value == tarId) return; tarId = value; OnPropertyChanged(nameof(T_ID)); }
        }
        public string CurDate
        {
            get { return curDate; }
            set { if (value == curDate) return; curDate = value; OnPropertyChanged(nameof(CurDate)); }
        }
        public string CurTime
        {
            get { return curTime; }
            set { if (value == curTime) return; curTime = value; OnPropertyChanged(nameof(CurTime)); }
        }
        public bool Result
        {
            get { return result; }
            set { if (value == result) return; result = value; OnPropertyChanged(nameof(Result)); }
        }
        public bool NotConfirm
        {
            get { return notConfirm; }
            set { if (value == notConfirm) return; notConfirm = value; OnPropertyChanged(nameof(NotConfirm)); }
        }
        public double Lx
        {
            get { return lx; }
            set { if (value == lx) return; lx = value; OnPropertyChanged(nameof(Lx)); }
        }
        public double Ly
        {
            get { return ly; }
            set { if (value == ly) return; ly = value; OnPropertyChanged(nameof(Ly)); }
        }
        public double Rx
        {
            get { return rx; }
            set { if (value == rx) return; rx = value; OnPropertyChanged(nameof(Rx)); }
        }
        public double Ry
        {
            get { return ry; }
            set { if (value == ry) return; ry = value; OnPropertyChanged(nameof(Ry)); }
        }
        public double Lx_APC
        {
            get { return lx_apc; }
            set { if (value == lx_apc) return; lx_apc = value; OnPropertyChanged(nameof(Lx_APC)); }
        }
        public double Ly_APC
        {
            get { return ly_apc; }
            set { if (value == ly_apc) return; ly_apc = value; OnPropertyChanged(nameof(Ly_APC)); }
        }
        public double Rx_APC
        {
            get { return rx_apc; }
            set { if (value == rx_apc) return; rx_apc = value; OnPropertyChanged(nameof(Rx_APC)); }
        }
        public double Ry_APC
        {
            get { return ry_apc; }
            set { if (value == ry_apc) return; ry_apc = value; OnPropertyChanged(nameof(Ry_APC)); }
        }
        public double T
        {
            get { return t; }
            set { if (value == t) return; t = value; OnPropertyChanged(nameof(T)); }
        }
        public double Hx
        {
            get { return holeToHoleDistX1; }
            set { if (value == holeToHoleDistX1) return; holeToHoleDistX1 = value; OnPropertyChanged(nameof(Hx)); }
        }
        public double Hy
        {
            get { return holeToHoleDistY1; }
            set { if (value == holeToHoleDistY1) return; holeToHoleDistY1 = value; OnPropertyChanged(nameof(Hy)); }
        }

        public double Hd
        {
            get { return holeToHoleDistD; }
            set { if (value == holeToHoleDistD) return; holeToHoleDistD = value; OnPropertyChanged(nameof(Hd)); }
        }

        public double LxDiff
        {
            get { return lxDiff; }
            set { if (value == lxDiff) return; lxDiff = value; OnPropertyChanged(nameof(LxDiff)); }
        }
        public double LyDiff
        {
            get { return lyDiff; }
            set { if (value == lyDiff) return; lyDiff = value; OnPropertyChanged(nameof(LyDiff)); }
        }
        public double RxDiff
        {
            get { return rxDiff; }
            set { if (value == rxDiff) return; rxDiff = value; OnPropertyChanged(nameof(RxDiff)); }
        }
        public double RyDiff
        {
            get { return ryDiff; }
            set { if (value == ryDiff) return; ryDiff = value; OnPropertyChanged(nameof(RyDiff)); }
        }
        public double HxDiff
        {
            get { return hxDiff; }
            set { if (value == hxDiff) return; hxDiff = value; OnPropertyChanged(nameof(HxDiff)); }
        }
        public double HyDiff
        {
            get { return hyDiff; }
            set { if (value == hyDiff) return; hyDiff = value; OnPropertyChanged(nameof(HyDiff)); }
        }
        public double LxOffset
        {
            get { return lxOffset; }
            set { if (value == lxOffset) return; lxOffset = value; OnPropertyChanged(nameof(LxOffset)); }
        }
        public double LyOffset
        {
            get { return lyOffset; }
            set { if (value == lyOffset) return; lyOffset = value; OnPropertyChanged(nameof(LyOffset)); }
        }
        public double RxOffset
        {
            get { return rxOffset; }
            set { if (value == rxOffset) return; rxOffset = value; OnPropertyChanged(nameof(RxOffset)); }
        }
        public double RyOffset
        {
            get { return ryOffset; }
            set { if (value == ryOffset) return; ryOffset = value; OnPropertyChanged(nameof(RyOffset)); }
        }
        public double HxOffset
        {
            get { return hxOffset; }
            set { if (value == hxOffset) return; hxOffset = value; OnPropertyChanged(nameof(HxOffset)); }
        }
        public double HyOffset
        {
            get { return hyOffset; }
            set { if (value == hyOffset) return; hyOffset = value; OnPropertyChanged(nameof(HyOffset)); }
        }
        //public double Hole_X2
        //{
        //    get { return holeToHoleDistX2; }
        //    set { if (value == holeToHoleDistX2) return; holeToHoleDistX2 = value; OnPropertyChanged(nameof(Hole_X2)); }
        //}
        //public double Hole_Y2
        //{
        //    get { return holeToHoleDistY2; }
        //    set { if (value == holeToHoleDistY2) return; holeToHoleDistY2 = value; OnPropertyChanged(nameof(Hole_Y2)); }
        //}

        public double H_Top
        {
            get { return holeToHoleTop; }
            set { if (value == holeToHoleTop) return; holeToHoleTop = value; OnPropertyChanged(nameof(H_Top)); }
        }
        public double H_Left
        {
            get { return holeToHoleLeft; }
            set { if (value == holeToHoleLeft) return; holeToHoleLeft = value; OnPropertyChanged(nameof(H_Left)); }
        }
        public double H_Bottom
        {
            get { return holeToHoleBottom; }
            set { if (value == holeToHoleBottom) return; holeToHoleBottom = value; OnPropertyChanged(nameof(H_Bottom)); }
        }
        public double H_Right
        {
            get { return holeToHoleRight; }
            set { if (value == holeToHoleRight) return; holeToHoleRight = value; OnPropertyChanged(nameof(H_Right)); }
        }
        public double Rev1X
        {
            get { return rev1X; }
            set { if (value == rev1X) return; rev1X = value; OnPropertyChanged(nameof(Rev1X)); }
        }
        public double Rev1Y
        {
            get { return rev1Y; }
            set { if (value == rev1Y) return; rev1Y = value; OnPropertyChanged(nameof(Rev1Y)); }
        }
        public double Rev1T
        {
            get { return rev1T; }
            set { if (value == rev1T) return; rev1T = value; OnPropertyChanged(nameof(Rev1T)); }
        }

        public double Length_tar
        {
            get { return length_tar; }
            set { if (value == length_tar) return; length_tar = value; OnPropertyChanged(nameof(Length_tar)); }
        }
        public double Length_obj
        {
            get { return length_obj; }
            set { if (value == length_obj) return; length_obj = value; OnPropertyChanged(nameof(Length_obj)); }
        }
        public double Tar_Rt_X1
        {
            get { return tar_Rt_X1; }
            set { if (value == tar_Rt_X1) return; tar_Rt_X1 = value; OnPropertyChanged(nameof(Tar_Rt_X1)); }
        }
        public double Tar_Rt_Y1
        {
            get { return tar_Rt_Y1; }
            set { if (value == tar_Rt_Y1) return; tar_Rt_Y1 = value; OnPropertyChanged(nameof(Tar_Rt_Y1)); }
        }
        public double Tar_Rt_X2
        {
            get { return tar_Rt_X2; }
            set { if (value == tar_Rt_X2) return; tar_Rt_X2 = value; OnPropertyChanged(nameof(Tar_Rt_X2)); }
        }
        public double Tar_Rt_Y2
        {
            get { return tar_Rt_Y2; }
            set { if (value == tar_Rt_Y2) return; tar_Rt_Y2 = value; OnPropertyChanged(nameof(Tar_Rt_Y2)); }
        }
        public double TarHole_Rt_X
        {
            get { return tarHole_Rt_X; }
            set { if (value == tarHole_Rt_X) return; tarHole_Rt_X = value; OnPropertyChanged(nameof(TarHole_Rt_X)); }
        }
        public double TarHole_Rt_Y
        {
            get { return tarHole_Rt_Y; }
            set { if (value == tarHole_Rt_Y) return; tarHole_Rt_Y = value; OnPropertyChanged(nameof(TarHole_Rt_Y)); }
        }
        public double Obj_Rt_X1
        {
            get { return obj_Rt_X1; }
            set { if (value == obj_Rt_X1) return; obj_Rt_X1 = value; OnPropertyChanged(nameof(Obj_Rt_X1)); }
        }
        public double Obj_Rt_Y1
        {
            get { return obj_Rt_Y1; }
            set { if (value == obj_Rt_Y1) return; obj_Rt_Y1 = value; OnPropertyChanged(nameof(Obj_Rt_Y1)); }
        }
        public double Obj_Rt_X2
        {
            get { return obj_Rt_X2; }
            set { if (value == obj_Rt_X2) return; obj_Rt_X2 = value; OnPropertyChanged(nameof(Obj_Rt_X2)); }
        }
        public double Obj_Rt_Y2
        {
            get { return obj_Rt_Y2; }
            set { if (value == obj_Rt_Y2) return; obj_Rt_Y2 = value; OnPropertyChanged(nameof(Obj_Rt_Y2)); }
        }
        public double ObjHole_Rt_X
        {
            get { return objHole_Rt_X; }
            set { if (value == objHole_Rt_X) return; objHole_Rt_X = value; OnPropertyChanged(nameof(ObjHole_Rt_X)); }
        }
        public double ObjHole_Rt_Y
        {
            get { return objHole_Rt_Y; }
            set { if (value == objHole_Rt_Y) return; objHole_Rt_Y = value; OnPropertyChanged(nameof(ObjHole_Rt_Y)); }
        }
        #endregion


        public Algo_C_PanelAttachReslutIns() : base() { }

        public override string ToString()
        {
            return "";
        }

    }
}
