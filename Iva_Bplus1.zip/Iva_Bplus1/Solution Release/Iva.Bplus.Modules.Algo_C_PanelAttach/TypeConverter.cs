﻿using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.CogDisplay;
using Iva.Bplus.Modules.InspectionChart;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Modules.MultiGridViewDisplay;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public class CalDataListConverter : System.ComponentModel.TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Common.GetEachObjectName(typeof(CalDataObject)));
        }
    }
    public class DisplayListConverter : System.ComponentModel.TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Display.GetEachObjectName(typeof(CogDisplayObject)));
        }
    }
    public class BooleanToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool flag = (value is bool) ? (bool)value : false;
            bool collapsed = (parameter as string) == "collapsed";
            if (flag) return Visibility.Visible;
            return collapsed ? Visibility.Collapsed : Visibility.Hidden;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }

    /// <summary>
    /// 2020.12.17 hdy multi grid 설정용,,
    /// </summary>
    public class MultiGridViewListConverter : System.ComponentModel.TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Display.GetEachObjectName(typeof(MultiGridViewDisplayObject)));
        }
    }

    #region 2020.05.09
    public class ChartListConverter : System.ComponentModel.TypeConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(SystemObject_Display.GetEachObjectName(typeof(InspectionChartObject)));
        }
    }
    #endregion

    public class JudgeColorConverter : IValueConverter
    {

        // string -> boolean
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool flag = (bool)value;

            System.Windows.Media.Color red = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("Red");
            System.Windows.Media.Color blue = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("Blue");

            return flag == true ? new SolidColorBrush(blue) : new SolidColorBrush(red);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            //throw new NotImplementedException();
            return null;
        }
    }
}
