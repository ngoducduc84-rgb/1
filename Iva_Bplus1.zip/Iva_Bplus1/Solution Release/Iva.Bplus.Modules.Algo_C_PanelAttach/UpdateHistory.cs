﻿using Iva.Bplus.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iva.Bplus.Modules.Algo_C_PanelAttach
{
    public partial class Algo_C_PanelAttachShape
    {
        public override void UpdateHistory()
        {
            // ModuleBase Update History Loading
            base.UpdateHistory();

            /* Sample */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "First Release Version",                            // Update Title
                Version = new Version(1, 0, 0, 0),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>          // Update Item List
                {
                   "1. None",
                   "2. None",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2019, 4, 4, 17, 0, 0),                  // year, month, day, hour, minute, second
            });

            /* Additional Update History */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "Source Property 삭제",                             // Update Title
                Version = new Version(1, 0, 0, 1),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "Source Property 삭제",
                },
                Author = "Jun Youngho",                                     // Author Name
                Email = "youngho.jun@samsung.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 1, 10, 10, 0, 0),                  // year, month, day, hour, minute, second
            });

            /* Additional Update History */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "",                             					// Update Title
                Version = new Version(1, 0, 0, 2),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "Inspection.cs의 InspectionHole()에서 window hole, TapeHoleLineV, TapeHoleLineH 관련 코드 삭제 " +
                   "--> 윈도우 홀의 경우, 검사기준이 아님에도 셋팅을 해야하기 때문에 잡체인지 시간을 잡아 먹음. 현재 Line들은 사용 안함.",

                   "AlignCalc3P.cs의 Inspection PANEL Hole에서 검사 기준을 XY에서 D로 변경함.",
                },
                Author = "Sungjun Park",                                     // Author Name
                Email = "xyunit@gmail.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 9, 10, 12, 0, 0),                  // year, month, day, hour, minute, second
            });

            /* Additional Update History */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "",                             // Update Title
                Version = new Version(1, 0, 0, 3),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "AlignCalc3P.cs에 2점 <-> 3점 얼라인 변환되는 if문 추가",
                   "Hole Inspection에서 Simple-tool이 아닌 Multi-tool 2개를 사용 할수 있게 프로그램 수정",
                },
                Author = "Sungjun Park",                                     // Author Name
                Email = "xyunit@gmail.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 9, 18, 12, 0, 0),                  // year, month, day, hour, minute, second
            });

            /* Additional Update History */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "",                             // Update Title
                Version = new Version(1, 0, 0, 4),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "Panel H2H을 따로 처리 할 수 있게 분리 함",
                   "Inspection에서 각도 틀어짐에 대한 검사 스펙 추가",
                },
                Author = "Sungjun Park",                                     // Author Name
                Email = "xyunit@gmail.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 10, 09, 12, 0, 0),                  // year, month, day, hour, minute, second
            });

            /* Additional Update History */
            ReleaseNote.AddUpdateHistory(new Struct.ReleaseNote
            {
                IsCommon = false,                                           // ModuleBase(true) Each Shape(true)
                Title = "",                             // Update Title
                Version = new Version(1, 0, 0, 5),                          // Update Version(major, minor, build, revision)
                Descriptions = new ObservableCollection<string>             // Update Item List
                {
                   "Panel H2H에서 검사 기준을 타원 안에 들어오면 OK로 수정",
                   "Panel H2H에서 검사 결과 부호 추가",
                   "Inspection에서 검사 기준(X&Y -> D) 수정",
                },
                Author = "Sungjun Park",                                     // Author Name
                Email = "xyunit@gmail.com",                          // Author E-Mail Address
                Time = new DateTime(2020, 10, 09, 12, 0, 0),                  // year, month, day, hour, minute, second
            });
        }
    }
}
