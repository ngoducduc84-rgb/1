﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo_Lami_Bended_4sides
{
    public partial class Algo_Lami_Bended_4sidesObject : AlgoObjectBase
    {
        
        private bool Align4PCenterCalc(bool isUseUVRW = false)
        {
            //4Point 받아서 중심 Center Align을 해봅시다. 
            #region Initialize
            model = SystemModel.GetCurModel();
            bResult = true;
            ObjPointData = new IPointResult[4];
            ObjCalData = new CalDataObject[4];
            ObjFindCnt = new IClear[4];
            ObjRobotData = new XY[4];
            ObjCoordData = new XY[4];
            ObjFixData = new XY[4];
            Revision = new XYT();
            Revision_FDC = new XYT();
            rst = "";
            Main_CHNo = 0;
            #endregion

            #region InputDataWtire
            //PLC Data Input
            AssignPLCData_GLami();    
            AlignOffset = GLamiPLCIO.OffsetXYT;
            CurPos = GLamiPLCIO.CurPosXXYY;
            
            //Model Param 
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Align4PCenterModelParams;

            double[] LengthSpec = new double[4];
            bool[] LcheckRst = new bool[4] { true, true, true, true };
            LengthSpec[0] = (double)mParams.ObjLength12.Value;
            LengthSpec[1] = (double)mParams.ObjLength34.Value;
            LengthSpec[2] = (double)mParams.ObjLength23.Value;
            LengthSpec[3] = (double)mParams.ObjLength14.Value;
            double LengthTor = (double)mParams.LengthTolerance.Value;
                        
            double[] LimitSpec = new double[3];
            bool[] LimitRst = new bool[3] { true, true, true };
            LimitSpec[0] = (double)mParams.Limit_X.Value;
            LimitSpec[1] = (double)mParams.Limit_Y.Value;
            LimitSpec[2] = (double)mParams.Limit_T.Value;
            double[] LimitTor = new double[3];
            LimitTor[0] = (double)mParams.Limit_X_Tolerance.Value;
            LimitTor[1] = (double)mParams.Limit_Y_Tolerance.Value;
            LimitTor[2] = (double)mParams.Limit_T_Tolerance.Value;

            for (int i = 0; i < 4; i++)
            {
                if (!InputValues.ContainsKey("Obj_P" + (i + 1).ToString()))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                ObjPointData[i] = InputValues["Obj_P" + (i + 1).ToString()] as IPointResult;
                ObjFindCnt[i] = InputValues["Obj_P" + (i + 1).ToString()] as IClear;

                ObjCalData[i] = ObjPointData[i].CalData as CalDataObject;

                if (ObjCalData[i] == null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    return false;
                }

                ObjRobotData[i] = ObjCalData[i].GetV2R(model, new XY(ObjPointData[i].OutputXYT.X, ObjPointData[i].OutputXYT.Y));
                ObjFixData[i] = ObjCalData[i].GetRotateCenter(model);
                ObjCoordData[i] = ObjFixData[i] + ObjRobotData[i];
            }

            int Findcnt = CheckFindPoint(ObjFindCnt); 
            #endregion

            #region Calc Align & Lcheck 

            XYT ObjCenter = new XYT();
            XYT TarCenter = new XYT();
            XYT ZeroPos = new XYT(0,0,0);

            double Length12 = 0;
            double Length34 = 0;
            double Length14 = 0;
            double Length23 = 0;
            //다 찾은 경우는 정상 진행
            if (Findcnt==4)
            {
                ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[1].X + ObjCoordData[2].X + ObjCoordData[3].X) * 0.25;
                ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y + ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.25;
                TarCenter.X = (ObjFixData[0].X + ObjFixData[1].X + ObjFixData[2].X + ObjFixData[3].X) * 0.25;
                TarCenter.Y = (ObjFixData[0].Y + ObjFixData[1].Y + ObjFixData[2].Y + ObjFixData[3].Y) * 0.25;
                
                ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1])) +
                                NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3]))) * 0.5;
                TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[0], ObjFixData[1])) +
                                NormalizeTheta(GetTheta(ObjFixData[2], ObjFixData[3]))) * 0.5;
                //L-check
                Length12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                Length34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                Length14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                Length23 = GetLength(ObjCoordData[1], ObjCoordData[2]);
                LcheckRst[0] = ConfirmSpecRange(Length12, LengthSpec[0], LengthTor);
                LcheckRst[1] = ConfirmSpecRange(Length34, LengthSpec[1], LengthTor);
                LcheckRst[2] = ConfirmSpecRange(Length14, LengthSpec[2], LengthTor);
                LcheckRst[3] = ConfirmSpecRange(Length23, LengthSpec[3], LengthTor);
            }
            //3개라도 찾은 경우 3PMode 상태
            else if(align3PMode == Align3PMode.Use && Findcnt == 3)
            {
                if(ObjFindCnt[0].FindCnt<1)
                {
                    ObjCenter.X = (ObjCoordData[1].X + ObjCoordData[2].X) * 0.5;
                    ObjCenter.Y = (ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.5;
                    TarCenter.X = (ObjFixData[1].X + ObjFixData[2].X) * 0.5;
                    TarCenter.Y = (ObjFixData[2].Y + ObjFixData[3].Y) * 0.5;
                    ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3])));
                    TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[2], ObjFixData[3])));
                    //L-check 
                    Length34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                    Length23 = GetLength(ObjCoordData[1], ObjCoordData[2]);
                    LcheckRst[1] = ConfirmSpecRange(Length34, LengthSpec[1], LengthTor);
                    LcheckRst[3] = ConfirmSpecRange(Length23, LengthSpec[3], LengthTor);
                }
                else if(ObjFindCnt[1].FindCnt < 1)
                {
                    ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[3].X) * 0.5;
                    ObjCenter.Y = (ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.5;
                    TarCenter.X = (ObjFixData[0].X + ObjFixData[3].X) * 0.5;
                    TarCenter.Y = (ObjFixData[2].Y + ObjFixData[3].Y) * 0.5;
                    ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3])));
                    TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[2], ObjFixData[3])));
                    //L-check
                    Length34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                    Length14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                    LcheckRst[1] = ConfirmSpecRange(Length34, LengthSpec[1], LengthTor);
                    LcheckRst[2] = ConfirmSpecRange(Length14, LengthSpec[2], LengthTor);
                }
                else if(ObjFindCnt[2].FindCnt < 1)
                {
                    ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[3].X) * 0.5;
                    ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y) * 0.5;
                    TarCenter.X = (ObjFixData[0].X + ObjFixData[3].X) * 0.5;
                    TarCenter.Y = (ObjFixData[0].Y + ObjFixData[1].Y) * 0.5;
                    ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1])));
                    TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[0], ObjFixData[1])));
                    //L-check
                    Length12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                    Length14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                    LcheckRst[0] = ConfirmSpecRange(Length12, LengthSpec[0], LengthTor);
                    LcheckRst[2] = ConfirmSpecRange(Length14, LengthSpec[2], LengthTor);
                }
                else if (ObjFindCnt[3].FindCnt < 1)
                {
                    ObjCenter.X = (ObjCoordData[1].X + ObjCoordData[2].X) * 0.5;
                    ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y) * 0.5;
                    TarCenter.X = (ObjFixData[1].X + ObjFixData[2].X) * 0.5;
                    TarCenter.Y = (ObjFixData[0].Y + ObjFixData[1].Y) * 0.5;
                    ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1])));
                    TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[0], ObjFixData[1])));
                    //L-check
                    Length12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                    Length23 = GetLength(ObjCoordData[1], ObjCoordData[2]);
                    LcheckRst[0] = ConfirmSpecRange(Length12, LengthSpec[0], LengthTor);
                    LcheckRst[3] = ConfirmSpecRange(Length23, LengthSpec[3], LengthTor);
                }
                rst = "3Point Align ";
            }
            //3개도 못찾은 경우
            else
            {
                bResult = false;
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                rst = "Mark Find NG";
                return false;
            }

            XYT Tar_Pos = ApplyTargetOffset(TarCenter, AlignOffset);

            double RadT = NormalizeTheta(Tar_Pos.T - ObjCenter.T);
            double DriftX = Math.Cos(RadT) * ObjCenter.X - Math.Sin(RadT) * ObjCenter.Y;
            double DriftY = Math.Sin(RadT) * ObjCenter.X + Math.Cos(RadT) * ObjCenter.Y;
			
			Revision.X = Tar_Pos.X - DriftX;
            Revision.Y = Tar_Pos.Y - DriftY;
            Revision.T = RadianToDegree(RadT);

            XYT Tar_Pos_FDC = ApplyTargetOffset(TarCenter, ZeroPos);

            double RadT_FDC = NormalizeTheta(Tar_Pos_FDC.T - ObjCenter.T);
            double DriftX_FDC = Math.Cos(RadT_FDC) * ObjCenter.X - Math.Sin(RadT_FDC) * ObjCenter.Y;
            double DriftY_FDC = Math.Sin(RadT_FDC) * ObjCenter.X + Math.Cos(RadT_FDC) * ObjCenter.Y;

            Revision_FDC.X = Tar_Pos_FDC.X - DriftX_FDC;
            Revision_FDC.Y = Tar_Pos_FDC.Y - DriftY_FDC;
            Revision_FDC.T = RadianToDegree(RadT_FDC);
            #endregion

            #region convert UVRW
            if (isUseUVRW)
            {
                UVRWDataObject.UVRWOption = AxisOption.UVRW;
                UVRW convertXY = UVRWDataObject.GetXYPos4Axis(Revision_FDC.X, Revision.Y) as UVRW;
                UVRW convertT = UVRWDataObject.GetThetaPos4Axis(Revision.T) as UVRW;
                Revision_UVRW = convertXY + convertT;
            }
            else Revision_UVRW = new UVRW();
            #endregion

            #region Check Length 판정 및 메뉴얼 마크로 설정
            if (bResult && (!LcheckRst[0] || !LcheckRst[1] || !LcheckRst[2] || !LcheckRst[3]))
            {
                //if (!LcheckRst[0]) { ObjMatchingData[0].Tool.ProcMode = ProcessMode.Manual; ObjMatchingData[1].Tool.ProcMode = ProcessMode.Manual; }
                //if (!LcheckRst[1]) { ObjMatchingData[2].Tool.ProcMode = ProcessMode.Manual; ObjMatchingData[3].Tool.ProcMode = ProcessMode.Manual; }
                //if (!LcheckRst[2]) { ObjMatchingData[0].Tool.ProcMode = ProcessMode.Manual; ObjMatchingData[3].Tool.ProcMode = ProcessMode.Manual; }
                //if (!LcheckRst[3]) { ObjMatchingData[1].Tool.ProcMode = ProcessMode.Manual; ObjMatchingData[2].Tool.ProcMode = ProcessMode.Manual; }

                bResult = false;
                errorCode = AlgoActionBase.Err_Length_Check;
                rst = "L Check NG";
            }
            #endregion

            #region Limit 판정 및 메뉴얼 마크로 설정
            LimitRst[0] = ConfirmSpecRange(Revision.X, LimitSpec[0], LimitTor[0]);
            LimitRst[1] = ConfirmSpecRange(Revision.Y, LimitSpec[1], LimitTor[1]);
            LimitRst[2] = ConfirmSpecRange(Revision.T, LimitSpec[2], LimitTor[2]);

            if (bResult && (!LimitRst[0] || !LimitRst[1] || !LimitRst[2]))
            {
                bResult = false;
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                rst = "Limit NG";
            }

            if (bResult)
            {
                rst = "OK";
            }
            #endregion

            #region ResultData Update & log Write
            AlgoRst = new Align4PCenterReslut
            {
                Name = name,
                ID = sourceID,
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Result = rst,
                RevX = Revision.X,
                RevY = Revision.Y,
                RevT = Revision.T,
                RevX1 = Revision_UVRW.V,
                RevX2 = Revision_UVRW.W,
                RevY1 = Revision_UVRW.U,
                RevY2 = Revision_UVRW.R,
                OffsetX = AlignOffset.X,
                OffsetY = AlignOffset.Y,
                OffsetT = AlignOffset.T,
                ObjectLength12 = Length12,
                ObjectLength34 = Length34,
                ObjectLength13 = Length14,
                ObjectLength24 = Length23,
            };
            if (GridViewObject != null)
                GridViewObject.SetResult(AlgoRst);
            #endregion

            #region FDC Write
            List<IOStruct> FDC_IOs = new List<IOStruct>();
            string UnitName = null;

            if (processType == Algo_Lami_Bended_4sides.ProcessType.U2_CH_LOWER_PREFORM)
            {
                UnitName = "PRE_FORM";
            }
            else if(processType == Algo_Lami_Bended_4sides.ProcessType.U1_PANEL_PRE_ALIGN)
            {
                UnitName = "PANEL_PRE";
            }
            else if(processType == Algo_Lami_Bended_4sides.ProcessType.U2_WIN_PRE_ALIGN)
            {
                UnitName = "WIN_PRE";
            }

            #region Line, Mark 구별 O
            for (int i = 0; i < 4; i++)
            {
                if (ObjPointData[i] is MatchingRstData)
                {
                    VisionValues[UnitName+"_ALIGN_MARK_POS_" + (i + 1) + "_X"].NextValue = (double)ObjPointData[i].OutputXYT.X;                       FDC_IOs.Add(VisionValues[UnitName+"_ALIGN_MARK_POS_" + (i + 1) + "_X"]);
                    VisionValues[UnitName+"_ALIGN_MARK_POS_" + (i + 1) + "_Y"].NextValue = (double)ObjPointData[i].OutputXYT.Y;                       FDC_IOs.Add(VisionValues[UnitName+"_ALIGN_MARK_POS_" + (i + 1) + "_Y"]);
                    VisionValues[UnitName+"_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"].NextValue = (double)ObjPointData[i].Score;                       FDC_IOs.Add(VisionValues[UnitName+"_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"]);

                    VisionValues[UnitName+"_ANGLE " + (i + 1)].NextValue = (double)90;                                                                FDC_IOs.Add(VisionValues[UnitName+"_ANGLE " + (i + 1)]);
                }
                else if (ObjPointData[i] is LineCrossRstData)
                {
                    VisionValues[UnitName+"_ALIGN_MARK_POS_" + (i + 1) + "_X"].NextValue = (double)ObjPointData[i].OutputXYT.X;                       FDC_IOs.Add(VisionValues[UnitName+"_ALIGN_MARK_POS_" + (i + 1) + "_X"]);
                    VisionValues[UnitName+"_ALIGN_MARK_POS_" + (i + 1) + "_Y"].NextValue = (double)ObjPointData[i].OutputXYT.Y;                       FDC_IOs.Add(VisionValues[UnitName+"_ALIGN_MARK_POS_" + (i + 1) + "_Y"]);
                    VisionValues[UnitName+"_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"].NextValue = (double)99;                                          FDC_IOs.Add(VisionValues[UnitName+"_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"]);

                    VisionValues[UnitName+"_ANGLE " + (i + 1)].NextValue = (double)ObjPointData[i].Angle;                                             FDC_IOs.Add(VisionValues[UnitName+"_ANGLE " + (i + 1)]);
                }
            }

            if(Findcnt == 4)
            {
                VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"].NextValue = (double)Length12;                                                           FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"]);
                VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"].NextValue = (double)Length34;                                                           FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"]);

                VisionValues[UnitName+"_HEIGHT 1"].NextValue = (double)Length14;                                                                      FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 1"]);
                VisionValues[UnitName+"_HEIGHT 2"].NextValue = (double)Length23;                                                                      FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 2"]);
            }
            else if (Findcnt == 3 && ObjFindCnt[0].FindCnt < 1)
            {
                VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"].NextValue = (double)mParams.ObjLength12.Value;                                          FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"]);
                VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"].NextValue = (double)Length34;                                                           FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"]);

                VisionValues[UnitName+"_HEIGHT 1"].NextValue = (double)mParams.ObjLength14.Value;                                                     FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 1"]);
                VisionValues[UnitName+"_HEIGHT 2"].NextValue = (double)Length23;                                                                      FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 2"]);
            }
            else if (Findcnt == 3 && ObjFindCnt[1].FindCnt < 1)
            {
                VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"].NextValue = (double)mParams.ObjLength12.Value;                                          FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"]);
                VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"].NextValue = (double)Length34;                                                           FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"]);

                VisionValues[UnitName+"_HEIGHT 1"].NextValue = (double)Length14;                                                                      FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 1"]);
                VisionValues[UnitName+"_HEIGHT 2"].NextValue = (double)mParams.ObjLength23.Value;                                                     FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 2"]);
            }
            else if (Findcnt == 3 && ObjFindCnt[2].FindCnt < 1)
            {
                VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"].NextValue = (double)Length12;                                                           FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"]);
                VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"].NextValue = (double)mParams.ObjLength34.Value;                                          FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"]);

                VisionValues[UnitName+"_HEIGHT 1"].NextValue = (double)Length14;                                                                      FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 1"]);
                VisionValues[UnitName+"_HEIGHT 2"].NextValue = (double)mParams.ObjLength23.Value;                                                     FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 2"]);
            }
            else if (Findcnt == 3 && ObjFindCnt[3].FindCnt < 1)
            {
                VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"].NextValue = (double)Length12;                                                           FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P1_T0_P2"]);
                VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"].NextValue = (double)mParams.ObjLength34.Value;                                          FDC_IOs.Add(VisionValues[UnitName+"_MARK_PITCH_P3_T0_P4"]);

                VisionValues[UnitName+"_HEIGHT 1"].NextValue = (double)mParams.ObjLength14.Value;                                                     FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 1"]);
                VisionValues[UnitName+"_HEIGHT 2"].NextValue = (double)Length23;                                                                      FDC_IOs.Add(VisionValues[UnitName+"_HEIGHT 2"]);
            }
            
            VisionValues["ALIGN_POS_TARGET_Y"].NextValue = (double)Revision.Y;                                                                        FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_Y"]);
            VisionValues["ALIGN_POS_TARGET_X"].NextValue = (double)Revision.X;                                                                        FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_X"]);
            VisionValues["ALIGN_POS_TARGET_THETA"].NextValue = (double)Revision.T;                                                                    FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_THETA"]);
                                                                                                                                     
            VisionValues["VISION_ALIGN_RESULT_REV_X"].NextValue = (double)Revision_FDC.X;                                                             FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_X"]);
            VisionValues["VISION_ALIGN_RESULT_REV_Y"].NextValue = (double)Revision_FDC.Y;                                                             FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_Y"]);
            VisionValues["VISION_ALIGN_RESULT_REV_THETA"].NextValue = (double)Revision_FDC.T;                                                         FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_THETA"]);
                                                                                                                                     
            VisionValues["ALIGN_RESULT_X1"].NextValue = (double)Revision_UVRW.V;                                                                      FDC_IOs.Add(VisionValues["ALIGN_RESULT_X1"]);
            VisionValues["ALIGN_RESULT_X2"].NextValue = (double)Revision_UVRW.W;                                                                      FDC_IOs.Add(VisionValues["ALIGN_RESULT_X2"]);
            VisionValues["ALIGN_RESULT_Y1"].NextValue = (double)Revision_UVRW.U;                                                                      FDC_IOs.Add(VisionValues["ALIGN_RESULT_Y1"]);
            VisionValues["ALIGN_RESULT_Y2"].NextValue = (double)Revision_UVRW.R;                                                                      FDC_IOs.Add(VisionValues["ALIGN_RESULT_Y2"]);
            #endregion

            #region Line, Mark 구별 X
            /*
            VisionValues["LOWER_ALIGN_MARK_POS_1_X"].NextValue = (double)ObjMatchingData[0].OutputXYT.X;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_1_X"]);
            VisionValues["LOWER_ALIGN_MARK_POS_1_Y"].NextValue = (double)ObjMatchingData[0].OutputXYT.Y;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_1_Y"]);
            VisionValues["LOWER_ALIGN_MARK_1_MATCH_RATIO"].NextValue = (double)ObjMatchingData[0].Score;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_1_MATCH_RATIO"]);
            VisionValues["LOWER_ALIGN_MARK_POS_2_X"].NextValue = (double)ObjMatchingData[1].OutputXYT.X;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_2_X"]);
            VisionValues["LOWER_ALIGN_MARK_POS_2_Y"].NextValue = (double)ObjMatchingData[1].OutputXYT.Y;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_2_Y"]);
            VisionValues["LOWER_ALIGN_MARK_2_MATCH_RATIO"].NextValue = (double)ObjMatchingData[1].Score;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_2_MATCH_RATIO"]);
            VisionValues["LOWER_MARK_PITCH_P1_T0_P2"].NextValue = (double)Length12;                                 FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P1_T0_P2"]);
            VisionValues["LOWER_ALIGN_MARK_POS_3_X"].NextValue = (double)ObjMatchingData[2].OutputXYT.X;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_3_X"]);
            VisionValues["LOWER_ALIGN_MARK_POS_3_Y"].NextValue = (double)ObjMatchingData[2].OutputXYT.Y;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_3_Y"]);
            VisionValues["LOWER_ALIGN_MARK_3_MATCH_RATIO"].NextValue = (double)ObjMatchingData[2].Score;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_3_MATCH_RATIO"]);
            VisionValues["LOWER_ALIGN_MARK_POS_4_X"].NextValue = (double)ObjMatchingData[3].OutputXYT.X;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_4_X"]);
            VisionValues["LOWER_ALIGN_MARK_POS_4_Y"].NextValue = (double)ObjMatchingData[3].OutputXYT.Y;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_4_Y"]);
            VisionValues["LOWER_ALIGN_MARK_4_MATCH_RATIO"].NextValue = (double)ObjMatchingData[3].Score;            FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_4_MATCH_RATIO"]);
            VisionValues["LOWER_MARK_PITCH_P3_T0_P4"].NextValue = (double)Length34;                                 FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P3_T0_P4"]);
            VisionValues["ALIGN_POS_TARGET_X"].NextValue = (double)Revision.X;                                      FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_X"]);
            VisionValues["ALIGN_POS_TARGET_Y"].NextValue = (double)Revision.Y;                                      FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_Y"]);
            VisionValues["ALIGN_POS_TARGET_THETA"].NextValue = (double)Revision.T;                                  FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_THETA"]);
            VisionValues["VISION_ALIGN_RESULT_REV_X"].NextValue = (double)Revision_FDC.X;                           FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_X"]);
            VisionValues["VISION_ALIGN_RESULT_REV_Y"].NextValue = (double)Revision_FDC.Y;                           FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_Y"]);
            VisionValues["VISION_ALIGN_RESULT_REV_THETA"].NextValue = (double)Revision_FDC.T;                       FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_THETA"]);
            VisionValues["ALIGN_RESULT_X1"].NextValue = (double)Revision_UVRW.V;                                    FDC_IOs.Add(VisionValues["ALIGN_RESULT_X1"]);
            VisionValues["ALIGN_RESULT_X2"].NextValue = (double)Revision_UVRW.W;                                    FDC_IOs.Add(VisionValues["ALIGN_RESULT_X2"]);
            VisionValues["ALIGN_RESULT_Y1"].NextValue = (double)Revision_UVRW.U;                                    FDC_IOs.Add(VisionValues["ALIGN_RESULT_Y1"]);
            VisionValues["ALIGN_RESULT_Y2"].NextValue = (double)Revision_UVRW.R;                                    FDC_IOs.Add(VisionValues["ALIGN_RESULT_Y2"]);
            VisionValues["LOW HEIGHT 1"].NextValue = (double)Length14;                                              FDC_IOs.Add(VisionValues["LOW HEIGHT 1"]);
            VisionValues["LOW HEIGHT 2"].NextValue = (double)Length23;                                              FDC_IOs.Add(VisionValues["LOW HEIGHT 2"]);
            VisionValues["LOWER ANGLE 1"].NextValue = (double)0.0;                                                  FDC_IOs.Add(VisionValues["LOWER ANGLE 1"]);
            VisionValues["LOWER ANGLE 2"].NextValue = (double)0.0;                                                  FDC_IOs.Add(VisionValues["LOWER ANGLE 2"]);
            VisionValues["LOWER ANGLE 3"].NextValue = (double)0.0;                                                  FDC_IOs.Add(VisionValues["LOWER ANGLE 3"]);
            VisionValues["LOWER ANGLE 4"].NextValue = (double)0.0;                                                  FDC_IOs.Add(VisionValues["LOWER ANGLE 4"]);
            */
            #endregion

            CommodObject.SetVisionValues(FDC_IOs);
            #endregion

            WriteVisionIO(AlgoRst, isUseUVRW);
            //AppendMessage(Name, "Caluration Complete");

            return true;
        }
    }
}

