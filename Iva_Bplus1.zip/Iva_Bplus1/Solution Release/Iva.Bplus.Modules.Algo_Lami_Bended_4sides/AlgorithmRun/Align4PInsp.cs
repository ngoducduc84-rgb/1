﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;
using OpenCvSharp;
using Cognex.VisionPro;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo_Lami_Bended_4sides
{
    public partial class Algo_Lami_Bended_4sidesObject
    {
        //Inspection과 Aling을 동시에 사용하는 경우 추가
        private bool Align4PInspCalc(bool AlignFunc = false)
        {
            #region Initialize
            model = SystemModel.GetCurModel();
            bResult = true;
           
            ObjPointData = new IPointResult[4];
            TarPointData = new IPointResult[4];
            ImageResult = new IImageResult[4];

            ObjRobotData = new XY[4];
            TarRobotData = new XY[4];

            ObjCoordData = new XY[4];
            TarCoordData = new XY[4];

            ObjFixData = new XY[4];
            TarFixData = new XY[4];
            ObjFindCnt = new IClear[4];
            ObjCalData = new CalDataObject[4];

            XY[] CamCenterPixel = new XY[4];
            inspectionRstData = new XY[4] { new XY(0, 0), new XY(0, 0), new XY(0, 0), new XY(0, 0) };
            
            Revision = new XYT();
            Revision_FDC = new XYT();
            bool[] LcheckRst = new bool[4] { true, true, true, true };
            double[] LengthSpec = new double[4];
            double LengthTor = 0;
            XYT LimitXYT = new XYT(0,0,0);
            #endregion

            #region InputDataWtire
            //PLC Data Read 
            AssignPLCData_GLami();
            AlignOffset = GLamiPLCIO.OffsetXYT;
            CurPos = GLamiPLCIO.CurPosXXYY;
            Main_CHNo = GLamiPLCIO.Main_CHNo;

            //Model Param Read
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            InspModelParams = modelParams as Align4PInspModelParams;

            double ResolutionX = (double)InspModelParams.ResolutionX.Value;
            double ResolutionY = (double)InspModelParams.ResolutionY.Value; 

            double DistSpecX1 = (double)InspModelParams.DistSpecX1.Value;
            double DistSpecX2 = (double)InspModelParams.DistSpecX2.Value;
            double DistSpecX3 = (double)InspModelParams.DistSpecX3.Value;
            double DistSpecX4 = (double)InspModelParams.DistSpecX4.Value;
            double DistSpecY1 = (double)InspModelParams.DistSpecY1.Value;
            double DistSpecY2 = (double)InspModelParams.DistSpecY2.Value;
            double DistSpecY3 = (double)InspModelParams.DistSpecY3.Value;
            double DistSpecY4 = (double)InspModelParams.DistSpecY4.Value;
            double ToleraneX = (double)InspModelParams.ToleranceX.Value;
            double ToleraneY = (double)InspModelParams.ToleranceY.Value;
            double scaleX1 = (double)InspModelParams.ScaleX1.Value;
            double scaleX2 = (double)InspModelParams.ScaleX2.Value;
            double scaleX3 = (double)InspModelParams.ScaleX3.Value;
            double scaleX4 = (double)InspModelParams.ScaleX4.Value;
            double scaleY1 = (double)InspModelParams.ScaleY1.Value;
            double scaleY2 = (double)InspModelParams.ScaleY2.Value;
            double scaleY3 = (double)InspModelParams.ScaleY3.Value;
            double scaleY4 = (double)InspModelParams.ScaleY4.Value;
            double CamToCamX = (double)InspModelParams.CamToCamLengthX.Value;
            double CamToCamY = (double)InspModelParams.CamToCamLengthY.Value;

            LengthSpec[0] = (double)InspModelParams.ObjLength12.Value;
            LengthSpec[1] = (double)InspModelParams.ObjLength34.Value;
            LengthSpec[2] = (double)InspModelParams.ObjLength23.Value;
            LengthSpec[3] = (double)InspModelParams.ObjLength14.Value;
            LimitXYT.X = (double)InspModelParams.Limit_X.Value;
            LimitXYT.Y = (double)InspModelParams.Limit_Y.Value;
            LimitXYT.T = (double)InspModelParams.Limit_T.Value;
            LengthTor = (double)InspModelParams.LengthTolerance.Value;

            bool bCaldataUse = true;
            //conntect Check
            for (int i = 0; i < 4; i++)
            {
                if (!InputValues.ContainsKey("Obj_P" + (i + 1).ToString()))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
              
                ObjPointData[i] = InputValues["Obj_P" + (i + 1).ToString()] as IPointResult;
                ObjFindCnt[i] = InputValues["Obj_P" + (i + 1).ToString()] as IClear;

                if (!InputValues.ContainsKey("Tar_P" + (i + 1).ToString()))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }

                TarPointData[i] = InputValues["Tar_P" + (i + 1).ToString()] as IPointResult;
                

                ObjCalData[i] = ObjPointData[i].CalData as CalDataObject;
               
                if (ObjCalData[i] == null)
                {
                    bCaldataUse = false;
                }

                //이미지 중심 좌표 
                ImageResult[i] = InputValues["Tar_P" + (i + 1).ToString()] as IImageResult;
                CamCenterPixel[i] = new XY (ImageResult[i].CenterPoint.X, ImageResult[i].CenterPoint.Y);
            }
            #endregion

            #region Calc Distance Point to Point 
            //좌표계 만들기,,, 로딩 Theta 떄문이다
            //카메라 중심은 패널 마크 간의 거리 활용...
            //      1-------4
            //      |       |
            //      |       |
            //      |       |
            //      2-------3


            //회전 중심을 못찾는 경우 카메라간의 거리 설계치로.... 
            if (bCaldataUse)
            {
                for (int i = 0; i < 4; i++)
                {
                    TarFixData[i] = ObjFixData[i] = ObjCalData[i].GetRotateCenter(model);
                }
            }
            //회전 중심값이 없는 경우는 카메라값 받아 와서 씁시다.
            if (ObjFixData[0].X == 0 && ObjFixData[0].Y == 0)
            {
                TarFixData[0] = ObjFixData[0] = new XY(0, 0);
                TarFixData[1] = ObjFixData[1] = new XY(0, CamToCamY);
                TarFixData[2] = ObjFixData[2] = new XY(CamToCamX, CamToCamY);
                TarFixData[3] = ObjFixData[3] = new XY(CamToCamX, 0);
            }
            //Calibration 못하는 경우 해상도로 계산....
            if (bCaldataUse)
            {
                for (int i = 0; i < 4; i++)
                {
                    TarCoordData[i] = new XY((TarPointData[i].OutputXYT.X - CamCenterPixel[i].X) * ResolutionX + TarFixData[i].X
                                       , (CamCenterPixel[i].Y - TarPointData[i].OutputXYT.Y) * ResolutionX + TarFixData[i].Y);
                    ObjCoordData[i] = new XY((ObjPointData[i].OutputXYT.X - CamCenterPixel[i].X) * ResolutionX + TarFixData[i].X
                                            , (CamCenterPixel[i].Y - ObjPointData[i].OutputXYT.Y) * ResolutionX + TarFixData[i].Y);
                }
            }
            else
            {
                for (int i = 0; i < 4; i++)
                {
                    ObjRobotData[i] = ObjCalData[i].GetV2R(model, new XY(ObjPointData[i].OutputXYT.X, ObjPointData[i].OutputXYT.Y));
                    TarRobotData[i] = ObjCalData[i].GetV2R(model, new XY(TarPointData[i].OutputXYT.X, TarPointData[i].OutputXYT.Y));
                    ObjCoordData[i] = ObjRobotData[i] + ObjFixData[i];
                    TarCoordData[i] = TarRobotData[i] + TarFixData[i];
                }
            }
           
            int Findcnt = CheckFindPoint(ObjFindCnt);
            #region Align Calc

            XYT ObjCenter = new XYT();
            XYT TarCenter = new XYT();
            XYT ZeroPos = new XYT(0, 0, 0);
            double Length12 = 0;
            double Length34 = 0;
            double Length14 = 0;
            double Length23 = 0;
            
            //4Point Center Align 
            if (AlignFunc)
            {
                if (Findcnt == 4)
                {
                    ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[1].X + ObjCoordData[2].X + ObjCoordData[3].X) * 0.25;
                    ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y + ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.25;
                    TarCenter.X = (ObjFixData[0].X + ObjFixData[1].X + ObjFixData[2].X + ObjFixData[3].X) * 0.25;
                    TarCenter.Y = (ObjFixData[0].Y + ObjFixData[1].Y + ObjFixData[2].Y + ObjFixData[3].Y) * 0.25;

                    ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1])) +
                                    NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3]))) * 0.5;
                    TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[0], ObjFixData[1])) +
                                    NormalizeTheta(GetTheta(ObjFixData[2], ObjFixData[3]))) * 0.5;
                    //L-check
                    Length12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                    Length34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                    Length14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                    Length23 = GetLength(ObjCoordData[1], ObjCoordData[2]);

                    LcheckRst[0] = ConfirmSpecRange(Length12, LengthSpec[0], LengthTor);
                    LcheckRst[1] = ConfirmSpecRange(Length34, LengthSpec[1], LengthTor);
                    LcheckRst[2] = ConfirmSpecRange(Length14, LengthSpec[2], LengthTor);
                    LcheckRst[3] = ConfirmSpecRange(Length23, LengthSpec[3], LengthTor);
                }

                //3개라도 찾은 경우 3PMode 상태
                else if (align3PMode == Align3PMode.Use && Findcnt == 3)
                {
                    if (ObjFindCnt[0].FindCnt < 1)
                    {
                        ObjCenter.X = (ObjCoordData[1].X + ObjCoordData[2].X) * 0.5;
                        ObjCenter.Y = (ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.5;
                        TarCenter.X = (ObjFixData[1].X + ObjFixData[2].X) * 0.5;
                        TarCenter.Y = (ObjFixData[2].Y + ObjFixData[3].Y) * 0.5;
                        ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3])));
                        TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[2], ObjFixData[3])));
                        //L-check 
                        Length34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                        Length23 = GetLength(ObjCoordData[1], ObjCoordData[2]);
                        LcheckRst[1] = ConfirmSpecRange(Length34, LengthSpec[1], LengthTor);
                        LcheckRst[3] = ConfirmSpecRange(Length23, LengthSpec[3], LengthTor);
                    }
                    else if (ObjFindCnt[1].FindCnt < 1)
                    {
                        ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[3].X) * 0.5;
                        ObjCenter.Y = (ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.5;
                        TarCenter.X = (ObjFixData[0].X + ObjFixData[3].X) * 0.5;
                        TarCenter.Y = (ObjFixData[2].Y + ObjFixData[3].Y) * 0.5;
                        ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3])));
                        TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[2], ObjFixData[3])));
                        //L-check
                        Length34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                        Length14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                        LcheckRst[1] = ConfirmSpecRange(Length34, LengthSpec[1], LengthTor);
                        LcheckRst[2] = ConfirmSpecRange(Length14, LengthSpec[2], LengthTor);
                    }
                    else if (ObjFindCnt[2].FindCnt < 1)
                    {
                        ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[3].X) * 0.5;
                        ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y) * 0.5;
                        TarCenter.X = (ObjFixData[0].X + ObjFixData[3].X) * 0.5;
                        TarCenter.Y = (ObjFixData[0].Y + ObjFixData[1].Y) * 0.5;
                        ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1])));
                        TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[0], ObjFixData[1])));
                        //L-check
                        Length12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                        Length14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                        LcheckRst[0] = ConfirmSpecRange(Length12, LengthSpec[0], LengthTor);
                        LcheckRst[2] = ConfirmSpecRange(Length14, LengthSpec[2], LengthTor);
                    }
                    else if (ObjFindCnt[3].FindCnt < 1)
                    {
                        ObjCenter.X = (ObjCoordData[1].X + ObjCoordData[2].X) * 0.5;
                        ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y) * 0.5;
                        TarCenter.X = (ObjFixData[1].X + ObjFixData[2].X) * 0.5;
                        TarCenter.Y = (ObjFixData[0].Y + ObjFixData[1].Y) * 0.5;
                        ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1])));
                        TarCenter.T = (NormalizeTheta(GetTheta(ObjFixData[0], ObjFixData[1])));
                        //L-check
                        Length12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                        Length23 = GetLength(ObjCoordData[1], ObjCoordData[2]);
                        LcheckRst[0] = ConfirmSpecRange(Length12, LengthSpec[0], LengthTor);
                        LcheckRst[3] = ConfirmSpecRange(Length23, LengthSpec[3], LengthTor);
                    }
                    rst = "3Point Align ";
                }
                //3개도 못찾은 경우
                else
                {
                    bResult = false;
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    rst = "Mark Find NG";
                    return false;
                }
                XYT Tar_Pos = ApplyTargetOffset(TarCenter, AlignOffset);

                double RadT = NormalizeTheta(Tar_Pos.T - ObjCenter.T);
                double DriftX = Math.Cos(RadT) * ObjCenter.X - Math.Sin(RadT) * ObjCenter.Y;
                double DriftY = Math.Sin(RadT) * ObjCenter.X + Math.Cos(RadT) * ObjCenter.Y;

                Revision.X = Tar_Pos.X - DriftX;
                Revision.Y = Tar_Pos.Y - DriftY;
                Revision.T = RadianToDegree(RadT);

                XYT Tar_Pos_FDC = ApplyTargetOffset(TarCenter, ZeroPos);

                double RadT_FDC = NormalizeTheta(Tar_Pos_FDC.T - ObjCenter.T);
                double DriftX_FDC = Math.Cos(RadT_FDC) * ObjCenter.X - Math.Sin(RadT_FDC) * ObjCenter.Y;
                double DriftY_FDC = Math.Sin(RadT_FDC) * ObjCenter.X + Math.Cos(RadT_FDC) * ObjCenter.Y;

                Revision_FDC.X = Tar_Pos_FDC.X - DriftX_FDC;
                Revision_FDC.Y = Tar_Pos_FDC.Y - DriftY_FDC;
                Revision_FDC.T = RadianToDegree(RadT_FDC);

            }
            #endregion

            double TarThLine12 = GetTheta(TarCoordData[0], TarCoordData[1]);
            double TarThLine23 = GetTheta(TarCoordData[1], TarCoordData[2]);
            double TarThLine34 = GetTheta(TarCoordData[2], TarCoordData[3]);
            double TarThLine14 = GetTheta(TarCoordData[0], TarCoordData[3]);

            inspectionRstData[0].X = GetDistanceLinePoint(TarThLine12, new XY(TarCoordData[0].X, TarCoordData[0].Y), new XY(ObjCoordData[0].X, ObjCoordData[0].Y)) * scaleX1;
            inspectionRstData[0].Y = GetDistanceLinePoint(TarThLine14, new XY(TarCoordData[0].X, TarCoordData[0].Y), new XY(ObjCoordData[0].X, ObjCoordData[0].Y)) * scaleY1;
            inspectionRstData[1].X = GetDistanceLinePoint(TarThLine12, new XY(TarCoordData[1].X, TarCoordData[1].Y), new XY(ObjCoordData[1].X, ObjCoordData[1].Y)) * scaleX2;
            inspectionRstData[1].Y = GetDistanceLinePoint(TarThLine23, new XY(TarCoordData[1].X, TarCoordData[1].Y), new XY(ObjCoordData[1].X, ObjCoordData[1].Y)) * scaleY2;
            inspectionRstData[2].X = GetDistanceLinePoint(TarThLine34, new XY(TarCoordData[2].X, TarCoordData[2].Y), new XY(ObjCoordData[2].X, ObjCoordData[2].Y)) * scaleX3;
            inspectionRstData[2].Y = GetDistanceLinePoint(TarThLine23, new XY(TarCoordData[2].X, TarCoordData[2].Y), new XY(ObjCoordData[2].X, ObjCoordData[2].Y)) * scaleY3;
            inspectionRstData[3].X = GetDistanceLinePoint(TarThLine34, new XY(TarCoordData[3].X, TarCoordData[3].Y), new XY(ObjCoordData[3].X, ObjCoordData[3].Y)) * scaleX4;
            inspectionRstData[3].Y = GetDistanceLinePoint(TarThLine14, new XY(TarCoordData[3].X, TarCoordData[3].Y), new XY(ObjCoordData[3].X, ObjCoordData[3].Y)) * scaleY4;

            #endregion

            #region Check data
            bool[] MeasureSpecX = new bool[4] { false, false, false, false };
            bool[] MeasureSpecY = new bool[4] { false, false, false, false };
            
            MeasureSpecX[0] = MeasureSpecTolerance(inspectionRstData[0].X, DistSpecX1, ToleraneX);
            MeasureSpecX[1] = MeasureSpecTolerance(inspectionRstData[1].X, DistSpecX2, ToleraneX);
            MeasureSpecX[2] = MeasureSpecTolerance(inspectionRstData[2].X, DistSpecX3, ToleraneX);
            MeasureSpecX[3] = MeasureSpecTolerance(inspectionRstData[3].X, DistSpecX4, ToleraneX);
            MeasureSpecY[0] = MeasureSpecTolerance(inspectionRstData[0].Y, DistSpecY1, ToleraneY);
            MeasureSpecY[1] = MeasureSpecTolerance(inspectionRstData[1].Y, DistSpecY2, ToleraneY);
            MeasureSpecY[2] = MeasureSpecTolerance(inspectionRstData[2].Y, DistSpecY3, ToleraneY);
            MeasureSpecY[3] = MeasureSpecTolerance(inspectionRstData[3].Y, DistSpecY4, ToleraneY);

            //3개는 Spec In인데 1개가 Spec Out 경우는 다시 역산해서 넣어 줘 보자... 다른 경우는 그냥 NG로 
            if(!MeasureSpecX[0] && MeasureSpecX[1] && MeasureSpecX[2] && MeasureSpecX[3])
            {
                inspectionRstData[0].X = DistSpecX1 + DistSpecX4 - inspectionRstData[3].X;
            }
            else if (MeasureSpecX[0] && !MeasureSpecX[1] && MeasureSpecX[2] && MeasureSpecX[3])
            {
                inspectionRstData[1].X = DistSpecX2 + DistSpecX3 - inspectionRstData[2].X;
            }
            else if (MeasureSpecX[0] && MeasureSpecX[1] && !MeasureSpecX[2] && MeasureSpecX[3])
            {
                inspectionRstData[2].X = DistSpecX2 + DistSpecX3 - inspectionRstData[1].X;
            }
            else if (MeasureSpecX[0] && MeasureSpecX[1] && MeasureSpecX[2] && !MeasureSpecX[3])
            {
                inspectionRstData[3].X = DistSpecX1 + DistSpecX4 - inspectionRstData[0].X;
            }

            if (!MeasureSpecY[0] && MeasureSpecY[1] && MeasureSpecY[2] && MeasureSpecY[3])
            {
                inspectionRstData[0].Y = DistSpecY1 + DistSpecY2 - inspectionRstData[1].Y;
            }
            else if (MeasureSpecY[0] && !MeasureSpecY[1] && MeasureSpecY[2] && MeasureSpecY[3])
            {
                inspectionRstData[1].Y = DistSpecY1 + DistSpecY2 - inspectionRstData[0].Y;
            }
            else if (MeasureSpecY[0] && MeasureSpecY[1] && !MeasureSpecY[2] && MeasureSpecY[3])
            {
                inspectionRstData[2].Y = DistSpecY3 + DistSpecY4 - inspectionRstData[3].Y;
            }
            else if (MeasureSpecY[0] && MeasureSpecY[1] && MeasureSpecY[2] && !MeasureSpecY[3])
            {
                inspectionRstData[3].Y = DistSpecY3 + DistSpecY4 - inspectionRstData[2].Y;
            }
            #endregion

            #region Confirm Result
            if (ToleraneX != 0 && ToleraneY != 0)
            {
                if(MeasureSpecTolerance(inspectionRstData[0].X, DistSpecX1, ToleraneX) ||MeasureSpecTolerance(inspectionRstData[1].X, DistSpecX2, ToleraneX) ||
                   MeasureSpecTolerance(inspectionRstData[2].X, DistSpecX3, ToleraneX) ||MeasureSpecTolerance(inspectionRstData[3].X, DistSpecX4, ToleraneX) ||
                   MeasureSpecTolerance(inspectionRstData[0].Y, DistSpecY2, ToleraneY) ||MeasureSpecTolerance(inspectionRstData[1].Y, DistSpecY3, ToleraneY) ||
                   MeasureSpecTolerance(inspectionRstData[2].Y, DistSpecY4, ToleraneY) ||MeasureSpecTolerance(inspectionRstData[3].Y, DistSpecY1, ToleraneY))
                {
                    bResult = false;
                    rst = "Inspection Spec Over";
                }
            }
            if (bResult)
            {
                rst = "OK";
            }
            #endregion

            #region ResultData Update & log Write
            AlgoRst = new Align4PInspReslut
            {
                Name = name,
                ID = sourceID,
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Result = rst,
                DistanceX1 = Math.Round(inspectionRstData[0].X, 3, MidpointRounding.ToEven),
                DistanceY1 = Math.Round(inspectionRstData[1].X, 3, MidpointRounding.ToEven),
                DistanceX2 = Math.Round(inspectionRstData[2].X, 3, MidpointRounding.ToEven),
                DistanceY2 = Math.Round(inspectionRstData[3].X, 3, MidpointRounding.ToEven),
                DistanceX3 = Math.Round(inspectionRstData[0].Y, 3, MidpointRounding.ToEven),
                DistanceY3 = Math.Round(inspectionRstData[1].Y, 3, MidpointRounding.ToEven),
                DistanceX4 = Math.Round(inspectionRstData[2].Y, 3, MidpointRounding.ToEven),
                DistanceY4 = Math.Round(inspectionRstData[3].Y, 3, MidpointRounding.ToEven),
            };
            if(GridViewObject!=null)
            GridViewObject.SetResult(AlgoRst);
            #endregion


            #region FDC Write
            List<IOStruct> FDC_IOs = new List<IOStruct>();

            if(processType == Algo_Lami_Bended_4sides.ProcessType.U1_PANEL_PRE_INSP)
            {
                VisionValues["PANEL_PRE_MARK_POINT_P1_X"].NextValue = (double)ObjPointData[0].OutputXYT.X;                                               FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_P1_X"]);
                VisionValues["PANEL_PRE_MARK_POINT_P1_Y"].NextValue = (double)ObjPointData[0].OutputXYT.Y;                                               FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_P1_Y"]);
                VisionValues["PANEL_PRE_MARK_POINT_SCORE_P1"].NextValue = (double)ObjPointData[0].Score;                                                 FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_SCORE_P1"]);
                VisionValues["PANEL_PRE_MARK_POINT_P2_X"].NextValue = (double)ObjPointData[1].OutputXYT.X;                                               FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_P2_X"]);
                VisionValues["PANEL_PRE_MARK_POINT_P2_Y"].NextValue = (double)ObjPointData[1].OutputXYT.Y;                                               FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_P2_Y"]);
                VisionValues["PANEL_PRE_MARK_POINT_SCORE_P2"].NextValue = (double)ObjPointData[1].Score;                                                 FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_SCORE_P2"]);
                VisionValues["PANEL_PRE_MARK_PITCH_P1_TO_P2"].NextValue = (double)0;                                                                     FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_PITCH_P1_TO_P2"]);
                VisionValues["PANEL_PRE_MARK_POINT_P3_X"].NextValue = (double)ObjPointData[2].OutputXYT.X;                                               FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_P3_X"]);
                VisionValues["PANEL_PRE_MARK_POINT_P3_Y"].NextValue = (double)ObjPointData[2].OutputXYT.Y;                                               FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_P3_Y"]);
                VisionValues["PANEL_PRE_MARK_POINT_SCORE_P3"].NextValue = (double)ObjPointData[2].Score;                                                 FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_SCORE_P3"]);
                VisionValues["PANEL_PRE_MARK_POINT_P4_X"].NextValue = (double)ObjPointData[3].OutputXYT.X;                                               FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_P4_X"]);
                VisionValues["PANEL_PRE_MARK_POINT_P4_Y"].NextValue = (double)ObjPointData[3].OutputXYT.Y;                                               FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_P4_Y"]);
                VisionValues["PANEL_PRE_MARK_POINT_SCORE_P4"].NextValue = (double)ObjPointData[3].Score;                                                 FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_POINT_SCORE_P4"]);
                VisionValues["PANEL_PRE_MARK_PITCH_P3_TO_P4"].NextValue = (double)0;                                                                     FDC_IOs.Add(VisionValues["PANEL_PRE_MARK_PITCH_P3_TO_P4"]);
                VisionValues["PANEL_PRE_TARGET_POS_X"].NextValue = (double)0;                                                                            FDC_IOs.Add(VisionValues["PANEL_PRE_TARGET_POS_X"]);
                VisionValues["PANEL_PRE_TARGET_POS_Y"].NextValue = (double)0;                                                                            FDC_IOs.Add(VisionValues["PANEL_PRE_TARGET_POS_Y"]);
                VisionValues["PANEL_PRE_TARGET_POS_T"].NextValue = (double)0;                                                                            FDC_IOs.Add(VisionValues["PANEL_PRE_TARGET_POS_T"]);
                VisionValues["PANEL_PRE_VISION_RESULT_REV_X"].NextValue = (double)0;                                                                     FDC_IOs.Add(VisionValues["PANEL_PRE_VISION_RESULT_REV_X"]);
                VisionValues["PANEL_PRE_VISION_RESULT_REV_Y"].NextValue = (double)0;                                                                     FDC_IOs.Add(VisionValues["PANEL_PRE_VISION_RESULT_REV_Y"]);
                VisionValues["PANEL_PRE_VISION_RESULT_REV_T"].NextValue = (double)0;                                                                     FDC_IOs.Add(VisionValues["PANEL_PRE_VISION_RESULT_REV_T"]);
                VisionValues["HEIGHT 1"].NextValue = (double)0;                                                                                          FDC_IOs.Add(VisionValues["HEIGHT 1"]);
                VisionValues["HEIGHT 2"].NextValue = (double)0;                                                                                          FDC_IOs.Add(VisionValues["HEIGHT 2"]);
                VisionValues["ANGLE 1"].NextValue = (double)0;                                                                                           FDC_IOs.Add(VisionValues["ANGLE 1"]);
                VisionValues["ANGLE 2"].NextValue = (double)0;                                                                                           FDC_IOs.Add(VisionValues["ANGLE 2"]);
                VisionValues["ANGLE 3"].NextValue = (double)0;                                                                                           FDC_IOs.Add(VisionValues["ANGLE 3"]);
                VisionValues["ANGLE 4"].NextValue = (double)0;                                                                                           FDC_IOs.Add(VisionValues["ANGLE 4"]);
                                                                                                                                                         
                VisionValues["SUB_INSPECTION_MARK_POINT_P1_X"].NextValue = (double)TarPointData[0].OutputXYT.X;                                          FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_P1_X"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_P1_Y"].NextValue = (double)TarPointData[0].OutputXYT.Y;                                          FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_P1_Y"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_SCORE_P1"].NextValue = (double)TarPointData[0].Score;                                            FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_SCORE_P1"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_P2_X"].NextValue = (double)TarPointData[1].OutputXYT.X;                                          FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_P2_X"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_P2_Y"].NextValue = (double)TarPointData[1].OutputXYT.Y;                                          FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_P2_Y"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_SCORE_P2"].NextValue = (double)TarPointData[1].Score;                                            FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_SCORE_P2"]);
                VisionValues["SUB_INSPECTION_MARK_PITCH_P1_TO_P2"].NextValue = (double)0;                                                                FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_PITCH_P1_TO_P2"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_P3_X"].NextValue = (double)TarPointData[2].OutputXYT.X;                                          FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_P3_X"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_P3_Y"].NextValue = (double)TarPointData[2].OutputXYT.Y;                                          FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_P3_Y"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_SCORE_P3"].NextValue = (double)TarPointData[2].Score;                                            FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_SCORE_P3"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_P4_X"].NextValue = (double)TarPointData[3].OutputXYT.X;                                          FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_P4_X"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_P4_Y"].NextValue = (double)TarPointData[3].OutputXYT.Y;                                          FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_P4_Y"]);
                VisionValues["SUB_INSPECTION_MARK_POINT_SCORE_P4"].NextValue = (double)TarPointData[3].Score;                                            FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_POINT_SCORE_P4"]);
                VisionValues["SUB_INSPECTION_MARK_PITCH_P3_TO_P4"].NextValue = (double)0;                                                                FDC_IOs.Add(VisionValues["SUB_INSPECTION_MARK_PITCH_P3_TO_P4"]);
                VisionValues["SUB_INSPECTION_VISION_RESULT_REV_X"].NextValue = (double)0;                                                                FDC_IOs.Add(VisionValues["SUB_INSPECTION_VISION_RESULT_REV_X"]);
                VisionValues["SUB_INSPECTION_VISION_RESULT_REV_Y"].NextValue = (double)0;                                                                FDC_IOs.Add(VisionValues["SUB_INSPECTION_VISION_RESULT_REV_Y"]);
                VisionValues["SUB_INSPECTION_VISION_RESULT_REV_T"].NextValue = (double)0;                                                                FDC_IOs.Add(VisionValues["SUB_INSPECTION_VISION_RESULT_REV_T"]);
                                                                                                                                                         
                VisionValues["SUB_INSP_DIST_FRONT_X1"].NextValue = (double)Math.Round(inspectionRstData[0].X, 3, MidpointRounding.ToEven);               FDC_IOs.Add(VisionValues["SUB_INSP_DIST_FRONT_X1"]);
                VisionValues["SUB_INSP_DIST_FRONT_Y1"].NextValue = (double)Math.Round(inspectionRstData[1].X, 3, MidpointRounding.ToEven);               FDC_IOs.Add(VisionValues["SUB_INSP_DIST_FRONT_Y1"]);
                VisionValues["SUB_INSP_DIST_FRONT_X2"].NextValue = (double)Math.Round(inspectionRstData[2].X, 3, MidpointRounding.ToEven);               FDC_IOs.Add(VisionValues["SUB_INSP_DIST_FRONT_X2"]);
                VisionValues["SUB_INSP_DIST_FRONT_Y2"].NextValue = (double)Math.Round(inspectionRstData[3].X, 3, MidpointRounding.ToEven);               FDC_IOs.Add(VisionValues["SUB_INSP_DIST_FRONT_Y2"]);
                VisionValues["SUB_INSP_DIST_REAR_X1"].NextValue = (double)Math.Round(inspectionRstData[0].Y, 3, MidpointRounding.ToEven);                FDC_IOs.Add(VisionValues["SUB_INSP_DIST_REAR_X1"]);
                VisionValues["SUB_INSP_DIST_REAR_Y1"].NextValue = (double)Math.Round(inspectionRstData[1].Y, 3, MidpointRounding.ToEven);                FDC_IOs.Add(VisionValues["SUB_INSP_DIST_REAR_Y1"]);
                VisionValues["SUB_INSP_DIST_REAR_X2"].NextValue = (double)Math.Round(inspectionRstData[2].Y, 3, MidpointRounding.ToEven);                FDC_IOs.Add(VisionValues["SUB_INSP_DIST_REAR_X2"]);
                VisionValues["SUB_INSP_DIST_REAR_Y2"].NextValue = (double)Math.Round(inspectionRstData[3].Y, 3, MidpointRounding.ToEven);                FDC_IOs.Add(VisionValues["SUB_INSP_DIST_REAR_Y2"]);
            }
            else if(processType == Algo_Lami_Bended_4sides.ProcessType.U3_MAIN_INSP)
            {
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P1_X"].NextValue = (double)TarPointData[0].OutputXYT.X;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P1_X"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P1_Y"].NextValue = (double)TarPointData[0].OutputXYT.Y;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P1_Y"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P1"].NextValue = (double)TarPointData[0].Score;                                       FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P1"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P2_X"].NextValue = (double)TarPointData[1].OutputXYT.X;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P2_X"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P2_Y"].NextValue = (double)TarPointData[1].OutputXYT.Y;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P2_Y"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P2"].NextValue = (double)TarPointData[1].Score;                                       FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P2"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_PITCH_P1_TO_P2"].NextValue = (double)0;                                                           FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_PITCH_P1_TO_P2"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P3_X"].NextValue = (double)TarPointData[2].OutputXYT.X;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P3_X"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P3_Y"].NextValue = (double)TarPointData[2].OutputXYT.Y;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P3_Y"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P3"].NextValue = (double)TarPointData[2].Score;                                       FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P3"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P4_X"].NextValue = (double)TarPointData[3].OutputXYT.X;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P4_X"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P4_Y"].NextValue = (double)TarPointData[3].OutputXYT.Y;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P4_Y"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P4"].NextValue = (double)TarPointData[3].Score;                                       FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_POINT_SCORE_P4"]);
                VisionValues["MAIN_INSPECTION_Tar_MARK_PITCH_P3_TO_P4"].NextValue = (double)0;                                                           FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Tar_MARK_PITCH_P3_TO_P4"]);
                                                                                                                                                        
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P1_X"].NextValue = (double)ObjPointData[0].OutputXYT.X;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P1_X"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P1_Y"].NextValue = (double)ObjPointData[0].OutputXYT.Y;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P1_Y"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P1"].NextValue = (double)ObjPointData[0].Score;                                       FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P1"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P2_X"].NextValue = (double)ObjPointData[1].OutputXYT.X;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P2_X"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P2_Y"].NextValue = (double)ObjPointData[1].OutputXYT.Y;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P2_Y"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P2"].NextValue = (double)ObjPointData[1].Score;                                       FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P2"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_PITCH_P1_TO_P2"].NextValue = (double)0;                                                           FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_PITCH_P1_TO_P2"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P3_X"].NextValue = (double)ObjPointData[2].OutputXYT.X;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P3_X"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P3_Y"].NextValue = (double)ObjPointData[2].OutputXYT.Y;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P3_Y"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P3"].NextValue = (double)ObjPointData[2].Score;                                       FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P3"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P4_X"].NextValue = (double)ObjPointData[3].OutputXYT.X;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P4_X"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P4_Y"].NextValue = (double)ObjPointData[3].OutputXYT.Y;                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P4_Y"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P4"].NextValue = (double)ObjPointData[3].Score;                                       FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_POINT_SCORE_P4"]);
                VisionValues["MAIN_INSPECTION_Obj_MARK_PITCH_P3_TO_P4"].NextValue = (double)0;                                                           FDC_IOs.Add(VisionValues["MAIN_INSPECTION_Obj_MARK_PITCH_P3_TO_P4"]);
                                                                                                                                                        
                VisionValues["MAIN_INSPECTION_VISION_RESULT_REV_X"].NextValue = (double)0;                                                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_VISION_RESULT_REV_X"]);
                VisionValues["MAIN_INSPECTION_VISION_RESULT_REV_Y"].NextValue = (double)0;                                                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_VISION_RESULT_REV_Y"]);
                VisionValues["MAIN_INSPECTION_VISION_RESULT_REV_T"].NextValue = (double)0;                                                               FDC_IOs.Add(VisionValues["MAIN_INSPECTION_VISION_RESULT_REV_T"]);
                VisionValues["MAIN_INSP_DIST_FRONT_X1"].NextValue = (double)Math.Round(inspectionRstData[0].X, 3, MidpointRounding.ToEven);              FDC_IOs.Add(VisionValues["MAIN_INSP_DIST_FRONT_X1"]);
                VisionValues["MAIN_INSP_DIST_FRONT_Y1"].NextValue = (double)Math.Round(inspectionRstData[1].X, 3, MidpointRounding.ToEven);              FDC_IOs.Add(VisionValues["MAIN_INSP_DIST_FRONT_Y1"]);
                VisionValues["MAIN_INSP_DIST_FRONT_X2"].NextValue = (double)Math.Round(inspectionRstData[2].X, 3, MidpointRounding.ToEven);              FDC_IOs.Add(VisionValues["MAIN_INSP_DIST_FRONT_X2"]);
                VisionValues["MAIN_INSP_DIST_FRONT_Y2"].NextValue = (double)Math.Round(inspectionRstData[3].X, 3, MidpointRounding.ToEven);              FDC_IOs.Add(VisionValues["MAIN_INSP_DIST_FRONT_Y2"]);
                VisionValues["MAIN_INSP_DIST_REAR_X1"].NextValue = (double)Math.Round(inspectionRstData[0].Y, 3, MidpointRounding.ToEven);               FDC_IOs.Add(VisionValues["MAIN_INSP_DIST_REAR_X1"]);
                VisionValues["MAIN_INSP_DIST_REAR_Y1"].NextValue = (double)Math.Round(inspectionRstData[1].Y, 3, MidpointRounding.ToEven);               FDC_IOs.Add(VisionValues["MAIN_INSP_DIST_REAR_Y1"]);
                VisionValues["MAIN_INSP_DIST_REAR_X2"].NextValue = (double)Math.Round(inspectionRstData[2].Y, 3, MidpointRounding.ToEven);               FDC_IOs.Add(VisionValues["MAIN_INSP_DIST_REAR_X2"]);
                VisionValues["MAIN_INSP_DIST_REAR_Y2"].NextValue = (double)Math.Round(inspectionRstData[3].Y, 3, MidpointRounding.ToEven);               FDC_IOs.Add(VisionValues["MAIN_INSP_DIST_REAR_Y2"]);
            }

            #endregion
            WriteVisionIO(AlgoRst);

            //AppendMessage(Name, "Caluration Complete");
            return true;

        }

        //Line의 Theta와 Point 성분으로 다른 포인트의 법선 거리를 구하는 함수
        private double GetDistanceLinePoint(double _LineRad, XY _LinePoint, XY _DotPoint)
        {
            double rst = 0;

            double A = Math.Tan(_LineRad);
            double B = -1;
            double C = _LinePoint.Y - A * _LinePoint.X;

            rst = Math.Abs(A * _DotPoint.X + B * _DotPoint.Y + C) / Math.Sqrt(A*A + B*B);

            return rst;
        }

        private bool MeasureSpecTolerance(double _Rst, double _Spec, double _Tol)
        {
            if (_Tol == 0) return true;
            else
            {
                if (_Tol > Math.Abs(_Rst - _Spec)) return true;
                else return false;
            }
        }
    }
}