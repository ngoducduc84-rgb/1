﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using Iva.Bplus.Modules.CogDisplay;

// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo_Lami_Bended_4sides
{
    public partial class Algo_Lami_Bended_4sidesObject
    {
        private bool Align4PObjTarCalc()
        {
            #region Initialize
            model = SystemModel.GetCurModel();
            bResult = true;
            ObjPointData = new IPointResult[4];
            TarPointData = new IPointResult[4];
            ObjFindCnt = new IClear[4];
            TarFindCnt = new IClear[4];
            ObjCalData = new CalDataObject[4];
            TarCalData = new CalDataObject[4];

            ObjRobotData = new XY[4];
            TarRobotData = new XY[4];

            ObjCoordData = new XY[4];
            TarCoordData = new XY[4];

            ObjFixData = new XY[4];
            TarFixData = new XY[4];

            Revision = new XYT();
           
            double[] ObjLengthSpec = new double[4];
            bool[] ObjLcheckRst = new bool[4] { true, true, true, true };
            double[] TarLengthSpec = new double[4];
            bool[] TarLcheckRst = new bool[4] { true, true, true, true };
            double ObjLengthTor = 0;
            double TarLengthTor = 0;
            #endregion

            #region InputDataWtire
            //Model Param Read
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Align4PObjTarModelParams;
            ObjLengthSpec[0] = (double)mParams.ObjLength12.Value;
            ObjLengthSpec[1] = (double)mParams.ObjLength34.Value;
            ObjLengthSpec[2] = (double)mParams.ObjLength14.Value;
            ObjLengthSpec[3] = (double)mParams.ObjLength23.Value;
            ObjLengthTor = (double)mParams.ObjLengthTolerance.Value;

            TarLengthSpec[0] = (double)mParams.TarLength12.Value;
            TarLengthSpec[1] = (double)mParams.TarLength34.Value;
            TarLengthSpec[2] = (double)mParams.TarLength14.Value;
            TarLengthSpec[3] = (double)mParams.TarLength23.Value;
            TarLengthTor = (double)mParams.TarLengthTolerance.Value;

            double[] LimitSpec = new double[3];
            bool[] LimitRst = new bool[3] { true, true, true };
            LimitSpec[0] = (double)mParams.Limit_X.Value;
            LimitSpec[1] = (double)mParams.Limit_Y.Value;
            LimitSpec[2] = (double)mParams.Limit_T.Value;
            double[] LimitTor = new double[3];
            LimitTor[0] = (double)mParams.Limit_X_Tolerance.Value;
            LimitTor[1] = (double)mParams.Limit_Y_Tolerance.Value;
            LimitTor[2] = (double)mParams.Limit_T_Tolerance.Value;

            //PLC Data Read 
            AssignPLCData_GLami();
            AlignOffset = GLamiPLCIO.OffsetXYT;

            //conntect Check
            for (int i = 0; i < 4; i++)
            {
                if (!InputValues.ContainsKey("Obj_P" + (i + 1).ToString()))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                ObjPointData[i] = InputValues["Obj_P" + (i + 1).ToString()] as IPointResult;
                ObjFindCnt[i] = InputValues["Obj_P" + (i + 1).ToString()] as IClear;
                if (!InputValues.ContainsKey("Tar_P"+(i+1).ToString()))
                {
                    errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                    return false;
                }
                TarPointData[i] = InputValues["Tar_P" + (i + 1).ToString()] as IPointResult;
                TarFindCnt[i] = InputValues["Tar_P" + (i + 1).ToString()] as IClear;

                ObjCalData[i] = ObjPointData[i] as CalDataObject;
                if (ObjCalData[i] == null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    return false;
                }

                TarCalData[i] = TarPointData[i].CalData as CalDataObject;
                if(TarCalData[i]==null)
                {
                    errorCode = AlgoActionBase.Err_CalData_Is_Null;
                    return false;
                }

                ObjRobotData[i] = ObjCalData[i].GetV2R(model, new XY(ObjPointData[i].OutputXYT.X, ObjPointData[i].OutputXYT.Y));
                ObjFixData[i] = ObjCalData[i].GetRotateCenter(model);
                ObjCoordData[i] = ObjCalData[i].GetRotateCenter(model);
                ObjCoordData[i].X += ObjRobotData[i].X;
                ObjCoordData[i].Y += ObjRobotData[i].Y;

                TarRobotData[i] = TarCalData[i].GetV2R(model, new XY(TarPointData[i].OutputXYT.X, TarPointData[i].OutputXYT.Y));
                TarFixData[i] = TarCalData[i].GetRotateCenter(model);
                TarCoordData[i] = TarCalData[i].GetRotateCenter(model);
                TarCoordData[i].X += TarRobotData[i].X;
                TarCoordData[i].Y += TarRobotData[i].Y;
            }
            bool[] bFind = new bool[4] { false, false, false, false };
            int Findcnt = CheckFindPoint(ObjFindCnt, TarFindCnt, ref bFind);
            #endregion

            #region Calc Align

            XYT ObjCenter = new XYT();
            XYT TarCenter = new XYT();
            XYT ZeroPos = new XYT(0,0,0);

            double ObjLength12 = 0;
            double ObjLength34 = 0;
            double ObjLength14 = 0;
            double ObjLength23 = 0;
            double TarLength12 = 0;
            double TarLength34 = 0;
            double TarLength14 = 0;
            double TarLength23 = 0;
            //4Point 다 찾은 경우는 정상 진행
            if (Findcnt == 4)
            {
                ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[1].X + ObjCoordData[2].X + ObjCoordData[3].X) * 0.25;
                ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y + ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.25;
                TarCenter.X = (TarCoordData[0].X + TarCoordData[1].X + TarCoordData[2].X + TarCoordData[3].X) * 0.25;
                TarCenter.Y = (TarCoordData[0].Y + TarCoordData[1].Y + TarCoordData[2].Y + TarCoordData[3].Y) * 0.25;

                ObjCenter.T = (NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1])) +
                                NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3]))) * 0.5;
                TarCenter.T = (NormalizeTheta(GetTheta(TarCoordData[0], TarCoordData[1])) +
                                NormalizeTheta(GetTheta(TarCoordData[2], TarCoordData[3]))) * 0.5;

                ObjLength12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                ObjLength34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                ObjLength14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                ObjLength23 = GetLength(ObjCoordData[1], ObjCoordData[2]);
                TarLength12 = GetLength(TarCoordData[0], TarCoordData[1]);
                TarLength34 = GetLength(TarCoordData[2], TarCoordData[3]);
                TarLength14 = GetLength(TarCoordData[0], TarCoordData[3]);
                TarLength23 = GetLength(TarCoordData[1], TarCoordData[2]);

                ObjLcheckRst[0] = ConfirmSpecRange(ObjLength12, ObjLengthSpec[0], ObjLengthTor);
                ObjLcheckRst[1] = ConfirmSpecRange(ObjLength34, ObjLengthSpec[1], ObjLengthTor);
                ObjLcheckRst[2] = ConfirmSpecRange(ObjLength14, ObjLengthSpec[2], ObjLengthTor);
                ObjLcheckRst[3] = ConfirmSpecRange(ObjLength23, ObjLengthSpec[3], ObjLengthTor);

                TarLcheckRst[0] = ConfirmSpecRange(TarLength12, TarLengthSpec[0], TarLengthTor);
                TarLcheckRst[1] = ConfirmSpecRange(TarLength34, TarLengthSpec[1], TarLengthTor);
                TarLcheckRst[2] = ConfirmSpecRange(TarLength14, TarLengthSpec[2], TarLengthTor);
                TarLcheckRst[3] = ConfirmSpecRange(TarLength23, TarLengthSpec[3], TarLengthTor);
            }
            else if(Findcnt==3 && align3PMode == Align3PMode.Use)
            {
                if(!bFind[0])
                {
                    ObjCenter.X = (ObjCoordData[1].X + ObjCoordData[2].X) * 0.5;
                    ObjCenter.Y = (ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.5;
                    TarCenter.X = (TarCoordData[1].X + TarCoordData[2].X) * 0.5;
                    TarCenter.Y = (TarCoordData[2].Y + TarCoordData[3].Y) * 0.5;
                    ObjCenter.T = NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3]));
                    TarCenter.T = NormalizeTheta(GetTheta(TarCoordData[2], TarCoordData[3]));

                    ObjLength34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                    ObjLength23 = GetLength(ObjCoordData[1], ObjCoordData[2]);
                    TarLength34 = GetLength(TarCoordData[2], TarCoordData[3]);
                    TarLength23 = GetLength(TarCoordData[1], TarCoordData[2]);

                    ObjLcheckRst[1] = ConfirmSpecRange(ObjLength34, ObjLengthSpec[1], ObjLengthTor);
                    ObjLcheckRst[3] = ConfirmSpecRange(ObjLength23, ObjLengthSpec[3], ObjLengthTor);
                    TarLcheckRst[1] = ConfirmSpecRange(TarLength34, TarLengthSpec[1], TarLengthTor);
                    TarLcheckRst[3] = ConfirmSpecRange(TarLength23, TarLengthSpec[3], TarLengthTor);
                }
                else if(!bFind[1])
                {
                    ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[3].X) * 0.5;
                    ObjCenter.Y = (ObjCoordData[2].Y + ObjCoordData[3].Y) * 0.5;
                    TarCenter.X = (TarCoordData[0].X + TarCoordData[3].X) * 0.5;
                    TarCenter.Y = (TarCoordData[2].Y + TarCoordData[3].Y) * 0.5;
                    ObjCenter.T = NormalizeTheta(GetTheta(ObjCoordData[2], ObjCoordData[3]));
                    TarCenter.T = NormalizeTheta(GetTheta(TarCoordData[2], TarCoordData[3]));

                    ObjLength34 = GetLength(ObjCoordData[2], ObjCoordData[3]);
                    ObjLength14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                    TarLength34 = GetLength(TarCoordData[2], TarCoordData[3]);
                    TarLength14 = GetLength(TarCoordData[0], TarCoordData[3]);
                    ObjLcheckRst[1] = ConfirmSpecRange(ObjLength34, ObjLengthSpec[1], ObjLengthTor);
                    ObjLcheckRst[2] = ConfirmSpecRange(ObjLength14, ObjLengthSpec[2], ObjLengthTor);
                    TarLcheckRst[1] = ConfirmSpecRange(TarLength34, TarLengthSpec[1], TarLengthTor);
                    TarLcheckRst[2] = ConfirmSpecRange(TarLength14, TarLengthSpec[2], TarLengthTor);
                }
                else if(!bFind[2])
                {
                    ObjCenter.X = (ObjCoordData[0].X + ObjCoordData[3].X) * 0.5;
                    ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y) * 0.5;
                    TarCenter.X = (TarCoordData[0].X + TarCoordData[3].X) * 0.5;
                    TarCenter.Y = (TarCoordData[0].Y + TarCoordData[1].Y) * 0.5;
                    ObjCenter.T = NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1]));
                    TarCenter.T = NormalizeTheta(GetTheta(TarCoordData[0], TarCoordData[1]));

                    ObjLength12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                    ObjLength14 = GetLength(ObjCoordData[0], ObjCoordData[3]);
                    TarLength12 = GetLength(TarCoordData[0], TarCoordData[1]);
                    TarLength14 = GetLength(TarCoordData[0], TarCoordData[3]);
                    ObjLcheckRst[0] = ConfirmSpecRange(ObjLength12, ObjLengthSpec[0], ObjLengthTor);
                    ObjLcheckRst[2] = ConfirmSpecRange(ObjLength14, ObjLengthSpec[2], ObjLengthTor);
                    TarLcheckRst[0] = ConfirmSpecRange(TarLength12, TarLengthSpec[0], TarLengthTor);
                    TarLcheckRst[2] = ConfirmSpecRange(TarLength14, TarLengthSpec[2], TarLengthTor);
                }
                else if(!bFind[3])
                {
                    ObjCenter.X = (ObjCoordData[1].X + ObjCoordData[2].X) * 0.5;
                    ObjCenter.Y = (ObjCoordData[0].Y + ObjCoordData[1].Y) * 0.5;
                    TarCenter.X = (TarCoordData[1].X + TarCoordData[2].X) * 0.5;
                    TarCenter.Y = (TarCoordData[0].Y + TarCoordData[1].Y) * 0.5;
                    ObjCenter.T = NormalizeTheta(GetTheta(ObjCoordData[0], ObjCoordData[1]));
                    TarCenter.T = NormalizeTheta(GetTheta(TarCoordData[0], TarCoordData[1]));

                    ObjLength12 = GetLength(ObjCoordData[0], ObjCoordData[1]);
                    ObjLength23 = GetLength(ObjCoordData[1], ObjCoordData[2]);
                    TarLength12 = GetLength(TarCoordData[0], TarCoordData[1]);
                    TarLength23 = GetLength(TarCoordData[1], TarCoordData[2]);
                    ObjLcheckRst[0] = ConfirmSpecRange(ObjLength12, ObjLengthSpec[0], ObjLengthTor);
                    ObjLcheckRst[3] = ConfirmSpecRange(ObjLength23, ObjLengthSpec[3], ObjLengthTor);
                    TarLcheckRst[0] = ConfirmSpecRange(TarLength12, TarLengthSpec[0], TarLengthTor);
                    TarLcheckRst[3] = ConfirmSpecRange(TarLength23, TarLengthSpec[3], TarLengthTor);
                }                
            }
            else
            {
                bResult = false;
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                rst = "Mark Find NG";
                return false;
            }

            XYT Tar_Pos = ApplyTargetOffset(TarCenter, AlignOffset);
            
            double RadT = NormalizeTheta(Tar_Pos.T - ObjCenter.T);
            double DriftX = Math.Cos(RadT) * ObjCenter.X - Math.Sin(RadT) * ObjCenter.Y;
            double DriftY = Math.Sin(RadT) * ObjCenter.X + Math.Cos(RadT) * ObjCenter.Y;

            Revision.X = Tar_Pos.X - DriftX;
            Revision.Y = Tar_Pos.Y - DriftY;
            Revision.T = RadianToDegree(RadT);

            XYT Tar_Pos_FDC = ApplyTargetOffset(TarCenter, ZeroPos);

            double RadT_FDC = NormalizeTheta(Tar_Pos_FDC.T - ObjCenter.T);
            double DriftX_FDC = Math.Cos(RadT_FDC) * ObjCenter.X - Math.Sin(RadT_FDC) * ObjCenter.Y;
            double DriftY_FDC = Math.Sin(RadT_FDC) * ObjCenter.X + Math.Cos(RadT_FDC) * ObjCenter.Y;

            Revision_FDC.X = Tar_Pos_FDC.X - DriftX_FDC;
            Revision_FDC.Y = Tar_Pos_FDC.Y - DriftY_FDC;
            Revision_FDC.T = RadianToDegree(RadT_FDC);
            #endregion

            #region convert UVRW
            UVRWDataObject.UVRWOption = AxisOption.UVRW;
            UVRW convertXY = UVRWDataObject.GetXYPos4Axis(Revision.X, Revision.Y) as UVRW;
            UVRW convertT = UVRWDataObject.GetThetaPos4Axis(Revision.T) as UVRW;
            Revision_UVRW = convertXY + convertT;
            #endregion

            #region Check Length
            if (!ObjLcheckRst[0] || !ObjLcheckRst[1] || !ObjLcheckRst[2] || !ObjLcheckRst[3])
            {
                bResult = false;
                errorCode = AlgoActionBase.Err_Lower_Length_Check;
                rst = "Lower L Check NG";
            }

            if (!TarLcheckRst[0] || !TarLcheckRst[1] || !TarLcheckRst[2] || !TarLcheckRst[3])
            {
                bResult = false;
                errorCode = AlgoActionBase.Err_Upper_Length_Check;
                rst += "Upper L Check NG";
            }
            #endregion

            #region Limit 판정 및 메뉴얼 마크로 설정
            LimitRst[0] = ConfirmSpecRange(Revision.X, LimitSpec[0], LimitTor[0]);
            LimitRst[1] = ConfirmSpecRange(Revision.Y, LimitSpec[1], LimitTor[1]);
            LimitRst[2] = ConfirmSpecRange(Revision.T, LimitSpec[2], LimitTor[2]);

            if (bResult && (!LimitRst[0] || !LimitRst[1] || !LimitRst[2]))
            {
                bResult = false;
                errorCode = AlgoActionBase.Err_Tolerance_Exceeded;
                rst = "Limit NG";
            }

            if (bResult)
            {
                rst = "OK";
            }
            #endregion

            #region ResultData Update & log Write
            AlgoRst = new Align4PObjTarReslut
            {
                Name = name,
                ID = sourceID,
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Result = rst,
                RevX = Revision.X,
                RevY = Revision.Y,
                RevT = Revision.T,
                RevX1 = Revision_UVRW.V,
                RevX2 = Revision_UVRW.W,
                RevY1 = Revision_UVRW.U,
                RevY2 = Revision_UVRW.R,
                OffsetX = AlignOffset.X,
                OffsetY = AlignOffset.Y,
                OffsetT = AlignOffset.T,
                ObjLength12 = ObjLength12,
                ObjLength34 = ObjLength34,
                ObjLength13 = ObjLength14,
                ObjLength24 = ObjLength23,
                TarLength12 = TarLength12,
                TarLength34 = TarLength34,
                TarLength13 = TarLength14,
                TarLength24 = TarLength23,
            };
            if (GridViewObject != null)
                GridViewObject.SetResult(AlgoRst);
            #endregion

            #region FDC Write
            List<IOStruct> FDC_IOs = new List<IOStruct>();

            #region Line, Mark 구별 O
            for (int i = 0; i < 4; i++)
            {
                if (ObjPointData[i] is MatchingRstData)
                {
                    VisionValues["LOWER_ALIGN_MARK_POS_" + (i + 1) + "_X"].NextValue = (double)ObjPointData[i].OutputXYT.X;     FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_" + (i + 1) + "_X"]);
                    VisionValues["LOWER_ALIGN_MARK_POS_" + (i + 1) + "_Y"].NextValue = (double)ObjPointData[i].OutputXYT.Y;     FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_" + (i + 1) + "_Y"]);
                    VisionValues["LOWER_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"].NextValue = (double)ObjPointData[i].Score;     FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"]);
                                                                                                                                
                    VisionValues["LOWER_ANGLE " + (i + 1)].NextValue = (double)90;                                              FDC_IOs.Add(VisionValues["LOWER_ANGLE " + (i + 1)]);
                }                                                                                                               
                else if(ObjPointData[i] is LineCrossRstData)                                                                    
                {                                                                                                               
                    VisionValues["LOWER_ALIGN_MARK_POS_" + (i + 1) + "_X"].NextValue = (double)ObjPointData[i].OutputXYT.X;     FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_" + (i + 1) + "_X"]);
                    VisionValues["LOWER_ALIGN_MARK_POS_" + (i + 1) + "_Y"].NextValue = (double)ObjPointData[i].OutputXYT.Y;     FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_" + (i + 1) + "_Y"]);
                    VisionValues["LOWER_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"].NextValue = (double)99;                        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"]);
                                                                                                                                
                    VisionValues["LOWER_ANGLE " + (i + 1)].NextValue = (double)ObjPointData[i].Angle;                           FDC_IOs.Add(VisionValues["LOWER_ANGLE " + (i + 1)]);
                }                                                                                                               
                                                                                                                                
                if(TarPointData[i] is MatchingRstData)                                                                          
                {                                                                                                               
                    VisionValues["UPPER_ALIGN_MARK_POS_" + (i + 1) + "_X"].NextValue = (double)TarPointData[i].OutputXYT.X;     FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_" + (i + 1) + "_X"]);
                    VisionValues["UPPER_ALIGN_MARK_POS_" + (i + 1) + "_Y"].NextValue = (double)TarPointData[i].OutputXYT.Y;     FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_" + (i + 1) + "_Y"]);
                    VisionValues["UPPER_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"].NextValue = (double)TarPointData[i].Score;     FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"]);
                                                                                                                                
                    VisionValues["UPPER_ANGLE " + (i + 1)].NextValue = (double)90;                                              FDC_IOs.Add(VisionValues["UPPER_ANGLE " + (i + 1)]);
                }                                                                                                               
                else if(TarPointData[i] is LineCrossRstData)                                                                    
                {                                                                                                               
                    VisionValues["UPPER_ALIGN_MARK_POS_" + (i + 1) + "_X"].NextValue = (double)TarPointData[i].OutputXYT.X;     FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_" + (i + 1) + "_X"]);
                    VisionValues["UPPER_ALIGN_MARK_POS_" + (i + 1) + "_Y"].NextValue = (double)TarPointData[i].OutputXYT.Y;     FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_" + (i + 1) + "_Y"]);
                    VisionValues["UPPER_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"].NextValue = (double)99;                        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_" + (i + 1) + "_MATCH_RATIO"]);
                                                                                                                                
                    VisionValues["UPPER_ANGLE " + (i + 1)].NextValue = (double)TarPointData[i].Angle;                           FDC_IOs.Add(VisionValues["UPPER_ANGLE " + (i + 1)]);
                }   
            }

            if (Findcnt == 4)
            {
                VisionValues["LOWER_MARK_PITCH_P1_T0_P2"].NextValue = (double)ObjLength12;                                      FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["LOWER_MARK_PITCH_P3_T0_P4"].NextValue = (double)ObjLength34;                                      FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P3_T0_P4"]);
                                                                                                                                
                VisionValues["UPPER_MARK_PITCH_P1_T0_P2"].NextValue = (double)TarLength12;                                      FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["UPPER_MARK_PITCH_P3_T0_P4"].NextValue = (double)TarLength34;                                      FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P3_T0_P4"]);

                VisionValues["LOWER_HEIGHT 1"].NextValue = (double)ObjLength14;                                                 FDC_IOs.Add(VisionValues["LOWER_HEIGHT 1"]);
                VisionValues["LOWER_HEIGHT 2"].NextValue = (double)ObjLength23;                                                 FDC_IOs.Add(VisionValues["LOWER_HEIGHT 2"]);

                VisionValues["UPPER_HEIGHT 1"].NextValue = (double)TarLength14;                                                 FDC_IOs.Add(VisionValues["UPPER_HEIGHT 1"]);
                VisionValues["UPPER_HEIGHT 2"].NextValue = (double)TarLength23;                                                 FDC_IOs.Add(VisionValues["UPPER_HEIGHT 2"]);
            }
            else if (Findcnt == 3 && !bFind[0])
            {
                VisionValues["LOWER_MARK_PITCH_P1_T0_P2"].NextValue = (double)mParams.ObjLength12.Value;                        FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["LOWER_MARK_PITCH_P3_T0_P4"].NextValue = (double)ObjLength34;                                      FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P3_T0_P4"]);
                                                                                                                                
                VisionValues["UPPER_MARK_PITCH_P1_T0_P2"].NextValue = (double)mParams.TarLength12.Value;                        FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["UPPER_MARK_PITCH_P3_T0_P4"].NextValue = (double)TarLength34;                                      FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P3_T0_P4"]);

                VisionValues["LOWER_HEIGHT 1"].NextValue = (double)mParams.ObjLength14.Value;                                   FDC_IOs.Add(VisionValues["LOWER_HEIGHT 1"]);
                VisionValues["LOWER_HEIGHT 2"].NextValue = (double)ObjLength23;                                                 FDC_IOs.Add(VisionValues["LOWER_HEIGHT 2"]);
                                                                                                                                
                VisionValues["UPPER_HEIGHT 1"].NextValue = (double)mParams.TarLength14.Value;                                   FDC_IOs.Add(VisionValues["UPPER_HEIGHT 1"]);
                VisionValues["UPPER_HEIGHT 2"].NextValue = (double)TarLength23;                                                 FDC_IOs.Add(VisionValues["UPPER_HEIGHT 2"]);
            }
            else if (Findcnt == 3 && !bFind[1])
            {
                VisionValues["LOWER_MARK_PITCH_P1_T0_P2"].NextValue = (double)mParams.ObjLength12.Value;                        FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["LOWER_MARK_PITCH_P3_T0_P4"].NextValue = (double)ObjLength34;                                      FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P3_T0_P4"]);
                                                                                                                                
                VisionValues["UPPER_MARK_PITCH_P1_T0_P2"].NextValue = (double)mParams.TarLength12.Value;                        FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["UPPER_MARK_PITCH_P3_T0_P4"].NextValue = (double)TarLength34;                                      FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P3_T0_P4"]);

                VisionValues["LOWER_HEIGHT 1"].NextValue = (double)ObjLength14;                                                 FDC_IOs.Add(VisionValues["LOWER_HEIGHT 1"]);
                VisionValues["LOWER_HEIGHT 2"].NextValue = (double)mParams.ObjLength23.Value;                                   FDC_IOs.Add(VisionValues["LOWER_HEIGHT 2"]);
                                                                                                                                
                VisionValues["UPPER_HEIGHT 1"].NextValue = (double)TarLength14;                                                 FDC_IOs.Add(VisionValues["UPPER_HEIGHT 1"]);
                VisionValues["UPPER_HEIGHT 2"].NextValue = (double)mParams.TarLength23.Value;                                   FDC_IOs.Add(VisionValues["UPPER_HEIGHT 2"]);
            }
            else if (Findcnt == 3 && !bFind[2])
            {
                VisionValues["LOWER_MARK_PITCH_P1_T0_P2"].NextValue = (double)ObjLength12;                                      FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["LOWER_MARK_PITCH_P3_T0_P4"].NextValue = (double)mParams.ObjLength34.Value;                        FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P3_T0_P4"]);
                                                                                                                                
                VisionValues["UPPER_MARK_PITCH_P1_T0_P2"].NextValue = (double)TarLength12;                                      FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["UPPER_MARK_PITCH_P3_T0_P4"].NextValue = (double)mParams.TarLength34.Value;                        FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P3_T0_P4"]);

                VisionValues["LOWER_HEIGHT 1"].NextValue = (double)ObjLength14;                                                 FDC_IOs.Add(VisionValues["LOWER_HEIGHT 1"]);
                VisionValues["LOWER_HEIGHT 2"].NextValue = (double)mParams.ObjLength23.Value;                                   FDC_IOs.Add(VisionValues["LOWER_HEIGHT 2"]);
                                                                                                                                
                VisionValues["UPPER_HEIGHT 1"].NextValue = (double)TarLength14;                                                 FDC_IOs.Add(VisionValues["UPPER_HEIGHT 1"]);
                VisionValues["UPPER_HEIGHT 2"].NextValue = (double)mParams.TarLength23.Value;                                   FDC_IOs.Add(VisionValues["UPPER_HEIGHT 2"]);
            }
            else if (Findcnt == 3 && !bFind[3])
            {
                VisionValues["LOWER_MARK_PITCH_P1_T0_P2"].NextValue = (double)ObjLength12;                                      FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["LOWER_MARK_PITCH_P3_T0_P4"].NextValue = (double)mParams.ObjLength34.Value;                        FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P3_T0_P4"]);
                                                                                                                                
                VisionValues["UPPER_MARK_PITCH_P1_T0_P2"].NextValue = (double)TarLength12;                                      FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P1_T0_P2"]);
                VisionValues["UPPER_MARK_PITCH_P3_T0_P4"].NextValue = (double)mParams.TarLength34.Value;                        FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P3_T0_P4"]);
                                                                                                                                
                VisionValues["LOWER_HEIGHT 1"].NextValue = (double)mParams.ObjLength14.Value;                                   FDC_IOs.Add(VisionValues["LOWER_HEIGHT 1"]);
                VisionValues["LOWER_HEIGHT 2"].NextValue = (double)ObjLength23;                                                 FDC_IOs.Add(VisionValues["LOWER_HEIGHT 2"]);
                                                                                                                                
                VisionValues["UPPER_HEIGHT 1"].NextValue = (double)mParams.TarLength14.Value;                                   FDC_IOs.Add(VisionValues["UPPER_HEIGHT 1"]);
                VisionValues["UPPER_HEIGHT 2"].NextValue = (double)TarLength23;                                                 FDC_IOs.Add(VisionValues["UPPER_HEIGHT 2"]);
            }            

            VisionValues["ALIGN_POS_TARGET_Y"].NextValue = (double)Revision.Y;                                                  FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_Y"]);
            VisionValues["ALIGN_POS_TARGET_X"].NextValue = (double)Revision.X;                                                  FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_X"]);
            VisionValues["ALIGN_POS_TARGET_THETA"].NextValue = (double)Revision.T;                                              FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_THETA"]);

            VisionValues["VISION_ALIGN_RESULT_REV_X"].NextValue = (double)Revision_FDC.X;                                       FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_X"]);
            VisionValues["VISION_ALIGN_RESULT_REV_Y"].NextValue = (double)Revision_FDC.Y;                                       FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_Y"]);
            VisionValues["VISION_ALIGN_RESULT_REV_THETA"].NextValue = (double)Revision_FDC.T;                                   FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_THETA"]);

            VisionValues["ALIGN_RESULT_X1"].NextValue = (double)Revision_UVRW.V;                                                FDC_IOs.Add(VisionValues["ALIGN_RESULT_X1"]);
            VisionValues["ALIGN_RESULT_X2"].NextValue = (double)Revision_UVRW.W;                                                FDC_IOs.Add(VisionValues["ALIGN_RESULT_X2"]);
            VisionValues["ALIGN_RESULT_Y1"].NextValue = (double)Revision_UVRW.U;                                                FDC_IOs.Add(VisionValues["ALIGN_RESULT_Y1"]);
            VisionValues["ALIGN_RESULT_Y2"].NextValue = (double)Revision_UVRW.R;                                                FDC_IOs.Add(VisionValues["ALIGN_RESULT_Y2"]);
            
            #endregion

            #region Line, Mark 구별 X
            /*
            VisionValues["LOWER_ALIGN_MARK_POS_1_X"].NextValue = (double)ObjMatchingData[0].OutputXYT.X;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_1_X"]);
            VisionValues["LOWER_ALIGN_MARK_POS_1_Y"].NextValue = (double)ObjMatchingData[0].OutputXYT.Y;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_1_Y"]);
            VisionValues["LOWER_ALIGN_MARK_1_MATCH_RATIO"].NextValue = (double)ObjMatchingData[0].Score;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_1_MATCH_RATIO"]);
            VisionValues["LOWER_ALIGN_MARK_POS_2_X"].NextValue = (double)ObjMatchingData[1].OutputXYT.X;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_2_X"]);
            VisionValues["LOWER_ALIGN_MARK_POS_2_Y"].NextValue = (double)ObjMatchingData[1].OutputXYT.Y;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_2_Y"]);
            VisionValues["LOWER_ALIGN_MARK_2_MATCH_RATIO"].NextValue = (double)ObjMatchingData[1].Score;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_2_MATCH_RATIO"]);
            VisionValues["LOWER_MARK_PITCH_P1_T0_P2"].NextValue = (double)ObjLength12;                          FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P1_T0_P2"]);
            VisionValues["LOWER_ALIGN_MARK_POS_3_X"].NextValue = (double)ObjMatchingData[2].OutputXYT.X;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_3_X"]);
            VisionValues["LOWER_ALIGN_MARK_POS_3_Y"].NextValue = (double)ObjMatchingData[2].OutputXYT.Y;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_3_Y"]);
            VisionValues["LOWER_ALIGN_MARK_3_MATCH_RATIO"].NextValue = (double)ObjMatchingData[2].Score;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_3_MATCH_RATIO"]);
            VisionValues["LOWER_ALIGN_MARK_POS_4_X"].NextValue = (double)ObjMatchingData[3].OutputXYT.X;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_4_X"]);
            VisionValues["LOWER_ALIGN_MARK_POS_4_Y"].NextValue = (double)ObjMatchingData[3].OutputXYT.Y;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_POS_4_Y"]);
            VisionValues["LOWER_ALIGN_MARK_4_MATCH_RATIO"].NextValue = (double)ObjMatchingData[3].Score;        FDC_IOs.Add(VisionValues["LOWER_ALIGN_MARK_4_MATCH_RATIO"]);
            VisionValues["LOWER_MARK_PITCH_P3_T0_P4"].NextValue = (double)ObjLength34;                          FDC_IOs.Add(VisionValues["LOWER_MARK_PITCH_P3_T0_P4"]);
            VisionValues["UPPER_ALIGN_MARK_POS_1_X"].NextValue = (double)TarMatchingData[0].OutputXYT.X; ;      FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_1_X"]);
            VisionValues["UPPER_ALIGN_MARK_POS_1_Y"].NextValue = (double)TarMatchingData[0].OutputXYT.Y;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_1_Y"]);
            VisionValues["UPPER_ALIGN_MARK_1_MATCH_RATIO"].NextValue = (double)TarMatchingData[0].Score;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_1_MATCH_RATIO"]);
            VisionValues["UPPER_ALIGN_MARK_POS_2_X"].NextValue = (double)TarMatchingData[1].OutputXYT.X;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_2_X"]);
            VisionValues["UPPER_ALIGN_MARK_POS_2_Y"].NextValue = (double)TarMatchingData[1].OutputXYT.Y;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_2_Y"]);
            VisionValues["UPPER_ALIGN_MARK_2_MATCH_RATIO"].NextValue = (double)TarMatchingData[1].Score;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_2_MATCH_RATIO"]);
            VisionValues["UPPER_MARK_PITCH_P1_T0_P2"].NextValue = (double)TarLength12;                          FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P1_T0_P2"]);
            VisionValues["UPPER_ALIGN_MARK_POS_3_X"].NextValue = (double)TarMatchingData[2].OutputXYT.X;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_3_X"]);
            VisionValues["UPPER_ALIGN_MARK_POS_3_Y"].NextValue = (double)TarMatchingData[2].OutputXYT.Y;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_3_Y"]);
            VisionValues["UPPER_ALIGN_MARK_3_MATCH_RATIO"].NextValue = (double)TarMatchingData[2].Score;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_3_MATCH_RATIO"]);
            VisionValues["UPPER_ALIGN_MARK_POS_4_X"].NextValue = (double)TarMatchingData[3].OutputXYT.X;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_4_X"]);
            VisionValues["UPPER_ALIGN_MARK_POS_4_Y"].NextValue = (double)TarMatchingData[3].OutputXYT.Y;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_POS_4_Y"]);
            VisionValues["UPPER_ALIGN_MARK_4_MATCH_RATIO"].NextValue = (double)TarMatchingData[3].Score;        FDC_IOs.Add(VisionValues["UPPER_ALIGN_MARK_4_MATCH_RATIO"]);
            VisionValues["UPPER_MARK_PITCH_P3_T0_P4"].NextValue = (double)TarLength34;                          FDC_IOs.Add(VisionValues["UPPER_MARK_PITCH_P3_T0_P4"]);
            VisionValues["ALIGN_POS_TARGET_Y"].NextValue = (double)Revision.Y;                                  FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_Y"]);
            VisionValues["ALIGN_POS_TARGET_X"].NextValue = (double)Revision.X;                                  FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_X"]);
            VisionValues["ALIGN_POS_TARGET_THETA"].NextValue = (double)Revision.T;                              FDC_IOs.Add(VisionValues["ALIGN_POS_TARGET_THETA"]);
            VisionValues["VISION_ALIGN_RESULT_REV_X"].NextValue = (double)Revision_FDC.X;                       FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_X"]);
            VisionValues["VISION_ALIGN_RESULT_REV_Y"].NextValue = (double)Revision_FDC.Y;                       FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_Y"]);
            VisionValues["VISION_ALIGN_RESULT_REV_THETA"].NextValue = (double)Revision_FDC.T;                   FDC_IOs.Add(VisionValues["VISION_ALIGN_RESULT_REV_THETA"]);
            VisionValues["ALIGN_RESULT_X1"].NextValue = (double)Revision_UVRW.V;                                FDC_IOs.Add(VisionValues["ALIGN_RESULT_X1"]);
            VisionValues["ALIGN_RESULT_X2"].NextValue = (double)Revision_UVRW.W;                                FDC_IOs.Add(VisionValues["ALIGN_RESULT_X2"]);
            VisionValues["ALIGN_RESULT_Y1"].NextValue = (double)Revision_UVRW.U;                                FDC_IOs.Add(VisionValues["ALIGN_RESULT_Y1"]);
            VisionValues["ALIGN_RESULT_Y2"].NextValue = (double)Revision_UVRW.R;                                FDC_IOs.Add(VisionValues["ALIGN_RESULT_Y2"]);
            VisionValues["LOW HEIGHT 1"].NextValue = (double)ObjLength14;                                       FDC_IOs.Add(VisionValues["LOW HEIGHT 1"]);
            VisionValues["LOW HEIGHT 2"].NextValue = (double)ObjLength23;                                       FDC_IOs.Add(VisionValues["LOW HEIGHT 2"]);
            VisionValues["UPPER HEIGHT 1"].NextValue = (double)TarLength14;                                     FDC_IOs.Add(VisionValues["UPPER HEIGHT 1"]);
            VisionValues["UPPER HEIGHT 2"].NextValue = (double)TarLength23;                                     FDC_IOs.Add(VisionValues["UPPER HEIGHT 2"]);
            VisionValues["LOWER ANGLE 1"].NextValue = (double)0.0;                                              FDC_IOs.Add(VisionValues["LOWER ANGLE 1"]);
            VisionValues["LOWER ANGLE 2"].NextValue = (double)0.0;                                              FDC_IOs.Add(VisionValues["LOWER ANGLE 2"]);
            VisionValues["LOWER ANGLE 3"].NextValue = (double)0.0;                                              FDC_IOs.Add(VisionValues["LOWER ANGLE 3"]);
            VisionValues["LOWER ANGLE 4"].NextValue = (double)0.0;                                              FDC_IOs.Add(VisionValues["LOWER ANGLE 4"]);
            VisionValues["UPPER ANGLE 1"].NextValue = (double)0.0;                                              FDC_IOs.Add(VisionValues["UPPER ANGLE 1"]);
            VisionValues["UPPER ANGLE 2"].NextValue = (double)0.0;                                              FDC_IOs.Add(VisionValues["UPPER ANGLE 2"]);
            VisionValues["UPPER ANGLE 3"].NextValue = (double)0.0;                                              FDC_IOs.Add(VisionValues["UPPER ANGLE 3"]);
            VisionValues["UPPER ANGLE 4"].NextValue = (double)0.0;                                              FDC_IOs.Add(VisionValues["UPPER ANGLE 4"]);
            */
            #endregion
            #endregion

            WriteVisionIO(AlgoRst, true);
            //AppendMessage(Name, "Caluration Complete");
            return true;
        }
    }
}

