﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iva.Bplus.Abstract;
using Iva.Bplus.Converter;
using Iva.Bplus.Enums;
using Iva.Bplus.Modules.CalData;
using Iva.Bplus.Modules.MitsubishiPLC;
using Iva.Bplus.Struct;
using Iva.Bplus.Interface;
using Iva.Bplus.Modules.CogDisplay;

using Cognex.VisionPro;
using Cognex.VisionPro.Dimensioning;

using System.Reflection;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;


// using OpenCvSharp;

namespace Iva.Bplus.Modules.Algo_Lami_Bended_4sides
{
    public partial class Algo_Lami_Bended_4sidesObject
    {
        private bool Pick_me_Pick_me_TapeCalc()
        {
            //cross Line의 1Point의 Theta 성분과 XY 성분으로 Align 해봅시다. 헤헤 
            #region Initialize
            model = SystemModel.GetCurModel();
            bResult = true;
            //ObjMatchingData = new MatchingRstData[1];
            ObjPointData = new IPointResult[1];
            //ObjLineData = new LineCrossRstData[1];
            ObjCalData = new CalDataObject[1];
            ObjRobotData = new XY[1];
            ObjCoordData = new XY[1];
            ObjFixData = new XY[1];
            Revision = new XYT();


            #endregion

            #region InputData Write
            //PLC Offset Data Read
            AssignPLCData_GLami();
            AlignOffset = CvtPLCIO.OffsetXYT;

            //Model Param Read
            AlgoParams modelParams;
            if (!ModelParams.TryGetValue(model, out modelParams)) return false;
            var mParams = modelParams as Pick_me_Pick_me_TapeModelParams;
            var limitX = (double)mParams.LimitX.Value;
            var limitY = (double)mParams.LimitY.Value;
            var limitT = (double)mParams.LimitT.Value;
            var Limit = new XYT(limitX, limitY, limitT);

            //connect check & Vision Result Write
            if (!InputValues.ContainsKey("Obj_P1"))
            {
                errorCode = AlgoActionBase.Err_Mark_Info_Missing;
                return false;
            }
            ObjPointData[0] = InputValues["Obj_P1"] as IPointResult;

            ObjCalData[0] = ObjPointData[0].CalData as CalDataObject;
            if(ObjCalData[0]==null)
            {
                errorCode = AlgoActionBase.Err_CalData_Is_Null;
                return false;
            }

            ObjRobotData[0] = ObjCalData[0].GetV2R(model, new XY(ObjLineData[0].OutputXYT.X, ObjLineData[0].OutputXYT.Y));
            ObjFixData[0] = ObjCalData[0].GetRotateCenter(model);
            ObjCoordData[0] = ObjFixData[0] + ObjRobotData[0];

            //Line의 Theta 성분 평균 가져 오기 2개인(세로,가로) 경우는 평균? 뭐가 좋을까... 상황에 따라 세로, 가로 상태 좋은걸 쓸까?
            double LineTheta = 0;
            int LineCnt = ObjLineData[0].Lines.Count;
            foreach(object obj in ObjLineData[0].Lines)
            {
                CogLine line = obj as CogLine;
                LineTheta += NormalizeTheta(line.Rotation);
            }
            LineTheta = LineTheta / LineCnt;

            #endregion

            #region Calc Align
            XYT TargetPos;
            if (ObjLineData[0].RefPoints.Count > 0)
            {
                TargetPos = new XYT(ObjLineData[0].RefPoints[0].X, ObjLineData[0].RefPoints[0].Y, 0);
            }
            else
                TargetPos = new XYT(0, 0, 0);

            TargetPos = ApplyTargetOffset(TargetPos, AlignOffset);

            XYT ObjectPos = new XYT(ObjCoordData[0].X, ObjCoordData[0].Y, LineTheta);

            double RadT = NormalizeTheta(TargetPos.T- ObjectPos.T);
            double DriftX = Math.Cos(RadT) * ObjectPos.X - Math.Sin(RadT) * ObjectPos.Y;
            double DriftY = Math.Sin(RadT) * ObjectPos.X + Math.Cos(RadT) * ObjectPos.Y;

            Revision.X = TargetPos.X - DriftX;
            Revision.Y = TargetPos.Y - DriftY;
            Revision.T = RadianToDegree(RadT);
            #endregion

            #region confirm Result
            if(ConfirmSpecMinMax(Revision.X, limitX * -1, limitX) ||
                ConfirmSpecMinMax(Revision.Y, limitY * -1, limitY) ||
                ConfirmSpecMinMax(Revision.T, limitT * -1, limitT))
            {
                errorCode = (int)Judgement.Tor_Exceed;
                bResult = false;
                rst = "Limit Over";
            }

            else
            {
                rst = "OK";
            }
            #endregion

            #region ResultData Update & log Write
            AlgoRst = new Pick_me_Pick_me_TapeReslut
            {
                Name = name,
                ID = sourceID,
                CurTime = DateTime.Now.ToString("HH:mm:ss"),
                CurDate = DateTime.Now.ToString("yyyy-MMM-dd(ddd)"),
                Result = rst,
                RevX = Revision.X,
                RevY = Revision.Y,
                RevT = Revision.T,
                OffsetX = AlignOffset.X,
                OffsetY = AlignOffset.Y,
                OffsetT = AlignOffset.T,
            };
            if (GridViewObject != null)
                GridViewObject.SetResult(AlgoRst);
            #endregion
            return true;
        }
    }
}

