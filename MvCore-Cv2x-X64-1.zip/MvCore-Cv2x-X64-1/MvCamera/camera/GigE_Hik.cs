﻿// Basler Camera
using Basler.Pylon;
using DirectShowLib;
using FlyCapture2Managed;
using MvCamCtrl.NET;
// OpenCv Processing
using OpenCvSharp;
using OpenCvSharp;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
// System Thread
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using SDImage = System.Drawing.Image;

namespace MvCore.CameraDevice
{
    //public delegate void grabImageHandl(Mat image);

    public class GigE_Hik : ICamDevice
    {
        
        //public static grabImageHandl eventGrapImage;
        [DllImport("kernel32.dll", EntryPoint = "RtlMoveMemory", SetLastError = false)]
        private static extern void CopyMemory(IntPtr dest, IntPtr src, uint count);

        public MyCamera Cam;
        //MyCamera.MV_CC_DEVICE_INFO_LIST m_stDeviceList = new MyCamera.MV_CC_DEVICE_INFO_LIST();
        Mat m_Image;
        private static Object BufForDriverLock = new Object();
        bool isHwTrigger = false;
        public bool IsHwTrigger
        {
            get { return isHwTrigger; }
            set
            {
                isHwTrigger = value;
                if (Cam != null)
                {
                    if (isHwTrigger)
                    {
                        //Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_SOFTWARE);
                    }
                    else
                    {
                        //Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_LINE0);
                    }
                }
            }
        }

        bool isLive = false;
        public bool IsLive
        {
            get { return isLive; }
            set
            {
                isLive = value;
                if (Cam != null)
                {
                    if (isLive == true)
                    {
                        //Cam.MV_CC_SetEnumValue_NET("TriggerMode", (uint)MyCamera.MV_CAM_TRIGGER_MODE.MV_TRIGGER_MODE_OFF);
                    }
                    else
                    {
                        //Cam.MV_CC_SetEnumValue_NET("TriggerMode", (uint)MyCamera.MV_CAM_TRIGGER_MODE.MV_TRIGGER_MODE_ON);
                        if (isHwTrigger)
                        {
                            //Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_SOFTWARE);
                        }
                        else
                        {
                            //Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_LINE0);
                        }
                    }
                }
            }
        }

        private int camIndex;
        public int CamIndex
        {
            get { return camIndex; }
            set { camIndex = value; }
        }

        private IntPtr handlPicShow;

        public IntPtr HandlPicShow
        {
            get { return handlPicShow; }
            set
            {
                handlPicShow = value;
                displayHandle = handlPicShow;
            }
        }

        bool IsGrabSuccess = false;
        bool IsGrabFail = false;

        object mLock = new object();

        static List<MyCamera.MV_CC_DEVICE_INFO> Caminfolist = new List<MyCamera.MV_CC_DEVICE_INFO>();
        static MyCamera.MV_CC_DEVICE_INFO_LIST Camlist;
        List<string> l_device = new List<string>();
        System.Diagnostics.Stopwatch stopWatch = new System.Diagnostics.Stopwatch();

        bool m_bGrabbing = false;
        Thread m_hReceiveThread = null;
        System.Drawing.Imaging.PixelFormat m_bitmapPixelFormat = System.Drawing.Imaging.PixelFormat.DontCare;
        IntPtr m_ConvertDstBuf = IntPtr.Zero;
        UInt32 m_nConvertDstBufLen = 0;
        IntPtr displayHandle = IntPtr.Zero;
        MyCamera.MV_FRAME_OUT_INFO_EX m_stFrameInfo = new MyCamera.MV_FRAME_OUT_INFO_EX();
        Bitmap m_bitmap = null;
        
        // ch:用于从驱动获取图像的缓存 | en:Buffer for getting image from driver
        UInt32 m_nBufSizeForDriver = 0;
        IntPtr m_BufForDriver = IntPtr.Zero;
        //bool grabLock = false;

        public GigE_Hik()
        {
            //// ch: 初始化 SDK | en: Initialize SDK
            //MyCamera.MV_CC_Initialize_NET();

            // ch: 枚举设备 | en: Enum Device List
            DeviceListAcq();
            //Console.WriteLine(typeof(OpenCvSharp.CvMat).Assembly.FullName);
        }

        public static Mat BitmapToMat(Bitmap bitmap)
        {
            // Xác định kiểu Mat tương ứng
            MatType matType;
            switch (bitmap.PixelFormat)
            {
                case System.Drawing.Imaging.PixelFormat.Format24bppRgb:
                    matType = MatType.CV_8UC3;
                    break;
                case System.Drawing.Imaging.PixelFormat.Format32bppArgb:
                case System.Drawing.Imaging.PixelFormat.Format32bppRgb:
                    matType = MatType.CV_8UC4;
                    break;
                case System.Drawing.Imaging.PixelFormat.Format8bppIndexed:
                    matType = MatType.CV_8UC1; // ảnh grayscale
                    break;
                default:
                    throw new Exception("Unsupported PixelFormat: " + bitmap.PixelFormat);
            }

            // Tạo Mat rỗng
            Mat mat = new Mat(bitmap.Height, bitmap.Width, matType);

            // Khóa vùng nhớ Bitmap
            BitmapData bmpData = bitmap.LockBits(
                new Rectangle(0, 0, bitmap.Width, bitmap.Height),
                ImageLockMode.ReadOnly,
                bitmap.PixelFormat);

            // Sao chép từng dòng để đảm bảo không lỗi stride
            IntPtr srcPtr = bmpData.Scan0;
            int srcStride = bmpData.Stride;

            int bytesPerPixel = SDImage.GetPixelFormatSize(bitmap.PixelFormat) / 8;

            unsafe
            {
                byte* src = (byte*)bmpData.Scan0;
                for (int y = 0; y < bitmap.Height; y++)
                {
                    byte* srcRow = src + y * bmpData.Stride;
                    byte* dstRow = (byte*)mat.Ptr(y);
                    Buffer.MemoryCopy(srcRow, dstRow, bitmap.Width * bytesPerPixel, bitmap.Width * bytesPerPixel);
                }
            }

            bitmap.UnlockBits(bmpData);

            return mat;
        }

        public static Mat Bitmap2Mat(Bitmap bitmap)
        {
            // Khóa vùng nhớ ảnh
            Rectangle rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            BitmapData bitmapData = bitmap.LockBits(rect, ImageLockMode.ReadOnly, bitmap.PixelFormat);

            // Tạo Mat tương ứng
            Mat mat;
            if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format8bppIndexed)
            {
                mat = new Mat(bitmap.Height, bitmap.Width, MatType.CV_8UC1);
            }
            else if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format24bppRgb)
            {
                mat = new Mat(bitmap.Height, bitmap.Width, MatType.CV_8UC3);
            }
            else if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format32bppArgb ||
                     bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format32bppRgb)
            {
                mat = new Mat(bitmap.Height, bitmap.Width, MatType.CV_8UC4);
            }
            else
            {
                bitmap.UnlockBits(bitmapData);
                throw new Exception($"Unsupported PixelFormat: {bitmap.PixelFormat}");
            }

            // Copy pixel từ Bitmap sang Mat
            int bytes = Math.Abs(bitmapData.Stride) * bitmap.Height;
            byte[] buffer = new byte[bytes];
            Marshal.Copy(bitmapData.Scan0, buffer, 0, bytes);

            // Ghi dữ liệu vào Mat (đúng cách)
            Marshal.Copy(buffer, 0, mat.Data, bytes);


            bitmap.UnlockBits(bitmapData);

            // Một số Bitmap lưu RGB, còn OpenCV dùng BGR → cần đảo kênh
            if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format24bppRgb)
            {
                Cv2.CvtColor(mat, mat,ColorConversionCodes.RGBA2BGR);
            }

            return mat;
        }

        public void ReceiveThreadProcess()
        {
            MyCamera.MV_FRAME_OUT stFrameInfo = new MyCamera.MV_FRAME_OUT();
            MyCamera.MV_DISPLAY_FRAME_INFO stDisplayInfo = new MyCamera.MV_DISPLAY_FRAME_INFO();
            MyCamera.MV_PIXEL_CONVERT_PARAM stConvertInfo = new MyCamera.MV_PIXEL_CONVERT_PARAM();
            int nRet = MyCamera.MV_OK;

            while (m_bGrabbing)
            {
                Console.WriteLine($"Receive Thread Process runing {camIndex}...");
                nRet = Cam.MV_CC_GetImageBuffer_NET(ref stFrameInfo, 1000);

                if (nRet == MyCamera.MV_OK)
                {
                    lock (BufForDriverLock)
                    {
                        if (m_BufForDriver == IntPtr.Zero || stFrameInfo.stFrameInfo.nFrameLen > m_nBufSizeForDriver)
                        {
                            if (m_BufForDriver != IntPtr.Zero)
                            {
                                Marshal.Release(m_BufForDriver);
                                m_BufForDriver = IntPtr.Zero;
                            }

                            m_BufForDriver = Marshal.AllocHGlobal((Int32)stFrameInfo.stFrameInfo.nFrameLen);
                            if (m_BufForDriver == IntPtr.Zero)
                            {
                                return;
                            }
                            m_nBufSizeForDriver = stFrameInfo.stFrameInfo.nFrameLen;
                        }

                        m_stFrameInfo = stFrameInfo.stFrameInfo;
                        CopyMemory(m_BufForDriver, stFrameInfo.pBufAddr, stFrameInfo.stFrameInfo.nFrameLen);

                        // ch:转换像素格式 | en:Convert Pixel Format
                        stConvertInfo.nWidth = stFrameInfo.stFrameInfo.nWidth;
                        stConvertInfo.nHeight = stFrameInfo.stFrameInfo.nHeight;
                        stConvertInfo.enSrcPixelType = stFrameInfo.stFrameInfo.enPixelType;
                        stConvertInfo.pSrcData = stFrameInfo.pBufAddr;
                        stConvertInfo.nSrcDataLen = stFrameInfo.stFrameInfo.nFrameLen;
                        stConvertInfo.pDstBuffer = m_ConvertDstBuf;
                        stConvertInfo.nDstBufferSize = m_nConvertDstBufLen;
                        if (System.Drawing.Imaging.PixelFormat.Format8bppIndexed == m_bitmap.PixelFormat)
                        {
                            stConvertInfo.enDstPixelType = MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono8;
                            Cam.MV_CC_ConvertPixelType_NET(ref stConvertInfo);
                        }
                        else
                        {
                            stConvertInfo.enDstPixelType = MyCamera.MvGvspPixelType.PixelType_Gvsp_BGR8_Packed;
                            Cam.MV_CC_ConvertPixelType_NET(ref stConvertInfo);
                        }

                        // ch:保存Bitmap数据 | en:Save Bitmap Data
                        BitmapData bitmapData = m_bitmap.LockBits(new Rectangle(0, 0, stConvertInfo.nWidth, stConvertInfo.nHeight), ImageLockMode.ReadWrite, m_bitmap.PixelFormat);
                        CopyMemory(bitmapData.Scan0, stConvertInfo.pDstBuffer, (UInt32)(bitmapData.Stride * m_bitmap.Height));
                        m_bitmap.UnlockBits(bitmapData);
                        Mat src = Bitmap2Mat(m_bitmap);
                       
                        m_Image = src.Clone();
                        IsGrabSuccess = true;
                        //eventGrapImage?.Invoke(Image);

                        //Cv2.CvtColor(src, src, ColorConversion.GrayToBgr);
                        //Cv2.Resize(Image, Image, new OpenCvSharp.CPlusPlus.Size(951, 540));
                        //Cv2.ImShow("src", Image);
                        //Cv2.WaitKey(100);



                    }

                    stDisplayInfo.hWnd = displayHandle;
                    stDisplayInfo.pData = stFrameInfo.pBufAddr;
                    stDisplayInfo.nDataLen = stFrameInfo.stFrameInfo.nFrameLen;
                    stDisplayInfo.nWidth = stFrameInfo.stFrameInfo.nWidth;
                    stDisplayInfo.nHeight = stFrameInfo.stFrameInfo.nHeight;
                    stDisplayInfo.enPixelType = stFrameInfo.stFrameInfo.enPixelType;
                    Cam.MV_CC_DisplayOneFrame_NET(ref stDisplayInfo);

                    Cam.MV_CC_FreeImageBuffer_NET(ref stFrameInfo);
                }
                else
                {
                    //if (bnTriggerMode.Checked)
                    //{
                    Thread.Sleep(5);
                    //}
                }
            }
        }

        private void ShowErrorMsg(string csMessage, int nErrorNum)
        {
            string errorMsg;
            if (nErrorNum == 0)
            {
                errorMsg = csMessage;
            }
            else
            {
                errorMsg = csMessage + ": Error =" + String.Format("{0:X}", nErrorNum);
            }

            switch (nErrorNum)
            {
                case MyCamera.MV_E_HANDLE: errorMsg += " Error or invalid handle "; break;
                case MyCamera.MV_E_SUPPORT: errorMsg += " Not supported function "; break;
                case MyCamera.MV_E_BUFOVER: errorMsg += " Cache is full "; break;
                case MyCamera.MV_E_CALLORDER: errorMsg += " Function calling order error "; break;
                case MyCamera.MV_E_PARAMETER: errorMsg += " Incorrect parameter "; break;
                case MyCamera.MV_E_RESOURCE: errorMsg += " Applying resource failed "; break;
                case MyCamera.MV_E_NODATA: errorMsg += " No data "; break;
                case MyCamera.MV_E_PRECONDITION: errorMsg += " Precondition error, or running environment changed "; break;
                case MyCamera.MV_E_VERSION: errorMsg += " Version mismatches "; break;
                case MyCamera.MV_E_NOENOUGH_BUF: errorMsg += " Insufficient memory "; break;
                case MyCamera.MV_E_UNKNOW: errorMsg += " Unknown error "; break;
                case MyCamera.MV_E_GC_GENERIC: errorMsg += " General error "; break;
                case MyCamera.MV_E_GC_ACCESS: errorMsg += " Node accessing condition error "; break;
                case MyCamera.MV_E_ACCESS_DENIED: errorMsg += " No permission "; break;
                case MyCamera.MV_E_BUSY: errorMsg += " Device is busy, or network disconnected "; break;
                case MyCamera.MV_E_NETER: errorMsg += " Network error "; break;
            }

            MessageBox.Show(errorMsg, "PROMPT");
        }
        private string DeleteTail(string strUserDefinedName)
        {
            strUserDefinedName = Regex.Unescape(strUserDefinedName);
            int nIndex = strUserDefinedName.IndexOf("\0");
            if (nIndex >= 0)
            {
                strUserDefinedName = strUserDefinedName.Remove(nIndex);
            }

            return strUserDefinedName;
        }

        //version MVS 4.5.1 
        //private void DeviceListAcq()
        //{
        //    Caminfolist.Clear();
        //    // ch:创建设备列表 | en:Create Device List
        //    System.GC.Collect();
        //    l_device.Clear();
        //    Camlist.nDeviceNum = 0;
        //    //这里枚举了所有类型，根据实际情况，选择合适的枚举类型即可
        //    int nRet = MyCamera.MV_CC_EnumDevices_NET(MyCamera.MV_GIGE_DEVICE | MyCamera.MV_USB_DEVICE | MyCamera.MV_GENTL_GIGE_DEVICE
        //        | MyCamera.MV_GENTL_CAMERALINK_DEVICE | MyCamera.MV_GENTL_CXP_DEVICE | MyCamera.MV_GENTL_XOF_DEVICE, ref Camlist);
        //    if (0 != nRet)
        //    {
        //        ShowErrorMsg("Enumerate devices fail!", 0);
        //        return;
        //    }

        //    // ch:在窗体列表中显示设备名 | en:Display device name in the form list
        //    for (int i = 0; i < Camlist.nDeviceNum; i++)
        //    {
        //        MyCamera.MV_CC_DEVICE_INFO device = (MyCamera.MV_CC_DEVICE_INFO)Marshal.PtrToStructure(Camlist.pDeviceInfo[i], typeof(MyCamera.MV_CC_DEVICE_INFO));
        //        Caminfolist.Add(device);
        //        string strUserDefinedName = "";
        //        if (device.nTLayerType == MyCamera.MV_GIGE_DEVICE)
        //        {
        //            MyCamera.MV_GIGE_DEVICE_INFO_EX gigeInfo = (MyCamera.MV_GIGE_DEVICE_INFO_EX)MyCamera.ByteToStruct(device.SpecialInfo.stGigEInfo, typeof(MyCamera.MV_GIGE_DEVICE_INFO_EX));

        //            if ((gigeInfo.chUserDefinedName.Length > 0) && (gigeInfo.chUserDefinedName[0] != '\0'))
        //            {
        //                if (MyCamera.IsTextUTF8(gigeInfo.chUserDefinedName))
        //                {
        //                    strUserDefinedName = Encoding.UTF8.GetString(gigeInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                else
        //                {
        //                    strUserDefinedName = Encoding.Default.GetString(gigeInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                l_device.Add("GEV: " + DeleteTail(strUserDefinedName) + " (" + gigeInfo.chSerialNumber + ")");
        //            }
        //            else
        //            {
        //                l_device.Add("GEV: " + gigeInfo.chManufacturerName + " " + gigeInfo.chModelName + " (" + gigeInfo.chSerialNumber + ")");
        //            }
        //        }
        //        else if (device.nTLayerType == MyCamera.MV_USB_DEVICE)
        //        {
        //            MyCamera.MV_USB3_DEVICE_INFO_EX usbInfo = (MyCamera.MV_USB3_DEVICE_INFO_EX)MyCamera.ByteToStruct(device.SpecialInfo.stUsb3VInfo, typeof(MyCamera.MV_USB3_DEVICE_INFO_EX));

        //            if ((usbInfo.chUserDefinedName.Length > 0) && (usbInfo.chUserDefinedName[0] != '\0'))
        //            {
        //                if (MyCamera.IsTextUTF8(usbInfo.chUserDefinedName))
        //                {
        //                    strUserDefinedName = Encoding.UTF8.GetString(usbInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                else
        //                {
        //                    strUserDefinedName = Encoding.Default.GetString(usbInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                l_device.Add("U3V: " + DeleteTail(strUserDefinedName) + " (" + usbInfo.chSerialNumber + ")");
        //            }
        //            else
        //            {
        //                l_device.Add("U3V: " + usbInfo.chManufacturerName + " " + usbInfo.chModelName + " (" + usbInfo.chSerialNumber + ")");
        //            }
        //        }
        //        else if (device.nTLayerType == MyCamera.MV_GENTL_CAMERALINK_DEVICE)
        //        {
        //            MyCamera.MV_CML_DEVICE_INFO CMLInfo = (MyCamera.MV_CML_DEVICE_INFO)MyCamera.ByteToStruct(device.SpecialInfo.stCMLInfo, typeof(MyCamera.MV_CML_DEVICE_INFO));

        //            if ((CMLInfo.chUserDefinedName.Length > 0) && (CMLInfo.chUserDefinedName[0] != '\0'))
        //            {
        //                if (MyCamera.IsTextUTF8(CMLInfo.chUserDefinedName))
        //                {
        //                    strUserDefinedName = Encoding.UTF8.GetString(CMLInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                else
        //                {
        //                    strUserDefinedName = Encoding.Default.GetString(CMLInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                l_device.Add("CML: " + DeleteTail(strUserDefinedName) + " (" + CMLInfo.chSerialNumber + ")");
        //            }
        //            else
        //            {
        //                l_device.Add("CML: " + CMLInfo.chManufacturerInfo + " " + CMLInfo.chModelName + " (" + CMLInfo.chSerialNumber + ")");
        //            }
        //        }
        //        else if (device.nTLayerType == MyCamera.MV_GENTL_CXP_DEVICE)
        //        {
        //            MyCamera.MV_CXP_DEVICE_INFO CXPInfo = (MyCamera.MV_CXP_DEVICE_INFO)MyCamera.ByteToStruct(device.SpecialInfo.stCXPInfo, typeof(MyCamera.MV_CXP_DEVICE_INFO));

        //            if ((CXPInfo.chUserDefinedName.Length > 0) && (CXPInfo.chUserDefinedName[0] != '\0'))
        //            {
        //                if (MyCamera.IsTextUTF8(CXPInfo.chUserDefinedName))
        //                {
        //                    strUserDefinedName = Encoding.UTF8.GetString(CXPInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                else
        //                {
        //                    strUserDefinedName = Encoding.Default.GetString(CXPInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                l_device.Add("CXP: " + DeleteTail(strUserDefinedName) + " (" + CXPInfo.chSerialNumber + ")");
        //            }
        //            else
        //            {
        //                l_device.Add("CXP: " + CXPInfo.chManufacturerInfo + " " + CXPInfo.chModelName + " (" + CXPInfo.chSerialNumber + ")");
        //            }
        //        }
        //        else if (device.nTLayerType == MyCamera.MV_GENTL_XOF_DEVICE)
        //        {
        //            MyCamera.MV_XOF_DEVICE_INFO XOFInfo = (MyCamera.MV_XOF_DEVICE_INFO)MyCamera.ByteToStruct(device.SpecialInfo.stXoFInfo, typeof(MyCamera.MV_XOF_DEVICE_INFO));

        //            if ((XOFInfo.chUserDefinedName.Length > 0) && (XOFInfo.chUserDefinedName[0] != '\0'))
        //            {
        //                if (MyCamera.IsTextUTF8(XOFInfo.chUserDefinedName))
        //                {
        //                    strUserDefinedName = Encoding.UTF8.GetString(XOFInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                else
        //                {
        //                    strUserDefinedName = Encoding.Default.GetString(XOFInfo.chUserDefinedName).TrimEnd('\0');
        //                }
        //                l_device.Add("XOF: " + DeleteTail(strUserDefinedName) + " (" + XOFInfo.chSerialNumber + ")");
        //            }
        //            else
        //            {
        //                l_device.Add("XOF: " + XOFInfo.chManufacturerInfo + " " + XOFInfo.chModelName + " (" + XOFInfo.chSerialNumber + ")");
        //            }
        //        }
        //    }

        //    // ch:选择第一项 | en:Select the first item
        //    if (Camlist.nDeviceNum != 0)
        //    {
        //        //cbDeviceList.SelectedIndex = 0;
        //    }
        //}


        //version MVS 4.0.0 SDK 4.0.0.5
        private void DeviceListAcq()
        {
            Caminfolist.Clear();
            // ch:创建设备列表 | en:Create Device List
            System.GC.Collect();
            l_device.Clear();
            Camlist.nDeviceNum = 0;


            // ch:创建设备列表 | en:Create Device List
            System.GC.Collect();
            l_device.Clear();
            Camlist.nDeviceNum = 0;
            int nRet = MyCamera.MV_CC_EnumDevices_NET(MyCamera.MV_GIGE_DEVICE | MyCamera.MV_USB_DEVICE, ref Camlist);
            if (0 != nRet)
            {
                ShowErrorMsg("Enumerate devices fail!", 0);
                return;
            }

            // ch:在窗体列表中显示设备名 | en:Display device name in the form list
            for (int i = 0; i < Camlist.nDeviceNum; i++)
            {
                MyCamera.MV_CC_DEVICE_INFO device = (MyCamera.MV_CC_DEVICE_INFO)Marshal.PtrToStructure(Camlist.pDeviceInfo[i], typeof(MyCamera.MV_CC_DEVICE_INFO));
                Caminfolist.Add(device);
                if (device.nTLayerType == MyCamera.MV_GIGE_DEVICE)
                {
                    MyCamera.MV_GIGE_DEVICE_INFO gigeInfo = (MyCamera.MV_GIGE_DEVICE_INFO)MyCamera.ByteToStruct(device.SpecialInfo.stGigEInfo, typeof(MyCamera.MV_GIGE_DEVICE_INFO));

                    if (gigeInfo.chUserDefinedName != "")
                    {
                        l_device.Add("GEV: " + gigeInfo.chUserDefinedName + " (" + gigeInfo.chSerialNumber + ")");
                    }
                    else
                    {
                        l_device.Add("GEV: " + gigeInfo.chManufacturerName + " " + gigeInfo.chModelName + " (" + gigeInfo.chSerialNumber + ")");
                    }
                }
                else if (device.nTLayerType == MyCamera.MV_USB_DEVICE)
                {
                    MyCamera.MV_USB3_DEVICE_INFO usbInfo = (MyCamera.MV_USB3_DEVICE_INFO)MyCamera.ByteToStruct(device.SpecialInfo.stUsb3VInfo, typeof(MyCamera.MV_USB3_DEVICE_INFO));
                    if (usbInfo.chUserDefinedName != "")
                    {
                        l_device.Add("U3V: " + usbInfo.chUserDefinedName + " (" + usbInfo.chSerialNumber + ")");
                    }
                    else
                    {
                        l_device.Add("U3V: " + usbInfo.chManufacturerName + " " + usbInfo.chModelName + " (" + usbInfo.chSerialNumber + ")");
                    }
                }
            }

            // ch:选择第一项 | en:Select the first item
            if (Camlist.nDeviceNum != 0)
            {
                //l_device.SelectedIndex = 0;
            }
        }

        // ch:像素类型是否为Mono格式 | en:If Pixel Type is Mono 
        private Boolean IsMono(UInt32 enPixelType)
        {
            switch (enPixelType)
            {
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono1p:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono2p:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono4p:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono8:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono8_Signed:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono10:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono10_Packed:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono12:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono12_Packed:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono14:
                case (UInt32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Mono16:
                    return true;
                default:
                    return false;
            }
        }

        // ch:取图前的必要操作步骤 | en:Necessary operation before grab
        private Int32 NecessaryOperBeforeGrab()
        {
            // ch:取图像宽 | en:Get Iamge Width
            MyCamera.MVCC_INTVALUE_EX stWidth = new MyCamera.MVCC_INTVALUE_EX();
            int nRet = Cam.MV_CC_GetIntValueEx_NET("Width", ref stWidth);
            if (MyCamera.MV_OK != nRet)
            {
                ShowErrorMsg("Get Width Info Fail!", nRet);
                return nRet;
            }
            // ch:取图像高 | en:Get Iamge Height
            MyCamera.MVCC_INTVALUE_EX stHeight = new MyCamera.MVCC_INTVALUE_EX();
            nRet = Cam.MV_CC_GetIntValueEx_NET("Height", ref stHeight);
            if (MyCamera.MV_OK != nRet)
            {
                ShowErrorMsg("Get Height Info Fail!", nRet);
                return nRet;
            }
            // ch:取像素格式 | en:Get Pixel Format
            MyCamera.MVCC_ENUMVALUE stPixelFormat = new MyCamera.MVCC_ENUMVALUE();
            nRet = Cam.MV_CC_GetEnumValue_NET("PixelFormat", ref stPixelFormat);
            if (MyCamera.MV_OK != nRet)
            {
                ShowErrorMsg("Get Pixel Format Fail!", nRet);
                return nRet;
            }

            // ch:设置bitmap像素格式，申请相应大小内存 | en:Set Bitmap Pixel Format, alloc memory
            if ((Int32)MyCamera.MvGvspPixelType.PixelType_Gvsp_Undefined == (Int32)stPixelFormat.nCurValue)
            {
                ShowErrorMsg("Unknown Pixel Format!", MyCamera.MV_E_UNKNOW);
                return MyCamera.MV_E_UNKNOW;
            }
            else if (IsMono(stPixelFormat.nCurValue))
            {
                m_bitmapPixelFormat = System.Drawing.Imaging.PixelFormat.Format8bppIndexed;

                if (IntPtr.Zero != m_ConvertDstBuf)
                {
                    Marshal.Release(m_ConvertDstBuf);
                    m_ConvertDstBuf = IntPtr.Zero;
                }

                // Mono8为单通道
                m_nConvertDstBufLen = (UInt32)(stWidth.nCurValue * stHeight.nCurValue);
                m_ConvertDstBuf = Marshal.AllocHGlobal((Int32)m_nConvertDstBufLen);
                if (IntPtr.Zero == m_ConvertDstBuf)
                {
                    ShowErrorMsg("Malloc Memory Fail!", MyCamera.MV_E_RESOURCE);
                    return MyCamera.MV_E_RESOURCE;
                }
            }
            else
            {
                m_bitmapPixelFormat = System.Drawing.Imaging.PixelFormat.Format24bppRgb;

                if (IntPtr.Zero != m_ConvertDstBuf)
                {
                    Marshal.FreeHGlobal(m_ConvertDstBuf);
                    m_ConvertDstBuf = IntPtr.Zero;
                }

                // RGB为三通道
                m_nConvertDstBufLen = (UInt32)(3 * stWidth.nCurValue * stHeight.nCurValue);
                m_ConvertDstBuf = Marshal.AllocHGlobal((Int32)m_nConvertDstBufLen);
                if (IntPtr.Zero == m_ConvertDstBuf)
                {
                    ShowErrorMsg("Malloc Memory Fail!", MyCamera.MV_E_RESOURCE);
                    return MyCamera.MV_E_RESOURCE;
                }
            }

            // 确保释放保存了旧图像数据的bitmap实例，用新图像宽高等信息new一个新的bitmap实例
            if (null != m_bitmap)
            {
                m_bitmap.Dispose();
                m_bitmap = null;
            }
            m_bitmap = new Bitmap((Int32)stWidth.nCurValue, (Int32)stHeight.nCurValue, m_bitmapPixelFormat);

            // ch:Mono8格式，设置为标准调色板 | en:Set Standard Palette in Mono8 Format
            if (System.Drawing.Imaging.PixelFormat.Format8bppIndexed == m_bitmapPixelFormat)
            {
                ColorPalette palette = m_bitmap.Palette;
                for (int i = 0; i < palette.Entries.Length; i++)
                {
                    palette.Entries[i] = Color.FromArgb(i, i, i);
                }
                m_bitmap.Palette = palette;
            }

            return MyCamera.MV_OK;
        }
        public void StartGrab()
        {
            // ch:前置配置 | en:pre-operation
            int nRet = NecessaryOperBeforeGrab();
            if (MyCamera.MV_OK != nRet)
            {
                return;
            }

            displayHandle = HandlPicShow;

            // ch:标志位置true | en:Set position bit true
            m_bGrabbing = true;

            m_stFrameInfo.nFrameLen = 0;//取流之前先清除帧长度
            m_stFrameInfo.enPixelType = MyCamera.MvGvspPixelType.PixelType_Gvsp_Undefined;

            m_hReceiveThread = new Thread(ReceiveThreadProcess);
            m_hReceiveThread.Start();

            // ch:开始采集 | en:Start Grabbing
            nRet = Cam.MV_CC_StartGrabbing_NET();
            if (MyCamera.MV_OK != nRet)
            {
                m_bGrabbing = false;
                m_hReceiveThread.Join();
                ShowErrorMsg("Start Grabbing Fail!", nRet);
                return;
            }

            // ch:控件操作 | en:Control Operation
            //SetCtrlWhenStartGrab();
        }

        private void getParam()
        {
            MyCamera.MVCC_FLOATVALUE stParam = new MyCamera.MVCC_FLOATVALUE();
            int nRet = Cam.MV_CC_GetFloatValue_NET("ExposureTime", ref stParam);
            if (MyCamera.MV_OK == nRet)
            {
                string tbExposure = stParam.fCurValue.ToString("F1");
                mExposureTime = stParam.fCurValue;
            }

            nRet = Cam.MV_CC_GetFloatValue_NET("Gain", ref stParam);
            if (MyCamera.MV_OK == nRet)
            {
                string tbGain = stParam.fCurValue.ToString("F1");
                mGainTime = stParam.fCurValue;
            }

            //nRet = Cam.MV_CC_GetFloatValue_NET("ResultingFrameRate", ref stParam);
            //if (MyCamera.MV_OK == nRet)
            //{
            //    string tbFrameRate = stParam.fCurValue.ToString("F1");
            //}
        }
        private void SetParam_Click()
        {
            try
            {
                float.Parse(ExposureTime.ToString());
                float.Parse(GainTime.ToString());
                //float.Parse(tbFrameRate.Text);
            }
            catch
            {
                ShowErrorMsg("Please enter correct type!", 0);
                return;
            }

            Cam.MV_CC_SetEnumValue_NET("ExposureAuto", 0);
            int nRet = Cam.MV_CC_SetFloatValue_NET("ExposureTime", float.Parse(ExposureTime.ToString()));
            if (nRet != MyCamera.MV_OK)
            {
                ShowErrorMsg("Set Exposure Time Fail!", nRet);
            }

            Cam.MV_CC_SetEnumValue_NET("GainAuto", 0);
            nRet = Cam.MV_CC_SetFloatValue_NET("Gain", float.Parse(GainTime.ToString()));
            if (nRet != MyCamera.MV_OK)
            {
                ShowErrorMsg("Set Gain Fail!", nRet);
            }

            //nRet = Cam.MV_CC_SetFloatValue_NET("AcquisitionFrameRate", float.Parse(0.ToString()));
            //if (nRet != MyCamera.MV_OK)
            //{
            //    ShowErrorMsg("Set Frame Rate Fail!", nRet);
            //}
        }
        private void openDevice(int index)
        {
            if (Camlist.nDeviceNum == 0 || index == -1)
            {
                ShowErrorMsg("No device, please select", 0);
                return;
            }

            // ch:获取选择的设备信息 | en:Get selected device information
            MyCamera.MV_CC_DEVICE_INFO device =
                (MyCamera.MV_CC_DEVICE_INFO)Marshal.PtrToStructure(Camlist.pDeviceInfo[index], typeof(MyCamera.MV_CC_DEVICE_INFO));

            // ch:打开设备 | en:Open device
            if (null == Cam)
            {
                Cam = new MyCamera();
                if (null == Cam)
                {
                    ShowErrorMsg("Applying resource fail!", MyCamera.MV_E_RESOURCE);
                    return;
                }
            }

            int nRet = Cam.MV_CC_CreateDevice_NET(ref device);
            if (MyCamera.MV_OK != nRet)
            {
                ShowErrorMsg("Create device fail!", nRet);
                return;
            }

            nRet = Cam.MV_CC_OpenDevice_NET();
            if (MyCamera.MV_OK != nRet)
            {
                Cam.MV_CC_DestroyDevice_NET();
                ShowErrorMsg("Device open fail!", nRet);
                return;
            }

            // ch:探测网络最佳包大小(只对GigE相机有效) | en:Detection network optimal package size(It only works for the GigE camera)
            if (device.nTLayerType == MyCamera.MV_GIGE_DEVICE)
            {
                int nPacketSize = Cam.MV_CC_GetOptimalPacketSize_NET();
                if (nPacketSize > 0)
                {
                    nRet = Cam.MV_CC_SetIntValueEx_NET("GevSCPSPacketSize", nPacketSize);
                    if (nRet != MyCamera.MV_OK)
                    {
                        ShowErrorMsg("Set Packet Size failed!", nRet);
                    }
                }
                else
                {
                    //ShowErrorMsg("Get Packet Size failed!", nPacketSize);
                }
            }

            // ch:设置采集连续模式 | en:Set Continues Aquisition Mode
            //Cam.MV_CC_SetEnumValue_NET("AcquisitionMode", (uint)MyCamera.MV_CAM_ACQUISITION_MODE.MV_ACQ_MODE_CONTINUOUS);
            //Cam.MV_CC_SetEnumValue_NET("TriggerMode", (uint)MyCamera.MV_CAM_TRIGGER_MODE.MV_TRIGGER_MODE_OFF);

            Cam.MV_CC_SetEnumValue_NET("TriggerMode", (uint)MyCamera.MV_CAM_TRIGGER_MODE.MV_TRIGGER_MODE_ON);
            Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_SOFTWARE);
            Console.WriteLine($"Open Device {index}");
            //bnGetParam_Click(null, null);// ch:获取参数 | en:Get parameters
            //getParam();
            StartGrab();
            //// ch:控件操作 | en:Control operation
            //SetCtrlWhenOpen();

        }

        private void closeDevice()
        {
            // ch:取流标志位清零 | en:Reset flow flag bit
            if (m_bGrabbing == true)
            {
                m_bGrabbing = false;
                m_hReceiveThread.Join();
            }

            if (m_BufForDriver != IntPtr.Zero)
            {
                Marshal.Release(m_BufForDriver);
            }

            if (Cam != null)
            {
                // ch:关闭设备 | en:Close Device
                Cam.MV_CC_CloseDevice_NET();
                Cam.MV_CC_DestroyDevice_NET();
            }

            // ch:控件操作 | en:Control Operation
            //SetCtrlWhenClose();
        }

        private void InitializeCamera()
        {
            // DeSerialize를 통해 파일을 읽어들일 경우를 대비해서 기존 열린 Camera를 다 닫아준다.
            //if (Camlist == null)
            //    Camlist = new List<ICamera>();
            //else
            //{
            //    if (Caminfolist == CameraFinder.Enumerate())
            //        return;
            //    foreach (ICamera cam in Camlist)
            //    {
            //        //if (cam.StreamGrabber.IsGrabbing) cam.StreamGrabber.Stop();
            //        cam.Close();
            //        cam.Dispose();
            //    }
            //    Camlist.Clear();
            //}
            //Caminfolist = CameraFinder.Enumerate();
        }

        public void AcqusitionStart()
        {
            //StartGrab();
            //Cam.StreamGrabber.Start(GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);

            //// Execute the software trigger. Wait up to 100 ms until the camera is ready for trigger.
            //if (Cam.WaitForFrameTriggerReady(100, TimeoutHandling.ThrowException))
            //{
            //    Cam.ExecuteSoftwareTrigger();
            //}
        }

        public void AcqusitionStop()
        {
            closeDevice();
            //Cam.StreamGrabber.Stop();
        }

        public void CameraClose()
        {
            //if (Cam == null) return;
            //if (Cam.StreamGrabber != null)
            //    Cam.StreamGrabber.Stop();
            //Cam.Close();
            // ch:取流标志位清零 | en:Reset flow flag bit
            if (m_bGrabbing == true)
            {
                m_bGrabbing = false;
                m_hReceiveThread.Join();
            }

            if (m_BufForDriver != IntPtr.Zero)
            {
                Marshal.Release(m_BufForDriver);
            }

            if (Cam != null)
            {
                // ch:关闭设备 | en:Close Device
                Cam.MV_CC_CloseDevice_NET();
                Cam.MV_CC_DestroyDevice_NET();
                Cam = null;
            }

            // ch:控件操作 | en:Control Operation
            //SetCtrlWhenClose();
        }

        public void CameraOpen(int camNumber)
        {
            //if (camNumber < 0 || camNumber >= Caminfolist.Count) return;

            //// 동일한 Job을 두 Thread에서 호출할 경우를 대비
            //// Cam이 Static으로 되어있다보니... 이벤트 등록을 카메라 Instance 별로 연결해 줘야 동작함

            //CamIndex = camNumber;

            //int index = Camlist.FindIndex(ss => Caminfolist[CamIndex]["SerialNumber"] == ss.CameraInfo["SerialNumber"]);

            //// 아직 만든적이 없으면...
            //if (index < 0)
            //{
            //    Cam = new Camera(Caminfolist[CamIndex]);
            //    Camlist.Add(Cam);
            //}
            //else
            //    Cam = Camlist[index] as Camera;

            //Cam.StreamGrabber.ImageGrabbed -= OnImageGrabbed;
            //Cam.ConnectionLost -= Cam_ConnectionLost;
            //Cam.StreamGrabber.ImageGrabbed += OnImageGrabbed;
            //Cam.ConnectionLost += Cam_ConnectionLost;

            //if (!Cam.IsOpen)
            //    Cam.Open();
            //if (Cam == null)
            //{
            //    openDevice(camNumber);
            //    StartGrab();
            //}
            if (Cam == null)
            {
                openDevice(camNumber);
            }


        }

        public void Run()
        {
            //if (Cam == null)
            //{
            //    openDevice(camIndex);
            //    StartGrab();
            //}else if (isLive == false && IsHwTrigger == true)
            //{
            //    //GrabImage();
            //}
        }

        public string GetCameraSeiralNo()
        {
            return GetCameraSeiralNo(CamIndex);
        }

        public string GetCameraSeiralNo(int camNumber)
        {
            if (Caminfolist == null) return null;
            if (Caminfolist.Count <= camNumber) return null;
            //selectDevice(camNumber);
            return l_device[camNumber];
        }

        private void Cam_ConnectionLost(object sender, EventArgs e)
        {
            CameraClose();
            Thread.Sleep(100);
            //CameraOpen(CamIndex);
        }

        public int GetConnectedCamCount()
        {
            return Caminfolist.Count;
        }

        void OnImageGrabbed(Object sender, ImageGrabbedEventArgs e)
        {
            try
            {
                // Get the grab result.
                IGrabResult grabResult = e.GrabResult;

                // Check if the image can be displayed.
                if (grabResult.IsValid)
                {
                    byte[] buffer = grabResult.PixelData as byte[];
                   // m_Image = new Mat((int)grabResult.Height, (int)grabResult.Width, MatType.CV_8UC1, /*(Array)*/grabResult.PixelData as byte[]);
                    m_Image = new Mat((int)grabResult.Height, (int)grabResult.Width, MatType.CV_8UC1);
                    m_Image.SetArray(grabResult.PixelData as byte[]);
                    IsGrabSuccess = true;
                }
            }
            catch (Exception exception)
            {
                IsGrabFail = true;
                //ShowException(exception);
            }
            finally
            {
                // Dispose the grab result if needed for returning it to the grab loop.
                e.DisposeGrabResultIfClone();
            }
        }

        public float ExposureTime
        {
            get
            {
                MyCamera.MVCC_FLOATVALUE stParam = new MyCamera.MVCC_FLOATVALUE();
                int nRet = Cam.MV_CC_GetFloatValue_NET("ExposureTime", ref stParam);
                if (MyCamera.MV_OK == nRet)
                {
                    string tbExposure = stParam.fCurValue.ToString("F1");
                    return mExposureTime = stParam.fCurValue;
                }
                return -1;
            }
            set
             {
                if (mExposureTime == value) return;
                mExposureTime = value;
                Cam.MV_CC_SetEnumValue_NET("ExposureAuto", 0);
                int nRet = Cam.MV_CC_SetFloatValue_NET("ExposureTime", float.Parse(mExposureTime.ToString()));
                if (nRet != MyCamera.MV_OK)
                {
                    ShowErrorMsg("Set Exposure Time Fail!", nRet);
                }
                



                //Cam.setStreamGrabber.UserData[.["ExposureTime"] = value;
            }
        }
        float mExposureTime;

        public float GainTime
        {
            get
            {
                MyCamera.MVCC_FLOATVALUE stParam = new MyCamera.MVCC_FLOATVALUE();
                int nRet = Cam.MV_CC_GetFloatValue_NET("Gain", ref stParam);
                nRet = Cam.MV_CC_GetFloatValue_NET("Gain", ref stParam);
                if (MyCamera.MV_OK == nRet)
                {
                    string tbGain = stParam.fCurValue.ToString("F1");
                    return mGainTime = stParam.fCurValue;
                }
                return -1;
            }
            set
            {
                if (mGainTime == value) return;
                mGainTime = value;
                Cam.MV_CC_SetEnumValue_NET("GainAuto", 0);
                int nRet = Cam.MV_CC_SetFloatValue_NET("Gain", float.Parse(mGainTime.ToString()));
                if (nRet != MyCamera.MV_OK)
                {
                    ShowErrorMsg("Set Gain Fail!", nRet);
                }
                
            }
        }
        float mGainTime;


        public int BeforeGrabDelay { get; set; }
        int mBeforeGrabDelay;

        public Mat QueryFrame()
        {
            throw new NotImplementedException();
        }

        public void ShowControlDialog()
        {
            throw new NotImplementedException();
        }

        public float Getfps()
        {
            throw new NotImplementedException();
        }

        protected virtual void Dispose(bool disposing)
        {
            //if (Cam == null) return;
            //if (Cam.IsOpen) Cam.Close();
            //Cam.Dispose();
        }

        public void Dispose()
        {
            // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
            Dispose(true);
            // TODO: 위의 종료자가 재정의된 경우 다음 코드 줄의 주석 처리를 제거합니다.
            // GC.SuppressFinalize(this);
        }

        public Mat GrabImage()
        {
            lock (mLock)
            {
                try
                {
                    if (Cam == null) return null;

                    // Delay
                    DateTime startTime = DateTime.Now;
                    while (DateTime.Now.Subtract(startTime).TotalMilliseconds < BeforeGrabDelay)
                    {
                        System.Threading.Thread.Sleep(1);
                    }

                    IsGrabFail = false;
                    IsGrabSuccess = false;

                    //if (Cam.StreamGrabber.IsGrabbing)
                    //{
                    //    Cam.StreamGrabber.Stop();
                    //    Thread.Sleep(500);
                    //}
                    //Cam.Parameters[PLCamera.AcquisitionMode].SetValue(PLCamera.AcquisitionMode.SingleFrame);
                    //Cam.StreamGrabber.Start(1, GrabStrategy.LatestImages, GrabLoop.ProvidedByStreamGrabber);
                    //if (isLive == false)
                    //{

                    int nRet = Cam.MV_CC_SetCommandValue_NET("TriggerSoftware");
                    if (MyCamera.MV_OK != nRet)
                    {
                        ShowErrorMsg("Trigger Software Fail!", nRet);
                        return null;
                    }
                    //IsGrabSuccess = true;
                    //}
                    stopWatch.Reset();
                    stopWatch.Start();
                    while (true)
                    {
                        //while (grapLock == false)
                        //{
                        //    Thread.Sleep(10);
                        //    if (stopWatch.ElapsedMilliseconds > 2000) return null;
                        //}
                        if (IsGrabSuccess)
                        {
                            lock (BufForDriverLock)
                            {
                                return m_Image; // daviddang 
                            }
                        }
                           
                        if (IsGrabFail) break;
                        if (stopWatch.ElapsedMilliseconds > 2000) break;
                        Thread.Sleep(10);
                    }
                    // Error 처리 추가할 것
                    return null;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    return null;
                }
            }
        }

        public bool FlushBuffer()
        {
            return true;
        }
    }
}