﻿using System;
//using System.Windows.Forms;
using NeptuneClassLibWrap;
using OpenCvSharp;
using System.Threading.Tasks;
using System.Threading;
using System.Runtime.InteropServices;
using OpenCvSharp;
using MvCore.Common;
using System.Collections.Generic;

namespace MvCore.CameraDevice
{
    public class GigE_IMITech : ICamDevice
    {
        static NeptuneClassLibCLR neptuneClass = null;
        static CameraInstance[] cameraInstance = null;

        const uint openTimeout = 5000;
        const uint grabTimeout = 500;
        const uint queryTimeout = 250;
        uint camTotalCount;

        FrameDataPtr frameData = new FrameDataPtr();

        //2016-01-14 IMI-Tech : Grab flag
        //bool isGrab = false;
        //bool isAcq = false;
        object AcquisitionLock = new object();

        NEPTUNE_IMAGE_SIZE maxSize = new NEPTUNE_IMAGE_SIZE();
        NEPTUNE_CAM_INFO[] pinfo = null;

        //ENeptuneAcquisitionMode mode = ENeptuneAcquisitionMode.NEPTUNE_ACQ_CONTINUOUS;

        Mat image = null;
        //2016-01-14 IMI-Tech : Grab Matrix    
        Mat imageGrab = null;

        //uint camIndex;
        float rcvFrameRate = 5f;

        bool isHwTrigger = false;
        public bool IsHwTrigger
        {
            get
            {
                return isHwTrigger;
            }
            set
            {
                isHwTrigger = value;
                NEPTUNE_TRIGGER trigger = new NEPTUNE_TRIGGER();
                cameraInstance[camIndex].GetTrigger(ref trigger);

                // 현재 Hw Trigger인지 확인
                //bool bHw = trigger.Source == ENeptuneTriggerSource.NEPTUNE_TRIGGER_SOURCE_SW ? false : true;

                // 현재 설정된 값과 value 값이 다르면
                //if (isHwTrigger != bHw)
                {
                    if (isHwTrigger == false) // SW Trigger로 변경
                    {
                        trigger.Mode = ENeptuneTriggerMode.NEPTUNE_TRIGGER_MODE_0;
                        trigger.nParam = 1;
                        trigger.Polarity = ENeptunePolarity.NEPTUNE_POLARITY_FALLINGEDGE;
                        trigger.Source = ENeptuneTriggerSource.NEPTUNE_TRIGGER_SOURCE_SW;
                        trigger.OnOff = ENeptuneBoolean.NEPTUNE_BOOL_TRUE;
                    }
                    else // HW Trigger로 변경
                    {
                        trigger.Mode = ENeptuneTriggerMode.NEPTUNE_TRIGGER_MODE_0;
                        trigger.nParam = 1;
                        trigger.Polarity = ENeptunePolarity.NEPTUNE_POLARITY_RISINGEDGE;
                        trigger.Source = ENeptuneTriggerSource.NEPTUNE_TRIGGER_SOURCE_LINE1;
                        trigger.OnOff = ENeptuneBoolean.NEPTUNE_BOOL_TRUE;
                        DelayHWTrigger();
                    }
                    cameraInstance[camIndex].SetTrigger(trigger);
                }
            }
        }

        bool isLive = false;
        public bool IsLive { get { return isLive; } set { isLive = value; } }

        private int camIndex;
        public int CamIndex
        {
            get { return camIndex; }
            set { camIndex = value; }
        }

        // HW트리거 모드전환 전에 사용해야할 함수입니다.
        // ExposureTimeAbs Node에서 ExposureTime (us) 값을 읽어와 Delay() 함수를 호출합니다.
        private void DelayHWTrigger()
        {
            NEPTUNE_XML_FLOAT_VALUE_INFO Info = new NEPTUNE_XML_FLOAT_VALUE_INFO();
            XMLDescription Desc = cameraInstance[camIndex].GetXMLInstance();
            Desc.GetNodeFloat("ExposureTimeAbs", ref Info);
            int nDelay = (int)(Info.dValue / 1000) + 76;
            //Delay(nDelay);
            Delay(nDelay * 2);        // IMI Sample 프로그램

            //Debug.WriteLine("[" + DateTime.Now + "] Delay " + nDelay.ToString() + "ms");
        }

        private static DateTime Delay(int MS)
        {
            DateTime thisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime afterMoment = thisMoment.Add(duration);

            while (afterMoment >= thisMoment)
            {
                System.Windows.Forms.Application.DoEvents();

                thisMoment = DateTime.Now;
            }

            return DateTime.Now;
        }

        public GigE_IMITech()
        {
            if (neptuneClass == null)
            {
                neptuneClass = new NeptuneClassLibCLR();
                neptuneClass.InitLibrary();
            }

            camTotalCount = DeviceManager.Instance.GetTotalCamera();
            if (cameraInstance == null)
            {
                cameraInstance = new CameraInstance[camTotalCount];
            }
            else
            {
                if (cameraInstance.Length != camTotalCount)
                    cameraInstance = new CameraInstance[camTotalCount];
            }

            pinfo = new NEPTUNE_CAM_INFO[camTotalCount];
            DeviceManager.Instance.GetCameraList(pinfo, camTotalCount);

            for (int i = 0; i < camTotalCount; i++)
            {
                if (string.IsNullOrEmpty(pinfo[i].strIP))
                    continue;

                for (int j = i; j < camTotalCount; j++)
                {
                    if (string.IsNullOrEmpty(pinfo[j].strIP))
                        continue;

                    if (ConvertIPToLong(pinfo[i].strIP) > ConvertIPToLong(pinfo[j].strIP))
                    {
                        NEPTUNE_CAM_INFO temp = pinfo[i];
                        pinfo[i] = pinfo[j];
                        pinfo[j] = temp;
                    }
                }
            }

        }

        long ConvertIPToLong(string ipAddress)
        {
            System.Net.IPAddress ip;

            if (System.Net.IPAddress.TryParse(ipAddress, out ip))
            {
                byte[] bytes = ip.GetAddressBytes();

                return (long)
                (
                    16777216 * (long)bytes[0] +
                    65536 * (long)bytes[1] +
                    256 * (long)bytes[2] +
                    (long)bytes[3]
                );
            }
            else
                return 0;
        }

        public void CameraOpen(int camNumber)
        {
            camIndex = camNumber;

            if (camIndex < 0 || camIndex > camTotalCount)
                throw new Exception("Cam Index 잘못");

            NeptuneDevice neptuneDeivce = DeviceManager.Instance.GetDeviceFromSerial(pinfo[camIndex].strSerial);

            if (neptuneDeivce == null)
                throw new Exception("There isn't camera device (IMI Tech)");

            if (cameraInstance[camNumber] != null)
                return;

            cameraInstance[camIndex] = new CameraInstance();
            DateTime s = DateTime.Now;
            while (true)
            {
                ENeptuneError error = cameraInstance[camIndex].CameraOpen(neptuneDeivce, ENeptuneDevAccess.NEPTUNE_DEV_ACCESS_EXCLUSIVE);
                if (error == ENeptuneError.NEPTUNE_ERR_Success)
                    break;

                if (DateTime.Now.Subtract(s).TotalMilliseconds > openTimeout)   //오픈 타임아웃 5초
                    throw new Exception("Cam Open TimeOut");
            }

            ENeptuneUserSet userSetNum = ENeptuneUserSet.NEPTUNE_USERSET_1; //userSet 1번 사용

            NEPTUNE_USERSET userSet = new NEPTUNE_USERSET();
            if ((cameraInstance[camIndex].GetUserSet(ref userSet) == ENeptuneError.NEPTUNE_ERR_Success) && ((userSet.SupportUserSet >> (int)userSetNum) & 0x00000001) == 1)
            {
                userSet.UserSetIndex = userSetNum;
                userSet.Command = ENeptuneUserSetCommand.NEPTUNE_USERSET_CMD_LOAD;
                if (cameraInstance[camIndex].SetUserSet(userSet) != ENeptuneError.NEPTUNE_ERR_Success)
                    throw new Exception("Cam setting load fail");
                //exposeTime check용
                //NEPTUNE_FEATURE nepturnfeature = new NEPTUNE_FEATURE();
                //cameraInstance[camIndex].GetFeature(ENeptuneFeature.NEPTUNE_FEATURE_SHUTTER, ref nepturnfeature);
            }

            ENeptuneDevType devType = neptuneDeivce.GetDeviceType();

            if (devType == ENeptuneDevType.NEPTUNE_DEV_TYPE_USB3)
            {
                cameraInstance[camIndex].SetFrameRate("10.0");
            }
            else if (devType == ENeptuneDevType.NEPTUNE_DEV_TYPE_GIGE)
            {
                cameraInstance[camIndex].WriteRegister(0x0D04, 8000); //PacketRate 8000.
                cameraInstance[camIndex].SetFrameRate("5.0");
            }

            cameraInstance[camIndex].SetPixelFormat(ENeptunePixelFormat.Mono8);

            cameraInstance[camIndex].GetMaxImageSize(ref maxSize);
            cameraInstance[camIndex].SetImageSize(maxSize);

            IsHwTrigger = false;
            AcqusitionStart();
        }

        public bool FlushBuffer()
        {
            //uint valu = cameraInstance[camIndex].GetBufferCount();
            //if (cameraInstance[camIndex].GetBufferCount() == 0) return true;
            if (cameraInstance[camIndex].FlushBuffer() == ENeptuneError.NEPTUNE_ERR_Success)
                return true;
            else
                return false;

        }
        public void CameraClose()
        {
            TriggerRun = null;
            if (cameraInstance != null && cameraInstance.Length > camIndex && cameraInstance[camIndex] != null)
            {
                lock (AcquisitionLock)
                {
                    ENeptuneError error = cameraInstance[camIndex].CameraClose();
                    cameraInstance[camIndex].Dispose();
                    cameraInstance[camIndex] = null;
                }
            }
        }

        public void ShowControlDialog()
        {
            if (cameraInstance[camIndex] != null)
                cameraInstance[camIndex].ShowControlDialog();
        }

        public Mat QueryFrame()
        {
            lock (AcquisitionLock)
            {
                if (cameraInstance.Length == 0) return null;
                if (cameraInstance[camIndex] == null) return null;

                AcqusitionStart();

                DateTime s = DateTime.Now;
                ENeptuneBoolean b = ENeptuneBoolean.NEPTUNE_BOOL_FALSE;
                ///*ENeptuneAcquisitionMode*/ mode = ENeptuneAcquisitionMode.NEPTUNE_ACQ_CONTINUOUS;
                uint fr = 0;
                //cameraInstance[camIndex].GetAcquisition(ref b, ref mode, ref fr);
                ENeptuneError err = cameraInstance[camIndex].WaitEventDataStream(ref frameData, queryTimeout);

                if (err == ENeptuneError.NEPTUNE_ERR_Success)
                {
                    ////
                    //string strFileName = "";
                    //DateTime currTime = DateTime.Now;
                    //strFileName = currTime.Month.ToString() + "_" + currTime.Day.ToString() + "(" +
                    //                                          currTime.Hour.ToString() + "_" + currTime.Minute.ToString() + "_" + currTime.Second.ToString() + "_" + string.Format("{0:D3}", currTime.Millisecond) +
                    //                                          ")" + ".raw";

                    //System.IO.FileStream stream = new System.IO.FileStream(strFileName,
                    //                                                                           System.IO.FileMode.Create,
                    //                                                                           System.IO.FileAccess.Write);
                    //byte[] buffer = new byte[frameData.GetBufferSize()];
                    //Marshal.Copy(frameData.GetBufferPtr(), buffer, 0, buffer.Length);
                    //stream.Write(buffer, 0, buffer.Length);
                    //stream.Close();
                    /////


                    //image = new Mat((int)frameData.GetHeight(), (int)frameData.GetWidth(), MatType.CV_8U, frameData.GetBufferPtr());
                    image = new Mat((int)frameData.GetHeight(), (int)frameData.GetWidth(), MatType.CV_8U);
                    image.SetArray(frameData.GetBufferPtr());
                    //2016-01-14 IMI-Tech : Grab 발생 유무 판단
                   /*
                                       if (isGrab)
                                       {
                                           imageGrab = image;
                                           isGrab = false;
                                       }
                    */

                   //Func.ShowTestImg(image, 0.25);
                   cameraInstance[camIndex].QueueBufferDataStream(frameData.GetBufferIndex());

                    // IMI Temp                 
                    //                    System.Diagnostics.Debug.WriteLine("[QueryFrame] 촬상시간 : " + DateTime.Now.Subtract(s).TotalMilliseconds);
                }
                else
                {
                    // IMI Temp                    
                    //                    System.Diagnostics.Debug.WriteLine("[QueryFrame] " + err.ToString());
                    //Logger.Log.Error("[QueryFrame] " + err.ToString());
                }
                return image;
            }
        }

        public void Run()
        { }

        public delegate void TriggerRunHandler(object sender, double time);
        public event TriggerRunHandler TriggerRun;

        void NotifyTriggerRun(long time)
        {
            if (TriggerRun != null)
            {
                TriggerRun(this, time);
            }
        }

        System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
        public Mat GrabImage()
        {
            sw.Restart();
            // Delay
            DateTime startTime = DateTime.Now;
            while (DateTime.Now.Subtract(startTime).TotalMilliseconds < BeforeGrabDelay)
            {
                System.Threading.Thread.Sleep(1);
            }

            lock (AcquisitionLock)
            {
                if (cameraInstance == null || cameraInstance.Length <= 0 || cameraInstance[camIndex] == null) return null;

                // 2016-01-15 IMI-Tech 삭제
                //AcqusitionStop();
                //NEPTUNE_TRIGGER trigger = new NEPTUNE_TRIGGER();
                //cameraInstance[camIndex].GetTrigger(ref trigger);
                //bool bHw = trigger.Source == ENeptuneTriggerSource.NEPTUNE_TRIGGER_SOURCE_SW ? false : true;
                //if (trigger.OnOff == ENeptuneBoolean.NEPTUNE_BOOL_FALSE || isHwTrigger)
                //{
                //    if (isHwTrigger == false)
                //    {
                //        trigger.Mode = ENeptuneTriggerMode.NEPTUNE_TRIGGER_MODE_0;
                //        trigger.nParam = 1;
                //        trigger.Polarity = ENeptunePolarity.NEPTUNE_POLARITY_FALLINGEDGE;
                //        trigger.Source = ENeptuneTriggerSource.NEPTUNE_TRIGGER_SOURCE_SW;
                //        trigger.OnOff = ENeptuneBoolean.NEPTUNE_BOOL_TRUE;
                //    }
                //    else
                //    {
                //        trigger.Mode = ENeptuneTriggerMode.NEPTUNE_TRIGGER_MODE_0;
                //        trigger.nParam = 1;
                //        trigger.Polarity = ENeptunePolarity.NEPTUNE_POLARITY_RISINGEDGE;
                //        trigger.Source = ENeptuneTriggerSource.NEPTUNE_TRIGGER_SOURCE_LINE1;
                //        trigger.OnOff = ENeptuneBoolean.NEPTUNE_BOOL_TRUE;
                //    }
                //    cameraInstance[camIndex].SetTrigger(trigger);
                //}

                // 2016-01-15 IMI-Tech Grab API 추가 1
                //if (trigger.OnOff == ENeptuneBoolean.NEPTUNE_BOOL_TRUE)
                //{
                System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}, Trigger -> FlushBuffer call..", camIndex));
                if (IsHwTrigger == false)
                    cameraInstance[camIndex].FlushBuffer();
                //}
                //else
                //{
                //    System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}, Live -> Grab call..", camIndex));
                //    cameraInstance[camIndex].Grab();
                //}

                DateTime s = DateTime.Now;

                ENeptuneError shotError = ENeptuneError.NEPTUNE_ERR_TimeOut;

                // 2016-01-15 IMI-Tech Grab API 추가 2
                //if (trigger.OnOff == ENeptuneBoolean.NEPTUNE_BOOL_FALSE)
                //    shotError = ENeptuneError.NEPTUNE_ERR_Success;

                ENeptuneError err = ENeptuneError.NEPTUNE_ERR_TimeOut;

                int retryCnt = 0;

                // 2016-01-14 IMI-Tech 삭제
                //while (true)
                {
                    if (isHwTrigger == false)
                    {
                        if (shotError != ENeptuneError.NEPTUNE_ERR_Success)
                        {
                            System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}   트리거 시작 시간 : {1}", camIndex, DateTime.Now.Subtract(s).TotalMilliseconds));
                            MvLogger.Log.Data(string.Format("Grab Start"), DateTime.Now);
                            shotError = cameraInstance[camIndex].RunSoftwareTrigger();
                        }
                        System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}   트리거 완료 시간 : {1}", camIndex, DateTime.Now.Subtract(s).TotalMilliseconds));
                        MvLogger.Log.Data(string.Format("Grab End"), DateTime.Now);

                        sw.Stop();
                        NotifyTriggerRun(sw.ElapsedMilliseconds);
                        System.Diagnostics.Debug.WriteLine(string.Format("=================================trigger time : {0}", sw.ElapsedMilliseconds));
                        if (shotError != ENeptuneError.NEPTUNE_ERR_Success)
                        {
                            System.Diagnostics.Debug.WriteLine(string.Format("Software Trigger send fail"));
                            return null;
                        }
                    }



                    // 2016-01-15 IMI-Tech : ERR_NO_DATA Exception
                    //while( true )
                    for (int i = 0; i < 5; i++)
                    {
                        err = cameraInstance[camIndex].WaitEventDataStream(ref frameData, grabTimeout);
                        if (err == ENeptuneError.NEPTUNE_ERR_Success)
                            break;
                        else if (err == ENeptuneError.NEPTUNE_ERR_TLInitFail)
                            continue;
                    }
                    if (err == ENeptuneError.NEPTUNE_ERR_TLInitFail)
                        System.Diagnostics.Debug.WriteLine(string.Format("Grab Error"));
                    else if (err == ENeptuneError.NEPTUNE_ERR_Success)
                        System.Diagnostics.Debug.WriteLine(string.Format("Grab Success"));


                    System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}   이미지 취득 완료 시간 : {1}", camIndex, DateTime.Now.Subtract(s).TotalMilliseconds));

                    ////////////////////
                    // 삼성 SDC 
                    //if (err != ENeptuneError.NEPTUNE_ERR_Success)
                    //{
                    //    System.Diagnostics.Debug.WriteLine(err.ToString());
                    //    continue;
                    //}
                    //else
                    //    break;

                    //if (DateTime.Now.Subtract(s).TotalMilliseconds > grabTimeout)
                    //{
                    //    if (retryCnt++ > 2)
                    //    {
                    //        System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}   Grab Fail", camIndex));
                    //        break;
                    //    }

                    //    System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}   TimeOut", camIndex));
                    //    Logger.Log.Error(string.Format("[GrabImage] CameraNo : {0}   TimeOut", camIndex));
                    //    shotError = ENeptuneError.NEPTUNE_ERR_TimeOut;
                    //    continue;
                    //}

                }

                //while (true)
                //{
                //    if (shotError != ENeptuneError.NEPTUNE_ERR_Success)
                //        shotError = cameraInstance[camIndex].OneShot();

                //    if (shotError == ENeptuneError.NEPTUNE_ERR_Success)
                //        err = cameraInstance[camIndex].WaitEventDataStream(ref frameData, grabTimeout);

                //    if (err != ENeptuneError.NEPTUNE_ERR_Success)
                //        System.Diagnostics.Debug.WriteLine(err.ToString());
                //    else
                //        break;

                //    if (DateTime.Now.Subtract(s).TotalMilliseconds > grabTimeout)
                //    {
                //        if (retryCnt++ > 2)
                //        {
                //            throw new Exception(string.Format("[GrabImage] CameraNo : {0}   Grab Fail", camIndex));
                //            break;
                //        }

                //        System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}   TimeOut", camIndex));
                //        Logger.Log.Error(string.Format("[GrabImage] CameraNo : {0}   TimeOut", camIndex));
                //        shotError = ENeptuneError.NEPTUNE_ERR_TimeOut;
                //        continue;
                //    }
                //}
                ////////////////////

                if (err == ENeptuneError.NEPTUNE_ERR_Success)
                {
                    // Mat img = new Mat((int)frameData.GetHeight(), (int)frameData.GetWidth(), MatType.CV_8U, frameData.GetBufferPtr()).Clone();
                    Mat img = new Mat((int)frameData.GetHeight(), (int)frameData.GetWidth(), MatType.CV_8U);
                    img.SetArray(frameData.GetBufferPtr());
 
                     cameraInstance[camIndex].QueueBufferDataStream(frameData.GetBufferIndex());
                    System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0}   촬상시간 : {1}", camIndex, DateTime.Now.Subtract(s).TotalMilliseconds));
                    cameraInstance[camIndex].FlushBuffer();
                    return img;
                }
                // 2016-01-14 IMI-Tech : Grab Fail
                System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] CameraNo : {0} Grab Timeout : {1}", camIndex, DateTime.Now.Subtract(s).TotalMilliseconds));
                cameraInstance[camIndex].FlushBuffer();
                return imageGrab;
            }
        }

        public void AcqusitionStart()
        {
            //if (mode != ENeptuneAcquisitionMode.NEPTUNE_ACQ_CONTINUOUS)
            {
                //ENeptuneError result;
                //if (isAcq == true)
                //{
                //    result = cameraInstance[camIndex].AcquisitionStop();
                //    if (result == ENeptuneError.NEPTUNE_ERR_Success)
                //        isAcq = false;
                //}
                NEPTUNE_TRIGGER stTrigger = new NEPTUNE_TRIGGER();
                cameraInstance[camIndex].GetTrigger(ref stTrigger);
                if (stTrigger.OnOff == ENeptuneBoolean.NEPTUNE_BOOL_TRUE)
                {
                    stTrigger.OnOff = ENeptuneBoolean.NEPTUNE_BOOL_FALSE;
                    cameraInstance[camIndex].SetTrigger(stTrigger);
                }
                cameraInstance[camIndex].AcquisitionStart(ENeptuneGrabMode.NEPTUNE_GRAB_CONTINUOUS);
                //if (isAcq == false)
                {
                    //result = ENeptuneError.NEPTUNE_ERR_Success;
                    //cameraInstance[camIndex].SetAcquisitionMode(ENeptuneAcquisitionMode.NEPTUNE_ACQ_CONTINUOUS, 0);

                    //ENeptuneError restartResult = cameraInstance[camIndex].AcquisitionStart(ENeptuneGrabMode.NEPTUNE_GRAB_CONTINUOUS); //single이든 continue든 acq는 continue 고정
                    //if (result == ENeptuneError.NEPTUNE_ERR_Success && restartResult == ENeptuneError.NEPTUNE_ERR_Success)
                    {
                        //isAcq = true;
                        //mode = ENeptuneAcquisitionMode.NEPTUNE_ACQ_CONTINUOUS;
                        //System.Diagnostics.Debug.WriteLine("[GrabImage] NEPTUNE_ACQ_CONTINUOUS 설정변경");
                    }
                }
            }
        }

        public void AcqusitionStop()
        {
            //if (mode != ENeptuneAcquisitionMode.NEPTUNE_ACQ_SINGLEFRAME)
            {
                ENeptuneError result = ENeptuneError.NEPTUNE_ERR_TimeOut;

                //if (isAcq == true)
                //{
                //    result = cameraInstance[camIndex].AcquisitionStop();
                //    if (result == ENeptuneError.NEPTUNE_ERR_Success)
                //        isAcq = false;
                //}

                //if (isAcq == false)
                //{
                //    result = cameraInstance[camIndex].SetAcquisitionMode(ENeptuneAcquisitionMode.NEPTUNE_ACQ_SINGLEFRAME, 0);

                //    ENeptuneError restartResult = cameraInstance[camIndex].AcquisitionStart(ENeptuneGrabMode.NEPTUNE_GRAB_CONTINUOUS); //single이든 continue든 acq는 continue 고정
                //    if (result == ENeptuneError.NEPTUNE_ERR_Success && restartResult == ENeptuneError.NEPTUNE_ERR_Success)
                //    {
                //        isAcq = true;
                //        mode = ENeptuneAcquisitionMode.NEPTUNE_ACQ_SINGLEFRAME;
                //        System.Diagnostics.Debug.WriteLine("[GrabImage] NEPTUNE_ACQ_SINGLEFRAME 설정변경");
                //    }
                //}

                //if (isAcq == false)
                {
                    // trigger Mode Setting
                    //NEPTUNE_TRIGGER_INFO TriggerInfo = new NEPTUNE_TRIGGER_INFO();
                    //cameraInstance[camIndex].GetTriggerInfo(ref TriggerInfo);

                    //if (TriggerInfo.bSupport == ENeptuneBoolean.NEPTUNE_BOOL_TRUE)
                    {
                        NEPTUNE_TRIGGER trigger = new NEPTUNE_TRIGGER();
                        cameraInstance[camIndex].GetTrigger(ref trigger);

                        //2016-01-15 IMI-Tech 삭제
                        //bool bFlush = false;

                        //if (trigger.OnOff == ENeptuneBoolean.NEPTUNE_BOOL_FALSE)   // Live
                        //    bFlush = true;                            


                        trigger.Mode = ENeptuneTriggerMode.NEPTUNE_TRIGGER_MODE_0;
                        trigger.nParam = 1;
                        trigger.OnOff = ENeptuneBoolean.NEPTUNE_BOOL_TRUE;
                        trigger.Polarity = ENeptunePolarity.NEPTUNE_POLARITY_FALLINGEDGE;
                        trigger.Source = ENeptuneTriggerSource.NEPTUNE_TRIGGER_SOURCE_SW;
                        result = cameraInstance[camIndex].SetTrigger(trigger);

                        //2016-01-15 IMI-Tech 삭제
                        //if( bFlush )
                        //    cameraInstance[camIndex].FlushBuffer();
                    }

                    //ENeptuneError restartResult = cameraInstance[camIndex].AcquisitionStart(ENeptuneGrabMode.NEPTUNE_GRAB_CONTINUOUS); //single이든 continue든 acq는 continue 고정
                    if (result == ENeptuneError.NEPTUNE_ERR_Success)// && restartResult == ENeptuneError.NEPTUNE_ERR_Success)
                    {
                        //isAcq = true;
                        //mode = ENeptuneAcquisitionMode.NEPTUNE_ACQ_SINGLEFRAME;
                        System.Diagnostics.Debug.WriteLine("[GrabImage] Live -> Trigger 모드 변경 성공");
                    }
                    else
                        System.Diagnostics.Debug.WriteLine("[GrabImage] Live -> Trigger 모드 변경 실패");
                }
            }
        }

        public float Getfps()
        {
            return this.rcvFrameRate;
        }

        public int GetConnectedCamCount()
        {
            return (int)camTotalCount;
        }

        public string GetCameraSeiralNo()
        {
            if (pinfo == null) return null;
            return pinfo[camIndex].strSerial;
        }

        public string GetCameraSeiralNo(int camNumber)
        {
            if (pinfo == null) return null;
            if (pinfo.Length <= camNumber) return null;
            return pinfo[camNumber].strSerial;
        }

        public float ExposureTime
        {
            get
            {
                return mExposureTime;
            }
            set
            {
                if (mExposureTime == value) return;
                mExposureTime = value;
                //Cam.setStreamGrabber.UserData[.["ExposureTime"] = value;
            }
        }
        float mExposureTime;

        public float GainTime
        {
            get
            {
                return mGainTime;
            }
            set
            {
                if (mGainTime == value) return;
                mGainTime = value;
            }
        }
        float mGainTime;

        public int BeforeGrabDelay { get; set; }
        int mBeforeGrabDelay;

        #region IDisposable Support
        private bool disposedValue = false; // 중복 호출을 검색하려면

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 관리되는 상태(관리되는 개체)를 삭제합니다.
                    CameraClose();
                }

                // TODO: 관리되지 않는 리소스(관리되지 않는 개체)를 해제하고 아래의 종료자를 재정의합니다.
                // TODO: 큰 필드를 null로 설정합니다.

                disposedValue = true;
            }
        }

        // TODO: 위의 Dispose(bool disposing)에 관리되지 않는 리소스를 해제하는 코드가 포함되어 있는 경우에만 종료자를 재정의합니다.
        // ~GigE_IMITech() {
        //   // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
        //   Dispose(false);
        // }

        // 삭제 가능한 패턴을 올바르게 구현하기 위해 추가된 코드입니다.
        public void Dispose()
        {
            // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
            Dispose(true);
            // TODO: 위의 종료자가 재정의된 경우 다음 코드 줄의 주석 처리를 제거합니다.
            // GC.SuppressFinalize(this);
        }

        #endregion
    }
}
