﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

// System Thread
using System.Threading;
using System.Threading.Tasks;

// OpenCv Processing
using OpenCvSharp;

// PointGrey Camera
using FlyCapture2Managed;
using FlyCapture2Managed.Gui;

namespace MvCore.CameraDevice
{
    public class GigE_PointGrey : ICamDevice
    {
        static CameraControlDialog m_camCtlDlg;
        static ManagedBusManager m_busMgr;
        static ManagedGigECamera[] m_cameras = null;

        bool isHwTrigger = false;
        public bool IsHwTrigger { get { return isHwTrigger; } set { isHwTrigger = value; } }

        bool isLive = false;
        public bool IsLive { get { return isLive; } set { isLive = value; } }
        private int camIndex;
        public int CamIndex
        {
            get { return camIndex; }
            set { camIndex = value; }
        }
        ManagedPGRGuid m_guid;
        ManagedImage m_rawImage;
        private bool m_grabImages;
        private uint m_camTotalCount = 0;
        public int m_camIndex;

        object AcquisitionLock = new object();

        static void PrintCameraInfo(CameraInfo camInfo)
        {
            StringBuilder newStr = new StringBuilder();
            newStr.Append("\n*** CAMERA INFORMATION ***\n");
            newStr.AppendFormat("Serial number - {0}\n", camInfo.serialNumber);
            newStr.AppendFormat("Camera model - {0}\n", camInfo.modelName);
            newStr.AppendFormat("Camera vendor - {0}\n", camInfo.vendorName);
            newStr.AppendFormat("Sensor - {0}\n", camInfo.sensorInfo);
            newStr.AppendFormat("Resolution - {0}\n", camInfo.sensorResolution);
            Console.WriteLine(newStr);
        }

        static void PrintStreamChannelInfo(GigEStreamChannel streamChannelInfo)
        {
            StringBuilder newStr = new StringBuilder();
            newStr.Append("\n*** STREAM CHANNEL INFORMATION ***\n");
            newStr.AppendFormat("Network interface - {0}\n", streamChannelInfo.networkInterfaceIndex);
            newStr.AppendFormat("Host post - {0}\n", streamChannelInfo.hostPost);
            newStr.AppendFormat("Do not fragment bit - {0}\n", streamChannelInfo.doNotFragment == true ? "Enabled" : "Disabled");
            newStr.AppendFormat("Packet size - {0}\n", streamChannelInfo.packetSize);
            newStr.AppendFormat("Inter packet delay - {0}\n", streamChannelInfo.interPacketDelay);
            newStr.AppendFormat("Destination IP address - {0}\n", streamChannelInfo.destinationIpAddress);
            newStr.AppendFormat("Source port (on camera) - {0}\n\n", streamChannelInfo.sourcePort);
            Console.WriteLine(newStr);
        }

        public GigE_PointGrey()
        {
            if (m_busMgr == null)
                m_busMgr = new ManagedBusManager();

            //// Camera Control Dialog
            //if (m_camCtlDlg != null) m_camCtlDlg = null;
            //m_camCtlDlg = new CameraControlDialog();

            // Create a raw image
            if (m_rawImage != null) m_rawImage.Dispose();
            m_rawImage = new ManagedImage();

            //CameraInfo[] camInfos = ManagedBusManager.DiscoverGigECameras();
            //Console.WriteLine("Number of cameras discovered: {0}", camInfos.Length);
            //foreach (CameraInfo camInfo in camInfos)
            //{
            //    PrintCameraInfo(camInfo);
            //}

            m_camTotalCount = m_busMgr.GetNumOfCameras();
            if (m_cameras == null)
            {
                m_cameras = new ManagedGigECamera[m_camTotalCount];
            }
            else
            {
                if (m_cameras.Length != m_camTotalCount)
                    m_cameras = new ManagedGigECamera[m_camTotalCount];
            }

            Console.WriteLine("Number of cameras enumerated: {0}", m_camTotalCount);
        }

        public void CameraOpen(int camNumber)
        {
            this.m_camIndex = camNumber;

            if (m_camIndex < 0 || m_camIndex > m_camTotalCount)
            {
                throw new Exception("Camera Index Error");
            }

            m_guid = m_busMgr.GetCameraFromIndex((uint)m_camIndex);

            if ((object)m_guid == null)
            {
                throw new Exception("There isn't ManagedPgRGuid (PointGrey)");
            }

            if (m_busMgr.GetInterfaceTypeFromGuid(m_guid) == InterfaceType.GigE)
            {
                try
                {
                    if (m_cameras[camNumber] != null)
                        return;

                    // Connect to a camera
                    m_cameras[camNumber] = new ManagedGigECamera();
                    m_cameras[camNumber].Connect(m_guid);

                    //// Connect to a Control Dialog
                    //m_camCtlDlg.Disconnect(); 
                    //m_camCtlDlg.Connect(m_camera);

                    // Get the camera information
                    CameraInfo camInfo = m_cameras[camNumber].GetCameraInfo();

                    PrintCameraInfo(camInfo);

                    FC2Config fc2 = m_cameras[camNumber].GetConfiguration();
                    fc2.grabMode = GrabMode.DropFrames;
                    m_cameras[camNumber].SetConfiguration(fc2);

                    GigEProperty property = m_cameras[camNumber].GetGigEProperty(GigEPropertyType.PacketSize);
                    property.value = m_cameras[camNumber].DiscoverGigEPacketSize();
                    m_cameras[camNumber].SetGigEProperty(property);
                    property = m_cameras[camNumber].GetGigEProperty(GigEPropertyType.PacketDelay);
                    property.value = 100;
                    m_cameras[camNumber].SetGigEProperty(property);

                    EmbeddedImageInfo embeddedInfo = m_cameras[camNumber].GetEmbeddedImageInfo();
                    if (embeddedInfo.timestamp.available == true)
                        embeddedInfo.timestamp.onOff = true;
                    m_cameras[camNumber].SetEmbeddedImageInfo(embeddedInfo);

                    GigEImageSettingsInfo imageSettingsInfo = m_cameras[camNumber].GetGigEImageSettingsInfo();
                    GigEImageSettings imageSettings = new GigEImageSettings();
                    imageSettings.offsetX = 0;
                    imageSettings.offsetY = 0;
                    imageSettings.height = imageSettingsInfo.maxHeight;
                    imageSettings.width = imageSettingsInfo.maxWidth;
                    imageSettings.pixelFormat = PixelFormat.PixelFormatMono8;
                    m_cameras[camNumber].SetGigEImageSettings(imageSettings);

                    uint numStreamChannels = m_cameras[camNumber].GetNumStreamChannels();
                    for (uint i = 0; i < numStreamChannels; i++)
                    {
                        GigEStreamChannel streamChannelInfo = m_cameras[camNumber].GetGigEStreamChannelInfo(i);
                        PrintStreamChannelInfo(streamChannelInfo);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(String.Format("Error running camera {0}. Error: {1}", m_camIndex, ex.Message));
                }
            }
        }

        public void CameraClose()
        {
            lock (AcquisitionLock)
            {
                try
                {
                    if (m_cameras[m_camIndex] != null)
                    {
                        if (m_cameras[m_camIndex].IsConnected())
                        {
                            AcqusitionStop();
                            m_cameras[m_camIndex].Disconnect();
                        }

                        m_cameras[m_camIndex].Dispose();
                        m_cameras[m_camIndex] = null;
                    }

                    if (m_camCtlDlg != null)
                    {
                        m_camCtlDlg.Disconnect();
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("[CameraClose] " + ex.ToString());
                    // Logger.Log.Error("[CameraClose] " + ex.Message.ToString());
                }
            }
        }

        /// <summary>
        /// Continue Grab Function
        /// </summary>
        /// <returns></returns>
        public Mat QueryFrame()
        {
            lock (AcquisitionLock)
            {
                try
                {
                    AcqusitionStart();
                    //m_camera.WaitForBufferEvent(m_rawImage, 0);
                    m_cameras[m_camIndex].RetrieveBuffer(m_rawImage);

                    if (m_rawImage == null) throw new Exception("ImageActiveBuffer is null");

                    unsafe
                    {
                        //Mat image = new Mat((int)m_rawImage.rows, (int)m_rawImage.cols, MatType.CV_8UC1, (IntPtr)m_rawImage.data);
                        Mat image = new Mat((int)m_rawImage.rows, (int)m_rawImage.cols, MatType.CV_8UC1);
                        image.SetArray((IntPtr)m_rawImage.data);
                        return image;
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("[QueryFrame] " + ex.ToString());
                    //Logger.Log.Error("[QueryFrame] " + ex.Message.ToString());
                    return null;
                }
            }
        }

        /// <summary>
        /// SingGrab Function
        /// </summary>
        /// <returns></returns>
        public Mat GrabImage()
        {
            // Delay
            DateTime startTime = DateTime.Now;
            while (DateTime.Now.Subtract(startTime).TotalMilliseconds < BeforeGrabDelay)
            {
                System.Threading.Thread.Sleep(1);
            }

            Mat grab = QueryFrame();
            //System.Diagnostics.Debug.WriteLine(string.Format("[GrabImage] Grabbing Time : {0}   index : {1}   time : {2}", startTime, m_camIndex.ToString(), DateTime.Now.Subtract(startTime).TotalMilliseconds));
            if (grab == null) return null;
            else return grab.Clone();
        }

        // Camera 시작
        public void AcqusitionStart()
        {
            if (!m_grabImages)
            {
                m_grabImages = true;

                try
                {
                    if (m_cameras[m_camIndex] == null) CameraOpen(m_camIndex);
                    m_cameras[m_camIndex].StartCapture();
                }
                catch (FC2Exception ex)
                {
                    //Logger.Log.Error("Failed to Start camera " + ex.Message);
                }
            }
        }

        public void AcqusitionStop()
        {
            if (m_grabImages)
            {
                m_grabImages = false;

                try
                {
                    m_cameras[m_camIndex].StopCapture();
                }
                catch (FC2Exception ex)
                {
                    //Logger.Log.Error("Failed to stop camera " + ex.Message);
                }
            }
        }

        public void ShowControlDialog()
        {
            if ((object)m_guid != null)
                m_camCtlDlg.Show();
        }

        public float Getfps()
        {
            return m_cameras[m_camIndex].GetProperty(PropertyType.FrameRate).absValue;
        }

        public bool OpenCam()
        {
            return true;
        }

        public void CloseCam()
        {
            m_camCtlDlg.Disconnect();
            m_cameras[m_camIndex].Disconnect();
        }

        public void Run()
        { }
        public int GetConnectedCamCount()
        {
            return (int)m_camTotalCount;
        }

        public string GetCameraSeiralNo()
        {
            return GetCameraSeiralNo(m_camIndex);
        }

        public string GetCameraSeiralNo(int camNumber)
        {
            if (m_busMgr == null) return null;
            return m_busMgr.GetCameraSerialNumberFromIndex((uint)camNumber).ToString();
        }

        #region IDisposable Support
        private bool disposedValue = false; // 중복 호출을 검색하려면

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 관리되는 상태(관리되는 개체)를 삭제합니다.
                    CameraClose();
                }

                // TODO: 관리되지 않는 리소스(관리되지 않는 개체)를 해제하고 아래의 종료자를 재정의합니다.
                // TODO: 큰 필드를 null로 설정합니다.

                disposedValue = true;
            }
        }

        // TODO: 위의 Dispose(bool disposing)에 관리되지 않는 리소스를 해제하는 코드가 포함되어 있는 경우에만 종료자를 재정의합니다.
        // ~GigE_ImagingSource() {
        //   // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
        //   Dispose(false);
        // }

        // 삭제 가능한 패턴을 올바르게 구현하기 위해 추가된 코드입니다.
        public void Dispose()
        {
            // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
            Dispose(true);
            // TODO: 위의 종료자가 재정의된 경우 다음 코드 줄의 주석 처리를 제거합니다.
            // GC.SuppressFinalize(this);
        }
        #endregion

        public bool FlushBuffer()
        {
            return true;
        }

        public float ExposureTime
        {
            get
            {
                return mExposureTime;
            }
            set
            {
                if (mExposureTime == value) return;
                mExposureTime = value;
                //Cam.setStreamGrabber.UserData[.["ExposureTime"] = value;
            }
        }
        float mExposureTime;

        public float GainTime
        {
            get
            {
                return mGainTime;
            }
            set
            {
                if (mGainTime == value) return;
                mGainTime = value;
            }
        }
        float mGainTime;

        public int BeforeGrabDelay { get; set; }
        int mBeforeGrabDelay;
    }
}