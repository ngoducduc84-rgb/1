﻿using System;
using OpenCvSharp;
using System.Threading.Tasks;
using OpenCvSharp;
using System.Collections.Generic;

namespace MvCore.CameraDevice
{
    [Serializable]
    public enum CameraType
    {
        GigE_IMITech, /*GigE_ImagingSource,*/ GigE_Basler, GigE_PointGrey, WebCam, Image, GigE_Crevis, GigE_Hik
    }

    public interface ICamDevice : IDisposable
    {

        /// <summary>
        /// 카메라에서 이미지 한장을 빼온다. 이 이미지는 최신 이미지가 아닐 수 있다.(보통 내부 buffer frame중에 가장 오래된거 꺼내옴). 디스플레이 용으로 사용.
        /// </summary>
        /// <returns></returns>
        Mat QueryFrame();

        /// <summary>
        /// 카메라에서 이미지 한장을 빼온다. 이 이미지는 호출한 시점의 카메라 이미지이다.(보통 내부 buffer frame중에 가장 최근거 꺼내옴). Vision 용으로 사용.
        /// </summary>
        /// <returns></returns>
        Mat GrabImage();

        /// <summary>
        /// 해당하는 카메라 넘버로 카메라를 연다
        /// </summary>
        /// <param name="camNumber">카메라 번호</param>
        void CameraOpen(int camNumber);

        /// <summary>
        /// 현재 카메라를 끈다. 
        /// </summary>
        void CameraClose();

        /// <summary>
        /// 카메라 영상취득 스타트. 스타트 한 시점에서 카메라 내부적으로 계속 찍고있는다.
        /// </summary>
        void AcqusitionStart();

        /// <summary>
        /// 카메라 영상취득 종료.
        /// </summary>
        void AcqusitionStop();

        void Run();

        /// <summary>
        /// 카메라 컨트롤 다이얼로그를 연다. 보통 카메라 API에서 지원하는 다이얼로그를 연다
        /// </summary>
        void ShowControlDialog();

        /// <summary>
        /// 현재 카메라 FPS를 받아온다
        /// </summary>
        float Getfps();

        /// <summary>
        /// 연결된 카메라 총 갯수를 가져온다.
        /// </summary>
        int GetConnectedCamCount();

        /// <summary>
        /// 현재 연결된 카메라 일련번호를 가져온다.
        /// </summary>
        string GetCameraSeiralNo();

        string GetCameraSeiralNo(int camNumber);

        bool IsHwTrigger { get; set; }

        bool IsLive { get; set; }

        bool FlushBuffer();

        float ExposureTime { get; set; }

        float GainTime { get; set; }

        int BeforeGrabDelay { get; set; }

        int CamIndex { get; set; }


    }
}
