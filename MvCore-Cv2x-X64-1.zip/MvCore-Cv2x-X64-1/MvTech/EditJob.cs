﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.core;
using System.Management;

namespace MvTech
{
    
    public partial class EditJob : Form
    {
        private _internal inter;
        public EditJob()
        {
            inter = new _internal();
            InitializeComponent();
           
        }

        private void EditJob_Load(object sender, EventArgs e)
        {
            mvJobEdit1.SubjectFormLoad();
            //if (inter.checkActive() == false) { mvJobEdit1 = null; }
        }

        private void EditJob_FormClosing(object sender, FormClosingEventArgs e)
        {
            mvJobEdit1.SubjectFormClosing();
        }

       
    }
}
