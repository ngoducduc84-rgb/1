﻿using MvCore;
using MvCore.Core;
using MvCore.Display;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using MvCore.core;
using System.Security.AccessControl;

namespace MvTech
{
    public partial class MVTech : Form
    {
        public MVTech()
        {
            InitializeComponent();
        }
        List<MvJob> jobs = new List<MvJob>();
        MvSerializer serializer = new MvSerializer();
        string PATH_JOB = "C:\\SVL_Data\\Job";
        private _internal inter;
        private void MVTech_Load(object sender, EventArgs e)
        {
            inter = new _internal();

            return;
            string[] files = Directory.GetFiles(PATH_JOB, "*.job");
            foreach (string file in files)
            {
                try
                {
                    MvJob job = null;
                    MvToolBase tool;
                    string extension = System.IO.Path.GetExtension(file).ToLower();

                    if (extension.Equals(".job"))
                        job = serializer.LoadJob(file);
                    else if (extension.Equals(".tlf"))
                    {
                        tool = serializer.LoadTool(file);
                        if (!(tool is MvToolBlock))
                            continue;
                        job = (tool as MvToolBlock).ToolJob;
                    }

                    this.Cursor = Cursors.Default;

                    if (job == null)
                    {
                        MessageBox.Show("Job load fail");
                        continue;
                    }

                    jobs.Add(job);
                    TreeNode node = new TreeNode();
                    node.Text = job.Name;
                    node.Tag = job;
                    tree_Jobs.Nodes.Add(node);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }




        int x, y;
        private void tree_Jobs_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            TreeNode node = tree_Jobs.GetNodeAt(e.X, e.Y);
            tree_Jobs.SelectedNode = node;
            if (node != null)
            {
                if (e.Button == MouseButtons.Right)
                {
                    MvJob job = node.Tag as MvJob;
                    ShowResult form = new ShowResult(ref job);
                    form.Show();
                }
                else if (e.Button == MouseButtons.Left)
                {
                    EditJob form = new EditJob();
                    form.mvJobEdit1.Job = node.Tag as MvJob;
                    form.Show();

                }
            }
        }

        public static string ShowInputDialog(string title, string message)
        {

            using (Form form = new Form())
            using (System.Windows.Forms.TextBox textBox = new System.Windows.Forms.TextBox())
            using (System.Windows.Forms.Button btnOk = new System.Windows.Forms.Button())
            using (System.Windows.Forms.Button btnCancel = new System.Windows.Forms.Button())
            using (Label label = new Label())
            {
                form.Text = title;
                label.Text = message;

                textBox.SetBounds(12, 35, 360, 20);
                label.SetBounds(12, 9, 360, 13);

                btnOk.Text = "OK";
                btnCancel.Text = "Cancel";
                btnOk.DialogResult = DialogResult.OK;
                btnCancel.DialogResult = DialogResult.Cancel;

                btnOk.SetBounds(216, 70, 75, 23);
                btnCancel.SetBounds(297, 70, 75, 23);

                form.ClientSize = new Size(384, 111);
                form.Controls.AddRange(new Control[] {
            label, textBox, btnOk, btnCancel
        });

                form.AcceptButton = btnOk;
                form.CancelButton = btnCancel;
                form.StartPosition = FormStartPosition.CenterParent;
                form.FormBorderStyle = FormBorderStyle.FixedDialog;
                form.MaximizeBox = false;
                form.MinimizeBox = false;

                return form.ShowDialog() == DialogResult.OK
                    ? textBox.Text
                    : null;
            }
        }


        private void activeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            inter.creartCode();
        }

        private void openToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (inter.checkActive() == false) { MessageBox.Show("Not Active"); return; }
            OpenFileDialog fd = new OpenFileDialog();
            MvSerializer serializer = new MvSerializer();
            fd.InitialDirectory = PATH_JOB;
            fd.Filter = "Job files (*.job)|*.job|ToolBlock files (*.tlf)|*.tlf|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.Multiselect = false;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;
            this.Cursor = Cursors.WaitCursor;
            MvJob job = null;
            MvToolBase tool;
            string extension = System.IO.Path.GetExtension(fd.FileName).ToLower();

            if (extension.Equals(".job"))
                job = serializer.LoadJob(fd.FileName);
            else if (extension.Equals(".tlf"))
            {
                tool = serializer.LoadTool(fd.FileName);
                if (!(tool is MvToolBlock))
                    return;
                job = (tool as MvToolBlock).ToolJob;
            }

            this.Cursor = Cursors.Default;

            if (job == null)
            {
                MessageBox.Show("Job load fail");
                return;
            }

            jobs.Add(job);
            TreeNode node = new TreeNode();
            node.Text = job.Name;
            node.Tag = job;
            tree_Jobs.Nodes.Add(node);
            //tree_Jobs.RedrawAllNode();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (inter.checkActive() == false) { MessageBox.Show("Not Active"); return; }
            EditJob editJob = new EditJob();
            string value = ShowInputDialog("input Job Name", "Job Name:");
            if (value != null)
            {
                MvJob newJob = new MvJob();
                newJob.Name = value;
                jobs.Add(newJob);
                TreeNode node = new TreeNode();
                node.Text = newJob.Name;
                node.Tag = newJob;
                tree_Jobs.Nodes.Add(node);
                editJob.mvJobEdit1.Job = newJob;
                editJob.Show();
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (inter == null)
            {
                inter = new _internal();
            }
            if (inter.checkActive() == false)
            {
                this.Close();
            }
        }

        private void MVTech_FormClosed(object sender, FormClosedEventArgs e)
        {
            foreach(MvJob job in jobs)
            {
                foreach (MvToolBase tool in job.ToolList)
                {

                    if (tool is MvToolBlock)
                    {
                        MvToolBlock tools = tool as MvToolBlock;
                        foreach (MvToolBase _tool in tools.ToolJob.ToolList)
                        {
                            closeCamera(_tool);
                        }
                    }
                    else if (tool is MvIf) 
                    {
                        MvIf tool_ = tool as MvIf;
                        foreach (MvToolBase _tool in tool_.ToolJobTrue.ToolList)
                        {
                            closeCamera(_tool);
                        }
                        foreach (MvToolBase _tool in tool_.ToolJobFalse.ToolList)
                        {
                            closeCamera(_tool);
                        }

                    }else if(tool is MvFor)
                    {
                        MvFor tool_ = tool as MvFor;
                        foreach (MvToolBase _tool in tool_.ToolJob.ToolList)
                        {
                            closeCamera(_tool);
                        }
                    }else
                    {
                        closeCamera(tool);
                    }    
                }
            }    
        }
         private void closeCamera(MvToolBase tool)
        {
            if(tool is MvAcquisition)
            {
                MvAcquisition acquisition = tool as MvAcquisition;
                acquisition.closeCamList();
            }    
        }

        private void tree_Jobs_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Delete)
            {
                TreeNode node = tree_Jobs.SelectedNode;
                if (node == null) return;
                tree_Jobs.Nodes.Remove(node);
            }
        }
    }
}
