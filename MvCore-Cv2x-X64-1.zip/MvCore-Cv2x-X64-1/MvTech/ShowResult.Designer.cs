﻿namespace MvTech
{
    partial class ShowResult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.mvDisplayViewEdit1 = new MvCore.Edit.Base.MvDisplayViewEdit();
            this.lbl_RunTime = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.mvDisplayViewEdit1);
            this.panel1.Location = new System.Drawing.Point(0, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(530, 374);
            this.panel1.TabIndex = 2;
            // 
            // mvDisplayViewEdit1
            // 
            this.mvDisplayViewEdit1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mvDisplayViewEdit1.Location = new System.Drawing.Point(0, 0);
            this.mvDisplayViewEdit1.Name = "mvDisplayViewEdit1";
            this.mvDisplayViewEdit1.Size = new System.Drawing.Size(530, 374);
            this.mvDisplayViewEdit1.TabIndex = 0;
            // 
            // lbl_RunTime
            // 
            this.lbl_RunTime.AutoSize = true;
            this.lbl_RunTime.Location = new System.Drawing.Point(367, 5);
            this.lbl_RunTime.Name = "lbl_RunTime";
            this.lbl_RunTime.Size = new System.Drawing.Size(29, 13);
            this.lbl_RunTime.TabIndex = 3;
            this.lbl_RunTime.Text = "0 ms";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(302, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Run Time: ";
            // 
            // ShowResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 406);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_RunTime);
            this.Controls.Add(this.panel1);
            this.Name = "ShowResult";
            this.Text = "ShowResult";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ShowResult_FormClosing);
            this.Load += new System.EventHandler(this.ShowResult_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public MvCore.Edit.Base.MvDisplayViewEdit mvDisplayViewEdit1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_RunTime;
        private System.Windows.Forms.Label label1;
    }
}