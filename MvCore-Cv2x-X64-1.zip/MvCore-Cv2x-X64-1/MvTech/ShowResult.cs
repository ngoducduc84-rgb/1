﻿using MvCore;
using MvCore.core;
using MvCore.Display;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MvTech
{
    public partial class ShowResult : Form
    {
        MvJob job;
        DrawShow draw;
        MvDisplayViewInteract disp;
        Thread th;
        bool threadLock = true;
        bool status = false;
        MvTCP tcp;
        MvAcquisition acq;
        internal _internal inter;
        bool acti = false;
        public ShowResult(ref MvJob job)
        {
            InitializeComponent();
            this.job = job;
            this.Text = $"Job: {job.Name}";
            disp = this.mvDisplayViewEdit1.Display;
            draw = new DrawShow(ref disp);
            this.mvDisplayViewEdit1.ClearImage();
            inter = new _internal();
            acti = inter.checkActive(); 
        }
        void runing()
        {

            while (threadLock)
            {
                //Console.WriteLine(job.Name);
                try
                {
                    this.mvDisplayViewEdit1.Invoke((Action)(() =>
                    {
                        this.mvDisplayViewEdit1.RefreshImage();


                    }));


                    foreach (MvToolBase tool in job.ToolList)
                    {

                        if (tool is MvToolBlock)
                        {
                            MvToolBlock tools = tool as MvToolBlock;
                            foreach (MvToolBase _tool in tools.ToolJob.ToolList)
                            {
                                this.mvDisplayViewEdit1.Invoke((Action)(() =>
                                {
                                    draw.CheckTool(_tool);

                                }));
                            }
                        }
                        else
                        {
                            this.mvDisplayViewEdit1.Invoke((Action)(() =>
                            {
                                draw.CheckTool(tool);

                            }));
                        }
                    }
                    this.mvDisplayViewEdit1.Invoke((Action)(() =>
                    {
                        //mvDisplayViewEdit1.Invalidate();
                        //mvDisplayViewEdit1.Update();
                    }));
                    this.lbl_RunTime.Invoke((Action)(() =>
                    {
                        lbl_RunTime.Invoke((Action)(() => { lbl_RunTime.Text = $"{job.LastRunTime} ms"; }));
                    }));
                    Thread.Sleep(10);
                }
                catch (Exception)
                {
                }
            }

            //Thread.Sleep(300);
        }

        private void btn_Run_Click(object sender, EventArgs e)
        {

                
           
        }

        private void _tcp_eventReciverHandler(object sender, string Data)
        {
            
            if ((Data.Contains("HE") || Data.Contains("TT") || Data.Contains("XT") || Data.Contains("RF")) && acti)
            {
                try
                {
                    job.Run();
                    this.mvDisplayViewEdit1.Invoke((Action)(() =>
                    {
                        this.mvDisplayViewEdit1.RefreshImage();


                    }));
                    foreach (MvToolBase tool in job.ToolList)
                    {

                        if (tool is MvToolBlock)
                        {
                            MvToolBlock tools = tool as MvToolBlock;
                            foreach (MvToolBase _tool in tools.ToolJob.ToolList)
                            {
                                this.mvDisplayViewEdit1.Invoke((Action)(() =>
                                {
                                    draw.CheckTool(_tool);

                                }));
                            }
                        }
                        else
                        {
                            this.mvDisplayViewEdit1.Invoke((Action)(() =>
                            {
                                draw.CheckTool(tool);

                            }));
                        }
                    }
                    this.mvDisplayViewEdit1.Invoke((Action)(() =>
                    {
                        //mvDisplayViewEdit1.Invalidate();
                        //mvDisplayViewEdit1.Update();
                    }));
                    this.lbl_RunTime.Invoke((Action)(() =>
                    {
                        lbl_RunTime.Invoke((Action)(() => { lbl_RunTime.Text = $"{job.LastRunTime} ms"; }));
                    }));
                    Thread.Sleep(10);
                }
                catch (Exception)
                {
                }
            }
        }

        private void ShowResult_FormClosing(object sender, FormClosingEventArgs e)
        {
            //threadLock = false;
            //if (th != null)
            //{
            //    th.Join(100);
            //    th = null;
            //    status = false;
            //}
            acq.closeCamList();

            if (tcp != null && tcp.tcpServer != null) { tcp.tcpServer.ReciverEvent -= _tcp_eventReciverHandler; tcp.tcpServer.Close(); tcp.tcpServer = null; }
            if (tcp != null && tcp.tcpClient != null) { tcp.tcpClient.ReciverEvent -= _tcp_eventReciverHandler; tcp.tcpClient.Close(); tcp.tcpClient = null; }
           
            
        }

        private void ShowResult_Load(object sender, EventArgs e)
        {
            foreach (MvToolBase tool in job.ToolList)
            {

                
                if (tool is MvToolBlock)
                {
                    MvToolBlock tools = tool as MvToolBlock;
                    foreach (MvToolBase _tool in tools.ToolJob.ToolList)
                    {
                        if (tool is MvTCP)
                        {
                            tcp = tool as MvTCP;
                            tcp.Run();
                            if (tcp != null && tcp.tcpServer != null && tcp.tcpServer.connectStatus == true) { tcp.tcpServer.ReciverEvent += _tcp_eventReciverHandler; }
                            if (tcp != null && tcp.tcpClient != null && tcp.tcpClient.connectStatus == true) { tcp.tcpClient.ReciverEvent += _tcp_eventReciverHandler; }
                           
                        }
                        else if (tool is MvAcquisition)
                        {
                            acq = tool as MvAcquisition;
                        }
                    }
                }
                else
                {
                    if (tool is MvTCP)
                    {
                        tcp = tool as MvTCP;
                        tcp.Run();
                        if (tcp != null && tcp.tcpServer != null && tcp.tcpServer.connectStatus == true) { tcp.tcpServer.ReciverEvent += _tcp_eventReciverHandler; ; }
                        if (tcp != null && tcp.tcpClient != null && tcp.tcpClient.connectStatus == true) { tcp.tcpClient.ReciverEvent += _tcp_eventReciverHandler; }
                       
                    }
                    else if (tool is MvAcquisition)
                    {
                        acq = tool as MvAcquisition;
                    }
                }
            }
        }
    }
}
