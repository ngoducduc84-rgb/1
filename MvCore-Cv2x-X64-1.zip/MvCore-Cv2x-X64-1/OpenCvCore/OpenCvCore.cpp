﻿#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui_c.h>
#include <vector>
#include <windows.h>

using namespace cv;
using namespace std;



#pragma region edge base
#pragma region Edge

struct vecResult
{
	double Score, Angle;
	cv::Point MaxLoc;
	cv::Point recTL;
	cv::Point contour;
	vector<vector<Point>> contours;
	vecResult()
	{
		Score = 0;
		Angle = 0;
		MaxLoc = Point(0, 0);
		recTL = Point(0, 0);
		contour = Point(0, 0);
	}
};

struct  mResult
{
	double x;
	double y;
	double score;
	double angle;
	vector<vector<Point>> contours;
	mResult()
	{
	}
	mResult(double _x, double _y, double _score, double _angle)
	{
		x = _x;
		y = _y;
		score = _score;
		angle = _angle;
		contours = vector < vector<Point>>();
	}
};

struct  matchResult
{
	double x;
	double y;
	double score;
	double angle;
};

struct DPoint
{
public:
	double x;
	double y;

	DPoint() : x(0), y(0) {}   // ✔ default constructor
	DPoint(double x, double y)
	{
		this->x = x;
		this->y = y;
	}
	DPoint operator+(const DPoint& other) const
	{
		return DPoint(x + other.x, y + other.y);
	}
	DPoint operator-(const DPoint& other) const
	{
		return DPoint(x - other.x, y - other.y);
	}
	DPoint operator*(double k) const
	{
		return DPoint(x * k, y * k);
	}
	bool operator==(const DPoint& other) const
	{
		return x == other.x && y == other.y;
	}
	// --- ÉP KIỂU TỪ DPoint → cv::Point2d ---
	operator cv::Point2d() const
	{
		return cv::Point2d(x, y);
	}

	// --- ÉP KIỂU TỪ cv::Point2d → DPoint ---
	DPoint(const cv::Point2d& p)
	{
		x = p.x;
		y = p.y;
	}
	// Ép kiểu sang cv::Point (int)
	operator cv::Point() const
	{
		return cv::Point((int)x, (int)y);
	}
	// Ép kiểu từ cv::Point (int) → DPoint
	DPoint(const cv::Point& p)
	{
		x = p.x;
		y = p.y;
	}

};

struct ImageBuffer
{

	unsigned char* data;
	int width;
	int height;
	int channels;

};

struct PointInfo
{
public:

	Point2d Point;
	Point2d Center;
	Point2d Offset;
	Point2d Derivative;
	double Magnitude;
	double Direction;
	double Angle;
	vector<vector<cv::Point>> contours;

	PointInfo() {};
	void Update(Point2d _center)
	{
		Center = _center;
		Offset = Point2d(Point.x - _center.x, Point.y - _center.y);
	}
};
struct PointTrain
{
	vector<PointInfo> Points;
	vector<vector<cv::Point>> contours;
};
#pragma endregion

Mat Image2Mat(ImageBuffer* img)
{
	/*int size = img->width * img->height * img->channels;

	unsigned char* p = img->data;*/

	cv::Mat imgMat;

	if (img->channels == 1)
	{
		imgMat = cv::Mat(img->height, img->width, CV_8UC1, img->data);
		//OutputDebugStringA("111");
		/*MessageBoxA(NULL, "1", "Debug", MB_OK);*/
	}
	else if (img->channels == 3)
	{
		imgMat = cv::Mat(img->height, img->width, CV_8UC3, img->data);
		/*MessageBoxA(NULL, "3", "Debug", MB_OK);*/
	}
	else if (img->channels == 4)
	{
		imgMat = cv::Mat(img->height, img->width, CV_8UC4, img->data);
		/*MessageBoxA(NULL, "4", "Debug", MB_OK);*/
	}

	return imgMat.clone();
}


#pragma region Variable

vector<vector<vector<PointInfo>>> vecTrain;
vector<vecResult> all_Results4;

std::mutex mtx; // Mutex để đồng bộ hóa truy cập vào all_Results

//double MinScore = 0.98;
double Greediness = 0.9;
int threshMin = 0;
int threshMax = 255;
double angleMin = -179.9;
double angleMax = 179.9;
int KSize = 1;

//extern double m_dEdgeThresh1 = 130;
//extern double m_dEdgeThresh2 = 250;
#pragma endregion
mResult match_Template(Mat m_Src, Mat m_Dst);
vecResult MatchSearch(Mat seachImage, vector<PointInfo> results, double angle);
PointTrain TrainTemplate(Mat dst, double angle = 0);
mResult match_Edge(Mat m_Src, Mat m_Dst);
cv::Mat rotateMat(const cv::Mat source, double angle);
Mat ToGray(Mat input);

extern "C" __declspec(dllexport)
void FreeMemory(void* ptr)
{
	free(ptr);
}
extern "C" __declspec(dllexport)
void FreeContours(DPoint* ptr)
{
	free(ptr);
}
//////cách 1
//extern "C" __declspec(dllexport) DPoint* MatchEdge(ImageBuffer* img, ImageBuffer* tem, matchResult* result, int* count1,int* count2, int _threshMin, int _threshMax, double _angleMin, double _angleMax)
//{
//	Mat graySrc, grayDst;
//	Mat src = Image2Mat(img);
//	Mat dst = Image2Mat(tem);
//	threshMin = _threshMin;
//	threshMax = _threshMax;
//	angleMin = _angleMin;
//	angleMax = _angleMax;
//	if (src.channels() != 1) { cv::cvtColor(src, graySrc, COLOR_BGR2GRAY); }else { src.copyTo(graySrc); }
//	if (dst.channels() != 1) { cv::cvtColor(dst, grayDst, COLOR_BGR2GRAY); }else { dst.copyTo(grayDst); }
//	//MessageBoxA(NULL, std::to_string(threshMin).c_str(), "threshMin", MB_OK);
//	//MessageBoxA(NULL, std::to_string(threshMax).c_str(), "threshMax", MB_OK);
//	mResult res = match_Edge(graySrc, grayDst);
//	result->angle = res.angle;
//	result->score = res.score;
//	result->x = res.x;
//	result->y = res.y;
//
//	*count1 = res.contours.size();
//	*count2 = res.contours.size();
//	DPoint* arr = (DPoint*)malloc(sizeof(DPoint) * (*count));
//	for (int i = 0; i < *count; i++)
//		arr[i] = res.contours[i];
//	return arr;
//
//	/*strcpy_s(pt->h, "Hello C#");*/
//
//}
//extern "C" __declspec(dllexport)
//void MatchEdge(ImageBuffer* img, ImageBuffer* tem, matchResult* result,
//	DPoint** pointsOut,     // flattened array
//	int** sizesOut,         // size of each contour
//	int* contourCountOut,   // number of contours
//	int* totalPointsOut,    // total points
//	int _threshMin,
//	int _threshMax,
//	double _angleMin,
//	double _angleMax)
//{
//	Mat graySrc, grayDst;
//	Mat src = Image2Mat(img);
//	Mat dst = Image2Mat(tem);
//	threshMin = _threshMin;
//	threshMax = _threshMax;
//	angleMin = _angleMin;
//	angleMax = _angleMax;
//	graySrc = ToGray(src);
//	grayDst = ToGray(dst);
//	mResult res = match_Edge(graySrc, grayDst);
//	
//	result->angle = res.angle;
//	result->score = res.score;
//	result->x = res.x;
//	result->y = res.y;
//	
//	int contourCount = res.contours.size();
//	*contourCountOut = contourCount;
//	
//	////// --- Đếm tổng số điểm ---
//	int total = 0;
//	for (auto& c : res.contours)
//		total += (int)c.size();
//	*totalPointsOut = total;
//	
//	//////// --- Cấp phát bộ nhớ trả về C# ---
//	DPoint* pts = (DPoint*)malloc(sizeof(DPoint) * total);
//	int* sizes = (int*)malloc(sizeof(int) * contourCount);
//	
//	int index = 0;
//	for (int i = 0; i < contourCount; i++)
//	{
//		sizes[i] = res.contours[i].size();
//		for (auto& p : res.contours[i])
//		{
//			pts[index].x = p.x;
//			pts[index].y = p.y;
//			index++;
//		}
//	}
//	
//	*pointsOut = pts;
//	*sizesOut = sizes;
//	
//}

extern "C" __declspec(dllexport)
void MatchEdge(ImageBuffer* img, ImageBuffer* tem, matchResult* result,
	DPoint** pointsOut,
	int** sizesOut,
	int* contourCountOut,
	int* totalPointsOut,
	int _threshMin,
	int _threshMax,
	double _angleMin,
	double _angleMax)
{
	Mat graySrc, grayDst;
	Mat src = Image2Mat(img);
	Mat dst = Image2Mat(tem);

	graySrc = ToGray(src);
	grayDst = ToGray(dst);
	threshMin = _threshMin;
	threshMax = _threshMax;
	angleMin = _angleMin;
	angleMax = _angleMax;
	mResult res = mResult(0, 0, 0, 0);
	res = match_Edge(graySrc, grayDst);

	// Copy template match result
	result->angle = res.angle;
	result->score = res.score;
	result->x = res.x;
	result->y = res.y;

	// Count contours
	int contourCount = (int)res.contours.size();
	*contourCountOut = contourCount;

	// No contours => return null pointers
	if (contourCount == 0)
	{
		*totalPointsOut = 0;
		*pointsOut = nullptr;
		*sizesOut = nullptr;
		return;
	}

	// Count total points
	int total = 0;
	for (auto& c : res.contours) {
		total += (int)c.size();
	}
	*totalPointsOut = total;

	if (total == 0)
	{
		*pointsOut = nullptr;
		*sizesOut = nullptr;
		return;
	}

	// Allocate memory
	DPoint* pts = (DPoint*)malloc(sizeof(DPoint) * total);
	int* sizes = (int*)malloc(sizeof(int) * contourCount);

	if (!pts || !sizes) {
		// Allocation failed
		if (pts) free(pts);
		if (sizes) free(sizes);
		*pointsOut = nullptr;
		*sizesOut = nullptr;
		*totalPointsOut = 0;
		*contourCountOut = 0;
		return;
	}

	// Fill data
	int index = 0;
	for (int i = 0; i < contourCount; i++)
	{
		sizes[i] = (int)res.contours[i].size();

		for (auto& p : res.contours[i])
		{
			pts[index].x = p.x;
			pts[index].y = p.y;
			index++;
		}
	}

	*pointsOut = pts;
	*sizesOut = sizes;
}





//***************************************************************************************






//ve 1 diem
Mat drawDot(cv::Mat src, Point point, Scalar color, int lineWidth)
{
	line(src, point, point, color, lineWidth);
	return src;
}

Point2f rotate(Point2f p, double cx, double cy, double theta) {
	double s = sin(theta);
	double c = cos(theta);

	// Dịch chuyển điểm về gốc
	p.x -= cx;
	p.y -= cy;

	// Xoay điểm
	double xnew = p.x * c - p.y * s;
	double ynew = p.x * s + p.y * c;

	// Dịch chuyển điểm trở lại
	p.x = xnew + cx;
	p.y = ynew + cy;

	return p;
}

//xoay ảnh không bị cắt xoay vua bang khung xoay
cv::Mat rotateMat(const cv::Mat source, double angle) {
	// Lấy kích thước ảnh gốc
	int w = source.cols;
	int h = source.rows;
	cv::Point2f center(w / 2.0, h / 2.0);

	// Tạo ma trận xoay
	cv::Mat rotationMatrix = cv::getRotationMatrix2D(center, angle, 1.0);

	// Tính toán kích thước mới của ảnh sau khi xoay
	double absCos = std::abs(rotationMatrix.at<double>(0, 0));
	double absSin = std::abs(rotationMatrix.at<double>(0, 1));
	int boundW = int(h * absSin + w * absCos);
	int boundH = int(h * absCos + w * absSin);

	// Điều chỉnh ma trận xoay để dịch chuyển ảnh vào trung tâm
	rotationMatrix.at<double>(0, 2) += boundW / 2.0 - center.x;
	rotationMatrix.at<double>(1, 2) += boundH / 2.0 - center.y;

	// Xoay ảnh và trả về kết quả
	cv::Mat rotated;
	cv::warpAffine(source, rotated, rotationMatrix, cv::Size(boundW, boundH), INTER_LINEAR, BORDER_REPLICATE);
	return rotated;
}

// Hàm tính vùng bao quanh khi xoay hình chữ nhật
cv::Rect calculateBoundingBox(double x1, double y1, double x2, double y2, double theta) {
	// Tính tâm của hình chữ nhật
	double cx = (x1 + x2) / 2.0;
	double cy = (y1 + y2) / 2.0;

	// Các đỉnh của hình chữ nhật ban đầu
	Point2f p1 = Point2f(x1, y1);
	Point2f p2 = Point2f(x1, y2);
	Point2f p3 = Point2f(x2, y1);
	Point2f p4 = Point2f(x2, y2);

	// Xoay các đỉnh
	p1 = rotate(p1, cx, cy, theta);
	p2 = rotate(p2, cx, cy, theta);
	p3 = rotate(p3, cx, cy, theta);
	p4 = rotate(p4, cx, cy, theta);

	// Tìm các giá trị min và max cho vùng bao quanh
	float xmin = min(min(p1.x, p2.x), min(p3.x, p4.x));
	float xmax = max(max(p1.x, p2.x), max(p3.x, p4.x));
	float ymin = min(min(p1.y, p2.y), min(p3.y, p4.y));
	float ymax = max(max(p1.y, p2.y), max(p3.y, p4.y));

	Rect rect = Rect(xmin, ymin, xmax - xmin, ymax - ymin);
	return rect;
	//// In kết quả
	//std::cout << "Bounding Box: " << std::endl;
	//std::cout << "Min X: " << xmin << std::endl;
	//std::cout << "Max X: " << xmax << std::endl;
	//std::cout << "Min Y: " << ymin << std::endl;
	//std::cout << "Max Y: " << ymax << std::endl;
}

inline double baseMatch(Mat src, vector<PointInfo> results, int w, int h)
{



	int j = w;
	int i = h;
	Mat gx;
	Mat gy;
	Mat direction;
	Mat magnitude;
	//cv::cvtColor(seachImage, src, COLOR_RGB2GRAY);

	int MinThresh = 0, MaxThresh = 255;

	double minScore = 0.01;
	double greediness = Greediness;
	//ncc match search
	//int noOfCordinates = (int)results.size();
	double normMinScore = minScore / (double)results.size(); //normalized min score
	double normGreediness = (1 - greediness * minScore) / (1 - greediness) / (double)results.size();
	double partialScore = 0;
	double resultScore = 0;
	double partialSum = 0;
	Point center;
	try {//time start
		cv::cvtColor(src, src, COLOR_RGB2GRAY);
		cv::Sobel(src, gx, CV_64F, 1, 0, 3);
		cv::Sobel(src, gy, CV_64F, 0, 1, 3);
		cv::cartToPolar(gx, gy, magnitude, direction);
	}
	catch (const std::exception ex) { cout << "base Match Error: " << ex.what() << endl; }
	//time stop = 70 ms
	for (int m = 0; m < results.size(); m++)
	{
		PointInfo item = results[m];
		int curX = (int)(j + item.Offset.x);
		int curY = (int)(i + item.Offset.y);
		double iTx = item.Derivative.x;
		double iTy = item.Derivative.y;
		if (curX <0 || curY <0 || curY> src.rows - 1 || curX > src.cols - 1)
		{
			continue;
		}
		double iSx = gx.at<double>(curY, curX, 0);
		double iSy = gy.at<double>(curY, curX, 0);
		if ((iSx != 0 || iSy != 0) && (iTx != 0 || iTy != 0))
		{
			double mag = magnitude.at<double>(curY, curX, 0);
			double matGradMag = mag == 0 ? 0 : 1 / mag;// 1/√(dx²+dy²)
			partialSum += ((iSx * iTx) + (iSy * iTy)) * (item.Magnitude * matGradMag);
		}
		int sumOfCoords = m + 1;
		partialScore = partialSum / sumOfCoords;
		/*if (partialScore < min((minScore - 1) + normGreediness * sumOfCoords, normMinScore * sumOfCoords))
		{
			break;
		}*/
	}
	clock_t finish_time1 = clock();
	src.release();
	gx.release();
	gy.release();
	direction.release();
	magnitude.release();
	return partialScore;
}

PointTrain TrainTemplate(Mat dst, double angle)
{

	try
	{
		PointTrain res;
		/*Mat dst = _dst.clone();*/
		/*vector<PointInfo> results;*/
	/*	results.clear();*/
		vector<vector<Point>> contours;
		contours.clear();
		vector<Vec4i> hierarchy;

		Mat output;
		register cv::Mat gx;
		register cv::Mat gy;
		register cv::Mat magnitude;
		register cv::Mat direction;
		double areaMax;
		int index = 0;
		int indexMax = 0;
		Point2d sum = Point2d(0, 0);
		Point2d _center;


		//Mat gray, bin;

		//if (rot.channels() == 1)
		//{
		//	rot.copyTo(gray);
		//}
		//else if (rot.channels() == 3)
		//{
		//	cv::cvtColor(rot, gray, COLOR_RGB2GRAY);
		//}
		//else if (rot.channels() == 4)
		//{
		//	cv::cvtColor(rot, gray, COLOR_BGRA2GRAY);
		//}
		//threshold(gray, bin, threshMin, threshMax, CV_THRESH_BINARY | THRESH_OTSU);
		//dst = bin.clone();


		//dst = rotateMat(cvtemplate, angle);
		//if (dst.channels() == 1)
		//{
		//	//dst.copyTo(dst);
		//}
		//else if (dst.channels() == 3)
		//{
		//	cv::cvtColor(dst, dst, COLOR_RGB2GRAY);
		//}
		//else if (dst.channels() == 4)
		//{
		//	cv::cvtColor(dst, dst, COLOR_BGRA2GRAY);
		//}
		/*MessageBoxA(NULL, std::to_string(threshMin).c_str(), "threshMin", MB_OK);
		MessageBoxA(NULL,std::to_string(threshMax).c_str(), "threshMax", MB_OK);*/
		Mat rot = rotateMat(dst, angle);
		cv::Canny(rot, output, threshMin, threshMax, 3, false);
		cv::findContours(output, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
		cv::Sobel(rot, gx, CV_64F, 1, 0, KSize);
		cv::Sobel(rot, gy, CV_64F, 0, 1, KSize);
		cv::cartToPolar(gx, gy, magnitude, direction);

		if (contours.empty())
			return {};
		for (int i = 0; i < contours.size(); i++)
		{
			for (int j = 0; j < contours[i].size(); j++)
			{

				Point2d cur = contours[i][j];
				double fdx = gx.at<double>(cur.y, cur.x);//dx
				double fdy = gy.at<double>(cur.y, cur.x);//dy
				Point2d der = Point2d(fdx, fdy);//(dx,dy)
				double mag = magnitude.at<double>(cur.y, cur.x); // √(dx²+dy²)
				double dir = direction.at<double>(cur.y, cur.x); // atan2(dy,dx)
				PointInfo pi;
				pi.Point = cur,
					pi.Derivative = der,
					pi.Direction = dir,
					pi.Magnitude = mag == 0 ? 0 : 1 / mag;
				res.Points.push_back(pi);
				sum += (Point2d)cur;
				//OutputDebugString((L"sum X: " + to_wstring(sum.x) + L"sum Y: " + to_wstring(sum.y) + L"\n").c_str());

			}

		}

		_center.x = (sum.x / res.Points.size());
		_center.y = (sum.y / res.Points.size());


		for (int i = 0; i < res.Points.size(); i++)
		{
			res.Points[i].Center = _center;
			res.Points[i].Offset = res.Points[i].Point - _center;
		}
		res.contours = contours;

		/*cvtColor(dst, dst, COLOR_GRAY2RGB);
		cv::drawContours(dst, contours, -1, Scalar(0, 255, 0), 1);
		for (int i = 0; i < contours.size(); i++)
		{
			cv::drawContours(dst, contours,i, Scalar(0, 255, 0), 1);
		}
		cv::circle(dst, _center, 2, cv::Scalar(0, 255, 0), -1);
		cv::imshow("Template", dst);
		waitKey(1000);*/


		return res;
	}
	catch (const std::exception ex) { cout << "Train Error: " << ex.what() << endl; return {}; }

}

vecResult MatchSearch(Mat src, PointTrain temPoints, double angle)
{

	//clock_t start_time1 = clock();
	/*Mat src = _src.clone();*/
	register Mat gx;
	register Mat gy;
	register Mat direction;
	register Mat magnitude;
	auto minScore = 0.01;
	auto greediness = Greediness;
	vecResult result = vecResult();

	//ncc match search
	//int noOfCordinates = (int)temPoints.size();
	double normMinScore = minScore / (double)temPoints.Points.size(); //normalized min score
	double normGreediness = (1 - greediness * minScore) / (1 - greediness) / (double)temPoints.Points.size();
	double partialScore = 0;
	double resultScore = 0;



	try
	{
		if (src.empty() == false)
		{


			//Mat gray, bin;
			//
			//if (seachImage.channels() == 1)
			//{
			//	seachImage.copyTo(gray);
			//}
			//else if (seachImage.channels() == 3)
			//{
			//	cv::cvtColor(seachImage, gray, COLOR_RGB2GRAY);
			//}
			//else if (seachImage.channels() == 4)
			//{
			//	cv::cvtColor(seachImage, gray, COLOR_BGRA2GRAY);
			//}
			//threshold(gray, bin, threshMin, threshMax, THRESH_BINARY | THRESH_OTSU);
			/*src = bin.clone();*/

			/*if (seachImage.channels() == 1)
			{
				seachImage.copyTo(src);
			}
			else if (seachImage.channels() == 3)
			{
				cv::cvtColor(seachImage, src, COLOR_RGB2GRAY);
			}
			else if (seachImage.channels() == 4)
			{
				cv::cvtColor(seachImage, src, COLOR_BGRA2GRAY);
			}*/

			cv::Sobel(src, gx, CV_64F, 1, 0, KSize);
			cv::Sobel(src, gy, CV_64F, 0, 1, KSize);
			cv::cartToPolar(gx, gy, magnitude, direction);
			clock_t start_time1 = clock();
			for (int i = 0, h = src.rows; i < h; i++)
			{
				for (int j = 0, w = src.cols; j < w; j++)
				{
					double partialSum = 0;
					for (int m = 0; m < temPoints.Points.size(); m++)
					{
						PointInfo item = temPoints.Points[m];
						int curX = (int)(j + item.Offset.x);
						int curY = (int)(i + item.Offset.y);
						double iTx = item.Derivative.x;
						double iTy = item.Derivative.y;
						if (curX <0 || curY <0 || curY> src.rows - 1 || curX > src.cols - 1)
						{
							continue;
						}
						double iSx = gx.at<double>(curY, curX);
						double iSy = gy.at<double>(curY, curX);
						if ((iSx != 0 || iSy != 0) && (iTx != 0 || iTy != 0))
						{
							double mag = magnitude.at<double>(curY, curX);
							double matGradMag = mag == 0 ? 0 : 1 / mag;// 1/√(dx²+dy²)
							partialSum += ((iSx * iTx) + (iSy * iTy)) * (item.Magnitude * matGradMag);
						}
						int sumOfCoords = m + 1;
						partialScore = partialSum / sumOfCoords;
						if (partialScore < min((minScore - 1) + normGreediness * sumOfCoords, normMinScore * sumOfCoords))
						{
							break;
						}
					}
					if (partialScore > result.Score)
					{
						//OutputDebugString((L"Score: " + to_wstring(partialScore) + L" X: " + to_wstring(j) + L" Y: " + to_wstring(i) + L"\n").c_str());
						result.Score = partialScore;
						result.Angle = angle;
						result.MaxLoc = Point(j, i);

					}
				}
			}

			result.contours.resize(temPoints.contours.size());
			for (int i = 0; i < temPoints.contours.size(); i++)
			{
				for (int j = 0; j < temPoints.contours[i].size(); j++)
				{
					result.contours[i].push_back(temPoints.contours[i][j] + (result.MaxLoc - (Point)temPoints.Points[i].Center));
				}
			}


			//result.contours = temPoints.contours;
			/*result.contours.resize(1);*/
			//for (int i = 0; i < temPoints.Points.size(); i++)
			//{
			//	result.contours.at(0).push_back((Point)temPoints.Points[i].Point + (result.MaxLoc - (Point)temPoints.Points[i].Center));
			//	/*src = drawDot(src, (Point)contours[0][i], Scalar(0, 255, 0), 1);*/
			//}

			/*
			/*	cv::circle(src, center, 2, Scalar(0, 0, 255), -1);*/
			/*result.Score = resultScore;
			result.contours = contours;
			result.Angle = angle;
			result.MaxLoc = center;*/
			/*	if (src.rows > 1902 || src.cols > 1080)
				{
					resize(src, src, cv::Size(1902, 1080));
				}*/
			clock_t finish_time1 = clock();
			double total_time = ((double)finish_time1 - (double)start_time1) / CLOCKS_PER_SEC;
			//OutputDebugString((L"MatchSeach time: " + to_wstring(total_time * 1000) + L" ms" + L"\n").c_str());
			/*cv::imshow("seach Image result", src);
			cv::waitKey(1);*/
			//OutputDebugString((L"Score: " + to_wstring(resultScore) + L"   Angle: " + to_wstring(angle)+L"\n").c_str());

			/*for each (auto value in vecResult)
			{
				OutputDebugString((L"Score: " + to_wstring(value.Score) + L" X: " + to_wstring(value.MaxLoc.x) + L" Y: " + to_wstring(value.MaxLoc.y) + L"\n").c_str());
			}*/
		}
		return result;
	}
	catch (const std::exception ex) { cout << "Match Seach Error: " << ex.what() << endl; }

	return result;
}

void Process(Mat _src, Mat _dst, vector<vecResult>* all_result, double angle)
{
	//clock_t start_time1 = clock();
	PointTrain pointTrain = TrainTemplate(_dst, angle);
	//MessageBoxW(NULL, std::to_wstring(trainRes.size()).c_str(), std::to_wstring(angle).c_str(), 0);
	vecResult result = MatchSearch(_src, pointTrain, angle);
	std::lock_guard<std::mutex> lock(mtx); // Khóa mutex khi truy cập all_Results
	all_result->push_back(result);
	/*clock_t finish_time1 = clock();
	double total_time = ((double)finish_time1 - (double)start_time1) / CLOCKS_PER_SEC;
	OutputDebugString((L"Process Seach time: " + to_wstring(total_time * 1000) + L" ms" + L"\n").c_str());*/
}

mResult match_Edge(Mat m_Src, Mat m_Dst)
{
	mResult _result;
	try
	{

		/*	int channels = m_Src.channels();
			int channels2 = m_Dst.channels();*/
			/*vector<vector<double>> results;*/

		vector<vecResult> all_Results;
		clock_t start_time1 = clock();
		//vector<cv::Rect> vecRect;
		cv::Rect roi = Rect(0, 0, 0, 0);
		bool check = true;
		double Score = 0.001;
		double stepAngle = 1;
		int layerPyramid = 2;//GetTopLayer(&m_Dst, (int)sqrt((double)264));;
		std::vector<std::thread> threads1;
		std::vector<std::thread> threads2;
		std::vector<std::thread> threads3;
		std::vector<std::thread> threads4;

		register vector<Mat> m_SrcPyramid;
		register vector<Mat> m_DstPyramid;
		Mat croppedImage, src_Copy;
		//std::string m_SrcPath = CT2A(m_m_SrcPath);
		//std::string m_DstPath = CT2A(m_m_DstPath);
		/*Mat m_Src = imread(m_SrcPath, IMREAD_ANYCOLOR);
		Mat m_Dst = imread(m_DstPath, IMREAD_ANYCOLOR);*/

		////tạo ngưỡng nhị phân
		//cv::threshold(m_Src, src_Copy, threshMin, threshMax, THRESH_BINARY);
		//cv::threshold(m_Dst, m_Dst, threshMin, threshMax, THRESH_BINARY);
		/*imshow("src", src_Copy);
		imshow("dst", m_Dst);
		waitKey(1000);*/
		//tạo kim tự tháp hình ảnh
		cv::buildPyramid(m_Src, m_SrcPyramid, layerPyramid);
		cv::buildPyramid(m_Dst, m_DstPyramid, layerPyramid);





		//creart thread tìm kiếm trong lớp đỉnh kim tự tháp
		for (double angle = angleMin; angle < angleMax; angle = angle += stepAngle) {
			threads1.emplace_back(std::thread(Process, m_SrcPyramid[layerPyramid], m_DstPyramid[layerPyramid], &all_Results, angle));
		}
		//run thread
		for (auto& t : threads1) {
			//t.detach();
			t.join();
		}
		//sắp xếp vector theo giá trị Score
		sort(all_Results.begin(), all_Results.end(), [](vecResult& a, vecResult& b) { return a.Score > b.Score; });
		//tạo vùng Roi với giá trị lớn nhất
		for (int j = layerPyramid; j >= 0; j--)
		{
			double x1, y1, x2, y2;
			double angle = all_Results[0].Angle;
			double radian = angle * (3.14 / 180);
			double adj = ((layerPyramid - j + 1) * 2) * 5;
			if (layerPyramid - j == 0)
			{
				y1 = all_Results[0].MaxLoc.y - (m_DstPyramid[j].rows / 2);
				x2 = all_Results[0].MaxLoc.x - (m_DstPyramid[j].cols / 2) + m_DstPyramid[j].cols;
				y2 = all_Results[0].MaxLoc.y - (m_DstPyramid[j].rows / 2) + m_DstPyramid[j].rows;
				x1 = all_Results[0].MaxLoc.x - (m_DstPyramid[j].cols / 2);
			}
			else
			{
				x1 = all_Results[0].MaxLoc.x * ((layerPyramid - j) * 2) - (m_DstPyramid[j].cols / 2);
				y1 = all_Results[0].MaxLoc.y * ((layerPyramid - j) * 2) - (m_DstPyramid[j].rows / 2);
				x2 = all_Results[0].MaxLoc.x * ((layerPyramid - j) * 2) - (m_DstPyramid[j].cols / 2) + m_DstPyramid[j].cols;
				y2 = all_Results[0].MaxLoc.y * ((layerPyramid - j) * 2) - (m_DstPyramid[j].rows / 2) + m_DstPyramid[j].rows;
			}
			roi = calculateBoundingBox(x1 - adj, y1 - adj, x2 + adj, y2 + adj, radian);
			//vecRect.push_back(roi);
		}
		if (all_Results.empty() == true) { return {}; }

		//sắp xếp vector theo giá trị Score
		sort(all_Results.begin(), all_Results.end(), [](vecResult& a, vecResult& b) { return a.Score > b.Score; });

		//cắt ảnh (đáy kim tự tháp) //error(if use mutil thread(error color))
		if (m_SrcPyramid[0].cols - (roi.x + roi.width) <= 0 || m_SrcPyramid[0].rows - (roi.y + roi.height) <= 0) { return {}; }
		//cvtColor(m_SrcPyramid[0], m_SrcPyramid[0], COLOR_GRAY2BGR);
		croppedImage = m_SrcPyramid[0](roi);
		// chạy với góc xoay 0.1;
		for (double angle = +all_Results[0].Angle - (stepAngle / 2); angle < all_Results[0].Angle + (stepAngle / 2); angle += 0.1) {
			//threads.emplace_back(std::thread(processImage, std::ref(image)));
			threads2.emplace_back(std::thread(Process, croppedImage, m_DstPyramid[0], &all_Results, angle));
		}

		all_Results.clear();
		//run thread
		for (auto& t : threads2) {
			//t.detach();
			t.join();
		}


		//sắp xếp vector theo giá trị Score
		sort(all_Results.begin(), all_Results.end(), [](vecResult& a, vecResult& b) { return a.Score > b.Score; });
		//clock_t start_time1 = clock();
		// chạy với góc xoay 0.01;
		for (double angle = +all_Results[0].Angle - (stepAngle / 20); angle < all_Results[0].Angle + (stepAngle / 20); angle += 0.01) {
			//OutputDebugString((L"Angle: " + to_wstring(angle) + L"\n").c_str());
			threads3.emplace_back(std::thread(Process, croppedImage, m_DstPyramid[0], &all_Results, angle));
		}
		all_Results.clear();
		//run thread
		for (auto& t : threads3) {
			//t.detach();
			t.join();
		}

		//sắp xếp vector theo giá trị Score
		sort(all_Results.begin(), all_Results.end(), [](vecResult& a, vecResult& b) { return a.Score > b.Score; });

		if (check == true)
		{
			// chạy với góc xoay 0.001;
			for (double angle = +all_Results[0].Angle - (stepAngle / 200); angle < all_Results[0].Angle + (stepAngle / 200); angle += 0.001) {
				//OutputDebugString((L"Angle: " + to_wstring(angle) + L"\n").c_str());
				threads4.emplace_back(std::thread(Process, croppedImage, m_DstPyramid[0], &all_Results, angle));
			}
			all_Results.clear();
			//run thread
			for (auto& t : threads4) {
				//t.detach();
				t.join();
			}
			//sắp xếp vector theo giá trị Score
			sort(all_Results.begin(), all_Results.end(), [](vecResult& a, vecResult& b) { return a.Score > b.Score; });
		}

		//trả lại giá trị location khi chưa cắt;
		all_Results[0].MaxLoc.x += roi.tl().x;
		all_Results[0].MaxLoc.y += roi.tl().y;
		Point offset = roi.tl();
		if (all_Results.size() == 0)
		{
			_result = mResult(0, 0, 0, 0);
		}
		_result.x = all_Results[0].MaxLoc.x;
		_result.y = all_Results[0].MaxLoc.y;
		_result.score = all_Results[0].Score;
		_result.angle = all_Results[0].Angle;




		/*memcpy(_result.contours,all_Results[0].contours[0].data(),all_Results[0].contours[0].size() * sizeof(DPoint));
		_result.contourCount = all_Results[0].contours[0].size();*/



		//OutputDebugString((L"Score: " + to_wstring(all_Results[0].Score) + L" Angle: " + to_wstring(all_Results[0].Angle) + L" X: " + to_wstring(all_Results[0].MaxLoc.x) + L" Y: " + to_wstring(all_Results[0].MaxLoc.y) + L"\n").c_str());
		//clock_t finish_time1 = clock();
		/*double total_time = ((double)finish_time1 - (double)start_time1) / CLOCKS_PER_SEC;*/
		//OutputDebugString((L"Seach time: " + to_wstring(total_time * 1000) + L" ms" + L"\n").c_str());
		/*cv::putText(m_Src, "Run Time: " + to_string(total_time * 1000), Point(10, 80), cv::FONT_HERSHEY_SIMPLEX, 1, Scalar(0, 255, 0), 2);*/
		if (all_Results[0].Score > Score)
		{
			//cv::circle(m_Src, all_Results[0].MaxLoc, 2, Scalar(0, 255, 0), -1);
			//string text = "Score: " + to_string(all_Results[0].Score) + " Angle: " + to_string(all_Results[0].Angle) + " X:" + to_string(all_Results[0].MaxLoc.x) + " Y:" + to_string(all_Results[0].MaxLoc.y);
			//cv::putText(m_Src, text, Point(10, 40), cv::FONT_HERSHEY_SIMPLEX, 1, Scalar(0, 255, 0), 2);

			_result.contours.resize(all_Results[0].contours.size());
			for (int j = 0; j < all_Results[0].contours.size(); ++j)
			{
				for (const auto& p : all_Results[0].contours[j])
					_result.contours[j].push_back(p + offset);
			}
		}
		//else
		//{
		//	string text = "No Match";
		//	cv::putText(m_Src, text, Point(10, 40), cv::FONT_HERSHEY_SIMPLEX, 1, Scalar(0, 255, 0), 2);
		//}
		//if (m_Src.rows > 1902 || m_Src.cols > 1080)
		//{
		//	resize(m_Src, m_Src, cv::Size(1902, 1080));
		//}

	/*	cv::imshow("result", m_Src);
		cv::waitKey(5000);*/

		m_SrcPyramid.clear();
		m_DstPyramid.clear();
		all_Results.clear();
		croppedImage.release();
		m_Dst.release();
		roi.empty();
		all_Results.clear();
		m_Src.release();
		return _result;
	}
	catch (const std::exception ex) { cout << "Match Edge Error: " << ex.what() << endl; }
}
Mat ToGray(Mat input)
{
	Mat gray;

	int ch = input.channels();

	if (ch == 3)
	{
		cv::cvtColor(input, gray, COLOR_BGR2GRAY);
	}
	else if (ch == 4)
	{
		cv::cvtColor(input, gray, COLOR_BGRA2GRAY);
	}
	else if (ch == 1)
	{
		gray = input.clone();  // đã là grayscale rồi
	}
	return gray;
}
void main(void)
{
	threshMin = 100;
	threshMax = 255;
	angleMin = -30;
	angleMax = 30;
	Mat binSrc, binDst, graySrc, grayDst;
	/*Mat src = cv::imread("C:\\Users\\admin\\Documents\\img\\img_20251126_161617.jpg", IMREAD_ANYCOLOR);
	Mat dst = cv::imread("C:\\Users\\admin\\Documents\\img\\tm.jpg", IMREAD_ANYCOLOR);*/
	Mat src = cv::imread("C:\\Users\\admin\\Documents\\Presentation1\\0.JPG", IMREAD_ANYCOLOR);
	Mat dst = cv::imread("C:\\Users\\admin\\Documents\\Presentation1\\tm0.jpg", IMREAD_ANYCOLOR);
	graySrc = ToGray(src);
	grayDst = ToGray(dst);
	cv::threshold(graySrc, binSrc, threshMin, threshMax, CV_THRESH_BINARY | THRESH_OTSU);
	cv::threshold(grayDst, binDst, threshMin, threshMax, CV_THRESH_BINARY | THRESH_OTSU);
	/*cv::imshow("SRC", binSrc);
	cv::imshow("DST", binDst);*/
	clock_t start_time1 = clock();

	mResult res = match_Edge(graySrc, grayDst);

	clock_t finish_time1 = clock();
	double total_time = ((double)finish_time1 - (double)start_time1) / CLOCKS_PER_SEC;
	OutputDebugString((L"Seach time: " + to_wstring(total_time * 1000) + L" ms" + L"\n").c_str());

	drawContours(src, res.contours, -1, Scalar(0, 255, 0), 1);
	cv::circle(src, Point(res.x, res.y), 2, Scalar(0, 255, 0), -1);
	string text = "Score: " + to_string(res.score) + " Angle: " + to_string(res.angle) + " X:" + to_string(res.x) + " Y:" + to_string(res.y);
	cv::putText(src, text, Point(10, 40), cv::FONT_HERSHEY_SIMPLEX, 1, Scalar(0, 255, 0), 2);
	if (src.rows > 1902 || src.cols > 1080)
	{
		resize(src, src, cv::Size(1802, 980));
	}
	cv::imshow("Result", src);
	cv::waitKey(20000);

}

#pragma endregion

#pragma region fast template matching
extern "C" __declspec(dllexport)
void TemplateMatch(ImageBuffer* img, ImageBuffer* tem, matchResult* result,
	/*DPoint** pointsOut,
	int** sizesOut,
	int* contourCountOut,
	int* totalPointsOut,*/
	int _threshMin,
	int _threshMax,
	double _angleMin,
	double _angleMax)
{
	Mat graySrc, grayDst;
	Mat src = Image2Mat(img);
	Mat dst = Image2Mat(tem);

	graySrc = ToGray(src);
	grayDst = ToGray(dst);
	threshMin = _threshMin;
	threshMax = _threshMax;
	angleMin = _angleMin;
	angleMax = _angleMax;
	mResult res = mResult(0, 0, 0, 0);
	res = match_Template(graySrc, grayDst);

	// Copy template match result
	result->angle = res.angle;
	result->score = res.score;
	result->x = res.x;
	result->y = res.y;

	//// Count contours
	//int contourCount = (int)res.contours.size();
	//*contourCountOut = contourCount;

	//// No contours => return null pointers
	//if (contourCount == 0)
	//{
	//	*totalPointsOut = 0;
	//	*pointsOut = nullptr;
	//	*sizesOut = nullptr;
	//	return;
	//}

	//// Count total points
	//int total = 0;
	//for (auto& c : res.contours) {
	//	total += (int)c.size();
	//}
	//*totalPointsOut = total;

	//if (total == 0)
	//{
	//	*pointsOut = nullptr;
	//	*sizesOut = nullptr;
	//	return;
	//}

	//// Allocate memory
	//DPoint* pts = (DPoint*)malloc(sizeof(DPoint) * total);
	//int* sizes = (int*)malloc(sizeof(int) * contourCount);

	//if (!pts || !sizes) {
	//	// Allocation failed
	//	if (pts) free(pts);
	//	if (sizes) free(sizes);
	//	*pointsOut = nullptr;
	//	*sizesOut = nullptr;
	//	*totalPointsOut = 0;
	//	*contourCountOut = 0;
	//	return;
	//}

	//// Fill data
	//int index = 0;
	//for (int i = 0; i < contourCount; i++)
	//{
	//	sizes[i] = (int)res.contours[i].size();

	//	for (auto& p : res.contours[i])
	//	{
	//		pts[index].x = p.x;
	//		pts[index].y = p.y;
	//		index++;
	//	}
	//}

	//*pointsOut = pts;
	//*sizesOut = sizes;
}
struct s_TemplData
{
	vector<Mat> vecPyramid;
	vector<Scalar> vecTemplMean;
	vector<double> vecTemplNorm;
	vector<double> vecInvArea;
	vector<bool> vecResultEqual1;
	bool bIsPatternLearned;
	int iBorderColor;
	void clear()
	{
		vector<Mat>().swap(vecPyramid);
		vector<double>().swap(vecTemplNorm);
		vector<double>().swap(vecInvArea);
		vector<Scalar>().swap(vecTemplMean);
		vector<bool>().swap(vecResultEqual1);
	}
	void resize(int iSize)
	{
		vecTemplMean.resize(iSize);
		vecTemplNorm.resize(iSize, 0);
		vecInvArea.resize(iSize, 1);
		vecResultEqual1.resize(iSize, false);
	}
	s_TemplData()
	{
		bIsPatternLearned = false;
	}
};
struct s_SingleTargetMatch
{
	Point2d ptLT, ptRT, ptRB, ptLB, ptCenter;
	double dMatchedAngle;
	double dMatchScore;
	//variable find houdlinesP
	vector<Vec4i> lines;
	cv::Rect rect;
};
struct s_BlockMax
{
	struct Block
	{
		Rect rect;
		double dMax;
		Point ptMaxLoc;
		Block()
		{
		}
		Block(Rect rect_, double dMax_, Point ptMaxLoc_)
		{
			rect = rect_;
			dMax = dMax_;
			ptMaxLoc = ptMaxLoc_;
		}
	};
	s_BlockMax()
	{
	}
	vector<Block> vecBlock;
	cv::Mat matSrc;
	s_BlockMax(cv::Mat matSrc_, cv::Size sizeTemplate)
	{
		matSrc = matSrc_;
		// Tách matSrc thành nhiều khối và tính riêng giá trị lớn nhất
		int iBlockW = sizeTemplate.width * 2;
		int iBlockH = sizeTemplate.height * 2;

		int iCol = matSrc.cols / iBlockW;
		bool bHResidue = matSrc.cols % iBlockW != 0;

		int iRow = matSrc.rows / iBlockH;
		bool bVResidue = matSrc.rows % iBlockH != 0;

		if (iCol == 0 || iRow == 0)
		{
			vecBlock.clear();
			return;
		}

		vecBlock.resize(iCol * iRow);
		int iCount = 0;
		for (int y = 0; y < iRow; y++)
		{
			for (int x = 0; x < iCol; x++)
			{
				Rect rectBlock(x * iBlockW, y * iBlockH, iBlockW, iBlockH);
				vecBlock[iCount].rect = rectBlock;
				minMaxLoc(matSrc(rectBlock), 0, &vecBlock[iCount].dMax, 0, &vecBlock[iCount].ptMaxLoc);
				vecBlock[iCount].ptMaxLoc += rectBlock.tl();
				iCount++;
			}
		}
		if (bHResidue && bVResidue)
		{
			Rect rectRight(iCol * iBlockW, 0, matSrc.cols - iCol * iBlockW, matSrc.rows);
			Block blockRight;
			blockRight.rect = rectRight;
			minMaxLoc(matSrc(rectRight), 0, &blockRight.dMax, 0, &blockRight.ptMaxLoc);
			blockRight.ptMaxLoc += rectRight.tl();
			vecBlock.push_back(blockRight);

			Rect rectBottom(0, iRow * iBlockH, iCol * iBlockW, matSrc.rows - iRow * iBlockH);
			Block blockBottom;
			blockBottom.rect = rectBottom;
			minMaxLoc(matSrc(rectBottom), 0, &blockBottom.dMax, 0, &blockBottom.ptMaxLoc);
			blockBottom.ptMaxLoc += rectBottom.tl();
			vecBlock.push_back(blockBottom);
		}
		else if (bHResidue)
		{
			Rect rectRight(iCol * iBlockW, 0, matSrc.cols - iCol * iBlockW, matSrc.rows);
			Block blockRight;
			blockRight.rect = rectRight;
			minMaxLoc(matSrc(rectRight), 0, &blockRight.dMax, 0, &blockRight.ptMaxLoc);
			blockRight.ptMaxLoc += rectRight.tl();
			vecBlock.push_back(blockRight);
		}
		else
		{
			Rect rectBottom(0, iRow * iBlockH, matSrc.cols, matSrc.rows - iRow * iBlockH);
			Block blockBottom;
			blockBottom.rect = rectBottom;
			minMaxLoc(matSrc(rectBottom), 0, &blockBottom.dMax, 0, &blockBottom.ptMaxLoc);
			blockBottom.ptMaxLoc += rectBottom.tl();
			vecBlock.push_back(blockBottom);
		}
	}
	void UpdateMax(Rect rectIgnore)
	{
		if (vecBlock.size() == 0)
			return;
		//tìm tất cả các khối giao nhau với hình vuông (rectIgnore)
		int iSize = vecBlock.size();
		for (int i = 0; i < iSize; i++)
		{
			Rect rectIntersec = rectIgnore & vecBlock[i].rect;
			//không có giao nhau
			if (rectIntersec.width == 0 && rectIntersec.height == 0)
				continue;
			//Có giao điểm, cập nhật vị trí cực trị và cực trị
			minMaxLoc(matSrc(vecBlock[i].rect), 0, &vecBlock[i].dMax, 0, &vecBlock[i].ptMaxLoc);
			vecBlock[i].ptMaxLoc += vecBlock[i].rect.tl();
		}
	}
	void GetMaxValueLoc(double& dMax, Point& ptMaxLoc)
	{
		int iSize = vecBlock.size();
		if (iSize == 0)
		{
			minMaxLoc(matSrc, 0, &dMax, 0, &ptMaxLoc);
			return;
		}
		//Tìm giá trị lớn nhất từ ​​khối
		int iIndex = 0;
		dMax = vecBlock[0].dMax;
		for (int i = 1; i < iSize; i++)
		{
			if (vecBlock[i].dMax >= dMax)
			{
				iIndex = i;
				dMax = vecBlock[i].dMax;
			}
		}
		ptMaxLoc = vecBlock[iIndex].ptMaxLoc;
	}
};

struct s_MatchParameter
{
	Point2d pt;
	double dMatchScore;
	double dMatchAngle;
	//Mat matRotatedSrc;
	Rect rectRoi;
	double dAngleStart;
	double dAngleEnd;
	RotatedRect rectR;
	Rect rectBounding;
	bool bDelete;

	double vecResult[3][3];//for subpixel
	int iMaxScoreIndex;//for subpixel
	bool bPosOnBorder;
	Point2d ptSubPixel;
	double dNewAngle;
	s_MatchParameter(Point2f ptMinMax, double dScore, double dAngle)//, Mat matRotatedSrc = Mat ())
	{
		pt = ptMinMax;
		dMatchScore = dScore;
		dMatchAngle = dAngle;

		bDelete = false;
		dNewAngle = 0.0;

		bPosOnBorder = false;
	}
	s_MatchParameter()
	{
		double dMatchScore = 0;
		double dMatchAngle = 0;
	}
	~s_MatchParameter()
	{

	}
};


#pragma region Variable
#define R2D (180.0 / CV_PI)
#define D2R (CV_PI / 180.0)
#define VISION_TOLERANCE 0.0001
#define MATCH_CANDIDATE_NUM 5
extern int m_iMaxPos = 1;
//extern int m_iLinesThresh = 120;
//extern int m_iLinesLenght = 150;
extern int m_iLinesGap = 10;
extern int m_iMinReduceArea = 150;
extern int m_iCannyMinThresh = 130;
extern int m_iCannyMaxThresh = 200;
//extern short m_dTolerance1 = -15;
//extern short m_dTolerance2 = 0;
//extern short m_dTolerance3 = 0;
//extern short m_dTolerance4 = 15;
extern double m_dMaxOverlap = 0.8;
//extern double m_dToleranceAngle = 15;
extern double m_dScore = 0.5;
s_TemplData m_TemplData;
bool m_ckSIMD = true;
bool m_ckOutputROI = false;
bool m_ckBitwiseNot = false;
bool m_bToleranceRange = true;
bool m_bDebugMode = false;
bool m_bSubPixel = false;
bool m_bStopLayer1 = false;
bool m_bFindLines = false;
bool m_bCannyShow = false;
cv::Mat m_matSrc;
std::vector<s_SingleTargetMatch> m_vecSingleTargetData;
#pragma endregion

//Lấy layer trên cùng
int GetTopLayer(Mat* matTempl, int iMinDstLength)
{
	int iTopLayer = 0;
	int iMinReduceArea = iMinDstLength * iMinDstLength;
	int iArea = matTempl->cols * matTempl->rows;
	while (iArea > iMinReduceArea)
	{
		iArea /= 4;
		iTopLayer++;
	}
	return iTopLayer;
}

Mat polygonCropImage(Mat src, vector<Point> polygon)
{
	//cắt ảnh theo hình chữ nhật xoay
	vector<vector<Point>>  m_polygon;
	m_polygon.push_back(polygon);
	Mat src_copy;
	src.copyTo(src_copy);
	Mat mask(src.size(), CV_8UC1);
	mask = 0;
	cv::drawContours(mask, m_polygon, 0, Scalar(255, 255, 255), -1);
	Mat imgCrop(src_copy.size(), CV_8UC3, Scalar(0, 0, 0));
	//cắt hình ảnh theo mặt nạ
	src_copy.copyTo(imgCrop, mask);
	//tạo hộp giới hạn cho đa giác
	//imshow("Crop", imgCrop);
	cv::Rect r = cv::boundingRect(m_polygon.at(0));
	//cắt hình ảnh theo hộp giới hạn
	try
	{
		if (0 > r.x || 0 > r.width || r.x + r.width > imgCrop.cols || 0 > r.y || 0 > r.height || r.y + r.height > imgCrop.rows) { return  Mat(); }

		imgCrop = imgCrop(r);
	}
	catch (const std::exception&)
	{
		MessageBoxA(NULL, "Error", "Roi", MB_OK);
	}

	mask = mask(r);
	m_polygon.clear();
	polygon.clear();
	return imgCrop;

}

/// </summary>
/// <param name="m_matSrc"></param>
/// <param name="m_matDst"></param>

//
//void msgbox(string str)
//{
//	MessageBoxA(NULL, str.c_str(), "notication", MB_OKCANCEL);
//}
//From ImageShop
// 4 Tổng cộng dữ liệu 32 bit đã ký.

//hàm nội tuyền "inline" thực hiện hàm trong hàm main(giảm thời gian gọi hàm) hàm sẽ không
// thực hiện nếu cóHàm chứa vòng lặp (for, while, do-while).Hàm chứa các biến tĩnh.
//Hàm đệ quy.Hàm chứa câu lệnh switch hoặc goto.
inline int _mm_hsum_epi32(__m128i V)      // V3 V2 V1 V0
{
	// Người ta đo thực tế tốc độ này còn nhanh hơn._mm_extract_epi32 chậm nhất.
	__m128i T = _mm_add_epi32(V, _mm_srli_si128(V, 8));  // V3+V1   V2+V0  V1  V0  
	T = _mm_add_epi32(T, _mm_srli_si128(T, 4));    // V3+V1+V2+V0  V2+V0+V1 V1+V0 V0 
	return _mm_cvtsi128_si32(T);       // trích xuất bit thấp
}
// Phép nhân dữ liệu byte dựa trên SSE.
// <param name="Kernel">Ma trận hạt nhân cần được tích hợp. </param>
// <param name="Conv">ma trận tích chập. </param>
// <param name="Length">Độ dài của tất cả các phần tử của ma trận.。 </param>
inline int IM_Conv_SIMD(unsigned char* pCharKernel, unsigned char* pCharConv, int iLength)
{
	const int iBlockSize = 16, Block = iLength / iBlockSize;
	__m128i SumV = _mm_setzero_si128();
	__m128i Zero = _mm_setzero_si128();
	for (int Y = 0; Y < Block * iBlockSize; Y += iBlockSize)
	{
		__m128i SrcK = _mm_loadu_si128((__m128i*)(pCharKernel + Y));
		__m128i SrcC = _mm_loadu_si128((__m128i*)(pCharConv + Y));
		__m128i SrcK_L = _mm_unpacklo_epi8(SrcK, Zero);
		__m128i SrcK_H = _mm_unpackhi_epi8(SrcK, Zero);
		__m128i SrcC_L = _mm_unpacklo_epi8(SrcC, Zero);
		__m128i SrcC_H = _mm_unpackhi_epi8(SrcC, Zero);
		__m128i SumT = _mm_add_epi32(_mm_madd_epi16(SrcK_L, SrcC_L), _mm_madd_epi16(SrcK_H, SrcC_H));
		SumV = _mm_add_epi32(SumV, SumT);
	}
	int Sum = _mm_hsum_epi32(SumV);
	for (int Y = Block * iBlockSize; Y < iLength; Y++)
	{
		Sum += pCharKernel[Y] * pCharConv[Y];
	}
	return Sum;
}
//Mat Read_TCHAR(TCHAR* pTChar)
//{
//	CString cstr;
//	cstr.Format(L"%s", pTChar);
//
//	FILE* f = NULL;
//	_tfopen_s(&f, cstr, _T("rb"));
//	if (!f)
//		return Mat();
//	fseek(f, 0, SEEK_END);
//	size_t buffer_size = ftell(f);
//	fseek(f, 0, SEEK_SET);
//
//	std::vector<char> buffer(buffer_size);
//	fread(&buffer[0], sizeof(char), buffer_size, f);
//	fclose(f);
//
//	Mat mat = imdecode(buffer, IMREAD_GRAYSCALE);
//
//	return mat;
//}
//học mẫu
void LearnPattern(Mat m_matDst)
{
	//UpdateData(1);;
	m_TemplData.clear();

	int iTopLayer = GetTopLayer(&m_matDst, (int)sqrt((double)m_iMinReduceArea));
	buildPyramid(m_matDst, m_TemplData.vecPyramid, iTopLayer);
	s_TemplData* templData = &m_TemplData;
	templData->iBorderColor = mean(m_matDst).val[0] < 128 ? 255 : 0;
	int iSize = templData->vecPyramid.size();
	templData->resize(iSize);

	for (int i = 0; i < iSize; i++)
	{
		double invArea = 1. / ((double)templData->vecPyramid[i].rows * templData->vecPyramid[i].cols);
		Scalar templMean, templSdv;
		double templNorm = 0, templSum2 = 0;

		meanStdDev(templData->vecPyramid[i], templMean, templSdv);
		templNorm = templSdv[0] * templSdv[0] + templSdv[1] * templSdv[1] + templSdv[2] * templSdv[2] + templSdv[3] * templSdv[3];

		if (templNorm < DBL_EPSILON)
		{
			templData->vecResultEqual1[i] = true;
		}
		templSum2 = templNorm + templMean[0] * templMean[0] + templMean[1] * templMean[1] + templMean[2] * templMean[2] + templMean[3] * templMean[3];


		templSum2 /= invArea;
		templNorm = std::sqrt(templNorm);
		templNorm /= std::sqrt(invArea); // care of accuracy here


		templData->vecInvArea[i] = invArea;
		templData->vecTemplMean[i] = templMean;
		templData->vecTemplNorm[i] = templNorm;
	}
	templData->bIsPatternLearned = true;
}
//so khớp ảnh chỉ phát hiện 1 đối tượng
mResult TemplateMatching(Mat src, Mat dst)
{

	mResult res = mResult(0, 0, 0, 0);
	if (src.rows < dst.rows || src.cols < dst.cols) { return res; }
	// Initialize variables
	cv::Mat result;
	double minVal, maxVal;
	cv::Point minLoc, maxLoc;
	/*std::vector <double> vresult;*/

	// Perform template matching using NCC
	cv::matchTemplate(src, dst, result, cv::TM_CCOEFF_NORMED);
	cv::minMaxLoc(result, &minVal, &maxVal, &minLoc, &maxLoc);

	// Draw a rectangle around the best match
	//cv::rectangle(src, maxLoc, cv::Point(maxLoc.x + dst.cols, maxLoc.y + dst.rows), cv::Scalar(0,0,255), 20);
	//cv::circle(src, Point2f(maxLoc.x+(dst.cols)/2, maxLoc.y + (dst.rows)/2), 2, Scalar(255, 255, 255), 2);
	/*vresult.push_back(maxLoc.x + (dst.cols) / 2);
	vresult.push_back(maxLoc.y + (dst.rows) / 2);
	vresult.push_back(maxVal);*/
	// Display the result
	//cv::imshow("Result", src);
	//cv::waitKey(0);
	res.x = maxLoc.x + (dst.cols) / 2;
	res.y = maxLoc.y + (dst.rows) / 2;
	res.score = maxVal;
	return res;

}
void CCOEFF_Denominator(cv::Mat& matSrc, s_TemplData* pTemplData, cv::Mat& matResult, int iLayer)
{
	if (pTemplData->vecResultEqual1[iLayer])
	{
		matResult = Scalar::all(1);
		return;
	}
	double* q0 = 0, * q1 = 0, * q2 = 0, * q3 = 0;

	Mat sum, sqsum;
	cv::integral(matSrc, sum, sqsum, CV_64F);

	q0 = (double*)sqsum.data;
	q1 = q0 + pTemplData->vecPyramid[iLayer].cols;
	q2 = (double*)(sqsum.data + pTemplData->vecPyramid[iLayer].rows * sqsum.step);
	q3 = q2 + pTemplData->vecPyramid[iLayer].cols;

	double* p0 = (double*)sum.data;
	double* p1 = p0 + pTemplData->vecPyramid[iLayer].cols;
	double* p2 = (double*)(sum.data + pTemplData->vecPyramid[iLayer].rows * sum.step);
	double* p3 = p2 + pTemplData->vecPyramid[iLayer].cols;

	int sumstep = sum.data ? (int)(sum.step / sizeof(double)) : 0;
	int sqstep = sqsum.data ? (int)(sqsum.step / sizeof(double)) : 0;

	//
	double dTemplMean0 = pTemplData->vecTemplMean[iLayer][0];
	double dTemplNorm = pTemplData->vecTemplNorm[iLayer];
	double dInvArea = pTemplData->vecInvArea[iLayer];
	//

	int i, j;
	for (i = 0; i < matResult.rows; i++)
	{
		float* rrow = matResult.ptr<float>(i);
		int idx = i * sumstep;
		int idx2 = i * sqstep;

		for (j = 0; j < matResult.cols; j += 1, idx += 1, idx2 += 1)
		{
			double num = rrow[j], t;
			double wndMean2 = 0, wndSum2 = 0;

			t = p0[idx] - p1[idx] - p2[idx] + p3[idx];
			wndMean2 += t * t;
			num -= t * dTemplMean0;
			wndMean2 *= dInvArea;


			t = q0[idx2] - q1[idx2] - q2[idx2] + q3[idx2];
			wndSum2 += t;


			//t = std::sqrt (MAX (wndSum2 - wndMean2, 0)) * dTemplNorm;

			double diff2 = MAX(wndSum2 - wndMean2, 0);
			if (diff2 <= min(0.5, 10 * FLT_EPSILON * wndSum2))
				t = 0; // avoid rounding errors
			else
				t = std::sqrt(diff2) * dTemplNorm;

			if (fabs(num) < t)
				num /= t;
			else if (fabs(num) < t * 1.125)
				num = num > 0 ? 1 : -1;
			else
				num = 0;

			rrow[j] = (float)num;
		}
	}
}
//phát hiện đường thẳng
vector<Vec4i> houghLinesP(Mat src, int thresh = 5, double minLineLength = 10, double minLengGap = 250, int minCannyThresh = 10, int maxCannyThresh = 150)
{
	Mat edge, cvColor;
	// Edge detection
	cv::Canny(src, edge, minCannyThresh, maxCannyThresh, 3);
	//imshow("canny", edge);
	// Copy edges to the images that will display the results in BGR
	cv::cvtColor(edge, cvColor, COLOR_GRAY2BGR);
	// Create a vector to store lines of the image
	vector<Vec4i> lines;
	// Apply Hough Transform
	cv::HoughLinesP(edge, lines, 1, CV_PI / 180, thresh, minLineLength, minLengGap);
	return lines;
	// Draw lines on the image
	/*for (size_t i = 0; i < lines.size(); i++) {
		Vec4i l = lines[i];
		line(src, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(255, 0, 0), 2, LINE_AA);
	}
	return src;*/

}
void MatchTemplate(cv::Mat& matSrc, s_TemplData* pTemplData, cv::Mat& matResult, int iLayer, bool bUseSIMD)
{	//nếu sử dụng tính năng tích chập SIMD

	if (m_ckSIMD == true && bUseSIMD)
	{
		//From ImageShop
		matResult.create(matSrc.rows - pTemplData->vecPyramid[iLayer].rows + 1,
			matSrc.cols - pTemplData->vecPyramid[iLayer].cols + 1, CV_32FC1);
		matResult.setTo(0);
		cv::Mat& matTemplate = pTemplData->vecPyramid[iLayer];

		int  t_r_end = matTemplate.rows, t_r = 0;
		for (int r = 0; r < matResult.rows; r++)
		{
			float* r_matResult = matResult.ptr<float>(r);
			uchar* r_source = matSrc.ptr<uchar>(r);
			uchar* r_template, * r_sub_source;
			for (int c = 0; c < matResult.cols; ++c, ++r_matResult, ++r_source)
			{
				r_template = matTemplate.ptr<uchar>();
				r_sub_source = r_source;
				for (t_r = 0; t_r < t_r_end; ++t_r, r_sub_source += matSrc.cols, r_template += matTemplate.cols)
				{
					*r_matResult = *r_matResult + IM_Conv_SIMD(r_template, r_sub_source, matTemplate.cols);
				}
			}
		}
		//From ImageShop
	}
	else
	{
		if (matSrc.rows < pTemplData->vecPyramid[iLayer].rows || matSrc.cols < pTemplData->vecPyramid[iLayer].cols) { return; }
		cv::matchTemplate(matSrc, pTemplData->vecPyramid[iLayer], matResult, CV_TM_CCORR);
		//find_edgeBaseMatching(matSrc, pTemplData->vecPyramid[iLayer], matResult, 0.3, 100, 200, 0.8);
	/*	double min = 0, max = 0;
		cv::Point minLoc(-1, -1), maxLoc(-1, -1);
		cv::minMaxLoc(matResult, &min, &max, &minLoc, &maxLoc);*/
	}

	/*Mat diff;
	absdiff(matResult, matResult, diff);
	double dMaxValue;
	minMaxLoc(diff, 0, &dMaxValue, 0,0);*/
	CCOEFF_Denominator(matSrc, pTemplData, matResult, iLayer);
}
// lấy kích thước quay tốt nhất
Point2f ptRotatePt2f(Point2f ptInput, Point2f ptOrg, double dAngle)
{
	double dWidth = ptOrg.x * 2;
	double dHeight = ptOrg.y * 2;
	double dY1 = dHeight - ptInput.y, dY2 = dHeight - ptOrg.y;

	double dX = (ptInput.x - ptOrg.x) * cos(dAngle) - (dY1 - ptOrg.y) * sin(dAngle) + ptOrg.x;
	double dY = (ptInput.x - ptOrg.x) * sin(dAngle) + (dY1 - ptOrg.y) * cos(dAngle) + dY2;

	dY = -dY + dHeight;
	return Point2f((float)dX, (float)dY);
}
//hàm tính góc 3 điểm
double FindAngle(Point2d orgin, Point2d p1, Point2d p2)
{
	cv::Point2d ab = { orgin.x - p1.x, orgin.y - p1.y };
	cv::Point2d cb = { orgin.x - p2.x, orgin.y - p2.y };
	float dot = (ab.x * cb.x + ab.y * cb.y); // dot product
	float cross = (ab.x * cb.y - ab.y * cb.x); // cross product
	float alpha = atan2(cross, dot);
	return  (double)(alpha * 180 / CV_PI);
}
Size GetBestRotationSize(Size sizeSrc, Size sizeDst, double dRAngle)
{
	double dRAngle_radian = dRAngle * D2R;
	Point ptLT(0, 0), ptLB(0, sizeSrc.height - 1), ptRB(sizeSrc.width - 1, sizeSrc.height - 1), ptRT(sizeSrc.width - 1, 0);
	Point2f ptCenter((sizeSrc.width - 1) / 2.0f, (sizeSrc.height - 1) / 2.0f);
	Point2f ptLT_R = ptRotatePt2f(Point2f(ptLT), ptCenter, dRAngle_radian);
	Point2f ptLB_R = ptRotatePt2f(Point2f(ptLB), ptCenter, dRAngle_radian);
	Point2f ptRB_R = ptRotatePt2f(Point2f(ptRB), ptCenter, dRAngle_radian);
	Point2f ptRT_R = ptRotatePt2f(Point2f(ptRT), ptCenter, dRAngle_radian);

	float fTopY = max(max(ptLT_R.y, ptLB_R.y), max(ptRB_R.y, ptRT_R.y));
	float fBottomY = min(min(ptLT_R.y, ptLB_R.y), min(ptRB_R.y, ptRT_R.y));
	float fRightX = max(max(ptLT_R.x, ptLB_R.x), max(ptRB_R.x, ptRT_R.x));
	float fLeftX = min(min(ptLT_R.x, ptLB_R.x), min(ptRB_R.x, ptRT_R.x));

	if (dRAngle > 360)
		dRAngle -= 360;
	else if (dRAngle < 0)
		dRAngle += 360;

	if (fabs(fabs(dRAngle) - 90) < VISION_TOLERANCE || fabs(fabs(dRAngle) - 270) < VISION_TOLERANCE)
	{
		return Size(sizeSrc.height, sizeSrc.width);
	}
	else if (fabs(dRAngle) < VISION_TOLERANCE || fabs(fabs(dRAngle) - 180) < VISION_TOLERANCE)
	{
		return sizeSrc;
	}

	double dAngle = dRAngle;

	if (dAngle > 0 && dAngle < 90)
	{
		;
	}
	else if (dAngle > 90 && dAngle < 180)
	{
		dAngle -= 90;
	}
	else if (dAngle > 180 && dAngle < 270)
	{
		dAngle -= 180;
	}
	else if (dAngle > 270 && dAngle < 360)
	{
		dAngle -= 270;
	}
	else//Debug
	{
		cout << "Unkown" << endl;
	}

	float fH1 = sizeDst.width * sin(dAngle * D2R) * cos(dAngle * D2R);
	float fH2 = sizeDst.height * sin(dAngle * D2R) * cos(dAngle * D2R);

	int iHalfHeight = (int)ceil(fTopY - ptCenter.y - fH1);
	int iHalfWidth = (int)ceil(fRightX - ptCenter.x - fH2);

	Size sizeRet(iHalfWidth * 2, iHalfHeight * 2);

	bool bWrongSize = (sizeDst.width < sizeRet.width && sizeDst.height > sizeRet.height)
		|| (sizeDst.width > sizeRet.width && sizeDst.height < sizeRet.height
			|| sizeDst.area() > sizeRet.area());
	if (bWrongSize)
		sizeRet = Size(int(fRightX - fLeftX + 0.5), int(fTopY - fBottomY + 0.5));

	return sizeRet;
}
Point GetNextMaxLoc(Mat& matResult, Point ptMaxLoc, Size sizeTemplate, double& dMaxValue, double dMaxOverlap, s_BlockMax& blockMax)
{
	//Khu vực được so sánh cần xem xét tỷ lệ trùng lặp
	int iStartX = int(ptMaxLoc.x - sizeTemplate.width * (1 - dMaxOverlap));
	int iStartY = int(ptMaxLoc.y - sizeTemplate.height * (1 - dMaxOverlap));
	Rect rectIgnore(iStartX, iStartY, int(2 * sizeTemplate.width * (1 - dMaxOverlap))
		, int(2 * sizeTemplate.height * (1 - dMaxOverlap)));
	//bôi đen
	rectangle(matResult, rectIgnore, Scalar(-1), CV_FILLED);
	blockMax.UpdateMax(rectIgnore);
	Point ptReturn;
	blockMax.GetMaxValueLoc(dMaxValue, ptReturn);
	return ptReturn;
}
Point GetNextMaxLoc(Mat& matResult, Point ptMaxLoc, Size sizeTemplate, double& dMaxValue, double dMaxOverlap)
{
	//Các khu vực được so sánh hoàn toàn không trùng nhau: +- chiều rộng và chiều cao của mẫu
	//int iStartX = ptMaxLoc.x - iTemplateW;
	//int iStartY = ptMaxLoc.y - iTemplateH;
	//int iEndX = ptMaxLoc.x + iTemplateW;

	//int iEndY = ptMaxLoc.y + iTemplateH;
	////bôi đen
	//rectangle (matResult, Rect (iStartX, iStartY, 2 * iTemplateW * (1-dMaxOverlap * 2), 2 * iTemplateH * (1-dMaxOverlap * 2)), Scalar (dMinValue), CV_FILLED);
	////nhận được tối đa tiếp theo
	//Point ptNewMaxLoc;
	//minMaxLoc (matResult, 0, &dMaxValue, 0, &ptNewMaxLoc);
	//return ptNewMaxLoc;

	//Khu vực được so sánh cần xem xét tỷ lệ trùng lặp
	int iStartX = ptMaxLoc.x - sizeTemplate.width * (1 - dMaxOverlap);
	int iStartY = ptMaxLoc.y - sizeTemplate.height * (1 - dMaxOverlap);
	//bôi đen
	rectangle(matResult, Rect(iStartX, iStartY, 2 * sizeTemplate.width * (1 - dMaxOverlap), 2 * sizeTemplate.height * (1 - dMaxOverlap)), Scalar(-1), CV_FILLED);
	//nhận được tối đa tiếp theo
	Point ptNewMaxLoc;
	minMaxLoc(matResult, 0, &dMaxValue, 0, &ptNewMaxLoc);
	return ptNewMaxLoc;
}
void GetRotatedROI(Mat& matSrc, Size size, Point2f ptLT, double dAngle, Mat& matROI)
{
	double dAngle_radian = dAngle * D2R;
	Point2f ptC((matSrc.cols - 1) / 2.0f, (matSrc.rows - 1) / 2.0f);
	Point2f ptLT_rotate = ptRotatePt2f(ptLT, ptC, dAngle_radian);
	Size sizePadding(size.width + 6, size.height + 6);

	//tạo ma trận biến đổi 
	Mat rMat = getRotationMatrix2D(ptC, dAngle, 1);
	rMat.at<double>(0, 2) -= ptLT_rotate.x - 3;
	rMat.at<double>(1, 2) -= ptLT_rotate.y - 3;
	// Phép trừ của ma trận dịch và xoay (0, 2) (1, 2) là phần bù của đồ họa được xoay, -= ptLT_rotate.x - 3 có nghĩa là đồ họa được xoay di chuyển theo hướng -X ptLT_rotate.x - 3
	//Debug

	//Debug  / biến đổi hình ảnh
	warpAffine(matSrc, matROI, rMat, sizePadding);
}
bool SubPixEsimation(vector<s_MatchParameter>* vec, double* dNewX, double* dNewY, double* dNewAngle, double dAngleStep, int iMaxScoreIndex)
{
	//Az=S, (A.T)Az=(A.T)s, z = ((A.T)A).inv (A.T)s

	Mat matA(27, 10, CV_64F);
	Mat matZ(10, 1, CV_64F);
	Mat matS(27, 1, CV_64F);

	double dX_maxScore = (*vec)[iMaxScoreIndex].pt.x;
	double dY_maxScore = (*vec)[iMaxScoreIndex].pt.y;
	double dTheata_maxScore = (*vec)[iMaxScoreIndex].dMatchAngle;
	int iRow = 0;
	/*for (int x = -1; x <= 1; x++)
	{
		for (int y = -1; y <= 1; y++)
		{
			for (int theta = 0; theta <= 2; theta++)
			{*/
	for (int theta = 0; theta <= 2; theta++)
	{
		for (int y = -1; y <= 1; y++)
		{
			for (int x = -1; x <= 1; x++)
			{
				//xx yy tt xy xt yt x y t 1
				//0  1  2  3  4  5  6 7 8 9
				double dX = dX_maxScore + x;
				double dY = dY_maxScore + y;
				//double dT = (*vec)[theta].dMatchAngle + (theta - 1) * dAngleStep;
				double dT = (dTheata_maxScore + (theta - 1) * dAngleStep) * D2R;
				matA.at<double>(iRow, 0) = dX * dX;
				matA.at<double>(iRow, 1) = dY * dY;
				matA.at<double>(iRow, 2) = dT * dT;
				matA.at<double>(iRow, 3) = dX * dY;
				matA.at<double>(iRow, 4) = dX * dT;
				matA.at<double>(iRow, 5) = dY * dT;
				matA.at<double>(iRow, 6) = dX;
				matA.at<double>(iRow, 7) = dY;
				matA.at<double>(iRow, 8) = dT;
				matA.at<double>(iRow, 9) = 1.0;
				matS.at<double>(iRow, 0) = (*vec)[iMaxScoreIndex + (theta - 1)].vecResult[x + 1][y + 1];
				iRow++;
#ifdef _DEBUG
				/*string str = format ("%.6f, %.6f, %.6f, %.6f, %.6f, %.6f, %.6f, %.6f, %.6f, %.6f", dValueA[0], dValueA[1], dValueA[2], dValueA[3], dValueA[4], dValueA[5], dValueA[6], dValueA[7], dValueA[8], dValueA[9]);
				fileA <<  str << endl;
				str = format ("%.6f", dValueS[iRow]);
				fileS << str << endl;*/
#endif
			}
		}
	}
	//Giải ma trận Z, ta được k0~k9
	//[ x* ] = [ 2k0 k3 k4 ]-1 [ -k6 ]
	//| y* | = | k3 2k1 k5 |   | -k7 |
	//[ t* ] = [ k4 k5 2k2 ]   [ -k8 ]

	//solve (matA, matS, matZ, DECOMP_SVD);
	matZ = (matA.t() * matA).inv() * matA.t() * matS;
	Mat matZ_t;
	transpose(matZ, matZ_t);
	double* dZ = matZ_t.ptr<double>(0);
	Mat matK1 = (Mat_<double>(3, 3) <<
		(2 * dZ[0]), dZ[3], dZ[4],
		dZ[3], (2 * dZ[1]), dZ[5],
		dZ[4], dZ[5], (2 * dZ[2]));
	Mat matK2 = (Mat_<double>(3, 1) << -dZ[6], -dZ[7], -dZ[8]);
	Mat matDelta = matK1.inv() * matK2;

	*dNewX = matDelta.at<double>(0, 0);
	*dNewY = matDelta.at<double>(1, 0);
	*dNewAngle = matDelta.at<double>(2, 0) * R2D;
	return true;
}
bool compareScoreBig2Small(const s_MatchParameter& lhs, const s_MatchParameter& rhs) { return  lhs.dMatchScore > rhs.dMatchScore; }
bool comparePtWithAngle(const pair<Point2f, double> lhs, const pair<Point2f, double> rhs) { return lhs.second < rhs.second; }
void FilterWithScore(vector<s_MatchParameter>* vec, double dScore)
{
	sort(vec->begin(), vec->end(), compareScoreBig2Small);
	int iSize = vec->size(), iIndexDelete = iSize + 1;
	for (int i = 0; i < iSize; i++)
	{
		if ((*vec)[i].dMatchScore < dScore)
		{
			iIndexDelete = i;
			break;
		}
	}
	if (iIndexDelete == iSize + 1)//không có phần tử nào nhỏ hơndScore
		return;
	vec->erase(vec->begin() + iIndexDelete, vec->end());
	return;
}
void SortPtWithCenter(vector<Point2f>& vecSort)
{
	int iSize = (int)vecSort.size();
	Point2f ptCenter;
	for (int i = 0; i < iSize; i++)
		ptCenter += vecSort[i];
	ptCenter /= iSize;

	Point2f vecX(1, 0);

	vector<pair<Point2f, double>> vecPtAngle(iSize);
	for (int i = 0; i < iSize; i++)
	{
		vecPtAngle[i].first = vecSort[i];//pt
		Point2f vec1(vecSort[i].x - ptCenter.x, vecSort[i].y - ptCenter.y);
		float fNormVec1 = vec1.x * vec1.x + vec1.y * vec1.y;
		float fDot = vec1.x;

		if (vec1.y < 0)//Nếu điểm nằm trên tâm
		{
			vecPtAngle[i].second = acos(fDot / fNormVec1) * R2D;
		}
		else if (vec1.y > 0)// đặt dưới
		{
			vecPtAngle[i].second = 360 - acos(fDot / fNormVec1) * R2D;
		}
		else//Điểm và tâm nằm trong cùng một Y
		{
			if (vec1.x - ptCenter.x > 0)
				vecPtAngle[i].second = 0;
			else
				vecPtAngle[i].second = 180;
		}

	}
	sort(vecPtAngle.begin(), vecPtAngle.end(), comparePtWithAngle);
	for (int i = 0; i < iSize; i++)
		vecSort[i] = vecPtAngle[i].first;
}
void FilterWithRotatedRect(vector<s_MatchParameter>* vec, int iMethod, double dMaxOverLap)
{
	int iMatchSize = (int)vec->size();
	RotatedRect rect1, rect2;
	for (int i = 0; i < iMatchSize - 1; i++)
	{
		if (vec->at(i).bDelete)
			continue;
		for (int j = i + 1; j < iMatchSize; j++)
		{
			if (vec->at(j).bDelete)
				continue;
			rect1 = vec->at(i).rectR;
			rect2 = vec->at(j).rectR;
			vector<Point2f> vecInterSec;
			int iInterSecType = rotatedRectangleIntersection(rect1, rect2, vecInterSec);
			if (iInterSecType == INTERSECT_NONE)//không có ngã tư
				continue;
			else if (iInterSecType == INTERSECT_FULL) //Một hình chữ nhật bao bọc một hình chữ nhật khác
			{
				int iDeleteIndex;
				if (iMethod == CV_TM_SQDIFF)
					iDeleteIndex = (vec->at(i).dMatchScore <= vec->at(j).dMatchScore) ? j : i;
				else
					iDeleteIndex = (vec->at(i).dMatchScore >= vec->at(j).dMatchScore) ? j : i;
				vec->at(iDeleteIndex).bDelete = true;
			}
			else//Ngã tư > 0
			{
				if (vecInterSec.size() < 3)//một hoặc hai ngã tư
					continue;
				else
				{
					int iDeleteIndex;
					//Tìm tỷ lệ diện tích và chồng chéo
					SortPtWithCenter(vecInterSec);
					double dArea = contourArea(vecInterSec);
					double dRatio = dArea / rect1.size.area();
					//Nếu nó lớn hơn tỷ lệ trùng lặp tối đa, hãy chọn cái có điểm cao
					if (dRatio > dMaxOverLap)
					{
						if (iMethod == CV_TM_SQDIFF)
							iDeleteIndex = (vec->at(i).dMatchScore <= vec->at(j).dMatchScore) ? j : i;
						else
							iDeleteIndex = (vec->at(i).dMatchScore >= vec->at(j).dMatchScore) ? j : i;
						vec->at(iDeleteIndex).bDelete = true;
					}
				}
			}
		}
	}
	vector<s_MatchParameter>::iterator it;
	for (it = vec->begin(); it != vec->end();)
	{
		if ((*it).bDelete)
			it = vec->erase(it);
		else
			++it;
	}
}
void OutputRoi(s_SingleTargetMatch sstm, Mat m_Src)
{
	if (!m_ckOutputROI)
		return;
	Rect rect(sstm.ptLT, sstm.ptRB);
	for (int i = 1; i < 50; i++)
	{
		String strName = cv::format("../x64/Release/outputRoi/roi%d.bmp", i);

		/*if(std::filesystem::exists(strName))
			continue;*/
		cv::imwrite(strName, m_Src(rect));
		break;
	}
}
//// vẽ chữ thập ở điểm giữa 
//void Core::DrawMarkCross(Mat& matDraw, int iX, int iY, int iLength, Scalar color, int iThickness)
//{
//	if (matDraw.empty())
//		return;
//	Point ptC(iX, iY);
//	cv::line(matDraw, ptC - Point(iLength, 0), ptC + Point(iLength, 0), color, iThickness);
//	cv::line(matDraw, ptC - Point(0, iLength), ptC + Point(0, iLength), color, iThickness);
//}

///////////////////////////////////////////////////////////////////////////////Match////////////////////////////////////////////////////////////////////////////////

mResult match_Template(Mat m_Src, Mat m_Dst)
{
	//vector<vector<double>> result;
	mResult result = mResult(0, 0, 0, 0);

	if (m_Src.empty() || m_Dst.empty())
	{
		cout << "No image Src or Dst" << endl;
		return result;
	}
	if (m_Dst.cols > m_Src.cols || m_Dst.rows > m_Src.rows)
	{
		cout << "Size Dst too Big" << endl;
		return result;
	}
	if (m_Dst.size().area() > m_Src.size().area())
	{
		cout << "Area Dst > Area Src" << endl;
		return result;
	}
	m_vecSingleTargetData.clear();
	LearnPattern(m_Dst); //học mẫu
	
	//cout << "Step 1" << endl;
	//
	//if (m_TemplData.bIsPatternLearned)
	//{
	//	// học mẫu
	//	outputDialog("msg abc3");
	//	return false;
	//}

	//gọi timer
	//double d1 = clock();
	//xác định số lớp kim tự tháp ,tổng cộng bằng iLayer+ 1
	int iTopLayer = GetTopLayer(&m_Dst, (int)sqrt((double)m_iMinReduceArea));
	//xây kim tự tháp
	vector<Mat> vecMatSrcPyr;
	//nếu Reflective được tích
	if (m_ckBitwiseNot)
	{
		Mat matNewSrc = 255 - m_Src;
		buildPyramid(matNewSrc, vecMatSrcPyr, iTopLayer);
		Mat rsmatnewsrc;
		/*	cv::resize(matNewSrc, rsmatnewsrc, Size(1902, 1080));
			cv::imshow("Top Layer", matNewSrc);
			moveWindow("Top Layer", 0, 0);*/
	}
	else
	{
		buildPyramid(m_Src, vecMatSrcPyr, iTopLayer); //xây dựng kim tự tháp(hình ảnh đầu vào,vector đầu ra, số lớp layer)
	}
	//cout << "Step 2" << endl;
	s_TemplData* pTemplData = &m_TemplData; //khai báo con trỏ pTemplData
	///////////////////////////////Trong giai đoạn đầu tiên, lớp trên cùng được sử dụng để tìm ra góc gần đúng và ROI
	//bước của góc quay (hàm max lấy giá trị lớn nhất của 1 trong 2 cạnh)
	double dAngleStep = atan(2.0 / max(pTemplData->vecPyramid[iTopLayer].cols, pTemplData->vecPyramid[iTopLayer].rows)) * R2D;
	vector<double> vecAngles;
	// nếu nút mũi tên đi xuống được check( select mode angle option)
	if (m_bToleranceRange)
	{

		if (angleMin >= 0 || 0 >= angleMax)
		{
			cout << "cai dat sai thong so goc" << endl;
			return result;
		}	//gán các bước quay vào vector vecAngles
		for (double dAngle = angleMin; dAngle < angleMin + dAngleStep; dAngle += dAngleStep) // dAngle : giá trị góc min
			vecAngles.push_back(dAngle);  //thêm dAngle vào cuối mảng Vector VecAngles
		for (double dAngle = 0; dAngle < angleMax + dAngleStep; dAngle += dAngleStep)
			vecAngles.push_back(dAngle);//thêm dAngle vào cuối mảng Vector VecAngles
	}
	else  //
	{	// nếu giá trị cài đặt khoảng góc quay < 0.0000001
		if (angleMax < VISION_TOLERANCE)
		{
			vecAngles.push_back(0.0); // vector quay đặt thành 0
		}
		else
		{	// gán các bước quay vào vector Angles
			for (double dAngle = 0; dAngle < angleMax + dAngleStep; dAngle += dAngleStep)
				vecAngles.push_back(dAngle);
			for (double dAngle = -dAngleStep; dAngle > -angleMax - dAngleStep; dAngle -= dAngleStep)
				vecAngles.push_back(dAngle);
		}
	}
	//cout << "Step 3" << endl;
	//đặt biến top ảnh đầu vào = lớp của kim tự tháp (with,high, center)
	int iTopSrcW = vecMatSrcPyr[iTopLayer].cols, iTopSrcH = vecMatSrcPyr[iTopLayer].rows;
	//lấy điểm giữa
	Point2f ptCenter((iTopSrcW - 1) / 2.0f, (iTopSrcH - 1) / 2.0f);

	int iSize = (int)vecAngles.size(); // iSize số lần Quay Angle number
	//vector<s_MatchParameter> vecMatchParameter (iSize * (Core::m_iMaxPos + MATCH_CANDIDATE_NUM));
	vector<s_MatchParameter> vecMatchParameter; //khai báo Vector lưu giá trị các đối tượng được tìm thấy qua các góc đo
	//Caculate lowest score at every layer
	vector<double> vecLayerScore(iTopLayer + 1, m_dScore);
	//tạo lớp kim tự tháp
	for (int iLayer = 1; iLayer <= iTopLayer; iLayer++)
	{
		vecLayerScore[iLayer] = vecLayerScore[iLayer - 1] * 0.9;
	}
	//cout << "Step 4" << endl;
	Size sizePat = pTemplData->vecPyramid[iTopLayer].size();
	bool bCalMaxByBlock = (vecMatSrcPyr[iTopLayer].size().area() / sizePat.area() > 500) && m_iMaxPos > 10;

	//vòng lặp với khoảng góc quay được cài đặt
	for (int i = 0; i < iSize; i++)
	{
		Mat matRotatedSrc, matR = getRotationMatrix2D(ptCenter, vecAngles[i], 1);//cv2.getRotationMatrix2D(tâm, góc, tỷ lệ) tạo ma trận xoay
		Mat matResult;
		Point ptMaxLoc;
		double dValue, dMaxVal;
		double dRotate = clock();
		Size sizeBest = GetBestRotationSize(vecMatSrcPyr[iTopLayer].size(), pTemplData->vecPyramid[iTopLayer].size(), vecAngles[i]); //Nhận kích thước quay tốt nhất

		float fTranslationX = (sizeBest.width - 1) / 2.0f - ptCenter.x;
		float fTranslationY = (sizeBest.height - 1) / 2.0f - ptCenter.y;
		matR.at<double>(0, 2) += fTranslationX;
		matR.at<double>(1, 2) += fTranslationY;
		//biến đổi xoay
		cv::warpAffine(vecMatSrcPyr[iTopLayer], matRotatedSrc, matR, sizeBest, INTER_LINEAR, BORDER_CONSTANT, Scalar(pTemplData->iBorderColor));
		//so khớp ảnh trả về hình ảnh Src xoay(lớp đỉnh kim tự tháp)
		MatchTemplate(matRotatedSrc, pTemplData, matResult, iTopLayer, false);
		if (bCalMaxByBlock == true) // false
		{	//tách ảnh thành nhiều khối(Dst*2 with,rows) ==> lấy block có giá trị minmax Val- minmax Loc lớn nhất
			s_BlockMax blockMax(matResult, pTemplData->vecPyramid[iTopLayer].size());
			//Tìm giá trị lớn nhất từ ​​khối
			blockMax.GetMaxValueLoc(dMaxVal, ptMaxLoc);
			if (dMaxVal < vecLayerScore[iTopLayer])
				continue;

			vecMatchParameter.push_back(s_MatchParameter(cv::Point2f(ptMaxLoc.x - fTranslationX, ptMaxLoc.y - fTranslationY), dMaxVal, vecAngles[i]));
			for (int j = 0; j < m_iMaxPos + MATCH_CANDIDATE_NUM - 1; j++)
			{
				ptMaxLoc = GetNextMaxLoc(matResult, ptMaxLoc, pTemplData->vecPyramid[iTopLayer].size(), dValue, m_dMaxOverlap, blockMax);
				if (dValue < vecLayerScore[iTopLayer])
					break;
				vecMatchParameter.push_back(s_MatchParameter(Point2f(ptMaxLoc.x - fTranslationX, ptMaxLoc.y - fTranslationY), dValue, vecAngles[i]));
			}
		}
		else
		{
			minMaxLoc(matResult, 0, &dMaxVal, 0, &ptMaxLoc);
			/*for (int i = 0; i < matResult.rows; i++)
			{
				for (int j = 0; j < matResult.cols; j++)
				{
					OutputDebugString((L"R: " + to_wstring(i) + L" C: " + to_wstring(j) + L"\n").c_str());
				}

			}*/
			if (dMaxVal < vecLayerScore[iTopLayer])
				continue;
			vecMatchParameter.push_back(s_MatchParameter(Point2f(ptMaxLoc.x - fTranslationX, ptMaxLoc.y - fTranslationY), dMaxVal, vecAngles[i]));
			//lặp lại để tìm các đối tượng (mutil template matching) trong góc 1 quay
			for (int j = 0; j < m_iMaxPos + MATCH_CANDIDATE_NUM - 1; j++)
			{
				ptMaxLoc = GetNextMaxLoc(matResult, ptMaxLoc, pTemplData->vecPyramid[iTopLayer].size(), dValue, m_dMaxOverlap);
				//nếu Score < Score lớp đầu tiên thì break
				if (dValue < vecLayerScore[iTopLayer])
					break;
				vecMatchParameter.push_back(s_MatchParameter(Point2f(ptMaxLoc.x - fTranslationX, ptMaxLoc.y - fTranslationY), dValue, vecAngles[i]));
			}
		}
	}
	//cout << "Step 5" << endl;
	//sắp xếp mảng theo thứ tự
	sort(vecMatchParameter.begin(), vecMatchParameter.end(), compareScoreBig2Small);
	int iMatchSize = (int)vecMatchParameter.size();
	int iDstW = pTemplData->vecPyramid[iTopLayer].cols, iDstH = pTemplData->vecPyramid[iTopLayer].rows;
	//Hiển thị kết quả lớp đầu tiên
	if (m_bDebugMode == true) // nếu checkbox debug được check(false)
	{
		int iDebugScale = 2;

		Mat matShow, matResize;
		cv::resize(vecMatSrcPyr[iTopLayer], matResize, vecMatSrcPyr[iTopLayer].size() * iDebugScale);
		cvtColor(matResize, matShow, CV_GRAY2BGR);
		string str = cv::format("Toplayer, Candidate:%d", iMatchSize);
		vector<Point2f> vec;
		for (int i = 0; i < iMatchSize; i++)
		{
			Point2f ptLT, ptRT, ptRB, ptLB;
			double dRAngle = -vecMatchParameter[i].dMatchAngle * D2R;
			ptLT = ptRotatePt2f(vecMatchParameter[i].pt, ptCenter, dRAngle);
			ptRT = Point2f(ptLT.x + iDstW * (float)cos(dRAngle), ptLT.y - iDstW * (float)sin(dRAngle));
			ptLB = Point2f(ptLT.x + iDstH * (float)sin(dRAngle), ptLT.y + iDstH * (float)cos(dRAngle));
			ptRB = Point2f(ptRT.x + iDstH * (float)sin(dRAngle), ptRT.y + iDstH * (float)cos(dRAngle));
			line(matShow, ptLT * iDebugScale, ptLB * iDebugScale, Scalar(0, 255, 0));
			line(matShow, ptLB * iDebugScale, ptRB * iDebugScale, Scalar(0, 255, 0));
			line(matShow, ptRB * iDebugScale, ptRT * iDebugScale, Scalar(0, 255, 0));
			line(matShow, ptRT * iDebugScale, ptLT * iDebugScale, Scalar(0, 255, 0));
			cv::circle(matShow, ptLT * iDebugScale, 1, Scalar(0, 0, 255));
			vec.push_back(ptLT * iDebugScale);
			vec.push_back(ptRT * iDebugScale);
			vec.push_back(ptLB * iDebugScale);
			vec.push_back(ptRB * iDebugScale);

			string strText = cv::format("%d", i);
			putText(matShow, strText, ptLT * iDebugScale, FONT_HERSHEY_PLAIN, 1, Scalar(0, 255, 0));
		}
		cvNamedWindow(str.c_str(), 0x10000000);
		Rect rectShow = boundingRect(vec);
		cv::imshow(str, matShow);// (rectShow));
		//moveWindow (str, 0, 0);
	}
	//Hiển thị kết quả lớp đầu tiên
		//kết thúc giai đoạn đầu
	bool bSubPixelEstimation = m_bSubPixel;
	int iStopLayer = m_bStopLayer1 ? 1 : 0; //Khi được đặt thành 1: khớp thô, hy sinh độ chính xác để cải thiện tốc độ.
	//int iSearchSize = min (Core::m_iMaxPos + MATCH_CANDIDATE_NUM, (int)vecMatchParameter.size ());//Có thể không cần search hết, mất thời gian quá
	vector<s_MatchParameter> vecAllResult;
	//vòng lặp các đối tượng được tìm thấy qua từng góc xoay
	for (int i = 0; i < (int)vecMatchParameter.size(); i++)
		//for (int i = 0; i < iSearchSize; i++)
	{
		double dRAngle = -vecMatchParameter[i].dMatchAngle * D2R;
		Point2f ptLT = ptRotatePt2f(vecMatchParameter[i].pt, ptCenter, dRAngle);

		double dAngleStep = atan(2.0 / max(iDstW, iDstH)) * R2D;//thay đổi tối thiểu thành tối đa
		vecMatchParameter[i].dAngleStart = vecMatchParameter[i].dMatchAngle - dAngleStep;
		vecMatchParameter[i].dAngleEnd = vecMatchParameter[i].dMatchAngle + dAngleStep;
		if (iTopLayer <= iStopLayer)
		{
			vecMatchParameter[i].pt = Point2d(ptLT * ((iTopLayer == 0) ? 1 : 2));
			vecAllResult.push_back(vecMatchParameter[i]);
		}
		else
		{	//vòng lặp qua các lớp layer kim tự tháp
			for (int iLayer = iTopLayer - 1; iLayer >= iStopLayer; iLayer--)
			{
				//góc tìm kiếm
				dAngleStep = atan(2.0 / max(pTemplData->vecPyramid[iLayer].cols, pTemplData->vecPyramid[iLayer].rows)) * R2D;//thay đổi tối thiểu thành tối đa
				vector<double> vecAngles;
				//double dAngleS = vecMatchParameter[i].dAngleStart, dAngleE = vecMatchParameter[i].dAngleEnd;
				double dMatchedAngle = vecMatchParameter[i].dMatchAngle;
				if (m_bToleranceRange)
				{
					for (int i = -1; i <= 1; i++)
						vecAngles.push_back(dMatchedAngle + dAngleStep * i);
				}
				else
				{
					if (angleMax < VISION_TOLERANCE)
						vecAngles.push_back(0.0);
					else
						for (int i = -1; i <= 1; i++)
							vecAngles.push_back(dMatchedAngle + dAngleStep * i);
				}
				Point2f ptSrcCenter((vecMatSrcPyr[iLayer].cols - 1) / 2.0f, (vecMatSrcPyr[iLayer].rows - 1) / 2.0f);
				iSize = (int)vecAngles.size();
				vector<s_MatchParameter> vecNewMatchParameter(iSize);
				int iMaxScoreIndex = 0;
				double dBigValue = -1;
				//vòng lặp qua các góc 
				for (int j = 0; j < iSize; j++)
				{
					Mat matResult, matRotatedSrc;
					double dMaxValue = 0;
					Point ptMaxLoc;
					//lấy vùng xoay quan tâm
					GetRotatedROI(vecMatSrcPyr[iLayer], pTemplData->vecPyramid[iLayer].size(), ptLT * 2, vecAngles[j], matRotatedSrc);
					MatchTemplate(matRotatedSrc, pTemplData, matResult, iLayer, true);
					/*imshow("rotation image", matRotatedSrc);
					waitKey(300);*/
					//matchTemplate (matRotatedSrc, pTemplData->vecPyramid[iLayer], matResult, CV_TM_CCOEFF_NORMED);
					minMaxLoc(matResult, 0, &dMaxValue, 0, &ptMaxLoc);
					vecNewMatchParameter[j] = s_MatchParameter(ptMaxLoc, dMaxValue, vecAngles[j]);

					if (vecNewMatchParameter[j].dMatchScore > dBigValue)
					{
						iMaxScoreIndex = j;
						dBigValue = vecNewMatchParameter[j].dMatchScore;
					}
					//ước tính subpixel
					if (ptMaxLoc.x == 0 || ptMaxLoc.y == 0 || ptMaxLoc.x == matResult.cols - 1 || ptMaxLoc.y == matResult.rows - 1)
						vecNewMatchParameter[j].bPosOnBorder = true;
					if (!vecNewMatchParameter[j].bPosOnBorder)
					{
						for (int y = -1; y <= 1; y++)
							for (int x = -1; x <= 1; x++)
								vecNewMatchParameter[j].vecResult[x + 1][y + 1] = matResult.at<float>(ptMaxLoc + Point(x, y));
					}
					//ước tính subpixel
				}
				if (vecNewMatchParameter[iMaxScoreIndex].dMatchScore < vecLayerScore[iLayer])
					break;
				//ước tính subpixel
				if (bSubPixelEstimation
					&& iLayer == 0
					&& (!vecNewMatchParameter[iMaxScoreIndex].bPosOnBorder)
					&& iMaxScoreIndex != 0
					&& iMaxScoreIndex != 2)
				{
					double dNewX = 0, dNewY = 0, dNewAngle = 0;
					SubPixEsimation(&vecNewMatchParameter, &dNewX, &dNewY, &dNewAngle, dAngleStep, iMaxScoreIndex);
					vecNewMatchParameter[iMaxScoreIndex].pt = Point2d(dNewX, dNewY);
					vecNewMatchParameter[iMaxScoreIndex].dMatchAngle = dNewAngle;

				}
				//ước tính subpixel

				double dNewMatchAngle = vecNewMatchParameter[iMaxScoreIndex].dMatchAngle;

				//Trả lại hệ tọa độ khi xoay(GetRotatedROI) là (0, 0)
				Point2f ptPaddingLT = ptRotatePt2f(ptLT * 2, ptSrcCenter, dNewMatchAngle * D2R) - Point2f(3, 3);
				Point2f pt(vecNewMatchParameter[iMaxScoreIndex].pt.x + ptPaddingLT.x, vecNewMatchParameter[iMaxScoreIndex].pt.y + ptPaddingLT.y);
				//quay lại
				pt = ptRotatePt2f(pt, ptSrcCenter, -dNewMatchAngle * D2R);
				// sau mỗi lớp layer góc quay giảm đi 1 nửa cho đến khi lớp layer đến đáy của kim tự tháp
				if (iLayer == iStopLayer)
				{
					vecNewMatchParameter[iMaxScoreIndex].pt = pt * (iStopLayer == 0 ? 1 : 2);
					vecAllResult.push_back(vecNewMatchParameter[iMaxScoreIndex]);
				}
				else
				{
					//thay mới MatchAngle ptLT
					vecMatchParameter[i].dMatchAngle = dNewMatchAngle;
					vecMatchParameter[i].dAngleStart = vecMatchParameter[i].dMatchAngle - dAngleStep / 2;
					vecMatchParameter[i].dAngleEnd = vecMatchParameter[i].dMatchAngle + dAngleStep / 2;
					ptLT = pt;
				}
			}

		}
	}
	//cout << "Step 6" << endl;
	FilterWithScore(&vecAllResult, m_dScore);

	//Cuối cùng lọc ra chồng chéo
	iDstW = pTemplData->vecPyramid[iStopLayer].cols * (iStopLayer == 0 ? 1 : 2);
	iDstH = pTemplData->vecPyramid[iStopLayer].rows * (iStopLayer == 0 ? 1 : 2);

	for (int i = 0; i < (int)vecAllResult.size(); i++)
	{
		Point2f ptLT, ptRT, ptRB, ptLB;
		double dRAngle = -vecAllResult[i].dMatchAngle * D2R;
		ptLT = vecAllResult[i].pt;
		ptRT = Point2f(ptLT.x + iDstW * (float)cos(dRAngle), ptLT.y - iDstW * (float)sin(dRAngle));
		ptLB = Point2f(ptLT.x + iDstH * (float)sin(dRAngle), ptLT.y + iDstH * (float)cos(dRAngle));
		ptRB = Point2f(ptRT.x + iDstH * (float)sin(dRAngle), ptRT.y + iDstH * (float)cos(dRAngle));
		//ghi hình chữ nhật xoay
		vecAllResult[i].rectR = RotatedRect(ptLT, ptRT, ptRB);
	}
	FilterWithRotatedRect(&vecAllResult, CV_TM_CCOEFF_NORMED, m_dMaxOverlap);// lọc với hình chữa nhật xoay chồng chéo
	//Cuối cùng lọc ra chồng chéo

	//Sắp xếp theo điểm số
	sort(vecAllResult.begin(), vecAllResult.end(), compareScoreBig2Small);
	// hien thi thoi gian tinh toan guidialog
	//m_strExecureTime.Format((L"%s ExecureTime : %d ms"), m_strLanExecutionTime, int(clock() - d1));
	//mainDlg->m_statusBar.SetPaneText(0, m_strExecureTime);

	//xóa vector lưu trữ object được tìm thấy
	//Core::m_vecSingleTargetData.clear(); //skip
	//xoa danh sach guidialog

	iMatchSize = (int)vecAllResult.size();
	if (vecAllResult.size() == 0)
	{
		cout << "No Match" << endl;
		return result;
	}

	int iW = pTemplData->vecPyramid[0].cols, iH = pTemplData->vecPyramid[0].rows;

	for (int i = 0; i < iMatchSize; i++)
	{
		s_SingleTargetMatch sstm;
		vector<double> FeedBack;
		double dRAngle = -vecAllResult[i].dMatchAngle * D2R;

		sstm.ptLT = vecAllResult[i].pt;
		sstm.ptRT = Point2d(sstm.ptLT.x + iW * cos(dRAngle), sstm.ptLT.y - iW * sin(dRAngle));
		sstm.ptLB = Point2d(sstm.ptLT.x + iH * sin(dRAngle), sstm.ptLT.y + iH * cos(dRAngle));
		sstm.ptRB = Point2d(sstm.ptRT.x + iH * sin(dRAngle), sstm.ptRT.y + iH * cos(dRAngle));
		sstm.ptCenter = Point2d((sstm.ptLT.x + sstm.ptRT.x + sstm.ptRB.x + sstm.ptLB.x) / 4, (sstm.ptLT.y + sstm.ptRT.y + sstm.ptRB.y + sstm.ptLB.y) / 4);
		sstm.dMatchedAngle = -vecAllResult[i].dMatchAngle;
		sstm.dMatchScore = vecAllResult[i].dMatchScore;
		/*FeedBack.push_back(sstm.dMatchScore);
		FeedBack.push_back(sstm.dMatchedAngle);
		FeedBack.push_back(sstm.ptCenter.x);
		FeedBack.push_back(sstm.ptCenter.y);
		result.push_back(FeedBack);*/
		result.score = sstm.dMatchScore;
		result.angle = sstm.dMatchedAngle;
		result.x = sstm.ptCenter.x;
		result.y = sstm.ptCenter.y;
		if (sstm.dMatchedAngle < -180)
			sstm.dMatchedAngle += 360;
		if (sstm.dMatchedAngle > 180)
			sstm.dMatchedAngle -= 360;
		m_vecSingleTargetData.push_back(sstm);
		/*OutputRoi(sstm, m_matSrc);*/
		if (i + 1 == m_iMaxPos)
			break;
	}
	//cout << "Step 7" << endl;
	//cắt ảnh theo đối tượng được tìm thấy
	vector<Point> polygon{ Point(m_vecSingleTargetData[0].ptLT.x,m_vecSingleTargetData[0].ptLT.y),Point(m_vecSingleTargetData[0].ptRT.x,m_vecSingleTargetData[0].ptRT.y)
		,Point(m_vecSingleTargetData[0].ptRB.x,m_vecSingleTargetData[0].ptRB.y),Point(m_vecSingleTargetData[0].ptLB.x,m_vecSingleTargetData[0].ptLB.y) };
	Mat cropImage = polygonCropImage(m_Src, polygon);
	if (cropImage.rows == 0 || cropImage.cols == 0) { cout << "Error Roi Size" << endl;  return  mResult(0, 0, 0, 0); }
	//cout << "Step 8" << endl;
	//imshow("Cropimagepolygon", cropImage);
	//waitKey(10);
	int bestIndex;
	double bestScore = 0;
	//lặp lại 10 lần
	for (int j = 1; j < 10; j++)
	{
		double AngleStep = dAngleStep / pow(2, iTopLayer + j);
		double AngleStart = m_vecSingleTargetData[0].dMatchedAngle - dAngleStep / pow(2, iTopLayer + j);
		double AngleEnd = m_vecSingleTargetData[0].dMatchedAngle + dAngleStep / pow(2, iTopLayer + j);
		/*outputDialog(AngleStep);
		outputDialog(AngleStart);
		outputDialog(AngleEnd);*/
		for (double i = AngleStart; i <= AngleEnd; i += AngleStep)
		{
			if (i == m_vecSingleTargetData[0].dMatchedAngle)
			{
				continue;
			}
			//xoay ảnh theo góc mới
			Mat newRotateImage = rotateMat(cropImage, i);
			//tiến hành so sánh
			mResult result2 = TemplateMatching(newRotateImage, m_Dst);
			//nếu kết quả là tốt nhất
			if (m_vecSingleTargetData[0].dMatchScore < result2.score)
			{
				m_vecSingleTargetData[0].dMatchScore = result2.score;
				m_vecSingleTargetData[0].ptCenter = Point2d(result2.x, result2.y);
				m_vecSingleTargetData[0].dMatchedAngle = i;
				result.x = m_vecSingleTargetData[0].ptCenter.x;
				result.y = m_vecSingleTargetData[0].ptCenter.y;
				result.score = m_vecSingleTargetData[0].dMatchScore;
				result.angle = m_vecSingleTargetData[0].dMatchedAngle;
			}
			//outputDialog(to_string(result2[2]) +"\t" + to_string(i), true);

		}
		//outputDialog("\n");
	}
	//cout << "Step 9" << endl;
	if (m_bFindLines == true)
	{
		//cắt ảnh theo hình chữ nhật xoay
		vector<vector<Point>>  m_polygon;
		m_polygon.resize(1);
		//thêm các điểm Point vào vector để tạo thành hình đa giác
		m_polygon.at(0).push_back(m_vecSingleTargetData[0].ptLT);
		m_polygon.at(0).push_back(m_vecSingleTargetData[0].ptLB);
		m_polygon.at(0).push_back(m_vecSingleTargetData[0].ptRB);
		m_polygon.at(0).push_back(m_vecSingleTargetData[0].ptRT);
		Mat resize_src;
		m_matSrc.copyTo(resize_src);
		Mat mask(m_matSrc.size(), CV_8UC1);
		mask = 0;
		cv::drawContours(mask, m_polygon, 0, Scalar(255, 255, 255), -1);
		Mat imgCrop(resize_src.size(), CV_8UC3, Scalar(0, 0, 0));
		//cắt hình ảnh theo mặt nạ
		resize_src.copyTo(imgCrop, mask);
		//tạo hộp giới hạn cho đa giác
		//imshow("Crop", imgCrop);
		cv::Rect r = cv::boundingRect(m_polygon.at(0));
		//cắt hình ảnh theo hộp giới hạn
		imgCrop = imgCrop(r);
		mask = mask(r);
		//Core::houghLinesP(imgCrop, 6, 3);
		//convert màu ảnh làm mất đường viền hiển thị hình đa giác (màu đỏ)
		//cv::cvtColor(imgCrop, imgCrop, CV_BGR2GRAY);
		if (m_bCannyShow == true)
		{
			Mat edge;
			cv::Canny(imgCrop, edge, m_iCannyMinThresh, m_iCannyMaxThresh, 3);
			imshow("canny", edge);
			//imshow("Crop",imgCrop);
		}
		///phần ảnh được cắt
		m_vecSingleTargetData[0].rect = r;
		result.x = m_vecSingleTargetData[0].ptCenter.x;
		result.y = m_vecSingleTargetData[0].ptCenter.y;
		result.score = m_vecSingleTargetData[0].dMatchScore;
		result.angle = m_vecSingleTargetData[0].dMatchedAngle;
		//tim duong line

		//std::vector<cv::Vec4i> lines = houghLinesP(imgCrop, m_iLinesThresh, m_iLinesLenght, m_iLinesGap, m_iCannyMinThresh, m_iCannyMaxThresh);
		//if (lines.size() > 0)
		//{
		//	//// Draw lines on the image
		//	for (size_t i = 0; i < lines.size(); i++) {
		//		m_vecSingleTargetData[0].lines.push_back(lines[i]);
		//		//	Vec4i l = m_vecSingleTargetData[0].lines[i];
		//		//	line(m_matSrc, Point(l[0]+ r.x, l[1] +r.y), Point(l[2] + r.x, l[3] + r.y), Scalar(0, 0, 255), 4, LINE_AA);
		//		//	//line(imgCrop, Point(l[0],l[1]), Point(l[2],l[3]), Scalar(0, 0, 255), 1, LINE_AA);
		//	}
		//	//gán giá trị góc xoay bằng góc của lines
		//	Point2d pOgrin = Point2d(double(m_vecSingleTargetData[0].lines[0][0]), double(m_vecSingleTargetData[0].lines[0][1]));
		//	Point2d p1 = Point2d(double(m_vecSingleTargetData[0].lines[0][2]), double(m_vecSingleTargetData[0].lines[0][3]));
		//	Point2d p2 = Point2d(double(5000), double(m_vecSingleTargetData[0].lines[0][1]));
		//	m_vecSingleTargetData[0].dMatchedAngle = FindAngle(pOgrin, p1, p2);
		//	//imshow("crop image", imgCrop);
		//	///*cv::imwrite(Core::path_DstPolygon, imgCropCopy);
		//	//*/cv::imwrite(Core::path_MaskDstPolygon, mask);
		//}
		m_polygon.clear();
	}
	//cout << "Step 10" << endl;
	return result;
}

////////////////////////////////////////////////////////////////////////////////////end Match/////////////////////////////////////////////////////////////////////


//void Core::example_FastTemplateMatching()
//{
//
//	HWND hwndParent = FindWindowA(("Class Name Vision Align"), ("Vision Align"));
//	CWnd* cWndParent = CWnd::FromHandle(hwndParent);
//	CVisionAlignMFCDlg* mainDlg = (CVisionAlignMFCDlg*)cWndParent;
//	HWND hwndMain = FindWindowExA(NULL, NULL, "Class Name Vision Align", "Vision Align");
//	CWnd* cWndMain = CWnd::FromHandle(hwndMain);
//	/*CString FileNameSrc = L"D:\\Recycle Bin\\pic2\\0.PNG";
//	Mat src = Read_TCHAR(FileNameSrc.GetBuffer());
//	FileNameSrc.ReleaseBuffer();
//
//	CString FileNameDst = L"D:\\Recycle Bin\\pic2\\0tm.png";
//	Mat dst = Read_TCHAR(FileNameDst.GetBuffer());
//	FileNameDst.ReleaseBuffer();*/
//	Mat src = imread("D:/Recycle Bin/pic2/7.PNG", IMREAD_GRAYSCALE);
//	Mat dst = imread("../x64/Release/Pattern/master1.png", IMREAD_GRAYSCALE);
//	startTime();
//	//xóa dữ liệu lưu vào vector và listMsg
//	Core::m_vecSingleTargetData.clear();
//	mainDlg->m_listMsg.DeleteAllItems();
//	mainDlg->updateParameterFastTemplate();
//	vector<string> readdata = readFile(Core::path_ConfigROI1);
//	Rect roi1;
//	roi1.x = stoi(readdata[0]);
//	roi1.y = stoi(readdata[1]);
//	roi1.width = stoi(readdata[2]) - stoi(readdata[0]);
//	roi1.height = stoi(readdata[3]) - stoi(readdata[1]);
//	Mat src_crop1 = src(roi1);
//	//cv::cvtColor(m_matSrc, srcConvert, COLOR_GRAY2BGR);
//	Core::m_bShowResult = true;
//	m_tool_number = 1;
//	matchFastTemplate(src_crop1, Core::m_matDst1, roi1);
//
//	mainDlg->m_matDst = Core::m_matDst1;
//	mainDlg->RefreshSrcView();
//	stopTime();
//	tackTime();
//}

#pragma endregion