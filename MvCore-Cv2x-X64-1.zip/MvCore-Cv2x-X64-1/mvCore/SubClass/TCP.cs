﻿using DirectShowLib;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MvCore
{
    [field: NonSerialized]
    public delegate void serverReciverHandler(Object sender, string Data);
    [Serializable]
    #region Server

    public partial class Server
    {
        #region Variable
        [field: NonSerialized] public event serverReciverHandler ReciverEvent;
        [NonSerialized] private byte[] _buffer = new byte[1024];
        [NonSerialized] public List<Socket> __ClientSockets;
        [NonSerialized] List<string> _names = new List<string>();
        [NonSerialized] public Socket _serverSocket;
        [NonSerialized] string ipAddress;
        [NonSerialized] int Port;
        [NonSerialized] public bool connectStatus = false;
        [NonSerialized] public List<Socket> l_Socket = new List<Socket>();


        #endregion

        public Server() { }
        public Server(int _port)
        {
            ipAddress = getIPAddress();
            Port = _port;
            connectStatus = Connect();

        }

        public Server(string _ipAddress, int _port)
        {
            ipAddress = _ipAddress;
            Port = _port;
            connectStatus = Connect();
        }


        private bool IsPortInUse(int port)
        {
            bool inUse = false;
            IPGlobalProperties ipProperties = IPGlobalProperties.GetIPGlobalProperties();
            IPEndPoint[] tcpEndPoints = ipProperties.GetActiveTcpListeners();

            foreach (IPEndPoint endPoint in tcpEndPoints)
            {
                if (endPoint.Port == port)
                {
                    inUse = true;
                    break;
                }
            }

            return inUse;
        }
        // mở cổng kết nối Server
        public bool Connect()
        {
            try
            {
                if (IsPortInUse(Port) == false)
                {
                    __ClientSockets = new List<Socket>();
                    _serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    Console.WriteLine("Setting up my_server . . .");
                    _serverSocket.Bind(new IPEndPoint(IPAddress.Parse(ipAddress), Convert.ToInt16(Port)));//Convert.ToInt64("192.168.0.118") //IPAddress.Any
                    _serverSocket.Listen(1);
                    //nhận dữ liệu từ cổng kết nối
                    _serverSocket.BeginAccept(new AsyncCallback(AppceptCallback), null);
                    return true;
                }
                return false;

            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public void Close()
        {
            if (_serverSocket != null)
            {
                foreach (Socket client in __ClientSockets)
                {
                    client.Dispose();
                }
                _serverSocket.Close();
                _serverSocket.Dispose();
                _serverSocket = null;
                connectStatus = false;
            }
        }
        #region API
        private void Print(string msg)
        {
        }
        public static string getIPAddress()
        {
            string IPAddress = string.Empty;
            IPHostEntry Host = default(IPHostEntry);
            string Hostname = null;
            Hostname = System.Environment.MachineName;
            Host = Dns.GetHostEntry(Hostname);
            foreach (IPAddress IP in Host.AddressList)
            {
                if (IP.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    IPAddress = Convert.ToString(IP);
                }
            }
            return IPAddress;
        }
        //sự kiện chấp nhận kết nối từ Client
        public void AppceptCallback(IAsyncResult ar)
        {
            Thread.Sleep(20);
            try
            {
                if (_serverSocket != null)
                {

                    Socket socket = _serverSocket.EndAccept(ar);
                    __ClientSockets.Add(socket);
                    //socket.RemoteEndPoint.ToString()); tên socket
                    socket.BeginReceive(_buffer, 0, _buffer.Length, SocketFlags.None, new AsyncCallback(ReceiveCallback), socket);
                    _serverSocket.BeginAccept(new AsyncCallback(AppceptCallback), null);
                }
            }
            catch (Exception ex) { Print(ex.ToString()); }
        }

        //đóng kết nối Client
        private void RemoveClient(Socket socket)
        {
            for (int i = 0; i < __ClientSockets.Count; i++)
            {
                if (__ClientSockets[i].RemoteEndPoint.ToString().Equals(socket.RemoteEndPoint.ToString()))
                {
                    __ClientSockets.RemoveAt(i);
                }
            }
        }
        //sự kiện nhận dữ liệu từ Client
        public void ReceiveCallback(IAsyncResult ar)
        {
            Thread.Sleep(20);
            try
            {
                if (_serverSocket != null)
                {
                    Socket socket = (Socket)ar.AsyncState;
                    if (socket.Connected)
                    {
                        int received;
                        try
                        {
                            received = socket.EndReceive(ar);
                        }
                        catch (Exception)
                        {
                            RemoveClient(socket);
                            return;
                        }
                        if (received != 0)
                        {
                            byte[] dataBuf = new byte[received];
                            Array.Copy(_buffer, dataBuf, received);
                            string text = Encoding.ASCII.GetString(dataBuf);
                            //Console.WriteLine("Client Say: " + text);
                            ReciverEvent?.Invoke(socket, text);

                        }
                        else
                        {
                            //RemoveClient(socket);
                        }
                    }
                    socket.BeginReceive(_buffer, 0, _buffer.Length, SocketFlags.None, new AsyncCallback(ReceiveCallback), socket); //error
                }
            }
            catch (Exception ex) 
            { 
                Print(ex.Message); 
            }
        }


        private void SendCallback(IAsyncResult AR)
        {
            Socket socket = (Socket)AR.AsyncState;
            socket.EndSend(AR);
        }
        //gửi dữ liệu xuống Client
        private void SendData(Socket socket,int index, string noidung)
        {
            try
            {
                byte[] data = Encoding.ASCII.GetBytes(noidung);
                socket.BeginSend(data, 0, data.Length, SocketFlags.None, new AsyncCallback(SendCallback), socket);
                _serverSocket.BeginAccept(new AsyncCallback(AppceptCallback), null);
            }
            catch (Exception)
            {
                __ClientSockets.RemoveAt(index);
            }
            
        }
        public void send(string Data_Send)
        {
            if (__ClientSockets != null)
            {
                for (int j = 0; j < __ClientSockets.Count; j++)
                {
                    SendData(__ClientSockets[j],j, Data_Send);
                }
            } 
        }

      

        #endregion
    }
    #endregion
    [field: NonSerialized]
    public delegate void clientReciverHandler(Object sender, string Data);

    [Serializable]
    #region Client
    public partial class Client
    {
        #region Variable
        [field: NonSerialized] public event clientReciverHandler ReciverEvent;
        [NonSerialized] private string ipAddress;
        [NonSerialized] private int Port;
        [NonSerialized] public bool connectStatus = false;
        [NonSerialized] public Socket _clientSocket;//= new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        [NonSerialized] byte[] receivedBuf = new byte[1024];

        #endregion

        public Client() { }
        public Client(int _Port)
        {
            ipAddress = getIPAddress();
            Port = _Port;
            connectStatus = Connect();
        }
        public Client(string _IPAdrress, int _Port)
        {
            ipAddress = _IPAdrress;
            Port = _Port;
            connectStatus = Connect();
                
        }



        #region API
        public bool Connect()
        {
            _clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            int retry = 0;
            while (!_clientSocket.Connected)
            {
                try
                {
                    if (retry > 3) return false;
                    _clientSocket.Connect(ipAddress, Port);

                }
                catch (SocketException ex)
                {
                    retry++;
                    Print(ex.Message);
                    return false;
                }
            }
            Print("Connected!");
            _clientSocket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveData), _clientSocket);
            return true;
        }

        public void Close()
        {
            _clientSocket.Close();
            _clientSocket = null;
            connectStatus = false;
        }


        void Print(string Msg)
        {

        }
        public string getIPAddress()
        {
            string IPAddress = string.Empty;
            IPHostEntry Host = default(IPHostEntry);
            string Hostname = null;
            Hostname = System.Environment.MachineName;
            Host = Dns.GetHostEntry(Hostname);
            foreach (IPAddress IP in Host.AddressList)
            {
                if (IP.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    IPAddress = Convert.ToString(IP);
                }
            }
            return IPAddress;
        }


        //gửi dữ liệu
        public void send(string Data_Send)
        {
            try
            {
                if (_clientSocket != null)
                {
                    if (_clientSocket.Connected)
                    {
                        byte[] buffer = Encoding.ASCII.GetBytes(Data_Send);
                        _clientSocket.Send(buffer);
                        //form.txt_Receiver.AppendText("\nClient: " + form.txt_Send.Text);
                        //form.txt_Receiver_Socket.AppendText("\nClient: " + Data_Send);
                    }
                }
            }
            catch (Exception ex) { Print(ex.Message); }
        }
        //dữ liệu nhận được từ Server
        private void ReceiveData(IAsyncResult ar)
        {
            Thread.Sleep(20);
            try
            {
                if (_clientSocket != null)
                {
                    if (_clientSocket.Connected == true)
                    {
                        Socket socket = (Socket)ar.AsyncState;
                        int received = socket.EndReceive(ar);
                        byte[] dataBuf = new byte[received];
                        Array.Copy(receivedBuf, dataBuf, received);
                        string text = Encoding.ASCII.GetString(dataBuf);
                        ReciverEvent?.Invoke(socket, text);
                        _clientSocket.BeginReceive(receivedBuf, 0, receivedBuf.Length, SocketFlags.None, new AsyncCallback(ReceiveData), _clientSocket);
                    }
                }
            }
            catch (Exception ex) { Print(ex.Message); }
        }
        // không dùng
        private void SendLoop()
        {
            while (true)
            {
                byte[] receivedBuf = new byte[1024];
                int rev = _clientSocket.Receive(receivedBuf);
                if (rev != 0)
                {
                    byte[] data = new byte[rev];
                    Array.Copy(receivedBuf, data, rev);
                    string text = Encoding.ASCII.GetString(data);
                }
                else _clientSocket.Close();

            }
        }




        #endregion
    }
    #endregion
}
