﻿using MvCore;
using System;
using System.Windows.Forms;

namespace test  // namespace của bạn
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new testForm());
        }
    }
}