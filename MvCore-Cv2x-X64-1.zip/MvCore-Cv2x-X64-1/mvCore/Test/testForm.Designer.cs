﻿namespace MvCore
{
    partial class testForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mvJobEdit1 = new MvCore.Edit.MvJobEdit();
            this.SuspendLayout();
            // 
            // mvJobEdit1
            // 
            this.mvJobEdit1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.mvJobEdit1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mvJobEdit1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mvJobEdit1.Location = new System.Drawing.Point(0, 0);
            this.mvJobEdit1.Name = "mvJobEdit1";
            this.mvJobEdit1.Size = new System.Drawing.Size(1014, 622);
            this.mvJobEdit1.TabIndex = 0;
            // 
            // testForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 622);
            this.Controls.Add(this.mvJobEdit1);
            this.Name = "testForm";
            this.Text = "testForm";
            this.ResumeLayout(false);

        }

        #endregion

        private Edit.MvJobEdit mvJobEdit1;
    }
}