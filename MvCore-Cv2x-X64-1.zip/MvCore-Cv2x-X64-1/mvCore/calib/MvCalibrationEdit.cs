﻿using MvCore.Edit;
using MvCore.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
//using MvCore.Interface;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MvCore.Edit
{
    public partial class MvCalibrationEdit : MvToolEditBase
    {
        public event EventHandler OnSaved;
        public MvCalibrationEdit()
        {
            InitializeComponent();
            InitBinding();
            
            MvCalib.calDataEvent += SvCalib_calDataEvent;
            //calibrationStartFunc = new Func<bool>(CalibrationStart);
            //rotationStartFunc = new Func<bool>(RotationStart); 
            //manualStartFunc = new Func<bool>(ManualMoveStart);
            if(calibration == null)
                calibration = new MvCalibration();
            this.SubjectChanged += SvCalibrationEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            

            jobEdit = new MvJobEdit();
            recipeForm = new MvToolEditForm(jobEdit);
            InitImageInfo();
        }

        public MvCalib Subject // tool class ( Chủ thể )
        {
            get { return base.GetSubject() as MvCalib; }
            set { base.SetSubject(value); }
        }

        public override void formLoad()
        {
            SvCalib_calDataEvent(Subject.calibration.CalData);
        }

        private void SvCalib_calDataEvent(MvCalibrationData data)
        {
            if (this.InvokeRequired)
            {
                // Gọi lại chính hàm này trong UI thread
                this.Invoke(new Action<MvCalibrationData>(SvCalib_calDataEvent), data);
                return;
            }

            // --- Code bên dưới an toàn với UI thread ---
          
            DrawCalibrationResult(svDisplayViewEdit.Display);
            DrawRotationResult(svDisplayViewEdit.Display);
        }

        SvImageInfo calibrationImageInfo;
        SvImageInfo rotationImageInfo;
                
        void InitImageInfo()
        {
            calibrationImageInfo = new SvImageInfo("Calibration");
            calibrationImageInfo.drawingFunc = DrawCalibrationResult;
            
            rotationImageInfo = new SvImageInfo("Rotation");
            rotationImageInfo.drawingFunc = DrawRotationResult;

            SvDisplayViewEdit.InsertCustomImage(0, calibrationImageInfo);
            SvDisplayViewEdit.InsertCustomImage(1, rotationImageInfo);
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedTab == tp_Cal || tabControl.SelectedTab == tp_CalResult)
                SvDisplayViewEdit.imageListComboBox.SelectedItem = calibrationImageInfo;
            else if (tabControl.SelectedTab == tp_Rot || tabControl.SelectedTab == tp_RotResult)
                SvDisplayViewEdit.imageListComboBox.SelectedItem = rotationImageInfo;
            else
                SvDisplayViewEdit.imageListComboBox.SelectedItem = null;
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("Calibration"))
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(originPoint);        
        }

       
        MvCalibration calibration;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvCalibration Calibration
        {
            get { return calibration; }
            set
            {
                calibration = value;
                if (value == null) return;
                base.NotifySubjectChanged(this, null);
            }
        }

        void SvCalibrationEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject.calibration.CalData;
            source.ResetBindings(true);
            source2.DataSource = Subject;
            source2.ResetBindings(true);
            SvDisplayViewEdit.RefreshImage();
            tabControl_SelectedIndexChanged(this, null);
        }

        BindingSource source;
        BindingSource source2;

        public double DistanceX
        {
            get { return Subject.calibration.CalData.Distance.X; }
            set { Subject.calibration.CalData.Distance = new Point2d( value, Subject.calibration.CalData.Distance.Y); }
        }
        public double DistanceY
        {
            get { return Subject.calibration.CalData.Distance.Y; }
            set { Subject.calibration.CalData.Distance = new Point2d( Subject.calibration.CalData.Distance.X,value); }
        }

        public double VisionTT_TCPX
        {
            get { return Subject.calibration.CalData.VisionTT_TCP.X; }
            set { Subject.calibration.CalData.VisionTT_TCP = new Point2d(value, Subject.calibration.CalData.VisionTT_TCP.Y); }
        }
        public double VisionTT_TCPY
        {
            get { return Subject.calibration.CalData.VisionTT_TCP.Y; }
            set { Subject.calibration.CalData.VisionTT_TCP = new Point2d(Subject.calibration.CalData.VisionTT_TCP.X, value); }
        }

        public double RobotTT_TCPX
        {
            get { return Subject.calibration.CalData.RobotTT_TCP.X; }
            set { Subject.calibration.CalData.RobotTT_TCP = new Point2d(value, Subject.calibration.CalData.RobotTT_TCP.Y); }
        }
        public double RobotTT_TCPY
        {
            get { return Subject.calibration.CalData.RobotTT_TCP.Y; }
            set { Subject.calibration.CalData.RobotTT_TCP = new Point2d(Subject.calibration.CalData.RobotTT_TCP.X, value); }
        }

        public double VisionHE_TCPX
        {
            get { return Subject.calibration.CalData.VisionHE_TCP.X; }
            set { Subject.calibration.CalData.VisionHE_TCP = new Point2d(value, Subject.calibration.CalData.VisionHE_TCP.Y); }
        }
        public double VisionHE_TCPY
        {
            get { return Subject.calibration.CalData.VisionHE_TCP.Y; }
            set { Subject.calibration.CalData.VisionHE_TCP = new Point2d(Subject.calibration.CalData.VisionHE_TCP.X, value); }
        }

        public double RobotHE_TCPX
        {
            get { return Subject.calibration.CalData.RobotHE_TCP.X; }
            set { Subject.calibration.CalData.RobotHE_TCP = new Point2d(value, Subject.calibration.CalData.RobotHE_TCP.Y); }
        }
        public double RobotHE_TCPY
        {
            get { return Subject.calibration.CalData.RobotHE_TCP.Y; }
            set { Subject.calibration.CalData.RobotHE_TCP = new Point2d(Subject.calibration.CalData.RobotHE_TCP.X, value); }
        }




        public double VisionMasterX
        {
            get { return Subject.calibration.CalData.VisionMaster.X; }
            set { Subject.calibration.CalData.VisionMaster = new Point3d(value, Subject.calibration.CalData.VisionMaster.Y, Subject.calibration.CalData.VisionMaster.Z); }
        }
        public double VisionMasterY
        {
            get { return Subject.calibration.CalData.VisionMaster.Y; }
            set { Subject.calibration.CalData.VisionMaster = new Point3d(Subject.calibration.CalData.VisionMaster.X,value, Subject.calibration.CalData.VisionMaster.Z); }
        }

        public double VisionMasterZ
        {
            get { return Subject.calibration.CalData.VisionMaster.Z; }
            set { Subject.calibration.CalData.VisionMaster = new Point3d(Subject.calibration.CalData.VisionMaster.X, Subject.calibration.CalData.VisionMaster.Y, value); }
        }

        public double RobotMasterX
        {
            get { return Subject.calibration.CalData.RobotMaster.X; }
            set { Subject.calibration.CalData.RobotMaster = new Point3d(value, Subject.calibration.CalData.RobotMaster.Y, Subject.calibration.CalData.RobotMaster.Z); }
        }
        public double RobotMasterY
        {
            get { return Subject.calibration.CalData.RobotMaster.Y; }
            set { Subject.calibration.CalData.RobotMaster = new Point3d(Subject.calibration.CalData.RobotMaster.X, value, Subject.calibration.CalData.RobotMaster.Z); }
        }

        public double RobotMasterZ
        {
            get { return Subject.calibration.CalData.RobotMaster.Z; }
            set { Subject.calibration.CalData.RobotMaster = new Point3d(Subject.calibration.CalData.RobotMaster.X, Subject.calibration.CalData.RobotMaster.Y, value); }
        }

        void InitBinding()
        {
            source = new BindingSource(typeof(MvCalibrationData), null);
            source2 = new BindingSource(typeof(MvCalib), null);
            nud_SelectedTP.DataBindings.Add("Value", source, "GPNo", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Cal_PitchH.DataBindings.Add("Value", source, "PitchH", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Cal_PitchV.DataBindings.Add("Value", source, "PitchV", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Cal_PointH.DataBindings.Add("Value", source, "PointH", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Cal_PointV.DataBindings.Add("Value", source, "PointV", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Cal_ShiftH.DataBindings.Add("Value", source, "CalShiftH", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Cal_ShiftV.DataBindings.Add("Value", source, "CalShiftV", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_AreaH.DataBindings.Add("Value", source, "AreaH", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_AreaV.DataBindings.Add("Value", source, "AreaV", true, DataSourceUpdateMode.OnPropertyChanged, 3f);

            nud_Rot_AngleFrom.DataBindings.Add("Value", source, "AngleFrom", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Rot_AngleTo.DataBindings.Add("Value", source, "AngleTo", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Rot_RotCount.DataBindings.Add("Value", source, "RotCount", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Rot_ShiftH.DataBindings.Add("Value", source, "RotShiftH", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_Rot_ShiftV.DataBindings.Add("Value", source, "RotShiftV", true, DataSourceUpdateMode.OnPropertyChanged, 3f);

            cb_SelectTool.DisplayMember = "Key"; cb_SelectTool.ValueMember = "Value";
            cb_SelectTool.DataSource = Enum.GetValues(typeof(MvCalib.E_Tool)).Cast<MvCalib.E_Tool>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_SelectTool.DataBindings.Add("SelectedValue", source2, "Tool", true, DataSourceUpdateMode.OnPropertyChanged);

            txt_distanceX.DataBindings.Add("Text", this, "DistanceX", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_distanceY.DataBindings.Add("Text", this, "DistanceY", true, DataSourceUpdateMode.OnPropertyChanged, 3f);

            txt_VisionTCP_X.DataBindings.Add("Text", this, "VisionTT_TCPX", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_VisionTCP_Y.DataBindings.Add("Text", this, "VisionTT_TCPY", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_RobotTCP_X.DataBindings.Add("Text", this, "RobotTT_TCPX", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_RobotTCP_Y.DataBindings.Add("Text", this, "RobotTT_TCPY", true, DataSourceUpdateMode.OnPropertyChanged, 3f);

            txt_VisionHE_TCP_X.DataBindings.Add("Text", this, "VisionHE_TCPX", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_VisionHE_TCP_Y.DataBindings.Add("Text", this, "VisionHE_TCPY", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_RobotHE_TCP_X.DataBindings.Add("Text", this, "RobotHE_TCPX", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_RobotHE_TCP_Y.DataBindings.Add("Text", this, "RobotHE_TCPY", true, DataSourceUpdateMode.OnPropertyChanged, 3f);


            txt_VisionMaster_X.DataBindings.Add("Text", this, "VisionMasterX", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_VisionMaster_Y.DataBindings.Add("Text", this, "VisionMasterY", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_VisionMaster_Z.DataBindings.Add("Text", this, "VisionMasterZ", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_RobotMaster_X.DataBindings.Add("Text", this, "RobotMasterX", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_RobotMaster_Y.DataBindings.Add("Text", this, "RobotMasterY", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_RobotMaster_Z.DataBindings.Add("Text", this, "RobotMasterZ", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            cb_saveLog.DataSource = new List<bool> { true, false };
            cb_saveLog.DataBindings.Add("Text", source2, "SaveLog", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
        }

        void InitCalibration()
        {
            calibrationJob = new MvJob();
            calibrationJob.ToolList.Add(new MvAcquisition());
            MvTemplateMatch template = new MvTemplateMatch();

            template.AutoParam = false;
            template.AngleNeg = 20;
            template.AnglePos = 20;
            template.ScaleFirst = 3;
            template.ScaleLast = 1;

            calibrationJob.ToolList.Add(template);
            
        }

        void InitRotation()
        {
            rotationJob = new MvJob();
            rotationJob.ToolList.Add(new MvAcquisition());
            MvTemplateMatch template = new MvTemplateMatch();

            template.AutoParam = false;
            template.AngleNeg = 20;
            template.AnglePos = 20;
            template.ScaleFirst = 3;
            template.ScaleLast = 1;

            rotationJob.ToolList.Add(new MvTemplateMatch());
        }

        MvJob rotationJob;
        MvJob calibrationJob;

        public MvJobEdit jobEdit;
        MvToolEditForm recipeForm;
        
        private void btn_LoadRecipe_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            MvJob job;
            SvImageInfo info;

            if (btn == btn_LoadCalRcp)
            {
                if (calibrationJob == null) InitCalibration();
                job = calibrationJob;
                info = calibrationImageInfo;
            }
            else if (btn == btn_LoadRotRcp)
            {
                if (rotationJob == null) InitRotation();
                job = rotationJob;
                info = rotationImageInfo;
            }
            else
                return;

            jobEdit.PATH_JOB = this.PATH_JOB;
            jobEdit.Job = job;
            recipeForm.ShowDialog();

            job.Run();

            MvAcquisition acqusitionTool = job.ToolList[0] as MvAcquisition;

            if (acqusitionTool != null)
                info.Image = acqusitionTool.AcqusitionImage;

            SvDisplayViewEdit.RefreshImage();

            MvTemplateMatch templateMatchingTool = job.GetLastRunTool() as MvTemplateMatch;

            if (templateMatchingTool != null)
            {
                if (btn == btn_LoadCalRcp)
                {
                    svd_CalPattern.Image = templateMatchingTool.TemplateImage;
                    if (svd_CalPattern.Image != null)
                        Subject.calibration.CalData.CalPatternRect = new OpenCvSharp.CPlusPlus.Rect(0, 0, svd_CalPattern.Image.Width, svd_CalPattern.Image.Height);
                }
                else if (btn == btn_LoadRotRcp)
                {
                    svd_RotPattern.Image = templateMatchingTool.TemplateImage;
                    if (svd_RotPattern.Image != null)
                        Subject.calibration.CalData.RotPatternRect = new OpenCvSharp.CPlusPlus.Rect(0, 0, svd_RotPattern.Image.Width, svd_RotPattern.Image.Height); 
                }
            }

            tabControl_SelectedIndexChanged(this, null);
        }

        protected override void tsb_Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Calibration files (*.cal)|*.cal|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.DefaultExt = "*.cal";
            fd.InitialDirectory = PATH_CALIB;

            if (calibrationJob != null && calibrationJob["Acquisition"] != null)
                fd.FileName = lbl_CurrentJob.Text;// string.Format("Cam{0}", (calibrationJob["Acquisition"] as SvAcquisition).CameraNumber + 1);
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            bool success = serializer.SaveCalibration(Subject.calibration.CalData, fd.FileName);

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);

            if (!success)
                MessageBox.Show("Calibration save fail");
            else
            {
                MessageBox.Show("Calibration save success");
                if (OnSaved != null) OnSaved(this, null);
            }
        }

        protected override void tsb_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Calibration files (*.cal)|*.cal|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.Multiselect = false;
            fd.InitialDirectory = PATH_CALIB;  
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;
            MvCalibrationData caldata = serializer.LoadCalibration(fd.FileName);

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);

            if (caldata == null)
            {
                MessageBox.Show("Calibration file load fail");
                return;
            }

            Subject.calibration.CalData = caldata;
            nud_Degree.Value = caldata.CalDegree;
            nud_UsingArea.Value = (decimal)caldata.UsingArea;

            rotationImageInfo.Image = Subject.calibration.CalData.RotImage;
            calibrationImageInfo.Image = Subject.calibration.CalData.CalImage;

            if (tabControl.SelectedTab == tp_Rot || tabControl.SelectedTab == tp_RotResult)
            {
                SvDisplayViewEdit.imageListComboBox.SelectedItem = rotationImageInfo;
                SvDisplayViewEdit.RefreshImage();
                //DrawRotationResult(SvDisplayViewEdit.Display);
            }
            else
            {
                SvDisplayViewEdit.imageListComboBox.SelectedItem = calibrationImageInfo;
                SvDisplayViewEdit.RefreshImage();
                //DrawCalibrationResult(SvDisplayViewEdit.Display);
            }
        }

        protected override void tsb_Run_Click(object sender, EventArgs e)
        {
            MvJob job;
            SvImageInfo info;

            if (tabControl.SelectedTab == tp_Cal || tabControl.SelectedTab == tp_CalResult)
            {
                job = calibrationJob;
                info = calibrationImageInfo;
            }
            else if (tabControl.SelectedTab == tp_Rot || tabControl.SelectedTab == tp_RotResult)
            {
                job = rotationJob;
                info = rotationImageInfo;
            }
            else 
                return;
            
            if (job == null)
            {
                MessageBox.Show("Job is null", "information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            job.Run(true);

            MvTemplateMatch templateMatchingTool = job.GetLastRunTool() as MvTemplateMatch;

            if (templateMatchingTool != null)
            {
                info.Image = templateMatchingTool.InputImage;
                SvImageInfo.DrwaingFunc originFunc = info.drawingFunc;
                info.drawingFunc = templateMatchingTool.imageList[1].drawingFunc;
                SvDisplayViewEdit.RefreshImage();
                info.drawingFunc = originFunc;
            }
        }

        Func<bool> calibrationStartFunc;
        Func<bool> rotationStartFunc;
        Func<bool> manualStartFunc;

        bool isStart = false;
        IAsyncResult result;
     
        private void btn_Start_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            if (Subject.calibration == null)
            {
                MessageBox.Show("Calibration data is null\r\nIt will be created automatically after this message\r\nPlease check and set parameter agian.");
                Subject.calibration = new MvCalibration();
                return;
            }

            if (result != null && !result.IsCompleted)
            {
                if (isStart)
                {
                    isStart = false;
                    pbar_Cal.Value = 0;//08.27 hong 
                    MessageBox.Show("Being stoping this action. please wait until Done.");
                }
                return;
            }

            if (btn == btn_Cal_Start) //calibration Start
            {
                if (MessageBox.Show("Calibration Start?.", "Calibration", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
                    != System.Windows.Forms.DialogResult.OK) return;
                
                pbar_Cal.Value = 0;
                
                result = calibrationStartFunc.BeginInvoke(new AsyncCallback(CalibrationCompleteCallBack), calibrationStartFunc);
            }
            else if (btn == btn_Rot_Start) //rotation Start
            {
                if (Subject.calibration.CalData.VtoRMat == null)
                {
                    MessageBox.Show("Can't Find Rotation Center.\r\nDo Calibration Before Finding Rotation Center!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("Rotation Start?.", "Rotation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
                    != System.Windows.Forms.DialogResult.OK) return;

                pbar_Rot.Value = 0;

                result = rotationStartFunc.BeginInvoke(new AsyncCallback(CalibrationCompleteCallBack), rotationStartFunc);
            }
            else if(btn == btn_ManualStart)
            {
                if (MessageBox.Show("Manual Move Start?.", "Manual Move", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
                    != System.Windows.Forms.DialogResult.OK) return;

                result = manualStartFunc.BeginInvoke(new AsyncCallback(CalibrationCompleteCallBack), manualStartFunc);                
            }

        }

        void CalibrationCompleteCallBack(IAsyncResult result)
        {
            Func<bool> startFunc = result.AsyncState as Func<bool>;
            bool success = startFunc.EndInvoke(result);

            if (success)
                this.Invoke(new Action(SvDisplayViewEdit.RefreshImage));

            this.Invoke(new Action(delegate { btn_ManualStart.Text = "Start"; btn_Cal_Start.Text = "Start"; btn_Rot_Start.Text = "Start"; }));
            isStart = false;
        }

        private void btn_OriginToCenter_Click(object sender, EventArgs e)
        {
            if (SvDisplayViewEdit.Display.Image == null) return;
            originPoint.X = SvDisplayViewEdit.Display.Image.Width / 2;
            originPoint.Y = SvDisplayViewEdit.Display.Image.Height / 2;
        }

        private void btn_MakeCalMatrix_Click(object sender, EventArgs e)
        {
            if (gv_Cal_Result.Rows.Count - 1 < 3) return;
            //Calibration Matrix(m_VtoRMatrix)를 생성한다.
            Point2d[] RobotPts = new Point2d[gv_Cal_Result.Rows.Count - 1];
            Point2d[] VisionPts = new Point2d[gv_Cal_Result.Rows.Count - 1];
          
            double RX, RY, VX, VY;
            for (int i = 0; i < gv_Cal_Result.Rows.Count - 1; i++)
            {
                try
                {
                    RX = double.Parse(gv_Cal_Result.Rows[i].Cells["RobotX"].Value.ToString());
                    RY = double.Parse(gv_Cal_Result.Rows[i].Cells["RobotY"].Value.ToString());
                    VX = double.Parse(gv_Cal_Result.Rows[i].Cells["VisionX_Pixel"].Value.ToString());
                    VY = double.Parse(gv_Cal_Result.Rows[i].Cells["VisionY_Pixel"].Value.ToString());
                }
                catch
                {
                    continue;
                }
                RobotPts[i] = new Point2d(RX, RY);
                VisionPts[i] = new Point2d(VX, VY);
            }
            Subject.calibration.CalData.RefPoint = VisionPts;
            Subject.calibration.CalData.ShiftPoint = new Point2d[VisionPts.Length];
            for (int i=0;i<VisionPts.Length;i++)
            {
                Subject.calibration.CalData.ShiftPoint[i] = VisionPts[i] - Subject.calibration.CalData.Distance;
            }
          
            Subject.calibration.CalData.RobotPoint = RobotPts;
            Point2d[] visionPt = Subject.calibration.CalData.ShiftPoint.Skip(0).Take(Subject.calibration.CalData.GPNo).ToArray();
            Point2d[] robotPt = Subject.calibration.CalData.RobotPoint.Skip(0).Take(Subject.calibration.CalData.GPNo).ToArray();
            Subject.calibration.CalData.VtoRMat.Mat = Calibration.CalcCalibrationMat(visionPt, robotPt);

            //if (DialogResult.Yes == MessageBox.Show("Do You Want to Move Origin to Ceter of Display?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            //    ChangeOrigin(new Point2d(SvDisplayViewEdit.Display.Image.Width / 2, SvDisplayViewEdit.Display.Image.Height / 2));
            //else
            //    ChangeOrigin(originPoint.Point2d);
            //calData.CalImage.TransformMat = SvFunc.EMat;

            //double[,] dd = SvFunc.DisplayMat(CalData.VtoRMat.Mat);
            
            //SvDisplayViewEdit.Display.Image = calData.CalImage;
            DrawCalibrationResult(SvDisplayViewEdit.Display);
            //SvDisplayViewEdit.RefreshImage();
        }

        private void btn_CalRotationCenter_Click(object sender, EventArgs e)
        {
            // Test Code
            //List<Point2d> listPts1 = new List<Point2d>();
            //listPts1.Add(new Point2d(-120, -120));
            //listPts1.Add(new Point2d(-130.5, -110));
            //listPts1.Add(new Point2d(-140, -100));

            //List<Point2d> listPts2 = new List<Point2d>();
            //listPts2.Add(new Point2d(82, -0));
            //listPts2.Add(new Point2d(83.5, -10));
            //listPts2.Add(new Point2d(84, -40));
            //Point2d CP1, CP2;
            //calibration.FindRotationCenter(listPts1, listPts2, 1000, out CP1, out CP2);
            //return;
            // Test Code End
            //////////////////////// Calculate Center Pos. ////////////////////////
            Subject.calibration.CalData.RotPoints = new List<Point3d>();
            Subject.calibration.CalData.RotAngles = new List<double>();
            int matrixLen = Subject.calibration.CalData.GPNo;
            for (int i = 0; i < gv_Rot_Pts.RowCount - 1; i++)
            {
                Subject.calibration.CalData.RotAngles.Add(double.Parse(gv_Rot_Pts.Rows[i].Cells["RotateAngle"].Value.ToString()));
                double X = double.Parse(gv_Rot_Pts.Rows[i].Cells["RotateX"].Value.ToString());
                double Y = double.Parse(gv_Rot_Pts.Rows[i].Cells["RotateY"].Value.ToString());
                double T = double.Parse(gv_Rot_Pts.Rows[i].Cells["RotateT"].Value.ToString());
                double RX = double.Parse(gv_Rot_Pts.Rows[i].Cells["R_X"].Value.ToString());
                double RY = double.Parse(gv_Rot_Pts.Rows[i].Cells["R_Y"].Value.ToString());
                Subject.calibration.CalData.RotPoints.Add(new Point3d(X, Y, T * Math.PI / 180));
                Subject.calibration.CalData.RefPoint[matrixLen+i] = new Point2d(X, Y);
                Subject.calibration.CalData.RobotPoint[matrixLen + i] = new Point2d(RX, RY);
            }

            Point2d cp = Subject.calibration.FindRotationCenter(Subject.calibration.CalData.RotPoints);
            if (cp == new Point2d())
                Subject.calibration.CalData.RobotTT_TCP = new Point2d();
            else
                Subject.calibration.CalData.RobotTT_TCP = Calibration.VtoR(Calibration.FindRotationCenter(Subject.calibration.CalData.RotPoints)) - new Point2d(Subject.calibration.CalData.RotShiftH, Subject.calibration.CalData.RotShiftV); //회전중심 계산 후 저장

            DrawRotationResult(SvDisplayViewEdit.Display);
        }

        private void Cal_Simulator_Click(object sender, EventArgs e)
        {
            MvCalibrationEdit_SimulationForm simulForm = new MvCalibrationEdit_SimulationForm();

            if (Subject.calibration.CalData.RobotTT_TCP.X == 0 && Subject.calibration.CalData.RobotTT_TCP.Y == 0)
            {
                MessageBox.Show("There is no Calibration Data ", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else
            {
                simulForm.centerPT = Subject.calibration.CalData.RobotTT_TCP;
                simulForm.calPath = PATH_CALIB + "\\" +lbl_CurrentJob.Text + ".cal";
                
                int tmpwidth = 0, tmpheight = 0;
                tmpwidth = Subject.calibration.CalData.CalImage.Width;
                tmpheight = Subject.calibration.CalData.CalImage.Height;

                //추후에 받아온 이미지로 넘길경우 적용 가능
                MvImage calImg = new MvImage(new Mat(tmpheight, tmpwidth, MatType.CV_8U, new Scalar(255)));
                simulForm.Simul_Image = calImg;
            }

            simulForm.ShowDialog();

        }

        private void nud_Degree_ValueChanged(object sender, EventArgs e)
        {
            if (!IsPossibleNonlinear) return;
            if (Subject.calibration.CalData.LinearRobotPoints.Count == 0) return;
            if (Subject.calibration.CalData.LinearRobotPoints.Count - 1 < (int)nud_Degree.Value)
                nud_Degree.Value = Subject.calibration.CalData.LinearRobotPoints.Count - 1;
            if (Subject.calibration.CalData.LinearRobotPoints[0].Count - 1 < (int)nud_Degree.Value)
                nud_Degree.Value = Subject.calibration.CalData.LinearRobotPoints[0].Count - 1;

            Subject.calibration.CalData.CalDegree = (int)nud_Degree.Value;
            Subject.calibration.CalData.UsingArea = (double)nud_UsingArea.Value;

            DrawCalibrationResult(svDisplayViewEdit.Display);
        }

        private void pbar_Cal_Click(object sender, EventArgs e)
        {
          
        }

        private void btn_RtoV_Click(object sender, EventArgs e)
        {
            if (Subject.calibration.CalData.VtoRMat.Mat != null)
            {
                double Rx, Ry,Rr;
                double.TryParse(txt_R_X_Point.Text, out Rx);
                double.TryParse(txt_R_Y_Point.Text, out Ry);
                double.TryParse(txt_R_R_Point.Text, out Rr);
                Point2d robotPoint;
                if (Rr != 0)
                {
                   robotPoint = Subject.calibration.find_RotatePoint(new Point3d(Rx,Ry,Rr), calibration.CalData.RobotTT_TCP);

                }else
                {
                    robotPoint = new Point2d(Rx, Ry);
                }
                Point2d visionPoint = Subject.calibration.RtoV(robotPoint);
                txt_V_X_Point.Text = visionPoint.X.ToString();
                txt_V_Y_Point.Text = visionPoint.Y.ToString();
            }
        }

        private void btn_VtoR_Click(object sender, EventArgs e)
        {
            if (Subject.calibration.CalData.VtoRMat.Mat != null)
            {
                double Vx, Vy,Vr;
                double.TryParse(txt_V_X_Point.Text, out Vx);
                double.TryParse(txt_V_Y_Point.Text, out Vy);
                double.TryParse(txt_V_R_Point.Text, out Vr);
                Point2d visionPoint;
                if (Vr != 0)
                {
                    visionPoint = Subject.calibration.find_RotatePoint(new Point3d(Vx,Vy,Vr), calibration.CalData.VisionTT_TCP);
                }
                else
                {
                    visionPoint = new Point2d(Vx, Vy);
                }  
                Point2d robotPoint = Subject.calibration.VtoR(visionPoint);
                txt_R_X_Point.Text = robotPoint.X.ToString();
                txt_R_Y_Point.Text = robotPoint.Y.ToString();
            }
        }
    }
}
