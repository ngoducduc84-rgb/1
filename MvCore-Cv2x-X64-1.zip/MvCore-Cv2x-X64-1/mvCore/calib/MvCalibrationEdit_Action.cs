﻿using MvCore.Common;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
//using MvCore.Interface;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
//using ZXing;

namespace MvCore.Edit
{
    public partial class MvCalibrationEdit
    {
        private Server R_server;

        public Server R_Server
        {
            get { return R_server; }
            set { R_server = value; }
        }

        bool IsPossibleNonlinear { get { return calibration.CalcNonlinearCalibration(); } }
        MvCalibrationData CalData
        {
            get
            {
                if (calibration == null)
                    calibration = new MvCalibration();
                return calibration.CalData;
            }
            set
            {
                if (calibration == null)
                    calibration = new MvCalibration();

                // Nonlinear 추가
                if (value.CalDegree < (int)nud_Degree.Minimum)
                    value.CalDegree = (int)nud_Degree.Minimum;
                if (value.CalDegree > (int)nud_Degree.Maximum)
                    value.CalDegree = (int)nud_Degree.Maximum;

                if (value.UsingArea < (double)nud_UsingArea.Minimum)
                    value.UsingArea = (double)nud_UsingArea.Minimum;
                if (value.UsingArea > (double)nud_UsingArea.Maximum)
                    value.UsingArea = (double)nud_UsingArea.Maximum;

                calibration.CalData = value;

                base.NotifySubjectChanged(this, null);
            }

        }

        bool JobValidation(MvJob currentJob)
        {
            if (currentJob == null)
            {
                MessageBox.Show("There is no Job");
                return false;
            }

            MvAcquisition acquisitionTool = currentJob.ToolList[0] as MvAcquisition;

            if (acquisitionTool == null)
            {
                MessageBox.Show("First Tool must be 'Acquisition'!!");
                return false;
            }

            MvTemplateMatch templateMatchTool = currentJob.GetLastRunTool() as MvTemplateMatch;

            if (templateMatchTool == null)
            {
                MessageBox.Show("Last Tool must be 'PatternMatch' or 'TemplateMatching'");
                return false;
            }

            if (templateMatchTool.TemplateImage == null)
            {
                MessageBox.Show("There is not selected pattern.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        //bool InitRobot()
        //{
        //    if (robot == null)
        //    {
        //        MessageBox.Show("Selected robot is null", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        return false;
        //    }

        //    if (!robot.StartCalibration(CalData.GPNo))
        //    {
        //        MessageBox.Show("Calibration can't start.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        robot.EndCalibration();
        //        return false;
        //    }

        //    if (MessageBox.Show("Attach the Jig, and Click 'OK'", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Information)
        //        != System.Windows.Forms.DialogResult.OK)
        //    {
        //        robot.EndCalibration();
        //        return false;
        //    }

        //    return true;
        //}

        public Point3d? Run(MvJob job)
        {
            job.Run(true);

            MvTemplateMatch templateMatchingTool = job.GetLastRunTool() as MvTemplateMatch;

            double score = templateMatchingTool.Score;
            Point3d result = templateMatchingTool.ResultCP;

            if (score < 0.6)
            {
                MessageBox.Show("Find position is failed\r\nScore: " + score, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }

            SvImageInfo info;

            if (job == calibrationJob)
                info = calibrationImageInfo;
            else if (job == rotationJob)
                info = rotationImageInfo;
            else throw new Exception("Job이 뭐가 들어온건데?");

            info.Image = templateMatchingTool.InputImage;
            SvImageInfo.DrwaingFunc originFunc = info.drawingFunc;
            info.drawingFunc = templateMatchingTool.imageList[1].drawingFunc;
            this.Invoke(new Action(SvDisplayViewEdit.RefreshImage));
            info.drawingFunc = originFunc;

            if (job == calibrationJob)
                Subject.calibration.CalData.CalImage = info.Image;
            else if (job == rotationJob)
                Subject.calibration.CalData.RotImage = info.Image;

            return result;
        }

        MvPoint originPoint = new MvPoint();

        bool CalibrationStart()
        {
            isStart = true;
            this.Invoke(new Action(delegate { btn_Cal_Start.Text = "Stop"; }));

            if (!JobValidation(calibrationJob)) return false;
            //if (!InitRobot()) return false;

            int H = Subject.calibration.CalData.PointH;
            int V = Subject.calibration.CalData.PointV;
            double pitchH = Subject.calibration.CalData.PitchH;
            double pitchV = Subject.calibration.CalData.PitchV;

            bool bMoveOrigin2Cener = false;

            if (DialogResult.Yes == MessageBox.Show("Do You Want to Move Origin to Center of Display?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                //btn_OriginToCenter_Click(null, null);
                bMoveOrigin2Cener = true;
            }

            if (H % 2 == 0 || V % 2 == 0)
            {
                MessageBox.Show("Points Count must be odd.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (H < 3 || V < 3)
            {
                MessageBox.Show("Points Count too Small.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            Subject.calibration.CalData.RefPoint = new Point2d[H * V];
            Subject.calibration.CalData.RobotPoint = new Point2d[H * V];

            this.Invoke(new Action(delegate { pbar_Cal.Maximum = H * V; }));


            try
            {
                for (int i = 0; i < V; i++)
                {
                    for (int j = 0; j < H; j++)
                    {
                        if (isStart == false) throw new Exception();

                        Subject.calibration.CalData.RobotPoint[i * H + j] = new Point2d((j - (H - 1) / 2) * pitchH, (i - (V - 1) / 2) * pitchV);
                        Point2d MovePoint = Subject.calibration.CalData.RobotPoint[i * H + j] + new Point2d(Subject.calibration.CalData.CalShiftH,Subject.calibration.CalData.CalShiftV);

                        //if (!robot.WriteCalOffset((float)MovePoint.X, (float)MovePoint.Y, 0.0f))//robot send O
                        //{
                        //    MessageBox.Show("Calibration Offset send failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //    throw new Exception();
                        //}

                        //if (robot.MoveCalibration() == false)
                        //{
                        //    MessageBox.Show(string.Format("Can't find mark {0} : Move signal send failed.).", i * H + j), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //    throw new Exception();
                        //}

                        Point3d? result = Run(calibrationJob);

                        if (result == null)
                            throw new Exception();

                        Subject.calibration.CalData.RefPoint[i * H + j] = new Point2d(result.Value.X, result.Value.Y);
                        this.Invoke(new Action(pbar_Cal.PerformStep));

                        //Thread.Sleep(500);
                    }
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                //robot.EndCalibration();
            }

            // 가운데 점(RefPoint[(H * V - 1) / 2])을 (ImgWidth/2, ImgHeight/2)으로 Normalize한 값으로 전체 normalize
            //if (originPoint.X == 0 && originPoint.Y == 0)
            //this.Invoke(new Action(()=>btn_OriginToCenter_Click(this, null)));

            //Point2d normP = CalData.RefPoint[(H * V - 1) / 2] - new Point2d(originPoint.X, originPoint.Y);

            //for (int i = 0; i < V; i++)
            //{
            //    for (int j = 0; j < H; j++)
            //    {
            //        CalData.RefPoint[i * H + j] -= normP;
            //    }
            //}

            //Calibration Matrix(m_VtoRMatrix)를 생성한다.
            Subject.calibration.CalData.VtoRMat.Mat = Subject.calibration.CalcCalibrationMat(Subject.calibration.CalData.RefPoint, Subject.calibration.CalData.RobotPoint);

            if (bMoveOrigin2Cener)
                ChangeOrigin(new Point2d(SvDisplayViewEdit.Display.Image.Width / 2, SvDisplayViewEdit.Display.Image.Height / 2));
            else
                ChangeOrigin(originPoint.Point2d);

            ChangeOrigin(new Point2d(SvDisplayViewEdit.Display.Image.Width / 2, SvDisplayViewEdit.Display.Image.Height / 2));

            return true;
        }

        public bool CalibrationStart(string Data)
        {

            isStart = true;
            this.Invoke(new Action(delegate { btn_Cal_Start.Text = "Stop"; }));

            if (!JobValidation(calibrationJob)) return false;


            int H = Subject.calibration.CalData.PointH;
            int V = Subject.calibration.CalData.PointV;
            double pitchH = Subject.calibration.CalData.PitchH;
            double pitchV = Subject.calibration.CalData.PitchV;
            bool bMoveOrigin2Cener = false;
            if (DialogResult.Yes == MessageBox.Show("Do You Want to Move Origin to Center of Display?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                //btn_OriginToCenter_Click(null, null);
                bMoveOrigin2Cener = true;
            }
            if (H < 3 || V < 3)
            {
                MessageBox.Show("Points Count too Small.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            Subject.calibration.CalData.RefPoint = new Point2d[H * V];
            Subject.calibration.CalData.RobotPoint = new Point2d[H * V];

            this.Invoke(new Action(delegate { pbar_Cal.Maximum = H * V; }));
            try
            {
                for (int i = 0; i < V; i++)
                {
                    for (int j = 0; j < H; j++)
                    {

                    }
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                //robot.EndCalibration();
            }
            Subject.calibration.CalData.VtoRMat.Mat = Calibration.CalcCalibrationMat(Subject.calibration.CalData.RefPoint,Subject.calibration.CalData.RobotPoint);

            if (bMoveOrigin2Cener)
                ChangeOrigin(new Point2d(SvDisplayViewEdit.Display.Image.Width / 2, SvDisplayViewEdit.Display.Image.Height / 2));
            else
                ChangeOrigin(originPoint.Point2d);

            ChangeOrigin(new Point2d(SvDisplayViewEdit.Display.Image.Width / 2, SvDisplayViewEdit.Display.Image.Height / 2));

            return true;
        }

        void ChangeOrigin(Point2d _originPoint)
        {
            Mat calMat = Subject.calibration.CalData.VtoRMat.Mat;

            Point2d robotCP = calibration.VtoR_Linear(_originPoint);

            for (int i = 0; i < Subject.calibration.CalData.RobotPoint.Length; i++)
            {
                Subject.calibration.CalData.RobotPoint[i] -= robotCP;
            }

            Subject.calibration.CalData.VtoRMat.Mat = Calibration.CalcCalibrationMat(Subject.calibration.CalData.RefPoint, Subject.calibration.CalData.RobotPoint);
            originPoint.Point2d = _originPoint;
            //double[,] dd = SvFunc.DisplayMat(calMat);
            //double[,] ddd = SvFunc.DisplayMat(newCalMat);
            //Point2d P = calibration.VtoR_Linear(originPoint.Point2d);
        }

        bool RotationStart()
        {
            isStart = true;
            this.Invoke(new Action(delegate { btn_Rot_Start.Text = "Stop"; }));

            if (!JobValidation(rotationJob)) return false;
            //if (!InitRobot()) return false;

            List<Point3d> resultPts = new List<Point3d>();
            List<double> listAngle = new List<double>();
            Point3d[] resultP = new Point3d[2];

            float angle;
            float angleFrom = Subject.calibration.CalData.AngleFrom;
            float angleTo = Subject.calibration.CalData.AngleTo;

            double shiftH = Subject.calibration.CalData.RotShiftH;
            double shiftV = Subject.calibration.CalData.RotShiftV;
            int rotCount = Subject.calibration.CalData.RotCount;

            this.Invoke(new Action(delegate { pbar_Rot.Maximum = rotCount; }));

            try
            {
                for (int i = 0; i < rotCount; i++)
                {
                    if (isStart == false) throw new Exception();

                    angle = angleFrom + (i) * (angleTo - angleFrom) / (rotCount - 1);
                    listAngle.Add(angle);

                    //if (!robot.WriteCalOffset((float)shiftH, (float)shiftV, angle))
                    //{
                    //    MessageBox.Show("Rotation Offset send failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //    throw new Exception();
                    //}

                    //if (!robot.MoveCalibration())
                    //{
                    //    MessageBox.Show("Rotation signal send failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //    throw new Exception();
                    //}

                    // 2016.03.06.ASH =====> IMI Camera의 경우 buffer내 이전 영상 남아있을 경우가 있어서... 임시로 추가함.
                    //npb_VIsion.MatImage = cam.GrabImage().Clone();
                    // 2016.03.06.ASH 

                    Point3d? result = Run(rotationJob);
                    if (result == null)
                        throw new Exception();

                    resultPts.Add(result.Value);
                    this.Invoke(new Action(pbar_Rot.PerformStep));

                    //Thread.Sleep(500);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                MvLogger.Log.Error(ex.Message);
                return false;
            }
            finally
            {
                //robot.EndCalibration(); //Escape Robot Loop
            }

            //////////////////////// Check Reasonability ////////////////////////
            List<double> Length = new List<double>();
            for (int i = 0; i < rotCount - 1; i++)
            {
                double L = Point2d.Distance(new Point2d(resultPts[i].X, resultPts[i].Y), new Point2d(resultPts[i + 1].X, resultPts[i + 1].Y));
                Length.Add(L);
            }

            ////////////////////////// Calculate Center Pos. ////////////////////////
            //if (calData.RotPoints == null)
            //    calData.RotPoints = new List<Point3d>();
            //else
            //    calData.RotPoints.Clear();

            //foreach (Point3d pt in resultPts)
            //{
            //    calData.RotPoints.Add(pt);
            //}

            Subject.calibration.CalData.RotPoints = resultPts; //các vị trí mark vision bắt được
            Subject.calibration.CalData.RotAngles = listAngle;

            if (rotCount == 2)
            {
                double dthetaDeg = (Subject.calibration.VtoR(resultPts[1]).Z - Subject.calibration.VtoR(resultPts[0]).Z) * 180 / Math.PI;
                float fT = angleTo - angleFrom;
                if (Math.Abs(fT - dthetaDeg) > 1)
                {
                    string str = "Difference of Angle is too big\r\n + P0: " + Subject.calibration.VtoR(resultPts[0]).Z + ", P1: " + Subject.calibration.VtoR(resultPts[1]).Z;
                    MessageBox.Show(str, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else if (rotCount > 2)
            {
                double diff = Length.Max() - Length.Min();
                if (diff > 10)
                {
                    MessageBox.Show("Difference of Angle is too big", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else
                return false;

            Subject.calibration.CalData.RobotTT_TCP = Subject.calibration.VtoR(Subject.calibration.FindRotationCenter(resultPts)) - new Point2d(shiftH, shiftV); //회전중심 계산 후 저장

            //////////////////////// Save RobotGP Pos. ////////////////////////
            float x = 0; float y = 0; float w = 0;

            //robot.ReadPosition(CalData.GPNo, out x, out y, out w);

            Subject.calibration.CalData.RobotGP = new Point2d(x, y);
            Subject.calibration.CalData.RobotGPT = w;
            return true;
        }

        /// <summary>
        /// 화면에 Calibration 결과를 그린다.
        /// </summary>
        void DrawCalibrationResult(MvCore.Display.MvDisplayView display)
        {
            if(Subject == null) { return; }
            // Test에서는 cVisionData 값을 가지고 한다.
            int H = Subject.calibration.CalData.RobotPoints_Y.Count;
            int V = Subject.calibration.CalData.RobotPoints_X.Count;
            double pitchH = Subject.calibration.CalData.PitchH;
            double pitchV = Subject.calibration.CalData.PitchV;

            if (Subject.calibration.CalData.VtoRMat == null || Subject.calibration.CalData.RefPoint == null)
            {
                //MessageBox.Show("There is not Calibraion Data.");
                return;
            }

            display.ClearImage();
            (display as Display.MvDisplayViewInteract).InteractiveGraphicsCollection.Add(originPoint);
            this.SvDisplayViewEdit.CalibrationMat = Subject.calibration.CalData.VtoRMat.Mat;
            //폼에 결과를 쓴다

            if (Subject.calibration.CalData.RobotPoint == null)
            {
                Subject.calibration.CalData.RobotPoint = new Point2d[Subject.calibration.CalData.PointV * Subject.calibration.CalData.PointH];
                for (int i = 0; i < V; i++)
                {
                    for (int j = 0; j < H; j++)
                    {
                        Subject.calibration.CalData.RobotPoint[i * H + j] = new Point2d((j - (H - 1) / 2) * pitchH, (i - (V - 1) / 2) * pitchV);
                    }
                }
            }

            if (gv_Cal_Result.IsDisposed || gv_Cal_Result.Disposing)
            {
                return;
            }
            gv_Cal_Result.Rows.Clear();
            if(Subject.calibration.CalData.RefPoint.Length < Subject.calibration.CalData.GPNo) { return; }
            for (int i = 0; i < Subject.calibration.CalData.GPNo; i++)
            {
                Point2d v = Subject.calibration.CalData.RefPoint[i];
                Point2d r = Subject.calibration.CalData.RobotPoint[i];
                Point2d v_s = Subject.calibration.CalData.ShiftPoint[i];
                {
                    gv_Cal_Result.Rows.Add(i.ToString(),
                        r.X.ToString("f3"), r.Y.ToString("f3"),
                        Subject.calibration.VtoR(v_s).X.ToString("f3"), Subject.calibration.VtoR(v_s).Y.ToString("f3"),
                        (Subject.calibration.VtoR(v_s) - r).X.ToString("f3"), (Subject.calibration.VtoR(v_s) - r).Y.ToString("f3"),
                        v.X.ToString("f3"),v.Y.ToString("f3"),
                        v_s.X.ToString("f3"), v_s.Y.ToString("f3"));
                }
            }


            gv_Diff.Rows.Clear();
            List<double> diffX = new List<double>();
            List<double> diffY = new List<double>();

            for (int i = 0; i < gv_Cal_Result.RowCount - 1; i++)
            {
                diffX.Add(double.Parse(gv_Cal_Result.Rows[i].Cells[5].Value.ToString()));
                diffY.Add(double.Parse(gv_Cal_Result.Rows[i].Cells[6].Value.ToString()));
            }
            gv_Diff.Rows.Add("Diff_X", diffX.Min().ToString("f3"), diffX.Max().ToString("f3"), (3 * GetStdev(diffX)).ToString("f3"));
            gv_Diff.Rows.Add("Diff_Y", diffY.Min().ToString("f3"), diffY.Max().ToString("f3"), (3 * GetStdev(diffY)).ToString("f3"));

            // 화면에 Display
            // 마크 표시하고 박스도 그리면 좋지...
            DisplayCordinate(display);

            // Lattice 그리기
            DrawLattice(display);

            Point2d refP;
            Font font = new Font("굴림체", 8, System.Drawing.FontStyle.Bold);

            if (calibrationImageInfo.Image == null)
            {
                if (Subject.calibration.CalData.CalImage != null)
                {
                    calibrationImageInfo.Image = Subject.calibration.CalData.CalImage;
                    SvDisplayViewEdit.RefreshImage();
                }
                else
                {
                    display.DrawString(string.Format("There is No Calibration Image"), font, Brushes.Red, new Point2d(0, 0));
                    return;
                }
            }

            double size = 5 / display.ZoomRatio;

            // mapMatrix^(-1) * (PitchH, PitchV)는 과연 어떻게 표시될 것인지 보여준다.            
            //for (int i = 0; i < V; i++)
            //{
            //    for (int j = 0; j < H; j++)
            //    {
            //        refP = new Point2d((j - (H - 1) / 2) * pitchH, (i - (V - 1) / 2) * pitchV);
            //        display.DrawString(string.Format("({0:0.000},{1:0.000})", refP.X, refP.Y),
            //                                font, Brushes.Cyan, new Point2d(Calibration.RToV(refP).X + 10.0, Calibration.RToV(refP).Y + 80.0));
            //        display.DrawCross(Pens.Cyan, Calibration.RToV(refP), 2 * size, 2 * size, 0);
            //    }
            //}

            // Vision에서 측정된 Ref. Point(Red) 그리기  vision and robot matrix Cross
            for (int i = 0; i < Subject.calibration.CalData.GPNo; i++)
            {
                refP = Subject.calibration.CalData.ShiftPoint[i];
                //if (!mDrawNonlinear)
                //{
                //if (!IsPossibleNonlinear) continue;
                display.DrawString(string.Format("(V:{0:0.00} , {1:0.00})",Subject.calibration.VtoR(refP).X, Subject.calibration.VtoR(refP).Y),
                                        font, Brushes.Red, new Point2d(refP.X + 10.0, refP.Y - font.Size / display.ZoomRatio));
                display.DrawCross(Pens.Red, refP, 4 * size, 4 * size, 0);

                refP = Subject.calibration.CalData.RobotPoint[i];
                display.DrawString(string.Format("(R:{0:0.00} , {1:0.00})", refP.X, refP.Y),
                                        font, Brushes.Cyan, new Point2d(Subject.calibration.RtoV(refP).X + 10.0, Subject.calibration.RtoV(refP).Y + 0.5 * font.Size / display.ZoomRatio));
                display.DrawCross(Pens.Cyan, Subject.calibration.RtoV(refP), 2 * size, 2 * size, 0);
            }
        }

        private double GetStdev(List<double> array)
        {
            if (array == null) return 0;
            double squareSum = 0;
            double average = array.Average();
            for (int i = 0; i < array.Count; i++)
            {
                squareSum += Math.Pow(array[i] - average, 2);
            }
            double stdev = Math.Sqrt(squareSum / (array.Count - 1));

            return stdev;
        }
        ///hiển thị tọa độ
        void DisplayCordinate(MvCore.Display.MvDisplayView display)
        {
            int countX = 1; int countY = 1;
            for (int i = 1; i <Subject.calibration.CalData.RobotPoint.Length; i++)
            {
                if (Subject.calibration.CalData.RobotPoint[0].Y != Subject.calibration.CalData.RobotPoint[i].Y)
                {
                    countX = i;
                    countY = Subject.calibration.CalData.RobotPoint.Length / countX;
                    break;
                }
            }

            Font font = new Font("굴림체", 10, System.Drawing.FontStyle.Bold);

            if (Subject.calibration.GetVtoRMat() == null)
            {
                display.DrawString("No Calibration Data", font, Brushes.Red, new PointF(display.Width - 100, display.Height - 20));
                return;
            }

            double pitchH = double.MaxValue; double pitchV = double.MaxValue;
            for (int i = 0; i < Subject.calibration.CalData.RobotPoint.Length - 1; i++)
            {
                double dh = Subject.calibration.CalData.RobotPoint[i + 1].X - Subject.calibration.CalData.RobotPoint[i].X;
                if (dh < 0.1) continue;
                if (pitchH > dh) pitchH = dh;
            }
            for (int i = 0; i < Subject.calibration.CalData.RobotPoint.Length - 1; i++)
            {
                double dh = Subject.calibration.CalData.RobotPoint[i + 1].Y - Subject.calibration.CalData.RobotPoint[i].Y;
                if (dh < 0.1) continue;
                if (pitchV > dh) pitchV = dh;
            }

            if (pitchH == double.MaxValue) pitchH = pitchV;
            if (pitchV == double.MaxValue) pitchV = pitchH;

            {
                PointF HSP = display.PtoP(Subject.calibration.RtoV_Linear(new Point2d(0 * pitchH, 0))); //Horizontal Start Point
                PointF HEP = display.PtoP(Subject.calibration.RtoV_Linear(new Point2d(+2 * pitchH, 0))); //Horizontal End Point
                PointF VSP = display.PtoP(Subject.calibration.RtoV_Linear(new Point2d(0, 0 * pitchV))); //Vertical Start Point
                PointF VEP = display.PtoP(Subject.calibration.RtoV_Linear(new Point2d(0, +2 * pitchV))); //Vertical End Point


                //draw origin Vision
                //display.DrawArrow(Pens.Yellow, HSP, HEP, 20, 20);
                //display.DrawArrow(Pens.Red, VSP, VEP, 20, 20);
                display.DrawArrow(Pens.Yellow, new PointF(0,0), new PointF(300,0), 10, 10);
                display.DrawArrow(Pens.Red, new PointF(0, 0), new PointF(0, 300), 10, 10);
            }

            display.DrawString("X", font, Brushes.Yellow, Subject.calibration.RtoV_Linear(new Point2d(2 * pitchH, 0)));
            display.DrawString("Y", font, Brushes.Red, Subject.calibration.RtoV_Linear(new Point2d(0, 2 * pitchV)));

            //display.DrawString("X ──", font, Brushes.Yellow, new PointF(0, display.Height / 2 - font.Size / display.ZoomRatio));
            //display.DrawString("Y ──", font, Brushes.Red, new PointF(0, display.Height / 2 + font.Size / display.ZoomRatio));
            display.DrawString("X ──", font, Brushes.Yellow, new PointF(150,-30));
            display.DrawString("Y ──", font, Brushes.Red, new PointF(-50, 150));
        }
        //vẽ lưới
        private void DrawLattice(Display.MvDisplayView display, bool isNonlinear = false)
        {
            if (Subject.calibration.CalData.CalImage == null) { Subject.calibration.CalData.CalImage = new MvImage(new Mat(new OpenCvSharp.CPlusPlus.Size(Subject.calibration.CalData.Width, Subject.calibration.CalData.Height), MatType.CV_8UC1)); }
            int countX = 1; int countY = 1;
            for (int i = 1; i < Subject.calibration.CalData.RobotPoint.Length; i++)
            {
                if (Subject.calibration.CalData.RobotPoint[0].Y != Subject.calibration.CalData.RobotPoint[i].Y)
                {
                    countX = i;
                    countY = Subject.calibration.CalData.RobotPoint.Length / countX;
                    break;
                }
            }

            //int pitchH = cal.CalData.PitchH; <- 이렇게 하니 Pitch값을 바꿀때마다 선 간격이 바뀌어서 기존 Point 위치와 안맞음
            //int pitchV = cal.CalData.PitchV;
            int pitchH = (int)Math.Round(Subject.calibration.CalData.RobotPoint[1].X - Subject.calibration.CalData.RobotPoint[0].X);
            int pitchV = (int)Math.Round(Subject.calibration.CalData.RobotPoint[countX].Y - Subject.calibration.CalData.RobotPoint[0].Y);

            /////// 화면에 표시할 수 있는 가장 큰 외곽선(좌표계) 그리기
            Pen pen = new Pen(Brushes.LightGreen, 2 / display.ZoomRatio);
            pen.DashStyle = DashStyle.Dash;

            double size = 1000;
            Point2d originPt = Subject.calibration.RtoV_Linear(new Point2d(0, 0));
            Point2d widthPt =  Subject.calibration.RtoV_Linear(new Point2d(size, 0));
            Point2d heightPt = Subject.calibration.RtoV_Linear(new Point2d(0, size));
            double scale = Math.Min(Math.Abs(Subject.calibration.CalData.CalImage.Width / widthPt.DistanceTo(originPt)), Math.Abs(Subject.calibration.CalData.CalImage.Height / heightPt.DistanceTo(originPt)));
            size *= scale * 0.5;

            display.DrawLine(pen, Subject.calibration.RtoV_Linear(new Point2d(-size, size)),  Subject.calibration.RtoV_Linear(new Point2d(size, size)));
            display.DrawLine(pen, Subject.calibration.RtoV_Linear(new Point2d(-size, -size)), Subject.calibration.RtoV_Linear(new Point2d(size, -size)));

            display.DrawLine(pen, Subject.calibration.RtoV_Linear(new Point2d(size, -size)),  Subject.calibration.RtoV_Linear(new Point2d(size, size)));
            display.DrawLine(pen, Subject.calibration.RtoV_Linear(new Point2d(-size, -size)), Subject.calibration.RtoV_Linear(new Point2d(-size, size)));

            //if (!mDrawNonlinear)
            //{
            Pen px = new Pen(Brushes.Cyan, 1 / display.ZoomRatio);
            px.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            for (int i = -countY / 2; i <= countY / 2; i++)
                display.DrawLine(px, Subject.calibration.RtoV_Linear(new Point2d(-size, i * pitchV)), Subject.calibration.RtoV_Linear(new Point2d(size, i * pitchV)));

            Pen py = new Pen(Brushes.Red, 1 / display.ZoomRatio);
            py.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            for (int i = -countX / 2; i <= countX / 2; i++)
                display.DrawLine(py, Subject.calibration.RtoV_Linear(new Point2d(i * pitchH, -size)), Subject.calibration.RtoV_Linear(new Point2d(i * pitchH, size)));
            //}

            if (IsPossibleNonlinear)
            {
                px = new Pen(Brushes.Cyan, 2 / display.ZoomRatio);
                px.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
                for (int i = -countY / 2; i <= countY / 2; i++)
                {
                    for (double x = -size; x < size; x++)
                    {
                        Point2d robotP = new Point2d(x, i * pitchV);
                        Point2d nonlinearP = Subject.calibration.GetNonlinearValue(robotP);
                        display.DrawCross(px, Subject.calibration.RtoV(nonlinearP), 2, 2, 0);
                    }
                }
                py = new Pen(Brushes.Red, 2 / display.ZoomRatio);
                py.EndCap = System.Drawing.Drawing2D.LineCap.Flat;
                for (int i = -countX / 2; i <= countX / 2; i++)
                {
                    for (double y = -size; y < size; y++)
                    {
                        Point2d robotP = new Point2d(i * pitchH, y);
                        Point2d nonlinearP = Subject.calibration.GetNonlinearValue(robotP);
                        display.DrawCross(py, Subject.calibration.RtoV(nonlinearP), 2, 2, 0);
                    }
                }
            }

        }

        /// <summary>
        /// 화면에 this.calData를 표시한다.
        /// </summary>
        void DrawRotationResult(MvCore.Display.MvDisplayView display)
        {
            if(Subject == null) { return; }
            if (Subject.calibration.CalData.RotPoints == null || Subject.calibration.CalData.RotPoints.Count == 0)
            {
                //MessageBox.Show("Rotaion result data is null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Subject.calibration.GetVtoRMat() == null)
            {
                //MessageBox.Show("Calibration result data is null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Subject.calibration.CalData.RotAngles == null)
            {
                Subject.calibration.CalData.RotAngles = new List<double>();

                for (int i = 0; i < Subject.calibration.CalData.RotCount; i++)
                {
                    double angle = Subject.calibration.CalData.AngleFrom + (i) * (Subject.calibration.CalData.AngleTo - Subject.calibration.CalData.AngleFrom) / (Subject.calibration.CalData.RotCount - 1);
                    Subject.calibration.CalData.RotAngles.Add(angle);
                }
            }

            display.ClearImage();

            List<Point3d> resultPts = Subject.calibration.CalData.RotPoints;

            //Point2d robotCP = new Point2d(Subject.calibration.CalData.RobotTCP.X, Subject.calibration.CalData.RobotTCP.Y);
            //Point2d robotShiftCP = robotCP + new Point2d(Subject.calibration.CalData.RotShiftH, Subject.calibration.CalData.RotShiftV);
            //Point2d visionShiftCP = Subject.calibration.RtoV(robotShiftCP);
            //Point2d visionCP = Subject.calibration.RtoV(robotCP);

            Point3d visionMaster =  Subject.calibration.CalData.VisionMaster;
            Point3d robotMaster = Subject.calibration.CalData.RobotMaster;

            Point2d visionHE_TCP = Subject.calibration.CalData.VisionHE_TCP;
            Point2d robotHE_TCP = Subject.calibration.CalData.RobotHE_TCP;

            Point2d robotTT_TCP = Subject.calibration.CalData.RobotTT_TCP;
            Point2d visionTT_TCP = Subject.calibration.CalData.VisionTT_TCP;

            float radius = (float)Math.Sqrt(Math.Pow(resultPts[0].X - visionHE_TCP.X, 2) + Math.Pow(resultPts[0].Y - visionHE_TCP.Y, 2)); //위에꺼랑 이거랑 같을지 모르겠음.

            //폼에 출력하기
            lbl_Rot_Origin_RLocation.Text = string.Format("({0:F3}, {1:F3})", robotHE_TCP.X, robotHE_TCP.Y);
            lbl_Rot_Origin_VLocation.Text = string.Format("({0:F3}, {1:F3})", visionHE_TCP.X, visionHE_TCP.Y);
            lbl_Rot_Origin_RadiusVision.Text = string.Format("{0:F3} px", radius);
            //lbl_RobotGPos.Text = string.Format("( {0:F3}, {1:F3}, {2:F3})", calData.RobotGP.X, calData.RobotGP.Y, calData.RobotGPT);
            nud_GP_X.Value = (decimal)Subject.calibration.CalData.RobotGP.X; nud_GP_Y.Value = (decimal)Subject.calibration.CalData.RobotGP.Y;

            Point2d P0 = new Point2d(resultPts[0].X, resultPts[0].Y);

            if (Subject.calibration.CalData.VtoRMat != null)
                lbl_Rot_Origin_RadiusRobot.Text = string.Format("{0:F3} mm", OpenCvSharp.CPlusPlus.Point.Distance((OpenCvSharp.CPlusPlus.Point)Subject.calibration.VtoR(P0), (OpenCvSharp.CPlusPlus.Point)Subject.calibration.VtoR(visionTT_TCP)));

            Font font = new Font("굴림체", 8, System.Drawing.FontStyle.Bold);
            display.ClearImage();

            Rect patternRect = Subject.calibration.CalData.RotPatternRect;
            if (patternRect.Width <= 0 || patternRect.Height <= 0)
                patternRect = new Rect(0, 0, 100, 100);

            //if (rotationImageInfo.Image == null)
            //{
            //    if (Subject.calibration.CalData.RotImage != null)
            //    {
            //        rotationImageInfo.Image = Subject.calibration.CalData.RotImage;
            //        SvDisplayViewEdit.RefreshImage();
            //    }
            //    else
            //    {
            //        Subject.calibration.CalData.RotImage = new MvImage(new Mat(new OpenCvSharp.CPlusPlus.Size(Subject.calibration.CalData.Width, Subject.calibration.CalData.Height), MatType.CV_8UC1));
            //        rotationImageInfo.Image = Subject.calibration.CalData.RotImage;
            //        SvDisplayViewEdit.RefreshImage();
            //        display.DrawString(string.Format("There is No RotationCenter Image"), font, new SolidBrush(Color.Red), new Point2d(0, 0));
            //        return;
            //    }
            //}

            if (rotationImageInfo.Image == null)
            {
                if (Subject.calibration.CalData.CalImage != null)
                {
                    rotationImageInfo.Image = Subject.calibration.CalData.CalImage;
                    SvDisplayViewEdit.RefreshImage();
                }
                else
                {
                    display.DrawString(string.Format("There is No Rotation Image"), font, Brushes.Red, new Point2d(0, 0));
                    return;
                }
            }

            // Display ListView
            if (gv_Rot_Pts.IsDisposed || gv_Rot_Pts.Disposing)
            {
                return;
            }
            gv_Rot_Pts.Rows.Clear();
            int matrixLen = Subject.calibration.CalData.GPNo; 
            for (int i = 0; i < Subject.calibration.CalData.RotPoints.Count; i++)
            {
                if (matrixLen + i > Subject.calibration.CalData.RobotPoint.Length)
                    break;
                gv_Rot_Pts.Rows.Add(new string[7]
                { i.ToString(), Subject.calibration.CalData.RotAngles[i].ToString("f2") ,Subject.calibration.CalData.RotPoints[i].X.ToString("f3"), Subject.calibration.CalData.RotPoints[i].Y.ToString("f3"), (Subject.calibration.CalData.RotPoints[i].Z * 180 / Math.PI).ToString("f3"),
                Subject.calibration.CalData.RobotPoint[matrixLen+i].X.ToString("f2"),Subject.calibration.CalData.RobotPoint[matrixLen+i].Y.ToString("f2")});
            }

            //좌표계 그리기           
            DisplayCordinate(display);

            // vẽ điểm các điểm Rotation vệ tinh
            for (int i = 0; i < Subject.calibration.CalData.RotPoints.Count; i++)
            {
                Point2d resultPt = new Point2d(resultPts[i].X, resultPts[i].Y);
                // 패턴 그리기
                display.DrawCross(Pens.Red, resultPt, patternRect.Width, patternRect.Height, resultPts[i].Z);
                display.DrawRectangle(Pens.YellowGreen, resultPt, patternRect.Width, patternRect.Height, resultPts[i].Z);

                // 좌표 그리기
                display.DrawString(string.Format("V" + i + ": ({0:0.00}, {1:0.00} px, {2:0.0} deg)",
                    resultPts[i].X, resultPts[i].Y, resultPts[i].Z * 180 / Math.PI), font, Brushes.GreenYellow, resultPt);
            }
            //Shift 표시
            float size = 3f / display.ZoomRatio;
           

            //vẽ vị trí master Vision
            display.DrawString(string.Format("Master : ({0:0.00}, {1:0.00} mm, {2:0.00} deg)\r\nMaster : ({3:0.00}, {4:0.00} px, {5:0.00} deg)",
                robotMaster.X, robotMaster.Y, robotMaster.Z, visionMaster.X, visionMaster.Y, visionMaster.Z), font, Brushes.Red, new Point2d(visionMaster.X,visionMaster.Y));
            //vẽ dấu + tại vị trí Master
            Pen p = new Pen(Color.Lime, size);
            display.DrawCross(Pens.Red, new Point2d(visionMaster.X, visionMaster.Y), patternRect.Width, patternRect.Height, visionMaster.Z);


            //vẽ vị trí vision TT TCP 
            display.DrawString(string.Format("V_TT_TCP : ({0:0.00}, {1:0.00}) px",visionTT_TCP.X, visionTT_TCP.Y), font, Brushes.Pink, visionTT_TCP);
            //vẽ vòng tròn nhỏ tại vị trí TT_TCP
            p = new Pen(Color.Pink, size);
            p.DashStyle = DashStyle.Solid;
            display.DrawEllipse(p, visionTT_TCP, 1 * size, 1 * size);

            //vẽ vị trí robot TT TCP
            display.DrawString(string.Format("R_TT_TCP : ({0:0.00}, {1:0.00}) mm",robotTT_TCP.X, robotTT_TCP.Y), font, Brushes.Blue, Subject.calibration.RtoV(robotTT_TCP) + new Point2d(-60*size,0));
            //vẽ vòng tròn nhỏ tại vị trí TT_TCP
            p = new Pen(Color.Blue, size);
            p.DashStyle = DashStyle.Solid;
            display.DrawEllipse(p, Subject.calibration.RtoV(robotTT_TCP), 2 * size, 2 * size);


            //vẽ vị trí vision HE TCP 
            display.DrawString(string.Format("V_HE_TCP : ({0:0.00}, {1:0.00}) px",visionHE_TCP.X, visionHE_TCP.Y), font, Brushes.Red, visionHE_TCP);
            //vẽ vòng tròn nhỏ tại vị trí Vision_HE_TCP
            //원점 그리기
            p = new Pen(Color.Red, size);
            p.DashStyle = DashStyle.Solid;
            display.DrawEllipse(p, visionHE_TCP, 1 * size, 1 * size);


            //vẽ vị trí robot HE TCP Vision
            display.DrawString(string.Format("R_HE_TCP : ({0:0.00}, {1:0.00}) mm", robotHE_TCP.X, robotHE_TCP.Y), font, Brushes.Green, Subject.calibration.RtoV(robotHE_TCP) + new Point2d(-60*size,0));
            //vẽ vòng tròn nhỏ tại vị trí Robot_HE_TCP
            p = new Pen(Color.Green, size);
            p.DashStyle = DashStyle.Solid;
            display.DrawEllipse(p,Subject.calibration.RtoV(robotHE_TCP), 2 * size, 2 * size);


            //vẽ Vòng tròn tại tâm là HE_TCP với bán kính là các điểm Rotation vệ tinh
            //회전반경 그리기
            p = new Pen(Color.Fuchsia, 2);
            p.DashPattern = new float[] { 2f, 1f, 1f, 1f };
            display.DrawEllipse(p, visionHE_TCP, radius, radius);
            //vẽ Line nối giữa HE_TCP và TT_TCP
            p.DashStyle = DashStyle.Dot;
            display.DrawLine(p, visionHE_TCP, visionTT_TCP);
           



        }
    }
}
