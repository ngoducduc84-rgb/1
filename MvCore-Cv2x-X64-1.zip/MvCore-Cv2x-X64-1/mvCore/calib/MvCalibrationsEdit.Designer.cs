﻿namespace MvCore.Edit
{
    partial class MvCalibrationsEdit
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tp_Info = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txt_V_R_Point = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txt_R_R_Point = new System.Windows.Forms.TextBox();
            this.btn_VtoR = new System.Windows.Forms.Button();
            this.btn_RtoV = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txt_V_Y_Point = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txt_R_Y_Point = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txt_V_X_Point = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txt_R_X_Point = new System.Windows.Forms.TextBox();
            this.gb_Manual = new System.Windows.Forms.GroupBox();
            this.gb_ManualMove = new System.Windows.Forms.GroupBox();
            this.nud_OffsetT = new System.Windows.Forms.NumericUpDown();
            this.nud_OffsetY = new System.Windows.Forms.NumericUpDown();
            this.nud_OffsetX = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.cb_MoveTeachingPos = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cb_ManualMoveStart = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cb_ManualIndex = new System.Windows.Forms.ComboBox();
            this.gb_ManualToolSelector = new System.Windows.Forms.GroupBox();
            this.rb_Tool1 = new System.Windows.Forms.RadioButton();
            this.rb_Tool2 = new System.Windows.Forms.RadioButton();
            this.btn_ManualStart = new System.Windows.Forms.Button();
            this.gb_Robot = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.cb_SelectTool = new System.Windows.Forms.ComboBox();
            this.nud_SelectedTP = new System.Windows.Forms.NumericUpDown();
            this.Cal_Simulator = new System.Windows.Forms.Button();
            this.lbl_SelectedRobot = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_CamSet = new System.Windows.Forms.Label();
            this.tp_CalResult = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txt_distanceY = new System.Windows.Forms.TextBox();
            this.txt_distanceX = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.nud_UsingArea = new System.Windows.Forms.NumericUpDown();
            this.nud_Degree = new System.Windows.Forms.NumericUpDown();
            this.btn_MakeCalMatrix = new System.Windows.Forms.Button();
            this.gv_Diff = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gv_Cal_Result = new System.Windows.Forms.DataGridView();
            this.No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RobotX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RobotY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VisionX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VisionY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiffX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiffY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VisionX_Pixel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VisionY_Pixel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VisionX_Pixel_Shift = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VisionY_Pixel_Shift = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tp_RotResult = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.txt_RobotHE_TCP_Y = new System.Windows.Forms.TextBox();
            this.txt_RobotHE_TCP_X = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.txt_VisionHE_TCP_Y = new System.Windows.Forms.TextBox();
            this.txt_VisionHE_TCP_X = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.txt_RobotMaster_Z = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txt_VisionMaster_Z = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.txt_RobotMaster_Y = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txt_RobotMaster_X = new System.Windows.Forms.TextBox();
            this.txt_VisionMaster_Y = new System.Windows.Forms.TextBox();
            this.txt_VisionMaster_X = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_VisionTCP_Y = new System.Windows.Forms.TextBox();
            this.txt_VisionTCP_X = new System.Windows.Forms.TextBox();
            this.txt_RobotTCP_Y = new System.Windows.Forms.TextBox();
            this.txt_RobotTCP_X = new System.Windows.Forms.TextBox();
            this.btn_CalRotationCenter = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.nud_GP_Y = new System.Windows.Forms.NumericUpDown();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.lbl_Rot_Origin_RLocation = new System.Windows.Forms.Label();
            this.lbl_Rot_Origin_VLocation = new System.Windows.Forms.Label();
            this.lbl_Rot_Origin_RadiusVision = new System.Windows.Forms.Label();
            this.lbl_Rot_Origin_RadiusRobot = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nud_GP_X = new System.Windows.Forms.NumericUpDown();
            this.gv_Rot_Pts = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RotateAngle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RotateX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RotateY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RotateT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_X = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.R_Y = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbl_RotShiftX = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_AngleFrom = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_AngleTo = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lbl_Rotmm = new System.Windows.Forms.Label();
            this.lbl_PosCount = new System.Windows.Forms.Label();
            this.lbl_RotShift = new System.Windows.Forms.Label();
            this.nud_Rot_AngleFrom = new System.Windows.Forms.NumericUpDown();
            this.nud_Rot_ShiftH = new System.Windows.Forms.NumericUpDown();
            this.nud_Rot_AngleTo = new System.Windows.Forms.NumericUpDown();
            this.nud_Rot_RotCount = new System.Windows.Forms.NumericUpDown();
            this.nud_Rot_ShiftV = new System.Windows.Forms.NumericUpDown();
            this.btn_Rot_Start = new System.Windows.Forms.Button();
            this.pbar_Rot = new System.Windows.Forms.ProgressBar();
            this.btn_LoadRotRcp = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.tp_Rot = new System.Windows.Forms.TabPage();
            this.svd_RotPattern = new MvCore.Display.MvDisplayView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Cross = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lbl_shift = new System.Windows.Forms.Label();
            this.lbl_X = new System.Windows.Forms.Label();
            this.nud_Cal_PointH = new System.Windows.Forms.NumericUpDown();
            this.nud_Cal_PitchH = new System.Windows.Forms.NumericUpDown();
            this.nud_AreaH = new System.Windows.Forms.NumericUpDown();
            this.nud_Cal_ShiftH = new System.Windows.Forms.NumericUpDown();
            this.nud_Cal_PitchV = new System.Windows.Forms.NumericUpDown();
            this.nud_AreaV = new System.Windows.Forms.NumericUpDown();
            this.nud_Cal_ShiftV = new System.Windows.Forms.NumericUpDown();
            this.nud_Cal_PointV = new System.Windows.Forms.NumericUpDown();
            this.btn_Cal_Start = new System.Windows.Forms.Button();
            this.pbar_Cal = new System.Windows.Forms.ProgressBar();
            this.btn_LoadCalRcp = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.tp_Cal = new System.Windows.Forms.TabPage();
            this.svd_CalPattern = new MvCore.Display.MvDisplayView();
            this.tabControl.SuspendLayout();
            this.tp_Info.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.gb_Manual.SuspendLayout();
            this.gb_ManualMove.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OffsetT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OffsetY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OffsetX)).BeginInit();
            this.gb_ManualToolSelector.SuspendLayout();
            this.gb_Robot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SelectedTP)).BeginInit();
            this.tp_CalResult.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_UsingArea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Degree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Diff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Cal_Result)).BeginInit();
            this.tp_RotResult.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GP_Y)).BeginInit();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GP_X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Rot_Pts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_AngleFrom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_ShiftH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_AngleTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_RotCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_ShiftV)).BeginInit();
            this.tp_Rot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_PointH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_PitchH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AreaH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_ShiftH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_PitchV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AreaV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_ShiftV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_PointV)).BeginInit();
            this.tp_Cal.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Info);
            this.tabControl.Controls.Add(this.tp_CalResult);
            this.tabControl.Controls.Add(this.tp_RotResult);
            this.tabControl.Controls.Add(this.tp_Cal);
            this.tabControl.Controls.Add(this.tp_Rot);
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // lbl_CurrentJob
            // 
            this.lbl_CurrentJob.Location = new System.Drawing.Point(750, 0);
            this.lbl_CurrentJob.Size = new System.Drawing.Size(148, 26);
            // 
            // tp_Info
            // 
            this.tp_Info.Controls.Add(this.groupBox7);
            this.tp_Info.Controls.Add(this.gb_Manual);
            this.tp_Info.Controls.Add(this.gb_Robot);
            this.tp_Info.Location = new System.Drawing.Point(4, 22);
            this.tp_Info.Name = "tp_Info";
            this.tp_Info.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Info.Size = new System.Drawing.Size(442, 426);
            this.tp_Info.TabIndex = 0;
            this.tp_Info.Text = "Infomation";
            this.tp_Info.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label52);
            this.groupBox7.Controls.Add(this.txt_V_R_Point);
            this.groupBox7.Controls.Add(this.label53);
            this.groupBox7.Controls.Add(this.txt_R_R_Point);
            this.groupBox7.Controls.Add(this.btn_VtoR);
            this.groupBox7.Controls.Add(this.btn_RtoV);
            this.groupBox7.Controls.Add(this.label43);
            this.groupBox7.Controls.Add(this.label42);
            this.groupBox7.Controls.Add(this.label40);
            this.groupBox7.Controls.Add(this.txt_V_Y_Point);
            this.groupBox7.Controls.Add(this.label41);
            this.groupBox7.Controls.Add(this.txt_R_Y_Point);
            this.groupBox7.Controls.Add(this.label39);
            this.groupBox7.Controls.Add(this.txt_V_X_Point);
            this.groupBox7.Controls.Add(this.label37);
            this.groupBox7.Controls.Add(this.txt_R_X_Point);
            this.groupBox7.Location = new System.Drawing.Point(16, 148);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(303, 161);
            this.groupBox7.TabIndex = 36;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Test";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(165, 92);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(18, 13);
            this.label52.TabIndex = 15;
            this.label52.Text = "R:";
            // 
            // txt_V_R_Point
            // 
            this.txt_V_R_Point.Location = new System.Drawing.Point(185, 89);
            this.txt_V_R_Point.Name = "txt_V_R_Point";
            this.txt_V_R_Point.Size = new System.Drawing.Size(100, 20);
            this.txt_V_R_Point.TabIndex = 14;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(5, 92);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(18, 13);
            this.label53.TabIndex = 13;
            this.label53.Text = "R:";
            // 
            // txt_R_R_Point
            // 
            this.txt_R_R_Point.Location = new System.Drawing.Point(25, 89);
            this.txt_R_R_Point.Name = "txt_R_R_Point";
            this.txt_R_R_Point.Size = new System.Drawing.Size(100, 20);
            this.txt_R_R_Point.TabIndex = 12;
            // 
            // btn_VtoR
            // 
            this.btn_VtoR.Location = new System.Drawing.Point(185, 123);
            this.btn_VtoR.Name = "btn_VtoR";
            this.btn_VtoR.Size = new System.Drawing.Size(101, 23);
            this.btn_VtoR.TabIndex = 11;
            this.btn_VtoR.Text = "Robot <- Vision";
            this.btn_VtoR.UseVisualStyleBackColor = true;
            this.btn_VtoR.Click += new System.EventHandler(this.btn_VtoR_Click);
            // 
            // btn_RtoV
            // 
            this.btn_RtoV.Location = new System.Drawing.Point(26, 124);
            this.btn_RtoV.Name = "btn_RtoV";
            this.btn_RtoV.Size = new System.Drawing.Size(101, 23);
            this.btn_RtoV.TabIndex = 10;
            this.btn_RtoV.Text = "Robot -> Vision";
            this.btn_RtoV.UseVisualStyleBackColor = true;
            this.btn_RtoV.Click += new System.EventHandler(this.btn_RtoV_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(204, 16);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(63, 13);
            this.label43.TabIndex = 9;
            this.label43.Text = "Robot Point";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(43, 16);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(63, 13);
            this.label42.TabIndex = 8;
            this.label42.Text = "Robot Point";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(166, 66);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(17, 13);
            this.label40.TabIndex = 7;
            this.label40.Text = "Y:";
            // 
            // txt_V_Y_Point
            // 
            this.txt_V_Y_Point.Location = new System.Drawing.Point(186, 63);
            this.txt_V_Y_Point.Name = "txt_V_Y_Point";
            this.txt_V_Y_Point.Size = new System.Drawing.Size(100, 20);
            this.txt_V_Y_Point.TabIndex = 6;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(6, 66);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(17, 13);
            this.label41.TabIndex = 5;
            this.label41.Text = "Y:";
            // 
            // txt_R_Y_Point
            // 
            this.txt_R_Y_Point.Location = new System.Drawing.Point(26, 63);
            this.txt_R_Y_Point.Name = "txt_R_Y_Point";
            this.txt_R_Y_Point.Size = new System.Drawing.Size(100, 20);
            this.txt_R_Y_Point.TabIndex = 4;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(167, 38);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(17, 13);
            this.label39.TabIndex = 3;
            this.label39.Text = "X:";
            // 
            // txt_V_X_Point
            // 
            this.txt_V_X_Point.Location = new System.Drawing.Point(187, 35);
            this.txt_V_X_Point.Name = "txt_V_X_Point";
            this.txt_V_X_Point.Size = new System.Drawing.Size(100, 20);
            this.txt_V_X_Point.TabIndex = 2;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(7, 38);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(17, 13);
            this.label37.TabIndex = 1;
            this.label37.Text = "X:";
            // 
            // txt_R_X_Point
            // 
            this.txt_R_X_Point.Location = new System.Drawing.Point(27, 35);
            this.txt_R_X_Point.Name = "txt_R_X_Point";
            this.txt_R_X_Point.Size = new System.Drawing.Size(100, 20);
            this.txt_R_X_Point.TabIndex = 0;
            // 
            // gb_Manual
            // 
            this.gb_Manual.Controls.Add(this.gb_ManualMove);
            this.gb_Manual.Controls.Add(this.btn_ManualStart);
            this.gb_Manual.Enabled = false;
            this.gb_Manual.Location = new System.Drawing.Point(16, 367);
            this.gb_Manual.Name = "gb_Manual";
            this.gb_Manual.Size = new System.Drawing.Size(403, 53);
            this.gb_Manual.TabIndex = 35;
            this.gb_Manual.TabStop = false;
            this.gb_Manual.Text = "Manual";
            this.gb_Manual.Visible = false;
            // 
            // gb_ManualMove
            // 
            this.gb_ManualMove.Controls.Add(this.nud_OffsetT);
            this.gb_ManualMove.Controls.Add(this.nud_OffsetY);
            this.gb_ManualMove.Controls.Add(this.nud_OffsetX);
            this.gb_ManualMove.Controls.Add(this.label15);
            this.gb_ManualMove.Controls.Add(this.cb_MoveTeachingPos);
            this.gb_ManualMove.Controls.Add(this.label14);
            this.gb_ManualMove.Controls.Add(this.cb_ManualMoveStart);
            this.gb_ManualMove.Controls.Add(this.label16);
            this.gb_ManualMove.Controls.Add(this.label13);
            this.gb_ManualMove.Controls.Add(this.label12);
            this.gb_ManualMove.Controls.Add(this.cb_ManualIndex);
            this.gb_ManualMove.Controls.Add(this.gb_ManualToolSelector);
            this.gb_ManualMove.Enabled = false;
            this.gb_ManualMove.Location = new System.Drawing.Point(18, 19);
            this.gb_ManualMove.Name = "gb_ManualMove";
            this.gb_ManualMove.Size = new System.Drawing.Size(366, 145);
            this.gb_ManualMove.TabIndex = 38;
            this.gb_ManualMove.TabStop = false;
            this.gb_ManualMove.Visible = false;
            // 
            // nud_OffsetT
            // 
            this.nud_OffsetT.DecimalPlaces = 3;
            this.nud_OffsetT.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_OffsetT.Location = new System.Drawing.Point(282, 117);
            this.nud_OffsetT.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_OffsetT.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_OffsetT.Name = "nud_OffsetT";
            this.nud_OffsetT.Size = new System.Drawing.Size(69, 20);
            this.nud_OffsetT.TabIndex = 34;
            this.nud_OffsetT.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_OffsetY
            // 
            this.nud_OffsetY.DecimalPlaces = 3;
            this.nud_OffsetY.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_OffsetY.Location = new System.Drawing.Point(186, 117);
            this.nud_OffsetY.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_OffsetY.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_OffsetY.Name = "nud_OffsetY";
            this.nud_OffsetY.Size = new System.Drawing.Size(69, 20);
            this.nud_OffsetY.TabIndex = 34;
            this.nud_OffsetY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_OffsetX
            // 
            this.nud_OffsetX.DecimalPlaces = 3;
            this.nud_OffsetX.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_OffsetX.Location = new System.Drawing.Point(90, 117);
            this.nud_OffsetX.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_OffsetX.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            -2147483648});
            this.nud_OffsetX.Name = "nud_OffsetX";
            this.nud_OffsetX.Size = new System.Drawing.Size(69, 20);
            this.nud_OffsetX.TabIndex = 34;
            this.nud_OffsetX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(262, 119);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(23, 13);
            this.label15.TabIndex = 32;
            this.label15.Text = "T : ";
            // 
            // cb_MoveTeachingPos
            // 
            this.cb_MoveTeachingPos.Appearance = System.Windows.Forms.Appearance.Button;
            this.cb_MoveTeachingPos.Location = new System.Drawing.Point(226, 19);
            this.cb_MoveTeachingPos.Name = "cb_MoveTeachingPos";
            this.cb_MoveTeachingPos.Size = new System.Drawing.Size(109, 39);
            this.cb_MoveTeachingPos.TabIndex = 36;
            this.cb_MoveTeachingPos.Text = "Move\r\nTeachingPos";
            this.cb_MoveTeachingPos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cb_MoveTeachingPos.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(166, 119);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 13);
            this.label14.TabIndex = 32;
            this.label14.Text = "Y : ";
            // 
            // cb_ManualMoveStart
            // 
            this.cb_ManualMoveStart.Appearance = System.Windows.Forms.Appearance.Button;
            this.cb_ManualMoveStart.Location = new System.Drawing.Point(226, 65);
            this.cb_ManualMoveStart.Name = "cb_ManualMoveStart";
            this.cb_ManualMoveStart.Size = new System.Drawing.Size(109, 39);
            this.cb_ManualMoveStart.TabIndex = 36;
            this.cb_ManualMoveStart.Text = "Move";
            this.cb_ManualMoveStart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cb_ManualMoveStart.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 119);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "Offset";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(70, 119);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "X : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "Index : ";
            // 
            // cb_ManualIndex
            // 
            this.cb_ManualIndex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_ManualIndex.FormattingEnabled = true;
            this.cb_ManualIndex.Location = new System.Drawing.Point(77, 23);
            this.cb_ManualIndex.Name = "cb_ManualIndex";
            this.cb_ManualIndex.Size = new System.Drawing.Size(111, 21);
            this.cb_ManualIndex.TabIndex = 1;
            // 
            // gb_ManualToolSelector
            // 
            this.gb_ManualToolSelector.Controls.Add(this.rb_Tool1);
            this.gb_ManualToolSelector.Controls.Add(this.rb_Tool2);
            this.gb_ManualToolSelector.Location = new System.Drawing.Point(33, 57);
            this.gb_ManualToolSelector.Name = "gb_ManualToolSelector";
            this.gb_ManualToolSelector.Size = new System.Drawing.Size(155, 47);
            this.gb_ManualToolSelector.TabIndex = 0;
            this.gb_ManualToolSelector.TabStop = false;
            this.gb_ManualToolSelector.Text = "Tool Selector";
            // 
            // rb_Tool1
            // 
            this.rb_Tool1.AutoSize = true;
            this.rb_Tool1.Checked = true;
            this.rb_Tool1.Location = new System.Drawing.Point(24, 19);
            this.rb_Tool1.Name = "rb_Tool1";
            this.rb_Tool1.Size = new System.Drawing.Size(52, 17);
            this.rb_Tool1.TabIndex = 0;
            this.rb_Tool1.TabStop = true;
            this.rb_Tool1.Text = "Tool1";
            this.rb_Tool1.UseVisualStyleBackColor = true;
            // 
            // rb_Tool2
            // 
            this.rb_Tool2.AutoSize = true;
            this.rb_Tool2.Location = new System.Drawing.Point(91, 19);
            this.rb_Tool2.Name = "rb_Tool2";
            this.rb_Tool2.Size = new System.Drawing.Size(52, 17);
            this.rb_Tool2.TabIndex = 0;
            this.rb_Tool2.TabStop = true;
            this.rb_Tool2.Text = "Tool2";
            this.rb_Tool2.UseVisualStyleBackColor = true;
            // 
            // btn_ManualStart
            // 
            this.btn_ManualStart.Location = new System.Drawing.Point(18, 170);
            this.btn_ManualStart.Name = "btn_ManualStart";
            this.btn_ManualStart.Size = new System.Drawing.Size(366, 29);
            this.btn_ManualStart.TabIndex = 36;
            this.btn_ManualStart.Text = "Manual Start";
            this.btn_ManualStart.UseVisualStyleBackColor = true;
            this.btn_ManualStart.Click += new System.EventHandler(this.btn_Start_Click);
            // 
            // gb_Robot
            // 
            this.gb_Robot.Controls.Add(this.label25);
            this.gb_Robot.Controls.Add(this.cb_SelectTool);
            this.gb_Robot.Controls.Add(this.nud_SelectedTP);
            this.gb_Robot.Controls.Add(this.Cal_Simulator);
            this.gb_Robot.Controls.Add(this.lbl_SelectedRobot);
            this.gb_Robot.Controls.Add(this.label8);
            this.gb_Robot.Controls.Add(this.lbl_CamSet);
            this.gb_Robot.Location = new System.Drawing.Point(16, 20);
            this.gb_Robot.Name = "gb_Robot";
            this.gb_Robot.Size = new System.Drawing.Size(403, 106);
            this.gb_Robot.TabIndex = 33;
            this.gb_Robot.TabStop = false;
            this.gb_Robot.Text = "Hardware";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(16, 59);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(67, 13);
            this.label25.TabIndex = 36;
            this.label25.Text = "Select Tool :";
            // 
            // cb_SelectTool
            // 
            this.cb_SelectTool.FormattingEnabled = true;
            this.cb_SelectTool.Items.AddRange(new object[] {
            "Tool 0",
            "Tool 1",
            "Tool 2",
            "Tool 3",
            "Tool 4",
            "Tool 5",
            "Tool 6",
            "Tool 7",
            "Tool 8",
            "Tool 9"});
            this.cb_SelectTool.Location = new System.Drawing.Point(156, 56);
            this.cb_SelectTool.Name = "cb_SelectTool";
            this.cb_SelectTool.Size = new System.Drawing.Size(71, 21);
            this.cb_SelectTool.TabIndex = 35;
            // 
            // nud_SelectedTP
            // 
            this.nud_SelectedTP.Location = new System.Drawing.Point(156, 30);
            this.nud_SelectedTP.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_SelectedTP.Name = "nud_SelectedTP";
            this.nud_SelectedTP.Size = new System.Drawing.Size(71, 20);
            this.nud_SelectedTP.TabIndex = 34;
            this.nud_SelectedTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Cal_Simulator
            // 
            this.Cal_Simulator.Location = new System.Drawing.Point(299, 30);
            this.Cal_Simulator.Name = "Cal_Simulator";
            this.Cal_Simulator.Size = new System.Drawing.Size(85, 49);
            this.Cal_Simulator.TabIndex = 34;
            this.Cal_Simulator.Text = "Cal Simulator";
            this.Cal_Simulator.UseVisualStyleBackColor = true;
            this.Cal_Simulator.Visible = false;
            this.Cal_Simulator.Click += new System.EventHandler(this.Cal_Simulator_Click);
            // 
            // lbl_SelectedRobot
            // 
            this.lbl_SelectedRobot.AutoSize = true;
            this.lbl_SelectedRobot.Location = new System.Drawing.Point(139, 90);
            this.lbl_SelectedRobot.Name = "lbl_SelectedRobot";
            this.lbl_SelectedRobot.Size = new System.Drawing.Size(33, 13);
            this.lbl_SelectedRobot.TabIndex = 33;
            this.lbl_SelectedRobot.Text = "None";
            this.lbl_SelectedRobot.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 13);
            this.label8.TabIndex = 32;
            this.label8.Text = "Selected Robot : ";
            this.label8.Visible = false;
            // 
            // lbl_CamSet
            // 
            this.lbl_CamSet.AutoSize = true;
            this.lbl_CamSet.Location = new System.Drawing.Point(15, 32);
            this.lbl_CamSet.Name = "lbl_CamSet";
            this.lbl_CamSet.Size = new System.Drawing.Size(133, 13);
            this.lbl_CamSet.TabIndex = 32;
            this.lbl_CamSet.Text = "Selected Teaching Point : ";
            // 
            // tp_CalResult
            // 
            this.tp_CalResult.Controls.Add(this.groupBox3);
            this.tp_CalResult.Controls.Add(this.label20);
            this.tp_CalResult.Controls.Add(this.label19);
            this.tp_CalResult.Controls.Add(this.nud_UsingArea);
            this.tp_CalResult.Controls.Add(this.nud_Degree);
            this.tp_CalResult.Controls.Add(this.btn_MakeCalMatrix);
            this.tp_CalResult.Controls.Add(this.gv_Diff);
            this.tp_CalResult.Controls.Add(this.gv_Cal_Result);
            this.tp_CalResult.Location = new System.Drawing.Point(4, 22);
            this.tp_CalResult.Name = "tp_CalResult";
            this.tp_CalResult.Size = new System.Drawing.Size(442, 426);
            this.tp_CalResult.TabIndex = 2;
            this.tp_CalResult.Text = "Calibration Result";
            this.tp_CalResult.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.txt_distanceY);
            this.groupBox3.Controls.Add(this.txt_distanceX);
            this.groupBox3.Location = new System.Drawing.Point(144, 383);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(220, 36);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Distance";
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(112, 16);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(14, 13);
            this.label26.TabIndex = 24;
            this.label26.Text = "Y";
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(2, 17);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(14, 13);
            this.label24.TabIndex = 23;
            this.label24.Text = "X";
            // 
            // txt_distanceY
            // 
            this.txt_distanceY.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_distanceY.Location = new System.Drawing.Point(128, 13);
            this.txt_distanceY.Name = "txt_distanceY";
            this.txt_distanceY.Size = new System.Drawing.Size(90, 20);
            this.txt_distanceY.TabIndex = 22;
            // 
            // txt_distanceX
            // 
            this.txt_distanceX.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_distanceX.Location = new System.Drawing.Point(17, 13);
            this.txt_distanceX.Name = "txt_distanceX";
            this.txt_distanceX.Size = new System.Drawing.Size(90, 20);
            this.txt_distanceX.TabIndex = 21;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(287, 406);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 13);
            this.label20.TabIndex = 9;
            this.label20.Text = "Using Area :";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(287, 383);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 9;
            this.label19.Text = "Calib. Degree :";
            // 
            // nud_UsingArea
            // 
            this.nud_UsingArea.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_UsingArea.DecimalPlaces = 2;
            this.nud_UsingArea.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.nud_UsingArea.Location = new System.Drawing.Point(364, 402);
            this.nud_UsingArea.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_UsingArea.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            65536});
            this.nud_UsingArea.Name = "nud_UsingArea";
            this.nud_UsingArea.Size = new System.Drawing.Size(74, 20);
            this.nud_UsingArea.TabIndex = 8;
            this.nud_UsingArea.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_UsingArea.Visible = false;
            this.nud_UsingArea.ValueChanged += new System.EventHandler(this.nud_Degree_ValueChanged);
            // 
            // nud_Degree
            // 
            this.nud_Degree.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nud_Degree.Location = new System.Drawing.Point(364, 379);
            this.nud_Degree.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Degree.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Degree.Name = "nud_Degree";
            this.nud_Degree.Size = new System.Drawing.Size(74, 20);
            this.nud_Degree.TabIndex = 8;
            this.nud_Degree.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Degree.Visible = false;
            this.nud_Degree.ValueChanged += new System.EventHandler(this.nud_Degree_ValueChanged);
            // 
            // btn_MakeCalMatrix
            // 
            this.btn_MakeCalMatrix.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_MakeCalMatrix.Location = new System.Drawing.Point(9, 387);
            this.btn_MakeCalMatrix.Name = "btn_MakeCalMatrix";
            this.btn_MakeCalMatrix.Size = new System.Drawing.Size(128, 33);
            this.btn_MakeCalMatrix.TabIndex = 7;
            this.btn_MakeCalMatrix.Text = "Make Calibration Matrix";
            this.btn_MakeCalMatrix.UseVisualStyleBackColor = true;
            this.btn_MakeCalMatrix.Click += new System.EventHandler(this.btn_MakeCalMatrix_Click);
            // 
            // gv_Diff
            // 
            this.gv_Diff.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Diff.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.gv_Diff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Diff.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Diff.DefaultCellStyle = dataGridViewCellStyle14;
            this.gv_Diff.Location = new System.Drawing.Point(8, 306);
            this.gv_Diff.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gv_Diff.Name = "gv_Diff";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Diff.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.gv_Diff.RowHeadersVisible = false;
            this.gv_Diff.RowTemplate.Height = 27;
            this.gv_Diff.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gv_Diff.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Diff.Size = new System.Drawing.Size(428, 72);
            this.gv_Diff.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DividerWidth = 1;
            this.dataGridViewTextBoxColumn2.HeaderText = "";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 92;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DividerWidth = 1;
            this.dataGridViewTextBoxColumn3.HeaderText = "Min (mm)";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 112;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DividerWidth = 1;
            this.dataGridViewTextBoxColumn4.HeaderText = "Max (mm)";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 112;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DividerWidth = 1;
            this.dataGridViewTextBoxColumn5.HeaderText = "3*Std.";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 112;
            // 
            // gv_Cal_Result
            // 
            this.gv_Cal_Result.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Cal_Result.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.gv_Cal_Result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Cal_Result.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.No,
            this.RobotX,
            this.RobotY,
            this.VisionX,
            this.VisionY,
            this.DiffX,
            this.DiffY,
            this.VisionX_Pixel,
            this.VisionY_Pixel,
            this.VisionX_Pixel_Shift,
            this.VisionY_Pixel_Shift});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Cal_Result.DefaultCellStyle = dataGridViewCellStyle17;
            this.gv_Cal_Result.Location = new System.Drawing.Point(8, 10);
            this.gv_Cal_Result.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gv_Cal_Result.Name = "gv_Cal_Result";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Cal_Result.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.gv_Cal_Result.RowHeadersVisible = false;
            this.gv_Cal_Result.RowTemplate.Height = 27;
            this.gv_Cal_Result.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Cal_Result.Size = new System.Drawing.Size(428, 292);
            this.gv_Cal_Result.TabIndex = 6;
            // 
            // No
            // 
            this.No.DividerWidth = 1;
            this.No.HeaderText = "No";
            this.No.Name = "No";
            this.No.Width = 30;
            // 
            // RobotX
            // 
            this.RobotX.DividerWidth = 1;
            this.RobotX.HeaderText = "R_X (㎜)";
            this.RobotX.Name = "RobotX";
            this.RobotX.Width = 60;
            // 
            // RobotY
            // 
            this.RobotY.DividerWidth = 1;
            this.RobotY.HeaderText = "R_Y (㎜)";
            this.RobotY.Name = "RobotY";
            this.RobotY.Width = 60;
            // 
            // VisionX
            // 
            this.VisionX.DividerWidth = 1;
            this.VisionX.HeaderText = "V_X (㎜)";
            this.VisionX.Name = "VisionX";
            this.VisionX.Width = 60;
            // 
            // VisionY
            // 
            this.VisionY.DividerWidth = 1;
            this.VisionY.HeaderText = "V_Y (㎜)";
            this.VisionY.Name = "VisionY";
            this.VisionY.Width = 60;
            // 
            // DiffX
            // 
            this.DiffX.DividerWidth = 1;
            this.DiffX.HeaderText = "DiffX";
            this.DiffX.Name = "DiffX";
            this.DiffX.Width = 50;
            // 
            // DiffY
            // 
            this.DiffY.DividerWidth = 1;
            this.DiffY.HeaderText = "DiffY";
            this.DiffY.Name = "DiffY";
            this.DiffY.Width = 50;
            // 
            // VisionX_Pixel
            // 
            this.VisionX_Pixel.HeaderText = "V_X (P)";
            this.VisionX_Pixel.Name = "VisionX_Pixel";
            this.VisionX_Pixel.Width = 60;
            // 
            // VisionY_Pixel
            // 
            this.VisionY_Pixel.HeaderText = "V_Y (P)";
            this.VisionY_Pixel.Name = "VisionY_Pixel";
            this.VisionY_Pixel.Width = 60;
            // 
            // VisionX_Pixel_Shift
            // 
            this.VisionX_Pixel_Shift.HeaderText = "V_X_Shift";
            this.VisionX_Pixel_Shift.Name = "VisionX_Pixel_Shift";
            this.VisionX_Pixel_Shift.Width = 60;
            // 
            // VisionY_Pixel_Shift
            // 
            this.VisionY_Pixel_Shift.HeaderText = "V_Y_Shift";
            this.VisionY_Pixel_Shift.Name = "VisionY_Pixel_Shift";
            this.VisionY_Pixel_Shift.Width = 60;
            // 
            // tp_RotResult
            // 
            this.tp_RotResult.Controls.Add(this.groupBox8);
            this.tp_RotResult.Controls.Add(this.groupBox4);
            this.tp_RotResult.Controls.Add(this.groupBox2);
            this.tp_RotResult.Controls.Add(this.label10);
            this.tp_RotResult.Controls.Add(this.nud_GP_Y);
            this.tp_RotResult.Controls.Add(this.groupBox13);
            this.tp_RotResult.Controls.Add(this.label7);
            this.tp_RotResult.Controls.Add(this.nud_GP_X);
            this.tp_RotResult.Controls.Add(this.gv_Rot_Pts);
            this.tp_RotResult.Location = new System.Drawing.Point(4, 22);
            this.tp_RotResult.Name = "tp_RotResult";
            this.tp_RotResult.Size = new System.Drawing.Size(442, 426);
            this.tp_RotResult.TabIndex = 4;
            this.tp_RotResult.Text = "Rotation Result";
            this.tp_RotResult.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox8.Controls.Add(this.label50);
            this.groupBox8.Controls.Add(this.label51);
            this.groupBox8.Controls.Add(this.txt_RobotHE_TCP_Y);
            this.groupBox8.Controls.Add(this.txt_RobotHE_TCP_X);
            this.groupBox8.Controls.Add(this.label46);
            this.groupBox8.Controls.Add(this.label49);
            this.groupBox8.Controls.Add(this.txt_VisionHE_TCP_Y);
            this.groupBox8.Controls.Add(this.txt_VisionHE_TCP_X);
            this.groupBox8.Location = new System.Drawing.Point(11, 261);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(182, 73);
            this.groupBox8.TabIndex = 16;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "HE TCP";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(85, 51);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(25, 13);
            this.label50.TabIndex = 16;
            this.label50.Text = "RY:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(-2, 51);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(25, 13);
            this.label51.TabIndex = 15;
            this.label51.Text = "RX:";
            // 
            // txt_RobotHE_TCP_Y
            // 
            this.txt_RobotHE_TCP_Y.Location = new System.Drawing.Point(110, 47);
            this.txt_RobotHE_TCP_Y.Name = "txt_RobotHE_TCP_Y";
            this.txt_RobotHE_TCP_Y.Size = new System.Drawing.Size(66, 20);
            this.txt_RobotHE_TCP_Y.TabIndex = 14;
            // 
            // txt_RobotHE_TCP_X
            // 
            this.txt_RobotHE_TCP_X.Location = new System.Drawing.Point(23, 47);
            this.txt_RobotHE_TCP_X.Name = "txt_RobotHE_TCP_X";
            this.txt_RobotHE_TCP_X.Size = new System.Drawing.Size(60, 20);
            this.txt_RobotHE_TCP_X.TabIndex = 13;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(86, 19);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(24, 13);
            this.label46.TabIndex = 12;
            this.label46.Text = "VY:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(-1, 19);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(24, 13);
            this.label49.TabIndex = 11;
            this.label49.Text = "VX:";
            // 
            // txt_VisionHE_TCP_Y
            // 
            this.txt_VisionHE_TCP_Y.Location = new System.Drawing.Point(110, 15);
            this.txt_VisionHE_TCP_Y.Name = "txt_VisionHE_TCP_Y";
            this.txt_VisionHE_TCP_Y.Size = new System.Drawing.Size(66, 20);
            this.txt_VisionHE_TCP_Y.TabIndex = 1;
            // 
            // txt_VisionHE_TCP_X
            // 
            this.txt_VisionHE_TCP_X.Location = new System.Drawing.Point(23, 15);
            this.txt_VisionHE_TCP_X.Name = "txt_VisionHE_TCP_X";
            this.txt_VisionHE_TCP_X.Size = new System.Drawing.Size(60, 20);
            this.txt_VisionHE_TCP_X.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.txt_RobotMaster_Z);
            this.groupBox4.Controls.Add(this.label34);
            this.groupBox4.Controls.Add(this.txt_VisionMaster_Z);
            this.groupBox4.Controls.Add(this.label36);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.txt_RobotMaster_Y);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.txt_RobotMaster_X);
            this.groupBox4.Controls.Add(this.txt_VisionMaster_Y);
            this.groupBox4.Controls.Add(this.txt_VisionMaster_X);
            this.groupBox4.Location = new System.Drawing.Point(192, 265);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(243, 63);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vision Master";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(165, 44);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(26, 13);
            this.label33.TabIndex = 14;
            this.label33.Text = "RR:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(165, 18);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(25, 13);
            this.label35.TabIndex = 14;
            this.label35.Text = "VR:";
            // 
            // txt_RobotMaster_Z
            // 
            this.txt_RobotMaster_Z.Location = new System.Drawing.Point(187, 40);
            this.txt_RobotMaster_Z.Name = "txt_RobotMaster_Z";
            this.txt_RobotMaster_Z.Size = new System.Drawing.Size(57, 20);
            this.txt_RobotMaster_Z.TabIndex = 13;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(85, 45);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(25, 13);
            this.label34.TabIndex = 12;
            this.label34.Text = "RY:";
            // 
            // txt_VisionMaster_Z
            // 
            this.txt_VisionMaster_Z.Location = new System.Drawing.Point(187, 14);
            this.txt_VisionMaster_Z.Name = "txt_VisionMaster_Z";
            this.txt_VisionMaster_Z.Size = new System.Drawing.Size(57, 20);
            this.txt_VisionMaster_Z.TabIndex = 13;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(2, 45);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(25, 13);
            this.label36.TabIndex = 11;
            this.label36.Text = "RX:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(85, 19);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(24, 13);
            this.label31.TabIndex = 12;
            this.label31.Text = "VY:";
            // 
            // txt_RobotMaster_Y
            // 
            this.txt_RobotMaster_Y.Location = new System.Drawing.Point(109, 41);
            this.txt_RobotMaster_Y.Name = "txt_RobotMaster_Y";
            this.txt_RobotMaster_Y.Size = new System.Drawing.Size(57, 20);
            this.txt_RobotMaster_Y.TabIndex = 1;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(3, 19);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(24, 13);
            this.label32.TabIndex = 11;
            this.label32.Text = "VX:";
            // 
            // txt_RobotMaster_X
            // 
            this.txt_RobotMaster_X.Location = new System.Drawing.Point(27, 41);
            this.txt_RobotMaster_X.Name = "txt_RobotMaster_X";
            this.txt_RobotMaster_X.Size = new System.Drawing.Size(57, 20);
            this.txt_RobotMaster_X.TabIndex = 0;
            // 
            // txt_VisionMaster_Y
            // 
            this.txt_VisionMaster_Y.Location = new System.Drawing.Point(108, 15);
            this.txt_VisionMaster_Y.Name = "txt_VisionMaster_Y";
            this.txt_VisionMaster_Y.Size = new System.Drawing.Size(57, 20);
            this.txt_VisionMaster_Y.TabIndex = 1;
            // 
            // txt_VisionMaster_X
            // 
            this.txt_VisionMaster_X.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txt_VisionMaster_X.Location = new System.Drawing.Point(27, 17);
            this.txt_VisionMaster_X.Name = "txt_VisionMaster_X";
            this.txt_VisionMaster_X.Size = new System.Drawing.Size(57, 20);
            this.txt_VisionMaster_X.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.txt_VisionTCP_Y);
            this.groupBox2.Controls.Add(this.txt_VisionTCP_X);
            this.groupBox2.Controls.Add(this.txt_RobotTCP_Y);
            this.groupBox2.Controls.Add(this.txt_RobotTCP_X);
            this.groupBox2.Location = new System.Drawing.Point(8, 339);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(185, 80);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "TT TCP";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(89, 49);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(25, 13);
            this.label29.TabIndex = 12;
            this.label29.Text = "RY:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(89, 19);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(24, 13);
            this.label28.TabIndex = 12;
            this.label28.Text = "VY:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(-1, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(24, 13);
            this.label27.TabIndex = 11;
            this.label27.Text = "VX:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(0, 49);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(25, 13);
            this.label30.TabIndex = 11;
            this.label30.Text = "RX:";
            // 
            // txt_VisionTCP_Y
            // 
            this.txt_VisionTCP_Y.Location = new System.Drawing.Point(114, 15);
            this.txt_VisionTCP_Y.Name = "txt_VisionTCP_Y";
            this.txt_VisionTCP_Y.Size = new System.Drawing.Size(61, 20);
            this.txt_VisionTCP_Y.TabIndex = 1;
            // 
            // txt_VisionTCP_X
            // 
            this.txt_VisionTCP_X.Location = new System.Drawing.Point(24, 15);
            this.txt_VisionTCP_X.Name = "txt_VisionTCP_X";
            this.txt_VisionTCP_X.Size = new System.Drawing.Size(61, 20);
            this.txt_VisionTCP_X.TabIndex = 0;
            // 
            // txt_RobotTCP_Y
            // 
            this.txt_RobotTCP_Y.Location = new System.Drawing.Point(114, 45);
            this.txt_RobotTCP_Y.Name = "txt_RobotTCP_Y";
            this.txt_RobotTCP_Y.Size = new System.Drawing.Size(61, 20);
            this.txt_RobotTCP_Y.TabIndex = 1;
            // 
            // txt_RobotTCP_X
            // 
            this.txt_RobotTCP_X.Location = new System.Drawing.Point(25, 45);
            this.txt_RobotTCP_X.Name = "txt_RobotTCP_X";
            this.txt_RobotTCP_X.Size = new System.Drawing.Size(61, 20);
            this.txt_RobotTCP_X.TabIndex = 0;
            // 
            // btn_CalRotationCenter
            // 
            this.btn_CalRotationCenter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_CalRotationCenter.Location = new System.Drawing.Point(152, 12);
            this.btn_CalRotationCenter.Name = "btn_CalRotationCenter";
            this.btn_CalRotationCenter.Size = new System.Drawing.Size(82, 71);
            this.btn_CalRotationCenter.TabIndex = 8;
            this.btn_CalRotationCenter.Text = "Make Calibration Matrix";
            this.btn_CalRotationCenter.UseVisualStyleBackColor = true;
            this.btn_CalRotationCenter.Click += new System.EventHandler(this.btn_CalRotationCenter_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(215, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Robot GP Y :";
            // 
            // nud_GP_Y
            // 
            this.nud_GP_Y.DecimalPlaces = 3;
            this.nud_GP_Y.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_GP_Y.Location = new System.Drawing.Point(296, 16);
            this.nud_GP_Y.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nud_GP_Y.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.nud_GP_Y.Name = "nud_GP_Y";
            this.nud_GP_Y.Size = new System.Drawing.Size(88, 20);
            this.nud_GP_Y.TabIndex = 8;
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox13.Controls.Add(this.label45);
            this.groupBox13.Controls.Add(this.label48);
            this.groupBox13.Controls.Add(this.lbl_Rot_Origin_RLocation);
            this.groupBox13.Controls.Add(this.btn_CalRotationCenter);
            this.groupBox13.Controls.Add(this.lbl_Rot_Origin_VLocation);
            this.groupBox13.Controls.Add(this.lbl_Rot_Origin_RadiusVision);
            this.groupBox13.Controls.Add(this.lbl_Rot_Origin_RadiusRobot);
            this.groupBox13.Controls.Add(this.label44);
            this.groupBox13.Controls.Add(this.label47);
            this.groupBox13.Location = new System.Drawing.Point(201, 334);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(234, 89);
            this.groupBox13.TabIndex = 7;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Rotation Origin";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(4, 62);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 13);
            this.label45.TabIndex = 3;
            this.label45.Text = "Vision";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(106, 17);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(40, 13);
            this.label48.TabIndex = 4;
            this.label48.Text = "Radius";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_Rot_Origin_RLocation
            // 
            this.lbl_Rot_Origin_RLocation.AutoSize = true;
            this.lbl_Rot_Origin_RLocation.Location = new System.Drawing.Point(38, 39);
            this.lbl_Rot_Origin_RLocation.Name = "lbl_Rot_Origin_RLocation";
            this.lbl_Rot_Origin_RLocation.Size = new System.Drawing.Size(79, 13);
            this.lbl_Rot_Origin_RLocation.TabIndex = 4;
            this.lbl_Rot_Origin_RLocation.Text = "(          ,           )";
            this.lbl_Rot_Origin_RLocation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_Rot_Origin_VLocation
            // 
            this.lbl_Rot_Origin_VLocation.AutoSize = true;
            this.lbl_Rot_Origin_VLocation.Location = new System.Drawing.Point(38, 62);
            this.lbl_Rot_Origin_VLocation.Name = "lbl_Rot_Origin_VLocation";
            this.lbl_Rot_Origin_VLocation.Size = new System.Drawing.Size(79, 13);
            this.lbl_Rot_Origin_VLocation.TabIndex = 4;
            this.lbl_Rot_Origin_VLocation.Text = "(          ,           )";
            this.lbl_Rot_Origin_VLocation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_Rot_Origin_RadiusVision
            // 
            this.lbl_Rot_Origin_RadiusVision.AutoSize = true;
            this.lbl_Rot_Origin_RadiusVision.Location = new System.Drawing.Point(89, 62);
            this.lbl_Rot_Origin_RadiusVision.Name = "lbl_Rot_Origin_RadiusVision";
            this.lbl_Rot_Origin_RadiusVision.Size = new System.Drawing.Size(51, 13);
            this.lbl_Rot_Origin_RadiusVision.TabIndex = 4;
            this.lbl_Rot_Origin_RadiusVision.Text = "           px";
            this.lbl_Rot_Origin_RadiusVision.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_Rot_Origin_RadiusRobot
            // 
            this.lbl_Rot_Origin_RadiusRobot.AutoSize = true;
            this.lbl_Rot_Origin_RadiusRobot.Location = new System.Drawing.Point(89, 39);
            this.lbl_Rot_Origin_RadiusRobot.Name = "lbl_Rot_Origin_RadiusRobot";
            this.lbl_Rot_Origin_RadiusRobot.Size = new System.Drawing.Size(56, 13);
            this.lbl_Rot_Origin_RadiusRobot.TabIndex = 4;
            this.lbl_Rot_Origin_RadiusRobot.Text = "           mm";
            this.lbl_Rot_Origin_RadiusRobot.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(5, 39);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(36, 13);
            this.label44.TabIndex = 4;
            this.label44.Text = "Robot";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(61, 17);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(48, 13);
            this.label47.TabIndex = 4;
            this.label47.Text = "Location";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Robot GP X :";
            // 
            // nud_GP_X
            // 
            this.nud_GP_X.DecimalPlaces = 3;
            this.nud_GP_X.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_GP_X.Location = new System.Drawing.Point(98, 16);
            this.nud_GP_X.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nud_GP_X.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            -2147483648});
            this.nud_GP_X.Name = "nud_GP_X";
            this.nud_GP_X.Size = new System.Drawing.Size(88, 20);
            this.nud_GP_X.TabIndex = 8;
            // 
            // gv_Rot_Pts
            // 
            this.gv_Rot_Pts.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Rot_Pts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.gv_Rot_Pts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv_Rot_Pts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.RotateAngle,
            this.RotateX,
            this.RotateY,
            this.RotateT,
            this.R_X,
            this.R_Y});
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gv_Rot_Pts.DefaultCellStyle = dataGridViewCellStyle11;
            this.gv_Rot_Pts.Location = new System.Drawing.Point(8, 54);
            this.gv_Rot_Pts.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gv_Rot_Pts.Name = "gv_Rot_Pts";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gv_Rot_Pts.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.gv_Rot_Pts.RowHeadersVisible = false;
            this.gv_Rot_Pts.RowTemplate.Height = 27;
            this.gv_Rot_Pts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gv_Rot_Pts.Size = new System.Drawing.Size(428, 202);
            this.gv_Rot_Pts.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DividerWidth = 1;
            this.dataGridViewTextBoxColumn1.HeaderText = "No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 30;
            // 
            // RotateAngle
            // 
            this.RotateAngle.HeaderText = "Angle (deg)";
            this.RotateAngle.Name = "RotateAngle";
            // 
            // RotateX
            // 
            this.RotateX.HeaderText = "V_X (P)";
            this.RotateX.Name = "RotateX";
            // 
            // RotateY
            // 
            this.RotateY.HeaderText = "V_Y (P)";
            this.RotateY.Name = "RotateY";
            // 
            // RotateT
            // 
            this.RotateT.HeaderText = "V_T (deg)";
            this.RotateT.Name = "RotateT";
            // 
            // R_X
            // 
            this.R_X.HeaderText = "R_X(mm)";
            this.R_X.Name = "R_X";
            // 
            // R_Y
            // 
            this.R_Y.HeaderText = "R_Y(mm)";
            this.R_Y.Name = "R_Y";
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(220, 15);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(215, 167);
            this.groupBox5.TabIndex = 20;
            this.groupBox5.TabStop = false;
            this.groupBox5.Visible = false;
            // 
            // lbl_RotShiftX
            // 
            this.lbl_RotShiftX.AutoSize = true;
            this.lbl_RotShiftX.Location = new System.Drawing.Point(125, 139);
            this.lbl_RotShiftX.Name = "lbl_RotShiftX";
            this.lbl_RotShiftX.Size = new System.Drawing.Size(10, 13);
            this.lbl_RotShiftX.TabIndex = 6;
            this.lbl_RotShiftX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(97, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 13);
            this.label6.TabIndex = 4;
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_AngleFrom
            // 
            this.lbl_AngleFrom.AutoSize = true;
            this.lbl_AngleFrom.Location = new System.Drawing.Point(9, 27);
            this.lbl_AngleFrom.Name = "lbl_AngleFrom";
            this.lbl_AngleFrom.Size = new System.Drawing.Size(69, 13);
            this.lbl_AngleFrom.TabIndex = 0;
            this.lbl_AngleFrom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(185, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 13);
            this.label5.TabIndex = 4;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_AngleTo
            // 
            this.lbl_AngleTo.AutoSize = true;
            this.lbl_AngleTo.Location = new System.Drawing.Point(111, 27);
            this.lbl_AngleTo.Name = "lbl_AngleTo";
            this.lbl_AngleTo.Size = new System.Drawing.Size(56, 13);
            this.lbl_AngleTo.TabIndex = 0;
            this.lbl_AngleTo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(173, 85);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(19, 13);
            this.label38.TabIndex = 4;
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_Rotmm
            // 
            this.lbl_Rotmm.AutoSize = true;
            this.lbl_Rotmm.Location = new System.Drawing.Point(185, 139);
            this.lbl_Rotmm.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_Rotmm.Name = "lbl_Rotmm";
            this.lbl_Rotmm.Size = new System.Drawing.Size(23, 13);
            this.lbl_Rotmm.TabIndex = 7;
            this.lbl_Rotmm.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_PosCount
            // 
            this.lbl_PosCount.AutoSize = true;
            this.lbl_PosCount.Location = new System.Drawing.Point(9, 88);
            this.lbl_PosCount.Name = "lbl_PosCount";
            this.lbl_PosCount.Size = new System.Drawing.Size(68, 13);
            this.lbl_PosCount.TabIndex = 0;
            this.lbl_PosCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_RotShift
            // 
            this.lbl_RotShift.AutoSize = true;
            this.lbl_RotShift.Location = new System.Drawing.Point(9, 138);
            this.lbl_RotShift.Name = "lbl_RotShift";
            this.lbl_RotShift.Size = new System.Drawing.Size(40, 13);
            this.lbl_RotShift.TabIndex = 6;
            this.lbl_RotShift.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nud_Rot_AngleFrom
            // 
            this.nud_Rot_AngleFrom.Location = new System.Drawing.Point(25, 45);
            this.nud_Rot_AngleFrom.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Rot_AngleFrom.Minimum = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            this.nud_Rot_AngleFrom.Name = "nud_Rot_AngleFrom";
            this.nud_Rot_AngleFrom.Size = new System.Drawing.Size(65, 20);
            this.nud_Rot_AngleFrom.TabIndex = 5;
            // 
            // nud_Rot_ShiftH
            // 
            this.nud_Rot_ShiftH.Location = new System.Drawing.Point(73, 136);
            this.nud_Rot_ShiftH.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_Rot_ShiftH.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.nud_Rot_ShiftH.Name = "nud_Rot_ShiftH";
            this.nud_Rot_ShiftH.Size = new System.Drawing.Size(50, 20);
            this.nud_Rot_ShiftH.TabIndex = 9;
            this.nud_Rot_ShiftH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Rot_ShiftH.Value = new decimal(new int[] {
            120,
            0,
            0,
            -2147483648});
            // 
            // nud_Rot_AngleTo
            // 
            this.nud_Rot_AngleTo.Location = new System.Drawing.Point(120, 45);
            this.nud_Rot_AngleTo.Maximum = new decimal(new int[] {
            90,
            0,
            0,
            0});
            this.nud_Rot_AngleTo.Minimum = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            this.nud_Rot_AngleTo.Name = "nud_Rot_AngleTo";
            this.nud_Rot_AngleTo.Size = new System.Drawing.Size(65, 20);
            this.nud_Rot_AngleTo.TabIndex = 5;
            // 
            // nud_Rot_RotCount
            // 
            this.nud_Rot_RotCount.Location = new System.Drawing.Point(106, 83);
            this.nud_Rot_RotCount.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.nud_Rot_RotCount.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nud_Rot_RotCount.Name = "nud_Rot_RotCount";
            this.nud_Rot_RotCount.Size = new System.Drawing.Size(65, 20);
            this.nud_Rot_RotCount.TabIndex = 5;
            this.nud_Rot_RotCount.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // nud_Rot_ShiftV
            // 
            this.nud_Rot_ShiftV.Location = new System.Drawing.Point(136, 136);
            this.nud_Rot_ShiftV.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_Rot_ShiftV.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.nud_Rot_ShiftV.Name = "nud_Rot_ShiftV";
            this.nud_Rot_ShiftV.Size = new System.Drawing.Size(50, 20);
            this.nud_Rot_ShiftV.TabIndex = 8;
            this.nud_Rot_ShiftV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_Rot_Start
            // 
            this.btn_Rot_Start.Location = new System.Drawing.Point(220, 188);
            this.btn_Rot_Start.Name = "btn_Rot_Start";
            this.btn_Rot_Start.Size = new System.Drawing.Size(215, 40);
            this.btn_Rot_Start.TabIndex = 21;
            this.btn_Rot_Start.Text = "Start";
            this.btn_Rot_Start.UseVisualStyleBackColor = true;
            this.btn_Rot_Start.Visible = false;
            this.btn_Rot_Start.Click += new System.EventHandler(this.btn_Start_Click);
            // 
            // pbar_Rot
            // 
            this.pbar_Rot.Location = new System.Drawing.Point(220, 234);
            this.pbar_Rot.Name = "pbar_Rot";
            this.pbar_Rot.Size = new System.Drawing.Size(215, 22);
            this.pbar_Rot.Step = 1;
            this.pbar_Rot.TabIndex = 22;
            this.pbar_Rot.Visible = false;
            // 
            // btn_LoadRotRcp
            // 
            this.btn_LoadRotRcp.Location = new System.Drawing.Point(10, 225);
            this.btn_LoadRotRcp.Name = "btn_LoadRotRcp";
            this.btn_LoadRotRcp.Size = new System.Drawing.Size(199, 31);
            this.btn_LoadRotRcp.TabIndex = 23;
            this.btn_LoadRotRcp.Text = "LoadRecipe";
            this.btn_LoadRotRcp.UseVisualStyleBackColor = true;
            this.btn_LoadRotRcp.Visible = false;
            this.btn_LoadRotRcp.Click += new System.EventHandler(this.btn_LoadRecipe_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(15, 270);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 13);
            this.label18.TabIndex = 24;
            this.label18.Visible = false;
            // 
            // tp_Rot
            // 
            this.tp_Rot.Controls.Add(this.label18);
            this.tp_Rot.Controls.Add(this.btn_LoadRotRcp);
            this.tp_Rot.Controls.Add(this.pbar_Rot);
            this.tp_Rot.Controls.Add(this.btn_Rot_Start);
            this.tp_Rot.Controls.Add(this.groupBox5);
            this.tp_Rot.Controls.Add(this.svd_RotPattern);
            this.tp_Rot.Location = new System.Drawing.Point(4, 22);
            this.tp_Rot.Name = "tp_Rot";
            this.tp_Rot.Size = new System.Drawing.Size(442, 426);
            this.tp_Rot.TabIndex = 3;
            this.tp_Rot.Text = "Rotation";
            this.tp_Rot.UseVisualStyleBackColor = true;
            // 
            // svd_RotPattern
            // 
            this.svd_RotPattern.Auto_Fit = false;
            this.svd_RotPattern.AutoScroll = true;
            this.svd_RotPattern.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svd_RotPattern.IsDisplayCenterLine = false;
            this.svd_RotPattern.IsDisplayCoordinate = false;
            this.svd_RotPattern.Location = new System.Drawing.Point(10, 15);
            this.svd_RotPattern.Name = "svd_RotPattern";
            this.svd_RotPattern.Size = new System.Drawing.Size(199, 200);
            this.svd_RotPattern.TabIndex = 7;
            this.svd_RotPattern.ToastVisible = true;
            this.svd_RotPattern.Visible = false;
            this.svd_RotPattern.ZoomVisible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(220, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(215, 167);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(187, 68);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 13);
            this.label3.TabIndex = 0;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(187, 131);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 13);
            this.label1.TabIndex = 0;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(187, 38);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 13);
            this.label21.TabIndex = 0;
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 99);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 0;
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(122, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 0;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_Cross
            // 
            this.lbl_Cross.AutoSize = true;
            this.lbl_Cross.Location = new System.Drawing.Point(122, 69);
            this.lbl_Cross.Name = "lbl_Cross";
            this.lbl_Cross.Size = new System.Drawing.Size(14, 13);
            this.lbl_Cross.TabIndex = 0;
            this.lbl_Cross.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(122, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 13);
            this.label2.TabIndex = 0;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(122, 39);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(14, 13);
            this.label22.TabIndex = 0;
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 69);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 0;
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 39);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(38, 13);
            this.label23.TabIndex = 0;
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_shift
            // 
            this.lbl_shift.AutoSize = true;
            this.lbl_shift.Location = new System.Drawing.Point(10, 131);
            this.lbl_shift.Name = "lbl_shift";
            this.lbl_shift.Size = new System.Drawing.Size(40, 13);
            this.lbl_shift.TabIndex = 0;
            this.lbl_shift.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_X
            // 
            this.lbl_X.AutoSize = true;
            this.lbl_X.Location = new System.Drawing.Point(93, 18);
            this.lbl_X.Name = "lbl_X";
            this.lbl_X.Size = new System.Drawing.Size(57, 13);
            this.lbl_X.TabIndex = 0;
            this.lbl_X.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nud_Cal_PointH
            // 
            this.nud_Cal_PointH.Location = new System.Drawing.Point(71, 96);
            this.nud_Cal_PointH.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Cal_PointH.Name = "nud_Cal_PointH";
            this.nud_Cal_PointH.Size = new System.Drawing.Size(50, 20);
            this.nud_Cal_PointH.TabIndex = 1;
            this.nud_Cal_PointH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Cal_PointH.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_Cal_PitchH
            // 
            this.nud_Cal_PitchH.DecimalPlaces = 1;
            this.nud_Cal_PitchH.Location = new System.Drawing.Point(71, 66);
            this.nud_Cal_PitchH.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_Cal_PitchH.Name = "nud_Cal_PitchH";
            this.nud_Cal_PitchH.Size = new System.Drawing.Size(50, 20);
            this.nud_Cal_PitchH.TabIndex = 1;
            this.nud_Cal_PitchH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Cal_PitchH.Value = new decimal(new int[] {
            120,
            0,
            0,
            0});
            // 
            // nud_AreaH
            // 
            this.nud_AreaH.DecimalPlaces = 1;
            this.nud_AreaH.Location = new System.Drawing.Point(71, 36);
            this.nud_AreaH.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_AreaH.Name = "nud_AreaH";
            this.nud_AreaH.Size = new System.Drawing.Size(50, 20);
            this.nud_AreaH.TabIndex = 1;
            this.nud_AreaH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_AreaH.Value = new decimal(new int[] {
            120,
            0,
            0,
            0});
            // 
            // nud_Cal_ShiftH
            // 
            this.nud_Cal_ShiftH.DecimalPlaces = 1;
            this.nud_Cal_ShiftH.Location = new System.Drawing.Point(71, 128);
            this.nud_Cal_ShiftH.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_Cal_ShiftH.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.nud_Cal_ShiftH.Name = "nud_Cal_ShiftH";
            this.nud_Cal_ShiftH.Size = new System.Drawing.Size(50, 20);
            this.nud_Cal_ShiftH.TabIndex = 1;
            this.nud_Cal_ShiftH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_Cal_PitchV
            // 
            this.nud_Cal_PitchV.DecimalPlaces = 1;
            this.nud_Cal_PitchV.Location = new System.Drawing.Point(136, 66);
            this.nud_Cal_PitchV.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_Cal_PitchV.Name = "nud_Cal_PitchV";
            this.nud_Cal_PitchV.Size = new System.Drawing.Size(50, 20);
            this.nud_Cal_PitchV.TabIndex = 1;
            this.nud_Cal_PitchV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Cal_PitchV.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            // 
            // nud_AreaV
            // 
            this.nud_AreaV.DecimalPlaces = 1;
            this.nud_AreaV.Location = new System.Drawing.Point(136, 36);
            this.nud_AreaV.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_AreaV.Name = "nud_AreaV";
            this.nud_AreaV.Size = new System.Drawing.Size(50, 20);
            this.nud_AreaV.TabIndex = 1;
            this.nud_AreaV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_AreaV.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            // 
            // nud_Cal_ShiftV
            // 
            this.nud_Cal_ShiftV.DecimalPlaces = 1;
            this.nud_Cal_ShiftV.Location = new System.Drawing.Point(136, 128);
            this.nud_Cal_ShiftV.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nud_Cal_ShiftV.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.nud_Cal_ShiftV.Name = "nud_Cal_ShiftV";
            this.nud_Cal_ShiftV.Size = new System.Drawing.Size(50, 20);
            this.nud_Cal_ShiftV.TabIndex = 1;
            this.nud_Cal_ShiftV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // nud_Cal_PointV
            // 
            this.nud_Cal_PointV.Location = new System.Drawing.Point(136, 96);
            this.nud_Cal_PointV.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Cal_PointV.Name = "nud_Cal_PointV";
            this.nud_Cal_PointV.Size = new System.Drawing.Size(50, 20);
            this.nud_Cal_PointV.TabIndex = 1;
            this.nud_Cal_PointV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_Cal_PointV.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // btn_Cal_Start
            // 
            this.btn_Cal_Start.Location = new System.Drawing.Point(220, 188);
            this.btn_Cal_Start.Name = "btn_Cal_Start";
            this.btn_Cal_Start.Size = new System.Drawing.Size(215, 40);
            this.btn_Cal_Start.TabIndex = 7;
            this.btn_Cal_Start.Text = "Start";
            this.btn_Cal_Start.UseVisualStyleBackColor = true;
            this.btn_Cal_Start.Visible = false;
            this.btn_Cal_Start.Click += new System.EventHandler(this.btn_Start_Click);
            // 
            // pbar_Cal
            // 
            this.pbar_Cal.Location = new System.Drawing.Point(220, 234);
            this.pbar_Cal.Name = "pbar_Cal";
            this.pbar_Cal.Size = new System.Drawing.Size(215, 22);
            this.pbar_Cal.Step = 1;
            this.pbar_Cal.TabIndex = 9;
            this.pbar_Cal.Visible = false;
            this.pbar_Cal.Click += new System.EventHandler(this.pbar_Cal_Click);
            // 
            // btn_LoadCalRcp
            // 
            this.btn_LoadCalRcp.Location = new System.Drawing.Point(10, 225);
            this.btn_LoadCalRcp.Name = "btn_LoadCalRcp";
            this.btn_LoadCalRcp.Size = new System.Drawing.Size(199, 31);
            this.btn_LoadCalRcp.TabIndex = 20;
            this.btn_LoadCalRcp.Text = "LoadRecipe";
            this.btn_LoadCalRcp.UseVisualStyleBackColor = true;
            this.btn_LoadCalRcp.Visible = false;
            this.btn_LoadCalRcp.Click += new System.EventHandler(this.btn_LoadRecipe_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 270);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 13);
            this.label17.TabIndex = 21;
            this.label17.Visible = false;
            // 
            // tp_Cal
            // 
            this.tp_Cal.Controls.Add(this.label17);
            this.tp_Cal.Controls.Add(this.btn_LoadCalRcp);
            this.tp_Cal.Controls.Add(this.pbar_Cal);
            this.tp_Cal.Controls.Add(this.btn_Cal_Start);
            this.tp_Cal.Controls.Add(this.groupBox1);
            this.tp_Cal.Controls.Add(this.svd_CalPattern);
            this.tp_Cal.Location = new System.Drawing.Point(4, 22);
            this.tp_Cal.Name = "tp_Cal";
            this.tp_Cal.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Cal.Size = new System.Drawing.Size(442, 426);
            this.tp_Cal.TabIndex = 1;
            this.tp_Cal.Text = "Calibration";
            this.tp_Cal.UseVisualStyleBackColor = true;
            // 
            // svd_CalPattern
            // 
            this.svd_CalPattern.Auto_Fit = false;
            this.svd_CalPattern.AutoScroll = true;
            this.svd_CalPattern.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svd_CalPattern.IsDisplayCenterLine = false;
            this.svd_CalPattern.IsDisplayCoordinate = false;
            this.svd_CalPattern.Location = new System.Drawing.Point(10, 15);
            this.svd_CalPattern.Name = "svd_CalPattern";
            this.svd_CalPattern.Size = new System.Drawing.Size(199, 200);
            this.svd_CalPattern.TabIndex = 0;
            this.svd_CalPattern.ToastVisible = true;
            this.svd_CalPattern.Visible = false;
            this.svd_CalPattern.ZoomVisible = false;
            // 
            // MvCalibrationEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MvCalibrationEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Info.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.gb_Manual.ResumeLayout(false);
            this.gb_ManualMove.ResumeLayout(false);
            this.gb_ManualMove.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OffsetT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OffsetY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_OffsetX)).EndInit();
            this.gb_ManualToolSelector.ResumeLayout(false);
            this.gb_ManualToolSelector.PerformLayout();
            this.gb_Robot.ResumeLayout(false);
            this.gb_Robot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_SelectedTP)).EndInit();
            this.tp_CalResult.ResumeLayout(false);
            this.tp_CalResult.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_UsingArea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Degree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Diff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Cal_Result)).EndInit();
            this.tp_RotResult.ResumeLayout(false);
            this.tp_RotResult.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GP_Y)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_GP_X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv_Rot_Pts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_AngleFrom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_ShiftH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_AngleTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_RotCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Rot_ShiftV)).EndInit();
            this.tp_Rot.ResumeLayout(false);
            this.tp_Rot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_PointH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_PitchH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AreaH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_ShiftH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_PitchV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_AreaV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_ShiftV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Cal_PointV)).EndInit();
            this.tp_Cal.ResumeLayout(false);
            this.tp_Cal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Info;
        private System.Windows.Forms.TabPage tp_CalResult;
        private System.Windows.Forms.TabPage tp_RotResult;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label lbl_Rot_Origin_RLocation;
        private System.Windows.Forms.Label lbl_Rot_Origin_VLocation;
        private System.Windows.Forms.Label lbl_Rot_Origin_RadiusVision;
        private System.Windows.Forms.Label lbl_Rot_Origin_RadiusRobot;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label lbl_CamSet;
        private System.Windows.Forms.GroupBox gb_Robot;
        private System.Windows.Forms.Label lbl_SelectedRobot;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nud_SelectedTP;
        private System.Windows.Forms.DataGridView gv_Cal_Result;
        private System.Windows.Forms.Button btn_MakeCalMatrix;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nud_GP_Y;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nud_GP_X;
        private System.Windows.Forms.DataGridView gv_Rot_Pts;
        private System.Windows.Forms.Button btn_CalRotationCenter;
        private System.Windows.Forms.Button Cal_Simulator;
        private System.Windows.Forms.GroupBox gb_Manual;
        private System.Windows.Forms.Button btn_ManualStart;
        private System.Windows.Forms.ComboBox cb_ManualIndex;
        private System.Windows.Forms.GroupBox gb_ManualToolSelector;
        private System.Windows.Forms.RadioButton rb_Tool1;
        private System.Windows.Forms.RadioButton rb_Tool2;
        private System.Windows.Forms.GroupBox gb_ManualMove;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox cb_ManualMoveStart;
        private System.Windows.Forms.CheckBox cb_MoveTeachingPos;
        private System.Windows.Forms.NumericUpDown nud_OffsetX;
        private System.Windows.Forms.NumericUpDown nud_OffsetT;
        private System.Windows.Forms.NumericUpDown nud_OffsetY;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown nud_Degree;
        private System.Windows.Forms.DataGridView gv_Diff;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown nud_UsingArea;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cb_SelectTool;
        private System.Windows.Forms.TabPage tp_Cal;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btn_LoadCalRcp;
        private System.Windows.Forms.ProgressBar pbar_Cal;
        private System.Windows.Forms.Button btn_Cal_Start;
        private System.Windows.Forms.GroupBox groupBox1;
        private Display.MvDisplayView svd_CalPattern;
        private System.Windows.Forms.TabPage tp_Rot;
        private System.Windows.Forms.Label label18;
        private Display.MvDisplayView svd_RotPattern;
        private System.Windows.Forms.Button btn_LoadRotRcp;
        private System.Windows.Forms.ProgressBar pbar_Rot;
        private System.Windows.Forms.Button btn_Rot_Start;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lbl_RotShiftX;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_AngleFrom;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_AngleTo;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label lbl_Rotmm;
        private System.Windows.Forms.Label lbl_PosCount;
        private System.Windows.Forms.Label lbl_RotShift;
        private System.Windows.Forms.NumericUpDown nud_Rot_AngleFrom;
        private System.Windows.Forms.NumericUpDown nud_Rot_ShiftH;
        private System.Windows.Forms.NumericUpDown nud_Rot_AngleTo;
        private System.Windows.Forms.NumericUpDown nud_Rot_RotCount;
        private System.Windows.Forms.NumericUpDown nud_Rot_ShiftV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Cross;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbl_shift;
        private System.Windows.Forms.Label lbl_X;
        private System.Windows.Forms.NumericUpDown nud_Cal_PointH;
        private System.Windows.Forms.NumericUpDown nud_Cal_PitchH;
        private System.Windows.Forms.NumericUpDown nud_AreaH;
        private System.Windows.Forms.NumericUpDown nud_Cal_ShiftH;
        private System.Windows.Forms.NumericUpDown nud_Cal_PitchV;
        private System.Windows.Forms.NumericUpDown nud_AreaV;
        private System.Windows.Forms.NumericUpDown nud_Cal_ShiftV;
        private System.Windows.Forms.NumericUpDown nud_Cal_PointV;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txt_RobotTCP_Y;
        private System.Windows.Forms.TextBox txt_RobotTCP_X;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txt_VisionTCP_Y;
        private System.Windows.Forms.TextBox txt_VisionTCP_X;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txt_VisionMaster_Y;
        private System.Windows.Forms.TextBox txt_VisionMaster_X;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txt_RobotMaster_Z;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txt_RobotMaster_Y;
        private System.Windows.Forms.TextBox txt_RobotMaster_X;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txt_VisionMaster_Z;
        private System.Windows.Forms.DataGridViewTextBoxColumn No;
        private System.Windows.Forms.DataGridViewTextBoxColumn RobotX;
        private System.Windows.Forms.DataGridViewTextBoxColumn RobotY;
        private System.Windows.Forms.DataGridViewTextBoxColumn VisionX;
        private System.Windows.Forms.DataGridViewTextBoxColumn VisionY;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiffX;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiffY;
        private System.Windows.Forms.DataGridViewTextBoxColumn VisionX_Pixel;
        private System.Windows.Forms.DataGridViewTextBoxColumn VisionY_Pixel;
        private System.Windows.Forms.DataGridViewTextBoxColumn VisionX_Pixel_Shift;
        private System.Windows.Forms.DataGridViewTextBoxColumn VisionY_Pixel_Shift;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txt_V_Y_Point;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txt_R_Y_Point;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txt_V_X_Point;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txt_R_X_Point;
        private System.Windows.Forms.Button btn_VtoR;
        private System.Windows.Forms.Button btn_RtoV;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn RotateAngle;
        private System.Windows.Forms.DataGridViewTextBoxColumn RotateX;
        private System.Windows.Forms.DataGridViewTextBoxColumn RotateY;
        private System.Windows.Forms.DataGridViewTextBoxColumn RotateT;
        private System.Windows.Forms.DataGridViewTextBoxColumn R_X;
        private System.Windows.Forms.DataGridViewTextBoxColumn R_Y;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txt_VisionHE_TCP_Y;
        private System.Windows.Forms.TextBox txt_VisionHE_TCP_X;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txt_RobotHE_TCP_Y;
        private System.Windows.Forms.TextBox txt_RobotHE_TCP_X;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txt_distanceY;
        private System.Windows.Forms.TextBox txt_distanceX;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txt_V_R_Point;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txt_R_R_Point;
    }
}
