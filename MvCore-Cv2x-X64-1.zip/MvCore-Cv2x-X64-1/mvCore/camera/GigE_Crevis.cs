﻿using Crevis.VirtualFG40Library;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MvCore.CameraDevice
{
    public class GigE_Crevis : ICamDevice
    {
        VirtualFG40Library _virtualFG40 = new VirtualFG40Library();
        Int32 _hDevice = 0;
        Int32 _width = 0;
        Int32 _height = 0;
        Int32 _bufferSize = 0;
        Boolean _isOpen = false;
        Boolean _isRun = false;
        IntPtr _pImage = new IntPtr();


        bool isHwTrigger = false;
        public bool IsHwTrigger { get { return isHwTrigger; } set { isHwTrigger = value; } }

        bool isLive = false;
        public bool IsLive { get { return isLive; } set { isLive = value; } }

        private int camIndex;
        public int CamIndex
        {
            get { return camIndex; }
            set { camIndex = value; }
        }
        static GigE_Crevis()
        {
            //string CREVIS_CAM_ROOT = System.IO.Path.Combine(Environment.CurrentDirectory, @"Dll", IntPtr.Size == 4 ? "x86" : "x64", "CREVIS");

            //string currentEnvironmentVariable = Environment.GetEnvironmentVariable("CREVIS_CAM_ROOT", EnvironmentVariableTarget.Machine);
            //if (string.IsNullOrEmpty(currentEnvironmentVariable) || currentEnvironmentVariable != CREVIS_CAM_ROOT)
            //    Environment.SetEnvironmentVariable("CREVIS_CAM_ROOT", CREVIS_CAM_ROOT, EnvironmentVariableTarget.Machine);
        }

        public GigE_Crevis()
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;
            try
            {
                //System Initialize
                status = _virtualFG40.InitSystem();
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("System Initialize failed : {0}", status));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("GigE_Crevis" + ex.ToString());
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
            }
        }
        public void CameraOpen(int camNumber)
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;
            UInt32 camNum = 0;
            UInt32 UcamNum = (UInt32)camNumber;

            bool initstatus = false;
            _virtualFG40.IsInitSystem(ref initstatus);
            if (!initstatus)
            {
                //_virtualFG40.FreeSystem();
                //_virtualFG40.InitSystem();
                return;
            }
            if (_isOpen) return;
            try
            {
                // Update Device List
                status = _virtualFG40.UpdateDevice();
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    _virtualFG40.FreeSystem();
                    throw new Exception(String.Format("Update Device list failed : {0}", status));
                }

                status = _virtualFG40.GetAvailableCameraNum(ref camNum);
                if (camNum <= 0)
                {
                    _virtualFG40.FreeSystem();
                    throw new Exception("The camera can not be connected.");
                }
                // camera open
                status = _virtualFG40.OpenDevice(UcamNum, ref _hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    _virtualFG40.FreeSystem();
                    throw new Exception(String.Format("Open device failed : {0}", status));
                }

                _isOpen = true;

                // Call Set Feature
                SetFeature();

                // Get Width
                status = _virtualFG40.GetIntReg(_hDevice, VirtualFG40Library.MCAM_WIDTH, ref _width);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Read Register failed : {0}", status));
                }

                // Get Height
                status = _virtualFG40.GetIntReg(_hDevice, VirtualFG40Library.MCAM_HEIGHT, ref _height);

                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Read Register failed : {0}", status));
                }

                // Image buffer allocation
                _bufferSize = _width * _height;
                _pImage = Marshal.AllocHGlobal(_bufferSize);

                //pictureBox_Display.Image = new Bitmap(_width, _height, PixelFormat.Format8bppIndexed);
                //IMI와 맞추기 위해 수정...
                AcqusitionStart();
            }
            catch (Exception ex)
            {
                Console.WriteLine("CameraOpen" + ex.ToString());
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
                return;
            }

        }
        public void CameraClose()
        {
            if (_isOpen == true)
            {
                if (_isRun == true)
                    AcqusitionStop();
                if (_pImage != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(_pImage);
                    _pImage = IntPtr.Zero;
                }
                // Close Device
                _virtualFG40.CloseDevice(_hDevice);
            }

            _virtualFG40.FreeSystem();
        }


        private void SetFeature()
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;

            try
            {
                // Set Trigger Mode
                status = _virtualFG40.SetEnumReg(_hDevice, VirtualFG40Library.MCAM_TRIGGER_MODE, VirtualFG40Library.TRIGGER_MODE_ON);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Write Register failed : {0}", status));
                }

                //TriggerSource => Software
                status = _virtualFG40.SetEnumReg(_hDevice, VirtualFG40Library.MCAM_TRIGGER_SOURCE, VirtualFG40Library.TRIGGER_SOURCE_SOFTWARE);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Write Register failed : {0}", status));
                }

                //TriggerDelay => 1us
                status = _virtualFG40.SetFloatReg(_hDevice, VirtualFG40Library.MCAM_TRIGGER_DELAY, 1.0f);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Write Register failed : {0}", status));
                }

                // Set PixelFormat
                status = _virtualFG40.SetEnumReg(_hDevice, VirtualFG40Library.MCAM_PIXEL_FORMAT, VirtualFG40Library.PIXEL_FORMAT_MONO8);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Write Register failed : {0}", status));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("SetFrature" + ex.ToString());
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
                return;
            }
        }
        public Mat QueryFrame()
        {
            return null;
        }
        public Mat GrabImage()
        {
            // 1. Excute Acquisition Start command
            // 2. Excute GrabStartAsync command
            // 3. Excute SoftwareTrigger command
            // 4. Grab Image using GrabImageAsync
            // 5. Image Display

            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;

            if (!_isOpen) return null;
            if (!_isRun)
            {
                AcqusitionStart();
            }

            try
            {
                //IMI와 맞추기 위해 수정...
                /*
                // Acqusition Start
                status = _virtualFG40.AcqStart(_hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    //bool test = false;
                    //status = _virtualFG40.IsInitSystem(ref test);
                    //status = _virtualFG40.IsOpenDevice(_hDevice, ref test);
                    throw new Exception(String.Format("Acqusition Start failed : {0}", status));
                }

                // GrabStartAsync
                _virtualFG40.GrabStartAsync(_hDevice, 0xFFFFFFFF);
                */
                // Software Trigger
                status = _virtualFG40.SetCmdReg(_hDevice, VirtualFG40Library.MCAM_TRIGGER_SOFTWARE);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Software trigger command failed : {0}", status));
                }

                // Delay
                DateTime startTime = DateTime.Now;
                while (DateTime.Now.Subtract(startTime).TotalMilliseconds < BeforeGrabDelay)
                {
                    System.Threading.Thread.Sleep(1);
                }

                // Grab Function
                status = _virtualFG40.GrabImageAsync(_hDevice, _pImage, (UInt32)_bufferSize, 0xFFFFFFFF);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("GrabImage failed : {0}", status));
                }

                // Grab Function
                //DispImage();
                //Mat GrabImg = new Mat(_pImage).Clone(); //아래코드와 차이점은?
                Mat GrabImg = new Mat((int)_height, (int)_width, MatType.CV_8U, _pImage).Clone();
                //Mat GrabImg = new Mat((int)_height, (int)_width, MatType.CV_8U);
                //GrabImg.SetArray(_pImage);

                // Acqusition Stop
                /*
                status = _virtualFG40.AcqStop(_hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Acqusition Stop failed : {0}", status));
                }
                 */
                return GrabImg;
            }
            catch (Exception ex)
            {
                Console.WriteLine("grabImage" + ex.ToString());
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
                return null;
            }
        }
        public void AcqusitionStart()
        {
            // 1. Change Acquisition Mode : Continuous
            // 2. Excute Acqusition Start Command
            // 3. Excute GrabStartAsync command
            // 4. Acqusution Loop Function (Timer)
            // -> Excute SoftwareTrigger command
            //	-> Grab Image using GrabImageAsync
            //	-> Image Display

            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;
            if (!_isOpen) return;
            try
            {
                // Change Acqusition Mode
                status = _virtualFG40.SetEnumReg(_hDevice, VirtualFG40Library.MCAM_ACQUISITION_MODE, VirtualFG40Library.ACQUISITION_MODE_CONTINUOUS);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Write Register failed : {0}", status));
                }

                // Acqusition Start
                status = _virtualFG40.AcqStart(_hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Acqusition Start failed : {0}", status));
                }
                _isRun = true;
                // GrabStartAsync
                _virtualFG40.GrabStartAsync(_hDevice, 0xFFFFFFFF);

                // Acqusution Loop Function
                //timer_Grab.Enabled = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Acq" + ex.ToString());
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
                return;
            }

        }

        public void AcqusitionStop()
        {
            // 1. Thread suspend or Timer Stop
            // 2. Excute Acqusition Stop Command 

            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;

            try
            {
                //timer_Grab.Enabled = false;

                // Acqusition Stop
                status = _virtualFG40.AcqStop(_hDevice);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Acqusition Start failed : {0}", status));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Stop" + ex.ToString());
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
                return;
            }
        }

        public void Run()
        { }

        public void ShowControlDialog()
        {
            throw new NotImplementedException();
        }

        public float Getfps()
        {
            throw new NotImplementedException();
        }
        public int GetConnectedCamCount()
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;
            UInt32 camNum = 0;

            try
            {
                // Update Device List
                status = _virtualFG40.UpdateDevice();
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    _virtualFG40.FreeSystem();
                    throw new Exception(String.Format("Update Device list failed : {0}", status));
                }

                status = _virtualFG40.GetAvailableCameraNum(ref camNum);
                return (int)camNum;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
                return 0;
            }
        }

        int CamNumber = 0;
        public string GetCameraSeiralNo()
        {
            return GetCameraSeiralNo(CamNumber);
        }
        public string GetCameraSeiralNo(int camNumber)
        {
            Int32 status = VirtualFG40Library.MCAM_ERR_SUCCESS;
            UInt32 size = 0;
            Byte[] pInfo;
            string modelName;

            try
            {
                // Device Model Name
                status = _virtualFG40.GetStrReg(_hDevice, VirtualFG40Library.MCAM_DEVICE_MODEL_NAME, null, ref size);
                if (status != VirtualFG40Library.MCAM_ERR_SUCCESS)
                {
                    throw new Exception(String.Format("Read Register failed : {0}", status));
                }
                pInfo = new Byte[size];
                _virtualFG40.GetStrReg(_hDevice, VirtualFG40Library.MCAM_DEVICE_MODEL_NAME, pInfo, ref size);
                modelName = Encoding.Default.GetString(pInfo);
                return modelName;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[Interface] " + ex.Message);
                return null;
            }
        }
        #region IDisposable Support

        private bool disposedValue = false; // 중복 호출을 검색하려면

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 관리되는 상태(관리되는 개체)를 삭제합니다.
                    CameraClose();
                }

                // TODO: 관리되지 않는 리소스(관리되지 않는 개체)를 해제하고 아래의 종료자를 재정의합니다.
                // TODO: 큰 필드를 null로 설정합니다.

                disposedValue = true;
            }
        }

        // TODO: 위의 Dispose(bool disposing)에 관리되지 않는 리소스를 해제하는 코드가 포함되어 있는 경우에만 종료자를 재정의합니다.
        // ~GigE_IMITech() {
        //   // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
        //   Dispose(false);
        // }

        // 삭제 가능한 패턴을 올바르게 구현하기 위해 추가된 코드입니다.
        public void Dispose()
        {
            // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
            Dispose(true);
            // TODO: 위의 종료자가 재정의된 경우 다음 코드 줄의 주석 처리를 제거합니다.
            // GC.SuppressFinalize(this);
        }

        #endregion

        public bool FlushBuffer()
        {
            return true;
        }

        public float ExposureTime
        {
            get
            {
                return mExposureTime;
            }
            set
            {
                if (mExposureTime == value) return;
                mExposureTime = value;
                //Cam.setStreamGrabber.UserData[.["ExposureTime"] = value;
            }
        }
        float mExposureTime;

        public float GainTime
        {
            get
            {
                return mGainTime;
            }
            set
            {
                if (mGainTime == value) return;
                mGainTime = value;
            }
        }
        float mGainTime;

        public int BeforeGrabDelay { get; set; }
        int mBeforeGrabDelay;
    }
}
