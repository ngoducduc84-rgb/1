﻿// Basler Camera
using Basler.Pylon;
using DirectShowLib;
using FlyCapture2Managed;
using MVSDK_Net;

// OpenCv Processing
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
// System Thread
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using SDImage = System.Drawing.Image;

namespace MvCore.CameraDevice
{
    //public delegate void grabImageHandl(Mat image);

    public class GigE_MvView : ICamDevice
    {

        //public static grabImageHandl eventGrapImage;
        [DllImport("kernel32.dll", EntryPoint = "RtlMoveMemory", SetLastError = false)]
        private static extern void CopyMemory(IntPtr dest, IntPtr src, uint count);

        //public MyCamera Cam;
        //MyCamera.MV_CC_DEVICE_INFO_LIST m_stDeviceList = new MyCamera.MV_CC_DEVICE_INFO_LIST();
        Mat m_Image;
        private  Object BufForDriverLock = new Object();
        bool isHwTrigger = false;
        public bool IsHwTrigger
        {
            get { return isHwTrigger; }
            set
            {
                isHwTrigger = value;
                if (cam != null)
                {
                    if (isHwTrigger)
                    {
                        //Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_SOFTWARE);
                    }
                    else
                    {
                        //Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_LINE0);
                    }
                }
            }
        }

        bool isLive = false;
        public bool IsLive
        {
            get { return isLive; }
            set
            {
                isLive = value;
                if (cam != null)
                {
                    if (isLive == true)
                    {
                        //Cam.MV_CC_SetEnumValue_NET("TriggerMode", (uint)MyCamera.MV_CAM_TRIGGER_MODE.MV_TRIGGER_MODE_OFF);
                    }
                    else
                    {
                        //Cam.MV_CC_SetEnumValue_NET("TriggerMode", (uint)MyCamera.MV_CAM_TRIGGER_MODE.MV_TRIGGER_MODE_ON);
                        if (isHwTrigger)
                        {
                            //Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_SOFTWARE);
                        }
                        else
                        {
                            //Cam.MV_CC_SetEnumValue_NET("TriggerSource", (uint)MyCamera.MV_CAM_TRIGGER_SOURCE.MV_TRIGGER_SOURCE_LINE0);
                        }
                    }
                }
            }
        }

        private int camIndex;
        public int CamIndex
        {
            get { return camIndex; }
            set { camIndex = value; }
        }

        private IntPtr handlPicShow;

        public IntPtr HandlPicShow
        {
            get { return handlPicShow; }
            set
            {
                handlPicShow = value;
                displayHandle = handlPicShow;
            }
        }

        bool IsGrabSuccess = false;
        bool IsGrabFail = false;

        object mLock = new object();

        //static List<MyCamera.MV_CC_DEVICE_INFO> Caminfolist = new List<MyCamera.MV_CC_DEVICE_INFO>();
        //static MyCamera.MV_CC_DEVICE_INFO_LIST Camlist;
        List<string> listDeviceName = new List<string>();
        List<IMVDefine.IMV_DeviceInfo> ListDevices = new List<IMVDefine.IMV_DeviceInfo>();
        System.Diagnostics.Stopwatch stopWatch = new System.Diagnostics.Stopwatch();

        //bool m_bGrabbing = false;
        //Thread m_hReceiveThread = null;
        //System.Drawing.Imaging.PixelFormat m_bitmapPixelFormat = System.Drawing.Imaging.PixelFormat.DontCare;
        //IntPtr m_ConvertDstBuf = IntPtr.Zero;
        //UInt32 m_nConvertDstBufLen = 0;
        IntPtr displayHandle = IntPtr.Zero;
        //MyCamera.MV_FRAME_OUT_INFO_EX m_stFrameInfo = new MyCamera.MV_FRAME_OUT_INFO_EX();
        Bitmap m_bitmap = null;

        //// ch:用于从驱动获取图像的缓存 | en:Buffer for getting image from driver
        //UInt32 m_nBufSizeForDriver = 0;
        //IntPtr m_BufForDriver = IntPtr.Zero;
        ////bool grabLock = false;

        public GigE_MvView()
        {
            //// ch: 初始化 SDK | en: Initialize SDK
            //MyCamera.MV_CC_Initialize_NET();

            // ch: 枚举设备 | en: Enum Device List
            //DeviceListAcq();
           
            btnEnumDevices_Click();
            IntPtr _pictureBox = new IntPtr();
            m_Render = new Render(_pictureBox);
            
            //Console.WriteLine(typeof(OpenCvSharp.CvMat).Assembly.FullName);
        }

        public  Mat BitmapToMat(Bitmap bitmap)
        {
            // Xác định kiểu Mat tương ứng
            MatType matType;
            switch (bitmap.PixelFormat)
            {
                case System.Drawing.Imaging.PixelFormat.Format24bppRgb:
                    matType = MatType.CV_8UC3;
                    break;
                case System.Drawing.Imaging.PixelFormat.Format32bppArgb:
                case System.Drawing.Imaging.PixelFormat.Format32bppRgb:
                    matType = MatType.CV_8UC4;
                    break;
                case System.Drawing.Imaging.PixelFormat.Format8bppIndexed:
                    matType = MatType.CV_8UC1; // ảnh grayscale
                    break;
                default:
                    throw new Exception("Unsupported PixelFormat: " + bitmap.PixelFormat);
            }

            // Tạo Mat rỗng
            Mat mat = new Mat(bitmap.Height, bitmap.Width, matType);

            // Khóa vùng nhớ Bitmap
            BitmapData bmpData = bitmap.LockBits(
                new Rectangle(0, 0, bitmap.Width, bitmap.Height),
                ImageLockMode.ReadOnly,
                bitmap.PixelFormat);

            // Sao chép từng dòng để đảm bảo không lỗi stride
            IntPtr srcPtr = bmpData.Scan0;
            int srcStride = bmpData.Stride;

            int bytesPerPixel = SDImage.GetPixelFormatSize(bitmap.PixelFormat) / 8;

            unsafe
            {
                byte* src = (byte*)bmpData.Scan0;
                for (int y = 0; y < bitmap.Height; y++)
                {
                    byte* srcRow = src + y * bmpData.Stride;
                    byte* dstRow = (byte*)mat.Ptr(y);
                    Buffer.MemoryCopy(srcRow, dstRow, bitmap.Width * bytesPerPixel, bitmap.Width * bytesPerPixel);
                }
            }

            bitmap.UnlockBits(bmpData);

            return mat;
        }

        public  Mat Bitmap2Mat(Bitmap bitmap)
        {
            // Khóa vùng nhớ ảnh
            Rectangle rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
            BitmapData bitmapData = bitmap.LockBits(rect, ImageLockMode.ReadOnly, bitmap.PixelFormat);

            // Tạo Mat tương ứng
            Mat mat;
            if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format8bppIndexed)
            {
                mat = new Mat(bitmap.Height, bitmap.Width, MatType.CV_8UC1);
            }
            else if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format24bppRgb)
            {
                mat = new Mat(bitmap.Height, bitmap.Width, MatType.CV_8UC3);
            }
            else if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format32bppArgb ||
                     bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format32bppRgb)
            {
                mat = new Mat(bitmap.Height, bitmap.Width, MatType.CV_8UC4);
            }
            else
            {
                bitmap.UnlockBits(bitmapData);
                throw new Exception($"Unsupported PixelFormat: {bitmap.PixelFormat}");
            }

            // Copy pixel từ Bitmap sang Mat
            int bytes = Math.Abs(bitmapData.Stride) * bitmap.Height;
            byte[] buffer = new byte[bytes];
            Marshal.Copy(bitmapData.Scan0, buffer, 0, bytes);

            // Ghi dữ liệu vào Mat (đúng cách)
            Marshal.Copy(buffer, 0, mat.Data, bytes);


            bitmap.UnlockBits(bitmapData);

            // Một số Bitmap lưu RGB, còn OpenCV dùng BGR → cần đảo kênh
            if (bitmap.PixelFormat == System.Drawing.Imaging.PixelFormat.Format24bppRgb)
            {
                Cv2.CvtColor(mat, mat, ColorConversion.RgbaToBgr);
                //Cv2.CvtColor(mat, mat,ColorConversionCodes.RGBA2BGR);
            }

            return mat;
        }



        public void AcqusitionStart()
        {
            //StartGrab();
            //Cam.StreamGrabber.Start(GrabStrategy.OneByOne, GrabLoop.ProvidedByStreamGrabber);

            //// Execute the software trigger. Wait up to 100 ms until the camera is ready for trigger.
            //if (Cam.WaitForFrameTriggerReady(100, TimeoutHandling.ThrowException))
            //{
            //    Cam.ExecuteSoftwareTrigger();
            //}
        }

        public void AcqusitionStop()
        {
            btnClose_Click();
            //closeDevice();
            //Cam.StreamGrabber.Stop();
        }

        public void CameraClose()
        {
            radioContinue_CheckedChanged();// sửa lỗi không mở được camera trên phần mềm khác (không có ảnh)
            btnClose_Click();
            cam = null;

        }

        public void CameraOpen(int camNumber)
        {
            if (cam == null)
            {
                cam = new MyCamera();
                if (btnOpen_Click(camNumber))
                {
                    chbSoftTrigger_CheckedChanged(true);
                    radioTrigger_CheckedChanged(true);
                    btnStart_Click();
                }
            }
        }

        public void Run()
        {
            //if (Cam == null)
            //{
            //    openDevice(camIndex);
            //    StartGrab();
            //}else if (isLive == false && IsHwTrigger == true)
            //{
            //    //GrabImage();
            //}
        }

        //public string GetCameraSeiralNo()
        //{
        //    return GetCameraSeiralNo(CamIndex);
        //}

        //public string GetCameraSeiralNo(int camNumber)
        //{
        //    if (camNumber < 0 || camNumber > Caminfolist.Count - 1) return null;
        //    if (Caminfolist == null) return null;
        //    if (Caminfolist.Count <= camNumber) return null;
        //    //selectDevice(camNumber);
        //    return l_device[camNumber];
        //}

        //private void Cam_ConnectionLost(object sender, EventArgs e)
        //{
        //    CameraClose();
        //    Thread.Sleep(100);
        //    //CameraOpen(CamIndex);
        //}

        public int GetConnectedCamCount()
        {
            return listDeviceName.Count;
        }

        void OnImageGrabbed(Object sender, ImageGrabbedEventArgs e)
        {
            try
            {
                // Get the grab result.
                IGrabResult grabResult = e.GrabResult;

                // Check if the image can be displayed.
                if (grabResult.IsValid)
                {
                    byte[] buffer = grabResult.PixelData as byte[];
                    m_Image = new Mat((int)grabResult.Height, (int)grabResult.Width, MatType.CV_8UC1, /*(Array)*/grabResult.PixelData as byte[]);
                    //m_Image = new Mat((int)grabResult.Height, (int)grabResult.Width, MatType.CV_8UC1);
                    //m_Image.SetArray(grabResult.PixelData as byte[]);
                    IsGrabSuccess = true;
                }
            }
            catch (Exception exception)
            {
                IsGrabFail = true;
                //ShowException(exception);
            }
            finally
            {
                // Dispose the grab result if needed for returning it to the grab loop.
                e.DisposeGrabResultIfClone();
            }
        }

        public float ExposureTime
        {
            get
            {
                if (cam == null) return -1;
                double exposureTime = 0;
                int res = cam.IMV_GetDoubleFeatureValue("ExposureTime", ref exposureTime);
                if (IMVDefine.IMV_OK != res)
                {
                    MessageBox.Show("get exposuretime failed!");
                    return -1;
                }
                return (float)exposureTime;
            }
            set
            {

                if (cam == null || mExposureTime == value) return;
                mExposureTime = value;
                double maxexposuretime = 0;
                double minexposuretime = 0;
                int res = cam.IMV_GetDoubleFeatureMin("ExposureTime", ref minexposuretime);
                if (res != IMVDefine.IMV_OK)
                {
                    MessageBox.Show(string.Format("Get feature minimum exposuretime failed! ErrorCode[{0}]", res));
                    return;
                }
                res = cam.IMV_GetDoubleFeatureMax("ExposureTime", ref maxexposuretime);
                if (res != IMVDefine.IMV_OK)
                {
                    Console.WriteLine(string.Format("Get feature maximum exposuretime failed! ErrorCode[{0}]", res));
                    return;
                }
                if (mExposureTime < minexposuretime || mExposureTime > maxexposuretime)
                {
                    MessageBox.Show(string.Format("Exposuretime is not valid,the max value is {0} ,the min value is {1}",
                        maxexposuretime, minexposuretime));
                    return;
                }



                //Cam.setStreamGrabber.UserData[.["ExposureTime"] = value;
            }
        }
        float mExposureTime;

        public float GainTime
        {
            get
            {
                if (cam == null) return -1;
                double gain = 0;
                int res = cam.IMV_GetDoubleFeatureValue("GainRaw", ref gain);
                if (IMVDefine.IMV_OK != res)
                {
                    MessageBox.Show("get gainraw failed!");
                    return -1;
                }
                return (float)gain;
            }
            set
            {
                if (cam == null || mGainTime == value) return;
                mGainTime = value;
                double maxgain = 0;
                double mingain = 0;
                int res = cam.IMV_GetDoubleFeatureMin("GainRaw", ref mingain);
                if (res != IMVDefine.IMV_OK)
                {
                    MessageBox.Show(string.Format("Get feature minimum gainraw failed! ErrorCode[{0}]", res));
                    return;
                }
                res = cam.IMV_GetDoubleFeatureMax("GainRaw", ref maxgain);
                if (res != IMVDefine.IMV_OK)
                {
                    Console.WriteLine(string.Format("Get feature maximum gainraw failed! ErrorCode[{0}]", res));
                    return;
                }
                if (mGainTime < mingain || mGainTime > maxgain)
                {
                    MessageBox.Show(string.Format("Gain is not valid,the max value is {0} ,the min value is {1}", maxgain,
                        mingain));
                    return;
                }

            }
        }
        float mGainTime;


        public int BeforeGrabDelay { get; set; }
        int mBeforeGrabDelay;

        public Mat QueryFrame()
        {
            throw new NotImplementedException();
        }

        public void ShowControlDialog()
        {
            throw new NotImplementedException();
        }

        public float Getfps()
        {
            throw new NotImplementedException();
        }

        protected virtual void Dispose(bool disposing)
        {
            //if (Cam == null) return;
            //if (Cam.IsOpen) Cam.Close();
            //Cam.Dispose();
        }

        public void Dispose()
        {
            // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
            Dispose(true);
            // TODO: 위의 종료자가 재정의된 경우 다음 코드 줄의 주석 처리를 제거합니다.
            // GC.SuppressFinalize(this);
        }

        public Mat GrabImage()
        {
            lock (mLock)
            {
                try
                {
                    if (cam == null) return null;

                    // Delay
                    DateTime startTime = DateTime.Now;
                    while (DateTime.Now.Subtract(startTime).TotalMilliseconds < BeforeGrabDelay)
                    {
                        System.Threading.Thread.Sleep(1);
                    }

                    IsGrabFail = false;
                    IsGrabSuccess = false;

                    //if (Cam.StreamGrabber.IsGrabbing)
                    //{
                    //    Cam.StreamGrabber.Stop();
                    //    Thread.Sleep(500);
                    //}
                    //Cam.Parameters[PLCamera.AcquisitionMode].SetValue(PLCamera.AcquisitionMode.SingleFrame);
                    //Cam.StreamGrabber.Start(1, GrabStrategy.LatestImages, GrabLoop.ProvidedByStreamGrabber);
                    //if (isLive == false)
                    //{

                    btnSoftware_Click();
                    //IsGrabSuccess = true;
                    //}
                    stopWatch.Reset();
                    stopWatch.Start();
                    while (true)
                    {
                        //while (grapLock == false)
                        //{
                        //    Thread.Sleep(10);
                        //    if (stopWatch.ElapsedMilliseconds > 2000) return null;
                        //}
                        if (IsGrabSuccess)
                        {
                            lock (BufForDriverLock)
                            {
                                return m_Image; // daviddang 
                            }
                        }

                        if (IsGrabFail) break;
                        if (stopWatch.ElapsedMilliseconds > 2000) break;
                        Thread.Sleep(10);
                    }
                    // Error 처리 추가할 것
                    return null;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    return null;
                }
            }
        }
       
        public bool FlushBuffer()
        {
            return true;
        }
        

        /********************************** MvView Camera*************************************/

        private MyCamera cam ; // 设备对象 | device object
        private Render m_Render; // 显示类 | display
        private bool m_bGrabbing = false;
        private Thread m_hReceiveThread = null; //取流线程 | get frame thread
        private IntPtr m_pDstData;              //转码缓存 | Transcoding cache
        private int m_nDstDataSize = 0;
        private string m_binSavePath = Environment.CurrentDirectory + @"\Bins";
        private string m_bitMapSavePath = Environment.CurrentDirectory + @"\BitMaps";
        private IntPtr m_pBufForCache = IntPtr.Zero; //源数据缓存，用于保存图片 | Source data cache, used to save images
        private UInt32 m_nBufSizeForCache = 0;
        private IMVDefine.IMV_FrameInfo frameInfo = new IMVDefine.IMV_FrameInfo();
        private  object m_bufferLock = new object();
        List<string> PixelType = new List<string>();
        [DllImport("kernel32.dll", EntryPoint = "CopyMemory", SetLastError = false)]
        public static extern void CopyMemory(IntPtr dest, IntPtr src, int count);




         bool ConvertToMat(ref IMVDefine.IMV_Frame frame, ref Mat mat)
        {

            if (frame.frameInfo.pixelFormat == IMVDefine.IMV_EPixelType.gvspPixelMono8)
            {
                mat = new Mat((int)frame.frameInfo.height, (int)frame.frameInfo.width, MatType.CV_8UC1, frame.pData);
            }
            else if (frame.frameInfo.pixelFormat == IMVDefine.IMV_EPixelType.gvspPixelBGR8)
            {
                //mat = new Mat.FromPixelData((int)frame.frameInfo.height, (int)frame.frameInfo.width, MatType.CV_8UC3, frame.pData);
                mat = new Mat((int)frame.frameInfo.height, (int)frame.frameInfo.width, MatType.CV_8UC3, frame.pData);
            }
            // 其他彩色需要先转成BGR8
            // Other colors need to be converted to BGR8 first
            else
            {

                IntPtr pDstBuf = IntPtr.Zero;
                pDstBuf = Marshal.AllocHGlobal((int)frame.frameInfo.width * (int)frame.frameInfo.height * 3);
                IMVDefine.IMV_PixelConvertParam stPixelConvertParam = new IMVDefine.IMV_PixelConvertParam();
                stPixelConvertParam.nWidth = frame.frameInfo.width;
                stPixelConvertParam.nHeight = frame.frameInfo.height;
                stPixelConvertParam.ePixelFormat = frame.frameInfo.pixelFormat;
                stPixelConvertParam.pSrcData = frame.pData;
                stPixelConvertParam.nSrcDataLen = frame.frameInfo.size;
                stPixelConvertParam.nPaddingX = frame.frameInfo.paddingX;
                stPixelConvertParam.nPaddingY = frame.frameInfo.paddingY;
                stPixelConvertParam.eBayerDemosaic = IMVDefine.IMV_EBayerDemosaic.demosaicNearestNeighbor;
                stPixelConvertParam.eDstPixelFormat = IMVDefine.IMV_EPixelType.gvspPixelBGR8;
                stPixelConvertParam.pDstBuf = pDstBuf;
                stPixelConvertParam.nDstBufSize = frame.frameInfo.width * frame.frameInfo.height * 3;
                MyCamera _cam = new MyCamera();
                int res = _cam.IMV_PixelConvert(ref stPixelConvertParam);
                if (res == IMVDefine.IMV_OK)
                {
                    // Console.WriteLine("image convert to BGR successfully!");
                    mat = new Mat((int)frame.frameInfo.height, (int)frame.frameInfo.width, MatType.CV_8UC3, pDstBuf);
                }
                else
                {
                    Console.WriteLine("image convert to BGR fail!");
                    return false;
                }
            }

            //mat.ImWrite("Mat.bmp");
            //mat.Release();
            //Console.WriteLine("convert to mat success");
            return true;
        }

        public void ReceiveThreadProcess()
        {
            IMVDefine.IMV_Frame frame = new IMVDefine.IMV_Frame();
            while (m_bGrabbing)
            {
                Console.WriteLine($"Receive Thread Process runing {camIndex}...");
                if (cam != null && (IMVDefine.IMV_OK == cam.IMV_GetFrame(ref frame, 1000)))
                {
                    try
                    {
                        lock (m_bufferLock)
                        {
                            if (m_pBufForCache == IntPtr.Zero || frame.frameInfo.size > m_nBufSizeForCache)
                            {
                                if (m_pBufForCache != IntPtr.Zero)
                                {
                                    Marshal.FreeHGlobal(m_pBufForCache);
                                    m_pBufForCache = IntPtr.Zero;
                                }

                                m_pBufForCache = Marshal.AllocHGlobal((Int32)frame.frameInfo.size);
                                if (m_pBufForCache == IntPtr.Zero)
                                {
                                    return;
                                }
                                m_nBufSizeForCache = frame.frameInfo.size;
                            }
                            frameInfo = frame.frameInfo;
                            CopyMemory(m_pBufForCache, frame.pData, (int)frame.frameInfo.size);


                            if (frame.frameInfo.pixelFormat == IMVDefine.IMV_EPixelType.gvspPixelMono8)
                            {
                                m_Render.Display(frame.pData, (int)frame.frameInfo.width, (int)frame.frameInfo.height,
                                    Render.VR_PIXEL_TYPE_E.VR_PIXEL_FMT_MONO8);
                                Mat src = new Mat();
                                ConvertToMat(ref frame, ref src);
                                m_Image = src.Clone();
                                IsGrabSuccess = true;
                            }
                            else if (frame.frameInfo.pixelFormat == IMVDefine.IMV_EPixelType.gvspPixelBGR8)
                            {
                                m_Render.Display(frame.pData, (int)frame.frameInfo.width, (int)frame.frameInfo.height,
                                    Render.VR_PIXEL_TYPE_E.VR_PIXEL_FMT_RGB24);
                                Mat src = new Mat();
                                ConvertToMat(ref frame, ref src);
                                m_Image = src.Clone();
                                IsGrabSuccess = true;
                            }
                            else
                            {
                                // 图像转码为BGR格式 
                                // raw frame data converted to BGR 
                                if (true == ConvertToBGR24(frame)) //转码成功显示图像
                                {
                                    m_Render.Display(m_pDstData, (int)frame.frameInfo.width, (int)frame.frameInfo.height,
                                        Render.VR_PIXEL_TYPE_E.VR_PIXEL_FMT_RGB24);
                                    Mat src = new Mat();
                                    ConvertToMat(ref frame, ref src);
                                    m_Image = src.Clone();
                                    IsGrabSuccess = true;
                                }
                            }
                            //Cv2.ImShow("img", m_Image);
                            //Cv2.WaitKey(1000);
                        }
                    }
                    catch (Exception exception)
                    {
                        MessageBox.Show(exception.ToString());
                    }
                    finally
                    {
                        // 必须主动释放驱动缓存
                        // Must actively release the driver cache
                        cam.IMV_ReleaseFrame(ref frame);
                    }
                }
            }
        }


        //openDevice
        private bool btnOpen_Click(int camnumber)
        {
            try
            {
                if (listDeviceName.Count > 0)
                {
                    // 创建设备句柄
                    // Create Device Handle
                    int res = cam.IMV_CreateHandle(IMVDefine.IMV_ECreateHandleMode.modeByIndex, camnumber);

                    // 打开设备 
                    // open device 
                    res = cam.IMV_Open();
                    if (res != IMVDefine.IMV_OK)
                    {
                        MessageBox.Show("Open camera failed");
                        return false;
                    }

                    //cbPixelType.Items.Clear();
                    //cbPixelType.Text = string.Empty;

                    // 获取所有可以设置的像素格式 
                    // get all Image Pixel Format
                    uint nEntryNum = 0;
                    IMVDefine.IMV_EnumEntryList pixelTypeList = new IMVDefine.IMV_EnumEntryList();
                    res = cam.IMV_GetEnumFeatureEntryNum("PixelFormat", ref nEntryNum);
                    if (res != IMVDefine.IMV_OK)
                    {
                        MessageBox.Show(string.Format("Get settable enumeration number failed! ErrorCode[{0}]", res));
                        return false;
                    }

                    pixelTypeList.nEnumEntryBufferSize = (uint)Marshal.SizeOf(typeof(IMVDefine.IMV_EnumEntryInfo)) *
                                                         nEntryNum;
                    pixelTypeList.pEnumEntryInfo = Marshal.AllocHGlobal((int)pixelTypeList.nEnumEntryBufferSize);
                    if (pixelTypeList.pEnumEntryInfo == IntPtr.Zero)
                    {
                        MessageBox.Show("pEnumEntryInfo is NULL");
                        return false;
                    }

                    res = cam.IMV_GetEnumFeatureEntrys("PixelFormat", ref pixelTypeList);
                    if (res != IMVDefine.IMV_OK)
                    {
                        MessageBox.Show("get all Image Pixel Format failed");
                        return false;
                    }
                    for (int i = 0; i < nEntryNum; i++)
                    {
                        IMVDefine.IMV_EnumEntryInfo entryInfo =
                            (IMVDefine.IMV_EnumEntryInfo)
                                Marshal.PtrToStructure(
                                    pixelTypeList.pEnumEntryInfo +
                                    Marshal.SizeOf(typeof(IMVDefine.IMV_EnumEntryInfo)) * i,
                                    typeof(IMVDefine.IMV_EnumEntryInfo));
                        PixelType.Add(entryInfo.name);
                    }

                    if (pixelTypeList.pEnumEntryInfo != IntPtr.Zero)
                    {
                        Marshal.FreeHGlobal(pixelTypeList.pEnumEntryInfo);
                        pixelTypeList.pEnumEntryInfo = IntPtr.Zero;
                    }

                    ////获取当前相机的触发源
                    ////get Trigger Source
                    //IMVDefine.IMV_String triggerSourcce = new IMVDefine.IMV_String();
                    //res = cam.IMV_GetEnumFeatureSymbol("TriggerSource", ref triggerSourcce);
                    //if (res != IMVDefine.IMV_OK)
                    //{
                    //    MessageBox.Show("get TriggerSource failed");
                    //    return;
                    //}
                    //if (triggerSourcce.str == "Software")
                    //{
                    //    chbSoftTrigger_CheckedChanged(true);
                    //}
                    //else
                    //{
                    //    chbSoftTrigger_CheckedChanged(false);
                    //}

                    ////获取当前相机的触发模式
                    ////get Trigger Mode
                    //IMVDefine.IMV_String triggerMode = new IMVDefine.IMV_String();
                    //res = cam.IMV_GetEnumFeatureSymbol("TriggerMode", ref triggerMode);
                    //if (res != IMVDefine.IMV_OK)
                    //{
                    //    MessageBox.Show("get TriggerMode failed");
                    //    return;
                    //}
                    //if (triggerMode.str == "Off")
                    //{
                    //    radioContinue_CheckedChanged();
                    //}
                    //else
                    //{
                    //    radioTrigger_CheckedChanged(true);
                    //}

                    // 获取当前相机的参数
                    // get Parameters
                    double _ExposureTime, _GainTime;
                    getParam(out _ExposureTime, out _GainTime);
                    ExposureTime = (float)_ExposureTime;
                    GainTime = (float)_GainTime;
                    // 设置缓存个数为8（默认值为16） 
                    // set buffer count to 8 (default 16) 
                    res = cam.IMV_SetBufferCount(8);
                    return true;
                }
                return false;
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.ToString());
                return false;
            }
        }


        //Close Device
        private void btnClose_Click()
        {
            try
            {
                if (cam != null)
                {
                    if (true == cam.IMV_IsGrabbing())
                    {
                        btnStop_Click(null, null);
                    }
                    cam.IMV_Close(); // 关闭相机 | close camera 
                    cam.IMV_DestroyHandle();

                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.ToString());
            }
        }

        // 窗口关闭 
        // Window Closed 
        protected void OnClosed()
        {
            if (true == cam.IMV_IsOpen())
            {
                btnClose_Click();
            }
            m_Render.Close();
            m_Render = null;

            if (m_pDstData != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(m_pDstData);
                m_pDstData = IntPtr.Zero;
            }

            if (m_pBufForCache != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(m_pBufForCache);
                m_pBufForCache = IntPtr.Zero;
            }
        }
        //Seach
        private void btnEnumDevices_Click()
        {
            listDeviceName.Clear();

            // 设备搜索 
            // device search 
            IMVDefine.IMV_DeviceList deviceList = new IMVDefine.IMV_DeviceList();
            IMVDefine.IMV_EInterfaceType interfaceTp = IMVDefine.IMV_EInterfaceType.interfaceTypeAll;
            int res = MyCamera.IMV_EnumDevices(ref deviceList, (uint)interfaceTp);

            // 添加设备信息
            // Add device info
            if (res == IMVDefine.IMV_OK && deviceList.nDevNum > 0)
            {
                for (int i = 0; i < deviceList.nDevNum; i++)
                {
                    IMVDefine.IMV_DeviceInfo deviceInfo =
                        (IMVDefine.IMV_DeviceInfo)
                            Marshal.PtrToStructure(
                                deviceList.pDevInfo + Marshal.SizeOf(typeof(IMVDefine.IMV_DeviceInfo)) * i,
                                typeof(IMVDefine.IMV_DeviceInfo));
                    listDeviceName.Add(deviceInfo.cameraName + "[" + deviceInfo.serialNumber + "]");
                    ListDevices.Add(deviceInfo);
                }
                //选择第一项
                //select the first item
                CamIndex = 0;
            }
            else
            {
                MessageBox.Show("Enumerate devices fail!Please check!");
            }
        }

        //Start
        private void btnStart_Click()
        {
            // 标志位置true 
            // set position bit true
            m_bGrabbing = true;

            m_hReceiveThread = new Thread(ReceiveThreadProcess);
            m_hReceiveThread.Start();

            // 开启码流 
            // start grabbing 
            if (IMVDefine.IMV_OK != cam.IMV_StartGrabbing())
            {
                m_bGrabbing = false;
                m_hReceiveThread.Join();
                MessageBox.Show("Start grabbing failed");
                return;
            }
        }


        //Stop
        private void btnStop_Click(object sender, EventArgs e)
        {
            // 标志位置为false
            // set position bit false
            m_bGrabbing = false;
            m_hReceiveThread.Join();

            // 停止码流 
            // stop grabbing
            if (IMVDefine.IMV_OK != cam.IMV_StopGrabbing())
            {
                MessageBox.Show("Stop Grabbing Fail!");
            }
        }

        //软触发一次
        //Software Trigger
        private void btnSoftware_Click()
        {
            if (cam.IMV_IsGrabbing())
            {
                //发送一次触发命令
                //Send Trigger Command
                int res = IMVDefine.IMV_OK;
                res = cam.IMV_ExecuteCommandFeature("TriggerSoftware");
                if (IMVDefine.IMV_OK != res)
                {
                    MessageBox.Show(string.Format("Execute TriggerSoftware failed! ErrorCode[{0}]", res));
                    return;
                }
            }
        }

        private void btnSetParam_Click(double exposure, double gain)
        {
            if (false == cam.IMV_IsOpen())
            {
                MessageBox.Show("Device is not connect!");
                return;
            }

            try
            {
                double.Parse(exposure.ToString());
                double.Parse(gain.ToString());
            }
            catch
            {
                MessageBox.Show("Please enter correct type!");
                return;
            }

            int res = IMVDefine.IMV_OK;
            // 获取可设置曝光值
            // get valid ExposureTime 
            double exposureTime = exposure;
            double maxexposuretime = 0;
            double minexposuretime = 0;
            res = cam.IMV_GetDoubleFeatureMin("ExposureTime", ref minexposuretime);
            if (res != IMVDefine.IMV_OK)
            {
                MessageBox.Show(string.Format("Get feature minimum exposuretime failed! ErrorCode[{0}]", res));
                return;
            }
            res = cam.IMV_GetDoubleFeatureMax("ExposureTime", ref maxexposuretime);
            if (res != IMVDefine.IMV_OK)
            {
                Console.WriteLine(string.Format("Get feature maximum exposuretime failed! ErrorCode[{0}]", res));
                return;
            }
            if (exposureTime < minexposuretime || exposureTime > maxexposuretime)
            {
                MessageBox.Show(string.Format("Exposuretime is not valid,the max value is {0} ,the min value is {1}",
                    maxexposuretime, minexposuretime));
                return;
            }

            // 获取可设置增益 
            // get valid Gain 
            double maxgain = 0;
            double mingain = 0;
            double _gain = gain;
            res = cam.IMV_GetDoubleFeatureMin("GainRaw", ref mingain);
            if (res != IMVDefine.IMV_OK)
            {
                MessageBox.Show(string.Format("Get feature minimum gainraw failed! ErrorCode[{0}]", res));
                return;
            }
            res = cam.IMV_GetDoubleFeatureMax("GainRaw", ref maxgain);
            if (res != IMVDefine.IMV_OK)
            {
                Console.WriteLine(string.Format("Get feature maximum gainraw failed! ErrorCode[{0}]", res));
                return;
            }
            if (_gain < mingain || _gain > maxgain)
            {
                MessageBox.Show(string.Format("Gain is not valid,the max value is {0} ,the min value is {1}", maxgain,
                    mingain));
                return;
            }


            //设置图像格式
            // set Pixel Type
            if (true == cam.IMV_IsOpen() && false == cam.IMV_IsGrabbing())
            {
                //string pixelType = cbPixelType.Text;
                //res = cam.IMV_SetEnumFeatureSymbol("PixelFormat", pixelType);
                //if (IMVDefine.IMV_OK != res)
                //{
                //    MessageBox.Show("set pixelFormat fail!");
                //}
            }

            // 设置曝光值
            // set ExposureTime 
            res = cam.IMV_SetDoubleFeatureValue("ExposureTime", exposureTime);
            if (IMVDefine.IMV_OK != res)
            {
                MessageBox.Show("set exposuretime fail!");
            }

            // 设置增益 
            // set Gain 
            res = cam.IMV_SetDoubleFeatureValue("GainRaw", _gain);
            if (IMVDefine.IMV_OK != res)
            {
                MessageBox.Show("set gain fail!");
            }
        }

        //转码函数
        //transcoding function
        private bool ConvertToBGR24(IMVDefine.IMV_Frame frame)
        {
            IMVDefine.IMV_PixelConvertParam stPixelConvertParam = new IMVDefine.IMV_PixelConvertParam();

            //当内存申请失败，返回false
            try
            {
                if (m_pDstData == IntPtr.Zero || (int)(frame.frameInfo.width * frame.frameInfo.height * 3) > m_nDstDataSize)
                {
                    if (m_pDstData != IntPtr.Zero)
                    {
                        Marshal.FreeHGlobal(m_pDstData);
                    }
                    m_pDstData = Marshal.AllocHGlobal((int)(frame.frameInfo.width * frame.frameInfo.height * 3));
                    m_nDstDataSize = (int)(frame.frameInfo.width * frame.frameInfo.height * 3);
                }
            }
            catch
            {
                return false;
            }

            // 图像转换成BGR8
            // convert image to BGR8
            stPixelConvertParam.nWidth = frame.frameInfo.width;
            stPixelConvertParam.nHeight = frame.frameInfo.height;
            stPixelConvertParam.ePixelFormat = frame.frameInfo.pixelFormat;
            stPixelConvertParam.pSrcData = frame.pData;
            stPixelConvertParam.nSrcDataLen = frame.frameInfo.size;
            stPixelConvertParam.nPaddingX = frame.frameInfo.paddingX;
            stPixelConvertParam.nPaddingY = frame.frameInfo.paddingY;
            stPixelConvertParam.eBayerDemosaic = IMVDefine.IMV_EBayerDemosaic.demosaicBilinear;
            stPixelConvertParam.eDstPixelFormat = IMVDefine.IMV_EPixelType.gvspPixelBGR8;
            stPixelConvertParam.pDstBuf = m_pDstData;
            stPixelConvertParam.nDstBufSize = (uint)m_nDstDataSize;

            int res = cam.IMV_PixelConvert(ref stPixelConvertParam);
            if (res != IMVDefine.IMV_OK)
            {
                // 转码出错,返回false           
                return false;
            }

            return true;
        }

        private bool SaveToBitmap(IntPtr pSrcData)
        {
            Bitmap bitmap = null;
            if (!ConvertToBitmap(pSrcData, ref bitmap))
            {
                return false;
            }

            if (!Directory.Exists(m_bitMapSavePath))
            {
                Directory.CreateDirectory(m_bitMapSavePath);
            }
            try
            {
                string imageName = m_bitMapSavePath + @"\" + frameInfo.blockId + ".bmp";
                bitmap.Save(imageName, ImageFormat.Bmp);
                bitmap.Dispose();
                MessageBox.Show(string.Format("Save bitmap Successfully!Save path is [{0}]", imageName));
            }
            catch (Exception exception)
            {
                if (bitmap != null)
                {
                    bitmap.Dispose();
                }
                MessageBox.Show("Save bitmap Failed,because" + exception.ToString());
                return false;
            }
            return true;
        }

        private bool ConvertToBitmap(IntPtr pSrcData, ref Bitmap bitmap)
        {
            IntPtr pDstRGB;
            BitmapData bmpData;
            Rectangle bitmapRect = new Rectangle();
            int ImgSize;

            if (frameInfo.pixelFormat == IMVDefine.IMV_EPixelType.gvspPixelMono8) //图像格式为Mono8时，无需转码，直接转成bitmap进行保存
            {
                // 用Mono8数据生成Bitmap
                bitmap = new Bitmap((int)frameInfo.width, (int)frameInfo.height, System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                ColorPalette colorPalette = bitmap.Palette;
                for (int i = 0; i != 256; ++i)
                {
                    colorPalette.Entries[i] = Color.FromArgb(i, i, i);
                }
                bitmap.Palette = colorPalette;

                bitmapRect.Height = bitmap.Height;
                bitmapRect.Width = bitmap.Width;
                bmpData = bitmap.LockBits(bitmapRect, ImageLockMode.ReadWrite, bitmap.PixelFormat);
                CopyMemory(bmpData.Scan0, pSrcData, bmpData.Stride * bitmap.Height);
                bitmap.UnlockBits(bmpData);
            }
            else if (frameInfo.pixelFormat == IMVDefine.IMV_EPixelType.gvspPixelBGR8) //图像格式为BGR8时，无需转码，直接转成bitmap进行保存
            {
                // 用BGR24数据生成Bitmap
                bitmap = new Bitmap((int)frameInfo.width, (int)frameInfo.height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

                bitmapRect.Height = bitmap.Height;
                bitmapRect.Width = bitmap.Width;
                bmpData = bitmap.LockBits(bitmapRect, ImageLockMode.ReadWrite, bitmap.PixelFormat);
                CopyMemory(bmpData.Scan0, pSrcData, bmpData.Stride * bitmap.Height);
                bitmap.UnlockBits(bmpData);
            }
            else //当图像格式为其它时，先转码为BGR24，然后转成bitmap进行保存
            {
                ImgSize = (int)frameInfo.width * (int)frameInfo.height * 3;

                try
                {
                    pDstRGB = Marshal.AllocHGlobal(ImgSize);
                }
                catch
                {
                    return false;
                }
                if (pDstRGB == IntPtr.Zero)
                {
                    return false;
                }

                IMVDefine.IMV_PixelConvertParam stPixelConvertParam = new IMVDefine.IMV_PixelConvertParam();
                int res = 0;
                // 转码参数
                stPixelConvertParam.nWidth = frameInfo.width;
                stPixelConvertParam.nHeight = frameInfo.height;
                stPixelConvertParam.ePixelFormat = frameInfo.pixelFormat;
                stPixelConvertParam.pSrcData = pSrcData;
                stPixelConvertParam.nSrcDataLen = frameInfo.size;
                stPixelConvertParam.nPaddingX = frameInfo.paddingX;
                stPixelConvertParam.nPaddingY = frameInfo.paddingY;
                stPixelConvertParam.eBayerDemosaic = IMVDefine.IMV_EBayerDemosaic.demosaicNearestNeighbor;
                stPixelConvertParam.eDstPixelFormat = IMVDefine.IMV_EPixelType.gvspPixelBGR8;
                stPixelConvertParam.pDstBuf = pDstRGB;
                stPixelConvertParam.nDstBufSize = (uint)ImgSize;

                res = cam.IMV_PixelConvert(ref stPixelConvertParam);
                if (IMVDefine.IMV_OK != res)
                {
                    // 转码出错
                    MessageBox.Show("image convert to BGR failed!");
                    return false;
                }

                // 用BGR24数据生成Bitmap
                bitmap = new Bitmap((int)frameInfo.width, (int)frameInfo.height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

                bitmapRect.Height = bitmap.Height;
                bitmapRect.Width = bitmap.Width;
                bmpData = bitmap.LockBits(bitmapRect, ImageLockMode.ReadWrite, bitmap.PixelFormat);
                CopyMemory(bmpData.Scan0, pDstRGB, bmpData.Stride * bitmap.Height);
                bitmap.UnlockBits(bmpData);

                Marshal.FreeHGlobal(pDstRGB);
            }
            return true;
        }

        private bool SaveToBin(IntPtr pSrcData)
        {
            byte[] pBuffer = new byte[frameInfo.size];
            Marshal.Copy(pSrcData, pBuffer, 0, (int)frameInfo.size);
            if (!Directory.Exists(m_binSavePath))
            {
                Directory.CreateDirectory(m_binSavePath);
            }
            try
            {
                string binPath = m_binSavePath + @"\" + frameInfo.blockId + ".bin";
                using (Stream filePath = new FileStream(binPath, FileMode.Create))
                {
                    using (BinaryWriter sw = new BinaryWriter(filePath)) //建立二进制文件流
                    {
                        sw.Write(pBuffer);
                    }
                }
                MessageBox.Show(string.Format("Save bin Successfully!Save path is [{0}]", binPath));
            }
            catch (Exception exception)
            {
                MessageBox.Show("Save bin Failed,because" + exception.ToString());
                return false;
            }
            return true;
        }

        private void btnSaveBMP_Click(object sender, EventArgs e)
        {
            if (false == m_bGrabbing)
            {
                MessageBox.Show("Not Start Grabbing");
                return;
            }

            lock (m_bufferLock)
            {
                if (m_pBufForCache != IntPtr.Zero)
                    SaveToBitmap(m_pBufForCache);
            }

        }

        private void btnSaveBIN_Click(object sender, EventArgs e)
        {
            if (false == m_bGrabbing)
            {
                MessageBox.Show("Not Start Grabbing");
                return;
            }

            lock (m_bufferLock)
            {
                if (m_pBufForCache != IntPtr.Zero)
                    SaveToBin(m_pBufForCache);
            }
        }

        private void getParam(out double exposure, out double gain)
        {
            int res = IMVDefine.IMV_OK;
            //cbPixelType.Text = string.Empty;
            //获取图像格式                   
            IMVDefine.IMV_String pixelType = new IMVDefine.IMV_String();
            res = cam.IMV_GetEnumFeatureSymbol("PixelFormat", ref pixelType);
            if (IMVDefine.IMV_OK != res)
            {
                MessageBox.Show("get image pixle format failed!");
            }
            //cbPixelType.SelectedText = pixelType.str;

            // 获取曝光值
            // set ExposureTime 
            double exposureTime = 0;
            res = cam.IMV_GetDoubleFeatureValue("ExposureTime", ref exposureTime);
            if (IMVDefine.IMV_OK != res)
            {
                MessageBox.Show("get exposuretime failed!");
            }
            //txtExposuretime.Text = exposureTime.ToString("f2");

            // 设置增益 
            // set Gain 
            double _gain = 0;
            res = cam.IMV_GetDoubleFeatureValue("GainRaw", ref _gain);
            if (IMVDefine.IMV_OK != res)
            {
                MessageBox.Show("get gainraw failed!");
            }
            exposure = exposureTime;
            gain = _gain;
            //txtGainRaw.Text = gain.ToString("f2");
        }

        //Continuous mode
        private void radioContinue_CheckedChanged()
        {
            //关闭触发模式
            //Close Trigger Mode
            int res = IMVDefine.IMV_OK;
            res = cam.IMV_SetEnumFeatureSymbol("TriggerMode", "Off");
            if (IMVDefine.IMV_OK != res)
            {
                MessageBox.Show("Set Trigger Mode failed!");
                return;
            }
        }

        private void radioTrigger_CheckedChanged(bool SoftTrigger)
        {

            //打开触发模式
            //Open Trigger Mode
            int res = IMVDefine.IMV_OK;
            res = cam.IMV_SetEnumFeatureSymbol("TriggerMode", "On");
            if (IMVDefine.IMV_OK != res)
            {
                MessageBox.Show("Set Trigger Mode failed!");
                return;
            }

            if (SoftTrigger)
            {
                //设置触发源为软触发
                //Set Trigger Source to Software
                res = cam.IMV_SetEnumFeatureSymbol("TriggerSource", "Software");
                if (IMVDefine.IMV_OK != res)
                {
                    MessageBox.Show("Set Trigger Source failed!");
                    return;
                }


            }
            else
            {
                //设置触发源为Line1
                //Set Trigger Source to Line1
                res = cam.IMV_SetEnumFeatureSymbol("TriggerSource", "Line1");
                if (IMVDefine.IMV_OK != res)
                {
                    MessageBox.Show("Set Trigger Source failed!");
                    return;
                }
            }
        }

        //cbSoftWaveTrigger
        private void chbSoftTrigger_CheckedChanged(bool softTrigger)
        {
            int res = IMVDefine.IMV_OK;
            if (softTrigger)
            {
                //设置触发源为软触发
                //Set Trigger Source to Software
                res = cam.IMV_SetEnumFeatureSymbol("TriggerSource", "Software");
                if (IMVDefine.IMV_OK != res)
                {
                    MessageBox.Show("Set Trigger Source failed!");
                    return;
                }
            }
            else
            {
                //设置触发源为Line1
                //Set Trigger Source to Line1
                res = cam.IMV_SetEnumFeatureSymbol("TriggerSource", "Line1");
                if (IMVDefine.IMV_OK != res)
                {
                    MessageBox.Show("Set Trigger Source failed!");
                    return;
                }

            }
        }

        public string GetCameraSeiralNo()
        {
            return GetCameraSeiralNo(CamIndex);
        }

        public string GetCameraSeiralNo(int camNumber)
        {
            if (camNumber < 0 || camNumber > ListDevices.Count - 1) return null;
            if (ListDevices == null) return null;
            if (ListDevices.Count <= camNumber) return null;
            //selectDevice(camNumber);
            return listDeviceName[camNumber];
        }
    }

}