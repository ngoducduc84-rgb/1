﻿using Basler.Pylon;
using DirectShowLib;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MvCore.CameraDevice
{
    [Serializable]
    public class WebCam : ICamDevice
    {
        static CvCapture cvcapture;
        
        //static OpenCvSharp.VideoCapture Capture;
        Mat m_imgsrc;
        int m_iCamNo;

        static DsDevice[] devs;

        static object AcqusitionLock = new object();

        IFilterGraph2 graphBuilder = new FilterGraph() as IFilterGraph2;
        IBaseFilter capFilter = null;
        IAMCameraControl _camera;
        bool isHwTrigger;
        public bool IsHwTrigger { get { return isHwTrigger; } set { isHwTrigger = value; } }

        bool isLive = false;
        public bool IsLive { get { return isLive; } set { isLive = value; } }

        private int camIndex;
        public int CamIndex
        {
            get { return camIndex; }
            set { camIndex = value; }
        }

        public WebCam()
        {
            devs = DsDevice.GetDevicesOfCat(FilterCategory.VideoInputDevice);
        }

        public Mat QueryFrame()
        {
            lock (AcqusitionLock)
            {
                if (cvcapture == null)
                    return null;

                IplImage aa = cvcapture.QueryFrame();
                if (aa == null) return null;
                m_imgsrc = new Mat(aa, true);
                Cv2.CvtColor(m_imgsrc, m_imgsrc, ColorConversion.BgrToGray);
                return m_imgsrc;
                //if (Capture == null || !Capture.IsOpened())
                //    return null;

                //Mat frame = new Mat();

                //// Lấy frame
                //if (!Capture.Read(frame) || frame.Empty())
                //    return null;

                //// Chuyển sang grayscale
                //Cv2.CvtColor(frame, frame, ColorConversionCodes.BGR2GRAY);

                //return frame;
            }
        }

        public Mat GrabImage()
        {
            // Delay
            DateTime startTime = DateTime.Now;
            while (DateTime.Now.Subtract(startTime).TotalMilliseconds < BeforeGrabDelay)
            {
                System.Threading.Thread.Sleep(1);
            }

            lock (AcqusitionLock)
            {
                if (cvcapture == null || cvcapture.IsDisposed)
                    return null;

                cvcapture.QueryFrame(); //cvcapture는 왠지 모르겠는데 내부적으로 프레임이 두개인듯. 두번 호출해야 최신영상 들어옴...
                IplImage aa = cvcapture.QueryFrame();
                m_imgsrc = new Mat(aa, true);
                Cv2.CvtColor(m_imgsrc, m_imgsrc, ColorConversion.BgrToGray);
                return m_imgsrc;
                //if (Capture == null || !Capture.IsOpened())
                //    return null;
                //Mat frame = new Mat();
                //if (!Capture.Read(frame) || frame.Empty())
                //    return null;
                //// Chuyển sang ảnh xám
                //Cv2.CvtColor(frame, frame, ColorConversionCodes.BGR2GRAY);
                //m_imgsrc = frame;
                //return m_imgsrc;
            }
        }

        public void CameraOpen(int camNumber)
        {
            m_iCamNo = camNumber;


            DsDevice dev = devs[0];

            if (dev == null) return;
            if (graphBuilder != null)
                graphBuilder.AddSourceFilterForMoniker(dev.Mon, null, dev.Name, out capFilter); //getting capture filter for converting it into IAMCameraControl

            _camera = capFilter as IAMCameraControl;
            if (_camera != null)
            {
                _camera.Set(CameraControlProperty.Focus, 0, CameraControlFlags.Manual); //Setting focus to macro (in my camera, range between 0 - 250)
                //_camera.Set(CameraControlProperty.Exposure, -3, CameraControlFlags.Manual);
                _camera.Set(CameraControlProperty.Iris, 0, CameraControlFlags.Manual);
            }
            if (cvcapture == null || cvcapture.IsDisposed)
                cvcapture = CvCapture.FromCamera(CaptureDevice.DShow, m_iCamNo);
            //if (Capture == null || !Capture.IsOpened())
            //{
            //    cvcapture = CvCapture.FromCamera(CaptureDevice.DShow, m_iCamNo);
            //    //Capture = new VideoCapture(m_iCamNo, VideoCaptureAPIs.DSHOW);
            //}
        }

        public void CameraClose()
        {
            cvcapture.Dispose();
            cvcapture = null;
        }

        public void AcqusitionStart()
        {
            return;
        }

        public void AcqusitionStop()
        {
            return;
        }


        public void Run()
        { }

        public float Getfps()
        {
            float rcvFrameRate = -1;
            if (cvcapture != null)
                rcvFrameRate = (float)cvcapture.Fps;

            return rcvFrameRate;
        }

        public void ShowControlDialog()
        {
        }

        public int GetConnectedCamCount()
        {
            if (devs != null)
            {
                return devs.Length;
            }
            return 0;
        }

        #region IDisposable Support
        private bool disposedValue = false; // 중복 호출을 검색하려면

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: 관리되는 상태(관리되는 개체)를 삭제합니다.
                    if (cvcapture != null)
                        cvcapture.Dispose();
                }

                // TODO: 관리되지 않는 리소스(관리되지 않는 개체)를 해제하고 아래의 종료자를 재정의합니다.
                // TODO: 큰 필드를 null로 설정합니다.

                disposedValue = true;
            }
        }

        // TODO: 위의 Dispose(bool disposing)에 관리되지 않는 리소스를 해제하는 코드가 포함되어 있는 경우에만 종료자를 재정의합니다.
        // ~WebCam() {
        //   // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
        //   Dispose(false);
        // }

        // 삭제 가능한 패턴을 올바르게 구현하기 위해 추가된 코드입니다.
        public void Dispose()
        {
            // 이 코드를 변경하지 마세요. 위의 Dispose(bool disposing)에 정리 코드를 입력하세요.
            Dispose(true);
            // TODO: 위의 종료자가 재정의된 경우 다음 코드 줄의 주석 처리를 제거합니다.
            // GC.SuppressFinalize(this);
        }

        #endregion


        public string GetCameraSeiralNo()
        {
            return GetCameraSeiralNo(m_iCamNo);
        }

        public string GetCameraSeiralNo(int CamNumber)
        {
            if (devs == null) return null;
            if (m_iCamNo >= devs.Length) return null;

            DsDevice dev = devs[CamNumber];
            return dev.Name;
        }

        public bool FlushBuffer()
        {
            return true;
        }

        public float ExposureTime
        {
            get
            {
                return mExposureTime;
            }
            set
            {
                if (mExposureTime == value) return;
                mExposureTime = value;
                //Cam.setStreamGrabber.UserData[.["ExposureTime"] = value;
            }
        }
        float mExposureTime;

        public float GainTime
        {
            get
            {
                return mGainTime;
            }
            set
            {
                if (mGainTime == value) return;
                mGainTime = value;
            }
        }
        float mGainTime;

        public int BeforeGrabDelay { get; set; }
        int mBeforeGrabDelay;
    }
}
