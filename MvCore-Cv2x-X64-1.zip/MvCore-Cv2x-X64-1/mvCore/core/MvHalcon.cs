﻿using HalconDotNet;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MvCore
{
    [Serializable]
    public class MvHalcon
    {
        public double AngleStart = 0;
        public double AngleEnd = 360;
        public int pyramid = 5;
        public int mode = 0;
        public int MatchCount = 1;


        private HTuple contrastMax;

        public HTuple ContrastMax
        {
            get { return contrastMax; }
            set
            {
                if (value == 0)
                {
                    contrastMax = "auto";
                }
                else
                {
                    contrastMax = value;
                }
            }
        }
        private HTuple contrastMin;

        public HTuple ContrastMin
        {
            get { return contrastMin; }
            set
            {
                if (value == 0)
                {
                    contrastMin = "auto";
                }
                else
                {
                    contrastMin = value;
                }
            }
        }








        public string halEdgeMode = "interpolation";
        HShapeModel halEdge;
        HNCCModel halNNC;


        [NonSerialized]
        private Mat template;

        public Mat Template
        {
            get { return template; }
            set
            {

                template = value;
                train(template);
            }
        }

        public MvHalcon()
        {
            if (ContrastMax == null)
                ContrastMax = 0;
            if (ContrastMin == null)
                ContrastMin = 0;
            AngleStart = -30;
            AngleEnd = 30;
            pyramid = 5;
            mode = 0;
            halEdgeMode = "interpolation";
            MatchCount = 1;

        }
        public MvHalcon(double angleStart, double angleEnd, int pyramid, string halEdgeMode, int MatchCount, int mode)
        {
            if (ContrastMax == null)
                ContrastMax = 0;
            if (ContrastMin == null)
                ContrastMin = 0;
            this.mode = mode;
            this.AngleStart = angleStart;
            this.AngleEnd = angleEnd;
            this.pyramid = pyramid;
            this.halEdgeMode = halEdgeMode;
            this.MatchCount = MatchCount;

        }
        public MvHalcon(double angleStart, double angleEnd, int pyramid, string halEdgeMode, int contrastMin, int contrastMax, int mode, int MatchCount, Mat template)
        {
            if (contrastMax == null)
                ContrastMax = 0;
            else
                ContrastMax = contrastMax;

            if (contrastMin == null)
                ContrastMin = 0;
            else
                ContrastMin = contrastMin;
            this.mode = mode;
            this.AngleStart = angleStart;
            this.AngleEnd = angleEnd;
            this.pyramid = pyramid;
            this.halEdgeMode = halEdgeMode;
            this.Template = template;
            this.MatchCount = MatchCount;

        }

        public HImage Mat2HImage(Mat mat)
        {
            // 1️⃣ Chỉ cho phép ảnh xám 8-bit
            if (mat.Type() != MatType.CV_8UC1)
                return null;

            // 2️⃣ Đảm bảo memory liên tục
            if (!mat.IsContinuous())
                mat = mat.Clone();

            // 3️⃣ Copy data sang managed buffer
            int size = mat.Rows * mat.Cols;
            byte[] buffer = new byte[size];
            Marshal.Copy(mat.Data, buffer, 0, size);

            // 4️⃣ Pin buffer (RẤT QUAN TRỌNG)
            //GCHandle _handle = GCHandle.Alloc(buffer, GCHandleType.Pinned); // lỗi tràn bộ nhớ do không được giải phóng (free)

            // 5️⃣ Tạo HImage từ IntPtr
            //return new HImage(
            //     "byte",
            //     mat.Cols,
            //     mat.Rows,
            //     _handle.AddrOfPinnedObject()
            // );
            return new HImage("byte",mat.Cols,mat.Rows,mat.Data);
        }

        public static List<List<OpenCvSharp.CPlusPlus.Point>> HObjectToPointLists(HObject xldContours, OpenCvSharp.CPlusPlus.Rect Roi)
        {
            List<List<OpenCvSharp.CPlusPlus.Point>> result = new List<List<OpenCvSharp.CPlusPlus.Point>>();

            if (xldContours == null || !xldContours.IsInitialized())
                return result;

            // Đếm số contour
            HTuple count;
            HOperatorSet.CountObj(xldContours, out count);

            for (int i = 1; i <= count; i++) // HALCON index bắt đầu từ 1
            {
                // Lấy từng contour
                HObject singleContour;
                HOperatorSet.SelectObj(xldContours, out singleContour, i);

                // Lấy điểm contour
                HTuple rows, cols;
                HOperatorSet.GetContourXld(singleContour, out rows, out cols);

                List<OpenCvSharp.CPlusPlus.Point> points = new List<OpenCvSharp.CPlusPlus.Point>();

                for (int j = 0; j < rows.Length; j++)
                {
                    points.Add(new OpenCvSharp.CPlusPlus.Point(
                        (int)Math.Round(cols[j].D) + Roi.X,
                        (int)Math.Round(rows[j].D) + Roi.Y
                    ));
                }

                if (points.Count > 0)
                    result.Add(points);

                singleContour.Dispose();
            }

            return result;
        }
        private List<List<OpenCvSharp.CPlusPlus.Point>> trainContours;

        public List<List<OpenCvSharp.CPlusPlus.Point>> TrainContours
        {
            get
            {
                if (halEdge == null || trainContours == null) { return new List<List<OpenCvSharp.CPlusPlus.Point>>(); }
                return trainContours;
            }
            set { trainContours = value; }
        }

        public void train(Mat tem)
        {
            HImage img = Mat2HImage(tem);
            try
            {
                if (mode == 0)
                {
                    halEdge = new HShapeModel(img, (HTuple)pyramid, (HTuple)(-180) * Math.PI / 180, (HTuple)360 * Math.PI / 180, "auto", "none", "use_polarity", ContrastMax, ContrastMin);
                    HObject modelContours;
                    HOperatorSet.GetShapeModelContours(
                        out modelContours,
                        halEdge,
                        1     // level (1 = chi tiết nhất)
                    );
                    HTuple homMat2D;
                    // Tạo ma trận biến đổi
                    HOperatorSet.VectorAngleToRigid(
                        0, 0, 0,
                        tem.Height / 2, tem.Width / 2, 0,
                        out homMat2D
                    );
                    // Transform contour
                    HObject contoursTrans;
                    HOperatorSet.AffineTransContourXld(
                        modelContours,
                        out contoursTrans,
                        homMat2D
                    );
                    TrainContours = HObjectToPointLists(contoursTrans, new OpenCvSharp.CPlusPlus.Rect(0, 0, 0, 0));
                }
                else if (mode == 1)
                    halNNC = new HNCCModel(img, (HTuple)pyramid, -180 * Math.PI / 180, (HTuple)360 * Math.PI / 180, "auto", "use_polarity");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }


            //List<List<OpenCvSharp.CPlusPlus.Point>>  _TrainContours = HObjectToPointLists(modelContours, new OpenCvSharp.CPlusPlus.Rect(0, 0, 0, 0));
            //var allPts = _TrainContours.SelectMany(c => c).ToList();

            //int minX = allPts.Min(p => p.X);
            //int minY = allPts.Min(p => p.Y);
            //TrainContours = _TrainContours.Select(contour =>contour.Select(p =>new OpenCvSharp.CPlusPlus.Point(p.X - minX,p.Y - minY)).ToList()).ToList();

        }
        public double FindShape(Mat Src, out Point3d center, out List<List<OpenCvSharp.CPlusPlus.Point>> contours, OpenCvSharp.CPlusPlus.Rect Roi)
        {
            HImage hImage = Mat2HImage(Src);
            if (halEdge == null || hImage == null) { center = new Point3d(0, 0, 0); contours = new List<List<OpenCvSharp.CPlusPlus.Point>>(); return 0f; }

            HTuple hRow, hColumn, hAngle, hScore;

            //double rangeAnge = (AngleEnd - AngleStart) / 2;
            //double meanAngle = AngleEnd - rangeAnge;
            halEdge.FindShapeModel(hImage, (HTuple)((AngleEnd) * -1) * (Math.PI / 180), (HTuple)(AngleEnd + AngleStart) * (Math.PI / 180), 0.1, MatchCount, 0, halEdgeMode, pyramid, 0, out hRow, out hColumn, out hAngle, out hScore);//interpolation,least_squares ,least_squares_high
            if (hScore.Length == 0 || hAngle.Length == 0 || hRow.Length == 0 || hColumn.Length == 0) { center = new Point3d(0, 0, 0); contours = new List<List<OpenCvSharp.CPlusPlus.Point>>(); return 0f; }
            center = new Point3d(hColumn, hRow, hAngle);
            double Score = hScore;
            // Lấy contour model
            HObject modelContours;
            HOperatorSet.GetShapeModelContours(
                out modelContours,
                halEdge,
                1
            );
            HTuple homMat2D;
            // Tạo ma trận biến đổi
            HOperatorSet.VectorAngleToRigid(
                0, 0, 0,
                hRow, hColumn, hAngle,
                out homMat2D
            );
            // Transform contour
            HObject contoursTrans;
            HOperatorSet.AffineTransContourXld(
                modelContours,
                out contoursTrans,
                homMat2D
            );
            contours = HObjectToPointLists(contoursTrans, Roi);
            hRow.Dispose();
            hColumn.Dispose();
            hAngle.Dispose();
            hScore.Dispose();
            hImage.Dispose();
            contoursTrans.Dispose();
            homMat2D.Dispose();
            modelContours.Dispose();
            return Score;
        }
        public double FindNNC(Mat Src, out Point3d center)
        {
            HImage hImage = Mat2HImage(Src);
            if (halNNC == null || hImage == null) { center = new Point3d(0, 0, 0); return 0f; }
            HTuple hRow, hColumn, hAngle, hScore;
            halNNC.FindNccModel(hImage, (HTuple)((AngleEnd) * -1) * (Math.PI / 180), (HTuple)(AngleEnd + AngleStart) * (Math.PI / 180), 0.1, MatchCount, 0, "true", pyramid, out hRow, out hColumn, out hAngle, out hScore);
            if (hScore.Length == 0 || hAngle.Length == 0 || hRow.Length == 0 || hColumn.Length == 0) { center = new Point3d(0, 0, 0); return 0f; }
            center = new Point3d(hColumn, hRow, hAngle); // * 180 / Math.PI
            double Score = hScore;
            hRow.Dispose();
            hColumn.Dispose();
            hAngle.Dispose();
            hScore.Dispose();
            hImage.Dispose();
            return Score;
        }

        public double[] FindShape(Mat src, out Point3d[] centers, out List<List<List<OpenCvSharp.CPlusPlus.Point>>> contours, OpenCvSharp.CPlusPlus.Rect roi)
        {
            centers = Array.Empty<Point3d>();
            contours = new List<List<List<OpenCvSharp.CPlusPlus.Point>>>();

            HImage hImage = Mat2HImage(src);
            if (halEdge == null || hImage == null)
                return Array.Empty<double>();

            HTuple hRow, hColumn, hAngle, hScore;

            halEdge.FindShapeModel(
                hImage,
                (HTuple)(-AngleEnd * Math.PI / 180.0),
                (HTuple)((AngleEnd + AngleStart) * Math.PI / 180.0),
                0.1,
                MatchCount,
                0,
                halEdgeMode,
                pyramid,
                0,
                out hRow,
                out hColumn,
                out hAngle,
                out hScore
            );

            int count = hScore.Length;
            if (count == 0)
                return Array.Empty<double>();

            // ===== Convert kết quả =====
            centers = new Point3d[count];
            double[] scores = new double[count];

            for (int i = 0; i < count; i++)
            {
                centers[i] = new Point3d(
                    hColumn[i].D,
                    hRow[i].D,
                    hAngle[i].D
                );
                scores[i] = hScore[i].D;
            }

            // ===== Lấy contour gốc của model =====
            HObject modelContours;
            HOperatorSet.GetShapeModelContours(
                out modelContours,
                halEdge,
                1
            );

            // ===== Transform contour cho từng match =====
            for (int i = 0; i < count; i++)
            {
                HTuple homMat2D;
                HOperatorSet.VectorAngleToRigid(
                    0, 0, 0,
                    hRow[i], hColumn[i], hAngle[i],
                    out homMat2D
                );

                HObject contourTrans;
                HOperatorSet.AffineTransContourXld(
                    modelContours,
                    out contourTrans,
                    homMat2D
                );

                // Convert HALCON contour → OpenCV points
                contours.Add(HObjectToPointLists(contourTrans, roi));
                contourTrans.Dispose();
                homMat2D.Dispose();
            }
            hRow.Dispose();
            hColumn.Dispose();
            hAngle.Dispose();
            hScore.Dispose();
            hImage.Dispose();
            modelContours.Dispose();
            hImage = null;
            modelContours = null;
            return scores;
        }

        public double[] FindNNC(Mat src, out Point3d[] centers)
        {
            centers = Array.Empty<Point3d>();

            HImage hImage = Mat2HImage(src);
            if (halNNC == null || hImage == null)
                return Array.Empty<double>();

            HTuple hRow, hColumn, hAngle, hScore;

            halNNC.FindNccModel(
                hImage,
                (HTuple)(-AngleEnd * Math.PI / 180.0),
                (HTuple)((AngleEnd + AngleStart) * Math.PI / 180.0),
                0.1,
                MatchCount,
                0,
                "true",
                pyramid,
                out hRow,
                out hColumn,
                out hAngle,
                out hScore
            );

            int count = hScore.Length;
            if (count == 0)
                return Array.Empty<double>();

            centers = new Point3d[count];
            double[] scores = new double[count];

            for (int i = 0; i < count; i++)
            {
                centers[i] = new Point3d(
                    hColumn[i].D,
                    hRow[i].D,
                    hAngle[i].D   // rad
                );

                scores[i] = hScore[i].D;
            }
            hRow.Dispose();
            hColumn.Dispose();
            hAngle.Dispose();
            hScore.Dispose();
            hImage.Dispose();
            return scores;
        }


        public void test()
        {
            //for (int i = 0; i < 13; i++)
            //{
            //    Mat tem = new Mat("C:\\Users\\admin\\Documents\\Presentation1\\tm0.jpg", LoadMode.GrayScale);
            //    Mat src = new Mat($"C:\\Users\\admin\\Documents\\Presentation1\\{i}.JPG", LoadMode.GrayScale);
            //    train(tem);
            //    Point3d center;
            //    double score = FindShape(src, out center);
            //    Cv2.CvtColor(src, src, ColorConversion.GrayToBgr);
            //    if(src.Width > 1802 || src.Height > 980)
            //    {
            //        src.Resize(new OpenCvSharp.CPlusPlus.Size(1802, 980));
            //    }
            //    Cv2.Line(src, new Point2d(center.X - 5, center.Y), new Point2d(center.X + 5, center.Y), new Scalar(0, 255, 0));
            //    Cv2.Line(src, new Point2d(center.X, center.Y - 5), new Point2d(center.X, center.Y + 5), new Scalar(0, 255, 0));
            //    Cv2.PutText(src, $"Score:{score} X:{center.X} Y:{center.Y} R:{center.Z}", new Point2d(center.X, center.Y), FontFace.HersheyComplex, 1f, new Scalar(0, 255, 0), 1);
            //    Cv2.ImShow("res", src);
            //    Cv2.WaitKey(2000);
            //}

            for (int i = 0; i < 13; i++)
            {
                if (i == 10) continue;
                Mat msrc = new Mat($"C:\\Users\\admin\\Documents\\Presentation1\\{i}.JPG", LoadMode.GrayScale);
                HImage tem = new HImage("C:\\Users\\admin\\Documents\\Presentation1\\tm0.jpg");
                HImage src = new HImage($"C:\\Users\\admin\\Documents\\Presentation1\\{i}.JPG");
                HShapeModel _haledge = new HShapeModel(tem, 3, (HTuple)AngleStart * Math.PI / 180, (HTuple)AngleEnd * Math.PI / 180, "auto", "none", "use_polarity", "auto", 10); ;
                HTuple hX, hY, hAngle, hScore;
                _haledge.FindShapeModel(src, (HTuple)0 * Math.PI / 180, (HTuple)360 * Math.PI / 180, 0.1, 1, 1, "interpolation", 1, 1, out hY, out hX, out hAngle, out hScore);

                if (hScore.Length == 0) continue;
                Cv2.CvtColor(msrc, msrc, ColorConversion.GrayToBgr);
                if (msrc.Width > 1802 || msrc.Height > 980)
                {
                    msrc.Resize(new OpenCvSharp.CPlusPlus.Size(1802, 980));
                }
                Cv2.Line(msrc, new Point2d(hX - 5, hY), new Point2d(hX + 5, hY), new Scalar(0, 0, 255));
                Cv2.Line(msrc, new Point2d(hX, hY - 5), new Point2d(hX, hY + 5), new Scalar(0, 0, 255));
                Cv2.PutText(msrc, $"Score:{hScore:F3} X:{hX:F3} Y:{hY:F3} R:{hAngle:F3}", new Point2d(0, 40), FontFace.HersheyComplex, 1f, new Scalar(0, 255, 0), 1);
                Cv2.ImShow("res", msrc);
                Cv2.WaitKey(2000);
            }

        }
    }
}
