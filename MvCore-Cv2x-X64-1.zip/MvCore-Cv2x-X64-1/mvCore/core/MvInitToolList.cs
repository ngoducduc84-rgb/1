﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;
using MvCore.Edit;


namespace MvCore.Core
{
    partial class MvToolBlockTree
    {
        void InitToolList()
        {
            tools = new Dictionary<MvToolBase, MvToolEditForm>();

            //*****************************************************************************
            //        #        #######      ######   
            //       ###       ##    ##   ##
            //      ## ##      ##    ##  ##
            //     #######     #######   ##            순으로 추가할것!
            //    ##     ##    ##    ##  ##
            //   ##       ##   ##    ##   ##
            //  ##         ##  #######      ######
            //*****************************************************************************
            tools.Add(new MvAcquisition(), new MvToolEditForm(new MvAcqisitionEdit()));

            tools.Add(new MvBarcode(), new MvToolEditForm(new MvBarcodeEdit()));
            tools.Add(new MvBlob(), new MvToolEditForm(new MvBlobEdit()));
            tools.Add(new MvBlur(), new MvToolEditForm(new MvBlurEdit()));

            tools.Add(new MvCalib(), new MvToolEditForm(new MvCalibrationEdit()));
            tools.Add(new MvCalibs(), new MvToolEditForm(new MvCalibrationsEdit()));
            //tools.Add(new MvCaliper(), new MvToolEditForm(new MvCaliperEdit())); //디버깅중_05.10_hong
            tools.Add(new MvCameraCalibration(), new MvToolEditForm(new MvCameraCalibrationEdit())); //디버깅중_05.10_hong
            tools.Add(new MvManualCalibration(), new MvToolEditForm(new MvManualCalibrationEdit()));
            tools.Add(new MvCreateCricle(), new MvToolEditForm(new MvCreateCircleEdit()));
            tools.Add(new MvCreateLine(), new MvToolEditForm(new MvCreateLineEdit()));
            tools.Add(new MvCreatePoint(), new MvToolEditForm(new MvCreatePointEdit()));

            tools.Add(new MvDataAnalysis(), new MvToolEditForm(new MvDataAnalysisEdit()));
            tools.Add(new MvDataLog(), new MvToolEditForm(new MvDataLogEdit()));
            tools.Add(new MvDistance2P(), new MvToolEditForm(new MvDistance2PEdit()));
            tools.Add(new MvDistance3P(), new MvToolEditForm(new MvDistance3PEdit()));

            tools.Add(new MvEdge(), new MvToolEditForm(new MvEdgeEdit()));
            tools.Add(new MvEqualizer(), new MvToolEditForm(new MvEqualizerEdit()));

           
            tools.Add(new MvFindCircle(), new MvToolEditForm(new MvFindCircleEdit()));
            tools.Add(new MvFindCorner(), new MvToolEditForm(new MvFindCornerEdit()));
            tools.Add(new MvFindLine(), new MvToolEditForm(new MvFindLineEdit()));
            tools.Add(new MvFindParallelLine(), new MvToolEditForm(new MvFindParallelLineEdit()));
            tools.Add(new MvFit(), new MvToolEditForm(new MvFitEdit()));
            tools.Add(new MvFixture(), new MvToolEditForm(new MvFixtureEdit()));
            tools.Add(new MvFor(), new MvToolEditForm(new MvForEdit()));

            tools.Add(new MvHistogram(), new MvToolEditForm(new MvHistogramEdit()));

            tools.Add(new MvIf(), new MvToolEditForm(new MvIfEdit()));
            tools.Add(new MvImageCalculate(), new MvToolEditForm(new MvImageCalculateEdit()));
            tools.Add(new MvImageConverter(), new MvToolEditForm(new MvImageConverterEdit()));
            tools.Add(new MvImageSave(), new MvToolEditForm(new MvImageSaveEdit()));
            tools.Add(new MvIntersectLine(), new MvToolEditForm(new MvIntersectLineEdit()));

            tools.Add(new MvJudgement(), new MvToolEditForm(new MvJudgementEdit()));
            tools.Add(new MvJudgementOverpocket(), new MvToolEditForm(new MvJudgementOverpocketEdit()));

            tools.Add(new MvMakeLattice(), new MvToolEditForm(new MvMakeLatticeEdit()));
            tools.Add(new MvMakeLine(), new MvToolEditForm(new MvMakeLineEdit()));
            tools.Add(new MvMakePoint(), new MvToolEditForm(new MvMakePointEdit()));
            //tools.Add(new SvMakePoint2(), new SvToolEditForm(new SvMakePoint2Edit()));      
            tools.Add(new MvMakeRectFromLine(), new MvToolEditForm(new MvMakeRectFromLineEdit()));
            tools.Add(new MvMakeRegions(), new MvToolEditForm(new MvMakeRegionsEdit()));
            tools.Add(new MvMasking(), new MvToolEditForm(new MvMaskingEdit()));
            tools.Add(new MvMeasureSharpness(), new MvToolEditForm(new MvMeasureSharpnessEdit()));
            tools.Add(new MvMeasurement(), new MvToolEditForm(new MvMeasurementEdit()));
            tools.Add(new MvMerge(), new MvToolEditForm(new MvMergeEdit()));
            tools.Add(new MvMerges(), new MvToolEditForm(new MvMergesEdit()));
            tools.Add(new MvMorphology(), new MvToolEditForm(new MvMorphologyEdit()));

            tools.Add(new MvOut(), new MvToolEditForm(new MvOutEdit()));

            tools.Add(new MvRegion(), new MvToolEditForm(new MvRegionEdit()));
            tools.Add(new MvResultAnalysis(), new MvToolEditForm(new MvResultAnalysisEdit()));
            tools.Add(new MvRotation(), new MvToolEditForm(new MvRotationEdit()));

            tools.Add(new MvSubImage(), new MvToolEditForm(new MvSubImageEdit()));
            tools.Add(new MvSharpness(), new MvToolEditForm(new MvSharpnessEdit()));
            tools.Add(new MvShow(), new MvToolEditForm(new MvShowEdit()));

            tools.Add(new MvTemplateMatch(), new MvToolEditForm(new MvTemplateMatchEdit()));
            tools.Add(new MvTemplateMatchs(), new MvToolEditForm(new MvTemplateMatchsEdit()));
            tools.Add(new MvTemplateMatchOverpocket(), new MvToolEditForm(new MvTemplateMatchOverpocketEdit()));
            tools.Add(new MvToolBlock(), new MvToolEditForm(new MvToolBlockEdit(svToolTreeView)));
            tools.Add(new MvTCP(), new MvToolEditForm(new MvTCPEdit()));
            tools.Add(new MvTCPSend(), new MvToolEditForm(new MvTCPSendEdit()));

            tools.Add(new MvWarpping(), new MvToolEditForm(new MvWarppingEdit()));
            tools.Add(new MvWarppingPoint(), new MvToolEditForm(new MvWarppingPointEdit()));
        }
    }
}
