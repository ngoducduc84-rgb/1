﻿namespace MvCore.Core
{
    partial class MvToolBlockTree
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.svToolTreeView = new MvCore.Core.MvToolBlockTreeView();
            this.SuspendLayout();
            // 
            // svToolTreeView
            // 
            this.svToolTreeView.AllowDrop = true;
            this.svToolTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.svToolTreeView.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
            this.svToolTreeView.Location = new System.Drawing.Point(0, 0);
            this.svToolTreeView.Name = "svToolTreeView";
            this.svToolTreeView.ShowPlusMinus = false;
            this.svToolTreeView.ShowRootLines = false;
            this.svToolTreeView.Size = new System.Drawing.Size(270, 256);
            this.svToolTreeView.TabIndex = 0;
            // 
            // SvToolBlockTree
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Controls.Add(this.svToolTreeView);
            this.Name = "SvToolBlockTree";
            this.Size = new System.Drawing.Size(270, 256);
            this.ResumeLayout(false);

        }

        #endregion

        private MvToolBlockTreeView svToolTreeView;
    }
}
