﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;
using MvCore.Edit;

namespace MvCore.Core
{
    public partial class MvToolBlockTree : UserControl // Form chứa treeView
    {
        MvToolListForm toolListForm;

        static bool isInitTool = false;

        public MvToolBlockTree()
        {
            InitializeComponent();
            svToolTreeView.ToolDoubleClick += svToolTree_ToolDoubleClick;
            svToolTreeView.ToolSelect += svToolTreeView_ToolSelect;

            this.Disposed += (sender, e) =>
            {
                MvAcquisition.CloseCamlist();

                if (tools != null)
                {
                    foreach (MvToolEditForm form in tools.Values)
                    {
                        form.Close();
                        form.Dispose();
                    }
                }

                if (toolListForm != null)
                {
                    toolListForm.Close();
                    toolListForm.Dispose();
                }

                isInitTool = false;
            };

        }

        void svToolTreeView_ToolSelect(object sender, MvToolBase tool)
        {
            NotifyToolSelect(sender, tool);
        }

        public delegate void ToolSelectHandler(object sender, MvToolBase tool);
        public event ToolSelectHandler ToolSelect;

        void NotifyToolSelect(object sender, MvToolBase tool)
        {
            if (ToolSelect != null)
                ToolSelect(sender, tool);
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvJob Job
        {
            get { return svToolTreeView.Job; }
            set { svToolTreeView.Job = value; }
        }

        static Dictionary<MvToolBase, MvToolEditForm> tools;
    

        public void ShowToolList()
        {
            if (!isInitTool)
            {
                isInitTool = true;
                InitToolList();
            }

            if (toolListForm == null || toolListForm.IsDisposed)
            {
                toolListForm = new MvToolListForm(tools.Keys);
                toolListForm.svToolList.MouseDown += svToolTreeView.toolListForm_MouseDown;
            }

            if (toolListForm.Visible == true)
                toolListForm.Focus();
            else
                toolListForm.Show();
        }

        void svToolTree_ToolDoubleClick(object sender, MvToolBase selectedTool)
        {
            //if (!isInitTool)
            //{
            //    isInitTool = true;
            //    InitToolList(); 
            //}
            InitToolList(); //daviddang
            MvToolEditForm selectedToolEditForm = new MvToolEditForm();

            foreach (MvToolBase tool in tools.Keys)
            {
                if (selectedTool != null && tool.GetType() == selectedTool.GetType())
                {
                   selectedToolEditForm = tools[tool];//
                    if (tool is MvDataLog)
                    {
                        selectedToolEditForm.Deactivate -= selectedToolEditForm_DeactivateChanged;
                        selectedToolEditForm.Deactivate += selectedToolEditForm_DeactivateChanged;
                    }
                    break;
                }
            }
            if (selectedTool != null)
            {
                selectedToolEditForm.Subject = selectedTool;//

                if (selectedToolEditForm == null || selectedToolEditForm.IsDisposed) { MessageBox.Show("이거 버그임. 고쳐야됨. 이럴리가 없는데"); return; } //|| selectedToolEditForm.IsDisposed

                if (selectedToolEditForm.Visible == true)
                    selectedToolEditForm.Focus();
                else
                    selectedToolEditForm.Show();//

                if (selectedToolEditForm.WindowState == FormWindowState.Minimized)
                    selectedToolEditForm.WindowState = FormWindowState.Normal;
            }
        }

        void selectedToolEditForm_DeactivateChanged(object sender, EventArgs e)
        {
            RedrawAllNode();
        }


        public void SetToolBlockInOutput(MvToolBlock toolBlock)
        {
            svToolTreeView.InputTool = toolBlock.inputTool;
            toolBlock.outputTool.outParams.Clear();
            svToolTreeView.OutputTool = toolBlock.outputTool;
            svToolTreeView.Job = toolBlock.ToolJob;
        }

        public void RedrawAllNode()
        {
            svToolTreeView.RedrawAllNode();
        }
    }
}
