﻿using OpenCvSharp;
//using OpenCvSharp.Flann;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media;
using static System.Windows.Forms.AxHost;

//using CodeRunTime;

//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MvCore.Core
{
    public class MvToolBlockTreeView : TreeView// tree chua cac tool
    {
        public MvToolBlockTreeView()
        {
            InitDrag();
            InitJob();
            InitContextMenu();


            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);

            this.KeyDown += SvToolBlockTreeView_KeyDown;
            this.KeyUp += SvToolBlockTreeView_KeyUp;
            this.BeforeCollapse += SvToolBlockTreeView_BeforeCollapse;
            this.ShowPlusMinus = false;
            this.ShowRootLines = false;

            this.MouseMove += SvToolBlockTreeView_MouseMove;
            this.MouseDown += SvToolBlockTreeView_MouseDown;
          
        }

        private void SvToolBlockTreeView_MouseMove(object sender, MouseEventArgs e)
        {
            if (ListLink == null) return;

            // 모든 Link의 IsHighLight와 IsChanged를 Update
            for (int i = 0; i < ListLink.Length; i++)
            {
                foreach (List<Link> links in ListLink[i].Values)
                {
                    for (int j = 0; j < links.Count; j++)
                        links[j].HighlightLink((System.Drawing.Point)e.Location);
                }
            }

            TreeNode hoverNode = GetNodeAt(e.Location);

            if (hoverNode == null) return;

            OnDrawNode(new DrawTreeNodeEventArgs(this.CreateGraphics(), hoverNode, this.Bounds, TreeNodeStates.Marked));
        }

        private void SvToolBlockTreeView_BeforeCollapse(object sender, TreeViewCancelEventArgs e)
        {
            e.Cancel = true;
        }

        public bool IsControl = false;

        void SvToolBlockTreeView_KeyUp(object sender, KeyEventArgs e)
        {
            IsControl = false;
        }

        private void SvToolBlockTreeView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Delete)
            {
                try
                {
                    TreeNode node = SelectedNode;

                    if (inputTool != null && node.Index == 0) return;
                    if (outputTool != null && node.Index == this.Nodes.Count - 1) return;

                    if (node.Level > 0)
                        return;
                    if (MessageBox.Show("Do You Want to delete this tool?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                    {
                        return;
                    }
                    DeleteNode(node);
                }
                finally
                {
                    this.Focus();
                }
            }
            else if ((e.KeyData & Keys.Control) == Keys.Control)
            {
                IsControl = true;
            }
          
        }

        public void toolListForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Clicks == 2)
            {
                MvToolList svtoollist = sender as MvToolList;
                string typeName = svtoollist.SelectedItem.GetType().ToString();

                if (string.IsNullOrEmpty(typeName)) return;

                try
                {
                    MvToolBase tool = Activator.CreateInstance(Type.GetType(typeName, null, typeResolve)) as MvToolBase;
                    int index = this.Nodes.Count;
                    AddNode(index, tool);
                    NotifyToolSelect(this, tool);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }

        #region Context
        ContextMenuStrip context;
        void InitContextMenu()
        {
            context = new System.Windows.Forms.ContextMenuStrip();
            context.Items.Add("Cancel LInk", null, delegate
            {
                int index = this.Nodes.IndexOf(GetRootNode(SelectedNode));

                MvToolBase tool = JobContainInOut[index];

                if (tool.inParams.ContainsKey(SelectedNode.Text))
                    tool.inParams[SelectedNode.Text] = null;
                RedrawAllNode();
            });

            context.Items.Add("Rename", null, delegate
            {
                TreeNode node = SelectedNode;
                MvToolBase tool = node.Tag as MvToolBase;
                int index = node.Index;
                //if (inputTool != null && index == 0 ) return;
                //if (outputTool != null && index == this.Nodes.Count - 1) return;
                //daviddang
                if (inputTool != null && node.Text == "Input") return;
                if (outputTool != null && node.Text == "Output") return;
                if (tool is MvFor || tool is MvIf) return;
                RenameForm renameForm = new RenameForm(node.Text);

                System.Drawing.Point pt = this.PointToScreen(this.Location);
                renameForm.StartPosition = FormStartPosition.Manual;
                renameForm.Location = new System.Drawing.Point(pt.X + node.Bounds.Right + 10, pt.Y + node.Bounds.Top - 50);
                if (DialogResult.OK != renameForm.ShowDialog())
                    return;

                if (inputTool != null && node.Text == "Input") index -= 1;
                if (node.Level == 0)
                {
                    // job.ToolList[index].toolName = renameForm.newName;
                    //daviddang

                    tool.toolName = renameForm.newName;
                }
                else
                {
                    if (node.Parent.Parent.Tag is MvIf)
                    {
                        MvIf toolIf = node.Parent.Parent.Tag as MvIf;
                        if (toolIf is null) return;
                        if (node.Parent.Text == "True")
                        {
                            toolIf.ToolJobTrue.ToolList[index].toolName = renameForm.newName;
                        }
                        else if (node.Parent.Text == "False")
                        {
                            toolIf.ToolJobFalse.ToolList[index].toolName = renameForm.newName;
                        }
                    }
                    else if (node.Parent.Parent.Tag is MvFor)
                    {
                        MvFor toolFor = node.Parent.Parent.Tag as MvFor;
                        if (toolFor is null) return;
                        if (node.Parent.Text == "For Region")
                        {
                            toolFor.ToolJob.ToolList[index].toolName = renameForm.newName;
                        }
                    }
                }
                node.Text = renameForm.newName;
                node.Name = node.Text;

            });

            context.Items.Add("Modify parmas", null, delegate
            {
                TreeNode node = SelectedNode;
                //if (inputTool != null && index == 0 ) return;
                //if (outputTool != null && index == this.Nodes.Count - 1) return;
                //daviddang
                if (inputTool != null && node.Text == "Input") return;
                if (outputTool != null && node.Text == "Output") return;

                ModifyPamams(node);
            });

            context.Items.Add("Delete", null, delegate
            {
                TreeNode node = SelectedNode;

                //if (inputTool != null && node.Index == 0) return;
                //if (outputTool != null && node.Index == this.Nodes.Count - 1) return;
                //daviddang
                if (inputTool != null && node.Text == "Input") return;
                if (outputTool != null && node.Text == "Output") return;
                if (node.Level % 2 == 0) //daviddang
                {
                    DeleteNode(node);
                }
            });

            this.ContextMenuStrip = context;
            context.Opening += context_Opening;

        }

        void context_Opening(object sender, CancelEventArgs e)
        {
            if (SelectedNode == null)
                return;

            foreach (ToolStripItem item in context.Items)
            {
                item.Visible = false;
            }

            //하드코딩입니다. 이렇게 짜는거 안좋은데 나도몰라....
            if (SelectedNode.Level % 2 == 0) //neu la tool Node 
            {
                context.Items[1].Visible = true; //rename
                context.Items[2].Visible = true;//modify parmas
                context.Items[3].Visible = true;//delete
            }
            if (SelectedNode.Level % 2 != 0) //neu la Input parmas or output parmas
            {
                context.Items[0].Visible = true; //can Link
                //context.Items[1].Visible = true; //rename
                //context.Items[2].Visible = true; //modify parmas
                //context.Items[3].Visible = true; //delete
            }
        }

        #endregion

        #region NodeAction

        TreeNode MakeNode(MvToolBase tool)
        {
            if (tool == null) return null;
            TreeNode toolNode = new TreeNode(tool.ToString());
            toolNode.Tag = tool;
            toolNode.Name = tool.ToString();
            foreach (string ob in tool.GetInputParamNames())
            {
                TreeNode inputNode = new TreeNode(ob);
                inputNode.Name = ob;
                inputNode.ForeColor = System.Drawing.Color.Red;
                toolNode.Nodes.Add(inputNode);
                this.ContextMenuStrip = context;
            }

            foreach (string ob in tool.GetOutputParamNames())
            {
                TreeNode outputNode = new TreeNode(ob);
                outputNode.Name = ob;
                outputNode.ForeColor = System.Drawing.Color.Blue;
                toolNode.Nodes.Add(outputNode);
                this.ContextMenuStrip = context;
            }

            return toolNode;
        }

        void AddNode(int index, MvToolBase tool)
        {
            TreeNode toolNode = MakeNode(tool);
            toolNode.Tag = tool;
            if (inputTool != null)
            {
                if (index < 1) index = 1;
                else if (index >= this.Nodes.Count) index = this.Nodes.Count - 1;
            }
            this.Nodes.Insert(index, toolNode);

            if (inputTool != null) index -= 1;
            job.ToolList.Insert(index, tool);
            RedrawAllNode();
        }

        void DeleteNode(TreeNode node)
        {
            int index = node.Index;
            //if (inputTool != null ) index -= 1; 
            if (inputTool != null && SelectedNode.Level == 0) index -= 1;
            if (node.Level == 0)
            {

                //SvToolBase tool = job.ToolList[index];
                //daviddang
                MvToolBase tool = node.Tag as MvToolBase;
                job.ToolList.Remove(tool);
                tool = null;
            }
            else //daviddang
            {
                if (node.Parent.Parent.Tag is MvIf)
                {
                    MvIf toolIf = node.Parent.Parent.Tag as MvIf;
                    if (toolIf is null) return;
                    if (node.Parent.Text == "True")
                    {
                        MvToolBase tool = toolIf.ToolJobTrue.ToolList[index];
                        toolIf.ToolJobTrue.ToolList.Remove(tool);
                        tool = null;
                    }
                    else if (node.Parent.Text == "False")
                    {
                        MvToolBase tool = toolIf.ToolJobFalse.ToolList[index];
                        toolIf.ToolJobFalse.ToolList.Remove(tool);
                        tool = null;
                    }
                }
                else if (node.Parent.Parent.Tag is MvFor)
                {
                    MvFor toolFor = node.Parent.Parent.Tag as MvFor;
                    if (toolFor is null) return;
                    if (node.Parent.Text == "For Region")
                    {
                        MvToolBase tool = toolFor.ToolJob.ToolList[index];
                        toolFor.ToolJob.ToolList.Remove(tool);
                        tool = null;
                    }
                }
            }
            this.Nodes.Remove(node);
            RedrawAllNode();
        }

        TreeNode GetRootNode(TreeNode node)
        {
            if (node == null)
                return null;

            if (node.Parent == null)
                return node;
            else
                return GetRootNode(node.Parent);
        }

        TreeNode GetRootNode(TreeNode node, string key)
        {
            if (node == null)
                return null;

            if (node.Parent == null || node.Text == key)
                return node;
            else
                return GetRootNode(node.Parent, key);
        }

        private MvToolBase GetToolFromNode(TreeNode node)
        {
            return node?.Tag as MvToolBase;
        }

        void ModifyPamams(TreeNode node)
        {
            MvToolParamsEditForm form = new MvToolParamsEditForm();

            int index = node.Index;
            //if (inputTool != null) index -= 1;
            if (inputTool != null && SelectedNode.Level == 0) index -= 1;
            if (node.Level % 2 == 0)
            {

                //SvToolBase tool = job.ToolList[index];
                MvToolBase tool = SelectedNode.Tag as MvToolBase;//daviddang
                //toolBlock만 예외처리
                if (tool is MvToolBlock)
                {
                    MessageBox.Show("[ToolBlock] tool can be modified in tool editor, not this menu.");
                    return;
                }

                form.Subject = tool;
            }

            form.ShowDialog();

            RedrawAllNode();

            form.Dispose();
        }

        #endregion

        #region Job_Init&Job_Select

        MvToolBlock.SvInnerToolBlock inputTool;
        MvToolBlock.SvInnerToolBlock outputTool;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvToolBlock.SvInnerToolBlock InputTool
        {
            get { return inputTool; }
            set
            {
                inputTool = value;
                //RedrawAllNode();
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvToolBlock.SvInnerToolBlock OutputTool
        {
            get { return outputTool; }
            set
            {
                outputTool = value;
                //RedrawAllNode();
            }
        }

        void InitJob()
        {
            job = new MvJob();
            this.AfterSelect += VJobList_AfterSelect;
            this.NodeMouseDoubleClick += SvToolBlockTreeView_NodeMouseDoubleClick;
        }

        MvJob job;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvJob Job
        {
            get { return job; }
            set
            {
                lock (drawLock)
                {
                    job = value;

                    if (job == null || job.ToolList == null) return;

                    job.RestoreLink();
                    RedrawAllNode();
                }
            }
        }

        void VJobList_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode selectedRoot = GetRootNode(e.Node);
            int index = selectedRoot.Index;

            MvToolBase tool;

            if (inputTool != null && SelectedNode.Level == 0) index -= 1;

            if (index < 0)
                tool = InputTool;
            else if (index >= job.ToolList.Count)
                tool = OutputTool;
            else
                tool = job.ToolList[index];

            NotifyToolSelect(sender, tool);

        }

        public delegate void ToolSelectHandler(object sender, MvToolBase tool);
        public event ToolSelectHandler ToolSelect;

        void NotifyToolSelect(object sender, MvToolBase tool)
        {
            if (ToolSelect != null)
                ToolSelect(sender, tool);
        }

        void SvToolBlockTreeView_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            TreeNode selectedRoot = GetRootNode(SelectedNode);
            int index = selectedRoot.Index;

            if (inputTool != null && SelectedNode.Level == 0) index -= 1;
            if ((index < 0 || index >= job.ToolList.Count) && SelectedNode.Level == 0) return;
            //SvToolBase tool = job.ToolList[index];
            //daviddang
            MvToolBase tool = SelectedNode.Tag as MvToolBase;
            NotifyToolDoubleClick(sender, tool);
        }

        public delegate void ToolDoubleClickHandler(object sender, MvToolBase tool);
        public event ToolDoubleClickHandler ToolDoubleClick;

        void NotifyToolDoubleClick(object sender, MvToolBase tool)
        {
            MvToolBlockTreeView _tool = sender as MvToolBlockTreeView; //daviddang
            TreeNode node = _tool.SelectedNode;
            if (ToolDoubleClick != null)
                ToolDoubleClick(sender, (MvToolBase)node.Tag);
        }

        public Dictionary<string, List<Link>>[] ListLink;
        //public Dictionary<string, List<Link>>[] ListLink = new Dictionary<string, List<Link>>[1];
        List<MvToolBase> JobContainInOut;

        //tao TreeNode tu SvIf tool
        private TreeNode BuildTreeNode(TreeNode node, MvIf tool)
        {
            //TreeNode chilNode = MakeNode(tool);
            node = MakeNode(tool);
            //node.Nodes["Condition 1"].Tag = tool.Condition1 != null ? tool.Condition1 : "Condition 1";
            //node.Nodes["Condition 2"].Tag = tool.Condition1 ?? "Condition 2";
            node.Nodes["True"].Tag = tool.ToolJobTrue;
            node.Nodes["False"].Tag = tool.ToolJobFalse;
            MvIf ifTool = tool as MvIf;
            if (ifTool.ToolJobTrue.ToolList.Count > 0)
            {
                foreach (MvToolBase m_tool in ifTool.ToolJobTrue.ToolList)
                {
                    if (m_tool != null)
                    {
                        if (m_tool is MvIf)
                        {
                            node.Nodes["True"].Nodes.Add(BuildTreeNode(node, (MvIf)m_tool));
                        }
                        else if (m_tool is MvFor)
                        {
                            node.Nodes["True"].Nodes.Add(BuildTreeNode(node, (MvFor)m_tool));
                        }
                        else
                        {
                            node.Nodes["True"].Nodes.Add(MakeNode(m_tool));
                        }
                    }
                }

            }
            if (ifTool.ToolJobFalse.ToolList.Count > 0)
            {
                foreach (MvToolBase m_tool in ifTool.ToolJobFalse.ToolList)
                {
                    if (m_tool != null)
                    {
                        if (m_tool is MvIf)
                        {

                            node.Nodes["False"].Nodes.Add(BuildTreeNode(node, (MvIf)m_tool));
                        }
                        else if (m_tool is MvFor)
                        {
                            node.Nodes["False"].Nodes.Add(BuildTreeNode(node, (MvFor)m_tool));
                        }
                        else
                        {
                            node.Nodes["False"].Nodes.Add(MakeNode(m_tool));
                        }
                    }
                }
            }

            return node;
        }
        //tao TreeNode tu SvFor tool
        private TreeNode BuildTreeNode(TreeNode node, MvFor tool)
        {
            //TreeNode chilNode = MakeNode(tool);
            node = MakeNode(tool);
            //node.Nodes["Condition 1"].Tag = tool.Condition1 != null ? tool.Condition1 : "Condition 1";
            //node.Nodes["Condition 2"].Tag = tool.Condition1 ?? "Condition 2";
            node.Nodes["For Region"].Tag = tool.ToolJob;
            MvFor forTool = tool as MvFor;
            if (forTool.ToolJob.ToolList.Count > 0)
            {
                foreach (MvToolBase m_tool in forTool.ToolJob.ToolList)
                {
                    if (m_tool != null)
                    {
                        if (m_tool is MvFor)
                        {
                            node.Nodes["For Region"].Nodes.Add(BuildTreeNode(node, (MvFor)m_tool));
                        }
                        else if (m_tool is MvIf)
                        {
                            node.Nodes["For Region"].Nodes.Add(BuildTreeNode(node, (MvIf)m_tool));
                        }
                        else
                        {
                            node.Nodes["For Region"].Nodes.Add(MakeNode(m_tool));
                        }
                    }
                }
            }
            return node;
        }
        //lấy các tool trong list kể cả tool con
        IEnumerable<MvToolBase> GetAllTools(MvToolBase tool)
        {
            yield return tool; // luôn trả về tool gốc

            if (tool is MvIf ifTool)
            {
                foreach (var t in ifTool.ToolJobTrue.ToolList)
                    foreach (var child in GetAllTools(t))
                        yield return child;

                foreach (var t in ifTool.ToolJobFalse.ToolList)
                    foreach (var child in GetAllTools(t))
                        yield return child;
            }
        }



        //Old code
        //public void RedrawAllNode()
        //{
        //    int rootIndex = 0;
        //    int childIndex = -1;
        //    int topIndex = 0;
        //    int topChildIndex = -1;

        //    if (SelectedNode != null) // 현재 선택된 값 저장
        //    {
        //        rootIndex = GetRootNode(SelectedNode).Index;
        //        if (SelectedNode.Level == 1)
        //            childIndex = SelectedNode.Index;
        //    }

        //    if (TopNode != null) // 현재 TopNode 저장
        //    {
        //        topIndex = GetRootNode(TopNode).Index;
        //        if (TopNode.Level == 1)
        //            topChildIndex = TopNode.Index;
        //    }

        //    if (job == null) return;

        //    JobContainInOut = new List<SvToolBase>();
        //    if (inputTool != null) JobContainInOut.Add(inputTool);
        //    JobContainInOut.AddRange(job.ToolList);
        //    if (outputTool != null) JobContainInOut.Add(outputTool);

        //    if (JobContainInOut.Count == 0) return;

        //    ////////// Node 만들기
        //    List<TreeNode> listTree = new List<TreeNode>();

        //    foreach (SvToolBase tool in JobContainInOut)
        //    {
        //        if (tool == null) continue;
        //        TreeNode toolNode = new TreeNode();
        //        if (tool is SvIf) //daviddang
        //        {
        //            toolNode = BuildTreeNode(toolNode, (SvIf)tool);
        //        }
        //        else
        //        {
        //            toolNode = MakeNode(tool);

        //        }
        //        if (SelectedNode != null)
        //        {
        //            SelectedNode.Nodes.Add(MakeNode(tool));

        //        }
        //        listTree.Add(toolNode);
        //    }




        //    if (outputTool != null)
        //    {
        //        List<TreeNode> deleteingNode = new List<TreeNode>();
        //        foreach (TreeNode node in listTree[listTree.Count - 1].Nodes)
        //        {
        //            if (node.ForeColor == System.Drawing.Color.Blue)
        //                deleteingNode.Add(node);
        //        }

        //        foreach (TreeNode node in deleteingNode)
        //        {
        //            listTree[listTree.Count - 1].Nodes.Remove(node);
        //        }
        //    }

        //    TreeNode[] treeArray = listTree.ToArray();
        //    mDrawNode = false;

        //    BeginUpdate();
        //    Nodes.Clear();
        //    Nodes.AddRange(treeArray);
        //    EndUpdate();

        //    ////////// LinkList 만들기
        //    MaxLinkWidth = 10;

        //    ListLink = new Dictionary<string, List<Link>>[JobContainInOut.Count];
        //    for (int i = 0; i < ListLink.Length; i++)
        //        ListLink[i] = new Dictionary<string, List<Link>>();

        //    for (int start = 0; start < JobContainInOut.Count; start++)
        //    {
        //        for (int end = JobContainInOut.Count - 1; end > start; end--)
        //        {
        //            foreach (var inparam in JobContainInOut[end].inParams)
        //            {
        //                if (inparam.Value == null) continue;

        //                SvToolBase startTool = JobContainInOut[start];
        //                SvToolBase endtool = inparam.Value.Instance as SvToolBase;

        //                if (!Nodes[start].Nodes.ContainsKey(inparam.Value.FieldName))
        //                    continue;

        //                if (startTool.HashCode == inparam.Value.InstanceHashcode)// && e.Node.Name == inparam.Value.FieldName)
        //                {
        //                    int width;
        //                    if (!ListLink[start].ContainsKey(inparam.Value.FieldName))
        //                    {
        //                        MaxLinkWidth += 10;
        //                        width = MaxLinkWidth;
        //                        ListLink[start].Add(inparam.Value.FieldName, new List<Link>());
        //                    }
        //                    else
        //                        width = ListLink[start][inparam.Value.FieldName][0].Width;

        //                    Link link = new Link(Nodes[start].Nodes[inparam.Value.FieldName], Nodes[end].Nodes[inparam.Key], width);
        //                    ListLink[start][inparam.Value.FieldName].Add(link);
        //                }
        //            }
        //        }
        //    }

        //    for (int start = 0; start < JobContainInOut.Count; start++)
        //    {
        //        foreach (var v in ListLink[start].Values)
        //        {
        //            if (v.Count > 0) v[0].IsLast = true;
        //            else v[0].IsLast = false;
        //        }
        //    }

        //    ////////// 기존 선택된 노드 다시 선택
        //    try
        //    {
        //        TreeNode selectedNode = null;
        //        if (Nodes.Count > 0)
        //        {
        //            if (rootIndex < Nodes.Count)
        //            {
        //                selectedNode = Nodes[rootIndex];
        //                if (childIndex != -1 && childIndex < selectedNode.Nodes.Count)
        //                    selectedNode = selectedNode.Nodes[childIndex];
        //            }
        //            else if (rootIndex == Nodes.Count)
        //                selectedNode = Nodes[--rootIndex];
        //        }

        //        mDrawNode = true;

        //        if (selectedNode != null)
        //            SelectedNode = selectedNode;

        //        if (topIndex > -1 && topIndex < Nodes.Count)
        //        {
        //            TopNode = Nodes[topIndex];
        //            if (topChildIndex > -1 && topChildIndex < TopNode.Nodes.Count)
        //                TopNode = TopNode.Nodes[topChildIndex];
        //        }

        //        for (int i = 0; i < ListLink.Length; i++)
        //        {
        //            foreach (var v in ListLink[i].Values)
        //            {
        //                for (int j = 0; j < v.Count; j++)
        //                {
        //                    OnDrawNode(new DrawTreeNodeEventArgs(this.CreateGraphics(), v[0].StartNode, this.Bounds, TreeNodeStates.Hot));
        //                    return;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return;
        //    }
        //}


        public void RedrawAllNode()
        {
            int linkindex = 0;
            int rootIndex = 0;
            int childIndex = -1;
            int topIndex = 0;
            int topChildIndex = -1;

            if (SelectedNode != null) // Lưu giá trị hiện đang được chọn
            {
                rootIndex = GetRootNode(SelectedNode).Index;
                if (SelectedNode.Level == 1)
                    childIndex = SelectedNode.Index;
            }

            if (TopNode != null) // Lưu TopNode hiện tại
            {
                topIndex = GetRootNode(TopNode).Index;
                if (TopNode.Level == 1)
                    topChildIndex = TopNode.Index;
            }

            if (job == null) return;

            //JobContainInOut = new List<SvToolBase>();
            //if (inputTool != null) JobContainInOut.Add(inputTool);
            //JobContainInOut.AddRange(job.ToolList);
            //if (outputTool != null) JobContainInOut.Add(outputTool);
            //if (JobContainInOut.Count == 0) return;
            List<MvToolBase> listTool = new List<MvToolBase>();
            //nếu là blockTool thì thêm input && output vào ListTool
            if (inputTool != null) listTool.Add(inputTool);
            listTool.AddRange(job.ToolList);
            if (outputTool != null) listTool.Add(outputTool);



            if (listTool.Count == 0) return;
            ////////// Node 만들기
            List<TreeNode> listTree = new List<TreeNode>();

            foreach (MvToolBase tool in listTool)
            {
                if (tool == null) continue;
                TreeNode toolNode = new TreeNode();
                if (tool is MvIf) //daviddang
                {
                    toolNode = BuildTreeNode(toolNode, (MvIf)tool);
                }
                else if (tool is MvFor)
                {
                    toolNode = BuildTreeNode(toolNode, (MvFor)tool);
                }
                else
                {
                    toolNode = MakeNode(tool);

                }
                if (SelectedNode != null)
                {
                    SelectedNode.Nodes.Add(MakeNode(tool));

                }
                listTree.Add(toolNode);
            }




            if (outputTool != null)
            {
                List<TreeNode> deleteingNode = new List<TreeNode>();
                foreach (TreeNode node in listTree[listTree.Count - 1].Nodes)
                {
                    if (node.ForeColor == System.Drawing.Color.Blue)
                        deleteingNode.Add(node);
                }

                foreach (TreeNode node in deleteingNode)
                {
                    listTree[listTree.Count - 1].Nodes.Remove(node);
                }
            }

            TreeNode[] treeArray = listTree.ToArray();
            mDrawNode = false;

            BeginUpdate();
            this.Nodes.Clear();
            this.Nodes.AddRange(treeArray);
            EndUpdate();

            ////////// LinkList 만들기
            MaxLinkWidth = 230;

            //daviddang
            JobContainInOut = new List<MvToolBase>();
            if (inputTool != null) JobContainInOut.Add(inputTool);
            JobContainInOut.AddRange(job.ToolList);
            if (outputTool != null) JobContainInOut.Add(outputTool);
            if (JobContainInOut.Count == 0) return;

            ////khai bao listLink
            ListLink = new Dictionary<string, List<Link>>[1000];//daviddang edit test
            for (int i = 0; i < 1000; i++) //daviddang edit test
            { ListLink[i] = new Dictionary<string, List<Link>>(); }
            //ListLink[0] = new Dictionary<string, List<Link>>();
            //Array.Clear(ListLink, 0, ListLink.Length);



            //daviddang
            foreach (TreeNode srcNode in this.Nodes.GetAllNodes())
            {
                MvToolBase srcTool = srcNode.Tag as MvToolBase;
                if (srcNode.Tag is MvIf || srcNode.Text == "True" || srcNode.Text == "False") continue;
                if (srcNode.Tag is MvFor || srcNode.Text == "For Region") continue;
                foreach (TreeNode dstnode in this.Nodes.GetAllNodes())
                {
                    if (dstnode.Text == "True" || dstnode.Text == "False") continue;
                    if (dstnode.Text == "For Region") continue;
                    MvToolBase dstTool = dstnode.Tag as MvToolBase;
                    foreach (var inparam in dstTool.inParams) //lặp qua các phần tử inParams trong DstTool
                    {
                        if (inparam.Value == null) continue;
                        if (!srcNode.Nodes.ContainsKey(inparam.Value.FieldName)) continue; //kiểm tra xem trong Node[Start] có node input&output nào có tên == Node[end].inparam.Value.FieldName
                        if (srcTool.HashCode == inparam.Value.InstanceHashcode)// && e.Node.Name == inparam.Value.FieldName) kiểm tra mã băm của SrcTool == Dst Tool
                        {
                            //Console.WriteLine(srcNode.Text);
                            int width;
                            //// tăng kích thước mảng lên newSize
                            //Array.Resize(ref ListLink, ListLink.Count());
                            //ListLink[ListLink.Count()] = new Dictionary<string, List<Link>>();

                            if (!ListLink[linkindex].ContainsKey(inparam.Value.FieldName))//ListLink[Start] không chứa inparam.Value.FieldName
                            {
                                MaxLinkWidth += 10;
                                width = MaxLinkWidth;
                                ListLink[linkindex].Add(inparam.Value.FieldName, new List<Link>());// thêm key vào  ListLink[Start]
                            }
                            else
                                width = ListLink[linkindex][inparam.Value.FieldName][0].Width;

                            Link link = new Link(srcNode.Nodes[inparam.Value.FieldName], dstnode.Nodes[inparam.Key], width); //tạo Link Node[Start] với Node[end]
                            ListLink[linkindex][inparam.Value.FieldName].Add(link); //thêm link vào List<Link>

                            linkindex++;

                        }
                    }
                }
            }

            for (int _start = 0; _start < ListLink.Length; _start++)
            {
                if (ListLink[_start] != null)
                {
                    foreach (var v in ListLink[_start].Values)
                    {
                        if (v.Count > 0) v[0].IsLast = true;
                        else v[0].IsLast = false;
                    }
                }
            }


            ////////// 기존 선택된 노드 다시 선택
            try
            {
                TreeNode selectedNode = null;
                if (this.Nodes.Count > 0)
                {
                    if (rootIndex < this.Nodes.Count)
                    {
                        selectedNode = this.Nodes[rootIndex];
                        if (childIndex != -1 && childIndex < selectedNode.Nodes.Count)
                            selectedNode = selectedNode.Nodes[childIndex];
                    }
                    else if (rootIndex == this.Nodes.Count)
                        selectedNode = this.Nodes[--rootIndex];
                }

                mDrawNode = true;

                if (selectedNode != null)
                    SelectedNode = selectedNode;

                if (topIndex > -1 && topIndex < this.Nodes.Count)
                {
                    TopNode = this.Nodes[topIndex];
                    if (topChildIndex > -1 && topChildIndex < TopNode.Nodes.Count)
                        TopNode = TopNode.Nodes[topChildIndex];
                }

                for (int i = 0; i < ListLink.Length; i++)
                {
                    foreach (var v in ListLink[i].Values)
                    {
                        for (int j = 0; j < v.Count; j++)
                        {
                            OnDrawNode(new DrawTreeNodeEventArgs(this.CreateGraphics(), v[0].StartNode, this.Bounds, TreeNodeStates.Hot));
                            return;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                return;
            }
        }

        //void RedrawAllNode(SvJob newJob)
        //{
        //    BeginUpdate();
        //    Nodes.Clear();

        //    MaxLinkWidth = 0;
        //    NodeLinkWidth = new Dictionary<string,int>[newJob.ToolList.Count + 2];
        //    for (int i = 0; i < NodeLinkWidth.Length; i++)
        //        NodeLinkWidth[i] = new Dictionary<string, int>();

        //    if (inputTool != null)
        //        Nodes.Add(MakeNode(inputTool));

        //    SelectedNode = null;    //선택된 노드 초기화해야 맨땅에서부터 그려짐.

        //    foreach (SvToolBase tool in newJob.ToolList)
        //    {
        //        if (tool == null) continue;
        //        AddNode(job.ToolList.Count,tool);
        //    }

        //    if (outputTool != null)
        //        Nodes.Add(MakeNode(outputTool));

        //    EndUpdate();
        //    Update();
        //}
        #endregion

        #region Drag&Drop Event
        void InitDrag()
        {
            this.AllowDrop = true;
            this.DrawMode = TreeViewDrawMode.OwnerDrawText;
            this.ItemDrag += NTreeView_ItemDrag;
            this.DragDrop += NTreeView_DragDrop;
            this.DragEnter += NTreeView_DragEnter;
            this.DragOver += NTreeView_DragOver;


            InitPen();
        }

        System.Drawing.Pen linkPen;

        void InitPen()
        {
            linkPen = new System.Drawing.Pen(System.Drawing.Color.Black);
            linkPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            linkPen.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
        }

        Dictionary<string, int>[] NodeLinkWidth;
        int MaxLinkWidth = 0;
        object drawLock = new object();

        bool mDrawNode = false;
        protected override void OnDrawNode(DrawTreeNodeEventArgs e)
        {

            //e.DrawDefault = true;//daviddang
            if (ListLink == null) return;

            lock (drawLock)
            {
                ExpandAll();
                e.DrawDefault = true;

                if (!mDrawNode) return;

                TreeNode bottom = null;
                bottom = TopNode;
                while (true)
                {
                    TreeNode newbottom = bottom.NextVisibleNode;
                    if (newbottom == null || !newbottom.IsVisible)
                        break;
                    bottom = newbottom;
                }

                if (e.Node.Level % 2 == 0)
                {
                    int ellipseSize = 7;
                    int posX = e.Node.Bounds.Location.X + e.Node.Bounds.Width + 2;
                    int posY = e.Node.Bounds.Location.Y + (e.Node.Bounds.Height - ellipseSize) / 2;

                    try //daviddang
                    {

                        // IsSuccess 등록
                        if (JobContainInOut[e.Node.Index].lastRunSuccess)
                            e.Graphics.FillEllipse(System.Drawing.Brushes.LimeGreen, posX, posY, ellipseSize, ellipseSize);
                        else
                            e.Graphics.FillEllipse(System.Drawing.Brushes.OrangeRed, posX, posY, ellipseSize, ellipseSize);
                    }
                    catch (Exception)
                    {

                    }

                }

                // 깜박임 개선을 위해 System에서 호출되는 경우 중 첫번째와 마지막(Scroll 때문에...) 경우만 처리
                if (e.State == 0 && e.Node != TopNode && e.Node != bottom && !IsDragDrop)
                    return;

                //for (int i = 0; i < Math.Min(this.Nodes.Count, JobContainInOut.Count); i++)
                //{
                foreach (var item in ListLink) //daviddang
                {
                    foreach (List<Link> links in item.Values)
                    {
                        if (links.FindIndex(ss => ss.IsChanged == true) < 0 && e.State == TreeNodeStates.Marked)
                            continue;

                        for (int j = 0; j < links.Count; j++)
                        {
                            links[j].IsChanged = true;
                            links[j].DrawLine(e.Graphics);
                        }
                        // HighLight 일 경우 한번 더 그려준다.
                        for (int j = 0; j < links.Count; j++)
                        {
                            if (links[j].IsHighLight)
                                links[j].DrawLine(e.Graphics);
                        }
                    }
                }
                //}
            }
        }

        private void SvToolBlockTreeView_MouseDown(object sender, MouseEventArgs e) //sự kiện mouse down 
        {
            if (ListLink == null) return;
            for (int i = 0; i < ListLink.Length; i++)
            {
                foreach (List<Link> links in ListLink[i].Values)
                {
                    for (int j = 0; j < links.Count; j++)
                    {
                        if (links[j].IsHighLight)
                        {
                            NTreeView_ItemDrag(links[j], new ItemDragEventArgs(e.Button));
                            return;
                        }
                    }
                }
            }
        }

        void NTreeView_ItemDrag(object sender, ItemDragEventArgs e)
        {
            if (e.Item is TreeNode)
            {
                TreeNode node = e.Item as TreeNode;
                bool islinkdrag = false;
                SelectedNode = node;

                if (node.Level % 2 == 0)
                {
                    DoDragDrop(node, DragDropEffects.All);
                }
                else if (node.Level % 2 != 0)
                {
                    if (node.ForeColor != System.Drawing.Color.Red)
                        DoDragDrop(node, DragDropEffects.Link);
                }
                else
                    throw new Exception("노드 레벨은 0, 1이 한계. 이거 의외는 프로그래밍 에러");
            }
            else if (e.Item == null)
            {
                Link link = sender as Link;
                DoDragDrop(link, DragDropEffects.Link);
            }
        }

        void NTreeView_DragOver(object sender, DragEventArgs e)
        {

            System.Drawing.Point ClientPoint = this.PointToClient(new System.Drawing.Point(e.X, e.Y));
            this.SelectedNode = this.GetNodeAt(ClientPoint);

            if (SelectedNode != null)
            {
                int index = this.Nodes.IndexOf(GetRootNode(this.SelectedNode)) - 1;
                if (index < 0) index = 0;

                //this.Nodes[index].EnsureVisible(); //cuuộn Scroll Bar xuống dưới

                if (e.Effect == DragDropEffects.All || e.Effect == DragDropEffects.Move)
                {
                    if (e.KeyState == 9)
                        e.Effect = DragDropEffects.All;
                    else
                        e.Effect = DragDropEffects.Move;
                    OnValidated(null);
                }
            }else
            {

                // Chuột không nằm trên node → auto scroll
                if (this.TopNode?.NextVisibleNode != null)
                {
                    this.TopNode = this.TopNode.NextVisibleNode;
                }
            }
        }

        bool IsDragDrop = false;
        void NTreeView_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.AllowedEffect;
            IsDragDrop = true;
            //딱히 안씀?
            //SvToolBase tool = e.Data.GetData(typeof(SvToolBase)) as SvToolBase;
        }

        void NTreeView_DragDrop(object sender, DragEventArgs e)
        {

            IsDragDrop = false;
            //BeginUpdate();
            switch (e.Effect)
            {
                case DragDropEffects.Copy:
                    AddTool(e);
                    break;
                case DragDropEffects.Move:
                    ChangeJobOrder(e);
                    break;
                case DragDropEffects.Link:
                    if (e.Data.GetData(typeof(TreeNode)) == null)// Kiểm tra xem dữ liệu được kéo vào không phải là một TreeNode
                    {
                        Link link = e.Data.GetData(typeof(Link)) as Link;
                        e.Data.SetData(typeof(TreeNode), link.StartNode);// = new DragEventArgs(link.StartNode, 0, e.X, e.Y, DragDropEffects.Link, DragDropEffects.Link);
                    }
                    //AddLink(e.Data.GetData(typeof(Link) as Link);

                    LinkParameters(e);
                    break;
                case DragDropEffects.All:
                    //display update 하는동안 바로 또 Drag할 때
                    //Drag&Drop effect 시작을 All로 하다보니(이렇게 하지 않으면 Mouse에 '+' 표시가 안됨)
                    //가끔 Move인데 Copy로 들어오는 경우가 있어서... -,.- 한번 더 Filtering
                    if (e.KeyState == 8)
                        CopyTool(e);
                    else
                        ChangeJobOrder(e);
                    break;
            }
        }

        private void AddLink(Link link)
        {
            throw new NotImplementedException();
        }

        Func<System.Reflection.Assembly, string, bool, Type> typeResolve = (assembly, ttypeName, isIgnore) =>
        {
            if (assembly == null)
            {
                string assemblyName = ttypeName.Substring(0, ttypeName.IndexOf('.'));

                System.Reflection.Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
                foreach (System.Reflection.Assembly assem in assemblies)
                {
                    if (assem.GetName().Name == assemblyName)
                    {
                        assembly = assem;
                        break;
                    }
                }
            }

            return assembly.GetType(ttypeName, isIgnore);
        };

        //insert Node If tool
        bool insertNode(TreeNode SelectedNode, MvToolBase tool, bool listState)
        {
            int listSelect = listState ? 1 : 0;
            MvToolBase currentTool;
            int childIndex = 0;
            TreeNode newToolNode = MakeNode(tool);
            if (tool is MvIf)
            {
                MvIf toolIf = tool as MvIf;
                newToolNode.Nodes["True"].Tag = toolIf.ToolJobTrue;
                newToolNode.Nodes["False"].Tag = toolIf.ToolJobFalse;
            }
            TreeNode currentNode;
            if (SelectedNode.Parent.Text == "True" || SelectedNode.Parent.Text == "False") //select Node != Node true (child Node of Node true)
            {
                currentNode = SelectedNode.Parent; //Node true in parent node
                if (SelectedNode.Index > currentNode.Nodes.Count) { childIndex = currentNode.Nodes.Count; } else { childIndex = SelectedNode.Index; }
            }
            else if (SelectedNode.Text == "True" || SelectedNode.Text == "False")
            {
                currentNode = SelectedNode; //Node true in parent node
                childIndex = currentNode.Nodes.Count; // insert Node to End List
            }
            else { return false; }

            currentNode.Nodes.Insert(childIndex, newToolNode);
            currentNode.Nodes[childIndex].Tag = tool;
            currentTool = GetToolFromNode(currentNode.Parent);
            //currentTool.ToolLists[listSelect].Insert(childIndex, tool);
            MvIf ifTool = currentTool as MvIf;
            if (listState)//daviddang
            { ifTool.ToolJobTrue.ToolList.Insert(childIndex, tool); }
            else
            { ifTool.ToolJobFalse.ToolList.Insert(childIndex, tool); }
            return true;
        }

        //insert Node For tool
        bool insertNode(TreeNode SelectedNode, MvToolBase tool)
        {

            MvToolBase currentTool;
            int childIndex = 0;
            TreeNode newToolNode = MakeNode(tool);
            if (tool is MvFor)
            {
                MvFor toolFor = tool as MvFor;
                newToolNode.Nodes["For Region"].Tag = toolFor.ToolJob;
            }
            TreeNode currentNode;
            if (SelectedNode.Parent.Text == "For Region") //select Node != Node true (child Node of Node true)
            {
                currentNode = SelectedNode.Parent; //Node true in parent node
                if (SelectedNode.Index > currentNode.Nodes.Count) { childIndex = currentNode.Nodes.Count; } else { childIndex = SelectedNode.Index; }
            }
            else if (SelectedNode.Text == "For Region")
            {
                currentNode = SelectedNode; //Node true in parent node
                childIndex = currentNode.Nodes.Count; // insert Node to End List
            }
            else { return false; }

            currentNode.Nodes.Insert(childIndex, newToolNode);
            currentNode.Nodes[childIndex].Tag = tool;
            currentTool = GetToolFromNode(currentNode.Parent);
            MvFor ForTool = currentTool as MvFor;
            ForTool.ToolJob.ToolList.Insert(childIndex, tool);
            return true;
        }

        public void AddTool(DragEventArgs e)
        {
            string typeName = null;
            string[] formats = e.Data.GetFormats(true);
            foreach (string format in formats)
            {
                try
                {
                    if (Type.GetType(format, null, typeResolve).BaseType == typeof(MvToolBase))
                    {
                        typeName = format;
                        break;
                    }
                }
                catch { continue; }
            }

            if (string.IsNullOrEmpty(typeName)) return;

            try
            {
                MvToolBase tool = Activator.CreateInstance(Type.GetType(typeName, null, typeResolve)) as MvToolBase;

                System.Drawing.Point ClientPoint = this.PointToClient(new System.Drawing.Point(e.X, e.Y));
                this.SelectedNode = this.GetNodeAt(ClientPoint);
                if (SelectedNode == null)
                {
                    if (job == null)
                    {
                        job = new MvJob();
                        job.ToolList.Clear();
                    }

                    int index = this.Nodes.Count;

                    AddNode(index, tool);
                }
                else//insert tool
                {
                    ////daviddang 
                    //TreeNode parentNode = GetRootNode(SelectedNode);
                    TreeNode parentNode = SelectedNode.Parent;
                    //int _index = parentNode.Index;
                    if (parentNode != null && parentNode.Name == "If" && SelectedNode.Parent != null)
                    {
                        //TreeNode newToolNode = MakeNode(tool);
                        //SvToolBase currentTool;
                        //int childIndex = 0;

                        if (SelectedNode.Parent.Text == "True" || SelectedNode.Text == "True")
                        {
                            insertNode(SelectedNode, tool, true);
                        }
                        else if (SelectedNode.Parent.Text == "False" || SelectedNode.Text == "False")
                        {
                            insertNode(SelectedNode, tool, false);
                        }
                        this.ExpandAll();

                    }
                    else if (parentNode != null && (SelectedNode.Parent.Name == "True" || SelectedNode.Parent.Name == "False"))
                    {
                        if (parentNode != null && SelectedNode.Parent != null)
                        {
                            //TreeNode newToolNode = MakeNode(tool);
                            //SvToolBase currentTool;
                            //int childIndex = 0;

                            if (SelectedNode.Parent.Text == "True" || SelectedNode.Text == "True")
                            {
                                insertNode(SelectedNode, tool, true);
                            }
                            else if (SelectedNode.Parent.Text == "False" || SelectedNode.Text == "False")
                            {
                                insertNode(SelectedNode, tool, false);
                            }
                            this.ExpandAll();
                        }

                    }
                    else if (parentNode != null && (parentNode.Name == "For" || parentNode.Name == "For Region") && SelectedNode.Parent != null)
                    {
                        insertNode(SelectedNode, tool);
                        this.ExpandAll();
                    }
                    else
                    {
                        int index = GetRootNode(SelectedNode).Index;
                        if (index > this.Nodes.Count) return;
                        AddNode(index, tool);
                    }

                }

                NotifyToolSelect(this, tool);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        void CopyTool(DragEventArgs e)
        {
            TreeNode draggedNode = e.Data.GetData(typeof(TreeNode)) as TreeNode;
            int draggedIndex = draggedNode.Index;
            if (inputTool != null) draggedIndex -= 1;

            if (draggedIndex < 0 || draggedIndex >= job.ToolList.Count) return;
            MvToolBase draggedTool = job.ToolList[draggedIndex];

            System.Drawing.Point ClientPoint = this.PointToClient(new System.Drawing.Point(e.X, e.Y));
            SelectedNode = this.GetNodeAt(ClientPoint);
            TreeNode selectedRoot = GetRootNode(SelectedNode);

            MvToolBase copyTool = MvFunc.CopyTool(draggedTool, draggedTool.GetType()) as MvToolBase;

            int selectedIndex;
            if (selectedRoot == null)
            {
                selectedIndex = this.GetNodeCount(false);
            }
            else
                selectedIndex = selectedRoot.Index;

            if (inputTool != null) selectedIndex -= 1;
            if (selectedIndex < 0) return;
            if (selectedIndex > job.ToolList.Count)
                selectedIndex = job.ToolList.Count - 1;

            if (inputTool != null) selectedIndex += 1;

            AddNode(selectedIndex, copyTool);
            SelectedNode = this.Nodes[selectedIndex];

            foreach (KeyValuePair<string, InputParams> kv in draggedTool.inParams)
            {
                if (kv.Value == null) continue;
                copyTool.inParams[kv.Key] = new InputParams(kv.Value.Instance, kv.Value.FieldName);
                copyTool.GetInParams();
                copyTool.Run();
            }

            NotifyToolSelect(this, copyTool);
            RedrawAllNode();
        }

        void ChangeJobOrder(DragEventArgs e)
        {
            TreeNode draggedNode = e.Data.GetData(typeof(TreeNode)) as TreeNode;

            System.Drawing.Point ClientPoint = this.PointToClient(new System.Drawing.Point(e.X, e.Y));
            SelectedNode = this.GetNodeAt(ClientPoint);
            if (SelectedNode == null) return;
            int dragIndex = draggedNode.Index;
            int SelectIndex = SelectedNode.Index;

            //daviddang
            MvToolBase dragTool = draggedNode.Tag as MvToolBase;
            MvToolBase SelectTool = SelectedNode.Tag as MvToolBase;
            //TreeNode SubNode = SelectedNode;
            //SelectedNode = draggedNode;
            //draggedNode = SubNode;

            List<MvToolBase> l_dragTool;
            List<MvToolBase> l_SelectTool;
            if (draggedNode.Level == 0) l_dragTool = Job.ToolList;
            else
            {
                if (draggedNode.Text == "True" || draggedNode.Text == "False" || draggedNode.Text == "For Region")
                {
                    l_dragTool = (draggedNode.Tag as MvJob).ToolList;
                }
                else
                {
                    l_dragTool = (draggedNode.Parent.Tag as MvJob).ToolList;
                }

            }

            if (SelectedNode.Level == 0) l_SelectTool = Job.ToolList;
            else
            {
                if (SelectedNode.Text == "True" || SelectedNode.Text == "False" || SelectedNode.Text == "For Region")
                {
                    l_SelectTool = (SelectedNode.Tag as MvJob).ToolList;
                }
                else
                {
                    l_SelectTool = (SelectedNode.Parent.Tag as MvJob).ToolList;
                }

            }
            l_dragTool.Remove(dragTool);
            if (dragIndex <= l_dragTool.Count)
                l_dragTool.Insert(dragIndex, SelectTool);
            else
                l_dragTool.Insert(l_dragTool.Count, SelectTool);

            l_SelectTool.Remove(SelectTool);
            if (SelectIndex <= l_SelectTool.Count)
                l_SelectTool.Insert(SelectIndex, dragTool);
            else
                l_SelectTool.Insert(l_SelectTool.Count, dragTool);




            //int draggedIndex = draggedNode.Index;
            //if (inputTool != null) draggedIndex -= 1;

            //if (draggedIndex < 0 || draggedIndex >= job.ToolList.Count) return;
            //SvToolBase draggedTool = job.ToolList[draggedIndex];
            //draggedNode.Tag = draggedTool;
            //TreeNode selectedRoot = GetRootNode(SelectedNode);
            //int selectedIndex;
            //if (selectedRoot == null)
            //{
            //    selectedIndex = this.GetNodeCount(false) - 1;
            //}
            //else
            //    selectedIndex = selectedRoot.Index;

            //if (inputTool != null) selectedIndex -= 1;
            //if (draggedIndex == selectedIndex) return;

            //if (selectedIndex < 0) return;
            //if (selectedIndex >= job.ToolList.Count)
            //    selectedIndex = job.ToolList.Count - 1;
            //SvToolBase selectedTool = job.ToolList[selectedIndex];

            //if (selectedTool is SvToolBlock.SvInnerToolBlock)
            //    return;

            ////잡체인지 먼저 해야함
            //job.ToolList.Remove(draggedTool);
            //job.ToolList.Insert(selectedIndex, draggedTool);

            //그다음에 노드 변경
            //this.Nodes.Remove(draggedNode);
            //if (inputTool != null) selectedIndex += 1;
            //this.Nodes.Insert(selectedIndex, draggedNode);
            //SelectedNode = draggedNode;

            RedrawAllNode();
        }

        //daviddang
        List<int> GetIndexIfTool(TreeNode node)
        {
            List<int> index = new List<int>();

            if (node == null)
                return index;

            // Duyệt ngược lên tới root
            TreeNode current = node.Parent;
            while (current != null)
            {
                if (current.Text == "If")
                {
                    index.Add(current.Index);
                }
                current = current.Parent;
            }

            return index;
        }
        List<int> GetNodeIndexPath(TreeNode node)
        {
            List<int> indices = new List<int>();

            TreeNode current = node;
            while (current != null)
            {
                indices.Insert(0, current.Index); // thêm vào đầu để giữ thứ tự từ root
                current = current.Parent;
            }

            return indices;
        }
        List<int> GetToolIndexPath(TreeNode Node)
        {
            List<int> NodePath = GetNodeIndexPath(Node);
            List<int> ToolPath = new List<int>();
            for (int i = 0; i < NodePath.Count; i++)
            {
                if (i % 2 == 0)
                {
                    ToolPath.Add(NodePath[i]);
                }
                else
                {
                    if (NodePath[i] == 2) { ToolPath.Add(1); } //true
                    if (NodePath[i] == 3) { ToolPath.Add(0); } //false
                }

            }
            return ToolPath;

        }


        //SvToolBase GetToolByPath(List<int> path, List<SvToolBase> jobContainInOut)
        //{
        //    SvIf toolif = null;
        //    //toolif = (SvIf)jobContainInOut[path[0]];
        //    SvToolBase currentTool = null;
        //    List<SvToolBase> listTool = null;
        //    List<List<SvToolBase>> LLToolbase = new List<List<SvToolBase>>();


        //    for (int i = 0; i < path.Count; i++)
        //    {

        //        if (i % 2 == 0) //tool
        //        {
        //            if (toolif == null)
        //            {
        //                toolif = (SvIf)jobContainInOut[path[i]];
        //                LLToolbase = toolif.ToolLists;
        //            }
        //            else
        //            {
        //                if (listTool[path[i]] is SvIf)
        //                {
        //                    toolif = (SvIf)listTool[path[i]];
        //                    LLToolbase = toolif.ToolLists;
        //                }
        //                else
        //                {
        //                    currentTool = listTool[path[i]];
        //                    return currentTool;
        //                }
        //            }

        //        }
        //        else //Node true/false
        //        {
        //            if (path[i] == 1) //true
        //            {
        //                listTool = LLToolbase[1];
        //            }
        //            else if (path[i] == 0)// false
        //            {
        //                listTool = LLToolbase[0];
        //            }
        //        }

        //    }
        //    return currentTool;
        //}



        void LinkParameters(DragEventArgs e)
        {
            TreeNode srcNode = e.Data.GetData(typeof(TreeNode)) as TreeNode; //Node nguồn

            System.Drawing.Point ClientPoint = this.PointToClient(new System.Drawing.Point(e.X, e.Y));
            SelectedNode = this.GetNodeAt(ClientPoint);                     //Node Đích
            List<int> indexNode = GetNodeIndexPath(srcNode); //daviddang
            if (SelectedNode == null || srcNode == SelectedNode) return;


            if (SelectedNode.ForeColor != System.Drawing.Color.Red) return;
            if (GetRootNode(SelectedNode).Index < GetRootNode(srcNode).Index)
                return;
            //List<int> srcIndex = getIndexIfTool(srcNode); //daviddang
            //List<int> selectIndex = new List<int>();



            int SelectedNodeindex = SelectedNode.Parent.Index;
            int srcNodeindex = srcNode.Parent.Index;

            if (inputTool != null)
            {
                SelectedNodeindex -= 1;
                srcNodeindex -= 1;
            }
            //daviddang
            MvToolBase srcTool = srcNode.Parent.Tag as MvToolBase;
            MvToolBase selectedTool = SelectedNode.Parent.Tag as MvToolBase;

            //if (outputTool != null && SelectedNodeindex >= job.ToolList.Count)
            //    selectedTool = outputTool;
            //else
            //    selectedTool = job.ToolList[SelectedNodeindex];

            //if (inputTool != null && srcNodeindex < 0)
            //    srcTool = inputTool;
            //else
            //    srcTool = job.ToolList[srcNodeindex];

            // 깜박임 개선
            if (selectedTool.inParams[SelectedNode.Text] != null && selectedTool.inParams[SelectedNode.Text].InstanceHashcode == srcTool.HashCode && selectedTool.inParams[SelectedNode.Text].FieldName == srcNode.Text)
                return;
            selectedTool.inParams[SelectedNode.Text] = new InputParams(srcTool, srcNode.Text);// tạo Tham số đầu vào cho tool đích từ tool nguồn
           //MvImage image = selectedTool.inParams[SelectedNode.Text].GetValue() as MvImage;
       
            selectedTool.GetInParams();
            RedrawAllNode();
        }
        #endregion

        public class Link
        {
            public Link(TreeNode _startNode, TreeNode _endNode, int _width)
            {
                StartNode = _startNode; EndNode = _endNode; Width = _width;
            }

            int Margin = 10;
            public TreeNode StartNode
            {
                get { return mStartNode; }
                set { mStartNode = value; }
            }
            TreeNode mStartNode;
            public TreeNode EndNode
            {
                get { return mEndNode; }
                set { mEndNode = value; }
            }
            public TreeNode mEndNode;

            public System.Drawing.Point SP
            {
                get
                {
                    if (mStartNode == null) return new System.Drawing.Point();
                    return mStartNode.Bounds.Location + new System.Drawing.Size(mStartNode.Bounds.Width + Margin, mStartNode.Bounds.Height / 2);
                }
            }
            public System.Drawing.Point EP
            {
                get
                {
                    if (mEndNode == null) return new System.Drawing.Point();
                    return mEndNode.Bounds.Location + new System.Drawing.Size(mEndNode.Bounds.Width + Margin, mEndNode.Bounds.Height / 2);
                }
            }

            public System.Drawing.Point MP1
            {
                get
                {
                    return new System.Drawing.Point(WidthMargin + Width, SP.Y);
                }
            }

            public System.Drawing.Point MP2
            {
                get
                {
                    return new System.Drawing.Point(WidthMargin + Width, EP.Y);
                }
            }

            int WidthMargin = 120;

            public int Width;
            public int Height { get { return EP.Y - SP.Y + 1; } }

            public bool IsDrawVertical;
            public bool IsHighLight;
            public bool IsChanged;

            public bool IsLast;

            int gap = 8;

            public void HighlightLink(System.Drawing.Point pt)
            {
                bool isHighLight = false;
                IsChanged = false;

                if (SP.X < pt.X && MP1.X > pt.X && SP.Y + gap > pt.Y && SP.Y - gap < pt.Y)
                    isHighLight = true;
                if (MP1.X - gap < pt.X && MP1.X + gap > pt.X && MP1.Y < pt.Y && MP2.Y > pt.Y)
                    isHighLight = true;
                if (EP.X < pt.X && MP2.X > pt.X && EP.Y + gap > pt.Y && EP.Y - gap < pt.Y)
                    isHighLight = true;

                if (isHighLight != IsHighLight)
                {
                    IsChanged = true;
                    IsHighLight = isHighLight;
                }
            }

            public void DrawLine(Graphics gdi)
            {
                if (!IsChanged) return;

                System.Drawing.Pen pSurround = new System.Drawing.Pen(System.Drawing.Color.LightYellow);
                pSurround.EndCap = LineCap.Flat;
                pSurround.LineJoin = LineJoin.Miter;
                pSurround.CompoundArray = new float[4] { 0, 0.375f, 0.625f, 1f };
                pSurround.Width = 4;

                System.Drawing.Pen pCenter = new System.Drawing.Pen(System.Drawing.Color.Blue);
                pCenter.Width = 1;

                if (IsLast)
                    IsDrawVertical = true;

                if (IsHighLight)
                {
                    pSurround.Color = System.Drawing.Color.LimeGreen;
                    IsDrawVertical = true;
                }

                if (IsDrawVertical)
                {
                    gdi.DrawLine(pSurround, MP1, MP2);
                    gdi.DrawLine(pCenter, MP1, MP2);
                }

                gdi.DrawLine(pSurround, SP, MP1);
                gdi.DrawLine(pCenter, SP, MP1);

                pSurround.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                pCenter.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                gdi.DrawLine(pSurround, MP2, EP);
                gdi.DrawLine(pCenter, MP2, EP);

                //IsLast = islasttemp;
            }
        }
    }
    public static class TreeNodeExtensions
    {
        public static IEnumerable<TreeNode> GetAllNodes(this TreeNodeCollection nodes)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.Tag == null) continue;
                yield return node; // trả về node hiện tại

                foreach (var child in node.Nodes.GetAllNodes()) // đệ quy vào con
                {
                    if (child.Tag == null) continue;
                    yield return child;
                }
            }
        }
    }
}
