﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MvCore.Core
{
    public class MvToolList : ListBox
    {
        public MvToolList()
        {
            InitDrag();
        }

        void InitDrag()
        {
            this.AllowDrop = true;
            this.MouseDown += SvToolList_MouseDown;
            this.DragDrop += SvToolList_DragDrop;
            this.DragEnter += SvToolList_DragEnter;
            this.DragOver += SvToolList_DragOver;
        }

        void SvToolList_MouseDown(object sender, MouseEventArgs e)
        {
            if (this.SelectedIndex == -1) return;

            DoDragDrop(this.SelectedItem as MvToolBase, DragDropEffects.Copy);                
        }
                

        void SvToolList_DragOver(object sender, DragEventArgs e)
        {
            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));
        }

        void SvToolList_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.AllowedEffect;

            MvToolBase tool = e.Data.GetData(typeof(MvToolBase)) as MvToolBase;
        }

        void SvToolList_DragDrop(object sender, DragEventArgs e)
        {
            TreeNode d = new TreeNode();

            Point ClientPoint = this.PointToClient(new Point(e.X, e.Y));            
        }
    }
}
