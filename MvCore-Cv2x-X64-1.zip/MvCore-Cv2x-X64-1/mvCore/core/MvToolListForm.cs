﻿using MvCore.core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MvCore.Core
{
    public partial class MvToolListForm : Form
    {
        internal _internal inter;
        public MvToolListForm(IEnumerable<MvToolBase> tools)
        {
            inter = new _internal();
            InitializeComponent();
            if(inter.checkActive() == false) { return; }
            svToolList.Items.Clear();

            foreach (MvToolBase tool in tools)
            {
                svToolList.Items.Add(tool);
            }
        }
    }
}
