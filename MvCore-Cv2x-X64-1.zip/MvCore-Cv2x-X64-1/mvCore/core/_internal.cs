﻿using DirectShowLib;
using HalconDotNet;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;

namespace MvCore.core
{
   public class _internal
    {
        public string creartCode()
        {
            string key = getKey();
            string Keys = Encrypt("Encrypt1102*#@", key);
            CreateLicenseKeyFile(Keys);
            saveTime();
            return Keys;
        }
        public bool checkActive()
        {
            return checkLicensing();
        }
        internal void CreateLicenseKeyFile(string licenseContent)
        {
            // 1️⃣ Lấy thư mục đang chạy ứng dụng
            string appDir = AppDomain.CurrentDomain.BaseDirectory;

            // 2️⃣ Tạo đường dẫn thư mục licenseKey
            string licenseDir =System.IO.Path.Combine(appDir, "licenseKey");

            // 3️⃣ Nếu chưa tồn tại thì tạo mới
            if (!Directory.Exists(licenseDir))
            {
                Directory.CreateDirectory(licenseDir);
            }
            string licenseFile = System.IO.Path.Combine(licenseDir, "license.lic");
            File.WriteAllText(licenseFile, licenseContent);
        }

       internal string ReadLicenseKeyFile()
        {
            // 1️⃣ Lấy thư mục đang chạy ứng dụng
            string appDir = AppDomain.CurrentDomain.BaseDirectory;

            // 2️⃣ Đường dẫn thư mục licenseKey
            string licenseDir = System.IO.Path.Combine(appDir, "licenseKey");

            // 3️⃣ Đường dẫn file license
            string licenseFile = System.IO.Path.Combine(licenseDir, "license.lic");

            // 4️⃣ Kiểm tra tồn tại
            if (!File.Exists(licenseFile))
                return null;

            // 5️⃣ Đọc nội dung
            return File.ReadAllText(licenseFile);
        }
        //mã hóa
        internal string Encrypt(string key, string toEncrypt)
        {
            byte[] toEncryptArray = Encoding.UTF8.GetBytes(toEncrypt);
            MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
            byte[] keyArray = hashmd5.ComputeHash(Encoding.UTF8.GetBytes(key));
            ICryptoTransform cTransform = new TripleDESCryptoServiceProvider
            {
                Key = keyArray,
                Mode = CipherMode.ECB,
                Padding = PaddingMode.PKCS7
            }.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        //giải mã
        // Token: 0x060000D7 RID: 215 RVA: 0x0000E38C File Offset: 0x0000C58C
        internal string Decrypt(string key, string toDecrypt)
        {
            string result;
            try
            {
                byte[] toEncryptArray = Convert.FromBase64String(toDecrypt);
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();

                byte[] keyArray = hashmd5.ComputeHash(Encoding.UTF8.GetBytes(key));
                ICryptoTransform cTransform = new TripleDESCryptoServiceProvider
                {
                    Key = keyArray,
                    Mode = CipherMode.ECB,
                    Padding = PaddingMode.PKCS7
                }.CreateDecryptor();
                byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);//error
                result = Encoding.UTF8.GetString(resultArray);
            }
            catch
            {
                result = null;
            }
            return result;
        }

        /****************************************************************************************/









        // Token: 0x04000012 RID: 18
        private DateTime rightNow;

        // Token: 0x04000013 RID: 19
        private string seriPrinter;

        // Token: 0x04000014 RID: 20
        private string timeNow;

        // Token: 0x04000015 RID: 21
        private string yearNow;

        // Token: 0x04000016 RID: 22
        private string monthNow;

        // Token: 0x04000017 RID: 23
        private string dayNow;

        // Token: 0x04000018 RID: 24
        private string hourNow;

        // Token: 0x04000019 RID: 25
        private string minNow;

        // Token: 0x0400001A RID: 26
        private string secNow;

        // Token: 0x0400001B RID: 27
        private string requestX;

        // Token: 0x0400001C RID: 28
        private string passX;
         void getDateData()
        {
            this.rightNow = DateTime.Now;
            string format = "yyyyMMddHH";
            this.timeNow = this.rightNow.ToString(format);
            this.yearNow = this.rightNow.ToString("yyyy");
            this.monthNow = this.rightNow.ToString("MM");
            this.dayNow = this.rightNow.ToString("dd");
            this.hourNow = this.rightNow.ToString("HH");
            this.minNow = this.rightNow.ToString("mm");
            this.secNow = this.rightNow.ToString("ss");
        }
        // Token: 0x060000C2 RID: 194 RVA: 0x0000C928 File Offset: 0x0000AB28
         string getcodeStringDay()
        {
            this.getDateData();
            string tmp = "";
            string text = this.dayNow;
            string a = text;
            if (!(a == "01"))
            {
            }
            return this.dayNow;
        }

        // Token: 0x060000C3 RID: 195 RVA: 0x0000C964 File Offset: 0x0000AB64
         string getcodeStringMonth()
        {
            this.getDateData();
            string tmp = "";
            string text = this.monthNow;
            string a = text;
            if (!(a == "01"))
            {
            }
            return this.monthNow;
        }

        // Token: 0x060000C4 RID: 196 RVA: 0x0000C9A0 File Offset: 0x0000ABA0
         string getcodeStringYear()
        {
            this.getDateData();
            string text = this.yearNow;
            string a = text;
            if (!(a == "01"))
            {
            }
            return this.yearNow;
        }

        // Token: 0x060000C5 RID: 197 RVA: 0x0000C9E4 File Offset: 0x0000ABE4
         string getcodeStringHour()
        {
            this.getDateData();
            string text = this.hourNow;
            string a = text;
            if (!(a == "01"))
            {
            }
            return this.hourNow;
        }

        // Token: 0x060000C6 RID: 198 RVA: 0x0000CA28 File Offset: 0x0000AC28
         string getcodeStringMin()
        {
            this.getDateData();
            string text = this.minNow;
            string a = text;
            if (!(a == "01"))
            {
            }
            return this.minNow;
        }

        // Token: 0x060000C7 RID: 199 RVA: 0x0000CA6C File Offset: 0x0000AC6C
         string getcodeStringSec()
        {
            this.getDateData();
            string text = this.secNow;
            string a = text;
            if (!(a == "01"))
            {
            }
            return this.secNow;
        }




        internal string GetCPUID()
        {
            ManagementClass mc = new ManagementClass("win32_processor");
            ManagementObjectCollection moc = mc.GetInstances();
            string CPUID = string.Empty;
            foreach (ManagementBaseObject managementBaseObject in moc)
            {
                ManagementObject mo = (ManagementObject)managementBaseObject;
                bool flag = CPUID == string.Empty;
                if (flag)
                {
                    CPUID = mo.Properties["processorID"].Value.ToString();
                    break;
                }
                mo.Dispose();
            }
            return CPUID;
        }

        // Token: 0x060000D5 RID: 213 RVA: 0x0000E2F4 File Offset: 0x0000C4F4
        //public string getIDDevice()
        //{
        //    return this.txtIdMachine.Text;
        //}
        internal string getKey()
        {

            //string codeDecrypted = this.congdongcsharp_Decrypt("@PhucNguyen", this.txtpasswordsys.Text);
            //string codeDecryptednoMinSec = codeDecrypted.Substring(0, codeDecrypted.Length - 4);
            string codeEncrypt = string.Concat(new string[]
            {
                this.GetCPUID(),
                "!",this.getcodeStringYear(),
                "@",this.getcodeStringMonth(),
                "#",this.getcodeStringDay(),
                "$",this.getcodeStringHour(),
                "%",this.getMac(),
                "^",this.GetMainboardId(),
            });
            //return string.Compare(codeDecryptednoMinSec, codeEncrypt) == 0;
            return codeEncrypt;
        }

        internal bool getActiveCrackOK(string key)
        {
            string codeDecrypted = this.Decrypt("DavidDang$&^$*(%*", key);
            if (codeDecrypted == null) return false;
            string codeDecryptednoMinSec = codeDecrypted.Substring(0, codeDecrypted.Length - 4);
            string CPU = codeDecryptednoMinSec.Substring(0, codeDecryptednoMinSec.IndexOf('!'));
            string mac = codeDecryptednoMinSec.IndexOf('%') + 1 is int ma && ma >= 0 ? codeDecryptednoMinSec.Substring(ma, codeDecryptednoMinSec.IndexOf('^') - codeDecryptednoMinSec.IndexOf('%') - 1) : null;
            string board = codeDecryptednoMinSec.IndexOf('^') + 1 is int b && b >= 0 ? codeDecryptednoMinSec.Substring(b, codeDecryptednoMinSec.IndexOf('&') - codeDecryptednoMinSec.IndexOf('^') - 1) : null;
            string year = codeDecryptednoMinSec.IndexOf('!') + 1 is int y && y >= 0 ? codeDecryptednoMinSec.Substring(y, codeDecryptednoMinSec.IndexOf('@') - codeDecryptednoMinSec.IndexOf('!') - 1) : null;
            string month = codeDecryptednoMinSec.IndexOf('@') + 1 is int m && m >= 0 ? codeDecryptednoMinSec.Substring(m, codeDecryptednoMinSec.IndexOf('#') - codeDecryptednoMinSec.IndexOf('@') - 1) : null;
            string day = codeDecryptednoMinSec.IndexOf('#') + 1 is int d && d >= 0 ? codeDecryptednoMinSec.Substring(d, codeDecryptednoMinSec.IndexOf('$') - codeDecryptednoMinSec.IndexOf('#') - 1) : null;
            string time = codeDecryptednoMinSec.IndexOf('&') + 1 is int t && t >= 0 ? codeDecryptednoMinSec.Substring(t, codeDecryptednoMinSec.IndexOf('*') - codeDecryptednoMinSec.IndexOf('&') - 1) : null;
            DateTime date = new DateTime(int.Parse(year), int.Parse(month), int.Parse(day));
            date = date.AddMonths(int.Parse(time));
            TimeSpan diff = DateTime.Now - date;
            if (GetCPUID() == CPU && getMac() == mac && GetMainboardId() == board && diff < TimeSpan.Zero)
            {
                return true;
            }
            return false;
        }


        //void creartKey()
        //{
        //    using (var rsa = RSA.Create(2048))
        //    {
        //        File.WriteAllText("private.pem", rsa.ToXmlString(true));

        //        File.WriteAllText("public.pem", rsa.ToXmlString(false));
        //    }

        //}

        internal void writeRegister(string path, string user, string key)
        {

            RegistryKey keys = Registry.CurrentUser.CreateSubKey(path);
            keys.SetValue(user, key);
            keys.Close();
        }
        string readRegister(string path, string user)
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey(path);

            if (key == null)
                return null; // chưa tồn tại key

            object value = key.GetValue(user);
            key.Close();

            return value?.ToString();
        }

       internal string getMac()
        {
            string macAddress = null;

            ManagementObjectSearcher searcher =
                new ManagementObjectSearcher(
                    "SELECT MACAddress FROM Win32_NetworkAdapter " +
                    "WHERE MACAddress IS NOT NULL AND PhysicalAdapter = TRUE");

            foreach (ManagementObject obj in searcher.Get())
            {
                macAddress = obj["MACAddress"].ToString();
                break; // lấy cái đầu tiên (thường là LAN onboard)
            }
            return macAddress;

        }



       internal string GetMainboardId()
        {
            string serial = "UNKNOWN";

            ManagementObjectSearcher searcher =
                new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard");

            foreach (ManagementObject obj in searcher.Get())
            {
                serial = obj["SerialNumber"]?.ToString();
                break;
            }

            return serial;
        }
      

        internal bool checkLicensing()
        {
            string key = ReadLicenseKeyFile();

            if (checkTime() && getActiveCrackOK(key))
            {
                return true;
            }
            return false;
        }
       

        void saveTime()
        {
            writeRegister(@"SOFTWARE\MvTech", "Syno", Encrypt("dateTime", DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
        }
        bool checkTime()
        {
          string  user = "Syno";
          string  path = @"SOFTWARE\MvTech";
            string checktime = Decrypt("dateTime", readRegister(path,user));
            DateTime dt = DateTime.ParseExact(checktime, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
            if (DateTime.Now < dt)
                return false;
            else
            {
                saveTime();
                return true;
            }

        }

    }
}
