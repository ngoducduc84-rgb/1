﻿using MvCore;
using MvCore.Edit;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MvCore;
using MvCore.Tools;
using MvCore.Display;
using OpenCvSharp.Extensions;
using System.Management;
using System.Threading;


namespace MvCore
{
    public class DrawShow
    {
        MvDisplayViewInteract display;
        protected System.Drawing.Font font08 = new System.Drawing.Font("Segoe UI", 12, System.Drawing.FontStyle.Bold);
        protected System.Drawing.Font font16 = new System.Drawing.Font("Segoe UI", 16, System.Drawing.FontStyle.Bold);
        protected System.Drawing.Font font72 = new System.Drawing.Font("Segoe UI", 72, System.Drawing.FontStyle.Bold);
        public DrawShow(ref MvDisplayViewInteract _disp)
        {
            this.display = _disp;
        }

        public bool CheckTool(MvToolBase tool, int blockindex = 0)
        {
            if (tool is MvAcquisition) return CheckTool(tool as MvAcquisition, blockindex);
            else if (tool is MvRegion) return CheckTool(tool as MvRegion, blockindex);
            else if (tool is MvTemplateMatch) return CheckTool(tool as MvTemplateMatch, blockindex);
            else if (tool is MvTemplateMatchs) return CheckTool(tool as MvTemplateMatchs, blockindex);
            //20200528 HNB
            else if (tool is MvTemplateMatchOverpocket) return CheckTool(tool as MvTemplateMatchOverpocket, blockindex);

            else if (tool is MvIntersectLine) return CheckTool(tool as MvIntersectLine, blockindex);
            else if (tool is MvJudgement) return CheckTool(tool as MvJudgement, blockindex);

            //20200528 HNB
            else if (tool is MvJudgementOverpocket) return CheckTool(tool as MvJudgementOverpocket, blockindex);

            else if (tool is MvFindLine) return CheckTool(tool as MvFindLine, blockindex);
            else if (tool is MvMakeLine) return CheckTool(tool as MvMakeLine, blockindex);
            else if (tool is MvMakeRectFromLine) return CheckTool(tool as MvMakeRectFromLine, blockindex);
            else if (tool is MvHistogram) return CheckTool(tool as MvHistogram, blockindex);
            else if (tool is MvBlob) return CheckTool(tool as MvBlob, blockindex);
            else if (tool is MvMorphology) return CheckTool(tool as MvMorphology, blockindex);
            else if (tool is MvDistance3P) return CheckTool(tool as MvDistance3P, blockindex);
            else if (tool is MvMakePoint)
            {
                // MvWarpping이 같은 toolblock 안에 있으면 원본에 표시, 아니면 toolblock 화면에 표시
                //if (AlignResult.JobInfo[blockindex].ContainsKey(typeof(MvWarpping)))
                //    blockindex = 0;
                //return CheckTool(tool as MvMakePoint, blockindex);
                return true;
            }
            else return false;
        }

        protected virtual bool CheckTool(MvAcquisition acq, int displayindex = 0)
        {
            if (displayindex == 0)
            {
                //mAlignResult.InputImage = acq.AcqusitionImage;
                //mAlignResult.OriginalImage = acq.OriginalImage;
                display.Image = acq.AcqusitionImage;
            }
            if (acq.InputImage == null || acq.InputImage.Height == 0 || acq.InputImage.Width == 0)
            {
                return false;
            }
            return acq.lastRunSuccess;
        }

        //protected List<MvRectangle> Rects = new List<MvRectangle>();

        protected virtual bool CheckTool(MvRegion region, int displayindex = 0)
        {
            // Box 그리기
            MvRectangle regionRect = region.OutputImage.RegionRect;
            Pen pen = new Pen(Color.Pink);
            pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            //string str = mRegionIndex.ToString();
            PointF location = new PointF(region.OutputImage.RegionRect.Location.X, region.OutputImage.RegionRect.Location.Y);

            //this.mUpdateDisplayCode.Add(new Action(() =>
            //{
            //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
            //    (display) =>
            //    {
            //display.DrawString(str, font08, Brushes.Pink, location);
            display.DrawRectangle(pen, regionRect.RectF);
            //    };
            //}));

            return region.lastRunSuccess;
        }

        protected virtual bool CheckTool(MvTemplateMatch templateMatch, int displayindex = 0)
        {
            try
            {



                //mAlignResult.Scores.Add(templateMatch.Score);//스코어는 유무검사에 사용되므로 무조건 추가
                //mAlignResult.ResultValues.Add(templateMatch.Score);
                Mat edge = new Mat(new OpenCvSharp.CPlusPlus.Size(templateMatch.InputImage.Width, templateMatch.InputImage.Height), MatType.CV_8UC4, new Scalar(0, 0, 0, 0));
                if (templateMatch.listResultBox == null || templateMatch.listResultBox.Count == 0 || templateMatch.listResultBox[0].CP == null) { return false; }
                Point2d TMcenter = new Point2d((double)templateMatch.listResultBox[0].CP.X, (double)templateMatch.listResultBox[0].CP.Y);

                //if (double.IsNaN(TMcenter.X) || double.IsNaN(TMcenter.Y))
                //    TMcenter = new Point2d(templateMatch.failResultBox.CP.X, templateMatch.failResultBox.CP.Y - 500);

                // Box 그리기
                Point2d[] resultBox = templateMatch.ResultBox;


                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                if (templateMatch.Score >= templateMatch.PCreteria)
                {
                    Pen pen = new Pen(Color.Green, 4f);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    display.DrawString($"Score: {templateMatch.Score:F4}, X: {TMcenter.X:F4}, Y: {TMcenter.Y:F4}, Anlge: {templateMatch.Rotation_Degree:F4}", font08, Brushes.Green, new PointF(10, 40));
                    display.DrawPolyLines(pen, resultBox);
                }
                else
                {
                    Pen pen = new Pen(Color.Red, 4f);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    display.DrawString($"Score: {templateMatch.Score:F4}, X: {TMcenter.X:F4}, Y: {TMcenter.Y:F4}, Anlge: {templateMatch.Rotation_Degree:F4}", font08, Brushes.Red, new PointF(10, 40));
                    display.DrawPolyLines(pen, resultBox);
                }
                Pen p = new Pen(Color.Green, 4f);
                display.DrawCross(p, TMcenter, 40, 40, templateMatch.Rotation);
                //    };
                //}));

                //if (/*(mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete) &&*/ // 검사기능 사용 && 템플릿 매칭
                //    !(mProcess == Main.Process.Object1 || mProcess == Main.Process.Object2))//object 아니면 단순 유무검사 이므로 do_judgement에서 최종 처리함.
                //    return true;

                string message = "";
                Brush brush;

                if (templateMatch.Score < templateMatch.PCreteria/*  && ListAlignIndex.Contains(displayindex)*/)//ng
                {
                    message = string.Format("Temp NG : {0:F2} (Spec : {1:F2})", templateMatch.Score, templateMatch.PCreteria);
                    //SequenceLog(message, MvLogger.LogType.ERROR);
                    brush = Brushes.Red;
                    templateMatch.lastRunSuccess = false;
                    //mAlignResult.resultMessage = "TemplateMatching NG";
                }
                else//ok
                {
                    message = string.Format("Temp OK {0:F2}", templateMatch.Score);
                    //SequenceLog(message, MvLogger.LogType.DATA);
                    brush = Brushes.Green;
                    templateMatch.lastRunSuccess = true;
                }
                if (templateMatch.UseEdge && templateMatch.listResultBox[0].contours != null && templateMatch.listResultBox[0].contours.Count() > 0)
                {
                    Cv2.DrawContours(edge, templateMatch.listResultBox[0].contours, -1, new Scalar(0, 255, 0, 255), 1);
                }
                try
                {
                    display.DrawImage(edge.ToBitmap(), new PointF(0, 0));
                    //this.mUpdateDisplayCode.Add(new Action(() =>
                    //{
                    //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                    //    (display) =>
                    //    {
                    display.DrawString(message, font08, brush, TMcenter);
                    //    };
                    //}));
                }
                catch (Exception)
                {
                    return false;
                }


                return templateMatch.lastRunSuccess;
            }
            catch (Exception)
            {

                return false;
            }
        }

        protected virtual bool CheckTool(MvTemplateMatchs templateMatch, int displayindex = 0)
        {
            //mAlignResult.Scores.Add(templateMatch.Score);//스코어는 유무검사에 사용되므로 무조건 추가
            //mAlignResult.ResultValues.Add(templateMatch.Score);
            if (templateMatch.InputImage == null) { return false; }
            Mat edge = new Mat(new OpenCvSharp.CPlusPlus.Size(templateMatch.InputImage.Width, templateMatch.InputImage.Height), MatType.CV_8UC4, new Scalar(0, 0, 0, 0));
            for (int i = 0; i < templateMatch.listResultBox.Count; i++)
            {
                if (templateMatch.listResultBox[i].CP == null) { return false; }
                Point3d TMcenter = templateMatch.listResultBox[i].CP;

                //if (double.IsNaN(TMcenter.X) || double.IsNaN(TMcenter.Y))
                //    TMcenter = new Point2d(templateMatch.failResultBox.CP.X, templateMatch.failResultBox.CP.Y - 500);

                // Box 그리기
                Point2d[] resultBox = templateMatch.listResultBox[i].Box;


                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                if (templateMatch.listResultBox[i].Score != null && templateMatch.listResultBox[i].Score >= templateMatch.PCreteria)
                {
                    Pen pen = new Pen(Color.Green, 4f);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    display.DrawString($"Score: {templateMatch.listResultBox[i].Score:F4}, X: {TMcenter.X:F4}, Y: {TMcenter.Y:F4}, Anlge: {TMcenter.Z * (180 / Math.PI):F4}", font08, Brushes.Green, new PointF(10, i * 80 + 30));
                    display.DrawPolyLines(pen, resultBox);
                }
                else
                {
                    Pen pen = new Pen(Color.Red, 4f);
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    display.DrawString($"Score: {templateMatch.listResultBox[i].Score:F4}, X: {TMcenter.X:F4}, Y: {TMcenter.Y:F4}, Anlge: {TMcenter.Z * (180 / Math.PI):F4}", font08, Brushes.Red, new PointF(10, i * 80 + 30));
                    display.DrawPolyLines(pen, resultBox);
                }

                //    };
                //}));

                //if (/*(mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete) &&*/ // 검사기능 사용 && 템플릿 매칭
                //    !(mProcess == Main.Process.Object1 || mProcess == Main.Process.Object2))//object 아니면 단순 유무검사 이므로 do_judgement에서 최종 처리함.
                //    return true;

                string message = "";
                Brush brush;

                if (templateMatch.listResultBox[i].Score != null && templateMatch.listResultBox[i].Score < templateMatch.PCreteria/*  && ListAlignIndex.Contains(displayindex)*/)//ng
                {
                    message = string.Format("Temp NG : {0:F2} (Spec : {1:F2})", templateMatch.listResultBox[i].Score, templateMatch.PCreteria);
                    //SequenceLog(message, MvLogger.LogType.ERROR);
                    brush = Brushes.Red;
                    templateMatch.lastRunSuccess = false;
                    //mAlignResult.resultMessage = "TemplateMatching NG";
                }
                else//ok
                {
                    message = string.Format("Temp OK {0:F2}", templateMatch.listResultBox[i].Score);
                    brush = Brushes.Green;
                    templateMatch.lastRunSuccess = true;
                }
                Pen p = new Pen(Color.Red, 4f);
                display.DrawCross(p, new Point2d(TMcenter.X, TMcenter.Y), 40, 40, TMcenter.Z);
                display.DrawString(message, font08, brush, new PointF((float)TMcenter.X, (float)TMcenter.Y));

                if (templateMatch.UseEdge && templateMatch.listResultBox[i].contours != null && templateMatch.listResultBox[i].contours.Count() > 0)
                {
                    Cv2.DrawContours(edge, templateMatch.listResultBox[i].contours, -1, new Scalar(0, 255, 0, 255), 1);
                }

            }
            display.DrawImage(edge.ToBitmap(), new PointF(0, 0));
            return templateMatch.lastRunSuccess;
        }
        //20200528 HNB
        protected virtual bool CheckTool(MvTemplateMatchOverpocket templateMatch, int displayindex = 0)
        {
            //mAlignResult.Scores.Add(templateMatch.Score);//스코어는 유무검사에 사용되므로 무조건 추가
            //mAlignResult.ResultValues.Add(templateMatch.Score);

            Point2d TMcenter = new Point2d(templateMatch.TranslateX, templateMatch.TranslateY);

            if (double.IsNaN(TMcenter.X) || double.IsNaN(TMcenter.Y))
                TMcenter = new Point2d(templateMatch.failResultBox.CP.X, templateMatch.failResultBox.CP.Y - 500);

            // Box 그리기
            Point2d[] resultBox = templateMatch.ResultBox;
            Pen pen = new Pen(Color.DimGray, 2f);
            pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;

            //this.mUpdateDisplayCode.Add(new Action(() =>
            //{
            //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
            //    (display) =>
            //    {
            display.DrawPolyLines(pen, resultBox);
            //    };
            //}));

            //if (/*(mProcData.UseInspect && mProcData.InspectTool == EInspectTool.Templete) &&*/ // 검사기능 사용 && 템플릿 매칭
            //    !(mProcess == Main.Process.Object1 || mProcess == Main.Process.Object2))//object 아니면 단순 유무검사 이므로 do_judgement에서 최종 처리함.
            //    return true;

            string message = "";
            Brush brush;

            if (templateMatch.Score < templateMatch.PCreteria/*  && ListAlignIndex.Contains(displayindex)*/)//ng
            {
                message = string.Format("Temp NG : {0:F2} (Spec : {1:F2})", templateMatch.Score, templateMatch.PCreteria);
                //SequenceLog(message, MvLogger.LogType.ERROR);
                brush = Brushes.Red;
                templateMatch.lastRunSuccess = false;
            }
            else//ok
            {
                message = string.Format("{0:F2}", templateMatch.Score);
                //SequenceLog(message, MvLogger.LogType.DATA);
                brush = Brushes.LightGreen;
                templateMatch.lastRunSuccess = true;
            }

            //this.mUpdateDisplayCode.Add(new Action(() =>
            //{
            //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
            //    (display) =>
            //    {
            display.DrawString(message, font08, brush, TMcenter);
            //    };
            //}));

            return templateMatch.lastRunSuccess;
        }
        protected virtual bool CheckTool(MvIntersectLine intersectLine, int displayindex = 0)
        {
            if (intersectLine.IntersectPoint == null) return false;
            Point2d intersectpoint = MvFunc.FixtureToImage2D(intersectLine.IntersectPoint.Point2d, intersectLine.IntersectPoint.TransformMat);

            double normalizedAngle = intersectLine.Angle;   // +2 * Math.PI; // 0 < normalizedAngle < 180
            while (normalizedAngle - 180 > 0)
            {
                normalizedAngle -= 180;
            }

            if (Math.Abs(normalizedAngle - 90) > intersectLine.mScore)
            {
                string message1 = string.Format("IntersectLine NG : {0:F2}", normalizedAngle);
                string message2 = string.Format("(Spec : 90º±{0:F2})", intersectLine.mScore);
                //SequenceLog(message1 + message2, MvLogger.LogType.ERROR);

                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                display.DrawString(message1, font08, Brushes.Red, intersectpoint + new Point2d(-200, -120 - font08.Size / display.ZoomRatio));
                display.DrawString(message2, font08, Brushes.Red, intersectpoint + new Point2d(-200, -120 + font08.Size / display.ZoomRatio));
                //    };
                //}));

                //mAlignResult.resultMessage = "Intersect_Line Angle NG";
                return false;
            }

            return intersectLine.lastRunSuccess;
        }

        protected virtual bool CheckTool(MvFindLine findLine, int displayindex = 0)
        {
            if (findLine.lastRunSuccess == false || findLine.Line == null)
            {
                //SequenceLog("Find Line NG", MvLogger.LogType.ERROR);
                //mAlignResult.resultMessage = "Find_Line Fail";
                return false;
            }

            bool isLineOk = true;
            Point2d sp = MvFunc.FixtureToImage2D(findLine.Line.SP, findLine.Line.TransformMat);
            Point2d ep = MvFunc.FixtureToImage2D(findLine.Line.EP, findLine.Line.TransformMat);
            Point2d lineCenterPt = (sp + ep) * 0.5;
            double scale = 0.06;
            Point2d SP = (sp - lineCenterPt) * scale + lineCenterPt;
            Point2d EP = (ep - lineCenterPt) * scale + lineCenterPt;

            if (findLine.Score > findLine.SetScore)
            {
                string message = string.Format("Line Distance NG : {0:F3} (Spec : {1:F3})", findLine.Score, findLine.SetScore);
                //mAlignResult.resultMessage = "Line_Distance NG";
                //SequenceLog(message, MvLogger.LogType.ERROR);

                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                display.DrawLine(Pens.Red, SP, EP);
                display.DrawString(message, font08, Brushes.Red, lineCenterPt + new Point2d(-150, (-font08.Size / display.ZoomRatio - 150) / 2));
                //    };
                //}));

                isLineOk = false;
            }
            else
            {
                string message = string.Format("Line Distance : {0:F3}", findLine.Score);
                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                display.DrawLine(Pens.YellowGreen, SP, EP);
                //display.DrawString(message, font08, Brushes.Cyan, lineCenterPt + new Point2d(-150, (-font08.Size / display.ZoomRatio - 150) / 2));
                //    };
                //}));
            }

            int caliperCount = findLine.LineCaliper.NumberOfCaliper - findLine.NumberOfIgnore;
            int successCnt = (findLine.ResultList.FindAll(x => x.Used == "true")).Count;
            if (successCnt <= findLine.SetCount)
            {
                string message = string.Format("Line Count NG : {0} (Spec : {1}) / {2}", successCnt, findLine.SetCount, caliperCount);
                //mAlignResult.resultMessage = "Find_Line Count NG";

                //SequenceLog(message, MvLogger.LogType.ERROR);

                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                display.DrawString(message, font08, Brushes.Red, lineCenterPt + new Point2d(-150, (-font08.Size / display.ZoomRatio) / 2));
                //    };
                //}));

                isLineOk = false;
            }
            else
            {
                string message = string.Format("Line Count : {0} / {1}", successCnt, caliperCount);
                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                // 이거 표시 안하니까 현재 셋팅상태를 볼수가 없어서...
                display.DrawString(message, font08, Brushes.Cyan, lineCenterPt + new Point2d(-150, (-font08.Size / display.ZoomRatio) / 2));
                //    };
                //}));
            }

            if (!isLineOk)
            {
                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                display.DrawLine(Pens.Red, SP, EP);
                //    };
                //}));

                //mAlignResult.resultMessage = "Find_Line Fail";

                return false;
            }

            return findLine.lastRunSuccess;
        }

        protected virtual bool CheckTool(MvMakeLine makeline, int displayindex = 0)
        {
            if (makeline.lastRunSuccess == false || makeline == null)
                return false;

            //MvCalibration cal = mRobotData.Calibrations;
            //var p1 = cal.VtoR(makeline.OutLine.SP);
            //var p2 = cal.VtoR(makeline.OutLine.EP);
            //double len = Point2d.Distance(p1, p2);
            //Point2d pnt = makeline.LineCenter.Point2d;
            //float min = mModelData.IntersectLineLength - mModelData.LineLengthTolerence;
            //float max = mModelData.IntersectLineLength + mModelData.LineLengthTolerence;
            //if (len < min || len > max)
            //{
            //    string message = string.Format("Line Length NG : {0:f2}mm (Spec : {1}±{2}mm)", len, mModelData.IntersectLineLength, mModelData.LineLengthTolerence);

            //    mAlignResult.resultMessage = "Line_Length NG";

            //    SequenceLog(message, MvLogger.LogType.ERROR);

            //    this.mUpdateDisplayCode.Add(new Action(() =>
            //    {
            //        mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
            //        (display) =>
            //        {
            //            display.DrawString(message, font08, Brushes.Red, pnt + new Point2d(-150, (-font08.Size / display.ZoomRatio - 150) / 2));
            //        };
            //    }));
            //    return false;
            //}
            //else
            //{
            //    string message = string.Format("Line Length : {0:f2} (Spec : {1})", len, mModelData.IntersectLineLength);
            //    //SequenceLog(message, MvLogger.LogType.DATA);

            //    this.mUpdateDisplayCode.Add(new Action(() =>
            //    {
            //        mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
            //        (display) =>
            //        {
            //            display.DrawString(message, font08, Brushes.SkyBlue, pnt + new Point2d(-150, (-font08.Size / display.ZoomRatio - 150) / 2));
            //        };
            //    }));
            //}

            return makeline.lastRunSuccess;
        }

        protected virtual bool CheckTool(MvMakePoint makepoint, int displayindex = 0)
        {
            if (makepoint.lastRunSuccess == false || makepoint == null || makepoint.OutPoint == null)
            {
                //mAlignResult.resultMessage = "Make_Point NG";
                return false;
            }

            double X = makepoint.OutPoint.X;
            double Y = makepoint.OutPoint.Y;
            double T = makepoint.OutPoint.ThetaRad;
            string str = string.Format("({0:f3}, {1:f3}, {2:f3})", X, Y, T);

            //this.mUpdateDisplayCode.Add(new Action(() =>
            //{
            //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
            //    (display) =>
            //    {
            display.DrawCross(Pens.Red, new Point2d(X, Y), 100, 100, T);
            display.DrawString(str, font08, Brushes.SkyBlue, new Point2d(X, Y) + new Point2d(-150, (-font08.Size / display.ZoomRatio + 150) / 2));

            //    };
            //}));

            return makepoint.lastRunSuccess;
        }

        protected virtual bool CheckTool(MvMakeRectFromLine makerect, int displayindex = 0)
        {
            if (makerect.IsRectangle == false)
            {
                if (makerect.IsAngle == false)
                {
                    //mAlignResult.resultMessage = "Rectange Angle NG";
                    //SequenceLog("Rectangle Angle NG", MvLogger.LogType.ERROR);
                }
                else
                {
                    //mAlignResult.resultMessage = "Rectange Distance NG";
                    //SequenceLog("Rectangle Distance NG", MvLogger.LogType.ERROR);
                }

                //this.mUpdateDisplayCode.Add(new Action(() =>
                //{
                //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                //    (display) =>
                //    {
                display.DrawPolyLines(Pens.Red, makerect.ResultPoints);
                //    };
                //}));
                return false;
            }
            //this.mUpdateDisplayCode.Add(new Action(() =>
            //{
            //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
            //    (display) =>
            //    {
            display.DrawPolyLines(Pens.YellowGreen, makerect.ResultPoints);
            //    };
            //}));

            return makerect.lastRunSuccess;
        }

        protected virtual bool CheckTool(MvHistogram histo, int displayindex = 0)
        {
            //if (histo.lastRunSuccess == false || histo == null || histo.Mean == 0)
            //    return false;

            //mAlignResult.Means.Add(histo.Mean);
            //mAlignResult.ResultValues.Add(histo.Mean);
            //string log = string.Format("Mean : {0:f1}", histo.Mean);
            //SequenceLog(log, MvLogger.LogType.SEQUENCE);

            return histo.lastRunSuccess;
        }

        protected virtual bool CheckTool(MvBlob blob, int displayindex = 0)
        {
            //if (histo.lastRunSuccess == false || histo == null || histo.Mean == 0)
            //    return false;

            return blob.lastRunSuccess;
        }
        protected virtual bool CheckTool(MvMorphology morphology, int displayindex = 0)
        {
            return morphology.lastRunSuccess;
        }


        MvImage inputimage;

        protected virtual bool CheckTool(MvJudgement judge, int displayindex = 0)
        {
            //mAlignResult.Scores.Add(judge.Value);
            //mAlignResult.ResultValues.Add(judge.Value);

            //string sJudge = string.Format("{0} : ", (mRegionIndex + 1));
            //sJudge += judge.Judgement ? "OK" : "NG";
            //string log = sJudge;

            //sJudge += string.Format("\n{0:f3} \n(spec : {1:f3})", judge.Value, judge.Creteria);
            //log += string.Format(" : {0:f3} (spec : {1:f3})", judge.Value, judge.Creteria);
            //SequenceLog(log, MvLogger.LogType.DATA); //Data로 로그를 바꿔야 하지 않을까?

            Brush brush = (judge.Judgement) ? Brushes.YellowGreen : Brushes.Orange;

            if (judge.inParams.ContainsKey("InputImage") && judge.InputImage != null)
            {
                if (inputimage != null)
                    inputimage.Dispose();

                inputimage = judge.InputImage.Clone(true);

                if (inputimage.RegionRect.Height != inputimage.Height)
                {
                    //this.mUpdateDisplayCode.Add(new Action(() =>
                    //{
                    //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                    //    (display) =>
                    //    {
                    Mat mask = new Mat(inputimage.Mat.Size(), inputimage.Mat.Type());
                    mask.SetTo(0);
                    mask.FillPoly(new OpenCvSharp.CPlusPlus.Point[][] { inputimage.RegionRectPtsImage }, new Scalar(255));
                    inputimage.Mat.CopyTo(display.Image.Mat, mask);
                    display.DrawPolyLines(Pens.Pink, inputimage.RegionRectFPts);

                    //System.Drawing.Font font = new System.Drawing.Font("굴림체", 8, System.Drawing.FontStyle.Bold);
                    //System.Drawing.SolidBrush brush2 = judgement ? new System.Drawing.SolidBrush(System.Drawing.Color.Blue) : new System.Drawing.SolidBrush(System.Drawing.Color.Red);

                    //string tmp = string.Format("Value: {0:f3} {1} {2:f3}(spec)\r\n", value, comparison, creteria);
                    //string tmp2 = string.Format("Judgement: {0}", judgement);


                    //display.DrawString(sJudge, font08, brush, inputimage.RegionRectFPts[0]);      // 어디서 쓰는지 잘 모르겠음 (19.08.14 HOZZANG)
                    //display.DrawString(tmp2, font, brush2, new PointF(inputimage.RegionRectFPts[0].X, inputimage.RegionRectFPts[0].Y + 1.5f * font.Size / display.ZoomRatio));

                    //inputimage.Dispose();
                    mask.Dispose();
                    //    };
                    //}));
                }
            }

            //mAlignResult.Judgements.Add(judge.Judgement);
            //mAlignResult.JudgementSpec.Add(judge.Creteria);
            //mAlignResult.judgeCnt++;

            //string log = string.Format("Judge : {0:f1}", judge.Judgement);
            //SequenceLog(log, MvLogger.LogType.SEQUENCE);

            return judge.lastRunSuccess;
        }

        //20200516 HNB
        protected virtual bool CheckTool(MvJudgementOverpocket judge, int displayindex = 0)
        {
            //20200516 HNB edit to show image
            //mAlignResult.ResultValues.Add(judge.Score);
            string sJudge = ""; ;// = string.Format("{0} : ", (mRegionIndex + 1));
            sJudge += judge.Judgement ? "OK" : "NG";
            string log = sJudge;

            sJudge += string.Format("\n{0:f3} \n(spec : {1:f3})", judge.Score, judge.Creteria1);
            sJudge += string.Format("\n{0:f3} \n(spec : {1:f3})", judge.X, judge.Creteria2);
            sJudge += string.Format("\n{0:f3} \n(spec : {1:f3})", judge.Y, judge.Creteria3);
            sJudge += string.Format("\n{0:f5} \n(spec : {1:f5})", judge.T, judge.Creteria4);
            log += string.Format(" : {0:f3} (spec : {1:f3})", judge.Score, judge.Creteria1);
            log += string.Format(" : {0:f3} (spec : {1:f3})", judge.X, judge.Creteria2);
            log += string.Format(" : {0:f3} (spec : {1:f3})", judge.Y, judge.Creteria3);
            log += string.Format(" : {0:f5} (spec : {1:f5})", judge.T, judge.Creteria4);
            //SequenceLog(log, MvLogger.LogType.SEQUENCE); //Data로 로그를 바꿔야 하지 않을까?

            Brush brush = (judge.Judgement) ? Brushes.YellowGreen : Brushes.Orange;

            if (judge.inParams.ContainsKey("InputImage") && judge.InputImage != null)
            {
                if (inputimage != null) inputimage.Dispose();
                inputimage = judge.InputImage.Clone(true);

                if (inputimage.RegionRect.Height != inputimage.Height)
                {
                    //this.mUpdateDisplayCode.Add(new Action(() =>
                    //{
                    //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
                    //    (display) =>
                    //    {
                    Mat mask = new Mat(inputimage.Mat.Size(), inputimage.Mat.Type());
                    mask.SetTo(0);
                    mask.FillPoly(new OpenCvSharp.CPlusPlus.Point[][] { inputimage.RegionRectPtsImage }, new Scalar(255));
                    inputimage.Mat.CopyTo(display.Image.Mat, mask);

                    display.DrawPolyLines(Pens.Pink, inputimage.RegionRectFPts);
                    display.DrawString(sJudge, font08, brush, inputimage.RegionRectFPts[0]);
                    mask.Dispose();
                    //    };
                    //}));
                }
            }

            return judge.lastRunSuccess;
        }
        protected virtual bool CheckTool(MvDistance3P dist, int displayindex = 0)
        {
            if (dist.lastRunSuccess == false)
            {
                return false;
            }

            MvLine line = dist.DistLine.Clone();
            MvPoint P = dist.PointC.Clone();

            //this.mUpdateDisplayCode.Add(new Action(() =>
            //{
            //    mViewModel.Edit.CustomImageList[displayindex].drawingFunc +=
            //    (display) =>
            //    {
            Point2d sp = MvFunc.FixtureToImage2D(MvFunc.FixtureToImage2D(line.SP, line.TransformMat), display.Transform2D);
            Point2d ep = MvFunc.FixtureToImage2D(MvFunc.FixtureToImage2D(line.EP, line.TransformMat), display.Transform2D);
            Point2d cp = MvFunc.FixtureToImage2D(MvFunc.FixtureToImage2D(P.Point2d, P.TransformMat), display.Transform2D);

            Point2d lineVec = ep - sp;

            if (lineVec.X == 0 && lineVec.Y == 0) return false;

            Point2d unitLineVec = (lineVec * (1 / lineVec.DotProduct(lineVec)));
            double projectionlength = (cp - sp).DotProduct(lineVec);
            Point2d crossPoint = sp + unitLineVec * projectionlength;

            Point2d SP = crossPoint;
            Point2d EP = cp;

            string message = string.Format("Line Distance : {0:F3}", dist.DistanceResult);
            Pen p = new Pen(Brushes.Violet);
            p.Width = 3;
            display.DrawLine(p, SP, EP);
            p.Width = 4;
            display.DrawEllipse(p, SP, 2f, 2f);
            display.DrawEllipse(p, EP, 2f, 2f);
            //    };
            //}));

            return true;
        }
    }
}
