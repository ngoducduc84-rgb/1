﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Display;
using MvCore;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;
using System.Drawing.Imaging;

namespace MvCore.Edit.Base
{
    public partial class MvDisplayViewEdit : UserControl
    {
        public MvDisplayViewEdit()
        {
            InitializeComponent();
            customImageList = new Dictionary<int, SvImageInfo>();
            svDisplayViewStatusBar.Display = sdv_display;
            cb_ImageList.Click += cb_ImageList_Click;
            cb_ImageList.SelectedValueChanged += cb_ImageList_SelectedValueChanged;
            
        }

        bool IsComboBoxClick = false;

        void cb_ImageList_Click(object sender, EventArgs e)
        {
            IsComboBoxClick = true;
        }

        MvToolBase subject;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvToolBase Subject
        { 
            get { return subject;}
            set
            {
                subject = value;
                RefreshImage();
                
                if (cb_ImageList.Items.Count > 0)
                    cb_ImageList.SelectedIndex = cb_ImageList.Items.Count - 1;
            }
        }

        public MvDisplayViewInteract Display
        {
            get { return sdv_display; }
        }

        int currentIndex;

        public void RefreshImage()
        {
            sdv_display.Image = null;
            currentIndex = cb_ImageList.SelectedIndex;

            cb_ImageList.Items.Clear();

            if (subject != null)
            {
                foreach (SvImageInfo info in subject.imageList)
                {
                    cb_ImageList.Items.Add(info);
                }
            }

            foreach (KeyValuePair<int, SvImageInfo> pair in customImageList)
            {                
                cb_ImageList.Items.Insert(pair.Key, pair.Value);
            }

            cb_ImageList_SelectedValueChanged(this, null);
        }

        public void ClearImage()
        {
            sdv_display.Image = null;
        }

        public void InsertCustomImage(int index, SvImageInfo info)
        {
            customImageList.Add(index, info);
        }

        public void RemoveCustomImage(int index)
        {
            customImageList.Remove(index);
        }

        public void ClearCustomImage()
        {
            customImageList.Clear();
        }

        public void SetLastImage()
        {
            if (cb_ImageList.Items.Count > 0)
                cb_ImageList.SelectedIndex = cb_ImageList.Items.Count - 1;
        }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Browsable(false)]
        public Dictionary<int, SvImageInfo> CustomImageList { get { return customImageList; } set { customImageList = value; } }
        Dictionary<int, SvImageInfo> customImageList;

        public ComboBox imageListComboBox
        {
            get { return cb_ImageList; }
        }

        void cb_ImageList_SelectedValueChanged(object sender, EventArgs e)
        {
            this.Display.ClearImage();

            float oldZoom = Display.ZoomRatio;
            System.Drawing.Point oldLocation = Display.imageLocation;

            if (cb_ImageList.SelectedItem == null)
            {
                if (currentIndex != -1 && cb_ImageList.Items.Count > currentIndex)
                    cb_ImageList.SelectedIndex = currentIndex;
                else if (cb_ImageList.Items.Count > 0)
                    cb_ImageList.SelectedIndex = cb_ImageList.Items.Count - 1;
                return;
            }
            
            SvImageInfo imageInfo = (SvImageInfo)cb_ImageList.SelectedItem;
            sdv_display.Image = imageInfo.Image;
            if (imageInfo.drawingFunc != null && sdv_display.Image != null)
                imageInfo.drawingFunc(sdv_display);

            NotifySelectedValueChanged(imageInfo);

            if (IsComboBoxClick)
            {
                Display.ZoomRatio = oldZoom;
                Display.imageLocation = oldLocation;
                IsComboBoxClick = false;
            }
        }

        public delegate void SelectedImageChangedHandler(object sender, SvImageInfo imageInfo);
        
        public event SelectedImageChangedHandler SelectedImageChanged;

        void NotifySelectedValueChanged(SvImageInfo imageInfo)
        {
            if (SelectedImageChanged != null)
            {
                SelectedImageChanged(this, imageInfo);
            }
        }


        public Mat CalibrationMat
        {
            set
            {
                // Calibration VtoR과 Fixture Image2Fixture Matrix가 서로 반대네... 젠장 바꿔야지...
                Mat transF = null;
                if (value.Type() == MatType.CV_64FC1)
                {
                    transF = new Mat(3, 3, MatType.CV_32FC1);
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            transF.Set(i, j, (float)value.At<double>(i, j));
                        }
                    }
                }
                else if (value.Type() != MatType.CV_32FC1)
                    return;

                //float[,] ff = SvFunc.DisplayMatF(transF);
                //mViewModel.Edit.Display.Transform2D = transF;

                svDisplayViewStatusBar.CalibrationMat = transF;
                if (transF != null) transF.Dispose();
            }
        }

        public Mat GetDisplayImage(int _index = 0)
        {
            MvDisplayView display = new MvDisplayView();
            display.Width = Display.Width;
            display.Height = Display.Height;
            try
            {
                display.Image = CustomImageList[_index].Image;
                customImageList[_index].drawingFunc(display);
                return display.GetDisplayImage();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("[image save fail] \r\n" + ex.ToString());
                return null;
            }
            finally
            {
                display.Dispose();
            }
        }
        public IntPtr getPicHanld()
        {
          return  sdv_display.getPicHanld();
        }
    }
}
