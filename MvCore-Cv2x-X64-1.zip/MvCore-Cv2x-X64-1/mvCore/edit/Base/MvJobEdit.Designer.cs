﻿//using OpenCvSharp.ML;
using System.Windows.Forms;

namespace MvCore.Edit
{
    partial class MvJobEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_Tools = new System.Windows.Forms.TabPage();
            this.svToolBlockTree = new MvCore.Core.MvToolBlockTree();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tabControl.SuspendLayout();
            this.tp_Tools.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Tools);
            // 
            // tp_Tools
            // 
            this.tp_Tools.Controls.Add(this.svToolBlockTree);
            this.tp_Tools.Location = new System.Drawing.Point(4, 22);
            this.tp_Tools.Name = "tp_Tools";
            this.tp_Tools.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Tools.Size = new System.Drawing.Size(442, 426);
            this.tp_Tools.TabIndex = 0;
            this.tp_Tools.Text = "Tools";
            this.tp_Tools.UseVisualStyleBackColor = true;
            // 
            // svToolBlockTree
            // 
            this.svToolBlockTree.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.svToolBlockTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.svToolBlockTree.Location = new System.Drawing.Point(3, 3);
            this.svToolBlockTree.Name = "svToolBlockTree";
            this.svToolBlockTree.Size = new System.Drawing.Size(436, 420);
            this.svToolBlockTree.TabIndex = 0;
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Margin = new System.Windows.Forms.Padding(3, 1, 3, 2);
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 23);
            // 
            // MvJobEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "MvJobEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Tools.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Tools;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private MvCore.Core.MvToolBlockTree svToolBlockTree;
             
    }
}
