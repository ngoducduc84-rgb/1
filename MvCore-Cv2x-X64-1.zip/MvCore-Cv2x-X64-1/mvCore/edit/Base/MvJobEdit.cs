﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Core;
using System.Reflection;
using MvCore.Edit.Base;
using MvCore.CameraDevice;
using MvCore;
using MvCore.core;


namespace MvCore.Edit
{
  
    public partial class MvJobEdit : MvToolEditBase
    {
        public event EventHandler OnSaved;
        MvTCP tcp;
        public MvJobEdit()
        {
            
            InitializeComponent();

            svToolBlockTree.ToolSelect += svToolBlockTree_ToolSelect;
            this.Disposed += (a, b) => { SvDisplayViewEdit.Display.Dispose(); };   
        }
        public void SubjectFormLoad()
        {
            if (Job != null) { loadJob(Job); }
        }
        public void SubjectFormClosing()
        {
            if (tcp != null && tcp.tcpServer != null) { tcp.tcpServer.ReciverEvent -= Server_ReciverEvent; tcp.tcpServer.Close(); tcp.tcpServer = null; }
            if (tcp != null && tcp.tcpClient != null) { tcp.tcpClient.ReciverEvent -= Client_ReciverEvent; tcp.tcpClient.Close(); tcp.tcpClient = null; }
            
        }
        private void loadJob(MvJob job)
        {
            foreach (MvToolBase tool in this.Job.ToolList)
            {
                if (tool is MvToolBlock)
                {
                    MvToolBlock tools = tool as MvToolBlock;
                    foreach (MvToolBase _tool in tools.ToolJob.ToolList)
                    {
                        if (tool is MvTCP)
                        {
                            tcp = tool as MvTCP;
                            tcp.Run();
                            if (tcp != null && tcp.tcpServer != null && tcp.tcpServer.connectStatus == true) { tcp.tcpServer.ReciverEvent += Server_ReciverEvent; }
                            if (tcp != null && tcp.tcpClient != null && tcp.tcpClient.connectStatus == true) { tcp.tcpClient.ReciverEvent += Client_ReciverEvent; }

                        }
                    }
                }
                else
                {
                    if (tool is MvTCP)
                    {
                        tcp = tool as MvTCP;
                        tcp.Run();
                        if (tcp != null && tcp.tcpServer != null && tcp.tcpServer.connectStatus == true) { tcp.tcpServer.ReciverEvent += Server_ReciverEvent; }
                        if (tcp != null && tcp.tcpClient != null && tcp.tcpClient.connectStatus == true) { tcp.tcpClient.ReciverEvent += Client_ReciverEvent; }

                    } 
                }
            } 
        }

        private void Client_ReciverEvent(object sender, string Data)
        {
            if (tcp.TestRunMode)
            {
                if (Data.Contains("HE") || Data.Contains("XT") || Data.Contains("TT") || Data.Contains("RF"))
                {
                    if (this.InvokeRequired)
                    {
                        this.BeginInvoke(new Action(() => tsb_Run_Click(this, new EventArgs())));
                    }
                    else
                    {
                        tsb_Run_Click(this, new EventArgs());
                    }
                }
                else
                {
                    Data = "";
                }
            }
        }

        private void Server_ReciverEvent(object sender, string Data)
        {
            if (tcp.TestRunMode)
            {
                if (Data.Contains("HE") || Data.Contains("XT") || Data.Contains("TT") || Data.Contains("RF"))
                {
                    if (this.InvokeRequired)
                    {
                        this.BeginInvoke(new Action(() => tsb_Run_Click(this, new EventArgs())));
                    }
                    else
                    {
                        tsb_Run_Click(this, new EventArgs());
                    }
                }
                else
                {
                    Data = "";
                }
            }
        }

        protected override void OnLayout(LayoutEventArgs e)
        {
            IsToolListButtonVisible = true;
            IsAutoRunButtonVisible = true;
            base.OnLayout(e);
        }

        void svToolBlockTree_ToolSelect(object sender, MvToolBase tool)
        {
            base.SvDisplayViewEdit.Subject = tool;
        }

        protected override void tsb_ToolList_Click(object sender, EventArgs e)
        {
            svToolBlockTree.ShowToolList();
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvJob Job
        {
            get { return svToolBlockTree.Job; }
            set { svToolBlockTree.Job = value; lbl_CurrentJob.Text = value.Name; }
        }

        protected override void tsb_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.InitialDirectory = PATH_JOB;
            fd.Filter = "Job files (*.job)|*.job|ToolBlock files (*.tlf)|*.tlf|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.Multiselect = false;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;
            this.Cursor = Cursors.WaitCursor;
            MvJob job = null;
            MvToolBase tool;
            string extension = System.IO.Path.GetExtension(fd.FileName).ToLower();

            if (extension.Equals(".job"))
                job = serializer.LoadJob(fd.FileName);
            else if (extension.Equals(".tlf"))
            {
                tool = serializer.LoadTool(fd.FileName);
                if (!(tool is MvToolBlock))
                    return;
                job = (tool as MvToolBlock).ToolJob;
              
            }
           
            this.Cursor = Cursors.Default;

            if (job == null)
            {
                MessageBox.Show("Job load fail");
                return;
            }

            Job.ToolList = job.ToolList;
            svToolBlockTree.RedrawAllNode();

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);

            base.SvDisplayViewEdit.ClearImage();
        }

        protected override void tsb_Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.InitialDirectory = PATH_JOB;
            string fname = lbl_CurrentJob.Text;
            fd.FileName = fname;
            fd.Filter = "Job files (*.job)|*.job|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.DefaultExt = "*.job";
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            this.Cursor = Cursors.WaitCursor;
            this.Cursor = Cursors.Default;

            string name = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);
            lbl_CurrentJob.Text = name;
            Job.Name = name;
            bool success = serializer.SaveJob(Job, fd.FileName);

            if (!success)
                MessageBox.Show("Job save fail");
            else
            {
                MessageBox.Show("Job save success");
                if (OnSaved != null) OnSaved(this, null);
            }
        }

        protected override void tsb_Run_Click(object sender, EventArgs e)
        {
            if (Job != null)
                Job.Run(true);
            float zoom = svDisplayViewEdit.Display.ZoomRatio;
            System.Drawing.Point location = svDisplayViewEdit.Display.imageLocation;

            UpdateDisplay();

            if (zoom != 1 || location != new System.Drawing.Point(0, 0))
            {
                svDisplayViewEdit.Display.ZoomRatio = zoom;
                svDisplayViewEdit.Display.imageLocation = location;
            }
        }

        void UpdateDisplay()
        {
            if (Job != null)
            {
                Job.OnRan();

                if (Job.LastRunSuccess)
                    ToolStatusImage = global::MvCore.Properties.Resources.SuccessIcon;
                else
                    ToolStatusImage = global::MvCore.Properties.Resources.FailIcon;

                ToolStatusText = string.Format("{0:F2}ms", Job.LastRunTime);
            }

            SvDisplayViewEdit.RefreshImage();
            svToolBlockTree.Refresh();
            //svToolBlockTree.RedrawAllNode();
        }

        System.Threading.CancellationTokenSource autoRunTokenSource = new System.Threading.CancellationTokenSource();

        protected override void tsb_AutoRun_Click(object sender, EventArgs e)
        {

            if (base.IsAutoRunning)
            {
                autoRunTokenSource.Cancel(true);
                autoRunTokenSource.Dispose();
            }
            else
            {
                base.IsAutoRunning = true;
                autoRunTokenSource = new System.Threading.CancellationTokenSource();
                Task autoRunTask = Task.Factory.StartNew(() =>
                    {
                        MvAcquisition acq = Job["Acquisition"] as MvAcquisition;
                        while (true)
                        {
                            if (Job != null) Job.Run(true);
                            this.Invoke(new Action(UpdateDisplay));
                            //System.Threading.Thread.Sleep(40);

                            if (autoRunTokenSource.Token == null)
                                break;
                            if (autoRunTokenSource.Token.IsCancellationRequested)
                                autoRunTokenSource.Token.ThrowIfCancellationRequested();

                            if (acq != null && acq.CameraType == CameraType.Image && acq.CurrentImageIndex == acq.InputImageList.Count)
                                break;

                        }
                    }, autoRunTokenSource.Token).ContinueWith((task) =>
                    {
                        base.IsAutoRunning = false;
                    });
            }

        }

        public void Run()
        {
            tsb_Run_Click(null, null);
        }
    }
}
