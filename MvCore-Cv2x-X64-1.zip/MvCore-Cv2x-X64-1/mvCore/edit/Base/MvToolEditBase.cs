﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.CompilerServices;
using MvCore.CameraDevice;

namespace MvCore.Edit.Base
{
    public partial class MvToolEditBase : UserControl, INotifyPropertyChanged
    {
        public string PATH_JOB = "C:\\SVL_Data\\Job";
        public string PATH_CALIB = "C:\\SVL_Data\\Calibration"; 

        public MvToolEditBase()
        {
            InitializeComponent();

            this.tsb_Run.Click += tsb_Run_Click;
            this.tsb_Load.Click += tsb_Load_Click;
            this.tsb_Save.Click += tsb_Save_Click;            
            this.tsb_ToolList.Click += tsb_ToolList_Click;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;

            this.tabControl.KeyDown += SvToolEditBase_KeyDown;

            ToolStatusImage = global::MvCore.Properties.Resources.FailIcon;
            ToolStatusText = string.Format("{0:F2}ms", 0);

            InitDisplayViewEdit();
          
        }

        public List<string> GetTypeList()
        {
            List<string> typeList = new List<string>();
            typeList.Add(typeof(MvImage).FullName);
            typeList.Add(typeof(bool).FullName);
            typeList.Add(typeof(int).FullName);
            typeList.Add(typeof(float).FullName);
            typeList.Add(typeof(double).FullName);
            typeList.Add(typeof(string).FullName);
            typeList.Add(typeof(MvBlobObject).FullName);
            typeList.Add(typeof(MvLine).FullName);
            typeList.Add(typeof(MvLineCaliper).FullName);
            typeList.Add(typeof(MvMask).FullName);
            typeList.Add(typeof(MvPoint).FullName);
            typeList.Add(typeof(MvRectangle).FullName);
            typeList.Add(typeof(MvRotationRectangle).FullName);
            typeList.Add(typeof(MvPolyLine).FullName);
            typeList.Add(typeof(Server).FullName);
            typeList.Add(typeof(Client).FullName);
            return typeList;
        }

        //public SvToolEditBase Subject // tool class
        //{
        //    get { return GetSubject() as SvToolEditBase; }
        //    set
        //    {
        //        SetSubject(value);
        //    }
        //}

        //load dữ liệu từ tool
        virtual public void formLoad() { }

        virtual public void formClosed(){ }

        virtual public void formClosing() { }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {

        }



            void SvToolEditBase_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.F5)
            //    tsb_Run_Click(null, null);
        }

        void subject_Ran(object sender, MvToolBase tool)
        {
            float oldZoom = svDisplayViewEdit.Display.ZoomRatio;
            Point oldLocation = svDisplayViewEdit.Display.imageLocation;

            svDisplayViewEdit.SetLastImage(); // daviddang edit

            svDisplayViewEdit.Display.ZoomRatio = oldZoom;
            svDisplayViewEdit.Display.imageLocation = oldLocation;
        }
        
        private MvToolBase subject;

        internal void SetSubject(MvToolBase subject)
        {
            if (this.subject != null)
                this.subject.Ran -= subject_Ran;            
            this.subject = subject;
            this.subject.Ran += subject_Ran;

            lbl_CurrentJob.Text = subject.ToString();
            UpdateStatus();

            svDisplayViewEdit.Subject = subject;
            NotifySubjectChanged(this, this.subject);
        }

        internal MvToolBase GetSubject()
        {
            return this.subject;
        }

        protected delegate void SubjectChangedHandler(object sender, MvToolBase tool);
        protected event SubjectChangedHandler SubjectChanged;

        public void NotifySubjectChanged(object sender, MvToolBase tool)
        {
            if (SubjectChanged != null)
                SubjectChanged(sender, tool);
        }


        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected MvDisplayViewEdit SvDisplayViewEdit
        {
            get { return this.svDisplayViewEdit; }
            set { this.svDisplayViewEdit = value; }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected StatusStrip StatusStrip
        {
            get { return this.statusStrip; }
            set { this.statusStrip = value; }
        }

        virtual protected void InitDisplayViewEdit()
        {
            
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected bool IsAutoRunButtonVisible
        {
            get { return tsb_AutoRun.Visible; }
            set { tsb_AutoRun.Visible = value; }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected bool IsToolListButtonVisible
        {
            get { return tsb_ToolList.Visible; }
            set { tsb_ToolList.Visible = value; }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected string ToolStatusText
        {
            get { return tssl_ProcessTime.Text; }
            set { tssl_ProcessTime.Text = value; }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected Image ToolStatusImage
        {
            get { return tssl_SuccessImage.Image; }
            set { tssl_SuccessImage.Image = value; }
        }

        void UpdateStatus()
        {
            if (subject.lastRunSuccess)
                ToolStatusImage = global::MvCore.Properties.Resources.SuccessIcon;
            else
                ToolStatusImage = global::MvCore.Properties.Resources.FailIcon;

            ToolStatusText = string.Format("{0:F2}ms", subject.lastProcessTime);
        }

        virtual protected  void tsb_ToolList_Click(object sender, System.EventArgs e)
        {           
        }

        public bool DeepCopy(object origin, object src)
        {
            Type originType = origin.GetType();
            Type srcType = src.GetType();

            if (originType != srcType) return false;

            System.Reflection.FieldInfo[] originFields = originType.GetFields(System.Reflection.BindingFlags.Instance |
                                                                              System.Reflection.BindingFlags.Public | 
                                                                              System.Reflection.BindingFlags.NonPublic |
                                                                              System.Reflection.BindingFlags.Static |
                                                                              System.Reflection.BindingFlags.DeclaredOnly);

            foreach (System.Reflection.FieldInfo info in originFields)
            {
                if (info.FieldType == typeof(SvImageInfo)) continue;
                info.SetValue(origin, info.GetValue(src));
            }

            return true;
        }

        protected MvSerializer serializer = new MvSerializer();

        virtual protected void tsb_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Tool files (*.tlf)|*.tlf|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.Multiselect = false;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            this.Cursor = Cursors.WaitCursor;
            MvToolBase tool = serializer.LoadTool(fd.FileName);
            this.Cursor = Cursors.Default;

            if (tool == null)
            {
                MessageBox.Show("Tool load fail");
                return;
            }

            if (!DeepCopy(subject, tool))
            {
                MessageBox.Show(string.Format("Tool type not match.\r\nTool file type : {0}",tool.ToString()));
                return;
            }

            SetSubject(subject);
            SvDisplayViewEdit.ClearImage();

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);     
        }

        virtual protected void tsb_Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Tool files (*.tlf)|*.tlf|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.DefaultExt = "*.tlf";
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            this.Cursor = Cursors.WaitCursor;
            bool success = serializer.SaveTool(GetSubject(), fd.FileName);
            this.Cursor = Cursors.Default;

            if (!success)
                MessageBox.Show("Tool save fail");
            else
                MessageBox.Show("Tool save success");

        }

        virtual protected void tsb_Run_Click(object sender, EventArgs e)
        {
            this.Focus();
            subject.GetInParams();
            if (subject != null)
            {
                subject.InitOutProperty();
                DateTime lastProcessTimeStart = DateTime.Now;
                subject.Run(true);
                subject.OnRan();
                subject.lastProcessTime = DateTime.Now.Subtract(lastProcessTimeStart).TotalMilliseconds;
            }
           
            UpdateStatus();
           
            // A.S.H subject_Ran에 추가되어서 제거
            //if (subject.lastRunSuccess)
            //    svDisplayViewEdit.imageListComboBox.SelectedIndex = svDisplayViewEdit.imageListComboBox.Items.Count - 1;
            float oldZoom = svDisplayViewEdit.Display.ZoomRatio;
            Point oldLocation = svDisplayViewEdit.Display.imageLocation;

            svDisplayViewEdit.RefreshImage();

            svDisplayViewEdit.Display.ZoomRatio = oldZoom;
            svDisplayViewEdit.Display.imageLocation = oldLocation;
        }

        bool isAutoRunning = false;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        protected bool IsAutoRunning
        {
            get { return isAutoRunning; }
            set
            {
                isAutoRunning = value;

                if (!isAutoRunning)
                {
                    tsb_AutoRun.Image = global::MvCore.Properties.Resources.tsb_AutoRun_Image;
                }
                else
                {
                    tsb_AutoRun.Image = global::MvCore.Properties.Resources.tsb_Stop_Image;
                }
            }
        }

        System.Threading.CancellationTokenSource autoRunTokenSource = new System.Threading.CancellationTokenSource();

        virtual protected void tsb_AutoRun_Click(object sender, EventArgs e)
        {
        }        

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
