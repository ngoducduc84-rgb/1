﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MvCore.Edit.Base
{
    public partial class MvToolEditForm : Form
    {
        public MvToolEditForm()
        { }
        public MvToolEditForm(MvToolEditBase toolEditBase)
        {
            InitializeComponent();

            this.toolEditBase = toolEditBase;

            this.toolEditBase.Dock = DockStyle.Fill;
            this.Controls.Add(this.toolEditBase);
            
            string[] name = this.toolEditBase.ToString().Split('.');

            this.Text = name.Last().Replace("Sv","");
        }
        
        public MvToolEditBase toolEditBase;

        public MvToolBase Subject
        {
            get { return toolEditBase.GetSubject(); }
            set { toolEditBase.SetSubject(value); }
        }

        protected override void OnVisibleChanged(EventArgs e)
        {
            if(this.Visible)
            {
                toolEditBase.tabControl.SelectedIndex = 0;
                if (toolEditBase.svDisplayViewEdit.imageListComboBox.Items.Count > 0)
                    toolEditBase.svDisplayViewEdit.imageListComboBox.SelectedIndex = 0;
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            this.Dispose();
            //if (e.CloseReason == CloseReason.UserClosing)
            //{
            //    //e.Cancel = true;
            //    this.Close();
            //    return;
            //}
        }

        private void SvToolEditForm_Load(object sender, EventArgs e)
        {
            toolEditBase.formLoad();
        }

        

        private void SvToolEditForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            toolEditBase.formClosed();
        }

        private void SvToolEditForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            toolEditBase.formClosing();
        }
    }
}
