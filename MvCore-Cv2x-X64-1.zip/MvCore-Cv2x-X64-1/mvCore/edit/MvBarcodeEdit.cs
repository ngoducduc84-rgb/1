﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;
using OpenCvSharp;


namespace MvCore.Edit
{
    public partial class MvBarcodeEdit : MvToolEditBase
    {
        public MvBarcodeEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvBarcodeEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("Input"))
            {
                if (Subject.InputImage != null)
                {
                    SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.RegionRect);
                    Subject.DisplayRegions(SvDisplayViewEdit.Display);
                }
            }
            else if (imageInfo.ImageName.Contains("Output"))
            {
                if (Subject.InputImage != null)
                {
                    Subject.DisplayOutRegions(SvDisplayViewEdit.Display);
                }
            }
        }

        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject)
        {
            if (drawObject == Subject.RegionRect)
            {
                RemoveRegionValueChangedEvent();

                MvRectangle regionRect = drawObject as MvRectangle;
                nud_Region_X.Value = (decimal)regionRect.Location.X;
                nud_Region_Y.Value = (decimal)regionRect.Location.Y;
                nud_Region_Width.Value = (decimal)regionRect.Width;
                nud_Region_Height.Value = (decimal)regionRect.Height;

                AddRegionValueChangedEvent();
                Subject.DisplayRegions(SvDisplayViewEdit.Display);
            }
        }
        void SvBarcodeEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]

        public MvBarcode Subject
        {
            get { return base.GetSubject() as MvBarcode; }
            set { base.SetSubject(value); }
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvBarcode), null);

            cb_BarcodeType.DisplayMember = "Key"; cb_BarcodeType.ValueMember = "Value";
            cb_BarcodeType.DataSource = Enum.GetValues(typeof(MvBarcode.BarcodeType)).Cast<MvBarcode.BarcodeType>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_BarcodeType.DataBindings.Add("SelectedValue", source, "Type", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_Region_X.DataBindings.Add("Value", source, "RegionX", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Region_Y.DataBindings.Add("Value", source, "RegionY", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Region_Width.DataBindings.Add("Value", source, "RegionWidth", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Region_Height.DataBindings.Add("Value", source, "RegionHeight", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_BarcodeIndex.DataBindings.Add("Value", source, "Index", true, DataSourceUpdateMode.OnPropertyChanged);

            DataBindings.Add("BarcodeResult", source, "ResultList", true, DataSourceUpdateMode.Never);
        }


        #region Region Event

        void AddRegionValueChangedEvent()
        {
            nud_Region_X.ValueChanged += nud_RegionRect_ValueChanged;
            nud_Region_Y.ValueChanged += nud_RegionRect_ValueChanged;
            nud_Region_Width.ValueChanged += nud_RegionRect_ValueChanged;
            nud_Region_Height.ValueChanged += nud_RegionRect_ValueChanged;
        }

        void RemoveRegionValueChangedEvent()
        {
            nud_Region_X.ValueChanged -= nud_RegionRect_ValueChanged;
            nud_Region_Y.ValueChanged -= nud_RegionRect_ValueChanged;
            nud_Region_Width.ValueChanged -= nud_RegionRect_ValueChanged;
            nud_Region_Height.ValueChanged -= nud_RegionRect_ValueChanged;
        }

        private void nud_RegionRect_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown nud = sender as NumericUpDown;

            if (nud == nud_Region_X || nud == nud_Region_Y)
            {
                Subject.RegionRect.Location = new OpenCvSharp.CPlusPlus.Point2f((float)nud_Region_X.Value, (float)nud_Region_Y.Value);
            }
            else if (nud == nud_Region_Height)
            {
                Subject.RegionRect.Height = (float)nud_Region_Height.Value;
            }
            else if (nud == nud_Region_Width)
            {
                Subject.RegionRect.Width = (float)nud_Region_Width.Value;
            }
            else return;
            Subject.DisplayRegions(SvDisplayViewEdit.Display);
        }

        private void btn_ResetRegionRect_Click(object sender, EventArgs e)
        {
            if (Subject != null && Subject.InputImage != null)
            {
                Subject.RegionRect = new MvRectangle(0, 0, Subject.InputImage.Width, Subject.InputImage.Height);
                tsb_Run_Click(this, null);
                Display_DrawObjectChanged(this, Subject.RegionRect);
            }
        }
        #endregion
        public List<SvBarcodeResults> BarcodeResult
        {
            get { throw new Exception("Can't get"); }
            set
            {
                this.Invoke(new Action(delegate 
                {
                    dg_Barcode_Result.DataSource = null; 
                    dg_Barcode_Result.DataSource = value;                

                    for (int i = 1; i < dg_Barcode_Result.Columns.Count; i++)
                    {
                        dg_Barcode_Result.Columns[i].ReadOnly = true;
                        dg_Barcode_Result.Columns[i].Resizable = DataGridViewTriState.False;
                        dg_Barcode_Result.Columns[i].Width = 40;
                    }

                    dg_Barcode_Result.Columns[0].Width = 30;
                    dg_Barcode_Result.Columns[1].Width = 80;
                    dg_Barcode_Result.Columns[2].Width = 200;
                }));
            }
        }
    }
    
}
