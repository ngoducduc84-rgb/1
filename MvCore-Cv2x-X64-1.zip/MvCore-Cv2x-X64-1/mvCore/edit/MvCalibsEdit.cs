﻿using OpenCvSharp;
using MvCore.Edit.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MvCore.Edit
{
    public partial class MvCalibsEdit : MvToolEditBase
    {
        public MvCalibsEdit()
        {
            InitializeComponent();
            initBinding();
            this.SubjectChanged += SvCalibEdit_SubjectChanged;
        }

        public override void formLoad()
        {
           
        }

        public MvCalibs Subject // tool class
        {
            get { return base.GetSubject() as MvCalibs; }
            set { base.SetSubject(value); }
        }
       
        
        BindingSource source;
        private void SvCalibEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
        void initBinding()
        {   
            source = new BindingSource(typeof(MvCalibs), null);
            cb_ToolSelect.DataBindings.Add("SelectedIndex", source, "ToolSelect", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_NumberMatrixPoint.DataBindings.Add("Value", source, "NumberMatrixPoint", true, DataSourceUpdateMode.OnPropertyChanged);
        }


    }
}
