﻿using MvCore.Edit.Base;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace MvCore.Edit
{
    public partial class MvCaliperEdit : MvToolEditBase
    {
        public MvCaliperEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvCaliperEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }
        protected override void InitDisplayViewEdit()
        {

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvCaliper Subject
        {
            get { return base.GetSubject() as MvCaliper; }
            set { base.SetSubject(value); }
        }

        void SvCaliperEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.CaliperLine);
            }
        }

        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject)
        {
            if (drawObject is MvRotationRectangle)
            {
                MvRotationRectangle rectCaliper = drawObject as MvRotationRectangle;
                RectCaliper = rectCaliper;
            }
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvCaliper), null);
            nud_Caliper_MinContrastThreshold.DataBindings.Add("Value", source, "OneCaliper.MinContrastThreshold");
            nud_Caliper_FilterHalfSize.DataBindings.Add("Value", source, "OneCaliper.FilterHalfSize");

            //npb_Img.DataBindings.Add("Caliper", source, "CaliperLine", false, DataSourceUpdateMode.OnPropertyChanged);
            //DataBindings.Add("Caliper", source, "CaliperLine.", false, DataSourceUpdateMode.Never);

            //npb_Img.DataBindings.Add("CaliperProjectionLength", source, "OneCaliper.ProjectionLength", false, DataSourceUpdateMode.OnPropertyChanged);
            //npb_Img.DataBindings.Add("CaliperSearchLength", source, "OneCaliper.SearchLength", false, DataSourceUpdateMode.OnPropertyChanged);

            DataBindings.Add("Priority", source, "OneCaliper.Priority", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("Polarity", source, "OneCaliper.Polarity", true, DataSourceUpdateMode.OnPropertyChanged);

        }

        void rb_Caliper_Polarity_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb.Checked)
                NotifyPropertyChanged("Polarity");
        }

        void rb_Caliper_Priority_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb.Checked)
                NotifyPropertyChanged("Priority");
        }

        private void nud_Caliper_CaliperLine_ValueChanged(object sender, EventArgs e)
        {
            NotifyPropertyChanged("CaliperLine");
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvLineCaliper.EdgePolarity Polarity
        {
            get
            {
                MvLineCaliper.EdgePolarity caliperPolarity = MvLineCaliper.EdgePolarity.Dark_to_Light;
                if (rb_Caliper_AnyPolarity.Checked)
                    caliperPolarity = MvLineCaliper.EdgePolarity.Any_Polarity;
                else if (rb_Caliper_DtoL.Checked)
                    caliperPolarity = MvLineCaliper.EdgePolarity.Dark_to_Light;
                else if (rb_Caliper_LtoD.Checked)
                    caliperPolarity = MvLineCaliper.EdgePolarity.Light_to_Dark;
                else
                    throw new Exception("프로그램 잘못짬");

                return caliperPolarity;
            }
            set
            {
                if (value == MvLineCaliper.EdgePolarity.Any_Polarity)
                    rb_Caliper_AnyPolarity.Checked = true;
                else if (value == MvLineCaliper.EdgePolarity.Dark_to_Light)
                    rb_Caliper_DtoL.Checked = true;
                else if (value == MvLineCaliper.EdgePolarity.Light_to_Dark)
                    rb_Caliper_LtoD.Checked = true;
                else
                    throw new Exception("프로그램 잘못짬");
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvLineCaliper.CaliperPriority Priority
        {
            get
            {
                MvLineCaliper.CaliperPriority caliperPriority = MvLineCaliper.CaliperPriority.Peak;
                if (rb_Caliper_Peak.Checked)
                    caliperPriority = MvLineCaliper.CaliperPriority.Peak;
                else if (rb_Caliper_Last.Checked)
                    caliperPriority = MvLineCaliper.CaliperPriority.Last;
                else if (rb_Caliper_First.Checked)
                    caliperPriority = MvLineCaliper.CaliperPriority.First;
                else
                    throw new Exception("프로그램 잘못짬");

                return caliperPriority;
            }
            set
            {
                if (value == MvLineCaliper.CaliperPriority.First)
                    rb_Caliper_First.Checked = true;
                else if (value == MvLineCaliper.CaliperPriority.Last)
                    rb_Caliper_Last.Checked = true;
                else if (value == MvLineCaliper.CaliperPriority.Peak)
                    rb_Caliper_Peak.Checked = true;
                else
                    throw new Exception("프로그램 잘못짬");
            }
        }

        /*
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public SvLine CaliperLine
        {
            get
            {
                SvLine line = new SvLine();
                line.SP = new OpenCvSharp.CPlusPlus.Point2d((double)nud_Caliper_SpX.Value, (double)nud_Caliper_SpY.Value);
                line.EP = new OpenCvSharp.CPlusPlus.Point2d((double)nud_Caliper_Width.Value, (double)nud_Caliper_Height.Value);
                return line;
            }
            set
            {
                nud_Caliper_SpX.Value = (decimal)value.SP.X;
                nud_Caliper_SpY.Value = (decimal)value.SP.Y;
                nud_Caliper_Width.Value = (decimal)value.EP.X;
                nud_Caliper_Height.Value = (decimal)value.EP.Y;
            }
        }
        */
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvRotationRectangle RectCaliper
        {
            get
            {
                return new MvRotationRectangle((float)nud_Caliper_SpX.Value, (float)nud_Caliper_SpY.Value, (float)nud_Caliper_Width.Value, (float)nud_Caliper_Height.Value);
            }
            set
            {

                nud_Caliper_SpX.Value = (decimal)value.Location.X;
                nud_Caliper_SpY.Value = (decimal)value.Location.Y;
                nud_Caliper_Width.Value = (decimal)value.Width;
                nud_Caliper_Height.Value = (decimal)value.Height;

            }
        }

    }
}
