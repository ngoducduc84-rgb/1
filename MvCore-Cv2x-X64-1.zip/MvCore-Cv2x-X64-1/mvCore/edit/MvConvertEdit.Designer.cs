﻿namespace MvCore.Edit
{
    partial class MvConvertEdit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void  InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MvConvertEdit));
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dg_Input = new System.Windows.Forms.DataGridView();
            this.dgtbc_Input_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcbc_Input_Type = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsb_Input_Add = new System.Windows.Forms.ToolStripButton();
            this.tsb_Input_Remove = new System.Windows.Forms.ToolStripButton();
            this.tsb_Input_Up = new System.Windows.Forms.ToolStripButton();
            this.tsb_Input_Down = new System.Windows.Forms.ToolStripButton();
            this.lbl_Input = new System.Windows.Forms.ToolStripLabel();
            this.dg_Output = new System.Windows.Forms.DataGridView();
            this.dgtbc_Output_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgcbc_Output_Type = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.tsb_Output_Add = new System.Windows.Forms.ToolStripButton();
            this.tsb_Output_Remove = new System.Windows.Forms.ToolStripButton();
            this.tsb_Output_Up = new System.Windows.Forms.ToolStripButton();
            this.tsb_Output_Down = new System.Windows.Forms.ToolStripButton();
            this.lbl_Output = new System.Windows.Forms.ToolStripLabel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Input)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Output)).BeginInit();
            this.toolStrip2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(442, 426);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "input/output";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dg_Input);
            this.splitContainer1.Panel1.Controls.Add(this.toolStrip1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dg_Output);
            this.splitContainer1.Panel2.Controls.Add(this.toolStrip2);
            this.splitContainer1.Size = new System.Drawing.Size(442, 426);
            this.splitContainer1.SplitterDistance = 195;
            this.splitContainer1.TabIndex = 0;
            // 
            // dg_Input
            // 
            this.dg_Input.AllowUserToAddRows = false;
            this.dg_Input.AllowUserToDeleteRows = false;
            this.dg_Input.AllowUserToResizeRows = false;
            this.dg_Input.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dg_Input.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgtbc_Input_Name,
            this.dgcbc_Input_Type});
            this.dg_Input.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg_Input.Location = new System.Drawing.Point(0, 25);
            this.dg_Input.MultiSelect = false;
            this.dg_Input.Name = "dg_Input";
            this.dg_Input.RowHeadersVisible = false;
            this.dg_Input.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dg_Input.RowTemplate.Height = 23;
            this.dg_Input.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_Input.Size = new System.Drawing.Size(442, 170);
            this.dg_Input.TabIndex = 6;
            // 
            // dgtbc_Input_Name
            // 
            this.dgtbc_Input_Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dgtbc_Input_Name.FillWeight = 40F;
            this.dgtbc_Input_Name.HeaderText = "Name";
            this.dgtbc_Input_Name.Name = "dgtbc_Input_Name";
            this.dgtbc_Input_Name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dgcbc_Input_Type
            // 
            this.dgcbc_Input_Type.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dgcbc_Input_Type.FillWeight = 80F;
            this.dgcbc_Input_Type.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dgcbc_Input_Type.HeaderText = "Type";
            this.dgcbc_Input_Type.Name = "dgcbc_Input_Type";
            this.dgcbc_Input_Type.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsb_Input_Add,
            this.tsb_Input_Remove,
            this.tsb_Input_Up,
            this.tsb_Input_Down,
            this.lbl_Input});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(442, 25);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "menuStrip1";
            // 
            // tsb_Input_Add
            // 
            this.tsb_Input_Add.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Input_Add.Image = global::MvCore.Properties.Resources.Add;
            this.tsb_Input_Add.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Input_Add.Name = "tsb_Input_Add";
            this.tsb_Input_Add.Size = new System.Drawing.Size(23, 22);
            this.tsb_Input_Add.Text = "Add";
            this.tsb_Input_Add.Click += new System.EventHandler(this.tsb_Input_Click);
            // 
            // tsb_Input_Remove
            // 
            this.tsb_Input_Remove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Input_Remove.Image = global::MvCore.Properties.Resources.Remove;
            this.tsb_Input_Remove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Input_Remove.Name = "tsb_Input_Remove";
            this.tsb_Input_Remove.Size = new System.Drawing.Size(23, 22);
            this.tsb_Input_Remove.Text = "Remove";
            this.tsb_Input_Remove.Click += new System.EventHandler(this.tsb_Input_Click);
            // 
            // tsb_Input_Up
            // 
            this.tsb_Input_Up.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Input_Up.Image = global::MvCore.Properties.Resources.Up;
            this.tsb_Input_Up.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Input_Up.Name = "tsb_Input_Up";
            this.tsb_Input_Up.Size = new System.Drawing.Size(23, 22);
            this.tsb_Input_Up.Text = "Up";
            this.tsb_Input_Up.Click += new System.EventHandler(this.tsb_Input_Click);
            // 
            // tsb_Input_Down
            // 
            this.tsb_Input_Down.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Input_Down.Image = ((System.Drawing.Image)(resources.GetObject("tsb_Input_Down.Image")));
            this.tsb_Input_Down.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Input_Down.Name = "tsb_Input_Down";
            this.tsb_Input_Down.Size = new System.Drawing.Size(23, 22);
            this.tsb_Input_Down.Text = "Down";
            this.tsb_Input_Down.Click += new System.EventHandler(this.tsb_Input_Click);
            // 
            // lbl_Input
            // 
            this.lbl_Input.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lbl_Input.AutoSize = false;
            this.lbl_Input.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.lbl_Input.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lbl_Input.Name = "lbl_Input";
            this.lbl_Input.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.lbl_Input.Size = new System.Drawing.Size(300, 22);
            this.lbl_Input.Text = "Input";
            // 
            // dg_Output
            // 
            this.dg_Output.AllowUserToAddRows = false;
            this.dg_Output.AllowUserToDeleteRows = false;
            this.dg_Output.AllowUserToResizeRows = false;
            this.dg_Output.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dg_Output.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgtbc_Output_Name,
            this.dgcbc_Output_Type});
            this.dg_Output.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg_Output.Location = new System.Drawing.Point(0, 25);
            this.dg_Output.MultiSelect = false;
            this.dg_Output.Name = "dg_Output";
            this.dg_Output.RowHeadersVisible = false;
            this.dg_Output.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dg_Output.RowTemplate.Height = 23;
            this.dg_Output.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_Output.Size = new System.Drawing.Size(442, 202);
            this.dg_Output.TabIndex = 8;
            // 
            // dgtbc_Output_Name
            // 
            this.dgtbc_Output_Name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dgtbc_Output_Name.FillWeight = 40F;
            this.dgtbc_Output_Name.HeaderText = "Name";
            this.dgtbc_Output_Name.Name = "dgtbc_Output_Name";
            this.dgtbc_Output_Name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dgcbc_Output_Type
            // 
            this.dgcbc_Output_Type.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dgcbc_Output_Type.FillWeight = 80F;
            this.dgcbc_Output_Type.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dgcbc_Output_Type.HeaderText = "Type";
            this.dgcbc_Output_Type.Name = "dgcbc_Output_Type";
            this.dgcbc_Output_Type.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // toolStrip2
            // 
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsb_Output_Add,
            this.tsb_Output_Remove,
            this.tsb_Output_Up,
            this.tsb_Output_Down,
            this.lbl_Output});
            this.toolStrip2.Location = new System.Drawing.Point(0, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(442, 25);
            this.toolStrip2.TabIndex = 7;
            this.toolStrip2.Text = "menuStrip2";
            // 
            // tsb_Output_Add
            // 
            this.tsb_Output_Add.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Output_Add.Image = global::MvCore.Properties.Resources.Add;
            this.tsb_Output_Add.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Output_Add.Name = "tsb_Output_Add";
            this.tsb_Output_Add.Size = new System.Drawing.Size(23, 22);
            this.tsb_Output_Add.Text = "Add";
            this.tsb_Output_Add.Click += new System.EventHandler(this.tsb_Output_Click);
            // 
            // tsb_Output_Remove
            // 
            this.tsb_Output_Remove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Output_Remove.Image = global::MvCore.Properties.Resources.Remove;
            this.tsb_Output_Remove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Output_Remove.Name = "tsb_Output_Remove";
            this.tsb_Output_Remove.Size = new System.Drawing.Size(23, 22);
            this.tsb_Output_Remove.Text = "Remove";
            this.tsb_Output_Remove.Click += new System.EventHandler(this.tsb_Output_Click);
            // 
            // tsb_Output_Up
            // 
            this.tsb_Output_Up.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Output_Up.Image = global::MvCore.Properties.Resources.Up;
            this.tsb_Output_Up.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Output_Up.Name = "tsb_Output_Up";
            this.tsb_Output_Up.Size = new System.Drawing.Size(23, 22);
            this.tsb_Output_Up.Text = "Up";
            this.tsb_Output_Up.Click += new System.EventHandler(this.tsb_Output_Click);
            // 
            // tsb_Output_Down
            // 
            this.tsb_Output_Down.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsb_Output_Down.Image = ((System.Drawing.Image)(resources.GetObject("tsb_Output_Down.Image")));
            this.tsb_Output_Down.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_Output_Down.Name = "tsb_Output_Down";
            this.tsb_Output_Down.Size = new System.Drawing.Size(23, 22);
            this.tsb_Output_Down.Text = "Down";
            this.tsb_Output_Down.Click += new System.EventHandler(this.tsb_Output_Click);
            // 
            // lbl_Output
            // 
            this.lbl_Output.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.lbl_Output.AutoSize = false;
            this.lbl_Output.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.lbl_Output.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.lbl_Output.Name = "lbl_Output";
            this.lbl_Output.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.lbl_Output.Size = new System.Drawing.Size(300, 22);
            this.lbl_Output.Text = "Output";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.cb_type);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(442, 426);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Param";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Type";
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Items.AddRange(new object[] {
            "String  -> List",
            "List -> String"});
            this.cb_type.Location = new System.Drawing.Point(66, 15);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(121, 21);
            this.cb_type.TabIndex = 0;
            this.cb_type.Text = "Type";
            this.cb_type.SelectedIndexChanged += new System.EventHandler(this.cb_type_SelectedIndexChanged);
            // 
            // SvConvertEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "SvConvertEdit";
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_Input)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Output)).EndInit();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsb_Input_Add;
        private System.Windows.Forms.ToolStripButton tsb_Input_Remove;
        private System.Windows.Forms.ToolStripButton tsb_Input_Up;
        private System.Windows.Forms.ToolStripButton tsb_Input_Down;
        private System.Windows.Forms.ToolStripLabel lbl_Input;
        private System.Windows.Forms.DataGridView dg_Input;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtbc_Input_Name;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgcbc_Input_Type;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton tsb_Output_Add;
        private System.Windows.Forms.ToolStripButton tsb_Output_Remove;
        private System.Windows.Forms.ToolStripButton tsb_Output_Up;
        private System.Windows.Forms.ToolStripButton tsb_Output_Down;
        private System.Windows.Forms.ToolStripLabel lbl_Output;
        private System.Windows.Forms.DataGridView dg_Output;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtbc_Output_Name;
        private System.Windows.Forms.DataGridViewComboBoxColumn dgcbc_Output_Type;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_type;
    }
}
