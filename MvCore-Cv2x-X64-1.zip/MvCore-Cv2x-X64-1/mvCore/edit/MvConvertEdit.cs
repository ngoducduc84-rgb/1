﻿using MvCore.Core;
using MvCore.Edit.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MvCore.Edit
{
    public partial class MvConvertEdit : MvToolEditBase
    {
        MvCore.Core.MvToolBlockTreeView parentTreeView;

        public MvConvertEdit()
        {
            InitializeComponent();
            base.SubjectChanged += SvToolBlockEdit_SubjectChanged;
        }

        public MvConvertEdit(MvCore.Core.MvToolBlockTreeView parentTreeView)
            : this()
        {
            this.parentTreeView = parentTreeView;
        }
       

        public MvConvert Subject // tool class
        {
            get { return base.GetSubject() as MvConvert; }
            set { base.SetSubject(value); }
        }

        public override void formLoad()
        {
            if (Subject != null)
            {
                InitDataGrid();
                cb_type.SelectedIndex = Subject.M_Type;
            }
        }
        void SvToolBlockEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            //Subject.RestoreTool();

            //if (parentTreeView != null)
            //    parentTreeView.RedrawAllNode();

            //svToolBlockTree.SetToolBlockInOutput(Subject);
            UpdateDataGrid();
        }
        #region DataGrid

        bool isEdit = false;
        void UpdateDataGrid()
        {
            try
            {
                dg_Input.RowValidated -= dg_RowValidated;
                dg_Output.RowValidated -= dg_RowValidated;

                dg_Input.RowValidating -= dg_RowValidating;
                dg_Output.RowValidating -= dg_RowValidating;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            dg_Input.Rows.Clear();
            foreach (object[] obj in Subject.GetInputs())
            {
                dg_Input.Rows.Add(obj);
            }

            dg_Output.Rows.Clear();
            foreach (object[] obj in Subject.GetOutputs())
            {
                dg_Output.Rows.Add(obj);
            }

            try
            {
                dg_Input.RowValidated += dg_RowValidated;
                dg_Output.RowValidated += dg_RowValidated;

                dg_Input.RowValidating += dg_RowValidating;
                dg_Output.RowValidating += dg_RowValidating;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        void InitDataGrid()
        {
            DataGridViewComboBoxColumn column;
            column = dg_Input.Columns[1] as DataGridViewComboBoxColumn;
            column.DataSource = GetTypeList();
            column = dg_Output.Columns[1] as DataGridViewComboBoxColumn;
            column.DataSource = GetTypeList();

            dg_Input.RowValidated += dg_RowValidated;
            dg_Output.RowValidated += dg_RowValidated;

            dg_Input.RowValidating += dg_RowValidating;
            dg_Output.RowValidating += dg_RowValidating;

            dg_Input.CellBeginEdit += (sender, e) =>
            {
                isEdit = true;
            };

            dg_Output.CellBeginEdit += (sender, e) =>
            {
                isEdit = true;
            };
        }

        void dg_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            DataGridView dg = sender as DataGridView;

            if (e.ColumnIndex == 0)
            {
                string newName = dg.Rows[e.RowIndex].Cells[0].Value as string;

                if (string.IsNullOrEmpty(newName))
                {
                    MessageBox.Show("Name can not be empty");
                    e.Cancel = true;
                    return;
                }

                foreach (DataGridViewRow row in dg.Rows)
                {
                    if (row.IsNewRow) continue;
                    if (e.RowIndex == row.Index) continue;
                    string name = row.Cells[0].Value as string;
                    if (name == newName)
                    {
                        MessageBox.Show("Name is already exist");
                        dg.Rows[e.RowIndex].Cells[0].Value = "";
                        e.Cancel = true;
                        return;
                    }
                }
            }

            if (e.ColumnIndex == 1)
            {
                object value = dg.Rows[e.RowIndex].Cells[1].Value;
                if (value == null)
                {
                    MessageBox.Show("Type can not be 'Null'");
                    e.Cancel = true;
                    return;
                }
            }
            isEdit = false;
        }

        void dg_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            DataGridView dg = sender as DataGridView;

            if (Subject == null) return;

            if (dg == dg_Input)
            {
                Subject.ClearInput();
                foreach (DataGridViewRow row in dg.Rows)
                {
                    if (row.IsNewRow) continue;
                    string name = row.Cells[0].Value as string;
                    Type type = Type.GetType(row.Cells[1].Value as string);
                    if (type == null) return;
                    Subject.AddInput(name, type);
                }
            }
            else if (dg == dg_Output)
            {
                Subject.ClearOutput();
                //List<string> notDeletingList = new List<string>();
                foreach (DataGridViewRow row in dg.Rows)
                {
                    if (row.IsNewRow) continue;
                    string name = row.Cells[0].Value as string;
                    Type type = Type.GetType(row.Cells[1].Value as string);
                    if (type == null) return;
                    //notDeletingList.Add(name); 
                    Subject.AddOutput(name, type);
                }

                //List<string> keys = Subject.outputTool.inParams.Keys.ToList();
                //foreach(string key in keys)
                //{
                //    if (!notDeletingList.Contains(key))
                //        Subject.outputTool.inParams.Remove(key);
                //}
            }

            if (parentTreeView != null)
                parentTreeView.RedrawAllNode();  
        }

        private void tsb_Input_Click(object sender, EventArgs e)
        {
            ToolStripButton btn = sender as ToolStripButton;
            DataGridView dg = dg_Input;
            DataGridAction(dg, btn);
        }

        private void tsb_Output_Click(object sender, EventArgs e)
        {
            ToolStripButton btn = sender as ToolStripButton;
            DataGridView dg = dg_Output;
            DataGridAction(dg, btn);
        }

        void DataGridAction(DataGridView dg, ToolStripButton btn)
        {
            if (isEdit) return;

            if (btn == tsb_Input_Add || btn == tsb_Output_Add)
            {
                dg.Rows.Add(new object[2] { "", typeof(MvImage).FullName });
                dg.CurrentCell = dg.Rows[dg.Rows.Count - 1].Cells[0];
                dg.BeginEdit(false);
                isEdit = true;
            }
            else if (btn == tsb_Input_Remove || btn == tsb_Output_Remove)
            {
                if (dg.SelectedRows.Count == 0 || dg.SelectedRows[0].IsNewRow) return;
                dg.Rows.Remove(dg.SelectedRows[0]);
            }
            else if (btn == tsb_Input_Up || btn == tsb_Output_Up)
            {
                if (dg.SelectedRows.Count == 0 || dg.SelectedRows[0].IsNewRow) return;
                int index = dg.Rows.IndexOf(dg.SelectedRows[0]);
                DataGridViewRow selectedRow = dg.Rows[index];
                if (index - 1 < 0) return;

                dg.RowValidated -= dg_RowValidated;
                dg.Rows.RemoveAt(index);
                dg.Rows.Insert(index - 1, selectedRow);
                dg.CurrentCell = selectedRow.Cells[0];
                dg.RowValidated += dg_RowValidated;
            }
            else if (btn == tsb_Input_Down || btn == tsb_Output_Down)
            {
                if (dg.SelectedRows.Count == 0 || dg.SelectedRows[0].IsNewRow) return;
                int index = dg.Rows.IndexOf(dg.SelectedRows[0]);
                DataGridViewRow selectedRow = dg.Rows[index];
                if (index + 1 >= dg.Rows.Count) return;

                dg.RowValidated -= dg_RowValidated;
                dg.Rows.RemoveAt(index);
                dg.Rows.Insert(index + 1, selectedRow);
                dg.CurrentCell = selectedRow.Cells[0];
                dg.RowValidated += dg_RowValidated;
            }

            dg_RowValidated(dg, null);
        }

        #endregion

        private void cb_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            Subject.M_Type =  cb_type.SelectedIndex;
        }
    }
}