﻿namespace MvCore.Edit
{
    partial class MvCreateCircleEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.nud_FindCircle_CenterX = new System.Windows.Forms.NumericUpDown();
            this.nud_FindCircle_CenterY = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nud_FindCircle_R = new System.Windows.Forms.NumericUpDown();
            this.tp_Setting = new System.Windows.Forms.TabPage();
            this.tabControl.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_CenterX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_CenterY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_R)).BeginInit();
            this.tp_Setting.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Setting);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_FindCircle_R);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.nud_FindCircle_CenterY);
            this.groupBox1.Controls.Add(this.nud_FindCircle_CenterX);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(305, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(134, 94);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Center";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "X: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Y: ";
            // 
            // nud_FindCircle_CenterX
            // 
            this.nud_FindCircle_CenterX.DecimalPlaces = 3;
            this.nud_FindCircle_CenterX.Location = new System.Drawing.Point(63, 16);
            this.nud_FindCircle_CenterX.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_FindCircle_CenterX.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_CenterX.Name = "nud_FindCircle_CenterX";
            this.nud_FindCircle_CenterX.Size = new System.Drawing.Size(69, 20);
            this.nud_FindCircle_CenterX.TabIndex = 22;
            this.nud_FindCircle_CenterX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_FindCircle_CenterX.ValueChanged += new System.EventHandler(this.nud_FindCircle_CaliperCircle_ValueChanged);
            // 
            // nud_FindCircle_CenterY
            // 
            this.nud_FindCircle_CenterY.DecimalPlaces = 3;
            this.nud_FindCircle_CenterY.Location = new System.Drawing.Point(63, 45);
            this.nud_FindCircle_CenterY.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_FindCircle_CenterY.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_CenterY.Name = "nud_FindCircle_CenterY";
            this.nud_FindCircle_CenterY.Size = new System.Drawing.Size(69, 20);
            this.nud_FindCircle_CenterY.TabIndex = 24;
            this.nud_FindCircle_CenterY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_FindCircle_CenterY.ValueChanged += new System.EventHandler(this.nud_FindCircle_CaliperCircle_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "R: ";
            // 
            // nud_FindCircle_R
            // 
            this.nud_FindCircle_R.DecimalPlaces = 3;
            this.nud_FindCircle_R.Location = new System.Drawing.Point(63, 71);
            this.nud_FindCircle_R.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_FindCircle_R.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_R.Name = "nud_FindCircle_R";
            this.nud_FindCircle_R.Size = new System.Drawing.Size(69, 20);
            this.nud_FindCircle_R.TabIndex = 26;
            this.nud_FindCircle_R.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_FindCircle_R.ValueChanged += new System.EventHandler(this.nud_FindCircle_CaliperCircle_ValueChanged);
            // 
            // tp_Setting
            // 
            this.tp_Setting.Controls.Add(this.groupBox1);
            this.tp_Setting.Location = new System.Drawing.Point(4, 22);
            this.tp_Setting.Name = "tp_Setting";
            this.tp_Setting.Size = new System.Drawing.Size(442, 426);
            this.tp_Setting.TabIndex = 0;
            this.tp_Setting.Text = "Setting";
            this.tp_Setting.UseVisualStyleBackColor = true;
            // 
            // MvCreateCircleEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "MvCreateCircleEdit";
            this.tabControl.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_CenterX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_CenterY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_R)).EndInit();
            this.tp_Setting.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Setting;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_R;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_CenterY;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_CenterX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
    }
}
