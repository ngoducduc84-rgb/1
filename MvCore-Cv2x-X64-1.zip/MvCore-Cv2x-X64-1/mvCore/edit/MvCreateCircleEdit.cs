﻿using MvCore.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MvCore.Edit
{
    public partial class MvCreateCircleEdit : MvToolEditBase
    {
        public MvCreateCircleEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvFindLineEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }
        void SvFindLineEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
        public MvCreateCricle Subject
        {
            get { return base.GetSubject() as MvCreateCricle; }
            set { base.SetSubject(value); }
        }

        BindingSource source;
        void InitBinding()
        {
            source = new BindingSource(typeof(MvCreateCricle), null);


            //nud_FindCircle_width.DataBindings.Add("Value", source, "Circle.Width", true, DataSourceUpdateMode.OnPropertyChanged);
            //nud_FindCircle_height.DataBindings.Add("Value", source, "Circle.Height", true, DataSourceUpdateMode.OnPropertyChanged);
            //nud_FindCircle_CenterX.DataBindings.Add("Value", source, "CX", true, DataSourceUpdateMode.OnPropertyChanged);
            //nud_FindCircle_CenterY.DataBindings.Add("Value", source, "CY", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("Circle", source, "Circle", true, DataSourceUpdateMode.OnPropertyChanged);
            //DataBindings.Add("FindLineResult", source, "ResultList", true, DataSourceUpdateMode.Never);
        }
        private void nud_FindCircle_CaliperCircle_ValueChanged(object sender, EventArgs e)
        {
            if (lockEvent == false)
            {
                NotifyPropertyChanged("Circle");
                svDisplayViewEdit.Refresh(); //Refresh draw image
            }
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.Circle);
            }
        }
        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject) //update new Circle
        {
            if (drawObject is MvCircle)
            {
                MvCircle elipse = drawObject as MvCircle;
                Circle = elipse;
            }
        }
        bool lockEvent = false;
        private MvCircle circle;
        public MvCircle Circle
        {
            get
            {

                //circle.Width = (float)nud_FindCircle_width.Value;
                //circle.Height = (float)nud_FindCircle_height.Value;
                circle.R = (float)nud_FindCircle_R.Value;
                circle.Center = new OpenCvSharp.CPlusPlus.Point2d((double)nud_FindCircle_CenterX.Value, (double)nud_FindCircle_CenterY.Value);
                return circle;
            }
            set
            {

                lockEvent = true;
                circle = value;
                //nud_FindCircle_width.Value = (decimal)value.Width;
                //nud_FindCircle_height.Value = (decimal)value.Height;
                nud_FindCircle_R.Value = (decimal)value.R;
                nud_FindCircle_CenterX.Value = (decimal)value.Center.X;
                nud_FindCircle_CenterY.Value = (decimal)value.Center.Y;
                //svDisplayViewEdit.Refresh(); //Refresh draw image
                lockEvent = false;

            }
        }
    }
}
