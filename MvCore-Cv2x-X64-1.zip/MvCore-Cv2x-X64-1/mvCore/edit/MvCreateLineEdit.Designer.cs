﻿namespace MvCore.Edit
{
    partial class MvCreateLineEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_Setting = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nud_PoinA_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_PoinA_X = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_mode = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cb_lineMode = new System.Windows.Forms.ComboBox();
            this.nud_Line_EpY = new System.Windows.Forms.NumericUpDown();
            this.nud_Line_Length = new System.Windows.Forms.NumericUpDown();
            this.nud_Line_EpX = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.nud_Line_SpX = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.nud_Line_SpY = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nud_Line_Angle = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabControl.SuspendLayout();
            this.tp_Setting.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PoinA_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PoinA_X)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_EpY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_Length)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_EpX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_SpX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_SpY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_Angle)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Setting);
            // 
            // tp_Setting
            // 
            this.tp_Setting.Controls.Add(this.groupBox3);
            this.tp_Setting.Controls.Add(this.label3);
            this.tp_Setting.Controls.Add(this.cb_mode);
            this.tp_Setting.Controls.Add(this.groupBox2);
            this.tp_Setting.Location = new System.Drawing.Point(4, 22);
            this.tp_Setting.Name = "tp_Setting";
            this.tp_Setting.Size = new System.Drawing.Size(442, 426);
            this.tp_Setting.TabIndex = 0;
            this.tp_Setting.Text = "Setting";
            this.tp_Setting.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.nud_PoinA_Y);
            this.groupBox3.Controls.Add(this.nud_PoinA_X);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(167, 41);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(117, 89);
            this.groupBox3.TabIndex = 29;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Point A";
            // 
            // nud_PoinA_Y
            // 
            this.nud_PoinA_Y.DecimalPlaces = 3;
            this.nud_PoinA_Y.Location = new System.Drawing.Point(39, 47);
            this.nud_PoinA_Y.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_PoinA_Y.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_PoinA_Y.Name = "nud_PoinA_Y";
            this.nud_PoinA_Y.Size = new System.Drawing.Size(69, 20);
            this.nud_PoinA_Y.TabIndex = 24;
            this.nud_PoinA_Y.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_PoinA_Y.ValueChanged += new System.EventHandler(this.nud_CreateLine_3pX_ValueChanged);
            // 
            // nud_PoinA_X
            // 
            this.nud_PoinA_X.DecimalPlaces = 3;
            this.nud_PoinA_X.Location = new System.Drawing.Point(39, 18);
            this.nud_PoinA_X.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_PoinA_X.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_PoinA_X.Name = "nud_PoinA_X";
            this.nud_PoinA_X.Size = new System.Drawing.Size(69, 20);
            this.nud_PoinA_X.TabIndex = 22;
            this.nud_PoinA_X.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_PoinA_X.ValueChanged += new System.EventHandler(this.nud_CreateLine_3pX_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Y: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "X: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "Mode: ";
            // 
            // cb_mode
            // 
            this.cb_mode.FormattingEnabled = true;
            this.cb_mode.Location = new System.Drawing.Point(53, 3);
            this.cb_mode.Name = "cb_mode";
            this.cb_mode.Size = new System.Drawing.Size(117, 21);
            this.cb_mode.TabIndex = 32;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cb_lineMode);
            this.groupBox2.Controls.Add(this.nud_Line_EpY);
            this.groupBox2.Controls.Add(this.nud_Line_Length);
            this.groupBox2.Controls.Add(this.nud_Line_EpX);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.nud_Line_SpX);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.nud_Line_SpY);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.nud_Line_Angle);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(20, 41);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(126, 222);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Line A";
            // 
            // cb_lineMode
            // 
            this.cb_lineMode.FormattingEnabled = true;
            this.cb_lineMode.Location = new System.Drawing.Point(17, 185);
            this.cb_lineMode.Name = "cb_lineMode";
            this.cb_lineMode.Size = new System.Drawing.Size(97, 21);
            this.cb_lineMode.TabIndex = 34;
            this.cb_lineMode.SelectedValueChanged += new System.EventHandler(this.cb_lineMode_SelectedValueChanged);
            // 
            // nud_Line_EpY
            // 
            this.nud_Line_EpY.DecimalPlaces = 3;
            this.nud_Line_EpY.Location = new System.Drawing.Point(45, 150);
            this.nud_Line_EpY.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Line_EpY.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Line_EpY.Name = "nud_Line_EpY";
            this.nud_Line_EpY.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_EpY.TabIndex = 24;
            this.nud_Line_EpY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_EpY.ValueChanged += new System.EventHandler(this.nud_FindCircle_caliperLine_ValueChanged);
            // 
            // nud_Line_Length
            // 
            this.nud_Line_Length.DecimalPlaces = 3;
            this.nud_Line_Length.Location = new System.Drawing.Point(45, 95);
            this.nud_Line_Length.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Line_Length.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Line_Length.Name = "nud_Line_Length";
            this.nud_Line_Length.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_Length.TabIndex = 35;
            this.nud_Line_Length.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_Length.ValueChanged += new System.EventHandler(this.nud_FindCircle_caliperLine_ValueChanged);
            // 
            // nud_Line_EpX
            // 
            this.nud_Line_EpX.DecimalPlaces = 3;
            this.nud_Line_EpX.Location = new System.Drawing.Point(45, 121);
            this.nud_Line_EpX.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Line_EpX.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Line_EpX.Name = "nud_Line_EpX";
            this.nud_Line_EpX.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_EpX.TabIndex = 22;
            this.nud_Line_EpX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_EpX.ValueChanged += new System.EventHandler(this.nud_FindCircle_caliperLine_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 152);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "EY: ";
            // 
            // nud_Line_SpX
            // 
            this.nud_Line_SpX.DecimalPlaces = 3;
            this.nud_Line_SpX.Location = new System.Drawing.Point(45, 17);
            this.nud_Line_SpX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Line_SpX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Line_SpX.Name = "nud_Line_SpX";
            this.nud_Line_SpX.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_SpX.TabIndex = 27;
            this.nud_Line_SpX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_SpX.ValueChanged += new System.EventHandler(this.nud_FindCircle_caliperLine_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 124);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "EX: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "Length: ";
            // 
            // nud_Line_SpY
            // 
            this.nud_Line_SpY.DecimalPlaces = 3;
            this.nud_Line_SpY.Location = new System.Drawing.Point(45, 43);
            this.nud_Line_SpY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Line_SpY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Line_SpY.Name = "nud_Line_SpY";
            this.nud_Line_SpY.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_SpY.TabIndex = 30;
            this.nud_Line_SpY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_SpY.ValueChanged += new System.EventHandler(this.nud_FindCircle_caliperLine_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "SX: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "SY: ";
            // 
            // nud_Line_Angle
            // 
            this.nud_Line_Angle.DecimalPlaces = 3;
            this.nud_Line_Angle.Location = new System.Drawing.Point(45, 69);
            this.nud_Line_Angle.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Line_Angle.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Line_Angle.Name = "nud_Line_Angle";
            this.nud_Line_Angle.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_Angle.TabIndex = 26;
            this.nud_Line_Angle.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_Angle.ValueChanged += new System.EventHandler(this.nud_FindCircle_caliperLine_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "Angle: ";
            // 
            // MvCreateLineEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "MvCreateLineEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Setting.ResumeLayout(false);
            this.tp_Setting.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PoinA_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PoinA_X)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_EpY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_Length)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_EpX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_SpX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_SpY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_Angle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Setting;
        private System.Windows.Forms.NumericUpDown nud_Line_SpX;
        private System.Windows.Forms.NumericUpDown nud_Line_EpY;
        private System.Windows.Forms.NumericUpDown nud_Line_EpX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nud_Line_SpY;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.NumericUpDown nud_Line_Angle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_mode;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown nud_PoinA_Y;
        private System.Windows.Forms.NumericUpDown nud_PoinA_X;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nud_Line_Length;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cb_lineMode;
    }
}
