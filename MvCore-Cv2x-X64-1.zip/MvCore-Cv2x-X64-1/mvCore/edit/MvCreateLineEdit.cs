﻿using MvCore.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace MvCore.Edit
{
    public partial class MvCreateLineEdit : MvToolEditBase
    {
        public MvCreateLineEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvFindLineEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }
        void SvFindLineEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
        public MvCreateLine Subject
        {
            get { return base.GetSubject() as MvCreateLine; }
            set { base.SetSubject(value); }
        }

        BindingSource source;
        void InitBinding()
        {
            source = new BindingSource(typeof(MvCreateLine), null);

            cb_mode.DisplayMember = "Key"; cb_mode.ValueMember = "Value";
            cb_mode.DataSource = Enum.GetValues(typeof(MvCreateLine.E_mode)).Cast<MvCreateLine.E_mode>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_mode.DataBindings.Add("SelectedValue", source, "Mode", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Line_Angle.DataBindings.Add("Value", source, "Angle", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("Line", source, "Line", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("ThreePoint", source, "ThreePoint", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_lineMode.DataSource = Enum.GetValues(typeof(ELineMode));
            cb_lineMode.DataBindings.Add("SelectedValue", this, "lineMode", true, DataSourceUpdateMode.OnPropertyChanged);

            //DataBindings.Add("FindLineResult", source, "ResultList", true, DataSourceUpdateMode.Never);
        }
        private void nud_FindCircle_caliperLine_ValueChanged(object sender, EventArgs e)
        {
            if (lockEvent == false)
            {
                NotifyPropertyChanged("Line");
                svDisplayViewEdit.Refresh(); //Refresh draw image
            }
        }

        private void nud_CreateLine_3pX_ValueChanged(object sender, EventArgs e)
        {
            if (lockEvent2 == false)
            {
                NotifyPropertyChanged("ThreePoint");
                svDisplayViewEdit.Refresh(); //Refresh draw image
            }
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                {
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.Line);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.ThreePoint);
                }
            }
        }
        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject) //update new Circle
        {
            if (drawObject is MvLine)
            {
                MvLine _line = drawObject as MvLine;
                Line = _line;
            }
            if (drawObject is MvPoint)
            {
                MvPoint _threePoint = drawObject as MvPoint;
                ThreePoint = _threePoint;
            }
            //NotifyPropertyChanged("Line");
        }
        public enum ELineMode { TwoPoint, AngleLength }
        private ELineMode lineMode = ELineMode.TwoPoint;

        public ELineMode LineMode
        {
            get
            {
                if (lineMode == ELineMode.TwoPoint)
                {
                    nud_Line_Angle.Enabled = false;
                    nud_Line_Length.Enabled = false;
                    nud_Line_EpX.Enabled = true;
                    nud_Line_EpY.Enabled = true;
                }
                else
                {
                    nud_Line_Angle.Enabled = true;
                    nud_Line_Length.Enabled = true;
                    nud_Line_EpX.Enabled = false;
                    nud_Line_EpY.Enabled = false;
                }
                return lineMode;
            }
            set
            {
                lineMode = value;
                if (value == ELineMode.TwoPoint)
                {
                    nud_Line_Angle.Enabled = false;
                    nud_Line_Length.Enabled = false;
                    nud_Line_EpX.Enabled = true;
                    nud_Line_EpY.Enabled = true;
                }
                else
                {
                    nud_Line_Angle.Enabled = true;
                    nud_Line_Length.Enabled = true;
                    nud_Line_EpX.Enabled = false;
                    nud_Line_EpY.Enabled = false;

                }
            }
        }


        private void cb_lineMode_SelectedValueChanged(object sender, EventArgs e)
        {

        }
        private float GetAngleDeg(Point2d start, Point2d end)
        {

            double dx = end.X - start.X;
            double dy = end.Y - start.Y;

            if (dx == 0 && dy == 0)
                return 0; // 2 điểm trùng nhau

            double angleRad = Math.Atan2(dy, dx);
            double angleDeg = angleRad * 180.0 / Math.PI;

            if (angleDeg < 0)
                angleDeg += 360;
            return (float)angleDeg;
        }

        private Point2d CreateEndPoint(Point2d StartPoint, double angle, double length)
        {
            double rad = angle * Math.PI / 180.0;
            return new Point2d(StartPoint.X + length * Math.Cos(rad), StartPoint.Y + length * Math.Sin(rad));
        }

        bool lockEvent = false;
        private MvLine line;
        public MvLine Line
        {
            get
            {
                line.SP = new Point2d((double)nud_Line_SpX.Value, (double)nud_Line_SpY.Value);
                line.R = (float)nud_Line_Angle.Value;
                if (LineMode == ELineMode.AngleLength)
                {
                    line.EP = CreateEndPoint(line.SP, line.R,(double)nud_Line_Length.Value);
                }
                else
                {
                    line.EP = new Point2d((double)nud_Line_EpX.Value, (double)nud_Line_EpY.Value);
                    line.R = GetAngleDeg(line.SP, line.EP);
                }
                Line = line;
                return line;
            }
            set
            {

                lockEvent = true;
                line = value;
                nud_Line_SpX.Value = (decimal)value.SP.X;
                nud_Line_SpY.Value = (decimal)value.SP.Y;
                nud_Line_EpX.Value = (decimal)value.EP.X;
                nud_Line_EpY.Value = (decimal)value.EP.Y;
                nud_Line_Angle.Value = (decimal)GetAngleDeg(value.SP, value.EP);
                nud_Line_Length.Value = (decimal)value.GetLineLength();
                lockEvent = false;

            }
        }

        private MvPoint threePoint;

        bool lockEvent2 = false;
        public MvPoint ThreePoint
        {
            get
            {
                threePoint.X = (float)nud_PoinA_X.Value;
                threePoint.Y = (float)nud_PoinA_Y.Value;
                return threePoint;
            }
            set
            {
                lockEvent2 = true;
                threePoint = value;
                nud_PoinA_X.Value = (decimal)value.X;
                nud_PoinA_Y.Value = (decimal)value.Y;
                lockEvent2 = false;
            }
        }




    }
}
