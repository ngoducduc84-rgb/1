﻿namespace MvCore.Edit
{
    partial class MvCreatePointEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_Setting = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nud_PoinA_Y = new System.Windows.Forms.NumericUpDown();
            this.nud_PoinA_X = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabControl.SuspendLayout();
            this.tp_Setting.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PoinA_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PoinA_X)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Setting);
            // 
            // tp_Setting
            // 
            this.tp_Setting.Controls.Add(this.groupBox3);
            this.tp_Setting.Location = new System.Drawing.Point(4, 22);
            this.tp_Setting.Name = "tp_Setting";
            this.tp_Setting.Size = new System.Drawing.Size(442, 426);
            this.tp_Setting.TabIndex = 0;
            this.tp_Setting.Text = "Setting";
            this.tp_Setting.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.nud_PoinA_Y);
            this.groupBox3.Controls.Add(this.nud_PoinA_X);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(117, 89);
            this.groupBox3.TabIndex = 29;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Point A";
            // 
            // nud_PoinA_Y
            // 
            this.nud_PoinA_Y.DecimalPlaces = 3;
            this.nud_PoinA_Y.Location = new System.Drawing.Point(39, 47);
            this.nud_PoinA_Y.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_PoinA_Y.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_PoinA_Y.Name = "nud_PoinA_Y";
            this.nud_PoinA_Y.Size = new System.Drawing.Size(69, 20);
            this.nud_PoinA_Y.TabIndex = 24;
            this.nud_PoinA_Y.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_PoinA_Y.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_PoinA_X
            // 
            this.nud_PoinA_X.DecimalPlaces = 3;
            this.nud_PoinA_X.Location = new System.Drawing.Point(39, 18);
            this.nud_PoinA_X.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_PoinA_X.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_PoinA_X.Name = "nud_PoinA_X";
            this.nud_PoinA_X.Size = new System.Drawing.Size(69, 20);
            this.nud_PoinA_X.TabIndex = 22;
            this.nud_PoinA_X.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_PoinA_X.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Y: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "X: ";
            // 
            // MvCreatePointEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "MvCreatePointEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Setting.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PoinA_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PoinA_X)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Setting;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown nud_PoinA_Y;
        private System.Windows.Forms.NumericUpDown nud_PoinA_X;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}
