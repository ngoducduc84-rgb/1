﻿using MvCore.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace MvCore.Edit
{
    public partial class MvCreatePointEdit : MvToolEditBase
    {
        public MvCreatePointEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvFindLineEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }
        void SvFindLineEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
        public MvCreatePoint Subject
        {
            get { return base.GetSubject() as MvCreatePoint; }
            set { base.SetSubject(value); }
        }

        BindingSource source;
        void InitBinding()
        {
            source = new BindingSource(typeof(MvCreatePoint), null);
            DataBindings.Add("PointA", source, "PointA", true, DataSourceUpdateMode.OnPropertyChanged);
            //DataBindings.Add("FindLineResult", source, "ResultList", true, DataSourceUpdateMode.Never);
        }
       
        private void nud_ValueChanged(object sender, EventArgs e)
        {
            if (lockPoint == false)
            {
                NotifyPropertyChanged("PointA");
                svDisplayViewEdit.Refresh(); //Refresh draw image
            }
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                {
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.PointA);
                }
            }
        }
        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject) //update new Circle
        {
            if (drawObject is MvPoint)
            {
                MvPoint _Point = drawObject as MvPoint;
                PointA = _Point;
            }
            //NotifyPropertyChanged("Line");
        }
       


        bool lockPoint = false;
        private MvPoint pointA;
        public MvPoint PointA
        {
            get
            {
                pointA.X = (float)nud_PoinA_X.Value;
                pointA.Y = (float)nud_PoinA_Y.Value;
                return pointA;
            }
            set
            {

                lockPoint = true;
                pointA = value;
                nud_PoinA_X.Value = (decimal)value.X;
                nud_PoinA_Y.Value = (decimal)value.Y;
                lockPoint = false;

            }
        }
    }
}
