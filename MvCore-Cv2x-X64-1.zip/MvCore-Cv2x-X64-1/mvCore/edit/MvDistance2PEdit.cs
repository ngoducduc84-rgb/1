﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;

namespace MvCore.Edit
{
    public partial class MvDistance2PEdit : MvToolEditBase
    {
        public MvDistance2PEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvCaliperEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvDistance2P Subject
        {
            get { return base.GetSubject() as MvDistance2P; }
            set { base.SetSubject(value); }
        }

        void SvCaliperEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                {
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.PointA);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.PointB);
                }
            }
        }

        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject)
        {
            if (drawObject is MvPoint)
                DataBindings["PointA"].ReadValue();
            if (drawObject is MvPoint)
                DataBindings["PointB"].ReadValue();
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvDistance2P), null);
            DataBindings.Add("PointA", source, "PointA", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("PointB", source, "PointB", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("DistanceResult", source, "DistanceResult", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        public double DistanceResult
        {
            get { throw new Exception("쓰면 안됨"); }
            set { nud_Distance_Result.Value = (decimal)value; }
        }

        public MvPoint PointA
        {
            get
            {
                PointA.Point2d = new Point2d((double)nud_Distance_SPX.Value, (double)nud_Distance_SPY.Value);
                return PointA;
            }
            set
            {
                nud_Distance_SPX.Value = (decimal)value.X;
                nud_Distance_SPY.Value = (decimal)value.Y;
            }
        }

        public MvPoint PointB
        {
            get
            {
                PointB.Point2d = new Point2d((double)nud_Distance_EPX.Value, (double)nud_Distance_EPY.Value);
                return PointB;
            }
            set
            {
                nud_Distance_EPX.Value = (decimal)value.X;
                nud_Distance_EPY.Value = (decimal)value.Y;
            }
        }
    }
}
