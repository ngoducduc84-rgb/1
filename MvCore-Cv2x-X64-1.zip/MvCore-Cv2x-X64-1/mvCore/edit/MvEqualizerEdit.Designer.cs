﻿namespace MvCore.Edit
{
    partial class MvEqualizerEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_Region = new System.Windows.Forms.TabPage();
            this.tabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Region);
            // 
            // tp_Region
            // 
            this.tp_Region.Location = new System.Drawing.Point(4, 22);
            this.tp_Region.Name = "tp_Region";
            this.tp_Region.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Region.Size = new System.Drawing.Size(442, 426);
            this.tp_Region.TabIndex = 0;
            this.tp_Region.Text = "Region";
            this.tp_Region.UseVisualStyleBackColor = true;
            // 
            // SvEqualizerEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "SvEqualizerEdit";
            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Region;
    }
}
