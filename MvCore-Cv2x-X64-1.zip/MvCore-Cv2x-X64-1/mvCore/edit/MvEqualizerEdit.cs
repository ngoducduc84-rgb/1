﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;
using OpenCvSharp;

namespace MvCore.Edit
{
    public partial class MvEqualizerEdit : MvToolEditBase
    {
        public MvEqualizerEdit()
        {          
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvEqualizerEdit_SubjectChanged;
        }
        
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]

        public MvEqualizer Subject
        {
            get { return base.GetSubject() as MvEqualizer; }
            set { base.SetSubject(value); }
        }

        void SvEqualizerEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvEqualizer), null);
        }               
    }
}
