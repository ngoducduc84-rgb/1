﻿namespace MvCore.Edit
{
    partial class MvFindCircleEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_Setting = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_count = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Score = new System.Windows.Forms.TextBox();
            this.btn_SwapPoint = new System.Windows.Forms.Button();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nud_FindCircle_UseNumberOfCalipers = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_FindCircle_IgnoreType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.nud_FindCircle_NumberOfIgnore = new System.Windows.Forms.NumericUpDown();
            this.cb_FindCircle_FittingType = new System.Windows.Forms.ComboBox();
            this.nud_FindCircle_PercentageOfIgnore = new System.Windows.Forms.NumericUpDown();
            this.label46 = new System.Windows.Forms.Label();
            this.lbl_FindCircle_PercentageOfIgnore = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.nud_FindCircle_Radius = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_FindCircle_CenterY = new System.Windows.Forms.NumericUpDown();
            this.nud_FindCircle_CenterX = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.nud_FindCircle_EA = new System.Windows.Forms.NumericUpDown();
            this.nud_FindCircle_SA = new System.Windows.Forms.NumericUpDown();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.nud_FindCircle_ContrastThreshold = new System.Windows.Forms.NumericUpDown();
            this.nud_FindCircle_FilterHalfSize = new System.Windows.Forms.NumericUpDown();
            this.gb_FindCircle_Priority = new System.Windows.Forms.GroupBox();
            this.rb_FindCircle_Pos = new System.Windows.Forms.RadioButton();
            this.rb_FindCircle_Peak = new System.Windows.Forms.RadioButton();
            this.rb_FindCircle_Last = new System.Windows.Forms.RadioButton();
            this.rb_FindCircle_First = new System.Windows.Forms.RadioButton();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.rb_FindCircle_AnyPolarity = new System.Windows.Forms.RadioButton();
            this.rb_FindCircle_DarkToLight = new System.Windows.Forms.RadioButton();
            this.rb_FindCircle_LightToDark = new System.Windows.Forms.RadioButton();
            this.label45 = new System.Windows.Forms.Label();
            this.nud_FindCircle_SearchLength = new System.Windows.Forms.NumericUpDown();
            this.label44 = new System.Windows.Forms.Label();
            this.nud_FindCircle_ProjectionLength = new System.Windows.Forms.NumericUpDown();
            this.nud_FindCircle_NumberOfCalipers = new System.Windows.Forms.NumericUpDown();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.tp_Result = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.dg_FindCircle_Result = new System.Windows.Forms.DataGridView();
            this.nud_FindCircle_Score = new System.Windows.Forms.NumericUpDown();
            this.lbl_FindCircle_Score = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tp_Setting.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_UseNumberOfCalipers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_NumberOfIgnore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_PercentageOfIgnore)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_Radius)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_CenterY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_CenterX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_EA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_SA)).BeginInit();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_ContrastThreshold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_FilterHalfSize)).BeginInit();
            this.gb_FindCircle_Priority.SuspendLayout();
            this.groupBox17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_SearchLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_ProjectionLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_NumberOfCalipers)).BeginInit();
            this.tp_Result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_FindCircle_Result)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_Score)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Setting);
            this.tabControl.Controls.Add(this.tp_Result);
            // 
            // tp_Setting
            // 
            this.tp_Setting.Controls.Add(this.label6);
            this.tp_Setting.Controls.Add(this.txt_count);
            this.tp_Setting.Controls.Add(this.label5);
            this.tp_Setting.Controls.Add(this.txt_Score);
            this.tp_Setting.Controls.Add(this.btn_SwapPoint);
            this.tp_Setting.Controls.Add(this.groupBox20);
            this.tp_Setting.Controls.Add(this.groupBox9);
            this.tp_Setting.Controls.Add(this.groupBox16);
            this.tp_Setting.Location = new System.Drawing.Point(4, 22);
            this.tp_Setting.Name = "tp_Setting";
            this.tp_Setting.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Setting.Size = new System.Drawing.Size(442, 426);
            this.tp_Setting.TabIndex = 0;
            this.tp_Setting.Text = "Setting";
            this.tp_Setting.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(284, 280);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "> Set Count: ";
            // 
            // txt_count
            // 
            this.txt_count.Location = new System.Drawing.Point(357, 277);
            this.txt_count.Name = "txt_count";
            this.txt_count.Size = new System.Drawing.Size(72, 20);
            this.txt_count.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(284, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "< Set Score: ";
            // 
            // txt_Score
            // 
            this.txt_Score.Location = new System.Drawing.Point(357, 251);
            this.txt_Score.Name = "txt_Score";
            this.txt_Score.Size = new System.Drawing.Size(72, 20);
            this.txt_Score.TabIndex = 24;
            // 
            // btn_SwapPoint
            // 
            this.btn_SwapPoint.Location = new System.Drawing.Point(291, 214);
            this.btn_SwapPoint.Name = "btn_SwapPoint";
            this.btn_SwapPoint.Size = new System.Drawing.Size(138, 34);
            this.btn_SwapPoint.TabIndex = 23;
            this.btn_SwapPoint.Text = "Swap";
            this.btn_SwapPoint.UseVisualStyleBackColor = true;
            this.btn_SwapPoint.Click += new System.EventHandler(this.btn_SwapPoint_Click);
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.label4);
            this.groupBox20.Controls.Add(this.nud_FindCircle_UseNumberOfCalipers);
            this.groupBox20.Controls.Add(this.label3);
            this.groupBox20.Controls.Add(this.cb_FindCircle_IgnoreType);
            this.groupBox20.Controls.Add(this.label2);
            this.groupBox20.Controls.Add(this.nud_FindCircle_NumberOfIgnore);
            this.groupBox20.Controls.Add(this.cb_FindCircle_FittingType);
            this.groupBox20.Controls.Add(this.nud_FindCircle_PercentageOfIgnore);
            this.groupBox20.Controls.Add(this.label46);
            this.groupBox20.Controls.Add(this.lbl_FindCircle_PercentageOfIgnore);
            this.groupBox20.Location = new System.Drawing.Point(10, 318);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(419, 95);
            this.groupBox20.TabIndex = 22;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Line Fitting";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(122, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "Number Of Using Calipers (w/ Masking) :";
            // 
            // nud_FindCircle_UseNumberOfCalipers
            // 
            this.nud_FindCircle_UseNumberOfCalipers.InterceptArrowKeys = false;
            this.nud_FindCircle_UseNumberOfCalipers.Location = new System.Drawing.Point(365, 68);
            this.nud_FindCircle_UseNumberOfCalipers.Name = "nud_FindCircle_UseNumberOfCalipers";
            this.nud_FindCircle_UseNumberOfCalipers.ReadOnly = true;
            this.nud_FindCircle_UseNumberOfCalipers.Size = new System.Drawing.Size(46, 20);
            this.nud_FindCircle_UseNumberOfCalipers.TabIndex = 29;
            this.nud_FindCircle_UseNumberOfCalipers.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_FindCircle_UseNumberOfCalipers.ValueChanged += new System.EventHandler(this.nud_FindLine_UseNumberOfCalipers_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(248, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "Number Of Ignore : ";
            // 
            // cb_FindCircle_IgnoreType
            // 
            this.cb_FindCircle_IgnoreType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_FindCircle_IgnoreType.FormattingEnabled = true;
            this.cb_FindCircle_IgnoreType.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cb_FindCircle_IgnoreType.Location = new System.Drawing.Point(108, 42);
            this.cb_FindCircle_IgnoreType.Name = "cb_FindCircle_IgnoreType";
            this.cb_FindCircle_IgnoreType.Size = new System.Drawing.Size(88, 21);
            this.cb_FindCircle_IgnoreType.TabIndex = 27;
            this.cb_FindCircle_IgnoreType.SelectedIndexChanged += new System.EventHandler(this.cb_FindLIne_IgnoreType_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 26;
            this.label2.Text = "Ignore Type : ";
            // 
            // nud_FindCircle_NumberOfIgnore
            // 
            this.nud_FindCircle_NumberOfIgnore.Location = new System.Drawing.Point(365, 16);
            this.nud_FindCircle_NumberOfIgnore.Name = "nud_FindCircle_NumberOfIgnore";
            this.nud_FindCircle_NumberOfIgnore.Size = new System.Drawing.Size(46, 20);
            this.nud_FindCircle_NumberOfIgnore.TabIndex = 25;
            this.nud_FindCircle_NumberOfIgnore.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_FindCircle_NumberOfIgnore.ValueChanged += new System.EventHandler(this.nud_FindLine_NumberOfIgnore_ValueChanged);
            // 
            // cb_FindCircle_FittingType
            // 
            this.cb_FindCircle_FittingType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_FindCircle_FittingType.FormattingEnabled = true;
            this.cb_FindCircle_FittingType.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cb_FindCircle_FittingType.Location = new System.Drawing.Point(108, 16);
            this.cb_FindCircle_FittingType.Name = "cb_FindCircle_FittingType";
            this.cb_FindCircle_FittingType.Size = new System.Drawing.Size(88, 21);
            this.cb_FindCircle_FittingType.TabIndex = 17;
            // 
            // nud_FindCircle_PercentageOfIgnore
            // 
            this.nud_FindCircle_PercentageOfIgnore.Location = new System.Drawing.Point(365, 42);
            this.nud_FindCircle_PercentageOfIgnore.Name = "nud_FindCircle_PercentageOfIgnore";
            this.nud_FindCircle_PercentageOfIgnore.Size = new System.Drawing.Size(46, 20);
            this.nud_FindCircle_PercentageOfIgnore.TabIndex = 24;
            this.nud_FindCircle_PercentageOfIgnore.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_FindCircle_PercentageOfIgnore.ValueChanged += new System.EventHandler(this.nud_FindLine_PercentageOfIgnore_ValueChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(19, 20);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(71, 13);
            this.label46.TabIndex = 16;
            this.label46.Text = "Fitting Type : ";
            // 
            // lbl_FindCircle_PercentageOfIgnore
            // 
            this.lbl_FindCircle_PercentageOfIgnore.AutoSize = true;
            this.lbl_FindCircle_PercentageOfIgnore.Location = new System.Drawing.Point(205, 46);
            this.lbl_FindCircle_PercentageOfIgnore.Name = "lbl_FindCircle_PercentageOfIgnore";
            this.lbl_FindCircle_PercentageOfIgnore.Size = new System.Drawing.Size(135, 13);
            this.lbl_FindCircle_PercentageOfIgnore.TabIndex = 13;
            this.lbl_FindCircle_PercentageOfIgnore.Text = "Percentage Of Ignore (%) : ";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.groupBox1);
            this.groupBox9.Controls.Add(this.nud_FindCircle_EA);
            this.groupBox9.Controls.Add(this.nud_FindCircle_SA);
            this.groupBox9.Controls.Add(this.label49);
            this.groupBox9.Controls.Add(this.label50);
            this.groupBox9.Location = new System.Drawing.Point(291, 11);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(138, 203);
            this.groupBox9.TabIndex = 20;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Caliper Location";
            // 
            // nud_FindCircle_Radius
            // 
            this.nud_FindCircle_Radius.DecimalPlaces = 3;
            this.nud_FindCircle_Radius.Location = new System.Drawing.Point(62, 60);
            this.nud_FindCircle_Radius.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_FindCircle_Radius.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_Radius.Name = "nud_FindCircle_Radius";
            this.nud_FindCircle_Radius.Size = new System.Drawing.Size(69, 20);
            this.nud_FindCircle_Radius.TabIndex = 29;
            this.nud_FindCircle_Radius.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_FindCircle_Radius.ValueChanged += new System.EventHandler(this.nud_FindCircle_CaliperCircle_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(31, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(21, 13);
            this.label11.TabIndex = 28;
            this.label11.Text = "R: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_FindCircle_Radius);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.nud_FindCircle_CenterY);
            this.groupBox1.Controls.Add(this.nud_FindCircle_CenterX);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(4, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(134, 88);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Center";
            // 
            // nud_FindCircle_CenterY
            // 
            this.nud_FindCircle_CenterY.DecimalPlaces = 3;
            this.nud_FindCircle_CenterY.Location = new System.Drawing.Point(63, 34);
            this.nud_FindCircle_CenterY.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_FindCircle_CenterY.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_CenterY.Name = "nud_FindCircle_CenterY";
            this.nud_FindCircle_CenterY.Size = new System.Drawing.Size(69, 20);
            this.nud_FindCircle_CenterY.TabIndex = 24;
            this.nud_FindCircle_CenterY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_FindCircle_CenterY.ValueChanged += new System.EventHandler(this.nud_FindCircle_CaliperCircle_ValueChanged);
            // 
            // nud_FindCircle_CenterX
            // 
            this.nud_FindCircle_CenterX.DecimalPlaces = 3;
            this.nud_FindCircle_CenterX.Location = new System.Drawing.Point(63, 8);
            this.nud_FindCircle_CenterX.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_FindCircle_CenterX.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_CenterX.Name = "nud_FindCircle_CenterX";
            this.nud_FindCircle_CenterX.Size = new System.Drawing.Size(69, 20);
            this.nud_FindCircle_CenterX.TabIndex = 22;
            this.nud_FindCircle_CenterX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_FindCircle_CenterX.ValueChanged += new System.EventHandler(this.nud_FindCircle_CaliperCircle_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Y: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "X: ";
            // 
            // nud_FindCircle_EA
            // 
            this.nud_FindCircle_EA.DecimalPlaces = 3;
            this.nud_FindCircle_EA.Location = new System.Drawing.Point(66, 50);
            this.nud_FindCircle_EA.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_FindCircle_EA.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_EA.Name = "nud_FindCircle_EA";
            this.nud_FindCircle_EA.Size = new System.Drawing.Size(69, 20);
            this.nud_FindCircle_EA.TabIndex = 18;
            this.nud_FindCircle_EA.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_FindCircle_EA.ValueChanged += new System.EventHandler(this.nud_FindCircle_CaliperCircle_ValueChanged);
            // 
            // nud_FindCircle_SA
            // 
            this.nud_FindCircle_SA.DecimalPlaces = 3;
            this.nud_FindCircle_SA.Location = new System.Drawing.Point(66, 25);
            this.nud_FindCircle_SA.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_FindCircle_SA.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_SA.Name = "nud_FindCircle_SA";
            this.nud_FindCircle_SA.Size = new System.Drawing.Size(69, 20);
            this.nud_FindCircle_SA.TabIndex = 18;
            this.nud_FindCircle_SA.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_FindCircle_SA.ValueChanged += new System.EventHandler(this.nud_FindCircle_CaliperCircle_ValueChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(3, 28);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(59, 13);
            this.label49.TabIndex = 17;
            this.label49.Text = "Start Angle";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(2, 52);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(56, 13);
            this.label50.TabIndex = 17;
            this.label50.Text = "End Angle";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.nud_FindCircle_ContrastThreshold);
            this.groupBox16.Controls.Add(this.nud_FindCircle_FilterHalfSize);
            this.groupBox16.Controls.Add(this.gb_FindCircle_Priority);
            this.groupBox16.Controls.Add(this.groupBox17);
            this.groupBox16.Controls.Add(this.label45);
            this.groupBox16.Controls.Add(this.nud_FindCircle_SearchLength);
            this.groupBox16.Controls.Add(this.label44);
            this.groupBox16.Controls.Add(this.nud_FindCircle_ProjectionLength);
            this.groupBox16.Controls.Add(this.nud_FindCircle_NumberOfCalipers);
            this.groupBox16.Controls.Add(this.label40);
            this.groupBox16.Controls.Add(this.label41);
            this.groupBox16.Controls.Add(this.label42);
            this.groupBox16.Location = new System.Drawing.Point(10, 10);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(271, 299);
            this.groupBox16.TabIndex = 19;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Caliper";
            // 
            // nud_FindCircle_ContrastThreshold
            // 
            this.nud_FindCircle_ContrastThreshold.DecimalPlaces = 3;
            this.nud_FindCircle_ContrastThreshold.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_FindCircle_ContrastThreshold.Location = new System.Drawing.Point(206, 265);
            this.nud_FindCircle_ContrastThreshold.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.nud_FindCircle_ContrastThreshold.Name = "nud_FindCircle_ContrastThreshold";
            this.nud_FindCircle_ContrastThreshold.Size = new System.Drawing.Size(52, 20);
            this.nud_FindCircle_ContrastThreshold.TabIndex = 15;
            this.nud_FindCircle_ContrastThreshold.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // nud_FindCircle_FilterHalfSize
            // 
            this.nud_FindCircle_FilterHalfSize.Location = new System.Drawing.Point(206, 242);
            this.nud_FindCircle_FilterHalfSize.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.nud_FindCircle_FilterHalfSize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_FindCircle_FilterHalfSize.Name = "nud_FindCircle_FilterHalfSize";
            this.nud_FindCircle_FilterHalfSize.Size = new System.Drawing.Size(52, 20);
            this.nud_FindCircle_FilterHalfSize.TabIndex = 15;
            this.nud_FindCircle_FilterHalfSize.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // gb_FindCircle_Priority
            // 
            this.gb_FindCircle_Priority.Controls.Add(this.rb_FindCircle_Pos);
            this.gb_FindCircle_Priority.Controls.Add(this.rb_FindCircle_Peak);
            this.gb_FindCircle_Priority.Controls.Add(this.rb_FindCircle_Last);
            this.gb_FindCircle_Priority.Controls.Add(this.rb_FindCircle_First);
            this.gb_FindCircle_Priority.Location = new System.Drawing.Point(15, 183);
            this.gb_FindCircle_Priority.Name = "gb_FindCircle_Priority";
            this.gb_FindCircle_Priority.Size = new System.Drawing.Size(243, 45);
            this.gb_FindCircle_Priority.TabIndex = 16;
            this.gb_FindCircle_Priority.TabStop = false;
            this.gb_FindCircle_Priority.Text = "Priority";
            // 
            // rb_FindCircle_Pos
            // 
            this.rb_FindCircle_Pos.AutoSize = true;
            this.rb_FindCircle_Pos.Location = new System.Drawing.Point(187, 20);
            this.rb_FindCircle_Pos.Name = "rb_FindCircle_Pos";
            this.rb_FindCircle_Pos.Size = new System.Drawing.Size(43, 17);
            this.rb_FindCircle_Pos.TabIndex = 3;
            this.rb_FindCircle_Pos.Text = "Pos";
            this.rb_FindCircle_Pos.UseVisualStyleBackColor = true;
            this.rb_FindCircle_Pos.CheckedChanged += new System.EventHandler(this.rb_FindLine_Priority_CheckedChanged);
            // 
            // rb_FindCircle_Peak
            // 
            this.rb_FindCircle_Peak.AutoSize = true;
            this.rb_FindCircle_Peak.Location = new System.Drawing.Point(18, 20);
            this.rb_FindCircle_Peak.Name = "rb_FindCircle_Peak";
            this.rb_FindCircle_Peak.Size = new System.Drawing.Size(50, 17);
            this.rb_FindCircle_Peak.TabIndex = 2;
            this.rb_FindCircle_Peak.Text = "Peak";
            this.rb_FindCircle_Peak.UseVisualStyleBackColor = true;
            this.rb_FindCircle_Peak.CheckedChanged += new System.EventHandler(this.rb_FindLine_Priority_CheckedChanged);
            // 
            // rb_FindCircle_Last
            // 
            this.rb_FindCircle_Last.AutoSize = true;
            this.rb_FindCircle_Last.Location = new System.Drawing.Point(132, 20);
            this.rb_FindCircle_Last.Name = "rb_FindCircle_Last";
            this.rb_FindCircle_Last.Size = new System.Drawing.Size(45, 17);
            this.rb_FindCircle_Last.TabIndex = 2;
            this.rb_FindCircle_Last.Text = "Last";
            this.rb_FindCircle_Last.UseVisualStyleBackColor = true;
            this.rb_FindCircle_Last.CheckedChanged += new System.EventHandler(this.rb_FindLine_Priority_CheckedChanged);
            // 
            // rb_FindCircle_First
            // 
            this.rb_FindCircle_First.AutoSize = true;
            this.rb_FindCircle_First.Location = new System.Drawing.Point(77, 20);
            this.rb_FindCircle_First.Name = "rb_FindCircle_First";
            this.rb_FindCircle_First.Size = new System.Drawing.Size(44, 17);
            this.rb_FindCircle_First.TabIndex = 2;
            this.rb_FindCircle_First.Text = "First";
            this.rb_FindCircle_First.UseVisualStyleBackColor = true;
            this.rb_FindCircle_First.CheckedChanged += new System.EventHandler(this.rb_FindLine_Priority_CheckedChanged);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.rb_FindCircle_AnyPolarity);
            this.groupBox17.Controls.Add(this.rb_FindCircle_DarkToLight);
            this.groupBox17.Controls.Add(this.rb_FindCircle_LightToDark);
            this.groupBox17.Location = new System.Drawing.Point(15, 104);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(243, 71);
            this.groupBox17.TabIndex = 16;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Polarity";
            // 
            // rb_FindCircle_AnyPolarity
            // 
            this.rb_FindCircle_AnyPolarity.AutoSize = true;
            this.rb_FindCircle_AnyPolarity.Location = new System.Drawing.Point(132, 30);
            this.rb_FindCircle_AnyPolarity.Name = "rb_FindCircle_AnyPolarity";
            this.rb_FindCircle_AnyPolarity.Size = new System.Drawing.Size(80, 17);
            this.rb_FindCircle_AnyPolarity.TabIndex = 2;
            this.rb_FindCircle_AnyPolarity.Text = "Any Polarity";
            this.rb_FindCircle_AnyPolarity.UseVisualStyleBackColor = true;
            this.rb_FindCircle_AnyPolarity.CheckedChanged += new System.EventHandler(this.rb_FindLine_Polarity_CheckedChanged);
            // 
            // rb_FindCircle_DarkToLight
            // 
            this.rb_FindCircle_DarkToLight.AutoSize = true;
            this.rb_FindCircle_DarkToLight.Location = new System.Drawing.Point(18, 44);
            this.rb_FindCircle_DarkToLight.Name = "rb_FindCircle_DarkToLight";
            this.rb_FindCircle_DarkToLight.Size = new System.Drawing.Size(86, 17);
            this.rb_FindCircle_DarkToLight.TabIndex = 2;
            this.rb_FindCircle_DarkToLight.Text = "Dark to Light";
            this.rb_FindCircle_DarkToLight.UseVisualStyleBackColor = true;
            this.rb_FindCircle_DarkToLight.CheckedChanged += new System.EventHandler(this.rb_FindLine_Polarity_CheckedChanged);
            // 
            // rb_FindCircle_LightToDark
            // 
            this.rb_FindCircle_LightToDark.AutoSize = true;
            this.rb_FindCircle_LightToDark.Location = new System.Drawing.Point(18, 20);
            this.rb_FindCircle_LightToDark.Name = "rb_FindCircle_LightToDark";
            this.rb_FindCircle_LightToDark.Size = new System.Drawing.Size(86, 17);
            this.rb_FindCircle_LightToDark.TabIndex = 2;
            this.rb_FindCircle_LightToDark.Text = "Light to Dark";
            this.rb_FindCircle_LightToDark.UseVisualStyleBackColor = true;
            this.rb_FindCircle_LightToDark.CheckedChanged += new System.EventHandler(this.rb_FindLine_Polarity_CheckedChanged);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(58, 244);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(113, 13);
            this.label45.TabIndex = 13;
            this.label45.Text = "Filter Half Size Pixels : ";
            // 
            // nud_FindCircle_SearchLength
            // 
            this.nud_FindCircle_SearchLength.DecimalPlaces = 3;
            this.nud_FindCircle_SearchLength.Location = new System.Drawing.Point(174, 51);
            this.nud_FindCircle_SearchLength.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_FindCircle_SearchLength.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_FindCircle_SearchLength.Name = "nud_FindCircle_SearchLength";
            this.nud_FindCircle_SearchLength.Size = new System.Drawing.Size(84, 20);
            this.nud_FindCircle_SearchLength.TabIndex = 16;
            this.nud_FindCircle_SearchLength.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(45, 267);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(125, 13);
            this.label44.TabIndex = 12;
            this.label44.Text = "Min Contrast Threshold : ";
            // 
            // nud_FindCircle_ProjectionLength
            // 
            this.nud_FindCircle_ProjectionLength.DecimalPlaces = 3;
            this.nud_FindCircle_ProjectionLength.Location = new System.Drawing.Point(174, 77);
            this.nud_FindCircle_ProjectionLength.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_FindCircle_ProjectionLength.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_FindCircle_ProjectionLength.Name = "nud_FindCircle_ProjectionLength";
            this.nud_FindCircle_ProjectionLength.Size = new System.Drawing.Size(84, 20);
            this.nud_FindCircle_ProjectionLength.TabIndex = 17;
            this.nud_FindCircle_ProjectionLength.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_FindCircle_NumberOfCalipers
            // 
            this.nud_FindCircle_NumberOfCalipers.Location = new System.Drawing.Point(206, 26);
            this.nud_FindCircle_NumberOfCalipers.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.nud_FindCircle_NumberOfCalipers.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_FindCircle_NumberOfCalipers.Name = "nud_FindCircle_NumberOfCalipers";
            this.nud_FindCircle_NumberOfCalipers.Size = new System.Drawing.Size(52, 20);
            this.nud_FindCircle_NumberOfCalipers.TabIndex = 15;
            this.nud_FindCircle_NumberOfCalipers.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(36, 79);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(99, 13);
            this.label40.TabIndex = 11;
            this.label40.Text = "Projection Length : ";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(51, 53);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(86, 13);
            this.label41.TabIndex = 12;
            this.label41.Text = "Search Length : ";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(24, 28);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(105, 13);
            this.label42.TabIndex = 13;
            this.label42.Text = "Number of Calipers : ";
            // 
            // tp_Result
            // 
            this.tp_Result.Controls.Add(this.label1);
            this.tp_Result.Controls.Add(this.dg_FindCircle_Result);
            this.tp_Result.Controls.Add(this.nud_FindCircle_Score);
            this.tp_Result.Controls.Add(this.lbl_FindCircle_Score);
            this.tp_Result.Location = new System.Drawing.Point(4, 22);
            this.tp_Result.Name = "tp_Result";
            this.tp_Result.Size = new System.Drawing.Size(442, 426);
            this.tp_Result.TabIndex = 1;
            this.tp_Result.Text = "Result";
            this.tp_Result.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(203, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 13);
            this.label1.TabIndex = 24;
            this.label1.Text = "To multi-select, After select rows and \'space\' key";
            // 
            // dg_FindCircle_Result
            // 
            this.dg_FindCircle_Result.AllowUserToAddRows = false;
            this.dg_FindCircle_Result.AllowUserToDeleteRows = false;
            this.dg_FindCircle_Result.AllowUserToResizeColumns = false;
            this.dg_FindCircle_Result.AllowUserToResizeRows = false;
            this.dg_FindCircle_Result.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_FindCircle_Result.Location = new System.Drawing.Point(13, 41);
            this.dg_FindCircle_Result.Name = "dg_FindCircle_Result";
            this.dg_FindCircle_Result.RowHeadersVisible = false;
            this.dg_FindCircle_Result.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dg_FindCircle_Result.RowTemplate.Height = 23;
            this.dg_FindCircle_Result.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg_FindCircle_Result.Size = new System.Drawing.Size(416, 373);
            this.dg_FindCircle_Result.TabIndex = 23;
            // 
            // nud_FindCircle_Score
            // 
            this.nud_FindCircle_Score.DecimalPlaces = 2;
            this.nud_FindCircle_Score.Increment = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nud_FindCircle_Score.Location = new System.Drawing.Point(98, 14);
            this.nud_FindCircle_Score.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nud_FindCircle_Score.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.nud_FindCircle_Score.Name = "nud_FindCircle_Score";
            this.nud_FindCircle_Score.ReadOnly = true;
            this.nud_FindCircle_Score.Size = new System.Drawing.Size(65, 20);
            this.nud_FindCircle_Score.TabIndex = 22;
            this.nud_FindCircle_Score.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // lbl_FindCircle_Score
            // 
            this.lbl_FindCircle_Score.AutoSize = true;
            this.lbl_FindCircle_Score.Location = new System.Drawing.Point(10, 16);
            this.lbl_FindCircle_Score.Name = "lbl_FindCircle_Score";
            this.lbl_FindCircle_Score.Size = new System.Drawing.Size(81, 13);
            this.lbl_FindCircle_Score.TabIndex = 21;
            this.lbl_FindCircle_Score.Text = "Current Score : ";
            // 
            // MvFindCircleEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "MvFindCircleEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Setting.ResumeLayout(false);
            this.tp_Setting.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_UseNumberOfCalipers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_NumberOfIgnore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_PercentageOfIgnore)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_Radius)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_CenterY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_CenterX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_EA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_SA)).EndInit();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_ContrastThreshold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_FilterHalfSize)).EndInit();
            this.gb_FindCircle_Priority.ResumeLayout(false);
            this.gb_FindCircle_Priority.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_SearchLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_ProjectionLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_NumberOfCalipers)).EndInit();
            this.tp_Result.ResumeLayout(false);
            this.tp_Result.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_FindCircle_Result)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FindCircle_Score)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Setting;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.ComboBox cb_FindCircle_FittingType;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label lbl_FindCircle_PercentageOfIgnore;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_EA;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_SA;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_ContrastThreshold;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_FilterHalfSize;
        private System.Windows.Forms.GroupBox gb_FindCircle_Priority;
        private System.Windows.Forms.RadioButton rb_FindCircle_Peak;
        private System.Windows.Forms.RadioButton rb_FindCircle_Last;
        private System.Windows.Forms.RadioButton rb_FindCircle_First;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.RadioButton rb_FindCircle_AnyPolarity;
        private System.Windows.Forms.RadioButton rb_FindCircle_DarkToLight;
        private System.Windows.Forms.RadioButton rb_FindCircle_LightToDark;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_SearchLength;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_ProjectionLength;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_NumberOfCalipers;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TabPage tp_Result;
        private System.Windows.Forms.DataGridView dg_FindCircle_Result;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_Score;
        private System.Windows.Forms.Label lbl_FindCircle_Score;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_PercentageOfIgnore;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_NumberOfIgnore;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_FindCircle_IgnoreType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_UseNumberOfCalipers;
		private System.Windows.Forms.Button btn_SwapPoint;
        private System.Windows.Forms.RadioButton rb_FindCircle_Pos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Score;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_count;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_CenterY;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_CenterX;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nud_FindCircle_Radius;
        private System.Windows.Forms.Label label11;
    }
}
