﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;
using System.Threading;

namespace MvCore.Edit
{
    public partial class MvFindCircleEdit : MvToolEditBase
    {
        public MvFindCircleEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvFindLineEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
            this.dg_FindCircle_Result.KeyDown += SvFindLineEdit_KeyDown;
            this.dg_FindCircle_Result.CellValueChanged += dg_FindLIne_Result_CellValueChanged;
        }


        // FindLine Result에서 masking 변경시 이벤트
        void dg_FindLIne_Result_CellValueChanged(object sender, EventArgs e)
        {
            this.nud_FindCircle_PercentageOfIgnore.ValueChanged -= nud_FindLine_PercentageOfIgnore_ValueChanged;
            this.nud_FindCircle_NumberOfIgnore.ValueChanged -= nud_FindLine_NumberOfIgnore_ValueChanged;

            Subject.Cal_IgnoreNumber();

            this.nud_FindCircle_PercentageOfIgnore.ValueChanged += nud_FindLine_PercentageOfIgnore_ValueChanged;
            this.nud_FindCircle_NumberOfIgnore.ValueChanged += nud_FindLine_NumberOfIgnore_ValueChanged;
        }

        // FindLine Result에서 SpaceKey를 이용하여 masking 변경시 이벤트
        void SvFindLineEdit_KeyDown(object sender, KeyEventArgs e)
        {
            dg_FindCircle_Result.EditMode = DataGridViewEditMode.EditProgrammatically;
            this.dg_FindCircle_Result.CellValueChanged -= dg_FindLIne_Result_CellValueChanged;

            if (e.KeyData == Keys.Space)
            {
                this.nud_FindCircle_PercentageOfIgnore.ValueChanged -= nud_FindLine_PercentageOfIgnore_ValueChanged;
                this.nud_FindCircle_NumberOfIgnore.ValueChanged -= nud_FindLine_NumberOfIgnore_ValueChanged;

                //int index = dg_FindLIne_Result.SelectedRows[0].Index;
                bool use = (bool)dg_FindCircle_Result.SelectedRows[0].Cells[0].Value;
                foreach (DataGridViewRow row in dg_FindCircle_Result.SelectedRows)
                {
                    row.Cells[0].Value = !use;
                    Subject.ResultList[row.Index].Use = !use;
                }

                Subject.Cal_IgnoreNumber();

                this.nud_FindCircle_PercentageOfIgnore.ValueChanged += nud_FindLine_PercentageOfIgnore_ValueChanged;
                this.nud_FindCircle_NumberOfIgnore.ValueChanged += nud_FindLine_NumberOfIgnore_ValueChanged;
            }
            else
            {
                return;
            }

            dg_FindCircle_Result.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
            this.dg_FindCircle_Result.CellValueChanged += dg_FindLIne_Result_CellValueChanged;
        }

        void SvFindLineEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.CircleCaliper);
            }
        }

        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject)
        {
            if (drawObject is MvCircleCaliper)
            {
                MvCircleCaliper circleCaliper = drawObject as MvCircleCaliper;
                Circle = circleCaliper.Circle;
                NotifyPropertyChanged("CircleCaliper");


            }
        }

        protected override void InitDisplayViewEdit()
        {

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvFindCircle Subject
        {
            get { return base.GetSubject() as MvFindCircle; }
            set { base.SetSubject(value); }
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvFindCircle), null);

            cb_FindCircle_FittingType.DisplayMember = "Key"; cb_FindCircle_FittingType.ValueMember = "Value";
            cb_FindCircle_FittingType.DataSource = Enum.GetValues(typeof(OpenCvSharp.DistanceType)).Cast<OpenCvSharp.DistanceType>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            //cb_FindLIne_FittingType.DataSource = Enum.GetValues(typeof(OpenCvSharp.DistanceTypes)).Cast<OpenCvSharp.DistanceTypes>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_FindCircle_FittingType.DataBindings.Add("SelectedValue", source, "FittingType", true, DataSourceUpdateMode.OnPropertyChanged);

            cb_FindCircle_IgnoreType.DataSource = MvFindCircle.IgnoreTypeList.Values.ToList();
            cb_FindCircle_IgnoreType.DataBindings.Add("SelectedItem", source, "IgnoreType", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_FindCircle_UseNumberOfCalipers.DataBindings.Add("Value", source, "UseNumberOfCalipers", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_NumberOfIgnore.DataBindings.Add("Value", source, "NumberOfIgnore", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_PercentageOfIgnore.DataBindings.Add("Value", source, "PercentageOfIgnore", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_Score.DataBindings.Add("Value", source, "Score", true, DataSourceUpdateMode.Never);
            txt_Score.DataBindings.Add("Text", source, "SetScore", true, DataSourceUpdateMode.OnPropertyChanged);
            txt_count.DataBindings.Add("Text", source, "SetCount", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_ContrastThreshold.DataBindings.Add("Value", source, "CircleCaliper.MinContrastThreshold", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_FilterHalfSize.DataBindings.Add("Value", source, "CircleCaliper.FilterHalfSize", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_NumberOfCalipers.DataBindings.Add("Value", source, "CircleCaliper.NumberOfCaliper", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_ProjectionLength.DataBindings.Add("Value", source, "CircleCaliper.ProjectionLength", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_SearchLength.DataBindings.Add("Value", source, "CircleCaliper.SearchLength", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_SA.DataBindings.Add("Value", source, "CircleCaliper.StartAngle", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_EA.DataBindings.Add("Value", source, "CircleCaliper.EndAngle", true, DataSourceUpdateMode.OnPropertyChanged);
            //nud_FindCircle_Width.DataBindings.Add("Value", source, "CircleCaliper.Circle.Width", true, DataSourceUpdateMode.OnPropertyChanged);
            //nud_FindCircle_Height.DataBindings.Add("Value", source, "CircleCaliper.Circle.Height", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_Radius.DataBindings.Add("Value", source, "CircleCaliper.Radius", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_CenterX.DataBindings.Add("Value", source, "CircleCaliper.CX", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_FindCircle_CenterY.DataBindings.Add("Value", source, "CircleCaliper.CY", true, DataSourceUpdateMode.OnPropertyChanged);


            DataBindings.Add("Circle", source, "CircleCaliper.Circle", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("Polarity", source, "CircleCaliper.Polarity", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("Priority", source, "CircleCaliper.Priority", true, DataSourceUpdateMode.OnPropertyChanged);

            DataBindings.Add("FindLineResult", source, "ResultList", true, DataSourceUpdateMode.Never);
        }

        private void nud_FindCircle_CaliperCircle_ValueChanged(object sender, EventArgs e)
        {

           
            NotifyPropertyChanged("Circle");
            //svDisplayViewEdit.Invalidate();
            //svDisplayViewEdit.Refresh();


        }

        private void rb_FindLine_Polarity_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb.Checked)
                NotifyPropertyChanged("Polarity");
        }

        private void rb_FindLine_Priority_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = sender as RadioButton;
            if (rb.Checked)
                NotifyPropertyChanged("Priority");
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvCircle Circle
        {
            get
            {
                MvCircle circle = new MvCircle();
                //line.SP = new OpenCvSharp.CPlusPlus.Point2d((double)nud_FindLine_SpX.Value, (double)nud_FindLine_SpY.Value);
                //line.EP = new OpenCvSharp.CPlusPlus.Point2d((double)nud_FindLine_EpX.Value, (double)nud_FindLine_EpY.Value);
                circle.StartAngle = (double)nud_FindCircle_SA.Value;
                circle.EndAngle = (double)nud_FindCircle_EA.Value;
                //circle.Width = (float)nud_FindCircle_Width.Value;
                //circle.Height = (float)nud_FindCircle_Height.Value;
                circle.R = (float)nud_FindCircle_Radius.Value;
                circle.CenterF = new PointF((float)nud_FindCircle_CenterX.Value, (float)nud_FindCircle_CenterY.Value);
                return circle;
            }
            set
            {
                //nud_FindLine_SpX.Value = (decimal)value.SP.X;
                //nud_FindLine_SpY.Value = (decimal)value.SP.Y;
                //nud_FindLine_EpX.Value = (decimal)value.EP.X;
                //nud_FindLine_EpY.Value = (decimal)value.EP.Y;
                nud_FindCircle_SA.Value = (decimal)value.StartAngle;
                nud_FindCircle_EA.Value = (decimal)value.EndAngle;
                //nud_FindCircle_Width.Value = (decimal)value.Width;
                //nud_FindCircle_Height.Value = (decimal)value.Height;
                nud_FindCircle_Radius.Value = (decimal)value.R;
                nud_FindCircle_CenterX.Value = (decimal)value.CenterF.X;
                nud_FindCircle_CenterY.Value = (decimal)value.CenterF.Y;

                //nud_FindCircle_CenterX.Value = (decimal)value.Center.X;
                //nud_FindCircle_CenterY.Value = (decimal)value.Center.Y;
                svDisplayViewEdit.Refresh(); //Refresh Draw Image 
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvCircleCaliper.CaliperPriority Priority
        {
            get
            {
                MvCircleCaliper.CaliperPriority caliperPriority = MvCircleCaliper.CaliperPriority.Peak;
                if (rb_FindCircle_Peak.Checked)
                    caliperPriority = MvCircleCaliper.CaliperPriority.Peak;
                else if (rb_FindCircle_Last.Checked)
                    caliperPriority = MvCircleCaliper.CaliperPriority.Last;
                else if (rb_FindCircle_First.Checked)
                    caliperPriority = MvCircleCaliper.CaliperPriority.First;
                else if (rb_FindCircle_Pos.Checked)
                    caliperPriority = MvCircleCaliper.CaliperPriority.Pos;
                else
                    throw new Exception("프로그램 잘못짬");

                return caliperPriority;
            }
            set
            {
                if (value == MvCircleCaliper.CaliperPriority.First)
                    rb_FindCircle_First.Checked = true;
                else if (value == MvCircleCaliper.CaliperPriority.Last)
                    rb_FindCircle_Last.Checked = true;
                else if (value == MvCircleCaliper.CaliperPriority.Peak)
                    rb_FindCircle_Peak.Checked = true;
                else if (value == MvCircleCaliper.CaliperPriority.Pos)
                    rb_FindCircle_Pos.Checked = true;
                else
                    throw new Exception("프로그램 잘못짬");
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvCircleCaliper.EdgePolarity Polarity
        {
            get
            {
                MvCircleCaliper.EdgePolarity caliperPolarity = MvCircleCaliper.EdgePolarity.Dark_to_Light;
                if (rb_FindCircle_AnyPolarity.Checked)
                    caliperPolarity = MvCircleCaliper.EdgePolarity.Any_Polarity;
                else if (rb_FindCircle_DarkToLight.Checked)
                    caliperPolarity = MvCircleCaliper.EdgePolarity.Dark_to_Light;
                else if (rb_FindCircle_LightToDark.Checked)
                    caliperPolarity = MvCircleCaliper.EdgePolarity.Light_to_Dark;
                else
                    throw new Exception("프로그램 잘못짬");

                return caliperPolarity;
            }
            set
            {
                if (value == MvCircleCaliper.EdgePolarity.Any_Polarity)
                    rb_FindCircle_AnyPolarity.Checked = true;
                else if (value == MvCircleCaliper.EdgePolarity.Dark_to_Light)
                    rb_FindCircle_DarkToLight.Checked = true;
                else if (value == MvCircleCaliper.EdgePolarity.Light_to_Dark)
                    rb_FindCircle_LightToDark.Checked = true;
                else
                    throw new Exception("프로그램 잘못짬");
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public List<MvFindCircle.FindCircleResult> FindLineResult
        {
            get { throw new Exception("Can't get"); }
            set
            {
                dg_FindCircle_Result.DataSource = null;
                dg_FindCircle_Result.DataSource = value;

                for (int i = 1; i < dg_FindCircle_Result.Columns.Count; i++)
                {
                    dg_FindCircle_Result.Columns[i].ReadOnly = true;
                    dg_FindCircle_Result.Columns[i].Resizable = DataGridViewTriState.False;
                    dg_FindCircle_Result.Columns[i].Width = 70;
                }

                dg_FindCircle_Result.Columns[0].Width = 32;
                dg_FindCircle_Result.Columns[1].Width = 28;
                dg_FindCircle_Result.Columns[2].Width = 48;
            }
        }

        private void cb_FindLIne_IgnoreType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Subject == null) return;
            Subject.IgnoreType = cb_FindCircle_IgnoreType.SelectedItem.ToString();

            if (Subject.IgnoreType == "Number")
            {
                nud_FindCircle_NumberOfIgnore.ReadOnly = false;
                nud_FindCircle_PercentageOfIgnore.ReadOnly = true;
                NotifyPropertyChanged("IgnorType");
            }
            else
            {
                nud_FindCircle_NumberOfIgnore.ReadOnly = true;
                nud_FindCircle_PercentageOfIgnore.ReadOnly = false;
                NotifyPropertyChanged("IgnorType");
            }
        }

        // PercentageOfIgnore 수치 변경 이벤트
        private void nud_FindLine_PercentageOfIgnore_ValueChanged(object sender, EventArgs e)
        {
            Subject.PercentageOfIgnore = (int)nud_FindCircle_PercentageOfIgnore.Value;
            this.nud_FindCircle_PercentageOfIgnore.ValueChanged -= nud_FindLine_NumberOfIgnore_ValueChanged;

            Subject.Cal_IgnoreNumber();

            this.nud_FindCircle_PercentageOfIgnore.ValueChanged += nud_FindLine_NumberOfIgnore_ValueChanged;
        }

        private void nud_FindLine_NumberOfIgnore_ValueChanged(object sender, EventArgs e)
        {
            Subject.NumberOfIgnore = (int)nud_FindCircle_NumberOfIgnore.Value;
            this.nud_FindCircle_PercentageOfIgnore.ValueChanged -= nud_FindLine_PercentageOfIgnore_ValueChanged;

            Subject.Cal_IgnoreNumber();

            this.nud_FindCircle_PercentageOfIgnore.ValueChanged += nud_FindLine_PercentageOfIgnore_ValueChanged;
        }

        private void nud_FindLine_UseNumberOfCalipers_ValueChanged(object sender, EventArgs e)
        {
            Subject.Cal_UseCount();
        }

        private void btn_SwapPoint_Click(object sender, EventArgs e)
        {
            Subject.Swap();
        }


    }
}
