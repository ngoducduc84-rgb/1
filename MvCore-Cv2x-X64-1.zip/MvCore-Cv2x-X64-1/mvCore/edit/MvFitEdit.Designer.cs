﻿namespace MvCore.Edit
{
    partial class MvFitEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_Setting = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.nud_Fit_FourPY = new System.Windows.Forms.NumericUpDown();
            this.nud_Fit_FourPX = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nud_Fit_ThreePY = new System.Windows.Forms.NumericUpDown();
            this.nud_Fit_ThreePX = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_mode = new System.Windows.Forms.ComboBox();
            this.nud_CreateLine_Angle = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nud_Fit_OnePX = new System.Windows.Forms.NumericUpDown();
            this.nud_Fit_OnePY = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_Fit_TwoPY = new System.Windows.Forms.NumericUpDown();
            this.nud_Fit_TwoPX = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.nud_Fit_FivePY = new System.Windows.Forms.NumericUpDown();
            this.nud_Fit_FivePX = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tp_Setting.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_FourPY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_FourPX)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_ThreePY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_ThreePX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CreateLine_Angle)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_OnePX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_OnePY)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_TwoPY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_TwoPX)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_FivePY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_FivePX)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Setting);
            // 
            // tp_Setting
            // 
            this.tp_Setting.Controls.Add(this.groupBox5);
            this.tp_Setting.Controls.Add(this.groupBox4);
            this.tp_Setting.Controls.Add(this.groupBox3);
            this.tp_Setting.Controls.Add(this.label3);
            this.tp_Setting.Controls.Add(this.cb_mode);
            this.tp_Setting.Controls.Add(this.nud_CreateLine_Angle);
            this.tp_Setting.Controls.Add(this.label2);
            this.tp_Setting.Controls.Add(this.groupBox2);
            this.tp_Setting.Controls.Add(this.groupBox1);
            this.tp_Setting.Location = new System.Drawing.Point(4, 22);
            this.tp_Setting.Name = "tp_Setting";
            this.tp_Setting.Size = new System.Drawing.Size(442, 426);
            this.tp_Setting.TabIndex = 0;
            this.tp_Setting.Text = "Setting";
            this.tp_Setting.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.nud_Fit_FourPY);
            this.groupBox4.Controls.Add(this.nud_Fit_FourPX);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.ForeColor = System.Drawing.Color.Cyan;
            this.groupBox4.Location = new System.Drawing.Point(162, 134);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(134, 67);
            this.groupBox4.TabIndex = 30;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Four Point";
            // 
            // nud_Fit_FourPY
            // 
            this.nud_Fit_FourPY.DecimalPlaces = 3;
            this.nud_Fit_FourPY.Location = new System.Drawing.Point(63, 45);
            this.nud_Fit_FourPY.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Fit_FourPY.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Fit_FourPY.Name = "nud_Fit_FourPY";
            this.nud_Fit_FourPY.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_FourPY.TabIndex = 24;
            this.nud_Fit_FourPY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_FourPY.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // nud_Fit_FourPX
            // 
            this.nud_Fit_FourPX.DecimalPlaces = 3;
            this.nud_Fit_FourPX.Location = new System.Drawing.Point(63, 16);
            this.nud_Fit_FourPX.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Fit_FourPX.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Fit_FourPX.Name = "nud_Fit_FourPX";
            this.nud_Fit_FourPX.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_FourPX.TabIndex = 22;
            this.nud_Fit_FourPX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_FourPX.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Y: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "X: ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.nud_Fit_ThreePY);
            this.groupBox3.Controls.Add(this.nud_Fit_ThreePX);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.ForeColor = System.Drawing.Color.Green;
            this.groupBox3.Location = new System.Drawing.Point(4, 134);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(134, 67);
            this.groupBox3.TabIndex = 29;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ThreePoint";
            // 
            // nud_Fit_ThreePY
            // 
            this.nud_Fit_ThreePY.DecimalPlaces = 3;
            this.nud_Fit_ThreePY.Location = new System.Drawing.Point(63, 45);
            this.nud_Fit_ThreePY.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Fit_ThreePY.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Fit_ThreePY.Name = "nud_Fit_ThreePY";
            this.nud_Fit_ThreePY.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_ThreePY.TabIndex = 24;
            this.nud_Fit_ThreePY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_ThreePY.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // nud_Fit_ThreePX
            // 
            this.nud_Fit_ThreePX.DecimalPlaces = 3;
            this.nud_Fit_ThreePX.Location = new System.Drawing.Point(63, 16);
            this.nud_Fit_ThreePX.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Fit_ThreePX.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Fit_ThreePX.Name = "nud_Fit_ThreePX";
            this.nud_Fit_ThreePX.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_ThreePX.TabIndex = 22;
            this.nud_Fit_ThreePX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_ThreePX.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Y: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "X: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(322, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "Mode: ";
            // 
            // cb_mode
            // 
            this.cb_mode.FormattingEnabled = true;
            this.cb_mode.Location = new System.Drawing.Point(366, 52);
            this.cb_mode.Name = "cb_mode";
            this.cb_mode.Size = new System.Drawing.Size(69, 21);
            this.cb_mode.TabIndex = 32;
            // 
            // nud_CreateLine_Angle
            // 
            this.nud_CreateLine_Angle.DecimalPlaces = 3;
            this.nud_CreateLine_Angle.Location = new System.Drawing.Point(366, 86);
            this.nud_CreateLine_Angle.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_CreateLine_Angle.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_CreateLine_Angle.Name = "nud_CreateLine_Angle";
            this.nud_CreateLine_Angle.Size = new System.Drawing.Size(69, 20);
            this.nud_CreateLine_Angle.TabIndex = 26;
            this.nud_CreateLine_Angle.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(322, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "Angle: ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nud_Fit_OnePX);
            this.groupBox2.Controls.Add(this.nud_Fit_OnePY);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Location = new System.Drawing.Point(3, 41);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(134, 67);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "One Point";
            // 
            // nud_Fit_OnePX
            // 
            this.nud_Fit_OnePX.DecimalPlaces = 3;
            this.nud_Fit_OnePX.Location = new System.Drawing.Point(66, 17);
            this.nud_Fit_OnePX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Fit_OnePX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Fit_OnePX.Name = "nud_Fit_OnePX";
            this.nud_Fit_OnePX.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_OnePX.TabIndex = 27;
            this.nud_Fit_OnePX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_OnePX.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // nud_Fit_OnePY
            // 
            this.nud_Fit_OnePY.DecimalPlaces = 3;
            this.nud_Fit_OnePY.Location = new System.Drawing.Point(66, 43);
            this.nud_Fit_OnePY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Fit_OnePY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Fit_OnePY.Name = "nud_Fit_OnePY";
            this.nud_Fit_OnePY.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_OnePY.TabIndex = 30;
            this.nud_Fit_OnePY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_OnePY.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "X: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "Y: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_Fit_TwoPY);
            this.groupBox1.Controls.Add(this.nud_Fit_TwoPX);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.ForeColor = System.Drawing.Color.YellowGreen;
            this.groupBox1.Location = new System.Drawing.Point(164, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(134, 67);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Two Point";
            // 
            // nud_Fit_TwoPY
            // 
            this.nud_Fit_TwoPY.DecimalPlaces = 3;
            this.nud_Fit_TwoPY.Location = new System.Drawing.Point(63, 45);
            this.nud_Fit_TwoPY.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Fit_TwoPY.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Fit_TwoPY.Name = "nud_Fit_TwoPY";
            this.nud_Fit_TwoPY.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_TwoPY.TabIndex = 24;
            this.nud_Fit_TwoPY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_TwoPY.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // nud_Fit_TwoPX
            // 
            this.nud_Fit_TwoPX.DecimalPlaces = 3;
            this.nud_Fit_TwoPX.Location = new System.Drawing.Point(63, 16);
            this.nud_Fit_TwoPX.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Fit_TwoPX.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Fit_TwoPX.Name = "nud_Fit_TwoPX";
            this.nud_Fit_TwoPX.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_TwoPX.TabIndex = 22;
            this.nud_Fit_TwoPX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_TwoPX.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Y: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "X: ";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.nud_Fit_FivePY);
            this.groupBox5.Controls.Add(this.nud_Fit_FivePX);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.ForeColor = System.Drawing.Color.Fuchsia;
            this.groupBox5.Location = new System.Drawing.Point(306, 134);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(134, 67);
            this.groupBox5.TabIndex = 31;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Five Point";
            // 
            // nud_Fit_FivePY
            // 
            this.nud_Fit_FivePY.DecimalPlaces = 3;
            this.nud_Fit_FivePY.Location = new System.Drawing.Point(63, 45);
            this.nud_Fit_FivePY.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Fit_FivePY.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Fit_FivePY.Name = "nud_Fit_FivePY";
            this.nud_Fit_FivePY.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_FivePY.TabIndex = 24;
            this.nud_Fit_FivePY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_FivePY.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // nud_Fit_FivePX
            // 
            this.nud_Fit_FivePX.DecimalPlaces = 3;
            this.nud_Fit_FivePX.Location = new System.Drawing.Point(63, 16);
            this.nud_Fit_FivePX.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Fit_FivePX.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Fit_FivePX.Name = "nud_Fit_FivePX";
            this.nud_Fit_FivePX.Size = new System.Drawing.Size(69, 20);
            this.nud_Fit_FivePX.TabIndex = 22;
            this.nud_Fit_FivePX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Fit_FivePX.ValueChanged += new System.EventHandler(this.nud_Fit_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Y: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(32, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(20, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "X: ";
            // 
            // MvFitEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "MvFitEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Setting.ResumeLayout(false);
            this.tp_Setting.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_FourPY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_FourPX)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_ThreePY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_ThreePX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CreateLine_Angle)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_OnePX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_OnePY)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_TwoPY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_TwoPX)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_FivePY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Fit_FivePX)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Setting;
        private System.Windows.Forms.NumericUpDown nud_Fit_OnePX;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nud_Fit_TwoPY;
        private System.Windows.Forms.NumericUpDown nud_Fit_TwoPX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nud_Fit_OnePY;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.NumericUpDown nud_CreateLine_Angle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_mode;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown nud_Fit_ThreePY;
        private System.Windows.Forms.NumericUpDown nud_Fit_ThreePX;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown nud_Fit_FourPY;
        private System.Windows.Forms.NumericUpDown nud_Fit_FourPX;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.NumericUpDown nud_Fit_FivePY;
        private System.Windows.Forms.NumericUpDown nud_Fit_FivePX;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}
