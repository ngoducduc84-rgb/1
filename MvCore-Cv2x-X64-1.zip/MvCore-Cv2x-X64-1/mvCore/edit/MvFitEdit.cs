﻿using MvCore.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MvCore.Edit
{
    public partial class MvFitEdit : MvToolEditBase
    {
        public MvFitEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvFindLineEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }
        void SvFindLineEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
        public MvFit Subject
        {
            get { return base.GetSubject() as MvFit; }
            set { base.SetSubject(value); }
        }

        BindingSource source;
        void InitBinding()
        {
            source = new BindingSource(typeof(MvCreateLine), null);

            cb_mode.DisplayMember = "Key"; cb_mode.ValueMember = "Value";
            cb_mode.DataSource = Enum.GetValues(typeof(MvFit.E_mode)).Cast<MvFit.E_mode>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_mode.DataBindings.Add("SelectedValue", source, "Mode", true, DataSourceUpdateMode.OnPropertyChanged);

            //nud_CreateLine_Angle.DataBindings.Add("Value", source, "Angle", true, DataSourceUpdateMode.OnPropertyChanged);
            //DataBindings.Add("caliperLine", source, "Line", true, DataSourceUpdateMode.OnPropertyChanged);

            DataBindings.Add("OnePoint", source, "OnePoint", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("TwoPoint", source, "TwoPoint", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("ThreePoint", source, "ThreePoint", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("FourPoint", source, "FourPoint", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("FivePoint", source, "FivePoint", true, DataSourceUpdateMode.OnPropertyChanged);
            //DataBindings.Add("FindLineResult", source, "ResultList", true, DataSourceUpdateMode.Never);
        }
        //private void nud_FindCircle_caliperLine_ValueChanged(object sender, EventArgs e)
        //{
        //    if (lockEvent == false)
        //    {
        //        NotifyPropertyChanged("caliperLine");
        //        svDisplayViewEdit.Refresh(); //Refresh draw image
        //    }
        //}

        private void nud_Fit_ValueChanged(object sender, EventArgs e)
        {
            if (lockEvent1 == false)
                NotifyPropertyChanged("OnePoint");
            if (lockEvent2 == false)
                NotifyPropertyChanged("TwoPoint");
            if (lockEvent3 == false)
                NotifyPropertyChanged("ThreePoint");
            if (lockEvent4 == false)
                NotifyPropertyChanged("FourPoint");
            if (lockEvent5 == false)
                NotifyPropertyChanged("FivePoint");
            svDisplayViewEdit.Refresh(); //Refresh draw image
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                {
                    //this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.Line);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.OnePoint);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.TwoPoint);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.ThreePoint);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.FourPoint);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.FivePoint);
                }

            }
        }
        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject) //update new Circle
        {

            if (drawObject is MvPoint)
            {
                MvPoint _newPoint = drawObject as MvPoint;
                switch (_newPoint.ID)
                {
                    case 0:
                        OnePoint = _newPoint; break;
                    case 1:
                        TwoPoint = _newPoint; break;
                    case 2:
                        ThreePoint = _newPoint; break;
                    case 3:
                        FourPoint = _newPoint; break;
                    case 4:
                        FivePoint = _newPoint; break;
                }
            }
        }
        //bool lockEvent = false;
        //private MvLine caliperLine;
        //public MvLine CaliperLine
        //{
        //    get
        //    {
        //        caliperLine.SP = new Point2d((double)nud_Fit_OnePX.Value, (double)nud_Fit_OnePY.Value);
        //        caliperLine.EP = new Point2d((double)nud_Fit_TwoPX.Value, (double)nud_Fit_TwoPY.Value);
        //        return caliperLine;
        //    }
        //    set
        //    {

        //        lockEvent = true;
        //        caliperLine = value;
        //        nud_Fit_OnePX.Value = (decimal)value.SP.X;
        //        nud_Fit_OnePY.Value = (decimal)value.SP.Y;
        //        nud_Fit_TwoPX.Value = (decimal)value.EP.X;
        //        nud_Fit_TwoPY.Value = (decimal)value.EP.Y;
        //        //svDisplayViewEdit.Refresh(); //Refresh draw image
        //        lockEvent = false;

        //    }
        //}

        bool lockEvent1 = false;
        private MvPoint onePoint;
        public MvPoint OnePoint
        {
            get
            {
                onePoint.X = (float)nud_Fit_OnePX.Value;
                onePoint.Y = (float)nud_Fit_OnePY.Value;
                return onePoint;
            }
            set
            {
                lockEvent1 = true;
                onePoint = value;
                nud_Fit_OnePX.Value = (decimal)value.X;
                nud_Fit_OnePY.Value = (decimal)value.Y;
                lockEvent1 = false;
            }
        }

        bool lockEvent2 = false;
        private MvPoint twoPoint;
        public MvPoint TwoPoint
        {
            get
            {
                twoPoint.X = (float)nud_Fit_TwoPX.Value;
                twoPoint.Y = (float)nud_Fit_TwoPY.Value;
                return twoPoint;
            }
            set
            {
                lockEvent2 = true;
                twoPoint = value;
                nud_Fit_TwoPX.Value = (decimal)value.X;
                nud_Fit_TwoPY.Value = (decimal)value.Y;
                lockEvent2 = false;
            }
        }

        bool lockEvent3 = false;
        private MvPoint threePoint;
        public MvPoint ThreePoint
        {
            get
            {
                threePoint.X = (float)nud_Fit_ThreePX.Value;
                threePoint.Y = (float)nud_Fit_ThreePY.Value;
                return threePoint;
            }
            set
            {
                lockEvent3 = true;
                threePoint = value;
                nud_Fit_ThreePX.Value = (decimal)value.X;
                nud_Fit_ThreePY.Value = (decimal)value.Y;
                lockEvent3 = false;
            }
        }

        bool lockEvent4 = false;
        private MvPoint fourPoint;
        public MvPoint FourPoint
        {
            get
            {
                fourPoint.X = (float)nud_Fit_FourPX.Value;
                fourPoint.Y = (float)nud_Fit_FourPY.Value;
                return fourPoint;
            }
            set
            {
                lockEvent4 = true;
                fourPoint = value;
                nud_Fit_FourPX.Value = (decimal)value.X;
                nud_Fit_FourPY.Value = (decimal)value.Y;
                lockEvent4 = false;
            }
        }

        bool lockEvent5 = false;
        private MvPoint fivePoint;
        public MvPoint FivePoint
        {
            get
            {
                fivePoint.X = (float)nud_Fit_FivePX.Value;
                fivePoint.Y = (float)nud_Fit_FivePY.Value;
                return fivePoint;
            }
            set
            {
                lockEvent5 = true;
                fivePoint = value;
                nud_Fit_FivePX.Value = (decimal)value.X;
                nud_Fit_FivePY.Value = (decimal)value.Y;
                lockEvent5 = false;
            }
        }


    }
}
