﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenCvSharp;
using MvCore.Edit.Base;

namespace MvCore.Edit
{
    public partial class MvFixtureEdit : MvToolEditBase
    {
        public MvFixtureEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvFixtureEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {

            if(imageInfo.ImageName.Contains("OutputImage"))
            { 
                if(imageInfo.Image != null)
                {
                    //this.SvDisplayViewEdit.Display.GraphicsFuncCollection.Add(DrawCoodination);
                }
            }
            else
                this.SvDisplayViewEdit.Display.ClearImage();
        }

        void DrawCoodination(Graphics gdi)
        {
            int size = (int)(SvDisplayViewEdit.Width * 0.2 / SvDisplayViewEdit.Display.ZoomRatio);

            PointF originPt = new PointF(0f, 0f);
            PointF widthPt = new PointF(size, originPt.Y);
            PointF heightPt = new PointF(originPt.X, size);
            using (Pen p = new Pen(Brushes.Cyan, 3 / SvDisplayViewEdit.Display.ZoomRatio))
            {
                p.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                
                gdi.DrawLine(p, originPt, widthPt);
                gdi.DrawLine(p, originPt, heightPt);

                float fontSize = 15;
                Font font = new System.Drawing.Font("굴림", fontSize,System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel);
                gdi.DrawString("X", font, Brushes.Cyan, widthPt.X, widthPt.Y - fontSize / 2);
                gdi.DrawString("Y", font, Brushes.Cyan, heightPt.X - fontSize / 2, heightPt.Y);
                font.Dispose();
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvFixture Subject
        {
            get { return base.GetSubject() as MvFixture; }
            set { base.SetSubject(value); }
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvFixture), null);
            nud_Translate_X.DataBindings.Add("Value", source, "TranslateX", true, DataSourceUpdateMode.OnPropertyChanged, 0f);
            nud_Translate_Y.DataBindings.Add("Value", source, "TranslateY", true, DataSourceUpdateMode.OnPropertyChanged, 0f);
            nud_Scaling.DataBindings.Add("Value", source, "Scale", true, DataSourceUpdateMode.OnPropertyChanged, 0f);

            DataBindings.Add("Rotation", source, "Rotation", true, DataSourceUpdateMode.OnPropertyChanged, 0f);
        }

        void SvFixtureEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            nud_Translate_X.Value = 0;
            nud_Translate_Y.Value = 0;
            nud_Rotation.Value = 0;
            nud_Scaling.Value = 1;
        }

        private void btn_RotDegRadChanger_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            float value = (float)nud_Rotation.Value;
            if (btn.Text == "deg")
            {
                btn.Text = "rad";
                nud_Rotation.Value = (decimal)(value * Math.PI / 180);
            }
            else
            {
                btn.Text = "deg";
                nud_Rotation.Value = (decimal)(value / Math.PI * 180);
            }
        }

        private void nud_Rotation_ValueChanged(object sender, EventArgs e)
        {
            NotifyPropertyChanged("Rotation");
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public float Rotation
        {
            get 
            {
                float value = (float)nud_Rotation.Value;

                if (btn_RotDegRadChanger.Text == "deg")
                    value = (float)(value * Math.PI / 180);

                return value;
            }
            set
            {
                float val = value;
                if (btn_RotDegRadChanger.Text == "deg")
                    val = (float)(val / Math.PI * 180);

                nud_Rotation.Value = (decimal)val;
            }
        }

    }
}
