﻿using MvCore.Edit.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MvCore.Edit
{
    public partial class MvForEdit : MvToolEditBase
    {
       

        public MvForEdit()
        {
            InitializeComponent();
        }
        public override void formLoad()
        {
            if (Subject != null)
            {
                numericUpDown2.Value = Subject.Condition;
            }
        }
        public MvFor Subject // tool class
        {
            get { return base.GetSubject() as MvFor; }
            set { base.SetSubject(value); }
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            if (Subject != null)
            {
                Subject.Condition = (int)numericUpDown2.Value;
            }
               
        }
    }
}
