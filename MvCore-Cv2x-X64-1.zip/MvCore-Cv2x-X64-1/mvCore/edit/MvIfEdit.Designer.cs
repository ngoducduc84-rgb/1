﻿namespace MvCore.Edit
{
    partial class MvIfEdit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Parameter = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_Condition2 = new System.Windows.Forms.ComboBox();
            this.cb_Condition1 = new System.Windows.Forms.ComboBox();
            this.tabControl.SuspendLayout();
            this.Parameter.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.Parameter);
            // 
            // Parameter
            // 
            this.Parameter.Controls.Add(this.cb_Condition2);
            this.Parameter.Controls.Add(this.cb_Condition1);
            this.Parameter.Controls.Add(this.label2);
            this.Parameter.Controls.Add(this.label1);
            this.Parameter.Location = new System.Drawing.Point(4, 22);
            this.Parameter.Name = "Parameter";
            this.Parameter.Size = new System.Drawing.Size(442, 426);
            this.Parameter.TabIndex = 0;
            this.Parameter.Text = "tabPage1";
            this.Parameter.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Condition2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Condition1";
            // 
            // cb_Condition2
            // 
            this.cb_Condition2.FormattingEnabled = true;
            this.cb_Condition2.Location = new System.Drawing.Point(80, 44);
            this.cb_Condition2.Name = "cb_Condition2";
            this.cb_Condition2.Size = new System.Drawing.Size(81, 21);
            this.cb_Condition2.TabIndex = 7;
            // 
            // cb_Condition1
            // 
            this.cb_Condition1.FormattingEnabled = true;
            this.cb_Condition1.Location = new System.Drawing.Point(80, 16);
            this.cb_Condition1.Name = "cb_Condition1";
            this.cb_Condition1.Size = new System.Drawing.Size(81, 21);
            this.cb_Condition1.TabIndex = 6;
            // 
            // MvIfEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "MvIfEdit";
            this.tabControl.ResumeLayout(false);
            this.Parameter.ResumeLayout(false);
            this.Parameter.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage Parameter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_Condition2;
        private System.Windows.Forms.ComboBox cb_Condition1;
    }
}
