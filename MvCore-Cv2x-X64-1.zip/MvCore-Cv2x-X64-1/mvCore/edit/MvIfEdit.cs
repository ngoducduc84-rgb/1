﻿using MvCore.Edit.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MvCore.Edit
{
    public partial class MvIfEdit : MvToolEditBase
    {
        public MvIfEdit()
        {
            InitializeComponent();
            initBinding();
            this.SubjectChanged += MvIfEdit_SubjectChanged;
        }

        public MvIf Subject // tool class
        {
            get { return base.GetSubject() as MvIf; }
            set { base.SetSubject(value); }
        }
        private void MvIfEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
        public override void formLoad()
        {
            //if (Subject != null)
            //{
            //    if(Subject.Condition1 != null)
            //        textBox1.Text = Subject.Condition1.ToString();
            //    if (Subject.Condition2 != null)
            //        textBox2.Text = Subject.Condition2.ToString();
            //}
        }

        BindingSource source;
        void initBinding()
        {
            source = new BindingSource(typeof(MvIf), null);
            cb_Condition1.DataSource = new List<bool> { true, false };
            cb_Condition2.DataSource = new List<bool> { true, false };
            cb_Condition1.DataBindings.Add("Text", source, "Condition1", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            cb_Condition2.DataBindings.Add("Text", source, "Condition2", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
        }

        //private void textBox1_TextChanged(object sender, EventArgs e)
        //{
        //    if (Subject != null)
        //    {
        //       Subject.Condition1 = textBox1.Text;
        //    }
        //}

        //private void textBox2_TextChanged(object sender, EventArgs e)
        //{
        //    if (Subject != null)
        //    {
        //        Subject.Condition2 = textBox2.Text;
        //    }
        //}
    }
}
