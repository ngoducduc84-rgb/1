﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;




namespace MvCore.Edit
{
    public partial class MvImageCalculateEdit : MvToolEditBase
    {
        public MvImageCalculateEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvImageCalculateEdit_SubjectChanged;
        }
        protected override void InitDisplayViewEdit()
        {

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvImageCalculate Subject
        {
            get { return base.GetSubject() as MvImageCalculate; }
            set { base.SetSubject(value); }
        }

        void SvImageCalculateEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvImageCalculate), null);
            nud_ImgCal_alpha.DataBindings.Add("Value", source, "ImgCal_Alpha", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_ImgCal_beta.DataBindings.Add("Value", source, "ImgCal_Beta", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_ImgCal_gamma.DataBindings.Add("Value", source, "ImgCal_Gamma", true, DataSourceUpdateMode.OnPropertyChanged);
            chk_Abs.DataBindings.Add("Checked", source, "IsAbs", true, DataSourceUpdateMode.OnPropertyChanged);
            chk_AutoSubtract.DataBindings.Add("Checked", source, "IsAutoSubtract", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void nud_ImgCal_ValueChanged(object sender, EventArgs e)
        {
            //Subject.Run();
            SvDisplayViewEdit.RefreshImage();
        }

        private void chk_AutoSubtract_CheckedChanged(object sender, EventArgs e)
        {
            gb_Calculator.Enabled = !chk_AutoSubtract.Checked;
        }
    }
}
