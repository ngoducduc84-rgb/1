﻿namespace MvCore.Edit
{
    partial class MvImageConverterEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_brightness = new System.Windows.Forms.TabPage();
            this.svHistogramBox = new MvCore.Display.MvHistogramBox();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.btn_AutoConvert = new System.Windows.Forms.Button();
            this.tb_Contrast = new System.Windows.Forms.TextBox();
            this.tb_Bright = new System.Windows.Forms.TextBox();
            this.lb_Contrast = new System.Windows.Forms.Label();
            this.track_Contrast = new System.Windows.Forms.TrackBar();
            this.lb_Brightness = new System.Windows.Forms.Label();
            this.track_Brightness = new System.Windows.Forms.TrackBar();
            this.tabControl.SuspendLayout();
            this.tp_brightness.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.track_Contrast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.track_Brightness)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_brightness);
            // 
            // tp_brightness
            // 
            this.tp_brightness.Controls.Add(this.svHistogramBox);
            this.tp_brightness.Controls.Add(this.btn_Reset);
            this.tp_brightness.Controls.Add(this.btn_AutoConvert);
            this.tp_brightness.Controls.Add(this.tb_Contrast);
            this.tp_brightness.Controls.Add(this.tb_Bright);
            this.tp_brightness.Controls.Add(this.lb_Contrast);
            this.tp_brightness.Controls.Add(this.track_Contrast);
            this.tp_brightness.Controls.Add(this.lb_Brightness);
            this.tp_brightness.Controls.Add(this.track_Brightness);
            this.tp_brightness.Location = new System.Drawing.Point(4, 22);
            this.tp_brightness.Name = "tp_brightness";
            this.tp_brightness.Padding = new System.Windows.Forms.Padding(3);
            this.tp_brightness.Size = new System.Drawing.Size(442, 426);
            this.tp_brightness.TabIndex = 0;
            this.tp_brightness.Text = "ImageConverter";
            this.tp_brightness.UseVisualStyleBackColor = true;
            // 
            // svHistogramBox
            // 
            this.svHistogramBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.svHistogramBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.svHistogramBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.svHistogramBox.EnableRangeDrag = false;
            this.svHistogramBox.Location = new System.Drawing.Point(82, 274);
            this.svHistogramBox.Name = "svHistogramBox";
            this.svHistogramBox.RangeHigh = 256;
            this.svHistogramBox.RangeLow = 0;
            this.svHistogramBox.Size = new System.Drawing.Size(284, 136);
            this.svHistogramBox.TabIndex = 13;
            this.svHistogramBox.UseOnlyLowRange = false;
            // 
            // btn_Reset
            // 
            this.btn_Reset.Location = new System.Drawing.Point(227, 225);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(139, 31);
            this.btn_Reset.TabIndex = 12;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = true;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // btn_AutoConvert
            // 
            this.btn_AutoConvert.Location = new System.Drawing.Point(82, 225);
            this.btn_AutoConvert.Name = "btn_AutoConvert";
            this.btn_AutoConvert.Size = new System.Drawing.Size(139, 31);
            this.btn_AutoConvert.TabIndex = 12;
            this.btn_AutoConvert.Text = "Auto Convert";
            this.btn_AutoConvert.UseVisualStyleBackColor = true;
            this.btn_AutoConvert.Click += new System.EventHandler(this.btn_AutoConvert_Click);
            // 
            // tb_Contrast
            // 
            this.tb_Contrast.Enabled = false;
            this.tb_Contrast.Location = new System.Drawing.Point(154, 20);
            this.tb_Contrast.Name = "tb_Contrast";
            this.tb_Contrast.Size = new System.Drawing.Size(83, 20);
            this.tb_Contrast.TabIndex = 10;
            // 
            // tb_Bright
            // 
            this.tb_Bright.Enabled = false;
            this.tb_Bright.Location = new System.Drawing.Point(154, 127);
            this.tb_Bright.Name = "tb_Bright";
            this.tb_Bright.Size = new System.Drawing.Size(83, 20);
            this.tb_Bright.TabIndex = 11;
            // 
            // lb_Contrast
            // 
            this.lb_Contrast.AutoSize = true;
            this.lb_Contrast.Location = new System.Drawing.Point(80, 24);
            this.lb_Contrast.Name = "lb_Contrast";
            this.lb_Contrast.Size = new System.Drawing.Size(46, 13);
            this.lb_Contrast.TabIndex = 8;
            this.lb_Contrast.Text = "Contrast";
            // 
            // track_Contrast
            // 
            this.track_Contrast.Location = new System.Drawing.Point(82, 52);
            this.track_Contrast.Maximum = 2000;
            this.track_Contrast.Minimum = -2000;
            this.track_Contrast.Name = "track_Contrast";
            this.track_Contrast.Size = new System.Drawing.Size(284, 45);
            this.track_Contrast.TabIndex = 6;
            this.track_Contrast.Scroll += new System.EventHandler(this.track_ImageConverter_Scroll);
            // 
            // lb_Brightness
            // 
            this.lb_Brightness.AutoSize = true;
            this.lb_Brightness.Location = new System.Drawing.Point(80, 131);
            this.lb_Brightness.Name = "lb_Brightness";
            this.lb_Brightness.Size = new System.Drawing.Size(56, 13);
            this.lb_Brightness.TabIndex = 9;
            this.lb_Brightness.Text = "Brightness";
            // 
            // track_Brightness
            // 
            this.track_Brightness.LargeChange = 500;
            this.track_Brightness.Location = new System.Drawing.Point(82, 161);
            this.track_Brightness.Maximum = 25500;
            this.track_Brightness.Minimum = -25500;
            this.track_Brightness.Name = "track_Brightness";
            this.track_Brightness.Size = new System.Drawing.Size(284, 45);
            this.track_Brightness.SmallChange = 100;
            this.track_Brightness.TabIndex = 7;
            this.track_Brightness.Scroll += new System.EventHandler(this.track_ImageConverter_Scroll);
            // 
            // SvImageConverterEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "SvImageConverterEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_brightness.ResumeLayout(false);
            this.tp_brightness.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.track_Contrast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.track_Brightness)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_brightness;
        private System.Windows.Forms.Button btn_AutoConvert;
        private System.Windows.Forms.TextBox tb_Contrast;
        private System.Windows.Forms.TextBox tb_Bright;
        private System.Windows.Forms.Label lb_Contrast;
        private System.Windows.Forms.TrackBar track_Contrast;
        private System.Windows.Forms.Label lb_Brightness;
        private System.Windows.Forms.TrackBar track_Brightness;
        private System.Windows.Forms.Button btn_Reset;
        private Display.MvHistogramBox svHistogramBox;
    }
}
