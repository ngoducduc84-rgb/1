﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;




namespace MvCore.Edit
{
    public partial class MvImageSaveEdit : MvToolEditBase
    {
        public MvImageSaveEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvImageSaveEdit_SubjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {

        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]

        
        public MvImageSave Subject
        {
            get { return base.GetSubject() as MvImageSave; }
            set { base.SetSubject(value); }
        }

        public void SvImageSaveEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvImageSave), null);
            tb_ImageSave_Name.DataBindings.Add("Text", source, "SaveFileName", true, DataSourceUpdateMode.OnPropertyChanged);
            tbSavePath.DataBindings.Add("Text", source, "SaveFilePath", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void btnSelectPath_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            if (!string.IsNullOrEmpty(tbSavePath.Text)) dlg.SelectedPath = tbSavePath.Text;
            if(dlg.ShowDialog() == DialogResult.OK)
            {
                Subject.SaveFilePath = dlg.SelectedPath;
            }
        }
    }
}
