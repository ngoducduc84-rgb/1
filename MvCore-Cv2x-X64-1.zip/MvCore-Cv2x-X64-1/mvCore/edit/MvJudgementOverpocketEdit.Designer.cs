﻿namespace MvCore.Edit
{
    partial class MvJudgementOverpocketEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Judgment = new System.Windows.Forms.TabPage();
            this.nud_Creteria4_ = new System.Windows.Forms.NumericUpDown();
            this.nud_Creteria4 = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.lb_Output4 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lb_Input4 = new System.Windows.Forms.Label();
            this.cb_Comparison4 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.nud_Creteria3_ = new System.Windows.Forms.NumericUpDown();
            this.nud_Creteria3 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.lb_Output3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lb_Input3 = new System.Windows.Forms.Label();
            this.cb_Comparison3 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.nud_Creteria2_ = new System.Windows.Forms.NumericUpDown();
            this.nud_Creteria2 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_Output2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_Input2 = new System.Windows.Forms.Label();
            this.cb_Comparison2 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.nud_Creteria1_ = new System.Windows.Forms.NumericUpDown();
            this.nud_Creteria1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_Output1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Input1 = new System.Windows.Forms.Label();
            this.cb_Comparison1 = new System.Windows.Forms.ComboBox();
            this.lable = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tb_Judgment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria4_)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria3_)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria2_)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria1_)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tb_Judgment);
            // 
            // tb_Judgment
            // 
            this.tb_Judgment.Controls.Add(this.nud_Creteria4_);
            this.tb_Judgment.Controls.Add(this.nud_Creteria4);
            this.tb_Judgment.Controls.Add(this.label13);
            this.tb_Judgment.Controls.Add(this.lb_Output4);
            this.tb_Judgment.Controls.Add(this.label15);
            this.tb_Judgment.Controls.Add(this.lb_Input4);
            this.tb_Judgment.Controls.Add(this.cb_Comparison4);
            this.tb_Judgment.Controls.Add(this.label17);
            this.tb_Judgment.Controls.Add(this.nud_Creteria3_);
            this.tb_Judgment.Controls.Add(this.nud_Creteria3);
            this.tb_Judgment.Controls.Add(this.label8);
            this.tb_Judgment.Controls.Add(this.lb_Output3);
            this.tb_Judgment.Controls.Add(this.label10);
            this.tb_Judgment.Controls.Add(this.lb_Input3);
            this.tb_Judgment.Controls.Add(this.cb_Comparison3);
            this.tb_Judgment.Controls.Add(this.label12);
            this.tb_Judgment.Controls.Add(this.nud_Creteria2_);
            this.tb_Judgment.Controls.Add(this.nud_Creteria2);
            this.tb_Judgment.Controls.Add(this.label2);
            this.tb_Judgment.Controls.Add(this.lb_Output2);
            this.tb_Judgment.Controls.Add(this.label5);
            this.tb_Judgment.Controls.Add(this.lb_Input2);
            this.tb_Judgment.Controls.Add(this.cb_Comparison2);
            this.tb_Judgment.Controls.Add(this.label7);
            this.tb_Judgment.Controls.Add(this.nud_Creteria1_);
            this.tb_Judgment.Controls.Add(this.nud_Creteria1);
            this.tb_Judgment.Controls.Add(this.label3);
            this.tb_Judgment.Controls.Add(this.lb_Output1);
            this.tb_Judgment.Controls.Add(this.label1);
            this.tb_Judgment.Controls.Add(this.lb_Input1);
            this.tb_Judgment.Controls.Add(this.cb_Comparison1);
            this.tb_Judgment.Controls.Add(this.lable);
            this.tb_Judgment.Location = new System.Drawing.Point(4, 22);
            this.tb_Judgment.Name = "tb_Judgment";
            this.tb_Judgment.Padding = new System.Windows.Forms.Padding(3);
            this.tb_Judgment.Size = new System.Drawing.Size(442, 426);
            this.tb_Judgment.TabIndex = 0;
            this.tb_Judgment.Text = "Judgement";
            this.tb_Judgment.UseVisualStyleBackColor = true;
            // 
            // nud_Creteria4_
            // 
            this.nud_Creteria4_.DecimalPlaces = 2;
            this.nud_Creteria4_.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Creteria4_.Location = new System.Drawing.Point(241, 346);
            this.nud_Creteria4_.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nud_Creteria4_.Minimum = new decimal(new int[] {
            1410065408,
            2,
            0,
            -2147483648});
            this.nud_Creteria4_.Name = "nud_Creteria4_";
            this.nud_Creteria4_.Size = new System.Drawing.Size(72, 20);
            this.nud_Creteria4_.TabIndex = 54;
            this.nud_Creteria4_.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Creteria4_.Visible = false;
            // 
            // nud_Creteria4
            // 
            this.nud_Creteria4.DecimalPlaces = 2;
            this.nud_Creteria4.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Creteria4.Location = new System.Drawing.Point(241, 319);
            this.nud_Creteria4.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nud_Creteria4.Minimum = new decimal(new int[] {
            1410065408,
            2,
            0,
            -2147483648});
            this.nud_Creteria4.Name = "nud_Creteria4";
            this.nud_Creteria4.Size = new System.Drawing.Size(72, 20);
            this.nud_Creteria4.TabIndex = 55;
            this.nud_Creteria4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(82, 387);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 13);
            this.label13.TabIndex = 50;
            this.label13.Text = "Output Value : ";
            // 
            // lb_Output4
            // 
            this.lb_Output4.AutoSize = true;
            this.lb_Output4.Location = new System.Drawing.Point(171, 387);
            this.lb_Output4.Name = "lb_Output4";
            this.lb_Output4.Size = new System.Drawing.Size(34, 13);
            this.lb_Output4.TabIndex = 51;
            this.lb_Output4.Text = "Value";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(82, 365);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 13);
            this.label15.TabIndex = 52;
            this.label15.Text = "Input Value : ";
            // 
            // lb_Input4
            // 
            this.lb_Input4.AutoSize = true;
            this.lb_Input4.Location = new System.Drawing.Point(171, 365);
            this.lb_Input4.Name = "lb_Input4";
            this.lb_Input4.Size = new System.Drawing.Size(34, 13);
            this.lb_Input4.TabIndex = 53;
            this.lb_Input4.Text = "Value";
            // 
            // cb_Comparison4
            // 
            this.cb_Comparison4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Comparison4.FormattingEnabled = true;
            this.cb_Comparison4.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cb_Comparison4.Location = new System.Drawing.Point(130, 318);
            this.cb_Comparison4.Name = "cb_Comparison4";
            this.cb_Comparison4.Size = new System.Drawing.Size(96, 21);
            this.cb_Comparison4.TabIndex = 48;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(82, 321);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(34, 13);
            this.label17.TabIndex = 49;
            this.label17.Text = "Value";
            // 
            // nud_Creteria3_
            // 
            this.nud_Creteria3_.DecimalPlaces = 2;
            this.nud_Creteria3_.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Creteria3_.Location = new System.Drawing.Point(241, 246);
            this.nud_Creteria3_.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nud_Creteria3_.Minimum = new decimal(new int[] {
            1410065408,
            2,
            0,
            -2147483648});
            this.nud_Creteria3_.Name = "nud_Creteria3_";
            this.nud_Creteria3_.Size = new System.Drawing.Size(72, 20);
            this.nud_Creteria3_.TabIndex = 46;
            this.nud_Creteria3_.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Creteria3_.Visible = false;
            // 
            // nud_Creteria3
            // 
            this.nud_Creteria3.DecimalPlaces = 2;
            this.nud_Creteria3.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Creteria3.Location = new System.Drawing.Point(241, 219);
            this.nud_Creteria3.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nud_Creteria3.Minimum = new decimal(new int[] {
            1410065408,
            2,
            0,
            -2147483648});
            this.nud_Creteria3.Name = "nud_Creteria3";
            this.nud_Creteria3.Size = new System.Drawing.Size(72, 20);
            this.nud_Creteria3.TabIndex = 47;
            this.nud_Creteria3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(82, 287);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Output Value : ";
            // 
            // lb_Output3
            // 
            this.lb_Output3.AutoSize = true;
            this.lb_Output3.Location = new System.Drawing.Point(171, 287);
            this.lb_Output3.Name = "lb_Output3";
            this.lb_Output3.Size = new System.Drawing.Size(34, 13);
            this.lb_Output3.TabIndex = 43;
            this.lb_Output3.Text = "Value";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(82, 265);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 13);
            this.label10.TabIndex = 44;
            this.label10.Text = "Input Value : ";
            // 
            // lb_Input3
            // 
            this.lb_Input3.AutoSize = true;
            this.lb_Input3.Location = new System.Drawing.Point(171, 265);
            this.lb_Input3.Name = "lb_Input3";
            this.lb_Input3.Size = new System.Drawing.Size(34, 13);
            this.lb_Input3.TabIndex = 45;
            this.lb_Input3.Text = "Value";
            // 
            // cb_Comparison3
            // 
            this.cb_Comparison3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Comparison3.FormattingEnabled = true;
            this.cb_Comparison3.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cb_Comparison3.Location = new System.Drawing.Point(130, 218);
            this.cb_Comparison3.Name = "cb_Comparison3";
            this.cb_Comparison3.Size = new System.Drawing.Size(96, 21);
            this.cb_Comparison3.TabIndex = 40;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(82, 221);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 41;
            this.label12.Text = "Value";
            // 
            // nud_Creteria2_
            // 
            this.nud_Creteria2_.DecimalPlaces = 2;
            this.nud_Creteria2_.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Creteria2_.Location = new System.Drawing.Point(241, 139);
            this.nud_Creteria2_.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nud_Creteria2_.Minimum = new decimal(new int[] {
            1410065408,
            2,
            0,
            -2147483648});
            this.nud_Creteria2_.Name = "nud_Creteria2_";
            this.nud_Creteria2_.Size = new System.Drawing.Size(72, 20);
            this.nud_Creteria2_.TabIndex = 38;
            this.nud_Creteria2_.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Creteria2_.Visible = false;
            // 
            // nud_Creteria2
            // 
            this.nud_Creteria2.DecimalPlaces = 2;
            this.nud_Creteria2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Creteria2.Location = new System.Drawing.Point(241, 112);
            this.nud_Creteria2.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nud_Creteria2.Minimum = new decimal(new int[] {
            1410065408,
            2,
            0,
            -2147483648});
            this.nud_Creteria2.Name = "nud_Creteria2";
            this.nud_Creteria2.Size = new System.Drawing.Size(72, 20);
            this.nud_Creteria2.TabIndex = 39;
            this.nud_Creteria2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(82, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "Output Value : ";
            // 
            // lb_Output2
            // 
            this.lb_Output2.AutoSize = true;
            this.lb_Output2.Location = new System.Drawing.Point(171, 180);
            this.lb_Output2.Name = "lb_Output2";
            this.lb_Output2.Size = new System.Drawing.Size(34, 13);
            this.lb_Output2.TabIndex = 35;
            this.lb_Output2.Text = "Value";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(82, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 36;
            this.label5.Text = "Input Value : ";
            // 
            // lb_Input2
            // 
            this.lb_Input2.AutoSize = true;
            this.lb_Input2.Location = new System.Drawing.Point(171, 158);
            this.lb_Input2.Name = "lb_Input2";
            this.lb_Input2.Size = new System.Drawing.Size(34, 13);
            this.lb_Input2.TabIndex = 37;
            this.lb_Input2.Text = "Value";
            // 
            // cb_Comparison2
            // 
            this.cb_Comparison2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Comparison2.FormattingEnabled = true;
            this.cb_Comparison2.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cb_Comparison2.Location = new System.Drawing.Point(130, 111);
            this.cb_Comparison2.Name = "cb_Comparison2";
            this.cb_Comparison2.Size = new System.Drawing.Size(96, 21);
            this.cb_Comparison2.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(82, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 33;
            this.label7.Text = "Value";
            // 
            // nud_Creteria1_
            // 
            this.nud_Creteria1_.DecimalPlaces = 2;
            this.nud_Creteria1_.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Creteria1_.Location = new System.Drawing.Point(241, 43);
            this.nud_Creteria1_.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nud_Creteria1_.Minimum = new decimal(new int[] {
            1410065408,
            2,
            0,
            -2147483648});
            this.nud_Creteria1_.Name = "nud_Creteria1_";
            this.nud_Creteria1_.Size = new System.Drawing.Size(72, 20);
            this.nud_Creteria1_.TabIndex = 31;
            this.nud_Creteria1_.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Creteria1_.Visible = false;
            // 
            // nud_Creteria1
            // 
            this.nud_Creteria1.DecimalPlaces = 2;
            this.nud_Creteria1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_Creteria1.Location = new System.Drawing.Point(241, 16);
            this.nud_Creteria1.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.nud_Creteria1.Minimum = new decimal(new int[] {
            1410065408,
            2,
            0,
            -2147483648});
            this.nud_Creteria1.Name = "nud_Creteria1";
            this.nud_Creteria1.Size = new System.Drawing.Size(72, 20);
            this.nud_Creteria1.TabIndex = 31;
            this.nud_Creteria1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 30;
            this.label3.Text = "Output Value : ";
            // 
            // lb_Output1
            // 
            this.lb_Output1.AutoSize = true;
            this.lb_Output1.Location = new System.Drawing.Point(171, 84);
            this.lb_Output1.Name = "lb_Output1";
            this.lb_Output1.Size = new System.Drawing.Size(34, 13);
            this.lb_Output1.TabIndex = 30;
            this.lb_Output1.Text = "Value";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Input Value : ";
            // 
            // lb_Input1
            // 
            this.lb_Input1.AutoSize = true;
            this.lb_Input1.Location = new System.Drawing.Point(171, 62);
            this.lb_Input1.Name = "lb_Input1";
            this.lb_Input1.Size = new System.Drawing.Size(34, 13);
            this.lb_Input1.TabIndex = 30;
            this.lb_Input1.Text = "Value";
            // 
            // cb_Comparison1
            // 
            this.cb_Comparison1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Comparison1.FormattingEnabled = true;
            this.cb_Comparison1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.cb_Comparison1.Location = new System.Drawing.Point(130, 15);
            this.cb_Comparison1.Name = "cb_Comparison1";
            this.cb_Comparison1.Size = new System.Drawing.Size(96, 21);
            this.cb_Comparison1.TabIndex = 28;
            this.cb_Comparison1.SelectedIndexChanged += new System.EventHandler(this.Cb_Comparison1_SelectedValueChanged);
            // 
            // lable
            // 
            this.lable.AutoSize = true;
            this.lable.Location = new System.Drawing.Point(82, 18);
            this.lable.Name = "lable";
            this.lable.Size = new System.Drawing.Size(34, 13);
            this.lable.TabIndex = 29;
            this.lable.Text = "Value";
            // 
            // SvJudgementEditOverpocket
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "SvJudgementEditOverpocket";
            this.tabControl.ResumeLayout(false);
            this.tb_Judgment.ResumeLayout(false);
            this.tb_Judgment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria4_)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria3_)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria2_)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria1_)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Creteria1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tb_Judgment;
        private System.Windows.Forms.NumericUpDown nud_Creteria1;
        private System.Windows.Forms.Label lb_Input1;
        private System.Windows.Forms.ComboBox cb_Comparison1;
        private System.Windows.Forms.Label lable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_Output1;
        private System.Windows.Forms.NumericUpDown nud_Creteria1_;
        private System.Windows.Forms.NumericUpDown nud_Creteria4_;
        private System.Windows.Forms.NumericUpDown nud_Creteria4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lb_Output4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lb_Input4;
        private System.Windows.Forms.ComboBox cb_Comparison4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown nud_Creteria3_;
        private System.Windows.Forms.NumericUpDown nud_Creteria3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lb_Output3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lb_Input3;
        private System.Windows.Forms.ComboBox cb_Comparison3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown nud_Creteria2_;
        private System.Windows.Forms.NumericUpDown nud_Creteria2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_Output2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_Input2;
        private System.Windows.Forms.ComboBox cb_Comparison2;
        private System.Windows.Forms.Label label7;
    }
}
