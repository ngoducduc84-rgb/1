﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;

namespace MvCore.Edit
{
    public partial class MvMakeLatticeEdit : MvCore.Edit.Base.MvToolEditBase
    {
        public MvMakeLatticeEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvWarppingEdit_SubjectChanged;

            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            //this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_InDrawObjectChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_OutDrawObjectChanged;
        }

        protected override void InitDisplayViewEdit()
        {
            //if (outPointsImageInfo != null)
            //    outPointsImageInfo.Image.Dispose();
            
            //outPointsImageInfo = new SvImageInfo("[SubImage] OutputPoints");

            //SvDisplayViewEdit.InsertCustomImage(1, outPointsImageInfo);
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("Output"))
            {
                tabControl.SelectedTab = tb_Out_Pers;
                if (Subject == null || Subject.InputImage == null) return;
                if (cb_OutOption.SelectedValue == null)
                    cb_OutOption.SelectedValue = MvMakeLattice.Option.Perspective;

                SvDisplayViewEdit.Display.Image = Subject.OutputImage;

                if ((MvMakeLattice.Option)cb_OutOption.SelectedValue == MvMakeLattice.Option.Perspective)
                    SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.OutPLineObject);
                else
                    SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.OutRectObject);
                SvDisplayViewEdit.Display.GraphicsCollection.Add(Subject.OutputPoint);

                if (Subject.OutputPoint != null)
                    Subject.OutputPoint.Display = SvDisplayViewEdit.Display;
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvMakeLattice Subject
        {
            get { return base.GetSubject() as MvMakeLattice; }
            set { base.SetSubject(value); }
        }

        void SvWarppingEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
            if (Subject == null) return;         
            //Display_InDrawObjectChanged(this, Subject.InPLineObject);
            Display_OutDrawObjectChanged(this, Subject.OutPLineObject);
        }

        #region InputPoints Event

        //void Display_InDrawObjectChanged(object sender, IInteractDrawObject drawObject)
        //{
        //    if (Subject.InPLineObject == null) return;
        //    Remove_In_nud_ValueChangedEvent();

        //    nud_InP0_X.Value = (decimal)Subject.InPLineObject[0].X; nud_InP0_Y.Value = (decimal)Subject.InPLineObject[0].Y;
        //    nud_InP1_X.Value = (decimal)Subject.InPLineObject[1].X; nud_InP1_Y.Value = (decimal)Subject.InPLineObject[1].Y;
        //    nud_InP2_X.Value = (decimal)Subject.InPLineObject[2].X; nud_InP2_Y.Value = (decimal)Subject.InPLineObject[2].Y;
        //    nud_InP3_X.Value = (decimal)Subject.InPLineObject[3].X; nud_InP3_Y.Value = (decimal)Subject.InPLineObject[3].Y;
            
        //    Add_In_nud_ValueChangedEvent();
        //}

        //void Add_In_nud_ValueChangedEvent()
        //{
        //    nud_InP0_X.ValueChanged += nud_InputDrawPoint_ValueChanged; nud_InP0_Y.ValueChanged += nud_InputDrawPoint_ValueChanged;
        //    nud_InP1_X.ValueChanged += nud_InputDrawPoint_ValueChanged; nud_InP1_Y.ValueChanged += nud_InputDrawPoint_ValueChanged;
        //    nud_InP2_X.ValueChanged += nud_InputDrawPoint_ValueChanged; nud_InP2_Y.ValueChanged += nud_InputDrawPoint_ValueChanged;
        //    nud_InP3_X.ValueChanged += nud_InputDrawPoint_ValueChanged; nud_InP3_Y.ValueChanged += nud_InputDrawPoint_ValueChanged;
        //}

        //void Remove_In_nud_ValueChangedEvent()
        //{
        //    nud_InP0_X.ValueChanged -= nud_InputDrawPoint_ValueChanged; nud_InP0_Y.ValueChanged -= nud_InputDrawPoint_ValueChanged;
        //    nud_InP1_X.ValueChanged -= nud_InputDrawPoint_ValueChanged; nud_InP1_Y.ValueChanged -= nud_InputDrawPoint_ValueChanged;
        //    nud_InP2_X.ValueChanged -= nud_InputDrawPoint_ValueChanged; nud_InP2_Y.ValueChanged -= nud_InputDrawPoint_ValueChanged;
        //    nud_InP3_X.ValueChanged -= nud_InputDrawPoint_ValueChanged; nud_InP3_Y.ValueChanged -= nud_InputDrawPoint_ValueChanged;
        //}

        //private void nud_InputDrawPoint_ValueChanged(object sender, EventArgs e)
        //{
        //    if (Subject.InPLineObject == null) return;
        //    NumericUpDown nud = sender as NumericUpDown;

        //    if (nud == nud_InP0_X || nud == nud_InP0_Y)
        //    {
        //        Subject.InPLineObject[0] = new PointF((float)nud_InP0_X.Value, (float)nud_InP0_Y.Value);
        //    }
        //    else if (nud == nud_InP1_X || nud == nud_InP1_Y)
        //    {
        //        Subject.InPLineObject[1] = new PointF((float)nud_InP1_X.Value, (float)nud_InP1_Y.Value);
        //    }
        //    else if (nud == nud_InP2_X || nud == nud_InP2_Y)
        //    {
        //        Subject.InPLineObject[2] = new PointF((float)nud_InP2_X.Value, (float)nud_InP2_Y.Value);
        //    }
        //    else if (nud == nud_InP3_X || nud == nud_InP3_Y)
        //    {
        //        Subject.InPLineObject[3] = new PointF((float)nud_InP3_X.Value, (float)nud_InP3_Y.Value);
        //    }

        //    SvDisplayViewEdit.Display.Invalidate();
        //}

        #endregion

        #region OutputPoints Event

        void Display_OutDrawObjectChanged(object sender, InteractDrawObject drawObject)
        {
            if (Subject.OutPLineObject == null) return;
            Remove_Out_nud_ValueChangedEvent();

            nud_OutP0_X.Value = (decimal)Subject.OutPLineObject[0].X; nud_OutP0_Y.Value = (decimal)Subject.OutPLineObject[0].Y;
            nud_OutP1_X.Value = (decimal)Subject.OutPLineObject[1].X; nud_OutP1_Y.Value = (decimal)Subject.OutPLineObject[1].Y;
            nud_OutP2_X.Value = (decimal)Subject.OutPLineObject[2].X; nud_OutP2_Y.Value = (decimal)Subject.OutPLineObject[2].Y;
            nud_OutP3_X.Value = (decimal)Subject.OutPLineObject[3].X; nud_OutP3_Y.Value = (decimal)Subject.OutPLineObject[3].Y;

            Add_Out_nud_ValueChangedEvent();
        }

        void Add_Out_nud_ValueChangedEvent()
        {
            nud_OutP0_X.ValueChanged += nud_OutputDrawPoint_ValueChanged; nud_OutP0_Y.ValueChanged += nud_OutputDrawPoint_ValueChanged;
            nud_OutP1_X.ValueChanged += nud_OutputDrawPoint_ValueChanged; nud_OutP1_Y.ValueChanged += nud_OutputDrawPoint_ValueChanged;
            nud_OutP2_X.ValueChanged += nud_OutputDrawPoint_ValueChanged; nud_OutP2_Y.ValueChanged += nud_OutputDrawPoint_ValueChanged;
            nud_OutP3_X.ValueChanged += nud_OutputDrawPoint_ValueChanged; nud_OutP3_Y.ValueChanged += nud_OutputDrawPoint_ValueChanged;
        }

        void Remove_Out_nud_ValueChangedEvent()
        {
            nud_OutP0_X.ValueChanged -= nud_OutputDrawPoint_ValueChanged; nud_OutP0_Y.ValueChanged -= nud_OutputDrawPoint_ValueChanged;
            nud_OutP1_X.ValueChanged -= nud_OutputDrawPoint_ValueChanged; nud_OutP1_Y.ValueChanged -= nud_OutputDrawPoint_ValueChanged;
            nud_OutP2_X.ValueChanged -= nud_OutputDrawPoint_ValueChanged; nud_OutP2_Y.ValueChanged -= nud_OutputDrawPoint_ValueChanged;
            nud_OutP3_X.ValueChanged -= nud_OutputDrawPoint_ValueChanged; nud_OutP3_Y.ValueChanged -= nud_OutputDrawPoint_ValueChanged;
        }

        private void nud_OutputDrawPoint_ValueChanged(object sender, EventArgs e)
        {
            if (Subject.OutPLineObject == null) return;
            NumericUpDown nud = sender as NumericUpDown;

            MvPolyLine plinetemp = Subject.OutPLineObject;
            if (nud == nud_OutP0_X || nud == nud_OutP0_Y)
            {
                if ((MvMakeLattice.Option)cb_OutOption.SelectedValue == MvMakeLattice.Option.Rectangle)
                {
                    if (nud_OutP3_X.Value != nud_OutP0_X.Value) nud_OutP3_X.Value = nud_OutP0_X.Value;
                    if (nud_OutP1_Y.Value != nud_OutP0_Y.Value) nud_OutP1_Y.Value = nud_OutP0_Y.Value;
                }
                plinetemp[0] = new PointF((float)nud_OutP0_X.Value, (float)nud_OutP0_Y.Value);
            }
            else if (nud == nud_OutP1_X || nud == nud_OutP1_Y)
            {
                if ((MvMakeLattice.Option)cb_OutOption.SelectedValue == MvMakeLattice.Option.Rectangle)
                {
                    if (nud_OutP2_X.Value != nud_OutP1_X.Value) nud_OutP2_X.Value = nud_OutP1_X.Value;
                    if (nud_OutP0_Y.Value != nud_OutP1_Y.Value) nud_OutP0_Y.Value = nud_OutP1_Y.Value;
                }
                plinetemp[1] = new PointF((float)nud_OutP1_X.Value, (float)nud_OutP1_Y.Value);
            }
            else if (nud == nud_OutP2_X || nud == nud_OutP2_Y)
            {
                if ((MvMakeLattice.Option)cb_OutOption.SelectedValue == MvMakeLattice.Option.Rectangle)
                {
                    if (nud_OutP1_X.Value != nud_OutP2_X.Value) nud_OutP1_X.Value = nud_OutP2_X.Value;
                    if (nud_OutP3_Y.Value != nud_OutP2_Y.Value) nud_OutP3_Y.Value = nud_OutP2_Y.Value;
                }
                plinetemp[2] = new PointF((float)nud_OutP2_X.Value, (float)nud_OutP2_Y.Value);
            }
            else if (nud == nud_OutP3_X || nud == nud_OutP3_Y)
            {
                if ((MvMakeLattice.Option)cb_OutOption.SelectedValue == MvMakeLattice.Option.Rectangle)
                {
                    if (nud_OutP0_X.Value != nud_OutP3_X.Value) nud_OutP0_X.Value = nud_OutP3_X.Value;
                    if (nud_OutP2_Y.Value != nud_OutP3_Y.Value) nud_OutP2_Y.Value = nud_OutP3_Y.Value;
                }
                plinetemp[3] = new PointF((float)nud_OutP3_X.Value, (float)nud_OutP3_Y.Value);
            }
            Subject.OutPLineObject = plinetemp;
            SvDisplayViewEdit.Display.Invalidate();
        }       

        #endregion
        
        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvMakeLattice), null);
            cb_OutOption.DisplayMember = "Key"; cb_OutOption.ValueMember = "Value";
            cb_OutOption.DataSource = Enum.GetValues(typeof(MvMakeLattice.Option)).Cast<MvMakeLattice.Option>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_OutOption.DataBindings.Add("SelectedValue", source, "OutOption", true, DataSourceUpdateMode.OnPropertyChanged);
            
        }

        SvImageInfo inPointsImageInfo;
        SvImageInfo outPointsImageInfo;

        private void cb_OutOption_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Subject == null || Subject.OutputPoint == null) return;

            SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Clear();
            if ((MvMakeLattice.Option)cb_OutOption.SelectedValue == MvMakeLattice.Option.Perspective)
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.OutPLineObject);
            else
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.OutRectObject);

            SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.OutputPoint);
            Subject.OutputPoint.Display = SvDisplayViewEdit.Display;
            Display_OutDrawObjectChanged(this, null);
        }

        //private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    TabControl send = sender as TabControl;
        //    if (send.SelectedTab == tb_In_Pers)
        //        SvDisplayViewEdit.imageListComboBox.SelectedItem = Subject.imageList[0];
        //    else
        //        SvDisplayViewEdit.imageListComboBox.SelectedItem = Subject.imageList[1];
        //}

        //private void btn_ResetInQuad_Click(object sender, EventArgs e)
        //{
        //    if (Subject.InputImage == null) return;
        //    nud_InP0_X.Value = 0; nud_InP0_Y.Value = 0;
        //    nud_InP1_X.Value = (decimal)Subject.InputImage.Width; nud_InP1_Y.Value = 0;
        //    nud_InP2_X.Value = (decimal)Subject.InputImage.Width; nud_InP2_Y.Value = (decimal)Subject.InputImage.Height;
        //    nud_InP3_X.Value = 0; nud_InP3_Y.Value = (decimal)Subject.InputImage.Height;
        //}

        private void btn_ResetOutQuad_Click(object sender, EventArgs e)
        {
            if (Subject.InputImage == null) return;
            nud_OutP0_X.Value = 0; nud_OutP0_Y.Value = 0;
            nud_OutP1_X.Value = (decimal)Subject.InputImage.Width; nud_OutP1_Y.Value = 0;
            nud_OutP2_X.Value = (decimal)Subject.InputImage.Width; nud_OutP2_Y.Value = (decimal)Subject.InputImage.Height;
            nud_OutP3_X.Value = 0; nud_OutP3_Y.Value = (decimal)Subject.InputImage.Height;

        }

    }
}
