﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;
using OpenCvSharp;

namespace MvCore.Edit
{
    public partial class MvManualCalibrationEdit : MvToolEditBase
    {
        public MvManualCalibrationEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvCameraCalibrationEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }

        private void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject)
        {
            if (drawObject is MvPoint)
            {
                MvPoint _Point = drawObject as MvPoint;
                Origin = _Point;
                NotifyPropertyChanged("Origin");
                svDisplayViewEdit.Refresh(); //Refresh draw image
            }
        }

        private void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("CornerImage"))
            {
                if (Subject != null)
                {
                    //this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.Origin);
                }
            }
        }
        private void nud_ValueChanged(object sender, EventArgs e)
        {
            if (lockPoint == false)
            {
                NotifyPropertyChanged("Origin");
                svDisplayViewEdit.Refresh(); //Refresh draw image
              
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvManualCalibration Subject
        {
            get { return base.GetSubject() as MvManualCalibration; }
            set { base.SetSubject(value); }
        }

        void SvCameraCalibrationEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvManualCalibration), null);

            nud_Calibration_Count.DataBindings.Add("Value", source, "ImageNum", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Calibration_ChessHeight.DataBindings.Add("Value", source, "ChessHeight", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Calibration_ChessWidth.DataBindings.Add("Value", source, "ChessWidth", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Calibration_ChessSize.DataBindings.Add("Value", source, "ChessSize", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_Distortion_K1.DataBindings.Add("Value", source, "K1", true, DataSourceUpdateMode.Never);
            nud_Distortion_K2.DataBindings.Add("Value", source, "K2", true, DataSourceUpdateMode.Never);
            nud_Distortion_K3.DataBindings.Add("Value", source, "K3", true, DataSourceUpdateMode.Never);
            nud_Distortion_P1.DataBindings.Add("Value", source, "P1", true, DataSourceUpdateMode.Never);
            nud_Distortion_P2.DataBindings.Add("Value", source, "P2", true, DataSourceUpdateMode.Never);

            nud_Camera_FX.DataBindings.Add("Value", source, "FX", true, DataSourceUpdateMode.Never);
            nud_Camera_FY.DataBindings.Add("Value", source, "FY", true, DataSourceUpdateMode.Never);
            nud_Camera_CX.DataBindings.Add("Value", source, "CX", true, DataSourceUpdateMode.Never);
            nud_Camera_CY.DataBindings.Add("Value", source, "CY", true, DataSourceUpdateMode.Never);
            //DataBindings.Add("Origin", source, "Origin", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void btn_CalibrationParam_Make_Click(object sender, EventArgs e)
        {
            Subject.runCalibration();
            SvDisplayViewEdit.RefreshImage();
        }

        private void btn_CalibrationParam_Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Calibration files (*.xml)|*.xml|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.DefaultExt = "*.xml";
            fd.InitialDirectory = PATH_CALIB;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            bool success = Subject.saveCameraParams(fd.FileName);

            if (!success)
            {
                MessageBox.Show("Calibration file save fail");
                return;
            }            
        }

        private void btn_CalibrationParam_Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Calibration files (*.xml)|*.xml|All files (*.*)|*.*";
            fd.FilterIndex = 1;
            fd.Multiselect = false;
            fd.InitialDirectory = PATH_CALIB;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            bool success = Subject.loadCameraParams(fd.FileName);

            if (!success)
            {
                MessageBox.Show("Calibration file load fail");
                return;
            }
        }
        bool lockPoint = false;
        private MvPoint origin;
        public MvPoint Origin
        {
            get
            {
                origin.X = (float)nud_PoinA_X.Value;
                origin.Y = (float)nud_PoinA_Y.Value;
                return origin;
            }
            set
            {

                lockPoint = true;
                origin = value;
                nud_PoinA_X.Value = (decimal)value.X;
                nud_PoinA_Y.Value = (decimal)value.Y;
                lockPoint = false;

            }
        }
    }
}
