﻿namespace MvCore.Edit
{
    partial class MvMaskingEdit
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_Masking = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.nud_PenSize = new System.Windows.Forms.NumericUpDown();
            this.btn_MaskReset = new System.Windows.Forms.Button();
            this.btn_Fill = new System.Windows.Forms.Button();
            this.cb_PenType = new System.Windows.Forms.ComboBox();
            this.chb_DrawOnOff = new System.Windows.Forms.CheckBox();
            this.tabControl.SuspendLayout();
            this.tp_Masking.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PenSize)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Masking);
            // 
            // tp_Masking
            // 
            this.tp_Masking.Controls.Add(this.groupBox2);
            this.tp_Masking.Location = new System.Drawing.Point(4, 22);
            this.tp_Masking.Name = "tp_Masking";
            this.tp_Masking.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Masking.Size = new System.Drawing.Size(442, 426);
            this.tp_Masking.TabIndex = 1;
            this.tp_Masking.Text = "Masking";
            this.tp_Masking.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.nud_PenSize);
            this.groupBox2.Controls.Add(this.btn_MaskReset);
            this.groupBox2.Controls.Add(this.btn_Fill);
            this.groupBox2.Controls.Add(this.cb_PenType);
            this.groupBox2.Controls.Add(this.chb_DrawOnOff);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(430, 192);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(301, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 12);
            this.label1.TabIndex = 46;
            this.label1.Text = "Line Size";
            // 
            // nud_PenSize
            // 
            this.nud_PenSize.Location = new System.Drawing.Point(365, 24);
            this.nud_PenSize.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_PenSize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_PenSize.Name = "nud_PenSize";
            this.nud_PenSize.Size = new System.Drawing.Size(48, 21);
            this.nud_PenSize.TabIndex = 45;
            this.nud_PenSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.nud_PenSize.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.nud_PenSize.ValueChanged += new System.EventHandler(this.nud_PenSize_ValueChanged);
            // 
            // btn_MaskReset
            // 
            this.btn_MaskReset.Location = new System.Drawing.Point(277, 61);
            this.btn_MaskReset.Name = "btn_MaskReset";
            this.btn_MaskReset.Size = new System.Drawing.Size(124, 32);
            this.btn_MaskReset.TabIndex = 44;
            this.btn_MaskReset.Text = "Mask Reset";
            this.btn_MaskReset.UseVisualStyleBackColor = true;
            this.btn_MaskReset.Click += new System.EventHandler(this.btn_MaskReset_Click);
            // 
            // btn_Fill
            // 
            this.btn_Fill.Location = new System.Drawing.Point(147, 61);
            this.btn_Fill.Name = "btn_Fill";
            this.btn_Fill.Size = new System.Drawing.Size(124, 32);
            this.btn_Fill.TabIndex = 44;
            this.btn_Fill.Text = "Fill";
            this.btn_Fill.UseVisualStyleBackColor = true;
            this.btn_Fill.Click += new System.EventHandler(this.btn_Fill_Click);
            // 
            // cb_PenType
            // 
            this.cb_PenType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_PenType.FormattingEnabled = true;
            this.cb_PenType.Location = new System.Drawing.Point(17, 24);
            this.cb_PenType.Name = "cb_PenType";
            this.cb_PenType.Size = new System.Drawing.Size(257, 20);
            this.cb_PenType.TabIndex = 43;
            this.cb_PenType.SelectedIndexChanged += new System.EventHandler(this.cb_PenType_SelectedIndexChanged);
            // 
            // chb_DrawOnOff
            // 
            this.chb_DrawOnOff.Appearance = System.Windows.Forms.Appearance.Button;
            this.chb_DrawOnOff.Location = new System.Drawing.Point(17, 61);
            this.chb_DrawOnOff.Name = "chb_DrawOnOff";
            this.chb_DrawOnOff.Size = new System.Drawing.Size(124, 32);
            this.chb_DrawOnOff.TabIndex = 42;
            this.chb_DrawOnOff.Text = "Mask On";
            this.chb_DrawOnOff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chb_DrawOnOff.UseVisualStyleBackColor = true;
            this.chb_DrawOnOff.CheckedChanged += new System.EventHandler(this.chb_DrawOnOff_CheckedChanged);
            // 
            // SvMaskingEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.Name = "SvMaskingEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Masking.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_PenSize)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Masking;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_Fill;
        private System.Windows.Forms.ComboBox cb_PenType;
        private System.Windows.Forms.CheckBox chb_DrawOnOff;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nud_PenSize;
        private System.Windows.Forms.Button btn_MaskReset;
    }
}
