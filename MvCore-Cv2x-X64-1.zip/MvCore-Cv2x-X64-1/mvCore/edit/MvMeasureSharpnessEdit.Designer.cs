﻿namespace MvCore.Edit
{
    partial class MvMeasureSharpnessEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            this.tp_ImgCal = new System.Windows.Forms.TabPage();
            this.nud_MaxPrewitCount = new System.Windows.Forms.NumericUpDown();
            this.lbl_MaxPrewittCount = new System.Windows.Forms.Label();
            this.lv_Msharpness = new System.Windows.Forms.ListView();
            this.Prewitt1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Prewitt2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Prewitt3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabControl.SuspendLayout();
            this.tp_ImgCal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MaxPrewitCount)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_ImgCal);
            // 
            // tp_ImgCal
            // 
            this.tp_ImgCal.Controls.Add(this.nud_MaxPrewitCount);
            this.tp_ImgCal.Controls.Add(this.lbl_MaxPrewittCount);
            this.tp_ImgCal.Controls.Add(this.lv_Msharpness);
            this.tp_ImgCal.Location = new System.Drawing.Point(4, 25);
            this.tp_ImgCal.Name = "tp_ImgCal";
            this.tp_ImgCal.Padding = new System.Windows.Forms.Padding(3);
            this.tp_ImgCal.Size = new System.Drawing.Size(442, 423);
            this.tp_ImgCal.TabIndex = 0;
            this.tp_ImgCal.Text = "ImageCalculate";
            this.tp_ImgCal.UseVisualStyleBackColor = true;
            // 
            // nud_MaxPrewitCount
            // 
            this.nud_MaxPrewitCount.Location = new System.Drawing.Point(188, 15);
            this.nud_MaxPrewitCount.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nud_MaxPrewitCount.Name = "nud_MaxPrewitCount";
            this.nud_MaxPrewitCount.Size = new System.Drawing.Size(80, 25);
            this.nud_MaxPrewitCount.TabIndex = 5;
            // 
            // lbl_MaxPrewittCount
            // 
            this.lbl_MaxPrewittCount.AutoSize = true;
            this.lbl_MaxPrewittCount.Location = new System.Drawing.Point(30, 21);
            this.lbl_MaxPrewittCount.Name = "lbl_MaxPrewittCount";
            this.lbl_MaxPrewittCount.Size = new System.Drawing.Size(128, 15);
            this.lbl_MaxPrewittCount.TabIndex = 4;
            this.lbl_MaxPrewittCount.Text = "Max Prewitt Count";
            // 
            // lv_Msharpness
            // 
            this.lv_Msharpness.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lv_Msharpness.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Prewitt1,
            this.Prewitt2,
            this.Prewitt3});
            this.lv_Msharpness.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.lv_Msharpness.Location = new System.Drawing.Point(24, 53);
            this.lv_Msharpness.Name = "lv_Msharpness";
            this.lv_Msharpness.Size = new System.Drawing.Size(382, 332);
            this.lv_Msharpness.TabIndex = 3;
            this.lv_Msharpness.UseCompatibleStateImageBehavior = false;
            this.lv_Msharpness.View = System.Windows.Forms.View.Details;
            // 
            // Prewitt1
            // 
            this.Prewitt1.Width = 115;
            // 
            // Prewitt2
            // 
            this.Prewitt2.Width = 115;
            // 
            // Prewitt3
            // 
            this.Prewitt3.Width = 115;
            // 
            // SvMeasureSharpnessEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "SvMeasureSharpnessEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_ImgCal.ResumeLayout(false);
            this.tp_ImgCal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_MaxPrewitCount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_ImgCal;
        private System.Windows.Forms.ListView lv_Msharpness;
        private System.Windows.Forms.ColumnHeader Prewitt1;
        private System.Windows.Forms.ColumnHeader Prewitt2;
        private System.Windows.Forms.ColumnHeader Prewitt3;
        private System.Windows.Forms.NumericUpDown nud_MaxPrewitCount;
        private System.Windows.Forms.Label lbl_MaxPrewittCount;
    }
}
