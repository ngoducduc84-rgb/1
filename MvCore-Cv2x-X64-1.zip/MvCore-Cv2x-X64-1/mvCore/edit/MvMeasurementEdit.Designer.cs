﻿namespace MvCore.Edit
{
    partial class MvMeasurementEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.tp_Setting = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.nud_Ellipse_BH = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.nud_Ellipse_BW = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.nud_Ellipse_BX = new System.Windows.Forms.NumericUpDown();
            this.nud_Ellipse_BY = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.nud_Ellipse_AH = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.nud_Ellipse_AW = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.nud_Ellipse_AX = new System.Windows.Forms.NumericUpDown();
            this.nud_Ellipse_AY = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.nud_Circle_BR = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.nud_Circle_BX = new System.Windows.Forms.NumericUpDown();
            this.nud_Circle_BY = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.nud_Circle_AR = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.nud_Circle_AX = new System.Windows.Forms.NumericUpDown();
            this.nud_Circle_AY = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.nud_Point_BX = new System.Windows.Forms.NumericUpDown();
            this.nud_Point_BY = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nud_Point_AX = new System.Windows.Forms.NumericUpDown();
            this.nud_Point_AY = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cb_mode = new System.Windows.Forms.ComboBox();
            this.nud_CreateLine_Angle = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nud_Line_AR = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nud_Line_AX = new System.Windows.Forms.NumericUpDown();
            this.nud_Line_AY = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_Line_BR = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.nud_Line_BY = new System.Windows.Forms.NumericUpDown();
            this.nud_Line_BX = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.nud_Line_AL = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.nud_Line_BL = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.nud_Ellipse_AR = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.nud_Ellipse_BR = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tp_Setting.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BY)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AY)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_BR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_BX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_BY)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_AR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_AX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_AY)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Point_BX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Point_BY)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Point_AX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Point_AY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CreateLine_Angle)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_AR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_AX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_AY)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_BR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_BY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_BX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_AL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_BL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BR)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Setting);
            // 
            // tp_Setting
            // 
            this.tp_Setting.Controls.Add(this.groupBox8);
            this.tp_Setting.Controls.Add(this.groupBox7);
            this.tp_Setting.Controls.Add(this.groupBox6);
            this.tp_Setting.Controls.Add(this.groupBox5);
            this.tp_Setting.Controls.Add(this.groupBox4);
            this.tp_Setting.Controls.Add(this.groupBox3);
            this.tp_Setting.Controls.Add(this.label3);
            this.tp_Setting.Controls.Add(this.cb_mode);
            this.tp_Setting.Controls.Add(this.nud_CreateLine_Angle);
            this.tp_Setting.Controls.Add(this.label2);
            this.tp_Setting.Controls.Add(this.groupBox2);
            this.tp_Setting.Controls.Add(this.groupBox1);
            this.tp_Setting.Location = new System.Drawing.Point(4, 22);
            this.tp_Setting.Name = "tp_Setting";
            this.tp_Setting.Size = new System.Drawing.Size(442, 426);
            this.tp_Setting.TabIndex = 0;
            this.tp_Setting.Text = "Setting";
            this.tp_Setting.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.nud_Ellipse_BR);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.nud_Ellipse_BH);
            this.groupBox8.Controls.Add(this.label23);
            this.groupBox8.Controls.Add(this.nud_Ellipse_BW);
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.nud_Ellipse_BX);
            this.groupBox8.Controls.Add(this.nud_Ellipse_BY);
            this.groupBox8.Controls.Add(this.label25);
            this.groupBox8.Controls.Add(this.label26);
            this.groupBox8.Location = new System.Drawing.Point(157, 275);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(134, 151);
            this.groupBox8.TabIndex = 35;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Elipse A";
            // 
            // nud_Ellipse_BH
            // 
            this.nud_Ellipse_BH.DecimalPlaces = 3;
            this.nud_Ellipse_BH.Location = new System.Drawing.Point(65, 93);
            this.nud_Ellipse_BH.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_BH.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_BH.Name = "nud_Ellipse_BH";
            this.nud_Ellipse_BH.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_BH.TabIndex = 34;
            this.nud_Ellipse_BH.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_BH.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(33, 95);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(21, 13);
            this.label23.TabIndex = 33;
            this.label23.Text = "H: ";
            // 
            // nud_Ellipse_BW
            // 
            this.nud_Ellipse_BW.DecimalPlaces = 3;
            this.nud_Ellipse_BW.Location = new System.Drawing.Point(65, 67);
            this.nud_Ellipse_BW.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_BW.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_BW.Name = "nud_Ellipse_BW";
            this.nud_Ellipse_BW.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_BW.TabIndex = 32;
            this.nud_Ellipse_BW.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_BW.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(33, 69);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(24, 13);
            this.label24.TabIndex = 31;
            this.label24.Text = "W: ";
            // 
            // nud_Ellipse_BX
            // 
            this.nud_Ellipse_BX.DecimalPlaces = 3;
            this.nud_Ellipse_BX.Location = new System.Drawing.Point(66, 17);
            this.nud_Ellipse_BX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_BX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_BX.Name = "nud_Ellipse_BX";
            this.nud_Ellipse_BX.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_BX.TabIndex = 27;
            this.nud_Ellipse_BX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_BX.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_Ellipse_BY
            // 
            this.nud_Ellipse_BY.DecimalPlaces = 3;
            this.nud_Ellipse_BY.Location = new System.Drawing.Point(66, 43);
            this.nud_Ellipse_BY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_BY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_BY.Name = "nud_Ellipse_BY";
            this.nud_Ellipse_BY.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_BY.TabIndex = 30;
            this.nud_Ellipse_BY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_BY.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(34, 19);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(20, 13);
            this.label25.TabIndex = 26;
            this.label25.Text = "X: ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(34, 45);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(20, 13);
            this.label26.TabIndex = 29;
            this.label26.Text = "Y: ";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.nud_Ellipse_AR);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.nud_Ellipse_AH);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.numericUpDown2);
            this.groupBox7.Controls.Add(this.nud_Ellipse_AW);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.nud_Ellipse_AX);
            this.groupBox7.Controls.Add(this.nud_Ellipse_AY);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Location = new System.Drawing.Point(5, 275);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(134, 148);
            this.groupBox7.TabIndex = 34;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Elipse A";
            // 
            // nud_Ellipse_AH
            // 
            this.nud_Ellipse_AH.DecimalPlaces = 3;
            this.nud_Ellipse_AH.Location = new System.Drawing.Point(65, 93);
            this.nud_Ellipse_AH.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_AH.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_AH.Name = "nud_Ellipse_AH";
            this.nud_Ellipse_AH.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_AH.TabIndex = 34;
            this.nud_Ellipse_AH.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_AH.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(33, 95);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(21, 13);
            this.label22.TabIndex = 33;
            this.label22.Text = "H: ";
            // 
            // nud_Ellipse_AW
            // 
            this.nud_Ellipse_AW.DecimalPlaces = 3;
            this.nud_Ellipse_AW.Location = new System.Drawing.Point(65, 67);
            this.nud_Ellipse_AW.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_AW.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_AW.Name = "nud_Ellipse_AW";
            this.nud_Ellipse_AW.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_AW.TabIndex = 32;
            this.nud_Ellipse_AW.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_AW.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(33, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(24, 13);
            this.label19.TabIndex = 31;
            this.label19.Text = "W: ";
            // 
            // nud_Ellipse_AX
            // 
            this.nud_Ellipse_AX.DecimalPlaces = 3;
            this.nud_Ellipse_AX.Location = new System.Drawing.Point(66, 17);
            this.nud_Ellipse_AX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_AX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_AX.Name = "nud_Ellipse_AX";
            this.nud_Ellipse_AX.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_AX.TabIndex = 27;
            this.nud_Ellipse_AX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_AX.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_Ellipse_AY
            // 
            this.nud_Ellipse_AY.DecimalPlaces = 3;
            this.nud_Ellipse_AY.Location = new System.Drawing.Point(66, 43);
            this.nud_Ellipse_AY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_AY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_AY.Name = "nud_Ellipse_AY";
            this.nud_Ellipse_AY.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_AY.TabIndex = 30;
            this.nud_Ellipse_AY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_AY.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(34, 19);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(20, 13);
            this.label20.TabIndex = 26;
            this.label20.Text = "X: ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(34, 45);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(20, 13);
            this.label21.TabIndex = 29;
            this.label21.Text = "Y: ";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.nud_Circle_BR);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.nud_Circle_BX);
            this.groupBox6.Controls.Add(this.nud_Circle_BY);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Location = new System.Drawing.Point(309, 136);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(134, 87);
            this.groupBox6.TabIndex = 34;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Circle B";
            this.groupBox6.Visible = false;
            // 
            // nud_Circle_BR
            // 
            this.nud_Circle_BR.DecimalPlaces = 3;
            this.nud_Circle_BR.Location = new System.Drawing.Point(65, 67);
            this.nud_Circle_BR.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Circle_BR.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Circle_BR.Name = "nud_Circle_BR";
            this.nud_Circle_BR.Size = new System.Drawing.Size(69, 20);
            this.nud_Circle_BR.TabIndex = 32;
            this.nud_Circle_BR.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Circle_BR.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(33, 69);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 13);
            this.label16.TabIndex = 31;
            this.label16.Text = "R: ";
            // 
            // nud_Circle_BX
            // 
            this.nud_Circle_BX.DecimalPlaces = 3;
            this.nud_Circle_BX.Location = new System.Drawing.Point(66, 17);
            this.nud_Circle_BX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Circle_BX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Circle_BX.Name = "nud_Circle_BX";
            this.nud_Circle_BX.Size = new System.Drawing.Size(69, 20);
            this.nud_Circle_BX.TabIndex = 27;
            this.nud_Circle_BX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Circle_BX.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_Circle_BY
            // 
            this.nud_Circle_BY.DecimalPlaces = 3;
            this.nud_Circle_BY.Location = new System.Drawing.Point(66, 43);
            this.nud_Circle_BY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Circle_BY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Circle_BY.Name = "nud_Circle_BY";
            this.nud_Circle_BY.Size = new System.Drawing.Size(69, 20);
            this.nud_Circle_BY.TabIndex = 30;
            this.nud_Circle_BY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Circle_BY.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(34, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(20, 13);
            this.label17.TabIndex = 26;
            this.label17.Text = "X: ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(34, 45);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 13);
            this.label18.TabIndex = 29;
            this.label18.Text = "Y: ";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.nud_Circle_AR);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.nud_Circle_AX);
            this.groupBox5.Controls.Add(this.nud_Circle_AY);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Location = new System.Drawing.Point(308, 39);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(134, 87);
            this.groupBox5.TabIndex = 33;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Circle A";
            this.groupBox5.Visible = false;
            // 
            // nud_Circle_AR
            // 
            this.nud_Circle_AR.DecimalPlaces = 3;
            this.nud_Circle_AR.Location = new System.Drawing.Point(65, 67);
            this.nud_Circle_AR.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Circle_AR.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Circle_AR.Name = "nud_Circle_AR";
            this.nud_Circle_AR.Size = new System.Drawing.Size(69, 20);
            this.nud_Circle_AR.TabIndex = 32;
            this.nud_Circle_AR.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Circle_AR.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(33, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 13);
            this.label13.TabIndex = 31;
            this.label13.Text = "R: ";
            // 
            // nud_Circle_AX
            // 
            this.nud_Circle_AX.DecimalPlaces = 3;
            this.nud_Circle_AX.Location = new System.Drawing.Point(66, 17);
            this.nud_Circle_AX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Circle_AX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Circle_AX.Name = "nud_Circle_AX";
            this.nud_Circle_AX.Size = new System.Drawing.Size(69, 20);
            this.nud_Circle_AX.TabIndex = 27;
            this.nud_Circle_AX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Circle_AX.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_Circle_AY
            // 
            this.nud_Circle_AY.DecimalPlaces = 3;
            this.nud_Circle_AY.Location = new System.Drawing.Point(66, 43);
            this.nud_Circle_AY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Circle_AY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Circle_AY.Name = "nud_Circle_AY";
            this.nud_Circle_AY.Size = new System.Drawing.Size(69, 20);
            this.nud_Circle_AY.TabIndex = 30;
            this.nud_Circle_AY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Circle_AY.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(34, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(20, 13);
            this.label14.TabIndex = 26;
            this.label14.Text = "X: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(34, 45);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(20, 13);
            this.label15.TabIndex = 29;
            this.label15.Text = "Y: ";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.nud_Point_BX);
            this.groupBox4.Controls.Add(this.nud_Point_BY);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Location = new System.Drawing.Point(158, 39);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(134, 76);
            this.groupBox4.TabIndex = 34;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Point B";
            // 
            // nud_Point_BX
            // 
            this.nud_Point_BX.DecimalPlaces = 3;
            this.nud_Point_BX.Location = new System.Drawing.Point(66, 17);
            this.nud_Point_BX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Point_BX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Point_BX.Name = "nud_Point_BX";
            this.nud_Point_BX.Size = new System.Drawing.Size(69, 20);
            this.nud_Point_BX.TabIndex = 27;
            this.nud_Point_BX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Point_BX.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_Point_BY
            // 
            this.nud_Point_BY.DecimalPlaces = 3;
            this.nud_Point_BY.Location = new System.Drawing.Point(66, 43);
            this.nud_Point_BY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Point_BY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Point_BY.Name = "nud_Point_BY";
            this.nud_Point_BY.Size = new System.Drawing.Size(69, 20);
            this.nud_Point_BY.TabIndex = 30;
            this.nud_Point_BY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Point_BY.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "X: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(34, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(20, 13);
            this.label12.TabIndex = 29;
            this.label12.Text = "Y: ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.nud_Point_AX);
            this.groupBox3.Controls.Add(this.nud_Point_AY);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(6, 39);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(134, 76);
            this.groupBox3.TabIndex = 33;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Point A";
            // 
            // nud_Point_AX
            // 
            this.nud_Point_AX.DecimalPlaces = 3;
            this.nud_Point_AX.Location = new System.Drawing.Point(66, 17);
            this.nud_Point_AX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Point_AX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Point_AX.Name = "nud_Point_AX";
            this.nud_Point_AX.Size = new System.Drawing.Size(69, 20);
            this.nud_Point_AX.TabIndex = 27;
            this.nud_Point_AX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Point_AX.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_Point_AY
            // 
            this.nud_Point_AY.DecimalPlaces = 3;
            this.nud_Point_AY.Location = new System.Drawing.Point(66, 43);
            this.nud_Point_AY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Point_AY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Point_AY.Name = "nud_Point_AY";
            this.nud_Point_AY.Size = new System.Drawing.Size(69, 20);
            this.nud_Point_AY.TabIndex = 30;
            this.nud_Point_AY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Point_AY.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(34, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "X: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(34, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 13);
            this.label11.TabIndex = 29;
            this.label11.Text = "Y: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(268, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "Mode: ";
            // 
            // cb_mode
            // 
            this.cb_mode.FormattingEnabled = true;
            this.cb_mode.Location = new System.Drawing.Point(314, 3);
            this.cb_mode.Name = "cb_mode";
            this.cb_mode.Size = new System.Drawing.Size(125, 21);
            this.cb_mode.TabIndex = 32;
            // 
            // nud_CreateLine_Angle
            // 
            this.nud_CreateLine_Angle.DecimalPlaces = 3;
            this.nud_CreateLine_Angle.Location = new System.Drawing.Point(184, 3);
            this.nud_CreateLine_Angle.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_CreateLine_Angle.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_CreateLine_Angle.Name = "nud_CreateLine_Angle";
            this.nud_CreateLine_Angle.Size = new System.Drawing.Size(69, 20);
            this.nud_CreateLine_Angle.TabIndex = 26;
            this.nud_CreateLine_Angle.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "Angle: ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nud_Line_AL);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.nud_Line_AR);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.nud_Line_AX);
            this.groupBox2.Controls.Add(this.nud_Line_AY);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(4, 136);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(134, 133);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Line A";
            // 
            // nud_Line_AR
            // 
            this.nud_Line_AR.DecimalPlaces = 3;
            this.nud_Line_AR.Location = new System.Drawing.Point(65, 67);
            this.nud_Line_AR.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Line_AR.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Line_AR.Name = "nud_Line_AR";
            this.nud_Line_AR.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_AR.TabIndex = 32;
            this.nud_Line_AR.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_AR.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 13);
            this.label6.TabIndex = 31;
            this.label6.Text = "R: ";
            // 
            // nud_Line_AX
            // 
            this.nud_Line_AX.DecimalPlaces = 3;
            this.nud_Line_AX.Location = new System.Drawing.Point(66, 17);
            this.nud_Line_AX.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Line_AX.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Line_AX.Name = "nud_Line_AX";
            this.nud_Line_AX.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_AX.TabIndex = 27;
            this.nud_Line_AX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_AX.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_Line_AY
            // 
            this.nud_Line_AY.DecimalPlaces = 3;
            this.nud_Line_AY.Location = new System.Drawing.Point(66, 43);
            this.nud_Line_AY.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Line_AY.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Line_AY.Name = "nud_Line_AY";
            this.nud_Line_AY.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_AY.TabIndex = 30;
            this.nud_Line_AY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_AY.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "X: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "Y: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_Line_BL);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.nud_Line_BR);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.nud_Line_BY);
            this.groupBox1.Controls.Add(this.nud_Line_BX);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(157, 136);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(134, 133);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Line B";
            // 
            // nud_Line_BR
            // 
            this.nud_Line_BR.DecimalPlaces = 3;
            this.nud_Line_BR.Location = new System.Drawing.Point(63, 67);
            this.nud_Line_BR.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Line_BR.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Line_BR.Name = "nud_Line_BR";
            this.nud_Line_BR.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_BR.TabIndex = 34;
            this.nud_Line_BR.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_BR.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 13);
            this.label4.TabIndex = 33;
            this.label4.Text = "R: ";
            // 
            // nud_Line_BY
            // 
            this.nud_Line_BY.DecimalPlaces = 3;
            this.nud_Line_BY.Location = new System.Drawing.Point(63, 41);
            this.nud_Line_BY.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Line_BY.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Line_BY.Name = "nud_Line_BY";
            this.nud_Line_BY.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_BY.TabIndex = 24;
            this.nud_Line_BY.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_BY.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // nud_Line_BX
            // 
            this.nud_Line_BX.DecimalPlaces = 3;
            this.nud_Line_BX.Location = new System.Drawing.Point(63, 16);
            this.nud_Line_BX.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_Line_BX.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.nud_Line_BX.Name = "nud_Line_BX";
            this.nud_Line_BX.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_BX.TabIndex = 22;
            this.nud_Line_BX.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_BX.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Y: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(32, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "X: ";
            // 
            // nud_Line_AL
            // 
            this.nud_Line_AL.DecimalPlaces = 3;
            this.nud_Line_AL.Location = new System.Drawing.Point(65, 91);
            this.nud_Line_AL.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Line_AL.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Line_AL.Name = "nud_Line_AL";
            this.nud_Line_AL.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_AL.TabIndex = 34;
            this.nud_Line_AL.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_AL.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(33, 93);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 13);
            this.label27.TabIndex = 33;
            this.label27.Text = "L: ";
            // 
            // nud_Line_BL
            // 
            this.nud_Line_BL.DecimalPlaces = 3;
            this.nud_Line_BL.Location = new System.Drawing.Point(63, 93);
            this.nud_Line_BL.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Line_BL.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Line_BL.Name = "nud_Line_BL";
            this.nud_Line_BL.Size = new System.Drawing.Size(69, 20);
            this.nud_Line_BL.TabIndex = 36;
            this.nud_Line_BL.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Line_BL.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(31, 95);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 13);
            this.label28.TabIndex = 35;
            this.label28.Text = "L: ";
            // 
            // nud_Ellipse_AR
            // 
            this.nud_Ellipse_AR.DecimalPlaces = 3;
            this.nud_Ellipse_AR.Location = new System.Drawing.Point(65, 119);
            this.nud_Ellipse_AR.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_AR.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_AR.Name = "nud_Ellipse_AR";
            this.nud_Ellipse_AR.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_AR.TabIndex = 37;
            this.nud_Ellipse_AR.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_AR.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(33, 121);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(21, 13);
            this.label29.TabIndex = 35;
            this.label29.Text = "R: ";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DecimalPlaces = 3;
            this.numericUpDown2.Location = new System.Drawing.Point(67, 119);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(69, 20);
            this.numericUpDown2.TabIndex = 38;
            this.numericUpDown2.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(35, 121);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(21, 13);
            this.label30.TabIndex = 36;
            this.label30.Text = "H: ";
            // 
            // nud_Ellipse_BR
            // 
            this.nud_Ellipse_BR.DecimalPlaces = 3;
            this.nud_Ellipse_BR.Location = new System.Drawing.Point(65, 119);
            this.nud_Ellipse_BR.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_Ellipse_BR.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.nud_Ellipse_BR.Name = "nud_Ellipse_BR";
            this.nud_Ellipse_BR.Size = new System.Drawing.Size(69, 20);
            this.nud_Ellipse_BR.TabIndex = 36;
            this.nud_Ellipse_BR.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nud_Ellipse_BR.ValueChanged += new System.EventHandler(this.nud_ValueChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(33, 121);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(21, 13);
            this.label31.TabIndex = 35;
            this.label31.Text = "R: ";
            // 
            // MvMeasurementEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "MvMeasurementEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Setting.ResumeLayout(false);
            this.tp_Setting.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BY)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AY)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_BR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_BX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_BY)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_AR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_AX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Circle_AY)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Point_BX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Point_BY)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Point_AX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Point_AY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_CreateLine_Angle)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_AR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_AX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_AY)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_BR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_BY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_BX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_AL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Line_BL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_AR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Ellipse_BR)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tp_Setting;
        private System.Windows.Forms.NumericUpDown nud_Line_AX;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nud_Line_BY;
        private System.Windows.Forms.NumericUpDown nud_Line_BX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nud_Line_AY;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.NumericUpDown nud_CreateLine_Angle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cb_mode;
        private System.Windows.Forms.NumericUpDown nud_Line_AR;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nud_Line_BR;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.NumericUpDown nud_Circle_BR;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown nud_Circle_BX;
        private System.Windows.Forms.NumericUpDown nud_Circle_BY;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.NumericUpDown nud_Circle_AR;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown nud_Circle_AX;
        private System.Windows.Forms.NumericUpDown nud_Circle_AY;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown nud_Point_BX;
        private System.Windows.Forms.NumericUpDown nud_Point_BY;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown nud_Point_AX;
        private System.Windows.Forms.NumericUpDown nud_Point_AY;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_AW;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_AX;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_AY;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_AH;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_BH;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_BW;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_BX;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_BY;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown nud_Line_AL;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown nud_Line_BL;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_BR;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown nud_Ellipse_AR;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label30;
    }
}
