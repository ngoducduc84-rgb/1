﻿using MvCore.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MvCore.Edit
{
    public partial class MvMeasurementEdit : MvToolEditBase
    {
        public MvMeasurementEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += SvFindLineEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;
            this.SvDisplayViewEdit.Display.DrawObjectChanged += Display_DrawObjectChanged;
        }
        void SvFindLineEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
        public MvMeasurement Subject
        {
            get { return base.GetSubject() as MvMeasurement; }
            set { base.SetSubject(value); }
        }

        BindingSource source;
        void InitBinding()
        {
            source = new BindingSource(typeof(MvMeasurement), null);

            cb_mode.DisplayMember = "Key"; cb_mode.ValueMember = "Value";
            cb_mode.DataSource = Enum.GetValues(typeof(MvMeasurement.E_mode)).Cast<MvMeasurement.E_mode>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_mode.DataBindings.Add("SelectedValue", source, "Mode", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_CreateLine_Angle.DataBindings.Add("Value", source, "Angle", true, DataSourceUpdateMode.OnPropertyChanged);

            DataBindings.Add("PointA", source, "PointA", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("PointB", source, "PointB", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("LineA", source, "LineA", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("LineB", source, "LineB", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("EllipseA", source, "EllipseA", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("EllipseB", source, "EllipseB", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("CircleA", source, "CircleA", true, DataSourceUpdateMode.OnPropertyChanged);
            DataBindings.Add("CircleB", source, "CircleB", true, DataSourceUpdateMode.OnPropertyChanged);
            //DataBindings.Add("FindLineResult", source, "ResultList", true, DataSourceUpdateMode.Never);
        }

        private float GetAngleDeg(Point2d start, Point2d end)
        {
            
            double dx = end.X - start.X;
            double dy = end.Y - start.Y;

            if (dx == 0 && dy == 0)
                return 0; // 2 điểm trùng nhau

            double angleRad = Math.Atan2(dy, dx);
            double angleDeg = angleRad * 180.0 / Math.PI;

            if (angleDeg < 0)
                angleDeg += 360;
            Console.WriteLine($"start: X:{start.X},Y: {start.Y}, end: X:{end.X},Y:{end.Y} ,angle:{angleDeg}");
            return (float)angleDeg;
        }

        private Point2d CreateEndPoint(Point2d StartPoint, double angle, double length)
        {
            double rad = angle * Math.PI / 180.0;
            return new Point2d(StartPoint.X + length * Math.Cos(rad), StartPoint.Y + length * Math.Sin(rad));
        }


        private void nud_ValueChanged(object sender, EventArgs e)
        {
            if (lockPointA == false)
                NotifyPropertyChanged("PointA");
            if (lockPointB == false)
                NotifyPropertyChanged("PointB");
            if (lockLineA == false)
                NotifyPropertyChanged("LineA");
            if (lockLineB == false)
                NotifyPropertyChanged("LineB");
            if (lockEllipseA == false)
                NotifyPropertyChanged("EllipseA");
            if (lockEllipseB == false)
                NotifyPropertyChanged("EllipseB");
            if (lockCircleA == false)
                NotifyPropertyChanged("CircleA");
            if (lockCircleB == false)
                NotifyPropertyChanged("CircleB");
            svDisplayViewEdit.Refresh(); //Refresh draw image
        }


        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject != null)
                {
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.PointA);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.PointB);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.LineA);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.LineB);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.EllipseA);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.EllipseB);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.CircleA);
                    this.SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(Subject.CircleB);

                }
            }
        }
        void Display_DrawObjectChanged(object sender, InteractDrawObject drawObject) //update new Circle
        {
            if (drawObject is MvPoint)
            {
                MvPoint point = drawObject as MvPoint;
                if(point.ID == 0)
                    PointA = point;
                else
                    PointB = point;
            }
            if (drawObject is MvLine)
            {
                MvLine line = drawObject as MvLine;
                if (line.ID == 0)
                {  line.R = GetAngleDeg(line.SP, line.EP); LineA = line; }
                else
                { line.R = GetAngleDeg(line.SP, line.EP); LineB = line; }
            }
            if (drawObject is MvEllipse)
            {
                MvEllipse elipse = drawObject as MvEllipse;
                if(elipse.ID == 0)
                    EllipseA = elipse;
                else
                    EllipseB = elipse;
            }
            if (drawObject is MvCircle)
            {
                MvCircle circle = drawObject as MvCircle;
                if (circle.ID == 0)
                    CircleA = circle;
                else
                    CircleB = circle;
            }

        }
        //bool lockEvent = false;
        //private MvLine caliperLine;
        //public MvLine CaliperLine
        //{
        //    get
        //    {
        //        caliperLine.SP = new Point2d((double)nud_Line_AX.Value, (double)nud_Line_AY.Value);
        //        caliperLine.EP = new Point2d((double)nud_Line_BX.Value, (double)nud_Line_BY.Value);
        //        return caliperLine;
        //    }
        //    set
        //    {

        //        lockEvent = true;
        //        caliperLine = value;
        //        nud_Line_AX.Value = (decimal)value.SP.X;
        //        nud_Line_AY.Value = (decimal)value.SP.Y;
        //        nud_Line_BX.Value = (decimal)value.EP.X;
        //        nud_Line_BY.Value = (decimal)value.EP.Y;
        //        //svDisplayViewEdit.Refresh(); //Refresh draw image
        //        lockEvent = false;

        //    }
        //}

        bool lockPointA = false;
        private MvPoint pointA;
        public MvPoint PointA
        {
            get
            {
                pointA.X = (float)nud_Point_AX.Value;
                pointA.Y = (float)nud_Point_AY.Value;
                return pointA;
            }
            set
            {
                lockPointA = true;
                pointA = value;
                nud_Point_AX.Value = (decimal)value.X;
                nud_Point_AY.Value = (decimal)value.Y;
                lockPointA = false;
            }
        }

        bool lockPointB = false;
        private MvPoint pointB;
        public MvPoint PointB
        {
            get
            {
                pointB.X = (float)nud_Point_BX.Value;
                pointB.Y = (float)nud_Point_BY.Value;
                return pointB;
            }
            set
            {
                lockPointB = true;
                pointB = value;
                nud_Point_BX.Value = (decimal)value.X;
                nud_Point_BY.Value = (decimal)value.Y;
                lockPointB = false;
            }
        }

        bool lockLineA = false;
        private MvLine lineA;
        public MvLine LineA
        {
            get
            {
                lineA.R = (float)nud_Line_AR.Value;
                lineA.SP = new Point2d((double)nud_Line_AX.Value, (double)nud_Line_AY.Value);
                lineA.L = (float)nud_Line_AL.Value;
                lineA.EP = CreateEndPoint(lineA.SP, lineA.R, lineA.L);
                return lineA;
            }
            set
            {
                lockLineA = true;
                lineA = value;
                nud_Line_AX.Value = (decimal)value.SP.X;
                nud_Line_AY.Value = (decimal)value.SP.Y;
                nud_Line_AR.Value = (decimal)value.R;
                nud_Line_AL.Value = (decimal)(value.GetLineLength());
                lockLineA = false;
            }
        }
        bool lockLineB = false;
        private MvLine lineB;
        public MvLine LineB
        {
            get
            {
                lineB.R = (float)nud_Line_BR.Value;
                lineB.SP = new Point2d((double)nud_Line_BX.Value, (double)nud_Line_BY.Value);
                lineB.L = (float)nud_Line_BL.Value;
                lineB.EP = CreateEndPoint(lineB.SP, lineB.R, lineB.L);
                return lineB;
            }
            set
            {
                lockLineB = true;
                lineB = value;
                nud_Line_BX.Value = (decimal)value.SP.X;
                nud_Line_BY.Value = (decimal)value.SP.Y;
                nud_Line_BR.Value = (decimal)value.R;
                nud_Line_BL.Value = (decimal)(value.GetLineLength());
                lockLineB = false;
            }
        }

        bool lockEllipseA = false;
        private MvEllipse ellipseA;
        public MvEllipse EllipseA
        {
            get
            {
                ellipseA.Center = new PointF((float)nud_Ellipse_AX.Value, (float)nud_Ellipse_AY.Value);
                ellipseA.Width = (float)nud_Ellipse_AW.Value;
                ellipseA.Height = (float)nud_Ellipse_AH.Value;
                ellipseA.R = (float)nud_Ellipse_AR.Value;
                return ellipseA;
            }
            set
            {
                lockEllipseA = true;
                ellipseA = value;
                nud_Ellipse_AX.Value = (decimal)value.Center.X;
                nud_Ellipse_AY.Value = (decimal)value.Center.Y;
                nud_Ellipse_AW.Value = (decimal)value.Width;
                nud_Ellipse_AH.Value = (decimal)value.Height;
                nud_Ellipse_AR.Value = (decimal)value.R;
                lockEllipseA = false;
            }
        }

        bool lockEllipseB = false;
        private MvEllipse ellipseB;
        public MvEllipse EllipseB
        {
            get
            {
                ellipseB.Center = new PointF((float)nud_Ellipse_BX.Value, (float)nud_Ellipse_BY.Value);
                ellipseB.Width = (float)nud_Ellipse_BW.Value;
                ellipseB.Height = (float)nud_Ellipse_BH.Value;
                ellipseB.R = (float)nud_Ellipse_BR.Value;
                return ellipseB;
            }
            set
            {
                lockEllipseB = true;
                ellipseB = value;
                nud_Ellipse_BX.Value = (decimal)value.Center.X;
                nud_Ellipse_BY.Value = (decimal)value.Center.Y;
                nud_Ellipse_BW.Value = (decimal)value.Width;
                nud_Ellipse_BH.Value = (decimal)value.Height;
                nud_Ellipse_BR.Value = (decimal)value.R;
                lockEllipseB = false;
            }
        }

        bool lockCircleA = false;
        private MvCircle circleA;

        public MvCircle CircleA
        {
            get 
            {
                circleA.Center = new Point2d((double)nud_Circle_AX.Value,(double)nud_Circle_AY.Value);
                circleA.R = (float)nud_Circle_AR.Value;
                return circleA; 
            }
            set 
            {
                lockCircleA = true;
                circleA = value;
                nud_Circle_AX.Value = (decimal)value.Center.X;
                nud_Circle_AY.Value = (decimal)value.Center.Y;
                nud_Circle_AR.Value = (decimal)value.R;
                lockCircleA = false;
            }
        }

        bool lockCircleB = false;
        private MvCircle circleB;

        public MvCircle CircleB
        {
            get
            {
                circleB.Center = new Point2d((double)nud_Circle_BX.Value, (double)nud_Circle_BY.Value);
                circleB.R = (float)nud_Circle_BR.Value;
                return circleB;
            }
            set
            {
                lockCircleB = true;
                circleB = value;
                nud_Circle_BX.Value = (decimal)value.Center.X;
                nud_Circle_BY.Value = (decimal)value.Center.Y;
                nud_Circle_BR.Value = (decimal)value.R;
                lockCircleB = false;
            }
        }




    }
}
