﻿namespace MvCore.Edit
{
    partial class MvMergeEdit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_operator = new System.Windows.Forms.ComboBox();
            this.cb_mode = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_O0 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_i9 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_i8 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_i7 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_i6 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_i5 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_i4 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_i3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_i2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_i1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_i0 = new System.Windows.Forms.TextBox();
            this.tabControl.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage2);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.txt_O0);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.txt_i9);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.txt_i8);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.txt_i7);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.txt_i6);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.txt_i5);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.txt_i4);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txt_i3);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txt_i2);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txt_i1);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txt_i0);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.cb_operator);
            this.tabPage2.Controls.Add(this.cb_mode);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(442, 426);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "setting";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(226, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Operator";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(226, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Mode";
            // 
            // cb_operator
            // 
            this.cb_operator.FormattingEnabled = true;
            this.cb_operator.Items.AddRange(new object[] {
            "+",
            "-",
            "*",
            "/"});
            this.cb_operator.Location = new System.Drawing.Point(315, 50);
            this.cb_operator.Name = "cb_operator";
            this.cb_operator.Size = new System.Drawing.Size(121, 21);
            this.cb_operator.TabIndex = 1;
            // 
            // cb_mode
            // 
            this.cb_mode.FormattingEnabled = true;
            this.cb_mode.Items.AddRange(new object[] {
            "Split",
            "toList",
            "toString",
            "toArray",
            "Math"});
            this.cb_mode.Location = new System.Drawing.Point(315, 13);
            this.cb_mode.Name = "cb_mode";
            this.cb_mode.Size = new System.Drawing.Size(121, 21);
            this.cb_mode.TabIndex = 0;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(14, 281);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 13);
            this.label17.TabIndex = 47;
            this.label17.Text = "O0";
            // 
            // txt_O0
            // 
            this.txt_O0.Location = new System.Drawing.Point(44, 278);
            this.txt_O0.Name = "txt_O0";
            this.txt_O0.Size = new System.Drawing.Size(100, 20);
            this.txt_O0.TabIndex = 46;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 255);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(16, 13);
            this.label18.TabIndex = 45;
            this.label18.Text = "I9";
            // 
            // txt_i9
            // 
            this.txt_i9.Location = new System.Drawing.Point(44, 252);
            this.txt_i9.Name = "txt_i9";
            this.txt_i9.Size = new System.Drawing.Size(100, 20);
            this.txt_i9.TabIndex = 44;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 229);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 13);
            this.label13.TabIndex = 43;
            this.label13.Text = "I8";
            // 
            // txt_i8
            // 
            this.txt_i8.Location = new System.Drawing.Point(44, 226);
            this.txt_i8.Name = "txt_i8";
            this.txt_i8.Size = new System.Drawing.Size(100, 20);
            this.txt_i8.TabIndex = 42;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 203);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 13);
            this.label14.TabIndex = 41;
            this.label14.Text = "I7";
            // 
            // txt_i7
            // 
            this.txt_i7.Location = new System.Drawing.Point(44, 200);
            this.txt_i7.Name = "txt_i7";
            this.txt_i7.Size = new System.Drawing.Size(100, 20);
            this.txt_i7.TabIndex = 40;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 177);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 13);
            this.label15.TabIndex = 39;
            this.label15.Text = "I6";
            // 
            // txt_i6
            // 
            this.txt_i6.Location = new System.Drawing.Point(44, 174);
            this.txt_i6.Name = "txt_i6";
            this.txt_i6.Size = new System.Drawing.Size(100, 20);
            this.txt_i6.TabIndex = 38;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 13);
            this.label10.TabIndex = 37;
            this.label10.Text = "I5";
            // 
            // txt_i5
            // 
            this.txt_i5.Location = new System.Drawing.Point(44, 148);
            this.txt_i5.Name = "txt_i5";
            this.txt_i5.Size = new System.Drawing.Size(100, 20);
            this.txt_i5.TabIndex = 36;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 125);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 13);
            this.label11.TabIndex = 35;
            this.label11.Text = "I4";
            // 
            // txt_i4
            // 
            this.txt_i4.Location = new System.Drawing.Point(44, 122);
            this.txt_i4.Name = "txt_i4";
            this.txt_i4.Size = new System.Drawing.Size(100, 20);
            this.txt_i4.TabIndex = 34;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "I3";
            // 
            // txt_i3
            // 
            this.txt_i3.Location = new System.Drawing.Point(44, 96);
            this.txt_i3.Name = "txt_i3";
            this.txt_i3.Size = new System.Drawing.Size(100, 20);
            this.txt_i3.TabIndex = 32;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 73);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "I2";
            // 
            // txt_i2
            // 
            this.txt_i2.Location = new System.Drawing.Point(44, 70);
            this.txt_i2.Name = "txt_i2";
            this.txt_i2.Size = new System.Drawing.Size(100, 20);
            this.txt_i2.TabIndex = 30;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 47);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "I1";
            // 
            // txt_i1
            // 
            this.txt_i1.Location = new System.Drawing.Point(44, 44);
            this.txt_i1.Name = "txt_i1";
            this.txt_i1.Size = new System.Drawing.Size(100, 20);
            this.txt_i1.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "I0";
            // 
            // txt_i0
            // 
            this.txt_i0.Location = new System.Drawing.Point(44, 18);
            this.txt_i0.Name = "txt_i0";
            this.txt_i0.Size = new System.Drawing.Size(100, 20);
            this.txt_i0.TabIndex = 26;
            // 
            // MvCalculatorEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "MvCalculatorEdit";
            this.tabControl.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_operator;
        private System.Windows.Forms.ComboBox cb_mode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_O0;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_i9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_i8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_i7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_i6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_i5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_i4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_i3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_i2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_i1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_i0;
    }
}
