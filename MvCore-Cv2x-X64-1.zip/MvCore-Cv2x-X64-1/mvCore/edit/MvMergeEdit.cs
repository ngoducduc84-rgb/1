﻿using MvCore.Edit.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MvCore.Edit
{
    public partial class MvMergeEdit : MvToolEditBase
    {
        private Label label1;
        private Label label4;
        private Label label3;
        //private TextBox textBox3;
        private Label label2;
        //private ComboBox comboBox1;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown1;
        private TabPage tabPage1;

        public MvMergeEdit()
        {
            InitializeComponent();
            initBinding();
            this.SubjectChanged += SvListToStringEdit_SubjectChanged;
        }

        public override void formLoad()
        {

        }

        public MvMerge Subject // tool class
        {
            get { return base.GetSubject() as MvMerge; }
            set { base.SetSubject(value); }
        }


        BindingSource source;
        private void SvListToStringEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }
       
        void initBinding()
        {
            source = new BindingSource(typeof(MvMerge), null);
            cb_mode.DataBindings.Add("SelectedIndex", source, "Mode", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_operator.DataBindings.Add("SelectedIndex", source, "_Operator", true, DataSourceUpdateMode.OnPropertyChanged);
            txt_i0.DataBindings.Add("Text", source, "I0", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i1.DataBindings.Add("Text", source, "I1", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i2.DataBindings.Add("Text", source, "I2", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i3.DataBindings.Add("Text", source, "I3", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i4.DataBindings.Add("Text", source, "I4", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i5.DataBindings.Add("Text", source, "I5", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i6.DataBindings.Add("Text", source, "I6", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i7.DataBindings.Add("Text", source, "I7", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i8.DataBindings.Add("Text", source, "I8", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_i9.DataBindings.Add("Text", source, "I9", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            txt_O0.DataBindings.Add("Text", source, "O0", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
        }   
    }
}