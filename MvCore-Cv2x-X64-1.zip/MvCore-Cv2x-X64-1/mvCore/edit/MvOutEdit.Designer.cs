﻿namespace MvCore.Edit
{
    partial class MvOutEdit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }



        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_Bolean = new System.Windows.Forms.ComboBox();
            this.txt_String = new System.Windows.Forms.TextBox();
            this.nud_foat = new System.Windows.Forms.NumericUpDown();
            this.nud_int = new System.Windows.Forms.NumericUpDown();
            this.tabControl.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_foat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_int)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage2);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cb_Bolean);
            this.tabPage2.Controls.Add(this.txt_String);
            this.tabPage2.Controls.Add(this.nud_foat);
            this.tabPage2.Controls.Add(this.nud_int);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(442, 426);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "Page1";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Bolean Out";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "String Out";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Double Out";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "int Out";
            // 
            // cb_Bolean
            // 
            this.cb_Bolean.FormattingEnabled = true;
            this.cb_Bolean.Items.AddRange(new object[] {
            "True",
            "False"});
            this.cb_Bolean.Location = new System.Drawing.Point(87, 135);
            this.cb_Bolean.Name = "cb_Bolean";
            this.cb_Bolean.Size = new System.Drawing.Size(120, 21);
            this.cb_Bolean.TabIndex = 11;
            // 
            // txt_String
            // 
            this.txt_String.Location = new System.Drawing.Point(87, 89);
            this.txt_String.Name = "txt_String";
            this.txt_String.Size = new System.Drawing.Size(120, 20);
            this.txt_String.TabIndex = 10;
            // 
            // nud_foat
            // 
            this.nud_foat.DecimalPlaces = 9;
            this.nud_foat.Location = new System.Drawing.Point(87, 47);
            this.nud_foat.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_foat.Name = "nud_foat";
            this.nud_foat.Size = new System.Drawing.Size(120, 20);
            this.nud_foat.TabIndex = 9;
            // 
            // nud_int
            // 
            this.nud_int.Location = new System.Drawing.Point(87, 6);
            this.nud_int.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nud_int.Name = "nud_int";
            this.nud_int.Size = new System.Drawing.Size(120, 20);
            this.nud_int.TabIndex = 8;
            // 
            // MvOutputEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "MvOutputEdit";
            this.tabControl.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_foat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_int)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_Bolean;
        private System.Windows.Forms.TextBox txt_String;
        private System.Windows.Forms.NumericUpDown nud_foat;
        private System.Windows.Forms.NumericUpDown nud_int;
    }
}
