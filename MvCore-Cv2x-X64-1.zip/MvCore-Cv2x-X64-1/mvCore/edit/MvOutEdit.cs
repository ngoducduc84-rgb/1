﻿using MvCore.Edit.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MvCore.Edit
{
    public partial class MvOutEdit : MvToolEditBase
    {
        private Label label1;
        private Label label4;
        private Label label3;
        //private TextBox textBox3;
        private Label label2;
        //private ComboBox comboBox1;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown1;
        private TabPage tabPage1;

        public MvOutEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += MvOutputEdit_SubjectChanged;
        }
       

        public MvOut Subject // tool class
        {
            get { return base.GetSubject() as MvOut; }
            set { base.SetSubject(value);}
        }

        private void MvOutputEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        BindingSource source;

        void InitBinding()
        {
            source = new BindingSource(typeof(MvOut), null);

            nud_int.DataBindings.Add("Value", source, "IntOut", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            nud_foat.DataBindings.Add("Value", source, "FloatOut", true, DataSourceUpdateMode.OnPropertyChanged, 3f);
            txt_String.DataBindings.Add("Text", source, "StringOut", true, DataSourceUpdateMode.OnPropertyChanged, ToString());
            cb_Bolean.DataBindings.Add("Text", source, "BoolOut", true, DataSourceUpdateMode.OnPropertyChanged, ToString());

        }

        public override void formLoad()
        {
            //if (Subject != null)
            //{
            //    numericUpDown3.Value = Subject.IntOut;
            //    numericUpDown4.Value = (decimal)Subject.DoubleOut;
            //    textBox1.Text = Subject.StringOut;
            //    comboBox1.Text = Subject.BoolOut.ToString(); // "True" hoặc "False"
            //}
        }
        //int
      
    }
}