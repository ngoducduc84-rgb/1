﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Core;
using System.Reflection;
using MvCore.Edit.Base;

namespace MvCore.Edit
{
    public partial class MvResultAnalysisEdit : MvToolEditBase
    {
        MvRotationRectangle regionRect;

        public MvResultAnalysisEdit()
        {
            InitializeComponent();
            InitBinding();
            base.SubjectChanged += SvResultAnalysisEdit_SubjectChanged;
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
         public MvResultAnalysis Subject
        {
            get { return base.GetSubject() as MvResultAnalysis; }
            set { base.SetSubject(value);}
        }

        BindingSource source;
        void SvResultAnalysisEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        void InitBinding()
        {
            source = new BindingSource(typeof(MvIntersectLine), null);
            DataBindings.Add("State", source, "Result", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        [NonSerialized]
        bool state = false;

        [OutputParam]
        public bool State
        {
            get 
            { 
                return state; 
            }
            set 
            { 
                state = value;
                UpdataResultStatus(state);
                NotifyPropertyChanged(); 
            }
        }

        void UpdataResultStatus(bool Status)
        {
            if (Status)
            {
                lbl_ResultStatus.Text = "Accept";
                lbl_ResultStatus.BackColor = Color.DodgerBlue;
                lbl_ResultStatus.ForeColor = Color.White;
            }

            else
            {
                lbl_ResultStatus.Text = "Reject";
                lbl_ResultStatus.BackColor = Color.Red;
                lbl_ResultStatus.ForeColor = Color.Black;
            }
        }
    }
}
