﻿namespace MvCore.Edit
{
    partial class MvTCPEdit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_send = new System.Windows.Forms.Button();
            this.txt_send = new System.Windows.Forms.TextBox();
            this.rtb_Reciver = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rbtn_client = new System.Windows.Forms.RadioButton();
            this.rbtn_server = new System.Windows.Forms.RadioButton();
            this.txt_port = new System.Windows.Forms.TextBox();
            this.txt_ipAddress = new System.Windows.Forms.TextBox();
            this.cb_testRunMode = new System.Windows.Forms.CheckBox();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.cb_testRunMode);
            this.tabPage1.Controls.Add(this.btn_send);
            this.tabPage1.Controls.Add(this.txt_send);
            this.tabPage1.Controls.Add(this.rtb_Reciver);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.rbtn_client);
            this.tabPage1.Controls.Add(this.rbtn_server);
            this.tabPage1.Controls.Add(this.txt_port);
            this.tabPage1.Controls.Add(this.txt_ipAddress);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(442, 426);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Param";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_send
            // 
            this.btn_send.Location = new System.Drawing.Point(355, 399);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(75, 23);
            this.btn_send.TabIndex = 8;
            this.btn_send.Text = "Send";
            this.btn_send.UseVisualStyleBackColor = true;
            this.btn_send.Click += new System.EventHandler(this.btn_send_Click);
            // 
            // txt_send
            // 
            this.txt_send.Location = new System.Drawing.Point(17, 400);
            this.txt_send.Name = "txt_send";
            this.txt_send.Size = new System.Drawing.Size(332, 20);
            this.txt_send.TabIndex = 7;
            // 
            // rtb_Reciver
            // 
            this.rtb_Reciver.Location = new System.Drawing.Point(17, 57);
            this.rtb_Reciver.Name = "rtb_Reciver";
            this.rtb_Reciver.Size = new System.Drawing.Size(413, 336);
            this.rtb_Reciver.TabIndex = 6;
            this.rtb_Reciver.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(191, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Port:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "IPAddress:";
            // 
            // rbtn_client
            // 
            this.rbtn_client.AutoSize = true;
            this.rbtn_client.Location = new System.Drawing.Point(379, 16);
            this.rbtn_client.Name = "rbtn_client";
            this.rbtn_client.Size = new System.Drawing.Size(51, 17);
            this.rbtn_client.TabIndex = 3;
            this.rbtn_client.TabStop = true;
            this.rbtn_client.Text = "Client";
            this.rbtn_client.UseVisualStyleBackColor = true;
            
            // 
            // rbtn_server
            // 
            this.rbtn_server.AutoSize = true;
            this.rbtn_server.Location = new System.Drawing.Point(310, 16);
            this.rbtn_server.Name = "rbtn_server";
            this.rbtn_server.Size = new System.Drawing.Size(56, 17);
            this.rbtn_server.TabIndex = 2;
            this.rbtn_server.TabStop = true;
            this.rbtn_server.Text = "Server";
            this.rbtn_server.UseVisualStyleBackColor = true;
          
            // 
            // txt_port
            // 
            this.txt_port.Location = new System.Drawing.Point(226, 15);
            this.txt_port.Name = "txt_port";
            this.txt_port.Size = new System.Drawing.Size(69, 20);
            this.txt_port.TabIndex = 1;
          
            // 
            // txt_ipAddress
            // 
            this.txt_ipAddress.Location = new System.Drawing.Point(80, 15);
            this.txt_ipAddress.Name = "txt_ipAddress";
            this.txt_ipAddress.Size = new System.Drawing.Size(100, 20);
            this.txt_ipAddress.TabIndex = 0;
           
            // 
            // cb_testRunMode
            // 
            this.cb_testRunMode.AutoSize = true;
            this.cb_testRunMode.Location = new System.Drawing.Point(310, 38);
            this.cb_testRunMode.Name = "cb_testRunMode";
            this.cb_testRunMode.Size = new System.Drawing.Size(100, 17);
            this.cb_testRunMode.TabIndex = 9;
            this.cb_testRunMode.Text = "Test Run Mode";
            this.cb_testRunMode.UseVisualStyleBackColor = true;
            // 
            // MvTCPEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "MvTCPEdit";
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txt_ipAddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbtn_client;
        private System.Windows.Forms.RadioButton rbtn_server;
        private System.Windows.Forms.TextBox txt_port;
        private System.Windows.Forms.Button btn_send;
        private System.Windows.Forms.TextBox txt_send;
        private System.Windows.Forms.RichTextBox rtb_Reciver;
        private System.Windows.Forms.CheckBox cb_testRunMode;
    }
}
