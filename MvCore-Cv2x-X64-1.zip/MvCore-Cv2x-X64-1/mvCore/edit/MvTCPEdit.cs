﻿using MvCore.Edit.Base;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MvCore.MvTemplateMatch;

namespace MvCore.Edit
{
    public partial class MvTCPEdit : MvToolEditBase
    {
        public MvTCPEdit()
        {
            InitializeComponent();
            InitBinding();
            this.SubjectChanged += MvTCPEdit_SubjectChanged;
        }

        private void MvTCPEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            source.DataSource = Subject;
            source.ResetBindings(true);
        }

        public override void formLoad()
        {
            if (Subject != null)
            {
                txt_ipAddress.Text = Subject.IpAddress?.ToString() ?? string.Empty;
                txt_port.Text = Subject.Port.ToString()?.ToString() ?? string.Empty;
                rbtn_server.Checked = Subject.Mode;
                rbtn_client.Checked = !rbtn_server.Checked;
                MvTCP outputTool = Subject as MvTCP;
                Subject.eventReciverHandler += Subject_eventReciverHandler;
            }
        }
        BindingSource source;
        void InitBinding()
        {
            source = new BindingSource(typeof(MvTCP), null);
            txt_ipAddress.DataBindings.Add("Text", source, "IpAddress", true, DataSourceUpdateMode.OnPropertyChanged);
            txt_port.DataBindings.Add("Text", source, "Port", true, DataSourceUpdateMode.OnPropertyChanged);
            rbtn_server.DataBindings.Add("Checked", source, "Mode", true, DataSourceUpdateMode.OnPropertyChanged);
            //rbtn_client.DataBindings.Add("Checked", source, "Mode", true, DataSourceUpdateMode.OnPropertyChanged);
            cb_testRunMode.DataBindings.Add("Checked", source, "TestRunMode", true, DataSourceUpdateMode.OnPropertyChanged);
          
        }

        private void Subject_eventReciverHandler(object sender, string data)
        {
            if (rtb_Reciver.IsHandleCreated)
            {
                rtb_Reciver.BeginInvoke(new Action(() =>
                {
                    rtb_Reciver.AppendText(data + Environment.NewLine);
                }));
            }
        }
        public MvTCP Subject // tool class
        {
            get { return base.GetSubject() as MvTCP; }
            set { base.SetSubject(value); }
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            MvTCP outputTool = Subject as MvTCP;
            outputTool.sendData(txt_send.Text);
        }
    }
}
