﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore.Edit.Base;

namespace MvCore.Edit
{
    public partial class MvTCPSendEdit : MvToolEditBase
    {
        public MvTCPSendEdit()
        {
            InitializeComponent();
        }
        public MvTCPSend Subject // tool class
        {
            get { return base.GetSubject() as MvTCPSend; }
            set { base.SetSubject(value); }
        }
        public override void formLoad()
        {
        }
    }
}
