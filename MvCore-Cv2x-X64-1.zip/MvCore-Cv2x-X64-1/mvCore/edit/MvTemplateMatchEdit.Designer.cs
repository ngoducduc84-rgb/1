﻿namespace MvCore.Edit
{
    partial class MvTemplateMatchEdit
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tp_Train = new System.Windows.Forms.TabPage();
            this.btn_grab = new System.Windows.Forms.Button();
            this.chb_UseRegonMode = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nud_TempTHHigh = new System.Windows.Forms.NumericUpDown();
            this.lbl_Tilda = new System.Windows.Forms.Label();
            this.nud_TempTHLow = new System.Windows.Forms.NumericUpDown();
            this.cb_MatchMode = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_refMark_Right = new System.Windows.Forms.Button();
            this.btn_refMark_Down = new System.Windows.Forms.Button();
            this.btn_refMark_Left = new System.Windows.Forms.Button();
            this.btn_refMark_Up = new System.Windows.Forms.Button();
            this.lb_patter3 = new System.Windows.Forms.Label();
            this.lb_patter2 = new System.Windows.Forms.Label();
            this.lb_patter1 = new System.Windows.Forms.Label();
            this.lb_patter0 = new System.Windows.Forms.Label();
            this.btn_Pre = new System.Windows.Forms.Button();
            this.btn_Next = new System.Windows.Forms.Button();
            this.chb_MaskOn = new System.Windows.Forms.CheckBox();
            this.chb_AutoIndex = new System.Windows.Forms.CheckBox();
            this.chb_TempUseEdge = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.svd_SubPattern3 = new MvCore.Display.MvDisplayViewInteract();
            this.svd_SubPattern2 = new MvCore.Display.MvDisplayViewInteract();
            this.svd_SubPattern1 = new MvCore.Display.MvDisplayViewInteract();
            this.svd_SubPattern0 = new MvCore.Display.MvDisplayViewInteract();
            this.svd_Template = new MvCore.Display.MvDisplayViewInteract();
            this.btn_ResetMask = new System.Windows.Forms.Button();
            this.btn_RefToCenter = new System.Windows.Forms.Button();
            this.btn_LoadPattern = new System.Windows.Forms.Button();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.btn_AddPattern = new System.Windows.Forms.Button();
            this.btn_SavePattern = new System.Windows.Forms.Button();
            this.btn_TemplateMatching_Grab = new System.Windows.Forms.Button();
            this.btn_Selected = new System.Windows.Forms.Button();
            this.tp_Setting = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_TempScaleMax = new System.Windows.Forms.NumericUpDown();
            this.nud_TempScaleMin = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.gb_Priority = new System.Windows.Forms.GroupBox();
            this.cb_TemplPriority = new System.Windows.Forms.ComboBox();
            this.nud_TMmaxCount = new System.Windows.Forms.NumericUpDown();
            this.nud_templPCreteria = new System.Windows.Forms.NumericUpDown();
            this.lb_templmaxcount = new System.Windows.Forms.Label();
            this.lb_TemplPriCre = new System.Windows.Forms.Label();
            this.lb_TemplPri = new System.Windows.Forms.Label();
            this.gb_MatchingMethod = new System.Windows.Forms.GroupBox();
            this.cb_HalEdgeMode = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.nud_pyramid = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.chb_AutoParam = new System.Windows.Forms.CheckBox();
            this.nud_templPrecision = new System.Windows.Forms.NumericUpDown();
            this.nud_FirstStep = new System.Windows.Forms.NumericUpDown();
            this.nud_Template_Method_Degree2 = new System.Windows.Forms.NumericUpDown();
            this.nud_Template_Method_Degree1 = new System.Windows.Forms.NumericUpDown();
            this.nud_Template_ScaleLast = new System.Windows.Forms.NumericUpDown();
            this.nud_Template_ScaleFirst = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_SclaeLast = new System.Windows.Forms.Label();
            this.lbl_ScaleFirst = new System.Windows.Forms.Label();
            this.lb_FirstStep = new System.Windows.Forms.Label();
            this.lb_TemplPrecision = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tp_Train.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TempTHHigh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TempTHLow)).BeginInit();
            this.tp_Setting.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TempScaleMax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TempScaleMin)).BeginInit();
            this.gb_Priority.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TMmaxCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_templPCreteria)).BeginInit();
            this.gb_MatchingMethod.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_pyramid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_templPrecision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FirstStep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Template_Method_Degree2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Template_Method_Degree1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Template_ScaleLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Template_ScaleFirst)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tp_Train);
            this.tabControl.Controls.Add(this.tp_Setting);
            // 
            // tp_Train
            // 
            this.tp_Train.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tp_Train.Controls.Add(this.btn_grab);
            this.tp_Train.Controls.Add(this.chb_UseRegonMode);
            this.tp_Train.Controls.Add(this.groupBox2);
            this.tp_Train.Controls.Add(this.cb_MatchMode);
            this.tp_Train.Controls.Add(this.label8);
            this.tp_Train.Controls.Add(this.btn_refMark_Right);
            this.tp_Train.Controls.Add(this.btn_refMark_Down);
            this.tp_Train.Controls.Add(this.btn_refMark_Left);
            this.tp_Train.Controls.Add(this.btn_refMark_Up);
            this.tp_Train.Controls.Add(this.lb_patter3);
            this.tp_Train.Controls.Add(this.lb_patter2);
            this.tp_Train.Controls.Add(this.lb_patter1);
            this.tp_Train.Controls.Add(this.lb_patter0);
            this.tp_Train.Controls.Add(this.btn_Pre);
            this.tp_Train.Controls.Add(this.btn_Next);
            this.tp_Train.Controls.Add(this.chb_MaskOn);
            this.tp_Train.Controls.Add(this.chb_AutoIndex);
            this.tp_Train.Controls.Add(this.chb_TempUseEdge);
            this.tp_Train.Controls.Add(this.label6);
            this.tp_Train.Controls.Add(this.label5);
            this.tp_Train.Controls.Add(this.svd_SubPattern3);
            this.tp_Train.Controls.Add(this.svd_SubPattern2);
            this.tp_Train.Controls.Add(this.svd_SubPattern1);
            this.tp_Train.Controls.Add(this.svd_SubPattern0);
            this.tp_Train.Controls.Add(this.svd_Template);
            this.tp_Train.Controls.Add(this.btn_ResetMask);
            this.tp_Train.Controls.Add(this.btn_RefToCenter);
            this.tp_Train.Controls.Add(this.btn_LoadPattern);
            this.tp_Train.Controls.Add(this.btn_Remove);
            this.tp_Train.Controls.Add(this.btn_AddPattern);
            this.tp_Train.Controls.Add(this.btn_SavePattern);
            this.tp_Train.Controls.Add(this.btn_TemplateMatching_Grab);
            this.tp_Train.Controls.Add(this.btn_Selected);
            this.tp_Train.Location = new System.Drawing.Point(4, 22);
            this.tp_Train.Name = "tp_Train";
            this.tp_Train.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Train.Size = new System.Drawing.Size(442, 426);
            this.tp_Train.TabIndex = 1;
            this.tp_Train.Text = "Mark Regist";
            this.tp_Train.UseVisualStyleBackColor = true;
            // 
            // btn_grab
            // 
            this.btn_grab.Location = new System.Drawing.Point(218, 346);
            this.btn_grab.Name = "btn_grab";
            this.btn_grab.Size = new System.Drawing.Size(54, 32);
            this.btn_grab.TabIndex = 59;
            this.btn_grab.Text = "Grab";
            this.btn_grab.UseVisualStyleBackColor = true;
            this.btn_grab.Click += new System.EventHandler(this.btn_grab_Click);
            // 
            // chb_UseRegonMode
            // 
            this.chb_UseRegonMode.AutoSize = true;
            this.chb_UseRegonMode.Checked = true;
            this.chb_UseRegonMode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chb_UseRegonMode.Location = new System.Drawing.Point(139, 256);
            this.chb_UseRegonMode.Name = "chb_UseRegonMode";
            this.chb_UseRegonMode.Size = new System.Drawing.Size(112, 17);
            this.chb_UseRegonMode.TabIndex = 58;
            this.chb_UseRegonMode.Text = "Use Region Mode";
            this.chb_UseRegonMode.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.nud_TempTHHigh);
            this.groupBox2.Controls.Add(this.lbl_Tilda);
            this.groupBox2.Controls.Add(this.nud_TempTHLow);
            this.groupBox2.Location = new System.Drawing.Point(3, 375);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(189, 49);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thresh";
            // 
            // nud_TempTHHigh
            // 
            this.nud_TempTHHigh.Location = new System.Drawing.Point(123, 15);
            this.nud_TempTHHigh.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_TempTHHigh.Name = "nud_TempTHHigh";
            this.nud_TempTHHigh.Size = new System.Drawing.Size(60, 20);
            this.nud_TempTHHigh.TabIndex = 46;
            this.nud_TempTHHigh.ValueChanged += new System.EventHandler(this.nud_Threshold_ValueChanged);
            // 
            // lbl_Tilda
            // 
            this.lbl_Tilda.AutoSize = true;
            this.lbl_Tilda.Location = new System.Drawing.Point(86, 18);
            this.lbl_Tilda.Name = "lbl_Tilda";
            this.lbl_Tilda.Size = new System.Drawing.Size(14, 13);
            this.lbl_Tilda.TabIndex = 42;
            this.lbl_Tilda.Text = "~";
            // 
            // nud_TempTHLow
            // 
            this.nud_TempTHLow.Location = new System.Drawing.Point(8, 15);
            this.nud_TempTHLow.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_TempTHLow.Name = "nud_TempTHLow";
            this.nud_TempTHLow.Size = new System.Drawing.Size(60, 20);
            this.nud_TempTHLow.TabIndex = 46;
            this.nud_TempTHLow.ValueChanged += new System.EventHandler(this.nud_Threshold_ValueChanged);
            // 
            // cb_MatchMode
            // 
            this.cb_MatchMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_MatchMode.FormattingEnabled = true;
            this.cb_MatchMode.Location = new System.Drawing.Point(77, 353);
            this.cb_MatchMode.Name = "cb_MatchMode";
            this.cb_MatchMode.Size = new System.Drawing.Size(115, 21);
            this.cb_MatchMode.TabIndex = 55;
            this.cb_MatchMode.SelectedValueChanged += new System.EventHandler(this.cb_MatchMode_SelectedValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1, 357);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 13);
            this.label8.TabIndex = 56;
            this.label8.Text = "Match Mode : ";
            // 
            // btn_refMark_Right
            // 
            this.btn_refMark_Right.Location = new System.Drawing.Point(245, 214);
            this.btn_refMark_Right.Name = "btn_refMark_Right";
            this.btn_refMark_Right.Size = new System.Drawing.Size(75, 23);
            this.btn_refMark_Right.TabIndex = 54;
            this.btn_refMark_Right.Text = "▶";
            this.btn_refMark_Right.UseVisualStyleBackColor = true;
            this.btn_refMark_Right.Click += new System.EventHandler(this.btn_refMark_Right_Click);
            // 
            // btn_refMark_Down
            // 
            this.btn_refMark_Down.Location = new System.Drawing.Point(164, 228);
            this.btn_refMark_Down.Name = "btn_refMark_Down";
            this.btn_refMark_Down.Size = new System.Drawing.Size(75, 23);
            this.btn_refMark_Down.TabIndex = 53;
            this.btn_refMark_Down.Text = "▼";
            this.btn_refMark_Down.UseVisualStyleBackColor = true;
            this.btn_refMark_Down.Click += new System.EventHandler(this.btn_refMark_Down_Click);
            // 
            // btn_refMark_Left
            // 
            this.btn_refMark_Left.Location = new System.Drawing.Point(83, 213);
            this.btn_refMark_Left.Name = "btn_refMark_Left";
            this.btn_refMark_Left.Size = new System.Drawing.Size(75, 23);
            this.btn_refMark_Left.TabIndex = 52;
            this.btn_refMark_Left.Text = "◀";
            this.btn_refMark_Left.UseVisualStyleBackColor = true;
            this.btn_refMark_Left.Click += new System.EventHandler(this.btn_refMark_Left_Click);
            // 
            // btn_refMark_Up
            // 
            this.btn_refMark_Up.Location = new System.Drawing.Point(164, 199);
            this.btn_refMark_Up.Name = "btn_refMark_Up";
            this.btn_refMark_Up.Size = new System.Drawing.Size(75, 23);
            this.btn_refMark_Up.TabIndex = 51;
            this.btn_refMark_Up.Text = "▲";
            this.btn_refMark_Up.UseVisualStyleBackColor = true;
            this.btn_refMark_Up.Click += new System.EventHandler(this.btn_refMark_Up_Click);
            // 
            // lb_patter3
            // 
            this.lb_patter3.AutoSize = true;
            this.lb_patter3.Location = new System.Drawing.Point(318, 336);
            this.lb_patter3.Name = "lb_patter3";
            this.lb_patter3.Size = new System.Drawing.Size(10, 13);
            this.lb_patter3.TabIndex = 49;
            this.lb_patter3.Text = "-";
            this.lb_patter3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_patter2
            // 
            this.lb_patter2.AutoSize = true;
            this.lb_patter2.Location = new System.Drawing.Point(228, 336);
            this.lb_patter2.Name = "lb_patter2";
            this.lb_patter2.Size = new System.Drawing.Size(10, 13);
            this.lb_patter2.TabIndex = 49;
            this.lb_patter2.Text = "-";
            this.lb_patter2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_patter1
            // 
            this.lb_patter1.AutoSize = true;
            this.lb_patter1.Location = new System.Drawing.Point(139, 336);
            this.lb_patter1.Name = "lb_patter1";
            this.lb_patter1.Size = new System.Drawing.Size(10, 13);
            this.lb_patter1.TabIndex = 49;
            this.lb_patter1.Text = "-";
            this.lb_patter1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_patter0
            // 
            this.lb_patter0.AutoSize = true;
            this.lb_patter0.Location = new System.Drawing.Point(50, 336);
            this.lb_patter0.Name = "lb_patter0";
            this.lb_patter0.Size = new System.Drawing.Size(10, 13);
            this.lb_patter0.TabIndex = 49;
            this.lb_patter0.Text = "-";
            this.lb_patter0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_Pre
            // 
            this.btn_Pre.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.btn_Pre.FlatAppearance.BorderSize = 0;
            this.btn_Pre.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_Pre.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_Pre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Pre.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btn_Pre.ForeColor = System.Drawing.Color.Red;
            this.btn_Pre.Location = new System.Drawing.Point(25, 279);
            this.btn_Pre.Name = "btn_Pre";
            this.btn_Pre.Size = new System.Drawing.Size(19, 53);
            this.btn_Pre.TabIndex = 48;
            this.btn_Pre.Text = "◀";
            this.btn_Pre.UseVisualStyleBackColor = true;
            this.btn_Pre.Click += new System.EventHandler(this.btn_Pre_Click);
            // 
            // btn_Next
            // 
            this.btn_Next.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.btn_Next.FlatAppearance.BorderSize = 0;
            this.btn_Next.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btn_Next.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_Next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Next.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btn_Next.ForeColor = System.Drawing.Color.Red;
            this.btn_Next.Location = new System.Drawing.Point(406, 279);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(19, 53);
            this.btn_Next.TabIndex = 48;
            this.btn_Next.Text = "▶";
            this.btn_Next.UseVisualStyleBackColor = true;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // chb_MaskOn
            // 
            this.chb_MaskOn.Appearance = System.Windows.Forms.Appearance.Button;
            this.chb_MaskOn.Checked = true;
            this.chb_MaskOn.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chb_MaskOn.Location = new System.Drawing.Point(218, 384);
            this.chb_MaskOn.Name = "chb_MaskOn";
            this.chb_MaskOn.Size = new System.Drawing.Size(114, 31);
            this.chb_MaskOn.TabIndex = 47;
            this.chb_MaskOn.Text = "Mask On";
            this.chb_MaskOn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chb_MaskOn.UseVisualStyleBackColor = true;
            this.chb_MaskOn.CheckedChanged += new System.EventHandler(this.chb_MaskOn_CheckedChanged);
            // 
            // chb_AutoIndex
            // 
            this.chb_AutoIndex.AutoSize = true;
            this.chb_AutoIndex.Location = new System.Drawing.Point(22, 257);
            this.chb_AutoIndex.Name = "chb_AutoIndex";
            this.chb_AutoIndex.Size = new System.Drawing.Size(95, 17);
            this.chb_AutoIndex.TabIndex = 45;
            this.chb_AutoIndex.Text = "Auto Index(+1)";
            this.chb_AutoIndex.UseVisualStyleBackColor = true;
            this.chb_AutoIndex.CheckedChanged += new System.EventHandler(this.chb_TempUseEdge_CheckedChanged);
            // 
            // chb_TempUseEdge
            // 
            this.chb_TempUseEdge.AutoSize = true;
            this.chb_TempUseEdge.Checked = true;
            this.chb_TempUseEdge.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chb_TempUseEdge.Location = new System.Drawing.Point(308, 257);
            this.chb_TempUseEdge.Name = "chb_TempUseEdge";
            this.chb_TempUseEdge.Size = new System.Drawing.Size(79, 17);
            this.chb_TempUseEdge.TabIndex = 45;
            this.chb_TempUseEdge.Text = "Draw Edge";
            this.chb_TempUseEdge.UseVisualStyleBackColor = true;
            this.chb_TempUseEdge.CheckedChanged += new System.EventHandler(this.chb_TempUseEdge_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(117, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(255, 13);
            this.label6.TabIndex = 30;
            this.label6.Text = "※ Image be masked when do drag mouse on pattern";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 30;
            this.label5.Text = "- Pattern :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // svd_SubPattern3
            // 
            this.svd_SubPattern3.Auto_Fit = false;
            this.svd_SubPattern3.AutoScroll = true;
            this.svd_SubPattern3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.svd_SubPattern3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.svd_SubPattern3.CurrentObject = null;
            this.svd_SubPattern3.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svd_SubPattern3.IsDisplayCenterLine = false;
            this.svd_SubPattern3.IsDisplayCoordinate = false;
            this.svd_SubPattern3.Location = new System.Drawing.Point(317, 279);
            this.svd_SubPattern3.Name = "svd_SubPattern3";
            this.svd_SubPattern3.Size = new System.Drawing.Size(83, 54);
            this.svd_SubPattern3.TabIndex = 16;
            this.svd_SubPattern3.ToastVisible = false;
            this.svd_SubPattern3.ZoomVisible = false;
            this.svd_SubPattern3.Click += new System.EventHandler(this.svd_SubPattern_Click);
            // 
            // svd_SubPattern2
            // 
            this.svd_SubPattern2.Auto_Fit = false;
            this.svd_SubPattern2.AutoScroll = true;
            this.svd_SubPattern2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.svd_SubPattern2.CurrentObject = null;
            this.svd_SubPattern2.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svd_SubPattern2.IsDisplayCenterLine = false;
            this.svd_SubPattern2.IsDisplayCoordinate = false;
            this.svd_SubPattern2.Location = new System.Drawing.Point(228, 279);
            this.svd_SubPattern2.Name = "svd_SubPattern2";
            this.svd_SubPattern2.Size = new System.Drawing.Size(83, 54);
            this.svd_SubPattern2.TabIndex = 16;
            this.svd_SubPattern2.ToastVisible = false;
            this.svd_SubPattern2.ZoomVisible = false;
            this.svd_SubPattern2.Click += new System.EventHandler(this.svd_SubPattern_Click);
            // 
            // svd_SubPattern1
            // 
            this.svd_SubPattern1.Auto_Fit = false;
            this.svd_SubPattern1.AutoScroll = true;
            this.svd_SubPattern1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.svd_SubPattern1.CurrentObject = null;
            this.svd_SubPattern1.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svd_SubPattern1.IsDisplayCenterLine = false;
            this.svd_SubPattern1.IsDisplayCoordinate = false;
            this.svd_SubPattern1.Location = new System.Drawing.Point(139, 279);
            this.svd_SubPattern1.Name = "svd_SubPattern1";
            this.svd_SubPattern1.Size = new System.Drawing.Size(83, 54);
            this.svd_SubPattern1.TabIndex = 16;
            this.svd_SubPattern1.ToastVisible = false;
            this.svd_SubPattern1.ZoomVisible = false;
            this.svd_SubPattern1.Click += new System.EventHandler(this.svd_SubPattern_Click);
            // 
            // svd_SubPattern0
            // 
            this.svd_SubPattern0.Auto_Fit = false;
            this.svd_SubPattern0.AutoScroll = true;
            this.svd_SubPattern0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.svd_SubPattern0.CurrentObject = null;
            this.svd_SubPattern0.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svd_SubPattern0.IsDisplayCenterLine = false;
            this.svd_SubPattern0.IsDisplayCoordinate = false;
            this.svd_SubPattern0.Location = new System.Drawing.Point(50, 279);
            this.svd_SubPattern0.Name = "svd_SubPattern0";
            this.svd_SubPattern0.Size = new System.Drawing.Size(83, 54);
            this.svd_SubPattern0.TabIndex = 16;
            this.svd_SubPattern0.ToastVisible = false;
            this.svd_SubPattern0.ZoomVisible = false;
            this.svd_SubPattern0.Click += new System.EventHandler(this.svd_SubPattern_Click);
            // 
            // svd_Template
            // 
            this.svd_Template.Auto_Fit = false;
            this.svd_Template.AutoScroll = true;
            this.svd_Template.CurrentObject = null;
            this.svd_Template.Cursor = System.Windows.Forms.Cursors.Cross;
            this.svd_Template.IsDisplayCenterLine = false;
            this.svd_Template.IsDisplayCoordinate = false;
            this.svd_Template.Location = new System.Drawing.Point(25, 26);
            this.svd_Template.Name = "svd_Template";
            this.svd_Template.Size = new System.Drawing.Size(340, 166);
            this.svd_Template.TabIndex = 16;
            this.svd_Template.ToastVisible = false;
            this.svd_Template.ZoomVisible = false;
            // 
            // btn_ResetMask
            // 
            this.btn_ResetMask.Location = new System.Drawing.Point(352, 384);
            this.btn_ResetMask.Name = "btn_ResetMask";
            this.btn_ResetMask.Size = new System.Drawing.Size(85, 32);
            this.btn_ResetMask.TabIndex = 14;
            this.btn_ResetMask.Text = "Reset Mask";
            this.btn_ResetMask.UseVisualStyleBackColor = true;
            this.btn_ResetMask.Click += new System.EventHandler(this.btn_ResetMask_Click);
            // 
            // btn_RefToCenter
            // 
            this.btn_RefToCenter.Location = new System.Drawing.Point(350, 347);
            this.btn_RefToCenter.Name = "btn_RefToCenter";
            this.btn_RefToCenter.Size = new System.Drawing.Size(87, 32);
            this.btn_RefToCenter.TabIndex = 14;
            this.btn_RefToCenter.Text = "Ref. To Center";
            this.btn_RefToCenter.UseVisualStyleBackColor = true;
            this.btn_RefToCenter.Click += new System.EventHandler(this.btn_RefToCenter_Click);
            // 
            // btn_LoadPattern
            // 
            this.btn_LoadPattern.Location = new System.Drawing.Point(368, 82);
            this.btn_LoadPattern.Margin = new System.Windows.Forms.Padding(0);
            this.btn_LoadPattern.Name = "btn_LoadPattern";
            this.btn_LoadPattern.Size = new System.Drawing.Size(69, 52);
            this.btn_LoadPattern.TabIndex = 12;
            this.btn_LoadPattern.Text = "Pattern Load";
            this.btn_LoadPattern.UseVisualStyleBackColor = true;
            this.btn_LoadPattern.Click += new System.EventHandler(this.btn_PatternLoad_Click);
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(368, 199);
            this.btn_Remove.Margin = new System.Windows.Forms.Padding(0);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(69, 52);
            this.btn_Remove.TabIndex = 12;
            this.btn_Remove.Text = "Pattern Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_PatternRemove_Click);
            // 
            // btn_AddPattern
            // 
            this.btn_AddPattern.Location = new System.Drawing.Point(368, 140);
            this.btn_AddPattern.Margin = new System.Windows.Forms.Padding(0);
            this.btn_AddPattern.Name = "btn_AddPattern";
            this.btn_AddPattern.Size = new System.Drawing.Size(69, 52);
            this.btn_AddPattern.TabIndex = 12;
            this.btn_AddPattern.Text = "Pattern Add";
            this.btn_AddPattern.UseVisualStyleBackColor = true;
            this.btn_AddPattern.Click += new System.EventHandler(this.btn_PatternAdd_Click);
            // 
            // btn_SavePattern
            // 
            this.btn_SavePattern.Location = new System.Drawing.Point(368, 25);
            this.btn_SavePattern.Margin = new System.Windows.Forms.Padding(0);
            this.btn_SavePattern.Name = "btn_SavePattern";
            this.btn_SavePattern.Size = new System.Drawing.Size(69, 52);
            this.btn_SavePattern.TabIndex = 12;
            this.btn_SavePattern.Text = "Pattern Save";
            this.btn_SavePattern.UseVisualStyleBackColor = true;
            this.btn_SavePattern.Click += new System.EventHandler(this.btn_PatternSave_Click);
            // 
            // btn_TemplateMatching_Grab
            // 
            this.btn_TemplateMatching_Grab.Location = new System.Drawing.Point(278, 346);
            this.btn_TemplateMatching_Grab.Name = "btn_TemplateMatching_Grab";
            this.btn_TemplateMatching_Grab.Size = new System.Drawing.Size(54, 32);
            this.btn_TemplateMatching_Grab.TabIndex = 12;
            this.btn_TemplateMatching_Grab.Text = "Train";
            this.btn_TemplateMatching_Grab.UseVisualStyleBackColor = true;
            this.btn_TemplateMatching_Grab.Click += new System.EventHandler(this.btn_TemplateMatching_Train_Click);
            // 
            // btn_Selected
            // 
            this.btn_Selected.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btn_Selected.FlatAppearance.BorderSize = 2;
            this.btn_Selected.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Selected.Location = new System.Drawing.Point(46, 278);
            this.btn_Selected.Name = "btn_Selected";
            this.btn_Selected.Size = new System.Drawing.Size(89, 58);
            this.btn_Selected.TabIndex = 50;
            this.btn_Selected.Text = "button1";
            this.btn_Selected.UseVisualStyleBackColor = true;
            // 
            // tp_Setting
            // 
            this.tp_Setting.Controls.Add(this.groupBox1);
            this.tp_Setting.Controls.Add(this.gb_Priority);
            this.tp_Setting.Controls.Add(this.gb_MatchingMethod);
            this.tp_Setting.Location = new System.Drawing.Point(4, 22);
            this.tp_Setting.Name = "tp_Setting";
            this.tp_Setting.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Setting.Size = new System.Drawing.Size(442, 426);
            this.tp_Setting.TabIndex = 2;
            this.tp_Setting.Text = "Setting";
            this.tp_Setting.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_TempScaleMax);
            this.groupBox1.Controls.Add(this.nud_TempScaleMin);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(7, 295);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(427, 53);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Scale";
            // 
            // nud_TempScaleMax
            // 
            this.nud_TempScaleMax.DecimalPlaces = 1;
            this.nud_TempScaleMax.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_TempScaleMax.Location = new System.Drawing.Point(130, 21);
            this.nud_TempScaleMax.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nud_TempScaleMax.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_TempScaleMax.Name = "nud_TempScaleMax";
            this.nud_TempScaleMax.Size = new System.Drawing.Size(67, 20);
            this.nud_TempScaleMax.TabIndex = 48;
            this.nud_TempScaleMax.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_TempScaleMax.ValueChanged += new System.EventHandler(this.nud_TempScaleMax_ValueChanged);
            // 
            // nud_TempScaleMin
            // 
            this.nud_TempScaleMin.DecimalPlaces = 1;
            this.nud_TempScaleMin.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_TempScaleMin.Location = new System.Drawing.Point(25, 21);
            this.nud_TempScaleMin.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nud_TempScaleMin.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nud_TempScaleMin.Name = "nud_TempScaleMin";
            this.nud_TempScaleMin.Size = new System.Drawing.Size(67, 20);
            this.nud_TempScaleMin.TabIndex = 48;
            this.nud_TempScaleMin.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_TempScaleMin.ValueChanged += new System.EventHandler(this.nud_TempScaleMin_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(102, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 13);
            this.label9.TabIndex = 36;
            this.label9.Text = "~";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gb_Priority
            // 
            this.gb_Priority.Controls.Add(this.cb_TemplPriority);
            this.gb_Priority.Controls.Add(this.nud_TMmaxCount);
            this.gb_Priority.Controls.Add(this.nud_templPCreteria);
            this.gb_Priority.Controls.Add(this.lb_templmaxcount);
            this.gb_Priority.Controls.Add(this.lb_TemplPriCre);
            this.gb_Priority.Controls.Add(this.lb_TemplPri);
            this.gb_Priority.Location = new System.Drawing.Point(7, 208);
            this.gb_Priority.Name = "gb_Priority";
            this.gb_Priority.Size = new System.Drawing.Size(427, 81);
            this.gb_Priority.TabIndex = 21;
            this.gb_Priority.TabStop = false;
            this.gb_Priority.Text = "Priority";
            // 
            // cb_TemplPriority
            // 
            this.cb_TemplPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_TemplPriority.FormattingEnabled = true;
            this.cb_TemplPriority.Location = new System.Drawing.Point(79, 21);
            this.cb_TemplPriority.Name = "cb_TemplPriority";
            this.cb_TemplPriority.Size = new System.Drawing.Size(123, 21);
            this.cb_TemplPriority.TabIndex = 22;
            // 
            // nud_TMmaxCount
            // 
            this.nud_TMmaxCount.Location = new System.Drawing.Point(327, 48);
            this.nud_TMmaxCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_TMmaxCount.Name = "nud_TMmaxCount";
            this.nud_TMmaxCount.Size = new System.Drawing.Size(67, 20);
            this.nud_TMmaxCount.TabIndex = 48;
            this.nud_TMmaxCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_templPCreteria
            // 
            this.nud_templPCreteria.DecimalPlaces = 2;
            this.nud_templPCreteria.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nud_templPCreteria.Location = new System.Drawing.Point(327, 22);
            this.nud_templPCreteria.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_templPCreteria.Name = "nud_templPCreteria";
            this.nud_templPCreteria.Size = new System.Drawing.Size(67, 20);
            this.nud_templPCreteria.TabIndex = 48;
            this.nud_templPCreteria.Value = new decimal(new int[] {
            100,
            0,
            0,
            131072});
            // 
            // lb_templmaxcount
            // 
            this.lb_templmaxcount.AutoSize = true;
            this.lb_templmaxcount.Location = new System.Drawing.Point(242, 50);
            this.lb_templmaxcount.Name = "lb_templmaxcount";
            this.lb_templmaxcount.Size = new System.Drawing.Size(67, 13);
            this.lb_templmaxcount.TabIndex = 36;
            this.lb_templmaxcount.Text = "Max Count : ";
            this.lb_templmaxcount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_TemplPriCre
            // 
            this.lb_TemplPriCre.AutoSize = true;
            this.lb_TemplPriCre.Location = new System.Drawing.Point(242, 24);
            this.lb_TemplPriCre.Name = "lb_TemplPriCre";
            this.lb_TemplPriCre.Size = new System.Drawing.Size(44, 13);
            this.lb_TemplPriCre.TabIndex = 36;
            this.lb_TemplPriCre.Text = "Score : ";
            this.lb_TemplPriCre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_TemplPri
            // 
            this.lb_TemplPri.AutoSize = true;
            this.lb_TemplPri.Location = new System.Drawing.Point(24, 23);
            this.lb_TemplPri.Name = "lb_TemplPri";
            this.lb_TemplPri.Size = new System.Drawing.Size(47, 13);
            this.lb_TemplPri.TabIndex = 34;
            this.lb_TemplPri.Text = "Priority : ";
            // 
            // gb_MatchingMethod
            // 
            this.gb_MatchingMethod.Controls.Add(this.cb_HalEdgeMode);
            this.gb_MatchingMethod.Controls.Add(this.label11);
            this.gb_MatchingMethod.Controls.Add(this.nud_pyramid);
            this.gb_MatchingMethod.Controls.Add(this.label10);
            this.gb_MatchingMethod.Controls.Add(this.chb_AutoParam);
            this.gb_MatchingMethod.Controls.Add(this.nud_templPrecision);
            this.gb_MatchingMethod.Controls.Add(this.nud_FirstStep);
            this.gb_MatchingMethod.Controls.Add(this.nud_Template_Method_Degree2);
            this.gb_MatchingMethod.Controls.Add(this.nud_Template_Method_Degree1);
            this.gb_MatchingMethod.Controls.Add(this.nud_Template_ScaleLast);
            this.gb_MatchingMethod.Controls.Add(this.nud_Template_ScaleFirst);
            this.gb_MatchingMethod.Controls.Add(this.label1);
            this.gb_MatchingMethod.Controls.Add(this.label4);
            this.gb_MatchingMethod.Controls.Add(this.label3);
            this.gb_MatchingMethod.Controls.Add(this.lbl_SclaeLast);
            this.gb_MatchingMethod.Controls.Add(this.lbl_ScaleFirst);
            this.gb_MatchingMethod.Controls.Add(this.lb_FirstStep);
            this.gb_MatchingMethod.Controls.Add(this.lb_TemplPrecision);
            this.gb_MatchingMethod.Controls.Add(this.label7);
            this.gb_MatchingMethod.Controls.Add(this.label2);
            this.gb_MatchingMethod.Controls.Add(this.label53);
            this.gb_MatchingMethod.Location = new System.Drawing.Point(7, 24);
            this.gb_MatchingMethod.Name = "gb_MatchingMethod";
            this.gb_MatchingMethod.Size = new System.Drawing.Size(427, 178);
            this.gb_MatchingMethod.TabIndex = 20;
            this.gb_MatchingMethod.TabStop = false;
            // 
            // cb_HalEdgeMode
            // 
            this.cb_HalEdgeMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_HalEdgeMode.FormattingEnabled = true;
            this.cb_HalEdgeMode.Location = new System.Drawing.Point(113, 135);
            this.cb_HalEdgeMode.Name = "cb_HalEdgeMode";
            this.cb_HalEdgeMode.Size = new System.Drawing.Size(109, 21);
            this.cb_HalEdgeMode.TabIndex = 51;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 140);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 13);
            this.label11.TabIndex = 52;
            this.label11.Text = "Hal Edge Mode : ";
            // 
            // nud_pyramid
            // 
            this.nud_pyramid.DecimalPlaces = 2;
            this.nud_pyramid.Location = new System.Drawing.Point(113, 109);
            this.nud_pyramid.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_pyramid.Name = "nud_pyramid";
            this.nud_pyramid.Size = new System.Drawing.Size(67, 20);
            this.nud_pyramid.TabIndex = 50;
            this.nud_pyramid.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 111);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 49;
            this.label10.Text = "Pyramid: ";
            // 
            // chb_AutoParam
            // 
            this.chb_AutoParam.AutoSize = true;
            this.chb_AutoParam.BackColor = System.Drawing.Color.White;
            this.chb_AutoParam.Location = new System.Drawing.Point(13, 0);
            this.chb_AutoParam.Name = "chb_AutoParam";
            this.chb_AutoParam.Size = new System.Drawing.Size(146, 17);
            this.chb_AutoParam.TabIndex = 22;
            this.chb_AutoParam.Text = "Auto Matching Parameter";
            this.chb_AutoParam.UseVisualStyleBackColor = false;
            this.chb_AutoParam.CheckedChanged += new System.EventHandler(this.chb_AutoParam_CheckedChanged);
            // 
            // nud_templPrecision
            // 
            this.nud_templPrecision.DecimalPlaces = 2;
            this.nud_templPrecision.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_templPrecision.Location = new System.Drawing.Point(318, 134);
            this.nud_templPrecision.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_templPrecision.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nud_templPrecision.Name = "nud_templPrecision";
            this.nud_templPrecision.Size = new System.Drawing.Size(67, 20);
            this.nud_templPrecision.TabIndex = 48;
            this.nud_templPrecision.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            // 
            // nud_FirstStep
            // 
            this.nud_FirstStep.DecimalPlaces = 2;
            this.nud_FirstStep.Location = new System.Drawing.Point(318, 107);
            this.nud_FirstStep.Name = "nud_FirstStep";
            this.nud_FirstStep.Size = new System.Drawing.Size(67, 20);
            this.nud_FirstStep.TabIndex = 48;
            // 
            // nud_Template_Method_Degree2
            // 
            this.nud_Template_Method_Degree2.Location = new System.Drawing.Point(318, 80);
            this.nud_Template_Method_Degree2.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_Template_Method_Degree2.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_Template_Method_Degree2.Name = "nud_Template_Method_Degree2";
            this.nud_Template_Method_Degree2.Size = new System.Drawing.Size(67, 20);
            this.nud_Template_Method_Degree2.TabIndex = 48;
            // 
            // nud_Template_Method_Degree1
            // 
            this.nud_Template_Method_Degree1.Location = new System.Drawing.Point(318, 55);
            this.nud_Template_Method_Degree1.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nud_Template_Method_Degree1.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nud_Template_Method_Degree1.Name = "nud_Template_Method_Degree1";
            this.nud_Template_Method_Degree1.Size = new System.Drawing.Size(67, 20);
            this.nud_Template_Method_Degree1.TabIndex = 48;
            // 
            // nud_Template_ScaleLast
            // 
            this.nud_Template_ScaleLast.DecimalPlaces = 2;
            this.nud_Template_ScaleLast.Location = new System.Drawing.Point(113, 76);
            this.nud_Template_ScaleLast.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nud_Template_ScaleLast.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Template_ScaleLast.Name = "nud_Template_ScaleLast";
            this.nud_Template_ScaleLast.Size = new System.Drawing.Size(67, 20);
            this.nud_Template_ScaleLast.TabIndex = 47;
            this.nud_Template_ScaleLast.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nud_Template_ScaleFirst
            // 
            this.nud_Template_ScaleFirst.DecimalPlaces = 2;
            this.nud_Template_ScaleFirst.Location = new System.Drawing.Point(113, 51);
            this.nud_Template_ScaleFirst.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Template_ScaleFirst.Name = "nud_Template_ScaleFirst";
            this.nud_Template_ScaleFirst.Size = new System.Drawing.Size(67, 20);
            this.nud_Template_ScaleFirst.TabIndex = 47;
            this.nud_Template_ScaleFirst.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "- Scale :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(49, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Last : ";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "First : ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_SclaeLast
            // 
            this.lbl_SclaeLast.AutoSize = true;
            this.lbl_SclaeLast.Location = new System.Drawing.Point(89, 78);
            this.lbl_SclaeLast.Name = "lbl_SclaeLast";
            this.lbl_SclaeLast.Size = new System.Drawing.Size(21, 13);
            this.lbl_SclaeLast.TabIndex = 30;
            this.lbl_SclaeLast.Text = "1 /";
            // 
            // lbl_ScaleFirst
            // 
            this.lbl_ScaleFirst.AutoSize = true;
            this.lbl_ScaleFirst.Location = new System.Drawing.Point(89, 53);
            this.lbl_ScaleFirst.Name = "lbl_ScaleFirst";
            this.lbl_ScaleFirst.Size = new System.Drawing.Size(21, 13);
            this.lbl_ScaleFirst.TabIndex = 30;
            this.lbl_ScaleFirst.Text = "1 /";
            // 
            // lb_FirstStep
            // 
            this.lb_FirstStep.AutoSize = true;
            this.lb_FirstStep.Location = new System.Drawing.Point(248, 109);
            this.lb_FirstStep.Name = "lb_FirstStep";
            this.lb_FirstStep.Size = new System.Drawing.Size(60, 13);
            this.lb_FirstStep.TabIndex = 26;
            this.lb_FirstStep.Text = "First Step : ";
            // 
            // lb_TemplPrecision
            // 
            this.lb_TemplPrecision.AutoSize = true;
            this.lb_TemplPrecision.Location = new System.Drawing.Point(248, 137);
            this.lb_TemplPrecision.Name = "lb_TemplPrecision";
            this.lb_TemplPrecision.Size = new System.Drawing.Size(59, 13);
            this.lb_TemplPrecision.TabIndex = 26;
            this.lb_TemplPrecision.Text = "Precision : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(274, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "+deg : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(260, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 26;
            this.label2.Text = "- Angle : ";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(274, 57);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(37, 13);
            this.label53.TabIndex = 26;
            this.label53.Text = "-deg : ";
            // 
            // MvTemplateMatchEdit
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MvTemplateMatchEdit";
            this.tabControl.ResumeLayout(false);
            this.tp_Train.ResumeLayout(false);
            this.tp_Train.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TempTHHigh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TempTHLow)).EndInit();
            this.tp_Setting.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TempScaleMax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TempScaleMin)).EndInit();
            this.gb_Priority.ResumeLayout(false);
            this.gb_Priority.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_TMmaxCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_templPCreteria)).EndInit();
            this.gb_MatchingMethod.ResumeLayout(false);
            this.gb_MatchingMethod.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_pyramid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_templPrecision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_FirstStep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Template_Method_Degree2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Template_Method_Degree1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Template_ScaleLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Template_ScaleFirst)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabPage tp_Train;
        private System.Windows.Forms.Button btn_RefToCenter;
        private System.Windows.Forms.Button btn_TemplateMatching_Grab;
        private System.Windows.Forms.TabPage tp_Setting;
        private System.Windows.Forms.GroupBox gb_Priority;
        private System.Windows.Forms.Label lb_templmaxcount;
        private System.Windows.Forms.Label lb_TemplPriCre;
        private System.Windows.Forms.Label lb_TemplPri;
        private System.Windows.Forms.GroupBox gb_MatchingMethod;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_SclaeLast;
        private System.Windows.Forms.Label lbl_ScaleFirst;
        private System.Windows.Forms.Label lb_FirstStep;
        private System.Windows.Forms.Label lb_TemplPrecision;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label5;
        private Display.MvDisplayViewInteract svd_Template;
        private System.Windows.Forms.CheckBox chb_TempUseEdge;
        private System.Windows.Forms.Label lbl_Tilda;
        private System.Windows.Forms.Button btn_ResetMask;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nud_TempTHHigh;
        private System.Windows.Forms.NumericUpDown nud_TempTHLow;
        private System.Windows.Forms.NumericUpDown nud_Template_ScaleLast;
        private System.Windows.Forms.NumericUpDown nud_Template_ScaleFirst;
        private System.Windows.Forms.NumericUpDown nud_templPrecision;
        private System.Windows.Forms.NumericUpDown nud_FirstStep;
        private System.Windows.Forms.NumericUpDown nud_Template_Method_Degree2;
        private System.Windows.Forms.NumericUpDown nud_Template_Method_Degree1;
        private System.Windows.Forms.NumericUpDown nud_TMmaxCount;
        private System.Windows.Forms.NumericUpDown nud_templPCreteria;
        private System.Windows.Forms.ComboBox cb_TemplPriority;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown nud_TempScaleMax;
        private System.Windows.Forms.NumericUpDown nud_TempScaleMin;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox chb_MaskOn;
        private System.Windows.Forms.CheckBox chb_AutoParam;
        private System.Windows.Forms.Button btn_SavePattern;
        private System.Windows.Forms.Button btn_LoadPattern;
        private System.Windows.Forms.Button btn_Pre;
        private System.Windows.Forms.Button btn_Next;
        private Display.MvDisplayViewInteract svd_SubPattern3;
        private Display.MvDisplayViewInteract svd_SubPattern2;
        private Display.MvDisplayViewInteract svd_SubPattern1;
        private Display.MvDisplayViewInteract svd_SubPattern0;
        private System.Windows.Forms.Button btn_AddPattern;
        private System.Windows.Forms.Label lb_patter3;
        private System.Windows.Forms.Label lb_patter2;
        private System.Windows.Forms.Label lb_patter1;
        private System.Windows.Forms.Label lb_patter0;
        private System.Windows.Forms.Button btn_Selected;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.CheckBox chb_AutoIndex;
        private System.Windows.Forms.Button btn_refMark_Right;
        private System.Windows.Forms.Button btn_refMark_Down;
        private System.Windows.Forms.Button btn_refMark_Left;
        private System.Windows.Forms.Button btn_refMark_Up;
        private System.Windows.Forms.ComboBox cb_MatchMode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chb_UseRegonMode;
        private System.Windows.Forms.ComboBox cb_HalEdgeMode;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown nud_pyramid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_grab;
    }
}
