﻿using HalconDotNet;
using MvCore.Core;
using MvCore.Display;
using MvCore.Edit.Base;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace MvCore.Edit
{
    public partial class MvTemplateMatchEdit : MvToolEditBase
    {
        MvRotationRectangle templateRegion;
        MvRotationRectangle RoiRegion;
        public MvTemplateMatchEdit()
        {
            InitializeComponent();
            InitBinding();

            this.SubjectChanged += SvTMEdit_SubjectChanged;
            this.SvDisplayViewEdit.SelectedImageChanged += SvDisplayViewEdit_SelectedImageChanged;

            //templateRegion = new SvRotationRectangle();


            mPatternDisplayList = new List<MvDisplayViewInteract>();
            mPatternDisplayList.Add(svd_SubPattern0);
            mPatternDisplayList.Add(svd_SubPattern1);
            mPatternDisplayList.Add(svd_SubPattern2);
            mPatternDisplayList.Add(svd_SubPattern3);

            mPatternLabelList = new List<Label>();
            mPatternLabelList.Add(lb_patter0);
            mPatternLabelList.Add(lb_patter1);
            mPatternLabelList.Add(lb_patter2);
            mPatternLabelList.Add(lb_patter3);
        }

        public override void formLoad()
        {
            if (Subject != null && SvDisplayViewEdit.Display.Image != null && SvDisplayViewEdit.Display.Image.Width > 0 && SvDisplayViewEdit.Display.Image.Height > 0)
            {
                if (Subject.RoiRegion == null)
                {
                    Subject.RoiRegion = new MvRotationRectangle(0, 0, SvDisplayViewEdit.Display.Image.Width, SvDisplayViewEdit.Display.Image.Height);
                }
                if (Subject.TemplateRegion == null)
                {
                    Subject.TemplateRegion = new MvRotationRectangle(SvDisplayViewEdit.Display.Image.Width / 2 - 100, SvDisplayViewEdit.Display.Image.Height / 2 - 100, 200, 200);
                }
                RoiRegion = Subject.RoiRegion;
                templateRegion = Subject.TemplateRegion;
            }
        }

        void SvDisplayViewEdit_SelectedImageChanged(object sender, SvImageInfo imageInfo)
        {
            if (imageInfo.ImageName.Contains("Train"))
            {
                if (Subject.InputImage == null) return;
                SvDisplayViewEdit.Display.Image = Subject.InputImage;
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(templateRegion);
            }
            else if (imageInfo.ImageName.Contains("InputImage"))
            {
                if (Subject.InputImage == null) return;
                SvDisplayViewEdit.Display.Image = Subject.InputImage;
                SvDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(RoiRegion);
            }
            //else if (imageInfo.ImageName.Contains("OutputImage"))
            //{
            //    if (SvDisplayViewEdit.Display.Image == null) return;
            //    DrawResult(SvDisplayViewEdit.Display);
            //}
        }


        protected override void InitDisplayViewEdit()
        {
            SvDisplayViewEdit.InsertCustomImage(1, new SvImageInfo("[TemplateMatch] Train"));
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public MvTemplateMatch Subject
        {
            get { return base.GetSubject() as MvTemplateMatch; }
            set { base.SetSubject(value); }
        }

        void SvTMEdit_SubjectChanged(object sender, MvToolBase tool)
        {
            if (Subject == null) { return; }
            source.DataSource = Subject;
            source.ResetBindings(true);

            svd_Template.Image = null;
            InitPatternList();
            SetTemplateImage(Subject.SelectedPatternIndex);

            ResetTepmplateGraphics();
        }

        void ResetTepmplateGraphics()
        {
            svd_Template.InteractiveGraphicsCollection.Clear();
            svd_Template.GraphicsCollection.Clear();

            if (Subject.TemplateImage == null)
            {
                return;
            }
            svd_Template.Image = Subject.TemplateImage;

            if (Subject.RefPoint != null)
            {
                //Subject.RefPoint.SelectionSize = (int)(10 / svd_Template.ZoomRatio);
                svd_Template.InteractiveGraphicsCollection.Add(Subject.RefPoint);
            }

            if (Subject.Mask != null && Subject.SelectedPatternIndex > -1 && Subject.mPatternDataList.Count > Subject.SelectedPatternIndex)
            {
                Subject.Mask = Subject.mPatternDataList[Subject.SelectedPatternIndex].Value.MaskImage;
                svd_Template.GraphicsCollection.Add(Subject.Mask);

                Subject.Mask.DrawMask = true;

                // 만약 Edge 사용한다면... Edge 표시
                //if (chb_TempUseEdge.Checked)
                //    nud_Threshold_ValueChanged(null, null);
                if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.Edge /*|| (MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.EdgePlus*/)
                {
                    nud_Threshold_ValueChanged(null, null);
                }


            }
        }

        BindingSource source;

        int mSelectedIndex;
        public int SelectedIndex
        {
            get { return mSelectedIndex; }
            set
            {
                if (mSelectedIndex == value) return;
                mSelectedIndex = value;
                SetTemplateImage(value);
                int refreshindex = value - 1;

                if (value == 0)
                    refreshindex = 0;

                RefreshPatternList(refreshindex);
            }
        }

        void InitBinding()
        {
            source = new BindingSource(typeof(MvTemplateMatch), null);
            nud_Template_ScaleFirst.DataBindings.Add("Value", source, "ScaleFirst", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_ScaleLast.DataBindings.Add("Value", source, "ScaleLast", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_Method_Degree1.DataBindings.Add("Value", source, "AngleNeg", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_Template_Method_Degree2.DataBindings.Add("Value", source, "AnglePos", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TMmaxCount.DataBindings.Add("Value", source, "MaxCount", true, DataSourceUpdateMode.OnPropertyChanged, 1);
            nud_FirstStep.DataBindings.Add("Value", source, "FirstStep", true, DataSourceUpdateMode.OnPropertyChanged);

            cb_TemplPriority.DisplayMember = "Key"; cb_TemplPriority.ValueMember = "Value";
            cb_TemplPriority.DataSource = Enum.GetValues(typeof(MvTemplateMatch.Direction)).Cast<MvTemplateMatch.Direction>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_TemplPriority.DataBindings.Add("SelectedValue", source, "Priority", true, DataSourceUpdateMode.OnPropertyChanged);

            cb_MatchMode.DisplayMember = "Key"; cb_MatchMode.ValueMember = "Value";
            cb_MatchMode.DataSource = Enum.GetValues(typeof(MvTemplateMatch.E_MatchMode)).Cast<MvTemplateMatch.E_MatchMode>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_MatchMode.DataBindings.Add("SelectedValue", source, "MatchMode", true, DataSourceUpdateMode.OnPropertyChanged);

            cb_HalEdgeMode.DisplayMember = "Key"; cb_HalEdgeMode.ValueMember = "Value";
            cb_HalEdgeMode.DataSource = Enum.GetValues(typeof(MvTemplateMatch.E_HalEdgeMode)).Cast<MvTemplateMatch.E_HalEdgeMode>().ToDictionary(obj => obj.ToString(), obj => obj).ToList();
            cb_HalEdgeMode.DataBindings.Add("SelectedValue", source, "HalEdgeMode", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_pyramid.DataBindings.Add("Value", source, "Pyramid", true, DataSourceUpdateMode.OnPropertyChanged);

            nud_templPCreteria.DataBindings.Add("Value", source, "PCreteria", true, DataSourceUpdateMode.OnPropertyChanged); //Score
            nud_templPrecision.DataBindings.Add("Value", source, "Precision", true, DataSourceUpdateMode.OnPropertyChanged);
            chb_TempUseEdge.DataBindings.Add("Checked", source, "UseEdge", true, DataSourceUpdateMode.OnPropertyChanged);
            chb_UseRegonMode.DataBindings.Add("Checked", source, "RegionMode", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempTHLow.DataBindings.Add("Value", source, "THLow", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempTHHigh.DataBindings.Add("Value", source, "THHigh", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempScaleMin.DataBindings.Add("Value", source, "TempScaleMin", true, DataSourceUpdateMode.OnPropertyChanged);
            nud_TempScaleMax.DataBindings.Add("Value", source, "TempScaleMax", true, DataSourceUpdateMode.OnPropertyChanged);
            chb_AutoParam.DataBindings.Add("Checked", source, "AutoParam", true, DataSourceUpdateMode.OnPropertyChanged);

            chb_AutoIndex.DataBindings.Add("Checked", source, "IsAutoIndex", true, DataSourceUpdateMode.OnPropertyChanged);
            this.DataBindings.Add("SelectedIndex", source, "SelectedPatternIndex", true, DataSourceUpdateMode.OnPropertyChanged);

            //chb_TempUseEdge.DataBindings.Add("Checked", source, "Mask.OnMask", true, DataSourceUpdateMode.OnPropertyChanged);
        }

        private void btn_grab_Click(object sender, EventArgs e)
        {
            SvImageInfo imageInfo = (SvImageInfo)SvDisplayViewEdit.imageListComboBox.SelectedItem;
            if (!imageInfo.ImageName.Contains("Train")) return;

            MvImage image = SvDisplayViewEdit.Display.Image;
            if (image == null) return;

            Mat templateImg = templateRegion.GetROIRegion(image.Mat);
            //Mat inputImg = RoiRegion.GetROIRegion(image.Mat);
            //Cv2.ImShow("inputimage", inputImg);
            //Cv2.WaitKey(1);
            if (templateImg == null)
            {
                //MessageBox.Show("선택된 이미지 영역이 없습니다.");
                MessageBox.Show("There does not select image.");
                return;
            }

            svd_Template.Image = new MvImage(templateImg);

            PatternData patterndata = new PatternData(svd_Template.Image);


            Subject.mPatternDataList.Insert(0, new KeyValuePair<string, PatternData>("", patterndata));
        }

        private void btn_TemplateMatching_Train_Click(object sender, EventArgs e)
        {
            //SvImageInfo imageInfo = (SvImageInfo)SvDisplayViewEdit.imageListComboBox.SelectedItem;
            //if (!imageInfo.ImageName.Contains("Train")) return;

            //MvImage image = SvDisplayViewEdit.Display.Image;
            //if (image == null) return;

            //Mat templateImg = templateRegion.GetROIRegion(image.Mat);
            ////Mat inputImg = RoiRegion.GetROIRegion(image.Mat);
            ////Cv2.ImShow("inputimage", inputImg);
            ////Cv2.WaitKey(1);
            //if (templateImg == null)
            //{
            //    //MessageBox.Show("선택된 이미지 영역이 없습니다.");
            //    MessageBox.Show("There does not select image.");
            //    return;
            //}

            //svd_Template.Image = new MvImage(templateImg);

            //PatternData patterndata = new PatternData(svd_Template.Image);


            //Subject.mPatternDataList.Insert(0, new KeyValuePair<string, PatternData>("", patterndata));
            //if (Subject.mPatternDataList.Count > )
            Subject.SelectedPatternIndex = 0;
            Subject.train();
            SetTemplateImage(0);
            RefreshPatternList();
            nud_Threshold_ValueChanged(this, null);
        }

        private void chb_TempUseEdge_CheckedChanged(object sender, EventArgs e)
        {
            //if (chb_TempUseEdge.Checked)
            //{
            //    //btn_ResetMask.Enabled = true;
            //    //chb_MaskOn.Enabled = true;
            //    svd_Template.GraphicsFuncCollection.Add(DrawEdgeImage);
            //    nud_Threshold_ValueChanged(this, null);
            //}
            //else
            //{
            //    //chb_MaskOn.Enabled = false;
            //    //btn_ResetMask.Enabled = false;
            //    svd_Template.GraphicsFuncCollection.Clear();
            //}
        }
        private void cb_MatchMode_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cb_MatchMode.SelectedValue == null) { return; }

            if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.Edge /*|| (MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.EdgePlus*/ || (MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.HEdge)
            {
                svd_Template.GraphicsFuncCollection.Add(DrawEdgeImage);
                nud_Threshold_ValueChanged(this, null);
            }
            else
            {
                svd_Template.GraphicsFuncCollection.Clear();
            }
            if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.HEdge || (MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.HNNC)
            {
                if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.HEdge)
                {
                    cb_HalEdgeMode.Enabled = true;
                    nud_pyramid.Enabled = true;
                }
                else
                {
                    cb_HalEdgeMode.Enabled = false;
                }
            }
            else
            {
                cb_HalEdgeMode.Enabled = false;
                nud_pyramid.Enabled = false;
            }

        }

        Mat Edge;

        void DrawEdgeImage(Graphics gdi)
        {
            if (Subject.TemplateImage == null || Edge == null) return;

            Bitmap bitmap;
            Mat maskedEdge = new Mat();

            Mat mask = Subject.Mask.MaskMat;
            Mat colorEdge = new Mat(mask.Size(), MatType.CV_8UC4);
            Mat nullMat = new Mat(mask.Size(), MatType.CV_8UC1, new Scalar(0));

            if (Edge.Type() != MatType.CV_8UC1) return;

            if (mask != null && mask.Width != 0 && mask.Height != 0)
            {
                Edge.CopyTo(maskedEdge, mask);
                Cv2.Merge(new Mat[] { nullMat, maskedEdge, nullMat, maskedEdge }, colorEdge);
                bitmap = colorEdge.ToBitmap();
            }
            else
            {
                Cv2.Merge(new Mat[] { nullMat, Edge, nullMat, Edge }, colorEdge);
                bitmap = colorEdge.ToBitmap();
            }

            gdi.DrawImageUnscaled(bitmap, 0, 0);

            nullMat.Dispose();
            colorEdge.Dispose();
            maskedEdge.Dispose();
            bitmap.Dispose();
        }


        private void btn_RefToCenter_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(svd_Template.Image.Width / 2, svd_Template.Image.Height / 2);
        }

        private void btn_ResetMask_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.Mask.ResetMask();
        }

        private void nud_Threshold_ValueChanged(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;
            //if (!chb_TempUseEdge.Checked) return;
            if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue != MvTemplateMatch.E_MatchMode.Edge && /*(MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue != MvTemplateMatch.E_MatchMode.EdgePlus &&*/ (MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue != MvTemplateMatch.E_MatchMode.HEdge) return;
            if (Subject.TemplateImage == null) return;
            Mat src = Subject.TemplateImage.Mat;

            int minSize = Math.Min(Math.Min(src.Width, src.Height), 1000);
            if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.Edge)
            {
                Subject.GetEdge(src, minSize, out Edge, 1);
            }
            //else if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.EdgePlus)
            //{
            //    Subject.GetEdge(src, out Edge, (int)nud_TempTHLow.Value, (int)nud_TempTHHigh.Value);
            //}
            else if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.HEdge)
            {
                Subject.GetEdge(src, out Edge);
            }
            else
            {
                return;
            }
            //SvFunc.ShowTestImg(Edge, 0.25);
            //src.Dispose();
            svd_Template.Invalidate();
        }

        private void nud_TempScaleMin_ValueChanged(object sender, EventArgs e)
        {
            if (nud_TempScaleMin.Value > nud_TempScaleMax.Value)
                nud_TempScaleMin.Value = nud_TempScaleMax.Value;
        }

        private void nud_TempScaleMax_ValueChanged(object sender, EventArgs e)
        {
            if (nud_TempScaleMax.Value < nud_TempScaleMin.Value)
                nud_TempScaleMax.Value = nud_TempScaleMin.Value;
        }

        private void chb_MaskOn_CheckedChanged(object sender, EventArgs e)
        {
            //Subject.Mask.OnMask = chb_MaskOn.Checked;

            //if (chb_MaskOn.Checked)
            //    chb_MaskOn.Text = "Mask On";
            //else
            //    chb_MaskOn.Text = "Mask Off";
            if (svd_Template.Image == null) return;

            svd_Template.GraphicsCollection.Clear();
            if (Subject.mPatternDataList.Count == 0) { return; }
            PatternData pattern = Subject.mPatternDataList[Subject.SelectedPatternIndex].Value;
            MvMaskingEdit maskedit = new MvMaskingEdit();
            MvMasking svMask = new MvMasking();
            MvToolEditForm maskform = new MvToolEditForm(maskedit);

            //maskedit.svDisplayViewEdit.Display.Image = pattern.PatternImage;
            //maskedit.svDisplayViewEdit.Display.InteractiveGraphicsCollection.Add(pattern.MaskImage);

            svMask.InputImage = pattern.PatternImage;
            svMask.Mask = pattern.MaskImage;
            pattern.MaskImage.DrawMask = true;

            maskedit.Subject = svMask;

            svMask.InitOutProperty();
            svMask.Run(true);
            maskform.ShowDialog();

            pattern.MaskImage.DrawMask = true;
            svd_Template.GraphicsCollection.Add(pattern.MaskImage);

            pattern.MakeMaskedPattern();


        }

        private void chb_AutoParam_CheckedChanged(object sender, EventArgs e)
        {
            bool autoCheck = chb_AutoParam.Checked;

            nud_FirstStep.ReadOnly = autoCheck;
            nud_templPrecision.ReadOnly = autoCheck;
            nud_Template_ScaleFirst.ReadOnly = autoCheck;
            nud_Template_ScaleLast.ReadOnly = autoCheck;
            nud_Template_Method_Degree1.ReadOnly = autoCheck;
            nud_Template_Method_Degree2.ReadOnly = autoCheck;
        }

        #region Pattern Save, Multi Pattern
        List<MvDisplayViewInteract> mPatternDisplayList = new List<MvDisplayViewInteract>();
        List<Label> mPatternLabelList = new List<Label>();

        private void btn_PatternSave_Click(object sender, EventArgs e)
        {
            if (svd_Template == null || svd_Template.Image == null || svd_Template.Image.Width == 0 || svd_Template.Image.Height == 0)
                return;
            //if (Subject.TemplateImage == null || Subject.TemplateImage.Mat == null || Subject.TemplateImage.Width == 0 || Subject.TemplateImage.Height == 0)
            //    return;

            SaveFileDialog fd = new SaveFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            this.Cursor = Cursors.WaitCursor;
            PatternData patternData = new PatternData(Subject.TemplateImage, Subject.Mask, Subject.RefPoint);

            // File Save
            patternData.SavePattern(fd.FileName);

            // Icon 만들기
            //using (Stream IconStream = System.IO.File.OpenWrite(fd.FileName))
            //{
            //    Bitmap bitmap = Subject.TemplateImage.Mat.ToBitmap(System.Drawing.Imaging.PixelFormat.Format24bppRgb);
            //    bitmap.SetResolution(72, 72);
            //    Icon icon = System.Drawing.Icon.FromHandle(bitmap.GetHicon());
            //    icon.Save(IconStream);
            //}
            this.Cursor = Cursors.Default;

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);
        }

        private void btn_PatternLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            fd.Multiselect = true;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            this.Cursor = Cursors.WaitCursor;

            for (int i = 0; i < Subject.mPatternDataList.Count; i++)
            {
                Subject.mPatternDataList[i].Value.Dispose();
            }

            Subject.mPatternDataList.Clear();
            Subject.mPatternDataList.Clear();

            foreach (string path in fd.FileNames)
            {
                Subject.mPatternDataList.Add(new KeyValuePair<string, PatternData>(path, (PatternData)serializer.Deserializing(path)));
            }

            InitPatternList();

            this.Cursor = Cursors.Default;

            lbl_CurrentJob.Text = System.IO.Path.GetFileNameWithoutExtension(fd.FileName);
        }

        private void btn_Pre_Click(object sender, EventArgs e)
        {
            //if (!lb_patter0.Text.Contains('.')) return; 
            string[] lb = lb_patter0.Text.Split('.');
            int startIndex;
            if (!int.TryParse(lb[0], out startIndex)) return;
            if (startIndex <= 0) return;
            startIndex--;

            RefreshPatternList(startIndex);
        }
        private void btn_Next_Click(object sender, EventArgs e)
        {
            if (!lb_patter0.Text.Contains('.')) return;
            string[] lb = lb_patter3.Text.Split('.');
            int endIndex;
            if (!int.TryParse(lb[0], out endIndex)) return;
            if (endIndex >= Subject.mPatternDataList.Count - 1) return;
            endIndex++;

            RefreshPatternList(endIndex - 3);
        }

        private void btn_PatternAdd_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog();
            fd.Filter = "Image files (*.pti)|*.pti";
            fd.FilterIndex = 1;
            fd.Multiselect = true;
            if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

            if (string.IsNullOrEmpty(fd.FileName)) return;

            foreach (string path in fd.FileNames)
            {
                if (Subject.mPatternDataList.FindIndex(x => x.Key == path) >= 0) continue;
                Subject.mPatternDataList.Add(new KeyValuePair<string, PatternData>(path, (PatternData)serializer.Deserializing(path)));
            }

            RefreshPatternList();
        }

        private void btn_PatternRemove_Click(object sender, EventArgs e)
        {
            if (Subject.mPatternDataList.Count > Subject.SelectedPatternIndex && Subject.SelectedPatternIndex >= 0)
            {
                Subject.mPatternDataList[Subject.SelectedPatternIndex].Value.Dispose();
                Subject.TemplateImage.Dispose();
                Subject.mPatternDataList.RemoveAt(Subject.SelectedPatternIndex);
            }

            if (Subject.SelectedPatternIndex >= Subject.mPatternDataList.Count)
                SetTemplateImage(Subject.mPatternDataList.Count - 1, false);

            RefreshPatternList();
        }

        private void InitPatternList()
        {
            for (int i = 0; i < 4; i++)
            {
                mPatternDisplayList[i].Image = null;
            }
            if (Subject != null)
                SetTemplateImage(Subject.SelectedPatternIndex, false);
            RefreshPatternList(0);
        }

        private void RefreshPatternList(int _startindex = -1)
        {
            if (Subject == null) { return; }
            int startindex = 0;
            if (_startindex < 0) // 동일 Index일 경우...-1, -2도 들어올 수 있음!!
            {
                if (!int.TryParse(lb_patter0.Text.Split('.')[0], out startindex))
                    _startindex = 0;
                else
                    _startindex = startindex;
            }

            for (int i = 0; i < mPatternDisplayList.Count; i++)
            {
                string labelName = (_startindex + i).ToString();
                if (_startindex + i < Subject.mPatternDataList.Count)
                    labelName += "." + System.IO.Path.GetFileNameWithoutExtension(Subject.mPatternDataList[_startindex + i].Key);
                mPatternLabelList[i].Text = labelName;
            }

            btn_Selected.Visible = false;

            for (int i = 0; i < mPatternDisplayList.Count; i++)
            {
                //if (!lb_patter0.Text.Contains('.')) return;
                string[] lb = lb_patter0.Text.Split('.');

                int startIndex;
                if (!int.TryParse(lb[0], out startIndex)) break;
                // 패턴이 없으면 패턴리스트에서 지워준다.
                if (startIndex + i >= Subject.mPatternDataList.Count)
                {
                    mPatternDisplayList[i].Image = null;
                    continue;
                }

                mPatternDisplayList[i].Image = Subject.mPatternDataList[startIndex + i].Value.PatternImage;
                mPatternDisplayList[i].FitToWindow();

                // 빨간 박스 표시
                if (startIndex + i == Subject.SelectedPatternIndex)
                {
                    btn_Selected.Visible = true;
                    btn_Selected.Location = new System.Drawing.Point(mPatternDisplayList[i].Location.X - 2, mPatternDisplayList[i].Location.Y - 2);
                }
            }

            svd_Template.Image = null;

            // 처리할 항목이 없으면 리턴
            if (Subject.mPatternDataList.Count == 0) return;

            // 화면에 현재 Pattern 표시
            if (Subject.SelectedPatternIndex > -1)
                SetTemplateImage(Subject.SelectedPatternIndex);
        }

        private void svd_SubPattern_Click(object sender, EventArgs e)
        {
            int selectedDisplayIndex;
            string lbName = (sender as MvDisplayViewInteract).Name;

            selectedDisplayIndex = int.Parse(lbName.Substring(lbName.Length - 1));
            int selectedIndex = int.Parse(mPatternLabelList[selectedDisplayIndex].Text.Split('.')[0]);

            RefreshPatternList();

            if (selectedIndex == Subject.SelectedPatternIndex) return;


            SetTemplateImage(selectedIndex);
        }

        private void SetTemplateImage(int _index, bool _saveMask = true)
        {
            if (Subject.mPatternDataList.Count <= _index) return;
            if (Subject.mPatternDataList.Count == 0) return;

            Subject.SelectedPatternIndex = _index;

            // 만약 Edge 사용한다면... Edge 표시
            //if (chb_TempUseEdge.Checked)
            //    nud_Threshold_ValueChanged(null, null);
            if ((MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.Edge /*|| (MvTemplateMatch.E_MatchMode)cb_MatchMode.SelectedValue == MvTemplateMatch.E_MatchMode.EdgePlus*/)
                nud_Threshold_ValueChanged(null, null);
            PatternData pattrnData;
            if (_index == -1)
                pattrnData = new PatternData(); // 모든 멤버가 null임
            else
                pattrnData = Subject.mPatternDataList[_index].Value;

            Subject.TemplateImage = pattrnData.PatternImage;
            Subject.Mask = pattrnData.MaskImage;
            Subject.RefPoint = pattrnData.RefPoint;

            // 이코드가 있어야 현재 Subject.Refpoint를 화면에 뿌려주게 된다.
            //Subject.mPatternDataList[Subject.mSelectedPatternIndex].Value.RefPoint = Subject.RefPoint;


            ResetTepmplateGraphics();
        }

        #endregion

        private void btn_refMark_Up_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X, Subject.RefPoint.PointF.Y - 1);
        }

        private void btn_refMark_Down_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X, Subject.RefPoint.PointF.Y + 1);
        }

        private void btn_refMark_Left_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X - 1, Subject.RefPoint.PointF.Y);
        }

        private void btn_refMark_Right_Click(object sender, EventArgs e)
        {
            if (svd_Template.Image == null) return;

            Subject.RefPoint.PointF = new PointF(Subject.RefPoint.PointF.X + 1, Subject.RefPoint.PointF.Y);
        }


    }
}
