﻿using MvCore.Display;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MvCore
{
    [Serializable]
    public class MvCircle : InteractDrawObject
    {
        private enum SelectionPoint
        {
            None,
            Center,
            R

                //,Width
                //,Height
        }

        private Color color = Color.Red;

        //private float width;

        //private float height;

        //private Point2d sp;

        //private Point2d ep;

        private int direction;

        private Point2d center;

        private SelectionPoint selectionPoint;
        [NonSerialized]
        private Point2f[] selectionPoints = new Point2f[3];

        [Browsable(false)]
        public Color Color
        {
            get
            {
                return color;
            }
            set
            {
                color = value;
            }
        }
        private float r;
        [TypeConverter(typeof(FloatTypeConverter))]
        [FormattedFloatFormatString("F3")]
        public float R
        {
            get { return r; }
            set { r = value; }
        }


        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        private double startAngle;

        public double StartAngle
        {
            get { return startAngle; }
            set { startAngle = value; }
        }
        private double endAngle;

        public double EndAngle
        {
            get { return endAngle; }
            set { endAngle = value; }
        }
        //private float radius;

        //public float Radius
        //{
        //    get 
        //    {
        //        radius = height;
        //        return radius; 
        //    }
        //    set 
        //    {
        //        height = value;
        //        width = value;
        //        radius = value; 
        //    }
        //}


        private double thetaAngle;

        public double ThetaAngle
        {
            get { return thetaAngle; }
            set { thetaAngle = value; }
        }



        //[Browsable(false)]

        public Point2d Center
        {
            get
            {
                return center;
            }
            set
            {
                center = value;
            }
        }

        [TypeConverter(typeof(FloatTypeConverter))]
        [FormattedFloatFormatString("F3")]
        public float CenterX
        {
            get
            {
                return (float)center.X;
            }
            set
            {
                center.X = value;
            }
        }

        [TypeConverter(typeof(FloatTypeConverter))]
        [FormattedFloatFormatString("F3")]
        public float CenterY
        {
            get
            {
                return (float)center.Y;
            }
            set
            {
                center.Y = value;
            }
        }

        //[TypeConverter(typeof(FloatTypeConverter))]
        //[FormattedFloatFormatString("F3")]
        //public float Height
        //{
        //    get
        //    {
        //        return height;
        //    }
        //    set
        //    {
        //        height = value;
        //    }
        //}

        //[TypeConverter(typeof(FloatTypeConverter))]
        //[FormattedFloatFormatString("F3")]
        //public float Width
        //{
        //    get
        //    {
        //        return width;
        //    }
        //    set
        //    {
        //        width = value;
        //    }
        //}

        //[TypeConverter(typeof(FloatTypeConverter))]
        //[FormattedFloatFormatString("F3")]
        //public Point2d SP
        //{
        //    get
        //    {
        //        return sp;
        //    }
        //    set
        //    {
        //        sp = value;
        //    }
        //}

        //[TypeConverter(typeof(FloatTypeConverter))]
        //[FormattedFloatFormatString("F3")]
        //public Point2d EP
        //{
        //    get
        //    {
        //        return ep;
        //    }
        //    set
        //    {
        //        ep = value;
        //    }
        //}

        [Browsable(false)]
        public PointF CenterF
        {
            get
            {
                return new PointF((float)Center.X, (float)Center.Y);
            }
            set
            {
                center.X = value.X;
                center.Y = value.Y;
                Center = new Point2d(value.X, value.Y);
            }
        }

        public override MvDisplayViewInteract Display
        {
            get
            {
                return display;
            }
            set
            {
                display = value;
            }
        }

        public MvCircle()
        {
            //width = 300f;
            //height = 300f;
            R = 300f;
            if (display != null && display.Width != 0 && display.Height != 0)
            {
                Center = new Point2d(display.Width/2, display.Height/2);
            }
            else
            {
                Center = new Point2d(100.0, 100.0);
            }
            startAngle = 0;
            endAngle = 360;
            //sp = new Point2d(10,50) ;
            //ep = new Point2d(50,50);
        }

        public override string ToString()
        {
            return "Ellipse";
        }

        public MvCircle(Point2d center, float width, float r)
            : this()
        {
            this.center = center;
            this.r = r;
            //this.width = width;
            //this.height = height;
        }

        public double GetLineLength()
        {
            return (double)((EndAngle - StartAngle) / 360f) * Math.PI * 2.0 * (double)R;
            //return (double)123;

        }

        public override bool FindPoint(PointF mouseLocation)
        {
            if (base.IsPositionChange)
            {
                switch (selectionPoint)
                {
                    case SelectionPoint.Center:
                        CenterF = mouseLocation;
                        break;
                    case SelectionPoint.R:
                        R = (float)Math.Abs((double)mouseLocation.X - Center.X) * 2f;
                        break;
                    //case SelectionPoint.Height:
                    //    Height = (float)Math.Abs((double)mouseLocation.Y - Center.Y) * 2f;
                    //    break;
                }

                return true;
            }

            int num = -1;
            double num2 = double.MaxValue;
            Point2f point2f = FixtureToImage2F(new Point2f(mouseLocation.X, mouseLocation.Y), base.TransformMat);
            if (selectionPoints == null) return false;
            for (int i = 0; i < selectionPoints.Length; i++)
            {
                double num3 = point2f.DistanceTo(selectionPoints[i]);
                if (num3 <= num2)
                {
                    num = i;
                    num2 = num3;
                }
            }

            if (num2 > (double)base.SelectionSize)
            {
                num = -1;
            }

            switch (num)
            {
                case -1:
                    display.Cursor = Cursors.Arrow;
                    selectionPoint = SelectionPoint.None;
                    return false;
                case 0:
                    display.Cursor = Cursors.SizeAll;
                    selectionPoint = SelectionPoint.Center;
                    break;
                case 1:
                    display.Cursor = Cursors.SizeWE;
                    selectionPoint = SelectionPoint.R;
                    break;
                //case 2:
                //    display.Cursor = Cursors.SizeNS;
                //    selectionPoint = SelectionPoint.Height;
                //    break;
            }

            return true;
        }

        public override void SelectPoint()
        {
            if (selectionPoint != 0)
            {
                base.IsPositionChange = true;
            }
        }

        public override void ResetSelectedPoint()
        {
            base.IsPositionChange = false;
            selectionPoint = SelectionPoint.None;
        }

        public override void Draw(Graphics gdi)
        {
             
            if (color.IsEmpty)
            {
                color = Color.Red;
            }

            if (selectionPoints == null)
            {
                selectionPoints = new Point2f[3];
            }

            selectionPoints[0] = new Point2f(CenterF.X, CenterF.Y);
            //selectionPoints[1] = new Point2f(CenterF.X + Width / 2f, CenterF.Y);
            //selectionPoints[2] = new Point2f(CenterF.X, CenterF.Y - Height / 2f);
            selectionPoints[1] = new Point2f(CenterF.X + R / 2f, CenterF.Y);
            selectionPoints[2] = new Point2f(CenterF.X, CenterF.Y - R / 2f);
            Pen pen = new Pen(color);
            float num = Math.Abs((selectionPoints[1] - selectionPoints[0]).X);
            float num2 = Math.Abs((selectionPoints[2] - selectionPoints[0]).Y);
            gdi.DrawEllipse(pen, selectionPoints[0].X - num, selectionPoints[0].Y - num2, 2f * num, 2f * num2);
            gdi.DrawEllipse(Pens.LimeGreen, selectionPoints[0].X - (float)(base.SelectionSize / 2), selectionPoints[0].Y - (float)(base.SelectionSize / 2), base.SelectionSize, base.SelectionSize);
           gdi.DrawEllipse(Pens.LimeGreen, selectionPoints[1].X - (float)(base.SelectionSize / 2), selectionPoints[1].Y - (float)(base.SelectionSize / 2), base.SelectionSize, base.SelectionSize);
            //gdi.DrawEllipse(Pens.LimeGreen, selectionPoints[2].X - (float)(base.SelectionSize / 2), selectionPoints[2].Y - (float)(base.SelectionSize / 2), base.SelectionSize, base.SelectionSize);
        }

        public MvCircle Clone()
        {
            if (this == null)
            {
                return null;
            }

            return new MvCircle
            {
                Center = center,
                R = r,
                //Height = height,
                //Width = width,
                //SP = SP,
                //EP = EP,
                TransformMat = base.TransformMat
            };
        }
        public static Point2f FixtureToImage2F(Point2f point, Mat mat)
        {
            if (mat == null)
            {
                return point;
            }

            Mat mat2 = mat.Inv();
            return ImageToFixture2F(point, mat2);
        }
        public static Point2f ImageToFixture2F(Point2f point, Mat mat)
        {
            Point2d point2d = ImageToFixture2D(new Point2d(point.X, point.Y), mat);
            return new Point2f((float)point2d.X, (float)point2d.Y);
        }
        public static Point2d ImageToFixture2D(Point2d point, Mat mat)
        {
            if (mat == null)
            {
                return point;
            }

            Point2d result = default(Point2d);
            Mat mat2 = new Mat(3, 1, MatType.CV_32FC1);
            mat2.Set(0, 0, (float)point.X);
            mat2.Set(1, 0, (float)point.Y);
            mat2.Set(2, 0, 1f);
            Mat mat3 = mat * mat2;
            result.X = (double)mat3.Get<float>(0, 0) / (double)mat3.Get<float>(2, 0);
            result.Y = (double)mat3.Get<float>(1, 0) / (double)mat3.Get<float>(2, 0);
            return result;
        }
    }
    public class FloatTypeConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            if (!(sourceType == typeof(string)))
            {
                return sourceType == typeof(float);
            }

            return true;
        }

        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            if (!(destinationType == typeof(string)))
            {
                return destinationType == typeof(float);
            }

            return true;
        }

        public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is float)
            {
                return value;
            }

            if (value is string s)
            {
                return float.Parse(s);
            }

            return null;
        }

        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType != typeof(string))
            {
                return null;
            }

            if (value is float)
            {
                PropertyDescriptor propertyDescriptor = context.PropertyDescriptor;
                if (propertyDescriptor != null)
                {
                    FormattedFloatFormatString formattedFloatFormatString = propertyDescriptor.Attributes.OfType<FormattedFloatFormatString>().FirstOrDefault();
                    if (formattedFloatFormatString != null)
                    {
                        return ((float)value).ToString(formattedFloatFormatString.FormatString);
                    }

                    return ((float)value).ToString();
                }
            }

            return null;
        }

    }
    [AttributeUsage(AttributeTargets.Property)]
    public class FormattedFloatFormatString : Attribute
    {
        public string FormatString { get; private set; }

        public FormattedFloatFormatString(string formatString)
        {
            FormatString = formatString;
        }
    }
}
