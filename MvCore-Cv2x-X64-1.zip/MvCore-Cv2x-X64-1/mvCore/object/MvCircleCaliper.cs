﻿using MvCore.Display;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using System.Windows.Forms.VisualStyles;
using static MvCore.MvLineCaliper;

namespace MvCore
{
    [Serializable]
    public class MvCircleCaliper : InteractDrawObject
    {
        private enum SelectionPoint
        {
            None,
            SP,
            MP,
            EP,
            CP
        }
        public enum CaliperPriority { Peak, First, Last, Pos }
        public enum EdgePolarity { Dark_to_Light, Light_to_Dark, Any_Polarity };
        public enum EDirection
        {
            Outer = -1,
            Inner = 1
        }

        private int numberOfCaliper;

        private float searchLength;

        private float projectionLength;

        private EdgePolarity edgePolarity;

        private CaliperPriority priority;

        private int filterHalfSize;

        private int filterSize;

        private float minContrastThreshold;

        private EDirection direction = EDirection.Inner;

        private MvCircle circle = new MvCircle();

        [NonSerialized]
        [CompilerGenerated]
        private PropertyChangedEventHandler EPropChangedHandler;

        [NonSerialized]
        [CompilerGenerated]
        private EventHandler ENumberOfCaliperChanged;

        [NonSerialized]
        private Mat prewittFilter;

        private SelectionPoint selectionPoint;

        [NonSerialized]
        private PointF[] selectionPoints;

        [Description("Number Of Caliper (value > 3)")]
      

        private int upDownValueEditor;

        public int UpDownValueEditor
        {
            get { return upDownValueEditor; }
            set { upDownValueEditor = value; }
        }

        public int NumberOfCaliper
        {
            get
            {
                return numberOfCaliper;
            }
            set
            {
                if (value >= 4 && numberOfCaliper != value)
                {
                    numberOfCaliper = value;
                    OnRefresh(this, null);
                    if (ENumberOfCaliperChanged != null)
                    {
                        ENumberOfCaliperChanged(this, null);
                    }

                    NotifyPropertyChanged("NumberOfCaliper");
                }
            }
        }

        [Description("Search Length (value > 4)")]
        [PropertyOrder(52)]
        public float SearchLength
        {
            get
            {
                return searchLength;
            }
            set
            {
                if (!(value < 5f) && searchLength != value)
                {
                    searchLength = value;
                    OnRefresh(this, null);
                    NotifyPropertyChanged("SearchLength");
                }
            }
        }

        [Description("Projection Length (value > 4)")]
        [PropertyOrder(53)]
        public float ProjectionLength
        {
            get
            {
                return projectionLength;
            }
            set
            {
                if (!(value < 5f) && projectionLength != value)
                {
                    projectionLength = value;
                    OnRefresh(this, null);
                    NotifyPropertyChanged("ProjectionLength");
                }
            }
        }

        [Description("Polarity")]
        [PropertyOrder(54)]
        public EdgePolarity Polarity
        {
            get
            {
                return edgePolarity;
            }
            set
            {
                edgePolarity = value;
                OnRefresh(this, null);
                NotifyPropertyChanged("Polarity");
            }
        }

        [Description("Priority")]
        [PropertyOrder(55)]
        public CaliperPriority Priority
        {
            get
            {
                return priority;
            }
            set
            {
                priority = value;
                OnRefresh(this, null);
                NotifyPropertyChanged("Priority");
            }
        }

        [Description("FilterHalfSize")]
        [PropertyOrder(56)]
       
        public int FilterHalfSize
        {
            get
            {
                return filterHalfSize;
            }
            set
            {
                if (value < 1)
                {
                    return;
                }

                if (filterHalfSize != value)
                {
                    NotifyPropertyChanged("FilterHalfSize");
                }

                filterHalfSize = value;
                filterSize = filterHalfSize * 2 + 1;
                if (prewittFilter != null)
                {
                    prewittFilter.Dispose();
                }

                float[] array = new float[filterSize];
                for (int i = 0; i < filterSize; i++)
                {
                    if (i < filterHalfSize)
                    {
                        array[i] = -1f / (float)filterSize * 5f;
                    }
                    else if (i == filterHalfSize)
                    {
                        array[i] = 0f;
                    }
                    else
                    {
                        array[i] = 1f / (float)filterSize * 5f;
                    }
                }

                prewittFilter = new Mat(filterSize, 1, 5, array, 0L);
            }
        }

        [Description("MinContrastThreshold (0~255)")]
        [PropertyOrder(57)]
        public float MinContrastThreshold
        {
            get
            {
                return minContrastThreshold;
            }
            set
            {
                if (minContrastThreshold != value && !(value < 0f) && !(value > 255f))
                {
                    minContrastThreshold = value;
                    NotifyPropertyChanged("MinContrastThreshold");
                }
            }
        }

        [Description("Search Direction")]
        [PropertyOrder(58)]
        public EDirection Direction
        {
            get
            {
                return direction;
            }
            set
            {
                if (direction != value)
                {
                    direction = value;
                    OnRefresh(this, null);
                    NotifyPropertyChanged("Direction");
                }
            }
        }

        [TypeConverter(typeof(ExpandableObjectConverter))]
        [PropertyOrder(59)]
        [ReadOnly(true)]
        public MvCircle Circle
        {
            get
            {
                return circle;
            }
            set
            {
                circle = value;
                OnRefresh(this, null);
            }
        }

        [Browsable(false)]
        private float radius ;
        public float Radius
        {
            get
            {
                return radius;
            }
            set
            {
                //Circle.Width = value;
                //Circle.Height = value;
                Circle.R = value;
                radius = value;

            }
        }

        //[Browsable(false)]
        //private float height;

        //public float Height
        //{
        //    get { return height; }
        //    set { height = value; }
        //}
        //[Browsable(false)]
        //private float width;

        //public float  Width
        //{
        //    get { return width; }
        //    set { width = value; }
        //}




        [Browsable(false)]
        public PointF SP //Start Point ARC
        {
            get
            {
                return new PointF((float)(circle.Center.X + (double)circle.R * Math.Cos((double)StartAngle * Math.PI / 180.0)), (float)(circle.Center.Y + (double)circle.R * Math.Sin((double)StartAngle * Math.PI / 180.0)));
            }
            set
            {
                Radius = (float)Math.Sqrt(Math.Pow(value.X - CP.X, 2.0) + Math.Pow(value.Y - CP.Y, 2.0));
            }
        }

        [Browsable(false)]
        public PointF MP //Mid Point ARC
        {
            get
            {
                return new PointF((float)(circle.Center.X + (double)circle.R * Math.Cos((double)((circle.StartAngle + circle.EndAngle) / 2f) * Math.PI / 180.0)), (float)(circle.Center.Y + (double)circle.R * Math.Sin((double)((circle.StartAngle + circle.EndAngle) / 2f) * Math.PI / 180.0)));
            }
            set
            {
                Radius = (float)Math.Sqrt(Math.Pow(value.X - CP.X, 2.0) + Math.Pow(value.Y - CP.Y, 2.0));
            }
        }

        [Browsable(false)]
        public PointF EP //End Point ARC
        {
            get
            {
                return new PointF((float)(circle.Center.X + (double)circle.R * Math.Cos((double)circle.EndAngle * Math.PI / 180.0)), (float)(circle.Center.Y + (double)circle.R * Math.Sin((double)circle.EndAngle * Math.PI / 180.0)));
            }
            set
            {
                Radius = (float)Math.Sqrt(Math.Pow(value.X - CP.X, 2.0) + Math.Pow(value.Y - CP.Y, 2.0));
            }
        }

        [Browsable(false)]

        private float cx;

        public float CX
        {
            get
            {
                cx = CP.X;
                return cx; 
            }
            set 
            {
                cx = value;
                CP = new PointF(cx, CP.Y);
                circle.CenterF = CP;
            }
        }
        private float cy;

        public float CY
        {       
            get 
            {
                cy = CP.Y;
                return cy; 
            }
            set
            {

                cy = value;
                CP = new PointF(CP.X, cy);
                circle.CenterF = CP;
            }
        }


        private PointF cp;
        public PointF CP
        {
            get
            {
                cp = circle.CenterF; 
                return cp;
            }
            set
            {
                circle.CenterF = value;
                cp = value;
                //Console.WriteLine(value);

            }
        }

        public override MvDisplayViewInteract Display
        {
            get
            {
                return display;
            }
            set
            {
                display = value;
            }
        }

        [Browsable(false)]
        private double startAngle;
        public double StartAngle
        {
            get
            {
                startAngle =  circle.StartAngle;
                return startAngle;
            }
            set
            {
                startAngle = value;
                circle.StartAngle = value;
            }
        }

        [Browsable(false)]
        private double endAngle;
        public double EndAngle
        {
            get
            {
                endAngle = circle.EndAngle;
                return endAngle;
            }
            set
            {
                endAngle = value;
                circle.EndAngle = value;

            }
        }

        public event PropertyChangedEventHandler PropertyChanged
        {
            [CompilerGenerated]
            add
            {
                PropertyChangedEventHandler propertyChangedEventHandler = EPropChangedHandler;
                PropertyChangedEventHandler propertyChangedEventHandler2;
                do
                {
                    propertyChangedEventHandler2 = propertyChangedEventHandler;
                    PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
                    propertyChangedEventHandler = Interlocked.CompareExchange(ref EPropChangedHandler, value2, propertyChangedEventHandler2);
                }
                while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
            }
            [CompilerGenerated]
            remove
            {
                PropertyChangedEventHandler propertyChangedEventHandler = EPropChangedHandler;
                PropertyChangedEventHandler propertyChangedEventHandler2;
                do
                {
                    propertyChangedEventHandler2 = propertyChangedEventHandler;
                    PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
                    propertyChangedEventHandler = Interlocked.CompareExchange(ref EPropChangedHandler, value2, propertyChangedEventHandler2);
                }
                while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
            }
        }

        public event EventHandler NumberOfCaliperChanged
        {
            [CompilerGenerated]
            add
            {
                EventHandler eventHandler = ENumberOfCaliperChanged;
                EventHandler eventHandler2;
                do
                {
                    eventHandler2 = eventHandler;
                    EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
                    eventHandler = Interlocked.CompareExchange(ref ENumberOfCaliperChanged, value2, eventHandler2);
                }
                while ((object)eventHandler != eventHandler2);
            }
            [CompilerGenerated]
            remove
            {
                EventHandler eventHandler = ENumberOfCaliperChanged;
                EventHandler eventHandler2;
                do
                {
                    eventHandler2 = eventHandler;
                    EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
                    eventHandler = Interlocked.CompareExchange(ref ENumberOfCaliperChanged, value2, eventHandler2);
                }
                while ((object)eventHandler != eventHandler2);
            }
        }

        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
           
        }

        public override string ToString()
        {
            return "CircleCaliper";
        }

        public MvCircleCaliper()
        {
            numberOfCaliper = 20;
            searchLength = 100f;
            projectionLength = 4f;
            filterHalfSize = 1;
            filterSize = 3;
            prewittFilter = new Mat(filterSize, 1, 5, new float[3] { -1f, 0f, 1f }, 0L);
            minContrastThreshold = 20f;
            edgePolarity = EdgePolarity.Dark_to_Light;
            radius = 100;
         
            
          
        }

        public MvCircleCaliper(MvCircle circle)
            : this()
        {
            circle = circle;
        }

        public List<Point3f> CalCaliperPoints(Mat srcImg)
        {
            if (srcImg.Width == 0 || srcImg.Height == 0)
            {
                return new List<Point3f>();
            }

            _ = circle.GetLineLength() / (double)numberOfCaliper;
            List<Point3f> list = new List<Point3f>(numberOfCaliper);
            for (int i = 0; i < numberOfCaliper; i++)
            {
                double num = (double)(circle.StartAngle + (circle.EndAngle - circle.StartAngle) / (float)(numberOfCaliper - 1) * (float)i) * Math.PI / 180.0;
                Mat mat = new Mat();
                Point2f center = new Point2f((float)(circle.Center.X + (double)circle.R * Math.Cos(num)), (float)(circle.Center.Y + (double)circle.R * Math.Sin(num)));
                OpenCvSharp.CPlusPlus.Size dsize = new OpenCvSharp.CPlusPlus.Size(projectionLength, searchLength);
                Mat rotationMatrix2D = Cv2.GetRotationMatrix2D(center, num * 180.0 / Math.PI + (double)(90 * (int)Direction), 1.0);
                rotationMatrix2D.Set(0, 2, rotationMatrix2D.At<double>(0, 2) - (double)center.X);
                rotationMatrix2D.Set(1, 2, rotationMatrix2D.At<double>(1, 2) - (double)center.Y + (double)(searchLength / 2f));
                Cv2.WarpAffine(srcImg, mat, rotationMatrix2D, dsize,Interpolation.Linear,OpenCvSharp.BorderType.Replicate);
                rotationMatrix2D.Dispose();
                //MatIndexer<byte> caliperIndexer = caliperMat.GetIndexer();

                //Mat caliperMat = new Mat(rotationImg, caliperRegion);
                //var caliperIndexer = caliperMat.GetGenericIndexer<byte>();
                //Mat projectionMat = new Mat(caliperMat.Height, 1, MatType.CV_32FC1);
                //var indexer = projectionMat.GetGenericIndexer<float>();


                //Mat<byte> mat2 = new Mat<byte>(mat);
                //MatIndexer<byte> indexer = mat2.GetIndexer();
                //Mat<float> mat3 = new Mat<float>(mat2.Height, 1);
                //MatIndexer<float> indexer2 = mat3.GetIndexer();


                Mat mat2 = mat.Clone();
                MatIndexer<byte> indexer = mat2.GetGenericIndexer<byte>();

                Mat mat3 = new Mat(mat.Height, 1, MatType.CV_32FC1);

                MatIndexer<float> indexer2 = mat3.GetGenericIndexer<float>();

                for (int j = 0; j < mat2.Height; j++)
                {
                    float num2 = 0f;
                    for (int k = 0; k < mat2.Width; k++)
                    {
                        num2 += (float)(int)indexer[j, k];
                    }

                    indexer2[j, 0] = num2 / (float)mat2.Width;
                }

                Point3f edgePoint = GetEdgePoint(mat3);
                if (edgePoint.Y == -1f)
                {
                    list.Add(new Point3f(-1f, -1f, 0f));
                }
                else
                {
                    edgePoint.Y = (0f - searchLength) / 2f + edgePoint.Y;
                    Mat rotationMatrix2D2 = Cv2.GetRotationMatrix2D(new Point2f(0f, 0f), (0.0 - num) * 180.0 / Math.PI - (double)(90 * (int)Direction), 1.0);
                    Mat mat4 = new Mat(3, 1, MatType.CV_64FC1, new double[3] { edgePoint.X, edgePoint.Y, 1.0 }, 0L);
                    mat4 = rotationMatrix2D2 * mat4;
                    edgePoint.X = (float)mat4.At<double>(0, 0) + center.X;
                    edgePoint.Y = (float)mat4.At<double>(1, 0) + center.Y;
                    list.Add(edgePoint);
                    rotationMatrix2D2.Dispose();
                    mat4.Dispose();
                }

                mat3.Dispose();
                mat.Dispose();
            }

            return list;
        }

        protected Point3f GetEdgePoint(Mat projectionImg)
        {
            FilterHalfSize = filterHalfSize;
            Mat mat = new Mat();
            Cv2.GaussianBlur(projectionImg, mat, new OpenCvSharp.CPlusPlus.Size(1, 1), 0.0);
            Mat mat2 = new Mat();
            Cv2.Filter2D(mat, mat2, -1, prewittFilter);
            MatIndexer<float> indexer = mat2.GetGenericIndexer<float>();
            OpenCvSharp.CPlusPlus.Point minLoc = default(OpenCvSharp.CPlusPlus.Point);
            OpenCvSharp.CPlusPlus.Point maxLoc = default(OpenCvSharp.CPlusPlus.Point);
            bool flag = true;
            bool flag2 = true;
            float num = 0f;
            float num2 = 0f;
            switch (priority)
            {
                case CaliperPriority.First:
                    {
                        minLoc.Y = (maxLoc.Y = mat2.Height - 1);
                        for (int j = 0; j < mat2.Height; j++)
                        {
                            if (!(flag || flag2))
                            {
                                break;
                            }

                            float num8 = indexer[j, 0];
                            if (flag)
                            {
                                if (num8 > minContrastThreshold && num8 > num)
                                {
                                    num = num8;
                                    maxLoc.Y = j;
                                }

                                if (num > 0f && num8 < num)
                                {
                                    flag = false;
                                }
                            }

                            if (flag2)
                            {
                                if (num8 < 0f - minContrastThreshold && num8 < num2)
                                {
                                    num2 = num8;
                                    minLoc.Y = j;
                                }

                                if (num2 < 0f && num8 > num2)
                                {
                                    flag2 = false;
                                }
                            }
                        }

                        break;
                    }
                case CaliperPriority.Last:
                    {
                        int num9 = mat2.Height - 1;
                        while (num9 >= 0 && (flag || flag2))
                        {
                            float num10 = indexer[num9, 0];
                            if (flag)
                            {
                                if (num10 > minContrastThreshold && num10 > num)
                                {
                                    num = num10;
                                    maxLoc.Y = num9;
                                }

                                if (num > 0f && num10 < num)
                                {
                                    flag = false;
                                }
                            }

                            if (flag2)
                            {
                                if (num10 < 0f - minContrastThreshold && num10 < num2)
                                {
                                    num2 = num10;
                                    minLoc.Y = num9;
                                }

                                if (num2 < 0f && num10 > num2)
                                {
                                    flag2 = false;
                                }
                            }

                            num9--;
                        }

                        break;
                    }
                case CaliperPriority.Peak:
                    {
                        Cv2.MinMaxLoc(mat2, out var minVal, out var maxVal, out minLoc, out maxLoc);
                        if (minVal > (double)(0f - minContrastThreshold))
                        {
                            minLoc.Y = 0;
                        }

                        if (maxVal < (double)minContrastThreshold)
                        {
                            maxLoc.Y = 0;
                        }

                        num2 = (float)minVal;
                        num = (float)maxVal;
                        break;
                    }
                case CaliperPriority.Pos:
                    {
                        minLoc.Y = (maxLoc.Y = mat2.Height - 1);
                        float num3 = 0f;
                        float num4 = 0f;
                        int num5 = 0;
                        int num6 = 0;
                        for (int i = 0; i < mat2.Height; i++)
                        {
                            if (!(flag || flag2))
                            {
                                break;
                            }

                            float num7 = indexer[i, 0];
                            if (flag)
                            {
                                if (num7 > minContrastThreshold && num7 > num4)
                                {
                                    num4 = num7;
                                    num5 = i;
                                }

                                if (num4 > 0f && num7 < num4)
                                {
                                    if (Math.Abs((double)(mat2.Height - 1) / 2.0 - (double)num5) < Math.Abs((double)(mat2.Height - 1) / 2.0 - (double)maxLoc.Y))
                                    {
                                        num = num4;
                                        maxLoc.Y = num5;
                                    }
                                    else if (Math.Abs((double)(mat2.Height - 1) / 2.0 - (double)num5) == Math.Abs((double)(mat2.Height - 1) / 2.0 - (double)maxLoc.Y))
                                    {
                                        if (num4 >= num)
                                        {
                                            num = num4;
                                            maxLoc.Y = num5;
                                        }
                                    }
                                    else
                                    {
                                        flag = false;
                                    }

                                    num4 = 0f;
                                    num5 = 0;
                                }
                            }

                            if (!flag2)
                            {
                                continue;
                            }

                            if (num7 < 0f - minContrastThreshold && num7 < num3)
                            {
                                num3 = num7;
                                num6 = i;
                            }

                            if (!(num3 < 0f) || !(num7 > num3))
                            {
                                continue;
                            }

                            if (Math.Abs((double)(mat2.Height - 1) / 2.0 - (double)num6) < Math.Abs((double)(mat2.Height - 1) / 2.0 - (double)minLoc.Y))
                            {
                                num2 = num3;
                                minLoc.Y = num6;
                            }
                            else if (Math.Abs((double)(mat2.Height - 1) / 2.0 - (double)num6) == Math.Abs((double)(mat2.Height - 1) / 2.0 - (double)minLoc.Y))
                            {
                                if (num3 <= num2)
                                {
                                    num2 = num3;
                                    minLoc.Y = num6;
                                }
                            }
                            else
                            {
                                flag2 = false;
                            }

                            num3 = 0f;
                            num6 = 0;
                        }

                        break;
                    }
            }

            Point3f point3f = default(Point3f);
            switch (edgePolarity)
            {
                case EdgePolarity.Any_Polarity:
                    if (priority == CaliperPriority.First)
                    {
                        point3f.Y = ((minLoc.Y < maxLoc.Y) ? minLoc.Y : maxLoc.Y);
                    }
                    else if (priority == CaliperPriority.Last)
                    {
                        point3f.Y = ((minLoc.Y > maxLoc.Y) ? minLoc.Y : maxLoc.Y);
                    }
                    else
                    {
                        point3f.Y = ((Math.Abs(num2) > Math.Abs(num)) ? minLoc.Y : maxLoc.Y);
                    }

                    break;
                case EdgePolarity.Dark_to_Light:
                    point3f.Y = maxLoc.Y;
                    break;
                case EdgePolarity.Light_to_Dark:
                    point3f.Y = minLoc.Y;
                    break;
            }

            if (point3f.Y == 0f || point3f.Y == (float)(mat2.Height - 1))
            {
                return new Point3f(point3f.X, -1f, point3f.Z);
            }

            point3f.Z = Math.Abs(indexer[(int)point3f.Y, 0]);
            point3f = getSubPixel(mat2, (int)point3f.Y);
            mat.Dispose();
            mat2.Dispose();
            return point3f;
        }

        protected Point3f getSubPixel(Mat Input, int Index)
        {
            Point3f result = new Point3f(0f, Index, Input.At<float>(Index, 0));
            if (Index == 0 || Index == Input.Height)
            {
                return result;
            }

            float[] array = new float[3]
            {
            Index - 1,
            Index,
            Index + 1
            };
            float[] data = new float[3]
            {
            Input.At<float>(Index - 1),
            Input.At<float>(Index),
            Input.At<float>(Index + 1)
            };
            MatType cV_32FC = MatType.CV_32FC1;
            float[] obj = new float[9] { 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f };
            obj[0] = array[0] * array[0];
            obj[1] = array[0];
            obj[3] = array[1] * array[1];
            obj[4] = array[1];
            obj[6] = array[2] * array[2];
            obj[7] = array[2];
            Mat mat = new Mat(3, 3, cV_32FC, obj, 0L);
            Mat mat2 = new Mat(3, 1, MatType.CV_32FC1, data, 0L);
            Mat mat3 = mat.Inv() * mat2;
            result.Y = -1f * mat3.At<float>(1) / mat3.At<float>(0) / 2f;
            result.Z = mat3.At<float>(0) * result.Y * result.Y + mat3.At<float>(1) * result.Y + mat3.At<float>(2);
            result.Z = Math.Abs(result.Z);
            MvFunc.DisplayMat(Input);
            return result;
        }



        //Select Point Custom Cricle Caliper
        public override bool FindPoint(PointF mouseLocation)
        {
            if (base.IsPositionChange)
            {
                switch (selectionPoint)
                {
                    case SelectionPoint.None:
                        ResetSelectedPoint();
                        break;
                    case SelectionPoint.SP:
                        {
                            float num2 = (float)(Math.Atan2(mouseLocation.Y - CP.Y, mouseLocation.X - CP.X) * 180.0 / Math.PI);
                            if (num2 < EndAngle)
                            {
                                StartAngle = num2;
                            }
                            else
                            {
                                StartAngle = num2 - 360f;
                            }

                            if (StartAngle > 355f)
                            {
                                StartAngle = 350f;
                            }
                            else if (StartAngle < -355f)
                            {
                                StartAngle = -350f;
                            }
                            else if (StartAngle + 15f > EndAngle)
                            {
                                StartAngle = EndAngle - 20f;
                            }

                            break;
                        }
                    case SelectionPoint.MP:
                            Radius = (float)Math.Sqrt(Math.Pow(mouseLocation.X - CP.X, 2.0) + Math.Pow(mouseLocation.Y - CP.Y, 2.0));
                        break;
                    case SelectionPoint.EP:
                        {
                            float num = (float)(Math.Atan2(mouseLocation.Y - CP.Y, mouseLocation.X - CP.X) * 180.0 / Math.PI);
                            if (num > StartAngle)
                            {
                                EndAngle = num;
                            }
                            else
                            {
                                EndAngle = num + 360f;
                            }

                            if (EndAngle > 355f)
                            {
                                EndAngle = 350f;
                            }
                            else if (EndAngle < -355f)
                            {
                                EndAngle = -350f;
                            }
                            else if (StartAngle + 15f > EndAngle)
                            {
                                EndAngle = StartAngle + 20f;
                            }

                            break;
                        }
                    case SelectionPoint.CP:
                        CP = new PointF(mouseLocation.X, mouseLocation.Y);
                        break;
                }
            }

            int num3 = -1;
            double num4 = double.MaxValue;
            if (selectionPoints == null)
            {
                selectionPoints = new PointF[4];
            }

            selectionPoints[0] = SP;
            selectionPoints[1] = MP;
            selectionPoints[2] = EP;
            selectionPoints[3] = CP;
            for (int i = 0; i < selectionPoints.Length; i++)
            {
                double num5 = Math.Sqrt(Math.Pow(selectionPoints[i].X - mouseLocation.X, 2.0) + Math.Pow(selectionPoints[i].Y - mouseLocation.Y, 2.0));
                if (num5 <= num4)
                {
                    num3 = i;
                    num4 = num5;
                }
            }

            if (num4 > (double)base.SelectionSize)
            {
                num3 = -1;
            }

            switch (num3)
            {
                case -1:
                    display.Cursor = Cursors.Default;
                    selectionPoint = SelectionPoint.None;
                    return false;
                case 0:
                    display.Cursor = Cursors.SizeAll;
                    selectionPoint = SelectionPoint.SP;
                    break;
                case 1:
                    display.Cursor = Cursors.SizeAll;
                    selectionPoint = SelectionPoint.MP;
                    break;
                case 2:
                    display.Cursor = Cursors.SizeAll;
                    selectionPoint = SelectionPoint.EP;
                    break;
                case 3:
                    display.Cursor = Cursors.SizeAll;
                    selectionPoint = SelectionPoint.CP;
                    break;
            }

            return true;
        }

        public override void SelectPoint()
        {
            if (selectionPoint != 0)
            {
                base.IsPositionChange = true;
            }
        }

        public override void ResetSelectedPoint()
        {
            base.IsPositionChange = false;
            selectionPoint = SelectionPoint.None;
        }

        public override void Draw(Graphics gdi)
        {
            MvCircle _circle = new MvCircle();
            DisplayMatF(transformMat);
            _circle.Center = FixtureToImage2D(new Point2d(CP.X, CP.Y), base.TransformMat);
            //_circle.Height = Circle.Height;
            //_circle.Width = Circle.Width;
            _circle.R = Circle.R;
            _circle.StartAngle = StartAngle;
            _circle.EndAngle = EndAngle;
            _ = _circle.GetLineLength() / (double)(numberOfCaliper - 1);
            gdi.DrawEllipse(Pens.Red, _circle.CenterF.X - _circle.R, _circle.CenterF.Y - _circle.R, 2f * _circle.R, 2f * _circle.R);
            double num;
            for (int i = 0; i < numberOfCaliper; i++)
            {
                num = (double)(_circle.StartAngle + (_circle.EndAngle - _circle.StartAngle) / (float)(numberOfCaliper - 1) * (float)i) * Math.PI / 180.0;
                PointF pointF = Rotate(new PointF((0f - projectionLength) / 2f, 0f - searchLength / 2f), num + Math.PI / 2.0);
                PointF pointF2 = Rotate(new PointF(projectionLength / 2f, 0f - searchLength / 2f), num + Math.PI / 2.0);
                PointF pointF3 = Rotate(new PointF(projectionLength / 2f, searchLength / 2f), num + Math.PI / 2.0);
                PointF pointF4 = Rotate(new PointF((0f - projectionLength) / 2f, searchLength / 2f), num + Math.PI / 2.0);
                gdi.DrawPolygon(Pens.Cyan, new PointF[4]
                {
                new PointF(pointF.X + (float)_circle.Center.X + (float)((double)_circle.R * Math.Cos(num)), pointF.Y + (float)_circle.Center.Y + (float)((double)_circle.R * Math.Sin(num))),
                new PointF(pointF2.X + (float)_circle.Center.X + (float)((double)_circle.R * Math.Cos(num)), pointF2.Y + (float)_circle.Center.Y + (float)((double)_circle.R * Math.Sin(num))),
                new PointF(pointF3.X + (float)_circle.Center.X + (float)((double)_circle.R * Math.Cos(num)), pointF3.Y + (float)_circle.Center.Y + (float)((double)_circle.R * Math.Sin(num))),
                new PointF(pointF4.X + (float)_circle.Center.X + (float)((double)_circle.R * Math.Cos(num)), pointF4.Y + (float)_circle.Center.Y + (float)((double)_circle.R * Math.Sin(num)))
                });
            }

            int num2 = 0;
            num2 = ((Direction == EDirection.Inner) ? 1 : (-1));
            Pen pen = new Pen(Color.Cyan, 10f);
            AdjustableArrowCap customEndCap = new AdjustableArrowCap(2f, 3f);
            pen.CustomEndCap = customEndCap;
            num = (double)(_circle.StartAngle + (_circle.EndAngle - _circle.StartAngle) / 2f) * Math.PI / 180.0;
            gdi.DrawLine(pen, Rotate(new PointF(0f, (0f - (searchLength / 2f + searchLength / 5f)) * (float)num2), num + Math.PI / 2.0) + new SizeF((float)_circle.Center.X + (float)((double)_circle.R * Math.Cos(num)), (float)_circle.Center.Y + (float)((double)_circle.R * Math.Sin(num))),
                Rotate(new PointF(0f, (searchLength / 2f + searchLength / 5f) * (float)num2), num + Math.PI / 2.0) + new SizeF((float)_circle.Center.X + (float)((double)_circle.R * Math.Cos(num)), (float)_circle.Center.Y + (float)((double)_circle.R * Math.Sin(num))));
            gdi.DrawEllipse(Pens.Cyan, _circle.CenterF.X - 10f, _circle.CenterF.Y - 10f, 20f, 20f);
            pen.Dispose();
        }
        public static double[,] DisplayMat(Mat src)
        {
            double[,] array = new double[src.Height, src.Width];
            for (int i = 0; i < src.Height; i++)
            {
                for (int j = 0; j < src.Width; j++)
                {
                    array[i, j] = src.At<double>(i, j);
                }
            }

            return array;
        }
        public static float[,] DisplayMatF(Mat src)
        {
            if (src == null)
            {
                return new float[0, 0];
            }

            float[,] array = new float[src.Height, src.Width];
            for (int i = 0; i < src.Height; i++)
            {
                for (int j = 0; j < src.Width; j++)
                {
                    array[i, j] = src.At<float>(i, j);
                }
            }

            return array;
        }
        public static Point2d FixtureToImage2D(Point2d point, Mat mat)
        {
            if (mat == null)
            {
                return point;
            }

            Mat mat2 = mat.Inv();
            return ImageToFixture2D(point, mat2);
        }
        public static Point2d ImageToFixture2D(Point2d point, Mat mat)
        {
            if (mat == null)
            {
                return point;
            }

            Point2d result = default(Point2d);
            Mat mat2 = new Mat(3, 1, MatType.CV_32FC1);
            mat2.Set(0, 0, (float)point.X);
            mat2.Set(1, 0, (float)point.Y);
            mat2.Set(2, 0, 1f);
            Mat mat3 = mat * mat2;
            result.X = (double)mat3.Get<float>(0, 0) / (double)mat3.Get<float>(2, 0);
            result.Y = (double)mat3.Get<float>(1, 0) / (double)mat3.Get<float>(2, 0);
            return result;
        }
        public static PointF Rotate(PointF point, double thetaRad)
        {
            PointF result = default(PointF);
            result.X = (float)(Math.Cos(thetaRad) * (double)point.X - Math.Sin(thetaRad) * (double)point.Y);
            result.Y = (float)(Math.Sin(thetaRad) * (double)point.X + Math.Cos(thetaRad) * (double)point.Y);
            return result;
        }
    }
    [AttributeUsage(AttributeTargets.Property)]
    public class PropertyOrderAttribute : Attribute
    {
        private int A_order;

        public int Order => A_order;

        public PropertyOrderAttribute(int order)
        {
            A_order = order;
        }
    }
  


}
