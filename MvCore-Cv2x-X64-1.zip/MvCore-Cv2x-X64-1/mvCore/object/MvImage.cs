﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System.Runtime.Serialization;
using System.Reflection;

namespace MvCore
{
    [Serializable]
    public class MvImage : IDisposable, ISerializable, ICloneable
    {
        public MvImage() : this(new Mat())
        {
        }

        public MvImage(Mat mat)
        {
            regionRect = new MvRectangle();
            transformMat = Mat.Eye(3, 3, MatType.CV_32FC1);
            this.mat = mat;
            RegionRect = new MvRectangle(0, 0, mat.Width, mat.Height);
        }

        public object Clone()
        {
            return Clone(true);
        }

        //lỗi tràn bộ nhớ
        //public SvImage Clone(bool isMatCopy)
        //{            
        //    SvImage cloneImg = new SvImage();

        //    if (this.mat == null || this.mat.IsDisposed)
        //        cloneImg.mat = null;
        //    else if (isMatCopy)
        //        cloneImg.mat = this.mat.Clone();
        //    else
        //        cloneImg.mat = this.mat;

        //    cloneImg.regionRect.RectF = this.regionRect.RectF;

        //    cloneImg.transformMat = this.transformMat.Clone();

        //    return cloneImg;
        //}

        public MvImage Clone(bool isMatCopy)
        {
            MvImage c = new MvImage();

            if (this.mat == null || this.mat.IsDisposed)
                c.mat = null;
            else
                c.mat = isMatCopy ? this.mat.Clone() : this.mat.Clone(); // luôn clone

            c.regionRect.RectF = this.regionRect.RectF;

            if (this.transformMat != null)
                c.transformMat = this.transformMat.Clone();

            return c;
        }

        Mat mat;

        public Mat Mat
        {
            get { return mat; }
            set
            {
                if (mat != null && !mat.IsDisposed && mat != value)
                    mat.Dispose();

                if (value == null || value.IsDisposed)
                    mat = new Mat();
                else
                    mat = value; 
                if (regionRect.Width == 0 && regionRect.Height == 0)
                    RegionRect = new MvRectangle(0, 0, mat.Width, mat.Height);
            }
        }

        public int Width 
        {
            get
            {
                if (IsNull)
                    return 0;
                else
                    return mat.Width;
            }
        }

        public int Height
        {
            get
            {
                if (IsNull)
                    return 0;
                else
                    return mat.Height;
            }
        }

        public bool IsNull
        {
            get
            {
                if (mat == null || mat.IsDisposed || mat.Width == 0 || mat.Height == 0)
                    return true;
                else
                    return false;
            }
        }

        MvRectangle regionRect;

        public MvRectangle RegionRect
        {
            get
            {
                //AdjustRegionRect();
                return regionRect; 
            }
            set { regionRect = value; }
        }

        void AdjustRegionRect()
        {
            Point2f transformedLocation = MvFunc.FixtureToImage2F(regionRect.Location, transformMat);
            if (mat != null && !mat.IsDisposed)
            {
                if (regionRect.Width < 0) regionRect.Width = 0;
                if (regionRect.Height < 0) regionRect.Height = 0;
                if (transformedLocation.X + regionRect.Width > mat.Width) regionRect.Width = mat.Width - transformedLocation.X;
                if (transformedLocation.Y + regionRect.Height > mat.Height) regionRect.Height = mat.Height - transformedLocation.Y;                
            }
        }

        Mat transformMat;

        public Mat TransformMat
        {
            get { return transformMat; }
            set 
            {
                if (transformMat != null && !transformMat.IsDisposed && transformMat.Width != 0 && transformMat.Height != 0)
                    transformMat.Dispose();

                if (value == null || value.IsDisposed)
                {
                    transformMat = Mat.Eye(3, 3, MatType.CV_32FC1);
                    return;
                }
                transformMat = value.Clone(); 
            }
        }
        
        public void Dispose()
        {
            if (mat != null && !mat.IsDisposed)
            {
                mat.Dispose();
                mat = new Mat();
            }

            transformMat.Dispose();
            transformMat = Mat.Eye(3, 3, MatType.CV_32FC1);

            regionRect = null;
            regionRect = new MvRectangle();
        }

        MvImage(SerializationInfo info, StreamingContext context)
        {
            MvSerializer.Deserializeing(this, info, context);
        }
        
        [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Demand,SerializationFormatter = true)]
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            MvSerializer.Serializeing(this, info, context);
        }

        public Point2f[] RegionRect2fPtsImage
        {
            get
            {
                Point2f[] pts = new Point2f[4];

                pts[0] = MvFunc.FixtureToImage2F(new Point2f(RegionRect.RectF.Left, RegionRect.RectF.Top), TransformMat);
                pts[1] = MvFunc.FixtureToImage2F(new Point2f(RegionRect.RectF.Right, RegionRect.RectF.Top), TransformMat);
                pts[2] = MvFunc.FixtureToImage2F(new Point2f(RegionRect.RectF.Right, RegionRect.RectF.Bottom), TransformMat);
                pts[3] = MvFunc.FixtureToImage2F(new Point2f(RegionRect.RectF.Left, RegionRect.RectF.Bottom), TransformMat);

                return pts;
            }
        }

        public Point2f[] RegionRect2fPts
        {
            get
            {
                Point2f[] pts = new Point2f[4];

                pts[0] = new Point2f(0, 0);
                pts[1] = new Point2f(RegionRect.RectF.Right - RegionRect.RectF.Left, 0);
                pts[2] = new Point2f(RegionRect.RectF.Right - RegionRect.RectF.Left, RegionRect.RectF.Bottom - RegionRect.RectF.Top);
                pts[3] = new Point2f(0, RegionRect.RectF.Bottom - RegionRect.RectF.Top);

                return pts;
            }
        }

        public OpenCvSharp.CPlusPlus.Point[] RegionRectPtsImage
        {
            get
            {
                OpenCvSharp.CPlusPlus.Point[] pts = new OpenCvSharp.CPlusPlus.Point[4];

                pts[0] = (Point)MvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(RegionRect.RectF.Left, RegionRect.RectF.Top), TransformMat);
                pts[1] = (Point)MvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(RegionRect.RectF.Right, RegionRect.RectF.Top), TransformMat);
                pts[2] = (Point)MvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(RegionRect.RectF.Right, RegionRect.RectF.Bottom), TransformMat);
                pts[3] = (Point)MvFunc.FixtureToImage2F(new OpenCvSharp.CPlusPlus.Point(RegionRect.RectF.Left, RegionRect.RectF.Bottom), TransformMat);

                return pts;
            }
        }

        public OpenCvSharp.CPlusPlus.Point[] RegionRectPts
        {
            get
            {
                OpenCvSharp.CPlusPlus.Point[] pts = new OpenCvSharp.CPlusPlus.Point[4];

                pts[0] = new OpenCvSharp.CPlusPlus.Point(0, 0);
                pts[1] = new OpenCvSharp.CPlusPlus.Point(RegionRect.RectF.Right - RegionRect.RectF.Left, 0);
                pts[2] = new OpenCvSharp.CPlusPlus.Point(RegionRect.RectF.Right - RegionRect.RectF.Left, RegionRect.RectF.Bottom - RegionRect.RectF.Top);
                pts[3] = new OpenCvSharp.CPlusPlus.Point(0, RegionRect.RectF.Bottom - RegionRect.RectF.Top);

                return pts;
            }
        }

        public System.Drawing.PointF[] RegionRectFPts
        {
            get
            {
                System.Drawing.PointF[] pts = new System.Drawing.PointF[4];
                Point2f[] p2f = RegionRect2fPtsImage;
                for (int i = 0; i < 4; i++)
                    pts[i] = new System.Drawing.PointF(p2f[i].X, p2f[i].Y);

                return pts;
            }
        }
    }
}
