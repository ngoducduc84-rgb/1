﻿using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

public  class JsonHelper
{
    private  readonly JsonSerializerOptions Options = new JsonSerializerOptions
    {
        WriteIndented = true,   // format đẹp
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        ReferenceHandler = ReferenceHandler.IgnoreCycles // tránh lỗi vòng tham chiếu
    };

    // Lưu object ra file JSON
    public  void SaveToFile<T>(T obj, string path)
    {
        string json = JsonSerializer.Serialize(obj, Options);
        File.WriteAllText(path, json);
    }

    // Load object từ file JSON
    public  T LoadFromFile<T>(string path)
    {
        string json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<T>(json, Options);
    }
}
