﻿using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using MvCore.core;

namespace MvCore
{
    // 내 능력으로 한계라 박싱 언박싱 성능 고려 안함.

    [Serializable]
    public class MvJob
    {
        List<MvToolBase> toolList = new List<MvToolBase>();
        [NonSerialized]
        _internal inter;
        [NonSerialized]
        internal bool active = false;
        public List<MvToolBase> ToolList
        {            
            get { return toolList; }
            set 
            {
                toolList.Clear();
                foreach(MvToolBase tool in value)
                {
                    toolList.Add(tool);
                }
            }
        }

        public MvToolBase this[string name]
        {
            get
            {
                MvToolBase selectTool = null;

                foreach (MvToolBase tool in toolList)
                {
                    if (name == tool.ToString())
                        selectTool = tool;
                }
                return selectTool;
            }
        }

        public MvJob()
        {
           
        }

        string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        bool lastRunSuccess;

        public bool LastRunSuccess { get { return lastRunSuccess; } }

        double lastRunTime;

        public double LastRunTime { get { return lastRunTime; } }

        public void RestoreLink()
        {
            foreach (MvToolBase tool in toolList)
            {
                if (tool == null) continue;
                foreach (KeyValuePair<string, InputParams> param in tool.inParams)
                {
                    InputParams dstValue = param.Value;
                    if (dstValue == null) continue;

                    foreach (MvToolBase t in toolList)
                    {
                        if (t == tool)
                            continue;
                        if (t.HashCode == dstValue.InstanceHashcode)
                        {
                            dstValue.Instance = t;
                            break;
                        }
                    }

                }
            }
        }

        public List<KeyValuePair<string, double>> GetLastProcessTimes()
        {
            //System.Collections.Generic.Dictionary<string, double> lastProcessTimes = new System.Collections.Generic.Dictionary<string, double>();
            List<KeyValuePair<string, double>> lastProcessTimes = new List<KeyValuePair<string, double>>();
            double TT = 0;
            foreach (MvToolBase tool in toolList)
            {
                lastProcessTimes.Add(new KeyValuePair<string, double>(tool.ToString(), tool.lastProcessTime));
                TT += tool.lastProcessTime;
            }
            lastProcessTimes.Insert(0, new KeyValuePair<string, double>("Total Time", TT));
            return lastProcessTimes;
        }

        public MvToolBase GetLastRunTool()
        {
            return toolList.Last();
        }

        public Dictionary<string, object> GetLastRunOutParams()
        {
            return toolList.Last().outParams;
        }

        public static T Clone<T>(T obj)
        {
            using (var ms = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(ms, obj);
                ms.Position = 0;
                return (T)formatter.Deserialize(ms);
            }
        }

        public struct OutImageInfo
        {
            public OutImageInfo(string ToolName, string ImageName, Mat Image, Image overray)
            {
                this.ToolName = ToolName;
                this.ImageName = ImageName;
                this.Image = Image;
                this.overray = overray;
            }

            public readonly string ToolName;
            public readonly string ImageName;
            [NonSerialized]
            public readonly Mat Image;
            public readonly Image overray;

            public override string ToString()
            {
                return string.Format("Tool : {0,-20}Name : {1}", ToolName, ImageName);
            }
        }

        public List<OutImageInfo> GetOutImages()
        {
            List<OutImageInfo> outImages = new List<OutImageInfo>();

            foreach (MvToolBase tool in toolList)
            {
                foreach (KeyValuePair<string, object> param in tool.outParams)
                {
                    if (param.Value == null) continue;
                    //if (param.Value is Mat) ;
                    //outImages.Add(new OutImageInfo(tool.ToString(), param.Key, param.Value as Mat));
                }
            }

            return outImages;
        }

        public void Run(bool isEditMode = false)
        {
            //if (active == false) { if (inter == null) { inter = new _internal(); } active = inter.checkActive(); }
            
            //if (active == false || toolList.Count == 0) return;

            DateTime runTimeStart = DateTime.Now;
            lastRunSuccess = true;

            RestoreLink();

            foreach (MvToolBase tool in toolList)
            {
                DateTime lastProcessTimeStart = DateTime.Now;

                tool.GetInParams();
                tool.InitOutProperty();
                tool.Run(isEditMode);

                //if (tool.lastRunSuccess)
                {
                    tool.GetOutParams();
                    tool.OnRan();
                }

                tool.lastProcessTime = DateTime.Now.Subtract(lastProcessTimeStart).TotalMilliseconds;
                System.Diagnostics.Debug.WriteLine(tool.ToString() + " Time: " + tool.lastProcessTime);

                lastRunSuccess &= tool.lastRunSuccess;
            }

            lastRunTime = DateTime.Now.Subtract(runTimeStart).TotalMilliseconds;
            System.Diagnostics.Debug.WriteLine("Total VisionJob Time: " + lastRunTime);

            GC.Collect();
        }

        public void RunWithoutAcq()
        {
            if (toolList.Count == 0) return;

            DateTime runTimeStart = DateTime.Now;
            lastRunSuccess = true;

            RestoreLink();

            foreach (MvToolBase tool in toolList)
            {
                if (tool is MvAcquisition) continue;

                DateTime lastProcessTimeStart = DateTime.Now;

                tool.GetInParams();
                tool.InitOutProperty();
                tool.Run();

                tool.GetOutParams();
                tool.OnRan();

                tool.lastProcessTime = DateTime.Now.Subtract(lastProcessTimeStart).TotalMilliseconds;
                System.Diagnostics.Debug.WriteLine(tool.ToString() + " Time: " + tool.lastProcessTime);

                lastRunSuccess &= tool.lastRunSuccess;
            }

            lastRunTime = DateTime.Now.Subtract(runTimeStart).TotalMilliseconds;
            System.Diagnostics.Debug.WriteLine("Total VisionJob Time: " + lastRunTime);

            GC.Collect();
        }

        public void RunBeforeTool(MvToolBase toolbase)
        {
            try
            {
                if (toolList.Count == 0) return;
                if (toolbase == null) { Run(); return; }

                DateTime runTimeStart = DateTime.Now;
                lastRunSuccess = true;

                RestoreLink();

                foreach (MvToolBase tool in toolList)
                {
                    if (tool == toolbase) break;

                    DateTime lastProcessTimeStart = DateTime.Now;

                    tool.GetInParams();
                    tool.InitOutProperty();
                    tool.Run();

                    tool.GetOutParams();
                    tool.OnRan();

                    tool.lastProcessTime = DateTime.Now.Subtract(lastProcessTimeStart).TotalMilliseconds;
                    System.Diagnostics.Debug.WriteLine(tool.ToString() + " Time: " + tool.lastProcessTime);

                    lastRunSuccess &= tool.lastRunSuccess;
                }

                lastRunTime = DateTime.Now.Subtract(runTimeStart).TotalMilliseconds;
                System.Diagnostics.Debug.WriteLine("Total VisionJob Time: " + lastRunTime);

                GC.Collect();
            }
            catch (Exception ex)
            {
                Console.WriteLine("RunBeforeTool" + ex.ToString());
                return;
            }
        }
        public void OnRan()
        {
            //foreach (SvToolBase tool in toolList)
            //{
            //    tool.OnRan();
            //}

            NotifyRan(this, this);
        }

        public delegate void RanHandler(object sender, MvJob job);

        [field: NonSerialized]
        public event RanHandler Ran;

        protected void NotifyRan(object sender, MvJob job)
        {
            if (Ran != null)
                Ran(sender, job);
        }

    }
}
