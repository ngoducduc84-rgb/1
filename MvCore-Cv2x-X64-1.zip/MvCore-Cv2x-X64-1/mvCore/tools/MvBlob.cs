﻿using DirectShowLib;
using OpenCvSharp;
using OpenCvSharp.Blob;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Windows;
using System.Windows.Forms;
//using static OpenCvSharp.ConnectedComponents;

namespace MvCore
{
    [Serializable]
    public class MvBlob : MvToolBase
    {
        public MvBlob()
        {
            kSize = 3;
            minArea = 1000; maxArea = 1000000;
            rangeLow = 0; rangeHigh = 255;
        }

        public MvBlob(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public enum BlobMode { Theshold, Adaptive, inRange, Bernsen, Nick, NiblackFast, SauvolaFast }
        public enum BlobType { Binary, Otsu, Gaussian, Mean };
        public enum BlobPolarity { Black, White };
        public enum BlobBinaryType { ToBlack, ToZero };
        public enum BlobDirection { None, Left, Top, Right, Bottom };

        #region InputParams

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }

        [InputParam]
        public MvImage InputImage { get; set; }

        [InputParam]
        public MvPolyLine InPolyLine { get; set; }
        #endregion

        // TKL : Region 영역 Data로 Histogram을 그려주도록 수정
        private Mat regionImage;

        public Mat RegionImage
        {
            get
            {
                return regionImage;
            }
            set
            {
                if (regionImage != null) regionImage.Dispose();
                regionImage = value.Clone();
            }
        }

        bool isGetBlob;

        public List<int> Ranges = new List<int>();


        public int BlobRangeIndex { get; set; }

        public int Range
        {
            get
            {
                return mRange;
            }

            set { mRange = value; NotifyPropertyChanged("Range"); }
        }
        int mRange;

        public bool IsGetBlob
        {
            get { return isGetBlob; }
            set { isGetBlob = value; }
        }

        bool isfillingHole;
        public bool IsfillingHole
        {
            get { return isfillingHole; }
            set { isfillingHole = value; }
        }

        bool isExceptBoundary;
        public bool IsExceptBoundary
        {
            get { return isExceptBoundary; }
            set { isExceptBoundary = value; }
        }

        BlobMode mode;
        BlobType type;
        BlobPolarity pola = BlobPolarity.White;
        BlobBinaryType binaryType;

        int kSize;
        int minArea, maxArea;
        int rangeLow, rangeHigh;
        int constant;
        double adequateCoefficient, adequateCoefficientR;

        public BlobMode Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        public BlobType Type
        {
            get { return type; }
            set { type = value; }
        }

        public BlobPolarity Polarity
        {
            get { return pola; }
            set { pola = value; }
        }

        public BlobBinaryType BinaryType
        {
            get { return binaryType; }
            set { binaryType = value; }
        }

        public BlobDirection Priority
        {
            get; set;
        }

        public int KernelSize
        {
            get { return kSize; }
            set { kSize = value; }
        }

        public int RangeLow
        {
            get { return rangeLow; }
            set { rangeLow = value; }
        }

        public int RangeHigh
        {
            get { return rangeHigh; }
            set { rangeHigh = value; }
        }

        public int Constant
        {
            get { return constant; }
            set { constant = value; }
        }

        public double AdequateCoefficient
        {
            get { return adequateCoefficient; }
            set { adequateCoefficient = value; }
        }

        public double AdequateCoefficientR
        {
            get { return adequateCoefficientR; }
            set { adequateCoefficientR = value; }
        }

        [Serializable]
        public class svBlobFilter
        {
            public enum Properties { Area, CenterMassX, CenterMassY, Angle, RectSize, RectWidth, RectHeight }
            public enum RangeFilter { Include, Exclude };

            public svBlobFilter() { }
            public svBlobFilter(Properties property) { this.property = property; }

            Properties property;
            public Properties Property { get { return property; } set { property = value; } }
            bool use;
            public bool Use { get { return use; } set { use = value; } }
            RangeFilter range;
            public RangeFilter Range { get { return range; } set { range = value; } }
            int low;
            public int Low { get { return low; } set { low = value; } }
            int high = 10000000;
            public int High { get { return high; } set { high = value; } }
        }

        svBlobFilter.Properties sortingOrder;
        public svBlobFilter.Properties SortingOrder { get { return sortingOrder; } set { sortingOrder = value; } }

        bool isSortingAscending;
        public bool IsSortingAscending { get { return isSortingAscending; } set { isSortingAscending = value; } }

        List<svBlobFilter> blobFilter;
        public List<svBlobFilter> BlobFilter
        {
            get
            {
                if (blobFilter == null || blobFilter.Count != 7)
                {
                    blobFilter = new List<svBlobFilter>();
                    blobFilter.Add(new svBlobFilter(svBlobFilter.Properties.Area));
                    blobFilter.Add(new svBlobFilter(svBlobFilter.Properties.CenterMassX));
                    blobFilter.Add(new svBlobFilter(svBlobFilter.Properties.CenterMassY));
                    blobFilter.Add(new svBlobFilter(svBlobFilter.Properties.Angle));
                    blobFilter.Add(new svBlobFilter(svBlobFilter.Properties.RectSize));
                    blobFilter.Add(new svBlobFilter(svBlobFilter.Properties.RectWidth));
                    blobFilter.Add(new svBlobFilter(svBlobFilter.Properties.RectHeight));
                }
                return blobFilter;
            }
            set { throw new Exception("blobFilter 쓰면 안됩니다"); }
        }

        #region OutputParams
        [NonSerialized]
        MvImage binaryimage;

        [OutputParam]
        public MvImage BinaryImage
        {
            get { return binaryimage; }
            set
            {
                if (binaryimage != null) binaryimage.Dispose();
                binaryimage = value;
            }
        }

        [NonSerialized]
        MvImage blobimage;
        [OutputParam]
        public MvImage BlobImage
        {
            get { return blobimage; }
            set { blobimage = value; }
        }

        [NonSerialized]
        List<MvBlobObject> blobs;

        [OutputParam]
        public List<MvBlobObject> Blobs
        {
            get
            {
                if (blobs == null)
                    return new List<MvBlobObject>();
                return blobs;
            }
            set
            {
                blobs = value;
            }
        }

        [OutputParam]
        public double AreaSum { get; set; }

        [OutputParam]
        public double AreaRate
        {
            get
            {
                if (InputImage == null || InputImage.RegionRect == null)
                    return 0;
                Rectf regionRect = InputImage.RegionRect.RectF;
                if (regionRect == null || regionRect.Width == 0 || regionRect.Height == 0) return 0;
                double rate = AreaSum / (regionRect.Width * regionRect.Height);
                return rate;
            }
            set
            {
            }
        }
        [OutputParam]
        public double RectLengthSum { get; set; }
        [OutputParam]
        public double RectAreaSum { get; set; }


        public int MaxCount
        {
            get { return mMaxCount; }
            set { mMaxCount = value; }
        }
        int mMaxCount = 0;

        public override void InitOutParmas()
        {
            outParams.Add("AreaSum", null);
            outParams.Add("AreaRate", null);
        }

        [OutputParam]
        public float TranslateX { get; set; }

        [OutputParam]
        public float TranslateY { get; set; }

        [OutputParam]
        public float Rotation { get; set; }

        #endregion
        SvImageInfo inputImageInfo;
        SvImageInfo binaryImageInfo;
        SvImageInfo blobImageInfo;

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            binaryImageInfo = new SvImageInfo(string.Format("[{0}] BinaryImage", this.ToString()));
            blobImageInfo = new SvImageInfo(string.Format("[{0}] BlobImage", this.ToString()));

            imageList.Add(inputImageInfo);
            imageList.Add(binaryImageInfo);
            //imageList.Add(blobImageInfo); //이것만 예외로 동적으로 등록.
        }


        //public static Mat Bernsen(Mat src, int windowSize, int contrastLimit)
        //{
        //    Mat dst = new Mat();
        //    Mat localMin = new Mat();
        //    Mat localMax = new Mat();

        //    OpenCvSharp.CPlusPlus.Size ksize = new OpenCvSharp.CPlusPlus.Size(windowSize, windowSize);

        //    Cv2.Erode(src, localMin, Cv2.GetStructuringElement(MorphShapes.Rect, ksize));
        //    Cv2.Dilate(src, localMax, Cv2.GetStructuringElement(MorphShapes.Rect, ksize));

        //    Mat contrast = localMax - localMin;
        //    Mat midGray = (localMax + localMin) / 2;

        //    dst = new Mat(src.Rows, src.Cols, MatType.CV_8UC1);

        //    for (int r = 0; r < src.Rows; r++)
        //    {
        //        for (int c = 0; c < src.Cols; c++)
        //        {
        //            if (contrast.At<byte>(r, c) < contrastLimit)
        //                dst.Set<byte>(r, c, 0);
        //            else
        //                dst.Set<byte>(r, c, src.At<byte>(r, c) > midGray.At<byte>(r, c) ? (byte)255 : (byte)0);
        //        }
        //    }
        //    return dst;
        //}

        //public static Mat Nick(Mat src, int windowSize, double k)
        //{
        //    Mat mean = new Mat();
        //    Mat sqmean = new Mat();

        //    Cv2.Blur(src, mean, new OpenCvSharp.Size(windowSize, windowSize));
        //    Cv2.SqrBoxFilter(src, sqmean, MatType.CV_32F, new OpenCvSharp.Size(windowSize, windowSize));

        //    Mat variance = sqmean - mean.Mul(mean);
        //    Mat stddev = new Mat();
        //    Cv2.Sqrt(variance, stddev);

        //    Mat threshold = mean + k * stddev;

        //    Mat dst = new Mat(src.Rows, src.Cols, MatType.CV_8UC1);
        //    Cv2.Threshold(src, dst, 0, 255, ThresholdTypes.Binary);

        //    for (int r = 0; r < src.Rows; r++)
        //        for (int c = 0; c < src.Cols; c++)
        //            dst.Set<byte>(r, c,
        //                src.At<byte>(r, c) > threshold.At<float>(r, c) ? (byte)255 : (byte)0);

        //    return dst;
        //}

        //public static Mat Sauvola(Mat src, int windowSize, double k, double R = 128)
        //{
        //    Mat mean = new Mat();
        //    Mat sqmean = new Mat();

        //    Cv2.Blur(src, mean, new OpenCvSharp.Size(windowSize, windowSize));
        //    Cv2.SqrBoxFilter(src, sqmean, MatType.CV_32F, new OpenCvSharp.Size(windowSize, windowSize));

        //    Mat variance = sqmean - mean.Mul(mean);
        //    Mat stddev = new Mat();
        //    Cv2.Sqrt(variance, stddev);

        //    Mat dst = new Mat(src.Rows, src.Cols, MatType.CV_8UC1);

        //    for (int r = 0; r < src.Rows; r++)
        //    {
        //        for (int c = 0; c < src.Cols; c++)
        //        {
        //            float m = mean.At<byte>(r, c);
        //            float s = stddev.At<float>(r, c);

        //            float thr = m * (1 + (float)k * ((s / (float)R) - 1));
        //            byte pix = src.At<byte>(r, c);

        //            dst.Set(r, c, pix > thr ? (byte)255 : (byte)0);
        //        }
        //    }

        //    return dst;
        //}

        //public static Mat Niblack(Mat src, int windowSize, double k)
        //{
        //    Mat mean = new Mat();
        //    Mat sqmean = new Mat();

        //    Cv2.Blur(src, mean, new OpenCvSharp.Size(windowSize, windowSize));
        //    Cv2.SqrBoxFilter(src, sqmean, MatType.CV_32F, new OpenCvSharp.Size(windowSize, windowSize));

        //    Mat variance = sqmean - mean.Mul(mean);
        //    Mat stddev = new Mat();
        //    Cv2.Sqrt(variance, stddev);

        //    Mat dst = new Mat(src.Rows, src.Cols, MatType.CV_8UC1);

        //    for (int r = 0; r < src.Rows; r++)
        //    {
        //        for (int c = 0; c < src.Cols; c++)
        //        {
        //            float m = mean.At<byte>(r, c);
        //            float sd = stddev.At<float>(r, c);
        //            float thr = m + (float)(k * sd);
        //            byte pix = src.At<byte>(r, c);

        //            dst.Set(r, c, (pix > thr) ? (byte)255 : (byte)0);
        //        }
        //    }

        //    return dst;
        //}



        public Mat Binarizing(Mat src, BlobMode mode, BlobType type, BlobPolarity pola, BlobBinaryType binaryType, int rangeLow, int rangeHigh, int kSize,
                               int constant, double adequateCoefficient, double adequateCoefficientR)
        {
            if (kSize < 1 || kSize % 2 == 0)
                kSize = 3;

            if (rangeLow < 0 || rangeLow > 256)
                throw new Exception("rangeLow < 0 || rangeLow > 255");

            if (rangeHigh < 0 || rangeHigh > 256)
                throw new Exception("rangeHigh < 0 || rangeHigh > 255");

            Mat dst = new Mat();
            //switch (mode)
            //{
            //    case BlobMode.Theshold:

            //        ThresholdTypes thresholdType;

            //        if (pola == BlobPolarity.White && binaryType == BlobBinaryType.ToBlack)
            //            thresholdType = ThresholdTypes.Binary;
            //        else if (pola == BlobPolarity.White && binaryType == BlobBinaryType.ToZero)
            //            thresholdType = ThresholdTypes.Tozero;
            //        else if (pola == BlobPolarity.Black && binaryType == BlobBinaryType.ToBlack)
            //            thresholdType = ThresholdTypes.BinaryInv;
            //        else if (pola == BlobPolarity.Black && binaryType == BlobBinaryType.ToZero)
            //            thresholdType = ThresholdTypes.TozeroInv;
            //        else
            //            throw new Exception("thresholdType not find");

            //        if (type == BlobType.Otsu)
            //            thresholdType |= ThresholdTypes.Otsu;

            //        if (type == BlobType.Gaussian || type == BlobType.Mean)
            //            throw new Exception("wrong threshold type");

            //        Cv2.Threshold(src, dst, rangeLow, 255, thresholdType);
            //        break;
            //    case BlobMode.Adaptive:

            //        AdaptiveThresholdTypes adaptiveThresholdType;

            //        if (type == BlobType.Gaussian)
            //            adaptiveThresholdType = AdaptiveThresholdTypes.GaussianC;
            //        else if (type == BlobType.Mean)
            //            adaptiveThresholdType = AdaptiveThresholdTypes.MeanC;
            //        else
            //            throw new Exception("BlobMode must be Gaussian or Mean");

            //        if (pola == BlobPolarity.White)
            //            thresholdType = ThresholdTypes.Binary;
            //        else if (pola == BlobPolarity.Black)
            //            thresholdType = ThresholdTypes.BinaryInv;
            //        else
            //            throw new Exception("BlobPolarity must be Binary or BinaryInv");

            //        Cv2.AdaptiveThreshold(src, dst, 255, adaptiveThresholdType, thresholdType, kSize, constant);
            //        break;
            //    case BlobMode.inRange:
            //        Cv2.InRange(src, new Scalar(rangeLow), new Scalar(rangeHigh), dst);
            //        break;
            //    default:
            //        //IplImage image = src.ToIplImage();
            //        //IplImage dstImage = new IplImage(src.Width, src.Height, BitDepth.U8, src.Channels());
            //        Mat image = src.Clone();
            //        Mat dstImage = new Mat(src.Rows, src.Cols, MatType.CV_8UC1);
            //        switch (mode)
            //        {
            //            case BlobMode.Bernsen:
            //                dstImage = Bernsen(image, kSize, rangeLow);
            //                break;

            //            case BlobMode.Nick:
            //                dstImage = Nick(image, kSize, adequateCoefficient);
            //                break;

            //            case BlobMode.NiblackFast:
            //                dstImage = Niblack(image, kSize, adequateCoefficient);
            //                break;

            //            case BlobMode.SauvolaFast:
            //                dstImage = Sauvola(image, kSize, adequateCoefficient, adequateCoefficientR);
            //                break;
            //        }
            //        image.Dispose();
            //        dst = dstImage.Clone();
            //        dstImage.Dispose();
            //        break;
            //}

            switch (mode)
            {
                case BlobMode.Theshold:

                    ThresholdType thresholdType;

                    if (pola == BlobPolarity.White && binaryType == BlobBinaryType.ToBlack)
                        thresholdType = ThresholdType.Binary;
                    else if (pola == BlobPolarity.White && binaryType == BlobBinaryType.ToZero)
                        thresholdType = ThresholdType.ToZero;
                    else if (pola == BlobPolarity.Black && binaryType == BlobBinaryType.ToBlack)
                        thresholdType = ThresholdType.BinaryInv;
                    else if (pola == BlobPolarity.Black && binaryType == BlobBinaryType.ToZero)
                        thresholdType = ThresholdType.ToZeroInv;
                    else
                        throw new Exception("thresholdType not find");

                    if (type == BlobType.Otsu)
                        thresholdType |= ThresholdType.Otsu;

                    if (type == BlobType.Gaussian || type == BlobType.Mean)
                        //throw new Exception("wrong threshold type");
                       System.Windows.Forms.MessageBox.Show("wrong threshold type");

                    Cv2.Threshold(src, dst, rangeLow, 255, thresholdType);
                    break;
                case BlobMode.Adaptive:

                    AdaptiveThresholdType adaptiveThresholdType;

                    if (type == BlobType.Gaussian)
                        adaptiveThresholdType = AdaptiveThresholdType.GaussianC;
                    else if (type == BlobType.Mean)
                        adaptiveThresholdType = AdaptiveThresholdType.MeanC;
                    else
                        throw new Exception("BlobMode must be Gaussian or Mean");

                    if (pola == BlobPolarity.White)
                        thresholdType = ThresholdType.Binary;
                    else if (pola == BlobPolarity.Black)
                        thresholdType = ThresholdType.BinaryInv;
                    else
                        throw new Exception("BlobPolarity must be Binary or BinaryInv");

                    Cv2.AdaptiveThreshold(src, dst, 255, adaptiveThresholdType, thresholdType, kSize, constant);
                    break;
                case BlobMode.inRange:
                    Cv2.InRange(src, new Scalar(rangeLow), new Scalar(rangeHigh), dst);
                    break;
                default:
                    IplImage image = src.ToIplImage();
                    IplImage dstImage = new IplImage(src.Width, src.Height, BitDepth.U8, src.Channels());
                    switch (mode)
                    {
                        case BlobMode.Bernsen:
                            Binarizer.Bernsen(image, dstImage, kSize, (byte)constant, (byte)rangeLow);
                            break;
                        case BlobMode.Nick:
                            Binarizer.Nick(image, dstImage, kSize, adequateCoefficient);
                            break;
                        case BlobMode.NiblackFast:
                            Binarizer.NiblackFast(image, dstImage, kSize, adequateCoefficient);
                            break;
                        case BlobMode.SauvolaFast:
                            Binarizer.SauvolaFast(image, dstImage, kSize, adequateCoefficient, adequateCoefficientR);
                            break;
                    }
                    image.Dispose();
                    dst = new Mat(dstImage, true);
                    dstImage.Dispose();
                    break;
            }
            return dst;
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;

            if (BinaryImage != null) BinaryImage.Dispose();
            BinaryImage = null;

            if (BlobImage != null) BlobImage.Dispose();
            BlobImage = null;

            Blobs.Clear();
            GetOutParams();
        }

        //public void ApplyFilter(List<Blob> cvBlobs)
        public void ApplyFilter(CvBlobs cvBlobs)
        {
            List<int> requireRemoveList = new List<int>();
            for (int i = 1; i <= cvBlobs.Count; i++)
            {
                bool requireRemove = false;
                foreach (svBlobFilter filter in BlobFilter)
                {
                    if (!filter.Use) continue;

                    switch (filter.Property)
                    {
                        case svBlobFilter.Properties.Area:
                            if (filter.Range == svBlobFilter.RangeFilter.Include)
                            { if (cvBlobs[i].Area < filter.Low || cvBlobs[i].Area > filter.High) requireRemove = true; }
                            else if (filter.Range == svBlobFilter.RangeFilter.Exclude)
                            { if (cvBlobs[i].Area >= filter.Low && cvBlobs[i].Area <= filter.High) requireRemove = true; }
                            break;
                        case svBlobFilter.Properties.CenterMassX:
                            if (filter.Range == svBlobFilter.RangeFilter.Include)
                            { if (cvBlobs[i].Centroid.X < filter.Low || cvBlobs[i].Centroid.X > filter.High) requireRemove = true; }
                            else if (filter.Range == svBlobFilter.RangeFilter.Exclude)
                            { if (cvBlobs[i].Centroid.X >= filter.Low && cvBlobs[i].Centroid.X <= filter.High) requireRemove = true; }
                            break;
                        case svBlobFilter.Properties.CenterMassY:
                            if (filter.Range == svBlobFilter.RangeFilter.Include)
                            { if (cvBlobs[i].Centroid.Y < filter.Low || cvBlobs[i].Centroid.Y > filter.High) requireRemove = true; }
                            else if (filter.Range == svBlobFilter.RangeFilter.Exclude)
                            { if (cvBlobs[i].Centroid.Y >= filter.Low && cvBlobs[i].Centroid.Y <= filter.High) requireRemove = true; }
                            break;
                        // 20160704 Angle Filter ADD _ Hozzang
                        case svBlobFilter.Properties.Angle:
                            //angle = Math.Atan(2 * cvBlobs[i].N11 / (cvBlobs[i].N20 - cvBlobs[i].N02)) / 2;
                            //if (angle > 0)
                            //{ if (cvBlobs[i].U20 < cvBlobs[i].U02) angle = angle - 90 * (Math.PI / 180); }
                            //else
                            //{ if (cvBlobs[i].U20 < cvBlobs[i].U02) angle = 90 * (Math.PI / 180) + angle; }

                            Moments m = Cv2.Moments(cvBlobs[i].Area);
                            double angle = 0;
                            angle = Math.Atan(2 * m.Nu11 / (m.Nu20 - m.Nu02)) / 2;

                            if (angle > 0)
                            { if (m.Nu20 < m.Nu02) angle = angle - 90 * (Math.PI / 180); }
                            else
                            { if (m.Nu20 < m.Nu02) angle = 90 * (Math.PI / 180) + angle; }

                            angle = angle * (180 / Math.PI);

                            if (filter.Range == svBlobFilter.RangeFilter.Include)
                            { if (angle < filter.Low || angle > filter.High) requireRemove = true; }
                            else if (filter.Range == svBlobFilter.RangeFilter.Exclude)
                            { if (blobs[i].Angle >= filter.Low && blobs[i].Angle <= filter.High) requireRemove = true; }
                            break;
                        case svBlobFilter.Properties.RectSize:
                            if (filter.Range == svBlobFilter.RangeFilter.Include)
                            { if ((cvBlobs[i].Rect.Width * cvBlobs[i].Rect.Height) < filter.Low || (cvBlobs[i].Rect.Width * cvBlobs[i].Rect.Height) > filter.High) requireRemove = true; }
                            else if (filter.Range == svBlobFilter.RangeFilter.Exclude)
                            { if ((cvBlobs[i].Rect.Width * cvBlobs[i].Rect.Height) >= filter.Low && (cvBlobs[i].Rect.Width * cvBlobs[i].Rect.Height) <= filter.High) requireRemove = true; }
                            break;
                        case svBlobFilter.Properties.RectWidth:
                            if (filter.Range == svBlobFilter.RangeFilter.Include)
                            { if (cvBlobs[i].Rect.Width < filter.Low || cvBlobs[i].Rect.Width > filter.High) requireRemove = true; }
                            else if (filter.Range == svBlobFilter.RangeFilter.Exclude)
                            { if (cvBlobs[i].Rect.Width >= filter.Low && cvBlobs[i].Rect.Width <= filter.High) requireRemove = true; }
                            break;
                        case svBlobFilter.Properties.RectHeight:
                            if (filter.Range == svBlobFilter.RangeFilter.Include)
                            { if (cvBlobs[i].Rect.Height < filter.Low || cvBlobs[i].Rect.Height > filter.High) requireRemove = true; }
                            else if (filter.Range == svBlobFilter.RangeFilter.Exclude)
                            { if (cvBlobs[i].Rect.Height >= filter.Low && cvBlobs[i].Rect.Height <= filter.High) requireRemove = true; }
                            break;
                        default:
                            break;
                    }
                }
                if (requireRemove) requireRemoveList.Add(i);
            }
            foreach (int index in requireRemoveList) { cvBlobs.Remove(index); }
            //foreach (int index in requireRemoveList) {cvBlobs.RemoveAt(index); }
        }

        public void DisplayBlobInfo(MvCore.Display.MvDisplayView display)
        {
            //display.GraphicsFuncCollection.Clear();
            if (InputImage ==  null || display.Image == null || display.Image.Mat == null || display.Image.Mat.Width == 0) return;

            Pen p = new Pen(Color.Pink);

            double X = InputImage.RegionRect.RectF.X;
            double Y = InputImage.RegionRect.RectF.Y;
            Size2f size = InputImage.RegionRect.RectF.Size;
            display.DrawRectangle(p, new Point2d(X, Y), size);

            System.Drawing.Font font = new System.Drawing.Font("굴림체", 12, System.Drawing.FontStyle.Bold);
            System.Drawing.SolidBrush brush = new System.Drawing.SolidBrush(System.Drawing.Color.Violet);
            string tmp = string.Format("AreaSum: {0}\r\nRegion: {1:f0}\r\nAreaRate : {2:f4}\r\nRectLengthSum : {3}\r\nRectAreaSum : {4}", AreaSum, size.Width * size.Height, AreaRate, RectLengthSum, RectAreaSum);

            display.DrawString(tmp, font, brush, new Point2d(10, 10));

            display.Invalidate();
        }

        public override void Run(bool isEditMode = false)
        {
            DateTime s = DateTime.Now;

            inputImageInfo.Image = InputImage;

            if (InputImage == null) return;

            AreaSum = 0; RectLengthSum = 0; RectAreaSum = 0;
           OpenCvSharp.CPlusPlus.Rect regionRect = InputImage.RegionRect.Rect;

            Rectf roiRectf = InputImage.RegionRect.RectF;

            Point2f[] pts = InputImage.RegionRect2fPtsImage;
            Point2f[] pts2 = InputImage.RegionRect2fPts;

            Mat pMat = Cv2.GetPerspectiveTransform(pts, pts2);
            Mat temp = new Mat();
            Cv2.WarpPerspective(InputImage.Mat, temp, pMat, new OpenCvSharp.CPlusPlus.Size(roiRectf.Size.Width, roiRectf.Size.Height));

            // 직사각형 Blob Image
            Mat binary = Binarizing(temp, Mode, Type, Polarity, BinaryType, RangeLow, RangeHigh, KernelSize, constant, AdequateCoefficient, AdequateCoefficientR);

            RegionImage = temp;
            if (!isGetBlob)
                AreaSum = binary.CountNonZero();

            // 역warping Blob Image


            // Display Blob Image
            Mat binarywarp = new Mat();
            pMat = Cv2.GetPerspectiveTransform(pts2, pts);
            Cv2.WarpPerspective(binary, binarywarp, pMat, InputImage.Mat.Size());

            Mat mask = new Mat(InputImage.Mat.Size(), InputImage.Mat.Type());
            mask.SetTo(0);
            mask.FillPoly(new OpenCvSharp.CPlusPlus.Point[][] { InputImage.RegionRectPtsImage },new Scalar(1));

            BinaryImage = InputImage.Clone(true);
            binarywarp.CopyTo(BinaryImage.Mat, mask);

            //SvFunc.ShowTestImg(temp, 0.5);
            //SvFunc.ShowTestImg(binary, 0.5);
            //SvFunc.ShowTestImg(BinaryImage.Mat, 0.5);


            binaryImageInfo.Image = BinaryImage;

            if (isGetBlob)
            {
                Mat roiMat = new Mat();

                using (Mat regionMat = new Mat(BinaryImage.Mat.Size(), MatType.CV_8U))
                {
                    Cv2.Rectangle(regionMat, regionRect, new Scalar(1), -1);
                    BinaryImage.Mat.CopyTo(roiMat, regionMat);
                }

                string 이진화변환시간 = "이진화 변환시간 : " + DateTime.Now.Subtract(s).TotalMilliseconds.ToString() + "\r\n";

                s = DateTime.Now;

                if (isfillingHole)
                {
                    DateTime fillingHoleTimeStart = DateTime.Now;
                    OpenCvSharp.CPlusPlus.Point[][] contours; HierarchyIndex[] hierarchyIndex;
                    roiMat.FindContours(out contours, out hierarchyIndex, ContourRetrieval.External, ContourChain.ApproxNone);
                    roiMat.DrawContours(contours, -1, new Scalar(255), -1, LineType.Link8, hierarchyIndex);
                    //roiMat.FindContours(out contours, out hierarchyIndex,RetrievalModes.External ,ContourApproximationModes.ApproxNone);
                    //roiMat.DrawContours(contours, -1, new Scalar(255), -1, LineTypes.Link8, hierarchyIndex);
                    double fillingHoleTime = DateTime.Now.Subtract(fillingHoleTimeStart).TotalMilliseconds;
                    Console.WriteLine("fillingHole 계산시간 : " + fillingHoleTime.ToString());
                }

                IplImage ipl_BinImage = roiMat.ToIplImage(false);
                CvBlobs cvBlobs = new CvBlobs(ipl_BinImage);
                //Mat ipl_BinImage = roiMat.Clone();
                //Cv2.CvtColor(ipl_BinImage, ipl_BinImage, ColorConversionCodes.BGR2GRAY);
                //Mat m_binary = new Mat();
                //Cv2.Threshold(ipl_BinImage, m_binary, 128, 255, ThresholdTypes.Binary);
                //var param = new SimpleBlobDetector.Params();
                //param.FilterByArea = true;
                //param.MinArea = 50;
                //param.MaxArea = 5000;

                //param.FilterByCircularity = false;
                //param.FilterByConvexity = false;
                //param.FilterByInertia = false;

                //// Nếu blob sáng trên nền tối:
                //param.FilterByColor = true;
                //param.BlobColor = 255;
                //// Tạo detector
                //var detector = SimpleBlobDetector.Create(param);
                //// Phát hiện blob
                //KeyPoint[] keypoints = detector.Detect(m_binary);

                //var cc = Cv2.ConnectedComponentsEx(m_binary);
                //var m_blobs = cc.Blobs;
                //List<Blob> cvBlobs = m_blobs.ToList();
                ApplyFilter(cvBlobs);

                if (blobs == null) blobs = new List<MvBlobObject>();
                else blobs.Clear();

                //if (isExceptBoundary)
                //{
                //    foreach (KeyValuePair<int, CvBlob> cvblobPair in cvBlobs)
                //}

                foreach (KeyValuePair<int, CvBlob> cvblobPair in cvBlobs)
                {
                    CvBlob cvBlob = cvblobPair.Value;

                    double thetarad;

                    if ((cvBlob.N20 - cvBlob.N02) == 0) thetarad = 0;
                    else
                        thetarad = Math.Atan(2 * cvBlob.N11 / (cvBlob.N20 - cvBlob.N02)) / 2;

                    if (thetarad > 0)
                    { if (cvBlob.U20 < cvBlob.U02) thetarad = thetarad - 90 * (Math.PI / 180); }
                    else
                    { if (cvBlob.U20 < cvBlob.U02) thetarad = 90 * (Math.PI / 180) + thetarad; }

                    MvBlobObject blob = new MvBlobObject(cvBlob.Label, cvBlob.Area, new Point2d(cvBlob.Centroid.X, cvBlob.Centroid.Y), thetarad * (180 / Math.PI), (cvBlob.Rect.Width * cvBlob.Rect.Height), cvBlob.Rect.Width, cvBlob.Rect.Height);

                    //Insert Sort
                    int insertIndex;
                    for (insertIndex = 0; insertIndex < blobs.Count; insertIndex++)
                    {
                        if (blob.Area > blobs[insertIndex].Area)
                            break;
                    }

                    blobs.Insert(insertIndex, blob);
                }
                //foreach ( Blob cvBlob in cvBlobs)
                //{
                //    Moments m = Cv2.Moments(cvBlob.Area);
                //    double thetarad;

                //    //if ((cvBlob.N20 - cvBlob.N02) == 0) thetarad = 0;
                //    //else
                //    //    thetarad = Math.Atan(2 * cvBlob.N11 / (cvBlob.N20 - cvBlob.N02)) / 2;
                //    //if (thetarad > 0)
                //    //{ if (cvBlob.U20 < cvBlob.U02) thetarad = thetarad - 90 * (Math.PI / 180); }
                //    //else
                //    //{ if (cvBlob.U20 < cvBlob.U02) thetarad = 90 * (Math.PI / 180) + thetarad; }

                //    if ((m.Nu20 - m.Nu02) == 0) thetarad = 0;
                //    else
                //        thetarad = Math.Atan(2 * m.Nu11 / (m.Nu20 - m.Nu02)) / 2;
                //    if (thetarad > 0)
                //    { if (m.Nu20 < m.Nu02) thetarad = thetarad - 90 * (Math.PI / 180); }
                //    else
                //    { if (m.Nu20 < m.Nu02) thetarad = 90 * (Math.PI / 180) + thetarad; }

                //    MvBlobObject blob = new MvBlobObject(cvBlob.Label, cvBlob.Area, new Point2d(cvBlob.Centroid.X, cvBlob.Centroid.Y), thetarad * (180 / Math.PI), (cvBlob.Rect.Width * cvBlob.Rect.Height), cvBlob.Rect.Width, cvBlob.Rect.Height);

                //    //Insert Sort
                //    int insertIndex;
                //    for (insertIndex = 0; insertIndex < blobs.Count; insertIndex++)
                //    {
                //        if (blob.Area > blobs[insertIndex].Area)
                //            break;
                //    }

                //    blobs.Insert(insertIndex, blob);
                //}

                string Blob계산시간 = "Blob 계산시간 : " + DateTime.Now.Subtract(s).TotalMilliseconds.ToString() + "\r\n";
                Console.WriteLine(이진화변환시간 + Blob계산시간);

                if (isEditMode)
                {
                    if (BinaryImage != null)
                    {
                        IplImage BlobIpl = new IplImage(ipl_BinImage.Size, ipl_BinImage.Depth, 3);
                        //Mat blobMat = RenderBlobsOpenCvSharp4(ipl_BinImage);
                        try
                        {
                            cvBlobs.RenderBlobs(ipl_BinImage, BlobIpl, RenderBlobsMode.Angle | RenderBlobsMode.Centroid | RenderBlobsMode.Color | RenderBlobsMode.BoundingBox);
                            //BlobImage = new MvImage(blobMat.Clone());
                            if (BlobImage != null) BlobImage.Dispose();
                            BlobImage = new MvImage(new Mat(BlobIpl).Clone());
                            //BlobImage = new MvImage(new Mat(blobMat).Clone());

                            BlobIpl.Dispose();
                            //blobMat.Dispose();
                            blobImageInfo.Image = BlobImage;

                            if (!imageList.Contains(blobImageInfo))
                                imageList.Add(blobImageInfo);
                        }
                        catch
                        {
                            if (BlobImage != null) BlobImage.Dispose();
                            BlobIpl.Dispose();
                            //blobMat.Dispose();
                        }
                    }
                }

                cvBlobs.Clear();
                roiMat.Dispose();


                if (blobs != null && blobs.Count > 0)
                {
                    switch (Priority)
                    {
                        case BlobDirection.None:
                            blobs.Sort((x, y) =>
                            {
                                double xVal, yVal;
                                switch (sortingOrder)
                                {
                                    case svBlobFilter.Properties.Area:
                                        xVal = x.Area; yVal = y.Area;
                                        break;
                                    case svBlobFilter.Properties.CenterMassX:
                                        xVal = x.Centroid.X; yVal = y.Centroid.X;
                                        break;
                                    case svBlobFilter.Properties.CenterMassY:
                                        xVal = x.Centroid.Y; yVal = y.Centroid.Y;
                                        break;
                                    case svBlobFilter.Properties.Angle:
                                        xVal = x.Angle; yVal = y.Angle;
                                        break;
                                    case svBlobFilter.Properties.RectSize:
                                        xVal = x.RectSize; yVal = y.RectSize;
                                        break;
                                    case svBlobFilter.Properties.RectWidth:
                                        xVal = x.RectWidth; yVal = y.RectWidth;
                                        break;
                                    case svBlobFilter.Properties.RectHeight:
                                        xVal = x.RectHeight; yVal = y.RectHeight;
                                        break;
                                    default:
                                        return 0;
                                }

                                int retrunVal = 0;
                                if (xVal > yVal) retrunVal = -1;
                                else if (xVal < yVal) retrunVal = 1;
                                else retrunVal = 0;

                                if (IsSortingAscending) retrunVal *= -1;

                                return retrunVal;
                            }
                            );
                            break;
                        case BlobDirection.Left:
                            Blobs.Sort((a, b) => ((a.Centroid.X < b.Centroid.X) ? -1 : 1));
                            break;
                        case BlobDirection.Right:
                            Blobs.Sort((a, b) => ((a.Centroid.X > b.Centroid.X) ? -1 : 1));
                            break;
                        case BlobDirection.Top:
                            Blobs.Sort((a, b) => ((a.Centroid.Y < b.Centroid.Y) ? -1 : 1));
                            break;
                        case BlobDirection.Bottom:
                            Blobs.Sort((a, b) => ((a.Centroid.Y > b.Centroid.Y) ? -1 : 1));
                            break;
                    }
                    //AreaSum = 0;
                    //RectLengthSum = 0;
                    //RectAreaSum = 0;
                    if (MaxCount > blobs.Count || MaxCount == 0)
                        MaxCount = blobs.Count;
                    for (int i = 0; i < MaxCount; i++)
                    {
                        AreaSum += blobs[i].Area;
                        RectLengthSum += blobs[i].RectWidth + blobs[i].RectHeight;
                        RectAreaSum += blobs[i].RectSize;
                    }
                    TranslateX = (float)blobs[0].Centroid.X;
                    TranslateY = (float)blobs[0].Centroid.Y;
                    Rotation = (float)(blobs[0].Angle * Math.PI / 180);
                }
            }
            else
            {
                AreaSum = binary.CountNonZero();

                if (imageList.Contains(blobImageInfo))
                    imageList.Remove(blobImageInfo);
            }

            binaryImageInfo.drawingFunc = DisplayBlobInfo;
            blobImageInfo.drawingFunc = DisplayBlobInfo;

            temp.Dispose();
            binary.Dispose();
            binarywarp.Dispose();
            mask.Dispose();
            pMat.Dispose();

            if (isEditMode)
                NotifyPropertyChanged("Blobs");

            lastRunSuccess = true;
        }
        //public static Mat RenderBlobsOpenCvSharp4(Mat binary)
        //{
        //    // Kết quả là ảnh màu
        //    Mat output = new Mat();
        //    Cv2.CvtColor(binary, output, ColorConversionCodes.GRAY2BGR);

        //    // Tìm contour (đại diện blob)
        //  OpenCvSharp.Point[][] contours;
        //    HierarchyIndex[] hier;
        //    Cv2.FindContours(binary, out contours, out hier,
        //        RetrievalModes.External, ContourApproximationModes.ApproxSimple);

        //    Random rng = new Random();

        //    foreach (var contour in contours)
        //    {
        //        if (contour.Length < 5)
        //            continue;

        //        // --- 1. Màu blob ----
        //        Scalar color = new Scalar(
        //            rng.Next(50, 255),
        //            rng.Next(50, 255),
        //            rng.Next(50, 255)
        //        );

        //        // --- 2. Bounding Box xoay (MinAreaRect) ----
        //        RotatedRect r = Cv2.MinAreaRect(contour);
        //        Point2f[] pts = r.Points();
        //        for (int j = 0; j < 4; j++)
        //            Cv2.Line(output, (OpenCvSharp.Point)pts[j], (OpenCvSharp.Point)pts[(j + 1) % 4], color, 2);

        //        // --- 3. Tâm (centroid) ----
        //        Moments m = Cv2.Moments(contour);
        //        int cx = (int)(m.M10 / m.M00);
        //        int cy = (int)(m.M01 / m.M00);

        //        Cv2.Circle(output, new OpenCvSharp.Point(cx, cy), 3, Scalar.Yellow, -1);

        //        // --- 4. Hướng blob (angle từ MinAreaRect) ----
        //        double angle = r.Angle;
        //        Cv2.PutText(output, $"Angle: {angle:F1}",
        //            new OpenCvSharp.Point(cx + 5, cy - 5),
        //            HersheyFonts.HersheySimplex, 0.5, Scalar.White, 1);

        //        // --- 5. Vẽ contour (màu blob) ----
        //        Cv2.DrawContours(output, new[] { contour }, -1, color, 2);
        //    }

        //    return output;
        //}

    }
}
