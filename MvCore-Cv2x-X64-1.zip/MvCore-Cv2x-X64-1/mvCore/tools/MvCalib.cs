﻿using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using MvCore.Edit.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
//using static MvCore.MvToolBlock;
using MvCore.Edit;
using MvCore.util;



namespace MvCore
{

    public delegate void calDataHandl(MvCalibrationData data);
    [Serializable] //khai báo serial lưu dữ liệu

    public class MvCalib : MvToolBase
    {
        public static event calDataHandl calDataEvent;
        LogFile log;
        public MvCalib()
        {
            log = new LogFile();
            //inputTool = new SvInnerToolBlock();
            //inputTool.toolName = "Input";
            //outputTool = new SvInnerToolBlock();
            //outputTool.toolName = "Output";
            //calDataEvent?.Invoke(calibration.CalData);

        }
        public MvCalib(SerializationInfo info, StreamingContext context) : base(info, context) { } //khai báo đọc dữ liệu



        public enum E_Tool
        {
            tool0 = 0, tool1 = 1, tool2 = 2, tool3 = 3, tool4 = 4, tool5 = 5, tool6 = 6, tool7 = 7, tool8 = 8, tool9 = 9
        }

        public override void InitImageList()
        {
            //throw new NotImplementedException();
        }

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
            inParams.Add("Receiver", null);
            inParams.Add("VisionX", null);
            inParams.Add("VisionY", null);
            inParams.Add("V_Rotation", null);
            outParams.Add("RobotX", null);
            outParams.Add("RobotY", null);
            outParams.Add("R_Rotation", null);
        }

        private string receiver;
        private float visionX;
        private float visionY;
        private float v_Rotation;
        private float robotX;
        private float robotY;
        private float r_Rotation;
        private Mat matrixV2R;
        private Mat matrixR2V;
        private List<Point3d> visionPoints = new List<Point3d>();
        private List<Point3d> robotPoints = new List<Point3d>();
        public MvCalibration calibration = new MvCalibration();
        private Point2d visionTCP;
        private Point3d visionMaster;

        private MvImage inputImage;

        public MvImage InputImage
        {
            get { return inputImage; }
            set { inputImage = value; }
        }
        //public int ToolSelect
        //{
        //    get { return toolSelect; }
        //    set { toolSelect = value; }
        //}

        private E_Tool tool;

        public E_Tool Tool
        {
            get { return tool; }
            set { tool = value; }
        }


        [InputParam]
        public string Receiver
        {
            get { return receiver; }
            set { receiver = value; }
        }
        [InputParam]
        public float VisionX
        {
            get { return visionX; }
            set { visionX = value; }
        }
        [InputParam]
        public float VisionY
        {
            get { return visionY; }
            set { visionY = value; }
        }
        [InputParam]
        public float V_Rotation
        {
            get { return v_Rotation; }
            set { v_Rotation = value; }
        }
        [OutputParam]
        public float RobotX
        {
            get { return robotX; }
            set { robotX = value; }
        }
        [OutputParam]
        public float RobotY
        {
            get { return robotY; }
            set { robotY = value; }
        }
        [OutputParam]

        public float R_Rotation
        {
            get { return r_Rotation; }
            set { r_Rotation = value; }
        }

        private bool saveLog;

        public bool SaveLog
        {
            get { return saveLog; }
            set { saveLog = value; }
        }


        //[OutputParam]
        //public Mat Matrix
        //{
        //    get { return matrix; }
        //    set { matrix = value; }
        //}
        //public Point2d VisionTCP
        //{
        //    get { return visionTCP; }
        //    set { visionTCP = value; }
        //}
        //public Point3d VisionMaster
        //{
        //    get { return visionMaster; }
        //    set { visionMaster = value; }
        //}


        public override void InitOutParmas()
        {
            //do nothing this tool
            outParams.Add("Matrix", null);
        }

        public override void InitOutProperty()
        {
            //throw new NotImplementedException();
        }

        //{,HE1,0,170.000,520.000,13.032,}
        string[] split(string data)
        {
            return data.Trim('{', '}').Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        }


        public override void Run(bool isEditMode = false)
        {
            //Point2d SubPoint2 = calibration.find_RotatePoint(new Point3d(637, 401, 0), new Point2d(873, 403),45); OK
            //GetInParams();
            //List<Point3d> l_rot = new List<Point3d>() { new Point3d(637, 401, 0), new Point3d(645, 463, 0), new Point3d(645, 340,0) }; //new Point3d(645, 340, 0), new Point3d(706,235, 0), new Point3d(755,198, 0),new Point3d(812,173, 0)
            //Point2d tcp = calibration.FindRotationCenter(l_rot);

            RobotX = 0;
            RobotY = 0;
            R_Rotation = 0;
            if (inParams["Receiver"]?.GetValue() != null)
            {
                string[] data = split((string)inParams["Receiver"].GetValue());


                if (data[0] == $"HEB{(int)Tool}")
                {
                    //làm mới các list
                    visionPoints.Clear();
                    robotPoints.Clear();
                    matrixV2R = new Mat();
                    matrixR2V = new Mat();
                    calibration.CalData = new MvCalibrationData();
                }
                else if (data[0] == $"HE{(int)Tool}")
                {
                    //chuyển đổi dữ liệu nhận được từ robot
                    float.TryParse(data[2], out robotX);
                    float.TryParse(data[3], out robotY);
                    float.TryParse(data[4], out r_Rotation);
                    //add dữ liệu vị trí robot và vision
                    visionPoints.Add(new Point3d(visionX, visionY, v_Rotation));
                    robotPoints.Add(new Point3d(robotX, robotY, R_Rotation));
                }
                else if (data[0] == $"HEE{(int)Tool}")
                {
                    //chuyển đổi dữ liệu nhận được từ robot
                    float.TryParse(data[2], out robotX);
                    float.TryParse(data[3], out robotY);
                    float.TryParse(data[4], out r_Rotation);

                    //dữ liệu vision Point
                    calibration.CalData.RefPoint = visionPoints.Select(p => new Point2d(p.X, p.Y)).ToArray();
                    //dữ liệu robot Point
                    calibration.CalData.RobotPoint = robotPoints.Select(p => new Point2d(p.X, p.Y)).ToArray();

                    //tách phần dữ liệu rotation của vision trong VisionPoints
                    calibration.CalData.RotPoints = visionPoints.GetRange(calibration.CalData.GPNo, visionPoints.Count() - calibration.CalData.GPNo);
                    //sắp xếp dữ liệu Rotation Point theo T
                    List<Point3d> l_RotSort = calibration.CalData.RotPoints.ToList();
                    l_RotSort.Sort((p1, p2) => p1.Z.CompareTo(p2.Z));
                    calibration.CalData.AngleFrom = (float)l_RotSort[0].Z;
                    calibration.CalData.AngleTo = (float)l_RotSort[l_RotSort.Count - 1].Z;

                    //tìm tâm TCP robot trên tọa độ vision
                    calibration.CalData.VisionHE_TCP = calibration.FindRotationCenter(calibration.CalData.RotPoints);
                    calibration.CalData.RobotHE_TCP = new Point2d(robotX, robotY);
                    //tìm khoảng cách Mark HE vision master với TCP vision Master
                    Point2d distance = new Point2d(visionPoints[calibration.CalData.GPNo].X, visionPoints[calibration.CalData.GPNo].Y) - calibration.CalData.VisionHE_TCP;
                    calibration.CalData.Distance = distance;
                    //đưa vị trí  HE vision master về TCP vision Master
                    calibration.CalData.ShiftPoint = new Point2d[calibration.CalData.RefPoint.Length];
                    for (int i = 0; i < calibration.CalData.RefPoint.Length; i++)
                    {
                        calibration.CalData.ShiftPoint[i] = calibration.CalData.RefPoint[i] - distance;
                    }

                    //tách 9 điểm matrixPoint của robot
                    Point2d[] visionPt = calibration.CalData.ShiftPoint.Skip(0).Take(calibration.CalData.GPNo).ToArray();
                    Point2d[] robotPt = robotPoints.GetRange(0, 9).ToArray().Select(p => new Point2d(p.X, p.Y)).ToArray();
                    calibration.CalData.VtoRMat.Mat = calibration.CalcCalibrationMat(visionPt, robotPt);



                    if (calibration.CalData.CalImage == null || calibration.CalData.CalImage.IsNull) { calibration.CalData.CalImage = InputImage.Clone(true); }
                    //if (calibration.CalData.RotImage == null || calibration.CalData.RotImage.IsNull) {calibration.CalData.RotImage = InputImage.Clone(true); }
                    calibration.CalData.RotShiftH = calibration.CalData.RotShiftH = 0;
                    calDataEvent?.Invoke(calibration.CalData);

                }
                else if (data[0] == $"TT{(int)Tool}")
                {
                    //chuyển đổi dữ liệu nhận được từ robot
                    float.TryParse(data[2], out robotX);
                    float.TryParse(data[3], out robotY);
                    float.TryParse(data[4], out r_Rotation);
                    //lấy vị trí từ robot gửi tới (TCP robot)
                    //chuyển đổi dữ liệu từ TCP robot sang vị trí TCP vision(TCProbot x matrixR2V)  //luu vi tri tam xoay TCP Vision

                    calibration.CalData.RobotTT_TCP = new Point2d(RobotX, RobotY);
                    calibration.CalData.VisionTT_TCP = calibration.RtoV(new Point2d(RobotX, RobotY));
                    //lưu vi tri master
                    calibration.CalData.VisionMaster = new Point3d(VisionX, VisionY, V_Rotation);
                    Point2d cvtMaster = calibration.VtoR(new Point2d(calibration.CalData.VisionMaster.X, calibration.CalData.VisionMaster.Y));
                    calibration.CalData.RobotMaster = new Point3d(cvtMaster.X, cvtMaster.Y, V_Rotation);
                    //if (calibration.CalData.CalImage == null || calibration.CalData.CalImage.IsNull) { calibration.CalData.CalImage = InputImage.Clone(true); }
                    if (calibration.CalData.RotImage == null || calibration.CalData.RotImage.IsNull) { calibration.CalData.RotImage = InputImage.Clone(true); }
                    calDataEvent?.Invoke(calibration.CalData);

                }
                else if (data[0].Contains("XT"))
                {
                    if (double.IsNaN(VisionX) || double.IsNaN(VisionY) || double.IsNaN(V_Rotation))
                    {
                        RobotX = 0; RobotY = 0; R_Rotation = 0;
                        GetOutParams();
                        lastRunSuccess = false;
                        return;
                    }
                    //lấy vi tri mới của object
                    Point3d curPoint = new Point3d(VisionX, VisionY, V_Rotation);
                    //so sanh với vị trí master ==> Angle + distance

                    Point2d newPoint = calibration.find_RotatePoint(new Point3d(curPoint.X, curPoint.Y, calibration.CalData.VisionMaster.Z - curPoint.Z), calibration.CalData.VisionTT_TCP);
                    Point2d RobotShift = calibration.VtoR(newPoint);
                    Point3d RobotDistance = new Point3d(calibration.CalData.RobotMaster.X - RobotShift.X, calibration.CalData.RobotMaster.Y - RobotShift.Y, calibration.CalData.VisionMaster.Z - curPoint.Z);
                    //gửi Angle+distance =>Robot
                    RobotX = (float)Math.Round(RobotDistance.X, 3);
                    RobotY = (float)Math.Round(RobotDistance.Y, 3);
                    R_Rotation = (float)Math.Round(RobotDistance.Z, 3);
                    if (SaveLog == true)
                    {
                        if (log == null)
                        {
                            log = new LogFile();
                        }
                        log.saveLog($"VisisonSend: X: {VisionX},Y: {VisionY},R: {V_Rotation}");
                        log.saveLog($"RobotReceiv: X: {RobotX} ,Y: {RobotY},R: {R_Rotation}");
                    }
                }
                else if (data[0].Contains("RF"))

                {
                    //calibration.CalData.RotCenter = calibration.VtoR(calibration.CalData.VisionTCP);
                    if (calibration.CalData.CalImage == null || calibration.CalData.CalImage.IsNull) { calibration.CalData.CalImage = InputImage.Clone(true); }
                    if (calibration.CalData.RotImage == null || calibration.CalData.RotImage.IsNull) { calibration.CalData.RotImage = InputImage.Clone(true); }
                    calDataEvent?.Invoke(calibration.CalData);
                }
            }
            GetOutParams();
            lastRunSuccess = true;
        }
    }
}
