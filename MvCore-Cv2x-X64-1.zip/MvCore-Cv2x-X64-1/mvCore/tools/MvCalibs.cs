﻿using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using MvCore.Edit.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using static MvCore.MvToolBlock;
using MvCore.Edit;



namespace MvCore
{

    public delegate void calDataHandls(MvCalibrationData data);
    [Serializable] //khai báo serial lưu dữ liệu
   
    public class MvCalibs : MvToolBase
    {
        public static event calDataHandl calDataEvent;
        public MvCalibs()
        {
            //inputTool = new SvInnerToolBlock();
            //inputTool.toolName = "Input";
            //outputTool = new SvInnerToolBlock();
            //outputTool.toolName = "Output";
            //calDataEvent?.Invoke(calibration.CalData);

        }
        public MvCalibs(SerializationInfo info, StreamingContext context) : base(info, context) { } //khai báo đọc dữ liệu



        public enum E_Tool
        {
            Tool0 = 0,Tool1=1,Tool2=2,Tool3=3,Tool4=4,Tool5=5,Tool6=6,Tool7=7,Tool8=8,Tool9=9
        }

        public override void InitImageList()
        {
            //throw new NotImplementedException();
        }

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
            inParams.Add("Receiver", null);
            inParams.Add("VisionX", null);
            inParams.Add("VisionY", null);
            inParams.Add("V_Rotation", null);
            outParams.Add("RobotX", null);
            outParams.Add("RobotY", null);
            outParams.Add("R_Rotation", null);
        }
      
        private string receiver;
        private float[] visionX;
        private float[] visionY;
        private float[] v_Rotation;
        private float[] robotX;
        private float[] robotY;
        private float[] r_Rotation;
        private Mat matrixV2R;
        private Mat matrixR2V;
        private List<Point3d> visionPoints = new List<Point3d>();
        private List<Point3d> robotPoints = new List<Point3d>();
        public MvCalibration calibration = new MvCalibration();
        private Point2d visionTCP;
        private Point3d visionMaster;

        private MvImage inputImage;

        public MvImage InputImage
        {
            get { return inputImage; }
            set { inputImage = value; }
        }
        //public int ToolSelect
        //{
        //    get { return toolSelect; }
        //    set { toolSelect = value; }
        //}

        private E_Tool tool;

        public E_Tool Tool
        {
            get { return tool; }
            set { tool = value; }
        }


        [InputParam]
        public string Receiver
        {
            get { return receiver; }
            set { receiver = value; }
        }
        [InputParam]
        public float[] VisionX
        {
            get { return visionX; }
            set { visionX = value; }
        }
        [InputParam]
        public float[] VisionY
        {
            get { return visionY; }
            set { visionY = value; }
        }
        [InputParam]
        public float[] V_Rotation
        {
            get { return v_Rotation; }
            set { v_Rotation = value; }
        }
        [OutputParam]
        public float[] RobotX
        {
            get { return robotX; }
            set { robotX = value; }
        }
        [OutputParam]
        public float[] RobotY
        {
            get { return robotY; }
            set { robotY = value; }
        }
        [OutputParam]

        public float[] R_Rotation
        {
            get { return r_Rotation; }
            set { r_Rotation = value; }
        }

        //[OutputParam]
        //public Mat Matrix
        //{
        //    get { return matrix; }
        //    set { matrix = value; }
        //}
        //public Point2d VisionTCP
        //{
        //    get { return visionTCP; }
        //    set { visionTCP = value; }
        //}
        //public Point3d VisionMaster
        //{
        //    get { return visionMaster; }
        //    set { visionMaster = value; }
        //}


        public override void InitOutParmas()
        {
            //do nothing this tool
            outParams.Add("Matrix", null);
        }

        public override void InitOutProperty()
        {
            //throw new NotImplementedException();
        }

        //{,HE1,0,170.000,520.000,13.032,}
        string[] split(string data)
        {
            return data.Trim('{', '}').Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        }


        public override void Run(bool isEditMode = false)
        {
            //Point2d SubPoint2 = calibration.find_RotatePoint(new Point3d(637, 401, 0), new Point2d(873, 403),45); OK
            //GetInParams();
            //List<Point3d> l_rot = new List<Point3d>() { new Point3d(637, 401, 0), new Point3d(645, 463, 0), new Point3d(645, 340,0) }; //new Point3d(645, 340, 0), new Point3d(706,235, 0), new Point3d(755,198, 0),new Point3d(812,173, 0)
            //Point2d tcp = calibration.FindRotationCenter(l_rot);
           
            if (inParams["Receiver"]?.GetValue() != null)
            {
                string[] data = split((string)inParams["Receiver"].GetValue());

                RobotX = new float[VisionX.Count()];
                RobotY = new float[VisionY.Count()];
                R_Rotation = new float[V_Rotation.Count()];
                if (data[0] == $"HEB{(int)Tool}")
                {
                    //làm mới các list
                    visionPoints.Clear();
                    robotPoints.Clear();
                    matrixV2R = new Mat();
                    matrixR2V = new Mat();
                    calibration.CalData = new MvCalibrationData();
                }
                else if (data[0] == $"HE{(int)Tool}")
                {
                   
                    //chuyển đổi dữ liệu nhận được từ robot
                    float.TryParse(data[2], out robotX[0]);
                    float.TryParse(data[3], out robotY[0]);
                    float.TryParse(data[4], out r_Rotation[0]);
                    //add dữ liệu vị trí robot và vision
                    visionPoints.Add(new Point3d(visionX[0], visionY[0], v_Rotation[0]));
                    robotPoints.Add(new Point3d(robotX[0], robotY[0], R_Rotation[0]));
                }
                else if (data[0] == $"HEE{(int)Tool}")
                {
                  
                    //chuyển đổi dữ liệu nhận được từ robot
                    float.TryParse(data[2], out robotX[0]);
                    float.TryParse(data[3], out robotY[0]);
                    float.TryParse(data[4], out r_Rotation[0]);

                    //dữ liệu vision Point
                    calibration.CalData.RefPoint = visionPoints.Select(p => new Point2d(p.X, p.Y)).ToArray();
                    //dữ liệu robot Point
                    calibration.CalData.RobotPoint = robotPoints.Select(p => new Point2d(p.X, p.Y)).ToArray();
                   
                    //tách phần dữ liệu rotation của vision trong VisionPoints
                    calibration.CalData.RotPoints = visionPoints.GetRange(calibration.CalData.GPNo, visionPoints.Count() - calibration.CalData.GPNo);
                    //sắp xếp dữ liệu Rotation Point theo T
                    List<Point3d> l_RotSort = calibration.CalData.RotPoints.ToList();
                    l_RotSort.Sort((p1, p2) => p1.Z.CompareTo(p2.Z));
                    calibration.CalData.AngleFrom = (float)l_RotSort[0].Z;
                    calibration.CalData.AngleTo = (float)l_RotSort[l_RotSort.Count - 1].Z;

                    //tìm tâm TCP robot trên tọa độ vision
                    calibration.CalData.VisionHE_TCP = calibration.FindRotationCenter(calibration.CalData.RotPoints);
                    calibration.CalData.RobotHE_TCP = new Point2d(robotX[0], robotY[0]);
                    //tìm khoảng cách Mark HE vision master với TCP vision Master
                    Point2d distance = new Point2d(visionPoints[calibration.CalData.GPNo].X, visionPoints[calibration.CalData.GPNo].Y) - calibration.CalData.VisionHE_TCP;
                    calibration.CalData.Distance = distance;
                    //đưa vị trí  HE vision master về TCP vision Master
                    calibration.CalData.ShiftPoint = new Point2d[calibration.CalData.RefPoint.Length];
                    for (int i = 0; i < calibration.CalData.RefPoint.Length; i++)
                    {
                        calibration.CalData.ShiftPoint[i] = calibration.CalData.RefPoint[i] - distance;
                    }

                    //tách 9 điểm matrixPoint của robot
                    Point2d[] visionPt = calibration.CalData.ShiftPoint.Skip(0).Take(calibration.CalData.GPNo).ToArray();
                    Point2d[] robotPt = robotPoints.GetRange(0, 9).ToArray().Select(p => new Point2d(p.X, p.Y)).ToArray();
                    calibration.CalData.VtoRMat.Mat = calibration.CalcCalibrationMat(visionPt, robotPt);



                    if (calibration.CalData.CalImage == null || calibration.CalData.CalImage.IsNull) {calibration.CalData.CalImage = InputImage.Clone(true); }
                    //if (calibration.CalData.RotImage == null || calibration.CalData.RotImage.IsNull) {calibration.CalData.RotImage = InputImage.Clone(true); }
                    calibration.CalData.RotShiftH = calibration.CalData.RotShiftH = 0;
                    calDataEvent?.Invoke(calibration.CalData);

                }
                else if (data[0] == $"TT{(int)Tool}")
                {
                    //chuyển đổi dữ liệu nhận được từ robot
                    float.TryParse(data[2], out robotX[0]);
                    float.TryParse(data[3], out robotY[0]);
                    float.TryParse(data[4], out r_Rotation[0]);
                    //lấy vị trí từ robot gửi tới (TCP robot)
                    //chuyển đổi dữ liệu từ TCP robot sang vị trí TCP vision(TCProbot x matrixR2V)  //luu vi tri tam xoay TCP Vision

                    calibration.CalData.RobotTT_TCP = new Point2d(RobotX[0], RobotY[0]);
                    calibration.CalData.VisionTT_TCP = calibration.RtoV(new Point2d(RobotX[0], RobotY[0]));
                    //lưu vi tri master
                    calibration.CalData.VisionMaster = new Point3d(VisionX[0], VisionY[0], V_Rotation[0]);
                    Point2d cvtMaster = calibration.VtoR(new Point2d(calibration.CalData.VisionMaster.X, calibration.CalData.VisionMaster.Y));
                    calibration.CalData.RobotMaster = new Point3d(cvtMaster.X, cvtMaster.Y, V_Rotation[0]);
                    //if (calibration.CalData.CalImage == null || calibration.CalData.CalImage.IsNull) { calibration.CalData.CalImage = InputImage.Clone(true); }
                    if (calibration.CalData.RotImage == null || calibration.CalData.RotImage.IsNull) { calibration.CalData.RotImage = InputImage.Clone(true); }
                    calDataEvent?.Invoke(calibration.CalData);

                }
                else if (data[0].Contains("XT"))
                {
                    
                    for (int i = 0; i < VisionX.Count(); i++)
                    {
                        if (double.IsNaN(VisionX[i]) || double.IsNaN(VisionY[i]) || double.IsNaN(V_Rotation[i]))
                        {
                            RobotX[i] = 0; RobotY[i] = 0; R_Rotation[i] = 0;
                            GetOutParams();
                            lastRunSuccess = false;
                            return;
                        }
                        //lấy vi tri mới của object
                        Point3d curPoint = new Point3d(VisionX[i], VisionY[i], V_Rotation[i]);
                        //so sanh với vị trí master ==> Angle + distance

                        Point2d newPoint = calibration.find_RotatePoint(new Point3d(curPoint.X, curPoint.Y, calibration.CalData.VisionMaster.Z - curPoint.Z), calibration.CalData.VisionTT_TCP);
                        Point2d RobotShift = calibration.VtoR(newPoint);
                        Point3d RobotDistance = new Point3d(calibration.CalData.RobotMaster.X - RobotShift.X, calibration.CalData.RobotMaster.Y - RobotShift.Y, calibration.CalData.VisionMaster.Z - curPoint.Z);
                        //gửi Angle+distance =>Robot
                        RobotX[i] = (float)Math.Round(RobotDistance.X, 3);
                        RobotY[i] = (float)Math.Round(RobotDistance.Y, 3);
                        R_Rotation[i] = (float)Math.Round(RobotDistance.Z, 3);

                        //for (int i = 0; i < calibration.CalData.RefPoint.Length; i++)
                        //{
                        //    Console.WriteLine($"{i}_X:{calibration.VtoR(calibration.CalData.RefPoint[i]).X}  Y:{calibration.VtoR(calibration.CalData.RefPoint[i]).Y}");
                        //}
                        //for (int r = 0; r < calibration.CalData.VtoRMat.Mat.Rows; r++)
                        //{
                        //    for (int c = 0; c < calibration.CalData.VtoRMat.Mat.Cols; c++)
                        //    {
                        //        Console.Write(calibration.CalData.VtoRMat.Mat.At<double>(r, c) + "\t");
                        //    }
                        //    Console.Write("\n");
                        //}
                    }
                }
                else if (data[0].Contains("RF"))

                {
                    //calibration.CalData.RotCenter = calibration.VtoR(calibration.CalData.VisionTCP);
                    if (calibration.CalData.CalImage == null || calibration.CalData.CalImage.IsNull) { calibration.CalData.CalImage = InputImage.Clone(true); }
                    if (calibration.CalData.RotImage == null || calibration.CalData.RotImage.IsNull) { calibration.CalData.RotImage = InputImage.Clone(true); }
                    calDataEvent?.Invoke(calibration.CalData);
                }
            }



            //List<string> l_int = new List<string>();
            //if (isEditMode)
            //{
            //    foreach (KeyValuePair<string, object> param in inputTool.outParams)
            //    {
            //        SvImageInfo info = inputTool.imageList.Find((item) => { if (item.ImageName == param.Key) return true; return false; });
            //        if (info != null)
            //        {
            //            if (param.Value is SvImage)
            //            {
            //                info.Image = param.Value as SvImage;
            //            }
            //        }
            //        if (param.Value is System.Int32)
            //        {
            //            l_int.Add(param.Value.ToString() + ",");
            //        }
            //    }
            //}
            //imageList = new List<SvImageInfo>();

            //if (isEditMode)
            //{
            //    foreach (KeyValuePair<string, InputParams> param in outputTool.inParams)
            //    {
            //        if (param.Value == null) continue;
            //        if (param.Value.Instance as SvToolBase == null) continue;
            //        foreach (SvImageInfo imageinfo in (param.Value.Instance as SvToolBase).imageList)
            //        {
            //            imageList.Add(imageinfo);

            //        }
            //    }
            //}
            //outputTool.imageList = imageList;
            GetOutParams();
            lastRunSuccess = true;
        }
        //#region Grid


        //public SvInnerToolBlock inputTool;
        //public SvInnerToolBlock outputTool;

        //public Dictionary<string, object> innerInput
        //{ get { return inputTool.outParams; } }

        //public Dictionary<string, object> innerOutput
        //{ get { return outputTool.outParams; } }
        //[NonSerialized]
        //Dictionary<string, InputParams> tempInParams;
        //[NonSerialized]
        //Dictionary<string, InputParams> tempOutputToolInParams;

        //public List<object[]> GetInputs()
        //{
        //    List<object[]> param = new List<object[]>();
        //    foreach (KeyValuePair<string, Type> pair in inputTool.inputTypeList)
        //    {
        //        object[] obj = new object[2];
        //        obj[0] = pair.Key;
        //        obj[1] = pair.Value.FullName;
        //        param.Add(obj);
        //    }
        //    return param;
        //}

        //public List<object[]> GetOutputs()
        //{
        //    List<object[]> param = new List<object[]>();
        //    foreach (KeyValuePair<string, Type> pair in outputTool.outputTypeList)
        //    {
        //        object[] obj = new object[2];
        //        obj[0] = pair.Key;
        //        obj[1] = pair.Value.FullName;
        //        param.Add(obj);
        //    }
        //    return param;
        //}
        //public void ClearInput()
        //{
        //    tempInParams = new Dictionary<string, InputParams>();
        //    foreach (KeyValuePair<string, InputParams> pair in inParams)
        //    {
        //        if (pair.Value != null)
        //            tempInParams.Add(pair.Key, pair.Value);
        //    }

        //    inputTool.outParams.Clear();
        //    outputTool.outParams.Clear();
        //    inputTool.inputTypeList.Clear();
        //    inParams.Clear();
        //    inputTool.imageList.Clear();
        //}
        //public void ClearOutput()
        //{
        //    tempOutputToolInParams = new Dictionary<string, InputParams>();
        //    foreach (KeyValuePair<string, InputParams> pair in outputTool.inParams)
        //    {
        //        if (pair.Value != null)
        //            tempOutputToolInParams.Add(pair.Key, pair.Value);
        //    }

        //    outputTool.inParams.Clear();
        //    outputTool.outParams.Clear();
        //    outputTool.outputTypeList.Clear();
        //    outParams.Clear();
        //    outputTool.imageList.Clear();
        //    imageList.Clear();
        //}
        //public void AddInput(string key, Type type)
        //{
        //    inputTool.inputTypeList.Add(key, type);

        //    InputParams value = null;
        //    if (tempInParams != null && tempInParams.ContainsKey(key))
        //        value = tempInParams[key];

        //    inParams.Add(key, value);

        //    inputTool.outParams.Add(key, Activator.CreateInstance(type));

        //    if (type.Equals(typeof(SvImage)))
        //        inputTool.imageList.Add(new SvImageInfo(key));

        //}

        //public void AddOutput(string key, Type type)
        //{
        //    outputTool.outputTypeList.Add(key, type);

        //    InputParams value = null;
        //    if (tempOutputToolInParams != null && tempOutputToolInParams.ContainsKey(key))
        //        value = tempOutputToolInParams[key];

        //    outputTool.inParams.Add(key, value);

        //    outParams.Add(key, null);

        //    if (type.Equals(typeof(SvImage)))
        //    {
        //        SvImageInfo outputImageInfo = new SvImageInfo(key);
        //        outputTool.imageList.Add(outputImageInfo);
        //        imageList.Add(outputImageInfo);
        //    }
        //}
        //public override void GetInParams()
        //{
        //    List<string> deletedKey = new List<string>();

        //    inputTool.lastRunSuccess = true;

        //    foreach (KeyValuePair<string, InputParams> param in inParams)
        //    {
        //        Type keyType = inputTool.inputTypeList[param.Key];

        //        object value = null;

        //        if (param.Value != null)
        //        {
        //            Type type = param.Value.GetType();

        //            if (keyType != type)
        //            {
        //                if (type == null)
        //                    System.Windows.Forms.MessageBox.Show("Type is wrong");
        //                else
        //                    System.Windows.Forms.MessageBox.Show(string.Format("Type is not match\r\nsrcType : {0}\r\ndstType : {1}", type.Name, keyType.Name));
        //                deletedKey.Add(param.Key);
        //                continue;
        //            }

        //            value = param.Value.GetValue();
        //        }

        //        if (value == null) inputTool.lastRunSuccess = false;

        //        inputTool.outParams[param.Key] = value;
        //    }

        //    foreach (string key in deletedKey)
        //    {
        //        inParams[key] = null;
        //    }
        //}

        //public override void GetOutParams()
        //{
        //    outputTool.GetInParams();
        //    foreach (KeyValuePair<string, object> item in outputTool.outParams)
        //    {
        //        this.outParams[item.Key] = item.Value;
        //    }
        //}
        //#endregion
    }
}
