﻿using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using static MvCore.MvToolBlock;

namespace MvCore
{
    [Serializable] //khai báo serial lưu dữ liệu
    public class MvConvert : MvToolBase
    {

        public MvConvert()
        {
            inputTool = new SvInnerToolBlock();
            inputTool.toolName = "Input";
            outputTool = new SvInnerToolBlock();
            outputTool.toolName = "Output";
            AddInput("StringIn", typeof(String));
            AddOutput("StringOut", typeof(String));
        }
        public MvConvert(SerializationInfo info, StreamingContext context) : base(info, context) { } //khai báo đọc dữ liệu

        private int m_Type = 0;

        public int M_Type
        {
            get { return m_Type; }
            set { m_Type = value; }
        }


        //private string dataIn;
        //private string dataOut;
        //[InputParam]
        //public string DataIn
        //{
        //    get { return dataIn; }
        //    set { dataIn = value; }
        //}
        //[OutputParam]
        //public string DataOut
        //{
        //    get { return dataOut; }
        //    set { dataOut = value; }
        //}


        public override void InitImageList()
        {
            //throw new NotImplementedException();
        }

        public override void InitInParmas()
        {
            //throw new NotImplementedException();
            //inParams.Add("DataIn", null);
        }


        public override void InitOutParmas()
        {
            //do nothing this tool
            //outParams.Add("DataOut", null);


        }

        public override void InitOutProperty()
        {
            //throw new NotImplementedException();
        }
        //{,HE1,0,170.000,520.000,13.032,}
        string[] split(string data)
        {
            return data.Trim('{', '}').Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        }

        public override void Run(bool isEditMode = false)
        {
            GetInParams();


                //list -> string
                int idx = 0;
                string DataIn = inputTool.outParams["StringIn"]?.ToString() ?? "";
                string[] dataSplit = split(DataIn);
                if (dataSplit.Length > 0)
                {
                   
                    foreach (string key in outputTool.inParams.Keys.ToList())
                    {
                        if (key == "StringOut") continue;
                        if (idx >= dataSplit.Length) break;
                        this.outParams[key] = dataSplit[idx];
                        idx++;

                    }
                }
           
                // string -> List
                string data = null;
                foreach (string key in inputTool.outParams.Keys.ToList())
                {
                    if (key == "StringIn") continue;
                    data += inputTool.outParams[key] +",";
                }
                outputTool.outParams["StringOut"] = data;
          

            List<string> l_int = new List<string>();
            if (isEditMode)
            {
                foreach (KeyValuePair<string, object> param in inputTool.outParams)
                {
                    SvImageInfo info = inputTool.imageList.Find((item) => { if (item.ImageName == param.Key) return true; return false; });
                    if (info != null)
                    {
                        if (param.Value is MvImage)
                        {
                            info.Image = param.Value as MvImage;
                        }
                    }
                    if (param.Value is System.Int32)
                    {
                        l_int.Add(param.Value.ToString() + ",");
                    }
                }
            }
            imageList = new List<SvImageInfo>();

            if (isEditMode)
            {
                foreach (KeyValuePair<string, InputParams> param in outputTool.inParams)
                {
                    if (param.Value == null) continue;
                    if (param.Value.Instance as MvToolBase == null) continue;
                    foreach (SvImageInfo imageinfo in (param.Value.Instance as MvToolBase).imageList)
                    {
                        imageList.Add(imageinfo);

                    }
                }
            }
            outputTool.imageList = imageList;
            GetOutParams();
            lastRunSuccess = true;
        }
        #region Grid


        public SvInnerToolBlock inputTool;
        public SvInnerToolBlock outputTool;

        public Dictionary<string, object> innerInput
        { get { return inputTool.outParams; } }

        public Dictionary<string, object> innerOutput
        { get { return outputTool.outParams; } }
        [NonSerialized]
        Dictionary<string, InputParams> tempInParams;
        [NonSerialized]
        Dictionary<string, InputParams> tempOutputToolInParams;

        public List<object[]> GetInputs()
        {
            List<object[]> param = new List<object[]>();
            foreach (KeyValuePair<string, Type> pair in inputTool.inputTypeList)
            {
                object[] obj = new object[2];
                obj[0] = pair.Key;
                obj[1] = pair.Value.FullName;
                param.Add(obj);
            }
            return param;
        }

        public List<object[]> GetOutputs()
        {
            List<object[]> param = new List<object[]>();
            foreach (KeyValuePair<string, Type> pair in outputTool.outputTypeList)
            {
                object[] obj = new object[2];
                obj[0] = pair.Key;
                obj[1] = pair.Value.FullName;
                param.Add(obj);
            }
            return param;
        }
        public void ClearInput()
        {
            tempInParams = new Dictionary<string, InputParams>();
            foreach (KeyValuePair<string, InputParams> pair in inParams)
            {
                if (pair.Value != null)
                    tempInParams.Add(pair.Key, pair.Value);
            }

            inputTool.outParams.Clear();
            outputTool.outParams.Clear();
            inputTool.inputTypeList.Clear();
            inParams.Clear();
            inputTool.imageList.Clear();
        }
        public void ClearOutput()
        {
            tempOutputToolInParams = new Dictionary<string, InputParams>();
            foreach (KeyValuePair<string, InputParams> pair in outputTool.inParams)
            {
                if (pair.Value != null)
                    tempOutputToolInParams.Add(pair.Key, pair.Value);
            }

            outputTool.inParams.Clear();
            outputTool.outParams.Clear();
            outputTool.outputTypeList.Clear();
            outParams.Clear();
            outputTool.imageList.Clear();
            imageList.Clear();
        }
        public void AddInput(string key, Type type)
        {
            inputTool.inputTypeList.Add(key, type);

            InputParams value = null;
            if (tempInParams != null && tempInParams.ContainsKey(key))
                value = tempInParams[key];

            inParams.Add(key, value);
            if (type == typeof(string))
                inputTool.outParams.Add(key, null);
            else
                inputTool.outParams.Add(key, Activator.CreateInstance(type));

            if (type.Equals(typeof(MvImage)))
                inputTool.imageList.Add(new SvImageInfo(key));

        }

        public void AddOutput(string key, Type type)
        {
            outputTool.outputTypeList.Add(key, type);

            InputParams value = null;
            if (tempOutputToolInParams != null && tempOutputToolInParams.ContainsKey(key))
                value = tempOutputToolInParams[key];

            outputTool.inParams.Add(key, value);

            outParams.Add(key, null);

            if (type.Equals(typeof(MvImage)))
            {
                SvImageInfo outputImageInfo = new SvImageInfo(key);
                outputTool.imageList.Add(outputImageInfo);
                imageList.Add(outputImageInfo);
            }
        }
        public override void GetInParams()
        {
            List<string> deletedKey = new List<string>();

            inputTool.lastRunSuccess = true;

            foreach (KeyValuePair<string, InputParams> param in inParams)
            {
                Type keyType = inputTool.inputTypeList[param.Key];

                object value = null;

                if (param.Value != null)
                {
                    Type type = param.Value.GetType();

                    if (keyType != type)
                    {
                        if (type == null)
                            System.Windows.Forms.MessageBox.Show("Type is wrong");
                        else
                            System.Windows.Forms.MessageBox.Show(string.Format("Type is not match\r\nsrcType : {0}\r\ndstType : {1}", type.Name, keyType.Name));
                        deletedKey.Add(param.Key);
                        continue;
                    }

                    value = param.Value.GetValue();
                }

                if (value == null) inputTool.lastRunSuccess = false;

                inputTool.outParams[param.Key] = value;
            }

            foreach (string key in deletedKey)
            {
                inParams[key] = null;
            }
        }

        public override void GetOutParams()
        {
            outputTool.GetInParams();
            foreach (KeyValuePair<string, object> item in outputTool.outParams)
            {
                this.outParams[item.Key] = item.Value;
            }
        }
        #endregion
    }
}
