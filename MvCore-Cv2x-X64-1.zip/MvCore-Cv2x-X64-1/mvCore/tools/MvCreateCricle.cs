﻿using MvCore.Edit;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
//using MvCore.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Windows.Shapes;

namespace MvCore
{
    [Serializable]
    public class MvCreateCricle : MvToolBase
    {
        public MvCreateCricle()
        {
           if(Circle == null)
            {
                Circle = new MvCircle();
            }
        }
        public MvCreateCricle(SerializationInfo info, StreamingContext context) : base(info, context)
        {
           
        }



        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }
        public override void InitOutParmas()
        {
            outParams.Add("CircleOut", null);
        }
        public override void InitOutProperty()
        {

        }

        [NonSerialized]
        MvImage inputImage;

        [InputParam]
        public MvImage InputImage
        {
            get { return inputImage; }
            set
            {
                if (value == null) return;
                inputImage = value;
            }
        }
       



     
        private MvCircle circle;
        
        public MvCircle Circle
        {
            get { return circle; }
            set { circle = value; }
        }

        private MvCircle circleOut;
        [OutputParam]
        public MvCircle CircleOut
        {
            get { return circleOut; }
            set { circleOut = value; }
        }


        [NonSerialized]
        private double cx;

        public double CX
        {
            get 
            {
                cx = Circle.Center.X;
                return cx; 
            }
            set 
            {
                cx = value;
                Circle.Center = new Point2d(value,Circle.Center.Y);
            }
        }
        [NonSerialized]
        private double cy;

        public double CY
        {
            get 
            {
                cy = Circle.Center.Y;
                return cy; 
            }
            set 
            { 
                cy = value;
                Circle.Center = new Point2d(Circle.Center.X, value);
            }
        }




        public void DrawCricle(MvCore.Display.MvDisplayView display)
        {
          
            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Cyan, 1);
            //if (Line1 != null)
            //    display.DrawLine(p, Line1.SP, Line1.EP);
            //if (Line2 != null)
            //    display.DrawLine(p, Line2.SP, Line2.EP);
            if (Circle != null)
            {
                System.Drawing.Pen px = new System.Drawing.Pen(System.Drawing.Color.Red,9);
                System.Drawing.Font f = new System.Drawing.Font("굴림체", 10, System.Drawing.FontStyle.Bold);
                display.DrawEllipseRef(px, Circle.Center,Circle.R , Circle.R);
                display.DrawString($"X: {Circle.Center.X:F4}, Y: {Circle.Center.Y:F4}", f,p.Brush,new PointF((float)Circle.Center.X,(float)Circle.Center.Y));
            } 
        }
       
        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            imageList.Clear();
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));
            outputImageInfo.drawingFunc = DrawCricle;
            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }
       

      




        public override void Run(bool isEditMode = false)
        {
          
            inputImageInfo.Image = InputImage;

        
            if (inputImage != null)
                outputImageInfo.Image = InputImage;
           
          
            if (Circle == null || Circle.Center == null || double.IsNaN(Circle.Center.X) || double.IsNaN(Circle.Center.Y))
            {
                lastRunSuccess = false; return;
            }
            CircleOut = Circle;
            lastRunSuccess = true;
        }
    }
}
