﻿using MvCore.Edit;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
//using MvCore.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Windows.Shapes;

namespace MvCore
{
    [Serializable]
    public class MvCreateLine : MvToolBase
    {
        public MvCreateLine()
        {
           if(Line == null)
            {
                Line = new MvLine();
            }
           if(ThreePoint == null)
            {
                ThreePoint = new MvPoint(0,0);
            }
        }
        public MvCreateLine(SerializationInfo info, StreamingContext context) : base(info, context)
        {
           
        }

      


        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }
        public override void InitOutParmas()
        {
            outParams.Add("LineOut", null);
        }
        public override void InitOutProperty()
        {

        }

        [NonSerialized]
        MvImage inputImage;

        [InputParam]
        public MvImage InputImage
        {
            get { return inputImage; }
            set
            {
                if (value == null) return;
                inputImage = value;
            }
        }




       
        private MvLine line;
        
        public MvLine Line
        {
            get { return line; }
            set { line = value; }
        }


        private MvLine line2;

        public MvLine Line2
        {
            get { return line2; }
            set { line2 = value; }
        }

        private MvPoint threePoint;

        public MvPoint ThreePoint
        {
            get { return threePoint; }
            set { threePoint = value; }
        }


        private MvLine lineOut;
        [OutputParam]
        public MvLine LineOut
        {
            get { return lineOut; }
            set { lineOut = value; }
        }

        private MvLine lineOut2;
        [OutputParam]
        public MvLine LineOut2
        {
            get { return lineOut2; }
            set { lineOut2 = value; }
        }

        public enum E_mode
        {
            Point = 0,Angle = 1 ,BiscectPoints =2,Parallel=3,Perpendicular=4
        }

        private E_mode mode;

        public E_mode Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        private float angle;

        public float Angle
        {
            get { return angle; }
            set { angle = value; }
        }

        private MvLine CreatePerpendicularLine(MvLine line, double length)
        {
            // 1. Điểm đầu cuối
            Point2d p1 = line.SP;
            Point2d p2 = line.EP;

            // 2. Trung điểm
            double mx = (p1.X + p2.X) / 2.0;
            double my = (p1.Y + p2.Y) / 2.0;

            // 3. Vector hướng
            double dx = p2.X - p1.X;
            double dy = p2.Y - p1.Y;

            // 4. Độ dài vector
            double len = Math.Sqrt(dx * dx + dy * dy);
            if (len == 0) return null;

            // 5. Vector pháp tuyến (vuông góc)
            double nx = -dy / len;
            double ny = dx / len;

            double half = length / 2.0;

            // 6. Tạo line vuông góc
            Point2d sp = new Point2d(
                mx - half * nx,
                my - half * ny
            );

            Point2d ep = new Point2d(
                mx + half * nx,
                my + half * ny
            );

            return new MvLine
            {
                SP = sp,
                EP = ep
            };
        }

        private Point2d CreateEndPoint(Point2d StartPoint,double angle,double length)
        {
            double rad = angle * Math.PI / 180.0;
            return new Point2d(StartPoint.X + length * Math.Cos(rad), StartPoint.Y + length * Math.Sin(rad));
        }

        public static MvLine CreateParallelLineThroughPoint(MvLine line,Point2d p)
        {
            Point2d sp = line.SP;
            Point2d ep = line.EP;

            double dx = ep.X - sp.X;
            double dy = ep.Y - sp.Y;

            double len = Math.Sqrt(dx * dx + dy * dy);
            if (len == 0) return null;

            // Pháp tuyến chuẩn hóa
            double nx = -dy / len;
            double ny = dx / len;

            // Khoảng cách từ điểm tới line
            double d = (p.X - sp.X) * nx + (p.Y - sp.Y) * ny;

            // Dịch line
            Point2d sp2 = new Point2d(
                sp.X + d * nx,
                sp.Y + d * ny
            );

            Point2d ep2 = new Point2d(
                ep.X + d * nx,
                ep.Y + d * ny
            );

            return new MvLine
            {
                SP = sp2,
                EP = ep2
            };
        }

        public static MvLine CreatePerpendicularLineThroughPoint(MvLine baseLine,Point2d p,double length)
        {
            Point2d sp = baseLine.SP;
            Point2d ep = baseLine.EP;

            double dx = ep.X - sp.X;
            double dy = ep.Y - sp.Y;

            double len = Math.Sqrt(dx * dx + dy * dy);
            if (len == 0) return null;

            // Vector pháp tuyến (vuông góc)
            double nx = -dy / len;
            double ny = dx / len;

            double half = length / 2.0;

            Point2d sp2 = new Point2d(
                p.X - half * nx,
                p.Y - half * ny
            );

            Point2d ep2 = new Point2d(
                p.X + half * nx,
                p.Y + half * ny
            );

            return new MvLine
            {
                SP = sp2,
                EP = ep2
            };
        }

        public void DrawLine(MvCore.Display.MvDisplayView display)
        {
            System.Drawing.Pen px = new System.Drawing.Pen(System.Drawing.Color.Red, 9);
            System.Drawing.Font f = new System.Drawing.Font("굴림체", 10, System.Drawing.FontStyle.Bold);
            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Cyan, 1);
            if (Mode == E_mode.Point)
            {
                if (Line != null)
                {
                    display.DrawLine(px, Line.SP, Line.EP);
                }
            }else if(Mode == E_mode.Angle)
            {
                Point2d endPoint = CreateEndPoint(Line.SP,Angle, Line.GetLineLength());
                if (Line != null)
                {
                    display.DrawLine(px, Line.SP, endPoint);
                }
            }else if(Mode == E_mode.BiscectPoints)
            {
                MvLine line2 = CreatePerpendicularLine(Line, Line.GetLineLength());
                if(line2 != null && Line != null)
                {
                    display.DrawLine(px, Line.SP, Line.EP);
                    display.DrawLine(px, line2.SP, line2.EP);
                    lineOut2 = line2;
                }
            }
            else if(Mode == E_mode.Parallel)
            {
                MvLine line2 = CreateParallelLineThroughPoint(Line,ThreePoint.Point2d);
                if (line2 != null && Line != null)
                {
                    display.DrawLine(px, Line.SP, Line.EP);
                    display.DrawLine(px, line2.SP, line2.EP);
                    lineOut2 = line2;
                }
            }else if(Mode == E_mode.Perpendicular)
            {
                MvLine line2 = CreatePerpendicularLineThroughPoint(Line, ThreePoint.Point2d, Line.GetLineLength());
                if (line2 != null && Line != null)
                {
                    display.DrawLine(px, Line.SP, Line.EP);
                    display.DrawLine(px, line2.SP, line2.EP);
                    lineOut2 = line2;
                }
            }
        }
       
        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            imageList.Clear();
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));
            outputImageInfo.drawingFunc = DrawLine;
            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }
       

      




        public override void Run(bool isEditMode = false)
        {
          
            inputImageInfo.Image = InputImage;

        
            if (inputImage != null)
                outputImageInfo.Image = InputImage;
           
          
            if (Line == null || Line.SP == null || Line.EP == null || double.IsNaN(Line.SP.X) || double.IsNaN(Line.EP.Y))
            {
                lastRunSuccess = false; return;
            }
            LineOut = Line;
            lastRunSuccess = true;
        }
    }
}
