﻿using MvCore.Edit;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
//using MvCore.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Windows.Shapes;

namespace MvCore
{
    [Serializable]
    public class MvCreatePoint : MvToolBase
    {
        public MvCreatePoint()
        {
           if(PointA == null)
            {
                PointA = new MvPoint(0,0);
            }
        }
        public MvCreatePoint(SerializationInfo info, StreamingContext context) : base(info, context)
        {
           
        }

      


        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }
        public override void InitOutParmas()
        {
            outParams.Add("LineOut", null);
        }
        public override void InitOutProperty()
        {

        }

        [NonSerialized]
        MvImage inputImage;

        [InputParam]
        public MvImage InputImage
        {
            get { return inputImage; }
            set
            {
                if (value == null) return;
                inputImage = value;
            }
        }
        private MvPoint pointOut;

        public MvPoint PointOut
        {
            get { return pointOut; }
            set { pointOut = value; }
        }


        private MvPoint pointA;

        public MvPoint PointA
        {
            get { return pointA; }
            set { pointA = value; }
        }


        public void DrawLine(MvCore.Display.MvDisplayView display)
        {
            System.Drawing.Pen px = new System.Drawing.Pen(System.Drawing.Color.Red, 9);
            System.Drawing.Font f = new System.Drawing.Font("굴림체", 10, System.Drawing.FontStyle.Bold);
            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Cyan, 1);
            if (PointA != null)
                display.DrawCross(p, PointA.Point2d, 10, 10, 0);
        }
       
        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            imageList.Clear();
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));
            outputImageInfo.drawingFunc = DrawLine;
            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }
       

      




        public override void Run(bool isEditMode = false)
        {
          
            inputImageInfo.Image = InputImage;

        
            if (inputImage != null)
                outputImageInfo.Image = InputImage;
           
          
            if (PointA == null)
            {
                lastRunSuccess = false; return;
            }
            PointOut = PointA;
            lastRunSuccess = true;
        }
    }
}
