﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MvCore.Tools
{
    [Serializable]
    public class MvEmptyTool : MvToolBase
    {
        public override void InitImageList()
        {
            
        }

        public override void InitInParmas()
        {
           
        }

        public override void InitOutParmas()
        {
            
        }

        public override void InitOutProperty()
        {
           
        }

        public override void Run(bool isEditMode = false)
        {
           
        }
    }
}
