﻿using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace MvCore
{
    [Serializable]
    public class MvEqualizer : MvToolBase
    {
        public MvEqualizer() { }

        protected MvEqualizer(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {

        }

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }

        [InputParam]
        public MvImage InputImage { get; set; }

        public override void InitOutParmas()
        {
            outParams.Add("OutputImage", null);
        }

        [OutputParam]
        public MvImage OutputImage { get; set; }

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));

            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            
            if (OutputImage != null) OutputImage.Dispose();
            OutputImage = null;

            GetOutParams(); 
        }

        public override void Run(bool isEditMode = false)
        {
            inputImageInfo.Image = InputImage;

            if (InputImage == null) return;

            if (OutputImage != null) OutputImage.Dispose();
            OutputImage = InputImage.Clone(true);

            Rect regionRect = InputImage.RegionRect.Rect;
            regionRect.Location =(Point)MvFunc.FixtureToImage2D((Point2d)(regionRect.Location), InputImage.TransformMat);

            Mat inMat = InputImage.Mat[regionRect];
            Mat outMat = OutputImage.Mat[regionRect];

            Cv2.EqualizeHist(inMat, outMat);
            
            outputImageInfo.Image = OutputImage;
            
            lastRunSuccess = true;
        }
    }
}
