﻿using MvCore.Edit;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
//using MvCore.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Shapes;
using static MvCore.MvCircleCaliper;

namespace MvCore
{
    [Serializable]
    public class MvFindCircle : MvToolBase
    {
        public MvFindCircle()
        {
            score = 0;
            circleCaliper = new MvCircleCaliper();
            circleCaliper.NumberOfCaliperChanged += circleCaliper_NumberOfCaliperChanged;

            resultList = new List<FindCircleResult>();
            for (int i = 0; i < circleCaliper.NumberOfCaliper; i++)
                resultList.Add(new FindCircleResult(i));

            fittingType = DistanceType.L12;
        }

        void circleCaliper_NumberOfCaliperChanged(object sender, EventArgs e)
        {
            List<bool> uselist = null;

            if (resultList == null)
                resultList = new List<FindCircleResult>();
            else
            {
                uselist = new List<bool>();
                for (int i = 0; i < resultList.Count; i++)
                {
                    uselist.Add(resultList[i].Use);
                }
            }

            resultList.Clear();
            for (int i = 0; i < circleCaliper.NumberOfCaliper; i++)
            {
                resultList.Add(new FindCircleResult(i));
                if (uselist != null && i < uselist.Count)
                    resultList[i].Use = uselist[i];
            }
            Cal_IgnoreNumber();    
        }

        public MvFindCircle(SerializationInfo info, StreamingContext context) : base(info, context) 
        {
            circleCaliper.NumberOfCaliperChanged += circleCaliper_NumberOfCaliperChanged;
        }

        // Number Of Ignore 계산 (Number of Caliper, Percentage of Ignore, Masking 변경시 동작)
        public void Cal_IgnoreNumber()
        {
            int useCount = 0;
            foreach (FindCircleResult result in resultList)
            {
                if (result.Use == true)
                    useCount++;
            }

            UseNumberOfCalipers = useCount;

            if (IgnoreType == "Number")
            {
                if (NumberOfIgnore < useCount)
                {
                    PercentageOfIgnore = (int)Math.Round((double)((NumberOfIgnore * 100) / useCount));
                }
                else if (useCount == 0)
                {
                    
                }
                else
                {
                    NumberOfIgnore = useCount;
                    PercentageOfIgnore = 100;
                }
                NotifyPropertyChanged("PercentageOfIgnore");
            }
            else
            {
                NumberOfIgnore = (int)Math.Round((double)((useCount * PercentageOfIgnore) / 100));
                NotifyPropertyChanged("NumberOfIgnore");
            }            
        }

        public void Cal_UseCount()
        {
            int useCount = 0;
            foreach (FindCircleResult result in resultList)
            {
                if (result.Use == true)
                    useCount++;
            }

            UseNumberOfCalipers = useCount;
            NotifyPropertyChanged("UseCount");
        }

        #region InParams

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }

        public enum eIgnoreType { Number, Percentage }
        public string IgnoreType
        {
            get { return IgnoreTypeList[mIgnoreType]; }
            set { mIgnoreType = IgnoreTypeList.First(x => x.Value == value).Key; NotifyPropertyChanged("IgnoreType"); }
        }
        eIgnoreType mIgnoreType;

        public static Dictionary<eIgnoreType, string> IgnoreTypeList
        {
            get
            {
                Dictionary<eIgnoreType, string> ignoreType = new Dictionary<eIgnoreType, string>();
                ignoreType.Add(eIgnoreType.Number, "Number");
                ignoreType.Add(eIgnoreType.Percentage, "Percentage");
                return ignoreType;
            }
        }        


        [InputParam]
        public MvImage InputImage 
        {
            get { return inputImage; }
            set {
                if (value == null) return;
                inputImage = value;
                circleCaliper.TransformMat = value.TransformMat;
            } 
        }
        [NonSerialized]
        MvImage inputImage;

        //캘리퍼 관련        
        MvCircleCaliper circleCaliper;

        public MvCircleCaliper CircleCaliper
        {
            get { return circleCaliper; }
            set { circleCaliper = value; }
        }

        
        DistanceType fittingType;

        public DistanceType FittingType
        {
            get { return fittingType; }
            set { fittingType = value; }
        }

        //TypeOfIgnore ignoreType;

        //public TypeOfIgnore IgnoreType
        //{
        //    get { return ignoreType; }
        //    set { ignoreType = value; }
        //}

        int percentageOfIgnore;

        public int PercentageOfIgnore
        {
            get { return percentageOfIgnore; }
            set { percentageOfIgnore = value; }
        }

        int numberOfIgnore;

        public int NumberOfIgnore
        {
            get { return numberOfIgnore; }
            set { numberOfIgnore = value; }
        }

        int useNumberOfCalipers;

        public int UseNumberOfCalipers
        {
            get { return useNumberOfCalipers; }
            set { useNumberOfCalipers = value; }
        }

        #endregion

        #region OutParams

        public override void InitOutParmas()
        {
            outParams.Add("Circle", null);
            //outParams.Add("Distance", null);
        }
                
        [OutputParam]
        public MvCircle Circle
        {
            get
            {
                if (circle == null) return null;
              
                MvCircle outline = new MvCircle();
                outline.R = circle.R;
                outline.Center = circle.Center;
                //outline.Center = MvFunc.ImageToFixture2D(MvFunc.FixtureToImage2D(circle.Center, circle.TransformMat), InputImage.TransformMat);
                //outline.EP = MvFunc.ImageToFixture2D(MvFunc.FixtureToImage2D(circle.EP, circle.TransformMat), InputImage.TransformMat);
                outline.TransformMat = InputImage.TransformMat;
                return circle = outline;
                //return outline;
            }
            set
            {
                circle = value;
            }
        }

       
        private Point2d center;
        [OutputParam]
        public Point2d Center
        {
            get { return center; }
            set { center = value; }
        }

        //private float radius;
        //[OutputParam]
        //public float Radius
        //{
        //    get { return radius; }
        //    set { radius = value; }
        //}





        [NonSerialized]
        MvCircle circle;
        
        double score = 0.0;

        public double Score
        {
            get { return Math.Round(score, 3); }
            set { }
        }

        private double setScore;

        public double SetScore
        {
            get { return setScore; }
            set { setScore = value; }
        }

        private int setCount;

        public int SetCount
        {
            get { return setCount; }
            set { setCount = value; }
        }



        [OutputParam]
        public double Ave_Dist
        {
            get { return Score; }
            set { }
        }

        [Serializable]
        public class FindCircleResult
        {
            public FindCircleResult(int no)
            {
                this.No = no;
                Use = true;
                Used = "false";
                X = "0.000";
                Y = "0.000";
                Distance = "0.000";
                Threshold = "0.000";
            }

            public FindCircleResult(bool isUse, int no, string isUsed, string x, string y, string distance, string threshold)
            {
                this.Use = isUse;
                this.No = no;
                this.Used = isUsed;
                this.X = x;
                this.Y = y;
                this.Distance = distance;
                this.Threshold = threshold;
            }

            public bool Use { get; set; }
            public int No { get; set; }
            public string Used { get; set; }
            public string X { get; set; }
            public string Y { get; set; }
            public string Distance { get; set; }
            public string Threshold { get; set; }
        }

        List<FindCircleResult> resultList;

        public List<FindCircleResult> ResultList
        {
            get
            {
                if (resultList == null)
                {
                    resultList = new List<FindCircleResult>();
                    for (int i = 0; i < circleCaliper.NumberOfCaliper; i++)
                        resultList.Add(new FindCircleResult(i));
                }
                return resultList;
            }
            set { throw new Exception("Can't set"); }        
        }
        

        #endregion

        [Serializable]
        class CalBestCircle
        {
            public List<Point3f> caliperPoints;

            public CalBestCircle(List<Point3f> caliperPoints)
            {
                this.caliperPoints = caliperPoints;
            }

            double score = double.MaxValue;
            public CvLine2D bestLine;
            public List<int> bestExceptPoint = new List<int>();

            static int cnt = 0;
            List<int> result = new List<int>();

            int GetnCr(int n, int r)
            {
                if (r == 0)
                    return 1;

                long combination = 1;
                int cnt = 1;

                if (n - r < r)
                    r = n - r;

                for (int i = n; i > n - r; i--)
                {
                    combination *= i;
                    combination /= cnt++;
                }

                return (int)combination;
            }

            DistanceType fittingType;
            public double Calculate(int numberOfIgnore, DistanceType fittingType)
            {
                this.fittingType = fittingType;

                Gready(numberOfIgnore);

                if (score == double.MaxValue)
                    score = 0;

                return score;
            }
            public (PointF center, float radius) FitCircle(List<Point3f> points)
            {
                if (points.Count < 3)
                    throw new ArgumentException("Need at least 3 points");

                float sumX = 0, sumY = 0;
                float sumX2 = 0, sumY2 = 0;
                float sumXY = 0;
                float sumX3 = 0, sumY3 = 0;
                float sumX1Y2 = 0, sumX2Y1 = 0;

                int n = points.Count;

                foreach (var p in points)
                {
                    float x = p.X;
                    float y = p.Y;
                    float x2 = x * x;
                    float y2 = y * y;

                    sumX += x;
                    sumY += y;
                    sumX2 += x2;
                    sumY2 += y2;
                    sumXY += x * y;
                    sumX3 += x2 * x;
                    sumY3 += y2 * y;
                    sumX1Y2 += x * y2;
                    sumX2Y1 += x2 * y;
                }

                float C = n * sumX2 - sumX * sumX;
                float D = n * sumXY - sumX * sumY;
                float E = n * sumX3 + n * sumX1Y2 - (sumX2 + sumY2) * sumX;
                float G = n * sumY2 - sumY * sumY;
                float H = n * sumX2Y1 + n * sumY3 - (sumX2 + sumY2) * sumY;

                float a = (H * D - E * G) / (C * G - D * D);
                float b = (H * C - E * D) / (D * D - G * C);

                float cX = -a / 2;
                float cY = -b / 2;

                float r = 0;
                foreach (var p in points)
                    r += Distance(p, new Point3f(cX, cY,0));

                r /= n;

                return (new PointF(cX, cY), r);
            }

           



            public float Distance(Point3f p1, Point3f p2)
            {
                float dx = p1.X - p2.X;
                float dy = p1.Y - p2.Y;
                return (float)Math.Sqrt(dx * dx + dy * dy);
            }

            void Gready(int numberOfIgnore)
            {
                if (numberOfIgnore == 0)
                {
                    score = GetCricle(result, out bestLine);
                    bestExceptPoint = result;
                    return;
                }

                for (int cnt = 0; cnt < numberOfIgnore; cnt++)
                {
                    score = double.MaxValue;
                    for (int i = 0; i < caliperPoints.Count; i++)
                    {
                        if (caliperPoints[i].X == -1 && caliperPoints[i].Y == -1)
                            continue;

                        result.Add(i);
                        CvLine2D fitLine;
                        double localScore = GetCricle(result, out fitLine);
                        if (localScore < score)
                        {
                            bool isUsed = false;
                            foreach (int exceptPoint in bestExceptPoint)
                            {
                                if (exceptPoint == i)
                                {
                                    isUsed = true;
                                    break;
                                }
                            }

                            if (!isUsed)
                            {
                                bestLine = fitLine;
                                score = localScore;

                                bestExceptPoint.Clear();
                                foreach (int resultIndex in result)
                                {
                                    bestExceptPoint.Add(resultIndex);
                                }
                            }
                        }
                        result.RemoveAt(result.Count - 1);
                    }
                    if (cnt < bestExceptPoint.Count)
                        result.Add(bestExceptPoint[cnt]);
                }
            }

            [Obsolete]
            void combination(int i, int n, int r)
            {
                if (r == 0)
                {
                    CvLine2D fitLine;
                    double localScore = GetCricle(result, out fitLine);
                    if (localScore < score)
                    {
                        bestLine = fitLine;
                        score = localScore;

                        bestExceptPoint.Clear();
                        foreach (int resultIndex in result)
                            bestExceptPoint.Add(resultIndex);
                    }
                    return;
                }

                for (int k = i; k < n; k++)
                {
                    result.Add(k);
                    combination(k + 1, n, r - 1);
                    result.RemoveRange(result.Count - 1, 1);
                }
            }

            List<Point2f> goodPoints;
            double GetCricle(List<int> exceptPoint, out CvLine2D fitLine)
            {
                goodPoints = new List<Point2f>();
                int count = -1;
                foreach (Point3f pt in caliperPoints)
                {
                    count++;
                    if (pt.X != -1 || pt.Y != -1)
                    {
                        bool isContinue = false;
                        for (int i = 0; i < exceptPoint.Count; i++)
                        {
                            if (count == exceptPoint[i])
                            {
                                isContinue = true;
                                break;
                            }
                        }
                        if (isContinue)
                            continue;

                        goodPoints.Add(new Point2f(pt.X, pt.Y));
                    }
                }

                fitLine = null;//new CvLine2D(new float[] {});
                if (goodPoints.Count < 2) return -1.0;

                fitLine = Cv2.FitLine(goodPoints.ToArray(), fittingType, 0, 0.01, 0.01);

                double sum = 0;
                foreach (Point2f point in goodPoints)
                {
                    sum += fitLine.Distance(point.X, point.Y);
                }

                if (goodPoints.Count == 0)
                    return 0;
                else
                    return sum / goodPoints.Count;

            }

        }

        [NonSerialized]
        CalBestCircle calBesCircle;

        void MakeResultList(CalBestCircle calBestCricle)
        {
            if (calBestCricle.caliperPoints.Count != circleCaliper.NumberOfCaliper) return;
            for (int i = 0; i < circleCaliper.NumberOfCaliper; i++)
            {
                Point2d pt = new Point2d(calBestCricle.caliperPoints[i].X, calBestCricle.caliperPoints[i].Y);

                if (calBestCricle.caliperPoints[i].X != -1 || calBestCricle.caliperPoints[i].Y != -1)
                {
                    bool isTrue = true;
                    if (calBestCricle.bestExceptPoint != null)
                    {
                        for (int j = 0; j < calBestCricle.bestExceptPoint.Count; j++)
                        {
                            if (i == calBestCricle.bestExceptPoint[j])
                            {
                                isTrue = false;
                                break;
                            }
                        }
                    }

                    if (isTrue == false)
                    {
                        resultList[i].Used = "false";
                        resultList[i].Distance = "-";
                    }
                    else
                    {
                        resultList[i].Used = "true";

                        if (calBestCricle == null || calBestCricle.bestLine == null)
                            resultList[i].Distance = "-";
                        else
                            resultList[i].Distance = calBestCricle.bestLine.Distance(calBestCricle.caliperPoints[i].X, calBestCricle.caliperPoints[i].Y).ToString("F3");
                    }

                    pt = MvFunc.ImageToFixture2D(pt, InputImage.TransformMat);
                }
                else
                {
                    resultList[i].Used = "false";
                    resultList[i].Distance = "-";
                }

                resultList[i].X = pt.X.ToString("F3");
                resultList[i].Y = pt.Y.ToString("F3");

                resultList[i].Threshold = calBestCricle.caliperPoints[i].Z.ToString("F3");
            }
        }

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));

            outputImageInfo.drawingFunc = DrawCricle;

            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }

        public void DrawCricle(MvCore.Display.MvDisplayView display)
        {
            if (calBesCircle == null) return;
            if (InputImage == null) return;

            double angle = 0;
            if (Circle != null)
                angle = Circle.ThetaAngle;
            else
                return;

            float circleTickness = 1f;

            //display.Transform2D = SvFunc.EMat;

            System.Drawing.Pen CyanPen = new System.Drawing.Pen(System.Drawing.Color.Cyan, circleTickness);
            System.Drawing.Pen RedPen = new System.Drawing.Pen(System.Drawing.Color.Red, circleTickness);
            System.Drawing.Pen GreenPen = new System.Drawing.Pen(System.Drawing.Color.LimeGreen, circleTickness);
            System.Drawing.Pen p;
            for (int i = 0; i < calBesCircle.caliperPoints.Count; i++)
            {
                if (calBesCircle.caliperPoints[i].X != -1 || calBesCircle.caliperPoints[i].Y != -1)
                {
                    p = GreenPen;

                    for (int j = 0; j < calBesCircle.bestExceptPoint.Count; j++)
                    {
                        if (i == calBesCircle.bestExceptPoint[j])
                        {
                            p = RedPen;
                            break;
                        }
                    }

                    // 2016.06.15 TEXT & Display Ratio Add _ HOZZANG
                    //Point2d centerPt = SvFunc.ImageToFixture2D(new Point2d(calBestLine.caliperPoints[i].X, calBestLine.caliperPoints[i].Y), InputImage.TransformMat);
                    Point2d centerPt = new Point2d(calBesCircle.caliperPoints[i].X, calBesCircle.caliperPoints[i].Y);
                    float circleSize = 1 / display.ZoomRatio;
                    //display.DrawEllipse(p, centerPt, circleSize, circleSize);   // Find Circle Center Point
                   

                    circleSize = 3 / display.ZoomRatio;
                    display.DrawCross(p, centerPt, circleSize, circleSize, calBesCircle.caliperPoints[i].Z);
                    //display.DrawEllipse(p, centerPt, circleSize, circleSize);   // Find Circle Center Point

                    //float[,] ff = SvFunc.DisplayMatF(inputImage.TransformMat);
                    //float[,] ffline = SvFunc.DisplayMatF(Circle.TransformMat);
                    Point2d stringPt = new Point2d(centerPt.X, centerPt.Y - 60);
                    //stringPt = MvFunc.ImageToFixture2D(MvFunc.RotateAtCenter(stringPt, centerPt, Math.Abs(angle) * Math.PI / 180), inputImage.TransformMat);

                    float fontSize = 7;
                    System.Drawing.Font f = new System.Drawing.Font("굴림체", fontSize, System.Drawing.FontStyle.Bold);
                    display.DrawString(i.ToString(), f, p.Brush, stringPt);         // Caliper NO.
                }
            }
            if(Circle != null&& score <= setScore && resultList.Count >= SetCount)
            {
                Point2d PointTranform = MvFunc.FixtureToImage2D(Circle.Center, inputImage.TransformMat); //chuyển đổi tọa độ ảnh từ FixTool sang tọa độ gốc
                display.DrawEllipse(new Pen(System.Drawing.Color.Aqua), PointTranform, Circle.R, Circle.R);   // Find Circle Center Point
                display.DrawEllipse(new Pen(System.Drawing.Color.Aqua), PointTranform,  0.5f/ display.ZoomRatio, 0.5f / display.ZoomRatio);   // Find Circle Center Point
            }

            if (calBesCircle.bestLine != null)
            {
                p = CyanPen;
                
                //Point2d sp = SvFunc.ImageToFixture2D(Circle.SP, InputImage.TransformMat);
                //Point2d ep = SvFunc.ImageToFixture2D(Circle.EP, InputImage.TransformMat);
                //display.DrawLine(p, Circle.SP, Circle.EP);
            }
        }

        MvCircle GetTransformCaliperLine(MvCircle circle)
        {
            MvCircle caliperLine = new MvCircle();
            //caliperLine.SP = MvFunc.FixtureToImage2D(circle.SP, InputImage.TransformMat);
            //caliperLine.EP = MvFunc.FixtureToImage2D(circle.EP, InputImage.TransformMat);
            return caliperLine;
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            Circle = null;
            GetOutParams(); 
        }

        public void Swap()
        {
            if(CircleCaliper.Direction == EDirection.Inner)
            {
                CircleCaliper.Direction = EDirection.Outer;
            }else
            {
                CircleCaliper.Direction = EDirection.Inner;
            }
        }

        public override void Run(bool isEditMode = false)
        {
            inputImageInfo.Image = InputImage;
            outputImageInfo.Image = InputImage;

            if (InputImage == null) return;

            if (float.IsInfinity(circleCaliper.SP.X) || float.IsInfinity(circleCaliper.SP.Y) || float.IsNaN(circleCaliper.SP.X) || float.IsNaN(circleCaliper.SP.Y)) return;
            if (float.IsInfinity(circleCaliper.EP.X) || float.IsInfinity(circleCaliper.EP.Y) || float.IsNaN(circleCaliper.EP.X) || float.IsNaN(circleCaliper.EP.Y)) return;

            if (isEditMode) NotifyPropertyChanged();

            if (resultList == null)
            {
                resultList = new List<FindCircleResult>();
                for (int i = 0; i < circleCaliper.NumberOfCaliper; i++)
                    resultList.Add(new FindCircleResult(i));
            }

            MvCircle oldCircle = circleCaliper.Circle;
            //circleCaliper.CaliperCircle = GetTransformCaliperLine(circleCaliper.CaliperCircle);

            DateTime startTime = DateTime.Now;
            List<Point3f> points = circleCaliper.CalCaliperPoints(InputImage.Mat);
            circleCaliper.Circle = oldCircle;
            double 계산시간 = DateTime.Now.Subtract(startTime).TotalMilliseconds;

            startTime = DateTime.Now;
            int countUsed = 0;
            foreach (FindCircleResult result in resultList)
            {
                if (!result.Use && points.Count > result.No)
                    points[result.No] = new Point3f(-1, -1, 0);
                if(result.Used.Contains("true"))
                    countUsed++;
            }

            calBesCircle = new CalBestCircle(points);
            
            if (points.Count < 3) 
            {
                lastRunSuccess = false;
                return;
            }
            var (center, radius) = calBesCircle.FitCircle(points);
            RotatedRect elipse = new RotatedRect(new Point2f(center.X, center.Y), new Size2f(radius, radius), 0); // find Circle
            //RotatedRect elipse = Cv2.FitEllipse(points.Select(p => new Point2f(p.X,p.Y)).ToArray());  //find Ellipse
            score = calBesCircle.Calculate(numberOfIgnore, fittingType);
            if(score > setScore || countUsed < SetCount)
            {
                MvCircle resCircle = new MvCircle();
                resCircle.CenterX = float.NaN;
                resCircle.CenterY = float.NaN;
                resCircle.R = float.NaN;
                resCircle.TransformMat = Mat.Eye(3, 3, MatType.CV_32FC1);
                Circle = resCircle;
                Center = Circle.Center;
                //Radius = Circle.Radius;
                lastRunSuccess = false;
                return;
            }
            //CvLine2D bestLine = calBesCircle.bestLine;

            double 핏라인 = DateTime.Now.Subtract(startTime).TotalMilliseconds;
            System.Diagnostics.Debug.WriteLine(string.Format("[FindCircle] CalCaliperPoints : {0}, calBestCricle : {1}", 계산시간, 핏라인));

            //if (bestLine == null) return;

            //CvPoint CvP1, CvP2;

            //bestLine.FitSize(InputImage.Width, InputImage.Height, out CvP1, out CvP2);
            //Point2d expectvector = oldCircle.EP - oldCircle.SP;
            
            //Point2d resultvector = new Point2d(bestLine.Vx, bestLine.Vy);
            //Point2d cptemp = new Point2d(bestLine.X1, bestLine.Y1);
            //Point2d sptemp = cptemp + new Point2d(bestLine.Vx, bestLine.Vy) * -10000;
            //Point2d eptemp = cptemp + new Point2d(bestLine.Vx, bestLine.Vy) * 10000;
            //if (expectvector.DotProduct(resultvector) < 0)
            //{
            //    Point2d temp = sptemp;
            //    sptemp = eptemp;
            //    eptemp = temp;
            //}

            MvCircle resultCircle = new MvCircle();

            //resultline.SP = new Point2d(CvP1.X, CvP1.Y);
            //resultline.EP = new Point2d(CvP2.X, CvP2.Y);
            resultCircle.CenterX = elipse.Center.X;
            resultCircle.CenterY = elipse.Center.Y;
            resultCircle.R = elipse.Size.Width;
            resultCircle.ThetaAngle = elipse.Angle;
            //resultCircle.SP = sptemp;
            //resultCircle.EP = eptemp;
            resultCircle.TransformMat = Mat.Eye(3, 3, MatType.CV_32FC1);

            Circle = resultCircle;
            Center = Circle.Center;
            //Radius = Circle.Radius;
            MakeResultList(calBesCircle);
            if (isEditMode)
            {
                NotifyPropertyChanged("Score");
            }

            lastRunSuccess = true;
        }
    }
}
