﻿using MvCore.Edit;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
//using MvCore.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Windows.Shapes;

namespace MvCore
{
    [Serializable]
    public class MvFindCorner : MvToolBase
    {
        public MvFindCorner()
        {
           
        }


        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
            inParams.Add("Line1", null);
            inParams.Add("Line2", null);
        }
        public override void InitOutParmas()
        {
            outParams.Add("Corner", null);
        }
        public override void InitOutProperty()
        {

        }

        [NonSerialized]
        MvImage inputImage;

        [InputParam]
        public MvImage InputImage
        {
            get { return inputImage; }
            set
            {
                if (value == null) return;
                inputImage = value;
            }
        }
        [NonSerialized]
        private MvLine line1;
        [InputParam]
        public MvLine Line1
        {
            get { return line1; }
            set { line1 = value; }
        }
        [NonSerialized]
        private MvLine line2;
        [InputParam]
        public MvLine Line2
        {
            get { return line2; }
            set { line2 = value; }
        }



        [NonSerialized]
        private Point2d corner;
        [OutputParam]
        public Point2d Corner
        {
            get { return corner; }
            set { corner = value; }
        }

        public void DrawLine(MvCore.Display.MvDisplayView display)
        {
          
            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Cyan, 1);
            if (Line1 != null)
                display.DrawLine(p, Line1.SP, Line1.EP);
            if (Line2 != null)
                display.DrawLine(p, Line2.SP, Line2.EP);
            if (Corner != null)
            {
                System.Drawing.Pen px = new System.Drawing.Pen(System.Drawing.Color.Red,9);
                System.Drawing.Font f = new System.Drawing.Font("굴림체", 10, System.Drawing.FontStyle.Bold);
                display.DrawEllipse(px, Corner,10 , 10);
                display.DrawString($"X: {Corner.X:F4}, Y: {Corner.Y:F4}", f,p.Brush,new PointF((float)Corner.X+10,(float)Corner.Y+20));
            } 
        }
        //SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            imageList.Clear();
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));
            outputImageInfo.drawingFunc = DrawLine;
            imageList.Add(outputImageInfo);
        }


        public Point2d FindCorner(MvLine _Line1, MvLine _Line2)
        {
            if(Line1 == null || Line2 == null) return new Point2d(double.NaN, double.NaN);
            double x1 = _Line1.SP.X, y1 = _Line1.SP.Y;
            double x2 = _Line1.EP.X, y2 = _Line1.EP.Y;
            double x3 = _Line2.SP.X, y3 = _Line2.SP.Y;
            double x4 = _Line2.EP.X, y4 = _Line2.EP.Y;

            double denominator =
                (x1 - x2) * (y3 - y4) -
                (y1 - y2) * (x3 - x4);

            if (Math.Abs(denominator) < 1e-6f)
            {
                return new Point2d(double.NaN, double.NaN); // Song song hoặc trùng nhau
            }

            double px =
                ((x1 * y2 - y1 * x2) * (x3 - x4) -
                 (x1 - x2) * (x3 * y4 - y3 * x4)) / denominator;

            double py =
                ((x1 * y2 - y1 * x2) * (y3 - y4) -
                 (y1 - y2) * (x3 * y4 - y3 * x4)) / denominator;

            return new Point2d(px, py);
        }




        public override void Run(bool isEditMode = false)
        {
           
            GetInParams();
            if (inputImage != null)
                outputImageInfo.Image = InputImage;
            if(Line1 != null && Line2 != null)
                Corner = FindCorner(Line1, Line2);
            GetOutParams();
            if (double.IsNaN(Corner.X) || double.IsNaN(Corner.Y))
            {
                lastRunSuccess = false; return;
            }
            lastRunSuccess = true;
        }
    }
}
