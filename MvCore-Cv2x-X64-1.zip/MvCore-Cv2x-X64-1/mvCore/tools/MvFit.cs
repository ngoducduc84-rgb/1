﻿using MvCore.Edit;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
//using MvCore.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Windows.Shapes;

namespace MvCore
{
    [Serializable]
    public class MvFit : MvToolBase
    {
        public MvFit()
        {
            //if(Line == null)
            // {
            //     Line = new MvLine();
            // }
            if (OnePoint == null)
                OnePoint = new MvPoint(0, 0);OnePoint.ID = 0;OnePoint.Color = Color.Red;
            if (TwoPoint == null)
                TwoPoint = new MvPoint(0, 0);TwoPoint.ID = 1;TwoPoint.Color = Color.YellowGreen;
            if (ThreePoint == null)
                ThreePoint = new MvPoint(0, 0);ThreePoint.ID = 2; ThreePoint.Color = Color.Green;
            if (FourPoint == null)
                FourPoint = new MvPoint(0,0); FourPoint.ID = 3;FourPoint.Color = Color.Cyan;
            if (FivePoint == null)
                FivePoint = new MvPoint(0, 0); FivePoint.ID = 4; FourPoint.Color = Color.Fuchsia;
        }
        public MvFit(SerializationInfo info, StreamingContext context) : base(info, context)
        {
           
        }

      


        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }
        public override void InitOutParmas()
        {
            outParams.Add("LineOut", null);
        }
        public override void InitOutProperty()
        {

        }

        [NonSerialized]
        MvImage inputImage;

        [InputParam]
        public MvImage InputImage
        {
            get { return inputImage; }
            set
            {
                if (value == null) return;
                inputImage = value;
            }
        }






        private MvPoint onePoint;

        public MvPoint OnePoint
        {
            get { return onePoint; }
            set { onePoint = value; }
        }

        private MvPoint twoPoint;

        public MvPoint TwoPoint
        {
            get { return twoPoint; }
            set { twoPoint = value; }
        }

        private MvPoint threePoint;

        public MvPoint ThreePoint
        {
            get { return threePoint; }
            set { threePoint = value; }
        }
        private MvPoint fourPoint;

        public MvPoint FourPoint
        {
            get { return fourPoint; }
            set { fourPoint = value; }
        }

        private MvPoint fivePoint;
        public MvPoint FivePoint
        {
            get { return fivePoint; }
            set { fivePoint = value; }
        }


        private MvLine lineOut;
        [OutputParam]
        public MvLine LineOut
        {
            get { return lineOut; }
            set { lineOut = value; }
        }

        

        public enum E_mode
        {
            FitCircle = 0,FitElipse = 1 ,FitLine =2
        }

        private E_mode mode;

        public E_mode Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        //private float angle;

        //public float Angle
        //{
        //    get { return angle; }
        //    set { angle = value; }
        //}

        public static bool TryGetCircle(
        PointF A, PointF B, PointF C,
        out PointF center, out float radius)
        {
            center = new PointF();
            radius = 0;

            float x1 = A.X, y1 = A.Y;
            float x2 = B.X, y2 = B.Y;
            float x3 = C.X, y3 = C.Y;

            float D = 2 * (
                x1 * (y2 - y3) +
                x2 * (y3 - y1) +
                x3 * (y1 - y2)
            );

            // 3 điểm thẳng hàng
            if (Math.Abs(D) < 1e-6)
                return false;

            float x1Sq = x1 * x1 + y1 * y1;
            float x2Sq = x2 * x2 + y2 * y2;
            float x3Sq = x3 * x3 + y3 * y3;

            float cx = (
                x1Sq * (y2 - y3) +
                x2Sq * (y3 - y1) +
                x3Sq * (y1 - y2)
            ) / D;

            float cy = (
                x1Sq * (x3 - x2) +
                x2Sq * (x1 - x3) +
                x3Sq * (x2 - x1)
            ) / D;

            center = new PointF(cx, cy);
            radius = Distance(center, A);

            return true;
        }

        private static float Distance(PointF p1, PointF p2)
        {
            float dx = p1.X - p2.X;
            float dy = p1.Y - p2.Y;
            return (float)Math.Sqrt(dx * dx + dy * dy);
        }

        public void Draw(MvCore.Display.MvDisplayView display)
        {
            System.Drawing.Pen px = new System.Drawing.Pen(System.Drawing.Color.Red, 9);
            System.Drawing.Font f = new System.Drawing.Font("굴림체", 10, System.Drawing.FontStyle.Bold);
            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Cyan, 1);

           
            if (Mode == E_mode.FitCircle)
            {
                PointF center;
                float radius;
                if(TryGetCircle(OnePoint.PointF,twoPoint.PointF,threePoint.PointF,out center,out radius))
                {
                    display.DrawEllipse(p, center, radius,radius);
                }
            }else if(Mode == E_mode.FitElipse)
            {
                List<OpenCvSharp.CPlusPlus.Point> points = new List<OpenCvSharp.CPlusPlus.Point>() { OnePoint.Point, TwoPoint.Point, ThreePoint.Point, FourPoint.Point ,FivePoint.Point};
               if(points.Count <5) return;
                RotatedRect rect = Cv2.FitEllipse(points.ToArray());
                Point2f center = rect.Center;
                float width = rect.Size.Width/2;
                float height = rect.Size.Height/2;
                float anlge = rect.Angle;
                if(center != null )
                {
                    display.DrawEllipse(p,new PointF(center.X,center.Y), width, height);
                }

            }else if(Mode == E_mode.FitLine)
            {
                Point2f[] pts = new Point2f[]{OnePoint.Point,twoPoint.Point};
                CvLine2D line = Cv2.FitLine( pts,DistanceType.L2,0, 0.01, 0.01 );
                if(line != null)
                {
                    double vx = line.Vx;
                    double vy = line.Vy;
                    double x0 = line.X1;
                    double y0 = line.Y1;

                    Point2d pt1 = new Point2d(x0 - vx * 1000,y0 - vy * 1000);
                    Point2d pt2 = new Point2d(x0 + vx * 1000,y0 + vy * 1000);
                    display.DrawLine(p, pt1, pt2);
                }
            }
          
        }
       
        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            imageList.Clear();
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));
            outputImageInfo.drawingFunc = Draw;
            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }
       

      




        public override void Run(bool isEditMode = false)
        {
          
            inputImageInfo.Image = InputImage;

        
            if (inputImage != null)
                outputImageInfo.Image = InputImage;
           
          
            //if (Line == null || Line.SP == null || Line.EP == null || double.IsNaN(Line.SP.X) || double.IsNaN(Line.EP.Y))
            //{
            //    lastRunSuccess = false; return;
            //}
            //LineOut = Line;
            lastRunSuccess = true;
        }
    }
}
