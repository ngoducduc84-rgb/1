﻿using OpenCvSharp;
using MvCore.Core;
using MvCore.Tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Windows.Forms;

namespace MvCore
{
    [Serializable]
    public class MvFor : MvToolBase
    {

        public MvFor()
        {
            ToolJob = new MvJob(); 
        }

        MvJob toolJob;

        public MvJob ToolJob
        {
            get { return toolJob; }
            set { toolJob = value; }
        }
        

        public MvFor(SerializationInfo info, StreamingContext context) : base(info, context) { }
        #region 안씀

        public override void InitInParmas()
        {
            //do nothing this tool
            inParams.Add("Condition", null);
           
        }
        private int condition;
        [InputParam]
        public int Condition 
        {
            get { return condition; }
            set { condition = value; }
        }
        public void getInParmas()
        {
            if (inParams["Condition"] != null)
            {
                Condition = (int)inParams["Condition"].GetValue();
            }
        }
        public override void InitOutParmas()
        {
            //do nothing this tool
            outParams.Add("For Region", null);
        }
        [OutputParam]
        public string _true { get; set; }
        [OutputParam]
        public string _false { get; set; }
        public TreeNodeCollection trueNodes { get; set; }
        public TreeNodeCollection falseNodes { get; set; }

        public override void InitImageList()
        {
            //do nothing this tool
        }

        public override void InitOutProperty()
        {

        }

        public override void Run(bool isEditMode = false)
        {

            getInParmas();
            
            if (Condition != null)
            {
                for (int i = 0; i < Condition; i++)
                {
                    if (toolJob != null)
                        toolJob.Run(isEditMode);
                }
                
            }
            
            GetOutParams();
            lastRunSuccess = true;
        }

        //public override void InitOutProperty()
        //{
        //    //do nothing this tool
        //}

        #endregion




    }
}
