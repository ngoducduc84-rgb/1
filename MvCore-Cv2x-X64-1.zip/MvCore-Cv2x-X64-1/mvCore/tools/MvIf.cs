﻿using MvCore.Core;
using MvCore.Tools;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Windows.Forms;

namespace MvCore
{
    [Serializable]
    public class MvIf : MvToolBase
    {

        public MvIf()
        {
            ToolJobTrue = new MvJob();
            toolJobFalse = new MvJob();
        }

        MvJob toolJobTrue;

        public MvJob ToolJobTrue
        {
            get { return toolJobTrue; }
            set { toolJobTrue = value; }
        }
        MvJob toolJobFalse;

        public MvJob ToolJobFalse
        {
            get { return toolJobFalse; }
            set { toolJobFalse = value; }
        }

        public MvIf(SerializationInfo info, StreamingContext context) : base(info, context) { }
        #region 안씀

        public override void InitInParmas()
        {
            //do nothing this tool
            inParams.Add("Condition1", null);
            inParams.Add("Condition2", null);
        }
        private Boolean condition1;
        private Boolean condition2;
        [InputParam]
        public Boolean Condition1 
        {
            get { return condition1; }
            set { condition1 = value; } 
        }
        [InputParam]
        public Boolean Condition2 
        {
            get { return condition2; }
            set { condition2 = value; }
        }
        public override void GetInParams()
        {
            List<string> deletedKey = new List<string>();

            foreach (KeyValuePair<string, InputParams> param in inParams)
            {
                PropertyInfo property = this.GetType().GetProperty(param.Key);

                if (property == null) continue;

                object value = null;

                if (param.Value == null)
                {
                    if (property.PropertyType.IsValueType)
                    {
                        var propInfo = this.GetType().GetProperty(property.Name);
                        value = propInfo?.GetValue(this);
                    }
                }
                else
                {
                    Type type = param.Value.GetType();

                    if (property.PropertyType != type)
                    {
                        if (type == null)
                            System.Windows.Forms.MessageBox.Show("Type is wrong");
                        else
                            System.Windows.Forms.MessageBox.Show(string.Format("Type is not match\r\nsrcType : {0}\r\ndstType : {1}", type.Name, property.PropertyType.Name));
                        deletedKey.Add(param.Key);
                        continue;
                    }

                    value = param.Value.GetValue();
                }

                property.SetValue(this, value);
            }

            foreach (string key in deletedKey)
            {
                inParams[key] = null;
            }
        }
        public override void InitOutParmas()
        {
            //do nothing this tool
            outParams.Add("True", null);
            outParams.Add("False", null);
        }
        [OutputParam]
        public string _true { get; set; }
        [OutputParam]
        public string _false { get; set; }
        public TreeNodeCollection trueNodes { get; set; }
        public TreeNodeCollection falseNodes { get; set; }

        public override void InitImageList()
        {
            //do nothing this tool
        }

        public override void InitOutProperty()
        {

        }

        public override void Run(bool isEditMode = false)
        {

            //getInParmas();

            if (Condition1 == Condition2)
            {
                if (toolJobTrue != null)
                    toolJobTrue.Run(isEditMode);
            }
            else
            {
                if (toolJobFalse != null)
                    toolJobFalse.Run(isEditMode);
            }
            GetOutParams();
            lastRunSuccess = true;
        }

        //public override void InitOutProperty()
        //{
        //    //do nothing this tool
        //}

        #endregion

       


    }
}
