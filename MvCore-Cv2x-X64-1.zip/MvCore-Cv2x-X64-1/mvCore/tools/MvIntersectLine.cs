﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;

namespace MvCore
{
    [Serializable]
    public class MvIntersectLine : MvToolBase
    {
        public MvIntersectLine() { }
        public MvIntersectLine(SerializationInfo info, StreamingContext context) : base(info, context) { }

        private int mcount;

        public int mCount
        {
            get { return mcount; }
            set { mcount = value; }
        }

        private double mscore;

        public double mScore
        {
            get { return mscore; }
            set { mscore = value; }
        }



        #region InParams

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
            inParams.Add("LineA", null);
            inParams.Add("LineB", null);
        }

        [InputParam]
        public MvImage InputImage { get; set; }

        [InputParam]
        public MvLine LineA
        {
            get
            {
                if (lineA == null) return null;
                MvLine outline = new MvLine();
                outline.SP = MvFunc.ImageToFixture2D(MvFunc.FixtureToImage2D(lineA.SP, lineA.TransformMat), InputImage.TransformMat);
                outline.EP = MvFunc.ImageToFixture2D(MvFunc.FixtureToImage2D(lineA.EP, lineA.TransformMat), InputImage.TransformMat);
                outline.TransformMat = InputImage.TransformMat;
                return outline;
            }
            set
            {
                lineA = value;
            }
        }
        MvLine lineA;

        [InputParam]
        public MvLine LineB
        {
            get
            {
                if (lineB == null) return null;
                MvLine outline = new MvLine();
                outline.SP = MvFunc.ImageToFixture2D(MvFunc.FixtureToImage2D(lineB.SP, lineB.TransformMat), InputImage.TransformMat);
                outline.EP = MvFunc.ImageToFixture2D(MvFunc.FixtureToImage2D(lineB.EP, lineB.TransformMat), InputImage.TransformMat);
                outline.TransformMat = InputImage.TransformMat;
                return outline;
            }
            set
            {
                lineB = value;
            }
        }
        MvLine lineB;

        [InputParam]
        public MvImage OutputImage { get; set; }

        #endregion

        #region OutParams

        public override void InitOutParmas()
        {
            outParams.Add("IntersectPoint", null);
        }

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;
        
        bool isIntersect = false;
        [NonSerialized]
        MvPoint intersectPoint;
        double angle;

        [OutputParam]
        public bool IsIntersect
        {
            get { return isIntersect; }
            set { isIntersect = value; NotifyPropertyChanged(); }
        }

        [OutputParam]
        public MvPoint IntersectPoint
        {
            get { return intersectPoint; }
            set { intersectPoint = value; NotifyPropertyChanged(); }
        }

        [OutputParam]
        public double Angle
        {
            get { return angle; }
            set { angle = value; NotifyPropertyChanged(); }
        }

        #endregion

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));
            outputImageInfo.drawingFunc = DrawIntersectLine;

            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);             
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            IsIntersect = false;
            IntersectPoint = null;
            Angle = 0.0;
            GetOutParams();
        }

        public void DrawIntersectLine(MvCore.Display.MvDisplayView display)
        {
            if (InputImage == null) return;
            if (LineA == null || LineB == null) return;
            if (intersectPoint == null) return;

            System.Drawing.Pen CyanPen = new System.Drawing.Pen(System.Drawing.Color.Cyan, 1);
            System.Drawing.Pen RedPen = new System.Drawing.Pen(System.Drawing.Color.Red, 3);

            display.DrawLine(CyanPen, LineA.SP, LineA.EP);
            display.DrawLine(CyanPen, LineB.SP, LineB.EP);

            display.DrawCross(RedPen, IntersectPoint.Point2d, 100, 100, LineA.ThetaAngle * Math.PI / 180);
            Font f = new System.Drawing.Font("굴림", 10, System.Drawing.FontStyle.Bold);
            SolidBrush SB = new System.Drawing.SolidBrush(Color.Cyan);
            display.DrawString(string.Format("({0:f3}, {1:f3}, {2:f3})", intersectPoint.X, intersectPoint.Y, Angle), f, SB, new Point2d(intersectPoint.X, intersectPoint.Y));
        }

        public override void Run(bool isEditMode = false)
        {
            inputImageInfo.Image = InputImage;
            outputImageInfo.Image = InputImage;

            if (InputImage == null) return;
            if (LineA == null || LineB == null) return;

            Point2d? cvIntersectPoint = MvFunc.FindCrossPoint(LineA, LineB);
            
            if (cvIntersectPoint != null)
            {
                IsIntersect = true;
                
                //cvIntersectPoint = SvFunc.ImageToFixture2D(SvFunc.FixtureToImage2D((Point2d)cvIntersectPoint, LineA.TransformMat), InputImage.TransformMat);

                IntersectPoint = new MvPoint(((Point2d)cvIntersectPoint).X, ((Point2d)cvIntersectPoint).Y);
                Angle = Math.Abs(LineB.ThetaAngle - LineA.ThetaAngle);

                IntersectPoint.ThetaRad = Math.Atan2(LineA.EP.Y - LineA.SP.Y, LineA.EP.X - LineA.SP.X);
                IntersectPoint.TransformMat = InputImage.TransformMat;
                //float[,] ff = SvFunc.DisplayMatF(IntersectPoint.TransformMat);
            }
            else
                IsIntersect = false;
            
            lastRunSuccess = true;
        }
    }
}
