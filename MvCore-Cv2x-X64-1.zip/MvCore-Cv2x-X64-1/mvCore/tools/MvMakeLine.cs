﻿using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.Serialization;

namespace MvCore
{
    [Serializable]
    public class MvMakeLine : MvToolBase
    {
        public MvMakeLine()
        {
            lCreteria = 600;
            //regionRect = new SvRectangle();            
        }

        public MvMakeLine(SerializationInfo info, StreamingContext context) : base(info, context) { }

        #region InputValue

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
            inParams.Add("InPoint1", null);
            inParams.Add("InPoint2", null);
        }

        [InputParam]
        public MvImage InputImage { get; set; }
        
        MvPoint inPoint1;
        [InputParam]
        public MvPoint InPoint1
        {
            get
            {
                if (inPoint1 == null)
                {
                    if (!inParams.ContainsKey("InPoint1"))
                        inPoint1 = new MvPoint();
                    else
                        return null;
                }
                Point3d P = MvFunc.ImageToFixture3D(MvFunc.FixtureToImage3D(new Point3d(inPoint1.X, inPoint1.Y, inPoint1.ThetaRad), inPoint1.TransformMat), InputImage.TransformMat);
                return new MvPoint(P);
            }
            set
            {
                inPoint1 = value;
                if (value == null) return;
                //NotifyPropertyChanged("InPoint1");
            }
        }

        MvPoint inPoint2;
        [InputParam]
        public MvPoint InPoint2
        {
            get
            {
                if (inPoint2 == null)
                {
                    if (!inParams.ContainsKey("InPoint2"))
                        inPoint2 = new MvPoint(100, 0);
                    else
                        return null;
                }
                Point3d P = MvFunc.ImageToFixture3D(MvFunc.FixtureToImage3D(new Point3d(inPoint2.X, inPoint2.Y, inPoint2.ThetaRad), inPoint2.TransformMat), InputImage.TransformMat);
                return new MvPoint(P);
            }
            set
            {
                inPoint2 = value;
                if (value == null) return;
                //NotifyPropertyChanged("InPoint2");
            }
        }

        MvLine inLine;
        [InputParam]
        public MvLine InLine
        {
            get 
            {
                if (inLine == null)
                {
                    if (InPoint1 == null || InPoint2 == null) return null;
                }
                inLine = new MvLine(inPoint1.Point2d, inPoint2.Point2d);
                return inLine;
            }
            set
            {
                if (value == null) return;
                if (InPoint1 != null)
                    inPoint1.Point2d = value.SP;
                if (InPoint2 != null)
                    inPoint2.Point2d = value.EP;
            }
        }

        double lCreteria;
        public double LCreteria
        {
            get { return lCreteria; }
            set { lCreteria = value; }
        }
        #endregion

        #region OutputValue
        public override void InitOutParmas()
        {
            outParams.Add("OutLine", null);
        }


        MvPoint lineCenter;
        [OutputParam]
        public MvPoint LineCenter
        {
            get
            {
                if (OutLine == null) return null;
                lineCenter = new MvPoint(OutLine.CP.X, OutLine.CP.Y);
                lineCenter.ThetaRad = OutLine.ThetaRad;
                lineCenter.TransformMat = InputImage.TransformMat;
                return lineCenter;
            }
            set { lineCenter = value; }
        }

        MvLine outLine;
        [OutputParam]
        public MvLine OutLine
        {
            get
            {
                return outLine;
            }
            set 
            {
                outLine = value;
            }
        }

        double result;
        [OutputParam]
        public double Result
        {
            get { return result; }
            set
            {
                result = value;
            }
        }

        [OutputParam]
        public bool IsLine { get; set; }

        [OutputParam]
        public bool IsDistance { get; set; }

        #endregion

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));

            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            OutLine = null;
            lineCenter = null;
            IsLine = false;
            GetOutParams();
        }

        public void DrawLine(Display.MvDisplayView display)
        {
            if (display.Image == null) return;
            if (inPoint1 == null || inPoint2 == null) return;
            display.GraphicsFuncCollection.Clear();
            
            display.GraphicsCollection.Add(OutLine);
        }

        public override void Run(bool isEditMode = false)
        {
            inputImageInfo.Image = InputImage;

            if (InputImage == null) return;
            if (InPoint1 == null || InPoint2 == null) return;

            OutLine = new MvLine();
            OutLine.SP = InPoint1.Point2d;
            OutLine.EP = InPoint2.Point2d;
            //OutLine.SP = SvFunc.ImageToFixture2D(SvFunc.FixtureToImage2D(InPoint1.Point2d, InPoint1.TransformMat), InputImage.TransformMat);
            //OutLine.EP = SvFunc.ImageToFixture2D(SvFunc.FixtureToImage2D(InPoint2.Point2d, InPoint2.TransformMat), InputImage.TransformMat);
            OutLine.TransformMat = InputImage.TransformMat;

            outputImageInfo.Image = InputImage;
            outputImageInfo.drawingFunc = DrawLine;

            IsLine = CheckLine();

            lastRunSuccess = true;
            NotifyPropertyChanged("OutLine");
        }

        MvPoint[] ArrangePoints(MvPoint[] inArray)
        {
            if (inArray.Length != 4) return null;
            List<MvPoint> outArray = new List<MvPoint>(inArray);
            outArray.Sort((a, b) => (a.Y < b.Y) ? -1 : 1);
            if (outArray[0].X > outArray[1].X)
            {
                MvPoint temp = outArray[1];
                outArray.RemoveAt(1);
                outArray.Insert(0, temp);
            }
            if (outArray[2].X < outArray[3].X)
            {
                MvPoint temp = outArray[3];
                outArray.RemoveAt(3);
                outArray.Insert(2, temp);
            }
            return outArray.ToArray();
        }

        Rectf getRectFromArray(MvPoint[] value)
        {
            Rectf rect = new Rectf();
            float minX = Math.Min(Math.Min(Math.Min(value[0].X, value[1].X), value[2].X), value[3].X);
            float minY = Math.Min(Math.Min(Math.Min(value[0].Y, value[1].Y), value[2].Y), value[3].Y);
            rect.Location = new Point2f(minX, minY);
            rect.Width = Math.Max(Math.Max(Math.Max(Math.Abs(value[0].X - minX), Math.Abs(value[1].X - minX)), Math.Abs(value[2].X - minX)), Math.Abs(value[3].X - minX));
            rect.Height = Math.Max(Math.Max(Math.Max(Math.Abs(value[0].Y - minY), Math.Abs(value[1].Y - minY)), Math.Abs(value[2].Y - minY)), Math.Abs(value[3].Y - minY));
            value = getArrayFromRect(rect);
            return rect;
        }

        MvPoint[] getArrayFromRect(Rectf rect)
        {
            MvPoint[] pF = new MvPoint[4];
            pF[0] = new MvPoint(rect.X, rect.Y);
            pF[1] = new MvPoint(rect.X + rect.Width - 1, rect.Y);
            pF[2] = new MvPoint(rect.X + rect.Width - 1, rect.Y + rect.Height - 1);
            pF[3] = new MvPoint(rect.X, rect.Y + rect.Height - 1);
            return pF;
        }

        bool CheckLine()
        {
            IsDistance = true;
            bool isline = false;
            Result = Point2d.Distance(OutLine.SP, OutLine.EP);

            // L Check        
            if (Result < lCreteria)
            {
                IsDistance = false;
                return isline;
            }

            return true;
        }
    }
}
