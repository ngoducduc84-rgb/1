﻿using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System;
using System.Drawing;
using System.Runtime.Serialization;

namespace MvCore
{
    [Serializable]
    public class MvMasking : MvToolBase
    {
        public MvMasking()
        {
            rotationRect = new MvRotationRectangle();
            ellipse = new MvEllipse();
        }

        public MvMasking(SerializationInfo info, StreamingContext context) : base(info, context) { }

        #region InputValue

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }

        [InputParam]
        public MvImage InputImage { get; set; }

        #endregion

        MvRotationRectangle rotationRect;
        public MvRotationRectangle RotationRect
        {
            get { return rotationRect; }
            set
            {
                rotationRect = value.Clone();
                rotationRect.TransformMat = InputImage.TransformMat;
            }
        }

        MvEllipse ellipse;
        public MvEllipse Ellipse
        {
            get { return ellipse; }
            set 
            {
                ellipse = new MvEllipse(value.Center, value.Width, value.Height);
                ellipse.TransformMat = InputImage.TransformMat;
            }
        }

        public enum ePenType
        {
            None, Rect, Ellipse
        }
        public ePenType PenType { get; set; }

        MvMask mask;
        public MvMask Mask
        {
            get 
            {
                if (InputImage == null) return null;
                MvImage imagetemp = null;

                if (mask == null)
                {
                    mask = new MvMask(InputImage.Width, InputImage.Height);
                }
                else if (!mask.IsPossible(InputImage))
                {
                    imagetemp = new MvImage(mask.MaskMat.Clone());
                    imagetemp.TransformMat = mask.TransformMat;
                    mask.Dispose();
                    mask = new MvMask(InputImage.Width, InputImage.Height);
                }

                if (imagetemp != null)
                {
                    //SvFunc.ShowTestImg(imagetemp.Mat, 0.5);
                    Cv2.WarpPerspective(imagetemp.Mat, mask.MaskMat, Mat.Eye(3, 3, MatType.CV_32FC1), new OpenCvSharp.CPlusPlus.Size(mask.MaskMat.Width, mask.MaskMat.Height), OpenCvSharp.Interpolation.Linear, OpenCvSharp.BorderType.Constant, 255);
                    //Cv2.WarpPerspective(imagetemp.Mat, mask.MaskMat, Mat.Eye(3, 3, MatType.CV_32FC1), new OpenCvSharp.Size(mask.MaskMat.Width, mask.MaskMat.Height), OpenCvSharp.InterpolationFlags .Linear, OpenCvSharp.BorderTypes.Constant, new Scalar(255));
                    //SvFunc.ShowTestImg(mask.MaskMat, 0.5);
                    imagetemp.Dispose();
                }

                mask.DrawMask = PenType == ePenType.None;
                mask.TransformMat = InputImage.TransformMat;
                return mask; 
            }
            set
            {
                if (mask == value) return;
                mask = value;
                NotifyPropertyChanged("Mask");
            }
        }

        public bool OnMask
        {
            get 
            { 
                if (mask == null) return true;
                return mask.OnMask;
            }
            set
            {
                if (mask == null) return;
                if (mask.OnMask == value) return;
                mask.OnMask = value;
                NotifyPropertyChanged("OnMask");
            }
        }

        public int PenSize
        {
            get
            {
                if (mask == null) return 0;
                return mask.PenSize;
            }
            set
            {
                if (mask == null) return;
                if (mask.PenSize == value) return;
                mask.PenSize = value;
                NotifyPropertyChanged("PenSize");
            }
        }

        #region OutputValue
        public override void InitOutParmas()
        {
            outParams.Add("OutputImage", null);
        }

        [OutputParam]
        public MvImage OutputImage { get; set; }

        MvImage maskImage;
        [OutputParam]
        public MvImage MaskImage
        {
            get
            {
                if (maskImage == null)
                    maskImage = new MvImage(Mask.MaskMat);
                return maskImage;
            }
        }
        
        #endregion

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));

            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;

            if (OutputImage != null) OutputImage.Dispose();
            OutputImage = null;

            GetOutParams();
        }

        public override void Run(bool isEditMode = false)
        {
            inputImageInfo.Image = InputImage;

            if (InputImage == null) return;
            
            if (OutputImage != null) OutputImage.Dispose();            
            OutputImage = new MvImage();

            //if (Mask != null && !Mask.IsPossible(InputImage))
                InputImage.Mat.CopyTo(OutputImage.Mat, Mask.MaskMat);
            //else
                //OutputImage = InputImage.Clone(true);

            OutputImage.RegionRect = new MvRectangle(0, 0, OutputImage.Width, OutputImage.Height);

            outputImageInfo.Image = OutputImage;
            
            lastRunSuccess = true;
        }

    }
}
