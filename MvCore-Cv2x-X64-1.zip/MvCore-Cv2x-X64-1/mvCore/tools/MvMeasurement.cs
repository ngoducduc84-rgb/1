﻿using MvCore.Edit;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
//using MvCore.Common;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using System.Windows.Shapes;

namespace MvCore
{
    [Serializable]
    public class MvMeasurement : MvToolBase
    {
        public MvMeasurement()
        {
            if (PointA == null)
                PointA = new MvPoint(0, 0); PointA.ID = 0; PointA.Color = Color.Green;
            if (PointB == null)
                PointB = new MvPoint(0, 0); PointB.ID = 1; PointB.Color = Color.Red;
            if (LineA == null)
                LineA = new MvLine(); LineA.ID = 0; LineA.Color = Color.Green;
            if (LineB == null)
                LineB = new MvLine(); LineB.ID = 1; LineB.Color = Color.Red;
            if (EllipseA == null)
                EllipseA = new MvEllipse(); EllipseA.ID = 0; EllipseA.Color = Color.Green;
            if (EllipseB == null)
                EllipseB = new MvEllipse(); EllipseB.ID = 1; EllipseB.Color = Color.Red;
            if (CircleA == null)
                CircleA = new MvCircle(); CircleA.ID = 0; CircleA.Color = Color.Green;
            if (CircleB == null)
                CircleB = new MvCircle(); CircleB.ID = 1; CircleB.Color = Color.Red;
        }
        public MvMeasurement(SerializationInfo info, StreamingContext context) : base(info, context)
        {

        }




        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }
        public override void InitOutParmas()
        {
            outParams.Add("AngleOut", null);
            outParams.Add("DistanceOut", null);
        }
        public override void InitOutProperty()
        {

        }

        [NonSerialized]
        MvImage inputImage;

        [InputParam]
        public MvImage InputImage
        {
            get { return inputImage; }
            set
            {
                if (value == null) return;
                inputImage = value;
            }
        }

        private float angleOut;
        [OutputParam]
        public float AngleOut
        {
            get { return angleOut; }
            set { angleOut = value; }
        }
        private float distanceOut;
        [OutputParam]
        public float DistanceOut
        {
            get { return distanceOut; }
            set { distanceOut = value; }
        }



        public enum E_mode
        {
            AnlgeLineLine = 0, AnglePointPoint = 1, DistanceCircleCircle = 2, DistanceLineCircle = 3, DistanceLineEllipse = 4, DistancePointCircle = 5, DistancePointEllipse = 6,
            DistancePointLine = 7, DistancePointPoint = 8, DistancePointSegment = 9, DistanceSegmentCircle = 10, DistanceSegmentEllipse = 11, DistanceSegmentLine = 12, DistanceSegmentSegment = 13
        }

        private E_mode mode;

        public E_mode Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        private float angle;

        public float Angle
        {
            get { return angle; }
            set { angle = value; }
        }

        private MvPoint pointA;
        [InputParam]
        public MvPoint PointA
        {
            get { return pointA; }
            set { pointA = value; }
        }
        private MvPoint pointB;
        [InputParam]
        public MvPoint PointB
        {
            get { return pointB; }
            set { pointB = value; }
        }

        private MvLine lineA;
        [InputParam]
        public MvLine LineA
        {
            get { return lineA; }
            set { lineA = value; }
        }

        private MvLine lineB;
        [InputParam]
        public MvLine LineB
        {
            get { return lineB; }
            set { lineB = value; }
        }

        private MvEllipse ellipseA;
        [InputParam]
        public MvEllipse EllipseA
        {
            get { return ellipseA; }
            set { ellipseA = value; }
        }

        private MvEllipse ellipseB;
        [InputParam]
        public MvEllipse EllipseB
        {
            get { return ellipseB; }
            set { ellipseB = value; }
        }

        private MvCircle circleA;
        [InputParam]
        public MvCircle CircleA
        {
            get { return circleA; }
            set { circleA = value; }
        }

        private MvCircle circleB;
        [InputParam]
        public MvCircle CircleB
        {
            get { return circleB; }
            set { circleB = value; }
        }


        public void Draw(MvCore.Display.MvDisplayView display)
        {
            System.Drawing.Pen px = new System.Drawing.Pen(System.Drawing.Color.Red, 9);
            System.Drawing.Font f = new System.Drawing.Font("굴림체", 10, System.Drawing.FontStyle.Bold);
            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Cyan, 1);
            //if (Mode == E_mode.Point)
            //{
            //    if (Line != null)
            //    {
            //        display.DrawLine(px, Line.SP, Line.EP);
            //    }
            //}else if(Mode == E_mode.Angle)
            //{
            //    Point2d endPoint = CreateEndPoint(Line.SP,Angle, Line.GetLineLength());
            //    if (Line != null)
            //    {
            //        display.DrawLine(px, Line.SP, endPoint);
            //    }
            //}else if(Mode == E_mode.BiscectPoints)
            //{
            //    MvLine line2 = CreatePerpendicularLine(Line, Line.GetLineLength());
            //    if(line2 != null && Line != null)
            //    {
            //        display.DrawLine(px, Line.SP, Line.EP);
            //        display.DrawLine(px, line2.SP, line2.EP);
            //        lineOut2 = line2;
            //    }
            //}
            //else if(Mode == E_mode.Parallel)
            //{
            //    MvLine line2 = CreateParallelLineThroughPoint(Line,ThreePoint.Point2d);
            //    if (line2 != null && Line != null)
            //    {
            //        display.DrawLine(px, Line.SP, Line.EP);
            //        display.DrawLine(px, line2.SP, line2.EP);
            //        lineOut2 = line2;
            //    }
            //}else if(Mode == E_mode.Perpendicular)
            //{
            //    MvLine line2 = CreatePerpendicularLineThroughPoint(Line, ThreePoint.Point2d, Line.GetLineLength());
            //    if (line2 != null && Line != null)
            //    {
            //        display.DrawLine(px, Line.SP, Line.EP);
            //        display.DrawLine(px, line2.SP, line2.EP);
            //        lineOut2 = line2;
            //    }
            //}
        }

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        public override void InitImageList()
        {
            imageList.Clear();
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));
            outputImageInfo.drawingFunc = Draw;
            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }

        public static double AngleLineLine(Point2d a1, Point2d a2, Point2d b1, Point2d b2)
        {
            // Vector chỉ phương
            double ux = a2.X - a1.X;
            double uy = a2.Y - a1.Y;

            double vx = b2.X - b1.X;
            double vy = b2.Y - b1.Y;

            double dot = ux * vx + uy * vy;
            double magU = Math.Sqrt(ux * ux + uy * uy);
            double magV = Math.Sqrt(vx * vx + vy * vy);

            if (magU < 1e-9 || magV < 1e-9)
                return 0; // line không hợp lệ

            double cos = dot / (magU * magV);

            // Chống sai số số học
            cos = Math.Max(-1.0, Math.Min(1.0, cos));

            double angleRad = Math.Acos(cos);
            double angleDeg = angleRad * 180.0 / Math.PI;

            return angleDeg; // 0 → 180°
        }

        public static double AnglePointPoint(Point2d a, Point2d b)
        {
            double dx = b.X - a.X;
            double dy = b.Y - a.Y;

            if (dx == 0 && dy == 0)
                return 0; // 2 điểm trùng nhau

            double angle = Math.Atan2(dy, dx) * 180.0 / Math.PI;
            if (angle < 0) angle += 360;

            return angle;
        }
        public static double DistanceCircleCircle(Point2d c1, double r1, Point2d c2, double r2)
        {
            double dx = c2.X - c1.X;
            double dy = c2.Y - c1.Y;

            double centerDistance = Math.Sqrt(dx * dx + dy * dy);

            return centerDistance - (r1 + r2);
        }
        public static double DistanceCircleLine(Point2d A, Point2d B, Point2d C, double r)
        {
            double Acoef = B.Y - A.Y;
            double Bcoef = A.X - B.X;
            double Ccoef = B.X * A.Y - A.X * B.Y;

            double distCenterToLine =
                Math.Abs(Acoef * C.X + Bcoef * C.Y + Ccoef) /
                Math.Sqrt(Acoef * Acoef + Bcoef * Bcoef);

            return distCenterToLine - r;
        }
        public static double DistanceCircleToSegment(Point2d A, Point2d B, Point2d C, double r)
        {
            double vx = B.X - A.X;
            double vy = B.Y - A.Y;

            double wx = C.X - A.X;
            double wy = C.Y - A.Y;

            double c1 = vx * wx + vy * wy;
            if (c1 <= 0)
                return Math.Sqrt(wx * wx + wy * wy) - r;

            double c2 = vx * vx + vy * vy;
            if (c2 <= c1)
                return Math.Sqrt(
                    (C.X - B.X) * (C.X - B.X) +
                    (C.Y - B.Y) * (C.Y - B.Y)) - r;

            double t = c1 / c2;
            double px = A.X + t * vx;
            double py = A.Y + t * vy;

            double dx = C.X - px;
            double dy = C.Y - py;

            return Math.Sqrt(dx * dx + dy * dy) - r;
        }


        public static double DistanceLineEllipse(Point2d L1, Point2d L2,Point2d center,double a, double b,double ellipseAngleDeg)
        {
            // 1) Tạo pháp tuyến đơn vị cho line
            double dx = L2.X - L1.X;
            double dy = L2.Y - L1.Y;
            double len = Math.Sqrt(dx * dx + dy * dy);
            if (len < EPS) return 0; // line suy biến

            // normal = (dy, -dx) hoặc (-dy, dx) đều được (chỉ khác dấu)
            double nx = dy / len;
            double ny = -dx / len;

            // 2) Signed distance từ tâm ellipse tới line: d0 = n · (center - L1)
            double d0 = nx * (center.X - L1.X) + ny * (center.Y - L1.Y);

            // 3) Đưa pháp tuyến về hệ trục ellipse (xoay ngược ellipse)
            double theta = ellipseAngleDeg * Math.PI / 180.0;
            Point2d nLocal = Rotate(new Point2d(nx, ny), -theta);

            // 4) Bán kính hiệu dụng của ellipse theo hướng pháp tuyến
            double r = Math.Sqrt((a * nLocal.X) * (a * nLocal.X) + (b * nLocal.Y) * (b * nLocal.Y));

            // 5) Khoảng cách line-ellipse
            return Math.Max(0.0, Math.Abs(d0) - r);
        }

        //    public static double DistanceLineEllipse(
        //Point2d linePoint, double lineAngleDeg,
        //Point2d ellipseCenter,
        //double a, double b,
        //double ellipseAngleDeg)
        //    {
        //        double lt = lineAngleDeg * Math.PI / 180.0;
        //        double et = ellipseAngleDeg * Math.PI / 180.0;

        //        // pháp tuyến line
        //        double nx = Math.Cos(lt);
        //        double ny = -Math.Sin(lt);

        //        // xoay pháp tuyến về hệ ellipse
        //        double c = Math.Cos(-et);
        //        double s = Math.Sin(-et);
        //        double nxp = nx * c - ny * s;
        //        double nyp = nx * s + ny * c;

        //        double C = -(nx * linePoint.X + ny * linePoint.Y);

        //        double dCenter =
        //            Math.Abs(nx * ellipseCenter.X +
        //                     ny * ellipseCenter.Y + C);

        //        double rEff =
        //            Math.Sqrt(a * a * nxp * nxp +
        //                      b * b * nyp * nyp);

        //        return dCenter - rEff;
        //    }

        public static double DistancePointCircle(Point2d p, Point2d center, double r)
        {
            double dx = p.X - center.X;
            double dy = p.Y - center.Y;

            double distToCenter = Math.Sqrt(dx * dx + dy * dy);

            return distToCenter - r;
        }



        private static Point2d RotateOrigin(Point2d p, double angleRad)
        {
            double c = Math.Cos(angleRad);
            double s = Math.Sin(angleRad);
            return new Point2d(
                p.X * c - p.Y * s,
                p.X * s + p.Y * c
            );
        }
        public static double DistancePointEllipse(Point2d point, Point2d center, double a, double b, double ellipseAngleDeg, out Point2d closestPoint)
        {
            closestPoint = default;

            if (a <= 0 || b <= 0)
                throw new ArgumentException("a và b phải > 0 (a=width/2, b=height/2).");

            // 1) Đưa point về hệ ellipse (tâm về 0,0 và bỏ xoay)
            double ang = ellipseAngleDeg * Math.PI / 180.0;

            Point2d pLocal = point - center;
            pLocal = RotateOrigin(pLocal, -ang); // inverse rotation

            // 2) Dùng đối xứng về góc phần tư 1 để giải cho ổn định
            double sx = pLocal.X >= 0 ? 1.0 : -1.0;
            double sy = pLocal.Y >= 0 ? 1.0 : -1.0;

            double px = Math.Abs(pLocal.X);
            double py = Math.Abs(pLocal.Y);

            double a2 = a * a;
            double b2 = b * b;

            // Case đặc biệt
            if (px < 1e-15 && py < 1e-15)
            {
                // Tại tâm: điểm gần nhất là (0, b) (hoặc (0,-b)), distance = b (trục nhỏ)
                Point2d qLocal0 = new Point2d(0, b);
                Point2d qWorld0 = RotateOrigin(qLocal0, ang) + center;
                closestPoint = qWorld0;
                return b;
            }
            if (py < 1e-15)
            {
                // Nằm trên trục X: gần nhất là (a,0)
                Point2d qLocal = new Point2d(a * sx, 0);
                closestPoint = RotateOrigin(qLocal, ang) + center;
                return Math.Abs(px - a);
            }
            if (px < 1e-15)
            {
                // Nằm trên trục Y: gần nhất là (0,b)
                Point2d qLocal = new Point2d(0, b * sy);
                closestPoint = RotateOrigin(qLocal, ang) + center;
                return Math.Abs(py - b);
            }

            // Kiểm tra point nằm trong/ngoài ellipse (trong hệ local)
            double g = (px * px) / a2 + (py * py) / b2;
            if (Math.Abs(g - 1.0) < 1e-12)
            {
                // Điểm nằm ngay trên ellipse
                closestPoint = point;
                return 0.0;
            }

            // 3) Giải F(lambda)=0 bằng bisection (robust)
            double F(double lamda)
            {
                double t1 = a2 * px * px / ((a2 + lamda) * (a2 + lamda));
                double t2 = b2 * py * py / ((b2 + lamda) * (b2 + lamda));
                return t1 + t2 - 1.0;
            }

            double lo, hi;

            if (g > 1.0)
            {
                // outside -> lambda > 0
                lo = 0.0;
                hi = 1.0;
                while (F(hi) > 0.0)
                {
                    hi *= 2.0;
                    if (hi > 1e18) break; // tránh loop vô hạn trong case cực đoan
                }
            }
            else
            {
                // inside -> lambda in (-min(a^2,b^2), 0)
                double m = Math.Min(a2, b2);
                lo = -m + 1e-12;
                hi = 0.0;
            }

            double fLo = F(lo);
            double fHi = F(hi);
            if (fLo * fHi > 0)
                throw new Exception("Không bracket được nghiệm. Kiểm tra lại a,b hoặc dữ liệu điểm.");

            // Bisection ~ 60 vòng là đủ double
            double lamMid = 0.0;
            for (int i = 0; i < 80; i++)
            {
                lamMid = 0.5 * (lo + hi);
                double fMid = F(lamMid);

                if (Math.Abs(fMid) < 1e-14)
                    break;

                if (fLo * fMid > 0)
                {
                    lo = lamMid;
                    fLo = fMid;
                }
                else
                {
                    hi = lamMid;
                    fHi = fMid;
                }
            }

            double lam = lamMid;

            // 4) Tính điểm gần nhất Q trên ellipse (trong góc phần tư 1)
            double qx = a2 * px / (a2 + lam);
            double qy = b2 * py / (b2 + lam);

            // Trả về đúng góc phần tư ban đầu
            Point2d qLocalSigned = new Point2d(qx * sx, qy * sy);

            // 5) Distance thật trong local (rotation/translation không làm đổi distance)
            double dx = qLocalSigned.X - pLocal.X;
            double dy = qLocalSigned.Y - pLocal.Y;
            double dist = Math.Sqrt(dx * dx + dy * dy);

            // 6) Đổi Q về world
            closestPoint = RotateOrigin(qLocalSigned, ang) + center;

            return dist;
        }

        public static double DistancePointLine(Point2d A, Point2d B, Point2d P)
        {
            double vx = B.X - A.X;
            double vy = B.Y - A.Y;

            double wx = P.X - A.X;
            double wy = P.Y - A.Y;

            double cross = vx * wy - vy * wx;
            double len = Math.Sqrt(vx * vx + vy * vy);

            if (len < 1e-12)
                return 0; // A và B trùng nhau -> line không hợp lệ

            return Math.Abs(cross) / len;
        }
        public static double DistancePointPoint(Point2d a, Point2d b)
        {
            double dx = b.X - a.X;
            double dy = b.Y - a.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        public static double DistancePointSegment(Point2d A, Point2d B, Point2d P, out Point2d closestPoint)
        {
            double vx = B.X - A.X;
            double vy = B.Y - A.Y;

            double wx = P.X - A.X;
            double wy = P.Y - A.Y;

            double len2 = vx * vx + vy * vy;

            // Segment bị "co" thành 1 điểm
            if (len2 < 1e-12)
            {
                closestPoint = A;
                double dx0 = P.X - A.X;
                double dy0 = P.Y - A.Y;
                return Math.Sqrt(dx0 * dx0 + dy0 * dy0);
            }

            // tham số chiếu (không clamp)
            double t = (wx * vx + wy * vy) / len2;

            // clamp vào [0..1] để nằm trong đoạn
            if (t < 0) t = 0;
            else if (t > 1) t = 1;

            closestPoint = new Point2d(A.X + t * vx, A.Y + t * vy);

            double dx = P.X - closestPoint.X;
            double dy = P.Y - closestPoint.Y;

            return Math.Sqrt(dx * dx + dy * dy);
        }

        public static double DistancePointToSegment(Point2d A, Point2d B, Point2d P, out Point2d closestPoint)
        {
            double vx = B.X - A.X;
            double vy = B.Y - A.Y;
            double len2 = vx * vx + vy * vy;

            // Segment suy biến thành 1 điểm
            if (len2 < 1e-12)
            {
                closestPoint = A;
                double dx0 = P.X - A.X;
                double dy0 = P.Y - A.Y;
                return Math.Sqrt(dx0 * dx0 + dy0 * dy0);
            }

            // Tham số chiếu
            double t = ((P.X - A.X) * vx + (P.Y - A.Y) * vy) / len2;

            // Clamp về [0..1] để nằm trong đoạn
            if (t < 0) t = 0;
            else if (t > 1) t = 1;

            closestPoint = new Point2d(A.X + t * vx, A.Y + t * vy);

            double dx = P.X - closestPoint.X;
            double dy = P.Y - closestPoint.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }
        public static double DistanceSegmentCircle(Point2d A, Point2d B, Point2d center, double r, out Point2d closestOnSegment, out Point2d closestOnCircle)
        {
            if (r < 0) throw new ArgumentException("r must be >= 0");

            double dCenterToSeg = DistancePointToSegment(A, B, center, out closestOnSegment);

            // Nếu segment cắt/đi vào hình tròn đặc => khoảng cách = 0
            double signed = dCenterToSeg - r;
            double gap = Math.Max(0.0, signed);

            // Điểm gần nhất trên circle (nếu cần)
            // Nếu center trùng closestOnSegment, chọn hướng bất kỳ
            double dx = closestOnSegment.X - center.X;
            double dy = closestOnSegment.Y - center.Y;
            double len = Math.Sqrt(dx * dx + dy * dy);

            if (len < 1e-12)
            {
                // fallback hướng (1,0)
                closestOnCircle = new Point2d(center.X + r, center.Y);
            }
            else
            {
                closestOnCircle = new Point2d(center.X + r * dx / len, center.Y + r * dy / len);
            }

            return gap; // >= 0
        }

        // Xoay một điểm quanh gốc (0,0)
        private static Point2d Rotate(Point2d p, double angleRad)
        {
            double c = Math.Cos(angleRad);
            double s = Math.Sin(angleRad);
            return new Point2d(
                p.X * c - p.Y * s,
                p.X * s + p.Y * c
            );
        }

        // Đưa điểm world -> ellipse local (tâm về 0,0 và bỏ xoay)
        private static Point2d ToEllipseLocal(Point2d pWorld, Point2d center, double ellipseAngleRad)
        {
            double x = pWorld.X - center.X;
            double y = pWorld.Y - center.Y;
            return Rotate(new Point2d(x, y), -ellipseAngleRad);
        }

        // Đưa điểm ellipse local -> world
        private static Point2d ToWorld(Point2d pLocal, Point2d center, double ellipseAngleRad)
        {
            Point2d r = Rotate(pLocal, ellipseAngleRad);
            return new Point2d(r.X + center.X, r.Y + center.Y);
        }

        // Kiểm tra point nằm trong/ngoài ellipse axis-aligned (tâm tại 0,0)
        private static double EllipseImplicit(Point2d p, double a, double b)
        {
            double a2 = a * a;
            double b2 = b * b;
            return (p.X * p.X) / a2 + (p.Y * p.Y) / b2; // <=1: trong/biên, >1: ngoài
        }

        /// <summary>
        /// Khoảng cách từ 1 điểm đến BIÊN ellipse axis-aligned (tâm 0,0).
        /// Trả về (distance >=0) và closestPoint nằm trên biên ellipse.
        /// Dùng bisection tìm lambda (robust cho cả điểm trong và ngoài).
        /// </summary>
        private static double DistancePointToEllipseLocal(Point2d p, double a, double b, out Point2d closest)
        {
            closest = default;

            if (a <= 0 || b <= 0)
                throw new ArgumentException("a,b phải > 0");

            double x = p.X;
            double y = p.Y;

            // đối xứng sang góc phần tư 1 để ổn định số
            double sx = x >= 0 ? 1.0 : -1.0;
            double sy = y >= 0 ? 1.0 : -1.0;
            double px = Math.Abs(x);
            double py = Math.Abs(y);

            double a2 = a * a;
            double b2 = b * b;

            // Case đặc biệt: p gần (0,0)
            if (px < 1e-15 && py < 1e-15)
            {
                closest = new Point2d(0, b); // bất kỳ điểm trên ellipse
                return b;
            }

            double g = (px * px) / a2 + (py * py) / b2;
            if (Math.Abs(g - 1.0) < 1e-14)
            {
                closest = p; // đã nằm trên biên
                return 0.0;
            }

            // F(lambda) = a^2 px^2/(a^2+λ)^2 + b^2 py^2/(b^2+λ)^2 - 1
            double F(double lamda)
            {
                double t1 = a2 * px * px / ((a2 + lamda) * (a2 + lamda));
                double t2 = b2 * py * py / ((b2 + lamda) * (b2 + lamda));
                return t1 + t2 - 1.0;
            }

            double lo, hi;

            if (g > 1.0)
            {
                // điểm ngoài: lambda > 0
                lo = 0.0;
                hi = 1.0;
                while (F(hi) > 0.0)
                {
                    hi *= 2.0;
                    if (hi > 1e18) break;
                }
            }
            else
            {
                // điểm trong: lambda in (-min(a^2,b^2), 0)
                double m = Math.Min(a2, b2);
                lo = -m + 1e-12;
                hi = 0.0;
            }

            double fLo = F(lo);
            double fHi = F(hi);
            if (fLo * fHi > 0.0)
                throw new Exception("Không bracket được nghiệm lambda (kiểm tra dữ liệu).");

            // Bisection
            double mid = 0.0;
            for (int i = 0; i < 80; i++)
            {
                mid = 0.5 * (lo + hi);
                double fMid = F(mid);

                if (Math.Abs(fMid) < 1e-14) break;

                if (fLo * fMid > 0.0)
                {
                    lo = mid;
                    fLo = fMid;
                }
                else
                {
                    hi = mid;
                    fHi = fMid;
                }
            }

            double lam = mid;

            // điểm gần nhất trên ellipse (góc phần tư 1)
            double qx = a2 * px / (a2 + lam);
            double qy = b2 * py / (b2 + lam);

            closest = new Point2d(qx * sx, qy * sy);

            double dx = closest.X - x;
            double dy = closest.Y - y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        /// <summary>
        /// Segment AB có cắt ellipse axis-aligned (tâm 0,0) không?
        /// Nếu có, trả về true và một điểm giao (hitPoint).
        /// </summary>
        private static bool SegmentIntersectsEllipseLocal(Point2d A, Point2d B, double a, double b, out Point2d hitPoint)
        {
            hitPoint = default;

            double dx = B.X - A.X;
            double dy = B.Y - A.Y;

            double a2 = a * a;
            double b2 = b * b;

            // (A + tD) thế vào x^2/a^2 + y^2/b^2 = 1 => alpha t^2 + beta t + gamma = 0
            double alpha = (dx * dx) / a2 + (dy * dy) / b2;
            double beta = 2.0 * (A.X * dx / a2 + A.Y * dy / b2);
            double gamma = (A.X * A.X) / a2 + (A.Y * A.Y) / b2 - 1.0;

            // Segment suy biến
            if (alpha < 1e-18)
            {
                // A~B: coi như 1 điểm
                if (Math.Abs(gamma) < 1e-12)
                {
                    hitPoint = A;
                    return true;
                }
                return false;
            }

            double disc = beta * beta - 4.0 * alpha * gamma;
            if (disc < -1e-12) return false;
            if (disc < 0) disc = 0;

            double s = Math.Sqrt(disc);
            double t1 = (-beta - s) / (2.0 * alpha);
            double t2 = (-beta + s) / (2.0 * alpha);

            bool ok1 = (t1 >= 0.0 && t1 <= 1.0);
            bool ok2 = (t2 >= 0.0 && t2 <= 1.0);

            if (!ok1 && !ok2) return false;

            double t = ok1 ? t1 : t2;
            hitPoint = new Point2d(A.X + t * dx, A.Y + t * dy);
            return true;
        }

        /// <summary>
        /// Khoảng cách ngắn nhất giữa segment AB và BIÊN ellipse (có thể xoay).
        /// Trả về distance (>=0) và 2 điểm gần nhất:
        /// - closestOnSegment: điểm trên segment
        /// - closestOnEllipse: điểm trên biên ellipse
        /// </summary>
        public static double DistanceSegmentEllipse(Point2d segA, Point2d segB, Point2d ellipseCenter, double ellipseWidth, double ellipseHeight, double ellipseAngleDeg, out Point2d closestOnSegment, out Point2d closestOnEllipse)
        {
            closestOnSegment = default;
            closestOnEllipse = default;

            double a = ellipseWidth * 0.5;   // bán trục
            double b = ellipseHeight * 0.5;

            if (a <= 0 || b <= 0)
                throw new ArgumentException("ellipseWidth/Height phải > 0");

            double ang = ellipseAngleDeg * Math.PI / 180.0;

            // 1) đưa segment về local của ellipse
            Point2d A = ToEllipseLocal(segA, ellipseCenter, ang);
            Point2d B = ToEllipseLocal(segB, ellipseCenter, ang);

            // 2) Nếu segment cắt/tiếp xúc ellipse => khoảng cách = 0
            if (SegmentIntersectsEllipseLocal(A, B, a, b, out Point2d hitLocal))
            {
                Point2d hitWorld = ToWorld(hitLocal, ellipseCenter, ang);
                closestOnSegment = hitWorld;
                closestOnEllipse = hitWorld;
                return 0.0;
            }

            // 3) Nếu cả 2 đầu mút nằm trong ellipse => đoạn nằm trong ellipse (ellipse lồi)
            double gA = EllipseImplicit(A, a, b);
            double gB = EllipseImplicit(B, a, b);
            if (gA < 1.0 && gB < 1.0)
            {
                double dA = DistancePointToEllipseLocal(A, a, b, out Point2d qA);
                double dB = DistancePointToEllipseLocal(B, a, b, out Point2d qB);

                if (dA <= dB)
                {
                    closestOnSegment = segA;
                    closestOnEllipse = ToWorld(qA, ellipseCenter, ang);
                    return dA;
                }
                else
                {
                    closestOnSegment = segB;
                    closestOnEllipse = ToWorld(qB, ellipseCenter, ang);
                    return dB;
                }
            }

            // 4) Trường hợp còn lại: segment ở ngoài ellipse => tối ưu theo t ∈ [0,1]
            double vx = B.X - A.X;
            double vy = B.Y - A.Y;
            double len2 = vx * vx + vy * vy;

            // Segment suy biến (A~B)
            if (len2 < 1e-12)
            {
                double d = DistancePointToEllipseLocal(A, a, b, out Point2d q);
                closestOnSegment = segA;
                closestOnEllipse = ToWorld(q, ellipseCenter, ang);
                return d;
            }

            // Golden section search
            double f(double t)
            {
                Point2d p = new Point2d(A.X + t * vx, A.Y + t * vy);
                double d = DistancePointToEllipseLocal(p, a, b, out _);
                return d;
            }

            double lo = 0.0, hi = 1.0;
            const double gr = 0.6180339887498949; // (sqrt(5)-1)/2

            double c = hi - gr * (hi - lo);
            double d1 = lo + gr * (hi - lo);
            double fc = f(c);
            double fd = f(d1);

            for (int i = 0; i < 80; i++)
            {
                if (fc > fd)
                {
                    lo = c;
                    c = d1; fc = fd;
                    d1 = lo + gr * (hi - lo);
                    fd = f(d1);
                }
                else
                {
                    hi = d1;
                    d1 = c; fd = fc;
                    c = hi - gr * (hi - lo);
                    fc = f(c);
                }
            }

            double tBest = 0.5 * (lo + hi);
            Point2d pBestLocal = new Point2d(A.X + tBest * vx, A.Y + tBest * vy);

            double dist = DistancePointToEllipseLocal(pBestLocal, a, b, out Point2d qBestLocal);

            closestOnSegment = ToWorld(pBestLocal, ellipseCenter, ang);
            closestOnEllipse = ToWorld(qBestLocal, ellipseCenter, ang);
            return dist;
        }

        private const double EPS = 1e-12;

        // Signed distance của P tới line vô hạn qua L1-L2 (có dấu)
        private static double SignedDistPointToLine(Point2d P, Point2d L1, Point2d L2)
        {
            double A = L2.Y - L1.Y;
            double B = L1.X - L2.X;
            double C = L2.X * L1.Y - L1.X * L2.Y;

            double denom = Math.Sqrt(A * A + B * B);
            if (denom < EPS) return 0; // line suy biến

            return (A * P.X + B * P.Y + C) / denom;
        }

        // Chiếu vuông góc điểm P lên line vô hạn qua L1-L2
        private static Point2d ProjectPointToLine(Point2d P, Point2d L1, Point2d L2)
        {
            double dx = L2.X - L1.X;
            double dy = L2.Y - L1.Y;
            double len2 = dx * dx + dy * dy;

            if (len2 < EPS) return L1;

            double t = ((P.X - L1.X) * dx + (P.Y - L1.Y) * dy) / len2;
            return new Point2d(L1.X + t * dx, L1.Y + t * dy);
        }

        /// <summary>
        /// Khoảng cách ngắn nhất giữa segment AB và line vô hạn (L1-L2).
        /// Trả về distance >= 0 và 2 điểm gần nhất.
        /// </summary>
        public static double DistanceSegmentLine(Point2d A, Point2d B,Point2d L1, Point2d L2,out Point2d closestOnSegment,out Point2d closestOnLine)
        {
            closestOnSegment = default;
            closestOnLine = default;

            // line suy biến thành 1 điểm
            double ldx = L2.X - L1.X, ldy = L2.Y - L1.Y;
            if (ldx * ldx + ldy * ldy < EPS)
            {
                // distance segment -> point L1
                double vx = B.X - A.X, vy = B.Y - A.Y;
                double len2 = vx * vx + vy * vy;

                if (len2 < EPS)
                {
                    closestOnSegment = A;
                    closestOnLine = L1;
                    return Math.Sqrt((A.X - L1.X) * (A.X - L1.X) + (A.Y - L1.Y) * (A.Y - L1.Y));
                }

                double t = ((L1.X - A.X) * vx + (L1.Y - A.Y) * vy) / len2;
                if (t < 0) t = 0;
                else if (t > 1) t = 1;

                closestOnSegment = new Point2d(A.X + t * vx, A.Y + t * vy);
                closestOnLine = L1;

                double dx0 = closestOnSegment.X - L1.X;
                double dy0 = closestOnSegment.Y - L1.Y;
                return Math.Sqrt(dx0 * dx0 + dy0 * dy0);
            }

            // signed distances của A,B tới line
            double dA = SignedDistPointToLine(A, L1, L2);
            double dB = SignedDistPointToLine(B, L1, L2);

            // Nếu A hoặc B nằm trên line
            if (Math.Abs(dA) < EPS)
            {
                closestOnSegment = A;
                closestOnLine = A;
                return 0.0;
            }
            if (Math.Abs(dB) < EPS)
            {
                closestOnSegment = B;
                closestOnLine = B;
                return 0.0;
            }

            // Nếu segment cắt line (2 đầu khác phía)
            if (dA * dB < 0.0)
            {
                // nội suy giao điểm theo signed distance
                double t = dA / (dA - dB); // nằm trong (0,1)
                Point2d I = new Point2d(A.X + t * (B.X - A.X), A.Y + t * (B.Y - A.Y));

                closestOnSegment = I;
                closestOnLine = I;
                return 0.0;
            }

            // Không cắt => min ở endpoint
            if (Math.Abs(dA) <= Math.Abs(dB))
            {
                closestOnSegment = A;
                closestOnLine = ProjectPointToLine(A, L1, L2);
                return Math.Abs(dA);
            }
            else
            {
                closestOnSegment = B;
                closestOnLine = ProjectPointToLine(B, L1, L2);
                return Math.Abs(dB);
            }
        }

 

        private static double Dot(Point2d a, Point2d b) => a.X * b.X + a.Y * b.Y;
        private static double Cross(Point2d a, Point2d b) => a.X * b.Y - a.Y * b.X;

        private static double Distance(Point2d a, Point2d b)
        {
            double dx = a.X - b.X;
            double dy = a.Y - b.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        // Point -> Segment (trả về closest point)
        private static double DistancePoint2Segment(Point2d A, Point2d B, Point2d P, out Point2d closest)
        {
            Point2d AB = new Point2d(B.X - A.X, B.Y - A.Y);
            double len2 = Dot(AB, AB);

            if (len2 < EPS)
            {
                closest = A;
                return Distance(P, A);
            }

            Point2d AP = new Point2d(P.X - A.X, P.Y - A.Y);
            double t = Dot(AP, AB) / len2;

            if (t < 0) t = 0;
            else if (t > 1) t = 1;

            closest = new Point2d(A.X + t * AB.X, A.Y + t * AB.Y);
            return Distance(P, closest);
        }

        // Kiểm tra giao nhau (bao gồm chạm) của 2 segment
        private static bool SegmentsIntersect(Point2d A, Point2d B, Point2d C, Point2d D)
        {
            Point2d AB = new Point2d(B.X - A.X, B.Y - A.Y);
            Point2d AC = new Point2d(C.X - A.X, C.Y - A.Y);
            Point2d AD = new Point2d(D.X - A.X, D.Y - A.Y);

            Point2d CD = new Point2d(D.X - C.X, D.Y - C.Y);
            Point2d CA = new Point2d(A.X - C.X, A.Y - C.Y);
            Point2d CB = new Point2d(B.X - C.X, B.Y - C.Y);

            double c1 = Cross(AB, AC);
            double c2 = Cross(AB, AD);
            double c3 = Cross(CD, CA);
            double c4 = Cross(CD, CB);

            // General case
            if ((c1 > EPS && c2 < -EPS || c1 < -EPS && c2 > EPS) &&
                (c3 > EPS && c4 < -EPS || c3 < -EPS && c4 > EPS))
                return true;

            // Colinear / touching cases
            bool OnSegment(Point2d P, Point2d Q, Point2d R)
            {
                // Q nằm trên PR?
                return Math.Min(P.X, R.X) - EPS <= Q.X && Q.X <= Math.Max(P.X, R.X) + EPS &&
                       Math.Min(P.Y, R.Y) - EPS <= Q.Y && Q.Y <= Math.Max(P.Y, R.Y) + EPS &&
                       Math.Abs(Cross(new Point2d(Q.X - P.X, Q.Y - P.Y), new Point2d(R.X - P.X, R.Y - P.Y))) < 1e-9;
            }

            if (Math.Abs(c1) <= EPS && OnSegment(A, C, B)) return true;
            if (Math.Abs(c2) <= EPS && OnSegment(A, D, B)) return true;
            if (Math.Abs(c3) <= EPS && OnSegment(C, A, D)) return true;
            if (Math.Abs(c4) <= EPS && OnSegment(C, B, D)) return true;

            return false;
        }

        /// <summary>
        /// Khoảng cách ngắn nhất giữa segment AB và segment CD.
        /// Trả về distance >= 0.
        /// out pOnAB: điểm gần nhất trên AB
        /// out pOnCD: điểm gần nhất trên CD
        /// </summary>
        public static double DistanceSegmentSegment(Point2d A, Point2d B,Point2d C, Point2d D,out Point2d pOnAB,out Point2d pOnCD)
        {
            pOnAB = default;
            pOnCD = default;

            // Nếu giao nhau/chạm nhau => 0
            if (SegmentsIntersect(A, B, C, D))
            {
                // Lấy một điểm giao "xấp xỉ": dùng endpoint gần segment kia nhất
                // (đủ để debug; distance vẫn chính xác = 0)
                double da = DistancePoint2Segment(C, D, A, out var qa);
                double db = DistancePoint2Segment(C, D, B, out var qb);
                if (da <= db) { pOnAB = A; pOnCD = qa; }
                else { pOnAB = B; pOnCD = qb; }
                return 0.0;
            }

            // Không giao => min của 4 khoảng cách endpoint->segment
            double d1 = DistancePoint2Segment(C, D, A, out var q1); // A -> CD
            double d2 = DistancePoint2Segment(C, D, B, out var q2); // B -> CD
            double d3 = DistancePoint2Segment(A, B, C, out var q3); // C -> AB
            double d4 = DistancePoint2Segment(A, B, D, out var q4); // D -> AB

            double min = d1;
            pOnAB = A; pOnCD = q1;

            if (d2 < min) { min = d2; pOnAB = B; pOnCD = q2; }
            if (d3 < min) { min = d3; pOnAB = q3; pOnCD = C; }
            if (d4 < min) { min = d4; pOnAB = q4; pOnCD = D; }

            return min;
        }



        public override void Run(bool isEditMode = false)
        {
          
            inputImageInfo.Image = InputImage;

        
            if (inputImage != null)
                outputImageInfo.Image = InputImage;

            if (mode == E_mode.AnlgeLineLine && LineA != null && LineB != null)
            {
                AngleOut = (float)AngleLineLine(LineA.SP, LineA.EP, LineB.SP, LineB.EP);

            } else if (mode == E_mode.AnglePointPoint && PointA != null && PointB != null)
            {
                AngleOut = (float)AnglePointPoint(PointA.Point2d, PointB.Point2d);

            } else if (mode == E_mode.DistanceCircleCircle && CircleA != null && CircleB != null)
            {
                DistanceOut = (float)DistanceCircleCircle(CircleA.Center, CircleA.R, CircleB.Center, CircleB.R);
              
            } else if (mode == E_mode.DistanceLineCircle && LineA != null && CircleA != null)
            {
                DistanceOut = (float)DistanceCircleLine(LineA.SP, LineA.EP, CircleA.Center, CircleA.R);
            }else if(mode == E_mode.DistanceLineEllipse && LineA != null && EllipseA != null)
            {
                DistanceOut = (float)DistanceLineEllipse(LineA.SP,LineA.EP, EllipseA.Center2d, EllipseA.Width, EllipseA.Height,0);
            }else if(mode == E_mode.DistancePointCircle && PointA != null && CircleA != null)
            {
                DistanceOut = (float)DistancePointCircle(PointA.Point2d, CircleA.Center,(double)CircleA.R);
            }else if(mode == E_mode.DistancePointEllipse && PointA != null && EllipseA != null)
            {
                Point2d closePoint = new Point2d();
                DistanceOut = (float)DistancePointEllipse(PointA.Point2d, EllipseA.Center2d, EllipseA.Width,EllipseA.Height,0,out closePoint);
            }else if(mode == E_mode.DistancePointLine && PointA != null && LineA != null)
            {
                DistanceOut = (float)DistancePointLine(LineA.SP, LineA.EP, PointA.Point2d);
            }else if(mode == E_mode.DistancePointPoint && PointA != null && PointB != null)
            {
                DistanceOut = (float)DistancePointPoint(PointA.Point2d, PointB.Point2d);
            }else if(mode == E_mode.DistancePointSegment && LineA != null && PointA != null)
            {
                Point2d closePoint;
                DistanceOut = (float)DistancePointSegment(LineA.SP, LineA.EP, PointA.Point2d, out closePoint);
            }else if(mode == E_mode.DistanceSegmentCircle && LineA != null && CircleA != null)
            {
                Point2d closeSegment, closeCircle;
                DistanceOut = (float)DistanceSegmentCircle(LineA.SP, LineA.EP, CircleA.Center, CircleA.R, out closeSegment, out closeCircle);
            } else if(mode == E_mode.DistanceSegmentEllipse && LineA != null && EllipseA != null)
            {
                Point2d closeSegment, closeEllipse;
                DistanceOut = (float)DistanceSegmentEllipse(LineA.SP, LineA.EP, EllipseA.Center2d, EllipseA.Width, EllipseA.Height, 0, out closeSegment,out closeEllipse);
            }else if(mode == E_mode.DistanceSegmentLine && LineA != null && LineB != null)
            {
                Point2d closeSegment, closeLine;
                DistanceOut = (float)DistanceSegmentLine(LineA.SP, LineA.EP, LineB.SP, LineB.EP, out closeSegment, out closeLine);
            }else if(mode == E_mode.DistanceSegmentSegment && LineA != null && LineB != null)
            {
                Point2d closeSegmentA, closeSegmentB;
                DistanceOut = (float)DistanceSegmentSegment(LineA.SP, LineA.EP, LineB.SP, LineB.EP, out closeSegmentA, out closeSegmentB);
            }
            lastRunSuccess = true;
        }
    }
}
