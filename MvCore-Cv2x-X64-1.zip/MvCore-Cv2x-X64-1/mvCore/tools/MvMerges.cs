﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using OpenCvSharp;
using System.Drawing;
using System.Data.SqlTypes;
using log4net.Util;

namespace MvCore
{
    [Serializable] //khai báo serial lưu dữ liệu
    public class MvMerges : MvToolBase
    {
        public MvMerges()
        {

        }
        public MvMerges(SerializationInfo info, StreamingContext context) : base(info, context) { } //khai báo đọc dữ liệu

        public override void InitImageList()
        {
            //throw new NotImplementedException();
        }

        public override void InitInParmas()
        {
            //throw new NotImplementedException();
        }
        private int i0;
        private float[] i1;
        private float[] i2;
        private float[] i3;
        private float[] i4;
        private float[] i5;
        private float[] i6;
        private float[] i7;
        private float[] i8;
        private float[] i9;
        private string o0;

        [InputParam]
        public int I0
        {
            get { return i0; }
            set { i0 = value; }
        }
        [InputParam]
        public float[] I1
        {
            get { return i1; }
            set { i1 = value; }
        }

        [InputParam]
        public float[] I2
        {
            get { return i2; }
            set { i2 = value; }
        }

        [InputParam]
        public float[] I3
        {
            get { return i3; }
            set { i3 = value; }
        }
        [InputParam]
        public float[] I4
        {
            get { return i4; }
            set { i4 = value; }
        }

        [InputParam]
        public float[] I5
        {
            get { return i5; }
            set { i5 = value; }
        }

        [InputParam]
        public float[] I6
        {
            get { return i6; }
            set { i6 = value; }
        }
        [InputParam]
        public float[] I7
        {
            get { return i7; }
            set { i7 = value; }
        }

        [InputParam]
        public float[] I8
        {
            get { return i8; }
            set { i8 = value; }
        }

        [InputParam]
        public float[] I9
        {
            get { return i9; }
            set { i9 = value; }
        }


        [OutputParam]
        public String O0
        {
            get { return o0; }
            set { o0 = value; }
        }


        private int mode;

        public int Mode
        {
            get { return mode; }
            set { mode = value; }
        }
        private int _operator;

        public int _Operator
        {
            get { return _operator; }
            set { _operator = value; }
        }




        public override void InitOutParmas()
        {
            //do nothing this tool
            inParams.Add("I0", null);
            inParams.Add("I1", null);
            inParams.Add("I2", null);
            inParams.Add("I3", null);
            inParams.Add("I4", null);
            inParams.Add("I5", null);
            inParams.Add("I6", null);
            outParams.Add("O0", null);

        }

        public override void InitOutProperty()
        {
            //throw new NotImplementedException();
        }

        public override void Run(bool isEditMode = false)
        {
            GetInParams();
            string s_out = null;
            if (I1 == null) return;
            for (int i=0;i<I1.Length;i++)
            {
                s_out += "{";
                if (I1 != null && i< I1.Length && I1[i] != null) { s_out += $"{I1[i]},"; }
                if (I2 != null && i< I2.Length && I2[i] != null) { s_out += $"{I2[i]},"; }
                if (I3 != null && i< I3.Length && I3[i] != null) { s_out += $"{I3[i]},"; }
                if (I4 != null && i< I4.Length && I4[i] != null) { s_out += $"{I4[i]},"; }
                if (I5 != null && i< I5.Length && I5[i] != null) { s_out += $"{I5[i]},"; }
                if (I6 != null && i< I6.Length && I6[i] != null) { s_out += $"{I6[i]},"; }
                if (I7 != null && i< I7.Length && I7[i] != null) { s_out += $"{I7[i]},"; }
                if (I8 != null && i< I8.Length && I8[i] != null) { s_out += $"{I8[i]},"; }
                if (I9 != null && i< I9.Length && I9[i] != null) { s_out += $"{I9[i]},"; }
                s_out = s_out.TrimEnd(',');
                s_out += "}";
            }


            //for (int i = 0; i < inParams.Count(); i++)
            //{
            //    if (inParams[$"I{i}"]?.GetValue() != null)
            //        s_out += $"{inParams[$"I{i}"]?.GetValue()}";
            //    if (i < inParams.Count - 1)
            //        s_out += ",";
            //}
            s_out = $"{{{I0}{s_out}}}";
            O0 = s_out;
            Console.WriteLine("SvCalculator test output:  " + s_out);
            GetOutParams();
            lastRunSuccess = true;
        }
    }
}
