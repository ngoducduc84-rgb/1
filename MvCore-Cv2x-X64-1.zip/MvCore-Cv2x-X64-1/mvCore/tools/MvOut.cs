﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using OpenCvSharp;
using System.Drawing;
using System.Data.SqlTypes;

namespace MvCore
{
    [Serializable] //khai báo serial lưu dữ liệu
    public class MvOut : MvToolBase
    {
        public MvOut()
        {

        }
        public MvOut(SerializationInfo info, StreamingContext context) : base(info, context) { } //khai báo đọc dữ liệu

        public override void InitImageList()
        {
            //throw new NotImplementedException();
        }

        public override void InitInParmas()
        {
            //throw new NotImplementedException();
        }
        private int intOut;
        private float floatOut;
        private string stringOut;
        private bool boolOut;

        [OutputParam]
        public int IntOut
        {
            get { return intOut; }
            set { intOut = value; }
        }
        [OutputParam]
        public float FloatOut
        {
            get { return floatOut; }
            set { floatOut = value; }
        }
        [OutputParam]
        public String StringOut
        {
            get { return stringOut; }
            set { stringOut = value; }
        }
        [OutputParam]
        public bool BoolOut
        {
            get { return boolOut; }
            set { boolOut = value; }
        }


        public override void InitOutParmas()
        {
            //do nothing this tool
            outParams.Add("IntOut", null);
            outParams.Add("StringOut", null);

        }

        public override void InitOutProperty()
        {
            //throw new NotImplementedException();
        }

        public override void Run(bool isEditMode = false)
        {
            GetOutParams();
            lastRunSuccess = true;
        }
    }
}
