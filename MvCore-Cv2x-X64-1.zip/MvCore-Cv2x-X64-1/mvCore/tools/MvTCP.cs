﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using OpenCvSharp;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
namespace MvCore
{
    [field: NonSerialized]
    public delegate void reciverHandler(object sender, string data);
    [Serializable]
    public class MvTCP : MvToolBase
    {
        [field: NonSerialized]
        public event reciverHandler eventReciverHandler;
        public MvTCP()
        {
            IpAddress = Server.getIPAddress();
            Port = 8000;
            Mode = true;
        }
        public MvTCP(SerializationInfo info, StreamingContext context) : base(info, context) { } //khai báo đọc dữ liệu

        public override void InitImageList()
        {
            //throw new NotImplementedException();
        }

        public override void InitInParmas()
        {
            //throw new NotImplementedException();
        }
        [NonSerialized]
        public Server tcpServer;
        [NonSerialized]
        public Client tcpClient;


        [NonSerialized]
        private string receiver;

        private bool mode;
        public bool Mode
        {
            get { return mode; }
            set { mode = value; }
        }

        [NonSerialized]
        private bool testRunMode;

        public bool TestRunMode
        {
            get { return testRunMode; }
            set { testRunMode = value; }
        }


        private string ipAddress;
        //[InputParam]
        public string IpAddress
        {
            get { return ipAddress; }
            set { ipAddress = value; }
        }

        private int port;
        //[InputParam]
        public int Port
        {
            get { return port; }
            set { port = value; }
        }

        [OutputParam]
        public Server TCPServer
        {
            get { return tcpServer; }
            set { tcpServer = value; }
        }
        [OutputParam]
        public Client TCPClient
        {
            get { return tcpClient; }
            set { tcpClient = value; }
        }
        [OutputParam]
        public string Receiver
        {
            get { return receiver; }
            set { receiver = value; }
        }
        public override void InitOutParmas()
        {
            //do nothing this tool
            outParams.Add("TCPServer", null);
            //outParams.Add("TCPClient", null);
            outParams.Add("Receiver", null);

        }

        public override void InitOutProperty()
        {
            //throw new NotImplementedException();
        }

        public override void Run(bool isEditMode = false)
        {
            if (mode == true)
            {
                if (tcpServer == null)
                {
                    if (ipAddress == null)
                        tcpServer = new Server(port);
                    else
                        tcpServer = new Server(IpAddress, port);
                    tcpServer.ReciverEvent += Server_ReciverEvent; 
                }else
                {
                    TCPServer = tcpServer;
                }
               
            }
            else
            {
                if (tcpClient == null)
                {
                    if (ipAddress == null)
                        tcpClient = new Client(port);
                    else
                        tcpClient = new Client(IpAddress, port);
                    //tcpClient.Connect();
                    tcpClient.ReciverEvent += Client_ReciverEvent;
                    TCPClient = tcpClient;
                }
                else
                {
                    TCPClient = tcpClient;
                }
            }



            GetOutParams();
            lastRunSuccess = true;
        }

        private void Server_ReciverEvent(object sender, string Data)
        {
            Console.WriteLine(Data);
            Receiver = Data;
            GetOutParams();
            eventReciverHandler?.Invoke(sender, Data);

        }
        private void Client_ReciverEvent(object sender, string Data)
        {
            Console.WriteLine(Data);
            Receiver = Data;
            GetOutParams();
            eventReciverHandler?.Invoke(sender, Data);
        }
        public void sendData(String data)
        {
            if (tcpServer != null)
            {
                tcpServer.send(data);
            }
        }
    }
}
