﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using OpenCvSharp;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
namespace MvCore
{
    [Serializable]
    public class MvTCPSend : MvToolBase
    {

        public MvTCPSend()
        {
        }
        public MvTCPSend(SerializationInfo info, StreamingContext context) : base(info, context) { } //khai báo đọc dữ liệu

        public override void InitImageList()
        {
            //throw new NotImplementedException();
        }

        public override void InitInParmas()
        {
            //throw new NotImplementedException();
            inParams.Add("TCPServer", null);
            //inParams.Add("TCPClient", null);
            inParams.Add("DataSend", null);

        }


        private string dataSend;

        private Server tcpSerer;
        private Client tcpClient;



        [InputParam]
        public string DataSend
        {
            get { return dataSend; }
            set { dataSend = value; }
        }

        [InputParam]
        public Server TCPServer
        {
            get { return tcpSerer; }
            set { tcpSerer = value; }
        }
        [InputParam]
        public Client TCPClient
        {
            get { return tcpClient; }
            set { tcpClient = value; }
        }


        public override void InitOutParmas()
        {
            //do nothing this tool

        }

        public override void InitOutProperty()
        {
            //throw new NotImplementedException();
        }

        public override void Run(bool isEditMode = false)
        {

            GetInParams();
            if (TCPServer != null && dataSend != null)
            {
                TCPServer.send(dataSend);

            }
            else if (TCPClient != null && dataSend != null)
            {
                TCPClient.send(dataSend);
            }


            //GetOutParams();
            lastRunSuccess = true;
        }

    }
}
