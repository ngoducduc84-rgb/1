﻿using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;
//using MvCore.Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security;
using System.Security.Cryptography;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using ZXing.QrCode.Internal;
using static MvCore.MvTemplateMatchs;
using cv = OpenCvSharp;
using sys = System.Drawing;

namespace MvCore
{
    [Serializable]
    public class MvTemplateMatchs : MvToolBase
    {


        private MvRotationRectangle templateRegion;
        public MvRotationRectangle TemplateRegion
        {
            get { return templateRegion; }
            set { templateRegion = value; }
        }

        private MvRotationRectangle roiRegion;
        public MvRotationRectangle RoiRegion
        {
            get { return roiRegion; }
            set
            {
                roiRegion = value;
            }
        }


        Scalar whiteColor = new Scalar(255);
        Scalar grayColor = new Scalar(170);
        Scalar grayColor1 = new Scalar(85);
        Scalar blackColor = new Scalar(0);
        Scalar borderColor = new Scalar(0, 0, 0);
        public enum Direction
        {
            None, Left, Top, Right, Bottom
        }
        private bool regionMode;

        public bool RegionMode
        {
            get { return regionMode; }
            set { regionMode = value; }
        }

        public enum E_MatchMode
        {
            HEdge, HNNC, Template, Edge
        }
        public enum E_HalEdgeMode
        {
            interpolation, least_squares, least_squares_high
        }
        [NonSerialized]
        Mat m_desROI;
        Rect m_ROIrect;

        byte[] lut;
        public MvTemplateMatchs()
        {
            InputImage = new MvImage();
            refPoint = new MvPoint();
            m_desROI = new Mat();
            scaleFirst = 10;
            scaleLast = 2;
            angleNeg = 20;
            anglePos = 20;
            m_PCreteria = 0.75;
            m_precision = 0.02;
            m_firstStep = 5;
            MaxCount = 1;
            Priority = Direction.None;
            m_tempScaleMin = 1;
            m_tempScaleMax = 1;

            thLow = 50;
            thHigh = 150;
            AutoParam = true;
            if (Halcons == null)
                Halcons = new MvHalcon();
            halEdgeMode = E_HalEdgeMode.interpolation;
            pyramid = 5;
        }

        public MvTemplateMatchs(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            // 기존에 mPaaterDataList가 없을 경우 대비
            if (tempImg != null && mPatternDataList.Count == 0)
            {
                PatternData pattern = new PatternData(tempImg, Mask, refPoint);
                mPatternDataList.Add(new KeyValuePair<string, PatternData>("", pattern));
                mSelectedPatternIndex = 0;
            }
            if (Halcons == null)
                Halcons = new MvHalcon();
            m_AutoIndexNext = mSelectedPatternIndex;
        }

        int m_AutoIndexNext;

        #region InputValue

        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
        }

        [InputParam]
        public MvImage InputImage { get; set; }

        // scaleFirst
        double scaleFirst;
        public double ScaleFirst
        {
            get { return scaleFirst; }
            set
            {
                scaleFirst = value;
            }
        }
        //ScaleLast
        double scaleLast;
        public double ScaleLast
        {
            get { return scaleLast; }
            set
            {
                scaleLast = value;
            }
        }
        // - Deg
        int angleNeg;
        public int AngleNeg
        {
            get { return angleNeg; }
            set
            {
                angleNeg = value;
                if (Halcons != null)
                {
                    Halcons.AngleStart = value;
                }
            }
        }
        //+ Deg
        int anglePos;
        public int AnglePos
        {
            get { return anglePos; }
            set
            {
                anglePos = value;
                if (Halcons != null)
                {
                    Halcons.AngleEnd = value;
                }
            }
        }
        // Auto Matching Parameter
        bool autoParam;
        public bool AutoParam
        {
            get { return autoParam; }
            set { autoParam = value; }
        }

        MvImage tempImg;
        [OutputParam]
        public MvImage TemplateImage
        {
            get
            {
                return tempImg;
            }
            set
            {
                if (value == null) return;

                // 이미지 형식은 1채널로 통일
                MvImage temp = new MvImage(new Mat(value.Mat.Size(), MatType.CV_8UC1));
                if (value.Mat.Type() == MatType.CV_8UC3)
                    Cv2.CvtColor(value.Mat, temp.Mat, ColorConversion.RgbToGray);
                //Cv2.CvtColor(value.Mat, temp.Mat, ColorConversionCodes.RGB2GRAY);
                else if (value.Mat.Type() == MatType.CV_8UC1)
                    temp = value.Clone(true);
                else
                    return;

                if (tempImg != null)
                    tempImg.Dispose();

                tempImg = temp;
                mBorderColor = ((double)tempImg.Mat.Mean() + 255 / 2) % 255;
            }
        }

        double mBorderColor;
        //double BorderColor { get { if (useEdge) return 0; else return mBorderColor; } }
        double BorderColor { get { if (MatchMode == E_MatchMode.Edge) return 0; else return mBorderColor; } }

        MvMask mask;
        public MvMask Mask { get { return mask; } set { mask = value; } }

        [NonSerialized]
        Mat MaskedPattern;

        MvImage m_foundImage;
        [OutputParam]
        public MvImage FoundImage
        {
            get { return m_foundImage; }
            set
            {
                if (value == null) return;
                if (m_foundImage != null)
                    m_foundImage.Dispose();
                m_foundImage = value.Clone(true);
            }
        }

        MvPoint refPoint;
        public MvPoint RefPoint
        {
            get { return refPoint; }
            set { refPoint = value; }
        }

        double m_tempScaleMin;
        public double TempScaleMin
        {
            get { return m_tempScaleMin; }
            set { m_tempScaleMin = value; }
        }

        double m_tempScaleMax;
        public double TempScaleMax
        {
            get { return m_tempScaleMax; }
            set { m_tempScaleMax = value; }
        }

        double m_tempScaleX;
        double m_tempScaleY;
        double m_tempScaleXOld;
        double m_tempScaleYOld;


        //Score
        private double m_PCreteria;
        public double PCreteria
        {
            get { return m_PCreteria; }
            set { m_PCreteria = value; }
        }

        //Fist Step
        private double m_firstStep;
        public double FirstStep
        {
            get { return Math.Max(m_firstStep, m_precision); }
            set { m_firstStep = Math.Max(value, m_precision); }
        }

        //Precision
        private double m_precision;
        public double Precision
        {
            get { return m_precision; }
            set { m_precision = value; }
        }
        //MaxCount
        private int m_maxCount;
        public int MaxCount
        {
            get { return m_maxCount; }
            set
            {
                m_maxCount = value;
                if (Halcons != null)
                    halcons.MatchCount = value;
            }
        }
        //thresh Low
        private int thLow;
        public int THLow
        {
            get { return thLow; }
            set
            {
                thLow = value;
                if (Halcons != null)
                {
                    Halcons.ContrastMin = value;
                }
            }
        }
        //thresh High
        private int thHigh;
        public int THHigh
        {
            get { return thHigh; }
            set
            {
                thHigh = value;
                if (Halcons != null)
                {
                    Halcons.ContrastMax = value;
                }
            }
        }

        //Priority
        Direction priority;
        public Direction Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        //Match Mode
        E_MatchMode matchMode;
        public E_MatchMode MatchMode
        {
            get { return matchMode; }
            set
            {
                matchMode = value;
            }
        }

        private int pyramid;

        public int Pyramid
        {
            get { return pyramid; }
            set
            {
                pyramid = value;
                if (Halcons != null)
                    Halcons.pyramid = value;

            }
        }

        private E_HalEdgeMode halEdgeMode;

        public E_HalEdgeMode HalEdgeMode
        {
            get { return halEdgeMode; }
            set
            {
                halEdgeMode = value;
                if (Halcons != null)
                    Halcons.halEdgeMode = value.ToString();

            }
        }



        bool useEdge;
        public bool UseEdge
        {
            get { return useEdge; }
            set
            {
                useEdge = value;
                //Mask.DrawMask = value;
            }
        }

        //private MvHalcon halcon;

        //public MvHalcon Halcon
        //{
        //    get { return halcon; }
        //    set { halcon = value; }
        //}
        #endregion

        #region OutputValue
        public override void InitOutParmas()
        {
            outParams.Add("Score", null);
            outParams.Add("TranslateX", null);
            outParams.Add("TranslateY", null);
            outParams.Add("Rotation_Degree", null);
        }

        [OutputParam]
        public float[] TranslateX
        {
            get 
            {
                if (listResultBox == null || listResultBox.Count == 0)
                    return Array.Empty<float>();

                return listResultBox
                    .Select(r => (float)r.CP.X)
                    .ToArray();
            }
        }

        //public float TranslateX
        //{
        //    get { if (m_result == null) return float.NaN; return (float)m_result.Value.X; }
        //    set { }
        //}


        [OutputParam]
        public float[] TranslateY
        {
            get
            {
                if (listResultBox == null || listResultBox.Count == 0)
                    return Array.Empty<float>();

                return listResultBox
                    .Select(r => (float)r.CP.Y)
                    .ToArray();
            }
        }

        [OutputParam]
        public float[] Rotation
        {
            get
            {
                if (listResultBox == null || listResultBox.Count == 0)
                    return Array.Empty<float>();

                return listResultBox
                    .Select(r => (float)r.CP.Z)
                    .ToArray();
            }
        }

        [OutputParam]
        public float[] Rotation_Degree
        {
            get
            {
                if (listResultBox == null || listResultBox.Count == 0)
                    return Array.Empty<float>();

                return listResultBox
                    .Select(r => (float)(r.CP.Z*(180/Math.PI)))
                    .ToArray();
            }
        }

        [OutputParam]
        public float AdjustedScale
        {
            get { return (float)(m_tempScaleX + m_tempScaleY) / 2; }
            set { }
        }

        [OutputParam]
        public float AdjustedScaleX
        {
            get { return (float)m_tempScaleX; }
            set { }
        }

        [OutputParam]
        public float AdjustedScaleY
        {
            get { return (float)m_tempScaleY; }
            set { }
        }

        [OutputParam]
        public Point3d? Result
        {
            get { return m_result; }
            set
            {
                m_result = value;
            }
        }

        [OutputParam]
        public MvPoint SvPoint
        {
            get
            {
                if (m_result == null) return null;
                MvPoint result = new MvPoint(m_result.Value.X, m_result.Value.Y);
                result.ThetaRad = m_result.Value.Z;
                return result;
            }
            set
            {

            }
        }
        [NonSerialized]
        Point3d? m_result;
        //List<Point3d> listResultCP;

        [OutputParam]
        public Point3d ResultCP
        {
            get 
            {
                return resultCP; 
            }
            set
            {
                resultCP = value;
            }
        }
        [NonSerialized]
        Point3d resultCP;

        [NonSerialized]
        double m_score;
        [OutputParam]
        public double[] Score
        {
            get
            {
                if (listResultBox == null || listResultBox.Count == 0)
                    return Array.Empty<double>();

                return listResultBox
                    .Select(r => (double)r.Score)
                    .ToArray();
            }
            //set
            //{
            //    m_score = value;
            //}
        }

        [NonSerialized]
        Point2d[] m_resultBox;
        [NonSerialized]
       public List<FoundResult> listResultBox;
        //List<List<OpenCvSharp.CPlusPlus.Point>> l_Contours = new List<List<OpenCvSharp.CPlusPlus.Point>>();

        public FoundResult failResultBox;

        [OutputParam]
        public Point2d[] ResultBox
        {
            get { return m_resultBox; }
            set { m_resultBox = value; }
        }

        [Serializable]
        public class FoundResult
        {
            public double Score;
            public Point3d CP;
            public Point2d[] Box;
            public OpenCvSharp.CPlusPlus.Point[][] contours;

            public FoundResult(double S, Point3d cp, Point2d[] box)
            {
                Score = S;
                CP = cp;
                Box = box;
            }
            public FoundResult(double S, Point3d cp, Point2d[] box, OpenCvSharp.CPlusPlus.Point[][] _contours)
            {
                Score = S;
                CP = cp;
                Box = box;
                this.contours = _contours;
            }
        }

        [NonSerialized]
        Mat listScale;

        #endregion

        SvImageInfo inputImageInfo;
        SvImageInfo outputImageInfo;

        [NonSerialized]
        double m_SearchScale;
        [NonSerialized]
        int m_iFindCount;
        [NonSerialized]
        int m_iteration;

        bool m_IsAutoIndex;

        // autoIndex
        public bool IsAutoIndex
        {
            get { return m_IsAutoIndex; }
            set
            {
                if (m_IsAutoIndex == value) return;
                m_IsAutoIndex = value;
                if (!value) m_AutoIndexNext = mSelectedPatternIndex;
            }
        }

        [NonSerialized]
        Mat m_sclSrc;
        [NonSerialized]
        Mat m_sclTemp;
        [NonSerialized]
        Mat m_scaledMask;
        [NonSerialized]
        List<Mat> m_listC = new List<Mat>();

        OpenCvSharp.MatchTemplateMethod MatchMethod;
        //TemplateMatchModes MatchMethod;

        public List<KeyValuePair<string, PatternData>> mPatternDataList = new List<KeyValuePair<string, PatternData>>();


        private MvHalcon halcons;

        public MvHalcon Halcons
        {
            get { return halcons; }
            set { halcons = value; }
        }


        int mSelectedPatternIndex = -1;
        public int SelectedPatternIndex
        {
            get { return mSelectedPatternIndex; }
            set
            {
                if (mSelectedPatternIndex == value) return;
                mSelectedPatternIndex = value;
                m_AutoIndexNext = value;
                NotifyPropertyChanged("SelectedPatternIndex");
            }
        }
        public void train()
        {
            Mat temMask;
            if (mPatternDataList.Count == 0) { return; }
            if (mPatternDataList[0].Value.MaskedPattern == null)
                temMask = mPatternDataList[0].Value.PatternImage.Mat;
            else
                temMask = mPatternDataList[0].Value.MaskedPattern;
            //Cv2.ImShow("temMask", temMask); Cv2.WaitKey(3000);
            int mode;
            if (MatchMode == E_MatchMode.HEdge)
                mode = 0;
            else
                mode = 1;
            Halcons = new MvHalcon((double)AngleNeg, (double)AnglePos, Pyramid, halEdgeMode.ToString(), THLow, THHigh, mode, MaxCount, temMask);
        }
        public void DrawResult(MvCore.Display.MvDisplayView display)
        {
            if (InputImage == null || InputImage.Width == 0 || InputImage.Height == 0) return;

            System.Drawing.Font f = new System.Drawing.Font("굴림체", 10, System.Drawing.FontStyle.Bold);
            System.Drawing.SolidBrush SB;
            Point2d P0 = new Point2d(0, 0);
            Point2d P1, P2;
            string tmp = null;

            Rect schROI = InputImage.RegionRect.Rect;
            OpenCvSharp.CPlusPlus.Point rightbottom = schROI.Location + new OpenCvSharp.CPlusPlus.Point(schROI.Size.Width - 1, schROI.Size.Height - 1);
            display.DrawRectangle(new System.Drawing.Pen(System.Drawing.Color.Pink, 1), MvFunc.ImageToFixture2D(schROI.Location, InputImage.TransformMat), MvFunc.ImageToFixture2D(rightbottom, InputImage.TransformMat));

            //if (m_score < m_PCreteria || listResultBox.Count == 0)
            //{
            //    if (failResultBox == null)
            //        return;
            //    SB = new System.Drawing.SolidBrush(System.Drawing.Color.Red);

            //    display.DrawPolyLines(new System.Drawing.Pen(System.Drawing.Color.Red, 1), failResultBox.Box);
            //    tmp = string.Format("P : ({0:F3}, {1:F3})\n\rT : {2:F3}deg\n\rScore : {3:F3}", failResultBox.CP.X, failResultBox.CP.Y, failResultBox.CP.Z * 180f / Math.PI, Score);
            //    P0 = new Point2d(failResultBox.CP.X, failResultBox.CP.Y);
            //    display.DrawString(tmp, f, SB, P0 + new Point2d(10, 10));
            //    return;
            //}

            //if (m_resultBox == null) return;
            //if (listResultBox.Count == 0) return;





            SB = new System.Drawing.SolidBrush(System.Drawing.Color.Lime);
          
            // 찾은 결과 표시
            for (int i = 0; i < listResultBox.Count; i++)
            {
                Point3d CP = listResultBox[i].CP;
                double angle = CP.Z * (180 / Math.PI);
                P0 = new Point2d(CP.X, CP.Y);
                P1 = P0 + MvFunc.Rotate(new Point2d(display.Width / 4, 0),CP.Z);
                P2 = P0 + MvFunc.Rotate(new Point2d(0, display.Width / 4),CP.Z);
                display.DrawArrow(new System.Drawing.Pen(System.Drawing.Color.Red, 1), P0, P1, 10);
                display.DrawArrow(new System.Drawing.Pen(System.Drawing.Color.Green, 1), P0, P2, 10);
                display.DrawPolyLines(new System.Drawing.Pen(System.Drawing.Color.YellowGreen, 1), listResultBox[i].Box);
                tmp = string.Format("P{0}: ({1:F3}, {2:F3})\n\rR : {3:F3}deg\n\rScore : {4:F3}", i, CP.X,CP.Y, angle, listResultBox[i].Score);
                display.DrawString(tmp, f, SB, P0 + new Point2d(10, 10));
                tmp = string.Format("Finding Count : {0}\n\rAdjust Scale : {1:F3}, {2:F3}", listResultBox.Count, m_tempScaleX, m_tempScaleY);
                display.DrawString(tmp, f, SB, new System.Drawing.PointF(InputImage.Width * 0.5f, 5));

                display.DrawCross(System.Drawing.Pens.Green, new Point2d(CP.X,CP.Y), 100, 100, CP.Z * 180f / Math.PI);

                
                if (UseEdge && matchMode == E_MatchMode.HEdge)
                    display.DrawEdge(listResultBox[i].contours, InputImage.Mat.Clone());
            }
        }

        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            outputImageInfo = new SvImageInfo(string.Format("[{0}] OutputImage", this.ToString()));

            outputImageInfo.drawingFunc = DrawResult;

            imageList.Add(inputImageInfo);
            imageList.Add(outputImageInfo);
        }

        public override void InitOutProperty()
        {
            lastRunSuccess = false;
            //Score[0] = 0.0;
            Result = new Point3d(0, 0, 0);
            ResultCP = new Point3d(0, 0, 0);
            ResultBox = null;
            failResultBox = null;
            m_result = null;

            if (FoundImage != null) FoundImage.Dispose();
            FoundImage = null;

            listResultBox = new List<FoundResult>();
            m_tempScaleXOld = 0;
            m_tempScaleYOld = 0;
            if (matchMode == E_MatchMode.Edge)
                MatchMethod = OpenCvSharp.MatchTemplateMethod.CCoeffNormed;
            else
                MatchMethod = OpenCvSharp.MatchTemplateMethod.CCoeffNormed;
            m_SearchScale = 0;
            GetOutParams();
        }

        //[DllImport("Dll/Core.dll", CallingConvention = CallingConvention.Cdecl)]
        //public static extern int AddNumbers(int a, int b);
        #region Match Base
        [StructLayout(LayoutKind.Sequential)]
        public struct DPoint
        {
            public double x;
            public double y;
            public DPoint(double x, double y)
            {
                this.x = x;
                this.y = y;
            }

            //DPoint a = new DPoint(6,8);
            //DPoint b = new DPoint(1,3);
            //OpenCvSharp.Point c = new OpenCvSharp.Point(3,2);
            //System.Drawing.Point d = new System.Drawing.Point(6,9);
            public static DPoint operator +(DPoint a, DPoint b) => new DPoint(a.x + b.x, a.y + b.y);  //a += b
            public static DPoint operator -(DPoint a, DPoint b) => new DPoint(a.x - b.x, a.y - b.y); //a = a - b
            public static DPoint operator *(DPoint a, DPoint b) => new DPoint(a.x * b.x, a.y * b.y);  //a *= b
            public static DPoint operator /(DPoint a, DPoint b) => new DPoint(a.x / b.x, a.y / b.y); // a = a / b
            public static implicit operator DPoint(OpenCvSharp.CPlusPlus.Point a) => new DPoint(a.X, a.Y); //a = c
            public static implicit operator DPoint(OpenCvSharp.CPlusPlus.Point2d a) => new DPoint(a.X, a.Y);
            public static explicit operator DPoint(System.Drawing.Point a) => new DPoint(a.X, a.Y); //a = (System.Drawing.Point)d
            public static implicit operator OpenCvSharp.CPlusPlus.Point(DPoint p)
            {
                return new OpenCvSharp.CPlusPlus.Point((int)p.x, (int)p.y);
            }

            public static DPoint RotatePoint(DPoint p, DPoint center, double angleDeg)
            {
                double angle = angleDeg * Math.PI / 180.0;

                double cos = Math.Cos(angle);
                double sin = Math.Sin(angle);

                double dx = p.x - center.x;
                double dy = p.y - center.y;

                double rx = dx * cos - dy * sin + center.x;
                double ry = dx * sin + dy * cos + center.y;

                return new DPoint(rx, ry);
            }
        }
        public struct PointInfo
        {

            public DPoint Point;
            public DPoint Center;
            public DPoint Offset;
            public DPoint Derivative;
            public double Magnitude;
            public double Direction;
            public double Angle;
            public void Update(DPoint _center)
            {
                Center = _center;
                Offset = Point - _center;
            }
        };

        [StructLayout(LayoutKind.Sequential)]
        public struct matchResult
        {
            public double x;
            public double y;
            public double score;
            public double angle;
            public matchResult(double x, double y, double score, double angle)
            {
                this.x = x;
                this.y = y;
                this.score = score;
                this.angle = angle;
            }
            //public int contourCount;
            //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 10000)]
            //public DPoint[] contours;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct ImageBuffer
        {
            public IntPtr data;
            public int width;
            public int height;
            public int channels;
        }

        public static ImageBuffer Mat2Image(Mat mat)
        {
            ImageBuffer buf = new ImageBuffer();
            buf.data = mat.Data;       // pointer tới pixel Mat
            buf.width = mat.Cols;       // số cột (W)
            buf.height = mat.Rows;       // số dòng (H)
            buf.channels = mat.Channels(); // CV_8UC3 → 3, CV_8UC1 → 1

            return buf;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct myPoint
        {
            double _X;
            double _y;
            double _r;
            double core;
            public myPoint(int x, int y) { _X = x; _y = y; _r = 0; core = 0; }
            public static implicit operator myPoint(OpenCvSharp.CPlusPlus.Point a) => new myPoint(a.X, a.Y);
            /*char z[32];
            int k;
            char h[32];*/
        };
        Mat ToGray(Mat input)
        {
            Mat gray = new Mat();

            int ch = input.Channels();

            if (ch == 3)
            {
                Cv2.CvtColor(input, gray, ColorConversion.RgbToGray);
            }
            else if (ch == 4)
            {
                Cv2.CvtColor(input, gray, ColorConversion.BgraToGray);
            }
            else if (ch == 1)
            {
                gray = input.Clone();  // đã là grayscale rồi
            }
            else
            {
                throw new Exception("Unsupported channel count: " + ch);
            }

            return gray;
        }
        public static Point2d[] OriginBox(Point3d center, double width, double height)
        {
            double cx = center.X;
            double cy = center.Y;
            double theta = center.Z;  // radian

            double w2 = width / 2.0;
            double h2 = height / 2.0;

            // 4 góc template (relative)
            Point2d[] box = new Point2d[4];
            Point2d[] pts = new Point2d[]
            {
        new Point2d(-w2, -h2),
        new Point2d(+w2, -h2),
        new Point2d(+w2, +h2),
        new Point2d(-w2, +h2)
            };

            for (int i = 0; i < 4; i++)
            {
                double x = pts[i].X;
                double y = pts[i].Y;

                double xr = x * Math.Cos(theta) - y * Math.Sin(theta) + cx;
                double yr = x * Math.Sin(theta) + y * Math.Cos(theta) + cy;

                box[i] = new Point2d(xr, yr);
            }

            return box;
        }
        [DllImport("OpenCvCore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void FreeContours(IntPtr ptr);
        [DllImport("OpenCvCore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void FreeMemory(IntPtr ptr);

        //[DllImport("OpenCvCore.dll", CallingConvention = CallingConvention.Cdecl)]
        //public static extern IntPtr MatchEdge(ref ImageBuffer img, ref ImageBuffer tem, ref matchResult result, out int count, int threshMin, int threshMax, double angleMin, double angleMax);
        //[DllImport("OpenCvCore.dll", CallingConvention = CallingConvention.Cdecl)]
        //public static extern void MatchEdge(ref ImageBuffer img, ref ImageBuffer tem, ref matchResult result, out IntPtr points,out IntPtr sizes,out int contourCount,out int totalPoints, int threshMin, int threshMax, double angleMin, double angleMax);
        [DllImport("OpenCvCore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void MatchEdge(
    ref ImageBuffer img,
    ref ImageBuffer tem,
    ref matchResult result,
    out IntPtr points,        // DPoint**
    out IntPtr sizes,         // int**
    out int contourCount,     // int*
    out int totalPoints,      // int*
    int threshMin,
    int threshMax,
    double angleMin,
    double angleMax
);
        [DllImport("OpenCvCore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void TemplateMatch(
    ref ImageBuffer img,
    ref ImageBuffer tem,
    ref matchResult result,
    //,out IntPtr points,        // DPoint**
    //out IntPtr sizes,         // int**
    //out int contourCount,     // int*
    //out int totalPoints,      // int*
    int threshMin,
    int threshMax,
    double angleMin,
    double angleMax
);

        #endregion

        public override void Run(bool isEditMode = false)
        {
            #region begin run

            //int result = AddNumbers(5, 7);
            //Console.WriteLine("Kết quả: " + result);
            DateTime TemplateMatchRunTime = DateTime.Now;
            listResultBox.Clear();
            inputImageInfo.Image = InputImage;
            outputImageInfo.Image = InputImage;
            //20200604 HNB
            outputImageInfo.Image = InputImage;
            SelectedPatternIndex = m_AutoIndexNext;
            if (mPatternDataList.Count <= mSelectedPatternIndex)
                return;

            if (!PatternChange())
            {
                string error = "[" + this.GetType().Name + "] Pattern Index is Wrong!";
                Console.WriteLine(error);
                return;
            }

            if (m_IsAutoIndex)
                m_AutoIndexNext = (m_AutoIndexNext + 1) % mPatternDataList.Count;

            if (InputImage == null) return;
            if (InputImage.Mat.Channels() == 3)
            {
                MessageBox.Show("InputImage Channel is three(Color)!", "Inform", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            Rect m_searchROI;
            if (RegionMode == true)
            {
                m_searchROI = InputImage.RegionRect.Rect;
            }
            else
            {
                m_searchROI = new Rect((OpenCvSharp.CPlusPlus.Point)roiRegion.Location, new OpenCvSharp.CPlusPlus.Size(roiRegion.Width, roiRegion.Height));
            }
            if (tempImg == null) return;

            if (m_searchROI == null)
                m_searchROI = new Rect(new OpenCvSharp.CPlusPlus.Point(0, 0), InputImage.Mat.Size());

            if (m_searchROI.Width == 0 || m_searchROI.Height == 0) m_searchROI = new Rect(new OpenCvSharp.CPlusPlus.Point(), InputImage.Mat.Size());

            //m_searchROI.Location = m_searchROI.Location;// SvFunc.FixtureToImage2D(m_searchROI.Location, InputImage.TransformMat);

            if (InputImage.Width < tempImg.Width || InputImage.Height < tempImg.Height) return;

            Point3d resultCenter = new Point3d();
            //Console.WriteLine($"[Mat @616] Size={InputImage.Mat.Width}x{InputImage.Mat.Height}, Step={InputImage.Mat.Step()}, Cont={InputImage.Mat.IsContinuous()}, Sub={InputImage.Mat.IsSubmatrix()}, Type={InputImage.Mat.Type()}");
            Mat des = InputImage.Mat.Clone(); //error

            if (m_searchROI.Width < tempImg.Width || m_searchROI.Height < tempImg.Height) return;
            if (0 > m_searchROI.X || 0 > m_searchROI.Width || m_searchROI.X + m_searchROI.Width > des.Width || 0 > m_searchROI.Y || 0 > m_searchROI.Height || m_searchROI.Y + m_searchROI.Height > des.Height)
            {
                if (m_searchROI.X + m_searchROI.Width > des.Width)
                {
                    m_searchROI.Width = des.Width - m_searchROI.X - 1;
                }
                if (m_searchROI.Y + m_searchROI.Height > des.Height)
                {
                    m_searchROI.Height = des.Height - m_searchROI.Y - 1;
                }
                if (0 > m_searchROI.X)
                {
                    m_searchROI.X = 0;
                }
                if (0 > m_searchROI.Y)
                {
                    m_searchROI.Y = 0;
                }
                if (0 > m_searchROI.X || 0 > m_searchROI.Width || m_searchROI.X + m_searchROI.Width > des.Width || 0 > m_searchROI.Y || 0 > m_searchROI.Height || m_searchROI.Y + m_searchROI.Height > des.Height)
                { Console.WriteLine("ROI Out Range!"); return; }
            }
            //if (m_searchROI.X + m_searchROI.Width > InputImage.Mat.Width) { m_searchROI.Width = InputImage.Mat.Width - m_searchROI.X; }
            //if (m_searchROI.Y + m_searchROI.Height > InputImage.Mat.Height) { m_searchROI.Height = InputImage.Mat.Height - m_searchROI.Y; }
            m_ROIrect = new Rect(m_searchROI.X, m_searchROI.Y, m_searchROI.Width - tempImg.Width, m_searchROI.Height - tempImg.Height);
            //Mat desROI = des[m_searchROI];
            //m_desROI = desROI.Clone();

            // While (Score > Pcriteria)
            // 0. ROI = Total Image Rect -> Scaled RotTempMatching
            // 1. ROI = 1Result * 2 -> Not Scaled RotTempMatching
            Point2d[] resultbox = new Point2d[4];
            Rect ROI = new Rect();

            double degStep = 0.0;
            double degRange = 0.0;
            double startT = 0.0;
            double S = 0.0;
            double score = 0.0;
            double margin = 1.1;
            double templW, templH;
            FoundResult sResult;
            List<FoundResult> adjustobserver = new List<FoundResult>();

            if (AutoParam)
            {
                double templimitsize = 50;
                scaleFirst = 10;

                if (tempImg.Width < templimitsize || tempImg.Height < templimitsize)
                    scaleFirst = 1;

                scaleLast = Math.Max(ScaleFirst / 8, 1);

                m_firstStep = 5;
                m_precision = 0.02;
                angleNeg = anglePos = 20;
                NotifyPropertyChanged();
            }

            Point2d[] box = new Point2d[4];
            m_listC = new List<Mat>();

            DateTime dt;

            m_tempScaleX = m_tempScaleY = Math.Round((TempScaleMin + TempScaleMax) / 2);
            if (m_searchROI.X + m_searchROI.Width > des.Width)
            {
                m_searchROI = new Rect(m_searchROI.X, m_searchROI.Y, des.Width - m_searchROI.X, m_searchROI.Height);
            }
            if (m_searchROI.Y + m_searchROI.Height > des.Height)
            {
                m_searchROI = new Rect(m_searchROI.X, m_searchROI.Y, m_searchROI.Width, des.Height - m_searchROI.Y);
            }
            Mat srcGray = ToGray(new Mat(des, m_searchROI).Clone());

            if (mPatternDataList.Count == 0) { return; }
            Mat temMask;
            if (mPatternDataList[0].Value.MaskedPattern == null || mPatternDataList[0].Value.MaskedPattern.Height == 0 || mPatternDataList[0].Value.MaskedPattern.Width == 0)
                temMask = mPatternDataList[0].Value.PatternImage.Mat;
            else
                temMask = mPatternDataList[0].Value.MaskedPattern;
            Mat dstGray = ToGray(temMask.Clone());
            //Mat dstGray = ToGray(tempImg.Mat.Clone());
            //Cv2.ImShow("Mask", dstGray); Cv2.WaitKey(3000);
            DateTime start = DateTime.Now;
            int count;
            int contourCount = 0, totalPoints = 0;
            #endregion

            switch (MatchMode)
            {
                case E_MatchMode.Edge:
                case E_MatchMode.Template:


                    for (m_iFindCount = 0; m_iFindCount < MaxCount; m_iFindCount++)
                    {
                        dt = DateTime.Now;
                        // S = 1/Scale until step == 0.5deg

                        // Adjust scale
                        List<Point2d> list_scaletoscore = new List<Point2d>();
                        double adjustgoodscore = -1;
                        double adjustgoodscale = -1;
                        int adjustgoodstep = 0;
                        Point3d adjustgoolcenter = new Point3d();
                        double adjustgoodrange = 0;

                        double adjustscalestep = Math.Min(0.05, (m_tempScaleMax - m_tempScaleMin) / 2);
                        int adjuststep = 0;

                        for (double adjustscale = m_tempScaleMin; adjustscale <= m_tempScaleMax; adjustscale += adjustscalestep, adjuststep += 1)
                        {
                            if (m_iFindCount == 0)
                            {
                                templW = Math.Round(tempImg.Width * adjustscale);
                                templH = Math.Round(tempImg.Height * adjustscale);
                                m_tempScaleX = adjustscale;
                                m_tempScaleY = adjustscale;
                            }
                            else // 두번째 부터는 처음에 찾은 m_tempScale을 적용한다. 
                            {
                                templW = Math.Round(tempImg.Width * AdjustedScale);
                                templH = Math.Round(tempImg.Height * AdjustedScale);
                            }

                            S = 1.0 / ScaleFirst;

                            degRange = angleNeg + anglePos;
                            degStep = Math.Max(m_firstStep, m_precision);

                            startT = (anglePos - angleNeg) / 2;
                            ROI = new Rect(m_searchROI.Location, m_searchROI.Size);// new Rect(new Point(0, 0), desROI.Size());
                            margin = 1.1;

                            // 1. Iteration
                            m_iteration = 0;

                            double oldstartT;
                            do
                            {
                                oldstartT = startT;
                                score = RotTempMatching(des, tempImg.Mat, ROI, startT, degRange, degStep, S, out resultCenter, out resultbox, margin);
                                //Console.WriteLine($"Start: {startT}, degRange: {degRange}, degStep: {degStep},S: {S},marginL: {margin}");
                                //Console.WriteLine($"Score: {score} {resultCenter}");
                                ROI = new Rect((int)Math.Round(resultCenter.X - templW / 2), (int)Math.Round(resultCenter.Y - templH / 2), (int)Math.Round(templW), (int)Math.Round(templH));
                                m_iteration += 1;

                                // 처음의 경우 degStep으로 판단해야 해서...
                                degRange = Math.Min(degStep, degRange / 2);
                                degStep = Math.Max(degRange / 2, m_precision);
                                startT = resultCenter.Z * 180.0 / Math.PI;
                                if (Math.Abs(oldstartT - startT) < m_precision && m_iteration > 1)
                                {
                                    //degRange = Math.Max(Math.Abs(oldstartT - startT) * 2, 0.02);
                                    degRange = m_precision * 2;
                                    break;
                                }
                                margin = 1.1;
                                S *= 2;
                                if (S < 0.2) S = 0.2;
                                if (S > 1 / ScaleLast) S = 1 / ScaleLast;
                                if (m_iteration == 3) break;
                            }
                            while (degStep > m_precision);

                            // 찾은 결과는 List에 저장
                            list_scaletoscore.Add(new Point2d(adjustscale, score));
                            adjustobserver.Add(new FoundResult(score, resultCenter, resultbox));
                            if (adjustgoodscore < score)
                            {
                                adjustgoodscore = score;
                                adjustgoodscale = adjustscale;
                                adjustgoodstep = adjuststep;
                                adjustgoolcenter = resultCenter;
                                adjustgoodrange = degRange;
                            }

                            // 이건 훗날 메모리 vs 속도 향상을 좀 고민해야함...
                            // 속도 향상을 위해서는 이게 RotTemplateMatch 안에 들어가 있어야될 듯
                            // 
                            if (m_iFindCount == 0 && adjustscalestep > 0) // scale 옵션이 없으면 그냥 건너뛰자. 그래야 m_listC가 남아있다.
                            {
                                for (int i = 0; i < m_listC.Count; i++) m_listC[i].Dispose();
                                m_listC.Clear();
                            }
                            else
                                break;
                        }

                        MvFunc.TimeWatch(dt, m_iFindCount.ToString() + " Finding");

                        //////////////////////////////////// Adjust Scale
                        if (m_iFindCount == 0 && adjustscalestep > 0)
                        {
                            double oldscale = adjustgoodscale;
                            Point3d maxcenter = resultCenter;
                            double maxscore = adjustgoodscore;
                            double maxscale = adjustgoodscale;

                            degRange = angleNeg + anglePos;
                            degStep = Math.Max(m_firstStep, m_precision);
                            startT = (anglePos - angleNeg) / 2;

                            for (int i = 0; i < 4; i++)
                            {
                                for (int j = 0; j < m_listC.Count; i++) m_listC[i].Dispose();
                                m_listC.Clear();

                                adjustgoodstep = list_scaletoscore.FindIndex(a => a.Y == maxscore);
                                Point2d adjustresult = CalSubValue(list_scaletoscore, adjustgoodstep);
                                adjustgoodscale = adjustresult.X;

                                templW = Math.Round(tempImg.Width * adjustgoodscale);
                                templH = Math.Round(tempImg.Height * adjustgoodscale);
                                ROI = new Rect((int)Math.Round(maxcenter.X - templW / 2), (int)Math.Round(maxcenter.Y - templH / 2), (int)Math.Round(templW), (int)Math.Round(templH));
                                degStep = Math.Max(adjustgoodrange / 2, m_precision);

                                m_tempScaleX = m_tempScaleY = adjustgoodscale;
                                score = RotTempMatching(des, tempImg.Mat, ROI, startT, degRange, degStep, S, out adjustgoolcenter, out resultbox, margin);
                                //Console.WriteLine($"Start: {startT}, degRange: {degRange}, degStep: {degStep},S: {S},marginL: {margin}");
                                //Console.WriteLine($"Score: {score} {resultCenter}");
                                if (score > maxscore)
                                {
                                    maxscore = score;
                                    maxscale = adjustgoodscale;
                                    maxcenter = adjustgoolcenter;
                                }
                                else
                                {
                                    m_tempScaleX = m_tempScaleY = list_scaletoscore[adjustgoodstep].X;
                                }

                                list_scaletoscore.Add(new Point2d(adjustgoodscale, score));
                                list_scaletoscore.Sort((x1, x2) => x1.X < x2.X ? -1 : 1);

                                oldscale = adjustgoodscale;

                                // 더이상 score 변화가 없으면 탈출~
                                if (Math.Abs(oldscale - adjustgoodscale) < 0.005) break;
                            }
                        }

                        resultCenter = adjustgoolcenter;
                        degRange = adjustgoodrange;

                        #region adjust X,Y scale
                        //////////////////////////////////// Adjust X,Y Scale
                        //dt = DateTime.Now;
                        //double maxScore;
                        //if (m_iFindCount == 0 && TempScaleMax != TempScaleMin && score < 0.9)
                        //{
                        //    templW = Cv.Round(tempImg.Width * m_tempScaleMax);
                        //    templH = Cv.Round(tempImg.Height * m_tempScaleMax);
                        //    ROI = new Rect(Cv.Round(resultCenter.X - templW / 2), Cv.Round(resultCenter.Y - templH / 2), Cv.Round(templW), Cv.Round(templH));
                        //    margin = 1.1;

                        //    int maxX = 0; int maxY = 0;
                        //    double scalestep = Math.Min(0.1, (m_tempScaleMax - m_tempScaleMin) / 2);
                        //    int capacity = Cv.Round(m_tempScaleMax / scalestep) + 1;
                        //    listScale = new Mat(capacity, capacity, MatType.CV_64FC1, -1);
                        //    maxScore = 0;
                        //    Point3d resultcp = new Point3d();

                        //    Queue<Point> Q = new Queue<Point>();
                        //    int[] dx = new int[4] { 0, 1, 0, -1 };
                        //    int[] dy = new int[4] { 1, 0, -1, 0 };

                        //    //for (double scaleX = m_tempScaleMin; scaleX <= m_tempScaleMax; scaleX += m_tempScaleMax - m_tempScaleMin)
                        //    //{
                        //    //    for (double scaleY = m_tempScaleMin; scaleY <= m_tempScaleMax; scaleY += m_tempScaleMax - m_tempScaleMin)
                        //    //    {
                        //    double scaleX = (m_tempScaleMax + m_tempScaleMin) / 2;
                        //    double scaleY = (m_tempScaleMax + m_tempScaleMin) / 2;
                        //    int inX = Cv.Round(scaleX / scalestep);
                        //    int inY = Cv.Round(scaleY / scalestep);
                        //    m_tempScaleX = inX * scalestep;
                        //    m_tempScaleY = inY * scalestep;
                        //    score = RotTempMatching(des, tempImg.Mat, ROI, startT, 0, degStep, S, out resultCenter, out resultbox, margin);
                        //    listScale.Set<double>(inY, inX, score);
                        //    Q.Enqueue(new Point(inX, inY));
                        //    maxScore = score;
                        //    resultcp = resultCenter;
                        //    for (int ii = 0; ii < 4; ii++)
                        //    {
                        //        box[ii] = resultbox[ii];
                        //    }
                        //    maxX = inX;
                        //    maxY = inY;
                        //    //    }
                        //    //}

                        //    while(Q.Count > 0)
                        //    {
                        //        Point P = Q.Dequeue();
                        //        int X, Y;
                        //        for (int i = 0; i < 4; i++)
                        //        {
                        //            X = P.X + dx[i];
                        //            Y = P.Y + dy[i];
                        //            if (listScale.At<double>(Y, X) != -1)
                        //                continue;
                        //            if (X < Cv.Round(m_tempScaleMin / scalestep) || X > Cv.Round(m_tempScaleMax / scalestep))
                        //                continue;
                        //            if (Y < Cv.Round(m_tempScaleMin / scalestep) || Y > Cv.Round(m_tempScaleMax / scalestep))
                        //                continue;

                        //            m_tempScaleX = (double)X * scalestep;
                        //            m_tempScaleY = (double)Y * scalestep;
                        //            score = RotTempMatching(des, tempImg.Mat, ROI, startT, 0, degStep, S, out resultCenter, out resultbox, margin);
                        //            listScale.Set<double>(Y, X, score);

                        //            if (score > listScale.At<double>(P.Y, P.X))
                        //            {
                        //                Q.Enqueue(new Point(X, Y));                                
                        //            }

                        //            if (score > maxScore)
                        //            {
                        //                maxScore = score;
                        //                maxX = X; maxY = Y;
                        //                resultcp = resultCenter;
                        //                for (int ii = 0; ii < 4; ii++)
                        //                {
                        //                    box[ii] = resultbox[ii];
                        //                }
                        //            }
                        //        }
                        //    }

                        //    Point3d sub = new Point3d(0, 0, score);
                        //    sub = CalSubValue(listScale, maxX, maxY);                    
                        //    //double[,] dd = SvFunc.DisplayMat(listScale);
                        //    m_tempScaleX = sub.X * scalestep;
                        //    m_tempScaleY = sub.Y * scalestep;
                        //    score = sub.Z;

                        //    //m_tempScaleX = maxX * scalestep;
                        //    //m_tempScaleY = maxY * scalestep;
                        //    //score = maxScore;
                        //    resultCenter = resultcp;
                        //    resultbox = box;
                        //    listScale.Dispose();
                        //}

                        ////templW = tempImg.Width * m_tempScaleX;
                        ////templH = tempImg.Height * m_tempScaleY;

                        //SvFunc.TimeWatch(dt, "Adjust Scale");
                        #endregion


                        // edge mode
                        if (MatchMode == E_MatchMode.Edge && score > m_PCreteria / 2)
                        {
                            double oldscore = score;
                            templW = Math.Round(tempImg.Width * m_tempScaleMax);
                            templH = Math.Round(tempImg.Height * m_tempScaleMax);
                            ROI = new Rect((int)Math.Round(resultCenter.X - templW / 2), (int)Math.Round(resultCenter.Y - templH / 2), (int)Math.Round(templW), (int)Math.Round(templH));
                            margin = 1.1;
                            score = RotTempMatching(des, tempImg.Mat, ROI, startT, 0, degStep, S, out resultCenter, out resultbox, margin, true);
                            //Console.WriteLine($"Start: {startT}, degRange: {degRange}, degStep: {degStep},S: {S},marginL: {margin}");
                            //Console.WriteLine($"Score: {score} {resultCenter}");
                            //score = (oldscore + score) / 2;
                        }

                        // Priority
                        if (score > m_PCreteria)
                        {
                            box = new Point2d[4];
                            for (int ii = 0; ii < 4; ii++)
                            {
                                box[ii] = resultbox[ii];
                            }
                            listResultBox.Add(new FoundResult(score, resultCenter, box));
                            // float[,] ff = SvFunc.DisplayMatF(InputImage.TransformMat);
                            //SvFunc.ShowTestImg(desROI, 0.2);
                        }
                        else
                        {
                            break;
                        }
                    }

                    for (int i = 0; i < m_listC.Count; i++)
                    {
                        m_listC[i].Dispose();
                    }
                    m_listC.Clear();

                    double firstscore = 0;
                    if (listResultBox.Count > 0)
                    {
                        switch (Priority)
                        {
                            case Direction.None:
                                listResultBox.Sort((a, b) => ((a.Score > b.Score) ? -1 : 1));
                                break;
                            case Direction.Left:
                                listResultBox.Sort((a, b) => ((a.CP.X < b.CP.X) ? -1 : 1));
                                break;
                            case Direction.Right:
                                listResultBox.Sort((a, b) => ((a.CP.X > b.CP.X) ? -1 : 1));
                                break;
                            case Direction.Top:
                                listResultBox.Sort((a, b) => ((a.CP.Y < b.CP.Y) ? -1 : 1));
                                break;
                            case Direction.Bottom:
                                listResultBox.Sort((a, b) => ((a.CP.Y > b.CP.Y) ? -1 : 1));
                                break;
                        }
                        // Priority Mask에서 listResultBox[0]을 사용하면 안되기 때문에 0번은 삭제후 나중에 추가
                        firstscore = listResultBox[0].Score;
                        resultCenter = listResultBox[0].CP; // Final Finding을 위해 대입
                        listResultBox.RemoveAt(0);
                    }
                    else
                    {
                        box = new Point2d[4];
                        for (int ii = 0; ii < 4; ii++)
                        {
                            box[ii] = MvFunc.ImageToFixture2D(resultbox[ii], InputImage.TransformMat);
                        }
                        failResultBox = new FoundResult(score, MvFunc.ImageToFixture3D(resultCenter, InputImage.TransformMat), box);
                        resultCenter = failResultBox.CP;
                        //for (int ii = 0; ii < resultbox.Length; ii++)
                        //{
                        //    failResultBox.Box[ii] += new Point2d(m_searchROI.X, m_searchROI.Y);
                        //}
                        //failResultBox.CP += new Point3d(m_searchROI.X, m_searchROI.Y, 0);
                        //m_score = score;
                        //return;
                    }

                    ///////////////////// Final Finding
                    dt = DateTime.Now;
                    startT = resultCenter.Z * 180.0 / Math.PI;
                    //degRange = m_precision * 2;
                    degStep = degRange / 2;
                    S = 1 / scaleLast;

                    //location = new Point(Math.Max(0, Cv.Round(resultCenter.X - templW / 2)), Math.Max(0, Cv.Round(resultCenter.Y - templH / 2)));
                    //sz = new Size(Math.Min(resultCenter.X + templW / 2, m_searchROI.Width) - location.X, Math.Min(resultCenter.Y + templH / 2, m_searchROI.Height) - location.Y);

                    //ROI = new Rect(location, sz);
                    templW = Math.Round(tempImg.Width * m_tempScaleX);
                    templH = Math.Round(tempImg.Height * m_tempScaleY);
                    ROI = new Rect((int)Math.Round(resultCenter.X - templW / 2), (int)Math.Round(resultCenter.Y - templH / 2), (int)Math.Round(templW), (int)Math.Round(templH));

                    margin = 1.1;
                    Point3d resl;
                    double _score;
                    Point2d[] resBox;
                    _score = RotTempMatching(des, tempImg.Mat, ROI, startT, degRange, degStep, S, out resl, out resBox, margin);
                    if (_score > score)
                    {
                        score = _score;
                        resultCenter = resl;
                        resultbox = resBox;
                    }
                    //Console.WriteLine($"Start: {startT}, degRange: {degRange}, degStep: {degStep},S: {S},marginL: {margin}");
                    //Console.WriteLine($"Score: {score} {resultCenter}");
                    //if (MatchMode == E_MatchMode.Edge)
                    //{
                    //    double oldscore = score;
                    //    //Point3d aa; Point2d[] bb;
                    //    //score = RotTempMatching(des, tempImg.Mat, ROI, startT, 0, degStep, S, out aa, out bb, margin, true); //không sử dụng
                    //    //score = (oldscore + score) / 2;
                    //}
                    //startT = resultCenter.Z * 180.0 / Math.PI;
                    MvFunc.TimeWatch(dt, "Last Finding");

                    listResultBox.Insert(0, new FoundResult(score, resultCenter, resultbox));
                    break;
                #region EdgePlus
                //case E_MatchMode.EdgePlus:
                //    ImageBuffer img = Mat2Image(srcGray);
                //    ImageBuffer tem = Mat2Image(dstGray);
                //    matchResult res = new matchResult(0, 0, 0, 0); 
                //   

                //    IntPtr ptsPtr, sizesPtr;
                //    int contourCount = 0, totalPoints = 0;

                //    MatchEdge(ref img, ref tem, ref res, out ptsPtr, out sizesPtr,
                //              out contourCount, out totalPoints, (int)THLow, (int)THHigh, (double)AngleNeg * -1, (double)AnglePos);

                //    if (res.score == 0 || contourCount == 0 || totalPoints == 0 || ptsPtr == IntPtr.Zero || sizesPtr == IntPtr.Zero) return;
                //    if (res.score < PCreteria)
                //    {
                //        res = new matchResult(0, 0, 0, 0);
                //        count = 0;
                //        contourCount = 0;
                //        totalPoints = 0;
                //    }
                //    resultCenter = new Point3d(res.x + m_searchROI.X, res.y + m_searchROI.Y, res.angle / (180 / Math.PI) * -1);
                //    resultbox = OriginBox(resultCenter, dstGray.Width * m_tempScaleX, dstGray.Height * m_tempScaleY);
                //    listResultBox.Insert(0, new FoundResult(res.score, resultCenter, resultbox));

                //    // lấy sizes
                //    int[] sizes = new int[contourCount];
                //    Marshal.Copy(sizesPtr, sizes, 0, contourCount);

                //    // lấy points
                //    DPoint[] pts = new DPoint[totalPoints];
                //    int sz = Marshal.SizeOf(typeof(DPoint));

                //    for (int i = 0; i < totalPoints; i++)
                //    {
                //        pts[i] = Marshal.PtrToStructure<DPoint>(ptsPtr + i * sz);
                //    }

                //    // dựng lại jagged array
                //    List<List<DPoint>> contours = new List<List<DPoint>>();
                //    l_Contours.Clear();
                //    int idx = 0;
                //    for (int c = 0; c < contourCount; c++)
                //    {
                //        //var contour = new List<DPoint>();
                //        List<OpenCvSharp.CPlusPlus.Point> contourx = new List<OpenCvSharp.CPlusPlus.Point>();
                //        for (int j = 0; j < sizes[c]; j++)
                //        {
                //            //contour.Add(pts[idx++]);
                //            var p = pts[idx++];  // chỉ tăng idx 1 lần
                //            contourx.Add(new OpenCvSharp.CPlusPlus.Point(
                //                p.x + m_searchROI.X,
                //                p.y + m_searchROI.Y));
                //        }
                //        //contours.Add(contour);
                //        l_Contours.Add(contourx);
                //    }


                //    // free memory
                //    FreeMemory(ptsPtr);
                //    FreeMemory(sizesPtr);


                //    //Cv2.DrawContours(srcGray, l_Contours, -1, new Scalar(0, 255, 0), 1);
                //    //Cv2.PutText(des, $"Score: {res.score:F4}", new OpenCvSharp.Point(10, 40), HersheyFonts.HersheyDuplex, 1, new Scalar(0, 255, 0), 2, 0);
                //    //Cv2.PutText(des, $"Angle: {res.angle:F4}", new OpenCvSharp.Point(10, 80), HersheyFonts.HersheyDuplex, 1, new Scalar(0, 255, 0), 2, 0);
                //    //Cv2.PutText(des, $"X: {res.x:F4}", new OpenCvSharp.Point(80, 120), HersheyFonts.HersheyDuplex, 1, new Scalar(0, 255, 0), 2, 0);
                //    //Cv2.PutText(des, $"Y: {res.y:F4}", new OpenCvSharp.Point(80, 160), HersheyFonts.HersheyDuplex, 1, new Scalar(0, 255, 0), 2, 0);
                //    //Cv2.Circle(des, new OpenCvSharp.Point(res.x, res.y), 8, new Scalar(0, 0, 255), -1);

                //    //TimeSpan duration = DateTime.Now - start;
                //    //Console.WriteLine("Time = " + duration.TotalMilliseconds + " ms");
                //    //lbl_time.Text = $"{duration.TotalMilliseconds} ms";
                //    //pic_Src.Image = src.ToBitmap();
                //    //Cv2.Resize(src, src, new OpenCvSharp.Size(1802, 980));
                //    //Cv2.ImShow("SrcX", src);
                //    //Cv2.WaitKey(10000);
                //    //FreeContours(ptr);
                //    break;
                #endregion
                case E_MatchMode.HEdge:
                case E_MatchMode.HNNC:
                    //List<List<OpenCvSharp.CPlusPlus.Point>> edgecontours = new List<List<cv.CPlusPlus.Point>>();

                    //Point3d res3;
                    //double score3;
                    //if (matchMode == E_MatchMode.HEdge)
                    //    score3 = Halcons.FindShape(srcGray, out res3, out edgecontours, m_searchROI);
                    //else
                    //    score3 = Halcons.FindNNC(srcGray, out res3);
                    //if (score3 < PCreteria)
                    //{
                    //    res3 = new Point3d(0, 0, 0);
                    //    count = 0;
                    //    contourCount = 0;
                    //    totalPoints = 0;
                    //}
                    //double angleNorm = Math.Atan2(Math.Sin(res3.Z), Math.Cos(res3.Z));
                    //resultCenter = new Point3d(res3.X + m_searchROI.X, res3.Y + m_searchROI.Y, angleNorm*-1);
                    //resultbox = OriginBox(resultCenter, dstGray.Width * m_tempScaleX, dstGray.Height * m_tempScaleY);
                    //listResultBox.Insert(0, new FoundResult(score3, resultCenter, resultbox));
                    //l_Contours.Clear();
                    //l_Contours = edgecontours;

                    List<List<List<OpenCvSharp.CPlusPlus.Point>>> edgecontours = new List<List<List<cv.CPlusPlus.Point>>>();
                    Point2d[] _resBox = new Point2d[4];
                    Point3d[] center;
                    double[] score3;
                    if (matchMode == E_MatchMode.HEdge)
                        score3 = Halcons.FindShape(srcGray, out center, out edgecontours, m_searchROI);
                    else
                        score3 = Halcons.FindNNC(srcGray, out center);

                    for (int i = 0; i < score3.Count(); i++)
                    {
                        if (score3[i] < PCreteria)
                        {
                            center[i] = new Point3d(0, 0, 0);
                            count = 0;
                            contourCount = 0;
                            totalPoints = 0;
                        }
                        else
                        {
                            //double angle = center[i].Z * (180 / Math.PI);
                            //double angleNorm = Math.Atan2(Math.Sin(center[i].Z), Math.Cos(center[i].Z));
                            resultCenter = new Point3d(center[i].X + m_searchROI.X, center[i].Y + m_searchROI.Y, center[i].Z * -1);
                            _resBox = OriginBox(resultCenter, dstGray.Width * m_tempScaleX, dstGray.Height * m_tempScaleY);
                            listResultBox.Insert(i, new FoundResult(score3[i], resultCenter, _resBox, edgecontours[i].Select(x => x.ToArray()).ToArray()));
                        }
                    }
                    listResultBox = listResultBox.OrderByDescending(r => r.Score).ToList();
                    //l_Contours.Clear();
                    //l_Contours = edgecontours;

                    break;

            }
            // ROI 보상
            //for (int ii = 0; ii < listResultBox.Count; ii++)
            //{
            //    for (int jj = 0; jj < resultbox.Length; jj++)
            //    {
            //        listResultBox[ii].Box[jj] += new Point2d(m_searchROI.X, m_searchROI.Y);
            //    }
            //    listResultBox[ii].CP += new Point3d(m_searchROI.X, m_searchROI.Y, 0);
            //}

            // Calculate Ref. Point
            //Mat matRot = Cv2.GetRotationMatrix2D(new Point2f((float)resultbox[0].X, (float)resultbox[0].Y), -resultCenter.Z * 180 / Math.PI, 1);
            //Mat resultRefMat = new Mat(3, 1, MatType.CV_64FC1, new double[] { m_tempScaleX * refPoint.X + resultbox[0].X, m_tempScaleY * refPoint.Y + resultbox[0].Y, 1 });
            ////Mat resultRefMat = new Mat(3, 1, MatType.CV_64FC1);
            ////resultRefMat.SetArray(new double[] { m_tempScaleX * refPoint.X + resultbox[0].X, m_tempScaleY * refPoint.Y + resultbox[0].Y, 1 });
            //resultRefMat = matRot * resultRefMat;
            //m_result = new Point3d(resultRefMat.At<double>(0, 0), resultRefMat.At<double>(1, 0), resultCenter.Z);

            //// Fixture 보상
            //m_result = MvFunc.ImageToFixture3D(m_result.Value, InputImage.TransformMat);
            //for (int ii = 0; ii < listResultBox.Count; ii++)
            //{
            //    for (int jj = 0; jj < 4; jj++)
            //        resultbox[jj] = MvFunc.ImageToFixture2D(resultbox[jj], InputImage.TransformMat);
            //    listResultBox[ii].CP = MvFunc.ImageToFixture3D(listResultBox[ii].CP, InputImage.TransformMat);
            //}

            //resultCenter = listResultBox[0].CP;
            //ResultBox = listResultBox[0].Box;

            // Mat Dispose
            if (des != null) des.Dispose();
            //if (matRot != null) matRot.Dispose();
            //if (resultRefMat != null) resultRefMat.Dispose();
            if (m_desROI != null) m_desROI.Dispose();
            for (int i = 0; i < m_listC.Count; i++)
                if (m_listC[i] != null) m_listC[i].Dispose();
            if (FoundImage != null) FoundImage.Dispose();

            if (resultbox == null || resultbox.Length == 0) return;
            /////////////////////

            //ResultCP = resultCenter;
            FoundImage = GetFoundImage(InputImage);

            //if (listResultBox.Count > 0)
            //    Score[0] = listResultBox[0].Score;

            if (listResultBox.Count > 0)
                lastRunSuccess = true;
            else
            {
                listResultBox.Insert(0, new FoundResult(m_score, new Point3d(double.NaN, double.NaN, double.NaN), resultbox));
                Result = new Point3d(double.NaN, double.NaN, double.NaN);
            }

            MvFunc.TimeWatch(TemplateMatchRunTime, "TemplateMatching 시간");
        }

        // MultiPattern 추가 17.09.27
        private bool PatternChange()
        {
            if (mPatternDataList.Count == 0) return false;
            if (mSelectedPatternIndex >= mPatternDataList.Count) return false;
            if (mSelectedPatternIndex < 0) mSelectedPatternIndex = 0;

            TemplateImage = mPatternDataList[mSelectedPatternIndex].Value.PatternImage;
            Mask = mPatternDataList[mSelectedPatternIndex].Value.MaskImage;
            refPoint = mPatternDataList[mSelectedPatternIndex].Value.RefPoint;

            return true;
        }

        MvImage GetFoundImage(MvImage image)
        {
            if (image == null || image.Mat == null || image.Mat.IsDisposed) return null;

            Point2f center = MvFunc.FixtureToImage2F(new Point2f((float)ResultCP.X, (float)resultCP.Y), image.TransformMat);

            double T = ResultCP.Z;
            double H = tempImg.Width;
            int V = tempImg.Height;

            Mat Rmat = Cv2.GetRotationMatrix2D(center, T * 180 / Math.PI, 1);
            Rmat.Set<double>(0, 2, Rmat.At<double>(0, 2) - center.X + H / 2.0);
            Rmat.Set<double>(1, 2, Rmat.At<double>(1, 2) - center.Y + V / 2.0);

            Rect rect = new Rect((int)center.X, (int)center.Y, (int)H, (int)V);

            MvImage templateImg = new MvImage();
            //Func.ShowTestImg(mask, 0.25);

            Cv2.WarpAffine(image.Mat, templateImg.Mat, Rmat, rect.Size, Interpolation.Linear, OpenCvSharp.BorderType.Constant, borderColor);

            Rmat.Dispose();

            return templateImg;
        }

        public double RotTempMatching(Mat _src, Mat _temp, Rect _roi, double _degStart, double _degRange, double _degStep,
            double _searchscale, out Point3d _resultcp, out Point2d[] _resultbox, double _margin = 1.5, bool _maskedscore = false)
        {
            _resultcp = new Point3d();
            _resultbox = new Point2d[4];
            _degStep = Math.Round(_degStep, 10);

            if (_searchscale == 0) return -1;
            if (m_tempScaleX == 0 || m_tempScaleY == 0) return -1;

            // 이조건은 왜있는거임... ㅡ,.ㅡ A.S.H 삭제 17.10.10
            //if (src.Width < templROI.Right + 1 || src.Height < templROI.Bottom + 1) return -1;
            if (_roi.Width < 0 || _roi.Height < 0) return -1;
            if (double.IsNaN(_degStart) || double.IsNaN(_degRange) || double.IsNaN(_degStep)) return -1;

            // Original Rect, Size
            Point2d ROICP = (_roi.TopLeft + _roi.BottomRight) * 0.5;
            OpenCvSharp.CPlusPlus.Point ScROICP = (OpenCvSharp.CPlusPlus.Point)ROICP * _searchscale;

            Point3d matchingPoint = new Point3d(0.0, 0.0, -_degStart);
            double matchingScore = -1.0f;
            double ellipsS = 0.4;

            Rect ScSrcRotRect;
            Mat ScSrcRot;


            // Template Image Scaling
            if (m_tempScaleX != m_tempScaleXOld || m_tempScaleY != m_tempScaleYOld || _searchscale != m_SearchScale)
            {
                m_tempScaleXOld = m_tempScaleX;
                m_tempScaleYOld = m_tempScaleY;
                int StempW = (int)Math.Round(_temp.Width * _searchscale * m_tempScaleX);
                int StempH = (int)Math.Round(_temp.Height * _searchscale * m_tempScaleY);
                if (StempH < 0 || StempW < 0) return -1;

                OpenCvSharp.CPlusPlus.Size tempsize = new OpenCvSharp.CPlusPlus.Size(StempW, StempH);
                if (m_sclTemp != null)
                    m_sclTemp.Dispose();
                m_sclTemp = new Mat();

                Cv2.Resize(_temp, m_sclTemp, tempsize, 0, 0, Interpolation.Linear);

                if (MatchMode == E_MatchMode.Edge)
                {
                    if (m_scaledMask != null)
                        m_scaledMask.Dispose();
                    m_scaledMask = new Mat();

                    // EdgeDetect 적용
                    // 정밀도에 있어서는 잘 모르겠으나, 속도향상을 위해 여기에 구현
                    int minBlobsize = Math.Min(m_sclTemp.Width, m_sclTemp.Height);
                    GetEdge(m_sclTemp, minBlobsize, out m_sclTemp, _searchscale);

                    /////////////////// Mask 적용(Edge 일때만)
                    if (mask.MaskMat != null && Mask.MaskMat.Width != 0 && Mask.MaskMat.Height != 0 && !mask.MaskMat.IsDisposed)
                    {
                        Mat maskedtmp = new Mat(m_sclTemp.Size(), m_sclTemp.Type(), new Scalar(0));
                        Cv2.Resize(mask.MaskMat, m_scaledMask, m_sclTemp.Size());
                        m_sclTemp.CopyTo(maskedtmp, m_scaledMask);
                        if (m_sclTemp != null)
                            m_sclTemp.Dispose();
                        m_sclTemp = maskedtmp;//.Clone();
                        //SvFunc.ShowTestImg(scaledtemp, 1);
                    }
                }
            }

            // Source Image Scaling


            if (m_SearchScale != _searchscale)
            {
                m_SearchScale = _searchscale;
                if (m_sclSrc != null) m_sclSrc.Dispose();
                m_sclSrc = new Mat();

                Cv2.Resize(_src, m_sclSrc, MvFunc.ResizeSize(_src.Size(), _searchscale), 0, 0, Interpolation.Linear);

                if (MatchMode == E_MatchMode.Edge)
                {
                    // EdgeDetect 적용
                    // 정밀도에 있어서는 잘 모르겠으나, 속도향상을 위해 여기에 구현
                    int minBlobsize = Math.Min(m_sclTemp.Width, m_sclTemp.Height);
                    GetEdge(m_sclSrc, minBlobsize, out m_sclSrc, _searchscale);
                    //masktmp.Dispose();
                }
            }
            //int scaledSrcWidth = Cv.Round(sclK * Math.Max(Cv.Round(src_ROI.Width * scale), Cv.Round(src_ROI.Height * scale)));
            double Trad = _degRange / 2 * Math.PI / 180;
            Point2d righttop = new Point2d(Math.Max(_roi.Width / 2, _temp.Width * m_tempScaleX / 2), Math.Max(_roi.Height / 2, _temp.Height * m_tempScaleY / 2));
            double scaledSrcW = MvFunc.Rotate(righttop, -Trad).X * 2 * _searchscale * _margin;
            double scaledSrcH = MvFunc.Rotate(righttop, Trad).Y * 2 * _searchscale * _margin;

            ScSrcRotRect = new Rect();
            ScSrcRotRect.X = (int)Math.Round(ScROICP.X - scaledSrcW / 2);
            ScSrcRotRect.Y = (int)Math.Round(ScROICP.Y - scaledSrcH / 2);
            ScSrcRotRect.Size = new OpenCvSharp.CPlusPlus.Size(scaledSrcW, scaledSrcH);
            ScSrcRot = new Mat(ScSrcRotRect.Size, _src.Type());

            Mat matTrans = new Mat(2, 3, MatType.CV_64F, new double[] { 1, 0, -ScSrcRotRect.X, 0, 1, -ScSrcRotRect.Y });
            Mat matTransScale = new Mat(2, 3, MatType.CV_64F, new double[] { _searchscale, 0, -ScSrcRotRect.X, 0, _searchscale, -ScSrcRotRect.Y });
            //Mat matTransScale = new Mat(2, 3, MatType.CV_64F);
            //matTransScale.SetArray(new double[] { _searchscale, 0, -ScSrcRotRect.X, 0, _searchscale, -ScSrcRotRect.Y });

            if (_degStep <= 0)
            {
                _degRange = 0;
                _degStep = 1;
            }
            else
                _degRange -= 2 * ((_degRange / 2) % _degStep);

            int maxAngleIdx = 0;


            bool retry = true;
            // MatchTemplate
            double min = 0, max = 0;
            OpenCvSharp.CPlusPlus.Point minPoint = new OpenCvSharp.CPlusPlus.Point();
            OpenCvSharp.CPlusPlus.Point maxPoint = new OpenCvSharp.CPlusPlus.Point();

            List<Point2d> listAngleToScore = new List<Point2d>();
            List<OpenCvSharp.CPlusPlus.Point> PrePoints = new List<OpenCvSharp.CPlusPlus.Point>();
            for (int i = 0; i < listResultBox.Count; i++)
            {
                PrePoints.Add(new OpenCvSharp.CPlusPlus.Point(listResultBox[i].CP.X * _searchscale, listResultBox[i].CP.Y * _searchscale));
                //PrePoints[i] -= templROI.Location;
            }

            Mat RotateMat = new Mat();
            //Mat TransScaleMat = new Mat(3, 3, MatType.CV_64F, new double[] 
            //{ 
            //    matTransScale.At<double>(0, 0), matTransScale.At<double>(0, 1), matTransScale.At<double>(0, 2),
            //    matTransScale.At<double>(1, 0), matTransScale.At<double>(1, 1), matTransScale.At<double>(1, 2),
            //    0, 0, 1
            //});

            //// ScSrcRot를 회전시키면서 가장 높은 Score의 위치, 각도를 찾는다.
            //// Image는 Pattern 결과값과 반대이므로 desStart는 음수가 맞다...
            Mat C = null;
            Mat Ctemp = null;

            int anglecount = 0;

            double startA = Math.Round(-_degRange / 2 - _degStart, 10);
            double endA = Math.Round(_degRange / 2 - _degStart, 10);

            for (double angle = startA; angle <= endA; angle += _degStep, anglecount++)
            {
                if (double.IsInfinity(angle) || double.IsNaN(angle))
                    return 0;
                RotateMat = Cv2.GetRotationMatrix2D(new Point2f(ScROICP.X, ScROICP.Y), -angle, 1);
                RotateMat.Set<double>(0, 2, RotateMat.At<double>(0, 2) - ScSrcRotRect.X);
                RotateMat.Set<double>(1, 2, RotateMat.At<double>(1, 2) - ScSrcRotRect.Y);

                Cv2.WarpAffine(m_sclSrc, ScSrcRot, RotateMat, ScSrcRot.Size(), Interpolation.Linear, OpenCvSharp.BorderType.Constant, borderColor);
                OpenCvSharp.CPlusPlus.Point ellipsP;

                if (m_iteration == 0) // 전체 찾기할 경우
                {
                    if (m_listC.Count - 1 < anglecount) // 한번도 찾지 않았을 경우, 궂이 count로 측정하는 이유는 이전에 찾을때 score가 높아서 도중에 탈출하면 m_listC가 다 없을수도 있어서...
                    {
                        C = new Mat(ScSrcRot.Size(), MatType.CV_32F);
                        MvFunc.StartWatch("TemplateMatch 전체찾기");
                        Cv2.MatchTemplate(ScSrcRot, m_sclTemp, C, MatchMethod);
                        MvFunc.StopWatch();
                        for (int i = 0; i < PrePoints.Count; i++)
                        {
                            Point3d cp3d = MvFunc.MattoP(RotateMat/* * TransScaleMat*/ * MvFunc.PtoMat(new Point3d(PrePoints[i].X, PrePoints[i].Y, 1)), true);
                            ellipsP = new OpenCvSharp.CPlusPlus.Point(cp3d.X, cp3d.Y);
                            if (C != null)
                                C.Ellipse(ellipsP - new OpenCvSharp.CPlusPlus.Point(m_sclTemp.Width * 0.5, m_sclTemp.Height * 0.5), new OpenCvSharp.CPlusPlus.Size(m_sclTemp.Width * ellipsS, m_sclTemp.Height * ellipsS), 0, -180, 180, borderColor, -1);
                        }

                        Mat mask;
                        Mat maskedC = ApplyROIMask(C, matTransScale, 1, out mask);
                        Cv2.MinMaxLoc(maskedC, out min, out max, out minPoint, out maxPoint, mask);
                        m_listC.Add(maskedC);
                        if (C != null) C.Dispose();
                        if (mask != null) mask.Dispose();
                    }
                    else // 한번이라도 찾아봤던거면 m_listC를 새로 만들지 않고 기존에 있는거에 Masking 해서 다음것 검색
                    {
                        C = m_listC[anglecount];

                        MvFunc.StartWatch("Mask에 원그리기");

                        if (PrePoints.Count > 0)
                        {
                            int i = PrePoints.Count - 1;

                            Point3d cp3d = MvFunc.MattoP(RotateMat/* * TransScaleMat*/ * MvFunc.PtoMat(new Point3d(PrePoints[i].X, PrePoints[i].Y, 1)), true);
                            ellipsP = new OpenCvSharp.CPlusPlus.Point(cp3d.X, cp3d.Y);
                            C.Ellipse(ellipsP - new OpenCvSharp.CPlusPlus.Point(m_sclTemp.Width * 0.5, m_sclTemp.Height * 0.5), new OpenCvSharp.CPlusPlus.Size(m_sclTemp.Width * ellipsS, m_sclTemp.Height * ellipsS), 0, -180, 180, borderColor, -1);
                        }
                        Cv2.MinMaxLoc(C, out min, out max, out minPoint, out maxPoint);
                    }
                    //SvFunc.ShowTestImg(C, 2);
                    MvFunc.StopWatch();
                }
                else // 전체 찾기 아닐경우는 걍 무식하게...
                {
                    Ctemp = new Mat(ScSrcRot.Size(), MatType.CV_32F);

                    MvFunc.StartWatch("TemplateMatch 부분찾기");
                    Cv2.MatchTemplate(ScSrcRot, m_sclTemp, Ctemp, MatchMethod);
                    MvFunc.StopWatch();
                    for (int i = 0; i < PrePoints.Count; i++)
                    {
                        Point3d cp3d = MvFunc.MattoP(RotateMat/* * TransScaleMat*/ * MvFunc.PtoMat(new Point3d(PrePoints[i].X, PrePoints[i].Y, 1)), true);
                        ellipsP = new OpenCvSharp.CPlusPlus.Point(cp3d.X, cp3d.Y);
                        Ctemp.Ellipse(ellipsP - new OpenCvSharp.CPlusPlus.Point(m_sclTemp.Width * 0.5, m_sclTemp.Height * 0.5), new OpenCvSharp.CPlusPlus.Size(m_sclTemp.Width * ellipsS, m_sclTemp.Height * ellipsS), 0, -180, 180, borderColor, -1);
                    }

                    // ROI rotation 생략
                    Cv2.MinMaxLoc(Ctemp, out min, out max, out minPoint, out maxPoint);
                }
                if (Ctemp != null) Ctemp.Dispose();

                double creteria = 0.9;

                listAngleToScore.Add(new Point2d(angle, max));

                ////// Debugging용 Code 삭제 금지 ////////
                //for (int i = 0; i < PrePoints.Count; i++)
                //{
                //    Point3d cp3d = SvFunc.MattoP(RotateMat/* * TransScaleMat*/ * SvFunc.PtoMat(new Point3d(PrePoints[i].X, PrePoints[i].Y, 1)), true);
                //    ellipsP = new Point(cp3d.X, cp3d.Y);
                //    if (C != null)
                //        C.Ellipse(ellipsP - new Point(m_sclTemp.Width * 0.5, m_sclTemp.Height * 0.5), new Size(m_sclTemp.Width * ellipsS, m_sclTemp.Height * ellipsS), 0, -180, 180, 0.5, -1);
                //}
                //ScSrcRot.Circle(maxPoint, 40, 40, 10);
                //ScSrcRot.Circle(maxPoint, 10, 40, 10);
                //Scalar color = 125;
                //if (max > matchingScore)
                //    color = 200;
                //ScSrcRot.PutText("Score Max:" + matchingScore.ToString("F3") + " now:" + max.ToString("F3"), new Point(0, 10), FontFace.Vector0, 0.3, color);
                //ScSrcRot.PutText("Angle Max:" + matchingPoint.Z.ToString("F3") + " now:" + angle.ToString("F3"), new Point(0, 20), FontFace.Vector0, 0.3, color);
                //SvFunc.ShowTestImg(m_sclTemp, 2, "Template");
                //SvFunc.ShowTestImg(ScSrcRot, 2);
                //if (C != null)
                //    SvFunc.ShowTestImg(C, 2);
                ///////// Debugging용 Code 끝 ///////////

                if (max > matchingScore)
                {
                    matchingScore = max;
                    maxAngleIdx = listAngleToScore.Count - 1;
                    matchingPoint.X = maxPoint.X;
                    matchingPoint.Y = maxPoint.Y;
                    matchingPoint.Z = angle;

                    if (matchingScore > creteria)// && !(m_iteration == 0 && m_iFindCount == 0))
                        retry = false;
                }
                else if (!retry)
                {
                    break;
                }
            }

            ////// SubAngle 사용하여 다시 MaxPoint, MaxScore를 찾는다.

            if (listAngleToScore.Count > 1)
            {
                // Score 최대값이 listAngleToScore 처음에 있을때(최대값을 앞에서 더 찾아야 함)
                double angle = startA;
                int count = 0;
                while (maxAngleIdx == 0 && count < 5)
                {
                    angle -= _degStep;
                    RotateMat = Cv2.GetRotationMatrix2D(new Point2f(ScSrcRotRect.X + ScSrcRotRect.Width / 2, ScSrcRotRect.Y + ScSrcRotRect.Height / 2), -angle, 1);
                    RotateMat.Set<double>(0, 2, RotateMat.At<double>(0, 2) - ScSrcRotRect.X);
                    RotateMat.Set<double>(1, 2, RotateMat.At<double>(1, 2) - ScSrcRotRect.Y);

                    Cv2.WarpAffine(m_sclSrc, ScSrcRot, RotateMat, ScSrcRot.Size(), Interpolation.Linear, OpenCvSharp.BorderType.Constant, borderColor);
                    Ctemp = new Mat(ScSrcRot.Size(), MatType.CV_32F);
                    Cv2.MatchTemplate(ScSrcRot, m_sclTemp, Ctemp, MatchMethod);

                    for (int i = 0; i < PrePoints.Count; i++)
                    {
                        Point3d cp3d = MvFunc.MattoP(RotateMat/* * TransScaleMat*/ * MvFunc.PtoMat(new Point3d(PrePoints[i].X, PrePoints[i].Y, 1)), true);
                        OpenCvSharp.CPlusPlus.Point ellipsP = new OpenCvSharp.CPlusPlus.Point(cp3d.X, cp3d.Y);
                        Ctemp.Ellipse(ellipsP - new OpenCvSharp.CPlusPlus.Point(m_sclTemp.Width * 0.5, m_sclTemp.Height * 0.5), new OpenCvSharp.CPlusPlus.Size(m_sclTemp.Width * ellipsS, m_sclTemp.Height * ellipsS), 0, -180, 180, borderColor, -1);
                    }

                    // ROI rotation
                    Mat mask;
                    Mat maskedMat = ApplyROIMask(Ctemp, matTransScale, 1, out mask);
                    Cv2.MinMaxLoc(Ctemp, out min, out max, out minPoint, out maxPoint, mask);
                    if (mask != null) mask.Dispose();
                    if (maskedMat != null) maskedMat.Dispose();

                    listAngleToScore.Insert(0, new Point2d(angle, max));
                    maxAngleIdx++;

                    if (max > matchingScore)
                    {
                        matchingScore = max;
                        maxAngleIdx = 0;
                        matchingPoint.X = maxPoint.X;
                        matchingPoint.Y = maxPoint.Y;
                        matchingPoint.Z = angle;
                        maxAngleIdx = 0;
                    }
                    Ctemp.Dispose();
                    count++;
                }

                // Score 최대값이 listAngleToScore 마지막에 있을때(최대값을 뒤에서 더 찾아야 함)
                angle = endA;
                count = 0;
                while (maxAngleIdx == listAngleToScore.Count - 1 && count < 5)
                {
                    angle += _degStep;
                    RotateMat = Cv2.GetRotationMatrix2D(new Point2f(ScSrcRotRect.X + ScSrcRotRect.Width / 2, ScSrcRotRect.Y + ScSrcRotRect.Height / 2), -angle, 1);
                    RotateMat.Set<double>(0, 2, RotateMat.At<double>(0, 2) - ScSrcRotRect.X);
                    RotateMat.Set<double>(1, 2, RotateMat.At<double>(1, 2) - ScSrcRotRect.Y);

                    Cv2.WarpAffine(m_sclSrc, ScSrcRot, RotateMat, ScSrcRot.Size(), Interpolation.Linear, OpenCvSharp.BorderType.Constant, borderColor);
                    Ctemp = new Mat(ScSrcRot.Size(), MatType.CV_32F);
                    Cv2.MatchTemplate(ScSrcRot, m_sclTemp, Ctemp, MatchMethod);

                    for (int i = 0; i < PrePoints.Count; i++)
                    {
                        Point3d cp3d = MvFunc.MattoP(RotateMat/* * TransScaleMat*/ * MvFunc.PtoMat(new Point3d(PrePoints[i].X, PrePoints[i].Y, 1)), true);
                        OpenCvSharp.CPlusPlus.Point ellipsP = new OpenCvSharp.CPlusPlus.Point(cp3d.X, cp3d.Y);
                        Ctemp.Ellipse(ellipsP - new OpenCvSharp.CPlusPlus.Point(m_sclTemp.Width * 0.5, m_sclTemp.Height * 0.5), new OpenCvSharp.CPlusPlus.Size(m_sclTemp.Width * ellipsS, m_sclTemp.Height * ellipsS), 0, -180, 180, borderColor, -1);
                    }

                    // ROI rotation
                    Mat mask;
                    Mat maskedMat = ApplyROIMask(Ctemp, matTransScale, 1, out mask);
                    Cv2.MinMaxLoc(Ctemp, out min, out max, out minPoint, out maxPoint, mask);
                    if (mask != null) mask.Dispose();
                    if (maskedMat != null) maskedMat.Dispose();

                    listAngleToScore.Add(new Point2d(angle, max));

                    if (max > matchingScore)
                    {
                        matchingScore = max;
                        maxAngleIdx = listAngleToScore.Count - 1;
                        matchingPoint.X = maxPoint.X;
                        matchingPoint.Y = maxPoint.Y;
                        matchingPoint.Z = angle;
                    }
                    Ctemp.Dispose();
                    count++;
                }

                double anglediff = double.MaxValue;
                max = double.MaxValue;
                Point2d subA = new Point2d();
                List<Mat> listSubC = new List<Mat>();
                Mat SubC = null;
                count = 0;
                while (anglediff > _degStep / 5 && count < 5)
                {
                    double oldangle = listAngleToScore[maxAngleIdx].X;
                    subA = CalSubValue(listAngleToScore, maxAngleIdx);
                    anglediff = Math.Abs(oldangle - subA.X);
                    RotateMat = Cv2.GetRotationMatrix2D(new Point2f(ScSrcRotRect.X + ScSrcRotRect.Width / 2, ScSrcRotRect.Y + ScSrcRotRect.Height / 2), -subA.X, 1);
                    RotateMat.Set<double>(0, 2, RotateMat.At<double>(0, 2) - ScSrcRotRect.X);
                    RotateMat.Set<double>(1, 2, RotateMat.At<double>(1, 2) - ScSrcRotRect.Y);

                    Cv2.WarpAffine(m_sclSrc, ScSrcRot, RotateMat, ScSrcRot.Size(), Interpolation.Linear, OpenCvSharp.BorderType.Constant, borderColor);

                    SubC = new Mat(ScSrcRot.Size(), MatType.CV_32F);
                    listSubC.Add(SubC);
                    Cv2.MatchTemplate(ScSrcRot, m_sclTemp, SubC, MatchMethod);
                    for (int i = 0; i < PrePoints.Count; i++)
                    {
                        Point3d cp3d = MvFunc.MattoP(RotateMat/* * TransScaleMat*/ * MvFunc.PtoMat(new Point3d(PrePoints[i].X, PrePoints[i].Y, 1)), true);
                        OpenCvSharp.CPlusPlus.Point ellipsP = new OpenCvSharp.CPlusPlus.Point(cp3d.X, cp3d.Y);
                        SubC.Ellipse(ellipsP - new OpenCvSharp.CPlusPlus.Point(m_sclTemp.Width * 0.5, m_sclTemp.Height * 0.5), new OpenCvSharp.CPlusPlus.Size(m_sclTemp.Width * ellipsS, m_sclTemp.Height * ellipsS), 0, -180, 180, borderColor, -1);
                    }

                    // ROI rotation
                    Mat mask;
                    Mat maskedMat = ApplyROIMask(SubC, matTransScale, 1, out mask);
                    Cv2.MinMaxLoc(SubC, out min, out max, out minPoint, out maxPoint, mask);
                    if (mask != null) mask.Dispose();
                    if (maskedMat != null) maskedMat.Dispose();

                    // 만약 각도가 어느정도 정확하다고 판단(각도에 따라 찾은 대상이 동일하다는 뜻)되면, SubAngle을 믿는다.
                    if (max > matchingScore)
                    {
                        matchingScore = max;
                        listAngleToScore.Add(new Point2d(subA.X, max));
                        listAngleToScore.Sort((a, b) => (a.X < b.X) ? -1 : 1);
                        maxAngleIdx = listAngleToScore.FindIndex(a => a.Y == max);
                        matchingPoint.X = maxPoint.X;
                        matchingPoint.Y = maxPoint.Y;
                        matchingPoint.Z = subA.X;

                        ////// Debugging용 Code 삭제 금지 ////////
                        //ScSrcRot.Circle(maxPoint, 40, 40, 10);
                        //ScSrcRot.Circle(maxPoint, 10, 40, 10);
                        //ScSrcRot.PutText(max.ToString("F3") + "  " + subA.X.ToString("F3"), new Point(0, 20), FontFace.HersheyComplex, 0.5, 125);
                        //if (SubC != null)
                        //    SvFunc.ShowTestImg(SubC, 2);
                        //SvFunc.ShowTestImg(ScSrcRot, 2);
                        ///////// Debugging용 Code 끝 ///////////
                    }
                    else
                        break;
                    if (m_iteration == 0)
                        break;
                    count++;
                }

                Point2d subpixel = CalSubpixel3(SubC, new OpenCvSharp.CPlusPlus.Point(matchingPoint.X, matchingPoint.Y));
                matchingPoint.X = subpixel.X;
                matchingPoint.Y = subpixel.Y;
                matchingPoint.Z = subA.X;
                matchingScore = max;

                for (int i = 0; i < listSubC.Count; i++)
                    listSubC[i].Dispose();
            }

            if (MatchMode == E_MatchMode.Edge && _maskedscore)
            {
                DateTime dt2 = DateTime.Now;
                if (_maskedscore)
                    ApplyMask(maxPoint, ScSrcRot, m_sclTemp, m_scaledMask, max, out matchingScore);

                MvFunc.TimeWatch(dt2, "CalSubpixel3");
            }


            //////// Debugging용 Code 삭제 금지 ////////
            //for (int i = 0; i < PrePoints.Count; i++)
            //{
            //    Point3d cp3d = SvFunc.MattoP(RotateMat/* * TransScaleMat*/ * SvFunc.PtoMat(new Point3d(PrePoints[i].X, PrePoints[i].Y, 1)), true);
            //    Point ellipsP = new Point(cp3d.X, cp3d.Y);
            //    C.Ellipse(ellipsP - new Point(m_sclTemp.Width * 0.5, m_sclTemp.Height * 0.5), new Size(m_sclTemp.Width * ellipsS, m_sclTemp.Height * ellipsS), 0, -180, 180, 0.5, -1);
            //}
            //ScSrcRot.Circle(maxPoint, 50, 255, 10);
            //ScSrcRot.Circle(maxPoint, 10, 255, 10);
            //SvFunc.ShowTestImg(m_sclTemp, 1);
            //SvFunc.ShowTestImg(ScSrcRot, 1);
            ////SvFunc.ShowTestImg(Cmat, 1);
            //foreach (Mat m in m_listC)
            //{
            //    SvFunc.ShowTestImg(m, 1);
            //}
            //////////// Debugging용 Code 끝 ///////////


            ////////////////////////////////////////////////////     Result Warping     ///////////////////////////////////////////////////////////////////
            Point2d[] source = new Point2d[4];
            Point2d[] target = new Point2d[4];

            source[0] = new Point2d(0, 0);
            source[1] = new Point2d(1, 0);
            source[2] = new Point2d(0, 1);
            source[3] = new Point2d(1, 1);

            double T = matchingPoint.Z * Math.PI / 180;

            target[0] = new Point2d(ScSrcRot.Width / 2, ScSrcRot.Height / 2) + new Point2d(-ScROICP.X * Math.Cos(T) + ScROICP.Y * Math.Sin(T), -ScROICP.X * Math.Sin(T) - ScROICP.Y * Math.Cos(T));
            target[1] = target[0] + new Point2d(Math.Cos(T), Math.Sin(T));
            target[2] = target[0] + new Point2d(Math.Cos(T + Math.PI / 2), Math.Sin(T + Math.PI / 2));
            target[3] = target[0] + new Point2d(Math.Cos(T) + Math.Cos(T + Math.PI / 2), Math.Sin(T) + Math.Sin(T + Math.PI / 2));

            Mat warpMat = Cv2.FindHomography(target, source);
            Mat newSM = warpMat * new Mat(3, 1, MatType.CV_64FC1, new double[] { matchingPoint.X, matchingPoint.Y, 1 });
            warpMat.Dispose();

            //Mat warpMat = Cv2.FindHomography(target, source);
            //Mat m_match = new Mat(3, 1, MatType.CV_64FC1);
            //m_match.SetArray(new double[] { matchingPoint.X, matchingPoint.Y, 1 });
            //Mat newSM = warpMat * m_match;
            //warpMat.Dispose();

            _resultcp = new Point3d(newSM.At<double>(0, 0) / newSM.At<double>(2, 0) / _searchscale, newSM.At<double>(1, 0) / newSM.At<double>(2, 0) / _searchscale, -T);

            _resultbox = OrigintoBox(_resultcp, _temp.Width * m_tempScaleX, _temp.Height * m_tempScaleY);
            ScSrcRot.Dispose();

            _resultcp = (_resultcp + new Point3d(_resultbox[2].X, _resultbox[2].Y, _resultcp.Z)) * 0.5;
            double scaleFactX = (m_tempScaleX < 1) ? Math.Sqrt(m_tempScaleX) : 1;
            double scaleFactY = (m_tempScaleY < 1) ? Math.Sqrt(m_tempScaleY) : 1;

            return matchingScore * scaleFactX * scaleFactY;
        }

        private Mat ApplyROIMask(Mat _C, Mat _transferMat, double _scale, out Mat _mask)
        {
            _mask = null;

            if (_C == null || _transferMat == null) return null;

            //Mat transferMat = new Mat(2, 3, MatType.CV_64FC1, new double[] { 1, 0, _transferMat.Get<double>(0, 2), 0, 1, _transferMat.Get<double>(1, 2) });
            //_rotateMat.Set(0, 0, 1);
            //_rotateMat.Set(0, 1, 0);
            //_rotateMat.Set(1, 0, 0);
            //_rotateMat.Set(1, 1, 1);
            _mask = new Mat(_C.Size(), MatType.CV_8UC1, new Scalar(0));

            Point2d[] roibox = new Point2d[4];
            roibox[0] = new Point2d(m_ROIrect.Left, m_ROIrect.Top) * _scale;
            roibox[1] = new Point2d(m_ROIrect.Right, m_ROIrect.Top) * _scale;
            roibox[2] = new Point2d(m_ROIrect.Right, m_ROIrect.Bottom) * _scale;
            roibox[3] = new Point2d(m_ROIrect.Left, m_ROIrect.Bottom) * _scale;

            // ROI rotation
            OpenCvSharp.CPlusPlus.Point[] rotROIpoints = new OpenCvSharp.CPlusPlus.Point[4];
            for (int i = 0; i < 4; i++)
            {
                Mat result = _transferMat * new Mat(3, 1, MatType.CV_64FC1, new double[3] { roibox[i].X, roibox[i].Y, 1 });
                rotROIpoints[i] = new OpenCvSharp.CPlusPlus.Point(result.At<double>(0, 0), result.At<double>(0, 1));
                //Mat sub = new Mat(3, 1, MatType.CV_64FC1);
                //sub.SetArray(new double[3] { roibox[i].X, roibox[i].Y, 1 });
                //Mat result = _transferMat * sub;
                //rotROIpoints[i] = new OpenCvSharp.CPlusPlus.Point(result.At<double>(0, 0), result.At<double>(0, 1));
            }
            Cv2.FillPoly(_mask, new OpenCvSharp.CPlusPlus.Point[][] { rotROIpoints }, new Scalar(100));

            Mat maskedC = new Mat(_C.Size(), _C.Type(), new Scalar(0));
            //SvFunc.ShowTestImg(_mask, 2);
            _C.CopyTo(maskedC, _mask);
            //SvFunc.ShowTestImg(maskedC, 2);

            return maskedC;
        }

        Point2d[] OrigintoBox(Point3d OriginP, double W, double H)
        {
            Point2d[] Box = new Point2d[4];
            Box[0] = new Point2d(OriginP.X, OriginP.Y);
            Box[1] = Box[0] + new Point2d(Math.Cos(OriginP.Z), Math.Sin(OriginP.Z)) * W;
            Box[3] = Box[0] + new Point2d(Math.Cos(OriginP.Z + Math.PI / 2), Math.Sin(OriginP.Z + Math.PI / 2)) * H;
            Box[2] = Box[1] + Box[3] - Box[0];
            return Box;
        }

        OpenCvSharp.CPlusPlus.Point ApplyMask(OpenCvSharp.CPlusPlus.Point maxPoint, Mat scaledSrcRot, Mat scaledtemp, Mat scaledMask, double maxV, out double score)
        {
            DateTime dt = DateTime.Now;
            score = maxV;

            if (scaledMask == null || scaledMask.Width == 0 || scaledMask.Height == 0)
                return maxPoint;
            if (scaledtemp == null || scaledtemp.Width != scaledMask.Width || scaledtemp.Height != scaledMask.Height)
                return maxPoint;
            int spare = 0;
            OpenCvSharp.CPlusPlus.Point newMaxPoint = maxPoint;

            using (Mat C = new Mat(scaledtemp.Size(), MatType.CV_32F))
            {
                for (int r = -spare; r <= spare; r++)
                {
                    for (int c = -spare; c <= spare; c++)
                    {
                        Mat srctmp;
                        Mat scaledMasktmp;

                        int X = maxPoint.X + c; int Y = maxPoint.Y + r;

                        Rect srcROI = new Rect(X, Y, scaledtemp.Width, scaledtemp.Height);
                        srcROI = MvFunc.GetRect(scaledSrcRot, srcROI);
                        Rect maskROI = new Rect(0, 0, scaledtemp.Width, scaledtemp.Height);

                        //if (X < 0)
                        //{
                        //    maskROI.X = -X;
                        //    srcROI.Width = maskROI.Width += X;
                        //    srcROI.X = 0;
                        //}
                        //if (Y < 0)
                        //{
                        //    maskROI.Y = -Y;
                        //    srcROI.Height = maskROI.Height += Y;
                        //    srcROI.Y = 0;
                        //}
                        //if (X + scaledtemp.Width > scaledSrcRot.Width)
                        //{
                        //    maskROI.Width = srcROI.Width = scaledtemp.Width - X;
                        //}
                        //if (Y + scaledtemp.Height > scaledSrcRot.Height)
                        //{
                        //    maskROI.Height = srcROI.Height = scaledtemp.Height - Y;
                        //}

                        srctmp = scaledSrcRot[srcROI];
                        scaledMasktmp = scaledMask[maskROI];

                        Mat maskedtmp = new Mat();
                        //SvFunc.ShowTestImg(srctmp, 1);
                        //SvFunc.ShowTestImg(scaledMask, 1);
                        srctmp.CopyTo(maskedtmp, scaledtemp);
                        //SvFunc.ShowTestImg(maskedtmp, 1);
                        //SvFunc.ShowTestImg(scaledtemp, 1);
                        Cv2.MatchTemplate(maskedtmp, scaledtemp, C, MatchMethod);
                        double min, max;
                        OpenCvSharp.CPlusPlus.Point minP, maxP;

                        maskedtmp.Dispose();
                        Cv2.MinMaxLoc(C, out min, out max, out minP, out maxP);

                        // max 와 maxPoint를 Masking 후 최대값으로 교체
                        if (max > score)
                        {
                            score = max;
                            newMaxPoint = new OpenCvSharp.CPlusPlus.Point(X, Y);
                        }
                    }
                }
            }

            //SvFunc.TimeWatch(dt, "한번더 찾는데 걸리는 시간");
            return newMaxPoint;
        }

        Point2d CalSubValue(List<Point2d> listScore, int maxIdx)
        {
            //////////////////// subpixel 적용
            //  ax^2 + bx + c = f(x)
            //  2ax + b = f'(x)
            //  |x0^2 x0 1||a|   |y0|
            //  |x1^2 x1 1||b| = |y1|
            //  |x2^2 x2 1||c|   |y2|
            ////////////////////
            //if (listScore.Count < 3) return listScore[maxIdx];
            //if (maxIdx == listScore.Count - 1)
            //    maxIdx = listScore.Count - 2;
            //if (maxIdx == 0)
            //    maxIdx = 1;//
            if (maxIdx == listScore.Count - 1 || maxIdx == 0)
                return listScore[maxIdx];

            //Point2d maxScore = listScore[maxIdx];
            double[] X = new double[3] { listScore[maxIdx - 1].X, listScore[maxIdx].X, listScore[maxIdx + 1].X };
            double[] Y = new double[3] { listScore[maxIdx - 1].Y, listScore[maxIdx].Y, listScore[maxIdx + 1].Y };

            Mat KMat = new Mat(3, 3, MatType.CV_64FC1, new double[] { X[0] * X[0], X[0], 1, X[1] * X[1], X[1], 1, X[2] * X[2], X[2], 1 });
            Mat YMat = new Mat(3, 1, MatType.CV_64FC1, Y);
            //Mat KMat = new Mat(3, 3, MatType.CV_64FC1);
            //Mat YMat = new Mat(3, 1, MatType.CV_64FC1);
            //KMat.SetArray(new double[] { X[0] * X[0], X[0], 1, X[1] * X[1], X[1], 1, X[2] * X[2], X[2], 1 });
            //YMat.SetArray(Y);

            if (KMat.Determinant() == 0)
            {
                return listScore[maxIdx];
            }
            Mat XMat = KMat.Inv() * YMat;

            double solX = -1 * XMat.At<double>(1) / XMat.At<double>(0) / 2;
            double solY = XMat.At<double>(0) * solX * solX + XMat.At<double>(1) * solX + XMat.At<double>(2);

            if (double.IsInfinity(solX) || double.IsInfinity(solY))
            {
                return listScore[maxIdx];
            }
            return new Point2d(solX, solY);
        }

        Point3d CalSubValue(Mat ScoreMat, int maxX, int maxY)
        {
            //////////////////// subpixel 적용
            //  ax^2 + bx + c = f(x)
            //  2ax + b = f'(x)
            //  |x0^2 x0 1||a|   |y0|
            //  |x1^2 x1 1||b| = |y1|
            //  |x2^2 x2 1||c|   |y2|
            ////////////////////
            //if (listScore.Count < 3) return listScore[maxIdx];
            //if (maxIdx == listScore.Count - 1)
            //    maxIdx = listScore.Count - 2;
            //if (maxIdx == 0)
            //    maxIdx = 1;//
            if (maxX == ScoreMat.Width - 1 || maxX == 0 || maxY == ScoreMat.Height - 1 || maxY == 0)
                return new Point3d(maxX, maxY, ScoreMat.At<double>(maxY, maxX));

            //double[,] aaaa = SvFunc.DisplayMat(ScoreMat);

            if (ScoreMat.At<double>(maxY, maxX - 1) == -1 || ScoreMat.At<double>(maxY, maxX + 1) == -1 || ScoreMat.At<double>(maxY - 1, maxX) == -1 || ScoreMat.At<double>(maxY + 1, maxX) == -1)
                return new Point3d(maxX, maxY, ScoreMat.At<double>(maxY, maxX));

            //if (ScoreMat.At<double>(maxY, maxX - 1) == -1)
            //    maxX += 1;
            //if (ScoreMat.At<double>(maxY, maxX + 1) == -1)
            //    maxX -= 1;
            //if (ScoreMat.At<double>(maxY - 1, maxX) == -1)
            //    maxY += 1;
            //if (ScoreMat.At<double>(maxY + 1, maxX) == -1)
            //    maxY -= 1;

            //Point2d maxScore = listScore[maxIdx];
            double[] X = new double[3] { maxX - 1, maxX, maxX + 1 };
            double[] Y = new double[3] { maxY - 1, maxY, maxY + 1 };
            double[] XZ = new double[3] { ScoreMat.At<double>(maxY, maxX - 1), ScoreMat.At<double>(maxY, maxX), ScoreMat.At<double>(maxY, maxX + 1) };
            double[] YZ = new double[3] { ScoreMat.At<double>(maxY - 1, maxX), ScoreMat.At<double>(maxY, maxX), ScoreMat.At<double>(maxY + 1, maxX) };

            Mat KXMat = new Mat(3, 3, MatType.CV_64FC1, new double[] { X[0] * X[0], X[0], 1, X[1] * X[1], X[1], 1, X[2] * X[2], X[2], 1 });
            Mat KYMat = new Mat(3, 3, MatType.CV_64FC1, new double[] { Y[0] * Y[0], Y[0], 1, Y[1] * Y[1], Y[1], 1, Y[2] * Y[2], Y[2], 1 });
            Mat XZMat = new Mat(3, 1, MatType.CV_64FC1, XZ);
            Mat YZMat = new Mat(3, 1, MatType.CV_64FC1, YZ);

            //Mat KXMat = new Mat(3, 3, MatType.CV_64FC1);
            //Mat KYMat = new Mat(3, 3, MatType.CV_64FC1);
            //Mat XZMat = new Mat(3, 1, MatType.CV_64FC1);
            //Mat YZMat = new Mat(3, 1, MatType.CV_64FC1);
            //KXMat.SetArray(new double[] { X[0] * X[0], X[0], 1, X[1] * X[1], X[1], 1, X[2] * X[2], X[2], 1 });
            //KYMat.SetArray(new double[] { Y[0] * Y[0], Y[0], 1, Y[1] * Y[1], Y[1], 1, Y[2] * Y[2], Y[2], 1 });
            //XZMat.SetArray(XZ);
            //YZMat.SetArray(YZ);
            Mat XMat = KXMat.Inv() * XZMat;
            Mat YMat = KYMat.Inv() * YZMat;

            double solX = -1 * XMat.At<double>(1) / XMat.At<double>(0) / 2;
            double solY = -1 * YMat.At<double>(1) / YMat.At<double>(0) / 2;
            double solZ = XMat.At<double>(0) * solX * solX + XMat.At<double>(1) * solX + XMat.At<double>(2);
            double solZ2 = YMat.At<double>(0) * solY * solY + YMat.At<double>(1) * solY + YMat.At<double>(2);
            return new Point3d(solX, solY, Math.Max(solZ, solZ2));
        }

        //Point2d CalSubpixel2(Mat CoeffMat, Point maxPoint)
        //{
        //    //////////////////// subpixel 적용
        //    //  ax^2 + bx + c = f(x)
        //    //  2ax + b = f'(x)
        //    //  f'(1) = 2a + b,  f'(-1) = -2a + b
        //    //  f'(0) = b
        //    //  f'(x) = 0, x = -b / 2a = -2f'(0) / (f'(1) - f'(-1)) 
        //    ////////////////////
        //    //Mat subPixel = C[maxPoint.Y - 2, maxPoint.Y + 2, maxPoint.X - 2, maxPoint.X + 2];
        //    //Mat kernel = new Mat(3, 3, MatType.CV_8UC1, new double[] { 0, -0.5, 0, -0.5, 0, 0.5, 0});
        //    //src_ROI.Filter2D(-1, kernel, new Point(-1, -1));
        //    const int cp = 4;
        //    if (maxPoint.X - cp < 0 || maxPoint.Y - cp < 0 || maxPoint.X + cp > CoeffMat.Width - 1 || maxPoint.Y - cp > CoeffMat.Height)
        //        return new Point2d(maxPoint.X, maxPoint.Y);

        //    Mat C = CoeffMat[maxPoint.Y - cp, maxPoint.Y + cp, maxPoint.X - cp, maxPoint.X + cp].Clone();
        //    C = C.GaussianBlur(new Size(3, 3), 1);
        //    float[] dfX = new float[3];
        //    float[] dfY = new float[3];
        //    for (int i = -1; i < 2; i++)
        //    {
        //        dfX[1 + i] = (C.At<float>(cp, cp + i + 1) - C.At<float>(cp, cp + i - 1)) / 2;
        //        dfY[1 + i] = (C.At<float>(cp + i + 1, cp) - C.At<float>(cp + i - 1, cp)) / 2;
        //    }
        //    double dX = -2 * dfX[1] / (dfX[2] - dfX[0]);
        //    double dY = -2 * dfY[1] / (dfY[2] - dfY[0]);
        //    SvLogger.Log.Debug(string.Format("Second : ({0:0.000}, {1:0.000})", dX, dY));
        //    C.Dispose();
        //    return new Point2d(maxPoint.X + dX, maxPoint.Y + dY);
        //}

        Point2d CalSubpixel3(Mat CoeffMat, OpenCvSharp.CPlusPlus.Point maxPoint)
        {
            //////////////////// subpixel 적용
            //  ax^3 + bx^2 + cx + d = f(x)
            //  3ax^2 + 2bx + c = f'(x)
            //  f'(1) = 3a + 2b + c,  f'(-1) = 3a - 2b + c
            //  f'(0) = c,
            //  f'(1) - f'(-1) = 4b,
            //  f'(1) + f'(-1) - 2f'(0) = 6a
            //  f'(x) = 0, x = (-b + sqrt(b^2 - 3ac)) / 3a 
            ////////////////////
            //Mat subPixel = C[maxPoint.Y - 2, maxPoint.Y + 2, maxPoint.X - 2, maxPoint.X + 2];
            //Mat kernel = new Mat(3, 3, MatType.CV_8UC1, new double[] { 0, -0.5, 0, -0.5, 0, 0.5, 0});
            //src_ROI.Filter2D(-1, kernel, new Point(-1, -1));
            const int cp = 4;
            if (maxPoint.X - cp < 0 || maxPoint.Y - cp < 0 || maxPoint.X + cp > CoeffMat.Width - 1 || maxPoint.Y + cp > CoeffMat.Height - 1)
                return new Point2d(maxPoint.X, maxPoint.Y);

            Mat C = CoeffMat[maxPoint.Y - cp, maxPoint.Y + cp, maxPoint.X - cp, maxPoint.X + cp].Clone();
            C = C.GaussianBlur(new OpenCvSharp.CPlusPlus.Size(3, 3), 1);
            float[] dfX = new float[3];
            float[] dfY = new float[3];
            for (int i = -1; i < 2; i++)
            {
                dfX[1 + i] = (C.At<float>(cp, cp + i + 1) - C.At<float>(cp, cp + i - 1)) / 2;
                dfY[1 + i] = (C.At<float>(cp + i + 1, cp) - C.At<float>(cp + i - 1, cp)) / 2;
            }
            double a, b, c, dX, dY;
            c = dfX[1];
            b = (dfX[2] - dfX[0]) / 4;
            a = (dfX[2] + dfX[0] - 2 * c) / 6;
            if (a == 0)
                dX = 0;
            else
                dX = (b < 0) ? (-b - Math.Sqrt(b * b - 3 * a * c)) / 3 / a : (-b + Math.Sqrt(b * b - 3 * a * c)) / 3 / a;
            c = dfY[1];
            b = (dfY[2] - dfY[0]) / 4;
            a = (dfY[2] + dfY[0] - 2 * c) / 6;
            if (a == 0)
                dY = 0;
            else
                dY = (b < 0) ? (-b - Math.Sqrt(b * b - 3 * a * c)) / 3 / a : (-b + Math.Sqrt(b * b - 3 * a * c)) / 3 / a;

            if (Math.Abs(dX) > 1 || double.IsNaN(dX)) dX = 0;
            if (Math.Abs(dY) > 1 || double.IsNaN(dY)) dY = 0;

            //SvLogger.Log.Debug(string.Format("dfX[0]: {0:0.000}, dfX[1]: {1:0.000}, dfX[2]: {2:0.000})", dfX[0], dfX[1], dfX[2]));
            //SvLogger.Log.Debug(string.Format("dfY[0]: {0:0.000}, dfY[1]: {1:0.000}, dfY[2]: {2:0.000})", dfY[0], dfY[1], dfY[2]));
            //SvLogger.Log.Debug(string.Format("Third : ({0:0.000}, {1:0.000})", dX, dY));
            //System.Diagnostics.Debug.WriteLine(string.Format("dfX[0]: {0:0.000}, dfX[1]: {1:0.000}, dfX[2]: {2:0.000})", dfX[0], dfX[1], dfX[2]));
            //System.Diagnostics.Debug.WriteLine(string.Format("dfY[0]: {0:0.000}, dfY[1]: {1:0.000}, dfY[2]: {2:0.000})", dfY[0], dfY[1], dfY[2]));
            //System.Diagnostics.Debug.WriteLine(string.Format("Third : ({0:0.000}, {1:0.000})", dX, dY));
            C.Dispose();
            return new Point2d(maxPoint.X + dX, maxPoint.Y + dY);
        }

        public void GetEdge(Mat SrcImg, int minSize, out Mat Edge, double scale, int backcolor = 0, ThresholdType THtype = ThresholdType.Binary)
        {
            MvFunc.StartWatch("GetEdge");
            if (SrcImg == null || SrcImg.Width == 0 || SrcImg.Height == 0)
            {
                Edge = null;
                return;
            }


            if (lut == null)
            {
                lut = new byte[256];
                for (int i = 0; i < lut.Length; i++)
                {
                    if (i < 250)
                        lut[i] = 0;
                    else
                        lut[i] = (byte)i;

                }
            }

            SrcImg.Blur(new OpenCvSharp.CPlusPlus.Size(3, 3));
            Edge = SrcImg.AdaptiveThreshold(255, AdaptiveThresholdType.GaussianC, ThresholdType.BinaryInv, 5, 10);
            Edge.LUT(lut);
            MvFunc.StopWatch();
            return;

            /*
            MatType matType = MatType.CV_32FC1;
            Mat src = new Mat();
            Mat sobelX = new Mat();
            Mat sobelY = new Mat();
            Mat sobel = new Mat();
            Edge = new Mat(SrcImg.Size(), SrcImg.Type(), 0);

            // Canny Edge
            int ksize = 2 * Cv.Round(4 * scale) + 1;
            if (ksize > 5) ksize = 5;
            if (ksize < 3) ksize = 3;

            //SvFunc.ShowTestImg(SrcImg, 0.5);
            Cv2.Blur(SrcImg, Edge, new Size(ksize, ksize));
            Cv2.Canny(Edge, Edge, thLow, thHigh, 3, false);

            // Soble Edge
            //SrcImg.ConvertTo(src, matType);
            //int ksize = 1;// 2 * Cv.Round(5 * scale) + 1;
            //Cv2.Sobel(src, sobelX, matType, 1, 0, ksize);
            //Cv2.Sobel(src, sobelY, matType, 0, 1, ksize);

            //sobel = (Cv2.Abs(sobelX) + Cv2.Abs(sobelY));
            //sobel.ConvertTo(Edge, SrcImg.Type());
            //Cv2.Threshold(Edge, Edge, thLow, thHigh, THtype);
            /////////////////////////////////////

            IplImage ipl_BinImage = Edge.ToIplImage(false);

            CvBlobs cvBlobs = new CvBlobs(ipl_BinImage);
            List<CvBlob> listblob = cvBlobs.Values.ToList<CvBlob>();
            listblob.Sort((a, b) => (a.Area > b.Area) ? -1 : 1);
            CvBlobs newBlobs = new CvBlobs();
            for (int i = 0; i < listblob.Count; i++)
            {
                if (i > 200) cvBlobs.Remove(listblob[i].Label);
            }
            IplImage Edgeipl = new IplImage(Edge.Size(), BitDepth.U8, 1);
            double blobEraserSize = Cv.Round(minSize * scale * 0.1);
            
            cvBlobs.FilterLabels(Edgeipl);
            //SvFunc.ShowTestImg(Edge, 1);
            Edge.Dispose();
            Edge = new Mat(Edgeipl, true);

            Cv2.Blur(Edge, Edge, new Size((ksize + 1) / 2, (ksize + 1) / 2));
            Cv2.Threshold(Edge, Edge, 1, int.MaxValue, THtype);

            //Edge = Edge + backcolor;
            //SvFunc.ShowTestImg(Edge, 1);
            ipl_BinImage.Dispose();
            Edgeipl.Dispose();//Dispose시키면 큰일난다...

            //SvFunc.ShowTestImg(Edge, 1);

            //Mat element = Cv2.GetStructuringElement(StructuringElementShape.Rect, new Size(5, 5));
            //Cv2.MorphologyEx(sobel, sobel, MorphologyOperation.Open, element);

            //Cv2.Laplacian(Edge, Edge, -1, 1, 10, 5);
            SvFunc.StopWatch();

            //element.Dispose();
            src.Dispose();
            sobelX.Dispose();
            sobelY.Dispose();
            sobel.Dispose();
            return;
			*/
        }

        public void GetEdge_(Mat SrcImg, int minSize, out Mat Edge, double scale, int backcolor = 0, ThresholdType THtype = ThresholdType.Binary)
        {
            MvFunc.StartWatch("GetEdge");
            if (SrcImg == null || SrcImg.Width == 0 || SrcImg.Height == 0)
            {
                Edge = null;
                return;
            }

            OpenCvSharp.CPlusPlus.Size tempsz = tempImg.Mat.Size();
            HOGDescriptor hog = new HOGDescriptor(SrcImg.Size(), new OpenCvSharp.CPlusPlus.Size(tempsz.Width, tempsz.Height));

            Mat grad = new Mat();
            Mat angleOfs = new Mat();
            Mat[] gg = new Mat[2];
            Mat[] aa = new Mat[2];

            hog.ComputeGradient(SrcImg, grad, angleOfs);
            Cv2.Split(grad, out gg);
            Cv2.Split(angleOfs, out aa);

            KeyPoint[] surfPts;
            float[][] descripter;

            KeyPoint[] keyPoints;
            BRISK BriskDetector = new BRISK();
            //BRISK BriskDetector = BRISK.Create();
            keyPoints = BriskDetector.Detect(SrcImg);
            Mat KeyPmat = new Mat(SrcImg.Size(), MatType.CV_8UC3);
            Cv2.DrawKeypoints(SrcImg, keyPoints, KeyPmat, new Scalar(255, 0, 0), DrawMatchesFlags.Default);
            Edge = null;
            //Edge = KeyPmat.Split()
            //SvFunc.ShowTestImg(Edge, 0.25);

            //CvSURFParams surfParams = Cv.SURFParams(100, false);
            //Cv.ExtractSURF(SrcImg.ToIplImage(false), null, out surfPts, out descripter, surfParams);


            //IplImage EdgeIpl = new IplImage();
            //Edge = new Mat(EdgeIpl, false);

            //SvFunc.ShowTestImg(Edge, 0.25);
            //gg[0].ConvertTo(Edge, MatType.CV_8UC1);

            //SvFunc.ShowTestImg(gg[0], 0.25);
            //Edge = gg[0];





            return;
        }

        public void GetEdge(Mat SrcImg, out Mat Edge, int threshMin, int threshMax)
        {
            MvFunc.StartWatch("GetEdge");
            if (SrcImg == null || SrcImg.Width == 0 || SrcImg.Height == 0)
            {
                Edge = null;
                return;
            }

            if (lut == null)
            {
                lut = new byte[256];
                for (int i = 0; i < lut.Length; i++)
                {
                    if (i < 250)
                        lut[i] = 0;
                    else
                        lut[i] = (byte)i;

                }
            }

            Mat canny = new Mat();
            //SrcImg.Blur(new cv.Size(3, 3));
            Edge = SrcImg.AdaptiveThreshold(255, AdaptiveThresholdType.GaussianC, ThresholdType.BinaryInv, 5, 10);
            Edge.LUT(lut);
            /// using the canny algorithm to get edges
            Cv2.Canny(SrcImg, canny, threshMin, threshMax, 3, false);
            //Cv2.FindContours(canny, out var contours, out var hierarchy, RetrievalModes.External, ContourApproximationModes.ApproxSimple);
            Cv2.FindContours(canny, out var contours, out var hierarchy, ContourRetrieval.External, ContourChain.ApproxNone);
            Cv2.DrawContours(Edge, contours, -1, Scalar.LightGreen, 2);
            //Cv2.ImShow("Edge", Edge);
            //Cv2.WaitKey(5000);
            MvFunc.StopWatch();
            return;


        }
        public void GetEdge(Mat SrcImg, out Mat Edge)
        {
            MvFunc.StartWatch("GetEdge");
            if (SrcImg == null || SrcImg.Width == 0 || SrcImg.Height == 0)
            {
                Edge = null;
                return;
            }

            if (lut == null)
            {
                lut = new byte[256];
                for (int i = 0; i < lut.Length; i++)
                {
                    if (i < 250)
                        lut[i] = 0;
                    else
                        lut[i] = (byte)i;

                }
            }
            Edge = new Mat(SrcImg.Size(), MatType.CV_8UC1, new Scalar(0));
            Mat canny = new Mat();
            //SrcImg.Blur(new cv.Size(3, 3));
            //Edge = SrcImg.AdaptiveThreshold(255, AdaptiveThresholdType.GaussianC, ThresholdType.BinaryInv, 5, 10);
            //Edge.LUT(lut);

            /// using the canny algorithm to get edges
            //Cv2.Canny(SrcImg, canny, threshMin, threshMax, 3, false);
            //Cv2.FindContours(canny, out var contours, out var hierarchy, RetrievalModes.External, ContourApproximationModes.ApproxSimple);
            //Cv2.FindContours(canny, out var contours, out var hierarchy, ContourRetrieval.External, ContourChain.ApproxNone);
            //OpenCvSharp.CPlusPlus.Point[][] contours = Halcons[0].TrainContours.Select(contour =>contour.Select(p =>new OpenCvSharp.CPlusPlus.Point(p.X - origin.X,p.Y - origin.Y)).ToArray()).ToArray();
            OpenCvSharp.CPlusPlus.Point[][] contours = Halcons.TrainContours.Select(contour => contour.ToArray()).ToArray();
            Cv2.DrawContours(Edge, contours, -1, Scalar.LightGreen, 2);
            //Cv2.ImShow("Edge", Edge);
            //Cv2.WaitKey(5000);
            MvFunc.StopWatch();
            return;
        }


    }

    //[Serializable]
    //public class PatternData : ISerializable, IDisposable
    //{
    //    public MvImage PatternImage;
    //    public MvMask MaskImage;
    //    public MvPoint RefPoint;
    //    public Mat MaskedPattern;

    //    public PatternData()
    //    { }

    //    public PatternData(MvImage _pattern, MvMask _mask = null, MvPoint _point = null)
    //    {
    //        if (_pattern == null)
    //            return;
    //        else
    //            PatternImage = _pattern.Clone(true);

    //        if (_mask == null || _mask.MaskMat.Width != PatternImage.Width || _mask.MaskMat.Height != PatternImage.Height)
    //            MaskImage = new MvMask(_pattern.Width, _pattern.Height);
    //        else
    //            MaskImage = _mask.Clone();

    //        if (_point == null)
    //            RefPoint = new MvPoint(_pattern.Width / 2, _pattern.Height / 2);
    //        else
    //            RefPoint = new MvPoint(_point.Point3d);
    //    }

    //    public PatternData(SerializationInfo info, StreamingContext context)
    //    {
    //        MvSerializer.Deserializeing(this, info, context);
    //    }

    //    [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Demand, SerializationFormatter = true)]
    //    public void GetObjectData(SerializationInfo info, StreamingContext context)
    //    {
    //        MvSerializer.Serializeing(this, info, context);
    //    }

    //    public void MakeMaskedPattern()
    //    {
    //        if (PatternImage.Mat != null && MaskImage.MaskMat != null)
    //        {
    //            //MaskedPattern = PatternImage.Mat.Clone();
    //            if (MaskedPattern != null)
    //                MaskedPattern.Dispose();
    //            MaskedPattern = new Mat();
    //            PatternImage.Mat.CopyTo(MaskedPattern, MaskImage.MaskMat);
    //            double mean = (double)MaskedPattern.Mean(MaskImage.MaskMat);
    //            //Cv2.ScaleAdd(new Scalar(255) - MaskImage.MaskMat, mean / 255.0, MaskedPattern, MaskedPattern); // Area mask color Gray
    //            Cv2.ScaleAdd(new Scalar(255) - MaskImage.MaskMat, 0, MaskedPattern, MaskedPattern); // Area mask color Black




    //            //SvFunc.ShowTestImg(PatternImage.Mat, 1);
    //            //SvFunc.ShowTestImg(MaskImage.MaskMat, 1);
    //            //SvFunc.ShowTestImg(new Scalar(255) - MaskImage.MaskMat, 1);
    //            //SvFunc.ShowTestImg(MaskedPattern, 1);
    //            //Cv2.ImShow("mask1", MaskedPattern);
    //            //Cv2.WaitKey(3000);
    //        }
    //    }

    //    public bool SavePattern(string _path)
    //    {
    //        MvSerializer serialize = new MvSerializer();
    //        return serialize.Serializing(_path, this);
    //    }

    //    public void Dispose()
    //    {
    //        if (PatternImage != null) PatternImage.Dispose();
    //        if (MaskImage != null) MaskImage.Dispose();
    //    }
    //}
}
