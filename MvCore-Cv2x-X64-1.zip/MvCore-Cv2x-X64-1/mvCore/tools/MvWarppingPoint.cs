﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenCvSharp;
using OpenCvSharp.CPlusPlus;
using System.Runtime.Serialization;
using System.Windows.Forms;
//using MvCore.Common;
using System.Drawing;


namespace MvCore
{
    [Serializable]
    public class MvWarppingPoint : MvToolBase
    {
        public MvWarppingPoint()
        {
            calibrationData = new MvCalibrationData();
        }
        public MvWarppingPoint(SerializationInfo info, StreamingContext context) : base(info, context) { }

        #region InParams
        
        public override void InitInParmas()
        {
            inParams.Add("InputImage", null);
            inParams.Add("InputPoint", null);
        }

        [InputParam]
        public MvImage InputImage { get; set; }

        MvPoint inputPoint;
        [InputParam]
        public MvPoint InputPoint
        {
            get
            {
                if (inputPoint == null) return null;

                Point3d p = MvFunc.ImageToFixture3D(MvFunc.FixtureToImage3D(inputPoint.Point3d, inputPoint.TransformMat), InputImage.TransformMat);
                MvPoint outP = new MvPoint(p.X, p.Y, p.Z);
                outP.TransformMat = InputImage.TransformMat;
                return outP;
            }
            set
            {
                inputPoint = value;
            }
        }

        MvCalibrationData calibrationData;
        public MvCalibrationData CalibrationData
        {
            get { return calibrationData; }
            set
            {
                calibrationData = value;
                mCalibrationMat = calibrationData.VtoRMat.Mat;
            }
        }
        #endregion

        #region OutParams

        public override void InitOutParmas()
        {
            outParams.Add("OutputPoint", null);
        }
        
        MvPoint outputPoint;
        [OutputParam]
        public MvPoint OutputPoint
        {
            get { return outputPoint; }
            set { outputPoint = value; }
        }

        [OutputParam]
        public float[] CalibrationMatF
        {
            get
            {
                if (calibrationData == null || calibrationData.VtoRMat == null)
                    return null;
                mCalibrationMat = calibrationData.VtoRMat.Mat;
                float[] calMatseries = new float[9];
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        calMatseries[i * 3 + j] = (float)mCalibrationMat.At<double>(i, j);
                    }
                }
                return calMatseries;
            }
            set { }
        }
        [NonSerialized]
        Mat mCalibrationMat;
        #endregion

        SvImageInfo inputImageInfo;
        public override void InitImageList()
        {
            inputImageInfo = new SvImageInfo(string.Format("[{0}] InputImage", this.ToString()));
            imageList.Add(inputImageInfo);
        }

        public override void InitOutProperty()
        {
            OutputPoint = null;
            lastRunSuccess = false;
        }

        public void DrawInOutPoint(Display.MvDisplayView display)
        {
            if (!MvFunc.IsPossibleImage(InputImage))
                return;
            //display.GraphicsFuncCollection.Clear();
            if (InputPoint == null) return;

            InputPoint.Display = display as Display.MvDisplayViewInteract;
            display.GraphicsCollection.Add(InputPoint);
            
            //if (OutputPoint != null)
            //{
            //    OutputPoint.Display = display as Display.SvDisplayViewInteract;
            //    OutputPoint.Color = Color.Cyan;
            //    display.GraphicsCollection.Add(OutputPoint);
            //}

            double size = 1000;

            Point2d originPt = RtoV(new Point2d(0, 0));
            Point2d widthPt = RtoV(new Point2d(size, 0));
            Point2d heightPt = RtoV(new Point2d(0, size));
            double scale = Math.Min(Math.Abs(InputImage.Width / widthPt.DistanceTo(originPt)), Math.Abs(InputImage.Height / heightPt.DistanceTo(originPt)));

            //double dd = widthPt.DistanceTo(originPt);
            //double d = heightPt.DistanceTo(originPt);
            size *= scale * 0.5;

            Pen px = new Pen(Brushes.Cyan, 1 / display.ZoomRatio);
            px.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            
            display.DrawLine(px, RtoV(new Point2d(-size, 0)), RtoV(new Point2d(size, 0)));
            display.DrawLine(px, RtoV(new Point2d(-size, size)), RtoV(new Point2d(size, size)));
            display.DrawLine(px, RtoV(new Point2d(-size, -size)), RtoV(new Point2d(size, -size)));

            Pen py = new Pen(Brushes.Red, 1 / display.ZoomRatio);
            py.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            display.DrawLine(py, RtoV(new Point2d(0, -size)), RtoV(new Point2d(0, size)));
            display.DrawLine(py, RtoV(new Point2d(size, -size)), RtoV(new Point2d(size, size)));
            display.DrawLine(py, RtoV(new Point2d(-size, -size)), RtoV(new Point2d(-size, size)));

            float fontSize = 8;

            widthPt = RtoV(new Point2d(size, 0));
            heightPt = RtoV(new Point2d(0, size));

            Font font = new System.Drawing.Font("굴림", fontSize,System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel);
            display.DrawString("X", font, Brushes.Cyan, new Point2d(widthPt.X, widthPt.Y - fontSize / display.ZoomRatio / 2));
            display.DrawString("Y", font, Brushes.Cyan, new Point2d(heightPt.X - fontSize / display.ZoomRatio / 2, heightPt.Y));

            display.DrawString(size.ToString("f3"), font, Brushes.Cyan, widthPt + new Point2d(font.Size, font.Size));
            display.DrawString(size.ToString("f3"), font, Brushes.Cyan, heightPt + new Point2d(font.Size, font.Size));
            display.DrawString(string.Format("In: ({0:f3}, {1:f3}, {2:f3})", InputPoint.X, InputPoint.Y, InputPoint.ThetaRad * 180 / Math.PI), font, Brushes.Red, new Point2d(InputPoint.X, InputPoint.Y - font.Size / display.ZoomRatio - 2));
            display.DrawString(string.Format("Out: ({0:f3}, {1:f3}, {2:f3})", OutputPoint.X, OutputPoint.Y, OutputPoint.ThetaRad * 180 / Math.PI), font, Brushes.Cyan, new Point2d(InputPoint.X, InputPoint.Y + 2));

        }

        public override void Run(bool isEditMode = false)
        {
            if (InputImage == null) return;

            inputImageInfo.Image = InputImage;

            if (InputPoint != null && inParams.ContainsKey("InputPoint"))
            {
                OutputPoint = VtoR(inputPoint);
                inputImageInfo.drawingFunc = DrawInOutPoint;
            }
            lastRunSuccess = true;
        }


        public MvPoint VtoR(MvPoint vision, bool isWarp = true)
        {
            if (calibrationData == null || calibrationData.VtoRMat == null)
                throw new Exception("VtoRMat is null");

            if (vision == null) return null;

            Point2d vision2d = new Point2d(vision.X, vision.Y);

            // 로봇 좌표계 T축 보정 시작
            Point2d RobotP0, RobotP1, RobotP2, RobotZeroDirection;
            double dT;

            if (isWarp) // [Vision의 수직도 < 로봇의 X,Y 직각도 라고 판단] => 로봇 좌표계에서 각도 측정
            {
                double L = 1000;
                List<Point2d> X = new List<Point2d>();
                X.Add(RtoV(new Point2d(L, 0)));
                X.Add(RtoV(new Point2d(-L, 0)));
                X.Add(RtoV(new Point2d(0, L)));
                X.Add(RtoV(new Point2d(0, -L)));
                //X.Add(RtoV(new Point2d(0, 0)));

                X.Sort((a, b) => a.X > b.X ? -1 : 1);

                RobotZeroDirection = VtoR(X[0]);
                //if (X[0].X == 0) RobotZeroDirection = RtoV(new Point2d(L, 0));
                //else if (X[0].X == 1) RobotZeroDirection = RtoV(new Point2d(-L, 0));
                //else if (X[0].X == 2) RobotZeroDirection = RtoV(new Point2d(0, L));
                //else RobotZeroDirection = RtoV(new Point2d(0, -L));
                
                RobotP0 = VtoR(vision2d);
                //RobotP1 = VtoR(vision2d)/*Vision -> Robot*/ + RobotZeroDirection/*Robot*/;
                RobotP1 = RobotZeroDirection;
                RobotP2 = VtoR(vision2d + new Point2d(L * Math.Cos(vision.ThetaRad), L * Math.Sin(vision.ThetaRad)));
                RobotP2 = RobotP2 - RobotP0;
                double dsin = (RobotP1.X * RobotP2.Y - RobotP1.Y * RobotP2.X);
                double dcos = (RobotP1.X * RobotP2.X + RobotP1.Y * RobotP2.Y);
                dT = Math.Atan2(dsin, dcos);
                double dd = dT * 180 / Math.PI;

                //RobotP1 = RobotZeroDirection;
                //RobotP2 = VtoR(RtoV(new Point2d(0, 0)) + new Point2d(L, 0)); //Vision 0도일때 좌표
                //dsin = (RobotP1.X * RobotP2.Y - RobotP1.Y * RobotP2.X);
                //dcos = (RobotP1.X * RobotP2.X + RobotP1.Y * RobotP2.Y);
                //dT -= Math.Atan2(dsin, dcos);

                //dd = dT * 180 / Math.PI;
            }
            else // [Vision의 수직도 > 로봇의 X,Y 직각도 라고 판단] => 비젼 좌표계에서 각도 측정후 부호 반전
            {
                RobotP0 = VtoR(vision2d);
                dT = ((calibrationData.AngleTo - calibrationData.AngleFrom) / (calibrationData.RotPoints[calibrationData.RotPoints.Count - 1].Z - calibrationData.RotPoints[0].Z) > 0) ? vision.ThetaRad : -vision.ThetaRad;  
            }

            //System.Diagnostics.Debug.WriteLine(string.Format("로봇 좌표 : ({0:0.00}, {1:0.00}), 각도 : {2:0.00}", RobotP0.X, RobotP0.Y, dT));

            //return new Point3d(vision2d.X, vision2d.Y, dT);
            MvPoint robot = new MvPoint(RobotP0.X, RobotP0.Y, dT);
            return robot;
        }

        /// <summary>
        /// Vision 좌표 -> Robot 좌표 변환 (CalCalib)
        /// </summary>
        /// <param name="Vision">Visio 좌표</param>
        /// <returns>Robot 좌표</returns>
        public Point2d VtoR(Point2d vision)
        {
            if (calibrationData.VtoRMat == null)
                throw new Exception("VtoRMat is null");

            Mat visionMat = new Mat(3, 1, MatType.CV_64FC1, new double[] { vision.X, vision.Y, 1.0 });
            //Mat visionMat = new Mat(3, 1, MatType.CV_64FC1);
            //visionMat.SetArray(new double[] { vision.X, vision.Y, 1.0 });
            visionMat = calibrationData.VtoRMat.Mat * visionMat;

            return new Point2d(visionMat.At<double>(0, 0) / visionMat.At<double>(2, 0), visionMat.At<double>(1, 0) / visionMat.At<double>(2, 0));
        }

        /// <summary>
        /// Robot 좌표 -> Vision 좌표 변환 (InverseCalCalib)
        /// </summary>
        /// <param name="Robot">Robot 좌표</param>
        /// <returns>Vision 좌표</returns>
        public Point2d RtoV(Point2d robot)
        {
            if (calibrationData.VtoRMat == null)
                throw new Exception("VtoRMat is null");

            Mat RtoVMat = GetRtoVMat();
            Mat RobotMat = new Mat(3, 1, MatType.CV_64FC1, new double[] { robot.X, robot.Y, 1.0 });
            //Mat RobotMat = new Mat(3, 1, MatType.CV_64FC1);
            //RobotMat.SetArray(new double[] { robot.X, robot.Y, 1.0 });


             RobotMat = RtoVMat * RobotMat;
            RtoVMat.Dispose();
            Point2d resultPt = new Point2d(RobotMat.At<double>(0, 0) / RobotMat.At<double>(2, 0), RobotMat.At<double>(1, 0) / RobotMat.At<double>(2, 0));
            return resultPt;
        }

        /// <summary>
        /// Vision 좌표 -> Robot 좌표 변환 행렬 반환
        /// </summary>
        /// <returns>VtoR 변환행렬</returns>
        public Mat GetVtoRMat()
        {
            return calibrationData.VtoRMat.Mat;
        }

        /// <summary>
        /// Robot 좌표 -> Vision 좌표 변환 
        /// </summary>
        /// <returns>RtoV 변환행렬</returns>
        public Mat GetRtoVMat()
        {
            return calibrationData.VtoRMat.Mat.Inv();
        }
    }
}
