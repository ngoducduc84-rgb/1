﻿using log4net.Util;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MvCore.util
{
    [Serializable]
    public class LogFile
    {
        #region Print
        public void ScrollToBottom(RichTextBox richTextBox)
        {
            richTextBox.SelectionStart = richTextBox.Text.Length;
            richTextBox.ScrollToCaret();
        }
        public  void ScrollToBottom(ListBox listBox)
        {
            if (listBox.Items.Count > 0)
            {
                if (listBox.Items.Count > 50)
                    listBox.Items.RemoveAt(0);
                listBox.TopIndex = listBox.Items.Count - 1;

            }
        }
        //public void print(string data, bool show = false)
        //{
        //    if (show == true)
        //    {
        //        // lb_console.Items.Add(DateTime.Now.ToString("dd/MM/yy-HH:mm:ss: ") + data);
        //        lb_log.Items.Add(DateTime.Now.ToString("dd/MM/yy-HH:mm:ss: ") + data);
        //        // ScrollToBottom(lb_console);
        //        ScrollToBottom(lb_log);
        //    }
        //    saveLog(data);
        //    //lb_console.Items.Add(DateTime.Now.ToString("HH:mm:ss: ") + data);
        //}
        //void prints(string str)
        //{
        //    string time = DateTime.Now.ToString("HH:mm::ss");
        //    string data = string.Format($"[{time}]: {str}");
        //    this.Invoke((MethodInvoker)(() =>
        //    {
        //        if (lb_console.Items.Count > 300)
        //        {
        //            lb_console.Items.RemoveAt(0);
        //        }
        //        lb_console.Items.Add(data);
        //        file.WriteLog(data);
        //    }));
        //}
        public  void ShowNotification(string message, string Notication = "Notification_", ToolTipIcon icon = ToolTipIcon.Error)
        {
            // Tạo một NotifyIcon mới
            NotifyIcon notificationIcon = new NotifyIcon();
            notificationIcon.Icon = SystemIcons.Information;
            notificationIcon.Visible = true;

            // Hiển thị thông báo
            notificationIcon.ShowBalloonTip(10, Notication, message, icon);

            // Sau khi hiển thị xong, giải phóng NotifyIcon
            notificationIcon.Dispose();
        }
        public void saveLog(string logData)
        {
            string applicationPath = System.IO.Directory.GetCurrentDirectory(); // lấy đường dẫn app hiện tại
            string logFilePath = applicationPath + $"\\log\\{DateTime.Now.ToString("dd_MM_yyyy")}.txt";
            string folderPath = applicationPath + @"\log";
            // Kiểm tra nếu thư mục không tồn tại, hãy tạo nó
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
                Console.WriteLine("Folder Log created successfully.");
            }
            try
            {
                if (File.Exists(logFilePath))
                {
                    // Mở hoặc tạo file log
                    using (StreamWriter writer = File.AppendText(logFilePath))
                    {
                        // Ghi log
                        writer.WriteLine($"{DateTime.Now} - {logData}");
                    }
                }
                else
                {
                    File.Create(logFilePath).Close(); // Tạo file mới rồi đóng lại
                    // Mở hoặc tạo file log
                    using (StreamWriter writer = File.AppendText(logFilePath))
                    {
                        // Ghi log
                        writer.WriteLine($"{DateTime.Now} - {logData}");
                    }
                }
            }
            catch (Exception ex)
            {
                //ShowNotification(ex.Message);

            }
        }

        bool msg(string messeger)
        {
            var result = MessageBox.Show(messeger, "confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                return true;
            }
            else if (result == DialogResult.No)
            {
                return false;
            }
            return false;
        }
        #endregion
    }
}
