﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MvCore;

namespace MvCore.Util
{
    public partial class MvLoadingForm : Form
    {
        public MvLoadingForm()
        {
            InitializeComponent();
        }
    }
}
