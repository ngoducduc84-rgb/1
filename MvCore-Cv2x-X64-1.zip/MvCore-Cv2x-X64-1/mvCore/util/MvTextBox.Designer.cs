﻿namespace MvCore.Util
{
    partial class MvTextBox
    {
        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.textbox = new System.Windows.Forms.TextBox();
            this.btn_Calculator = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textbox
            // 
            this.textbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textbox.Location = new System.Drawing.Point(20, 20);
            this.textbox.Name = "textbox";
            this.textbox.Size = new System.Drawing.Size(24, 13);
            this.textbox.TabIndex = 0;
            this.textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Calculator
            // 
            this.btn_Calculator.BackgroundImage = global::MvCore.Properties.Resources.Calculator_icon;
            this.btn_Calculator.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Calculator.Cursor = System.Windows.Forms.Cursors.Default;
            this.btn_Calculator.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_Calculator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Calculator.Location = new System.Drawing.Point(43, 0);
            this.btn_Calculator.Name = "btn_Calculator";
            this.btn_Calculator.Size = new System.Drawing.Size(19, 52);
            this.btn_Calculator.TabIndex = 1;
            this.btn_Calculator.UseVisualStyleBackColor = true;
            // 
            // SvTextBox
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.btn_Calculator);
            this.Controls.Add(this.textbox);
            this.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Name = "SvTextBox";
            this.Size = new System.Drawing.Size(62, 52);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textbox;
        private System.ComponentModel.IContainer components;
        private System.Windows.Forms.Button btn_Calculator;
    }
}
