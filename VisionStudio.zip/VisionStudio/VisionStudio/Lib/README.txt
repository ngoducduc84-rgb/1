CHÉP VÀO THƯ MỤC NÀY (từ bản cài Halcon 18.11 của bạn):

  halcondotnet.dll   <- %HALCONROOT%\bin\dotnet35\halcondotnet.dll   (hoặc dotnet40)
  halcon.dll         <- %HALCONROOT%\bin\x64-win64\halcon.dll         (native, tuỳ chọn: csproj tự chép cạnh .exe nếu có)

Lưu ý:
 - File halcondotnet.dll trong MvCore-Cv2x-X64-1.zip là bản 19.11 (không phải 18.11) → KHÔNG dùng cho dự án này.
 - Build x64. Máy chạy cần Halcon runtime + license (HALCONROOT trong PATH).
