# VisionStudio

Phần mềm vision tổng hợp từ 4 dự án (IVA_Bplus, IVA-A_SDV/SvMip, MvCore, VisionAutoCode), viết lại thành một ứng dụng WPF thống nhất, **xử lý ảnh hoàn toàn bằng Halcon**.

| Yêu cầu | Cách thực hiện |
|---|---|
| Giao diện tham khảo IVA_Bplus | Bố cục Designer: Toolbox · Flowchart (Procedure → Tool) · Image view · Property panel · Log · Scheduler/Trigger/Comm (xem "Về giao diện IVA B+" bên dưới) |
| Halcon 18.11 (chỉ cần halcon.dll + halcondotnet.dll) | Không dùng thư viện ảnh nào khác. Camera qua Halcon frame grabber. Xem `Lib/README.txt` |
| Align dẫn hướng, inspection, blob, measurement, find line… | 43 tool, xem `docs/TOOL_MATRIX.md` |
| Màu sắc VisionAutoCode | Dark/Light dùng đúng bảng màu `AppColorTheme` (`Themes/Dark.xaml`, `Light.xaml`), nút ◐ Theme để đổi |
| Đầy đủ tool của 4 file, sửa tool nếu không hợp lý | Bảng đối chiếu từng tool gốc → tool mới (hoặc lý do chưa port) ở `docs/TOOL_MATRIX.md` |

## Build
1. Chép `halcondotnet.dll` (+ `halcon.dll`) Halcon **18.11** vào `Lib/` (xem `Lib/README.txt`).
2. Visual Studio 2019/2022 (workload .NET desktop, targeting pack .NET Framework 4.8) → mở `VisionStudio.sln`, cấu hình **x64**, Build. (NuGet: chỉ `Newtonsoft.Json`.)
3. Chạy `VisionStudio.App`. Cần Halcon runtime + license trên máy.

> ⚠ Mã này được viết và rà soát tĩnh, **chưa được biên dịch hay chạy thử** (môi trường tạo không có .NET/Halcon). Rất có thể còn vài lỗi biên dịch nhỏ (đặc biệt chữ ký hàm Halcon theo đúng 18.11) – xem mục "Việc cần làm khi build lần đầu".

## Cách dùng nhanh
1. **Procedures** (tab trái) = mỗi procedure là một flowchart. Double-click tool trong **Toolbox** để thêm; tool mới tự nối ảnh/fixture (tên tool = tên lớp + số: `ShapeMatch1`, `Align2P1`…) với tool phía trước.
2. **Node editor**: mỗi tool là node có cổng vào (trái) và cổng ra (phải), màu theo kiểu dữ liệu. Kéo tool từ Toolbox thả vào canvas; kéo từ cổng ra sang cổng vào để nối (chỉ nối được cổng cùng kiểu, không tạo vòng lặp); kéo đầu dây khỏi cổng vào để nối lại; chuột phải dây/cổng → Disconnect; Ctrl+lăn = zoom; chuột giữa = kéo nền; nút ⛶ Node view phóng to vùng node. Chọn tool → chỉnh ở **Properties**. Ô có combo là **liên kết** tới cổng ra của tool khác (`ShapeMatch1.Fixture`, `FindLine1.Line`…); đường nối trên flowchart tự vẽ theo liên kết. Chuột phải node: Run to here / Disable / Delete.
3. **ROI**: bấm “✎ Draw ROI on image” (chạy procedure trước để có ảnh; chuột trái vẽ, chuột phải xác nhận). ROI nên vẽ trên ảnh mẫu (hệ toạ độ teach); khi nối `Fixture` ROI tự dịch/xoay theo vật.
4. **Train / Teach**: tool có nút hành động (Shape Match: *Train template*; Align: *Teach reference marks*; Fixture: *Teach reference*; Variation: *Train from folder*). Model lưu trong `Models/` cạnh file `.vsproj`.
5. **Calibration** (📐): N-point affine pixel→mm, tâm xoay, scale mm/px. Align dùng calibration theo tên.
6. **Cameras / Comm / Triggers**: cấu hình; bật **Scheduler** để nhận lệnh TCP (vd. `T1`) → chạy procedure → trả lời theo `Reply template` (`{OK},{Align2P1.X},{Align2P1.Y},{Align2P1.T}`).
7. F5 chạy 1 lần, F6 chạy liên tục.

## Kiến trúc
```
VisionStudio.Core   (class library, không phụ thuộc UI)
  Framework/   ToolBase · [Tool]/[Param] · RunContext · Procedure (topo-sort) · Project (JSON) · Scheduler
  Tools/       Image · Locate · Geometry · Region · Align · Logic/Comm
  Calibration/ affine LS, tâm xoay (fit tròn)
  Camera/      Halcon open_framegrabber
  Comm/        TCP server/client, Modbus TCP master
VisionStudio.App    (WPF)
  Controls/    FlowCanvas · PropertyPanel (sinh từ [Param]) · ImageView (HSmartWindowControlWPF)
  Views/       Calibration · ListEditor (Camera/Comm/Trigger) · Prompt
  Themes/      Dark / Light (màu VisionAutoCode) + style
```
**Thêm tool mới** = 1 class kế thừa `ToolBase`, gắn `[Tool(...)]`, khai báo tham số bằng `[Param]` (có `Source=Kind.*` nếu là input liên kết), override `Ports` và `Execute`. Toolbox, panel thuộc tính, flowchart, lưu/mở dự án tự nhận.

## Về giao diện IVA B+
Zip IVA_Bplus **chỉ chứa module plugin** (các `Algo*`, `Std*Scheduler`…) và một stub Designer; phần khung chính (`Iva.Bplus.dll`, Designer.exe, Telerik docking) **không có trong zip**. Vì vậy giao diện được dựng lại theo các gì quan sát được (Scheduler → Procedure → Algorithm; Designer flowchart; PropertyGrid; log), không phải bản sao điểm-ảnh. Telerik/DevExpress (thương mại) không dùng; thay bằng control WPF thuần.

## Giả định đã đặt (cần bạn kiểm tra)
* **Align XYθ** (`AlignEngine`): các hàm gốc `GetThetaColumn/NormalizeTheta/ApplyTargetOffset` không có trong zip → viết lại: best-fit cứng (bình phương tối thiểu) giữa mark vật và mark tham chiếu, stage xoay quanh tâm xoay (calibration) rồi tịnh tiến; offset cộng sau cùng; `Theta direction` đổi dấu θ. Toán đã kiểm chứng số (sai số ~1e-15) nhưng **hướng dương XY/θ phải đối chiếu với máy thật**.
* Quy ước pixel: `Pt.X = column`, `Pt.Y = row`; góc Halcon ngược chiều kim đồng hồ trên màn hình.
* Calibration: ma trận affine hàng-chủ `x = h0·px + h1·py + h2` (cùng quy ước VisionAutoCode).

## Việc cần làm khi build lần đầu
1. Nếu trình biên dịch báo sai chữ ký một hàm `HOperatorSet.*` → đối chiếu Halcon 18.11 Reference (các hàm rủi ro nhất: `VectorToProjHomMat2d`, `AddMetrologyObject*Measure`, `GetMetrologyObjectMeasures`, `FindAnisoShapeModel`, `CreateDataCode2dModel`).
2. `HSmartWindowControlWPF` (ImageView): kiểm tra zoom/pan có vẽ lại đúng (đã gắn Redraw vào HMouseWheel/HMouseUp/HMouseMove). Dùng HwndHost nên không đặt control WPF đè lên vùng ảnh.
3. Camera: thử `Cameras → List devices`; tên tham số GenICam (`ExposureTime`, `Gain`, `TriggerMode`…) tuỳ hãng, sửa ở mục Advanced. SDK hãng (Hik/Basler…) chưa tích hợp trực tiếp – thêm adapter nếu interface Halcon không hỗ trợ.
4. Kiểm tra dấu X/Y/θ của Align trên máy thật (xem "Giả định").
5. Chưa có unit test; toán lõi (`AlignEngine`, `SolveAffine`, `FitCircle`) đã kiểm chứng bằng mô phỏng độc lập.
