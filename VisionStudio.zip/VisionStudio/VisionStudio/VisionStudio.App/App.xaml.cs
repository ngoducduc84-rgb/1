using System;
using System.Linq;
using System.Windows;

namespace VisionStudio.App
{
    public partial class App : Application
    {
        public static bool IsDark { get; private set; } = true;

        public App()
        {
            DispatcherUnhandledException += (s, e) =>
            {
                MessageBox.Show(e.Exception.ToString(), "VisionStudio – lỗi chưa xử lý", MessageBoxButton.OK, MessageBoxImage.Error);
                e.Handled = true;
            };
        }

        /// <summary>Kiểm tra halcondotnet.dll (managed) và halcon.dll (native) cùng phiên bản TRƯỚC khi tạo cửa sổ.
        /// Lệch phiên bản gây lỗi lạ như "HALCON error #5190 Invalid window parameter in set_window_param".</summary>
        protected override void OnStartup(StartupEventArgs e)
        {
            try
            {
                var asm = typeof(HalconDotNet.HTuple).Assembly;
                var v = asm.GetName().Version;
                string native = HalconDotNet.HSystem.GetSystem("version").S;
                string nativePath = "";
                foreach (System.Diagnostics.ProcessModule m in System.Diagnostics.Process.GetCurrentProcess().Modules)
                    if (m.ModuleName.Equals("halcon.dll", StringComparison.OrdinalIgnoreCase)) nativePath = m.FileName;
                string managed = v.Major + "." + v.Minor;
                if (!native.StartsWith(managed))
                    MessageBox.Show("Halcon bị LỆCH PHIÊN BẢN:\n\n" +
                        "• halcondotnet.dll (managed): " + v + "\n  " + asm.Location + "\n" +
                        "• halcon.dll (native): " + native + "\n  " + nativePath + "\n\n" +
                        "Hai file phải cùng phiên bản (18.11). Xoá halcon.dll thừa cạnh file .exe / trong Lib, " +
                        "đặt thư mục bin\\x64-win64 của Halcon 18.11 lên ĐẦU biến PATH rồi chạy lại.",
                        "VisionStudio – Halcon", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Không nạp được Halcon (halcon.dll / license):\n" + ex.Message, "VisionStudio – Halcon", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            base.OnStartup(e);
        }

        /// <summary>Đổi Dark/Light bằng cách thay dictionary màu (các style dùng DynamicResource nên cập nhật ngay).</summary>
        public static void SetTheme(bool dark)
        {
            var dicts = Current.Resources.MergedDictionaries;
            var old = dicts.FirstOrDefault(d => d.Source != null && (d.Source.OriginalString.EndsWith("Dark.xaml") || d.Source.OriginalString.EndsWith("Light.xaml")));
            var nd = new ResourceDictionary { Source = new Uri(dark ? "Themes/Dark.xaml" : "Themes/Light.xaml", UriKind.Relative) };
            if (old != null) dicts.Remove(old);
            dicts.Insert(0, nd); IsDark = dark;
        }

        public static System.Windows.Media.Brush Brush(string key) => (System.Windows.Media.Brush)Current.FindResource(key);
    }
}
