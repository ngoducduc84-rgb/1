using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using VisionStudio.Core.Framework;

namespace VisionStudio.App.Controls
{
    /// <summary>Node editor: mỗi tool là 1 node có cổng vào (các tham số link) và cổng ra (Ports).
    /// Kéo từ cổng ra sang cổng vào để nối; kéo từ cổng vào đã nối để nối lại/ngắt; kéo tool từ Toolbox thả vào canvas;
    /// Ctrl+lăn chuột = zoom; chuột giữa = pan. Dữ liệu vẫn là các chuỗi link "Tool.Port" trong tham số tool.</summary>
    public class FlowCanvas : ScrollViewer
    {
        const double NodeW = 210, HeaderH = 26, RowH = 20, FooterH = 22;

        class InPort { public ToolBase Tool; public PropertyInfo Prop; public ParamAttribute Attr; public Point Pos; }
        class OutPort { public ToolBase Tool; public Port Port; public Point Pos; }

        readonly Canvas _cv = new Canvas();
        readonly List<InPort> _ins = new List<InPort>();
        readonly List<OutPort> _outs = new List<OutPort>();
        Procedure _proc; ToolBase _selected;
        ToolBase _drag; Point _dragOff;
        OutPort _linkFrom; Path _tmp; string _linkKind;
        double _zoom = 1; bool _panning; Point _panStart; double _panH, _panV;

        public event Action<ToolBase> SelectionChanged;
        public event Action<ToolBase> DeleteRequested;
        public event Action<ToolBase> RunToRequested;
        public event Action Changed;          // vị trí/bật-tắt thay đổi
        public event Action LinkEdited;       // nối / ngắt liên kết
        public event Action<Type, Point> ToolDropped;

        public ToolBase Selected => _selected;

        public FlowCanvas()
        {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto; VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            Content = _cv; AllowDrop = true; Focusable = true;
            _cv.MouseLeftButtonDown += (s, e) => { if (e.Source == _cv) Select(null); };
            _cv.MouseMove += OnMove;
            _cv.MouseLeftButtonUp += OnUp;
            PreviewMouseWheel += (s, e) =>
            {
                if ((Keyboard.Modifiers & ModifierKeys.Control) == 0) return;
                _zoom = Math.Max(0.4, Math.Min(2.0, _zoom * (e.Delta > 0 ? 1.1 : 1 / 1.1)));
                _cv.LayoutTransform = new ScaleTransform(_zoom, _zoom); e.Handled = true;
            };
            PreviewMouseDown += (s, e) => { if (e.ChangedButton == MouseButton.Middle) { _panning = true; _panStart = e.GetPosition(this); _panH = HorizontalOffset; _panV = VerticalOffset; CaptureMouse(); e.Handled = true; } };
            PreviewMouseMove += (s, e) => { if (_panning) { var p = e.GetPosition(this); ScrollToHorizontalOffset(_panH - (p.X - _panStart.X)); ScrollToVerticalOffset(_panV - (p.Y - _panStart.Y)); } };
            PreviewMouseUp += (s, e) => { if (_panning && e.ChangedButton == MouseButton.Middle) { _panning = false; ReleaseMouseCapture(); } };
            Drop += (s, e) =>
            {
                if (e.Data.GetData("VsToolType") is Type t) { var p = e.GetPosition(_cv); ToolDropped?.Invoke(t, new Point(Math.Max(0, Math.Round(p.X / 10) * 10), Math.Max(0, Math.Round(p.Y / 10) * 10))); }
            };
            DragOver += (s, e) => { e.Effects = e.Data.GetDataPresent("VsToolType") ? DragDropEffects.Copy : DragDropEffects.None; e.Handled = true; };
        }

        public void Bind(Procedure p) { _proc = p; _selected = null; Rebuild(); }
        public void Select(ToolBase t) { _selected = t; Rebuild(); SelectionChanged?.Invoke(t); }

        // ───────── kiểu dữ liệu / màu cổng ─────────
        static Brush KindBrush(string k)
        {
            string c;
            switch (k)
            {
                case Kind.Image: c = "#38BDF8"; break; case Kind.Region: c = "#A78BFA"; break; case Kind.Point: c = "#F87171"; break;
                case Kind.Points: c = "#FB923C"; break; case Kind.Line: c = "#FACC15"; break; case Kind.Circle: c = "#F472B6"; break;
                case Kind.Number: c = "#4ADE80"; break; case Kind.Bool: c = "#94A3B8"; break; case Kind.Text: c = "#CBD5E1"; break;
                case Kind.Fixture: c = "#22D3EE"; break; case Kind.Pose: c = "#FB7185"; break; default: c = "#E2E8F0"; break;
            }
            return (Brush)new BrushConverter().ConvertFromString(c);
        }
        static bool Compatible(string want, string have) => want == Kind.Any || want == have || (want == Kind.Point && have == Kind.Pose);

        static List<ToolMeta.ParamInfo> InputsOf(ToolBase t)
            => ToolMeta.GetParams(t.GetType()).Where(p => p.Attr.Source != null && p.Prop.PropertyType == typeof(string) && p.Prop.CanWrite).ToList();

        static double HeightOf(ToolBase t) => HeaderH + Math.Max(1, Math.Max(InputsOf(t).Count, t.AllPorts.Count())) * RowH + FooterH;

        // ───────── dựng lại ─────────
        public void Rebuild()
        {
            _cv.Children.Clear(); _ins.Clear(); _outs.Clear(); _tmp = null;
            var bc = ((SolidColorBrush)App.Brush("VsBorderBrush")).Color;
            _cv.Background = new DrawingBrush(new GeometryDrawing(new SolidColorBrush(bc), null, new EllipseGeometry(new Point(1, 1), 1, 1)))
            { TileMode = TileMode.Tile, Viewport = new Rect(0, 0, 24, 24), ViewportUnits = BrushMappingMode.Absolute, Viewbox = new Rect(0, 0, 24, 24), ViewboxUnits = BrushMappingMode.Absolute };
            Background = App.Brush("VsPanelAltBrush");
            if (_proc == null) return;

            // vị trí cổng
            foreach (var t in _proc.Tools)
            {
                var ins = InputsOf(t); for (int i = 0; i < ins.Count; i++)
                    _ins.Add(new InPort { Tool = t, Prop = ins[i].Prop, Attr = ins[i].Attr, Pos = new Point(t.X, t.Y + HeaderH + i * RowH + RowH / 2) });
                int o = 0; foreach (var p in t.AllPorts) _outs.Add(new OutPort { Tool = t, Port = p, Pos = new Point(t.X + NodeW, t.Y + HeaderH + o++ * RowH + RowH / 2) });
            }
            DrawEdges();
            foreach (var t in _proc.Tools) DrawNode(t);

            double mw = Math.Max(1400, _proc.Tools.Select(t => t.X).DefaultIfEmpty(0).Max() + NodeW + 300);
            double mh = Math.Max(700, _proc.Tools.Select(t => t.Y + HeightOf(t)).DefaultIfEmpty(0).Max() + 200);
            _cv.Width = mw; _cv.Height = mh;
        }

        void DrawNode(ToolBase t)
        {
            var attr = ToolMeta.GetToolAttr(t.GetType());
            Brush edge = App.Brush("VsBorderBrush");
            if (t.Result != null && t.Result.Executed) edge = t.Result.Ok ? App.Brush("VsSuccessBrush") : App.Brush("VsErrorBrush");
            else if (t.Result != null && t.Result.Skipped && !string.IsNullOrEmpty(t.Result.Message)) edge = App.Brush("VsWarningBrush");
            bool sel = t == _selected; double h = HeightOf(t);

            var body = new Border
            {
                Width = NodeW, Height = h, CornerRadius = new CornerRadius(6), BorderThickness = new Thickness(sel ? 2.5 : 1.5),
                BorderBrush = sel ? App.Brush("VsInfoBrush") : edge, Background = App.Brush("VsPanelBrush"), Opacity = t.Enabled ? 1 : 0.55,
                ToolTip = (attr?.Description ?? "") + (string.IsNullOrEmpty(t.Result?.Message) ? "" : "\n" + t.Result.Message)
            };
            Canvas.SetLeft(body, t.X); Canvas.SetTop(body, t.Y); _cv.Children.Add(body);

            var head = new Border { Width = NodeW - 2, Height = HeaderH, CornerRadius = new CornerRadius(5, 5, 0, 0), Background = sel ? App.Brush("VsSelectionBrush") : App.Brush("VsControlBrush"), Cursor = Cursors.SizeAll, Opacity = t.Enabled ? 1 : 0.55 };
            var title = new TextBlock { Text = $"{attr?.Glyph} {t.Name}", FontWeight = FontWeights.SemiBold, Margin = new Thickness(8, 4, 8, 0), TextTrimming = TextTrimming.CharacterEllipsis };
            head.Child = title; Canvas.SetLeft(head, t.X + 1); Canvas.SetTop(head, t.Y + 1); _cv.Children.Add(head);

            Action<object, MouseButtonEventArgs> down = (s, e) =>
            {
                _drag = t; _dragOff = e.GetPosition(_cv); _dragOff = new Point(_dragOff.X - t.X, _dragOff.Y - t.Y); _cv.CaptureMouse();
                if (_selected != t) { _selected = t; SelectionChanged?.Invoke(t); }
                e.Handled = true;
            };
            head.MouseLeftButtonDown += (s, e) => down(s, e); body.MouseLeftButtonDown += (s, e) => down(s, e);
            var cm = new ContextMenu();
            var runTo = new MenuItem { Header = "Run to here" }; runTo.Click += (s, e) => RunToRequested?.Invoke(t);
            var tog = new MenuItem { Header = t.Enabled ? "Disable" : "Enable" }; tog.Click += (s, e) => { t.Enabled = !t.Enabled; Rebuild(); Changed?.Invoke(); };
            var del = new MenuItem { Header = "Delete" }; del.Click += (s, e) => DeleteRequested?.Invoke(t);
            cm.Items.Add(runTo); cm.Items.Add(tog); cm.Items.Add(new Separator()); cm.Items.Add(del); head.ContextMenu = cm; body.ContextMenu = cm;

            // cổng vào (trái)
            foreach (var ip in _ins.Where(x => x.Tool == t))
            {
                string cur = ip.Prop.GetValue(t) as string; bool linked = !string.IsNullOrWhiteSpace(cur);
                var dot = MakeDot(ip.Attr.Source, linked); Canvas.SetLeft(dot, ip.Pos.X - 6); Canvas.SetTop(dot, ip.Pos.Y - 6); dot.Tag = ip;
                dot.ToolTip = linked ? $"{ip.Attr.Display} ← {cur}\n(kéo để nối lại, chuột phải để ngắt)" : $"{ip.Attr.Display} ({ip.Attr.Source})";
                dot.MouseLeftButtonDown += OnInPortDown;
                var m = new ContextMenu(); var dis = new MenuItem { Header = "Disconnect" }; var ipc = ip;
                dis.Click += (s, e) => { SetLink(ipc, null); }; m.Items.Add(dis); dot.ContextMenu = m;
                _cv.Children.Add(dot);
                string txt = ip.Attr.Display.Length > 24 ? ip.Attr.Display.Substring(0, 23) + "…" : ip.Attr.Display;
                var lb = new TextBlock { Text = txt, FontSize = 11, Foreground = linked ? App.Brush("VsTextBrush") : App.Brush("VsSubTextBrush"), IsHitTestVisible = false, Width = NodeW / 2 - 10, TextTrimming = TextTrimming.CharacterEllipsis };
                Canvas.SetLeft(lb, ip.Pos.X + 9); Canvas.SetTop(lb, ip.Pos.Y - 8); _cv.Children.Add(lb);
            }
            // cổng ra (phải)
            foreach (var op in _outs.Where(x => x.Tool == t))
            {
                var dot = MakeDot(op.Port.Kind, true); Canvas.SetLeft(dot, op.Pos.X - 6); Canvas.SetTop(dot, op.Pos.Y - 6); dot.Tag = op;
                dot.ToolTip = $"{op.Port.Name} ({op.Port.Kind}) – kéo sang cổng vào để nối"; dot.Cursor = Cursors.Cross;
                dot.MouseLeftButtonDown += OnOutPortDown; _cv.Children.Add(dot);
                var lb = new TextBlock { Text = op.Port.Name, FontSize = 11, TextAlignment = TextAlignment.Right, Foreground = App.Brush("VsTextBrush"), IsHitTestVisible = false, Width = NodeW / 2 - 10 };
                Canvas.SetLeft(lb, op.Pos.X - 9 - (NodeW / 2 - 10)); Canvas.SetTop(lb, op.Pos.Y - 8); _cv.Children.Add(lb);
            }
            // chân node: trạng thái
            string foot = t.Result != null && t.Result.Executed ? $"{(t.Result.Ok ? "OK" : "NG")} · {t.Result.Ms:0.#} ms · {t.Result.Message}" : (t.Result != null && t.Result.Skipped ? "skip " + t.Result.Message : attr?.Category);
            var ft = new TextBlock { Text = foot, FontSize = 10, Foreground = (t.Result != null && t.Result.Executed) ? (t.Result.Ok ? App.Brush("VsSuccessBrush") : App.Brush("VsErrorBrush")) : App.Brush("VsSubTextBrush"), Width = NodeW - 14, TextTrimming = TextTrimming.CharacterEllipsis, IsHitTestVisible = false };
            Canvas.SetLeft(ft, t.X + 8); Canvas.SetTop(ft, t.Y + h - FooterH + 3); _cv.Children.Add(ft);
        }

        Ellipse MakeDot(string kind, bool filled)
            => new Ellipse { Width = 12, Height = 12, Fill = filled ? KindBrush(kind) : App.Brush("VsPanelBrush"), Stroke = KindBrush(kind), StrokeThickness = 2, Cursor = Cursors.Hand };

        // ───────── cạnh ─────────
        static Geometry Curve(Point a, Point b)
        {
            double dx = Math.Max(50, Math.Abs(b.X - a.X) / 2); var f = new PathFigure { StartPoint = a };
            f.Segments.Add(new BezierSegment(new Point(a.X + dx, a.Y), new Point(b.X - dx, b.Y), b, true));
            var g = new PathGeometry(); g.Figures.Add(f); return g;
        }

        void DrawEdges()
        {
            foreach (var ip in _ins)
            {
                string v = ip.Prop.GetValue(ip.Tool) as string; if (string.IsNullOrWhiteSpace(v)) continue;
                int d = v.IndexOf('.'); if (d <= 0) continue; string tn = v.Substring(0, d), pn = v.Substring(d + 1);
                var op = _outs.FirstOrDefault(o => string.Equals(o.Tool.Name, tn, StringComparison.OrdinalIgnoreCase) && o.Port.Name == pn); if (op == null) continue;
                bool hot = ip.Tool == _selected || op.Tool == _selected;
                var brush = KindBrush(op.Port.Kind);
                var path = new Path { Data = Curve(op.Pos, ip.Pos), Stroke = brush, StrokeThickness = hot ? 3 : 1.8, Opacity = hot ? 1 : 0.75, Cursor = Cursors.Hand, ToolTip = v + " → " + ip.Tool.Name + "." + ip.Attr.Display };
                var cm = new ContextMenu(); var dis = new MenuItem { Header = "Disconnect" }; var ipc = ip; dis.Click += (s, e) => SetLink(ipc, null); cm.Items.Add(dis); path.ContextMenu = cm;
                _cv.Children.Add(path);
            }
        }

        // ───────── nối / ngắt ─────────
        void SetLink(InPort ip, string value)
        {
            try { ip.Prop.SetValue(ip.Tool, string.IsNullOrEmpty(value) ? null : value); } catch { }
            Rebuild(); LinkEdited?.Invoke();
        }

        bool DependsOn(ToolBase a, ToolBase b, HashSet<ToolBase> seen = null)
        {
            seen = seen ?? new HashSet<ToolBase>(); if (!seen.Add(a)) return false;
            foreach (var d in ToolMeta.Dependencies(a)) { var dt = _proc.Find(d); if (dt == null) continue; if (dt == b || DependsOn(dt, b, seen)) return true; }
            return false;
        }

        bool CanLink(OutPort o, InPort i) => o != null && i != null && o.Tool != i.Tool && Compatible(i.Attr.Source, o.Port.Kind) && !DependsOn(o.Tool, i.Tool);

        void OnOutPortDown(object sender, MouseButtonEventArgs e)
        {
            var op = (OutPort)((FrameworkElement)sender).Tag; StartLink(op); e.Handled = true;
        }

        void OnInPortDown(object sender, MouseButtonEventArgs e)
        {
            var ip = (InPort)((FrameworkElement)sender).Tag; e.Handled = true;
            string v = ip.Prop.GetValue(ip.Tool) as string;
            if (string.IsNullOrWhiteSpace(v)) return;
            int d = v.IndexOf('.'); if (d <= 0) return;
            var op = _outs.FirstOrDefault(o => string.Equals(o.Tool.Name, v.Substring(0, d), StringComparison.OrdinalIgnoreCase) && o.Port.Name == v.Substring(d + 1));
            if (op == null) return;
            ip.Prop.SetValue(ip.Tool, null);          // nhấc dây ra khỏi cổng vào → kéo để nối lại
            LinkEdited?.Invoke(); Rebuild();
            var op2 = _outs.First(o => o.Tool == op.Tool && o.Port.Name == op.Port.Name); StartLink(op2);
        }

        void StartLink(OutPort op)
        {
            _linkFrom = op; _linkKind = op.Port.Kind;
            _tmp = new Path { Stroke = KindBrush(op.Port.Kind), StrokeThickness = 2.5, StrokeDashArray = new DoubleCollection { 4, 3 }, IsHitTestVisible = false, Data = Curve(op.Pos, op.Pos) };
            _cv.Children.Add(_tmp); _cv.CaptureMouse();
        }

        InPort NearestIn(Point p, OutPort from)
            => from == null ? null : _ins.Where(i => CanLink(from, i)).Select(i => new { i, d = (i.Pos - p).Length }).Where(x => x.d < 16).OrderBy(x => x.d).Select(x => x.i).FirstOrDefault();

        void OnMove(object sender, MouseEventArgs e)
        {
            var p = e.GetPosition(_cv);
            if (_linkFrom != null && _tmp != null)
            {
                var near = NearestIn(p, _linkFrom); _tmp.Data = Curve(_linkFrom.Pos, near != null ? near.Pos : p);
                _tmp.Stroke = near != null ? App.Brush("VsSuccessBrush") : KindBrush(_linkKind);
                return;
            }
            if (_drag == null || e.LeftButton != MouseButtonState.Pressed) return;
            _drag.X = Math.Max(0, Math.Round((p.X - _dragOff.X) / 10) * 10); _drag.Y = Math.Max(0, Math.Round((p.Y - _dragOff.Y) / 10) * 10);
            Rebuild();
        }

        void OnUp(object sender, MouseButtonEventArgs e)
        {
            if (_linkFrom != null)
            {
                var from = _linkFrom; _linkFrom = null; _cv.ReleaseMouseCapture();
                var near = NearestIn(e.GetPosition(_cv), from); _tmp = null;
                if (near != null) SetLink(near, from.Tool.Name + "." + from.Port.Name); else Rebuild();
                return;
            }
            if (_drag != null) { _drag = null; _cv.ReleaseMouseCapture(); Changed?.Invoke(); }
        }

        // ───────── bố cục tự động ─────────
        public void AutoLayout()
        {
            if (_proc == null) return;
            var level = new Dictionary<ToolBase, int>();
            int Lv(ToolBase t, int guard = 0)
            {
                if (level.TryGetValue(t, out int v)) return v; if (guard > 50) return 0;
                int m = -1; foreach (var d in ToolMeta.Dependencies(t)) { var dt = _proc.Find(d); if (dt != null && dt != t) m = Math.Max(m, Lv(dt, guard + 1)); }
                return level[t] = m + 1;
            }
            foreach (var t in _proc.Tools) Lv(t);
            var ycur = new Dictionary<int, double>();
            foreach (var t in _proc.Tools.OrderBy(t => level[t]))
            {
                int l = level[t]; ycur.TryGetValue(l, out double y);
                t.X = 30 + l * (NodeW + 90); t.Y = 20 + y; ycur[l] = y + HeightOf(t) + 24;
            }
            Rebuild(); Changed?.Invoke();
        }
    }
}
