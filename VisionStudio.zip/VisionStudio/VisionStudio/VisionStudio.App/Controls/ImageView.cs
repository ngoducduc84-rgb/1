using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms.Integration;
using System.Windows.Threading;
using HalconDotNet;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Halcon;

namespace VisionStudio.App.Controls
{
    /// <summary>Hiển thị ảnh Halcon bằng HWindowControl (WinForms) đặt trong WindowsFormsHost – ổn định hơn HSmartWindowControlWPF.
    /// Zoom (lăn chuột, theo vị trí con trỏ) và pan (kéo chuột trái) tự cài bằng set_part. Thanh thông tin đặt dưới (tránh airspace).</summary>
    public class ImageView : Grid
    {
        readonly WindowsFormsHost _host = new WindowsFormsHost();
        readonly HWindowControl _ctrl = new HWindowControl();
        readonly TextBlock _info = new TextBlock { Margin = new Thickness(6, 2, 6, 2), FontFamily = new System.Windows.Media.FontFamily("Consolas") };
        readonly TextBlock _status = new TextBlock { Margin = new Thickness(6, 2, 6, 2), FontWeight = FontWeights.Bold, FontSize = 14 };
        HObject _image; IList<OverlayItem> _overlays; bool _ready, _panning, _drawing;
        int _w, _h; double _r1, _c1, _r2, _c2, _pr0, _pc0;

        HWindow Hw => _ctrl.HalconWindow;
        string _initErr; readonly DispatcherTimer _retry = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(300) };
        const string Build = "ImageView v3";
        public bool HasImage => _image != null && _image.IsInitialized();

        public ImageView()
        {
            RowDefinitions.Add(new RowDefinition()); RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            _host.Child = _ctrl; Children.Add(_host);
            var bar = new DockPanel { Background = App.Brush("VsPanelAltBrush") }; SetRow(bar, 1);
            DockPanel.SetDock(_status, Dock.Right); bar.Children.Add(_status); bar.Children.Add(_info);
            Children.Add(bar);

            _ctrl.HandleCreated += (s, e) => TryInit();
            Loaded += (s, e) => TryInit();
            _retry.Tick += (s, e) => { if (TryInit()) { _retry.Stop(); Redraw(); } };
            _retry.Start();
            _ctrl.SizeChanged += (s, e) => { if (_ready) { Normalize(); Redraw(); } };
            _ctrl.HMouseWheel += (s, e) => OnWheel(e.Delta);
            _ctrl.HMouseDown += (s, e) => { if (!_drawing && e.Button.ToString() == "Left") { _panning = TryMouse(out _pr0, out _pc0); } };
            _ctrl.HMouseUp += (s, e) => _panning = false;
            _ctrl.HMouseMove += (s, e) => OnMove();
        }

        /// <summary>Khởi tạo cửa sổ Halcon khi control đã có handle. An toàn khi gọi nhiều lần.</summary>
        bool TryInit()
        {
            if (_ready) return true;
            try
            {
                if (!_ctrl.IsHandleCreated) return false;
                var w = _ctrl.HalconWindow; if (w == null) return false;
                _ready = true; _initErr = null;
                try { w.SetWindowParam("background_color", "black"); } catch (HalconException) { }
                Fit(); return true;
            }
            catch (HalconException ex) { _ready = false; _initErr = "Không tạo được cửa sổ Halcon: " + ex.GetErrorMessage(); _info.Text = _initErr; return false; }
            catch (Exception ex) { _ready = false; _initErr = "Cửa sổ Halcon chưa sẵn sàng: " + ex.Message; _info.Text = _initErr; return false; }
        }

        bool TryMouse(out double row, out double col)
        {
            row = col = 0;
            try { Hw.GetMpositionSubPix(out double r, out double c, out int b); row = r; col = c; return true; }
            catch (HalconException) { return false; }
        }

        double WinW => Math.Max(1, _ctrl.Width);
        double WinH => Math.Max(1, _ctrl.Height);

        void Fit()
        {
            if (!_ready) return;
            if (_w <= 0) { _r1 = 0; _c1 = 0; _r2 = WinH - 1; _c2 = WinW - 1; Redraw(); return; }
            double s = Math.Min(WinW / _w, WinH / _h), pw = WinW / s, ph = WinH / s;
            _c1 = (_w - pw) / 2; _c2 = _c1 + pw; _r1 = (_h - ph) / 2; _r2 = _r1 + ph; Redraw();
        }

        /// <summary>Giữ tỉ lệ part = tỉ lệ cửa sổ (không méo ảnh khi đổi kích thước).</summary>
        void Normalize()
        {
            double pw = _c2 - _c1; if (pw <= 0) return; double ph = pw * WinH / WinW, cy = (_r1 + _r2) / 2;
            _r1 = cy - ph / 2; _r2 = cy + ph / 2;
        }

        void OnWheel(int delta)
        {
            if (!_ready || !HasImage || _drawing) return;
            if (!TryMouse(out double ar, out double ac)) { ar = (_r1 + _r2) / 2; ac = (_c1 + _c2) / 2; }
            double f = delta > 0 ? 0.8 : 1.25;
            double pw = (_c2 - _c1) * f; if (pw > _w * 20 || pw < 8) return;
            _r1 = ar - (ar - _r1) * f; _r2 = ar + (_r2 - ar) * f; _c1 = ac - (ac - _c1) * f; _c2 = ac + (_c2 - ac) * f;
            Redraw();
        }

        void OnMove()
        {
            if (_drawing || !_ready) return;
            if (!TryMouse(out double r, out double c)) return;
            if (_panning)
            {
                double dr = _pr0 - r, dc = _pc0 - c; _r1 += dr; _r2 += dr; _c1 += dc; _c2 += dc; Redraw();
            }
            if (!HasImage) return;
            string g = "";
            try { HOperatorSet.GetGrayval(_image, (int)r, (int)c, out HTuple v); g = string.Join(",", v.ToDArr().Select(x => x.ToString("0"))); } catch { }
            _info.Text = $"X={c:0.0}  Y={r:0.0}  gray={g}   [{_w}x{_h}]";
        }

        public void SetStatus(bool? ok, string text)
        {
            _status.Text = text ?? "";
            _status.Foreground = ok == null ? App.Brush("VsSubTextBrush") : ok == true ? App.Brush("VsSuccessBrush") : App.Brush("VsErrorBrush");
        }

        public void FitImage() => Fit();

        /// <summary>Hiển thị ảnh + overlay. Đối tượng KHÔNG thuộc view – gọi Clear() trước khi Dispose chúng.</summary>
        public void Show(HObject image, IList<OverlayItem> overlays)
        {
            _image = image; _overlays = overlays;
            if (!HasImage) _info.Text = Hint;
            else if (!_ready) _info.Text = _initErr ?? "Đang khởi tạo cửa sổ Halcon… (" + Build + ")";
            if (HasImage)
            {
                HOperatorSet.GetImageSize(_image, out HTuple w, out HTuple h);
                if (w.I != _w || h.I != _h) { _w = w.I; _h = h.I; Fit(); return; }
            }
            Redraw();
        }

        const string HintText = "Chưa có ảnh – bấm 🖼 Open image (hoặc thêm tool Image Source) rồi Run (F5)";
        string Hint => _initErr ?? HintText;

        public void Clear() { _image = null; _overlays = null; _info.Text = Hint; Redraw(); }

        public void Redraw()
        {
            if (!_ready && !TryInit()) return;
            try
            {
                var hw = Hw;
                hw.SetPart((int)Math.Round(_r1), (int)Math.Round(_c1), (int)Math.Round(_r2), (int)Math.Round(_c2));
                hw.ClearWindow();
                if (HasImage) hw.DispObj(_image);
                hw.SetLineWidth(2);
                try { hw.SetFont("Consolas-Bold-14"); } catch (HalconException) { }
                if (_overlays != null)
                    foreach (var o in _overlays.ToList())
                    {
                        hw.SetColor(o.Color ?? "green");
                        switch (o.Kind)
                        {
                            case OverlayKind.Object:
                                if (o.Obj == null || !o.Obj.IsInitialized()) break;
                                hw.SetDraw(o.Fill ? "fill" : "margin"); hw.DispObj(o.Obj); break;
                            case OverlayKind.Cross: hw.DispCross(o.R, o.C, o.Size * 2, o.Angle); break;
                            case OverlayKind.Line: hw.DispLine(o.R, o.C, o.R2, o.C2); break;
                            case OverlayKind.Circle: hw.SetDraw("margin"); hw.DispCircle(o.R, o.C, o.Size); break;
                            case OverlayKind.Text: hw.SetTposition((int)o.R, (int)o.C); hw.WriteString(o.Text ?? ""); break;
                        }
                    }
                if (HasImage) _info.Text = $"[{_w}x{_h}]  zoom: lăn chuột · pan: kéo chuột trái   ({Build})";
            }
            catch (HalconException ex) { _info.Text = "Halcon vẽ lỗi: " + ex.GetErrorMessage(); }
            catch (Exception ex) { _info.Text = "Lỗi vẽ: " + ex.Message; }
        }

        /// <summary>Vẽ ROI tương tác (chuột trái kéo/chỉnh, chuột phải xác nhận).</summary>
        public bool DrawRoi(RoiBase roi)
        {
            if (!_ready) return false;
            _drawing = true; _panning = false;
            try
            {
                Hw.SetColor("yellow"); Hw.SetDraw("margin"); Hw.SetLineWidth(2);
                return roi.Draw(Hw);
            }
            finally { _drawing = false; Redraw(); }
        }
    }
}
