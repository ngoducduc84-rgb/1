using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using VisionStudio.Core.Framework;

namespace VisionStudio.App.Controls
{
    /// <summary>Panel thuộc tính tự sinh từ [Param] (thay cho Telerik RadPropertyGrid của IVA B+).</summary>
    public class PropertyPanel : UserControl
    {
        readonly ScrollViewer _scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
        readonly StackPanel _root = new StackPanel { Margin = new Thickness(6) };
        object _target;

        public Project Project { get; set; }
        public Procedure Procedure { get; set; }
        public bool ShowHeader { get; set; } = true;

        public event Action<object> ValueChanged;
        public event Action<RoiBase> DrawRoiRequested;
        public event Action<IToolAction> ActionRequested;
        public event Action<ToolBase, string> RenameRequested;

        public PropertyPanel() { _scroll.Content = _root; Content = _scroll; }

        public void Bind(object target)
        {
            _target = target; _root.Children.Clear();
            if (target == null)
            {
                _root.Children.Add(new TextBlock { Text = "Chọn một tool trên flowchart để chỉnh thuộc tính.", Foreground = App.Brush("VsSubTextBrush"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(4) });
                return;
            }
            if (ShowHeader && target is ToolBase tb) BuildHeader(tb);

            var ps = ToolMeta.GetParams(target.GetType());
            foreach (var grp in ps.GroupBy(p => p.Attr.Category))
            {
                var panel = new StackPanel();
                foreach (var pi in grp) panel.Children.Add(BuildRow(target, pi));
                _root.Children.Add(new Expander { Header = grp.Key, Content = panel, Margin = new Thickness(0, 2, 0, 2) });
            }
            if (target is IToolAction act)
            {
                var b = new Button { Content = "▶ " + act.ActionName, Style = (Style)FindResource("AccentButton"), Margin = new Thickness(0, 8, 0, 2) };
                b.Click += (s, e) => ActionRequested?.Invoke(act);
                _root.Children.Add(b);
            }
        }

        void BuildHeader(ToolBase tb)
        {
            var attr = ToolMeta.GetToolAttr(tb.GetType());
            _root.Children.Add(new TextBlock { Text = $"{attr?.Glyph} {attr?.Name}", FontSize = 14, FontWeight = FontWeights.SemiBold, Foreground = App.Brush("VsInfoBrush") });
            if (!string.IsNullOrEmpty(attr?.Description))
                _root.Children.Add(new TextBlock { Text = attr.Description, Foreground = App.Brush("VsSubTextBrush"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 6) });
            var g = new Grid { Margin = new Thickness(0, 0, 0, 6) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) }); g.ColumnDefinitions.Add(new ColumnDefinition());
            g.Children.Add(new TextBlock { Text = "Name", VerticalAlignment = VerticalAlignment.Center });
            var tx = new TextBox { Text = tb.Name }; Grid.SetColumn(tx, 1); g.Children.Add(tx);
            Action commit = () => { if (tx.Text != tb.Name) RenameRequested?.Invoke(tb, tx.Text); tx.Text = tb.Name; };
            tx.LostFocus += (s, e) => commit(); tx.KeyDown += (s, e) => { if (e.Key == Key.Enter) commit(); };
            _root.Children.Add(g);
        }

        FrameworkElement BuildRow(object owner, ToolMeta.ParamInfo pi)
        {
            var p = pi.Prop; var a = pi.Attr; var t = p.PropertyType;
            if (typeof(RoiBase).IsAssignableFrom(t)) return BuildRoi(owner, pi);

            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) }); g.ColumnDefinitions.Add(new ColumnDefinition());
            var lbl = new TextBlock { Text = a.Display, VerticalAlignment = VerticalAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis, ToolTip = a.Hint ?? a.Display };
            g.Children.Add(lbl);
            FrameworkElement ed = CreateEditor(owner, p, a);
            ed.ToolTip = a.Hint ?? a.Display; Grid.SetColumn(ed, 1); g.Children.Add(ed);
            return g;
        }

        FrameworkElement BuildRoi(object owner, ToolMeta.ParamInfo pi)
        {
            var roi = (RoiBase)pi.Prop.GetValue(owner);
            if (roi == null) { roi = (RoiBase)Activator.CreateInstance(pi.Prop.PropertyType); pi.Prop.SetValue(owner, roi); }
            var inner = new StackPanel();
            foreach (var sub in ToolMeta.GetParams(roi.GetType())) inner.Children.Add(BuildRow(roi, sub));
            var draw = new Button { Content = "✎ Draw ROI on image", Style = (Style)FindResource("AccentButton"), Margin = new Thickness(0, 4, 0, 2) };
            draw.Click += (s, e) => { DrawRoiRequested?.Invoke(roi); Bind(_target); ValueChanged?.Invoke(owner); };
            inner.Children.Add(draw);
            return new Expander { Header = pi.Attr.Display, Content = inner, Margin = new Thickness(0, 3, 0, 3) };
        }

        FrameworkElement CreateEditor(object owner, PropertyInfo p, ParamAttribute a)
        {
            var t = p.PropertyType;
            if (t == typeof(bool))
            {
                var cb = new CheckBox { IsChecked = (bool)p.GetValue(owner), VerticalAlignment = VerticalAlignment.Center };
                cb.Click += (s, e) => Set(owner, p, cb.IsChecked == true); return cb;
            }
            if (a.Source != null && t == typeof(string)) return LinkCombo(owner, p, a);
            if (a.List != null && t == typeof(string)) return Combo(owner, p, ListItems(a.List), true);
            if (a.Choices != null) return Combo(owner, p, a.Choices.Split('|'), false);
            if (t.IsEnum) return Combo(owner, p, Enum.GetNames(t), false);
            if (t == typeof(int) || t == typeof(double) || t == typeof(long) || t == typeof(byte) || t == typeof(float) || t == typeof(short))
            {
                var tx = new TextBox { Text = Fmt(p.GetValue(owner)) };
                Action commit = () =>
                {
                    if (double.TryParse(tx.Text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out double v))
                    {
                        if (!double.IsNaN(a.Min) && v < a.Min) v = a.Min; if (!double.IsNaN(a.Max) && v > a.Max) v = a.Max;
                        Set(owner, p, Convert.ChangeType(v, t, CultureInfo.InvariantCulture));
                    }
                    tx.Text = Fmt(p.GetValue(owner));
                };
                tx.LostFocus += (s, e) => commit(); tx.KeyDown += (s, e) => { if (e.Key == Key.Enter) commit(); };
                return tx;
            }
            // string
            var str = new TextBox { Text = (string)p.GetValue(owner) ?? "" };
            if (a.Editor == Editor.MultilineText) { str.AcceptsReturn = true; str.Height = 56; str.TextWrapping = TextWrapping.Wrap; str.VerticalContentAlignment = VerticalAlignment.Top; }
            str.LostFocus += (s, e) => Set(owner, p, str.Text);
            if (a.Editor == Editor.File || a.Editor == Editor.Folder)
            {
                var dock = new DockPanel();
                var btn = new Button { Content = "…", Padding = new Thickness(6, 1, 6, 1), Margin = new Thickness(2, 0, 0, 0) }; DockPanel.SetDock(btn, Dock.Right);
                btn.Click += (s, e) =>
                {
                    if (a.Editor == Editor.File) { var d = new Microsoft.Win32.OpenFileDialog(); if (d.ShowDialog() == true) { str.Text = d.FileName; Set(owner, p, d.FileName); } }
                    else { using (var d = new System.Windows.Forms.FolderBrowserDialog()) if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK) { str.Text = d.SelectedPath; Set(owner, p, d.SelectedPath); } }
                };
                dock.Children.Add(btn); dock.Children.Add(str); return dock;
            }
            return str;
        }

        static string Fmt(object v) => v is double d ? d.ToString("0.######", CultureInfo.InvariantCulture) : Convert.ToString(v, CultureInfo.InvariantCulture);

        ComboBox Combo(object owner, PropertyInfo p, IEnumerable<string> items, bool allowEmpty)
        {
            var list = items.ToList(); if (allowEmpty) list.Insert(0, "");
            string cur = Convert.ToString(p.GetValue(owner), CultureInfo.InvariantCulture) ?? "";
            if (!list.Contains(cur)) list.Add(cur);
            var cb = new ComboBox { ItemsSource = list, SelectedItem = cur };
            cb.SelectionChanged += (s, e) =>
            {
                if (cb.SelectedItem == null) return; string v = (string)cb.SelectedItem;
                object val = p.PropertyType.IsEnum ? Enum.Parse(p.PropertyType, v) : p.PropertyType == typeof(string) ? (allowEmpty && v == "" ? null : v) : Convert.ChangeType(v, p.PropertyType, CultureInfo.InvariantCulture);
                Set(owner, p, val);
            };
            return cb;
        }

        IEnumerable<string> ListItems(string kind)
        {
            if (Project == null) return new string[0];
            switch (kind)
            {
                case "calib": return Project.Calibrations.Select(c => c.Name);
                case "camera": return Project.Cameras.Select(c => c.Name);
                case "comm": return Project.Comms.Select(c => c.Name);
                case "procedure": return Project.Procedures.Select(c => c.Name);
            }
            return new string[0];
        }

        static bool Compatible(string want, string have)
            => want == Kind.Any || want == have || (want == Kind.Point && have == Kind.Pose);

        bool DependsOn(ToolBase a, ToolBase b, HashSet<ToolBase> seen = null)
        {
            seen = seen ?? new HashSet<ToolBase>(); if (!seen.Add(a)) return false;
            foreach (var d in ToolMeta.Dependencies(a)) { var dt = Procedure?.Find(d); if (dt == null) continue; if (dt == b || DependsOn(dt, b, seen)) return true; }
            return false;
        }

        ComboBox LinkCombo(object owner, PropertyInfo p, ParamAttribute a)
        {
            var items = new List<string> { "" };
            if (Procedure != null)
                foreach (var tool in Procedure.Tools)
                {
                    if (tool == owner) continue;
                    if (owner is ToolBase me && DependsOn(tool, me)) continue;   // chống vòng lặp
                    foreach (var port in tool.AllPorts) if (Compatible(a.Source, port.Kind)) items.Add(tool.Name + "." + port.Name);
                }
            string cur = (string)p.GetValue(owner) ?? ""; if (!items.Contains(cur)) items.Add(cur);
            var cb = new ComboBox { ItemsSource = items, SelectedItem = cur };
            cb.SelectionChanged += (s, e) => { if (cb.SelectedItem != null) Set(owner, p, (string)cb.SelectedItem == "" ? null : (string)cb.SelectedItem); };
            return cb;
        }

        void Set(object owner, PropertyInfo p, object v)
        {
            try { p.SetValue(owner, v); } catch { }
            ValueChanged?.Invoke(owner);
        }
    }
}
