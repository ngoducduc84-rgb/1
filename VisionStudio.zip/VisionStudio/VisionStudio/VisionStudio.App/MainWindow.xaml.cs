using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using HalconDotNet;
using Microsoft.Win32;
using VisionStudio.App.Controls;
using VisionStudio.App.Views;
using VisionStudio.Core.Camera;
using VisionStudio.Core.Comm;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Tools;

namespace VisionStudio.App
{
    public class LogItem { public string Text { get; set; } public Brush Brush { get; set; } }
    public class ToolRow { public string Name { get; set; } public string Status { get; set; } public string Ms { get; set; } public string Message { get; set; } }

    public partial class MainWindow : Window
    {
        static readonly string[] CategoryOrder = { "Acquisition", "Image", "Locate", "Geometry", "Measure", "Calibration", "Align", "Logic", "Comm" };

        Project _proj; Procedure _proc; RunContext _ctx;
        readonly Scheduler _sched = new Scheduler();
        CancellationTokenSource _loopCts;
        bool _busy, _dirty; HObject _manualImage;
        readonly ObservableCollection<LogItem> _log = new ObservableCollection<LogItem>();
        readonly ObservableCollection<LogItem> _commLog = new ObservableCollection<LogItem>();

        public MainWindow()
        {
            InitializeComponent();
            FitToScreen();
            LogList.ItemsSource = _log; CommList.ItemsSource = _commLog;
            BuildToolTree();

            Flow.SelectionChanged += OnSelectTool;
            Flow.DeleteRequested += DeleteTool;
            Flow.RunToRequested += async t => await RunAsync(SubProcedure(t));
            Flow.Changed += () => _dirty = true;
            Flow.LinkEdited += async () => { _dirty = true; Props.Bind(Flow.Selected); if (ChkAuto.IsChecked == true) await RunAsync(); };
            Flow.ToolDropped += (type, pos) => AddTool(type, pos);

            Props.ValueChanged += async o => { _dirty = true; Flow.Rebuild(); if (ChkAuto.IsChecked == true) await RunAsync(); };
            Props.DrawRoiRequested += OnDrawRoi;
            Props.ActionRequested += OnToolAction;
            Props.RenameRequested += (t, n) => { _proc.Rename(t, n); _dirty = true; Flow.Rebuild(); Props.Bind(t); };

            _sched.LogSink = Log;
            _sched.Completed += (proc, ctx, rule) => Dispatcher.BeginInvoke(new Action(() =>
            {
                if (proc == _proc && !_busy) ApplyContext(ctx, proc.LastOk); else ctx.Dispose();
            }));
            CommHub.Received += (ch, t) => LogComm("RX", ch, t);
            CommHub.StateChanged += (ch, t) => LogComm("--", ch, t);

            Loaded += (s, e) => SetProject(Project.CreateDefault());
            Closing += OnClosing;
            PreviewKeyDown += (s, e) => { if (e.Key == Key.F5) { OnRunOnce(null, null); e.Handled = true; } else if (e.Key == Key.F6) { BtnLoop.IsChecked = BtnLoop.IsChecked != true; OnLoop(null, null); e.Handled = true; } };
        }

        /// <summary>Co cửa sổ theo vùng làm việc của màn hình (tránh tràn khỏi màn hình nhỏ / DPI cao).</summary>
        void FitToScreen()
        {
            var wa = SystemParameters.WorkArea;
            Width = Math.Min(1560, wa.Width); Height = Math.Min(920, wa.Height);
            MinWidth = Math.Min(900, wa.Width); MinHeight = Math.Min(560, wa.Height);
            Left = wa.Left + (wa.Width - Width) / 2; Top = wa.Top + (wa.Height - Height) / 2;
            if (wa.Width < 1500 || wa.Height < 880) WindowState = WindowState.Maximized;
        }

        // ───────────────────────── Log ─────────────────────────
        void Log(string level, string msg)
        {
            Brush b = level == "ERROR" ? App.Brush("VsErrorBrush") : level == "WARN" ? App.Brush("VsWarningBrush") : App.Brush("VsTextBrush");
            Dispatcher.BeginInvoke(new Action(() =>
            {
                _log.Add(new LogItem { Text = $"{DateTime.Now:HH:mm:ss.fff} [{level}] {msg}", Brush = b });
                while (_log.Count > 600) _log.RemoveAt(0);
                if (_log.Count > 0) LogList.ScrollIntoView(_log[_log.Count - 1]);
            }));
        }

        void LogComm(string dir, string ch, string text)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                _commLog.Add(new LogItem { Text = $"{DateTime.Now:HH:mm:ss.fff} {dir} [{ch}] {text}", Brush = App.Brush(dir == "RX" ? "VsTriggerBrush" : "VsSubTextBrush") });
                while (_commLog.Count > 400) _commLog.RemoveAt(0);
                if (_commLog.Count > 0) CommList.ScrollIntoView(_commLog[_commLog.Count - 1]);
            }));
        }

        // ───────────────────────── Toolbox / Project ─────────────────────────
        void BuildToolTree()
        {
            ToolTree.Items.Clear();
            foreach (var g in ToolRegistry.Types.GroupBy(t => ToolMeta.GetToolAttr(t).Category).OrderBy(g => { int i = Array.IndexOf(CategoryOrder, g.Key); return i < 0 ? 99 : i; }))
            {
                var cat = new TreeViewItem { Header = g.Key, IsExpanded = true, FontWeight = FontWeights.SemiBold, Foreground = App.Brush("VsInfoBrush") };
                foreach (var t in g)
                {
                    var a = ToolMeta.GetToolAttr(t);
                    cat.Items.Add(new TreeViewItem { Header = $"{a.Glyph}  {a.Name}", Tag = t, ToolTip = a.Description, FontWeight = FontWeights.Normal });
                }
                ToolTree.Items.Add(cat);
            }
        }

        void SetProject(Project p)
        {
            OnStop(null, null); _sched.Stop(); BtnSched.IsChecked = false; TxtSched.Text = "Scheduler: OFF";
            DisposeCtx(); _proj = p; _dirty = false;
            _sched.Project = p; Props.Project = p;
            CommHub.Configure(p.Comms);
            RefreshProcList(0); UpdateTitle();
        }

        void RefreshProcList(int select)
        {
            ProcList.SelectionChanged -= OnProcSelected;
            ProcList.ItemsSource = null; ProcList.ItemsSource = _proj.Procedures.Select(x => x.Name).ToList();
            ProcList.SelectionChanged += OnProcSelected;
            ProcList.SelectedIndex = Math.Max(0, Math.Min(select, _proj.Procedures.Count - 1));
        }

        void OnProcSelected(object s, SelectionChangedEventArgs e)
        {
            int i = ProcList.SelectedIndex; if (i < 0 || i >= _proj.Procedures.Count) return;
            _proc = _proj.Procedures[i]; DisposeCtx();
            Flow.Bind(_proc); Props.Procedure = _proc; Props.Bind(null);
            ToolGrid.ItemsSource = null; ReportGrid.ItemsSource = null; View.SetStatus(null, ""); TxtCycle.Text = "";
        }

        void OnProcAdd(object s, RoutedEventArgs e)
        {
            string n = Prompt.Ask(this, "New procedure", "Tên procedure:", "Procedure" + (_proj.Procedures.Count + 1)); if (string.IsNullOrWhiteSpace(n)) return;
            if (_proj.Procedures.Any(p => p.Name == n)) { MessageBox.Show(this, "Tên đã tồn tại."); return; }
            _proj.Procedures.Add(new Procedure { Name = n }); _dirty = true; RefreshProcList(_proj.Procedures.Count - 1);
        }
        void OnProcRename(object s, RoutedEventArgs e)
        {
            if (_proc == null) return; string old = _proc.Name;
            string n = Prompt.Ask(this, "Rename", "Tên mới:", old); if (string.IsNullOrWhiteSpace(n) || n == old || _proj.Procedures.Any(p => p.Name == n)) return;
            _proc.Name = n; foreach (var t in _proj.Triggers.Where(t => t.Procedure == old)) t.Procedure = n;
            _dirty = true; RefreshProcList(_proj.Procedures.IndexOf(_proc));
        }
        void OnProcDelete(object s, RoutedEventArgs e)
        {
            if (_proj.Procedures.Count <= 1) { MessageBox.Show(this, "Phải còn ít nhất 1 procedure."); return; }
            if (MessageBox.Show(this, $"Xoá '{_proc.Name}'?", "Delete", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
            _proj.Procedures.Remove(_proc); _dirty = true; RefreshProcList(0);
        }

        // ───────────────────────── Tool add / delete ─────────────────────────
        void OnToolTreeDoubleClick(object s, MouseButtonEventArgs e)
        {
            if (ToolTree.SelectedItem is TreeViewItem it && it.Tag is Type t) AddTool(t);
        }

        Point _treeDown; bool _treeDragging;
        void OnToolTreeDown(object s, MouseButtonEventArgs e) { _treeDown = e.GetPosition(ToolTree); _treeDragging = false; }
        void OnToolTreeMove(object s, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed || _treeDragging) return;
            var d = e.GetPosition(ToolTree) - _treeDown;
            if (Math.Abs(d.X) < SystemParameters.MinimumHorizontalDragDistance && Math.Abs(d.Y) < SystemParameters.MinimumVerticalDragDistance) return;
            DependencyObject o = e.OriginalSource as DependencyObject; TreeViewItem it = null;
            while (o != null && it == null) { it = o as TreeViewItem; o = it == null ? (o is Visual || o is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(o) : LogicalTreeHelper.GetParent(o)) : null; }
            if (it != null && it.Tag is Type t)
            {
                _treeDragging = true;
                DragDrop.DoDragDrop(ToolTree, new DataObject("VsToolType", t), DragDropEffects.Copy);
            }
        }

        void AddTool(Type type, Point? at = null)
        {
            if (_proc == null) return;
            var tool = ToolRegistry.Create(type);
            var sel = Flow.Selected;
            if (at.HasValue) { tool.X = at.Value.X; tool.Y = at.Value.Y; }
            else
            {
                tool.X = sel != null ? sel.X + 300 : 30 + (_proc.Tools.Count % 6) * 40;
                tool.Y = sel != null ? sel.Y : 20 + (_proc.Tools.Count % 6) * 70;
                while (_proc.Tools.Any(t => Math.Abs(t.X - tool.X) < 5 && Math.Abs(t.Y - tool.Y) < 5)) tool.Y += 90;
            }
            AutoLink(tool);
            _proc.Add(tool); _dirty = true; Flow.Select(tool);
        }

        /// <summary>Tự nối input ảnh/fixture với tool gần nhất phía trước có cổng tương ứng (tiện thao tác).</summary>
        void AutoLink(ToolBase tool)
        {
            foreach (var pi in ToolMeta.GetParams(tool.GetType()).Where(p => p.Attr.Source == Kind.Image || p.Attr.Source == Kind.Fixture))
            {
                if (pi.Prop.PropertyType != typeof(string) || !string.IsNullOrEmpty(pi.Prop.GetValue(tool) as string)) continue;
                if (pi.Attr.Source == Kind.Image && !pi.Prop.Name.Contains("Image") ) continue;
                if (pi.Attr.Source == Kind.Image && pi.Prop.Name == "ImageB") continue;
                for (int i = _proc.Tools.Count - 1; i >= 0; i--)
                {
                    var src = _proc.Tools[i];
                    var port = src.Ports.FirstOrDefault(p => p.Kind == pi.Attr.Source);
                    if (port != null) { pi.Prop.SetValue(tool, src.Name + "." + port.Name); break; }
                }
            }
        }

        void DeleteTool(ToolBase t)
        {
            if (MessageBox.Show(this, $"Xoá tool '{t.Name}'?", "Delete", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
            _proc.Remove(t); _dirty = true; Flow.Select(null);
        }

        Procedure SubProcedure(ToolBase target)
        {
            var set = new HashSet<ToolBase>();
            void Add(ToolBase t) { if (!set.Add(t)) return; foreach (var d in ToolMeta.Dependencies(t)) { var dt = _proc.Find(d); if (dt != null) Add(dt); } }
            Add(target);
            return new Procedure { Name = _proc.Name, Tools = _proc.Tools.Where(set.Contains).ToList() };
        }

        // ───────────────────────── Run ─────────────────────────
        async void OnRunOnce(object s, RoutedEventArgs e) { await RunAsync(); }

        async Task RunAsync(Procedure only = null)
        {
            if (_busy || _proc == null) return;
            _busy = true; BtnRun.IsEnabled = false; TxtStatus.Text = "Running…";
            try
            {
                var run = only ?? _proc;
                var ctx = await Task.Run(() => _sched.RunOnce(run));
                ApplyContext(ctx, run.LastOk);
            }
            catch (Exception ex) { Log("ERROR", ex.Message); }
            finally { _busy = false; BtnRun.IsEnabled = true; TxtStatus.Text = "Ready"; }
        }

        RunContext RunSync()
        {
            var ctx = _sched.RunOnce(_proc); ApplyContext(ctx, _proc.LastOk); return _ctx;
        }

        void DisposeCtx() { View.Clear(); _ctx?.Dispose(); _ctx = null; }

        void ApplyContext(RunContext ctx, bool ok)
        {
            DisposeCtx(); _ctx = ctx;
            Flow.Rebuild();
            var rows = _proc.Order().Where(t => t.Result != null && (t.Result.Executed || t.Result.Skipped)).Select(t => new ToolRow
            {
                Name = t.Name, Status = t.Result.Skipped ? (t.Result.Ok || string.IsNullOrEmpty(t.Result.Message) || t.Result.Message == "Condition false" ? "skip" : "NG") : t.Result.Ok ? "OK" : "NG",
                Ms = t.Result.Ms.ToString("0.#"), Message = t.Result.Message
            }).ToList();
            ToolGrid.ItemsSource = rows; ReportGrid.ItemsSource = ctx.Report.ToList();
            double total = _proc.Tools.Where(t => t.Result != null && t.Result.Executed).Sum(t => t.Result.Ms);
            TxtCycle.Text = $"Cycle {total:0.#} ms";
            View.SetStatus(ok, ok ? "OK" : "NG");
            ShowCurrent();
        }

        void ShowCurrent()
        {
            if (_ctx == null) { View.Clear(); return; }
            View.Show(PickImage(), _ctx.Overlays);
        }

        HObject PickImage()
        {
            HObject FromValue(string key) => _ctx.Values.TryGetValue(key, out object o) && o is HObject h && h.IsInitialized() ? h : null;
            var sel = Flow.Selected;
            if (sel != null)
            {
                foreach (var port in sel.Ports.Where(p => p.Kind == Kind.Image)) { var h = FromValue(RunContext.Key(sel.Name, port.Name)); if (h != null) return h; }
                foreach (var pi in ToolMeta.GetParams(sel.GetType()).Where(p => p.Attr.Source == Kind.Image && p.Prop.PropertyType == typeof(string)))
                { var link = pi.Prop.GetValue(sel) as string; if (!string.IsNullOrWhiteSpace(link)) { var h = FromValue(link.Trim()); if (h != null) return h; } }
            }
            foreach (var t in _proc.Order()) foreach (var port in t.Ports.Where(p => p.Kind == Kind.Image)) { var h = FromValue(RunContext.Key(t.Name, port.Name)); if (h != null) return h; }
            return null;
        }

        void OnSelectTool(ToolBase t) { Props.Bind(t); ShowCurrent(); }

        async void OnLoop(object s, RoutedEventArgs e)
        {
            if (BtnLoop.IsChecked == true)
            {
                _loopCts = new CancellationTokenSource(); var ct = _loopCts.Token;
                while (!ct.IsCancellationRequested) { await RunAsync(); try { await Task.Delay(30, ct); } catch { break; } }
            }
            else _loopCts?.Cancel();
        }

        void OnStop(object s, RoutedEventArgs e) { BtnLoop.IsChecked = false; _loopCts?.Cancel(); }

        // ───────────────────────── ROI / Action ─────────────────────────
        void OnDrawRoi(RoiBase roi)
        {
            try
            {
                if (!View.HasImage) { RunSync(); }
                if (!View.HasImage) { MessageBox.Show(this, "Chưa có ảnh để vẽ ROI. Hãy chạy procedure (Run once) với Image Source hợp lệ.", "ROI"); return; }
                TxtStatus.Text = "Vẽ ROI: chuột trái để vẽ/chỉnh, CHUỘT PHẢI để xác nhận";
                View.DrawRoi(roi); _dirty = true; TxtStatus.Text = "Ready";
                ShowCurrent();
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "ROI"); }
        }

        async void OnToolAction(IToolAction act)
        {
            try
            {
                if (_ctx == null) RunSync();
                if (_ctx == null) return;
                string msg = act.DoAction(_ctx); Log("INFO", msg); TxtStatus.Text = msg; _dirty = true;
                Props.Bind(Flow.Selected);
                await RunAsync();
            }
            catch (Exception ex) { Log("ERROR", ex.Message); MessageBox.Show(this, ex.Message, act.ActionName, MessageBoxButton.OK, MessageBoxImage.Warning); }
        }

        // ───────────────────────── Scheduler / dialogs ─────────────────────────
        void OnScheduler(object s, RoutedEventArgs e)
        {
            if (BtnSched.IsChecked == true) { _sched.Start(_proj, Log); TxtSched.Text = "Scheduler: ON"; TxtSched.Foreground = App.Brush("VsSuccessBrush"); }
            else { _sched.Stop(); TxtSched.Text = "Scheduler: OFF"; TxtSched.Foreground = App.Brush("VsSubTextBrush"); }
        }

        void OnCameras(object s, RoutedEventArgs e)
        {
            var extras = new List<KeyValuePair<string, Action<CameraConfig>>>
            {
                new KeyValuePair<string, Action<CameraConfig>>("Open", c => { CameraService.Open(c); Log("INFO", "Camera mở: " + c.Name); }),
                new KeyValuePair<string, Action<CameraConfig>>("Apply settings", c => CameraService.Apply(c)),
                new KeyValuePair<string, Action<CameraConfig>>("Grab → view", c =>
                {
                    if (!CameraService.IsOpen(c.Name)) CameraService.Open(c);
                    var img = CameraService.Grab(c); View.Clear(); _manualImage?.Dispose(); _manualImage = img; View.Show(img, null);
                }),
                new KeyValuePair<string, Action<CameraConfig>>("Close", c => CameraService.Close(c.Name)),
                new KeyValuePair<string, Action<CameraConfig>>("List devices", c =>
                    MessageBox.Show(string.Join("\n", CameraService.EnumerateDevices(c.Interface).DefaultIfEmpty("(không có thiết bị / thiếu interface)")), "Devices (" + c.Interface + ")"))
            };
            new ListEditorWindow<CameraConfig>(this, "Cameras", _proj.Cameras, () => new CameraConfig { Name = "Cam" + (_proj.Cameras.Count + 1) }, c => c.Name, _proj, extras).ShowDialog();
            _dirty = true; Props.Bind(Flow.Selected);
        }

        void OnComm(object s, RoutedEventArgs e)
        {
            var extras = new List<KeyValuePair<string, Action<CommConfig>>>
            {
                new KeyValuePair<string, Action<CommConfig>>("Apply / restart all", c => CommHub.Configure(_proj.Comms)),
                new KeyValuePair<string, Action<CommConfig>>("Send test text", c =>
                { string t = Prompt.Ask(this, "Send", "Nội dung gửi qua '" + c.Name + "':", "HELLO"); if (t != null) { bool ok = CommHub.Send(c.Name, t); LogComm("TX", c.Name, t + (ok ? "" : "  (không gửi được)")); } })
            };
            new ListEditorWindow<CommConfig>(this, "Communication", _proj.Comms, () => new CommConfig { Name = "Comm" + (_proj.Comms.Count + 1), Port = 8000 + _proj.Comms.Count }, c => c.Name, _proj, extras).ShowDialog();
            CommHub.Configure(_proj.Comms); _dirty = true; Props.Bind(Flow.Selected);
        }

        void OnTriggers(object s, RoutedEventArgs e)
        {
            var extras = new List<KeyValuePair<string, Action<TriggerRule>>> { new KeyValuePair<string, Action<TriggerRule>>("Run now", r => Task.Run(() => _sched.Execute(r, null))) };
            new ListEditorWindow<TriggerRule>(this, "Triggers (Scheduler)", _proj.Triggers, () => new TriggerRule { Name = "Trigger" + (_proj.Triggers.Count + 1), Procedure = _proc?.Name }, r => r.Name, _proj, extras).ShowDialog();
            _dirty = true;
            if (BtnSched.IsChecked == true) { _sched.Stop(); _sched.Start(_proj, Log); }
        }

        void OnCalibration(object s, RoutedEventArgs e)
        {
            var w = new CalibrationWindow(this, _proj, _proc, () => { RunSync(); return _ctx; });
            w.ShowDialog(); if (w.Changed) _dirty = true; Props.Bind(Flow.Selected);
        }

        void OnNodeView(object s, RoutedEventArgs e)
        {
            bool big = BtnNodeView.IsChecked == true;
            RowImage.Height = big ? new GridLength(0) : new GridLength(3, GridUnitType.Star);
            RowSplit.Height = big ? new GridLength(0) : new GridLength(5);
            RowFlow.Height = big ? new GridLength(1, GridUnitType.Star) : new GridLength(2, GridUnitType.Star);
        }

        void OnFit(object s, RoutedEventArgs e) => View.FitImage();
        void OnAutoLayout(object s, RoutedEventArgs e) => Flow.AutoLayout();
        void OnTheme(object s, RoutedEventArgs e) { App.SetTheme(!App.IsDark); BuildToolTree(); Flow.Rebuild(); View.Redraw(); Props.Bind(Flow.Selected); }

        // ───────────────────────── Mở ảnh nhanh ─────────────────────────
        void OnOpenImage(object s, RoutedEventArgs e)
        {
            var d = new OpenFileDialog { Filter = "Ảnh|*.bmp;*.png;*.jpg;*.jpeg;*.tif;*.tiff|Tất cả|*.*" };
            if (d.ShowDialog() == true) LoadImageFile(d.FileName);
        }

        void OnFileDrop(object s, DragEventArgs e)
        {
            if (e.Data.GetData(DataFormats.FileDrop) is string[] files && files.Length > 0) LoadImageFile(files[0]);
        }

        /// <summary>Tạo (nếu chưa có) tool Image Source ở chế độ File, gán đường dẫn rồi chạy để hiển thị ảnh.</summary>
        async void LoadImageFile(string path)
        {
            if (_proc == null) return;
            var src = _proc.Tools.OfType<ImageSourceTool>().FirstOrDefault();
            if (src == null) { src = new ImageSourceTool { X = 30, Y = 20 }; _proc.Add(src); }
            src.Mode = "File"; src.FilePath = path; _dirty = true;
            Flow.Select(src);
            await RunAsync();
            if (!View.HasImage) TxtStatus.Text = "Không hiển thị được ảnh – xem tab Log";
        }

        // ───────────────────────── File ─────────────────────────
        const string Filter = "VisionStudio project (*.vsproj)|*.vsproj";

        bool ConfirmDiscard()
        {
            if (!_dirty) return true;
            var r = MessageBox.Show(this, "Lưu thay đổi trước khi tiếp tục?", "VisionStudio", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (r == MessageBoxResult.Cancel) return false;
            if (r == MessageBoxResult.Yes) return SaveProject(false);
            return true;
        }

        void OnNew(object s, RoutedEventArgs e) { if (ConfirmDiscard()) SetProject(Project.CreateDefault()); }

        void OnOpen(object s, RoutedEventArgs e)
        {
            if (!ConfirmDiscard()) return;
            var d = new OpenFileDialog { Filter = Filter }; if (d.ShowDialog() != true) return;
            try { SetProject(Project.Load(d.FileName)); Log("INFO", "Mở " + d.FileName); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Open"); }
        }

        void OnSave(object s, RoutedEventArgs e) => SaveProject(false);
        void OnSaveAs(object s, RoutedEventArgs e) => SaveProject(true);

        bool SaveProject(bool asNew)
        {
            try
            {
                string path = _proj.FilePath;
                if (asNew || string.IsNullOrEmpty(path))
                {
                    var d = new SaveFileDialog { Filter = Filter, FileName = _proj.Name + ".vsproj" }; if (d.ShowDialog() != true) return false; path = d.FileName;
                    _proj.Name = Path.GetFileNameWithoutExtension(path);
                }
                string oldModels = _proj.ModelDir; _proj.Save(path); string newModels = _proj.ModelDir;
                if (!string.Equals(oldModels, newModels, StringComparison.OrdinalIgnoreCase) && Directory.Exists(oldModels))
                    foreach (var f in Directory.GetFiles(oldModels)) { try { File.Copy(f, Path.Combine(newModels, Path.GetFileName(f)), true); } catch { } }
                _dirty = false; UpdateTitle(); Log("INFO", "Đã lưu " + path); return true;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Save"); return false; }
        }

        void UpdateTitle() => Title = "VisionStudio – " + (string.IsNullOrEmpty(_proj.FilePath) ? "(chưa lưu)" : _proj.FilePath);

        void OnClosing(object s, System.ComponentModel.CancelEventArgs e)
        {
            if (!ConfirmDiscard()) { e.Cancel = true; return; }
            _loopCts?.Cancel(); _sched.Dispose(); CommHub.StopAll(); CameraService.CloseAll();
            DisposeCtx(); _manualImage?.Dispose();
        }
    }
}
