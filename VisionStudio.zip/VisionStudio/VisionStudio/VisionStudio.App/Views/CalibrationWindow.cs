using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using VisionStudio.Core.Calibration;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Geometry;

namespace VisionStudio.App.Views
{
    public class CalRow { public double Px { get; set; } public double Py { get; set; } public double Rx { get; set; } public double Ry { get; set; } }
    public class RotRow { public int No { get; set; } public double X { get; set; } public double Y { get; set; } }

    /// <summary>Hiệu chỉnh: (1) N-point affine pixel→mm, (2) tâm xoay stage, (3) scale mm/px.
    /// Điểm pixel được lấy từ cổng "Point" của 1 tool trong procedure hiện tại (vd. ShapeMatch1.Point).</summary>
    public class CalibrationWindow : Window
    {
        readonly Project _proj; readonly Procedure _proc; readonly Func<RunContext> _run;
        readonly ComboBox _calSel = new ComboBox { IsEditable = true, MinWidth = 160 };
        readonly ComboBox _link = new ComboBox { MinWidth = 220 };
        readonly ObservableCollection<CalRow> _rows = new ObservableCollection<CalRow>();
        readonly ObservableCollection<RotRow> _rot = new ObservableCollection<RotRow>();
        readonly TextBlock _msg = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(4) };
        readonly TextBox _knownMm = new TextBox { Text = "10", Width = 80 }, _pxDist = new TextBox { Text = "100", Width = 80 };
        readonly CheckBox _flipY = new CheckBox { Content = "Flip Y (Y mm hướng lên)", Margin = new Thickness(0, 4, 0, 0) };
        public bool Changed { get; private set; }

        public CalibrationWindow(Window owner, Project proj, Procedure proc, Func<RunContext> runProcedure)
        {
            Owner = owner; _proj = proj; _proc = proc; _run = runProcedure;
            Title = "Calibration"; Width = 760; Height = 600; WindowStartupLocation = WindowStartupLocation.CenterOwner;

            var root = new DockPanel { Margin = new Thickness(8) };
            var top = new WrapPanel { Margin = new Thickness(0, 0, 0, 6) }; DockPanel.SetDock(top, Dock.Top);
            top.Children.Add(new TextBlock { Text = "Calibration:", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) });
            top.Children.Add(_calSel);
            var bNew = new Button { Content = "＋ New" }; bNew.Click += (s, e) => { string n = Prompt.Ask(this, "New calibration", "Tên calibration:", "Cal" + (_proj.Calibrations.Count + 1)); if (!string.IsNullOrWhiteSpace(n)) { Ensure(n); LoadList(n); } };
            var bDel = new Button { Content = "Delete" }; bDel.Click += (s, e) => { var c = Cur(); if (c != null) { _proj.Calibrations.Remove(c); Changed = true; LoadList(null); } };
            top.Children.Add(bNew); top.Children.Add(bDel);
            top.Children.Add(new TextBlock { Text = "   Point source:", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 6, 0) });
            top.Children.Add(_link);
            root.Children.Add(top);

            _msg.Foreground = App.Brush("VsSubTextBrush"); DockPanel.SetDock(_msg, Dock.Bottom); root.Children.Add(_msg);

            var tabs = new TabControl();
            tabs.Items.Add(new TabItem { Header = "N-point (pixel → mm)", Content = BuildNPoint() });
            tabs.Items.Add(new TabItem { Header = "Rotation center", Content = BuildRot() });
            tabs.Items.Add(new TabItem { Header = "Scale (mm/px)", Content = BuildScale() });
            root.Children.Add(tabs); Content = root;

            // nguồn điểm
            var srcs = new List<string>();
            foreach (var t in _proc.Tools) foreach (var p in t.AllPorts) if (p.Kind == Kind.Point || p.Kind == Kind.Pose) srcs.Add(t.Name + "." + p.Name);
            _link.ItemsSource = srcs; if (srcs.Count > 0) _link.SelectedIndex = 0;
            LoadList(_proj.Calibrations.FirstOrDefault()?.Name);
        }

        void LoadList(string select)
        {
            _calSel.ItemsSource = _proj.Calibrations.Select(c => c.Name).ToList();
            _calSel.Text = select ?? (_proj.Calibrations.Count > 0 ? _proj.Calibrations[0].Name : "");
            ShowInfo();
        }
        CalibrationData Ensure(string name)
        {
            var c = _proj.FindCalib(name); if (c == null) { c = new CalibrationData { Name = name }; _proj.Calibrations.Add(c); Changed = true; }
            return c;
        }
        CalibrationData Cur() => string.IsNullOrWhiteSpace(_calSel.Text) ? null : _proj.FindCalib(_calSel.Text);
        CalibrationData CurOrNew() { if (string.IsNullOrWhiteSpace(_calSel.Text)) _calSel.Text = "Cal1"; return Ensure(_calSel.Text.Trim()); }

        void ShowInfo()
        {
            var c = Cur();
            _msg.Text = c == null ? "Chưa có calibration. Bấm '＋ New'." :
                $"[{c.Name}] valid={c.Valid}  pixel size = {c.PixelSizeX:0.#####} × {c.PixelSizeY:0.#####} mm/px  RMS={c.RmsMm:0.####} mm  max={c.MaxMm:0.####}  RC=({c.RotCenterX:0.###}, {c.RotCenterY:0.###})  [{c.Created}]";
        }

        bool Capture(out Pt px)
        {
            px = new Pt();
            if (_link.SelectedItem == null) { MessageBox.Show(this, "Chọn 'Point source' (cổng Point của 1 tool).", Title); return false; }
            var ctx = _run(); if (ctx == null) return false;
            string link = (string)_link.SelectedItem;
            if (!ctx.Values.TryGetValue(link, out object o)) { MessageBox.Show(this, "Tool chưa có kết quả '" + link + "' (kiểm tra ảnh/tool có OK không).", Title); return false; }
            if (o is Pt p) px = p; else if (o is Xyt x) px = new Pt(x.X, x.Y); else return false;
            return true;
        }

        FrameworkElement BuildNPoint()
        {
            var dock = new DockPanel { Margin = new Thickness(0, 6, 0, 0) };
            var bar = new WrapPanel(); DockPanel.SetDock(bar, Dock.Bottom);
            var grid = new DataGrid { ItemsSource = _rows, CanUserAddRows = false };
            foreach (var h in new[] { ("Px (col)", "Px"), ("Py (row)", "Py"), ("Robot X mm", "Rx"), ("Robot Y mm", "Ry") })
                grid.Columns.Add(new DataGridTextColumn { Header = h.Item1, Width = new DataGridLength(1, DataGridLengthUnitType.Star), Binding = new System.Windows.Data.Binding(h.Item2) { StringFormat = "0.###" } });
            var cap = new Button { Content = "📷 Capture pixel (run)", Style = (Style)FindResource("AccentButton") };
            cap.Click += (s, e) => { if (Capture(out Pt p)) _rows.Add(new CalRow { Px = p.X, Py = p.Y }); };
            var add = new Button { Content = "＋ Row" }; add.Click += (s, e) => _rows.Add(new CalRow());
            var del = new Button { Content = "Delete row" }; del.Click += (s, e) => { if (grid.SelectedItem is CalRow r) _rows.Remove(r); };
            var clr = new Button { Content = "Clear" }; clr.Click += (s, e) => _rows.Clear();
            var solve = new Button { Content = "✔ Solve → save", Style = (Style)FindResource("AccentButton") };
            solve.Click += (s, e) =>
            {
                if (_rows.Count < 3) { MessageBox.Show(this, "Cần ≥ 3 điểm (khuyến nghị 9, không thẳng hàng).", Title); return; }
                var c0 = CurOrNew();
                var sol = CalibrationData.SolveAffine(c0.Name, _rows.Select(r => new Pt(r.Px, r.Py)).ToList(), _rows.Select(r => new Pt(r.Rx, r.Ry)).ToList());
                if (!sol.Valid) { MessageBox.Show(this, "Giải thất bại (điểm thẳng hàng?).", Title); return; }
                c0.Hom = sol.Hom; c0.Valid = true; c0.PixelSizeX = sol.PixelSizeX; c0.PixelSizeY = sol.PixelSizeY; c0.RmsMm = sol.RmsMm; c0.MaxMm = sol.MaxMm; c0.PointCount = sol.PointCount; c0.Created = sol.Created;
                Changed = true; LoadList(c0.Name);
            };
            foreach (var b in new Button[] { cap, add, del, clr, solve }) bar.Children.Add(b);
            dock.Children.Add(bar);
            dock.Children.Add(new TextBlock { Text = "Di chuyển vật/stage tới ≥ 9 vị trí (lưới 3×3). Mỗi vị trí: bấm Capture rồi nhập toạ độ robot (mm).", Foreground = App.Brush("VsSubTextBrush"), Margin = new Thickness(0, 0, 0, 6), TextWrapping = TextWrapping.Wrap });
            DockPanel.SetDock(dock.Children[dock.Children.Count - 1], Dock.Top);
            dock.Children.Add(grid); return dock;
        }

        FrameworkElement BuildRot()
        {
            var dock = new DockPanel { Margin = new Thickness(0, 6, 0, 0) };
            var bar = new WrapPanel(); DockPanel.SetDock(bar, Dock.Bottom);
            var hint = new TextBlock { Text = "Xoay stage qua ≥ 3 góc khác nhau (vd. -5°, 0°, +5°) với cùng 1 mark. Mỗi góc bấm Capture (đổi sang mm bằng calibration hiện tại) → Solve = fit đường tròn.", Foreground = App.Brush("VsSubTextBrush"), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 6) };
            DockPanel.SetDock(hint, Dock.Top); dock.Children.Add(hint);
            var grid = new DataGrid { ItemsSource = _rot, IsReadOnly = true };
            grid.Columns.Add(new DataGridTextColumn { Header = "#", Binding = new System.Windows.Data.Binding("No"), Width = 40 });
            grid.Columns.Add(new DataGridTextColumn { Header = "X mm", Binding = new System.Windows.Data.Binding("X") { StringFormat = "0.####" }, Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
            grid.Columns.Add(new DataGridTextColumn { Header = "Y mm", Binding = new System.Windows.Data.Binding("Y") { StringFormat = "0.####" }, Width = new DataGridLength(1, DataGridLengthUnitType.Star) });
            var cap = new Button { Content = "📷 Capture (mm)", Style = (Style)FindResource("AccentButton") };
            cap.Click += (s, e) =>
            {
                var c = Cur(); if (c == null || !c.Valid) { MessageBox.Show(this, "Cần calibration N-point hợp lệ trước.", Title); return; }
                if (Capture(out Pt p)) { var m = c.V2R(p); _rot.Add(new RotRow { No = _rot.Count + 1, X = m.X, Y = m.Y }); }
            };
            var clr = new Button { Content = "Clear" }; clr.Click += (s, e) => _rot.Clear();
            var solve = new Button { Content = "✔ Solve rotation center", Style = (Style)FindResource("AccentButton") };
            solve.Click += (s, e) =>
            {
                var c = Cur(); if (c == null) return;
                if (_rot.Count < 3) { MessageBox.Show(this, "Cần ≥ 3 điểm.", Title); return; }
                if (c.SolveRotationCenter(_rot.Select(r => new Pt(r.X, r.Y)).ToList(), out double res)) { Changed = true; ShowInfo(); _msg.Text += $"   → tâm xoay residual = {res:0.####} mm"; }
                else MessageBox.Show(this, "Fit thất bại.", Title);
            };
            bar.Children.Add(cap); bar.Children.Add(clr); bar.Children.Add(solve); dock.Children.Add(bar); dock.Children.Add(grid); return dock;
        }

        FrameworkElement BuildScale()
        {
            var sp = new StackPanel { Margin = new Thickness(0, 10, 0, 0) };
            sp.Children.Add(new TextBlock { Text = "Cách nhanh khi không cần hệ toạ độ robot: nhập khoảng cách thật (mm) và khoảng cách pixel tương ứng.", TextWrapping = TextWrapping.Wrap, Foreground = App.Brush("VsSubTextBrush"), Margin = new Thickness(0, 0, 0, 8) });
            var r1 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
            r1.Children.Add(new TextBlock { Text = "Known distance (mm):", Width = 150, VerticalAlignment = VerticalAlignment.Center }); r1.Children.Add(_knownMm); sp.Children.Add(r1);
            var r2 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
            r2.Children.Add(new TextBlock { Text = "Pixel distance:", Width = 150, VerticalAlignment = VerticalAlignment.Center }); r2.Children.Add(_pxDist); sp.Children.Add(r2);
            sp.Children.Add(_flipY);
            var apply = new Button { Content = "✔ Apply scale → save", Style = (Style)FindResource("AccentButton"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 10, 0, 0) };
            apply.Click += (s, e) =>
            {
                if (!double.TryParse(_knownMm.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out double mm) || !double.TryParse(_pxDist.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out double px) || mm <= 0 || px <= 0)
                { MessageBox.Show(this, "Giá trị không hợp lệ.", Title); return; }
                var c0 = CurOrNew(); var sc = CalibrationData.FromScale(c0.Name, mm / px, _flipY.IsChecked == true);
                c0.Hom = sc.Hom; c0.Valid = true; c0.PixelSizeX = sc.PixelSizeX; c0.PixelSizeY = sc.PixelSizeY; c0.RmsMm = 0; c0.MaxMm = 0; c0.Created = sc.Created;
                Changed = true; LoadList(c0.Name);
            };
            sp.Children.Add(apply); return sp;
        }
    }
}
