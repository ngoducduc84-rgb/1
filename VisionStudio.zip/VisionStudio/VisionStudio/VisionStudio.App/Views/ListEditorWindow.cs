using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using VisionStudio.App.Controls;
using VisionStudio.Core.Framework;

namespace VisionStudio.App.Views
{
    /// <summary>Cửa sổ chỉnh danh sách cấu hình (Camera / Comm / Trigger) bằng PropertyPanel dùng chung.</summary>
    public class ListEditorWindow<T> : Window where T : class
    {
        readonly IList<T> _items; readonly Func<T> _factory; readonly Func<T, string> _name;
        readonly ListBox _list = new ListBox(); readonly PropertyPanel _props = new PropertyPanel { ShowHeader = false };

        public ListEditorWindow(Window owner, string title, IList<T> items, Func<T> factory, Func<T, string> nameOf, Project project,
                                IEnumerable<KeyValuePair<string, Action<T>>> extras = null)
        {
            Title = title; Owner = owner; Width = 820; Height = 560; WindowStartupLocation = WindowStartupLocation.CenterOwner;
            _items = items; _factory = factory; _name = nameOf; _props.Project = project;

            var grid = new Grid { Margin = new Thickness(8) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) }); grid.ColumnDefinitions.Add(new ColumnDefinition());
            var left = new DockPanel { Margin = new Thickness(0, 0, 8, 0) };
            var btns = new WrapPanel(); DockPanel.SetDock(btns, Dock.Bottom);
            var add = new Button { Content = "＋ Add" }; add.Click += (s, e) => { var n = _factory(); _items.Add(n); Reload(n); };
            var del = new Button { Content = "Delete" }; del.Click += (s, e) => { if (_list.SelectedIndex >= 0) { _items.RemoveAt(_list.SelectedIndex); Reload(null); } };
            btns.Children.Add(add); btns.Children.Add(del);
            left.Children.Add(btns); left.Children.Add(_list); grid.Children.Add(left);

            var right = new DockPanel { }; Grid.SetColumn(right, 1);
            if (extras != null)
            {
                var ex = new WrapPanel { Margin = new Thickness(0, 6, 0, 0) }; DockPanel.SetDock(ex, Dock.Bottom);
                foreach (var kv in extras)
                {
                    var a = kv.Value; var b = new Button { Content = kv.Key, Style = (Style)FindResource("AccentButton") };
                    b.Click += (s, e) => { if (_list.SelectedItem is T t) { try { a(t); } catch (Exception ex2) { MessageBox.Show(this, ex2.Message, Title, MessageBoxButton.OK, MessageBoxImage.Warning); } } };
                    ex.Children.Add(b);
                }
                right.Children.Add(ex);
            }
            right.Children.Add(_props); grid.Children.Add(right);
            Content = grid;

            _list.SelectionChanged += (s, e) => _props.Bind(_list.SelectedItem as T);
            _props.ValueChanged += o => { int i = _list.SelectedIndex; _list.Items.Refresh(); _list.SelectedIndex = i; };
            Reload(_items.FirstOrDefault());
        }

        void Reload(T select)
        {
            _list.ItemsSource = null; _list.ItemsSource = _items.ToList();
            _list.DisplayMemberPath = null;
            _list.ItemTemplate = null;
            _list.ItemContainerStyle = null;
            // hiển thị tên bằng ItemTemplate động
            var dt = new DataTemplate(); var f = new FrameworkElementFactory(typeof(TextBlock));
            f.SetBinding(TextBlock.TextProperty, new System.Windows.Data.Binding { Converter = new NameConv(_name) });
            dt.VisualTree = f; _list.ItemTemplate = dt;
            if (select != null) _list.SelectedItem = select; else if (_items.Count > 0) _list.SelectedIndex = 0; else _props.Bind(null);
        }

        class NameConv : System.Windows.Data.IValueConverter
        {
            readonly Func<T, string> _f; public NameConv(Func<T, string> f) { _f = f; }
            public object Convert(object v, Type t, object p, System.Globalization.CultureInfo c) => v is T x ? _f(x) : "";
            public object ConvertBack(object v, Type t, object p, System.Globalization.CultureInfo c) => throw new NotSupportedException();
        }
    }
}
