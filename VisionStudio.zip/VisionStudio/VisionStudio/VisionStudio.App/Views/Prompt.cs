using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace VisionStudio.App.Views
{
    /// <summary>Hộp nhập chuỗi đơn giản.</summary>
    public static class Prompt
    {
        public static string Ask(Window owner, string title, string label, string def = "")
        {
            var w = new Window { Title = title, Width = 420, SizeToContent = SizeToContent.Height, Owner = owner, WindowStartupLocation = WindowStartupLocation.CenterOwner, ResizeMode = ResizeMode.NoResize, ShowInTaskbar = false };
            var sp = new StackPanel { Margin = new Thickness(14) };
            sp.Children.Add(new TextBlock { Text = label, Margin = new Thickness(0, 0, 0, 6), TextWrapping = TextWrapping.Wrap });
            var tb = new TextBox { Text = def, Margin = new Thickness(0, 0, 0, 10) }; sp.Children.Add(tb);
            var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            string result = null;
            var ok = new Button { Content = "OK", Width = 70, IsDefault = true }; ok.Click += (s, e) => { result = tb.Text; w.DialogResult = true; };
            var cancel = new Button { Content = "Cancel", Width = 70, IsCancel = true };
            row.Children.Add(ok); row.Children.Add(cancel); sp.Children.Add(row); w.Content = sp;
            w.Loaded += (s, e) => { tb.Focus(); tb.SelectAll(); };
            return w.ShowDialog() == true ? result : null;
        }
    }
}
