using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using VisionStudio.Core.Geometry;

namespace VisionStudio.Core.Calibration
{
    /// <summary>Hiệu chỉnh pixel → mm (affine 2x3, hàng-chủ: x=h0*px+h1*py+h2, y=h3*px+h4*py+h5, với px=cột, py=hàng) + tâm xoay.</summary>
    public class CalibrationData
    {
        public string Name { get; set; } = "Cal1";
        public double[] Hom { get; set; } = { 1, 0, 0, 0, 1, 0 };
        public bool Valid { get; set; }
        public double RotCenterX { get; set; }   // mm, tâm xoay của stage (theta)
        public double RotCenterY { get; set; }
        public double PixelSizeX { get; set; } = 1;
        public double PixelSizeY { get; set; } = 1;
        public double RmsMm { get; set; }
        public double MaxMm { get; set; }
        public int PointCount { get; set; }
        public string Created { get; set; }

        [JsonIgnore] public Pt RotCenter => new Pt(RotCenterX, RotCenterY);

        /// <summary>Pixel (X=col, Y=row) → mm.</summary>
        public Pt V2R(Pt px) => new Pt(Hom[0] * px.X + Hom[1] * px.Y + Hom[2], Hom[3] * px.X + Hom[4] * px.Y + Hom[5]);

        public Pt R2V(Pt mm)
        {
            double a = Hom[0], b = Hom[1], c = Hom[3], d = Hom[4];
            double det = a * d - b * c; if (Math.Abs(det) < 1e-18) return mm;
            double x = mm.X - Hom[2], y = mm.Y - Hom[5];
            return new Pt((d * x - b * y) / det, (-c * x + a * y) / det);
        }

        /// <summary>Góc trong ảnh (độ, ngược kim đồng hồ trên màn hình) → góc trong hệ mm.</summary>
        public double AngleToRobotDeg(double visionDeg)
        {
            double r = visionDeg * GeoMath.D2R;
            double dx = Math.Cos(r), dy = -Math.Sin(r);   // ảnh: hàng hướng xuống
            double rx = Hom[0] * dx + Hom[1] * dy, ry = Hom[3] * dx + Hom[4] * dy;
            return GeoMath.NormDeg(Math.Atan2(ry, rx) * GeoMath.R2D);
        }

        public static CalibrationData FromScale(string name, double mmPerPixel, bool flipY)
            => new CalibrationData
            {
                Name = name, Valid = mmPerPixel > 0, PixelSizeX = mmPerPixel, PixelSizeY = mmPerPixel,
                Hom = new[] { mmPerPixel, 0, 0, 0, flipY ? -mmPerPixel : mmPerPixel, 0 },
                Created = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

        /// <summary>Giải affine bình phương tối thiểu từ N >= 3 cặp (pixel → mm).</summary>
        public static CalibrationData SolveAffine(string name, IList<Pt> px, IList<Pt> mm)
        {
            int n = px.Count;
            if (n < 3 || mm.Count != n) return new CalibrationData { Name = name, Valid = false };
            // Phương trình chuẩn 3x3: [Σx² Σxy Σx; Σxy Σy² Σy; Σx Σy n] · [a b t]ᵀ = [Σxu Σyu Σu]ᵀ
            double sxx = 0, sxy = 0, sx = 0, syy = 0, sy = 0;
            double sxu = 0, syu = 0, su = 0, sxv = 0, syv = 0, sv = 0;
            for (int i = 0; i < n; i++)
            {
                double x = px[i].X, y = px[i].Y, u = mm[i].X, v = mm[i].Y;
                sxx += x * x; sxy += x * y; sx += x; syy += y * y; sy += y;
                sxu += x * u; syu += y * u; su += u; sxv += x * v; syv += y * v; sv += v;
            }
            double[,] A = { { sxx, sxy, sx }, { sxy, syy, sy }, { sx, sy, n } };
            if (!Solve3(A, new[] { sxu, syu, su }, out double[] p1) || !Solve3(A, new[] { sxv, syv, sv }, out double[] p2))
                return new CalibrationData { Name = name, Valid = false };
            var cal = new CalibrationData
            {
                Name = name, Valid = true, PointCount = n,
                Hom = new[] { p1[0], p1[1], p1[2], p2[0], p2[1], p2[2] },
                Created = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };
            cal.PixelSizeX = Math.Sqrt(cal.Hom[0] * cal.Hom[0] + cal.Hom[3] * cal.Hom[3]);
            cal.PixelSizeY = Math.Sqrt(cal.Hom[1] * cal.Hom[1] + cal.Hom[4] * cal.Hom[4]);
            double sum = 0, max = 0;
            for (int i = 0; i < n; i++) { double e = cal.V2R(px[i]).DistTo(mm[i]); sum += e * e; if (e > max) max = e; }
            cal.RmsMm = Math.Sqrt(sum / n); cal.MaxMm = max;
            return cal;
        }

        static bool Solve3(double[,] A, double[] b, out double[] x)
        {
            x = new double[3]; var m = (double[,])A.Clone(); var r = (double[])b.Clone();
            for (int c = 0; c < 3; c++)
            {
                int piv = c; for (int i = c + 1; i < 3; i++) if (Math.Abs(m[i, c]) > Math.Abs(m[piv, c])) piv = i;
                if (Math.Abs(m[piv, c]) < 1e-14) return false;
                if (piv != c) { for (int k = 0; k < 3; k++) { var t = m[c, k]; m[c, k] = m[piv, k]; m[piv, k] = t; } var tr = r[c]; r[c] = r[piv]; r[piv] = tr; }
                for (int i = c + 1; i < 3; i++)
                {
                    double f = m[i, c] / m[c, c];
                    for (int k = c; k < 3; k++) m[i, k] -= f * m[c, k];
                    r[i] -= f * r[c];
                }
            }
            for (int i = 2; i >= 0; i--)
            {
                double s = r[i]; for (int k = i + 1; k < 3; k++) s -= m[i, k] * x[k];
                x[i] = s / m[i, i];
            }
            return true;
        }

        /// <summary>Tâm xoay stage: các điểm mm của 1 mark khi stage xoay quanh tâm → fit đường tròn.</summary>
        public bool SolveRotationCenter(IList<Pt> markMm, out double residualMm)
        {
            residualMm = 0;
            if (!GeoMath.FitCircle(markMm, out double cx, out double cy, out double r)) return false;
            double sum = 0; foreach (var p in markMm) { double e = Math.Abs(p.DistTo(new Pt(cx, cy)) - r); sum += e * e; }
            residualMm = Math.Sqrt(sum / markMm.Count);
            RotCenterX = cx; RotCenterY = cy; return true;
        }
    }
}
