using System;
using VisionStudio.Core.Framework;
using System.Collections.Generic;
using System.Linq;
using HalconDotNet;

namespace VisionStudio.Core.Camera
{
    public class CameraConfig
    {
        [Param("Camera", "Name")] public string Name { get; set; } = "Cam1";
        /// <summary>Tên interface Halcon: GigEVision2, USB3Vision, DirectShow, File ...</summary>
        [Param("Camera", "Halcon interface", Choices = "GigEVision2|USB3Vision|DirectShow|File|HIKVision|MVision")] public string Interface { get; set; } = "GigEVision2";
        [Param("Camera", "Device id (default = first)")] public string Device { get; set; } = "default";
        [Param("Settings", "Exposure (µs)", Min = 1)] public double ExposureUs { get; set; } = 5000;
        [Param("Settings", "Gain")] public double Gain { get; set; } = 0;
        [Param("Settings", "Trigger", Choices = "Free|Software|Hardware")] public string TriggerMode { get; set; } = "Software";
        [Param("Advanced", "Exposure param name")] public string ExposureParam { get; set; } = "ExposureTime";
        [Param("Advanced", "Gain param name")] public string GainParam { get; set; } = "Gain";
        [Param("Image", "Mirror horizontal")] public bool MirrorX { get; set; }
        [Param("Image", "Mirror vertical")] public bool MirrorY { get; set; }
        [Param("Image", "Rotate (deg)", Choices = "0|90|180|270")] public int Rotate90 { get; set; }
    }

    /// <summary>Quản lý camera qua Halcon frame grabber (cần halcon.dll + interface tương ứng). Bổ sung adapter SDK hãng bằng ICameraSource.</summary>
    public static class CameraService
    {
        static readonly Dictionary<string, HTuple> _handles = new Dictionary<string, HTuple>();
        static readonly object _lock = new object();

        public static List<string> EnumerateDevices(string iface)
        {
            var list = new List<string>();
            try
            {
                HOperatorSet.InfoFramegrabber(iface, "device", out HTuple info, out HTuple values);
                foreach (var v in values.SArr) list.Add(v);
            }
            catch (HalconException) { }
            return list;
        }

        public static void Open(CameraConfig cfg)
        {
            lock (_lock)
            {
                Close(cfg.Name);
                HOperatorSet.OpenFramegrabber(cfg.Interface, 0, 0, 0, 0, 0, 0, "progressive", -1, "default", -1.0, "false", "default", cfg.Device, 0, -1, out HTuple h);
                _handles[cfg.Name] = h;
                Apply(cfg);
            }
        }

        public static void Apply(CameraConfig cfg)
        {
            lock (_lock)
            {
                if (!_handles.TryGetValue(cfg.Name, out HTuple h)) return;
                TrySet(h, cfg.ExposureParam, cfg.ExposureUs);
                TrySet(h, cfg.GainParam, cfg.Gain);
                if (cfg.TriggerMode == "Software") { TrySet(h, "TriggerMode", "On"); TrySet(h, "TriggerSource", "Software"); }
                else if (cfg.TriggerMode == "Hardware") { TrySet(h, "TriggerMode", "On"); TrySet(h, "TriggerSource", "Line1"); }
                else TrySet(h, "TriggerMode", "Off");
            }
        }

        static void TrySet(HTuple h, string name, HTuple val)
        {
            try { HOperatorSet.SetFramegrabberParam(h, name, val); } catch (HalconException) { }
        }

        public static bool IsOpen(string name) { lock (_lock) return _handles.ContainsKey(name); }

        public static void Close(string name)
        {
            lock (_lock)
            {
                if (_handles.TryGetValue(name, out HTuple h)) { try { HOperatorSet.CloseFramegrabber(h); } catch { } _handles.Remove(name); }
            }
        }
        public static void CloseAll() { lock (_lock) { foreach (var k in _handles.Keys.ToList()) Close(k); } }

        /// <summary>Chụp 1 ảnh. Nếu TriggerMode=Software sẽ gọi TriggerSoftware.</summary>
        public static HObject Grab(CameraConfig cfg, int timeoutMs = 3000)
        {
            HTuple h;
            lock (_lock) { if (!_handles.TryGetValue(cfg.Name, out h)) throw new InvalidOperationException("Camera '" + cfg.Name + "' chưa mở"); }
            try { HOperatorSet.SetFramegrabberParam(h, "grab_timeout", timeoutMs); } catch (HalconException) { }
            if (cfg.TriggerMode == "Software") TrySet(h, "do_execute_command", "TriggerSoftware");
            HOperatorSet.GrabImageAsync(out HObject img, h, -1);
            return PostProcess(cfg, img);
        }

        public static HObject PostProcess(CameraConfig cfg, HObject img)
        {
            HObject cur = img;
            if (cfg.MirrorX) { HOperatorSet.MirrorImage(cur, out HObject o, "column"); cur.Dispose(); cur = o; }
            if (cfg.MirrorY) { HOperatorSet.MirrorImage(cur, out HObject o, "row"); cur.Dispose(); cur = o; }
            if (cfg.Rotate90 != 0) { HOperatorSet.RotateImage(cur, out HObject o, cfg.Rotate90, "constant"); cur.Dispose(); cur = o; }
            return cur;
        }
    }
}
