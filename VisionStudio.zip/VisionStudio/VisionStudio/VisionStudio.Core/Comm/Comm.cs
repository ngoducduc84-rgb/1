using System;
using VisionStudio.Core.Framework;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace VisionStudio.Core.Comm
{
    public class CommConfig
    {
        [Param("Channel", "Name")] public string Name { get; set; } = "Comm1";
        /// <summary>TcpClient | TcpServer | ModbusTcp</summary>
        [Param("Channel", "Type", Choices = "TcpServer|TcpClient|ModbusTcp")] public string Type { get; set; } = "TcpServer";
        [Param("Channel", "Host (client / modbus)")] public string Host { get; set; } = "127.0.0.1";
        [Param("Channel", "Port", Min = 1, Max = 65535)] public int Port { get; set; } = 8000;
        [Param("Channel", "Terminator", Hint = "\\r\\n hoặc rỗng")] public string Terminator { get; set; } = "\\r\\n";
        [Param("Channel", "Modbus unit id", Min = 0, Max = 255)] public byte UnitId { get; set; } = 1;
        [Param("Channel", "Auto start")] public bool AutoStart { get; set; } = true;
        public string TerminatorChars => (Terminator ?? "").Replace("\\r", "\r").Replace("\\n", "\n");
    }

    public interface ICommChannel : IDisposable
    {
        string Name { get; }
        bool Connected { get; }
        event Action<string, string> Received;      // (channel, text)
        event Action<string, string> StateChanged;  // (channel, text)
        void Start();
        void Stop();
        bool Send(string text);
    }

    /// <summary>TCP server (nhiều client) hoặc TCP client (tự kết nối lại). Gói tin tách theo Terminator.</summary>
    public class TcpChannel : ICommChannel
    {
        readonly CommConfig _cfg; readonly bool _server;
        CancellationTokenSource _cts;
        TcpListener _listener;
        readonly ConcurrentDictionary<TcpClient, bool> _clients = new ConcurrentDictionary<TcpClient, bool>();
        public string Name => _cfg.Name;
        public bool Connected => _clients.Keys.Any(c => c.Connected);
        public event Action<string, string> Received;
        public event Action<string, string> StateChanged;

        public TcpChannel(CommConfig cfg) { _cfg = cfg; _server = cfg.Type == "TcpServer"; }

        public void Start()
        {
            Stop(); _cts = new CancellationTokenSource(); var ct = _cts.Token;
            if (_server) Task.Run(() => ServerLoop(ct)); else Task.Run(() => ClientLoop(ct));
        }

        async Task ServerLoop(CancellationToken ct)
        {
            try
            {
                _listener = new TcpListener(IPAddress.Any, _cfg.Port); _listener.Start();
                StateChanged?.Invoke(Name, "Listening :" + _cfg.Port);
                while (!ct.IsCancellationRequested)
                {
                    var c = await _listener.AcceptTcpClientAsync();
                    _clients[c] = true; StateChanged?.Invoke(Name, "Client connected " + c.Client.RemoteEndPoint);
                    _ = Task.Run(() => ReadLoop(c, ct));
                }
            }
            catch (Exception ex) { if (!ct.IsCancellationRequested) StateChanged?.Invoke(Name, "Error: " + ex.Message); }
        }

        async Task ClientLoop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    var c = new TcpClient(); await c.ConnectAsync(_cfg.Host, _cfg.Port);
                    _clients[c] = true; StateChanged?.Invoke(Name, "Connected " + _cfg.Host + ":" + _cfg.Port);
                    await ReadLoop(c, ct);
                }
                catch (Exception ex) { StateChanged?.Invoke(Name, "Reconnect: " + ex.Message); }
                try { await Task.Delay(2000, ct); } catch { }
            }
        }

        async Task ReadLoop(TcpClient c, CancellationToken ct)
        {
            var sb = new StringBuilder(); var buf = new byte[4096]; string term = _cfg.TerminatorChars;
            try
            {
                var ns = c.GetStream();
                while (!ct.IsCancellationRequested && c.Connected)
                {
                    int n = await ns.ReadAsync(buf, 0, buf.Length, ct);
                    if (n <= 0) break;
                    sb.Append(Encoding.ASCII.GetString(buf, 0, n));
                    string s = sb.ToString();
                    if (string.IsNullOrEmpty(term)) { sb.Clear(); Received?.Invoke(Name, s); continue; }
                    int idx;
                    while ((idx = s.IndexOf(term, StringComparison.Ordinal)) >= 0)
                    {
                        string msg = s.Substring(0, idx); s = s.Substring(idx + term.Length);
                        if (msg.Length > 0) Received?.Invoke(Name, msg);
                    }
                    sb.Clear(); sb.Append(s);
                }
            }
            catch { }
            finally { _clients.TryRemove(c, out _); try { c.Close(); } catch { } StateChanged?.Invoke(Name, "Disconnected"); }
        }

        public bool Send(string text)
        {
            var data = Encoding.ASCII.GetBytes(text + _cfg.TerminatorChars); bool any = false;
            foreach (var c in _clients.Keys.ToList())
            {
                try { if (c.Connected) { c.GetStream().Write(data, 0, data.Length); any = true; } } catch { }
            }
            return any;
        }

        public void Stop()
        {
            try { _cts?.Cancel(); } catch { }
            try { _listener?.Stop(); } catch { }
            foreach (var c in _clients.Keys.ToList()) { try { c.Close(); } catch { } }
            _clients.Clear();
        }
        public void Dispose() => Stop();
    }

    /// <summary>Modbus TCP master tối giản (FC 01/03/05/06/16).</summary>
    public class ModbusTcpChannel : ICommChannel
    {
        readonly CommConfig _cfg; TcpClient _c; ushort _tid; readonly object _lk = new object();
        public string Name => _cfg.Name;
        public bool Connected => _c != null && _c.Connected;
        public event Action<string, string> Received;
        public event Action<string, string> StateChanged;
        public ModbusTcpChannel(CommConfig cfg) { _cfg = cfg; }

        public void Start()
        {
            lock (_lk)
            {
                Stop(); _c = new TcpClient { ReceiveTimeout = 2000, SendTimeout = 2000 };
                try { _c.Connect(_cfg.Host, _cfg.Port); StateChanged?.Invoke(Name, "Connected"); }
                catch (Exception ex) { StateChanged?.Invoke(Name, "Error: " + ex.Message); }
            }
        }

        byte[] Transact(byte fc, byte[] pdu)
        {
            lock (_lk)
            {
                if (!Connected) Start();
                if (!Connected) throw new IOException("Modbus chưa kết nối");
                _tid++;
                var req = new byte[7 + 1 + pdu.Length];
                req[0] = (byte)(_tid >> 8); req[1] = (byte)_tid; req[4] = (byte)((pdu.Length + 2) >> 8); req[5] = (byte)(pdu.Length + 2);
                req[6] = _cfg.UnitId; req[7] = fc; Array.Copy(pdu, 0, req, 8, pdu.Length);
                var ns = _c.GetStream(); ns.Write(req, 0, req.Length);
                var hdr = ReadN(ns, 7); int len = (hdr[4] << 8) | hdr[5];
                var body = ReadN(ns, len - 1);
                if ((body[0] & 0x80) != 0) throw new IOException("Modbus exception " + body[1]);
                return body;
            }
        }
        static byte[] ReadN(NetworkStream ns, int n)
        {
            var b = new byte[n]; int o = 0; while (o < n) { int r = ns.Read(b, o, n - o); if (r <= 0) throw new IOException("closed"); o += r; }
            return b;
        }

        public ushort[] ReadHolding(ushort start, ushort count)
        {
            var r = Transact(3, new[] { (byte)(start >> 8), (byte)start, (byte)(count >> 8), (byte)count });
            var vals = new ushort[count];
            for (int i = 0; i < count; i++) vals[i] = (ushort)((r[2 + i * 2] << 8) | r[3 + i * 2]);
            return vals;
        }
        public void WriteRegisters(ushort start, ushort[] values)
        {
            var pdu = new byte[5 + values.Length * 2];
            pdu[0] = (byte)(start >> 8); pdu[1] = (byte)start; pdu[2] = (byte)(values.Length >> 8); pdu[3] = (byte)values.Length; pdu[4] = (byte)(values.Length * 2);
            for (int i = 0; i < values.Length; i++) { pdu[5 + i * 2] = (byte)(values[i] >> 8); pdu[6 + i * 2] = (byte)values[i]; }
            Transact(16, pdu);
        }
        public void WriteCoil(ushort addr, bool on) => Transact(5, new[] { (byte)(addr >> 8), (byte)addr, (byte)(on ? 0xFF : 0x00), (byte)0 });

        /// <summary>Send("addr=v1,v2,...") ghi thanh ghi giữ (holding) từ addr.</summary>
        public bool Send(string text)
        {
            try
            {
                var parts = text.Split('=');
                ushort a = ushort.Parse(parts[0].Trim());
                var vals = parts[1].Split(',').Select(s => (ushort)(short)Math.Round(double.Parse(s.Trim(), System.Globalization.CultureInfo.InvariantCulture))).ToArray();
                WriteRegisters(a, vals); return true;
            }
            catch (Exception ex) { StateChanged?.Invoke(Name, "Write error: " + ex.Message); return false; }
        }
        public void Stop() { try { _c?.Close(); } catch { } _c = null; }
        public void Dispose() => Stop();
    }

    public static class CommHub
    {
        static readonly Dictionary<string, ICommChannel> _ch = new Dictionary<string, ICommChannel>(StringComparer.OrdinalIgnoreCase);
        public static event Action<string, string> Received;
        public static event Action<string, string> StateChanged;
        /// <summary>Tin nhắn cuối cùng nhận được theo kênh.</summary>
        public static readonly ConcurrentDictionary<string, string> Last = new ConcurrentDictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public static ICommChannel Get(string name) { lock (_ch) { _ch.TryGetValue(name ?? "", out var c); return c; } }

        public static void Configure(IEnumerable<CommConfig> cfgs)
        {
            lock (_ch)
            {
                foreach (var c in _ch.Values) c.Dispose(); _ch.Clear();
                foreach (var cfg in cfgs)
                {
                    ICommChannel ch = cfg.Type == "ModbusTcp" ? (ICommChannel)new ModbusTcpChannel(cfg) : new TcpChannel(cfg);
                    ch.Received += (n, t) => { Last[n] = t; Received?.Invoke(n, t); };
                    ch.StateChanged += (n, t) => StateChanged?.Invoke(n, t);
                    _ch[cfg.Name] = ch;
                    if (cfg.AutoStart) { try { ch.Start(); } catch { } }
                }
            }
        }
        public static bool Send(string channel, string text) { var c = Get(channel); return c != null && c.Send(text); }
        public static void StopAll() { lock (_ch) { foreach (var c in _ch.Values) c.Dispose(); _ch.Clear(); } }
    }
}
