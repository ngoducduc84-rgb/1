using System;

namespace VisionStudio.Core.Framework
{
    /// <summary>Các loại dữ liệu chạy giữa các tool (kiểu cổng).</summary>
    public static class Kind
    {
        public const string Image = "image";
        public const string Region = "region";
        public const string Point = "point";     // Pt
        public const string Points = "points";   // List<Pt>
        public const string Line = "line";       // LineD
        public const string Circle = "circle";   // CircleD
        public const string Number = "number";   // double
        public const string Bool = "bool";
        public const string Text = "text";
        public const string Fixture = "fixture"; // FixtureData
        public const string Pose = "pose";       // Xyt
        public const string Any = "any";
    }

    public enum Editor { Auto, File, Folder, MultilineText }

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public sealed class ToolAttribute : Attribute
    {
        public string Name { get; }
        public string Category { get; }
        public string Description { get; set; } = "";
        public string Glyph { get; set; } = "▣";
        public ToolAttribute(string name, string category) { Name = name; Category = category; }
    }

    /// <summary>Đánh dấu thuộc tính hiển thị trong PropertyGrid. Source != null nghĩa là thuộc tính là LIÊN KẾT tới cổng ra của tool khác ("Tool.Port").</summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public sealed class ParamAttribute : Attribute
    {
        public string Category { get; }
        public string Display { get; }
        public string Source { get; set; }          // Kind.* → đây là link input
        public double Min { get; set; } = double.NaN;
        public double Max { get; set; } = double.NaN;
        public string Choices { get; set; }         // "a|b|c" cho string
        public string Hint { get; set; }
        public Editor Editor { get; set; } = Editor.Auto;
        /// <summary>Tên danh sách động: "calib", "camera", "comm".</summary>
        public string List { get; set; }
        public ParamAttribute(string category, string display) { Category = category; Display = display; }
    }

    public class Port
    {
        public string Name { get; }
        public string Kind { get; }
        public Port(string name, string kind) { Name = name; Kind = kind; }
    }
}
