using System;
namespace VisionStudio.Core.Framework
{
    /// <summary>Tool có hành động teach/train (nút bấm trên panel thuộc tính). ctx = kết quả lần chạy gần nhất (có ảnh vào).</summary>
    public interface IToolAction
    {
        string ActionName { get; }
        string DoAction(RunContext ctx);
    }
}
