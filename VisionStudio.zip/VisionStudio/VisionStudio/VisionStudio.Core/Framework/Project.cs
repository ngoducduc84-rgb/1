using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Newtonsoft.Json;
using VisionStudio.Core.Calibration;
using VisionStudio.Core.Camera;
using VisionStudio.Core.Comm;

namespace VisionStudio.Core.Framework
{
    public class Procedure
    {
        public string Name { get; set; } = "Procedure1";
        public List<ToolBase> Tools { get; set; } = new List<ToolBase>();
        public bool LastOk { get; set; }

        public ToolBase Find(string name) => Tools.FirstOrDefault(t => string.Equals(t.Name, name, StringComparison.OrdinalIgnoreCase));

        public void Add(ToolBase tool)
        {
            string baseName = tool.GetType().Name; if (baseName.EndsWith("Tool") && baseName.Length > 4) baseName = baseName.Substring(0, baseName.Length - 4);
            int n = 1; while (Find(baseName + n) != null) n++;
            tool.Name = baseName + n;
            Tools.Add(tool);
        }

        public void Remove(ToolBase tool)
        {
            Tools.Remove(tool);
            // xoá các link trỏ tới tool đã xoá
            foreach (var t in Tools)
                foreach (var pi in ToolMeta.GetParams(t.GetType()))
                    if (pi.Attr.Source != null && pi.Prop.PropertyType == typeof(string) && pi.Prop.CanWrite)
                    {
                        var v = pi.Prop.GetValue(t) as string;
                        if (v != null && v.StartsWith(tool.Name + ".", StringComparison.OrdinalIgnoreCase)) pi.Prop.SetValue(t, null);
                    }
        }

        public void Rename(ToolBase tool, string newName)
        {
            if (string.IsNullOrWhiteSpace(newName) || Find(newName) != null) return;
            string old = tool.Name; tool.Name = newName;
            foreach (var t in Tools)
                foreach (var pi in ToolMeta.GetParams(t.GetType()))
                    if (pi.Attr.Source != null && pi.Prop.PropertyType == typeof(string) && pi.Prop.CanWrite)
                    {
                        var v = pi.Prop.GetValue(t) as string;
                        if (v != null && v.StartsWith(old + ".", StringComparison.OrdinalIgnoreCase))
                            pi.Prop.SetValue(t, newName + v.Substring(old.Length));
                    }
        }

        /// <summary>Sắp xếp topo theo link; tool không phụ thuộc giữ nguyên thứ tự danh sách.</summary>
        public List<ToolBase> Order()
        {
            var result = new List<ToolBase>(); var state = new Dictionary<ToolBase, int>();
            void Visit(ToolBase t)
            {
                if (state.TryGetValue(t, out int s)) return; // 1 = đang duyệt (vòng) / 2 = xong
                state[t] = 1;
                foreach (var d in ToolMeta.Dependencies(t)) { var dt = Find(d); if (dt != null && dt != t) Visit(dt); }
                state[t] = 2; result.Add(t);
            }
            foreach (var t in Tools) Visit(t);
            return result;
        }

        public RunContext Run(Project project, Action<string, string> log = null, CancellationToken? ct = null)
        {
            var ctx = new RunContext { Project = project };
            if (log != null) ctx.Log = log;
            bool allOk = true;
            var failed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var t in Order())
            {
                if (ct.HasValue && ct.Value.IsCancellationRequested) break;
                t.Result = new ToolResult();
                if (!t.Enabled) { t.Result.Skipped = true; continue; }
                if (!string.IsNullOrWhiteSpace(t.Condition))
                {
                    if (!(ctx.TryGet(t.Condition, out bool cond) && cond)) { t.Result.Skipped = true; t.Result.Message = "Condition false"; continue; }
                }
                if (!t.RunOnUpstreamFail && ToolMeta.Dependencies(t).Any(d => failed.Contains(d)))
                {
                    t.Result.Skipped = true; t.Result.Ok = false; t.Result.Message = "Upstream NG"; failed.Add(t.Name); allOk = false; continue;
                }
                t.Run(ctx);
                if (!t.Result.Ok) { failed.Add(t.Name); allOk = false; }
            }
            LastOk = allOk;
            return ctx;
        }
    }

    /// <summary>Quy tắc kích hoạt: nguồn (Manual / Camera / Comm) → chạy procedure.</summary>
    public class TriggerRule
    {
        [Param("Trigger", "Name")] public string Name { get; set; } = "Trigger1";
        [Param("Trigger", "Source", Choices = "Comm|Timer|Manual")] public string Source { get; set; } = "Comm";
        [Param("Trigger", "Comm channel (blank = any)", List = "comm")] public string CommChannel { get; set; }
        [Param("Trigger", "Command text")] public string Command { get; set; } = "T1";
        [Param("Trigger", "Timer (ms)", Min = 50)] public int TimerMs { get; set; } = 1000;
        [Param("Trigger", "Procedure to run", List = "procedure")] public string Procedure { get; set; }
        [Param("Reply", "Reply template", Hint = "VD: {OK},{Align2P1.X},{Align2P1.Y},{Align2P1.T}")] public string ReplyFormat { get; set; } = "{OK},{Result}";
        [Param("Trigger", "Enabled")] public bool Enabled { get; set; } = true;
    }

    public class Project
    {
        public string Name { get; set; } = "NewProject";
        public List<Procedure> Procedures { get; set; } = new List<Procedure>();
        public List<CalibrationData> Calibrations { get; set; } = new List<CalibrationData>();
        public List<CameraConfig> Cameras { get; set; } = new List<CameraConfig>();
        public List<CommConfig> Comms { get; set; } = new List<CommConfig>();
        public List<TriggerRule> Triggers { get; set; } = new List<TriggerRule>();

        [JsonIgnore] public string FilePath { get; set; }
        [JsonIgnore] public string Dir => string.IsNullOrEmpty(FilePath) ? AppDomain.CurrentDomain.BaseDirectory : Path.GetDirectoryName(FilePath);
        [JsonIgnore] public string ModelDir { get { var d = Path.Combine(Dir, "Models"); Directory.CreateDirectory(d); return d; } }

        public static Project CreateDefault()
        {
            var p = new Project(); p.Procedures.Add(new Procedure { Name = "Procedure1" }); return p;
        }

        static JsonSerializerSettings Settings() => new JsonSerializerSettings
        {
            TypeNameHandling = TypeNameHandling.Auto,
            Formatting = Formatting.Indented,
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };

        public void Save(string path)
        {
            FilePath = path;
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, JsonConvert.SerializeObject(this, Settings()));
        }

        public static Project Load(string path)
        {
            var p = JsonConvert.DeserializeObject<Project>(File.ReadAllText(path), Settings()) ?? CreateDefault();
            p.FilePath = path;
            if (p.Procedures.Count == 0) p.Procedures.Add(new Procedure());
            return p;
        }

        public CalibrationData FindCalib(string name) => Calibrations.FirstOrDefault(c => c.Name == name);
    }
}
