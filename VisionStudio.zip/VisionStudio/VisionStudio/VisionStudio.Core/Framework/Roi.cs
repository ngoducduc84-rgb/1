using System;
using HalconDotNet;
using Newtonsoft.Json;
using VisionStudio.Core.Geometry;

namespace VisionStudio.Core.Framework
{
    /// <summary>ROI định nghĩa trong hệ toạ độ ảnh lúc teach. Khi có Fixture, dùng Transformed() để dịch/xoay theo vật.</summary>
    public abstract class RoiBase
    {
        [JsonIgnore] public abstract string Kind { get; }
        /// <summary>Vẽ tương tác trên cửa sổ Halcon (chuột trái vẽ, chuột phải kết thúc). Trả về true nếu thành công.</summary>
        public abstract bool Draw(HWindow win);
        public abstract HObject ToRegion();
        public abstract RoiBase Clone();
    }

    public class Rect2Roi : RoiBase
    {
        [Param("ROI", "Row")] public double Row { get; set; } = 200;
        [Param("ROI", "Column")] public double Col { get; set; } = 200;
        [Param("ROI", "Phi (deg)")] public double PhiDeg { get; set; }
        [Param("ROI", "Half length 1")] public double Len1 { get; set; } = 100;
        [Param("ROI", "Half length 2")] public double Len2 { get; set; } = 100;
        public override string Kind => "rect2";

        public override bool Draw(HWindow win)
        {
            try
            {
                win.DrawRectangle2(out double r, out double c, out double phi, out double l1, out double l2);
                Row = r; Col = c; PhiDeg = phi * GeoMath.R2D; Len1 = l1; Len2 = l2; return true;
            }
            catch (HalconException) { return false; }
        }
        public override HObject ToRegion()
        {
            HOperatorSet.GenRectangle2(out HObject rg, Row, Col, PhiDeg * GeoMath.D2R, Len1, Len2);
            return rg;
        }
        public Rect2Roi Transformed(FixtureData fx)
        {
            if (fx == null) return (Rect2Roi)Clone();
            fx.Transform(Row, Col, out double r, out double c);
            return new Rect2Roi { Row = r, Col = c, PhiDeg = fx.TransformAngleDeg(PhiDeg), Len1 = Len1, Len2 = Len2 };
        }
        public override RoiBase Clone() => (RoiBase)MemberwiseClone();
    }

    /// <summary>ROI đoạn thẳng + bề rộng nửa vùng đo (dùng cho Find Line / Caliper).</summary>
    public class LineRoi : RoiBase
    {
        [Param("ROI", "Row 1")] public double R1 { get; set; } = 200;
        [Param("ROI", "Col 1")] public double C1 { get; set; } = 150;
        [Param("ROI", "Row 2")] public double R2 { get; set; } = 200;
        [Param("ROI", "Col 2")] public double C2 { get; set; } = 350;
        [Param("ROI", "Half width", Min = 2)] public double HalfWidth { get; set; } = 20;
        public override string Kind => "line";

        public override bool Draw(HWindow win)
        {
            try
            {
                win.DrawLine(out double r1, out double c1, out double r2, out double c2);
                R1 = r1; C1 = c1; R2 = r2; C2 = c2; return true;
            }
            catch (HalconException) { return false; }
        }
        public override HObject ToRegion()
        {
            double dr = R2 - R1, dc = C2 - C1; double len = Math.Sqrt(dr * dr + dc * dc) / 2;
            double phi = Math.Atan2(-dr, dc);
            HOperatorSet.GenRectangle2(out HObject rg, (R1 + R2) / 2, (C1 + C2) / 2, phi, Math.Max(1, len), Math.Max(1, HalfWidth));
            return rg;
        }
        public LineRoi Transformed(FixtureData fx)
        {
            if (fx == null) return (LineRoi)Clone();
            fx.Transform(R1, C1, out double a1, out double b1);
            fx.Transform(R2, C2, out double a2, out double b2);
            return new LineRoi { R1 = a1, C1 = b1, R2 = a2, C2 = b2, HalfWidth = HalfWidth };
        }
        public override RoiBase Clone() => (RoiBase)MemberwiseClone();
    }

    /// <summary>ROI vành tròn (Find Circle): tâm, bán kính, nửa bề rộng vành.</summary>
    public class CircleRoi : RoiBase
    {
        [Param("ROI", "Row")] public double R { get; set; } = 250;
        [Param("ROI", "Column")] public double C { get; set; } = 250;
        [Param("ROI", "Radius", Min = 3)] public double Radius { get; set; } = 100;
        [Param("ROI", "Half width", Min = 2)] public double HalfWidth { get; set; } = 20;
        public override string Kind => "circle";

        public override bool Draw(HWindow win)
        {
            try
            {
                win.DrawCircle(out double r, out double c, out double rad);
                R = r; C = c; Radius = rad; return true;
            }
            catch (HalconException) { return false; }
        }
        public override HObject ToRegion()
        {
            HOperatorSet.GenCircle(out HObject outer, R, C, Radius + HalfWidth);
            HOperatorSet.GenCircle(out HObject inner, R, C, Math.Max(1, Radius - HalfWidth));
            HOperatorSet.Difference(outer, inner, out HObject ring);
            outer.Dispose(); inner.Dispose();
            return ring;
        }
        public CircleRoi Transformed(FixtureData fx)
        {
            if (fx == null) return (CircleRoi)Clone();
            fx.Transform(R, C, out double r, out double c);
            return new CircleRoi { R = r, C = c, Radius = Radius, HalfWidth = HalfWidth };
        }
        public override RoiBase Clone() => (RoiBase)MemberwiseClone();
    }
}
