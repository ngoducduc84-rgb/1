using System;
using System.Collections.Generic;
using System.Linq;
using HalconDotNet;
using VisionStudio.Core.Geometry;

namespace VisionStudio.Core.Framework
{
    public enum OverlayKind { Object, Cross, Line, Circle, Text, Arrow }

    public class OverlayItem
    {
        public OverlayKind Kind;
        public HObject Obj;                 // Object: region/xld (đã copy)
        public double R, C, R2, C2, Size, Angle;
        public string Text, Color = "green";
        public bool Fill;                   // Object: tô đặc region
    }

    public class ToolResult
    {
        public bool Executed;
        public bool Skipped;
        public bool Ok;
        public string Message = "";
        public double Ms;
    }

    /// <summary>Bộ nhớ chạy 1 lần của procedure: giá trị cổng ra, overlay vẽ, báo cáo kết quả.</summary>
    public class RunContext : IDisposable
    {
        public readonly Dictionary<string, object> Values = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        public readonly List<OverlayItem> Overlays = new List<OverlayItem>();
        public readonly List<KeyValuePair<string, string>> Report = new List<KeyValuePair<string, string>>();
        public readonly List<IDisposable> Owned = new List<IDisposable>();
        public Project Project;
        public Action<string, string> Log = (lvl, msg) => { };   // (level, message)
        public string CurrentTool = "";
        public DateTime StartTime = DateTime.Now;

        public static string Key(string tool, string port) => tool + "." + port;

        public void Set(ToolBase t, string port, object value)
        {
            Values[Key(t.Name, port)] = value;
            if (value is IDisposable d && !(value is string)) Owned.Add(d);
        }

        public bool TryGet<T>(string link, out T value)
        {
            value = default(T);
            if (string.IsNullOrWhiteSpace(link)) return false;
            if (Values.TryGetValue(link.Trim(), out object o) && o is T t) { value = t; return true; }
            return false;
        }
        public T Get<T>(string link) where T : class { TryGet(link, out T v); return v; }
        public HObject Image(string link) => Get<HObject>(link);

        public T Own<T>(T obj) where T : IDisposable { if (obj != null) Owned.Add(obj); return obj; }

        // ---- Overlay helpers ----
        public void AddObj(HObject obj, string color = "green", bool fill = false)
        {
            if (obj == null || !obj.IsInitialized()) return;
            Overlays.Add(new OverlayItem { Kind = OverlayKind.Object, Obj = obj.CopyObj(1, -1), Color = color, Fill = fill });
        }
        public void AddCross(double r, double c, double size = 20, double angleDeg = 0, string color = "green")
            => Overlays.Add(new OverlayItem { Kind = OverlayKind.Cross, R = r, C = c, Size = size, Angle = angleDeg * GeoMath.D2R, Color = color });
        public void AddLine(double r1, double c1, double r2, double c2, string color = "green")
            => Overlays.Add(new OverlayItem { Kind = OverlayKind.Line, R = r1, C = c1, R2 = r2, C2 = c2, Color = color });
        public void AddCircle(double r, double c, double rad, string color = "green")
            => Overlays.Add(new OverlayItem { Kind = OverlayKind.Circle, R = r, C = c, Size = rad, Color = color });
        public void AddText(double r, double c, string text, string color = "green")
            => Overlays.Add(new OverlayItem { Kind = OverlayKind.Text, R = r, C = c, Text = text, Color = color });

        public void Report_(string tool, string key, object val)
            => Report.Add(new KeyValuePair<string, string>(tool + "." + key, val is double d ? d.ToString("0.###") : Convert.ToString(val)));

        public void Dispose()
        {
            foreach (var o in Overlays) { try { o.Obj?.Dispose(); } catch { } }
            Overlays.Clear();
            foreach (var d in Owned) { try { d.Dispose(); } catch { } }
            Owned.Clear(); Values.Clear();
        }
    }
}
