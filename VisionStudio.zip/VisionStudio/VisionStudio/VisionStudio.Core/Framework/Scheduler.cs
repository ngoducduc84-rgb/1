using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using VisionStudio.Core.Comm;
using VisionStudio.Core.Tools;

namespace VisionStudio.Core.Framework
{
    /// <summary>Lập lịch kiểu IVA B+: trigger (Comm command / Timer) → chạy Procedure → trả lời qua Comm.
    /// Mọi lần chạy được tuần tự hoá (1 procedure tại 1 thời điểm) để an toàn với Halcon/camera.</summary>
    public class Scheduler : IDisposable
    {
        readonly object _runLock = new object();
        Project _project; Action<string, string> _log = (l, m) => { };
        readonly List<Timer> _timers = new List<Timer>();
        public bool Running { get; private set; }
        /// <summary>Project dùng cho RunOnce/Execute (đặt khi mở dự án; Start() cũng đặt).</summary>
        public Project Project { get => _project; set => _project = value; }
        public Action<string, string> LogSink { set { _log = value ?? ((l, m) => { }); } }

        /// <summary>Phát sinh sau mỗi lần chạy. Người nhận chịu trách nhiệm Dispose RunContext (nếu không có người nhận, Scheduler tự Dispose).</summary>
        public event Action<Procedure, RunContext, TriggerRule> Completed;

        public void Start(Project p, Action<string, string> log)
        {
            Stop(); _project = p; if (log != null) _log = log; Running = true;
            CommHub.Received += OnReceived;
            foreach (var t in p.Triggers.Where(t => t.Enabled && t.Source == "Timer"))
            {
                var rule = t;
                _timers.Add(new Timer(_ => { if (Running) Execute(rule, null); }, null, Math.Max(50, rule.TimerMs), Math.Max(50, rule.TimerMs)));
            }
            _log("INFO", $"Scheduler started ({p.Triggers.Count(t => t.Enabled)} trigger)");
        }

        public void Stop()
        {
            if (!Running) return; Running = false;
            CommHub.Received -= OnReceived;
            foreach (var t in _timers) t.Dispose(); _timers.Clear();
            _log("INFO", "Scheduler stopped");
        }

        void OnReceived(string channel, string text)
        {
            if (!Running || _project == null) return;
            string cmd = (text ?? "").Trim();
            foreach (var rule in _project.Triggers.Where(t => t.Enabled && t.Source == "Comm"
                         && (string.IsNullOrEmpty(t.CommChannel) || string.Equals(t.CommChannel, channel, StringComparison.OrdinalIgnoreCase))
                         && string.Equals(t.Command, cmd, StringComparison.OrdinalIgnoreCase)).ToList())
            {
                var r = rule; var ch = channel;
                ThreadPool.QueueUserWorkItem(_ => Execute(r, ch));
            }
        }

        /// <summary>Chạy procedure theo quy tắc, trả lời qua kênh.</summary>
        public RunContext Execute(TriggerRule rule, string replyChannel)
        {
            var proc = _project?.Procedures.FirstOrDefault(p => p.Name == rule.Procedure);
            if (proc == null) { _log("ERROR", "Trigger '" + rule.Name + "': không có procedure '" + rule.Procedure + "'"); return null; }
            RunContext ctx;
            lock (_runLock) ctx = proc.Run(_project, _log);
            string ch = replyChannel ?? rule.CommChannel;
            if (!string.IsNullOrEmpty(ch) && !string.IsNullOrWhiteSpace(rule.ReplyFormat))
            {
                string msg = SendCommTool.Expand(ctx, rule.ReplyFormat, proc.LastOk, 3);
                CommHub.Send(ch, msg); _log("INFO", "Reply → " + ch + ": " + msg);
            }
            var h = Completed;
            if (h != null) h(proc, ctx, rule); else ctx.Dispose();
            return ctx;
        }

        public RunContext RunOnce(Procedure proc)
        {
            lock (_runLock) return proc.Run(_project, _log);
        }

        public void Dispose() { Stop(); }
    }
}
