using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using HalconDotNet;
using Newtonsoft.Json;
using VisionStudio.Core.Geometry;

namespace VisionStudio.Core.Framework
{
    public abstract class ToolBase
    {
        public string Name { get; set; }
        public double X { get; set; }      // vị trí trên flowchart
        public double Y { get; set; }

        [Param("General", "Enabled")] public bool Enabled { get; set; } = true;
        [Param("General", "Run if (bool link)", Source = Kind.Bool, Hint = "Điều kiện chạy (thay cho tool If). Trống = luôn chạy.")]
        public string Condition { get; set; }
        [Param("General", "Run even if upstream NG")] public bool RunOnUpstreamFail { get; set; }
        [Param("General", "Comment", Editor = Editor.MultilineText)] public string Comment { get; set; }

        [JsonIgnore] public ToolResult Result { get; set; } = new ToolResult();

        /// <summary>Các cổng ra (ngoài "OK").</summary>
        [JsonIgnore] public virtual IEnumerable<Port> Ports { get { yield break; } }
        [JsonIgnore] public IEnumerable<Port> AllPorts => new[] { new Port("OK", Kind.Bool) }.Concat(Ports);

        protected abstract void Execute(RunContext ctx, ToolResult res);

        public void Run(RunContext ctx)
        {
            var sw = Stopwatch.StartNew();
            Result = new ToolResult { Executed = true };
            ctx.CurrentTool = Name;
            try
            {
                Execute(ctx, Result);
            }
            catch (HalconException hx)
            {
                Result.Ok = false; Result.Message = "Halcon: " + hx.GetErrorMessage();
            }
            catch (Exception ex)
            {
                Result.Ok = false; Result.Message = ex.Message;
            }
            sw.Stop(); Result.Ms = sw.Elapsed.TotalMilliseconds;
            ctx.Values[RunContext.Key(Name, "OK")] = Result.Ok;
            ctx.Log(Result.Ok ? "INFO" : "ERROR", $"[{Name}] {(Result.Ok ? "OK" : "NG")} {Result.Ms:0.#} ms {Result.Message}");
        }

        // ---- tiện ích cho tool con ----
        protected void Out(RunContext ctx, string port, object value) => ctx.Set(this, port, value);

        protected static HTuple T(double v) => new HTuple(v);

        /// <summary>Lấy ảnh đầu vào hoặc ném lỗi dễ hiểu.</summary>
        protected HObject RequireImage(RunContext ctx, string link)
        {
            var img = ctx.Image(link);
            if (img == null || !img.IsInitialized()) throw new InvalidOperationException("Chưa có ảnh đầu vào (link: '" + link + "')");
            return img;
        }
        protected FixtureData GetFixture(RunContext ctx, string link) => ctx.Get<FixtureData>(link);

        protected static void ImageSize(HObject img, out int w, out int h)
        {
            HOperatorSet.GetImageSize(img, out HTuple ww, out HTuple hh); w = ww.I; h = hh.I;
        }
    }

    /// <summary>Phản chiếu metadata tool.</summary>
    public static class ToolMeta
    {
        public class ParamInfo { public PropertyInfo Prop; public ParamAttribute Attr; }

        public static List<ParamInfo> GetParams(Type t)
            => t.GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .Select(p => new ParamInfo { Prop = p, Attr = p.GetCustomAttribute<ParamAttribute>() })
                .Where(x => x.Attr != null && x.Prop.CanRead).ToList();

        /// <summary>Danh sách tên tool mà tool này phụ thuộc (từ các thuộc tính link).</summary>
        public static IEnumerable<string> Dependencies(ToolBase tool)
        {
            foreach (var pi in GetParams(tool.GetType()))
            {
                if (pi.Attr.Source == null || pi.Prop.PropertyType != typeof(string)) continue;
                string v = pi.Prop.GetValue(tool) as string;
                if (string.IsNullOrWhiteSpace(v)) continue;
                int i = v.IndexOf('.');
                if (i > 0) yield return v.Substring(0, i);
            }
        }

        public static ToolAttribute GetToolAttr(Type t) => t.GetCustomAttribute<ToolAttribute>();
    }

    public static class ToolRegistry
    {
        private static List<Type> _types;
        public static IReadOnlyList<Type> Types
        {
            get
            {
                if (_types == null)
                    _types = typeof(ToolBase).Assembly.GetTypes()
                        .Where(t => !t.IsAbstract && typeof(ToolBase).IsAssignableFrom(t) && t.GetCustomAttribute<ToolAttribute>() != null)
                        .OrderBy(t => ToolMeta.GetToolAttr(t).Category).ThenBy(t => ToolMeta.GetToolAttr(t).Name).ToList();
                return _types;
            }
        }
        public static ToolBase Create(Type t) => (ToolBase)Activator.CreateInstance(t);
    }
}
