using System;
using System.Collections.Generic;

namespace VisionStudio.Core.Geometry
{
    /// <summary>Điểm 2D. Với pixel: X = cột (column), Y = hàng (row). Với mm: X,Y theo hệ robot.</summary>
    public struct Pt
    {
        public double X, Y;
        public Pt(double x, double y) { X = x; Y = y; }
        public static Pt operator +(Pt a, Pt b) => new Pt(a.X + b.X, a.Y + b.Y);
        public static Pt operator -(Pt a, Pt b) => new Pt(a.X - b.X, a.Y - b.Y);
        public static Pt operator *(Pt a, double k) => new Pt(a.X * k, a.Y * k);
        public static Pt operator /(Pt a, double k) => new Pt(a.X / k, a.Y / k);
        public double DistTo(Pt o) { double dx = X - o.X, dy = Y - o.Y; return Math.Sqrt(dx * dx + dy * dy); }
        public override string ToString() => $"({X:0.###}, {Y:0.###})";
    }

    /// <summary>Pose X, Y, Theta. T tính bằng ĐỘ.</summary>
    public struct Xyt
    {
        public double X, Y, T;
        public Xyt(double x, double y, double t) { X = x; Y = y; T = t; }
        public override string ToString() => $"X={X:0.###} Y={Y:0.###} T={T:0.###}";
    }

    /// <summary>Đường thẳng theo toạ độ ảnh (row/col).</summary>
    public class LineD
    {
        public double R1, C1, R2, C2;
        public LineD() { }
        public LineD(double r1, double c1, double r2, double c2) { R1 = r1; C1 = c1; R2 = r2; C2 = c2; }
        public Pt P1 => new Pt(C1, R1);
        public Pt P2 => new Pt(C2, R2);
        public double Length => Math.Sqrt((R2 - R1) * (R2 - R1) + (C2 - C1) * (C2 - C1));
        /// <summary>Góc (độ) so với trục cột, ngược chiều kim đồng hồ trên màn hình.</summary>
        public double AngleDeg => Math.Atan2(-(R2 - R1), C2 - C1) * 180.0 / Math.PI;
    }

    public class CircleD
    {
        public double R, C, Rad;
        public CircleD() { }
        public CircleD(double r, double c, double rad) { R = r; C = c; Rad = rad; }
        public Pt Center => new Pt(C, R);
    }

    public static class GeoMath
    {
        public const double D2R = Math.PI / 180.0;
        public const double R2D = 180.0 / Math.PI;

        public static double NormRad(double a) { while (a > Math.PI) a -= 2 * Math.PI; while (a <= -Math.PI) a += 2 * Math.PI; return a; }
        public static double NormDeg(double a) { while (a > 180) a -= 360; while (a <= -180) a += 360; return a; }

        /// <summary>Khoảng cách có dấu từ điểm (X=col, Y=row) tới đường thẳng.</summary>
        public static double PointLineDistance(Pt p, LineD l)
        {
            double dx = l.C2 - l.C1, dy = l.R2 - l.R1;
            double len = Math.Sqrt(dx * dx + dy * dy);
            if (len < 1e-12) return p.DistTo(l.P1);
            return ((p.X - l.C1) * dy - (p.Y - l.R1) * dx) / len;
        }

        public static bool Intersect(LineD a, LineD b, out Pt p)
        {
            double x1 = a.C1, y1 = a.R1, x2 = a.C2, y2 = a.R2;
            double x3 = b.C1, y3 = b.R1, x4 = b.C2, y4 = b.R2;
            double d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
            if (Math.Abs(d) < 1e-12) { p = new Pt(); return false; }
            double t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / d;
            p = new Pt(x1 + t * (x2 - x1), y1 + t * (y2 - y1));
            return true;
        }

        /// <summary>Fit đường tròn đại số (Kåsa) cho >= 3 điểm.</summary>
        public static bool FitCircle(IList<Pt> pts, out double cx, out double cy, out double r)
        {
            cx = cy = r = 0;
            int n = pts.Count; if (n < 3) return false;
            double sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0, sxxx = 0, syyy = 0, sxyy = 0, sxxy = 0;
            foreach (var p in pts)
            {
                double x = p.X, y = p.Y;
                sx += x; sy += y; sxx += x * x; syy += y * y; sxy += x * y;
                sxxx += x * x * x; syyy += y * y * y; sxyy += x * y * y; sxxy += x * x * y;
            }
            double a1 = 2 * (sx * sx - n * sxx), b1 = 2 * (sx * sy - n * sxy);
            double a2 = b1, b2 = 2 * (sy * sy - n * syy);
            double c1 = sxx * sx - n * sxxx + sx * syy - n * sxyy;
            double c2 = sxx * sy - n * sxxy + sy * syy - n * syyy;
            double det = a1 * b2 - a2 * b1;
            if (Math.Abs(det) < 1e-12) return false;
            cx = (c1 * b2 - c2 * b1) / det;
            cy = (a1 * c2 - a2 * c1) / det;
            double sum = 0; foreach (var p in pts) sum += Math.Sqrt((p.X - cx) * (p.X - cx) + (p.Y - cy) * (p.Y - cy));
            r = sum / n;
            return true;
        }

        public static Pt Mid(Pt a, Pt b) => new Pt((a.X + b.X) / 2, (a.Y + b.Y) / 2);
    }

    /// <summary>Biến đổi cứng (fixture): từ pose tham chiếu (lúc teach) sang pose hiện tại. row/col, góc Halcon (độ).</summary>
    public class FixtureData
    {
        public double R0, C0, A0;
        public double R1, C1, A1;
        public double DeltaRad => (A1 - A0) * GeoMath.D2R;

        public void Transform(double r, double c, out double rr, out double cc)
        {
            double th = DeltaRad, cs = Math.Cos(th), sn = Math.Sin(th);
            double dr = r - R0, dc = c - C0;
            rr = R1 + dr * cs - dc * sn;
            cc = C1 + dr * sn + dc * cs;
        }
        public double TransformAngleDeg(double phiDeg) => phiDeg + (A1 - A0);
    }
}
