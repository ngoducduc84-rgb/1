using System;
using System.Collections.Generic;
using System.Globalization;
using HalconDotNet;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Geometry;

namespace VisionStudio.Core.Halcon
{
    public static class HalconUtil
    {
        /// <summary>Tạo HTuple hỗn hợp (string/int/double/bool) – tránh phụ thuộc constructor theo từng phiên bản.</summary>
        public static HTuple Tup(params object[] items)
        {
            var t = new HTuple();
            foreach (var o in items)
            {
                if (o is string s) t = t.TupleConcat(new HTuple(s));
                else if (o is int i) t = t.TupleConcat(new HTuple(i));
                else if (o is double d) t = t.TupleConcat(new HTuple(d));
                else if (o is bool b) t = t.TupleConcat(new HTuple(b ? 1 : 0));
                else if (o is HTuple ht) t = t.TupleConcat(ht);
                else throw new ArgumentException("Kiểu HTuple không hỗ trợ: " + o?.GetType());
            }
            return t;
        }

        /// <summary>Lấy handle cửa sổ dạng HTuple, tương thích mọi bản Halcon .NET
        /// (≤18.05: HWindow.HalconID kiểu IntPtr; 18.11+: handle là HHandle/HTool.Handle, HTuple có constructor tương ứng).</summary>
        public static HTuple WinHandle(HWindow w)
        {
            if (w == null) throw new ArgumentNullException(nameof(w));
            foreach (var name in new[] { "HalconID", "Handle" })
            {
                var p = w.GetType().GetProperty(name);
                if (p == null) continue;
                object v = p.GetValue(w, null);
                if (v == null) continue;
                if (v is HTuple t) return t;
                var c = FindCtor(v.GetType());
                if (c != null) return (HTuple)c.Invoke(new[] { v });
            }
            var c2 = FindCtor(w.GetType());
            if (c2 != null) return (HTuple)c2.Invoke(new object[] { w });
            throw new InvalidOperationException("Không lấy được handle cửa sổ Halcon từ HWindow (phiên bản halcondotnet không hỗ trợ).");
        }

        static System.Reflection.ConstructorInfo FindCtor(Type argType)
        {
            foreach (var c in typeof(HTuple).GetConstructors())
            {
                var ps = c.GetParameters();
                if (ps.Length == 1 && ps[0].ParameterType != typeof(object) && !ps[0].ParameterType.IsArray && ps[0].ParameterType.IsAssignableFrom(argType)) return c;
            }
            return null;
        }

        public static void Safe(ref HObject o) { if (o != null) { try { o.Dispose(); } catch { } o = null; } }

        public static bool Valid(HObject o) => o != null && o.IsInitialized();

        public static int Count(HObject o)
        {
            if (!Valid(o)) return 0;
            HOperatorSet.CountObj(o, out HTuple n); return n.I;
        }

        public static string[] Choices(string s) => (s ?? "").Split('|');

        public static double[] ToDoubles(HTuple t) { return t == null || t.Length == 0 ? new double[0] : t.ToDArr(); }

        /// <summary>Chuyển ảnh sang xám 1 kênh (rgb1_to_gray nếu 3 kênh).</summary>
        public static HObject ToGray(HObject img)
        {
            HOperatorSet.CountChannels(img, out HTuple ch);
            if (ch.I == 3) { HOperatorSet.Rgb1ToGray(img, out HObject g); return g; }
            if (ch.I > 1) { HOperatorSet.AccessChannel(img, out HObject g, 1); return g; }
            return img.CopyObj(1, -1);
        }

        public static HObject ReduceTo(HObject img, HObject region)
        {
            HOperatorSet.ReduceDomain(img, region, out HObject r); return r;
        }

        /// <summary>Áp dụng homMat2D (6 phần tử) lên (row,col) – kiểu Halcon (x=row, y=col).</summary>
        public static void ApplyHom(HTuple hom, double r, double c, out double rr, out double cc)
        {
            HOperatorSet.AffineTransPoint2d(hom, r, c, out HTuple qr, out HTuple qc); rr = qr.D; cc = qc.D;
        }
    }

    /// <summary>Quy đổi pixel → mm theo calibration đặt tên.</summary>
    public static class Cal
    {
        public static Pt ToMm(RunContext ctx, string calName, Pt px)
        {
            if (string.IsNullOrWhiteSpace(calName) || ctx.Project == null) return px;
            var c = ctx.Project.FindCalib(calName);
            return (c != null && c.Valid) ? c.V2R(px) : px;
        }
        public static double Scale(RunContext ctx, string calName)
        {
            if (string.IsNullOrWhiteSpace(calName) || ctx.Project == null) return 1;
            var c = ctx.Project.FindCalib(calName);
            return (c != null && c.Valid) ? (c.PixelSizeX + c.PixelSizeY) / 2 : 1;
        }
        public static string F(double v) => v.ToString("0.###", CultureInfo.InvariantCulture);
    }
}
