using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using HalconDotNet;

namespace VisionStudio.Core.Halcon
{
    /// <summary>Đọc ảnh: thử Halcon read_image trước; nếu Halcon không đọc được (đuôi file sai, biến thể BMP/TIFF lạ…)
    /// thì dự phòng bằng GDI+ rồi chuyển sang HImage (BGR 8-bit).</summary>
    public static class ImageIo
    {
        public static HObject Read(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) throw new FileNotFoundException("Không thấy file ảnh", path);
            try
            {
                HOperatorSet.ReadImage(out HObject img, path);
                return img;
            }
            catch (HalconException hx)
            {
                try { return ReadViaGdi(path); }
                catch (Exception gx)
                {
                    throw new InvalidOperationException(
                        $"Không đọc được ảnh '{path}'. Halcon: {hx.GetErrorMessage()} | GDI+: {gx.Message}. " +
                        "File có thể bị hỏng hoặc định dạng không hỗ trợ (WebP/HEIC/AVIF…): hãy xuất lại sang PNG/JPG/BMP chuẩn.", hx);
                }
            }
        }

        static HObject ReadViaGdi(string path)
        {
            byte[] bytes = File.ReadAllBytes(path);
            using (var ms = new MemoryStream(bytes))
            using (var bmp = new Bitmap(ms))
            {
                int w = bmp.Width, h = bmp.Height;
                var data = bmp.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
                var packed = new byte[w * h * 3];
                try
                {
                    for (int y = 0; y < h; y++)
                        Marshal.Copy(IntPtr.Add(data.Scan0, y * data.Stride), packed, y * w * 3, w * 3);   // bỏ padding cuối hàng
                }
                finally { bmp.UnlockBits(data); }

                var pin = GCHandle.Alloc(packed, GCHandleType.Pinned);
                try
                {
                    var img = new HImage();
                    img.GenImageInterleaved(pin.AddrOfPinnedObject(), "bgr", w, h, -1, "byte", w, h, 0, 0, 8, 0);
                    return img;
                }
                finally { pin.Free(); }
            }
        }
    }
}
