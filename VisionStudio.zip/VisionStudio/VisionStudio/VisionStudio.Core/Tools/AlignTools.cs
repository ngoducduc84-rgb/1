using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using VisionStudio.Core.Calibration;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Geometry;
using VisionStudio.Core.Halcon;

namespace VisionStudio.Core.Tools
{
    /// <summary>Lõi toán căn chỉnh XYθ (port từ Algo2PAlign/Algo4PAlign/Algo4PTarObj của IVA B+ sang C# thuần).
    /// Tìm phép dời (dx,dy,dθ) cho stage xoay quanh tâm RC sao cho các mark vật khớp với mark tham chiếu (bình phương tối thiểu, cứng).</summary>
    public static class AlignEngine
    {
        public static Xyt Solve(IList<Pt> obj, IList<Pt> rf, Pt rc, double thetaSign, out double maxResidual, out double dThetaRad)
        {
            int n = obj.Count;
            Pt co = new Pt(obj.Average(p => p.X), obj.Average(p => p.Y));
            Pt cr = new Pt(rf.Average(p => p.X), rf.Average(p => p.Y));
            double dot = 0, cross = 0;
            for (int i = 0; i < n; i++)
            {
                double ox = obj[i].X - co.X, oy = obj[i].Y - co.Y, rx = rf[i].X - cr.X, ry = rf[i].Y - cr.Y;
                dot += ox * rx + oy * ry; cross += ox * ry - oy * rx;
            }
            double th = n >= 2 ? Math.Atan2(cross, dot) : 0;
            double c = Math.Cos(th), s = Math.Sin(th);
            // stage: xoay th quanh rc rồi tịnh tiến d sao cho tâm vật trùng tâm ref
            double rx0 = co.X - rc.X, ry0 = co.Y - rc.Y;
            var d = new Pt(cr.X - rc.X - (c * rx0 - s * ry0), cr.Y - rc.Y - (s * rx0 + c * ry0));
            double mr = 0;
            for (int i = 0; i < n; i++)
            {
                double px = obj[i].X - rc.X, py = obj[i].Y - rc.Y;
                double qx = c * px - s * py + rc.X + d.X, qy = s * px + c * py + rc.Y + d.Y;
                mr = Math.Max(mr, Math.Sqrt((qx - rf[i].X) * (qx - rf[i].X) + (qy - rf[i].Y) * (qy - rf[i].Y)));
            }
            maxResidual = mr; dThetaRad = th;
            return new Xyt(d.X, d.Y, th * GeoMath.R2D * thetaSign);
        }
    }

    public abstract class AlignBase : ToolBase, IToolAction
    {
        [Param("Calibration", "Cal mark 1", List = "calib")] public string Cal1 { get; set; }
        [Param("Calibration", "Cal mark 2 (blank = Cal 1)", List = "calib")] public string Cal2 { get; set; }
        [Param("Calibration", "Cal mark 3 (blank = Cal 1)", List = "calib")] public string Cal3 { get; set; }
        [Param("Calibration", "Cal mark 4 (blank = Cal 1)", List = "calib")] public string Cal4 { get; set; }
        [Param("Align", "Rotation center", Choices = "From calibration|Manual")] public string RcMode { get; set; } = "From calibration";
        [Param("Align", "Manual RC X (mm)")] public double RcX { get; set; }
        [Param("Align", "Manual RC Y (mm)")] public double RcY { get; set; }
        [Param("Align", "Theta direction", Choices = "+1 (CCW)|-1 (CW)")] public string ThetaDir { get; set; } = "+1 (CCW)";
        [Param("Offset", "Offset X (mm)")] public double OffX { get; set; }
        [Param("Offset", "Offset Y (mm)")] public double OffY { get; set; }
        [Param("Offset", "Offset T (deg)")] public double OffT { get; set; }
        [Param("Limit", "Limit X (0 = off)", Min = 0)] public double LimX { get; set; }
        [Param("Limit", "Limit Y (0 = off)", Min = 0)] public double LimY { get; set; }
        [Param("Limit", "Limit T (0 = off)", Min = 0)] public double LimT { get; set; }
        [Param("Precision", "Done if |X| ≤", Min = 0)] public double PrecX { get; set; } = 0.01;
        [Param("Precision", "Done if |Y| ≤", Min = 0)] public double PrecY { get; set; } = 0.01;
        [Param("Precision", "Done if |T| ≤", Min = 0)] public double PrecT { get; set; } = 0.01;
        [Param("Check", "Max residual mm (0 = off)", Min = 0)] public double MaxResidual { get; set; }
        [Param("Check", "Expected L01 (0 = off)", Min = 0)] public double L01 { get; set; }
        [Param("Check", "Expected L23 (0 = off)", Min = 0)] public double L23 { get; set; }
        [Param("Check", "Expected L02 (0 = off)", Min = 0)] public double L02 { get; set; }
        [Param("Check", "Expected L13 (0 = off)", Min = 0)] public double L13 { get; set; }
        [Param("Check", "Length tolerance ±", Min = 0)] public double LenTol { get; set; } = 0.1;

        /// <summary>Điểm tham chiếu teach (pixel).</summary>
        public List<Pt> RefPoints { get; set; } = new List<Pt>();

        [JsonIgnore] public virtual string ActionName => "Teach reference marks";
        [JsonIgnore] protected abstract int N { get; }
        protected abstract string[] ObjLinks { get; }
        protected virtual string[] RefLinks => null;   // null = dùng RefPoints đã teach

        public override IEnumerable<Port> Ports
        {
            get
            {
                yield return new Port("Rev", Kind.Pose); yield return new Port("X", Kind.Number); yield return new Port("Y", Kind.Number); yield return new Port("T", Kind.Number);
                yield return new Port("InLimit", Kind.Bool); yield return new Port("Done", Kind.Bool); yield return new Port("Residual", Kind.Number); yield return new Port("Length", Kind.Number);
            }
        }

        string CalFor(int i) { string c = i == 0 ? Cal1 : i == 1 ? Cal2 : i == 2 ? Cal3 : Cal4; return string.IsNullOrWhiteSpace(c) ? Cal1 : c; }

        List<Pt> ReadPoints(RunContext ctx, string[] links, string what)
        {
            var l = new List<Pt>();
            for (int i = 0; i < N; i++)
            {
                if (!Geo.TryPoint(ctx, links[i], out Pt p)) throw new InvalidOperationException($"Thiếu {what} {i + 1} (link '{links[i]}')");
                l.Add(p);
            }
            return l;
        }

        public string DoAction(RunContext ctx)
        {
            RefPoints = ReadPoints(ctx, ObjLinks, "mark");
            return "Đã lưu " + RefPoints.Count + " điểm tham chiếu (pixel)";
        }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var objPx = ReadPoints(ctx, ObjLinks, "mark vật");
            List<Pt> refPx;
            if (RefLinks != null) refPx = ReadPoints(ctx, RefLinks, "mark target");
            else
            {
                if (RefPoints == null || RefPoints.Count < N) throw new InvalidOperationException("Chưa teach tham chiếu (bấm 'Teach reference marks')");
                refPx = RefPoints.Take(N).ToList();
            }
            var obj = new List<Pt>(); var rf = new List<Pt>();
            for (int i = 0; i < N; i++) { obj.Add(Cal.ToMm(ctx, CalFor(i), objPx[i])); rf.Add(Cal.ToMm(ctx, CalFor(i), refPx[i])); }

            Pt rc = new Pt(RcX, RcY);
            if (RcMode == "From calibration" && ctx.Project != null) { var c = ctx.Project.FindCalib(Cal1); if (c != null && c.Valid) rc = c.RotCenter; }
            double sign = ThetaDir.StartsWith("-") ? -1 : 1;

            var rev = AlignEngine.Solve(obj, rf, rc, sign, out double resid, out double dth);
            rev = new Xyt(rev.X + OffX, rev.Y + OffY, rev.T + OffT);

            bool inLimit = (LimX <= 0 || Math.Abs(rev.X) <= LimX) && (LimY <= 0 || Math.Abs(rev.Y) <= LimY) && (LimT <= 0 || Math.Abs(rev.T) <= LimT);
            bool done = Math.Abs(rev.X) <= PrecX && Math.Abs(rev.Y) <= PrecY && Math.Abs(rev.T) <= PrecT;

            // kiểm tra chiều dài giữa các mark vật (0-1, 2-3, 0-2, 1-3)
            bool lenOk = true; string lenMsg = "";
            void CheckLen(int a, int b, double exp, string nm)
            {
                if (exp <= 0 || a >= N || b >= N) return;
                double len = obj[a].DistTo(obj[b]);
                if (Math.Abs(len - exp) > LenTol) { lenOk = false; lenMsg += $" {nm}={len:0.###}(≠{exp})"; }
            }
            CheckLen(0, 1, L01, "L01"); CheckLen(2, 3, L23, "L23"); CheckLen(0, 2, L02, "L02"); CheckLen(1, 3, L13, "L13");
            bool residOk = MaxResidual <= 0 || resid <= MaxResidual;

            Out(ctx, "Rev", rev); Out(ctx, "X", rev.X); Out(ctx, "Y", rev.Y); Out(ctx, "T", rev.T);
            Out(ctx, "InLimit", inLimit); Out(ctx, "Done", done); Out(ctx, "Residual", resid); Out(ctx, "Length", obj.Count > 1 ? obj[0].DistTo(obj[1]) : 0.0);

            for (int i = 0; i < N; i++) { ctx.AddCross(objPx[i].Y, objPx[i].X, 18, 0, "red"); ctx.AddText(objPx[i].Y + 20, objPx[i].X + 10, "P" + (i + 1), "yellow"); }
            res.Ok = inLimit && lenOk && residOk;
            res.Message = $"{rev} resid={resid:0.###}" + (inLimit ? "" : " OUT-OF-LIMIT") + (done ? " DONE" : "") + lenMsg + (residOk ? "" : " RESIDUAL");
            ctx.Report_(Name, "X", rev.X); ctx.Report_(Name, "Y", rev.Y); ctx.Report_(Name, "T", rev.T);
        }
    }

    [Tool("Align 2P (XYT)", "Align", Description = "Căn chỉnh 2 mark → X, Y, θ (tâm xoay, offset, limit, kiểm tra chiều dài)", Glyph = "⊕")]
    public class Align2PTool : AlignBase
    {
        [Param("Marks", "Mark 1 (point)", Source = Kind.Any)] public string P1 { get; set; }
        [Param("Marks", "Mark 2 (point)", Source = Kind.Any)] public string P2 { get; set; }
        protected override int N => 2;
        protected override string[] ObjLinks => new[] { P1, P2 };
    }

    [Tool("Align 4P (XYT)", "Align", Description = "Căn chỉnh 4 mark (TL,TR,BL,BR) bằng best-fit cứng; kiểm tra 4 cạnh + sai số dư", Glyph = "⊞")]
    public class Align4PTool : AlignBase
    {
        [Param("Marks", "Mark 1 TL", Source = Kind.Any)] public string P1 { get; set; }
        [Param("Marks", "Mark 2 TR", Source = Kind.Any)] public string P2 { get; set; }
        [Param("Marks", "Mark 3 BL", Source = Kind.Any)] public string P3 { get; set; }
        [Param("Marks", "Mark 4 BR", Source = Kind.Any)] public string P4 { get; set; }
        protected override int N => 4;
        protected override string[] ObjLinks => new[] { P1, P2, P3, P4 };
    }

    [Tool("Target-Object Align", "Align", Description = "Căn Object theo Target đo trực tiếp (2 hoặc 4 mark mỗi bên) – lami/attach", Glyph = "⇄")]
    public class TargetObjectAlignTool : AlignBase
    {
        [Param("Setup", "Mark count", Choices = "2|4")] public string Count { get; set; } = "4";
        [Param("Object", "Object 1", Source = Kind.Any)] public string O1 { get; set; }
        [Param("Object", "Object 2", Source = Kind.Any)] public string O2 { get; set; }
        [Param("Object", "Object 3", Source = Kind.Any)] public string O3 { get; set; }
        [Param("Object", "Object 4", Source = Kind.Any)] public string O4 { get; set; }
        [Param("Target", "Target 1", Source = Kind.Any)] public string T1 { get; set; }
        [Param("Target", "Target 2", Source = Kind.Any)] public string T2 { get; set; }
        [Param("Target", "Target 3", Source = Kind.Any)] public string T3 { get; set; }
        [Param("Target", "Target 4", Source = Kind.Any)] public string T4 { get; set; }
        [JsonIgnore] protected override int N => Count == "2" ? 2 : 4;
        protected override string[] ObjLinks => new[] { O1, O2, O3, O4 };
        protected override string[] RefLinks => new[] { T1, T2, T3, T4 };
        [JsonIgnore] public override string ActionName => "(không cần teach)";
    }

    [Tool("Point-to-Line Inspection", "Align", Description = "Kiểm tra khoảng cách các điểm tới đường chuẩn (gap/offset) – mỗi điểm có dung sai", Glyph = "⟂")]
    public class PointLineInspectionTool : ToolBase
    {
        [Param("Input", "Reference line", Source = Kind.Line)] public string LineLink { get; set; }
        [Param("Input", "Points", Source = Kind.Points)] public string PointsLink { get; set; }
        [Param("Input", "Point 1", Source = Kind.Any)] public string P1 { get; set; }
        [Param("Input", "Point 2", Source = Kind.Any)] public string P2 { get; set; }
        [Param("Input", "Point 3", Source = Kind.Any)] public string P3 { get; set; }
        [Param("Input", "Point 4", Source = Kind.Any)] public string P4 { get; set; }
        [Param("Spec", "Calibration", List = "calib")] public string Calibration { get; set; }
        [Param("Spec", "Nominal")] public double Nominal { get; set; }
        [Param("Spec", "Tolerance −")] public double TolMinus { get; set; } = 0.1;
        [Param("Spec", "Tolerance +")] public double TolPlus { get; set; } = 0.1;
        [Param("Spec", "Use absolute distance")] public bool Absolute { get; set; } = true;
        public override IEnumerable<Port> Ports { get { yield return new Port("Min", Kind.Number); yield return new Port("Max", Kind.Number); yield return new Port("Mean", Kind.Number); yield return new Port("D1", Kind.Number); yield return new Port("D2", Kind.Number); yield return new Port("D3", Kind.Number); yield return new Port("D4", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var line = ctx.Get<LineD>(LineLink) ?? throw new InvalidOperationException("Thiếu đường chuẩn");
            var ml = Geo.ToMm(ctx, Calibration, line); var pts = new List<Pt>();
            var many = ctx.Get<List<Pt>>(PointsLink); if (many != null) pts.AddRange(many);
            foreach (var l in new[] { P1, P2, P3, P4 }) if (Geo.TryPoint(ctx, l, out Pt p)) pts.Add(p);
            if (pts.Count == 0) throw new InvalidOperationException("Chưa có điểm đầu vào");
            var ds = pts.Select(p => { double d = GeoMath.PointLineDistance(Cal.ToMm(ctx, Calibration, p), ml); return Absolute ? Math.Abs(d) : d; }).ToList();
            for (int i = 0; i < Math.Min(4, ds.Count); i++) Out(ctx, "D" + (i + 1), ds[i]);
            Out(ctx, "Min", ds.Min()); Out(ctx, "Max", ds.Max()); Out(ctx, "Mean", ds.Average());
            bool ok = ds.All(d => d - Nominal >= -Math.Abs(TolMinus) && d - Nominal <= Math.Abs(TolPlus));
            for (int i = 0; i < pts.Count; i++) ctx.AddText(pts[i].Y + 14, pts[i].X + 6, ds[i].ToString("0.###"), (ds[i] - Nominal >= -TolMinus && ds[i] - Nominal <= TolPlus) ? "green" : "red");
            ctx.AddLine(line.R1, line.C1, line.R2, line.C2, "cyan");
            res.Ok = ok; res.Message = $"min={ds.Min():0.###} max={ds.Max():0.###}"; ctx.Report_(Name, "Max", ds.Max());
        }
    }

    [Tool("Pixel → mm (Calibration)", "Calibration", Description = "Đổi điểm/danh sách điểm pixel sang mm bằng calibration đã lưu", Glyph = "㎜")]
    public class CalibApplyTool : ToolBase
    {
        [Param("Input", "Point", Source = Kind.Any)] public string PointLink { get; set; }
        [Param("Input", "Points", Source = Kind.Points)] public string PointsLink { get; set; }
        [Param("Calibration", "Calibration", List = "calib")] public string Calibration { get; set; }
        [Param("Calibration", "Add rotation center", Hint = "Cộng tâm xoay (hệ stage)")] public bool AddRc { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Point", Kind.Point); yield return new Port("Points", Kind.Points); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var cal = ctx.Project?.FindCalib(Calibration);
            if (cal == null || !cal.Valid) throw new InvalidOperationException("Calibration '" + Calibration + "' không hợp lệ");
            Pt Conv(Pt p) { var m = cal.V2R(p); return AddRc ? new Pt(m.X + cal.RotCenterX, m.Y + cal.RotCenterY) : m; }
            if (Geo.TryPoint(ctx, PointLink, out Pt p1)) { var m = Conv(p1); Out(ctx, "Point", m); res.Message = m.ToString(); res.Ok = true; }
            var many = ctx.Get<List<Pt>>(PointsLink);
            if (many != null) { Out(ctx, "Points", many.Select(Conv).ToList()); res.Ok = true; res.Message += $" {many.Count} pts"; }
            if (!res.Ok) throw new InvalidOperationException("Chưa có điểm đầu vào");
        }
    }
}
