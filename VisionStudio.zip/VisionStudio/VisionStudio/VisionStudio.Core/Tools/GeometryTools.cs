using System;
using System.Collections.Generic;
using System.Linq;
using HalconDotNet;
using Newtonsoft.Json;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Geometry;
using VisionStudio.Core.Halcon;

namespace VisionStudio.Core.Tools
{
    /// <summary>Hàm dùng chung cho tool hình học.</summary>
    internal static class Geo
    {
        public static bool TryPoint(RunContext ctx, string link, out Pt p)
        {
            p = new Pt();
            if (string.IsNullOrWhiteSpace(link) || !ctx.Values.TryGetValue(link.Trim(), out object o)) return false;
            if (o is Pt pt) { p = pt; return true; }
            if (o is Xyt xyt) { p = new Pt(xyt.X, xyt.Y); return true; }
            if (o is CircleD c) { p = c.Center; return true; }
            return false;
        }

        /// <summary>Fit đường thẳng TLS cho tập điểm (X=col, Y=row). Trả về đoạn từ điểm đầu tới điểm cuối theo hình chiếu.</summary>
        public static LineD FitLine(IList<Pt> pts, out double rms)
        {
            rms = 0; int n = pts.Count; if (n < 2) return null;
            double mx = pts.Average(p => p.X), my = pts.Average(p => p.Y);
            double sxx = 0, syy = 0, sxy = 0;
            foreach (var p in pts) { double dx = p.X - mx, dy = p.Y - my; sxx += dx * dx; syy += dy * dy; sxy += dx * dy; }
            double th = 0.5 * Math.Atan2(2 * sxy, sxx - syy);
            double ux = Math.Cos(th), uy = Math.Sin(th);
            double tmin = double.MaxValue, tmax = double.MinValue, e2 = 0;
            foreach (var p in pts)
            {
                double dx = p.X - mx, dy = p.Y - my, t = dx * ux + dy * uy, d = -dx * uy + dy * ux;
                if (t < tmin) tmin = t; if (t > tmax) tmax = t; e2 += d * d;
            }
            rms = Math.Sqrt(e2 / n);
            return new LineD(my + tmin * uy, mx + tmin * ux, my + tmax * uy, mx + tmax * ux);
        }

        public static LineD FitLineRobust(IList<Pt> pts, out double rms)
        {
            var use = pts.ToList(); var l = FitLine(use, out rms);
            for (int it = 0; it < 3 && l != null && use.Count > 4; it++)
            {
                double lim = Math.Max(2.5 * rms, 0.3);
                var keep = use.Where(p => Math.Abs(GeoMath.PointLineDistance(p, l)) <= lim).ToList();
                if (keep.Count == use.Count || keep.Count < 3) break;
                use = keep; l = FitLine(use, out rms);
            }
            return l;
        }

        public static LineD ToMm(RunContext ctx, string cal, LineD l)
        {
            var a = Cal.ToMm(ctx, cal, l.P1); var b = Cal.ToMm(ctx, cal, l.P2);
            return new LineD(a.Y, a.X, b.Y, b.X);
        }

        public static string AutoParams(out HTuple names, out HTuple vals, string transition, string select, int n, double minScore)
        {
            names = HalconUtil.Tup("measure_transition", "measure_select", "num_measures", "num_instances", "min_score");
            vals = HalconUtil.Tup(transition, select, n, 1, minScore); return "";
        }
    }

    [Tool("Find Line", "Geometry", Description = "Tìm đường thẳng bằng caliper (Halcon Metrology) + fit tự loại điểm nhiễu", Glyph = "╱")]
    public class FindLineTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("ROI", "Line ROI")] public LineRoi Roi { get; set; } = new LineRoi();
        [Param("Caliper", "Number of calipers", Min = 3)] public int Count { get; set; } = 15;
        [Param("Caliper", "Caliper half-width", Min = 1)] public double CaliperWidth { get; set; } = 5;
        [Param("Caliper", "Sigma", Min = 0.4)] public double Sigma { get; set; } = 1.5;
        [Param("Caliper", "Edge threshold", Min = 1)] public double Threshold { get; set; } = 30;
        [Param("Caliper", "Transition", Choices = "all|positive|negative")] public string Transition { get; set; } = "all";
        [Param("Caliper", "Select", Choices = "first|last|all")] public string Select { get; set; } = "first";
        [Param("Caliper", "Min score", Min = 0, Max = 1)] public double MinScore { get; set; } = 0.5;
        [Param("Spec", "Min used calipers %", Min = 0, Max = 100)] public double MinUsedPct { get; set; } = 50;

        public override IEnumerable<Port> Ports
        {
            get { yield return new Port("Line", Kind.Line); yield return new Port("Mid", Kind.Point); yield return new Port("Angle", Kind.Number); yield return new Port("Score", Kind.Number); yield return new Port("Points", Kind.Points); }
        }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = HalconUtil.ToGray(RequireImage(ctx, InputImage));
            var roi = Roi.Transformed(GetFixture(ctx, FixtureLink));
            HTuple mh = null;
            try
            {
                ImageSize(img, out int w, out int h);
                HOperatorSet.CreateMetrologyModel(out mh);
                HOperatorSet.SetMetrologyModelImageSize(mh, w, h);
                Geo.AutoParams(out HTuple pn, out HTuple pv, Transition, Select, Count, MinScore);
                HOperatorSet.AddMetrologyObjectLineMeasure(mh, roi.R1, roi.C1, roi.R2, roi.C2, roi.HalfWidth, CaliperWidth, Sigma, Threshold, pn, pv, out HTuple idx);
                HOperatorSet.ApplyMetrologyModel(img, mh);
                HOperatorSet.GetMetrologyObjectResult(mh, idx, "all", "result_type", "all_param", out HTuple prm);
                HOperatorSet.GetMetrologyObjectMeasures(out HObject mc, mh, idx, "all", out HTuple mr, out HTuple mcol);
                mc.Dispose();

                using (var reg = roi.ToRegion()) ctx.AddObj(reg, "blue");
                var pts = new List<Pt>(); for (int i = 0; i < mr.Length; i++) pts.Add(new Pt(mcol[i].D, mr[i].D));
                foreach (var p in pts) ctx.AddCross(p.Y, p.X, 4, 0, "yellow");
                double score = Count > 0 ? (double)pts.Count / Count : 0;
                Out(ctx, "Points", pts); Out(ctx, "Score", score);
                if (prm.Length < 4 || pts.Count < 2) { res.Ok = false; res.Message = "Không tìm thấy đường (" + pts.Count + " điểm)"; return; }

                var line = new LineD(prm[0].D, prm[1].D, prm[2].D, prm[3].D);
                Out(ctx, "Line", line); Out(ctx, "Mid", GeoMath.Mid(line.P1, line.P2)); Out(ctx, "Angle", line.AngleDeg);
                ctx.AddLine(line.R1, line.C1, line.R2, line.C2, "green");
                res.Ok = score * 100 >= MinUsedPct; res.Message = $"angle={line.AngleDeg:0.###}° used={pts.Count}/{Count}";
                ctx.Report_(Name, "Angle", line.AngleDeg); ctx.Report_(Name, "Used", pts.Count);
            }
            finally { if (mh != null) { try { HOperatorSet.ClearMetrologyModel(mh); } catch { } } img.Dispose(); }
        }
    }

    [Tool("Find Circle", "Geometry", Description = "Tìm đường tròn bằng caliper hướng tâm (Halcon Metrology)", Glyph = "◯")]
    public class FindCircleTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("ROI", "Circle ROI")] public CircleRoi Roi { get; set; } = new CircleRoi();
        [Param("Caliper", "Number of calipers", Min = 4)] public int Count { get; set; } = 36;
        [Param("Caliper", "Caliper half-width", Min = 1)] public double CaliperWidth { get; set; } = 5;
        [Param("Caliper", "Sigma", Min = 0.4)] public double Sigma { get; set; } = 1.5;
        [Param("Caliper", "Edge threshold", Min = 1)] public double Threshold { get; set; } = 30;
        [Param("Caliper", "Transition", Choices = "all|positive|negative")] public string Transition { get; set; } = "all";
        [Param("Caliper", "Select", Choices = "first|last|all")] public string Select { get; set; } = "first";
        [Param("Caliper", "Min score", Min = 0, Max = 1)] public double MinScore { get; set; } = 0.5;
        [Param("Spec", "Min used calipers %", Min = 0, Max = 100)] public double MinUsedPct { get; set; } = 50;
        [Param("Spec", "Calibration", List = "calib")] public string Calibration { get; set; }
        [Param("Spec", "Nominal diameter (mm/px)")] public double Nominal { get; set; }
        [Param("Spec", "Tolerance ±")] public double Tol { get; set; }

        public override IEnumerable<Port> Ports
        {
            get { yield return new Port("Circle", Kind.Circle); yield return new Port("Center", Kind.Point); yield return new Port("Radius", Kind.Number); yield return new Port("Diameter", Kind.Number); yield return new Port("Score", Kind.Number); yield return new Port("Points", Kind.Points); }
        }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = HalconUtil.ToGray(RequireImage(ctx, InputImage));
            var roi = Roi.Transformed(GetFixture(ctx, FixtureLink)); HTuple mh = null;
            try
            {
                ImageSize(img, out int w, out int h);
                HOperatorSet.CreateMetrologyModel(out mh); HOperatorSet.SetMetrologyModelImageSize(mh, w, h);
                Geo.AutoParams(out HTuple pn, out HTuple pv, Transition, Select, Count, MinScore);
                HOperatorSet.AddMetrologyObjectCircleMeasure(mh, roi.R, roi.C, roi.Radius, roi.HalfWidth, CaliperWidth, Sigma, Threshold, pn, pv, out HTuple idx);
                HOperatorSet.ApplyMetrologyModel(img, mh);
                HOperatorSet.GetMetrologyObjectResult(mh, idx, "all", "result_type", "all_param", out HTuple prm);
                HOperatorSet.GetMetrologyObjectMeasures(out HObject mc, mh, idx, "all", out HTuple mr, out HTuple mcol); mc.Dispose();
                using (var reg = roi.ToRegion()) ctx.AddObj(reg, "blue");
                var pts = new List<Pt>(); for (int i = 0; i < mr.Length; i++) pts.Add(new Pt(mcol[i].D, mr[i].D));
                foreach (var p in pts) ctx.AddCross(p.Y, p.X, 4, 0, "yellow");
                double score = (double)pts.Count / Count; Out(ctx, "Points", pts); Out(ctx, "Score", score);
                if (prm.Length < 3) { res.Ok = false; res.Message = "Không tìm thấy vòng tròn"; return; }
                var c = new CircleD(prm[0].D, prm[1].D, prm[2].D);
                Out(ctx, "Circle", c); Out(ctx, "Center", c.Center); Out(ctx, "Radius", c.Rad);
                double dia = 2 * c.Rad * Cal.Scale(ctx, Calibration); Out(ctx, "Diameter", dia);
                ctx.AddCircle(c.R, c.C, c.Rad, "green"); ctx.AddCross(c.R, c.C, 15, 0, "red");
                res.Ok = score * 100 >= MinUsedPct && (Tol <= 0 || Math.Abs(dia - Nominal) <= Tol);
                res.Message = $"R={c.Rad:0.###}px Ø={dia:0.###} used={pts.Count}/{Count}"; ctx.Report_(Name, "Diameter", dia);
            }
            finally { if (mh != null) { try { HOperatorSet.ClearMetrologyModel(mh); } catch { } } img.Dispose(); }
        }
    }

    [Tool("Caliper (Width)", "Geometry", Description = "Đo bề rộng giữa 2 cạnh (measure_pairs) trong ROI chữ nhật; Phi = hướng đo", Glyph = "↔")]
    public class CaliperTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("ROI", "Measure ROI (Len1 = hướng đo)")] public Rect2Roi Roi { get; set; } = new Rect2Roi { Len1 = 60, Len2 = 15 };
        [Param("Edge", "Sigma", Min = 0.4)] public double Sigma { get; set; } = 1.5;
        [Param("Edge", "Threshold", Min = 1)] public double Threshold { get; set; } = 30;
        [Param("Edge", "Transition", Choices = "all|positive|negative")] public string Transition { get; set; } = "positive";
        [Param("Edge", "Select", Choices = "first|last|all")] public string Select { get; set; } = "first";
        [Param("Spec", "Calibration", List = "calib")] public string Calibration { get; set; }
        [Param("Spec", "Nominal")] public double Nominal { get; set; }
        [Param("Spec", "Tolerance ±")] public double Tol { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Width", Kind.Number); yield return new Port("Mid", Kind.Point); yield return new Port("Count", Kind.Number); yield return new Port("Points", Kind.Points); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = HalconUtil.ToGray(RequireImage(ctx, InputImage)); var roi = Roi.Transformed(GetFixture(ctx, FixtureLink)); HTuple mh = null;
            try
            {
                ImageSize(img, out int w, out int h);
                HOperatorSet.GenMeasureRectangle2(roi.Row, roi.Col, roi.PhiDeg * GeoMath.D2R, roi.Len1, roi.Len2, w, h, "bilinear", out mh);
                HOperatorSet.MeasurePairs(img, mh, Sigma, Threshold, Transition, Select, out HTuple r1, out HTuple c1, out HTuple a1, out HTuple r2, out HTuple c2, out HTuple a2, out HTuple intra, out HTuple inter);
                using (var reg = roi.ToRegion()) ctx.AddObj(reg, "blue");
                int n = r1.Length; Out(ctx, "Count", (double)n);
                if (n == 0) { res.Ok = false; res.Message = "Không thấy cặp cạnh"; return; }
                var pts = new List<Pt>();
                for (int i = 0; i < n; i++) { pts.Add(new Pt(c1[i].D, r1[i].D)); pts.Add(new Pt(c2[i].D, r2[i].D)); ctx.AddLine(r1[i].D, c1[i].D, r2[i].D, c2[i].D, "green"); }
                double wd = intra[0].D * Cal.Scale(ctx, Calibration);
                Out(ctx, "Width", wd); Out(ctx, "Mid", new Pt((c1[0].D + c2[0].D) / 2, (r1[0].D + r2[0].D) / 2)); Out(ctx, "Points", pts);
                res.Ok = Tol <= 0 || Math.Abs(wd - Nominal) <= Tol; res.Message = "width=" + Cal.F(wd); ctx.Report_(Name, "Width", wd);
            }
            finally { if (mh != null) { try { HOperatorSet.CloseMeasure(mh); } catch { } } img.Dispose(); }
        }
    }

    [Tool("Find Parallel Line", "Geometry", Description = "Tìm 2 đường song song (băng/cạnh kép) + khoảng cách + đường tâm", Glyph = "═")]
    public class FindParallelLineTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("ROI", "Line ROI (HalfWidth = nửa vùng tìm)")] public LineRoi Roi { get; set; } = new LineRoi { HalfWidth = 40 };
        [Param("Caliper", "Number of calipers", Min = 3)] public int Count { get; set; } = 12;
        [Param("Caliper", "Caliper half-width", Min = 1)] public double CaliperWidth { get; set; } = 6;
        [Param("Caliper", "Sigma", Min = 0.4)] public double Sigma { get; set; } = 1.5;
        [Param("Caliper", "Threshold", Min = 1)] public double Threshold { get; set; } = 30;
        [Param("Caliper", "Transition", Choices = "all|positive|negative")] public string Transition { get; set; } = "positive";
        [Param("Spec", "Calibration", List = "calib")] public string Calibration { get; set; }
        [Param("Spec", "Nominal distance")] public double Nominal { get; set; }
        [Param("Spec", "Tolerance ±")] public double Tol { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Line1", Kind.Line); yield return new Port("Line2", Kind.Line); yield return new Port("Center", Kind.Line); yield return new Port("Distance", Kind.Number); yield return new Port("Angle", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = HalconUtil.ToGray(RequireImage(ctx, InputImage)); var roi = Roi.Transformed(GetFixture(ctx, FixtureLink));
            var A = new List<Pt>(); var B = new List<Pt>();
            try
            {
                ImageSize(img, out int w, out int h);
                double dr = roi.R2 - roi.R1, dc = roi.C2 - roi.C1, len = Math.Sqrt(dr * dr + dc * dc);
                double phi = Math.Atan2(-dr, dc) + Math.PI / 2;     // hướng đo vuông góc đường ROI
                for (int i = 0; i < Count; i++)
                {
                    double t = (i + 0.5) / Count, r = roi.R1 + t * dr, c = roi.C1 + t * dc; HTuple mh = null;
                    try
                    {
                        HOperatorSet.GenMeasureRectangle2(r, c, phi, roi.HalfWidth, Math.Max(1, CaliperWidth), w, h, "bilinear", out mh);
                        HOperatorSet.MeasurePairs(img, mh, Sigma, Threshold, Transition, "first", out HTuple r1, out HTuple c1, out HTuple a1, out HTuple r2, out HTuple c2, out HTuple a2, out HTuple intra, out HTuple inter);
                        if (r1.Length > 0) { A.Add(new Pt(c1[0].D, r1[0].D)); B.Add(new Pt(c2[0].D, r2[0].D)); }
                    }
                    finally { if (mh != null) HOperatorSet.CloseMeasure(mh); }
                }
                using (var reg = roi.ToRegion()) ctx.AddObj(reg, "blue");
                if (A.Count < 3) { res.Ok = false; res.Message = "Ít điểm (" + A.Count + ")"; return; }
                var l1 = Geo.FitLineRobust(A, out double e1); var l2 = Geo.FitLineRobust(B, out double e2);
                var mid = new LineD((l1.R1 + l2.R1) / 2, (l1.C1 + l2.C1) / 2, (l1.R2 + l2.R2) / 2, (l1.C2 + l2.C2) / 2);
                double dist = (Math.Abs(GeoMath.PointLineDistance(l2.P1, l1)) + Math.Abs(GeoMath.PointLineDistance(l2.P2, l1))) / 2 * Cal.Scale(ctx, Calibration);
                Out(ctx, "Line1", l1); Out(ctx, "Line2", l2); Out(ctx, "Center", mid); Out(ctx, "Distance", dist); Out(ctx, "Angle", mid.AngleDeg);
                ctx.AddLine(l1.R1, l1.C1, l1.R2, l1.C2, "green"); ctx.AddLine(l2.R1, l2.C1, l2.R2, l2.C2, "green"); ctx.AddLine(mid.R1, mid.C1, mid.R2, mid.C2, "cyan");
                res.Ok = Tol <= 0 || Math.Abs(dist - Nominal) <= Tol; res.Message = $"dist={Cal.F(dist)} angle={mid.AngleDeg:0.###}°"; ctx.Report_(Name, "Distance", dist);
            }
            finally { img.Dispose(); }
        }
    }

    [Tool("Edge Contour", "Geometry", Description = "Trích cạnh sub-pixel trong ROI (edges_sub_pix): số contour, tổng chiều dài, điểm", Glyph = "〰")]
    public class EdgeTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("ROI", "Region")] public Rect2Roi Roi { get; set; } = new Rect2Roi();
        [Param("Edge", "Filter", Choices = "canny|deriche1|lanser2|sobel_amp")] public string Filter { get; set; } = "canny";
        [Param("Edge", "Alpha", Min = 0.2)] public double Alpha { get; set; } = 1.0;
        [Param("Edge", "Low", Min = 1)] public double Low { get; set; } = 20;
        [Param("Edge", "High", Min = 1)] public double High { get; set; } = 40;
        [Param("Filter", "Min contour length", Min = 0)] public double MinLen { get; set; } = 20;
        public override IEnumerable<Port> Ports { get { yield return new Port("Count", Kind.Number); yield return new Port("Length", Kind.Number); yield return new Port("Points", Kind.Points); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var gray = HalconUtil.ToGray(RequireImage(ctx, InputImage)); HObject rg = Roi.Transformed(GetFixture(ctx, FixtureLink)).ToRegion(), red = null, edges = null, sel = null;
            try
            {
                red = HalconUtil.ReduceTo(gray, rg);
                HOperatorSet.EdgesSubPix(red, out edges, Filter, Alpha, Low, High);
                HOperatorSet.SelectContoursXld(edges, out sel, "contour_length", MinLen, 1e9, -0.5, 0.5);
                int n = HalconUtil.Count(sel); Out(ctx, "Count", (double)n);
                var pts = new List<Pt>(); double total = 0;
                if (n > 0)
                {
                    HOperatorSet.LengthXld(sel, out HTuple lens); total = lens.TupleSum().D;
                    for (int k = 1; k <= Math.Min(n, 30); k++)
                    {
                        HOperatorSet.SelectObj(sel, out HObject one, k);
                        HOperatorSet.GetContourXld(one, out HTuple rr, out HTuple cc); one.Dispose();
                        int step = Math.Max(1, rr.Length / 200);
                        for (int i = 0; i < rr.Length; i += step) pts.Add(new Pt(cc[i].D, rr[i].D));
                    }
                }
                Out(ctx, "Length", total); Out(ctx, "Points", pts); ctx.AddObj(rg, "yellow"); ctx.AddObj(sel, "green");
                res.Ok = n > 0; res.Message = $"{n} contours, L={total:0.#}";
            }
            finally { gray.Dispose(); rg.Dispose(); red?.Dispose(); edges?.Dispose(); sel?.Dispose(); }
        }
    }

    [Tool("Intersect Lines (Corner)", "Geometry", Description = "Giao điểm 2 đường thẳng + góc giữa chúng (tìm góc/corner)", Glyph = "✕")]
    public class IntersectLineTool : ToolBase
    {
        [Param("Input", "Line A", Source = Kind.Line)] public string LineA { get; set; }
        [Param("Input", "Line B", Source = Kind.Line)] public string LineB { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Point", Kind.Point); yield return new Port("Angle", Kind.Number); yield return new Port("Pose", Kind.Pose); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var a = ctx.Get<LineD>(LineA); var b = ctx.Get<LineD>(LineB);
            if (a == null || b == null) throw new InvalidOperationException("Thiếu đường thẳng đầu vào");
            if (!GeoMath.Intersect(a, b, out Pt p)) { res.Ok = false; res.Message = "Hai đường song song"; return; }
            double ang = Math.Abs(GeoMath.NormDeg(a.AngleDeg - b.AngleDeg)); if (ang > 90) ang = 180 - ang;
            Out(ctx, "Point", p); Out(ctx, "Angle", ang); Out(ctx, "Pose", new Xyt(p.X, p.Y, a.AngleDeg));
            ctx.AddCross(p.Y, p.X, 20, 0, "red"); res.Ok = true; res.Message = $"{p} angle={ang:0.##}°"; ctx.Report_(Name, "X", p.X); ctx.Report_(Name, "Y", p.Y);
        }
    }

    [Tool("Fit Points", "Geometry", Description = "Fit đường thẳng hoặc đường tròn từ danh sách điểm", Glyph = "⌇")]
    public class FitTool : ToolBase
    {
        [Param("Input", "Points", Source = Kind.Points)] public string InputPoints { get; set; }
        [Param("Fit", "Type", Choices = "Line|Circle")] public string FitType { get; set; } = "Line";
        public override IEnumerable<Port> Ports { get { yield return new Port("Line", Kind.Line); yield return new Port("Circle", Kind.Circle); yield return new Port("Center", Kind.Point); yield return new Port("Error", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var pts = ctx.Get<List<Pt>>(InputPoints) ?? throw new InvalidOperationException("Thiếu điểm đầu vào");
            if (FitType == "Line")
            {
                var l = Geo.FitLineRobust(pts, out double rms) ?? throw new InvalidOperationException("Cần ≥ 2 điểm");
                Out(ctx, "Line", l); Out(ctx, "Center", GeoMath.Mid(l.P1, l.P2)); Out(ctx, "Error", rms); ctx.AddLine(l.R1, l.C1, l.R2, l.C2, "green"); res.Message = $"rms={rms:0.###}";
            }
            else
            {
                if (!GeoMath.FitCircle(pts, out double cx, out double cy, out double r)) throw new InvalidOperationException("Fit tròn thất bại (cần ≥ 3 điểm)");
                var c = new CircleD(cy, cx, r); double e = pts.Average(p => Math.Abs(p.DistTo(c.Center) - r));
                Out(ctx, "Circle", c); Out(ctx, "Center", c.Center); Out(ctx, "Error", e); ctx.AddCircle(cy, cx, r, "green"); res.Message = $"R={r:0.###} err={e:0.###}";
            }
            res.Ok = true;
        }
    }

    [Tool("Make Point", "Geometry", Glyph = "•")]
    public class MakePointTool : ToolBase
    {
        [Param("Point", "Mode", Choices = "Fixed|From numbers|Midpoint|On line (ratio)|Offset from point")] public string Mode { get; set; } = "Fixed";
        [Param("Point", "X (col)")] public double X_ { get; set; }
        [Param("Point", "Y (row)")] public double Y_ { get; set; }
        [Param("Input", "X number", Source = Kind.Number)] public string XLink { get; set; }
        [Param("Input", "Y number", Source = Kind.Number)] public string YLink { get; set; }
        [Param("Input", "Point A", Source = Kind.Any)] public string PointA { get; set; }
        [Param("Input", "Point B", Source = Kind.Any)] public string PointB { get; set; }
        [Param("Input", "Line", Source = Kind.Line)] public string LineLink { get; set; }
        [Param("Point", "Ratio 0..1 (On line)")] public double Ratio { get; set; } = 0.5;
        [Param("Point", "Offset X")] public double OffX { get; set; }
        [Param("Point", "Offset Y")] public double OffY { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Point", Kind.Point); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            Pt p;
            switch (Mode)
            {
                case "From numbers":
                    ctx.TryGet(XLink, out double x); ctx.TryGet(YLink, out double y); p = new Pt(x, y); break;
                case "Midpoint":
                    if (!Geo.TryPoint(ctx, PointA, out Pt a) || !Geo.TryPoint(ctx, PointB, out Pt b)) throw new InvalidOperationException("Thiếu điểm A/B");
                    p = GeoMath.Mid(a, b); break;
                case "On line (ratio)":
                    var l = ctx.Get<LineD>(LineLink) ?? throw new InvalidOperationException("Thiếu đường thẳng");
                    p = new Pt(l.C1 + Ratio * (l.C2 - l.C1), l.R1 + Ratio * (l.R2 - l.R1)); break;
                case "Offset from point":
                    if (!Geo.TryPoint(ctx, PointA, out Pt o)) throw new InvalidOperationException("Thiếu điểm A");
                    p = new Pt(o.X + OffX, o.Y + OffY); break;
                default: p = new Pt(X_, Y_); break;
            }
            Out(ctx, "Point", p); ctx.AddCross(p.Y, p.X, 12, 0, "magenta"); res.Ok = true; res.Message = p.ToString();
        }
    }

    [Tool("Make Line", "Geometry", Description = "Tạo đường thẳng từ 2 điểm", Glyph = "─")]
    public class MakeLineTool : ToolBase
    {
        [Param("Input", "Point A", Source = Kind.Any)] public string PointA { get; set; }
        [Param("Input", "Point B", Source = Kind.Any)] public string PointB { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Line", Kind.Line); yield return new Port("Angle", Kind.Number); yield return new Port("Length", Kind.Number); } }
        protected override void Execute(RunContext ctx, ToolResult res)
        {
            if (!Geo.TryPoint(ctx, PointA, out Pt a) || !Geo.TryPoint(ctx, PointB, out Pt b)) throw new InvalidOperationException("Thiếu điểm A/B");
            var l = new LineD(a.Y, a.X, b.Y, b.X); Out(ctx, "Line", l); Out(ctx, "Angle", l.AngleDeg); Out(ctx, "Length", l.Length);
            ctx.AddLine(a.Y, a.X, b.Y, b.X, "magenta"); res.Ok = true; res.Message = $"angle={l.AngleDeg:0.##}°";
        }
    }

    [Tool("Circle From 3 Points", "Geometry", Glyph = "◌")]
    public class CreateCircleTool : ToolBase
    {
        [Param("Input", "Point A", Source = Kind.Any)] public string PointA { get; set; }
        [Param("Input", "Point B", Source = Kind.Any)] public string PointB { get; set; }
        [Param("Input", "Point C", Source = Kind.Any)] public string PointC { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Circle", Kind.Circle); yield return new Port("Center", Kind.Point); yield return new Port("Radius", Kind.Number); } }
        protected override void Execute(RunContext ctx, ToolResult res)
        {
            if (!Geo.TryPoint(ctx, PointA, out Pt a) || !Geo.TryPoint(ctx, PointB, out Pt b) || !Geo.TryPoint(ctx, PointC, out Pt c)) throw new InvalidOperationException("Thiếu điểm");
            if (!GeoMath.FitCircle(new[] { a, b, c }, out double cx, out double cy, out double r)) throw new InvalidOperationException("3 điểm thẳng hàng");
            var cd = new CircleD(cy, cx, r); Out(ctx, "Circle", cd); Out(ctx, "Center", cd.Center); Out(ctx, "Radius", r); ctx.AddCircle(cy, cx, r, "magenta"); res.Ok = true;
        }
    }

    [Tool("Make Lattice", "Geometry", Description = "Sinh lưới điểm (hàng/cột, bước, góc xoay) từ điểm gốc", Glyph = "⁞")]
    public class MakeLatticeTool : ToolBase
    {
        [Param("Input", "Origin point", Source = Kind.Any)] public string Origin { get; set; }
        [Param("Lattice", "Origin X (nếu không link)")] public double OX { get; set; }
        [Param("Lattice", "Origin Y")] public double OY { get; set; }
        [Param("Lattice", "Columns", Min = 1)] public int Cols { get; set; } = 3;
        [Param("Lattice", "Rows", Min = 1)] public int Rows { get; set; } = 3;
        [Param("Lattice", "Pitch X")] public double PitchX { get; set; } = 50;
        [Param("Lattice", "Pitch Y")] public double PitchY { get; set; } = 50;
        [Param("Lattice", "Rotation (deg)")] public double Rot { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Points", Kind.Points); yield return new Port("Count", Kind.Number); } }
        protected override void Execute(RunContext ctx, ToolResult res)
        {
            Pt o = new Pt(OX, OY); if (!string.IsNullOrWhiteSpace(Origin) && Geo.TryPoint(ctx, Origin, out Pt lo)) o = lo;
            double r = Rot * GeoMath.D2R, cs = Math.Cos(r), sn = Math.Sin(r); var list = new List<Pt>();
            for (int j = 0; j < Rows; j++) for (int i = 0; i < Cols; i++)
                { double dx = i * PitchX, dy = j * PitchY; list.Add(new Pt(o.X + dx * cs - dy * sn, o.Y + dx * sn + dy * cs)); }
            Out(ctx, "Points", list); Out(ctx, "Count", (double)list.Count); foreach (var p in list) ctx.AddCross(p.Y, p.X, 8, 0, "magenta"); res.Ok = true;
        }
    }

    [Tool("Measurement", "Measure", Description = "Khoảng cách / góc: điểm-điểm, điểm-đường, đường-đường, góc 3 điểm, góc 2 đường, dX, dY. Có dung sai", Glyph = "📏")]
    public class MeasurementTool : ToolBase
    {
        [Param("Measure", "Mode", Choices = "Point-Point|Point-Line|Line-Line|Angle 3 points|Angle Line-Line|dX (B-A)|dY (B-A)")] public string Mode { get; set; } = "Point-Point";
        [Param("Input", "A", Source = Kind.Any)] public string A { get; set; }
        [Param("Input", "B", Source = Kind.Any)] public string B { get; set; }
        [Param("Input", "C (vertex = B)", Source = Kind.Any)] public string C { get; set; }
        [Param("Spec", "Calibration", List = "calib")] public string Calibration { get; set; }
        [Param("Spec", "Nominal")] public double Nominal { get; set; }
        [Param("Spec", "Tolerance −")] public double TolMinus { get; set; }
        [Param("Spec", "Tolerance +")] public double TolPlus { get; set; }
        [Param("Spec", "Offset")] public double Offset { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Value", Kind.Number); yield return new Port("Deviation", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            double v;
            switch (Mode)
            {
                case "Point-Line":
                    { Geo.TryPoint(ctx, A, out Pt p); var l = ctx.Get<LineD>(B) ?? throw new InvalidOperationException("B phải là đường thẳng");
                      v = Math.Abs(GeoMath.PointLineDistance(Cal.ToMm(ctx, Calibration, p), Geo.ToMm(ctx, Calibration, l))); break; }
                case "Line-Line":
                    { var la = ctx.Get<LineD>(A) ?? throw new InvalidOperationException("A phải là đường thẳng"); var lb = ctx.Get<LineD>(B) ?? throw new InvalidOperationException("B phải là đường thẳng");
                      var ma = Geo.ToMm(ctx, Calibration, la); var mb = Geo.ToMm(ctx, Calibration, lb);
                      v = (Math.Abs(GeoMath.PointLineDistance(mb.P1, ma)) + Math.Abs(GeoMath.PointLineDistance(mb.P2, ma))) / 2; break; }
                case "Angle 3 points":
                    { if (!Geo.TryPoint(ctx, A, out Pt a) || !Geo.TryPoint(ctx, B, out Pt b) || !Geo.TryPoint(ctx, C, out Pt c)) throw new InvalidOperationException("Thiếu điểm A/B/C");
                      double a1 = Math.Atan2(a.Y - b.Y, a.X - b.X), a2 = Math.Atan2(c.Y - b.Y, c.X - b.X);
                      v = Math.Abs(GeoMath.NormDeg((a1 - a2) * GeoMath.R2D)); break; }
                case "Angle Line-Line":
                    { var la = ctx.Get<LineD>(A); var lb = ctx.Get<LineD>(B); if (la == null || lb == null) throw new InvalidOperationException("Thiếu đường thẳng");
                      v = Math.Abs(GeoMath.NormDeg(la.AngleDeg - lb.AngleDeg)); if (v > 90) v = 180 - v; break; }
                case "dX (B-A)":
                case "dY (B-A)":
                    { if (!Geo.TryPoint(ctx, A, out Pt a) || !Geo.TryPoint(ctx, B, out Pt b)) throw new InvalidOperationException("Thiếu điểm A/B");
                      var ma = Cal.ToMm(ctx, Calibration, a); var mb = Cal.ToMm(ctx, Calibration, b); v = Mode.StartsWith("dX") ? mb.X - ma.X : mb.Y - ma.Y; break; }
                default:
                    { if (!Geo.TryPoint(ctx, A, out Pt a) || !Geo.TryPoint(ctx, B, out Pt b)) throw new InvalidOperationException("Thiếu điểm A/B");
                      v = Cal.ToMm(ctx, Calibration, a).DistTo(Cal.ToMm(ctx, Calibration, b));
                      ctx.AddLine(a.Y, a.X, b.Y, b.X, "cyan"); break; }
            }
            v += Offset; double dev = v - Nominal;
            Out(ctx, "Value", v); Out(ctx, "Deviation", dev);
            res.Ok = (TolMinus == 0 && TolPlus == 0) || (dev >= -Math.Abs(TolMinus) && dev <= Math.Abs(TolPlus));
            res.Message = $"{Mode} = {Cal.F(v)} (Δ {Cal.F(dev)})"; ctx.Report_(Name, "Value", v);
        }
    }

    [Tool("Fixture (from point + angle)", "Geometry", Description = "Tạo hệ toạ độ Fixture từ điểm & góc bất kỳ (vd. từ FindLine/Intersect). Bấm Teach để lưu pose chuẩn", Glyph = "⌖")]
    public class FixtureTool : ToolBase, IToolAction
    {
        [Param("Input", "Point", Source = Kind.Any)] public string PointLink { get; set; }
        [Param("Input", "Angle (deg)", Source = Kind.Number)] public string AngleLink { get; set; }
        [Param("Reference", "Ref row")] public double RefRow { get; set; }
        [Param("Reference", "Ref col")] public double RefCol { get; set; }
        [Param("Reference", "Ref angle")] public double RefAngle { get; set; }
        [JsonIgnore] public string ActionName => "Teach reference";
        public override IEnumerable<Port> Ports { get { yield return new Port("Fixture", Kind.Fixture); } }

        bool Read(RunContext ctx, out double r, out double c, out double a)
        {
            r = c = a = 0; if (!Geo.TryPoint(ctx, PointLink, out Pt p)) return false;
            r = p.Y; c = p.X; ctx.TryGet(AngleLink, out a); return true;
        }
        public string DoAction(RunContext ctx)
        {
            if (!Read(ctx, out double r, out double c, out double a)) throw new InvalidOperationException("Chưa có điểm đầu vào");
            RefRow = r; RefCol = c; RefAngle = a; return $"Ref = ({r:0.##}, {c:0.##}, {a:0.##}°)";
        }
        protected override void Execute(RunContext ctx, ToolResult res)
        {
            if (!Read(ctx, out double r, out double c, out double a)) throw new InvalidOperationException("Chưa có điểm đầu vào");
            Out(ctx, "Fixture", new FixtureData { R0 = RefRow, C0 = RefCol, A0 = RefAngle, R1 = r, C1 = c, A1 = a });
            ctx.AddCross(r, c, 25, a, "red"); res.Ok = true; res.Message = $"Δ=({c - RefCol:0.##}, {r - RefRow:0.##}, {a - RefAngle:0.##}°)";
        }
    }
}
