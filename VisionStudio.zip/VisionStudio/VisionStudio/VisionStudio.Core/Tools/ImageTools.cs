using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HalconDotNet;
using VisionStudio.Core.Camera;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Geometry;
using VisionStudio.Core.Halcon;

namespace VisionStudio.Core.Tools
{
    [Tool("Image Source", "Acquisition", Description = "Nạp ảnh từ file, thư mục hoặc camera (Halcon frame grabber)", Glyph = "📷")]
    public class ImageSourceTool : ToolBase
    {
        [Param("Source", "Mode", Choices = "File|Folder|Camera")] public string Mode { get; set; } = "File";
        [Param("Source", "File", Editor = Editor.File)] public string FilePath { get; set; }
        [Param("Source", "Folder", Editor = Editor.Folder)] public string FolderPath { get; set; }
        [Param("Source", "Loop folder")] public bool LoopFolder { get; set; } = true;
        [Param("Source", "Camera", List = "camera")] public string Camera { get; set; }
        [Newtonsoft.Json.JsonIgnore] public int FolderIndex { get; set; }
        [Newtonsoft.Json.JsonIgnore] public string CurrentPath { get; private set; }

        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); yield return new Port("Width", Kind.Number); yield return new Port("Height", Kind.Number); yield return new Port("Path", Kind.Text); } }

        static readonly string[] Exts = { ".bmp", ".png", ".jpg", ".jpeg", ".tif", ".tiff" };

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            HObject img; string path = "";
            if (Mode == "Camera")
            {
                var cfg = ctx.Project?.Cameras.FirstOrDefault(c => c.Name == Camera) ?? throw new InvalidOperationException("Chưa chọn camera");
                if (!CameraService.IsOpen(cfg.Name)) CameraService.Open(cfg);
                img = CameraService.Grab(cfg); path = "camera:" + cfg.Name;
            }
            else
            {
                if (Mode == "Folder")
                {
                    var files = Directory.Exists(FolderPath ?? "") ? Directory.GetFiles(FolderPath).Where(f => Exts.Contains(Path.GetExtension(f).ToLower())).OrderBy(f => f).ToArray() : new string[0];
                    if (files.Length == 0) throw new FileNotFoundException("Thư mục không có ảnh");
                    if (FolderIndex >= files.Length) { if (LoopFolder) FolderIndex = 0; else throw new InvalidOperationException("Hết ảnh"); }
                    path = files[FolderIndex++];
                }
                else path = FilePath;
                if (!File.Exists(path ?? "")) throw new FileNotFoundException("Không thấy file ảnh", path);
                img = ImageIo.Read(path);
            }
            CurrentPath = path;
            ImageSize(img, out int w, out int h);
            Out(ctx, "Image", img); Out(ctx, "Width", (double)w); Out(ctx, "Height", (double)h); Out(ctx, "Path", path);
            res.Ok = true; res.Message = $"{w}x{h} {Path.GetFileName(path)}";
        }
    }

    [Tool("Image Save", "Acquisition", Description = "Lưu ảnh theo kết quả OK/NG", Glyph = "💾")]
    public class ImageSaveTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Result (bool)", Source = Kind.Bool)] public string ResultLink { get; set; }
        [Param("Save", "Folder", Editor = Editor.Folder)] public string Folder { get; set; } = "D:\\VisionImages";
        [Param("Save", "Save when", Choices = "Always|NG only|OK only")] public string SaveWhen { get; set; } = "NG only";
        [Param("Save", "Format", Choices = "png|bmp|jpg|tiff")] public string Format { get; set; } = "png";
        [Param("Save", "Max files per folder", Min = 0)] public int MaxFiles { get; set; } = 5000;

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = RequireImage(ctx, InputImage);
            bool ok = true; if (!string.IsNullOrWhiteSpace(ResultLink)) ctx.TryGet(ResultLink, out ok);
            bool save = SaveWhen == "Always" || (SaveWhen == "NG only" && !ok) || (SaveWhen == "OK only" && ok);
            res.Ok = true;
            if (!save) { res.Message = "Skip save"; return; }
            string dir = Path.Combine(Folder, DateTime.Now.ToString("yyyyMMdd"), ok ? "OK" : "NG"); Directory.CreateDirectory(dir);
            string file = Path.Combine(dir, DateTime.Now.ToString("HHmmss_fff") + "_" + Name);
            HOperatorSet.WriteImage(img, Format, 0, file);
            if (MaxFiles > 0) { var fs = Directory.GetFiles(dir).OrderBy(f => f).ToList(); for (int i = 0; i < fs.Count - MaxFiles; i++) try { File.Delete(fs[i]); } catch { } }
            res.Message = Path.GetFileName(file);
        }
    }

    [Tool("Crop / Sub Image", "Image", Description = "Cắt ảnh theo ROI (có thể theo Fixture)", Glyph = "✂")]
    public class SubImageTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("ROI", "Region")] public Rect2Roi Roi { get; set; } = new Rect2Roi();
        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = RequireImage(ctx, InputImage);
            var roi = Roi.Transformed(GetFixture(ctx, FixtureLink));
            HObject rg = roi.ToRegion(), red = null, crop = null;
            try
            {
                red = HalconUtil.ReduceTo(img, rg);
                HOperatorSet.CropDomain(red, out crop);
                ctx.AddObj(rg, "yellow");
                Out(ctx, "Image", crop); crop = null; res.Ok = true;
            }
            finally { rg?.Dispose(); red?.Dispose(); crop?.Dispose(); }
        }
    }

    [Tool("Rotate / Mirror", "Image", Glyph = "⟳")]
    public class RotationTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Transform", "Mode", Choices = "Rotate 90|Rotate 180|Rotate 270|Mirror Horizontal|Mirror Vertical|Angle")] public string Mode { get; set; } = "Rotate 90";
        [Param("Transform", "Angle (deg)")] public double Angle { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = RequireImage(ctx, InputImage); HObject o;
            switch (Mode)
            {
                case "Rotate 90": HOperatorSet.RotateImage(img, out o, 90, "constant"); break;
                case "Rotate 180": HOperatorSet.RotateImage(img, out o, 180, "constant"); break;
                case "Rotate 270": HOperatorSet.RotateImage(img, out o, 270, "constant"); break;
                case "Mirror Horizontal": HOperatorSet.MirrorImage(img, out o, "column"); break;
                case "Mirror Vertical": HOperatorSet.MirrorImage(img, out o, "row"); break;
                default: HOperatorSet.RotateImage(img, out o, Angle, "constant"); break;
            }
            Out(ctx, "Image", o); res.Ok = true;
        }
    }

    [Tool("Color Convert", "Image", Glyph = "◐")]
    public class ConvertTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Convert", "Mode", Choices = "Gray|Red|Green|Blue|Hue|Saturation|Value|Invert|To byte")] public string Mode { get; set; } = "Gray";
        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = RequireImage(ctx, InputImage); HObject o = null;
            HOperatorSet.CountChannels(img, out HTuple ch);
            switch (Mode)
            {
                case "Gray": o = HalconUtil.ToGray(img); break;
                case "Invert": HOperatorSet.InvertImage(img, out o); break;
                case "To byte": HOperatorSet.ConvertImageType(img, out o, "byte"); break;
                case "Red": case "Green": case "Blue":
                    if (ch.I < 3) throw new InvalidOperationException("Ảnh không phải RGB");
                    HOperatorSet.Decompose3(img, out HObject r, out HObject g, out HObject b);
                    o = Mode == "Red" ? r : Mode == "Green" ? g : b;
                    if (o != r) r.Dispose(); if (o != g) g.Dispose(); if (o != b) b.Dispose(); break;
                default:
                    if (ch.I < 3) throw new InvalidOperationException("Ảnh không phải RGB");
                    HOperatorSet.Decompose3(img, out HObject r2, out HObject g2, out HObject b2);
                    HOperatorSet.TransFromRgb(r2, g2, b2, out HObject h, out HObject s, out HObject v, "hsv");
                    o = Mode == "Hue" ? h : Mode == "Saturation" ? s : v;
                    if (o != h) h.Dispose(); if (o != s) s.Dispose(); if (o != v) v.Dispose();
                    r2.Dispose(); g2.Dispose(); b2.Dispose(); break;
            }
            Out(ctx, "Image", o); res.Ok = true;
        }
    }

    [Tool("Blur / Filter", "Image", Glyph = "≋")]
    public class BlurTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Filter", "Type", Choices = "Gaussian|Median|Mean|Sobel edge|Emphasize")] public string Type { get; set; } = "Gaussian";
        [Param("Filter", "Size", Min = 1, Hint = "Gaussian: 3,5,7,9,11.. | Median/Mean/Emphasize: kích thước kernel")] public int Size { get; set; } = 5;
        [Param("Filter", "Emphasize factor")] public double Factor { get; set; } = 1.5;
        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = RequireImage(ctx, InputImage); HObject o;
            int k = Math.Max(1, Size); if (k % 2 == 0) k++;
            switch (Type)
            {
                case "Median": HOperatorSet.MedianImage(img, out o, "circle", Math.Max(1, k / 2), "mirrored"); break;
                case "Mean": HOperatorSet.MeanImage(img, out o, k, k); break;
                case "Sobel edge": HOperatorSet.SobelAmp(img, out o, "sum_abs", Math.Min(k, 11)); break;
                case "Emphasize": HOperatorSet.Emphasize(img, out o, k, k, Factor); break;
                default: HOperatorSet.GaussImage(img, out o, Math.Max(3, k)); break;
            }
            Out(ctx, "Image", o); res.Ok = true;
        }
    }

    [Tool("Contrast / Equalize", "Image", Glyph = "◑")]
    public class EqualizerTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Mode", "Type", Choices = "Histogram equalize|Scale max|Illuminate|Gain/Offset")] public string Type { get; set; } = "Histogram equalize";
        [Param("Mode", "Mask size", Min = 3)] public int Mask { get; set; } = 101;
        [Param("Mode", "Factor")] public double Factor { get; set; } = 0.7;
        [Param("Mode", "Gain")] public double Gain { get; set; } = 1.0;
        [Param("Mode", "Offset")] public double Offset { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = RequireImage(ctx, InputImage); HObject o;
            switch (Type)
            {
                case "Scale max": HOperatorSet.ScaleImageMax(img, out o); break;
                case "Illuminate": HOperatorSet.Illuminate(img, out o, Mask, Mask, Factor); break;
                case "Gain/Offset": HOperatorSet.ScaleImage(img, out o, Gain, Offset); break;
                default: HOperatorSet.EquHistoImage(img, out o); break;
            }
            Out(ctx, "Image", o); res.Ok = true;
        }
    }

    [Tool("Image Calculate", "Image", Glyph = "±")]
    public class ImageCalculateTool : ToolBase
    {
        [Param("Input", "Image A", Source = Kind.Image)] public string ImageA { get; set; }
        [Param("Input", "Image B", Source = Kind.Image)] public string ImageB { get; set; }
        [Param("Operation", "Op", Choices = "Add|Subtract|AbsDiff|Multiply|Min|Max")] public string Op { get; set; } = "AbsDiff";
        [Param("Operation", "Gain")] public double Mult { get; set; } = 1.0;
        [Param("Operation", "Offset")] public double Add { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var a = RequireImage(ctx, ImageA); var b = RequireImage(ctx, ImageB); HObject o;
            switch (Op)
            {
                case "Add": HOperatorSet.AddImage(a, b, out o, Mult, Add); break;
                case "Subtract": HOperatorSet.SubImage(a, b, out o, Mult, Add); break;
                case "Multiply": HOperatorSet.MultImage(a, b, out o, Mult, Add); break;
                case "Min": HOperatorSet.MinImage(a, b, out o); break;
                case "Max": HOperatorSet.MaxImage(a, b, out o); break;
                default: HOperatorSet.AbsDiffImage(a, b, out o, Mult); break;
            }
            Out(ctx, "Image", o); res.Ok = true;
        }
    }

    [Tool("Masking", "Image", Description = "Tô kín vùng (trong/ngoài ROI) bằng mức xám cố định", Glyph = "▦")]
    public class MaskingTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("Mask", "Region (ROI)")] public Rect2Roi Roi { get; set; } = new Rect2Roi();
        [Param("Mask", "Region input (overrides ROI)", Source = Kind.Region)] public string RegionLink { get; set; }
        [Param("Mask", "Fill outside (else inside)")] public bool FillOutside { get; set; }
        [Param("Mask", "Gray value", Min = 0, Max = 255)] public int Gray { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = RequireImage(ctx, InputImage);
            var regIn = ctx.Get<HObject>(RegionLink);
            HObject rg = HalconUtil.Valid(regIn) ? regIn.CopyObj(1, -1) : Roi.Transformed(GetFixture(ctx, FixtureLink)).ToRegion(), use = null, o = null, dom = null;
            try
            {
                if (FillOutside) { HOperatorSet.GetDomain(img, out dom); HOperatorSet.Difference(dom, rg, out use); } else use = rg;
                HOperatorSet.PaintRegion(use, img, out o, (double)Gray, "fill");
                Out(ctx, "Image", o); o = null; res.Ok = true;
            }
            finally { if (use != rg) use?.Dispose(); rg.Dispose(); dom?.Dispose(); o?.Dispose(); }
        }
    }

    [Tool("Perspective Warp", "Image", Description = "Nắn phối cảnh từ 4 điểm (TL,TR,BR,BL) về hình chữ nhật", Glyph = "⬓")]
    public class WarpingTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "4 points (TL,TR,BR,BL)", Source = Kind.Points)] public string SrcPoints { get; set; }
        [Param("Output", "Width", Min = 2)] public int OutW { get; set; } = 800;
        [Param("Output", "Height", Min = 2)] public int OutH { get; set; } = 600;
        public override IEnumerable<Port> Ports { get { yield return new Port("Image", Kind.Image); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = RequireImage(ctx, InputImage);
            var pts = ctx.Get<List<Pt>>(SrcPoints);
            if (pts == null || pts.Count < 4) throw new InvalidOperationException("Cần 4 điểm nguồn");
            // Quy ước Halcon 2D: x = row, y = column.
            var px = new HTuple(pts.Take(4).Select(p => p.Y).ToArray()); var py = new HTuple(pts.Take(4).Select(p => p.X).ToArray());
            var qx = new HTuple(new double[] { 0, 0, OutH - 1, OutH - 1 }); var qy = new HTuple(new double[] { 0, OutW - 1, OutW - 1, 0 });
            HOperatorSet.VectorToProjHomMat2d(px, py, qx, qy, "normalized_dlt", new HTuple(), new HTuple(), new HTuple(), new HTuple(), new HTuple(), new HTuple(), out HTuple hom, out HTuple cov);
            HOperatorSet.ProjectiveTransImage(img, out HObject t, hom, "bilinear", "false", "false");
            HOperatorSet.CropRectangle1(t, out HObject c, 0, 0, OutH - 1, OutW - 1); t.Dispose();
            Out(ctx, "Image", c); res.Ok = true;
        }
    }

    [Tool("Histogram / Stats", "Image", Glyph = "▥")]
    public class HistogramTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("ROI", "Region")] public Rect2Roi Roi { get; set; } = new Rect2Roi();
        [Param("Spec", "Mean min")] public double MeanMin { get; set; }
        [Param("Spec", "Mean max")] public double MeanMax { get; set; } = 255;
        public override IEnumerable<Port> Ports { get { yield return new Port("Mean", Kind.Number); yield return new Port("Deviation", Kind.Number); yield return new Port("Min", Kind.Number); yield return new Port("Max", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = HalconUtil.ToGray(RequireImage(ctx, InputImage));
            HObject rg = Roi.Transformed(GetFixture(ctx, FixtureLink)).ToRegion();
            try
            {
                HOperatorSet.Intensity(rg, img, out HTuple mean, out HTuple dev);
                HOperatorSet.MinMaxGray(rg, img, 0, out HTuple mn, out HTuple mx, out HTuple range);
                Out(ctx, "Mean", mean.D); Out(ctx, "Deviation", dev.D); Out(ctx, "Min", mn.D); Out(ctx, "Max", mx.D);
                ctx.AddObj(rg, "yellow"); res.Ok = mean.D >= MeanMin && mean.D <= MeanMax;
                res.Message = $"mean={mean.D:0.#} dev={dev.D:0.#}"; ctx.Report_(Name, "Mean", mean.D);
            }
            finally { rg.Dispose(); img.Dispose(); }
        }
    }

    [Tool("Sharpness", "Image", Description = "Đo độ nét (Tenengrad) trong ROI", Glyph = "◎")]
    public class SharpnessTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("ROI", "Region")] public Rect2Roi Roi { get; set; } = new Rect2Roi();
        [Param("Spec", "Min score")] public double MinScore { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Score", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var img = HalconUtil.ToGray(RequireImage(ctx, InputImage));
            HObject rg = Roi.ToRegion(); HObject sob = null;
            try
            {
                HOperatorSet.SobelAmp(img, out sob, "sum_abs", 3);
                HOperatorSet.Intensity(rg, sob, out HTuple mean, out HTuple dev);
                Out(ctx, "Score", mean.D); res.Ok = mean.D >= MinScore; res.Message = "score=" + Cal.F(mean.D);
                ctx.AddObj(rg, "yellow"); ctx.Report_(Name, "Score", mean.D);
            }
            finally { rg.Dispose(); sob?.Dispose(); img.Dispose(); }
        }
    }
}
