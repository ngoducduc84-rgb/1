using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using HalconDotNet;
using Newtonsoft.Json;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Geometry;
using VisionStudio.Core.Halcon;

namespace VisionStudio.Core.Tools
{
    [Tool("Shape / NCC Match", "Locate", Description = "Tìm mẫu: Shape model (Standard/Scaled/Aniso) hoặc NCC. Xuất Fixture, điểm, góc, score", Glyph = "◈")]
    public class ShapeMatchTool : ToolBase, IToolAction
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture (search ROI)", Source = Kind.Fixture)] public string FixtureLink { get; set; }

        [Param("Template", "Mode", Choices = "Standard|Scaled|Aniso|NCC")] public string Mode { get; set; } = "Standard";
        [Param("Template", "Template ROI")] public Rect2Roi TemplateRoi { get; set; } = new Rect2Roi { Row = 250, Col = 250, Len1 = 80, Len2 = 80 };
        [Param("Template", "Num levels (auto|n)")] public string NumLevels { get; set; } = "auto";
        [Param("Template", "Contrast (auto|n)")] public string Contrast { get; set; } = "auto";
        [Param("Template", "Min contrast (auto|n)")] public string MinContrast { get; set; } = "auto";

        [Param("Search", "Use search ROI")] public bool UseSearchRoi { get; set; }
        [Param("Search", "Search ROI")] public Rect2Roi SearchRoi { get; set; } = new Rect2Roi { Row = 300, Col = 400, Len1 = 300, Len2 = 250 };
        [Param("Search", "Angle start (deg)")] public double AngleStart { get; set; } = -30;
        [Param("Search", "Angle extent (deg)")] public double AngleExtent { get; set; } = 60;
        [Param("Search", "Scale min")] public double ScaleMin { get; set; } = 0.9;
        [Param("Search", "Scale max")] public double ScaleMax { get; set; } = 1.1;
        [Param("Search", "Min score", Min = 0, Max = 1)] public double MinScore { get; set; } = 0.7;
        [Param("Search", "Max matches", Min = 1)] public int MaxMatches { get; set; } = 1;
        [Param("Search", "Max overlap", Min = 0, Max = 1)] public double MaxOverlap { get; set; } = 0.5;
        [Param("Search", "Greediness", Min = 0, Max = 1)] public double Greediness { get; set; } = 0.9;
        [Param("Search", "Sub-pixel", Choices = "none|interpolation|least_squares|least_squares_high")] public string SubPixel { get; set; } = "least_squares";

        public string ModelFile { get; set; }
        public double RefRow { get; set; }
        public double RefCol { get; set; }
        public double RefAngle { get; set; }
        public string TrainedMode { get; set; }

        [JsonIgnore] HTuple _model; [JsonIgnore] HObject _contours;
        [JsonIgnore] public string ActionName => "Train template";

        public override IEnumerable<Port> Ports
        {
            get
            {
                yield return new Port("Fixture", Kind.Fixture); yield return new Port("Point", Kind.Point); yield return new Port("Pose", Kind.Pose);
                yield return new Port("Angle", Kind.Number); yield return new Port("Score", Kind.Number); yield return new Port("Count", Kind.Number);
                yield return new Port("Points", Kind.Points); yield return new Port("Scale", Kind.Number);
            }
        }

        static HTuple AutoOr(string s, bool isInt)
        {
            if (string.IsNullOrWhiteSpace(s) || s.Trim().ToLower() == "auto") return new HTuple("auto");
            double d = double.Parse(s, CultureInfo.InvariantCulture); return isInt ? new HTuple((int)d) : new HTuple(d);
        }

        void ClearModel()
        {
            if (_model != null) { try { if (TrainedMode == "NCC") HOperatorSet.ClearNccModel(_model); else HOperatorSet.ClearShapeModel(_model); } catch { } _model = null; }
            _contours?.Dispose(); _contours = null;
        }

        string ModelPath(RunContext ctx) => Path.Combine(ctx.Project != null ? ctx.Project.ModelDir : AppDomain.CurrentDomain.BaseDirectory, Name + (Mode == "NCC" ? ".ncm" : ".shm"));

        public string DoAction(RunContext ctx)
        {
            var src = RequireImage(ctx, InputImage);
            HObject gray = HalconUtil.ToGray(src), rg = TemplateRoi.ToRegion(), red = null;
            try
            {
                red = HalconUtil.ReduceTo(gray, rg);
                ClearModel();
                double a0 = AngleStart * GeoMath.D2R, ae = AngleExtent * GeoMath.D2R;
                HTuple nl = AutoOr(NumLevels, true), ct = AutoOr(Contrast, false), mc = AutoOr(MinContrast, false);
                switch (Mode)
                {
                    case "NCC": HOperatorSet.CreateNccModel(red, nl, a0, ae, "auto", "use_polarity", out _model); break;
                    case "Scaled": HOperatorSet.CreateScaledShapeModel(red, nl, a0, ae, "auto", ScaleMin, ScaleMax, "auto", "auto", "use_polarity", ct, mc, out _model); break;
                    case "Aniso": HOperatorSet.CreateAnisoShapeModel(red, nl, a0, ae, "auto", ScaleMin, ScaleMax, "auto", ScaleMin, ScaleMax, "auto", "auto", "use_polarity", ct, mc, out _model); break;
                    default: HOperatorSet.CreateShapeModel(red, nl, a0, ae, "auto", "auto", "use_polarity", ct, mc, out _model); break;
                }
                TrainedMode = Mode;
                string path = ModelPath(ctx);
                if (Mode == "NCC") HOperatorSet.WriteNccModel(_model, path); else HOperatorSet.WriteShapeModel(_model, path);
                ModelFile = Path.GetFileName(path);

                // pose tham chiếu: tìm lại ngay trên ảnh train
                RefRow = TemplateRoi.Row; RefCol = TemplateRoi.Col; RefAngle = 0;
                var m = FindAll(gray, null, 0.5, 1);
                if (m.Count > 0) { RefRow = m[0].Row; RefCol = m[0].Col; RefAngle = m[0].AngleDeg; }
                return $"Đã train ({Mode}). Ref = ({RefRow:0.##}, {RefCol:0.##}, {RefAngle:0.##}°)";
            }
            finally { gray.Dispose(); rg.Dispose(); red?.Dispose(); }
        }

        class Match { public double Row, Col, AngleDeg, Score, ScaleR = 1, ScaleC = 1; }

        List<Match> FindAll(HObject gray, HObject searchRegion, double minScore, int maxMatches)
        {
            HObject use = gray, reduced = null; var list = new List<Match>();
            try
            {
                if (searchRegion != null) { reduced = HalconUtil.ReduceTo(gray, searchRegion); use = reduced; }
                double a0 = AngleStart * GeoMath.D2R, ae = AngleExtent * GeoMath.D2R;
                HTuple row, col, ang, score, s1 = null, s2 = null;
                switch (TrainedMode ?? Mode)
                {
                    case "NCC":
                        HOperatorSet.FindNccModel(use, _model, a0, ae, minScore, maxMatches, MaxOverlap, "true", 0, out row, out col, out ang, out score); break;
                    case "Scaled":
                        HOperatorSet.FindScaledShapeModel(use, _model, a0, ae, ScaleMin, ScaleMax, minScore, maxMatches, MaxOverlap, SubPixel, 0, Greediness, out row, out col, out ang, out s1, out score); break;
                    case "Aniso":
                        HOperatorSet.FindAnisoShapeModel(use, _model, a0, ae, ScaleMin, ScaleMax, ScaleMin, ScaleMax, minScore, maxMatches, MaxOverlap, SubPixel, 0, Greediness, out row, out col, out ang, out s1, out s2, out score); break;
                    default:
                        HOperatorSet.FindShapeModel(use, _model, a0, ae, minScore, maxMatches, MaxOverlap, SubPixel, 0, Greediness, out row, out col, out ang, out score); break;
                }
                for (int i = 0; i < row.Length; i++)
                    list.Add(new Match
                    {
                        Row = row[i].D, Col = col[i].D, AngleDeg = ang[i].D * GeoMath.R2D, Score = score[i].D,
                        ScaleR = s1 != null ? s1[i].D : 1, ScaleC = s2 != null ? s2[i].D : (s1 != null ? s1[i].D : 1)
                    });
            }
            finally { reduced?.Dispose(); }
            return list;
        }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            if (_model == null)
            {
                string path = string.IsNullOrEmpty(ModelFile) ? null : ModelPath(ctx);
                if (path == null || !File.Exists(path)) throw new InvalidOperationException("Chưa train mẫu (bấm 'Train template')");
                if (TrainedMode == "NCC") HOperatorSet.ReadNccModel(path, out _model); else HOperatorSet.ReadShapeModel(path, out _model);
            }
            var img = RequireImage(ctx, InputImage); HObject gray = HalconUtil.ToGray(img), sr = null;
            try
            {
                if (UseSearchRoi) { sr = SearchRoi.Transformed(GetFixture(ctx, FixtureLink)).ToRegion(); ctx.AddObj(sr, "blue"); }
                var ms = FindAll(gray, sr, MinScore, MaxMatches);
                Out(ctx, "Count", (double)ms.Count);
                res.Ok = ms.Count > 0;
                if (ms.Count == 0) { res.Message = "Không tìm thấy"; return; }

                if (_contours == null && (TrainedMode ?? Mode) != "NCC")
                    HOperatorSet.GetShapeModelContours(out _contours, _model, 1);
                foreach (var m in ms)
                {
                    if (_contours != null)
                    {
                        HOperatorSet.HomMat2dIdentity(out HTuple h1);
                        HOperatorSet.HomMat2dScale(h1, m.ScaleR, m.ScaleC, 0, 0, out HTuple h2);
                        HOperatorSet.HomMat2dRotate(h2, m.AngleDeg * GeoMath.D2R, 0, 0, out HTuple h3);
                        HOperatorSet.HomMat2dTranslate(h3, m.Row, m.Col, out HTuple h4);
                        HOperatorSet.AffineTransContourXld(_contours, out HObject tc, h4);
                        ctx.AddObj(tc, "green"); tc.Dispose();
                    }
                    ctx.AddCross(m.Row, m.Col, 25, m.AngleDeg, "red");
                }
                var f = ms[0];
                ctx.AddText(f.Row - 40, f.Col - 40, $"{f.Score:0.00}  {f.AngleDeg:0.0}°", "yellow");
                Out(ctx, "Fixture", new FixtureData { R0 = RefRow, C0 = RefCol, A0 = RefAngle, R1 = f.Row, C1 = f.Col, A1 = f.AngleDeg });
                Out(ctx, "Point", new Pt(f.Col, f.Row)); Out(ctx, "Pose", new Xyt(f.Col, f.Row, f.AngleDeg));
                Out(ctx, "Angle", f.AngleDeg); Out(ctx, "Score", f.Score); Out(ctx, "Scale", f.ScaleR);
                Out(ctx, "Points", ms.Select(m => new Pt(m.Col, m.Row)).ToList());
                res.Message = $"{ms.Count} match, score={f.Score:0.000}";
                ctx.Report_(Name, "Score", f.Score); ctx.Report_(Name, "X", f.Col); ctx.Report_(Name, "Y", f.Row); ctx.Report_(Name, "Angle", f.AngleDeg);
            }
            finally { gray.Dispose(); sr?.Dispose(); }
        }
    }

    [Tool("Blob", "Locate", Description = "Threshold → blob → lọc đặc trưng. Xuất số lượng, diện tích, tâm, hộp bao (bounding/min-area box)", Glyph = "⬤")]
    public class BlobTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("ROI", "Use ROI")] public bool UseRoi { get; set; } = true;
        [Param("ROI", "Region")] public Rect2Roi Roi { get; set; } = new Rect2Roi();

        [Param("Threshold", "Mode", Choices = "Fixed|Auto (Otsu)|Dynamic")] public string ThresholdMode { get; set; } = "Fixed";
        [Param("Threshold", "Polarity", Choices = "Light|Dark")] public string Polarity { get; set; } = "Light";
        [Param("Threshold", "Min gray", Min = 0, Max = 255)] public int MinGray { get; set; } = 128;
        [Param("Threshold", "Max gray", Min = 0, Max = 255)] public int MaxGray { get; set; } = 255;
        [Param("Threshold", "Dynamic mask size", Min = 3)] public int DynSize { get; set; } = 31;
        [Param("Threshold", "Dynamic offset")] public double DynOffset { get; set; } = 10;

        [Param("Morphology", "Open radius", Min = 0)] public double OpenR { get; set; }
        [Param("Morphology", "Close radius", Min = 0)] public double CloseR { get; set; }
        [Param("Morphology", "Fill holes")] public bool FillHoles { get; set; }

        [Param("Filter", "Min area", Min = 0)] public double MinArea { get; set; } = 100;
        [Param("Filter", "Max area", Min = 0)] public double MaxArea { get; set; } = 9999999;
        [Param("Filter", "Extra feature", Choices = "none|circularity|rectangularity|compactness|width|height|ra|rb|anisometry")] public string Feature { get; set; } = "none";
        [Param("Filter", "Feature min")] public double FeatMin { get; set; }
        [Param("Filter", "Feature max")] public double FeatMax { get; set; } = 1e9;

        [Param("Spec", "Min count")] public int MinCount { get; set; } = 1;
        [Param("Spec", "Max count")] public int MaxCount { get; set; } = 9999;
        [Param("Spec", "Box type", Choices = "MinArea (rotated)|Axis aligned")] public string BoxType { get; set; } = "MinArea (rotated)";

        public override IEnumerable<Port> Ports
        {
            get
            {
                yield return new Port("Count", Kind.Number); yield return new Port("Area", Kind.Number); yield return new Port("TotalArea", Kind.Number);
                yield return new Port("Center", Kind.Point); yield return new Port("Points", Kind.Points); yield return new Port("Region", Kind.Region);
                yield return new Port("Pose", Kind.Pose); yield return new Port("Length", Kind.Number); yield return new Port("Width", Kind.Number);
            }
        }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            HObject gray = HalconUtil.ToGray(RequireImage(ctx, InputImage));
            HObject roiRg = null, work = gray, mean = null, reg = null, tmp = null, conn = null, sel = null;
            try
            {
                if (UseRoi) { roiRg = Roi.Transformed(GetFixture(ctx, FixtureLink)).ToRegion(); work = HalconUtil.ReduceTo(gray, roiRg); ctx.AddObj(roiRg, "yellow"); }
                string pol = Polarity == "Dark" ? "dark" : "light";
                switch (ThresholdMode)
                {
                    case "Auto (Otsu)": HOperatorSet.BinaryThreshold(work, out reg, "max_separability", pol, out HTuple used); break;
                    case "Dynamic":
                        HOperatorSet.MeanImage(work, out mean, DynSize, DynSize); HOperatorSet.DynThreshold(work, mean, out reg, DynOffset, pol); break;
                    default: HOperatorSet.Threshold(work, out reg, MinGray, MaxGray); break;
                }
                if (OpenR > 0) { HOperatorSet.OpeningCircle(reg, out tmp, OpenR); reg.Dispose(); reg = tmp; tmp = null; }
                if (CloseR > 0) { HOperatorSet.ClosingCircle(reg, out tmp, CloseR); reg.Dispose(); reg = tmp; tmp = null; }
                if (FillHoles) { HOperatorSet.FillUp(reg, out tmp); reg.Dispose(); reg = tmp; tmp = null; }
                HOperatorSet.Connection(reg, out conn);
                if (Feature != "none")
                    HOperatorSet.SelectShape(conn, out sel, HalconUtil.Tup("area", Feature), "and", HalconUtil.Tup(MinArea, FeatMin), HalconUtil.Tup(MaxArea, FeatMax));
                else HOperatorSet.SelectShape(conn, out sel, "area", "and", MinArea, MaxArea);

                int n = HalconUtil.Count(sel);
                Out(ctx, "Count", (double)n);
                res.Ok = n >= MinCount && n <= MaxCount; res.Message = "count=" + n;
                ctx.Report_(Name, "Count", n);
                if (n == 0) { return; }

                HOperatorSet.AreaCenter(sel, out HTuple area, out HTuple row, out HTuple col);
                int big = 0; double tot = 0; for (int i = 0; i < n; i++) { tot += area[i].D; if (area[i].D > area[big].D) big = i; }
                Out(ctx, "Area", area[big].D); Out(ctx, "TotalArea", tot);
                Out(ctx, "Center", new Pt(col[big].D, row[big].D));
                Out(ctx, "Points", Enumerable.Range(0, n).Select(i => new Pt(col[i].D, row[i].D)).ToList());
                ctx.Report_(Name, "Area", area[big].D);

                HOperatorSet.SelectObj(sel, out HObject one, big + 1);
                try
                {
                    if (BoxType.StartsWith("MinArea"))
                    {
                        HOperatorSet.SmallestRectangle2(one, out HTuple r, out HTuple c, out HTuple phi, out HTuple l1, out HTuple l2);
                        Out(ctx, "Pose", new Xyt(c.D, r.D, phi.D * GeoMath.R2D)); Out(ctx, "Length", 2 * l1.D); Out(ctx, "Width", 2 * l2.D);
                        HOperatorSet.GenRectangle2ContourXld(out HObject box, r, c, phi, l1, l2); ctx.AddObj(box, "cyan"); box.Dispose();
                    }
                    else
                    {
                        HOperatorSet.SmallestRectangle1(one, out HTuple r1, out HTuple c1, out HTuple r2, out HTuple c2);
                        Out(ctx, "Pose", new Xyt((c1.D + c2.D) / 2, (r1.D + r2.D) / 2, 0)); Out(ctx, "Length", c2.D - c1.D); Out(ctx, "Width", r2.D - r1.D);
                        HOperatorSet.GenRectangle1(out HObject rc, r1, c1, r2, c2); HOperatorSet.GenContourRegionXld(rc, out HObject cont, "border"); ctx.AddObj(cont, "cyan"); rc.Dispose(); cont.Dispose();
                    }
                }
                finally { one.Dispose(); }
                ctx.AddObj(sel, "green", false);
                for (int i = 0; i < n; i++) ctx.AddCross(row[i].D, col[i].D, 10, 0, "red");
                Out(ctx, "Region", sel); sel = null;     // ctx sở hữu
            }
            finally
            {
                if (work != gray) work?.Dispose(); gray.Dispose(); roiRg?.Dispose(); mean?.Dispose(); reg?.Dispose(); tmp?.Dispose(); conn?.Dispose(); sel?.Dispose();
            }
        }
    }

    [Tool("Variation Inspect", "Locate", Description = "So sánh với ảnh chuẩn (Halcon variation model). Train bằng thư mục ảnh tốt đã căn chỉnh", Glyph = "≠")]
    public class VariationInspectTool : ToolBase, IToolAction
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Train", "Good images folder", Editor = Editor.Folder)] public string TrainFolder { get; set; }
        [Param("Train", "Abs threshold", Min = 0)] public double AbsThr { get; set; } = 15;
        [Param("Train", "Var threshold", Min = 0)] public double VarThr { get; set; } = 3;
        [Param("Inspect", "Min defect area", Min = 0)] public double MinDefect { get; set; } = 30;
        [Param("Inspect", "Max defects (OK if ≤)")] public int MaxDefects { get; set; } = 0;
        public string ModelFile { get; set; }
        [JsonIgnore] HTuple _vm;
        [JsonIgnore] public string ActionName => "Train from folder";
        public override IEnumerable<Port> Ports { get { yield return new Port("Count", Kind.Number); yield return new Port("Region", Kind.Region); yield return new Port("Area", Kind.Number); } }

        string Path_(RunContext ctx) => Path.Combine(ctx.Project != null ? ctx.Project.ModelDir : AppDomain.CurrentDomain.BaseDirectory, Name + ".var");

        public string DoAction(RunContext ctx)
        {
            if (!Directory.Exists(TrainFolder ?? "")) throw new DirectoryNotFoundException("Chọn thư mục ảnh tốt");
            var files = Directory.GetFiles(TrainFolder).Where(f => new[] { ".bmp", ".png", ".jpg", ".tif", ".tiff" }.Contains(System.IO.Path.GetExtension(f).ToLower())).ToArray();
            if (files.Length < 2) throw new InvalidOperationException("Cần ≥ 2 ảnh tốt");
            if (_vm != null) { try { HOperatorSet.ClearVariationModel(_vm); } catch { } _vm = null; }
            for (int i = 0; i < files.Length; i++)
            {
                HObject raw = ImageIo.Read(files[i]); HObject g = HalconUtil.ToGray(raw); raw.Dispose();
                if (i == 0) { ImageSize(g, out int w, out int h); HOperatorSet.CreateVariationModel(w, h, "byte", "direct", out _vm); }
                HOperatorSet.TrainVariationModel(g, _vm); g.Dispose();
            }
            HOperatorSet.PrepareVariationModel(_vm, AbsThr, VarThr);
            string p = Path_(ctx); HOperatorSet.WriteVariationModel(_vm, p); ModelFile = System.IO.Path.GetFileName(p);
            return $"Đã train {files.Length} ảnh";
        }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            if (_vm == null)
            {
                string p = string.IsNullOrEmpty(ModelFile) ? null : Path_(ctx);
                if (p == null || !File.Exists(p)) throw new InvalidOperationException("Chưa train variation model");
                HOperatorSet.ReadVariationModel(p, out _vm);
            }
            HObject g = HalconUtil.ToGray(RequireImage(ctx, InputImage)), diff = null, conn = null, sel = null;
            try
            {
                HOperatorSet.CompareVariationModel(g, out diff, _vm);
                HOperatorSet.Connection(diff, out conn);
                HOperatorSet.SelectShape(conn, out sel, "area", "and", MinDefect, 9999999);
                int n = HalconUtil.Count(sel); Out(ctx, "Count", (double)n);
                double tot = 0; if (n > 0) { HOperatorSet.AreaCenter(sel, out HTuple a, out HTuple r, out HTuple c); tot = a.TupleSum().D; }
                Out(ctx, "Area", tot);
                ctx.AddObj(sel, "red", true); Out(ctx, "Region", sel); sel = null;
                res.Ok = n <= MaxDefects; res.Message = "defects=" + n; ctx.Report_(Name, "Defects", n);
            }
            finally { g.Dispose(); diff?.Dispose(); conn?.Dispose(); sel?.Dispose(); }
        }
    }

    [Tool("Barcode / DataCode", "Locate", Description = "Đọc 1D barcode và 2D code (DataMatrix, QR, PDF417, Aztec)", Glyph = "▌▌")]
    public class BarcodeTool : ToolBase
    {
        [Param("Input", "Image", Source = Kind.Image)] public string InputImage { get; set; }
        [Param("Code", "Type", Choices = "1D auto|Code 128|Code 39|EAN-13|EAN-8|UPC-A|Codabar|2/5 Interleaved|Data Matrix ECC 200|QR Code|PDF417|Aztec Code")] public string CodeType { get; set; } = "Data Matrix ECC 200";
        [Param("Code", "Enhanced recognition")] public bool Enhanced { get; set; } = true;
        [Param("ROI", "Use ROI")] public bool UseRoi { get; set; }
        [Param("ROI", "Region")] public Rect2Roi Roi { get; set; } = new Rect2Roi();
        [Param("Spec", "Expected text (blank = any)")] public string Expected { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Text", Kind.Text); yield return new Port("Count", Kind.Number); } }

        static readonly string[] OneD = { "1D auto", "Code 128", "Code 39", "EAN-13", "EAN-8", "UPC-A", "Codabar", "2/5 Interleaved" };

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            HObject gray = HalconUtil.ToGray(RequireImage(ctx, InputImage)), work = gray, rg = null, symbols = null;
            try
            {
                if (UseRoi) { rg = Roi.ToRegion(); work = HalconUtil.ReduceTo(gray, rg); ctx.AddObj(rg, "yellow"); }
                HTuple decoded;
                if (OneD.Contains(CodeType))
                {
                    HOperatorSet.CreateBarCodeModel(new HTuple(), new HTuple(), out HTuple bh);
                    try { HOperatorSet.FindBarCode(work, out symbols, bh, CodeType == "1D auto" ? "auto" : CodeType, out decoded); }
                    finally { HOperatorSet.ClearBarCodeModel(bh); }
                }
                else
                {
                    HOperatorSet.CreateDataCode2dModel(CodeType, "default_parameters", Enhanced ? "enhanced_recognition" : "standard_recognition", out HTuple dh);
                    try { HOperatorSet.FindDataCode2d(work, out symbols, dh, new HTuple(), new HTuple(), out HTuple rh, out decoded); }
                    finally { HOperatorSet.ClearDataCode2dModel(dh); }
                }
                int n = decoded.Length; string text = n > 0 ? decoded[0].S : "";
                Out(ctx, "Text", text); Out(ctx, "Count", (double)n);
                if (HalconUtil.Valid(symbols)) ctx.AddObj(symbols, "green");
                res.Ok = n > 0 && (string.IsNullOrEmpty(Expected) || text == Expected);
                res.Message = n > 0 ? text : "Không đọc được"; ctx.Report_(Name, "Text", text);
            }
            finally { if (work != gray) work?.Dispose(); gray.Dispose(); rg?.Dispose(); symbols?.Dispose(); }
        }
    }
}
