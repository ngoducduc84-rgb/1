using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using VisionStudio.Core.Comm;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Geometry;
using VisionStudio.Core.Halcon;

namespace VisionStudio.Core.Tools
{
    [Tool("Judgement", "Logic", Description = "Gộp tối đa 4 giá trị số với ngưỡng Min/Max → OK/NG", Glyph = "⚖")]
    public class JudgementTool : ToolBase
    {
        [Param("Value 1", "Link", Source = Kind.Number)] public string V1 { get; set; }
        [Param("Value 1", "Min")] public double Min1 { get; set; } = double.MinValue / 2;
        [Param("Value 1", "Max")] public double Max1 { get; set; } = double.MaxValue / 2;
        [Param("Value 2", "Link", Source = Kind.Number)] public string V2 { get; set; }
        [Param("Value 2", "Min")] public double Min2 { get; set; } = double.MinValue / 2;
        [Param("Value 2", "Max")] public double Max2 { get; set; } = double.MaxValue / 2;
        [Param("Value 3", "Link", Source = Kind.Number)] public string V3 { get; set; }
        [Param("Value 3", "Min")] public double Min3 { get; set; } = double.MinValue / 2;
        [Param("Value 3", "Max")] public double Max3 { get; set; } = double.MaxValue / 2;
        [Param("Value 4", "Link", Source = Kind.Number)] public string V4 { get; set; }
        [Param("Value 4", "Min")] public double Min4 { get; set; } = double.MinValue / 2;
        [Param("Value 4", "Max")] public double Max4 { get; set; } = double.MaxValue / 2;
        [Param("Combine", "Also require bool", Source = Kind.Bool)] public string BoolLink { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Result", Kind.Bool); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            bool ok = true; var sb = new StringBuilder();
            void Chk(string link, double mn, double mx, int i)
            {
                if (string.IsNullOrWhiteSpace(link)) return;
                if (!ctx.TryGet(link, out double v)) { ok = false; sb.Append($" V{i}:missing"); return; }
                bool g = v >= mn && v <= mx; ok &= g; sb.Append($" V{i}={Cal.F(v)}{(g ? "" : "✗")}");
            }
            Chk(V1, Min1, Max1, 1); Chk(V2, Min2, Max2, 2); Chk(V3, Min3, Max3, 3); Chk(V4, Min4, Max4, 4);
            if (!string.IsNullOrWhiteSpace(BoolLink)) { ctx.TryGet(BoolLink, out bool b); ok &= b; }
            Out(ctx, "Result", ok); res.Ok = ok; res.Message = sb.ToString().Trim();
        }
    }

    [Tool("Merge / Logic", "Logic", Description = "AND / OR / NOT các bool, hoặc chọn giá trị hợp lệ đầu tiên (fallback)", Glyph = "⋔")]
    public class MergeTool : ToolBase
    {
        [Param("Mode", "Operation", Choices = "AND|OR|NOT (A)|Select first valid")] public string Op { get; set; } = "AND";
        [Param("Input", "A", Source = Kind.Any)] public string A { get; set; }
        [Param("Input", "B", Source = Kind.Any)] public string B { get; set; }
        [Param("Input", "C", Source = Kind.Any)] public string C { get; set; }
        [Param("Input", "D", Source = Kind.Any)] public string D { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Result", Kind.Bool); yield return new Port("Value", Kind.Any); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var links = new[] { A, B, C, D }.Where(l => !string.IsNullOrWhiteSpace(l)).ToList();
            if (Op == "Select first valid")
            {
                foreach (var l in links) if (ctx.Values.TryGetValue(l.Trim(), out object v)) { Out(ctx, "Value", v); Out(ctx, "Result", true); res.Ok = true; res.Message = "from " + l; return; }
                Out(ctx, "Result", false); res.Ok = false; res.Message = "không có giá trị hợp lệ"; return;
            }
            var bs = links.Select(l => ctx.TryGet(l, out bool b) && b).ToList(); bool r;
            if (Op == "NOT (A)") r = !(bs.Count > 0 && bs[0]);
            else if (Op == "OR") r = bs.Any(x => x);
            else r = bs.Count > 0 && bs.All(x => x);
            Out(ctx, "Result", r); res.Ok = r; res.Message = Op + " = " + r;
        }
    }

    [Tool("Result Analysis", "Logic", Description = "Đếm OK/NG và tỷ lệ yield", Glyph = "Σ")]
    public class ResultAnalysisTool : ToolBase, IToolAction
    {
        [Param("Input", "Result (bool)", Source = Kind.Bool)] public string ResultLink { get; set; }
        [JsonIgnore] public int Total { get; set; }
        [JsonIgnore] public int OkCount { get; set; }
        [JsonIgnore] public string ActionName => "Reset counters";
        public override IEnumerable<Port> Ports { get { yield return new Port("Total", Kind.Number); yield return new Port("OKCount", Kind.Number); yield return new Port("NGCount", Kind.Number); yield return new Port("Yield", Kind.Number); } }
        public string DoAction(RunContext ctx) { Total = 0; OkCount = 0; return "Đã reset"; }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            ctx.TryGet(ResultLink, out bool ok); Total++; if (ok) OkCount++;
            double y = Total > 0 ? 100.0 * OkCount / Total : 0;
            Out(ctx, "Total", (double)Total); Out(ctx, "OKCount", (double)OkCount); Out(ctx, "NGCount", (double)(Total - OkCount)); Out(ctx, "Yield", y);
            res.Ok = true; res.Message = $"{OkCount}/{Total} yield={y:0.##}%";
        }
    }

    [Tool("Data Log (CSV)", "Logic", Description = "Ghi tối đa 6 giá trị ra file CSV theo ngày", Glyph = "📝")]
    public class DataLogTool : ToolBase
    {
        [Param("Log", "Folder", Editor = Editor.Folder)] public string Folder { get; set; } = "D:\\VisionLog";
        [Param("Log", "Result (bool)", Source = Kind.Bool)] public string ResultLink { get; set; }
        [Param("Log", "Value 1", Source = Kind.Any)] public string V1 { get; set; }
        [Param("Log", "Value 2", Source = Kind.Any)] public string V2 { get; set; }
        [Param("Log", "Value 3", Source = Kind.Any)] public string V3 { get; set; }
        [Param("Log", "Value 4", Source = Kind.Any)] public string V4 { get; set; }
        [Param("Log", "Value 5", Source = Kind.Any)] public string V5 { get; set; }
        [Param("Log", "Value 6", Source = Kind.Any)] public string V6 { get; set; }
        static readonly object Lk = new object();

        public static string Fmt(object o)
        {
            if (o == null) return "";
            if (o is double d) return d.ToString("0.####", CultureInfo.InvariantCulture);
            if (o is Pt p) return $"{p.X:0.###};{p.Y:0.###}";
            if (o is Xyt x) return $"{x.X:0.###};{x.Y:0.###};{x.T:0.###}";
            if (o is bool b) return b ? "OK" : "NG";
            return Convert.ToString(o, CultureInfo.InvariantCulture);
        }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            Directory.CreateDirectory(Folder);
            string file = Path.Combine(Folder, DateTime.Now.ToString("yyyyMMdd") + ".csv");
            var links = new[] { V1, V2, V3, V4, V5, V6 }.Where(l => !string.IsNullOrWhiteSpace(l)).ToList();
            bool ok = true; if (!string.IsNullOrWhiteSpace(ResultLink)) ctx.TryGet(ResultLink, out ok);
            var cols = new List<string> { DateTime.Now.ToString("HH:mm:ss.fff"), ok ? "OK" : "NG" };
            cols.AddRange(links.Select(l => ctx.Values.TryGetValue(l.Trim(), out object v) ? Fmt(v) : ""));
            lock (Lk)
            {
                bool head = !File.Exists(file);
                using (var sw = new StreamWriter(file, true, Encoding.UTF8))
                {
                    if (head) sw.WriteLine("Time,Result," + string.Join(",", links));
                    sw.WriteLine(string.Join(",", cols));
                }
            }
            res.Ok = true; res.Message = Path.GetFileName(file);
        }
    }

    [Tool("Send (Comm)", "Comm", Description = "Gửi chuỗi kết quả qua TCP / Modbus. Dùng {Tool.Port} làm biến, {OK} và {Result}", Glyph = "➤")]
    public class SendCommTool : ToolBase
    {
        [Param("Comm", "Channel", List = "comm")] public string Channel { get; set; }
        [Param("Comm", "Template", Hint = "VD: {Align2P1.X},{Align2P1.Y},{Align2P1.T}")] public string Template { get; set; } = "{OK},{Align2P1.X},{Align2P1.Y},{Align2P1.T}";
        [Param("Comm", "Send when", Choices = "Always|OK only|NG only")] public string When { get; set; } = "Always";
        [Param("Comm", "Overall result (bool)", Source = Kind.Bool)] public string ResultLink { get; set; }
        [Param("Comm", "Decimals", Min = 0, Max = 6)] public int Decimals { get; set; } = 3;
        public override IEnumerable<Port> Ports { get { yield return new Port("Sent", Kind.Text); } }

        public static string Expand(RunContext ctx, string tpl, bool overall, int dec)
        {
            return Regex.Replace(tpl ?? "", @"\{([^}]+)\}", m =>
            {
                string key = m.Groups[1].Value.Trim();
                if (key.Equals("OK", StringComparison.OrdinalIgnoreCase) || key.Equals("Result", StringComparison.OrdinalIgnoreCase)) return overall ? "OK" : "NG";
                if (!ctx.Values.TryGetValue(key, out object v)) return "0";
                if (v is double d) return d.ToString("F" + dec, CultureInfo.InvariantCulture);
                if (v is bool b) return b ? "1" : "0";
                return DataLogTool.Fmt(v);
            });
        }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            bool ok = true; if (!string.IsNullOrWhiteSpace(ResultLink)) ctx.TryGet(ResultLink, out ok);
            res.Ok = true;
            if ((When == "OK only" && !ok) || (When == "NG only" && ok)) { res.Message = "Skip"; return; }
            string text = Expand(ctx, Template, ok, Decimals);
            bool sent = CommHub.Send(Channel, text);
            Out(ctx, "Sent", text); res.Ok = sent; res.Message = sent ? text : "Gửi thất bại (kênh chưa kết nối)";
        }
    }

    [Tool("Receive (Comm)", "Comm", Description = "Đọc tin nhắn cuối nhận được trên kênh, tách tối đa 4 số", Glyph = "⮈")]
    public class ReceiveCommTool : ToolBase
    {
        [Param("Comm", "Channel", List = "comm")] public string Channel { get; set; }
        [Param("Comm", "Separator")] public string Separator { get; set; } = ",";
        public override IEnumerable<Port> Ports { get { yield return new Port("Text", Kind.Text); yield return new Port("N1", Kind.Number); yield return new Port("N2", Kind.Number); yield return new Port("N3", Kind.Number); yield return new Port("N4", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            CommHub.Last.TryGetValue(Channel ?? "", out string t); t = t ?? ""; Out(ctx, "Text", t);
            var parts = t.Split(new[] { string.IsNullOrEmpty(Separator) ? "," : Separator }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < 4; i++) { double v = 0; if (i < parts.Length) double.TryParse(parts[i].Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out v); Out(ctx, "N" + (i + 1), v); }
            res.Ok = t.Length > 0; res.Message = t.Length > 0 ? t : "chưa có dữ liệu";
        }
    }
}
