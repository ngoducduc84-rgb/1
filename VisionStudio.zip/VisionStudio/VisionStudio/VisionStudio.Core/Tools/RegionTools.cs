using System;
using System.Collections.Generic;
using System.Linq;
using HalconDotNet;
using VisionStudio.Core.Framework;
using VisionStudio.Core.Geometry;
using VisionStudio.Core.Halcon;

namespace VisionStudio.Core.Tools
{
    [Tool("Make Region", "Image", Description = "Tạo Region từ ROI (chữ nhật / vành tròn / dải theo đường thẳng), có theo Fixture", Glyph = "▭")]
    public class MakeRegionTool : ToolBase
    {
        [Param("Input", "Fixture", Source = Kind.Fixture)] public string FixtureLink { get; set; }
        [Param("Input", "Line (for band)", Source = Kind.Line)] public string LineLink { get; set; }
        [Param("Region", "Mode", Choices = "Rectangle|Ring|Band along line")] public string Mode { get; set; } = "Rectangle";
        [Param("Region", "Band half-width")] public double BandHalf { get; set; } = 10;
        [Param("Rectangle", "Rect ROI")] public Rect2Roi Rect { get; set; } = new Rect2Roi();
        [Param("Ring", "Ring ROI")] public CircleRoi Ring { get; set; } = new CircleRoi();
        public override IEnumerable<Port> Ports { get { yield return new Port("Region", Kind.Region); yield return new Port("Area", Kind.Number); yield return new Port("Center", Kind.Point); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var fx = GetFixture(ctx, FixtureLink); HObject rg;
            if (Mode == "Ring") rg = Ring.Transformed(fx).ToRegion();
            else if (Mode == "Band along line")
            {
                var l = ctx.Get<LineD>(LineLink) ?? throw new InvalidOperationException("Thiếu đường thẳng");
                rg = new LineRoi { R1 = l.R1, C1 = l.C1, R2 = l.R2, C2 = l.C2, HalfWidth = BandHalf }.ToRegion();
            }
            else rg = Rect.Transformed(fx).ToRegion();
            HOperatorSet.AreaCenter(rg, out HTuple a, out HTuple r, out HTuple c);
            Out(ctx, "Area", a.D); Out(ctx, "Center", new Pt(c.D, r.D)); ctx.AddObj(rg, "yellow");
            Out(ctx, "Region", rg); res.Ok = true; res.Message = "area=" + Cal.F(a.D);
        }
    }

    [Tool("Morphology", "Image", Description = "Phép hình thái trên Region (dilate/erode/open/close, fill, connection)", Glyph = "⬡")]
    public class MorphologyTool : ToolBase
    {
        [Param("Input", "Region", Source = Kind.Region)] public string RegionLink { get; set; }
        [Param("Op", "Operation", Choices = "Dilation circle|Erosion circle|Opening circle|Closing circle|Dilation rect|Erosion rect|Opening rect|Closing rect|Fill up|Union|Complement")]
        public string Op { get; set; } = "Opening circle";
        [Param("Op", "Radius / width", Min = 0.5)] public double Radius { get; set; } = 3.5;
        [Param("Op", "Height (rect)", Min = 1)] public double Height { get; set; } = 3;
        public override IEnumerable<Port> Ports { get { yield return new Port("Region", Kind.Region); yield return new Port("Area", Kind.Number); yield return new Port("Count", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var src = ctx.Get<HObject>(RegionLink); if (!HalconUtil.Valid(src)) throw new InvalidOperationException("Thiếu Region đầu vào");
            HObject o;
            switch (Op)
            {
                case "Dilation circle": HOperatorSet.DilationCircle(src, out o, Radius); break;
                case "Erosion circle": HOperatorSet.ErosionCircle(src, out o, Radius); break;
                case "Opening circle": HOperatorSet.OpeningCircle(src, out o, Radius); break;
                case "Closing circle": HOperatorSet.ClosingCircle(src, out o, Radius); break;
                case "Dilation rect": HOperatorSet.DilationRectangle1(src, out o, Radius, Height); break;
                case "Erosion rect": HOperatorSet.ErosionRectangle1(src, out o, Radius, Height); break;
                case "Opening rect": HOperatorSet.OpeningRectangle1(src, out o, Radius, Height); break;
                case "Closing rect": HOperatorSet.ClosingRectangle1(src, out o, Radius, Height); break;
                case "Fill up": HOperatorSet.FillUp(src, out o); break;
                case "Union": HOperatorSet.Union1(src, out o); break;
                default: HOperatorSet.Complement(src, out o); break;
            }
            HOperatorSet.Connection(o, out HObject conn); int n = HalconUtil.Count(conn); conn.Dispose();
            double area = 0; if (HalconUtil.Count(o) > 0) { HOperatorSet.AreaCenter(o, out HTuple a, out HTuple r, out HTuple c); area = a.TupleSum().D; }
            Out(ctx, "Area", area); Out(ctx, "Count", (double)n); ctx.AddObj(o, "green");
            Out(ctx, "Region", o); res.Ok = true; res.Message = $"area={area:0} regions={n}";
        }
    }

    [Tool("Select Number", "Logic", Description = "Chọn 1 trong tối đa 4 giá trị số: Min / Max / Gần mục tiêu nhất (Angle Selector)", Glyph = "⇅")]
    public class SelectNumberTool : ToolBase
    {
        [Param("Input", "A", Source = Kind.Number)] public string A { get; set; }
        [Param("Input", "B", Source = Kind.Number)] public string B { get; set; }
        [Param("Input", "C", Source = Kind.Number)] public string C { get; set; }
        [Param("Input", "D", Source = Kind.Number)] public string D { get; set; }
        [Param("Select", "Mode", Choices = "Min|Max|Closest to target|Closest angle to target (wrap 360)")] public string Mode { get; set; } = "Min";
        [Param("Select", "Target")] public double Target { get; set; }
        public override IEnumerable<Port> Ports { get { yield return new Port("Value", Kind.Number); yield return new Port("Index", Kind.Number); } }

        protected override void Execute(RunContext ctx, ToolResult res)
        {
            var vals = new List<KeyValuePair<int, double>>(); int i = 0;
            foreach (var l in new[] { A, B, C, D }) { i++; if (ctx.TryGet(l, out double v)) vals.Add(new KeyValuePair<int, double>(i, v)); }
            if (vals.Count == 0) throw new InvalidOperationException("Chưa có giá trị đầu vào");
            KeyValuePair<int, double> best;
            switch (Mode)
            {
                case "Max": best = vals.OrderByDescending(k => k.Value).First(); break;
                case "Closest to target": best = vals.OrderBy(k => Math.Abs(k.Value - Target)).First(); break;
                case "Closest angle to target (wrap 360)": best = vals.OrderBy(k => Math.Abs(GeoMath.NormDeg(k.Value - Target))).First(); break;
                default: best = vals.OrderBy(k => k.Value).First(); break;
            }
            Out(ctx, "Value", best.Value); Out(ctx, "Index", (double)best.Key); res.Ok = true; res.Message = $"{Mode}: {Cal.F(best.Value)} (#{best.Key})";
        }
    }
}
