﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using VisionMachine.Controls.Common;
using VisionMachine.Services.Appearance;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Licensing;
using VisionMachine.Services.Localization;
using VisionMachine.Services.Runtime;
using VisionMachine.Views.License;
using VisionMachine.Views.Main;
using VisionMachine.Views.Startup;

namespace VisionMachine
{
	// Token: 0x02000004 RID: 4
	public partial class App : Application
	{
		// Token: 0x0600000E RID: 14 RVA: 0x000022F0 File Offset: 0x000004F0
		protected override void OnStartup(StartupEventArgs e)
		{
			bool createdNew;
			this._singleInstanceMutex = new Mutex(true, "Global\\VisionMachine_SingleInstance", ref createdNew);
			bool flag = !createdNew;
			if (flag)
			{
				MessageBox.Show("VisionMachine is already running.", "VisionMachine", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				base.Shutdown();
			}
			else
			{
				this.HookGlobalExceptionHandlers();
				StartupDiag.BeginSession();
				GenTlProducerGuard.Apply();
				StartupDiag.Log("OnStartup: " + GenTlProducerGuard.LastMessage);
				StartupDiag.Log("OnStartup: applying theme");
				ThemeService.Initialize();
				LanguageService.Initialize();
				UiLocalizer.Install();
				ContextMenuIconService.Install();
				base.OnStartup(e);
				base.ShutdownMode = ShutdownMode.OnExplicitShutdown;
				LicenseState expiredLicense;
				bool flag2 = LicenseExpiryWarningService.TryGetExpiredLicense(out expiredLicense);
				if (flag2)
				{
					LicenseExpiredWindow expiredWindow = new LicenseExpiredWindow(expiredLicense);
					expiredWindow.ShowDialog();
					bool flag3 = !expiredWindow.LicenseRenewed;
					if (flag3)
					{
						base.Shutdown();
						return;
					}
				}
				bool flag4 = !LicenseService.IsActivated;
				if (flag4)
				{
					LicenseExpiredWindow requiredWindow = LicenseExpiredWindow.ForMissingLicense();
					requiredWindow.ShowDialog();
					bool flag5 = !requiredWindow.LicenseRenewed;
					if (flag5)
					{
						base.Shutdown();
						return;
					}
				}
				StartupSplash splash = StartupSplash.Show();
				base.ShutdownMode = ShutdownMode.OnMainWindowClose;
				try
				{
					StartupDiag.Log("OnStartup: creating MainWindow");
					MainWindow main = new MainWindow();
					StartupDiag.Log("OnStartup: MainWindow created");
					bool splashClosed = false;
					Action <>9__2;
					main.ContentRendered += delegate(object s, EventArgs ev)
					{
						bool splashClosed = splashClosed;
						if (!splashClosed)
						{
							splashClosed = true;
							splash.Close();
							Dispatcher dispatcher = main.Dispatcher;
							Action method;
							if ((method = <>9__2) == null)
							{
								method = (<>9__2 = delegate()
								{
									App.BringToFront(main);
								});
							}
							dispatcher.BeginInvoke(method, DispatcherPriority.ApplicationIdle, Array.Empty<object>());
						}
					};
					base.MainWindow = main;
					main.Show();
					StartupDiag.Log("OnStartup: MainWindow shown");
					main.Dispatcher.BeginInvoke(new Action(delegate()
					{
						try
						{
							LoadingOverlay.PrewarmShared();
						}
						catch
						{
						}
					}), DispatcherPriority.ApplicationIdle, Array.Empty<object>());
				}
				catch (Exception ex)
				{
					StartupDiag.Log("OnStartup FAILED", ex);
					splash.Close();
					throw;
				}
			}
		}

		// Token: 0x0600000F RID: 15 RVA: 0x00002508 File Offset: 0x00000708
		protected override void OnExit(ExitEventArgs e)
		{
			try
			{
				bool flag = this._singleInstanceMutex != null;
				if (flag)
				{
					try
					{
						this._singleInstanceMutex.ReleaseMutex();
					}
					catch
					{
					}
					this._singleInstanceMutex.Dispose();
					this._singleInstanceMutex = null;
				}
			}
			catch
			{
			}
			base.OnExit(e);
		}

		// Token: 0x06000010 RID: 16 RVA: 0x0000257C File Offset: 0x0000077C
		private void HookGlobalExceptionHandlers()
		{
			base.DispatcherUnhandledException += delegate(object s, DispatcherUnhandledExceptionEventArgs args)
			{
				App.LogCrash("UI thread", args.Exception);
				try
				{
					MessageBox.Show("An unexpected error occurred:\n\n" + args.Exception.Message + "\n\nThe error was logged. The application will try to keep running.", "VisionMachine", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
				catch
				{
				}
				args.Handled = true;
			};
			AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs args)
			{
				App.LogCrash("Background thread", args.ExceptionObject as Exception);
			};
			TaskScheduler.UnobservedTaskException += delegate(object s, UnobservedTaskExceptionEventArgs args)
			{
				App.LogCrash("Task", args.Exception);
				args.SetObserved();
			};
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002600 File Offset: 0x00000800
		private static void LogCrash(string source, Exception ex)
		{
			bool flag = ex == null;
			if (!flag)
			{
				try
				{
					string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VisionMachine");
					Directory.CreateDirectory(folder);
					string line = string.Concat(new string[]
					{
						"[",
						DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
						"] ",
						source,
						": ",
						(ex != null) ? ex.ToString() : null,
						Environment.NewLine,
						Environment.NewLine
					});
					File.AppendAllText(Path.Combine(folder, "crash_log.txt"), line);
				}
				catch
				{
				}
			}
		}

		// Token: 0x06000012 RID: 18 RVA: 0x000026C0 File Offset: 0x000008C0
		private static void BringToFront(Window window)
		{
			bool flag = window == null;
			if (!flag)
			{
				try
				{
					bool flag2 = window.WindowState == WindowState.Minimized;
					if (flag2)
					{
						window.WindowState = WindowState.Normal;
					}
					window.Show();
					window.Activate();
					window.Topmost = true;
					window.Topmost = false;
					window.Focus();
				}
				catch
				{
				}
			}
		}

		// Token: 0x04000006 RID: 6
		private Mutex _singleInstanceMutex;
	}
}
