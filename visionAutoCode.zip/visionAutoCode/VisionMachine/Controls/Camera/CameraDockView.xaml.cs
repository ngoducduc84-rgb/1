﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using DevExpress.Xpf.Bars;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using HalconDotNet;
using VisionMachine.Views.Home;

namespace VisionMachine.Controls.Camera
{
	// Token: 0x020002B2 RID: 690
	public partial class CameraDockView : UserControl
	{
		// Token: 0x1400004B RID: 75
		// (add) Token: 0x060025A9 RID: 9641 RVA: 0x000DB940 File Offset: 0x000D9B40
		// (remove) Token: 0x060025AA RID: 9642 RVA: 0x000DB978 File Offset: 0x000D9B78
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event EventHandler OpenRequested;

		// Token: 0x1400004C RID: 76
		// (add) Token: 0x060025AB RID: 9643 RVA: 0x000DB9B0 File Offset: 0x000D9BB0
		// (remove) Token: 0x060025AC RID: 9644 RVA: 0x000DB9E8 File Offset: 0x000D9BE8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event EventHandler RunRequested;

		// Token: 0x1400004D RID: 77
		// (add) Token: 0x060025AD RID: 9645 RVA: 0x000DBA20 File Offset: 0x000D9C20
		// (remove) Token: 0x060025AE RID: 9646 RVA: 0x000DBA58 File Offset: 0x000D9C58
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event EventHandler SettingRequested;

		// Token: 0x17000AFA RID: 2810
		// (get) Token: 0x060025AF RID: 9647 RVA: 0x000DBA8D File Offset: 0x000D9C8D
		// (set) Token: 0x060025B0 RID: 9648 RVA: 0x000DBA95 File Offset: 0x000D9C95
		public Form_home HomeHost { get; set; }

		// Token: 0x060025B1 RID: 9649 RVA: 0x000DBAA0 File Offset: 0x000D9CA0
		public void SetConnectionState(bool connected)
		{
			string expectedText = connected ? "Connected" : "Disconnected";
			bool? connectionState = this._connectionState;
			bool flag = connectionState.GetValueOrDefault() == connected & connectionState != null;
			if (flag)
			{
				bool flag2 = !string.Equals(this.ConnectionText.Text, expectedText, StringComparison.Ordinal);
				if (flag2)
				{
					this.ConnectionText.Text = expectedText;
				}
			}
			else
			{
				this._connectionState = new bool?(connected);
				Color colour = connected ? Color.FromRgb(74, 222, 128) : Color.FromRgb(248, 113, 113);
				SolidColorBrush brush = new SolidColorBrush(colour);
				SolidColorBrush background = new SolidColorBrush(colour)
				{
					Opacity = 0.2
				};
				this.ConnectionText.Text = expectedText;
				this.ConnectionText.Foreground = brush;
				this.ConnectionDot.Fill = brush;
				this.ConnectionBadge.BorderBrush = brush;
				this.ConnectionBadge.Background = background;
			}
		}

		// Token: 0x060025B2 RID: 9650 RVA: 0x000DBBA4 File Offset: 0x000D9DA4
		public CameraDockView()
		{
			this.InitializeComponent();
			bool flag = this.hWindow != null;
			if (flag)
			{
				this.hWindow.HMoveContent = false;
				this.hWindow.HZoomContent = HSmartWindowControlWPF.ZoomContent.Off;
				this.hWindow.HDoubleClickToFitContent = false;
			}
		}

		// Token: 0x17000AFB RID: 2811
		// (get) Token: 0x060025B3 RID: 9651 RVA: 0x000DBBF6 File Offset: 0x000D9DF6
		public HSmartWindowControlWPF WindowControl
		{
			get
			{
				return this.hWindow;
			}
		}

		// Token: 0x060025B4 RID: 9652 RVA: 0x0000AB39 File Offset: 0x00008D39
		public void SetTitle(string title)
		{
		}

		// Token: 0x060025B5 RID: 9653 RVA: 0x000DBBFE File Offset: 0x000D9DFE
		public void SetPixelInfo(string text)
		{
			this.txtPixelInfo.EditValue = (string.IsNullOrWhiteSpace(text) ? "Row: -, Col: -, Gray: -, RGB: -, Size: - x -" : text);
		}

		// Token: 0x060025B6 RID: 9654 RVA: 0x000DBC20 File Offset: 0x000D9E20
		private void BarManager_ItemClick(object sender, ItemClickEventArgs e)
		{
			BarItem item = e.Item;
			object value;
			if ((value = ((item != null) ? item.Tag : null)) == null)
			{
				BarItem item2 = e.Item;
				value = ((item2 != null) ? item2.Content : null);
			}
			string action = Convert.ToString(value);
			string text = action;
			string a = text;
			if (!(a == "Open"))
			{
				if (!(a == "Run"))
				{
					if (a == "Setting")
					{
						this.ExecuteSetting();
					}
				}
				else
				{
					this.ExecuteRun();
				}
			}
			else
			{
				this.ExecuteOpenImage();
			}
		}

		// Token: 0x060025B7 RID: 9655 RVA: 0x000DBCA4 File Offset: 0x000D9EA4
		private void ExecuteOpenImage()
		{
			Form_home home = this.ResolveHomeHost();
			bool flag = home != null;
			if (flag)
			{
				home.OpenImageFromCameraDock(this);
			}
			else
			{
				bool flag2 = this.OpenRequested != null;
				if (flag2)
				{
					this.OpenRequested(this, EventArgs.Empty);
				}
				else
				{
					DXMessageBox.Show("Home host was not found for this camera display.", "Open Image");
				}
			}
		}

		// Token: 0x060025B8 RID: 9656 RVA: 0x000DBD00 File Offset: 0x000D9F00
		private void ExecuteRun()
		{
			Form_home home = this.ResolveHomeHost();
			bool flag = home != null;
			if (flag)
			{
				home.RunTurnSnapFromCameraDock(this);
			}
			else
			{
				bool flag2 = this.RunRequested != null;
				if (flag2)
				{
					this.RunRequested(this, EventArgs.Empty);
				}
				else
				{
					DXMessageBox.Show("Home host was not found for this camera display.", "Run TurnSnap");
				}
			}
		}

		// Token: 0x060025B9 RID: 9657 RVA: 0x000DBD5C File Offset: 0x000D9F5C
		private void ExecuteSetting()
		{
			Form_home home = this.ResolveHomeHost();
			bool flag = home != null;
			if (flag)
			{
				home.ShowSettingFromCameraDock(this);
			}
			else
			{
				bool flag2 = this.SettingRequested != null;
				if (flag2)
				{
					this.SettingRequested(this, EventArgs.Empty);
				}
				else
				{
					DXMessageBox.Show("Home host was not found for this camera display.", "Home Run Setting");
				}
			}
		}

		// Token: 0x060025BA RID: 9658 RVA: 0x000DBDB5 File Offset: 0x000D9FB5
		private void HWindow_MouseMove(object sender, MouseEventArgs e)
		{
			Form_home form_home = this.ResolveHomeHost();
			if (form_home != null)
			{
				form_home.UpdatePixelInspectorFromCameraDock(this, e);
			}
		}

		// Token: 0x060025BB RID: 9659 RVA: 0x000DBDCC File Offset: 0x000D9FCC
		private void HWindow_MouseLeave(object sender, MouseEventArgs e)
		{
			this.SetPixelInfo(null);
		}

		// Token: 0x060025BC RID: 9660 RVA: 0x000DBDD8 File Offset: 0x000D9FD8
		private void SaveImage_Click(object sender, RoutedEventArgs e)
		{
			Form_home home = this.ResolveHomeHost();
			bool flag = home != null;
			if (flag)
			{
				home.SaveCameraDockImage(this);
			}
			else
			{
				DXMessageBox.Show("Home host was not found for this camera display.", "Save Image");
			}
		}

		// Token: 0x060025BD RID: 9661 RVA: 0x000DBE10 File Offset: 0x000DA010
		private Form_home ResolveHomeHost()
		{
			bool flag = this.HomeHost != null;
			Form_home result;
			if (flag)
			{
				result = this.HomeHost;
			}
			else
			{
				bool flag2 = Form_home.Instance != null;
				if (flag2)
				{
					result = Form_home.Instance;
				}
				else
				{
					DependencyObject parent;
					for (DependencyObject current = this; current != null; current = parent)
					{
						Form_home home = current as Form_home;
						bool flag3 = home != null;
						if (flag3)
						{
							return home;
						}
						parent = null;
						try
						{
							parent = VisualTreeHelper.GetParent(current);
						}
						catch
						{
						}
						bool flag4 = parent == null;
						if (flag4)
						{
							parent = LogicalTreeHelper.GetParent(current);
						}
					}
					result = null;
				}
			}
			return result;
		}

		// Token: 0x04000FDE RID: 4062
		private bool? _connectionState;
	}
}
