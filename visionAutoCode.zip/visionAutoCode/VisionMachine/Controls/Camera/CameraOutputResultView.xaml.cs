﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Grid;
using Microsoft.Win32;
using VisionMachine.Controls.Home;

namespace VisionMachine.Controls.Camera
{
	// Token: 0x020002B1 RID: 689
	public partial class CameraOutputResultView : UserControl
	{
		// Token: 0x060025A0 RID: 9632 RVA: 0x000DB51E File Offset: 0x000D971E
		public CameraOutputResultView()
		{
			this.InitializeComponent();
		}

		// Token: 0x17000AF9 RID: 2809
		// (get) Token: 0x060025A1 RID: 9633 RVA: 0x000DB53A File Offset: 0x000D973A
		public ObservableCollection<HomeOutputResultRow> OutputResults { get; } = new ObservableCollection<HomeOutputResultRow>();

		// Token: 0x060025A2 RID: 9634 RVA: 0x000DB544 File Offset: 0x000D9744
		public void ShowOutputResults(IEnumerable<HomeOutputResultRow> rows)
		{
			this.OutputResults.Clear();
			bool flag = rows == null;
			if (!flag)
			{
				foreach (HomeOutputResultRow row in rows)
				{
					bool flag2 = row != null;
					if (flag2)
					{
						this.OutputResults.Add(row);
					}
				}
			}
		}

		// Token: 0x060025A3 RID: 9635 RVA: 0x000DB5B8 File Offset: 0x000D97B8
		private void CopyResults_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Clipboard.SetText(this.BuildText(false));
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Could not copy the output: " + ex.Message, "Copy Output");
			}
		}

		// Token: 0x060025A4 RID: 9636 RVA: 0x000DB608 File Offset: 0x000D9808
		private void ExportResults_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this.OutputResults == null || this.OutputResults.Count == 0;
			if (flag)
			{
				DXMessageBox.Show("There is no output to export.", "Export Output");
			}
			else
			{
				SaveFileDialog dialog = new SaveFileDialog
				{
					Title = "Export Output Result",
					Filter = "CSV file (*.csv)|*.csv|Text file (*.txt)|*.txt|All files (*.*)|*.*",
					FileName = "output_result_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv"
				};
				bool flag2 = !dialog.ShowDialog().GetValueOrDefault();
				if (!flag2)
				{
					try
					{
						bool csv = !dialog.FileName.EndsWith(".txt", StringComparison.OrdinalIgnoreCase);
						File.WriteAllText(dialog.FileName, this.BuildText(csv), Encoding.UTF8);
					}
					catch (Exception ex)
					{
						DXMessageBox.Show("Could not export the output: " + ex.Message, "Export Output");
					}
				}
			}
		}

		// Token: 0x060025A5 RID: 9637 RVA: 0x000DB710 File Offset: 0x000D9910
		private string BuildText(bool csv)
		{
			bool flag = this.OutputResults == null || this.OutputResults.Count == 0;
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				char separator = csv ? ',' : '\t';
				StringBuilder builder = new StringBuilder();
				builder.Append("Tool").Append(separator).Append("Result").Append(separator).Append("Status").Append(separator).AppendLine("Time (ms)");
				foreach (HomeOutputResultRow row in this.OutputResults)
				{
					builder.Append(CameraOutputResultView.Escape(row.ToolName, csv)).Append(separator).Append(CameraOutputResultView.Escape(row.Result, csv)).Append(separator).Append(CameraOutputResultView.Escape(row.Status, csv)).Append(separator).AppendLine(row.ProcessingTimeMs.ToString("0.###"));
				}
				result = builder.ToString();
			}
			return result;
		}

		// Token: 0x060025A6 RID: 9638 RVA: 0x000DB844 File Offset: 0x000D9A44
		private static string Escape(string value, bool csv)
		{
			value = (value ?? string.Empty);
			string result;
			if (csv)
			{
				result = "\"" + value.Replace("\"", "\"\"") + "\"";
			}
			else
			{
				result = value.Replace('\t', ' ');
			}
			return result;
		}
	}
}
