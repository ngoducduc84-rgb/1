﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Threading;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using VisionMachine.Controls.Common;
using VisionMachine.Models.Camera;
using VisionMachine.Services.Camera;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Camera;

namespace VisionMachine.Controls.Camera
{
	// Token: 0x020002B5 RID: 693
	public partial class Camera_Select_UI : UserControl, INotifyPropertyChanged
	{
		// Token: 0x17000B03 RID: 2819
		// (get) Token: 0x060025FA RID: 9722 RVA: 0x000DD410 File Offset: 0x000DB610
		// (set) Token: 0x060025FB RID: 9723 RVA: 0x000DD428 File Offset: 0x000DB628
		public IReadOnlyList<ConnectedCameraInfo> FilteredConnectedCameras
		{
			get
			{
				return this._filteredConnectedCameras;
			}
			private set
			{
				this._filteredConnectedCameras = (value ?? new List<ConnectedCameraInfo>());
				this.OnPropertyChanged("FilteredConnectedCameras");
			}
		}

		// Token: 0x060025FC RID: 9724 RVA: 0x000DD448 File Offset: 0x000DB648
		private static double ComputeTickFrequency(double min, double max)
		{
			double span = max - min;
			bool flag = span <= 0.0;
			double result;
			if (flag)
			{
				result = 1.0;
			}
			else
			{
				double frequency = span / 100.0;
				result = ((frequency < 1.0) ? 1.0 : frequency);
			}
			return result;
		}

		// Token: 0x17000B04 RID: 2820
		// (get) Token: 0x060025FD RID: 9725 RVA: 0x000DD4A1 File Offset: 0x000DB6A1
		public IReadOnlyList<CameraVendor> VendorOptions { get; } = new CameraVendor[]
		{
			CameraVendor.Unknown,
			CameraVendor.Basler,
			CameraVendor.Hikvision
		};

		// Token: 0x060025FE RID: 9726 RVA: 0x000DD4AC File Offset: 0x000DB6AC
		public Camera_Select_UI()
		{
			this.InitializeComponent();
			base.Loaded += this.Camera_Select_UI_Loaded;
			base.DataContextChanged += this.Camera_Select_UI_DataContextChanged;
		}

		// Token: 0x1400004F RID: 79
		// (add) Token: 0x060025FF RID: 9727 RVA: 0x000DD54C File Offset: 0x000DB74C
		// (remove) Token: 0x06002600 RID: 9728 RVA: 0x000DD584 File Offset: 0x000DB784
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06002601 RID: 9729 RVA: 0x000DD5B9 File Offset: 0x000DB7B9
		private void OnPropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x17000B05 RID: 2821
		// (get) Token: 0x06002602 RID: 9730 RVA: 0x000DD5D8 File Offset: 0x000DB7D8
		private MainViewModel ViewModel
		{
			get
			{
				return base.DataContext as MainViewModel;
			}
		}

		// Token: 0x17000B06 RID: 2822
		// (get) Token: 0x06002603 RID: 9731 RVA: 0x000DD5F8 File Offset: 0x000DB7F8
		private CameraParameterConfig SelectedConfig
		{
			get
			{
				MainViewModel viewModel = this.ViewModel;
				CameraParameterConfig result;
				if (viewModel == null)
				{
					result = null;
				}
				else
				{
					CameraNode selectedCamera = viewModel.SelectedCamera;
					result = ((selectedCamera != null) ? selectedCamera.CameraConfig : null);
				}
				return result;
			}
		}

		// Token: 0x06002604 RID: 9732 RVA: 0x000DD628 File Offset: 0x000DB828
		private void Camera_Select_UI_Loaded(object sender, RoutedEventArgs e)
		{
			this.SetDefaultEditorRanges();
			this.RefreshFilteredConnectedCameras();
			this.RefreshParameterRanges();
			base.Dispatcher.BeginInvoke(new Action(this.RefreshParameterRanges), DispatcherPriority.ApplicationIdle, Array.Empty<object>());
		}

		// Token: 0x06002605 RID: 9733 RVA: 0x000DD65E File Offset: 0x000DB85E
		private void Camera_Select_UI_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			this.RefreshFilteredConnectedCameras();
			this.RefreshParameterRanges();
		}

		// Token: 0x06002606 RID: 9734 RVA: 0x000DD670 File Offset: 0x000DB870
		private void RefreshParameterRanges()
		{
			bool isRefreshingRanges = this._isRefreshingRanges;
			if (!isRefreshingRanges)
			{
				CameraParameterConfig config = this.SelectedConfig;
				bool flag = config == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
				if (!flag)
				{
					this._isRefreshingRanges = true;
					Task.Run(delegate()
					{
						CameraParameterRange gain = null;
						CameraParameterRange exposure = null;
						for (int attempt = 0; attempt < 5; attempt++)
						{
							try
							{
								CameraHardwareRuntimeService.GetGainAndExposureRange(config, out gain, out exposure);
							}
							catch
							{
							}
							bool gainOk = gain != null && gain.Max > gain.Min;
							bool exposureOk = exposure != null && exposure.Max > exposure.Min;
							bool flag2 = gainOk && exposureOk;
							if (flag2)
							{
								break;
							}
							bool flag3 = attempt < 4;
							if (flag3)
							{
								Thread.Sleep(400);
							}
						}
						this.Dispatcher.BeginInvoke(new Action(delegate()
						{
							try
							{
								bool flag4 = config != this.SelectedConfig;
								if (!flag4)
								{
									bool flag5 = gain != null && gain.Max > gain.Min;
									if (flag5)
									{
										this._gainMin = gain.Min;
										this._gainMax = gain.Max;
										this._gainIncrement = 1.0;
										this.ApplyTrackRange(this.GainTrack, gain.Min, gain.Max);
										Camera_Select_UI.ClampConfigValue(config, true, gain.Min, gain.Max);
									}
									bool flag6 = exposure != null && exposure.Max > exposure.Min;
									if (flag6)
									{
										this._exposureMin = exposure.Min;
										this._exposureMax = exposure.Max;
										this._exposureIncrement = Camera_Select_UI.ComputeIncrement(exposure.Min, exposure.Max);
										this.ApplyTrackRange(this.ExposureTrack, exposure.Min, exposure.Max);
										Camera_Select_UI.ClampConfigValue(config, false, exposure.Min, exposure.Max);
									}
								}
							}
							finally
							{
								this._isRefreshingRanges = false;
							}
						}), Array.Empty<object>());
					});
				}
			}
		}

		// Token: 0x06002607 RID: 9735 RVA: 0x000DD6DD File Offset: 0x000DB8DD
		private void SetDefaultEditorRanges()
		{
			this.ApplyTrackRange(this.GainTrack, this._gainMin, this._gainMax);
			this.ApplyTrackRange(this.ExposureTrack, this._exposureMin, this._exposureMax);
		}

		// Token: 0x06002608 RID: 9736 RVA: 0x000DD714 File Offset: 0x000DB914
		private void ApplyTrackRange(TrackBarEdit track, double min, double max)
		{
			bool flag = track == null || max <= min;
			if (!flag)
			{
				track.Minimum = min;
				track.Maximum = max;
				track.TickFrequency = Camera_Select_UI.ComputeTickFrequency(min, max);
			}
		}

		// Token: 0x06002609 RID: 9737 RVA: 0x000DD753 File Offset: 0x000DB953
		private void GainUp_Click(object sender, RoutedEventArgs e)
		{
			this.StepValue(true, 1);
		}

		// Token: 0x0600260A RID: 9738 RVA: 0x000DD75F File Offset: 0x000DB95F
		private void GainDown_Click(object sender, RoutedEventArgs e)
		{
			this.StepValue(true, -1);
		}

		// Token: 0x0600260B RID: 9739 RVA: 0x000DD76B File Offset: 0x000DB96B
		private void ExposureUp_Click(object sender, RoutedEventArgs e)
		{
			this.StepValue(false, 1);
		}

		// Token: 0x0600260C RID: 9740 RVA: 0x000DD777 File Offset: 0x000DB977
		private void ExposureDown_Click(object sender, RoutedEventArgs e)
		{
			this.StepValue(false, -1);
		}

		// Token: 0x0600260D RID: 9741 RVA: 0x000DD783 File Offset: 0x000DB983
		private void GainText_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.ApplyOnUserTyping(sender, true);
		}

		// Token: 0x0600260E RID: 9742 RVA: 0x000DD78F File Offset: 0x000DB98F
		private void ExposureText_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.ApplyOnUserTyping(sender, false);
		}

		// Token: 0x0600260F RID: 9743 RVA: 0x000DD79C File Offset: 0x000DB99C
		private void ApplyOnUserTyping(object sender, bool isGain)
		{
			TextBox textBox = sender as TextBox;
			bool flag = textBox == null || !textBox.IsKeyboardFocusWithin;
			if (!flag)
			{
				CameraParameterConfig config = this.SelectedConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					if (isGain)
					{
						CameraHardwareRuntimeService.ApplyGain(config);
					}
					else
					{
						CameraHardwareRuntimeService.ApplyExposure(config);
					}
				}
			}
		}

		// Token: 0x06002610 RID: 9744 RVA: 0x000DD7EE File Offset: 0x000DB9EE
		private void GainText_LostFocus(object sender, RoutedEventArgs e)
		{
			this.ClampSelectedConfig(true);
		}

		// Token: 0x06002611 RID: 9745 RVA: 0x000DD7F9 File Offset: 0x000DB9F9
		private void ExposureText_LostFocus(object sender, RoutedEventArgs e)
		{
			this.ClampSelectedConfig(false);
		}

		// Token: 0x06002612 RID: 9746 RVA: 0x000DD804 File Offset: 0x000DBA04
		private void StepValue(bool isGain, int direction)
		{
			CameraParameterConfig config = this.SelectedConfig;
			bool flag = config == null;
			if (!flag)
			{
				double increment = isGain ? this._gainIncrement : this._exposureIncrement;
				double min = isGain ? this._gainMin : this._exposureMin;
				double max = isGain ? this._gainMax : this._exposureMax;
				double current = isGain ? config.Gain : config.ExposureTime;
				double next = current + (double)direction * ((increment <= 0.0) ? 1.0 : increment);
				bool flag2 = next < min;
				if (flag2)
				{
					next = min;
				}
				bool flag3 = next > max;
				if (flag3)
				{
					next = max;
				}
				if (isGain)
				{
					config.Gain = next;
					CameraHardwareRuntimeService.ApplyGain(config);
				}
				else
				{
					config.ExposureTime = next;
					CameraHardwareRuntimeService.ApplyExposure(config);
				}
			}
		}

		// Token: 0x06002613 RID: 9747 RVA: 0x000DD8DC File Offset: 0x000DBADC
		private void ClampSelectedConfig(bool isGain)
		{
			CameraParameterConfig config = this.SelectedConfig;
			bool flag = config == null;
			if (!flag)
			{
				if (isGain)
				{
					Camera_Select_UI.ClampConfigValue(config, true, this._gainMin, this._gainMax);
					CameraHardwareRuntimeService.ApplyGain(config);
				}
				else
				{
					Camera_Select_UI.ClampConfigValue(config, false, this._exposureMin, this._exposureMax);
					CameraHardwareRuntimeService.ApplyExposure(config);
				}
			}
		}

		// Token: 0x06002614 RID: 9748 RVA: 0x000DD93C File Offset: 0x000DBB3C
		private static void ClampConfigValue(CameraParameterConfig config, bool isGain, double min, double max)
		{
			bool flag = config == null;
			if (!flag)
			{
				double value = isGain ? config.Gain : config.ExposureTime;
				double clamped = value;
				bool flag2 = clamped < min;
				if (flag2)
				{
					clamped = min;
				}
				bool flag3 = clamped > max;
				if (flag3)
				{
					clamped = max;
				}
				bool flag4 = clamped == value;
				if (!flag4)
				{
					if (isGain)
					{
						config.Gain = clamped;
					}
					else
					{
						config.ExposureTime = clamped;
					}
				}
			}
		}

		// Token: 0x06002615 RID: 9749 RVA: 0x000DD9A4 File Offset: 0x000DBBA4
		private static double ComputeIncrement(double min, double max)
		{
			double span = max - min;
			bool flag = span <= 0.0;
			double result;
			if (flag)
			{
				result = 1.0;
			}
			else
			{
				double step = Math.Round(span / 100.0);
				result = ((step < 1.0) ? 1.0 : step);
			}
			return result;
		}

		// Token: 0x06002616 RID: 9750 RVA: 0x000DDA04 File Offset: 0x000DBC04
		public void RefreshCameraListBinding()
		{
			MainViewModel vm = this.ViewModel;
			bool flag = vm == null;
			if (!flag)
			{
				this.CameraCombo.ItemsSource = null;
				this.CameraCombo.ItemsSource = vm.Cameras;
				bool flag2 = vm.SelectedCamera == null || !vm.Cameras.Contains(vm.SelectedCamera);
				if (flag2)
				{
					vm.SelectedCamera = vm.Cameras.FirstOrDefault<CameraNode>();
				}
				this.CameraCombo.SelectedItem = vm.SelectedCamera;
				this.RefreshFilteredConnectedCameras();
			}
		}

		// Token: 0x06002617 RID: 9751 RVA: 0x000DDA92 File Offset: 0x000DBC92
		private void RefreshConnectedCameras_Click(object sender, RoutedEventArgs e)
		{
			MainViewModel viewModel = this.ViewModel;
			if (viewModel != null)
			{
				viewModel.RefreshConnectedCameras();
			}
			this.RefreshFilteredConnectedCameras();
		}

		// Token: 0x06002618 RID: 9752 RVA: 0x000DDAB0 File Offset: 0x000DBCB0
		private void Camera_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool realChange = e != null && e.OldValue != null && !object.Equals(e.OldValue, e.NewValue);
			bool flag = realChange;
			if (flag)
			{
				Window owner = Window.GetWindow(this);
				LoadingOverlay.ShowShared(owner, "Loading camera configuration...");
			}
			this.RefreshFilteredConnectedCameras();
			this.RefreshParameterRanges();
			bool flag2 = realChange;
			if (flag2)
			{
				base.Dispatcher.BeginInvoke(new Action(LoadingOverlay.HideShared), DispatcherPriority.ContextIdle, Array.Empty<object>());
			}
		}

		// Token: 0x06002619 RID: 9753 RVA: 0x000DDB30 File Offset: 0x000DBD30
		private void Vendor_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			CameraParameterConfig config = this.SelectedConfig;
			bool flag = config == null;
			if (!flag)
			{
				bool flag2 = Camera_Select_UI.IsUserEdit(sender) && e.OldValue != null && !object.Equals(e.OldValue, e.NewValue);
				if (flag2)
				{
					config.ConnectedCameraId = null;
					this.SaveCameraConfig();
				}
				this.RefreshFilteredConnectedCameras();
			}
		}

		// Token: 0x0600261A RID: 9754 RVA: 0x000DDB94 File Offset: 0x000DBD94
		private void ConnectedCamera_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			MainViewModel vm = this.ViewModel;
			CameraParameterConfig config = this.SelectedConfig;
			bool flag = vm == null || config == null;
			if (!flag)
			{
				bool isRestoringSerialDisplay = this._isRestoringSerialDisplay;
				if (!isRestoringSerialDisplay)
				{
					string id = e.NewValue as string;
					ConnectedCameraInfo selectedCameraInfo = e.NewValue as ConnectedCameraInfo;
					bool flag2 = selectedCameraInfo != null;
					if (flag2)
					{
						id = selectedCameraInfo.Id;
					}
					bool flag3 = string.IsNullOrWhiteSpace(id);
					if (flag3)
					{
						bool flag4 = Camera_Select_UI.IsUserEdit(sender) && !this._isRefreshingConnectedCameras;
						if (flag4)
						{
							config.ConnectedCameraId = null;
							this.SaveCameraConfig();
						}
						this.RefreshFilteredConnectedCameras();
					}
					else
					{
						ConnectedCameraInfo connected = vm.ConnectedCameras.FirstOrDefault((ConnectedCameraInfo x) => x.Id == id);
						bool flag5 = connected != null && Camera_Select_UI.IsUserEdit(sender) && !this._isRefreshingConnectedCameras;
						if (flag5)
						{
							this.ClearDuplicateSerialFromOtherCameras(connected.Id);
							config.ConnectedCameraId = connected.Id;
							config.Vendor = connected.Vendor;
							this.SaveCameraConfig();
						}
						this.RefreshFilteredConnectedCameras();
					}
				}
			}
		}

		// Token: 0x0600261B RID: 9755 RVA: 0x000DDCC6 File Offset: 0x000DBEC6
		private void Exposure_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			CameraHardwareRuntimeService.ApplyExposure(this.SelectedConfig);
		}

		// Token: 0x0600261C RID: 9756 RVA: 0x000DDCD5 File Offset: 0x000DBED5
		private void Gain_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			CameraHardwareRuntimeService.ApplyGain(this.SelectedConfig);
		}

		// Token: 0x0600261D RID: 9757 RVA: 0x000DDCE4 File Offset: 0x000DBEE4
		private void StartCamera_Click(object sender, RoutedEventArgs e)
		{
			Form_Camera instance = Form_Camera.Instance;
			if (instance != null)
			{
				instance.StartSelectedCameraLive();
			}
		}

		// Token: 0x0600261E RID: 9758 RVA: 0x000DDCF8 File Offset: 0x000DBEF8
		private void StopCamera_Click(object sender, RoutedEventArgs e)
		{
			Form_Camera instance = Form_Camera.Instance;
			if (instance != null)
			{
				instance.StopSelectedCameraLive();
			}
		}

		// Token: 0x0600261F RID: 9759 RVA: 0x000DDD0C File Offset: 0x000DBF0C
		private void RefreshFilteredConnectedCameras()
		{
			MainViewModel vm = this.ViewModel;
			CameraNode selectedCamera = (vm != null) ? vm.SelectedCamera : null;
			CameraNode selectedCamera2 = selectedCamera;
			CameraParameterConfig selectedConfig = (selectedCamera2 != null) ? selectedCamera2.CameraConfig : null;
			List<ConnectedCameraInfo> cameras = new List<ConnectedCameraInfo>();
			this._isRefreshingConnectedCameras = true;
			try
			{
				bool flag = vm == null;
				if (flag)
				{
					this.FilteredConnectedCameras = cameras;
				}
				else
				{
					this.NormalizeDuplicateSerialAssignments();
					string currentSerial = (selectedConfig != null) ? selectedConfig.ConnectedCameraId : null;
					CameraVendor selectedVendor = (selectedConfig != null) ? selectedConfig.Vendor : CameraVendor.Unknown;
					cameras.Add(new ConnectedCameraInfo
					{
						Id = "",
						Name = "None",
						Vendor = CameraVendor.Unknown
					});
					HashSet<string> usedByOtherCameras = new HashSet<string>(from x in (from x in vm.Cameras
					where x != selectedCamera
					select x).Select(delegate(CameraNode x)
					{
						CameraParameterConfig cameraConfig = x.CameraConfig;
						return (cameraConfig != null) ? cameraConfig.ConnectedCameraId : null;
					})
					where !string.IsNullOrWhiteSpace(x)
					select x);
					foreach (ConnectedCameraInfo camera in vm.ConnectedCameras)
					{
						bool flag2 = camera == null || string.IsNullOrWhiteSpace(camera.Id);
						if (!flag2)
						{
							bool flag3 = selectedVendor != CameraVendor.Unknown && camera.Vendor != selectedVendor;
							if (!flag3)
							{
								bool flag4 = camera.Id == currentSerial || !usedByOtherCameras.Contains(camera.Id);
								if (flag4)
								{
									cameras.Add(camera);
								}
							}
						}
					}
					bool flag5 = cameras.Count == 1 && selectedVendor > CameraVendor.Unknown;
					if (flag5)
					{
						foreach (ConnectedCameraInfo camera2 in vm.ConnectedCameras)
						{
							bool flag6 = camera2 == null || string.IsNullOrWhiteSpace(camera2.Id) || usedByOtherCameras.Contains(camera2.Id);
							if (!flag6)
							{
								cameras.Add(camera2);
							}
						}
					}
					Camera_Select_UI.EnsureCurrentSerialOption(cameras, currentSerial, selectedVendor);
					this.FilteredConnectedCameras = cameras;
					base.Dispatcher.BeginInvoke(new Action(this.RefreshSerialEditorDisplay), DispatcherPriority.Background, Array.Empty<object>());
				}
			}
			finally
			{
				this._isRefreshingConnectedCameras = false;
			}
		}

		// Token: 0x06002620 RID: 9760 RVA: 0x000DDFDC File Offset: 0x000DC1DC
		private void RefreshSerialEditorDisplay()
		{
			bool isRestoringSerialDisplay = this._isRestoringSerialDisplay;
			if (!isRestoringSerialDisplay)
			{
				this._isRestoringSerialDisplay = true;
				try
				{
					ComboBoxEdit serialCombo = this.SerialCombo;
					if (serialCombo != null)
					{
						BindingExpression bindingExpression = serialCombo.GetBindingExpression(BaseEdit.EditValueProperty);
						if (bindingExpression != null)
						{
							bindingExpression.UpdateTarget();
						}
					}
				}
				finally
				{
					this._isRestoringSerialDisplay = false;
				}
			}
		}

		// Token: 0x06002621 RID: 9761 RVA: 0x000DE040 File Offset: 0x000DC240
		private static bool IsUserEdit(object sender)
		{
			ComboBoxEdit editor = sender as ComboBoxEdit;
			return editor != null && editor.IsKeyboardFocusWithin;
		}

		// Token: 0x06002622 RID: 9762 RVA: 0x000DE068 File Offset: 0x000DC268
		private static void EnsureCurrentSerialOption(IList<ConnectedCameraInfo> cameras, string currentSerial, CameraVendor selectedVendor)
		{
			bool flag = string.IsNullOrWhiteSpace(currentSerial) || cameras.Any((ConnectedCameraInfo x) => x.Id == currentSerial);
			if (!flag)
			{
				cameras.Add(new ConnectedCameraInfo
				{
					Id = currentSerial,
					Name = "Saved serial",
					Vendor = selectedVendor
				});
			}
		}

		// Token: 0x06002623 RID: 9763 RVA: 0x000DE0DC File Offset: 0x000DC2DC
		private void NormalizeDuplicateSerialAssignments()
		{
			MainViewModel vm = this.ViewModel;
			bool flag = vm == null;
			if (!flag)
			{
				HashSet<string> usedSerials = new HashSet<string>();
				foreach (CameraNode camera in vm.Cameras)
				{
					CameraParameterConfig config = (camera != null) ? camera.CameraConfig : null;
					bool flag2 = config == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
					if (!flag2)
					{
						bool flag3 = usedSerials.Add(config.ConnectedCameraId);
						if (!flag3)
						{
							config.ConnectedCameraId = null;
							config.Vendor = CameraVendor.Unknown;
						}
					}
				}
			}
		}

		// Token: 0x06002624 RID: 9764 RVA: 0x000DE198 File Offset: 0x000DC398
		private void ClearDuplicateSerialFromOtherCameras(string serial)
		{
			MainViewModel vm = this.ViewModel;
			CameraNode selectedCamera = (vm != null) ? vm.SelectedCamera : null;
			bool flag = vm == null || string.IsNullOrWhiteSpace(serial);
			if (!flag)
			{
				foreach (CameraNode camera in vm.Cameras)
				{
					bool flag2 = camera == selectedCamera;
					if (!flag2)
					{
						CameraParameterConfig config = (camera != null) ? camera.CameraConfig : null;
						bool flag3 = config == null || config.ConnectedCameraId != serial;
						if (!flag3)
						{
							config.ConnectedCameraId = null;
							config.Vendor = CameraVendor.Unknown;
						}
					}
				}
			}
		}

		// Token: 0x06002625 RID: 9765 RVA: 0x000DE258 File Offset: 0x000DC458
		private void SaveCameraConfig()
		{
			CameraModelConfigStorageService.SaveCurrentModelConfig(this.ViewModel);
		}

		// Token: 0x04000FFA RID: 4090
		private IReadOnlyList<ConnectedCameraInfo> _filteredConnectedCameras = new List<ConnectedCameraInfo>();

		// Token: 0x04000FFB RID: 4091
		private bool _isRefreshingConnectedCameras;

		// Token: 0x04000FFC RID: 4092
		private bool _isRestoringSerialDisplay;

		// Token: 0x04000FFD RID: 4093
		private bool _isRefreshingRanges;

		// Token: 0x04000FFE RID: 4094
		private double _gainMin;

		// Token: 0x04000FFF RID: 4095
		private double _gainMax = 1000.0;

		// Token: 0x04001000 RID: 4096
		private double _gainIncrement = 1.0;

		// Token: 0x04001001 RID: 4097
		private double _exposureMin;

		// Token: 0x04001002 RID: 4098
		private double _exposureMax = 1000000.0;

		// Token: 0x04001003 RID: 4099
		private double _exposureIncrement = 1000.0;
	}
}
