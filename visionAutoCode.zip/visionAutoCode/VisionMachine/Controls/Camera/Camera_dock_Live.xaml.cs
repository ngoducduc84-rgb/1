﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using HalconDotNet;
using Microsoft.Win32;
using VisionMachine.Controls.Common;
using VisionMachine.Services.Camera;
using VisionMachine.Views.Setting.Controllers;

namespace VisionMachine.Controls.Camera
{
	// Token: 0x020002B3 RID: 691
	public partial class Camera_dock_Live : UserControl
	{
		// Token: 0x060025C0 RID: 9664 RVA: 0x000DBFFC File Offset: 0x000DA1FC
		public Camera_dock_Live()
		{
			this.InitializeComponent();
			this._displayState = new CameraLiveDisplayState(this.hWindow);
			this.SubscribePixelInfo();
			this.hWindow.Tag = this._displayState;
			base.Loaded += this.Camera_dock_Live_Loaded;
			base.Unloaded += this.Camera_dock_Live_Unloaded;
		}

		// Token: 0x17000AFC RID: 2812
		// (get) Token: 0x060025C1 RID: 9665 RVA: 0x000DC068 File Offset: 0x000DA268
		public HSmartWindowControlWPF WindowControl
		{
			get
			{
				return this.hWindow;
			}
		}

		// Token: 0x060025C2 RID: 9666 RVA: 0x0000AB39 File Offset: 0x00008D39
		public void SetTitle(string title)
		{
		}

		// Token: 0x060025C3 RID: 9667 RVA: 0x000DC070 File Offset: 0x000DA270
		private void HWindow_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
		{
			this._displayState.MouseWheel(e);
		}

		// Token: 0x060025C4 RID: 9668 RVA: 0x000DC080 File Offset: 0x000DA280
		private void HWindow_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this._displayState.MouseDown(e);
		}

		// Token: 0x060025C5 RID: 9669 RVA: 0x000DC090 File Offset: 0x000DA290
		private void HWindow_MouseMove(object sender, MouseEventArgs e)
		{
			this._displayState.MouseMove(e);
		}

		// Token: 0x060025C6 RID: 9670 RVA: 0x000DC0A0 File Offset: 0x000DA2A0
		private void HWindow_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this._displayState.MouseUp(e);
		}

		// Token: 0x060025C7 RID: 9671 RVA: 0x000DC0B0 File Offset: 0x000DA2B0
		private void HWindow_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
		{
			bool flag = this.hWindow.ContextMenu == null;
			if (!flag)
			{
				this.hWindow.ContextMenu.PlacementTarget = this.hWindow;
				this.hWindow.ContextMenu.IsOpen = true;
				e.Handled = true;
			}
		}

		// Token: 0x060025C8 RID: 9672 RVA: 0x000DC104 File Offset: 0x000DA304
		private void HWindow_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			bool flag = e.ChangedButton > MouseButton.Left;
			if (!flag)
			{
				this._displayState.Fit();
				e.Handled = true;
			}
		}

		// Token: 0x060025C9 RID: 9673 RVA: 0x000DC135 File Offset: 0x000DA335
		private void SaveImage_Click(object sender, RoutedEventArgs e)
		{
			this.SaveCurrentLiveImage();
		}

		// Token: 0x060025CA RID: 9674 RVA: 0x000DC13F File Offset: 0x000DA33F
		private void DisplayState_PixelInfoChanged(string text)
		{
			this.txtPixelInfo.EditValue = text;
		}

		// Token: 0x060025CB RID: 9675 RVA: 0x000DC150 File Offset: 0x000DA350
		private void SubscribePixelInfo()
		{
			bool pixelInfoSubscribed = this._pixelInfoSubscribed;
			if (!pixelInfoSubscribed)
			{
				this._displayState.PixelInfoChanged += this.DisplayState_PixelInfoChanged;
				this._pixelInfoSubscribed = true;
			}
		}

		// Token: 0x060025CC RID: 9676 RVA: 0x000DC18C File Offset: 0x000DA38C
		private void UnsubscribePixelInfo()
		{
			bool flag = !this._pixelInfoSubscribed;
			if (!flag)
			{
				this._displayState.PixelInfoChanged -= this.DisplayState_PixelInfoChanged;
				this._pixelInfoSubscribed = false;
			}
		}

		// Token: 0x060025CD RID: 9677 RVA: 0x000DC1C8 File Offset: 0x000DA3C8
		private void Camera_dock_Live_Loaded(object sender, RoutedEventArgs e)
		{
			this.SubscribePixelInfo();
		}

		// Token: 0x060025CE RID: 9678 RVA: 0x000DC1D2 File Offset: 0x000DA3D2
		private void Camera_dock_Live_Unloaded(object sender, RoutedEventArgs e)
		{
			this.UnsubscribePixelInfo();
			this._displayState.Dispose();
		}

		// Token: 0x060025CF RID: 9679 RVA: 0x000DC1E8 File Offset: 0x000DA3E8
		private void SaveCurrentLiveImage()
		{
			bool flag = !this._displayState.HasImage;
			if (flag)
			{
				DXMessageBox.Show("No live image is available to save.", "Save Image", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				SaveFileDialog dialog = new SaveFileDialog
				{
					Title = "Save Live Image",
					Filter = "PNG Image (*.png)|*.png|Bitmap Image (*.bmp)|*.bmp|JPEG Image (*.jpg)|*.jpg|TIFF Image (*.tif)|*.tif",
					DefaultExt = ".png",
					FileName = "camera_live_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png",
					AddExtension = true,
					OverwritePrompt = true
				};
				bool flag2 = !dialog.ShowDialog().GetValueOrDefault();
				if (!flag2)
				{
					HObject image = this._displayState.GetCurrentImageCopy();
					bool flag3 = image == null || !image.IsInitialized();
					if (flag3)
					{
						DXMessageBox.Show("No live image is available to save.", "Save Image", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					}
					else
					{
						try
						{
							LoadingOverlay.Run(Window.GetWindow(this), "Saving image...", delegate
							{
								SettingDisplayController.WriteImage(image, dialog.FileName);
							});
							DXMessageBox.Show("Image saved:\n" + dialog.FileName, "Save Image", MessageBoxButton.OK, MessageBoxImage.Asterisk);
						}
						catch (Exception ex)
						{
							DXMessageBox.Show("Failed to save image: " + ex.Message, "Save Image", MessageBoxButton.OK, MessageBoxImage.Hand);
						}
						finally
						{
							try
							{
								image.Dispose();
							}
							catch
							{
							}
						}
					}
				}
			}
		}

		// Token: 0x04000FE8 RID: 4072
		private readonly CameraLiveDisplayState _displayState;

		// Token: 0x04000FE9 RID: 4073
		private bool _pixelInfoSubscribed;
	}
}
