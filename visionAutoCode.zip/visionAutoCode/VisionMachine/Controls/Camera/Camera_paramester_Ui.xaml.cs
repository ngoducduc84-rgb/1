﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.PropertyGrid;
using VisionMachine.Controls.Common;
using VisionMachine.Models.Camera;
using VisionMachine.Services.Camera;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Home;

namespace VisionMachine.Controls.Camera
{
	// Token: 0x020002B4 RID: 692
	public partial class Camera_paramester_Ui : UserControl, INotifyPropertyChanged, IStyleConnector
	{
		// Token: 0x17000AFD RID: 2813
		// (get) Token: 0x060025D2 RID: 9682 RVA: 0x000DC4F8 File Offset: 0x000DA6F8
		public ObservableCollection<string> PixelFormatOptions { get; } = new ObservableCollection<string>();

		// Token: 0x17000AFE RID: 2814
		// (get) Token: 0x060025D3 RID: 9683 RVA: 0x000DC500 File Offset: 0x000DA700
		public ObservableCollection<string> LightSourcePresetOptions { get; } = new ObservableCollection<string>();

		// Token: 0x17000AFF RID: 2815
		// (get) Token: 0x060025D4 RID: 9684 RVA: 0x000DC508 File Offset: 0x000DA708
		// (set) Token: 0x060025D5 RID: 9685 RVA: 0x000DC520 File Offset: 0x000DA720
		public IReadOnlyList<ConnectedCameraInfo> ConnectedCameraOptions
		{
			get
			{
				return this._connectedCameraOptions;
			}
			private set
			{
				this._connectedCameraOptions = (value ?? new List<ConnectedCameraInfo>());
				this.OnPropertyChanged("ConnectedCameraOptions");
			}
		}

		// Token: 0x17000B00 RID: 2816
		// (get) Token: 0x060025D6 RID: 9686 RVA: 0x000DC53F File Offset: 0x000DA73F
		public IReadOnlyList<CameraVendor> VendorOptions { get; } = new CameraVendor[]
		{
			CameraVendor.Unknown,
			CameraVendor.Basler,
			CameraVendor.Hikvision
		};

		// Token: 0x17000B01 RID: 2817
		// (get) Token: 0x060025D7 RID: 9687 RVA: 0x000DC547 File Offset: 0x000DA747
		public IReadOnlyList<string> RotationFillColorOptions { get; } = new string[]
		{
			"Black",
			"White",
			"Gray",
			"Red",
			"Green",
			"Blue",
			"Yellow",
			"Cyan",
			"Magenta"
		};

		// Token: 0x060025D8 RID: 9688 RVA: 0x000DC550 File Offset: 0x000DA750
		public Camera_paramester_Ui()
		{
			this.InitializeComponent();
			base.Loaded += this.Camera_paramester_Ui_Loaded;
			base.DataContextChanged += this.Camera_paramester_Ui_DataContextChanged;
		}

		// Token: 0x1400004E RID: 78
		// (add) Token: 0x060025D9 RID: 9689 RVA: 0x000DC61C File Offset: 0x000DA81C
		// (remove) Token: 0x060025DA RID: 9690 RVA: 0x000DC654 File Offset: 0x000DA854
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060025DB RID: 9691 RVA: 0x000DC689 File Offset: 0x000DA889
		private void OnPropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x17000B02 RID: 2818
		// (get) Token: 0x060025DC RID: 9692 RVA: 0x000DC6A8 File Offset: 0x000DA8A8
		private CameraParameterConfig CurrentConfig
		{
			get
			{
				MainViewModel vm = base.DataContext as MainViewModel;
				CameraParameterConfig result;
				if (vm == null)
				{
					result = null;
				}
				else
				{
					CameraNode selectedCamera = vm.SelectedCamera;
					result = ((selectedCamera != null) ? selectedCamera.CameraConfig : null);
				}
				return result;
			}
		}

		// Token: 0x060025DD RID: 9693 RVA: 0x000DC6DE File Offset: 0x000DA8DE
		private void Camera_paramester_Ui_Loaded(object sender, RoutedEventArgs e)
		{
			this.SubscribeSelectedCameraConfig();
			this.RefreshConnectedCameraOptions(true);
			this.RefreshPixelFormatOptions();
			this.RefreshLightSourcePresetOptions();
		}

		// Token: 0x060025DE RID: 9694 RVA: 0x000DC6FE File Offset: 0x000DA8FE
		private void Camera_paramester_Ui_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			this.SubscribeSelectedCameraConfig();
			this.RefreshConnectedCameraOptions(false);
			this.RefreshPixelFormatOptions();
			this.RefreshLightSourcePresetOptions();
		}

		// Token: 0x060025DF RID: 9695 RVA: 0x000DC71E File Offset: 0x000DA91E
		private void ConnectedCameraEditor_Loaded(object sender, RoutedEventArgs e)
		{
			this.RefreshConnectedCameraOptions(false);
		}

		// Token: 0x060025E0 RID: 9696 RVA: 0x000DC71E File Offset: 0x000DA91E
		private void ConnectedCameraEditor_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			this.RefreshConnectedCameraOptions(false);
		}

		// Token: 0x060025E1 RID: 9697 RVA: 0x000DC71E File Offset: 0x000DA91E
		private void ConnectedCameraEditor_MouseEnter(object sender, MouseEventArgs e)
		{
			this.RefreshConnectedCameraOptions(false);
		}

		// Token: 0x060025E2 RID: 9698 RVA: 0x000DC72C File Offset: 0x000DA92C
		private void Vendor_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			CameraParameterConfig config = this.CurrentConfig;
			bool flag = config == null;
			if (!flag)
			{
				bool flag2 = Camera_paramester_Ui.IsUserEdit(sender) && e.OldValue != null && !object.Equals(e.OldValue, e.NewValue);
				if (flag2)
				{
					config.ConnectedCameraId = null;
					this.SaveCameraConfig();
				}
				this.RefreshConnectedCameraOptions(false);
				this.RefreshPixelFormatOptions();
				this.RefreshLightSourcePresetOptions();
			}
		}

		// Token: 0x060025E3 RID: 9699 RVA: 0x000DC7A0 File Offset: 0x000DA9A0
		private void ConnectedCamera_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			MainViewModel vm = base.DataContext as MainViewModel;
			CameraParameterConfig config = this.CurrentConfig;
			bool flag = vm == null || config == null;
			if (!flag)
			{
				string id = e.NewValue as string;
				bool flag2 = string.IsNullOrWhiteSpace(id);
				if (flag2)
				{
					bool flag3 = Camera_paramester_Ui.IsUserEdit(sender) && !this._isRefreshingConnectedCameraOptions;
					if (flag3)
					{
						config.ConnectedCameraId = null;
						this.SaveCameraConfig();
					}
					this.RefreshConnectedCameraOptions(false);
				}
				else
				{
					ConnectedCameraInfo connected = vm.ConnectedCameras.FirstOrDefault((ConnectedCameraInfo x) => x.Id == id);
					bool flag4 = connected != null && Camera_paramester_Ui.IsUserEdit(sender) && !this._isRefreshingConnectedCameraOptions;
					if (flag4)
					{
						this.ClearDuplicateSerialFromOtherCameras(connected.Id);
						config.ConnectedCameraId = connected.Id;
						config.Vendor = connected.Vendor;
						this.SaveCameraConfig();
					}
					this.RefreshConnectedCameraOptions(false);
					this.RefreshPixelFormatOptions();
					this.RefreshLightSourcePresetOptions();
				}
			}
		}

		// Token: 0x060025E4 RID: 9700 RVA: 0x000DC8B0 File Offset: 0x000DAAB0
		private void Parameter_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			MainViewModel vm = base.DataContext as MainViewModel;
			CameraParameterConfig config;
			if (vm == null)
			{
				config = null;
			}
			else
			{
				CameraNode selectedCamera = vm.SelectedCamera;
				config = ((selectedCamera != null) ? selectedCamera.CameraConfig : null);
			}
			CameraHardwareRuntimeService.ApplyParameter(config);
		}

		// Token: 0x060025E5 RID: 9701 RVA: 0x000DC8E8 File Offset: 0x000DAAE8
		private void PixelFormatEditor_Loaded(object sender, RoutedEventArgs e)
		{
			this.RefreshPixelFormatOptions();
		}

		// Token: 0x060025E6 RID: 9702 RVA: 0x000DC8E8 File Offset: 0x000DAAE8
		private void PixelFormatEditor_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			this.RefreshPixelFormatOptions();
		}

		// Token: 0x060025E7 RID: 9703 RVA: 0x000DC8E8 File Offset: 0x000DAAE8
		private void PixelFormatEditor_MouseEnter(object sender, MouseEventArgs e)
		{
			this.RefreshPixelFormatOptions();
		}

		// Token: 0x060025E8 RID: 9704 RVA: 0x000DC8F2 File Offset: 0x000DAAF2
		private void LightSourcePresetEditor_Loaded(object sender, RoutedEventArgs e)
		{
			this.RefreshLightSourcePresetOptions();
		}

		// Token: 0x060025E9 RID: 9705 RVA: 0x000DC8F2 File Offset: 0x000DAAF2
		private void LightSourcePresetEditor_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			this.RefreshLightSourcePresetOptions();
		}

		// Token: 0x060025EA RID: 9706 RVA: 0x000DC8F2 File Offset: 0x000DAAF2
		private void LightSourcePresetEditor_MouseEnter(object sender, MouseEventArgs e)
		{
			this.RefreshLightSourcePresetOptions();
		}

		// Token: 0x060025EB RID: 9707 RVA: 0x000DC8FC File Offset: 0x000DAAFC
		private void ApplyAndSave_Click(object sender, RoutedEventArgs e)
		{
			Camera_paramester_Ui.<>c__DisplayClass39_0 CS$<>8__locals1 = new Camera_paramester_Ui.<>c__DisplayClass39_0();
			CS$<>8__locals1.vm = (base.DataContext as MainViewModel);
			Camera_paramester_Ui.<>c__DisplayClass39_0 CS$<>8__locals2 = CS$<>8__locals1;
			MainViewModel vm = CS$<>8__locals1.vm;
			CameraParameterConfig config;
			if (vm == null)
			{
				config = null;
			}
			else
			{
				CameraNode selectedCamera = vm.SelectedCamera;
				config = ((selectedCamera != null) ? selectedCamera.CameraConfig : null);
			}
			CS$<>8__locals2.config = config;
			Window owner = Window.GetWindow(this);
			CS$<>8__locals1.error = null;
			LoadingOverlay.RunOnUi(owner, "Saving camera settings...", delegate
			{
				try
				{
					CameraHardwareRuntimeService.ApplyParameter(CS$<>8__locals1.config);
					CameraModelConfigStorageService.SaveCurrentModelConfig(CS$<>8__locals1.vm);
					Form_home instance = Form_home.Instance;
					if (instance != null)
					{
						instance.RefreshHardwareTriggerCameras();
					}
				}
				catch (Exception ex)
				{
					CS$<>8__locals1.error = ex;
				}
			});
			bool flag = CS$<>8__locals1.error == null;
			if (flag)
			{
				DXMessageBox.Show(owner, "Camera settings saved successfully.", "Camera", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				DXMessageBox.Show(owner, CS$<>8__locals1.error.Message, "Camera", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}

		// Token: 0x060025EC RID: 9708 RVA: 0x000DC9AC File Offset: 0x000DABAC
		private void SubscribeSelectedCameraConfig()
		{
			bool flag = this._subscribedConfig != null;
			if (flag)
			{
				this._subscribedConfig.PropertyChanged -= this.CameraConfig_PropertyChanged;
			}
			this._subscribedConfig = this.CurrentConfig;
			bool flag2 = this._subscribedConfig != null;
			if (flag2)
			{
				this._subscribedConfig.PropertyChanged += this.CameraConfig_PropertyChanged;
			}
		}

		// Token: 0x060025ED RID: 9709 RVA: 0x000DCA10 File Offset: 0x000DAC10
		private void CameraConfig_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e.PropertyName == "ConnectedCameraId" || e.PropertyName == "Vendor";
			if (flag)
			{
				this.RefreshConnectedCameraOptions(false);
				this.RefreshPixelFormatOptions();
				this.RefreshLightSourcePresetOptions();
			}
		}

		// Token: 0x060025EE RID: 9710 RVA: 0x000DCA60 File Offset: 0x000DAC60
		private void RefreshConnectedCameraOptions(bool refreshDiscovery)
		{
			MainViewModel vm = base.DataContext as MainViewModel;
			CameraParameterConfig config = this.CurrentConfig;
			List<ConnectedCameraInfo> options = new List<ConnectedCameraInfo>();
			this._isRefreshingConnectedCameraOptions = true;
			try
			{
				bool flag = vm == null;
				if (flag)
				{
					this.ConnectedCameraOptions = options;
				}
				else
				{
					if (refreshDiscovery)
					{
						vm.RefreshConnectedCameras();
					}
					CameraNode selectedCamera = vm.SelectedCamera;
					CameraVendor selectedVendor = (config != null) ? config.Vendor : CameraVendor.Unknown;
					string currentSerial = (config != null) ? config.ConnectedCameraId : null;
					options.Add(new ConnectedCameraInfo
					{
						Id = "",
						Name = "None",
						Vendor = CameraVendor.Unknown
					});
					HashSet<string> usedByOtherCameras = new HashSet<string>(from x in (from x in vm.Cameras
					where x != selectedCamera
					select x).Select(delegate(CameraNode x)
					{
						CameraParameterConfig cameraConfig = x.CameraConfig;
						return (cameraConfig != null) ? cameraConfig.ConnectedCameraId : null;
					})
					where !string.IsNullOrWhiteSpace(x)
					select x);
					foreach (ConnectedCameraInfo camera in vm.ConnectedCameras)
					{
						bool flag2 = camera == null || string.IsNullOrWhiteSpace(camera.Id);
						if (!flag2)
						{
							bool flag3 = selectedVendor != CameraVendor.Unknown && camera.Vendor != selectedVendor;
							if (!flag3)
							{
								bool flag4 = camera.Id == currentSerial || !usedByOtherCameras.Contains(camera.Id);
								if (flag4)
								{
									options.Add(camera);
								}
							}
						}
					}
					bool flag5 = options.Count == 1 && selectedVendor > CameraVendor.Unknown;
					if (flag5)
					{
						foreach (ConnectedCameraInfo camera2 in vm.ConnectedCameras)
						{
							bool flag6 = camera2 == null || string.IsNullOrWhiteSpace(camera2.Id) || usedByOtherCameras.Contains(camera2.Id);
							if (!flag6)
							{
								options.Add(camera2);
							}
						}
					}
					Camera_paramester_Ui.EnsureCurrentSerialOption(options, currentSerial, selectedVendor);
					this.ConnectedCameraOptions = options;
				}
			}
			finally
			{
				this._isRefreshingConnectedCameraOptions = false;
			}
		}

		// Token: 0x060025EF RID: 9711 RVA: 0x000DCD0C File Offset: 0x000DAF0C
		private static bool IsUserEdit(object sender)
		{
			ComboBoxEdit editor = sender as ComboBoxEdit;
			return editor != null && editor.IsKeyboardFocusWithin;
		}

		// Token: 0x060025F0 RID: 9712 RVA: 0x000DCD34 File Offset: 0x000DAF34
		private static void EnsureCurrentSerialOption(IList<ConnectedCameraInfo> options, string currentSerial, CameraVendor selectedVendor)
		{
			bool flag = string.IsNullOrWhiteSpace(currentSerial) || options.Any((ConnectedCameraInfo x) => x.Id == currentSerial);
			if (!flag)
			{
				options.Add(new ConnectedCameraInfo
				{
					Id = currentSerial,
					Name = "Saved serial",
					Vendor = selectedVendor
				});
			}
		}

		// Token: 0x060025F1 RID: 9713 RVA: 0x000DCDA8 File Offset: 0x000DAFA8
		private void ClearDuplicateSerialFromOtherCameras(string serial)
		{
			MainViewModel vm = base.DataContext as MainViewModel;
			CameraNode selectedCamera = (vm != null) ? vm.SelectedCamera : null;
			bool flag = vm == null || string.IsNullOrWhiteSpace(serial);
			if (!flag)
			{
				foreach (CameraNode camera in vm.Cameras)
				{
					bool flag2 = camera == selectedCamera;
					if (!flag2)
					{
						CameraParameterConfig config = (camera != null) ? camera.CameraConfig : null;
						bool flag3 = config == null || config.ConnectedCameraId != serial;
						if (!flag3)
						{
							config.ConnectedCameraId = null;
							config.Vendor = CameraVendor.Unknown;
						}
					}
				}
			}
		}

		// Token: 0x060025F2 RID: 9714 RVA: 0x000DCE6C File Offset: 0x000DB06C
		private void SaveCameraConfig()
		{
			CameraModelConfigStorageService.SaveCurrentModelConfig(base.DataContext as MainViewModel);
		}

		// Token: 0x060025F3 RID: 9715 RVA: 0x000DCE80 File Offset: 0x000DB080
		private void RefreshPixelFormatOptions()
		{
			bool isRefreshingPixelFormatOptions = this._isRefreshingPixelFormatOptions;
			if (!isRefreshingPixelFormatOptions)
			{
				CameraParameterConfig config = this.CurrentConfig;
				this._isRefreshingPixelFormatOptions = true;
				Task.Run(delegate()
				{
					List<string> formats;
					try
					{
						formats = CameraHardwareRuntimeService.GetPixelFormatOptions(config);
					}
					catch
					{
						formats = null;
					}
					this.Dispatcher.BeginInvoke(new Action(delegate()
					{
						try
						{
							this.ApplyPixelFormatOptions(config, formats);
						}
						finally
						{
							this._isRefreshingPixelFormatOptions = false;
						}
					}), Array.Empty<object>());
				});
			}
		}

		// Token: 0x060025F4 RID: 9716 RVA: 0x000DCECC File Offset: 0x000DB0CC
		private void ApplyPixelFormatOptions(CameraParameterConfig config, List<string> formats)
		{
			bool flag = formats == null;
			if (flag)
			{
				formats = new List<string>();
			}
			bool flag2 = formats.Count <= 0 && !string.IsNullOrWhiteSpace((config != null) ? config.PixelFormat : null);
			if (flag2)
			{
				formats.Add(config.PixelFormat);
			}
			bool flag3 = formats.Count <= 0;
			if (flag3)
			{
				formats.Add("Mono8");
			}
			formats = (from x in (from x in formats
			where !string.IsNullOrWhiteSpace(x)
			select x).Distinct<string>()
			orderby x
			select x).ToList<string>();
			bool flag4 = this.PixelFormatOptions.SequenceEqual(formats);
			if (!flag4)
			{
				this.PixelFormatOptions.Clear();
				foreach (string format in formats)
				{
					this.PixelFormatOptions.Add(format);
				}
				bool flag5 = config != null && !string.IsNullOrWhiteSpace(config.PixelFormat) && !this.PixelFormatOptions.Contains(config.PixelFormat);
				if (flag5)
				{
					config.PixelFormat = this.PixelFormatOptions.FirstOrDefault<string>();
				}
			}
		}

		// Token: 0x060025F5 RID: 9717 RVA: 0x000DD03C File Offset: 0x000DB23C
		private void RefreshLightSourcePresetOptions()
		{
			bool isRefreshingLightSourceOptions = this._isRefreshingLightSourceOptions;
			if (!isRefreshingLightSourceOptions)
			{
				CameraParameterConfig config = this.CurrentConfig;
				this._isRefreshingLightSourceOptions = true;
				Task.Run(delegate()
				{
					List<string> presets;
					try
					{
						presets = CameraHardwareRuntimeService.GetLightSourcePresetOptions(config);
					}
					catch
					{
						presets = null;
					}
					this.Dispatcher.BeginInvoke(new Action(delegate()
					{
						try
						{
							this.ApplyLightSourcePresetOptions(config, presets);
						}
						finally
						{
							this._isRefreshingLightSourceOptions = false;
						}
					}), Array.Empty<object>());
				});
			}
		}

		// Token: 0x060025F6 RID: 9718 RVA: 0x000DD088 File Offset: 0x000DB288
		private void ApplyLightSourcePresetOptions(CameraParameterConfig config, List<string> presets)
		{
			bool flag = presets == null;
			if (flag)
			{
				presets = new List<string>();
			}
			bool flag2 = !string.IsNullOrWhiteSpace((config != null) ? config.LightSourcePreset : null) && !presets.Contains(config.LightSourcePreset);
			if (flag2)
			{
				presets.Add(config.LightSourcePreset);
			}
			bool flag3 = presets.Count <= 0;
			if (flag3)
			{
				presets.Add("");
			}
			presets = (from x in (from x in presets
			where x != null
			select x).Distinct<string>()
			orderby x
			select x).ToList<string>();
			bool flag4 = this.LightSourcePresetOptions.SequenceEqual(presets);
			if (!flag4)
			{
				this.LightSourcePresetOptions.Clear();
				foreach (string preset in presets)
				{
					this.LightSourcePresetOptions.Add(preset);
				}
				bool flag5 = config != null && !string.IsNullOrWhiteSpace(config.LightSourcePreset) && !this.LightSourcePresetOptions.Contains(config.LightSourcePreset);
				if (flag5)
				{
					config.LightSourcePreset = this.LightSourcePresetOptions.FirstOrDefault<string>();
				}
			}
		}

		// Token: 0x060025F9 RID: 9721 RVA: 0x000DD298 File Offset: 0x000DB498
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 3:
				((ComboBoxEdit)target).Loaded += this.ConnectedCameraEditor_Loaded;
				((ComboBoxEdit)target).GotKeyboardFocus += this.ConnectedCameraEditor_GotKeyboardFocus;
				((ComboBoxEdit)target).MouseEnter += this.ConnectedCameraEditor_MouseEnter;
				((ComboBoxEdit)target).EditValueChanged += this.ConnectedCamera_EditValueChanged;
				break;
			case 4:
				((ComboBoxEdit)target).EditValueChanged += this.Vendor_EditValueChanged;
				break;
			case 5:
				((ComboBoxEdit)target).Loaded += this.PixelFormatEditor_Loaded;
				((ComboBoxEdit)target).GotKeyboardFocus += this.PixelFormatEditor_GotKeyboardFocus;
				((ComboBoxEdit)target).MouseEnter += this.PixelFormatEditor_MouseEnter;
				((ComboBoxEdit)target).EditValueChanged += this.Parameter_EditValueChanged;
				break;
			case 6:
				((ComboBoxEdit)target).Loaded += this.LightSourcePresetEditor_Loaded;
				((ComboBoxEdit)target).GotKeyboardFocus += this.LightSourcePresetEditor_GotKeyboardFocus;
				((ComboBoxEdit)target).MouseEnter += this.LightSourcePresetEditor_MouseEnter;
				((ComboBoxEdit)target).EditValueChanged += this.Parameter_EditValueChanged;
				break;
			}
		}

		// Token: 0x04000FED RID: 4077
		private CameraParameterConfig _subscribedConfig;

		// Token: 0x04000FEE RID: 4078
		private IReadOnlyList<ConnectedCameraInfo> _connectedCameraOptions = new List<ConnectedCameraInfo>();

		// Token: 0x04000FEF RID: 4079
		private bool _isRefreshingConnectedCameraOptions;

		// Token: 0x04000FF5 RID: 4085
		private bool _isRefreshingPixelFormatOptions;

		// Token: 0x04000FF6 RID: 4086
		private bool _isRefreshingLightSourceOptions;
	}
}
