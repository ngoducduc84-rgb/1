﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.LayoutControl;
using VisionMachine.Models.Light;
using VisionMachine.Services.Light;
using VisionMachine.ViewModels.Main;

namespace VisionMachine.Controls.Camera
{
	// Token: 0x020002B6 RID: 694
	public partial class Light_Select_UI : UserControl
	{
		// Token: 0x06002628 RID: 9768 RVA: 0x000DE514 File Offset: 0x000DC714
		public Light_Select_UI()
		{
			this.InitializeComponent();
			base.Loaded += this.Light_Select_UI_Loaded;
			base.Unloaded += this.Light_Select_UI_Unloaded;
			base.DataContextChanged += this.Light_Select_UI_DataContextChanged;
		}

		// Token: 0x17000B07 RID: 2823
		// (get) Token: 0x06002629 RID: 9769 RVA: 0x000DE588 File Offset: 0x000DC788
		private MainViewModel ViewModel
		{
			get
			{
				return base.DataContext as MainViewModel;
			}
		}

		// Token: 0x17000B08 RID: 2824
		// (get) Token: 0x0600262A RID: 9770 RVA: 0x000DE5A8 File Offset: 0x000DC7A8
		private LightControllerConfig LightConfig
		{
			get
			{
				MainViewModel viewModel = this.ViewModel;
				return (viewModel != null) ? viewModel.LightConfig : null;
			}
		}

		// Token: 0x0600262B RID: 9771 RVA: 0x000DE5CC File Offset: 0x000DC7CC
		private void Light_Select_UI_Loaded(object sender, RoutedEventArgs e)
		{
			this.InitModeCombo();
			this.WatchViewModel(false);
			this.ReloadFromConfig();
			this.PrepareSelectedController();
		}

		// Token: 0x0600262C RID: 9772 RVA: 0x000DE5EC File Offset: 0x000DC7EC
		private void Light_Select_UI_Unloaded(object sender, RoutedEventArgs e)
		{
			this.WatchViewModel(true);
		}

		// Token: 0x0600262D RID: 9773 RVA: 0x000DE5F7 File Offset: 0x000DC7F7
		private void Light_Select_UI_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			this.WatchViewModel(false);
			this.ReloadFromConfig();
		}

		// Token: 0x0600262E RID: 9774 RVA: 0x000DE60C File Offset: 0x000DC80C
		private void WatchViewModel(bool detach = false)
		{
			INotifyPropertyChanged wanted = detach ? null : this.ViewModel;
			bool flag = this._watchedViewModel == wanted;
			if (!flag)
			{
				bool flag2 = this._watchedViewModel != null;
				if (flag2)
				{
					this._watchedViewModel.PropertyChanged -= this.ViewModel_PropertyChanged;
				}
				this._watchedViewModel = wanted;
				bool flag3 = this._watchedViewModel != null;
				if (flag3)
				{
					this._watchedViewModel.PropertyChanged += this.ViewModel_PropertyChanged;
				}
			}
		}

		// Token: 0x0600262F RID: 9775 RVA: 0x000DE688 File Offset: 0x000DC888
		private void ViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e == null || e.PropertyName != "LightConfig";
			if (!flag)
			{
				bool flag2 = base.Dispatcher.CheckAccess();
				if (flag2)
				{
					this.ReloadFromConfig();
				}
				else
				{
					base.Dispatcher.BeginInvoke(new Action(this.ReloadFromConfig), Array.Empty<object>());
				}
			}
		}

		// Token: 0x06002630 RID: 9776 RVA: 0x000DE6E7 File Offset: 0x000DC8E7
		private void ReloadFromConfig()
		{
			this.RefreshLightListBinding();
			this.PopulateChannels();
			this.LoadChannelEditors();
			this.UpdateChannelSelectorVisibility();
		}

		// Token: 0x06002631 RID: 9777 RVA: 0x000DE708 File Offset: 0x000DC908
		private void InitModeCombo()
		{
			bool flag = this.ModeCombo.ItemsSource != null;
			if (!flag)
			{
				this.ModeCombo.DisplayMember = "DisplayName";
				this.ModeCombo.ItemsSource = new List<Light_Select_UI.LightModeOption>
				{
					new Light_Select_UI.LightModeOption
					{
						Mode = LightChannelMode.Manual,
						DisplayName = "Manual"
					},
					new Light_Select_UI.LightModeOption
					{
						Mode = LightChannelMode.OnWhenTrigger,
						DisplayName = "On when camera trigger"
					}
				};
			}
		}

		// Token: 0x06002632 RID: 9778 RVA: 0x000DE78C File Offset: 0x000DC98C
		private void LightCombo_PopupOpened(object sender, RoutedEventArgs e)
		{
			MainViewModel viewModel = this.ViewModel;
			if (viewModel != null)
			{
				viewModel.RefreshConnectedLights(new Action(this.RefreshLightListBinding));
			}
		}

		// Token: 0x06002633 RID: 9779 RVA: 0x000DE78C File Offset: 0x000DC98C
		private void RefreshLights_Click(object sender, RoutedEventArgs e)
		{
			MainViewModel viewModel = this.ViewModel;
			if (viewModel != null)
			{
				viewModel.RefreshConnectedLights(new Action(this.RefreshLightListBinding));
			}
		}

		// Token: 0x06002634 RID: 9780 RVA: 0x000DE7B0 File Offset: 0x000DC9B0
		private void RefreshLightListBinding()
		{
			MainViewModel vm = this.ViewModel;
			LightControllerConfig config = this.LightConfig;
			bool flag = vm == null;
			if (!flag)
			{
				List<ConnectedLightInfo> items = new List<ConnectedLightInfo>
				{
					new ConnectedLightInfo
					{
						Id = "",
						Name = "None"
					}
				};
				foreach (ConnectedLightInfo light in vm.ConnectedLights)
				{
					bool flag2 = light == null || string.IsNullOrWhiteSpace(light.Id);
					if (!flag2)
					{
						items.Add(light);
					}
				}
				string savedSerial = (config != null) ? config.SerialNumber : null;
				bool flag3 = !string.IsNullOrWhiteSpace(savedSerial) && items.All((ConnectedLightInfo x) => x.Id != savedSerial);
				if (flag3)
				{
					items.Add(new ConnectedLightInfo
					{
						Id = savedSerial,
						Name = "Saved controller"
					});
				}
				this._isUpdatingEditors = true;
				try
				{
					this.LightCombo.ItemsSource = items;
					this.LightCombo.SelectedItem = items.FirstOrDefault((ConnectedLightInfo x) => x.Id == (savedSerial ?? string.Empty));
				}
				finally
				{
					this._isUpdatingEditors = false;
				}
			}
		}

		// Token: 0x06002635 RID: 9781 RVA: 0x000DE920 File Offset: 0x000DCB20
		private void LightCombo_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool isUpdatingEditors = this._isUpdatingEditors;
			if (!isUpdatingEditors)
			{
				LightControllerConfig config = this.LightConfig;
				bool flag = config == null;
				if (!flag)
				{
					ConnectedLightInfo selected = this.LightCombo.SelectedItem as ConnectedLightInfo;
					config.SerialNumber = (((selected != null) ? selected.Id : null) ?? string.Empty);
					this.PopulateChannels();
					this.LoadChannelEditors();
					this.UpdateChannelSelectorVisibility();
					this.PrepareSelectedController();
				}
			}
		}

		// Token: 0x06002636 RID: 9782 RVA: 0x000DE994 File Offset: 0x000DCB94
		private int GetChannelCount()
		{
			LightControllerConfig config = this.LightConfig;
			bool flag = config == null || string.IsNullOrWhiteSpace(config.SerialNumber);
			int result;
			if (flag)
			{
				result = 4;
			}
			else
			{
				MainViewModel viewModel = this.ViewModel;
				ConnectedLightInfo info = (viewModel != null) ? viewModel.ConnectedLights.FirstOrDefault((ConnectedLightInfo x) => x.Id == config.SerialNumber) : null;
				int count = (info != null) ? info.ChannelCount : 4;
				result = ((count > 0) ? count : 4);
			}
			return result;
		}

		// Token: 0x06002637 RID: 9783 RVA: 0x000DEA18 File Offset: 0x000DCC18
		private void PopulateChannels()
		{
			int count = this.GetChannelCount();
			List<int> channels = Enumerable.Range(0, count).ToList<int>();
			LightControllerConfig lightConfig = this.LightConfig;
			int selected = (lightConfig != null) ? lightConfig.SelectedChannel : 0;
			bool flag = selected < 0 || selected >= count;
			if (flag)
			{
				selected = 0;
			}
			this._isUpdatingEditors = true;
			try
			{
				this.ChannelCombo.ItemsSource = channels;
				this.ChannelCombo.EditValue = selected;
			}
			finally
			{
				this._isUpdatingEditors = false;
			}
			bool flag2 = this.LightConfig != null;
			if (flag2)
			{
				this.LightConfig.SelectedChannel = selected;
			}
			this.UpdateChannelSelectorVisibility();
		}

		// Token: 0x06002638 RID: 9784 RVA: 0x000DEAC8 File Offset: 0x000DCCC8
		private void ChannelCombo_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool isUpdatingEditors = this._isUpdatingEditors;
			if (!isUpdatingEditors)
			{
				LightControllerConfig config = this.LightConfig;
				bool flag = config == null;
				if (!flag)
				{
					object editValue = this.ChannelCombo.EditValue;
					int channel;
					bool flag2;
					if (editValue is int)
					{
						channel = (int)editValue;
						flag2 = true;
					}
					else
					{
						flag2 = false;
					}
					bool flag3 = flag2;
					if (flag3)
					{
						config.SelectedChannel = channel;
						this.LoadChannelEditors();
					}
				}
			}
		}

		// Token: 0x06002639 RID: 9785 RVA: 0x000DEB2C File Offset: 0x000DCD2C
		private void ApplyAllCheck_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool isUpdatingEditors = this._isUpdatingEditors;
			if (!isUpdatingEditors)
			{
				LightControllerConfig config = this.LightConfig;
				bool flag = config == null;
				if (!flag)
				{
					config.ApplyToAllChannels = this.IsApplyAllEnabled();
					bool applyToAllChannels = config.ApplyToAllChannels;
					if (applyToAllChannels)
					{
						this.SyncCurrentChannelToAll();
						this.ApplyCurrentChannel(0);
					}
					this.UpdateChannelSelectorVisibility();
					this.LoadChannelEditors();
				}
			}
		}

		// Token: 0x17000B09 RID: 2825
		// (get) Token: 0x0600263A RID: 9786 RVA: 0x000DEB90 File Offset: 0x000DCD90
		private LightChannelConfig CurrentChannel
		{
			get
			{
				LightControllerConfig config = this.LightConfig;
				return (config != null) ? config.GetOrCreateChannel(config.SelectedChannel) : null;
			}
		}

		// Token: 0x0600263B RID: 9787 RVA: 0x000DEBBC File Offset: 0x000DCDBC
		private void LoadChannelEditors()
		{
			LightChannelConfig channel = this.CurrentChannel;
			bool flag = channel == null;
			if (!flag)
			{
				LightControllerConfig lightConfig = this.LightConfig;
				LightControllerRuntimeService.GetBrightnessRange((lightConfig != null) ? lightConfig.SerialNumber : null, out this._brightnessMin, out this._brightnessMax);
				this._brightnessIncrement = Light_Select_UI.ComputeIncrement(this._brightnessMin, this._brightnessMax);
				this._isUpdatingEditors = true;
				try
				{
					Light_Select_UI.ApplyTrackRange(this.BrightnessTrack, this._brightnessMin, this._brightnessMax);
					List<Light_Select_UI.LightModeOption> options = this.ModeCombo.ItemsSource as List<Light_Select_UI.LightModeOption>;
					this.ModeCombo.SelectedItem = ((options != null) ? options.FirstOrDefault((Light_Select_UI.LightModeOption o) => o.Mode == channel.Mode) : null);
					double clamped = Light_Select_UI.Clamp(channel.Brightness, this._brightnessMin, this._brightnessMax);
					channel.Brightness = clamped;
					BaseEdit applyAllCheck = this.ApplyAllCheck;
					LightControllerConfig lightConfig2 = this.LightConfig;
					applyAllCheck.EditValue = (lightConfig2 != null && lightConfig2.ApplyToAllChannels);
					this.BrightnessTrack.EditValue = clamped;
					this.BrightnessText.Text = clamped.ToString("0", CultureInfo.InvariantCulture);
				}
				finally
				{
					this._isUpdatingEditors = false;
				}
				this.UpdateChannelSelectorVisibility();
				this.UpdateManualControls();
			}
		}

		// Token: 0x0600263C RID: 9788 RVA: 0x000DED28 File Offset: 0x000DCF28
		private void UpdateManualControls()
		{
			LightChannelConfig channel = this.CurrentChannel;
			bool manual = channel != null && channel.Mode == LightChannelMode.Manual;
			this.ManualControlItem.Visibility = (manual ? Visibility.Visible : Visibility.Collapsed);
			bool flag = channel == null;
			if (!flag)
			{
				this._isUpdatingEditors = true;
				try
				{
					this.ManualOnCheck.EditValue = (manual && channel.IsOn);
				}
				finally
				{
					this._isUpdatingEditors = false;
				}
			}
		}

		// Token: 0x0600263D RID: 9789 RVA: 0x000DEDAC File Offset: 0x000DCFAC
		private void ModeCombo_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool isUpdatingEditors = this._isUpdatingEditors;
			if (!isUpdatingEditors)
			{
				LightChannelConfig channel = this.CurrentChannel;
				Light_Select_UI.LightModeOption option = this.ModeCombo.SelectedItem as Light_Select_UI.LightModeOption;
				bool flag = channel == null || option == null;
				if (!flag)
				{
					channel.Mode = option.Mode;
					bool flag2 = this.IsApplyAllEnabled();
					if (flag2)
					{
						this.SyncCurrentChannelToAll();
					}
					this.UpdateManualControls();
					this.ApplyCurrentChannel(0);
				}
			}
		}

		// Token: 0x0600263E RID: 9790 RVA: 0x000DEE20 File Offset: 0x000DD020
		private void ManualOnCheck_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool isUpdatingEditors = this._isUpdatingEditors;
			if (!isUpdatingEditors)
			{
				this.SetManualState((this.ManualOnCheck.EditValue as bool?).GetValueOrDefault());
			}
		}

		// Token: 0x0600263F RID: 9791 RVA: 0x000DEE60 File Offset: 0x000DD060
		private void SetManualState(bool on)
		{
			LightChannelConfig channel = this.CurrentChannel;
			bool flag = channel == null;
			if (!flag)
			{
				channel.Mode = LightChannelMode.Manual;
				channel.IsOn = on;
				bool flag2 = this.IsApplyAllEnabled();
				if (flag2)
				{
					this.SyncCurrentChannelToAll();
				}
				this.UpdateManualControls();
				this.ApplyCurrentChannel(0);
				LightModelConfigStorageService.SaveCurrentModelConfig(this.ViewModel);
			}
		}

		// Token: 0x06002640 RID: 9792 RVA: 0x000DEEBC File Offset: 0x000DD0BC
		private void BrightnessText_TextChanged(object sender, TextChangedEventArgs e)
		{
			bool isUpdatingEditors = this._isUpdatingEditors;
			if (!isUpdatingEditors)
			{
				TextBox textBox = sender as TextBox;
				bool flag = textBox == null || !textBox.IsKeyboardFocusWithin;
				if (!flag)
				{
					double value;
					bool flag2 = !Light_Select_UI.TryParse(textBox.Text, out value);
					if (!flag2)
					{
						this.SetBrightness(value, false, true);
					}
				}
			}
		}

		// Token: 0x06002641 RID: 9793 RVA: 0x000DEF14 File Offset: 0x000DD114
		private void BrightnessText_LostFocus(object sender, RoutedEventArgs e)
		{
			LightChannelConfig channel = this.CurrentChannel;
			bool flag = channel == null;
			if (!flag)
			{
				this.SetBrightness(channel.Brightness, true, true);
			}
		}

		// Token: 0x06002642 RID: 9794 RVA: 0x000DEF44 File Offset: 0x000DD144
		private void BrightnessTrack_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool isUpdatingEditors = this._isUpdatingEditors;
			if (!isUpdatingEditors)
			{
				double value;
				bool flag = Light_Select_UI.TryParse(this.BrightnessTrack.EditValue, out value);
				if (flag)
				{
					this.SetBrightness(value, true, false);
				}
			}
		}

		// Token: 0x06002643 RID: 9795 RVA: 0x000DEF7E File Offset: 0x000DD17E
		private void BrightnessUp_Click(object sender, RoutedEventArgs e)
		{
			this.StepBrightness(1);
		}

		// Token: 0x06002644 RID: 9796 RVA: 0x000DEF89 File Offset: 0x000DD189
		private void BrightnessDown_Click(object sender, RoutedEventArgs e)
		{
			this.StepBrightness(-1);
		}

		// Token: 0x06002645 RID: 9797 RVA: 0x000DEF94 File Offset: 0x000DD194
		private void StepBrightness(int direction)
		{
			LightChannelConfig channel = this.CurrentChannel;
			bool flag = channel == null;
			if (!flag)
			{
				double step = (this._brightnessIncrement <= 0.0) ? 1.0 : this._brightnessIncrement;
				this.SetBrightness(channel.Brightness + (double)direction * step, true, true);
			}
		}

		// Token: 0x06002646 RID: 9798 RVA: 0x000DEFEC File Offset: 0x000DD1EC
		private void SetBrightness(double value, bool updateText, bool updateTrack = true)
		{
			LightChannelConfig channel = this.CurrentChannel;
			bool flag = channel == null;
			if (!flag)
			{
				double clamped = Light_Select_UI.Clamp(value, this._brightnessMin, this._brightnessMax);
				channel.Brightness = clamped;
				bool flag2 = this.IsApplyAllEnabled();
				if (flag2)
				{
					this.SyncCurrentChannelToAll();
				}
				this._isUpdatingEditors = true;
				try
				{
					if (updateTrack)
					{
						this.BrightnessTrack.EditValue = clamped;
					}
					if (updateText)
					{
						this.BrightnessText.Text = clamped.ToString("0", CultureInfo.InvariantCulture);
					}
				}
				finally
				{
					this._isUpdatingEditors = false;
				}
				this.ApplyCurrentChannel(100);
			}
		}

		// Token: 0x06002647 RID: 9799 RVA: 0x000DF0A8 File Offset: 0x000DD2A8
		private void ApplyCurrentChannel(int debounceMs = 0)
		{
			LightControllerConfig config = this.LightConfig;
			bool flag = config == null || string.IsNullOrWhiteSpace(config.SerialNumber);
			if (!flag)
			{
				LightControllerRuntimeService.QueueUiApply(config, config.SelectedChannel, config.ApplyToAllChannels, debounceMs);
			}
		}

		// Token: 0x06002648 RID: 9800 RVA: 0x000DF0E8 File Offset: 0x000DD2E8
		private void PrepareSelectedController()
		{
			LightControllerConfig lightConfig = this.LightConfig;
			string serialNumber = (lightConfig != null) ? lightConfig.SerialNumber : null;
			bool flag = !string.IsNullOrWhiteSpace(serialNumber);
			if (flag)
			{
				LightControllerRuntimeService.ConnectAsync(serialNumber);
			}
		}

		// Token: 0x06002649 RID: 9801 RVA: 0x000DF120 File Offset: 0x000DD320
		[DebuggerStepThrough]
		private void SaveLight_Click(object sender, RoutedEventArgs e)
		{
			Light_Select_UI.<SaveLight_Click>d__42 <SaveLight_Click>d__ = new Light_Select_UI.<SaveLight_Click>d__42();
			<SaveLight_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<SaveLight_Click>d__.<>4__this = this;
			<SaveLight_Click>d__.sender = sender;
			<SaveLight_Click>d__.e = e;
			<SaveLight_Click>d__.<>1__state = -1;
			<SaveLight_Click>d__.<>t__builder.Start<Light_Select_UI.<SaveLight_Click>d__42>(ref <SaveLight_Click>d__);
		}

		// Token: 0x0600264A RID: 9802 RVA: 0x000DF168 File Offset: 0x000DD368
		private static void ApplyTrackRange(TrackBarEdit track, double min, double max)
		{
			bool flag = track == null || max <= min;
			if (!flag)
			{
				track.Minimum = min;
				track.Maximum = max;
				track.TickFrequency = Light_Select_UI.ComputeTickFrequency(min, max);
			}
		}

		// Token: 0x0600264B RID: 9803 RVA: 0x000DF1A8 File Offset: 0x000DD3A8
		private static double ComputeTickFrequency(double min, double max)
		{
			double span = max - min;
			bool flag = span <= 0.0;
			double result;
			if (flag)
			{
				result = 1.0;
			}
			else
			{
				double frequency = span / 100.0;
				result = ((frequency < 1.0) ? 1.0 : frequency);
			}
			return result;
		}

		// Token: 0x0600264C RID: 9804 RVA: 0x000DF204 File Offset: 0x000DD404
		private static double ComputeIncrement(double min, double max)
		{
			double span = max - min;
			bool flag = span <= 0.0;
			double result;
			if (flag)
			{
				result = 1.0;
			}
			else
			{
				double step = Math.Round(span / 100.0);
				result = ((step < 1.0) ? 1.0 : step);
			}
			return result;
		}

		// Token: 0x0600264D RID: 9805 RVA: 0x000DF264 File Offset: 0x000DD464
		private static double Clamp(double value, double min, double max)
		{
			bool flag = value < min;
			double result;
			if (flag)
			{
				result = min;
			}
			else
			{
				bool flag2 = value > max;
				if (flag2)
				{
					result = max;
				}
				else
				{
					result = value;
				}
			}
			return result;
		}

		// Token: 0x0600264E RID: 9806 RVA: 0x000DF290 File Offset: 0x000DD490
		private bool IsApplyAllEnabled()
		{
			bool value;
			bool flag;
			if (this.ApplyAllCheck != null)
			{
				object editValue = this.ApplyAllCheck.EditValue;
				if (editValue is bool)
				{
					value = (bool)editValue;
					flag = true;
				}
				else
				{
					flag = false;
				}
			}
			else
			{
				flag = false;
			}
			return flag && value;
		}

		// Token: 0x0600264F RID: 9807 RVA: 0x000DF2D0 File Offset: 0x000DD4D0
		private void UpdateChannelSelectorVisibility()
		{
			bool flag = this.ChannelLayoutItem == null;
			if (!flag)
			{
				this.ChannelLayoutItem.Visibility = ((this.LightConfig != null && this.LightConfig.ApplyToAllChannels) ? Visibility.Collapsed : Visibility.Visible);
			}
		}

		// Token: 0x06002650 RID: 9808 RVA: 0x000DF314 File Offset: 0x000DD514
		private IEnumerable<int> GetChannelIndices()
		{
			int count = this.GetChannelCount();
			bool flag = count <= 0;
			if (flag)
			{
				count = 4;
			}
			return Enumerable.Range(0, count);
		}

		// Token: 0x06002651 RID: 9809 RVA: 0x000DF344 File Offset: 0x000DD544
		private void SyncCurrentChannelToAll()
		{
			LightControllerConfig config = this.LightConfig;
			LightChannelConfig source = this.CurrentChannel;
			bool flag = config == null || source == null;
			if (!flag)
			{
				foreach (int channelIndex in this.GetChannelIndices())
				{
					LightChannelConfig target = config.GetOrCreateChannel(channelIndex);
					target.Mode = source.Mode;
					target.IsOn = source.IsOn;
					target.Brightness = source.Brightness;
				}
			}
		}

		// Token: 0x06002652 RID: 9810 RVA: 0x000DF3E4 File Offset: 0x000DD5E4
		private static bool TryParse(object value, out double result)
		{
			result = 0.0;
			bool flag = value == null;
			return !flag && (double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out result) || double.TryParse(value.ToString(), out result));
		}

		// Token: 0x0400100E RID: 4110
		private double _brightnessMin;

		// Token: 0x0400100F RID: 4111
		private double _brightnessMax = 255.0;

		// Token: 0x04001010 RID: 4112
		private double _brightnessIncrement = 1.0;

		// Token: 0x04001011 RID: 4113
		private bool _isUpdatingEditors;

		// Token: 0x04001012 RID: 4114
		private INotifyPropertyChanged _watchedViewModel;

		// Token: 0x020004E9 RID: 1257
		private sealed class LightModeOption
		{
			// Token: 0x17000BA0 RID: 2976
			// (get) Token: 0x06002DB9 RID: 11705 RVA: 0x000EE64C File Offset: 0x000EC84C
			// (set) Token: 0x06002DBA RID: 11706 RVA: 0x000EE654 File Offset: 0x000EC854
			public LightChannelMode Mode { get; set; }

			// Token: 0x17000BA1 RID: 2977
			// (get) Token: 0x06002DBB RID: 11707 RVA: 0x000EE65D File Offset: 0x000EC85D
			// (set) Token: 0x06002DBC RID: 11708 RVA: 0x000EE665 File Offset: 0x000EC865
			public string DisplayName { get; set; }
		}
	}
}
