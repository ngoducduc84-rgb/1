﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;

namespace VisionMachine.Controls.Common
{
	// Token: 0x020002AA RID: 682
	public partial class LoadingOverlay : UserControl
	{
		// Token: 0x06002556 RID: 9558 RVA: 0x000D9B2C File Offset: 0x000D7D2C
		public LoadingOverlay()
		{
			this.InitializeComponent();
		}

		// Token: 0x17000AEC RID: 2796
		// (get) Token: 0x06002557 RID: 9559 RVA: 0x000D9B40 File Offset: 0x000D7D40
		// (set) Token: 0x06002558 RID: 9560 RVA: 0x000D9B62 File Offset: 0x000D7D62
		public string Message
		{
			get
			{
				return (string)base.GetValue(LoadingOverlay.MessageProperty);
			}
			set
			{
				base.SetValue(LoadingOverlay.MessageProperty, value);
			}
		}

		// Token: 0x06002559 RID: 9561 RVA: 0x000D9B74 File Offset: 0x000D7D74
		public static void Run(Window owner, string message, Action work)
		{
			bool flag = work == null;
			if (!flag)
			{
				Window host = LoadingOverlay.BuildHost(owner, message);
				Exception error = null;
				Action <>9__1;
				Action <>9__3;
				Action<Task> <>9__2;
				host.Loaded += delegate(object s, RoutedEventArgs e)
				{
					Action action;
					if ((action = <>9__1) == null)
					{
						action = (<>9__1 = delegate()
						{
							try
							{
								work();
							}
							catch (Exception ex)
							{
								error = ex;
							}
						});
					}
					Task task = Task.Run(action);
					Action<Task> continuationAction;
					if ((continuationAction = <>9__2) == null)
					{
						continuationAction = (<>9__2 = delegate(Task t)
						{
							Dispatcher dispatcher = host.Dispatcher;
							Action callback;
							if ((callback = <>9__3) == null)
							{
								callback = (<>9__3 = delegate()
								{
									bool isLoaded = host.IsLoaded;
									if (isLoaded)
									{
										host.Close();
									}
								});
							}
							dispatcher.Invoke(callback);
						});
					}
					task.ContinueWith(continuationAction);
				};
				host.ShowDialog();
				bool flag2 = error != null;
				if (flag2)
				{
					throw error;
				}
			}
		}

		// Token: 0x0600255A RID: 9562 RVA: 0x000D9BEC File Offset: 0x000D7DEC
		public static void RunOnUi(Window owner, string message, Action uiWork)
		{
			bool flag = uiWork == null;
			if (!flag)
			{
				double left = 0.0;
				double top = 0.0;
				double width = 480.0;
				double height = 320.0;
				bool hasOwnerBounds = false;
				Window validOwner = LoadingOverlay.GetValidOwner(owner);
				bool flag2 = validOwner != null;
				if (flag2)
				{
					try
					{
						left = validOwner.Left;
						top = validOwner.Top;
						width = ((validOwner.ActualWidth > 0.0) ? validOwner.ActualWidth : validOwner.Width);
						height = ((validOwner.ActualHeight > 0.0) ? validOwner.ActualHeight : validOwner.Height);
						hasOwnerBounds = (!double.IsNaN(left) && !double.IsNaN(top) && width > 0.0 && height > 0.0);
					}
					catch
					{
					}
				}
				Window host = null;
				Dispatcher overlayDispatcher = null;
				ManualResetEventSlim ready = new ManualResetEventSlim(false);
				RoutedEventHandler <>9__5;
				Thread thread = new Thread(delegate()
				{
					LoadingOverlay overlay = new LoadingOverlay
					{
						Message = message
					};
					FrameworkElement host = new Window
					{
						Content = overlay,
						WindowStyle = WindowStyle.None,
						AllowsTransparency = true,
						Background = Brushes.Transparent,
						ShowInTaskbar = false,
						Topmost = true,
						ResizeMode = ResizeMode.NoResize
					};
					bool hasOwnerBounds = hasOwnerBounds;
					if (hasOwnerBounds)
					{
						host.WindowStartupLocation = WindowStartupLocation.Manual;
						host.Left = left;
						host.Top = top;
						host.Width = width;
						host.Height = height;
					}
					else
					{
						host.WindowStartupLocation = WindowStartupLocation.CenterScreen;
						host.Width = width;
						host.Height = height;
					}
					overlayDispatcher = Dispatcher.CurrentDispatcher;
					host = host;
					RoutedEventHandler value;
					if ((value = <>9__5) == null)
					{
						value = (<>9__5 = delegate(object s, RoutedEventArgs e)
						{
							ready.Set();
						});
					}
					host.Loaded += value;
					host.Show();
					Dispatcher.Run();
				});
				thread.SetApartmentState(ApartmentState.STA);
				thread.IsBackground = true;
				thread.Start();
				ready.Wait(2000);
				Dispatcher mainDispatcher = Dispatcher.CurrentDispatcher;
				try
				{
					uiWork();
					mainDispatcher.Invoke(delegate()
					{
					}, DispatcherPriority.Render);
					mainDispatcher.Invoke(delegate()
					{
					}, DispatcherPriority.Loaded);
					mainDispatcher.Invoke(delegate()
					{
					}, DispatcherPriority.ContextIdle);
				}
				finally
				{
					bool flag3 = overlayDispatcher != null;
					if (flag3)
					{
						try
						{
							overlayDispatcher.Invoke(delegate()
							{
								try
								{
									Window host = host;
									if (host != null)
									{
										host.Close();
									}
								}
								catch
								{
								}
							});
						}
						catch
						{
						}
						overlayDispatcher.InvokeShutdown();
					}
				}
			}
		}

		// Token: 0x0600255B RID: 9563 RVA: 0x000D9E64 File Offset: 0x000D8064
		public static void PrewarmShared()
		{
			LoadingOverlay.EnsureSharedThread();
		}

		// Token: 0x0600255C RID: 9564 RVA: 0x000D9E70 File Offset: 0x000D8070
		public static void ShowShared(Window owner, string message)
		{
			LoadingOverlay.EnsureSharedThread();
			Dispatcher dispatcher = LoadingOverlay._sharedDispatcher;
			bool flag = dispatcher == null;
			if (!flag)
			{
				double left = double.NaN;
				double top = double.NaN;
				double width = 0.0;
				double height = 0.0;
				Window validOwner = LoadingOverlay.GetValidOwner(owner);
				bool flag2 = validOwner != null;
				if (flag2)
				{
					try
					{
						left = validOwner.Left;
						top = validOwner.Top;
						width = ((validOwner.ActualWidth > 0.0) ? validOwner.ActualWidth : validOwner.Width);
						height = ((validOwner.ActualHeight > 0.0) ? validOwner.ActualHeight : validOwner.Height);
					}
					catch
					{
					}
				}
				dispatcher.BeginInvoke(new Action(delegate()
				{
					try
					{
						bool flag3 = LoadingOverlay._sharedContent != null;
						if (flag3)
						{
							LoadingOverlay._sharedContent.Message = message;
						}
						bool flag4 = !double.IsNaN(left) && !double.IsNaN(top) && width > 0.0 && height > 0.0;
						if (flag4)
						{
							LoadingOverlay._sharedWindow.WindowStartupLocation = WindowStartupLocation.Manual;
							LoadingOverlay._sharedWindow.Left = left;
							LoadingOverlay._sharedWindow.Top = top;
							LoadingOverlay._sharedWindow.Width = width;
							LoadingOverlay._sharedWindow.Height = height;
						}
						else
						{
							LoadingOverlay._sharedWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
						}
						LoadingOverlay._sharedWindow.Show();
						LoadingOverlay._sharedWindow.Topmost = true;
					}
					catch
					{
					}
				}), Array.Empty<object>());
			}
		}

		// Token: 0x0600255D RID: 9565 RVA: 0x000D9F88 File Offset: 0x000D8188
		public static void HideShared()
		{
			Dispatcher dispatcher = LoadingOverlay._sharedDispatcher;
			bool flag = dispatcher == null;
			if (!flag)
			{
				dispatcher.BeginInvoke(new Action(delegate()
				{
					try
					{
						Window sharedWindow = LoadingOverlay._sharedWindow;
						if (sharedWindow != null)
						{
							sharedWindow.Hide();
						}
					}
					catch
					{
					}
				}), Array.Empty<object>());
			}
		}

		// Token: 0x0600255E RID: 9566 RVA: 0x000D9FD4 File Offset: 0x000D81D4
		private static void EnsureSharedThread()
		{
			object sharedSync = LoadingOverlay._sharedSync;
			bool flag = false;
			try
			{
				Monitor.Enter(sharedSync, ref flag);
				bool flag2 = LoadingOverlay._sharedDispatcher != null;
				if (!flag2)
				{
					ManualResetEventSlim ready = new ManualResetEventSlim(false);
					Thread thread = new Thread(delegate()
					{
						LoadingOverlay._sharedContent = new LoadingOverlay
						{
							Message = "Please wait..."
						};
						LoadingOverlay._sharedWindow = new Window
						{
							Content = LoadingOverlay._sharedContent,
							WindowStyle = WindowStyle.None,
							AllowsTransparency = true,
							Background = Brushes.Transparent,
							ShowInTaskbar = false,
							Topmost = true,
							ResizeMode = ResizeMode.NoResize,
							WindowStartupLocation = WindowStartupLocation.CenterScreen,
							Width = 480.0,
							Height = 320.0,
							ShowActivated = false
						};
						LoadingOverlay._sharedDispatcher = Dispatcher.CurrentDispatcher;
						ready.Set();
						Dispatcher.Run();
					});
					thread.SetApartmentState(ApartmentState.STA);
					thread.IsBackground = true;
					thread.Start();
					ready.Wait(3000);
				}
			}
			finally
			{
				if (flag)
				{
					Monitor.Exit(sharedSync);
				}
			}
		}

		// Token: 0x0600255F RID: 9567 RVA: 0x000DA070 File Offset: 0x000D8270
		public static void FlashOnUi(Window owner, string message)
		{
			Window host = LoadingOverlay.BuildHost(owner, message);
			host.Show();
			host.Dispatcher.Invoke(delegate()
			{
			}, DispatcherPriority.Render);
			host.Dispatcher.BeginInvoke(new Action(delegate()
			{
				try
				{
					bool isLoaded = host.IsLoaded;
					if (isLoaded)
					{
						host.Close();
					}
				}
				catch
				{
				}
			}), DispatcherPriority.ContextIdle, Array.Empty<object>());
		}

		// Token: 0x06002560 RID: 9568 RVA: 0x000DA0F4 File Offset: 0x000D82F4
		private static Window BuildHost(Window owner, string message)
		{
			LoadingOverlay overlay = new LoadingOverlay
			{
				Message = message
			};
			Window host = new Window
			{
				Content = overlay,
				WindowStyle = WindowStyle.None,
				AllowsTransparency = true,
				Background = Brushes.Transparent,
				ShowInTaskbar = false,
				Topmost = true,
				ResizeMode = ResizeMode.NoResize,
				WindowStartupLocation = WindowStartupLocation.CenterOwner
			};
			Window validOwner = LoadingOverlay.GetValidOwner(owner);
			bool flag = validOwner != null;
			if (flag)
			{
				host.Owner = validOwner;
				host.Width = ((validOwner.ActualWidth > 0.0) ? validOwner.ActualWidth : 480.0);
				host.Height = ((validOwner.ActualHeight > 0.0) ? validOwner.ActualHeight : 320.0);
			}
			else
			{
				host.Width = 480.0;
				host.Height = 320.0;
				host.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			}
			return host;
		}

		// Token: 0x06002561 RID: 9569 RVA: 0x000DA1F8 File Offset: 0x000D83F8
		private static Window GetValidOwner(Window candidate)
		{
			return WindowOwnerHelper.GetValidOwner(candidate);
		}

		// Token: 0x04000FBB RID: 4027
		public static readonly DependencyProperty MessageProperty = DependencyProperty.Register("Message", typeof(string), typeof(LoadingOverlay), new PropertyMetadata("Please wait..."));

		// Token: 0x04000FBC RID: 4028
		private static Window _sharedWindow;

		// Token: 0x04000FBD RID: 4029
		private static Dispatcher _sharedDispatcher;

		// Token: 0x04000FBE RID: 4030
		private static LoadingOverlay _sharedContent;

		// Token: 0x04000FBF RID: 4031
		private static readonly object _sharedSync = new object();
	}
}
