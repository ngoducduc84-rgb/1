﻿using System;
using System.Windows;

namespace VisionMachine.Controls.Common
{
	// Token: 0x020002A9 RID: 681
	public static class WindowOwnerHelper
	{
		// Token: 0x06002554 RID: 9556 RVA: 0x000D9A2C File Offset: 0x000D7C2C
		public static Window GetValidOwner(Window candidate)
		{
			bool flag = WindowOwnerHelper.IsUsable(candidate);
			Window result;
			if (flag)
			{
				result = candidate;
			}
			else
			{
				Application app = Application.Current;
				bool flag2 = app == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					bool flag3 = WindowOwnerHelper.IsUsable(app.MainWindow);
					if (flag3)
					{
						result = app.MainWindow;
					}
					else
					{
						foreach (object obj in app.Windows)
						{
							Window window = (Window)obj;
							bool flag4 = WindowOwnerHelper.IsUsable(window);
							if (flag4)
							{
								return window;
							}
						}
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x06002555 RID: 9557 RVA: 0x000D9AE0 File Offset: 0x000D7CE0
		public static bool IsUsable(Window window)
		{
			bool flag = window == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					result = (window.IsLoaded && PresentationSource.FromVisual(window) != null);
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}
	}
}
