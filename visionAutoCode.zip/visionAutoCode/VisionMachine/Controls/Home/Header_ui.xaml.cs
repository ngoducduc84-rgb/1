﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using VisionMachine.Services.Storage;

namespace VisionMachine.Controls.Home
{
	// Token: 0x020002AB RID: 683
	public partial class Header_ui : UserControl
	{
		// Token: 0x06002565 RID: 9573 RVA: 0x000DA2C2 File Offset: 0x000D84C2
		public Header_ui()
		{
			this.InitializeComponent();
			this.ApplyTitle(ApplicationTitleStorageService.Load());
		}

		// Token: 0x06002566 RID: 9574 RVA: 0x000DA2E0 File Offset: 0x000D84E0
		private void RenameApplicationTitle_Click(object sender, RoutedEventArgs e)
		{
			TextEdit editor = new TextEdit
			{
				EditValue = this.ApplicationTitleText.Text,
				Height = 30.0,
				MaxLength = 80,
				Margin = new Thickness(0.0, 4.0, 0.0, 16.0)
			};
			SimpleButton saveButton = new SimpleButton
			{
				Content = "Save",
				Width = 90.0,
				Height = 32.0,
				Margin = new Thickness(8.0, 0.0, 0.0, 0.0)
			};
			SimpleButton cancelButton = new SimpleButton
			{
				Content = "Cancel",
				Width = 90.0,
				Height = 32.0
			};
			StackPanel buttonPanel = new StackPanel
			{
				Orientation = Orientation.Horizontal,
				HorizontalAlignment = HorizontalAlignment.Right
			};
			buttonPanel.Children.Add(cancelButton);
			buttonPanel.Children.Add(saveButton);
			StackPanel content = new StackPanel
			{
				Margin = new Thickness(16.0)
			};
			content.Children.Add(new TextBlock
			{
				Text = "Application Title",
				FontWeight = FontWeights.SemiBold
			});
			content.Children.Add(editor);
			content.Children.Add(buttonPanel);
			Window owner = Window.GetWindow(this);
			ThemedWindow dialog = new ThemedWindow
			{
				Title = "Rename Application Title",
				Width = 420.0,
				Height = 170.0,
				ResizeMode = ResizeMode.NoResize,
				WindowStartupLocation = ((owner != null && owner.IsLoaded) ? WindowStartupLocation.CenterOwner : WindowStartupLocation.CenterScreen),
				Content = content
			};
			bool flag = owner != null && owner.IsLoaded;
			if (flag)
			{
				dialog.Owner = owner;
			}
			cancelButton.Click += delegate(object s, RoutedEventArgs args)
			{
				dialog.DialogResult = new bool?(false);
				dialog.Close();
			};
			saveButton.Click += delegate(object s, RoutedEventArgs args)
			{
				this.SaveTitleAndClose(dialog, editor);
			};
			editor.KeyDown += delegate(object s, KeyEventArgs args)
			{
				bool flag2 = args.Key == Key.Return;
				if (flag2)
				{
					this.SaveTitleAndClose(dialog, editor);
					args.Handled = true;
				}
				else
				{
					bool flag3 = args.Key == Key.Escape;
					if (flag3)
					{
						dialog.DialogResult = new bool?(false);
						dialog.Close();
						args.Handled = true;
					}
				}
			};
			dialog.ContentRendered += delegate(object s, EventArgs args)
			{
				editor.Focus();
				editor.SelectAll();
			};
			dialog.ShowDialog();
		}

		// Token: 0x06002567 RID: 9575 RVA: 0x000DA578 File Offset: 0x000D8778
		private void SaveTitleAndClose(ThemedWindow dialog, TextEdit editor)
		{
			string title = (editor.EditValue ?? string.Empty).ToString().Trim();
			bool flag = string.IsNullOrWhiteSpace(title);
			if (flag)
			{
				DXMessageBox.Show(dialog, "Application title cannot be empty.", "Rename Application Title", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				editor.Focus();
			}
			else
			{
				try
				{
					this.ApplyTitle(ApplicationTitleStorageService.Save(title));
					dialog.DialogResult = new bool?(true);
					dialog.Close();
				}
				catch (Exception ex)
				{
					DXMessageBox.Show(dialog, "Failed to save application title:" + Environment.NewLine + ex.Message, "Rename Application Title", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		// Token: 0x06002568 RID: 9576 RVA: 0x000DA628 File Offset: 0x000D8828
		private void ApplyTitle(string title)
		{
			bool flag = this.ApplicationTitleText == null;
			if (!flag)
			{
				this.ApplicationTitleText.Text = (string.IsNullOrWhiteSpace(title) ? "VISION PRESS MACHINE" : title);
				this.ApplicationTitleText.ToolTip = this.ApplicationTitleText.Text;
			}
		}
	}
}
