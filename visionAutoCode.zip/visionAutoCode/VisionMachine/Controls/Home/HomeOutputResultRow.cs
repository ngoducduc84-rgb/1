﻿using System;
using System.Windows.Media;

namespace VisionMachine.Controls.Home
{
	// Token: 0x020002AD RID: 685
	public class HomeOutputResultRow
	{
		// Token: 0x17000AED RID: 2797
		// (get) Token: 0x06002573 RID: 9587 RVA: 0x000DA966 File Offset: 0x000D8B66
		// (set) Token: 0x06002574 RID: 9588 RVA: 0x000DA96E File Offset: 0x000D8B6E
		public string ToolName { get; set; }

		// Token: 0x17000AEE RID: 2798
		// (get) Token: 0x06002575 RID: 9589 RVA: 0x000DA977 File Offset: 0x000D8B77
		// (set) Token: 0x06002576 RID: 9590 RVA: 0x000DA97F File Offset: 0x000D8B7F
		public string Result { get; set; }

		// Token: 0x17000AEF RID: 2799
		// (get) Token: 0x06002577 RID: 9591 RVA: 0x000DA988 File Offset: 0x000D8B88
		// (set) Token: 0x06002578 RID: 9592 RVA: 0x000DA990 File Offset: 0x000D8B90
		public string Status { get; set; }

		// Token: 0x17000AF0 RID: 2800
		// (get) Token: 0x06002579 RID: 9593 RVA: 0x000DA999 File Offset: 0x000D8B99
		// (set) Token: 0x0600257A RID: 9594 RVA: 0x000DA9A1 File Offset: 0x000D8BA1
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000AF1 RID: 2801
		// (get) Token: 0x0600257B RID: 9595 RVA: 0x000DA9AC File Offset: 0x000D8BAC
		public Brush StatusBrush
		{
			get
			{
				bool flag = string.Equals(this.Status, "OK", StringComparison.OrdinalIgnoreCase);
				Brush result;
				if (flag)
				{
					result = Brushes.LimeGreen;
				}
				else
				{
					bool flag2 = string.Equals(this.Status, "NG", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						result = Brushes.Red;
					}
					else
					{
						bool flag3 = string.Equals(this.Status, "Lost", StringComparison.OrdinalIgnoreCase) || string.Equals(this.Status, "No Calib", StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							result = Brushes.Goldenrod;
						}
						else
						{
							result = Brushes.Transparent;
						}
					}
				}
				return result;
			}
		}
	}
}
