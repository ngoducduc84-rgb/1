﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.ResultInspection;

namespace VisionMachine.Controls.Home
{
	// Token: 0x020002AE RID: 686
	public static class HomeToolResultFormatter
	{
		// Token: 0x0600257D RID: 9597 RVA: 0x000DAA30 File Offset: 0x000D8C30
		public static HomeOutputResultRow Build(ToolVision tool, object result, double timeMs)
		{
			string name = (tool != null) ? tool.Name : null;
			bool flag = string.IsNullOrWhiteSpace(name);
			if (flag)
			{
				name = (((tool != null) ? tool.ToolType.ToString() : null) ?? "Tool");
			}
			HomeOutputResultRow row = new HomeOutputResultRow
			{
				ToolName = name,
				Result = string.Empty,
				Status = "OK",
				ProcessingTimeMs = timeMs
			};
			bool flag2 = result == null;
			HomeOutputResultRow result2;
			if (flag2)
			{
				row.Status = "Lost";
				result2 = row;
			}
			else
			{
				InspectionVerdict verdict = ToolInspectionJudgment.Evaluate(result);
				bool judgable = verdict.Judgable;
				if (judgable)
				{
					row.Status = verdict.Status;
					row.Result = (verdict.ValueText ?? string.Empty);
					bool flag3 = !string.IsNullOrWhiteSpace(verdict.SpecText);
					if (flag3)
					{
						row.Result = (string.IsNullOrWhiteSpace(row.Result) ? verdict.SpecText : (row.Result + "  " + verdict.SpecText));
					}
					result2 = row;
				}
				else
				{
					string text;
					row.Status = HomeToolResultFormatter.ExtractGeneric(result, out text);
					row.Result = text;
					result2 = row;
				}
			}
			return result2;
		}

		// Token: 0x0600257E RID: 9598 RVA: 0x000DAB6C File Offset: 0x000D8D6C
		private static string ExtractGeneric(object result, out string text)
		{
			Type type = result.GetType();
			bool? isSuccess = HomeToolResultFormatter.GetBool(type, result, "IsSuccess");
			bool? flag = HomeToolResultFormatter.GetBool(type, result, "IsOk");
			bool? flag2;
			if (flag == null)
			{
				bool? @bool = HomeToolResultFormatter.GetBool(type, result, "IsSpecOk");
				flag2 = ((@bool != null) ? @bool : HomeToolResultFormatter.GetBool(type, result, "IsTotalOk"));
			}
			else
			{
				flag2 = flag;
			}
			bool? isOk = flag2;
			string message = HomeToolResultFormatter.GetString(type, result, "Message");
			double? score = HomeToolResultFormatter.GetDouble(type, result, "Score");
			List<string> parts = new List<string>();
			bool flag3 = score != null;
			if (flag3)
			{
				parts.Add("Score=" + score.Value.ToString("0.000", HomeToolResultFormatter.Inv));
			}
			flag = isSuccess;
			bool flag4 = false;
			bool flag5 = flag.GetValueOrDefault() == flag4 & flag != null;
			string result2;
			if (flag5)
			{
				text = (string.IsNullOrWhiteSpace(message) ? "Failed" : message);
				result2 = "Lost";
			}
			else
			{
				string text2;
				if (!isOk.GetValueOrDefault())
				{
					flag = isOk;
					flag4 = false;
					text2 = ((flag.GetValueOrDefault() == flag4 & flag != null) ? "NG" : "OK");
				}
				else
				{
					text2 = "OK";
				}
				string status = text2;
				flag = isOk;
				flag4 = false;
				bool flag6 = (flag.GetValueOrDefault() == flag4 & flag != null) && !string.IsNullOrWhiteSpace(message);
				if (flag6)
				{
					parts.Add(message);
				}
				text = ((parts.Count > 0) ? string.Join("  ", parts) : (message ?? string.Empty));
				result2 = status;
			}
			return result2;
		}

		// Token: 0x0600257F RID: 9599 RVA: 0x000DAD08 File Offset: 0x000D8F08
		private static bool? GetBool(Type type, object obj, string name)
		{
			PropertyInfo prop = type.GetProperty(name, BindingFlags.Instance | BindingFlags.Public);
			bool flag = prop != null && prop.PropertyType == typeof(bool);
			bool? result;
			if (flag)
			{
				result = new bool?((bool)prop.GetValue(obj));
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06002580 RID: 9600 RVA: 0x000DAD68 File Offset: 0x000D8F68
		private static double? GetDouble(Type type, object obj, string name)
		{
			PropertyInfo prop = type.GetProperty(name, BindingFlags.Instance | BindingFlags.Public);
			bool flag = prop != null && (prop.PropertyType == typeof(double) || prop.PropertyType == typeof(float));
			double? result;
			if (flag)
			{
				result = new double?(Convert.ToDouble(prop.GetValue(obj), HomeToolResultFormatter.Inv));
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06002581 RID: 9601 RVA: 0x000DADE8 File Offset: 0x000D8FE8
		private static string GetString(Type type, object obj, string name)
		{
			PropertyInfo prop = type.GetProperty(name, BindingFlags.Instance | BindingFlags.Public);
			bool flag = prop != null && prop.PropertyType == typeof(string);
			string result;
			if (flag)
			{
				result = (prop.GetValue(obj) as string);
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x04000FCD RID: 4045
		private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
	}
}
