﻿using System;
using System.Windows.Media;

namespace VisionMachine.Controls.Home
{
	// Token: 0x020002B0 RID: 688
	public class LogItem
	{
		// Token: 0x17000AF3 RID: 2803
		// (get) Token: 0x06002593 RID: 9619 RVA: 0x000DB4B8 File Offset: 0x000D96B8
		// (set) Token: 0x06002594 RID: 9620 RVA: 0x000DB4C0 File Offset: 0x000D96C0
		public string Time { get; set; }

		// Token: 0x17000AF4 RID: 2804
		// (get) Token: 0x06002595 RID: 9621 RVA: 0x000DB4C9 File Offset: 0x000D96C9
		// (set) Token: 0x06002596 RID: 9622 RVA: 0x000DB4D1 File Offset: 0x000D96D1
		public string Message { get; set; }

		// Token: 0x17000AF5 RID: 2805
		// (get) Token: 0x06002597 RID: 9623 RVA: 0x000DB4DA File Offset: 0x000D96DA
		// (set) Token: 0x06002598 RID: 9624 RVA: 0x000DB4E2 File Offset: 0x000D96E2
		public string Tag { get; set; }

		// Token: 0x17000AF6 RID: 2806
		// (get) Token: 0x06002599 RID: 9625 RVA: 0x000DB4EB File Offset: 0x000D96EB
		// (set) Token: 0x0600259A RID: 9626 RVA: 0x000DB4F3 File Offset: 0x000D96F3
		public Brush StatusColor { get; set; }

		// Token: 0x17000AF7 RID: 2807
		// (get) Token: 0x0600259B RID: 9627 RVA: 0x000DB4FC File Offset: 0x000D96FC
		// (set) Token: 0x0600259C RID: 9628 RVA: 0x000DB504 File Offset: 0x000D9704
		public Brush TagColor { get; set; }

		// Token: 0x17000AF8 RID: 2808
		// (get) Token: 0x0600259D RID: 9629 RVA: 0x000DB50D File Offset: 0x000D970D
		// (set) Token: 0x0600259E RID: 9630 RVA: 0x000DB515 File Offset: 0x000D9715
		public Brush TagBg { get; set; }
	}
}
