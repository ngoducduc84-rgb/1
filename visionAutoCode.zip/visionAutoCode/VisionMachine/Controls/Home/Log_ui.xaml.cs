﻿using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using Microsoft.Win32;
using VisionMachine.Services.Runtime;
using VisionMachine.Views.Main;

namespace VisionMachine.Controls.Home
{
	// Token: 0x020002AF RID: 687
	public partial class Log_ui : UserControl
	{
		// Token: 0x17000AF2 RID: 2802
		// (get) Token: 0x06002583 RID: 9603 RVA: 0x000DAE45 File Offset: 0x000D9045
		// (set) Token: 0x06002584 RID: 9604 RVA: 0x000DAE4D File Offset: 0x000D904D
		public ObservableCollection<LogItem> Logs { get; set; }

		// Token: 0x06002585 RID: 9605 RVA: 0x000DAE58 File Offset: 0x000D9058
		public Log_ui()
		{
			this.InitializeComponent();
			this.Logs = new ObservableCollection<LogItem>();
			this.LogList.ItemsSource = this.Logs;
			VisionLogService.RegisterSink(delegate(string level, string message)
			{
				bool flag = base.Dispatcher.CheckAccess();
				if (flag)
				{
					this.AddLog(level, message);
				}
				else
				{
					base.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this.AddLog(level, message);
					}), Array.Empty<object>());
				}
			});
			base.Loaded += this.LogUi_Loaded;
			base.Unloaded += this.LogUi_Unloaded;
		}

		// Token: 0x06002586 RID: 9606 RVA: 0x000DAECA File Offset: 0x000D90CA
		private void LogUi_Loaded(object sender, RoutedEventArgs e)
		{
			VisionLogService.HistoryCleared -= this.VisionLogHistoryCleared;
			VisionLogService.HistoryCleared += this.VisionLogHistoryCleared;
		}

		// Token: 0x06002587 RID: 9607 RVA: 0x000DAEF1 File Offset: 0x000D90F1
		private void LogUi_Unloaded(object sender, RoutedEventArgs e)
		{
			VisionLogService.HistoryCleared -= this.VisionLogHistoryCleared;
		}

		// Token: 0x06002588 RID: 9608 RVA: 0x000DAF08 File Offset: 0x000D9108
		private void VisionLogHistoryCleared()
		{
			bool flag = base.Dispatcher.CheckAccess();
			if (flag)
			{
				this.Logs.Clear();
			}
			else
			{
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					this.Logs.Clear();
				}), Array.Empty<object>());
			}
		}

		// Token: 0x06002589 RID: 9609 RVA: 0x000DAF50 File Offset: 0x000D9150
		private void OpenLogTab_Click(object sender, RoutedEventArgs e)
		{
			MainWindow instance = MainWindow.instance;
			if (instance != null)
			{
				instance.OpenLogVisionDocument();
			}
		}

		// Token: 0x0600258A RID: 9610 RVA: 0x000DAF64 File Offset: 0x000D9164
		public void AddLog(string tag, string message)
		{
			string normalizedTag = string.IsNullOrWhiteSpace(tag) ? "INFO" : tag.Trim().ToUpperInvariant();
			Brush statusColor = Brushes.LimeGreen;
			Brush tagColor = Brushes.LightBlue;
			Brush tagBg = new SolidColorBrush(Color.FromArgb(30, 0, 150, byte.MaxValue));
			bool flag = normalizedTag == "WARN";
			if (flag)
			{
				statusColor = Brushes.Gold;
				tagColor = Brushes.Gold;
				tagBg = new SolidColorBrush(Color.FromArgb(40, byte.MaxValue, 200, 0));
			}
			else
			{
				bool flag2 = normalizedTag == "ERROR";
				if (flag2)
				{
					statusColor = Brushes.IndianRed;
					tagColor = Brushes.IndianRed;
					tagBg = new SolidColorBrush(Color.FromArgb(40, byte.MaxValue, 70, 70));
				}
				else
				{
					bool flag3 = normalizedTag == "TRIGGER";
					if (flag3)
					{
						statusColor = Brushes.DeepSkyBlue;
						tagColor = Brushes.DeepSkyBlue;
						tagBg = new SolidColorBrush(Color.FromArgb(40, 0, 180, byte.MaxValue));
					}
				}
			}
			this.Logs.Insert(0, new LogItem
			{
				Time = DateTime.Now.ToString("HH:mm:ss.fff"),
				Message = (message ?? string.Empty),
				Tag = normalizedTag,
				StatusColor = statusColor,
				TagColor = tagColor,
				TagBg = tagBg
			});
			while (this.Logs.Count > 300)
			{
				this.Logs.RemoveAt(this.Logs.Count - 1);
			}
		}

		// Token: 0x0600258B RID: 9611 RVA: 0x000DB0E8 File Offset: 0x000D92E8
		private void CopyLog_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Clipboard.SetText(this.BuildLogText(false));
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Could not copy the log: " + ex.Message, "Copy Log");
			}
		}

		// Token: 0x0600258C RID: 9612 RVA: 0x000DB138 File Offset: 0x000D9338
		private void ExportLog_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this.Logs == null || this.Logs.Count == 0;
			if (flag)
			{
				DXMessageBox.Show("There is no log to export.", "Export Log");
			}
			else
			{
				SaveFileDialog dialog = new SaveFileDialog
				{
					Title = "Export Vision Log",
					Filter = "Text file (*.txt)|*.txt|CSV file (*.csv)|*.csv|All files (*.*)|*.*",
					FileName = "vision_log_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt"
				};
				bool flag2 = !dialog.ShowDialog().GetValueOrDefault();
				if (!flag2)
				{
					try
					{
						bool csv = dialog.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase);
						File.WriteAllText(dialog.FileName, this.BuildLogText(csv), Encoding.UTF8);
					}
					catch (Exception ex)
					{
						DXMessageBox.Show("Could not export the log: " + ex.Message, "Export Log");
					}
				}
			}
		}

		// Token: 0x0600258D RID: 9613 RVA: 0x0008852A File Offset: 0x0008672A
		private void ClearLog_Click(object sender, RoutedEventArgs e)
		{
			VisionLogService.Clear();
		}

		// Token: 0x0600258E RID: 9614 RVA: 0x000DB23C File Offset: 0x000D943C
		private string BuildLogText(bool csv = false)
		{
			bool flag = this.Logs == null || this.Logs.Count == 0;
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				char separator = csv ? ',' : '\t';
				StringBuilder builder = new StringBuilder();
				if (csv)
				{
					builder.AppendLine("Time,Tag,Message");
				}
				foreach (LogItem log in this.Logs)
				{
					string message = csv ? ("\"" + (log.Message ?? string.Empty).Replace("\"", "\"\"") + "\"") : log.Message;
					builder.Append(log.Time);
					builder.Append(separator);
					builder.Append(log.Tag);
					builder.Append(separator);
					builder.AppendLine(message);
				}
				result = builder.ToString();
			}
			return result;
		}
	}
}
