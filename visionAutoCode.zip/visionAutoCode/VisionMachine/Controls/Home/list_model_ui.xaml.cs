﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Model;
using VisionMachine.Services.Runtime;
using VisionMachine.Views.Home;

namespace VisionMachine.Controls.Home
{
	// Token: 0x020002AC RID: 684
	public partial class list_model_ui : UserControl
	{
		// Token: 0x0600256B RID: 9579 RVA: 0x000DA715 File Offset: 0x000D8915
		public list_model_ui()
		{
			this.InitializeComponent();
			base.Loaded += this.ListModelUi_Loaded;
		}

		// Token: 0x0600256C RID: 9580 RVA: 0x000DA739 File Offset: 0x000D8939
		private void ListModelUi_Loaded(object sender, RoutedEventArgs e)
		{
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				bool flag = this.ModelListBox == null;
				if (!flag)
				{
					this.ModelListBox.ApplyTemplate();
					this.ModelListBox.UpdateLayout();
					object selected = this.ModelListBox.SelectedItem;
					bool flag2 = selected == null;
					if (!flag2)
					{
						this.ModelListBox.ScrollIntoView(selected);
						this.ModelListBox.UpdateLayout();
						ListBoxItem container = this.ModelListBox.ItemContainerGenerator.ContainerFromItem(selected) as ListBoxItem;
						if (container != null)
						{
							container.InvalidateMeasure();
						}
						if (container != null)
						{
							container.InvalidateArrange();
						}
						if (container != null)
						{
							container.UpdateLayout();
						}
					}
				}
			}), DispatcherPriority.ContextIdle, Array.Empty<object>());
		}

		// Token: 0x0600256D RID: 9581 RVA: 0x000DA75A File Offset: 0x000D895A
		private void ModelSearchBox_TextChanged(object sender, TextChangedEventArgs e)
		{
			ModelSearchFilter.Apply(this.ModelListBox, this.ModelSearchBox.Text);
		}

		// Token: 0x0600256E RID: 9582 RVA: 0x000DA774 File Offset: 0x000D8974
		private void ModelListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ModelConfig model = this.ModelListBox.SelectedItem as ModelConfig;
			bool flag = model == null;
			if (!flag)
			{
				ModelConfig current = ModelRuntimeStore.CurrentModel;
				bool flag2 = current != null && current.Id == model.Id;
				if (!flag2)
				{
					base.Dispatcher.BeginInvoke(new Action(delegate()
					{
						bool flag3 = this.ModelListBox.SelectedItem != model;
						if (!flag3)
						{
							ModelConfig active = ModelRuntimeStore.CurrentModel;
							bool flag4 = active != null && active.Id == model.Id;
							if (!flag4)
							{
								Form_home instance = Form_home.Instance;
								if (instance != null)
								{
									instance.SwitchModel(model);
								}
							}
						}
					}), DispatcherPriority.Background, Array.Empty<object>());
				}
			}
		}
	}
}
