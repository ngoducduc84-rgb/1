﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VisionMachine.Converters
{
	// Token: 0x020002A7 RID: 679
	public class InverseBoolConverter : IValueConverter
	{
		// Token: 0x06002546 RID: 9542 RVA: 0x000D98AC File Offset: 0x000D7AAC
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			bool b;
			bool flag;
			if (value is bool)
			{
				b = (bool)value;
				flag = true;
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			object result;
			if (flag2)
			{
				result = !b;
			}
			else
			{
				result = true;
			}
			return result;
		}

		// Token: 0x06002547 RID: 9543 RVA: 0x000D98E8 File Offset: 0x000D7AE8
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			bool b;
			bool flag;
			if (value is bool)
			{
				b = (bool)value;
				flag = true;
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			object result;
			if (flag2)
			{
				result = !b;
			}
			else
			{
				result = false;
			}
			return result;
		}
	}
}
