﻿using System;
using System.Collections;
using System.Globalization;
using System.Windows.Data;

namespace VisionMachine.Converters
{
	// Token: 0x020002A8 RID: 680
	public class ToolGridHeightConverter : IValueConverter
	{
		// Token: 0x17000AE8 RID: 2792
		// (get) Token: 0x06002549 RID: 9545 RVA: 0x000D9923 File Offset: 0x000D7B23
		// (set) Token: 0x0600254A RID: 9546 RVA: 0x000D992B File Offset: 0x000D7B2B
		public double RowHeight { get; set; } = 34.0;

		// Token: 0x17000AE9 RID: 2793
		// (get) Token: 0x0600254B RID: 9547 RVA: 0x000D9934 File Offset: 0x000D7B34
		// (set) Token: 0x0600254C RID: 9548 RVA: 0x000D993C File Offset: 0x000D7B3C
		public double HeaderHeight { get; set; } = 32.0;

		// Token: 0x17000AEA RID: 2794
		// (get) Token: 0x0600254D RID: 9549 RVA: 0x000D9945 File Offset: 0x000D7B45
		// (set) Token: 0x0600254E RID: 9550 RVA: 0x000D994D File Offset: 0x000D7B4D
		public double MinHeight { get; set; } = 90.0;

		// Token: 0x17000AEB RID: 2795
		// (get) Token: 0x0600254F RID: 9551 RVA: 0x000D9956 File Offset: 0x000D7B56
		// (set) Token: 0x06002550 RID: 9552 RVA: 0x000D995E File Offset: 0x000D7B5E
		public double ExtraHeight { get; set; } = 16.0;

		// Token: 0x06002551 RID: 9553 RVA: 0x000D9968 File Offset: 0x000D7B68
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			int count = 1;
			ICollection collection = value as ICollection;
			bool flag = collection != null;
			if (flag)
			{
				count = collection.Count;
			}
			double height = this.HeaderHeight + this.RowHeight * (double)Math.Max(count, 1) + this.ExtraHeight;
			return Math.Max(height, this.MinHeight);
		}

		// Token: 0x06002552 RID: 9554 RVA: 0x000D99C4 File Offset: 0x000D7BC4
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return Binding.DoNothing;
		}
	}
}
