﻿using System;
using System.Collections.Specialized;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace VisionMachine.Helpers
{
	// Token: 0x020002A5 RID: 677
	public static class ListRowNumbering
	{
		// Token: 0x0600253D RID: 9533 RVA: 0x000D95F3 File Offset: 0x000D77F3
		public static void SetIsEnabled(DependencyObject element, bool value)
		{
			element.SetValue(ListRowNumbering.IsEnabledProperty, value);
		}

		// Token: 0x0600253E RID: 9534 RVA: 0x000D9608 File Offset: 0x000D7808
		public static bool GetIsEnabled(DependencyObject element)
		{
			return (bool)element.GetValue(ListRowNumbering.IsEnabledProperty);
		}

		// Token: 0x0600253F RID: 9535 RVA: 0x000D962A File Offset: 0x000D782A
		public static void SetNumber(DependencyObject element, string value)
		{
			element.SetValue(ListRowNumbering.NumberProperty, value);
		}

		// Token: 0x06002540 RID: 9536 RVA: 0x000D963C File Offset: 0x000D783C
		public static string GetNumber(DependencyObject element)
		{
			return (string)element.GetValue(ListRowNumbering.NumberProperty);
		}

		// Token: 0x06002541 RID: 9537 RVA: 0x000D9660 File Offset: 0x000D7860
		private static void OnIsEnabledChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
		{
			ItemsControl list = sender as ItemsControl;
			bool flag = list == null;
			if (!flag)
			{
				INotifyCollectionChanged items = list.Items;
				bool flag2 = (bool)e.NewValue;
				if (flag2)
				{
					bool flag3 = items != null;
					if (flag3)
					{
						items.CollectionChanged += delegate(object s, NotifyCollectionChangedEventArgs a)
						{
							ListRowNumbering.Renumber(list);
						};
					}
					list.ItemContainerGenerator.StatusChanged += delegate(object s, EventArgs a)
					{
						ListRowNumbering.Renumber(list);
					};
					ListRowNumbering.Renumber(list);
				}
			}
		}

		// Token: 0x06002542 RID: 9538 RVA: 0x000D96F4 File Offset: 0x000D78F4
		private static void Renumber(ItemsControl list)
		{
			bool flag = list.ItemContainerGenerator.Status != GeneratorStatus.ContainersGenerated;
			if (!flag)
			{
				for (int i = 0; i < list.Items.Count; i++)
				{
					DependencyObject container = list.ItemContainerGenerator.ContainerFromIndex(i);
					bool flag2 = container == null;
					if (!flag2)
					{
						string number = (i + 1).ToString(CultureInfo.InvariantCulture);
						bool flag3 = !string.Equals(ListRowNumbering.GetNumber(container), number, StringComparison.Ordinal);
						if (flag3)
						{
							ListRowNumbering.SetNumber(container, number);
						}
					}
				}
			}
		}

		// Token: 0x04000FA9 RID: 4009
		public static readonly DependencyProperty IsEnabledProperty = DependencyProperty.RegisterAttached("IsEnabled", typeof(bool), typeof(ListRowNumbering), new PropertyMetadata(false, new PropertyChangedCallback(ListRowNumbering.OnIsEnabledChanged)));

		// Token: 0x04000FAA RID: 4010
		public static readonly DependencyProperty NumberProperty = DependencyProperty.RegisterAttached("Number", typeof(string), typeof(ListRowNumbering), new PropertyMetadata(string.Empty));
	}
}
