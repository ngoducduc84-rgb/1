﻿using System;
using System.IO;

namespace VisionMachine.Helpers
{
	// Token: 0x020002A6 RID: 678
	public static class Manager_path
	{
		// Token: 0x06002544 RID: 9540 RVA: 0x000D97F8 File Offset: 0x000D79F8
		public static void Creat_path(string NameFolder)
		{
			DirectoryInfo Dir = new DirectoryInfo(NameFolder);
			bool flag = !Dir.Exists;
			if (flag)
			{
				Dir.Create();
			}
		}

		// Token: 0x04000FAB RID: 4011
		public static string _dataPath = "C:\\\\Data_base_vision_DB\\\\Model";

		// Token: 0x04000FAC RID: 4012
		public static string path_manager = "C:\\Data_base_vision_DB\\Model";

		// Token: 0x04000FAD RID: 4013
		public static string path_Camera_Qty = "C:\\Data_base_vision_DB\\Model\\Camera_qty.json";

		// Token: 0x04000FAE RID: 4014
		public static string _logSettingJsonPath = "C:\\Data_base_vision_DB\\Model\\Log_vision_setting.json";

		// Token: 0x04000FAF RID: 4015
		public static string path_vision_log = "C:\\Data_base_vision_DB\\VisionLogs";

		// Token: 0x04000FB0 RID: 4016
		public static string _modelJsonPath = "C:\\Data_base_vision_DB\\Model\\_modelJsonPath.json";

		// Token: 0x04000FB1 RID: 4017
		public static string path_communication = "C:\\Data_base_vision_DB\\Communication";

		// Token: 0x04000FB2 RID: 4018
		public static string _toolboxVisibilityJsonPath = "C:\\Data_base_vision_DB\\Model\\Toolbox_visibility.json";

		// Token: 0x04000FB3 RID: 4019
		public static string _languageJsonPath = "C:\\Data_base_vision_DB\\Model\\Language.json";

		// Token: 0x04000FB4 RID: 4020
		public static string _licenseJsonPath = "C:\\Data_base_vision_DB\\Model\\License.json";

		// Token: 0x04000FB5 RID: 4021
		public static string _licenseWarningJsonPath = "C:\\Data_base_vision_DB\\Model\\License_warning.json";

		// Token: 0x04000FB6 RID: 4022
		public static string _themeJsonPath = "C:\\Data_base_vision_DB\\Model\\Theme.json";
	}
}
