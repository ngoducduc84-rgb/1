﻿using System;
using System.ComponentModel;
using System.Diagnostics;

namespace VisionMachine.Models.Camera
{
	// Token: 0x020002A0 RID: 672
	public class CameraItem : INotifyPropertyChanged
	{
		// Token: 0x17000ACA RID: 2762
		// (get) Token: 0x060024F7 RID: 9463 RVA: 0x000D8C90 File Offset: 0x000D6E90
		// (set) Token: 0x060024F8 RID: 9464 RVA: 0x000D8C98 File Offset: 0x000D6E98
		public string CameraName
		{
			get
			{
				return this._cameraName;
			}
			set
			{
				this._cameraName = value;
				this.OnPropertyChanged("CameraName");
			}
		}

		// Token: 0x17000ACB RID: 2763
		// (get) Token: 0x060024F9 RID: 9465 RVA: 0x000D8CAE File Offset: 0x000D6EAE
		// (set) Token: 0x060024FA RID: 9466 RVA: 0x000D8CB6 File Offset: 0x000D6EB6
		public string Category
		{
			get
			{
				return this._category;
			}
			set
			{
				this._category = value;
				this.OnPropertyChanged("Category");
			}
		}

		// Token: 0x17000ACC RID: 2764
		// (get) Token: 0x060024FB RID: 9467 RVA: 0x000D8CCC File Offset: 0x000D6ECC
		// (set) Token: 0x060024FC RID: 9468 RVA: 0x000D8CD4 File Offset: 0x000D6ED4
		public string Version
		{
			get
			{
				return this._version;
			}
			set
			{
				this._version = value;
				this.OnPropertyChanged("Version");
			}
		}

		// Token: 0x17000ACD RID: 2765
		// (get) Token: 0x060024FD RID: 9469 RVA: 0x000D8CEA File Offset: 0x000D6EEA
		// (set) Token: 0x060024FE RID: 9470 RVA: 0x000D8CF2 File Offset: 0x000D6EF2
		public string Tags
		{
			get
			{
				return this._tags;
			}
			set
			{
				this._tags = value;
				this.OnPropertyChanged("Tags");
			}
		}

		// Token: 0x14000048 RID: 72
		// (add) Token: 0x060024FF RID: 9471 RVA: 0x000D8D08 File Offset: 0x000D6F08
		// (remove) Token: 0x06002500 RID: 9472 RVA: 0x000D8D40 File Offset: 0x000D6F40
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06002501 RID: 9473 RVA: 0x000D8D75 File Offset: 0x000D6F75
		protected void OnPropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000F87 RID: 3975
		private string _cameraName;

		// Token: 0x04000F88 RID: 3976
		private string _category;

		// Token: 0x04000F89 RID: 3977
		private string _version;

		// Token: 0x04000F8A RID: 3978
		private string _tags;
	}
}
