﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Models.Camera
{
	// Token: 0x0200029E RID: 670
	public class CameraModelConfigData
	{
		// Token: 0x17000AC5 RID: 2757
		// (get) Token: 0x060024EB RID: 9451 RVA: 0x000D8C13 File Offset: 0x000D6E13
		// (set) Token: 0x060024EC RID: 9452 RVA: 0x000D8C1B File Offset: 0x000D6E1B
		public string ModelName { get; set; }

		// Token: 0x17000AC6 RID: 2758
		// (get) Token: 0x060024ED RID: 9453 RVA: 0x000D8C24 File Offset: 0x000D6E24
		// (set) Token: 0x060024EE RID: 9454 RVA: 0x000D8C2C File Offset: 0x000D6E2C
		public List<CameraModelConfigItem> Cameras { get; set; } = new List<CameraModelConfigItem>();
	}
}
