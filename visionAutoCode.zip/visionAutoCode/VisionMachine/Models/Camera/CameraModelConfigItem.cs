﻿using System;

namespace VisionMachine.Models.Camera
{
	// Token: 0x0200029F RID: 671
	public class CameraModelConfigItem
	{
		// Token: 0x17000AC7 RID: 2759
		// (get) Token: 0x060024F0 RID: 9456 RVA: 0x000D8C49 File Offset: 0x000D6E49
		// (set) Token: 0x060024F1 RID: 9457 RVA: 0x000D8C51 File Offset: 0x000D6E51
		public string CameraName { get; set; }

		// Token: 0x17000AC8 RID: 2760
		// (get) Token: 0x060024F2 RID: 9458 RVA: 0x000D8C5A File Offset: 0x000D6E5A
		// (set) Token: 0x060024F3 RID: 9459 RVA: 0x000D8C62 File Offset: 0x000D6E62
		public int CameraIndex { get; set; }

		// Token: 0x17000AC9 RID: 2761
		// (get) Token: 0x060024F4 RID: 9460 RVA: 0x000D8C6B File Offset: 0x000D6E6B
		// (set) Token: 0x060024F5 RID: 9461 RVA: 0x000D8C73 File Offset: 0x000D6E73
		public CameraParameterConfig Parameter { get; set; } = new CameraParameterConfig();
	}
}
