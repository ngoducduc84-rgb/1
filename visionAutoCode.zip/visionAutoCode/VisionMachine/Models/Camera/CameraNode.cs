﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;

namespace VisionMachine.Models.Camera
{
	// Token: 0x020002A1 RID: 673
	public class CameraNode : INotifyPropertyChanged
	{
		// Token: 0x17000ACE RID: 2766
		// (get) Token: 0x06002503 RID: 9475 RVA: 0x000D8D91 File Offset: 0x000D6F91
		// (set) Token: 0x06002504 RID: 9476 RVA: 0x000D8D9C File Offset: 0x000D6F9C
		public int Index
		{
			get
			{
				return this._index;
			}
			set
			{
				bool flag = this._index != value;
				if (flag)
				{
					this._index = value;
					this.OnPropertyChanged("Index");
					this.OnPropertyChanged("DisplayName");
				}
			}
		}

		// Token: 0x17000ACF RID: 2767
		// (get) Token: 0x06002505 RID: 9477 RVA: 0x000D8DDB File Offset: 0x000D6FDB
		// (set) Token: 0x06002506 RID: 9478 RVA: 0x000D8DE4 File Offset: 0x000D6FE4
		public bool IsSelected
		{
			get
			{
				return this._isSelected;
			}
			set
			{
				bool flag = this._isSelected != value;
				if (flag)
				{
					this._isSelected = value;
					this.OnPropertyChanged("IsSelected");
				}
			}
		}

		// Token: 0x17000AD0 RID: 2768
		// (get) Token: 0x06002507 RID: 9479 RVA: 0x000D8E17 File Offset: 0x000D7017
		// (set) Token: 0x06002508 RID: 9480 RVA: 0x000D8E20 File Offset: 0x000D7020
		public CameraItem CameraInfo
		{
			get
			{
				return this._cameraInfo;
			}
			set
			{
				bool flag = this._cameraInfo != value;
				if (flag)
				{
					this._cameraInfo = value;
					this.OnPropertyChanged("CameraInfo");
					this.OnPropertyChanged("Name");
					this.OnPropertyChanged("DisplayName");
				}
			}
		}

		// Token: 0x17000AD1 RID: 2769
		// (get) Token: 0x06002509 RID: 9481 RVA: 0x000D8E6C File Offset: 0x000D706C
		// (set) Token: 0x0600250A RID: 9482 RVA: 0x000D8E84 File Offset: 0x000D7084
		public CameraParameterConfig CameraConfig
		{
			get
			{
				return this._cameraConfig;
			}
			set
			{
				bool flag = this._cameraConfig == value;
				if (!flag)
				{
					this._cameraConfig = (value ?? new CameraParameterConfig());
					this.OnPropertyChanged("CameraConfig");
				}
			}
		}

		// Token: 0x17000AD2 RID: 2770
		// (get) Token: 0x0600250B RID: 9483 RVA: 0x000D8EBD File Offset: 0x000D70BD
		public string Name
		{
			get
			{
				CameraItem cameraInfo = this.CameraInfo;
				return ((cameraInfo != null) ? cameraInfo.CameraName : null) ?? "Unknown Camera";
			}
		}

		// Token: 0x17000AD3 RID: 2771
		// (get) Token: 0x0600250C RID: 9484 RVA: 0x000D8EDA File Offset: 0x000D70DA
		public string DisplayName
		{
			get
			{
				return string.Format("Camera {0}: {1}", this.Index, this.Name);
			}
		}

		// Token: 0x17000AD4 RID: 2772
		// (get) Token: 0x0600250D RID: 9485 RVA: 0x000D8EF7 File Offset: 0x000D70F7
		// (set) Token: 0x0600250E RID: 9486 RVA: 0x000D8EFF File Offset: 0x000D70FF
		public ObservableCollection<TurnSnap> TurnSnaps { get; set; } = new ObservableCollection<TurnSnap>();

		// Token: 0x14000049 RID: 73
		// (add) Token: 0x0600250F RID: 9487 RVA: 0x000D8F08 File Offset: 0x000D7108
		// (remove) Token: 0x06002510 RID: 9488 RVA: 0x000D8F40 File Offset: 0x000D7140
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06002511 RID: 9489 RVA: 0x000D8F75 File Offset: 0x000D7175
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000F8C RID: 3980
		private int _index;

		// Token: 0x04000F8D RID: 3981
		private bool _isSelected;

		// Token: 0x04000F8E RID: 3982
		private CameraItem _cameraInfo;

		// Token: 0x04000F8F RID: 3983
		private CameraParameterConfig _cameraConfig = new CameraParameterConfig();
	}
}
