﻿using System;
using System.ComponentModel;
using System.Diagnostics;

namespace VisionMachine.Models.Camera
{
	// Token: 0x020002A2 RID: 674
	public class CameraParameterConfig : INotifyPropertyChanged
	{
		// Token: 0x17000AD5 RID: 2773
		// (get) Token: 0x06002513 RID: 9491 RVA: 0x000D8FB0 File Offset: 0x000D71B0
		// (set) Token: 0x06002514 RID: 9492 RVA: 0x000D8FC8 File Offset: 0x000D71C8
		[DisplayName("Serial Camera")]
		public string ConnectedCameraId
		{
			get
			{
				return this._connectedCameraId;
			}
			set
			{
				bool flag = this._connectedCameraId == value;
				if (!flag)
				{
					this._connectedCameraId = value;
					this.OnPropertyChanged("ConnectedCameraId");
				}
			}
		}

		// Token: 0x17000AD6 RID: 2774
		// (get) Token: 0x06002515 RID: 9493 RVA: 0x000D8FFC File Offset: 0x000D71FC
		// (set) Token: 0x06002516 RID: 9494 RVA: 0x000D9014 File Offset: 0x000D7214
		[DisplayName("Vendor")]
		public CameraVendor Vendor
		{
			get
			{
				return this._vendor;
			}
			set
			{
				bool flag = this._vendor == value;
				if (!flag)
				{
					this._vendor = value;
					this.OnPropertyChanged("Vendor");
				}
			}
		}

		// Token: 0x17000AD7 RID: 2775
		// (get) Token: 0x06002517 RID: 9495 RVA: 0x000D9044 File Offset: 0x000D7244
		// (set) Token: 0x06002518 RID: 9496 RVA: 0x000D905C File Offset: 0x000D725C
		[DisplayName("Exposure Time")]
		public double ExposureTime
		{
			get
			{
				return this._exposureTime;
			}
			set
			{
				bool flag = this._exposureTime == value;
				if (!flag)
				{
					this._exposureTime = value;
					this.OnPropertyChanged("ExposureTime");
				}
			}
		}

		// Token: 0x17000AD8 RID: 2776
		// (get) Token: 0x06002519 RID: 9497 RVA: 0x000D908C File Offset: 0x000D728C
		// (set) Token: 0x0600251A RID: 9498 RVA: 0x000D90A4 File Offset: 0x000D72A4
		[DisplayName("Gain")]
		public double Gain
		{
			get
			{
				return this._gain;
			}
			set
			{
				bool flag = this._gain == value;
				if (!flag)
				{
					this._gain = value;
					this.OnPropertyChanged("Gain");
				}
			}
		}

		// Token: 0x17000AD9 RID: 2777
		// (get) Token: 0x0600251B RID: 9499 RVA: 0x000D90D4 File Offset: 0x000D72D4
		// (set) Token: 0x0600251C RID: 9500 RVA: 0x000D90EC File Offset: 0x000D72EC
		[DisplayName("Hardware Trigger")]
		public bool HardwareTrigger
		{
			get
			{
				return this._hardwareTrigger;
			}
			set
			{
				bool flag = this._hardwareTrigger == value;
				if (!flag)
				{
					this._hardwareTrigger = value;
					this.OnPropertyChanged("HardwareTrigger");
				}
			}
		}

		// Token: 0x17000ADA RID: 2778
		// (get) Token: 0x0600251D RID: 9501 RVA: 0x000D911C File Offset: 0x000D731C
		// (set) Token: 0x0600251E RID: 9502 RVA: 0x000D9134 File Offset: 0x000D7334
		[DisplayName("Pixel Format")]
		public string PixelFormat
		{
			get
			{
				return this._pixelFormat;
			}
			set
			{
				bool flag = this._pixelFormat == value;
				if (!flag)
				{
					this._pixelFormat = value;
					this.OnPropertyChanged("PixelFormat");
				}
			}
		}

		// Token: 0x17000ADB RID: 2779
		// (get) Token: 0x0600251F RID: 9503 RVA: 0x000D9168 File Offset: 0x000D7368
		// (set) Token: 0x06002520 RID: 9504 RVA: 0x000D9180 File Offset: 0x000D7380
		[DisplayName("Light Source Preset")]
		public string LightSourcePreset
		{
			get
			{
				return this._lightSourcePreset;
			}
			set
			{
				bool flag = this._lightSourcePreset == value;
				if (!flag)
				{
					this._lightSourcePreset = value;
					this.OnPropertyChanged("LightSourcePreset");
				}
			}
		}

		// Token: 0x17000ADC RID: 2780
		// (get) Token: 0x06002521 RID: 9505 RVA: 0x000D91B4 File Offset: 0x000D73B4
		// (set) Token: 0x06002522 RID: 9506 RVA: 0x000D91CC File Offset: 0x000D73CC
		[DisplayName("Mirror Row")]
		public bool MirrorRow
		{
			get
			{
				return this._mirrorRow;
			}
			set
			{
				bool flag = this._mirrorRow == value;
				if (!flag)
				{
					this._mirrorRow = value;
					this.OnPropertyChanged("MirrorRow");
				}
			}
		}

		// Token: 0x17000ADD RID: 2781
		// (get) Token: 0x06002523 RID: 9507 RVA: 0x000D91FC File Offset: 0x000D73FC
		// (set) Token: 0x06002524 RID: 9508 RVA: 0x000D9214 File Offset: 0x000D7414
		[DisplayName("Mirror Column")]
		public bool MirrorColumn
		{
			get
			{
				return this._mirrorColumn;
			}
			set
			{
				bool flag = this._mirrorColumn == value;
				if (!flag)
				{
					this._mirrorColumn = value;
					this.OnPropertyChanged("MirrorColumn");
				}
			}
		}

		// Token: 0x17000ADE RID: 2782
		// (get) Token: 0x06002525 RID: 9509 RVA: 0x000D9244 File Offset: 0x000D7444
		// (set) Token: 0x06002526 RID: 9510 RVA: 0x000D925C File Offset: 0x000D745C
		[DisplayName("Rotation Image")]
		public double RotationImage
		{
			get
			{
				return this._rotationImage;
			}
			set
			{
				bool flag = this._rotationImage == value;
				if (!flag)
				{
					this._rotationImage = value;
					this.OnPropertyChanged("RotationImage");
				}
			}
		}

		// Token: 0x17000ADF RID: 2783
		// (get) Token: 0x06002527 RID: 9511 RVA: 0x000D928C File Offset: 0x000D748C
		// (set) Token: 0x06002528 RID: 9512 RVA: 0x000D92A4 File Offset: 0x000D74A4
		[DisplayName("Expand Rotation Canvas")]
		public bool ExpandRotationCanvas
		{
			get
			{
				return this._expandRotationCanvas;
			}
			set
			{
				bool flag = this._expandRotationCanvas == value;
				if (!flag)
				{
					this._expandRotationCanvas = value;
					this.OnPropertyChanged("ExpandRotationCanvas");
				}
			}
		}

		// Token: 0x17000AE0 RID: 2784
		// (get) Token: 0x06002529 RID: 9513 RVA: 0x000D92D4 File Offset: 0x000D74D4
		// (set) Token: 0x0600252A RID: 9514 RVA: 0x000D92EC File Offset: 0x000D74EC
		[DisplayName("Rotation Fill Color")]
		public string RotationFillColor
		{
			get
			{
				return this._rotationFillColor;
			}
			set
			{
				bool flag = this._rotationFillColor == value;
				if (!flag)
				{
					this._rotationFillColor = value;
					this.OnPropertyChanged("RotationFillColor");
				}
			}
		}

		// Token: 0x17000AE1 RID: 2785
		// (get) Token: 0x0600252B RID: 9515 RVA: 0x000D9320 File Offset: 0x000D7520
		// (set) Token: 0x0600252C RID: 9516 RVA: 0x000D9338 File Offset: 0x000D7538
		[DisplayName("Show Center")]
		public bool ShowCenter
		{
			get
			{
				return this._showCenter;
			}
			set
			{
				bool flag = this._showCenter == value;
				if (!flag)
				{
					this._showCenter = value;
					this.OnPropertyChanged("ShowCenter");
				}
			}
		}

		// Token: 0x17000AE2 RID: 2786
		// (get) Token: 0x0600252D RID: 9517 RVA: 0x000D9368 File Offset: 0x000D7568
		// (set) Token: 0x0600252E RID: 9518 RVA: 0x000D9380 File Offset: 0x000D7580
		[DisplayName("Center Length")]
		public double CenterLength
		{
			get
			{
				return this._centerLength;
			}
			set
			{
				bool flag = this._centerLength == value;
				if (!flag)
				{
					this._centerLength = value;
					this.OnPropertyChanged("CenterLength");
				}
			}
		}

		// Token: 0x17000AE3 RID: 2787
		// (get) Token: 0x0600252F RID: 9519 RVA: 0x000D93B0 File Offset: 0x000D75B0
		// (set) Token: 0x06002530 RID: 9520 RVA: 0x000D93C8 File Offset: 0x000D75C8
		[DisplayName("Center Angle")]
		public double CenterAngle
		{
			get
			{
				return this._centerAngle;
			}
			set
			{
				bool flag = this._centerAngle == value;
				if (!flag)
				{
					this._centerAngle = value;
					this.OnPropertyChanged("CenterAngle");
				}
			}
		}

		// Token: 0x1400004A RID: 74
		// (add) Token: 0x06002531 RID: 9521 RVA: 0x000D93F8 File Offset: 0x000D75F8
		// (remove) Token: 0x06002532 RID: 9522 RVA: 0x000D9430 File Offset: 0x000D7630
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06002533 RID: 9523 RVA: 0x000D9465 File Offset: 0x000D7665
		protected void OnPropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000F92 RID: 3986
		private string _connectedCameraId;

		// Token: 0x04000F93 RID: 3987
		private CameraVendor _vendor = CameraVendor.Unknown;

		// Token: 0x04000F94 RID: 3988
		private double _exposureTime = 1000.0;

		// Token: 0x04000F95 RID: 3989
		private double _gain = 0.0;

		// Token: 0x04000F96 RID: 3990
		private bool _hardwareTrigger;

		// Token: 0x04000F97 RID: 3991
		private string _pixelFormat = "Mono8";

		// Token: 0x04000F98 RID: 3992
		private string _lightSourcePreset;

		// Token: 0x04000F99 RID: 3993
		private bool _mirrorRow;

		// Token: 0x04000F9A RID: 3994
		private bool _mirrorColumn;

		// Token: 0x04000F9B RID: 3995
		private double _rotationImage;

		// Token: 0x04000F9C RID: 3996
		private bool _expandRotationCanvas = true;

		// Token: 0x04000F9D RID: 3997
		private string _rotationFillColor = "Black";

		// Token: 0x04000F9E RID: 3998
		private bool _showCenter;

		// Token: 0x04000F9F RID: 3999
		private double _centerLength = 100.0;

		// Token: 0x04000FA0 RID: 4000
		private double _centerAngle;
	}
}
