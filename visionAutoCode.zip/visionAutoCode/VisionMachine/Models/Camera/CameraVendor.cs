﻿using System;

namespace VisionMachine.Models.Camera
{
	// Token: 0x020002A3 RID: 675
	public enum CameraVendor
	{
		// Token: 0x04000FA3 RID: 4003
		Unknown,
		// Token: 0x04000FA4 RID: 4004
		Basler,
		// Token: 0x04000FA5 RID: 4005
		Hikvision
	}
}
