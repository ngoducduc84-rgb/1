﻿using System;

namespace VisionMachine.Models.Camera
{
	// Token: 0x020002A4 RID: 676
	public class ConnectedCameraInfo
	{
		// Token: 0x17000AE4 RID: 2788
		// (get) Token: 0x06002535 RID: 9525 RVA: 0x000D94E9 File Offset: 0x000D76E9
		// (set) Token: 0x06002536 RID: 9526 RVA: 0x000D94F1 File Offset: 0x000D76F1
		public string Id { get; set; }

		// Token: 0x17000AE5 RID: 2789
		// (get) Token: 0x06002537 RID: 9527 RVA: 0x000D94FA File Offset: 0x000D76FA
		// (set) Token: 0x06002538 RID: 9528 RVA: 0x000D9502 File Offset: 0x000D7702
		public string Name { get; set; }

		// Token: 0x17000AE6 RID: 2790
		// (get) Token: 0x06002539 RID: 9529 RVA: 0x000D950B File Offset: 0x000D770B
		// (set) Token: 0x0600253A RID: 9530 RVA: 0x000D9513 File Offset: 0x000D7713
		public CameraVendor Vendor { get; set; }

		// Token: 0x17000AE7 RID: 2791
		// (get) Token: 0x0600253B RID: 9531 RVA: 0x000D951C File Offset: 0x000D771C
		public string DisplayName
		{
			get
			{
				bool flag = string.IsNullOrWhiteSpace(this.Id) && string.Equals(this.Name, "None", StringComparison.OrdinalIgnoreCase);
				string result;
				if (flag)
				{
					result = "None";
				}
				else
				{
					string vendor = (this.Vendor == CameraVendor.Unknown) ? "Camera" : this.Vendor.ToString();
					bool flag2 = string.IsNullOrWhiteSpace(this.Id);
					if (flag2)
					{
						result = vendor + " - " + (this.Name ?? "Unknown");
					}
					else
					{
						result = string.Concat(new string[]
						{
							vendor,
							" - ",
							this.Name ?? "Unknown",
							" (",
							this.Id,
							")"
						});
					}
				}
				return result;
			}
		}
	}
}
