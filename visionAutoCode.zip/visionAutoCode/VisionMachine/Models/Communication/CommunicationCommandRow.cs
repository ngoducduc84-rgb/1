﻿using System;

namespace VisionMachine.Models.Communication
{
	// Token: 0x02000292 RID: 658
	public class CommunicationCommandRow
	{
		// Token: 0x17000A78 RID: 2680
		// (get) Token: 0x06002438 RID: 9272 RVA: 0x000D7AFE File Offset: 0x000D5CFE
		// (set) Token: 0x06002439 RID: 9273 RVA: 0x000D7B06 File Offset: 0x000D5D06
		public string Time { get; set; }

		// Token: 0x17000A79 RID: 2681
		// (get) Token: 0x0600243A RID: 9274 RVA: 0x000D7B0F File Offset: 0x000D5D0F
		// (set) Token: 0x0600243B RID: 9275 RVA: 0x000D7B17 File Offset: 0x000D5D17
		public string Command { get; set; }

		// Token: 0x17000A7A RID: 2682
		// (get) Token: 0x0600243C RID: 9276 RVA: 0x000D7B20 File Offset: 0x000D5D20
		// (set) Token: 0x0600243D RID: 9277 RVA: 0x000D7B28 File Offset: 0x000D5D28
		public string Address { get; set; }

		// Token: 0x17000A7B RID: 2683
		// (get) Token: 0x0600243E RID: 9278 RVA: 0x000D7B31 File Offset: 0x000D5D31
		// (set) Token: 0x0600243F RID: 9279 RVA: 0x000D7B39 File Offset: 0x000D5D39
		public string Value { get; set; }

		// Token: 0x17000A7C RID: 2684
		// (get) Token: 0x06002440 RID: 9280 RVA: 0x000D7B42 File Offset: 0x000D5D42
		// (set) Token: 0x06002441 RID: 9281 RVA: 0x000D7B4A File Offset: 0x000D5D4A
		public string Result { get; set; }
	}
}
