﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using Newtonsoft.Json;

namespace VisionMachine.Models.Communication
{
	// Token: 0x02000293 RID: 659
	public class CommunicationConnection : INotifyPropertyChanged
	{
		// Token: 0x14000044 RID: 68
		// (add) Token: 0x06002443 RID: 9283 RVA: 0x000D7B54 File Offset: 0x000D5D54
		// (remove) Token: 0x06002444 RID: 9284 RVA: 0x000D7B8C File Offset: 0x000D5D8C
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x17000A7D RID: 2685
		// (get) Token: 0x06002445 RID: 9285 RVA: 0x000D7BC1 File Offset: 0x000D5DC1
		// (set) Token: 0x06002446 RID: 9286 RVA: 0x000D7BC9 File Offset: 0x000D5DC9
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				this.SetValue<string>(ref this._name, value, "Name");
			}
		}

		// Token: 0x17000A7E RID: 2686
		// (get) Token: 0x06002447 RID: 9287 RVA: 0x000D7BDE File Offset: 0x000D5DDE
		// (set) Token: 0x06002448 RID: 9288 RVA: 0x000D7BE8 File Offset: 0x000D5DE8
		public string Protocol
		{
			get
			{
				return this._protocol;
			}
			set
			{
				bool flag = this.SetValue<string>(ref this._protocol, value, "Protocol");
				if (flag)
				{
					this.OnPropertyChanged("ProtocolShortName");
					this.OnPropertyChanged("ProtocolBrush");
				}
			}
		}

		// Token: 0x17000A7F RID: 2687
		// (get) Token: 0x06002449 RID: 9289 RVA: 0x000D7C26 File Offset: 0x000D5E26
		// (set) Token: 0x0600244A RID: 9290 RVA: 0x000D7C30 File Offset: 0x000D5E30
		public string Status
		{
			get
			{
				return this._status;
			}
			set
			{
				bool flag = this.SetValue<string>(ref this._status, value, "Status");
				if (flag)
				{
					this.OnPropertyChanged("StatusBrush");
				}
			}
		}

		// Token: 0x17000A80 RID: 2688
		// (get) Token: 0x0600244B RID: 9291 RVA: 0x000D7C60 File Offset: 0x000D5E60
		// (set) Token: 0x0600244C RID: 9292 RVA: 0x000D7C68 File Offset: 0x000D5E68
		public string Description
		{
			get
			{
				return this._description;
			}
			set
			{
				this.SetValue<string>(ref this._description, value, "Description");
			}
		}

		// Token: 0x17000A81 RID: 2689
		// (get) Token: 0x0600244D RID: 9293 RVA: 0x000D7C7D File Offset: 0x000D5E7D
		// (set) Token: 0x0600244E RID: 9294 RVA: 0x000D7C85 File Offset: 0x000D5E85
		public string IpAddress
		{
			get
			{
				return this._ipAddress;
			}
			set
			{
				this.SetValue<string>(ref this._ipAddress, value, "IpAddress");
			}
		}

		// Token: 0x17000A82 RID: 2690
		// (get) Token: 0x0600244F RID: 9295 RVA: 0x000D7C9A File Offset: 0x000D5E9A
		// (set) Token: 0x06002450 RID: 9296 RVA: 0x000D7CA2 File Offset: 0x000D5EA2
		public int Port
		{
			get
			{
				return this._port;
			}
			set
			{
				this.SetValue<int>(ref this._port, value, "Port");
			}
		}

		// Token: 0x17000A83 RID: 2691
		// (get) Token: 0x06002451 RID: 9297 RVA: 0x000D7CB7 File Offset: 0x000D5EB7
		// (set) Token: 0x06002452 RID: 9298 RVA: 0x000D7CBF File Offset: 0x000D5EBF
		public int TimeoutMs
		{
			get
			{
				return this._timeoutMs;
			}
			set
			{
				this.SetValue<int>(ref this._timeoutMs, value, "TimeoutMs");
			}
		}

		// Token: 0x17000A84 RID: 2692
		// (get) Token: 0x06002453 RID: 9299 RVA: 0x000D7CD4 File Offset: 0x000D5ED4
		// (set) Token: 0x06002454 RID: 9300 RVA: 0x000D7CDC File Offset: 0x000D5EDC
		public int LogicalStationNumber
		{
			get
			{
				return this._logicalStationNumber;
			}
			set
			{
				this.SetValue<int>(ref this._logicalStationNumber, value, "LogicalStationNumber");
			}
		}

		// Token: 0x17000A85 RID: 2693
		// (get) Token: 0x06002455 RID: 9301 RVA: 0x000D7CF1 File Offset: 0x000D5EF1
		// (set) Token: 0x06002456 RID: 9302 RVA: 0x000D7CF9 File Offset: 0x000D5EF9
		public string ExchangeInterval
		{
			get
			{
				return this._exchangeInterval;
			}
			set
			{
				this.SetValue<string>(ref this._exchangeInterval, value, "ExchangeInterval");
			}
		}

		// Token: 0x17000A86 RID: 2694
		// (get) Token: 0x06002457 RID: 9303 RVA: 0x000D7D0E File Offset: 0x000D5F0E
		// (set) Token: 0x06002458 RID: 9304 RVA: 0x000D7D16 File Offset: 0x000D5F16
		public string ByteOrder
		{
			get
			{
				return this._byteOrder;
			}
			set
			{
				this.SetValue<string>(ref this._byteOrder, value, "ByteOrder");
			}
		}

		// Token: 0x17000A87 RID: 2695
		// (get) Token: 0x06002459 RID: 9305 RVA: 0x000D7D2B File Offset: 0x000D5F2B
		// (set) Token: 0x0600245A RID: 9306 RVA: 0x000D7D33 File Offset: 0x000D5F33
		public string WordOrder
		{
			get
			{
				return this._wordOrder;
			}
			set
			{
				this.SetValue<string>(ref this._wordOrder, value, "WordOrder");
			}
		}

		// Token: 0x17000A88 RID: 2696
		// (get) Token: 0x0600245B RID: 9307 RVA: 0x000D7D48 File Offset: 0x000D5F48
		// (set) Token: 0x0600245C RID: 9308 RVA: 0x000D7D50 File Offset: 0x000D5F50
		public string FloatFormat
		{
			get
			{
				return this._floatFormat;
			}
			set
			{
				this.SetValue<string>(ref this._floatFormat, value, "FloatFormat");
			}
		}

		// Token: 0x17000A89 RID: 2697
		// (get) Token: 0x0600245D RID: 9309 RVA: 0x000D7D65 File Offset: 0x000D5F65
		// (set) Token: 0x0600245E RID: 9310 RVA: 0x000D7D6D File Offset: 0x000D5F6D
		public bool KeepAlive
		{
			get
			{
				return this._keepAlive;
			}
			set
			{
				this.SetValue<bool>(ref this._keepAlive, value, "KeepAlive");
			}
		}

		// Token: 0x17000A8A RID: 2698
		// (get) Token: 0x0600245F RID: 9311 RVA: 0x000D7D82 File Offset: 0x000D5F82
		// (set) Token: 0x06002460 RID: 9312 RVA: 0x000D7D8A File Offset: 0x000D5F8A
		public bool AutoReconnect
		{
			get
			{
				return this._autoReconnect;
			}
			set
			{
				this.SetValue<bool>(ref this._autoReconnect, value, "AutoReconnect");
			}
		}

		// Token: 0x17000A8B RID: 2699
		// (get) Token: 0x06002461 RID: 9313 RVA: 0x000D7D9F File Offset: 0x000D5F9F
		// (set) Token: 0x06002462 RID: 9314 RVA: 0x000D7DA7 File Offset: 0x000D5FA7
		public string MonitorStartAddress
		{
			get
			{
				return this._monitorStartAddress;
			}
			set
			{
				this.SetValue<string>(ref this._monitorStartAddress, value, "MonitorStartAddress");
			}
		}

		// Token: 0x17000A8C RID: 2700
		// (get) Token: 0x06002463 RID: 9315 RVA: 0x000D7DBC File Offset: 0x000D5FBC
		// (set) Token: 0x06002464 RID: 9316 RVA: 0x000D7DC4 File Offset: 0x000D5FC4
		public string MonitorEndAddress
		{
			get
			{
				return this._monitorEndAddress;
			}
			set
			{
				this.SetValue<string>(ref this._monitorEndAddress, value, "MonitorEndAddress");
			}
		}

		// Token: 0x17000A8D RID: 2701
		// (get) Token: 0x06002465 RID: 9317 RVA: 0x000D7DD9 File Offset: 0x000D5FD9
		// (set) Token: 0x06002466 RID: 9318 RVA: 0x000D7DE1 File Offset: 0x000D5FE1
		public string MonitorDataType
		{
			get
			{
				return this._monitorDataType;
			}
			set
			{
				this.SetValue<string>(ref this._monitorDataType, value, "MonitorDataType");
			}
		}

		// Token: 0x17000A8E RID: 2702
		// (get) Token: 0x06002467 RID: 9319 RVA: 0x000D7DF6 File Offset: 0x000D5FF6
		// (set) Token: 0x06002468 RID: 9320 RVA: 0x000D7DFE File Offset: 0x000D5FFE
		public string MonitorFunctionCode
		{
			get
			{
				return this._monitorFunctionCode;
			}
			set
			{
				this.SetValue<string>(ref this._monitorFunctionCode, value, "MonitorFunctionCode");
			}
		}

		// Token: 0x17000A8F RID: 2703
		// (get) Token: 0x06002469 RID: 9321 RVA: 0x000D7E13 File Offset: 0x000D6013
		// (set) Token: 0x0600246A RID: 9322 RVA: 0x000D7E1B File Offset: 0x000D601B
		public string ConnectedTime
		{
			get
			{
				return this._connectedTime;
			}
			set
			{
				this.SetValue<string>(ref this._connectedTime, value, "ConnectedTime");
			}
		}

		// Token: 0x17000A90 RID: 2704
		// (get) Token: 0x0600246B RID: 9323 RVA: 0x000D7E30 File Offset: 0x000D6030
		// (set) Token: 0x0600246C RID: 9324 RVA: 0x000D7E38 File Offset: 0x000D6038
		public string LastUpdate
		{
			get
			{
				return this._lastUpdate;
			}
			set
			{
				this.SetValue<string>(ref this._lastUpdate, value, "LastUpdate");
			}
		}

		// Token: 0x17000A91 RID: 2705
		// (get) Token: 0x0600246D RID: 9325 RVA: 0x000D7E4D File Offset: 0x000D604D
		// (set) Token: 0x0600246E RID: 9326 RVA: 0x000D7E55 File Offset: 0x000D6055
		public string SendBytes
		{
			get
			{
				return this._sendBytes;
			}
			set
			{
				this.SetValue<string>(ref this._sendBytes, value, "SendBytes");
			}
		}

		// Token: 0x17000A92 RID: 2706
		// (get) Token: 0x0600246F RID: 9327 RVA: 0x000D7E6A File Offset: 0x000D606A
		// (set) Token: 0x06002470 RID: 9328 RVA: 0x000D7E72 File Offset: 0x000D6072
		public string ReceiveBytes
		{
			get
			{
				return this._receiveBytes;
			}
			set
			{
				this.SetValue<string>(ref this._receiveBytes, value, "ReceiveBytes");
			}
		}

		// Token: 0x17000A93 RID: 2707
		// (get) Token: 0x06002471 RID: 9329 RVA: 0x000D7E87 File Offset: 0x000D6087
		// (set) Token: 0x06002472 RID: 9330 RVA: 0x000D7E8F File Offset: 0x000D608F
		public int ErrorCount
		{
			get
			{
				return this._errorCount;
			}
			set
			{
				this.SetValue<int>(ref this._errorCount, value, "ErrorCount");
			}
		}

		// Token: 0x17000A94 RID: 2708
		// (get) Token: 0x06002473 RID: 9331 RVA: 0x000D7EA4 File Offset: 0x000D60A4
		// (set) Token: 0x06002474 RID: 9332 RVA: 0x000D7EAC File Offset: 0x000D60AC
		[JsonIgnore]
		public bool IsSelected
		{
			get
			{
				return this._isSelected;
			}
			set
			{
				bool flag = this.SetValue<bool>(ref this._isSelected, value, "IsSelected");
				if (flag)
				{
					this.OnPropertyChanged("CardBackgroundBrush");
					this.OnPropertyChanged("CardBorderBrush");
				}
			}
		}

		// Token: 0x17000A95 RID: 2709
		// (get) Token: 0x06002475 RID: 9333 RVA: 0x000D7EEA File Offset: 0x000D60EA
		[JsonIgnore]
		public Brush CardBackgroundBrush
		{
			get
			{
				return this.IsSelected ? new SolidColorBrush(Color.FromRgb(19, 47, 91)) : new SolidColorBrush(Color.FromRgb(16, 26, 37));
			}
		}

		// Token: 0x17000A96 RID: 2710
		// (get) Token: 0x06002476 RID: 9334 RVA: 0x000D7F16 File Offset: 0x000D6116
		[JsonIgnore]
		public Brush CardBorderBrush
		{
			get
			{
				return this.IsSelected ? new SolidColorBrush(Color.FromRgb(68, 128, byte.MaxValue)) : new SolidColorBrush(Color.FromRgb(38, 51, 66));
			}
		}

		// Token: 0x17000A97 RID: 2711
		// (get) Token: 0x06002477 RID: 9335 RVA: 0x000D7F48 File Offset: 0x000D6148
		[JsonIgnore]
		public Brush StatusBrush
		{
			get
			{
				string status = this.Status;
				string a = status;
				Brush result;
				if (!(a == "Connected"))
				{
					if (!(a == "Connecting..."))
					{
						result = Brushes.IndianRed;
					}
					else
					{
						result = Brushes.Gold;
					}
				}
				else
				{
					result = Brushes.LimeGreen;
				}
				return result;
			}
		}

		// Token: 0x17000A98 RID: 2712
		// (get) Token: 0x06002478 RID: 9336 RVA: 0x000D7F94 File Offset: 0x000D6194
		[JsonIgnore]
		public string ProtocolShortName
		{
			get
			{
				string protocol = this.Protocol;
				string a = protocol;
				string result;
				if (!(a == "Modbus Server TCP/IP"))
				{
					if (!(a == "OPC UA"))
					{
						if (!(a == "MX Component"))
						{
							result = "CLI";
						}
						else
						{
							result = "MX";
						}
					}
					else
					{
						result = "OPC";
					}
				}
				else
				{
					result = "SRV";
				}
				return result;
			}
		}

		// Token: 0x17000A99 RID: 2713
		// (get) Token: 0x06002479 RID: 9337 RVA: 0x000D7FF8 File Offset: 0x000D61F8
		[JsonIgnore]
		public Brush ProtocolBrush
		{
			get
			{
				string protocol = this.Protocol;
				string a = protocol;
				Brush result;
				if (!(a == "Modbus Server TCP/IP"))
				{
					if (!(a == "OPC UA"))
					{
						if (!(a == "MX Component"))
						{
							result = new SolidColorBrush(Color.FromRgb(44, 132, byte.MaxValue));
						}
						else
						{
							result = new SolidColorBrush(Color.FromRgb(232, 121, 41));
						}
					}
					else
					{
						result = new SolidColorBrush(Color.FromRgb(168, 85, 247));
					}
				}
				else
				{
					result = new SolidColorBrush(Color.FromRgb(64, 180, 82));
				}
				return result;
			}
		}

		// Token: 0x0600247A RID: 9338 RVA: 0x000D8098 File Offset: 0x000D6298
		public void ApplyDefaultPort()
		{
			string protocol = this.Protocol;
			string a = protocol;
			if (!(a == "Modbus Server TCP/IP"))
			{
				if (!(a == "OPC UA"))
				{
					if (!(a == "MX Component"))
					{
						if (!(a == "MC Protocol"))
						{
							this.Port = 502;
						}
						else
						{
							this.Port = 5007;
						}
					}
					else
					{
						this.Port = 0;
					}
				}
				else
				{
					this.Port = 4840;
				}
			}
			else
			{
				this.Port = 502;
			}
		}

		// Token: 0x0600247B RID: 9339 RVA: 0x000D8128 File Offset: 0x000D6328
		public void AddTraffic(int sentBytes, int receivedBytes)
		{
			bool flag = sentBytes > 0;
			if (flag)
			{
				this._totalSentBytes += (long)sentBytes;
			}
			bool flag2 = receivedBytes > 0;
			if (flag2)
			{
				this._totalReceivedBytes += (long)receivedBytes;
			}
			this.SendBytes = CommunicationConnection.FormatBytes(this._totalSentBytes);
			this.ReceiveBytes = CommunicationConnection.FormatBytes(this._totalReceivedBytes);
		}

		// Token: 0x0600247C RID: 9340 RVA: 0x000D8188 File Offset: 0x000D6388
		private static string FormatBytes(long bytes)
		{
			bool flag = bytes >= 1048576L;
			string result;
			if (flag)
			{
				result = string.Format("{0:0.##} MB", (double)bytes / 1024.0 / 1024.0);
			}
			else
			{
				bool flag2 = bytes >= 1024L;
				if (flag2)
				{
					result = string.Format("{0:0.##} KB", (double)bytes / 1024.0);
				}
				else
				{
					result = string.Format("{0} B", bytes);
				}
			}
			return result;
		}

		// Token: 0x0600247D RID: 9341 RVA: 0x000D8210 File Offset: 0x000D6410
		private bool SetValue<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
		{
			bool flag = object.Equals(field, value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				field = value;
				this.OnPropertyChanged(propertyName);
				result = true;
			}
			return result;
		}

		// Token: 0x0600247E RID: 9342 RVA: 0x000D8250 File Offset: 0x000D6450
		private void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000F37 RID: 3895
		private string _name;

		// Token: 0x04000F38 RID: 3896
		private string _protocol = "Modbus Client TCP/IP";

		// Token: 0x04000F39 RID: 3897
		private string _status = "Disconnected";

		// Token: 0x04000F3A RID: 3898
		private string _description;

		// Token: 0x04000F3B RID: 3899
		private string _ipAddress;

		// Token: 0x04000F3C RID: 3900
		private int _port;

		// Token: 0x04000F3D RID: 3901
		private int _timeoutMs = 2000;

		// Token: 0x04000F3E RID: 3902
		private int _logicalStationNumber;

		// Token: 0x04000F3F RID: 3903
		private string _exchangeInterval = "10 ms";

		// Token: 0x04000F40 RID: 3904
		private string _byteOrder = "Big Endian (AB CD)";

		// Token: 0x04000F41 RID: 3905
		private string _wordOrder = "Big Endian (AB CD)";

		// Token: 0x04000F42 RID: 3906
		private string _floatFormat = "IEEE 754";

		// Token: 0x04000F43 RID: 3907
		private bool _keepAlive = true;

		// Token: 0x04000F44 RID: 3908
		private bool _autoReconnect = true;

		// Token: 0x04000F45 RID: 3909
		private string _monitorStartAddress = "40001";

		// Token: 0x04000F46 RID: 3910
		private string _monitorEndAddress = "40010";

		// Token: 0x04000F47 RID: 3911
		private string _monitorDataType = "UINT16";

		// Token: 0x04000F48 RID: 3912
		private string _monitorFunctionCode = "03 Read Holding Registers";

		// Token: 0x04000F49 RID: 3913
		private string _connectedTime = "--";

		// Token: 0x04000F4A RID: 3914
		private string _lastUpdate = "--";

		// Token: 0x04000F4B RID: 3915
		private string _sendBytes = "0 B";

		// Token: 0x04000F4C RID: 3916
		private string _receiveBytes = "0 B";

		// Token: 0x04000F4D RID: 3917
		private long _totalSentBytes;

		// Token: 0x04000F4E RID: 3918
		private long _totalReceivedBytes;

		// Token: 0x04000F4F RID: 3919
		private int _errorCount;

		// Token: 0x04000F50 RID: 3920
		private bool _isSelected;
	}
}
