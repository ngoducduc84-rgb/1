﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Communication
{
	// Token: 0x02000294 RID: 660
	public class CommunicationInitialValueRow : INotifyPropertyChanged
	{
		// Token: 0x14000045 RID: 69
		// (add) Token: 0x06002480 RID: 9344 RVA: 0x000D8334 File Offset: 0x000D6534
		// (remove) Token: 0x06002481 RID: 9345 RVA: 0x000D836C File Offset: 0x000D656C
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x17000A9A RID: 2714
		// (get) Token: 0x06002482 RID: 9346 RVA: 0x000D83A1 File Offset: 0x000D65A1
		// (set) Token: 0x06002483 RID: 9347 RVA: 0x000D83A9 File Offset: 0x000D65A9
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				this.SetValue<string>(ref this._name, value, "Name");
			}
		}

		// Token: 0x17000A9B RID: 2715
		// (get) Token: 0x06002484 RID: 9348 RVA: 0x000D83BE File Offset: 0x000D65BE
		// (set) Token: 0x06002485 RID: 9349 RVA: 0x000D83C6 File Offset: 0x000D65C6
		public string Address
		{
			get
			{
				return this._address;
			}
			set
			{
				this.SetValue<string>(ref this._address, value, "Address");
			}
		}

		// Token: 0x17000A9C RID: 2716
		// (get) Token: 0x06002486 RID: 9350 RVA: 0x000D83DB File Offset: 0x000D65DB
		// (set) Token: 0x06002487 RID: 9351 RVA: 0x000D83E3 File Offset: 0x000D65E3
		public string Value
		{
			get
			{
				return this._value;
			}
			set
			{
				this.SetValue<string>(ref this._value, value, "Value");
			}
		}

		// Token: 0x17000A9D RID: 2717
		// (get) Token: 0x06002488 RID: 9352 RVA: 0x000D83F8 File Offset: 0x000D65F8
		// (set) Token: 0x06002489 RID: 9353 RVA: 0x000D8400 File Offset: 0x000D6600
		public string DataType
		{
			get
			{
				return this._dataType;
			}
			set
			{
				this.SetValue<string>(ref this._dataType, value, "DataType");
			}
		}

		// Token: 0x0600248A RID: 9354 RVA: 0x000D8418 File Offset: 0x000D6618
		private void SetValue<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
		{
			bool flag = object.Equals(field, value);
			if (!flag)
			{
				field = value;
				PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
				if (propertyChanged != null)
				{
					propertyChanged(this, new PropertyChangedEventArgs(propertyName));
				}
			}
		}

		// Token: 0x04000F52 RID: 3922
		private string _name;

		// Token: 0x04000F53 RID: 3923
		private string _address;

		// Token: 0x04000F54 RID: 3924
		private string _value;

		// Token: 0x04000F55 RID: 3925
		private string _dataType = "INT16";
	}
}
