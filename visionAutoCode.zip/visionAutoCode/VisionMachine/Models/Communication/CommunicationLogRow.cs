﻿using System;

namespace VisionMachine.Models.Communication
{
	// Token: 0x02000295 RID: 661
	public class CommunicationLogRow
	{
		// Token: 0x17000A9E RID: 2718
		// (get) Token: 0x0600248C RID: 9356 RVA: 0x000D8476 File Offset: 0x000D6676
		// (set) Token: 0x0600248D RID: 9357 RVA: 0x000D847E File Offset: 0x000D667E
		public string Time { get; set; }

		// Token: 0x17000A9F RID: 2719
		// (get) Token: 0x0600248E RID: 9358 RVA: 0x000D8487 File Offset: 0x000D6687
		// (set) Token: 0x0600248F RID: 9359 RVA: 0x000D848F File Offset: 0x000D668F
		public string Level { get; set; }

		// Token: 0x17000AA0 RID: 2720
		// (get) Token: 0x06002490 RID: 9360 RVA: 0x000D8498 File Offset: 0x000D6698
		// (set) Token: 0x06002491 RID: 9361 RVA: 0x000D84A0 File Offset: 0x000D66A0
		public string Message { get; set; }
	}
}
