﻿using System;

namespace VisionMachine.Models.Communication
{
	// Token: 0x02000296 RID: 662
	public class CommunicationMonitorRow
	{
		// Token: 0x06002493 RID: 9363 RVA: 0x000D84AC File Offset: 0x000D66AC
		public CommunicationMonitorRow(string address, string dataType, string value, string quality, string timestamp, string description) : this(null, null, null, address, dataType, value, quality, timestamp, description)
		{
		}

		// Token: 0x06002494 RID: 9364 RVA: 0x000D84D0 File Offset: 0x000D66D0
		public CommunicationMonitorRow(string tagName, string group, string readWrite, string address, string dataType, string value, string quality, string timestamp, string description)
		{
			this.TagName = tagName;
			this.Group = group;
			this.ReadWrite = readWrite;
			this.Address = address;
			this.DataType = dataType;
			this.Value = value;
			this.Quality = quality;
			this.Timestamp = timestamp;
			this.Description = description;
		}

		// Token: 0x17000AA1 RID: 2721
		// (get) Token: 0x06002495 RID: 9365 RVA: 0x000D8533 File Offset: 0x000D6733
		// (set) Token: 0x06002496 RID: 9366 RVA: 0x000D853B File Offset: 0x000D673B
		public string TagName { get; set; }

		// Token: 0x17000AA2 RID: 2722
		// (get) Token: 0x06002497 RID: 9367 RVA: 0x000D8544 File Offset: 0x000D6744
		// (set) Token: 0x06002498 RID: 9368 RVA: 0x000D854C File Offset: 0x000D674C
		public string Group { get; set; }

		// Token: 0x17000AA3 RID: 2723
		// (get) Token: 0x06002499 RID: 9369 RVA: 0x000D8555 File Offset: 0x000D6755
		// (set) Token: 0x0600249A RID: 9370 RVA: 0x000D855D File Offset: 0x000D675D
		public string ReadWrite { get; set; }

		// Token: 0x17000AA4 RID: 2724
		// (get) Token: 0x0600249B RID: 9371 RVA: 0x000D8566 File Offset: 0x000D6766
		// (set) Token: 0x0600249C RID: 9372 RVA: 0x000D856E File Offset: 0x000D676E
		public string Address { get; set; }

		// Token: 0x17000AA5 RID: 2725
		// (get) Token: 0x0600249D RID: 9373 RVA: 0x000D8577 File Offset: 0x000D6777
		// (set) Token: 0x0600249E RID: 9374 RVA: 0x000D857F File Offset: 0x000D677F
		public string DataType { get; set; }

		// Token: 0x17000AA6 RID: 2726
		// (get) Token: 0x0600249F RID: 9375 RVA: 0x000D8588 File Offset: 0x000D6788
		// (set) Token: 0x060024A0 RID: 9376 RVA: 0x000D8590 File Offset: 0x000D6790
		public string Value { get; set; }

		// Token: 0x17000AA7 RID: 2727
		// (get) Token: 0x060024A1 RID: 9377 RVA: 0x000D8599 File Offset: 0x000D6799
		// (set) Token: 0x060024A2 RID: 9378 RVA: 0x000D85A1 File Offset: 0x000D67A1
		public string Quality { get; set; }

		// Token: 0x17000AA8 RID: 2728
		// (get) Token: 0x060024A3 RID: 9379 RVA: 0x000D85AA File Offset: 0x000D67AA
		// (set) Token: 0x060024A4 RID: 9380 RVA: 0x000D85B2 File Offset: 0x000D67B2
		public string Timestamp { get; set; }

		// Token: 0x17000AA9 RID: 2729
		// (get) Token: 0x060024A5 RID: 9381 RVA: 0x000D85BB File Offset: 0x000D67BB
		// (set) Token: 0x060024A6 RID: 9382 RVA: 0x000D85C3 File Offset: 0x000D67C3
		public string Description { get; set; }
	}
}
