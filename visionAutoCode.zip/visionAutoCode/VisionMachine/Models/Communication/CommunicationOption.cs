﻿using System;

namespace VisionMachine.Models.Communication
{
	// Token: 0x02000297 RID: 663
	public class CommunicationOption
	{
		// Token: 0x060024A7 RID: 9383 RVA: 0x000D85CC File Offset: 0x000D67CC
		public CommunicationOption(string displayText, string value)
		{
			this.DisplayText = displayText;
			this.Value = value;
		}

		// Token: 0x17000AAA RID: 2730
		// (get) Token: 0x060024A8 RID: 9384 RVA: 0x000D85E6 File Offset: 0x000D67E6
		// (set) Token: 0x060024A9 RID: 9385 RVA: 0x000D85EE File Offset: 0x000D67EE
		public string DisplayText { get; set; }

		// Token: 0x17000AAB RID: 2731
		// (get) Token: 0x060024AA RID: 9386 RVA: 0x000D85F7 File Offset: 0x000D67F7
		// (set) Token: 0x060024AB RID: 9387 RVA: 0x000D85FF File Offset: 0x000D67FF
		public string Value { get; set; }
	}
}
