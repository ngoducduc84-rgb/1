﻿using System;
using Newtonsoft.Json;

namespace VisionMachine.Models.Communication
{
	// Token: 0x02000298 RID: 664
	public class CommunicationTagRow
	{
		// Token: 0x060024AC RID: 9388 RVA: 0x000D8608 File Offset: 0x000D6808
		public CommunicationTagRow()
		{
		}

		// Token: 0x060024AD RID: 9389 RVA: 0x000D8619 File Offset: 0x000D6819
		public CommunicationTagRow(string name, string address, string dataType, string readWrite, string description) : this(name, address, dataType, readWrite, description, null)
		{
		}

		// Token: 0x060024AE RID: 9390 RVA: 0x000D862C File Offset: 0x000D682C
		public CommunicationTagRow(string name, string address, string dataType, string readWrite, string description, string group)
		{
			this.Name = name;
			this.Address = address;
			this.DataType = dataType;
			this.ReadWrite = readWrite;
			this.Description = description;
			this.Group = group;
		}

		// Token: 0x17000AAC RID: 2732
		// (get) Token: 0x060024AF RID: 9391 RVA: 0x000D867B File Offset: 0x000D687B
		// (set) Token: 0x060024B0 RID: 9392 RVA: 0x000D8683 File Offset: 0x000D6883
		public string Group { get; set; }

		// Token: 0x17000AAD RID: 2733
		// (get) Token: 0x060024B1 RID: 9393 RVA: 0x000D868C File Offset: 0x000D688C
		// (set) Token: 0x060024B2 RID: 9394 RVA: 0x000D8694 File Offset: 0x000D6894
		public string Name { get; set; }

		// Token: 0x17000AAE RID: 2734
		// (get) Token: 0x060024B3 RID: 9395 RVA: 0x000D869D File Offset: 0x000D689D
		// (set) Token: 0x060024B4 RID: 9396 RVA: 0x000D86A5 File Offset: 0x000D68A5
		public string Address { get; set; }

		// Token: 0x17000AAF RID: 2735
		// (get) Token: 0x060024B5 RID: 9397 RVA: 0x000D86AE File Offset: 0x000D68AE
		// (set) Token: 0x060024B6 RID: 9398 RVA: 0x000D86B6 File Offset: 0x000D68B6
		public string DataType { get; set; }

		// Token: 0x17000AB0 RID: 2736
		// (get) Token: 0x060024B7 RID: 9399 RVA: 0x000D86BF File Offset: 0x000D68BF
		// (set) Token: 0x060024B8 RID: 9400 RVA: 0x000D86C7 File Offset: 0x000D68C7
		public string ReadWrite { get; set; }

		// Token: 0x17000AB1 RID: 2737
		// (get) Token: 0x060024B9 RID: 9401 RVA: 0x000D86D0 File Offset: 0x000D68D0
		// (set) Token: 0x060024BA RID: 9402 RVA: 0x000D86D8 File Offset: 0x000D68D8
		public string LinkedToolName { get; set; }

		// Token: 0x17000AB2 RID: 2738
		// (get) Token: 0x060024BB RID: 9403 RVA: 0x000D86E1 File Offset: 0x000D68E1
		// (set) Token: 0x060024BC RID: 9404 RVA: 0x000D86E9 File Offset: 0x000D68E9
		public string ResultField { get; set; }

		// Token: 0x17000AB3 RID: 2739
		// (get) Token: 0x060024BD RID: 9405 RVA: 0x000D86F2 File Offset: 0x000D68F2
		// (set) Token: 0x060024BE RID: 9406 RVA: 0x000D86FA File Offset: 0x000D68FA
		public int MaxResultCount { get; set; } = 1;

		// Token: 0x17000AB4 RID: 2740
		// (get) Token: 0x060024BF RID: 9407 RVA: 0x000D8703 File Offset: 0x000D6903
		// (set) Token: 0x060024C0 RID: 9408 RVA: 0x000D870B File Offset: 0x000D690B
		public string Description { get; set; }

		// Token: 0x17000AB5 RID: 2741
		// (get) Token: 0x060024C1 RID: 9409 RVA: 0x000D8714 File Offset: 0x000D6914
		// (set) Token: 0x060024C2 RID: 9410 RVA: 0x000D871C File Offset: 0x000D691C
		[JsonIgnore]
		public bool HasDuplicateValue { get; set; }

		// Token: 0x17000AB6 RID: 2742
		// (get) Token: 0x060024C3 RID: 9411 RVA: 0x000D8725 File Offset: 0x000D6925
		// (set) Token: 0x060024C4 RID: 9412 RVA: 0x000D872D File Offset: 0x000D692D
		[JsonIgnore]
		public string ValidationMessage { get; set; }
	}
}
