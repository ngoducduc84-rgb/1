﻿using System;

namespace VisionMachine.Models.Config
{
	// Token: 0x02000291 RID: 657
	public class LogSettingConfig
	{
		// Token: 0x17000A73 RID: 2675
		// (get) Token: 0x0600242D RID: 9261 RVA: 0x000D7A8A File Offset: 0x000D5C8A
		// (set) Token: 0x0600242E RID: 9262 RVA: 0x000D7A92 File Offset: 0x000D5C92
		public string SavePath { get; set; } = "C:\\Data_base_vision_DB\\VisionLogs";

		// Token: 0x17000A74 RID: 2676
		// (get) Token: 0x0600242F RID: 9263 RVA: 0x000D7A9B File Offset: 0x000D5C9B
		// (set) Token: 0x06002430 RID: 9264 RVA: 0x000D7AA3 File Offset: 0x000D5CA3
		public string FileFormat { get; set; } = "JSONL";

		// Token: 0x17000A75 RID: 2677
		// (get) Token: 0x06002431 RID: 9265 RVA: 0x000D7AAC File Offset: 0x000D5CAC
		// (set) Token: 0x06002432 RID: 9266 RVA: 0x000D7AB4 File Offset: 0x000D5CB4
		public bool NGSave { get; set; }

		// Token: 0x17000A76 RID: 2678
		// (get) Token: 0x06002433 RID: 9267 RVA: 0x000D7ABD File Offset: 0x000D5CBD
		// (set) Token: 0x06002434 RID: 9268 RVA: 0x000D7AC5 File Offset: 0x000D5CC5
		public bool OKSave { get; set; }

		// Token: 0x17000A77 RID: 2679
		// (get) Token: 0x06002435 RID: 9269 RVA: 0x000D7ACE File Offset: 0x000D5CCE
		// (set) Token: 0x06002436 RID: 9270 RVA: 0x000D7AD6 File Offset: 0x000D5CD6
		public bool LostMasterSave { get; set; }
	}
}
