﻿using System;

namespace VisionMachine.Models.Light
{
	// Token: 0x0200029C RID: 668
	public class ConnectedLightInfo
	{
		// Token: 0x17000ABF RID: 2751
		// (get) Token: 0x060024DE RID: 9438 RVA: 0x000D8B15 File Offset: 0x000D6D15
		// (set) Token: 0x060024DF RID: 9439 RVA: 0x000D8B1D File Offset: 0x000D6D1D
		public string Id { get; set; }

		// Token: 0x17000AC0 RID: 2752
		// (get) Token: 0x060024E0 RID: 9440 RVA: 0x000D8B26 File Offset: 0x000D6D26
		// (set) Token: 0x060024E1 RID: 9441 RVA: 0x000D8B2E File Offset: 0x000D6D2E
		public string Name { get; set; }

		// Token: 0x17000AC1 RID: 2753
		// (get) Token: 0x060024E2 RID: 9442 RVA: 0x000D8B37 File Offset: 0x000D6D37
		// (set) Token: 0x060024E3 RID: 9443 RVA: 0x000D8B3F File Offset: 0x000D6D3F
		public int ChannelCount { get; set; } = 4;

		// Token: 0x17000AC2 RID: 2754
		// (get) Token: 0x060024E4 RID: 9444 RVA: 0x000D8B48 File Offset: 0x000D6D48
		public string DisplayName
		{
			get
			{
				bool flag = string.IsNullOrWhiteSpace(this.Id) && string.Equals(this.Name, "None", StringComparison.OrdinalIgnoreCase);
				string result;
				if (flag)
				{
					result = "None";
				}
				else
				{
					bool flag2 = string.IsNullOrWhiteSpace(this.Id);
					if (flag2)
					{
						result = (this.Name ?? "Unknown");
					}
					else
					{
						result = (this.Name ?? "Light") + " (" + this.Id + ")";
					}
				}
				return result;
			}
		}
	}
}
