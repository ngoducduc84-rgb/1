﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Light
{
	// Token: 0x0200029A RID: 666
	public class LightChannelConfig : INotifyPropertyChanged
	{
		// Token: 0x17000AB7 RID: 2743
		// (get) Token: 0x060024C5 RID: 9413 RVA: 0x000D8738 File Offset: 0x000D6938
		// (set) Token: 0x060024C6 RID: 9414 RVA: 0x000D8750 File Offset: 0x000D6950
		public int Channel
		{
			get
			{
				return this._channel;
			}
			set
			{
				bool flag = this._channel != value;
				if (flag)
				{
					this._channel = value;
					this.OnPropertyChanged("Channel");
				}
			}
		}

		// Token: 0x17000AB8 RID: 2744
		// (get) Token: 0x060024C7 RID: 9415 RVA: 0x000D8784 File Offset: 0x000D6984
		// (set) Token: 0x060024C8 RID: 9416 RVA: 0x000D879C File Offset: 0x000D699C
		public LightChannelMode Mode
		{
			get
			{
				return this._mode;
			}
			set
			{
				bool flag = this._mode != value;
				if (flag)
				{
					this._mode = value;
					this.OnPropertyChanged("Mode");
				}
			}
		}

		// Token: 0x17000AB9 RID: 2745
		// (get) Token: 0x060024C9 RID: 9417 RVA: 0x000D87D0 File Offset: 0x000D69D0
		// (set) Token: 0x060024CA RID: 9418 RVA: 0x000D87E8 File Offset: 0x000D69E8
		public bool IsOn
		{
			get
			{
				return this._isOn;
			}
			set
			{
				bool flag = this._isOn != value;
				if (flag)
				{
					this._isOn = value;
					this.OnPropertyChanged("IsOn");
				}
			}
		}

		// Token: 0x17000ABA RID: 2746
		// (get) Token: 0x060024CB RID: 9419 RVA: 0x000D881C File Offset: 0x000D6A1C
		// (set) Token: 0x060024CC RID: 9420 RVA: 0x000D8834 File Offset: 0x000D6A34
		public double Brightness
		{
			get
			{
				return this._brightness;
			}
			set
			{
				bool flag = this._brightness != value;
				if (flag)
				{
					this._brightness = value;
					this.OnPropertyChanged("Brightness");
				}
			}
		}

		// Token: 0x14000046 RID: 70
		// (add) Token: 0x060024CD RID: 9421 RVA: 0x000D8868 File Offset: 0x000D6A68
		// (remove) Token: 0x060024CE RID: 9422 RVA: 0x000D88A0 File Offset: 0x000D6AA0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060024CF RID: 9423 RVA: 0x000D88D5 File Offset: 0x000D6AD5
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000F73 RID: 3955
		private int _channel;

		// Token: 0x04000F74 RID: 3956
		private LightChannelMode _mode = LightChannelMode.Manual;

		// Token: 0x04000F75 RID: 3957
		private bool _isOn;

		// Token: 0x04000F76 RID: 3958
		private double _brightness;
	}
}
