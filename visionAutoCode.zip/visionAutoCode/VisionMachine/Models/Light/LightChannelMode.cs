﻿using System;
using System.ComponentModel;

namespace VisionMachine.Models.Light
{
	// Token: 0x02000299 RID: 665
	public enum LightChannelMode
	{
		// Token: 0x04000F71 RID: 3953
		[Description("Manual")]
		Manual,
		// Token: 0x04000F72 RID: 3954
		[Description("On when camera trigger")]
		OnWhenTrigger
	}
}
