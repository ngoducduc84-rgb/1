﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Light
{
	// Token: 0x0200029B RID: 667
	public class LightControllerConfig : INotifyPropertyChanged
	{
		// Token: 0x17000ABB RID: 2747
		// (get) Token: 0x060024D1 RID: 9425 RVA: 0x000D8904 File Offset: 0x000D6B04
		// (set) Token: 0x060024D2 RID: 9426 RVA: 0x000D891C File Offset: 0x000D6B1C
		public string SerialNumber
		{
			get
			{
				return this._serialNumber;
			}
			set
			{
				bool flag = this._serialNumber != value;
				if (flag)
				{
					this._serialNumber = value;
					this.OnPropertyChanged("SerialNumber");
				}
			}
		}

		// Token: 0x17000ABC RID: 2748
		// (get) Token: 0x060024D3 RID: 9427 RVA: 0x000D8950 File Offset: 0x000D6B50
		// (set) Token: 0x060024D4 RID: 9428 RVA: 0x000D8968 File Offset: 0x000D6B68
		public int SelectedChannel
		{
			get
			{
				return this._selectedChannel;
			}
			set
			{
				bool flag = this._selectedChannel != value;
				if (flag)
				{
					this._selectedChannel = value;
					this.OnPropertyChanged("SelectedChannel");
				}
			}
		}

		// Token: 0x17000ABD RID: 2749
		// (get) Token: 0x060024D5 RID: 9429 RVA: 0x000D899C File Offset: 0x000D6B9C
		// (set) Token: 0x060024D6 RID: 9430 RVA: 0x000D89B4 File Offset: 0x000D6BB4
		public bool ApplyToAllChannels
		{
			get
			{
				return this._applyToAllChannels;
			}
			set
			{
				bool flag = this._applyToAllChannels != value;
				if (flag)
				{
					this._applyToAllChannels = value;
					this.OnPropertyChanged("ApplyToAllChannels");
				}
			}
		}

		// Token: 0x17000ABE RID: 2750
		// (get) Token: 0x060024D7 RID: 9431 RVA: 0x000D89E7 File Offset: 0x000D6BE7
		// (set) Token: 0x060024D8 RID: 9432 RVA: 0x000D89EF File Offset: 0x000D6BEF
		public List<LightChannelConfig> Channels { get; set; } = new List<LightChannelConfig>();

		// Token: 0x060024D9 RID: 9433 RVA: 0x000D89F8 File Offset: 0x000D6BF8
		public LightChannelConfig GetOrCreateChannel(int channel)
		{
			bool flag = this.Channels == null;
			if (flag)
			{
				this.Channels = new List<LightChannelConfig>();
			}
			LightChannelConfig config = this.Channels.FirstOrDefault((LightChannelConfig c) => c.Channel == channel);
			bool flag2 = config == null;
			if (flag2)
			{
				config = new LightChannelConfig
				{
					Channel = channel
				};
				this.Channels.Add(config);
			}
			return config;
		}

		// Token: 0x14000047 RID: 71
		// (add) Token: 0x060024DA RID: 9434 RVA: 0x000D8A78 File Offset: 0x000D6C78
		// (remove) Token: 0x060024DB RID: 9435 RVA: 0x000D8AB0 File Offset: 0x000D6CB0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060024DC RID: 9436 RVA: 0x000D8AE5 File Offset: 0x000D6CE5
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000F78 RID: 3960
		private string _serialNumber;

		// Token: 0x04000F79 RID: 3961
		private int _selectedChannel;

		// Token: 0x04000F7A RID: 3962
		private bool _applyToAllChannels;
	}
}
