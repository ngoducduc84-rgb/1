﻿using System;

namespace VisionMachine.Models.Light
{
	// Token: 0x0200029D RID: 669
	public class LightModelConfigData
	{
		// Token: 0x17000AC3 RID: 2755
		// (get) Token: 0x060024E6 RID: 9446 RVA: 0x000D8BDD File Offset: 0x000D6DDD
		// (set) Token: 0x060024E7 RID: 9447 RVA: 0x000D8BE5 File Offset: 0x000D6DE5
		public string ModelName { get; set; }

		// Token: 0x17000AC4 RID: 2756
		// (get) Token: 0x060024E8 RID: 9448 RVA: 0x000D8BEE File Offset: 0x000D6DEE
		// (set) Token: 0x060024E9 RID: 9449 RVA: 0x000D8BF6 File Offset: 0x000D6DF6
		public LightControllerConfig Light { get; set; } = new LightControllerConfig();
	}
}
