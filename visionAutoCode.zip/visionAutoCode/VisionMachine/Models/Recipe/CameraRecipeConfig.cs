﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Models.Recipe
{
	// Token: 0x0200028E RID: 654
	public class CameraRecipeConfig
	{
		// Token: 0x17000A64 RID: 2660
		// (get) Token: 0x0600240C RID: 9228 RVA: 0x000D7939 File Offset: 0x000D5B39
		// (set) Token: 0x0600240D RID: 9229 RVA: 0x000D7941 File Offset: 0x000D5B41
		public string CameraName { get; set; }

		// Token: 0x17000A65 RID: 2661
		// (get) Token: 0x0600240E RID: 9230 RVA: 0x000D794A File Offset: 0x000D5B4A
		// (set) Token: 0x0600240F RID: 9231 RVA: 0x000D7952 File Offset: 0x000D5B52
		public int CameraIndex { get; set; }

		// Token: 0x17000A66 RID: 2662
		// (get) Token: 0x06002410 RID: 9232 RVA: 0x000D795B File Offset: 0x000D5B5B
		// (set) Token: 0x06002411 RID: 9233 RVA: 0x000D7963 File Offset: 0x000D5B63
		public List<TurnSnapRecipeConfig> TurnSnaps { get; set; } = new List<TurnSnapRecipeConfig>();
	}
}
