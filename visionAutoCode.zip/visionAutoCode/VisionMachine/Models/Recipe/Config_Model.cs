﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Models.Recipe
{
	// Token: 0x0200028B RID: 651
	public static class Config_Model
	{
		// Token: 0x060023FE RID: 9214 RVA: 0x000D7834 File Offset: 0x000D5A34
		public static void SaveToJson(string filePath)
		{
			string json = JsonConvert.SerializeObject(Config_Model.model, Formatting.Indented);
			File.WriteAllText(filePath, json);
		}

		// Token: 0x060023FF RID: 9215 RVA: 0x000D7858 File Offset: 0x000D5A58
		public static Model LoadFromJson(string filePath)
		{
			string json = File.ReadAllText(filePath);
			return JsonConvert.DeserializeObject<Model>(json);
		}

		// Token: 0x06002400 RID: 9216 RVA: 0x000D7878 File Offset: 0x000D5A78
		public static void Delete_model()
		{
			string current_model = Config_Model.model.Current_model;
			string model_select = Config_Model.model.Model_select;
			string path_fodel_model = Manager_path.path_manager + "\\" + model_select;
			bool flag = Directory.Exists(path_fodel_model);
			if (flag)
			{
				Directory.Delete(path_fodel_model, true);
			}
		}

		// Token: 0x04000F19 RID: 3865
		public static Model model = new Model();
	}
}
