﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Models.Recipe
{
	// Token: 0x02000289 RID: 649
	public class Model
	{
		// Token: 0x17000A4F RID: 2639
		// (get) Token: 0x060023DA RID: 9178 RVA: 0x000D76DD File Offset: 0x000D58DD
		// (set) Token: 0x060023DB RID: 9179 RVA: 0x000D76E5 File Offset: 0x000D58E5
		public string Current_model { get; set; }

		// Token: 0x04000F07 RID: 3847
		public List<ModelConfig> List_model = new List<ModelConfig>();

		// Token: 0x04000F08 RID: 3848
		public string Model_select = "";
	}
}
