﻿using System;

namespace VisionMachine.Models.Recipe
{
	// Token: 0x0200028A RID: 650
	public class ModelConfig
	{
		// Token: 0x17000A50 RID: 2640
		// (get) Token: 0x060023DD RID: 9181 RVA: 0x000D770D File Offset: 0x000D590D
		// (set) Token: 0x060023DE RID: 9182 RVA: 0x000D7715 File Offset: 0x000D5915
		public Guid Id { get; set; } = Guid.NewGuid();

		// Token: 0x17000A51 RID: 2641
		// (get) Token: 0x060023DF RID: 9183 RVA: 0x000D771E File Offset: 0x000D591E
		// (set) Token: 0x060023E0 RID: 9184 RVA: 0x000D7726 File Offset: 0x000D5926
		public string Model_name { get; set; }

		// Token: 0x17000A52 RID: 2642
		// (get) Token: 0x060023E1 RID: 9185 RVA: 0x000D772F File Offset: 0x000D592F
		// (set) Token: 0x060023E2 RID: 9186 RVA: 0x000D7737 File Offset: 0x000D5937
		public string Description { get; set; }

		// Token: 0x17000A53 RID: 2643
		// (get) Token: 0x060023E3 RID: 9187 RVA: 0x000D7740 File Offset: 0x000D5940
		// (set) Token: 0x060023E4 RID: 9188 RVA: 0x000D7748 File Offset: 0x000D5948
		public string Category { get; set; }

		// Token: 0x17000A54 RID: 2644
		// (get) Token: 0x060023E5 RID: 9189 RVA: 0x000D7751 File Offset: 0x000D5951
		// (set) Token: 0x060023E6 RID: 9190 RVA: 0x000D7759 File Offset: 0x000D5959
		public string Version { get; set; }

		// Token: 0x17000A55 RID: 2645
		// (get) Token: 0x060023E7 RID: 9191 RVA: 0x000D7762 File Offset: 0x000D5962
		// (set) Token: 0x060023E8 RID: 9192 RVA: 0x000D776A File Offset: 0x000D596A
		public string Tags { get; set; }

		// Token: 0x17000A56 RID: 2646
		// (get) Token: 0x060023E9 RID: 9193 RVA: 0x000D7773 File Offset: 0x000D5973
		// (set) Token: 0x060023EA RID: 9194 RVA: 0x000D777B File Offset: 0x000D597B
		public string Created_By { get; set; }

		// Token: 0x17000A57 RID: 2647
		// (get) Token: 0x060023EB RID: 9195 RVA: 0x000D7784 File Offset: 0x000D5984
		// (set) Token: 0x060023EC RID: 9196 RVA: 0x000D778C File Offset: 0x000D598C
		public string Created_Date { get; set; }

		// Token: 0x17000A58 RID: 2648
		// (get) Token: 0x060023ED RID: 9197 RVA: 0x000D7795 File Offset: 0x000D5995
		// (set) Token: 0x060023EE RID: 9198 RVA: 0x000D779D File Offset: 0x000D599D
		public string Camera_Name { get; set; }

		// Token: 0x17000A59 RID: 2649
		// (get) Token: 0x060023EF RID: 9199 RVA: 0x000D77A6 File Offset: 0x000D59A6
		// (set) Token: 0x060023F0 RID: 9200 RVA: 0x000D77AE File Offset: 0x000D59AE
		public string Camera_Category { get; set; }

		// Token: 0x17000A5A RID: 2650
		// (get) Token: 0x060023F1 RID: 9201 RVA: 0x000D77B7 File Offset: 0x000D59B7
		// (set) Token: 0x060023F2 RID: 9202 RVA: 0x000D77BF File Offset: 0x000D59BF
		public string Camera_Version { get; set; }

		// Token: 0x17000A5B RID: 2651
		// (get) Token: 0x060023F3 RID: 9203 RVA: 0x000D77C8 File Offset: 0x000D59C8
		// (set) Token: 0x060023F4 RID: 9204 RVA: 0x000D77D0 File Offset: 0x000D59D0
		public string Camera_Tags { get; set; }

		// Token: 0x17000A5C RID: 2652
		// (get) Token: 0x060023F5 RID: 9205 RVA: 0x000D77D9 File Offset: 0x000D59D9
		// (set) Token: 0x060023F6 RID: 9206 RVA: 0x000D77E1 File Offset: 0x000D59E1
		public string Save_Path { get; set; }

		// Token: 0x17000A5D RID: 2653
		// (get) Token: 0x060023F7 RID: 9207 RVA: 0x000D77EA File Offset: 0x000D59EA
		// (set) Token: 0x060023F8 RID: 9208 RVA: 0x000D77F2 File Offset: 0x000D59F2
		public string File_Format { get; set; }

		// Token: 0x17000A5E RID: 2654
		// (get) Token: 0x060023F9 RID: 9209 RVA: 0x000D77FB File Offset: 0x000D59FB
		// (set) Token: 0x060023FA RID: 9210 RVA: 0x000D7803 File Offset: 0x000D5A03
		public int Quality { get; set; }

		// Token: 0x17000A5F RID: 2655
		// (get) Token: 0x060023FB RID: 9211 RVA: 0x000D780C File Offset: 0x000D5A0C
		// (set) Token: 0x060023FC RID: 9212 RVA: 0x000D7814 File Offset: 0x000D5A14
		public bool Auto_Save { get; set; }
	}
}
