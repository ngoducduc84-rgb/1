﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Models.Recipe
{
	// Token: 0x0200028C RID: 652
	public class ModelFileData
	{
		// Token: 0x17000A60 RID: 2656
		// (get) Token: 0x06002402 RID: 9218 RVA: 0x000D78CD File Offset: 0x000D5ACD
		// (set) Token: 0x06002403 RID: 9219 RVA: 0x000D78D5 File Offset: 0x000D5AD5
		public Guid? CurrentModelId { get; set; }

		// Token: 0x17000A61 RID: 2657
		// (get) Token: 0x06002404 RID: 9220 RVA: 0x000D78DE File Offset: 0x000D5ADE
		// (set) Token: 0x06002405 RID: 9221 RVA: 0x000D78E6 File Offset: 0x000D5AE6
		public List<ModelConfig> Models { get; set; } = new List<ModelConfig>();
	}
}
