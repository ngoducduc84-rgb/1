﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Models.Recipe
{
	// Token: 0x0200028D RID: 653
	public class RecipeConfig
	{
		// Token: 0x17000A62 RID: 2658
		// (get) Token: 0x06002407 RID: 9223 RVA: 0x000D7903 File Offset: 0x000D5B03
		// (set) Token: 0x06002408 RID: 9224 RVA: 0x000D790B File Offset: 0x000D5B0B
		public string ModelName { get; set; }

		// Token: 0x17000A63 RID: 2659
		// (get) Token: 0x06002409 RID: 9225 RVA: 0x000D7914 File Offset: 0x000D5B14
		// (set) Token: 0x0600240A RID: 9226 RVA: 0x000D791C File Offset: 0x000D5B1C
		public List<CameraRecipeConfig> Cameras { get; set; } = new List<CameraRecipeConfig>();
	}
}
