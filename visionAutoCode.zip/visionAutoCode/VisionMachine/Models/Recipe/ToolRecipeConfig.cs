﻿using System;
using System.Collections.Generic;
using VisionMachine.Models.Roi;

namespace VisionMachine.Models.Recipe
{
	// Token: 0x02000290 RID: 656
	public class ToolRecipeConfig
	{
		// Token: 0x17000A69 RID: 2665
		// (get) Token: 0x06002418 RID: 9240 RVA: 0x000D79B6 File Offset: 0x000D5BB6
		// (set) Token: 0x06002419 RID: 9241 RVA: 0x000D79BE File Offset: 0x000D5BBE
		public string ToolId { get; set; }

		// Token: 0x17000A6A RID: 2666
		// (get) Token: 0x0600241A RID: 9242 RVA: 0x000D79C7 File Offset: 0x000D5BC7
		// (set) Token: 0x0600241B RID: 9243 RVA: 0x000D79CF File Offset: 0x000D5BCF
		public int Index { get; set; }

		// Token: 0x17000A6B RID: 2667
		// (get) Token: 0x0600241C RID: 9244 RVA: 0x000D79D8 File Offset: 0x000D5BD8
		// (set) Token: 0x0600241D RID: 9245 RVA: 0x000D79E0 File Offset: 0x000D5BE0
		public string Name { get; set; }

		// Token: 0x17000A6C RID: 2668
		// (get) Token: 0x0600241E RID: 9246 RVA: 0x000D79E9 File Offset: 0x000D5BE9
		// (set) Token: 0x0600241F RID: 9247 RVA: 0x000D79F1 File Offset: 0x000D5BF1
		public string ToolType { get; set; }

		// Token: 0x17000A6D RID: 2669
		// (get) Token: 0x06002420 RID: 9248 RVA: 0x000D79FA File Offset: 0x000D5BFA
		// (set) Token: 0x06002421 RID: 9249 RVA: 0x000D7A02 File Offset: 0x000D5C02
		public object Config { get; set; }

		// Token: 0x17000A6E RID: 2670
		// (get) Token: 0x06002422 RID: 9250 RVA: 0x000D7A0B File Offset: 0x000D5C0B
		// (set) Token: 0x06002423 RID: 9251 RVA: 0x000D7A13 File Offset: 0x000D5C13
		public object Spec { get; set; }

		// Token: 0x17000A6F RID: 2671
		// (get) Token: 0x06002424 RID: 9252 RVA: 0x000D7A1C File Offset: 0x000D5C1C
		// (set) Token: 0x06002425 RID: 9253 RVA: 0x000D7A24 File Offset: 0x000D5C24
		public object TrainModel { get; set; }

		// Token: 0x17000A70 RID: 2672
		// (get) Token: 0x06002426 RID: 9254 RVA: 0x000D7A2D File Offset: 0x000D5C2D
		// (set) Token: 0x06002427 RID: 9255 RVA: 0x000D7A35 File Offset: 0x000D5C35
		public List<RoiData> RoiItems { get; set; } = new List<RoiData>();

		// Token: 0x17000A71 RID: 2673
		// (get) Token: 0x06002428 RID: 9256 RVA: 0x000D7A3E File Offset: 0x000D5C3E
		// (set) Token: 0x06002429 RID: 9257 RVA: 0x000D7A46 File Offset: 0x000D5C46
		public List<RoiData> LimitRoiItems { get; set; } = new List<RoiData>();

		// Token: 0x17000A72 RID: 2674
		// (get) Token: 0x0600242A RID: 9258 RVA: 0x000D7A4F File Offset: 0x000D5C4F
		// (set) Token: 0x0600242B RID: 9259 RVA: 0x000D7A57 File Offset: 0x000D5C57
		public List<RoiData> MaskRoiItems { get; set; } = new List<RoiData>();
	}
}
