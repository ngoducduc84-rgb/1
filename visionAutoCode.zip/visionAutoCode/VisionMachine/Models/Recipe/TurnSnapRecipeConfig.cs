﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Models.Recipe
{
	// Token: 0x0200028F RID: 655
	public class TurnSnapRecipeConfig
	{
		// Token: 0x17000A67 RID: 2663
		// (get) Token: 0x06002413 RID: 9235 RVA: 0x000D7980 File Offset: 0x000D5B80
		// (set) Token: 0x06002414 RID: 9236 RVA: 0x000D7988 File Offset: 0x000D5B88
		public int Index { get; set; }

		// Token: 0x17000A68 RID: 2664
		// (get) Token: 0x06002415 RID: 9237 RVA: 0x000D7991 File Offset: 0x000D5B91
		// (set) Token: 0x06002416 RID: 9238 RVA: 0x000D7999 File Offset: 0x000D5B99
		public List<ToolRecipeConfig> Tools { get; set; } = new List<ToolRecipeConfig>();
	}
}
