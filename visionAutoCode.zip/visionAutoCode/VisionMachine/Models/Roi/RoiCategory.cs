﻿using System;

namespace VisionMachine.Models.Roi
{
	// Token: 0x0200027F RID: 639
	public enum RoiCategory
	{
		// Token: 0x04000EB9 RID: 3769
		Normal,
		// Token: 0x04000EBA RID: 3770
		Limit,
		// Token: 0x04000EBB RID: 3771
		Mask
	}
}
