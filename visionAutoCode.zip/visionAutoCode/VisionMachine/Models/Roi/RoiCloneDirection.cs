﻿using System;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000281 RID: 641
	public enum RoiCloneDirection
	{
		// Token: 0x04000EC4 RID: 3780
		DownRight,
		// Token: 0x04000EC5 RID: 3781
		DownLeft,
		// Token: 0x04000EC6 RID: 3782
		UpRight,
		// Token: 0x04000EC7 RID: 3783
		UpLeft
	}
}
