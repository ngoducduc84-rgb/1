﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000282 RID: 642
	public class RoiCloneSettings : INotifyPropertyChanged
	{
		// Token: 0x17000A2B RID: 2603
		// (get) Token: 0x06002387 RID: 9095 RVA: 0x000D6C04 File Offset: 0x000D4E04
		// (set) Token: 0x06002388 RID: 9096 RVA: 0x000D6C1C File Offset: 0x000D4E1C
		public int Rows
		{
			get
			{
				return this._rows;
			}
			set
			{
				int v = (value < 1) ? 1 : value;
				bool flag = this._rows == v;
				if (!flag)
				{
					this._rows = v;
					this.OnPropertyChanged("Rows");
					this.OnPropertyChanged("TotalCount");
					this.OnPropertyChanged("CloneCount");
				}
			}
		}

		// Token: 0x17000A2C RID: 2604
		// (get) Token: 0x06002389 RID: 9097 RVA: 0x000D6C70 File Offset: 0x000D4E70
		// (set) Token: 0x0600238A RID: 9098 RVA: 0x000D6C88 File Offset: 0x000D4E88
		public int Columns
		{
			get
			{
				return this._columns;
			}
			set
			{
				int v = (value < 1) ? 1 : value;
				bool flag = this._columns == v;
				if (!flag)
				{
					this._columns = v;
					this.OnPropertyChanged("Columns");
					this.OnPropertyChanged("TotalCount");
					this.OnPropertyChanged("CloneCount");
				}
			}
		}

		// Token: 0x17000A2D RID: 2605
		// (get) Token: 0x0600238B RID: 9099 RVA: 0x000D6CDC File Offset: 0x000D4EDC
		// (set) Token: 0x0600238C RID: 9100 RVA: 0x000D6CF4 File Offset: 0x000D4EF4
		public double OffsetRow
		{
			get
			{
				return this._offsetRow;
			}
			set
			{
				bool flag = this._offsetRow != value;
				if (flag)
				{
					this._offsetRow = value;
					this.OnPropertyChanged("OffsetRow");
				}
			}
		}

		// Token: 0x17000A2E RID: 2606
		// (get) Token: 0x0600238D RID: 9101 RVA: 0x000D6D28 File Offset: 0x000D4F28
		// (set) Token: 0x0600238E RID: 9102 RVA: 0x000D6D40 File Offset: 0x000D4F40
		public double OffsetColumn
		{
			get
			{
				return this._offsetColumn;
			}
			set
			{
				bool flag = this._offsetColumn != value;
				if (flag)
				{
					this._offsetColumn = value;
					this.OnPropertyChanged("OffsetColumn");
				}
			}
		}

		// Token: 0x17000A2F RID: 2607
		// (get) Token: 0x0600238F RID: 9103 RVA: 0x000D6D74 File Offset: 0x000D4F74
		// (set) Token: 0x06002390 RID: 9104 RVA: 0x000D6D8C File Offset: 0x000D4F8C
		public RoiCloneDirection Direction
		{
			get
			{
				return this._direction;
			}
			set
			{
				bool flag = this._direction != value;
				if (flag)
				{
					this._direction = value;
					this.OnPropertyChanged("Direction");
				}
			}
		}

		// Token: 0x17000A30 RID: 2608
		// (get) Token: 0x06002391 RID: 9105 RVA: 0x000D6DC0 File Offset: 0x000D4FC0
		// (set) Token: 0x06002392 RID: 9106 RVA: 0x000D6DD8 File Offset: 0x000D4FD8
		public double Angle
		{
			get
			{
				return this._angle;
			}
			set
			{
				bool flag = this._angle != value;
				if (flag)
				{
					this._angle = value;
					this.OnPropertyChanged("Angle");
				}
			}
		}

		// Token: 0x17000A31 RID: 2609
		// (get) Token: 0x06002393 RID: 9107 RVA: 0x000D6E0C File Offset: 0x000D500C
		public int TotalCount
		{
			get
			{
				return this.Rows * this.Columns;
			}
		}

		// Token: 0x17000A32 RID: 2610
		// (get) Token: 0x06002394 RID: 9108 RVA: 0x000D6E2C File Offset: 0x000D502C
		public int CloneCount
		{
			get
			{
				return this.TotalCount - 1;
			}
		}

		// Token: 0x06002395 RID: 9109 RVA: 0x000D6E48 File Offset: 0x000D5048
		public RoiCloneSettings Copy()
		{
			return new RoiCloneSettings
			{
				Rows = this.Rows,
				Columns = this.Columns,
				OffsetRow = this.OffsetRow,
				OffsetColumn = this.OffsetColumn,
				Direction = this.Direction,
				Angle = this.Angle
			};
		}

		// Token: 0x14000041 RID: 65
		// (add) Token: 0x06002396 RID: 9110 RVA: 0x000D6EB0 File Offset: 0x000D50B0
		// (remove) Token: 0x06002397 RID: 9111 RVA: 0x000D6EE8 File Offset: 0x000D50E8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06002398 RID: 9112 RVA: 0x000D6F1D File Offset: 0x000D511D
		private void OnPropertyChanged([CallerMemberName] string name = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		// Token: 0x04000EC8 RID: 3784
		private int _rows = 2;

		// Token: 0x04000EC9 RID: 3785
		private int _columns = 2;

		// Token: 0x04000ECA RID: 3786
		private double _offsetRow = 100.0;

		// Token: 0x04000ECB RID: 3787
		private double _offsetColumn = 100.0;

		// Token: 0x04000ECC RID: 3788
		private RoiCloneDirection _direction = RoiCloneDirection.DownRight;

		// Token: 0x04000ECD RID: 3789
		private double _angle;
	}
}
