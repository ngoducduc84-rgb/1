﻿using System;
using System.Collections.Generic;
using HalconDotNet;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000280 RID: 640
	public class RoiController
	{
		// Token: 0x0600236E RID: 9070 RVA: 0x000D5614 File Offset: 0x000D3814
		public void SuspendInteraction(HWindow windowControl)
		{
			bool flag = this._interactionSuspended || windowControl == null;
			if (!flag)
			{
				this._interactionSuspended = true;
				RoiController.Detach(windowControl, this._currentRoi);
				RoiController.Detach(windowControl, this._lineLengthLabel);
			}
		}

		// Token: 0x0600236F RID: 9071 RVA: 0x000D5658 File Offset: 0x000D3858
		public bool IsClosedContourAwayFromCorner(double row, double column, double tolerance)
		{
			bool flag = this._currentRoi == null || (this._currentShape.GetValueOrDefault() != RoiShape.Polygon && this._currentShape.GetValueOrDefault() != RoiShape.FreeDraw);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					HTuple rows = this._currentRoi.GetDrawingObjectParams("row");
					HTuple columns = this._currentRoi.GetDrawingObjectParams("column");
					int count = Math.Min(rows.Length, columns.Length);
					bool flag2 = count < 3;
					if (flag2)
					{
						result = false;
					}
					else
					{
						double endGap = RoiController.Distance(rows[0].D, columns[0].D, rows[count - 1].D, columns[count - 1].D);
						bool flag3 = endGap > 0.5;
						if (flag3)
						{
							result = false;
						}
						else
						{
							double tol = Math.Max(0.0, tolerance);
							for (int i = 0; i < count; i++)
							{
								bool flag4 = RoiController.Distance(row, column, rows[i].D, columns[i].D) <= tol;
								if (flag4)
								{
									return false;
								}
							}
							result = true;
						}
					}
				}
				catch (HOperatorException)
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06002370 RID: 9072 RVA: 0x000D57B4 File Offset: 0x000D39B4
		private static double Distance(double row1, double column1, double row2, double column2)
		{
			double deltaRow = row1 - row2;
			double deltaColumn = column1 - column2;
			return Math.Sqrt(deltaRow * deltaRow + deltaColumn * deltaColumn);
		}

		// Token: 0x06002371 RID: 9073 RVA: 0x000D57DC File Offset: 0x000D39DC
		public void ResumeInteraction(HWindow windowControl)
		{
			bool flag = !this._interactionSuspended;
			if (!flag)
			{
				this._interactionSuspended = false;
				bool flag2 = windowControl == null;
				if (!flag2)
				{
					RoiController.Attach(windowControl, this._currentRoi);
					RoiController.Attach(windowControl, this._lineLengthLabel);
				}
			}
		}

		// Token: 0x06002372 RID: 9074 RVA: 0x000D5824 File Offset: 0x000D3A24
		private static void Detach(HWindow windowControl, HDrawingObject drawingObject)
		{
			bool flag = drawingObject == null;
			if (!flag)
			{
				try
				{
					windowControl.DetachDrawingObjectFromWindow(drawingObject);
				}
				catch
				{
				}
			}
		}

		// Token: 0x06002373 RID: 9075 RVA: 0x000D5860 File Offset: 0x000D3A60
		private static void Attach(HWindow windowControl, HDrawingObject drawingObject)
		{
			bool flag = drawingObject == null;
			if (!flag)
			{
				try
				{
					windowControl.AttachDrawingObjectToWindow(drawingObject);
				}
				catch
				{
				}
			}
		}

		// Token: 0x06002374 RID: 9076 RVA: 0x000D589C File Offset: 0x000D3A9C
		public void Clear(HWindow windowControl)
		{
			bool flag = this._lineLengthLabel != null;
			if (flag)
			{
				try
				{
					bool flag2 = windowControl != null;
					if (flag2)
					{
						windowControl.DetachDrawingObjectFromWindow(this._lineLengthLabel);
					}
				}
				catch
				{
				}
				try
				{
					this._lineLengthLabel.Dispose();
				}
				catch
				{
				}
				this._lineLengthLabel = null;
			}
			bool flag3 = this._currentRoi != null;
			if (flag3)
			{
				try
				{
					bool flag4 = windowControl != null;
					if (flag4)
					{
						windowControl.DetachDrawingObjectFromWindow(this._currentRoi);
					}
				}
				catch
				{
				}
				try
				{
					this._currentRoi.Dispose();
				}
				catch
				{
				}
				this._currentRoi = null;
			}
			bool flag5 = this._drawnRegion != null;
			if (flag5)
			{
				try
				{
					this._drawnRegion.Dispose();
				}
				catch
				{
				}
				this._drawnRegion = null;
			}
			this._currentShape = null;
			this._interactionSuspended = false;
		}

		// Token: 0x06002375 RID: 9077 RVA: 0x000D59C0 File Offset: 0x000D3BC0
		public void ShowRoi(RoiShape shape, HWindow windowControl)
		{
			bool flag = windowControl == null;
			if (!flag)
			{
				this.Clear(windowControl);
				switch (shape)
				{
				case RoiShape.Rectangle:
					this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.RECTANGLE1, new HTuple[]
					{
						200,
						200,
						600,
						800
					});
					break;
				case RoiShape.Rectangle2:
					this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.RECTANGLE2, new HTuple[]
					{
						400,
						400,
						0.3,
						150,
						100
					});
					break;
				case RoiShape.Circle:
					this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.CIRCLE, new HTuple[]
					{
						400,
						400,
						150
					});
					break;
				case RoiShape.Ellipse:
					this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.ELLIPSE, new HTuple[]
					{
						400,
						400,
						0.0,
						180,
						100
					});
					break;
				case RoiShape.Line:
					this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.LINE, new HTuple[]
					{
						300,
						300,
						700,
						700
					});
					break;
				case RoiShape.Polygon:
				{
					HTuple rows = new HTuple(new double[]
					{
						100.0,
						200.0,
						300.0,
						100.0
					});
					HTuple cols = new HTuple(new double[]
					{
						100.0,
						300.0,
						250.0,
						100.0
					});
					this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.XLD_CONTOUR, new HTuple[]
					{
						rows,
						cols
					});
					break;
				}
				case RoiShape.FreeDraw:
				{
					HTuple rows2 = new HTuple(new double[]
					{
						150.0,
						180.0,
						220.0,
						260.0,
						300.0
					});
					HTuple cols2 = new HTuple(new double[]
					{
						150.0,
						210.0,
						250.0,
						220.0,
						180.0
					});
					this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.XLD_CONTOUR, new HTuple[]
					{
						rows2,
						cols2
					});
					break;
				}
				case RoiShape.DrawRegion:
				{
					HObject region;
					HOperatorSet.GenEmptyObj(out region);
					HOperatorSet.DrawRegion(out region, windowControl);
					this._drawnRegion = region;
					this._currentShape = new RoiShape?(shape);
					windowControl.SetColor("green");
					windowControl.SetDraw("margin");
					windowControl.DispObj(this._drawnRegion);
					return;
				}
				}
				bool flag2 = this._currentRoi != null;
				if (flag2)
				{
					windowControl.AttachDrawingObjectToWindow(this._currentRoi);
					this._currentShape = new RoiShape?(shape);
					bool flag3 = shape == RoiShape.Line;
					if (flag3)
					{
						this.AttachLineLengthLabel(windowControl);
					}
				}
			}
		}

		// Token: 0x06002376 RID: 9078 RVA: 0x000D5CC8 File Offset: 0x000D3EC8
		public void LoadRoi(RoiData roiData, HWindow windowControl)
		{
			bool flag = roiData == null || windowControl == null;
			if (!flag)
			{
				this.Clear(windowControl);
				bool flag2 = roiData.RoiType == RoiType.CustomPaint;
				if (!flag2)
				{
					switch (roiData.RoiType)
					{
					case RoiType.Rectangle1:
						this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.RECTANGLE1, new HTuple[]
						{
							roiData.Row1,
							roiData.Col1,
							roiData.Row2,
							roiData.Col2
						});
						this._currentShape = new RoiShape?(RoiShape.Rectangle);
						break;
					case RoiType.Rectangle2:
						this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.RECTANGLE2, new HTuple[]
						{
							roiData.CenterRow,
							roiData.CenterCol,
							roiData.Phi,
							roiData.Radius1,
							roiData.Radius2
						});
						this._currentShape = new RoiShape?(RoiShape.Rectangle2);
						break;
					case RoiType.Circle:
						this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.CIRCLE, new HTuple[]
						{
							roiData.CenterRow,
							roiData.CenterCol,
							roiData.Radius
						});
						this._currentShape = new RoiShape?(RoiShape.Circle);
						break;
					case RoiType.Ellipse:
						this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.ELLIPSE, new HTuple[]
						{
							roiData.CenterRow,
							roiData.CenterCol,
							roiData.Phi,
							roiData.Radius1,
							roiData.Radius2
						});
						this._currentShape = new RoiShape?(RoiShape.Ellipse);
						break;
					case RoiType.Line:
						this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.LINE, new HTuple[]
						{
							roiData.Row1,
							roiData.Col1,
							roiData.Row2,
							roiData.Col2
						});
						this._currentShape = new RoiShape?(RoiShape.Line);
						break;
					case RoiType.Polygon:
					{
						bool flag3 = roiData.Rows != null && roiData.Cols != null && roiData.Rows.Count >= 3 && roiData.Rows.Count == roiData.Cols.Count;
						if (flag3)
						{
							this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.XLD_CONTOUR, new HTuple[]
							{
								new HTuple(roiData.Rows.ToArray()),
								new HTuple(roiData.Cols.ToArray())
							});
							this._currentShape = new RoiShape?(RoiShape.Polygon);
						}
						break;
					}
					case RoiType.FreeDraw:
					{
						bool flag4 = roiData.Rows != null && roiData.Cols != null && roiData.Rows.Count >= 2 && roiData.Rows.Count == roiData.Cols.Count;
						if (flag4)
						{
							this._currentRoi = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.XLD_CONTOUR, new HTuple[]
							{
								new HTuple(roiData.Rows.ToArray()),
								new HTuple(roiData.Cols.ToArray())
							});
							this._currentShape = new RoiShape?(RoiShape.FreeDraw);
						}
						break;
					}
					case RoiType.DrawRegion:
						this._currentShape = new RoiShape?(RoiShape.DrawRegion);
						break;
					}
					bool flag5 = this._currentRoi != null;
					if (flag5)
					{
						windowControl.AttachDrawingObjectToWindow(this._currentRoi);
						bool flag6 = roiData.RoiType == RoiType.Line;
						if (flag6)
						{
							this.AttachLineLengthLabel(windowControl);
						}
					}
				}
			}
		}

		// Token: 0x06002377 RID: 9079 RVA: 0x000D6064 File Offset: 0x000D4264
		private void AttachLineLengthLabel(HWindow windowControl)
		{
			bool flag = windowControl == null || this._currentRoi == null;
			if (!flag)
			{
				try
				{
					double row;
					double column;
					string text;
					RoiController.GetLineLabelPlacement(this._currentRoi, out row, out column, out text);
					this._lineLengthLabel = HDrawingObject.CreateDrawingObject(HDrawingObject.HDrawingObjectType.TEXT, new HTuple[]
					{
						(int)Math.Round(row),
						(int)Math.Round(column),
						text
					});
					this._lineLengthLabel.SetDrawingObjectParams(new HTuple("color"), new HTuple("green"));
					windowControl.AttachDrawingObjectToWindow(this._lineLengthLabel);
					this._currentRoi.OnDrag(new HDrawingObject.HDrawingObjectCallbackClass(this.LineChanged));
					this._currentRoi.OnResize(new HDrawingObject.HDrawingObjectCallbackClass(this.LineChanged));
				}
				catch (HOperatorException)
				{
					this._lineLengthLabel = null;
				}
			}
		}

		// Token: 0x06002378 RID: 9080 RVA: 0x000D6154 File Offset: 0x000D4354
		private void LineChanged(HDrawingObject drawId, HWindow window, string type)
		{
			bool flag = this._lineLengthLabel == null || drawId == null;
			if (!flag)
			{
				try
				{
					double row;
					double column;
					string text;
					RoiController.GetLineLabelPlacement(drawId, out row, out column, out text);
					HTuple names = new HTuple(new string[]
					{
						"row",
						"column",
						"string"
					});
					HTuple values = new HTuple((int)Math.Round(row)).TupleConcat((int)Math.Round(column)).TupleConcat(text);
					this._lineLengthLabel.SetDrawingObjectParams(names, values);
				}
				catch (HOperatorException)
				{
				}
			}
		}

		// Token: 0x06002379 RID: 9081 RVA: 0x000D6200 File Offset: 0x000D4400
		private static void GetLineLabelPlacement(HDrawingObject line, out double row, out double column, out string text)
		{
			double row2 = line.GetDrawingObjectParams("row1").D;
			double column2 = line.GetDrawingObjectParams("column1").D;
			double row3 = line.GetDrawingObjectParams("row2").D;
			double column3 = line.GetDrawingObjectParams("column2").D;
			double deltaRow = row3 - row2;
			double deltaColumn = column3 - column2;
			text = "L=" + Math.Sqrt(deltaRow * deltaRow + deltaColumn * deltaColumn).ToString("0.0");
			row = Math.Max(0.0, (row2 + row3) / 2.0 - 16.0);
			column = Math.Max(0.0, (column2 + column3) / 2.0);
		}

		// Token: 0x0600237A RID: 9082 RVA: 0x000D62CC File Offset: 0x000D44CC
		public bool HitTest(double row, double col, double tolerance)
		{
			bool flag = this._currentRoi == null || this._currentShape == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				RoiData roi;
				try
				{
					roi = this.GetRoiData();
				}
				catch
				{
					return false;
				}
				bool flag2 = roi == null;
				if (flag2)
				{
					result = false;
				}
				else
				{
					double tol = Math.Max(0.0, tolerance);
					switch (roi.RoiType)
					{
					case RoiType.Rectangle1:
						result = (row >= Math.Min(roi.Row1, roi.Row2) - tol && row <= Math.Max(roi.Row1, roi.Row2) + tol && col >= Math.Min(roi.Col1, roi.Col2) - tol && col <= Math.Max(roi.Col1, roi.Col2) + tol);
						break;
					case RoiType.Rectangle2:
					{
						double dc = col - roi.CenterCol;
						double dr = row - roi.CenterRow;
						double cos = Math.Cos(roi.Phi);
						double sin = Math.Sin(roi.Phi);
						double u = dc * cos - dr * sin;
						double v = dc * sin + dr * cos;
						result = (Math.Abs(u) <= roi.Radius1 + tol && Math.Abs(v) <= roi.Radius2 + tol);
						break;
					}
					case RoiType.Circle:
					{
						double dc2 = col - roi.CenterCol;
						double dr2 = row - roi.CenterRow;
						result = (Math.Sqrt(dc2 * dc2 + dr2 * dr2) <= roi.Radius + tol);
						break;
					}
					case RoiType.Ellipse:
					{
						double dc3 = col - roi.CenterCol;
						double dr3 = row - roi.CenterRow;
						double cos2 = Math.Cos(roi.Phi);
						double sin2 = Math.Sin(roi.Phi);
						double u2 = dc3 * cos2 - dr3 * sin2;
						double v2 = dc3 * sin2 + dr3 * cos2;
						double r = roi.Radius1 + tol;
						double r2 = roi.Radius2 + tol;
						bool flag3 = r <= 0.0 || r2 <= 0.0;
						result = (!flag3 && u2 * u2 / (r * r) + v2 * v2 / (r2 * r2) <= 1.0);
						break;
					}
					case RoiType.Line:
						result = (RoiController.DistanceToSegment(row, col, roi.Row1, roi.Col1, roi.Row2, roi.Col2) <= tol);
						break;
					case RoiType.Polygon:
					case RoiType.FreeDraw:
					{
						List<double> rows = roi.Rows;
						List<double> cols = roi.Cols;
						bool flag4 = rows == null || cols == null || rows.Count < 2;
						if (flag4)
						{
							result = false;
						}
						else
						{
							bool flag5 = RoiController.IsInsidePolygon(row, col, rows, cols);
							if (flag5)
							{
								result = true;
							}
							else
							{
								for (int i = 0; i < rows.Count; i++)
								{
									int j = (i + 1) % rows.Count;
									bool flag6 = RoiController.DistanceToSegment(row, col, rows[i], cols[i], rows[j], cols[j]) <= tol;
									if (flag6)
									{
										return true;
									}
								}
								result = false;
							}
						}
						break;
					}
					default:
						result = false;
						break;
					}
				}
			}
			return result;
		}

		// Token: 0x0600237B RID: 9083 RVA: 0x000D6628 File Offset: 0x000D4828
		private static double DistanceToSegment(double row, double col, double row1, double col1, double row2, double col2)
		{
			double dr = row2 - row1;
			double dc = col2 - col1;
			double lengthSquared = dr * dr + dc * dc;
			bool flag = lengthSquared <= double.Epsilon;
			double result;
			if (flag)
			{
				double pr = row - row1;
				double pc = col - col1;
				result = Math.Sqrt(pr * pr + pc * pc);
			}
			else
			{
				double t = ((row - row1) * dr + (col - col1) * dc) / lengthSquared;
				t = Math.Max(0.0, Math.Min(1.0, t));
				double projRow = row1 + t * dr;
				double projCol = col1 + t * dc;
				double er = row - projRow;
				double ec = col - projCol;
				result = Math.Sqrt(er * er + ec * ec);
			}
			return result;
		}

		// Token: 0x0600237C RID: 9084 RVA: 0x000D66D8 File Offset: 0x000D48D8
		private static bool IsInsidePolygon(double row, double col, IList<double> rows, IList<double> cols)
		{
			bool inside = false;
			int count = Math.Min(rows.Count, cols.Count);
			int i = 0;
			int j = count - 1;
			while (i < count)
			{
				bool flag = rows[i] > row != rows[j] > row && col < (cols[j] - cols[i]) * (row - rows[i]) / (rows[j] - rows[i]) + cols[i];
				if (flag)
				{
					inside = !inside;
				}
				j = i++;
			}
			return inside;
		}

		// Token: 0x0600237D RID: 9085 RVA: 0x000D6778 File Offset: 0x000D4978
		public RoiData GetRoiData()
		{
			bool flag = this._currentShape == null;
			RoiData result;
			if (flag)
			{
				result = null;
			}
			else
			{
				switch (this._currentShape.Value)
				{
				case RoiShape.Rectangle:
				{
					bool flag2 = this._currentRoi == null;
					if (flag2)
					{
						result = null;
					}
					else
					{
						result = this.GetRectangleData();
					}
					break;
				}
				case RoiShape.Rectangle2:
				{
					bool flag3 = this._currentRoi == null;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = this.GetRectangle2Data();
					}
					break;
				}
				case RoiShape.Circle:
				{
					bool flag4 = this._currentRoi == null;
					if (flag4)
					{
						result = null;
					}
					else
					{
						result = this.GetCircleData();
					}
					break;
				}
				case RoiShape.Ellipse:
				{
					bool flag5 = this._currentRoi == null;
					if (flag5)
					{
						result = null;
					}
					else
					{
						result = this.GetEllipseData();
					}
					break;
				}
				case RoiShape.Line:
				{
					bool flag6 = this._currentRoi == null;
					if (flag6)
					{
						result = null;
					}
					else
					{
						result = this.GetLineData();
					}
					break;
				}
				case RoiShape.Polygon:
				{
					bool flag7 = this._currentRoi == null;
					if (flag7)
					{
						result = null;
					}
					else
					{
						result = this.GetXldContourData(RoiType.Polygon);
					}
					break;
				}
				case RoiShape.FreeDraw:
				{
					bool flag8 = this._currentRoi == null;
					if (flag8)
					{
						result = null;
					}
					else
					{
						result = this.GetXldContourData(RoiType.FreeDraw);
					}
					break;
				}
				case RoiShape.DrawRegion:
					result = new RoiData
					{
						RoiType = RoiType.DrawRegion
					};
					break;
				default:
					result = null;
					break;
				}
			}
			return result;
		}

		// Token: 0x0600237E RID: 9086 RVA: 0x000D68C8 File Offset: 0x000D4AC8
		private RoiData GetRectangle2Data()
		{
			return new RoiData
			{
				RoiType = RoiType.Rectangle2,
				CenterRow = this.GetDoubleParam("row"),
				CenterCol = this.GetDoubleParam("column"),
				Phi = this.GetDoubleParam("phi"),
				Radius1 = this.GetDoubleParam("length1"),
				Radius2 = this.GetDoubleParam("length2")
			};
		}

		// Token: 0x0600237F RID: 9087 RVA: 0x000D6944 File Offset: 0x000D4B44
		public HObject GetDrawnRegion()
		{
			return this._drawnRegion;
		}

		// Token: 0x06002380 RID: 9088 RVA: 0x000D695C File Offset: 0x000D4B5C
		private double GetDoubleParam(string name)
		{
			bool flag = this._currentRoi == null;
			double result;
			if (flag)
			{
				result = 0.0;
			}
			else
			{
				HTuple value = this._currentRoi.GetDrawingObjectParams(name);
				result = value.D;
			}
			return result;
		}

		// Token: 0x06002381 RID: 9089 RVA: 0x000D699C File Offset: 0x000D4B9C
		private RoiData GetRectangleData()
		{
			return new RoiData
			{
				RoiType = RoiType.Rectangle1,
				Row1 = this.GetDoubleParam("row1"),
				Col1 = this.GetDoubleParam("column1"),
				Row2 = this.GetDoubleParam("row2"),
				Col2 = this.GetDoubleParam("column2")
			};
		}

		// Token: 0x06002382 RID: 9090 RVA: 0x000D6A04 File Offset: 0x000D4C04
		private RoiData GetCircleData()
		{
			return new RoiData
			{
				RoiType = RoiType.Circle,
				CenterRow = this.GetDoubleParam("row"),
				CenterCol = this.GetDoubleParam("column"),
				Radius = this.GetDoubleParam("radius")
			};
		}

		// Token: 0x06002383 RID: 9091 RVA: 0x000D6A5C File Offset: 0x000D4C5C
		private RoiData GetEllipseData()
		{
			return new RoiData
			{
				RoiType = RoiType.Ellipse,
				CenterRow = this.GetDoubleParam("row"),
				CenterCol = this.GetDoubleParam("column"),
				Phi = this.GetDoubleParam("phi"),
				Radius1 = this.GetDoubleParam("radius1"),
				Radius2 = this.GetDoubleParam("radius2")
			};
		}

		// Token: 0x06002384 RID: 9092 RVA: 0x000D6AD8 File Offset: 0x000D4CD8
		private RoiData GetLineData()
		{
			return new RoiData
			{
				RoiType = RoiType.Line,
				Row1 = this.GetDoubleParam("row1"),
				Col1 = this.GetDoubleParam("column1"),
				Row2 = this.GetDoubleParam("row2"),
				Col2 = this.GetDoubleParam("column2")
			};
		}

		// Token: 0x06002385 RID: 9093 RVA: 0x000D6B40 File Offset: 0x000D4D40
		private RoiData GetXldContourData(RoiType roiType)
		{
			bool flag = this._currentRoi == null;
			RoiData result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HTuple rows = this._currentRoi.GetDrawingObjectParams("row");
				HTuple cols = this._currentRoi.GetDrawingObjectParams("column");
				RoiData roiData = new RoiData
				{
					RoiType = roiType,
					Rows = new List<double>(),
					Cols = new List<double>()
				};
				for (int i = 0; i < rows.Length; i++)
				{
					roiData.Rows.Add(rows[i].D);
					roiData.Cols.Add(cols[i].D);
				}
				result = roiData;
			}
			return result;
		}

		// Token: 0x04000EBC RID: 3772
		private HDrawingObject _currentRoi;

		// Token: 0x04000EBD RID: 3773
		private RoiShape? _currentShape;

		// Token: 0x04000EBE RID: 3774
		private HObject _drawnRegion;

		// Token: 0x04000EBF RID: 3775
		private HDrawingObject _lineLengthLabel;

		// Token: 0x04000EC0 RID: 3776
		private const double LineLabelGap = 16.0;

		// Token: 0x04000EC1 RID: 3777
		private bool _interactionSuspended;

		// Token: 0x04000EC2 RID: 3778
		private const double ClosedContourTolerance = 0.5;
	}
}
