﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000283 RID: 643
	public class RoiData : INotifyPropertyChanged
	{
		// Token: 0x17000A33 RID: 2611
		// (get) Token: 0x0600239A RID: 9114 RVA: 0x000D6F75 File Offset: 0x000D5175
		// (set) Token: 0x0600239B RID: 9115 RVA: 0x000D6F80 File Offset: 0x000D5180
		public RoiType RoiType
		{
			get
			{
				return this._roiType;
			}
			set
			{
				bool flag = this._roiType != value;
				if (flag)
				{
					this._roiType = value;
					this.OnPropertyChanged("RoiType");
					this.OnPropertyChanged("DisplayName");
				}
			}
		}

		// Token: 0x17000A34 RID: 2612
		// (get) Token: 0x0600239C RID: 9116 RVA: 0x000D6FBF File Offset: 0x000D51BF
		// (set) Token: 0x0600239D RID: 9117 RVA: 0x000D6FC8 File Offset: 0x000D51C8
		public bool IsSelected
		{
			get
			{
				return this._isSelected;
			}
			set
			{
				bool flag = this._isSelected != value;
				if (flag)
				{
					this._isSelected = value;
					this.OnPropertyChanged("IsSelected");
				}
			}
		}

		// Token: 0x17000A35 RID: 2613
		// (get) Token: 0x0600239E RID: 9118 RVA: 0x000D6FFB File Offset: 0x000D51FB
		// (set) Token: 0x0600239F RID: 9119 RVA: 0x000D7004 File Offset: 0x000D5204
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				bool flag = this._name != value;
				if (flag)
				{
					this._name = value;
					this.OnPropertyChanged("Name");
					this.OnPropertyChanged("DisplayName");
				}
			}
		}

		// Token: 0x17000A36 RID: 2614
		// (get) Token: 0x060023A0 RID: 9120 RVA: 0x000D7043 File Offset: 0x000D5243
		// (set) Token: 0x060023A1 RID: 9121 RVA: 0x000D704C File Offset: 0x000D524C
		public RoiMaskMode MaskMode
		{
			get
			{
				return this._maskMode;
			}
			set
			{
				bool flag = this._maskMode != value;
				if (flag)
				{
					this._maskMode = value;
					this.OnPropertyChanged("MaskMode");
				}
			}
		}

		// Token: 0x17000A37 RID: 2615
		// (get) Token: 0x060023A2 RID: 9122 RVA: 0x000D707F File Offset: 0x000D527F
		// (set) Token: 0x060023A3 RID: 9123 RVA: 0x000D7088 File Offset: 0x000D5288
		public RoiPolarity Polarity
		{
			get
			{
				return this._polarity;
			}
			set
			{
				bool flag = this._polarity != value;
				if (flag)
				{
					this._polarity = value;
					this.OnPropertyChanged("Polarity");
				}
			}
		}

		// Token: 0x17000A38 RID: 2616
		// (get) Token: 0x060023A4 RID: 9124 RVA: 0x000D70BB File Offset: 0x000D52BB
		// (set) Token: 0x060023A5 RID: 9125 RVA: 0x000D70C4 File Offset: 0x000D52C4
		public bool IsEnabled
		{
			get
			{
				return this._isEnabled;
			}
			set
			{
				bool flag = this._isEnabled != value;
				if (flag)
				{
					this._isEnabled = value;
					this.OnPropertyChanged("IsEnabled");
				}
			}
		}

		// Token: 0x17000A39 RID: 2617
		// (get) Token: 0x060023A6 RID: 9126 RVA: 0x000D70F7 File Offset: 0x000D52F7
		// (set) Token: 0x060023A7 RID: 9127 RVA: 0x000D7100 File Offset: 0x000D5300
		public string Description
		{
			get
			{
				return this._description;
			}
			set
			{
				bool flag = this._description != value;
				if (flag)
				{
					this._description = value;
					this.OnPropertyChanged("Description");
				}
			}
		}

		// Token: 0x17000A3A RID: 2618
		// (get) Token: 0x060023A8 RID: 9128 RVA: 0x000D7133 File Offset: 0x000D5333
		// (set) Token: 0x060023A9 RID: 9129 RVA: 0x000D713C File Offset: 0x000D533C
		public string MasterToolName
		{
			get
			{
				return this._masterToolName;
			}
			set
			{
				bool flag = this._masterToolName != value;
				if (flag)
				{
					this._masterToolName = value;
					bool flag2 = !string.IsNullOrWhiteSpace(value) && value != "None";
					if (flag2)
					{
						bool flag3 = string.IsNullOrWhiteSpace(this._masterPositionToolName);
						if (flag3)
						{
							this.MasterPositionToolName = value;
						}
						bool flag4 = string.IsNullOrWhiteSpace(this._masterAngleToolName);
						if (flag4)
						{
							this.MasterAngleToolName = value;
						}
					}
					this.OnPropertyChanged("MasterToolName");
				}
			}
		}

		// Token: 0x17000A3B RID: 2619
		// (get) Token: 0x060023AA RID: 9130 RVA: 0x000D71B9 File Offset: 0x000D53B9
		// (set) Token: 0x060023AB RID: 9131 RVA: 0x000D71C4 File Offset: 0x000D53C4
		public string MasterPositionToolName
		{
			get
			{
				return this._masterPositionToolName;
			}
			set
			{
				bool flag = this._masterPositionToolName != value;
				if (flag)
				{
					this._masterPositionToolName = value;
					this.OnPropertyChanged("MasterPositionToolName");
				}
			}
		}

		// Token: 0x17000A3C RID: 2620
		// (get) Token: 0x060023AC RID: 9132 RVA: 0x000D71F7 File Offset: 0x000D53F7
		// (set) Token: 0x060023AD RID: 9133 RVA: 0x000D7200 File Offset: 0x000D5400
		public string MasterAngleToolName
		{
			get
			{
				return this._masterAngleToolName;
			}
			set
			{
				bool flag = this._masterAngleToolName != value;
				if (flag)
				{
					this._masterAngleToolName = value;
					this.OnPropertyChanged("MasterAngleToolName");
				}
			}
		}

		// Token: 0x17000A3D RID: 2621
		// (get) Token: 0x060023AE RID: 9134 RVA: 0x000D7234 File Offset: 0x000D5434
		public string DisplayName
		{
			get
			{
				bool flag = string.IsNullOrWhiteSpace(this.Name);
				string result;
				if (flag)
				{
					result = this.RoiType.ToString();
				}
				else
				{
					result = string.Format("{0} ({1})", this.Name, this.RoiType);
				}
				return result;
			}
		}

		// Token: 0x17000A3E RID: 2622
		// (get) Token: 0x060023AF RID: 9135 RVA: 0x000D7287 File Offset: 0x000D5487
		// (set) Token: 0x060023B0 RID: 9136 RVA: 0x000D728F File Offset: 0x000D548F
		public ObservableCollection<RoiExtraProperty> ExtraProperties { get; set; } = new ObservableCollection<RoiExtraProperty>();

		// Token: 0x17000A3F RID: 2623
		// (get) Token: 0x060023B1 RID: 9137 RVA: 0x000D7298 File Offset: 0x000D5498
		// (set) Token: 0x060023B2 RID: 9138 RVA: 0x000D72A0 File Offset: 0x000D54A0
		public double Row1 { get; set; }

		// Token: 0x17000A40 RID: 2624
		// (get) Token: 0x060023B3 RID: 9139 RVA: 0x000D72A9 File Offset: 0x000D54A9
		// (set) Token: 0x060023B4 RID: 9140 RVA: 0x000D72B1 File Offset: 0x000D54B1
		public double Col1 { get; set; }

		// Token: 0x17000A41 RID: 2625
		// (get) Token: 0x060023B5 RID: 9141 RVA: 0x000D72BA File Offset: 0x000D54BA
		// (set) Token: 0x060023B6 RID: 9142 RVA: 0x000D72C2 File Offset: 0x000D54C2
		public double Row2 { get; set; }

		// Token: 0x17000A42 RID: 2626
		// (get) Token: 0x060023B7 RID: 9143 RVA: 0x000D72CB File Offset: 0x000D54CB
		// (set) Token: 0x060023B8 RID: 9144 RVA: 0x000D72D3 File Offset: 0x000D54D3
		public double Col2 { get; set; }

		// Token: 0x17000A43 RID: 2627
		// (get) Token: 0x060023B9 RID: 9145 RVA: 0x000D72DC File Offset: 0x000D54DC
		// (set) Token: 0x060023BA RID: 9146 RVA: 0x000D72E4 File Offset: 0x000D54E4
		public double CenterRow { get; set; }

		// Token: 0x17000A44 RID: 2628
		// (get) Token: 0x060023BB RID: 9147 RVA: 0x000D72ED File Offset: 0x000D54ED
		// (set) Token: 0x060023BC RID: 9148 RVA: 0x000D72F5 File Offset: 0x000D54F5
		public double CenterCol { get; set; }

		// Token: 0x17000A45 RID: 2629
		// (get) Token: 0x060023BD RID: 9149 RVA: 0x000D72FE File Offset: 0x000D54FE
		// (set) Token: 0x060023BE RID: 9150 RVA: 0x000D7306 File Offset: 0x000D5506
		public double Radius { get; set; }

		// Token: 0x17000A46 RID: 2630
		// (get) Token: 0x060023BF RID: 9151 RVA: 0x000D730F File Offset: 0x000D550F
		// (set) Token: 0x060023C0 RID: 9152 RVA: 0x000D7317 File Offset: 0x000D5517
		public double Phi { get; set; }

		// Token: 0x17000A47 RID: 2631
		// (get) Token: 0x060023C1 RID: 9153 RVA: 0x000D7320 File Offset: 0x000D5520
		// (set) Token: 0x060023C2 RID: 9154 RVA: 0x000D7328 File Offset: 0x000D5528
		public double Radius1 { get; set; }

		// Token: 0x17000A48 RID: 2632
		// (get) Token: 0x060023C3 RID: 9155 RVA: 0x000D7331 File Offset: 0x000D5531
		// (set) Token: 0x060023C4 RID: 9156 RVA: 0x000D7339 File Offset: 0x000D5539
		public double Radius2 { get; set; }

		// Token: 0x17000A49 RID: 2633
		// (get) Token: 0x060023C5 RID: 9157 RVA: 0x000D7342 File Offset: 0x000D5542
		// (set) Token: 0x060023C6 RID: 9158 RVA: 0x000D734A File Offset: 0x000D554A
		public List<double> Rows { get; set; } = new List<double>();

		// Token: 0x17000A4A RID: 2634
		// (get) Token: 0x060023C7 RID: 9159 RVA: 0x000D7353 File Offset: 0x000D5553
		// (set) Token: 0x060023C8 RID: 9160 RVA: 0x000D735B File Offset: 0x000D555B
		public List<double> Cols { get; set; } = new List<double>();

		// Token: 0x17000A4B RID: 2635
		// (get) Token: 0x060023C9 RID: 9161 RVA: 0x000D7364 File Offset: 0x000D5564
		// (set) Token: 0x060023CA RID: 9162 RVA: 0x000D736C File Offset: 0x000D556C
		public string CustomRegionFile { get; set; }

		// Token: 0x17000A4C RID: 2636
		// (get) Token: 0x060023CB RID: 9163 RVA: 0x000D7378 File Offset: 0x000D5578
		// (set) Token: 0x060023CC RID: 9164 RVA: 0x000D73A8 File Offset: 0x000D55A8
		public RoiCloneSettings CloneSettings
		{
			get
			{
				bool flag = this._cloneSettings == null;
				if (flag)
				{
					this._cloneSettings = new RoiCloneSettings();
				}
				return this._cloneSettings;
			}
			set
			{
				this._cloneSettings = value;
				this.OnPropertyChanged("CloneSettings");
			}
		}

		// Token: 0x060023CD RID: 9165 RVA: 0x000D73C0 File Offset: 0x000D55C0
		public void Refresh()
		{
			this.OnPropertyChanged("RoiType");
			this.OnPropertyChanged("IsSelected");
			this.OnPropertyChanged("Name");
			this.OnPropertyChanged("DisplayName");
			this.OnPropertyChanged("MaskMode");
			this.OnPropertyChanged("Polarity");
			this.OnPropertyChanged("IsEnabled");
			this.OnPropertyChanged("Description");
			this.OnPropertyChanged("MasterToolName");
			this.OnPropertyChanged("MasterPositionToolName");
			this.OnPropertyChanged("MasterAngleToolName");
			this.OnPropertyChanged("Row1");
			this.OnPropertyChanged("Col1");
			this.OnPropertyChanged("Row2");
			this.OnPropertyChanged("Col2");
			this.OnPropertyChanged("CenterRow");
			this.OnPropertyChanged("CenterCol");
			this.OnPropertyChanged("Radius");
			this.OnPropertyChanged("Phi");
			this.OnPropertyChanged("Radius1");
			this.OnPropertyChanged("Radius2");
			this.OnPropertyChanged("Rows");
			this.OnPropertyChanged("Cols");
			this.OnPropertyChanged("ExtraProperties");
		}

		// Token: 0x14000042 RID: 66
		// (add) Token: 0x060023CE RID: 9166 RVA: 0x000D74F0 File Offset: 0x000D56F0
		// (remove) Token: 0x060023CF RID: 9167 RVA: 0x000D7528 File Offset: 0x000D5728
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060023D0 RID: 9168 RVA: 0x000D7560 File Offset: 0x000D5760
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler handler = this.PropertyChanged;
			bool flag = handler != null;
			if (flag)
			{
				handler(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000ECF RID: 3791
		private RoiType _roiType;

		// Token: 0x04000ED0 RID: 3792
		private bool _isSelected;

		// Token: 0x04000ED1 RID: 3793
		private string _name;

		// Token: 0x04000ED2 RID: 3794
		private RoiMaskMode _maskMode;

		// Token: 0x04000ED3 RID: 3795
		private RoiPolarity _polarity = RoiPolarity.Negative;

		// Token: 0x04000ED4 RID: 3796
		private bool _isEnabled = true;

		// Token: 0x04000ED5 RID: 3797
		private string _description;

		// Token: 0x04000ED6 RID: 3798
		private string _masterToolName = "None";

		// Token: 0x04000ED7 RID: 3799
		private string _masterPositionToolName;

		// Token: 0x04000ED8 RID: 3800
		private string _masterAngleToolName;

		// Token: 0x04000EE7 RID: 3815
		private RoiCloneSettings _cloneSettings;
	}
}
