﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000284 RID: 644
	public class RoiExtraProperty : INotifyPropertyChanged
	{
		// Token: 0x17000A4D RID: 2637
		// (get) Token: 0x060023D2 RID: 9170 RVA: 0x000D75DA File Offset: 0x000D57DA
		// (set) Token: 0x060023D3 RID: 9171 RVA: 0x000D75E4 File Offset: 0x000D57E4
		public string Key
		{
			get
			{
				return this._key;
			}
			set
			{
				bool flag = this._key != value;
				if (flag)
				{
					this._key = value;
					this.OnPropertyChanged("Key");
				}
			}
		}

		// Token: 0x17000A4E RID: 2638
		// (get) Token: 0x060023D4 RID: 9172 RVA: 0x000D7617 File Offset: 0x000D5817
		// (set) Token: 0x060023D5 RID: 9173 RVA: 0x000D7620 File Offset: 0x000D5820
		public string Value
		{
			get
			{
				return this._value;
			}
			set
			{
				bool flag = this._value != value;
				if (flag)
				{
					this._value = value;
					this.OnPropertyChanged("Value");
				}
			}
		}

		// Token: 0x14000043 RID: 67
		// (add) Token: 0x060023D6 RID: 9174 RVA: 0x000D7654 File Offset: 0x000D5854
		// (remove) Token: 0x060023D7 RID: 9175 RVA: 0x000D768C File Offset: 0x000D588C
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060023D8 RID: 9176 RVA: 0x000D76C1 File Offset: 0x000D58C1
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000EE9 RID: 3817
		private string _key;

		// Token: 0x04000EEA RID: 3818
		private string _value;
	}
}
