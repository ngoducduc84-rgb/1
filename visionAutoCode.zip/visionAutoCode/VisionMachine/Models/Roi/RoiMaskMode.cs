﻿using System;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000285 RID: 645
	public enum RoiMaskMode
	{
		// Token: 0x04000EED RID: 3821
		Inside,
		// Token: 0x04000EEE RID: 3822
		Outside
	}
}
