﻿using System;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000286 RID: 646
	public enum RoiPolarity
	{
		// Token: 0x04000EF0 RID: 3824
		Positive,
		// Token: 0x04000EF1 RID: 3825
		Negative
	}
}
