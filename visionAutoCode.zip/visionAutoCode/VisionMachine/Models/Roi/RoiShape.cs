﻿using System;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000287 RID: 647
	public enum RoiShape
	{
		// Token: 0x04000EF3 RID: 3827
		Rectangle,
		// Token: 0x04000EF4 RID: 3828
		Rectangle2,
		// Token: 0x04000EF5 RID: 3829
		Circle,
		// Token: 0x04000EF6 RID: 3830
		Ellipse,
		// Token: 0x04000EF7 RID: 3831
		Line,
		// Token: 0x04000EF8 RID: 3832
		Polygon,
		// Token: 0x04000EF9 RID: 3833
		FreeDraw,
		// Token: 0x04000EFA RID: 3834
		DrawRegion
	}
}
