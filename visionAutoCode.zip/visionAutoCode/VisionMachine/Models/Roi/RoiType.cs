﻿using System;

namespace VisionMachine.Models.Roi
{
	// Token: 0x02000288 RID: 648
	public enum RoiType
	{
		// Token: 0x04000EFC RID: 3836
		None,
		// Token: 0x04000EFD RID: 3837
		Rectangle1,
		// Token: 0x04000EFE RID: 3838
		Rectangle2,
		// Token: 0x04000EFF RID: 3839
		Circle,
		// Token: 0x04000F00 RID: 3840
		Ellipse,
		// Token: 0x04000F01 RID: 3841
		Line,
		// Token: 0x04000F02 RID: 3842
		Polygon,
		// Token: 0x04000F03 RID: 3843
		FreeDraw,
		// Token: 0x04000F04 RID: 3844
		DrawRegion,
		// Token: 0x04000F05 RID: 3845
		CustomPaint
	}
}
