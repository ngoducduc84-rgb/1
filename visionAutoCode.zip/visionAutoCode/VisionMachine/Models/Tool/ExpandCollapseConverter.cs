﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VisionMachine.Models.Tool
{
	// Token: 0x02000275 RID: 629
	public class ExpandCollapseConverter : IValueConverter
	{
		// Token: 0x060022DE RID: 8926 RVA: 0x000D4A98 File Offset: 0x000D2C98
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			bool b;
			bool flag;
			if (value is bool)
			{
				b = (bool)value;
				flag = true;
			}
			else
			{
				flag = false;
			}
			return (flag && b) ? "▼" : "▶";
		}

		// Token: 0x060022DF RID: 8927 RVA: 0x000D4AD0 File Offset: 0x000D2CD0
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return null;
		}
	}
}
