﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Tool
{
	// Token: 0x02000276 RID: 630
	public abstract class ToolConfigBase : INotifyPropertyChanged
	{
		// Token: 0x170009F0 RID: 2544
		// (get) Token: 0x060022E1 RID: 8929 RVA: 0x000D4AE3 File Offset: 0x000D2CE3
		// (set) Token: 0x060022E2 RID: 8930 RVA: 0x000D4AEC File Offset: 0x000D2CEC
		public bool IsEnabled
		{
			get
			{
				return this._isEnabled;
			}
			set
			{
				bool flag = this._isEnabled != value;
				if (flag)
				{
					this._isEnabled = value;
					this.OnPropertyChanged("IsEnabled");
				}
			}
		}

		// Token: 0x1400003C RID: 60
		// (add) Token: 0x060022E3 RID: 8931 RVA: 0x000D4B20 File Offset: 0x000D2D20
		// (remove) Token: 0x060022E4 RID: 8932 RVA: 0x000D4B58 File Offset: 0x000D2D58
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060022E5 RID: 8933 RVA: 0x000D4B8D File Offset: 0x000D2D8D
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000E56 RID: 3670
		private bool _isEnabled = true;
	}
}
