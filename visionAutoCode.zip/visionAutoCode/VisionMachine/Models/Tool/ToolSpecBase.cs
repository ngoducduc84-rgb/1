﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Tool
{
	// Token: 0x02000277 RID: 631
	public abstract class ToolSpecBase : INotifyPropertyChanged
	{
		// Token: 0x170009F1 RID: 2545
		// (get) Token: 0x060022E7 RID: 8935 RVA: 0x000D4BB9 File Offset: 0x000D2DB9
		// (set) Token: 0x060022E8 RID: 8936 RVA: 0x000D4BC4 File Offset: 0x000D2DC4
		public bool IsEnabled
		{
			get
			{
				return this._isEnabled;
			}
			set
			{
				bool flag = this._isEnabled != value;
				if (flag)
				{
					this._isEnabled = value;
					this.OnPropertyChanged("IsEnabled");
				}
			}
		}

		// Token: 0x1400003D RID: 61
		// (add) Token: 0x060022E9 RID: 8937 RVA: 0x000D4BF8 File Offset: 0x000D2DF8
		// (remove) Token: 0x060022EA RID: 8938 RVA: 0x000D4C30 File Offset: 0x000D2E30
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060022EB RID: 8939 RVA: 0x000D4C65 File Offset: 0x000D2E65
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000E58 RID: 3672
		private bool _isEnabled = true;
	}
}
