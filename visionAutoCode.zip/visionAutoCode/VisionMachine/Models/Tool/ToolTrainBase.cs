﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Models.Tool
{
	// Token: 0x02000278 RID: 632
	public abstract class ToolTrainBase : INotifyPropertyChanged
	{
		// Token: 0x170009F2 RID: 2546
		// (get) Token: 0x060022ED RID: 8941 RVA: 0x000D4C91 File Offset: 0x000D2E91
		// (set) Token: 0x060022EE RID: 8942 RVA: 0x000D4C9C File Offset: 0x000D2E9C
		public bool IsEnabled
		{
			get
			{
				return this._isEnabled;
			}
			set
			{
				bool flag = this._isEnabled != value;
				if (flag)
				{
					this._isEnabled = value;
					this.OnPropertyChanged("IsEnabled");
				}
			}
		}

		// Token: 0x1400003E RID: 62
		// (add) Token: 0x060022EF RID: 8943 RVA: 0x000D4CD0 File Offset: 0x000D2ED0
		// (remove) Token: 0x060022F0 RID: 8944 RVA: 0x000D4D08 File Offset: 0x000D2F08
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060022F1 RID: 8945 RVA: 0x000D4D3D File Offset: 0x000D2F3D
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000E5A RID: 3674
		private bool _isEnabled = true;
	}
}
