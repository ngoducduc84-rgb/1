﻿using System;

namespace VisionMachine.Models.Tool
{
	// Token: 0x02000279 RID: 633
	public enum ToolType
	{
		// Token: 0x04000E5D RID: 3677
		Unknown,
		// Token: 0x04000E5E RID: 3678
		ImageLoader,
		// Token: 0x04000E5F RID: 3679
		Blob,
		// Token: 0x04000E60 RID: 3680
		Histogram,
		// Token: 0x04000E61 RID: 3681
		HistogramColor,
		// Token: 0x04000E62 RID: 3682
		FindCircle,
		// Token: 0x04000E63 RID: 3683
		FindLine,
		// Token: 0x04000E64 RID: 3684
		OCR,
		// Token: 0x04000E65 RID: 3685
		Shape_model,
		// Token: 0x04000E66 RID: 3686
		AnisoShapeModel,
		// Token: 0x04000E67 RID: 3687
		OverlappingShapeModel,
		// Token: 0x04000E68 RID: 3688
		ImageFilter,
		// Token: 0x04000E69 RID: 3689
		ImageTransform,
		// Token: 0x04000E6A RID: 3690
		SaveImage,
		// Token: 0x04000E6B RID: 3691
		MatrixCode,
		// Token: 0x04000E6C RID: 3692
		DistanceObject,
		// Token: 0x04000E6D RID: 3693
		MeasureCircle,
		// Token: 0x04000E6E RID: 3694
		CircleMaster,
		// Token: 0x04000E6F RID: 3695
		BoundingBoxMaster,
		// Token: 0x04000E70 RID: 3696
		MinAreaMaster,
		// Token: 0x04000E71 RID: 3697
		IntersectingLines,
		// Token: 0x04000E72 RID: 3698
		AngleSelector,
		// Token: 0x04000E73 RID: 3699
		FindBoundingBox,
		// Token: 0x04000E74 RID: 3700
		FindMinArea,
		// Token: 0x04000E75 RID: 3701
		CalibHandEye,
		// Token: 0x04000E76 RID: 3702
		ResultAlign,
		// Token: 0x04000E77 RID: 3703
		ResultInspection,
		// Token: 0x04000E78 RID: 3704
		DeformableInspection,
		// Token: 0x04000E79 RID: 3705
		VariationModel,
		// Token: 0x04000E7A RID: 3706
		DLObjectInspection,
		// Token: 0x04000E7B RID: 3707
		VariationChangeWD,
		// Token: 0x04000E7C RID: 3708
		ProductCountInspection,
		// Token: 0x04000E7D RID: 3709
		FindRedArrow,
		// Token: 0x04000E7E RID: 3710
		CountBoundingBox,
		// Token: 0x04000E7F RID: 3711
		ProcedureInspection,
		// Token: 0x04000E80 RID: 3712
		ProcedureModel
	}
}
