﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using HalconDotNet;
using Newtonsoft.Json;
using VisionMachine.Models.Roi;

namespace VisionMachine.Models.Tool
{
	// Token: 0x0200027A RID: 634
	public class ToolVision : INotifyPropertyChanged
	{
		// Token: 0x170009F3 RID: 2547
		// (get) Token: 0x060022F3 RID: 8947 RVA: 0x000D4D69 File Offset: 0x000D2F69
		// (set) Token: 0x060022F4 RID: 8948 RVA: 0x000D4D71 File Offset: 0x000D2F71
		public string ToolId
		{
			get
			{
				return this._toolId;
			}
			set
			{
				this._toolId = value;
				this.OnPropertyChanged("ToolId");
			}
		}

		// Token: 0x170009F4 RID: 2548
		// (get) Token: 0x060022F5 RID: 8949 RVA: 0x000D4D87 File Offset: 0x000D2F87
		// (set) Token: 0x060022F6 RID: 8950 RVA: 0x000D4D90 File Offset: 0x000D2F90
		public ToolSpecBase Spec
		{
			get
			{
				return this._spec;
			}
			set
			{
				bool flag = this._spec != value;
				if (flag)
				{
					this._spec = value;
					this.OnPropertyChanged("Spec");
				}
			}
		}

		// Token: 0x170009F5 RID: 2549
		// (get) Token: 0x060022F7 RID: 8951 RVA: 0x000D4DC3 File Offset: 0x000D2FC3
		// (set) Token: 0x060022F8 RID: 8952 RVA: 0x000D4DCC File Offset: 0x000D2FCC
		public ToolTrainBase TrainModel
		{
			get
			{
				return this._trainModel;
			}
			set
			{
				bool flag = this._trainModel != value;
				if (flag)
				{
					this._trainModel = value;
					this.OnPropertyChanged("TrainModel");
				}
			}
		}

		// Token: 0x170009F6 RID: 2550
		// (get) Token: 0x060022F9 RID: 8953 RVA: 0x000D4DFF File Offset: 0x000D2FFF
		// (set) Token: 0x060022FA RID: 8954 RVA: 0x000D4E08 File Offset: 0x000D3008
		public int Index
		{
			get
			{
				return this._index;
			}
			set
			{
				bool flag = this._index != value;
				if (flag)
				{
					this._index = value;
					this.OnPropertyChanged("Index");
				}
			}
		}

		// Token: 0x170009F7 RID: 2551
		// (get) Token: 0x060022FB RID: 8955 RVA: 0x000D4E3B File Offset: 0x000D303B
		// (set) Token: 0x060022FC RID: 8956 RVA: 0x000D4E44 File Offset: 0x000D3044
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				bool flag = this._name != value;
				if (flag)
				{
					this._name = value;
					this.OnPropertyChanged("Name");
				}
			}
		}

		// Token: 0x170009F8 RID: 2552
		// (get) Token: 0x060022FD RID: 8957 RVA: 0x000D4E77 File Offset: 0x000D3077
		// (set) Token: 0x060022FE RID: 8958 RVA: 0x000D4E80 File Offset: 0x000D3080
		public bool IsSelected
		{
			get
			{
				return this._isSelected;
			}
			set
			{
				bool flag = this._isSelected != value;
				if (flag)
				{
					this._isSelected = value;
					this.OnPropertyChanged("IsSelected");
				}
			}
		}

		// Token: 0x170009F9 RID: 2553
		// (get) Token: 0x060022FF RID: 8959 RVA: 0x000D4EB3 File Offset: 0x000D30B3
		// (set) Token: 0x06002300 RID: 8960 RVA: 0x000D4EBC File Offset: 0x000D30BC
		public ToolType ToolType
		{
			get
			{
				return this._toolType;
			}
			set
			{
				bool flag = this._toolType != value;
				if (flag)
				{
					this._toolType = value;
					this.OnPropertyChanged("ToolType");
				}
			}
		}

		// Token: 0x170009FA RID: 2554
		// (get) Token: 0x06002301 RID: 8961 RVA: 0x000D4EEF File Offset: 0x000D30EF
		// (set) Token: 0x06002302 RID: 8962 RVA: 0x000D4EF8 File Offset: 0x000D30F8
		public ToolConfigBase Config
		{
			get
			{
				return this._config;
			}
			set
			{
				bool flag = this._config != value;
				if (flag)
				{
					bool flag2 = this._config != null;
					if (flag2)
					{
						this._config.PropertyChanged -= this.Config_PropertyChanged;
					}
					this._config = value;
					bool flag3 = this._config != null;
					if (flag3)
					{
						this._config.PropertyChanged += this.Config_PropertyChanged;
					}
					this.OnPropertyChanged("Config");
					this.OnPropertyChanged("IsEnabled");
				}
			}
		}

		// Token: 0x170009FB RID: 2555
		// (get) Token: 0x06002303 RID: 8963 RVA: 0x000D4F84 File Offset: 0x000D3184
		// (set) Token: 0x06002304 RID: 8964 RVA: 0x000D4FAC File Offset: 0x000D31AC
		[JsonIgnore]
		public bool IsEnabled
		{
			get
			{
				return this.Config == null || this.Config.IsEnabled;
			}
			set
			{
				bool flag = this.Config == null || this.Config.IsEnabled == value;
				if (!flag)
				{
					this.Config.IsEnabled = value;
					this.OnPropertyChanged("IsEnabled");
				}
			}
		}

		// Token: 0x06002305 RID: 8965 RVA: 0x000D4FF4 File Offset: 0x000D31F4
		private void Config_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e.PropertyName == "IsEnabled";
			if (flag)
			{
				this.OnPropertyChanged("IsEnabled");
			}
		}

		// Token: 0x170009FC RID: 2556
		// (get) Token: 0x06002306 RID: 8966 RVA: 0x000D5022 File Offset: 0x000D3222
		// (set) Token: 0x06002307 RID: 8967 RVA: 0x000D502A File Offset: 0x000D322A
		public ObservableCollection<ToolVision> Children { get; set; } = new ObservableCollection<ToolVision>();

		// Token: 0x170009FD RID: 2557
		// (get) Token: 0x06002308 RID: 8968 RVA: 0x000D5033 File Offset: 0x000D3233
		// (set) Token: 0x06002309 RID: 8969 RVA: 0x000D503B File Offset: 0x000D323B
		[JsonIgnore]
		public ImageSource Icon { get; set; }

		// Token: 0x170009FE RID: 2558
		// (get) Token: 0x0600230A RID: 8970 RVA: 0x000D5044 File Offset: 0x000D3244
		// (set) Token: 0x0600230B RID: 8971 RVA: 0x000D504C File Offset: 0x000D324C
		[JsonIgnore]
		public TurnSnap ParentTurnSnap { get; set; }

		// Token: 0x170009FF RID: 2559
		// (get) Token: 0x0600230C RID: 8972 RVA: 0x000D5055 File Offset: 0x000D3255
		// (set) Token: 0x0600230D RID: 8973 RVA: 0x000D505D File Offset: 0x000D325D
		public ObservableCollection<RoiData> RoiItems { get; set; } = new ObservableCollection<RoiData>();

		// Token: 0x17000A00 RID: 2560
		// (get) Token: 0x0600230E RID: 8974 RVA: 0x000D5066 File Offset: 0x000D3266
		// (set) Token: 0x0600230F RID: 8975 RVA: 0x000D506E File Offset: 0x000D326E
		public ObservableCollection<RoiData> LimitRoiItems { get; set; } = new ObservableCollection<RoiData>();

		// Token: 0x17000A01 RID: 2561
		// (get) Token: 0x06002310 RID: 8976 RVA: 0x000D5077 File Offset: 0x000D3277
		// (set) Token: 0x06002311 RID: 8977 RVA: 0x000D507F File Offset: 0x000D327F
		public ObservableCollection<RoiData> MaskRoiItems { get; set; } = new ObservableCollection<RoiData>();

		// Token: 0x17000A02 RID: 2562
		// (get) Token: 0x06002312 RID: 8978 RVA: 0x000D5088 File Offset: 0x000D3288
		// (set) Token: 0x06002313 RID: 8979 RVA: 0x000D5090 File Offset: 0x000D3290
		[JsonIgnore]
		public RoiData SelectedRoi
		{
			get
			{
				return this._selectedRoi;
			}
			set
			{
				bool flag = this._selectedRoi != value;
				if (flag)
				{
					this._selectedRoi = value;
					this.OnPropertyChanged("SelectedRoi");
				}
			}
		}

		// Token: 0x1400003F RID: 63
		// (add) Token: 0x06002314 RID: 8980 RVA: 0x000D50C4 File Offset: 0x000D32C4
		// (remove) Token: 0x06002315 RID: 8981 RVA: 0x000D50FC File Offset: 0x000D32FC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06002316 RID: 8982 RVA: 0x000D5131 File Offset: 0x000D3331
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x17000A03 RID: 2563
		// (get) Token: 0x06002317 RID: 8983 RVA: 0x000D514D File Offset: 0x000D334D
		// (set) Token: 0x06002318 RID: 8984 RVA: 0x000D5155 File Offset: 0x000D3355
		[JsonIgnore]
		public HObject ShapeModelPreviewRegion { get; set; }

		// Token: 0x04000E81 RID: 3713
		private string _toolId = Guid.NewGuid().ToString("N");

		// Token: 0x04000E82 RID: 3714
		private int _index;

		// Token: 0x04000E83 RID: 3715
		private string _name;

		// Token: 0x04000E84 RID: 3716
		private bool _isSelected;

		// Token: 0x04000E85 RID: 3717
		private ToolType _toolType;

		// Token: 0x04000E86 RID: 3718
		private ToolConfigBase _config;

		// Token: 0x04000E87 RID: 3719
		private ToolSpecBase _spec;

		// Token: 0x04000E88 RID: 3720
		private ToolTrainBase _trainModel;

		// Token: 0x04000E8F RID: 3727
		private RoiData _selectedRoi;
	}
}
