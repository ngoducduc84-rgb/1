﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Camera;

namespace VisionMachine.Models.Tool
{
	// Token: 0x0200027B RID: 635
	public class TurnSnap : INotifyPropertyChanged
	{
		// Token: 0x17000A04 RID: 2564
		// (get) Token: 0x0600231A RID: 8986 RVA: 0x000D51B8 File Offset: 0x000D33B8
		// (set) Token: 0x0600231B RID: 8987 RVA: 0x000D51C0 File Offset: 0x000D33C0
		public int Index
		{
			get
			{
				return this._index;
			}
			set
			{
				bool flag = this._index != value;
				if (flag)
				{
					this._index = value;
					this.OnPropertyChanged("Index");
					this.OnPropertyChanged("DisplayName");
				}
			}
		}

		// Token: 0x17000A05 RID: 2565
		// (get) Token: 0x0600231C RID: 8988 RVA: 0x000D51FF File Offset: 0x000D33FF
		// (set) Token: 0x0600231D RID: 8989 RVA: 0x000D5208 File Offset: 0x000D3408
		public bool IsSelected
		{
			get
			{
				return this._isSelected;
			}
			set
			{
				bool flag = this._isSelected != value;
				if (flag)
				{
					this._isSelected = value;
					this.OnPropertyChanged("IsSelected");
				}
			}
		}

		// Token: 0x17000A06 RID: 2566
		// (get) Token: 0x0600231E RID: 8990 RVA: 0x000D523B File Offset: 0x000D343B
		public string DisplayName
		{
			get
			{
				return string.Format("TurnSnap {0}", this.Index);
			}
		}

		// Token: 0x17000A07 RID: 2567
		// (get) Token: 0x0600231F RID: 8991 RVA: 0x000D5252 File Offset: 0x000D3452
		// (set) Token: 0x06002320 RID: 8992 RVA: 0x000D525A File Offset: 0x000D345A
		public CameraNode ParentCamera { get; set; }

		// Token: 0x17000A08 RID: 2568
		// (get) Token: 0x06002321 RID: 8993 RVA: 0x000D5263 File Offset: 0x000D3463
		// (set) Token: 0x06002322 RID: 8994 RVA: 0x000D526B File Offset: 0x000D346B
		public ObservableCollection<ToolVision> Tools { get; set; } = new ObservableCollection<ToolVision>();

		// Token: 0x14000040 RID: 64
		// (add) Token: 0x06002323 RID: 8995 RVA: 0x000D5274 File Offset: 0x000D3474
		// (remove) Token: 0x06002324 RID: 8996 RVA: 0x000D52AC File Offset: 0x000D34AC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06002325 RID: 8997 RVA: 0x000D52E1 File Offset: 0x000D34E1
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x17000A09 RID: 2569
		// (get) Token: 0x06002326 RID: 8998 RVA: 0x000D52FD File Offset: 0x000D34FD
		// (set) Token: 0x06002327 RID: 8999 RVA: 0x000D5305 File Offset: 0x000D3505
		public bool IsToolListExpanded
		{
			get
			{
				return this._isToolListExpanded;
			}
			set
			{
				this._isToolListExpanded = value;
				this.OnPropertyChanged("IsToolListExpanded");
			}
		}

		// Token: 0x04000E92 RID: 3730
		private int _index;

		// Token: 0x04000E93 RID: 3731
		private bool _isSelected;

		// Token: 0x04000E97 RID: 3735
		private bool _isToolListExpanded = true;
	}
}
