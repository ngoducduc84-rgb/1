﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace VisionMachine.Models.Tool
{
	// Token: 0x0200027C RID: 636
	public class TurnSnapMinHeightConverter : IValueConverter
	{
		// Token: 0x06002329 RID: 9001 RVA: 0x000D5338 File Offset: 0x000D3538
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			bool b;
			bool flag;
			if (value is bool)
			{
				b = (bool)value;
				flag = true;
			}
			else
			{
				flag = false;
			}
			return (flag && b) ? 220 : 45;
		}

		// Token: 0x0600232A RID: 9002 RVA: 0x000D5374 File Offset: 0x000D3574
		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return null;
		}
	}
}
