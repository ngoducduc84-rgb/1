﻿using System;

namespace VisionMachine.Models.Tools
{
	// Token: 0x0200027E RID: 638
	public class ShapeMatchCandidate
	{
		// Token: 0x17000A1D RID: 2589
		// (get) Token: 0x06002351 RID: 9041 RVA: 0x000D54FF File Offset: 0x000D36FF
		// (set) Token: 0x06002352 RID: 9042 RVA: 0x000D5507 File Offset: 0x000D3707
		public int Index { get; set; }

		// Token: 0x17000A1E RID: 2590
		// (get) Token: 0x06002353 RID: 9043 RVA: 0x000D5510 File Offset: 0x000D3710
		// (set) Token: 0x06002354 RID: 9044 RVA: 0x000D5518 File Offset: 0x000D3718
		public int Order { get; set; }

		// Token: 0x17000A1F RID: 2591
		// (get) Token: 0x06002355 RID: 9045 RVA: 0x000D5521 File Offset: 0x000D3721
		// (set) Token: 0x06002356 RID: 9046 RVA: 0x000D5529 File Offset: 0x000D3729
		public int GridRow { get; set; }

		// Token: 0x17000A20 RID: 2592
		// (get) Token: 0x06002357 RID: 9047 RVA: 0x000D5532 File Offset: 0x000D3732
		// (set) Token: 0x06002358 RID: 9048 RVA: 0x000D553A File Offset: 0x000D373A
		public int GridColumn { get; set; }

		// Token: 0x17000A21 RID: 2593
		// (get) Token: 0x06002359 RID: 9049 RVA: 0x000D5543 File Offset: 0x000D3743
		// (set) Token: 0x0600235A RID: 9050 RVA: 0x000D554B File Offset: 0x000D374B
		public double Row { get; set; }

		// Token: 0x17000A22 RID: 2594
		// (get) Token: 0x0600235B RID: 9051 RVA: 0x000D5554 File Offset: 0x000D3754
		// (set) Token: 0x0600235C RID: 9052 RVA: 0x000D555C File Offset: 0x000D375C
		public double Column { get; set; }

		// Token: 0x17000A23 RID: 2595
		// (get) Token: 0x0600235D RID: 9053 RVA: 0x000D5565 File Offset: 0x000D3765
		// (set) Token: 0x0600235E RID: 9054 RVA: 0x000D556D File Offset: 0x000D376D
		public double Angle { get; set; }

		// Token: 0x17000A24 RID: 2596
		// (get) Token: 0x0600235F RID: 9055 RVA: 0x000D5576 File Offset: 0x000D3776
		// (set) Token: 0x06002360 RID: 9056 RVA: 0x000D557E File Offset: 0x000D377E
		public double Score { get; set; }

		// Token: 0x17000A25 RID: 2597
		// (get) Token: 0x06002361 RID: 9057 RVA: 0x000D5587 File Offset: 0x000D3787
		// (set) Token: 0x06002362 RID: 9058 RVA: 0x000D558F File Offset: 0x000D378F
		public double ScaleRow { get; set; } = 1.0;

		// Token: 0x17000A26 RID: 2598
		// (get) Token: 0x06002363 RID: 9059 RVA: 0x000D5598 File Offset: 0x000D3798
		// (set) Token: 0x06002364 RID: 9060 RVA: 0x000D55A0 File Offset: 0x000D37A0
		public double ScaleColumn { get; set; } = 1.0;

		// Token: 0x17000A27 RID: 2599
		// (get) Token: 0x06002365 RID: 9061 RVA: 0x000D55A9 File Offset: 0x000D37A9
		// (set) Token: 0x06002366 RID: 9062 RVA: 0x000D55B1 File Offset: 0x000D37B1
		public bool HasDelta { get; set; }

		// Token: 0x17000A28 RID: 2600
		// (get) Token: 0x06002367 RID: 9063 RVA: 0x000D55BA File Offset: 0x000D37BA
		// (set) Token: 0x06002368 RID: 9064 RVA: 0x000D55C2 File Offset: 0x000D37C2
		public double DeltaRow { get; set; }

		// Token: 0x17000A29 RID: 2601
		// (get) Token: 0x06002369 RID: 9065 RVA: 0x000D55CB File Offset: 0x000D37CB
		// (set) Token: 0x0600236A RID: 9066 RVA: 0x000D55D3 File Offset: 0x000D37D3
		public double DeltaColumn { get; set; }

		// Token: 0x17000A2A RID: 2602
		// (get) Token: 0x0600236B RID: 9067 RVA: 0x000D55DC File Offset: 0x000D37DC
		// (set) Token: 0x0600236C RID: 9068 RVA: 0x000D55E4 File Offset: 0x000D37E4
		public double DeltaAngle { get; set; }
	}
}
