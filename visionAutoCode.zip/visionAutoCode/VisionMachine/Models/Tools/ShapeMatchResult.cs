﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Models.Tools
{
	// Token: 0x0200027D RID: 637
	public class ShapeMatchResult
	{
		// Token: 0x17000A0A RID: 2570
		// (get) Token: 0x0600232C RID: 9004 RVA: 0x000D5387 File Offset: 0x000D3587
		// (set) Token: 0x0600232D RID: 9005 RVA: 0x000D538F File Offset: 0x000D358F
		public bool IsSuccess { get; set; }

		// Token: 0x17000A0B RID: 2571
		// (get) Token: 0x0600232E RID: 9006 RVA: 0x000D5398 File Offset: 0x000D3598
		public List<ShapeMatchCandidate> Matches { get; } = new List<ShapeMatchCandidate>();

		// Token: 0x17000A0C RID: 2572
		// (get) Token: 0x0600232F RID: 9007 RVA: 0x000D53A0 File Offset: 0x000D35A0
		public int MatchCount
		{
			get
			{
				return this.Matches.Count;
			}
		}

		// Token: 0x17000A0D RID: 2573
		// (get) Token: 0x06002330 RID: 9008 RVA: 0x000D53BD File Offset: 0x000D35BD
		// (set) Token: 0x06002331 RID: 9009 RVA: 0x000D53C5 File Offset: 0x000D35C5
		public int GridRow { get; set; }

		// Token: 0x17000A0E RID: 2574
		// (get) Token: 0x06002332 RID: 9010 RVA: 0x000D53CE File Offset: 0x000D35CE
		// (set) Token: 0x06002333 RID: 9011 RVA: 0x000D53D6 File Offset: 0x000D35D6
		public int GridColumn { get; set; }

		// Token: 0x17000A0F RID: 2575
		// (get) Token: 0x06002334 RID: 9012 RVA: 0x000D53DF File Offset: 0x000D35DF
		// (set) Token: 0x06002335 RID: 9013 RVA: 0x000D53E7 File Offset: 0x000D35E7
		public double Row { get; set; }

		// Token: 0x17000A10 RID: 2576
		// (get) Token: 0x06002336 RID: 9014 RVA: 0x000D53F0 File Offset: 0x000D35F0
		// (set) Token: 0x06002337 RID: 9015 RVA: 0x000D53F8 File Offset: 0x000D35F8
		public double Column { get; set; }

		// Token: 0x17000A11 RID: 2577
		// (get) Token: 0x06002338 RID: 9016 RVA: 0x000D5401 File Offset: 0x000D3601
		// (set) Token: 0x06002339 RID: 9017 RVA: 0x000D5409 File Offset: 0x000D3609
		public double Angle { get; set; }

		// Token: 0x17000A12 RID: 2578
		// (get) Token: 0x0600233A RID: 9018 RVA: 0x000D5412 File Offset: 0x000D3612
		// (set) Token: 0x0600233B RID: 9019 RVA: 0x000D541A File Offset: 0x000D361A
		public double Score { get; set; }

		// Token: 0x17000A13 RID: 2579
		// (get) Token: 0x0600233C RID: 9020 RVA: 0x000D5423 File Offset: 0x000D3623
		// (set) Token: 0x0600233D RID: 9021 RVA: 0x000D542B File Offset: 0x000D362B
		public double ScaleRow { get; set; } = 1.0;

		// Token: 0x17000A14 RID: 2580
		// (get) Token: 0x0600233E RID: 9022 RVA: 0x000D5434 File Offset: 0x000D3634
		// (set) Token: 0x0600233F RID: 9023 RVA: 0x000D543C File Offset: 0x000D363C
		public double ScaleColumn { get; set; } = 1.0;

		// Token: 0x17000A15 RID: 2581
		// (get) Token: 0x06002340 RID: 9024 RVA: 0x000D5445 File Offset: 0x000D3645
		// (set) Token: 0x06002341 RID: 9025 RVA: 0x000D544D File Offset: 0x000D364D
		public double DeltaRow { get; set; }

		// Token: 0x17000A16 RID: 2582
		// (get) Token: 0x06002342 RID: 9026 RVA: 0x000D5456 File Offset: 0x000D3656
		// (set) Token: 0x06002343 RID: 9027 RVA: 0x000D545E File Offset: 0x000D365E
		public double DeltaColumn { get; set; }

		// Token: 0x17000A17 RID: 2583
		// (get) Token: 0x06002344 RID: 9028 RVA: 0x000D5467 File Offset: 0x000D3667
		// (set) Token: 0x06002345 RID: 9029 RVA: 0x000D546F File Offset: 0x000D366F
		public double DeltaAngle { get; set; }

		// Token: 0x17000A18 RID: 2584
		// (get) Token: 0x06002346 RID: 9030 RVA: 0x000D5478 File Offset: 0x000D3678
		// (set) Token: 0x06002347 RID: 9031 RVA: 0x000D5480 File Offset: 0x000D3680
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000A19 RID: 2585
		// (get) Token: 0x06002348 RID: 9032 RVA: 0x000D5489 File Offset: 0x000D3689
		// (set) Token: 0x06002349 RID: 9033 RVA: 0x000D5491 File Offset: 0x000D3691
		public string InputSourceToolName { get; set; }

		// Token: 0x17000A1A RID: 2586
		// (get) Token: 0x0600234A RID: 9034 RVA: 0x000D549A File Offset: 0x000D369A
		// (set) Token: 0x0600234B RID: 9035 RVA: 0x000D54A2 File Offset: 0x000D36A2
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x17000A1B RID: 2587
		// (get) Token: 0x0600234C RID: 9036 RVA: 0x000D54AB File Offset: 0x000D36AB
		// (set) Token: 0x0600234D RID: 9037 RVA: 0x000D54B3 File Offset: 0x000D36B3
		public string RoiName { get; set; }

		// Token: 0x17000A1C RID: 2588
		// (get) Token: 0x0600234E RID: 9038 RVA: 0x000D54BC File Offset: 0x000D36BC
		// (set) Token: 0x0600234F RID: 9039 RVA: 0x000D54C4 File Offset: 0x000D36C4
		public string Message { get; set; }
	}
}
