﻿using System;

namespace VisionMachine.Services.Appearance
{
	// Token: 0x02000258 RID: 600
	public enum AppColorTheme
	{
		// Token: 0x04000DE7 RID: 3559
		Dark,
		// Token: 0x04000DE8 RID: 3560
		Light
	}
}
