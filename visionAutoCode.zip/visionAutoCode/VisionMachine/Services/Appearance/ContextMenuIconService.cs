﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace VisionMachine.Services.Appearance
{
	// Token: 0x0200025E RID: 606
	internal static class ContextMenuIconService
	{
		// Token: 0x060021F1 RID: 8689 RVA: 0x000C7814 File Offset: 0x000C5A14
		public static void Install()
		{
			bool installed = ContextMenuIconService._installed;
			if (!installed)
			{
				ContextMenuIconService._installed = true;
				EventManager.RegisterClassHandler(typeof(MenuItem), FrameworkElement.LoadedEvent, new RoutedEventHandler(ContextMenuIconService.OnMenuItemLoaded), true);
			}
		}

		// Token: 0x060021F2 RID: 8690 RVA: 0x000C7858 File Offset: 0x000C5A58
		private static void OnMenuItemLoaded(object sender, RoutedEventArgs e)
		{
			MenuItem menuItem = sender as MenuItem;
			bool flag = menuItem == null || menuItem.Icon != null;
			if (!flag)
			{
				string imagePath = ContextMenuIconService.ResolveImagePath(ContextMenuIconService.GetHeaderText(menuItem.Header));
				ImageSource source = ContextMenuIconService.GetImageSource(imagePath);
				bool flag2 = source == null;
				if (!flag2)
				{
					menuItem.Icon = new Image
					{
						Source = source,
						Width = 16.0,
						Height = 16.0,
						Stretch = Stretch.Uniform,
						SnapsToDevicePixels = true
					};
				}
			}
		}

		// Token: 0x060021F3 RID: 8691 RVA: 0x000C78EC File Offset: 0x000C5AEC
		private static string GetHeaderText(object header)
		{
			TextBlock textBlock = header as TextBlock;
			bool flag = textBlock != null;
			string result;
			if (flag)
			{
				result = (textBlock.Text ?? string.Empty);
			}
			else
			{
				result = (Convert.ToString(header, CultureInfo.CurrentCulture) ?? string.Empty);
			}
			return result;
		}

		// Token: 0x060021F4 RID: 8692 RVA: 0x000C7934 File Offset: 0x000C5B34
		private static string ResolveImagePath(string header)
		{
			string value = (header ?? string.Empty).Trim().ToLowerInvariant();
			bool flag = ContextMenuIconService.ContainsAny(value, new string[]
			{
				"copy",
				"sao chép"
			});
			string result;
			if (flag)
			{
				result = "Images/Edit/Copy_16x16.png";
			}
			else
			{
				bool flag2 = ContextMenuIconService.ContainsAny(value, new string[]
				{
					"paste",
					"dán"
				});
				if (flag2)
				{
					result = "Images/Edit/Paste_16x16.png";
				}
				else
				{
					bool flag3 = ContextMenuIconService.ContainsAny(value, new string[]
					{
						"export",
						"xuất"
					});
					if (flag3)
					{
						result = "Images/Export/ExportToXLSX_16x16.png";
					}
					else
					{
						bool flag4 = ContextMenuIconService.ContainsAny(value, new string[]
						{
							"save",
							"lưu"
						});
						if (flag4)
						{
							result = "Images/Save/Save_16x16.png";
						}
						else
						{
							bool flag5 = ContextMenuIconService.ContainsAny(value, new string[]
							{
								"clear",
								"delete",
								"xóa"
							});
							if (flag5)
							{
								result = "Images/Actions/Clear_16x16.png";
							}
							else
							{
								bool flag6 = ContextMenuIconService.ContainsAny(value, new string[]
								{
									"rename",
									"edit",
									"change protocol",
									"customization",
									"properties",
									"đổi tên",
									"chỉnh sửa"
								});
								if (flag6)
								{
									result = "Images/Edit/Edit_16x16.png";
								}
								else
								{
									bool flag7 = ContextMenuIconService.ContainsAny(value, new string[]
									{
										"refresh",
										"làm mới"
									});
									if (flag7)
									{
										result = "Images/Actions/Refresh_16x16.png";
									}
									else
									{
										bool flag8 = ContextMenuIconService.ContainsAny(value, new string[]
										{
											"open",
											"load",
											"mở",
											"tải"
										});
										if (flag8)
										{
											result = "Images/Actions/Open_16x16.png";
										}
										else
										{
											bool flag9 = ContextMenuIconService.ContainsAny(value, new string[]
											{
												"hide",
												"ẩn"
											});
											if (flag9)
											{
												result = "Images/Actions/Hide_16x16.png";
											}
											else
											{
												bool flag10 = ContextMenuIconService.ContainsAny(value, new string[]
												{
													"show",
													"zoom",
													"hiện",
													"phóng"
												});
												if (flag10)
												{
													result = "Images/Actions/Show_16x16.png";
												}
												else
												{
													bool flag11 = ContextMenuIconService.ContainsAny(value, new string[]
													{
														"english",
														"vietnamese",
														"tiếng anh",
														"tiếng việt"
													});
													if (flag11)
													{
														result = "Images/Actions/Apply_16x16.png";
													}
													else
													{
														result = "Images/Setup/Properties_32x32.png";
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060021F5 RID: 8693 RVA: 0x000C7BA4 File Offset: 0x000C5DA4
		private static bool ContainsAny(string value, params string[] terms)
		{
			foreach (string term in terms)
			{
				bool flag = value.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0;
				if (flag)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x060021F6 RID: 8694 RVA: 0x000C7BE8 File Offset: 0x000C5DE8
		private static ImageSource GetImageSource(string imagePath)
		{
			ImageSource cached;
			bool flag = ContextMenuIconService.ImageCache.TryGetValue(imagePath, out cached);
			ImageSource result;
			if (flag)
			{
				result = cached;
			}
			else
			{
				try
				{
					BitmapImage image = new BitmapImage();
					image.BeginInit();
					image.UriSource = new Uri("pack://application:,,,/DevExpress.Images.v22.2;component/" + imagePath, UriKind.Absolute);
					image.CacheOption = BitmapCacheOption.OnLoad;
					image.EndInit();
					image.Freeze();
					ContextMenuIconService.ImageCache[imagePath] = image;
					result = image;
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x04000E00 RID: 3584
		private const string DevExpressImagePrefix = "pack://application:,,,/DevExpress.Images.v22.2;component/";

		// Token: 0x04000E01 RID: 3585
		private static readonly Dictionary<string, ImageSource> ImageCache = new Dictionary<string, ImageSource>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000E02 RID: 3586
		private static bool _installed;
	}
}
