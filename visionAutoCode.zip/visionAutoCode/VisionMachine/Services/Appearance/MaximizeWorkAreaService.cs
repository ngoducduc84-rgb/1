﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace VisionMachine.Services.Appearance
{
	// Token: 0x0200025C RID: 604
	internal static class MaximizeWorkAreaService
	{
		// Token: 0x060021DE RID: 8670 RVA: 0x000C6FE8 File Offset: 0x000C51E8
		public static void Attach(Window window)
		{
			bool flag = window == null;
			if (!flag)
			{
				bool flag2 = new WindowInteropHelper(window).Handle != IntPtr.Zero;
				if (flag2)
				{
					MaximizeWorkAreaService.AddHook(window);
				}
				else
				{
					window.SourceInitialized += delegate(object s, EventArgs e)
					{
						MaximizeWorkAreaService.AddHook(window);
					};
				}
			}
		}

		// Token: 0x060021DF RID: 8671 RVA: 0x000C7058 File Offset: 0x000C5258
		private static void AddHook(Window window)
		{
			HwndSource source = HwndSource.FromHwnd(new WindowInteropHelper(window).Handle);
			bool flag = source != null;
			if (flag)
			{
				source.AddHook(new HwndSourceHook(MaximizeWorkAreaService.WindowProc));
			}
			MaximizeWorkAreaService.ClampRestoreSize(window);
		}

		// Token: 0x060021E0 RID: 8672 RVA: 0x000C709C File Offset: 0x000C529C
		private static void ClampRestoreSize(Window window)
		{
			try
			{
				IntPtr monitor = MaximizeWorkAreaService.MonitorFromWindow(new WindowInteropHelper(window).Handle, 2);
				bool flag = monitor == IntPtr.Zero;
				if (!flag)
				{
					MaximizeWorkAreaService.MONITORINFO info = default(MaximizeWorkAreaService.MONITORINFO);
					info.cbSize = Marshal.SizeOf(typeof(MaximizeWorkAreaService.MONITORINFO));
					bool flag2 = !MaximizeWorkAreaService.GetMonitorInfo(monitor, ref info);
					if (!flag2)
					{
						PresentationSource source = PresentationSource.FromVisual(window);
						bool flag3 = source == null || source.CompositionTarget == null;
						if (!flag3)
						{
							double scaleX = source.CompositionTarget.TransformToDevice.M11;
							double scaleY = source.CompositionTarget.TransformToDevice.M22;
							double availableWidth = (double)(info.rcWork.Right - info.rcWork.Left) / scaleX;
							double availableHeight = (double)(info.rcWork.Bottom - info.rcWork.Top) / scaleY;
							bool flag4 = window.Width > availableWidth;
							if (flag4)
							{
								window.Width = availableWidth;
							}
							bool flag5 = window.Height > availableHeight;
							if (flag5)
							{
								window.Height = availableHeight;
							}
						}
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060021E1 RID: 8673 RVA: 0x000C71E4 File Offset: 0x000C53E4
		private static IntPtr WindowProc(IntPtr windowHandle, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
		{
			bool flag = message == 36 && MaximizeWorkAreaService.ClampToWorkArea(windowHandle, lParam);
			if (flag)
			{
				handled = true;
			}
			return IntPtr.Zero;
		}

		// Token: 0x060021E2 RID: 8674 RVA: 0x000C7214 File Offset: 0x000C5414
		private static bool ClampToWorkArea(IntPtr windowHandle, IntPtr lParam)
		{
			bool result;
			try
			{
				IntPtr monitor = MaximizeWorkAreaService.MonitorFromWindow(windowHandle, 2);
				bool flag = monitor == IntPtr.Zero;
				if (flag)
				{
					result = false;
				}
				else
				{
					MaximizeWorkAreaService.MONITORINFO info = default(MaximizeWorkAreaService.MONITORINFO);
					info.cbSize = Marshal.SizeOf(typeof(MaximizeWorkAreaService.MONITORINFO));
					bool flag2 = !MaximizeWorkAreaService.GetMonitorInfo(monitor, ref info);
					if (flag2)
					{
						result = false;
					}
					else
					{
						MaximizeWorkAreaService.MINMAXINFO minMax = (MaximizeWorkAreaService.MINMAXINFO)Marshal.PtrToStructure(lParam, typeof(MaximizeWorkAreaService.MINMAXINFO));
						minMax.ptMaxPosition.x = info.rcWork.Left - info.rcMonitor.Left;
						minMax.ptMaxPosition.y = info.rcWork.Top - info.rcMonitor.Top;
						minMax.ptMaxSize.x = info.rcWork.Right - info.rcWork.Left;
						minMax.ptMaxSize.y = info.rcWork.Bottom - info.rcWork.Top;
						minMax.ptMaxTrackSize.x = minMax.ptMaxSize.x;
						minMax.ptMaxTrackSize.y = minMax.ptMaxSize.y;
						Marshal.StructureToPtr<MaximizeWorkAreaService.MINMAXINFO>(minMax, lParam, true);
						result = true;
					}
				}
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060021E3 RID: 8675
		[DllImport("user32.dll")]
		private static extern IntPtr MonitorFromWindow(IntPtr windowHandle, int flags);

		// Token: 0x060021E4 RID: 8676
		[DllImport("user32.dll")]
		private static extern bool GetMonitorInfo(IntPtr monitor, ref MaximizeWorkAreaService.MONITORINFO info);

		// Token: 0x04000DF0 RID: 3568
		private const int WmGetMinMaxInfo = 36;

		// Token: 0x04000DF1 RID: 3569
		private const int MonitorDefaultToNearest = 2;

		// Token: 0x020004AE RID: 1198
		private struct POINT
		{
			// Token: 0x04001696 RID: 5782
			public int x;

			// Token: 0x04001697 RID: 5783
			public int y;
		}

		// Token: 0x020004AF RID: 1199
		private struct MINMAXINFO
		{
			// Token: 0x04001698 RID: 5784
			public MaximizeWorkAreaService.POINT ptReserved;

			// Token: 0x04001699 RID: 5785
			public MaximizeWorkAreaService.POINT ptMaxSize;

			// Token: 0x0400169A RID: 5786
			public MaximizeWorkAreaService.POINT ptMaxPosition;

			// Token: 0x0400169B RID: 5787
			public MaximizeWorkAreaService.POINT ptMinTrackSize;

			// Token: 0x0400169C RID: 5788
			public MaximizeWorkAreaService.POINT ptMaxTrackSize;
		}

		// Token: 0x020004B0 RID: 1200
		private struct RECT
		{
			// Token: 0x0400169D RID: 5789
			public int Left;

			// Token: 0x0400169E RID: 5790
			public int Top;

			// Token: 0x0400169F RID: 5791
			public int Right;

			// Token: 0x040016A0 RID: 5792
			public int Bottom;
		}

		// Token: 0x020004B1 RID: 1201
		private struct MONITORINFO
		{
			// Token: 0x040016A1 RID: 5793
			public int cbSize;

			// Token: 0x040016A2 RID: 5794
			public MaximizeWorkAreaService.RECT rcMonitor;

			// Token: 0x040016A3 RID: 5795
			public MaximizeWorkAreaService.RECT rcWork;

			// Token: 0x040016A4 RID: 5796
			public int dwFlags;
		}
	}
}
