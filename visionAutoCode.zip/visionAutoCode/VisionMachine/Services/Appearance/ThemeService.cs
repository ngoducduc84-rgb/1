﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Services.Appearance
{
	// Token: 0x0200025A RID: 602
	public static class ThemeService
	{
		// Token: 0x170009D1 RID: 2513
		// (get) Token: 0x060021C5 RID: 8645 RVA: 0x000C61BB File Offset: 0x000C43BB
		// (set) Token: 0x060021C6 RID: 8646 RVA: 0x000C61C2 File Offset: 0x000C43C2
		public static AppColorTheme Current { get; private set; }

		// Token: 0x14000039 RID: 57
		// (add) Token: 0x060021C7 RID: 8647 RVA: 0x000C61CC File Offset: 0x000C43CC
		// (remove) Token: 0x060021C8 RID: 8648 RVA: 0x000C6200 File Offset: 0x000C4400
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler ThemeChanged;

		// Token: 0x060021C9 RID: 8649 RVA: 0x000C6233 File Offset: 0x000C4433
		public static void Initialize()
		{
			WpfThemeAdapter.Install();
			WindowCaptionThemeService.Install();
			ThemeService.Apply(ThemeService.Load(), false);
		}

		// Token: 0x060021CA RID: 8650 RVA: 0x000C624E File Offset: 0x000C444E
		public static void SetTheme(AppColorTheme theme)
		{
			ThemeService.Apply(theme, true);
		}

		// Token: 0x060021CB RID: 8651 RVA: 0x000C625C File Offset: 0x000C445C
		private static void Apply(AppColorTheme theme, bool save)
		{
			string themeName = ThemeService.GetThemeName(theme);
			bool flag = !ThemeService.IsThemeAvailable(themeName);
			if (flag)
			{
				AppColorTheme fallback = (theme == AppColorTheme.Light) ? AppColorTheme.Dark : AppColorTheme.Light;
				bool flag2 = ThemeService.IsThemeAvailable(ThemeService.GetThemeName(fallback));
				if (flag2)
				{
					theme = fallback;
					themeName = ThemeService.GetThemeName(theme);
				}
				else
				{
					themeName = null;
				}
			}
			ThemeService.Current = theme;
			ThemeService.ApplyApplicationPalette(theme);
			bool flag3 = themeName != null;
			if (flag3)
			{
				try
				{
					ApplicationThemeHelper.ApplicationThemeName = themeName;
				}
				catch (Exception)
				{
				}
			}
			WpfThemeAdapter.ApplyToOpenWindows(theme);
			WindowCaptionThemeService.ApplyToOpenWindows(theme);
			if (save)
			{
				ThemeService.Save(theme);
			}
			EventHandler themeChanged = ThemeService.ThemeChanged;
			if (themeChanged != null)
			{
				themeChanged(null, EventArgs.Empty);
			}
		}

		// Token: 0x060021CC RID: 8652 RVA: 0x000C6318 File Offset: 0x000C4518
		private static string GetThemeName(AppColorTheme theme)
		{
			return (theme == AppColorTheme.Light) ? "Win11Light" : "Win11Dark";
		}

		// Token: 0x060021CD RID: 8653 RVA: 0x000C633C File Offset: 0x000C453C
		private static bool IsThemeAvailable(string themeName)
		{
			bool result;
			try
			{
				Theme theme = Theme.FindTheme(themeName);
				bool flag = theme == null;
				if (flag)
				{
					result = false;
				}
				else
				{
					bool flag2 = string.IsNullOrEmpty(theme.AssemblyName);
					if (flag2)
					{
						result = true;
					}
					else
					{
						result = (Assembly.Load(theme.AssemblyName) != null);
					}
				}
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060021CE RID: 8654 RVA: 0x000C639C File Offset: 0x000C459C
		private static void ApplyApplicationPalette(AppColorTheme theme)
		{
			bool flag = Application.Current == null;
			if (!flag)
			{
				bool light = theme == AppColorTheme.Light;
				ThemeService.SetPaletteEntry("VmBackground", light ? "#F4F7FB" : "#050A14");
				ThemeService.SetPaletteEntry("VmPanel", light ? "#FFFFFF" : "#111923");
				ThemeService.SetPaletteEntry("VmPanelAlt", light ? "#F2F6FB" : "#0B121D");
				ThemeService.SetPaletteEntry("VmInput", light ? "#FFFFFF" : "#0D1626");
				ThemeService.SetPaletteEntry("VmControl", light ? "#E7EEF7" : "#16233A");
				ThemeService.SetPaletteEntry("VmBorder", light ? "#BCC9D9" : "#263342");
				ThemeService.SetPaletteEntry("VmText", light ? "#172235" : "#EAF2FF");
				ThemeService.SetPaletteEntry("VmSubText", light ? "#607089" : "#8FA4BD");
				ThemeService.SetPaletteEntry("VmSplitter", light ? "#AFC0D5" : "#1D3562");
				ThemeService.SetPaletteEntry("VmErrorText", light ? "#B91C1C" : "#F87171");
				ThemeService.SetPaletteEntry("VmWarningText", light ? "#92400E" : "#FBBF24");
				ThemeService.SetPaletteEntry("VmInfoText", light ? "#1D4ED8" : "#60A5FA");
				ThemeService.SetPaletteEntry("VmSuccessText", light ? "#166534" : "#4ADE80");
				ThemeService.SetPaletteEntry("VmTriggerText", light ? "#0E7490" : "#5FD0E8");
				ThemeService.SetPaletteEntry("VmAmberText", light ? "#854D0E" : "#FACC15");
			}
		}

		// Token: 0x060021CF RID: 8655 RVA: 0x000C6548 File Offset: 0x000C4748
		private static void SetPaletteEntry(string name, string value)
		{
			Color color = (Color)ColorConverter.ConvertFromString(value);
			ResourceDictionary resources = Application.Current.Resources;
			resources[name + "Color"] = color;
			string brushKey = name + "Brush";
			SolidColorBrush brush = resources[brushKey] as SolidColorBrush;
			bool flag = brush != null && !brush.IsFrozen;
			if (flag)
			{
				brush.Color = color;
			}
			else
			{
				resources[brushKey] = new SolidColorBrush(color);
			}
		}

		// Token: 0x060021D0 RID: 8656 RVA: 0x000C65D0 File Offset: 0x000C47D0
		private static AppColorTheme Load()
		{
			AppColorTheme result;
			try
			{
				string path = Manager_path._themeJsonPath;
				bool flag = !File.Exists(path);
				if (flag)
				{
					result = AppColorTheme.Dark;
				}
				else
				{
					ThemeSettingData data = JsonConvert.DeserializeObject<ThemeSettingData>(File.ReadAllText(path));
					AppColorTheme parsed;
					result = ((data != null && Enum.TryParse<AppColorTheme>(data.Theme, true, out parsed)) ? parsed : AppColorTheme.Dark);
				}
			}
			catch
			{
				result = AppColorTheme.Dark;
			}
			return result;
		}

		// Token: 0x060021D1 RID: 8657 RVA: 0x000C6638 File Offset: 0x000C4838
		private static void Save(AppColorTheme theme)
		{
			try
			{
				string path = Manager_path._themeJsonPath;
				string folder = Path.GetDirectoryName(path);
				bool flag = !string.IsNullOrWhiteSpace(folder);
				if (flag)
				{
					Manager_path.Creat_path(folder);
				}
				File.WriteAllText(path, JsonConvert.SerializeObject(new ThemeSettingData
				{
					Theme = theme.ToString()
				}, Formatting.Indented));
			}
			catch
			{
			}
		}
	}
}
