﻿using System;

namespace VisionMachine.Services.Appearance
{
	// Token: 0x02000259 RID: 601
	internal sealed class ThemeSettingData
	{
		// Token: 0x170009D0 RID: 2512
		// (get) Token: 0x060021C2 RID: 8642 RVA: 0x000C61AA File Offset: 0x000C43AA
		// (set) Token: 0x060021C3 RID: 8643 RVA: 0x000C61B2 File Offset: 0x000C43B2
		public string Theme { get; set; }
	}
}
