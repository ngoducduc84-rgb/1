﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;

namespace VisionMachine.Services.Appearance
{
	// Token: 0x0200025D RID: 605
	internal static class WindowCaptionThemeService
	{
		// Token: 0x060021E5 RID: 8677
		[DllImport("dwmapi.dll")]
		private static extern int DwmSetWindowAttribute(IntPtr windowHandle, int attribute, ref int attributeValue, int attributeSize);

		// Token: 0x060021E6 RID: 8678
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool SetWindowPos(IntPtr windowHandle, IntPtr insertAfter, int x, int y, int width, int height, uint flags);

		// Token: 0x060021E7 RID: 8679
		[DllImport("user32.dll", SetLastError = true)]
		private static extern bool RedrawWindow(IntPtr windowHandle, IntPtr updateRectangle, IntPtr updateRegion, uint flags);

		// Token: 0x060021E8 RID: 8680 RVA: 0x000C737C File Offset: 0x000C557C
		public static void Install()
		{
			bool installed = WindowCaptionThemeService._installed;
			if (!installed)
			{
				WindowCaptionThemeService._installed = true;
				EventManager.RegisterClassHandler(typeof(Window), FrameworkElement.LoadedEvent, new RoutedEventHandler(WindowCaptionThemeService.OnWindowLoaded), true);
			}
		}

		// Token: 0x060021E9 RID: 8681 RVA: 0x000C73C0 File Offset: 0x000C55C0
		public static void ApplyToOpenWindows(AppColorTheme theme)
		{
			bool flag = Application.Current == null;
			if (!flag)
			{
				foreach (object obj in Application.Current.Windows)
				{
					Window window = (Window)obj;
					WindowCaptionThemeService.Apply(window, theme);
					WindowCaptionThemeService.ScheduleReapply(window, theme);
				}
			}
		}

		// Token: 0x060021EA RID: 8682 RVA: 0x000C743C File Offset: 0x000C563C
		private static void OnWindowLoaded(object sender, RoutedEventArgs e)
		{
			Window window = sender as Window;
			bool flag = window == null;
			if (!flag)
			{
				window.ContentRendered -= WindowCaptionThemeService.OnWindowContentRendered;
				window.ContentRendered += WindowCaptionThemeService.OnWindowContentRendered;
				window.Activated -= WindowCaptionThemeService.OnWindowActivated;
				window.Activated += WindowCaptionThemeService.OnWindowActivated;
				WindowCaptionThemeService.Apply(window, ThemeService.Current);
				window.Dispatcher.BeginInvoke(new Action(delegate()
				{
					WindowCaptionThemeService.Apply(window, ThemeService.Current);
				}), DispatcherPriority.ApplicationIdle, Array.Empty<object>());
			}
		}

		// Token: 0x060021EB RID: 8683 RVA: 0x000C7502 File Offset: 0x000C5702
		private static void OnWindowContentRendered(object sender, EventArgs e)
		{
			WindowCaptionThemeService.Apply(sender as Window, ThemeService.Current);
		}

		// Token: 0x060021EC RID: 8684 RVA: 0x000C7518 File Offset: 0x000C5718
		private static void OnWindowActivated(object sender, EventArgs e)
		{
			Window window = sender as Window;
			WindowCaptionThemeService.Apply(window, ThemeService.Current);
			WindowCaptionThemeService.ScheduleReapply(window, ThemeService.Current);
		}

		// Token: 0x060021ED RID: 8685 RVA: 0x000C7548 File Offset: 0x000C5748
		private static void ScheduleReapply(Window window, AppColorTheme theme)
		{
			bool flag = window == null || window.Dispatcher == null;
			if (!flag)
			{
				int remainingPasses = 5;
				DispatcherTimer timer = new DispatcherTimer(DispatcherPriority.ApplicationIdle, window.Dispatcher)
				{
					Interval = TimeSpan.FromMilliseconds(150.0)
				};
				EventHandler tick = null;
				tick = delegate(object sender, EventArgs args)
				{
					bool flag2;
					if (window.IsLoaded)
					{
						int remainingPasses = remainingPasses;
						remainingPasses--;
						flag2 = (remainingPasses <= 0);
					}
					else
					{
						flag2 = true;
					}
					bool flag3 = flag2;
					if (flag3)
					{
						timer.Stop();
						timer.Tick -= tick;
					}
					else
					{
						WindowCaptionThemeService.Apply(window, theme);
					}
				};
				timer.Tick += tick;
				timer.Start();
			}
		}

		// Token: 0x060021EE RID: 8686 RVA: 0x000C75F4 File Offset: 0x000C57F4
		private static void Apply(Window window, AppColorTheme theme)
		{
			bool flag = window == null || Environment.OSVersion.Platform != PlatformID.Win32NT;
			if (!flag)
			{
				IntPtr handle = new WindowInteropHelper(window).Handle;
				bool flag2 = handle == IntPtr.Zero;
				if (!flag2)
				{
					try
					{
						int darkMode = (theme == AppColorTheme.Dark) ? 1 : 0;
						int result = WindowCaptionThemeService.DwmSetWindowAttribute(handle, 20, ref darkMode, 4);
						bool flag3 = result != 0;
						if (flag3)
						{
							WindowCaptionThemeService.DwmSetWindowAttribute(handle, 19, ref darkMode, 4);
						}
						int captionColor = WindowCaptionThemeService.ToColorRef(WindowCaptionThemeService.GetPaletteColor("VmBackgroundColor", (theme == AppColorTheme.Light) ? Color.FromRgb(244, 247, 251) : Color.FromRgb(5, 10, 20)));
						int textColor = WindowCaptionThemeService.ToColorRef(WindowCaptionThemeService.GetPaletteColor("VmTextColor", (theme == AppColorTheme.Light) ? Color.FromRgb(23, 34, 53) : Color.FromRgb(234, 242, byte.MaxValue)));
						int borderColor = WindowCaptionThemeService.ToColorRef(WindowCaptionThemeService.GetPaletteColor("VmBorderColor", (theme == AppColorTheme.Light) ? Color.FromRgb(188, 201, 217) : Color.FromRgb(38, 51, 66)));
						WindowCaptionThemeService.DwmSetWindowAttribute(handle, 35, ref captionColor, 4);
						WindowCaptionThemeService.DwmSetWindowAttribute(handle, 36, ref textColor, 4);
						WindowCaptionThemeService.DwmSetWindowAttribute(handle, 34, ref borderColor, 4);
						WindowCaptionThemeService.SetWindowPos(handle, IntPtr.Zero, 0, 0, 0, 0, 55U);
						WindowCaptionThemeService.RedrawWindow(handle, IntPtr.Zero, IntPtr.Zero, 1281U);
					}
					catch (DllNotFoundException)
					{
					}
					catch (EntryPointNotFoundException)
					{
					}
				}
			}
		}

		// Token: 0x060021EF RID: 8687 RVA: 0x000C77A0 File Offset: 0x000C59A0
		private static Color GetPaletteColor(string key, Color fallback)
		{
			bool flag = Application.Current == null;
			Color result;
			if (flag)
			{
				result = fallback;
			}
			else
			{
				object value = Application.Current.Resources[key];
				result = ((value is Color) ? ((Color)value) : fallback);
			}
			return result;
		}

		// Token: 0x060021F0 RID: 8688 RVA: 0x000C77E4 File Offset: 0x000C59E4
		private static int ToColorRef(Color color)
		{
			return (int)color.R | (int)color.G << 8 | (int)color.B << 16;
		}

		// Token: 0x04000DF2 RID: 3570
		private const int DwmUseImmersiveDarkModeBefore20H1 = 19;

		// Token: 0x04000DF3 RID: 3571
		private const int DwmUseImmersiveDarkMode = 20;

		// Token: 0x04000DF4 RID: 3572
		private const int DwmBorderColor = 34;

		// Token: 0x04000DF5 RID: 3573
		private const int DwmCaptionColor = 35;

		// Token: 0x04000DF6 RID: 3574
		private const int DwmTextColor = 36;

		// Token: 0x04000DF7 RID: 3575
		private const uint SwpNoSize = 1U;

		// Token: 0x04000DF8 RID: 3576
		private const uint SwpNoMove = 2U;

		// Token: 0x04000DF9 RID: 3577
		private const uint SwpNoZOrder = 4U;

		// Token: 0x04000DFA RID: 3578
		private const uint SwpNoActivate = 16U;

		// Token: 0x04000DFB RID: 3579
		private const uint SwpFrameChanged = 32U;

		// Token: 0x04000DFC RID: 3580
		private const uint RdwInvalidate = 1U;

		// Token: 0x04000DFD RID: 3581
		private const uint RdwFrame = 1024U;

		// Token: 0x04000DFE RID: 3582
		private const uint RdwUpdateNow = 256U;

		// Token: 0x04000DFF RID: 3583
		private static bool _installed;
	}
}
