﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace VisionMachine.Services.Appearance
{
	// Token: 0x0200025B RID: 603
	internal static class WpfThemeAdapter
	{
		// Token: 0x060021D2 RID: 8658 RVA: 0x000C66A8 File Offset: 0x000C48A8
		public static void Install()
		{
			bool installed = WpfThemeAdapter._installed;
			if (!installed)
			{
				WpfThemeAdapter._installed = true;
				EventManager.RegisterClassHandler(typeof(FrameworkElement), FrameworkElement.LoadedEvent, new RoutedEventHandler(WpfThemeAdapter.OnElementLoaded), true);
			}
		}

		// Token: 0x060021D3 RID: 8659 RVA: 0x000C66EC File Offset: 0x000C48EC
		public static void SetPreserveColors(DependencyObject element, bool preserve)
		{
			bool flag = element != null;
			if (flag)
			{
				element.SetValue(WpfThemeAdapter.PreserveColorsProperty, preserve);
			}
		}

		// Token: 0x060021D4 RID: 8660 RVA: 0x000C6714 File Offset: 0x000C4914
		private static bool GetPreserveColors(DependencyObject element)
		{
			return element != null && (bool)element.GetValue(WpfThemeAdapter.PreserveColorsProperty);
		}

		// Token: 0x060021D5 RID: 8661 RVA: 0x000C673C File Offset: 0x000C493C
		public static void ApplyToOpenWindows(AppColorTheme theme)
		{
			bool flag = Application.Current == null;
			if (!flag)
			{
				int applyVersion = Interlocked.Increment(ref WpfThemeAdapter._applyVersion);
				using (IEnumerator enumerator = Application.Current.Windows.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Window window = (Window)enumerator.Current;
						WpfThemeAdapter.ApplyTree(window, theme);
						window.Dispatcher.BeginInvoke(new Action(delegate()
						{
							bool flag2 = applyVersion == WpfThemeAdapter._applyVersion && ThemeService.Current == theme;
							if (flag2)
							{
								WpfThemeAdapter.ApplyTree(window, theme);
							}
						}), DispatcherPriority.Loaded, Array.Empty<object>());
					}
				}
			}
		}

		// Token: 0x060021D6 RID: 8662 RVA: 0x000C6814 File Offset: 0x000C4A14
		private static void OnElementLoaded(object sender, RoutedEventArgs e)
		{
			bool flag = ThemeService.Current != AppColorTheme.Light;
			if (!flag)
			{
				DependencyObject element = sender as DependencyObject;
				bool flag2 = element != null;
				if (flag2)
				{
					WpfThemeAdapter.ApplyElement(element, AppColorTheme.Light);
				}
			}
		}

		// Token: 0x060021D7 RID: 8663 RVA: 0x000C684C File Offset: 0x000C4A4C
		private static void ApplyTree(DependencyObject root, AppColorTheme theme)
		{
			bool flag = root == null;
			if (!flag)
			{
				HashSet<DependencyObject> visited = new HashSet<DependencyObject>();
				Stack<DependencyObject> pending = new Stack<DependencyObject>();
				pending.Push(root);
				while (pending.Count > 0)
				{
					DependencyObject current = pending.Pop();
					bool flag2 = current == null || !visited.Add(current);
					if (!flag2)
					{
						WpfThemeAdapter.ApplyElement(current, theme);
						int visualCount = 0;
						try
						{
							visualCount = VisualTreeHelper.GetChildrenCount(current);
						}
						catch
						{
						}
						for (int index = 0; index < visualCount; index++)
						{
							try
							{
								pending.Push(VisualTreeHelper.GetChild(current, index));
							}
							catch
							{
							}
						}
						try
						{
							foreach (object childValue in LogicalTreeHelper.GetChildren(current))
							{
								DependencyObject child = childValue as DependencyObject;
								bool flag3 = child != null;
								if (flag3)
								{
									pending.Push(child);
								}
							}
						}
						catch
						{
						}
					}
				}
			}
		}

		// Token: 0x060021D8 RID: 8664 RVA: 0x000C699C File Offset: 0x000C4B9C
		private static void ApplyElement(DependencyObject element, AppColorTheme theme)
		{
			bool flag = theme == AppColorTheme.Dark;
			if (flag)
			{
				WpfThemeAdapter.RestoreOriginalBrushes(element);
			}
			else
			{
				bool preserveColors = WpfThemeAdapter.GetPreserveColors(element);
				if (!preserveColors)
				{
					Control control = element as Control;
					bool flag2 = control != null;
					if (flag2)
					{
						WpfThemeAdapter.AdaptBrush(element, Control.BackgroundProperty, WpfThemeAdapter.BrushRole.Background);
						WpfThemeAdapter.AdaptBrush(element, Control.ForegroundProperty, WpfThemeAdapter.BrushRole.Foreground);
						WpfThemeAdapter.AdaptBrush(element, Control.BorderBrushProperty, WpfThemeAdapter.BrushRole.Border);
					}
					Panel panel = element as Panel;
					bool flag3 = panel != null;
					if (flag3)
					{
						WpfThemeAdapter.AdaptBrush(element, Panel.BackgroundProperty, WpfThemeAdapter.BrushRole.Background);
					}
					Border border = element as Border;
					bool flag4 = border != null;
					if (flag4)
					{
						WpfThemeAdapter.AdaptBrush(element, Border.BackgroundProperty, WpfThemeAdapter.BrushRole.Background);
						WpfThemeAdapter.AdaptBrush(element, Border.BorderBrushProperty, WpfThemeAdapter.BrushRole.Border);
					}
					TextBlock textBlock = element as TextBlock;
					bool flag5 = textBlock != null;
					if (flag5)
					{
						WpfThemeAdapter.AdaptBrush(element, TextBlock.BackgroundProperty, WpfThemeAdapter.BrushRole.Background);
						WpfThemeAdapter.AdaptBrush(element, TextBlock.ForegroundProperty, WpfThemeAdapter.BrushRole.Foreground);
					}
					TextElement textElement = element as TextElement;
					bool flag6 = textElement != null;
					if (flag6)
					{
						WpfThemeAdapter.AdaptBrush(element, TextElement.ForegroundProperty, WpfThemeAdapter.BrushRole.Foreground);
					}
					Shape shape = element as Shape;
					bool flag7 = shape != null;
					if (flag7)
					{
						WpfThemeAdapter.AdaptBrush(element, Shape.FillProperty, WpfThemeAdapter.BrushRole.Fill);
						WpfThemeAdapter.AdaptBrush(element, Shape.StrokeProperty, WpfThemeAdapter.BrushRole.Stroke);
					}
					Window window = element as Window;
					bool flag8 = window != null;
					if (flag8)
					{
						WpfThemeAdapter.AdaptBrush(element, Control.BackgroundProperty, WpfThemeAdapter.BrushRole.Background);
					}
				}
			}
		}

		// Token: 0x060021D9 RID: 8665 RVA: 0x000C6AF4 File Offset: 0x000C4CF4
		private static void AdaptBrush(DependencyObject element, DependencyProperty property, WpfThemeAdapter.BrushRole role)
		{
			SolidColorBrush source = element.GetValue(property) as SolidColorBrush;
			bool flag = source == null || source.Color.A == 0;
			if (!flag)
			{
				Color target;
				bool flag2 = !WpfThemeAdapter.TryGetLightColor(source.Color, role, out target) || target == source.Color;
				if (!flag2)
				{
					Dictionary<DependencyProperty, object> originals = element.GetValue(WpfThemeAdapter.OriginalBrushValuesProperty) as Dictionary<DependencyProperty, object>;
					bool flag3 = originals == null;
					if (flag3)
					{
						originals = new Dictionary<DependencyProperty, object>();
						element.SetValue(WpfThemeAdapter.OriginalBrushValuesProperty, originals);
					}
					bool flag4 = !originals.ContainsKey(property);
					if (flag4)
					{
						originals[property] = element.ReadLocalValue(property);
					}
					element.SetValue(property, new SolidColorBrush(target));
				}
			}
		}

		// Token: 0x060021DA RID: 8666 RVA: 0x000C6BB8 File Offset: 0x000C4DB8
		private static void RestoreOriginalBrushes(DependencyObject element)
		{
			Dictionary<DependencyProperty, object> originals = element.GetValue(WpfThemeAdapter.OriginalBrushValuesProperty) as Dictionary<DependencyProperty, object>;
			bool flag = originals == null;
			if (!flag)
			{
				foreach (KeyValuePair<DependencyProperty, object> item in originals)
				{
					bool flag2 = item.Value == DependencyProperty.UnsetValue;
					if (flag2)
					{
						element.ClearValue(item.Key);
					}
					else
					{
						element.SetValue(item.Key, item.Value);
					}
				}
				element.ClearValue(WpfThemeAdapter.OriginalBrushValuesProperty);
			}
		}

		// Token: 0x060021DB RID: 8667 RVA: 0x000C6C64 File Offset: 0x000C4E64
		private static bool TryGetLightColor(Color source, WpfThemeAdapter.BrushRole role, out Color target)
		{
			target = source;
			double max = (double)Math.Max(source.R, Math.Max(source.G, source.B)) / 255.0;
			double min = (double)Math.Min(source.R, Math.Min(source.G, source.B)) / 255.0;
			double luminance = (0.2126 * (double)source.R + 0.7152 * (double)source.G + 0.0722 * (double)source.B) / 255.0;
			double saturation = (max <= 0.0) ? 0.0 : ((max - min) / max);
			bool result;
			switch (role)
			{
			case WpfThemeAdapter.BrushRole.Background:
			{
				bool flag = luminance < 0.13;
				if (flag)
				{
					target = WpfThemeAdapter.WithAlpha(source, 247, 249, 252);
				}
				else
				{
					bool flag2 = luminance < 0.24;
					if (flag2)
					{
						target = WpfThemeAdapter.WithAlpha(source, 239, 244, 249);
					}
					else
					{
						bool flag3 = luminance < 0.4 && saturation < 0.62;
						if (flag3)
						{
							target = WpfThemeAdapter.WithAlpha(source, 225, 233, 243);
						}
						else
						{
							bool flag4 = luminance < 0.4 && saturation >= 0.62;
							if (!flag4)
							{
								result = false;
								break;
							}
							target = WpfThemeAdapter.WithAlpha(source, 219, 231, byte.MaxValue);
						}
					}
				}
				result = true;
				break;
			}
			case WpfThemeAdapter.BrushRole.Foreground:
			{
				bool flag5 = luminance > 0.78 && saturation < 0.42;
				if (flag5)
				{
					target = WpfThemeAdapter.WithAlpha(source, 25, 34, 48);
				}
				else
				{
					bool flag6 = luminance > 0.52 && saturation < 0.35;
					if (!flag6)
					{
						result = false;
						break;
					}
					target = WpfThemeAdapter.WithAlpha(source, 65, 78, 96);
				}
				result = true;
				break;
			}
			case WpfThemeAdapter.BrushRole.Border:
			case WpfThemeAdapter.BrushRole.Stroke:
			{
				bool flag7 = luminance < 0.42 && saturation < 0.72;
				if (flag7)
				{
					target = WpfThemeAdapter.WithAlpha(source, 185, 199, 217);
					result = true;
				}
				else
				{
					result = false;
				}
				break;
			}
			case WpfThemeAdapter.BrushRole.Fill:
			{
				bool flag8 = luminance < 0.3 && saturation < 0.38;
				if (flag8)
				{
					target = WpfThemeAdapter.WithAlpha(source, 225, 233, 243);
					result = true;
				}
				else
				{
					result = false;
				}
				break;
			}
			default:
				result = false;
				break;
			}
			return result;
		}

		// Token: 0x060021DC RID: 8668 RVA: 0x000C6F5C File Offset: 0x000C515C
		private static Color WithAlpha(Color source, byte red, byte green, byte blue)
		{
			return Color.FromArgb(source.A, red, green, blue);
		}

		// Token: 0x04000DEC RID: 3564
		private static readonly DependencyProperty OriginalBrushValuesProperty = DependencyProperty.RegisterAttached("OriginalBrushValues", typeof(Dictionary<DependencyProperty, object>), typeof(WpfThemeAdapter), new PropertyMetadata(null));

		// Token: 0x04000DED RID: 3565
		private static readonly DependencyProperty PreserveColorsProperty = DependencyProperty.RegisterAttached("PreserveColors", typeof(bool), typeof(WpfThemeAdapter), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.Inherits));

		// Token: 0x04000DEE RID: 3566
		private static bool _installed;

		// Token: 0x04000DEF RID: 3567
		private static int _applyVersion;

		// Token: 0x020004AB RID: 1195
		private enum BrushRole
		{
			// Token: 0x0400168D RID: 5773
			Background,
			// Token: 0x0400168E RID: 5774
			Foreground,
			// Token: 0x0400168F RID: 5775
			Border,
			// Token: 0x04001690 RID: 5776
			Fill,
			// Token: 0x04001691 RID: 5777
			Stroke
		}
	}
}
