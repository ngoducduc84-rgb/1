﻿using System;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x0200022B RID: 555
	public class CalibHandEyeConfigData
	{
		// Token: 0x17000954 RID: 2388
		// (get) Token: 0x06001F52 RID: 8018 RVA: 0x000B6F53 File Offset: 0x000B5153
		// (set) Token: 0x06001F53 RID: 8019 RVA: 0x000B6F5B File Offset: 0x000B515B
		public string CameraName { get; set; } = "None";

		// Token: 0x17000955 RID: 2389
		// (get) Token: 0x06001F54 RID: 8020 RVA: 0x000B6F64 File Offset: 0x000B5164
		// (set) Token: 0x06001F55 RID: 8021 RVA: 0x000B6F6C File Offset: 0x000B516C
		public string MasterToolName { get; set; } = "None";

		// Token: 0x17000956 RID: 2390
		// (get) Token: 0x06001F56 RID: 8022 RVA: 0x000B6F75 File Offset: 0x000B5175
		// (set) Token: 0x06001F57 RID: 8023 RVA: 0x000B6F7D File Offset: 0x000B517D
		public string CommunicationName { get; set; } = "None";

		// Token: 0x17000957 RID: 2391
		// (get) Token: 0x06001F58 RID: 8024 RVA: 0x000B6F86 File Offset: 0x000B5186
		// (set) Token: 0x06001F59 RID: 8025 RVA: 0x000B6F8E File Offset: 0x000B518E
		public int CalibrationPoints { get; set; } = 12;

		// Token: 0x17000958 RID: 2392
		// (get) Token: 0x06001F5A RID: 8026 RVA: 0x000B6F97 File Offset: 0x000B5197
		// (set) Token: 0x06001F5B RID: 8027 RVA: 0x000B6F9F File Offset: 0x000B519F
		public int RotationPointCount { get; set; } = 0;
	}
}
