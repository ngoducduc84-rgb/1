﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Runtime;
using VisionMachine.Views.Calibration.ViewModels;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x0200022A RID: 554
	public static class CalibHandEyeConfigStorageService
	{
		// Token: 0x17000952 RID: 2386
		// (get) Token: 0x06001F4A RID: 8010 RVA: 0x000B6DAA File Offset: 0x000B4FAA
		// (set) Token: 0x06001F4B RID: 8011 RVA: 0x000B6DB1 File Offset: 0x000B4FB1
		public static string LastSavePath { get; private set; }

		// Token: 0x17000953 RID: 2387
		// (get) Token: 0x06001F4C RID: 8012 RVA: 0x000B6DB9 File Offset: 0x000B4FB9
		// (set) Token: 0x06001F4D RID: 8013 RVA: 0x000B6DC0 File Offset: 0x000B4FC0
		public static string LastLoadPath { get; private set; }

		// Token: 0x06001F4E RID: 8014 RVA: 0x000B6DC8 File Offset: 0x000B4FC8
		public static string GetConfigPath()
		{
			string modelName = CalibHandEyeConfigStorageService.GetCurrentModelName();
			bool flag = string.IsNullOrWhiteSpace(modelName);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string folder = Path.Combine(Manager_path._dataPath, RecipePathService.MakeSafeFileName(modelName));
				Directory.CreateDirectory(folder);
				result = Path.Combine(folder, "calib_hand_eye_config.json");
			}
			return result;
		}

		// Token: 0x06001F4F RID: 8015 RVA: 0x000B6E14 File Offset: 0x000B5014
		public static CalibHandEyeConfigData Load()
		{
			string path = CalibHandEyeConfigStorageService.GetConfigPath();
			CalibHandEyeConfigStorageService.LastLoadPath = path;
			bool flag = string.IsNullOrWhiteSpace(path) || !File.Exists(path);
			CalibHandEyeConfigData result;
			if (flag)
			{
				result = new CalibHandEyeConfigData();
			}
			else
			{
				string json = File.ReadAllText(path);
				bool flag2 = string.IsNullOrWhiteSpace(json);
				if (flag2)
				{
					result = new CalibHandEyeConfigData();
				}
				else
				{
					result = (JsonConvert.DeserializeObject<CalibHandEyeConfigData>(json) ?? new CalibHandEyeConfigData());
				}
			}
			return result;
		}

		// Token: 0x06001F50 RID: 8016 RVA: 0x000B6E80 File Offset: 0x000B5080
		public static bool Save(CalibHandEyeSetting setting)
		{
			string path = CalibHandEyeConfigStorageService.GetConfigPath();
			bool flag = string.IsNullOrWhiteSpace(path) || setting == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string folder = Path.GetDirectoryName(path);
				bool flag2 = !string.IsNullOrWhiteSpace(folder);
				if (flag2)
				{
					Directory.CreateDirectory(folder);
				}
				CalibHandEyeConfigData data = new CalibHandEyeConfigData
				{
					CameraName = setting.CameraName,
					MasterToolName = setting.MasterToolName,
					CommunicationName = setting.CommunicationName,
					CalibrationPoints = setting.CalibrationPoints,
					RotationPointCount = setting.RotationPointCount
				};
				File.WriteAllText(path, JsonConvert.SerializeObject(data, Formatting.Indented));
				CalibHandEyeConfigStorageService.LastSavePath = path;
				result = true;
			}
			return result;
		}

		// Token: 0x06001F51 RID: 8017 RVA: 0x000B6F30 File Offset: 0x000B5130
		private static string GetCurrentModelName()
		{
			ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
			return (currentModel != null) ? currentModel.Model_name : null;
		}

		// Token: 0x04000CFE RID: 3326
		private const string FileName = "calib_hand_eye_config.json";
	}
}
