﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using VisionMachine.Models.Communication;
using VisionMachine.Services.Communication;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x0200022C RID: 556
	public static class CalibHandEyeControlService
	{
		// Token: 0x06001F5D RID: 8029 RVA: 0x000B6FE4 File Offset: 0x000B51E4
		public static bool TryWriteStop()
		{
			bool result;
			try
			{
				CalibHandEyeConfigData setting = CalibHandEyeConfigStorageService.Load();
				string connectionName = (setting != null) ? setting.CommunicationName : null;
				bool flag = string.IsNullOrWhiteSpace(connectionName) || string.Equals(connectionName, "None", StringComparison.OrdinalIgnoreCase);
				if (flag)
				{
					result = false;
				}
				else
				{
					CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(null);
					List<CommunicationConnection> connections = config.Connections;
					CommunicationConnection connection = (connections != null) ? connections.FirstOrDefault((CommunicationConnection x) => string.Equals(x.Name, connectionName, StringComparison.OrdinalIgnoreCase)) : null;
					bool flag2 = connection == null;
					if (flag2)
					{
						result = false;
					}
					else
					{
						CommunicationTagRow tag = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name).FirstOrDefault((CommunicationTagRow x) => CalibHandEyeControlService.NormalizeTagName(x.Name) == CalibHandEyeControlService.NormalizeTagName("calibration start"));
						bool flag3 = tag == null || string.IsNullOrWhiteSpace(tag.Address);
						if (flag3)
						{
							result = false;
						}
						else
						{
							PlcCommunicationService service = SharedCommunicationService.Instance;
							CommunicationOperationResult connectResult = service.ConnectIfDisconnected(connection);
							bool flag4 = !connectResult.Success;
							if (flag4)
							{
								VisionLogService.Log("Warn", "Calibration reset to Stop skipped: PLC connect failed (" + connectResult.Message + ").");
								result = false;
							}
							else
							{
								CommunicationOperationResult writeResult = service.Write(connection, tag.Address, string.IsNullOrWhiteSpace(tag.DataType) ? "INT16" : tag.DataType, "0");
								bool success = writeResult.Success;
								if (success)
								{
									VisionLogService.Log("Info", "Calibration mode reset to Stop on startup (" + connection.Name + ").");
									result = true;
								}
								else
								{
									VisionLogService.Log("Warn", "Calibration reset to Stop failed: " + writeResult.Message);
									result = false;
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				VisionLogService.Log("Warn", "Calibration reset to Stop failed: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06001F5E RID: 8030 RVA: 0x000B71E0 File Offset: 0x000B53E0
		public static bool TryWritePointCounts()
		{
			bool result;
			try
			{
				CalibHandEyeConfigData setting = CalibHandEyeConfigStorageService.Load();
				bool flag = setting == null;
				if (flag)
				{
					result = false;
				}
				else
				{
					CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(null);
					List<CommunicationConnection> connections = (config != null) ? config.Connections : null;
					bool flag2 = connections == null || connections.Count == 0;
					if (flag2)
					{
						result = false;
					}
					else
					{
						CommunicationConnection connection = connections.FirstOrDefault((CommunicationConnection x) => !string.IsNullOrWhiteSpace(setting.CommunicationName) && !string.Equals(setting.CommunicationName, "None", StringComparison.OrdinalIgnoreCase) && string.Equals(x.Name, setting.CommunicationName, StringComparison.OrdinalIgnoreCase));
						CommunicationTagRow positionTag = null;
						CommunicationTagRow rotationTag = null;
						bool flag3 = connection != null;
						if (flag3)
						{
							CalibHandEyeControlService.FindPointTags(config, connection, out positionTag, out rotationTag);
						}
						bool flag4 = positionTag == null && rotationTag == null;
						if (flag4)
						{
							foreach (CommunicationConnection candidate in connections)
							{
								CommunicationTagRow p;
								CommunicationTagRow r;
								CalibHandEyeControlService.FindPointTags(config, candidate, out p, out r);
								bool flag5 = p != null || r != null;
								if (flag5)
								{
									connection = candidate;
									positionTag = p;
									rotationTag = r;
									break;
								}
							}
						}
						bool flag6 = connection == null || (positionTag == null && rotationTag == null);
						if (flag6)
						{
							result = false;
						}
						else
						{
							PlcCommunicationService service = SharedCommunicationService.Instance;
							CommunicationOperationResult connectResult = service.ConnectIfDisconnected(connection);
							bool flag7 = !connectResult.Success;
							if (flag7)
							{
								VisionLogService.Log("Warn", "Calibration point counts not sent: PLC connect failed (" + connectResult.Message + ").");
								result = false;
							}
							else
							{
								bool wrote = false;
								wrote |= CalibHandEyeControlService.WritePointTag(service, connection, positionTag, Math.Max(0, setting.CalibrationPoints), "position");
								wrote |= CalibHandEyeControlService.WritePointTag(service, connection, rotationTag, Math.Max(0, setting.RotationPointCount), "rotation");
								bool flag8 = wrote;
								if (flag8)
								{
									VisionLogService.Log("Info", string.Concat(new string[]
									{
										"Calibration point counts sent to '",
										connection.Name,
										"': position=",
										setting.CalibrationPoints.ToString(),
										", rotation=",
										setting.RotationPointCount.ToString(),
										"."
									}));
								}
								result = wrote;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				VisionLogService.Log("Warn", "Calibration point counts write failed: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06001F5F RID: 8031 RVA: 0x000B7478 File Offset: 0x000B5678
		private static void FindPointTags(CommunicationConfigData config, CommunicationConnection connection, out CommunicationTagRow positionTag, out CommunicationTagRow rotationTag)
		{
			positionTag = null;
			rotationTag = null;
			List<CommunicationTagRow> tags = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name);
			foreach (CommunicationTagRow tag in tags)
			{
				bool flag = tag == null || string.IsNullOrWhiteSpace(tag.Address);
				if (!flag)
				{
					string normalized = CalibHandEyeControlService.NormalizeTagName(tag.Name);
					bool flag2 = positionTag == null && normalized == CalibHandEyeControlService.NormalizeTagName("calibration position point");
					if (flag2)
					{
						positionTag = tag;
					}
					else
					{
						bool flag3 = rotationTag == null && normalized == CalibHandEyeControlService.NormalizeTagName("calibration rotation point");
						if (flag3)
						{
							rotationTag = tag;
						}
					}
				}
			}
		}

		// Token: 0x06001F60 RID: 8032 RVA: 0x000B7540 File Offset: 0x000B5740
		private static bool WritePointTag(PlcCommunicationService service, CommunicationConnection connection, CommunicationTagRow tag, int value, string label)
		{
			bool flag = tag == null || string.IsNullOrWhiteSpace(tag.Address);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				CommunicationOperationResult writeResult = service.Write(connection, tag.Address, string.IsNullOrWhiteSpace(tag.DataType) ? "INT16" : tag.DataType, value.ToString(CultureInfo.InvariantCulture));
				bool flag2 = !writeResult.Success;
				if (flag2)
				{
					VisionLogService.Log("Warn", string.Concat(new string[]
					{
						"Calibration ",
						label,
						" point write failed @",
						tag.Address,
						": ",
						writeResult.Message
					}));
					result = false;
				}
				else
				{
					result = true;
				}
			}
			return result;
		}

		// Token: 0x06001F61 RID: 8033 RVA: 0x000B75FC File Offset: 0x000B57FC
		private static string NormalizeTagName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				result = new string(name.Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
			}
			return result;
		}

		// Token: 0x04000D06 RID: 3334
		private const string CalibrationStartTagName = "calibration start";
	}
}
