﻿using System;
using System.Globalization;
using System.IO;
using System.Text;
using HalconDotNet;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x0200022D RID: 557
	public static class CalibHandEyeExportService
	{
		// Token: 0x06001F62 RID: 8034 RVA: 0x000B7644 File Offset: 0x000B5844
		public static void Export(TcpCalibrationResult result, string datPath)
		{
			bool flag = result == null || !result.IsSuccess;
			if (flag)
			{
				throw new InvalidOperationException("Calibration result is not valid for export.");
			}
			bool flag2 = string.IsNullOrWhiteSpace(datPath);
			if (flag2)
			{
				throw new ArgumentException("Export path is empty.", "datPath");
			}
			HandEyeCalibrationResult mapping = result.Mapping ?? HandEyeCalibrationResult.Failed("missing");
			double[] hom = mapping.HomMat2D ?? new double[6];
			bool flag3 = hom.Length < 6;
			if (flag3)
			{
				hom = new double[6];
			}
			string folder = Path.GetDirectoryName(datPath);
			bool flag4 = !string.IsNullOrWhiteSpace(folder);
			if (flag4)
			{
				Directory.CreateDirectory(folder);
			}
			double[] values = new double[]
			{
				2.0,
				(double)mapping.PointCount,
				(double)result.RotationPointCount,
				hom[0],
				hom[1],
				hom[2],
				hom[3],
				hom[4],
				hom[5],
				mapping.PixelSizeX,
				mapping.PixelSizeY,
				mapping.RotationDeg,
				mapping.RmsErrorMm,
				mapping.ReprojectionErrorPx,
				result.CircleCenterImageX,
				result.CircleCenterImageY,
				result.CircleRadiusPx,
				result.CircleFitRmsPx,
				result.CircleCenterRobotX,
				result.CircleCenterRobotY,
				result.RadiusMm,
				result.FlangeMeanX,
				result.FlangeMeanY,
				result.TcpOffsetBaseX,
				result.TcpOffsetBaseY,
				result.TcpOffsetMagnitude,
				result.TcpOffsetToolX,
				result.TcpOffsetToolY,
				result.ReferenceRotationRz,
				result.ObservedMeanRobotX,
				result.ObservedMeanRobotY,
				mapping.AngleOffsetDeg,
				(double)(result.TcpAppliedToMapping ? 1 : 0),
				result.ReferenceImageX,
				result.ReferenceImageY,
				result.ReferenceVisionAngle,
				result.MappingVisionAngle
			};
			HTuple tuple = new HTuple(values);
			HOperatorSet.WriteTuple(tuple, datPath);
			CalibHandEyeExportService.WriteReadme(result, mapping, hom, datPath);
		}

		// Token: 0x06001F63 RID: 8035 RVA: 0x000B7870 File Offset: 0x000B5A70
		private static void WriteReadme(TcpCalibrationResult result, HandEyeCalibrationResult mapping, double[] hom, string datPath)
		{
			string txtPath = Path.ChangeExtension(datPath, ".txt");
			CultureInfo c = CultureInfo.InvariantCulture;
			StringBuilder sb = new StringBuilder();
			sb.AppendLine("# VisionMachine Hand-Eye / TCP calibration");
			sb.AppendLine("# .dat is a Halcon tuple file (read with read_tuple).");
			sb.AppendLine("# FormatVersion: " + 2.ToString(CultureInfo.InvariantCulture));
			sb.AppendLine("# Created: " + result.CreatedAt);
			sb.AppendLine();
			sb.AppendLine("[Step 1 - Mapping image->robot affine]");
			sb.AppendLine("MappingPoints      = " + mapping.PointCount.ToString(c));
			sb.AppendLine(string.Format(c, "HomMat2D           = [{0:0.########}, {1:0.########}, {2:0.########}, {3:0.########}, {4:0.########}, {5:0.########}]", new object[]
			{
				hom[0],
				hom[1],
				hom[2],
				hom[3],
				hom[4],
				hom[5]
			}));
			sb.AppendLine(string.Format(c, "PixelSizeX(mm/px)  = {0:0.########}", mapping.PixelSizeX));
			sb.AppendLine(string.Format(c, "PixelSizeY(mm/px)  = {0:0.########}", mapping.PixelSizeY));
			sb.AppendLine(string.Format(c, "Rotation(deg)      = {0:0.######}", mapping.RotationDeg));
			sb.AppendLine(string.Format(c, "AngleOffset(deg)   = {0:0.######}", mapping.AngleOffsetDeg));
			sb.AppendLine(string.Format(c, "MappingRMS(mm)     = {0:0.######}", mapping.RmsErrorMm));
			sb.AppendLine(string.Format(c, "Reprojection(px)   = {0:0.######}", mapping.ReprojectionErrorPx));
			sb.AppendLine();
			sb.AppendLine("[Step 2 - TCP from rotation circle]");
			sb.AppendLine("RotationPoints     = " + result.RotationPointCount.ToString(c));
			sb.AppendLine(string.Format(c, "CircleCenterImage  = ({0:0.###}, {1:0.###}) px", result.CircleCenterImageX, result.CircleCenterImageY));
			sb.AppendLine(string.Format(c, "CircleRadius(px)   = {0:0.###}", result.CircleRadiusPx));
			sb.AppendLine(string.Format(c, "CircleFitRMS(px)   = {0:0.###}", result.CircleFitRmsPx));
			sb.AppendLine(string.Format(c, "CircleCenterRobot  = ({0:0.###}, {1:0.###}) mm", result.CircleCenterRobotX, result.CircleCenterRobotY));
			sb.AppendLine("# CircleCenterRobot is the mean Robot X/Y from the rotation rows, i.e. the real TCP robot center.");
			sb.AppendLine(string.Format(c, "FlangeMean(mm)     = ({0:0.###}, {1:0.###})", result.FlangeMeanX, result.FlangeMeanY));
			sb.AppendLine("# FlangeMean is the average Robot X/Y read from the rotation rows.");
			sb.AppendLine("# It only changes when the robot X/Y values of those rows change.");
			sb.AppendLine(string.Format(c, "ObservedMeanRobot  = ({0:0.###}, {1:0.###}) mm", result.ObservedMeanRobotX, result.ObservedMeanRobotY));
			sb.AppendLine("# ObservedMeanRobot is the average of rotation image points after image->robot mapping.");
			sb.AppendLine(string.Format(c, "ReferenceRz(deg)   = {0:0.###}", result.ReferenceRotationRz));
			sb.AppendLine(string.Format(c, "ReferencePattern   = ({0:0.###}, {1:0.###}) px", result.ReferenceImageX, result.ReferenceImageY));
			sb.AppendLine(string.Format(c, "ReferenceVisionA   = {0:0.###} deg", result.ReferenceVisionAngle));
			sb.AppendLine(string.Format(c, "MappingVisionA     = {0:0.###} deg", result.MappingVisionAngle));
			sb.AppendLine("# MappingVisionA is the pattern orientation over the 9 mapping rows. A runtime");
			sb.AppendLine("# part detected at this angle gets zero TCP offset correction.");
			sb.AppendLine("TcpAppliedToMapping= " + (result.TcpAppliedToMapping ? "true" : "false"));
			sb.AppendLine();
			sb.AppendLine("[TCP offset correction to feed back to the robot tool]");
			sb.AppendLine(string.Format(c, "OffsetBase(mm)     = ({0:0.####}, {1:0.####})", result.TcpOffsetBaseX, result.TcpOffsetBaseY));
			sb.AppendLine(string.Format(c, "OffsetTool(mm)     = ({0:0.####}, {1:0.####})", result.TcpOffsetToolX, result.TcpOffsetToolY));
			sb.AppendLine(string.Format(c, "OffsetMagnitude(mm)= {0:0.####}", result.TcpOffsetMagnitude));
			File.WriteAllText(txtPath, sb.ToString());
		}

		// Token: 0x04000D07 RID: 3335
		private const int FormatVersion = 2;
	}
}
