﻿using System;
using System.Collections.Generic;
using VisionMachine.Views.Calibration.ViewModels;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x0200022F RID: 559
	public class CalibHandEyePointsData
	{
		// Token: 0x1700095B RID: 2395
		// (get) Token: 0x06001F6B RID: 8043 RVA: 0x000B7E04 File Offset: 0x000B6004
		// (set) Token: 0x06001F6C RID: 8044 RVA: 0x000B7E0C File Offset: 0x000B600C
		public List<RobotPoseRow> RobotPoints { get; set; } = new List<RobotPoseRow>();

		// Token: 0x1700095C RID: 2396
		// (get) Token: 0x06001F6D RID: 8045 RVA: 0x000B7E15 File Offset: 0x000B6015
		// (set) Token: 0x06001F6E RID: 8046 RVA: 0x000B7E1D File Offset: 0x000B601D
		public List<VisionPointRow> VisionPoints { get; set; } = new List<VisionPointRow>();
	}
}
