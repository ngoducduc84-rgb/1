﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using VisionMachine.Helpers;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Runtime;
using VisionMachine.Views.Calibration.ViewModels;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x0200022E RID: 558
	public static class CalibHandEyePointsStorageService
	{
		// Token: 0x17000959 RID: 2393
		// (get) Token: 0x06001F64 RID: 8036 RVA: 0x000B7CA5 File Offset: 0x000B5EA5
		// (set) Token: 0x06001F65 RID: 8037 RVA: 0x000B7CAC File Offset: 0x000B5EAC
		public static string LastSavePath { get; private set; }

		// Token: 0x1700095A RID: 2394
		// (get) Token: 0x06001F66 RID: 8038 RVA: 0x000B7CB4 File Offset: 0x000B5EB4
		// (set) Token: 0x06001F67 RID: 8039 RVA: 0x000B7CBB File Offset: 0x000B5EBB
		public static string LastLoadPath { get; private set; }

		// Token: 0x06001F68 RID: 8040 RVA: 0x000B7CC4 File Offset: 0x000B5EC4
		public static string GetPath()
		{
			ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
			string modelName = (currentModel != null) ? currentModel.Model_name : null;
			bool flag = string.IsNullOrWhiteSpace(modelName);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string folder = Path.Combine(Manager_path._dataPath, RecipePathService.MakeSafeFileName(modelName));
				Directory.CreateDirectory(folder);
				result = Path.Combine(folder, "calib_hand_eye_points.json");
			}
			return result;
		}

		// Token: 0x06001F69 RID: 8041 RVA: 0x000B7D1C File Offset: 0x000B5F1C
		public static bool Save(IEnumerable<RobotPoseRow> robotPoints, IEnumerable<VisionPointRow> visionPoints)
		{
			string path = CalibHandEyePointsStorageService.GetPath();
			bool flag = string.IsNullOrWhiteSpace(path);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string folder = Path.GetDirectoryName(path);
				bool flag2 = !string.IsNullOrWhiteSpace(folder);
				if (flag2)
				{
					Directory.CreateDirectory(folder);
				}
				CalibHandEyePointsData data = new CalibHandEyePointsData
				{
					RobotPoints = (robotPoints ?? Enumerable.Empty<RobotPoseRow>()).ToList<RobotPoseRow>(),
					VisionPoints = (visionPoints ?? Enumerable.Empty<VisionPointRow>()).ToList<VisionPointRow>()
				};
				File.WriteAllText(path, JsonConvert.SerializeObject(data, Formatting.Indented));
				CalibHandEyePointsStorageService.LastSavePath = path;
				result = true;
			}
			return result;
		}

		// Token: 0x06001F6A RID: 8042 RVA: 0x000B7DAC File Offset: 0x000B5FAC
		public static CalibHandEyePointsData Load()
		{
			string path = CalibHandEyePointsStorageService.GetPath();
			CalibHandEyePointsStorageService.LastLoadPath = path;
			bool flag = string.IsNullOrWhiteSpace(path) || !File.Exists(path);
			CalibHandEyePointsData result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string json = File.ReadAllText(path);
				bool flag2 = string.IsNullOrWhiteSpace(json);
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = JsonConvert.DeserializeObject<CalibHandEyePointsData>(json);
				}
			}
			return result;
		}

		// Token: 0x04000D08 RID: 3336
		private const string FileName = "calib_hand_eye_points.json";
	}
}
