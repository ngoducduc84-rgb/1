﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000230 RID: 560
	public static class CalibHandEyeResultStorageService
	{
		// Token: 0x1700095D RID: 2397
		// (get) Token: 0x06001F70 RID: 8048 RVA: 0x000B7E45 File Offset: 0x000B6045
		// (set) Token: 0x06001F71 RID: 8049 RVA: 0x000B7E4C File Offset: 0x000B604C
		public static string LastSavePath { get; private set; }

		// Token: 0x1700095E RID: 2398
		// (get) Token: 0x06001F72 RID: 8050 RVA: 0x000B7E54 File Offset: 0x000B6054
		// (set) Token: 0x06001F73 RID: 8051 RVA: 0x000B7E5B File Offset: 0x000B605B
		public static string LastLoadPath { get; private set; }

		// Token: 0x06001F74 RID: 8052 RVA: 0x000B7E64 File Offset: 0x000B6064
		public static string GetResultPath()
		{
			ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
			string modelName = (currentModel != null) ? currentModel.Model_name : null;
			bool flag = string.IsNullOrWhiteSpace(modelName);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string folder = Path.Combine(Manager_path._dataPath, RecipePathService.MakeSafeFileName(modelName));
				Directory.CreateDirectory(folder);
				result = Path.Combine(folder, "calib_hand_eye_result.json");
			}
			return result;
		}

		// Token: 0x06001F75 RID: 8053 RVA: 0x000B7EBC File Offset: 0x000B60BC
		public static bool Save(HandEyeCalibrationResult result)
		{
			string path = CalibHandEyeResultStorageService.GetResultPath();
			bool flag = string.IsNullOrWhiteSpace(path) || result == null;
			bool result2;
			if (flag)
			{
				result2 = false;
			}
			else
			{
				string folder = Path.GetDirectoryName(path);
				bool flag2 = !string.IsNullOrWhiteSpace(folder);
				if (flag2)
				{
					Directory.CreateDirectory(folder);
				}
				File.WriteAllText(path, JsonConvert.SerializeObject(result, Formatting.Indented));
				CalibHandEyeResultStorageService.LastSavePath = path;
				result2 = true;
			}
			return result2;
		}

		// Token: 0x06001F76 RID: 8054 RVA: 0x000B7F20 File Offset: 0x000B6120
		public static HandEyeCalibrationResult Load()
		{
			string path = CalibHandEyeResultStorageService.GetResultPath();
			CalibHandEyeResultStorageService.LastLoadPath = path;
			bool flag = string.IsNullOrWhiteSpace(path) || !File.Exists(path);
			HandEyeCalibrationResult result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string json = File.ReadAllText(path);
				bool flag2 = string.IsNullOrWhiteSpace(json);
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = JsonConvert.DeserializeObject<HandEyeCalibrationResult>(json);
				}
			}
			return result;
		}

		// Token: 0x04000D0D RID: 3341
		private const string FileName = "calib_hand_eye_result.json";
	}
}
