﻿using System;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000232 RID: 562
	public class CalibHandEyeWorkflowPointResult
	{
		// Token: 0x17000965 RID: 2405
		// (get) Token: 0x06001FB3 RID: 8115 RVA: 0x000BAA5E File Offset: 0x000B8C5E
		// (set) Token: 0x06001FB4 RID: 8116 RVA: 0x000BAA66 File Offset: 0x000B8C66
		public int Index { get; set; }

		// Token: 0x17000966 RID: 2406
		// (get) Token: 0x06001FB5 RID: 8117 RVA: 0x000BAA6F File Offset: 0x000B8C6F
		// (set) Token: 0x06001FB6 RID: 8118 RVA: 0x000BAA77 File Offset: 0x000B8C77
		public double RobotX { get; set; }

		// Token: 0x17000967 RID: 2407
		// (get) Token: 0x06001FB7 RID: 8119 RVA: 0x000BAA80 File Offset: 0x000B8C80
		// (set) Token: 0x06001FB8 RID: 8120 RVA: 0x000BAA88 File Offset: 0x000B8C88
		public double RobotY { get; set; }

		// Token: 0x17000968 RID: 2408
		// (get) Token: 0x06001FB9 RID: 8121 RVA: 0x000BAA91 File Offset: 0x000B8C91
		// (set) Token: 0x06001FBA RID: 8122 RVA: 0x000BAA99 File Offset: 0x000B8C99
		public double RobotRz { get; set; }

		// Token: 0x17000969 RID: 2409
		// (get) Token: 0x06001FBB RID: 8123 RVA: 0x000BAAA2 File Offset: 0x000B8CA2
		// (set) Token: 0x06001FBC RID: 8124 RVA: 0x000BAAAA File Offset: 0x000B8CAA
		public double RobotQuality { get; set; }

		// Token: 0x1700096A RID: 2410
		// (get) Token: 0x06001FBD RID: 8125 RVA: 0x000BAAB3 File Offset: 0x000B8CB3
		// (set) Token: 0x06001FBE RID: 8126 RVA: 0x000BAABB File Offset: 0x000B8CBB
		public double VisionX { get; set; }

		// Token: 0x1700096B RID: 2411
		// (get) Token: 0x06001FBF RID: 8127 RVA: 0x000BAAC4 File Offset: 0x000B8CC4
		// (set) Token: 0x06001FC0 RID: 8128 RVA: 0x000BAACC File Offset: 0x000B8CCC
		public double VisionY { get; set; }

		// Token: 0x1700096C RID: 2412
		// (get) Token: 0x06001FC1 RID: 8129 RVA: 0x000BAAD5 File Offset: 0x000B8CD5
		// (set) Token: 0x06001FC2 RID: 8130 RVA: 0x000BAADD File Offset: 0x000B8CDD
		public double VisionAngle { get; set; }

		// Token: 0x1700096D RID: 2413
		// (get) Token: 0x06001FC3 RID: 8131 RVA: 0x000BAAE6 File Offset: 0x000B8CE6
		// (set) Token: 0x06001FC4 RID: 8132 RVA: 0x000BAAEE File Offset: 0x000B8CEE
		public double Score { get; set; }

		// Token: 0x1700096E RID: 2414
		// (get) Token: 0x06001FC5 RID: 8133 RVA: 0x000BAAF7 File Offset: 0x000B8CF7
		// (set) Token: 0x06001FC6 RID: 8134 RVA: 0x000BAAFF File Offset: 0x000B8CFF
		public bool IsSuccess { get; set; }

		// Token: 0x1700096F RID: 2415
		// (get) Token: 0x06001FC7 RID: 8135 RVA: 0x000BAB08 File Offset: 0x000B8D08
		// (set) Token: 0x06001FC8 RID: 8136 RVA: 0x000BAB10 File Offset: 0x000B8D10
		public string Message { get; set; }
	}
}
