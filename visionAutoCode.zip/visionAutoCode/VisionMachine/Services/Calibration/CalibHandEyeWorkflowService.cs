﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using HalconDotNet;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Communication;
using VisionMachine.Models.Recipe;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Communication;
using VisionMachine.Services.Recipe;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Calibration.ViewModels;
using VisionMachine.Views.Main;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000231 RID: 561
	public sealed class CalibHandEyeWorkflowService : IDisposable
	{
		// Token: 0x1700095F RID: 2399
		// (get) Token: 0x06001F77 RID: 8055 RVA: 0x000B7F78 File Offset: 0x000B6178
		// (set) Token: 0x06001F78 RID: 8056 RVA: 0x000B7F80 File Offset: 0x000B6180
		public Action<HObject> ImageCaptured { get; set; }

		// Token: 0x17000960 RID: 2400
		// (get) Token: 0x06001F79 RID: 8057 RVA: 0x000B7F89 File Offset: 0x000B6189
		// (set) Token: 0x06001F7A RID: 8058 RVA: 0x000B7F91 File Offset: 0x000B6191
		public Action<CalibHandEyeWorkflowPointResult> RobotPoseRead { get; set; }

		// Token: 0x17000961 RID: 2401
		// (get) Token: 0x06001F7B RID: 8059 RVA: 0x000B7F9A File Offset: 0x000B619A
		// (set) Token: 0x06001F7C RID: 8060 RVA: 0x000B7FA2 File Offset: 0x000B61A2
		public Action<CalibHandEyeWorkflowPointResult> PointCompleted { get; set; }

		// Token: 0x17000962 RID: 2402
		// (get) Token: 0x06001F7D RID: 8061 RVA: 0x000B7FAB File Offset: 0x000B61AB
		// (set) Token: 0x06001F7E RID: 8062 RVA: 0x000B7FB3 File Offset: 0x000B61B3
		public Action<HandEyeCalibrationResult> CalibrationCompleted { get; set; }

		// Token: 0x17000963 RID: 2403
		// (get) Token: 0x06001F7F RID: 8063 RVA: 0x000B7FBC File Offset: 0x000B61BC
		// (set) Token: 0x06001F80 RID: 8064 RVA: 0x000B7FC4 File Offset: 0x000B61C4
		public Action<int, string, string, string, string> Log { get; set; }

		// Token: 0x17000964 RID: 2404
		// (get) Token: 0x06001F81 RID: 8065 RVA: 0x000B7FCD File Offset: 0x000B61CD
		// (set) Token: 0x06001F82 RID: 8066 RVA: 0x000B7FD5 File Offset: 0x000B61D5
		public Action<string> StatusChanged { get; set; }

		// Token: 0x06001F83 RID: 8067 RVA: 0x000B7FE0 File Offset: 0x000B61E0
		public Task RunAsync(CalibHandEyeSetting setting, CancellationToken cancellationToken)
		{
			return Task.Run(delegate()
			{
				this.Run(setting, cancellationToken);
			}, cancellationToken);
		}

		// Token: 0x06001F84 RID: 8068 RVA: 0x000B8024 File Offset: 0x000B6224
		public CalibHandEyeWorkflowPointResult CaptureOnce(CalibHandEyeSetting setting)
		{
			return this.CaptureOnce(setting, 1);
		}

		// Token: 0x06001F85 RID: 8069 RVA: 0x000B8040 File Offset: 0x000B6240
		public CalibHandEyeWorkflowPointResult CaptureOnce(CalibHandEyeSetting setting, int pointIndex)
		{
			CalibHandEyeWorkflowService.WorkflowContext context = CalibHandEyeWorkflowService.BuildVisionOnlyContext(setting);
			return this.ProcessPoint(context, pointIndex, CancellationToken.None, null);
		}

		// Token: 0x06001F86 RID: 8070 RVA: 0x000B8068 File Offset: 0x000B6268
		private void Run(CalibHandEyeSetting setting, CancellationToken cancellationToken)
		{
			CalibHandEyeWorkflowService.WorkflowContext context = this.BuildContext(setting);
			int pointIndex = 1;
			int totalPointCount = CalibHandEyeWorkflowService.GetTotalPointCount(setting);
			bool lastSnap = false;
			bool snapInitialized = false;
			bool snapWasOffAfterStart = false;
			bool snapStateLogged = false;
			string lastSnapReadError = null;
			this._samples.Clear();
			this.RegisterHardwareTriggerSession(context);
			try
			{
				this.WriteTag(context, "vision busy", 0);
				this.WriteTag(context, "vision capture done", 0);
				this.WriteTag(context, "robot next point", 0);
				this.WriteTag(context, "vision error code", 0);
				this.WriteTag(context, "calibration result valid", 0);
				this.WriteTag(context, "calibration position point", Math.Max(0, (setting != null) ? setting.CalibrationPoints : 0));
				this.WriteTag(context, "calibration rotation point", Math.Max(0, (setting != null) ? setting.RotationPointCount : 0));
				this.SetStatus("Waiting robot trigger.");
				this.AddLog(0, "Start", context.Connection.Name, "Running", "Calibration workflow started.");
				this.LogTriggerSetup(context);
				while (!cancellationToken.IsCancellationRequested && pointIndex <= totalPointCount)
				{
					HObject hardwareFrame = this.TakePendingHardwareFrame();
					bool flag = hardwareFrame != null;
					if (flag)
					{
						try
						{
							this.AddLog(pointIndex, "Trigger Capture", "hardware trigger", "Running", "Hardware trigger frame received. Capturing calibration point.");
							CalibHandEyeWorkflowPointResult hardwareResult = this.ProcessPoint(context, pointIndex, cancellationToken, hardwareFrame);
							Action<CalibHandEyeWorkflowPointResult> hardwareHandler = this.PointCompleted;
							bool flag2 = hardwareHandler != null;
							if (flag2)
							{
								hardwareHandler(hardwareResult);
							}
							bool isSuccess = hardwareResult.IsSuccess;
							if (isSuccess)
							{
								this._samples.Add(CalibHandEyeWorkflowService.ToSamplePoint(hardwareResult));
							}
							pointIndex++;
						}
						finally
						{
							hardwareFrame.Dispose();
						}
						snapWasOffAfterStart = false;
						lastSnap = false;
						bool flag3 = pointIndex > totalPointCount;
						if (flag3)
						{
							break;
						}
					}
					else
					{
						CalibHandEyeWorkflowService.TagReadValue completeRead = this.ReadSingleTag(context, "calibration complete", cancellationToken);
						bool isCanceled = completeRead.IsCanceled;
						if (isCanceled)
						{
							return;
						}
						bool complete = completeRead.Success && CalibHandEyeWorkflowService.IsTrue(completeRead.Value);
						CalibHandEyeWorkflowService.TagReadValue snapRead = this.ReadSingleTag(context, "calibration snap", cancellationToken);
						bool isCanceled2 = snapRead.IsCanceled;
						if (isCanceled2)
						{
							return;
						}
						bool flag4 = !snapRead.Success;
						if (flag4)
						{
							bool flag5 = !string.Equals(lastSnapReadError, snapRead.Message, StringComparison.OrdinalIgnoreCase);
							if (flag5)
							{
								lastSnapReadError = snapRead.Message;
								this.AddLog(pointIndex, "Read Trigger", "calibration snap", "Fail", snapRead.Message);
							}
							bool flag6 = !CalibHandEyeWorkflowService.WaitPollInterval(context.PollIntervalMs, cancellationToken);
							if (flag6)
							{
								return;
							}
						}
						else
						{
							lastSnapReadError = null;
							string snapValue = snapRead.Value;
							bool snap = CalibHandEyeWorkflowService.IsTrue(snapValue);
							bool flag7 = !snapStateLogged || snap != lastSnap;
							if (flag7)
							{
								snapStateLogged = true;
								this.AddLog(pointIndex, "Read Trigger", "calibration snap", snap ? "ON" : "OFF", "Calibration snap value = " + (snapValue ?? "<null>"));
							}
							bool flag8 = !snapInitialized;
							if (flag8)
							{
								snapInitialized = true;
								lastSnap = snap;
								snapWasOffAfterStart = !snap;
							}
							bool flag9 = !snap;
							if (flag9)
							{
								snapWasOffAfterStart = true;
							}
							bool flag10 = snapWasOffAfterStart && snap && !lastSnap;
							if (flag10)
							{
								this.AddLog(pointIndex, "Trigger Capture", "calibration snap", "Running", "Rising edge detected. Capturing calibration point.");
								CalibHandEyeWorkflowPointResult pointResult = this.ProcessPoint(context, pointIndex, cancellationToken, null);
								Action<CalibHandEyeWorkflowPointResult> handler = this.PointCompleted;
								bool flag11 = handler != null;
								if (flag11)
								{
									handler(pointResult);
								}
								bool isSuccess2 = pointResult.IsSuccess;
								if (isSuccess2)
								{
									this._samples.Add(CalibHandEyeWorkflowService.ToSamplePoint(pointResult));
								}
								pointIndex++;
								snapWasOffAfterStart = false;
							}
							else
							{
								bool flag12 = complete;
								if (flag12)
								{
									this.AddLog(pointIndex, "Complete", "calibration complete", "Success", "Robot completed calibration.");
									break;
								}
							}
							lastSnap = snap;
							bool flag13 = !CalibHandEyeWorkflowService.WaitPollInterval(context.PollIntervalMs, cancellationToken);
							if (flag13)
							{
								return;
							}
						}
					}
				}
				bool isCancellationRequested = cancellationToken.IsCancellationRequested;
				if (!isCancellationRequested)
				{
					bool flag14 = pointIndex > totalPointCount;
					if (flag14)
					{
						this.AddLog(0, "Complete", "calibration points", "Success", string.Format("Captured {0} calibration point(s).", totalPointCount));
					}
					this.FinalizeCalibration(context, setting);
				}
			}
			finally
			{
				this.UnregisterHardwareTriggerSession();
				this._plcService.Disconnect(context.Connection);
			}
		}

		// Token: 0x06001F87 RID: 8071 RVA: 0x000B8514 File Offset: 0x000B6714
		private void RegisterHardwareTriggerSession(CalibHandEyeWorkflowService.WorkflowContext context)
		{
			string hardwareCameraName;
			if (context == null)
			{
				hardwareCameraName = null;
			}
			else
			{
				CameraNode camera = context.Camera;
				if (camera == null)
				{
					hardwareCameraName = null;
				}
				else
				{
					CameraItem cameraInfo = camera.CameraInfo;
					hardwareCameraName = ((cameraInfo != null) ? cameraInfo.CameraName : null);
				}
			}
			this._hardwareCameraName = hardwareCameraName;
			string hardwareCameraNodeName;
			if (context == null)
			{
				hardwareCameraNodeName = null;
			}
			else
			{
				CameraNode camera2 = context.Camera;
				hardwareCameraNodeName = ((camera2 != null) ? camera2.Name : null);
			}
			this._hardwareCameraNodeName = hardwareCameraNodeName;
			object hardwareSessionLock = CalibHandEyeWorkflowService.HardwareSessionLock;
			lock (hardwareSessionLock)
			{
				CalibHandEyeWorkflowService._activeHardwareSession = this;
			}
		}

		// Token: 0x06001F88 RID: 8072 RVA: 0x000B85A0 File Offset: 0x000B67A0
		private void UnregisterHardwareTriggerSession()
		{
			object hardwareSessionLock = CalibHandEyeWorkflowService.HardwareSessionLock;
			lock (hardwareSessionLock)
			{
				bool flag2 = CalibHandEyeWorkflowService._activeHardwareSession == this;
				if (flag2)
				{
					CalibHandEyeWorkflowService._activeHardwareSession = null;
				}
			}
			HObject leftover = this.TakePendingHardwareFrame();
			try
			{
				if (leftover != null)
				{
					leftover.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001F89 RID: 8073 RVA: 0x000B8618 File Offset: 0x000B6818
		public static bool TryConsumeHardwareTriggerFrame(string cameraName, HObject image)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraName) || image == null || !image.IsInitialized();
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				object hardwareSessionLock = CalibHandEyeWorkflowService.HardwareSessionLock;
				CalibHandEyeWorkflowService session;
				lock (hardwareSessionLock)
				{
					session = CalibHandEyeWorkflowService._activeHardwareSession;
				}
				bool flag3 = session == null || !session.MatchesHardwareCamera(cameraName);
				result = (!flag3 && session.EnqueueHardwareFrame(image));
			}
			return result;
		}

		// Token: 0x06001F8A RID: 8074 RVA: 0x000B86A4 File Offset: 0x000B68A4
		private bool MatchesHardwareCamera(string cameraName)
		{
			return string.Equals(cameraName, this._hardwareCameraName, StringComparison.OrdinalIgnoreCase) || string.Equals(cameraName, this._hardwareCameraNodeName, StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001F8B RID: 8075 RVA: 0x000B86D8 File Offset: 0x000B68D8
		private bool EnqueueHardwareFrame(HObject image)
		{
			HObject copy;
			try
			{
				HOperatorSet.CopyImage(image, out copy);
			}
			catch
			{
				return false;
			}
			object hardwareFrameLock = this._hardwareFrameLock;
			lock (hardwareFrameLock)
			{
				try
				{
					HObject pendingHardwareFrame = this._pendingHardwareFrame;
					if (pendingHardwareFrame != null)
					{
						pendingHardwareFrame.Dispose();
					}
				}
				catch
				{
				}
				this._pendingHardwareFrame = copy;
			}
			return true;
		}

		// Token: 0x06001F8C RID: 8076 RVA: 0x000B876C File Offset: 0x000B696C
		private HObject TakePendingHardwareFrame()
		{
			object hardwareFrameLock = this._hardwareFrameLock;
			HObject result;
			lock (hardwareFrameLock)
			{
				HObject frame = this._pendingHardwareFrame;
				this._pendingHardwareFrame = null;
				result = frame;
			}
			return result;
		}

		// Token: 0x06001F8D RID: 8077 RVA: 0x000B87BC File Offset: 0x000B69BC
		private void LogTriggerSetup(CalibHandEyeWorkflowService.WorkflowContext context)
		{
			CommunicationTagRow snapTag;
			bool flag = context == null || context.Tags == null || !context.Tags.TryGetValue(CalibHandEyeWorkflowService.NormalizeName("calibration snap"), out snapTag);
			if (flag)
			{
				this.AddLog(0, "Trigger Setup", "calibration snap", "Fail", "Calibration snap tag was not found.");
			}
			else
			{
				this.AddLog(0, "Trigger Setup", "calibration snap", "Ready", string.Format("Polling address={0}, type={1}, interval={2} ms.", snapTag.Address, snapTag.DataType, context.PollIntervalMs));
			}
		}

		// Token: 0x06001F8E RID: 8078 RVA: 0x000B8850 File Offset: 0x000B6A50
		private void FinalizeCalibration(CalibHandEyeWorkflowService.WorkflowContext context, CalibHandEyeSetting setting)
		{
			bool flag = this._samples.Count < 3;
			if (flag)
			{
				this.SetStatus("Stopped. Not enough valid points to calibrate.");
				this.AddLog(0, "Calibrate", "hand-eye solve", "Fail", string.Format("Need at least 3 valid points, collected {0}.", this._samples.Count));
				this.WriteTag(context, "calibration result valid", 0);
			}
			else
			{
				int positionCount = Math.Max(0, (setting != null) ? setting.CalibrationPoints : this._samples.Count);
				List<HandEyeSamplePoint> mappingSamples = (from s in this._samples
				where s != null && s.IsValid && s.Index <= positionCount
				select s).ToList<HandEyeSamplePoint>();
				List<HandEyeSamplePoint> rotationSamples = (from s in this._samples
				where s != null && s.IsValid && s.Index > positionCount
				select s).ToList<HandEyeSamplePoint>();
				bool flag2 = mappingSamples.Count >= 3 && rotationSamples.Count >= 3;
				HandEyeCalibrationResult result;
				if (flag2)
				{
					this.AddLog(0, "Calibrate", "tcp -> mapping", "Running", string.Format("Computing TCP from {0} rotation point(s), then mapping H from {1} point(s).", rotationSamples.Count, mappingSamples.Count));
					TcpCalibrationResult tcp = TcpCalibrationSolver.Solve(mappingSamples, rotationSamples, true);
					result = ((tcp.IsSuccess && tcp.Mapping != null) ? tcp.Mapping : HandEyeCalibrationSolver.Solve(mappingSamples));
					bool flag3 = tcp.IsSuccess && tcp.TcpAppliedToMapping;
					if (flag3)
					{
						this.AddLog(0, "Calibrate", "tcp -> mapping", "Success", string.Format("TCP applied to mapping. Reprojection {0:0.###} -> {1:0.###} px.", tcp.MappingReprojectionBeforePx, tcp.MappingReprojectionAfterPx));
					}
				}
				else
				{
					List<HandEyeSamplePoint> samplesForFit = (mappingSamples.Count >= 3) ? mappingSamples : this._samples;
					this.AddLog(0, "Calibrate", "hand-eye solve", "Running", string.Format("Solving hand-eye transform from {0} points.", samplesForFit.Count));
					result = HandEyeCalibrationSolver.Solve(samplesForFit);
				}
				this.WriteResultTags(context, result);
				this.SetStatus(result.IsSuccess ? string.Format("Calibrated. RMS {0:0.####} mm.", result.RmsErrorMm) : "Calibration failed.");
				this.AddLog(0, "Calibrate", "hand-eye solve", result.IsSuccess ? "Success" : "Fail", result.Message);
				Action<HandEyeCalibrationResult> handler = this.CalibrationCompleted;
				bool flag4 = handler != null;
				if (flag4)
				{
					handler(result);
				}
			}
		}

		// Token: 0x06001F8F RID: 8079 RVA: 0x000B8AD0 File Offset: 0x000B6CD0
		private static bool WaitPollInterval(int pollIntervalMs, CancellationToken cancellationToken)
		{
			bool isCancellationRequested = cancellationToken.IsCancellationRequested;
			bool result;
			if (isCancellationRequested)
			{
				result = false;
			}
			else
			{
				int delay = Math.Max(1, pollIntervalMs);
				result = !cancellationToken.WaitHandle.WaitOne(delay);
			}
			return result;
		}

		// Token: 0x06001F90 RID: 8080 RVA: 0x000B8B0C File Offset: 0x000B6D0C
		private static int GetTotalPointCount(CalibHandEyeSetting setting)
		{
			bool flag = setting == null;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				result = Math.Max(0, setting.CalibrationPoints) + Math.Max(0, setting.RotationPointCount);
			}
			return result;
		}

		// Token: 0x06001F91 RID: 8081 RVA: 0x000B8B44 File Offset: 0x000B6D44
		private void WriteResultTags(CalibHandEyeWorkflowService.WorkflowContext context, HandEyeCalibrationResult result)
		{
			bool flag = result == null || !result.IsSuccess;
			if (flag)
			{
				this.WriteTag(context, "calibration result valid", 0);
			}
			else
			{
				this.WriteTag(context, "calibration scale x", result.PixelSizeX);
				this.WriteTag(context, "calibration scale y", result.PixelSizeY);
				this.WriteTag(context, "calibration rotation", result.RotationDeg);
				this.WriteTag(context, "calibration offset x", result.TranslationX);
				this.WriteTag(context, "calibration offset y", result.TranslationY);
				this.WriteTag(context, "calibration angle offset", result.AngleOffsetDeg);
				this.WriteTag(context, "calibration rms error", result.RmsErrorMm);
				this.WriteTag(context, "calibration result valid", 1);
			}
		}

		// Token: 0x06001F92 RID: 8082 RVA: 0x000B8C3C File Offset: 0x000B6E3C
		private static HandEyeSamplePoint ToSamplePoint(CalibHandEyeWorkflowPointResult point)
		{
			return new HandEyeSamplePoint
			{
				Index = point.Index,
				ImageX = point.VisionX,
				ImageY = point.VisionY,
				VisionAngle = point.VisionAngle,
				RobotX = point.RobotX,
				RobotY = point.RobotY,
				RobotRz = point.RobotRz,
				IsValid = point.IsSuccess
			};
		}

		// Token: 0x06001F93 RID: 8083 RVA: 0x000B8CBC File Offset: 0x000B6EBC
		private CalibHandEyeWorkflowPointResult ProcessPoint(CalibHandEyeWorkflowService.WorkflowContext context, int pointIndex, CancellationToken cancellationToken, HObject providedImage = null)
		{
			CalibHandEyeWorkflowPointResult pointResult = new CalibHandEyeWorkflowPointResult
			{
				Index = pointIndex
			};
			this.WriteTag(context, "vision busy", 1);
			this.WriteTag(context, "vision capture done", 0);
			this.WriteTag(context, "robot next point", 0);
			this.AddLog(pointIndex, "Read Robot", (context.Connection == null) ? "Manual Capture" : context.Connection.Name, "Running", (context.Connection == null) ? "No communication selected for manual capture." : "Reading robot actual position.");
			Dictionary<string, string> robotValues = this.ReadTags(context, cancellationToken);
			pointResult.RobotX = CalibHandEyeWorkflowService.ToDouble(CalibHandEyeWorkflowService.GetValue(robotValues, "calibration robot x"));
			pointResult.RobotY = CalibHandEyeWorkflowService.ToDouble(CalibHandEyeWorkflowService.GetValue(robotValues, "calibration robot y"));
			pointResult.RobotRz = CalibHandEyeWorkflowService.ToDouble(CalibHandEyeWorkflowService.GetValue(robotValues, "calibration robot degree"));
			Action<CalibHandEyeWorkflowPointResult> robotPoseHandler = this.RobotPoseRead;
			bool flag = robotPoseHandler != null;
			if (flag)
			{
				robotPoseHandler(pointResult);
			}
			this.AddLog(pointIndex, "Robot Coordinates", "calibration robot x/y/degree", "Success", string.Format("X={0:0.###}, Y={1:0.###}, Degree={2:0.###}", pointResult.RobotX, pointResult.RobotY, pointResult.RobotRz));
			HObject image = null;
			try
			{
				bool flag2 = providedImage != null && providedImage.IsInitialized();
				if (flag2)
				{
					this.AddLog(pointIndex, "Capture Image", context.Camera.Name, "Running", "Using hardware-triggered frame.");
					HOperatorSet.CopyImage(providedImage, out image);
				}
				else
				{
					this.AddLog(pointIndex, "Capture Image", context.Camera.Name, "Running", "Capturing image from selected camera.");
					image = CameraHardwareRuntimeService.CaptureImage(context.Camera.CameraConfig);
				}
				HObject displayImage;
				HOperatorSet.CopyImage(image, out displayImage);
				Action<HObject> imageHandler = this.ImageCaptured;
				bool flag3 = imageHandler != null;
				if (flag3)
				{
					imageHandler(displayImage);
				}
				ShapeMatchResult match = CalibHandEyeWorkflowService.NormalizeMasterResult(CalibHandEyeWorkflowService.RunMasterTool(image, context.MasterTool), context.MasterTool);
				pointResult.VisionX = match.Column;
				pointResult.VisionY = match.Row;
				pointResult.VisionAngle = match.Angle * 180.0 / 3.141592653589793;
				pointResult.Score = match.Score;
				pointResult.IsSuccess = match.IsSuccess;
				pointResult.Message = match.Message;
				this.WriteTag(context, "vision x", pointResult.VisionX);
				this.WriteTag(context, "vision y", pointResult.VisionY);
				this.WriteTag(context, "vision degree", pointResult.VisionAngle);
				this.WriteTag(context, "vision score", pointResult.Score);
				this.WriteTag(context, "vision result ok", pointResult.IsSuccess ? 1 : 0);
				this.WriteTag(context, "vision error code", pointResult.IsSuccess ? 0 : 1);
				this.WriteTag(context, "vision capture done", 1);
				this.WriteTag(context, "robot next point", pointResult.IsSuccess ? 1 : 0);
				this.AddLog(pointIndex, "Vision Process", context.MasterTool.Name, pointResult.IsSuccess ? "Success" : "Fail", pointResult.Message);
			}
			catch (Exception ex)
			{
				pointResult.IsSuccess = false;
				pointResult.Message = ex.Message;
				this.WriteTag(context, "vision result ok", 0);
				this.WriteTag(context, "vision error code", 1);
				this.WriteTag(context, "vision capture done", 1);
				this.WriteTag(context, "robot next point", 0);
				this.AddLog(pointIndex, "Vision Process", "Error", "Fail", ex.Message);
			}
			finally
			{
				this.WriteTag(context, "vision busy", 0);
				bool flag4 = image != null;
				if (flag4)
				{
					image.Dispose();
				}
			}
			return pointResult;
		}

		// Token: 0x06001F94 RID: 8084 RVA: 0x000B910C File Offset: 0x000B730C
		private CalibHandEyeWorkflowService.WorkflowContext BuildContext(CalibHandEyeSetting setting)
		{
			bool flag = setting == null;
			if (flag)
			{
				throw new InvalidOperationException("Calibration setting is not available.");
			}
			CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(null);
			CommunicationConnection connection = config.Connections.FirstOrDefault((CommunicationConnection x) => string.Equals(x.Name, setting.CommunicationName, StringComparison.OrdinalIgnoreCase));
			bool flag2 = connection == null || string.Equals(setting.CommunicationName, "None", StringComparison.OrdinalIgnoreCase);
			if (flag2)
			{
				throw new InvalidOperationException("Communication connection is not selected.");
			}
			bool isOpcUa = string.Equals(connection.Protocol, "OPC UA", StringComparison.OrdinalIgnoreCase);
			bool flag3 = !CommunicationOptions.SupportsTagReadWrite(connection.Protocol);
			if (flag3)
			{
				throw new InvalidOperationException("Calibration workflow requires a protocol that addresses tags: Modbus Client TCP/IP, OPC UA or MX Component.");
			}
			CommunicationOperationResult connectResult = this._plcService.Connect(connection);
			bool flag4 = !connectResult.Success;
			if (flag4)
			{
				throw new InvalidOperationException("PLC connect failed: " + connectResult.Message);
			}
			List<CommunicationTagRow> connectionTags = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name);
			CalibHandEyeWorkflowService.EnsureWorkflowTags(connectionTags, isOpcUa);
			MainWindow instance = MainWindow.instance;
			CameraNode cameraNode;
			if (instance == null)
			{
				cameraNode = null;
			}
			else
			{
				MainViewModel mainViewModel = instance.MainViewModel;
				if (mainViewModel == null)
				{
					cameraNode = null;
				}
				else
				{
					ObservableCollection<CameraNode> cameras = mainViewModel.Cameras;
					cameraNode = ((cameras != null) ? cameras.FirstOrDefault(delegate(CameraNode x)
					{
						string a;
						if (x == null)
						{
							a = null;
						}
						else
						{
							CameraItem cameraInfo = x.CameraInfo;
							a = ((cameraInfo != null) ? cameraInfo.CameraName : null);
						}
						return string.Equals(a, setting.CameraName, StringComparison.OrdinalIgnoreCase);
					}) : null);
				}
			}
			CameraNode camera = cameraNode;
			bool flag5 = camera == null || string.Equals(setting.CameraName, "None", StringComparison.OrdinalIgnoreCase);
			if (flag5)
			{
				throw new InvalidOperationException("Calibration camera is not selected.");
			}
			CalibHandEyeWorkflowService.EnsureCameraRecipeToolsLoaded(camera, setting.CameraName, setting.MasterToolName);
			ToolVision tool = CalibHandEyeWorkflowService.ResolveMasterTool(camera, setting.MasterToolName);
			bool flag6 = tool == null;
			if (flag6)
			{
				throw new InvalidOperationException(CalibHandEyeWorkflowService.CreateMasterToolNotFoundMessage(camera, setting.MasterToolName));
			}
			Dictionary<string, CommunicationTagRow> tagMap = (from x in connectionTags
			where !string.IsNullOrWhiteSpace(x.Name)
			group x by CalibHandEyeWorkflowService.NormalizeName(x.Name)).ToDictionary((IGrouping<string, CommunicationTagRow> x) => x.Key, (IGrouping<string, CommunicationTagRow> x) => x.First<CommunicationTagRow>(), StringComparer.OrdinalIgnoreCase);
			return new CalibHandEyeWorkflowService.WorkflowContext
			{
				Connection = connection,
				Camera = camera,
				MasterTool = tool,
				Tags = tagMap,
				PollIntervalMs = CalibHandEyeWorkflowService.GetPollInterval(connection)
			};
		}

		// Token: 0x06001F95 RID: 8085 RVA: 0x000B9394 File Offset: 0x000B7594
		private static CalibHandEyeWorkflowService.WorkflowContext BuildVisionOnlyContext(CalibHandEyeSetting setting)
		{
			bool flag = setting == null;
			if (flag)
			{
				throw new InvalidOperationException("Calibration setting is not available.");
			}
			MainWindow instance = MainWindow.instance;
			CameraNode cameraNode;
			if (instance == null)
			{
				cameraNode = null;
			}
			else
			{
				MainViewModel mainViewModel = instance.MainViewModel;
				if (mainViewModel == null)
				{
					cameraNode = null;
				}
				else
				{
					ObservableCollection<CameraNode> cameras = mainViewModel.Cameras;
					cameraNode = ((cameras != null) ? cameras.FirstOrDefault(delegate(CameraNode x)
					{
						string a;
						if (x == null)
						{
							a = null;
						}
						else
						{
							CameraItem cameraInfo = x.CameraInfo;
							a = ((cameraInfo != null) ? cameraInfo.CameraName : null);
						}
						return string.Equals(a, setting.CameraName, StringComparison.OrdinalIgnoreCase);
					}) : null);
				}
			}
			CameraNode camera = cameraNode;
			bool flag2 = camera == null || string.Equals(setting.CameraName, "None", StringComparison.OrdinalIgnoreCase);
			if (flag2)
			{
				throw new InvalidOperationException("Calibration camera is not selected.");
			}
			CalibHandEyeWorkflowService.EnsureCameraRecipeToolsLoaded(camera, setting.CameraName, setting.MasterToolName);
			ToolVision tool = CalibHandEyeWorkflowService.ResolveMasterTool(camera, setting.MasterToolName);
			bool flag3 = tool == null;
			if (flag3)
			{
				throw new InvalidOperationException(CalibHandEyeWorkflowService.CreateMasterToolNotFoundMessage(camera, setting.MasterToolName));
			}
			return new CalibHandEyeWorkflowService.WorkflowContext
			{
				Camera = camera,
				MasterTool = tool,
				Tags = new Dictionary<string, CommunicationTagRow>(StringComparer.OrdinalIgnoreCase),
				PollIntervalMs = 10
			};
		}

		// Token: 0x06001F96 RID: 8086 RVA: 0x000B94B0 File Offset: 0x000B76B0
		private static void EnsureCameraRecipeToolsLoaded(CameraNode camera, string cameraName, string selectedMaster)
		{
			bool flag = camera == null;
			if (!flag)
			{
				CalibHandEyeWorkflowService.NormalizeCameraToolParents(camera);
				bool flag2 = CalibHandEyeWorkflowService.ResolveMasterTool(camera, selectedMaster) != null;
				if (!flag2)
				{
					bool flag3 = (string.IsNullOrWhiteSpace(selectedMaster) || string.Equals(selectedMaster, "None", StringComparison.OrdinalIgnoreCase)) && CalibHandEyeWorkflowService.HasSupportedMasterTool(camera);
					if (!flag3)
					{
						string path = RecipePathService.GetCurrentModelRecipeJsonPath();
						bool flag4 = string.IsNullOrWhiteSpace(path);
						if (!flag4)
						{
							RecipeConfig recipe = RecipeStorageService.Load(path);
							CameraRecipeConfig cameraRecipeConfig;
							if (recipe == null)
							{
								cameraRecipeConfig = null;
							}
							else
							{
								List<CameraRecipeConfig> cameras = recipe.Cameras;
								cameraRecipeConfig = ((cameras != null) ? cameras.FirstOrDefault(delegate(CameraRecipeConfig x)
								{
									bool result;
									if (!string.Equals(x.CameraName, cameraName, StringComparison.OrdinalIgnoreCase))
									{
										string cameraName2 = x.CameraName;
										CameraItem cameraInfo = camera.CameraInfo;
										result = string.Equals(cameraName2, (cameraInfo != null) ? cameraInfo.CameraName : null, StringComparison.OrdinalIgnoreCase);
									}
									else
									{
										result = true;
									}
									return result;
								}) : null);
							}
							CameraRecipeConfig cameraRecipe = cameraRecipeConfig;
							bool flag5 = ((cameraRecipe != null) ? cameraRecipe.TurnSnaps : null) == null || cameraRecipe.TurnSnaps.Count == 0;
							if (!flag5)
							{
								camera.TurnSnaps.Clear();
								foreach (TurnSnapRecipeConfig tsRecipe in from x in cameraRecipe.TurnSnaps
								orderby x.Index
								select x)
								{
									TurnSnap turnSnap = new TurnSnap
									{
										Index = tsRecipe.Index,
										ParentCamera = camera
									};
									foreach (ToolRecipeConfig toolRecipe in (tsRecipe.Tools ?? new List<ToolRecipeConfig>()).OrderBy((ToolRecipeConfig x) => x.Index))
									{
										ToolVision tool = CalibHandEyeWorkflowService.CreateToolFromRecipe(toolRecipe, turnSnap);
										turnSnap.Tools.Add(tool);
									}
									camera.TurnSnaps.Add(turnSnap);
								}
								CalibHandEyeWorkflowService.NormalizeCameraToolParents(camera);
							}
						}
					}
				}
			}
		}

		// Token: 0x06001F97 RID: 8087 RVA: 0x000B96F0 File Offset: 0x000B78F0
		private static ToolVision CreateToolFromRecipe(ToolRecipeConfig toolRecipe, TurnSnap turnSnap)
		{
			ToolVision tool = new ToolVision
			{
				ToolId = (string.IsNullOrWhiteSpace(toolRecipe.ToolId) ? Guid.NewGuid().ToString("N") : toolRecipe.ToolId),
				Index = toolRecipe.Index,
				Name = toolRecipe.Name,
				ParentTurnSnap = turnSnap,
				Config = (toolRecipe.Config as ToolConfigBase),
				Spec = (toolRecipe.Spec as ToolSpecBase),
				TrainModel = (toolRecipe.TrainModel as ToolTrainBase)
			};
			ToolType toolType;
			bool flag = Enum.TryParse<ToolType>(toolRecipe.ToolType, out toolType);
			if (flag)
			{
				tool.ToolType = toolType;
			}
			CalibHandEyeWorkflowService.LoadRoiList(toolRecipe.RoiItems, tool.RoiItems);
			CalibHandEyeWorkflowService.LoadRoiList(toolRecipe.LimitRoiItems, tool.LimitRoiItems);
			CalibHandEyeWorkflowService.LoadRoiList(toolRecipe.MaskRoiItems, tool.MaskRoiItems);
			return tool;
		}

		// Token: 0x06001F98 RID: 8088 RVA: 0x000B97E4 File Offset: 0x000B79E4
		private static void LoadRoiList(IEnumerable<RoiData> source, ObservableCollection<RoiData> target)
		{
			target.Clear();
			bool flag = source == null;
			if (!flag)
			{
				foreach (RoiData roi in source)
				{
					bool flag2 = roi == null;
					if (!flag2)
					{
						roi.IsSelected = false;
						target.Add(roi);
					}
				}
			}
		}

		// Token: 0x06001F99 RID: 8089 RVA: 0x000B9858 File Offset: 0x000B7A58
		private static bool HasSupportedMasterTool(CameraNode camera)
		{
			bool flag = ((camera != null) ? camera.TurnSnaps : null) == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				result = (from x in camera.TurnSnaps
				where ((x != null) ? x.Tools : null) != null
				select x).SelectMany((TurnSnap x) => x.Tools).Any(new Func<ToolVision, bool>(CalibHandEyeWorkflowService.IsSupportedMasterTool));
			}
			return result;
		}

		// Token: 0x06001F9A RID: 8090 RVA: 0x000B98E0 File Offset: 0x000B7AE0
		private static void NormalizeCameraToolParents(CameraNode camera)
		{
			bool flag = ((camera != null) ? camera.TurnSnaps : null) == null;
			if (!flag)
			{
				foreach (TurnSnap turnSnap in camera.TurnSnaps)
				{
					bool flag2 = turnSnap == null;
					if (!flag2)
					{
						turnSnap.ParentCamera = camera;
						IEnumerable<ToolVision> tools = turnSnap.Tools;
						foreach (ToolVision tool in (tools ?? Enumerable.Empty<ToolVision>()))
						{
							tool.ParentTurnSnap = turnSnap;
						}
					}
				}
			}
		}

		// Token: 0x06001F9B RID: 8091 RVA: 0x000B99A8 File Offset: 0x000B7BA8
		private static void EnsureWorkflowTags(List<CommunicationTagRow> tags, bool isOpcUa)
		{
			bool flag = tags == null;
			if (!flag)
			{
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration snap", "40001", "INT16", "Read", "Robot trigger: capture image.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration robot x", "40002", "FLOAT", "Read", "Robot actual X position.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration robot y", "40004", "FLOAT", "Read", "Robot actual Y position.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration robot degree", "40006", "FLOAT", "Read", "Robot actual angle.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration position point", "40008", "INT16", "Write", "Number of position (mapping) calibration points, sent from the Calib Hand-Eye setting.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration rotation point", "40009", "INT16", "Write", "Number of rotation calibration points, sent from the Calib Hand-Eye setting.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration complete", "40010", "INT16", "Read", "Robot calibration complete bit.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration start", "40011", "INT16", "Write", "Calibration control command sent to robot: 1=start, 2=pause, 0=stop.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "vision busy", "40012", "INT16", "Write", "Vision is processing current calibration point.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "vision capture done", "40013", "INT16", "Write", "Vision capture and processing completed.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "vision result ok", "40014", "INT16", "Write", "Vision result status: 1=OK, 0=NG.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "vision x", "40015", "FLOAT", "Write", "Vision detected X/column in pixel.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "vision y", "40017", "FLOAT", "Write", "Vision detected Y/row in pixel.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "vision degree", "40019", "FLOAT", "Write", "Vision detected angle in degree.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "vision score", "40021", "FLOAT", "Write", "Vision detected score.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "robot next point", "40023", "INT16", "Write", "Vision command: robot can move to next calibration point.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "vision error code", "40024", "INT16", "Write", "Vision error code for robot.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration result valid", "40025", "INT16", "Write", "Calibration result valid: 1=OK, 0=NG.");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration scale x", "40026", "FLOAT", "Write", "Calibration pixel size X (mm/pixel).");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration scale y", "40028", "FLOAT", "Write", "Calibration pixel size Y (mm/pixel).");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration rotation", "40030", "FLOAT", "Write", "Calibration rotation angle (degree).");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration offset x", "40032", "FLOAT", "Write", "Calibration translation X (mm).");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration offset y", "40034", "FLOAT", "Write", "Calibration translation Y (mm).");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration angle offset", "40036", "FLOAT", "Write", "Calibration vision-to-robot angle offset (degree).");
				CalibHandEyeWorkflowService.AddWorkflowTag(tags, isOpcUa, "calibration rms error", "40038", "FLOAT", "Write", "Calibration RMS position error (mm).");
			}
		}

		// Token: 0x06001F9C RID: 8092 RVA: 0x000B9CFC File Offset: 0x000B7EFC
		private static void AddWorkflowTag(List<CommunicationTagRow> tags, bool isOpcUa, string name, string modbusAddress, string dataType, string readWrite, string description)
		{
			CalibHandEyeWorkflowService.AddTagIfMissing(tags, name, isOpcUa ? string.Empty : modbusAddress, dataType, readWrite, description);
		}

		// Token: 0x06001F9D RID: 8093 RVA: 0x000B9D18 File Offset: 0x000B7F18
		private static void AddTagIfMissing(List<CommunicationTagRow> tags, string name, string address, string dataType, string readWrite, string description)
		{
			CommunicationTagRow existing = tags.FirstOrDefault((CommunicationTagRow x) => string.Equals(CalibHandEyeWorkflowService.NormalizeName(x.Name), CalibHandEyeWorkflowService.NormalizeName(name), StringComparison.OrdinalIgnoreCase));
			bool flag = existing != null;
			if (flag)
			{
				bool flag2 = string.IsNullOrWhiteSpace(existing.Address);
				if (flag2)
				{
					existing.Address = address;
				}
				bool flag3 = string.IsNullOrWhiteSpace(existing.DataType);
				if (flag3)
				{
					existing.DataType = dataType;
				}
				bool flag4 = string.IsNullOrWhiteSpace(existing.ReadWrite);
				if (flag4)
				{
					existing.ReadWrite = readWrite;
				}
				bool flag5 = string.IsNullOrWhiteSpace(existing.Description);
				if (flag5)
				{
					existing.Description = description;
				}
			}
			else
			{
				tags.Add(new CommunicationTagRow(name, address, dataType, readWrite, description));
			}
		}

		// Token: 0x06001F9E RID: 8094 RVA: 0x000B9DD0 File Offset: 0x000B7FD0
		private static ToolVision ResolveMasterTool(CameraNode camera, string optionText)
		{
			bool flag = ((camera != null) ? camera.TurnSnaps : null) == null || string.IsNullOrWhiteSpace(optionText) || string.Equals(optionText, "None", StringComparison.OrdinalIgnoreCase);
			ToolVision result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string toolName = optionText;
				int separatorIndex = optionText.IndexOf(" - ", StringComparison.Ordinal);
				bool flag2 = separatorIndex >= 0;
				if (flag2)
				{
					toolName = optionText.Substring(separatorIndex + 3);
				}
				List<ToolVision> candidates = new List<ToolVision>();
				Func<ToolVision, bool> <>9__1;
				foreach (TurnSnap turnSnap in camera.TurnSnaps)
				{
					bool flag3 = ((turnSnap != null) ? turnSnap.Tools : null) == null;
					if (!flag3)
					{
						turnSnap.ParentCamera = camera;
						foreach (ToolVision item in turnSnap.Tools)
						{
							item.ParentTurnSnap = turnSnap;
						}
						candidates.AddRange(turnSnap.Tools.Where(new Func<ToolVision, bool>(CalibHandEyeWorkflowService.IsSupportedMasterTool)));
						IEnumerable<ToolVision> tools = turnSnap.Tools;
						Func<ToolVision, bool> predicate;
						if ((predicate = <>9__1) == null)
						{
							predicate = (<>9__1 = ((ToolVision x) => CalibHandEyeWorkflowService.IsSupportedMasterTool(x) && string.Equals(x.Name, toolName, StringComparison.OrdinalIgnoreCase)));
						}
						ToolVision tool = tools.FirstOrDefault(predicate);
						bool flag4 = tool != null;
						if (flag4)
						{
							return tool;
						}
					}
				}
				string normalizedToolName = CalibHandEyeWorkflowService.NormalizeToolOptionName(toolName);
				ToolVision normalizedMatch = candidates.FirstOrDefault((ToolVision x) => string.Equals(CalibHandEyeWorkflowService.NormalizeToolOptionName(x.Name), normalizedToolName, StringComparison.OrdinalIgnoreCase));
				bool flag5 = normalizedMatch != null;
				if (flag5)
				{
					result = normalizedMatch;
				}
				else
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001F9F RID: 8095 RVA: 0x000B9FA0 File Offset: 0x000B81A0
		private static bool IsSupportedMasterTool(ToolVision tool)
		{
			return tool != null && (tool.ToolType == ToolType.Shape_model || tool.ToolType == ToolType.AnisoShapeModel || tool.ToolType == ToolType.OverlappingShapeModel || tool.ToolType == ToolType.BoundingBoxMaster || tool.ToolType == ToolType.MinAreaMaster);
		}

		// Token: 0x06001FA0 RID: 8096 RVA: 0x000B9FEC File Offset: 0x000B81EC
		private static string NormalizeToolOptionName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				result = new string(name.Where(new Func<char, bool>(char.IsLetterOrDigit)).Select(new Func<char, char>(char.ToUpperInvariant)).ToArray<char>());
			}
			return result;
		}

		// Token: 0x06001FA1 RID: 8097 RVA: 0x000BA040 File Offset: 0x000B8240
		private static string CreateMasterToolNotFoundMessage(CameraNode camera, string selectedMaster)
		{
			List<string> available = new List<string>();
			bool flag = ((camera != null) ? camera.TurnSnaps : null) != null;
			if (flag)
			{
				foreach (TurnSnap turnSnap in from x in camera.TurnSnaps
				orderby x.Index
				select x)
				{
					IEnumerable<ToolVision> tools = turnSnap.Tools;
					foreach (ToolVision tool in (tools ?? Enumerable.Empty<ToolVision>()).Where(new Func<ToolVision, bool>(CalibHandEyeWorkflowService.IsSupportedMasterTool)).OrderBy((ToolVision x) => x.Index))
					{
						available.Add(turnSnap.DisplayName + " - " + tool.Name);
					}
				}
			}
			string availableText = (available.Count > 0) ? string.Join(", ", available) : "No master tool found in this camera.";
			string[] array = new string[6];
			array[0] = "Calibration master tool was not found.\nCamera: ";
			int num = 1;
			string text;
			if (camera == null)
			{
				text = null;
			}
			else
			{
				CameraItem cameraInfo = camera.CameraInfo;
				text = ((cameraInfo != null) ? cameraInfo.CameraName : null);
			}
			array[num] = (text ?? "None");
			array[2] = "\nSelected master: ";
			array[3] = (selectedMaster ?? "None");
			array[4] = "\nAvailable master tools: ";
			array[5] = availableText;
			return string.Concat(array);
		}

		// Token: 0x06001FA2 RID: 8098 RVA: 0x000BA1F0 File Offset: 0x000B83F0
		private static ShapeMatchResult RunMasterTool(HObject image, ToolVision tool)
		{
			bool flag = tool.ToolType == ToolType.Shape_model;
			ShapeMatchResult result;
			if (flag)
			{
				result = new ShapeModelProcessor().Match(image, tool);
			}
			else
			{
				bool flag2 = tool.ToolType == ToolType.AnisoShapeModel;
				if (flag2)
				{
					result = new AnisoShapeModelProcessor().Match(image, tool);
				}
				else
				{
					bool flag3 = tool.ToolType == ToolType.OverlappingShapeModel;
					if (flag3)
					{
						result = new OverlappingShapeModelProcessor().Match(image, tool);
					}
					else
					{
						bool flag4 = tool.ToolType == ToolType.BoundingBoxMaster;
						if (flag4)
						{
							result = new BoundingBoxMasterProcessor().Match(image, tool);
						}
						else
						{
							bool flag5 = tool.ToolType == ToolType.MinAreaMaster;
							if (flag5)
							{
								result = new MinAreaMasterProcessor().Match(image, tool);
							}
							else
							{
								result = new ShapeMatchResult
								{
									IsSuccess = false,
									Message = "Unsupported calibration master tool."
								};
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001FA3 RID: 8099 RVA: 0x000BA2B4 File Offset: 0x000B84B4
		private static ShapeMatchResult NormalizeMasterResult(ShapeMatchResult result, ToolVision tool)
		{
			bool flag = result == null || result.IsSuccess || tool == null || tool.ToolType != ToolType.AnisoShapeModel || result.Matches == null || result.Matches.Count == 0;
			ShapeMatchResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeMatchCandidate selected = (from x in result.Matches
				orderby x.Score descending, x.Index
				select x).FirstOrDefault<ShapeMatchCandidate>();
				bool flag2 = selected == null;
				if (flag2)
				{
					result2 = result;
				}
				else
				{
					result.IsSuccess = true;
					result.GridRow = selected.GridRow;
					result.GridColumn = selected.GridColumn;
					result.Row = selected.Row;
					result.Column = selected.Column;
					result.Angle = selected.Angle;
					result.ScaleRow = selected.ScaleRow;
					result.ScaleColumn = selected.ScaleColumn;
					result.Score = selected.Score;
					result.DeltaRow = selected.DeltaRow;
					result.DeltaColumn = selected.DeltaColumn;
					result.DeltaAngle = selected.DeltaAngle;
					result.Message = "Aniso Shape Model detected objects. Calibration used highest-score object because Pick Row/Column did not select a match.";
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x06001FA4 RID: 8100 RVA: 0x000BA40C File Offset: 0x000B860C
		private Dictionary<string, string> ReadTags(CalibHandEyeWorkflowService.WorkflowContext context, CancellationToken cancellationToken)
		{
			bool isCancellationRequested = cancellationToken.IsCancellationRequested;
			Dictionary<string, string> result2;
			if (isCancellationRequested)
			{
				result2 = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			}
			else
			{
				bool flag = context.Connection == null;
				if (flag)
				{
					result2 = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
				}
				else
				{
					List<CommunicationTagRow> readTags = (from x in context.Tags.Values
					where string.Equals(x.ReadWrite, "Read", StringComparison.OrdinalIgnoreCase) || string.Equals(x.ReadWrite, "Read/Write", StringComparison.OrdinalIgnoreCase) || CalibHandEyeWorkflowService.IsCalibrationInputTag(x.Name)
					select x).ToList<CommunicationTagRow>();
					CommunicationReadResult result = this._plcService.ReadAll(context.Connection, readTags);
					Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
					int i = 0;
					while (i < readTags.Count && i < result.Rows.Count)
					{
						values[CalibHandEyeWorkflowService.NormalizeName(readTags[i].Name)] = result.Rows[i].Value;
						i++;
					}
					result2 = values;
				}
			}
			return result2;
		}

		// Token: 0x06001FA5 RID: 8101 RVA: 0x000BA508 File Offset: 0x000B8708
		private CalibHandEyeWorkflowService.TagReadValue ReadSingleTag(CalibHandEyeWorkflowService.WorkflowContext context, string tagName, CancellationToken cancellationToken)
		{
			bool isCancellationRequested = cancellationToken.IsCancellationRequested;
			CalibHandEyeWorkflowService.TagReadValue result2;
			if (isCancellationRequested)
			{
				result2 = CalibHandEyeWorkflowService.TagReadValue.Canceled();
			}
			else
			{
				bool flag = context == null || context.Connection == null;
				if (flag)
				{
					result2 = CalibHandEyeWorkflowService.TagReadValue.Fail("Communication connection is not available.");
				}
				else
				{
					CommunicationTagRow tag;
					bool flag2 = context.Tags == null || !context.Tags.TryGetValue(CalibHandEyeWorkflowService.NormalizeName(tagName), out tag);
					if (flag2)
					{
						result2 = CalibHandEyeWorkflowService.TagReadValue.Fail("Tag '" + tagName + "' was not found in Tag Management.");
					}
					else
					{
						CommunicationReadResult result = this._plcService.ReadAll(context.Connection, new CommunicationTagRow[]
						{
							tag
						});
						bool flag3 = !result.Success;
						if (flag3)
						{
							result2 = CalibHandEyeWorkflowService.TagReadValue.Fail(result.Message);
						}
						else
						{
							CommunicationMonitorRow row = result.Rows.FirstOrDefault<CommunicationMonitorRow>();
							bool flag4 = row == null;
							if (flag4)
							{
								result2 = CalibHandEyeWorkflowService.TagReadValue.Fail("No value returned for tag '" + tagName + "'.");
							}
							else
							{
								bool flag5 = !string.Equals(row.Quality, "Good", StringComparison.OrdinalIgnoreCase);
								if (flag5)
								{
									result2 = CalibHandEyeWorkflowService.TagReadValue.Fail(string.Concat(new string[]
									{
										"Read tag '",
										tagName,
										"' failed. Address=",
										tag.Address,
										", Message=",
										row.Value
									}));
								}
								else
								{
									result2 = CalibHandEyeWorkflowService.TagReadValue.Ok(row.Value);
								}
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06001FA6 RID: 8102 RVA: 0x000BA674 File Offset: 0x000B8874
		private static bool IsCalibrationInputTag(string tagName)
		{
			string normalized = CalibHandEyeWorkflowService.NormalizeName(tagName);
			return normalized == CalibHandEyeWorkflowService.NormalizeName("calibration snap") || normalized == CalibHandEyeWorkflowService.NormalizeName("calibration robot x") || normalized == CalibHandEyeWorkflowService.NormalizeName("calibration robot y") || normalized == CalibHandEyeWorkflowService.NormalizeName("calibration robot degree") || normalized == CalibHandEyeWorkflowService.NormalizeName("calibration complete");
		}

		// Token: 0x06001FA7 RID: 8103 RVA: 0x000BA6E8 File Offset: 0x000B88E8
		private void WriteTag(CalibHandEyeWorkflowService.WorkflowContext context, string tagName, object value)
		{
			CommunicationTagRow tag;
			bool flag = context.Connection == null || context.Tags == null || !context.Tags.TryGetValue(CalibHandEyeWorkflowService.NormalizeName(tagName), out tag);
			if (!flag)
			{
				bool flag2 = !string.Equals(tag.ReadWrite, "Write", StringComparison.OrdinalIgnoreCase) && !string.Equals(tag.ReadWrite, "Read/Write", StringComparison.OrdinalIgnoreCase);
				if (!flag2)
				{
					string text = Convert.ToString(value, CultureInfo.InvariantCulture);
					CommunicationOperationResult result = this._plcService.Write(context.Connection, tag.Address, tag.DataType, text);
					bool flag3 = !result.Success;
					if (flag3)
					{
						this.AddLog(0, "Write Tag", tag.Name, "Fail", result.Message);
					}
				}
			}
		}

		// Token: 0x06001FA8 RID: 8104 RVA: 0x000BA7B4 File Offset: 0x000B89B4
		private static string GetValue(Dictionary<string, string> values, string tagName)
		{
			string value;
			return (values != null && values.TryGetValue(CalibHandEyeWorkflowService.NormalizeName(tagName), out value)) ? value : null;
		}

		// Token: 0x06001FA9 RID: 8105 RVA: 0x000BA7E0 File Offset: 0x000B89E0
		private static bool IsTrue(string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = string.Equals(value, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "TRUE", StringComparison.OrdinalIgnoreCase);
				double number;
				result = (flag2 || (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out number) && Math.Abs(number) > double.Epsilon));
			}
			return result;
		}

		// Token: 0x06001FAA RID: 8106 RVA: 0x000BA850 File Offset: 0x000B8A50
		private static double ToDouble(string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value) || string.Equals(value, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "OFF", StringComparison.OrdinalIgnoreCase);
			double result;
			if (flag)
			{
				result = 0.0;
			}
			else
			{
				double number;
				result = (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out number) ? number : 0.0);
			}
			return result;
		}

		// Token: 0x06001FAB RID: 8107 RVA: 0x000BA8B8 File Offset: 0x000B8AB8
		private static int ToInt(string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				bool flag2 = string.Equals(value, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "TRUE", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = 1;
				}
				else
				{
					bool flag3 = string.Equals(value, "OFF", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "FALSE", StringComparison.OrdinalIgnoreCase);
					if (flag3)
					{
						result = 0;
					}
					else
					{
						double number;
						result = (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out number) ? ((int)Math.Round(number)) : 0);
					}
				}
			}
			return result;
		}

		// Token: 0x06001FAC RID: 8108 RVA: 0x000BA944 File Offset: 0x000B8B44
		private static int GetPollInterval(CommunicationConnection connection)
		{
			string text = ((connection != null) ? connection.ExchangeInterval : null) ?? "10";
			string digits = new string(text.Where(new Func<char, bool>(char.IsDigit)).ToArray<char>());
			int value;
			return int.TryParse(digits, out value) ? Math.Max(10, value) : 10;
		}

		// Token: 0x06001FAD RID: 8109 RVA: 0x000BA9A0 File Offset: 0x000B8BA0
		private static string NormalizeName(string name)
		{
			return (name ?? string.Empty).Trim().ToLowerInvariant();
		}

		// Token: 0x06001FAE RID: 8110 RVA: 0x000BA9C8 File Offset: 0x000B8BC8
		private void AddLog(int point, string action, string command, string result, string message)
		{
			Action<int, string, string, string, string> handler = this.Log;
			bool flag = handler != null;
			if (flag)
			{
				handler(point, action, command, result, message);
			}
		}

		// Token: 0x06001FAF RID: 8111 RVA: 0x000BA9F4 File Offset: 0x000B8BF4
		private void SetStatus(string status)
		{
			Action<string> handler = this.StatusChanged;
			bool flag = handler != null;
			if (flag)
			{
				handler(status);
			}
		}

		// Token: 0x06001FB0 RID: 8112 RVA: 0x000BAA19 File Offset: 0x000B8C19
		public void Dispose()
		{
			this._plcService.Dispose();
		}

		// Token: 0x04000D10 RID: 3344
		private readonly PlcCommunicationService _plcService = SharedCommunicationService.Instance;

		// Token: 0x04000D11 RID: 3345
		private readonly List<HandEyeSamplePoint> _samples = new List<HandEyeSamplePoint>();

		// Token: 0x04000D12 RID: 3346
		private static readonly object HardwareSessionLock = new object();

		// Token: 0x04000D13 RID: 3347
		private static CalibHandEyeWorkflowService _activeHardwareSession;

		// Token: 0x04000D14 RID: 3348
		private readonly object _hardwareFrameLock = new object();

		// Token: 0x04000D15 RID: 3349
		private HObject _pendingHardwareFrame;

		// Token: 0x04000D16 RID: 3350
		private string _hardwareCameraName;

		// Token: 0x04000D17 RID: 3351
		private string _hardwareCameraNodeName;

		// Token: 0x04000D1E RID: 3358
		private const string TagCalibrationSnap = "calibration snap";

		// Token: 0x04000D1F RID: 3359
		private const string TagRobotX = "calibration robot x";

		// Token: 0x04000D20 RID: 3360
		private const string TagRobotY = "calibration robot y";

		// Token: 0x04000D21 RID: 3361
		private const string TagRobotDegree = "calibration robot degree";

		// Token: 0x04000D22 RID: 3362
		private const string TagCalibPositionPoint = "calibration position point";

		// Token: 0x04000D23 RID: 3363
		private const string TagCalibRotationPoint = "calibration rotation point";

		// Token: 0x04000D24 RID: 3364
		private const string TagCalibrationComplete = "calibration complete";

		// Token: 0x04000D25 RID: 3365
		private const string TagCalibrationStart = "calibration start";

		// Token: 0x04000D26 RID: 3366
		private const string TagVisionBusy = "vision busy";

		// Token: 0x04000D27 RID: 3367
		private const string TagVisionCaptureDone = "vision capture done";

		// Token: 0x04000D28 RID: 3368
		private const string TagVisionResultOk = "vision result ok";

		// Token: 0x04000D29 RID: 3369
		private const string TagVisionX = "vision x";

		// Token: 0x04000D2A RID: 3370
		private const string TagVisionY = "vision y";

		// Token: 0x04000D2B RID: 3371
		private const string TagVisionDegree = "vision degree";

		// Token: 0x04000D2C RID: 3372
		private const string TagVisionScore = "vision score";

		// Token: 0x04000D2D RID: 3373
		private const string TagRobotNextPoint = "robot next point";

		// Token: 0x04000D2E RID: 3374
		private const string TagVisionErrorCode = "vision error code";

		// Token: 0x04000D2F RID: 3375
		private const string TagCalibResultValid = "calibration result valid";

		// Token: 0x04000D30 RID: 3376
		private const string TagCalibScaleX = "calibration scale x";

		// Token: 0x04000D31 RID: 3377
		private const string TagCalibScaleY = "calibration scale y";

		// Token: 0x04000D32 RID: 3378
		private const string TagCalibRotation = "calibration rotation";

		// Token: 0x04000D33 RID: 3379
		private const string TagCalibOffsetX = "calibration offset x";

		// Token: 0x04000D34 RID: 3380
		private const string TagCalibOffsetY = "calibration offset y";

		// Token: 0x04000D35 RID: 3381
		private const string TagCalibAngleOffset = "calibration angle offset";

		// Token: 0x04000D36 RID: 3382
		private const string TagCalibRmsError = "calibration rms error";

		// Token: 0x0200047C RID: 1148
		private class WorkflowContext
		{
			// Token: 0x17000B8E RID: 2958
			// (get) Token: 0x06002C5D RID: 11357 RVA: 0x000EB05D File Offset: 0x000E925D
			// (set) Token: 0x06002C5E RID: 11358 RVA: 0x000EB065 File Offset: 0x000E9265
			public CommunicationConnection Connection { get; set; }

			// Token: 0x17000B8F RID: 2959
			// (get) Token: 0x06002C5F RID: 11359 RVA: 0x000EB06E File Offset: 0x000E926E
			// (set) Token: 0x06002C60 RID: 11360 RVA: 0x000EB076 File Offset: 0x000E9276
			public CameraNode Camera { get; set; }

			// Token: 0x17000B90 RID: 2960
			// (get) Token: 0x06002C61 RID: 11361 RVA: 0x000EB07F File Offset: 0x000E927F
			// (set) Token: 0x06002C62 RID: 11362 RVA: 0x000EB087 File Offset: 0x000E9287
			public ToolVision MasterTool { get; set; }

			// Token: 0x17000B91 RID: 2961
			// (get) Token: 0x06002C63 RID: 11363 RVA: 0x000EB090 File Offset: 0x000E9290
			// (set) Token: 0x06002C64 RID: 11364 RVA: 0x000EB098 File Offset: 0x000E9298
			public Dictionary<string, CommunicationTagRow> Tags { get; set; }

			// Token: 0x17000B92 RID: 2962
			// (get) Token: 0x06002C65 RID: 11365 RVA: 0x000EB0A1 File Offset: 0x000E92A1
			// (set) Token: 0x06002C66 RID: 11366 RVA: 0x000EB0A9 File Offset: 0x000E92A9
			public int PollIntervalMs { get; set; }
		}

		// Token: 0x0200047D RID: 1149
		private class TagReadValue
		{
			// Token: 0x17000B93 RID: 2963
			// (get) Token: 0x06002C68 RID: 11368 RVA: 0x000EB0B2 File Offset: 0x000E92B2
			// (set) Token: 0x06002C69 RID: 11369 RVA: 0x000EB0BA File Offset: 0x000E92BA
			public bool Success { get; set; }

			// Token: 0x17000B94 RID: 2964
			// (get) Token: 0x06002C6A RID: 11370 RVA: 0x000EB0C3 File Offset: 0x000E92C3
			// (set) Token: 0x06002C6B RID: 11371 RVA: 0x000EB0CB File Offset: 0x000E92CB
			public bool IsCanceled { get; set; }

			// Token: 0x17000B95 RID: 2965
			// (get) Token: 0x06002C6C RID: 11372 RVA: 0x000EB0D4 File Offset: 0x000E92D4
			// (set) Token: 0x06002C6D RID: 11373 RVA: 0x000EB0DC File Offset: 0x000E92DC
			public string Value { get; set; }

			// Token: 0x17000B96 RID: 2966
			// (get) Token: 0x06002C6E RID: 11374 RVA: 0x000EB0E5 File Offset: 0x000E92E5
			// (set) Token: 0x06002C6F RID: 11375 RVA: 0x000EB0ED File Offset: 0x000E92ED
			public string Message { get; set; }

			// Token: 0x06002C70 RID: 11376 RVA: 0x000EB0F8 File Offset: 0x000E92F8
			public static CalibHandEyeWorkflowService.TagReadValue Ok(string value)
			{
				return new CalibHandEyeWorkflowService.TagReadValue
				{
					Success = true,
					Value = value
				};
			}

			// Token: 0x06002C71 RID: 11377 RVA: 0x000EB120 File Offset: 0x000E9320
			public static CalibHandEyeWorkflowService.TagReadValue Fail(string message)
			{
				return new CalibHandEyeWorkflowService.TagReadValue
				{
					Success = false,
					Message = message
				};
			}

			// Token: 0x06002C72 RID: 11378 RVA: 0x000EB148 File Offset: 0x000E9348
			public static CalibHandEyeWorkflowService.TagReadValue Canceled()
			{
				return new CalibHandEyeWorkflowService.TagReadValue
				{
					IsCanceled = true,
					Message = "Canceled."
				};
			}
		}
	}
}
