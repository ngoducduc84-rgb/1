﻿using System;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000237 RID: 567
	internal static class CircleFit
	{
		// Token: 0x0600200A RID: 8202 RVA: 0x000BBBEC File Offset: 0x000B9DEC
		public static bool TryFit(double[] x, double[] y, out double centerX, out double centerY, out double radius, out double rmsError)
		{
			centerX = 0.0;
			centerY = 0.0;
			radius = 0.0;
			rmsError = 0.0;
			bool flag = x == null || y == null || x.Length != y.Length || x.Length < 3;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				int i = x.Length;
				double sxx = 0.0;
				double sxy = 0.0;
				double syy = 0.0;
				double sx = 0.0;
				double sy = 0.0;
				double sxz = 0.0;
				double syz = 0.0;
				double sz = 0.0;
				for (int j = 0; j < i; j++)
				{
					double xi = x[j];
					double yi = y[j];
					double zi = xi * xi + yi * yi;
					sxx += xi * xi;
					sxy += xi * yi;
					syy += yi * yi;
					sx += xi;
					sy += yi;
					sxz += xi * zi;
					syz += yi * zi;
					sz += zi;
				}
				double det = sxx * (syy * (double)i - sy * sy) - sxy * (sxy * (double)i - sy * sx) + sx * (sxy * sy - syy * sx);
				bool flag2 = Math.Abs(det) < 1E-09;
				if (flag2)
				{
					result = false;
				}
				else
				{
					double dD = sxz * (syy * (double)i - sy * sy) - sxy * (syz * (double)i - sy * sz) + sx * (syz * sy - syy * sz);
					double dE = sxx * (syz * (double)i - sz * sy) - sxz * (sxy * (double)i - sx * sy) + sx * (sxy * sz - syz * sx);
					double dF = sxx * (syy * sz - syz * sy) - sxy * (sxy * sz - syz * sx) + sxz * (sxy * sy - syy * sx);
					double dCoeff = dD / det;
					double eCoeff = dE / det;
					double fCoeff = dF / det;
					centerX = dCoeff / 2.0;
					centerY = eCoeff / 2.0;
					double radiusSquared = fCoeff + centerX * centerX + centerY * centerY;
					bool flag3 = radiusSquared <= 0.0;
					if (flag3)
					{
						result = false;
					}
					else
					{
						radius = Math.Sqrt(radiusSquared);
						double sumSq = 0.0;
						for (int k = 0; k < i; k++)
						{
							double dist = Math.Sqrt((x[k] - centerX) * (x[k] - centerX) + (y[k] - centerY) * (y[k] - centerY));
							double err = dist - radius;
							sumSq += err * err;
						}
						rmsError = Math.Sqrt(sumSq / (double)i);
						result = true;
					}
				}
			}
			return result;
		}
	}
}
