﻿using System;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000235 RID: 565
	public class HandEyeCalibrationResult
	{
		// Token: 0x17000978 RID: 2424
		// (get) Token: 0x06001FE4 RID: 8164 RVA: 0x000BB335 File Offset: 0x000B9535
		// (set) Token: 0x06001FE5 RID: 8165 RVA: 0x000BB33D File Offset: 0x000B953D
		public bool IsSuccess { get; set; }

		// Token: 0x17000979 RID: 2425
		// (get) Token: 0x06001FE6 RID: 8166 RVA: 0x000BB346 File Offset: 0x000B9546
		// (set) Token: 0x06001FE7 RID: 8167 RVA: 0x000BB34E File Offset: 0x000B954E
		public string Message { get; set; }

		// Token: 0x1700097A RID: 2426
		// (get) Token: 0x06001FE8 RID: 8168 RVA: 0x000BB357 File Offset: 0x000B9557
		// (set) Token: 0x06001FE9 RID: 8169 RVA: 0x000BB35F File Offset: 0x000B955F
		public int PointCount { get; set; }

		// Token: 0x1700097B RID: 2427
		// (get) Token: 0x06001FEA RID: 8170 RVA: 0x000BB368 File Offset: 0x000B9568
		// (set) Token: 0x06001FEB RID: 8171 RVA: 0x000BB370 File Offset: 0x000B9570
		public double[] HomMat2D { get; set; }

		// Token: 0x1700097C RID: 2428
		// (get) Token: 0x06001FEC RID: 8172 RVA: 0x000BB379 File Offset: 0x000B9579
		// (set) Token: 0x06001FED RID: 8173 RVA: 0x000BB381 File Offset: 0x000B9581
		public double[] InvHomMat2D { get; set; }

		// Token: 0x1700097D RID: 2429
		// (get) Token: 0x06001FEE RID: 8174 RVA: 0x000BB38A File Offset: 0x000B958A
		// (set) Token: 0x06001FEF RID: 8175 RVA: 0x000BB392 File Offset: 0x000B9592
		public double PixelSizeX { get; set; }

		// Token: 0x1700097E RID: 2430
		// (get) Token: 0x06001FF0 RID: 8176 RVA: 0x000BB39B File Offset: 0x000B959B
		// (set) Token: 0x06001FF1 RID: 8177 RVA: 0x000BB3A3 File Offset: 0x000B95A3
		public double PixelSizeY { get; set; }

		// Token: 0x1700097F RID: 2431
		// (get) Token: 0x06001FF2 RID: 8178 RVA: 0x000BB3AC File Offset: 0x000B95AC
		// (set) Token: 0x06001FF3 RID: 8179 RVA: 0x000BB3B4 File Offset: 0x000B95B4
		public double RotationDeg { get; set; }

		// Token: 0x17000980 RID: 2432
		// (get) Token: 0x06001FF4 RID: 8180 RVA: 0x000BB3BD File Offset: 0x000B95BD
		// (set) Token: 0x06001FF5 RID: 8181 RVA: 0x000BB3C5 File Offset: 0x000B95C5
		public double SlantDeg { get; set; }

		// Token: 0x17000981 RID: 2433
		// (get) Token: 0x06001FF6 RID: 8182 RVA: 0x000BB3CE File Offset: 0x000B95CE
		// (set) Token: 0x06001FF7 RID: 8183 RVA: 0x000BB3D6 File Offset: 0x000B95D6
		public double TranslationX { get; set; }

		// Token: 0x17000982 RID: 2434
		// (get) Token: 0x06001FF8 RID: 8184 RVA: 0x000BB3DF File Offset: 0x000B95DF
		// (set) Token: 0x06001FF9 RID: 8185 RVA: 0x000BB3E7 File Offset: 0x000B95E7
		public double TranslationY { get; set; }

		// Token: 0x17000983 RID: 2435
		// (get) Token: 0x06001FFA RID: 8186 RVA: 0x000BB3F0 File Offset: 0x000B95F0
		// (set) Token: 0x06001FFB RID: 8187 RVA: 0x000BB3F8 File Offset: 0x000B95F8
		public double AngleOffsetDeg { get; set; }

		// Token: 0x17000984 RID: 2436
		// (get) Token: 0x06001FFC RID: 8188 RVA: 0x000BB401 File Offset: 0x000B9601
		// (set) Token: 0x06001FFD RID: 8189 RVA: 0x000BB409 File Offset: 0x000B9609
		public double RmsErrorMm { get; set; }

		// Token: 0x17000985 RID: 2437
		// (get) Token: 0x06001FFE RID: 8190 RVA: 0x000BB412 File Offset: 0x000B9612
		// (set) Token: 0x06001FFF RID: 8191 RVA: 0x000BB41A File Offset: 0x000B961A
		public double MaxErrorMm { get; set; }

		// Token: 0x17000986 RID: 2438
		// (get) Token: 0x06002000 RID: 8192 RVA: 0x000BB423 File Offset: 0x000B9623
		// (set) Token: 0x06002001 RID: 8193 RVA: 0x000BB42B File Offset: 0x000B962B
		public double ReprojectionErrorPx { get; set; }

		// Token: 0x17000987 RID: 2439
		// (get) Token: 0x06002002 RID: 8194 RVA: 0x000BB434 File Offset: 0x000B9634
		// (set) Token: 0x06002003 RID: 8195 RVA: 0x000BB43C File Offset: 0x000B963C
		public string CreatedAt { get; set; }

		// Token: 0x06002004 RID: 8196 RVA: 0x000BB448 File Offset: 0x000B9648
		public static HandEyeCalibrationResult Failed(string message)
		{
			return new HandEyeCalibrationResult
			{
				IsSuccess = false,
				Message = message
			};
		}
	}
}
