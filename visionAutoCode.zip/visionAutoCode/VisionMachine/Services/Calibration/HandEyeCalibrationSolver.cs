﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using HalconDotNet;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000233 RID: 563
	public static class HandEyeCalibrationSolver
	{
		// Token: 0x06001FCA RID: 8138 RVA: 0x000BAB1C File Offset: 0x000B8D1C
		public static HandEyeCalibrationResult Solve(IList<HandEyeSamplePoint> samples)
		{
			List<HandEyeSamplePoint> points = (from x in samples ?? new List<HandEyeSamplePoint>()
			where x != null && x.IsValid
			select x).ToList<HandEyeSamplePoint>();
			bool flag = points.Count < 3;
			HandEyeCalibrationResult result;
			if (flag)
			{
				result = HandEyeCalibrationResult.Failed(string.Format("Need at least {0} valid calibration points, but only {1} are available.", 3, points.Count));
			}
			else
			{
				try
				{
					HTuple imageX = new HTuple((from p in points
					select p.ImageX).ToArray<double>());
					HTuple imageY = new HTuple((from p in points
					select p.ImageY).ToArray<double>());
					HTuple robotX = new HTuple((from p in points
					select p.RobotX).ToArray<double>());
					HTuple robotY = new HTuple((from p in points
					select p.RobotY).ToArray<double>());
					HTuple homMat2D;
					HOperatorSet.VectorToHomMat2d(imageX, imageY, robotX, robotY, out homMat2D);
					HTuple invHomMat2D;
					HOperatorSet.HomMat2dInvert(homMat2D, out invHomMat2D);
					HTuple mappedX;
					HTuple mappedY;
					HOperatorSet.AffineTransPoint2d(homMat2D, imageX, imageY, out mappedX, out mappedY);
					double sumSqMm = 0.0;
					double maxErrMm = 0.0;
					for (int i = 0; i < points.Count; i++)
					{
						double dx = mappedX[i].D - points[i].RobotX;
						double dy = mappedY[i].D - points[i].RobotY;
						double err = Math.Sqrt(dx * dx + dy * dy);
						sumSqMm += err * err;
						bool flag2 = err > maxErrMm;
						if (flag2)
						{
							maxErrMm = err;
						}
					}
					double rmsMm = Math.Sqrt(sumSqMm / (double)points.Count);
					HTuple reprojX;
					HTuple reprojY;
					HOperatorSet.AffineTransPoint2d(invHomMat2D, robotX, robotY, out reprojX, out reprojY);
					double sumSqPx = 0.0;
					for (int j = 0; j < points.Count; j++)
					{
						double dx2 = reprojX[j].D - points[j].ImageX;
						double dy2 = reprojY[j].D - points[j].ImageY;
						sumSqPx += dx2 * dx2 + dy2 * dy2;
					}
					double reprojectionPx = Math.Sqrt(sumSqPx / (double)points.Count);
					HTuple sx;
					HTuple sy;
					HTuple phi;
					HTuple theta;
					HTuple tx;
					HTuple ty;
					HOperatorSet.HomMat2dToAffinePar(homMat2D, out sx, out sy, out phi, out theta, out tx, out ty);
					double rotationDeg = HandEyeCalibrationSolver.NormalizeDegree(HandEyeCalibrationSolver.RadToDeg(phi.D));
					double slantDeg = HandEyeCalibrationSolver.RadToDeg(theta.D);
					double angleOffsetDeg = HandEyeCalibrationSolver.ComputeAngleOffset(points, homMat2D);
					result = new HandEyeCalibrationResult
					{
						IsSuccess = true,
						Message = string.Format("Calibration solved with {0} points. RMS = {1:0.####} mm.", points.Count, rmsMm),
						PointCount = points.Count,
						HomMat2D = HandEyeCalibrationSolver.ToArray(homMat2D),
						InvHomMat2D = HandEyeCalibrationSolver.ToArray(invHomMat2D),
						PixelSizeX = Math.Abs(sx.D),
						PixelSizeY = Math.Abs(sy.D),
						RotationDeg = rotationDeg,
						SlantDeg = slantDeg,
						TranslationX = tx.D,
						TranslationY = ty.D,
						AngleOffsetDeg = angleOffsetDeg,
						RmsErrorMm = rmsMm,
						MaxErrorMm = maxErrMm,
						ReprojectionErrorPx = reprojectionPx,
						CreatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
					};
				}
				catch (Exception ex)
				{
					result = HandEyeCalibrationResult.Failed("Calibration solve failed: " + ex.Message);
				}
			}
			return result;
		}

		// Token: 0x06001FCB RID: 8139 RVA: 0x000BAF2C File Offset: 0x000B912C
		public static bool TryMapImageToRobot(HandEyeCalibrationResult result, double imageX, double imageY, out double robotX, out double robotY)
		{
			robotX = 0.0;
			robotY = 0.0;
			bool flag = result == null || !result.IsSuccess || result.HomMat2D == null || result.HomMat2D.Length < 6;
			bool result2;
			if (flag)
			{
				result2 = false;
			}
			else
			{
				HTuple homMat2D = new HTuple(result.HomMat2D);
				HTuple qx;
				HTuple qy;
				HOperatorSet.AffineTransPoint2d(homMat2D, imageX, imageY, out qx, out qy);
				robotX = qx.D;
				robotY = qy.D;
				result2 = true;
			}
			return result2;
		}

		// Token: 0x06001FCC RID: 8140 RVA: 0x000BAFB8 File Offset: 0x000B91B8
		public static double MapImageAngleToRobotAngleDeg(double visionAngleDeg, HTuple homMat2D)
		{
			bool flag = homMat2D == null || homMat2D.Length < 6;
			double result;
			if (flag)
			{
				result = HandEyeCalibrationSolver.NormalizeDegree(visionAngleDeg);
			}
			else
			{
				double angleRad = HandEyeCalibrationSolver.DegToRad(visionAngleDeg);
				double imageDx = Math.Cos(angleRad);
				double imageDy = Math.Sin(angleRad);
				double robotDx = homMat2D[0].D * imageDx + homMat2D[1].D * imageDy;
				double robotDy = homMat2D[3].D * imageDx + homMat2D[4].D * imageDy;
				bool flag2 = Math.Abs(robotDx) < 1E-12 && Math.Abs(robotDy) < 1E-12;
				if (flag2)
				{
					result = HandEyeCalibrationSolver.NormalizeDegree(visionAngleDeg);
				}
				else
				{
					result = HandEyeCalibrationSolver.NormalizeDegree(HandEyeCalibrationSolver.RadToDeg(Math.Atan2(robotDy, robotDx)));
				}
			}
			return result;
		}

		// Token: 0x06001FCD RID: 8141 RVA: 0x000BB088 File Offset: 0x000B9288
		public static double MapImageAngleToRobotAngleDeg(double visionAngleDeg, double[] homMat2D)
		{
			bool flag = homMat2D == null || homMat2D.Length < 6;
			double result;
			if (flag)
			{
				result = HandEyeCalibrationSolver.NormalizeDegree(visionAngleDeg);
			}
			else
			{
				result = HandEyeCalibrationSolver.MapImageAngleToRobotAngleDeg(visionAngleDeg, new HTuple(homMat2D));
			}
			return result;
		}

		// Token: 0x06001FCE RID: 8142 RVA: 0x000BB0C0 File Offset: 0x000B92C0
		private static double ComputeAngleOffset(IList<HandEyeSamplePoint> points, HTuple homMat2D)
		{
			double sumSin = 0.0;
			double sumCos = 0.0;
			foreach (HandEyeSamplePoint point in points)
			{
				double mappedVisionAngle = HandEyeCalibrationSolver.MapImageAngleToRobotAngleDeg(point.VisionAngle, homMat2D);
				double diffRad = HandEyeCalibrationSolver.DegToRad(point.RobotRz - mappedVisionAngle);
				sumSin += Math.Sin(diffRad);
				sumCos += Math.Cos(diffRad);
			}
			bool flag = Math.Abs(sumSin) < 1E-12 && Math.Abs(sumCos) < 1E-12;
			double result;
			if (flag)
			{
				result = 0.0;
			}
			else
			{
				result = HandEyeCalibrationSolver.NormalizeDegree(HandEyeCalibrationSolver.RadToDeg(Math.Atan2(sumSin, sumCos)));
			}
			return result;
		}

		// Token: 0x06001FCF RID: 8143 RVA: 0x000BB19C File Offset: 0x000B939C
		private static double[] ToArray(HTuple tuple)
		{
			bool flag = tuple == null;
			double[] result;
			if (flag)
			{
				result = new double[0];
			}
			else
			{
				double[] values = new double[tuple.Length];
				for (int i = 0; i < tuple.Length; i++)
				{
					values[i] = tuple[i].D;
				}
				result = values;
			}
			return result;
		}

		// Token: 0x06001FD0 RID: 8144 RVA: 0x000BB1F4 File Offset: 0x000B93F4
		private static double RadToDeg(double radians)
		{
			return radians * 180.0 / 3.141592653589793;
		}

		// Token: 0x06001FD1 RID: 8145 RVA: 0x000BB21C File Offset: 0x000B941C
		private static double DegToRad(double degrees)
		{
			return degrees * 3.141592653589793 / 180.0;
		}

		// Token: 0x06001FD2 RID: 8146 RVA: 0x000BB244 File Offset: 0x000B9444
		private static double NormalizeDegree(double degrees)
		{
			double value = degrees % 360.0;
			bool flag = value > 180.0;
			if (flag)
			{
				value -= 360.0;
			}
			else
			{
				bool flag2 = value < -180.0;
				if (flag2)
				{
					value += 360.0;
				}
			}
			return value;
		}

		// Token: 0x04000D42 RID: 3394
		private const int MinimumPointCount = 3;
	}
}
