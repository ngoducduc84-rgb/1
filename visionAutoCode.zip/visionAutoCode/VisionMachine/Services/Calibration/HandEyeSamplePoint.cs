﻿using System;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000234 RID: 564
	public class HandEyeSamplePoint
	{
		// Token: 0x17000970 RID: 2416
		// (get) Token: 0x06001FD3 RID: 8147 RVA: 0x000BB29D File Offset: 0x000B949D
		// (set) Token: 0x06001FD4 RID: 8148 RVA: 0x000BB2A5 File Offset: 0x000B94A5
		public int Index { get; set; }

		// Token: 0x17000971 RID: 2417
		// (get) Token: 0x06001FD5 RID: 8149 RVA: 0x000BB2AE File Offset: 0x000B94AE
		// (set) Token: 0x06001FD6 RID: 8150 RVA: 0x000BB2B6 File Offset: 0x000B94B6
		public double ImageX { get; set; }

		// Token: 0x17000972 RID: 2418
		// (get) Token: 0x06001FD7 RID: 8151 RVA: 0x000BB2BF File Offset: 0x000B94BF
		// (set) Token: 0x06001FD8 RID: 8152 RVA: 0x000BB2C7 File Offset: 0x000B94C7
		public double ImageY { get; set; }

		// Token: 0x17000973 RID: 2419
		// (get) Token: 0x06001FD9 RID: 8153 RVA: 0x000BB2D0 File Offset: 0x000B94D0
		// (set) Token: 0x06001FDA RID: 8154 RVA: 0x000BB2D8 File Offset: 0x000B94D8
		public double VisionAngle { get; set; }

		// Token: 0x17000974 RID: 2420
		// (get) Token: 0x06001FDB RID: 8155 RVA: 0x000BB2E1 File Offset: 0x000B94E1
		// (set) Token: 0x06001FDC RID: 8156 RVA: 0x000BB2E9 File Offset: 0x000B94E9
		public double RobotX { get; set; }

		// Token: 0x17000975 RID: 2421
		// (get) Token: 0x06001FDD RID: 8157 RVA: 0x000BB2F2 File Offset: 0x000B94F2
		// (set) Token: 0x06001FDE RID: 8158 RVA: 0x000BB2FA File Offset: 0x000B94FA
		public double RobotY { get; set; }

		// Token: 0x17000976 RID: 2422
		// (get) Token: 0x06001FDF RID: 8159 RVA: 0x000BB303 File Offset: 0x000B9503
		// (set) Token: 0x06001FE0 RID: 8160 RVA: 0x000BB30B File Offset: 0x000B950B
		public double RobotRz { get; set; }

		// Token: 0x17000977 RID: 2423
		// (get) Token: 0x06001FE1 RID: 8161 RVA: 0x000BB314 File Offset: 0x000B9514
		// (set) Token: 0x06001FE2 RID: 8162 RVA: 0x000BB31C File Offset: 0x000B951C
		public bool IsValid { get; set; } = true;
	}
}
