﻿using System;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000238 RID: 568
	public class TcpCalibrationResult
	{
		// Token: 0x17000988 RID: 2440
		// (get) Token: 0x0600200B RID: 8203 RVA: 0x000BBEB3 File Offset: 0x000BA0B3
		// (set) Token: 0x0600200C RID: 8204 RVA: 0x000BBEBB File Offset: 0x000BA0BB
		public bool IsSuccess { get; set; }

		// Token: 0x17000989 RID: 2441
		// (get) Token: 0x0600200D RID: 8205 RVA: 0x000BBEC4 File Offset: 0x000BA0C4
		// (set) Token: 0x0600200E RID: 8206 RVA: 0x000BBECC File Offset: 0x000BA0CC
		public string Message { get; set; }

		// Token: 0x1700098A RID: 2442
		// (get) Token: 0x0600200F RID: 8207 RVA: 0x000BBED5 File Offset: 0x000BA0D5
		// (set) Token: 0x06002010 RID: 8208 RVA: 0x000BBEDD File Offset: 0x000BA0DD
		public HandEyeCalibrationResult Mapping { get; set; }

		// Token: 0x1700098B RID: 2443
		// (get) Token: 0x06002011 RID: 8209 RVA: 0x000BBEE6 File Offset: 0x000BA0E6
		// (set) Token: 0x06002012 RID: 8210 RVA: 0x000BBEEE File Offset: 0x000BA0EE
		public int RotationPointCount { get; set; }

		// Token: 0x1700098C RID: 2444
		// (get) Token: 0x06002013 RID: 8211 RVA: 0x000BBEF7 File Offset: 0x000BA0F7
		// (set) Token: 0x06002014 RID: 8212 RVA: 0x000BBEFF File Offset: 0x000BA0FF
		public double CircleCenterImageX { get; set; }

		// Token: 0x1700098D RID: 2445
		// (get) Token: 0x06002015 RID: 8213 RVA: 0x000BBF08 File Offset: 0x000BA108
		// (set) Token: 0x06002016 RID: 8214 RVA: 0x000BBF10 File Offset: 0x000BA110
		public double CircleCenterImageY { get; set; }

		// Token: 0x1700098E RID: 2446
		// (get) Token: 0x06002017 RID: 8215 RVA: 0x000BBF19 File Offset: 0x000BA119
		// (set) Token: 0x06002018 RID: 8216 RVA: 0x000BBF21 File Offset: 0x000BA121
		public double CircleRadiusPx { get; set; }

		// Token: 0x1700098F RID: 2447
		// (get) Token: 0x06002019 RID: 8217 RVA: 0x000BBF2A File Offset: 0x000BA12A
		// (set) Token: 0x0600201A RID: 8218 RVA: 0x000BBF32 File Offset: 0x000BA132
		public double CircleFitRmsPx { get; set; }

		// Token: 0x17000990 RID: 2448
		// (get) Token: 0x0600201B RID: 8219 RVA: 0x000BBF3B File Offset: 0x000BA13B
		// (set) Token: 0x0600201C RID: 8220 RVA: 0x000BBF43 File Offset: 0x000BA143
		public double CircleCenterRobotX { get; set; }

		// Token: 0x17000991 RID: 2449
		// (get) Token: 0x0600201D RID: 8221 RVA: 0x000BBF4C File Offset: 0x000BA14C
		// (set) Token: 0x0600201E RID: 8222 RVA: 0x000BBF54 File Offset: 0x000BA154
		public double CircleCenterRobotY { get; set; }

		// Token: 0x17000992 RID: 2450
		// (get) Token: 0x0600201F RID: 8223 RVA: 0x000BBF5D File Offset: 0x000BA15D
		// (set) Token: 0x06002020 RID: 8224 RVA: 0x000BBF65 File Offset: 0x000BA165
		public double CrossReferenceRobotX { get; set; }

		// Token: 0x17000993 RID: 2451
		// (get) Token: 0x06002021 RID: 8225 RVA: 0x000BBF6E File Offset: 0x000BA16E
		// (set) Token: 0x06002022 RID: 8226 RVA: 0x000BBF76 File Offset: 0x000BA176
		public double CrossReferenceRobotY { get; set; }

		// Token: 0x17000994 RID: 2452
		// (get) Token: 0x06002023 RID: 8227 RVA: 0x000BBF7F File Offset: 0x000BA17F
		// (set) Token: 0x06002024 RID: 8228 RVA: 0x000BBF87 File Offset: 0x000BA187
		public double RadiusMm { get; set; }

		// Token: 0x17000995 RID: 2453
		// (get) Token: 0x06002025 RID: 8229 RVA: 0x000BBF90 File Offset: 0x000BA190
		// (set) Token: 0x06002026 RID: 8230 RVA: 0x000BBF98 File Offset: 0x000BA198
		public double TcpOffsetBaseX { get; set; }

		// Token: 0x17000996 RID: 2454
		// (get) Token: 0x06002027 RID: 8231 RVA: 0x000BBFA1 File Offset: 0x000BA1A1
		// (set) Token: 0x06002028 RID: 8232 RVA: 0x000BBFA9 File Offset: 0x000BA1A9
		public double TcpOffsetBaseY { get; set; }

		// Token: 0x17000997 RID: 2455
		// (get) Token: 0x06002029 RID: 8233 RVA: 0x000BBFB2 File Offset: 0x000BA1B2
		// (set) Token: 0x0600202A RID: 8234 RVA: 0x000BBFBA File Offset: 0x000BA1BA
		public double TcpOffsetMagnitude { get; set; }

		// Token: 0x17000998 RID: 2456
		// (get) Token: 0x0600202B RID: 8235 RVA: 0x000BBFC3 File Offset: 0x000BA1C3
		// (set) Token: 0x0600202C RID: 8236 RVA: 0x000BBFCB File Offset: 0x000BA1CB
		public double TcpOffsetToolX { get; set; }

		// Token: 0x17000999 RID: 2457
		// (get) Token: 0x0600202D RID: 8237 RVA: 0x000BBFD4 File Offset: 0x000BA1D4
		// (set) Token: 0x0600202E RID: 8238 RVA: 0x000BBFDC File Offset: 0x000BA1DC
		public double TcpOffsetToolY { get; set; }

		// Token: 0x1700099A RID: 2458
		// (get) Token: 0x0600202F RID: 8239 RVA: 0x000BBFE5 File Offset: 0x000BA1E5
		// (set) Token: 0x06002030 RID: 8240 RVA: 0x000BBFED File Offset: 0x000BA1ED
		public double ReferenceRotationRz { get; set; }

		// Token: 0x1700099B RID: 2459
		// (get) Token: 0x06002031 RID: 8241 RVA: 0x000BBFF6 File Offset: 0x000BA1F6
		// (set) Token: 0x06002032 RID: 8242 RVA: 0x000BBFFE File Offset: 0x000BA1FE
		public double ReferenceImageX { get; set; }

		// Token: 0x1700099C RID: 2460
		// (get) Token: 0x06002033 RID: 8243 RVA: 0x000BC007 File Offset: 0x000BA207
		// (set) Token: 0x06002034 RID: 8244 RVA: 0x000BC00F File Offset: 0x000BA20F
		public double ReferenceImageY { get; set; }

		// Token: 0x1700099D RID: 2461
		// (get) Token: 0x06002035 RID: 8245 RVA: 0x000BC018 File Offset: 0x000BA218
		// (set) Token: 0x06002036 RID: 8246 RVA: 0x000BC020 File Offset: 0x000BA220
		public double ReferenceVisionAngle { get; set; }

		// Token: 0x1700099E RID: 2462
		// (get) Token: 0x06002037 RID: 8247 RVA: 0x000BC029 File Offset: 0x000BA229
		// (set) Token: 0x06002038 RID: 8248 RVA: 0x000BC031 File Offset: 0x000BA231
		public double MappingVisionAngle { get; set; }

		// Token: 0x1700099F RID: 2463
		// (get) Token: 0x06002039 RID: 8249 RVA: 0x000BC03A File Offset: 0x000BA23A
		// (set) Token: 0x0600203A RID: 8250 RVA: 0x000BC042 File Offset: 0x000BA242
		public double FlangeMeanX { get; set; }

		// Token: 0x170009A0 RID: 2464
		// (get) Token: 0x0600203B RID: 8251 RVA: 0x000BC04B File Offset: 0x000BA24B
		// (set) Token: 0x0600203C RID: 8252 RVA: 0x000BC053 File Offset: 0x000BA253
		public double FlangeMeanY { get; set; }

		// Token: 0x170009A1 RID: 2465
		// (get) Token: 0x0600203D RID: 8253 RVA: 0x000BC05C File Offset: 0x000BA25C
		// (set) Token: 0x0600203E RID: 8254 RVA: 0x000BC064 File Offset: 0x000BA264
		public double ObservedMeanRobotX { get; set; }

		// Token: 0x170009A2 RID: 2466
		// (get) Token: 0x0600203F RID: 8255 RVA: 0x000BC06D File Offset: 0x000BA26D
		// (set) Token: 0x06002040 RID: 8256 RVA: 0x000BC075 File Offset: 0x000BA275
		public double ObservedMeanRobotY { get; set; }

		// Token: 0x170009A3 RID: 2467
		// (get) Token: 0x06002041 RID: 8257 RVA: 0x000BC07E File Offset: 0x000BA27E
		// (set) Token: 0x06002042 RID: 8258 RVA: 0x000BC086 File Offset: 0x000BA286
		public bool TcpAppliedToMapping { get; set; }

		// Token: 0x170009A4 RID: 2468
		// (get) Token: 0x06002043 RID: 8259 RVA: 0x000BC08F File Offset: 0x000BA28F
		// (set) Token: 0x06002044 RID: 8260 RVA: 0x000BC097 File Offset: 0x000BA297
		public double MappingReprojectionBeforePx { get; set; }

		// Token: 0x170009A5 RID: 2469
		// (get) Token: 0x06002045 RID: 8261 RVA: 0x000BC0A0 File Offset: 0x000BA2A0
		// (set) Token: 0x06002046 RID: 8262 RVA: 0x000BC0A8 File Offset: 0x000BA2A8
		public double MappingReprojectionAfterPx { get; set; }

		// Token: 0x170009A6 RID: 2470
		// (get) Token: 0x06002047 RID: 8263 RVA: 0x000BC0B1 File Offset: 0x000BA2B1
		// (set) Token: 0x06002048 RID: 8264 RVA: 0x000BC0B9 File Offset: 0x000BA2B9
		public string CreatedAt { get; set; }

		// Token: 0x06002049 RID: 8265 RVA: 0x000BC0C4 File Offset: 0x000BA2C4
		public static TcpCalibrationResult Failed(string message)
		{
			return new TcpCalibrationResult
			{
				IsSuccess = false,
				Message = message
			};
		}
	}
}
