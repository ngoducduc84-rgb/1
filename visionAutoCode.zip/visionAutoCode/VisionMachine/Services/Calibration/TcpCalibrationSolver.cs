﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace VisionMachine.Services.Calibration
{
	// Token: 0x02000236 RID: 566
	public static class TcpCalibrationSolver
	{
		// Token: 0x06002006 RID: 8198 RVA: 0x000BB470 File Offset: 0x000B9670
		public static TcpCalibrationResult Solve(IList<HandEyeSamplePoint> mappingSamples, IList<HandEyeSamplePoint> rotationSamples)
		{
			return TcpCalibrationSolver.Solve(mappingSamples, rotationSamples, false);
		}

		// Token: 0x06002007 RID: 8199 RVA: 0x000BB48C File Offset: 0x000B968C
		public static TcpCalibrationResult Solve(IList<HandEyeSamplePoint> mappingSamples, IList<HandEyeSamplePoint> rotationSamples, bool applyTcpToMapping)
		{
			HandEyeCalibrationResult mapping = HandEyeCalibrationSolver.Solve(mappingSamples);
			bool flag = !mapping.IsSuccess;
			TcpCalibrationResult result;
			if (flag)
			{
				result = TcpCalibrationResult.Failed("Mapping (step 1) calibration failed: " + mapping.Message);
			}
			else
			{
				List<HandEyeSamplePoint> rotation = (from x in rotationSamples ?? new List<HandEyeSamplePoint>()
				where x != null && x.IsValid
				select x).ToList<HandEyeSamplePoint>();
				bool flag2 = rotation.Count < 3;
				if (flag2)
				{
					result = TcpCalibrationResult.Failed(string.Format("Need at least {0} valid rotation points for circle fit, got {1}.", 3, rotation.Count));
				}
				else
				{
					double centerImageX;
					double centerImageY;
					double radiusPx;
					double fitRmsPx;
					bool fitted = CircleFit.TryFit((from p in rotation
					select p.ImageX).ToArray<double>(), (from p in rotation
					select p.ImageY).ToArray<double>(), out centerImageX, out centerImageY, out radiusPx, out fitRmsPx);
					bool flag3 = !fitted;
					if (flag3)
					{
						result = TcpCalibrationResult.Failed("Circle fit failed (rotation points may be collinear).");
					}
					else
					{
						double flangeX = rotation.Average((HandEyeSamplePoint p) => p.RobotX);
						double flangeY = rotation.Average((HandEyeSamplePoint p) => p.RobotY);
						double centerRobotX = flangeX;
						double centerRobotY = flangeY;
						HandEyeSamplePoint reference = rotation[0];
						double mappingSumSin = 0.0;
						double mappingSumCos = 0.0;
						int mappingAngleCount = 0;
						foreach (HandEyeSamplePoint p3 in (mappingSamples ?? new List<HandEyeSamplePoint>()))
						{
							bool flag4 = p3 == null || !p3.IsValid;
							if (!flag4)
							{
								double rad = p3.VisionAngle * 3.141592653589793 / 180.0;
								mappingSumSin += Math.Sin(rad);
								mappingSumCos += Math.Cos(rad);
								mappingAngleCount++;
							}
						}
						double mappingVisionAngle = (mappingAngleCount > 0) ? (Math.Atan2(mappingSumSin, mappingSumCos) * 180.0 / 3.141592653589793) : reference.VisionAngle;
						double crossRobotX;
						double crossRobotY;
						HandEyeCalibrationSolver.TryMapImageToRobot(mapping, reference.ImageX, reference.ImageY, out crossRobotX, out crossRobotY);
						double offsetBaseX = centerRobotX - crossRobotX;
						double offsetBaseY = centerRobotY - crossRobotY;
						double offsetMagnitude = Math.Sqrt(offsetBaseX * offsetBaseX + offsetBaseY * offsetBaseY);
						double refRad = -reference.RobotRz * 3.141592653589793 / 180.0;
						double offsetToolX = Math.Cos(refRad) * offsetBaseX - Math.Sin(refRad) * offsetBaseY;
						double offsetToolY = Math.Sin(refRad) * offsetBaseX + Math.Cos(refRad) * offsetBaseY;
						double observedMeanRobotX;
						double observedMeanRobotY;
						TcpCalibrationSolver.ComputeObservedMeanRobot(mapping, rotation, out observedMeanRobotX, out observedMeanRobotY);
						HandEyeCalibrationResult finalMapping = mapping;
						double reprojBeforePx = mapping.ReprojectionErrorPx;
						double reprojAfterPx = reprojBeforePx;
						bool tcpAppliedToMapping = false;
						bool flag5 = applyTcpToMapping && (Math.Abs(centerImageX - reference.ImageX) > 1E-09 || Math.Abs(centerImageY - reference.ImageY) > 1E-09);
						if (flag5)
						{
							List<HandEyeSamplePoint> correctedMapping = new List<HandEyeSamplePoint>();
							foreach (HandEyeSamplePoint p2 in (mappingSamples ?? new List<HandEyeSamplePoint>()))
							{
								bool flag6 = p2 == null;
								if (!flag6)
								{
									double tcpImageX;
									double tcpImageY;
									TcpCalibrationSolver.TransformPatternToTcpImage(p2.ImageX, p2.ImageY, p2.VisionAngle, reference.ImageX, reference.ImageY, reference.VisionAngle, centerImageX, centerImageY, out tcpImageX, out tcpImageY);
									correctedMapping.Add(new HandEyeSamplePoint
									{
										Index = p2.Index,
										ImageX = tcpImageX,
										ImageY = tcpImageY,
										VisionAngle = p2.VisionAngle,
										RobotX = p2.RobotX,
										RobotY = p2.RobotY,
										RobotRz = p2.RobotRz,
										IsValid = p2.IsValid
									});
								}
							}
							HandEyeCalibrationResult corrected = HandEyeCalibrationSolver.Solve(correctedMapping);
							bool isSuccess = corrected.IsSuccess;
							if (isSuccess)
							{
								finalMapping = corrected;
								reprojAfterPx = corrected.ReprojectionErrorPx;
								tcpAppliedToMapping = true;
							}
						}
						result = new TcpCalibrationResult
						{
							IsSuccess = true,
							Message = string.Format("TCP solved. Offset = ({0:0.###}, {1:0.###}) mm, radius = {2:0.###} mm.", offsetBaseX, offsetBaseY, offsetMagnitude) + (tcpAppliedToMapping ? string.Format(" Mapping H corrected by TCP (reprojection {0:0.###} -> {1:0.###} px).", reprojBeforePx, reprojAfterPx) : string.Empty),
							Mapping = finalMapping,
							TcpAppliedToMapping = tcpAppliedToMapping,
							MappingReprojectionBeforePx = reprojBeforePx,
							MappingReprojectionAfterPx = reprojAfterPx,
							RotationPointCount = rotation.Count,
							CircleCenterImageX = centerImageX,
							CircleCenterImageY = centerImageY,
							CircleRadiusPx = radiusPx,
							CircleFitRmsPx = fitRmsPx,
							CircleCenterRobotX = centerRobotX,
							CircleCenterRobotY = centerRobotY,
							CrossReferenceRobotX = crossRobotX,
							CrossReferenceRobotY = crossRobotY,
							RadiusMm = offsetMagnitude,
							TcpOffsetBaseX = offsetBaseX,
							TcpOffsetBaseY = offsetBaseY,
							TcpOffsetMagnitude = offsetMagnitude,
							TcpOffsetToolX = offsetToolX,
							TcpOffsetToolY = offsetToolY,
							ReferenceRotationRz = reference.RobotRz,
							ReferenceImageX = reference.ImageX,
							ReferenceImageY = reference.ImageY,
							ReferenceVisionAngle = reference.VisionAngle,
							MappingVisionAngle = mappingVisionAngle,
							FlangeMeanX = flangeX,
							FlangeMeanY = flangeY,
							ObservedMeanRobotX = observedMeanRobotX,
							ObservedMeanRobotY = observedMeanRobotY,
							CreatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)
						};
					}
				}
			}
			return result;
		}

		// Token: 0x06002008 RID: 8200 RVA: 0x000BBAA4 File Offset: 0x000B9CA4
		public static void TransformPatternToTcpImage(double patternImageX, double patternImageY, double patternVisionAngleDeg, double referencePatternImageX, double referencePatternImageY, double referenceVisionAngleDeg, double referenceTcpImageX, double referenceTcpImageY, out double tcpImageX, out double tcpImageY)
		{
			double deltaAngleRad = -(patternVisionAngleDeg - referenceVisionAngleDeg) * 3.141592653589793 / 180.0;
			double cos = Math.Cos(deltaAngleRad);
			double sin = Math.Sin(deltaAngleRad);
			double offsetColumn = referenceTcpImageX - referencePatternImageX;
			double offsetRow = referenceTcpImageY - referencePatternImageY;
			double tcpColumn = patternImageX + offsetColumn * cos - offsetRow * sin;
			double tcpRow = patternImageY + offsetColumn * sin + offsetRow * cos;
			tcpImageX = tcpColumn;
			tcpImageY = tcpRow;
		}

		// Token: 0x06002009 RID: 8201 RVA: 0x000BBB08 File Offset: 0x000B9D08
		private static void ComputeObservedMeanRobot(HandEyeCalibrationResult mapping, IList<HandEyeSamplePoint> rotation, out double meanX, out double meanY)
		{
			meanX = 0.0;
			meanY = 0.0;
			bool flag = mapping == null || rotation == null || rotation.Count == 0;
			if (!flag)
			{
				double sumX = 0.0;
				double sumY = 0.0;
				int count = 0;
				foreach (HandEyeSamplePoint point in rotation)
				{
					double robotX;
					double robotY;
					bool flag2 = !HandEyeCalibrationSolver.TryMapImageToRobot(mapping, point.ImageX, point.ImageY, out robotX, out robotY);
					if (!flag2)
					{
						sumX += robotX;
						sumY += robotY;
						count++;
					}
				}
				bool flag3 = count <= 0;
				if (!flag3)
				{
					meanX = sumX / (double)count;
					meanY = sumY / (double)count;
				}
			}
		}

		// Token: 0x04000D5B RID: 3419
		private const int MinimumRotationPoints = 3;
	}
}
