﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using Basler.Pylon;
using HalconDotNet;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200023F RID: 575
	public sealed class BaslerLiveCameraService : IDisposable
	{
		// Token: 0x170009AC RID: 2476
		// (get) Token: 0x0600208D RID: 8333 RVA: 0x000BDD88 File Offset: 0x000BBF88
		public bool IsRunning
		{
			get
			{
				return this._worker != null && !this._worker.IsCompleted;
			}
		}

		// Token: 0x0600208E RID: 8334 RVA: 0x000BDDB4 File Offset: 0x000BBFB4
		public bool IsCameraConnected()
		{
			object cameraLock = this._cameraLock;
			bool result;
			lock (cameraLock)
			{
				try
				{
					result = (this._camera != null && this._camera.IsConnected);
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x0600208F RID: 8335 RVA: 0x000BDE20 File Offset: 0x000BC020
		public void Start(CameraParameterConfig config, HSmartWindowControlWPF display)
		{
			bool flag = config == null || display == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			if (!flag)
			{
				this.Stop();
				try
				{
					this._config = config;
					this._cameraId = config.ConnectedCameraId;
					CameraSnapshotService.Release(this._cameraId);
					this.OpenWithRetry();
					this.ApplyParameter(config);
					CameraHardwareRuntimeService.Register(this._cameraId, this);
					this._cancellation = new CancellationTokenSource();
					this._worker = Task.Run(delegate()
					{
						this.LiveLoop(display, this._cancellation.Token);
					}, this._cancellation.Token);
				}
				catch
				{
					this.Stop();
					throw;
				}
			}
		}

		// Token: 0x06002090 RID: 8336 RVA: 0x000BDEF0 File Offset: 0x000BC0F0
		private void OpenWithRetry()
		{
			Exception last = null;
			for (int attempt = 0; attempt < 5; attempt++)
			{
				try
				{
					bool flag = this._camera == null;
					if (flag)
					{
						this._camera = new Camera(this._cameraId);
					}
					this._camera.Open();
					return;
				}
				catch (Exception ex)
				{
					last = ex;
					try
					{
						Camera camera = this._camera;
						if (camera != null)
						{
							camera.Close();
						}
					}
					catch
					{
					}
					try
					{
						Camera camera2 = this._camera;
						if (camera2 != null)
						{
							camera2.Dispose();
						}
					}
					catch
					{
					}
					this._camera = null;
					bool flag2 = attempt < 4;
					if (flag2)
					{
						Thread.Sleep(400);
					}
				}
			}
			throw last ?? new InvalidOperationException("Failed to open camera '" + this._cameraId + "'.");
		}

		// Token: 0x06002091 RID: 8337 RVA: 0x000BDFEC File Offset: 0x000BC1EC
		public void Stop()
		{
			try
			{
				CancellationTokenSource cancellation = this._cancellation;
				if (cancellation != null)
				{
					cancellation.Cancel();
				}
				Task worker = this._worker;
				if (worker != null)
				{
					worker.Wait(1000);
				}
			}
			catch
			{
			}
			finally
			{
				CameraHardwareRuntimeService.Unregister(this._cameraId, this);
				this._cameraId = null;
				this._config = null;
				this._worker = null;
				this.DisposeLatestImage();
				CancellationTokenSource cancellation2 = this._cancellation;
				if (cancellation2 != null)
				{
					cancellation2.Dispose();
				}
				this._cancellation = null;
				try
				{
					Camera camera = this._camera;
					bool flag;
					if (camera == null)
					{
						flag = false;
					}
					else
					{
						IStreamGrabber streamGrabber = camera.StreamGrabber;
						flag = ((streamGrabber != null) ? new bool?(streamGrabber.IsGrabbing) : null).GetValueOrDefault();
					}
					bool flag2 = flag;
					if (flag2)
					{
						this._camera.StreamGrabber.Stop();
					}
				}
				catch
				{
				}
				try
				{
					Camera camera2 = this._camera;
					if (camera2 != null)
					{
						camera2.Close();
					}
					Camera camera3 = this._camera;
					if (camera3 != null)
					{
						camera3.Dispose();
					}
				}
				catch
				{
				}
				this._camera = null;
			}
		}

		// Token: 0x06002092 RID: 8338 RVA: 0x000BE130 File Offset: 0x000BC330
		public void Dispose()
		{
			this.Stop();
		}

		// Token: 0x06002093 RID: 8339 RVA: 0x000BE13C File Offset: 0x000BC33C
		public void SetExposure(double exposureTime)
		{
			object cameraLock = this._cameraLock;
			lock (cameraLock)
			{
				this.ApplyExposureValue(exposureTime);
			}
		}

		// Token: 0x06002094 RID: 8340 RVA: 0x000BE184 File Offset: 0x000BC384
		public void SetGain(double gain)
		{
			object cameraLock = this._cameraLock;
			lock (cameraLock)
			{
				this.ApplyGainValue(gain);
			}
		}

		// Token: 0x06002095 RID: 8341 RVA: 0x000BE1CC File Offset: 0x000BC3CC
		private void ApplyExposureValue(double exposureTime)
		{
			this.TrySetEnumValue(PLCamera.ExposureAuto, "Off");
			bool flag = this.TrySetFloatClamped(PLCamera.ExposureTime, exposureTime);
			if (!flag)
			{
				this.TrySetFloatClamped(PLCamera.ExposureTimeAbs, exposureTime);
			}
		}

		// Token: 0x06002096 RID: 8342 RVA: 0x000BE210 File Offset: 0x000BC410
		private void ApplyGainValue(double gain)
		{
			this.TrySetEnumValue(PLCamera.GainSelector, "All");
			this.TrySetEnumValue(PLCamera.GainAuto, "Off");
			bool flag = this.TrySetFloatClamped(PLCamera.Gain, gain);
			if (!flag)
			{
				this.TrySetIntClamped(PLCamera.GainRaw, gain);
			}
		}

		// Token: 0x06002097 RID: 8343 RVA: 0x000BE26C File Offset: 0x000BC46C
		private bool TrySetFloatClamped(FloatName name, double value)
		{
			bool result;
			try
			{
				Camera camera = this._camera;
				IFloatParameter parameter = (camera != null) ? camera.Parameters[name] : null;
				bool flag = parameter == null || !parameter.IsWritable;
				if (flag)
				{
					result = false;
				}
				else
				{
					double min = parameter.GetMinimum();
					double max = parameter.GetMaximum();
					double clamped = value;
					bool flag2 = clamped < min;
					if (flag2)
					{
						clamped = min;
					}
					bool flag3 = clamped > max;
					if (flag3)
					{
						clamped = max;
					}
					parameter.SetValue(clamped);
					result = true;
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06002098 RID: 8344 RVA: 0x000BE2FC File Offset: 0x000BC4FC
		private bool TrySetIntClamped(IntegerName name, double value)
		{
			bool result;
			try
			{
				Camera camera = this._camera;
				IIntegerParameter parameter = (camera != null) ? camera.Parameters[name] : null;
				bool flag = parameter == null || !parameter.IsWritable;
				if (flag)
				{
					result = false;
				}
				else
				{
					long min = parameter.GetMinimum();
					long max = parameter.GetMaximum();
					long increment = 1L;
					try
					{
						long inc = parameter.GetIncrement();
						bool flag2 = inc > 0L;
						if (flag2)
						{
							increment = inc;
						}
					}
					catch
					{
					}
					long clamped = (long)Math.Round(value);
					bool flag3 = clamped < min;
					if (flag3)
					{
						clamped = min;
					}
					bool flag4 = clamped > max;
					if (flag4)
					{
						clamped = max;
					}
					long offset = (clamped - min) % increment;
					bool flag5 = offset != 0L;
					if (flag5)
					{
						clamped -= offset;
					}
					parameter.SetValue(clamped);
					result = true;
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06002099 RID: 8345 RVA: 0x000BE3E8 File Offset: 0x000BC5E8
		public CameraParameterRange GetGainRange()
		{
			object cameraLock = this._cameraLock;
			CameraParameterRange result;
			lock (cameraLock)
			{
				result = (this.TryGetFloatRange(PLCamera.Gain) ?? this.TryGetIntRange(PLCamera.GainRaw));
			}
			return result;
		}

		// Token: 0x0600209A RID: 8346 RVA: 0x000BE444 File Offset: 0x000BC644
		public CameraParameterRange GetExposureRange()
		{
			object cameraLock = this._cameraLock;
			CameraParameterRange result;
			lock (cameraLock)
			{
				result = (this.TryGetFloatRange(PLCamera.ExposureTime) ?? this.TryGetFloatRange(PLCamera.ExposureTimeAbs));
			}
			return result;
		}

		// Token: 0x0600209B RID: 8347 RVA: 0x000BE4A0 File Offset: 0x000BC6A0
		private CameraParameterRange TryGetFloatRange(FloatName name)
		{
			CameraParameterRange result;
			try
			{
				Camera camera = this._camera;
				IFloatParameter parameter = (camera != null) ? camera.Parameters[name] : null;
				bool flag = parameter == null || !parameter.IsReadable;
				if (flag)
				{
					result = null;
				}
				else
				{
					result = new CameraParameterRange
					{
						Min = parameter.GetMinimum(),
						Max = parameter.GetMaximum(),
						IsInteger = false
					};
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600209C RID: 8348 RVA: 0x000BE520 File Offset: 0x000BC720
		private CameraParameterRange TryGetIntRange(IntegerName name)
		{
			CameraParameterRange result;
			try
			{
				Camera camera = this._camera;
				IIntegerParameter parameter = (camera != null) ? camera.Parameters[name] : null;
				bool flag = parameter == null || !parameter.IsReadable;
				if (flag)
				{
					result = null;
				}
				else
				{
					result = new CameraParameterRange
					{
						Min = (double)parameter.GetMinimum(),
						Max = (double)parameter.GetMaximum(),
						IsInteger = true
					};
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600209D RID: 8349 RVA: 0x000BE5A4 File Offset: 0x000BC7A4
		private void TrySetEnumValue(EnumName name, string value)
		{
			try
			{
				Camera camera = this._camera;
				IEnumParameter parameter = (camera != null) ? camera.Parameters[name] : null;
				bool flag = parameter == null || !parameter.IsWritable;
				if (!flag)
				{
					bool flag2 = parameter.CanSetValue(value);
					if (flag2)
					{
						parameter.SetValue(value);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600209E RID: 8350 RVA: 0x000BE60C File Offset: 0x000BC80C
		public void SetTriggerMode(bool enabled)
		{
			object cameraLock = this._cameraLock;
			lock (cameraLock)
			{
				this.TrySetStringParameter("TriggerSelector", "FrameStart");
				if (enabled)
				{
					this.TrySetStringParameter("TriggerSource", "Line1");
					this.TrySetStringParameter("TriggerActivation", "RisingEdge");
				}
				this.TrySetStringParameter("TriggerMode", enabled ? "On" : "Off");
			}
		}

		// Token: 0x0600209F RID: 8351 RVA: 0x000BE6A0 File Offset: 0x000BC8A0
		public void SetPixelFormat(string pixelFormat)
		{
			bool flag = string.IsNullOrWhiteSpace(pixelFormat);
			if (!flag)
			{
				object cameraLock = this._cameraLock;
				lock (cameraLock)
				{
					bool wasGrabbing = this.IsStreamGrabbing();
					bool flag3 = wasGrabbing;
					if (flag3)
					{
						this._camera.StreamGrabber.Stop();
					}
					bool isApplied = this.TrySetStringParameter("PixelFormat", pixelFormat);
					bool flag4 = isApplied;
					if (flag4)
					{
						this._displayPixelFormat = pixelFormat;
					}
				}
			}
		}

		// Token: 0x060020A0 RID: 8352 RVA: 0x000BE728 File Offset: 0x000BC928
		public void SetLightSourcePreset(string preset)
		{
			object cameraLock = this._cameraLock;
			lock (cameraLock)
			{
				this.TrySetStringParameter("BslLightSourcePreset", preset);
			}
		}

		// Token: 0x060020A1 RID: 8353 RVA: 0x000BE774 File Offset: 0x000BC974
		public List<string> GetPixelFormatOptions()
		{
			object cameraLock = this._cameraLock;
			List<string> enumParameterValues;
			lock (cameraLock)
			{
				enumParameterValues = this.GetEnumParameterValues("PixelFormat");
			}
			return enumParameterValues;
		}

		// Token: 0x060020A2 RID: 8354 RVA: 0x000BE7C0 File Offset: 0x000BC9C0
		public List<string> GetLightSourcePresetOptions()
		{
			object cameraLock = this._cameraLock;
			List<string> enumParameterValues;
			lock (cameraLock)
			{
				enumParameterValues = this.GetEnumParameterValues("BslLightSourcePreset");
			}
			return enumParameterValues;
		}

		// Token: 0x060020A3 RID: 8355 RVA: 0x000BE80C File Offset: 0x000BCA0C
		public long GetLatestImageAgeMs()
		{
			object latestImageLock = this._latestImageLock;
			long result;
			lock (latestImageLock)
			{
				bool flag2 = this._latestImage == null || !this._latestImage.IsInitialized();
				if (flag2)
				{
					result = long.MaxValue;
				}
				else
				{
					result = this._latestImageStopwatch.ElapsedMilliseconds;
				}
			}
			return result;
		}

		// Token: 0x060020A4 RID: 8356 RVA: 0x000BE884 File Offset: 0x000BCA84
		public bool CopyLatestImage(out HObject image)
		{
			image = null;
			object latestImageLock = this._latestImageLock;
			bool result;
			lock (latestImageLock)
			{
				bool flag2 = this._latestImage == null || !this._latestImage.IsInitialized();
				if (flag2)
				{
					result = false;
				}
				else
				{
					try
					{
						HOperatorSet.CopyImage(this._latestImage, out image);
						result = (image != null && image.IsInitialized());
					}
					catch
					{
						HObject hobject = image;
						if (hobject != null)
						{
							hobject.Dispose();
						}
						image = null;
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x060020A5 RID: 8357 RVA: 0x000BE92C File Offset: 0x000BCB2C
		private void LiveLoop(HSmartWindowControlWPF display, CancellationToken token)
		{
			bool flag = this._camera == null;
			if (!flag)
			{
				PixelDataConverter converter = new PixelDataConverter();
				while (!token.IsCancellationRequested)
				{
					try
					{
						object cameraLock = this._cameraLock;
						IGrabResult grabResult;
						string displayPixelFormat;
						lock (cameraLock)
						{
							bool flag3 = this._camera == null;
							if (flag3)
							{
								break;
							}
							this.EnsureStreamGrabberStarted();
							grabResult = this._camera.StreamGrabber.RetrieveResult(250, TimeoutHandling.Return);
							displayPixelFormat = this._displayPixelFormat;
						}
						using (grabResult)
						{
							bool flag4 = grabResult == null || !grabResult.GrabSucceeded || grabResult.Width <= 0 || grabResult.Height <= 0;
							if (!flag4)
							{
								HObject image = BaslerLiveCameraService.ConvertToHalconImage(converter, grabResult, displayPixelFormat);
								bool flag5 = image == null;
								if (!flag5)
								{
									HObject displayImage = CameraImageTransformService.Apply(image, this._config);
									bool flag6 = displayImage != image;
									if (flag6)
									{
										image.Dispose();
									}
									image = displayImage;
									int width = grabResult.Width;
									int height = grabResult.Height;
									HTuple displayWidth;
									HTuple displayHeight;
									HOperatorSet.GetImageSize(image, out displayWidth, out displayHeight);
									width = displayWidth.I;
									height = displayHeight.I;
									this.StoreLatestImage(image);
									bool flag7 = this._config != null && this._config.HardwareTrigger;
									if (flag7)
									{
										CameraHardwareTriggerFrameRouter.Publish(this._config, image);
										image.Dispose();
									}
									else
									{
										HObject frame = image;
										bool flag8 = Interlocked.CompareExchange(ref this._displayPending, 1, 0) != 0;
										if (flag8)
										{
											frame.Dispose();
										}
										else
										{
											display.Dispatcher.BeginInvoke(new Action(delegate()
											{
												try
												{
													CameraLiveDisplayState displayState = display.Tag as CameraLiveDisplayState;
													bool flag9 = displayState != null;
													if (flag9)
													{
														displayState.DisplayFrame(frame, width, height, this._config);
													}
													else
													{
														HWindow window = display.HalconWindow;
														window.ClearWindow();
														window.SetPart(0, 0, height - 1, width - 1);
														window.DispObj(frame);
													}
												}
												finally
												{
													frame.Dispose();
													Interlocked.Exchange(ref this._displayPending, 0);
												}
											}), DispatcherPriority.Background, Array.Empty<object>());
										}
									}
								}
							}
						}
					}
					catch
					{
						Thread.Sleep(50);
					}
				}
			}
		}

		// Token: 0x060020A6 RID: 8358 RVA: 0x000BEBB0 File Offset: 0x000BCDB0
		private void StoreLatestImage(HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			if (!flag)
			{
				object latestImageLock = this._latestImageLock;
				lock (latestImageLock)
				{
					bool flag3 = this._latestImage != null && this._latestImage.IsInitialized() && this._latestImageStopwatch.ElapsedMilliseconds < 100L;
					if (flag3)
					{
						return;
					}
				}
				HObject copy = null;
				try
				{
					HOperatorSet.CopyImage(image, out copy);
				}
				catch
				{
					if (copy != null)
					{
						copy.Dispose();
					}
					copy = null;
				}
				bool flag4 = copy == null;
				if (!flag4)
				{
					object latestImageLock2 = this._latestImageLock;
					lock (latestImageLock2)
					{
						this.DisposeLatestImageCore();
						this._latestImage = copy;
						this._latestImageStopwatch.Restart();
					}
				}
			}
		}

		// Token: 0x060020A7 RID: 8359 RVA: 0x000BECC0 File Offset: 0x000BCEC0
		private void DisposeLatestImage()
		{
			object latestImageLock = this._latestImageLock;
			lock (latestImageLock)
			{
				this.DisposeLatestImageCore();
			}
		}

		// Token: 0x060020A8 RID: 8360 RVA: 0x000BED08 File Offset: 0x000BCF08
		private void DisposeLatestImageCore()
		{
			try
			{
				HObject latestImage = this._latestImage;
				if (latestImage != null)
				{
					latestImage.Dispose();
				}
			}
			catch
			{
			}
			this._latestImage = null;
		}

		// Token: 0x060020A9 RID: 8361 RVA: 0x000BED48 File Offset: 0x000BCF48
		private static HObject ConvertToHalconImage(PixelDataConverter converter, IGrabResult grabResult, string pixelFormat)
		{
			int width = grabResult.Width;
			int height = grabResult.Height;
			bool isColor = BaslerLiveCameraService.IsColorPixelFormat(pixelFormat);
			converter.OutputPixelFormat = (isColor ? PixelType.BGR8packed : PixelType.Mono8);
			byte[] buffer = isColor ? new byte[width * height * 3] : new byte[width * height];
			converter.Convert<byte>(buffer, grabResult);
			GCHandle handle = GCHandle.Alloc(buffer, GCHandleType.Pinned);
			HObject result;
			try
			{
				bool flag = isColor;
				HObject image;
				if (flag)
				{
					HOperatorSet.GenImageInterleaved(out image, handle.AddrOfPinnedObject(), "bgr", width, height, 0, "byte", width, height, 0, 0, -1, 0);
				}
				else
				{
					HOperatorSet.GenImage1(out image, "byte", width, height, handle.AddrOfPinnedObject());
				}
				result = image;
			}
			finally
			{
				handle.Free();
			}
			return result;
		}

		// Token: 0x060020AA RID: 8362 RVA: 0x000BEE64 File Offset: 0x000BD064
		private void ApplyParameter(CameraParameterConfig config)
		{
			object cameraLock = this._cameraLock;
			lock (cameraLock)
			{
				this.ApplyParameterCore(config);
			}
		}

		// Token: 0x060020AB RID: 8363 RVA: 0x000BEEAC File Offset: 0x000BD0AC
		private void ApplyParameterCore(CameraParameterConfig config)
		{
			this.ApplyExposureValue(config.ExposureTime);
			this.ApplyGainValue(config.Gain);
			bool flag = this.TrySetStringParameter("PixelFormat", config.PixelFormat);
			if (flag)
			{
				this._displayPixelFormat = config.PixelFormat;
			}
			this.TrySetStringParameter("TriggerSelector", "FrameStart");
			bool hardwareTrigger = config.HardwareTrigger;
			if (hardwareTrigger)
			{
				this.TrySetStringParameter("TriggerSource", "Line1");
				this.TrySetStringParameter("TriggerActivation", "RisingEdge");
			}
			this.TrySetStringParameter("TriggerMode", config.HardwareTrigger ? "On" : "Off");
			this.TrySetStringParameter("BslLightSourcePreset", config.LightSourcePreset);
		}

		// Token: 0x060020AC RID: 8364 RVA: 0x000BEF68 File Offset: 0x000BD168
		private bool TrySetDoubleParameter(string name, double value)
		{
			bool result;
			try
			{
				result = BaslerLiveCameraService.TryInvokeSetValue(this._camera.Parameters[name], value);
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060020AD RID: 8365 RVA: 0x000BEFB0 File Offset: 0x000BD1B0
		private bool TrySetStringParameter(string name, string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					result = BaslerLiveCameraService.TryInvokeSetValue(this._camera.Parameters[name], value);
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x060020AE RID: 8366 RVA: 0x000BF000 File Offset: 0x000BD200
		private List<string> GetEnumParameterValues(string name)
		{
			List<string> result = new List<string>();
			try
			{
				Camera camera = this._camera;
				object parameter = (camera != null) ? camera.Parameters[name] : null;
				MethodInfo getAllValuesMethod = (parameter != null) ? parameter.GetType().GetMethod("GetAllValues", Type.EmptyTypes) : null;
				IEnumerable values = ((getAllValuesMethod != null) ? getAllValuesMethod.Invoke(parameter, null) : null) as IEnumerable;
				bool flag = values == null;
				if (flag)
				{
					return result;
				}
				foreach (object value in values)
				{
					string text = (value != null) ? value.ToString() : null;
					bool flag2 = !string.IsNullOrWhiteSpace(text) && !result.Contains(text);
					if (flag2)
					{
						result.Add(text);
					}
				}
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x060020AF RID: 8367 RVA: 0x000BF108 File Offset: 0x000BD308
		private void EnsureStreamGrabberStarted()
		{
			Camera camera = this._camera;
			bool flag;
			if (camera == null)
			{
				flag = false;
			}
			else
			{
				IStreamGrabber streamGrabber = camera.StreamGrabber;
				flag = ((streamGrabber != null) ? new bool?(streamGrabber.IsGrabbing) : null).GetValueOrDefault();
			}
			bool flag2 = flag;
			if (!flag2)
			{
				this._camera.StreamGrabber.Start(GrabStrategy.LatestImages, GrabLoop.ProvidedByUser);
			}
		}

		// Token: 0x060020B0 RID: 8368 RVA: 0x000BF164 File Offset: 0x000BD364
		private bool IsStreamGrabbing()
		{
			bool result;
			try
			{
				Camera camera = this._camera;
				bool flag;
				if (camera == null)
				{
					flag = false;
				}
				else
				{
					IStreamGrabber streamGrabber = camera.StreamGrabber;
					flag = ((streamGrabber != null) ? new bool?(streamGrabber.IsGrabbing) : null).GetValueOrDefault();
				}
				result = flag;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060020B1 RID: 8369 RVA: 0x000BF1C0 File Offset: 0x000BD3C0
		private static bool IsColorPixelFormat(string pixelFormat)
		{
			bool flag = string.IsNullOrWhiteSpace(pixelFormat);
			return !flag && (pixelFormat.IndexOf("Bayer", StringComparison.OrdinalIgnoreCase) >= 0 || pixelFormat.IndexOf("RGB", StringComparison.OrdinalIgnoreCase) >= 0 || pixelFormat.IndexOf("BGR", StringComparison.OrdinalIgnoreCase) >= 0);
		}

		// Token: 0x060020B2 RID: 8370 RVA: 0x000BF214 File Offset: 0x000BD414
		private static bool TryInvokeSetValue(object parameter, object value)
		{
			bool flag = parameter == null || value == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				MethodInfo method = parameter.GetType().GetMethods().FirstOrDefault((MethodInfo x) => x.Name == "SetValue" && x.GetParameters().Length >= 1 && BaslerLiveCameraService.CanUseParameterType(x.GetParameters()[0].ParameterType, value));
				bool flag2 = method == null;
				if (flag2)
				{
					result = false;
				}
				else
				{
					try
					{
						object convertedValue = BaslerLiveCameraService.ConvertValue(value, method.GetParameters()[0].ParameterType);
						method.Invoke(parameter, new object[]
						{
							convertedValue
						});
						result = true;
					}
					catch
					{
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x060020B3 RID: 8371 RVA: 0x000BF2C0 File Offset: 0x000BD4C0
		private static bool CanUseParameterType(Type parameterType, object value)
		{
			bool flag = parameterType == null || value == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = parameterType.IsInstanceOfType(value);
				if (flag2)
				{
					result = true;
				}
				else
				{
					bool flag3 = value is double;
					if (flag3)
					{
						result = (parameterType == typeof(double) || parameterType == typeof(float) || parameterType == typeof(int) || parameterType == typeof(long));
					}
					else
					{
						result = (value is string && parameterType == typeof(string));
					}
				}
			}
			return result;
		}

		// Token: 0x060020B4 RID: 8372 RVA: 0x000BF374 File Offset: 0x000BD574
		private static object ConvertValue(object value, Type targetType)
		{
			bool flag = targetType.IsInstanceOfType(value);
			object result;
			if (flag)
			{
				result = value;
			}
			else
			{
				result = Convert.ChangeType(value, targetType);
			}
			return result;
		}

		// Token: 0x04000D8B RID: 3467
		private Camera _camera;

		// Token: 0x04000D8C RID: 3468
		private CancellationTokenSource _cancellation;

		// Token: 0x04000D8D RID: 3469
		private Task _worker;

		// Token: 0x04000D8E RID: 3470
		private string _cameraId;

		// Token: 0x04000D8F RID: 3471
		private string _displayPixelFormat = "Mono8";

		// Token: 0x04000D90 RID: 3472
		private CameraParameterConfig _config;

		// Token: 0x04000D91 RID: 3473
		private readonly object _cameraLock = new object();

		// Token: 0x04000D92 RID: 3474
		private readonly object _latestImageLock = new object();

		// Token: 0x04000D93 RID: 3475
		private readonly Stopwatch _latestImageStopwatch = Stopwatch.StartNew();

		// Token: 0x04000D94 RID: 3476
		private HObject _latestImage;

		// Token: 0x04000D95 RID: 3477
		private int _displayPending;
	}
}
