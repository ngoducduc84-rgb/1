﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200023D RID: 573
	internal sealed class BaslerReflectionCameraService : IDisposable
	{
		// Token: 0x06002075 RID: 8309 RVA: 0x000BD313 File Offset: 0x000BB513
		private BaslerReflectionCameraService(Assembly assembly, object camera)
		{
			this._assembly = assembly;
			this._camera = camera;
		}

		// Token: 0x06002076 RID: 8310 RVA: 0x000BD32C File Offset: 0x000BB52C
		public static BaslerReflectionCameraService Create(string serial)
		{
			bool flag = string.IsNullOrWhiteSpace(serial);
			BaslerReflectionCameraService result;
			if (flag)
			{
				result = null;
			}
			else
			{
				Assembly assembly = CameraSdkAssemblyLoader.LoadBaslerPylon();
				Type cameraType = (assembly != null) ? assembly.GetType("Basler.Pylon.Camera") : null;
				bool flag2 = cameraType == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					try
					{
						object camera = Activator.CreateInstance(cameraType, new object[]
						{
							serial
						});
						result = new BaslerReflectionCameraService(assembly, camera);
					}
					catch
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x06002077 RID: 8311 RVA: 0x000BD3A8 File Offset: 0x000BB5A8
		public void ApplyParameter(CameraParameterConfig config)
		{
			bool flag = config == null;
			if (!flag)
			{
				this.OpenIfNeeded();
				this.SetDoubleParameter(new string[]
				{
					"ExposureTime",
					"ExposureTimeAbs"
				}, config.ExposureTime);
				this.SetDoubleParameter(new string[]
				{
					"Gain",
					"GainRaw"
				}, config.Gain);
				this.SetStringParameter(new string[]
				{
					"PixelFormat"
				}, config.PixelFormat);
				this.SetStringParameter(new string[]
				{
					"TriggerMode"
				}, config.HardwareTrigger ? "On" : "Off");
				this.SetStringParameter(new string[]
				{
					"BslLightSourcePreset"
				}, config.LightSourcePreset);
			}
		}

		// Token: 0x06002078 RID: 8312 RVA: 0x000BD46F File Offset: 0x000BB66F
		public void SetExposure(double exposureTime)
		{
			this.OpenIfNeeded();
			this.SetDoubleParameter(new string[]
			{
				"ExposureTime",
				"ExposureTimeAbs"
			}, exposureTime);
		}

		// Token: 0x06002079 RID: 8313 RVA: 0x000BD497 File Offset: 0x000BB697
		public void SetGain(double gain)
		{
			this.OpenIfNeeded();
			this.SetDoubleParameter(new string[]
			{
				"Gain",
				"GainRaw"
			}, gain);
		}

		// Token: 0x0600207A RID: 8314 RVA: 0x000BD4C0 File Offset: 0x000BB6C0
		public CameraParameterRange GetGainRange()
		{
			this.OpenIfNeeded();
			return this.GetNumericRange("Gain", false) ?? this.GetNumericRange("GainRaw", true);
		}

		// Token: 0x0600207B RID: 8315 RVA: 0x000BD4F8 File Offset: 0x000BB6F8
		public CameraParameterRange GetExposureRange()
		{
			this.OpenIfNeeded();
			return this.GetNumericRange("ExposureTime", false) ?? this.GetNumericRange("ExposureTimeAbs", false);
		}

		// Token: 0x0600207C RID: 8316 RVA: 0x000BD530 File Offset: 0x000BB730
		private CameraParameterRange GetNumericRange(string name, bool isInteger)
		{
			object parameter = this.GetParameter(name);
			bool flag = parameter == null;
			CameraParameterRange result;
			if (flag)
			{
				result = null;
			}
			else
			{
				try
				{
					MethodInfo getMin = parameter.GetType().GetMethod("GetMinimum", Type.EmptyTypes);
					MethodInfo getMax = parameter.GetType().GetMethod("GetMaximum", Type.EmptyTypes);
					bool flag2 = getMin == null || getMax == null;
					if (flag2)
					{
						result = null;
					}
					else
					{
						object minObj = getMin.Invoke(parameter, null);
						object maxObj = getMax.Invoke(parameter, null);
						bool flag3 = minObj == null || maxObj == null;
						if (flag3)
						{
							result = null;
						}
						else
						{
							result = new CameraParameterRange
							{
								Min = Convert.ToDouble(minObj),
								Max = Convert.ToDouble(maxObj),
								IsInteger = isInteger
							};
						}
					}
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x0600207D RID: 8317 RVA: 0x000BD610 File Offset: 0x000BB810
		public List<string> GetPixelFormatOptions()
		{
			this.OpenIfNeeded();
			return this.GetEnumParameterValues("PixelFormat");
		}

		// Token: 0x0600207E RID: 8318 RVA: 0x000BD634 File Offset: 0x000BB834
		public List<string> GetLightSourcePresetOptions()
		{
			this.OpenIfNeeded();
			return this.GetEnumParameterValues("BslLightSourcePreset");
		}

		// Token: 0x0600207F RID: 8319 RVA: 0x000BD658 File Offset: 0x000BB858
		public void Dispose()
		{
			try
			{
				object camera = this._camera;
				object obj;
				if (camera == null)
				{
					obj = null;
				}
				else
				{
					PropertyInfo property = camera.GetType().GetProperty("StreamGrabber");
					obj = ((property != null) ? property.GetValue(this._camera, null) : null);
				}
				object streamGrabber = obj;
				bool isGrabbing = BaslerReflectionCameraService.GetBoolProperty(streamGrabber, "IsGrabbing");
				bool flag = isGrabbing;
				if (flag)
				{
					MethodInfo method = streamGrabber.GetType().GetMethod("Stop", Type.EmptyTypes);
					if (method != null)
					{
						method.Invoke(streamGrabber, null);
					}
				}
			}
			catch
			{
			}
			try
			{
				bool isOpen = BaslerReflectionCameraService.GetBoolProperty(this._camera, "IsOpen");
				bool flag2 = isOpen;
				if (flag2)
				{
					MethodInfo method2 = this._camera.GetType().GetMethod("Close", Type.EmptyTypes);
					if (method2 != null)
					{
						method2.Invoke(this._camera, null);
					}
				}
			}
			catch
			{
			}
			try
			{
				IDisposable disposable = this._camera as IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06002080 RID: 8320 RVA: 0x000BD770 File Offset: 0x000BB970
		private void OpenIfNeeded()
		{
			bool isOpen = BaslerReflectionCameraService.GetBoolProperty(this._camera, "IsOpen");
			bool flag = isOpen;
			if (!flag)
			{
				MethodInfo method = this._camera.GetType().GetMethod("Open", Type.EmptyTypes);
				if (method != null)
				{
					method.Invoke(this._camera, null);
				}
			}
		}

		// Token: 0x06002081 RID: 8321 RVA: 0x000BD7C4 File Offset: 0x000BB9C4
		private void SetDoubleParameter(IEnumerable<string> names, double value)
		{
			foreach (string name in names)
			{
				object parameter = this.GetParameter(name);
				bool flag = BaslerReflectionCameraService.TryInvokeSetValue(parameter, value);
				if (flag)
				{
					break;
				}
			}
		}

		// Token: 0x06002082 RID: 8322 RVA: 0x000BD824 File Offset: 0x000BBA24
		private void SetStringParameter(IEnumerable<string> names, string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			if (!flag)
			{
				foreach (string name in names)
				{
					object parameter = this.GetParameter(name);
					bool flag2 = BaslerReflectionCameraService.TryInvokeSetValue(parameter, value);
					if (flag2)
					{
						break;
					}
				}
			}
		}

		// Token: 0x06002083 RID: 8323 RVA: 0x000BD890 File Offset: 0x000BBA90
		private object GetParameter(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				PropertyInfo property = this._camera.GetType().GetProperty("Parameters");
				object parameters = (property != null) ? property.GetValue(this._camera, null) : null;
				bool flag2 = parameters == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					try
					{
						PropertyInfo indexer = parameters.GetType().GetProperty("Item", new Type[]
						{
							typeof(string)
						});
						result = ((indexer != null) ? indexer.GetValue(parameters, new object[]
						{
							name
						}) : null);
					}
					catch
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x06002084 RID: 8324 RVA: 0x000BD93C File Offset: 0x000BBB3C
		private List<string> GetEnumParameterValues(string name)
		{
			List<string> result = new List<string>();
			object parameter = this.GetParameter(name);
			bool flag = parameter == null;
			List<string> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				try
				{
					MethodInfo getAllValuesMethod = parameter.GetType().GetMethod("GetAllValues", Type.EmptyTypes);
					IEnumerable values = ((getAllValuesMethod != null) ? getAllValuesMethod.Invoke(parameter, null) : null) as IEnumerable;
					bool flag2 = values == null;
					if (flag2)
					{
						return result;
					}
					foreach (object value in values)
					{
						string text = (value != null) ? value.ToString() : null;
						bool flag3 = !string.IsNullOrWhiteSpace(text) && !result.Contains(text);
						if (flag3)
						{
							result.Add(text);
						}
					}
				}
				catch
				{
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06002085 RID: 8325 RVA: 0x000BDA40 File Offset: 0x000BBC40
		private static bool TryInvokeSetValue(object parameter, object value)
		{
			bool flag = parameter == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				MethodInfo method = parameter.GetType().GetMethods().FirstOrDefault((MethodInfo x) => x.Name == "SetValue" && x.GetParameters().Length >= 1 && BaslerReflectionCameraService.CanUseParameterType(x.GetParameters()[0].ParameterType, value));
				bool flag2 = method == null;
				if (flag2)
				{
					result = false;
				}
				else
				{
					try
					{
						object convertedValue = BaslerReflectionCameraService.ConvertValue(value, method.GetParameters()[0].ParameterType);
						method.Invoke(parameter, new object[]
						{
							convertedValue
						});
						result = true;
					}
					catch
					{
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x06002086 RID: 8326 RVA: 0x000BDAE0 File Offset: 0x000BBCE0
		private static bool CanUseParameterType(Type parameterType, object value)
		{
			bool flag = parameterType == null || value == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = parameterType.IsInstanceOfType(value);
				if (flag2)
				{
					result = true;
				}
				else
				{
					bool flag3 = value is double;
					if (flag3)
					{
						result = (parameterType == typeof(double) || parameterType == typeof(float) || parameterType == typeof(int) || parameterType == typeof(long));
					}
					else
					{
						result = (value is string && parameterType == typeof(string));
					}
				}
			}
			return result;
		}

		// Token: 0x06002087 RID: 8327 RVA: 0x000BDB94 File Offset: 0x000BBD94
		private static object ConvertValue(object value, Type targetType)
		{
			bool flag = targetType.IsInstanceOfType(value);
			object result;
			if (flag)
			{
				result = value;
			}
			else
			{
				result = Convert.ChangeType(value, targetType);
			}
			return result;
		}

		// Token: 0x06002088 RID: 8328 RVA: 0x000BDBBC File Offset: 0x000BBDBC
		private static bool GetBoolProperty(object target, string propertyName)
		{
			bool result;
			try
			{
				object obj;
				if (target == null)
				{
					obj = null;
				}
				else
				{
					PropertyInfo property = target.GetType().GetProperty(propertyName);
					obj = ((property != null) ? property.GetValue(target, null) : null);
				}
				object value = obj;
				result = (value is bool && (bool)value);
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x04000D88 RID: 3464
		private readonly Assembly _assembly;

		// Token: 0x04000D89 RID: 3465
		private readonly object _camera;
	}
}
