﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VisionMachine.Models.Camera;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Main;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200023A RID: 570
	public static class CameraConnectionMonitorService
	{
		// Token: 0x170009AA RID: 2474
		// (get) Token: 0x06002052 RID: 8274 RVA: 0x000BC11E File Offset: 0x000BA31E
		// (set) Token: 0x06002053 RID: 8275 RVA: 0x000BC125 File Offset: 0x000BA325
		public static int ProbeIntervalMs { get; set; } = 1000;

		// Token: 0x06002054 RID: 8276 RVA: 0x000BC130 File Offset: 0x000BA330
		public static void EnsureStarted()
		{
			object syncRoot = CameraConnectionMonitorService.SyncRoot;
			bool flag = false;
			try
			{
				Monitor.Enter(syncRoot, ref flag);
				bool flag2 = CameraConnectionMonitorService._probeTask != null && !CameraConnectionMonitorService._probeTask.IsCompleted;
				if (!flag2)
				{
					CancellationTokenSource cancellation = new CancellationTokenSource();
					CancellationToken token = cancellation.Token;
					CameraConnectionMonitorService._cancellation = cancellation;
					CameraConnectionMonitorService._probeTask = Task.Run(delegate()
					{
						CameraConnectionMonitorService.ProbeLoop(token);
					}, token);
				}
			}
			finally
			{
				if (flag)
				{
					Monitor.Exit(syncRoot);
				}
			}
		}

		// Token: 0x06002055 RID: 8277 RVA: 0x000BC1C8 File Offset: 0x000BA3C8
		public static void Stop()
		{
			object syncRoot = CameraConnectionMonitorService.SyncRoot;
			CancellationTokenSource cancellation;
			Task task;
			lock (syncRoot)
			{
				cancellation = CameraConnectionMonitorService._cancellation;
				task = CameraConnectionMonitorService._probeTask;
				CameraConnectionMonitorService._cancellation = null;
				CameraConnectionMonitorService._probeTask = null;
				CameraConnectionMonitorService._hasProbed = false;
				CameraConnectionMonitorService.States.Clear();
			}
			try
			{
				CancellationTokenSource cancellation2 = cancellation;
				if (cancellation2 != null)
				{
					cancellation2.Cancel();
				}
			}
			catch
			{
			}
			bool flag2 = cancellation == null;
			if (!flag2)
			{
				bool flag3 = task == null || task.IsCompleted;
				if (flag3)
				{
					try
					{
						cancellation.Dispose();
					}
					catch
					{
					}
				}
				else
				{
					task.ContinueWith(delegate(Task _)
					{
						try
						{
							cancellation.Dispose();
						}
						catch
						{
						}
					}, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
				}
			}
		}

		// Token: 0x06002056 RID: 8278 RVA: 0x000BC2CC File Offset: 0x000BA4CC
		public static bool TryGetConnected(string cameraName, out bool isConnected)
		{
			isConnected = false;
			bool flag = string.IsNullOrWhiteSpace(cameraName);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				object syncRoot = CameraConnectionMonitorService.SyncRoot;
				lock (syncRoot)
				{
					bool flag3 = !CameraConnectionMonitorService._hasProbed;
					if (flag3)
					{
						result = false;
					}
					else
					{
						bool value;
						isConnected = (CameraConnectionMonitorService.States.TryGetValue(cameraName.Trim(), out value) && value);
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x06002057 RID: 8279 RVA: 0x000BC348 File Offset: 0x000BA548
		public static void PublishDiscoverySnapshot(IEnumerable<CameraNode> cameras, IEnumerable<ConnectedCameraInfo> connectedCameras)
		{
			HashSet<string> presentIds = new HashSet<string>(from camera in connectedCameras ?? Enumerable.Empty<ConnectedCameraInfo>()
			where camera != null && !string.IsNullOrWhiteSpace(camera.Id)
			select camera.Id.Trim(), StringComparer.OrdinalIgnoreCase);
			Dictionary<string, bool> states = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
			foreach (CameraNode camera2 in (cameras ?? Enumerable.Empty<CameraNode>()))
			{
				string text;
				if (camera2 == null)
				{
					text = null;
				}
				else
				{
					CameraItem cameraInfo = camera2.CameraInfo;
					text = ((cameraInfo != null) ? cameraInfo.CameraName : null);
				}
				string name = text;
				bool flag = string.IsNullOrWhiteSpace(name);
				if (flag)
				{
					name = ((camera2 != null) ? camera2.Name : null);
				}
				bool flag2 = string.IsNullOrWhiteSpace(name);
				if (!flag2)
				{
					string text2;
					if (camera2 == null)
					{
						text2 = null;
					}
					else
					{
						CameraParameterConfig cameraConfig = camera2.CameraConfig;
						text2 = ((cameraConfig != null) ? cameraConfig.ConnectedCameraId : null);
					}
					string cameraId = text2;
					states[name.Trim()] = (!string.IsNullOrWhiteSpace(cameraId) && presentIds.Contains(cameraId.Trim()));
				}
			}
			object syncRoot = CameraConnectionMonitorService.SyncRoot;
			lock (syncRoot)
			{
				CameraConnectionMonitorService.States.Clear();
				foreach (KeyValuePair<string, bool> entry in states)
				{
					CameraConnectionMonitorService.States[entry.Key] = entry.Value;
				}
				CameraConnectionMonitorService._hasProbed = true;
			}
		}

		// Token: 0x06002058 RID: 8280 RVA: 0x000BC520 File Offset: 0x000BA720
		private static void ProbeLoop(CancellationToken cancellationToken)
		{
			while (!cancellationToken.IsCancellationRequested)
			{
				try
				{
					CameraConnectionMonitorService.Probe();
				}
				catch
				{
				}
				bool flag = cancellationToken.WaitHandle.WaitOne(Math.Max(250, CameraConnectionMonitorService.ProbeIntervalMs));
				if (flag)
				{
					break;
				}
			}
		}

		// Token: 0x06002059 RID: 8281 RVA: 0x000BC580 File Offset: 0x000BA780
		private static void Probe()
		{
			MainWindow instance = MainWindow.instance;
			bool flag;
			if (instance == null)
			{
				flag = false;
			}
			else
			{
				MainViewModel mainViewModel = instance.MainViewModel;
				flag = ((mainViewModel != null) ? new bool?(mainViewModel.IsDiscoveringCameras) : null).GetValueOrDefault();
			}
			bool flag2 = flag;
			if (!flag2)
			{
				List<CameraConnectionMonitorService.CameraProbeTarget> cameras = CameraConnectionMonitorService.GetConfiguredCameras();
				bool flag3 = cameras.Count == 0;
				if (flag3)
				{
					object syncRoot = CameraConnectionMonitorService.SyncRoot;
					lock (syncRoot)
					{
						CameraConnectionMonitorService.States.Clear();
						CameraConnectionMonitorService._hasProbed = true;
					}
				}
				else
				{
					Dictionary<string, bool> immediateStates = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
					foreach (CameraConnectionMonitorService.CameraProbeTarget camera2 in cameras)
					{
						bool flag5 = string.IsNullOrWhiteSpace(camera2.CameraId);
						if (flag5)
						{
							immediateStates[camera2.Name] = false;
						}
						else
						{
							bool? liveState = CameraConnectionMonitorService.GetLiveState(camera2.CameraId);
							bool flag6 = liveState != null;
							if (flag6)
							{
								immediateStates[camera2.Name] = liveState.Value;
							}
						}
					}
					CameraConnectionMonitorService.UpdateStates(immediateStates);
					Task[] probeTasks = (from camera in cameras
					where !string.IsNullOrWhiteSpace(camera.CameraId) && !CameraConnectionMonitorService.GetLiveState(camera.CameraId).GetValueOrDefault()
					group camera by camera.Vendor into @group
					select Task.Run(delegate()
					{
						CameraConnectionMonitorService.ProbeVendor(@group.Key, @group.ToList<CameraConnectionMonitorService.CameraProbeTarget>());
					})).ToArray<Task>();
					bool flag7 = probeTasks.Length != 0;
					if (flag7)
					{
						Task.WaitAll(probeTasks);
					}
				}
			}
		}

		// Token: 0x0600205A RID: 8282 RVA: 0x000BC754 File Offset: 0x000BA954
		private static void ProbeVendor(CameraVendor vendor, List<CameraConnectionMonitorService.CameraProbeTarget> cameras)
		{
			try
			{
				HashSet<string> presentIds = new HashSet<string>(from device in CameraDiscoveryService.EnumerateConnectedCameras(vendor)
				where device != null && !string.IsNullOrWhiteSpace(device.Id)
				select device.Id.Trim(), StringComparer.OrdinalIgnoreCase);
				Dictionary<string, bool> states = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
				foreach (CameraConnectionMonitorService.CameraProbeTarget camera in cameras)
				{
					states[camera.Name] = (CameraConnectionMonitorService.GetLiveState(camera.CameraId).GetValueOrDefault() || presentIds.Contains(camera.CameraId));
				}
				CameraConnectionMonitorService.UpdateStates(states);
			}
			catch
			{
			}
		}

		// Token: 0x0600205B RID: 8283 RVA: 0x000BC854 File Offset: 0x000BAA54
		private static void UpdateStates(IDictionary<string, bool> states)
		{
			bool flag = states == null || states.Count == 0;
			if (!flag)
			{
				object syncRoot = CameraConnectionMonitorService.SyncRoot;
				lock (syncRoot)
				{
					foreach (KeyValuePair<string, bool> entry in states)
					{
						CameraConnectionMonitorService.States[entry.Key] = entry.Value;
					}
					CameraConnectionMonitorService._hasProbed = true;
				}
			}
		}

		// Token: 0x0600205C RID: 8284 RVA: 0x000BC8FC File Offset: 0x000BAAFC
		private static bool? GetLiveState(string cameraId)
		{
			bool? result;
			try
			{
				result = (string.IsNullOrWhiteSpace(cameraId) ? null : CameraHardwareRuntimeService.TryGetLiveConnectionState(cameraId));
			}
			catch
			{
				result = new bool?(false);
			}
			return result;
		}

		// Token: 0x0600205D RID: 8285 RVA: 0x000BC944 File Offset: 0x000BAB44
		private static List<CameraConnectionMonitorService.CameraProbeTarget> GetConfiguredCameras()
		{
			List<CameraConnectionMonitorService.CameraProbeTarget> result = new List<CameraConnectionMonitorService.CameraProbeTarget>();
			try
			{
				MainWindow instance = MainWindow.instance;
				ObservableCollection<CameraNode> observableCollection;
				if (instance == null)
				{
					observableCollection = null;
				}
				else
				{
					MainViewModel mainViewModel = instance.MainViewModel;
					observableCollection = ((mainViewModel != null) ? mainViewModel.Cameras : null);
				}
				ObservableCollection<CameraNode> cameras = observableCollection;
				bool flag = cameras == null;
				if (flag)
				{
					return result;
				}
				foreach (CameraNode camera in cameras)
				{
					string text;
					if (camera == null)
					{
						text = null;
					}
					else
					{
						CameraItem cameraInfo = camera.CameraInfo;
						text = ((cameraInfo != null) ? cameraInfo.CameraName : null);
					}
					string name = text;
					bool flag2 = string.IsNullOrWhiteSpace(name);
					if (!flag2)
					{
						List<CameraConnectionMonitorService.CameraProbeTarget> list = result;
						CameraConnectionMonitorService.CameraProbeTarget cameraProbeTarget = new CameraConnectionMonitorService.CameraProbeTarget();
						cameraProbeTarget.Name = name.Trim();
						CameraParameterConfig cameraConfig = camera.CameraConfig;
						string cameraId;
						if (cameraConfig == null)
						{
							cameraId = null;
						}
						else
						{
							string connectedCameraId = cameraConfig.ConnectedCameraId;
							cameraId = ((connectedCameraId != null) ? connectedCameraId.Trim() : null);
						}
						cameraProbeTarget.CameraId = cameraId;
						CameraParameterConfig cameraConfig2 = camera.CameraConfig;
						cameraProbeTarget.Vendor = ((cameraConfig2 != null) ? cameraConfig2.Vendor : CameraVendor.Unknown);
						list.Add(cameraProbeTarget);
					}
				}
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x04000D7E RID: 3454
		private static readonly object SyncRoot = new object();

		// Token: 0x04000D7F RID: 3455
		private static readonly Dictionary<string, bool> States = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000D80 RID: 3456
		private static CancellationTokenSource _cancellation;

		// Token: 0x04000D81 RID: 3457
		private static Task _probeTask;

		// Token: 0x04000D82 RID: 3458
		private static bool _hasProbed;

		// Token: 0x02000488 RID: 1160
		private class CameraProbeTarget
		{
			// Token: 0x17000B97 RID: 2967
			// (get) Token: 0x06002CA2 RID: 11426 RVA: 0x000EB37D File Offset: 0x000E957D
			// (set) Token: 0x06002CA3 RID: 11427 RVA: 0x000EB385 File Offset: 0x000E9585
			public string Name { get; set; }

			// Token: 0x17000B98 RID: 2968
			// (get) Token: 0x06002CA4 RID: 11428 RVA: 0x000EB38E File Offset: 0x000E958E
			// (set) Token: 0x06002CA5 RID: 11429 RVA: 0x000EB396 File Offset: 0x000E9596
			public string CameraId { get; set; }

			// Token: 0x17000B99 RID: 2969
			// (get) Token: 0x06002CA6 RID: 11430 RVA: 0x000EB39F File Offset: 0x000E959F
			// (set) Token: 0x06002CA7 RID: 11431 RVA: 0x000EB3A7 File Offset: 0x000E95A7
			public CameraVendor Vendor { get; set; }
		}
	}
}
