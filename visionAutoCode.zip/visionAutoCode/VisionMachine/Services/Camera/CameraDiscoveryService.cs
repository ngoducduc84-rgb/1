﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Security;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200023B RID: 571
	public static class CameraDiscoveryService
	{
		// Token: 0x0600205F RID: 8287 RVA: 0x000BCA90 File Offset: 0x000BAC90
		public static List<ConnectedCameraInfo> EnumerateConnectedCameras()
		{
			List<ConnectedCameraInfo> result = new List<ConnectedCameraInfo>();
			CameraDiscoveryService.AddRangeUnique(result, CameraDiscoveryService.EnumerateBaslerCameras());
			CameraDiscoveryService.AddRangeUnique(result, CameraDiscoveryService.EnumerateHikvisionCameras());
			bool flag = result.Count > 0;
			List<ConnectedCameraInfo> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				using (IEnumerator<CameraItem> enumerator = CameraRuntimeStore.Cameras.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						CameraItem camera = enumerator.Current;
						bool flag2 = string.IsNullOrWhiteSpace(camera.CameraName);
						if (!flag2)
						{
							bool flag3 = result.Any((ConnectedCameraInfo x) => x.Id == camera.CameraName);
							if (!flag3)
							{
								result.Add(new ConnectedCameraInfo
								{
									Id = camera.CameraName,
									Name = camera.CameraName,
									Vendor = CameraVendor.Unknown
								});
							}
						}
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06002060 RID: 8288 RVA: 0x000BCB94 File Offset: 0x000BAD94
		public static List<ConnectedCameraInfo> EnumerateConnectedCameras(CameraVendor vendor)
		{
			List<ConnectedCameraInfo> result = new List<ConnectedCameraInfo>();
			if (vendor != CameraVendor.Basler)
			{
				if (vendor != CameraVendor.Hikvision)
				{
					CameraDiscoveryService.AddRangeUnique(result, CameraDiscoveryService.EnumerateBaslerCameras());
					CameraDiscoveryService.AddRangeUnique(result, CameraDiscoveryService.EnumerateHikvisionCameras());
				}
				else
				{
					CameraDiscoveryService.AddRangeUnique(result, CameraDiscoveryService.EnumerateHikvisionCameras());
				}
			}
			else
			{
				CameraDiscoveryService.AddRangeUnique(result, CameraDiscoveryService.EnumerateBaslerCameras());
			}
			return result;
		}

		// Token: 0x06002061 RID: 8289 RVA: 0x000BCBF4 File Offset: 0x000BADF4
		private static void AddRangeUnique(List<ConnectedCameraInfo> target, IEnumerable<ConnectedCameraInfo> source)
		{
			bool flag = target == null || source == null;
			if (!flag)
			{
				using (IEnumerator<ConnectedCameraInfo> enumerator = source.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						ConnectedCameraInfo camera = enumerator.Current;
						bool flag2 = camera == null || string.IsNullOrWhiteSpace(camera.Id);
						if (!flag2)
						{
							bool exists = target.Any((ConnectedCameraInfo x) => x.Id == camera.Id && x.Vendor == camera.Vendor);
							bool flag3 = !exists;
							if (flag3)
							{
								target.Add(camera);
							}
						}
					}
				}
			}
		}

		// Token: 0x06002062 RID: 8290 RVA: 0x000BCCA8 File Offset: 0x000BAEA8
		private static IEnumerable<ConnectedCameraInfo> EnumerateBaslerCameras()
		{
			return new CameraDiscoveryService.<EnumerateBaslerCameras>d__3(-2);
		}

		// Token: 0x06002063 RID: 8291 RVA: 0x000BCCB1 File Offset: 0x000BAEB1
		private static IEnumerable<ConnectedCameraInfo> EnumerateHikvisionCameras()
		{
			return new CameraDiscoveryService.<EnumerateHikvisionCameras>d__4(-2);
		}

		// Token: 0x06002064 RID: 8292 RVA: 0x000BCCBC File Offset: 0x000BAEBC
		private static object BuildHikvisionLayerMask(Type layerType)
		{
			int mask = 0;
			string[] names = new string[]
			{
				"MvGigEDevice",
				"MvUsbDevice",
				"MvVirGigEDevice",
				"MvVirUsbDevice",
				"MvCameraLinkDevice",
				"MvGenTLGigEDevice",
				"MvGenTLCameraLinkDevice",
				"MvGenTLCXPDevice",
				"MvGenTLXoFDevice"
			};
			foreach (string name in names)
			{
				try
				{
					object value = Enum.Parse(layerType, name);
					mask |= Convert.ToInt32(value);
				}
				catch
				{
				}
			}
			bool flag = mask <= 0;
			if (flag)
			{
				mask = -1;
			}
			return Enum.ToObject(layerType, mask);
		}

		// Token: 0x06002065 RID: 8293 RVA: 0x000BCD80 File Offset: 0x000BAF80
		[HandleProcessCorruptedStateExceptions]
		[SecurityCritical]
		private static IEnumerable SafeInvokeEnumerable(MethodInfo method, object target, object[] args)
		{
			IEnumerable result;
			try
			{
				result = (method.Invoke(target, args) as IEnumerable);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06002066 RID: 8294 RVA: 0x000BCDB8 File Offset: 0x000BAFB8
		[HandleProcessCorruptedStateExceptions]
		[SecurityCritical]
		private static bool SafeInvoke(MethodInfo method, object target, object[] args)
		{
			bool result;
			try
			{
				method.Invoke(target, args);
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06002067 RID: 8295 RVA: 0x000BCDEC File Offset: 0x000BAFEC
		private static string GetStaticStringProperty(Type type, string propertyName)
		{
			string result;
			try
			{
				PropertyInfo property = type.GetProperty(propertyName, BindingFlags.Static | BindingFlags.Public);
				string text;
				if (property == null)
				{
					text = null;
				}
				else
				{
					object value = property.GetValue(null, null);
					text = ((value != null) ? value.ToString() : null);
				}
				result = text;
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06002068 RID: 8296 RVA: 0x000BCE38 File Offset: 0x000BB038
		private static string GetCameraInfoValue(object cameraInfo, string key)
		{
			bool flag = cameraInfo == null || string.IsNullOrWhiteSpace(key);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				try
				{
					PropertyInfo indexer = cameraInfo.GetType().GetProperty("Item", new Type[]
					{
						typeof(string)
					});
					string text;
					if (indexer == null)
					{
						text = null;
					}
					else
					{
						object value = indexer.GetValue(cameraInfo, new object[]
						{
							key
						});
						text = ((value != null) ? value.ToString() : null);
					}
					result = text;
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06002069 RID: 8297 RVA: 0x000BCEC0 File Offset: 0x000BB0C0
		private static string GetObjectPropertyValue(object target, string propertyName)
		{
			string result;
			try
			{
				string text;
				if (target == null)
				{
					text = null;
				}
				else
				{
					PropertyInfo property = target.GetType().GetProperty(propertyName);
					if (property == null)
					{
						text = null;
					}
					else
					{
						object value = property.GetValue(target, null);
						text = ((value != null) ? value.ToString() : null);
					}
				}
				result = text;
			}
			catch
			{
				result = null;
			}
			return result;
		}
	}
}
