﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Controls;
using DevExpress.Xpf.Docking;
using VisionMachine.Controls.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000250 RID: 592
	internal static class CameraDockFactory
	{
		// Token: 0x170009C2 RID: 2498
		// (get) Token: 0x0600217D RID: 8573 RVA: 0x000C4DC1 File Offset: 0x000C2FC1
		// (set) Token: 0x0600217E RID: 8574 RVA: 0x000C4DC8 File Offset: 0x000C2FC8
		public static CameraLayoutSettings CurrentSettings { get; private set; }

		// Token: 0x0600217F RID: 8575 RVA: 0x000C4DD0 File Offset: 0x000C2FD0
		public static void Load_config_select_Camera()
		{
			string _configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CameraLayoutSettings.json");
			CameraDockFactory.CurrentSettings = CameraLayoutSettings.LoadFromFile(_configPath);
			CameraDockFactory._maxRow = CameraDockFactory.CurrentSettings.MaxCamerasPerRow;
			CameraDockFactory.CameraCount = CameraDockFactory.CurrentSettings.CameraCount;
		}

		// Token: 0x06002180 RID: 8576 RVA: 0x000C4E20 File Offset: 0x000C3020
		public static void CreateCameraDocks(LayoutGroup rootGroup, List<CameraDockItem> _cameraDocks)
		{
			rootGroup.Items.Clear();
			_cameraDocks.Clear();
			LayoutGroup currentRow = null;
			for (int i = 1; i <= CameraRuntimeStore.Cameras.Count; i++)
			{
				bool flag = (i - 1) % CameraRuntimeStore.Count_per_row == 0;
				if (flag)
				{
					currentRow = new LayoutGroup
					{
						Orientation = Orientation.Horizontal,
						ShowCloseButton = false
					};
					rootGroup.Items.Add(currentRow);
				}
				BaseLayoutItem item = CameraDockFactory.CreateCameraPanel(_cameraDocks, i, CameraRuntimeStore.Cameras[i - 1].CameraName);
				currentRow.Items.Add(item);
			}
		}

		// Token: 0x06002181 RID: 8577 RVA: 0x000C4EC0 File Offset: 0x000C30C0
		private static BaseLayoutItem CreateCameraPanel(List<CameraDockItem> _cameraDocks, int cameraIndex, string Camera_name)
		{
			LayoutPanel panel = new LayoutPanel
			{
				Caption = Camera_name,
				AllowClose = false,
				AllowFloat = true,
				AllowDock = true,
				AllowHide = true
			};
			CameraDockView view = new CameraDockView();
			view.SetTitle(Camera_name);
			panel.Content = view;
			LayoutPanel outputPanel = new LayoutPanel
			{
				Caption = "Output Result " + Camera_name,
				AllowClose = false,
				AllowFloat = true,
				AllowDock = true,
				AllowHide = true
			};
			CameraOutputResultView outputView = new CameraOutputResultView();
			outputPanel.Content = outputView;
			TabbedGroup group = new TabbedGroup();
			group.Items.Add(panel);
			group.Items.Add(outputPanel);
			group.SelectedTabIndex = 0;
			_cameraDocks.Add(new CameraDockItem
			{
				CameraIndex = cameraIndex,
				Panel = panel,
				View = view,
				HWindowControl = view.WindowControl,
				OutputPanel = outputPanel,
				OutputView = outputView
			});
			return group;
		}

		// Token: 0x06002182 RID: 8578 RVA: 0x000C4FD0 File Offset: 0x000C31D0
		public static void CreateCameraDocksLive(LayoutGroup rootGroup, List<CameraDockItem_live> _cameraDocks)
		{
			rootGroup.Items.Clear();
			_cameraDocks.Clear();
			int perRow = (CameraRuntimeStore.Count_per_row <= 0) ? 1 : CameraRuntimeStore.Count_per_row;
			LayoutGroup currentRow = null;
			for (int i = 1; i <= CameraRuntimeStore.Cameras.Count; i++)
			{
				bool flag = (i - 1) % perRow == 0;
				if (flag)
				{
					currentRow = new LayoutGroup
					{
						Orientation = Orientation.Horizontal,
						ShowCloseButton = false
					};
					rootGroup.Items.Add(currentRow);
				}
				LayoutPanel panel = CameraDockFactory.CreateCameraPanel_live(_cameraDocks, i, CameraRuntimeStore.Cameras[i - 1].CameraName);
				currentRow.Items.Add(panel);
			}
		}

		// Token: 0x06002183 RID: 8579 RVA: 0x000C5080 File Offset: 0x000C3280
		private static LayoutPanel CreateCameraPanel_live(List<CameraDockItem_live> _cameraDocks, int cameraIndex, string Camera_name)
		{
			LayoutPanel panel = new LayoutPanel
			{
				Caption = Camera_name,
				AllowClose = false,
				AllowFloat = true,
				AllowDock = true,
				AllowHide = true
			};
			Camera_dock_Live view = new Camera_dock_Live();
			view.SetTitle(Camera_name);
			panel.Content = view;
			_cameraDocks.Add(new CameraDockItem_live
			{
				CameraIndex = cameraIndex,
				Panel = panel,
				View = view,
				HWindowControl = view.WindowControl
			});
			return panel;
		}

		// Token: 0x04000DCF RID: 3535
		public static int _maxRow;

		// Token: 0x04000DD0 RID: 3536
		public static int CameraCount;
	}
}
