﻿using System;
using DevExpress.Xpf.Docking;
using HalconDotNet;
using VisionMachine.Controls.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000248 RID: 584
	public class CameraDockItem
	{
		// Token: 0x170009B2 RID: 2482
		// (get) Token: 0x0600212D RID: 8493 RVA: 0x000C37F8 File Offset: 0x000C19F8
		// (set) Token: 0x0600212E RID: 8494 RVA: 0x000C3800 File Offset: 0x000C1A00
		public int CameraIndex { get; set; }

		// Token: 0x170009B3 RID: 2483
		// (get) Token: 0x0600212F RID: 8495 RVA: 0x000C3809 File Offset: 0x000C1A09
		// (set) Token: 0x06002130 RID: 8496 RVA: 0x000C3811 File Offset: 0x000C1A11
		public LayoutPanel Panel { get; set; }

		// Token: 0x170009B4 RID: 2484
		// (get) Token: 0x06002131 RID: 8497 RVA: 0x000C381A File Offset: 0x000C1A1A
		// (set) Token: 0x06002132 RID: 8498 RVA: 0x000C3822 File Offset: 0x000C1A22
		public CameraDockView View { get; set; }

		// Token: 0x170009B5 RID: 2485
		// (get) Token: 0x06002133 RID: 8499 RVA: 0x000C382B File Offset: 0x000C1A2B
		// (set) Token: 0x06002134 RID: 8500 RVA: 0x000C3833 File Offset: 0x000C1A33
		public HSmartWindowControlWPF HWindowControl { get; set; }

		// Token: 0x170009B6 RID: 2486
		// (get) Token: 0x06002135 RID: 8501 RVA: 0x000C383C File Offset: 0x000C1A3C
		// (set) Token: 0x06002136 RID: 8502 RVA: 0x000C3844 File Offset: 0x000C1A44
		public LayoutPanel OutputPanel { get; set; }

		// Token: 0x170009B7 RID: 2487
		// (get) Token: 0x06002137 RID: 8503 RVA: 0x000C384D File Offset: 0x000C1A4D
		// (set) Token: 0x06002138 RID: 8504 RVA: 0x000C3855 File Offset: 0x000C1A55
		public CameraOutputResultView OutputView { get; set; }
	}
}
