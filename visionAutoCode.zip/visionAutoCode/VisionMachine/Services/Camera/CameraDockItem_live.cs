﻿using System;
using DevExpress.Xpf.Docking;
using HalconDotNet;
using VisionMachine.Controls.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000249 RID: 585
	public class CameraDockItem_live
	{
		// Token: 0x170009B8 RID: 2488
		// (get) Token: 0x0600213A RID: 8506 RVA: 0x000C385E File Offset: 0x000C1A5E
		// (set) Token: 0x0600213B RID: 8507 RVA: 0x000C3866 File Offset: 0x000C1A66
		public int CameraIndex { get; set; }

		// Token: 0x170009B9 RID: 2489
		// (get) Token: 0x0600213C RID: 8508 RVA: 0x000C386F File Offset: 0x000C1A6F
		// (set) Token: 0x0600213D RID: 8509 RVA: 0x000C3877 File Offset: 0x000C1A77
		public LayoutPanel Panel { get; set; }

		// Token: 0x170009BA RID: 2490
		// (get) Token: 0x0600213E RID: 8510 RVA: 0x000C3880 File Offset: 0x000C1A80
		// (set) Token: 0x0600213F RID: 8511 RVA: 0x000C3888 File Offset: 0x000C1A88
		public Camera_dock_Live View { get; set; }

		// Token: 0x170009BB RID: 2491
		// (get) Token: 0x06002140 RID: 8512 RVA: 0x000C3891 File Offset: 0x000C1A91
		// (set) Token: 0x06002141 RID: 8513 RVA: 0x000C3899 File Offset: 0x000C1A99
		public HSmartWindowControlWPF HWindowControl { get; set; }
	}
}
