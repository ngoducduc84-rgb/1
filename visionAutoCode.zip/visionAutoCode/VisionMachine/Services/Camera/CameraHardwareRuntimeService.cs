﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using HalconDotNet;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200024A RID: 586
	public static class CameraHardwareRuntimeService
	{
		// Token: 0x06002143 RID: 8515 RVA: 0x000C38A4 File Offset: 0x000C1AA4
		public static void Register(string cameraId, object service)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraId) || service == null;
			if (!flag)
			{
				CameraSnapshotService.Release(cameraId);
				CameraHardwareRuntimeService.Services[cameraId] = service;
			}
		}

		// Token: 0x06002144 RID: 8516 RVA: 0x000C38DC File Offset: 0x000C1ADC
		public static bool IsRegistered(string cameraId)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraId);
			return !flag && CameraHardwareRuntimeService.Services.ContainsKey(cameraId);
		}

		// Token: 0x06002145 RID: 8517 RVA: 0x000C3908 File Offset: 0x000C1B08
		public static bool? TryGetLiveConnectionState(string cameraId)
		{
			object service = CameraHardwareRuntimeService.GetService(cameraId);
			bool flag = service == null;
			bool? result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new bool?(CameraHardwareRuntimeService.IsCameraConnected(service.GetType(), service));
			}
			return result;
		}

		// Token: 0x06002146 RID: 8518 RVA: 0x000C3948 File Offset: 0x000C1B48
		public static void Unregister(string cameraId, object service)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraId);
			if (!flag)
			{
				object registeredService;
				bool flag2 = !CameraHardwareRuntimeService.Services.TryGetValue(cameraId, out registeredService);
				if (!flag2)
				{
					bool flag3 = registeredService == service;
					if (flag3)
					{
						CameraHardwareRuntimeService.Services.Remove(cameraId);
					}
				}
			}
		}

		// Token: 0x06002147 RID: 8519 RVA: 0x000C398F File Offset: 0x000C1B8F
		public static void ApplyExposure(CameraParameterConfig config)
		{
			CameraHardwareRuntimeService.InvokeDoubleMethod((config != null) ? config.ConnectedCameraId : null, "SetExposure", (config != null) ? config.ExposureTime : 0.0);
		}

		// Token: 0x06002148 RID: 8520 RVA: 0x000C39BD File Offset: 0x000C1BBD
		public static void ApplyGain(CameraParameterConfig config)
		{
			CameraHardwareRuntimeService.InvokeDoubleMethod((config != null) ? config.ConnectedCameraId : null, "SetGain", (config != null) ? config.Gain : 0.0);
		}

		// Token: 0x06002149 RID: 8521 RVA: 0x000C39EC File Offset: 0x000C1BEC
		public static void ApplyParameter(CameraParameterConfig config)
		{
			bool flag = config == null;
			if (!flag)
			{
				bool flag2 = CameraHardwareRuntimeService.GetService(config.ConnectedCameraId) != null;
				if (flag2)
				{
					CameraHardwareRuntimeService.InvokeDoubleMethod(config.ConnectedCameraId, "SetExposure", config.ExposureTime);
					CameraHardwareRuntimeService.InvokeDoubleMethod(config.ConnectedCameraId, "SetGain", config.Gain);
					CameraHardwareRuntimeService.InvokeBoolMethod(config.ConnectedCameraId, "SetTriggerMode", config.HardwareTrigger);
					CameraHardwareRuntimeService.InvokeStringMethod(config.ConnectedCameraId, "SetPixelFormat", config.PixelFormat);
					CameraHardwareRuntimeService.InvokeStringMethod(config.ConnectedCameraId, "SetLightSourcePreset", config.LightSourcePreset);
				}
			}
		}

		// Token: 0x0600214A RID: 8522 RVA: 0x000C3A90 File Offset: 0x000C1C90
		public static CameraParameterRange GetGainRange(CameraParameterConfig config)
		{
			return CameraHardwareRuntimeService.GetRange(config, "GetGainRange", (BaslerReflectionCameraService service) => service.GetGainRange());
		}

		// Token: 0x0600214B RID: 8523 RVA: 0x000C3ACC File Offset: 0x000C1CCC
		public static CameraParameterRange GetExposureRange(CameraParameterConfig config)
		{
			return CameraHardwareRuntimeService.GetRange(config, "GetExposureRange", (BaslerReflectionCameraService service) => service.GetExposureRange());
		}

		// Token: 0x0600214C RID: 8524 RVA: 0x000C3B08 File Offset: 0x000C1D08
		public static void GetGainAndExposureRange(CameraParameterConfig config, out CameraParameterRange gain, out CameraParameterRange exposure)
		{
			gain = null;
			exposure = null;
			bool flag = config == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			if (!flag)
			{
				object liveService = CameraHardwareRuntimeService.GetService(config.ConnectedCameraId);
				bool flag2 = liveService != null;
				if (flag2)
				{
					gain = CameraHardwareRuntimeService.InvokeRangeMethod(liveService, "GetGainRange");
					exposure = CameraHardwareRuntimeService.InvokeRangeMethod(liveService, "GetExposureRange");
					bool flag3 = gain != null || exposure != null;
					if (flag3)
					{
						return;
					}
				}
				bool flag4 = config.Vendor == CameraVendor.Hikvision;
				if (flag4)
				{
					try
					{
						gain = HikLiveCameraService.GetFloatRange(config.ConnectedCameraId, "Gain");
					}
					catch
					{
					}
					try
					{
						exposure = HikLiveCameraService.GetFloatRange(config.ConnectedCameraId, "ExposureTime");
					}
					catch
					{
					}
				}
				else
				{
					bool flag5 = config.Vendor != CameraVendor.Basler;
					if (!flag5)
					{
						using (BaslerReflectionCameraService service = CameraHardwareRuntimeService.CreateBaslerService(config))
						{
							bool flag6 = service == null;
							if (!flag6)
							{
								try
								{
									gain = service.GetGainRange();
								}
								catch
								{
								}
								try
								{
									exposure = service.GetExposureRange();
								}
								catch
								{
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x0600214D RID: 8525 RVA: 0x000C3C68 File Offset: 0x000C1E68
		private static CameraParameterRange InvokeRangeMethod(object liveService, string methodName)
		{
			MethodInfo method = (liveService != null) ? liveService.GetType().GetMethod(methodName, Type.EmptyTypes) : null;
			bool flag = method == null;
			CameraParameterRange result;
			if (flag)
			{
				result = null;
			}
			else
			{
				try
				{
					result = (method.Invoke(liveService, null) as CameraParameterRange);
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x0600214E RID: 8526 RVA: 0x000C3CC8 File Offset: 0x000C1EC8
		private static CameraParameterRange GetRange(CameraParameterConfig config, string liveMethodName, Func<BaslerReflectionCameraService, CameraParameterRange> baslerReader)
		{
			bool flag = config == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			CameraParameterRange result;
			if (flag)
			{
				result = null;
			}
			else
			{
				object liveService = CameraHardwareRuntimeService.GetService(config.ConnectedCameraId);
				MethodInfo liveMethod = (liveService != null) ? liveService.GetType().GetMethod(liveMethodName, Type.EmptyTypes) : null;
				bool flag2 = liveMethod != null;
				if (flag2)
				{
					try
					{
						CameraParameterRange range = liveMethod.Invoke(liveService, null) as CameraParameterRange;
						bool flag3 = range != null;
						if (flag3)
						{
							return range;
						}
					}
					catch
					{
					}
				}
				bool flag4 = config.Vendor == CameraVendor.Basler;
				if (flag4)
				{
					using (BaslerReflectionCameraService service = CameraHardwareRuntimeService.CreateBaslerService(config))
					{
						bool flag5 = service != null;
						if (flag5)
						{
							try
							{
								return baslerReader(service);
							}
							catch
							{
							}
						}
					}
				}
				result = null;
			}
			return result;
		}

		// Token: 0x0600214F RID: 8527 RVA: 0x000C3DC4 File Offset: 0x000C1FC4
		public static List<string> GetPixelFormatOptions(CameraParameterConfig config)
		{
			return CameraHardwareRuntimeService.GetEnumOptions(config, "GetPixelFormatOptions", (BaslerReflectionCameraService service) => service.GetPixelFormatOptions());
		}

		// Token: 0x06002150 RID: 8528 RVA: 0x000C3E00 File Offset: 0x000C2000
		public static List<string> GetLightSourcePresetOptions(CameraParameterConfig config)
		{
			return CameraHardwareRuntimeService.GetEnumOptions(config, "GetLightSourcePresetOptions", (BaslerReflectionCameraService service) => service.GetLightSourcePresetOptions());
		}

		// Token: 0x06002151 RID: 8529 RVA: 0x000C3E3C File Offset: 0x000C203C
		public static HObject CaptureImage(CameraParameterConfig config)
		{
			bool flag = config == null;
			if (flag)
			{
				throw new ArgumentNullException("config");
			}
			bool flag2 = string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			if (flag2)
			{
				throw new InvalidOperationException("No serial camera is selected.");
			}
			object liveService = CameraHardwareRuntimeService.GetService(config.ConnectedCameraId);
			Type serviceType = (liveService != null) ? liveService.GetType() : null;
			MethodInfo liveMethod = (serviceType != null) ? serviceType.GetMethod("CopyLatestImage") : null;
			bool flag3 = liveMethod != null;
			if (flag3)
			{
				bool flag4 = !CameraHardwareRuntimeService.IsCameraConnected(serviceType, liveService);
				if (flag4)
				{
					throw new InvalidOperationException("Live camera '" + config.ConnectedCameraId + "' is disconnected.");
				}
				bool flag5 = CameraHardwareRuntimeService.GetLatestImageAgeMs(serviceType, liveService) <= 1000L;
				if (flag5)
				{
					HObject fresh = CameraHardwareRuntimeService.TryCopyLatestImage(liveService, liveMethod);
					bool flag6 = fresh != null;
					if (flag6)
					{
						return fresh;
					}
				}
				bool flag7 = CameraHardwareRuntimeService.IsLiveRunning(serviceType, liveService);
				if (flag7)
				{
					Stopwatch sw = Stopwatch.StartNew();
					while (sw.ElapsedMilliseconds < 1500L)
					{
						Thread.Sleep(25);
						bool flag8 = !CameraHardwareRuntimeService.IsCameraConnected(serviceType, liveService);
						if (flag8)
						{
							throw new InvalidOperationException("Live camera '" + config.ConnectedCameraId + "' is disconnected.");
						}
						bool flag9 = CameraHardwareRuntimeService.GetLatestImageAgeMs(serviceType, liveService) > 1000L;
						if (!flag9)
						{
							HObject latest = CameraHardwareRuntimeService.TryCopyLatestImage(liveService, liveMethod);
							bool flag10 = latest != null;
							if (flag10)
							{
								return latest;
							}
						}
					}
					throw new InvalidOperationException("Live camera '" + config.ConnectedCameraId + "' produced no fresh frame within the capture timeout (the camera may be disconnected).");
				}
			}
			return CameraSnapshotService.Capture(config);
		}

		// Token: 0x06002152 RID: 8530 RVA: 0x000C3FD8 File Offset: 0x000C21D8
		private static bool IsCameraConnected(Type serviceType, object liveService)
		{
			try
			{
				MethodInfo method = (serviceType != null) ? serviceType.GetMethod("IsCameraConnected", Type.EmptyTypes) : null;
				bool flag = method != null && method.ReturnType == typeof(bool);
				if (flag)
				{
					return (bool)method.Invoke(liveService, null);
				}
			}
			catch
			{
			}
			return true;
		}

		// Token: 0x06002153 RID: 8531 RVA: 0x000C4050 File Offset: 0x000C2250
		private static long GetLatestImageAgeMs(Type serviceType, object liveService)
		{
			try
			{
				MethodInfo method = (serviceType != null) ? serviceType.GetMethod("GetLatestImageAgeMs", Type.EmptyTypes) : null;
				bool flag = method != null && method.ReturnType == typeof(long);
				if (flag)
				{
					return (long)method.Invoke(liveService, null);
				}
			}
			catch
			{
			}
			return 0L;
		}

		// Token: 0x06002154 RID: 8532 RVA: 0x000C40CC File Offset: 0x000C22CC
		private static bool IsLiveRunning(Type serviceType, object liveService)
		{
			try
			{
				PropertyInfo prop = (serviceType != null) ? serviceType.GetProperty("IsRunning") : null;
				bool flag = prop != null && prop.PropertyType == typeof(bool);
				if (flag)
				{
					return (bool)prop.GetValue(liveService);
				}
			}
			catch
			{
			}
			return false;
		}

		// Token: 0x06002155 RID: 8533 RVA: 0x000C4140 File Offset: 0x000C2340
		private static HObject TryCopyLatestImage(object liveService, MethodInfo liveMethod)
		{
			object[] args = new object[1];
			try
			{
				bool hasImage = (bool)liveMethod.Invoke(liveService, args);
				HObject liveImage;
				bool flag;
				if (hasImage)
				{
					liveImage = (args[0] as HObject);
					if (liveImage != null)
					{
						flag = liveImage.IsInitialized();
						goto IL_2F;
					}
				}
				flag = false;
				IL_2F:
				bool flag2 = flag;
				if (flag2)
				{
					return liveImage;
				}
				HObject hobject = args[0] as HObject;
				if (hobject != null)
				{
					hobject.Dispose();
				}
			}
			catch
			{
				HObject hobject2 = args[0] as HObject;
				if (hobject2 != null)
				{
					hobject2.Dispose();
				}
			}
			return null;
		}

		// Token: 0x06002156 RID: 8534 RVA: 0x000C41D0 File Offset: 0x000C23D0
		private static object GetService(string cameraId)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraId);
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				object service;
				result = (CameraHardwareRuntimeService.Services.TryGetValue(cameraId, out service) ? service : null);
			}
			return result;
		}

		// Token: 0x06002157 RID: 8535 RVA: 0x000C4204 File Offset: 0x000C2404
		private static List<string> GetEnumOptions(CameraParameterConfig config, string liveMethodName, Func<BaslerReflectionCameraService, List<string>> baslerReader)
		{
			List<string> result = new List<string>();
			bool flag = config == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			List<string> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				object liveService = CameraHardwareRuntimeService.GetService(config.ConnectedCameraId);
				MethodInfo liveMethod = (liveService != null) ? liveService.GetType().GetMethod(liveMethodName) : null;
				bool flag2 = liveMethod != null;
				if (flag2)
				{
					try
					{
						result = (liveMethod.Invoke(liveService, null) as List<string>);
						bool flag3 = result != null && result.Count > 0;
						if (flag3)
						{
							return result;
						}
					}
					catch
					{
					}
				}
				bool flag4 = config.Vendor == CameraVendor.Hikvision && liveMethodName == "GetPixelFormatOptions";
				if (flag4)
				{
					try
					{
						result = HikLiveCameraService.GetSupportedPixelFormats(config.ConnectedCameraId);
						bool flag5 = result != null && result.Count > 0;
						if (flag5)
						{
							return result;
						}
					}
					catch
					{
					}
				}
				bool flag6 = config.Vendor != CameraVendor.Basler;
				if (flag6)
				{
					result2 = (result ?? new List<string>());
				}
				else
				{
					using (BaslerReflectionCameraService service = CameraHardwareRuntimeService.CreateBaslerService(config))
					{
						bool flag7 = service == null;
						if (flag7)
						{
							return result ?? new List<string>();
						}
						try
						{
							result = baslerReader(service);
						}
						catch
						{
						}
					}
					result2 = (result ?? new List<string>());
				}
			}
			return result2;
		}

		// Token: 0x06002158 RID: 8536 RVA: 0x000C4394 File Offset: 0x000C2594
		private static bool InvokeDoubleMethod(string cameraId, string methodName, double value)
		{
			object service = CameraHardwareRuntimeService.GetService(cameraId);
			MethodInfo method = (service != null) ? service.GetType().GetMethod(methodName) : null;
			bool flag = method == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					method.Invoke(service, new object[]
					{
						value
					});
				}
				catch
				{
				}
				result = true;
			}
			return result;
		}

		// Token: 0x06002159 RID: 8537 RVA: 0x000C4404 File Offset: 0x000C2604
		private static bool InvokeBoolMethod(string cameraId, string methodName, bool value)
		{
			object service = CameraHardwareRuntimeService.GetService(cameraId);
			MethodInfo method = (service != null) ? service.GetType().GetMethod(methodName) : null;
			bool flag = method == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					method.Invoke(service, new object[]
					{
						value
					});
				}
				catch
				{
				}
				result = true;
			}
			return result;
		}

		// Token: 0x0600215A RID: 8538 RVA: 0x000C4474 File Offset: 0x000C2674
		private static bool InvokeStringMethod(string cameraId, string methodName, string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				object service = CameraHardwareRuntimeService.GetService(cameraId);
				MethodInfo method = (service != null) ? service.GetType().GetMethod(methodName) : null;
				bool flag2 = method == null;
				if (flag2)
				{
					result = false;
				}
				else
				{
					try
					{
						method.Invoke(service, new object[]
						{
							value
						});
					}
					catch
					{
					}
					result = true;
				}
			}
			return result;
		}

		// Token: 0x0600215B RID: 8539 RVA: 0x000C44EC File Offset: 0x000C26EC
		private static bool TryApplyBaslerParameter(CameraParameterConfig config)
		{
			bool result;
			using (BaslerReflectionCameraService service = CameraHardwareRuntimeService.CreateBaslerService(config))
			{
				bool flag = service == null;
				if (flag)
				{
					result = false;
				}
				else
				{
					try
					{
						service.ApplyParameter(config);
						result = true;
					}
					catch
					{
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x0600215C RID: 8540 RVA: 0x000C454C File Offset: 0x000C274C
		private static bool TryApplyBaslerExposure(CameraParameterConfig config)
		{
			bool result;
			using (BaslerReflectionCameraService service = CameraHardwareRuntimeService.CreateBaslerService(config))
			{
				bool flag = service == null;
				if (flag)
				{
					result = false;
				}
				else
				{
					try
					{
						service.SetExposure(config.ExposureTime);
						result = true;
					}
					catch
					{
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x0600215D RID: 8541 RVA: 0x000C45B0 File Offset: 0x000C27B0
		private static bool TryApplyBaslerGain(CameraParameterConfig config)
		{
			bool result;
			using (BaslerReflectionCameraService service = CameraHardwareRuntimeService.CreateBaslerService(config))
			{
				bool flag = service == null;
				if (flag)
				{
					result = false;
				}
				else
				{
					try
					{
						service.SetGain(config.Gain);
						result = true;
					}
					catch
					{
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x0600215E RID: 8542 RVA: 0x000C4614 File Offset: 0x000C2814
		private static BaslerReflectionCameraService CreateBaslerService(CameraParameterConfig config)
		{
			bool flag = config == null || config.Vendor != CameraVendor.Basler;
			BaslerReflectionCameraService result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = BaslerReflectionCameraService.Create(config.ConnectedCameraId);
			}
			return result;
		}

		// Token: 0x04000DC5 RID: 3525
		private static readonly Dictionary<string, object> Services = new Dictionary<string, object>();

		// Token: 0x04000DC6 RID: 3526
		private const long FreshFrameMaxAgeMs = 1000L;
	}
}
