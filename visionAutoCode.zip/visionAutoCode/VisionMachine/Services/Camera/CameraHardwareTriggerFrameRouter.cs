﻿using System;
using System.Collections.ObjectModel;
using HalconDotNet;
using VisionMachine.Models.Camera;
using VisionMachine.Services.Calibration;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Home;
using VisionMachine.Views.Main;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000247 RID: 583
	public static class CameraHardwareTriggerFrameRouter
	{
		// Token: 0x0600212B RID: 8491 RVA: 0x000C36A4 File Offset: 0x000C18A4
		public static void Publish(CameraParameterConfig config, HObject image)
		{
			bool flag = config == null || !config.HardwareTrigger || image == null || !image.IsInitialized();
			if (!flag)
			{
				string cameraName = CameraHardwareTriggerFrameRouter.ResolveCameraName(config);
				bool flag2 = string.IsNullOrWhiteSpace(cameraName);
				if (!flag2)
				{
					bool flag3 = CalibHandEyeWorkflowService.TryConsumeHardwareTriggerFrame(cameraName, image);
					if (!flag3)
					{
						HObject copy = null;
						try
						{
							HOperatorSet.CopyImage(image, out copy);
							Form_home.PostHardwareCameraTrigger(cameraName, copy);
							copy = null;
						}
						catch
						{
							if (copy != null)
							{
								copy.Dispose();
							}
						}
					}
				}
			}
		}

		// Token: 0x0600212C RID: 8492 RVA: 0x000C3730 File Offset: 0x000C1930
		private static string ResolveCameraName(CameraParameterConfig config)
		{
			MainWindow instance = MainWindow.instance;
			ObservableCollection<CameraNode> observableCollection;
			if (instance == null)
			{
				observableCollection = null;
			}
			else
			{
				MainViewModel mainViewModel = instance.MainViewModel;
				observableCollection = ((mainViewModel != null) ? mainViewModel.Cameras : null);
			}
			ObservableCollection<CameraNode> cameras = observableCollection;
			bool flag = cameras == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				foreach (CameraNode camera in cameras)
				{
					bool flag2 = ((camera != null) ? camera.CameraConfig : null) == null;
					if (!flag2)
					{
						bool flag3 = camera.CameraConfig == config || string.Equals(camera.CameraConfig.ConnectedCameraId, config.ConnectedCameraId, StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							return camera.Name;
						}
					}
				}
				result = null;
			}
			return result;
		}
	}
}
