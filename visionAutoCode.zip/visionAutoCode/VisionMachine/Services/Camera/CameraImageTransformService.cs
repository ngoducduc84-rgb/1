﻿using System;
using HalconDotNet;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000245 RID: 581
	internal static class CameraImageTransformService
	{
		// Token: 0x06002109 RID: 8457 RVA: 0x000C2018 File Offset: 0x000C0218
		public static HObject Apply(HObject input, CameraParameterConfig config)
		{
			bool flag = input == null || !input.IsInitialized() || config == null;
			HObject result;
			if (flag)
			{
				result = input;
			}
			else
			{
				HObject current = input;
				bool ownsCurrent = false;
				try
				{
					bool mirrorRow = config.MirrorRow;
					if (mirrorRow)
					{
						current = CameraImageTransformService.ReplaceWithMirror(current, "row", ref ownsCurrent);
					}
					bool mirrorColumn = config.MirrorColumn;
					if (mirrorColumn)
					{
						current = CameraImageTransformService.ReplaceWithMirror(current, "column", ref ownsCurrent);
					}
					bool flag2 = Math.Abs(CameraImageTransformService.NormalizeAngle(config.RotationImage)) > 0.0001;
					if (flag2)
					{
						current = CameraImageTransformService.ReplaceWithRotation(current, config, ref ownsCurrent);
					}
					result = current;
				}
				catch
				{
					bool flag3 = ownsCurrent && current != input;
					if (flag3)
					{
						current.Dispose();
					}
					result = input;
				}
			}
			return result;
		}

		// Token: 0x0600210A RID: 8458 RVA: 0x000C20E0 File Offset: 0x000C02E0
		private static HObject ReplaceWithMirror(HObject input, string mode, ref bool ownsInput)
		{
			HObject output;
			HOperatorSet.MirrorImage(input, out output, mode);
			bool flag = ownsInput;
			if (flag)
			{
				input.Dispose();
			}
			ownsInput = true;
			return output;
		}

		// Token: 0x0600210B RID: 8459 RVA: 0x000C2114 File Offset: 0x000C0314
		private static HObject ReplaceWithRotation(HObject input, CameraParameterConfig config, ref bool ownsInput)
		{
			HTuple widthTuple;
			HTuple heightTuple;
			HOperatorSet.GetImageSize(input, out widthTuple, out heightTuple);
			double width = widthTuple.D;
			double height = heightTuple.D;
			double angleRad = config.RotationImage * 3.141592653589793 / 180.0;
			int outputWidth = widthTuple.I;
			int outputHeight = heightTuple.I;
			bool expandRotationCanvas = config.ExpandRotationCanvas;
			if (expandRotationCanvas)
			{
				double cos = Math.Abs(Math.Cos(angleRad));
				double sin = Math.Abs(Math.Sin(angleRad));
				outputWidth = Math.Max(1, (int)Math.Ceiling(width * cos + height * sin));
				outputHeight = Math.Max(1, (int)Math.Ceiling(width * sin + height * cos));
			}
			double sourceRow = (height - 1.0) / 2.0;
			double sourceColumn = (width - 1.0) / 2.0;
			double targetRow = ((double)outputHeight - 1.0) / 2.0;
			double targetColumn = ((double)outputWidth - 1.0) / 2.0;
			HTuple transform;
			HOperatorSet.VectorAngleToRigid(sourceRow, sourceColumn, 0, targetRow, targetColumn, angleRad, out transform);
			HObject rotated;
			HOperatorSet.AffineTransImageSize(input, out rotated, transform, "constant", outputWidth, outputHeight);
			HObject output = CameraImageTransformService.PaintRotationBackground(input, rotated, transform, outputWidth, outputHeight, config.RotationFillColor);
			bool flag = ownsInput;
			if (flag)
			{
				input.Dispose();
			}
			bool flag2 = output != rotated;
			if (flag2)
			{
				rotated.Dispose();
			}
			ownsInput = true;
			return output;
		}

		// Token: 0x0600210C RID: 8460 RVA: 0x000C22BC File Offset: 0x000C04BC
		private static HObject PaintRotationBackground(HObject source, HObject rotated, HTuple transform, int outputWidth, int outputHeight, string fillColor)
		{
			HObject sourceRegion = null;
			HObject transformedRegion = null;
			HObject canvasRegion = null;
			HObject outsideRegion = null;
			HObject result;
			try
			{
				HTuple sourceWidth;
				HTuple sourceHeight;
				HOperatorSet.GetImageSize(source, out sourceWidth, out sourceHeight);
				HOperatorSet.GenRectangle1(out sourceRegion, 0, 0, sourceHeight.I - 1, sourceWidth.I - 1);
				HOperatorSet.AffineTransRegion(sourceRegion, out transformedRegion, transform, "nearest_neighbor");
				HOperatorSet.GenRectangle1(out canvasRegion, 0, 0, outputHeight - 1, outputWidth - 1);
				HOperatorSet.Difference(canvasRegion, transformedRegion, out outsideRegion);
				HTuple channelCount;
				HOperatorSet.CountChannels(rotated, out channelCount);
				HTuple grayValues = CameraImageTransformService.BuildFillTuple(fillColor, (channelCount.Length > 0) ? channelCount[0].I : 1);
				HObject painted;
				HOperatorSet.PaintRegion(outsideRegion, rotated, out painted, grayValues, "fill");
				result = painted;
			}
			catch
			{
				HObject copy;
				HOperatorSet.CopyImage(rotated, out copy);
				result = copy;
			}
			finally
			{
				if (sourceRegion != null)
				{
					sourceRegion.Dispose();
				}
				if (transformedRegion != null)
				{
					transformedRegion.Dispose();
				}
				if (canvasRegion != null)
				{
					canvasRegion.Dispose();
				}
				if (outsideRegion != null)
				{
					outsideRegion.Dispose();
				}
			}
			return result;
		}

		// Token: 0x0600210D RID: 8461 RVA: 0x000C23FC File Offset: 0x000C05FC
		private static HTuple BuildFillTuple(string color, int channels)
		{
			byte r;
			byte g;
			byte b;
			CameraImageTransformService.GetRgb(color, out r, out g, out b);
			bool flag = channels >= 3;
			HTuple result;
			if (flag)
			{
				result = new HTuple(new int[]
				{
					(int)r,
					(int)g,
					(int)b
				});
			}
			else
			{
				int gray = (int)Math.Round(0.299 * (double)r + 0.587 * (double)g + 0.114 * (double)b);
				result = new HTuple(new int[]
				{
					gray
				});
			}
			return result;
		}

		// Token: 0x0600210E RID: 8462 RVA: 0x000C2484 File Offset: 0x000C0684
		private static void GetRgb(string color, out byte r, out byte g, out byte b)
		{
			string text = (color ?? "Black").Trim().ToLowerInvariant();
			string text2 = text;
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
			if (num <= 1231115066U)
			{
				if (num <= 96429129U)
				{
					if (num != 18738364U)
					{
						if (num == 96429129U)
						{
							if (text2 == "yellow")
							{
								r = byte.MaxValue;
								g = byte.MaxValue;
								b = 0;
								return;
							}
						}
					}
					else if (text2 == "green")
					{
						r = 0;
						g = byte.MaxValue;
						b = 0;
						return;
					}
				}
				else if (num != 1089765596U)
				{
					if (num == 1231115066U)
					{
						if (text2 == "cyan")
						{
							r = 0;
							g = byte.MaxValue;
							b = byte.MaxValue;
							return;
						}
					}
				}
				else if (text2 == "red")
				{
					r = byte.MaxValue;
					g = 0;
					b = 0;
					return;
				}
			}
			else
			{
				if (num > 2197550541U)
				{
					if (num != 2995788198U)
					{
						if (num != 3130700698U)
						{
							if (num != 3724674918U)
							{
								goto IL_203;
							}
							if (!(text2 == "white"))
							{
								goto IL_203;
							}
							r = byte.MaxValue;
							g = byte.MaxValue;
							b = byte.MaxValue;
							return;
						}
						else if (!(text2 == "gray"))
						{
							goto IL_203;
						}
					}
					else if (!(text2 == "grey"))
					{
						goto IL_203;
					}
					r = 128;
					g = 128;
					b = 128;
					return;
				}
				if (num != 1676028392U)
				{
					if (num == 2197550541U)
					{
						if (text2 == "blue")
						{
							r = 0;
							g = 0;
							b = byte.MaxValue;
							return;
						}
					}
				}
				else if (text2 == "magenta")
				{
					r = byte.MaxValue;
					g = 0;
					b = byte.MaxValue;
					return;
				}
			}
			IL_203:
			r = 0;
			g = 0;
			b = 0;
		}

		// Token: 0x0600210F RID: 8463 RVA: 0x000C26A0 File Offset: 0x000C08A0
		private static double NormalizeAngle(double angle)
		{
			double normalized = angle % 360.0;
			bool flag = normalized < 0.0;
			if (flag)
			{
				normalized += 360.0;
			}
			return normalized;
		}
	}
}
