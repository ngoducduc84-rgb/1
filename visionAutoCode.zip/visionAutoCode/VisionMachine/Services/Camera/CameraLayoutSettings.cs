﻿using System;
using System.IO;
using Newtonsoft.Json;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200024B RID: 587
	public class CameraLayoutSettings
	{
		// Token: 0x170009BC RID: 2492
		// (get) Token: 0x06002160 RID: 8544 RVA: 0x000C4658 File Offset: 0x000C2858
		// (set) Token: 0x06002161 RID: 8545 RVA: 0x000C4660 File Offset: 0x000C2860
		public int CameraCount { get; set; } = 4;

		// Token: 0x170009BD RID: 2493
		// (get) Token: 0x06002162 RID: 8546 RVA: 0x000C4669 File Offset: 0x000C2869
		// (set) Token: 0x06002163 RID: 8547 RVA: 0x000C4671 File Offset: 0x000C2871
		public int MaxCamerasPerRow { get; set; } = 3;

		// Token: 0x06002164 RID: 8548 RVA: 0x000C467C File Offset: 0x000C287C
		public static void SaveToFile(string filePath, CameraLayoutSettings settings)
		{
			string json = JsonConvert.SerializeObject(settings, Formatting.Indented);
			File.WriteAllText(filePath, json);
		}

		// Token: 0x06002165 RID: 8549 RVA: 0x000C469C File Offset: 0x000C289C
		public static CameraLayoutSettings LoadFromFile(string filePath)
		{
			bool flag = !File.Exists(filePath);
			CameraLayoutSettings result;
			if (flag)
			{
				result = new CameraLayoutSettings();
			}
			else
			{
				string json = File.ReadAllText(filePath);
				bool flag2 = string.IsNullOrWhiteSpace(json);
				if (flag2)
				{
					result = new CameraLayoutSettings();
				}
				else
				{
					result = (JsonConvert.DeserializeObject<CameraLayoutSettings>(json) ?? new CameraLayoutSettings());
				}
			}
			return result;
		}
	}
}
