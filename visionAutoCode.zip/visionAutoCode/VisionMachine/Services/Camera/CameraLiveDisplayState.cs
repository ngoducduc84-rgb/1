﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Input;
using HalconDotNet;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000246 RID: 582
	public sealed class CameraLiveDisplayState : IDisposable
	{
		// Token: 0x14000034 RID: 52
		// (add) Token: 0x06002110 RID: 8464 RVA: 0x000C26DC File Offset: 0x000C08DC
		// (remove) Token: 0x06002111 RID: 8465 RVA: 0x000C2714 File Offset: 0x000C0914
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event Action<string> PixelInfoChanged;

		// Token: 0x170009B1 RID: 2481
		// (get) Token: 0x06002112 RID: 8466 RVA: 0x000C274C File Offset: 0x000C094C
		public bool HasImage
		{
			get
			{
				return this._latestImage != null && this._latestImage.IsInitialized();
			}
		}

		// Token: 0x06002113 RID: 8467 RVA: 0x000C2774 File Offset: 0x000C0974
		public CameraLiveDisplayState(HSmartWindowControlWPF display)
		{
			this._display = display;
		}

		// Token: 0x06002114 RID: 8468 RVA: 0x000C27AD File Offset: 0x000C09AD
		public void DisplayFrame(HObject image, int width, int height)
		{
			this.DisplayFrame(image, width, height, null);
		}

		// Token: 0x06002115 RID: 8469 RVA: 0x000C27BC File Offset: 0x000C09BC
		public void DisplayFrame(HObject image, int width, int height, CameraParameterConfig config)
		{
			bool flag = this._display == null || image == null || !image.IsInitialized() || width <= 0 || height <= 0;
			if (!flag)
			{
				bool imageSizeChanged = this._imageWidth != width || this._imageHeight != height;
				this._imageWidth = width;
				this._imageHeight = height;
				this.UpdateFps();
				this.StoreLatestImageIfDue(image);
				HWindow window = this._display.HalconWindow;
				window.ClearWindow();
				bool flag2 = this._fitRequested || imageSizeChanged || !this._hasUserView;
				if (flag2)
				{
					window.SetPart(0, 0, height - 1, width - 1);
					this._fitRequested = false;
				}
				window.DispObj(image);
				CameraLiveDisplayState.DrawCenterOverlay(window, width, height, config);
				this.PublishPixelInfoIfDue();
			}
		}

		// Token: 0x06002116 RID: 8470 RVA: 0x000C288C File Offset: 0x000C0A8C
		private static void DrawCenterOverlay(HWindow window, int width, int height, CameraParameterConfig config)
		{
			bool flag = window == null || config == null || !config.ShowCenter || width <= 0 || height <= 0;
			if (!flag)
			{
				double centerRow = (double)(height - 1) / 2.0;
				double centerColumn = (double)(width - 1) / 2.0;
				double halfLength = Math.Max(5.0, (config.CenterLength <= 0.0) ? ((double)Math.Min(width, height) / 10.0) : (config.CenterLength / 2.0));
				double angle = config.CenterAngle * 3.141592653589793 / 180.0;
				CameraLiveDisplayState.DrawCenterLine(window, centerRow, centerColumn, halfLength, angle);
				CameraLiveDisplayState.DrawCenterLine(window, centerRow, centerColumn, halfLength, angle + 1.5707963267948966);
				HOperatorSet.SetColor(window, "cyan");
				HOperatorSet.SetLineWidth(window, 1);
				HOperatorSet.DispCross(window, centerRow, centerColumn, Math.Max(12.0, halfLength * 0.2), angle);
			}
		}

		// Token: 0x06002117 RID: 8471 RVA: 0x000C29C4 File Offset: 0x000C0BC4
		private static void DrawCenterLine(HWindow window, double centerRow, double centerColumn, double halfLength, double angle)
		{
			double rowDelta = Math.Sin(angle) * halfLength;
			double columnDelta = Math.Cos(angle) * halfLength;
			HOperatorSet.SetColor(window, "cyan");
			HOperatorSet.SetLineWidth(window, 2);
			HOperatorSet.DispLine(window, centerRow - rowDelta, centerColumn - columnDelta, centerRow + rowDelta, centerColumn + columnDelta);
		}

		// Token: 0x06002118 RID: 8472 RVA: 0x000C2A3A File Offset: 0x000C0C3A
		public void Fit()
		{
			this._fitRequested = true;
			this._hasUserView = false;
		}

		// Token: 0x06002119 RID: 8473 RVA: 0x000C2A4C File Offset: 0x000C0C4C
		public void MouseWheel(MouseWheelEventArgs e)
		{
			bool flag = e == null || this._display == null || this._imageWidth <= 0 || this._imageHeight <= 0;
			if (!flag)
			{
				e.Handled = true;
				HWindow window = this._display.HalconWindow;
				HTuple row;
				HTuple col;
				HTuple row2;
				HTuple col2;
				window.GetPart(out row, out col, out row2, out col2);
				double controlWidth = this._display.ActualWidth;
				double controlHeight = this._display.ActualHeight;
				bool flag2 = controlWidth <= 0.0 || controlHeight <= 0.0;
				if (!flag2)
				{
					double partHeight = row2.D - row.D + 1.0;
					double partWidth = col2.D - col.D + 1.0;
					bool flag3 = partHeight <= 1.0 || partWidth <= 1.0;
					if (!flag3)
					{
						double factor = (e.Delta > 0) ? 0.8 : 1.25;
						double newHeight = Math.Max(8.0, Math.Min((double)this._imageHeight * 20.0, partHeight * factor));
						double newWidth = Math.Max(8.0, Math.Min((double)this._imageWidth * 20.0, partWidth * factor));
						Point mouse = e.GetPosition(this._display);
						double mouseRow = row.D + mouse.Y * partHeight / controlHeight;
						double mouseColumn = col.D + mouse.X * partWidth / controlWidth;
						double relativeY = mouse.Y / controlHeight;
						double relativeX = mouse.X / controlWidth;
						double newRow = mouseRow - relativeY * newHeight;
						double newCol = mouseColumn - relativeX * newWidth;
						window.SetPart((int)Math.Round(newRow), (int)Math.Round(newCol), (int)Math.Round(newRow + newHeight - 1.0), (int)Math.Round(newCol + newWidth - 1.0));
						this._hasUserView = true;
						this._fitRequested = false;
					}
				}
			}
		}

		// Token: 0x0600211A RID: 8474 RVA: 0x000C2C7C File Offset: 0x000C0E7C
		public void MouseDown(MouseButtonEventArgs e)
		{
			bool flag = e == null || e.ChangedButton != MouseButton.Middle;
			if (!flag)
			{
				this._isPanning = true;
				this._lastMousePosition = e.GetPosition(this._display);
				this._display.CaptureMouse();
				this._display.Cursor = Cursors.SizeAll;
				e.Handled = true;
			}
		}

		// Token: 0x0600211B RID: 8475 RVA: 0x000C2CE4 File Offset: 0x000C0EE4
		public void MouseMove(MouseEventArgs e)
		{
			bool flag = e != null;
			if (flag)
			{
				this._lastInspectorPosition = e.GetPosition(this._display);
				this._hasInspectorPosition = true;
				this.PublishPixelInfoIfDue();
			}
			bool flag2 = !this._isPanning || e == null || this._display == null;
			if (!flag2)
			{
				HWindow window = this._display.HalconWindow;
				HTuple row;
				HTuple col;
				HTuple row2;
				HTuple col2;
				window.GetPart(out row, out col, out row2, out col2);
				Point currentPosition = e.GetPosition(this._display);
				double dx = currentPosition.X - this._lastMousePosition.X;
				double dy = currentPosition.Y - this._lastMousePosition.Y;
				this._lastMousePosition = currentPosition;
				double controlWidth = this._display.ActualWidth;
				double controlHeight = this._display.ActualHeight;
				bool flag3 = controlWidth <= 0.0 || controlHeight <= 0.0;
				if (!flag3)
				{
					double partWidth = col2.D - col.D + 1.0;
					double partHeight = row2.D - row.D + 1.0;
					double imageDx = dx * partWidth / controlWidth;
					double imageDy = dy * partHeight / controlHeight;
					window.SetPart((int)Math.Round(row.D - imageDy), (int)Math.Round(col.D - imageDx), (int)Math.Round(row2.D - imageDy), (int)Math.Round(col2.D - imageDx));
					this._hasUserView = true;
					e.Handled = true;
				}
			}
		}

		// Token: 0x0600211C RID: 8476 RVA: 0x000C2E7C File Offset: 0x000C107C
		public void Dispose()
		{
			this.DisposeLatestImage();
		}

		// Token: 0x0600211D RID: 8477 RVA: 0x000C2E88 File Offset: 0x000C1088
		public void SaveCurrentImage(string savePath)
		{
			bool flag = string.IsNullOrWhiteSpace(savePath);
			if (flag)
			{
				throw new ArgumentException("Save path is empty.");
			}
			bool flag2 = !this.HasImage;
			if (flag2)
			{
				throw new InvalidOperationException("No live image is available to save.");
			}
			string format = CameraLiveDisplayState.ResolveImageFormat(savePath);
			HOperatorSet.WriteImage(this._latestImage, format, 0, savePath);
		}

		// Token: 0x0600211E RID: 8478 RVA: 0x000C2EE8 File Offset: 0x000C10E8
		public HObject GetCurrentImageCopy()
		{
			bool flag = !this.HasImage;
			HObject result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HObject copy;
				HOperatorSet.CopyImage(this._latestImage, out copy);
				result = copy;
			}
			return result;
		}

		// Token: 0x0600211F RID: 8479 RVA: 0x000C2F1C File Offset: 0x000C111C
		public void MouseUp(MouseButtonEventArgs e)
		{
			bool flag = e == null || e.ChangedButton != MouseButton.Middle;
			if (!flag)
			{
				this._isPanning = false;
				bool isMouseCaptured = this._display.IsMouseCaptured;
				if (isMouseCaptured)
				{
					this._display.ReleaseMouseCapture();
				}
				this._display.Cursor = Cursors.Arrow;
				e.Handled = true;
			}
		}

		// Token: 0x06002120 RID: 8480 RVA: 0x000C2F80 File Offset: 0x000C1180
		private void StoreLatestImage(HObject image)
		{
			HObject copy = null;
			try
			{
				HOperatorSet.CopyImage(image, out copy);
			}
			catch
			{
				if (copy != null)
				{
					copy.Dispose();
				}
				copy = null;
			}
			this.DisposeLatestImage();
			this._latestImage = copy;
		}

		// Token: 0x06002121 RID: 8481 RVA: 0x000C2FD0 File Offset: 0x000C11D0
		private void StoreLatestImageIfDue(HObject image)
		{
			bool flag = this._latestImage != null && this._latestImage.IsInitialized() && this._latestImageStopwatch.ElapsedMilliseconds < 100L;
			if (!flag)
			{
				this.StoreLatestImage(image);
				this._latestImageStopwatch.Restart();
			}
		}

		// Token: 0x06002122 RID: 8482 RVA: 0x000C3024 File Offset: 0x000C1224
		private void DisposeLatestImage()
		{
			try
			{
				HObject latestImage = this._latestImage;
				if (latestImage != null)
				{
					latestImage.Dispose();
				}
			}
			catch
			{
			}
			this._latestImage = null;
		}

		// Token: 0x06002123 RID: 8483 RVA: 0x000C3064 File Offset: 0x000C1264
		private void UpdatePixelInfo(Point controlPosition)
		{
			string text = this.BuildPixelInfoText(controlPosition);
			Action<string> pixelInfoChanged = this.PixelInfoChanged;
			if (pixelInfoChanged != null)
			{
				pixelInfoChanged(text);
			}
		}

		// Token: 0x06002124 RID: 8484 RVA: 0x000C3090 File Offset: 0x000C1290
		private void PublishPixelInfo()
		{
			bool hasInspectorPosition = this._hasInspectorPosition;
			if (hasInspectorPosition)
			{
				this.UpdatePixelInfo(this._lastInspectorPosition);
			}
			else
			{
				Action<string> pixelInfoChanged = this.PixelInfoChanged;
				if (pixelInfoChanged != null)
				{
					pixelInfoChanged(this.BuildNoPixelInfoText());
				}
			}
		}

		// Token: 0x06002125 RID: 8485 RVA: 0x000C30D0 File Offset: 0x000C12D0
		private void PublishPixelInfoIfDue()
		{
			bool flag = this._pixelInfoStopwatch.ElapsedMilliseconds < 100L;
			if (!flag)
			{
				this.PublishPixelInfo();
				this._pixelInfoStopwatch.Restart();
			}
		}

		// Token: 0x06002126 RID: 8486 RVA: 0x000C3108 File Offset: 0x000C1308
		private void UpdateFps()
		{
			this._framesSinceFpsUpdate++;
			double elapsedMs = this._fpsStopwatch.Elapsed.TotalMilliseconds;
			bool flag = elapsedMs < 500.0;
			if (!flag)
			{
				this._fps = (double)this._framesSinceFpsUpdate * 1000.0 / elapsedMs;
				this._framesSinceFpsUpdate = 0;
				this._fpsStopwatch.Restart();
			}
		}

		// Token: 0x06002127 RID: 8487 RVA: 0x000C3178 File Offset: 0x000C1378
		private string BuildNoPixelInfoText()
		{
			bool flag = this._imageWidth <= 0 || this._imageHeight <= 0;
			string result;
			if (flag)
			{
				result = string.Format("X: -, Y: -, Gray: -, Size: - x -, FPS: {0:0.0}", this._fps);
			}
			else
			{
				result = string.Format("X: -, Y: -, Gray: -, Size: {0} x {1}, FPS: {2:0.0}", this._imageWidth, this._imageHeight, this._fps);
			}
			return result;
		}

		// Token: 0x06002128 RID: 8488 RVA: 0x000C31EC File Offset: 0x000C13EC
		private string BuildPixelInfoText(Point controlPosition)
		{
			bool flag = this._display == null || this._latestImage == null || !this._latestImage.IsInitialized() || this._imageWidth <= 0 || this._imageHeight <= 0;
			string result;
			if (flag)
			{
				result = this.BuildNoPixelInfoText();
			}
			else
			{
				int row;
				int column;
				bool flag2 = !this.TryGetImagePoint(controlPosition, out row, out column);
				if (flag2)
				{
					result = string.Format("X: -, Y: -, Gray: -, Size: {0} x {1}, FPS: {2:0.0}", this._imageWidth, this._imageHeight, this._fps);
				}
				else
				{
					bool flag3 = row < 0 || column < 0 || row >= this._imageHeight || column >= this._imageWidth;
					if (flag3)
					{
						result = string.Format("X: -, Y: -, Gray: -, Size: {0} x {1}, FPS: {2:0.0}", this._imageWidth, this._imageHeight, this._fps);
					}
					else
					{
						try
						{
							HTuple channelCount;
							HOperatorSet.CountChannels(this._latestImage, out channelCount);
							HTuple pixelValue;
							HOperatorSet.GetGrayval(this._latestImage, row, column, out pixelValue);
							int channels = (channelCount.Length > 0) ? channelCount[0].I : 1;
							bool flag4 = channels >= 3 && pixelValue.Length >= 3;
							if (flag4)
							{
								double blue = pixelValue[0].D;
								double green = pixelValue[1].D;
								double red = pixelValue[2].D;
								double gray = 0.299 * red + 0.587 * green + 0.114 * blue;
								result = string.Format("X: {0}, Y: {1}, Gray: {2:0.##}, B: {3:0.##}, G: {4:0.##}, R: {5:0.##}, Size: {6} x {7}, FPS: {8:0.0}", new object[]
								{
									column,
									row,
									gray,
									blue,
									green,
									red,
									this._imageWidth,
									this._imageHeight,
									this._fps
								});
							}
							else
							{
								double mono = (pixelValue.Length > 0) ? pixelValue[0].D : 0.0;
								result = string.Format("X: {0}, Y: {1}, Gray: {2:0.##}, Size: {3} x {4}, FPS: {5:0.0}", new object[]
								{
									column,
									row,
									mono,
									this._imageWidth,
									this._imageHeight,
									this._fps
								});
							}
						}
						catch
						{
							result = string.Format("X: {0}, Y: {1}, Gray: -, Size: {2} x {3}, FPS: {4:0.0}", new object[]
							{
								column,
								row,
								this._imageWidth,
								this._imageHeight,
								this._fps
							});
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06002129 RID: 8489 RVA: 0x000C3500 File Offset: 0x000C1700
		private bool TryGetImagePoint(Point controlPosition, out int row, out int column)
		{
			row = 0;
			column = 0;
			bool flag = this._display == null || this._display.ActualWidth <= 0.0 || this._display.ActualHeight <= 0.0;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					HWindow window = this._display.HalconWindow;
					HTuple row2;
					HTuple col;
					HTuple row3;
					HTuple col2;
					window.GetPart(out row2, out col, out row3, out col2);
					double imageRow = row2.D + controlPosition.Y * (row3.D - row2.D + 1.0) / this._display.ActualHeight;
					double imageColumn = col.D + controlPosition.X * (col2.D - col.D + 1.0) / this._display.ActualWidth;
					row = (int)Math.Round(imageRow);
					column = (int)Math.Round(imageColumn);
					result = true;
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x0600212A RID: 8490 RVA: 0x000C3614 File Offset: 0x000C1814
		private static string ResolveImageFormat(string savePath)
		{
			string extension = Path.GetExtension(savePath).ToLowerInvariant();
			string text = extension;
			string a = text;
			string result;
			if (!(a == ".jpg") && !(a == ".jpeg"))
			{
				if (!(a == ".png"))
				{
					if (!(a == ".tif") && !(a == ".tiff"))
					{
						if (!(a == ".bmp"))
						{
						}
						result = "bmp";
					}
					else
					{
						result = "tiff";
					}
				}
				else
				{
					result = "png";
				}
			}
			else
			{
				result = "jpeg";
			}
			return result;
		}

		// Token: 0x04000DAB RID: 3499
		private readonly HSmartWindowControlWPF _display;

		// Token: 0x04000DAC RID: 3500
		private bool _hasUserView;

		// Token: 0x04000DAD RID: 3501
		private bool _fitRequested = true;

		// Token: 0x04000DAE RID: 3502
		private bool _isPanning;

		// Token: 0x04000DAF RID: 3503
		private Point _lastMousePosition;

		// Token: 0x04000DB0 RID: 3504
		private int _imageWidth;

		// Token: 0x04000DB1 RID: 3505
		private int _imageHeight;

		// Token: 0x04000DB2 RID: 3506
		private HObject _latestImage;

		// Token: 0x04000DB3 RID: 3507
		private readonly Stopwatch _latestImageStopwatch = Stopwatch.StartNew();

		// Token: 0x04000DB4 RID: 3508
		private readonly Stopwatch _pixelInfoStopwatch = Stopwatch.StartNew();

		// Token: 0x04000DB5 RID: 3509
		private readonly Stopwatch _fpsStopwatch = Stopwatch.StartNew();

		// Token: 0x04000DB6 RID: 3510
		private int _framesSinceFpsUpdate;

		// Token: 0x04000DB7 RID: 3511
		private double _fps;

		// Token: 0x04000DB8 RID: 3512
		private Point _lastInspectorPosition;

		// Token: 0x04000DB9 RID: 3513
		private bool _hasInspectorPosition;
	}
}
