﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using VisionMachine.Helpers;
using VisionMachine.Models.Camera;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Runtime;
using VisionMachine.ViewModels.Main;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200024C RID: 588
	public static class CameraModelConfigStorageService
	{
		// Token: 0x06002167 RID: 8551 RVA: 0x000C4704 File Offset: 0x000C2904
		public static string GetCurrentModelCameraConfigPath()
		{
			bool flag = ModelRuntimeStore.CurrentModel == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string modelName = RecipePathService.MakeSafeFileName(ModelRuntimeStore.CurrentModel.Model_name);
				string folder = Path.Combine(Manager_path._dataPath, modelName);
				bool flag2 = string.IsNullOrWhiteSpace(folder);
				if (flag2)
				{
					result = null;
				}
				else
				{
					Directory.CreateDirectory(folder);
					result = Path.Combine(folder, "camera_config.json");
				}
			}
			return result;
		}

		// Token: 0x06002168 RID: 8552 RVA: 0x000C4764 File Offset: 0x000C2964
		public static void SaveCurrentModelConfig(MainViewModel viewModel)
		{
			bool flag = viewModel == null || ModelRuntimeStore.CurrentModel == null;
			if (!flag)
			{
				string path = CameraModelConfigStorageService.GetCurrentModelCameraConfigPath();
				bool flag2 = string.IsNullOrWhiteSpace(path);
				if (!flag2)
				{
					string folder = Path.GetDirectoryName(path);
					bool flag3 = !string.IsNullOrWhiteSpace(folder) && !Directory.Exists(folder);
					if (flag3)
					{
						Directory.CreateDirectory(folder);
					}
					CameraModelConfigData data = new CameraModelConfigData
					{
						ModelName = ModelRuntimeStore.CurrentModel.Model_name
					};
					foreach (CameraNode camera in viewModel.Cameras)
					{
						List<CameraModelConfigItem> cameras = data.Cameras;
						CameraModelConfigItem cameraModelConfigItem = new CameraModelConfigItem();
						cameraModelConfigItem.CameraIndex = camera.Index;
						CameraItem cameraInfo = camera.CameraInfo;
						cameraModelConfigItem.CameraName = ((cameraInfo != null) ? cameraInfo.CameraName : null);
						cameraModelConfigItem.Parameter = (camera.CameraConfig ?? new CameraParameterConfig());
						cameras.Add(cameraModelConfigItem);
					}
					string json = JsonConvert.SerializeObject(data, Formatting.Indented);
					File.WriteAllText(path, json);
				}
			}
		}

		// Token: 0x06002169 RID: 8553 RVA: 0x000C4888 File Offset: 0x000C2A88
		public static void LoadCurrentModelConfig(MainViewModel viewModel)
		{
			bool flag = viewModel == null;
			if (!flag)
			{
				string path = CameraModelConfigStorageService.GetCurrentModelCameraConfigPath();
				bool flag2 = string.IsNullOrWhiteSpace(path) || !File.Exists(path);
				if (flag2)
				{
					CameraModelConfigStorageService.EnsureDefaultConfigs(viewModel);
				}
				else
				{
					string json = File.ReadAllText(path);
					bool flag3 = string.IsNullOrWhiteSpace(json);
					if (flag3)
					{
						CameraModelConfigStorageService.EnsureDefaultConfigs(viewModel);
					}
					else
					{
						CameraModelConfigData data = JsonConvert.DeserializeObject<CameraModelConfigData>(json);
						bool flag4 = data == null || data.Cameras == null;
						if (flag4)
						{
							CameraModelConfigStorageService.EnsureDefaultConfigs(viewModel);
						}
						else
						{
							using (IEnumerator<CameraNode> enumerator = viewModel.Cameras.GetEnumerator())
							{
								while (enumerator.MoveNext())
								{
									CameraNode camera = enumerator.Current;
									CameraModelConfigItem saved = data.Cameras.FirstOrDefault(delegate(CameraModelConfigItem x)
									{
										string cameraName = x.CameraName;
										CameraItem cameraInfo = camera.CameraInfo;
										return cameraName == ((cameraInfo != null) ? cameraInfo.CameraName : null);
									});
									bool flag5 = saved == null;
									if (flag5)
									{
										saved = data.Cameras.FirstOrDefault((CameraModelConfigItem x) => x.CameraIndex == camera.Index);
									}
									camera.CameraConfig = (((saved != null) ? saved.Parameter : null) ?? new CameraParameterConfig());
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x0600216A RID: 8554 RVA: 0x000C49D0 File Offset: 0x000C2BD0
		private static void EnsureDefaultConfigs(MainViewModel viewModel)
		{
			foreach (CameraNode camera in viewModel.Cameras)
			{
				bool flag = camera.CameraConfig == null;
				if (flag)
				{
					camera.CameraConfig = new CameraParameterConfig();
				}
			}
		}
	}
}
