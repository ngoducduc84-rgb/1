﻿using System;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000239 RID: 569
	public sealed class CameraParameterRange
	{
		// Token: 0x170009A7 RID: 2471
		// (get) Token: 0x0600204B RID: 8267 RVA: 0x000BC0EB File Offset: 0x000BA2EB
		// (set) Token: 0x0600204C RID: 8268 RVA: 0x000BC0F3 File Offset: 0x000BA2F3
		public double Min { get; set; }

		// Token: 0x170009A8 RID: 2472
		// (get) Token: 0x0600204D RID: 8269 RVA: 0x000BC0FC File Offset: 0x000BA2FC
		// (set) Token: 0x0600204E RID: 8270 RVA: 0x000BC104 File Offset: 0x000BA304
		public double Max { get; set; }

		// Token: 0x170009A9 RID: 2473
		// (get) Token: 0x0600204F RID: 8271 RVA: 0x000BC10D File Offset: 0x000BA30D
		// (set) Token: 0x06002050 RID: 8272 RVA: 0x000BC115 File Offset: 0x000BA315
		public bool IsInteger { get; set; }
	}
}
