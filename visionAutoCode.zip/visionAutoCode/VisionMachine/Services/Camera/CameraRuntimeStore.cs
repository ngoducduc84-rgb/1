﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200024D RID: 589
	public static class CameraRuntimeStore
	{
		// Token: 0x14000035 RID: 53
		// (add) Token: 0x0600216B RID: 8555 RVA: 0x000C4A34 File Offset: 0x000C2C34
		// (remove) Token: 0x0600216C RID: 8556 RVA: 0x000C4A68 File Offset: 0x000C2C68
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler CamerasChanged;

		// Token: 0x170009BE RID: 2494
		// (get) Token: 0x0600216D RID: 8557 RVA: 0x000C4A9B File Offset: 0x000C2C9B
		public static ObservableCollection<CameraItem> Cameras { get; } = new ObservableCollection<CameraItem>();

		// Token: 0x170009BF RID: 2495
		// (get) Token: 0x0600216E RID: 8558 RVA: 0x000C4AA2 File Offset: 0x000C2CA2
		// (set) Token: 0x0600216F RID: 8559 RVA: 0x000C4AA9 File Offset: 0x000C2CA9
		public static int Count_per_row { get; private set; } = 1;

		// Token: 0x06002170 RID: 8560 RVA: 0x000C4AB4 File Offset: 0x000C2CB4
		public static void SetList(IEnumerable<CameraItem> cameras)
		{
			CameraRuntimeStore.Cameras.Clear();
			foreach (CameraItem camera in (cameras ?? Enumerable.Empty<CameraItem>()))
			{
				CameraRuntimeStore.Cameras.Add(camera);
			}
			EventHandler camerasChanged = CameraRuntimeStore.CamerasChanged;
			if (camerasChanged != null)
			{
				camerasChanged(null, EventArgs.Empty);
			}
		}

		// Token: 0x06002171 RID: 8561 RVA: 0x000C4B30 File Offset: 0x000C2D30
		public static void SetData(IEnumerable<CameraItem> cameras, int countPerRow)
		{
			CameraRuntimeStore.SetList(cameras);
			CameraRuntimeStore.Count_per_row = ((countPerRow > 0) ? countPerRow : 1);
		}

		// Token: 0x06002172 RID: 8562 RVA: 0x000C4B48 File Offset: 0x000C2D48
		public static CameraItem GetByName(string cameraName)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraName);
			CameraItem result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = CameraRuntimeStore.Cameras.FirstOrDefault((CameraItem x) => x.CameraName == cameraName);
			}
			return result;
		}

		// Token: 0x06002173 RID: 8563 RVA: 0x000C4B90 File Offset: 0x000C2D90
		public static void Clear()
		{
			CameraRuntimeStore.Cameras.Clear();
			CameraRuntimeStore.Count_per_row = 1;
			EventHandler camerasChanged = CameraRuntimeStore.CamerasChanged;
			if (camerasChanged != null)
			{
				camerasChanged(null, EventArgs.Empty);
			}
		}

		// Token: 0x06002174 RID: 8564 RVA: 0x000C4BBC File Offset: 0x000C2DBC
		public static void SetCountPerRow(int countPerRow)
		{
			bool flag = countPerRow <= 0;
			if (flag)
			{
				countPerRow = 1;
			}
			CameraRuntimeStore.Count_per_row = countPerRow;
		}
	}
}
