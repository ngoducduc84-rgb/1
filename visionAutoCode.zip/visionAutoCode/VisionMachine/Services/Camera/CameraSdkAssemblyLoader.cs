﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200023E RID: 574
	internal static class CameraSdkAssemblyLoader
	{
		// Token: 0x06002089 RID: 8329 RVA: 0x000BDC18 File Offset: 0x000BBE18
		public static Assembly LoadBaslerPylon()
		{
			return CameraSdkAssemblyLoader.TryLoadAssembly("Basler.Pylon", new string[]
			{
				"C:\\Program Files\\Basler\\pylon 6\\Development\\Assemblies\\Basler.Pylon\\x64\\Basler.Pylon.dll",
				"C:\\Program Files\\Basler\\pylon 6\\Development\\Assemblies\\Basler.Pylon\\x86\\Basler.Pylon.dll"
			});
		}

		// Token: 0x0600208A RID: 8330 RVA: 0x000BDC4C File Offset: 0x000BBE4C
		public static Assembly LoadHikvisionMvs()
		{
			return CameraSdkAssemblyLoader.TryLoadAssembly("MvCameraControl.Net", new string[]
			{
				"C:\\Program Files (x86)\\MVS\\Development\\DotNet\\AnyCpu\\MvCameraControl.Net.dll",
				"C:\\Program Files (x86)\\MVS\\Development\\DotNet\\win64\\MvCameraControl.Net.dll",
				"C:\\Program Files (x86)\\MVS\\Development\\DotNet\\win32\\MvCameraControl.Net.dll"
			});
		}

		// Token: 0x0600208B RID: 8331 RVA: 0x000BDC88 File Offset: 0x000BBE88
		private static Assembly TryLoadAssembly(string assemblyName, IEnumerable<string> probePaths)
		{
			try
			{
				Assembly loaded = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault((Assembly x) => x.GetName().Name == assemblyName);
				bool flag = loaded != null;
				if (flag)
				{
					return loaded;
				}
			}
			catch
			{
			}
			foreach (string path in (probePaths ?? Enumerable.Empty<string>()))
			{
				try
				{
					bool flag2 = File.Exists(path);
					if (flag2)
					{
						return Assembly.LoadFrom(path);
					}
				}
				catch
				{
				}
			}
			Assembly result;
			try
			{
				result = Assembly.Load(assemblyName);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x04000D8A RID: 3466
		public static readonly object MvsEnumerationLock = new object();
	}
}
