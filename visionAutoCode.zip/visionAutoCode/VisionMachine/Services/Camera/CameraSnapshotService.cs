﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using Basler.Pylon;
using HalconDotNet;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000242 RID: 578
	internal static class CameraSnapshotService
	{
		// Token: 0x060020F3 RID: 8435 RVA: 0x000C16F0 File Offset: 0x000BF8F0
		public static HObject Capture(CameraParameterConfig config)
		{
			bool flag = config == null;
			if (flag)
			{
				throw new ArgumentNullException("config");
			}
			bool flag2 = string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			if (flag2)
			{
				throw new InvalidOperationException("No serial camera is selected.");
			}
			bool flag3 = config.Vendor == CameraVendor.Hikvision;
			HObject result;
			if (flag3)
			{
				result = HikLiveCameraService.CaptureSnapshot(config);
			}
			else
			{
				bool flag4 = config.Vendor != CameraVendor.Basler;
				if (flag4)
				{
					throw new NotSupportedException("Camera snapshot is supported for Basler and Hikvision cameras only.");
				}
				result = CameraSnapshotService.CaptureBaslerCached(config);
			}
			return result;
		}

		// Token: 0x060020F4 RID: 8436 RVA: 0x000C1768 File Offset: 0x000BF968
		public static void Warmup(CameraParameterConfig config)
		{
			bool flag = config == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			if (!flag)
			{
				bool flag2 = config.Vendor == CameraVendor.Hikvision;
				if (flag2)
				{
					HikLiveCameraService.WarmupSnapshot(config);
				}
				else
				{
					bool flag3 = config.Vendor != CameraVendor.Basler;
					if (!flag3)
					{
						object baslerSessionsLock = CameraSnapshotService.BaslerSessionsLock;
						CameraSnapshotService.BaslerSnapshotSession session;
						lock (baslerSessionsLock)
						{
							bool flag5 = !CameraSnapshotService.BaslerSessions.TryGetValue(config.ConnectedCameraId, out session);
							if (flag5)
							{
								session = new CameraSnapshotService.BaslerSnapshotSession(config.ConnectedCameraId);
								CameraSnapshotService.BaslerSessions[config.ConnectedCameraId] = session;
							}
						}
						try
						{
							session.Warmup(config);
						}
						catch
						{
							CameraSnapshotService.Release(config.ConnectedCameraId);
							throw;
						}
					}
				}
			}
		}

		// Token: 0x060020F5 RID: 8437 RVA: 0x000C1858 File Offset: 0x000BFA58
		public static void Release(string cameraId)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraId);
			if (!flag)
			{
				object baslerSessionsLock = CameraSnapshotService.BaslerSessionsLock;
				lock (baslerSessionsLock)
				{
					CameraSnapshotService.BaslerSnapshotSession session;
					bool flag3 = !CameraSnapshotService.BaslerSessions.TryGetValue(cameraId, out session);
					if (flag3)
					{
						session = null;
					}
					else
					{
						CameraSnapshotService.BaslerSessions.Remove(cameraId);
					}
					if (session != null)
					{
						session.Dispose();
					}
				}
				HikLiveCameraService.ReleaseSnapshot(cameraId);
			}
		}

		// Token: 0x060020F6 RID: 8438 RVA: 0x000C18DC File Offset: 0x000BFADC
		private static HObject CaptureBaslerCached(CameraParameterConfig config)
		{
			object baslerSessionsLock = CameraSnapshotService.BaslerSessionsLock;
			CameraSnapshotService.BaslerSnapshotSession session;
			lock (baslerSessionsLock)
			{
				bool flag2 = !CameraSnapshotService.BaslerSessions.TryGetValue(config.ConnectedCameraId, out session);
				if (flag2)
				{
					session = new CameraSnapshotService.BaslerSnapshotSession(config.ConnectedCameraId);
					CameraSnapshotService.BaslerSessions[config.ConnectedCameraId] = session;
				}
			}
			HObject result;
			try
			{
				result = session.Capture(config);
			}
			catch
			{
				CameraSnapshotService.Release(config.ConnectedCameraId);
				throw;
			}
			return result;
		}

		// Token: 0x060020F7 RID: 8439 RVA: 0x000C1980 File Offset: 0x000BFB80
		private static void ApplyParameter(Camera camera, CameraParameterConfig config)
		{
			CameraSnapshotService.TrySetDoubleParameter(camera, "ExposureTime", config.ExposureTime);
			CameraSnapshotService.TrySetDoubleParameter(camera, "ExposureTimeAbs", config.ExposureTime);
			CameraSnapshotService.TrySetDoubleParameter(camera, "Gain", config.Gain);
			CameraSnapshotService.TrySetDoubleParameter(camera, "GainRaw", config.Gain);
			CameraSnapshotService.TrySetStringParameter(camera, "PixelFormat", config.PixelFormat);
			CameraSnapshotService.TrySetStringParameter(camera, "TriggerSelector", "FrameStart");
			bool hardwareTrigger = config.HardwareTrigger;
			if (hardwareTrigger)
			{
				CameraSnapshotService.TrySetStringParameter(camera, "TriggerSource", "Line1");
				CameraSnapshotService.TrySetStringParameter(camera, "TriggerActivation", "RisingEdge");
			}
			CameraSnapshotService.TrySetStringParameter(camera, "TriggerMode", config.HardwareTrigger ? "On" : "Off");
			CameraSnapshotService.TrySetStringParameter(camera, "BslLightSourcePreset", config.LightSourcePreset);
		}

		// Token: 0x060020F8 RID: 8440 RVA: 0x000C1A5C File Offset: 0x000BFC5C
		private static HObject ConvertToHalconImage(PixelDataConverter converter, IGrabResult grabResult, string pixelFormat)
		{
			int width = grabResult.Width;
			int height = grabResult.Height;
			bool isColor = CameraSnapshotService.IsColorPixelFormat(pixelFormat);
			converter.OutputPixelFormat = (isColor ? PixelType.BGR8packed : PixelType.Mono8);
			byte[] buffer = isColor ? new byte[width * height * 3] : new byte[width * height];
			converter.Convert<byte>(buffer, grabResult);
			GCHandle handle = GCHandle.Alloc(buffer, GCHandleType.Pinned);
			HObject result;
			try
			{
				bool flag = isColor;
				HObject image;
				if (flag)
				{
					HOperatorSet.GenImageInterleaved(out image, handle.AddrOfPinnedObject(), "bgr", width, height, 0, "byte", width, height, 0, 0, -1, 0);
				}
				else
				{
					HOperatorSet.GenImage1(out image, "byte", width, height, handle.AddrOfPinnedObject());
				}
				result = image;
			}
			finally
			{
				handle.Free();
			}
			return result;
		}

		// Token: 0x060020F9 RID: 8441 RVA: 0x000C1B78 File Offset: 0x000BFD78
		private static bool IsColorPixelFormat(string pixelFormat)
		{
			bool flag = string.IsNullOrWhiteSpace(pixelFormat);
			return !flag && (pixelFormat.IndexOf("Bayer", StringComparison.OrdinalIgnoreCase) >= 0 || pixelFormat.IndexOf("RGB", StringComparison.OrdinalIgnoreCase) >= 0 || pixelFormat.IndexOf("BGR", StringComparison.OrdinalIgnoreCase) >= 0);
		}

		// Token: 0x060020FA RID: 8442 RVA: 0x000C1BCC File Offset: 0x000BFDCC
		private static bool TrySetDoubleParameter(Camera camera, string name, double value)
		{
			bool result;
			try
			{
				result = CameraSnapshotService.TryInvokeSetValue(camera.Parameters[name], value);
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060020FB RID: 8443 RVA: 0x000C1C0C File Offset: 0x000BFE0C
		private static bool TrySetStringParameter(Camera camera, string name, string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					result = CameraSnapshotService.TryInvokeSetValue(camera.Parameters[name], value);
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x060020FC RID: 8444 RVA: 0x000C1C58 File Offset: 0x000BFE58
		private static bool TryInvokeSetValue(object parameter, object value)
		{
			bool flag = parameter == null || value == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				MethodInfo method = parameter.GetType().GetMethods().FirstOrDefault((MethodInfo x) => x.Name == "SetValue" && x.GetParameters().Length >= 1 && CameraSnapshotService.CanUseParameterType(x.GetParameters()[0].ParameterType, value));
				bool flag2 = method == null;
				if (flag2)
				{
					result = false;
				}
				else
				{
					try
					{
						object convertedValue = CameraSnapshotService.ConvertValue(value, method.GetParameters()[0].ParameterType);
						method.Invoke(parameter, new object[]
						{
							convertedValue
						});
						result = true;
					}
					catch
					{
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x060020FD RID: 8445 RVA: 0x000C1D04 File Offset: 0x000BFF04
		private static bool CanUseParameterType(Type parameterType, object value)
		{
			bool flag = parameterType == null || value == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = parameterType.IsInstanceOfType(value);
				if (flag2)
				{
					result = true;
				}
				else
				{
					bool flag3 = value is double;
					if (flag3)
					{
						result = (parameterType == typeof(double) || parameterType == typeof(float) || parameterType == typeof(int) || parameterType == typeof(long));
					}
					else
					{
						result = (value is string && parameterType == typeof(string));
					}
				}
			}
			return result;
		}

		// Token: 0x060020FE RID: 8446 RVA: 0x000C1DB8 File Offset: 0x000BFFB8
		private static object ConvertValue(object value, Type targetType)
		{
			bool flag = targetType.IsInstanceOfType(value);
			object result;
			if (flag)
			{
				result = value;
			}
			else
			{
				result = Convert.ChangeType(value, targetType);
			}
			return result;
		}

		// Token: 0x04000DA5 RID: 3493
		private static readonly object BaslerSessionsLock = new object();

		// Token: 0x04000DA6 RID: 3494
		private static readonly Dictionary<string, CameraSnapshotService.BaslerSnapshotSession> BaslerSessions = new Dictionary<string, CameraSnapshotService.BaslerSnapshotSession>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x020004A3 RID: 1187
		private sealed class BaslerSnapshotSession : IDisposable
		{
			// Token: 0x06002CFA RID: 11514 RVA: 0x000EC748 File Offset: 0x000EA948
			public BaslerSnapshotSession(string cameraId)
			{
				this._cameraId = cameraId;
			}

			// Token: 0x06002CFB RID: 11515 RVA: 0x000EC770 File Offset: 0x000EA970
			public HObject Capture(CameraParameterConfig config)
			{
				object @lock = this._lock;
				HObject result;
				lock (@lock)
				{
					this.EnsureOpen(config);
					CameraSnapshotService.ApplyParameter(this._camera, config);
					using (IGrabResult grabResult = this._camera.StreamGrabber.RetrieveResult(1000, TimeoutHandling.ThrowException))
					{
						bool flag2 = grabResult == null || !grabResult.GrabSucceeded || grabResult.Width <= 0 || grabResult.Height <= 0;
						if (flag2)
						{
							throw new InvalidOperationException("Failed to grab image from camera.");
						}
						HObject image = CameraSnapshotService.ConvertToHalconImage(this._converter, grabResult, config.PixelFormat);
						HObject transformed = CameraImageTransformService.Apply(image, config);
						bool flag3 = transformed != image;
						if (flag3)
						{
							image.Dispose();
						}
						result = transformed;
					}
				}
				return result;
			}

			// Token: 0x06002CFC RID: 11516 RVA: 0x000EC860 File Offset: 0x000EAA60
			public void Warmup(CameraParameterConfig config)
			{
				object @lock = this._lock;
				lock (@lock)
				{
					this.EnsureOpen(config);
				}
			}

			// Token: 0x06002CFD RID: 11517 RVA: 0x000EC8A8 File Offset: 0x000EAAA8
			public void Dispose()
			{
				object @lock = this._lock;
				lock (@lock)
				{
					this.DisposeCamera();
				}
			}

			// Token: 0x06002CFE RID: 11518 RVA: 0x000EC8EC File Offset: 0x000EAAEC
			private void EnsureOpen(CameraParameterConfig config)
			{
				bool flag = this._camera != null && this._camera.IsOpen && this._camera.IsConnected && this._camera.StreamGrabber.IsGrabbing;
				if (!flag)
				{
					this.DisposeCamera();
					this._camera = new Camera(this._cameraId);
					this._camera.Open();
					CameraSnapshotService.ApplyParameter(this._camera, config);
					this._camera.StreamGrabber.Start(GrabStrategy.LatestImages, GrabLoop.ProvidedByUser);
				}
			}

			// Token: 0x06002CFF RID: 11519 RVA: 0x000EC97C File Offset: 0x000EAB7C
			private void DisposeCamera()
			{
				try
				{
					Camera camera = this._camera;
					bool flag;
					if (camera == null)
					{
						flag = false;
					}
					else
					{
						IStreamGrabber streamGrabber = camera.StreamGrabber;
						flag = ((streamGrabber != null) ? new bool?(streamGrabber.IsGrabbing) : null).GetValueOrDefault();
					}
					bool flag2 = flag;
					if (flag2)
					{
						this._camera.StreamGrabber.Stop();
					}
				}
				catch
				{
				}
				try
				{
					Camera camera2 = this._camera;
					if (camera2 != null)
					{
						camera2.Close();
					}
				}
				catch
				{
				}
				try
				{
					Camera camera3 = this._camera;
					if (camera3 != null)
					{
						camera3.Dispose();
					}
				}
				catch
				{
				}
				this._camera = null;
			}

			// Token: 0x0400167A RID: 5754
			private readonly object _lock = new object();

			// Token: 0x0400167B RID: 5755
			private readonly string _cameraId;

			// Token: 0x0400167C RID: 5756
			private readonly PixelDataConverter _converter = new PixelDataConverter();

			// Token: 0x0400167D RID: 5757
			private Camera _camera;
		}
	}
}
