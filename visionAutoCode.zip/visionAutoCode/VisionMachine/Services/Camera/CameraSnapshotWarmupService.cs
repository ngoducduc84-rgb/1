﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000244 RID: 580
	public static class CameraSnapshotWarmupService
	{
		// Token: 0x06002108 RID: 8456 RVA: 0x000C1E4C File Offset: 0x000C004C
		public static CameraWarmupResult WarmupCameras(IEnumerable<CameraNode> cameras, ISet<string> availableCameraIds = null)
		{
			CameraWarmupResult result = new CameraWarmupResult();
			Stopwatch stopwatch = Stopwatch.StartNew();
			bool flag = cameras == null;
			CameraWarmupResult result2;
			if (flag)
			{
				stopwatch.Stop();
				result2 = result;
			}
			else
			{
				HashSet<string> done = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
				foreach (CameraNode camera in cameras)
				{
					CameraParameterConfig config = (camera != null) ? camera.CameraConfig : null;
					string serial = (config != null) ? config.ConnectedCameraId : null;
					bool flag2 = string.IsNullOrWhiteSpace(serial);
					if (flag2)
					{
						CameraWarmupResult cameraWarmupResult = result;
						int num = cameraWarmupResult.SkippedCount;
						cameraWarmupResult.SkippedCount = num + 1;
					}
					else
					{
						bool flag3 = availableCameraIds != null && !availableCameraIds.Contains(serial);
						if (flag3)
						{
							CameraWarmupResult cameraWarmupResult2 = result;
							int num = cameraWarmupResult2.SkippedCount;
							cameraWarmupResult2.SkippedCount = num + 1;
						}
						else
						{
							bool flag4 = !done.Add(serial);
							if (!flag4)
							{
								bool flag5 = CameraHardwareRuntimeService.IsRegistered(serial);
								if (flag5)
								{
									CameraWarmupResult cameraWarmupResult3 = result;
									int num = cameraWarmupResult3.SkippedCount;
									cameraWarmupResult3.SkippedCount = num + 1;
								}
								else
								{
									try
									{
										CameraSnapshotService.Warmup(config);
										CameraWarmupResult cameraWarmupResult4 = result;
										int num = cameraWarmupResult4.WarmedCount;
										cameraWarmupResult4.WarmedCount = num + 1;
									}
									catch (Exception ex)
									{
										result.Errors.Add("Camera '" + (camera.Name ?? serial) + "' could not be prepared: " + ex.Message);
									}
								}
							}
						}
					}
				}
				stopwatch.Stop();
				result.ElapsedMs = stopwatch.Elapsed.TotalMilliseconds;
				result2 = result;
			}
			return result2;
		}
	}
}
