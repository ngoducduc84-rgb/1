﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using VisionMachine.Models.Camera;
using VisionMachine.Services.Runtime;
using VisionMachine.ViewModels.Main;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000241 RID: 577
	public static class CameraStartupApplyService
	{
		// Token: 0x060020EF RID: 8431 RVA: 0x000C1390 File Offset: 0x000BF590
		public static void ApplyCurrentModelAsync(MainViewModel viewModel, string reason, int delayMs = 800)
		{
			CameraStartupApplyService.<>c__DisplayClass2_0 CS$<>8__locals1 = new CameraStartupApplyService.<>c__DisplayClass2_0();
			CS$<>8__locals1.delayMs = delayMs;
			CS$<>8__locals1.reason = reason;
			CS$<>8__locals1.configs = CameraStartupApplyService.SnapshotConfigs(viewModel);
			bool flag = CS$<>8__locals1.configs.Count == 0;
			if (flag)
			{
				VisionLogService.Log("Info", "Camera config apply skipped: no camera has a device assigned.");
			}
			else
			{
				object syncRoot = CameraStartupApplyService.SyncRoot;
				lock (syncRoot)
				{
					CameraStartupApplyService._requestId++;
					CS$<>8__locals1.requestId = CameraStartupApplyService._requestId;
				}
				Task.Run(delegate()
				{
					CameraStartupApplyService.<>c__DisplayClass2_0.<<ApplyCurrentModelAsync>b__0>d <<ApplyCurrentModelAsync>b__0>d = new CameraStartupApplyService.<>c__DisplayClass2_0.<<ApplyCurrentModelAsync>b__0>d();
					<<ApplyCurrentModelAsync>b__0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
					<<ApplyCurrentModelAsync>b__0>d.<>4__this = CS$<>8__locals1;
					<<ApplyCurrentModelAsync>b__0>d.<>1__state = -1;
					<<ApplyCurrentModelAsync>b__0>d.<>t__builder.Start<CameraStartupApplyService.<>c__DisplayClass2_0.<<ApplyCurrentModelAsync>b__0>d>(ref <<ApplyCurrentModelAsync>b__0>d);
					return <<ApplyCurrentModelAsync>b__0>d.<>t__builder.Task;
				});
			}
		}

		// Token: 0x060020F0 RID: 8432 RVA: 0x000C143C File Offset: 0x000BF63C
		private static void Apply(List<CameraParameterConfig> configs, string reason)
		{
			List<string> applied = new List<string>();
			int idle = 0;
			foreach (CameraParameterConfig config in configs)
			{
				bool flag = config == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
				if (!flag)
				{
					bool flag2 = !CameraHardwareRuntimeService.IsRegistered(config.ConnectedCameraId);
					if (flag2)
					{
						idle++;
					}
					else
					{
						try
						{
							CameraHardwareRuntimeService.ApplyParameter(config);
							applied.Add(string.Concat(new string[]
							{
								config.ConnectedCameraId,
								" exp=",
								config.ExposureTime.ToString("0.##"),
								" gain=",
								config.Gain.ToString("0.##")
							}));
						}
						catch (Exception ex)
						{
							string level = "Warn";
							string str = "Camera config apply failed for ";
							string connectedCameraId = config.ConnectedCameraId;
							string str2 = ": ";
							Exception baseException = ex.GetBaseException();
							VisionLogService.Log(level, str + connectedCameraId + str2 + (((baseException != null) ? baseException.Message : null) ?? ex.Message));
						}
					}
				}
			}
			VisionLogService.Log("Info", string.Concat(new string[]
			{
				"Camera config applied from model. Reason=",
				string.IsNullOrWhiteSpace(reason) ? "Load" : reason,
				", Applied=",
				applied.Count.ToString(),
				(applied.Count > 0) ? (" [" + string.Join("; ", applied.Take(4)) + "]") : string.Empty,
				(idle > 0) ? (", " + idle.ToString() + " camera(s) not streaming - applied on their next snap") : string.Empty
			}));
		}

		// Token: 0x060020F1 RID: 8433 RVA: 0x000C1640 File Offset: 0x000BF840
		private static List<CameraParameterConfig> SnapshotConfigs(MainViewModel viewModel)
		{
			List<CameraParameterConfig> result = new List<CameraParameterConfig>();
			bool flag = ((viewModel != null) ? viewModel.Cameras : null) == null;
			List<CameraParameterConfig> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (CameraNode camera in viewModel.Cameras)
				{
					CameraParameterConfig config = (camera != null) ? camera.CameraConfig : null;
					bool flag2 = config != null && !string.IsNullOrWhiteSpace(config.ConnectedCameraId);
					if (flag2)
					{
						result.Add(config);
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x04000DA3 RID: 3491
		private static readonly object SyncRoot = new object();

		// Token: 0x04000DA4 RID: 3492
		private static int _requestId;
	}
}
