﻿using System;
using System.Collections.Generic;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200024E RID: 590
	public class CameraStorageData
	{
		// Token: 0x170009C0 RID: 2496
		// (get) Token: 0x06002176 RID: 8566 RVA: 0x000C4BF1 File Offset: 0x000C2DF1
		// (set) Token: 0x06002177 RID: 8567 RVA: 0x000C4BF9 File Offset: 0x000C2DF9
		public List<CameraItem> Cameras { get; set; } = new List<CameraItem>();

		// Token: 0x170009C1 RID: 2497
		// (get) Token: 0x06002178 RID: 8568 RVA: 0x000C4C02 File Offset: 0x000C2E02
		// (set) Token: 0x06002179 RID: 8569 RVA: 0x000C4C0A File Offset: 0x000C2E0A
		public int Count_per_row { get; set; } = 1;
	}
}
