﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200024F RID: 591
	public static class CameraStorageService
	{
		// Token: 0x0600217B RID: 8571 RVA: 0x000C4C30 File Offset: 0x000C2E30
		public static void Save(string filePath, IEnumerable<CameraItem> cameras, int countPerRow)
		{
			bool flag = string.IsNullOrWhiteSpace(filePath);
			if (flag)
			{
				throw new ArgumentException("filePath is null or empty.", "filePath");
			}
			string folder = Path.GetDirectoryName(filePath);
			bool flag2 = !string.IsNullOrWhiteSpace(folder) && !Directory.Exists(folder);
			if (flag2)
			{
				Directory.CreateDirectory(folder);
			}
			CameraStorageData data = new CameraStorageData
			{
				Cameras = (((cameras != null) ? cameras.ToList<CameraItem>() : null) ?? new List<CameraItem>()),
				Count_per_row = ((countPerRow > 0) ? countPerRow : 1)
			};
			string json = JsonConvert.SerializeObject(data, Formatting.Indented);
			File.WriteAllText(filePath, json);
			CameraRuntimeStore.SetData(data.Cameras, data.Count_per_row);
		}

		// Token: 0x0600217C RID: 8572 RVA: 0x000C4CD4 File Offset: 0x000C2ED4
		public static CameraStorageData Load(string filePath)
		{
			bool flag = string.IsNullOrWhiteSpace(filePath);
			if (flag)
			{
				throw new ArgumentException("filePath is null or empty.", "filePath");
			}
			bool flag2 = !File.Exists(filePath);
			CameraStorageData result;
			if (flag2)
			{
				CameraStorageData emptyData = new CameraStorageData();
				CameraRuntimeStore.SetData(emptyData.Cameras, emptyData.Count_per_row);
				result = emptyData;
			}
			else
			{
				string json = File.ReadAllText(filePath);
				bool flag3 = string.IsNullOrWhiteSpace(json);
				if (flag3)
				{
					CameraStorageData emptyData2 = new CameraStorageData();
					CameraRuntimeStore.SetData(emptyData2.Cameras, emptyData2.Count_per_row);
					result = emptyData2;
				}
				else
				{
					CameraStorageData data = JsonConvert.DeserializeObject<CameraStorageData>(json) ?? new CameraStorageData();
					bool flag4 = data.Cameras == null;
					if (flag4)
					{
						data.Cameras = new List<CameraItem>();
					}
					bool flag5 = data.Count_per_row <= 0;
					if (flag5)
					{
						data.Count_per_row = 1;
					}
					CameraRuntimeStore.SetData(data.Cameras, data.Count_per_row);
					result = data;
				}
			}
			return result;
		}
	}
}
