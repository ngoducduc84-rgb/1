﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000243 RID: 579
	public sealed class CameraWarmupResult
	{
		// Token: 0x170009AD RID: 2477
		// (get) Token: 0x06002100 RID: 8448 RVA: 0x000C1DFB File Offset: 0x000BFFFB
		// (set) Token: 0x06002101 RID: 8449 RVA: 0x000C1E03 File Offset: 0x000C0003
		public int WarmedCount { get; set; }

		// Token: 0x170009AE RID: 2478
		// (get) Token: 0x06002102 RID: 8450 RVA: 0x000C1E0C File Offset: 0x000C000C
		// (set) Token: 0x06002103 RID: 8451 RVA: 0x000C1E14 File Offset: 0x000C0014
		public int SkippedCount { get; set; }

		// Token: 0x170009AF RID: 2479
		// (get) Token: 0x06002104 RID: 8452 RVA: 0x000C1E1D File Offset: 0x000C001D
		// (set) Token: 0x06002105 RID: 8453 RVA: 0x000C1E25 File Offset: 0x000C0025
		public double ElapsedMs { get; set; }

		// Token: 0x170009B0 RID: 2480
		// (get) Token: 0x06002106 RID: 8454 RVA: 0x000C1E2E File Offset: 0x000C002E
		public List<string> Errors { get; } = new List<string>();
	}
}
