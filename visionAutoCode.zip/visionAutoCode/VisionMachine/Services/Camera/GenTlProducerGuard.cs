﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace VisionMachine.Services.Camera
{
	// Token: 0x0200023C RID: 572
	public static class GenTlProducerGuard
	{
		// Token: 0x170009AB RID: 2475
		// (get) Token: 0x0600206A RID: 8298 RVA: 0x000BCF18 File Offset: 0x000BB118
		// (set) Token: 0x0600206B RID: 8299 RVA: 0x000BCF1F File Offset: 0x000BB11F
		public static string LastMessage { get; private set; }

		// Token: 0x0600206C RID: 8300 RVA: 0x000BCF28 File Offset: 0x000BB128
		public static void Apply()
		{
			try
			{
				bool flag = GenTlProducerGuard.IsDisabled();
				if (flag)
				{
					GenTlProducerGuard.LastMessage = "GenTL producer filter disabled by VISIONMACHINE_KEEP_ALL_GENTL.";
				}
				else
				{
					string current = Environment.GetEnvironmentVariable("GENICAM_GENTL64_PATH");
					bool flag2 = string.IsNullOrWhiteSpace(current);
					if (flag2)
					{
						GenTlProducerGuard.LastMessage = "No GenTL producer path is set.";
					}
					else
					{
						List<string> kept = new List<string>();
						List<string> dropped = new List<string>();
						foreach (string folder in current.Split(new char[]
						{
							';'
						}))
						{
							string trimmed = folder.Trim();
							bool flag3 = trimmed.Length == 0;
							if (!flag3)
							{
								bool flag4 = GenTlProducerGuard.ContainsFrameGrabberProducer(trimmed);
								if (flag4)
								{
									dropped.Add(trimmed);
								}
								else
								{
									kept.Add(trimmed);
								}
							}
						}
						bool flag5 = dropped.Count == 0;
						if (flag5)
						{
							GenTlProducerGuard.LastMessage = "No frame-grabber-only GenTL folders to drop.";
						}
						else
						{
							string narrowed = string.Join(";", kept);
							Environment.SetEnvironmentVariable("GENICAM_GENTL64_PATH", narrowed);
							GenTlProducerGuard.LastMessage = string.Concat(new string[]
							{
								"GenTL producer path narrowed for this process (",
								GenTlProducerGuard.PropagateToLoadedCRuntimes(narrowed).ToString(),
								" C runtime(s) updated); dropped ",
								string.Join(", ", dropped),
								"."
							});
						}
					}
				}
			}
			catch (Exception ex)
			{
				GenTlProducerGuard.LastMessage = "GenTL producer path could not be narrowed: " + ex.Message;
			}
		}

		// Token: 0x0600206D RID: 8301
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		private static extern IntPtr GetModuleHandleW(string moduleName);

		// Token: 0x0600206E RID: 8302
		[DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
		private static extern IntPtr GetProcAddress(IntPtr module, string procName);

		// Token: 0x0600206F RID: 8303 RVA: 0x000BD0B0 File Offset: 0x000BB2B0
		private static int PropagateToLoadedCRuntimes(string value)
		{
			int patched = 0;
			try
			{
				foreach (object obj in Process.GetCurrentProcess().Modules)
				{
					ProcessModule module = (ProcessModule)obj;
					string name = module.ModuleName;
					bool flag = !GenTlProducerGuard.IsCRuntimeModule(name);
					if (!flag)
					{
						try
						{
							IntPtr handle = GenTlProducerGuard.GetModuleHandleW(name);
							bool flag2 = handle == IntPtr.Zero;
							if (!flag2)
							{
								IntPtr entry = GenTlProducerGuard.GetProcAddress(handle, "_putenv_s");
								bool flag3 = entry == IntPtr.Zero;
								if (!flag3)
								{
									GenTlProducerGuard.PutEnvironmentVariable setter = (GenTlProducerGuard.PutEnvironmentVariable)Marshal.GetDelegateForFunctionPointer(entry, typeof(GenTlProducerGuard.PutEnvironmentVariable));
									bool flag4 = setter("GENICAM_GENTL64_PATH", value) == 0;
									if (flag4)
									{
										patched++;
									}
								}
							}
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
			return patched;
		}

		// Token: 0x06002070 RID: 8304 RVA: 0x000BD1D0 File Offset: 0x000BB3D0
		private static bool IsCRuntimeModule(string moduleName)
		{
			bool flag = string.IsNullOrWhiteSpace(moduleName);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string name = moduleName.ToLowerInvariant();
				result = (name.StartsWith("ucrtbase", StringComparison.Ordinal) || name.StartsWith("msvcr", StringComparison.Ordinal) || name == "msvcrt.dll");
			}
			return result;
		}

		// Token: 0x06002071 RID: 8305 RVA: 0x000BD224 File Offset: 0x000BB424
		private static bool ContainsFrameGrabberProducer(string folder)
		{
			bool result;
			try
			{
				bool flag = !Directory.Exists(folder);
				if (flag)
				{
					result = false;
				}
				else
				{
					result = Directory.GetFiles(folder, "*.cti").Select(new Func<string, string>(Path.GetFileName)).Any(new Func<string, bool>(GenTlProducerGuard.IsFrameGrabberProducer));
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06002072 RID: 8306 RVA: 0x000BD28C File Offset: 0x000BB48C
		private static bool IsFrameGrabberProducer(string fileName)
		{
			return GenTlProducerGuard.FrameGrabberProducerPrefixes.Any((string prefix) => fileName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));
		}

		// Token: 0x06002073 RID: 8307 RVA: 0x000BD2C4 File Offset: 0x000BB4C4
		private static bool IsDisabled()
		{
			string value = Environment.GetEnvironmentVariable("VISIONMACHINE_KEEP_ALL_GENTL");
			return string.Equals(value, "1", StringComparison.Ordinal) || string.Equals(value, "true", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x04000D84 RID: 3460
		private const string PathVariable = "GENICAM_GENTL64_PATH";

		// Token: 0x04000D85 RID: 3461
		private static readonly string[] FrameGrabberProducerPrefixes = new string[]
		{
			"MvFGProducer"
		};

		// Token: 0x04000D86 RID: 3462
		private const string DisableVariable = "VISIONMACHINE_KEEP_ALL_GENTL";

		// Token: 0x02000492 RID: 1170
		// (Invoke) Token: 0x06002CD1 RID: 11473
		[UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
		private delegate int PutEnvironmentVariable(string name, string value);
	}
}
