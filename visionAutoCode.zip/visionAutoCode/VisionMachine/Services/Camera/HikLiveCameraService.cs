﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;
using HalconDotNet;
using VisionMachine.Models.Camera;

namespace VisionMachine.Services.Camera
{
	// Token: 0x02000240 RID: 576
	public sealed class HikLiveCameraService : IDisposable
	{
		// Token: 0x060020B6 RID: 8374 RVA: 0x000BF3D4 File Offset: 0x000BD5D4
		public void Start(CameraParameterConfig config, HSmartWindowControlWPF display)
		{
			bool flag = config == null || display == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			if (!flag)
			{
				this.Stop();
				try
				{
					this._config = config;
					this._cameraId = config.ConnectedCameraId;
					CameraSnapshotService.Release(this._cameraId);
					this._device = HikLiveCameraService.CreateDeviceBySerial(this._cameraId);
					bool flag2 = this._device == null;
					if (flag2)
					{
						throw new InvalidOperationException("Hikvision camera was not found: " + this._cameraId);
					}
					HikLiveCameraService.InvokeMethod(this._device, "Open", Array.Empty<object>());
					this._streamGrabber = HikLiveCameraService.GetProperty(this._device, "StreamGrabber");
					this.ApplyParameter(config);
					CameraHardwareRuntimeService.Register(this._cameraId, this);
					HikLiveCameraService.InvokeMethod(this._streamGrabber, "StartGrabbing", Array.Empty<object>());
					this._cancellation = new CancellationTokenSource();
					this._worker = Task.Run(delegate()
					{
						this.LiveLoop(display, this._cancellation.Token);
					}, this._cancellation.Token);
				}
				catch
				{
					this.Stop();
					throw;
				}
			}
		}

		// Token: 0x060020B7 RID: 8375 RVA: 0x000BF518 File Offset: 0x000BD718
		public void Stop()
		{
			try
			{
				CancellationTokenSource cancellation = this._cancellation;
				if (cancellation != null)
				{
					cancellation.Cancel();
				}
				Task worker = this._worker;
				if (worker != null)
				{
					worker.Wait(1000);
				}
			}
			catch
			{
			}
			finally
			{
				CameraHardwareRuntimeService.Unregister(this._cameraId, this);
				this._cameraId = null;
				this._config = null;
				this._worker = null;
				this.DisposeLatestImage();
				CancellationTokenSource cancellation2 = this._cancellation;
				if (cancellation2 != null)
				{
					cancellation2.Dispose();
				}
				this._cancellation = null;
				try
				{
					HikLiveCameraService.InvokeMethod(this._streamGrabber, "StopGrabbing", Array.Empty<object>());
				}
				catch
				{
				}
				try
				{
					HikLiveCameraService.InvokeMethod(this._device, "Close", Array.Empty<object>());
				}
				catch
				{
				}
				HikLiveCameraService.TryDispose(this._device);
				this._streamGrabber = null;
				this._device = null;
			}
		}

		// Token: 0x060020B8 RID: 8376 RVA: 0x000BF630 File Offset: 0x000BD830
		public void Dispose()
		{
			this.Stop();
		}

		// Token: 0x060020B9 RID: 8377 RVA: 0x000BF63C File Offset: 0x000BD83C
		public void SetExposure(double exposureTime)
		{
			object deviceLock = this._deviceLock;
			lock (deviceLock)
			{
				this.TrySetFloatParameter("ExposureTime", exposureTime);
			}
		}

		// Token: 0x060020BA RID: 8378 RVA: 0x000BF688 File Offset: 0x000BD888
		public void SetGain(double gain)
		{
			object deviceLock = this._deviceLock;
			lock (deviceLock)
			{
				this.TrySetFloatParameter("Gain", gain);
			}
		}

		// Token: 0x060020BB RID: 8379 RVA: 0x000BF6D4 File Offset: 0x000BD8D4
		public void SetTriggerMode(bool enabled)
		{
			object deviceLock = this._deviceLock;
			lock (deviceLock)
			{
				this.TrySetEnumParameter("TriggerSelector", "FrameStart");
				if (enabled)
				{
					this.TrySetEnumParameter("TriggerSource", "Line1");
					this.TrySetEnumParameter("TriggerActivation", "RisingEdge");
				}
				this.TrySetEnumParameter("TriggerMode", enabled ? "On" : "Off");
			}
		}

		// Token: 0x060020BC RID: 8380 RVA: 0x000BF768 File Offset: 0x000BD968
		public void SetPixelFormat(string pixelFormat)
		{
			object deviceLock = this._deviceLock;
			lock (deviceLock)
			{
				this.TrySetEnumParameter("PixelFormat", pixelFormat);
			}
		}

		// Token: 0x060020BD RID: 8381 RVA: 0x0000AB39 File Offset: 0x00008D39
		public void SetLightSourcePreset(string preset)
		{
		}

		// Token: 0x060020BE RID: 8382 RVA: 0x000BF7B4 File Offset: 0x000BD9B4
		public List<string> GetPixelFormatOptions()
		{
			object deviceLock = this._deviceLock;
			List<string> enumParameterSymbols;
			lock (deviceLock)
			{
				enumParameterSymbols = this.GetEnumParameterSymbols("PixelFormat");
			}
			return enumParameterSymbols;
		}

		// Token: 0x060020BF RID: 8383 RVA: 0x000BF800 File Offset: 0x000BDA00
		public List<string> GetLightSourcePresetOptions()
		{
			return new List<string>();
		}

		// Token: 0x060020C0 RID: 8384 RVA: 0x000BF818 File Offset: 0x000BDA18
		public static List<string> GetSupportedPixelFormats(string serial)
		{
			return HikLiveCameraService.ReadEnumParameterSymbols(serial, "PixelFormat");
		}

		// Token: 0x060020C1 RID: 8385 RVA: 0x000BF838 File Offset: 0x000BDA38
		public static HObject CaptureSnapshot(CameraParameterConfig config)
		{
			bool flag = config == null;
			if (flag)
			{
				throw new ArgumentNullException("config");
			}
			bool flag2 = string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			if (flag2)
			{
				throw new InvalidOperationException("No serial camera is selected.");
			}
			return HikLiveCameraService.CaptureSnapshotCached(config);
		}

		// Token: 0x060020C2 RID: 8386 RVA: 0x000BF880 File Offset: 0x000BDA80
		public static void WarmupSnapshot(CameraParameterConfig config)
		{
			bool flag = config == null || string.IsNullOrWhiteSpace(config.ConnectedCameraId);
			if (!flag)
			{
				object snapshotSessionsLock = HikLiveCameraService.SnapshotSessionsLock;
				HikLiveCameraService.HikSnapshotSession session;
				lock (snapshotSessionsLock)
				{
					bool flag3 = !HikLiveCameraService.SnapshotSessions.TryGetValue(config.ConnectedCameraId, out session);
					if (flag3)
					{
						session = new HikLiveCameraService.HikSnapshotSession(config.ConnectedCameraId);
						HikLiveCameraService.SnapshotSessions[config.ConnectedCameraId] = session;
					}
				}
				try
				{
					session.Warmup(config);
				}
				catch
				{
					HikLiveCameraService.ReleaseSnapshot(config.ConnectedCameraId);
					throw;
				}
			}
		}

		// Token: 0x060020C3 RID: 8387 RVA: 0x000BF93C File Offset: 0x000BDB3C
		public static void ReleaseSnapshot(string cameraId)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraId);
			if (!flag)
			{
				object snapshotSessionsLock = HikLiveCameraService.SnapshotSessionsLock;
				lock (snapshotSessionsLock)
				{
					HikLiveCameraService.HikSnapshotSession session;
					bool flag3 = !HikLiveCameraService.SnapshotSessions.TryGetValue(cameraId, out session);
					if (!flag3)
					{
						HikLiveCameraService.SnapshotSessions.Remove(cameraId);
						session.Dispose();
					}
				}
			}
		}

		// Token: 0x060020C4 RID: 8388 RVA: 0x000BF9B4 File Offset: 0x000BDBB4
		private static HObject CaptureSnapshotCached(CameraParameterConfig config)
		{
			object snapshotSessionsLock = HikLiveCameraService.SnapshotSessionsLock;
			HikLiveCameraService.HikSnapshotSession session;
			lock (snapshotSessionsLock)
			{
				bool flag2 = !HikLiveCameraService.SnapshotSessions.TryGetValue(config.ConnectedCameraId, out session);
				if (flag2)
				{
					session = new HikLiveCameraService.HikSnapshotSession(config.ConnectedCameraId);
					HikLiveCameraService.SnapshotSessions[config.ConnectedCameraId] = session;
				}
			}
			HObject result;
			try
			{
				result = session.Capture(config);
			}
			catch
			{
				HikLiveCameraService.ReleaseSnapshot(config.ConnectedCameraId);
				throw;
			}
			return result;
		}

		// Token: 0x060020C5 RID: 8389 RVA: 0x000BFA58 File Offset: 0x000BDC58
		public bool IsCameraConnected()
		{
			object deviceLock = this._deviceLock;
			bool result;
			lock (deviceLock)
			{
				result = HikLiveCameraService.IsDeviceConnected(this._device);
			}
			return result;
		}

		// Token: 0x060020C6 RID: 8390 RVA: 0x000BFAA4 File Offset: 0x000BDCA4
		internal static bool IsDeviceConnected(object device)
		{
			bool flag = device == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					Type type = device.GetType();
					PropertyInfo prop = type.GetProperty("IsConnected");
					bool flag2 = prop != null && prop.PropertyType == typeof(bool);
					if (flag2)
					{
						return (bool)prop.GetValue(device);
					}
					foreach (string name in new string[]
					{
						"IsConnected",
						"IsDeviceConnected",
						"MV_CC_IsDeviceConnected_NET",
						"MV_CC_IsDeviceConnected"
					})
					{
						MethodInfo method = type.GetMethod(name, Type.EmptyTypes);
						bool flag3 = method != null && method.ReturnType == typeof(bool);
						if (flag3)
						{
							return (bool)method.Invoke(device, null);
						}
					}
				}
				catch
				{
				}
				result = true;
			}
			return result;
		}

		// Token: 0x060020C7 RID: 8391 RVA: 0x000BFBBC File Offset: 0x000BDDBC
		public long GetLatestImageAgeMs()
		{
			object latestImageLock = this._latestImageLock;
			long result;
			lock (latestImageLock)
			{
				bool flag2 = this._latestImage == null || !this._latestImage.IsInitialized();
				if (flag2)
				{
					result = long.MaxValue;
				}
				else
				{
					result = this._latestImageStopwatch.ElapsedMilliseconds;
				}
			}
			return result;
		}

		// Token: 0x060020C8 RID: 8392 RVA: 0x000BFC34 File Offset: 0x000BDE34
		public bool CopyLatestImage(out HObject image)
		{
			image = null;
			object latestImageLock = this._latestImageLock;
			bool result;
			lock (latestImageLock)
			{
				bool flag2 = this._latestImage == null || !this._latestImage.IsInitialized();
				if (flag2)
				{
					result = false;
				}
				else
				{
					try
					{
						HOperatorSet.CopyImage(this._latestImage, out image);
						result = (image != null && image.IsInitialized());
					}
					catch
					{
						HObject hobject = image;
						if (hobject != null)
						{
							hobject.Dispose();
						}
						image = null;
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x060020C9 RID: 8393 RVA: 0x000BFCDC File Offset: 0x000BDEDC
		private void LiveLoop(HSmartWindowControlWPF display, CancellationToken token)
		{
			while (!token.IsCancellationRequested)
			{
				object frame = null;
				try
				{
					object deviceLock = this._deviceLock;
					lock (deviceLock)
					{
						frame = this.GetImageBuffer(250U);
					}
					bool flag2 = frame == null;
					if (!flag2)
					{
						object sdkImage = HikLiveCameraService.GetProperty(frame, "Image");
						bool flag3 = sdkImage == null;
						if (!flag3)
						{
							HObject image = HikLiveCameraService.ConvertSdkImageToHalconImage(sdkImage);
							bool flag4 = image == null || !image.IsInitialized();
							if (flag4)
							{
								if (image != null)
								{
									image.Dispose();
								}
							}
							else
							{
								HObject displayImage = CameraImageTransformService.Apply(image, this._config);
								bool flag5 = displayImage != image;
								if (flag5)
								{
									image.Dispose();
								}
								image = displayImage;
								HTuple displayWidth;
								HTuple displayHeight;
								HOperatorSet.GetImageSize(image, out displayWidth, out displayHeight);
								int width = displayWidth.I;
								int height = displayHeight.I;
								this.StoreLatestImage(image);
								bool flag6 = this._config != null && this._config.HardwareTrigger;
								if (flag6)
								{
									CameraHardwareTriggerFrameRouter.Publish(this._config, image);
									image.Dispose();
								}
								else
								{
									HObject displayFrame = image;
									bool flag7 = Interlocked.CompareExchange(ref this._displayPending, 1, 0) != 0;
									if (flag7)
									{
										displayFrame.Dispose();
									}
									else
									{
										display.Dispatcher.BeginInvoke(new Action(delegate()
										{
											try
											{
												CameraLiveDisplayState displayState = display.Tag as CameraLiveDisplayState;
												bool flag8 = displayState != null;
												if (flag8)
												{
													displayState.DisplayFrame(displayFrame, width, height, this._config);
												}
												else
												{
													HWindow window = display.HalconWindow;
													window.ClearWindow();
													window.SetPart(0, 0, height - 1, width - 1);
													window.DispObj(displayFrame);
												}
											}
											finally
											{
												displayFrame.Dispose();
												Interlocked.Exchange(ref this._displayPending, 0);
											}
										}), DispatcherPriority.Background, Array.Empty<object>());
									}
								}
							}
						}
					}
				}
				catch
				{
					Thread.Sleep(50);
				}
				finally
				{
					this.FreeImageBuffer(frame);
				}
			}
		}

		// Token: 0x060020CA RID: 8394 RVA: 0x000BFF04 File Offset: 0x000BE104
		private void ApplyParameter(CameraParameterConfig config)
		{
			object deviceLock = this._deviceLock;
			lock (deviceLock)
			{
				this.TrySetFloatParameter("ExposureTime", config.ExposureTime);
				this.TrySetFloatParameter("Gain", config.Gain);
				this.TrySetEnumParameter("TriggerSelector", "FrameStart");
				bool hardwareTrigger = config.HardwareTrigger;
				if (hardwareTrigger)
				{
					this.TrySetEnumParameter("TriggerSource", "Line1");
					this.TrySetEnumParameter("TriggerActivation", "RisingEdge");
				}
				this.TrySetEnumParameter("TriggerMode", config.HardwareTrigger ? "On" : "Off");
				this.TrySetEnumParameter("PixelFormat", config.PixelFormat);
			}
		}

		// Token: 0x060020CB RID: 8395 RVA: 0x000BFFD8 File Offset: 0x000BE1D8
		private object GetImageBuffer(uint timeout)
		{
			object streamGrabber = this._streamGrabber;
			MethodInfo methodInfo;
			if (streamGrabber == null)
			{
				methodInfo = null;
			}
			else
			{
				methodInfo = streamGrabber.GetType().GetMethods().FirstOrDefault(delegate(MethodInfo x)
				{
					bool flag3 = x.Name != "GetImageBuffer";
					bool result3;
					if (flag3)
					{
						result3 = false;
					}
					else
					{
						ParameterInfo[] parameters = x.GetParameters();
						result3 = (parameters.Length == 2 && parameters[1].ParameterType.IsByRef);
					}
					return result3;
				});
			}
			MethodInfo method = methodInfo;
			bool flag = method == null;
			object result2;
			if (flag)
			{
				result2 = null;
			}
			else
			{
				object[] array = new object[2];
				array[0] = timeout;
				object[] args = array;
				object result = method.Invoke(this._streamGrabber, args);
				bool flag2 = !HikLiveCameraService.IsSuccess(result);
				if (flag2)
				{
					result2 = null;
				}
				else
				{
					result2 = args[1];
				}
			}
			return result2;
		}

		// Token: 0x060020CC RID: 8396 RVA: 0x000C0070 File Offset: 0x000BE270
		private void FreeImageBuffer(object frame)
		{
			bool flag = frame == null || this._streamGrabber == null;
			if (!flag)
			{
				try
				{
					HikLiveCameraService.InvokeMethod(this._streamGrabber, "FreeImageBuffer", new object[]
					{
						frame
					});
				}
				catch
				{
				}
			}
		}

		// Token: 0x060020CD RID: 8397 RVA: 0x000C00CC File Offset: 0x000BE2CC
		private void StoreLatestImage(HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			if (!flag)
			{
				object latestImageLock = this._latestImageLock;
				lock (latestImageLock)
				{
					bool flag3 = this._latestImage != null && this._latestImage.IsInitialized() && this._latestImageStopwatch.ElapsedMilliseconds < 100L;
					if (flag3)
					{
						return;
					}
				}
				HObject copy = null;
				try
				{
					HOperatorSet.CopyImage(image, out copy);
				}
				catch
				{
					if (copy != null)
					{
						copy.Dispose();
					}
					copy = null;
				}
				bool flag4 = copy == null;
				if (!flag4)
				{
					object latestImageLock2 = this._latestImageLock;
					lock (latestImageLock2)
					{
						this.DisposeLatestImageCore();
						this._latestImage = copy;
						this._latestImageStopwatch.Restart();
					}
				}
			}
		}

		// Token: 0x060020CE RID: 8398 RVA: 0x000C01DC File Offset: 0x000BE3DC
		private void DisposeLatestImage()
		{
			object latestImageLock = this._latestImageLock;
			lock (latestImageLock)
			{
				this.DisposeLatestImageCore();
			}
		}

		// Token: 0x060020CF RID: 8399 RVA: 0x000C0224 File Offset: 0x000BE424
		private void DisposeLatestImageCore()
		{
			try
			{
				HObject latestImage = this._latestImage;
				if (latestImage != null)
				{
					latestImage.Dispose();
				}
			}
			catch
			{
			}
			this._latestImage = null;
		}

		// Token: 0x060020D0 RID: 8400 RVA: 0x000C0264 File Offset: 0x000BE464
		public CameraParameterRange GetGainRange()
		{
			object deviceLock = this._deviceLock;
			CameraParameterRange result;
			lock (deviceLock)
			{
				result = HikLiveCameraService.ReadFloatRange(HikLiveCameraService.GetProperty(this._device, "Parameters"), "Gain");
			}
			return result;
		}

		// Token: 0x060020D1 RID: 8401 RVA: 0x000C02C0 File Offset: 0x000BE4C0
		public CameraParameterRange GetExposureRange()
		{
			object deviceLock = this._deviceLock;
			CameraParameterRange result;
			lock (deviceLock)
			{
				result = HikLiveCameraService.ReadFloatRange(HikLiveCameraService.GetProperty(this._device, "Parameters"), "ExposureTime");
			}
			return result;
		}

		// Token: 0x060020D2 RID: 8402 RVA: 0x000C031C File Offset: 0x000BE51C
		private static CameraParameterRange ReadFloatRange(object parameters, string name)
		{
			bool flag = parameters == null || string.IsNullOrWhiteSpace(name);
			CameraParameterRange result;
			if (flag)
			{
				result = null;
			}
			else
			{
				MethodInfo method = parameters.GetType().GetMethods().FirstOrDefault(delegate(MethodInfo x)
				{
					bool flag6 = x.Name != "GetFloatValue";
					bool result2;
					if (flag6)
					{
						result2 = false;
					}
					else
					{
						ParameterInfo[] args = x.GetParameters();
						result2 = (args.Length == 2 && args[0].ParameterType == typeof(string) && args[1].ParameterType.IsByRef);
					}
					return result2;
				});
				bool flag2 = method == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					object[] array = new object[2];
					array[0] = name;
					object[] invokeArgs = array;
					try
					{
						object status = method.Invoke(parameters, invokeArgs);
						bool flag3 = !HikLiveCameraService.IsSuccess(status);
						if (flag3)
						{
							return null;
						}
					}
					catch
					{
						return null;
					}
					object floatValue = invokeArgs[1];
					bool flag4 = floatValue == null;
					if (flag4)
					{
						result = null;
					}
					else
					{
						object minObj = HikLiveCameraService.GetProperty(floatValue, "Min");
						object maxObj = HikLiveCameraService.GetProperty(floatValue, "Max");
						bool flag5 = minObj == null || maxObj == null;
						if (flag5)
						{
							result = null;
						}
						else
						{
							try
							{
								result = new CameraParameterRange
								{
									Min = Convert.ToDouble(minObj),
									Max = Convert.ToDouble(maxObj),
									IsInteger = false
								};
							}
							catch
							{
								result = null;
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060020D3 RID: 8403 RVA: 0x000C0458 File Offset: 0x000BE658
		public static CameraParameterRange GetFloatRange(string serial, string name)
		{
			bool flag = string.IsNullOrWhiteSpace(serial) || string.IsNullOrWhiteSpace(name);
			CameraParameterRange result;
			if (flag)
			{
				result = null;
			}
			else
			{
				object device = null;
				try
				{
					device = HikLiveCameraService.CreateDeviceBySerial(serial);
					bool flag2 = device == null;
					if (flag2)
					{
						result = null;
					}
					else
					{
						bool flag3 = !HikLiveCameraService.IsSuccess(HikLiveCameraService.InvokeMethod(device, "Open", Array.Empty<object>()));
						if (flag3)
						{
							result = null;
						}
						else
						{
							result = HikLiveCameraService.ReadFloatRange(HikLiveCameraService.GetProperty(device, "Parameters"), name);
						}
					}
				}
				catch
				{
					result = null;
				}
				finally
				{
					try
					{
						HikLiveCameraService.InvokeMethod(device, "Close", Array.Empty<object>());
					}
					catch
					{
					}
					HikLiveCameraService.TryDispose(device);
				}
			}
			return result;
		}

		// Token: 0x060020D4 RID: 8404 RVA: 0x000C0520 File Offset: 0x000BE720
		private bool TrySetFloatParameter(string name, double value)
		{
			object parameters = HikLiveCameraService.GetProperty(this._device, "Parameters");
			return HikLiveCameraService.InvokeParameterMethod(parameters, "SetFloatValue", name, Convert.ToSingle(value));
		}

		// Token: 0x060020D5 RID: 8405 RVA: 0x000C055C File Offset: 0x000BE75C
		private bool TrySetEnumParameter(string name, string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				object parameters = HikLiveCameraService.GetProperty(this._device, "Parameters");
				result = HikLiveCameraService.InvokeParameterMethod(parameters, "SetEnumValueByString", name, value);
			}
			return result;
		}

		// Token: 0x060020D6 RID: 8406 RVA: 0x000C059C File Offset: 0x000BE79C
		private static bool InvokeParameterMethod(object parameters, string methodName, string name, object value)
		{
			bool flag = parameters == null || string.IsNullOrWhiteSpace(name);
			bool result2;
			if (flag)
			{
				result2 = false;
			}
			else
			{
				MethodInfo method = parameters.GetType().GetMethods().FirstOrDefault(delegate(MethodInfo x)
				{
					bool flag3 = x.Name != methodName;
					bool result3;
					if (flag3)
					{
						result3 = false;
					}
					else
					{
						ParameterInfo[] args = x.GetParameters();
						result3 = (args.Length == 2 && args[0].ParameterType == typeof(string));
					}
					return result3;
				});
				bool flag2 = method == null;
				if (flag2)
				{
					result2 = false;
				}
				else
				{
					try
					{
						object result = method.Invoke(parameters, new object[]
						{
							name,
							value
						});
						result2 = HikLiveCameraService.IsSuccess(result);
					}
					catch
					{
						result2 = false;
					}
				}
			}
			return result2;
		}

		// Token: 0x060020D7 RID: 8407 RVA: 0x000C0634 File Offset: 0x000BE834
		private static object CreateDeviceBySerial(string serial)
		{
			Assembly assembly = CameraSdkAssemblyLoader.LoadHikvisionMvs();
			bool flag = assembly == null;
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				object deviceInfo = HikLiveCameraService.FindDeviceInfoBySerial(assembly, serial);
				bool flag2 = deviceInfo == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					Type factoryType = assembly.GetType("MvCameraControl.DeviceFactory");
					MethodInfo methodInfo;
					if (factoryType == null)
					{
						methodInfo = null;
					}
					else
					{
						methodInfo = factoryType.GetMethods(BindingFlags.Static | BindingFlags.Public).FirstOrDefault((MethodInfo x) => x.Name == "CreateDevice" && x.GetParameters().Length == 1);
					}
					MethodInfo createMethod = methodInfo;
					result = ((createMethod != null) ? createMethod.Invoke(null, new object[]
					{
						deviceInfo
					}) : null);
				}
			}
			return result;
		}

		// Token: 0x060020D8 RID: 8408 RVA: 0x000C06D0 File Offset: 0x000BE8D0
		private List<string> GetEnumParameterSymbols(string name)
		{
			object parameters = HikLiveCameraService.GetProperty(this._device, "Parameters");
			return HikLiveCameraService.ReadEnumParameterSymbols(parameters, name);
		}

		// Token: 0x060020D9 RID: 8409 RVA: 0x000C06FC File Offset: 0x000BE8FC
		private static List<string> ReadEnumParameterSymbols(string serial, string name)
		{
			List<string> result = new List<string>();
			bool flag = string.IsNullOrWhiteSpace(serial) || string.IsNullOrWhiteSpace(name);
			List<string> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				object device = null;
				try
				{
					device = HikLiveCameraService.CreateDeviceBySerial(serial);
					bool flag2 = device == null;
					if (flag2)
					{
						result2 = result;
					}
					else
					{
						bool flag3 = !HikLiveCameraService.IsSuccess(HikLiveCameraService.InvokeMethod(device, "Open", Array.Empty<object>()));
						if (flag3)
						{
							result2 = result;
						}
						else
						{
							object parameters = HikLiveCameraService.GetProperty(device, "Parameters");
							result2 = HikLiveCameraService.ReadEnumParameterSymbols(parameters, name);
						}
					}
				}
				catch
				{
					result2 = result;
				}
				finally
				{
					try
					{
						HikLiveCameraService.InvokeMethod(device, "Close", Array.Empty<object>());
					}
					catch
					{
					}
					HikLiveCameraService.TryDispose(device);
				}
			}
			return result2;
		}

		// Token: 0x060020DA RID: 8410 RVA: 0x000C07D0 File Offset: 0x000BE9D0
		private static List<string> ReadEnumParameterSymbols(object parameters, string name)
		{
			List<string> result = new List<string>();
			bool flag = parameters == null || string.IsNullOrWhiteSpace(name);
			List<string> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				MethodInfo method = parameters.GetType().GetMethods().FirstOrDefault(delegate(MethodInfo x)
				{
					bool flag5 = x.Name != "GetEnumValue";
					bool result3;
					if (flag5)
					{
						result3 = false;
					}
					else
					{
						ParameterInfo[] args = x.GetParameters();
						result3 = (args.Length == 2 && args[0].ParameterType == typeof(string) && args[1].ParameterType.IsByRef);
					}
					return result3;
				});
				bool flag2 = method == null;
				if (flag2)
				{
					result2 = result;
				}
				else
				{
					object[] array = new object[2];
					array[0] = name;
					object[] invokeArgs = array;
					try
					{
						object status = method.Invoke(parameters, invokeArgs);
						bool flag3 = !HikLiveCameraService.IsSuccess(status);
						if (flag3)
						{
							return result;
						}
					}
					catch
					{
						return result;
					}
					object enumValue = invokeArgs[1];
					object entries = HikLiveCameraService.GetProperty(enumValue, "SupportEnumEntries");
					foreach (object entry in ((entries as IEnumerable) ?? new object[0]))
					{
						object property = HikLiveCameraService.GetProperty(entry, "Symbolic");
						string symbolic = (property != null) ? property.ToString() : null;
						bool flag4 = !string.IsNullOrWhiteSpace(symbolic) && !result.Contains(symbolic);
						if (flag4)
						{
							result.Add(symbolic);
						}
					}
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x060020DB RID: 8411 RVA: 0x000C093C File Offset: 0x000BEB3C
		private static object FindDeviceInfoBySerial(Assembly assembly, string serial)
		{
			Type layerType = assembly.GetType("MvCameraControl.DeviceTLayerType");
			Type deviceInfoType = assembly.GetType("MvCameraControl.IDeviceInfo");
			Type deviceEnumeratorType = assembly.GetType("MvCameraControl.DeviceEnumerator");
			bool flag = layerType == null || deviceInfoType == null || deviceEnumeratorType == null;
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				Type listType = typeof(List<>).MakeGenericType(new Type[]
				{
					deviceInfoType
				});
				MethodInfo enumMethod = deviceEnumeratorType.GetMethods(BindingFlags.Static | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo method)
				{
					bool flag4 = method.Name != "EnumDevices";
					bool result2;
					if (flag4)
					{
						result2 = false;
					}
					else
					{
						ParameterInfo[] parameters = method.GetParameters();
						Type listParameterType = (parameters.Length == 2 && parameters[1].ParameterType.IsByRef) ? parameters[1].ParameterType.GetElementType() : ((parameters.Length == 2) ? parameters[1].ParameterType : null);
						result2 = (parameters.Length == 2 && parameters[0].ParameterType == layerType && listParameterType == listType);
					}
					return result2;
				});
				bool flag2 = enumMethod == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					object devices = Activator.CreateInstance(listType);
					object layerMask = HikLiveCameraService.BuildLayerMask(layerType);
					object[] args = new object[]
					{
						layerMask,
						devices
					};
					try
					{
						enumMethod.Invoke(null, args);
						devices = (args[1] ?? devices);
					}
					catch
					{
						return null;
					}
					foreach (object deviceInfo in (devices as IEnumerable))
					{
						object property = HikLiveCameraService.GetProperty(deviceInfo, "SerialNumber");
						string deviceSerial = (property != null) ? property.ToString() : null;
						bool flag3 = string.Equals(deviceSerial, serial, StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							return deviceInfo;
						}
					}
					result = null;
				}
			}
			return result;
		}

		// Token: 0x060020DC RID: 8412 RVA: 0x000C0AD4 File Offset: 0x000BECD4
		private static object BuildLayerMask(Type layerType)
		{
			int mask = 0;
			string[] names = new string[]
			{
				"MvGigEDevice",
				"MvUsbDevice",
				"MvCameraLinkDevice",
				"MvGenTLGigEDevice",
				"MvGenTLCameraLinkDevice",
				"MvGenTLCXPDevice",
				"MvGenTLXoFDevice"
			};
			foreach (string name in names)
			{
				try
				{
					object value = Enum.Parse(layerType, name);
					mask |= Convert.ToInt32(value);
				}
				catch
				{
				}
			}
			bool flag = mask <= 0;
			if (flag)
			{
				mask = -1;
			}
			return Enum.ToObject(layerType, mask);
		}

		// Token: 0x060020DD RID: 8413 RVA: 0x000C0B84 File Offset: 0x000BED84
		private static HObject ConvertSdkImageToHalconImage(object sdkImage)
		{
			HObject image;
			bool flag = HikLiveCameraService.TryConvertSdkImageFast(sdkImage, out image);
			HObject result;
			if (flag)
			{
				result = image;
			}
			else
			{
				using (Bitmap bitmap = HikLiveCameraService.InvokeMethod(sdkImage, "ToBitmap", Array.Empty<object>()) as Bitmap)
				{
					bool flag2 = bitmap == null || bitmap.Width <= 0 || bitmap.Height <= 0;
					if (flag2)
					{
						result = null;
					}
					else
					{
						result = HikLiveCameraService.ConvertBitmapToHalconImage(bitmap);
					}
				}
			}
			return result;
		}

		// Token: 0x060020DE RID: 8414 RVA: 0x000C0C08 File Offset: 0x000BEE08
		private static bool TryConvertSdkImageFast(object sdkImage, out HObject image)
		{
			image = null;
			bool flag = sdkImage == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				int width = Convert.ToInt32(HikLiveCameraService.GetProperty(sdkImage, "Width") ?? 0);
				int height = Convert.ToInt32(HikLiveCameraService.GetProperty(sdkImage, "Height") ?? 0);
				bool flag2 = width <= 0 || height <= 0;
				if (flag2)
				{
					result = false;
				}
				else
				{
					string pixelType = Convert.ToString(HikLiveCameraService.GetProperty(sdkImage, "PixelType")) ?? string.Empty;
					bool flag3 = HikLiveCameraService.IsMono8PixelType(pixelType) || HikLiveCameraService.IsBayer8PixelType(pixelType);
					if (flag3)
					{
						byte[] pixels = HikLiveCameraService.CopyImageBytes(sdkImage, width * height);
						bool flag4 = pixels == null;
						if (flag4)
						{
							result = false;
						}
						else
						{
							image = HikLiveCameraService.CreateMonoImage(pixels, width, height);
							result = true;
						}
					}
					else
					{
						bool flag5 = HikLiveCameraService.IsBgr8PackedPixelType(pixelType) || HikLiveCameraService.IsRgb8PackedPixelType(pixelType);
						if (flag5)
						{
							byte[] pixels2 = HikLiveCameraService.CopyImageBytes(sdkImage, width * height * 3);
							bool flag6 = pixels2 == null;
							if (flag6)
							{
								result = false;
							}
							else
							{
								image = HikLiveCameraService.CreateInterleavedImage(pixels2, width, height, HikLiveCameraService.IsBgr8PackedPixelType(pixelType) ? "bgr" : "rgb");
								result = true;
							}
						}
						else
						{
							result = false;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060020DF RID: 8415 RVA: 0x000C0D3C File Offset: 0x000BEF3C
		private static byte[] CopyImageBytes(object sdkImage, int expectedBytes)
		{
			bool flag = expectedBytes <= 0;
			byte[] result;
			if (flag)
			{
				result = null;
			}
			else
			{
				byte[] sourceBytes = HikLiveCameraService.GetProperty(sdkImage, "PixelData") as byte[];
				bool flag2 = sourceBytes != null && sourceBytes.Length >= expectedBytes;
				if (flag2)
				{
					bool flag3 = sourceBytes.Length == expectedBytes;
					if (flag3)
					{
						result = sourceBytes;
					}
					else
					{
						byte[] pixels = new byte[expectedBytes];
						Buffer.BlockCopy(sourceBytes, 0, pixels, 0, expectedBytes);
						result = pixels;
					}
				}
				else
				{
					IntPtr pixelDataPtr = HikLiveCameraService.GetIntPtrProperty(sdkImage, "PixelDataPtr");
					bool flag4 = pixelDataPtr == IntPtr.Zero;
					if (flag4)
					{
						result = null;
					}
					else
					{
						byte[] copiedPixels = new byte[expectedBytes];
						Marshal.Copy(pixelDataPtr, copiedPixels, 0, expectedBytes);
						result = copiedPixels;
					}
				}
			}
			return result;
		}

		// Token: 0x060020E0 RID: 8416 RVA: 0x000C0DEC File Offset: 0x000BEFEC
		private static HObject CreateMonoImage(byte[] pixels, int width, int height)
		{
			GCHandle handle = GCHandle.Alloc(pixels, GCHandleType.Pinned);
			HObject result;
			try
			{
				HObject image;
				HOperatorSet.GenImage1(out image, "byte", width, height, handle.AddrOfPinnedObject());
				result = image;
			}
			finally
			{
				handle.Free();
			}
			return result;
		}

		// Token: 0x060020E1 RID: 8417 RVA: 0x000C0E50 File Offset: 0x000BF050
		private static HObject CreateInterleavedImage(byte[] pixels, int width, int height, string colorFormat)
		{
			GCHandle handle = GCHandle.Alloc(pixels, GCHandleType.Pinned);
			HObject result;
			try
			{
				HObject image;
				HOperatorSet.GenImageInterleaved(out image, handle.AddrOfPinnedObject(), colorFormat, width, height, 0, "byte", width, height, 0, 0, -1, 0);
				result = image;
			}
			finally
			{
				handle.Free();
			}
			return result;
		}

		// Token: 0x060020E2 RID: 8418 RVA: 0x000C0EE4 File Offset: 0x000BF0E4
		private static bool IsMono8PixelType(string pixelType)
		{
			return !string.IsNullOrWhiteSpace(pixelType) && pixelType.IndexOf("Mono8", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x060020E3 RID: 8419 RVA: 0x000C0F14 File Offset: 0x000BF114
		private static bool IsBayer8PixelType(string pixelType)
		{
			return !string.IsNullOrWhiteSpace(pixelType) && pixelType.IndexOf("Bayer", StringComparison.OrdinalIgnoreCase) >= 0 && pixelType.EndsWith("8", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x060020E4 RID: 8420 RVA: 0x000C0F4C File Offset: 0x000BF14C
		private static bool IsBgr8PackedPixelType(string pixelType)
		{
			string normalized = HikLiveCameraService.NormalizePixelType(pixelType);
			return normalized.IndexOf("BGR8PACKED", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x060020E5 RID: 8421 RVA: 0x000C0F78 File Offset: 0x000BF178
		private static bool IsRgb8PackedPixelType(string pixelType)
		{
			string normalized = HikLiveCameraService.NormalizePixelType(pixelType);
			return normalized.IndexOf("RGB8PACKED", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x060020E6 RID: 8422 RVA: 0x000C0FA4 File Offset: 0x000BF1A4
		private static string NormalizePixelType(string pixelType)
		{
			bool flag = string.IsNullOrWhiteSpace(pixelType);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				result = pixelType.Replace("_", string.Empty).Replace("-", string.Empty).Replace(" ", string.Empty).ToUpperInvariant();
			}
			return result;
		}

		// Token: 0x060020E7 RID: 8423 RVA: 0x000C0FFC File Offset: 0x000BF1FC
		private static IntPtr GetIntPtrProperty(object target, string propertyName)
		{
			object value = HikLiveCameraService.GetProperty(target, propertyName);
			IntPtr pointer;
			bool flag;
			if (value is IntPtr)
			{
				pointer = (IntPtr)value;
				flag = true;
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			IntPtr result;
			if (flag2)
			{
				result = pointer;
			}
			else
			{
				result = IntPtr.Zero;
			}
			return result;
		}

		// Token: 0x060020E8 RID: 8424 RVA: 0x000C1038 File Offset: 0x000BF238
		private static HObject ConvertBitmapToHalconImage(Bitmap source)
		{
			HObject result;
			using (Bitmap bitmap = new Bitmap(source.Width, source.Height, PixelFormat.Format24bppRgb))
			{
				using (Graphics graphics = Graphics.FromImage(bitmap))
				{
					graphics.DrawImage(source, 0, 0, source.Width, source.Height);
					Rectangle rect = new Rectangle(0, 0, bitmap.Width, bitmap.Height);
					BitmapData data = bitmap.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
					try
					{
						int rowBytes = bitmap.Width * 3;
						byte[] pixels = new byte[rowBytes * bitmap.Height];
						for (int row = 0; row < bitmap.Height; row++)
						{
							IntPtr sourceRow = IntPtr.Add(data.Scan0, row * data.Stride);
							Marshal.Copy(sourceRow, pixels, row * rowBytes, rowBytes);
						}
						GCHandle handle = GCHandle.Alloc(pixels, GCHandleType.Pinned);
						try
						{
							HObject image;
							HOperatorSet.GenImageInterleaved(out image, handle.AddrOfPinnedObject(), "bgr", bitmap.Width, bitmap.Height, 0, "byte", bitmap.Width, bitmap.Height, 0, 0, -1, 0);
							result = image;
						}
						finally
						{
							handle.Free();
						}
					}
					finally
					{
						bitmap.UnlockBits(data);
					}
				}
			}
			return result;
		}

		// Token: 0x060020E9 RID: 8425 RVA: 0x000C1214 File Offset: 0x000BF414
		private static object InvokeMethod(object target, string methodName, params object[] args)
		{
			bool flag = target == null;
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				MethodInfo method = target.GetType().GetMethods().FirstOrDefault(delegate(MethodInfo x)
				{
					bool result2;
					if (x.Name == methodName)
					{
						int num = x.GetParameters().Length;
						object[] args2 = args;
						result2 = (num == ((args2 != null) ? args2.Length : 0));
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				result = ((method != null) ? method.Invoke(target, args ?? new object[0]) : null);
			}
			return result;
		}

		// Token: 0x060020EA RID: 8426 RVA: 0x000C1280 File Offset: 0x000BF480
		private static object GetProperty(object target, string propertyName)
		{
			object result;
			try
			{
				object obj;
				if (target == null)
				{
					obj = null;
				}
				else
				{
					PropertyInfo property = target.GetType().GetProperty(propertyName);
					obj = ((property != null) ? property.GetValue(target, null) : null);
				}
				result = obj;
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060020EB RID: 8427 RVA: 0x000C12CC File Offset: 0x000BF4CC
		private static bool IsSuccess(object result)
		{
			bool flag = result == null;
			bool result2;
			if (flag)
			{
				result2 = true;
			}
			else
			{
				try
				{
					result2 = (Convert.ToInt32(result) == 0);
				}
				catch
				{
					result2 = false;
				}
			}
			return result2;
		}

		// Token: 0x060020EC RID: 8428 RVA: 0x000C130C File Offset: 0x000BF50C
		private static void TryDispose(object target)
		{
			try
			{
				IDisposable disposable = target as IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x04000D96 RID: 3478
		private static readonly object SnapshotSessionsLock = new object();

		// Token: 0x04000D97 RID: 3479
		private static readonly Dictionary<string, HikLiveCameraService.HikSnapshotSession> SnapshotSessions = new Dictionary<string, HikLiveCameraService.HikSnapshotSession>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000D98 RID: 3480
		private readonly object _deviceLock = new object();

		// Token: 0x04000D99 RID: 3481
		private readonly object _latestImageLock = new object();

		// Token: 0x04000D9A RID: 3482
		private object _device;

		// Token: 0x04000D9B RID: 3483
		private object _streamGrabber;

		// Token: 0x04000D9C RID: 3484
		private CancellationTokenSource _cancellation;

		// Token: 0x04000D9D RID: 3485
		private Task _worker;

		// Token: 0x04000D9E RID: 3486
		private readonly Stopwatch _latestImageStopwatch = Stopwatch.StartNew();

		// Token: 0x04000D9F RID: 3487
		private string _cameraId;

		// Token: 0x04000DA0 RID: 3488
		private CameraParameterConfig _config;

		// Token: 0x04000DA1 RID: 3489
		private HObject _latestImage;

		// Token: 0x04000DA2 RID: 3490
		private int _displayPending;

		// Token: 0x0200049A RID: 1178
		private sealed class HikSnapshotSession : IDisposable
		{
			// Token: 0x06002CE1 RID: 11489 RVA: 0x000EBFA6 File Offset: 0x000EA1A6
			public HikSnapshotSession(string cameraId)
			{
				this._cameraId = cameraId;
			}

			// Token: 0x06002CE2 RID: 11490 RVA: 0x000EBFD0 File Offset: 0x000EA1D0
			public HObject Capture(CameraParameterConfig config)
			{
				object @lock = this._lock;
				HObject result;
				lock (@lock)
				{
					object frame = null;
					HObject image = null;
					try
					{
						this.EnsureOpen(config);
						this._service.ApplyParameter(config);
						frame = this._service.GetImageBuffer(1000U);
						bool flag2 = frame == null;
						if (flag2)
						{
							throw new InvalidOperationException("Failed to grab image from Hikvision camera.");
						}
						object sdkImage = HikLiveCameraService.GetProperty(frame, "Image");
						bool flag3 = sdkImage == null;
						if (flag3)
						{
							throw new InvalidOperationException("Hikvision frame image is empty.");
						}
						image = HikLiveCameraService.ConvertSdkImageToHalconImage(sdkImage);
						bool flag4 = image == null || !image.IsInitialized();
						if (flag4)
						{
							throw new InvalidOperationException("Failed to convert Hikvision image to HALCON image.");
						}
						HObject transformed = CameraImageTransformService.Apply(image, config);
						bool flag5 = transformed != image;
						if (flag5)
						{
							image.Dispose();
							image = null;
						}
						result = transformed;
					}
					catch
					{
						if (image != null)
						{
							image.Dispose();
						}
						this.DisposeCore();
						throw;
					}
					finally
					{
						this._service.FreeImageBuffer(frame);
					}
				}
				return result;
			}

			// Token: 0x06002CE3 RID: 11491 RVA: 0x000EC100 File Offset: 0x000EA300
			public void Warmup(CameraParameterConfig config)
			{
				object @lock = this._lock;
				lock (@lock)
				{
					this.EnsureOpen(config);
				}
			}

			// Token: 0x06002CE4 RID: 11492 RVA: 0x000EC148 File Offset: 0x000EA348
			public void Dispose()
			{
				object @lock = this._lock;
				lock (@lock)
				{
					this.DisposeCore();
				}
			}

			// Token: 0x06002CE5 RID: 11493 RVA: 0x000EC18C File Offset: 0x000EA38C
			private void EnsureOpen(CameraParameterConfig config)
			{
				bool flag = this._isOpen && this._service._device != null && this._service._streamGrabber != null && HikLiveCameraService.IsDeviceConnected(this._service._device);
				if (!flag)
				{
					this.DisposeCore();
					this._service._config = config;
					this._service._cameraId = this._cameraId;
					this._service._device = HikLiveCameraService.CreateDeviceBySerial(this._cameraId);
					bool flag2 = this._service._device == null;
					if (flag2)
					{
						throw new InvalidOperationException("Hikvision camera was not found: " + this._cameraId);
					}
					bool flag3 = !HikLiveCameraService.IsSuccess(HikLiveCameraService.InvokeMethod(this._service._device, "Open", Array.Empty<object>()));
					if (flag3)
					{
						throw new InvalidOperationException("Failed to open Hikvision camera: " + this._cameraId);
					}
					this._service._streamGrabber = HikLiveCameraService.GetProperty(this._service._device, "StreamGrabber");
					this._service.ApplyParameter(config);
					bool flag4 = !HikLiveCameraService.IsSuccess(HikLiveCameraService.InvokeMethod(this._service._streamGrabber, "StartGrabbing", Array.Empty<object>()));
					if (flag4)
					{
						throw new InvalidOperationException("Failed to start Hikvision grabbing.");
					}
					this._isOpen = true;
				}
			}

			// Token: 0x06002CE6 RID: 11494 RVA: 0x000EC2DC File Offset: 0x000EA4DC
			private void DisposeCore()
			{
				try
				{
					bool flag = this._service._streamGrabber != null;
					if (flag)
					{
						HikLiveCameraService.InvokeMethod(this._service._streamGrabber, "StopGrabbing", Array.Empty<object>());
					}
				}
				catch
				{
				}
				try
				{
					bool flag2 = this._service._device != null;
					if (flag2)
					{
						HikLiveCameraService.InvokeMethod(this._service._device, "Close", Array.Empty<object>());
					}
				}
				catch
				{
				}
				HikLiveCameraService.TryDispose(this._service._device);
				this._service._streamGrabber = null;
				this._service._device = null;
				this._service._config = null;
				this._service._cameraId = null;
				this._isOpen = false;
			}

			// Token: 0x04001660 RID: 5728
			private readonly object _lock = new object();

			// Token: 0x04001661 RID: 5729
			private readonly string _cameraId;

			// Token: 0x04001662 RID: 5730
			private readonly HikLiveCameraService _service = new HikLiveCameraService();

			// Token: 0x04001663 RID: 5731
			private bool _isOpen;
		}
	}
}
