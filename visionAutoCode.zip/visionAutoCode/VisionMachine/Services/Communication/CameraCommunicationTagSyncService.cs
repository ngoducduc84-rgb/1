﻿using System;
using System.Collections.Generic;
using System.Linq;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001FA RID: 506
	public static class CameraCommunicationTagSyncService
	{
		// Token: 0x06001DE4 RID: 7652 RVA: 0x000AAC28 File Offset: 0x000A8E28
		public static void SynchronizeCurrentModel(IEnumerable<string> cameraNames)
		{
			string configPath = CommunicationConfigStorageService.GetConfigPath();
			CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(configPath);
			bool flag = config == null || config.Connections == null || config.Connections.Count == 0;
			if (!flag)
			{
				List<string> cameras = CameraCommunicationTagSyncService.NormalizeCameraNames(cameraNames);
				Dictionary<string, List<CommunicationTagRow>> synchronizedTags = new Dictionary<string, List<CommunicationTagRow>>(StringComparer.OrdinalIgnoreCase);
				foreach (KeyValuePair<string, List<CommunicationTagRow>> entry in (config.ConnectionTags ?? new Dictionary<string, List<CommunicationTagRow>>()))
				{
					bool flag2 = !string.IsNullOrWhiteSpace(entry.Key);
					if (flag2)
					{
						synchronizedTags[entry.Key.Trim()] = CameraCommunicationTagSyncService.CloneTags(entry.Value);
					}
				}
				foreach (CommunicationConnection connection in from x in config.Connections
				where x != null
				select x)
				{
					string key = string.IsNullOrWhiteSpace(connection.Name) ? "Default" : connection.Name.Trim();
					List<CommunicationTagRow> tags;
					bool flag3 = !synchronizedTags.TryGetValue(key, out tags);
					if (flag3)
					{
						tags = new List<CommunicationTagRow>();
					}
					CameraCommunicationTagSyncService.SynchronizeTags(tags, cameras, CommunicationAddressStyles.FromProtocol(connection.Protocol));
					synchronizedTags[key] = tags;
				}
				CommunicationConfigStorageService.Save(config.Connections, synchronizedTags, config.RuntimeSettings, configPath);
			}
		}

		// Token: 0x06001DE5 RID: 7653 RVA: 0x000AADD4 File Offset: 0x000A8FD4
		public static void SynchronizeTags(IList<CommunicationTagRow> tags, IEnumerable<string> cameraNames, CommunicationAddressStyle addressStyle)
		{
			bool flag = tags == null;
			if (!flag)
			{
				List<string> cameras = CameraCommunicationTagSyncService.NormalizeCameraNames(cameraNames);
				CameraCommunicationTagSyncService.RemoveDeletedCameraTags(tags, cameras);
				for (int i = 0; i < cameras.Count; i++)
				{
					string cameraName = cameras[i];
					int baseAddress = 41000 + i * 500;
					string prefix = "camera " + cameraName;
					string triggerGroup = cameraName + " - Trigger Camera";
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " trigger snap", baseAddress, "INT16", "Read", "Robot trigger bit for camera snap.", triggerGroup, null, 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " trigger run", baseAddress + 1, "INT16", "Read", "Robot trigger bit for running selected TurnSnap.", triggerGroup, null, 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " vision busy", baseAddress + 2, "INT16", "Write", "Vision busy status for this camera.", triggerGroup, null, 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " snap complete", baseAddress + 3, "INT16", "Write", "Vision snap completed bit for this camera.", triggerGroup, null, 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " run complete", baseAddress + 4, "INT16", "Write", "Vision run completed bit for this camera.", triggerGroup, null, 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " error code", baseAddress + 5, "INT16", "Write", "Vision camera trigger error code.", triggerGroup, null, 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " connected", baseAddress + 6, "INT16", "Write", "Camera connection status written by vision: 1 = camera is connected, 0 = connection lost.", triggerGroup, null, 1, addressStyle);
					string inspectionGroup = cameraName + " - Result Vision Inspection";
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " inspection complete", baseAddress + 30, "INT16", "Write", "Vision inspection processing completed.", inspectionGroup, "Inspection.Complete", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " inspection result ok", baseAddress + 31, "INT16", "Write", "Vision inspection result: 1=OK, 0=NG.", inspectionGroup, "Inspection.ResultOk", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " inspection ng code", baseAddress + 32, "INT16", "Write", "Vision inspection NG code.", inspectionGroup, "Inspection.NgCode", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " inspection value", baseAddress + 33, "FLOAT", "Write", "Vision inspection measured value.", inspectionGroup, "Inspection.Value", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " inspection result ng", baseAddress + 37, "INT16", "Write", "Vision inspection result: 1=NG, 0=OK.", inspectionGroup, "Inspection.ResultNg", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " inspection total ok", baseAddress + 35, "INT16", "Write", "Vision inspection all tools OK bit.", inspectionGroup, "Inspection.TotalOk", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " inspection total ng", baseAddress + 36, "INT16", "Write", "Vision inspection any tool NG bit.", inspectionGroup, "Inspection.TotalNg", 1, addressStyle);
					int alignBaseAddress = baseAddress + 50;
					string alignGroup = cameraName + " - Result Vision Align";
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " align complete", alignBaseAddress, "INT16", "Write", "Vision align processing completed.", alignGroup, "Align.Complete", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " align result ok", alignBaseAddress + 1, "INT16", "Write", "Vision align result: 1=OK, 0=NG.", alignGroup, "Align.ResultOk", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " align object count", alignBaseAddress + 2, "INT16", "Write", "Number of objects detected by vision for this align result.", alignGroup, "Align.Count", 1, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " align x", alignBaseAddress + 10, "FLOAT", "Write", "Vision align robot X result list.", alignGroup, "Align.X", 100, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " align y", alignBaseAddress + 110, "FLOAT", "Write", "Vision align robot Y result list.", alignGroup, "Align.Y", 100, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " align degree", alignBaseAddress + 210, "FLOAT", "Write", "Vision align angle result list.", alignGroup, "Align.Degree", 100, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " align score", alignBaseAddress + 310, "FLOAT", "Write", "Vision align score result list.", alignGroup, "Align.Score", 100, addressStyle);
					CameraCommunicationTagSyncService.AddTag(tags, prefix + " align error code", alignBaseAddress + 410, "INT16", "Write", "Vision align error code.", alignGroup, "Align.ErrorCode", 1, addressStyle);
				}
			}
		}

		// Token: 0x06001DE6 RID: 7654 RVA: 0x000AB274 File Offset: 0x000A9474
		private static List<string> NormalizeCameraNames(IEnumerable<string> cameraNames)
		{
			return (from x in cameraNames ?? Enumerable.Empty<string>()
			where !string.IsNullOrWhiteSpace(x)
			select x.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList<string>();
		}

		// Token: 0x06001DE7 RID: 7655 RVA: 0x000AB2E8 File Offset: 0x000A94E8
		private static void RemoveDeletedCameraTags(IList<CommunicationTagRow> tags, IList<string> cameraNames)
		{
			HashSet<string> known = new HashSet<string>(cameraNames, StringComparer.OrdinalIgnoreCase);
			List<CommunicationTagRow> removed = (from x in tags
			where x != null
			select x).Where(delegate(CommunicationTagRow x)
			{
				string cameraName = CameraCommunicationTagSyncService.ExtractCameraName(x.Group, x.Name);
				return !string.IsNullOrWhiteSpace(cameraName) && !known.Contains(cameraName);
			}).ToList<CommunicationTagRow>();
			foreach (CommunicationTagRow tag in removed)
			{
				tags.Remove(tag);
			}
		}

		// Token: 0x06001DE8 RID: 7656 RVA: 0x000AB390 File Offset: 0x000A9590
		private static string ExtractCameraName(string group, string tagName)
		{
			bool flag = !string.IsNullOrWhiteSpace(group);
			if (flag)
			{
				foreach (string suffix in CameraCommunicationTagSyncService.CameraGroupSuffixes)
				{
					bool flag2 = group.EndsWith(suffix, StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						return group.Substring(0, group.Length - suffix.Length).Trim();
					}
				}
			}
			bool flag3 = string.IsNullOrWhiteSpace(tagName);
			string result;
			if (flag3)
			{
				result = null;
			}
			else
			{
				string value = tagName.Trim();
				bool flag4 = !value.StartsWith("camera ", StringComparison.OrdinalIgnoreCase);
				if (flag4)
				{
					result = null;
				}
				else
				{
					foreach (string suffix2 in from x in CameraCommunicationTagSyncService.CameraTagSuffixes
					orderby x.Length descending
					select x)
					{
						bool flag5 = !value.EndsWith(suffix2, StringComparison.OrdinalIgnoreCase);
						if (!flag5)
						{
							int length = value.Length - "camera ".Length - suffix2.Length;
							return (length > 0) ? value.Substring("camera ".Length, length).Trim() : null;
						}
					}
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001DE9 RID: 7657 RVA: 0x000AB4F0 File Offset: 0x000A96F0
		private static void AddTag(IList<CommunicationTagRow> tags, string name, int address, string dataType, string readWrite, string description, string group, string resultField, int maxResultCount, CommunicationAddressStyle addressStyle)
		{
			CommunicationTagRow existing = tags.FirstOrDefault(delegate(CommunicationTagRow x)
			{
				bool result;
				if (x != null)
				{
					string name2 = x.Name;
					result = string.Equals((name2 != null) ? name2.Trim() : null, name, StringComparison.OrdinalIgnoreCase);
				}
				else
				{
					result = false;
				}
				return result;
			});
			string defaultAddress = CommunicationAddressStyles.Format(address, addressStyle);
			bool flag = existing == null;
			if (flag)
			{
				tags.Add(new CommunicationTagRow(name, defaultAddress, dataType, readWrite, description, group)
				{
					ResultField = resultField,
					MaxResultCount = Math.Max(1, maxResultCount)
				});
			}
			else
			{
				existing.Name = name;
				bool flag2 = !string.IsNullOrWhiteSpace(defaultAddress) && (string.IsNullOrWhiteSpace(existing.Address) || !CommunicationAddressStyles.Matches(existing.Address, addressStyle));
				if (flag2)
				{
					existing.Address = defaultAddress;
				}
				bool flag3 = string.IsNullOrWhiteSpace(existing.DataType);
				if (flag3)
				{
					existing.DataType = dataType;
				}
				bool flag4 = string.IsNullOrWhiteSpace(existing.ReadWrite);
				if (flag4)
				{
					existing.ReadWrite = readWrite;
				}
				bool flag5 = string.IsNullOrWhiteSpace(existing.Description);
				if (flag5)
				{
					existing.Description = description;
				}
				bool flag6 = string.IsNullOrWhiteSpace(existing.Group);
				if (flag6)
				{
					existing.Group = group;
				}
				bool flag7 = string.IsNullOrWhiteSpace(existing.ResultField);
				if (flag7)
				{
					existing.ResultField = resultField;
				}
				bool flag8 = existing.MaxResultCount <= 0;
				if (flag8)
				{
					existing.MaxResultCount = Math.Max(1, maxResultCount);
				}
			}
		}

		// Token: 0x06001DEA RID: 7658 RVA: 0x000AB654 File Offset: 0x000A9854
		private static List<CommunicationTagRow> CloneTags(IEnumerable<CommunicationTagRow> source)
		{
			return (from x in source ?? Enumerable.Empty<CommunicationTagRow>()
			where x != null
			select new CommunicationTagRow
			{
				Group = x.Group,
				Name = x.Name,
				Address = x.Address,
				DataType = x.DataType,
				ReadWrite = x.ReadWrite,
				LinkedToolName = x.LinkedToolName,
				ResultField = x.ResultField,
				MaxResultCount = x.MaxResultCount,
				Description = x.Description
			}).ToList<CommunicationTagRow>();
		}

		// Token: 0x04000C9F RID: 3231
		private const string OpcUaProtocol = "OPC UA";

		// Token: 0x04000CA0 RID: 3232
		private static readonly string[] CameraGroupSuffixes = new string[]
		{
			" - Trigger Camera",
			" - Result Vision Align",
			" - Result Vision Inspection"
		};

		// Token: 0x04000CA1 RID: 3233
		private static readonly string[] CameraTagSuffixes = new string[]
		{
			" trigger snap",
			" trigger run",
			" connected",
			" vision busy",
			" snap complete",
			" run complete",
			" error code",
			" align complete",
			" align result ok",
			" align object count",
			" align x",
			" align y",
			" align degree",
			" align score",
			" align error code",
			" inspection complete",
			" inspection result ok",
			" inspection result ng",
			" inspection ng code",
			" inspection value",
			" inspection total ok",
			" inspection total ng"
		};
	}
}
