﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Communication;
using VisionMachine.Services.Camera;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Home;
using VisionMachine.Views.Main;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F9 RID: 505
	public static class CameraTriggerCommunicationService
	{
		// Token: 0x14000032 RID: 50
		// (add) Token: 0x06001DB7 RID: 7607 RVA: 0x000A8528 File Offset: 0x000A6728
		// (remove) Token: 0x06001DB8 RID: 7608 RVA: 0x000A855C File Offset: 0x000A675C
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler<CameraTriggerEventArgs> CameraTriggered;

		// Token: 0x14000033 RID: 51
		// (add) Token: 0x06001DB9 RID: 7609 RVA: 0x000A8590 File Offset: 0x000A6790
		// (remove) Token: 0x06001DBA RID: 7610 RVA: 0x000A85C4 File Offset: 0x000A67C4
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler<CameraTriggerDiagnosticEventArgs> DiagnosticLogged;

		// Token: 0x06001DBB RID: 7611 RVA: 0x000A85F8 File Offset: 0x000A67F8
		public static bool IsActiveConnectionConnected()
		{
			object syncRoot = CameraTriggerCommunicationService.SyncRoot;
			CommunicationConnection activeConnection;
			bool activeConnectionHealthy;
			lock (syncRoot)
			{
				activeConnection = CameraTriggerCommunicationService._activeConnection;
				activeConnectionHealthy = CameraTriggerCommunicationService._activeConnectionHealthy;
			}
			bool flag2 = activeConnection != null && activeConnectionHealthy && CameraTriggerCommunicationService.IsConnectionReportedHealthy(activeConnection);
			bool result;
			if (flag2)
			{
				result = true;
			}
			else
			{
				CommunicationConnection configuredConnection = CameraTriggerCommunicationService.GetConfiguredCameraTriggerConnection();
				bool flag3 = configuredConnection != null && CameraTriggerCommunicationService.IsConnectionReportedHealthy(configuredConnection);
				result = (flag3 || CameraTriggerCommunicationService.IsAnyConfiguredConnectionConnected());
			}
			return result;
		}

		// Token: 0x06001DBC RID: 7612 RVA: 0x000A868C File Offset: 0x000A688C
		private static bool IsConnectionReportedHealthy(CommunicationConnection connection)
		{
			bool flag = connection == null || !CameraTriggerCommunicationService.CommunicationService.IsConnected(connection);
			CommunicationHealthState healthState;
			return !flag && (!CommunicationStartupService.TryGetConnectionHealth(connection.Name, out healthState) || healthState.IsConnected);
		}

		// Token: 0x06001DBD RID: 7613 RVA: 0x000A86D4 File Offset: 0x000A68D4
		private static bool IsAnyConfiguredConnectionConnected()
		{
			return CameraTriggerCommunicationService.GetFirstConnectedConnectionName() != null;
		}

		// Token: 0x06001DBE RID: 7614 RVA: 0x000A86F0 File Offset: 0x000A68F0
		private static string GetFirstConnectedConnectionName()
		{
			try
			{
				CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(null);
				foreach (CommunicationConnection connection in (config.Connections ?? new List<CommunicationConnection>()))
				{
					bool flag = connection != null && !string.IsNullOrWhiteSpace(connection.Name) && CameraTriggerCommunicationService.IsConnectionReportedHealthy(connection);
					if (flag)
					{
						return connection.Name;
					}
				}
			}
			catch
			{
			}
			return null;
		}

		// Token: 0x06001DBF RID: 7615 RVA: 0x000A8798 File Offset: 0x000A6998
		public static string GetActiveConnectionName()
		{
			object syncRoot = CameraTriggerCommunicationService.SyncRoot;
			lock (syncRoot)
			{
				CommunicationConnection activeConnection = CameraTriggerCommunicationService._activeConnection;
				bool flag2 = !string.IsNullOrWhiteSpace((activeConnection != null) ? activeConnection.Name : null);
				if (flag2)
				{
					return CameraTriggerCommunicationService._activeConnection.Name;
				}
			}
			CommunicationConnection configuredCameraTriggerConnection = CameraTriggerCommunicationService.GetConfiguredCameraTriggerConnection();
			string configuredName = (configuredCameraTriggerConnection != null) ? configuredCameraTriggerConnection.Name : null;
			bool flag3 = !string.IsNullOrWhiteSpace(configuredName);
			string result;
			if (flag3)
			{
				result = configuredName;
			}
			else
			{
				result = CameraTriggerCommunicationService.GetFirstConnectedConnectionName();
			}
			return result;
		}

		// Token: 0x06001DC0 RID: 7616 RVA: 0x000A8834 File Offset: 0x000A6A34
		public static bool IsActiveConnectionHealthyState()
		{
			object syncRoot = CameraTriggerCommunicationService.SyncRoot;
			bool activeConnectionHealthy;
			lock (syncRoot)
			{
				activeConnectionHealthy = CameraTriggerCommunicationService._activeConnectionHealthy;
			}
			return activeConnectionHealthy;
		}

		// Token: 0x06001DC1 RID: 7617 RVA: 0x000A8878 File Offset: 0x000A6A78
		private static bool IsActiveConnectionHealthy()
		{
			object syncRoot = CameraTriggerCommunicationService.SyncRoot;
			bool activeConnectionHealthy;
			lock (syncRoot)
			{
				activeConnectionHealthy = CameraTriggerCommunicationService._activeConnectionHealthy;
			}
			return activeConnectionHealthy;
		}

		// Token: 0x06001DC2 RID: 7618 RVA: 0x000A88BC File Offset: 0x000A6ABC
		private static CommunicationConnection GetConfiguredCameraTriggerConnection()
		{
			CommunicationConnection result;
			try
			{
				CameraTriggerCommunicationService.<>c__DisplayClass23_0 CS$<>8__locals1 = new CameraTriggerCommunicationService.<>c__DisplayClass23_0();
				CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(null);
				CameraTriggerCommunicationService.<>c__DisplayClass23_0 CS$<>8__locals2 = CS$<>8__locals1;
				CommunicationRuntimeSettings runtimeSettings = config.RuntimeSettings;
				CS$<>8__locals2.connectionName = ((runtimeSettings != null) ? runtimeSettings.CameraTriggerConnectionName : null);
				bool flag = string.IsNullOrWhiteSpace(CS$<>8__locals1.connectionName) || string.Equals(CS$<>8__locals1.connectionName, "None", StringComparison.OrdinalIgnoreCase);
				if (flag)
				{
					result = null;
				}
				else
				{
					result = (config.Connections ?? new List<CommunicationConnection>()).FirstOrDefault((CommunicationConnection x) => string.Equals(x.Name, CS$<>8__locals1.connectionName, StringComparison.OrdinalIgnoreCase));
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06001DC3 RID: 7619 RVA: 0x000A8954 File Offset: 0x000A6B54
		public static void StartCurrentModel(string configPath = null, bool forceRestart = false)
		{
			configPath = (string.IsNullOrWhiteSpace(configPath) ? CommunicationConfigStorageService.GetConfigPath() : configPath);
			object syncRoot = CameraTriggerCommunicationService.SyncRoot;
			bool flag = false;
			try
			{
				Monitor.Enter(syncRoot, ref flag);
				bool flag2 = !forceRestart && CameraTriggerCommunicationService._pollTask != null && !CameraTriggerCommunicationService._pollTask.IsCompleted && string.Equals(CameraTriggerCommunicationService._activeConfigPath, configPath, StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					CameraTriggerCommunicationService.RaiseDiagnostic("Info", "Camera trigger watcher is already running. Config=" + configPath);
				}
				else
				{
					CameraTriggerCommunicationService.StopLocked();
					CameraTriggerCommunicationService._activeConfigPath = configPath;
					CameraTriggerCommunicationService._activeConnection = null;
					CameraTriggerCommunicationService._activeConnectionHealthy = false;
					CancellationTokenSource cancellation = new CancellationTokenSource();
					CancellationToken cancellationToken = cancellation.Token;
					CameraTriggerCommunicationService._cancellation = cancellation;
					CameraTriggerCommunicationService.RaiseDiagnostic("Info", "Camera trigger watcher starting. Config=" + configPath);
					CameraTriggerCommunicationService._pollTask = Task.Run(delegate()
					{
						CameraTriggerCommunicationService.PollLoop(configPath, cancellationToken);
					}, cancellationToken);
				}
			}
			finally
			{
				if (flag)
				{
					Monitor.Exit(syncRoot);
				}
			}
		}

		// Token: 0x06001DC4 RID: 7620 RVA: 0x000A8AA0 File Offset: 0x000A6CA0
		public static void Stop()
		{
			object syncRoot = CameraTriggerCommunicationService.SyncRoot;
			lock (syncRoot)
			{
				CameraTriggerCommunicationService.StopLocked();
			}
		}

		// Token: 0x06001DC5 RID: 7621 RVA: 0x000A8AE4 File Offset: 0x000A6CE4
		private static void StopLocked()
		{
			CancellationTokenSource cancellation = CameraTriggerCommunicationService._cancellation;
			Task task = CameraTriggerCommunicationService._pollTask;
			try
			{
				CancellationTokenSource cancellation2 = cancellation;
				if (cancellation2 != null)
				{
					cancellation2.Cancel();
				}
			}
			catch
			{
			}
			bool flag = cancellation != null;
			if (flag)
			{
				bool flag2 = task == null || task.IsCompleted;
				if (flag2)
				{
					try
					{
						cancellation.Dispose();
					}
					catch
					{
					}
				}
				else
				{
					task.ContinueWith(delegate(Task _)
					{
						try
						{
							cancellation.Dispose();
						}
						catch
						{
						}
					}, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
				}
			}
			CameraTriggerCommunicationService._cancellation = null;
			CameraTriggerCommunicationService._pollTask = null;
			CameraTriggerCommunicationService._activeConfigPath = null;
			CameraTriggerCommunicationService._activeConnection = null;
			CameraTriggerCommunicationService._activeConnectionHealthy = false;
		}

		// Token: 0x06001DC6 RID: 7622 RVA: 0x000A8BBC File Offset: 0x000A6DBC
		private static void PollLoop(string configPath, CancellationToken cancellationToken)
		{
			try
			{
				CameraTriggerCommunicationService.PollLoopCore(configPath, cancellationToken);
			}
			catch (OperationCanceledException)
			{
			}
			catch (Exception ex)
			{
				CameraTriggerCommunicationService.RaiseDiagnostic("Error", "Camera trigger watcher stopped by error: " + ex.Message);
			}
		}

		// Token: 0x06001DC7 RID: 7623 RVA: 0x000A8C18 File Offset: 0x000A6E18
		private static void PollLoopCore(string configPath, CancellationToken cancellationToken)
		{
			CameraTriggerCommunicationService.<>c__DisplayClass28_0 CS$<>8__locals1 = new CameraTriggerCommunicationService.<>c__DisplayClass28_0();
			CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(configPath);
			CameraTriggerCommunicationService.<>c__DisplayClass28_0 CS$<>8__locals2 = CS$<>8__locals1;
			CommunicationRuntimeSettings runtimeSettings = config.RuntimeSettings;
			CS$<>8__locals2.triggerConnectionName = ((runtimeSettings != null) ? runtimeSettings.CameraTriggerConnectionName : null);
			bool hasDesignatedName = !string.IsNullOrWhiteSpace(CS$<>8__locals1.triggerConnectionName) && !string.Equals(CS$<>8__locals1.triggerConnectionName, "None", StringComparison.OrdinalIgnoreCase);
			CommunicationConnection connection = hasDesignatedName ? (config.Connections ?? new List<CommunicationConnection>()).FirstOrDefault((CommunicationConnection x) => CameraTriggerCommunicationService.IsSupportedTriggerConnection(x) && string.Equals(x.Name, CS$<>8__locals1.triggerConnectionName, StringComparison.OrdinalIgnoreCase)) : null;
			bool flag = hasDesignatedName && connection == null;
			if (flag)
			{
				CameraTriggerCommunicationService.RaiseDiagnostic("Warn", "Selected camera trigger connection was not found or is not a supported trigger protocol (Modbus Client TCP/IP or OPC UA): " + CS$<>8__locals1.triggerConnectionName);
			}
			else
			{
				bool flag2 = connection == null;
				if (flag2)
				{
					connection = CameraTriggerCommunicationService.FindFallbackTriggerConnection(config);
					bool flag3 = connection == null;
					if (flag3)
					{
						CameraTriggerCommunicationService.RaiseDiagnostic("Warn", "Camera trigger connection is not selected in Communication, and no connection with camera trigger snap tags was found to use automatically.");
						return;
					}
					CameraTriggerCommunicationService.RaiseDiagnostic("Info", "No camera trigger connection was selected; automatically using '" + connection.Name + "' because it has camera trigger snap tags. (You can pin it in Communication > Vision Trigger Camera Connection.)");
				}
				List<CommunicationTagRow> connectionTags = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name);
				List<CameraTriggerCommunicationService.CameraTriggerDefinition> triggers = CameraTriggerCommunicationService.BuildTriggerDefinitions(connectionTags);
				bool flag4 = triggers.Count == 0;
				if (flag4)
				{
					CameraTriggerCommunicationService.RaiseDiagnostic("Warn", "No camera trigger snap tags were found in Communication Tag Management.");
				}
				else
				{
					bool flag5 = triggers.All((CameraTriggerCommunicationService.CameraTriggerDefinition x) => x.SnapTag == null);
					if (flag5)
					{
						CameraTriggerCommunicationService.RaiseDiagnostic("Info", "Every camera trigger snap tag is set to None, so no software trigger is watched on this connection. The other camera tags still work.");
					}
					CameraTriggerCommunicationService.NormalizeConnection(connection);
					object syncRoot = CameraTriggerCommunicationService.SyncRoot;
					lock (syncRoot)
					{
						CameraTriggerCommunicationService._activeConnection = connection;
						CameraTriggerCommunicationService._activeConnectionHealthy = false;
					}
					CommunicationOperationResult connectResult = CameraTriggerCommunicationService.CommunicationService.ConnectIfDisconnected(connection);
					bool flag7 = !connectResult.Success;
					if (flag7)
					{
						CameraTriggerCommunicationService.SetActiveConnectionHealthy(false, connectResult.Message, true);
						CameraTriggerCommunicationService.RaiseDiagnostic("Error", "Camera trigger PLC connect failed: " + connectResult.Message);
					}
					else
					{
						CameraTriggerCommunicationService.SetActiveConnectionHealthy(true, "Connected.", true);
						CameraTriggerCommunicationService.RaiseDiagnostic("Info", string.Concat(new string[]
						{
							"Camera trigger PLC connected: ",
							connection.Name,
							" (",
							connection.IpAddress,
							":",
							connection.Port.ToString(),
							")"
						}));
					}
					int pollIntervalMs = CameraTriggerCommunicationService.GetPollInterval(connection);
					CameraTriggerCommunicationService.RaiseDiagnostic("Info", string.Concat(new string[]
					{
						"Camera trigger watcher ready. Connection=",
						connection.Name,
						", Camera trigger count=",
						triggers.Count.ToString(),
						", Poll=",
						pollIntervalMs.ToString(),
						" ms"
					}));
					foreach (CameraTriggerCommunicationService.CameraTriggerDefinition trigger in triggers)
					{
						string level = "Info";
						string[] array = new string[5];
						array[0] = "Watching camera '";
						array[1] = trigger.CameraName;
						array[2] = "' snap tag @";
						int num = 3;
						CommunicationTagRow snapTag = trigger.SnapTag;
						array[num] = (((snapTag != null) ? snapTag.Address : null) ?? "?");
						array[4] = ((trigger.RunTag != null) ? (", run tag @" + trigger.RunTag.Address) : ", no run tag (defaults to TurnSnap 1)");
						CameraTriggerCommunicationService.RaiseDiagnostic(level, string.Concat(array));
					}
					bool hasConnectedTags = triggers.Any((CameraTriggerCommunicationService.CameraTriggerDefinition x) => x.ConnectedTag != null && CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(x.ConnectedTag.Address));
					bool flag8 = hasConnectedTags;
					if (flag8)
					{
						CameraConnectionMonitorService.EnsureStarted();
						foreach (CameraTriggerCommunicationService.CameraTriggerDefinition trigger2 in from x in triggers
						where x.ConnectedTag != null && CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(x.ConnectedTag.Address)
						select x)
						{
							CameraTriggerCommunicationService.RaiseDiagnostic("Info", string.Concat(new string[]
							{
								"Reporting connection state of camera '",
								trigger2.CameraName,
								"' to @",
								trigger2.ConnectedTag.Address,
								" (1=connected, 0=lost)."
							}));
						}
					}
					Dictionary<string, bool?> lastSnapValues = triggers.ToDictionary((CameraTriggerCommunicationService.CameraTriggerDefinition x) => x.CameraName, (CameraTriggerCommunicationService.CameraTriggerDefinition x) => null, StringComparer.OrdinalIgnoreCase);
					Dictionary<string, int> lastConnectedWritten = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
					Dictionary<string, string> lastWriteErrors = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
					Stopwatch connectedRefresh = Stopwatch.StartNew();
					Dictionary<string, string> lastReadErrors = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
					HashSet<string> loggedFirstRead = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
					HashSet<string> loggedFirstReadOk = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
					Stopwatch heartbeat = Stopwatch.StartNew();
					bool connectionFailureLogged = !connectResult.Success;
					while (!cancellationToken.IsCancellationRequested)
					{
						bool flag9 = !CameraTriggerCommunicationService.CommunicationService.IsConnected(connection);
						if (flag9)
						{
							CameraTriggerCommunicationService.SetActiveConnectionHealthy(false, null, false);
							CommunicationOperationResult reconnect = CameraTriggerCommunicationService.CommunicationService.ConnectIfDisconnected(CameraTriggerCommunicationService.CloneConnectionWithTimeout(connection, 500));
							bool flag10 = !reconnect.Success;
							if (flag10)
							{
								bool flag11 = !connectionFailureLogged;
								if (flag11)
								{
									connectionFailureLogged = true;
									CameraTriggerCommunicationService.RaiseDiagnostic("Warn", "Camera trigger connection is not ready; reconnecting in background: " + reconnect.Message);
								}
								bool flag12 = cancellationToken.WaitHandle.WaitOne(Math.Max(250, pollIntervalMs));
								if (flag12)
								{
									break;
								}
								continue;
							}
							else
							{
								bool validated = CameraTriggerCommunicationService.ReadOneSnapTagForConnectionHealth(triggers, connection, lastReadErrors);
								bool flag13 = !validated;
								if (flag13)
								{
									CameraTriggerCommunicationService.CommunicationService.Disconnect(connection);
									CameraTriggerCommunicationService.SetActiveConnectionHealthy(false, "Trigger connection reconnect validation failed.", true);
									bool flag14 = cancellationToken.WaitHandle.WaitOne(Math.Max(250, pollIntervalMs));
									if (flag14)
									{
										break;
									}
									continue;
								}
								else
								{
									bool flag15 = connectionFailureLogged;
									if (flag15)
									{
										CameraTriggerCommunicationService.RaiseDiagnostic("Info", string.Concat(new string[]
										{
											"Camera trigger PLC connected: ",
											connection.Name,
											" (",
											connection.IpAddress,
											":",
											connection.Port.ToString(),
											")"
										}));
									}
									connectionFailureLogged = false;
									lastReadErrors.Clear();
									loggedFirstRead.Clear();
								}
							}
						}
						bool hasSoftwareTrigger = triggers.Any((CameraTriggerCommunicationService.CameraTriggerDefinition x) => x.SnapTag != null && !CameraTriggerCommunicationService.IsHardwareTriggerEnabled(x.CameraName));
						bool flag16 = !hasSoftwareTrigger;
						if (flag16)
						{
							CameraTriggerCommunicationService.ReadOneSnapTagForConnectionHealth(triggers, connection, lastReadErrors);
						}
						foreach (CameraTriggerCommunicationService.CameraTriggerDefinition trigger3 in triggers)
						{
							bool isCancellationRequested = cancellationToken.IsCancellationRequested;
							if (isCancellationRequested)
							{
								break;
							}
							bool flag17 = trigger3.SnapTag == null || CameraTriggerCommunicationService.IsHardwareTriggerEnabled(trigger3.CameraName);
							if (flag17)
							{
								lastSnapValues[trigger3.CameraName] = null;
							}
							else
							{
								string rawValue;
								string quality;
								string readAddress;
								string readError;
								bool readOk = CameraTriggerCommunicationService.TryReadRawFlexible(connection, trigger3.SnapTag, false, out rawValue, out quality, out readAddress, out readError);
								bool flag18 = !readOk;
								if (flag18)
								{
									bool flag19 = loggedFirstRead.Add(trigger3.CameraName);
									if (flag19)
									{
										string level2 = "Warn";
										string[] array2 = new string[7];
										array2[0] = "Camera '";
										array2[1] = trigger3.CameraName;
										array2[2] = "' snap tag @";
										int num2 = 3;
										CommunicationTagRow snapTag2 = trigger3.SnapTag;
										array2[num2] = (((snapTag2 != null) ? snapTag2.Address : null) ?? "?");
										array2[4] = " FIRST READ FAILED: ";
										array2[5] = (readError ?? "unknown error");
										array2[6] = " (check the PLC/OPC server actually serves this address/NodeId).";
										CameraTriggerCommunicationService.RaiseDiagnostic(level2, string.Concat(array2));
									}
									Dictionary<string, string> errors = lastReadErrors;
									CommunicationTagRow snapTag3 = trigger3.SnapTag;
									CameraTriggerCommunicationService.LogReadErrorOnce(errors, (snapTag3 != null) ? snapTag3.Name : null, readError);
								}
								else
								{
									bool snapValue = CameraTriggerCommunicationService.IsTrue(rawValue);
									bool flag20 = loggedFirstReadOk.Add(trigger3.CameraName);
									if (flag20)
									{
										string level3 = "Info";
										string[] array3 = new string[11];
										array3[0] = "Camera '";
										array3[1] = trigger3.CameraName;
										array3[2] = "' snap tag @";
										int num3 = 3;
										string text;
										if ((text = readAddress) == null)
										{
											CommunicationTagRow snapTag4 = trigger3.SnapTag;
											text = (((snapTag4 != null) ? snapTag4.Address : null) ?? "?");
										}
										array3[num3] = text;
										array3[4] = " first read OK: value='";
										array3[5] = (rawValue ?? string.Empty);
										array3[6] = "', quality=";
										array3[7] = (quality ?? "?");
										array3[8] = " -> interpreted as ";
										array3[9] = (snapValue ? "TRUE" : "FALSE");
										array3[10] = (snapValue ? " (already high; waiting for it to go low then high to trigger)." : " (waiting for false->true rising edge to trigger).");
										CameraTriggerCommunicationService.RaiseDiagnostic(level3, string.Concat(array3));
									}
									Dictionary<string, string> errors2 = lastReadErrors;
									CommunicationTagRow snapTag5 = trigger3.SnapTag;
									CameraTriggerCommunicationService.ClearReadError(errors2, (snapTag5 != null) ? snapTag5.Name : null);
									bool? lastSnap;
									lastSnapValues.TryGetValue(trigger3.CameraName, out lastSnap);
									bool flag21 = lastSnap == null;
									if (flag21)
									{
										lastSnapValues[trigger3.CameraName] = new bool?(snapValue);
										bool flag22 = snapValue;
										if (flag22)
										{
											CameraTriggerCommunicationService.RaiseDiagnostic("Info", "Camera '" + trigger3.CameraName + "' snap tag is ALREADY high at start-up; ignored. It must go low and high again to trigger.");
										}
									}
									else
									{
										bool flag23 = snapValue != lastSnap.Value;
										if (flag23)
										{
											CameraTriggerCommunicationService.RaiseDiagnostic("Info", string.Concat(new string[]
											{
												"Camera '",
												trigger3.CameraName,
												"' snap changed ",
												lastSnap.Value ? "TRUE" : "FALSE",
												" -> ",
												snapValue ? "TRUE" : "FALSE",
												" (value='",
												rawValue ?? string.Empty,
												"')."
											}));
										}
										bool flag24 = snapValue && !lastSnap.Value;
										if (flag24)
										{
											int turnSnapIndex = 0;
											bool flag25 = trigger3.RunTag != null;
											if (flag25)
											{
												int runValue;
												bool flag26 = CameraTriggerCommunicationService.ReadIntTagFlexible(connection, trigger3.RunTag, out runValue, out readError);
												if (flag26)
												{
													turnSnapIndex = Math.Max(0, runValue);
												}
												else
												{
													CameraTriggerCommunicationService.LogReadErrorOnce(lastReadErrors, trigger3.RunTag.Name, readError);
												}
											}
											bool isCancellationRequested2 = cancellationToken.IsCancellationRequested;
											if (isCancellationRequested2)
											{
												break;
											}
											CameraTriggerCommunicationService.RaiseDiagnostic("Trigger", string.Concat(new string[]
											{
												"Camera trigger detected. Camera=",
												trigger3.CameraName,
												", TriggerRun=",
												turnSnapIndex.ToString(),
												" -> TurnSnap ",
												(turnSnapIndex + 1).ToString()
											}));
											CameraTriggerCommunicationService.RaiseCameraTriggered(trigger3.CameraName, turnSnapIndex);
										}
										lastSnapValues[trigger3.CameraName] = new bool?(snapValue);
									}
								}
							}
						}
						bool flag27 = hasConnectedTags;
						if (flag27)
						{
							bool forceRewrite = connectedRefresh.ElapsedMilliseconds >= 5000L;
							bool flag28 = forceRewrite;
							if (flag28)
							{
								connectedRefresh.Restart();
							}
							CameraTriggerCommunicationService.PublishCameraConnectionStates(connection, triggers, lastConnectedWritten, lastWriteErrors, forceRewrite);
						}
						bool flag29 = heartbeat.ElapsedMilliseconds >= 5000L;
						if (flag29)
						{
							heartbeat.Restart();
							bool flag30 = !CameraTriggerCommunicationService.CommunicationService.IsConnected(connection) || !CameraTriggerCommunicationService.IsActiveConnectionHealthy();
							if (flag30)
							{
								CameraTriggerCommunicationService.CommunicationService.Disconnect(connection);
								CommunicationOperationResult reconnect2 = CameraTriggerCommunicationService.CommunicationService.ConnectIfDisconnected(CameraTriggerCommunicationService.CloneConnectionWithTimeout(connection, 500));
								bool success = reconnect2.Success;
								if (success)
								{
									bool validated2 = CameraTriggerCommunicationService.ReadOneSnapTagForConnectionHealth(triggers, connection, lastReadErrors);
									bool flag31 = validated2;
									if (flag31)
									{
										CameraTriggerCommunicationService.RaiseDiagnostic("Info", "Trigger connection reconnected and validated: " + connection.Name);
									}
									else
									{
										CameraTriggerCommunicationService.CommunicationService.Disconnect(connection);
										CameraTriggerCommunicationService.SetActiveConnectionHealthy(false, "Trigger connection reconnect validation failed.", true);
										CameraTriggerCommunicationService.RaiseDiagnostic("Warn", "Trigger connection reconnect validation failed: " + connection.Name);
									}
								}
								else
								{
									CameraTriggerCommunicationService.SetActiveConnectionHealthy(false, reconnect2.Message, true);
									CameraTriggerCommunicationService.RaiseDiagnostic("Warn", "Trigger connection lost; reconnect failed: " + reconnect2.Message);
								}
							}
						}
						bool flag32 = cancellationToken.WaitHandle.WaitOne(pollIntervalMs);
						if (flag32)
						{
							break;
						}
					}
					bool flag33 = hasConnectedTags;
					if (flag33)
					{
						CameraTriggerCommunicationService.WriteCameraConnectionZero(connection, triggers);
					}
				}
			}
		}

		// Token: 0x06001DC8 RID: 7624 RVA: 0x000A98E8 File Offset: 0x000A7AE8
		private static void PublishCameraConnectionStates(CommunicationConnection connection, IEnumerable<CameraTriggerCommunicationService.CameraTriggerDefinition> triggers, Dictionary<string, int> lastWritten, Dictionary<string, string> writeErrors, bool forceRewrite)
		{
			foreach (CameraTriggerCommunicationService.CameraTriggerDefinition trigger in (triggers ?? Enumerable.Empty<CameraTriggerCommunicationService.CameraTriggerDefinition>()))
			{
				CommunicationTagRow tag = (trigger != null) ? trigger.ConnectedTag : null;
				bool flag = tag == null || !CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(tag.Address);
				if (!flag)
				{
					bool isConnected;
					bool flag2 = !CameraConnectionMonitorService.TryGetConnected(trigger.CameraName, out isConnected);
					if (!flag2)
					{
						int value = isConnected ? 1 : 0;
						int previous;
						bool known = lastWritten.TryGetValue(trigger.CameraName, out previous);
						bool flag3 = known && previous == value && !forceRewrite;
						if (!flag3)
						{
							CommunicationOperationResult result = CameraTriggerCommunicationService.CommunicationService.Write(connection, tag.Address.Trim(), string.IsNullOrWhiteSpace(tag.DataType) ? "INT16" : tag.DataType.Trim(), value.ToString(CultureInfo.InvariantCulture));
							bool flag4 = !result.Success;
							if (flag4)
							{
								CameraTriggerCommunicationService.LogReadErrorOnce(writeErrors, tag.Name, string.Concat(new string[]
								{
									"Writing camera connection state of '",
									trigger.CameraName,
									"' to @",
									tag.Address,
									" failed: ",
									result.Message
								}));
							}
							else
							{
								CameraTriggerCommunicationService.ClearReadError(writeErrors, tag.Name);
								lastWritten[trigger.CameraName] = value;
								bool flag5 = !known || previous != value;
								if (flag5)
								{
									CameraTriggerCommunicationService.RaiseDiagnostic(isConnected ? "Info" : "Warn", string.Concat(new string[]
									{
										"Camera '",
										trigger.CameraName,
										"' is ",
										isConnected ? "CONNECTED" : "DISCONNECTED",
										"; wrote ",
										value.ToString(),
										" to @",
										tag.Address,
										"."
									}));
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001DC9 RID: 7625 RVA: 0x000A9B18 File Offset: 0x000A7D18
		private static void WriteCameraConnectionZero(CommunicationConnection connection, IEnumerable<CameraTriggerCommunicationService.CameraTriggerDefinition> triggers)
		{
			foreach (CameraTriggerCommunicationService.CameraTriggerDefinition trigger in (triggers ?? Enumerable.Empty<CameraTriggerCommunicationService.CameraTriggerDefinition>()))
			{
				CommunicationTagRow tag = (trigger != null) ? trigger.ConnectedTag : null;
				bool flag = tag == null || !CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(tag.Address);
				if (!flag)
				{
					try
					{
						CameraTriggerCommunicationService.CommunicationService.Write(connection, tag.Address.Trim(), string.IsNullOrWhiteSpace(tag.DataType) ? "INT16" : tag.DataType.Trim(), "0");
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x06001DCA RID: 7626 RVA: 0x000A9BE0 File Offset: 0x000A7DE0
		private static bool ReadOneSnapTagForConnectionHealth(IEnumerable<CameraTriggerCommunicationService.CameraTriggerDefinition> triggers, CommunicationConnection connection, Dictionary<string, string> lastReadErrors)
		{
			CameraTriggerCommunicationService.CameraTriggerDefinition trigger = (triggers ?? Enumerable.Empty<CameraTriggerCommunicationService.CameraTriggerDefinition>()).FirstOrDefault((CameraTriggerCommunicationService.CameraTriggerDefinition x) => x != null && x.SnapTag != null);
			bool flag = trigger == null;
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				string rawValue;
				string quality;
				string readAddress;
				string readError;
				bool readOk = CameraTriggerCommunicationService.TryReadRawFlexible(connection, trigger.SnapTag, false, out rawValue, out quality, out readAddress, out readError);
				bool flag2 = readOk;
				if (flag2)
				{
					CameraTriggerCommunicationService.ClearReadError(lastReadErrors, trigger.SnapTag.Name);
					result = true;
				}
				else
				{
					CameraTriggerCommunicationService.LogReadErrorOnce(lastReadErrors, trigger.SnapTag.Name, readError);
					bool flag3 = !CameraTriggerCommunicationService.IsTransportFailure(readError);
					if (flag3)
					{
						CameraTriggerCommunicationService.SetActiveConnectionHealthy(true, "Connected. Trigger tag read returned non-transport error: " + (readError ?? string.Empty), false);
						result = true;
					}
					else
					{
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x06001DCB RID: 7627 RVA: 0x000A9CB4 File Offset: 0x000A7EB4
		private static List<CameraTriggerCommunicationService.CameraTriggerDefinition> BuildTriggerDefinitions(IEnumerable<CommunicationTagRow> tags)
		{
			List<CommunicationTagRow> list = (from x in tags ?? Enumerable.Empty<CommunicationTagRow>()
			where x != null && !string.IsNullOrWhiteSpace(x.Name)
			select x).ToList<CommunicationTagRow>();
			List<CommunicationTagRow> snapTags = (from x in list
			where CameraTriggerCommunicationService.NormalizeName(x.Name).EndsWith("triggersnap", StringComparison.OrdinalIgnoreCase)
			select x).ToList<CommunicationTagRow>();
			List<CameraTriggerCommunicationService.CameraTriggerDefinition> definitions = new List<CameraTriggerCommunicationService.CameraTriggerDefinition>();
			foreach (CommunicationTagRow snapTag in snapTags)
			{
				string cameraName = CameraTriggerCommunicationService.ExtractCameraNameFromTriggerTag(snapTag.Name, "trigger snap");
				bool flag = string.IsNullOrWhiteSpace(cameraName);
				if (!flag)
				{
					CommunicationTagRow runTag = list.FirstOrDefault((CommunicationTagRow x) => string.Equals(CameraTriggerCommunicationService.NormalizeName(x.Name), CameraTriggerCommunicationService.NormalizeName("camera " + cameraName + " trigger run"), StringComparison.OrdinalIgnoreCase) && CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(x.Address));
					CommunicationTagRow connectedTag = list.FirstOrDefault((CommunicationTagRow x) => string.Equals(CameraTriggerCommunicationService.NormalizeName(x.Name), CameraTriggerCommunicationService.NormalizeName("camera " + cameraName + " connected"), StringComparison.OrdinalIgnoreCase));
					definitions.Add(new CameraTriggerCommunicationService.CameraTriggerDefinition
					{
						CameraName = cameraName,
						SnapTag = (CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(snapTag.Address) ? snapTag : null),
						RunTag = runTag,
						ConnectedTag = connectedTag
					});
				}
			}
			return definitions;
		}

		// Token: 0x06001DCC RID: 7628 RVA: 0x000A9E18 File Offset: 0x000A8018
		private static bool IsHardwareTriggerEnabled(string cameraName)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraName);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				MainWindow instance = MainWindow.instance;
				ObservableCollection<CameraNode> observableCollection;
				if (instance == null)
				{
					observableCollection = null;
				}
				else
				{
					MainViewModel mainViewModel = instance.MainViewModel;
					observableCollection = ((mainViewModel != null) ? mainViewModel.Cameras : null);
				}
				ObservableCollection<CameraNode> cameras = observableCollection;
				bool flag2 = cameras == null;
				if (flag2)
				{
					result = false;
				}
				else
				{
					foreach (CameraNode camera in cameras)
					{
						bool flag3 = camera == null;
						if (!flag3)
						{
							bool flag4;
							if (!string.Equals(camera.Name, cameraName, StringComparison.OrdinalIgnoreCase))
							{
								CameraItem cameraInfo = camera.CameraInfo;
								flag4 = string.Equals((cameraInfo != null) ? cameraInfo.CameraName : null, cameraName, StringComparison.OrdinalIgnoreCase);
							}
							else
							{
								flag4 = true;
							}
							bool sameCamera = flag4;
							bool flag5 = sameCamera;
							if (flag5)
							{
								CameraParameterConfig cameraConfig = camera.CameraConfig;
								return cameraConfig != null && cameraConfig.HardwareTrigger;
							}
						}
					}
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001DCD RID: 7629 RVA: 0x000A9F04 File Offset: 0x000A8104
		private static string ExtractCameraNameFromTriggerTag(string tagName, string suffix)
		{
			bool flag = string.IsNullOrWhiteSpace(tagName);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string value = tagName.Trim();
				bool flag2 = value.StartsWith("camera ", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					value = value.Substring("camera ".Length);
				}
				bool flag3 = value.EndsWith(suffix, StringComparison.OrdinalIgnoreCase);
				if (flag3)
				{
					value = value.Substring(0, value.Length - suffix.Length);
				}
				result = value.Trim();
			}
			return result;
		}

		// Token: 0x06001DCE RID: 7630 RVA: 0x000A9F78 File Offset: 0x000A8178
		private static bool ReadBoolTag(CommunicationConnection connection, CommunicationTagRow tag, out bool value, out string error)
		{
			value = false;
			error = null;
			string text;
			bool flag = !CameraTriggerCommunicationService.ReadTagValue(connection, tag, out text, out error);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				value = CameraTriggerCommunicationService.IsTrue(text);
				result = true;
			}
			return result;
		}

		// Token: 0x06001DCF RID: 7631 RVA: 0x000A9FB0 File Offset: 0x000A81B0
		private static bool ReadIntTag(CommunicationConnection connection, CommunicationTagRow tag, out int value, out string error)
		{
			value = 0;
			error = null;
			string text;
			bool flag = !CameraTriggerCommunicationService.ReadTagValue(connection, tag, out text, out error);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				double number;
				bool flag2 = double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out number);
				if (flag2)
				{
					value = (int)Math.Round(number);
					result = true;
				}
				else
				{
					error = "Tag '" + ((tag != null) ? tag.Name : null) + "' value is not a number: " + text;
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001DD0 RID: 7632 RVA: 0x000AA024 File Offset: 0x000A8224
		private static bool ReadIntTagFlexible(CommunicationConnection connection, CommunicationTagRow tag, out int value, out string error)
		{
			value = 0;
			string text;
			string quality;
			string addressUsed;
			bool flag = !CameraTriggerCommunicationService.TryReadRawFlexible(connection, tag, false, out text, out quality, out addressUsed, out error);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				double number;
				bool flag2 = double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out number);
				if (flag2)
				{
					value = (int)Math.Round(number);
					result = true;
				}
				else
				{
					error = "Tag '" + ((tag != null) ? tag.Name : null) + "' value is not a number: " + text;
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001DD1 RID: 7633 RVA: 0x000AA0A0 File Offset: 0x000A82A0
		private static bool TryReadRawFlexible(CommunicationConnection connection, CommunicationTagRow tag, bool logReadStart, out string value, out string quality, out string addressUsed, out string error)
		{
			value = null;
			quality = null;
			addressUsed = ((tag != null) ? tag.Address : null);
			if (logReadStart)
			{
				CameraTriggerCommunicationService.RaiseDiagnostic("Info", "[DEBUG] start read snap tag '" + (((tag != null) ? tag.Name : null) ?? "?") + "' @" + (((tag != null) ? tag.Address : null) ?? "?"));
			}
			bool flag = CameraTriggerCommunicationService.TryReadRaw(connection, tag, out value, out quality, out error);
			bool result;
			if (flag)
			{
				bool flag2 = CameraTriggerCommunicationService.IsTrue(value);
				if (flag2)
				{
					result = true;
				}
				else
				{
					string alternateAddress = CameraTriggerCommunicationService.GetRawOffsetProbeAddress((tag != null) ? tag.Address : null);
					bool flag3 = string.IsNullOrWhiteSpace(alternateAddress);
					if (flag3)
					{
						result = true;
					}
					else
					{
						CommunicationTagRow alternateTag = CameraTriggerCommunicationService.CloneTagWithAddress(tag, alternateAddress);
						string alternateValue;
						string alternateQuality;
						string alternateError;
						bool flag4 = CameraTriggerCommunicationService.TryReadRaw(connection, alternateTag, out alternateValue, out alternateQuality, out alternateError) && CameraTriggerCommunicationService.IsTrue(alternateValue);
						if (flag4)
						{
							value = alternateValue;
							quality = alternateQuality;
							addressUsed = tag.Address + " raw-offset";
							error = null;
							result = true;
						}
						else
						{
							result = true;
						}
					}
				}
			}
			else
			{
				string fallbackAddress = CameraTriggerCommunicationService.GetRawOffsetProbeAddress((tag != null) ? tag.Address : null);
				bool flag5 = string.IsNullOrWhiteSpace(fallbackAddress);
				if (flag5)
				{
					result = false;
				}
				else
				{
					CommunicationTagRow fallbackTag = CameraTriggerCommunicationService.CloneTagWithAddress(tag, fallbackAddress);
					bool flag6 = CameraTriggerCommunicationService.TryReadRaw(connection, fallbackTag, out value, out quality, out error);
					if (flag6)
					{
						addressUsed = tag.Address + " raw-offset";
						result = true;
					}
					else
					{
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x06001DD2 RID: 7634 RVA: 0x000AA214 File Offset: 0x000A8414
		private static CommunicationTagRow CloneTagWithAddress(CommunicationTagRow source, string address)
		{
			return new CommunicationTagRow
			{
				Group = ((source != null) ? source.Group : null),
				Name = ((source != null) ? source.Name : null),
				Address = address,
				DataType = ((source != null) ? source.DataType : null),
				ReadWrite = ((source != null) ? source.ReadWrite : null),
				LinkedToolName = ((source != null) ? source.LinkedToolName : null),
				ResultField = ((source != null) ? source.ResultField : null),
				MaxResultCount = ((source != null) ? source.MaxResultCount : 1),
				Description = ((source != null) ? source.Description : null)
			};
		}

		// Token: 0x06001DD3 RID: 7635 RVA: 0x000AA2CC File Offset: 0x000A84CC
		private static string GetRawOffsetProbeAddress(string address)
		{
			int value;
			bool flag = !int.TryParse(address, out value) || value < 1 || value > 65535;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				int displayAddressForRawOffset = value + 40001;
				bool flag2 = displayAddressForRawOffset > 99999;
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = displayAddressForRawOffset.ToString(CultureInfo.InvariantCulture);
				}
			}
			return result;
		}

		// Token: 0x06001DD4 RID: 7636 RVA: 0x000AA328 File Offset: 0x000A8528
		private static bool TryReadRaw(CommunicationConnection connection, CommunicationTagRow tag, out string value, out string quality, out string error)
		{
			value = null;
			quality = null;
			error = null;
			bool flag = tag == null || string.IsNullOrWhiteSpace(tag.Address);
			bool result2;
			if (flag)
			{
				error = "Tag is empty or has no address.";
				result2 = false;
			}
			else
			{
				CommunicationReadResult result = CameraTriggerCommunicationService.CommunicationService.ReadAll(connection, new CommunicationTagRow[]
				{
					tag
				});
				bool flag2 = (!result.Success || result.Rows.Count == 0) && !CameraTriggerCommunicationService.CommunicationService.IsConnected(connection);
				if (flag2)
				{
					CameraTriggerCommunicationService.SetActiveConnectionHealthy(false, null, false);
				}
				bool flag3 = !result.Success || result.Rows.Count == 0;
				if (flag3)
				{
					bool flag4 = CameraTriggerCommunicationService.IsTransportFailure(result.Message);
					if (flag4)
					{
						CameraTriggerCommunicationService.SetActiveConnectionHealthy(false, result.Message, true);
						CameraTriggerCommunicationService.CommunicationService.Disconnect(connection);
					}
					error = "Read tag '" + tag.Name + "' failed. " + result.Message;
					result2 = false;
				}
				else
				{
					quality = result.Rows[0].Quality;
					value = result.Rows[0].Value;
					bool flag5 = !string.Equals(quality, "Good", StringComparison.OrdinalIgnoreCase);
					if (flag5)
					{
						error = string.Concat(new string[]
						{
							"Read tag '",
							tag.Name,
							"' quality=",
							quality,
							", value=",
							value
						});
						CameraTriggerCommunicationService.SetActiveConnectionHealthy(true, "Connected. Trigger tag returned bad quality: " + (value ?? string.Empty), false);
						result2 = false;
					}
					else
					{
						CameraTriggerCommunicationService.SetActiveConnectionHealthy(true, "Connected.", false);
						result2 = true;
					}
				}
			}
			return result2;
		}

		// Token: 0x06001DD5 RID: 7637 RVA: 0x000AA4CC File Offset: 0x000A86CC
		private static void SetActiveConnectionHealthy(bool isHealthy, string message = null, bool forceNotify = false)
		{
			object syncRoot = CameraTriggerCommunicationService.SyncRoot;
			CommunicationConnection activeConnection;
			lock (syncRoot)
			{
				CameraTriggerCommunicationService._activeConnectionHealthy = isHealthy;
				activeConnection = CameraTriggerCommunicationService._activeConnection;
			}
			bool flag2 = activeConnection != null && !string.IsNullOrWhiteSpace(activeConnection.Name);
			if (flag2)
			{
				CommunicationStartupService.ReportExternalConnectionHealth(activeConnection.Name, isHealthy, string.IsNullOrWhiteSpace(message) ? (isHealthy ? "Connected." : "Disconnected.") : message, forceNotify);
			}
		}

		// Token: 0x06001DD6 RID: 7638 RVA: 0x000AA558 File Offset: 0x000A8758
		private static bool IsTransportFailure(string message)
		{
			bool flag = string.IsNullOrWhiteSpace(message);
			return !flag && (message.IndexOf("transport connection", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("unable to read data", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("unable to write data", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("connection timeout", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("timed out", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("forcibly closed", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("aborted", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("connection reset", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("Connection closed by remote device", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("stream is not connected", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("TCP socket is not connected", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("Connection is not connected", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("No connection could be made", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("failed to respond", StringComparison.OrdinalIgnoreCase) >= 0);
		}

		// Token: 0x06001DD7 RID: 7639 RVA: 0x000AA664 File Offset: 0x000A8864
		private static bool ReadTagValue(CommunicationConnection connection, CommunicationTagRow tag, out string value, out string error)
		{
			value = null;
			error = null;
			bool flag = tag == null || string.IsNullOrWhiteSpace(tag.Address);
			bool result2;
			if (flag)
			{
				error = "Tag is empty or has no address.";
				result2 = false;
			}
			else
			{
				CommunicationReadResult result = CameraTriggerCommunicationService.CommunicationService.ReadAll(connection, new CommunicationTagRow[]
				{
					tag
				});
				bool flag2 = !result.Success || result.Rows.Count == 0 || !string.Equals(result.Rows[0].Quality, "Good", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					bool flag3 = !CameraTriggerCommunicationService.CommunicationService.IsConnected(connection);
					if (flag3)
					{
						CameraTriggerCommunicationService.SetActiveConnectionHealthy(false, null, false);
					}
				}
				bool flag4 = !result.Success || result.Rows.Count == 0 || !string.Equals(result.Rows[0].Quality, "Good", StringComparison.OrdinalIgnoreCase);
				if (flag4)
				{
					error = ((result.Success && result.Rows.Count > 0) ? string.Concat(new string[]
					{
						"Read tag '",
						tag.Name,
						"' failed. Quality=",
						result.Rows[0].Quality,
						", Value=",
						result.Rows[0].Value
					}) : ("Read tag '" + tag.Name + "' failed. " + result.Message));
					result2 = false;
				}
				else
				{
					value = result.Rows[0].Value;
					result2 = true;
				}
			}
			return result2;
		}

		// Token: 0x06001DD8 RID: 7640 RVA: 0x000AA7F4 File Offset: 0x000A89F4
		private static void RaiseCameraTriggered(string cameraName, int turnSnapIndex)
		{
			CameraTriggerEventArgs args = new CameraTriggerEventArgs(cameraName, turnSnapIndex);
			Form_home.PostCameraTrigger(args);
			EventHandler<CameraTriggerEventArgs> handler = CameraTriggerCommunicationService.CameraTriggered;
			bool flag = handler != null;
			if (flag)
			{
				handler(null, args);
			}
		}

		// Token: 0x06001DD9 RID: 7641 RVA: 0x000AA828 File Offset: 0x000A8A28
		private static void RaiseDiagnostic(string level, string message)
		{
			CameraTriggerDiagnosticEventArgs args = new CameraTriggerDiagnosticEventArgs(level, message);
			Form_home.PostCameraTriggerDiagnostic(args);
			EventHandler<CameraTriggerDiagnosticEventArgs> handler = CameraTriggerCommunicationService.DiagnosticLogged;
			bool flag = handler != null;
			if (flag)
			{
				handler(null, args);
			}
		}

		// Token: 0x06001DDA RID: 7642 RVA: 0x000AA85C File Offset: 0x000A8A5C
		private static void LogReadErrorOnce(Dictionary<string, string> errors, string tagName, string error)
		{
			string key = string.IsNullOrWhiteSpace(tagName) ? "<unknown>" : tagName;
			string message = error ?? "Read failed.";
			string last;
			bool flag = errors.TryGetValue(key, out last) && string.Equals(last, message, StringComparison.Ordinal);
			if (!flag)
			{
				errors[key] = message;
				CameraTriggerCommunicationService.RaiseDiagnostic("Warn", message);
			}
		}

		// Token: 0x06001DDB RID: 7643 RVA: 0x000AA8B8 File Offset: 0x000A8AB8
		private static void ClearReadError(Dictionary<string, string> errors, string tagName)
		{
			bool flag = errors == null || string.IsNullOrWhiteSpace(tagName);
			if (!flag)
			{
				errors.Remove(tagName);
			}
		}

		// Token: 0x06001DDC RID: 7644 RVA: 0x000AA8E4 File Offset: 0x000A8AE4
		private static bool IsTrue(string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = string.Equals(value, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "TRUE", StringComparison.OrdinalIgnoreCase);
				double number;
				result = (flag2 || (double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out number) && Math.Abs(number) > double.Epsilon));
			}
			return result;
		}

		// Token: 0x06001DDD RID: 7645 RVA: 0x000AA954 File Offset: 0x000A8B54
		private static int GetPollInterval(CommunicationConnection connection)
		{
			string text = ((connection != null) ? connection.ExchangeInterval : null) ?? "10";
			string digits = new string(text.Where(new Func<char, bool>(char.IsDigit)).ToArray<char>());
			int value;
			return int.TryParse(digits, out value) ? Math.Max(10, value) : 10;
		}

		// Token: 0x06001DDE RID: 7646 RVA: 0x000AA9B0 File Offset: 0x000A8BB0
		private static CommunicationConnection FindFallbackTriggerConnection(CommunicationConfigData config)
		{
			CommunicationConfigData config2 = config;
			List<CommunicationConnection> connections = ((config2 != null) ? config2.Connections : null) ?? new List<CommunicationConnection>();
			PlcCommunicationService service = SharedCommunicationService.Instance;
			List<CommunicationConnection> candidates = (from x in connections
			where CameraTriggerCommunicationService.IsSupportedTriggerConnection(x) && !string.IsNullOrWhiteSpace(x.Name) && CameraTriggerCommunicationService.BuildTriggerDefinitions(CommunicationConfigStorageService.GetTagsForConnection(config, x.Name)).Count > 0
			select x).ToList<CommunicationConnection>();
			return candidates.FirstOrDefault((CommunicationConnection x) => service.IsConnected(x)) ?? candidates.FirstOrDefault<CommunicationConnection>();
		}

		// Token: 0x06001DDF RID: 7647 RVA: 0x000AAA2C File Offset: 0x000A8C2C
		private static bool IsSupportedTriggerConnection(CommunicationConnection connection)
		{
			return connection != null && CommunicationOptions.SupportsTagReadWrite(connection.Protocol);
		}

		// Token: 0x06001DE0 RID: 7648 RVA: 0x000AAA50 File Offset: 0x000A8C50
		private static void NormalizeConnection(CommunicationConnection connection)
		{
			bool flag = connection == null;
			if (!flag)
			{
				bool flag2 = string.IsNullOrWhiteSpace(connection.Protocol);
				if (flag2)
				{
					connection.Protocol = "Modbus Client TCP/IP";
				}
				bool flag3 = connection.Port <= 0 && !string.Equals(connection.Protocol, "MX Component", StringComparison.OrdinalIgnoreCase);
				if (flag3)
				{
					connection.ApplyDefaultPort();
				}
				bool flag4 = connection.TimeoutMs <= 0;
				if (flag4)
				{
					connection.TimeoutMs = 2000;
				}
			}
		}

		// Token: 0x06001DE1 RID: 7649 RVA: 0x000AAACC File Offset: 0x000A8CCC
		private static CommunicationConnection CloneConnectionWithTimeout(CommunicationConnection source, int timeoutMs)
		{
			bool flag = source == null;
			CommunicationConnection result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new CommunicationConnection
				{
					Name = source.Name,
					Protocol = source.Protocol,
					Description = source.Description,
					IpAddress = source.IpAddress,
					Port = source.Port,
					LogicalStationNumber = source.LogicalStationNumber,
					TimeoutMs = Math.Max(100, timeoutMs),
					ExchangeInterval = source.ExchangeInterval,
					ByteOrder = source.ByteOrder,
					WordOrder = source.WordOrder,
					FloatFormat = source.FloatFormat,
					KeepAlive = source.KeepAlive,
					AutoReconnect = source.AutoReconnect,
					MonitorStartAddress = source.MonitorStartAddress,
					MonitorEndAddress = source.MonitorEndAddress,
					MonitorDataType = source.MonitorDataType,
					MonitorFunctionCode = source.MonitorFunctionCode
				};
			}
			return result;
		}

		// Token: 0x06001DE2 RID: 7650 RVA: 0x000AABD4 File Offset: 0x000A8DD4
		private static string NormalizeName(string value)
		{
			return new string((value ?? string.Empty).Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
		}

		// Token: 0x04000C93 RID: 3219
		private static readonly object SyncRoot = new object();

		// Token: 0x04000C94 RID: 3220
		private static readonly PlcCommunicationService CommunicationService = SharedCommunicationService.Instance;

		// Token: 0x04000C95 RID: 3221
		private static CancellationTokenSource _cancellation;

		// Token: 0x04000C96 RID: 3222
		private static Task _pollTask;

		// Token: 0x04000C97 RID: 3223
		private static string _activeConfigPath;

		// Token: 0x04000C98 RID: 3224
		private static CommunicationConnection _activeConnection;

		// Token: 0x04000C99 RID: 3225
		private static bool _activeConnectionHealthy;

		// Token: 0x04000C9A RID: 3226
		private const int ReconnectHeartbeatMs = 5000;

		// Token: 0x04000C9B RID: 3227
		private const int ConnectedTagRefreshMs = 5000;

		// Token: 0x04000C9C RID: 3228
		private const int ReconnectTimeoutMs = 500;

		// Token: 0x0200044F RID: 1103
		private class CameraTriggerDefinition
		{
			// Token: 0x17000B83 RID: 2947
			// (get) Token: 0x06002BC2 RID: 11202 RVA: 0x000EA500 File Offset: 0x000E8700
			// (set) Token: 0x06002BC3 RID: 11203 RVA: 0x000EA508 File Offset: 0x000E8708
			public string CameraName { get; set; }

			// Token: 0x17000B84 RID: 2948
			// (get) Token: 0x06002BC4 RID: 11204 RVA: 0x000EA511 File Offset: 0x000E8711
			// (set) Token: 0x06002BC5 RID: 11205 RVA: 0x000EA519 File Offset: 0x000E8719
			public CommunicationTagRow SnapTag { get; set; }

			// Token: 0x17000B85 RID: 2949
			// (get) Token: 0x06002BC6 RID: 11206 RVA: 0x000EA522 File Offset: 0x000E8722
			// (set) Token: 0x06002BC7 RID: 11207 RVA: 0x000EA52A File Offset: 0x000E872A
			public CommunicationTagRow RunTag { get; set; }

			// Token: 0x17000B86 RID: 2950
			// (get) Token: 0x06002BC8 RID: 11208 RVA: 0x000EA533 File Offset: 0x000E8733
			// (set) Token: 0x06002BC9 RID: 11209 RVA: 0x000EA53B File Offset: 0x000E873B
			public CommunicationTagRow ConnectedTag { get; set; }
		}
	}
}
