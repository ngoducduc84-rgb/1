﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F8 RID: 504
	public class CameraTriggerDiagnosticEventArgs : EventArgs
	{
		// Token: 0x06001DB4 RID: 7604 RVA: 0x000A84E8 File Offset: 0x000A66E8
		public CameraTriggerDiagnosticEventArgs(string level, string message)
		{
			this.Level = (string.IsNullOrWhiteSpace(level) ? "Info" : level);
			this.Message = (message ?? string.Empty);
		}

		// Token: 0x17000930 RID: 2352
		// (get) Token: 0x06001DB5 RID: 7605 RVA: 0x000A8518 File Offset: 0x000A6718
		public string Level { get; }

		// Token: 0x17000931 RID: 2353
		// (get) Token: 0x06001DB6 RID: 7606 RVA: 0x000A8520 File Offset: 0x000A6720
		public string Message { get; }
	}
}
