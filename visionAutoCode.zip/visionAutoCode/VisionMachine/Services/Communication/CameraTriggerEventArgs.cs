﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F7 RID: 503
	public class CameraTriggerEventArgs : EventArgs
	{
		// Token: 0x06001DB1 RID: 7601 RVA: 0x000A84C0 File Offset: 0x000A66C0
		public CameraTriggerEventArgs(string cameraName, int turnSnapIndex)
		{
			this.CameraName = cameraName;
			this.TurnSnapIndex = turnSnapIndex;
		}

		// Token: 0x1700092E RID: 2350
		// (get) Token: 0x06001DB2 RID: 7602 RVA: 0x000A84D8 File Offset: 0x000A66D8
		public string CameraName { get; }

		// Token: 0x1700092F RID: 2351
		// (get) Token: 0x06001DB3 RID: 7603 RVA: 0x000A84E0 File Offset: 0x000A66E0
		public int TurnSnapIndex { get; }
	}
}
