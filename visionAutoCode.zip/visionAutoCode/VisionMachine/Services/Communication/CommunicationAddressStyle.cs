﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001E6 RID: 486
	public enum CommunicationAddressStyle
	{
		// Token: 0x04000C51 RID: 3153
		ModbusRegister,
		// Token: 0x04000C52 RID: 3154
		OpcNodeId,
		// Token: 0x04000C53 RID: 3155
		MxDevice
	}
}
