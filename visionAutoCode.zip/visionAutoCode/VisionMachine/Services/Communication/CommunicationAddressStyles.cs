﻿using System;
using System.Globalization;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001E7 RID: 487
	public static class CommunicationAddressStyles
	{
		// Token: 0x06001D12 RID: 7442 RVA: 0x000A4444 File Offset: 0x000A2644
		public static CommunicationAddressStyle FromProtocol(string protocol)
		{
			bool flag = string.Equals(protocol, "OPC UA", StringComparison.OrdinalIgnoreCase);
			CommunicationAddressStyle result;
			if (flag)
			{
				result = CommunicationAddressStyle.OpcNodeId;
			}
			else
			{
				bool flag2 = string.Equals(protocol, "MX Component", StringComparison.OrdinalIgnoreCase) || string.Equals(protocol, "MC Protocol", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = CommunicationAddressStyle.MxDevice;
				}
				else
				{
					result = CommunicationAddressStyle.ModbusRegister;
				}
			}
			return result;
		}

		// Token: 0x06001D13 RID: 7443 RVA: 0x000A4494 File Offset: 0x000A2694
		public static string Format(int modbusAddress, CommunicationAddressStyle style)
		{
			string result;
			if (style != CommunicationAddressStyle.OpcNodeId)
			{
				if (style != CommunicationAddressStyle.MxDevice)
				{
					result = modbusAddress.ToString(CultureInfo.InvariantCulture);
				}
				else
				{
					result = "D" + Math.Max(0, modbusAddress - 40000).ToString(CultureInfo.InvariantCulture);
				}
			}
			else
			{
				result = string.Empty;
			}
			return result;
		}

		// Token: 0x06001D14 RID: 7444 RVA: 0x000A44F4 File Offset: 0x000A26F4
		public static string Format(string modbusAddress, CommunicationAddressStyle style)
		{
			bool flag = style == CommunicationAddressStyle.ModbusRegister;
			string result;
			if (flag)
			{
				result = modbusAddress;
			}
			else
			{
				bool flag2 = string.IsNullOrWhiteSpace(modbusAddress);
				if (flag2)
				{
					result = modbusAddress;
				}
				else
				{
					int parsed;
					bool flag3 = !int.TryParse(modbusAddress.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed);
					if (flag3)
					{
						result = ((style == CommunicationAddressStyle.OpcNodeId) ? string.Empty : modbusAddress);
					}
					else
					{
						result = CommunicationAddressStyles.Format(parsed, style);
					}
				}
			}
			return result;
		}

		// Token: 0x06001D15 RID: 7445 RVA: 0x000A4554 File Offset: 0x000A2754
		public static bool Matches(string address, CommunicationAddressStyle style)
		{
			bool flag = string.IsNullOrWhiteSpace(address);
			bool result;
			if (flag)
			{
				result = (style == CommunicationAddressStyle.OpcNodeId);
			}
			else
			{
				string text = address.Trim();
				bool flag2 = !CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(text);
				if (flag2)
				{
					result = true;
				}
				else if (style != CommunicationAddressStyle.OpcNodeId)
				{
					if (style != CommunicationAddressStyle.MxDevice)
					{
						int parsed;
						result = int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed);
					}
					else
					{
						result = !char.IsDigit(text[0]);
					}
				}
				else
				{
					result = text.StartsWith("ns=", StringComparison.OrdinalIgnoreCase);
				}
			}
			return result;
		}

		// Token: 0x04000C54 RID: 3156
		private const int ModbusHoldingRegisterBase = 40000;

		// Token: 0x04000C55 RID: 3157
		public const string MxDataRegisterPrefix = "D";
	}
}
