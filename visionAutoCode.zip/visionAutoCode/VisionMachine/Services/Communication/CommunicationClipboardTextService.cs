﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001E8 RID: 488
	public static class CommunicationClipboardTextService
	{
		// Token: 0x06001D16 RID: 7446 RVA: 0x000A45D4 File Offset: 0x000A27D4
		public static string BuildMonitorRowsText(IEnumerable<CommunicationMonitorRow> rows)
		{
			StringBuilder builder = new StringBuilder();
			builder.AppendLine("Tag Label\tGroup\tNodeId / Address\tData Type\tValue\tQuality\tTimestamp\tDescription");
			foreach (CommunicationMonitorRow row in (rows ?? Enumerable.Empty<CommunicationMonitorRow>()))
			{
				builder.Append(CommunicationClipboardTextService.CopyCell(row.TagName)).Append('\t').Append(CommunicationClipboardTextService.CopyCell(row.Group)).Append('\t').Append(CommunicationClipboardTextService.CopyCell(row.Address)).Append('\t').Append(CommunicationClipboardTextService.CopyCell(row.DataType)).Append('\t').Append(CommunicationClipboardTextService.CopyCell(row.Value)).Append('\t').Append(CommunicationClipboardTextService.CopyCell(row.Quality)).Append('\t').Append(CommunicationClipboardTextService.CopyCell(row.Timestamp)).Append('\t').Append(CommunicationClipboardTextService.CopyCell(row.Description)).AppendLine();
			}
			return builder.ToString();
		}

		// Token: 0x06001D17 RID: 7447 RVA: 0x000A4700 File Offset: 0x000A2900
		private static string CopyCell(string value)
		{
			return (value ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
		}
	}
}
