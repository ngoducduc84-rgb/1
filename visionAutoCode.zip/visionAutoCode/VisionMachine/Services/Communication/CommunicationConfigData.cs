﻿using System;
using System.Collections.Generic;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001EA RID: 490
	public class CommunicationConfigData
	{
		// Token: 0x17000916 RID: 2326
		// (get) Token: 0x06001D36 RID: 7478 RVA: 0x000A57AC File Offset: 0x000A39AC
		// (set) Token: 0x06001D37 RID: 7479 RVA: 0x000A57B4 File Offset: 0x000A39B4
		public List<CommunicationConnection> Connections { get; set; } = new List<CommunicationConnection>();

		// Token: 0x17000917 RID: 2327
		// (get) Token: 0x06001D38 RID: 7480 RVA: 0x000A57BD File Offset: 0x000A39BD
		// (set) Token: 0x06001D39 RID: 7481 RVA: 0x000A57C5 File Offset: 0x000A39C5
		public List<CommunicationTagRow> Tags { get; set; } = new List<CommunicationTagRow>();

		// Token: 0x17000918 RID: 2328
		// (get) Token: 0x06001D3A RID: 7482 RVA: 0x000A57CE File Offset: 0x000A39CE
		// (set) Token: 0x06001D3B RID: 7483 RVA: 0x000A57D6 File Offset: 0x000A39D6
		public Dictionary<string, List<CommunicationTagRow>> ConnectionTags { get; set; } = new Dictionary<string, List<CommunicationTagRow>>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x17000919 RID: 2329
		// (get) Token: 0x06001D3C RID: 7484 RVA: 0x000A57DF File Offset: 0x000A39DF
		// (set) Token: 0x06001D3D RID: 7485 RVA: 0x000A57E7 File Offset: 0x000A39E7
		public Dictionary<string, List<CommunicationInitialValueRow>> InitialValues { get; set; } = new Dictionary<string, List<CommunicationInitialValueRow>>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x1700091A RID: 2330
		// (get) Token: 0x06001D3E RID: 7486 RVA: 0x000A57F0 File Offset: 0x000A39F0
		// (set) Token: 0x06001D3F RID: 7487 RVA: 0x000A57F8 File Offset: 0x000A39F8
		public CommunicationRuntimeSettings RuntimeSettings { get; set; } = new CommunicationRuntimeSettings();
	}
}
