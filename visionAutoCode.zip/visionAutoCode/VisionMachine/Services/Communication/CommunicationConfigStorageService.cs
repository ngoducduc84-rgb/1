﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using VisionMachine.Helpers;
using VisionMachine.Models.Communication;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001E9 RID: 489
	public static class CommunicationConfigStorageService
	{
		// Token: 0x17000913 RID: 2323
		// (get) Token: 0x06001D18 RID: 7448 RVA: 0x000A4749 File Offset: 0x000A2949
		// (set) Token: 0x06001D19 RID: 7449 RVA: 0x000A4750 File Offset: 0x000A2950
		public static string LastLoadPath { get; private set; }

		// Token: 0x17000914 RID: 2324
		// (get) Token: 0x06001D1A RID: 7450 RVA: 0x000A4758 File Offset: 0x000A2958
		// (set) Token: 0x06001D1B RID: 7451 RVA: 0x000A475F File Offset: 0x000A295F
		public static string LastLoadMessage { get; private set; }

		// Token: 0x17000915 RID: 2325
		// (get) Token: 0x06001D1C RID: 7452 RVA: 0x000A4767 File Offset: 0x000A2967
		// (set) Token: 0x06001D1D RID: 7453 RVA: 0x000A476E File Offset: 0x000A296E
		public static string LastSavePath { get; private set; }

		// Token: 0x06001D1E RID: 7454 RVA: 0x000A4778 File Offset: 0x000A2978
		public static string GetConfigPath()
		{
			string folder = null;
			string currentModelName = CommunicationConfigStorageService.GetCurrentModelName();
			bool flag = !string.IsNullOrWhiteSpace(currentModelName);
			if (flag)
			{
				string modelName = RecipePathService.MakeSafeFileName(currentModelName);
				folder = Path.Combine(Manager_path._dataPath, modelName);
			}
			bool flag2 = string.IsNullOrWhiteSpace(folder);
			if (flag2)
			{
				folder = Path.Combine(Manager_path.path_communication, "Communication");
			}
			Directory.CreateDirectory(folder);
			return Path.Combine(folder, "communication_config.json");
		}

		// Token: 0x06001D1F RID: 7455 RVA: 0x000A47E8 File Offset: 0x000A29E8
		private static string GetCurrentModelName()
		{
			bool flag = ModelRuntimeStore.CurrentModel != null && !string.IsNullOrWhiteSpace(ModelRuntimeStore.CurrentModel.Model_name);
			string result;
			if (flag)
			{
				result = ModelRuntimeStore.CurrentModel.Model_name;
			}
			else
			{
				try
				{
					bool flag2 = !File.Exists(Manager_path._modelJsonPath);
					if (flag2)
					{
						result = null;
					}
					else
					{
						string json = File.ReadAllText(Manager_path._modelJsonPath);
						bool flag3 = string.IsNullOrWhiteSpace(json);
						if (flag3)
						{
							result = null;
						}
						else
						{
							ModelFileData data = JsonConvert.DeserializeObject<ModelFileData>(json);
							ModelFileData data2 = data;
							bool flag4 = ((data2 != null) ? data2.Models : null) == null || data.CurrentModelId == null;
							if (flag4)
							{
								result = null;
							}
							else
							{
								ModelConfig current = data.Models.Find((ModelConfig x) => x.Id == data.CurrentModelId.Value);
								result = ((current != null) ? current.Model_name : null);
							}
						}
					}
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001D20 RID: 7456 RVA: 0x000A48F0 File Offset: 0x000A2AF0
		public static List<CommunicationConnection> Load(string preferredPath = null)
		{
			return CommunicationConfigStorageService.LoadConfig(preferredPath).Connections;
		}

		// Token: 0x06001D21 RID: 7457 RVA: 0x000A4910 File Offset: 0x000A2B10
		public static List<CommunicationTagRow> GetTagsForConnection(CommunicationConfigData config, string connectionName)
		{
			bool flag = config == null;
			List<CommunicationTagRow> result;
			if (flag)
			{
				result = new List<CommunicationTagRow>();
			}
			else
			{
				List<CommunicationTagRow> tags;
				bool flag2 = !string.IsNullOrWhiteSpace(connectionName) && config.ConnectionTags != null && config.ConnectionTags.TryGetValue(connectionName.Trim(), out tags);
				if (flag2)
				{
					result = CommunicationConfigStorageService.CloneTags(tags);
				}
				else
				{
					result = CommunicationConfigStorageService.CloneTags(config.Tags);
				}
			}
			return result;
		}

		// Token: 0x06001D22 RID: 7458 RVA: 0x000A4974 File Offset: 0x000A2B74
		public static CommunicationConfigData LoadConfig(string preferredPath = null)
		{
			bool hasExplicitPath = !string.IsNullOrWhiteSpace(preferredPath);
			bool hasCurrentModel = ModelRuntimeStore.CurrentModel != null && !string.IsNullOrWhiteSpace(ModelRuntimeStore.CurrentModel.Model_name);
			string path = (!hasExplicitPath) ? CommunicationConfigStorageService.GetConfigPath() : preferredPath;
			CommunicationConfigData config;
			bool flag = CommunicationConfigStorageService.TryLoadFromPath(path, out config);
			CommunicationConfigData result;
			if (flag)
			{
				result = config;
			}
			else
			{
				bool flag2 = hasExplicitPath || hasCurrentModel;
				if (flag2)
				{
					CommunicationConfigStorageService.LastLoadPath = path;
					CommunicationConfigStorageService.LastLoadMessage = (File.Exists(path) ? "Communication config is empty or invalid." : "Communication config file was not found for the current model.");
					result = new CommunicationConfigData();
				}
				else
				{
					string legacyPath = CommunicationConfigStorageService.GetLegacyConfigPath();
					bool flag3 = !string.IsNullOrWhiteSpace(legacyPath) && !string.Equals(legacyPath, path, StringComparison.OrdinalIgnoreCase) && CommunicationConfigStorageService.TryLoadFromPath(legacyPath, out config);
					if (flag3)
					{
						result = config;
					}
					else
					{
						string fallbackPath = CommunicationConfigStorageService.FindLatestModelConfigPath(path, legacyPath);
						bool flag4 = !string.IsNullOrWhiteSpace(fallbackPath) && CommunicationConfigStorageService.TryLoadFromPath(fallbackPath, out config);
						if (flag4)
						{
							result = config;
						}
						else
						{
							CommunicationConfigStorageService.LastLoadPath = path;
							CommunicationConfigStorageService.LastLoadMessage = (File.Exists(path) ? "Communication config is empty or invalid." : "Communication config file was not found.");
							result = new CommunicationConfigData();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001D23 RID: 7459 RVA: 0x000A4A8C File Offset: 0x000A2C8C
		private static bool TryLoadFromPath(string path, out CommunicationConfigData config)
		{
			config = new CommunicationConfigData();
			bool flag = string.IsNullOrWhiteSpace(path) || !File.Exists(path);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					config = CommunicationConfigStorageService.LoadFromPath(path);
					bool flag2 = config == null || ((config.Connections == null || config.Connections.Count == 0) && (config.Tags == null || config.Tags.Count == 0) && (config.ConnectionTags == null || config.ConnectionTags.Count == 0));
					if (flag2)
					{
						result = false;
					}
					else
					{
						CommunicationConfigStorageService.LastLoadPath = path;
						CommunicationConfigStorageService.LastLoadMessage = string.Format("Loaded {0} communication connection(s), {1} tag(s).", config.Connections.Count, config.Tags.Count);
						result = true;
					}
				}
				catch (Exception ex)
				{
					CommunicationConfigStorageService.LastLoadPath = path;
					CommunicationConfigStorageService.LastLoadMessage = ex.Message;
					config = new CommunicationConfigData();
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001D24 RID: 7460 RVA: 0x000A4B98 File Offset: 0x000A2D98
		private static CommunicationConfigData LoadFromPath(string path)
		{
			string json = File.ReadAllText(path);
			bool flag = string.IsNullOrWhiteSpace(json);
			CommunicationConfigData result;
			if (flag)
			{
				result = new CommunicationConfigData();
			}
			else
			{
				string trimmedJson = json.TrimStart(Array.Empty<char>());
				bool flag2 = trimmedJson.StartsWith("[", StringComparison.Ordinal);
				if (flag2)
				{
					CommunicationConfigData legacyConfig = new CommunicationConfigData
					{
						Connections = (JsonConvert.DeserializeObject<List<CommunicationConnection>>(json) ?? new List<CommunicationConnection>())
					};
					CommunicationConfigStorageService.NormalizeLoadedConfig(legacyConfig);
					result = legacyConfig;
				}
				else
				{
					CommunicationConfigData config = JsonConvert.DeserializeObject<CommunicationConfigData>(json) ?? new CommunicationConfigData();
					CommunicationConfigStorageService.NormalizeLoadedConfig(config);
					result = config;
				}
			}
			return result;
		}

		// Token: 0x06001D25 RID: 7461 RVA: 0x000A4C28 File Offset: 0x000A2E28
		private static void NormalizeLoadedConfig(CommunicationConfigData config)
		{
			bool flag = config == null;
			if (!flag)
			{
				bool flag2 = config.Connections == null;
				if (flag2)
				{
					config.Connections = new List<CommunicationConnection>();
				}
				bool flag3 = config.Tags == null;
				if (flag3)
				{
					config.Tags = new List<CommunicationTagRow>();
				}
				bool flag4 = config.ConnectionTags == null;
				if (flag4)
				{
					config.ConnectionTags = new Dictionary<string, List<CommunicationTagRow>>(StringComparer.OrdinalIgnoreCase);
				}
				bool flag5 = config.ConnectionTags.Count == 0 && config.Tags.Count > 0;
				if (flag5)
				{
					CommunicationConfigStorageService.MigrateLegacyGlobalTags(config);
				}
				bool flag6 = config.Tags.Count == 0 && config.ConnectionTags.Count > 0;
				if (flag6)
				{
					config.Tags = (from x in config.ConnectionTags
					where x.Value != null
					select x).SelectMany((KeyValuePair<string, List<CommunicationTagRow>> x) => x.Value).Select(new Func<CommunicationTagRow, CommunicationTagRow>(CommunicationConfigStorageService.CloneTag)).ToList<CommunicationTagRow>();
				}
				bool flag7 = config.RuntimeSettings == null;
				if (flag7)
				{
					config.RuntimeSettings = new CommunicationRuntimeSettings();
				}
				CommunicationConfigStorageService.NormalizeOpcConnectionTags(config);
			}
		}

		// Token: 0x06001D26 RID: 7462 RVA: 0x000A4D78 File Offset: 0x000A2F78
		private static void NormalizeOpcConnectionTags(CommunicationConfigData config)
		{
			bool flag = config == null || config.ConnectionTags == null || config.Connections == null;
			if (!flag)
			{
				HashSet<string> opcConnectionNames = new HashSet<string>(from x in config.Connections
				where CommunicationConfigStorageService.IsOpcUaProtocol((x != null) ? x.Protocol : null) && !string.IsNullOrWhiteSpace(x.Name)
				select x.Name.Trim(), StringComparer.OrdinalIgnoreCase);
				foreach (KeyValuePair<string, List<CommunicationTagRow>> entry in config.ConnectionTags)
				{
					bool flag2 = entry.Value == null;
					if (!flag2)
					{
						bool isOpcConnection = opcConnectionNames.Contains(entry.Key);
						foreach (CommunicationTagRow tag in from x in entry.Value
						where x != null
						select x)
						{
							bool flag3 = CommunicationConfigStorageService.IsHeartbeatTagName(tag.Name);
							if (flag3)
							{
								tag.DataType = "BOOL";
								tag.ReadWrite = "Read";
							}
							bool flag4 = isOpcConnection && !string.IsNullOrWhiteSpace(tag.Address) && !CommunicationConfigStorageService.LooksLikeOpcAddress(tag.Address);
							if (flag4)
							{
								tag.Address = string.Empty;
							}
						}
					}
				}
			}
		}

		// Token: 0x06001D27 RID: 7463 RVA: 0x000A4F50 File Offset: 0x000A3150
		private static void MigrateLegacyGlobalTags(CommunicationConfigData config)
		{
			CommunicationConnection communicationConnection = config.Connections.FirstOrDefault<CommunicationConnection>();
			string firstConnection = (communicationConnection != null) ? communicationConnection.Name : null;
			CommunicationConnection communicationConnection2 = config.Connections.FirstOrDefault((CommunicationConnection x) => !CommunicationConfigStorageService.IsOpcUaProtocol((x != null) ? x.Protocol : null));
			string firstModbusConnection = (communicationConnection2 != null) ? communicationConnection2.Name : null;
			CommunicationConnection communicationConnection3 = config.Connections.FirstOrDefault((CommunicationConnection x) => CommunicationConfigStorageService.IsOpcUaProtocol((x != null) ? x.Protocol : null));
			string firstOpcConnection = (communicationConnection3 != null) ? communicationConnection3.Name : null;
			bool flag = string.IsNullOrWhiteSpace(firstConnection);
			if (flag)
			{
				firstConnection = "Default";
			}
			bool flag2 = string.IsNullOrWhiteSpace(firstModbusConnection);
			if (flag2)
			{
				firstModbusConnection = firstConnection;
			}
			bool flag3 = string.IsNullOrWhiteSpace(firstOpcConnection);
			if (flag3)
			{
				firstOpcConnection = firstConnection;
			}
			foreach (CommunicationTagRow tag in from x in config.Tags
			where x != null
			select x)
			{
				string key = CommunicationConfigStorageService.LooksLikeOpcAddress(tag.Address) ? firstOpcConnection : firstModbusConnection;
				List<CommunicationTagRow> list;
				bool flag4 = !config.ConnectionTags.TryGetValue(key, out list);
				if (flag4)
				{
					list = new List<CommunicationTagRow>();
					config.ConnectionTags[key] = list;
				}
				list.Add(CommunicationConfigStorageService.CloneTag(tag));
			}
		}

		// Token: 0x06001D28 RID: 7464 RVA: 0x000A50CC File Offset: 0x000A32CC
		private static bool LooksLikeOpcAddress(string address)
		{
			return !string.IsNullOrWhiteSpace(address) && address.TrimStart(Array.Empty<char>()).StartsWith("ns=", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001D29 RID: 7465 RVA: 0x000A5100 File Offset: 0x000A3300
		private static bool IsHeartbeatTagName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string normalized = new string(name.Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
				result = (normalized == "heartbeat" || normalized == "opcheartbeat" || normalized == "modbusheartbeat" || normalized == "mxheartbeat" || normalized == "mxcomponentheartbeat" || normalized == "plcheartbeat" || normalized == "connectionheartbeat");
			}
			return result;
		}

		// Token: 0x06001D2A RID: 7466 RVA: 0x000A51A4 File Offset: 0x000A33A4
		private static bool IsOpcUaProtocol(string protocol)
		{
			return string.Equals(protocol, "OPC UA", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001D2B RID: 7467 RVA: 0x000A51C4 File Offset: 0x000A33C4
		private static string GetLegacyConfigPath()
		{
			string folder = RecipePathService.GetCurrentModelFolder();
			bool flag = string.IsNullOrWhiteSpace(folder);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = Path.Combine(folder, "communication_config.json");
			}
			return result;
		}

		// Token: 0x06001D2C RID: 7468 RVA: 0x000A51F8 File Offset: 0x000A33F8
		private static string FindLatestModelConfigPath(string currentPath, string legacyPath)
		{
			string result;
			try
			{
				bool flag = !Directory.Exists(Manager_path._dataPath);
				if (flag)
				{
					result = null;
				}
				else
				{
					result = (from x in (from dir in Directory.EnumerateDirectories(Manager_path._dataPath)
					select Path.Combine(dir, "communication_config.json")).Where(new Func<string, bool>(File.Exists))
					where !string.Equals(x, currentPath, StringComparison.OrdinalIgnoreCase) && !string.Equals(x, legacyPath, StringComparison.OrdinalIgnoreCase)
					select x).OrderByDescending(new Func<string, DateTime>(File.GetLastWriteTime)).FirstOrDefault<string>();
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06001D2D RID: 7469 RVA: 0x000A52B0 File Offset: 0x000A34B0
		public static void Save(IEnumerable<CommunicationConnection> connections, IEnumerable<CommunicationTagRow> tags, string configPath = null)
		{
			string path = string.IsNullOrWhiteSpace(configPath) ? CommunicationConfigStorageService.GetConfigPath() : configPath;
			CommunicationRuntimeSettings currentSettings = CommunicationConfigStorageService.LoadConfig(path).RuntimeSettings;
			CommunicationConfigStorageService.Save(connections, tags, currentSettings, path);
		}

		// Token: 0x06001D2E RID: 7470 RVA: 0x000A52E8 File Offset: 0x000A34E8
		public static void Save(IEnumerable<CommunicationConnection> connections, IEnumerable<CommunicationTagRow> tags, CommunicationRuntimeSettings runtimeSettings, string configPath = null)
		{
			List<CommunicationTagRow> tagList = (tags ?? Array.Empty<CommunicationTagRow>()).Select(new Func<CommunicationTagRow, CommunicationTagRow>(CommunicationConfigStorageService.CloneTag)).ToList<CommunicationTagRow>();
			Dictionary<string, List<CommunicationTagRow>> connectionTags = new Dictionary<string, List<CommunicationTagRow>>(StringComparer.OrdinalIgnoreCase);
			CommunicationConnection communicationConnection = (connections ?? Array.Empty<CommunicationConnection>()).FirstOrDefault<CommunicationConnection>();
			string key = (communicationConnection != null) ? communicationConnection.Name : null;
			bool flag = string.IsNullOrWhiteSpace(key);
			if (flag)
			{
				key = "Default";
			}
			connectionTags[key] = tagList;
			CommunicationConfigStorageService.Save(connections, connectionTags, runtimeSettings, configPath);
		}

		// Token: 0x06001D2F RID: 7471 RVA: 0x000A5364 File Offset: 0x000A3564
		public static void Save(IEnumerable<CommunicationConnection> connections, IDictionary<string, List<CommunicationTagRow>> connectionTags, CommunicationRuntimeSettings runtimeSettings, string configPath = null)
		{
			string path = string.IsNullOrWhiteSpace(configPath) ? CommunicationConfigStorageService.GetConfigPath() : configPath;
			string folder = Path.GetDirectoryName(path);
			bool flag = !string.IsNullOrWhiteSpace(folder);
			if (flag)
			{
				Directory.CreateDirectory(folder);
			}
			List<CommunicationConnection> connectionList = (connections ?? Array.Empty<CommunicationConnection>()).ToList<CommunicationConnection>();
			Dictionary<string, List<CommunicationTagRow>> normalizedConnectionTags = CommunicationConfigStorageService.NormalizeConnectionTags(connectionList, connectionTags);
			List<CommunicationTagRow> allTags = (from x in normalizedConnectionTags.Values
			where x != null
			select x).SelectMany((List<CommunicationTagRow> x) => x).Select(new Func<CommunicationTagRow, CommunicationTagRow>(CommunicationConfigStorageService.CloneTag)).ToList<CommunicationTagRow>();
			Dictionary<string, List<CommunicationInitialValueRow>> initialValues = CommunicationConfigStorageService._pendingInitialValues ?? CommunicationConfigStorageService.LoadConfig(path).InitialValues;
			CommunicationConfigStorageService._pendingInitialValues = null;
			string json = JsonConvert.SerializeObject(new CommunicationConfigData
			{
				Connections = connectionList,
				Tags = allTags,
				ConnectionTags = normalizedConnectionTags,
				InitialValues = (initialValues ?? new Dictionary<string, List<CommunicationInitialValueRow>>(StringComparer.OrdinalIgnoreCase)),
				RuntimeSettings = (runtimeSettings ?? new CommunicationRuntimeSettings())
			}, Formatting.Indented);
			File.WriteAllText(path, json);
			CommunicationConfigStorageService.LastSavePath = path;
		}

		// Token: 0x06001D30 RID: 7472 RVA: 0x000A5498 File Offset: 0x000A3698
		public static void Save(IEnumerable<CommunicationConnection> connections, string configPath = null)
		{
			CommunicationConfigStorageService.Save(connections, Enumerable.Empty<CommunicationTagRow>(), configPath);
		}

		// Token: 0x06001D31 RID: 7473 RVA: 0x000A54A8 File Offset: 0x000A36A8
		public static void Save(IEnumerable<CommunicationConnection> connections, IDictionary<string, List<CommunicationTagRow>> connectionTags, IDictionary<string, List<CommunicationInitialValueRow>> initialValues, CommunicationRuntimeSettings runtimeSettings, string configPath = null)
		{
			Dictionary<string, List<CommunicationInitialValueRow>> pendingInitialValues;
			if (initialValues != null)
			{
				pendingInitialValues = new Dictionary<string, List<CommunicationInitialValueRow>>(initialValues.ToDictionary((KeyValuePair<string, List<CommunicationInitialValueRow>> x) => x.Key, (KeyValuePair<string, List<CommunicationInitialValueRow>> x) => x.Value, StringComparer.OrdinalIgnoreCase), StringComparer.OrdinalIgnoreCase);
			}
			else
			{
				pendingInitialValues = new Dictionary<string, List<CommunicationInitialValueRow>>(StringComparer.OrdinalIgnoreCase);
			}
			CommunicationConfigStorageService._pendingInitialValues = pendingInitialValues;
			try
			{
				CommunicationConfigStorageService.Save(connections, connectionTags, runtimeSettings, configPath);
			}
			finally
			{
				CommunicationConfigStorageService._pendingInitialValues = null;
			}
		}

		// Token: 0x06001D32 RID: 7474 RVA: 0x000A5548 File Offset: 0x000A3748
		public static List<CommunicationInitialValueRow> GetInitialValuesForConnection(CommunicationConfigData config, string connectionName)
		{
			bool flag = ((config != null) ? config.InitialValues : null) == null || string.IsNullOrWhiteSpace(connectionName);
			List<CommunicationInitialValueRow> result;
			if (flag)
			{
				result = new List<CommunicationInitialValueRow>();
			}
			else
			{
				List<CommunicationInitialValueRow> rows;
				result = ((config.InitialValues.TryGetValue(connectionName.Trim(), out rows) && rows != null) ? rows : new List<CommunicationInitialValueRow>());
			}
			return result;
		}

		// Token: 0x06001D33 RID: 7475 RVA: 0x000A55A0 File Offset: 0x000A37A0
		private static Dictionary<string, List<CommunicationTagRow>> NormalizeConnectionTags(IEnumerable<CommunicationConnection> connections, IDictionary<string, List<CommunicationTagRow>> connectionTags)
		{
			Dictionary<string, List<CommunicationTagRow>> normalized = new Dictionary<string, List<CommunicationTagRow>>(StringComparer.OrdinalIgnoreCase);
			foreach (KeyValuePair<string, List<CommunicationTagRow>> entry in (connectionTags ?? new Dictionary<string, List<CommunicationTagRow>>()))
			{
				bool flag = string.IsNullOrWhiteSpace(entry.Key);
				if (!flag)
				{
					normalized[entry.Key.Trim()] = CommunicationConfigStorageService.CloneTags(entry.Value);
				}
			}
			foreach (CommunicationConnection connection in (connections ?? Array.Empty<CommunicationConnection>()))
			{
				bool flag2 = connection == null || string.IsNullOrWhiteSpace(connection.Name);
				if (!flag2)
				{
					bool flag3 = !normalized.ContainsKey(connection.Name);
					if (flag3)
					{
						normalized[connection.Name] = new List<CommunicationTagRow>();
					}
				}
			}
			return normalized;
		}

		// Token: 0x06001D34 RID: 7476 RVA: 0x000A56BC File Offset: 0x000A38BC
		private static List<CommunicationTagRow> CloneTags(IEnumerable<CommunicationTagRow> tags)
		{
			return (from x in tags ?? Array.Empty<CommunicationTagRow>()
			where x != null
			select x).Select(new Func<CommunicationTagRow, CommunicationTagRow>(CommunicationConfigStorageService.CloneTag)).ToList<CommunicationTagRow>();
		}

		// Token: 0x06001D35 RID: 7477 RVA: 0x000A5714 File Offset: 0x000A3914
		private static CommunicationTagRow CloneTag(CommunicationTagRow source)
		{
			bool flag = source == null;
			CommunicationTagRow result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new CommunicationTagRow
				{
					Group = source.Group,
					Name = source.Name,
					Address = source.Address,
					DataType = source.DataType,
					ReadWrite = source.ReadWrite,
					LinkedToolName = source.LinkedToolName,
					ResultField = source.ResultField,
					MaxResultCount = source.MaxResultCount,
					Description = source.Description
				};
			}
			return result;
		}

		// Token: 0x04000C56 RID: 3158
		private const string FileName = "communication_config.json";

		// Token: 0x04000C5A RID: 3162
		[ThreadStatic]
		private static Dictionary<string, List<CommunicationInitialValueRow>> _pendingInitialValues;
	}
}
