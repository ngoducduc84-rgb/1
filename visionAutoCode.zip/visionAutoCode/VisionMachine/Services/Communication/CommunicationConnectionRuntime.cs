﻿using System;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200020C RID: 524
	internal sealed class CommunicationConnectionRuntime : IDisposable
	{
		// Token: 0x06001E8F RID: 7823 RVA: 0x000B14FC File Offset: 0x000AF6FC
		public CommunicationConnectionRuntime(CommunicationConnection connection, IPlcCommunicationClient client)
		{
			if (client == null)
			{
				throw new ArgumentNullException("client");
			}
			this.Client = client;
			this.ConnectionName = CommunicationConnectionRuntime.NormalizeName((connection != null) ? connection.Name : null);
			this.Protocol = CommunicationConnectionRuntime.NormalizeProtocol((connection != null) ? connection.Protocol : null);
			this.Key = CommunicationConnectionRuntime.MakeKey(connection);
		}

		// Token: 0x17000940 RID: 2368
		// (get) Token: 0x06001E90 RID: 7824 RVA: 0x000B156C File Offset: 0x000AF76C
		public string Key { get; }

		// Token: 0x17000941 RID: 2369
		// (get) Token: 0x06001E91 RID: 7825 RVA: 0x000B1574 File Offset: 0x000AF774
		public string ConnectionName { get; }

		// Token: 0x17000942 RID: 2370
		// (get) Token: 0x06001E92 RID: 7826 RVA: 0x000B157C File Offset: 0x000AF77C
		public string Protocol { get; }

		// Token: 0x17000943 RID: 2371
		// (get) Token: 0x06001E93 RID: 7827 RVA: 0x000B1584 File Offset: 0x000AF784
		public IPlcCommunicationClient Client { get; }

		// Token: 0x17000944 RID: 2372
		// (get) Token: 0x06001E94 RID: 7828 RVA: 0x000B158C File Offset: 0x000AF78C
		public object IoLock { get; } = new object();

		// Token: 0x17000945 RID: 2373
		// (get) Token: 0x06001E95 RID: 7829 RVA: 0x000B1594 File Offset: 0x000AF794
		public bool IsConnected
		{
			get
			{
				return this.Client != null && this.Client.IsConnectionAlive;
			}
		}

		// Token: 0x06001E96 RID: 7830 RVA: 0x000B15AC File Offset: 0x000AF7AC
		public static string MakeKey(CommunicationConnection connection)
		{
			return CommunicationConnectionRuntime.NormalizeProtocol((connection != null) ? connection.Protocol : null) + "::" + CommunicationConnectionRuntime.NormalizeName((connection != null) ? connection.Name : null);
		}

		// Token: 0x06001E97 RID: 7831 RVA: 0x000B15EC File Offset: 0x000AF7EC
		private static string NormalizeProtocol(string protocol)
		{
			return string.IsNullOrWhiteSpace(protocol) ? "__unknown_protocol__" : protocol.Trim();
		}

		// Token: 0x06001E98 RID: 7832 RVA: 0x000B1614 File Offset: 0x000AF814
		private static string NormalizeName(string name)
		{
			return string.IsNullOrWhiteSpace(name) ? "__unnamed_connection__" : name.Trim();
		}

		// Token: 0x06001E99 RID: 7833 RVA: 0x000B163B File Offset: 0x000AF83B
		public void Dispose()
		{
			this.Client.Dispose();
		}
	}
}
