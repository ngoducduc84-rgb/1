﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F6 RID: 502
	public sealed class CommunicationHealthChangedEventArgs : EventArgs
	{
		// Token: 0x06001DAF RID: 7599 RVA: 0x000A84A7 File Offset: 0x000A66A7
		public CommunicationHealthChangedEventArgs(CommunicationHealthState state)
		{
			this.State = state;
		}

		// Token: 0x1700092D RID: 2349
		// (get) Token: 0x06001DB0 RID: 7600 RVA: 0x000A84B8 File Offset: 0x000A66B8
		public CommunicationHealthState State { get; }
	}
}
