﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F5 RID: 501
	public sealed class CommunicationHealthState
	{
		// Token: 0x17000925 RID: 2341
		// (get) Token: 0x06001D9E RID: 7582 RVA: 0x000A841F File Offset: 0x000A661F
		// (set) Token: 0x06001D9F RID: 7583 RVA: 0x000A8427 File Offset: 0x000A6627
		public string ConnectionName { get; set; }

		// Token: 0x17000926 RID: 2342
		// (get) Token: 0x06001DA0 RID: 7584 RVA: 0x000A8430 File Offset: 0x000A6630
		// (set) Token: 0x06001DA1 RID: 7585 RVA: 0x000A8438 File Offset: 0x000A6638
		public bool IsConnected { get; set; }

		// Token: 0x17000927 RID: 2343
		// (get) Token: 0x06001DA2 RID: 7586 RVA: 0x000A8441 File Offset: 0x000A6641
		// (set) Token: 0x06001DA3 RID: 7587 RVA: 0x000A8449 File Offset: 0x000A6649
		public string Message { get; set; }

		// Token: 0x17000928 RID: 2344
		// (get) Token: 0x06001DA4 RID: 7588 RVA: 0x000A8452 File Offset: 0x000A6652
		// (set) Token: 0x06001DA5 RID: 7589 RVA: 0x000A845A File Offset: 0x000A665A
		public DateTime LastUpdate { get; set; }

		// Token: 0x17000929 RID: 2345
		// (get) Token: 0x06001DA6 RID: 7590 RVA: 0x000A8463 File Offset: 0x000A6663
		// (set) Token: 0x06001DA7 RID: 7591 RVA: 0x000A846B File Offset: 0x000A666B
		public bool IsHeartbeatPulse { get; set; }

		// Token: 0x1700092A RID: 2346
		// (get) Token: 0x06001DA8 RID: 7592 RVA: 0x000A8474 File Offset: 0x000A6674
		// (set) Token: 0x06001DA9 RID: 7593 RVA: 0x000A847C File Offset: 0x000A667C
		public bool HasHeartbeatValue { get; set; }

		// Token: 0x1700092B RID: 2347
		// (get) Token: 0x06001DAA RID: 7594 RVA: 0x000A8485 File Offset: 0x000A6685
		// (set) Token: 0x06001DAB RID: 7595 RVA: 0x000A848D File Offset: 0x000A668D
		public bool HeartbeatValue { get; set; }

		// Token: 0x1700092C RID: 2348
		// (get) Token: 0x06001DAC RID: 7596 RVA: 0x000A8496 File Offset: 0x000A6696
		// (set) Token: 0x06001DAD RID: 7597 RVA: 0x000A849E File Offset: 0x000A669E
		public long HeartbeatSequence { get; set; }
	}
}
