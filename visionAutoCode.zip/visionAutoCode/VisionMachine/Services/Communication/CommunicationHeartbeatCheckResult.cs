﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001ED RID: 493
	internal sealed class CommunicationHeartbeatCheckResult
	{
		// Token: 0x1700091C RID: 2332
		// (get) Token: 0x06001D5C RID: 7516 RVA: 0x000A67A2 File Offset: 0x000A49A2
		// (set) Token: 0x06001D5D RID: 7517 RVA: 0x000A67AA File Offset: 0x000A49AA
		public bool Success { get; private set; }

		// Token: 0x1700091D RID: 2333
		// (get) Token: 0x06001D5E RID: 7518 RVA: 0x000A67B3 File Offset: 0x000A49B3
		// (set) Token: 0x06001D5F RID: 7519 RVA: 0x000A67BB File Offset: 0x000A49BB
		public string Message { get; private set; }

		// Token: 0x1700091E RID: 2334
		// (get) Token: 0x06001D60 RID: 7520 RVA: 0x000A67C4 File Offset: 0x000A49C4
		// (set) Token: 0x06001D61 RID: 7521 RVA: 0x000A67CC File Offset: 0x000A49CC
		public bool IsHeartbeatPulse { get; private set; }

		// Token: 0x1700091F RID: 2335
		// (get) Token: 0x06001D62 RID: 7522 RVA: 0x000A67D5 File Offset: 0x000A49D5
		// (set) Token: 0x06001D63 RID: 7523 RVA: 0x000A67DD File Offset: 0x000A49DD
		public bool HasHeartbeatValue { get; private set; }

		// Token: 0x17000920 RID: 2336
		// (get) Token: 0x06001D64 RID: 7524 RVA: 0x000A67E6 File Offset: 0x000A49E6
		// (set) Token: 0x06001D65 RID: 7525 RVA: 0x000A67EE File Offset: 0x000A49EE
		public bool HeartbeatValue { get; private set; }

		// Token: 0x06001D66 RID: 7526 RVA: 0x000A67F8 File Offset: 0x000A49F8
		public static CommunicationHeartbeatCheckResult Ok(string message)
		{
			return CommunicationHeartbeatCheckResult.Ok(message, false);
		}

		// Token: 0x06001D67 RID: 7527 RVA: 0x000A6814 File Offset: 0x000A4A14
		public static CommunicationHeartbeatCheckResult Ok(string message, bool isHeartbeatPulse)
		{
			return CommunicationHeartbeatCheckResult.Ok(message, isHeartbeatPulse, false, false);
		}

		// Token: 0x06001D68 RID: 7528 RVA: 0x000A6830 File Offset: 0x000A4A30
		public static CommunicationHeartbeatCheckResult Ok(string message, bool isHeartbeatPulse, bool hasHeartbeatValue, bool heartbeatValue)
		{
			return new CommunicationHeartbeatCheckResult
			{
				Success = true,
				Message = message,
				IsHeartbeatPulse = isHeartbeatPulse,
				HasHeartbeatValue = hasHeartbeatValue,
				HeartbeatValue = heartbeatValue
			};
		}

		// Token: 0x06001D69 RID: 7529 RVA: 0x000A6870 File Offset: 0x000A4A70
		public static CommunicationHeartbeatCheckResult Fail(string message)
		{
			return new CommunicationHeartbeatCheckResult
			{
				Success = false,
				Message = message,
				IsHeartbeatPulse = false,
				HasHeartbeatValue = false,
				HeartbeatValue = false
			};
		}

		// Token: 0x06001D6A RID: 7530 RVA: 0x000A68B0 File Offset: 0x000A4AB0
		public static CommunicationHeartbeatCheckResult Fail(string message, bool hasHeartbeatValue, bool heartbeatValue)
		{
			return new CommunicationHeartbeatCheckResult
			{
				Success = false,
				Message = message,
				IsHeartbeatPulse = false,
				HasHeartbeatValue = hasHeartbeatValue,
				HeartbeatValue = heartbeatValue
			};
		}
	}
}
