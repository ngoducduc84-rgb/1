﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001EC RID: 492
	internal static class CommunicationHeartbeatMonitorHelper
	{
		// Token: 0x06001D44 RID: 7492 RVA: 0x000A5880 File Offset: 0x000A3A80
		internal static CommunicationHeartbeatCheckResult CheckHeartbeat(PlcCommunicationService communicationService, CommunicationConnection connection, CommunicationTagRow heartbeatTag, string configPath, string protocolLabel)
		{
			string label = string.IsNullOrWhiteSpace(protocolLabel) ? "Connection" : protocolLabel.Trim();
			bool flag = heartbeatTag == null || !CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(heartbeatTag.Address);
			CommunicationHeartbeatCheckResult result;
			if (flag)
			{
				result = CommunicationHeartbeatCheckResult.Ok(label + " heartbeat is not configured.");
			}
			else
			{
				CommunicationTagRow readTag = new CommunicationTagRow
				{
					Name = heartbeatTag.Name,
					Address = heartbeatTag.Address,
					DataType = "BOOL",
					ReadWrite = "Read",
					Group = heartbeatTag.Group,
					Description = heartbeatTag.Description
				};
				CommunicationReadResult readResult = CommunicationHeartbeatMonitorHelper.ReadHeartbeatWithTimeout(communicationService, connection, readTag, label);
				bool flag2 = !readResult.Success;
				if (flag2)
				{
					bool flag3 = CommunicationHeartbeatMonitorHelper.IsIoBusy(readResult.Message);
					if (flag3)
					{
						result = CommunicationHeartbeatCheckResult.Ok(label + " heartbeat skipped because PLC I/O is busy.");
					}
					else
					{
						result = CommunicationHeartbeatCheckResult.Fail(label + " heartbeat read failed: " + readResult.Message);
					}
				}
				else
				{
					CommunicationMonitorRow row = readResult.Rows.FirstOrDefault<CommunicationMonitorRow>();
					bool flag4 = row == null || !string.Equals(row.Quality, "Good", StringComparison.OrdinalIgnoreCase);
					if (flag4)
					{
						CommunicationHeartbeatMonitorHelper.ClearHeartbeatState(configPath, connection.Name);
						string valueText = (row == null) ? "No value returned." : row.Value;
						result = CommunicationHeartbeatCheckResult.Fail(label + " heartbeat quality is bad: " + valueText);
					}
					else
					{
						bool actualValue;
						bool flag5 = !CommunicationHeartbeatMonitorHelper.TryParseHeartbeatValue(row.Value, out actualValue);
						if (flag5)
						{
							CommunicationHeartbeatMonitorHelper.ClearHeartbeatState(configPath, connection.Name);
							result = CommunicationHeartbeatCheckResult.Fail(label + " heartbeat value is not BOOL: " + (row.Value ?? string.Empty));
						}
						else
						{
							string key = CommunicationHeartbeatMonitorHelper.GetHeartbeatKey(configPath, connection.Name);
							DateTime now = DateTime.UtcNow;
							Dictionary<string, CommunicationHeartbeatMonitorHelper.HeartbeatState> heartbeatStates = CommunicationHeartbeatMonitorHelper.HeartbeatStates;
							lock (heartbeatStates)
							{
								CommunicationHeartbeatMonitorHelper.HeartbeatState state;
								bool flag7 = !CommunicationHeartbeatMonitorHelper.HeartbeatStates.TryGetValue(key, out state);
								if (flag7)
								{
									CommunicationHeartbeatMonitorHelper.HeartbeatStates[key] = new CommunicationHeartbeatMonitorHelper.HeartbeatState
									{
										LastValue = actualValue,
										LastChangeUtc = now
									};
									result = CommunicationHeartbeatCheckResult.Ok(label + " heartbeat initialized: " + CommunicationHeartbeatMonitorHelper.FormatHeartbeatValue(actualValue), true, true, actualValue);
								}
								else
								{
									bool flag8 = state.LastValue != actualValue;
									if (flag8)
									{
										state.LastValue = actualValue;
										state.LastChangeUtc = now;
										result = CommunicationHeartbeatCheckResult.Ok(label + " heartbeat changed: " + CommunicationHeartbeatMonitorHelper.FormatHeartbeatValue(actualValue), true, true, actualValue);
									}
									else
									{
										bool fresh = (now - state.LastChangeUtc).TotalMilliseconds <= 2500.0;
										bool flag9 = !fresh;
										if (flag9)
										{
											result = CommunicationHeartbeatCheckResult.Fail(string.Concat(new string[]
											{
												label,
												" heartbeat stale. Value stayed ",
												CommunicationHeartbeatMonitorHelper.FormatHeartbeatValue(actualValue),
												" for more than ",
												2500.ToString(),
												" ms."
											}), true, actualValue);
										}
										else
										{
											result = CommunicationHeartbeatCheckResult.Ok(label + " heartbeat alive: " + CommunicationHeartbeatMonitorHelper.FormatHeartbeatValue(actualValue), false, true, actualValue);
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001D45 RID: 7493 RVA: 0x000A5BD8 File Offset: 0x000A3DD8
		internal static CommunicationReadResult ReadHeartbeatWithTimeout(PlcCommunicationService communicationService, CommunicationConnection connection, CommunicationTagRow readTag, string protocolLabel)
		{
			string label = string.IsNullOrWhiteSpace(protocolLabel) ? "Connection" : protocolLabel.Trim();
			CommunicationReadResult result;
			try
			{
				Task<CommunicationReadResult> readTask = Task.Run<CommunicationReadResult>(() => communicationService.ReadAll(connection, new CommunicationTagRow[]
				{
					readTag
				}));
				bool flag = readTask.Wait(800);
				if (flag)
				{
					result = readTask.Result;
				}
				else
				{
					communicationService.Disconnect(connection);
					result = CommunicationReadResult.Fail(label + " heartbeat read timeout after " + 800.ToString() + " ms.");
				}
			}
			catch (AggregateException ex)
			{
				communicationService.Disconnect(connection);
				string str = label;
				string str2 = " heartbeat read failed: ";
				Exception baseException = ex.GetBaseException();
				result = CommunicationReadResult.Fail(str + str2 + (((baseException != null) ? baseException.Message : null) ?? ex.Message));
			}
			catch (Exception ex2)
			{
				communicationService.Disconnect(connection);
				result = CommunicationReadResult.Fail(label + " heartbeat read failed: " + ex2.Message);
			}
			return result;
		}

		// Token: 0x06001D46 RID: 7494 RVA: 0x000A5D14 File Offset: 0x000A3F14
		internal static void ClearHeartbeatState(string configPath, string connectionName)
		{
			Dictionary<string, CommunicationHeartbeatMonitorHelper.HeartbeatState> heartbeatStates = CommunicationHeartbeatMonitorHelper.HeartbeatStates;
			lock (heartbeatStates)
			{
				CommunicationHeartbeatMonitorHelper.HeartbeatStates.Remove(CommunicationHeartbeatMonitorHelper.GetHeartbeatKey(configPath, connectionName));
			}
		}

		// Token: 0x06001D47 RID: 7495 RVA: 0x000A5D64 File Offset: 0x000A3F64
		internal static CommunicationTagRow FindHeartbeatTag(IEnumerable<CommunicationTagRow> tags)
		{
			return (from x in tags ?? Enumerable.Empty<CommunicationTagRow>()
			where x != null
			select x).FirstOrDefault((CommunicationTagRow x) => CommunicationHeartbeatMonitorHelper.IsHeartbeatTagName(x.Name) && CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(x.Address));
		}

		// Token: 0x06001D48 RID: 7496 RVA: 0x000A5DC8 File Offset: 0x000A3FC8
		internal static CommunicationTagRow FindModbusTransportProbeTag(IEnumerable<CommunicationTagRow> tags, CommunicationConnection connection)
		{
			CommunicationTagRow configuredTag = (from x in tags ?? Enumerable.Empty<CommunicationTagRow>()
			where x != null
			select x).FirstOrDefault((CommunicationTagRow x) => !CommunicationHeartbeatMonitorHelper.IsHeartbeatTagName(x.Name) && CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(x.Address) && CommunicationHeartbeatMonitorHelper.IsReadTag(x) && !CommunicationHeartbeatMonitorHelper.LooksLikeOpcNodeId(x.Address));
			bool flag = configuredTag != null;
			CommunicationTagRow result;
			if (flag)
			{
				result = new CommunicationTagRow
				{
					Name = (string.IsNullOrWhiteSpace(configuredTag.Name) ? "modbus transport probe" : configuredTag.Name),
					Address = configuredTag.Address,
					DataType = (string.IsNullOrWhiteSpace(configuredTag.DataType) ? "UINT16" : configuredTag.DataType),
					ReadWrite = "Read",
					Group = configuredTag.Group,
					Description = configuredTag.Description
				};
			}
			else
			{
				string probeAddress = (connection == null || string.IsNullOrWhiteSpace(connection.MonitorStartAddress)) ? "40001" : connection.MonitorStartAddress;
				result = new CommunicationTagRow
				{
					Name = "modbus transport probe",
					Address = probeAddress,
					DataType = ((connection == null || string.IsNullOrWhiteSpace(connection.MonitorDataType)) ? "UINT16" : connection.MonitorDataType),
					ReadWrite = "Read",
					Group = "Connection Health",
					Description = "Auto reconnect transport probe."
				};
			}
			return result;
		}

		// Token: 0x06001D49 RID: 7497 RVA: 0x000A5F38 File Offset: 0x000A4138
		internal static CommunicationHeartbeatCheckResult CheckModbusTransportProbe(PlcCommunicationService communicationService, CommunicationConnection connection, CommunicationTagRow probeTag)
		{
			bool flag = probeTag == null || string.IsNullOrWhiteSpace(probeTag.Address);
			CommunicationHeartbeatCheckResult result;
			if (flag)
			{
				result = CommunicationHeartbeatCheckResult.Ok("Modbus transport probe is not configured.");
			}
			else
			{
				CommunicationReadResult readResult = CommunicationHeartbeatMonitorHelper.ReadHeartbeatWithTimeout(communicationService, connection, probeTag, "Modbus transport probe");
				bool flag2 = !readResult.Success;
				if (flag2)
				{
					bool flag3 = CommunicationHeartbeatMonitorHelper.IsIoBusy(readResult.Message);
					if (flag3)
					{
						result = CommunicationHeartbeatCheckResult.Ok("Modbus transport probe skipped because PLC I/O is busy.");
					}
					else
					{
						result = CommunicationHeartbeatCheckResult.Fail("Modbus transport probe failed: " + readResult.Message);
					}
				}
				else
				{
					CommunicationMonitorRow row = readResult.Rows.FirstOrDefault<CommunicationMonitorRow>();
					bool flag4 = row == null;
					if (flag4)
					{
						result = CommunicationHeartbeatCheckResult.Ok("Modbus transport probe returned no value.");
					}
					else
					{
						bool flag5 = !string.Equals(row.Quality, "Good", StringComparison.OrdinalIgnoreCase);
						if (flag5)
						{
							result = CommunicationHeartbeatCheckResult.Ok("Modbus transport probe reached PLC but register quality is bad: " + (row.Value ?? string.Empty));
						}
						else
						{
							result = CommunicationHeartbeatCheckResult.Ok("Modbus transport probe OK.");
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001D4A RID: 7498 RVA: 0x000A6030 File Offset: 0x000A4230
		internal static CommunicationHeartbeatCheckResult CheckMxComponentTransportProbe(PlcCommunicationService communicationService, CommunicationConnection connection)
		{
			bool flag = communicationService == null || connection == null;
			CommunicationHeartbeatCheckResult result2;
			if (flag)
			{
				result2 = CommunicationHeartbeatCheckResult.Fail("MX Component transport probe is not available.");
			}
			else
			{
				try
				{
					Task<CommunicationOperationResult> probeTask = Task.Run<CommunicationOperationResult>(() => communicationService.Test(connection));
					bool flag2 = !probeTask.Wait(800);
					if (flag2)
					{
						communicationService.Disconnect(connection);
						result2 = CommunicationHeartbeatCheckResult.Fail("MX Component transport probe timed out after " + 800.ToString() + " ms.");
					}
					else
					{
						CommunicationOperationResult result = probeTask.Result;
						result2 = (result.Success ? CommunicationHeartbeatCheckResult.Ok(result.Message) : CommunicationHeartbeatCheckResult.Fail("MX Component transport probe failed: " + result.Message));
					}
				}
				catch (AggregateException ex)
				{
					communicationService.Disconnect(connection);
					string str = "MX Component transport probe failed: ";
					Exception baseException = ex.GetBaseException();
					result2 = CommunicationHeartbeatCheckResult.Fail(str + (((baseException != null) ? baseException.Message : null) ?? ex.Message));
				}
				catch (Exception ex2)
				{
					communicationService.Disconnect(connection);
					result2 = CommunicationHeartbeatCheckResult.Fail("MX Component transport probe failed: " + ex2.Message);
				}
			}
			return result2;
		}

		// Token: 0x06001D4B RID: 7499 RVA: 0x000A61A8 File Offset: 0x000A43A8
		internal static bool IsModbusProtocol(string protocol)
		{
			return string.Equals(protocol, "Modbus Client TCP/IP", StringComparison.OrdinalIgnoreCase) || string.Equals(protocol, "Modbus Server TCP/IP", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001D4C RID: 7500 RVA: 0x000A61D8 File Offset: 0x000A43D8
		internal static bool IsOpcUaProtocol(string protocol)
		{
			return string.Equals(protocol, "OPC UA", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001D4D RID: 7501 RVA: 0x000A61F8 File Offset: 0x000A43F8
		internal static bool IsMxComponentProtocol(string protocol)
		{
			return string.Equals(protocol, "MX Component", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001D4E RID: 7502 RVA: 0x000A6218 File Offset: 0x000A4418
		internal static bool IsAutoReconnectCandidate(CommunicationConnection connection)
		{
			return CommunicationHeartbeatMonitorHelper.IsAutoConnectCandidate(connection) && (connection.AutoReconnect || CommunicationHeartbeatMonitorHelper.IsModbusProtocol(connection.Protocol) || CommunicationHeartbeatMonitorHelper.IsOpcUaProtocol(connection.Protocol) || CommunicationHeartbeatMonitorHelper.IsMxComponentProtocol(connection.Protocol));
		}

		// Token: 0x06001D4F RID: 7503 RVA: 0x000A6268 File Offset: 0x000A4468
		internal static bool IsAutoConnectCandidate(CommunicationConnection connection)
		{
			bool flag = connection == null || string.IsNullOrWhiteSpace(connection.Name);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = CommunicationHeartbeatMonitorHelper.IsMxComponentProtocol(connection.Protocol);
				if (flag2)
				{
					result = MxComponentRuntime.IsInstalled;
				}
				else
				{
					result = (CommunicationHeartbeatMonitorHelper.IsModbusProtocol(connection.Protocol) || CommunicationHeartbeatMonitorHelper.IsOpcUaProtocol(connection.Protocol));
				}
			}
			return result;
		}

		// Token: 0x06001D50 RID: 7504 RVA: 0x000A62C8 File Offset: 0x000A44C8
		internal static void NormalizeConnection(CommunicationConnection connection)
		{
			bool flag = connection == null;
			if (!flag)
			{
				bool flag2 = string.IsNullOrWhiteSpace(connection.Protocol);
				if (flag2)
				{
					connection.Protocol = "Modbus Client TCP/IP";
				}
				bool flag3 = connection.Port <= 0 && !CommunicationHeartbeatMonitorHelper.IsMxComponentProtocol(connection.Protocol);
				if (flag3)
				{
					connection.ApplyDefaultPort();
				}
				bool flag4 = connection.TimeoutMs <= 0;
				if (flag4)
				{
					connection.TimeoutMs = 2000;
				}
				bool flag5 = connection.Protocol == "Modbus Server TCP/IP";
				if (flag5)
				{
					connection.IpAddress = "0.0.0.0";
				}
			}
		}

		// Token: 0x06001D51 RID: 7505 RVA: 0x000A6360 File Offset: 0x000A4560
		internal static CommunicationConnection CreateHealthMonitorConnection(CommunicationConnection source)
		{
			bool flag = source == null;
			CommunicationConnection result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new CommunicationConnection
				{
					Name = source.Name,
					Protocol = source.Protocol,
					Description = source.Description,
					IpAddress = source.IpAddress,
					Port = source.Port,
					LogicalStationNumber = source.LogicalStationNumber,
					TimeoutMs = (CommunicationHeartbeatMonitorHelper.IsOpcUaProtocol(source.Protocol) ? Math.Max(300, Math.Min((source.TimeoutMs <= 0) ? 800 : source.TimeoutMs, 800)) : source.TimeoutMs),
					ExchangeInterval = source.ExchangeInterval,
					ByteOrder = source.ByteOrder,
					WordOrder = source.WordOrder,
					FloatFormat = source.FloatFormat,
					KeepAlive = source.KeepAlive,
					AutoReconnect = source.AutoReconnect,
					MonitorStartAddress = source.MonitorStartAddress,
					MonitorEndAddress = source.MonitorEndAddress,
					MonitorDataType = source.MonitorDataType,
					MonitorFunctionCode = source.MonitorFunctionCode
				};
			}
			return result;
		}

		// Token: 0x06001D52 RID: 7506 RVA: 0x000A649C File Offset: 0x000A469C
		internal static CommunicationConnection CreateModbusReconnectConnection(CommunicationConnection source)
		{
			CommunicationConnection connection = CommunicationHeartbeatMonitorHelper.CreateHealthMonitorConnection(source);
			bool flag = connection == null;
			CommunicationConnection result;
			if (flag)
			{
				result = null;
			}
			else
			{
				connection.TimeoutMs = Math.Max(200, Math.Min((connection.TimeoutMs <= 0) ? 500 : connection.TimeoutMs, 500));
				result = connection;
			}
			return result;
		}

		// Token: 0x06001D53 RID: 7507 RVA: 0x000A64F4 File Offset: 0x000A46F4
		private static bool IsReadTag(CommunicationTagRow tag)
		{
			string readWrite = ((tag != null) ? tag.ReadWrite : null) ?? string.Empty;
			return readWrite.IndexOf("Read", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x06001D54 RID: 7508 RVA: 0x000A6530 File Offset: 0x000A4730
		private static bool LooksLikeOpcNodeId(string address)
		{
			return !string.IsNullOrWhiteSpace(address) && address.TrimStart(Array.Empty<char>()).StartsWith("ns=", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001D55 RID: 7509 RVA: 0x000A6564 File Offset: 0x000A4764
		internal static bool IsConfiguredAddress(string address)
		{
			bool flag = string.IsNullOrWhiteSpace(address);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string text = address.Trim();
				result = (!string.Equals(text, "None", StringComparison.OrdinalIgnoreCase) && !string.Equals(text, "--", StringComparison.OrdinalIgnoreCase) && !string.Equals(text, "N/A", StringComparison.OrdinalIgnoreCase) && !string.Equals(text, "NA", StringComparison.OrdinalIgnoreCase) && !string.Equals(text, "Null", StringComparison.OrdinalIgnoreCase));
			}
			return result;
		}

		// Token: 0x06001D56 RID: 7510 RVA: 0x000A65D8 File Offset: 0x000A47D8
		private static bool TryParseHeartbeatValue(string value, out bool result)
		{
			result = false;
			string text = (value ?? string.Empty).Trim();
			bool flag = string.Equals(text, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "TRUE", StringComparison.OrdinalIgnoreCase) || text == "1";
			bool result2;
			if (flag)
			{
				result = true;
				result2 = true;
			}
			else
			{
				bool flag2 = string.Equals(text, "OFF", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "FALSE", StringComparison.OrdinalIgnoreCase) || text == "0";
				if (flag2)
				{
					result = false;
					result2 = true;
				}
				else
				{
					result2 = false;
				}
			}
			return result2;
		}

		// Token: 0x06001D57 RID: 7511 RVA: 0x000A666C File Offset: 0x000A486C
		private static bool IsIoBusy(string message)
		{
			return !string.IsNullOrWhiteSpace(message) && message.IndexOf("PLC I/O is busy", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x06001D58 RID: 7512 RVA: 0x000A669C File Offset: 0x000A489C
		private static string FormatHeartbeatValue(bool value)
		{
			return value ? "ON" : "OFF";
		}

		// Token: 0x06001D59 RID: 7513 RVA: 0x000A66C0 File Offset: 0x000A48C0
		private static string GetHeartbeatKey(string configPath, string connectionName)
		{
			return (configPath ?? string.Empty) + "|" + (connectionName ?? string.Empty);
		}

		// Token: 0x06001D5A RID: 7514 RVA: 0x000A66F0 File Offset: 0x000A48F0
		private static bool IsHeartbeatTagName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string normalized = new string(name.Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
				result = (normalized == "heartbeat" || normalized == "opcheartbeat" || normalized == "modbusheartbeat" || normalized == "mxheartbeat" || normalized == "mxcomponentheartbeat" || normalized == "plcheartbeat" || normalized == "connectionheartbeat");
			}
			return result;
		}

		// Token: 0x04000C61 RID: 3169
		internal const int PollIntervalMs = 200;

		// Token: 0x04000C62 RID: 3170
		internal const int GeneralHealthCheckIntervalMs = 500;

		// Token: 0x04000C63 RID: 3171
		internal const int HeartbeatReadTimeoutMs = 800;

		// Token: 0x04000C64 RID: 3172
		internal const int HeartbeatStaleMs = 2500;

		// Token: 0x04000C65 RID: 3173
		internal const int OpcReconnectRetryDelayMs = 200;

		// Token: 0x04000C66 RID: 3174
		private static readonly Dictionary<string, CommunicationHeartbeatMonitorHelper.HeartbeatState> HeartbeatStates = new Dictionary<string, CommunicationHeartbeatMonitorHelper.HeartbeatState>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x02000444 RID: 1092
		private sealed class HeartbeatState
		{
			// Token: 0x17000B81 RID: 2945
			// (get) Token: 0x06002B9A RID: 11162 RVA: 0x000EA2FB File Offset: 0x000E84FB
			// (set) Token: 0x06002B9B RID: 11163 RVA: 0x000EA303 File Offset: 0x000E8503
			public bool LastValue { get; set; }

			// Token: 0x17000B82 RID: 2946
			// (get) Token: 0x06002B9C RID: 11164 RVA: 0x000EA30C File Offset: 0x000E850C
			// (set) Token: 0x06002B9D RID: 11165 RVA: 0x000EA314 File Offset: 0x000E8514
			public DateTime LastChangeUtc { get; set; }
		}
	}
}
