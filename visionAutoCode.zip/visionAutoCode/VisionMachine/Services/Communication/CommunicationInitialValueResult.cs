﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001EE RID: 494
	public sealed class CommunicationInitialValueResult
	{
		// Token: 0x17000921 RID: 2337
		// (get) Token: 0x06001D6C RID: 7532 RVA: 0x000A68EF File Offset: 0x000A4AEF
		// (set) Token: 0x06001D6D RID: 7533 RVA: 0x000A68F7 File Offset: 0x000A4AF7
		public int WrittenCount { get; set; }

		// Token: 0x17000922 RID: 2338
		// (get) Token: 0x06001D6E RID: 7534 RVA: 0x000A6900 File Offset: 0x000A4B00
		// (set) Token: 0x06001D6F RID: 7535 RVA: 0x000A6908 File Offset: 0x000A4B08
		public int SkippedCount { get; set; }

		// Token: 0x17000923 RID: 2339
		// (get) Token: 0x06001D70 RID: 7536 RVA: 0x000A6911 File Offset: 0x000A4B11
		// (set) Token: 0x06001D71 RID: 7537 RVA: 0x000A6919 File Offset: 0x000A4B19
		public int ParkedCount { get; set; }

		// Token: 0x17000924 RID: 2340
		// (get) Token: 0x06001D72 RID: 7538 RVA: 0x000A6922 File Offset: 0x000A4B22
		public List<string> Errors { get; } = new List<string>();
	}
}
