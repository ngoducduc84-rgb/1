﻿using System;
using System.Collections.Generic;
using System.Linq;
using VisionMachine.Models.Communication;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001EF RID: 495
	public static class CommunicationInitialValueService
	{
		// Token: 0x06001D74 RID: 7540 RVA: 0x000A6940 File Offset: 0x000A4B40
		public static CommunicationInitialValueResult WriteCurrentModel(string configPath = null)
		{
			string path = string.IsNullOrWhiteSpace(configPath) ? CommunicationConfigStorageService.GetConfigPath() : configPath;
			CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(path);
			return CommunicationInitialValueService.Write(config, SharedCommunicationService.Instance);
		}

		// Token: 0x06001D75 RID: 7541 RVA: 0x000A6978 File Offset: 0x000A4B78
		public static CommunicationInitialValueResult Write(CommunicationConfigData config, PlcCommunicationService service)
		{
			CommunicationInitialValueResult result = new CommunicationInitialValueResult();
			bool flag = ((config != null) ? config.Connections : null) == null || service == null;
			CommunicationInitialValueResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (CommunicationConnection connection in from x in config.Connections
				where x != null
				select x)
				{
					List<CommunicationInitialValueRow> configured = CommunicationConfigStorageService.GetInitialValuesForConnection(config, connection.Name).Where((CommunicationInitialValueRow x) => x != null).ToList<CommunicationInitialValueRow>();
					List<CommunicationInitialValueRow> rows = configured.Where(new Func<CommunicationInitialValueRow, bool>(CommunicationInitialValueService.IsWritable)).ToList<CommunicationInitialValueRow>();
					result.ParkedCount += configured.Count - rows.Count;
					bool flag2 = rows.Count == 0;
					if (!flag2)
					{
						bool flag3 = !CommunicationOptions.SupportsTagReadWrite(connection.Protocol);
						if (flag3)
						{
							result.SkippedCount += rows.Count;
							result.Errors.Add(string.Concat(new string[]
							{
								"'",
								connection.Name,
								"' uses ",
								connection.Protocol,
								", which cannot address registers - ",
								rows.Count.ToString(),
								" initial value(s) skipped."
							}));
						}
						else
						{
							CommunicationInitialValueService.WriteConnection(connection, rows, service, result);
						}
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06001D76 RID: 7542 RVA: 0x000A6B40 File Offset: 0x000A4D40
		private static void WriteConnection(CommunicationConnection connection, List<CommunicationInitialValueRow> rows, PlcCommunicationService service, CommunicationInitialValueResult result)
		{
			CommunicationHeartbeatMonitorHelper.NormalizeConnection(connection);
			CommunicationOperationResult connectResult = service.ConnectIfDisconnected(connection);
			bool flag = !connectResult.Success;
			if (flag)
			{
				result.SkippedCount += rows.Count;
				result.Errors.Add(string.Concat(new string[]
				{
					"'",
					connection.Name,
					"' is not connected, ",
					rows.Count.ToString(),
					" initial value(s) skipped: ",
					connectResult.Message
				}));
			}
			else
			{
				foreach (CommunicationInitialValueRow row in rows)
				{
					try
					{
						CommunicationOperationResult writeResult = service.Write(connection, row.Address.Trim(), string.IsNullOrWhiteSpace(row.DataType) ? "INT16" : row.DataType.Trim(), row.Value ?? string.Empty);
						bool success = writeResult.Success;
						if (success)
						{
							int writtenCount = result.WrittenCount;
							result.WrittenCount = writtenCount + 1;
						}
						else
						{
							result.Errors.Add(string.Concat(new string[]
							{
								"'",
								connection.Name,
								"' ",
								CommunicationInitialValueService.Describe(row),
								" failed: ",
								writeResult.Message
							}));
						}
					}
					catch (Exception ex)
					{
						result.Errors.Add(string.Concat(new string[]
						{
							"'",
							connection.Name,
							"' ",
							CommunicationInitialValueService.Describe(row),
							" failed: ",
							ex.Message
						}));
					}
				}
			}
		}

		// Token: 0x06001D77 RID: 7543 RVA: 0x000A6D4C File Offset: 0x000A4F4C
		private static bool IsWritable(CommunicationInitialValueRow row)
		{
			return row != null && CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(row.Address) && !string.IsNullOrWhiteSpace(row.Value);
		}

		// Token: 0x06001D78 RID: 7544 RVA: 0x000A6D80 File Offset: 0x000A4F80
		private static string Describe(CommunicationInitialValueRow row)
		{
			string name = string.IsNullOrWhiteSpace(row.Name) ? "initial value" : row.Name.Trim();
			return string.Concat(new string[]
			{
				name,
				" @",
				row.Address,
				" = ",
				row.Value
			});
		}

		// Token: 0x06001D79 RID: 7545 RVA: 0x000A6DE4 File Offset: 0x000A4FE4
		public static void WriteCurrentModelAndLog(string configPath = null)
		{
			try
			{
				CommunicationInitialValueResult result = CommunicationInitialValueService.WriteCurrentModel(configPath);
				bool flag = result.WrittenCount > 0;
				if (flag)
				{
					VisionLogService.Log("Success", "Communication", "INIT-0001", "Initial values written to PLC: " + result.WrittenCount.ToString() + " register(s).", null, null);
				}
				foreach (string error in result.Errors)
				{
					VisionLogService.Log("Warn", "Communication", "INIT-0002", error, null, null);
				}
			}
			catch (Exception ex)
			{
				VisionLogService.Log("Error", "Communication", "INIT-0003", "Writing initial values failed: " + ex.Message, null, null);
			}
		}
	}
}
