﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200021D RID: 541
	public class CommunicationOperationResult
	{
		// Token: 0x17000947 RID: 2375
		// (get) Token: 0x06001EBA RID: 7866 RVA: 0x000B183F File Offset: 0x000AFA3F
		// (set) Token: 0x06001EBB RID: 7867 RVA: 0x000B1847 File Offset: 0x000AFA47
		public bool Success { get; set; }

		// Token: 0x17000948 RID: 2376
		// (get) Token: 0x06001EBC RID: 7868 RVA: 0x000B1850 File Offset: 0x000AFA50
		// (set) Token: 0x06001EBD RID: 7869 RVA: 0x000B1858 File Offset: 0x000AFA58
		public string Message { get; set; }

		// Token: 0x17000949 RID: 2377
		// (get) Token: 0x06001EBE RID: 7870 RVA: 0x000B1861 File Offset: 0x000AFA61
		// (set) Token: 0x06001EBF RID: 7871 RVA: 0x000B1869 File Offset: 0x000AFA69
		public int SentBytes { get; set; }

		// Token: 0x1700094A RID: 2378
		// (get) Token: 0x06001EC0 RID: 7872 RVA: 0x000B1872 File Offset: 0x000AFA72
		// (set) Token: 0x06001EC1 RID: 7873 RVA: 0x000B187A File Offset: 0x000AFA7A
		public int ReceivedBytes { get; set; }

		// Token: 0x06001EC2 RID: 7874 RVA: 0x000B1884 File Offset: 0x000AFA84
		public static CommunicationOperationResult Ok(string message, int sentBytes = 0, int receivedBytes = 0)
		{
			return new CommunicationOperationResult
			{
				Success = true,
				Message = message,
				SentBytes = sentBytes,
				ReceivedBytes = receivedBytes
			};
		}

		// Token: 0x06001EC3 RID: 7875 RVA: 0x000B18BC File Offset: 0x000AFABC
		public static CommunicationOperationResult Fail(string message, int sentBytes = 0, int receivedBytes = 0)
		{
			return new CommunicationOperationResult
			{
				Success = false,
				Message = message,
				SentBytes = sentBytes,
				ReceivedBytes = receivedBytes
			};
		}
	}
}
