﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F3 RID: 499
	public static class CommunicationOptions
	{
		// Token: 0x06001D8F RID: 7567 RVA: 0x000A7BBC File Offset: 0x000A5DBC
		public static bool SupportsTagReadWrite(string protocol)
		{
			return string.Equals(protocol, "Modbus Client TCP/IP", StringComparison.OrdinalIgnoreCase) || string.Equals(protocol, "OPC UA", StringComparison.OrdinalIgnoreCase) || string.Equals(protocol, "MX Component", StringComparison.OrdinalIgnoreCase) || string.Equals(protocol, "MC Protocol", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x04000C72 RID: 3186
		public const string ProtocolModbusClientTcp = "Modbus Client TCP/IP";

		// Token: 0x04000C73 RID: 3187
		public const string ProtocolModbusServerTcp = "Modbus Server TCP/IP";

		// Token: 0x04000C74 RID: 3188
		public const string ProtocolOpcUa = "OPC UA";

		// Token: 0x04000C75 RID: 3189
		public const string ProtocolMxComponent = "MX Component";

		// Token: 0x04000C76 RID: 3190
		public const string ProtocolMcProtocol = "MC Protocol";

		// Token: 0x04000C77 RID: 3191
		public static readonly string[] ProtocolOptions = new string[]
		{
			"Modbus Client TCP/IP",
			"Modbus Server TCP/IP",
			"OPC UA",
			"MX Component",
			"MC Protocol"
		};

		// Token: 0x04000C78 RID: 3192
		public static readonly string[] FunctionCodes = new string[]
		{
			"01 Read Coil Status",
			"02 Read Discrete Inputs",
			"03 Read Holding Registers",
			"04 Read Input Registers",
			"05 Write Single Coil",
			"06 Write Single Register",
			"15 Write Multiple Coils",
			"16 Write Multiple Registers"
		};

		// Token: 0x04000C79 RID: 3193
		public static readonly string[] MonitorFunctionCodes = new string[]
		{
			"03 Read Holding Registers",
			"04 Read Input Registers"
		};

		// Token: 0x04000C7A RID: 3194
		public static readonly string[] TagDataTypes = new string[]
		{
			"BOOL",
			"INT16",
			"UINT16",
			"INT32",
			"UINT32",
			"FLOAT",
			"REAL",
			"DINT"
		};

		// Token: 0x04000C7B RID: 3195
		public static readonly string[] TagReadWriteOptions = new string[]
		{
			"Read",
			"Write"
		};
	}
}
