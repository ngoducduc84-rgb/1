﻿using System;
using System.Linq;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200020F RID: 527
	internal abstract class CommunicationProtocolProviderBase : ICommunicationProtocolProvider
	{
		// Token: 0x06001E9E RID: 7838 RVA: 0x000B16F4 File Offset: 0x000AF8F4
		protected CommunicationProtocolProviderBase(params string[] protocolNames)
		{
			this._protocolNames = (protocolNames ?? Array.Empty<string>());
		}

		// Token: 0x06001E9F RID: 7839 RVA: 0x000B1710 File Offset: 0x000AF910
		public bool CanHandle(string protocol)
		{
			return this._protocolNames.Any((string x) => string.Equals(x, protocol, StringComparison.OrdinalIgnoreCase));
		}

		// Token: 0x06001EA0 RID: 7840
		public abstract IPlcCommunicationClient CreateClient();

		// Token: 0x04000CE0 RID: 3296
		private readonly string[] _protocolNames;
	}
}
