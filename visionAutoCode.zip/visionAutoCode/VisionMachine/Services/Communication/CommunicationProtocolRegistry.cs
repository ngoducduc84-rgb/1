﻿using System;
using System.Collections.Generic;
using System.Linq;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200020D RID: 525
	internal static class CommunicationProtocolRegistry
	{
		// Token: 0x06001E9A RID: 7834 RVA: 0x000B164C File Offset: 0x000AF84C
		public static IPlcCommunicationClient CreateClient(CommunicationConnection connection)
		{
			ICommunicationProtocolProvider provider = CommunicationProtocolRegistry.Providers.FirstOrDefault(delegate(ICommunicationProtocolProvider x)
			{
				CommunicationConnection connection2 = connection;
				return x.CanHandle((connection2 != null) ? connection2.Protocol : null);
			});
			IPlcCommunicationClient result;
			if (provider == null)
			{
				IPlcCommunicationClient plcCommunicationClient = new UnsupportedCommunicationClient("Unknown protocol.");
				result = plcCommunicationClient;
			}
			else
			{
				result = provider.CreateClient();
			}
			return result;
		}

		// Token: 0x04000CDF RID: 3295
		private static readonly IReadOnlyList<ICommunicationProtocolProvider> Providers = new ICommunicationProtocolProvider[]
		{
			new ModbusClientTcpProtocolProvider(),
			new ModbusServerTcpProtocolProvider(),
			new ModbusRtuProtocolProvider(),
			new SocketClientProtocolProvider(),
			new SocketServerProtocolProvider(),
			new McProtocolProvider(),
			new MxComponentProtocolProvider(),
			new OpcUaProtocolProvider()
		};
	}
}
