﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200021E RID: 542
	public class CommunicationReadResult : CommunicationOperationResult
	{
		// Token: 0x1700094B RID: 2379
		// (get) Token: 0x06001EC5 RID: 7877 RVA: 0x000B18F3 File Offset: 0x000AFAF3
		public ObservableCollection<CommunicationMonitorRow> Rows { get; } = new ObservableCollection<CommunicationMonitorRow>();

		// Token: 0x06001EC6 RID: 7878 RVA: 0x000B18FC File Offset: 0x000AFAFC
		public static CommunicationReadResult From(bool success, string message, IEnumerable<CommunicationMonitorRow> rows, int sentBytes, int receivedBytes)
		{
			CommunicationReadResult result = new CommunicationReadResult
			{
				Success = success,
				Message = message,
				SentBytes = sentBytes,
				ReceivedBytes = receivedBytes
			};
			foreach (CommunicationMonitorRow row in (rows ?? Enumerable.Empty<CommunicationMonitorRow>()))
			{
				result.Rows.Add(row);
			}
			return result;
		}

		// Token: 0x06001EC7 RID: 7879 RVA: 0x000B1984 File Offset: 0x000AFB84
		public static CommunicationReadResult Fail(string message)
		{
			return CommunicationReadResult.From(false, message, null, 0, 0);
		}
	}
}
