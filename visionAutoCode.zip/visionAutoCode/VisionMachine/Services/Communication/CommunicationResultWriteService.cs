﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using VisionMachine.Models.Communication;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.ResultAlign;
using VisionMachine.VisionTools.ResultInspection;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001FC RID: 508
	public static class CommunicationResultWriteService
	{
		// Token: 0x06001DF1 RID: 7665 RVA: 0x000AB7DC File Offset: 0x000A99DC
		public static bool IsAutoTriggeredOption(string linkedToolName)
		{
			return CommunicationResultWriteService.IsAutoTriggeredInspection(linkedToolName) || CommunicationResultWriteService.IsAutoTriggeredAlign(linkedToolName);
		}

		// Token: 0x06001DF2 RID: 7666 RVA: 0x000AB800 File Offset: 0x000A9A00
		private static bool IsAutoTriggeredInspection(string linkedToolName)
		{
			return string.Equals((linkedToolName ?? string.Empty).Trim(), "Auto: Result Inspection of triggered TurnSnap", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001DF3 RID: 7667 RVA: 0x000AB82C File Offset: 0x000A9A2C
		private static bool IsAutoTriggeredAlign(string linkedToolName)
		{
			return string.Equals((linkedToolName ?? string.Empty).Trim(), "Auto: Result Align of triggered TurnSnap", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001DF4 RID: 7668 RVA: 0x000AB858 File Offset: 0x000A9A58
		public static void WriteCameraResults(string cameraName, IList<ToolResultEntry> results, Action<string, string> log = null)
		{
			try
			{
				bool flag = string.IsNullOrWhiteSpace(cameraName) || results == null || results.Count == 0;
				if (!flag)
				{
					CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(CommunicationConfigStorageService.GetConfigPath());
					bool flag2 = config == null;
					if (!flag2)
					{
						CommunicationConnection connection = CommunicationResultWriteService.ResolveResultConnection(config, cameraName);
						bool flag3 = connection == null;
						if (flag3)
						{
							if (log != null)
							{
								log("Warn", "Result -> PLC skipped for camera '" + cameraName + "': no connection with tool-linked Write result tags for this camera was found.");
							}
						}
						else
						{
							CommunicationResultWriteService.NormalizeConnection(connection);
							List<CommunicationTagRow> connectionTags = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name);
							bool flag4 = connectionTags.Count == 0;
							if (!flag4)
							{
								CommunicationOperationResult connect = CommunicationResultWriteService.CommunicationService.ConnectIfDisconnected(connection);
								bool flag5 = !connect.Success;
								if (flag5)
								{
									if (log != null)
									{
										log("Warn", "Result -> Modbus skipped: PLC connect failed: " + connect.Message);
									}
								}
								else
								{
									CalibResultAlignResult alignResult = (from r in results
									select (r != null) ? r.Result : null).OfType<CalibResultAlignResult>().FirstOrDefault<CalibResultAlignResult>();
									CalibResultInspectionResult inspectionResult = (from r in results
									select (r != null) ? r.Result : null).OfType<CalibResultInspectionResult>().FirstOrDefault<CalibResultInspectionResult>();
									bool flag6 = alignResult == null && inspectionResult == null;
									if (flag6)
									{
										if (log != null)
										{
											log("Warn", "Result -> Modbus skipped for " + cameraName + ": the run produced no Result Align / Result Inspection result. Tools in run: " + CommunicationResultWriteService.DescribeResultTools(results));
										}
									}
									else
									{
										string cameraKey = CommunicationResultWriteService.NormalizeName("camera " + cameraName);
										List<string> modbusDetails = new List<string>();
										List<CommunicationTagRow> tagsForCamera = (from tag in connectionTags
										where tag != null && string.Equals(tag.ReadWrite, "Write", StringComparison.OrdinalIgnoreCase) && CommunicationResultWriteService.IsLinkedToTool(tag) && !string.IsNullOrWhiteSpace(tag.ResultField) && !string.Equals(tag.ResultField, "None", StringComparison.OrdinalIgnoreCase) && CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(tag.Address) && CommunicationResultWriteService.NormalizeName(tag.Name).StartsWith(cameraKey, StringComparison.Ordinal)
										select tag).ToList<CommunicationTagRow>();
										bool flag7 = tagsForCamera.Count == 0;
										if (flag7)
										{
											if (log != null)
											{
												log("Warn", "Result -> Modbus: no tool-linked Write tags found for camera '" + cameraName + "'. Link the result tags to a tool in Tag Management.");
											}
										}
										else
										{
											foreach (CommunicationTagRow tag3 in tagsForCamera)
											{
												bool flag8 = CommunicationResultWriteService.GetResultForTag(tag3, results) == null;
												if (flag8)
												{
													if (log != null)
													{
														log("Warn", string.Concat(new string[]
														{
															"Result -> Modbus: tag '",
															tag3.Name,
															"' is linked to '",
															tag3.LinkedToolName,
															"' but no matching tool result was found in this run. ",
															CommunicationResultWriteService.IsAutoTriggeredOption(tag3.LinkedToolName) ? "The triggered TurnSnap has no such tool - add it in the Setting form. " : string.Empty,
															"Tools in run: ",
															CommunicationResultWriteService.DescribeResultTools(results)
														}));
													}
												}
											}
											bool flag9 = CommunicationResultWriteService.IsOpcUa(connection);
											if (flag9)
											{
												CommunicationResultWriteService.WriteCameraResultsOpc(connection, cameraName, tagsForCamera, results, log);
											}
											else
											{
												bool flag10 = !CommunicationResultWriteService.IsModbus(connection);
												if (flag10)
												{
													CommunicationResultWriteService.WriteCameraResultsByTag(connection, cameraName, tagsForCamera, results, log);
												}
												else
												{
													string alignDetail;
													bool flag11 = CommunicationResultWriteService.WriteAlignCoordinateBatch(connection, tagsForCamera, results, log, out alignDetail) > 0 && !string.IsNullOrWhiteSpace(alignDetail);
													if (flag11)
													{
														modbusDetails.Add(alignDetail);
													}
													List<CommunicationTagRow> remainingTags = (from x in tagsForCamera
													where !CommunicationResultWriteService.IsAlignBatchField(x.ResultField)
													orderby CommunicationResultWriteService.IsCompleteField(x.ResultField) ? 1 : 0
													select x).ToList<CommunicationTagRow>();
													foreach (CommunicationTagRow tag2 in remainingTags)
													{
														object linkedResult = CommunicationResultWriteService.GetResultForTag(tag2, results);
														List<double> values = CommunicationResultWriteService.ResolveValues(tag2.ResultField, linkedResult as CalibResultAlignResult, linkedResult as CalibResultInspectionResult);
														bool flag12 = values == null;
														if (!flag12)
														{
															string detail;
															int written = CommunicationResultWriteService.WriteList(connection, tag2, values, log, out detail);
															bool flag13 = written > 0;
															if (flag13)
															{
																bool flag14 = !string.IsNullOrWhiteSpace(detail);
																if (flag14)
																{
																	modbusDetails.Add(detail);
																}
															}
														}
													}
													bool flag15 = modbusDetails.Count > 0;
													if (flag15)
													{
														if (log != null)
														{
															log("Info", "Modbus OUT " + cameraName + ": " + string.Join("; ", modbusDetails));
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				if (log != null)
				{
					log("Error", "Result -> Modbus failed: " + ex.Message);
				}
			}
		}

		// Token: 0x06001DF5 RID: 7669 RVA: 0x000ABD30 File Offset: 0x000A9F30
		private static void WriteCameraResultsByTag(CommunicationConnection connection, string cameraName, IList<CommunicationTagRow> tagsForCamera, IList<ToolResultEntry> results, Action<string, string> log)
		{
			List<string> details = new List<string>();
			List<CommunicationTagRow> ordered = (from x in tagsForCamera
			orderby CommunicationResultWriteService.IsCompleteField(x.ResultField) ? 1 : 0
			select x).ToList<CommunicationTagRow>();
			using (List<CommunicationTagRow>.Enumerator enumerator = ordered.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					CommunicationTagRow tag = enumerator.Current;
					object linkedResult = CommunicationResultWriteService.GetResultForTag(tag, results);
					List<double> values = CommunicationResultWriteService.ResolveValues(tag.ResultField, linkedResult as CalibResultAlignResult, linkedResult as CalibResultInspectionResult);
					bool flag = values == null || values.Count == 0;
					if (!flag)
					{
						int max = (tag.MaxResultCount > 0) ? tag.MaxResultCount : 1;
						int count = Math.Min(values.Count, max);
						int written = 0;
						for (int i = 0; i < count; i++)
						{
							string address = (i == 0) ? (tag.Address ?? string.Empty).Trim() : CommunicationResultWriteService.OffsetDeviceAddress(tag.Address, i);
							bool flag2 = string.IsNullOrWhiteSpace(address);
							if (flag2)
							{
								if (log != null)
								{
									log("Warn", string.Concat(new string[]
									{
										"Result -> PLC: '",
										tag.Name,
										"' needs ",
										count.ToString(),
										" consecutive devices but '",
										tag.Address,
										"' cannot be counted up; only the first value was written."
									}));
								}
								break;
							}
							string text = CommunicationResultWriteService.IsFloat(tag.DataType) ? values[i].ToString("0.######", CommunicationResultWriteService.Inv) : ((int)Math.Round(values[i])).ToString(CommunicationResultWriteService.Inv);
							CommunicationOperationResult result = CommunicationResultWriteService.CommunicationService.Write(connection, address, string.IsNullOrWhiteSpace(tag.DataType) ? "INT16" : tag.DataType.Trim(), text);
							bool flag3 = result == null || !result.Success;
							if (flag3)
							{
								if (log != null)
								{
									log("Warn", string.Concat(new string[]
									{
										"Result -> PLC: ",
										CommunicationResultWriteService.GetConciseFieldName(tag.ResultField),
										" @",
										address,
										" failed: ",
										((result != null) ? result.Message : null) ?? "write failed"
									}));
								}
								break;
							}
							written++;
						}
						bool flag4 = written > 0;
						if (flag4)
						{
							details.Add(string.Concat(new string[]
							{
								CommunicationResultWriteService.GetConciseFieldName(tag.ResultField),
								"@",
								tag.Address,
								"=",
								string.Join(",", from v in values.Take(written)
								select CommunicationResultWriteService.IsFloat(tag.DataType) ? v.ToString("0.###", CommunicationResultWriteService.Inv) : ((int)Math.Round(v)).ToString(CommunicationResultWriteService.Inv))
							}));
						}
					}
				}
			}
			bool flag5 = details.Count > 0;
			if (flag5)
			{
				if (log != null)
				{
					log("Info", "PLC OUT " + cameraName + ": " + string.Join("; ", details));
				}
			}
			else if (log != null)
			{
				log("Warn", "Result -> PLC: nothing was written for camera '" + cameraName + "'. The linked tools produced no matching result in this run - tools: " + CommunicationResultWriteService.DescribeResultTools(results));
			}
		}

		// Token: 0x06001DF6 RID: 7670 RVA: 0x000AC104 File Offset: 0x000AA304
		private static string OffsetDeviceAddress(string address, int offset)
		{
			string text = (address ?? string.Empty).Trim();
			bool flag = text.Length < 2 || offset <= 0;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				int split = 0;
				while (split < text.Length && !char.IsDigit(text[split]))
				{
					split++;
				}
				bool flag2 = split == 0 || split >= text.Length;
				if (flag2)
				{
					result = null;
				}
				else
				{
					string prefix = text.Substring(0, split).ToUpperInvariant();
					string digits = text.Substring(split);
					bool hex = prefix == "X" || prefix == "Y" || prefix == "B" || prefix == "W";
					try
					{
						bool flag3 = hex;
						if (flag3)
						{
							result = prefix + (Convert.ToInt32(digits, 16) + offset).ToString("X", CommunicationResultWriteService.Inv);
						}
						else
						{
							int decimalValue;
							bool flag4 = !int.TryParse(digits, NumberStyles.Integer, CommunicationResultWriteService.Inv, out decimalValue);
							if (flag4)
							{
								result = null;
							}
							else
							{
								result = prefix + (decimalValue + offset).ToString(CommunicationResultWriteService.Inv);
							}
						}
					}
					catch
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x06001DF7 RID: 7671 RVA: 0x000AC25C File Offset: 0x000AA45C
		private static void WriteCameraResultsOpc(CommunicationConnection connection, string cameraName, IList<CommunicationTagRow> tagsForCamera, IList<ToolResultEntry> results, Action<string, string> log)
		{
			List<string> details = new List<string>();
			int skippedEmpty = 0;
			List<CommunicationTagRow> orderedTags = (from x in tagsForCamera
			orderby CommunicationResultWriteService.IsCompleteField(x.ResultField) ? 1 : 0
			select x).ToList<CommunicationTagRow>();
			foreach (CommunicationTagRow tag in orderedTags)
			{
				object linkedResult = CommunicationResultWriteService.GetResultForTag(tag, results);
				List<double> values = CommunicationResultWriteService.ResolveValues(tag.ResultField, linkedResult as CalibResultAlignResult, linkedResult as CalibResultInspectionResult);
				bool flag = values == null || values.Count == 0;
				if (flag)
				{
					skippedEmpty++;
				}
				else
				{
					int max = (tag.MaxResultCount > 0) ? tag.MaxResultCount : 1;
					int count = Math.Min(values.Count, max);
					bool flag2 = count <= 0;
					if (flag2)
					{
						skippedEmpty++;
					}
					else
					{
						string detail;
						bool flag3 = CommunicationResultWriteService.WriteOpcTagValues(connection, tag, values.Take(count).ToList<double>(), log, out detail) && !string.IsNullOrWhiteSpace(detail);
						if (flag3)
						{
							details.Add(detail);
						}
					}
				}
			}
			bool flag4 = details.Count > 0;
			if (flag4)
			{
				if (log != null)
				{
					log("Info", "OPC OUT " + cameraName + ": " + string.Join("; ", details));
				}
			}
			else
			{
				CalibResultAlignResult align = (from r in results
				select (r != null) ? r.Result : null).OfType<CalibResultAlignResult>().FirstOrDefault<CalibResultAlignResult>();
				int? num;
				if (align == null)
				{
					num = null;
				}
				else
				{
					List<CalibResultAlignItem> items = align.Items;
					num = ((items != null) ? new int?(items.Count) : null);
				}
				int? num2 = num;
				int alignItems = num2.GetValueOrDefault();
				if (log != null)
				{
					log("Warn", string.Concat(new string[]
					{
						"OPC OUT ",
						cameraName,
						": nothing written. Linked result tags=",
						tagsForCamera.Count.ToString(),
						", skipped (no value)=",
						skippedEmpty.ToString(),
						", Result Align items=",
						alignItems.ToString(),
						(align == null) ? " (no Result Align result in this run)" : (" (IsSuccess=" + align.IsSuccess.ToString() + ")"),
						". If items=0, the Result Align tool produced no objects — check that its Calib Hand-Eye source tool exists in this TurnSnap and actually detects objects."
					}));
				}
			}
		}

		// Token: 0x06001DF8 RID: 7672 RVA: 0x000AC4EC File Offset: 0x000AA6EC
		private static bool WriteOpcTagValues(CommunicationConnection connection, CommunicationTagRow tag, List<double> values, Action<string, string> log, out string conciseDetail)
		{
			conciseDetail = null;
			CommunicationTagRow tag2 = tag;
			string text;
			if (tag2 == null)
			{
				text = null;
			}
			else
			{
				string address2 = tag2.Address;
				text = ((address2 != null) ? address2.Trim() : null);
			}
			string address = text;
			bool flag = string.IsNullOrWhiteSpace(address) || values == null || values.Count == 0;
			bool result2;
			if (flag)
			{
				result2 = false;
			}
			else
			{
				List<string> texts = (from x in values
				select CommunicationResultWriteService.FormatOpcNumber(x, tag.DataType)).ToList<string>();
				string arrayNode;
				int baseIndex;
				bool flag2 = texts.Count > 1 && CommunicationResultWriteService.TryParseIndexedNode(address, out arrayNode, out baseIndex);
				CommunicationOperationResult result;
				if (flag2)
				{
					result = null;
					for (int i = 0; i < texts.Count; i++)
					{
						string elementAddress = arrayNode + "[" + (baseIndex + i).ToString(CommunicationResultWriteService.Inv) + "]";
						result = CommunicationResultWriteService.CommunicationService.Write(connection, elementAddress, tag.DataType, texts[i]);
						bool flag3 = result == null || !result.Success;
						if (flag3)
						{
							break;
						}
					}
				}
				else
				{
					bool flag4 = texts.Count == 1;
					if (flag4)
					{
						result = CommunicationResultWriteService.CommunicationService.Write(connection, address, tag.DataType, texts[0]);
					}
					else
					{
						result = CommunicationResultWriteService.CommunicationService.WriteOpcArray(connection, address, tag.DataType, texts);
					}
				}
				bool flag5 = result == null || !result.Success;
				if (flag5)
				{
					if (log != null)
					{
						log("Warn", string.Concat(new string[]
						{
							"OPC OUT ",
							CommunicationResultWriteService.GetConciseFieldName(tag.ResultField),
							" @",
							address,
							" failed: ",
							((result != null) ? result.Message : null) ?? "write failed"
						}));
					}
					result2 = false;
				}
				else
				{
					conciseDetail = string.Concat(new string[]
					{
						CommunicationResultWriteService.GetConciseFieldName(tag.ResultField),
						" @",
						address,
						"=[",
						string.Join(",", texts),
						"]"
					});
					result2 = true;
				}
			}
			return result2;
		}

		// Token: 0x06001DF9 RID: 7673 RVA: 0x000AC728 File Offset: 0x000AA928
		private static bool TryParseIndexedNode(string address, out string arrayNode, out int baseIndex)
		{
			arrayNode = null;
			baseIndex = 0;
			bool flag = string.IsNullOrWhiteSpace(address);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string text = address.Trim();
				bool flag2 = !text.EndsWith("]", StringComparison.Ordinal);
				if (flag2)
				{
					result = false;
				}
				else
				{
					int bracket = text.LastIndexOf('[');
					bool flag3 = bracket <= 0;
					if (flag3)
					{
						result = false;
					}
					else
					{
						string indexText = text.Substring(bracket + 1, text.Length - bracket - 2);
						bool flag4 = !int.TryParse(indexText, NumberStyles.Integer, CommunicationResultWriteService.Inv, out baseIndex) || baseIndex < 0;
						if (flag4)
						{
							result = false;
						}
						else
						{
							arrayNode = text.Substring(0, bracket);
							result = true;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001DFA RID: 7674 RVA: 0x000AC7D4 File Offset: 0x000AA9D4
		private static string FormatOpcNumber(double value, string dataType)
		{
			return CommunicationResultWriteService.IsFloat(dataType) ? value.ToString("0.######", CommunicationResultWriteService.Inv) : ((int)Math.Round(value)).ToString(CommunicationResultWriteService.Inv);
		}

		// Token: 0x06001DFB RID: 7675 RVA: 0x000AC818 File Offset: 0x000AAA18
		private static List<double> ResolveValues(string field, CalibResultAlignResult align, CalibResultInspectionResult inspection)
		{
			field = field.Trim();
			bool flag = field.StartsWith("Align.", StringComparison.OrdinalIgnoreCase);
			List<double> result;
			if (flag)
			{
				bool flag2 = align == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					List<CalibResultAlignItem> items = align.Items;
					string text = field.ToLowerInvariant();
					string text2 = text;
					uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
					if (num <= 2557636779U)
					{
						if (num <= 1289215312U)
						{
							if (num != 529838594U)
							{
								if (num == 1289215312U)
								{
									if (text2 == "align.degree")
									{
										return (from i in items
										select i.HasDelta ? i.DeltaAngleDeg : i.AngleDeg).ToList<double>();
									}
								}
							}
							else if (text2 == "align.score")
							{
								return (from i in items
								select i.Score).ToList<double>();
							}
						}
						else if (num != 1716848295U)
						{
							if (num == 2557636779U)
							{
								if (text2 == "align.errorcode")
								{
									return new List<double>
									{
										(double)(align.IsSuccess ? 0 : 1)
									};
								}
							}
						}
						else if (text2 == "align.complete")
						{
							return new List<double>
							{
								1.0
							};
						}
					}
					else if (num <= 3205289371U)
					{
						if (num != 3182073919U)
						{
							if (num == 3205289371U)
							{
								if (text2 == "align.resultok")
								{
									return new List<double>
									{
										(double)((align.IsSuccess && items.Count > 0) ? 1 : 0)
									};
								}
							}
						}
						else if (text2 == "align.count")
						{
							return new List<double>
							{
								(double)(align.IsSuccess ? items.Count : 0)
							};
						}
					}
					else if (num != 3652525688U)
					{
						if (num == 3669303307U)
						{
							if (text2 == "align.y")
							{
								return (from i in items
								select i.HasDelta ? i.DeltaRobotY : i.RobotY).ToList<double>();
							}
						}
					}
					else if (text2 == "align.x")
					{
						return (from i in items
						select i.HasDelta ? i.DeltaRobotX : i.RobotX).ToList<double>();
					}
					result = null;
				}
			}
			else
			{
				bool flag3 = field.StartsWith("Inspection.", StringComparison.OrdinalIgnoreCase);
				if (flag3)
				{
					bool flag4 = inspection == null;
					if (flag4)
					{
						result = null;
					}
					else
					{
						string text3 = field.ToLowerInvariant();
						string text4 = text3;
						uint num = <PrivateImplementationDetails>.ComputeStringHash(text4);
						if (num <= 1623251000U)
						{
							if (num != 340891100U)
							{
								if (num != 1255269521U)
								{
									if (num == 1623251000U)
									{
										if (text4 == "inspection.resultok")
										{
											return new List<double>
											{
												(double)(inspection.IsOk ? 1 : 0)
											};
										}
									}
								}
								else if (text4 == "inspection.ngcode")
								{
									return new List<double>
									{
										(double)(inspection.IsOk ? 0 : 1)
									};
								}
							}
							else if (text4 == "inspection.value")
							{
								return (from i in inspection.Items
								where i != null
								select i.Value).ToList<double>();
							}
						}
						else if (num <= 2785916716U)
						{
							if (num != 2092774069U)
							{
								if (num == 2785916716U)
								{
									if (text4 == "inspection.totalng")
									{
										return new List<double>
										{
											(double)(inspection.IsOk ? 0 : 1)
										};
									}
								}
							}
							else if (text4 == "inspection.resultng")
							{
								return new List<double>
								{
									(double)(inspection.IsOk ? 0 : 1)
								};
							}
						}
						else if (num != 3389763905U)
						{
							if (num == 4165098116U)
							{
								if (text4 == "inspection.complete")
								{
									return new List<double>
									{
										1.0
									};
								}
							}
						}
						else if (text4 == "inspection.totalok")
						{
							return new List<double>
							{
								(double)(inspection.IsOk ? 1 : 0)
							};
						}
						result = null;
					}
				}
				else
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001DFC RID: 7676 RVA: 0x000ACD50 File Offset: 0x000AAF50
		private static int WriteAlignCoordinateBatch(CommunicationConnection connection, IList<CommunicationTagRow> tags, IList<ToolResultEntry> results, Action<string, string> log, out string conciseDetail)
		{
			conciseDetail = null;
			bool flag = connection == null || tags == null || results == null;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				string[] batchFields = new string[]
				{
					"Align.X",
					"Align.Y",
					"Align.Degree",
					"Align.Count"
				};
				List<CommunicationResultWriteService.AlignBatchEntry> entries = new List<CommunicationResultWriteService.AlignBatchEntry>();
				string[] array = batchFields;
				for (int i = 0; i < array.Length; i++)
				{
					string field = array[i];
					CommunicationTagRow tag = tags.FirstOrDefault((CommunicationTagRow x) => string.Equals(x.ResultField, field, StringComparison.OrdinalIgnoreCase));
					bool flag2 = tag == null;
					if (!flag2)
					{
						CalibResultAlignResult alignResult = CommunicationResultWriteService.GetResultForTag(tag, results) as CalibResultAlignResult;
						bool flag3 = alignResult == null;
						if (!flag3)
						{
							List<double> values = CommunicationResultWriteService.ResolveValues(field, alignResult, null);
							bool flag4 = values == null || values.Count == 0;
							if (!flag4)
							{
								int max = (tag.MaxResultCount > 0) ? tag.MaxResultCount : 1;
								int count = Math.Min(values.Count, max);
								bool flag5 = count <= 0;
								if (!flag5)
								{
									int startAddress;
									bool flag6 = !int.TryParse(tag.Address, NumberStyles.Integer, CommunicationResultWriteService.Inv, out startAddress);
									if (!flag6)
									{
										ushort[] registers = CommunicationResultWriteService.BuildRegisterArray(values, 0, count, tag.DataType);
										bool flag7 = registers == null || registers.Length == 0;
										if (!flag7)
										{
											entries.Add(new CommunicationResultWriteService.AlignBatchEntry
											{
												Tag = tag,
												Field = field,
												StartAddress = startAddress,
												Values = values.Take(count).ToList<double>(),
												Registers = registers
											});
										}
									}
								}
							}
						}
					}
				}
				bool flag8 = entries.Count == 0;
				if (flag8)
				{
					result = 0;
				}
				else
				{
					int firstAddress = entries.Min((CommunicationResultWriteService.AlignBatchEntry x) => x.StartAddress);
					int lastAddress = entries.Max((CommunicationResultWriteService.AlignBatchEntry x) => x.StartAddress + x.Registers.Length - 1);
					int registerCount = lastAddress - firstAddress + 1;
					bool flag9 = registerCount <= 0;
					if (flag9)
					{
						result = 0;
					}
					else
					{
						ushort[] mergedRegisters = new ushort[registerCount];
						foreach (CommunicationResultWriteService.AlignBatchEntry entry in entries)
						{
							int offset = entry.StartAddress - firstAddress;
							Array.Copy(entry.Registers, 0, mergedRegisters, offset, entry.Registers.Length);
						}
						int writtenRegisters = CommunicationResultWriteService.WriteRegisterArrayByChunks(connection, firstAddress, mergedRegisters, log, "Align coordinates");
						bool flag10 = writtenRegisters <= 0;
						if (flag10)
						{
							result = 0;
						}
						else
						{
							conciseDetail = string.Join("; ", from x in entries
							orderby CommunicationResultWriteService.GetAlignDetailOrder(x.Field)
							select CommunicationResultWriteService.BuildConciseModbusDetail(x.Tag, x.Values, x.Values.Count, x.StartAddress));
							result = entries.Count;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001DFD RID: 7677 RVA: 0x000AD090 File Offset: 0x000AB290
		private static int WriteRegisterArrayByChunks(CommunicationConnection connection, int firstAddress, ushort[] registers, Action<string, string> log, string label)
		{
			bool flag = registers == null || registers.Length == 0;
			int result2;
			if (flag)
			{
				result2 = 0;
			}
			else
			{
				int written = 0;
				for (int start = 0; start < registers.Length; start += 120)
				{
					int chunkCount = Math.Min(120, registers.Length - start);
					ushort[] chunk = new ushort[chunkCount];
					Array.Copy(registers, start, chunk, 0, chunkCount);
					string address = (firstAddress + start).ToString(CommunicationResultWriteService.Inv);
					CommunicationOperationResult result = CommunicationResultWriteService.CommunicationService.WriteRegisters(connection, address, chunk);
					bool flag2 = result == null || !result.Success;
					if (flag2)
					{
						if (log != null)
						{
							log("Warn", string.Concat(new string[]
							{
								"Modbus OUT ",
								label,
								" @",
								address,
								" failed: ",
								((result != null) ? result.Message : null) ?? "write failed"
							}));
						}
						break;
					}
					written += chunkCount;
				}
				result2 = written;
			}
			return result2;
		}

		// Token: 0x06001DFE RID: 7678 RVA: 0x000AD198 File Offset: 0x000AB398
		private static int WriteList(CommunicationConnection connection, CommunicationTagRow tag, List<double> values, Action<string, string> log, out string conciseDetail)
		{
			conciseDetail = null;
			bool flag = values == null || values.Count == 0;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				int baseAddress;
				bool flag2 = !int.TryParse(tag.Address, NumberStyles.Integer, CommunicationResultWriteService.Inv, out baseAddress);
				if (flag2)
				{
					if (log != null)
					{
						log("Warn", string.Concat(new string[]
						{
							"Result -> Modbus: '",
							tag.Name,
							"' has address '",
							tag.Address,
							"', which is not a Modbus register number, so nothing was written."
						}));
					}
					result = 0;
				}
				else
				{
					int stride = CommunicationValueConverter.GetRegisterStride(tag.DataType);
					int max = (tag.MaxResultCount > 0) ? tag.MaxResultCount : 1;
					int count = Math.Min(values.Count, max);
					int written = CommunicationResultWriteService.WriteValueArrayByChunks(connection, tag, values, count, stride, baseAddress, log);
					bool flag3 = written > 0 && CommunicationResultWriteService.IsConciseAlignField(tag.ResultField);
					if (flag3)
					{
						conciseDetail = CommunicationResultWriteService.BuildConciseModbusDetail(tag, values, count, baseAddress);
					}
					result = written;
				}
			}
			return result;
		}

		// Token: 0x06001DFF RID: 7679 RVA: 0x000AD298 File Offset: 0x000AB498
		private static int WriteValueArrayByChunks(CommunicationConnection connection, CommunicationTagRow tag, List<double> values, int valueCount, int stride, int baseAddress, Action<string, string> log)
		{
			int maxValuesPerFrame = Math.Max(1, 120 / Math.Max(1, stride));
			int written = 0;
			for (int start = 0; start < valueCount; start += maxValuesPerFrame)
			{
				int chunkCount = Math.Min(maxValuesPerFrame, valueCount - start);
				ushort[] registers = CommunicationResultWriteService.BuildRegisterArray(values, start, chunkCount, tag.DataType);
				string address = (baseAddress + start * stride).ToString(CommunicationResultWriteService.Inv);
				CommunicationOperationResult result = CommunicationResultWriteService.CommunicationService.WriteRegisters(connection, address, registers);
				bool flag = result == null || !result.Success;
				if (flag)
				{
					if (log != null)
					{
						log("Warn", string.Concat(new string[]
						{
							"Modbus OUT ",
							CommunicationResultWriteService.GetConciseFieldName(tag.ResultField),
							" @",
							address,
							" failed: ",
							((result != null) ? result.Message : null) ?? "write failed"
						}));
					}
					break;
				}
				written += chunkCount;
			}
			return written;
		}

		// Token: 0x06001E00 RID: 7680 RVA: 0x000AD3A0 File Offset: 0x000AB5A0
		private static ushort[] BuildRegisterArray(List<double> values, int start, int count, string dataType)
		{
			List<ushort> registers = new List<ushort>();
			bool isFloat = CommunicationResultWriteService.IsFloat(dataType);
			for (int i = 0; i < count; i++)
			{
				double value = values[start + i];
				string text = isFloat ? value.ToString("0.######", CommunicationResultWriteService.Inv) : ((int)Math.Round(value)).ToString(CommunicationResultWriteService.Inv);
				registers.AddRange(CommunicationValueConverter.ConvertValueToRegisters(text, dataType));
			}
			return registers.ToArray();
		}

		// Token: 0x06001E01 RID: 7681 RVA: 0x000AD424 File Offset: 0x000AB624
		private static bool IsConciseAlignField(string resultField)
		{
			string field = (resultField ?? string.Empty).Trim().ToLowerInvariant();
			return field == "align.x" || field == "align.y" || field == "align.degree" || field == "align.count";
		}

		// Token: 0x06001E02 RID: 7682 RVA: 0x000AD480 File Offset: 0x000AB680
		private static bool IsLinkedToTool(CommunicationTagRow tag)
		{
			return tag != null && !string.IsNullOrWhiteSpace(tag.LinkedToolName) && !string.Equals(tag.LinkedToolName, "None", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001E03 RID: 7683 RVA: 0x000AD4BC File Offset: 0x000AB6BC
		private static string DescribeResultTools(IList<ToolResultEntry> results)
		{
			bool flag = results == null || results.Count == 0;
			string result;
			if (flag)
			{
				result = "(none)";
			}
			else
			{
				List<string> names = (from r in results
				where ((r != null) ? r.Tool : null) != null
				select r).Select(delegate(ToolResultEntry r)
				{
					TurnSnap parentTurnSnap = r.Tool.ParentTurnSnap;
					int idx = (parentTurnSnap != null) ? parentTurnSnap.Index : 0;
					string ts = (idx > 0) ? ("TurnSnap " + idx.ToString() + " / ") : string.Empty;
					return string.Concat(new string[]
					{
						ts,
						r.Tool.Name ?? r.Tool.ToolType.ToString(),
						" [",
						r.Tool.ToolType.ToString(),
						"]"
					});
				}).ToList<string>();
				result = ((names.Count > 0) ? string.Join(", ", names) : "(none)");
			}
			return result;
		}

		// Token: 0x06001E04 RID: 7684 RVA: 0x000AD554 File Offset: 0x000AB754
		private static object GetResultForTag(CommunicationTagRow tag, IList<ToolResultEntry> results)
		{
			bool flag = tag == null || results == null || string.IsNullOrWhiteSpace(tag.LinkedToolName);
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool flag2 = CommunicationResultWriteService.IsAutoTriggeredInspection(tag.LinkedToolName);
				if (flag2)
				{
					result = CommunicationResultWriteService.LastResultOfType<CalibResultInspectionResult>(results);
				}
				else
				{
					bool flag3 = CommunicationResultWriteService.IsAutoTriggeredAlign(tag.LinkedToolName);
					if (flag3)
					{
						result = CommunicationResultWriteService.LastResultOfType<CalibResultAlignResult>(results);
					}
					else
					{
						ToolResultEntry entry = results.FirstOrDefault((ToolResultEntry r) => r != null && r.Result != null && CommunicationResultWriteService.TagLinksToTool(tag, r.Tool));
						result = ((entry != null) ? entry.Result : null);
					}
				}
			}
			return result;
		}

		// Token: 0x06001E05 RID: 7685 RVA: 0x000AD5F8 File Offset: 0x000AB7F8
		private static object LastResultOfType<T>(IList<ToolResultEntry> results) where T : class
		{
			for (int i = results.Count - 1; i >= 0; i--)
			{
				ToolResultEntry toolResultEntry = results[i];
				T match = ((toolResultEntry != null) ? toolResultEntry.Result : null) as T;
				bool flag = match != null;
				if (flag)
				{
					return match;
				}
			}
			return null;
		}

		// Token: 0x06001E06 RID: 7686 RVA: 0x000AD660 File Offset: 0x000AB860
		private static bool TagLinksToTool(CommunicationTagRow tag, ToolVision tool)
		{
			bool flag = tag == null || tool == null || string.IsNullOrWhiteSpace(tag.LinkedToolName);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = tool.ToolType == ToolType.ResultAlign;
				string typeText;
				if (flag2)
				{
					typeText = "Result Align";
				}
				else
				{
					bool flag3 = tool.ToolType == ToolType.ResultInspection;
					if (!flag3)
					{
						return false;
					}
					typeText = "Result Inspection";
				}
				string name = string.IsNullOrWhiteSpace(tool.Name) ? typeText : tool.Name;
				string link = CommunicationResultWriteService.NormalizeName(tag.LinkedToolName);
				TurnSnap parentTurnSnap = tool.ParentTurnSnap;
				int index = (parentTurnSnap != null) ? parentTurnSnap.Index : 0;
				bool flag4 = index > 0;
				if (flag4)
				{
					string tail = CommunicationResultWriteService.NormalizeName("TurnSnap" + index.ToString() + name + typeText);
					bool flag5 = link.EndsWith(tail, StringComparison.Ordinal);
					if (flag5)
					{
						return true;
					}
				}
				string nameType = CommunicationResultWriteService.NormalizeName(name + typeText);
				result = link.EndsWith(nameType, StringComparison.Ordinal);
			}
			return result;
		}

		// Token: 0x06001E07 RID: 7687 RVA: 0x000AD758 File Offset: 0x000AB958
		private static bool IsAlignBatchField(string resultField)
		{
			bool flag = string.IsNullOrWhiteSpace(resultField);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string field = resultField.Trim();
				result = CommunicationResultWriteService.AlignBatchFields.Any((string x) => string.Equals(x, field, StringComparison.OrdinalIgnoreCase));
			}
			return result;
		}

		// Token: 0x06001E08 RID: 7688 RVA: 0x000AD7A0 File Offset: 0x000AB9A0
		private static bool IsCompleteField(string resultField)
		{
			bool flag = string.IsNullOrWhiteSpace(resultField);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string field = resultField.Trim();
				result = (string.Equals(field, "Align.Complete", StringComparison.OrdinalIgnoreCase) || string.Equals(field, "Inspection.Complete", StringComparison.OrdinalIgnoreCase));
			}
			return result;
		}

		// Token: 0x06001E09 RID: 7689 RVA: 0x000AD7E4 File Offset: 0x000AB9E4
		private static int GetAlignDetailOrder(string resultField)
		{
			string field = (resultField ?? string.Empty).Trim().ToLowerInvariant();
			string text = field;
			string a = text;
			int result;
			if (!(a == "align.x"))
			{
				if (!(a == "align.y"))
				{
					if (!(a == "align.degree"))
					{
						if (!(a == "align.count"))
						{
							result = 100;
						}
						else
						{
							result = 3;
						}
					}
					else
					{
						result = 2;
					}
				}
				else
				{
					result = 1;
				}
			}
			else
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x06001E0A RID: 7690 RVA: 0x000AD858 File Offset: 0x000ABA58
		private static string BuildConciseModbusDetail(CommunicationTagRow tag, List<double> values, int count, int baseAddress)
		{
			string name = CommunicationResultWriteService.GetConciseFieldName(tag.ResultField);
			string valueText = string.Join(",", from x in values.Take(count)
			select CommunicationResultWriteService.IsFloat(tag.DataType) ? x.ToString("0.###", CommunicationResultWriteService.Inv) : ((int)Math.Round(x)).ToString(CommunicationResultWriteService.Inv));
			return string.Concat(new string[]
			{
				name,
				" @",
				baseAddress.ToString(CommunicationResultWriteService.Inv),
				"=[",
				valueText,
				"]"
			});
		}

		// Token: 0x06001E0B RID: 7691 RVA: 0x000AD8E8 File Offset: 0x000ABAE8
		private static string GetConciseFieldName(string resultField)
		{
			string field = (resultField ?? string.Empty).Trim().ToLowerInvariant();
			string text = field;
			string a = text;
			string result;
			if (!(a == "align.x"))
			{
				if (!(a == "align.y"))
				{
					if (!(a == "align.degree"))
					{
						if (!(a == "align.count"))
						{
							result = (string.IsNullOrWhiteSpace(resultField) ? "Value" : resultField);
						}
						else
						{
							result = "Count";
						}
					}
					else
					{
						result = "Angle";
					}
				}
				else
				{
					result = "Y";
				}
			}
			else
			{
				result = "X";
			}
			return result;
		}

		// Token: 0x06001E0C RID: 7692 RVA: 0x000AD97C File Offset: 0x000ABB7C
		private static bool IsFloat(string dataType)
		{
			return !string.IsNullOrWhiteSpace(dataType) && (dataType.IndexOf("FLOAT", StringComparison.OrdinalIgnoreCase) >= 0 || dataType.IndexOf("REAL", StringComparison.OrdinalIgnoreCase) >= 0);
		}

		// Token: 0x06001E0D RID: 7693 RVA: 0x000AD9C0 File Offset: 0x000ABBC0
		private static bool IsOpcUa(CommunicationConnection connection)
		{
			return connection != null && string.Equals(connection.Protocol, "OPC UA", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001E0E RID: 7694 RVA: 0x000AD9EC File Offset: 0x000ABBEC
		private static bool IsModbus(CommunicationConnection connection)
		{
			return connection != null && (string.Equals(connection.Protocol, "Modbus Client TCP/IP", StringComparison.OrdinalIgnoreCase) || string.Equals(connection.Protocol, "Modbus Server TCP/IP", StringComparison.OrdinalIgnoreCase));
		}

		// Token: 0x06001E0F RID: 7695 RVA: 0x000ADA2C File Offset: 0x000ABC2C
		private static bool IsSupportedResultConnection(CommunicationConnection connection)
		{
			return connection != null && CommunicationOptions.SupportsTagReadWrite(connection.Protocol);
		}

		// Token: 0x06001E10 RID: 7696 RVA: 0x000ADA50 File Offset: 0x000ABC50
		private static CommunicationConnection ResolveResultConnection(CommunicationConfigData config, string cameraName)
		{
			CommunicationResultWriteService.<>c__DisplayClass37_0 CS$<>8__locals1 = new CommunicationResultWriteService.<>c__DisplayClass37_0();
			CS$<>8__locals1.config = config;
			CommunicationConfigData config2 = CS$<>8__locals1.config;
			List<CommunicationConnection> connections = ((config2 != null) ? config2.Connections : null) ?? new List<CommunicationConnection>();
			CommunicationResultWriteService.<>c__DisplayClass37_0 CS$<>8__locals2 = CS$<>8__locals1;
			CommunicationConfigData config3 = CS$<>8__locals1.config;
			string designatedName;
			if (config3 == null)
			{
				designatedName = null;
			}
			else
			{
				CommunicationRuntimeSettings runtimeSettings = config3.RuntimeSettings;
				designatedName = ((runtimeSettings != null) ? runtimeSettings.CameraTriggerConnectionName : null);
			}
			CS$<>8__locals2.designatedName = designatedName;
			bool flag = !string.IsNullOrWhiteSpace(CS$<>8__locals1.designatedName) && !string.Equals(CS$<>8__locals1.designatedName, "None", StringComparison.OrdinalIgnoreCase);
			if (flag)
			{
				CommunicationConnection designated = connections.FirstOrDefault((CommunicationConnection x) => CommunicationResultWriteService.IsSupportedResultConnection(x) && string.Equals(x.Name, CS$<>8__locals1.designatedName, StringComparison.OrdinalIgnoreCase));
				bool flag2 = designated != null;
				if (flag2)
				{
					return designated;
				}
			}
			CS$<>8__locals1.cameraKey = CommunicationResultWriteService.NormalizeName("camera " + cameraName);
			CS$<>8__locals1.service = SharedCommunicationService.Instance;
			List<CommunicationConnection> candidates = connections.Where(delegate(CommunicationConnection x)
			{
				bool result;
				if (CommunicationResultWriteService.IsSupportedResultConnection(x) && !string.IsNullOrWhiteSpace(x.Name))
				{
					IEnumerable<CommunicationTagRow> tagsForConnection = CommunicationConfigStorageService.GetTagsForConnection(CS$<>8__locals1.config, x.Name);
					Func<CommunicationTagRow, bool> predicate;
					if ((predicate = CS$<>8__locals1.<>9__3) == null)
					{
						predicate = (CS$<>8__locals1.<>9__3 = ((CommunicationTagRow tag) => tag != null && string.Equals(tag.ReadWrite, "Write", StringComparison.OrdinalIgnoreCase) && CommunicationResultWriteService.IsLinkedToTool(tag) && !string.IsNullOrWhiteSpace(tag.Address) && CommunicationResultWriteService.NormalizeName(tag.Name).StartsWith(CS$<>8__locals1.cameraKey, StringComparison.Ordinal)));
					}
					result = tagsForConnection.Any(predicate);
				}
				else
				{
					result = false;
				}
				return result;
			}).ToList<CommunicationConnection>();
			return candidates.FirstOrDefault((CommunicationConnection x) => CS$<>8__locals1.service.IsConnected(x)) ?? candidates.FirstOrDefault<CommunicationConnection>();
		}

		// Token: 0x06001E11 RID: 7697 RVA: 0x000ADB58 File Offset: 0x000ABD58
		private static void NormalizeConnection(CommunicationConnection connection)
		{
			bool flag = connection == null;
			if (!flag)
			{
				bool flag2 = string.IsNullOrWhiteSpace(connection.Protocol);
				if (flag2)
				{
					connection.Protocol = "Modbus Client TCP/IP";
				}
				bool flag3 = connection.Port <= 0 && !string.Equals(connection.Protocol, "MX Component", StringComparison.OrdinalIgnoreCase);
				if (flag3)
				{
					connection.ApplyDefaultPort();
				}
				bool flag4 = connection.TimeoutMs <= 0;
				if (flag4)
				{
					connection.TimeoutMs = 2000;
				}
			}
		}

		// Token: 0x06001E12 RID: 7698 RVA: 0x000ADBD4 File Offset: 0x000ABDD4
		private static string NormalizeName(string value)
		{
			return new string((value ?? string.Empty).Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
		}

		// Token: 0x04000CA4 RID: 3236
		public const string AutoTriggeredInspectionOption = "Auto: Result Inspection of triggered TurnSnap";

		// Token: 0x04000CA5 RID: 3237
		public const string AutoTriggeredAlignOption = "Auto: Result Align of triggered TurnSnap";

		// Token: 0x04000CA6 RID: 3238
		private static readonly PlcCommunicationService CommunicationService = SharedCommunicationService.Instance;

		// Token: 0x04000CA7 RID: 3239
		private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

		// Token: 0x04000CA8 RID: 3240
		private const int MaxRegistersPerFrame = 120;

		// Token: 0x04000CA9 RID: 3241
		private static readonly string[] AlignBatchFields = new string[]
		{
			"Align.X",
			"Align.Y",
			"Align.Degree",
			"Align.Count"
		};

		// Token: 0x0200045B RID: 1115
		private class AlignBatchEntry
		{
			// Token: 0x17000B87 RID: 2951
			// (get) Token: 0x06002BF2 RID: 11250 RVA: 0x000EA81C File Offset: 0x000E8A1C
			// (set) Token: 0x06002BF3 RID: 11251 RVA: 0x000EA824 File Offset: 0x000E8A24
			public CommunicationTagRow Tag { get; set; }

			// Token: 0x17000B88 RID: 2952
			// (get) Token: 0x06002BF4 RID: 11252 RVA: 0x000EA82D File Offset: 0x000E8A2D
			// (set) Token: 0x06002BF5 RID: 11253 RVA: 0x000EA835 File Offset: 0x000E8A35
			public string Field { get; set; }

			// Token: 0x17000B89 RID: 2953
			// (get) Token: 0x06002BF6 RID: 11254 RVA: 0x000EA83E File Offset: 0x000E8A3E
			// (set) Token: 0x06002BF7 RID: 11255 RVA: 0x000EA846 File Offset: 0x000E8A46
			public int StartAddress { get; set; }

			// Token: 0x17000B8A RID: 2954
			// (get) Token: 0x06002BF8 RID: 11256 RVA: 0x000EA84F File Offset: 0x000E8A4F
			// (set) Token: 0x06002BF9 RID: 11257 RVA: 0x000EA857 File Offset: 0x000E8A57
			public List<double> Values { get; set; }

			// Token: 0x17000B8B RID: 2955
			// (get) Token: 0x06002BFA RID: 11258 RVA: 0x000EA860 File Offset: 0x000E8A60
			// (set) Token: 0x06002BFB RID: 11259 RVA: 0x000EA868 File Offset: 0x000E8A68
			public ushort[] Registers { get; set; }
		}
	}
}
