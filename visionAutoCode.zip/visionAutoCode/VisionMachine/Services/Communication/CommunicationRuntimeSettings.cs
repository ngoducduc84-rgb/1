﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001EB RID: 491
	public class CommunicationRuntimeSettings
	{
		// Token: 0x1700091B RID: 2331
		// (get) Token: 0x06001D41 RID: 7489 RVA: 0x000A5859 File Offset: 0x000A3A59
		// (set) Token: 0x06001D42 RID: 7490 RVA: 0x000A5861 File Offset: 0x000A3A61
		public string CameraTriggerConnectionName { get; set; } = "None";
	}
}
