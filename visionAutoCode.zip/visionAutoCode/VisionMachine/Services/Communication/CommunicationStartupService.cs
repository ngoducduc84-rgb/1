﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VisionMachine.Models.Communication;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F4 RID: 500
	public static class CommunicationStartupService
	{
		// Token: 0x14000031 RID: 49
		// (add) Token: 0x06001D91 RID: 7569 RVA: 0x000A7D14 File Offset: 0x000A5F14
		// (remove) Token: 0x06001D92 RID: 7570 RVA: 0x000A7D48 File Offset: 0x000A5F48
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler<CommunicationHealthChangedEventArgs> ConnectionHealthChanged;

		// Token: 0x06001D93 RID: 7571 RVA: 0x000A7D7C File Offset: 0x000A5F7C
		public static bool TryGetConnectionHealth(string connectionName, out CommunicationHealthState state)
		{
			Dictionary<string, CommunicationHealthState> runtimeStates = CommunicationStartupService.RuntimeStates;
			bool result;
			lock (runtimeStates)
			{
				result = CommunicationStartupService.RuntimeStates.TryGetValue(connectionName ?? string.Empty, out state);
			}
			return result;
		}

		// Token: 0x06001D94 RID: 7572 RVA: 0x000A7DD0 File Offset: 0x000A5FD0
		public static void ReportExternalConnectionHealth(string connectionName, bool isConnected, string message, bool forceNotify = true)
		{
			bool flag = string.IsNullOrWhiteSpace(connectionName);
			if (!flag)
			{
				CommunicationStartupService.ReportConnectionHealth(new CommunicationConnection
				{
					Name = connectionName
				}, isConnected, message, forceNotify, false, false, false);
			}
		}

		// Token: 0x06001D95 RID: 7573 RVA: 0x000A7E04 File Offset: 0x000A6004
		public static Task AutoConnectCurrentModelAsync(bool force = false, string configPath = null, bool startCameraTriggerWatcher = true)
		{
			configPath = (string.IsNullOrWhiteSpace(configPath) ? CommunicationConfigStorageService.GetConfigPath() : configPath);
			object syncRoot = CommunicationStartupService.SyncRoot;
			Task startupTask;
			lock (syncRoot)
			{
				bool flag2 = !force && CommunicationStartupService._startupTask != null && !CommunicationStartupService._startupTask.IsCompleted && string.Equals(CommunicationStartupService._lastStartedConfigPath, configPath, StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					startupTask = CommunicationStartupService._startupTask;
				}
				else
				{
					CommunicationStartupService._lastStartedConfigPath = configPath;
					CommunicationStartupService._startupTask = Task.Run(delegate()
					{
						CommunicationStartupService.AutoConnect(configPath, startCameraTriggerWatcher);
					});
					startupTask = CommunicationStartupService._startupTask;
				}
			}
			return startupTask;
		}

		// Token: 0x06001D96 RID: 7574 RVA: 0x000A7ED8 File Offset: 0x000A60D8
		public static void EnsureCurrentModelMonitorStarted(string configPath = null)
		{
			configPath = (string.IsNullOrWhiteSpace(configPath) ? CommunicationConfigStorageService.GetConfigPath() : configPath);
			CommunicationStartupService.StartHealthMonitor(configPath, false);
		}

		// Token: 0x06001D97 RID: 7575 RVA: 0x000A7EF8 File Offset: 0x000A60F8
		private static void AutoConnect(string configPath, bool startCameraTriggerWatcher)
		{
			CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(configPath);
			bool flag = ((config != null) ? config.Connections : null) == null || config.Connections.Count == 0;
			if (!flag)
			{
				CommunicationStartupService.WarnAboutMissingMxComponent(config.Connections);
				PlcCommunicationService communicationService = SharedCommunicationService.Instance;
				foreach (CommunicationConnection connection in config.Connections.Where(new Func<CommunicationConnection, bool>(CommunicationStartupService.IsAutoConnectCandidate)))
				{
					CommunicationHeartbeatMonitorHelper.NormalizeConnection(connection);
					CommunicationOperationResult connectResult = communicationService.ConnectIfDisconnected(CommunicationHeartbeatMonitorHelper.CreateHealthMonitorConnection(connection));
					CommunicationStartupService.ReportConnectionHealth(connection, connectResult.Success, connectResult.Message, false, false, false, false);
				}
				CommunicationInitialValueService.WriteCurrentModelAndLog(configPath);
				CommunicationStartupService.StartHealthMonitor(configPath, false);
				if (startCameraTriggerWatcher)
				{
					CameraTriggerCommunicationService.StartCurrentModel(configPath, false);
				}
			}
		}

		// Token: 0x06001D98 RID: 7576 RVA: 0x000A7FE8 File Offset: 0x000A61E8
		private static void WarnAboutMissingMxComponent(IEnumerable<CommunicationConnection> connections)
		{
			try
			{
				List<CommunicationConnection> mxConnections = (from x in connections ?? Enumerable.Empty<CommunicationConnection>()
				where x != null && CommunicationHeartbeatMonitorHelper.IsMxComponentProtocol(x.Protocol)
				select x).ToList<CommunicationConnection>();
				bool flag = mxConnections.Count == 0 || MxComponentRuntime.IsInstalled;
				if (!flag)
				{
					VisionLogService.Log("Error", "Communication", "MX-0001", MxComponentRuntime.DescribeInstallation() + " These connections stay offline: " + string.Join(", ", from x in mxConnections
					select x.Name) + ".", null, null);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine("MX Component availability check failed: " + ex.Message);
			}
		}

		// Token: 0x06001D99 RID: 7577 RVA: 0x000A80CC File Offset: 0x000A62CC
		private static void StartHealthMonitor(string configPath, bool force)
		{
			object syncRoot = CommunicationStartupService.SyncRoot;
			bool flag = false;
			try
			{
				Monitor.Enter(syncRoot, ref flag);
				bool samePath = string.Equals(CommunicationStartupService._healthMonitorConfigPath, configPath, StringComparison.OrdinalIgnoreCase);
				bool modbusMonitorAlive = CommunicationStartupService._modbusMonitorTask != null && !CommunicationStartupService._modbusMonitorTask.IsCompleted;
				bool opcHeartbeatMonitorAlive = CommunicationStartupService._opcHeartbeatMonitorTask != null && !CommunicationStartupService._opcHeartbeatMonitorTask.IsCompleted;
				bool flag2 = !force && samePath && modbusMonitorAlive && opcHeartbeatMonitorAlive;
				if (!flag2)
				{
					CancellationTokenSource previousCancellation = CommunicationStartupService._healthMonitorCancellation;
					Task previousModbusTask = CommunicationStartupService._modbusMonitorTask;
					Task previousOpcTask = CommunicationStartupService._opcHeartbeatMonitorTask;
					if (previousCancellation != null)
					{
						previousCancellation.Cancel();
					}
					CommunicationStartupService.DisposeCancellationWhenMonitorsExit(previousCancellation, previousModbusTask, previousOpcTask);
					CommunicationStartupService._healthMonitorCancellation = new CancellationTokenSource();
					CommunicationStartupService._healthMonitorConfigPath = configPath;
					CancellationToken token = CommunicationStartupService._healthMonitorCancellation.Token;
					CommunicationStartupService._modbusMonitorTask = Task.Run(delegate()
					{
						ModbusConnectionMonitorThread.Run(configPath, token);
					}, token);
					CommunicationStartupService._opcHeartbeatMonitorTask = Task.Run(delegate()
					{
						OpcUaHeartbeatMonitorThread.Run(configPath, token);
					}, token);
				}
			}
			finally
			{
				if (flag)
				{
					Monitor.Exit(syncRoot);
				}
			}
		}

		// Token: 0x06001D9A RID: 7578 RVA: 0x000A8224 File Offset: 0x000A6424
		private static bool IsAutoConnectCandidate(CommunicationConnection connection)
		{
			return CommunicationHeartbeatMonitorHelper.IsAutoConnectCandidate(connection);
		}

		// Token: 0x06001D9B RID: 7579 RVA: 0x000A823C File Offset: 0x000A643C
		private static void DisposeCancellationWhenMonitorsExit(CancellationTokenSource cancellation, Task modbusTask, Task opcTask)
		{
			bool flag = cancellation == null;
			if (!flag)
			{
				Task[] tasks = new Task[]
				{
					modbusTask ?? Task.CompletedTask,
					opcTask ?? Task.CompletedTask
				};
				Task.WhenAll(tasks).ContinueWith(delegate(Task _)
				{
					try
					{
						cancellation.Dispose();
					}
					catch
					{
					}
				}, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
			}
		}

		// Token: 0x06001D9C RID: 7580 RVA: 0x000A82B0 File Offset: 0x000A64B0
		internal static void ReportConnectionHealth(CommunicationConnection connection, bool isConnected, string message, bool forceNotify = false, bool isHeartbeatPulse = false, bool hasHeartbeatValue = false, bool heartbeatValue = false)
		{
			bool flag = connection == null || string.IsNullOrWhiteSpace(connection.Name);
			if (!flag)
			{
				CommunicationHealthState state = new CommunicationHealthState
				{
					ConnectionName = connection.Name,
					IsConnected = isConnected,
					Message = (string.IsNullOrWhiteSpace(message) ? (isConnected ? "Connected." : "Disconnected.") : message),
					LastUpdate = DateTime.Now,
					IsHeartbeatPulse = isHeartbeatPulse,
					HasHeartbeatValue = hasHeartbeatValue,
					HeartbeatValue = heartbeatValue,
					HeartbeatSequence = (hasHeartbeatValue ? Interlocked.Increment(ref CommunicationStartupService._heartbeatSequence) : 0L)
				};
				Dictionary<string, CommunicationHealthState> runtimeStates = CommunicationStartupService.RuntimeStates;
				bool changed;
				lock (runtimeStates)
				{
					CommunicationHealthState previous;
					changed = (forceNotify || !CommunicationStartupService.RuntimeStates.TryGetValue(connection.Name, out previous) || previous.IsConnected != state.IsConnected || (!state.IsConnected && !string.Equals(previous.Message, state.Message, StringComparison.Ordinal)));
					CommunicationStartupService.RuntimeStates[connection.Name] = state;
				}
				bool flag3 = changed;
				if (flag3)
				{
					EventHandler<CommunicationHealthChangedEventArgs> connectionHealthChanged = CommunicationStartupService.ConnectionHealthChanged;
					if (connectionHealthChanged != null)
					{
						connectionHealthChanged(null, new CommunicationHealthChangedEventArgs(state));
					}
				}
			}
		}

		// Token: 0x04000C7C RID: 3196
		private static readonly object SyncRoot = new object();

		// Token: 0x04000C7D RID: 3197
		private static string _lastStartedConfigPath;

		// Token: 0x04000C7E RID: 3198
		private static Task _startupTask;

		// Token: 0x04000C7F RID: 3199
		private static string _healthMonitorConfigPath;

		// Token: 0x04000C80 RID: 3200
		private static CancellationTokenSource _healthMonitorCancellation;

		// Token: 0x04000C81 RID: 3201
		private static Task _modbusMonitorTask;

		// Token: 0x04000C82 RID: 3202
		private static Task _opcHeartbeatMonitorTask;

		// Token: 0x04000C83 RID: 3203
		private static long _heartbeatSequence;

		// Token: 0x04000C84 RID: 3204
		private static readonly Dictionary<string, CommunicationHealthState> RuntimeStates = new Dictionary<string, CommunicationHealthState>(StringComparer.OrdinalIgnoreCase);
	}
}
