﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Security;
using System.Text;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F0 RID: 496
	public static class CommunicationTagExportService
	{
		// Token: 0x06001D7A RID: 7546 RVA: 0x000A6ED8 File Offset: 0x000A50D8
		public static void Export(IEnumerable<CommunicationTagRow> tags, string fileName, int filterIndex)
		{
			string extension2 = Path.GetExtension(fileName);
			string extension = (extension2 != null) ? extension2.ToLowerInvariant() : null;
			bool flag = string.IsNullOrWhiteSpace(extension);
			if (flag)
			{
				extension = ((filterIndex == 2) ? ".xls" : ((filterIndex == 3) ? ".csv" : ".xlsx"));
			}
			string text = extension;
			string a = text;
			if (!(a == ".csv"))
			{
				if (!(a == ".xls"))
				{
					if (!(a == ".xlsx"))
					{
						CommunicationTagExportService.ExportToXlsx(tags, fileName);
					}
					else
					{
						CommunicationTagExportService.ExportToXlsx(tags, fileName);
					}
				}
				else
				{
					CommunicationTagExportService.ExportToExcelXml(tags, fileName);
				}
			}
			else
			{
				CommunicationTagExportService.ExportToCsv(tags, fileName);
			}
		}

		// Token: 0x06001D7B RID: 7547 RVA: 0x000A6F78 File Offset: 0x000A5178
		private static void ExportToExcelXml(IEnumerable<CommunicationTagRow> tags, string fileName)
		{
			StringBuilder builder = new StringBuilder();
			builder.AppendLine("<?xml version=\"1.0\"?>");
			builder.AppendLine("<?mso-application progid=\"Excel.Sheet\"?>");
			builder.AppendLine("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"");
			builder.AppendLine(" xmlns:o=\"urn:schemas-microsoft-com:office:office\"");
			builder.AppendLine(" xmlns:x=\"urn:schemas-microsoft-com:office:excel\"");
			builder.AppendLine(" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\">");
			builder.AppendLine("<Worksheet ss:Name=\"Tag Management\">");
			builder.AppendLine("<Table>");
			CommunicationTagExportService.AppendExcelRow(builder, CommunicationTagExportService.HeaderColumns);
			foreach (CommunicationTagRow tag in (tags ?? Enumerable.Empty<CommunicationTagRow>()))
			{
				CommunicationTagExportService.AppendExcelRow(builder, CommunicationTagExportService.GetTagValues(tag));
			}
			builder.AppendLine("</Table>");
			builder.AppendLine("</Worksheet>");
			builder.AppendLine("</Workbook>");
			File.WriteAllText(fileName, builder.ToString(), Encoding.UTF8);
		}

		// Token: 0x06001D7C RID: 7548 RVA: 0x000A707C File Offset: 0x000A527C
		private static void ExportToCsv(IEnumerable<CommunicationTagRow> tags, string fileName)
		{
			StringBuilder builder = new StringBuilder();
			CommunicationTagExportService.AppendCsvRow(builder, CommunicationTagExportService.HeaderColumns);
			foreach (CommunicationTagRow tag in (tags ?? Enumerable.Empty<CommunicationTagRow>()))
			{
				CommunicationTagExportService.AppendCsvRow(builder, CommunicationTagExportService.GetTagValues(tag));
			}
			File.WriteAllText(fileName, builder.ToString(), new UTF8Encoding(true));
		}

		// Token: 0x06001D7D RID: 7549 RVA: 0x000A7100 File Offset: 0x000A5300
		private static void ExportToXlsx(IEnumerable<CommunicationTagRow> tags, string fileName)
		{
			bool flag = File.Exists(fileName);
			if (flag)
			{
				File.Delete(fileName);
			}
			using (Package package = Package.Open(fileName, FileMode.CreateNew))
			{
				Uri workbookUri = new Uri("/xl/workbook.xml", UriKind.Relative);
				Uri worksheetUri = new Uri("/xl/worksheets/sheet1.xml", UriKind.Relative);
				PackagePart workbookPart = package.CreatePart(workbookUri, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml", CompressionOption.Maximum);
				PackagePart worksheetPart = package.CreatePart(worksheetUri, "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml", CompressionOption.Maximum);
				package.CreateRelationship(workbookUri, TargetMode.Internal, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", "rId1");
				workbookPart.CreateRelationship(worksheetUri, TargetMode.Internal, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet", "rId1");
				using (StreamWriter writer = new StreamWriter(workbookPart.GetStream(FileMode.Create, FileAccess.Write), Encoding.UTF8))
				{
					writer.Write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Tag Management\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
				}
				using (StreamWriter writer2 = new StreamWriter(worksheetPart.GetStream(FileMode.Create, FileAccess.Write), Encoding.UTF8))
				{
					writer2.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
					writer2.WriteLine("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
					writer2.WriteLine("<sheetData>");
					CommunicationTagExportService.WriteXlsxRow(writer2, 1, CommunicationTagExportService.HeaderColumns);
					int rowIndex = 2;
					foreach (CommunicationTagRow tag in (tags ?? Enumerable.Empty<CommunicationTagRow>()))
					{
						CommunicationTagExportService.WriteXlsxRow(writer2, rowIndex++, CommunicationTagExportService.GetTagValues(tag));
					}
					writer2.WriteLine("</sheetData>");
					writer2.WriteLine("</worksheet>");
				}
			}
		}

		// Token: 0x06001D7E RID: 7550 RVA: 0x000A72F0 File Offset: 0x000A54F0
		private static string[] GetTagValues(CommunicationTagRow tag)
		{
			return new string[]
			{
				(tag != null) ? tag.Group : null,
				(tag != null) ? tag.Name : null,
				(tag != null) ? tag.Address : null,
				(tag != null) ? tag.DataType : null,
				(tag != null) ? tag.ReadWrite : null,
				(tag != null) ? tag.LinkedToolName : null,
				(tag != null) ? tag.ResultField : null,
				((tag != null) ? tag.MaxResultCount : 0).ToString(),
				(tag != null) ? tag.Description : null
			};
		}

		// Token: 0x06001D7F RID: 7551 RVA: 0x000A7398 File Offset: 0x000A5598
		private static void AppendExcelRow(StringBuilder builder, params string[] values)
		{
			builder.AppendLine("<Row>");
			foreach (string value in values)
			{
				builder.Append("<Cell><Data ss:Type=\"String\">");
				builder.Append(CommunicationTagExportService.EscapeExcelXml(value));
				builder.AppendLine("</Data></Cell>");
			}
			builder.AppendLine("</Row>");
		}

		// Token: 0x06001D80 RID: 7552 RVA: 0x000A73FC File Offset: 0x000A55FC
		private static string EscapeExcelXml(string value)
		{
			return SecurityElement.Escape(value ?? string.Empty) ?? string.Empty;
		}

		// Token: 0x06001D81 RID: 7553 RVA: 0x000A7426 File Offset: 0x000A5626
		private static void AppendCsvRow(StringBuilder builder, params string[] values)
		{
			builder.AppendLine(string.Join(",", values.Select(new Func<string, string>(CommunicationTagExportService.EscapeCsvValue))));
		}

		// Token: 0x06001D82 RID: 7554 RVA: 0x000A744C File Offset: 0x000A564C
		private static string EscapeCsvValue(string value)
		{
			value = (value ?? string.Empty);
			bool flag = value.Contains("\"") || value.Contains(",") || value.Contains("\r") || value.Contains("\n");
			string result;
			if (flag)
			{
				result = "\"" + value.Replace("\"", "\"\"") + "\"";
			}
			else
			{
				result = value;
			}
			return result;
		}

		// Token: 0x06001D83 RID: 7555 RVA: 0x000A74C8 File Offset: 0x000A56C8
		private static void WriteXlsxRow(StreamWriter writer, int rowIndex, params string[] values)
		{
			writer.Write("<row r=\"");
			writer.Write(rowIndex);
			writer.Write("\">");
			foreach (string value in values)
			{
				writer.Write("<c t=\"inlineStr\"><is><t>");
				writer.Write(CommunicationTagExportService.EscapeExcelXml(value));
				writer.Write("</t></is></c>");
			}
			writer.WriteLine("</row>");
		}

		// Token: 0x04000C70 RID: 3184
		private static readonly string[] HeaderColumns = new string[]
		{
			"Group",
			"Tag Name",
			"Address",
			"Data Type",
			"R/W",
			"Linked Tool",
			"Result Field",
			"Max Count",
			"Description"
		};
	}
}
