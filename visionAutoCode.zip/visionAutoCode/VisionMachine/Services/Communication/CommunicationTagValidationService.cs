﻿using System;
using System.Collections.Generic;
using System.Linq;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F1 RID: 497
	public static class CommunicationTagValidationService
	{
		// Token: 0x06001D85 RID: 7557 RVA: 0x000A75A4 File Offset: 0x000A57A4
		public static bool UpdateDuplicateWarnings(IEnumerable<CommunicationTagRow> tags)
		{
			List<CommunicationTagRow> tagList = (from x in tags ?? Enumerable.Empty<CommunicationTagRow>()
			where x != null
			select x).ToList<CommunicationTagRow>();
			foreach (CommunicationTagRow tag in tagList)
			{
				tag.HasDuplicateValue = false;
				tag.ValidationMessage = null;
			}
			CommunicationTagValidationService.MarkDuplicateTagNames(tagList);
			CommunicationTagValidationService.MarkOverlappingTagAddresses(tagList);
			return tagList.Any((CommunicationTagRow x) => x.HasDuplicateValue);
		}

		// Token: 0x06001D86 RID: 7558 RVA: 0x000A766C File Offset: 0x000A586C
		private static void MarkDuplicateTagNames(IEnumerable<CommunicationTagRow> tags)
		{
			IEnumerable<IGrouping<string, CommunicationTagRow>> duplicateNameGroups = from x in tags
			where !string.IsNullOrWhiteSpace(x.Name)
			group x by CommunicationTagValidationService.NormalizeTagName(x.Name) into x
			where !string.IsNullOrWhiteSpace(x.Key) && x.Count<CommunicationTagRow>() > 1
			select x;
			foreach (IGrouping<string, CommunicationTagRow> group in duplicateNameGroups)
			{
				foreach (CommunicationTagRow tag in group)
				{
					CommunicationTagValidationService.AddTagValidationMessage(tag, "Duplicate tag name.");
				}
			}
		}

		// Token: 0x06001D87 RID: 7559 RVA: 0x000A7760 File Offset: 0x000A5960
		private static void MarkOverlappingTagAddresses(IEnumerable<CommunicationTagRow> tags)
		{
			var ranges = tags.Where(delegate(CommunicationTagRow x)
			{
				int num;
				return CommunicationTagValidationService.TryParseTagAddress(x.Address, out num);
			}).Select(delegate(CommunicationTagRow x)
			{
				int start;
				CommunicationTagValidationService.TryParseTagAddress(x.Address, out start);
				int length = CommunicationTagValidationService.GetReservedRegisterCount(x);
				return new
				{
					Tag = x,
					Start = start,
					End = start + Math.Max(1, length) - 1
				};
			}).ToList();
			for (int i = 0; i < ranges.Count; i++)
			{
				for (int j = i + 1; j < ranges.Count; j++)
				{
					var first = ranges[i];
					var second = ranges[j];
					bool flag = first.End < second.Start || second.End < first.Start;
					if (!flag)
					{
						CommunicationTagValidationService.AddTagValidationMessage(first.Tag, string.Format("Address range overlaps with '{0}' ({1}-{2}).", second.Tag.Name, second.Start, second.End));
						CommunicationTagValidationService.AddTagValidationMessage(second.Tag, string.Format("Address range overlaps with '{0}' ({1}-{2}).", first.Tag.Name, first.Start, first.End));
					}
				}
			}
		}

		// Token: 0x06001D88 RID: 7560 RVA: 0x000A78AC File Offset: 0x000A5AAC
		private static void AddTagValidationMessage(CommunicationTagRow tag, string message)
		{
			bool flag = tag == null || string.IsNullOrWhiteSpace(message);
			if (!flag)
			{
				tag.HasDuplicateValue = true;
				bool flag2 = string.IsNullOrWhiteSpace(tag.ValidationMessage);
				if (flag2)
				{
					tag.ValidationMessage = message;
				}
				else
				{
					bool flag3 = tag.ValidationMessage.IndexOf(message, StringComparison.OrdinalIgnoreCase) < 0;
					if (flag3)
					{
						tag.ValidationMessage = tag.ValidationMessage + Environment.NewLine + message;
					}
				}
			}
		}

		// Token: 0x06001D89 RID: 7561 RVA: 0x000A791C File Offset: 0x000A5B1C
		private static bool TryParseTagAddress(string address, out int value)
		{
			value = 0;
			bool flag = string.IsNullOrWhiteSpace(address);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string cleaned = address.Trim();
				result = int.TryParse(cleaned, out value);
			}
			return result;
		}

		// Token: 0x06001D8A RID: 7562 RVA: 0x000A7950 File Offset: 0x000A5B50
		private static int GetReservedRegisterCount(CommunicationTagRow tag)
		{
			bool flag = tag == null;
			int result;
			if (flag)
			{
				result = 1;
			}
			else
			{
				int dataTypeRegisters = CommunicationTagValidationService.GetDataTypeRegisterCount(tag.DataType);
				int maxResultCount = Math.Max(1, tag.MaxResultCount);
				bool flag2 = CommunicationTagValidationService.IsVisionResultTag(tag);
				if (flag2)
				{
					result = Math.Max(dataTypeRegisters, maxResultCount);
				}
				else
				{
					result = dataTypeRegisters;
				}
			}
			return result;
		}

		// Token: 0x06001D8B RID: 7563 RVA: 0x000A79A0 File Offset: 0x000A5BA0
		private static int GetDataTypeRegisterCount(string dataType)
		{
			bool flag = string.IsNullOrWhiteSpace(dataType);
			int result;
			if (flag)
			{
				result = 1;
			}
			else
			{
				string text = dataType.Trim().ToUpperInvariant();
				string text2 = text;
				uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
				if (num <= 1573693125U)
				{
					if (num <= 200059396U)
					{
						if (num != 72344531U)
						{
							if (num != 200059396U)
							{
								goto IL_14D;
							}
							if (!(text2 == "INT64"))
							{
								goto IL_14D;
							}
							goto IL_149;
						}
						else
						{
							if (!(text2 == "UINT64"))
							{
								goto IL_14D;
							}
							goto IL_149;
						}
					}
					else if (num != 843930396U)
					{
						if (num != 1573693125U)
						{
							goto IL_14D;
						}
						if (!(text2 == "UDINT"))
						{
							goto IL_14D;
						}
					}
					else if (!(text2 == "DINT"))
					{
						goto IL_14D;
					}
				}
				else if (num <= 2286151596U)
				{
					if (num != 2214109151U)
					{
						if (num != 2286151596U)
						{
							goto IL_14D;
						}
						if (!(text2 == "UINT32"))
						{
							goto IL_14D;
						}
					}
					else if (!(text2 == "INT32"))
					{
						goto IL_14D;
					}
				}
				else if (num != 2316881829U)
				{
					if (num != 3560013981U)
					{
						if (num != 3751281736U)
						{
							goto IL_14D;
						}
						if (!(text2 == "DOUBLE"))
						{
							goto IL_14D;
						}
						goto IL_149;
					}
					else if (!(text2 == "REAL"))
					{
						goto IL_14D;
					}
				}
				else if (!(text2 == "FLOAT"))
				{
					goto IL_14D;
				}
				return 2;
				IL_149:
				return 4;
				IL_14D:
				result = 1;
			}
			return result;
		}

		// Token: 0x06001D8C RID: 7564 RVA: 0x000A7B00 File Offset: 0x000A5D00
		private static bool IsVisionResultTag(CommunicationTagRow tag)
		{
			bool flag = tag == null || string.IsNullOrWhiteSpace(tag.Group);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string group = tag.Group.Trim();
				result = (group.IndexOf("Vision Result", StringComparison.OrdinalIgnoreCase) >= 0 || group.IndexOf("Vision Align", StringComparison.OrdinalIgnoreCase) >= 0 || group.IndexOf("Vision Inspection", StringComparison.OrdinalIgnoreCase) >= 0);
			}
			return result;
		}

		// Token: 0x06001D8D RID: 7565 RVA: 0x000A7B6C File Offset: 0x000A5D6C
		private static string NormalizeTagName(string name)
		{
			return string.IsNullOrWhiteSpace(name) ? string.Empty : new string(name.Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
		}
	}
}
