﻿using System;
using System.Globalization;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000229 RID: 553
	internal static class CommunicationValueConverter
	{
		// Token: 0x06001F41 RID: 8001 RVA: 0x000B6724 File Offset: 0x000B4924
		public static int GetRegisterStride(string dataType)
		{
			string text = (dataType ?? string.Empty).ToUpperInvariant();
			string a = text;
			int result;
			if (!(a == "INT32") && !(a == "UINT32") && !(a == "DINT") && !(a == "FLOAT") && !(a == "REAL"))
			{
				result = 1;
			}
			else
			{
				result = 2;
			}
			return result;
		}

		// Token: 0x06001F42 RID: 8002 RVA: 0x000B6790 File Offset: 0x000B4990
		public static string ConvertRegisterValue(ushort rawValue, string dataType)
		{
			string text = (dataType ?? string.Empty).ToUpperInvariant();
			string a = text;
			string result;
			if (!(a == "BOOL"))
			{
				if (!(a == "INT16"))
				{
					if (!(a == "UINT16"))
					{
						result = rawValue.ToString();
					}
					else
					{
						result = rawValue.ToString();
					}
				}
				else
				{
					result = ((short)rawValue).ToString();
				}
			}
			else
			{
				result = ((rawValue != 0) ? "ON" : "OFF");
			}
			return result;
		}

		// Token: 0x06001F43 RID: 8003 RVA: 0x000B6810 File Offset: 0x000B4A10
		public static string ConvertRegisterValues(ushort[] registers, int index, string dataType)
		{
			bool flag = registers == null || index < 0 || index >= registers.Length;
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				string text = (dataType ?? string.Empty).ToUpperInvariant();
				string text2 = text;
				uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
				if (num > 2214109151U)
				{
					if (num <= 2316881829U)
					{
						if (num != 2286151596U)
						{
							if (num != 2316881829U)
							{
								goto IL_1D6;
							}
							if (!(text2 == "FLOAT"))
							{
								goto IL_1D6;
							}
						}
						else
						{
							if (!(text2 == "UINT32"))
							{
								goto IL_1D6;
							}
							return CommunicationValueConverter.CombineUInt32(registers, index).ToString();
						}
					}
					else if (num != 2991499325U)
					{
						if (num != 3560013981U)
						{
							goto IL_1D6;
						}
						if (!(text2 == "REAL"))
						{
							goto IL_1D6;
						}
					}
					else
					{
						if (!(text2 == "BOOL"))
						{
							goto IL_1D6;
						}
						return (registers[index] != 0) ? "ON" : "OFF";
					}
					return CommunicationValueConverter.ConvertFloat(registers, index).ToString("0.######");
				}
				if (num > 268302705U)
				{
					if (num != 843930396U)
					{
						if (num != 2214109151U)
						{
							goto IL_1D6;
						}
						if (!(text2 == "INT32"))
						{
							goto IL_1D6;
						}
					}
					else if (!(text2 == "DINT"))
					{
						goto IL_1D6;
					}
					return ((int)CommunicationValueConverter.CombineUInt32(registers, index)).ToString();
				}
				if (num != 71211698U)
				{
					if (num == 268302705U)
					{
						if (text2 == "INT16")
						{
							return ((short)registers[index]).ToString();
						}
					}
				}
				else if (text2 == "UINT16")
				{
					return registers[index].ToString();
				}
				IL_1D6:
				result = registers[index].ToString();
			}
			return result;
		}

		// Token: 0x06001F44 RID: 8004 RVA: 0x000B6A04 File Offset: 0x000B4C04
		public static ushort[] ConvertValueToRegisters(string value, string dataType)
		{
			string normalizedType = (dataType ?? string.Empty).ToUpperInvariant();
			string text = (value ?? string.Empty).Trim();
			string text2 = normalizedType;
			string text3 = text2;
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text3);
			if (num > 2214109151U)
			{
				if (num <= 2316881829U)
				{
					if (num != 2286151596U)
					{
						if (num != 2316881829U)
						{
							goto IL_1E6;
						}
						if (!(text3 == "FLOAT"))
						{
							goto IL_1E6;
						}
					}
					else
					{
						if (!(text3 == "UINT32"))
						{
							goto IL_1E6;
						}
						return CommunicationValueConverter.SplitUInt32(uint.Parse(text, CultureInfo.InvariantCulture));
					}
				}
				else if (num != 2991499325U)
				{
					if (num != 3560013981U)
					{
						goto IL_1E6;
					}
					if (!(text3 == "REAL"))
					{
						goto IL_1E6;
					}
				}
				else
				{
					if (!(text3 == "BOOL"))
					{
						goto IL_1E6;
					}
					return new ushort[]
					{
						CommunicationValueConverter.ParseBoolRegister(text)
					};
				}
				return CommunicationValueConverter.SplitFloat(float.Parse(text, CultureInfo.InvariantCulture));
			}
			if (num > 268302705U)
			{
				if (num != 843930396U)
				{
					if (num != 2214109151U)
					{
						goto IL_1E6;
					}
					if (!(text3 == "INT32"))
					{
						goto IL_1E6;
					}
				}
				else if (!(text3 == "DINT"))
				{
					goto IL_1E6;
				}
				return CommunicationValueConverter.SplitUInt32((uint)int.Parse(text, CultureInfo.InvariantCulture));
			}
			if (num != 71211698U)
			{
				if (num == 268302705U)
				{
					if (text3 == "INT16")
					{
						return new ushort[]
						{
							(ushort)short.Parse(text, CultureInfo.InvariantCulture)
						};
					}
				}
			}
			else if (text3 == "UINT16")
			{
				return new ushort[]
				{
					ushort.Parse(text, CultureInfo.InvariantCulture)
				};
			}
			IL_1E6:
			return new ushort[]
			{
				ushort.Parse(text, CultureInfo.InvariantCulture)
			};
		}

		// Token: 0x06001F45 RID: 8005 RVA: 0x000B6C14 File Offset: 0x000B4E14
		private static ushort ParseBoolRegister(string value)
		{
			bool flag = string.Equals(value, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "TRUE", StringComparison.OrdinalIgnoreCase);
			ushort result;
			if (flag)
			{
				result = 1;
			}
			else
			{
				bool flag2 = string.Equals(value, "OFF", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "FALSE", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = 0;
				}
				else
				{
					result = Convert.ToUInt16(value, CultureInfo.InvariantCulture);
				}
			}
			return result;
		}

		// Token: 0x06001F46 RID: 8006 RVA: 0x000B6C80 File Offset: 0x000B4E80
		private static ushort[] SplitUInt32(uint value)
		{
			return new ushort[]
			{
				(ushort)(value >> 16),
				(ushort)(value & 65535U)
			};
		}

		// Token: 0x06001F47 RID: 8007 RVA: 0x000B6CAC File Offset: 0x000B4EAC
		private static ushort[] SplitFloat(float value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			bool isLittleEndian = BitConverter.IsLittleEndian;
			if (isLittleEndian)
			{
				Array.Reverse(bytes);
			}
			return new ushort[]
			{
				(ushort)((int)bytes[0] << 8 | (int)bytes[1]),
				(ushort)((int)bytes[2] << 8 | (int)bytes[3])
			};
		}

		// Token: 0x06001F48 RID: 8008 RVA: 0x000B6CF8 File Offset: 0x000B4EF8
		private static uint CombineUInt32(ushort[] registers, int index)
		{
			bool flag = index + 1 >= registers.Length;
			if (flag)
			{
				throw new FormatException("Not enough registers for 32-bit value.");
			}
			return (uint)((int)registers[index] << 16 | (int)registers[index + 1]);
		}

		// Token: 0x06001F49 RID: 8009 RVA: 0x000B6D30 File Offset: 0x000B4F30
		private static float ConvertFloat(ushort[] registers, int index)
		{
			bool flag = index + 1 >= registers.Length;
			if (flag)
			{
				throw new FormatException("Not enough registers for float value.");
			}
			byte[] bytes = new byte[]
			{
				(byte)(registers[index] >> 8),
				(byte)(registers[index] & 255),
				(byte)(registers[index + 1] >> 8),
				(byte)(registers[index + 1] & 255)
			};
			bool isLittleEndian = BitConverter.IsLittleEndian;
			if (isLittleEndian)
			{
				Array.Reverse(bytes);
			}
			return BitConverter.ToSingle(bytes, 0);
		}
	}
}
