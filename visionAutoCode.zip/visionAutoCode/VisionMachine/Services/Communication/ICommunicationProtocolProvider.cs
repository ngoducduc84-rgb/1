﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200020E RID: 526
	internal interface ICommunicationProtocolProvider
	{
		// Token: 0x06001E9C RID: 7836
		bool CanHandle(string protocol);

		// Token: 0x06001E9D RID: 7837
		IPlcCommunicationClient CreateClient();
	}
}
