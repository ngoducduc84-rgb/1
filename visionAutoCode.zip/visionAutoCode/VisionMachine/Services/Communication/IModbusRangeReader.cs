﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000219 RID: 537
	internal interface IModbusRangeReader
	{
		// Token: 0x06001EB6 RID: 7862
		CommunicationReadResult ReadRange(string startAddressText, string endAddressText, string dataType, string functionCodeText);
	}
}
