﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200021A RID: 538
	internal interface IModbusRegisterArrayWriter
	{
		// Token: 0x06001EB7 RID: 7863
		CommunicationOperationResult WriteRegisters(string address, ushort[] values);
	}
}
