﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000206 RID: 518
	internal interface IMxComponentSession : IDisposable
	{
		// Token: 0x06001E5B RID: 7771
		int Open(int logicalStationNumber);

		// Token: 0x06001E5C RID: 7772
		int Close();

		// Token: 0x06001E5D RID: 7773
		int GetDevice(string device, out int value);

		// Token: 0x06001E5E RID: 7774
		int SetDevice(string device, int value);

		// Token: 0x06001E5F RID: 7775
		int GetCpuType(out string cpuName);
	}
}
