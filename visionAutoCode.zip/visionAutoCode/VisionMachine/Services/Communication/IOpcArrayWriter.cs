﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200021C RID: 540
	internal interface IOpcArrayWriter
	{
		// Token: 0x06001EB9 RID: 7865
		CommunicationOperationResult WriteArray(string nodeId, string dataType, IReadOnlyList<string> values);
	}
}
