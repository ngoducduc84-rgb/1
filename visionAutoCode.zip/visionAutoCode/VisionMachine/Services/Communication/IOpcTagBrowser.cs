﻿using System;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200021B RID: 539
	internal interface IOpcTagBrowser
	{
		// Token: 0x06001EB8 RID: 7864
		CommunicationReadResult BrowseTags(CommunicationConnection connection);
	}
}
