﻿using System;
using System.Collections.Generic;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000218 RID: 536
	internal interface IPlcCommunicationClient : IDisposable
	{
		// Token: 0x17000946 RID: 2374
		// (get) Token: 0x06001EB1 RID: 7857
		bool IsConnectionAlive { get; }

		// Token: 0x06001EB2 RID: 7858
		CommunicationOperationResult Connect(CommunicationConnection connection);

		// Token: 0x06001EB3 RID: 7859
		CommunicationOperationResult Test(CommunicationConnection connection);

		// Token: 0x06001EB4 RID: 7860
		CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags);

		// Token: 0x06001EB5 RID: 7861
		CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value);
	}
}
