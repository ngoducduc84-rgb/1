﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000201 RID: 513
	internal sealed class McDevice
	{
		// Token: 0x1700093A RID: 2362
		// (get) Token: 0x06001E2C RID: 7724 RVA: 0x000AE283 File Offset: 0x000AC483
		// (set) Token: 0x06001E2D RID: 7725 RVA: 0x000AE28B File Offset: 0x000AC48B
		public string Prefix { get; set; }

		// Token: 0x1700093B RID: 2363
		// (get) Token: 0x06001E2E RID: 7726 RVA: 0x000AE294 File Offset: 0x000AC494
		// (set) Token: 0x06001E2F RID: 7727 RVA: 0x000AE29C File Offset: 0x000AC49C
		public byte Code { get; set; }

		// Token: 0x1700093C RID: 2364
		// (get) Token: 0x06001E30 RID: 7728 RVA: 0x000AE2A5 File Offset: 0x000AC4A5
		// (set) Token: 0x06001E31 RID: 7729 RVA: 0x000AE2AD File Offset: 0x000AC4AD
		public int Number { get; set; }

		// Token: 0x1700093D RID: 2365
		// (get) Token: 0x06001E32 RID: 7730 RVA: 0x000AE2B6 File Offset: 0x000AC4B6
		// (set) Token: 0x06001E33 RID: 7731 RVA: 0x000AE2BE File Offset: 0x000AC4BE
		public bool IsBitDevice { get; set; }
	}
}
