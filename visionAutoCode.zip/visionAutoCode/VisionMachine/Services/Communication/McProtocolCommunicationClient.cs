﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000224 RID: 548
	internal class McProtocolCommunicationClient : TcpCommunicationClientBase
	{
		// Token: 0x06001EF6 RID: 7926 RVA: 0x000B2B74 File Offset: 0x000B0D74
		public override CommunicationOperationResult Connect(CommunicationConnection connection)
		{
			string text;
			if (connection == null)
			{
				text = null;
			}
			else
			{
				string ipAddress2 = connection.IpAddress;
				text = ((ipAddress2 != null) ? ipAddress2.Trim() : null);
			}
			string ipAddress = text;
			bool flag = string.IsNullOrWhiteSpace(ipAddress) || ipAddress == "0.0.0.0" || ipAddress == "::" || ipAddress == "::0";
			CommunicationOperationResult result2;
			if (flag)
			{
				result2 = CommunicationOperationResult.Fail("MC Protocol requires the IP address of the PLC Ethernet module.", 0, 0);
			}
			else
			{
				CommunicationOperationResult result = base.Connect(connection);
				result2 = (result.Success ? CommunicationOperationResult.Ok(string.Concat(new string[]
				{
					"MC Protocol socket open to ",
					ipAddress,
					":",
					connection.Port.ToString(),
					"."
				}), 0, 0) : result);
			}
			return result2;
		}

		// Token: 0x06001EF7 RID: 7927 RVA: 0x000B2C38 File Offset: 0x000B0E38
		public override CommunicationOperationResult Test(CommunicationConnection connection)
		{
			bool flag = !base.IsConnected();
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("MC Protocol socket is not connected.", 0, 0);
			}
			else
			{
				McDevice device;
				string parseError;
				bool flag2 = !McProtocolFrame.TryParseDevice("D0", out device, out parseError);
				if (flag2)
				{
					result = CommunicationOperationResult.Fail(parseError, 0, 0);
				}
				else
				{
					byte[] payload;
					string error;
					bool flag3 = !this.Exchange(McProtocolFrame.BuildWordReadRequest(device, 1, McProtocolCommunicationClient.GetTimeout(connection)), out payload, out error);
					if (flag3)
					{
						result = CommunicationOperationResult.Fail("MC Protocol probe failed: " + error, 0, 0);
					}
					else
					{
						result = CommunicationOperationResult.Ok("MC Protocol OK.", 0, payload.Length);
					}
				}
			}
			return result;
		}

		// Token: 0x06001EF8 RID: 7928 RVA: 0x000B2CD4 File Offset: 0x000B0ED4
		public override CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			bool flag = !base.IsConnected();
			CommunicationReadResult result;
			if (flag)
			{
				result = CommunicationReadResult.Fail("MC Protocol is not connected.");
			}
			else
			{
				List<CommunicationMonitorRow> rows = new List<CommunicationMonitorRow>();
				int readBytes = 0;
				string firstError = null;
				int timeout = McProtocolCommunicationClient.GetTimeout(connection);
				foreach (CommunicationTagRow tag in (tags ?? Enumerable.Empty<CommunicationTagRow>()))
				{
					bool flag2 = tag == null || string.IsNullOrWhiteSpace(tag.Address);
					if (!flag2)
					{
						string value;
						int bytes;
						string error;
						bool ok = this.TryReadTag(tag.Address.Trim(), tag.DataType, timeout, out value, out bytes, out error);
						bool flag3 = ok;
						if (flag3)
						{
							readBytes += bytes;
						}
						else
						{
							value = "--";
							bool flag4 = firstError == null;
							if (flag4)
							{
								firstError = error;
							}
						}
						rows.Add(new CommunicationMonitorRow(tag.Name, tag.Group, tag.ReadWrite, tag.Address, tag.DataType, value, ok ? "Good" : "Bad", DateTime.Now.ToString("HH:mm:ss.fff"), tag.Description));
					}
				}
				bool success = firstError == null;
				result = CommunicationReadResult.From(success, success ? ("Read " + rows.Count.ToString() + " tag(s) over MC Protocol.") : firstError, rows, 0, readBytes);
			}
			return result;
		}

		// Token: 0x06001EF9 RID: 7929 RVA: 0x000B2E60 File Offset: 0x000B1060
		public override CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			bool flag = !base.IsConnected();
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("MC Protocol is not connected.", 0, 0);
			}
			else
			{
				McDevice device;
				string error;
				bool flag2 = !McProtocolFrame.TryParseDevice(address, out device, out error);
				if (flag2)
				{
					result = CommunicationOperationResult.Fail(error, 0, 0);
				}
				else
				{
					int timeout = McProtocolCommunicationClient.GetTimeout(connection);
					bool isBool = string.Equals(dataType, "BOOL", StringComparison.OrdinalIgnoreCase);
					bool flag3 = isBool && device.IsBitDevice;
					byte[] request;
					if (flag3)
					{
						request = McProtocolFrame.BuildBitWriteRequest(device, McProtocolCommunicationClient.ParseBoolean(value), timeout);
					}
					else
					{
						ushort[] words;
						bool flag4 = !McProtocolCommunicationClient.TryEncodeWords(dataType, value, isBool, out words, out error);
						if (flag4)
						{
							return CommunicationOperationResult.Fail(error, 0, 0);
						}
						request = McProtocolFrame.BuildWordWriteRequest(device, words, timeout);
					}
					byte[] payload;
					bool flag5 = !this.Exchange(request, out payload, out error);
					if (flag5)
					{
						result = CommunicationOperationResult.Fail("MC Protocol write failed: " + error, 0, 0);
					}
					else
					{
						result = CommunicationOperationResult.Ok(string.Concat(new string[]
						{
							"Wrote ",
							address.Trim(),
							" = ",
							value,
							"."
						}), request.Length, 0);
					}
				}
			}
			return result;
		}

		// Token: 0x06001EFA RID: 7930 RVA: 0x000B2F88 File Offset: 0x000B1188
		private bool TryReadTag(string address, string dataType, int timeout, out string value, out int readBytes, out string error)
		{
			value = null;
			readBytes = 0;
			McDevice device;
			bool flag = !McProtocolFrame.TryParseDevice(address, out device, out error);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool isBool = string.Equals(dataType, "BOOL", StringComparison.OrdinalIgnoreCase);
				bool flag2 = isBool && device.IsBitDevice;
				if (flag2)
				{
					byte[] bitPayload;
					bool flag3 = !this.Exchange(McProtocolFrame.BuildBitReadRequest(device, 1, timeout), out bitPayload, out error);
					if (flag3)
					{
						result = false;
					}
					else
					{
						bool flag4 = bitPayload.Length < 1;
						if (flag4)
						{
							error = "MC Protocol returned no data for " + address + ".";
							result = false;
						}
						else
						{
							value = (((bitPayload[0] & 240) != 0) ? "1" : "0");
							readBytes = bitPayload.Length;
							result = true;
						}
					}
				}
				else
				{
					int wordCount = McProtocolCommunicationClient.GetWordCount(dataType);
					byte[] payload;
					bool flag5 = !this.Exchange(McProtocolFrame.BuildWordReadRequest(device, wordCount, timeout), out payload, out error);
					if (flag5)
					{
						result = false;
					}
					else
					{
						bool flag6 = payload.Length < wordCount * 2;
						if (flag6)
						{
							error = string.Concat(new string[]
							{
								"MC Protocol returned ",
								payload.Length.ToString(),
								" byte(s) for ",
								address,
								", expected ",
								(wordCount * 2).ToString(),
								"."
							});
							result = false;
						}
						else
						{
							readBytes = payload.Length;
							value = McProtocolCommunicationClient.DecodeValue(dataType, payload, isBool);
							result = true;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001EFB RID: 7931 RVA: 0x000B30F4 File Offset: 0x000B12F4
		private bool Exchange(byte[] request, out byte[] payload, out string error)
		{
			payload = null;
			error = null;
			object frameLock = this._frameLock;
			bool result;
			lock (frameLock)
			{
				try
				{
					this.Stream.Write(request, 0, request.Length);
					this.Stream.Flush();
					byte[] header = new byte[11];
					bool flag2 = !this.ReadExactly(header, header.Length, out error);
					if (flag2)
					{
						result = false;
					}
					else
					{
						int dataLength = McProtocolFrame.GetResponseDataLength(header);
						byte[] data = new byte[dataLength];
						bool flag3 = dataLength > 0 && !this.ReadExactly(data, dataLength, out error);
						if (flag3)
						{
							result = false;
						}
						else
						{
							result = McProtocolFrame.TryReadResponse(header, data, out payload, out error);
						}
					}
				}
				catch (Exception ex)
				{
					error = ex.Message;
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001EFC RID: 7932 RVA: 0x000B31D0 File Offset: 0x000B13D0
		private bool ReadExactly(byte[] buffer, int count, out string error)
		{
			error = null;
			int read;
			for (int offset = 0; offset < count; offset += read)
			{
				read = this.Stream.Read(buffer, offset, count - offset);
				bool flag = read <= 0;
				if (flag)
				{
					error = "The PLC closed the connection while a response was being read.";
					return false;
				}
			}
			return true;
		}

		// Token: 0x06001EFD RID: 7933 RVA: 0x000B3224 File Offset: 0x000B1424
		private static int GetTimeout(CommunicationConnection connection)
		{
			int timeout = (connection != null) ? connection.TimeoutMs : 0;
			return (timeout > 0) ? timeout : 2000;
		}

		// Token: 0x06001EFE RID: 7934 RVA: 0x000B3250 File Offset: 0x000B1450
		private static int GetWordCount(string dataType)
		{
			string text = (dataType ?? string.Empty).Trim().ToUpperInvariant();
			string a = text;
			int result;
			if (!(a == "INT32") && !(a == "UINT32") && !(a == "DINT") && !(a == "FLOAT") && !(a == "REAL"))
			{
				result = 1;
			}
			else
			{
				result = 2;
			}
			return result;
		}

		// Token: 0x06001EFF RID: 7935 RVA: 0x000B32C4 File Offset: 0x000B14C4
		private static string DecodeValue(string dataType, byte[] payload, bool isBool)
		{
			ushort low = (ushort)((int)payload[0] | (int)payload[1] << 8);
			string text = (dataType ?? string.Empty).Trim().ToUpperInvariant();
			string text2 = text;
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
			if (num > 2214109151U)
			{
				if (num <= 2316881829U)
				{
					if (num != 2286151596U)
					{
						if (num != 2316881829U)
						{
							goto IL_17D;
						}
						if (!(text2 == "FLOAT"))
						{
							goto IL_17D;
						}
					}
					else
					{
						if (!(text2 == "UINT32"))
						{
							goto IL_17D;
						}
						return ((uint)McProtocolCommunicationClient.ToInt32(payload)).ToString(CultureInfo.InvariantCulture);
					}
				}
				else if (num != 2991499325U)
				{
					if (num != 3560013981U)
					{
						goto IL_17D;
					}
					if (!(text2 == "REAL"))
					{
						goto IL_17D;
					}
				}
				else
				{
					if (!(text2 == "BOOL"))
					{
						goto IL_17D;
					}
					return (low != 0) ? "1" : "0";
				}
				return BitConverter.ToSingle(BitConverter.GetBytes(McProtocolCommunicationClient.ToInt32(payload)), 0).ToString(CultureInfo.InvariantCulture);
			}
			if (num != 268302705U)
			{
				if (num != 843930396U)
				{
					if (num != 2214109151U)
					{
						goto IL_17D;
					}
					if (!(text2 == "INT32"))
					{
						goto IL_17D;
					}
				}
				else if (!(text2 == "DINT"))
				{
					goto IL_17D;
				}
				return McProtocolCommunicationClient.ToInt32(payload).ToString(CultureInfo.InvariantCulture);
			}
			if (text2 == "INT16")
			{
				return ((short)low).ToString(CultureInfo.InvariantCulture);
			}
			IL_17D:
			return low.ToString(CultureInfo.InvariantCulture);
		}

		// Token: 0x06001F00 RID: 7936 RVA: 0x000B3460 File Offset: 0x000B1660
		private static int ToInt32(byte[] payload)
		{
			ushort low = (ushort)((int)payload[0] | (int)payload[1] << 8);
			ushort high = (ushort)((int)payload[2] | (int)payload[3] << 8);
			return (int)high << 16 | (int)low;
		}

		// Token: 0x06001F01 RID: 7937 RVA: 0x000B3490 File Offset: 0x000B1690
		private static bool TryEncodeWords(string dataType, string value, bool isBool, out ushort[] words, out string error)
		{
			words = null;
			error = null;
			string text = (value ?? string.Empty).Trim();
			bool result;
			try
			{
				string text2 = (dataType ?? string.Empty).Trim().ToUpperInvariant();
				string text3 = text2;
				uint num = <PrivateImplementationDetails>.ComputeStringHash(text3);
				if (num > 2214109151U)
				{
					if (num <= 2316881829U)
					{
						if (num != 2286151596U)
						{
							if (num != 2316881829U)
							{
								goto IL_1BE;
							}
							if (!(text3 == "FLOAT"))
							{
								goto IL_1BE;
							}
						}
						else
						{
							if (!(text3 == "UINT32"))
							{
								goto IL_1BE;
							}
							return McProtocolCommunicationClient.TrySplit((int)uint.Parse(text, CultureInfo.InvariantCulture), out words);
						}
					}
					else if (num != 2991499325U)
					{
						if (num != 3560013981U)
						{
							goto IL_1BE;
						}
						if (!(text3 == "REAL"))
						{
							goto IL_1BE;
						}
					}
					else
					{
						if (!(text3 == "BOOL"))
						{
							goto IL_1BE;
						}
						words = new ushort[]
						{
							McProtocolCommunicationClient.ParseBoolean(text) ? 1 : 0
						};
						return true;
					}
					return McProtocolCommunicationClient.TrySplit(BitConverter.ToInt32(BitConverter.GetBytes(float.Parse(text, CultureInfo.InvariantCulture)), 0), out words);
				}
				if (num != 268302705U)
				{
					if (num != 843930396U)
					{
						if (num != 2214109151U)
						{
							goto IL_1BE;
						}
						if (!(text3 == "INT32"))
						{
							goto IL_1BE;
						}
					}
					else if (!(text3 == "DINT"))
					{
						goto IL_1BE;
					}
					return McProtocolCommunicationClient.TrySplit(int.Parse(text, CultureInfo.InvariantCulture), out words);
				}
				if (text3 == "INT16")
				{
					words = new ushort[]
					{
						(ushort)short.Parse(text, CultureInfo.InvariantCulture)
					};
					return true;
				}
				IL_1BE:
				words = new ushort[]
				{
					ushort.Parse(text, CultureInfo.InvariantCulture)
				};
				result = true;
			}
			catch (Exception ex)
			{
				error = string.Concat(new string[]
				{
					"'",
					text,
					"' is not a valid ",
					dataType,
					" value: ",
					ex.Message
				});
				result = false;
			}
			return result;
		}

		// Token: 0x06001F02 RID: 7938 RVA: 0x000B36D4 File Offset: 0x000B18D4
		private static bool TrySplit(int value, out ushort[] words)
		{
			words = new ushort[]
			{
				(ushort)(value & 65535),
				(ushort)(value >> 16 & 65535)
			};
			return true;
		}

		// Token: 0x06001F03 RID: 7939 RVA: 0x000B3708 File Offset: 0x000B1908
		private static bool ParseBoolean(string value)
		{
			string text = (value ?? string.Empty).Trim();
			bool flag = string.Equals(text, "true", StringComparison.OrdinalIgnoreCase);
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = string.Equals(text, "false", StringComparison.OrdinalIgnoreCase);
				int number;
				result = (!flag2 && int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out number) && number != 0);
			}
			return result;
		}

		// Token: 0x04000CEC RID: 3308
		private readonly object _frameLock = new object();
	}
}
