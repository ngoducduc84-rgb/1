﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000202 RID: 514
	internal static class McProtocolFrame
	{
		// Token: 0x06001E35 RID: 7733 RVA: 0x000AE2C8 File Offset: 0x000AC4C8
		public static bool TryParseDevice(string address, out McDevice device, out string error)
		{
			device = null;
			error = null;
			bool flag = string.IsNullOrWhiteSpace(address);
			bool result;
			if (flag)
			{
				error = "MC Protocol needs a device address such as D100.";
				result = false;
			}
			else
			{
				Match match = McProtocolFrame.DevicePattern.Match(address);
				bool flag2 = !match.Success;
				if (flag2)
				{
					error = "'" + address.Trim() + "' is not a Mitsubishi device. Use a letter prefix and a number, such as D100, M0 or X1A.";
					result = false;
				}
				else
				{
					string prefix = match.Groups["prefix"].Value.ToUpperInvariant();
					string number = match.Groups["number"].Value;
					McProtocolFrame.DeviceInfo info;
					bool flag3 = !McProtocolFrame.Devices.TryGetValue(prefix, out info);
					if (flag3)
					{
						error = "Device '" + prefix + "' is not supported by MC Protocol here. Supported: D, R, ZR, W, SD, SW, TN, CN, M, SM, L, F, V, S, X, Y, B, SB, TS, TC, CS, CC.";
						result = false;
					}
					else
					{
						int parsed;
						bool flag4 = !int.TryParse(number, info.IsHex ? NumberStyles.HexNumber : NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed);
						if (flag4)
						{
							error = string.Concat(new string[]
							{
								"'",
								address.Trim(),
								"' has a number this device cannot use (",
								prefix,
								" is ",
								info.IsHex ? "hexadecimal" : "decimal",
								")."
							});
							result = false;
						}
						else
						{
							device = new McDevice
							{
								Prefix = prefix,
								Code = info.Code,
								Number = parsed,
								IsBitDevice = info.IsBit
							};
							result = true;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001E36 RID: 7734 RVA: 0x000AE44C File Offset: 0x000AC64C
		public static byte[] BuildWordReadRequest(McDevice device, int wordCount, int timeoutMs)
		{
			return McProtocolFrame.BuildRequest(1025, 0, device, wordCount, null, timeoutMs);
		}

		// Token: 0x06001E37 RID: 7735 RVA: 0x000AE470 File Offset: 0x000AC670
		public static byte[] BuildBitReadRequest(McDevice device, int bitCount, int timeoutMs)
		{
			return McProtocolFrame.BuildRequest(1025, 1, device, bitCount, null, timeoutMs);
		}

		// Token: 0x06001E38 RID: 7736 RVA: 0x000AE494 File Offset: 0x000AC694
		public static byte[] BuildWordWriteRequest(McDevice device, ushort[] words, int timeoutMs)
		{
			byte[] payload = new byte[words.Length * 2];
			for (int i = 0; i < words.Length; i++)
			{
				payload[i * 2] = (byte)(words[i] & 255);
				payload[i * 2 + 1] = (byte)(words[i] >> 8);
			}
			return McProtocolFrame.BuildRequest(5121, 0, device, words.Length, payload, timeoutMs);
		}

		// Token: 0x06001E39 RID: 7737 RVA: 0x000AE4F4 File Offset: 0x000AC6F4
		public static byte[] BuildBitWriteRequest(McDevice device, bool value, int timeoutMs)
		{
			byte[] payload = new byte[]
			{
				value ? 16 : 0
			};
			return McProtocolFrame.BuildRequest(5121, 1, device, 1, payload, timeoutMs);
		}

		// Token: 0x06001E3A RID: 7738 RVA: 0x000AE528 File Offset: 0x000AC728
		private static byte[] BuildRequest(ushort command, ushort subCommand, McDevice device, int points, byte[] payload, int timeoutMs)
		{
			List<byte> body = new List<byte>();
			int timerUnits = Math.Max(1, Math.Min(65535, timeoutMs / 250));
			McProtocolFrame.AddUInt16(body, (ushort)timerUnits);
			McProtocolFrame.AddUInt16(body, command);
			McProtocolFrame.AddUInt16(body, subCommand);
			body.Add((byte)(device.Number & 255));
			body.Add((byte)(device.Number >> 8 & 255));
			body.Add((byte)(device.Number >> 16 & 255));
			body.Add(device.Code);
			McProtocolFrame.AddUInt16(body, (ushort)points);
			bool flag = payload != null;
			if (flag)
			{
				body.AddRange(payload);
			}
			List<byte> frame = new List<byte>();
			McProtocolFrame.AddUInt16(frame, 80);
			frame.Add(0);
			frame.Add(byte.MaxValue);
			McProtocolFrame.AddUInt16(frame, 1023);
			frame.Add(0);
			McProtocolFrame.AddUInt16(frame, (ushort)body.Count);
			frame.AddRange(body);
			return frame.ToArray();
		}

		// Token: 0x06001E3B RID: 7739 RVA: 0x000AE630 File Offset: 0x000AC830
		public static bool TryReadResponse(byte[] header, byte[] data, out byte[] payload, out string error)
		{
			payload = null;
			error = null;
			bool flag = header == null || header.Length < 11;
			bool result;
			if (flag)
			{
				error = "MC Protocol response is too short.";
				result = false;
			}
			else
			{
				ushort subHeader = (ushort)((int)header[0] | (int)header[1] << 8);
				bool flag2 = subHeader != 208;
				if (flag2)
				{
					error = "MC Protocol response has an unexpected subheader 0x" + subHeader.ToString("X4", CultureInfo.InvariantCulture) + ".";
					result = false;
				}
				else
				{
					ushort endCode = (ushort)((int)header[9] | (int)header[10] << 8);
					bool flag3 = endCode > 0;
					if (flag3)
					{
						error = "PLC returned MC Protocol error 0x" + endCode.ToString("X4", CultureInfo.InvariantCulture) + ". " + McProtocolFrame.DescribeEndCode(endCode);
						result = false;
					}
					else
					{
						payload = (data ?? Array.Empty<byte>());
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x06001E3C RID: 7740 RVA: 0x000AE6FC File Offset: 0x000AC8FC
		public static int GetResponseDataLength(byte[] header)
		{
			bool flag = header == null || header.Length < 11;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				int length = (int)header[7] | (int)header[8] << 8;
				result = Math.Max(0, length - 2);
			}
			return result;
		}

		// Token: 0x06001E3D RID: 7741 RVA: 0x000AE738 File Offset: 0x000AC938
		private static string DescribeEndCode(ushort endCode)
		{
			string result;
			if (endCode != 85)
			{
				if (endCode != 16433)
				{
					switch (endCode)
					{
					case 49233:
					case 49234:
					case 49235:
					case 49236:
						return "Too many points in one request.";
					case 49238:
						return "The device number plus the point count runs past the end of that device.";
					case 49241:
						return "The command or subcommand is not allowed on this CPU.";
					case 49244:
						return "The request cannot be handled in this device's units.";
					case 49248:
						return "The device specification is wrong for this CPU.";
					case 49249:
						return "The request data length does not match the frame.";
					}
					result = "See the MELSEC Communication Protocol manual for this code.";
				}
				else
				{
					result = "The device number is outside the range configured in the PLC.";
				}
			}
			else
			{
				result = "The PLC is in RUN and write during RUN is disabled in its Ethernet parameters.";
			}
			return result;
		}

		// Token: 0x06001E3E RID: 7742 RVA: 0x000AE7FC File Offset: 0x000AC9FC
		private static void AddUInt16(List<byte> target, ushort value)
		{
			target.Add((byte)(value & 255));
			target.Add((byte)(value >> 8));
		}

		// Token: 0x04000CBA RID: 3258
		private const ushort RequestSubHeader = 80;

		// Token: 0x04000CBB RID: 3259
		private const ushort ResponseSubHeader = 208;

		// Token: 0x04000CBC RID: 3260
		private const byte DefaultNetworkNumber = 0;

		// Token: 0x04000CBD RID: 3261
		private const byte DefaultPlcNumber = 255;

		// Token: 0x04000CBE RID: 3262
		private const ushort DefaultModuleIoNumber = 1023;

		// Token: 0x04000CBF RID: 3263
		private const byte DefaultModuleStationNumber = 0;

		// Token: 0x04000CC0 RID: 3264
		private const ushort CommandBatchRead = 1025;

		// Token: 0x04000CC1 RID: 3265
		private const ushort CommandBatchWrite = 5121;

		// Token: 0x04000CC2 RID: 3266
		private const ushort SubCommandWordUnits = 0;

		// Token: 0x04000CC3 RID: 3267
		private const ushort SubCommandBitUnits = 1;

		// Token: 0x04000CC4 RID: 3268
		public const int ResponseHeaderLength = 11;

		// Token: 0x04000CC5 RID: 3269
		private static readonly Regex DevicePattern = new Regex("^\\s*(?<prefix>[A-Za-z]{1,2})\\s*(?<number>[0-9A-Fa-f]+)\\s*$", RegexOptions.Compiled);

		// Token: 0x04000CC6 RID: 3270
		private static readonly Dictionary<string, McProtocolFrame.DeviceInfo> Devices = new Dictionary<string, McProtocolFrame.DeviceInfo>(StringComparer.OrdinalIgnoreCase)
		{
			{
				"D",
				new McProtocolFrame.DeviceInfo(168, false, false)
			},
			{
				"R",
				new McProtocolFrame.DeviceInfo(175, false, false)
			},
			{
				"ZR",
				new McProtocolFrame.DeviceInfo(176, false, true)
			},
			{
				"W",
				new McProtocolFrame.DeviceInfo(180, false, true)
			},
			{
				"SD",
				new McProtocolFrame.DeviceInfo(169, false, false)
			},
			{
				"SW",
				new McProtocolFrame.DeviceInfo(181, false, true)
			},
			{
				"TN",
				new McProtocolFrame.DeviceInfo(194, false, false)
			},
			{
				"CN",
				new McProtocolFrame.DeviceInfo(197, false, false)
			},
			{
				"M",
				new McProtocolFrame.DeviceInfo(144, true, false)
			},
			{
				"SM",
				new McProtocolFrame.DeviceInfo(145, true, false)
			},
			{
				"L",
				new McProtocolFrame.DeviceInfo(146, true, false)
			},
			{
				"F",
				new McProtocolFrame.DeviceInfo(147, true, false)
			},
			{
				"V",
				new McProtocolFrame.DeviceInfo(148, true, false)
			},
			{
				"S",
				new McProtocolFrame.DeviceInfo(152, true, false)
			},
			{
				"X",
				new McProtocolFrame.DeviceInfo(156, true, true)
			},
			{
				"Y",
				new McProtocolFrame.DeviceInfo(157, true, true)
			},
			{
				"B",
				new McProtocolFrame.DeviceInfo(160, true, true)
			},
			{
				"SB",
				new McProtocolFrame.DeviceInfo(161, true, true)
			},
			{
				"TS",
				new McProtocolFrame.DeviceInfo(193, true, false)
			},
			{
				"TC",
				new McProtocolFrame.DeviceInfo(192, true, false)
			},
			{
				"CS",
				new McProtocolFrame.DeviceInfo(196, true, false)
			},
			{
				"CC",
				new McProtocolFrame.DeviceInfo(195, true, false)
			}
		};

		// Token: 0x02000468 RID: 1128
		private struct DeviceInfo
		{
			// Token: 0x06002C2E RID: 11310 RVA: 0x000EACEA File Offset: 0x000E8EEA
			public DeviceInfo(byte code, bool isBit, bool isHex)
			{
				this.Code = code;
				this.IsBit = isBit;
				this.IsHex = isHex;
			}

			// Token: 0x040015CC RID: 5580
			public readonly byte Code;

			// Token: 0x040015CD RID: 5581
			public readonly bool IsBit;

			// Token: 0x040015CE RID: 5582
			public readonly bool IsHex;
		}
	}
}
