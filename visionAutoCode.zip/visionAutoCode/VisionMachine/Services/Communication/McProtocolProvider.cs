﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000215 RID: 533
	internal sealed class McProtocolProvider : CommunicationProtocolProviderBase
	{
		// Token: 0x06001EAB RID: 7851 RVA: 0x000B17E2 File Offset: 0x000AF9E2
		public McProtocolProvider() : base(new string[]
		{
			"MC Protocol"
		})
		{
		}

		// Token: 0x06001EAC RID: 7852 RVA: 0x000B17FA File Offset: 0x000AF9FA
		public override IPlcCommunicationClient CreateClient()
		{
			return new McProtocolCommunicationClient();
		}
	}
}
