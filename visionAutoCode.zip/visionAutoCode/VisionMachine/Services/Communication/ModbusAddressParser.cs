﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000228 RID: 552
	internal static class ModbusAddressParser
	{
		// Token: 0x06001F3E RID: 7998 RVA: 0x000B6628 File Offset: 0x000B4828
		public static ushort ToHoldingRegisterOffset(string addressText)
		{
			return ModbusAddressParser.ToRegisterOffset(addressText, 3);
		}

		// Token: 0x06001F3F RID: 7999 RVA: 0x000B6644 File Offset: 0x000B4844
		public static ushort ToRegisterOffset(string addressText, byte functionCode)
		{
			int address;
			bool flag = !int.TryParse(addressText, out address);
			if (flag)
			{
				throw new FormatException("Invalid Modbus address.");
			}
			bool flag2 = functionCode == 4 && address >= 30001;
			if (flag2)
			{
				address -= 30001;
			}
			else
			{
				bool flag3 = address >= 40001;
				if (flag3)
				{
					address -= 40001;
				}
				else
				{
					bool flag4 = address > 0;
					if (!flag4)
					{
						throw new FormatException("Invalid Modbus address.");
					}
					address--;
				}
			}
			bool flag5 = address > 65535;
			if (flag5)
			{
				throw new FormatException("Modbus address is out of range.");
			}
			return (ushort)address;
		}

		// Token: 0x06001F40 RID: 8000 RVA: 0x000B66E4 File Offset: 0x000B48E4
		public static int ToDisplayAddressBase(string addressText, ushort offset)
		{
			int address;
			bool flag = !int.TryParse(addressText, out address);
			int result;
			if (flag)
			{
				result = (int)(offset + 1);
			}
			else
			{
				result = ((address >= 30001 || address >= 40001) ? address : ((int)(offset + 1)));
			}
			return result;
		}
	}
}
