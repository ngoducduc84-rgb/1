﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000210 RID: 528
	internal sealed class ModbusClientTcpProtocolProvider : CommunicationProtocolProviderBase
	{
		// Token: 0x06001EA1 RID: 7841 RVA: 0x000B1746 File Offset: 0x000AF946
		public ModbusClientTcpProtocolProvider() : base(new string[]
		{
			"Modbus Client TCP/IP",
			"Modbus TCP"
		})
		{
		}

		// Token: 0x06001EA2 RID: 7842 RVA: 0x000B1766 File Offset: 0x000AF966
		public override IPlcCommunicationClient CreateClient()
		{
			return new ModbusTcpCommunicationClient();
		}
	}
}
