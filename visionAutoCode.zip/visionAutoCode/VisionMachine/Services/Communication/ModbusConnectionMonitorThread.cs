﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000209 RID: 521
	internal static class ModbusConnectionMonitorThread
	{
		// Token: 0x06001E6F RID: 7791 RVA: 0x000AFAF4 File Offset: 0x000ADCF4
		internal static void Run(string configPath, CancellationToken cancellationToken)
		{
			PlcCommunicationService communicationService = SharedCommunicationService.Instance;
			DateTime lastGeneralHealthCheckUtc = DateTime.MinValue;
			while (!cancellationToken.IsCancellationRequested)
			{
				try
				{
					DateTime now = DateTime.UtcNow;
					bool runGeneralHealthCheck = (now - lastGeneralHealthCheckUtc).TotalMilliseconds >= 500.0;
					bool flag = runGeneralHealthCheck;
					if (flag)
					{
						CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(configPath);
						IEnumerable<CommunicationConnection> connections = config.Connections;
						foreach (CommunicationConnection connection in (connections ?? Enumerable.Empty<CommunicationConnection>()).Where(new Func<CommunicationConnection, bool>(ModbusConnectionMonitorThread.IsMonitorCandidate)))
						{
							try
							{
								cancellationToken.ThrowIfCancellationRequested();
								CommunicationHeartbeatMonitorHelper.NormalizeConnection(connection);
								List<CommunicationTagRow> tags = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name);
								CommunicationTagRow heartbeatTag = CommunicationHeartbeatMonitorHelper.FindHeartbeatTag(tags);
								bool flag2 = !communicationService.IsConnected(connection);
								if (flag2)
								{
									CommunicationHeartbeatMonitorHelper.ClearHeartbeatState(configPath, connection.Name);
									ModbusConnectionMonitorThread.ReconnectAndValidateTransport(communicationService, connection, tags, null);
								}
								else
								{
									bool flag3 = heartbeatTag == null;
									if (flag3)
									{
										CommunicationTagRow probeTag = CommunicationHeartbeatMonitorHelper.FindModbusTransportProbeTag(tags, connection);
										CommunicationHeartbeatCheckResult probeResult = CommunicationHeartbeatMonitorHelper.CheckModbusTransportProbe(communicationService, connection, probeTag);
										bool flag4 = !probeResult.Success;
										if (flag4)
										{
											CommunicationStartupService.ReportConnectionHealth(connection, false, probeResult.Message, true, false, false, false);
											communicationService.Disconnect(connection);
											ModbusConnectionMonitorThread.ReconnectAndValidateTransport(communicationService, connection, tags, probeTag);
										}
										else
										{
											CommunicationStartupService.ReportConnectionHealth(connection, true, probeResult.Message, false, false, false, false);
										}
									}
									else
									{
										CommunicationHeartbeatCheckResult heartbeatResult = CommunicationHeartbeatMonitorHelper.CheckHeartbeat(communicationService, connection, heartbeatTag, configPath, "Modbus");
										bool flag5 = !heartbeatResult.Success;
										if (flag5)
										{
											CommunicationStartupService.ReportConnectionHealth(connection, false, heartbeatResult.Message, true, false, heartbeatResult.HasHeartbeatValue, heartbeatResult.HeartbeatValue);
											communicationService.Disconnect(connection);
											ModbusConnectionMonitorThread.ReconnectAndValidateTransport(communicationService, connection, tags, null);
										}
										else
										{
											CommunicationStartupService.ReportConnectionHealth(connection, true, heartbeatResult.Message, false, heartbeatResult.IsHeartbeatPulse, heartbeatResult.HasHeartbeatValue, heartbeatResult.HeartbeatValue);
										}
									}
								}
							}
							catch (OperationCanceledException)
							{
								throw;
							}
							catch (Exception ex)
							{
								CommunicationConnection connection2 = connection;
								bool isConnected = false;
								string str = "Modbus monitor error: ";
								Exception baseException = ex.GetBaseException();
								CommunicationStartupService.ReportConnectionHealth(connection2, isConnected, str + (((baseException != null) ? baseException.Message : null) ?? ex.Message), true, false, false, false);
							}
						}
						lastGeneralHealthCheckUtc = now;
					}
				}
				catch (OperationCanceledException)
				{
					break;
				}
				catch
				{
				}
				try
				{
					Task.Delay(200, cancellationToken).Wait(cancellationToken);
				}
				catch (OperationCanceledException)
				{
					break;
				}
			}
		}

		// Token: 0x06001E70 RID: 7792 RVA: 0x000AFE14 File Offset: 0x000AE014
		private static bool IsMonitorCandidate(CommunicationConnection connection)
		{
			return CommunicationHeartbeatMonitorHelper.IsAutoReconnectCandidate(connection) && CommunicationHeartbeatMonitorHelper.IsModbusProtocol(connection.Protocol);
		}

		// Token: 0x06001E71 RID: 7793 RVA: 0x000AFE3C File Offset: 0x000AE03C
		private static void ReconnectAndValidateTransport(PlcCommunicationService communicationService, CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags, CommunicationTagRow probeTag)
		{
			CommunicationOperationResult reconnectResult = communicationService.ConnectIfDisconnected(CommunicationHeartbeatMonitorHelper.CreateModbusReconnectConnection(connection));
			bool flag = !reconnectResult.Success;
			if (flag)
			{
				CommunicationStartupService.ReportConnectionHealth(connection, false, reconnectResult.Message, true, false, false, false);
			}
			else
			{
				CommunicationTagRow validationTag = probeTag ?? CommunicationHeartbeatMonitorHelper.FindModbusTransportProbeTag(tags, connection);
				CommunicationHeartbeatCheckResult validationResult = CommunicationHeartbeatMonitorHelper.CheckModbusTransportProbe(communicationService, connection, validationTag);
				bool flag2 = !validationResult.Success;
				if (flag2)
				{
					communicationService.Disconnect(connection);
					CommunicationStartupService.ReportConnectionHealth(connection, false, "Modbus reconnect validation failed: " + validationResult.Message, true, false, false, false);
				}
				else
				{
					CommunicationStartupService.ReportConnectionHealth(connection, true, "Modbus reconnect validated. " + validationResult.Message, true, false, false, false);
				}
			}
		}
	}
}
