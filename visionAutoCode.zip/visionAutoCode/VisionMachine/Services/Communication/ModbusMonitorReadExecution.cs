﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000200 RID: 512
	public sealed class ModbusMonitorReadExecution
	{
		// Token: 0x17000938 RID: 2360
		// (get) Token: 0x06001E27 RID: 7719 RVA: 0x000AE261 File Offset: 0x000AC461
		// (set) Token: 0x06001E28 RID: 7720 RVA: 0x000AE269 File Offset: 0x000AC469
		public CommunicationOperationResult ConnectResult { get; set; }

		// Token: 0x17000939 RID: 2361
		// (get) Token: 0x06001E29 RID: 7721 RVA: 0x000AE272 File Offset: 0x000AC472
		// (set) Token: 0x06001E2A RID: 7722 RVA: 0x000AE27A File Offset: 0x000AC47A
		public CommunicationReadResult ReadResult { get; set; }
	}
}
