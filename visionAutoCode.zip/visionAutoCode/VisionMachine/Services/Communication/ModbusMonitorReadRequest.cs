﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001FF RID: 511
	public sealed class ModbusMonitorReadRequest
	{
		// Token: 0x17000934 RID: 2356
		// (get) Token: 0x06001E1E RID: 7710 RVA: 0x000AE21D File Offset: 0x000AC41D
		// (set) Token: 0x06001E1F RID: 7711 RVA: 0x000AE225 File Offset: 0x000AC425
		public string StartAddress { get; set; }

		// Token: 0x17000935 RID: 2357
		// (get) Token: 0x06001E20 RID: 7712 RVA: 0x000AE22E File Offset: 0x000AC42E
		// (set) Token: 0x06001E21 RID: 7713 RVA: 0x000AE236 File Offset: 0x000AC436
		public string EndAddress { get; set; }

		// Token: 0x17000936 RID: 2358
		// (get) Token: 0x06001E22 RID: 7714 RVA: 0x000AE23F File Offset: 0x000AC43F
		// (set) Token: 0x06001E23 RID: 7715 RVA: 0x000AE247 File Offset: 0x000AC447
		public string DataType { get; set; }

		// Token: 0x17000937 RID: 2359
		// (get) Token: 0x06001E24 RID: 7716 RVA: 0x000AE250 File Offset: 0x000AC450
		// (set) Token: 0x06001E25 RID: 7717 RVA: 0x000AE258 File Offset: 0x000AC458
		public string FunctionCode { get; set; }
	}
}
