﻿using System;
using System.Collections.Generic;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001FE RID: 510
	public sealed class ModbusMonitorService
	{
		// Token: 0x06001E1A RID: 7706 RVA: 0x000ADF39 File Offset: 0x000AC139
		public ModbusMonitorService(PlcCommunicationService communicationService)
		{
			this._communicationService = (communicationService ?? SharedCommunicationService.Instance);
		}

		// Token: 0x06001E1B RID: 7707 RVA: 0x000ADF64 File Offset: 0x000AC164
		public ModbusMonitorReadExecution ReadRangeWithReconnect(CommunicationConnection connection, ModbusMonitorReadRequest request, int reconnectBackoffMs, int reconnectTimeoutMs)
		{
			bool flag = connection == null;
			ModbusMonitorReadExecution result;
			if (flag)
			{
				result = new ModbusMonitorReadExecution
				{
					ReadResult = CommunicationReadResult.Fail("No connection selected.")
				};
			}
			else
			{
				bool flag2 = request == null;
				if (flag2)
				{
					result = new ModbusMonitorReadExecution
					{
						ReadResult = CommunicationReadResult.Fail("No Modbus monitor request configured.")
					};
				}
				else
				{
					CommunicationReadResult readResult = this._communicationService.ReadRange(connection, request.StartAddress, request.EndAddress, request.DataType, request.FunctionCode);
					CommunicationOperationResult connectResult = null;
					bool flag3 = !readResult.Success && string.Equals(readResult.Message, "Connection is not connected.", StringComparison.OrdinalIgnoreCase);
					if (flag3)
					{
						string key = ModbusMonitorService.GetConnectionKey(connection);
						DateTime now = DateTime.UtcNow;
						DateTime nextReconnectUtc;
						bool flag4 = this._nextReconnectUtcByConnection.TryGetValue(key, out nextReconnectUtc) && now < nextReconnectUtc;
						if (flag4)
						{
							return new ModbusMonitorReadExecution
							{
								ConnectResult = null,
								ReadResult = CommunicationReadResult.Fail("Connection is disconnected. Waiting before reconnect retry.")
							};
						}
						this._nextReconnectUtcByConnection[key] = now.AddMilliseconds((double)Math.Max(0, reconnectBackoffMs));
						connectResult = this._communicationService.Connect(ModbusMonitorService.CloneConnectionWithTimeout(connection, reconnectTimeoutMs));
						readResult = (connectResult.Success ? this._communicationService.ReadRange(connection, request.StartAddress, request.EndAddress, request.DataType, request.FunctionCode) : CommunicationReadResult.Fail(connectResult.Message));
					}
					result = new ModbusMonitorReadExecution
					{
						ConnectResult = connectResult,
						ReadResult = readResult
					};
				}
			}
			return result;
		}

		// Token: 0x06001E1C RID: 7708 RVA: 0x000AE0E8 File Offset: 0x000AC2E8
		private static string GetConnectionKey(CommunicationConnection connection)
		{
			return string.IsNullOrWhiteSpace((connection != null) ? connection.Name : null) ? "__default__" : connection.Name.Trim();
		}

		// Token: 0x06001E1D RID: 7709 RVA: 0x000AE120 File Offset: 0x000AC320
		private static CommunicationConnection CloneConnectionWithTimeout(CommunicationConnection source, int timeoutMs)
		{
			bool flag = source == null;
			CommunicationConnection result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new CommunicationConnection
				{
					Name = source.Name,
					Protocol = source.Protocol,
					Description = source.Description,
					IpAddress = source.IpAddress,
					Port = source.Port,
					TimeoutMs = ((timeoutMs > 0) ? timeoutMs : source.TimeoutMs),
					ExchangeInterval = source.ExchangeInterval,
					ByteOrder = source.ByteOrder,
					WordOrder = source.WordOrder,
					FloatFormat = source.FloatFormat,
					KeepAlive = source.KeepAlive,
					AutoReconnect = source.AutoReconnect,
					MonitorStartAddress = source.MonitorStartAddress,
					MonitorEndAddress = source.MonitorEndAddress,
					MonitorDataType = source.MonitorDataType,
					MonitorFunctionCode = source.MonitorFunctionCode
				};
			}
			return result;
		}

		// Token: 0x04000CAE RID: 3246
		private readonly PlcCommunicationService _communicationService;

		// Token: 0x04000CAF RID: 3247
		private readonly Dictionary<string, DateTime> _nextReconnectUtcByConnection = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
	}
}
