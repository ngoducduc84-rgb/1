﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000221 RID: 545
	internal class ModbusRtuCommunicationClient : IPlcCommunicationClient, IDisposable
	{
		// Token: 0x1700094D RID: 2381
		// (get) Token: 0x06001EE2 RID: 7906 RVA: 0x000B255F File Offset: 0x000B075F
		public bool IsConnectionAlive
		{
			get
			{
				return this._serialPort != null && this._serialPort.IsOpen;
			}
		}

		// Token: 0x06001EE3 RID: 7907 RVA: 0x000B2578 File Offset: 0x000B0778
		public CommunicationOperationResult Connect(CommunicationConnection connection)
		{
			CommunicationOperationResult result;
			try
			{
				this._serialPort = new SerialPort(connection.IpAddress, connection.Port, Parity.None, 8, StopBits.One)
				{
					ReadTimeout = connection.TimeoutMs,
					WriteTimeout = connection.TimeoutMs
				};
				this._serialPort.Open();
				result = CommunicationOperationResult.Ok("Serial port opened.", 0, 0);
			}
			catch (Exception ex)
			{
				this.Dispose();
				result = CommunicationOperationResult.Fail(ex.Message, 0, 0);
			}
			return result;
		}

		// Token: 0x06001EE4 RID: 7908 RVA: 0x000B2600 File Offset: 0x000B0800
		public CommunicationOperationResult Test(CommunicationConnection connection)
		{
			return (this._serialPort != null && this._serialPort.IsOpen) ? CommunicationOperationResult.Ok("Serial port is open.", 0, 0) : CommunicationOperationResult.Fail("Serial port is not open.", 0, 0);
		}

		// Token: 0x06001EE5 RID: 7909 RVA: 0x000B2644 File Offset: 0x000B0844
		public CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			List<CommunicationMonitorRow> rows = new List<CommunicationMonitorRow>();
			int sent = 0;
			int received = 0;
			string timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
			foreach (CommunicationTagRow tag in tags)
			{
				try
				{
					ushort registerAddress = ModbusAddressParser.ToHoldingRegisterOffset(tag.Address);
					byte[] request = ModbusRtuCommunicationClient.BuildRtuRequest(1, 3, registerAddress, 1);
					byte[] response = this.Transceive(request, 7);
					sent += request.Length;
					received += response.Length;
					ushort rawValue = (ushort)((int)response[3] << 8 | (int)response[4]);
					rows.Add(new CommunicationMonitorRow(tag.Address, tag.DataType, CommunicationValueConverter.ConvertRegisterValue(rawValue, tag.DataType), "Good", timestamp, tag.Description));
				}
				catch (Exception ex)
				{
					rows.Add(new CommunicationMonitorRow(tag.Address, tag.DataType, ex.Message, "Bad", timestamp, tag.Description));
				}
			}
			return CommunicationReadResult.From(true, "Read all completed.", rows, sent, received);
		}

		// Token: 0x06001EE6 RID: 7910 RVA: 0x000B2784 File Offset: 0x000B0984
		public CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			CommunicationOperationResult result;
			try
			{
				ushort registerAddress = ModbusAddressParser.ToHoldingRegisterOffset(address);
				ushort registerValue = CommunicationValueConverter.ConvertValueToRegisters(value, dataType)[0];
				byte[] request = ModbusRtuCommunicationClient.BuildRtuRequest(1, 6, registerAddress, registerValue);
				byte[] response = this.Transceive(request, 8);
				result = CommunicationOperationResult.Ok("Write single register completed.", request.Length, response.Length);
			}
			catch (Exception ex)
			{
				result = CommunicationOperationResult.Fail(ex.Message, 0, 0);
			}
			return result;
		}

		// Token: 0x06001EE7 RID: 7911 RVA: 0x000B27F4 File Offset: 0x000B09F4
		private byte[] Transceive(byte[] request, int expectedLength)
		{
			bool flag = this._serialPort == null || !this._serialPort.IsOpen;
			if (flag)
			{
				throw new InvalidOperationException("Serial port is not open.");
			}
			this._serialPort.DiscardInBuffer();
			this._serialPort.Write(request, 0, request.Length);
			byte[] response = new byte[expectedLength];
			for (int offset = 0; offset < expectedLength; offset += this._serialPort.Read(response, offset, expectedLength - offset))
			{
			}
			return response;
		}

		// Token: 0x06001EE8 RID: 7912 RVA: 0x000B2878 File Offset: 0x000B0A78
		private static byte[] BuildRtuRequest(byte station, byte functionCode, ushort address, ushort value)
		{
			byte[] request = new byte[8];
			request[0] = station;
			request[1] = functionCode;
			request[2] = (byte)(address >> 8);
			request[3] = (byte)(address & 255);
			request[4] = (byte)(value >> 8);
			request[5] = (byte)(value & 255);
			ushort crc = ModbusRtuCommunicationClient.CalculateModbusCrc(request, 6);
			request[6] = (byte)(crc & 255);
			request[7] = (byte)(crc >> 8);
			return request;
		}

		// Token: 0x06001EE9 RID: 7913 RVA: 0x000B28D8 File Offset: 0x000B0AD8
		private static ushort CalculateModbusCrc(byte[] data, int length)
		{
			ushort crc = ushort.MaxValue;
			for (int i = 0; i < length; i++)
			{
				crc ^= (ushort)data[i];
				for (int bit = 0; bit < 8; bit++)
				{
					bool carry = (crc & 1) > 0;
					crc = (ushort)(crc >> 1);
					bool flag = carry;
					if (flag)
					{
						crc ^= 40961;
					}
				}
			}
			return crc;
		}

		// Token: 0x06001EEA RID: 7914 RVA: 0x000B2940 File Offset: 0x000B0B40
		public void Dispose()
		{
			try
			{
				SerialPort serialPort = this._serialPort;
				if (serialPort != null)
				{
					serialPort.Close();
				}
			}
			catch
			{
			}
			this._serialPort = null;
		}

		// Token: 0x04000CEA RID: 3306
		private SerialPort _serialPort;
	}
}
