﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000212 RID: 530
	internal sealed class ModbusRtuProtocolProvider : CommunicationProtocolProviderBase
	{
		// Token: 0x06001EA5 RID: 7845 RVA: 0x000B178C File Offset: 0x000AF98C
		public ModbusRtuProtocolProvider() : base(new string[]
		{
			"Modbus RTU"
		})
		{
		}

		// Token: 0x06001EA6 RID: 7846 RVA: 0x000B17A4 File Offset: 0x000AF9A4
		public override IPlcCommunicationClient CreateClient()
		{
			return new ModbusRtuCommunicationClient();
		}
	}
}
