﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000211 RID: 529
	internal sealed class ModbusServerTcpProtocolProvider : CommunicationProtocolProviderBase
	{
		// Token: 0x06001EA3 RID: 7843 RVA: 0x000B176D File Offset: 0x000AF96D
		public ModbusServerTcpProtocolProvider() : base(new string[]
		{
			"Modbus Server TCP/IP"
		})
		{
		}

		// Token: 0x06001EA4 RID: 7844 RVA: 0x000B1785 File Offset: 0x000AF985
		public override IPlcCommunicationClient CreateClient()
		{
			return new SocketServerCommunicationClient();
		}
	}
}
