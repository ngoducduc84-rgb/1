﻿using System;
using System.Collections.Generic;
using System.IO;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000220 RID: 544
	internal class ModbusTcpCommunicationClient : TcpCommunicationClientBase, IModbusRangeReader, IModbusRegisterArrayWriter
	{
		// Token: 0x06001ED4 RID: 7892 RVA: 0x000B1E94 File Offset: 0x000B0094
		public override CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			List<CommunicationMonitorRow> rows = new List<CommunicationMonitorRow>();
			int sent = 0;
			int received = 0;
			string timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
			foreach (CommunicationTagRow tag in tags)
			{
				try
				{
					ushort registerAddress = ModbusAddressParser.ToHoldingRegisterOffset(tag.Address);
					ushort quantity = (ushort)CommunicationValueConverter.GetRegisterStride(tag.DataType);
					byte[] request = this.BuildReadHoldingRegisterRequest(registerAddress, quantity);
					byte[] response = base.Transceive(request);
					sent += request.Length;
					received += response.Length;
					ushort[] registers = ModbusTcpCommunicationClient.ParseRegisters(response, quantity);
					rows.Add(new CommunicationMonitorRow(tag.Address, tag.DataType, CommunicationValueConverter.ConvertRegisterValues(registers, 0, tag.DataType), "Good", timestamp, tag.Description));
				}
				catch (Exception ex)
				{
					bool flag = PlcCommunicationService.IsRecoverableTransportFailure(ex.Message);
					if (flag)
					{
						return CommunicationReadResult.Fail(ex.Message);
					}
					rows.Add(new CommunicationMonitorRow(tag.Address, tag.DataType, ex.Message, "Bad", timestamp, tag.Description));
				}
			}
			return CommunicationReadResult.From(true, "Read all completed.", rows, sent, received);
		}

		// Token: 0x06001ED5 RID: 7893 RVA: 0x000B2000 File Offset: 0x000B0200
		public CommunicationReadResult ReadRange(string startAddressText, string endAddressText, string dataType, string functionCodeText)
		{
			CommunicationReadResult result;
			try
			{
				byte functionCode = ModbusTcpCommunicationClient.ParseReadFunctionCode(functionCodeText);
				ushort startAddress = ModbusAddressParser.ToRegisterOffset(startAddressText, functionCode);
				ushort endAddress = ModbusAddressParser.ToRegisterOffset(endAddressText, functionCode);
				bool flag = endAddress < startAddress;
				if (flag)
				{
					throw new FormatException("End address must be greater than or equal to start address.");
				}
				ushort quantity = checked(endAddress - startAddress + 1);
				bool flag2 = quantity <= 0 || quantity > 125;
				if (flag2)
				{
					throw new FormatException("Modbus register quantity must be between 1 and 125.");
				}
				int registerStride = CommunicationValueConverter.GetRegisterStride(dataType);
				bool flag3 = (int)quantity < registerStride;
				if (flag3)
				{
					throw new FormatException("Selected address range is too small for the selected data type.");
				}
				byte[] request = this.BuildReadRegisterRequest(functionCode, startAddress, quantity);
				byte[] response = base.Transceive(request);
				ushort[] registers = ModbusTcpCommunicationClient.ParseRegisters(response, quantity);
				List<CommunicationMonitorRow> rows = new List<CommunicationMonitorRow>();
				string timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
				int displayAddress = ModbusAddressParser.ToDisplayAddressBase(startAddressText, startAddress);
				int i = 0;
				while (i + registerStride <= registers.Length)
				{
					rows.Add(new CommunicationMonitorRow((displayAddress + i).ToString(), dataType, CommunicationValueConverter.ConvertRegisterValues(registers, i, dataType), "Good", timestamp, (functionCode == 4) ? "Input register" : "Holding register"));
					i += registerStride;
				}
				result = CommunicationReadResult.From(true, string.Format("Read {0} value(s) completed.", rows.Count), rows, request.Length, response.Length);
			}
			catch (Exception ex)
			{
				result = CommunicationReadResult.Fail(ex.Message);
			}
			return result;
		}

		// Token: 0x06001ED6 RID: 7894 RVA: 0x000B217C File Offset: 0x000B037C
		public override CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			CommunicationOperationResult result;
			try
			{
				ushort registerAddress = ModbusAddressParser.ToHoldingRegisterOffset(address);
				ushort[] registerValues = CommunicationValueConverter.ConvertValueToRegisters(value, dataType);
				byte[] request = (registerValues.Length == 1) ? this.BuildWriteSingleRegisterRequest(registerAddress, registerValues[0]) : this.BuildWriteMultipleRegistersRequest(registerAddress, registerValues);
				byte[] response = base.Transceive(request);
				result = CommunicationOperationResult.Ok("Write register completed.", request.Length, response.Length);
			}
			catch (Exception ex)
			{
				result = CommunicationOperationResult.Fail(ex.Message, 0, 0);
			}
			return result;
		}

		// Token: 0x06001ED7 RID: 7895 RVA: 0x000B21FC File Offset: 0x000B03FC
		public CommunicationOperationResult WriteRegisters(string address, ushort[] values)
		{
			CommunicationOperationResult result;
			try
			{
				ushort registerAddress = ModbusAddressParser.ToHoldingRegisterOffset(address);
				byte[] request = this.BuildWriteMultipleRegistersRequest(registerAddress, values);
				byte[] response = base.Transceive(request);
				result = CommunicationOperationResult.Ok("Write register array completed.", request.Length, response.Length);
			}
			catch (Exception ex)
			{
				result = CommunicationOperationResult.Fail(ex.Message, 0, 0);
			}
			return result;
		}

		// Token: 0x06001ED8 RID: 7896 RVA: 0x000B225C File Offset: 0x000B045C
		private byte[] BuildReadHoldingRegisterRequest(ushort startAddress, ushort quantity)
		{
			return this.BuildModbusTcpRequest(3, startAddress, quantity);
		}

		// Token: 0x06001ED9 RID: 7897 RVA: 0x000B2278 File Offset: 0x000B0478
		private byte[] BuildReadRegisterRequest(byte functionCode, ushort startAddress, ushort quantity)
		{
			return this.BuildModbusTcpRequest(functionCode, startAddress, quantity);
		}

		// Token: 0x06001EDA RID: 7898 RVA: 0x000B2294 File Offset: 0x000B0494
		private byte[] BuildWriteSingleRegisterRequest(ushort startAddress, ushort value)
		{
			return this.BuildModbusTcpRequest(6, startAddress, value);
		}

		// Token: 0x06001EDB RID: 7899 RVA: 0x000B22B0 File Offset: 0x000B04B0
		private byte[] BuildWriteMultipleRegistersRequest(ushort startAddress, ushort[] values)
		{
			bool flag = values == null || values.Length == 0;
			if (flag)
			{
				throw new FormatException("No Modbus values to write.");
			}
			bool flag2 = values.Length > 123;
			if (flag2)
			{
				throw new FormatException("Modbus write quantity must be between 1 and 123.");
			}
			byte byteCount = checked((byte)(values.Length * 2));
			byte[] request = new byte[(int)(13 + byteCount)];
			byte[] buffer = request;
			int index = 0;
			ushort num = this._transactionId + 1;
			this._transactionId = num;
			ModbusTcpCommunicationClient.WriteUInt16(buffer, index, num);
			ModbusTcpCommunicationClient.WriteUInt16(request, 2, 0);
			ModbusTcpCommunicationClient.WriteUInt16(request, 4, (ushort)(7 + byteCount));
			request[6] = 1;
			request[7] = 16;
			ModbusTcpCommunicationClient.WriteUInt16(request, 8, startAddress);
			ModbusTcpCommunicationClient.WriteUInt16(request, 10, (ushort)values.Length);
			request[12] = byteCount;
			for (int i = 0; i < values.Length; i++)
			{
				ModbusTcpCommunicationClient.WriteUInt16(request, 13 + i * 2, values[i]);
			}
			return request;
		}

		// Token: 0x06001EDC RID: 7900 RVA: 0x000B2388 File Offset: 0x000B0588
		private byte[] BuildModbusTcpRequest(byte functionCode, ushort address, ushort value)
		{
			byte[] request = new byte[12];
			byte[] buffer = request;
			int index = 0;
			ushort num = this._transactionId + 1;
			this._transactionId = num;
			ModbusTcpCommunicationClient.WriteUInt16(buffer, index, num);
			ModbusTcpCommunicationClient.WriteUInt16(request, 2, 0);
			ModbusTcpCommunicationClient.WriteUInt16(request, 4, 6);
			request[6] = 1;
			request[7] = functionCode;
			ModbusTcpCommunicationClient.WriteUInt16(request, 8, address);
			ModbusTcpCommunicationClient.WriteUInt16(request, 10, value);
			return request;
		}

		// Token: 0x06001EDD RID: 7901 RVA: 0x000B23EC File Offset: 0x000B05EC
		private static ushort ParseSingleRegister(byte[] response)
		{
			bool flag = response == null || response.Length < 11;
			if (flag)
			{
				throw new IOException("Invalid Modbus response.");
			}
			bool flag2 = (response[7] & 128) > 0;
			if (flag2)
			{
				throw new IOException(string.Format("Modbus exception code {0}.", response[8]));
			}
			return (ushort)((int)response[9] << 8 | (int)response[10]);
		}

		// Token: 0x06001EDE RID: 7902 RVA: 0x000B2450 File Offset: 0x000B0650
		private static ushort[] ParseRegisters(byte[] response, ushort expectedQuantity)
		{
			bool flag = response == null || response.Length < 9;
			if (flag)
			{
				throw new IOException("Invalid Modbus response.");
			}
			bool flag2 = (response[7] & 128) > 0;
			if (flag2)
			{
				throw new IOException(string.Format("Modbus exception code {0}.", response[8]));
			}
			int expectedByteCount = (int)(expectedQuantity * 2);
			int byteCount = (int)response[8];
			bool flag3 = byteCount < expectedByteCount || response.Length < 9 + expectedByteCount;
			if (flag3)
			{
				throw new IOException("Invalid Modbus register payload.");
			}
			ushort[] registers = new ushort[(int)expectedQuantity];
			for (int i = 0; i < (int)expectedQuantity; i++)
			{
				int offset = 9 + i * 2;
				registers[i] = (ushort)((int)response[offset] << 8 | (int)response[offset + 1]);
			}
			return registers;
		}

		// Token: 0x06001EDF RID: 7903 RVA: 0x000B2510 File Offset: 0x000B0710
		private static byte ParseReadFunctionCode(string functionCodeText)
		{
			string value = functionCodeText ?? string.Empty;
			return value.StartsWith("04", StringComparison.OrdinalIgnoreCase) ? 4 : 3;
		}

		// Token: 0x06001EE0 RID: 7904 RVA: 0x000B253F File Offset: 0x000B073F
		private static void WriteUInt16(byte[] buffer, int index, ushort value)
		{
			buffer[index] = (byte)(value >> 8);
			buffer[index + 1] = (byte)(value & 255);
		}

		// Token: 0x04000CE9 RID: 3305
		private ushort _transactionId;
	}
}
