﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000225 RID: 549
	internal class MxComponentCommunicationClient : IPlcCommunicationClient, IDisposable
	{
		// Token: 0x1700094F RID: 2383
		// (get) Token: 0x06001F05 RID: 7941 RVA: 0x000B3780 File Offset: 0x000B1980
		public bool IsConnectionAlive
		{
			get
			{
				object sync = this._sync;
				bool result;
				lock (sync)
				{
					result = (this._session != null && this._worker != null && this._connectionAlive);
				}
				return result;
			}
		}

		// Token: 0x06001F06 RID: 7942 RVA: 0x000B37D8 File Offset: 0x000B19D8
		public CommunicationOperationResult Connect(CommunicationConnection connection)
		{
			object sync = this._sync;
			bool flag = false;
			CommunicationOperationResult result;
			try
			{
				Monitor.Enter(sync, ref flag);
				bool flag2 = !MxComponentRuntime.IsInstalled;
				if (flag2)
				{
					result = CommunicationOperationResult.Fail(MxComponentRuntime.DescribeInstallation(), 0, 0);
				}
				else
				{
					int station = (connection == null) ? 0 : connection.LogicalStationNumber;
					bool flag3 = this._session != null && this._logicalStationNumber == station && this._connectionAlive;
					if (flag3)
					{
						result = CommunicationOperationResult.Ok("MX Component already open.", 0, 0);
					}
					else
					{
						this.CloseCore();
						try
						{
							this._worker = new MxComponentStaWorker();
							int code = this._worker.Run<int>(delegate()
							{
								this._session = MxComponentRuntime.CreateSession();
								return this._session.Open(station);
							});
							bool flag4 = code != 0;
							if (flag4)
							{
								this.CloseCore();
								result = CommunicationOperationResult.Fail(string.Concat(new string[]
								{
									"MX Component could not open logical station ",
									station.ToString(),
									": ",
									MxComponentRuntime.DescribeStatus(code),
									". Check that station ",
									station.ToString(),
									" exists in MX Component's Communication Setup Utility and that its own test passes."
								}), 0, 0);
							}
							else
							{
								this._logicalStationNumber = station;
								this._connectionAlive = true;
								result = CommunicationOperationResult.Ok(string.Concat(new string[]
								{
									"MX Component connected on logical station ",
									station.ToString(),
									" via ",
									MxComponentRuntime.ResolvedProgId,
									"."
								}), 0, 0);
							}
						}
						catch (Exception ex)
						{
							this.CloseCore();
							result = CommunicationOperationResult.Fail("MX Component open failed: " + MxComponentRuntime.DescribeException(ex), 0, 0);
						}
					}
				}
			}
			finally
			{
				if (flag)
				{
					Monitor.Exit(sync);
				}
			}
			return result;
		}

		// Token: 0x06001F07 RID: 7943 RVA: 0x000B39CC File Offset: 0x000B1BCC
		public CommunicationOperationResult Test(CommunicationConnection connection)
		{
			object sync = this._sync;
			CommunicationOperationResult result;
			lock (sync)
			{
				bool flag2 = !MxComponentRuntime.IsInstalled;
				if (flag2)
				{
					result = CommunicationOperationResult.Fail(MxComponentRuntime.DescribeInstallation(), 0, 0);
				}
				else
				{
					bool flag3 = this._session == null || this._worker == null || !this._connectionAlive;
					if (flag3)
					{
						CommunicationOperationResult connectResult = this.Connect(connection);
						bool flag4 = !connectResult.Success;
						if (flag4)
						{
							return connectResult;
						}
					}
					try
					{
						string cpuName = this._worker.Run<string>(delegate()
						{
							string name;
							int status = this._session.GetCpuType(out name);
							bool flag5 = status != 0;
							if (flag5)
							{
								throw new InvalidOperationException(MxComponentRuntime.DescribeStatus(status));
							}
							return name;
						});
						this._connectionAlive = true;
						result = CommunicationOperationResult.Ok("MX Component OK on logical station " + this._logicalStationNumber.ToString() + (string.IsNullOrWhiteSpace(cpuName) ? "." : (" (CPU " + cpuName.Trim() + ").")), 0, 4);
					}
					catch (Exception ex)
					{
						this._connectionAlive = false;
						result = CommunicationOperationResult.Fail("MX Component probe failed: " + MxComponentRuntime.DescribeException(ex), 0, 0);
					}
				}
			}
			return result;
		}

		// Token: 0x06001F08 RID: 7944 RVA: 0x000B3B04 File Offset: 0x000B1D04
		public CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			object sync = this._sync;
			CommunicationReadResult result;
			lock (sync)
			{
				bool flag2 = !MxComponentRuntime.IsInstalled;
				if (flag2)
				{
					result = CommunicationReadResult.Fail(MxComponentRuntime.DescribeInstallation());
				}
				else
				{
					bool flag3 = this._session == null || this._worker == null || !this._connectionAlive;
					if (flag3)
					{
						result = CommunicationReadResult.Fail("MX Component is not connected.");
					}
					else
					{
						List<CommunicationMonitorRow> rows = new List<CommunicationMonitorRow>();
						int readBytes = 0;
						string firstError = null;
						foreach (CommunicationTagRow tag in (tags ?? Enumerable.Empty<CommunicationTagRow>()))
						{
							bool flag4 = tag == null || string.IsNullOrWhiteSpace(tag.Address);
							if (!flag4)
							{
								string value;
								string error;
								bool flag5 = this.TryReadDevice(tag.Address.Trim(), tag.DataType, out value, out error);
								string quality;
								if (flag5)
								{
									quality = "Good";
									readBytes += 4;
								}
								else
								{
									value = "--";
									quality = "Bad";
									bool flag6 = firstError == null;
									if (flag6)
									{
										firstError = error;
									}
								}
								rows.Add(new CommunicationMonitorRow(tag.Name, tag.Group, tag.ReadWrite, tag.Address, tag.DataType, value, quality, DateTime.Now.ToString("HH:mm:ss.fff"), tag.Description));
							}
						}
						bool success = firstError == null;
						result = CommunicationReadResult.From(success, success ? ("Read " + rows.Count.ToString() + " tag(s) from MX Component.") : firstError, rows, 0, readBytes);
					}
				}
			}
			return result;
		}

		// Token: 0x06001F09 RID: 7945 RVA: 0x000B3CF8 File Offset: 0x000B1EF8
		public CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			object sync = this._sync;
			CommunicationOperationResult result;
			lock (sync)
			{
				bool flag2 = !MxComponentRuntime.IsInstalled;
				if (flag2)
				{
					result = CommunicationOperationResult.Fail(MxComponentRuntime.DescribeInstallation(), 0, 0);
				}
				else
				{
					bool flag3 = this._session == null || this._worker == null || !this._connectionAlive;
					if (flag3)
					{
						result = CommunicationOperationResult.Fail("MX Component is not connected.", 0, 0);
					}
					else
					{
						bool flag4 = string.IsNullOrWhiteSpace(address);
						if (flag4)
						{
							result = CommunicationOperationResult.Fail("MX Component write needs a device address.", 0, 0);
						}
						else
						{
							try
							{
								string device = address.Trim();
								bool flag5 = MxComponentCommunicationClient.IsDoubleWord(dataType);
								if (flag5)
								{
									int longValue = MxComponentCommunicationClient.ParseInt32(value, dataType);
									int code = this._worker.Run<int>(delegate()
									{
										int status = this._session.SetDevice(device, longValue & 65535);
										bool flag8 = status != 0;
										int result2;
										if (flag8)
										{
											result2 = status;
										}
										else
										{
											result2 = this._session.SetDevice(MxComponentCommunicationClient.NextDevice(device), longValue >> 16 & 65535);
										}
										return result2;
									});
									bool flag6 = code != 0;
									if (flag6)
									{
										result = CommunicationOperationResult.Fail("MX Component write to " + device + " failed: " + MxComponentRuntime.DescribeStatus(code), 0, 0);
									}
									else
									{
										result = CommunicationOperationResult.Ok(string.Concat(new string[]
										{
											"Wrote ",
											longValue.ToString(),
											" to ",
											device,
											"."
										}), 4, 0);
									}
								}
								else
								{
									int wordValue = MxComponentCommunicationClient.ParseInt32(value, dataType);
									int single = this._worker.Run<int>(() => this._session.SetDevice(device, wordValue));
									bool flag7 = single != 0;
									if (flag7)
									{
										result = CommunicationOperationResult.Fail("MX Component write to " + device + " failed: " + MxComponentRuntime.DescribeStatus(single), 0, 0);
									}
									else
									{
										result = CommunicationOperationResult.Ok(string.Concat(new string[]
										{
											"Wrote ",
											wordValue.ToString(),
											" to ",
											device,
											"."
										}), 2, 0);
									}
								}
							}
							catch (Exception ex)
							{
								result = CommunicationOperationResult.Fail("MX Component write failed: " + MxComponentRuntime.DescribeException(ex), 0, 0);
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001F0A RID: 7946 RVA: 0x000B3F7C File Offset: 0x000B217C
		private bool TryReadDevice(string device, string dataType, out string value, out string error)
		{
			value = null;
			error = null;
			bool result;
			try
			{
				bool flag = MxComponentCommunicationClient.IsDoubleWord(dataType);
				if (flag)
				{
					int low;
					int high;
					bool flag2 = !this.TryGetDevice(device, out low, out error) || !this.TryGetDevice(MxComponentCommunicationClient.NextDevice(device), out high, out error);
					if (flag2)
					{
						result = false;
					}
					else
					{
						int combined = (int)((ushort)high) << 16 | (int)((ushort)low);
						value = MxComponentCommunicationClient.FormatValue(combined, dataType);
						result = true;
					}
				}
				else
				{
					int wordValue;
					bool flag3 = !this.TryGetDevice(device, out wordValue, out error);
					if (flag3)
					{
						result = false;
					}
					else
					{
						value = MxComponentCommunicationClient.FormatValue(wordValue, dataType);
						result = true;
					}
				}
			}
			catch (Exception ex)
			{
				error = "MX Component read of " + device + " failed: " + MxComponentRuntime.DescribeException(ex);
				result = false;
			}
			return result;
		}

		// Token: 0x06001F0B RID: 7947 RVA: 0x000B4040 File Offset: 0x000B2240
		private bool TryGetDevice(string device, out int value, out string error)
		{
			error = null;
			int read = 0;
			int status = this._worker.Run<int>(delegate()
			{
				int deviceValue;
				int code = this._session.GetDevice(device, out deviceValue);
				read = deviceValue;
				return code;
			});
			value = read;
			bool flag = status != 0;
			bool result;
			if (flag)
			{
				error = "MX Component read of " + device + " failed: " + MxComponentRuntime.DescribeStatus(status);
				result = false;
			}
			else
			{
				result = true;
			}
			return result;
		}

		// Token: 0x06001F0C RID: 7948 RVA: 0x000B40BC File Offset: 0x000B22BC
		private static string NextDevice(string device)
		{
			bool flag = string.IsNullOrWhiteSpace(device);
			string result;
			if (flag)
			{
				result = device;
			}
			else
			{
				string trimmed = device.Trim();
				int digitStart = trimmed.Length;
				while (digitStart > 0 && char.IsDigit(trimmed[digitStart - 1]))
				{
					digitStart--;
				}
				bool flag2 = digitStart == trimmed.Length;
				if (flag2)
				{
					result = trimmed;
				}
				else
				{
					string prefix = trimmed.Substring(0, digitStart);
					string digits = trimmed.Substring(digitStart);
					bool hex = prefix.Length > 0 && "XYWB".IndexOf(char.ToUpperInvariant(prefix[0])) >= 0;
					try
					{
						long number = hex ? Convert.ToInt64(digits, 16) : long.Parse(digits, CultureInfo.InvariantCulture);
						string next = hex ? (number + 1L).ToString("X") : (number + 1L).ToString(CultureInfo.InvariantCulture);
						result = prefix + next.PadLeft(digits.Length, '0');
					}
					catch
					{
						result = trimmed;
					}
				}
			}
			return result;
		}

		// Token: 0x06001F0D RID: 7949 RVA: 0x000B41DC File Offset: 0x000B23DC
		private static bool IsDoubleWord(string dataType)
		{
			string type = (dataType ?? string.Empty).Trim().ToUpperInvariant();
			return type == "INT32" || type == "UINT32" || type == "DINT" || type == "FLOAT" || type == "REAL";
		}

		// Token: 0x06001F0E RID: 7950 RVA: 0x000B4248 File Offset: 0x000B2448
		private static int ParseInt32(string value, string dataType)
		{
			string text = (value ?? string.Empty).Trim();
			string type = (dataType ?? string.Empty).Trim().ToUpperInvariant();
			bool flag2 = type == "BOOL";
			int result;
			if (flag2)
			{
				bool flag;
				bool flag3 = bool.TryParse(text, out flag);
				if (flag3)
				{
					result = (flag ? 1 : 0);
				}
				else
				{
					result = (string.Equals(text, "1", StringComparison.Ordinal) ? 1 : 0);
				}
			}
			else
			{
				bool flag4 = type == "FLOAT" || type == "REAL";
				if (flag4)
				{
					float number;
					float.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out number);
					result = BitConverter.ToInt32(BitConverter.GetBytes(number), 0);
				}
				else
				{
					int parsed;
					int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed);
					result = parsed;
				}
			}
			return result;
		}

		// Token: 0x06001F0F RID: 7951 RVA: 0x000B4318 File Offset: 0x000B2518
		private static string FormatValue(int raw, string dataType)
		{
			string type = (dataType ?? string.Empty).Trim().ToUpperInvariant();
			string text = type;
			string a = text;
			string result;
			if (!(a == "BOOL"))
			{
				if (!(a == "FLOAT") && !(a == "REAL"))
				{
					if (!(a == "UINT16"))
					{
						if (!(a == "UINT32"))
						{
							if (!(a == "INT16"))
							{
								result = raw.ToString(CultureInfo.InvariantCulture);
							}
							else
							{
								result = ((short)raw).ToString(CultureInfo.InvariantCulture);
							}
						}
						else
						{
							uint num = (uint)raw;
							result = num.ToString(CultureInfo.InvariantCulture);
						}
					}
					else
					{
						result = ((ushort)raw).ToString(CultureInfo.InvariantCulture);
					}
				}
				else
				{
					result = BitConverter.ToSingle(BitConverter.GetBytes(raw), 0).ToString("0.####", CultureInfo.InvariantCulture);
				}
			}
			else
			{
				result = ((raw != 0) ? "True" : "False");
			}
			return result;
		}

		// Token: 0x06001F10 RID: 7952 RVA: 0x000B440C File Offset: 0x000B260C
		private void CloseCore()
		{
			try
			{
				bool flag = this._worker != null && this._session != null;
				if (flag)
				{
					this._worker.Run(delegate()
					{
						this._session.Dispose();
					});
				}
			}
			catch
			{
			}
			try
			{
				MxComponentStaWorker worker = this._worker;
				if (worker != null)
				{
					worker.Dispose();
				}
			}
			catch
			{
			}
			this._worker = null;
			this._session = null;
			this._logicalStationNumber = -1;
			this._connectionAlive = false;
		}

		// Token: 0x06001F11 RID: 7953 RVA: 0x000B44A8 File Offset: 0x000B26A8
		public void Dispose()
		{
			object sync = this._sync;
			lock (sync)
			{
				this.CloseCore();
			}
		}

		// Token: 0x04000CED RID: 3309
		private readonly object _sync = new object();

		// Token: 0x04000CEE RID: 3310
		private MxComponentStaWorker _worker;

		// Token: 0x04000CEF RID: 3311
		private IMxComponentSession _session;

		// Token: 0x04000CF0 RID: 3312
		private int _logicalStationNumber = -1;

		// Token: 0x04000CF1 RID: 3313
		private bool _connectionAlive;
	}
}
