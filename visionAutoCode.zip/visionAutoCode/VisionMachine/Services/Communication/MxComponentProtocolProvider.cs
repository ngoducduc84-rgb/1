﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000216 RID: 534
	internal sealed class MxComponentProtocolProvider : CommunicationProtocolProviderBase
	{
		// Token: 0x06001EAD RID: 7853 RVA: 0x000B1801 File Offset: 0x000AFA01
		public MxComponentProtocolProvider() : base(new string[]
		{
			"MX Component"
		})
		{
		}

		// Token: 0x06001EAE RID: 7854 RVA: 0x000B1819 File Offset: 0x000AFA19
		public override IPlcCommunicationClient CreateClient()
		{
			return new MxComponentCommunicationClient();
		}
	}
}
