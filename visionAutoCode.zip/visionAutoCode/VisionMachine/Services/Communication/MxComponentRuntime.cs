﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000203 RID: 515
	public static class MxComponentRuntime
	{
		// Token: 0x1700093E RID: 2366
		// (get) Token: 0x06001E40 RID: 7744 RVA: 0x000AEA58 File Offset: 0x000ACC58
		public static bool IsInstalled
		{
			get
			{
				MxComponentRuntime.Probe();
				object sync = MxComponentRuntime.Sync;
				bool result;
				lock (sync)
				{
					result = (MxComponentRuntime._interopCoClass != null || MxComponentRuntime._dispatchControlType != null);
				}
				return result;
			}
		}

		// Token: 0x1700093F RID: 2367
		// (get) Token: 0x06001E41 RID: 7745 RVA: 0x000AEAB8 File Offset: 0x000ACCB8
		public static string ResolvedProgId
		{
			get
			{
				MxComponentRuntime.Probe();
				object sync = MxComponentRuntime.Sync;
				string result;
				lock (sync)
				{
					result = (MxComponentRuntime._resolvedDescription ?? "none");
				}
				return result;
			}
		}

		// Token: 0x06001E42 RID: 7746 RVA: 0x000AEB0C File Offset: 0x000ACD0C
		public static void ResetProbe()
		{
			object sync = MxComponentRuntime.Sync;
			lock (sync)
			{
				MxComponentRuntime._probed = false;
				MxComponentRuntime._interopCoClass = null;
				MxComponentRuntime._interopInterface = null;
				MxComponentRuntime._dispatchControlType = null;
				MxComponentRuntime._resolvedDescription = null;
			}
		}

		// Token: 0x06001E43 RID: 7747 RVA: 0x000AEB68 File Offset: 0x000ACD68
		internal static IMxComponentSession CreateSession()
		{
			MxComponentRuntime.Probe();
			object sync = MxComponentRuntime.Sync;
			Type coClass;
			Type contract;
			Type dispatchType;
			lock (sync)
			{
				coClass = MxComponentRuntime._interopCoClass;
				contract = MxComponentRuntime._interopInterface;
				dispatchType = MxComponentRuntime._dispatchControlType;
			}
			bool flag2 = coClass != null && contract != null;
			IMxComponentSession result;
			if (flag2)
			{
				result = new MxInteropSession(coClass, contract);
			}
			else
			{
				bool flag3 = dispatchType != null;
				if (!flag3)
				{
					throw new InvalidOperationException(MxComponentRuntime.DescribeInstallation());
				}
				result = new MxDispatchSession(dispatchType);
			}
			return result;
		}

		// Token: 0x06001E44 RID: 7748 RVA: 0x000AEC08 File Offset: 0x000ACE08
		private static void Probe()
		{
			object sync = MxComponentRuntime.Sync;
			lock (sync)
			{
				bool probed = MxComponentRuntime._probed;
				if (!probed)
				{
					MxComponentRuntime._probed = true;
					bool flag2 = MxComponentRuntime.TryLoadInterop(out MxComponentRuntime._interopCoClass, out MxComponentRuntime._interopInterface) && MxComponentRuntime.FindRegisteredProgId(MxComponentRuntime.LocalServerProgIds) != null;
					if (flag2)
					{
						MxComponentRuntime._resolvedDescription = MxComponentRuntime.FindRegisteredProgId(MxComponentRuntime.LocalServerProgIds) + " (out-of-process)";
					}
					else
					{
						MxComponentRuntime._interopCoClass = null;
						MxComponentRuntime._interopInterface = null;
						string inProcess = MxComponentRuntime.FindProgIdWithInProcessServer(MxComponentRuntime.InProcessProgIds);
						bool flag3 = inProcess != null;
						if (flag3)
						{
							try
							{
								MxComponentRuntime._dispatchControlType = Type.GetTypeFromProgID(inProcess, false);
								bool flag4 = MxComponentRuntime._dispatchControlType != null;
								if (flag4)
								{
									MxComponentRuntime._resolvedDescription = inProcess + " (in-process)";
									return;
								}
							}
							catch
							{
							}
						}
						MxComponentRuntime._dispatchControlType = null;
						MxComponentRuntime._resolvedDescription = null;
					}
				}
			}
		}

		// Token: 0x06001E45 RID: 7749 RVA: 0x000AED14 File Offset: 0x000ACF14
		private static bool TryLoadInterop(out Type coClass, out Type contract)
		{
			coClass = null;
			contract = null;
			bool result;
			try
			{
				string path = MxComponentRuntime.FindInteropAssembly();
				bool flag = path == null;
				if (flag)
				{
					result = false;
				}
				else
				{
					Assembly assembly = Assembly.LoadFrom(path);
					coClass = assembly.GetType("ActUtlType64Lib.ActUtlType64Class");
					contract = assembly.GetType("ActUtlType64Lib.IActUtlType64");
					result = (coClass != null && contract != null);
				}
			}
			catch
			{
				coClass = null;
				contract = null;
				result = false;
			}
			return result;
		}

		// Token: 0x06001E46 RID: 7750 RVA: 0x000AED94 File Offset: 0x000ACF94
		private static string FindInteropAssembly()
		{
			List<string> folders = new List<string>();
			try
			{
				folders.Add(AppDomain.CurrentDomain.BaseDirectory);
			}
			catch
			{
			}
			try
			{
				folders.Add(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
			}
			catch
			{
			}
			foreach (string folder in (from x in folders
			where !string.IsNullOrWhiteSpace(x)
			select x).Distinct<string>())
			{
				foreach (string candidate in new string[]
				{
					Path.Combine(folder, "Interop.ActUtlType64.dll"),
					Path.Combine(folder, "Lib", "Interop.ActUtlType64.dll")
				})
				{
					try
					{
						bool flag = File.Exists(candidate);
						if (flag)
						{
							return candidate;
						}
					}
					catch
					{
					}
				}
			}
			return null;
		}

		// Token: 0x06001E47 RID: 7751 RVA: 0x000AEED0 File Offset: 0x000AD0D0
		public static void SetProperty(object control, string name, object value)
		{
			bool flag = control == null;
			if (flag)
			{
				throw new InvalidOperationException("MX Component is not installed on this computer. Install Mitsubishi MX Component and restart the application.");
			}
			control.GetType().InvokeMember(name, BindingFlags.SetProperty, null, control, new object[]
			{
				value
			});
		}

		// Token: 0x06001E48 RID: 7752 RVA: 0x000AEF10 File Offset: 0x000AD110
		public static int Invoke(object control, string method, params object[] args)
		{
			bool flag = control == null;
			if (flag)
			{
				throw new InvalidOperationException("MX Component is not installed on this computer. Install Mitsubishi MX Component and restart the application.");
			}
			object returned = control.GetType().InvokeMember(method, BindingFlags.InvokeMethod, null, control, args ?? new object[0]);
			return MxComponentRuntime.ToStatusCode(returned);
		}

		// Token: 0x06001E49 RID: 7753 RVA: 0x000AEF5C File Offset: 0x000AD15C
		public static int InvokeWithOutput(object control, string method, object[] args, int outputIndex, out object outputValue)
		{
			outputValue = null;
			bool flag = control == null;
			if (flag)
			{
				throw new InvalidOperationException("MX Component is not installed on this computer. Install Mitsubishi MX Component and restart the application.");
			}
			bool flag2 = args == null || outputIndex < 0 || outputIndex >= args.Length;
			if (flag2)
			{
				throw new ArgumentOutOfRangeException("outputIndex");
			}
			ParameterModifier modifier = new ParameterModifier(args.Length);
			modifier[outputIndex] = true;
			object returned = control.GetType().InvokeMember(method, BindingFlags.InvokeMethod, null, control, args, new ParameterModifier[]
			{
				modifier
			}, null, null);
			outputValue = args[outputIndex];
			return MxComponentRuntime.ToStatusCode(returned);
		}

		// Token: 0x06001E4A RID: 7754 RVA: 0x000AEFF0 File Offset: 0x000AD1F0
		public static int InvokeWithOutputs(object control, string method, object[] args, out object[] outputs)
		{
			outputs = null;
			bool flag = control == null;
			if (flag)
			{
				throw new InvalidOperationException("MX Component is not installed on this computer. Install Mitsubishi MX Component and restart the application.");
			}
			args = (args ?? new object[0]);
			ParameterModifier modifier = new ParameterModifier(Math.Max(1, args.Length));
			for (int i = 0; i < args.Length; i++)
			{
				modifier[i] = true;
			}
			Type type = control.GetType();
			BindingFlags invokeAttr = BindingFlags.InvokeMethod;
			Binder binder = null;
			object[] args2 = args;
			ParameterModifier[] modifiers;
			if (args.Length != 0)
			{
				(modifiers = new ParameterModifier[1])[0] = modifier;
			}
			else
			{
				modifiers = null;
			}
			object returned = type.InvokeMember(method, invokeAttr, binder, control, args2, modifiers, null, null);
			outputs = args;
			return MxComponentRuntime.ToStatusCode(returned);
		}

		// Token: 0x06001E4B RID: 7755 RVA: 0x000AF08C File Offset: 0x000AD28C
		public static string DescribeStatus(int code)
		{
			return (code == 0) ? "OK" : ("MX Component error 0x" + code.ToString("X8"));
		}

		// Token: 0x06001E4C RID: 7756 RVA: 0x000AF0C0 File Offset: 0x000AD2C0
		public static string DescribeException(Exception ex)
		{
			Exception inner = (ex is TargetInvocationException && ex.InnerException != null) ? ex.InnerException : ex;
			COMException comException = inner as COMException;
			return (comException != null) ? (comException.Message + " (HRESULT 0x" + comException.HResult.ToString("X8") + ")") : inner.Message;
		}

		// Token: 0x06001E4D RID: 7757 RVA: 0x000AF128 File Offset: 0x000AD328
		public static string DescribeInstallation()
		{
			bool isInstalled = MxComponentRuntime.IsInstalled;
			string result;
			if (isInstalled)
			{
				result = "MX Component control in use: " + MxComponentRuntime.ResolvedProgId + ".";
			}
			else
			{
				bool hasLocalServer = MxComponentRuntime.FindRegisteredProgId(MxComponentRuntime.LocalServerProgIds) != null;
				bool hasInProcess = MxComponentRuntime.FindProgIdWithInProcessServer(MxComponentRuntime.InProcessProgIds) != null;
				bool flag = hasLocalServer;
				if (flag)
				{
					result = "MX Component provides the 64-bit control (ActUtlType64), but Interop.ActUtlType64.dll is missing from the application folder, so it cannot be used.";
				}
				else
				{
					bool flag2 = hasInProcess && Environment.Is64BitProcess;
					if (flag2)
					{
						result = "MX Component is installed, but this machine only registers the 32-bit in-process control and the application runs as a 64-bit process, which cannot load it. Install a MX Component version that provides ActUtlType64.";
					}
					else
					{
						bool flag3 = hasInProcess;
						if (flag3)
						{
							result = "MX Component is registered but its control could not be created.";
						}
						else
						{
							result = "MX Component is not installed on this computer. Install Mitsubishi MX Component and restart the application.";
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001E4E RID: 7758 RVA: 0x000AF1B4 File Offset: 0x000AD3B4
		private static string FindRegisteredProgId(string[] progIds)
		{
			return progIds.FirstOrDefault(new Func<string, bool>(MxComponentRuntime.IsProgIdRegistered));
		}

		// Token: 0x06001E4F RID: 7759 RVA: 0x000AF1D8 File Offset: 0x000AD3D8
		private static bool IsProgIdRegistered(string progId)
		{
			return MxComponentRuntime.ReadClsid(progId, RegistryView.Registry64) != null || MxComponentRuntime.ReadClsid(progId, RegistryView.Registry32) != null;
		}

		// Token: 0x06001E50 RID: 7760 RVA: 0x000AF208 File Offset: 0x000AD408
		private static string FindProgIdWithInProcessServer(string[] progIds)
		{
			RegistryView view = Environment.Is64BitProcess ? RegistryView.Registry64 : RegistryView.Registry32;
			foreach (string progId in progIds)
			{
				string clsid = MxComponentRuntime.ReadClsid(progId, view);
				bool flag = clsid == null;
				if (!flag)
				{
					bool flag2 = MxComponentRuntime.HasSubKey("CLSID\\" + clsid + "\\InprocServer32", view);
					if (flag2)
					{
						return progId;
					}
				}
			}
			return null;
		}

		// Token: 0x06001E51 RID: 7761 RVA: 0x000AF280 File Offset: 0x000AD480
		private static string ReadClsid(string progId, RegistryView view)
		{
			string result;
			try
			{
				using (RegistryKey root = RegistryKey.OpenBaseKey(RegistryHive.ClassesRoot, view))
				{
					using (RegistryKey key = root.OpenSubKey(progId + "\\CLSID"))
					{
						string clsid = ((key != null) ? key.GetValue(null) : null) as string;
						result = (string.IsNullOrWhiteSpace(clsid) ? null : clsid);
					}
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06001E52 RID: 7762 RVA: 0x000AF318 File Offset: 0x000AD518
		private static bool HasSubKey(string path, RegistryView view)
		{
			bool result;
			try
			{
				using (RegistryKey root = RegistryKey.OpenBaseKey(RegistryHive.ClassesRoot, view))
				{
					using (RegistryKey key = root.OpenSubKey(path))
					{
						result = (key != null);
					}
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06001E53 RID: 7763 RVA: 0x000AF388 File Offset: 0x000AD588
		private static int ToStatusCode(object returned)
		{
			bool flag = returned == null;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				try
				{
					result = Convert.ToInt32(returned);
				}
				catch
				{
					result = 0;
				}
			}
			return result;
		}

		// Token: 0x04000CC7 RID: 3271
		public const string NotInstalledMessage = "MX Component is not installed on this computer. Install Mitsubishi MX Component and restart the application.";

		// Token: 0x04000CC8 RID: 3272
		private const string InteropAssemblyFileName = "Interop.ActUtlType64.dll";

		// Token: 0x04000CC9 RID: 3273
		private const string InteropCoClassName = "ActUtlType64Lib.ActUtlType64Class";

		// Token: 0x04000CCA RID: 3274
		private const string InteropInterfaceName = "ActUtlType64Lib.IActUtlType64";

		// Token: 0x04000CCB RID: 3275
		private static readonly string[] LocalServerProgIds = new string[]
		{
			"ActUtlType64.ActUtlWrap",
			"ActUtlType64.ActUtlWrap.1"
		};

		// Token: 0x04000CCC RID: 3276
		private static readonly string[] InProcessProgIds = new string[]
		{
			"ActUtlType.ActUtlType",
			"ActUtlType.ActUtlType.1"
		};

		// Token: 0x04000CCD RID: 3277
		private static readonly object Sync = new object();

		// Token: 0x04000CCE RID: 3278
		private static bool _probed;

		// Token: 0x04000CCF RID: 3279
		private static Type _interopCoClass;

		// Token: 0x04000CD0 RID: 3280
		private static Type _interopInterface;

		// Token: 0x04000CD1 RID: 3281
		private static Type _dispatchControlType;

		// Token: 0x04000CD2 RID: 3282
		private static string _resolvedDescription;
	}
}
