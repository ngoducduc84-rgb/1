﻿using System;
using System.Collections.Concurrent;
using System.Threading;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000204 RID: 516
	internal sealed class MxComponentStaWorker : IDisposable
	{
		// Token: 0x06001E55 RID: 7765 RVA: 0x000AF414 File Offset: 0x000AD614
		public MxComponentStaWorker()
		{
			this._thread = new Thread(new ThreadStart(this.Loop))
			{
				IsBackground = true,
				Name = "MX Component STA"
			};
			this._thread.SetApartmentState(ApartmentState.STA);
			this._thread.Start();
		}

		// Token: 0x06001E56 RID: 7766 RVA: 0x000AF478 File Offset: 0x000AD678
		public T Run<T>(Func<T> work)
		{
			bool flag = work == null;
			if (flag)
			{
				throw new ArgumentNullException("work");
			}
			bool flag2 = Thread.CurrentThread == this._thread;
			T result2;
			if (flag2)
			{
				result2 = work();
			}
			else
			{
				T result = default(T);
				Exception error = null;
				using (ManualResetEventSlim done = new ManualResetEventSlim(false))
				{
					try
					{
						this._queue.Add(delegate()
						{
							try
							{
								result = work();
							}
							catch (Exception ex)
							{
								error = ex;
							}
							finally
							{
								done.Set();
							}
						});
					}
					catch (InvalidOperationException)
					{
						throw new InvalidOperationException("MX Component worker has been shut down.");
					}
					done.Wait();
				}
				bool flag3 = error != null;
				if (flag3)
				{
					throw new MxComponentWorkerException(error);
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06001E57 RID: 7767 RVA: 0x000AF590 File Offset: 0x000AD790
		public void Run(Action work)
		{
			bool flag = work == null;
			if (!flag)
			{
				this.Run<object>(delegate()
				{
					work();
					return null;
				});
			}
		}

		// Token: 0x06001E58 RID: 7768 RVA: 0x000AF5D0 File Offset: 0x000AD7D0
		private void Loop()
		{
			foreach (Action item in this._queue.GetConsumingEnumerable())
			{
				try
				{
					item();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001E59 RID: 7769 RVA: 0x000AF63C File Offset: 0x000AD83C
		public void Dispose()
		{
			try
			{
				this._queue.CompleteAdding();
			}
			catch
			{
			}
		}

		// Token: 0x04000CD3 RID: 3283
		private readonly BlockingCollection<Action> _queue = new BlockingCollection<Action>();

		// Token: 0x04000CD4 RID: 3284
		private readonly Thread _thread;
	}
}
