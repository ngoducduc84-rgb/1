﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000205 RID: 517
	internal sealed class MxComponentWorkerException : Exception
	{
		// Token: 0x06001E5A RID: 7770 RVA: 0x000AF670 File Offset: 0x000AD870
		public MxComponentWorkerException(Exception inner) : base(((inner != null) ? inner.Message : null) ?? "MX Component call failed.", inner)
		{
		}
	}
}
