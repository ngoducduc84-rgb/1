﻿using System;
using System.Runtime.InteropServices;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000208 RID: 520
	internal sealed class MxDispatchSession : IMxComponentSession, IDisposable
	{
		// Token: 0x06001E68 RID: 7784 RVA: 0x000AF8E4 File Offset: 0x000ADAE4
		public MxDispatchSession(Type controlType)
		{
			bool flag = controlType == null;
			if (flag)
			{
				throw new InvalidOperationException("MX Component is not installed on this computer. Install Mitsubishi MX Component and restart the application.");
			}
			this._control = Activator.CreateInstance(controlType);
		}

		// Token: 0x06001E69 RID: 7785 RVA: 0x000AF91C File Offset: 0x000ADB1C
		public int Open(int logicalStationNumber)
		{
			MxComponentRuntime.SetProperty(this._control, "ActLogicalStationNumber", logicalStationNumber);
			return MxComponentRuntime.Invoke(this._control, "Open", Array.Empty<object>());
		}

		// Token: 0x06001E6A RID: 7786 RVA: 0x000AF95C File Offset: 0x000ADB5C
		public int Close()
		{
			return (this._control == null) ? 0 : MxComponentRuntime.Invoke(this._control, "Close", Array.Empty<object>());
		}

		// Token: 0x06001E6B RID: 7787 RVA: 0x000AF990 File Offset: 0x000ADB90
		public int GetDevice(string device, out int value)
		{
			object[] args = new object[]
			{
				device,
				0
			};
			object read;
			int code = MxComponentRuntime.InvokeWithOutput(this._control, "GetDevice", args, 1, out read);
			value = ((code == 0) ? Convert.ToInt32(read) : 0);
			return code;
		}

		// Token: 0x06001E6C RID: 7788 RVA: 0x000AF9DC File Offset: 0x000ADBDC
		public int SetDevice(string device, int value)
		{
			return MxComponentRuntime.Invoke(this._control, "SetDevice", new object[]
			{
				device,
				value
			});
		}

		// Token: 0x06001E6D RID: 7789 RVA: 0x000AFA14 File Offset: 0x000ADC14
		public int GetCpuType(out string cpuName)
		{
			object[] outputs;
			int code = MxComponentRuntime.InvokeWithOutputs(this._control, "GetCpuType", new object[]
			{
				string.Empty,
				0
			}, out outputs);
			cpuName = ((code == 0 && outputs != null && outputs.Length != 0) ? Convert.ToString(outputs[0]) : string.Empty);
			return code;
		}

		// Token: 0x06001E6E RID: 7790 RVA: 0x000AFA6C File Offset: 0x000ADC6C
		public void Dispose()
		{
			bool flag = this._control == null;
			if (!flag)
			{
				try
				{
					MxComponentRuntime.Invoke(this._control, "Close", Array.Empty<object>());
				}
				catch
				{
				}
				try
				{
					bool flag2 = Marshal.IsComObject(this._control);
					if (flag2)
					{
						Marshal.ReleaseComObject(this._control);
					}
				}
				catch
				{
				}
				this._control = null;
			}
		}

		// Token: 0x04000CD7 RID: 3287
		private object _control;
	}
}
