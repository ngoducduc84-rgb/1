﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000207 RID: 519
	internal sealed class MxInteropSession : IMxComponentSession, IDisposable
	{
		// Token: 0x06001E60 RID: 7776 RVA: 0x000AF690 File Offset: 0x000AD890
		public MxInteropSession(Type coClassType, Type interfaceType)
		{
			bool flag = coClassType == null || interfaceType == null;
			if (flag)
			{
				throw new InvalidOperationException("MX Component is not installed on this computer. Install Mitsubishi MX Component and restart the application.");
			}
			this._interfaceType = interfaceType;
			this._control = Activator.CreateInstance(coClassType);
		}

		// Token: 0x06001E61 RID: 7777 RVA: 0x000AF6DC File Offset: 0x000AD8DC
		public int Open(int logicalStationNumber)
		{
			this._interfaceType.GetProperty("ActLogicalStationNumber").SetValue(this._control, logicalStationNumber, null);
			return this.Call("Open", null);
		}

		// Token: 0x06001E62 RID: 7778 RVA: 0x000AF720 File Offset: 0x000AD920
		public int Close()
		{
			return (this._control == null) ? 0 : this.Call("Close", null);
		}

		// Token: 0x06001E63 RID: 7779 RVA: 0x000AF74C File Offset: 0x000AD94C
		public int GetDevice(string device, out int value)
		{
			object[] args = new object[]
			{
				device,
				0
			};
			int code = this.Call("GetDevice", args);
			value = ((code == 0) ? Convert.ToInt32(args[1]) : 0);
			return code;
		}

		// Token: 0x06001E64 RID: 7780 RVA: 0x000AF790 File Offset: 0x000AD990
		public int SetDevice(string device, int value)
		{
			return this.Call("SetDevice", new object[]
			{
				device,
				value
			});
		}

		// Token: 0x06001E65 RID: 7781 RVA: 0x000AF7C0 File Offset: 0x000AD9C0
		public int GetCpuType(out string cpuName)
		{
			object[] args = new object[]
			{
				string.Empty,
				0
			};
			int code = this.Call("GetCpuType", args);
			cpuName = ((code == 0) ? Convert.ToString(args[0]) : string.Empty);
			return code;
		}

		// Token: 0x06001E66 RID: 7782 RVA: 0x000AF80C File Offset: 0x000ADA0C
		private int Call(string method, object[] args)
		{
			MethodInfo info = this._interfaceType.GetMethod(method);
			bool flag = info == null;
			if (flag)
			{
				throw new InvalidOperationException("MX Component control does not expose " + method + ".");
			}
			object returned = info.Invoke(this._control, args);
			return (returned == null) ? 0 : Convert.ToInt32(returned);
		}

		// Token: 0x06001E67 RID: 7783 RVA: 0x000AF868 File Offset: 0x000ADA68
		public void Dispose()
		{
			bool flag = this._control == null;
			if (!flag)
			{
				try
				{
					this.Call("Close", null);
				}
				catch
				{
				}
				try
				{
					bool flag2 = Marshal.IsComObject(this._control);
					if (flag2)
					{
						Marshal.ReleaseComObject(this._control);
					}
				}
				catch
				{
				}
				this._control = null;
			}
		}

		// Token: 0x04000CD5 RID: 3285
		private readonly Type _interfaceType;

		// Token: 0x04000CD6 RID: 3286
		private object _control;
	}
}
