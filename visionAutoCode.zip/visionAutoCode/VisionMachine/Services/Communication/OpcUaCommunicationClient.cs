﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Sockets;
using System.Threading;
using Opc.Ua;
using Opc.Ua.Client;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000226 RID: 550
	internal class OpcUaCommunicationClient : IPlcCommunicationClient, IDisposable, IOpcTagBrowser, IOpcArrayWriter
	{
		// Token: 0x17000950 RID: 2384
		// (get) Token: 0x06001F15 RID: 7957 RVA: 0x000B454C File Offset: 0x000B274C
		public bool IsConnectionAlive
		{
			get
			{
				object sync = this._sync;
				bool result;
				lock (sync)
				{
					result = (this._session != null && this._session.Connected && this._keepAliveHealthy && this.IsKeepAliveFresh());
				}
				return result;
			}
		}

		// Token: 0x06001F16 RID: 7958 RVA: 0x000B45B4 File Offset: 0x000B27B4
		public CommunicationOperationResult Connect(CommunicationConnection connection)
		{
			object sync = this._sync;
			CommunicationOperationResult result;
			lock (sync)
			{
				try
				{
					this.DisposeSession();
					this._endpointUrl = OpcUaCommunicationClient.BuildEndpointUrl(connection);
					this._configuration = OpcUaCommunicationClient.BuildApplicationConfiguration(connection);
					int timeoutMs = OpcUaCommunicationClient.GetOpcOperationTimeoutMs(connection);
					string probeError;
					bool flag2 = !OpcUaCommunicationClient.CanReachTcpEndpoint(connection, Math.Min(timeoutMs, 500), out probeError);
					if (flag2)
					{
						result = CommunicationOperationResult.Fail("OPC UA TCP probe failed: " + probeError, 0, 0);
					}
					else
					{
						EndpointDescription selectedEndpoint = CoreClientUtils.SelectEndpoint(this._configuration, this._endpointUrl, false, timeoutMs);
						EndpointConfiguration endpointConfiguration = EndpointConfiguration.Create(this._configuration);
						endpointConfiguration.OperationTimeout = timeoutMs;
						ConfiguredEndpoint endpoint = new ConfiguredEndpoint(null, selectedEndpoint, endpointConfiguration);
						UserIdentity identity = new UserIdentity(new AnonymousIdentityToken());
						uint sessionTimeout = (uint)Math.Max(2000, timeoutMs * 3);
						this._session = Session.Create(this._configuration, endpoint, false, "VisionMachine OPC UA", sessionTimeout, identity, null, CancellationToken.None).GetAwaiter().GetResult();
						bool flag3 = this._session != null;
						if (flag3)
						{
							this._keepAliveIntervalMs = Math.Max(300, timeoutMs);
							this._keepAliveTimeoutMs = Math.Max(1000, this._keepAliveIntervalMs * 3);
							this._keepAliveHealthy = true;
							this._lastKeepAliveStatus = null;
							this._lastKeepAliveUtc = DateTime.UtcNow;
							this._session.KeepAliveInterval = this._keepAliveIntervalMs;
							this._session.KeepAlive += this.OpcSession_KeepAlive;
						}
						result = ((this._session != null && this._session.Connected) ? CommunicationOperationResult.Ok("OPC UA connected.", 0, 0) : CommunicationOperationResult.Fail("OPC UA session was not established.", 0, 0));
					}
				}
				catch (Exception ex)
				{
					this.DisposeSession();
					result = CommunicationOperationResult.Fail("OPC UA connect failed: " + OpcUaCommunicationClient.FormatExceptionMessage(ex), 0, 0);
				}
			}
			return result;
		}

		// Token: 0x06001F17 RID: 7959 RVA: 0x000B47CC File Offset: 0x000B29CC
		public CommunicationOperationResult Test(CommunicationConnection connection)
		{
			object sync = this._sync;
			CommunicationOperationResult result;
			lock (sync)
			{
				bool flag2 = this._session == null || !this._session.Connected;
				if (flag2)
				{
					result = CommunicationOperationResult.Fail("OPC UA session is not connected.", 0, 0);
				}
				else
				{
					bool flag3 = !this._keepAliveHealthy;
					if (flag3)
					{
						string message = string.IsNullOrWhiteSpace(this._lastKeepAliveStatus) ? "OPC UA keep-alive reported a bad status." : this._lastKeepAliveStatus;
						this.DisposeSession();
						result = CommunicationOperationResult.Fail(message, 0, 0);
					}
					else
					{
						bool flag4 = !this.IsKeepAliveFresh();
						if (flag4)
						{
							string message2 = "OPC UA keep-alive timeout. Last keep-alive=" + ((this._lastKeepAliveUtc == DateTime.MinValue) ? "never" : this._lastKeepAliveUtc.ToLocalTime().ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture));
							this.DisposeSession();
							result = CommunicationOperationResult.Fail(message2, 0, 0);
						}
						else
						{
							try
							{
								ReadValueId valueId = new ReadValueId
								{
									NodeId = VariableIds.Server_ServerStatus_CurrentTime,
									AttributeId = 13U
								};
								ReadValueIdCollection nodesToRead = new ReadValueIdCollection
								{
									valueId
								};
								DataValueCollection results;
								DiagnosticInfoCollection diagnosticInfos;
								this._session.Read(OpcUaCommunicationClient.CreateRequestHeader(connection), 0.0, TimestampsToReturn.Neither, nodesToRead, out results, out diagnosticInfos);
								ClientBase.ValidateResponse<ReadValueId, DataValue>(results, nodesToRead);
								ClientBase.ValidateDiagnosticInfos<ReadValueId>(diagnosticInfos, nodesToRead);
								DataValue value = results.FirstOrDefault<DataValue>();
								bool flag5 = value == null || !StatusCode.IsGood(value.StatusCode);
								if (flag5)
								{
									result = CommunicationOperationResult.Fail("OPC UA health check failed: " + (((value != null) ? value.StatusCode.ToString() : null) ?? "No value"), 0, 0);
								}
								else
								{
									result = CommunicationOperationResult.Ok("OPC UA session is connected.", 0, 0);
								}
							}
							catch (Exception ex)
							{
								this.DisposeSession();
								result = CommunicationOperationResult.Fail("OPC UA health check failed: " + OpcUaCommunicationClient.FormatExceptionMessage(ex), 0, 0);
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001F18 RID: 7960 RVA: 0x000B4A00 File Offset: 0x000B2C00
		private void OpcSession_KeepAlive(ISession session, KeepAliveEventArgs e)
		{
			object sync = this._sync;
			lock (sync)
			{
				this._lastKeepAliveUtc = DateTime.UtcNow;
				bool flag2 = e == null || ServiceResult.IsGood(e.Status);
				if (flag2)
				{
					this._keepAliveHealthy = true;
					this._lastKeepAliveStatus = null;
				}
				else
				{
					this._keepAliveHealthy = false;
					string str = "OPC UA keep-alive failed: ";
					ServiceResult status = e.Status;
					this._lastKeepAliveStatus = str + ((status != null) ? status.ToString() : null);
				}
			}
		}

		// Token: 0x06001F19 RID: 7961 RVA: 0x000B4A9C File Offset: 0x000B2C9C
		private bool IsKeepAliveFresh()
		{
			bool flag = this._lastKeepAliveUtc == DateTime.MinValue;
			return !flag && (DateTime.UtcNow - this._lastKeepAliveUtc).TotalMilliseconds <= (double)this._keepAliveTimeoutMs;
		}

		// Token: 0x06001F1A RID: 7962 RVA: 0x000B4AEC File Offset: 0x000B2CEC
		public CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			object sync = this._sync;
			CommunicationReadResult result;
			lock (sync)
			{
				bool flag2 = this._session == null || !this._session.Connected;
				if (flag2)
				{
					result = CommunicationReadResult.Fail("OPC UA session is not connected.");
				}
				else
				{
					List<CommunicationTagRow> tagList = (from x in tags ?? Enumerable.Empty<CommunicationTagRow>()
					where x != null
					select x).ToList<CommunicationTagRow>();
					bool flag3 = tagList.Count == 0;
					if (flag3)
					{
						result = CommunicationReadResult.From(true, "No OPC UA tag configured.", null, 0, 0);
					}
					else
					{
						List<CommunicationMonitorRow> rows = new List<CommunicationMonitorRow>();
						string timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
						foreach (CommunicationTagRow tag in tagList)
						{
							try
							{
								OpcUaCommunicationClient.OpcAddress opcAddress = OpcUaCommunicationClient.ParseOpcAddress(tag.Address);
								ReadValueId valueId = new ReadValueId
								{
									NodeId = opcAddress.NodeId,
									AttributeId = 13U
								};
								ReadValueIdCollection nodesToRead = new ReadValueIdCollection
								{
									valueId
								};
								DataValueCollection results;
								DiagnosticInfoCollection diagnosticInfos;
								this._session.Read(OpcUaCommunicationClient.CreateRequestHeader(connection), 0.0, TimestampsToReturn.Neither, nodesToRead, out results, out diagnosticInfos);
								ClientBase.ValidateResponse<ReadValueId, DataValue>(results, nodesToRead);
								ClientBase.ValidateDiagnosticInfos<ReadValueId>(diagnosticInfos, nodesToRead);
								DataValue dataValue = results.FirstOrDefault<DataValue>();
								bool flag4 = dataValue == null;
								if (flag4)
								{
									throw new InvalidOperationException("OPC UA read returned no value.");
								}
								object outputValue = OpcUaCommunicationClient.ResolveOpcIndexedValue(dataValue.Value, opcAddress.ElementIndex);
								rows.Add(new CommunicationMonitorRow(tag.Name, tag.Group, tag.ReadWrite, tag.Address, OpcUaCommunicationClient.ResolveOpcDataType(tag.DataType, outputValue), OpcUaCommunicationClient.FormatOpcValue(outputValue), StatusCode.IsGood(dataValue.StatusCode) ? "Good" : "Bad", timestamp, string.IsNullOrWhiteSpace(tag.Description) ? tag.Name : tag.Description));
							}
							catch (Exception ex)
							{
								rows.Add(new CommunicationMonitorRow(tag.Name, tag.Group, tag.ReadWrite, tag.Address, tag.DataType, ex.Message, "Bad", timestamp, string.IsNullOrWhiteSpace(tag.Description) ? tag.Name : tag.Description));
							}
						}
						result = CommunicationReadResult.From(true, "OPC UA read completed.", rows, tagList.Count, rows.Count);
					}
				}
			}
			return result;
		}

		// Token: 0x06001F1B RID: 7963 RVA: 0x000B4DE0 File Offset: 0x000B2FE0
		public CommunicationReadResult BrowseTags(CommunicationConnection connection)
		{
			object sync = this._sync;
			CommunicationReadResult result2;
			lock (sync)
			{
				bool flag2 = this._session == null || !this._session.Connected;
				if (flag2)
				{
					result2 = CommunicationReadResult.Fail("OPC UA session is not connected.");
				}
				else
				{
					try
					{
						List<CommunicationTagRow> tags = new List<CommunicationTagRow>();
						HashSet<string> visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
						this.BrowseNodeRecursive(ObjectIds.ObjectsFolder, "Objects", 0, visited, tags);
						bool flag3 = tags.Count == 0;
						if (flag3)
						{
							result2 = CommunicationReadResult.Fail("No PLC OPC UA variables were found. Check that variables are enabled in the PLC OPC UA Server Variable CFG.");
						}
						else
						{
							CommunicationReadResult result = this.ReadAll(connection, tags);
							result.Message = "Browse OPC UA tags completed. Found " + tags.Count.ToString() + " variable(s).";
							result2 = result;
						}
					}
					catch (Exception ex)
					{
						result2 = CommunicationReadResult.Fail("Browse OPC UA tags failed: " + OpcUaCommunicationClient.FormatExceptionMessage(ex));
					}
				}
			}
			return result2;
		}

		// Token: 0x06001F1C RID: 7964 RVA: 0x000B4EF4 File Offset: 0x000B30F4
		public CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			object sync = this._sync;
			CommunicationOperationResult result;
			lock (sync)
			{
				bool flag2 = this._session == null || !this._session.Connected;
				if (flag2)
				{
					result = CommunicationOperationResult.Fail("OPC UA session is not connected.", 0, 0);
				}
				else
				{
					try
					{
						OpcUaCommunicationClient.OpcAddress opcAddress = OpcUaCommunicationClient.ParseOpcAddress(address);
						object writePayload = (opcAddress.ElementIndex != null) ? this.CreateOpcIndexedArrayWriteValue(opcAddress.NodeId, opcAddress.ElementIndex.Value, dataType, value) : OpcUaCommunicationClient.ConvertOpcWriteValue(value, dataType);
						WriteValue writeValue = new WriteValue
						{
							NodeId = opcAddress.NodeId,
							AttributeId = 13U,
							Value = new DataValue(new Variant(writePayload))
						};
						WriteValueCollection nodesToWrite = new WriteValueCollection
						{
							writeValue
						};
						StatusCodeCollection results;
						DiagnosticInfoCollection diagnosticInfos;
						this._session.Write(OpcUaCommunicationClient.CreateRequestHeader(connection), nodesToWrite, out results, out diagnosticInfos);
						ClientBase.ValidateResponse<WriteValue, StatusCode>(results, nodesToWrite);
						ClientBase.ValidateDiagnosticInfos<WriteValue>(diagnosticInfos, nodesToWrite);
						StatusCode status = results.FirstOrDefault<StatusCode>();
						bool flag3 = StatusCode.IsBad(status);
						if (flag3)
						{
							string str = "OPC UA write failed: ";
							StatusCode statusCode = status;
							result = CommunicationOperationResult.Fail(str + statusCode.ToString(), 0, 0);
						}
						else
						{
							result = CommunicationOperationResult.Ok("OPC UA write completed.", 1, 1);
						}
					}
					catch (Exception ex)
					{
						result = CommunicationOperationResult.Fail("OPC UA write failed: " + OpcUaCommunicationClient.FormatExceptionMessage(ex), 0, 0);
					}
				}
			}
			return result;
		}

		// Token: 0x06001F1D RID: 7965 RVA: 0x000B50A4 File Offset: 0x000B32A4
		public CommunicationOperationResult WriteArray(string nodeId, string dataType, IReadOnlyList<string> values)
		{
			object sync = this._sync;
			CommunicationOperationResult result;
			lock (sync)
			{
				bool flag2 = this._session == null || !this._session.Connected;
				if (flag2)
				{
					result = CommunicationOperationResult.Fail("OPC UA session is not connected.", 0, 0);
				}
				else
				{
					bool flag3 = values == null || values.Count == 0;
					if (flag3)
					{
						result = CommunicationOperationResult.Fail("No OPC array values to write.", 0, 0);
					}
					else
					{
						try
						{
							OpcUaCommunicationClient.OpcAddress opcAddress = OpcUaCommunicationClient.ParseOpcAddress(nodeId);
							bool flag4 = opcAddress.ElementIndex != null;
							if (flag4)
							{
								result = this.Write(null, nodeId, dataType, values[0]);
							}
							else
							{
								Array payload = OpcUaCommunicationClient.BuildOpcArray(dataType, values);
								WriteValue writeValue = new WriteValue
								{
									NodeId = opcAddress.NodeId,
									AttributeId = 13U,
									Value = new DataValue(new Variant(payload))
								};
								WriteValueCollection nodesToWrite = new WriteValueCollection
								{
									writeValue
								};
								StatusCodeCollection results;
								DiagnosticInfoCollection diagnosticInfos;
								this._session.Write(OpcUaCommunicationClient.CreateRequestHeader(null), nodesToWrite, out results, out diagnosticInfos);
								ClientBase.ValidateResponse<WriteValue, StatusCode>(results, nodesToWrite);
								ClientBase.ValidateDiagnosticInfos<WriteValue>(diagnosticInfos, nodesToWrite);
								StatusCode status = results.FirstOrDefault<StatusCode>();
								bool flag5 = StatusCode.IsBad(status);
								if (flag5)
								{
									string str = "OPC UA array write failed: ";
									StatusCode statusCode = status;
									result = CommunicationOperationResult.Fail(str + statusCode.ToString(), 0, 0);
								}
								else
								{
									result = CommunicationOperationResult.Ok("OPC UA array write completed.", values.Count, 1);
								}
							}
						}
						catch (Exception ex)
						{
							result = CommunicationOperationResult.Fail("OPC UA array write failed: " + OpcUaCommunicationClient.FormatExceptionMessage(ex), 0, 0);
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001F1E RID: 7966 RVA: 0x000B5278 File Offset: 0x000B3478
		private static Array BuildOpcArray(string dataType, IReadOnlyList<string> values)
		{
			string normalizedType = (dataType ?? string.Empty).Trim().ToUpperInvariant();
			string text = normalizedType;
			string text2 = text;
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
			if (num > 2286151596U)
			{
				if (num <= 2991499325U)
				{
					if (num != 2316881829U)
					{
						if (num != 2991499325U)
						{
							goto IL_1D3;
						}
						if (!(text2 == "BOOL"))
						{
							goto IL_1D3;
						}
						return OpcUaCommunicationClient.ConvertOpcArray<bool>(dataType, values);
					}
					else if (!(text2 == "FLOAT"))
					{
						goto IL_1D3;
					}
				}
				else if (num != 3560013981U)
				{
					if (num != 3751281736U)
					{
						if (num != 4127814520U)
						{
							goto IL_1D3;
						}
						if (!(text2 == "STRING"))
						{
							goto IL_1D3;
						}
						return OpcUaCommunicationClient.ConvertOpcArray<string>(dataType, values);
					}
					else
					{
						if (!(text2 == "DOUBLE"))
						{
							goto IL_1D3;
						}
						return OpcUaCommunicationClient.ConvertOpcArray<double>(dataType, values);
					}
				}
				else if (!(text2 == "REAL"))
				{
					goto IL_1D3;
				}
				return OpcUaCommunicationClient.ConvertOpcArray<float>(dataType, values);
			}
			if (num > 268302705U)
			{
				if (num != 843930396U)
				{
					if (num != 2214109151U)
					{
						if (num != 2286151596U)
						{
							goto IL_1D3;
						}
						if (!(text2 == "UINT32"))
						{
							goto IL_1D3;
						}
						return OpcUaCommunicationClient.ConvertOpcArray<uint>(dataType, values);
					}
					else if (!(text2 == "INT32"))
					{
						goto IL_1D3;
					}
				}
				else if (!(text2 == "DINT"))
				{
					goto IL_1D3;
				}
				return OpcUaCommunicationClient.ConvertOpcArray<int>(dataType, values);
			}
			if (num != 71211698U)
			{
				if (num == 268302705U)
				{
					if (text2 == "INT16")
					{
						return OpcUaCommunicationClient.ConvertOpcArray<short>(dataType, values);
					}
				}
			}
			else if (text2 == "UINT16")
			{
				return OpcUaCommunicationClient.ConvertOpcArray<ushort>(dataType, values);
			}
			IL_1D3:
			return OpcUaCommunicationClient.ConvertOpcArray<double>(dataType, values);
		}

		// Token: 0x06001F1F RID: 7967 RVA: 0x000B5468 File Offset: 0x000B3668
		private static T[] ConvertOpcArray<T>(string dataType, IReadOnlyList<string> values)
		{
			T[] array = new T[values.Count];
			for (int i = 0; i < values.Count; i++)
			{
				array[i] = (T)((object)OpcUaCommunicationClient.ConvertOpcWriteValueToType(values[i], dataType, typeof(T)));
			}
			return array;
		}

		// Token: 0x06001F20 RID: 7968 RVA: 0x000B54C0 File Offset: 0x000B36C0
		public void Dispose()
		{
			object sync = this._sync;
			lock (sync)
			{
				this.DisposeSession();
			}
		}

		// Token: 0x06001F21 RID: 7969 RVA: 0x000B5508 File Offset: 0x000B3708
		private static ApplicationConfiguration BuildApplicationConfiguration(CommunicationConnection connection)
		{
			int timeout = OpcUaCommunicationClient.GetOpcOperationTimeoutMs(connection);
			ApplicationConfiguration configuration = new ApplicationConfiguration
			{
				ApplicationName = "VisionMachine OPC UA Client",
				ApplicationUri = "urn:VisionMachine:OpcUaClient",
				ApplicationType = ApplicationType.Client,
				SecurityConfiguration = new SecurityConfiguration
				{
					AutoAcceptUntrustedCertificates = true,
					AddAppCertToTrustedStore = false,
					RejectSHA1SignedCertificates = false,
					MinimumCertificateKeySize = 1024,
					ApplicationCertificate = new CertificateIdentifier
					{
						StoreType = "Directory",
						StorePath = "OPC Foundation/CertificateStores/MachineDefault",
						SubjectName = "VisionMachine OPC UA Client"
					},
					TrustedPeerCertificates = new CertificateTrustList
					{
						StoreType = "Directory",
						StorePath = "OPC Foundation/CertificateStores/UA Applications"
					},
					TrustedIssuerCertificates = new CertificateTrustList
					{
						StoreType = "Directory",
						StorePath = "OPC Foundation/CertificateStores/UA Certificate Authorities"
					},
					RejectedCertificateStore = new CertificateTrustList
					{
						StoreType = "Directory",
						StorePath = "OPC Foundation/CertificateStores/RejectedCertificates"
					}
				},
				TransportConfigurations = new TransportConfigurationCollection(),
				TransportQuotas = new TransportQuotas
				{
					OperationTimeout = timeout,
					MaxStringLength = 1048576,
					MaxByteStringLength = 1048576,
					MaxArrayLength = 65535,
					MaxMessageSize = 4194304,
					MaxBufferSize = 65535
				},
				ClientConfiguration = new ClientConfiguration
				{
					DefaultSessionTimeout = Math.Max(2000, timeout * 3)
				},
				DisableHiResClock = false
			};
			configuration.Validate(ApplicationType.Client).GetAwaiter().GetResult();
			configuration.CertificateValidator.CertificateValidation += delegate(CertificateValidator sender, CertificateValidationEventArgs args)
			{
				args.Accept = true;
			};
			return configuration;
		}

		// Token: 0x06001F22 RID: 7970 RVA: 0x000B56D8 File Offset: 0x000B38D8
		private static int GetOpcOperationTimeoutMs(CommunicationConnection connection)
		{
			int configured = (connection != null) ? connection.TimeoutMs : 800;
			bool flag = configured <= 0;
			if (flag)
			{
				configured = 800;
			}
			return Math.Max(300, Math.Min(configured, 800));
		}

		// Token: 0x06001F23 RID: 7971 RVA: 0x000B5724 File Offset: 0x000B3924
		private static bool CanReachTcpEndpoint(CommunicationConnection connection, int timeoutMs, out string message)
		{
			message = null;
			string host;
			int port;
			bool flag = !OpcUaCommunicationClient.TryGetEndpointHostPort(connection, out host, out port, out message);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					using (TcpClient client = new TcpClient())
					{
						IAsyncResult asyncResult = client.BeginConnect(host, port, null, null);
						bool completed = asyncResult.AsyncWaitHandle.WaitOne(Math.Max(100, timeoutMs));
						bool flag2 = !completed;
						if (flag2)
						{
							message = string.Concat(new string[]
							{
								"TCP connect timeout ",
								timeoutMs.ToString(),
								" ms to ",
								host,
								":",
								port.ToString(),
								"."
							});
							result = false;
						}
						else
						{
							client.EndConnect(asyncResult);
							result = true;
						}
					}
				}
				catch (Exception ex)
				{
					message = OpcUaCommunicationClient.FormatExceptionMessage(ex);
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001F24 RID: 7972 RVA: 0x000B5818 File Offset: 0x000B3A18
		private static bool TryGetEndpointHostPort(CommunicationConnection connection, out string host, out int port, out string message)
		{
			host = (((connection != null) ? connection.IpAddress : null) ?? string.Empty).Trim();
			port = ((connection != null && connection.Port > 0) ? connection.Port : 4840);
			message = null;
			bool flag = string.IsNullOrWhiteSpace(host);
			if (flag)
			{
				host = "127.0.0.1";
			}
			bool flag2 = host.StartsWith("opc.tcp://", StringComparison.OrdinalIgnoreCase);
			if (flag2)
			{
				Uri uri;
				bool flag3 = !Uri.TryCreate(host, UriKind.Absolute, out uri);
				if (flag3)
				{
					message = "Invalid OPC endpoint URL: " + host;
					return false;
				}
				host = uri.Host;
				bool flag4 = uri.Port > 0;
				if (flag4)
				{
					port = uri.Port;
				}
			}
			return true;
		}

		// Token: 0x06001F25 RID: 7973 RVA: 0x000B58D0 File Offset: 0x000B3AD0
		private static string BuildEndpointUrl(CommunicationConnection connection)
		{
			string host = (((connection != null) ? connection.IpAddress : null) ?? string.Empty).Trim();
			bool flag = string.IsNullOrWhiteSpace(host);
			if (flag)
			{
				host = "127.0.0.1";
			}
			bool flag2 = host.StartsWith("opc.tcp://", StringComparison.OrdinalIgnoreCase);
			string result;
			if (flag2)
			{
				result = host;
			}
			else
			{
				int port = (connection != null && connection.Port > 0) ? connection.Port : 4840;
				result = "opc.tcp://" + host.TrimEnd(new char[]
				{
					'/'
				}) + ":" + port.ToString(CultureInfo.InvariantCulture);
			}
			return result;
		}

		// Token: 0x06001F26 RID: 7974 RVA: 0x000B596C File Offset: 0x000B3B6C
		private static NodeId ParseNodeId(string address)
		{
			bool flag = string.IsNullOrWhiteSpace(address);
			if (flag)
			{
				throw new FormatException("OPC UA node address is empty. Use format like ns=2;s=TagName or ns=2;i=1001.");
			}
			return NodeId.Parse(address.Trim());
		}

		// Token: 0x06001F27 RID: 7975 RVA: 0x000B59A0 File Offset: 0x000B3BA0
		private static OpcUaCommunicationClient.OpcAddress ParseOpcAddress(string address)
		{
			bool flag = string.IsNullOrWhiteSpace(address);
			if (flag)
			{
				throw new FormatException("OPC UA node address is empty. Use format like ns=2;s=TagName or ns=2;i=1001.");
			}
			string text = address.Trim();
			int? elementIndex = null;
			string nodeText = text;
			bool flag2 = text.EndsWith("]", StringComparison.Ordinal);
			if (flag2)
			{
				int bracketStart = text.LastIndexOf('[');
				bool flag3 = bracketStart > 0;
				if (flag3)
				{
					string indexText = text.Substring(bracketStart + 1, text.Length - bracketStart - 2);
					int parsedIndex;
					bool flag4 = int.TryParse(indexText, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsedIndex);
					if (flag4)
					{
						elementIndex = new int?(parsedIndex);
						nodeText = text.Substring(0, bracketStart);
					}
				}
			}
			return new OpcUaCommunicationClient.OpcAddress
			{
				NodeId = OpcUaCommunicationClient.ParseNodeId(nodeText),
				ElementIndex = elementIndex
			};
		}

		// Token: 0x06001F28 RID: 7976 RVA: 0x000B5A60 File Offset: 0x000B3C60
		private static string FormatOpcValue(object value)
		{
			bool flag = value == null;
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				Array array = value as Array;
				bool flag2 = array != null && !(value is byte[]);
				if (flag2)
				{
					result = string.Join(",", from object x in array
					select Convert.ToString(x, CultureInfo.InvariantCulture));
				}
				else
				{
					bool boolValue;
					bool flag3;
					if (value is bool)
					{
						boolValue = (bool)value;
						flag3 = true;
					}
					else
					{
						flag3 = false;
					}
					bool flag4 = flag3;
					if (flag4)
					{
						result = (boolValue ? "ON" : "OFF");
					}
					else
					{
						IFormattable formattable = value as IFormattable;
						bool flag5 = formattable != null;
						if (flag5)
						{
							result = formattable.ToString(null, CultureInfo.InvariantCulture);
						}
						else
						{
							result = value.ToString();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001F29 RID: 7977 RVA: 0x000B5B34 File Offset: 0x000B3D34
		private static object ResolveOpcIndexedValue(object value, int? elementIndex)
		{
			bool flag = elementIndex == null;
			object result;
			if (flag)
			{
				result = value;
			}
			else
			{
				Array array = value as Array;
				bool flag2 = array == null;
				if (flag2)
				{
					throw new FormatException("OPC UA indexed address was used, but the node value is not an array.");
				}
				int index = elementIndex.Value;
				bool flag3 = index < 0 || index >= array.Length;
				if (flag3)
				{
					throw new IndexOutOfRangeException("OPC UA array index is out of range.");
				}
				result = array.GetValue(index);
			}
			return result;
		}

		// Token: 0x06001F2A RID: 7978 RVA: 0x000B5BA8 File Offset: 0x000B3DA8
		private static string ResolveOpcDataType(string configuredDataType, object value)
		{
			bool flag = !string.Equals(configuredDataType, "OPC UA", StringComparison.OrdinalIgnoreCase);
			string result;
			if (flag)
			{
				result = configuredDataType;
			}
			else
			{
				bool flag2 = value == null;
				if (flag2)
				{
					result = "Null";
				}
				else
				{
					Array array = value as Array;
					bool flag3 = array != null && !(value is byte[]);
					if (flag3)
					{
						Type elementType2 = value.GetType().GetElementType();
						string elementType = ((elementType2 != null) ? elementType2.Name : null) ?? "Array";
						result = elementType + "[" + array.Length.ToString(CultureInfo.InvariantCulture) + "]";
					}
					else
					{
						result = value.GetType().Name;
					}
				}
			}
			return result;
		}

		// Token: 0x06001F2B RID: 7979 RVA: 0x000B5C5C File Offset: 0x000B3E5C
		private void BrowseNodeRecursive(NodeId nodeId, string path, int depth, HashSet<string> visited, List<CommunicationTagRow> tags)
		{
			bool flag = nodeId == null || depth > 12 || tags.Count >= 5000;
			if (!flag)
			{
				string nodeKey = nodeId.ToString();
				bool flag2 = !visited.Add(nodeKey);
				if (!flag2)
				{
					byte[] continuationPoint;
					ReferenceDescriptionCollection references;
					this._session.Browse(null, null, nodeId, 0U, BrowseDirection.Forward, ReferenceTypeIds.HierarchicalReferences, true, 3U, out continuationPoint, out references);
					bool flag3 = references == null;
					if (!flag3)
					{
						foreach (ReferenceDescription reference in references)
						{
							bool flag4 = reference == null || reference.NodeId == null;
							if (!flag4)
							{
								NodeId childNodeId = ExpandedNodeId.ToNodeId(reference.NodeId, this._session.NamespaceUris);
								bool flag5 = childNodeId == null;
								if (!flag5)
								{
									QualifiedName browseName2 = reference.BrowseName;
									string browseName = (browseName2 != null) ? browseName2.Name : null;
									LocalizedText displayName2 = reference.DisplayName;
									string displayName = (displayName2 != null) ? displayName2.Text : null;
									string label = string.IsNullOrWhiteSpace(displayName) ? browseName : displayName;
									bool flag6 = string.IsNullOrWhiteSpace(label);
									if (flag6)
									{
										label = childNodeId.ToString();
									}
									bool flag7 = OpcUaCommunicationClient.ShouldSkipOpcBrowseNode(childNodeId, browseName, reference.NodeClass);
									if (!flag7)
									{
										string childPath = string.IsNullOrWhiteSpace(path) ? label : (path + "." + label);
										bool flag8 = reference.NodeClass == NodeClass.Variable && childNodeId.NamespaceIndex > 0;
										if (flag8)
										{
											string tagLabel = OpcUaCommunicationClient.ExtractOpcTagLabel(childNodeId, label);
											tags.Add(new CommunicationTagRow
											{
												Group = OpcUaCommunicationClient.GetParentPath(childPath),
												Name = tagLabel,
												Address = childNodeId.ToString(),
												DataType = "OPC UA",
												ReadWrite = "Read",
												Description = childPath
											});
											bool flag9 = tags.Count >= 5000;
											if (flag9)
											{
												break;
											}
										}
										bool flag10 = reference.NodeClass == NodeClass.Object || reference.NodeClass == NodeClass.Variable;
										if (flag10)
										{
											this.BrowseNodeRecursive(childNodeId, childPath, depth + 1, visited, tags);
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001F2C RID: 7980 RVA: 0x000B5ECC File Offset: 0x000B40CC
		private static bool ShouldSkipOpcBrowseNode(NodeId nodeId, string browseName, NodeClass nodeClass)
		{
			bool flag = nodeId == null;
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = nodeId.NamespaceIndex == 0 && string.Equals(browseName, "Server", StringComparison.OrdinalIgnoreCase);
				result = flag2;
			}
			return result;
		}

		// Token: 0x06001F2D RID: 7981 RVA: 0x000B5F10 File Offset: 0x000B4110
		private static string GetParentPath(string path)
		{
			bool flag = string.IsNullOrWhiteSpace(path);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				int index = path.LastIndexOf('.');
				result = ((index > 0) ? path.Substring(0, index) : string.Empty);
			}
			return result;
		}

		// Token: 0x06001F2E RID: 7982 RVA: 0x000B5F50 File Offset: 0x000B4150
		private static string ExtractOpcTagLabel(NodeId nodeId, string fallback)
		{
			string nodeText = (nodeId != null) ? nodeId.ToString() : null;
			bool flag = !string.IsNullOrWhiteSpace(nodeText);
			if (flag)
			{
				int stringIndex = nodeText.IndexOf(";s=", StringComparison.OrdinalIgnoreCase);
				bool flag2 = stringIndex >= 0 && stringIndex + 3 < nodeText.Length;
				if (flag2)
				{
					return nodeText.Substring(stringIndex + 3);
				}
			}
			return string.IsNullOrWhiteSpace(fallback) ? nodeText : fallback;
		}

		// Token: 0x06001F2F RID: 7983 RVA: 0x000B5FBC File Offset: 0x000B41BC
		private static object ConvertOpcWriteValue(string value, string dataType)
		{
			string text = (value ?? string.Empty).Trim();
			string normalizedType = (dataType ?? string.Empty).Trim().ToUpperInvariant();
			string text2 = normalizedType;
			string text3 = text2;
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text3);
			if (num > 2286151596U)
			{
				if (num <= 2991499325U)
				{
					if (num != 2316881829U)
					{
						if (num != 2991499325U)
						{
							goto IL_267;
						}
						if (!(text3 == "BOOL"))
						{
							goto IL_267;
						}
						return string.Equals(text, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "TRUE", StringComparison.OrdinalIgnoreCase) || text == "1";
					}
					else if (!(text3 == "FLOAT"))
					{
						goto IL_267;
					}
				}
				else if (num != 3560013981U)
				{
					if (num != 3751281736U)
					{
						if (num != 4127814520U)
						{
							goto IL_267;
						}
						if (!(text3 == "STRING"))
						{
							goto IL_267;
						}
						return text;
					}
					else
					{
						if (!(text3 == "DOUBLE"))
						{
							goto IL_267;
						}
						return double.Parse(text, CultureInfo.InvariantCulture);
					}
				}
				else if (!(text3 == "REAL"))
				{
					goto IL_267;
				}
				return float.Parse(text, CultureInfo.InvariantCulture);
			}
			if (num > 268302705U)
			{
				if (num != 843930396U)
				{
					if (num != 2214109151U)
					{
						if (num != 2286151596U)
						{
							goto IL_267;
						}
						if (!(text3 == "UINT32"))
						{
							goto IL_267;
						}
						return uint.Parse(text, CultureInfo.InvariantCulture);
					}
					else if (!(text3 == "INT32"))
					{
						goto IL_267;
					}
				}
				else if (!(text3 == "DINT"))
				{
					goto IL_267;
				}
				return int.Parse(text, CultureInfo.InvariantCulture);
			}
			if (num != 71211698U)
			{
				if (num == 268302705U)
				{
					if (text3 == "INT16")
					{
						return short.Parse(text, CultureInfo.InvariantCulture);
					}
				}
			}
			else if (text3 == "UINT16")
			{
				return ushort.Parse(text, CultureInfo.InvariantCulture);
			}
			IL_267:
			return text;
		}

		// Token: 0x06001F30 RID: 7984 RVA: 0x000B6238 File Offset: 0x000B4438
		private object CreateOpcIndexedArrayWriteValue(NodeId nodeId, int elementIndex, string dataType, string value)
		{
			object currentValue = this.ReadOpcNodeValue(nodeId);
			Array array = currentValue as Array;
			bool flag = array == null;
			if (flag)
			{
				throw new FormatException("OPC UA indexed write was used, but the node value is not an array.");
			}
			bool flag2 = elementIndex < 0 || elementIndex >= array.Length;
			if (flag2)
			{
				throw new IndexOutOfRangeException("OPC UA array index is out of range.");
			}
			Type elementType = array.GetType().GetElementType() ?? typeof(object);
			Array copy = Array.CreateInstance(elementType, array.Length);
			Array.Copy(array, copy, array.Length);
			copy.SetValue(OpcUaCommunicationClient.ConvertOpcWriteValueToType(value, dataType, elementType), elementIndex);
			return copy;
		}

		// Token: 0x06001F31 RID: 7985 RVA: 0x000B62DC File Offset: 0x000B44DC
		private object ReadOpcNodeValue(NodeId nodeId)
		{
			ReadValueId valueId = new ReadValueId
			{
				NodeId = nodeId,
				AttributeId = 13U
			};
			ReadValueIdCollection nodesToRead = new ReadValueIdCollection
			{
				valueId
			};
			DataValueCollection results;
			DiagnosticInfoCollection diagnosticInfos;
			this._session.Read(OpcUaCommunicationClient.CreateRequestHeader(null), 0.0, TimestampsToReturn.Neither, nodesToRead, out results, out diagnosticInfos);
			ClientBase.ValidateResponse<ReadValueId, DataValue>(results, nodesToRead);
			ClientBase.ValidateDiagnosticInfos<ReadValueId>(diagnosticInfos, nodesToRead);
			DataValue dataValue = results.FirstOrDefault<DataValue>();
			bool flag = dataValue == null;
			if (flag)
			{
				throw new InvalidOperationException("OPC UA read returned no value.");
			}
			bool flag2 = StatusCode.IsBad(dataValue.StatusCode);
			if (flag2)
			{
				throw new InvalidOperationException("OPC UA read failed: " + dataValue.StatusCode.ToString());
			}
			return dataValue.Value;
		}

		// Token: 0x06001F32 RID: 7986 RVA: 0x000B63A4 File Offset: 0x000B45A4
		private static RequestHeader CreateRequestHeader(CommunicationConnection connection)
		{
			int timeoutMs = Math.Max(300, Math.Min((connection != null) ? connection.TimeoutMs : 1000, 2000));
			return new RequestHeader
			{
				TimeoutHint = (uint)timeoutMs
			};
		}

		// Token: 0x06001F33 RID: 7987 RVA: 0x000B63E8 File Offset: 0x000B45E8
		private static object ConvertOpcWriteValueToType(string value, string dataType, Type targetType)
		{
			bool flag = targetType == null || targetType == typeof(object);
			object result;
			if (flag)
			{
				result = OpcUaCommunicationClient.ConvertOpcWriteValue(value, dataType);
			}
			else
			{
				string text = (value ?? string.Empty).Trim();
				bool flag2 = targetType == typeof(bool);
				if (flag2)
				{
					result = (string.Equals(text, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "TRUE", StringComparison.OrdinalIgnoreCase) || text == "1");
				}
				else
				{
					bool flag3 = targetType == typeof(string);
					if (flag3)
					{
						result = text;
					}
					else
					{
						result = Convert.ChangeType(text, targetType, CultureInfo.InvariantCulture);
					}
				}
			}
			return result;
		}

		// Token: 0x06001F34 RID: 7988 RVA: 0x000B64A4 File Offset: 0x000B46A4
		private void DisposeSession()
		{
			try
			{
				bool flag = this._session != null;
				if (flag)
				{
					this._session.KeepAlive -= this.OpcSession_KeepAlive;
					this._session.Close();
					this._session.Dispose();
				}
			}
			catch
			{
			}
			finally
			{
				this._session = null;
				this._keepAliveHealthy = true;
				this._lastKeepAliveStatus = null;
				this._lastKeepAliveUtc = DateTime.MinValue;
			}
		}

		// Token: 0x06001F35 RID: 7989 RVA: 0x000B653C File Offset: 0x000B473C
		private static string FormatExceptionMessage(Exception exception)
		{
			bool flag = exception == null;
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				List<string> messages = new List<string>();
				for (Exception current = exception; current != null; current = current.InnerException)
				{
					bool flag2 = !string.IsNullOrWhiteSpace(current.Message) && !messages.Contains(current.Message);
					if (flag2)
					{
						messages.Add(current.Message);
					}
				}
				result = string.Join(" | ", messages);
			}
			return result;
		}

		// Token: 0x04000CF2 RID: 3314
		private const int MaxBrowseDepth = 12;

		// Token: 0x04000CF3 RID: 3315
		private const int MaxBrowseNodeCount = 5000;

		// Token: 0x04000CF4 RID: 3316
		private readonly object _sync = new object();

		// Token: 0x04000CF5 RID: 3317
		private Session _session;

		// Token: 0x04000CF6 RID: 3318
		private ApplicationConfiguration _configuration;

		// Token: 0x04000CF7 RID: 3319
		private string _endpointUrl;

		// Token: 0x04000CF8 RID: 3320
		private bool _keepAliveHealthy = true;

		// Token: 0x04000CF9 RID: 3321
		private string _lastKeepAliveStatus;

		// Token: 0x04000CFA RID: 3322
		private DateTime _lastKeepAliveUtc = DateTime.MinValue;

		// Token: 0x04000CFB RID: 3323
		private int _keepAliveIntervalMs = 1000;

		// Token: 0x04000CFC RID: 3324
		private int _keepAliveTimeoutMs = 3000;

		// Token: 0x02000477 RID: 1143
		private sealed class OpcAddress
		{
			// Token: 0x17000B8C RID: 2956
			// (get) Token: 0x06002C4C RID: 11340 RVA: 0x000EAF88 File Offset: 0x000E9188
			// (set) Token: 0x06002C4D RID: 11341 RVA: 0x000EAF90 File Offset: 0x000E9190
			public NodeId NodeId { get; set; }

			// Token: 0x17000B8D RID: 2957
			// (get) Token: 0x06002C4E RID: 11342 RVA: 0x000EAF99 File Offset: 0x000E9199
			// (set) Token: 0x06002C4F RID: 11343 RVA: 0x000EAFA1 File Offset: 0x000E91A1
			public int? ElementIndex { get; set; }
		}
	}
}
