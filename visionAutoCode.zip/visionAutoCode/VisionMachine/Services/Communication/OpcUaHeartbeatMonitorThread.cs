﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200020A RID: 522
	internal static class OpcUaHeartbeatMonitorThread
	{
		// Token: 0x06001E72 RID: 7794 RVA: 0x000AFEE4 File Offset: 0x000AE0E4
		internal static void Run(string configPath, CancellationToken cancellationToken)
		{
			PlcCommunicationService communicationService = SharedCommunicationService.Instance;
			while (!cancellationToken.IsCancellationRequested)
			{
				try
				{
					CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(configPath);
					IEnumerable<CommunicationConnection> connections = config.Connections;
					foreach (CommunicationConnection connection in (connections ?? Enumerable.Empty<CommunicationConnection>()).Where(new Func<CommunicationConnection, bool>(OpcUaHeartbeatMonitorThread.IsMonitorCandidate)))
					{
						cancellationToken.ThrowIfCancellationRequested();
						CommunicationHeartbeatMonitorHelper.NormalizeConnection(connection);
						CommunicationTagRow heartbeatTag = CommunicationHeartbeatMonitorHelper.FindHeartbeatTag(CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name));
						bool isMxComponent = CommunicationHeartbeatMonitorHelper.IsMxComponentProtocol(connection.Protocol);
						string protocolLabel = isMxComponent ? "MX Component" : "OPC UA";
						bool flag = !communicationService.IsConnected(connection);
						if (flag)
						{
							OpcUaHeartbeatMonitorThread.ReconnectUntilSuccess(communicationService, connection, configPath, protocolLabel + " connection is not alive.", cancellationToken);
						}
						else
						{
							bool flag2 = heartbeatTag == null;
							if (flag2)
							{
								bool flag3 = !isMxComponent;
								if (!flag3)
								{
									CommunicationHeartbeatCheckResult probeResult = CommunicationHeartbeatMonitorHelper.CheckMxComponentTransportProbe(communicationService, connection);
									bool flag4 = !probeResult.Success;
									if (flag4)
									{
										CommunicationStartupService.ReportConnectionHealth(connection, false, probeResult.Message, true, false, false, false);
										OpcUaHeartbeatMonitorThread.ReconnectUntilSuccess(communicationService, connection, configPath, probeResult.Message, cancellationToken);
									}
									else
									{
										CommunicationStartupService.ReportConnectionHealth(connection, true, probeResult.Message, false, false, false, false);
									}
								}
							}
							else
							{
								CommunicationHeartbeatCheckResult heartbeatResult = CommunicationHeartbeatMonitorHelper.CheckHeartbeat(communicationService, connection, heartbeatTag, configPath, protocolLabel);
								bool flag5 = !heartbeatResult.Success;
								if (flag5)
								{
									CommunicationStartupService.ReportConnectionHealth(connection, false, heartbeatResult.Message, true, false, heartbeatResult.HasHeartbeatValue, heartbeatResult.HeartbeatValue);
									OpcUaHeartbeatMonitorThread.ReconnectUntilSuccess(communicationService, connection, configPath, heartbeatResult.Message, cancellationToken);
								}
								else
								{
									CommunicationStartupService.ReportConnectionHealth(connection, true, heartbeatResult.Message, true, true, heartbeatResult.HasHeartbeatValue, heartbeatResult.HeartbeatValue);
								}
							}
						}
					}
				}
				catch (OperationCanceledException)
				{
					break;
				}
				catch
				{
				}
				try
				{
					Task.Delay(200, cancellationToken).Wait(cancellationToken);
				}
				catch (OperationCanceledException)
				{
					break;
				}
			}
		}

		// Token: 0x06001E73 RID: 7795 RVA: 0x000B0154 File Offset: 0x000AE354
		private static bool ReconnectUntilSuccess(PlcCommunicationService communicationService, CommunicationConnection connection, string configPath, string reason, CancellationToken cancellationToken)
		{
			bool flag = communicationService == null || connection == null || cancellationToken.IsCancellationRequested;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				CommunicationHeartbeatMonitorHelper.NormalizeConnection(connection);
				CommunicationConnection monitorConnection = CommunicationHeartbeatMonitorHelper.CreateHealthMonitorConnection(connection);
				string protocolLabel = CommunicationHeartbeatMonitorHelper.IsMxComponentProtocol(connection.Protocol) ? "MX Component" : "OPC UA";
				try
				{
					communicationService.Disconnect(monitorConnection);
				}
				catch
				{
				}
				int attempt = 0;
				while (!cancellationToken.IsCancellationRequested)
				{
					attempt++;
					CommunicationStartupService.ReportConnectionHealth(connection, false, string.Concat(new string[]
					{
						reason,
						" Reconnecting ",
						protocolLabel,
						", attempt ",
						attempt.ToString(),
						"..."
					}), true, false, false, false);
					CommunicationOperationResult reconnectResult = communicationService.Connect(monitorConnection);
					bool success = reconnectResult.Success;
					if (success)
					{
						CommunicationStartupService.ReportConnectionHealth(connection, false, protocolLabel + " reconnected. Validating connection health.", true, false, false, false);
						return true;
					}
					CommunicationStartupService.ReportConnectionHealth(connection, false, string.Concat(new string[]
					{
						protocolLabel,
						" reconnect failed, attempt ",
						attempt.ToString(),
						": ",
						reconnectResult.Message
					}), true, false, false, false);
					try
					{
						Task.Delay(200, cancellationToken).Wait(cancellationToken);
					}
					catch (OperationCanceledException)
					{
						return false;
					}
				}
				result = false;
			}
			return result;
		}

		// Token: 0x06001E74 RID: 7796 RVA: 0x000B02D0 File Offset: 0x000AE4D0
		private static bool IsMonitorCandidate(CommunicationConnection connection)
		{
			return CommunicationHeartbeatMonitorHelper.IsAutoReconnectCandidate(connection) && (CommunicationHeartbeatMonitorHelper.IsOpcUaProtocol(connection.Protocol) || CommunicationHeartbeatMonitorHelper.IsMxComponentProtocol(connection.Protocol));
		}
	}
}
