﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000217 RID: 535
	internal sealed class OpcUaProtocolProvider : CommunicationProtocolProviderBase
	{
		// Token: 0x06001EAF RID: 7855 RVA: 0x000B1820 File Offset: 0x000AFA20
		public OpcUaProtocolProvider() : base(new string[]
		{
			"OPC UA"
		})
		{
		}

		// Token: 0x06001EB0 RID: 7856 RVA: 0x000B1838 File Offset: 0x000AFA38
		public override IPlcCommunicationClient CreateClient()
		{
			return new OpcUaCommunicationClient();
		}
	}
}
