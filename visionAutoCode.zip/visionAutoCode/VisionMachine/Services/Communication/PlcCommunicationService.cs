﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200020B RID: 523
	public class PlcCommunicationService : IDisposable
	{
		// Token: 0x06001E75 RID: 7797 RVA: 0x000B0308 File Offset: 0x000AE508
		public CommunicationOperationResult Connect(CommunicationConnection connection)
		{
			bool flag = connection == null;
			CommunicationOperationResult result2;
			if (flag)
			{
				result2 = CommunicationOperationResult.Fail("No connection selected.", 0, 0);
			}
			else
			{
				string runtimeKey = CommunicationConnectionRuntime.MakeKey(connection);
				object runtimesLock = this._runtimesLock;
				List<CommunicationConnectionRuntime> staleRuntimes;
				lock (runtimesLock)
				{
					staleRuntimes = this.RemoveAllForConnectionNameCore(connection.Name);
				}
				PlcCommunicationService.DisposeRuntimes(staleRuntimes);
				IPlcCommunicationClient client = CommunicationProtocolRegistry.CreateClient(connection);
				CommunicationOperationResult result = client.Connect(connection);
				bool flag3 = !result.Success;
				if (flag3)
				{
					client.Dispose();
					result2 = result;
				}
				else
				{
					object runtimesLock2 = this._runtimesLock;
					List<CommunicationConnectionRuntime> replacedRuntimes;
					lock (runtimesLock2)
					{
						replacedRuntimes = this.RemoveAllForConnectionNameCore(connection.Name);
						this._runtimes[runtimeKey] = new CommunicationConnectionRuntime(connection, client);
					}
					PlcCommunicationService.DisposeRuntimes(replacedRuntimes);
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x06001E76 RID: 7798 RVA: 0x000B0410 File Offset: 0x000AE610
		public CommunicationOperationResult ConnectIfDisconnected(CommunicationConnection connection)
		{
			bool flag = connection == null;
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("No connection selected.", 0, 0);
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				lock (runtimesLock)
				{
					bool flag3 = this.IsConnectedCore(CommunicationConnectionRuntime.MakeKey(connection));
					if (flag3)
					{
						return CommunicationOperationResult.Ok("Already connected.", 0, 0);
					}
				}
				result = this.Connect(connection);
			}
			return result;
		}

		// Token: 0x06001E77 RID: 7799 RVA: 0x000B0494 File Offset: 0x000AE694
		public bool IsConnected(CommunicationConnection connection)
		{
			bool flag = connection == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				lock (runtimesLock)
				{
					result = this.IsConnectedCore(CommunicationConnectionRuntime.MakeKey(connection));
				}
			}
			return result;
		}

		// Token: 0x06001E78 RID: 7800 RVA: 0x000B04EC File Offset: 0x000AE6EC
		public bool IsConnected(string connectionName)
		{
			object runtimesLock = this._runtimesLock;
			bool result;
			lock (runtimesLock)
			{
				result = this.IsConnectedCore(connectionName);
			}
			return result;
		}

		// Token: 0x06001E79 RID: 7801 RVA: 0x000B0534 File Offset: 0x000AE734
		public CommunicationOperationResult Disconnect(CommunicationConnection connection)
		{
			bool flag = connection == null;
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("No connection selected.", 0, 0);
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				List<CommunicationConnectionRuntime> removedRuntimes;
				lock (runtimesLock)
				{
					removedRuntimes = this.RemoveAllForConnectionNameCore(connection.Name);
				}
				bool flag3 = removedRuntimes.Count == 0;
				if (flag3)
				{
					result = CommunicationOperationResult.Ok("Already disconnected.", 0, 0);
				}
				else
				{
					PlcCommunicationService.DisposeRuntimes(removedRuntimes);
					result = CommunicationOperationResult.Ok("Disconnected.", 0, 0);
				}
			}
			return result;
		}

		// Token: 0x06001E7A RID: 7802 RVA: 0x000B05CC File Offset: 0x000AE7CC
		public CommunicationOperationResult Test(CommunicationConnection connection)
		{
			bool flag = connection == null;
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("No connection selected.", 0, 0);
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				lock (runtimesLock)
				{
					string key = CommunicationConnectionRuntime.MakeKey(connection);
					CommunicationConnectionRuntime currentRuntime;
					bool flag3 = this._runtimes.TryGetValue(key, out currentRuntime);
					if (flag3)
					{
						return currentRuntime.Client.Test(connection);
					}
				}
				using (IPlcCommunicationClient client = CommunicationProtocolRegistry.CreateClient(connection))
				{
					CommunicationOperationResult connectResult = client.Connect(connection);
					bool flag4 = !connectResult.Success;
					if (flag4)
					{
						result = connectResult;
					}
					else
					{
						CommunicationOperationResult testResult = client.Test(connection);
						result = (testResult.Success ? testResult : connectResult);
					}
				}
			}
			return result;
		}

		// Token: 0x06001E7B RID: 7803 RVA: 0x000B06B0 File Offset: 0x000AE8B0
		public CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			bool flag = connection == null;
			CommunicationReadResult result;
			if (flag)
			{
				result = CommunicationReadResult.Fail("No connection selected.");
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				CommunicationConnectionRuntime runtime;
				lock (runtimesLock)
				{
					bool flag3 = !this.TryGetRuntimeCore(connection, out runtime);
					if (flag3)
					{
						return CommunicationReadResult.Fail("Connection is not connected.");
					}
				}
				object ioLock;
				string lockError;
				bool flag4 = !PlcCommunicationService.TryEnterIoLock(runtime, connection, out ioLock, out lockError);
				if (flag4)
				{
					result = CommunicationReadResult.Fail(lockError);
				}
				else
				{
					try
					{
						result = this.ReadAllCore(connection, runtime, tags ?? Enumerable.Empty<CommunicationTagRow>());
					}
					finally
					{
						Monitor.Exit(ioLock);
					}
				}
			}
			return result;
		}

		// Token: 0x06001E7C RID: 7804 RVA: 0x000B077C File Offset: 0x000AE97C
		private CommunicationReadResult ReadAllCore(CommunicationConnection connection, CommunicationConnectionRuntime runtime, IEnumerable<CommunicationTagRow> tags)
		{
			CommunicationReadResult result = runtime.Client.ReadAll(connection, tags ?? Enumerable.Empty<CommunicationTagRow>());
			bool flag = !result.Success && PlcCommunicationService.IsRecoverableTransportFailure(result.Message);
			if (flag)
			{
				object runtimesLock = this._runtimesLock;
				CommunicationConnectionRuntime removedRuntime;
				lock (runtimesLock)
				{
					removedRuntime = this.RemoveRuntimeCore(runtime.Key);
				}
				PlcCommunicationService.DisposeRuntime(removedRuntime);
			}
			return result;
		}

		// Token: 0x06001E7D RID: 7805 RVA: 0x000B080C File Offset: 0x000AEA0C
		public CommunicationReadResult ReadRange(CommunicationConnection connection, string startAddress, string endAddress, string dataType, string functionCode)
		{
			bool flag = connection == null;
			CommunicationReadResult result2;
			if (flag)
			{
				result2 = CommunicationReadResult.Fail("No connection selected.");
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				CommunicationConnectionRuntime runtime;
				lock (runtimesLock)
				{
					bool flag3 = !this.TryGetRuntimeCore(connection, out runtime);
					if (flag3)
					{
						return CommunicationReadResult.Fail("Connection is not connected.");
					}
				}
				IModbusRangeReader modbusClient = runtime.Client as IModbusRangeReader;
				bool flag4 = modbusClient == null;
				if (flag4)
				{
					result2 = CommunicationReadResult.Fail("Read range is supported for Modbus Client TCP/IP only.");
				}
				else
				{
					object ioLock;
					string lockError;
					bool flag5 = !PlcCommunicationService.TryEnterIoLock(runtime, connection, out ioLock, out lockError);
					if (flag5)
					{
						result2 = CommunicationReadResult.Fail(lockError);
					}
					else
					{
						try
						{
							CommunicationReadResult result = modbusClient.ReadRange(startAddress, endAddress, dataType, functionCode);
							bool flag6 = !result.Success && PlcCommunicationService.IsRecoverableTransportFailure(result.Message);
							if (flag6)
							{
								object runtimesLock2 = this._runtimesLock;
								CommunicationConnectionRuntime removedRuntime;
								lock (runtimesLock2)
								{
									removedRuntime = this.RemoveRuntimeCore(runtime.Key);
								}
								PlcCommunicationService.DisposeRuntime(removedRuntime);
							}
							result2 = result;
						}
						finally
						{
							Monitor.Exit(ioLock);
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06001E7E RID: 7806 RVA: 0x000B096C File Offset: 0x000AEB6C
		public CommunicationReadResult BrowseOpcTags(CommunicationConnection connection)
		{
			bool flag = connection == null;
			CommunicationReadResult result;
			if (flag)
			{
				result = CommunicationReadResult.Fail("No connection selected.");
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				CommunicationConnectionRuntime runtime;
				lock (runtimesLock)
				{
					bool flag3 = !this.TryGetRuntimeCore(connection, out runtime);
					if (flag3)
					{
						return CommunicationReadResult.Fail("Connection is not connected.");
					}
				}
				IOpcTagBrowser opcClient = runtime.Client as IOpcTagBrowser;
				bool flag4 = opcClient == null;
				if (flag4)
				{
					result = CommunicationReadResult.Fail("Browse OPC tags is supported for OPC UA only.");
				}
				else
				{
					object ioLock;
					string lockError;
					bool flag5 = !PlcCommunicationService.TryEnterIoLock(runtime, connection, out ioLock, out lockError);
					if (flag5)
					{
						result = CommunicationReadResult.Fail(lockError);
					}
					else
					{
						try
						{
							result = opcClient.BrowseTags(connection);
						}
						finally
						{
							Monitor.Exit(ioLock);
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001E7F RID: 7807 RVA: 0x000B0A54 File Offset: 0x000AEC54
		public CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			bool flag = connection == null;
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("No connection selected.", 0, 0);
			}
			else
			{
				CommunicationOperationResult firstResult = this.WriteOnce(connection, address, dataType, value);
				bool flag2 = firstResult.Success || !PlcCommunicationService.IsRecoverableTransportFailure(firstResult.Message);
				if (flag2)
				{
					result = firstResult;
				}
				else
				{
					this.Disconnect(connection);
					CommunicationOperationResult reconnectResult = this.Connect(connection);
					bool flag3 = !reconnectResult.Success;
					if (flag3)
					{
						result = CommunicationOperationResult.Fail(firstResult.Message + " Reconnect failed: " + reconnectResult.Message, firstResult.SentBytes, firstResult.ReceivedBytes);
					}
					else
					{
						CommunicationOperationResult retryResult = this.WriteOnce(connection, address, dataType, value);
						bool flag4 = !retryResult.Success;
						if (flag4)
						{
							result = CommunicationOperationResult.Fail(firstResult.Message + " Retry after reconnect failed: " + retryResult.Message, firstResult.SentBytes + retryResult.SentBytes, firstResult.ReceivedBytes + retryResult.ReceivedBytes);
						}
						else
						{
							CommunicationOperationResult communicationOperationResult = retryResult;
							communicationOperationResult.Message += " Reconnected and retried once.";
							retryResult.SentBytes += firstResult.SentBytes;
							retryResult.ReceivedBytes += firstResult.ReceivedBytes;
							result = retryResult;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001E80 RID: 7808 RVA: 0x000B0B9C File Offset: 0x000AED9C
		public CommunicationOperationResult WriteRegisters(CommunicationConnection connection, string address, ushort[] values)
		{
			bool flag = connection == null;
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("No connection selected.", 0, 0);
			}
			else
			{
				CommunicationOperationResult firstResult = this.WriteRegistersOnce(connection, address, values);
				bool flag2 = firstResult.Success || !PlcCommunicationService.IsRecoverableTransportFailure(firstResult.Message);
				if (flag2)
				{
					result = firstResult;
				}
				else
				{
					this.Disconnect(connection);
					CommunicationOperationResult reconnectResult = this.Connect(connection);
					bool flag3 = !reconnectResult.Success;
					if (flag3)
					{
						result = CommunicationOperationResult.Fail(firstResult.Message + " Reconnect failed: " + reconnectResult.Message, firstResult.SentBytes, firstResult.ReceivedBytes);
					}
					else
					{
						CommunicationOperationResult retryResult = this.WriteRegistersOnce(connection, address, values);
						bool flag4 = !retryResult.Success;
						if (flag4)
						{
							result = CommunicationOperationResult.Fail(firstResult.Message + " Retry after reconnect failed: " + retryResult.Message, firstResult.SentBytes + retryResult.SentBytes, firstResult.ReceivedBytes + retryResult.ReceivedBytes);
						}
						else
						{
							CommunicationOperationResult communicationOperationResult = retryResult;
							communicationOperationResult.Message += " Reconnected and retried once.";
							retryResult.SentBytes += firstResult.SentBytes;
							retryResult.ReceivedBytes += firstResult.ReceivedBytes;
							result = retryResult;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001E81 RID: 7809 RVA: 0x000B0CE0 File Offset: 0x000AEEE0
		public CommunicationOperationResult WriteOpcArray(CommunicationConnection connection, string address, string dataType, IReadOnlyList<string> values)
		{
			bool flag = connection == null;
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("No connection selected.", 0, 0);
			}
			else
			{
				CommunicationOperationResult firstResult = this.WriteOpcArrayOnce(connection, address, dataType, values);
				bool flag2 = firstResult.Success || !PlcCommunicationService.IsRecoverableTransportFailure(firstResult.Message);
				if (flag2)
				{
					result = firstResult;
				}
				else
				{
					this.Disconnect(connection);
					CommunicationOperationResult reconnectResult = this.Connect(connection);
					bool flag3 = !reconnectResult.Success;
					if (flag3)
					{
						result = CommunicationOperationResult.Fail(firstResult.Message + " Reconnect failed: " + reconnectResult.Message, 0, 0);
					}
					else
					{
						CommunicationOperationResult retryResult = this.WriteOpcArrayOnce(connection, address, dataType, values);
						bool flag4 = !retryResult.Success;
						if (flag4)
						{
							result = CommunicationOperationResult.Fail(firstResult.Message + " Retry after reconnect failed: " + retryResult.Message, 0, 0);
						}
						else
						{
							CommunicationOperationResult communicationOperationResult = retryResult;
							communicationOperationResult.Message += " Reconnected and retried once.";
							result = retryResult;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001E82 RID: 7810 RVA: 0x000B0DDC File Offset: 0x000AEFDC
		private CommunicationOperationResult WriteOpcArrayOnce(CommunicationConnection connection, string address, string dataType, IReadOnlyList<string> values)
		{
			bool flag = values == null || values.Count == 0;
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("No OPC array values to write.", 0, 0);
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				CommunicationConnectionRuntime runtime;
				lock (runtimesLock)
				{
					bool flag3 = !this.TryGetRuntimeCore(connection, out runtime);
					if (flag3)
					{
						return CommunicationOperationResult.Fail("Connection is not connected.", 0, 0);
					}
				}
				IOpcArrayWriter opcClient = runtime.Client as IOpcArrayWriter;
				bool flag4 = opcClient == null;
				if (flag4)
				{
					result = CommunicationOperationResult.Fail("Array write is supported for OPC UA only.", 0, 0);
				}
				else
				{
					object ioLock;
					string lockError;
					bool flag5 = !PlcCommunicationService.TryEnterIoLock(runtime, connection, out ioLock, out lockError);
					if (flag5)
					{
						result = CommunicationOperationResult.Fail(lockError, 0, 0);
					}
					else
					{
						try
						{
							result = opcClient.WriteArray(address, dataType, values);
						}
						finally
						{
							Monitor.Exit(ioLock);
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001E83 RID: 7811 RVA: 0x000B0EDC File Offset: 0x000AF0DC
		private CommunicationOperationResult WriteOnce(CommunicationConnection connection, string address, string dataType, string value)
		{
			object runtimesLock = this._runtimesLock;
			CommunicationConnectionRuntime runtime;
			lock (runtimesLock)
			{
				bool flag2 = !this.TryGetRuntimeCore(connection, out runtime);
				if (flag2)
				{
					return CommunicationOperationResult.Fail("Connection is not connected.", 0, 0);
				}
			}
			object ioLock;
			string lockError;
			bool flag3 = !PlcCommunicationService.TryEnterIoLock(runtime, connection, out ioLock, out lockError);
			CommunicationOperationResult result;
			if (flag3)
			{
				result = CommunicationOperationResult.Fail(lockError, 0, 0);
			}
			else
			{
				try
				{
					result = runtime.Client.Write(connection, address, dataType, value);
				}
				finally
				{
					Monitor.Exit(ioLock);
				}
			}
			return result;
		}

		// Token: 0x06001E84 RID: 7812 RVA: 0x000B0F90 File Offset: 0x000AF190
		private CommunicationOperationResult WriteRegistersOnce(CommunicationConnection connection, string address, ushort[] values)
		{
			bool flag = values == null || values.Length == 0;
			CommunicationOperationResult result;
			if (flag)
			{
				result = CommunicationOperationResult.Fail("No register values to write.", 0, 0);
			}
			else
			{
				object runtimesLock = this._runtimesLock;
				CommunicationConnectionRuntime runtime;
				lock (runtimesLock)
				{
					bool flag3 = !this.TryGetRuntimeCore(connection, out runtime);
					if (flag3)
					{
						return CommunicationOperationResult.Fail("Connection is not connected.", 0, 0);
					}
				}
				IModbusRegisterArrayWriter modbusClient = runtime.Client as IModbusRegisterArrayWriter;
				bool flag4 = modbusClient == null;
				if (flag4)
				{
					result = CommunicationOperationResult.Fail("Register array write is supported for Modbus Client TCP/IP only.", 0, 0);
				}
				else
				{
					object ioLock;
					string lockError;
					bool flag5 = !PlcCommunicationService.TryEnterIoLock(runtime, connection, out ioLock, out lockError);
					if (flag5)
					{
						result = CommunicationOperationResult.Fail(lockError, 0, 0);
					}
					else
					{
						try
						{
							result = modbusClient.WriteRegisters(address, values);
						}
						finally
						{
							Monitor.Exit(ioLock);
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001E85 RID: 7813 RVA: 0x000B1088 File Offset: 0x000AF288
		private static bool TryEnterIoLock(CommunicationConnectionRuntime runtime, CommunicationConnection connection, out object ioLock, out string message)
		{
			ioLock = ((runtime != null) ? runtime.IoLock : null);
			bool flag = ioLock == null;
			bool result;
			if (flag)
			{
				message = "Connection runtime is not available.";
				result = false;
			}
			else
			{
				int timeoutMs = Math.Max(200, Math.Min((connection != null) ? connection.TimeoutMs : 1000, 1000));
				bool flag2 = Monitor.TryEnter(ioLock, timeoutMs);
				if (flag2)
				{
					message = null;
					result = true;
				}
				else
				{
					message = "PLC I/O is busy. Another read/write is holding the shared connection longer than " + timeoutMs.ToString() + " ms.";
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001E86 RID: 7814 RVA: 0x000B1110 File Offset: 0x000AF310
		internal static bool IsRecoverableTransportFailure(string message)
		{
			bool flag = string.IsNullOrWhiteSpace(message);
			return !flag && (message.IndexOf("transport connection", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("unable to read data", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("unable to write data", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("connection timeout", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("timed out", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("forcibly closed", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("aborted", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("connection reset", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("Connection closed by remote device", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("stream is not connected", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("TCP socket is not connected", StringComparison.OrdinalIgnoreCase) >= 0 || message.IndexOf("Connection is not connected", StringComparison.OrdinalIgnoreCase) >= 0);
		}

		// Token: 0x06001E87 RID: 7815 RVA: 0x000B11F8 File Offset: 0x000AF3F8
		public void Dispose()
		{
			object runtimesLock = this._runtimesLock;
			List<CommunicationConnectionRuntime> runtimes;
			lock (runtimesLock)
			{
				runtimes = this._runtimes.Values.ToList<CommunicationConnectionRuntime>();
				this._runtimes.Clear();
			}
			PlcCommunicationService.DisposeRuntimes(runtimes);
		}

		// Token: 0x06001E88 RID: 7816 RVA: 0x000B125C File Offset: 0x000AF45C
		private bool IsConnectedCore(string keyOrConnectionName)
		{
			bool flag = string.IsNullOrWhiteSpace(keyOrConnectionName);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				CommunicationConnectionRuntime runtime;
				bool flag2 = this._runtimes.TryGetValue(keyOrConnectionName, out runtime);
				if (flag2)
				{
					result = runtime.IsConnected;
				}
				else
				{
					result = this._runtimes.Values.Any((CommunicationConnectionRuntime x) => string.Equals(x.ConnectionName, keyOrConnectionName, StringComparison.OrdinalIgnoreCase) && x.IsConnected);
				}
			}
			return result;
		}

		// Token: 0x06001E89 RID: 7817 RVA: 0x000B12CC File Offset: 0x000AF4CC
		private bool TryGetRuntimeCore(CommunicationConnection connection, out CommunicationConnectionRuntime runtime)
		{
			runtime = null;
			bool flag = connection == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string key = CommunicationConnectionRuntime.MakeKey(connection);
				bool flag2 = !this._runtimes.TryGetValue(key, out runtime);
				result = (!flag2 && runtime != null && runtime.IsConnected);
			}
			return result;
		}

		// Token: 0x06001E8A RID: 7818 RVA: 0x000B131C File Offset: 0x000AF51C
		private CommunicationConnectionRuntime RemoveRuntimeCore(string runtimeKey)
		{
			CommunicationConnectionRuntime runtime;
			bool flag = string.IsNullOrWhiteSpace(runtimeKey) || !this._runtimes.TryGetValue(runtimeKey, out runtime);
			CommunicationConnectionRuntime result;
			if (flag)
			{
				result = null;
			}
			else
			{
				this._runtimes.Remove(runtimeKey);
				result = runtime;
			}
			return result;
		}

		// Token: 0x06001E8B RID: 7819 RVA: 0x000B1364 File Offset: 0x000AF564
		private List<CommunicationConnectionRuntime> RemoveAllForConnectionNameCore(string connectionName)
		{
			List<CommunicationConnectionRuntime> runtimes = new List<CommunicationConnectionRuntime>();
			bool flag = string.IsNullOrWhiteSpace(connectionName);
			List<CommunicationConnectionRuntime> result;
			if (flag)
			{
				result = runtimes;
			}
			else
			{
				List<string> keys = (from x in this._runtimes
				where string.Equals(x.Value.ConnectionName, connectionName.Trim(), StringComparison.OrdinalIgnoreCase)
				select x.Key).ToList<string>();
				foreach (string key in keys)
				{
					CommunicationConnectionRuntime runtime = this.RemoveRuntimeCore(key);
					bool flag2 = runtime != null;
					if (flag2)
					{
						runtimes.Add(runtime);
					}
				}
				result = runtimes;
			}
			return result;
		}

		// Token: 0x06001E8C RID: 7820 RVA: 0x000B1444 File Offset: 0x000AF644
		private static void DisposeRuntimes(IEnumerable<CommunicationConnectionRuntime> runtimes)
		{
			bool flag = runtimes == null;
			if (!flag)
			{
				foreach (CommunicationConnectionRuntime runtime in runtimes)
				{
					PlcCommunicationService.DisposeRuntime(runtime);
				}
			}
		}

		// Token: 0x06001E8D RID: 7821 RVA: 0x000B149C File Offset: 0x000AF69C
		private static void DisposeRuntime(CommunicationConnectionRuntime runtime)
		{
			bool flag = runtime == null;
			if (!flag)
			{
				ThreadPool.QueueUserWorkItem(delegate(object _)
				{
					try
					{
						object ioLock = runtime.IoLock;
						lock (ioLock)
						{
							runtime.Dispose();
						}
					}
					catch
					{
					}
				});
			}
		}

		// Token: 0x04000CD8 RID: 3288
		private readonly Dictionary<string, CommunicationConnectionRuntime> _runtimes = new Dictionary<string, CommunicationConnectionRuntime>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000CD9 RID: 3289
		private readonly object _runtimesLock = new object();
	}
}
