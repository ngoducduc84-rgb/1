﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001F2 RID: 498
	public static class SharedCommunicationService
	{
		// Token: 0x04000C71 RID: 3185
		public static readonly PlcCommunicationService Instance = new PlcCommunicationService();
	}
}
