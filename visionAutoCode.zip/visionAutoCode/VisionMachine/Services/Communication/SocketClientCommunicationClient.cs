﻿using System;
using System.Collections.Generic;
using System.Text;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000222 RID: 546
	internal class SocketClientCommunicationClient : TcpCommunicationClientBase
	{
		// Token: 0x06001EEC RID: 7916 RVA: 0x000B2980 File Offset: 0x000B0B80
		public override CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			return CommunicationReadResult.Fail("Socket protocol uses custom packets. Use Command tab to send data.");
		}

		// Token: 0x06001EED RID: 7917 RVA: 0x000B299C File Offset: 0x000B0B9C
		public override CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			CommunicationOperationResult result;
			try
			{
				string payloadText = string.IsNullOrWhiteSpace(address) ? value : (address + ":" + value);
				byte[] payload = Encoding.ASCII.GetBytes(payloadText ?? string.Empty);
				this.Stream.Write(payload, 0, payload.Length);
				result = CommunicationOperationResult.Ok("Socket payload sent.", payload.Length, 0);
			}
			catch (Exception ex)
			{
				result = CommunicationOperationResult.Fail(ex.Message, 0, 0);
			}
			return result;
		}
	}
}
