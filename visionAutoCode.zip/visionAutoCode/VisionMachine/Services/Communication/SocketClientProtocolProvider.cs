﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000213 RID: 531
	internal sealed class SocketClientProtocolProvider : CommunicationProtocolProviderBase
	{
		// Token: 0x06001EA7 RID: 7847 RVA: 0x000B17AB File Offset: 0x000AF9AB
		public SocketClientProtocolProvider() : base(new string[]
		{
			"Socket Client"
		})
		{
		}

		// Token: 0x06001EA8 RID: 7848 RVA: 0x000B17C3 File Offset: 0x000AF9C3
		public override IPlcCommunicationClient CreateClient()
		{
			return new SocketClientCommunicationClient();
		}
	}
}
