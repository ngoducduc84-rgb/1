﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000223 RID: 547
	internal class SocketServerCommunicationClient : IPlcCommunicationClient, IDisposable
	{
		// Token: 0x1700094E RID: 2382
		// (get) Token: 0x06001EEF RID: 7919 RVA: 0x000B2A20 File Offset: 0x000B0C20
		public bool IsConnectionAlive
		{
			get
			{
				return this._listener != null;
			}
		}

		// Token: 0x06001EF0 RID: 7920 RVA: 0x000B2A2C File Offset: 0x000B0C2C
		public CommunicationOperationResult Connect(CommunicationConnection connection)
		{
			CommunicationOperationResult result;
			try
			{
				IPAddress address = (string.IsNullOrWhiteSpace(connection.IpAddress) || connection.IpAddress == "0.0.0.0") ? IPAddress.Any : IPAddress.Parse(connection.IpAddress);
				this._listener = new TcpListener(address, connection.Port);
				this._listener.Start();
				result = CommunicationOperationResult.Ok("Socket server started.", 0, 0);
			}
			catch (Exception ex)
			{
				this.Dispose();
				result = CommunicationOperationResult.Fail(ex.Message, 0, 0);
			}
			return result;
		}

		// Token: 0x06001EF1 RID: 7921 RVA: 0x000B2AC4 File Offset: 0x000B0CC4
		public CommunicationOperationResult Test(CommunicationConnection connection)
		{
			return (this._listener != null) ? CommunicationOperationResult.Ok("Socket server is listening.", 0, 0) : CommunicationOperationResult.Fail("Socket server is not started.", 0, 0);
		}

		// Token: 0x06001EF2 RID: 7922 RVA: 0x000B2AF8 File Offset: 0x000B0CF8
		public CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			return CommunicationReadResult.Fail("Socket server monitor requires a custom packet parser.");
		}

		// Token: 0x06001EF3 RID: 7923 RVA: 0x000B2B14 File Offset: 0x000B0D14
		public CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			return CommunicationOperationResult.Fail("Socket server write requires an accepted client session.", 0, 0);
		}

		// Token: 0x06001EF4 RID: 7924 RVA: 0x000B2B34 File Offset: 0x000B0D34
		public void Dispose()
		{
			try
			{
				TcpListener listener = this._listener;
				if (listener != null)
				{
					listener.Stop();
				}
			}
			catch
			{
			}
			this._listener = null;
		}

		// Token: 0x04000CEB RID: 3307
		private TcpListener _listener;
	}
}
