﻿using System;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000214 RID: 532
	internal sealed class SocketServerProtocolProvider : CommunicationProtocolProviderBase
	{
		// Token: 0x06001EA9 RID: 7849 RVA: 0x000B17CA File Offset: 0x000AF9CA
		public SocketServerProtocolProvider() : base(new string[]
		{
			"Socket Server"
		})
		{
		}

		// Token: 0x06001EAA RID: 7850 RVA: 0x000B1785 File Offset: 0x000AF985
		public override IPlcCommunicationClient CreateClient()
		{
			return new SocketServerCommunicationClient();
		}
	}
}
