﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x0200021F RID: 543
	internal abstract class TcpCommunicationClientBase : IPlcCommunicationClient, IDisposable
	{
		// Token: 0x1700094C RID: 2380
		// (get) Token: 0x06001EC9 RID: 7881 RVA: 0x000B19B4 File Offset: 0x000AFBB4
		public virtual bool IsConnectionAlive
		{
			get
			{
				return this.IsConnected();
			}
		}

		// Token: 0x06001ECA RID: 7882 RVA: 0x000B19BC File Offset: 0x000AFBBC
		public virtual CommunicationOperationResult Connect(CommunicationConnection connection)
		{
			CommunicationOperationResult result;
			try
			{
				string text;
				if (connection == null)
				{
					text = null;
				}
				else
				{
					string ipAddress2 = connection.IpAddress;
					text = ((ipAddress2 != null) ? ipAddress2.Trim() : null);
				}
				string ipAddress = text;
				bool flag = string.IsNullOrWhiteSpace(ipAddress) || ipAddress == "0.0.0.0" || ipAddress == "::0" || ipAddress == "::";
				if (flag)
				{
					result = CommunicationOperationResult.Fail("Modbus client requires a valid target IP address.", 0, 0);
				}
				else
				{
					IPAddress parsedAddress;
					bool flag2 = IPAddress.TryParse(ipAddress, out parsedAddress) && (object.Equals(parsedAddress, IPAddress.Any) || object.Equals(parsedAddress, IPAddress.IPv6Any));
					if (flag2)
					{
						result = CommunicationOperationResult.Fail("Modbus client requires a valid target IP address.", 0, 0);
					}
					else
					{
						this.Client = new TcpClient();
						IAsyncResult asyncResult = this.Client.BeginConnect(ipAddress, connection.Port, null, null);
						bool flag3 = !asyncResult.AsyncWaitHandle.WaitOne(connection.TimeoutMs);
						if (flag3)
						{
							result = CommunicationOperationResult.Fail("Connection timeout.", 0, 0);
						}
						else
						{
							this.Client.EndConnect(asyncResult);
							this.Client.ReceiveTimeout = connection.TimeoutMs;
							this.Client.SendTimeout = connection.TimeoutMs;
							this.Stream = this.Client.GetStream();
							this.Stream.ReadTimeout = connection.TimeoutMs;
							this.Stream.WriteTimeout = connection.TimeoutMs;
							result = CommunicationOperationResult.Ok("Connected.", 0, 0);
						}
					}
				}
			}
			catch (Exception ex)
			{
				this.Dispose();
				result = CommunicationOperationResult.Fail(ex.Message, 0, 0);
			}
			return result;
		}

		// Token: 0x06001ECB RID: 7883 RVA: 0x000B1B6C File Offset: 0x000AFD6C
		public virtual CommunicationOperationResult Test(CommunicationConnection connection)
		{
			return this.IsConnected() ? CommunicationOperationResult.Ok("Test success.", 0, 0) : CommunicationOperationResult.Fail("TCP socket is not connected.", 0, 0);
		}

		// Token: 0x06001ECC RID: 7884
		public abstract CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags);

		// Token: 0x06001ECD RID: 7885
		public abstract CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value);

		// Token: 0x06001ECE RID: 7886 RVA: 0x000B1BA0 File Offset: 0x000AFDA0
		protected bool IsConnected()
		{
			bool flag = this.Client == null || this.Stream == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					Socket socket = this.Client.Client;
					bool flag2 = socket == null || !socket.Connected;
					if (flag2)
					{
						result = false;
					}
					else
					{
						bool readable = socket.Poll(0, SelectMode.SelectRead);
						result = (!readable || socket.Available != 0);
					}
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001ECF RID: 7887 RVA: 0x000B1C24 File Offset: 0x000AFE24
		protected byte[] Transceive(byte[] request)
		{
			bool flag = !this.IsConnected();
			if (flag)
			{
				throw new InvalidOperationException("TCP socket is not connected.");
			}
			object ioLock = this._ioLock;
			byte[] result;
			lock (ioLock)
			{
				this.FlushPendingBytes();
				this.Stream.Write(request, 0, request.Length);
				byte[] header = this.ReadExact(7);
				int length = (int)header[4] << 8 | (int)header[5];
				bool flag3 = length <= 1;
				if (flag3)
				{
					throw new IOException("Invalid Modbus TCP length. Header=" + BitConverter.ToString(header));
				}
				byte[] body = this.ReadExact(length - 1);
				byte[] response = new byte[7 + body.Length];
				Buffer.BlockCopy(header, 0, response, 0, 7);
				Buffer.BlockCopy(body, 0, response, 7, body.Length);
				result = response;
			}
			return result;
		}

		// Token: 0x06001ED0 RID: 7888 RVA: 0x000B1D08 File Offset: 0x000AFF08
		private void FlushPendingBytes()
		{
			try
			{
				bool flag = this.Client == null || this.Stream == null;
				if (!flag)
				{
					byte[] buffer = new byte[256];
					while (this.Client.Available > 0)
					{
						int count = Math.Min(buffer.Length, this.Client.Available);
						int read = this.Stream.Read(buffer, 0, count);
						bool flag2 = read <= 0;
						if (flag2)
						{
							break;
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001ED1 RID: 7889 RVA: 0x000B1DA0 File Offset: 0x000AFFA0
		private byte[] ReadExact(int length)
		{
			byte[] buffer = new byte[length];
			int read;
			for (int offset = 0; offset < length; offset += read)
			{
				NetworkStream stream = this.Stream;
				bool flag = stream == null;
				if (flag)
				{
					throw new IOException("TCP stream is not connected.");
				}
				read = stream.Read(buffer, offset, length - offset);
				bool flag2 = read <= 0;
				if (flag2)
				{
					throw new IOException("Connection closed by remote device.");
				}
			}
			return buffer;
		}

		// Token: 0x06001ED2 RID: 7890 RVA: 0x000B1E10 File Offset: 0x000B0010
		public virtual void Dispose()
		{
			try
			{
				NetworkStream stream = this.Stream;
				if (stream != null)
				{
					stream.Dispose();
				}
			}
			catch
			{
			}
			try
			{
				TcpClient client = this.Client;
				if (client != null)
				{
					client.Close();
				}
			}
			catch
			{
			}
			this.Stream = null;
			this.Client = null;
		}

		// Token: 0x04000CE6 RID: 3302
		protected TcpClient Client;

		// Token: 0x04000CE7 RID: 3303
		protected NetworkStream Stream;

		// Token: 0x04000CE8 RID: 3304
		private readonly object _ioLock = new object();
	}
}
