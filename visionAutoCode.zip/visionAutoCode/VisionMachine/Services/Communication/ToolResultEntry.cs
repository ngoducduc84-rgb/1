﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001FB RID: 507
	public class ToolResultEntry
	{
		// Token: 0x17000932 RID: 2354
		// (get) Token: 0x06001DEC RID: 7660 RVA: 0x000AB7B9 File Offset: 0x000A99B9
		// (set) Token: 0x06001DED RID: 7661 RVA: 0x000AB7C1 File Offset: 0x000A99C1
		public ToolVision Tool { get; set; }

		// Token: 0x17000933 RID: 2355
		// (get) Token: 0x06001DEE RID: 7662 RVA: 0x000AB7CA File Offset: 0x000A99CA
		// (set) Token: 0x06001DEF RID: 7663 RVA: 0x000AB7D2 File Offset: 0x000A99D2
		public object Result { get; set; }
	}
}
