﻿using System;
using System.Collections.Generic;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x02000227 RID: 551
	internal class UnsupportedCommunicationClient : IPlcCommunicationClient, IDisposable
	{
		// Token: 0x17000951 RID: 2385
		// (get) Token: 0x06001F37 RID: 7991 RVA: 0x000B65F6 File Offset: 0x000B47F6
		public bool IsConnectionAlive
		{
			get
			{
				return false;
			}
		}

		// Token: 0x06001F38 RID: 7992 RVA: 0x000B65F9 File Offset: 0x000B47F9
		public UnsupportedCommunicationClient(string message)
		{
			this._message = message;
		}

		// Token: 0x06001F39 RID: 7993 RVA: 0x000B660A File Offset: 0x000B480A
		public CommunicationOperationResult Connect(CommunicationConnection connection)
		{
			return CommunicationOperationResult.Fail(this._message, 0, 0);
		}

		// Token: 0x06001F3A RID: 7994 RVA: 0x000B660A File Offset: 0x000B480A
		public CommunicationOperationResult Test(CommunicationConnection connection)
		{
			return CommunicationOperationResult.Fail(this._message, 0, 0);
		}

		// Token: 0x06001F3B RID: 7995 RVA: 0x000B6619 File Offset: 0x000B4819
		public CommunicationReadResult ReadAll(CommunicationConnection connection, IEnumerable<CommunicationTagRow> tags)
		{
			return CommunicationReadResult.Fail(this._message);
		}

		// Token: 0x06001F3C RID: 7996 RVA: 0x000B660A File Offset: 0x000B480A
		public CommunicationOperationResult Write(CommunicationConnection connection, string address, string dataType, string value)
		{
			return CommunicationOperationResult.Fail(this._message, 0, 0);
		}

		// Token: 0x06001F3D RID: 7997 RVA: 0x0000AB39 File Offset: 0x00008D39
		public void Dispose()
		{
		}

		// Token: 0x04000CFD RID: 3325
		private readonly string _message;
	}
}
