﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using VisionMachine.Models.Communication;

namespace VisionMachine.Services.Communication
{
	// Token: 0x020001FD RID: 509
	public static class VisionErrorCodeService
	{
		// Token: 0x06001E14 RID: 7700 RVA: 0x000ADC5C File Offset: 0x000ABE5C
		public static void WriteAsync(int code)
		{
			Task.Run<bool>(() => VisionErrorCodeService.Write(code));
		}

		// Token: 0x06001E15 RID: 7701 RVA: 0x000ADC8C File Offset: 0x000ABE8C
		public static bool Write(int code)
		{
			bool result;
			try
			{
				VisionErrorCodeService.<>c__DisplayClass5_0 CS$<>8__locals1 = new VisionErrorCodeService.<>c__DisplayClass5_0();
				CS$<>8__locals1.config = CommunicationConfigStorageService.LoadConfig(null);
				CommunicationConfigData config = CS$<>8__locals1.config;
				List<CommunicationConnection> connections = (config != null) ? config.Connections : null;
				bool flag = connections == null || connections.Count == 0;
				if (flag)
				{
					result = false;
				}
				else
				{
					CommunicationConnection connection = null;
					CommunicationTagRow tag = null;
					VisionErrorCodeService.<>c__DisplayClass5_0 CS$<>8__locals2 = CS$<>8__locals1;
					CommunicationRuntimeSettings runtimeSettings = CS$<>8__locals1.config.RuntimeSettings;
					CS$<>8__locals2.triggerName = ((runtimeSettings != null) ? runtimeSettings.CameraTriggerConnectionName : null);
					bool flag2 = !string.IsNullOrWhiteSpace(CS$<>8__locals1.triggerName) && !string.Equals(CS$<>8__locals1.triggerName, "None", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						CommunicationConnection preferred = connections.FirstOrDefault((CommunicationConnection x) => VisionErrorCodeService.IsSupported(x) && string.Equals(x.Name, CS$<>8__locals1.triggerName, StringComparison.OrdinalIgnoreCase));
						bool flag3 = preferred != null && VisionErrorCodeService.TryGetTag(CS$<>8__locals1.config, preferred, out tag);
						if (flag3)
						{
							connection = preferred;
						}
					}
					bool flag4 = connection == null;
					if (flag4)
					{
						List<CommunicationConnection> candidates = connections.Where(delegate(CommunicationConnection x)
						{
							CommunicationTagRow communicationTagRow;
							return VisionErrorCodeService.IsSupported(x) && VisionErrorCodeService.TryGetTag(CS$<>8__locals1.config, x, out communicationTagRow);
						}).ToList<CommunicationConnection>();
						connection = (candidates.FirstOrDefault((CommunicationConnection x) => VisionErrorCodeService.CommunicationService.IsConnected(x)) ?? candidates.FirstOrDefault<CommunicationConnection>());
						bool flag5 = connection != null;
						if (flag5)
						{
							VisionErrorCodeService.TryGetTag(CS$<>8__locals1.config, connection, out tag);
						}
					}
					bool flag6 = connection == null || tag == null || string.IsNullOrWhiteSpace(tag.Address);
					if (flag6)
					{
						result = false;
					}
					else
					{
						CommunicationOperationResult connectResult = VisionErrorCodeService.CommunicationService.ConnectIfDisconnected(connection);
						bool flag7 = !connectResult.Success;
						if (flag7)
						{
							result = false;
						}
						else
						{
							CommunicationOperationResult writeResult = VisionErrorCodeService.CommunicationService.Write(connection, tag.Address, string.IsNullOrWhiteSpace(tag.DataType) ? "INT16" : tag.DataType, code.ToString(CultureInfo.InvariantCulture));
							result = writeResult.Success;
						}
					}
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06001E16 RID: 7702 RVA: 0x000ADE78 File Offset: 0x000AC078
		private static bool TryGetTag(CommunicationConfigData config, CommunicationConnection connection, out CommunicationTagRow tag)
		{
			tag = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name).FirstOrDefault((CommunicationTagRow x) => x != null && CommunicationHeartbeatMonitorHelper.IsConfiguredAddress(x.Address) && VisionErrorCodeService.NormalizeTagName(x.Name) == VisionErrorCodeService.NormalizeTagName("vision error status"));
			return tag != null;
		}

		// Token: 0x06001E17 RID: 7703 RVA: 0x000ADEC4 File Offset: 0x000AC0C4
		private static bool IsSupported(CommunicationConnection connection)
		{
			return connection != null && CommunicationOptions.SupportsTagReadWrite(connection.Protocol);
		}

		// Token: 0x06001E18 RID: 7704 RVA: 0x000ADEE8 File Offset: 0x000AC0E8
		private static string NormalizeTagName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				result = new string(name.Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
			}
			return result;
		}

		// Token: 0x04000CAA RID: 3242
		public const string TagName = "vision error status";

		// Token: 0x04000CAB RID: 3243
		public const int CodeOk = 0;

		// Token: 0x04000CAC RID: 3244
		public const int CodeTriggeredNoResult = 10;

		// Token: 0x04000CAD RID: 3245
		private static readonly PlcCommunicationService CommunicationService = SharedCommunicationService.Instance;
	}
}
