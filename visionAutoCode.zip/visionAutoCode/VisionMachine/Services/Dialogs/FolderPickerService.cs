﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace VisionMachine.Services.Dialogs
{
	// Token: 0x020001E2 RID: 482
	public static class FolderPickerService
	{
		// Token: 0x06001D01 RID: 7425 RVA: 0x000A3B90 File Offset: 0x000A1D90
		public static string PickFolder(string title, string initialFolder, IntPtr owner)
		{
			string result;
			try
			{
				result = FolderPickerService.PickWithShellDialog(title, initialFolder, owner);
			}
			catch (Exception)
			{
				result = FolderPickerService.PickWithLegacyDialog(title, initialFolder);
			}
			return result;
		}

		// Token: 0x06001D02 RID: 7426 RVA: 0x000A3BC8 File Offset: 0x000A1DC8
		private static string PickWithShellDialog(string title, string initialFolder, IntPtr owner)
		{
			FolderPickerService.IFileDialog dialog = (FolderPickerService.IFileDialog)new FolderPickerService.FileOpenDialogRcw();
			string result2;
			try
			{
				uint options;
				dialog.GetOptions(out options);
				dialog.SetOptions(options | 32U | 64U | 2048U);
				bool flag = !string.IsNullOrWhiteSpace(title);
				if (flag)
				{
					dialog.SetTitle(title);
				}
				bool flag2 = !string.IsNullOrWhiteSpace(initialFolder) && Directory.Exists(initialFolder);
				if (flag2)
				{
					FolderPickerService.IShellItem start = FolderPickerService.CreateShellItem(initialFolder);
					bool flag3 = start != null;
					if (flag3)
					{
						dialog.SetFolder(start);
					}
				}
				int hr = dialog.Show(owner);
				bool flag4 = hr == -2147023673;
				if (flag4)
				{
					result2 = null;
				}
				else
				{
					bool flag5 = hr != 0;
					if (flag5)
					{
						Marshal.ThrowExceptionForHR(hr);
					}
					FolderPickerService.IShellItem result;
					dialog.GetResult(out result);
					bool flag6 = result == null;
					if (flag6)
					{
						result2 = null;
					}
					else
					{
						string path;
						result.GetDisplayName(2147844096U, out path);
						Marshal.ReleaseComObject(result);
						result2 = path;
					}
				}
			}
			finally
			{
				Marshal.ReleaseComObject(dialog);
			}
			return result2;
		}

		// Token: 0x06001D03 RID: 7427 RVA: 0x000A3CC8 File Offset: 0x000A1EC8
		private static string PickWithLegacyDialog(string title, string initialFolder)
		{
			string result;
			using (FolderBrowserDialog dialog = new FolderBrowserDialog())
			{
				dialog.Description = title;
				dialog.ShowNewFolderButton = false;
				bool flag = !string.IsNullOrWhiteSpace(initialFolder) && Directory.Exists(initialFolder);
				if (flag)
				{
					dialog.SelectedPath = initialFolder;
				}
				result = ((dialog.ShowDialog() == DialogResult.OK) ? dialog.SelectedPath : null);
			}
			return result;
		}

		// Token: 0x06001D04 RID: 7428 RVA: 0x000A3D3C File Offset: 0x000A1F3C
		private static FolderPickerService.IShellItem CreateShellItem(string path)
		{
			FolderPickerService.IShellItem result;
			try
			{
				Guid riid = new Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe");
				object item;
				FolderPickerService.SHCreateItemFromParsingName(path, IntPtr.Zero, ref riid, out item);
				result = (item as FolderPickerService.IShellItem);
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06001D05 RID: 7429
		[DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
		private static extern void SHCreateItemFromParsingName([MarshalAs(UnmanagedType.LPWStr)] string path, IntPtr pbc, ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out object ppv);

		// Token: 0x04000C4A RID: 3146
		private const uint FosPickFolders = 32U;

		// Token: 0x04000C4B RID: 3147
		private const uint FosForceFileSystem = 64U;

		// Token: 0x04000C4C RID: 3148
		private const uint FosPathMustExist = 2048U;

		// Token: 0x04000C4D RID: 3149
		private const uint SigdnFileSysPath = 2147844096U;

		// Token: 0x04000C4E RID: 3150
		private const int HresultCancelled = -2147023673;

		// Token: 0x04000C4F RID: 3151
		private const string IidShellItem = "43826d1e-e718-42ee-bc55-a1e261c37bfe";

		// Token: 0x0200043C RID: 1084
		[ClassInterface(ClassInterfaceType.None)]
		[Guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")]
		[ComImport]
		private class FileOpenDialogRcw
		{
			// Token: 0x06002B5E RID: 11102
			[MethodImpl(MethodImplOptions.InternalCall)]
			public extern FileOpenDialogRcw();
		}

		// Token: 0x0200043D RID: 1085
		[Guid("42f85136-db7e-439c-85f1-e4075d135fc8")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		private interface IFileDialog
		{
			// Token: 0x06002B5F RID: 11103
			[PreserveSig]
			int Show(IntPtr parent);

			// Token: 0x06002B60 RID: 11104
			void SetFileTypes(uint cFileTypes, IntPtr rgFilterSpec);

			// Token: 0x06002B61 RID: 11105
			void SetFileTypeIndex(uint iFileType);

			// Token: 0x06002B62 RID: 11106
			void GetFileTypeIndex(out uint piFileType);

			// Token: 0x06002B63 RID: 11107
			void Advise(IntPtr pfde, out uint pdwCookie);

			// Token: 0x06002B64 RID: 11108
			void Unadvise(uint dwCookie);

			// Token: 0x06002B65 RID: 11109
			void SetOptions(uint fos);

			// Token: 0x06002B66 RID: 11110
			void GetOptions(out uint pfos);

			// Token: 0x06002B67 RID: 11111
			void SetDefaultFolder(FolderPickerService.IShellItem psi);

			// Token: 0x06002B68 RID: 11112
			void SetFolder(FolderPickerService.IShellItem psi);

			// Token: 0x06002B69 RID: 11113
			void GetFolder(out FolderPickerService.IShellItem ppsi);

			// Token: 0x06002B6A RID: 11114
			void GetCurrentSelection(out FolderPickerService.IShellItem ppsi);

			// Token: 0x06002B6B RID: 11115
			void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string pszName);

			// Token: 0x06002B6C RID: 11116
			void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string pszName);

			// Token: 0x06002B6D RID: 11117
			void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string pszTitle);

			// Token: 0x06002B6E RID: 11118
			void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string pszText);

			// Token: 0x06002B6F RID: 11119
			void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string pszLabel);

			// Token: 0x06002B70 RID: 11120
			void GetResult(out FolderPickerService.IShellItem ppsi);

			// Token: 0x06002B71 RID: 11121
			void AddPlace(FolderPickerService.IShellItem psi, int fdap);

			// Token: 0x06002B72 RID: 11122
			void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string pszDefaultExtension);

			// Token: 0x06002B73 RID: 11123
			void Close([MarshalAs(UnmanagedType.Error)] int hr);

			// Token: 0x06002B74 RID: 11124
			void SetClientGuid(ref Guid guid);

			// Token: 0x06002B75 RID: 11125
			void ClearClientData();

			// Token: 0x06002B76 RID: 11126
			void SetFilter(IntPtr pFilter);
		}

		// Token: 0x0200043E RID: 1086
		[Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe")]
		[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
		[ComImport]
		private interface IShellItem
		{
			// Token: 0x06002B77 RID: 11127
			void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppv);

			// Token: 0x06002B78 RID: 11128
			void GetParent(out FolderPickerService.IShellItem ppsi);

			// Token: 0x06002B79 RID: 11129
			void GetDisplayName(uint sigdnName, [MarshalAs(UnmanagedType.LPWStr)] out string ppszName);

			// Token: 0x06002B7A RID: 11130
			void GetAttributes(uint sfgaoMask, out uint psfgaoAttribs);

			// Token: 0x06002B7B RID: 11131
			void Compare(FolderPickerService.IShellItem psi, uint hint, out int piOrder);
		}
	}
}
