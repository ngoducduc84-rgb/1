﻿using System;

namespace VisionMachine.Services.Licensing
{
	// Token: 0x02000266 RID: 614
	public class LicenseCheckResult
	{
		// Token: 0x170009DC RID: 2524
		// (get) Token: 0x06002245 RID: 8773 RVA: 0x000D102A File Offset: 0x000CF22A
		// (set) Token: 0x06002246 RID: 8774 RVA: 0x000D1032 File Offset: 0x000CF232
		public bool Success { get; set; }

		// Token: 0x170009DD RID: 2525
		// (get) Token: 0x06002247 RID: 8775 RVA: 0x000D103B File Offset: 0x000CF23B
		// (set) Token: 0x06002248 RID: 8776 RVA: 0x000D1043 File Offset: 0x000CF243
		public string Message { get; set; }

		// Token: 0x170009DE RID: 2526
		// (get) Token: 0x06002249 RID: 8777 RVA: 0x000D104C File Offset: 0x000CF24C
		// (set) Token: 0x0600224A RID: 8778 RVA: 0x000D1054 File Offset: 0x000CF254
		public LicenseState State { get; set; }

		// Token: 0x0600224B RID: 8779 RVA: 0x000D1060 File Offset: 0x000CF260
		public static LicenseCheckResult Fail(string message)
		{
			return new LicenseCheckResult
			{
				Success = false,
				Message = message
			};
		}
	}
}
