﻿using System;

namespace VisionMachine.Services.Licensing
{
	// Token: 0x02000268 RID: 616
	public sealed class LicenseExpiryWarningInfo
	{
		// Token: 0x170009E0 RID: 2528
		// (get) Token: 0x0600225E RID: 8798 RVA: 0x000D1982 File Offset: 0x000CFB82
		// (set) Token: 0x0600225F RID: 8799 RVA: 0x000D198A File Offset: 0x000CFB8A
		public LicenseState License { get; set; }

		// Token: 0x170009E1 RID: 2529
		// (get) Token: 0x06002260 RID: 8800 RVA: 0x000D1993 File Offset: 0x000CFB93
		// (set) Token: 0x06002261 RID: 8801 RVA: 0x000D199B File Offset: 0x000CFB9B
		public int DaysRemaining { get; set; }
	}
}
