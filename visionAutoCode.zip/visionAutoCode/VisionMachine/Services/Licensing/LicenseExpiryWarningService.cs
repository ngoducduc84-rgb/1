﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Services.Licensing
{
	// Token: 0x0200026A RID: 618
	public static class LicenseExpiryWarningService
	{
		// Token: 0x0600226A RID: 8810 RVA: 0x000D19D8 File Offset: 0x000CFBD8
		public static bool TryGetWarning(out LicenseExpiryWarningInfo info)
		{
			info = null;
			LicenseState license = LicenseService.GetState();
			bool flag = license == null || !license.IsActivated || license.IsPerpetual || license.ExpiresAt == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				DateTime expiresAt = license.ExpiresAt.Value;
				TimeSpan remaining = expiresAt - DateTime.Now;
				bool flag2 = remaining.TotalDays > 30.0;
				if (flag2)
				{
					result = false;
				}
				else
				{
					int daysRemaining = Math.Max(0, (int)Math.Ceiling(remaining.TotalDays));
					LicenseExpiryWarningState warningState = LicenseExpiryWarningService.Load();
					bool flag3 = warningState != null && warningState.SchemaVersion == 2 && warningState.LicenseExpiresAt == expiresAt && warningState.SnoozeUntil > DateTime.Now;
					if (flag3)
					{
						result = false;
					}
					else
					{
						info = new LicenseExpiryWarningInfo
						{
							License = license,
							DaysRemaining = daysRemaining
						};
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x0600226B RID: 8811 RVA: 0x000D1AD8 File Offset: 0x000CFCD8
		public static bool TryGetExpiredLicense(out LicenseState license)
		{
			license = LicenseService.GetStoredSignedStateIncludingExpired();
			return license != null && license.IsActivated && !license.IsPerpetual && license.ExpiresAt != null && DateTime.Now > license.ExpiresAt.Value;
		}

		// Token: 0x0600226C RID: 8812 RVA: 0x000D1B34 File Offset: 0x000CFD34
		public static void SnoozeUntilTomorrow(DateTime expiresAt)
		{
			LicenseExpiryWarningService.Save(new LicenseExpiryWarningState
			{
				SchemaVersion = 2,
				LicenseExpiresAt = expiresAt,
				SnoozeUntil = DateTime.Now.AddDays(1.0)
			});
		}

		// Token: 0x0600226D RID: 8813 RVA: 0x000D1B7C File Offset: 0x000CFD7C
		private static LicenseExpiryWarningState Load()
		{
			object syncRoot = LicenseExpiryWarningService.SyncRoot;
			LicenseExpiryWarningState result;
			lock (syncRoot)
			{
				try
				{
					string path = Manager_path._licenseWarningJsonPath;
					bool flag2 = !File.Exists(path);
					if (flag2)
					{
						result = null;
					}
					else
					{
						result = JsonConvert.DeserializeObject<LicenseExpiryWarningState>(File.ReadAllText(path));
					}
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x0600226E RID: 8814 RVA: 0x000D1BF4 File Offset: 0x000CFDF4
		private static void Save(LicenseExpiryWarningState state)
		{
			object syncRoot = LicenseExpiryWarningService.SyncRoot;
			lock (syncRoot)
			{
				try
				{
					string path = Manager_path._licenseWarningJsonPath;
					string folder = Path.GetDirectoryName(path);
					bool flag2 = !string.IsNullOrWhiteSpace(folder);
					if (flag2)
					{
						Manager_path.Creat_path(folder);
					}
					File.WriteAllText(path, JsonConvert.SerializeObject(state, Formatting.Indented));
				}
				catch
				{
				}
			}
		}

		// Token: 0x04000E34 RID: 3636
		public const int WarningThresholdDays = 30;

		// Token: 0x04000E35 RID: 3637
		private const int CurrentWarningStateVersion = 2;

		// Token: 0x04000E36 RID: 3638
		private static readonly object SyncRoot = new object();
	}
}
