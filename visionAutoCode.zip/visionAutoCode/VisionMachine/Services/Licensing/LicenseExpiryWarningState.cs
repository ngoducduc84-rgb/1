﻿using System;

namespace VisionMachine.Services.Licensing
{
	// Token: 0x02000269 RID: 617
	internal sealed class LicenseExpiryWarningState
	{
		// Token: 0x170009E2 RID: 2530
		// (get) Token: 0x06002263 RID: 8803 RVA: 0x000D19A4 File Offset: 0x000CFBA4
		// (set) Token: 0x06002264 RID: 8804 RVA: 0x000D19AC File Offset: 0x000CFBAC
		public int SchemaVersion { get; set; }

		// Token: 0x170009E3 RID: 2531
		// (get) Token: 0x06002265 RID: 8805 RVA: 0x000D19B5 File Offset: 0x000CFBB5
		// (set) Token: 0x06002266 RID: 8806 RVA: 0x000D19BD File Offset: 0x000CFBBD
		public DateTime LicenseExpiresAt { get; set; }

		// Token: 0x170009E4 RID: 2532
		// (get) Token: 0x06002267 RID: 8807 RVA: 0x000D19C6 File Offset: 0x000CFBC6
		// (set) Token: 0x06002268 RID: 8808 RVA: 0x000D19CE File Offset: 0x000CFBCE
		public DateTime SnoozeUntil { get; set; }
	}
}
