﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Services.Licensing
{
	// Token: 0x02000267 RID: 615
	public static class LicenseService
	{
		// Token: 0x0600224D RID: 8781 RVA: 0x000D1088 File Offset: 0x000CF288
		public static IEnumerable<KeyValuePair<char, string>> GetEditions()
		{
			return from x in LicenseService.Editions
			select new KeyValuePair<char, string>(x.Item1, x.Item2);
		}

		// Token: 0x0600224E RID: 8782 RVA: 0x000D10C4 File Offset: 0x000CF2C4
		public static char GetEditionCode(string editionName)
		{
			ValueTuple<char, string> match = LicenseService.Editions.FirstOrDefault(([TupleElementNames(new string[]
			{
				"Code",
				"Name"
			})] ValueTuple<char, string> x) => string.Equals(x.Item2, editionName, StringComparison.OrdinalIgnoreCase));
			return (match.Item2 == null) ? '\0' : match.Item1;
		}

		// Token: 0x0600224F RID: 8783 RVA: 0x000D110C File Offset: 0x000CF30C
		public static string GetConfigPath()
		{
			return Manager_path._licenseJsonPath;
		}

		// Token: 0x06002250 RID: 8784 RVA: 0x000D1124 File Offset: 0x000CF324
		public static LicenseState GetState()
		{
			object syncRoot = LicenseService.SyncRoot;
			LicenseState state;
			lock (syncRoot)
			{
				bool flag2 = LicenseService._state != null;
				if (flag2)
				{
					state = LicenseService._state;
				}
				else
				{
					LicenseService._state = (LicenseService.Load() ?? new LicenseState());
					bool isActivated = LicenseService._state.IsActivated;
					if (isActivated)
					{
						LicenseCheckResult recheck = LicenseService.Validate(LicenseService._state.Key);
						bool flag3 = !recheck.Success;
						if (flag3)
						{
							LicenseService._state = new LicenseState
							{
								IsActivated = false,
								MachineId = MachineIdService.GetMachineId()
							};
						}
						else
						{
							recheck.State.ActivatedAt = new DateTime?(LicenseService._state.ActivatedAt ?? DateTime.Now);
							LicenseService._state = recheck.State;
						}
					}
					state = LicenseService._state;
				}
			}
			return state;
		}

		// Token: 0x170009DF RID: 2527
		// (get) Token: 0x06002251 RID: 8785 RVA: 0x000D1230 File Offset: 0x000CF430
		public static bool IsActivated
		{
			get
			{
				return LicenseService.GetState().IsActivated;
			}
		}

		// Token: 0x06002252 RID: 8786 RVA: 0x000D124C File Offset: 0x000CF44C
		public static LicenseState GetStoredSignedStateIncludingExpired()
		{
			object syncRoot = LicenseService.SyncRoot;
			LicenseState result;
			lock (syncRoot)
			{
				LicenseState stored = LicenseService.Load();
				bool flag2 = stored == null || !stored.IsActivated || string.IsNullOrWhiteSpace(stored.Key);
				if (flag2)
				{
					result = null;
				}
				else
				{
					LicenseCheckResult recheck = LicenseService.ValidateCore(stored.Key, false);
					bool flag3 = !recheck.Success || recheck.State == null;
					if (flag3)
					{
						result = null;
					}
					else
					{
						recheck.State.ActivatedAt = stored.ActivatedAt;
						result = recheck.State;
					}
				}
			}
			return result;
		}

		// Token: 0x06002253 RID: 8787 RVA: 0x000D12FC File Offset: 0x000CF4FC
		public static LicenseCheckResult Activate(string key)
		{
			LicenseCheckResult result = LicenseService.Validate(key);
			bool flag = !result.Success;
			LicenseCheckResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				object syncRoot = LicenseService.SyncRoot;
				lock (syncRoot)
				{
					result.State.ActivatedAt = new DateTime?(DateTime.Now);
					LicenseService._state = result.State;
					LicenseService.Save(LicenseService._state);
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06002254 RID: 8788 RVA: 0x000D1388 File Offset: 0x000CF588
		public static void Deactivate()
		{
			object syncRoot = LicenseService.SyncRoot;
			lock (syncRoot)
			{
				LicenseService._state = new LicenseState
				{
					IsActivated = false,
					MachineId = MachineIdService.GetMachineId()
				};
				LicenseService.Save(LicenseService._state);
			}
		}

		// Token: 0x06002255 RID: 8789 RVA: 0x000D13F0 File Offset: 0x000CF5F0
		public static LicenseCheckResult Validate(string key)
		{
			return LicenseService.ValidateCore(key, true);
		}

		// Token: 0x06002256 RID: 8790 RVA: 0x000D140C File Offset: 0x000CF60C
		private static LicenseCheckResult ValidateCore(string key, bool rejectExpired)
		{
			string machineId = MachineIdService.GetMachineId();
			bool flag = machineId == "UNAVAILABLE";
			LicenseCheckResult result;
			if (flag)
			{
				result = LicenseCheckResult.Fail("The machine code could not be read from this computer, so a licence cannot be checked. Contact your supplier.");
			}
			else
			{
				string normalized = LicenseService.Normalize(key);
				bool flag2 = string.IsNullOrWhiteSpace(normalized);
				if (flag2)
				{
					result = LicenseCheckResult.Fail("Enter the licence you were given.");
				}
				else
				{
					string[] parts = normalized.Split(new char[]
					{
						'-'
					});
					bool flag3 = parts.Length != 3;
					if (flag3)
					{
						result = LicenseCheckResult.Fail("This licence is not in the expected form. It should look like 20251231-P-3F9A17C4B20E5D68.");
					}
					else
					{
						DateTime expiry;
						bool flag4 = !DateTime.TryParseExact(parts[0], "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out expiry);
						if (flag4)
						{
							result = LicenseCheckResult.Fail("The date inside this licence is not readable.");
						}
						else
						{
							bool perpetual = expiry.Date >= LicenseService.PerpetualDate.Date;
							expiry = (perpetual ? DateTime.MaxValue : expiry.Date.AddDays(1.0).AddSeconds(-1.0));
							bool flag5 = parts[1].Length != 1;
							if (flag5)
							{
								result = LicenseCheckResult.Fail("The edition inside this licence is not readable.");
							}
							else
							{
								char editionCode = parts[1][0];
								ValueTuple<char, string> edition = LicenseService.Editions.FirstOrDefault(([TupleElementNames(new string[]
								{
									"Code",
									"Name"
								})] ValueTuple<char, string> x) => x.Item1 == editionCode);
								bool flag6 = edition.Item2 == null;
								if (flag6)
								{
									result = LicenseCheckResult.Fail("This licence names an edition this version does not know.");
								}
								else
								{
									string expected = LicenseService.Sign(machineId, parts[0], editionCode);
									bool flag7 = !LicenseService.FixedTimeEquals(expected, parts[2]);
									if (flag7)
									{
										result = LicenseCheckResult.Fail("This licence does not belong to this machine. Check that the machine code sent to your supplier is the one shown above.");
									}
									else
									{
										bool flag8 = rejectExpired && DateTime.Now > expiry;
										if (flag8)
										{
											result = LicenseCheckResult.Fail("This licence expired on " + expiry.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + ".");
										}
										else
										{
											result = new LicenseCheckResult
											{
												Success = true,
												Message = (perpetual ? "The licence is valid and does not expire." : ("The licence is valid until " + expiry.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + ".")),
												State = new LicenseState
												{
													IsActivated = true,
													Key = normalized,
													MachineId = machineId,
													ExpiresAt = (perpetual ? null : new DateTime?(expiry)),
													IsPerpetual = perpetual,
													Edition = edition.Item2
												}
											};
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06002257 RID: 8791 RVA: 0x000D16AC File Offset: 0x000CF8AC
		public static string IssueKey(string machineId, DateTime expiryDate, char editionCode)
		{
			string day = expiryDate.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
			return string.Concat(new string[]
			{
				day,
				"-",
				editionCode.ToString(),
				"-",
				LicenseService.Sign(machineId, day, editionCode)
			});
		}

		// Token: 0x06002258 RID: 8792 RVA: 0x000D1704 File Offset: 0x000CF904
		private static string Sign(string machineId, string day, char editionCode)
		{
			string result;
			using (HMACSHA256 hmac = new HMACSHA256(Encoding.UTF8.GetBytes("VisionMachine-License-v1-9F2A64C1B7E34D80")))
			{
				byte[] mac = hmac.ComputeHash(Encoding.UTF8.GetBytes(string.Concat(new string[]
				{
					machineId,
					"|",
					day,
					"|",
					editionCode.ToString()
				})));
				result = string.Concat(from b in mac.Take(8)
				select b.ToString("X2", CultureInfo.InvariantCulture));
			}
			return result;
		}

		// Token: 0x06002259 RID: 8793 RVA: 0x000D17B8 File Offset: 0x000CF9B8
		private static bool FixedTimeEquals(string expected, string actual)
		{
			bool flag = expected == null || actual == null || expected.Length != actual.Length;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				int difference = 0;
				for (int i = 0; i < expected.Length; i++)
				{
					difference |= (int)(expected[i] ^ actual[i]);
				}
				result = (difference == 0);
			}
			return result;
		}

		// Token: 0x0600225A RID: 8794 RVA: 0x000D181C File Offset: 0x000CFA1C
		private static string Normalize(string key)
		{
			bool flag = string.IsNullOrWhiteSpace(key);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new string((from c in key
				where !char.IsWhiteSpace(c)
				select c).ToArray<char>()).ToUpperInvariant();
			}
			return result;
		}

		// Token: 0x0600225B RID: 8795 RVA: 0x000D1870 File Offset: 0x000CFA70
		private static LicenseState Load()
		{
			LicenseState result;
			try
			{
				string path = LicenseService.GetConfigPath();
				bool flag = !File.Exists(path);
				if (flag)
				{
					result = null;
				}
				else
				{
					result = JsonConvert.DeserializeObject<LicenseState>(File.ReadAllText(path));
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600225C RID: 8796 RVA: 0x000D18BC File Offset: 0x000CFABC
		private static void Save(LicenseState state)
		{
			try
			{
				string path = LicenseService.GetConfigPath();
				string folder = Path.GetDirectoryName(path);
				bool flag = !string.IsNullOrEmpty(folder);
				if (flag)
				{
					Manager_path.Creat_path(folder);
				}
				File.WriteAllText(path, JsonConvert.SerializeObject(state, Formatting.Indented));
			}
			catch
			{
			}
		}

		// Token: 0x04000E2A RID: 3626
		private const string SigningSecret = "VisionMachine-License-v1-9F2A64C1B7E34D80";

		// Token: 0x04000E2B RID: 3627
		private static readonly object SyncRoot = new object();

		// Token: 0x04000E2C RID: 3628
		private static LicenseState _state;

		// Token: 0x04000E2D RID: 3629
		[TupleElementNames(new string[]
		{
			"Code",
			"Name"
		})]
		private static readonly ValueTuple<char, string>[] Editions = new ValueTuple<char, string>[]
		{
			new ValueTuple<char, string>('S', "Standard"),
			new ValueTuple<char, string>('P', "Professional"),
			new ValueTuple<char, string>('E', "Enterprise")
		};

		// Token: 0x04000E2E RID: 3630
		public static readonly DateTime PerpetualDate = new DateTime(9999, 12, 31);
	}
}
