﻿using System;

namespace VisionMachine.Services.Licensing
{
	// Token: 0x02000265 RID: 613
	public class LicenseState
	{
		// Token: 0x170009D5 RID: 2517
		// (get) Token: 0x06002236 RID: 8758 RVA: 0x000D0FB3 File Offset: 0x000CF1B3
		// (set) Token: 0x06002237 RID: 8759 RVA: 0x000D0FBB File Offset: 0x000CF1BB
		public bool IsActivated { get; set; }

		// Token: 0x170009D6 RID: 2518
		// (get) Token: 0x06002238 RID: 8760 RVA: 0x000D0FC4 File Offset: 0x000CF1C4
		// (set) Token: 0x06002239 RID: 8761 RVA: 0x000D0FCC File Offset: 0x000CF1CC
		public string Key { get; set; }

		// Token: 0x170009D7 RID: 2519
		// (get) Token: 0x0600223A RID: 8762 RVA: 0x000D0FD5 File Offset: 0x000CF1D5
		// (set) Token: 0x0600223B RID: 8763 RVA: 0x000D0FDD File Offset: 0x000CF1DD
		public string MachineId { get; set; }

		// Token: 0x170009D8 RID: 2520
		// (get) Token: 0x0600223C RID: 8764 RVA: 0x000D0FE6 File Offset: 0x000CF1E6
		// (set) Token: 0x0600223D RID: 8765 RVA: 0x000D0FEE File Offset: 0x000CF1EE
		public DateTime? ActivatedAt { get; set; }

		// Token: 0x170009D9 RID: 2521
		// (get) Token: 0x0600223E RID: 8766 RVA: 0x000D0FF7 File Offset: 0x000CF1F7
		// (set) Token: 0x0600223F RID: 8767 RVA: 0x000D0FFF File Offset: 0x000CF1FF
		public DateTime? ExpiresAt { get; set; }

		// Token: 0x170009DA RID: 2522
		// (get) Token: 0x06002240 RID: 8768 RVA: 0x000D1008 File Offset: 0x000CF208
		// (set) Token: 0x06002241 RID: 8769 RVA: 0x000D1010 File Offset: 0x000CF210
		public bool IsPerpetual { get; set; }

		// Token: 0x170009DB RID: 2523
		// (get) Token: 0x06002242 RID: 8770 RVA: 0x000D1019 File Offset: 0x000CF219
		// (set) Token: 0x06002243 RID: 8771 RVA: 0x000D1021 File Offset: 0x000CF221
		public string Edition { get; set; }
	}
}
