﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Management;
using System.Security.Cryptography;
using System.Text;

namespace VisionMachine.Services.Licensing
{
	// Token: 0x02000264 RID: 612
	public static class MachineIdService
	{
		// Token: 0x0600222D RID: 8749 RVA: 0x000D0AF8 File Offset: 0x000CECF8
		public static string GetMachineId()
		{
			object syncRoot = MachineIdService.SyncRoot;
			string cached;
			lock (syncRoot)
			{
				bool flag2 = MachineIdService._cached != null;
				if (flag2)
				{
					cached = MachineIdService._cached;
				}
				else
				{
					string source = MachineIdService.ReadSystemDiskSerial();
					MachineIdService._cached = (string.IsNullOrWhiteSpace(source) ? "UNAVAILABLE" : MachineIdService.Format(MachineIdService.Hash(source)));
					cached = MachineIdService._cached;
				}
			}
			return cached;
		}

		// Token: 0x170009D4 RID: 2516
		// (get) Token: 0x0600222E RID: 8750 RVA: 0x000D0B78 File Offset: 0x000CED78
		public static bool IsAvailable
		{
			get
			{
				return MachineIdService.GetMachineId() != "UNAVAILABLE";
			}
		}

		// Token: 0x0600222F RID: 8751 RVA: 0x000D0B9C File Offset: 0x000CED9C
		private static string ReadSystemDiskSerial()
		{
			string systemDrive = MachineIdService.GetSystemDriveLetter();
			try
			{
				string partitionQuery = "ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='" + systemDrive + "'} WHERE AssocClass=Win32_LogicalDiskToPartition";
				using (ManagementObjectSearcher partitions = new ManagementObjectSearcher(partitionQuery))
				{
					foreach (ManagementBaseObject managementBaseObject in partitions.Get())
					{
						ManagementObject partition = (ManagementObject)managementBaseObject;
						string driveQuery = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='" + Convert.ToString(partition["DeviceID"]) + "'} WHERE AssocClass=Win32_DiskDriveToDiskPartition";
						using (ManagementObjectSearcher drives = new ManagementObjectSearcher(driveQuery))
						{
							foreach (ManagementBaseObject managementBaseObject2 in drives.Get())
							{
								ManagementObject drive = (ManagementObject)managementBaseObject2;
								string serial = Convert.ToString(drive["SerialNumber"]);
								bool flag = !string.IsNullOrWhiteSpace(serial);
								if (flag)
								{
									return serial.Trim();
								}
							}
						}
					}
				}
			}
			catch
			{
			}
			return MachineIdService.ReadVolumeSerial(systemDrive);
		}

		// Token: 0x06002230 RID: 8752 RVA: 0x000D0D44 File Offset: 0x000CEF44
		private static string ReadVolumeSerial(string systemDrive)
		{
			try
			{
				using (ManagementObject volume = new ManagementObject("Win32_LogicalDisk.DeviceID='" + systemDrive + "'"))
				{
					volume.Get();
					string serial = Convert.ToString(volume["VolumeSerialNumber"]);
					bool flag = !string.IsNullOrWhiteSpace(serial);
					if (flag)
					{
						return "VOL:" + serial.Trim();
					}
				}
			}
			catch
			{
			}
			return null;
		}

		// Token: 0x06002231 RID: 8753 RVA: 0x000D0DDC File Offset: 0x000CEFDC
		private static string GetSystemDriveLetter()
		{
			string drive = Environment.GetEnvironmentVariable("SystemDrive");
			return string.IsNullOrWhiteSpace(drive) ? "C:" : drive.Trim();
		}

		// Token: 0x06002232 RID: 8754 RVA: 0x000D0E10 File Offset: 0x000CF010
		public static string Normalize(string text)
		{
			bool flag = string.IsNullOrWhiteSpace(text);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string bare = new string((from c in text
				where !char.IsWhiteSpace(c) && c != '-'
				select c).ToArray<char>()).ToUpperInvariant();
				bool flag2 = bare.Length != 28 || !bare.All(new Func<char, bool>(Uri.IsHexDigit));
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = string.Join("-", from i in Enumerable.Range(0, bare.Length / 4)
					select bare.Substring(i * 4, 4));
				}
			}
			return result;
		}

		// Token: 0x06002233 RID: 8755 RVA: 0x000D0ED8 File Offset: 0x000CF0D8
		private static byte[] Hash(string source)
		{
			byte[] result;
			using (SHA256 sha = SHA256.Create())
			{
				result = sha.ComputeHash(Encoding.UTF8.GetBytes("VisionMachine|" + source));
			}
			return result;
		}

		// Token: 0x06002234 RID: 8756 RVA: 0x000D0F28 File Offset: 0x000CF128
		private static string Format(byte[] hash)
		{
			string hex = string.Concat(from b in hash.Take(14)
			select b.ToString("X2", CultureInfo.InvariantCulture));
			IEnumerable<string> groups = from i in Enumerable.Range(0, hex.Length / 4)
			select hex.Substring(i * 4, 4);
			return string.Join("-", groups);
		}

		// Token: 0x04000E1D RID: 3613
		private static readonly object SyncRoot = new object();

		// Token: 0x04000E1E RID: 3614
		private static string _cached;

		// Token: 0x04000E1F RID: 3615
		public const string Unavailable = "UNAVAILABLE";
	}
}
