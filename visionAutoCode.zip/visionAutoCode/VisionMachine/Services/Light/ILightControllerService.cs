﻿using System;
using System.Collections.Generic;
using VisionMachine.Models.Light;

namespace VisionMachine.Services.Light
{
	// Token: 0x0200026F RID: 623
	public interface ILightControllerService
	{
		// Token: 0x0600229D RID: 8861
		List<ConnectedLightInfo> EnumerateConnectedLights();

		// Token: 0x0600229E RID: 8862
		int GetChannelCount(string serialNumber);

		// Token: 0x0600229F RID: 8863
		void GetBrightnessRange(string serialNumber, out double min, out double max);

		// Token: 0x060022A0 RID: 8864
		bool Connect(string serialNumber, out string message);

		// Token: 0x060022A1 RID: 8865
		bool SetChannelOutput(string serialNumber, int channel, bool on, double brightness, out string message);

		// Token: 0x060022A2 RID: 8866
		void Disconnect();
	}
}
