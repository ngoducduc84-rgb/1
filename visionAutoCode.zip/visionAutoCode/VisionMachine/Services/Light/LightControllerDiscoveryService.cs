﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Security;
using VisionMachine.Models.Light;

namespace VisionMachine.Services.Light
{
	// Token: 0x02000271 RID: 625
	public static class LightControllerDiscoveryService
	{
		// Token: 0x060022BB RID: 8891 RVA: 0x000D3C50 File Offset: 0x000D1E50
		public static List<ConnectedLightInfo> EnumerateConnectedLights()
		{
			List<ConnectedLightInfo> result = new List<ConnectedLightInfo>();
			try
			{
				using (IEnumerator<ConnectedLightInfo> enumerator = LightControllerDiscoveryService.EnumerateMvsLights().GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						ConnectedLightInfo light = enumerator.Current;
						bool flag = light == null || string.IsNullOrWhiteSpace(light.Id);
						if (!flag)
						{
							bool flag2 = result.Any((ConnectedLightInfo x) => x.Id == light.Id);
							if (!flag2)
							{
								result.Add(light);
							}
						}
					}
				}
			}
			catch
			{
			}
			return result;
		}

		// Token: 0x060022BC RID: 8892 RVA: 0x000D3D10 File Offset: 0x000D1F10
		private static IEnumerable<ConnectedLightInfo> EnumerateMvsLights()
		{
			return new LightControllerDiscoveryService.<EnumerateMvsLights>d__1(-2);
		}

		// Token: 0x060022BD RID: 8893 RVA: 0x000D3D1C File Offset: 0x000D1F1C
		private static bool IsLightController(object deviceInfo)
		{
			return deviceInfo != null;
		}

		// Token: 0x060022BE RID: 8894 RVA: 0x000D3D34 File Offset: 0x000D1F34
		[HandleProcessCorruptedStateExceptions]
		[SecurityCritical]
		private static bool SafeInvoke(MethodInfo method, object target, object[] args)
		{
			bool result;
			try
			{
				method.Invoke(target, args);
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060022BF RID: 8895 RVA: 0x000D3D68 File Offset: 0x000D1F68
		private static object BuildLayerMask(Type layerType)
		{
			int mask = 0;
			string[] names = new string[]
			{
				"MvGigEDevice",
				"MvUsbDevice",
				"MvVirGigEDevice",
				"MvVirUsbDevice",
				"MvGenTLGigEDevice"
			};
			foreach (string name in names)
			{
				try
				{
					object value = Enum.Parse(layerType, name);
					mask |= Convert.ToInt32(value);
				}
				catch
				{
				}
			}
			bool flag = mask <= 0;
			if (flag)
			{
				mask = -1;
			}
			return Enum.ToObject(layerType, mask);
		}

		// Token: 0x060022C0 RID: 8896 RVA: 0x000D3E08 File Offset: 0x000D2008
		private static string GetPropertyValue(object target, string propertyName)
		{
			string result;
			try
			{
				string text;
				if (target == null)
				{
					text = null;
				}
				else
				{
					PropertyInfo property = target.GetType().GetProperty(propertyName);
					if (property == null)
					{
						text = null;
					}
					else
					{
						object value = property.GetValue(target, null);
						text = ((value != null) ? value.ToString() : null);
					}
				}
				result = text;
			}
			catch
			{
				result = null;
			}
			return result;
		}
	}
}
