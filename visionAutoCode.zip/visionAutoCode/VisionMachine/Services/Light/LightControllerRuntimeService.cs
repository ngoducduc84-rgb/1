﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using VisionMachine.Models.Light;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Light
{
	// Token: 0x02000272 RID: 626
	public static class LightControllerRuntimeService
	{
		// Token: 0x170009EF RID: 2543
		// (get) Token: 0x060022C1 RID: 8897 RVA: 0x000D3E60 File Offset: 0x000D2060
		// (set) Token: 0x060022C2 RID: 8898 RVA: 0x000D3E77 File Offset: 0x000D2077
		public static ILightControllerService Service
		{
			get
			{
				return LightControllerRuntimeService._service;
			}
			set
			{
				LightControllerRuntimeService._service = (value ?? new MvsLightControllerService());
			}
		}

		// Token: 0x060022C3 RID: 8899 RVA: 0x000D3E8C File Offset: 0x000D208C
		public static List<ConnectedLightInfo> EnumerateConnectedLights()
		{
			return LightControllerRuntimeService._service.EnumerateConnectedLights();
		}

		// Token: 0x060022C4 RID: 8900 RVA: 0x000D3EA8 File Offset: 0x000D20A8
		public static int GetChannelCount(string serialNumber)
		{
			return LightControllerRuntimeService._service.GetChannelCount(serialNumber);
		}

		// Token: 0x060022C5 RID: 8901 RVA: 0x000D3EC5 File Offset: 0x000D20C5
		public static void GetBrightnessRange(string serialNumber, out double min, out double max)
		{
			LightControllerRuntimeService._service.GetBrightnessRange(serialNumber, out min, out max);
		}

		// Token: 0x060022C6 RID: 8902 RVA: 0x000D3ED8 File Offset: 0x000D20D8
		public static bool Connect(string serialNumber, out string message)
		{
			return LightControllerRuntimeService._service.Connect(serialNumber, out message);
		}

		// Token: 0x060022C7 RID: 8903 RVA: 0x000D3EF8 File Offset: 0x000D20F8
		public static Task<bool> ConnectAsync(string serialNumber)
		{
			bool flag = string.IsNullOrWhiteSpace(serialNumber);
			Task<bool> result;
			if (flag)
			{
				result = Task.FromResult<bool>(false);
			}
			else
			{
				result = LightControllerRuntimeService.RunBackgroundCommandAsync(delegate
				{
					string message;
					bool ok = LightControllerRuntimeService.Connect(serialNumber, out message);
					bool flag2 = !ok && !string.IsNullOrWhiteSpace(message);
					if (flag2)
					{
						VisionLogService.Log("Warn", "Light controller connect failed: " + message);
					}
					return ok;
				});
			}
			return result;
		}

		// Token: 0x060022C8 RID: 8904 RVA: 0x000D3F40 File Offset: 0x000D2140
		public static bool ApplyChannel(LightControllerConfig config, int channel, out string message)
		{
			message = null;
			bool flag = config == null || string.IsNullOrWhiteSpace(config.SerialNumber);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				LightChannelConfig ch = config.GetOrCreateChannel(channel);
				bool on = ch.Mode == LightChannelMode.Manual && ch.IsOn;
				result = LightControllerRuntimeService._service.SetChannelOutput(config.SerialNumber, channel, on, ch.Brightness, out message);
			}
			return result;
		}

		// Token: 0x060022C9 RID: 8905 RVA: 0x000D3FA4 File Offset: 0x000D21A4
		public static void Disconnect()
		{
			LightControllerRuntimeService.CancelPendingUiCommand();
			try
			{
				LightControllerRuntimeService._service.Disconnect();
			}
			catch
			{
			}
		}

		// Token: 0x060022CA RID: 8906 RVA: 0x000D3FDC File Offset: 0x000D21DC
		public static void ApplyAll(LightControllerConfig config)
		{
			bool flag = config == null || string.IsNullOrWhiteSpace(config.SerialNumber) || config.Channels == null;
			if (!flag)
			{
				string connectMessage;
				bool flag2 = !LightControllerRuntimeService._service.Connect(config.SerialNumber, out connectMessage);
				if (!flag2)
				{
					foreach (LightChannelConfig ch in config.Channels)
					{
						bool on = ch.Mode == LightChannelMode.Manual && ch.IsOn;
						string text;
						LightControllerRuntimeService._service.SetChannelOutput(config.SerialNumber, ch.Channel, on, ch.Brightness, out text);
					}
				}
			}
		}

		// Token: 0x060022CB RID: 8907 RVA: 0x000D40A8 File Offset: 0x000D22A8
		public static bool ApplyAllWithReport(LightControllerConfig config, out List<string> messages)
		{
			messages = new List<string>();
			bool flag = config == null || string.IsNullOrWhiteSpace(config.SerialNumber) || config.Channels == null;
			bool result;
			if (flag)
			{
				messages.Add("No light controller is selected.");
				result = false;
			}
			else
			{
				string connectMessage;
				bool flag2 = !LightControllerRuntimeService._service.Connect(config.SerialNumber, out connectMessage);
				if (flag2)
				{
					messages.Add(string.IsNullOrWhiteSpace(connectMessage) ? "Light controller connection failed." : connectMessage);
					result = false;
				}
				else
				{
					bool allOk = true;
					foreach (LightChannelConfig ch in from x in config.Channels
					orderby x.Channel
					select x)
					{
						bool on = ch.Mode == LightChannelMode.Manual && ch.IsOn;
						string message;
						bool ok = LightControllerRuntimeService._service.SetChannelOutput(config.SerialNumber, ch.Channel, on, ch.Brightness, out message);
						allOk = (allOk && ok);
						bool flag3 = !string.IsNullOrWhiteSpace(message);
						if (flag3)
						{
							messages.Add(message);
						}
					}
					result = allOk;
				}
			}
			return result;
		}

		// Token: 0x060022CC RID: 8908 RVA: 0x000D41F4 File Offset: 0x000D23F4
		public static void QueueUiApply(LightControllerConfig config, int channel, bool applyAll, int debounceMs = 0)
		{
			LightControllerConfig snapshot = LightControllerRuntimeService.CloneConfig(config);
			bool flag = snapshot == null || string.IsNullOrWhiteSpace(snapshot.SerialNumber);
			if (!flag)
			{
				CancellationTokenSource cancellation = new CancellationTokenSource();
				object pendingCommandSync = LightControllerRuntimeService.PendingCommandSync;
				CancellationTokenSource previous;
				lock (pendingCommandSync)
				{
					previous = LightControllerRuntimeService._pendingUiCommand;
					LightControllerRuntimeService._pendingUiCommand = cancellation;
				}
				bool flag3 = previous != null;
				if (flag3)
				{
					previous.Cancel();
					previous.Dispose();
				}
				LightControllerRuntimeService.ObserveUiCommand(LightControllerRuntimeService.RunQueuedUiApplyAsync(snapshot, channel, applyAll, Math.Max(0, debounceMs), cancellation));
			}
		}

		// Token: 0x060022CD RID: 8909 RVA: 0x000D4298 File Offset: 0x000D2498
		public static Task<bool> ApplyAllAsync(LightControllerConfig config)
		{
			LightControllerConfig snapshot = LightControllerRuntimeService.CloneConfig(config);
			bool flag = snapshot == null || string.IsNullOrWhiteSpace(snapshot.SerialNumber);
			Task<bool> result;
			if (flag)
			{
				result = Task.FromResult<bool>(false);
			}
			else
			{
				result = LightControllerRuntimeService.RunBackgroundCommandAsync(delegate
				{
					List<string> messages;
					return LightControllerRuntimeService.ApplyAllWithReport(snapshot, out messages);
				});
			}
			return result;
		}

		// Token: 0x060022CE RID: 8910 RVA: 0x000D42F8 File Offset: 0x000D24F8
		public static bool IlluminateForTrigger(LightControllerConfig config)
		{
			bool flag = config == null || string.IsNullOrWhiteSpace(config.SerialNumber) || config.Channels == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool any = false;
				foreach (LightChannelConfig ch in from c in config.Channels
				where c.Mode == LightChannelMode.OnWhenTrigger
				select c)
				{
					string text;
					LightControllerRuntimeService._service.SetChannelOutput(config.SerialNumber, ch.Channel, true, ch.Brightness, out text);
					any = true;
				}
				result = any;
			}
			return result;
		}

		// Token: 0x060022CF RID: 8911 RVA: 0x000D43B8 File Offset: 0x000D25B8
		public static void EndTriggerIllumination(LightControllerConfig config)
		{
			bool flag = config == null || string.IsNullOrWhiteSpace(config.SerialNumber) || config.Channels == null;
			if (!flag)
			{
				foreach (LightChannelConfig ch in from c in config.Channels
				where c.Mode == LightChannelMode.OnWhenTrigger
				select c)
				{
					string text;
					LightControllerRuntimeService._service.SetChannelOutput(config.SerialNumber, ch.Channel, false, ch.Brightness, out text);
				}
			}
		}

		// Token: 0x060022D0 RID: 8912 RVA: 0x000D446C File Offset: 0x000D266C
		[DebuggerStepThrough]
		private static Task RunQueuedUiApplyAsync(LightControllerConfig snapshot, int channel, bool applyAll, int debounceMs, CancellationTokenSource cancellation)
		{
			LightControllerRuntimeService.<RunQueuedUiApplyAsync>d__20 <RunQueuedUiApplyAsync>d__ = new LightControllerRuntimeService.<RunQueuedUiApplyAsync>d__20();
			<RunQueuedUiApplyAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<RunQueuedUiApplyAsync>d__.snapshot = snapshot;
			<RunQueuedUiApplyAsync>d__.channel = channel;
			<RunQueuedUiApplyAsync>d__.applyAll = applyAll;
			<RunQueuedUiApplyAsync>d__.debounceMs = debounceMs;
			<RunQueuedUiApplyAsync>d__.cancellation = cancellation;
			<RunQueuedUiApplyAsync>d__.<>1__state = -1;
			<RunQueuedUiApplyAsync>d__.<>t__builder.Start<LightControllerRuntimeService.<RunQueuedUiApplyAsync>d__20>(ref <RunQueuedUiApplyAsync>d__);
			return <RunQueuedUiApplyAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060022D1 RID: 8913 RVA: 0x000D44D0 File Offset: 0x000D26D0
		[DebuggerStepThrough]
		private static Task<bool> RunBackgroundCommandAsync(Func<bool> command)
		{
			LightControllerRuntimeService.<RunBackgroundCommandAsync>d__21 <RunBackgroundCommandAsync>d__ = new LightControllerRuntimeService.<RunBackgroundCommandAsync>d__21();
			<RunBackgroundCommandAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<RunBackgroundCommandAsync>d__.command = command;
			<RunBackgroundCommandAsync>d__.<>1__state = -1;
			<RunBackgroundCommandAsync>d__.<>t__builder.Start<LightControllerRuntimeService.<RunBackgroundCommandAsync>d__21>(ref <RunBackgroundCommandAsync>d__);
			return <RunBackgroundCommandAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060022D2 RID: 8914 RVA: 0x000D4514 File Offset: 0x000D2714
		private static void ObserveUiCommand(Task task)
		{
			task.ContinueWith(delegate(Task completed)
			{
				AggregateException exception = completed.Exception;
				Exception error = (exception != null) ? exception.GetBaseException() : null;
				bool flag = error != null;
				if (flag)
				{
					VisionLogService.Log("Warn", "Light UI command failed: " + error.Message);
				}
			}, TaskContinuationOptions.OnlyOnFaulted);
		}

		// Token: 0x060022D3 RID: 8915 RVA: 0x000D4544 File Offset: 0x000D2744
		private static void CancelPendingUiCommand()
		{
			object pendingCommandSync = LightControllerRuntimeService.PendingCommandSync;
			CancellationTokenSource pending;
			lock (pendingCommandSync)
			{
				pending = LightControllerRuntimeService._pendingUiCommand;
				LightControllerRuntimeService._pendingUiCommand = null;
			}
			bool flag2 = pending == null;
			if (!flag2)
			{
				pending.Cancel();
			}
		}

		// Token: 0x060022D4 RID: 8916 RVA: 0x000D45A0 File Offset: 0x000D27A0
		private static LightControllerConfig CloneConfig(LightControllerConfig source)
		{
			bool flag = source == null;
			LightControllerConfig result;
			if (flag)
			{
				result = null;
			}
			else
			{
				LightControllerConfig lightControllerConfig = new LightControllerConfig();
				lightControllerConfig.SerialNumber = source.SerialNumber;
				lightControllerConfig.SelectedChannel = source.SelectedChannel;
				lightControllerConfig.ApplyToAllChannels = source.ApplyToAllChannels;
				List<LightChannelConfig> channels;
				if (source.Channels != null)
				{
					channels = (from channel in source.Channels
					where channel != null
					select new LightChannelConfig
					{
						Channel = channel.Channel,
						Mode = channel.Mode,
						IsOn = channel.IsOn,
						Brightness = channel.Brightness
					}).ToList<LightChannelConfig>();
				}
				else
				{
					channels = new List<LightChannelConfig>();
				}
				lightControllerConfig.Channels = channels;
				result = lightControllerConfig;
			}
			return result;
		}

		// Token: 0x04000E50 RID: 3664
		private static ILightControllerService _service = new MvsLightControllerService();

		// Token: 0x04000E51 RID: 3665
		private static readonly SemaphoreSlim BackgroundCommandGate = new SemaphoreSlim(1, 1);

		// Token: 0x04000E52 RID: 3666
		private static readonly object PendingCommandSync = new object();

		// Token: 0x04000E53 RID: 3667
		private static CancellationTokenSource _pendingUiCommand;
	}
}
