﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;
using VisionMachine.Models.Light;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Runtime;
using VisionMachine.ViewModels.Main;

namespace VisionMachine.Services.Light
{
	// Token: 0x02000273 RID: 627
	public static class LightModelConfigStorageService
	{
		// Token: 0x060022D6 RID: 8918 RVA: 0x000D4678 File Offset: 0x000D2878
		public static string GetCurrentModelLightConfigPath()
		{
			bool flag = ModelRuntimeStore.CurrentModel == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string modelName = RecipePathService.MakeSafeFileName(ModelRuntimeStore.CurrentModel.Model_name);
				string folder = Path.Combine(Manager_path._dataPath, modelName);
				bool flag2 = string.IsNullOrWhiteSpace(folder);
				if (flag2)
				{
					result = null;
				}
				else
				{
					Directory.CreateDirectory(folder);
					result = Path.Combine(folder, "light_config.json");
				}
			}
			return result;
		}

		// Token: 0x060022D7 RID: 8919 RVA: 0x000D46D8 File Offset: 0x000D28D8
		public static void SaveCurrentModelConfig(MainViewModel viewModel)
		{
			bool flag = viewModel == null || ModelRuntimeStore.CurrentModel == null;
			if (!flag)
			{
				string path = LightModelConfigStorageService.GetCurrentModelLightConfigPath();
				bool flag2 = string.IsNullOrWhiteSpace(path);
				if (!flag2)
				{
					string folder = Path.GetDirectoryName(path);
					bool flag3 = !string.IsNullOrWhiteSpace(folder) && !Directory.Exists(folder);
					if (flag3)
					{
						Directory.CreateDirectory(folder);
					}
					LightModelConfigData data = new LightModelConfigData
					{
						ModelName = ModelRuntimeStore.CurrentModel.Model_name,
						Light = (viewModel.LightConfig ?? new LightControllerConfig())
					};
					string json = JsonConvert.SerializeObject(data, Formatting.Indented);
					File.WriteAllText(path, json);
				}
			}
		}

		// Token: 0x060022D8 RID: 8920 RVA: 0x000D4778 File Offset: 0x000D2978
		public static void LoadCurrentModelConfig(MainViewModel viewModel)
		{
			bool flag = viewModel == null;
			if (!flag)
			{
				string path = LightModelConfigStorageService.GetCurrentModelLightConfigPath();
				bool flag2 = string.IsNullOrWhiteSpace(path) || !File.Exists(path);
				if (flag2)
				{
					bool flag3 = viewModel.LightConfig == null;
					if (flag3)
					{
						viewModel.LightConfig = new LightControllerConfig();
					}
				}
				else
				{
					string json = File.ReadAllText(path);
					bool flag4 = string.IsNullOrWhiteSpace(json);
					if (flag4)
					{
						bool flag5 = viewModel.LightConfig == null;
						if (flag5)
						{
							viewModel.LightConfig = new LightControllerConfig();
						}
					}
					else
					{
						LightModelConfigData data = JsonConvert.DeserializeObject<LightModelConfigData>(json);
						viewModel.LightConfig = (((data != null) ? data.Light : null) ?? new LightControllerConfig());
					}
				}
			}
		}
	}
}
