﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using VisionMachine.Models.Light;
using VisionMachine.Services.Runtime;
using VisionMachine.ViewModels.Main;

namespace VisionMachine.Services.Light
{
	// Token: 0x02000274 RID: 628
	public static class LightStartupApplyService
	{
		// Token: 0x060022D9 RID: 8921 RVA: 0x000D4828 File Offset: 0x000D2A28
		public static void ApplyCurrentModelAsync(MainViewModel viewModel, string reason, int delayMs = 1000)
		{
			LightStartupApplyService.<>c__DisplayClass2_0 CS$<>8__locals1 = new LightStartupApplyService.<>c__DisplayClass2_0();
			CS$<>8__locals1.delayMs = delayMs;
			CS$<>8__locals1.reason = reason;
			CS$<>8__locals1.snapshot = LightStartupApplyService.CloneConfig((viewModel != null) ? viewModel.LightConfig : null);
			bool flag = CS$<>8__locals1.snapshot == null || string.IsNullOrWhiteSpace(CS$<>8__locals1.snapshot.SerialNumber);
			if (flag)
			{
				VisionLogService.Log("Info", "Light config apply skipped: no light controller selected.");
			}
			else
			{
				object syncRoot = LightStartupApplyService.SyncRoot;
				lock (syncRoot)
				{
					LightStartupApplyService._requestId++;
					CS$<>8__locals1.requestId = LightStartupApplyService._requestId;
				}
				Task.Run(delegate()
				{
					LightStartupApplyService.<>c__DisplayClass2_0.<<ApplyCurrentModelAsync>b__0>d <<ApplyCurrentModelAsync>b__0>d = new LightStartupApplyService.<>c__DisplayClass2_0.<<ApplyCurrentModelAsync>b__0>d();
					<<ApplyCurrentModelAsync>b__0>d.<>t__builder = AsyncTaskMethodBuilder.Create();
					<<ApplyCurrentModelAsync>b__0>d.<>4__this = CS$<>8__locals1;
					<<ApplyCurrentModelAsync>b__0>d.<>1__state = -1;
					<<ApplyCurrentModelAsync>b__0>d.<>t__builder.Start<LightStartupApplyService.<>c__DisplayClass2_0.<<ApplyCurrentModelAsync>b__0>d>(ref <<ApplyCurrentModelAsync>b__0>d);
					return <<ApplyCurrentModelAsync>b__0>d.<>t__builder.Task;
				});
			}
		}

		// Token: 0x060022DA RID: 8922 RVA: 0x000D48EC File Offset: 0x000D2AEC
		private static LightControllerConfig CloneConfig(LightControllerConfig source)
		{
			bool flag = source == null;
			LightControllerConfig result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new LightControllerConfig
				{
					SerialNumber = source.SerialNumber,
					SelectedChannel = source.SelectedChannel,
					ApplyToAllChannels = source.ApplyToAllChannels,
					Channels = ((source.Channels == null) ? new List<LightChannelConfig>() : source.Channels.Select(new Func<LightChannelConfig, LightChannelConfig>(LightStartupApplyService.CloneChannel)).ToList<LightChannelConfig>())
				};
			}
			return result;
		}

		// Token: 0x060022DB RID: 8923 RVA: 0x000D496C File Offset: 0x000D2B6C
		private static LightChannelConfig CloneChannel(LightChannelConfig source)
		{
			bool flag = source == null;
			LightChannelConfig result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new LightChannelConfig
				{
					Channel = source.Channel,
					Mode = source.Mode,
					IsOn = source.IsOn,
					Brightness = source.Brightness
				};
			}
			return result;
		}

		// Token: 0x060022DC RID: 8924 RVA: 0x000D49C4 File Offset: 0x000D2BC4
		private static void NormalizeApplyAll(LightControllerConfig config)
		{
			bool flag = config == null || !config.ApplyToAllChannels;
			if (!flag)
			{
				LightChannelConfig source = config.GetOrCreateChannel(config.SelectedChannel);
				int val = 3;
				int val2;
				if (config.Channels != null && config.Channels.Count != 0)
				{
					val2 = config.Channels.Max((LightChannelConfig x) => x.Channel);
				}
				else
				{
					val2 = 3;
				}
				int maxChannel = Math.Max(val, val2);
				for (int channel = 0; channel <= maxChannel; channel++)
				{
					LightChannelConfig target = config.GetOrCreateChannel(channel);
					target.Mode = source.Mode;
					target.IsOn = source.IsOn;
					target.Brightness = source.Brightness;
				}
			}
		}

		// Token: 0x04000E54 RID: 3668
		private static readonly object SyncRoot = new object();

		// Token: 0x04000E55 RID: 3669
		private static int _requestId;
	}
}
