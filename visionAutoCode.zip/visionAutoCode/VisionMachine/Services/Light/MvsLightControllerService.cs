﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;
using System.Security;
using System.Text.RegularExpressions;
using VisionMachine.Models.Light;
using VisionMachine.Services.Camera;

namespace VisionMachine.Services.Light
{
	// Token: 0x02000270 RID: 624
	public class MvsLightControllerService : ILightControllerService
	{
		// Token: 0x060022A3 RID: 8867 RVA: 0x000D2D84 File Offset: 0x000D0F84
		public List<ConnectedLightInfo> EnumerateConnectedLights()
		{
			return LightControllerDiscoveryService.EnumerateConnectedLights();
		}

		// Token: 0x060022A4 RID: 8868 RVA: 0x000D2D9C File Offset: 0x000D0F9C
		public int GetChannelCount(string serialNumber)
		{
			bool flag = string.IsNullOrWhiteSpace(serialNumber);
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				ConnectedLightInfo info = this.EnumerateConnectedLights().FirstOrDefault((ConnectedLightInfo x) => x.Id == serialNumber);
				result = ((info != null) ? info.ChannelCount : 4);
			}
			return result;
		}

		// Token: 0x060022A5 RID: 8869 RVA: 0x000D2DF4 File Offset: 0x000D0FF4
		public void GetBrightnessRange(string serialNumber, out double min, out double max)
		{
			object sync = this._sync;
			lock (sync)
			{
				bool flag2 = !string.IsNullOrWhiteSpace(serialNumber) && serialNumber == this._connectedSerial && this._brightnessMax > this._brightnessMin;
				if (flag2)
				{
					min = this._brightnessMin;
					max = this._brightnessMax;
					return;
				}
			}
			min = 0.0;
			max = 255.0;
		}

		// Token: 0x060022A6 RID: 8870 RVA: 0x000D2E88 File Offset: 0x000D1088
		public bool Connect(string serialNumber, out string message)
		{
			bool flag = string.IsNullOrWhiteSpace(serialNumber);
			bool result;
			if (flag)
			{
				message = "No light controller is selected.";
				result = false;
			}
			else
			{
				object sync = this._sync;
				lock (sync)
				{
					result = this.EnsureConnected(serialNumber, out message);
				}
			}
			return result;
		}

		// Token: 0x060022A7 RID: 8871 RVA: 0x000D2EE8 File Offset: 0x000D10E8
		public bool SetChannelOutput(string serialNumber, int channel, bool on, double brightness, out string message)
		{
			bool flag = string.IsNullOrWhiteSpace(serialNumber);
			bool result;
			if (flag)
			{
				message = "No light controller is selected.";
				result = false;
			}
			else
			{
				object sync = this._sync;
				lock (sync)
				{
					try
					{
						bool flag3 = !this.EnsureConnected(serialNumber, out message);
						if (flag3)
						{
							result = false;
						}
						else
						{
							object parameters = MvsLightControllerService.GetProperty(this._device, "Parameters");
							bool flag4 = parameters == null;
							if (flag4)
							{
								message = "Light controller has no parameter interface.";
								MvsLightControllerService.Log(message);
								result = false;
							}
							else
							{
								MvsLightControllerService.Log("Disable sync output via 'LightSyncOutput' -> " + (MvsLightControllerService.TrySetBool(parameters, "LightSyncOutput", false) || MvsLightControllerService.TrySetInt(parameters, "LightSyncOutput", 0L)).ToString());
								uint deviceChannel = (uint)(channel + 1);
								bool okSel = MvsLightControllerService.TrySetEnumInt(parameters, "LightControllerSelector", deviceChannel) || MvsLightControllerService.TrySetEnumString(parameters, "LightControllerSelector", "LightController" + deviceChannel.ToString());
								MvsLightControllerService.Log("Select channel " + deviceChannel.ToString() + " via 'LightControllerSelector' -> " + okSel.ToString());
								bool okBright = MvsLightControllerService.TrySetInt(parameters, "LightBrightness", (long)Math.Round(brightness));
								MvsLightControllerService.Log("Brightness " + brightness.ToString("0") + " via 'LightBrightness' -> " + okBright.ToString());
								uint srcVal = on ? 1U : 255U;
								string srcName = on ? "On" : "Off";
								bool okSrc = MvsLightControllerService.TrySetEnumInt(parameters, "LightControllerSource", srcVal) || MvsLightControllerService.TrySetEnumString(parameters, "LightControllerSource", srcName);
								MvsLightControllerService.Log(string.Concat(new string[]
								{
									"Channel ",
									deviceChannel.ToString(),
									" Source=",
									srcName,
									" via 'LightControllerSource' -> ",
									okSrc.ToString()
								}));
								message = string.Concat(new string[]
								{
									"Channel ",
									deviceChannel.ToString(),
									": ",
									srcName,
									" @ ",
									brightness.ToString("0"),
									okSrc ? " (sent)" : " (source set failed - see light_log.txt)"
								});
								result = okSrc;
							}
						}
					}
					catch (Exception ex)
					{
						message = "Apply failed: " + ex.Message;
						string str = message;
						string str2 = " | ";
						Exception ex2 = ex;
						MvsLightControllerService.Log(str + str2 + ((ex2 != null) ? ex2.ToString() : null));
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x060022A8 RID: 8872 RVA: 0x000D31A0 File Offset: 0x000D13A0
		public void Disconnect()
		{
			object sync = this._sync;
			lock (sync)
			{
				this.DisconnectLocked();
			}
		}

		// Token: 0x060022A9 RID: 8873 RVA: 0x000D31E8 File Offset: 0x000D13E8
		[HandleProcessCorruptedStateExceptions]
		[SecurityCritical]
		private bool EnsureConnected(string serialNumber, out string message)
		{
			message = null;
			bool flag = this._device != null && this._connectedSerial == serialNumber && this.IsDeviceConnected(this._device);
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				this.DisconnectLocked();
				Assembly assembly = CameraSdkAssemblyLoader.LoadHikvisionMvs();
				bool flag2 = assembly == null;
				if (flag2)
				{
					message = "MVS SDK is not available.";
					MvsLightControllerService.Log(message);
					result = false;
				}
				else
				{
					try
					{
						object deviceInfo = MvsLightControllerService.FindDeviceInfoBySerial(assembly, serialNumber);
						bool flag3 = deviceInfo == null;
						if (flag3)
						{
							message = "Light controller '" + serialNumber + "' was not found on the network.";
							MvsLightControllerService.Log(message);
							result = false;
						}
						else
						{
							Type factoryType = assembly.GetType("MvCameraControl.DeviceFactory");
							MethodInfo methodInfo;
							if (factoryType == null)
							{
								methodInfo = null;
							}
							else
							{
								methodInfo = factoryType.GetMethods(BindingFlags.Static | BindingFlags.Public).FirstOrDefault((MethodInfo x) => x.Name == "CreateDevice" && x.GetParameters().Length == 1);
							}
							MethodInfo createMethod = methodInfo;
							object device = (createMethod != null) ? createMethod.Invoke(null, new object[]
							{
								deviceInfo
							}) : null;
							bool flag4 = device == null;
							if (flag4)
							{
								message = "Failed to create the light controller device.";
								MvsLightControllerService.Log(message);
								result = false;
							}
							else
							{
								bool flag5 = !MvsLightControllerService.IsSuccess(MvsLightControllerService.InvokeMethod(device, "Open", Array.Empty<object>()));
								if (flag5)
								{
									message = "Failed to open the light controller.";
									MvsLightControllerService.Log(message);
									MvsLightControllerService.TryDispose(device);
									result = false;
								}
								else
								{
									this._device = device;
									this._connectedSerial = serialNumber;
									MvsLightControllerService.Log("Connected to light controller '" + serialNumber + "'.");
									this.ReadBrightnessRange();
									bool flag6 = string.Equals(Environment.GetEnvironmentVariable("VISIONMACHINE_DUMP_LIGHT_NODES"), "1", StringComparison.Ordinal);
									if (flag6)
									{
										this.DumpNodeXml(serialNumber);
									}
									result = true;
								}
							}
						}
					}
					catch (Exception ex)
					{
						message = "Connect failed: " + ex.Message;
						MvsLightControllerService.Log(message);
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x060022AA RID: 8874 RVA: 0x000D33E0 File Offset: 0x000D15E0
		private void DisconnectLocked()
		{
			bool flag = this._device != null;
			if (flag)
			{
				try
				{
					MvsLightControllerService.InvokeMethod(this._device, "Close", Array.Empty<object>());
				}
				catch
				{
				}
				MvsLightControllerService.TryDispose(this._device);
			}
			this._device = null;
			this._connectedSerial = null;
			this._brightnessMin = 0.0;
			this._brightnessMax = 255.0;
		}

		// Token: 0x060022AB RID: 8875 RVA: 0x000D3464 File Offset: 0x000D1664
		private bool IsDeviceConnected(object device)
		{
			bool result;
			try
			{
				object value = MvsLightControllerService.GetProperty(device, "IsConnected");
				bool b;
				bool flag;
				if (value is bool)
				{
					b = (bool)value;
					flag = true;
				}
				else
				{
					flag = false;
				}
				result = (flag && b);
			}
			catch
			{
				result = true;
			}
			return result;
		}

		// Token: 0x060022AC RID: 8876 RVA: 0x000D34B0 File Offset: 0x000D16B0
		private void ReadBrightnessRange()
		{
			this._brightnessMin = 0.0;
			this._brightnessMax = 255.0;
			try
			{
				object parameters = MvsLightControllerService.GetProperty(this._device, "Parameters");
				bool flag = parameters == null;
				if (!flag)
				{
					MethodInfo getInt = parameters.GetType().GetMethods().FirstOrDefault((MethodInfo x) => x.Name == "GetIntValue" && x.GetParameters().Length == 2);
					bool flag2 = getInt == null;
					if (!flag2)
					{
						object[] array = new object[2];
						array[0] = "LightBrightness";
						object[] args = array;
						object ret = getInt.Invoke(parameters, args);
						bool flag3 = !MvsLightControllerService.IsSuccess(ret) || args[1] == null;
						if (!flag3)
						{
							object min = MvsLightControllerService.GetProperty(args[1], "Min");
							object max = MvsLightControllerService.GetProperty(args[1], "Max");
							bool flag4 = min != null;
							if (flag4)
							{
								this._brightnessMin = Convert.ToDouble(min);
							}
							bool flag5 = max != null && Convert.ToDouble(max) > this._brightnessMin;
							if (flag5)
							{
								this._brightnessMax = Convert.ToDouble(max);
							}
							MvsLightControllerService.Log("Brightness range read: " + this._brightnessMin.ToString() + " .. " + this._brightnessMax.ToString());
						}
					}
				}
			}
			catch (Exception ex)
			{
				MvsLightControllerService.Log("Brightness range read failed: " + ex.Message);
			}
		}

		// Token: 0x060022AD RID: 8877 RVA: 0x000D363C File Offset: 0x000D183C
		private void DumpNodeXml(string serial)
		{
			try
			{
				object parameters = MvsLightControllerService.GetProperty(this._device, "Parameters");
				MethodInfo methodInfo;
				if (parameters == null)
				{
					methodInfo = null;
				}
				else
				{
					methodInfo = parameters.GetType().GetMethods().FirstOrDefault((MethodInfo x) => x.Name == "GetGenICamXML" && x.GetParameters().Length == 1);
				}
				MethodInfo getXml = methodInfo;
				bool flag = getXml == null;
				if (!flag)
				{
					object[] args = new object[1];
					getXml.Invoke(parameters, args);
					string xml = args[0] as string;
					bool flag2 = string.IsNullOrWhiteSpace(xml);
					if (!flag2)
					{
						string safe = Regex.Replace(serial ?? "device", "[^\\w\\-]", "_");
						File.WriteAllText(Path.Combine(MvsLightControllerService.LogFolder, "light_nodes_" + safe + ".xml"), xml);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060022AE RID: 8878 RVA: 0x000D3720 File Offset: 0x000D1920
		[HandleProcessCorruptedStateExceptions]
		[SecurityCritical]
		private static object FindDeviceInfoBySerial(Assembly assembly, string serial)
		{
			Type layerType = assembly.GetType("MvCameraControl.DeviceTLayerType");
			Type deviceInfoType = assembly.GetType("MvCameraControl.IDeviceInfo");
			Type deviceEnumeratorType = assembly.GetType("MvCameraControl.DeviceEnumerator");
			bool flag = layerType == null || deviceInfoType == null || deviceEnumeratorType == null;
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				Type deviceListType = typeof(List<>).MakeGenericType(new Type[]
				{
					deviceInfoType
				});
				MethodInfo enumDevicesMethod = deviceEnumeratorType.GetMethods(BindingFlags.Static | BindingFlags.Public).FirstOrDefault(delegate(MethodInfo m)
				{
					bool flag5 = m.Name != "EnumDevices";
					bool result2;
					if (flag5)
					{
						result2 = false;
					}
					else
					{
						ParameterInfo[] p = m.GetParameters();
						Type listType = (p.Length == 2 && p[1].ParameterType.IsByRef) ? p[1].ParameterType.GetElementType() : ((p.Length == 2) ? p[1].ParameterType : null);
						result2 = (p.Length == 2 && p[0].ParameterType == layerType && listType == deviceListType);
					}
					return result2;
				});
				bool flag2 = enumDevicesMethod == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					object devices = Activator.CreateInstance(deviceListType);
					object layerMask = Enum.ToObject(layerType, -1);
					object mvsEnumerationLock = CameraSdkAssemblyLoader.MvsEnumerationLock;
					lock (mvsEnumerationLock)
					{
						object[] args = new object[]
						{
							layerMask,
							devices
						};
						try
						{
							enumDevicesMethod.Invoke(null, args);
						}
						catch
						{
							return null;
						}
						devices = (args[1] ?? devices);
					}
					foreach (object deviceInfo in (devices as IEnumerable))
					{
						object property = MvsLightControllerService.GetProperty(deviceInfo, "SerialNumber");
						string s = (property != null) ? property.ToString() : null;
						bool flag4 = s == serial;
						if (flag4)
						{
							return deviceInfo;
						}
					}
					result = null;
				}
			}
			return result;
		}

		// Token: 0x060022AF RID: 8879 RVA: 0x000D38EC File Offset: 0x000D1AEC
		private static bool TrySetInt(object parameters, string node, long value)
		{
			return MvsLightControllerService.InvokeParam(parameters, "SetIntValue", node, value, typeof(long));
		}

		// Token: 0x060022B0 RID: 8880 RVA: 0x000D391C File Offset: 0x000D1B1C
		private static bool TrySetEnumInt(object parameters, string node, uint value)
		{
			return MvsLightControllerService.InvokeParam(parameters, "SetEnumValue", node, value, typeof(uint));
		}

		// Token: 0x060022B1 RID: 8881 RVA: 0x000D394C File Offset: 0x000D1B4C
		private static bool TrySetEnumString(object parameters, string node, string value)
		{
			return MvsLightControllerService.InvokeParam(parameters, "SetEnumValueByString", node, value, typeof(string));
		}

		// Token: 0x060022B2 RID: 8882 RVA: 0x000D3978 File Offset: 0x000D1B78
		private static bool TrySetBool(object parameters, string node, bool value)
		{
			return MvsLightControllerService.InvokeParam(parameters, "SetBoolValue", node, value, typeof(bool));
		}

		// Token: 0x060022B3 RID: 8883 RVA: 0x000D39A8 File Offset: 0x000D1BA8
		private static bool InvokeParam(object parameters, string methodName, string node, object value, Type valueType)
		{
			bool flag = parameters == null || string.IsNullOrWhiteSpace(node);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				MethodInfo method = parameters.GetType().GetMethods().FirstOrDefault(delegate(MethodInfo x)
				{
					bool flag3 = x.Name != methodName;
					bool result2;
					if (flag3)
					{
						result2 = false;
					}
					else
					{
						ParameterInfo[] p = x.GetParameters();
						result2 = (p.Length == 2 && p[0].ParameterType == typeof(string) && p[1].ParameterType == valueType);
					}
					return result2;
				});
				bool flag2 = method == null;
				if (flag2)
				{
					result = false;
				}
				else
				{
					try
					{
						result = MvsLightControllerService.IsSuccess(method.Invoke(parameters, new object[]
						{
							node,
							value
						}));
					}
					catch
					{
						result = false;
					}
				}
			}
			return result;
		}

		// Token: 0x060022B4 RID: 8884 RVA: 0x000D3A44 File Offset: 0x000D1C44
		private static object InvokeMethod(object target, string methodName, params object[] args)
		{
			bool flag = target == null;
			object result;
			if (flag)
			{
				result = null;
			}
			else
			{
				MethodInfo method = target.GetType().GetMethods().FirstOrDefault(delegate(MethodInfo x)
				{
					bool result2;
					if (x.Name == methodName)
					{
						int num = x.GetParameters().Length;
						object[] args2 = args;
						result2 = (num == ((args2 != null) ? args2.Length : 0));
					}
					else
					{
						result2 = false;
					}
					return result2;
				});
				result = ((method != null) ? method.Invoke(target, args ?? new object[0]) : null);
			}
			return result;
		}

		// Token: 0x060022B5 RID: 8885 RVA: 0x000D3AB0 File Offset: 0x000D1CB0
		private static object GetProperty(object target, string propertyName)
		{
			object result;
			try
			{
				object obj;
				if (target == null)
				{
					obj = null;
				}
				else
				{
					PropertyInfo property = target.GetType().GetProperty(propertyName);
					obj = ((property != null) ? property.GetValue(target, null) : null);
				}
				result = obj;
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060022B6 RID: 8886 RVA: 0x000D3AFC File Offset: 0x000D1CFC
		private static bool IsSuccess(object result)
		{
			bool flag = result == null;
			bool result2;
			if (flag)
			{
				result2 = true;
			}
			else
			{
				try
				{
					result2 = (Convert.ToInt32(result) == 0);
				}
				catch
				{
					result2 = false;
				}
			}
			return result2;
		}

		// Token: 0x060022B7 RID: 8887 RVA: 0x000D3B3C File Offset: 0x000D1D3C
		private static void TryDispose(object target)
		{
			try
			{
				IDisposable disposable = target as IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x170009EE RID: 2542
		// (get) Token: 0x060022B8 RID: 8888 RVA: 0x000D3B78 File Offset: 0x000D1D78
		private static string LogFolder
		{
			get
			{
				string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VisionMachine");
				Directory.CreateDirectory(folder);
				return folder;
			}
		}

		// Token: 0x060022B9 RID: 8889 RVA: 0x000D3BA4 File Offset: 0x000D1DA4
		private static void Log(string message)
		{
			try
			{
				File.AppendAllText(Path.Combine(MvsLightControllerService.LogFolder, "light_log.txt"), string.Concat(new string[]
				{
					"[",
					DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
					"] ",
					message,
					Environment.NewLine
				}));
			}
			catch
			{
			}
		}

		// Token: 0x04000E43 RID: 3651
		private const string NodeSelector = "LightControllerSelector";

		// Token: 0x04000E44 RID: 3652
		private const string NodeBrightness = "LightBrightness";

		// Token: 0x04000E45 RID: 3653
		private const string NodeSource = "LightControllerSource";

		// Token: 0x04000E46 RID: 3654
		private const string NodeSyncOutput = "LightSyncOutput";

		// Token: 0x04000E47 RID: 3655
		private const uint SourceOn = 1U;

		// Token: 0x04000E48 RID: 3656
		private const uint SourceOff = 255U;

		// Token: 0x04000E49 RID: 3657
		private const double DefaultBrightnessMin = 0.0;

		// Token: 0x04000E4A RID: 3658
		private const double DefaultBrightnessMax = 255.0;

		// Token: 0x04000E4B RID: 3659
		private readonly object _sync = new object();

		// Token: 0x04000E4C RID: 3660
		private object _device;

		// Token: 0x04000E4D RID: 3661
		private string _connectedSerial;

		// Token: 0x04000E4E RID: 3662
		private double _brightnessMin = 0.0;

		// Token: 0x04000E4F RID: 3663
		private double _brightnessMax = 255.0;
	}
}
