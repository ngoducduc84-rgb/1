﻿using System;

namespace VisionMachine.Services.Localization
{
	// Token: 0x0200025F RID: 607
	public enum AppLanguage
	{
		// Token: 0x04000E04 RID: 3588
		English,
		// Token: 0x04000E05 RID: 3589
		Vietnamese,
		// Token: 0x04000E06 RID: 3590
		Korean
	}
}
