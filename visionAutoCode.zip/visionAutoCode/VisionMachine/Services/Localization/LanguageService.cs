﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Services.Localization
{
	// Token: 0x02000261 RID: 609
	public static class LanguageService
	{
		// Token: 0x170009D3 RID: 2515
		// (get) Token: 0x060021FB RID: 8699 RVA: 0x000C7C92 File Offset: 0x000C5E92
		// (set) Token: 0x060021FC RID: 8700 RVA: 0x000C7C99 File Offset: 0x000C5E99
		public static AppLanguage Current { get; private set; } = AppLanguage.English;

		// Token: 0x1400003A RID: 58
		// (add) Token: 0x060021FD RID: 8701 RVA: 0x000C7CA4 File Offset: 0x000C5EA4
		// (remove) Token: 0x060021FE RID: 8702 RVA: 0x000C7CD8 File Offset: 0x000C5ED8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler LanguageChanged;

		// Token: 0x060021FF RID: 8703 RVA: 0x000C7D0C File Offset: 0x000C5F0C
		public static string GetConfigPath()
		{
			return Manager_path._languageJsonPath;
		}

		// Token: 0x06002200 RID: 8704 RVA: 0x000C7D23 File Offset: 0x000C5F23
		public static void Initialize()
		{
			LanguageService.Apply(LanguageService.Load(), false);
		}

		// Token: 0x06002201 RID: 8705 RVA: 0x000C7D32 File Offset: 0x000C5F32
		public static void SetLanguage(AppLanguage language)
		{
			LanguageService.Apply(language, true);
		}

		// Token: 0x06002202 RID: 8706 RVA: 0x000C7D40 File Offset: 0x000C5F40
		public static string GetString(string key)
		{
			bool flag = string.IsNullOrWhiteSpace(key);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				Application application = Application.Current;
				object value = (application != null) ? application.TryFindResource(key) : null;
				result = ((value as string) ?? key);
			}
			return result;
		}

		// Token: 0x06002203 RID: 8707 RVA: 0x000C7D84 File Offset: 0x000C5F84
		private static void Apply(AppLanguage language, bool save)
		{
			Application app = Application.Current;
			bool flag = app == null;
			if (!flag)
			{
				ResourceDictionary dictionary;
				try
				{
					dictionary = new ResourceDictionary
					{
						Source = new Uri(LanguageService.GetSource(language), UriKind.Relative)
					};
				}
				catch
				{
					return;
				}
				bool flag2 = LanguageService._activeDictionary != null;
				if (flag2)
				{
					app.Resources.MergedDictionaries.Remove(LanguageService._activeDictionary);
				}
				app.Resources.MergedDictionaries.Add(dictionary);
				LanguageService._activeDictionary = dictionary;
				LanguageService.Current = language;
				if (save)
				{
					LanguageService.Save(language);
				}
				EventHandler languageChanged = LanguageService.LanguageChanged;
				if (languageChanged != null)
				{
					languageChanged(null, EventArgs.Empty);
				}
			}
		}

		// Token: 0x06002204 RID: 8708 RVA: 0x000C7E40 File Offset: 0x000C6040
		private static string GetSource(AppLanguage language)
		{
			string result;
			if (language != AppLanguage.Vietnamese)
			{
				if (language != AppLanguage.Korean)
				{
					result = "/VisionMachine;component/Resources/Localization/Strings.en.xaml";
				}
				else
				{
					result = "/VisionMachine;component/Resources/Localization/Strings.ko.xaml";
				}
			}
			else
			{
				result = "/VisionMachine;component/Resources/Localization/Strings.vi.xaml";
			}
			return result;
		}

		// Token: 0x06002205 RID: 8709 RVA: 0x000C7E78 File Offset: 0x000C6078
		private static AppLanguage Load()
		{
			AppLanguage result;
			try
			{
				string path = LanguageService.GetConfigPath();
				bool flag = !File.Exists(path);
				if (flag)
				{
					result = AppLanguage.English;
				}
				else
				{
					LanguageSettingData data = JsonConvert.DeserializeObject<LanguageSettingData>(File.ReadAllText(path));
					bool flag2 = data == null || string.IsNullOrWhiteSpace(data.Language);
					if (flag2)
					{
						result = AppLanguage.English;
					}
					else
					{
						AppLanguage saved;
						result = ((Enum.TryParse<AppLanguage>(data.Language.Trim(), true, out saved) && Enum.IsDefined(typeof(AppLanguage), saved)) ? saved : AppLanguage.English);
					}
				}
			}
			catch
			{
				result = AppLanguage.English;
			}
			return result;
		}

		// Token: 0x06002206 RID: 8710 RVA: 0x000C7F14 File Offset: 0x000C6114
		private static void Save(AppLanguage language)
		{
			try
			{
				object syncRoot = LanguageService.SyncRoot;
				lock (syncRoot)
				{
					string path = LanguageService.GetConfigPath();
					string folder = Path.GetDirectoryName(path);
					bool flag2 = !string.IsNullOrEmpty(folder);
					if (flag2)
					{
						Manager_path.Creat_path(folder);
					}
					File.WriteAllText(path, JsonConvert.SerializeObject(new LanguageSettingData
					{
						Language = language.ToString()
					}, Formatting.Indented));
				}
			}
			catch
			{
			}
		}

		// Token: 0x04000E08 RID: 3592
		private const string EnglishSource = "/VisionMachine;component/Resources/Localization/Strings.en.xaml";

		// Token: 0x04000E09 RID: 3593
		private const string VietnameseSource = "/VisionMachine;component/Resources/Localization/Strings.vi.xaml";

		// Token: 0x04000E0A RID: 3594
		private const string KoreanSource = "/VisionMachine;component/Resources/Localization/Strings.ko.xaml";

		// Token: 0x04000E0B RID: 3595
		private static readonly object SyncRoot = new object();

		// Token: 0x04000E0C RID: 3596
		private static ResourceDictionary _activeDictionary;
	}
}
