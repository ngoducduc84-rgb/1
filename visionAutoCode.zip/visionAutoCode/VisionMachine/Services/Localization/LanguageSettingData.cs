﻿using System;

namespace VisionMachine.Services.Localization
{
	// Token: 0x02000260 RID: 608
	public class LanguageSettingData
	{
		// Token: 0x170009D2 RID: 2514
		// (get) Token: 0x060021F8 RID: 8696 RVA: 0x000C7C81 File Offset: 0x000C5E81
		// (set) Token: 0x060021F9 RID: 8697 RVA: 0x000C7C89 File Offset: 0x000C5E89
		public string Language { get; set; }
	}
}
