﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using DevExpress.Xpf.Docking;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.Grid;
using DevExpress.Xpf.PropertyGrid;

namespace VisionMachine.Services.Localization
{
	// Token: 0x02000263 RID: 611
	public static class UiLocalizer
	{
		// Token: 0x06002212 RID: 8722 RVA: 0x000CFCC0 File Offset: 0x000CDEC0
		public static void Install()
		{
			bool installed = UiLocalizer._installed;
			if (!installed)
			{
				UiLocalizer._installed = true;
				EventManager.RegisterClassHandler(typeof(Window), FrameworkElement.LoadedEvent, new RoutedEventHandler(UiLocalizer.OnElementLoaded));
				EventManager.RegisterClassHandler(typeof(UserControl), FrameworkElement.LoadedEvent, new RoutedEventHandler(UiLocalizer.OnElementLoaded));
				EventManager.RegisterClassHandler(typeof(TextBlock), FrameworkElement.LoadedEvent, new RoutedEventHandler(UiLocalizer.OnElementLoaded));
				EventManager.RegisterClassHandler(typeof(ContentControl), FrameworkElement.LoadedEvent, new RoutedEventHandler(UiLocalizer.OnElementLoaded));
				EventManager.RegisterClassHandler(typeof(HeaderedItemsControl), FrameworkElement.LoadedEvent, new RoutedEventHandler(UiLocalizer.OnElementLoaded));
				EventManager.RegisterClassHandler(typeof(BaseLayoutItem), FrameworkElement.LoadedEvent, new RoutedEventHandler(UiLocalizer.OnElementLoaded));
				EventManager.RegisterClassHandler(typeof(PropertyGridControl), FrameworkElement.LoadedEvent, new RoutedEventHandler(UiLocalizer.OnElementLoaded));
				EventManager.RegisterClassHandler(typeof(GridControl), FrameworkElement.LoadedEvent, new RoutedEventHandler(UiLocalizer.OnElementLoaded));
				LanguageService.LanguageChanged += delegate(object s, EventArgs e)
				{
					UiLocalizer.LocalizeOpenWindows();
				};
			}
		}

		// Token: 0x06002213 RID: 8723 RVA: 0x000CFE10 File Offset: 0x000CE010
		private static void Track(DependencyObject element)
		{
			List<WeakReference> touched = UiLocalizer.Touched;
			lock (touched)
			{
				UiLocalizer.Touched.Add(new WeakReference(element));
			}
		}

		// Token: 0x06002214 RID: 8724 RVA: 0x000CFE60 File Offset: 0x000CE060
		public static void LocalizeOpenWindows()
		{
			UiLocalizer.RelocalizeTouched();
			Application app = Application.Current;
			bool flag = app == null;
			if (!flag)
			{
				foreach (object obj in app.Windows)
				{
					Window window = (Window)obj;
					UiLocalizer.Localize(window);
				}
			}
		}

		// Token: 0x06002215 RID: 8725 RVA: 0x000CFED8 File Offset: 0x000CE0D8
		private static void RelocalizeTouched()
		{
			List<WeakReference> touched = UiLocalizer.Touched;
			DependencyObject[] alive;
			lock (touched)
			{
				List<DependencyObject> live = new List<DependencyObject>(UiLocalizer.Touched.Count);
				for (int i = UiLocalizer.Touched.Count - 1; i >= 0; i--)
				{
					DependencyObject element = UiLocalizer.Touched[i].Target as DependencyObject;
					bool flag2 = element == null;
					if (flag2)
					{
						UiLocalizer.Touched.RemoveAt(i);
					}
					else
					{
						live.Add(element);
					}
				}
				alive = live.ToArray();
			}
			foreach (DependencyObject element2 in alive)
			{
				try
				{
					UiLocalizer.LocalizeElement(element2);
				}
				catch
				{
				}
			}
		}

		// Token: 0x06002216 RID: 8726 RVA: 0x000CFFCC File Offset: 0x000CE1CC
		private static void OnElementLoaded(object sender, RoutedEventArgs e)
		{
			UiLocalizer.Localize(sender as DependencyObject);
		}

		// Token: 0x06002217 RID: 8727 RVA: 0x000CFFDC File Offset: 0x000CE1DC
		public static void Localize(DependencyObject root)
		{
			bool flag = root == null;
			if (!flag)
			{
				try
				{
					UiLocalizer.Walk(root, new HashSet<DependencyObject>());
				}
				catch
				{
				}
			}
		}

		// Token: 0x06002218 RID: 8728 RVA: 0x000D001C File Offset: 0x000CE21C
		private static void Walk(DependencyObject node, HashSet<DependencyObject> visited)
		{
			bool flag = node == null || !visited.Add(node);
			if (!flag)
			{
				UiLocalizer.LocalizeElement(node);
				int count = (node is Visual || node is Visual3D) ? VisualTreeHelper.GetChildrenCount(node) : 0;
				for (int i = 0; i < count; i++)
				{
					UiLocalizer.Walk(VisualTreeHelper.GetChild(node, i), visited);
				}
				foreach (object child in LogicalTreeHelper.GetChildren(node))
				{
					UiLocalizer.Walk(child as DependencyObject, visited);
				}
			}
		}

		// Token: 0x06002219 RID: 8729 RVA: 0x000D00DC File Offset: 0x000CE2DC
		private static void LocalizeTextBlock(TextBlock textBlock)
		{
			bool flag = textBlock == null;
			if (!flag)
			{
				bool flag2 = UiLocalizer.IsSetByExpression(textBlock, TextBlock.TextProperty);
				if (!flag2)
				{
					bool flag3 = UiLocalizer.WasChangedByProgram(textBlock, textBlock.Text);
					if (!flag3)
					{
						string original = UiLocalizer.GetOriginal(textBlock, textBlock.Text);
						bool flag4 = string.IsNullOrWhiteSpace(original);
						if (!flag4)
						{
							string translated = UiTranslator.Translate(original);
							textBlock.Text = translated;
							textBlock.SetValue(UiLocalizer.LastAppliedTextProperty, translated);
						}
					}
				}
			}
		}

		// Token: 0x0600221A RID: 8730 RVA: 0x000D0150 File Offset: 0x000CE350
		private static void LocalizeContentControl(ContentControl control)
		{
			bool flag = control == null;
			if (!flag)
			{
				bool flag2 = UiLocalizer.IsSetByExpression(control, ContentControl.ContentProperty);
				if (!flag2)
				{
					string text = control.Content as string;
					bool flag3 = text == null;
					if (!flag3)
					{
						bool flag4 = UiLocalizer.WasChangedByProgram(control, text);
						if (!flag4)
						{
							string original = UiLocalizer.GetOriginal(control, text);
							bool flag5 = string.IsNullOrWhiteSpace(original);
							if (!flag5)
							{
								string translated = UiTranslator.Translate(original);
								control.Content = translated;
								control.SetValue(UiLocalizer.LastAppliedTextProperty, translated);
							}
						}
					}
				}
			}
		}

		// Token: 0x0600221B RID: 8731 RVA: 0x000D01D4 File Offset: 0x000CE3D4
		private static void LocalizeElement(DependencyObject node)
		{
			FrameworkElement element = node as FrameworkElement;
			bool flag = element != null && element.TemplatedParent != null;
			if (!flag)
			{
				PropertyGridControl grid = node as PropertyGridControl;
				bool flag2 = grid != null;
				if (flag2)
				{
					UiLocalizer.LocalizePropertyGrid(grid);
				}
				UiLocalizer.LocalizeGridColumns(node as GridControl);
				UiLocalizer.LocalizeWindowTitle(node as Window);
				UiLocalizer.LocalizeTextBlock(node as TextBlock);
				UiLocalizer.LocalizeContentControl(node as ContentControl);
				UiLocalizer.LocalizeHeaderedItem(node as HeaderedItemsControl);
				UiLocalizer.LocalizeLayoutItem(node as BaseLayoutItem);
				UiLocalizer.LocalizeEditorWatermark(node as BaseEdit);
				UiLocalizer.LocalizeHeaderedContent(node as HeaderedContentControl);
			}
		}

		// Token: 0x0600221C RID: 8732 RVA: 0x000D0274 File Offset: 0x000CE474
		public static void SetLocalizedCaption(BaseLayoutItem item, string english)
		{
			bool flag = item == null || string.IsNullOrWhiteSpace(english);
			if (!flag)
			{
				bool flag2 = !(item.GetValue(UiLocalizer.OriginalTextProperty) is string);
				if (flag2)
				{
					UiLocalizer.Track(item);
				}
				item.SetValue(UiLocalizer.OriginalTextProperty, english);
				item.Caption = UiTranslator.Translate(english);
			}
		}

		// Token: 0x0600221D RID: 8733 RVA: 0x000D02CC File Offset: 0x000CE4CC
		private static void LocalizeLayoutItem(BaseLayoutItem item)
		{
			bool flag = item == null;
			if (!flag)
			{
				bool flag2 = UiLocalizer.IsSetByExpression(item, BaseLayoutItem.CaptionProperty);
				if (!flag2)
				{
					string text = item.Caption as string;
					bool flag3 = text == null;
					if (!flag3)
					{
						string original = UiLocalizer.GetOriginal(item, text);
						bool flag4 = string.IsNullOrWhiteSpace(original);
						if (!flag4)
						{
							item.Caption = UiTranslator.Translate(original);
						}
					}
				}
			}
		}

		// Token: 0x0600221E RID: 8734 RVA: 0x000D0334 File Offset: 0x000CE534
		private static void LocalizeEditorWatermark(BaseEdit editor)
		{
			bool flag = editor == null;
			if (!flag)
			{
				bool flag2 = UiLocalizer.IsSetByExpression(editor, BaseEdit.NullTextProperty);
				if (!flag2)
				{
					string text = editor.NullText;
					bool flag3 = text == null;
					if (!flag3)
					{
						string original = UiLocalizer.GetOriginal(editor, text);
						bool flag4 = string.IsNullOrWhiteSpace(original);
						if (!flag4)
						{
							editor.NullText = UiTranslator.Translate(original);
						}
					}
				}
			}
		}

		// Token: 0x0600221F RID: 8735 RVA: 0x000D0394 File Offset: 0x000CE594
		private static void LocalizeWindowTitle(Window window)
		{
			bool flag = window == null;
			if (!flag)
			{
				bool flag2 = UiLocalizer.IsSetByExpression(window, Window.TitleProperty);
				if (!flag2)
				{
					string original = UiLocalizer.GetOriginal(window, window.Title);
					bool flag3 = string.IsNullOrWhiteSpace(original);
					if (!flag3)
					{
						window.Title = UiTranslator.Translate(original);
					}
				}
			}
		}

		// Token: 0x06002220 RID: 8736 RVA: 0x000D03E4 File Offset: 0x000CE5E4
		private static void LocalizeHeaderedContent(HeaderedContentControl control)
		{
			bool flag = control == null;
			if (!flag)
			{
				bool flag2 = UiLocalizer.IsSetByExpression(control, HeaderedContentControl.HeaderProperty);
				if (!flag2)
				{
					string text = control.Header as string;
					bool flag3 = text == null;
					if (!flag3)
					{
						string original = UiLocalizer.GetOriginal(control, text);
						bool flag4 = string.IsNullOrWhiteSpace(original);
						if (!flag4)
						{
							control.Header = UiTranslator.Translate(original);
						}
					}
				}
			}
		}

		// Token: 0x06002221 RID: 8737 RVA: 0x000D044C File Offset: 0x000CE64C
		private static void LocalizeHeaderedItem(HeaderedItemsControl control)
		{
			bool flag = control == null;
			if (!flag)
			{
				bool flag2 = UiLocalizer.IsSetByExpression(control, HeaderedItemsControl.HeaderProperty);
				if (!flag2)
				{
					string text = control.Header as string;
					bool flag3 = text == null;
					if (!flag3)
					{
						string original = UiLocalizer.GetOriginal(control, text);
						bool flag4 = string.IsNullOrWhiteSpace(original);
						if (!flag4)
						{
							control.Header = UiTranslator.Translate(original);
						}
					}
				}
			}
		}

		// Token: 0x06002222 RID: 8738 RVA: 0x000D04B4 File Offset: 0x000CE6B4
		private static void LocalizeGridColumns(GridControl grid)
		{
			bool flag = grid == null;
			if (!flag)
			{
				foreach (GridColumn column in grid.Columns)
				{
					UiLocalizer.LocalizeColumnHeader(column);
				}
			}
		}

		// Token: 0x06002223 RID: 8739 RVA: 0x000D0510 File Offset: 0x000CE710
		private static void LocalizeColumnHeader(BaseColumn column)
		{
			bool flag = column == null;
			if (!flag)
			{
				bool flag2 = UiLocalizer.IsSetByExpression(column, BaseColumn.HeaderProperty);
				if (!flag2)
				{
					string text = column.Header as string;
					bool flag3 = text == null;
					if (!flag3)
					{
						bool flag4 = UiLocalizer.WasChangedByProgram(column, text);
						if (!flag4)
						{
							string original = UiLocalizer.GetOriginal(column, text);
							bool flag5 = string.IsNullOrWhiteSpace(original);
							if (!flag5)
							{
								string translated = UiTranslator.Translate(original);
								column.Header = translated;
								column.SetValue(UiLocalizer.LastAppliedTextProperty, translated);
							}
						}
					}
				}
			}
		}

		// Token: 0x06002224 RID: 8740 RVA: 0x000D0594 File Offset: 0x000CE794
		private static void LocalizePropertyGrid(PropertyGridControl grid)
		{
			bool flag = grid.SelectedObject == null;
			if (!flag)
			{
				bool flag2 = !(bool)grid.GetValue(UiLocalizer.TrackedProperty);
				if (flag2)
				{
					grid.SetValue(UiLocalizer.TrackedProperty, true);
					UiLocalizer.Track(grid);
				}
				bool flag3 = LanguageService.Current != AppLanguage.Vietnamese;
				if (flag3)
				{
					UiLocalizer.ClearGeneratedRows(grid);
				}
				bool flag4 = grid.PropertyDefinitions == null || grid.PropertyDefinitions.Count == 0;
				if (flag4)
				{
					UiLocalizer.LocalizeGeneratedRows(grid);
				}
				else
				{
					bool flag5 = (bool)grid.GetValue(UiLocalizer.RowsGeneratedProperty);
					if (flag5)
					{
						UiLocalizer.ClearGeneratedRows(grid);
						UiLocalizer.LocalizeGeneratedRows(grid);
					}
					else
					{
						foreach (PropertyDefinitionBase definition in grid.PropertyDefinitions)
						{
							PropertyDefinition property = definition as PropertyDefinition;
							bool flag6 = property == null || string.IsNullOrWhiteSpace(property.Path);
							if (!flag6)
							{
								string english = UiLocalizer.GetOriginal(property, string.IsNullOrWhiteSpace(property.Header) ? UiLocalizer.GetDisplayName(grid.SelectedObject, property.Path) : property.Header);
								bool flag7 = string.IsNullOrWhiteSpace(english);
								if (!flag7)
								{
									property.Header = UiTranslator.Translate(english);
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06002225 RID: 8741 RVA: 0x000D070C File Offset: 0x000CE90C
		private static void LocalizeGeneratedRows(PropertyGridControl grid)
		{
			UiLocalizer.WatchSelectedObject(grid);
			bool flag = LanguageService.Current != AppLanguage.Vietnamese;
			if (!flag)
			{
				List<PropertyDefinition> definitions = new List<PropertyDefinition>();
				foreach (object obj in TypeDescriptor.GetProperties(grid.SelectedObject))
				{
					PropertyDescriptor descriptor = (PropertyDescriptor)obj;
					bool flag2 = !descriptor.IsBrowsable;
					if (!flag2)
					{
						definitions.Add(new PropertyDefinition
						{
							Path = descriptor.Name,
							Header = UiTranslator.Translate(descriptor.DisplayName)
						});
					}
				}
				bool flag3 = definitions.Count == 0;
				if (!flag3)
				{
					foreach (PropertyDefinition definition in definitions)
					{
						grid.PropertyDefinitions.Add(definition);
					}
					grid.SetValue(UiLocalizer.RowsGeneratedProperty, true);
				}
			}
		}

		// Token: 0x06002226 RID: 8742 RVA: 0x000D0834 File Offset: 0x000CEA34
		private static void ClearGeneratedRows(PropertyGridControl grid)
		{
			bool flag = !(bool)grid.GetValue(UiLocalizer.RowsGeneratedProperty);
			if (!flag)
			{
				grid.PropertyDefinitions.Clear();
				grid.SetValue(UiLocalizer.RowsGeneratedProperty, false);
			}
		}

		// Token: 0x06002227 RID: 8743 RVA: 0x000D087C File Offset: 0x000CEA7C
		private static void WatchSelectedObject(PropertyGridControl grid)
		{
			bool flag = (bool)grid.GetValue(UiLocalizer.WatchedProperty);
			if (!flag)
			{
				grid.SetValue(UiLocalizer.WatchedProperty, true);
				DependencyPropertyDescriptor descriptor = DependencyPropertyDescriptor.FromProperty(PropertyGridControl.SelectedObjectProperty, typeof(PropertyGridControl));
				bool flag2 = descriptor == null;
				if (!flag2)
				{
					descriptor.AddValueChanged(grid, delegate(object s, EventArgs e)
					{
						UiLocalizer.ClearGeneratedRows(grid);
						bool flag3 = grid.SelectedObject != null;
						if (flag3)
						{
							UiLocalizer.LocalizePropertyGrid(grid);
						}
					});
				}
			}
		}

		// Token: 0x06002228 RID: 8744 RVA: 0x000D0904 File Offset: 0x000CEB04
		private static string GetDisplayName(object source, string path)
		{
			bool flag = source == null || string.IsNullOrWhiteSpace(path);
			string result;
			if (flag)
			{
				result = path;
			}
			else
			{
				PropertyDescriptor descriptor = TypeDescriptor.GetProperties(source)[path];
				result = ((descriptor == null) ? path : descriptor.DisplayName);
			}
			return result;
		}

		// Token: 0x06002229 RID: 8745 RVA: 0x000D0944 File Offset: 0x000CEB44
		private static bool IsSetByExpression(DependencyObject element, DependencyProperty property)
		{
			bool flag = element == null || property == null;
			return !flag && element.ReadLocalValue(property) is Expression;
		}

		// Token: 0x0600222A RID: 8746 RVA: 0x000D0978 File Offset: 0x000CEB78
		private static bool WasChangedByProgram(DependencyObject element, string current)
		{
			string applied = element.GetValue(UiLocalizer.LastAppliedTextProperty) as string;
			bool flag = applied == null;
			return !flag && !string.Equals(applied, current, StringComparison.Ordinal);
		}

		// Token: 0x0600222B RID: 8747 RVA: 0x000D09B4 File Offset: 0x000CEBB4
		private static string GetOriginal(DependencyObject element, string current)
		{
			string stored = element.GetValue(UiLocalizer.OriginalTextProperty) as string;
			bool flag = stored != null;
			string result;
			if (flag)
			{
				result = stored;
			}
			else
			{
				element.SetValue(UiLocalizer.OriginalTextProperty, current ?? string.Empty);
				UiLocalizer.Track(element);
				result = current;
			}
			return result;
		}

		// Token: 0x04000E16 RID: 3606
		private static readonly DependencyProperty OriginalTextProperty = DependencyProperty.RegisterAttached("OriginalText", typeof(string), typeof(UiLocalizer), new PropertyMetadata(null));

		// Token: 0x04000E17 RID: 3607
		private static readonly DependencyProperty LastAppliedTextProperty = DependencyProperty.RegisterAttached("LastAppliedText", typeof(string), typeof(UiLocalizer), new PropertyMetadata(null));

		// Token: 0x04000E18 RID: 3608
		private static bool _installed;

		// Token: 0x04000E19 RID: 3609
		private static readonly List<WeakReference> Touched = new List<WeakReference>();

		// Token: 0x04000E1A RID: 3610
		private static readonly DependencyProperty RowsGeneratedProperty = DependencyProperty.RegisterAttached("RowsGenerated", typeof(bool), typeof(UiLocalizer), new PropertyMetadata(false));

		// Token: 0x04000E1B RID: 3611
		private static readonly DependencyProperty TrackedProperty = DependencyProperty.RegisterAttached("Tracked", typeof(bool), typeof(UiLocalizer), new PropertyMetadata(false));

		// Token: 0x04000E1C RID: 3612
		private static readonly DependencyProperty WatchedProperty = DependencyProperty.RegisterAttached("Watched", typeof(bool), typeof(UiLocalizer), new PropertyMetadata(false));
	}
}
