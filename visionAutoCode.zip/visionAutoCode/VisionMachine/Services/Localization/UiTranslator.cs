﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace VisionMachine.Services.Localization
{
	// Token: 0x02000262 RID: 610
	public static class UiTranslator
	{
		// Token: 0x06002208 RID: 8712 RVA: 0x000C7FC4 File Offset: 0x000C61C4
		public static string Translate(string english)
		{
			bool flag = string.IsNullOrWhiteSpace(english);
			string result;
			if (flag)
			{
				result = english;
			}
			else
			{
				AppLanguage language = LanguageService.Current;
				bool flag2 = language == AppLanguage.English;
				if (flag2)
				{
					result = english;
				}
				else
				{
					string trimmed = english.Trim();
					string translated = UiTranslator.TranslatePhrase(trimmed, language);
					result = (translated ?? english);
				}
			}
			return result;
		}

		// Token: 0x06002209 RID: 8713 RVA: 0x000C8014 File Offset: 0x000C6214
		private static Dictionary<string, string> PhrasesOf(AppLanguage language)
		{
			return (language == AppLanguage.Korean) ? UiTranslator.KoreanPhrases : UiTranslator.VietnamesePhrases;
		}

		// Token: 0x0600220A RID: 8714 RVA: 0x000C8038 File Offset: 0x000C6238
		private static Dictionary<string, string> TermsOf(AppLanguage language)
		{
			return (language == AppLanguage.Korean) ? UiTranslator.KoreanTerms : UiTranslator.VietnameseTerms;
		}

		// Token: 0x0600220B RID: 8715 RVA: 0x000C805C File Offset: 0x000C625C
		private static string TranslatePhrase(string text, AppLanguage language)
		{
			Dictionary<string, string> phrases = UiTranslator.PhrasesOf(language);
			string known;
			bool flag = phrases.TryGetValue(text, out known);
			string result2;
			if (flag)
			{
				result2 = known;
			}
			else
			{
				Match match = UiTranslator.TrailingNote.Match(text);
				bool flag2 = !match.Success;
				if (flag2)
				{
					result2 = UiTranslator.Finish(UiTranslator.TranslateCore(text, language), language);
				}
				else
				{
					string core = match.Groups["core"].Value;
					string note = match.Groups["note"].Value;
					bool flag3 = phrases.TryGetValue(core, out known);
					if (flag3)
					{
						result2 = known + " " + note;
					}
					else
					{
						string result = UiTranslator.TranslateCore(core, language);
						result2 = ((result == null) ? null : (UiTranslator.Finish(result, language) + " " + note));
					}
				}
			}
			return result2;
		}

		// Token: 0x0600220C RID: 8716 RVA: 0x000C812C File Offset: 0x000C632C
		private static string TranslateCore(string core, AppLanguage language)
		{
			bool flag = string.IsNullOrWhiteSpace(core);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				core = core.Trim();
				string term;
				bool flag2 = UiTranslator.TermsOf(language).TryGetValue(core, out term);
				if (flag2)
				{
					result = term;
				}
				else
				{
					string prefixed = UiTranslator.TranslateWithLeadIn(core, language);
					bool flag3 = prefixed != null;
					if (flag3)
					{
						result = prefixed;
					}
					else
					{
						bool flag4 = core.StartsWith("Min ", StringComparison.Ordinal);
						if (flag4)
						{
							result = UiTranslator.Qualify(core.Substring(4), true, language);
						}
						else
						{
							bool flag5 = core.StartsWith("Max ", StringComparison.Ordinal);
							if (flag5)
							{
								result = UiTranslator.Qualify(core.Substring(4), false, language);
							}
							else
							{
								bool flag6 = core.EndsWith(" Min", StringComparison.Ordinal);
								if (flag6)
								{
									result = UiTranslator.Qualify(core.Substring(0, core.Length - 4), true, language);
								}
								else
								{
									bool flag7 = core.EndsWith(" Max", StringComparison.Ordinal);
									if (flag7)
									{
										result = UiTranslator.Qualify(core.Substring(0, core.Length - 4), false, language);
									}
									else
									{
										result = null;
									}
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x0600220D RID: 8717 RVA: 0x000C8228 File Offset: 0x000C6428
		private static string TranslateWithLeadIn(string core, AppLanguage language)
		{
			Dictionary<string, string> leadIns = (language == AppLanguage.Korean) ? UiTranslator.KoreanSuffixVerbs : UiTranslator.VietnamesePrefixes;
			foreach (KeyValuePair<string, string> leadIn in leadIns)
			{
				bool flag = !core.StartsWith(leadIn.Key + " ", StringComparison.Ordinal);
				if (!flag)
				{
					string rest = UiTranslator.TranslateCore(core.Substring(leadIn.Key.Length + 1), language);
					bool flag2 = rest == null;
					if (!flag2)
					{
						return (language == AppLanguage.Korean) ? (rest + " " + leadIn.Value) : (leadIn.Value + " " + rest);
					}
				}
			}
			return null;
		}

		// Token: 0x0600220E RID: 8718 RVA: 0x000C830C File Offset: 0x000C650C
		private static string Qualify(string core, bool isMinimum, AppLanguage language)
		{
			string translated = UiTranslator.TranslateCore(core, language);
			bool flag = translated == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool flag2 = language == AppLanguage.Korean;
				if (flag2)
				{
					result = (isMinimum ? "최소 " : "최대 ") + translated;
				}
				else
				{
					result = translated + (isMinimum ? " tối thiểu" : " tối đa");
				}
			}
			return result;
		}

		// Token: 0x0600220F RID: 8719 RVA: 0x000C8368 File Offset: 0x000C6568
		private static string Finish(string text, AppLanguage language)
		{
			return (language == AppLanguage.Korean) ? text : UiTranslator.Capitalize(text);
		}

		// Token: 0x06002210 RID: 8720 RVA: 0x000C8388 File Offset: 0x000C6588
		private static string Capitalize(string text)
		{
			bool flag = string.IsNullOrEmpty(text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				result = char.ToUpper(text[0], CultureInfo.InvariantCulture).ToString() + text.Substring(1);
			}
			return result;
		}

		// Token: 0x04000E0F RID: 3599
		private static readonly Regex TrailingNote = new Regex("^(?<core>.*?)\\s*(?<note>\\([^()]*\\))$", RegexOptions.Compiled);

		// Token: 0x04000E10 RID: 3600
		private static readonly Dictionary<string, string> VietnamesePhrases = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
		{
			{
				"Copy Image Path",
				"Sao chép đường dẫn ảnh"
			},
			{
				"Enter the licence you were given.",
				"Hãy nhập license bạn được cấp."
			},
			{
				"This licence is not in the expected form. It should look like 20251231-P-3F9A17C4B20E5D68.",
				"License không đúng định dạng. Nó phải có dạng 20251231-P-3F9A17C4B20E5D68."
			},
			{
				"The date inside this licence is not readable.",
				"Không đọc được ngày trong license này."
			},
			{
				"The edition inside this licence is not readable.",
				"Không đọc được gói sử dụng trong license này."
			},
			{
				"This licence names an edition this version does not know.",
				"License này ghi một gói sử dụng mà phiên bản phần mềm này không biết."
			},
			{
				"This licence does not belong to this machine. Check that the machine code sent to your supplier is the one shown above.",
				"License này không thuộc về máy này. Hãy kiểm tra lại mã máy đã gửi cho nhà cung cấp có đúng là mã hiện ở trên không."
			},
			{
				"The machine code could not be read from this computer, so a licence cannot be checked. Contact your supplier.",
				"Không đọc được mã máy từ máy tính này nên không kiểm tra được license. Hãy liên hệ nhà cung cấp."
			},
			{
				"The licence is valid and does not expire.",
				"License hợp lệ và không có thời hạn."
			},
			{
				"Issue License",
				"Cấp license"
			},
			{
				"New license",
				"Tạo mới"
			},
			{
				"Enter the details to create a license for a device.",
				"Nhập thông tin để tạo license cho thiết bị."
			},
			{
				"1. MACHINE INFORMATION",
				"1. THÔNG TIN MÁY"
			},
			{
				"Machine ID",
				"Mã của máy (Machine ID)"
			},
			{
				"Paste",
				"Dán"
			},
			{
				"This code is taken from the device the license is for.",
				"Mã này được lấy từ thiết bị cần cấp license."
			},
			{
				"2. VALIDITY",
				"2. THỜI HẠN SỬ DỤNG"
			},
			{
				"Validity type",
				"Loại thời hạn"
			},
			{
				"Fixed period",
				"Có thời hạn"
			},
			{
				"Perpetual",
				"Vĩnh viễn"
			},
			{
				"Expiry date",
				"Ngày hết hạn"
			},
			{
				"The license stays valid to the end of the day chosen.",
				"License sẽ hết hạn vào cuối ngày đã chọn."
			},
			{
				"3. PACKAGE (OPTIONAL)",
				"3. THÔNG TIN GÓI (TÙY CHỌN)"
			},
			{
				"Package",
				"Gói sử dụng"
			},
			{
				"Choose the feature package this license grants.",
				"Chọn gói tính năng được phép sử dụng."
			},
			{
				"GENERATED LICENSE",
				"LICENSE ĐƯỢC TẠO"
			},
			{
				"License key",
				"Mã license"
			},
			{
				"License details",
				"Thông tin license"
			},
			{
				"Copied",
				"Đã sao chép"
			},
			{
				"Export license",
				"Xuất license"
			},
			{
				"Administrator Login",
				"Đăng nhập quản trị"
			},
			{
				"Sign in to reach the protected settings.",
				"Đăng nhập để vào phần cài đặt được bảo vệ."
			},
			{
				"User name",
				"Tên đăng nhập"
			},
			{
				"Password",
				"Mật khẩu"
			},
			{
				"Sign in",
				"Đăng nhập"
			},
			{
				"Run All",
				"Chạy tất cả"
			},
			{
				"Save All Config",
				"Lưu toàn bộ cấu hình"
			},
			{
				"Save Image",
				"Lưu ảnh"
			},
			{
				"Open Image",
				"Mở ảnh"
			},
			{
				"Select Image Folder",
				"Chọn thư mục ảnh"
			},
			{
				"Snap",
				"Chụp ảnh"
			},
			{
				"Next",
				"Tiếp"
			},
			{
				"Previous",
				"Trước"
			},
			{
				"Add TurnSnap",
				"Thêm TurnSnap"
			},
			{
				"ADD ROI",
				"THÊM ROI"
			},
			{
				"UPDATE ROI",
				"CẬP NHẬT ROI"
			},
			{
				"Edit",
				"Sửa"
			},
			{
				"Delete",
				"Xoá"
			},
			{
				"Custom",
				"Tự vẽ"
			},
			{
				"Rectangle",
				"Chữ nhật"
			},
			{
				"Rectangle2",
				"Chữ nhật xoay"
			},
			{
				"Circle",
				"Hình tròn"
			},
			{
				"Ellipse",
				"Elip"
			},
			{
				"Line",
				"Đường thẳng"
			},
			{
				"Polygon",
				"Đa giác"
			},
			{
				"FreeDraw",
				"Vẽ tự do"
			},
			{
				"Count Spec Enabled",
				"Bật spec số lượng"
			},
			{
				"Toolbox",
				"Hộp tool"
			},
			{
				"Tools",
				"Danh sách tool"
			},
			{
				"Tool Parameter",
				"Tham số tool"
			},
			{
				"Parameter",
				"Tham số"
			},
			{
				"Output Result",
				"Kết quả đầu ra"
			},
			{
				"Display",
				"Hiển thị"
			},
			{
				"Display setting",
				"Cài đặt hiển thị"
			},
			{
				"Manage Tool",
				"Quản lý tool"
			},
			{
				"Customization...",
				"Tuỳ chỉnh..."
			},
			{
				"Inspection / Measuring Tools",
				"Tool kiểm tra / đo"
			},
			{
				"Selection",
				"Lựa chọn"
			},
			{
				"Matching",
				"Khớp mẫu"
			},
			{
				"Analysis",
				"Phân tích"
			},
			{
				"Transform",
				"Biến đổi"
			},
			{
				"Filter Parameters",
				"Tham số bộ lọc"
			},
			{
				"Transform Parameters",
				"Tham số biến đổi"
			},
			{
				"Select Filter",
				"Chọn bộ lọc"
			},
			{
				"Source Tool",
				"Tool nguồn"
			},
			{
				"List image",
				"Danh sách ảnh"
			},
			{
				"Search model...",
				"Tìm model..."
			},
			{
				"MODEL LIST",
				"DANH SÁCH MODEL"
			},
			{
				"Save Image As",
				"Lưu ảnh thành"
			},
			{
				"Save Setting",
				"Lưu cài đặt"
			},
			{
				"Save",
				"Lưu"
			},
			{
				"Browse",
				"Duyệt"
			},
			{
				"Browse .pt File...",
				"Duyệt file .pt..."
			},
			{
				"Copy image",
				"Sao chép ảnh"
			},
			{
				"Paste image",
				"Dán ảnh"
			},
			{
				"Copy turnsnap",
				"Sao chép TurnSnap"
			},
			{
				"Paste turnsnap",
				"Dán TurnSnap"
			},
			{
				"Move",
				"Di chuyển"
			},
			{
				"Del",
				"Xoá"
			},
			{
				"Clear",
				"Xoá hết"
			},
			{
				"Clear Samples",
				"Xoá mẫu"
			},
			{
				"Add Sample",
				"Thêm mẫu"
			},
			{
				"Load Model",
				"Nạp model"
			},
			{
				"Train Model",
				"Huấn luyện model"
			},
			{
				"Predict Train",
				"Dự đoán (train)"
			},
			{
				"Pretrain",
				"Tiền huấn luyện"
			},
			{
				"Align Tool",
				"Tool căn chỉnh"
			},
			{
				"Auto search code type",
				"Tự dò kiểu mã"
			},
			{
				"ROI",
				"ROI"
			},
			{
				"Limit roi",
				"Limit ROI"
			},
			{
				"Mask roi",
				"Mask ROI"
			},
			{
				"Hide ROI",
				"Ẩn ROI"
			},
			{
				"Zoom to Fit",
				"Vừa khung hình"
			},
			{
				"Show All",
				"Hiện tất cả"
			},
			{
				"Hide All",
				"Ẩn tất cả"
			},
			{
				"Show All ROI",
				"Hiện tất cả ROI"
			},
			{
				"Show All Limit ROI",
				"Hiện tất cả Limit ROI"
			},
			{
				"Show All Mask ROI",
				"Hiện tất cả Mask ROI"
			},
			{
				"Clear All ROI",
				"Xoá tất cả ROI"
			},
			{
				"Clear All Limit ROI",
				"Xoá tất cả Limit ROI"
			},
			{
				"Clear All Mask ROI",
				"Xoá tất cả Mask ROI"
			},
			{
				"Spec",
				"Spec"
			},
			{
				"Spec Min",
				"Spec tối thiểu"
			},
			{
				"Spec Max",
				"Spec tối đa"
			},
			{
				"Min",
				"Tối thiểu"
			},
			{
				"Max",
				"Tối đa"
			},
			{
				"Max Def",
				"Biến dạng lớn nhất"
			},
			{
				"Mean Def",
				"Biến dạng trung bình"
			},
			{
				"Value",
				"Giá trị"
			},
			{
				"Value mm",
				"Giá trị (mm)"
			},
			{
				"Value px",
				"Giá trị (px)"
			},
			{
				"Radius px",
				"Bán kính (px)"
			},
			{
				"Diameter px",
				"Đường kính (px)"
			},
			{
				"Detail",
				"Chi tiết"
			},
			{
				"Message",
				"Thông báo"
			},
			{
				"Order",
				"Thứ tự"
			},
			{
				"Type",
				"Kiểu"
			},
			{
				"Use",
				"Dùng"
			},
			{
				"Class",
				"Lớp"
			},
			{
				"Conf",
				"Độ tin cậy"
			},
			{
				"Metric",
				"Đơn vị"
			},
			{
				"Calib",
				"Hiệu chuẩn"
			},
			{
				"Calib File",
				"File hiệu chuẩn"
			},
			{
				"Source Calib",
				"Nguồn hiệu chuẩn"
			},
			{
				"Run Calib",
				"Chạy hiệu chuẩn"
			},
			{
				"Calibration Setup",
				"Thiết lập hiệu chuẩn"
			},
			{
				"Calibration / Spec",
				"Hiệu chuẩn / Spec"
			},
			{
				"Calib Hand-Eye Tools To Align",
				"Tool Calib Hand-Eye cần căn chỉnh"
			},
			{
				"Master define",
				"Định nghĩa master"
			},
			{
				"Master X (mm)",
				"X master (mm)"
			},
			{
				"Master Y (mm)",
				"Y master (mm)"
			},
			{
				"Master TCP Row",
				"Hàng TCP master"
			},
			{
				"Master TCP Col",
				"Cột TCP master"
			},
			{
				"Robot X (mm)",
				"X robot (mm)"
			},
			{
				"Robot Y (mm)",
				"Y robot (mm)"
			},
			{
				"TCP Row",
				"Hàng TCP"
			},
			{
				"TCP Col",
				"Cột TCP"
			},
			{
				"Use TCP",
				"Dùng TCP"
			},
			{
				"A Offset",
				"Bù góc A"
			},
			{
				"Mapped A",
				"Góc A ánh xạ"
			},
			{
				"Delta A (deg)",
				"Lệch A (deg)"
			},
			{
				"Pixel Row",
				"Hàng điểm ảnh"
			},
			{
				"Pixel Col",
				"Cột điểm ảnh"
			},
			{
				"Center Row",
				"Hàng tâm"
			},
			{
				"Center Col",
				"Cột tâm"
			},
			{
				"Center Column",
				"Cột tâm"
			},
			{
				"Grid Col",
				"Cột lưới"
			},
			{
				"TL Row",
				"Hàng trên-trái"
			},
			{
				"TL Column",
				"Cột trên-trái"
			},
			{
				"TR Row",
				"Hàng trên-phải"
			},
			{
				"TR Column",
				"Cột trên-phải"
			},
			{
				"BL Row",
				"Hàng dưới-trái"
			},
			{
				"BL Column",
				"Cột dưới-trái"
			},
			{
				"BR Row",
				"Hàng dưới-phải"
			},
			{
				"BR Column",
				"Cột dưới-phải"
			},
			{
				"ROI Property",
				"Thuộc tính ROI"
			},
			{
				"Properties",
				"Thuộc tính"
			},
			{
				"Clone",
				"Nhân bản"
			},
			{
				"Name",
				"Tên"
			},
			{
				"Mask Mode",
				"Kiểu vùng"
			},
			{
				"Enabled",
				"Bật"
			},
			{
				"Rows",
				"Số hàng"
			},
			{
				"Columns",
				"Số cột"
			},
			{
				"Offset Row (px)",
				"Khoảng cách hàng (px)"
			},
			{
				"Offset Column (px)",
				"Khoảng cách cột (px)"
			},
			{
				"Direction",
				"Hướng"
			},
			{
				"Angle (deg)",
				"Góc (deg)"
			},
			{
				"Test Show",
				"Xem thử"
			},
			{
				"OK",
				"OK"
			},
			{
				"Cancel",
				"Huỷ"
			},
			{
				"Clone (nothing to add)",
				"Nhân bản (không có gì để thêm)"
			},
			{
				"Clone ({0})",
				"Nhân bản ({0})"
			},
			{
				"Grid {0} x {1} = {2} ROIs, {3} added",
				"Lưới {0} x {1} = {2} ROI, thêm {3}"
			},
			{
				"Draw the pattern on the image without creating anything",
				"Vẽ mẫu lên ảnh mà không tạo gì"
			},
			{
				"Test Show draws the pattern on the image without adding anything. Clone then commits it.",
				"Xem thử vẽ mẫu lên ảnh mà không thêm gì. Nhấn Nhân bản mới thực sự tạo."
			},
			{
				"Rows x Columns is the finished grid: 8 x 3 lays out 24 ROIs and adds 23, because the source already fills one position. Test Show draws the pattern on the image without adding anything - move this window aside to see it. Clone then commits it.",
				"Số hàng x Số cột là lưới hoàn chỉnh: 8 x 3 tạo ra 24 ROI và thêm 23, vì ROI gốc đã chiếm sẵn một vị trí. Xem thử vẽ mẫu lên ảnh mà không thêm gì - dời cửa sổ này sang bên để nhìn. Nhấn Nhân bản mới thực sự tạo."
			},
			{
				"Rows and Columns describe the finished grid and the source already fills one position, so 1 x 1 adds nothing. Raise one of them.",
				"Số hàng và Số cột mô tả lưới hoàn chỉnh, ROI gốc đã chiếm một vị trí, nên 1 x 1 không thêm được gì. Hãy tăng một trong hai."
			},
			{
				"Both offsets are 0, so every copy would sit on top of the original. Set the distance between two ROIs first.",
				"Cả hai khoảng cách đều bằng 0 nên mọi bản sao sẽ nằm đè lên ROI gốc. Hãy đặt khoảng cách giữa hai ROI trước."
			},
			{
				"Trial Run Tool",
				"Chạy thử tool"
			},
			{
				"Inspect (Trial Run)",
				"Kiểm tra (chạy thử)"
			},
			{
				"Train",
				"Huấn luyện"
			},
			{
				"Loading camera data...",
				"Đang tải dữ liệu camera..."
			},
			{
				"Tool Name",
				"Tên tool"
			},
			{
				"ROI Name",
				"Tên ROI"
			},
			{
				"ROI Value",
				"Giá trị ROI"
			},
			{
				"Total Value",
				"Tổng giá trị"
			},
			{
				"ROI Time",
				"Thời gian ROI"
			},
			{
				"Tool Time",
				"Thời gian tool"
			},
			{
				"Total Time",
				"Tổng thời gian"
			},
			{
				"Input Time",
				"Thời gian đầu vào"
			},
			{
				"TurnSnap Time",
				"Thời gian TurnSnap"
			},
			{
				"Master Time",
				"Thời gian master"
			},
			{
				"Find Line Time",
				"Thời gian tìm đường"
			},
			{
				"Line 1 Time",
				"Thời gian đường 1"
			},
			{
				"Line 2 Time",
				"Thời gian đường 2"
			},
			{
				"Master Status",
				"Trạng thái master"
			},
			{
				"Master Position",
				"Master vị trí"
			},
			{
				"Master Angle",
				"Master góc"
			},
			{
				"Master Tool",
				"Tool master"
			},
			{
				"Spec Status",
				"Trạng thái spec"
			},
			{
				"Spec Min mm",
				"Spec nhỏ nhất (mm)"
			},
			{
				"Spec Max mm",
				"Spec lớn nhất (mm)"
			},
			{
				"Distance mm",
				"Khoảng cách (mm)"
			},
			{
				"Image Source",
				"Nguồn ảnh"
			},
			{
				"Input Source",
				"Nguồn đầu vào"
			},
			{
				"Status",
				"Trạng thái"
			},
			{
				"Result",
				"Kết quả"
			},
			{
				"Time",
				"Thời gian"
			},
			{
				"Score",
				"Điểm khớp"
			},
			{
				"Match",
				"Khớp mẫu"
			},
			{
				"Picked",
				"Đã chọn"
			},
			{
				"Mode",
				"Chế độ"
			},
			{
				"Row",
				"Hàng"
			},
			{
				"Column",
				"Cột"
			},
			{
				"Grid Row",
				"Hàng lưới"
			},
			{
				"Grid Column",
				"Cột lưới"
			},
			{
				"Start Row",
				"Hàng bắt đầu"
			},
			{
				"Start Col",
				"Cột bắt đầu"
			},
			{
				"End Row",
				"Hàng kết thúc"
			},
			{
				"End Col",
				"Cột kết thúc"
			},
			{
				"Delta X",
				"Lệch X"
			},
			{
				"Delta Y",
				"Lệch Y"
			},
			{
				"Distance",
				"Khoảng cách"
			},
			{
				"Is Enabled",
				"Bật tool"
			},
			{
				"IsEnabled",
				"Bật tool"
			},
			{
				"Polarity",
				"Cực tính"
			},
			{
				"Threshold Polarity",
				"Cực tính ngưỡng"
			},
			{
				"Normal Size",
				"Giá trị chuẩn"
			},
			{
				"Upper Deviation",
				"Dung sai trên"
			},
			{
				"Lower Deviation",
				"Dung sai dưới"
			},
			{
				"Maximum Size",
				"Giá trị lớn nhất"
			},
			{
				"Minimum Size",
				"Giá trị nhỏ nhất"
			},
			{
				"Spec Mode",
				"Kiểu áp spec"
			},
			{
				"Work Scale",
				"Tỉ lệ xử lý"
			},
			{
				"Greediness",
				"Độ tham lam"
			},
			{
				"Interpolation",
				"Nội suy"
			},
			{
				"Operation",
				"Phép toán"
			},
			{
				"Transition",
				"Chuyển tiếp"
			},
			{
				"Selector",
				"Bộ chọn"
			},
			{
				"Preset",
				"Cấu hình sẵn"
			},
			{
				"Vendor",
				"Hãng"
			},
			{
				"Camera",
				"Camera"
			},
			{
				"Serial Camera",
				"Serial camera"
			},
			{
				"Communication",
				"Giao tiếp"
			},
			{
				"Hardware Trigger",
				"Trigger phần cứng"
			},
			{
				"Exposure Time",
				"Thời gian phơi sáng"
			},
			{
				"Gain",
				"Độ khuếch đại"
			},
			{
				"Pixel Format",
				"Định dạng điểm ảnh"
			},
			{
				"Image Format",
				"Định dạng ảnh"
			},
			{
				"Image Size",
				"Kích thước ảnh"
			},
			{
				"Image Mode",
				"Chế độ ảnh"
			},
			{
				"Light Source Preset",
				"Cấu hình nguồn sáng"
			},
			{
				"Check lost data",
				"Kiểm tra mất dữ liệu"
			},
			{
				"Trained",
				"Đã huấn luyện"
			},
			{
				"Trained Images",
				"Số ảnh đã huấn luyện"
			},
			{
				"Last Train Message",
				"Thông báo huấn luyện gần nhất"
			},
			{
				"Model Loaded",
				"Đã nạp model"
			},
			{
				"Variation Model Built",
				"Đã dựng variation model"
			},
			{
				"Prediction Ready",
				"Sẵn sàng dự đoán"
			},
			{
				"Num Levels (0 = auto)",
				"Số mức kim tự tháp (0 = tự động)"
			},
			{
				"Num Matches (0 = all)",
				"Số kết quả khớp (0 = tất cả)"
			},
			{
				"1 Pixel (mm)",
				"1 điểm ảnh (mm)"
			},
			{
				"mm/pixel",
				"mm/điểm ảnh"
			},
			{
				"+  Add New",
				"+  Thêm mới"
			},
			{
				"0 tags",
				"0 tag"
			},
			{
				"03 reads holding registers. 04 reads input registers.",
				"03 đọc holding register. 04 đọc input register."
			},
			{
				"1. Calibration Setting",
				"1. Cài đặt hiệu chuẩn"
			},
			{
				"2. Vision Preview",
				"2. Xem trước ảnh"
			},
			{
				"3. Calibration Log",
				"3. Nhật ký hiệu chuẩn"
			},
			{
				"4. Vision Detected Coordinates (Image)",
				"4. Toạ độ vision phát hiện (ảnh)"
			},
			{
				"5. Robot Real Coordinates (Base)",
				"5. Toạ độ thực của robot (base)"
			},
			{
				"6. Calibration Control",
				"6. Điều khiển hiệu chuẩn"
			},
			{
				"7. Calibration Result",
				"7. Kết quả hiệu chuẩn"
			},
			{
				"Action",
				"Thao tác"
			},
			{
				"Add",
				"Thêm"
			},
			{
				"Add a row at the end of the table",
				"Thêm một dòng vào cuối bảng"
			},
			{
				"Additional Information",
				"Thông tin thêm"
			},
			{
				"Address",
				"Địa chỉ"
			},
			{
				"All Logs",
				"Tất cả nhật ký"
			},
			{
				"Apply",
				"Áp dụng"
			},
			{
				"Apply And Save",
				"Áp dụng và lưu"
			},
			{
				"Apply Setting",
				"Áp dụng cài đặt"
			},
			{
				"Area scan",
				"Quét vùng"
			},
			{
				"Auto Read",
				"Tự động đọc"
			},
			{
				"Bottom camera",
				"Camera dưới"
			},
			{
				"Browse OPC Tags",
				"Duyệt tag OPC"
			},
			{
				"Browse PLC Tags",
				"Duyệt tag PLC"
			},
			{
				"Brush",
				"Bút vẽ"
			},
			{
				"Brush Size",
				"Cỡ bút"
			},
			{
				"CAMERA INFORMATION",
				"THÔNG TIN CAMERA"
			},
			{
				"CAMERA LIST",
				"DANH SÁCH CAMERA"
			},
			{
				"CREATE NEW MODEL",
				"TẠO MODEL MỚI"
			},
			{
				"Calibration File (.dat)",
				"File hiệu chuẩn (.dat)"
			},
			{
				"Camera Count",
				"Số lượng camera"
			},
			{
				"Camera Name *",
				"Tên camera *"
			},
			{
				"Camera Select",
				"Chọn camera"
			},
			{
				"Capture",
				"Chụp"
			},
			{
				"Category",
				"Danh mục"
			},
			{
				"Category:",
				"Danh mục:"
			},
			{
				"Change Protocol to selected type...",
				"Đổi Protocol sang kiểu đã chọn..."
			},
			{
				"Choose a folder...",
				"Chọn thư mục..."
			},
			{
				"Clear All Logs",
				"Xoá toàn bộ nhật ký"
			},
			{
				"Clear Logs",
				"Xoá nhật ký"
			},
			{
				"Clear all",
				"Xoá tất cả"
			},
			{
				"Clear selection",
				"Bỏ chọn"
			},
			{
				"Close",
				"Đóng"
			},
			{
				"Command",
				"Lệnh"
			},
			{
				"Config: --",
				"Cấu hình: --"
			},
			{
				"Confirm",
				"Xác nhận"
			},
			{
				"Connect",
				"Kết nối"
			},
			{
				"Connection Detail",
				"Chi tiết kết nối"
			},
			{
				"Connection Manager",
				"Quản lý kết nối"
			},
			{
				"Connection Name",
				"Tên kết nối"
			},
			{
				"Connection Setup",
				"Thiết lập kết nối"
			},
			{
				"Copy",
				"Sao chép"
			},
			{
				"Copy All",
				"Sao chép tất cả"
			},
			{
				"Copy Details",
				"Sao chép chi tiết"
			},
			{
				"Copy Log",
				"Sao chép nhật ký"
			},
			{
				"Copy Selected Log",
				"Sao chép dòng đã chọn"
			},
			{
				"Copy Visible Logs",
				"Sao chép nhật ký đang hiện"
			},
			{
				"Count Per Row :",
				"Số camera mỗi hàng :"
			},
			{
				"Create model",
				"Tạo model"
			},
			{
				"Created By",
				"Người tạo"
			},
			{
				"Created Date",
				"Ngày tạo"
			},
			{
				"Current Model: --",
				"Model hiện tại: --"
			},
			{
				"Data Exchange",
				"Chu kỳ trao đổi"
			},
			{
				"Data Monitor",
				"Giám sát dữ liệu"
			},
			{
				"Data Type",
				"Kiểu dữ liệu"
			},
			{
				"Data Type converts register data: INT16/UINT16 uses 1 register, INT32/UINT32/FLOAT uses 2 registers.",
				"Kiểu dữ liệu quyết định cách chuyển đổi: INT16/UINT16 dùng 1 register, INT32/UINT32/FLOAT dùng 2 register."
			},
			{
				"Decrease read cycle by 10 ms",
				"Giảm chu kỳ đọc 10 ms"
			},
			{
				"Define model information, configure vision settings and processing parameters",
				"Khai báo thông tin model, cấu hình vision và tham số xử lý"
			},
			{
				"Delete connection",
				"Xoá kết nối"
			},
			{
				"Delete model",
				"Xoá model"
			},
			{
				"Description",
				"Mô tả"
			},
			{
				"Details",
				"Chi tiết"
			},
			{
				"Disconnect",
				"Ngắt kết nối"
			},
			{
				"End Address",
				"Địa chỉ kết thúc"
			},
			{
				"Enter camera name...",
				"Nhập tên camera..."
			},
			{
				"Enter connection name",
				"Nhập tên kết nối"
			},
			{
				"Enter model name...",
				"Nhập tên model..."
			},
			{
				"Eraser",
				"Tẩy"
			},
			{
				"Errors",
				"Lỗi"
			},
			{
				"Export",
				"Xuất"
			},
			{
				"Export Calib",
				"Xuất hiệu chuẩn"
			},
			{
				"Export Config",
				"Xuất cấu hình"
			},
			{
				"Export Excel",
				"Xuất Excel"
			},
			{
				"Export as CSV",
				"Xuất ra CSV"
			},
			{
				"Export as Text",
				"Xuất ra văn bản"
			},
			{
				"Export to File...",
				"Xuất ra file..."
			},
			{
				"Fit",
				"Vừa khung"
			},
			{
				"Fit image",
				"Vừa khung hình"
			},
			{
				"From",
				"Từ"
			},
			{
				"Function Code",
				"Mã chức năng"
			},
			{
				"General Setting",
				"Cài đặt chung"
			},
			{
				"Group",
				"Nhóm"
			},
			{
				"Home",
				"Trang chủ"
			},
			{
				"INTELLIGENT VISION INSPECTION SYSTEM",
				"HỆ THỐNG KIỂM TRA VISION THÔNG MINH"
			},
			{
				"IP Address",
				"Địa chỉ IP"
			},
			{
				"Import Config",
				"Nhập cấu hình"
			},
			{
				"Increase read cycle by 10 ms",
				"Tăng chu kỳ đọc 10 ms"
			},
			{
				"Info",
				"Thông tin"
			},
			{
				"Initial Values",
				"Giá trị khởi tạo"
			},
			{
				"Insert",
				"Chèn"
			},
			{
				"Insert a row above the selected one - rows are written to the PLC in this order",
				"Chèn một dòng phía trên dòng đang chọn - thứ tự dòng là thứ tự ghi xuống PLC"
			},
			{
				"Keyword Search",
				"Tìm theo từ khoá"
			},
			{
				"LOG DETAILS",
				"CHI TIẾT NHẬT KÝ"
			},
			{
				"LOG VISION",
				"NHẬT KÝ VISION"
			},
			{
				"Left button = selected tool, right button = erase. Wheel zooms, MIDDLE button pans, double-click fits the image.",
				"Chuột trái = công cụ đang chọn, chuột phải = xoá. Lăn chuột để phóng to, chuột GIỮA để kéo ảnh, nhấp đúp để vừa khung."
			},
			{
				"Left camera",
				"Camera trái"
			},
			{
				"Light Select",
				"Chọn đèn"
			},
			{
				"Line scan",
				"Quét dòng"
			},
			{
				"Linked Tool",
				"Tool liên kết"
			},
			{
				"List model",
				"Danh sách model"
			},
			{
				"Live View",
				"Xem trực tiếp"
			},
			{
				"Load",
				"Nạp"
			},
			{
				"Load Image From File",
				"Nạp ảnh từ file"
			},
			{
				"Log Level",
				"Mức nhật ký"
			},
			{
				"Log Storage Path",
				"Đường dẫn lưu nhật ký"
			},
			{
				"Log storage settings",
				"Cài đặt lưu nhật ký"
			},
			{
				"Logs per page:",
				"Số dòng mỗi trang:"
			},
			{
				"MODEL",
				"MODEL"
			},
			{
				"MODEL INFORMATION",
				"THÔNG TIN MODEL"
			},
			{
				"Max Cameras Per Row",
				"Số camera tối đa mỗi hàng"
			},
			{
				"Maximize / Restore",
				"Phóng to / khôi phục"
			},
			{
				"Minimize",
				"Thu nhỏ"
			},
			{
				"Model Name *",
				"Tên model *"
			},
			{
				"Move All Points",
				"Di chuyển tất cả điểm"
			},
			{
				"Move To Point",
				"Di chuyển tới điểm"
			},
			{
				"Move turnsnap down",
				"Đưa TurnSnap xuống"
			},
			{
				"Move turnsnap up",
				"Đưa TurnSnap lên"
			},
			{
				"Needs a COLOUR image: red is separated as R - max(G, B), which a single-channel image cannot provide. Do not feed this tool the output of a Color To Gray filter.",
				"Cần ảnh MÀU: màu đỏ được tách theo R - max(G, B), ảnh một kênh không làm được. Đừng đưa ảnh từ filter Color To Gray vào tool này."
			},
			{
				"Needs a COLOUR image: the part is separated from the tray by the ratio between the red and blue channels, which a gray image cannot provide. Do not feed this tool the output of a Color To Gray filter.",
				"Cần ảnh MÀU: chi tiết được tách khỏi khay dựa trên tỉ lệ giữa kênh đỏ và kênh lam, ảnh xám không có thông tin đó. Đừng đưa ảnh từ filter Color To Gray vào tool này."
			},
			{
				"Network Setting",
				"Cài đặt mạng"
			},
			{
				"New model name",
				"Tên model mới"
			},
			{
				"Next page",
				"Trang sau"
			},
			{
				"No folder selected",
				"Chưa chọn thư mục"
			},
			{
				"No model",
				"Chưa có model"
			},
			{
				"No model selected",
				"Chưa chọn model"
			},
			{
				"NodeId / Address",
				"NodeId / Địa chỉ"
			},
			{
				"None (always save)",
				"Không (luôn lưu)"
			},
			{
				"OFF",
				"TẮT"
			},
			{
				"OPC Heartbeat",
				"OPC Heartbeat"
			},
			{
				"OPC Tag Monitor",
				"Giám sát tag OPC"
			},
			{
				"On",
				"Bật"
			},
			{
				"Open Folder",
				"Mở thư mục"
			},
			{
				"Open Log Vision Tab",
				"Mở tab Log Vision"
			},
			{
				"Operation Guide",
				"Hướng dẫn thao tác"
			},
			{
				"PLC: Disconnected | CAM: OK",
				"PLC: Mất kết nối | CAM: OK"
			},
			{
				"Parameters",
				"Tham số"
			},
			{
				"Pause",
				"Tạm dừng"
			},
			{
				"Pick dates",
				"Chọn ngày"
			},
			{
				"Point",
				"Điểm"
			},
			{
				"Point Status",
				"Trạng thái điểm"
			},
			{
				"Port",
				"Cổng"
			},
			{
				"Previous page",
				"Trang trước"
			},
			{
				"Protocol",
				"Giao thức"
			},
			{
				"Protocol Information",
				"Thông tin giao thức"
			},
			{
				"Quality",
				"Chất lượng"
			},
			{
				"Query to current time",
				"Truy vấn tới hiện tại"
			},
			{
				"R/W",
				"Đọc/Ghi"
			},
			{
				"RMS Error (mm)",
				"Sai số RMS (mm)"
			},
			{
				"Read All",
				"Đọc tất cả"
			},
			{
				"Read Cycle (ms)",
				"Chu kỳ đọc (ms)"
			},
			{
				"Read Range",
				"Dải đọc"
			},
			{
				"Read Tags",
				"Đọc tag"
			},
			{
				"Reads all OPC UA tags marked as Read in Tag Management. Address must be a NodeId such as ns=2;s=TagName or ns=2;i=1001.",
				"Đọc tất cả tag OPC UA được đánh dấu Read trong Tag Management. Address phải là NodeId, ví dụ ns=2;s=TagName hoặc ns=2;i=1001."
			},
			{
				"Ready for test",
				"Sẵn sàng kiểm tra"
			},
			{
				"Refresh",
				"Làm mới"
			},
			{
				"Refresh Light Controllers",
				"Làm mới bộ điều khiển đèn"
			},
			{
				"Refresh Serial Cameras",
				"Làm mới camera serial"
			},
			{
				"Reload Initial Values from the current model communication_config.json",
				"Nạp lại Initial Values từ communication_config.json của model hiện tại"
			},
			{
				"Reload Model Data",
				"Nạp lại dữ liệu model"
			},
			{
				"Rename Application Title",
				"Đổi tiêu đề ứng dụng"
			},
			{
				"Rename model",
				"Đổi tên model"
			},
			{
				"Reprojection Error (px)",
				"Sai số tái chiếu (px)"
			},
			{
				"Reset",
				"Đặt lại"
			},
			{
				"Result Field",
				"Trường kết quả"
			},
			{
				"Right camera",
				"Camera phải"
			},
			{
				"Right-click for options",
				"Chuột phải để mở tuỳ chọn"
			},
			{
				"Robot Command / Info",
				"Lệnh / thông tin robot"
			},
			{
				"Robot Control",
				"Điều khiển robot"
			},
			{
				"Row: -  Col: -  Gray: -  R: -  G: -  B: -  Size: -",
				"Hàng: -  Cột: -  Xám: -  R: -  G: -  B: -  Cỡ: -"
			},
			{
				"Run",
				"Chạy"
			},
			{
				"Rx (deg)",
				"Rx (deg)"
			},
			{
				"Ry (deg)",
				"Ry (deg)"
			},
			{
				"Rz (deg)",
				"Rz (deg)"
			},
			{
				"SYSTEM NOT READY",
				"HỆ THỐNG CHƯA SẴN SÀNG"
			},
			{
				"Save Calib",
				"Lưu hiệu chuẩn"
			},
			{
				"Save Image...",
				"Lưu ảnh..."
			},
			{
				"Save Light Config",
				"Lưu cấu hình đèn"
			},
			{
				"Save Path",
				"Đường dẫn lưu"
			},
			{
				"Save Region",
				"Lưu vùng"
			},
			{
				"Search connection...",
				"Tìm kết nối..."
			},
			{
				"Search message...",
				"Tìm nội dung..."
			},
			{
				"Select a log row to view details.",
				"Chọn một dòng để xem chi tiết."
			},
			{
				"Select folder",
				"Chọn thư mục"
			},
			{
				"Select the Calib Hand-Eye tools to combine:",
				"Chọn các tool Calib Hand-Eye cần kết hợp:"
			},
			{
				"Select the connection used to read camera trigger snap/run tags.",
				"Chọn kết nối dùng để đọc tag snap/run của camera."
			},
			{
				"Select tools to combine (NG if any is NG):",
				"Chọn các tool cần kết hợp (một tool NG là NG):"
			},
			{
				"Selected Point",
				"Điểm đã chọn"
			},
			{
				"Send",
				"Gửi"
			},
			{
				"Setting",
				"Cài đặt"
			},
			{
				"Show details",
				"Xem chi tiết"
			},
			{
				"Showing 0 logs",
				"Đang hiện 0 dòng"
			},
			{
				"Sort by time",
				"Sắp xếp theo thời gian"
			},
			{
				"Source",
				"Nguồn"
			},
			{
				"Source/Module",
				"Nguồn / Mô-đun"
			},
			{
				"Stack Trace",
				"Stack trace"
			},
			{
				"Start Address",
				"Địa chỉ bắt đầu"
			},
			{
				"Start Calibration",
				"Bắt đầu hiệu chuẩn"
			},
			{
				"Start Camera",
				"Bật camera"
			},
			{
				"Stop",
				"Dừng"
			},
			{
				"Stop Camera",
				"Tắt camera"
			},
			{
				"Success",
				"Thành công"
			},
			{
				"Tag Label",
				"Nhãn tag"
			},
			{
				"Tag Management",
				"Quản lý tag"
			},
			{
				"Tag Name",
				"Tên tag"
			},
			{
				"Tags",
				"Tag"
			},
			{
				"Tags:",
				"Tag:"
			},
			{
				"Teach Current Pose",
				"Dạy vị trí hiện tại"
			},
			{
				"Test",
				"Kiểm tra"
			},
			{
				"The model data folder and its recipe file are renamed too.",
				"Thư mục dữ liệu model và file recipe cũng được đổi tên theo."
			},
			{
				"Tick the tools that should appear in the toolbox. Unticked tools are hidden from the tree; tools already placed in a TurnSnap keep working either way.",
				"Tick những tool muốn hiện trong toolbox. Tool không tick sẽ bị ẩn khỏi cây; tool đã đặt trong TurnSnap vẫn chạy bình thường."
			},
			{
				"Time Range",
				"Khoảng thời gian"
			},
			{
				"Timeout (ms)",
				"Thời gian chờ (ms)"
			},
			{
				"Timestamp",
				"Thời điểm"
			},
			{
				"To",
				"Đến"
			},
			{
				"Tool",
				"Tool"
			},
			{
				"Top camera",
				"Camera trên"
			},
			{
				"Train on a master image that contains ONE product. Beside the shape model this also learns the product silhouette, the printed text and the master image, which the layer test needs.",
				"Huấn luyện trên ảnh master chỉ chứa MỘT sản phẩm. Ngoài shape model, nó còn học đường bao sản phẩm, chữ in và chính ảnh master - những thứ mà phép kiểm tra lớp cần."
			},
			{
				"Turn on Show Threshold, then drag the sliders - the picture re-runs as you drag. Draw one or more ROIs (a painted one works too) so only objects inside them are counted.",
				"Bật Hiện ngưỡng rồi kéo thanh trượt - ảnh chạy lại ngay khi kéo. Vẽ một hoặc nhiều ROI (ROI tô tay cũng được) để chỉ đếm đối tượng nằm trong đó."
			},
			{
				"Use same setting for all channels",
				"Dùng chung cài đặt cho tất cả kênh"
			},
			{
				"VISION PRESS MACHINE",
				"MÁY VISION PRESS"
			},
			{
				"Version",
				"Phiên bản"
			},
			{
				"Version:",
				"Phiên bản:"
			},
			{
				"View Detail",
				"Xem chi tiết"
			},
			{
				"View and analyze system logs",
				"Xem và phân tích nhật ký hệ thống"
			},
			{
				"Vision Trigger Camera Connection",
				"Kết nối camera nhận trigger"
			},
			{
				"Waiting for trigger...",
				"Đang chờ trigger..."
			},
			{
				"Warnings",
				"Cảnh báo"
			},
			{
				"When on, Trial Run tries all types and fills the detected one above.",
				"Khi bật, Trial Run sẽ thử tất cả các kiểu và điền kiểu nhận được vào ô trên."
			},
			{
				"Work Station (Logical Station No.)",
				"Work Station (số trạm logic)"
			},
			{
				"Write To PLC Now",
				"Ghi xuống PLC ngay"
			},
			{
				"Write value",
				"Giá trị ghi"
			},
			{
				"X (mm)",
				"X (mm)"
			},
			{
				"X (px)",
				"X (px)"
			},
			{
				"Y (mm)",
				"Y (mm)"
			},
			{
				"Y (px)",
				"Y (px)"
			},
			{
				"Z (mm)",
				"Z (mm)"
			},
			{
				"Zoom +",
				"Phóng to"
			},
			{
				"Zoom -",
				"Thu nhỏ"
			},
			{
				"Zoom: 100%",
				"Thu phóng: 100%"
			},
			{
				"30 px",
				"30 px"
			},
			{
				"Camera Basler",
				"Camera Basler"
			},
			{
				"Clear Log",
				"Xoá nhật ký"
			},
			{
				"Code",
				"Mã"
			},
			{
				"Copy Message",
				"Sao chép nội dung"
			},
			{
				"Copy Row",
				"Sao chép dòng"
			},
			{
				"Level",
				"Mức"
			},
			{
				"No log yet.",
				"Chưa có nhật ký."
			},
			{
				"Note",
				"Ghi chú"
			},
			{
				"Procedure File",
				"File procedure"
			},
			{
				"Train Procedure",
				"Procedure huấn luyện"
			},
			{
				"Train Procedure (optional)",
				"Procedure huấn luyện (tùy chọn)"
			},
			{
				"Find Procedure",
				"Procedure tìm"
			},
			{
				"Input parameters",
				"Tham số đầu vào"
			},
			{
				"Train (from ROI)",
				"Huấn luyện (từ ROI)"
			},
			{
				"Define Master",
				"Định nghĩa master"
			},
			{
				"Find (Trial Run)",
				"Tìm (chạy thử)"
			},
			{
				"Reload",
				"Tải lại"
			},
			{
				"Image Input Name",
				"Tên input ảnh"
			},
			{
				"Train Region Input Name",
				"Tên input vùng huấn luyện"
			},
			{
				"Search Region Input Name",
				"Tên input vùng tìm kiếm"
			},
			{
				"Model Path Input Name",
				"Tên input đường dẫn model"
			},
			{
				"Train Preview Output",
				"Output xem trước huấn luyện"
			},
			{
				"Row Output Name",
				"Tên output hàng"
			},
			{
				"Column Output Name",
				"Tên output cột"
			},
			{
				"Angle Output Name",
				"Tên output góc"
			},
			{
				"Score Output Name",
				"Tên output điểm"
			},
			{
				"Angle Is In Degrees",
				"Góc tính bằng độ"
			},
			{
				"Reduce Search To Limit ROI",
				"Giới hạn tìm kiếm trong limit ROI"
			},
			{
				"Drop Matches Outside Limit ROI",
				"Bỏ kết quả ngoài limit ROI"
			},
			{
				"Sort Mode",
				"Kiểu sắp xếp"
			},
			{
				"Pick Mode",
				"Kiểu chọn"
			},
			{
				"Show Objects",
				"Hiện đối tượng"
			},
			{
				"Show Cross",
				"Hiện dấu chữ thập"
			},
			{
				"Cross Size",
				"Cỡ dấu chữ thập"
			},
			{
				"Limit ROI Color",
				"Màu limit ROI"
			},
			{
				"Train Result",
				"Kết quả huấn luyện"
			},
			{
				"Draw the ROI on this tool and press Train: the ROI is what gets learned. Draw a Limit ROI to keep the returned coordinates inside one area of the image.",
				"Khoanh ROI trên tool này rồi nhấn Train: phần ROI chính là phần được học. Khoanh thêm Limit ROI để giới hạn tọa độ trả về trong một vùng của ảnh."
			},
			{
				"Pick Row / Pick Column choose which found object this master publishes to Calib Hand-Eye and Result Align; the rest are still numbered and drawn.",
				"Pick Row / Pick Column chọn vật thể nào sẽ được master này gửi xuống Calib Hand-Eye và Result Align; các vật còn lại vẫn được đánh số và vẽ."
			},
			{
				"Procedure Name",
				"Tên procedure"
			},
			{
				"ROI Mode",
				"Kiểu ROI"
			},
			{
				"ROI Delivery",
				"Cách truyền ROI"
			},
			{
				"ROI Input Name",
				"Tên input ROI"
			},
			{
				"Result Value Output",
				"Output giá trị kết quả"
			},
			{
				"Status Output",
				"Output trạng thái"
			},
			{
				"Aggregate (Per ROI)",
				"Tổng hợp (theo từng ROI)"
			},
			{
				"Output Image Name",
				"Tên ảnh output"
			},
			{
				"Objects To Draw",
				"Đối tượng cần vẽ"
			},
			{
				"Draw Filled",
				"Vẽ tô đặc"
			},
			{
				"Object Color",
				"Màu đối tượng"
			},
			{
				"Line Width",
				"Độ dày nét"
			},
			{
				"ROI Color",
				"Màu ROI"
			},
			{
				"Value Text Color",
				"Màu chữ giá trị"
			},
			{
				"Value Text Size",
				"Cỡ chữ giá trị"
			},
			{
				"Value Offset X",
				"Lệch X của chữ giá trị"
			},
			{
				"Value Offset Y",
				"Lệch Y của chữ giá trị"
			},
			{
				"Check Value",
				"Kiểm tra giá trị"
			},
			{
				"Value Min",
				"Giá trị tối thiểu"
			},
			{
				"Value Max",
				"Giá trị tối đa"
			},
			{
				"Check Status Output",
				"Kiểm tra output trạng thái"
			},
			{
				"Status OK Value",
				"Giá trị trạng thái OK"
			},
			{
				"The image chosen here is what the procedure receives. Draw ROIs on this tool as on any other - how they reach the procedure is set in the Procedure tab.",
				"Ảnh chọn ở đây chính là ảnh được đưa vào procedure. Khoanh ROI trên tool này như các tool khác – cách ROI đi vào procedure được cài ở tab Procedure."
			},
			{
				"ROI Delivery Reduce Domain works with any procedure, even one written without a region parameter. Result Value Output picks which returned number is THE value of this tool - the one the spec judges and Result Inspection reads; leave it empty to take the first numeric output.",
				"ROI Delivery Reduce Domain dùng được với mọi procedure, kể cả procedure không có tham số region. Result Value Output chọn số nào trong kết quả trả về là giá trị của tool này – giá trị mà spec chấm và Result Inspection đọc; để trống thì lấy số đầu tiên."
			},
			{
				"Light on",
				"Bật đèn"
			}
		};

		// Token: 0x04000E11 RID: 3601
		private static readonly Dictionary<string, string> VietnameseTerms = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
		{
			{
				"Area",
				"diện tích"
			},
			{
				"Blob Area",
				"diện tích blob"
			},
			{
				"Box Area",
				"diện tích khung"
			},
			{
				"Total Area",
				"tổng diện tích"
			},
			{
				"Patch Area",
				"diện tích mảng"
			},
			{
				"Band Area",
				"diện tích dải"
			},
			{
				"Contact Area",
				"diện tích tiếp xúc"
			},
			{
				"Overlap Area",
				"diện tích chồng lấn"
			},
			{
				"Overlap Core",
				"lõi chồng lấn"
			},
			{
				"Defect Area",
				"diện tích lỗi"
			},
			{
				"Product Area",
				"diện tích sản phẩm"
			},
			{
				"Inspect Area",
				"diện tích kiểm tra"
			},
			{
				"Cavity Min Area",
				"diện tích hốc nhỏ nhất"
			},
			{
				"Red Min Area",
				"diện tích đỏ nhỏ nhất"
			},
			{
				"Chroma Min Area",
				"diện tích màu nhỏ nhất"
			},
			{
				"Arrow Area",
				"diện tích mũi tên"
			},
			{
				"Color Mark",
				"dấu màu"
			},
			{
				"Foreign Object",
				"dị vật"
			},
			{
				"Foreign Object Size",
				"kích thước dị vật"
			},
			{
				"Total Defect Area",
				"tổng diện tích lỗi"
			},
			{
				"Defect Min Area",
				"diện tích lỗi nhỏ nhất"
			},
			{
				"Patch Band",
				"dải mảng"
			},
			{
				"Angle",
				"góc"
			},
			{
				"Delta Angle",
				"góc lệch"
			},
			{
				"Out-Of-Range Offset X",
				"bù X khi ngoài tầm"
			},
			{
				"Out-Of-Range Offset Y",
				"bù Y khi ngoài tầm"
			},
			{
				"Out-Of-Range Offset Angle",
				"bù góc khi ngoài tầm"
			},
			{
				"Threshold",
				"ngưỡng"
			},
			{
				"Abs Threshold",
				"ngưỡng tuyệt đối"
			},
			{
				"Var Threshold",
				"ngưỡng phương sai"
			},
			{
				"Var Abs Threshold",
				"ngưỡng phương sai tuyệt đối"
			},
			{
				"Diff Threshold",
				"ngưỡng sai khác"
			},
			{
				"Score Threshold",
				"ngưỡng điểm khớp"
			},
			{
				"Measure Threshold",
				"ngưỡng đo"
			},
			{
				"Print Threshold",
				"ngưỡng bản in"
			},
			{
				"Product Threshold",
				"ngưỡng sản phẩm"
			},
			{
				"Redness Threshold",
				"ngưỡng độ đỏ"
			},
			{
				"Defect Threshold",
				"ngưỡng lỗi"
			},
			{
				"Color Threshold",
				"ngưỡng màu"
			},
			{
				"Threshold Region",
				"vùng ngưỡng"
			},
			{
				"Threshold Color",
				"màu vùng ngưỡng"
			},
			{
				"Threshold Fill",
				"tô đặc vùng ngưỡng"
			},
			{
				"Color",
				"màu"
			},
			{
				"Text Color",
				"màu chữ"
			},
			{
				"Text Size",
				"cỡ chữ"
			},
			{
				"Index Text Color",
				"màu chữ chỉ số"
			},
			{
				"Index Text Size",
				"cỡ chữ chỉ số"
			},
			{
				"Summary Text Color",
				"màu chữ tổng kết"
			},
			{
				"Summary Text Size",
				"cỡ chữ tổng kết"
			},
			{
				"Coordinate Text Color",
				"màu chữ toạ độ"
			},
			{
				"Coordinate Text Size",
				"cỡ chữ toạ độ"
			},
			{
				"Box Color",
				"màu khung"
			},
			{
				"Mask Color",
				"màu mask"
			},
			{
				"Part Color",
				"màu chi tiết"
			},
			{
				"Arrow Color",
				"màu mũi tên"
			},
			{
				"Defect Color",
				"màu lỗi"
			},
			{
				"Contour Color",
				"màu đường bao"
			},
			{
				"Model Contour Color",
				"màu đường bao model"
			},
			{
				"Display Color",
				"màu hiển thị"
			},
			{
				"Match Color",
				"màu kết quả khớp"
			},
			{
				"Mesh Color",
				"màu lưới"
			},
			{
				"Top Color",
				"màu trên"
			},
			{
				"Bottom Color",
				"màu dưới"
			},
			{
				"Empty Cell Color",
				"màu ô trống"
			},
			{
				"Inspect Region Color",
				"màu vùng kiểm tra"
			},
			{
				"Contact Zone Color",
				"màu vùng tiếp xúc"
			},
			{
				"Rotation Fill Color",
				"màu nền khi xoay"
			},
			{
				"Multi ROI Color",
				"màu ROI nhóm"
			},
			{
				"Multi Center Color",
				"màu tâm nhóm"
			},
			{
				"Multi Text Color",
				"màu chữ nhóm"
			},
			{
				"Radius",
				"bán kính"
			},
			{
				"Close Radius",
				"bán kính closing"
			},
			{
				"Open Radius",
				"bán kính opening"
			},
			{
				"Body Close Radius",
				"bán kính closing thân"
			},
			{
				"Cavity Close Radius",
				"bán kính closing hốc"
			},
			{
				"Color Close Radius",
				"bán kính closing màu"
			},
			{
				"Color Open Radius",
				"bán kính opening màu"
			},
			{
				"Count",
				"số lượng"
			},
			{
				"Object Count",
				"số đối tượng"
			},
			{
				"Part Count",
				"số chi tiết"
			},
			{
				"Product Count",
				"số sản phẩm"
			},
			{
				"Arrow Count",
				"số mũi tên"
			},
			{
				"Defect Count",
				"số lỗi"
			},
			{
				"Foreign Object Count",
				"số dị vật"
			},
			{
				"Sample Count",
				"số mẫu"
			},
			{
				"Empty Pockets",
				"số ô trống"
			},
			{
				"Width",
				"chiều rộng"
			},
			{
				"Height",
				"chiều cao"
			},
			{
				"Box Width",
				"chiều rộng khung"
			},
			{
				"Box Height",
				"chiều cao khung"
			},
			{
				"Mask Width",
				"chiều rộng mask"
			},
			{
				"Mask Height",
				"chiều cao mask"
			},
			{
				"Edge Band Width",
				"bề rộng dải biên"
			},
			{
				"Mesh Line Width",
				"độ dày nét lưới"
			},
			{
				"Score",
				"điểm khớp"
			},
			{
				"Score Margin",
				"biên điểm khớp"
			},
			{
				"Min Score",
				"điểm khớp tối thiểu"
			},
			{
				"Contrast",
				"độ tương phản"
			},
			{
				"Min Contrast",
				"độ tương phản tối thiểu"
			},
			{
				"Sigma",
				"sigma"
			},
			{
				"Offset",
				"độ lệch"
			},
			{
				"Offset X",
				"độ lệch X"
			},
			{
				"Offset Y",
				"độ lệch Y"
			},
			{
				"Offset Angle",
				"độ lệch góc"
			},
			{
				"Index Offset X",
				"lệch chỉ số theo X"
			},
			{
				"Index Offset Y",
				"lệch chỉ số theo Y"
			},
			{
				"Rotation Angle",
				"góc xoay"
			},
			{
				"Angle Range",
				"khoảng góc"
			},
			{
				"Angle Extent",
				"biên độ góc"
			},
			{
				"Angle Start",
				"góc bắt đầu"
			},
			{
				"Start Phi",
				"góc bắt đầu"
			},
			{
				"End Phi",
				"góc kết thúc"
			},
			{
				"Center Angle",
				"góc tâm"
			},
			{
				"Center Length",
				"chiều dài tâm"
			},
			{
				"Length 1",
				"chiều dài 1"
			},
			{
				"Length 2",
				"chiều dài 2"
			},
			{
				"Margin",
				"lề"
			},
			{
				"Box Margin",
				"lề khung"
			},
			{
				"Border Margin",
				"lề biên"
			},
			{
				"Inner Margin",
				"lề trong"
			},
			{
				"Defect Box Margin",
				"lề khung lỗi"
			},
			{
				"Spacing",
				"khoảng cách"
			},
			{
				"Row Spacing",
				"khoảng cách hàng"
			},
			{
				"Column Spacing",
				"khoảng cách cột"
			},
			{
				"Mesh Spacing",
				"khoảng cách lưới"
			},
			{
				"Row Pitch",
				"bước hàng"
			},
			{
				"Column Pitch",
				"bước cột"
			},
			{
				"Grid Rows",
				"số hàng lưới"
			},
			{
				"Grid Columns",
				"số cột lưới"
			},
			{
				"Group Gap X",
				"khoảng cách gộp theo X"
			},
			{
				"Group Gap Y",
				"khoảng cách gộp theo Y"
			},
			{
				"Grouping",
				"gộp nhóm"
			},
			{
				"Min Center Distance",
				"khoảng cách tâm tối thiểu"
			},
			{
				"Contact Distance",
				"khoảng cách tiếp xúc"
			},
			{
				"Actual Distance",
				"khoảng cách thực"
			},
			{
				"Pixel Distance",
				"khoảng cách theo điểm ảnh"
			},
			{
				"Last Distance",
				"khoảng cách lần cuối"
			},
			{
				"Last Pixel Distance",
				"khoảng cách điểm ảnh lần cuối"
			},
			{
				"Last Value",
				"giá trị lần cuối"
			},
			{
				"Last Pixel Value",
				"giá trị điểm ảnh lần cuối"
			},
			{
				"Actual Value",
				"giá trị thực"
			},
			{
				"Pixel Value",
				"giá trị điểm ảnh"
			},
			{
				"Red Min Value",
				"giá trị đỏ nhỏ nhất"
			},
			{
				"ROI",
				"ROI"
			},
			{
				"ROI Index",
				"chỉ số ROI"
			},
			{
				"Limit ROI",
				"limit ROI"
			},
			{
				"Multi ROI",
				"ROI nhóm"
			},
			{
				"Multi ROI Center",
				"tâm ROI nhóm"
			},
			{
				"Mask",
				"mask"
			},
			{
				"Mask Type",
				"kiểu mask"
			},
			{
				"Mask Fill",
				"tô đặc mask"
			},
			{
				"NCC Mask Size",
				"cỡ mask NCC"
			},
			{
				"Index",
				"chỉ số"
			},
			{
				"Input Image",
				"ảnh đầu vào"
			},
			{
				"Redness Image",
				"ảnh độ đỏ"
			},
			{
				"Rotation Image",
				"ảnh xoay"
			},
			{
				"Warped Mesh",
				"lưới biến dạng"
			},
			{
				"Text",
				"chữ"
			},
			{
				"Value Text",
				"chữ giá trị"
			},
			{
				"Coordinate Text",
				"chữ toạ độ"
			},
			{
				"Layer Label",
				"nhãn lớp"
			},
			{
				"Size",
				"kích thước"
			},
			{
				"Box",
				"khung"
			},
			{
				"Boxes",
				"khung"
			},
			{
				"All Boxes",
				"tất cả khung"
			},
			{
				"Center",
				"tâm"
			},
			{
				"Contours",
				"đường bao"
			},
			{
				"Model Contour",
				"đường bao model"
			},
			{
				"Defects",
				"lỗi"
			},
			{
				"Parts",
				"chi tiết"
			},
			{
				"Matches",
				"kết quả khớp"
			},
			{
				"All Matches",
				"tất cả kết quả khớp"
			},
			{
				"Found Circle",
				"đường tròn tìm được"
			},
			{
				"Found Line",
				"đường thẳng tìm được"
			},
			{
				"Source Lines",
				"đường nguồn"
			},
			{
				"Intersection Point",
				"điểm giao"
			},
			{
				"Search Outline",
				"khung vùng tìm"
			},
			{
				"Inspect Region",
				"vùng kiểm tra"
			},
			{
				"Contact Zone",
				"vùng tiếp xúc"
			},
			{
				"Evidence Band",
				"dải bằng chứng"
			},
			{
				"Empty Cells",
				"ô trống"
			},
			{
				"Angle Guide",
				"vạch chỉ góc"
			},
			{
				"Arrow",
				"mũi tên"
			},
			{
				"Arrows",
				"mũi tên"
			},
			{
				"Object Order",
				"thứ tự đối tượng"
			},
			{
				"Result",
				"kết quả"
			},
			{
				"Mode",
				"chế độ"
			},
			{
				"Filter Type",
				"kiểu lọc"
			},
			{
				"Code Type",
				"kiểu mã"
			},
			{
				"Canvas Mode",
				"chế độ khung ảnh"
			},
			{
				"Region Mode",
				"chế độ vùng"
			},
			{
				"Object Mode",
				"chế độ đối tượng"
			},
			{
				"Value Mode",
				"chế độ giá trị"
			},
			{
				"Measure Mode",
				"chế độ đo"
			},
			{
				"Measurement Mode",
				"chế độ đo"
			},
			{
				"Naming Mode",
				"quy tắc đặt tên"
			},
			{
				"Folder Mode",
				"chế độ thư mục"
			},
			{
				"Angle Delta Mode",
				"chế độ lệch góc"
			},
			{
				"Coordinate Sort Mode",
				"chế độ sắp xếp toạ độ"
			},
			{
				"Sort Output Order",
				"thứ tự sắp xếp kết quả"
			},
			{
				"Defect Method",
				"phương pháp bắt lỗi"
			},
			{
				"Auto Search Type",
				"kiểu tìm tự động"
			},
			{
				"Flip Direction",
				"hướng lật"
			},
			{
				"Mirror Row",
				"lật theo hàng"
			},
			{
				"Mirror Column",
				"lật theo cột"
			},
			{
				"Pick Row",
				"hàng chọn"
			},
			{
				"Pick Column",
				"cột chọn"
			},
			{
				"Position Points",
				"điểm vị trí"
			},
			{
				"Rotation Points",
				"điểm xoay"
			},
			{
				"Max Points",
				"số điểm tối đa"
			},
			{
				"Class Filter",
				"lọc theo lớp"
			},
			{
				"Detect URL",
				"địa chỉ nhận diện"
			},
			{
				"Model File",
				"file model"
			},
			{
				"Model Path",
				"đường dẫn model"
			},
			{
				"Model Key",
				"khoá model"
			},
			{
				"Weight Path",
				"đường dẫn file trọng số"
			},
			{
				"Calibration File Path",
				"đường dẫn file hiệu chuẩn"
			},
			{
				"Save Folder",
				"thư mục lưu"
			},
			{
				"Crop Folder",
				"thư mục ảnh cắt"
			},
			{
				"File Name Prefix",
				"tiền tố tên file"
			},
			{
				"Save Condition",
				"điều kiện lưu"
			},
			{
				"Load Time",
				"thời gian nạp"
			},
			{
				"Linked Result Inspection",
				"tool tổng hợp liên kết"
			},
			{
				"Tray Grid",
				"lưới khay"
			},
			{
				"Calibration",
				"hiệu chuẩn"
			},
			{
				"Specular Rescue",
				"cứu vùng loá"
			},
			{
				"Manual Robot TCP",
				"TCP robot nhập tay"
			},
			{
				"TCP Offset",
				"bù TCP"
			},
			{
				"TCP To Mapping",
				"TCP vào phép ánh xạ"
			},
			{
				"Out-Of-Range Offset",
				"bù khi ngoài tầm"
			},
			{
				"Interlocked Objects",
				"đối tượng dính nhau"
			},
			{
				"Rotation Canvas",
				"khung ảnh khi xoay"
			},
			{
				"Min Inliers",
				"số điểm hợp lệ tối thiểu"
			},
			{
				"Min Inside Ratio",
				"tỉ lệ nằm trong tối thiểu"
			},
			{
				"Min Mean Redness",
				"độ đỏ trung bình tối thiểu"
			},
			{
				"Min Golden Matches",
				"số khớp mẫu chuẩn tối thiểu"
			},
			{
				"Min Print Pixels",
				"số điểm ảnh bản in tối thiểu"
			},
			{
				"Max Instances",
				"số thực thể tối đa"
			},
			{
				"Max Matches",
				"số kết quả khớp tối đa"
			},
			{
				"Max Overlap",
				"độ chồng lấn tối đa"
			},
			{
				"Max Anisometry",
				"độ dẹt tối đa"
			},
			{
				"Max Corner Shift",
				"dịch góc tối đa"
			},
			{
				"Num Instances",
				"số thực thể"
			},
			{
				"Num Level",
				"số mức"
			},
			{
				"Num Matched",
				"số đã khớp"
			},
			{
				"Create Num Levels",
				"số mức khi tạo model"
			},
			{
				"Find Num Levels",
				"số mức khi tìm"
			},
			{
				"Deformation",
				"độ biến dạng"
			},
			{
				"Max Deformation",
				"biến dạng lớn nhất"
			},
			{
				"Mean Deformation",
				"biến dạng trung bình"
			},
			{
				"Deformation Smoothness",
				"độ mượt biến dạng"
			},
			{
				"Scale Deviation",
				"sai lệch tỉ lệ"
			},
			{
				"Scale Row",
				"tỉ lệ theo hàng"
			},
			{
				"Scale Column",
				"tỉ lệ theo cột"
			},
			{
				"Match Tolerance",
				"dung sai khớp"
			},
			{
				"Print Hit Tolerance",
				"dung sai trúng bản in"
			},
			{
				"Print Dilate",
				"giãn bản in"
			},
			{
				"Print Ratio Below",
				"tỉ lệ in phía dưới"
			},
			{
				"Print Ratio On Top",
				"tỉ lệ in phía trên"
			},
			{
				"Region Shrink",
				"co vùng"
			},
			{
				"Overlap Erode",
				"bào mòn chồng lấn"
			},
			{
				"Smooth Window",
				"cửa sổ làm mượt"
			},
			{
				"Normalize Window",
				"cửa sổ chuẩn hoá"
			},
			{
				"Background Window",
				"cửa sổ nền"
			},
			{
				"Normalize Gain",
				"hệ số chuẩn hoá"
			},
			{
				"Normalize Offset",
				"độ lệch chuẩn hoá"
			},
			{
				"Normalize Weights",
				"chuẩn hoá trọng số"
			},
			{
				"Diff Smooth",
				"làm mượt sai khác"
			},
			{
				"Factor",
				"hệ số"
			},
			{
				"Gray",
				"mức xám"
			},
			{
				"Red",
				"đỏ"
			},
			{
				"Green",
				"lục"
			},
			{
				"Blue",
				"lam"
			},
			{
				"Bright R",
				"sáng kênh R"
			},
			{
				"Bright G",
				"sáng kênh G"
			},
			{
				"Bright B",
				"sáng kênh B"
			},
			{
				"Weight R",
				"trọng số R"
			},
			{
				"Weight G",
				"trọng số G"
			},
			{
				"Weight B",
				"trọng số B"
			},
			{
				"Weight Edge",
				"trọng số biên"
			},
			{
				"Weight Step",
				"trọng số bậc"
			},
			{
				"Weight Print",
				"trọng số bản in"
			},
			{
				"Weight Score",
				"trọng số điểm"
			},
			{
				"Weight Appearance",
				"trọng số bề mặt"
			},
			{
				"Chroma Min Diff",
				"chênh lệch màu tối thiểu"
			},
			{
				"Red Min Diff",
				"chênh lệch đỏ tối thiểu"
			},
			{
				"Cavity Offset",
				"bù hốc"
			},
			{
				"Step Inner",
				"bậc trong"
			},
			{
				"Step Outer",
				"bậc ngoài"
			},
			{
				"Step Exclude Other",
				"bậc loại trừ khác"
			},
			{
				"Relative Margin Patch",
				"lề tương đối theo mảng"
			},
			{
				"Relative Margin Step/Edge",
				"lề tương đối bậc/biên"
			},
			{
				"Absolute Margin Appearance",
				"lề tuyệt đối bề mặt"
			},
			{
				"Ratio Margin Appearance",
				"lề tỉ lệ bề mặt"
			},
			{
				"Grid Row 0",
				"hàng lưới 0"
			},
			{
				"Grid Column 0",
				"cột lưới 0"
			},
			{
				"Predicted Products",
				"số sản phẩm dự đoán"
			},
			{
				"Total Trained Products",
				"tổng sản phẩm đã huấn luyện"
			},
			{
				"Products In Current Train Image",
				"số sản phẩm trong ảnh huấn luyện"
			},
			{
				"Object 1",
				"đối tượng 1"
			},
			{
				"Object 2",
				"đối tượng 2"
			},
			{
				"Object 1 Feature",
				"đặc trưng đối tượng 1"
			},
			{
				"Object 2 Feature",
				"đặc trưng đối tượng 2"
			},
			{
				"Line Tool 1",
				"tool đường 1"
			},
			{
				"Line Tool 2",
				"tool đường 2"
			},
			{
				"Manual TCP Robot X",
				"TCP robot X nhập tay"
			},
			{
				"Manual TCP Robot Y",
				"TCP robot Y nhập tay"
			},
			{
				"Manual TCP Robot Rz",
				"TCP robot Rz nhập tay"
			}
		};

		// Token: 0x04000E12 RID: 3602
		private static readonly Dictionary<string, string> VietnamesePrefixes = new Dictionary<string, string>(StringComparer.Ordinal)
		{
			{
				"Show",
				"Hiện"
			},
			{
				"Check",
				"Kiểm tra"
			},
			{
				"Use",
				"Dùng"
			},
			{
				"Enable",
				"Bật"
			},
			{
				"Apply",
				"Áp dụng"
			},
			{
				"Exclude",
				"Loại trừ"
			},
			{
				"Expand",
				"Mở rộng"
			},
			{
				"Save",
				"Lưu"
			},
			{
				"Select",
				"Chọn"
			},
			{
				"Open",
				"Mở"
			},
			{
				"Add",
				"Thêm"
			}
		};

		// Token: 0x04000E13 RID: 3603
		private static readonly Dictionary<string, string> KoreanPhrases = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
		{
			{
				"Copy Image Path",
				"이미지 경로 복사"
			},
			{
				"Enter the licence you were given.",
				"발급받은 라이선스를 입력하십시오."
			},
			{
				"This licence is not in the expected form. It should look like 20251231-P-3F9A17C4B20E5D68.",
				"라이선스 형식이 올바르지 않습니다. 20251231-P-3F9A17C4B20E5D68 형태여야 합니다."
			},
			{
				"The date inside this licence is not readable.",
				"이 라이선스의 날짜를 읽을 수 없습니다."
			},
			{
				"The edition inside this licence is not readable.",
				"이 라이선스의 패키지를 읽을 수 없습니다."
			},
			{
				"This licence names an edition this version does not know.",
				"이 버전이 알지 못하는 패키지가 라이선스에 적혀 있습니다."
			},
			{
				"This licence does not belong to this machine. Check that the machine code sent to your supplier is the one shown above.",
				"이 라이선스는 이 장비의 것이 아닙니다. 공급업체에 보낸 장비 코드가 위에 표시된 코드와 같은지 확인하십시오."
			},
			{
				"The machine code could not be read from this computer, so a licence cannot be checked. Contact your supplier.",
				"이 컴퓨터에서 장비 코드를 읽을 수 없어 라이선스를 확인할 수 없습니다. 공급업체에 문의하십시오."
			},
			{
				"The licence is valid and does not expire.",
				"라이선스가 유효하며 만료되지 않습니다."
			},
			{
				"Issue License",
				"라이선스 발급"
			},
			{
				"New license",
				"새로 만들기"
			},
			{
				"Enter the details to create a license for a device.",
				"장비에 발급할 라이선스 정보를 입력하십시오."
			},
			{
				"1. MACHINE INFORMATION",
				"1. 장비 정보"
			},
			{
				"Machine ID",
				"장비 코드 (Machine ID)"
			},
			{
				"Paste",
				"붙여넣기"
			},
			{
				"This code is taken from the device the license is for.",
				"이 코드는 라이선스를 발급할 장비에서 확인합니다."
			},
			{
				"2. VALIDITY",
				"2. 사용 기간"
			},
			{
				"Validity type",
				"기간 유형"
			},
			{
				"Fixed period",
				"기간 제한"
			},
			{
				"Perpetual",
				"영구"
			},
			{
				"Expiry date",
				"만료일"
			},
			{
				"The license stays valid to the end of the day chosen.",
				"선택한 날짜의 종료 시각까지 유효합니다."
			},
			{
				"3. PACKAGE (OPTIONAL)",
				"3. 패키지 정보 (선택)"
			},
			{
				"Package",
				"사용 패키지"
			},
			{
				"Choose the feature package this license grants.",
				"사용을 허용할 기능 패키지를 선택하십시오."
			},
			{
				"GENERATED LICENSE",
				"생성된 라이선스"
			},
			{
				"License key",
				"라이선스 코드"
			},
			{
				"License details",
				"라이선스 정보"
			},
			{
				"Copied",
				"복사됨"
			},
			{
				"Export license",
				"라이선스 내보내기"
			},
			{
				"Administrator Login",
				"관리자 로그인"
			},
			{
				"Sign in to reach the protected settings.",
				"보호된 설정에 접근하려면 로그인하십시오."
			},
			{
				"User name",
				"사용자 이름"
			},
			{
				"Password",
				"비밀번호"
			},
			{
				"Sign in",
				"로그인"
			},
			{
				"Run All",
				"전체 실행"
			},
			{
				"Save All Config",
				"전체 설정 저장"
			},
			{
				"Save Image",
				"이미지 저장"
			},
			{
				"Save Image As",
				"다른 이름으로 저장"
			},
			{
				"Open Image",
				"이미지 열기"
			},
			{
				"Select Image Folder",
				"이미지 폴더 선택"
			},
			{
				"List image",
				"이미지 목록"
			},
			{
				"Snap",
				"촬영"
			},
			{
				"Next",
				"다음"
			},
			{
				"Previous",
				"이전"
			},
			{
				"Add TurnSnap",
				"TurnSnap 추가"
			},
			{
				"ADD ROI",
				"ROI 추가"
			},
			{
				"UPDATE ROI",
				"ROI 갱신"
			},
			{
				"Edit",
				"편집"
			},
			{
				"Delete",
				"삭제"
			},
			{
				"Del",
				"삭제"
			},
			{
				"Clear",
				"지우기"
			},
			{
				"Custom",
				"직접 그리기"
			},
			{
				"Trial Run Tool",
				"툴 시험 실행"
			},
			{
				"Inspect (Trial Run)",
				"검사 (시험 실행)"
			},
			{
				"Train",
				"학습"
			},
			{
				"Train Model",
				"모델 학습"
			},
			{
				"Predict Train",
				"예측 (학습)"
			},
			{
				"Pretrain",
				"사전 학습"
			},
			{
				"Load Model",
				"모델 불러오기"
			},
			{
				"Add Sample",
				"샘플 추가"
			},
			{
				"Clear Samples",
				"샘플 지우기"
			},
			{
				"Browse",
				"찾아보기"
			},
			{
				"Save",
				"저장"
			},
			{
				"Save Setting",
				"설정 저장"
			},
			{
				"Move",
				"이동"
			},
			{
				"Copy image",
				"이미지 복사"
			},
			{
				"Paste image",
				"이미지 붙여넣기"
			},
			{
				"Copy turnsnap",
				"TurnSnap 복사"
			},
			{
				"Paste turnsnap",
				"TurnSnap 붙여넣기"
			},
			{
				"Loading camera data...",
				"카메라 데이터 불러오는 중..."
			},
			{
				"Search model...",
				"모델 검색..."
			},
			{
				"MODEL LIST",
				"모델 목록"
			},
			{
				"Toolbox",
				"툴 박스"
			},
			{
				"Tools",
				"툴 목록"
			},
			{
				"Tool Parameter",
				"툴 파라미터"
			},
			{
				"Parameter",
				"파라미터"
			},
			{
				"Input Image",
				"입력 이미지"
			},
			{
				"Output Result",
				"출력 결과"
			},
			{
				"Display",
				"화면"
			},
			{
				"Display setting",
				"화면 설정"
			},
			{
				"Manage Tool",
				"툴 관리"
			},
			{
				"Customization...",
				"사용자 지정..."
			},
			{
				"Inspection / Measuring Tools",
				"검사 / 측정 툴"
			},
			{
				"Selection",
				"선택"
			},
			{
				"Matching",
				"매칭"
			},
			{
				"Analysis",
				"분석"
			},
			{
				"Transform",
				"변환"
			},
			{
				"Filter Parameters",
				"필터 파라미터"
			},
			{
				"Transform Parameters",
				"변환 파라미터"
			},
			{
				"Select Filter",
				"필터 선택"
			},
			{
				"Source Tool",
				"소스 툴"
			},
			{
				"Align Tool",
				"정렬 툴"
			},
			{
				"Zoom to Fit",
				"화면에 맞추기"
			},
			{
				"Hide ROI",
				"ROI 숨기기"
			},
			{
				"Show All",
				"모두 표시"
			},
			{
				"Hide All",
				"모두 숨기기"
			},
			{
				"Show All ROI",
				"모든 ROI 표시"
			},
			{
				"Show All Limit ROI",
				"모든 Limit ROI 표시"
			},
			{
				"Show All Mask ROI",
				"모든 Mask ROI 표시"
			},
			{
				"Clear All ROI",
				"모든 ROI 삭제"
			},
			{
				"Clear All Limit ROI",
				"모든 Limit ROI 삭제"
			},
			{
				"Clear All Mask ROI",
				"모든 Mask ROI 삭제"
			},
			{
				"Copy Message",
				"메시지 복사"
			},
			{
				"Copy Row",
				"행 복사"
			},
			{
				"Clear Log",
				"로그 지우기"
			},
			{
				"Log",
				"로그"
			},
			{
				"Time",
				"시간"
			},
			{
				"Level",
				"레벨"
			},
			{
				"Message",
				"메시지"
			},
			{
				"No log yet.",
				"로그가 없습니다."
			},
			{
				"Rectangle",
				"사각형"
			},
			{
				"Rectangle2",
				"회전 사각형"
			},
			{
				"Circle",
				"원"
			},
			{
				"Ellipse",
				"타원"
			},
			{
				"Line",
				"직선"
			},
			{
				"Polygon",
				"다각형"
			},
			{
				"FreeDraw",
				"자유 그리기"
			},
			{
				"ROI Property",
				"ROI 속성"
			},
			{
				"Properties",
				"속성"
			},
			{
				"Clone",
				"복제"
			},
			{
				"Name",
				"이름"
			},
			{
				"Mask Mode",
				"마스크 모드"
			},
			{
				"Polarity",
				"극성"
			},
			{
				"Enabled",
				"사용"
			},
			{
				"Is Enabled",
				"툴 사용"
			},
			{
				"IsEnabled",
				"툴 사용"
			},
			{
				"Rows",
				"행 수"
			},
			{
				"Columns",
				"열 수"
			},
			{
				"Offset Row (px)",
				"행 간격 (px)"
			},
			{
				"Offset Column (px)",
				"열 간격 (px)"
			},
			{
				"Direction",
				"방향"
			},
			{
				"Angle (deg)",
				"각도 (deg)"
			},
			{
				"Test Show",
				"미리 보기"
			},
			{
				"OK",
				"확인"
			},
			{
				"Cancel",
				"취소"
			},
			{
				"Master Position",
				"마스터 위치"
			},
			{
				"Master Angle",
				"마스터 각도"
			},
			{
				"Master Tool",
				"마스터 툴"
			},
			{
				"Clone ({0})",
				"복제 ({0})"
			},
			{
				"Clone (nothing to add)",
				"복제 (추가할 항목 없음)"
			},
			{
				"Grid {0} x {1} = {2} ROIs, {3} added",
				"격자 {0} x {1} = ROI {2}개, {3}개 추가"
			},
			{
				"Draw the pattern on the image without creating anything",
				"아무것도 만들지 않고 배치만 이미지에 표시합니다"
			},
			{
				"Test Show draws the pattern on the image without adding anything. Clone then commits it.",
				"미리 보기는 아무것도 추가하지 않고 배치만 표시합니다. 복제를 눌러야 실제로 생성됩니다."
			},
			{
				"Spec Mode",
				"스펙 적용 방식"
			},
			{
				"Normal Size",
				"기준값"
			},
			{
				"Upper Deviation",
				"상한 공차"
			},
			{
				"Lower Deviation",
				"하한 공차"
			},
			{
				"Maximum Size",
				"최대값"
			},
			{
				"Minimum Size",
				"최소값"
			},
			{
				"Spec",
				"스펙"
			},
			{
				"Spec Min",
				"스펙 최소"
			},
			{
				"Spec Max",
				"스펙 최대"
			},
			{
				"Min",
				"최소"
			},
			{
				"Max",
				"최대"
			},
			{
				"Value",
				"값"
			},
			{
				"Result",
				"결과"
			},
			{
				"Status",
				"상태"
			},
			{
				"Detail",
				"상세"
			},
			{
				"Type",
				"종류"
			},
			{
				"Use",
				"사용"
			},
			{
				"Order",
				"순서"
			},
			{
				"Mode",
				"모드"
			},
			{
				"Row",
				"행"
			},
			{
				"Column",
				"열"
			},
			{
				"Score",
				"매칭 점수"
			},
			{
				"Match",
				"매칭"
			},
			{
				"Camera",
				"카메라"
			},
			{
				"Communication",
				"통신"
			},
			{
				"Hardware Trigger",
				"하드웨어 트리거"
			},
			{
				"Exposure Time",
				"노출 시간"
			},
			{
				"Gain",
				"게인"
			},
			{
				"Pixel Format",
				"픽셀 포맷"
			},
			{
				"Image Format",
				"이미지 포맷"
			},
			{
				"Image Size",
				"이미지 크기"
			},
			{
				"Image Mode",
				"이미지 모드"
			},
			{
				"Light Source Preset",
				"조명 프리셋"
			},
			{
				"Vendor",
				"제조사"
			},
			{
				"Preset",
				"프리셋"
			},
			{
				"Interpolation",
				"보간"
			},
			{
				"Operation",
				"연산"
			},
			{
				"Filter Type",
				"필터 종류"
			},
			{
				"Threshold Polarity",
				"임계값 극성"
			},
			{
				"Work Scale",
				"처리 배율"
			},
			{
				"Trained",
				"학습 완료"
			},
			{
				"Trained Images",
				"학습 이미지 수"
			},
			{
				"Model Loaded",
				"모델 로드됨"
			},
			{
				"+  Add New",
				"+  새로 추가"
			},
			{
				"0 tags",
				"태그 0개"
			},
			{
				"03 reads holding registers. 04 reads input registers.",
				"03은 홀딩 레지스터, 04는 입력 레지스터를 읽습니다."
			},
			{
				"1 Pixel (mm)",
				"1 픽셀 (mm)"
			},
			{
				"1. Calibration Setting",
				"1. 캘리브레이션 설정"
			},
			{
				"2. Vision Preview",
				"2. 비전 미리 보기"
			},
			{
				"3. Calibration Log",
				"3. 캘리브레이션 로그"
			},
			{
				"4. Vision Detected Coordinates (Image)",
				"4. 비전 검출 좌표 (이미지)"
			},
			{
				"5. Robot Real Coordinates (Base)",
				"5. 로봇 실좌표 (베이스)"
			},
			{
				"6. Calibration Control",
				"6. 캘리브레이션 제어"
			},
			{
				"7. Calibration Result",
				"7. 캘리브레이션 결과"
			},
			{
				"A Offset",
				"A 오프셋"
			},
			{
				"Action",
				"동작"
			},
			{
				"Actual Distance (mm)",
				"실제 거리 (mm)"
			},
			{
				"Actual Value (mm)",
				"실제 값 (mm)"
			},
			{
				"Add",
				"추가"
			},
			{
				"Add a row at the end of the table",
				"표 맨 끝에 행을 추가합니다"
			},
			{
				"Additional Information",
				"추가 정보"
			},
			{
				"Address",
				"주소"
			},
			{
				"All Logs",
				"전체 로그"
			},
			{
				"Angle Delta Mode",
				"각도 편차 모드"
			},
			{
				"Apply",
				"적용"
			},
			{
				"Apply And Save",
				"적용 후 저장"
			},
			{
				"Apply Setting",
				"설정 적용"
			},
			{
				"Apply TCP Offset",
				"TCP 오프셋 적용"
			},
			{
				"Apply TCP To Mapping",
				"매핑에 TCP 적용"
			},
			{
				"Area scan",
				"에어리어 스캔"
			},
			{
				"Auto Read",
				"자동 읽기"
			},
			{
				"Auto Search Type",
				"자동 검색 종류"
			},
			{
				"Auto search code type",
				"코드 종류 자동 검색"
			},
			{
				"BL Column",
				"좌하 열"
			},
			{
				"BL Row",
				"좌하 행"
			},
			{
				"BR Column",
				"우하 열"
			},
			{
				"BR Row",
				"우하 행"
			},
			{
				"Bottom camera",
				"하단 카메라"
			},
			{
				"Bright B",
				"B 채널 밝기"
			},
			{
				"Bright G",
				"G 채널 밝기"
			},
			{
				"Bright R",
				"R 채널 밝기"
			},
			{
				"Browse OPC Tags",
				"OPC 태그 찾기"
			},
			{
				"Browse PLC Tags",
				"PLC 태그 찾기"
			},
			{
				"Brush",
				"브러시"
			},
			{
				"Brush Size",
				"브러시 크기"
			},
			{
				"CAMERA INFORMATION",
				"카메라 정보"
			},
			{
				"CAMERA LIST",
				"카메라 목록"
			},
			{
				"CREATE NEW MODEL",
				"새 모델 만들기"
			},
			{
				"Calib",
				"캘리브레이션"
			},
			{
				"Calib File",
				"캘리브레이션 파일"
			},
			{
				"Calib Hand-Eye Tools To Align",
				"정렬할 핸드아이 캘리브레이션 툴"
			},
			{
				"Calibration / Spec",
				"캘리브레이션 / 스펙"
			},
			{
				"Calibration File (.dat)",
				"캘리브레이션 파일 (.dat)"
			},
			{
				"Calibration File Path",
				"캘리브레이션 파일 경로"
			},
			{
				"Calibration Setup",
				"캘리브레이션 설정"
			},
			{
				"Camera Count",
				"카메라 수"
			},
			{
				"Camera Name *",
				"카메라 이름 *"
			},
			{
				"Camera Select",
				"카메라 선택"
			},
			{
				"Canvas Mode",
				"캔버스 모드"
			},
			{
				"Capture",
				"캡처"
			},
			{
				"Category",
				"분류"
			},
			{
				"Category:",
				"분류:"
			},
			{
				"Center Col",
				"중심 열"
			},
			{
				"Center Column",
				"중심 열"
			},
			{
				"Center Row",
				"중심 행"
			},
			{
				"Change Protocol to selected type...",
				"프로토콜을 선택한 종류로 변경..."
			},
			{
				"Check lost data",
				"데이터 손실 검사"
			},
			{
				"Choose a folder...",
				"폴더를 선택하세요..."
			},
			{
				"Class",
				"클래스"
			},
			{
				"Class Filter",
				"클래스 필터"
			},
			{
				"Clear All Logs",
				"모든 로그 지우기"
			},
			{
				"Clear Logs",
				"로그 지우기"
			},
			{
				"Clear all",
				"모두 지우기"
			},
			{
				"Clear selection",
				"선택 해제"
			},
			{
				"Close",
				"닫기"
			},
			{
				"Code",
				"코드"
			},
			{
				"Code Type",
				"코드 종류"
			},
			{
				"Command",
				"명령"
			},
			{
				"Conf",
				"신뢰도"
			},
			{
				"Config: --",
				"설정: --"
			},
			{
				"Confirm",
				"확인"
			},
			{
				"Connect",
				"연결"
			},
			{
				"Connection Detail",
				"연결 상세"
			},
			{
				"Connection Manager",
				"연결 관리"
			},
			{
				"Connection Name",
				"연결 이름"
			},
			{
				"Connection Setup",
				"연결 설정"
			},
			{
				"Coordinate Sort Mode",
				"좌표 정렬 모드"
			},
			{
				"Coordinate Text Color",
				"좌표 글자 색상"
			},
			{
				"Coordinate Text Size",
				"좌표 글자 크기"
			},
			{
				"Copy",
				"복사"
			},
			{
				"Copy All",
				"전체 복사"
			},
			{
				"Copy Details",
				"상세 복사"
			},
			{
				"Copy Log",
				"로그 복사"
			},
			{
				"Copy Selected Log",
				"선택한 로그 복사"
			},
			{
				"Copy Visible Logs",
				"보이는 로그 복사"
			},
			{
				"Count Per Row :",
				"행당 카메라 수 :"
			},
			{
				"Count Spec Enabled",
				"개수 스펙 사용"
			},
			{
				"Create Num Levels",
				"모델 생성 레벨 수"
			},
			{
				"Create model",
				"모델 생성"
			},
			{
				"Created By",
				"작성자"
			},
			{
				"Created Date",
				"작성일"
			},
			{
				"Crop Folder",
				"크롭 폴더"
			},
			{
				"Current Model: --",
				"현재 모델: --"
			},
			{
				"Data Exchange",
				"데이터 교환 주기"
			},
			{
				"Data Monitor",
				"데이터 모니터"
			},
			{
				"Data Type",
				"데이터 형식"
			},
			{
				"Data Type converts register data: INT16/UINT16 uses 1 register, INT32/UINT32/FLOAT uses 2 registers.",
				"데이터 형식이 레지스터 변환을 결정합니다: INT16/UINT16은 1워드, INT32/UINT32/FLOAT는 2워드를 사용합니다."
			},
			{
				"Decrease read cycle by 10 ms",
				"읽기 주기를 10 ms 줄입니다"
			},
			{
				"Defect Method",
				"불량 검출 방식"
			},
			{
				"Define model information, configure vision settings and processing parameters",
				"모델 정보를 정의하고 비전 설정과 처리 파라미터를 구성합니다"
			},
			{
				"Delete connection",
				"연결 삭제"
			},
			{
				"Delete model",
				"모델 삭제"
			},
			{
				"Delta A (deg)",
				"A 편차 (deg)"
			},
			{
				"Delta Angle (deg)",
				"각도 편차 (deg)"
			},
			{
				"Delta X",
				"X 편차"
			},
			{
				"Delta X (mm)",
				"X 편차 (mm)"
			},
			{
				"Delta Y",
				"Y 편차"
			},
			{
				"Delta Y (mm)",
				"Y 편차 (mm)"
			},
			{
				"Description",
				"설명"
			},
			{
				"Details",
				"상세"
			},
			{
				"Detect URL",
				"검출 서버 주소"
			},
			{
				"Diameter px",
				"지름 (px)"
			},
			{
				"Disconnect",
				"연결 해제"
			},
			{
				"Distance",
				"거리"
			},
			{
				"Distance mm",
				"거리 (mm)"
			},
			{
				"End Address",
				"종료 주소"
			},
			{
				"End Col",
				"종료 열"
			},
			{
				"End Row",
				"종료 행"
			},
			{
				"Enter camera name...",
				"카메라 이름 입력..."
			},
			{
				"Enter connection name",
				"연결 이름 입력"
			},
			{
				"Enter model name...",
				"모델 이름 입력..."
			},
			{
				"Eraser",
				"지우개"
			},
			{
				"Errors",
				"오류"
			},
			{
				"Exclude Interlocked Objects",
				"맞물린 객체 제외"
			},
			{
				"Expand Rotation Canvas",
				"회전 캔버스 확장"
			},
			{
				"Export",
				"내보내기"
			},
			{
				"Export Calib",
				"캘리브레이션 내보내기"
			},
			{
				"Export Config",
				"설정 내보내기"
			},
			{
				"Export Excel",
				"Excel 내보내기"
			},
			{
				"Export as CSV",
				"CSV로 내보내기"
			},
			{
				"Export as Text",
				"텍스트로 내보내기"
			},
			{
				"Export to File...",
				"파일로 내보내기..."
			},
			{
				"Factor",
				"계수"
			},
			{
				"File Name Prefix",
				"파일 이름 접두어"
			},
			{
				"Find Line Time",
				"직선 검출 시간"
			},
			{
				"Find Num Levels",
				"검색 레벨 수"
			},
			{
				"Fit",
				"화면 맞춤"
			},
			{
				"Fit image",
				"이미지 맞춤"
			},
			{
				"Flip Direction",
				"뒤집기 방향"
			},
			{
				"Folder Mode",
				"폴더 모드"
			},
			{
				"From",
				"시작"
			},
			{
				"Function Code",
				"기능 코드"
			},
			{
				"General Setting",
				"일반 설정"
			},
			{
				"Greediness",
				"탐색 강도"
			},
			{
				"Grid Col",
				"격자 열"
			},
			{
				"Grid Column",
				"격자 열"
			},
			{
				"Grid Row",
				"격자 행"
			},
			{
				"Group",
				"그룹"
			},
			{
				"Home",
				"홈"
			},
			{
				"INTELLIGENT VISION INSPECTION SYSTEM",
				"지능형 비전 검사 시스템"
			},
			{
				"IP Address",
				"IP 주소"
			},
			{
				"Image Source",
				"이미지 소스"
			},
			{
				"Import Config",
				"설정 가져오기"
			},
			{
				"Increase read cycle by 10 ms",
				"읽기 주기를 10 ms 늘립니다"
			},
			{
				"Info",
				"정보"
			},
			{
				"Initial Values",
				"초기값"
			},
			{
				"Input Source",
				"입력 소스"
			},
			{
				"Input Time",
				"입력 시간"
			},
			{
				"Input Time (ms)",
				"입력 시간 (ms)"
			},
			{
				"Insert",
				"삽입"
			},
			{
				"Insert a row above the selected one - rows are written to the PLC in this order",
				"선택한 행 위에 행을 삽입합니다 - 이 순서대로 PLC에 기록됩니다"
			},
			{
				"Keyword Search",
				"키워드 검색"
			},
			{
				"LOG DETAILS",
				"로그 상세"
			},
			{
				"LOG VISION",
				"비전 로그"
			},
			{
				"Last Distance (mm)",
				"최근 거리 (mm)"
			},
			{
				"Last Pixel Distance",
				"최근 픽셀 거리"
			},
			{
				"Last Pixel Value",
				"최근 픽셀 값"
			},
			{
				"Last Train Message",
				"최근 학습 메시지"
			},
			{
				"Last Value (mm)",
				"최근 값 (mm)"
			},
			{
				"Left button = selected tool, right button = erase. Wheel zooms, MIDDLE button pans, double-click fits the image.",
				"왼쪽 버튼 = 선택한 도구, 오른쪽 버튼 = 지우기. 휠은 확대/축소, 가운데 버튼은 이동, 더블 클릭은 화면 맞춤."
			},
			{
				"Left camera",
				"좌측 카메라"
			},
			{
				"Length 1",
				"길이 1"
			},
			{
				"Length 2",
				"길이 2"
			},
			{
				"Light Select",
				"조명 선택"
			},
			{
				"Limit roi",
				"Limit ROI"
			},
			{
				"Line 1 Time",
				"직선 1 시간"
			},
			{
				"Line 2 Time",
				"직선 2 시간"
			},
			{
				"Line Tool 1",
				"직선 툴 1"
			},
			{
				"Line Tool 2",
				"직선 툴 2"
			},
			{
				"Line scan",
				"라인 스캔"
			},
			{
				"Linked Result Inspection",
				"연결된 종합 판정 툴"
			},
			{
				"Linked Tool",
				"연결된 툴"
			},
			{
				"List model",
				"모델 목록"
			},
			{
				"Live View",
				"라이브 보기"
			},
			{
				"Load",
				"불러오기"
			},
			{
				"Load Image From File",
				"파일에서 이미지 불러오기"
			},
			{
				"Load Time (ms)",
				"로드 시간 (ms)"
			},
			{
				"Log Level",
				"로그 레벨"
			},
			{
				"Log Storage Path",
				"로그 저장 경로"
			},
			{
				"Log storage settings",
				"로그 저장 설정"
			},
			{
				"Logs per page:",
				"페이지당 로그 수:"
			},
			{
				"MODEL",
				"모델"
			},
			{
				"MODEL INFORMATION",
				"모델 정보"
			},
			{
				"Manual TCP Robot Rz (deg)",
				"수동 TCP 로봇 Rz (deg)"
			},
			{
				"Manual TCP Robot X (mm)",
				"수동 TCP 로봇 X (mm)"
			},
			{
				"Manual TCP Robot Y (mm)",
				"수동 TCP 로봇 Y (mm)"
			},
			{
				"Mapped A",
				"매핑된 A"
			},
			{
				"Mask roi",
				"Mask ROI"
			},
			{
				"Master Status",
				"마스터 상태"
			},
			{
				"Master TCP Col",
				"마스터 TCP 열"
			},
			{
				"Master TCP Row",
				"마스터 TCP 행"
			},
			{
				"Master Time",
				"마스터 시간"
			},
			{
				"Master Time (ms)",
				"마스터 시간 (ms)"
			},
			{
				"Master X (mm)",
				"마스터 X (mm)"
			},
			{
				"Master Y (mm)",
				"마스터 Y (mm)"
			},
			{
				"Master define",
				"마스터 정의"
			},
			{
				"Matrix Code",
				"매트릭스 코드"
			},
			{
				"Max Anisometry",
				"최대 이방성"
			},
			{
				"Max Cameras Per Row",
				"행당 최대 카메라 수"
			},
			{
				"Max Def",
				"최대 변형"
			},
			{
				"Max Instances",
				"최대 인스턴스 수"
			},
			{
				"Max Overlap",
				"최대 겹침"
			},
			{
				"Max Points",
				"최대 점 수"
			},
			{
				"Maximize / Restore",
				"최대화 / 복원"
			},
			{
				"Mean Def",
				"평균 변형"
			},
			{
				"Measure Threshold",
				"측정 임계값"
			},
			{
				"Measurement Mode",
				"측정 모드"
			},
			{
				"Metric",
				"단위"
			},
			{
				"Minimize",
				"최소화"
			},
			{
				"Mirror Column",
				"열 미러"
			},
			{
				"Mirror Row",
				"행 미러"
			},
			{
				"Model Key",
				"모델 키"
			},
			{
				"Model Name *",
				"모델 이름 *"
			},
			{
				"Move All Points",
				"모든 점 이동"
			},
			{
				"Move To Point",
				"점으로 이동"
			},
			{
				"Move turnsnap down",
				"TurnSnap 아래로 이동"
			},
			{
				"Move turnsnap up",
				"TurnSnap 위로 이동"
			},
			{
				"Naming Mode",
				"이름 규칙"
			},
			{
				"Needs a COLOUR image: red is separated as R - max(G, B), which a single-channel image cannot provide. Do not feed this tool the output of a Color To Gray filter.",
				"컬러 이미지가 필요합니다: 빨강은 R - max(G, B)로 분리되며 단일 채널 이미지로는 불가능합니다. Color To Gray 필터의 출력을 이 툴에 넣지 마세요."
			},
			{
				"Needs a COLOUR image: the part is separated from the tray by the ratio between the red and blue channels, which a gray image cannot provide. Do not feed this tool the output of a Color To Gray filter.",
				"컬러 이미지가 필요합니다: 부품은 적색과 청색 채널의 비율로 트레이와 분리되며 흑백 이미지로는 불가능합니다. Color To Gray 필터의 출력을 이 툴에 넣지 마세요."
			},
			{
				"Network Setting",
				"네트워크 설정"
			},
			{
				"New model name",
				"새 모델 이름"
			},
			{
				"Next page",
				"다음 페이지"
			},
			{
				"No folder selected",
				"선택된 폴더 없음"
			},
			{
				"No model",
				"모델 없음"
			},
			{
				"No model selected",
				"선택된 모델 없음"
			},
			{
				"NodeId / Address",
				"NodeId / 주소"
			},
			{
				"None (always save)",
				"없음 (항상 저장)"
			},
			{
				"Normalize Gain",
				"정규화 게인"
			},
			{
				"Normalize Offset",
				"정규화 오프셋"
			},
			{
				"Normalize Weights",
				"가중치 정규화"
			},
			{
				"Num Instances",
				"인스턴스 수"
			},
			{
				"Num Level",
				"레벨 수"
			},
			{
				"Num Levels (0 = auto)",
				"피라미드 레벨 수 (0 = 자동)"
			},
			{
				"Num Matched",
				"매칭된 수"
			},
			{
				"Num Matches (0 = all)",
				"매칭 수 (0 = 전체)"
			},
			{
				"OFF",
				"꺼짐"
			},
			{
				"OPC Heartbeat",
				"OPC 하트비트"
			},
			{
				"OPC Tag Monitor",
				"OPC 태그 모니터"
			},
			{
				"Object 1",
				"객체 1"
			},
			{
				"Object 1 Feature",
				"객체 1 특징"
			},
			{
				"Object 2",
				"객체 2"
			},
			{
				"Object 2 Feature",
				"객체 2 특징"
			},
			{
				"On",
				"켜짐"
			},
			{
				"Open Folder",
				"폴더 열기"
			},
			{
				"Open Log Vision Tab",
				"비전 로그 탭 열기"
			},
			{
				"Operation Guide",
				"조작 안내"
			},
			{
				"Out-Of-Range Offset Angle (deg)",
				"범위 초과 각도 오프셋 (deg)"
			},
			{
				"Out-Of-Range Offset X (mm)",
				"범위 초과 X 오프셋 (mm)"
			},
			{
				"Out-Of-Range Offset Y (mm)",
				"범위 초과 Y 오프셋 (mm)"
			},
			{
				"PLC: Disconnected | CAM: OK",
				"PLC: 연결 끊김 | CAM: OK"
			},
			{
				"Parameters",
				"파라미터"
			},
			{
				"Pause",
				"일시 정지"
			},
			{
				"Pick Column",
				"선택 열"
			},
			{
				"Pick Row",
				"선택 행"
			},
			{
				"Pick dates",
				"날짜 선택"
			},
			{
				"Picked",
				"선택됨"
			},
			{
				"Pixel Col",
				"픽셀 열"
			},
			{
				"Pixel Distance",
				"픽셀 거리"
			},
			{
				"Pixel Row",
				"픽셀 행"
			},
			{
				"Pixel Value",
				"픽셀 값"
			},
			{
				"Point",
				"점"
			},
			{
				"Point Status",
				"점 상태"
			},
			{
				"Port",
				"포트"
			},
			{
				"Position Points",
				"위치 점"
			},
			{
				"Predicted Products",
				"예측 제품 수"
			},
			{
				"Prediction Ready",
				"예측 준비됨"
			},
			{
				"Previous page",
				"이전 페이지"
			},
			{
				"Products In Current Train Image",
				"현재 학습 이미지의 제품 수"
			},
			{
				"Protocol",
				"프로토콜"
			},
			{
				"Protocol Information",
				"프로토콜 정보"
			},
			{
				"Quality",
				"품질"
			},
			{
				"Query to current time",
				"현재 시각까지 조회"
			},
			{
				"R/W",
				"읽기/쓰기"
			},
			{
				"RMS Error (mm)",
				"RMS 오차 (mm)"
			},
			{
				"ROI",
				"ROI"
			},
			{
				"ROI Name",
				"ROI 이름"
			},
			{
				"ROI Time",
				"ROI 시간"
			},
			{
				"ROI Time (ms)",
				"ROI 시간 (ms)"
			},
			{
				"ROI Value",
				"ROI 값"
			},
			{
				"Radius px",
				"반지름 (px)"
			},
			{
				"Read All",
				"전체 읽기"
			},
			{
				"Read Cycle (ms)",
				"읽기 주기 (ms)"
			},
			{
				"Read Range",
				"읽기 범위"
			},
			{
				"Read Tags",
				"태그 읽기"
			},
			{
				"Reads all OPC UA tags marked as Read in Tag Management. Address must be a NodeId such as ns=2;s=TagName or ns=2;i=1001.",
				"태그 관리에서 Read로 표시된 모든 OPC UA 태그를 읽습니다. 주소는 ns=2;s=TagName 또는 ns=2;i=1001 같은 NodeId여야 합니다."
			},
			{
				"Ready for test",
				"테스트 준비됨"
			},
			{
				"Refresh",
				"새로 고침"
			},
			{
				"Refresh Light Controllers",
				"조명 컨트롤러 새로 고침"
			},
			{
				"Refresh Serial Cameras",
				"시리얼 카메라 새로 고침"
			},
			{
				"Reload Initial Values from the current model communication_config.json",
				"현재 모델의 communication_config.json에서 초기값을 다시 불러옵니다"
			},
			{
				"Reload Model Data",
				"모델 데이터 다시 불러오기"
			},
			{
				"Rename Application Title",
				"프로그램 제목 변경"
			},
			{
				"Rename model",
				"모델 이름 변경"
			},
			{
				"Reprojection Error (px)",
				"재투영 오차 (px)"
			},
			{
				"Reset",
				"초기화"
			},
			{
				"Result Field",
				"결과 필드"
			},
			{
				"Right camera",
				"우측 카메라"
			},
			{
				"Right-click for options",
				"마우스 오른쪽 버튼으로 옵션 열기"
			},
			{
				"Robot Command / Info",
				"로봇 명령 / 정보"
			},
			{
				"Robot Control",
				"로봇 제어"
			},
			{
				"Robot X (mm)",
				"로봇 X (mm)"
			},
			{
				"Robot Y (mm)",
				"로봇 Y (mm)"
			},
			{
				"Rotation Fill Color",
				"회전 배경 색상"
			},
			{
				"Rotation Image",
				"회전 이미지"
			},
			{
				"Rotation Points",
				"회전 점"
			},
			{
				"Row: -  Col: -  Gray: -  R: -  G: -  B: -  Size: -",
				"행: -  열: -  그레이: -  R: -  G: -  B: -  크기: -"
			},
			{
				"Run",
				"실행"
			},
			{
				"Run Calib",
				"캘리브레이션 실행"
			},
			{
				"Rx (deg)",
				"Rx (deg)"
			},
			{
				"Ry (deg)",
				"Ry (deg)"
			},
			{
				"Rz (deg)",
				"Rz (deg)"
			},
			{
				"SYSTEM NOT READY",
				"시스템 준비 안 됨"
			},
			{
				"Save Calib",
				"캘리브레이션 저장"
			},
			{
				"Save Condition",
				"저장 조건"
			},
			{
				"Save Image...",
				"이미지 저장..."
			},
			{
				"Save Light Config",
				"조명 설정 저장"
			},
			{
				"Save Path",
				"저장 경로"
			},
			{
				"Save Region",
				"영역 저장"
			},
			{
				"Score Margin",
				"점수 여유"
			},
			{
				"Search connection...",
				"연결 검색..."
			},
			{
				"Search message...",
				"메시지 검색..."
			},
			{
				"Select a log row to view details.",
				"상세를 보려면 로그 행을 선택하세요."
			},
			{
				"Select folder",
				"폴더 선택"
			},
			{
				"Select the Calib Hand-Eye tools to combine:",
				"결합할 핸드아이 캘리브레이션 툴을 선택하세요:"
			},
			{
				"Select the connection used to read camera trigger snap/run tags.",
				"카메라 트리거 snap/run 태그를 읽을 연결을 선택하세요."
			},
			{
				"Select tools to combine (NG if any is NG):",
				"결합할 툴 선택 (하나라도 NG면 NG):"
			},
			{
				"Selected Point",
				"선택한 점"
			},
			{
				"Selector",
				"선택기"
			},
			{
				"Send",
				"전송"
			},
			{
				"Serial Camera",
				"시리얼 카메라"
			},
			{
				"Setting",
				"설정"
			},
			{
				"Show Coordinate Text",
				"좌표 글자 표시"
			},
			{
				"Show details",
				"상세 보기"
			},
			{
				"Showing 0 logs",
				"로그 0개 표시 중"
			},
			{
				"Sigma",
				"시그마"
			},
			{
				"Sort Output Order",
				"결과 정렬 순서"
			},
			{
				"Sort by time",
				"시간순 정렬"
			},
			{
				"Source",
				"소스"
			},
			{
				"Source Calib",
				"캘리브레이션 소스"
			},
			{
				"Source/Module",
				"소스 / 모듈"
			},
			{
				"Spec Max mm",
				"스펙 최대 (mm)"
			},
			{
				"Spec Min mm",
				"스펙 최소 (mm)"
			},
			{
				"Spec Status",
				"스펙 상태"
			},
			{
				"Stack Trace",
				"스택 트레이스"
			},
			{
				"Start Address",
				"시작 주소"
			},
			{
				"Start Calibration",
				"캘리브레이션 시작"
			},
			{
				"Start Camera",
				"카메라 시작"
			},
			{
				"Start Col",
				"시작 열"
			},
			{
				"Start Row",
				"시작 행"
			},
			{
				"Stop",
				"정지"
			},
			{
				"Stop Camera",
				"카메라 정지"
			},
			{
				"Success",
				"성공"
			},
			{
				"TCP Col",
				"TCP 열"
			},
			{
				"TCP Row",
				"TCP 행"
			},
			{
				"TL Column",
				"좌상 열"
			},
			{
				"TL Row",
				"좌상 행"
			},
			{
				"TR Column",
				"우상 열"
			},
			{
				"TR Row",
				"우상 행"
			},
			{
				"Tag Label",
				"태그 라벨"
			},
			{
				"Tag Management",
				"태그 관리"
			},
			{
				"Tag Name",
				"태그 이름"
			},
			{
				"Tags",
				"태그"
			},
			{
				"Tags:",
				"태그:"
			},
			{
				"Teach Current Pose",
				"현재 자세 티칭"
			},
			{
				"Test",
				"테스트"
			},
			{
				"The model data folder and its recipe file are renamed too.",
				"모델 데이터 폴더와 레시피 파일도 함께 이름이 변경됩니다."
			},
			{
				"Tick the tools that should appear in the toolbox. Unticked tools are hidden from the tree; tools already placed in a TurnSnap keep working either way.",
				"툴 박스에 표시할 툴을 선택하세요. 선택하지 않은 툴은 트리에서 숨겨지며, 이미 TurnSnap에 배치된 툴은 그대로 동작합니다."
			},
			{
				"Time Range",
				"기간"
			},
			{
				"Timeout (ms)",
				"타임아웃 (ms)"
			},
			{
				"Timestamp",
				"시각"
			},
			{
				"To",
				"끝"
			},
			{
				"Tool",
				"툴"
			},
			{
				"Tool Name",
				"툴 이름"
			},
			{
				"Tool Time",
				"툴 시간"
			},
			{
				"Top camera",
				"상단 카메라"
			},
			{
				"Total Time",
				"전체 시간"
			},
			{
				"Total Time (ms)",
				"전체 시간 (ms)"
			},
			{
				"Total Trained Products",
				"학습된 전체 제품 수"
			},
			{
				"Total Value",
				"전체 값"
			},
			{
				"Train on a master image that contains ONE product. Beside the shape model this also learns the product silhouette, the printed text and the master image, which the layer test needs.",
				"제품이 하나만 있는 마스터 이미지로 학습하세요. 셰이프 모델 외에 제품 외형, 인쇄 문자, 마스터 이미지도 함께 학습하며 레이어 검사에 필요합니다."
			},
			{
				"Transition",
				"전환"
			},
			{
				"Turn on Show Threshold, then drag the sliders - the picture re-runs as you drag. Draw one or more ROIs (a painted one works too) so only objects inside them are counted.",
				"임계값 표시를 켜고 슬라이더를 움직이면 이미지가 즉시 다시 계산됩니다. ROI를 하나 이상 그리면(직접 칠한 ROI도 가능) 그 안의 객체만 계수합니다."
			},
			{
				"TurnSnap Time",
				"TurnSnap 시간"
			},
			{
				"Use Manual Robot TCP",
				"수동 로봇 TCP 사용"
			},
			{
				"Use Out-Of-Range Offset",
				"범위 초과 오프셋 사용"
			},
			{
				"Use Specular Rescue",
				"반사 영역 보정 사용"
			},
			{
				"Use TCP",
				"TCP 사용"
			},
			{
				"Use same setting for all channels",
				"모든 채널에 같은 설정 사용"
			},
			{
				"VISION PRESS MACHINE",
				"비전 프레스 설비"
			},
			{
				"Value mm",
				"값 (mm)"
			},
			{
				"Value px",
				"값 (px)"
			},
			{
				"Variation Model Built",
				"변동 모델 생성됨"
			},
			{
				"Version",
				"버전"
			},
			{
				"Version:",
				"버전:"
			},
			{
				"View Detail",
				"상세 보기"
			},
			{
				"View and analyze system logs",
				"시스템 로그 조회 및 분석"
			},
			{
				"Vision Trigger Camera Connection",
				"비전 트리거 카메라 연결"
			},
			{
				"Waiting for trigger...",
				"트리거 대기 중..."
			},
			{
				"Warnings",
				"경고"
			},
			{
				"Weight Appearance",
				"외관 가중치"
			},
			{
				"Weight B (channel 3)",
				"B 가중치 (채널 3)"
			},
			{
				"Weight Edge",
				"에지 가중치"
			},
			{
				"Weight G (channel 2)",
				"G 가중치 (채널 2)"
			},
			{
				"Weight Path (.pt)",
				"가중치 파일 경로 (.pt)"
			},
			{
				"Weight Print",
				"인쇄 가중치"
			},
			{
				"Weight R (channel 1)",
				"R 가중치 (채널 1)"
			},
			{
				"Weight Score",
				"점수 가중치"
			},
			{
				"Weight Step",
				"단차 가중치"
			},
			{
				"When on, Trial Run tries all types and fills the detected one above.",
				"켜면 시험 실행이 모든 종류를 시도한 뒤 검출된 종류를 위 칸에 채웁니다."
			},
			{
				"Work Station (Logical Station No.)",
				"워크 스테이션 (논리 국번)"
			},
			{
				"Write To PLC Now",
				"지금 PLC에 쓰기"
			},
			{
				"Write value",
				"쓸 값"
			},
			{
				"X (mm)",
				"X (mm)"
			},
			{
				"X (px)",
				"X (px)"
			},
			{
				"Y (mm)",
				"Y (mm)"
			},
			{
				"Y (px)",
				"Y (px)"
			},
			{
				"Z (mm)",
				"Z (mm)"
			},
			{
				"Zoom +",
				"확대"
			},
			{
				"Zoom -",
				"축소"
			},
			{
				"Zoom: 100%",
				"확대율: 100%"
			},
			{
				"mm/pixel",
				"mm/픽셀"
			},
			{
				"Browse .pt File...",
				".pt 파일 찾기..."
			},
			{
				"Procedure",
				"프로시저"
			},
			{
				"Master",
				"마스터"
			},
			{
				"Note",
				"비고"
			},
			{
				"Procedure File",
				"프로시저 파일"
			},
			{
				"Train Procedure",
				"학습 프로시저"
			},
			{
				"Train Procedure (optional)",
				"학습 프로시저 (선택)"
			},
			{
				"Find Procedure",
				"찾기 프로시저"
			},
			{
				"Input parameters",
				"입력 파라미터"
			},
			{
				"Train (from ROI)",
				"학습 (ROI 기준)"
			},
			{
				"Define Master",
				"마스터 정의"
			},
			{
				"Find (Trial Run)",
				"찾기 (시험 실행)"
			},
			{
				"Reload",
				"다시 불러오기"
			},
			{
				"Image Input Name",
				"이미지 입력 이름"
			},
			{
				"Train Region Input Name",
				"학습 영역 입력 이름"
			},
			{
				"Search Region Input Name",
				"검색 영역 입력 이름"
			},
			{
				"Model Path Input Name",
				"모델 경로 입력 이름"
			},
			{
				"Train Preview Output",
				"학습 미리보기 출력"
			},
			{
				"Row Output Name",
				"행 출력 이름"
			},
			{
				"Column Output Name",
				"열 출력 이름"
			},
			{
				"Angle Output Name",
				"각도 출력 이름"
			},
			{
				"Score Output Name",
				"점수 출력 이름"
			},
			{
				"Angle Is In Degrees",
				"각도 단위는 도"
			},
			{
				"Reduce Search To Limit ROI",
				"검색을 limit ROI로 제한"
			},
			{
				"Drop Matches Outside Limit ROI",
				"limit ROI 밖 결과 제거"
			},
			{
				"Sort Mode",
				"정렬 방식"
			},
			{
				"Pick Mode",
				"선택 방식"
			},
			{
				"Show Objects",
				"객체 표시"
			},
			{
				"Show Cross",
				"십자 표시"
			},
			{
				"Cross Size",
				"십자 크기"
			},
			{
				"Limit ROI Color",
				"limit ROI 색상"
			},
			{
				"Train Result",
				"학습 결과"
			},
			{
				"Draw the ROI on this tool and press Train: the ROI is what gets learned. Draw a Limit ROI to keep the returned coordinates inside one area of the image.",
				"이 툴에서 ROI를 그리고 Train을 누르십시오. ROI가 학습되는 부분입니다. 반환되는 좌표를 이미지의 한 영역 안으로 제한하려면 Limit ROI를 그리십시오."
			},
			{
				"Pick Row / Pick Column choose which found object this master publishes to Calib Hand-Eye and Result Align; the rest are still numbered and drawn.",
				"Pick Row / Pick Column은 이 마스터가 Calib Hand-Eye와 Result Align으로 보낼 객체를 선택합니다. 나머지도 번호가 매겨지고 그려집니다."
			},
			{
				"Procedure Name",
				"프로시저 이름"
			},
			{
				"ROI Mode",
				"ROI 방식"
			},
			{
				"ROI Delivery",
				"ROI 전달 방식"
			},
			{
				"ROI Input Name",
				"ROI 입력 이름"
			},
			{
				"Result Value Output",
				"결과 값 출력"
			},
			{
				"Status Output",
				"상태 출력"
			},
			{
				"Aggregate (Per ROI)",
				"집계 (ROI별)"
			},
			{
				"Output Image Name",
				"출력 이미지 이름"
			},
			{
				"Objects To Draw",
				"그릴 객체"
			},
			{
				"Draw Filled",
				"채워서 그리기"
			},
			{
				"Object Color",
				"객체 색상"
			},
			{
				"Line Width",
				"선 두께"
			},
			{
				"ROI Color",
				"ROI 색상"
			},
			{
				"Value Text Color",
				"값 글자 색상"
			},
			{
				"Value Text Size",
				"값 글자 크기"
			},
			{
				"Value Offset X",
				"값 X 오프셋"
			},
			{
				"Value Offset Y",
				"값 Y 오프셋"
			},
			{
				"Check Value",
				"값 검사"
			},
			{
				"Value Min",
				"최소 값"
			},
			{
				"Value Max",
				"최대 값"
			},
			{
				"Check Status Output",
				"상태 출력 검사"
			},
			{
				"Status OK Value",
				"상태 OK 값"
			},
			{
				"The image chosen here is what the procedure receives. Draw ROIs on this tool as on any other - how they reach the procedure is set in the Procedure tab.",
				"여기서 선택한 이미지가 프로시저로 전달됩니다. 다른 툴처럼 이 툴에서 ROI를 그리십시오. ROI가 프로시저로 전달되는 방식은 Procedure 탭에서 설정합니다."
			},
			{
				"ROI Delivery Reduce Domain works with any procedure, even one written without a region parameter. Result Value Output picks which returned number is THE value of this tool - the one the spec judges and Result Inspection reads; leave it empty to take the first numeric output.",
				"ROI Delivery의 Reduce Domain은 region 파라미터가 없는 프로시저에서도 동작합니다. Result Value Output은 반환된 숫자 중 어느 것이 이 툴의 값인지 – spec이 판정하고 Result Inspection이 읽는 값을 – 선택합니다. 비워두면 첫 번째 숫자 출력을 사용합니다."
			},
			{
				"Light on",
				"조명 켜기"
			}
		};

		// Token: 0x04000E14 RID: 3604
		private static readonly Dictionary<string, string> KoreanTerms = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
		{
			{
				"Area",
				"면적"
			},
			{
				"Blob Area",
				"블롭 면적"
			},
			{
				"Box Area",
				"박스 면적"
			},
			{
				"Total Area",
				"전체 면적"
			},
			{
				"Defect Area",
				"불량 면적"
			},
			{
				"Inspect Area",
				"검사 면적"
			},
			{
				"Product Area",
				"제품 면적"
			},
			{
				"Contact Area",
				"접촉 면적"
			},
			{
				"Overlap Area",
				"겹침 면적"
			},
			{
				"Patch Area",
				"패치 면적"
			},
			{
				"Threshold",
				"임계값"
			},
			{
				"Color Threshold",
				"색상 임계값"
			},
			{
				"Score Threshold",
				"점수 임계값"
			},
			{
				"Diff Threshold",
				"차이 임계값"
			},
			{
				"Defect Threshold",
				"불량 임계값"
			},
			{
				"Product Threshold",
				"제품 임계값"
			},
			{
				"Redness Threshold",
				"적색도 임계값"
			},
			{
				"Threshold Region",
				"임계값 영역"
			},
			{
				"Threshold Color",
				"임계값 색상"
			},
			{
				"Threshold Fill",
				"임계값 채우기"
			},
			{
				"Color",
				"색상"
			},
			{
				"Text Color",
				"글자 색상"
			},
			{
				"Text Size",
				"글자 크기"
			},
			{
				"Index Text Color",
				"인덱스 글자 색상"
			},
			{
				"Index Text Size",
				"인덱스 글자 크기"
			},
			{
				"Summary Text Color",
				"요약 글자 색상"
			},
			{
				"Summary Text Size",
				"요약 글자 크기"
			},
			{
				"Box Color",
				"박스 색상"
			},
			{
				"Mask Color",
				"마스크 색상"
			},
			{
				"Defect Color",
				"불량 색상"
			},
			{
				"Contour Color",
				"윤곽 색상"
			},
			{
				"Model Contour Color",
				"모델 윤곽 색상"
			},
			{
				"Arrow Color",
				"화살표 색상"
			},
			{
				"Part Color",
				"부품 색상"
			},
			{
				"Radius",
				"반지름"
			},
			{
				"Close Radius",
				"클로징 반지름"
			},
			{
				"Open Radius",
				"오프닝 반지름"
			},
			{
				"Count",
				"개수"
			},
			{
				"Object Count",
				"객체 수"
			},
			{
				"Product Count",
				"제품 수"
			},
			{
				"Part Count",
				"부품 수"
			},
			{
				"Defect Count",
				"불량 수"
			},
			{
				"Arrow Count",
				"화살표 수"
			},
			{
				"Foreign Object",
				"이물"
			},
			{
				"Foreign Object Size",
				"이물 크기"
			},
			{
				"Foreign Object Count",
				"이물 수"
			},
			{
				"Sample Count",
				"샘플 수"
			},
			{
				"Empty Pockets",
				"빈 포켓 수"
			},
			{
				"Width",
				"너비"
			},
			{
				"Height",
				"높이"
			},
			{
				"Box Width",
				"박스 너비"
			},
			{
				"Box Height",
				"박스 높이"
			},
			{
				"Size",
				"크기"
			},
			{
				"Index",
				"인덱스"
			},
			{
				"ROI Index",
				"ROI 인덱스"
			},
			{
				"ROI",
				"ROI"
			},
			{
				"Limit ROI",
				"Limit ROI"
			},
			{
				"Mask",
				"마스크"
			},
			{
				"Text",
				"글자"
			},
			{
				"Value Text",
				"값 글자"
			},
			{
				"Input Image",
				"입력 이미지"
			},
			{
				"Redness Image",
				"적색도 이미지"
			},
			{
				"Box",
				"박스"
			},
			{
				"Boxes",
				"박스"
			},
			{
				"Center",
				"중심"
			},
			{
				"Contours",
				"윤곽"
			},
			{
				"Model Contour",
				"모델 윤곽"
			},
			{
				"Defects",
				"불량"
			},
			{
				"Parts",
				"부품"
			},
			{
				"Matches",
				"매칭 결과"
			},
			{
				"All Matches",
				"전체 매칭 결과"
			},
			{
				"Found Circle",
				"검출된 원"
			},
			{
				"Found Line",
				"검출된 직선"
			},
			{
				"Inspect Region",
				"검사 영역"
			},
			{
				"Object Order",
				"객체 순서"
			},
			{
				"Result",
				"결과"
			},
			{
				"Score",
				"매칭 점수"
			},
			{
				"Contrast",
				"대비"
			},
			{
				"Offset",
				"오프셋"
			},
			{
				"Offset X",
				"X 오프셋"
			},
			{
				"Offset Y",
				"Y 오프셋"
			},
			{
				"Index Offset X",
				"인덱스 X 오프셋"
			},
			{
				"Index Offset Y",
				"인덱스 Y 오프셋"
			},
			{
				"Angle",
				"각도"
			},
			{
				"Rotation Angle",
				"회전 각도"
			},
			{
				"Angle Range",
				"각도 범위"
			},
			{
				"Margin",
				"여백"
			},
			{
				"Box Margin",
				"박스 여백"
			},
			{
				"Spacing",
				"간격"
			},
			{
				"Row Spacing",
				"행 간격"
			},
			{
				"Column Spacing",
				"열 간격"
			},
			{
				"Group Gap X",
				"그룹 X 간격"
			},
			{
				"Group Gap Y",
				"그룹 Y 간격"
			},
			{
				"Grouping",
				"그룹화"
			},
			{
				"Grid Rows",
				"격자 행 수"
			},
			{
				"Grid Columns",
				"격자 열 수"
			},
			{
				"Calibration",
				"캘리브레이션"
			},
			{
				"Tray Grid",
				"트레이 격자"
			},
			{
				"Mode",
				"모드"
			},
			{
				"Measure Mode",
				"측정 모드"
			},
			{
				"Region Mode",
				"영역 모드"
			},
			{
				"Object Mode",
				"객체 모드"
			},
			{
				"Value Mode",
				"값 모드"
			},
			{
				"Save Folder",
				"저장 폴더"
			},
			{
				"Model File",
				"모델 파일"
			},
			{
				"Model Path",
				"모델 경로"
			},
			{
				"Abs Threshold",
				"절대 임계값"
			},
			{
				"Absolute Margin Appearance",
				"외관 절대 여백"
			},
			{
				"All Boxes",
				"전체 박스"
			},
			{
				"Angle Extent",
				"각도 범위 폭"
			},
			{
				"Angle Guide",
				"각도 가이드"
			},
			{
				"Angle Start",
				"시작 각도"
			},
			{
				"Arrow",
				"화살표"
			},
			{
				"Arrow Area",
				"화살표 면적"
			},
			{
				"Arrows",
				"화살표"
			},
			{
				"Background Window",
				"배경 윈도우"
			},
			{
				"Band Area",
				"띠 면적"
			},
			{
				"Blue",
				"청색"
			},
			{
				"Body Close Radius",
				"본체 클로징 반지름"
			},
			{
				"Border Margin",
				"테두리 여백"
			},
			{
				"Bottom Color",
				"하단 색상"
			},
			{
				"Cavity Close Radius",
				"공동 클로징 반지름"
			},
			{
				"Cavity Min Area",
				"최소 공동 면적"
			},
			{
				"Cavity Offset",
				"공동 오프셋"
			},
			{
				"Center Angle",
				"중심 각도"
			},
			{
				"Center Distance",
				"중심 거리"
			},
			{
				"Center Length",
				"중심 길이"
			},
			{
				"Chroma Min Area",
				"최소 채도 면적"
			},
			{
				"Chroma Min Diff",
				"최소 채도 차이"
			},
			{
				"Color Close Radius",
				"색상 클로징 반지름"
			},
			{
				"Color Mark",
				"색상 마크"
			},
			{
				"Color Open Radius",
				"색상 오프닝 반지름"
			},
			{
				"Column Pitch",
				"열 피치"
			},
			{
				"Contact Distance",
				"접촉 거리"
			},
			{
				"Contact Zone",
				"접촉 영역"
			},
			{
				"Contact Zone Color",
				"접촉 영역 색상"
			},
			{
				"Corner Shift",
				"모서리 이동"
			},
			{
				"Defect Box Margin",
				"불량 박스 여백"
			},
			{
				"Defect Min Area",
				"최소 불량 면적"
			},
			{
				"Deformation",
				"변형량"
			},
			{
				"Deformation Smoothness",
				"변형 평활도"
			},
			{
				"Diff Smooth",
				"차이 평활"
			},
			{
				"Display Color",
				"표시 색상"
			},
			{
				"Edge Band Width",
				"에지 띠 너비"
			},
			{
				"Empty Cell Color",
				"빈 셀 색상"
			},
			{
				"Empty Cells",
				"빈 셀"
			},
			{
				"End Phi",
				"종료 각도"
			},
			{
				"Evidence Band",
				"판정 근거 띠"
			},
			{
				"Golden Matches",
				"기준 매칭 수"
			},
			{
				"Gray",
				"그레이"
			},
			{
				"Green",
				"녹색"
			},
			{
				"Grid Column 0",
				"격자 기준 열"
			},
			{
				"Grid Row 0",
				"격자 기준 행"
			},
			{
				"Inliers",
				"유효 점 수"
			},
			{
				"Inner Margin",
				"내부 여백"
			},
			{
				"Inside Ratio",
				"내부 비율"
			},
			{
				"Inspect Region Color",
				"검사 영역 색상"
			},
			{
				"Intersection Point",
				"교점"
			},
			{
				"Layer Label",
				"레이어 라벨"
			},
			{
				"Mask Fill",
				"마스크 채우기"
			},
			{
				"Mask Height",
				"마스크 높이"
			},
			{
				"Mask Type",
				"마스크 종류"
			},
			{
				"Mask Width",
				"마스크 너비"
			},
			{
				"Match Color",
				"매칭 색상"
			},
			{
				"Match Tolerance",
				"매칭 공차"
			},
			{
				"Max Deformation",
				"최대 변형량"
			},
			{
				"Mean Deformation",
				"평균 변형량"
			},
			{
				"Mean Redness",
				"평균 적색도"
			},
			{
				"Measure Threshold",
				"측정 임계값"
			},
			{
				"Mesh Color",
				"메시 색상"
			},
			{
				"Mesh Line Width",
				"메시 선 두께"
			},
			{
				"Mesh Spacing",
				"메시 간격"
			},
			{
				"Multi Center Color",
				"다중 중심 색상"
			},
			{
				"Multi ROI",
				"다중 ROI"
			},
			{
				"Multi ROI Center",
				"다중 ROI 중심"
			},
			{
				"Multi ROI Color",
				"다중 ROI 색상"
			},
			{
				"Multi Text Color",
				"다중 글자 색상"
			},
			{
				"NCC Mask Size",
				"NCC 마스크 크기"
			},
			{
				"Normalize Window",
				"정규화 윈도우"
			},
			{
				"Offset Angle",
				"각도 오프셋"
			},
			{
				"Overlap Core",
				"겹침 핵심"
			},
			{
				"Overlap Erode",
				"겹침 침식"
			},
			{
				"Patch Band",
				"패치 띠"
			},
			{
				"Print Dilate",
				"인쇄 팽창"
			},
			{
				"Print Hit Tolerance",
				"인쇄 일치 공차"
			},
			{
				"Print Pixels",
				"인쇄 픽셀 수"
			},
			{
				"Print Ratio Below",
				"하단 인쇄 비율"
			},
			{
				"Print Ratio On Top",
				"상단 인쇄 비율"
			},
			{
				"Print Threshold",
				"인쇄 임계값"
			},
			{
				"Ratio Margin Appearance",
				"외관 비율 여백"
			},
			{
				"Red",
				"적색"
			},
			{
				"Red Min Area",
				"최소 적색 면적"
			},
			{
				"Red Min Diff",
				"최소 적색 차이"
			},
			{
				"Red Min Value",
				"최소 적색 값"
			},
			{
				"Region Shrink",
				"영역 축소"
			},
			{
				"Relative Margin Patch",
				"패치 상대 여백"
			},
			{
				"Relative Margin Step/Edge",
				"단차/에지 상대 여백"
			},
			{
				"Row Pitch",
				"행 피치"
			},
			{
				"Scale Column",
				"열 배율"
			},
			{
				"Scale Deviation",
				"배율 편차"
			},
			{
				"Scale Row",
				"행 배율"
			},
			{
				"Search Outline",
				"검색 영역 외곽"
			},
			{
				"Smooth Window",
				"평활 윈도우"
			},
			{
				"Source Lines",
				"소스 직선"
			},
			{
				"Start Phi",
				"시작 각도"
			},
			{
				"Step Exclude Other",
				"타 영역 제외 단차"
			},
			{
				"Step Inner",
				"내부 단차"
			},
			{
				"Step Outer",
				"외부 단차"
			},
			{
				"Top Color",
				"상단 색상"
			},
			{
				"Total Defect Area",
				"전체 불량 면적"
			},
			{
				"Var Abs Threshold",
				"분산 절대 임계값"
			},
			{
				"Var Threshold",
				"분산 임계값"
			},
			{
				"Warped Mesh",
				"변형 메시"
			}
		};

		// Token: 0x04000E15 RID: 3605
		private static readonly Dictionary<string, string> KoreanSuffixVerbs = new Dictionary<string, string>(StringComparer.Ordinal)
		{
			{
				"Show",
				"표시"
			},
			{
				"Check",
				"검사"
			},
			{
				"Use",
				"사용"
			},
			{
				"Enable",
				"사용"
			},
			{
				"Apply",
				"적용"
			},
			{
				"Exclude",
				"제외"
			},
			{
				"Expand",
				"확장"
			},
			{
				"Save",
				"저장"
			},
			{
				"Select",
				"선택"
			},
			{
				"Open",
				"열기"
			},
			{
				"Add",
				"추가"
			}
		};
	}
}
