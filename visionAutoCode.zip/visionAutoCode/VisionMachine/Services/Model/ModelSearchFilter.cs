﻿using System;
using System.Windows.Controls;
using VisionMachine.Models.Recipe;

namespace VisionMachine.Services.Model
{
	// Token: 0x02000257 RID: 599
	public static class ModelSearchFilter
	{
		// Token: 0x060021C0 RID: 8640 RVA: 0x000C60E8 File Offset: 0x000C42E8
		public static void Apply(ListBox list, string searchText)
		{
			bool flag = list == null || list.ItemsSource == null;
			if (!flag)
			{
				string search = (searchText ?? string.Empty).Trim();
				bool flag2 = search.Length == 0;
				if (flag2)
				{
					list.Items.Filter = null;
				}
				else
				{
					object selected = list.SelectedItem;
					list.Items.Filter = ((object item) => item == selected || ModelSearchFilter.Matches(item as ModelConfig, search));
				}
			}
		}

		// Token: 0x060021C1 RID: 8641 RVA: 0x000C616C File Offset: 0x000C436C
		private static bool Matches(ModelConfig model, string search)
		{
			bool flag = model == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string name = model.Model_name;
				result = (!string.IsNullOrEmpty(name) && name.IndexOf(search, StringComparison.CurrentCultureIgnoreCase) >= 0);
			}
			return result;
		}
	}
}
