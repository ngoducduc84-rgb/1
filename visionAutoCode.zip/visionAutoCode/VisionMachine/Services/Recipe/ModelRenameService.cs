﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using VisionMachine.Models.Recipe;

namespace VisionMachine.Services.Recipe
{
	// Token: 0x020001E3 RID: 483
	public static class ModelRenameService
	{
		// Token: 0x06001D06 RID: 7430 RVA: 0x000A3D88 File Offset: 0x000A1F88
		public static ModelRenameService.RenameResult Rename(ModelConfig model, string newName, IEnumerable<ModelConfig> allModels)
		{
			bool flag = model == null;
			ModelRenameService.RenameResult result;
			if (flag)
			{
				result = ModelRenameService.RenameResult.Fail("No model was selected.");
			}
			else
			{
				newName = (newName ?? string.Empty).Trim();
				bool flag2 = string.IsNullOrWhiteSpace(newName);
				if (flag2)
				{
					result = ModelRenameService.RenameResult.Fail("The model name cannot be empty.");
				}
				else
				{
					string oldName = (model.Model_name ?? string.Empty).Trim();
					bool flag3 = string.Equals(oldName, newName, StringComparison.Ordinal);
					if (flag3)
					{
						result = ModelRenameService.RenameResult.Ok("The model name was not changed.");
					}
					else
					{
						bool flag4 = newName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0;
						if (flag4)
						{
							result = ModelRenameService.RenameResult.Fail("The model name contains characters that are not allowed in a folder name.");
						}
						else
						{
							IEnumerable<ModelConfig> others = from x in allModels ?? Enumerable.Empty<ModelConfig>()
							where x != null && x != model
							select x;
							bool flag5 = others.Any((ModelConfig x) => string.Equals(x.Model_name, newName, StringComparison.OrdinalIgnoreCase));
							if (flag5)
							{
								result = ModelRenameService.RenameResult.Fail("A model named '" + newName + "' already exists.");
							}
							else
							{
								string oldFolder = RecipePathService.GetModelFolder(oldName);
								string newFolder = RecipePathService.GetModelFolder(newName);
								try
								{
									ModelRenameService.MoveModelFolder(oldName, newName);
								}
								catch (Exception ex)
								{
									return ModelRenameService.RenameResult.Fail("Failed to rename the model data folder: " + ex.Message + "\n\nClose anything using that folder and try again.");
								}
								string repointWarning = null;
								try
								{
									ModelRenameService.RepointAbsolutePaths(newFolder, oldFolder, newFolder);
								}
								catch (Exception ex2)
								{
									repointWarning = "\nWarning: the stored file paths could not be updated (" + ex2.Message + "). Check the calibration file path in the tools.";
								}
								model.Model_name = newName;
								result = ModelRenameService.RenameResult.Ok("Model renamed to '" + newName + "'." + (repointWarning ?? string.Empty));
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001D07 RID: 7431 RVA: 0x000A3F98 File Offset: 0x000A2198
		private static void MoveModelFolder(string oldName, string newName)
		{
			string sourceFolder = RecipePathService.GetModelFolder(oldName);
			string destFolder = RecipePathService.GetModelFolder(newName);
			bool flag = string.IsNullOrWhiteSpace(destFolder);
			if (flag)
			{
				throw new InvalidOperationException("The new model folder path is not valid.");
			}
			bool sameFolder = !string.IsNullOrWhiteSpace(sourceFolder) && string.Equals(Path.GetFullPath(sourceFolder).TrimEnd(new char[]
			{
				'\\'
			}), Path.GetFullPath(destFolder).TrimEnd(new char[]
			{
				'\\'
			}), StringComparison.OrdinalIgnoreCase);
			bool flag2 = !sameFolder;
			if (flag2)
			{
				bool flag3 = Directory.Exists(destFolder);
				if (flag3)
				{
					throw new InvalidOperationException("A data folder named '" + Path.GetFileName(destFolder) + "' already exists.");
				}
				bool flag4 = string.IsNullOrWhiteSpace(sourceFolder) || !Directory.Exists(sourceFolder);
				if (flag4)
				{
					return;
				}
				Directory.Move(sourceFolder, destFolder);
			}
			ModelRenameService.RenameRecipeJson(destFolder, oldName, newName);
		}

		// Token: 0x06001D08 RID: 7432 RVA: 0x000A4068 File Offset: 0x000A2268
		private static void RepointAbsolutePaths(string folder, string oldFolder, string newFolder)
		{
			bool flag = string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder) || string.IsNullOrWhiteSpace(oldFolder) || string.IsNullOrWhiteSpace(newFolder);
			if (!flag)
			{
				string oldPath = Path.GetFullPath(oldFolder).TrimEnd(new char[]
				{
					'\\'
				});
				string newPath = Path.GetFullPath(newFolder).TrimEnd(new char[]
				{
					'\\'
				});
				bool flag2 = string.Equals(oldPath, newPath, StringComparison.OrdinalIgnoreCase);
				if (!flag2)
				{
					string oldEscaped = oldPath.Replace("\\", "\\\\");
					string newEscaped = newPath.Replace("\\", "\\\\");
					foreach (string file in Directory.GetFiles(folder, "*.json", SearchOption.AllDirectories))
					{
						string content = File.ReadAllText(file);
						string updated = ModelRenameService.ReplaceIgnoreCase(content, oldEscaped, newEscaped);
						updated = ModelRenameService.ReplaceIgnoreCase(updated, oldPath, newPath);
						bool flag3 = !string.Equals(content, updated, StringComparison.Ordinal);
						if (flag3)
						{
							File.WriteAllText(file, updated);
						}
					}
				}
			}
		}

		// Token: 0x06001D09 RID: 7433 RVA: 0x000A4170 File Offset: 0x000A2370
		private static string ReplaceIgnoreCase(string source, string search, string replacement)
		{
			bool flag = string.IsNullOrEmpty(source) || string.IsNullOrEmpty(search);
			string result;
			if (flag)
			{
				result = source;
			}
			else
			{
				StringBuilder builder = new StringBuilder();
				int index = 0;
				for (;;)
				{
					int found = source.IndexOf(search, index, StringComparison.OrdinalIgnoreCase);
					bool flag2 = found < 0;
					if (flag2)
					{
						break;
					}
					builder.Append(source, index, found - index);
					builder.Append(replacement);
					index = found + search.Length;
				}
				builder.Append(source, index, source.Length - index);
				result = builder.ToString();
			}
			return result;
		}

		// Token: 0x06001D0A RID: 7434 RVA: 0x000A41FC File Offset: 0x000A23FC
		private static void RenameRecipeJson(string folder, string oldName, string newName)
		{
			bool flag = string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder);
			if (!flag)
			{
				string oldRecipe = Path.Combine(folder, RecipePathService.MakeSafeFileName(oldName) + ".json");
				string newRecipe = Path.Combine(folder, RecipePathService.MakeSafeFileName(newName) + ".json");
				bool flag2 = string.Equals(oldRecipe, newRecipe, StringComparison.OrdinalIgnoreCase);
				if (!flag2)
				{
					bool flag3 = !File.Exists(oldRecipe);
					if (!flag3)
					{
						bool flag4 = File.Exists(newRecipe);
						if (flag4)
						{
							File.Delete(newRecipe);
						}
						File.Move(oldRecipe, newRecipe);
					}
				}
			}
		}

		// Token: 0x0200043F RID: 1087
		public class RenameResult
		{
			// Token: 0x17000B7F RID: 2943
			// (get) Token: 0x06002B7C RID: 11132 RVA: 0x000EA195 File Offset: 0x000E8395
			// (set) Token: 0x06002B7D RID: 11133 RVA: 0x000EA19D File Offset: 0x000E839D
			public bool IsSuccess { get; set; }

			// Token: 0x17000B80 RID: 2944
			// (get) Token: 0x06002B7E RID: 11134 RVA: 0x000EA1A6 File Offset: 0x000E83A6
			// (set) Token: 0x06002B7F RID: 11135 RVA: 0x000EA1AE File Offset: 0x000E83AE
			public string Message { get; set; }

			// Token: 0x06002B80 RID: 11136 RVA: 0x000EA1B8 File Offset: 0x000E83B8
			public static ModelRenameService.RenameResult Fail(string message)
			{
				return new ModelRenameService.RenameResult
				{
					IsSuccess = false,
					Message = message
				};
			}

			// Token: 0x06002B81 RID: 11137 RVA: 0x000EA1E0 File Offset: 0x000E83E0
			public static ModelRenameService.RenameResult Ok(string message)
			{
				return new ModelRenameService.RenameResult
				{
					IsSuccess = true,
					Message = message
				};
			}
		}
	}
}
