﻿using System;
using System.IO;
using VisionMachine.Helpers;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Recipe
{
	// Token: 0x020001E4 RID: 484
	public static class RecipePathService
	{
		// Token: 0x17000912 RID: 2322
		// (get) Token: 0x06001D0B RID: 7435 RVA: 0x000A428C File Offset: 0x000A248C
		public static string RootDataPath
		{
			get
			{
				return string.IsNullOrWhiteSpace(Manager_path._dataPath) ? Manager_path.path_manager : Manager_path._dataPath;
			}
		}

		// Token: 0x06001D0C RID: 7436 RVA: 0x000A42B8 File Offset: 0x000A24B8
		public static string MakeSafeFileName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			string result;
			if (flag)
			{
				result = "Unknown";
			}
			else
			{
				foreach (char c in Path.GetInvalidFileNameChars())
				{
					name = name.Replace(c, '_');
				}
				result = name.Trim();
			}
			return result;
		}

		// Token: 0x06001D0D RID: 7437 RVA: 0x000A4308 File Offset: 0x000A2508
		public static string GetModelFolder(string modelName)
		{
			bool flag = string.IsNullOrWhiteSpace(modelName);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = Path.Combine(RecipePathService.RootDataPath, RecipePathService.MakeSafeFileName(modelName));
			}
			return result;
		}

		// Token: 0x06001D0E RID: 7438 RVA: 0x000A4338 File Offset: 0x000A2538
		public static string GetCurrentModelFolder()
		{
			ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
			bool flag = currentModel == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string modelName = RecipePathService.MakeSafeFileName(currentModel.Model_name);
				string folder = Path.Combine(RecipePathService.RootDataPath, modelName);
				Directory.CreateDirectory(folder);
				result = folder;
			}
			return result;
		}

		// Token: 0x06001D0F RID: 7439 RVA: 0x000A4380 File Offset: 0x000A2580
		public static string GetCurrentModelRecipeJsonPath()
		{
			ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
			bool flag = currentModel == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string modelName = RecipePathService.MakeSafeFileName(currentModel.Model_name);
				string folder = RecipePathService.GetCurrentModelFolder();
				result = Path.Combine(folder, modelName + ".json");
			}
			return result;
		}
	}
}
