﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Models.Recipe;

namespace VisionMachine.Services.Recipe
{
	// Token: 0x020001E5 RID: 485
	public static class RecipeStorageService
	{
		// Token: 0x06001D10 RID: 7440 RVA: 0x000A43CC File Offset: 0x000A25CC
		public static void Save(string path, RecipeConfig recipe)
		{
			string json = JsonConvert.SerializeObject(recipe, Formatting.Indented, new JsonSerializerSettings
			{
				TypeNameHandling = TypeNameHandling.Auto
			});
			File.WriteAllText(path, json);
		}

		// Token: 0x06001D11 RID: 7441 RVA: 0x000A43F8 File Offset: 0x000A25F8
		public static RecipeConfig Load(string path)
		{
			bool flag = !File.Exists(path);
			RecipeConfig result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string json = File.ReadAllText(path);
				bool flag2 = string.IsNullOrWhiteSpace(json);
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = JsonConvert.DeserializeObject<RecipeConfig>(json, new JsonSerializerSettings
					{
						TypeNameHandling = TypeNameHandling.Auto
					});
				}
			}
			return result;
		}
	}
}
