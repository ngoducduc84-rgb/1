﻿using System;
using System.Collections.Generic;
using System.IO;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Views.Setting.Services;

namespace VisionMachine.Services.Roi
{
	// Token: 0x020001DA RID: 474
	public static class CustomRoiRegionStore
	{
		// Token: 0x06001CD9 RID: 7385 RVA: 0x000A2974 File Offset: 0x000A0B74
		public static string BuildFileName(string roiName)
		{
			string safeName = CustomRoiRegionStore.MakeSafe(roiName);
			return string.Concat(new string[]
			{
				"custom_roi_",
				string.IsNullOrEmpty(safeName) ? "region" : safeName,
				"_",
				Guid.NewGuid().ToString("N").Substring(0, 8),
				".reg"
			});
		}

		// Token: 0x06001CDA RID: 7386 RVA: 0x000A29E0 File Offset: 0x000A0BE0
		public static string GetFullPath(ToolVision tool, RoiData roi)
		{
			bool flag = tool == null || roi == null || string.IsNullOrWhiteSpace(roi.CustomRegionFile);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string folder = CustomRoiRegionStore.GetTurnSnapFolder(tool);
				bool flag2 = string.IsNullOrWhiteSpace(folder);
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = Path.Combine(folder, roi.CustomRegionFile);
				}
			}
			return result;
		}

		// Token: 0x06001CDB RID: 7387 RVA: 0x000A2A30 File Offset: 0x000A0C30
		public static void Save(ToolVision tool, RoiData roi, HObject region)
		{
			bool flag = tool == null || roi == null;
			if (!flag)
			{
				string folder = CustomRoiRegionStore.GetTurnSnapFolder(tool);
				bool flag2 = string.IsNullOrWhiteSpace(folder);
				if (flag2)
				{
					throw new InvalidOperationException("The TurnSnap folder could not be resolved. Load a model before painting a Custom ROI.");
				}
				Directory.CreateDirectory(folder);
				bool flag3 = string.IsNullOrWhiteSpace(roi.CustomRegionFile);
				if (flag3)
				{
					roi.CustomRegionFile = CustomRoiRegionStore.BuildFileName(roi.Name);
				}
				string path = Path.Combine(folder, roi.CustomRegionFile);
				bool flag4 = region == null || !region.IsInitialized() || CustomRoiRegionStore.IsEmpty(region);
				if (flag4)
				{
					CustomRoiRegionStore.TryDelete(path);
					CustomRoiRegionStore.Invalidate(path);
				}
				else
				{
					HOperatorSet.WriteRegion(region, path);
					CustomRoiRegionStore.Invalidate(path);
				}
			}
		}

		// Token: 0x06001CDC RID: 7388 RVA: 0x000A2AE4 File Offset: 0x000A0CE4
		public static HObject Load(ToolVision tool, RoiData roi)
		{
			string path = CustomRoiRegionStore.GetFullPath(tool, roi);
			bool flag = string.IsNullOrWhiteSpace(path) || !File.Exists(path);
			HObject result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HObject cached = CustomRoiRegionStore.GetCached(path);
				bool flag2 = cached == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					HObject copy;
					HOperatorSet.CopyObj(cached, out copy, 1, -1);
					result = copy;
				}
			}
			return result;
		}

		// Token: 0x06001CDD RID: 7389 RVA: 0x000A2B4C File Offset: 0x000A0D4C
		private static HObject GetCached(string path)
		{
			DateTime stamp = File.GetLastWriteTimeUtc(path);
			object syncRoot = CustomRoiRegionStore.SyncRoot;
			HObject result;
			lock (syncRoot)
			{
				CustomRoiRegionStore.CacheEntry entry;
				bool flag2 = CustomRoiRegionStore.Cache.TryGetValue(path, out entry) && entry.LastWriteTimeUtc == stamp && entry.Region != null && entry.Region.IsInitialized();
				if (flag2)
				{
					result = entry.Region;
				}
				else
				{
					try
					{
						HObject region;
						HOperatorSet.ReadRegion(out region, path);
						bool flag3 = entry != null;
						if (flag3)
						{
							HObject region2 = entry.Region;
							if (region2 != null)
							{
								region2.Dispose();
							}
						}
						CustomRoiRegionStore.Cache[path] = new CustomRoiRegionStore.CacheEntry
						{
							LastWriteTimeUtc = stamp,
							Region = region
						};
						result = region;
					}
					catch
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x06001CDE RID: 7390 RVA: 0x000A2C3C File Offset: 0x000A0E3C
		public static void Invalidate(string path)
		{
			bool flag = string.IsNullOrWhiteSpace(path);
			if (!flag)
			{
				object syncRoot = CustomRoiRegionStore.SyncRoot;
				lock (syncRoot)
				{
					CustomRoiRegionStore.CacheEntry entry;
					bool flag3 = CustomRoiRegionStore.Cache.TryGetValue(path, out entry);
					if (flag3)
					{
						HObject region = entry.Region;
						if (region != null)
						{
							region.Dispose();
						}
						CustomRoiRegionStore.Cache.Remove(path);
					}
				}
			}
		}

		// Token: 0x06001CDF RID: 7391 RVA: 0x000A2CBC File Offset: 0x000A0EBC
		public static void Delete(ToolVision tool, RoiData roi)
		{
			string path = CustomRoiRegionStore.GetFullPath(tool, roi);
			bool flag = string.IsNullOrWhiteSpace(path);
			if (!flag)
			{
				CustomRoiRegionStore.Invalidate(path);
				CustomRoiRegionStore.TryDelete(path);
			}
		}

		// Token: 0x06001CE0 RID: 7392 RVA: 0x000A2CEC File Offset: 0x000A0EEC
		private static void TryDelete(string path)
		{
			try
			{
				bool flag = File.Exists(path);
				if (flag)
				{
					File.Delete(path);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06001CE1 RID: 7393 RVA: 0x000A2D24 File Offset: 0x000A0F24
		private static bool IsEmpty(HObject region)
		{
			bool result;
			try
			{
				HTuple area;
				HTuple htuple;
				HTuple htuple2;
				HOperatorSet.AreaCenter(region, out area, out htuple, out htuple2);
				result = (area.Length == 0 || area.D <= 0.0);
			}
			catch
			{
				result = true;
			}
			return result;
		}

		// Token: 0x06001CE2 RID: 7394 RVA: 0x000A2D7C File Offset: 0x000A0F7C
		private static string GetTurnSnapFolder(ToolVision tool)
		{
			string result;
			try
			{
				result = new SettingMasterImageService().GetTurnSnapFolder((tool != null) ? tool.ParentTurnSnap : null);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06001CE3 RID: 7395 RVA: 0x000A2DBC File Offset: 0x000A0FBC
		private static string MakeSafe(string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				foreach (char c in Path.GetInvalidFileNameChars())
				{
					value = value.Replace(c, '_');
				}
				result = value.Trim().Replace(' ', '_');
			}
			return result;
		}

		// Token: 0x04000C43 RID: 3139
		private static readonly object SyncRoot = new object();

		// Token: 0x04000C44 RID: 3140
		private static readonly Dictionary<string, CustomRoiRegionStore.CacheEntry> Cache = new Dictionary<string, CustomRoiRegionStore.CacheEntry>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000C45 RID: 3141
		private const string FileExtension = ".reg";

		// Token: 0x0200043A RID: 1082
		private sealed class CacheEntry
		{
			// Token: 0x04001547 RID: 5447
			public DateTime LastWriteTimeUtc;

			// Token: 0x04001548 RID: 5448
			public HObject Region;
		}
	}
}
