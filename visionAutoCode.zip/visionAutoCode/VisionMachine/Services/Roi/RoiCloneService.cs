﻿using System;
using System.Collections.Generic;
using System.Linq;
using VisionMachine.Models.Roi;

namespace VisionMachine.Services.Roi
{
	// Token: 0x020001DB RID: 475
	public static class RoiCloneService
	{
		// Token: 0x06001CE5 RID: 7397 RVA: 0x000A2E30 File Offset: 0x000A1030
		public static List<RoiData> BuildClones(RoiData source, RoiCloneSettings settings)
		{
			List<RoiData> clones = new List<RoiData>();
			bool flag = source == null || settings == null;
			List<RoiData> result;
			if (flag)
			{
				result = clones;
			}
			else
			{
				bool flag2 = source.RoiType == RoiType.CustomPaint;
				if (flag2)
				{
					result = clones;
				}
				else
				{
					double centerRow;
					double centerColumn;
					RoiCloneService.GetCenter(source, out centerRow, out centerColumn);
					double rowSign = (double)((settings.Direction == RoiCloneDirection.UpRight || settings.Direction == RoiCloneDirection.UpLeft) ? -1 : 1);
					double columnSign = (double)((settings.Direction == RoiCloneDirection.DownLeft || settings.Direction == RoiCloneDirection.UpLeft) ? -1 : 1);
					double radians = settings.Angle * 3.141592653589793 / 180.0;
					double cos = Math.Cos(radians);
					double sin = Math.Sin(radians);
					for (int r = 0; r < settings.Rows; r++)
					{
						for (int c = 0; c < settings.Columns; c++)
						{
							bool flag3 = r == 0 && c == 0;
							if (!flag3)
							{
								double offsetRow = rowSign * (double)r * settings.OffsetRow;
								double offsetColumn = columnSign * (double)c * settings.OffsetColumn;
								double rotatedRow = offsetRow * cos - offsetColumn * sin;
								double rotatedColumn = offsetRow * sin + offsetColumn * cos;
								RoiData clone = RoiCloneService.CloneGeometry(source);
								RoiCloneService.Translate(clone, rotatedRow, rotatedColumn);
								bool flag4 = Math.Abs(settings.Angle) > 1E-09;
								if (flag4)
								{
									RoiCloneService.Rotate(clone, centerRow + rotatedRow, centerColumn + rotatedColumn, radians);
								}
								clones.Add(clone);
							}
						}
					}
					result = clones;
				}
			}
			return result;
		}

		// Token: 0x06001CE6 RID: 7398 RVA: 0x000A2FC4 File Offset: 0x000A11C4
		private static RoiData CloneGeometry(RoiData source)
		{
			return new RoiData
			{
				RoiType = source.RoiType,
				MaskMode = source.MaskMode,
				Polarity = source.Polarity,
				IsEnabled = source.IsEnabled,
				MasterToolName = source.MasterToolName,
				MasterPositionToolName = source.MasterPositionToolName,
				MasterAngleToolName = source.MasterAngleToolName,
				Row1 = source.Row1,
				Col1 = source.Col1,
				Row2 = source.Row2,
				Col2 = source.Col2,
				CenterRow = source.CenterRow,
				CenterCol = source.CenterCol,
				Radius = source.Radius,
				Phi = source.Phi,
				Radius1 = source.Radius1,
				Radius2 = source.Radius2,
				Rows = ((source.Rows == null) ? new List<double>() : new List<double>(source.Rows)),
				Cols = ((source.Cols == null) ? new List<double>() : new List<double>(source.Cols)),
				CloneSettings = source.CloneSettings.Copy(),
				IsSelected = false
			};
		}

		// Token: 0x06001CE7 RID: 7399 RVA: 0x000A3114 File Offset: 0x000A1314
		public static void GetCenter(RoiData roi, out double row, out double column)
		{
			row = 0.0;
			column = 0.0;
			bool flag = roi == null;
			if (!flag)
			{
				switch (roi.RoiType)
				{
				case RoiType.Rectangle1:
				case RoiType.Line:
					row = (roi.Row1 + roi.Row2) / 2.0;
					column = (roi.Col1 + roi.Col2) / 2.0;
					break;
				case RoiType.Rectangle2:
				case RoiType.Circle:
				case RoiType.Ellipse:
					row = roi.CenterRow;
					column = roi.CenterCol;
					break;
				case RoiType.Polygon:
				case RoiType.FreeDraw:
				case RoiType.DrawRegion:
				{
					bool flag2 = roi.Rows == null || roi.Rows.Count == 0 || roi.Cols == null || roi.Cols.Count == 0;
					if (!flag2)
					{
						row = roi.Rows.Average();
						column = roi.Cols.Average();
					}
					break;
				}
				}
			}
		}

		// Token: 0x06001CE8 RID: 7400 RVA: 0x000A3218 File Offset: 0x000A1418
		private static void Translate(RoiData roi, double deltaRow, double deltaColumn)
		{
			roi.Row1 += deltaRow;
			roi.Row2 += deltaRow;
			roi.Col1 += deltaColumn;
			roi.Col2 += deltaColumn;
			roi.CenterRow += deltaRow;
			roi.CenterCol += deltaColumn;
			bool flag = roi.Rows != null;
			if (flag)
			{
				for (int i = 0; i < roi.Rows.Count; i++)
				{
					List<double> list = roi.Rows;
					int index = i;
					list[index] += deltaRow;
				}
			}
			bool flag2 = roi.Cols != null;
			if (flag2)
			{
				for (int j = 0; j < roi.Cols.Count; j++)
				{
					List<double> list = roi.Cols;
					int index = j;
					list[index] += deltaColumn;
				}
			}
		}

		// Token: 0x06001CE9 RID: 7401 RVA: 0x000A3314 File Offset: 0x000A1514
		private static void Rotate(RoiData roi, double pivotRow, double pivotColumn, double radians)
		{
			switch (roi.RoiType)
			{
			case RoiType.Rectangle1:
				RoiCloneService.ConvertRectangle1ToRectangle2(roi, radians);
				break;
			case RoiType.Rectangle2:
			case RoiType.Ellipse:
				roi.Phi -= radians;
				break;
			case RoiType.Line:
			{
				double row;
				double column;
				RoiCloneService.RotatePoint(pivotRow, pivotColumn, radians, roi.Row1, roi.Col1, out row, out column);
				double row2;
				double column2;
				RoiCloneService.RotatePoint(pivotRow, pivotColumn, radians, roi.Row2, roi.Col2, out row2, out column2);
				roi.Row1 = row;
				roi.Col1 = column;
				roi.Row2 = row2;
				roi.Col2 = column2;
				break;
			}
			case RoiType.Polygon:
			case RoiType.FreeDraw:
			case RoiType.DrawRegion:
				RoiCloneService.RotatePointList(roi, pivotRow, pivotColumn, radians);
				break;
			}
		}

		// Token: 0x06001CEA RID: 7402 RVA: 0x000A33D8 File Offset: 0x000A15D8
		private static void ConvertRectangle1ToRectangle2(RoiData roi, double radians)
		{
			double centerRow = (roi.Row1 + roi.Row2) / 2.0;
			double centerColumn = (roi.Col1 + roi.Col2) / 2.0;
			roi.RoiType = RoiType.Rectangle2;
			roi.CenterRow = centerRow;
			roi.CenterCol = centerColumn;
			roi.Radius1 = Math.Abs(roi.Col2 - roi.Col1) / 2.0;
			roi.Radius2 = Math.Abs(roi.Row2 - roi.Row1) / 2.0;
			roi.Phi = -radians;
		}

		// Token: 0x06001CEB RID: 7403 RVA: 0x000A3480 File Offset: 0x000A1680
		private static void RotatePointList(RoiData roi, double pivotRow, double pivotColumn, double radians)
		{
			bool flag = roi.Rows == null || roi.Cols == null;
			if (!flag)
			{
				int count = Math.Min(roi.Rows.Count, roi.Cols.Count);
				double cos = Math.Cos(radians);
				double sin = Math.Sin(radians);
				for (int i = 0; i < count; i++)
				{
					double deltaRow = roi.Rows[i] - pivotRow;
					double deltaColumn = roi.Cols[i] - pivotColumn;
					roi.Rows[i] = pivotRow + deltaRow * cos - deltaColumn * sin;
					roi.Cols[i] = pivotColumn + deltaRow * sin + deltaColumn * cos;
				}
			}
		}

		// Token: 0x06001CEC RID: 7404 RVA: 0x000A3544 File Offset: 0x000A1744
		private static void RotatePoint(double pivotRow, double pivotColumn, double radians, double row, double column, out double rotatedRow, out double rotatedColumn)
		{
			double cos = Math.Cos(radians);
			double sin = Math.Sin(radians);
			double deltaRow = row - pivotRow;
			double deltaColumn = column - pivotColumn;
			rotatedRow = pivotRow + deltaRow * cos - deltaColumn * sin;
			rotatedColumn = pivotColumn + deltaRow * sin + deltaColumn * cos;
		}
	}
}
