﻿using System;
using VisionMachine.Models.Config;

namespace VisionMachine.Services.Runtime
{
	// Token: 0x02000255 RID: 597
	public static class LogSettingRuntimeStore
	{
		// Token: 0x170009CD RID: 2509
		// (get) Token: 0x060021AF RID: 8623 RVA: 0x000C5EF3 File Offset: 0x000C40F3
		// (set) Token: 0x060021B0 RID: 8624 RVA: 0x000C5EFA File Offset: 0x000C40FA
		public static LogSettingConfig Current { get; private set; } = new LogSettingConfig();

		// Token: 0x060021B1 RID: 8625 RVA: 0x000C5F02 File Offset: 0x000C4102
		public static void Set(LogSettingConfig config)
		{
			LogSettingRuntimeStore.Current = (config ?? new LogSettingConfig());
		}

		// Token: 0x060021B2 RID: 8626 RVA: 0x000C5F15 File Offset: 0x000C4115
		public static void Clear()
		{
			LogSettingRuntimeStore.Current = new LogSettingConfig();
		}
	}
}
