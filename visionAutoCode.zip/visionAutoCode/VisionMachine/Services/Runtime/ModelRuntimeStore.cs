﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using VisionMachine.Models.Recipe;

namespace VisionMachine.Services.Runtime
{
	// Token: 0x02000256 RID: 598
	public static class ModelRuntimeStore
	{
		// Token: 0x14000038 RID: 56
		// (add) Token: 0x060021B4 RID: 8628 RVA: 0x000C5F30 File Offset: 0x000C4130
		// (remove) Token: 0x060021B5 RID: 8629 RVA: 0x000C5F64 File Offset: 0x000C4164
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler CurrentModelChanged;

		// Token: 0x170009CE RID: 2510
		// (get) Token: 0x060021B6 RID: 8630 RVA: 0x000C5F97 File Offset: 0x000C4197
		// (set) Token: 0x060021B7 RID: 8631 RVA: 0x000C5F9E File Offset: 0x000C419E
		public static ObservableCollection<ModelConfig> Models { get; private set; } = new ObservableCollection<ModelConfig>();

		// Token: 0x170009CF RID: 2511
		// (get) Token: 0x060021B8 RID: 8632 RVA: 0x000C5FA6 File Offset: 0x000C41A6
		// (set) Token: 0x060021B9 RID: 8633 RVA: 0x000C5FAD File Offset: 0x000C41AD
		public static ModelConfig CurrentModel { get; private set; }

		// Token: 0x060021BA RID: 8634 RVA: 0x000C5FB5 File Offset: 0x000C41B5
		public static void SetModels(IEnumerable<ModelConfig> models)
		{
			ModelRuntimeStore.Models = new ObservableCollection<ModelConfig>(models ?? Enumerable.Empty<ModelConfig>());
		}

		// Token: 0x060021BB RID: 8635 RVA: 0x000C5FD0 File Offset: 0x000C41D0
		public static void SetCurrentModel(ModelConfig model)
		{
			bool changed = !ModelRuntimeStore.IsSameModel(ModelRuntimeStore.CurrentModel, model);
			ModelRuntimeStore.CurrentModel = model;
			bool flag = changed;
			if (flag)
			{
				EventHandler currentModelChanged = ModelRuntimeStore.CurrentModelChanged;
				if (currentModelChanged != null)
				{
					currentModelChanged(null, EventArgs.Empty);
				}
			}
		}

		// Token: 0x060021BC RID: 8636 RVA: 0x000C6010 File Offset: 0x000C4210
		public static void ClearCurrentModel()
		{
			bool changed = ModelRuntimeStore.CurrentModel != null;
			ModelRuntimeStore.CurrentModel = null;
			bool flag = changed;
			if (flag)
			{
				EventHandler currentModelChanged = ModelRuntimeStore.CurrentModelChanged;
				if (currentModelChanged != null)
				{
					currentModelChanged(null, EventArgs.Empty);
				}
			}
		}

		// Token: 0x060021BD RID: 8637 RVA: 0x000C604C File Offset: 0x000C424C
		private static bool IsSameModel(ModelConfig left, ModelConfig right)
		{
			bool flag = left == right;
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = left == null || right == null;
				result = (!flag2 && left.Id == right.Id && string.Equals(left.Model_name, right.Model_name, StringComparison.OrdinalIgnoreCase));
			}
			return result;
		}

		// Token: 0x060021BE RID: 8638 RVA: 0x000C60A4 File Offset: 0x000C42A4
		public static ModelConfig GetById(Guid id)
		{
			return ModelRuntimeStore.Models.FirstOrDefault((ModelConfig x) => x.Id == id);
		}
	}
}
