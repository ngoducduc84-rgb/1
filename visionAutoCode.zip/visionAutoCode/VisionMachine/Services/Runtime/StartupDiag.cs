﻿using System;
using System.IO;

namespace VisionMachine.Services.Runtime
{
	// Token: 0x02000254 RID: 596
	public static class StartupDiag
	{
		// Token: 0x170009CC RID: 2508
		// (get) Token: 0x060021AA RID: 8618 RVA: 0x000C5DCC File Offset: 0x000C3FCC
		public static string LogPath
		{
			get
			{
				bool flag = StartupDiag._path == null;
				if (flag)
				{
					string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VisionMachine");
					Directory.CreateDirectory(folder);
					StartupDiag._path = Path.Combine(folder, "startup_log.txt");
				}
				return StartupDiag._path;
			}
		}

		// Token: 0x060021AB RID: 8619 RVA: 0x000C5E1C File Offset: 0x000C401C
		public static void Log(string message)
		{
			try
			{
				object sync = StartupDiag._sync;
				lock (sync)
				{
					File.AppendAllText(StartupDiag.LogPath, string.Concat(new string[]
					{
						"[",
						DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"),
						"] ",
						message,
						Environment.NewLine
					}));
				}
			}
			catch
			{
			}
		}

		// Token: 0x060021AC RID: 8620 RVA: 0x000C5EB8 File Offset: 0x000C40B8
		public static void Log(string message, Exception ex)
		{
			StartupDiag.Log(message + " | EXCEPTION: " + ((ex != null) ? ex.ToString() : null));
		}

		// Token: 0x060021AD RID: 8621 RVA: 0x000C5ED9 File Offset: 0x000C40D9
		public static void BeginSession()
		{
			StartupDiag.Log("==================== APP START ====================");
		}

		// Token: 0x04000DE0 RID: 3552
		private static readonly object _sync = new object();

		// Token: 0x04000DE1 RID: 3553
		private static string _path;
	}
}
