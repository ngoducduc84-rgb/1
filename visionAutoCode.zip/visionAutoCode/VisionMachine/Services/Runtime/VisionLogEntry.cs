﻿using System;

namespace VisionMachine.Services.Runtime
{
	// Token: 0x02000251 RID: 593
	public sealed class VisionLogEntry
	{
		// Token: 0x170009C3 RID: 2499
		// (get) Token: 0x06002184 RID: 8580 RVA: 0x000C5108 File Offset: 0x000C3308
		// (set) Token: 0x06002185 RID: 8581 RVA: 0x000C5110 File Offset: 0x000C3310
		public DateTime Timestamp { get; set; }

		// Token: 0x170009C4 RID: 2500
		// (get) Token: 0x06002186 RID: 8582 RVA: 0x000C5119 File Offset: 0x000C3319
		// (set) Token: 0x06002187 RID: 8583 RVA: 0x000C5121 File Offset: 0x000C3321
		public string Level { get; set; }

		// Token: 0x170009C5 RID: 2501
		// (get) Token: 0x06002188 RID: 8584 RVA: 0x000C512A File Offset: 0x000C332A
		// (set) Token: 0x06002189 RID: 8585 RVA: 0x000C5132 File Offset: 0x000C3332
		public string Source { get; set; }

		// Token: 0x170009C6 RID: 2502
		// (get) Token: 0x0600218A RID: 8586 RVA: 0x000C513B File Offset: 0x000C333B
		// (set) Token: 0x0600218B RID: 8587 RVA: 0x000C5143 File Offset: 0x000C3343
		public string Code { get; set; }

		// Token: 0x170009C7 RID: 2503
		// (get) Token: 0x0600218C RID: 8588 RVA: 0x000C514C File Offset: 0x000C334C
		// (set) Token: 0x0600218D RID: 8589 RVA: 0x000C5154 File Offset: 0x000C3354
		public string Message { get; set; }

		// Token: 0x170009C8 RID: 2504
		// (get) Token: 0x0600218E RID: 8590 RVA: 0x000C515D File Offset: 0x000C335D
		// (set) Token: 0x0600218F RID: 8591 RVA: 0x000C5165 File Offset: 0x000C3365
		public string Details { get; set; }

		// Token: 0x170009C9 RID: 2505
		// (get) Token: 0x06002190 RID: 8592 RVA: 0x000C516E File Offset: 0x000C336E
		// (set) Token: 0x06002191 RID: 8593 RVA: 0x000C5176 File Offset: 0x000C3376
		public string StackTrace { get; set; }

		// Token: 0x170009CA RID: 2506
		// (get) Token: 0x06002192 RID: 8594 RVA: 0x000C5180 File Offset: 0x000C3380
		public string TimeText
		{
			get
			{
				return this.Timestamp.ToString("dd/MM/yyyy HH:mm:ss.fff");
			}
		}
	}
}
