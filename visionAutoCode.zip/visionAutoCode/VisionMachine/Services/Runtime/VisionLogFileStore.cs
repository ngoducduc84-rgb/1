﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Services.Runtime
{
	// Token: 0x02000253 RID: 595
	public static class VisionLogFileStore
	{
		// Token: 0x170009CB RID: 2507
		// (get) Token: 0x060021A4 RID: 8612 RVA: 0x000C5A94 File Offset: 0x000C3C94
		public static string CurrentPath
		{
			get
			{
				object sync = VisionLogFileStore.Sync;
				string rootPath;
				lock (sync)
				{
					rootPath = VisionLogFileStore._rootPath;
				}
				return rootPath;
			}
		}

		// Token: 0x060021A5 RID: 8613 RVA: 0x000C5AD8 File Offset: 0x000C3CD8
		public static void Configure(string rootPath)
		{
			string path = string.IsNullOrWhiteSpace(rootPath) ? Manager_path.path_vision_log : Environment.ExpandEnvironmentVariables(rootPath.Trim());
			Directory.CreateDirectory(path);
			object sync = VisionLogFileStore.Sync;
			lock (sync)
			{
				VisionLogFileStore._rootPath = path;
			}
		}

		// Token: 0x060021A6 RID: 8614 RVA: 0x000C5B3C File Offset: 0x000C3D3C
		public static void Append(VisionLogEntry entry)
		{
			bool flag = entry == null;
			if (!flag)
			{
				try
				{
					object sync = VisionLogFileStore.Sync;
					lock (sync)
					{
						Directory.CreateDirectory(VisionLogFileStore._rootPath);
						string filePath = VisionLogFileStore.GetDailyFilePath(VisionLogFileStore._rootPath, entry.Timestamp.Date);
						string line = JsonConvert.SerializeObject(entry, Formatting.None);
						File.AppendAllText(filePath, line + Environment.NewLine);
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x060021A7 RID: 8615 RVA: 0x000C5BDC File Offset: 0x000C3DDC
		public static IReadOnlyList<VisionLogEntry> ReadRange(DateTime from, DateTime to)
		{
			List<VisionLogEntry> result = new List<VisionLogEntry>();
			bool flag = to < from;
			IReadOnlyList<VisionLogEntry> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				object sync = VisionLogFileStore.Sync;
				string root;
				lock (sync)
				{
					root = VisionLogFileStore._rootPath;
				}
				DateTime day = from.Date;
				while (day <= to.Date)
				{
					string filePath = VisionLogFileStore.GetDailyFilePath(root, day);
					try
					{
						object sync2 = VisionLogFileStore.Sync;
						string[] lines;
						lock (sync2)
						{
							bool flag4 = !File.Exists(filePath);
							if (flag4)
							{
								goto IL_11C;
							}
							lines = File.ReadAllLines(filePath);
						}
						foreach (string line in lines)
						{
							bool flag5 = string.IsNullOrWhiteSpace(line);
							if (!flag5)
							{
								VisionLogEntry entry;
								try
								{
									entry = JsonConvert.DeserializeObject<VisionLogEntry>(line);
								}
								catch
								{
									goto IL_105;
								}
								bool flag6 = entry != null && entry.Timestamp >= from && entry.Timestamp <= to;
								if (flag6)
								{
									result.Add(entry);
								}
							}
							IL_105:;
						}
					}
					catch
					{
					}
					IL_11C:
					day = day.AddDays(1.0);
					continue;
					goto IL_11C;
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x060021A8 RID: 8616 RVA: 0x000C5D68 File Offset: 0x000C3F68
		private static string GetDailyFilePath(string root, DateTime date)
		{
			string monthFolder = Path.Combine(root, date.ToString("yyyy-MM"));
			Directory.CreateDirectory(monthFolder);
			return Path.Combine(monthFolder, "vision_log_" + date.ToString("yyyyMMdd") + ".jsonl");
		}

		// Token: 0x04000DDE RID: 3550
		private static readonly object Sync = new object();

		// Token: 0x04000DDF RID: 3551
		private static string _rootPath = Manager_path.path_vision_log;
	}
}
