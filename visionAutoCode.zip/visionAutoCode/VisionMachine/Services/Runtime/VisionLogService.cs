﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace VisionMachine.Services.Runtime
{
	// Token: 0x02000252 RID: 594
	public static class VisionLogService
	{
		// Token: 0x14000036 RID: 54
		// (add) Token: 0x06002194 RID: 8596 RVA: 0x000C51A0 File Offset: 0x000C33A0
		// (remove) Token: 0x06002195 RID: 8597 RVA: 0x000C51D4 File Offset: 0x000C33D4
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event Action<VisionLogEntry> EntryLogged;

		// Token: 0x14000037 RID: 55
		// (add) Token: 0x06002196 RID: 8598 RVA: 0x000C5208 File Offset: 0x000C3408
		// (remove) Token: 0x06002197 RID: 8599 RVA: 0x000C523C File Offset: 0x000C343C
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event Action HistoryCleared;

		// Token: 0x06002198 RID: 8600 RVA: 0x000C5270 File Offset: 0x000C3470
		public static void RegisterSink(Action<string, string> sink)
		{
			object sync = VisionLogService.Sync;
			List<VisionLogEntry> snapshot;
			lock (sync)
			{
				VisionLogService._sink = sink;
				snapshot = ((sink == null) ? null : VisionLogService.History.ToList<VisionLogEntry>());
			}
			bool flag2 = sink == null || snapshot == null;
			if (!flag2)
			{
				foreach (VisionLogEntry entry in snapshot)
				{
					try
					{
						sink(entry.Level, entry.Message);
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x06002199 RID: 8601 RVA: 0x000C533C File Offset: 0x000C353C
		public static IReadOnlyList<VisionLogEntry> GetSnapshot()
		{
			object sync = VisionLogService.Sync;
			IReadOnlyList<VisionLogEntry> result;
			lock (sync)
			{
				result = VisionLogService.History.Select(new Func<VisionLogEntry, VisionLogEntry>(VisionLogService.Clone)).ToList<VisionLogEntry>();
			}
			return result;
		}

		// Token: 0x0600219A RID: 8602 RVA: 0x000C5398 File Offset: 0x000C3598
		public static void Log(string level, string message)
		{
			VisionLogService.Log(level, VisionLogService.InferSource(message), null, message, null, null);
		}

		// Token: 0x0600219B RID: 8603 RVA: 0x000C53AC File Offset: 0x000C35AC
		public static void Log(string level, string source, string code, string message, string details = null, string stackTrace = null)
		{
			VisionLogEntry entry = new VisionLogEntry
			{
				Timestamp = DateTime.Now,
				Level = VisionLogService.NormalizeLevel(level),
				Source = (string.IsNullOrWhiteSpace(source) ? "Application" : source.Trim()),
				Code = (string.IsNullOrWhiteSpace(code) ? VisionLogService.CreateCode(level, source) : code.Trim()),
				Message = (message ?? string.Empty),
				Details = (details ?? string.Empty),
				StackTrace = (stackTrace ?? string.Empty)
			};
			object sync = VisionLogService.Sync;
			Action<string, string> sink;
			Action<VisionLogEntry> handler;
			lock (sync)
			{
				VisionLogService.History.Add(entry);
				while (VisionLogService.History.Count > 5000)
				{
					VisionLogService.History.RemoveAt(0);
				}
				sink = VisionLogService._sink;
				handler = VisionLogService.EntryLogged;
			}
			VisionLogFileStore.Append(entry);
			try
			{
				if (sink != null)
				{
					sink(entry.Level, entry.Message);
				}
			}
			catch
			{
			}
			try
			{
				if (handler != null)
				{
					handler(VisionLogService.Clone(entry));
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600219C RID: 8604 RVA: 0x000C5514 File Offset: 0x000C3714
		public static void Clear()
		{
			object sync = VisionLogService.Sync;
			Action cleared;
			lock (sync)
			{
				VisionLogService.History.Clear();
				cleared = VisionLogService.HistoryCleared;
			}
			try
			{
				if (cleared != null)
				{
					cleared();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600219D RID: 8605 RVA: 0x000C5588 File Offset: 0x000C3788
		public static void MergeFromStorage(DateTime from, DateTime to)
		{
			IReadOnlyList<VisionLogEntry> storedEntries = VisionLogFileStore.ReadRange(from, to);
			bool flag = storedEntries == null || storedEntries.Count == 0;
			if (!flag)
			{
				object sync = VisionLogService.Sync;
				lock (sync)
				{
					HashSet<string> existingKeys = new HashSet<string>(VisionLogService.History.Select(new Func<VisionLogEntry, string>(VisionLogService.CreateEntryKey)));
					foreach (VisionLogEntry entry in storedEntries)
					{
						bool flag3 = entry != null && existingKeys.Add(VisionLogService.CreateEntryKey(entry));
						if (flag3)
						{
							VisionLogService.History.Add(VisionLogService.Clone(entry));
						}
					}
					bool flag4 = VisionLogService.History.Count > 5000;
					if (flag4)
					{
						List<VisionLogEntry> newest = (from x in (from x in VisionLogService.History
						orderby x.Timestamp descending
						select x).Take(5000)
						orderby x.Timestamp
						select x).ToList<VisionLogEntry>();
						VisionLogService.History.Clear();
						VisionLogService.History.AddRange(newest);
					}
				}
			}
		}

		// Token: 0x0600219E RID: 8606 RVA: 0x000C5714 File Offset: 0x000C3914
		private static string CreateEntryKey(VisionLogEntry entry)
		{
			return string.Concat(new string[]
			{
				entry.Timestamp.Ticks.ToString(),
				"|",
				entry.Level,
				"|",
				entry.Code,
				"|",
				entry.Message
			});
		}

		// Token: 0x0600219F RID: 8607 RVA: 0x000C5780 File Offset: 0x000C3980
		private static VisionLogEntry Clone(VisionLogEntry entry)
		{
			return new VisionLogEntry
			{
				Timestamp = entry.Timestamp,
				Level = entry.Level,
				Source = entry.Source,
				Code = entry.Code,
				Message = entry.Message,
				Details = entry.Details,
				StackTrace = entry.StackTrace
			};
		}

		// Token: 0x060021A0 RID: 8608 RVA: 0x000C57F4 File Offset: 0x000C39F4
		private static string NormalizeLevel(string level)
		{
			string value = (level ?? "INFO").Trim().ToUpperInvariant();
			bool flag = value == "WARNING";
			string result;
			if (flag)
			{
				result = "WARN";
			}
			else
			{
				bool flag2 = value == "ERR";
				if (flag2)
				{
					result = "ERROR";
				}
				else
				{
					bool flag3 = value == "OK";
					if (flag3)
					{
						result = "SUCCESS";
					}
					else
					{
						result = value;
					}
				}
			}
			return result;
		}

		// Token: 0x060021A1 RID: 8609 RVA: 0x000C5864 File Offset: 0x000C3A64
		private static string InferSource(string message)
		{
			string value = (message ?? string.Empty).ToLowerInvariant();
			bool flag = value.Contains("camera");
			string result;
			if (flag)
			{
				result = "Camera";
			}
			else
			{
				bool flag2 = value.Contains("opc");
				if (flag2)
				{
					result = "OPC UA Client";
				}
				else
				{
					bool flag3 = value.Contains("modbus") || value.Contains("plc") || value.Contains("connection");
					if (flag3)
					{
						result = "Communication";
					}
					else
					{
						bool flag4 = value.Contains("model") || value.Contains("tool");
						if (flag4)
						{
							result = "Vision Tool";
						}
						else
						{
							bool flag5 = value.Contains("calib") || value.Contains("robot");
							if (flag5)
							{
								result = "Calibration";
							}
							else
							{
								bool flag6 = value.Contains("config") || value.Contains("loaded") || value.Contains("saved");
								if (flag6)
								{
									result = "Configuration";
								}
								else
								{
									result = "Application";
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060021A2 RID: 8610 RVA: 0x000C5980 File Offset: 0x000C3B80
		private static string CreateCode(string level, string source)
		{
			string prefix = (source ?? string.Empty).ToUpperInvariant();
			bool flag = prefix.Contains("CAMERA");
			if (flag)
			{
				prefix = "CAM";
			}
			else
			{
				bool flag2 = prefix.Contains("OPC");
				if (flag2)
				{
					prefix = "OPC";
				}
				else
				{
					bool flag3 = prefix.Contains("COMM");
					if (flag3)
					{
						prefix = "COM";
					}
					else
					{
						bool flag4 = prefix.Contains("CALIB");
						if (flag4)
						{
							prefix = "CAL";
						}
						else
						{
							bool flag5 = prefix.Contains("VISION") || prefix.Contains("TOOL");
							if (flag5)
							{
								prefix = "VIS";
							}
							else
							{
								bool flag6 = (level ?? string.Empty).IndexOf("ERROR", StringComparison.OrdinalIgnoreCase) >= 0;
								if (flag6)
								{
									prefix = "ERR";
								}
								else
								{
									prefix = "APP";
								}
							}
						}
					}
				}
			}
			return prefix + "-" + DateTime.Now.ToString("HHmmssfff");
		}

		// Token: 0x04000DD8 RID: 3544
		private const int MaxHistoryCount = 5000;

		// Token: 0x04000DD9 RID: 3545
		private static readonly object Sync = new object();

		// Token: 0x04000DDA RID: 3546
		private static readonly List<VisionLogEntry> History = new List<VisionLogEntry>();

		// Token: 0x04000DDB RID: 3547
		private static Action<string, string> _sink;
	}
}
