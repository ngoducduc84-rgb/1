﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace VisionMachine.Services.Security
{
	// Token: 0x0200026B RID: 619
	public static class AdminSessionService
	{
		// Token: 0x1400003B RID: 59
		// (add) Token: 0x06002270 RID: 8816 RVA: 0x000D1C84 File Offset: 0x000CFE84
		// (remove) Token: 0x06002271 RID: 8817 RVA: 0x000D1CB8 File Offset: 0x000CFEB8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler Changed;

		// Token: 0x170009E5 RID: 2533
		// (get) Token: 0x06002272 RID: 8818 RVA: 0x000D1CEC File Offset: 0x000CFEEC
		public static bool IsSignedIn
		{
			get
			{
				object syncRoot = AdminSessionService.SyncRoot;
				bool signedIn;
				lock (syncRoot)
				{
					signedIn = AdminSessionService._signedIn;
				}
				return signedIn;
			}
		}

		// Token: 0x170009E6 RID: 2534
		// (get) Token: 0x06002273 RID: 8819 RVA: 0x000D1D30 File Offset: 0x000CFF30
		public static string UserName
		{
			get
			{
				return "Kevil";
			}
		}

		// Token: 0x06002274 RID: 8820 RVA: 0x000D1D48 File Offset: 0x000CFF48
		public static bool SignIn(string userName, string password)
		{
			bool nameOk = string.Equals((userName ?? string.Empty).Trim(), "Kevil", StringComparison.OrdinalIgnoreCase);
			bool passwordOk = AdminSessionService.FixedTimeEquals(AdminSessionService.Hash(password ?? string.Empty), "A443AF36F91059D1AA3F169327865A0D9DE8E8A8D403021CD1AF005B06C5F79D");
			bool flag = !nameOk || !passwordOk;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				object syncRoot = AdminSessionService.SyncRoot;
				lock (syncRoot)
				{
					AdminSessionService._signedIn = true;
				}
				EventHandler changed = AdminSessionService.Changed;
				if (changed != null)
				{
					changed(null, EventArgs.Empty);
				}
				result = true;
			}
			return result;
		}

		// Token: 0x06002275 RID: 8821 RVA: 0x000D1DF4 File Offset: 0x000CFFF4
		public static void SignOut()
		{
			object syncRoot = AdminSessionService.SyncRoot;
			lock (syncRoot)
			{
				bool flag2 = !AdminSessionService._signedIn;
				if (flag2)
				{
					return;
				}
				AdminSessionService._signedIn = false;
			}
			EventHandler changed = AdminSessionService.Changed;
			if (changed != null)
			{
				changed(null, EventArgs.Empty);
			}
		}

		// Token: 0x06002276 RID: 8822 RVA: 0x000D1E60 File Offset: 0x000D0060
		private static string Hash(string password)
		{
			string result;
			using (SHA256 sha = SHA256.Create())
			{
				byte[] digest = sha.ComputeHash(Encoding.UTF8.GetBytes("Kevil|" + password));
				result = string.Concat(from b in digest
				select b.ToString("X2"));
			}
			return result;
		}

		// Token: 0x06002277 RID: 8823 RVA: 0x000D1EDC File Offset: 0x000D00DC
		private static bool FixedTimeEquals(string a, string b)
		{
			bool flag = a == null || b == null || a.Length != b.Length;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				int difference = 0;
				for (int i = 0; i < a.Length; i++)
				{
					difference |= (int)(a[i] ^ b[i]);
				}
				result = (difference == 0);
			}
			return result;
		}

		// Token: 0x04000E37 RID: 3639
		private const string AdminUserName = "Kevil";

		// Token: 0x04000E38 RID: 3640
		private const string AdminPasswordHash = "A443AF36F91059D1AA3F169327865A0D9DE8E8A8D403021CD1AF005B06C5F79D";

		// Token: 0x04000E39 RID: 3641
		private static readonly object SyncRoot = new object();

		// Token: 0x04000E3A RID: 3642
		private static bool _signedIn;
	}
}
