﻿using System;
using System.IO;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.Services
{
	// Token: 0x020001D6 RID: 470
	public class SettingShapeModelMatchingService
	{
		// Token: 0x06001CB5 RID: 7349 RVA: 0x000A1554 File Offset: 0x0009F754
		public ShapeMatchResult Matching(ToolVision tool, HObject image)
		{
			ShapeMatchResult result = new ShapeMatchResult();
			bool flag = tool == null;
			ShapeMatchResult result2;
			if (flag)
			{
				result.Message = "Tool null.";
				result2 = result;
			}
			else
			{
				bool flag2 = image == null || !image.IsInitialized();
				if (flag2)
				{
					result.Message = "No image is available for matching.";
					result2 = result;
				}
				else
				{
					ShapeModelToolConfig config = tool.Config as ShapeModelToolConfig;
					ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
					bool flag3 = config == null || train == null;
					if (flag3)
					{
						result.Message = "The selected tool is not a Shape Model tool.";
						result2 = result;
					}
					else
					{
						bool flag4 = !train.IsTrained;
						if (flag4)
						{
							result.Message = "The Shape Model has not been trained.";
							result2 = result;
						}
						else
						{
							bool flag5 = tool.ParentTurnSnap == null;
							if (flag5)
							{
								result.Message = "The tool does not belong to a TurnSnap.";
								result2 = result;
							}
							else
							{
								string turnSnapFolder = this._masterImageService.GetTurnSnapFolder(tool.ParentTurnSnap);
								bool flag6 = string.IsNullOrWhiteSpace(turnSnapFolder);
								if (flag6)
								{
									result.Message = "Could not get the TurnSnap folder.";
									result2 = result;
								}
								else
								{
									string modelPath = this._pathService.GetShapeModelFullPath(turnSnapFolder, tool);
									bool flag7 = !File.Exists(modelPath);
									if (flag7)
									{
										result.Message = "Shape Model file was not found:\n" + modelPath;
										result2 = result;
									}
									else
									{
										HObject grayImage = null;
										HObject maskedImage = null;
										HObject searchImage = null;
										try
										{
											string cacheKey = tool.ToolId + "_" + modelPath;
											HTuple modelId = ShapeModelRuntimeCache.GetOrLoad(cacheKey, modelPath);
											grayImage = this.ConvertToGray(image);
											maskedImage = this._roiImageService.ApplyMaskRois(grayImage, tool);
											searchImage = this._roiImageService.ReduceByRois(maskedImage, tool.LimitRoiItems, tool);
											HTuple row;
											HTuple column;
											HTuple angle;
											HTuple score;
											HOperatorSet.FindShapeModel(searchImage, modelId, config.Angle_Start, config.Angle_extent, config.Min_score, config.Num_matched, config.Max_overlap, "least_squares", config.Num_level, config.Greediness, out row, out column, out angle, out score);
											bool flag8 = row.Length <= 0;
											if (flag8)
											{
												result.IsSuccess = false;
												result.Message = "Shape Model was not found.";
												result2 = result;
											}
											else
											{
												result.IsSuccess = true;
												result.Row = row[0].D;
												result.Column = column[0].D;
												result.Angle = angle[0].D;
												result.Score = score[0].D;
												train.LastRow = result.Row;
												train.LastColumn = result.Column;
												train.LastAngle = result.Angle;
												train.LastScore = result.Score;
												result.Message = "Matching completed successfully.";
												result2 = result;
											}
										}
										catch (Exception ex)
										{
											result.IsSuccess = false;
											result.Message = "Matching failed: " + ex.Message;
											result2 = result;
										}
										finally
										{
											bool flag9 = searchImage != null;
											if (flag9)
											{
												searchImage.Dispose();
											}
											bool flag10 = maskedImage != null;
											if (flag10)
											{
												maskedImage.Dispose();
											}
											bool flag11 = grayImage != null;
											if (flag11)
											{
												grayImage.Dispose();
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06001CB6 RID: 7350 RVA: 0x000A18CC File Offset: 0x0009FACC
		public ShapeMatchResult DefineMaster(ToolVision tool)
		{
			ShapeMatchResult result = new ShapeMatchResult();
			ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
			bool flag = train == null;
			ShapeMatchResult result2;
			if (flag)
			{
				result.Message = "The selected tool does not have a TrainModel.";
				result2 = result;
			}
			else
			{
				bool flag2 = train.LastScore <= 0.0;
				if (flag2)
				{
					result.Message = "No matching result is available for Define Master.";
					result2 = result;
				}
				else
				{
					train.MasterRow = train.LastRow;
					train.MasterColumn = train.LastColumn;
					train.MasterAngle = train.LastAngle;
					train.HasMasterDefined = true;
					result.IsSuccess = true;
					result.Row = train.MasterRow;
					result.Column = train.MasterColumn;
					result.Angle = train.MasterAngle;
					result.Score = train.LastScore;
					result.Message = "Master was defined successfully.";
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x06001CB7 RID: 7351 RVA: 0x000A19B0 File Offset: 0x0009FBB0
		public ShapeMatchResult TrialRun(ToolVision tool, HObject image)
		{
			ShapeMatchResult result = this.Matching(tool, image);
			bool flag = !result.IsSuccess;
			ShapeMatchResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null || !train.HasMasterDefined;
				if (flag2)
				{
					result.IsSuccess = false;
					result.Message = "Master has not been defined.";
					result2 = result;
				}
				else
				{
					result.DeltaRow = result.Row - train.MasterRow;
					result.DeltaColumn = result.Column - train.MasterColumn;
					result.DeltaAngle = SettingShapeModelMatchingService.NormalizeToPi(result.Angle - train.MasterAngle);
					result.Message = string.Concat(new string[]
					{
						"Trial Run OK. DeltaRow=",
						result.DeltaRow.ToString("0.000"),
						", DeltaColumn=",
						result.DeltaColumn.ToString("0.000"),
						", DeltaAngle=",
						SettingShapeModelMatchingService.ToDegrees(result.DeltaAngle).ToString("0.000"),
						" deg"
					});
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x06001CB8 RID: 7352 RVA: 0x000A1ADC File Offset: 0x0009FCDC
		private static double NormalizeToPi(double value)
		{
			while (value > 3.141592653589793)
			{
				value -= 6.283185307179586;
			}
			while (value < -3.141592653589793)
			{
				value += 6.283185307179586;
			}
			return value;
		}

		// Token: 0x06001CB9 RID: 7353 RVA: 0x000A1B30 File Offset: 0x0009FD30
		private static double ToDegrees(double radians)
		{
			return radians * 180.0 / 3.141592653589793;
		}

		// Token: 0x06001CBA RID: 7354 RVA: 0x000A1B58 File Offset: 0x0009FD58
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.I == 1;
			HObject gray;
			if (flag)
			{
				HOperatorSet.CopyImage(image, out gray);
			}
			else
			{
				HOperatorSet.Rgb1ToGray(image, out gray);
			}
			return gray;
		}

		// Token: 0x06001CBB RID: 7355 RVA: 0x000A1B9C File Offset: 0x0009FD9C
		private HObject ApplyLimitRoi(HObject image, ToolVision tool)
		{
			HObject resultImage = null;
			bool flag = tool.LimitRoiItems == null || tool.LimitRoiItems.Count == 0;
			HObject result;
			if (flag)
			{
				HOperatorSet.CopyImage(image, out resultImage);
				result = resultImage;
			}
			else
			{
				HObject allRegions;
				HOperatorSet.GenEmptyObj(out allRegions);
				foreach (RoiData roi in tool.LimitRoiItems)
				{
					HObject region = this.GenRegionFromRoi(roi);
					HTuple area;
					HTuple row;
					HTuple col;
					HOperatorSet.AreaCenter(region, out area, out row, out col);
					bool flag2 = area.Length > 0 && area.D > 0.0;
					if (flag2)
					{
						HObject temp;
						HOperatorSet.ConcatObj(allRegions, region, out temp);
						allRegions.Dispose();
						allRegions = temp;
					}
					region.Dispose();
				}
				HTuple count;
				HOperatorSet.CountObj(allRegions, out count);
				bool flag3 = count.I <= 0;
				if (flag3)
				{
					allRegions.Dispose();
					HOperatorSet.CopyImage(image, out resultImage);
					result = resultImage;
				}
				else
				{
					HObject unionRegion;
					HOperatorSet.Union1(allRegions, out unionRegion);
					HOperatorSet.ReduceDomain(image, unionRegion, out resultImage);
					allRegions.Dispose();
					unionRegion.Dispose();
					result = resultImage;
				}
			}
			return result;
		}

		// Token: 0x06001CBC RID: 7356 RVA: 0x000A1CE0 File Offset: 0x0009FEE0
		private HObject GenRegionFromRoi(RoiData roi)
		{
			bool flag = roi == null;
			HObject result;
			if (flag)
			{
				HObject region;
				HOperatorSet.GenEmptyObj(out region);
				result = region;
			}
			else
			{
				bool flag2 = roi.RoiType == RoiType.Rectangle1;
				HObject region;
				if (flag2)
				{
					HOperatorSet.GenRectangle1(out region, roi.Row1, roi.Col1, roi.Row2, roi.Col2);
				}
				else
				{
					bool flag3 = roi.RoiType == RoiType.Rectangle2;
					if (flag3)
					{
						HOperatorSet.GenRectangle2(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
					}
					else
					{
						bool flag4 = roi.RoiType == RoiType.Circle;
						if (flag4)
						{
							HOperatorSet.GenCircle(out region, roi.CenterRow, roi.CenterCol, roi.Radius);
						}
						else
						{
							bool flag5 = roi.RoiType == RoiType.Ellipse;
							if (flag5)
							{
								HOperatorSet.GenEllipse(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
							}
							else
							{
								bool flag6 = roi.RoiType == RoiType.Polygon || roi.RoiType == RoiType.FreeDraw;
								if (flag6)
								{
									region = this.GenRegionFromContourRoi(roi);
								}
								else
								{
									HOperatorSet.GenEmptyObj(out region);
								}
							}
						}
					}
				}
				result = region;
			}
			return result;
		}

		// Token: 0x06001CBD RID: 7357 RVA: 0x000A1E6C File Offset: 0x000A006C
		private HObject GenRegionFromContourRoi(RoiData roi)
		{
			bool flag = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 3 || roi.Rows.Count != roi.Cols.Count;
			HObject result;
			if (flag)
			{
				HObject region;
				HOperatorSet.GenEmptyObj(out region);
				result = region;
			}
			else
			{
				HObject contour = null;
				HObject region;
				try
				{
					HOperatorSet.GenContourPolygonXld(out contour, new HTuple(roi.Rows.ToArray()), new HTuple(roi.Cols.ToArray()));
					HOperatorSet.GenRegionContourXld(contour, out region, "filled");
				}
				finally
				{
					bool flag2 = contour != null;
					if (flag2)
					{
						contour.Dispose();
					}
				}
				result = region;
			}
			return result;
		}

		// Token: 0x04000C34 RID: 3124
		private readonly SettingShapeModelPathService _pathService = new SettingShapeModelPathService();

		// Token: 0x04000C35 RID: 3125
		private readonly SettingMasterImageService _masterImageService = new SettingMasterImageService();

		// Token: 0x04000C36 RID: 3126
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();
	}
}
