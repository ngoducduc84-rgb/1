﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HalconDotNet;

namespace VisionMachine.Services
{
	// Token: 0x020001D7 RID: 471
	public static class ShapeModelRuntimeCache
	{
		// Token: 0x06001CBF RID: 7359 RVA: 0x000A1F60 File Offset: 0x000A0160
		public static HTuple GetOrLoad(string key, string modelPath)
		{
			bool flag = string.IsNullOrWhiteSpace(key);
			if (flag)
			{
				key = modelPath;
			}
			string normalizedPath = Path.GetFullPath(modelPath);
			DateTime lastWriteTimeUtc = File.GetLastWriteTimeUtc(normalizedPath);
			object syncRoot = ShapeModelRuntimeCache.SyncRoot;
			HTuple result;
			lock (syncRoot)
			{
				ShapeModelRuntimeCache.CacheEntry entry;
				bool flag3 = ShapeModelRuntimeCache._cache.TryGetValue(key, out entry) && string.Equals(entry.ModelPath, normalizedPath, StringComparison.OrdinalIgnoreCase) && entry.LastWriteTimeUtc == lastWriteTimeUtc;
				if (flag3)
				{
					result = entry.ModelId;
				}
				else
				{
					bool flag4 = entry != null;
					if (flag4)
					{
						HOperatorSet.ClearShapeModel(entry.ModelId);
					}
					HTuple modelId;
					HOperatorSet.ReadShapeModel(normalizedPath, out modelId);
					ShapeModelRuntimeCache._cache[key] = new ShapeModelRuntimeCache.CacheEntry
					{
						ModelPath = normalizedPath,
						LastWriteTimeUtc = lastWriteTimeUtc,
						ModelId = modelId
					};
					result = modelId;
				}
			}
			return result;
		}

		// Token: 0x06001CC0 RID: 7360 RVA: 0x000A2054 File Offset: 0x000A0254
		public static void ClearOne(string key)
		{
			object syncRoot = ShapeModelRuntimeCache.SyncRoot;
			lock (syncRoot)
			{
				ShapeModelRuntimeCache.CacheEntry entry;
				bool flag2 = !ShapeModelRuntimeCache._cache.TryGetValue(key, out entry);
				if (!flag2)
				{
					HOperatorSet.ClearShapeModel(entry.ModelId);
					ShapeModelRuntimeCache._cache.Remove(key);
				}
			}
		}

		// Token: 0x06001CC1 RID: 7361 RVA: 0x000A20C0 File Offset: 0x000A02C0
		public static void ClearByTool(string toolId)
		{
			object syncRoot = ShapeModelRuntimeCache.SyncRoot;
			lock (syncRoot)
			{
				List<string> keys = (from key in ShapeModelRuntimeCache._cache.Keys
				where key == toolId || key.StartsWith(toolId + "_")
				select key).ToList<string>();
				foreach (string key2 in keys)
				{
					HOperatorSet.ClearShapeModel(ShapeModelRuntimeCache._cache[key2].ModelId);
					ShapeModelRuntimeCache._cache.Remove(key2);
				}
			}
		}

		// Token: 0x06001CC2 RID: 7362 RVA: 0x000A218C File Offset: 0x000A038C
		public static void ClearAll()
		{
			object syncRoot = ShapeModelRuntimeCache.SyncRoot;
			lock (syncRoot)
			{
				foreach (ShapeModelRuntimeCache.CacheEntry item in ShapeModelRuntimeCache._cache.Values)
				{
					HOperatorSet.ClearShapeModel(item.ModelId);
				}
				ShapeModelRuntimeCache._cache.Clear();
			}
		}

		// Token: 0x04000C37 RID: 3127
		private static readonly object SyncRoot = new object();

		// Token: 0x04000C38 RID: 3128
		private static readonly Dictionary<string, ShapeModelRuntimeCache.CacheEntry> _cache = new Dictionary<string, ShapeModelRuntimeCache.CacheEntry>();

		// Token: 0x02000438 RID: 1080
		private sealed class CacheEntry
		{
			// Token: 0x17000B7C RID: 2940
			// (get) Token: 0x06002B52 RID: 11090 RVA: 0x000EA0FF File Offset: 0x000E82FF
			// (set) Token: 0x06002B53 RID: 11091 RVA: 0x000EA107 File Offset: 0x000E8307
			public string ModelPath { get; set; }

			// Token: 0x17000B7D RID: 2941
			// (get) Token: 0x06002B54 RID: 11092 RVA: 0x000EA110 File Offset: 0x000E8310
			// (set) Token: 0x06002B55 RID: 11093 RVA: 0x000EA118 File Offset: 0x000E8318
			public DateTime LastWriteTimeUtc { get; set; }

			// Token: 0x17000B7E RID: 2942
			// (get) Token: 0x06002B56 RID: 11094 RVA: 0x000EA121 File Offset: 0x000E8321
			// (set) Token: 0x06002B57 RID: 11095 RVA: 0x000EA129 File Offset: 0x000E8329
			public HTuple ModelId { get; set; }
		}
	}
}
