﻿using System;

namespace VisionMachine.Services.Storage
{
	// Token: 0x020001DE RID: 478
	public sealed class ApplicationTitleSetting
	{
		// Token: 0x17000911 RID: 2321
		// (get) Token: 0x06001CF5 RID: 7413 RVA: 0x000A3680 File Offset: 0x000A1880
		// (set) Token: 0x06001CF6 RID: 7414 RVA: 0x000A3688 File Offset: 0x000A1888
		public string Title { get; set; }
	}
}
