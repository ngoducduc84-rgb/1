﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Services.Storage
{
	// Token: 0x020001DF RID: 479
	public static class ApplicationTitleStorageService
	{
		// Token: 0x06001CF8 RID: 7416 RVA: 0x000A3694 File Offset: 0x000A1894
		public static string GetConfigPath()
		{
			return Path.Combine(Manager_path.path_manager, "ApplicationTitle.json");
		}

		// Token: 0x06001CF9 RID: 7417 RVA: 0x000A36B8 File Offset: 0x000A18B8
		public static string Load()
		{
			string result;
			try
			{
				string path = ApplicationTitleStorageService.GetConfigPath();
				bool flag = !File.Exists(path);
				if (flag)
				{
					result = "VISION PRESS MACHINE";
				}
				else
				{
					ApplicationTitleSetting setting = JsonConvert.DeserializeObject<ApplicationTitleSetting>(File.ReadAllText(path));
					result = ApplicationTitleStorageService.Normalize((setting != null) ? setting.Title : null);
				}
			}
			catch
			{
				result = "VISION PRESS MACHINE";
			}
			return result;
		}

		// Token: 0x06001CFA RID: 7418 RVA: 0x000A3720 File Offset: 0x000A1920
		public static string Save(string title)
		{
			string normalized = ApplicationTitleStorageService.Normalize(title);
			string path = ApplicationTitleStorageService.GetConfigPath();
			string folder = Path.GetDirectoryName(path);
			bool flag = !string.IsNullOrWhiteSpace(folder);
			if (flag)
			{
				Directory.CreateDirectory(folder);
			}
			string temporaryPath = path + ".tmp";
			File.WriteAllText(temporaryPath, JsonConvert.SerializeObject(new ApplicationTitleSetting
			{
				Title = normalized
			}, Formatting.Indented));
			bool flag2 = File.Exists(path);
			if (flag2)
			{
				File.Replace(temporaryPath, path, null);
			}
			else
			{
				File.Move(temporaryPath, path);
			}
			return normalized;
		}

		// Token: 0x06001CFB RID: 7419 RVA: 0x000A37A4 File Offset: 0x000A19A4
		private static string Normalize(string title)
		{
			string normalized = (title ?? string.Empty).Trim();
			bool flag = string.IsNullOrWhiteSpace(normalized);
			string result;
			if (flag)
			{
				result = "VISION PRESS MACHINE";
			}
			else
			{
				bool flag2 = normalized.Length > 80;
				if (flag2)
				{
					normalized = normalized.Substring(0, 80).TrimEnd(Array.Empty<char>());
				}
				result = normalized;
			}
			return result;
		}

		// Token: 0x04000C49 RID: 3145
		public const string DefaultTitle = "VISION PRESS MACHINE";
	}
}
