﻿using System;

namespace VisionMachine.Services.Storage
{
	// Token: 0x020001DC RID: 476
	public class ListImageSetting
	{
		// Token: 0x1700090F RID: 2319
		// (get) Token: 0x06001CED RID: 7405 RVA: 0x000A3581 File Offset: 0x000A1781
		// (set) Token: 0x06001CEE RID: 7406 RVA: 0x000A3589 File Offset: 0x000A1789
		public string Folder { get; set; }

		// Token: 0x17000910 RID: 2320
		// (get) Token: 0x06001CEF RID: 7407 RVA: 0x000A3592 File Offset: 0x000A1792
		// (set) Token: 0x06001CF0 RID: 7408 RVA: 0x000A359A File Offset: 0x000A179A
		public string SelectedFileName { get; set; }
	}
}
