﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Services.Storage
{
	// Token: 0x020001DD RID: 477
	public static class ListImageSettingStorageService
	{
		// Token: 0x06001CF2 RID: 7410 RVA: 0x000A35A4 File Offset: 0x000A17A4
		private static string GetPath()
		{
			return Path.Combine(Manager_path.path_manager, "ListImageSetting.json");
		}

		// Token: 0x06001CF3 RID: 7411 RVA: 0x000A35C8 File Offset: 0x000A17C8
		public static void Save(string folder, string selectedFileName)
		{
			try
			{
				string path = ListImageSettingStorageService.GetPath();
				string directory = Path.GetDirectoryName(path);
				bool flag = !string.IsNullOrWhiteSpace(directory);
				if (flag)
				{
					Directory.CreateDirectory(directory);
				}
				ListImageSetting setting = new ListImageSetting
				{
					Folder = folder,
					SelectedFileName = selectedFileName
				};
				File.WriteAllText(path, JsonConvert.SerializeObject(setting, Formatting.Indented));
			}
			catch
			{
			}
		}

		// Token: 0x06001CF4 RID: 7412 RVA: 0x000A3634 File Offset: 0x000A1834
		public static ListImageSetting Load()
		{
			ListImageSetting result;
			try
			{
				string path = ListImageSettingStorageService.GetPath();
				bool flag = !File.Exists(path);
				if (flag)
				{
					result = null;
				}
				else
				{
					result = JsonConvert.DeserializeObject<ListImageSetting>(File.ReadAllText(path));
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}
	}
}
