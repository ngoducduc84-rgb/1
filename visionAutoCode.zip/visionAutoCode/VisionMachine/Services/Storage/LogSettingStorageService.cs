﻿using System;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;
using VisionMachine.Models.Config;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Storage
{
	// Token: 0x020001E0 RID: 480
	public static class LogSettingStorageService
	{
		// Token: 0x06001CFC RID: 7420 RVA: 0x000A37FC File Offset: 0x000A19FC
		public static void Save(string filePath, LogSettingConfig config)
		{
			bool flag = string.IsNullOrWhiteSpace(filePath);
			if (flag)
			{
				throw new ArgumentException("filePath is null or empty.", "filePath");
			}
			string folder = Path.GetDirectoryName(filePath);
			bool flag2 = !string.IsNullOrWhiteSpace(folder) && !Directory.Exists(folder);
			if (flag2)
			{
				Directory.CreateDirectory(folder);
			}
			string json = JsonConvert.SerializeObject(config ?? new LogSettingConfig(), Formatting.Indented);
			File.WriteAllText(filePath, json);
			LogSettingRuntimeStore.Set(config);
			VisionLogFileStore.Configure((config != null) ? config.SavePath : null);
		}

		// Token: 0x06001CFD RID: 7421 RVA: 0x000A387C File Offset: 0x000A1A7C
		public static LogSettingConfig Load(string filePath)
		{
			bool flag = string.IsNullOrWhiteSpace(filePath);
			if (flag)
			{
				throw new ArgumentException("filePath is null or empty.", "filePath");
			}
			bool flag2 = !File.Exists(filePath);
			LogSettingConfig result;
			if (flag2)
			{
				LogSettingConfig empty = new LogSettingConfig();
				LogSettingStorageService.PersistNormalizedConfig(filePath, empty);
				LogSettingRuntimeStore.Set(empty);
				VisionLogFileStore.Configure(empty.SavePath);
				result = empty;
			}
			else
			{
				string json = File.ReadAllText(filePath);
				bool flag3 = string.IsNullOrWhiteSpace(json);
				if (flag3)
				{
					LogSettingConfig empty2 = new LogSettingConfig();
					LogSettingStorageService.PersistNormalizedConfig(filePath, empty2);
					LogSettingRuntimeStore.Set(empty2);
					VisionLogFileStore.Configure(empty2.SavePath);
					result = empty2;
				}
				else
				{
					LogSettingConfig config = JsonConvert.DeserializeObject<LogSettingConfig>(json) ?? new LogSettingConfig();
					bool normalized = false;
					bool flag4 = string.IsNullOrWhiteSpace(config.SavePath);
					if (flag4)
					{
						config.SavePath = Manager_path.path_vision_log;
						normalized = true;
					}
					bool flag5 = string.IsNullOrWhiteSpace(config.FileFormat);
					if (flag5)
					{
						config.FileFormat = "JSONL";
						normalized = true;
					}
					bool flag6 = normalized;
					if (flag6)
					{
						LogSettingStorageService.PersistNormalizedConfig(filePath, config);
					}
					LogSettingRuntimeStore.Set(config);
					VisionLogFileStore.Configure(config.SavePath);
					result = config;
				}
			}
			return result;
		}

		// Token: 0x06001CFE RID: 7422 RVA: 0x000A39A0 File Offset: 0x000A1BA0
		private static void PersistNormalizedConfig(string filePath, LogSettingConfig config)
		{
			string folder = Path.GetDirectoryName(filePath);
			bool flag = !string.IsNullOrWhiteSpace(folder) && !Directory.Exists(folder);
			if (flag)
			{
				Directory.CreateDirectory(folder);
			}
			File.WriteAllText(filePath, JsonConvert.SerializeObject(config ?? new LogSettingConfig(), Formatting.Indented));
		}
	}
}
