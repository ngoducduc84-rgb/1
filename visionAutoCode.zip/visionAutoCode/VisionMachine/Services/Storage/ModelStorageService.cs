﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Runtime;

namespace VisionMachine.Services.Storage
{
	// Token: 0x020001E1 RID: 481
	public static class ModelStorageService
	{
		// Token: 0x06001CFF RID: 7423 RVA: 0x000A39EC File Offset: 0x000A1BEC
		public static void Save(string filePath, IEnumerable<ModelConfig> models, ModelConfig currentModel)
		{
			bool flag = string.IsNullOrWhiteSpace(filePath);
			if (flag)
			{
				throw new ArgumentException("filePath is null");
			}
			string folder = Path.GetDirectoryName(filePath);
			bool flag2 = !string.IsNullOrWhiteSpace(folder) && !Directory.Exists(folder);
			if (flag2)
			{
				Directory.CreateDirectory(folder);
			}
			ModelFileData data = new ModelFileData
			{
				Models = (((models != null) ? models.ToList<ModelConfig>() : null) ?? new List<ModelConfig>()),
				CurrentModelId = ((currentModel != null) ? new Guid?(currentModel.Id) : null)
			};
			string json = JsonConvert.SerializeObject(data, Formatting.Indented);
			File.WriteAllText(filePath, json);
			ModelRuntimeStore.SetModels(data.Models);
			ModelRuntimeStore.SetCurrentModel(currentModel);
		}

		// Token: 0x06001D00 RID: 7424 RVA: 0x000A3AA0 File Offset: 0x000A1CA0
		public static List<ModelConfig> Load(string filePath)
		{
			bool flag = !File.Exists(filePath);
			List<ModelConfig> result;
			if (flag)
			{
				ModelRuntimeStore.SetModels(new List<ModelConfig>());
				ModelRuntimeStore.ClearCurrentModel();
				result = new List<ModelConfig>();
			}
			else
			{
				string json = File.ReadAllText(filePath);
				bool flag2 = string.IsNullOrWhiteSpace(json);
				if (flag2)
				{
					ModelRuntimeStore.SetModels(new List<ModelConfig>());
					ModelRuntimeStore.ClearCurrentModel();
					result = new List<ModelConfig>();
				}
				else
				{
					ModelFileData data = JsonConvert.DeserializeObject<ModelFileData>(json) ?? new ModelFileData();
					ModelRuntimeStore.SetModels(data.Models);
					bool flag3 = data.CurrentModelId != null;
					if (flag3)
					{
						ModelConfig current = data.Models.FirstOrDefault((ModelConfig x) => x.Id == data.CurrentModelId);
						ModelRuntimeStore.SetCurrentModel(current);
					}
					else
					{
						ModelRuntimeStore.ClearCurrentModel();
					}
					result = data.Models;
				}
			}
			return result;
		}
	}
}
