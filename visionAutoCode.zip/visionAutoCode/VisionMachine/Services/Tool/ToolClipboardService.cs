﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using Newtonsoft.Json;
using VisionMachine.Helpers;
using VisionMachine.Models.Recipe;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Roi;
using VisionMachine.Services.Runtime;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.DeformableInspection;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ProductCountInspection;
using VisionMachine.VisionTools.ShapeModel;
using VisionMachine.VisionTools.VariationChangeWD;

namespace VisionMachine.Services.Tool
{
	// Token: 0x0200026C RID: 620
	public static class ToolClipboardService
	{
		// Token: 0x170009E7 RID: 2535
		// (get) Token: 0x06002279 RID: 8825 RVA: 0x000D1F4B File Offset: 0x000D014B
		// (set) Token: 0x0600227A RID: 8826 RVA: 0x000D1F52 File Offset: 0x000D0152
		public static ToolVision Copied { get; private set; }

		// Token: 0x170009E8 RID: 2536
		// (get) Token: 0x0600227B RID: 8827 RVA: 0x000D1F5A File Offset: 0x000D015A
		public static bool HasCopy
		{
			get
			{
				return ToolClipboardService.Copied != null;
			}
		}

		// Token: 0x170009E9 RID: 2537
		// (get) Token: 0x0600227C RID: 8828 RVA: 0x000D1F64 File Offset: 0x000D0164
		// (set) Token: 0x0600227D RID: 8829 RVA: 0x000D1F6B File Offset: 0x000D016B
		public static TurnSnap CopiedTurnSnap { get; private set; }

		// Token: 0x170009EA RID: 2538
		// (get) Token: 0x0600227E RID: 8830 RVA: 0x000D1F73 File Offset: 0x000D0173
		public static bool HasCopiedTurnSnap
		{
			get
			{
				return ToolClipboardService.CopiedTurnSnap != null;
			}
		}

		// Token: 0x0600227F RID: 8831 RVA: 0x000D1F7D File Offset: 0x000D017D
		public static void Copy(ToolVision tool)
		{
			ToolClipboardService.Copied = tool;
		}

		// Token: 0x06002280 RID: 8832 RVA: 0x000D1F87 File Offset: 0x000D0187
		public static void Clear()
		{
			ToolClipboardService.Copied = null;
		}

		// Token: 0x06002281 RID: 8833 RVA: 0x000D1F91 File Offset: 0x000D0191
		public static void CopyTurnSnap(TurnSnap turnSnap)
		{
			ToolClipboardService.CopiedTurnSnap = turnSnap;
		}

		// Token: 0x170009EB RID: 2539
		// (get) Token: 0x06002282 RID: 8834 RVA: 0x000D1F9B File Offset: 0x000D019B
		// (set) Token: 0x06002283 RID: 8835 RVA: 0x000D1FA2 File Offset: 0x000D01A2
		public static TurnSnap CopiedImageTurnSnap { get; private set; }

		// Token: 0x170009EC RID: 2540
		// (get) Token: 0x06002284 RID: 8836 RVA: 0x000D1FAA File Offset: 0x000D01AA
		public static bool HasCopiedImage
		{
			get
			{
				return ToolClipboardService.CopiedImageTurnSnap != null;
			}
		}

		// Token: 0x06002285 RID: 8837 RVA: 0x000D1FB4 File Offset: 0x000D01B4
		public static void CopyImage(TurnSnap turnSnap)
		{
			ToolClipboardService.CopiedImageTurnSnap = turnSnap;
		}

		// Token: 0x06002286 RID: 8838 RVA: 0x000D1FC0 File Offset: 0x000D01C0
		public static bool CanPasteImageInto(TurnSnap target)
		{
			return ToolClipboardService.CopiedImageTurnSnap != null && target != null && ToolClipboardService.CopiedImageTurnSnap != target;
		}

		// Token: 0x06002287 RID: 8839 RVA: 0x000D1FEC File Offset: 0x000D01EC
		public static bool PasteImageInto(TurnSnap target, TurnSnap source)
		{
			bool flag = target == null;
			if (flag)
			{
				throw new ArgumentNullException("target");
			}
			bool flag2 = source == null;
			if (flag2)
			{
				throw new ArgumentNullException("source");
			}
			bool flag3 = target == source;
			bool result;
			if (flag3)
			{
				result = false;
			}
			else
			{
				string srcFolder = ToolClipboardService.GetTurnSnapFolder(source);
				string dstFolder = ToolClipboardService.GetTurnSnapFolder(target);
				bool flag4 = string.IsNullOrWhiteSpace(srcFolder) || string.IsNullOrWhiteSpace(dstFolder);
				if (flag4)
				{
					result = false;
				}
				else
				{
					string srcPath = Path.Combine(srcFolder, "master.bmp");
					string dstPath = Path.Combine(dstFolder, "master.bmp");
					bool flag5 = !File.Exists(srcPath);
					if (flag5)
					{
						result = false;
					}
					else
					{
						Directory.CreateDirectory(dstFolder);
						File.Copy(srcPath, dstPath, true);
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x06002288 RID: 8840 RVA: 0x000D20A0 File Offset: 0x000D02A0
		public static bool CanPasteTurnSnapInto(TurnSnap target)
		{
			return ToolClipboardService.CopiedTurnSnap != null && target != null && ToolClipboardService.CopiedTurnSnap != target;
		}

		// Token: 0x06002289 RID: 8841 RVA: 0x000D20CC File Offset: 0x000D02CC
		public static void PasteTurnSnapInto(TurnSnap target, TurnSnap source)
		{
			bool flag = target == null;
			if (flag)
			{
				throw new ArgumentNullException("target");
			}
			bool flag2 = source == null;
			if (flag2)
			{
				throw new ArgumentNullException("source");
			}
			bool flag3 = target == source;
			if (!flag3)
			{
				target.Tools.Clear();
				int index = 1;
				foreach (ToolVision srcTool in source.Tools)
				{
					bool flag4 = srcTool == null;
					if (!flag4)
					{
						ToolVision newTool = new ToolVision
						{
							Name = srcTool.Name,
							ToolType = srcTool.ToolType,
							Index = index++,
							ParentTurnSnap = target,
							Icon = srcTool.Icon,
							Config = ToolClipboardService.CloneAs<ToolConfigBase>(srcTool.Config),
							Spec = ToolClipboardService.CloneAs<ToolSpecBase>(srcTool.Spec),
							TrainModel = ToolClipboardService.CloneAs<ToolTrainBase>(srcTool.TrainModel)
						};
						ToolClipboardService.CloneRoiInto(srcTool, newTool, srcTool.RoiItems, newTool.RoiItems);
						ToolClipboardService.CloneRoiInto(srcTool, newTool, srcTool.LimitRoiItems, newTool.LimitRoiItems);
						ToolClipboardService.CloneRoiInto(srcTool, newTool, srcTool.MaskRoiItems, newTool.MaskRoiItems);
						ToolClipboardService.CopyModelFile(srcTool, newTool);
						ShapeModelRuntimeCache.ClearByTool(newTool.ToolId);
						target.Tools.Add(newTool);
					}
				}
			}
		}

		// Token: 0x0600228A RID: 8842 RVA: 0x000D226C File Offset: 0x000D046C
		public static bool CanPasteInto(ToolVision target)
		{
			return ToolClipboardService.Copied != null && target != null && ToolClipboardService.Copied != target && ToolClipboardService.Copied.ToolType == target.ToolType;
		}

		// Token: 0x0600228B RID: 8843 RVA: 0x000D22A8 File Offset: 0x000D04A8
		public static void PasteInto(ToolVision target, ToolVision source)
		{
			bool flag = target == null;
			if (flag)
			{
				throw new ArgumentNullException("target");
			}
			bool flag2 = source == null;
			if (flag2)
			{
				throw new ArgumentNullException("source");
			}
			bool flag3 = target.ToolType != source.ToolType;
			if (flag3)
			{
				throw new InvalidOperationException("Cannot paste: the copied tool and the selected tool are different types.");
			}
			bool flag4 = target == source;
			if (!flag4)
			{
				target.Config = ToolClipboardService.CloneAs<ToolConfigBase>(source.Config);
				target.Spec = ToolClipboardService.CloneAs<ToolSpecBase>(source.Spec);
				target.TrainModel = ToolClipboardService.CloneAs<ToolTrainBase>(source.TrainModel);
				ToolClipboardService.CloneRoiInto(source, target, source.RoiItems, target.RoiItems);
				ToolClipboardService.CloneRoiInto(source, target, source.LimitRoiItems, target.LimitRoiItems);
				ToolClipboardService.CloneRoiInto(source, target, source.MaskRoiItems, target.MaskRoiItems);
				ToolClipboardService.CopyModelFile(source, target);
				ShapeModelRuntimeCache.ClearByTool(target.ToolId);
			}
		}

		// Token: 0x0600228C RID: 8844 RVA: 0x000D2390 File Offset: 0x000D0590
		private static T CloneAs<T>(T obj) where T : class
		{
			bool flag = obj == null;
			T result;
			if (flag)
			{
				result = default(T);
			}
			else
			{
				string json = JsonConvert.SerializeObject(obj, typeof(T), Formatting.None, ToolClipboardService.JsonSettings);
				result = (T)((object)JsonConvert.DeserializeObject(json, typeof(T), ToolClipboardService.JsonSettings));
			}
			return result;
		}

		// Token: 0x0600228D RID: 8845 RVA: 0x000D23F4 File Offset: 0x000D05F4
		private static void CloneRoiInto(ToolVision sourceTool, ToolVision targetTool, ObservableCollection<RoiData> source, ObservableCollection<RoiData> target)
		{
			bool flag = target == null;
			if (!flag)
			{
				target.Clear();
				bool flag2 = source == null;
				if (!flag2)
				{
					foreach (RoiData roi in source)
					{
						RoiData clone = ToolClipboardService.CloneAs<RoiData>(roi);
						bool flag3 = clone == null;
						if (!flag3)
						{
							clone.IsSelected = false;
							ToolClipboardService.CopyCustomRoiRegion(sourceTool, targetTool, roi, clone);
							target.Add(clone);
						}
					}
				}
			}
		}

		// Token: 0x0600228E RID: 8846 RVA: 0x000D2488 File Offset: 0x000D0688
		private static void CopyCustomRoiRegion(ToolVision sourceTool, ToolVision targetTool, RoiData sourceRoi, RoiData targetRoi)
		{
			bool flag = targetRoi == null || sourceRoi == null;
			if (!flag)
			{
				bool flag2 = sourceRoi.RoiType != RoiType.CustomPaint;
				if (!flag2)
				{
					bool flag3 = string.IsNullOrWhiteSpace(sourceRoi.CustomRegionFile);
					if (!flag3)
					{
						string srcFolder = ToolClipboardService.GetTurnSnapFolder((sourceTool != null) ? sourceTool.ParentTurnSnap : null);
						string dstFolder = ToolClipboardService.GetTurnSnapFolder((targetTool != null) ? targetTool.ParentTurnSnap : null);
						bool flag4 = string.IsNullOrWhiteSpace(srcFolder) || string.IsNullOrWhiteSpace(dstFolder);
						if (flag4)
						{
							targetRoi.CustomRegionFile = null;
						}
						else
						{
							string sourcePath = Path.Combine(srcFolder, sourceRoi.CustomRegionFile);
							bool flag5 = !File.Exists(sourcePath);
							if (flag5)
							{
								targetRoi.CustomRegionFile = null;
							}
							else
							{
								string fileName = CustomRoiRegionStore.BuildFileName(targetRoi.Name);
								string destinationPath = Path.Combine(dstFolder, fileName);
								try
								{
									ToolClipboardService.CopyFile(sourcePath, destinationPath);
									targetRoi.CustomRegionFile = fileName;
									CustomRoiRegionStore.Invalidate(destinationPath);
								}
								catch
								{
									targetRoi.CustomRegionFile = null;
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x0600228F RID: 8847 RVA: 0x000D2598 File Offset: 0x000D0798
		private static void CopyModelFile(ToolVision source, ToolVision target)
		{
			string srcFolder = ToolClipboardService.GetTurnSnapFolder(source.ParentTurnSnap);
			string dstFolder = ToolClipboardService.GetTurnSnapFolder(target.ParentTurnSnap);
			bool flag = string.IsNullOrWhiteSpace(srcFolder) || string.IsNullOrWhiteSpace(dstFolder);
			if (!flag)
			{
				ToolType toolType = target.ToolType;
				ToolType toolType2 = toolType;
				switch (toolType2)
				{
				case ToolType.Shape_model:
				{
					SettingShapeModelPathService ps = new SettingShapeModelPathService();
					ToolClipboardService.CopyFile(ps.GetShapeModelFullPath(srcFolder, source), ps.GetShapeModelFullPath(dstFolder, target));
					ShapeModelToolTrain train = target.TrainModel as ShapeModelToolTrain;
					bool flag2 = train != null;
					if (flag2)
					{
						train.ShapeModelFileName = ps.GetShapeModelFileName(target);
						train.ShapeModelRelativePath = ps.GetShapeModelRelativePath(target);
					}
					break;
				}
				case ToolType.AnisoShapeModel:
				{
					AnisoShapeModelPathService ps2 = new AnisoShapeModelPathService();
					ToolClipboardService.CopyFile(ps2.GetShapeModelFullPath(srcFolder, source), ps2.GetShapeModelFullPath(dstFolder, target));
					ShapeModelToolTrain train2 = target.TrainModel as ShapeModelToolTrain;
					bool flag3 = train2 != null;
					if (flag3)
					{
						train2.ShapeModelFileName = ps2.GetShapeModelFileName(target);
						train2.ShapeModelRelativePath = ps2.GetShapeModelRelativePath(target);
					}
					break;
				}
				case ToolType.OverlappingShapeModel:
				{
					OverlappingShapeModelPathService ps3 = new OverlappingShapeModelPathService();
					ToolClipboardService.CopyFile(ps3.GetShapeModelFullPath(srcFolder, source), ps3.GetShapeModelFullPath(dstFolder, target));
					ToolClipboardService.CopyFile(ps3.GetMasterRegionPath(srcFolder, source), ps3.GetMasterRegionPath(dstFolder, target));
					ToolClipboardService.CopyFile(ps3.GetMasterPrintPath(srcFolder, source), ps3.GetMasterPrintPath(dstFolder, target));
					ToolClipboardService.CopyFile(ps3.GetMasterImagePath(srcFolder, source), ps3.GetMasterImagePath(dstFolder, target));
					ToolClipboardService.CopyFile(ps3.GetMasterImagePath(srcFolder, source) + ".domain.reg", ps3.GetMasterImagePath(dstFolder, target) + ".domain.reg");
					ShapeModelToolTrain train3 = target.TrainModel as ShapeModelToolTrain;
					bool flag4 = train3 != null;
					if (flag4)
					{
						train3.ShapeModelFileName = ps3.GetShapeModelFileName(target);
						train3.ShapeModelRelativePath = ps3.GetShapeModelRelativePath(target);
					}
					break;
				}
				default:
					switch (toolType2)
					{
					case ToolType.DeformableInspection:
					{
						DeformableInspectionPathService ps4 = new DeformableInspectionPathService();
						ToolClipboardService.CopyFile(ps4.GetModelFullPath(srcFolder, source), ps4.GetModelFullPath(dstFolder, target));
						DeformableInspectionToolTrain train4 = target.TrainModel as DeformableInspectionToolTrain;
						bool flag5 = train4 != null;
						if (flag5)
						{
							train4.ModelRelativePath = ps4.GetModelRelativePath(target);
						}
						break;
					}
					case ToolType.VariationChangeWD:
					{
						VariationChangeWDPathService ps5 = new VariationChangeWDPathService();
						ToolClipboardService.CopyFile(ps5.GetVariationModelFullPath(srcFolder, source), ps5.GetVariationModelFullPath(dstFolder, target));
						ToolClipboardService.CopyFile(ps5.GetInspectRegionFullPath(srcFolder, source), ps5.GetInspectRegionFullPath(dstFolder, target));
						ToolClipboardService.CopyFile(ps5.GetMasterWorkImageFullPath(srcFolder, source), ps5.GetMasterWorkImageFullPath(dstFolder, target));
						string targetSamples = ps5.GetSampleFolder(dstFolder, target);
						foreach (string sample in ps5.GetSampleFiles(srcFolder, source))
						{
							ToolClipboardService.CopyFile(sample, Path.Combine(targetSamples, Path.GetFileName(sample)));
						}
						break;
					}
					case ToolType.ProductCountInspection:
					{
						ProductCountInspectionPathService ps6 = new ProductCountInspectionPathService();
						ToolClipboardService.CopyFile(ps6.GetShapeModelFullPath(srcFolder, source), ps6.GetShapeModelFullPath(dstFolder, target));
						ToolClipboardService.CopyFile(ps6.GetGoldenImageFullPath(srcFolder, source), ps6.GetGoldenImageFullPath(dstFolder, target));
						ToolClipboardService.CopyFile(ps6.GetTrainRegionFullPath(srcFolder, source), ps6.GetTrainRegionFullPath(dstFolder, target));
						ToolClipboardService.CopyFile(ps6.GetVariationModelFullPath(srcFolder, source), ps6.GetVariationModelFullPath(dstFolder, target));
						break;
					}
					}
					break;
				}
			}
		}

		// Token: 0x06002290 RID: 8848 RVA: 0x000D2904 File Offset: 0x000D0B04
		private static string GetTurnSnapFolder(TurnSnap turnSnap)
		{
			bool flag = ((turnSnap != null) ? turnSnap.ParentCamera : null) == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				ModelConfig model = ModelRuntimeStore.CurrentModel;
				bool flag2 = model == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					string rootPath = Manager_path._dataPath;
					bool flag3 = string.IsNullOrWhiteSpace(rootPath);
					if (flag3)
					{
						result = null;
					}
					else
					{
						string modelName = RecipePathService.MakeSafeFileName(model.Model_name);
						string cameraName = RecipePathService.MakeSafeFileName(turnSnap.ParentCamera.Name);
						string turnSnapName = "TurnSnap_" + turnSnap.Index.ToString();
						result = Path.Combine(rootPath, modelName, cameraName, turnSnapName);
					}
				}
			}
			return result;
		}

		// Token: 0x06002291 RID: 8849 RVA: 0x000D29A0 File Offset: 0x000D0BA0
		private static void CopyFile(string sourcePath, string destinationPath)
		{
			bool flag = string.IsNullOrWhiteSpace(sourcePath) || string.IsNullOrWhiteSpace(destinationPath);
			if (!flag)
			{
				bool flag2 = !File.Exists(sourcePath);
				if (!flag2)
				{
					bool flag3 = string.Equals(sourcePath, destinationPath, StringComparison.OrdinalIgnoreCase);
					if (!flag3)
					{
						string dir = Path.GetDirectoryName(destinationPath);
						bool flag4 = !string.IsNullOrWhiteSpace(dir);
						if (flag4)
						{
							Directory.CreateDirectory(dir);
						}
						File.Copy(sourcePath, destinationPath, true);
					}
				}
			}
		}

		// Token: 0x04000E3C RID: 3644
		private static readonly JsonSerializerSettings JsonSettings = new JsonSerializerSettings
		{
			TypeNameHandling = TypeNameHandling.Auto
		};
	}
}
