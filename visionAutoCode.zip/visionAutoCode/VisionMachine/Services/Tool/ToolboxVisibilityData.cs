﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Services.Tool
{
	// Token: 0x0200026D RID: 621
	public class ToolboxVisibilityData
	{
		// Token: 0x170009ED RID: 2541
		// (get) Token: 0x06002293 RID: 8851 RVA: 0x000D2A1C File Offset: 0x000D0C1C
		// (set) Token: 0x06002294 RID: 8852 RVA: 0x000D2A24 File Offset: 0x000D0C24
		public List<string> HiddenTools { get; set; } = new List<string>();
	}
}
