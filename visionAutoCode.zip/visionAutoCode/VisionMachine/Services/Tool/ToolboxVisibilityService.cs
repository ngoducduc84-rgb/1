﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using VisionMachine.Helpers;

namespace VisionMachine.Services.Tool
{
	// Token: 0x0200026E RID: 622
	public static class ToolboxVisibilityService
	{
		// Token: 0x06002296 RID: 8854 RVA: 0x000D2A44 File Offset: 0x000D0C44
		public static string GetConfigPath()
		{
			return Manager_path._toolboxVisibilityJsonPath;
		}

		// Token: 0x06002297 RID: 8855 RVA: 0x000D2A5C File Offset: 0x000D0C5C
		public static bool IsHidden(string toolName)
		{
			bool flag = string.IsNullOrWhiteSpace(toolName);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				object syncRoot = ToolboxVisibilityService.SyncRoot;
				lock (syncRoot)
				{
					ToolboxVisibilityService.EnsureLoadedLocked();
					result = ToolboxVisibilityService._hidden.Contains(toolName.Trim());
				}
			}
			return result;
		}

		// Token: 0x06002298 RID: 8856 RVA: 0x000D2AC0 File Offset: 0x000D0CC0
		public static HashSet<string> GetHidden()
		{
			object syncRoot = ToolboxVisibilityService.SyncRoot;
			HashSet<string> result;
			lock (syncRoot)
			{
				ToolboxVisibilityService.EnsureLoadedLocked();
				result = new HashSet<string>(ToolboxVisibilityService._hidden, StringComparer.OrdinalIgnoreCase);
			}
			return result;
		}

		// Token: 0x06002299 RID: 8857 RVA: 0x000D2B14 File Offset: 0x000D0D14
		public static string Save(IEnumerable<string> hiddenToolNames)
		{
			HashSet<string> hidden = new HashSet<string>(from x in hiddenToolNames ?? Enumerable.Empty<string>()
			where !string.IsNullOrWhiteSpace(x)
			select x.Trim(), StringComparer.OrdinalIgnoreCase);
			string result;
			try
			{
				string path = ToolboxVisibilityService.GetConfigPath();
				string folder = Path.GetDirectoryName(path);
				bool flag = !string.IsNullOrWhiteSpace(folder);
				if (flag)
				{
					Directory.CreateDirectory(folder);
				}
				ToolboxVisibilityData toolboxVisibilityData = new ToolboxVisibilityData();
				toolboxVisibilityData.HiddenTools = hidden.OrderBy((string x) => x, StringComparer.OrdinalIgnoreCase).ToList<string>();
				ToolboxVisibilityData data = toolboxVisibilityData;
				File.WriteAllText(path, JsonConvert.SerializeObject(data, Formatting.Indented));
				object syncRoot = ToolboxVisibilityService.SyncRoot;
				lock (syncRoot)
				{
					ToolboxVisibilityService._hidden = hidden;
				}
				result = null;
			}
			catch (Exception ex)
			{
				result = ex.Message;
			}
			return result;
		}

		// Token: 0x0600229A RID: 8858 RVA: 0x000D2C48 File Offset: 0x000D0E48
		public static void Invalidate()
		{
			object syncRoot = ToolboxVisibilityService.SyncRoot;
			lock (syncRoot)
			{
				ToolboxVisibilityService._hidden = null;
			}
		}

		// Token: 0x0600229B RID: 8859 RVA: 0x000D2C8C File Offset: 0x000D0E8C
		private static void EnsureLoadedLocked()
		{
			bool flag = ToolboxVisibilityService._hidden != null;
			if (!flag)
			{
				ToolboxVisibilityService._hidden = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
				try
				{
					string path = ToolboxVisibilityService.GetConfigPath();
					bool flag2 = !File.Exists(path);
					if (!flag2)
					{
						ToolboxVisibilityData data = JsonConvert.DeserializeObject<ToolboxVisibilityData>(File.ReadAllText(path));
						foreach (string name in (((data != null) ? data.HiddenTools : null) ?? new List<string>()))
						{
							bool flag3 = !string.IsNullOrWhiteSpace(name);
							if (flag3)
							{
								ToolboxVisibilityService._hidden.Add(name.Trim());
							}
						}
					}
				}
				catch
				{
					ToolboxVisibilityService._hidden = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
				}
			}
		}

		// Token: 0x04000E41 RID: 3649
		private static readonly object SyncRoot = new object();

		// Token: 0x04000E42 RID: 3650
		private static HashSet<string> _hidden;
	}
}
