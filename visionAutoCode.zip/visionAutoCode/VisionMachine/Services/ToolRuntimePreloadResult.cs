﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Services
{
	// Token: 0x020001D8 RID: 472
	public sealed class ToolRuntimePreloadResult
	{
		// Token: 0x17000908 RID: 2312
		// (get) Token: 0x06001CC4 RID: 7364 RVA: 0x000A223A File Offset: 0x000A043A
		// (set) Token: 0x06001CC5 RID: 7365 RVA: 0x000A2242 File Offset: 0x000A0442
		public int ShapeModelCount { get; set; }

		// Token: 0x17000909 RID: 2313
		// (get) Token: 0x06001CC6 RID: 7366 RVA: 0x000A224B File Offset: 0x000A044B
		// (set) Token: 0x06001CC7 RID: 7367 RVA: 0x000A2253 File Offset: 0x000A0453
		public int AnisoShapeModelCount { get; set; }

		// Token: 0x1700090A RID: 2314
		// (get) Token: 0x06001CC8 RID: 7368 RVA: 0x000A225C File Offset: 0x000A045C
		// (set) Token: 0x06001CC9 RID: 7369 RVA: 0x000A2264 File Offset: 0x000A0464
		public int OverlappingShapeModelCount { get; set; }

		// Token: 0x1700090B RID: 2315
		// (get) Token: 0x06001CCA RID: 7370 RVA: 0x000A226D File Offset: 0x000A046D
		// (set) Token: 0x06001CCB RID: 7371 RVA: 0x000A2275 File Offset: 0x000A0475
		public int CalibHandEyeCount { get; set; }

		// Token: 0x1700090C RID: 2316
		// (get) Token: 0x06001CCC RID: 7372 RVA: 0x000A227E File Offset: 0x000A047E
		// (set) Token: 0x06001CCD RID: 7373 RVA: 0x000A2286 File Offset: 0x000A0486
		public int ProcedureModelCount { get; set; }

		// Token: 0x1700090D RID: 2317
		// (get) Token: 0x06001CCE RID: 7374 RVA: 0x000A228F File Offset: 0x000A048F
		public List<string> Errors { get; } = new List<string>();

		// Token: 0x1700090E RID: 2318
		// (get) Token: 0x06001CCF RID: 7375 RVA: 0x000A2298 File Offset: 0x000A0498
		public int TotalCount
		{
			get
			{
				return this.ShapeModelCount + this.AnisoShapeModelCount + this.OverlappingShapeModelCount + this.CalibHandEyeCount + this.ProcedureModelCount;
			}
		}
	}
}
