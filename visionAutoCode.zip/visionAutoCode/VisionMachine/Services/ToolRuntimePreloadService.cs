﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Tool;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.CalibHandEye;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ProcedureModel;
using VisionMachine.VisionTools.Procedures;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.Services
{
	// Token: 0x020001D9 RID: 473
	public static class ToolRuntimePreloadService
	{
		// Token: 0x06001CD1 RID: 7377 RVA: 0x000A22E0 File Offset: 0x000A04E0
		public static ToolRuntimePreloadResult PreloadFromCameras(IEnumerable<CameraNode> cameras)
		{
			ToolRuntimePreloadResult result = new ToolRuntimePreloadResult();
			bool flag = cameras == null;
			ToolRuntimePreloadResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				try
				{
					result.CalibHandEyeCount = CalibHandEyeCalibrationCache.PreloadFromCameras(cameras);
				}
				catch (Exception ex)
				{
					result.Errors.Add("Calib Hand-Eye preload failed: " + ex.Message);
				}
				foreach (CameraNode camera in cameras)
				{
					bool flag2 = ((camera != null) ? camera.TurnSnaps : null) == null;
					if (!flag2)
					{
						foreach (TurnSnap turnSnap in camera.TurnSnaps)
						{
							bool flag3 = ((turnSnap != null) ? turnSnap.Tools : null) == null;
							if (!flag3)
							{
								foreach (ToolVision tool in turnSnap.Tools)
								{
									ToolRuntimePreloadService.PreloadTool(tool, result);
								}
							}
						}
					}
				}
				bool flag4 = result.Errors.Count > 0;
				if (flag4)
				{
					foreach (string error in result.Errors)
					{
						Debug.WriteLine("[ToolRuntimePreload] " + error);
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06001CD2 RID: 7378 RVA: 0x000A24B0 File Offset: 0x000A06B0
		private static void PreloadTool(ToolVision tool, ToolRuntimePreloadResult result)
		{
			bool flag = tool == null;
			if (!flag)
			{
				try
				{
					bool flag2 = tool.ToolType == ToolType.ProcedureModel;
					if (flag2)
					{
						ToolRuntimePreloadService.PreloadProcedureModel(tool, result);
					}
					else
					{
						bool flag3 = tool.ParentTurnSnap == null || tool.TrainModel == null;
						if (!flag3)
						{
							bool flag4 = tool.ToolType == ToolType.Shape_model;
							if (flag4)
							{
								ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
								bool flag5 = train == null || !train.IsTrained;
								if (!flag5)
								{
									string path = ToolRuntimePreloadService.ResolveShapeModelPath(tool);
									bool flag6 = ToolRuntimePreloadService.PreloadShapeModelHandle(tool, path);
									if (flag6)
									{
										int num = result.ShapeModelCount;
										result.ShapeModelCount = num + 1;
									}
								}
							}
							else
							{
								bool flag7 = tool.ToolType == ToolType.AnisoShapeModel;
								if (flag7)
								{
									ShapeModelToolTrain train2 = tool.TrainModel as ShapeModelToolTrain;
									bool flag8 = train2 == null || !train2.IsTrained;
									if (!flag8)
									{
										string path2 = ToolRuntimePreloadService.ResolveAnisoShapeModelPath(tool);
										bool flag9 = ToolRuntimePreloadService.PreloadShapeModelHandle(tool, path2);
										if (flag9)
										{
											int num = result.AnisoShapeModelCount;
											result.AnisoShapeModelCount = num + 1;
										}
									}
								}
								else
								{
									bool flag10 = tool.ToolType == ToolType.OverlappingShapeModel;
									if (flag10)
									{
										ShapeModelToolTrain train3 = tool.TrainModel as ShapeModelToolTrain;
										bool flag11 = train3 == null || !train3.IsTrained;
										if (!flag11)
										{
											string path3 = ToolRuntimePreloadService.ResolveOverlappingShapeModelPath(tool);
											bool flag12 = ToolRuntimePreloadService.PreloadShapeModelHandle(tool, path3);
											if (flag12)
											{
												int num = result.OverlappingShapeModelCount;
												result.OverlappingShapeModelCount = num + 1;
											}
										}
									}
								}
							}
						}
					}
				}
				catch (Exception ex)
				{
					result.Errors.Add((tool.Name ?? tool.ToolType.ToString()) + " preload failed: " + ex.Message);
				}
			}
		}

		// Token: 0x06001CD3 RID: 7379 RVA: 0x000A269C File Offset: 0x000A089C
		private static void PreloadProcedureModel(ToolVision tool, ToolRuntimePreloadResult result)
		{
			ProcedureModelToolConfig config = tool.Config as ProcedureModelToolConfig;
			bool flag = config == null || string.IsNullOrWhiteSpace(config.ProgramPath);
			if (!flag)
			{
				bool flag2 = !File.Exists(config.ProgramPath);
				if (flag2)
				{
					result.Errors.Add((tool.Name ?? "Procedure Model") + " preload skipped; procedure file was not found: " + config.ProgramPath);
				}
				else
				{
					HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
					bool flag3 = !string.IsNullOrWhiteSpace(config.TrainProcedureName);
					if (flag3)
					{
						names.Add(config.TrainProcedureName);
					}
					bool flag4 = !string.IsNullOrWhiteSpace(config.FindProcedureName);
					if (flag4)
					{
						names.Add(config.FindProcedureName);
					}
					bool flag5 = names.Count == 0;
					if (!flag5)
					{
						bool loaded = false;
						foreach (string procedureName in names)
						{
							string error;
							HDevProcedureSignature signature = HDevProcedureRuntime.GetSignature(config.ProgramPath, procedureName, out error);
							bool flag6 = signature != null;
							if (flag6)
							{
								loaded = true;
							}
							else
							{
								result.Errors.Add(string.Concat(new string[]
								{
									tool.Name ?? "Procedure Model",
									" procedure '",
									procedureName,
									"' preload failed: ",
									string.IsNullOrWhiteSpace(error) ? "Unknown error." : error
								}));
							}
						}
						bool flag7 = loaded;
						if (flag7)
						{
							int procedureModelCount = result.ProcedureModelCount;
							result.ProcedureModelCount = procedureModelCount + 1;
						}
					}
				}
			}
		}

		// Token: 0x06001CD4 RID: 7380 RVA: 0x000A284C File Offset: 0x000A0A4C
		private static bool PreloadShapeModelHandle(ToolVision tool, string modelPath)
		{
			bool flag = string.IsNullOrWhiteSpace(modelPath) || !File.Exists(modelPath);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				ShapeModelRuntimeCache.GetOrLoad(tool.ToolId, modelPath);
				result = true;
			}
			return result;
		}

		// Token: 0x06001CD5 RID: 7381 RVA: 0x000A288C File Offset: 0x000A0A8C
		private static string ResolveShapeModelPath(ToolVision tool)
		{
			string turnSnapFolder = ToolRuntimePreloadService.MasterImageService.GetTurnSnapFolder(tool.ParentTurnSnap);
			bool flag = string.IsNullOrWhiteSpace(turnSnapFolder);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = ToolRuntimePreloadService.ShapePathService.GetShapeModelFullPath(turnSnapFolder, tool);
			}
			return result;
		}

		// Token: 0x06001CD6 RID: 7382 RVA: 0x000A28CC File Offset: 0x000A0ACC
		private static string ResolveAnisoShapeModelPath(ToolVision tool)
		{
			string turnSnapFolder = ToolRuntimePreloadService.MasterImageService.GetTurnSnapFolder(tool.ParentTurnSnap);
			bool flag = string.IsNullOrWhiteSpace(turnSnapFolder);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = ToolRuntimePreloadService.AnisoPathService.GetShapeModelFullPath(turnSnapFolder, tool);
			}
			return result;
		}

		// Token: 0x06001CD7 RID: 7383 RVA: 0x000A290C File Offset: 0x000A0B0C
		private static string ResolveOverlappingShapeModelPath(ToolVision tool)
		{
			string turnSnapFolder = ToolRuntimePreloadService.MasterImageService.GetTurnSnapFolder(tool.ParentTurnSnap);
			bool flag = string.IsNullOrWhiteSpace(turnSnapFolder);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = ToolRuntimePreloadService.OverlappingPathService.GetShapeModelFullPath(turnSnapFolder, tool);
			}
			return result;
		}

		// Token: 0x04000C3F RID: 3135
		private static readonly SettingMasterImageService MasterImageService = new SettingMasterImageService();

		// Token: 0x04000C40 RID: 3136
		private static readonly SettingShapeModelPathService ShapePathService = new SettingShapeModelPathService();

		// Token: 0x04000C41 RID: 3137
		private static readonly AnisoShapeModelPathService AnisoPathService = new AnisoShapeModelPathService();

		// Token: 0x04000C42 RID: 3138
		private static readonly OverlappingShapeModelPathService OverlappingPathService = new OverlappingShapeModelPathService();
	}
}
