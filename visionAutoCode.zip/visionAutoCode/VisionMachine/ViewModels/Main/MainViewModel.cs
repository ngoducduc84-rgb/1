﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using DevExpress.Mvvm;
using DevExpress.Xpf.Core;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Light;
using VisionMachine.Models.Recipe;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Light;
using VisionMachine.Services.Runtime;
using VisionMachine.Services.Tool;

namespace VisionMachine.ViewModels.Main
{
	// Token: 0x02000198 RID: 408
	public class MainViewModel : ViewModelBase
	{
		// Token: 0x1700077A RID: 1914
		// (get) Token: 0x06001501 RID: 5377 RVA: 0x000640AA File Offset: 0x000622AA
		// (set) Token: 0x06001502 RID: 5378 RVA: 0x000640B2 File Offset: 0x000622B2
		public ObservableCollection<ToolVision> VisionTools { get; set; }

		// Token: 0x1700077B RID: 1915
		// (get) Token: 0x06001503 RID: 5379 RVA: 0x000640BB File Offset: 0x000622BB
		// (set) Token: 0x06001504 RID: 5380 RVA: 0x000640C3 File Offset: 0x000622C3
		public ObservableCollection<TurnSnap> TurnSnaps { get; set; } = new ObservableCollection<TurnSnap>();

		// Token: 0x1700077C RID: 1916
		// (get) Token: 0x06001505 RID: 5381 RVA: 0x000640CC File Offset: 0x000622CC
		// (set) Token: 0x06001506 RID: 5382 RVA: 0x000640D4 File Offset: 0x000622D4
		public ObservableCollection<CameraNode> Cameras { get; set; } = new ObservableCollection<CameraNode>();

		// Token: 0x1700077D RID: 1917
		// (get) Token: 0x06001507 RID: 5383 RVA: 0x000640DD File Offset: 0x000622DD
		// (set) Token: 0x06001508 RID: 5384 RVA: 0x000640E5 File Offset: 0x000622E5
		public ObservableCollection<ConnectedCameraInfo> ConnectedCameras { get; set; } = new ObservableCollection<ConnectedCameraInfo>();

		// Token: 0x1700077E RID: 1918
		// (get) Token: 0x06001509 RID: 5385 RVA: 0x000640EE File Offset: 0x000622EE
		// (set) Token: 0x0600150A RID: 5386 RVA: 0x000640F6 File Offset: 0x000622F6
		public ObservableCollection<ConnectedLightInfo> ConnectedLights { get; set; } = new ObservableCollection<ConnectedLightInfo>();

		// Token: 0x1700077F RID: 1919
		// (get) Token: 0x0600150B RID: 5387 RVA: 0x000640FF File Offset: 0x000622FF
		// (set) Token: 0x0600150C RID: 5388 RVA: 0x00064107 File Offset: 0x00062307
		public LightControllerConfig LightConfig
		{
			get
			{
				return this._lightConfig;
			}
			set
			{
				base.SetProperty<LightControllerConfig>(ref this._lightConfig, value ?? new LightControllerConfig(), "LightConfig");
			}
		}

		// Token: 0x17000780 RID: 1920
		// (get) Token: 0x0600150D RID: 5389 RVA: 0x00064125 File Offset: 0x00062325
		// (set) Token: 0x0600150E RID: 5390 RVA: 0x0006412D File Offset: 0x0006232D
		public CameraNode SelectedCamera
		{
			get
			{
				return this._selectedCamera;
			}
			set
			{
				base.SetProperty<CameraNode>(ref this._selectedCamera, value, "SelectedCamera");
			}
		}

		// Token: 0x17000781 RID: 1921
		// (get) Token: 0x0600150F RID: 5391 RVA: 0x00064142 File Offset: 0x00062342
		// (set) Token: 0x06001510 RID: 5392 RVA: 0x0006414A File Offset: 0x0006234A
		public ObservableCollection<string> Items { get; set; }

		// Token: 0x17000782 RID: 1922
		// (get) Token: 0x06001511 RID: 5393 RVA: 0x00064153 File Offset: 0x00062353
		// (set) Token: 0x06001512 RID: 5394 RVA: 0x0006415B File Offset: 0x0006235B
		public string SelectedItem { get; set; }

		// Token: 0x17000783 RID: 1923
		// (get) Token: 0x06001513 RID: 5395 RVA: 0x00064164 File Offset: 0x00062364
		// (set) Token: 0x06001514 RID: 5396 RVA: 0x0006416C File Offset: 0x0006236C
		public ToolVision SelectedTool
		{
			get
			{
				return this._selectedTool;
			}
			set
			{
				base.SetProperty<ToolVision>(ref this._selectedTool, value, "SelectedTool");
			}
		}

		// Token: 0x17000784 RID: 1924
		// (get) Token: 0x06001515 RID: 5397 RVA: 0x00064181 File Offset: 0x00062381
		// (set) Token: 0x06001516 RID: 5398 RVA: 0x00064189 File Offset: 0x00062389
		public string TextValue { get; set; }

		// Token: 0x17000785 RID: 1925
		// (get) Token: 0x06001517 RID: 5399 RVA: 0x00064192 File Offset: 0x00062392
		// (set) Token: 0x06001518 RID: 5400 RVA: 0x0006419A File Offset: 0x0006239A
		public string Current_model
		{
			get
			{
				return this.current_model;
			}
			set
			{
				this.current_model = value;
				this.OnPropertyChanged("Current_model");
			}
		}

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x06001519 RID: 5401 RVA: 0x000641B0 File Offset: 0x000623B0
		// (remove) Token: 0x0600151A RID: 5402 RVA: 0x000641E8 File Offset: 0x000623E8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public new event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x0600151B RID: 5403 RVA: 0x0006421D File Offset: 0x0006241D
		protected void OnPropertyChanged([CallerMemberName] string name = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		// Token: 0x17000786 RID: 1926
		// (get) Token: 0x0600151C RID: 5404 RVA: 0x00064239 File Offset: 0x00062439
		// (set) Token: 0x0600151D RID: 5405 RVA: 0x00064241 File Offset: 0x00062441
		public ObservableCollection<string> List_model { get; set; }

		// Token: 0x17000787 RID: 1927
		// (get) Token: 0x0600151E RID: 5406 RVA: 0x0006424A File Offset: 0x0006244A
		// (set) Token: 0x0600151F RID: 5407 RVA: 0x00064252 File Offset: 0x00062452
		public ObservableCollection<RoiData> RoiItems { get; set; } = new ObservableCollection<RoiData>();

		// Token: 0x17000788 RID: 1928
		// (get) Token: 0x06001520 RID: 5408 RVA: 0x0006425B File Offset: 0x0006245B
		// (set) Token: 0x06001521 RID: 5409 RVA: 0x00064263 File Offset: 0x00062463
		public RoiData SelectedRoi
		{
			get
			{
				return this._selectedRoi;
			}
			set
			{
				base.SetProperty<RoiData>(ref this._selectedRoi, value, "SelectedRoi");
			}
		}

		// Token: 0x06001522 RID: 5410 RVA: 0x00064278 File Offset: 0x00062478
		public MainViewModel()
		{
			this.initial_Tool_vision();
			this.Items = new ObservableCollection<string>
			{
				"Apple",
				"Banana",
				"Orange"
			};
		}

		// Token: 0x17000789 RID: 1929
		// (get) Token: 0x06001523 RID: 5411 RVA: 0x00064334 File Offset: 0x00062534
		// (set) Token: 0x06001524 RID: 5412 RVA: 0x0006434C File Offset: 0x0006254C
		public object CurrentParameterView
		{
			get
			{
				return this._currentParameterView;
			}
			set
			{
				base.SetProperty<object>(ref this._currentParameterView, value, "CurrentParameterView");
			}
		}

		// Token: 0x1700078A RID: 1930
		// (get) Token: 0x06001525 RID: 5413 RVA: 0x00064362 File Offset: 0x00062562
		// (set) Token: 0x06001526 RID: 5414 RVA: 0x0006436A File Offset: 0x0006256A
		public ObservableCollection<ToolVision> ToolCatalog { get; private set; } = new ObservableCollection<ToolVision>();

		// Token: 0x06001527 RID: 5415 RVA: 0x00064374 File Offset: 0x00062574
		private void initial_Tool_vision()
		{
			this.VisionTools = new ObservableCollection<ToolVision>();
			this.ToolCatalog = new ObservableCollection<ToolVision>
			{
				new ToolVision
				{
					Name = "Acquisition",
					Icon = DXImageHelper.GetImageSource("Images/Miscellaneous/Satellite_32x32.png"),
					Children = 
					{
						new ToolVision
						{
							Name = "Camera Live",
							Icon = DXImageHelper.GetImageSource("Images/Miscellaneous/Video_32x32.png")
						},
						new ToolVision
						{
							Name = "Image Loader",
							Icon = DXImageHelper.GetImageSource("Images/Business Objects/BOFolder_32x32.png")
						}
					}
				},
				new ToolVision
				{
					Name = "Master",
					Icon = DXImageHelper.GetImageSource("Images/Spreadsheet/GroupRows_32x32.png"),
					Children = 
					{
						new ToolVision
						{
							Name = "Select Master",
							Icon = DXImageHelper.GetImageSource("Images/Spreadsheet/Encrypt_32x32.png")
						},
						new ToolVision
						{
							Name = "Shape Model",
							Icon = DXImageHelper.GetImageSource("Images/Trendlines/Exponential_32x32.png")
						},
						new ToolVision
						{
							Name = "Aniso Shape Model",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Spline_32x32.png")
						},
						new ToolVision
						{
							Name = "Overlapping Shape Model",
							Icon = DXImageHelper.GetImageSource("Images/Arrange/BringToFront_32x32.png")
						},
						new ToolVision
						{
							Name = "Position Master",
							Icon = DXImageHelper.GetImageSource("Images/Reports/DesignReport_32x32.png"),
							Children = 
							{
								new ToolVision
								{
									Name = "Bounding Box Master",
									Icon = DXImageHelper.GetImageSource("Images/Snap/HighlightActiveElement_32x32.png")
								},
								new ToolVision
								{
									Name = "Min Area Master",
									Icon = DXImageHelper.GetImageSource("Images/Snap/GroupFieldsCollection_32x32.png")
								},
								new ToolVision
								{
									Name = "Intersecting Lines",
									Icon = DXImageHelper.GetImageSource("Images/RichEdit/BordersInside_32x32.png")
								},
								new ToolVision
								{
									Name = "Circle Master",
									Icon = DXImageHelper.GetImageSource("Images/Filter/PieSeries_32x32.png")
								},
								new ToolVision
								{
									Name = "Calib Hand-Eye",
									Icon = DXImageHelper.GetImageSource("Images/Setup/Properties_32x32.png")
								},
								new ToolVision
								{
									Name = "Result Align",
									Icon = DXImageHelper.GetImageSource("Images/Alignment/AlignVerticalCenter_32x32.png")
								},
								new ToolVision
								{
									Name = "Procedure Model",
									Icon = DXImageHelper.GetImageSource("Images/Function Library/Logical_32x32.png")
								}
							}
						},
						new ToolVision
						{
							Name = "Angle Master",
							Icon = DXImageHelper.GetImageSource("Images/Analysis/UpDownBars_32x32.png"),
							Children = 
							{
								new ToolVision
								{
									Name = "Angle Selector",
									Icon = DXImageHelper.GetImageSource("Images/Chart/DrillDownOnArguments_Pie_32x32.png")
								}
							}
						}
					}
				},
				new ToolVision
				{
					Name = "Preprocessing",
					Icon = DXImageHelper.GetImageSource("Images/Actions/Convert_32x32.png"),
					Children = 
					{
						new ToolVision
						{
							Name = "Image Filter",
							Icon = DXImageHelper.GetImageSource("Images/Filter/Filter_32x32.png")
						},
						new ToolVision
						{
							Name = "Image Transform",
							Icon = DXImageHelper.GetImageSource("Images/Actions/Convert_32x32.png")
						},
						new ToolVision
						{
							Name = "Save Image",
							Icon = DXImageHelper.GetImageSource("Images/Save/Save_32x32.png")
						}
					}
				},
				new ToolVision
				{
					Name = "Inspection",
					Icon = DXImageHelper.GetImageSource("Images/Appearance/ColorMixer_32x32.png"),
					Children = 
					{
						new ToolVision
						{
							Name = "Blob Detection",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Point_32x32.png")
						},
						new ToolVision
						{
							Name = "Histogram",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Column_32x32.png")
						},
						new ToolVision
						{
							Name = "Histogram Color",
							Icon = DXImageHelper.GetImageSource("Images/Chart/StackedColumn_32x32.png")
						},
						new ToolVision
						{
							Name = "Pattern Matching",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Spline_32x32.png")
						},
						new ToolVision
						{
							Name = "Contour",
							Icon = DXImageHelper.GetImageSource("Images/Chart/ScatterWithSmoothLines_32x32.png")
						},
						new ToolVision
						{
							Name = "Deformable Inspection",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Spline_32x32.png")
						},
						new ToolVision
						{
							Name = "Variation Model",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Spline_32x32.png")
						},
						new ToolVision
						{
							Name = "Variation Change WD",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Spline_32x32.png")
						},
						new ToolVision
						{
							Name = "Product Count Inspection",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Point_32x32.png")
						},
						new ToolVision
						{
							Name = "Find Red Arrow",
							Icon = DXImageHelper.GetImageSource("Images/Appearance/ColorMixer_32x32.png")
						},
						new ToolVision
						{
							Name = "Count Bounding Box",
							Icon = DXImageHelper.GetImageSource("Images/Chart/BottomLeftHorizontalOutside_32x32.png")
						},
						new ToolVision
						{
							Name = "DL Object Inspection",
							Icon = DXImageHelper.GetImageSource("Images/Snap/HighlightActiveElement_32x32.png")
						},
						new ToolVision
						{
							Name = "Procedure Inspection",
							Icon = DXImageHelper.GetImageSource("Images/Function Library/Logical_32x32.png")
						},
						new ToolVision
						{
							Name = "Result Inspection",
							Icon = DXImageHelper.GetImageSource("Images/Chart/Point_32x32.png")
						}
					}
				},
				new ToolVision
				{
					Name = "Measuring",
					Icon = DXImageHelper.GetImageSource("Images/Gauges/GaugeStyleLinearHorizontal_32x32.png"),
					Children = 
					{
						new ToolVision
						{
							Name = "Find Circle",
							Icon = DXImageHelper.GetImageSource("Images/Chart/PieStyleDonut_32x32.png")
						},
						new ToolVision
						{
							Name = "Measure Circle",
							Icon = DXImageHelper.GetImageSource("Images/Chart/PieStyleDonut_32x32.png")
						},
						new ToolVision
						{
							Name = "Find Line",
							Icon = DXImageHelper.GetImageSource("Images/Chart/LabelsRight_32x32.png")
						},
						new ToolVision
						{
							Name = "Find Bounding Box",
							Icon = DXImageHelper.GetImageSource("Images/Chart/BottomLeftHorizontalOutside_32x32.png")
						},
						new ToolVision
						{
							Name = "Find Min Area",
							Icon = DXImageHelper.GetImageSource("Images/Snap/ArrangeGroups_32x32.png")
						},
						new ToolVision
						{
							Name = "Distance Object",
							Icon = DXImageHelper.GetImageSource("Images/Grid/ColumnWidth_32x32.png")
						}
					}
				},
				new ToolVision
				{
					Name = "Recognition",
					Icon = DXImageHelper.GetImageSource("Images/Chart/VerticalAxisTitles_VerticalText_32x32.png"),
					Children = 
					{
						new ToolVision
						{
							Name = "OCR",
							Icon = DXImageHelper.GetImageSource("Images/Alignment/ContentAutoArrange_32x32.png")
						},
						new ToolVision
						{
							Name = "OCV",
							Icon = DXImageHelper.GetImageSource("Images/Dashboards/DashboardTitle_32x32.png")
						},
						new ToolVision
						{
							Name = "Barcode Reader",
							Icon = DXImageHelper.GetImageSource("Images/Content/Barcode_32x32.png")
						},
						new ToolVision
						{
							Name = "Matrixcode Reader",
							Icon = DXImageHelper.GetImageSource("GrayScaleImages/Other/DeleteCells_32x32.png")
						}
					}
				}
			};
			this.ApplyToolboxVisibility();
		}

		// Token: 0x06001528 RID: 5416 RVA: 0x00064C54 File Offset: 0x00062E54
		public void ApplyToolboxVisibility()
		{
			bool flag = this.VisionTools == null;
			if (flag)
			{
				this.VisionTools = new ObservableCollection<ToolVision>();
			}
			this.VisionTools.Clear();
			foreach (ToolVision category in this.ToolCatalog)
			{
				ToolVision node = MainViewModel.BuildVisibleEntry(category);
				bool flag2 = node != null;
				if (flag2)
				{
					this.VisionTools.Add(node);
				}
			}
			this.OnPropertyChanged("VisionTools");
		}

		// Token: 0x06001529 RID: 5417 RVA: 0x00064CF0 File Offset: 0x00062EF0
		private static ToolVision BuildVisibleEntry(ToolVision source)
		{
			bool flag = source == null || ToolboxVisibilityService.IsHidden(source.Name);
			ToolVision result;
			if (flag)
			{
				result = null;
			}
			else
			{
				ToolVision node = MainViewModel.CloneToolboxEntry(source);
				bool flag2 = source.Children == null || source.Children.Count == 0;
				if (flag2)
				{
					result = node;
				}
				else
				{
					foreach (ToolVision child in source.Children)
					{
						ToolVision visibleChild = MainViewModel.BuildVisibleEntry(child);
						bool flag3 = visibleChild != null;
						if (flag3)
						{
							node.Children.Add(visibleChild);
						}
					}
					result = ((node.Children.Count == 0) ? null : node);
				}
			}
			return result;
		}

		// Token: 0x0600152A RID: 5418 RVA: 0x00064DBC File Offset: 0x00062FBC
		private static ToolVision CloneToolboxEntry(ToolVision source)
		{
			return new ToolVision
			{
				Name = source.Name,
				Icon = source.Icon
			};
		}

		// Token: 0x0600152B RID: 5419 RVA: 0x00064DF0 File Offset: 0x00062FF0
		public void SyncCamerasFromRuntimeStore()
		{
			MainViewModel.<>c__DisplayClass77_0 CS$<>8__locals1 = new MainViewModel.<>c__DisplayClass77_0();
			MainViewModel.<>c__DisplayClass77_0 CS$<>8__locals2 = CS$<>8__locals1;
			CameraNode selectedCamera = this.SelectedCamera;
			string oldSelectedName;
			if (selectedCamera == null)
			{
				oldSelectedName = null;
			}
			else
			{
				CameraItem cameraInfo = selectedCamera.CameraInfo;
				oldSelectedName = ((cameraInfo != null) ? cameraInfo.CameraName : null);
			}
			CS$<>8__locals2.oldSelectedName = oldSelectedName;
			this.Cameras.Clear();
			int index = 1;
			foreach (CameraItem cam in CameraRuntimeStore.Cameras)
			{
				this.Cameras.Add(new CameraNode
				{
					Index = index++,
					CameraInfo = cam,
					CameraConfig = new CameraParameterConfig()
				});
			}
			bool flag = !string.IsNullOrWhiteSpace(CS$<>8__locals1.oldSelectedName);
			if (flag)
			{
				this.SelectedCamera = this.Cameras.FirstOrDefault(delegate(CameraNode c)
				{
					CameraItem cameraInfo2 = c.CameraInfo;
					return ((cameraInfo2 != null) ? cameraInfo2.CameraName : null) == CS$<>8__locals1.oldSelectedName;
				});
			}
			bool flag2 = this.SelectedCamera == null;
			if (flag2)
			{
				this.SelectedCamera = this.Cameras.FirstOrDefault<CameraNode>();
			}
			this.OnPropertyChanged("Cameras");
		}

		// Token: 0x0600152C RID: 5420 RVA: 0x00064F04 File Offset: 0x00063104
		public void SyncCamerasFromRuntimeStorePreserveTurns()
		{
			Dictionary<string, CameraNode> existing = this.Cameras.ToDictionary(delegate(CameraNode x)
			{
				CameraItem cameraInfo = x.CameraInfo;
				return ((cameraInfo != null) ? cameraInfo.CameraName : null) ?? "";
			}, (CameraNode x) => x);
			ObservableCollection<CameraNode> newList = new ObservableCollection<CameraNode>();
			int index = 1;
			foreach (CameraItem cam in CameraRuntimeStore.Cameras)
			{
				CameraNode oldNode;
				bool flag = existing.TryGetValue(cam.CameraName, out oldNode);
				if (flag)
				{
					oldNode.Index = index++;
					oldNode.CameraInfo = cam;
					bool flag2 = oldNode.CameraConfig == null;
					if (flag2)
					{
						oldNode.CameraConfig = new CameraParameterConfig();
					}
					newList.Add(oldNode);
				}
				else
				{
					newList.Add(new CameraNode
					{
						Index = index++,
						CameraInfo = cam,
						CameraConfig = new CameraParameterConfig()
					});
				}
			}
			this.Cameras.Clear();
			foreach (CameraNode item in newList)
			{
				this.Cameras.Add(item);
			}
			bool flag3 = this.SelectedCamera == null || !this.Cameras.Contains(this.SelectedCamera);
			if (flag3)
			{
				this.SelectedCamera = this.Cameras.FirstOrDefault<CameraNode>();
			}
			this.OnPropertyChanged("Cameras");
		}

		// Token: 0x1700078B RID: 1931
		// (get) Token: 0x0600152D RID: 5421 RVA: 0x000650C4 File Offset: 0x000632C4
		public bool IsDiscoveringCameras
		{
			get
			{
				return this._isDiscoveringCameras;
			}
		}

		// Token: 0x0600152E RID: 5422 RVA: 0x000650CC File Offset: 0x000632CC
		public void RefreshConnectedCameras()
		{
			this.RefreshConnectedCameras(null);
		}

		// Token: 0x0600152F RID: 5423 RVA: 0x000650D8 File Offset: 0x000632D8
		public void RefreshConnectedCameras(Action onCompleted)
		{
			bool isDiscoveringCameras = this._isDiscoveringCameras;
			if (isDiscoveringCameras)
			{
				Action onCompleted2 = onCompleted;
				if (onCompleted2 != null)
				{
					onCompleted2();
				}
			}
			else
			{
				this._isDiscoveringCameras = true;
				Task.Run(delegate()
				{
					List<ConnectedCameraInfo> cameras;
					try
					{
						cameras = CameraDiscoveryService.EnumerateConnectedCameras();
					}
					catch
					{
						cameras = new List<ConnectedCameraInfo>();
					}
					Action publish = delegate()
					{
						this.ConnectedCameras.Clear();
						foreach (ConnectedCameraInfo camera in cameras)
						{
							this.ConnectedCameras.Add(camera);
						}
						this._isDiscoveringCameras = false;
						Action onCompleted3 = onCompleted;
						if (onCompleted3 != null)
						{
							onCompleted3();
						}
					};
					Application application = Application.Current;
					Dispatcher dispatcher = (application != null) ? application.Dispatcher : null;
					bool flag = dispatcher == null || dispatcher.CheckAccess();
					if (flag)
					{
						publish();
					}
					else
					{
						dispatcher.BeginInvoke(publish, Array.Empty<object>());
					}
				});
			}
		}

		// Token: 0x06001530 RID: 5424 RVA: 0x00065132 File Offset: 0x00063332
		public void RefreshConnectedLights()
		{
			this.RefreshConnectedLights(null);
		}

		// Token: 0x06001531 RID: 5425 RVA: 0x00065140 File Offset: 0x00063340
		public void RefreshConnectedLights(Action onCompleted)
		{
			bool isDiscoveringLights = this._isDiscoveringLights;
			if (isDiscoveringLights)
			{
				Action onCompleted2 = onCompleted;
				if (onCompleted2 != null)
				{
					onCompleted2();
				}
			}
			else
			{
				this._isDiscoveringLights = true;
				Task.Run(delegate()
				{
					List<ConnectedLightInfo> lights;
					try
					{
						lights = LightControllerRuntimeService.EnumerateConnectedLights();
					}
					catch
					{
						lights = new List<ConnectedLightInfo>();
					}
					Action publish = delegate()
					{
						this.ConnectedLights.Clear();
						foreach (ConnectedLightInfo light in lights)
						{
							this.ConnectedLights.Add(light);
						}
						this._isDiscoveringLights = false;
						Action onCompleted3 = onCompleted;
						if (onCompleted3 != null)
						{
							onCompleted3();
						}
					};
					Application application = Application.Current;
					Dispatcher dispatcher = (application != null) ? application.Dispatcher : null;
					bool flag = dispatcher == null || dispatcher.CheckAccess();
					if (flag)
					{
						publish();
					}
					else
					{
						dispatcher.BeginInvoke(publish, Array.Empty<object>());
					}
				});
			}
		}

		// Token: 0x1700078C RID: 1932
		// (get) Token: 0x06001532 RID: 5426 RVA: 0x0006519A File Offset: 0x0006339A
		// (set) Token: 0x06001533 RID: 5427 RVA: 0x000651A2 File Offset: 0x000633A2
		public ObservableCollection<ModelConfig> Models { get; set; } = new ObservableCollection<ModelConfig>();

		// Token: 0x1700078D RID: 1933
		// (get) Token: 0x06001534 RID: 5428 RVA: 0x000651AB File Offset: 0x000633AB
		// (set) Token: 0x06001535 RID: 5429 RVA: 0x000651B3 File Offset: 0x000633B3
		public ModelConfig CurrentModel
		{
			get
			{
				return this._currentModel;
			}
			set
			{
				base.SetProperty<ModelConfig>(ref this._currentModel, value, "CurrentModel");
			}
		}

		// Token: 0x1700078E RID: 1934
		// (get) Token: 0x06001536 RID: 5430 RVA: 0x000651C8 File Offset: 0x000633C8
		// (set) Token: 0x06001537 RID: 5431 RVA: 0x000651D0 File Offset: 0x000633D0
		public string CurrentModelName
		{
			get
			{
				return this._currentModelName;
			}
			set
			{
				base.SetProperty<string>(ref this._currentModelName, value, "CurrentModelName");
			}
		}

		// Token: 0x06001538 RID: 5432 RVA: 0x000651E8 File Offset: 0x000633E8
		public void SyncModelsFromRuntimeStore()
		{
			MainViewModel.<>c__DisplayClass99_0 CS$<>8__locals1 = new MainViewModel.<>c__DisplayClass99_0();
			CS$<>8__locals1.<>4__this = this;
			List<ModelConfig> runtimeModels = (from x in ModelRuntimeStore.Models
			where x != null
			select x).ToList<ModelConfig>();
			int i;
			int j;
			for (i = this.Models.Count - 1; i >= 0; i = j - 1)
			{
				bool flag = !runtimeModels.Any((ModelConfig x) => x.Id == CS$<>8__locals1.<>4__this.Models[i].Id);
				if (flag)
				{
					this.Models.RemoveAt(i);
				}
				j = i;
			}
			for (int targetIndex = 0; targetIndex < runtimeModels.Count; targetIndex++)
			{
				ModelConfig runtimeModel = runtimeModels[targetIndex];
				int existingIndex = (from x in this.Models.Select((ModelConfig item, int index) => new
				{
					item,
					index
				})
				where x.item.Id == runtimeModel.Id
				select x.index).DefaultIfEmpty(-1).First<int>();
				bool flag2 = existingIndex < 0;
				if (flag2)
				{
					this.Models.Insert(targetIndex, runtimeModel);
				}
				else
				{
					bool flag3 = this.Models[existingIndex] != runtimeModel;
					if (flag3)
					{
						this.Models[existingIndex] = runtimeModel;
					}
					bool flag4 = existingIndex != targetIndex;
					if (flag4)
					{
						this.Models.Move(existingIndex, targetIndex);
					}
				}
			}
			CS$<>8__locals1.runtimeCurrent = ModelRuntimeStore.CurrentModel;
			this.CurrentModel = ((CS$<>8__locals1.runtimeCurrent == null) ? null : (this.Models.FirstOrDefault((ModelConfig x) => x.Id == CS$<>8__locals1.runtimeCurrent.Id) ?? CS$<>8__locals1.runtimeCurrent));
			ModelConfig currentModel = this.CurrentModel;
			this.CurrentModelName = (((currentModel != null) ? currentModel.Model_name : null) ?? "No model selected");
		}

		// Token: 0x040008C4 RID: 2244
		private LightControllerConfig _lightConfig = new LightControllerConfig();

		// Token: 0x040008C5 RID: 2245
		private CameraNode _selectedCamera;

		// Token: 0x040008C8 RID: 2248
		private ToolVision _selectedTool;

		// Token: 0x040008CA RID: 2250
		private string current_model = "";

		// Token: 0x040008CE RID: 2254
		private RoiData _selectedRoi;

		// Token: 0x040008CF RID: 2255
		private object _currentParameterView;

		// Token: 0x040008D1 RID: 2257
		private bool _isDiscoveringCameras;

		// Token: 0x040008D2 RID: 2258
		private bool _isDiscoveringLights;

		// Token: 0x040008D4 RID: 2260
		private ModelConfig _currentModel;

		// Token: 0x040008D5 RID: 2261
		private string _currentModelName = "No model selected";
	}
}
