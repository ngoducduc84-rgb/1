﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.Grid;
using DevExpress.Xpf.PropertyGrid;
using HalconDotNet;
using Microsoft.Win32;
using VisionMachine.Models.Communication;
using VisionMachine.Services.Calibration;
using VisionMachine.Services.Communication;
using VisionMachine.Views.Calibration.ViewModels;

namespace VisionMachine.Views.Calibration
{
	// Token: 0x020001C5 RID: 453
	public partial class Form_calib_handeye : ThemedWindow, IStyleConnector
	{
		// Token: 0x06001BAF RID: 7087 RVA: 0x0009A034 File Offset: 0x00098234
		public Form_calib_handeye()
		{
			this.InitializeComponent();
			CalibHandEyeViewModel viewModel = new CalibHandEyeViewModel();
			viewModel.Setting.PropertyChanged += this.Setting_PropertyChanged;
			viewModel.LoadSampleData();
			base.DataContext = viewModel;
			viewModel.LogRows.CollectionChanged += this.LogRows_CollectionChanged;
			CalibHandEyeOptionProvider.OptionsSourceChanged += this.CalibOptionsSourceChanged;
			CalibHandEyeOptionProvider.ActiveRefreshRequest = new Action(this.RequestRefreshFromExternalChange);
			this.RefreshSettingOptions(true);
		}

		// Token: 0x06001BB0 RID: 7088 RVA: 0x0009A0F4 File Offset: 0x000982F4
		public void RefreshSettingOptions(bool loadSavedConfig = false)
		{
			CalibHandEyeOptionProvider.Refresh();
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				if (loadSavedConfig)
				{
					Form_calib_handeye.ApplySavedSetting(viewModel.Setting);
				}
				string currentCamera = viewModel.Setting.CameraName;
				bool flag2 = string.IsNullOrWhiteSpace(currentCamera) || currentCamera == "None" || !CalibHandEyeOptionProvider.CameraOptions.Contains(currentCamera);
				if (flag2)
				{
					viewModel.Setting.CameraName = (CalibHandEyeOptionProvider.CameraOptions.FirstOrDefault((string x) => x != "None") ?? "None");
				}
				else
				{
					CalibHandEyeOptionProvider.RefreshMasterToolsForCamera(currentCamera);
				}
				bool flag3 = viewModel.Setting.MasterToolName == "None" || !CalibHandEyeOptionProvider.MasterToolOptions.Contains(viewModel.Setting.MasterToolName);
				if (flag3)
				{
					viewModel.Setting.MasterToolName = CalibHandEyeOptionProvider.GetDefaultMasterToolName();
				}
				bool flag4 = string.IsNullOrWhiteSpace(viewModel.Setting.CommunicationName) || !CalibHandEyeOptionProvider.CommunicationOptions.Contains(viewModel.Setting.CommunicationName);
				if (flag4)
				{
					viewModel.Setting.CommunicationName = (CalibHandEyeOptionProvider.CommunicationOptions.FirstOrDefault((string x) => x != "None") ?? "None");
				}
				this.RefreshPropertyGrid();
				if (loadSavedConfig)
				{
					this.LoadSavedPoints();
				}
			}
		}

		// Token: 0x06001BB1 RID: 7089 RVA: 0x0009A288 File Offset: 0x00098488
		private void OnLoaded(object sender, RoutedEventArgs e)
		{
			this.RefreshSettingOptions(true);
			this.RebindLogGrid();
		}

		// Token: 0x06001BB2 RID: 7090 RVA: 0x0009A29C File Offset: 0x0009849C
		private void LoadSavedPoints()
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				CalibHandEyePointsData data = CalibHandEyePointsStorageService.Load();
				bool flag2 = data == null || ((data.RobotPoints == null || data.RobotPoints.Count == 0) && (data.VisionPoints == null || data.VisionPoints.Count == 0));
				if (!flag2)
				{
					viewModel.LoadPoints(data.RobotPoints, data.VisionPoints);
					this.RebindPointGrids(viewModel);
					GridControl robotPointGrid = this.RobotPointGrid;
					if (robotPointGrid != null)
					{
						robotPointGrid.RefreshData();
					}
					GridControl visionPointGrid = this.VisionPointGrid;
					if (visionPointGrid != null)
					{
						visionPointGrid.RefreshData();
					}
					this._manualCaptureRowsReady = true;
					VisionPointRow nextPending = viewModel.VisionPoints.FirstOrDefault((VisionPointRow x) => string.Equals(x.Status, "Pending", StringComparison.OrdinalIgnoreCase));
					this._manualCaptureIndex = ((nextPending != null) ? nextPending.Index : (viewModel.VisionPoints.Count + 1));
					viewModel.AddLog(0, "Load", "calibration points", "Success", string.Format("Loaded {0} saved calibration point(s).", viewModel.VisionPoints.Count));
				}
			}
		}

		// Token: 0x06001BB3 RID: 7091 RVA: 0x0009A3CC File Offset: 0x000985CC
		protected override void OnClosed(EventArgs e)
		{
			this.StopWorkflow();
			bool flag = this._previewImage != null;
			if (flag)
			{
				this._previewImage.Dispose();
				this._previewImage = null;
			}
			CalibHandEyeOptionProvider.OptionsSourceChanged -= this.CalibOptionsSourceChanged;
			bool flag2 = CalibHandEyeOptionProvider.ActiveRefreshRequest == new Action(this.RequestRefreshFromExternalChange);
			if (flag2)
			{
				CalibHandEyeOptionProvider.ActiveRefreshRequest = null;
			}
			base.OnClosed(e);
		}

		// Token: 0x06001BB4 RID: 7092 RVA: 0x0009A43E File Offset: 0x0009863E
		private void CalibOptionsSourceChanged(object sender, EventArgs e)
		{
			this.RequestRefreshFromExternalChange();
		}

		// Token: 0x06001BB5 RID: 7093 RVA: 0x0009A448 File Offset: 0x00098648
		private void RequestRefreshFromExternalChange()
		{
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				this.RefreshSettingOptions(false);
			}), Array.Empty<object>());
		}

		// Token: 0x06001BB6 RID: 7094 RVA: 0x0009A468 File Offset: 0x00098668
		private void ApplySetting_Click(object sender, RoutedEventArgs e)
		{
			Keyboard.ClearFocus();
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				bool flag2 = !CalibHandEyeConfigStorageService.Save(viewModel.Setting);
				if (flag2)
				{
					DXMessageBox.Show(this, "No current model is selected. Calibration setting was not saved.", "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				}
				else
				{
					DXMessageBox.Show(this, "Calibration setting saved.", "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
			}
		}

		// Token: 0x06001BB7 RID: 7095 RVA: 0x0009A4D0 File Offset: 0x000986D0
		private bool EnsureCalibCameraAvailable(CalibHandEyeViewModel viewModel)
		{
			string text;
			if (viewModel == null)
			{
				text = null;
			}
			else
			{
				CalibHandEyeSetting setting = viewModel.Setting;
				text = ((setting != null) ? setting.CameraName : null);
			}
			string cameraName = text;
			bool hasCamera = !string.IsNullOrWhiteSpace(cameraName) && !string.Equals(cameraName, "None", StringComparison.OrdinalIgnoreCase);
			bool flag = hasCamera;
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				if (viewModel != null)
				{
					viewModel.SetCalibrationStatus("No camera found.");
				}
				if (viewModel != null)
				{
					viewModel.AddLog(0, "Camera", "availability check", "Fail", "No camera was found/selected for calibration. Connect a camera, then reopen or refresh the calibration form.");
				}
				this.RebindLogGrid();
				DXMessageBox.Show(this, "No camera was found or selected for calibration.\nPlease connect a camera and select it in the calibration setup, then try again.\n\nYou can still load an image from file to review points.", "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				result = false;
			}
			return result;
		}

		// Token: 0x06001BB8 RID: 7096 RVA: 0x0009A570 File Offset: 0x00098770
		[DebuggerStepThrough]
		private void CaptureOnce_Click(object sender, RoutedEventArgs e)
		{
			Form_calib_handeye.<CaptureOnce_Click>d__30 <CaptureOnce_Click>d__ = new Form_calib_handeye.<CaptureOnce_Click>d__30();
			<CaptureOnce_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<CaptureOnce_Click>d__.<>4__this = this;
			<CaptureOnce_Click>d__.sender = sender;
			<CaptureOnce_Click>d__.e = e;
			<CaptureOnce_Click>d__.<>1__state = -1;
			<CaptureOnce_Click>d__.<>t__builder.Start<Form_calib_handeye.<CaptureOnce_Click>d__30>(ref <CaptureOnce_Click>d__);
		}

		// Token: 0x06001BB9 RID: 7097 RVA: 0x0009A5B8 File Offset: 0x000987B8
		[DebuggerStepThrough]
		private void StartCalibration_Click(object sender, RoutedEventArgs e)
		{
			Form_calib_handeye.<StartCalibration_Click>d__31 <StartCalibration_Click>d__ = new Form_calib_handeye.<StartCalibration_Click>d__31();
			<StartCalibration_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<StartCalibration_Click>d__.<>4__this = this;
			<StartCalibration_Click>d__.sender = sender;
			<StartCalibration_Click>d__.e = e;
			<StartCalibration_Click>d__.<>1__state = -1;
			<StartCalibration_Click>d__.<>t__builder.Start<Form_calib_handeye.<StartCalibration_Click>d__31>(ref <StartCalibration_Click>d__);
		}

		// Token: 0x06001BBA RID: 7098 RVA: 0x0009A600 File Offset: 0x00098800
		[DebuggerStepThrough]
		private void PauseCalibration_Click(object sender, RoutedEventArgs e)
		{
			Form_calib_handeye.<PauseCalibration_Click>d__32 <PauseCalibration_Click>d__ = new Form_calib_handeye.<PauseCalibration_Click>d__32();
			<PauseCalibration_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<PauseCalibration_Click>d__.<>4__this = this;
			<PauseCalibration_Click>d__.sender = sender;
			<PauseCalibration_Click>d__.e = e;
			<PauseCalibration_Click>d__.<>1__state = -1;
			<PauseCalibration_Click>d__.<>t__builder.Start<Form_calib_handeye.<PauseCalibration_Click>d__32>(ref <PauseCalibration_Click>d__);
		}

		// Token: 0x06001BBB RID: 7099 RVA: 0x0009A648 File Offset: 0x00098848
		[DebuggerStepThrough]
		private void StopCalibration_Click(object sender, RoutedEventArgs e)
		{
			Form_calib_handeye.<StopCalibration_Click>d__33 <StopCalibration_Click>d__ = new Form_calib_handeye.<StopCalibration_Click>d__33();
			<StopCalibration_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<StopCalibration_Click>d__.<>4__this = this;
			<StopCalibration_Click>d__.sender = sender;
			<StopCalibration_Click>d__.e = e;
			<StopCalibration_Click>d__.<>1__state = -1;
			<StopCalibration_Click>d__.<>t__builder.Start<Form_calib_handeye.<StopCalibration_Click>d__33>(ref <StopCalibration_Click>d__);
		}

		// Token: 0x06001BBC RID: 7100 RVA: 0x0009A690 File Offset: 0x00098890
		private void ClearCalibrationLog_Click(object sender, RoutedEventArgs e)
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				viewModel.LogRows.Clear();
				GridControl calibrationLogGrid = this.CalibrationLogGrid;
				if (calibrationLogGrid != null)
				{
					calibrationLogGrid.RefreshData();
				}
			}
		}

		// Token: 0x06001BBD RID: 7101 RVA: 0x0009A6D4 File Offset: 0x000988D4
		private void CopyCalibrationLog_Click(object sender, RoutedEventArgs e)
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				StringBuilder builder = new StringBuilder();
				builder.AppendLine("Time\tPoint\tAction\tRobot Command / Info\tResult\tMessage");
				foreach (CalibrationLogRow row in viewModel.LogRows)
				{
					builder.Append(Form_calib_handeye.EscapeLogCell(row.Time));
					builder.Append('\t');
					builder.Append(row.Point.ToString(CultureInfo.InvariantCulture));
					builder.Append('\t');
					builder.Append(Form_calib_handeye.EscapeLogCell(row.Action));
					builder.Append('\t');
					builder.Append(Form_calib_handeye.EscapeLogCell(row.RobotCommand));
					builder.Append('\t');
					builder.Append(Form_calib_handeye.EscapeLogCell(row.Result));
					builder.Append('\t');
					builder.AppendLine(Form_calib_handeye.EscapeLogCell(row.Message));
				}
				Clipboard.SetText(builder.ToString());
			}
		}

		// Token: 0x06001BBE RID: 7102 RVA: 0x0009A808 File Offset: 0x00098A08
		private static string EscapeLogCell(string value)
		{
			return (value ?? string.Empty).Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
		}

		// Token: 0x06001BBF RID: 7103 RVA: 0x0009A854 File Offset: 0x00098A54
		[DebuggerStepThrough]
		private Task<bool> WriteCalibrationControlCommandAsync(CalibHandEyeViewModel viewModel, int commandValue, string actionName)
		{
			Form_calib_handeye.<WriteCalibrationControlCommandAsync>d__37 <WriteCalibrationControlCommandAsync>d__ = new Form_calib_handeye.<WriteCalibrationControlCommandAsync>d__37();
			<WriteCalibrationControlCommandAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<WriteCalibrationControlCommandAsync>d__.<>4__this = this;
			<WriteCalibrationControlCommandAsync>d__.viewModel = viewModel;
			<WriteCalibrationControlCommandAsync>d__.commandValue = commandValue;
			<WriteCalibrationControlCommandAsync>d__.actionName = actionName;
			<WriteCalibrationControlCommandAsync>d__.<>1__state = -1;
			<WriteCalibrationControlCommandAsync>d__.<>t__builder.Start<Form_calib_handeye.<WriteCalibrationControlCommandAsync>d__37>(ref <WriteCalibrationControlCommandAsync>d__);
			return <WriteCalibrationControlCommandAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06001BC0 RID: 7104 RVA: 0x0009A8B0 File Offset: 0x00098AB0
		private void WriteCalibrationControlCommand(CalibHandEyeViewModel viewModel, int commandValue)
		{
			bool flag = viewModel == null || viewModel.Setting == null;
			if (flag)
			{
				throw new InvalidOperationException("Calibration setting is not available.");
			}
			CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(null);
			CommunicationConnection connection = config.Connections.FirstOrDefault((CommunicationConnection x) => string.Equals(x.Name, viewModel.Setting.CommunicationName, StringComparison.OrdinalIgnoreCase));
			bool flag2 = connection == null || string.IsNullOrWhiteSpace(viewModel.Setting.CommunicationName) || string.Equals(viewModel.Setting.CommunicationName, "None", StringComparison.OrdinalIgnoreCase);
			if (flag2)
			{
				throw new InvalidOperationException("Communication connection is not selected.");
			}
			List<CommunicationTagRow> connectionTags = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name);
			CommunicationTagRow tag = connectionTags.FirstOrDefault((CommunicationTagRow x) => string.Equals(Form_calib_handeye.NormalizeCalibrationTagName(x.Name), Form_calib_handeye.NormalizeCalibrationTagName("calibration start"), StringComparison.OrdinalIgnoreCase));
			bool flag3 = tag == null;
			if (flag3)
			{
				throw new InvalidOperationException("Tag 'calibration start' was not found in Tag Management.");
			}
			bool flag4 = string.IsNullOrWhiteSpace(tag.Address);
			if (flag4)
			{
				throw new InvalidOperationException("Tag 'calibration start' does not have an address.");
			}
			CommunicationOperationResult connectResult = this._calibrationControlCommunicationService.ConnectIfDisconnected(connection);
			bool flag5 = !connectResult.Success;
			if (flag5)
			{
				throw new InvalidOperationException("PLC connect failed: " + connectResult.Message);
			}
			string valueText = commandValue.ToString(CultureInfo.InvariantCulture);
			CommunicationOperationResult writeResult = this._calibrationControlCommunicationService.Write(connection, tag.Address, string.IsNullOrWhiteSpace(tag.DataType) ? "INT16" : tag.DataType, valueText);
			bool flag6 = !writeResult.Success;
			if (flag6)
			{
				throw new InvalidOperationException("Write calibration start failed: " + writeResult.Message);
			}
		}

		// Token: 0x06001BC1 RID: 7105 RVA: 0x0009AA64 File Offset: 0x00098C64
		private static string NormalizeCalibrationTagName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				result = new string(name.Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
			}
			return result;
		}

		// Token: 0x06001BC2 RID: 7106 RVA: 0x0009AAAC File Offset: 0x00098CAC
		private void ResetCalibration_Click(object sender, RoutedEventArgs e)
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				Keyboard.ClearFocus();
				this.StopWorkflow();
				this._captureOverlayPoints.Clear();
				this._manualCaptureIndex = 1;
				this._manualCaptureRowsReady = true;
				viewModel.PrepareCalibrationRows();
				viewModel.LogRows.Clear();
				viewModel.SetCurrentPoint(1);
				viewModel.SetCalibrationStatus("Ready.");
				viewModel.AddLog(0, "Reset", "manual capture", "Success", "Calibration capture data was reset.");
				this.RebindPointGrids(viewModel);
				GridControl robotPointGrid = this.RobotPointGrid;
				if (robotPointGrid != null)
				{
					robotPointGrid.RefreshData();
				}
				GridControl visionPointGrid = this.VisionPointGrid;
				if (visionPointGrid != null)
				{
					visionPointGrid.RefreshData();
				}
				this.RebindLogGrid();
				this.RedrawPreview();
			}
		}

		// Token: 0x06001BC3 RID: 7107 RVA: 0x0009AB78 File Offset: 0x00098D78
		private void HWindowCalib_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
		{
			bool flag = this._previewImage == null || !this._previewImage.IsInitialized();
			if (!flag)
			{
				e.Handled = true;
				try
				{
					HWindow window = this.HWindowCalib.HalconWindow;
					HTuple row;
					HTuple col;
					HTuple row2;
					HTuple col2;
					window.GetPart(out row, out col, out row2, out col2);
					HTuple imageWidth;
					HTuple imageHeight;
					HOperatorSet.GetImageSize(this._previewImage, out imageWidth, out imageHeight);
					double controlWidth = this.HWindowCalib.ActualWidth;
					double controlHeight = this.HWindowCalib.ActualHeight;
					bool flag2 = controlWidth <= 0.0 || controlHeight <= 0.0;
					if (!flag2)
					{
						double partHeight = row2.D - row.D + 1.0;
						double partWidth = col2.D - col.D + 1.0;
						bool flag3 = partHeight <= 1.0 || partWidth <= 1.0;
						if (!flag3)
						{
							double factor = (e.Delta > 0) ? 0.8 : 1.25;
							double newHeight = Math.Max(8.0, Math.Min(imageHeight.D * 20.0, partHeight * factor));
							double newWidth = Math.Max(8.0, Math.Min(imageWidth.D * 20.0, partWidth * factor));
							Point mouse = e.GetPosition(this.HWindowCalib);
							double mouseRow = row.D + mouse.Y * partHeight / controlHeight;
							double mouseColumn = col.D + mouse.X * partWidth / controlWidth;
							double relativeY = mouse.Y / controlHeight;
							double relativeX = mouse.X / controlWidth;
							double newRow = mouseRow - relativeY * newHeight;
							double newCol = mouseColumn - relativeX * newWidth;
							window.SetPart((int)Math.Round(newRow), (int)Math.Round(newCol), (int)Math.Round(newRow + newHeight - 1.0), (int)Math.Round(newCol + newWidth - 1.0));
							this.SchedulePreviewRedraw();
						}
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001BC4 RID: 7108 RVA: 0x0009ADC8 File Offset: 0x00098FC8
		private void HWindowCalib_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			bool flag = this._previewImage == null || !this._previewImage.IsInitialized();
			if (!flag)
			{
				e.Handled = true;
				this.FitPreviewToWindow();
			}
		}

		// Token: 0x06001BC5 RID: 7109 RVA: 0x0009AE04 File Offset: 0x00099004
		private void HWindowCalib_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = this._previewImage == null || !this._previewImage.IsInitialized();
			if (!flag)
			{
				bool flag2 = e.ChangedButton != MouseButton.Left && e.ChangedButton != MouseButton.Middle;
				if (!flag2)
				{
					this._isPanning = true;
					this._lastPanPosition = e.GetPosition(this.HWindowCalib);
					this.HWindowCalib.CaptureMouse();
					this.HWindowCalib.Cursor = Cursors.SizeAll;
					e.Handled = true;
				}
			}
		}

		// Token: 0x06001BC6 RID: 7110 RVA: 0x0009AE90 File Offset: 0x00099090
		private void HWindowCalib_MouseMove(object sender, MouseEventArgs e)
		{
			this.UpdatePreviewPixelInspector(e);
			bool flag = !this._isPanning || this._previewImage == null || !this._previewImage.IsInitialized();
			if (!flag)
			{
				bool flag2 = e.LeftButton != MouseButtonState.Pressed && e.MiddleButton != MouseButtonState.Pressed;
				if (flag2)
				{
					this.EndPan();
				}
				else
				{
					try
					{
						Point current = e.GetPosition(this.HWindowCalib);
						double dx = current.X - this._lastPanPosition.X;
						double dy = current.Y - this._lastPanPosition.Y;
						this._lastPanPosition = current;
						bool flag3 = Math.Abs(dx) < 0.1 && Math.Abs(dy) < 0.1;
						if (!flag3)
						{
							HWindow window = this.HWindowCalib.HalconWindow;
							HTuple row;
							HTuple col;
							HTuple row2;
							HTuple col2;
							window.GetPart(out row, out col, out row2, out col2);
							double partWidth = col2.D - col.D + 1.0;
							double partHeight = row2.D - row.D + 1.0;
							double controlWidth = this.HWindowCalib.ActualWidth;
							double controlHeight = this.HWindowCalib.ActualHeight;
							bool flag4 = controlWidth <= 0.0 || controlHeight <= 0.0;
							if (!flag4)
							{
								double imageDx = dx * partWidth / controlWidth;
								double imageDy = dy * partHeight / controlHeight;
								window.SetPart((int)Math.Round(row.D - imageDy), (int)Math.Round(col.D - imageDx), (int)Math.Round(row2.D - imageDy), (int)Math.Round(col2.D - imageDx));
								this.SchedulePreviewRedraw();
								e.Handled = true;
							}
						}
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x06001BC7 RID: 7111 RVA: 0x0009B090 File Offset: 0x00099290
		private void HWindowCalib_MouseLeave(object sender, MouseEventArgs e)
		{
			this.SetPreviewPixelInspectorUnavailable(0, 0);
		}

		// Token: 0x06001BC8 RID: 7112 RVA: 0x0009B09C File Offset: 0x0009929C
		private void UpdatePreviewPixelInspector(MouseEventArgs e)
		{
			bool flag = e == null || this._previewImage == null || !this._previewImage.IsInitialized() || this.HWindowCalib == null || this.CalibPixelInspectorText == null;
			if (flag)
			{
				this.SetPreviewPixelInspectorUnavailable(0, 0);
			}
			else
			{
				DateTime now = DateTime.UtcNow;
				bool flag2 = (now - this._lastPreviewPixelInspectorUpdateUtc).TotalMilliseconds < 33.0;
				if (!flag2)
				{
					this._lastPreviewPixelInspectorUpdateUtc = now;
					try
					{
						HWindow window = this.HWindowCalib.HalconWindow;
						HTuple row;
						HTuple col;
						HTuple row2;
						HTuple col2;
						window.GetPart(out row, out col, out row2, out col2);
						double controlWidth = this.HWindowCalib.ActualWidth;
						double controlHeight = this.HWindowCalib.ActualHeight;
						bool flag3 = controlWidth <= 0.0 || controlHeight <= 0.0;
						if (flag3)
						{
							this.SetPreviewPixelInspectorUnavailable(0, 0);
						}
						else
						{
							Point position = e.GetPosition(this.HWindowCalib);
							double imageRow = row.D + position.Y * (row2.D - row.D + 1.0) / controlHeight;
							double imageColumn = col.D + position.X * (col2.D - col.D + 1.0) / controlWidth;
							int row3 = (int)Math.Round(imageRow);
							int column = (int)Math.Round(imageColumn);
							HTuple width;
							HTuple height;
							HOperatorSet.GetImageSize(this._previewImage, out width, out height);
							bool flag4 = row3 < 0 || column < 0 || row3 >= height.I || column >= width.I;
							if (flag4)
							{
								this.SetPreviewPixelInspectorUnavailable(width.I, height.I);
							}
							else
							{
								HTuple channelCount;
								HOperatorSet.CountChannels(this._previewImage, out channelCount);
								HTuple pixelValue;
								HOperatorSet.GetGrayval(this._previewImage, row3, column, out pixelValue);
								string gray = "-";
								string red = "-";
								string green = "-";
								string blue = "-";
								bool flag5 = channelCount.Length > 0 && channelCount[0].I >= 3 && pixelValue.Length >= 3;
								if (flag5)
								{
									double r = pixelValue[0].D;
									double g = pixelValue[1].D;
									double b = pixelValue[2].D;
									gray = (0.299 * r + 0.587 * g + 0.114 * b).ToString("0");
									red = r.ToString("0");
									green = g.ToString("0");
									blue = b.ToString("0");
								}
								else
								{
									bool flag6 = pixelValue.Length > 0;
									if (flag6)
									{
										gray = pixelValue[0].D.ToString("0");
									}
								}
								this.CalibPixelInspectorText.Text = string.Concat(new string[]
								{
									"Row: ",
									row3.ToString(),
									"  Col: ",
									column.ToString(),
									"  Gray: ",
									gray,
									"  R: ",
									red,
									"  G: ",
									green,
									"  B: ",
									blue,
									"  Size: ",
									width.I.ToString(),
									" x ",
									height.I.ToString()
								});
							}
						}
					}
					catch
					{
						this.SetPreviewPixelInspectorUnavailable(0, 0);
					}
				}
			}
		}

		// Token: 0x06001BC9 RID: 7113 RVA: 0x0009B474 File Offset: 0x00099674
		private void SetPreviewPixelInspectorUnavailable(int width = 0, int height = 0)
		{
			bool flag = this.CalibPixelInspectorText == null;
			if (!flag)
			{
				string size = (width > 0 && height > 0) ? (width.ToString() + " x " + height.ToString()) : "-";
				this.CalibPixelInspectorText.Text = "Row: -  Col: -  Gray: -  R: -  G: -  B: -  Size: " + size;
			}
		}

		// Token: 0x06001BCA RID: 7114 RVA: 0x0009B4D0 File Offset: 0x000996D0
		private void HWindowCalib_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.EndPan();
			e.Handled = true;
		}

		// Token: 0x06001BCB RID: 7115 RVA: 0x0009B4E4 File Offset: 0x000996E4
		private void HWindowCalib_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
		{
			HSmartWindowControlWPF hwindowCalib = this.HWindowCalib;
			bool flag = ((hwindowCalib != null) ? hwindowCalib.ContextMenu : null) == null;
			if (!flag)
			{
				this.HWindowCalib.ContextMenu.PlacementTarget = this.HWindowCalib;
				this.HWindowCalib.ContextMenu.IsOpen = true;
				e.Handled = true;
			}
		}

		// Token: 0x06001BCC RID: 7116 RVA: 0x0009B540 File Offset: 0x00099740
		private void SaveCalib_Click(object sender, RoutedEventArgs e)
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				Keyboard.ClearFocus();
				bool saved = CalibHandEyePointsStorageService.Save(viewModel.RobotPoints, viewModel.VisionPoints);
				viewModel.AddLog(0, "Save Calib", "calibration points", saved ? "Success" : "Fail", saved ? string.Format("Saved {0} vision / {1} robot point(s).", viewModel.VisionPoints.Count, viewModel.RobotPoints.Count) : "No current model is selected. Points were not saved.");
				List<HandEyeSamplePoint> mappingSamples = viewModel.BuildMappingSamples();
				List<HandEyeSamplePoint> rotationSamples = viewModel.BuildRotationSamples();
				string exportPath = null;
				bool exported = false;
				bool flag2 = mappingSamples.Count >= 3 && rotationSamples.Count >= 3;
				if (flag2)
				{
					TcpCalibrationResult tcp = TcpCalibrationSolver.Solve(mappingSamples, rotationSamples, false);
					bool flag3 = tcp.IsSuccess && tcp.Mapping != null && tcp.Mapping.IsSuccess;
					if (flag3)
					{
						viewModel.SetCalibrationResult(tcp.Mapping);
						this._lastTcpResult = tcp;
						exportPath = Form_calib_handeye.GetDefaultCalibFilePath();
						string tcpQualityMessage;
						bool flag4 = !Form_calib_handeye.IsTcpExportQualityAcceptable(tcp, out tcpQualityMessage);
						if (flag4)
						{
							viewModel.AddLog(0, "Save Calib", "export calib", "Fail", "Calibration file was NOT exported because TCP quality is not acceptable. " + tcpQualityMessage);
						}
						else
						{
							bool flag5 = !string.IsNullOrWhiteSpace(exportPath);
							if (flag5)
							{
								try
								{
									CalibHandEyeExportService.Export(tcp, exportPath);
									exported = true;
									viewModel.AddLog(0, "Save Calib", "export calib", "Success", "9-point matrix + TCP center exported to: " + exportPath);
								}
								catch (Exception ex)
								{
									viewModel.AddLog(0, "Save Calib", "export calib", "Fail", ex.Message);
								}
							}
							else
							{
								viewModel.AddLog(0, "Save Calib", "export calib", "Fail", "No current model is selected, so the calibration file was not exported.");
							}
						}
					}
					else
					{
						viewModel.AddLog(0, "Save Calib", "tcp solve", "Fail", tcp.Message);
					}
				}
				else
				{
					HandEyeCalibrationResult mapping = HandEyeCalibrationSolver.Solve(mappingSamples);
					bool isSuccess = mapping.IsSuccess;
					if (isSuccess)
					{
						viewModel.SetCalibrationResult(mapping);
					}
					viewModel.AddLog(0, "Save Calib", "export calib", "Warn", string.Concat(new string[]
					{
						"Have ",
						mappingSamples.Count.ToString(),
						" mapping / ",
						rotationSamples.Count.ToString(),
						" rotation point(s). Need >= 3 rotation points to compute TCP; calibration file was NOT exported."
					}));
				}
				this.RebindLogGrid();
				DXMessageBox.Show(this, (saved ? ("Calibration points saved to:\n" + CalibHandEyePointsStorageService.LastSavePath + "\n\n") : "No current model is selected, so the points were not saved.\n\n") + (exported ? ("Calibration matrix (9 points) + TCP center (3 rotation points) exported to:\n" + exportPath) : "Calibration file was NOT exported. Make sure a model is selected and you have >= 3 rotation points."), "Calib Hand-Eye", MessageBoxButton.OK, (saved && exported) ? MessageBoxImage.Asterisk : MessageBoxImage.Exclamation);
				this.RebuildGridOverlayFromData(viewModel);
				this.DrawTcpFromRotation(viewModel);
			}
		}

		// Token: 0x06001BCD RID: 7117 RVA: 0x0009B844 File Offset: 0x00099A44
		private static string GetDefaultCalibFilePath()
		{
			string dir = Form_calib_handeye.GetDefaultExportDirectory();
			bool flag = string.IsNullOrWhiteSpace(dir);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = Path.Combine(dir, "calib_hand_eye.dat");
			}
			return result;
		}

		// Token: 0x06001BCE RID: 7118 RVA: 0x0009B878 File Offset: 0x00099A78
		private static bool IsTcpExportQualityAcceptable(TcpCalibrationResult tcp, out string message)
		{
			message = null;
			bool flag = tcp == null || !tcp.IsSuccess;
			bool result;
			if (flag)
			{
				message = ((tcp == null) ? "TCP result is empty." : tcp.Message);
				result = false;
			}
			else
			{
				bool flag2 = tcp.CircleRadiusPx < 5.0;
				if (flag2)
				{
					message = "Rotation circle radius is too small (" + tcp.CircleRadiusPx.ToString("0.###") + " px). Rotate the robot by a larger angle and capture the rotation points again.";
					result = false;
				}
				else
				{
					bool flag3 = tcp.CircleFitRmsPx > tcp.CircleRadiusPx * 0.25;
					if (flag3)
					{
						message = string.Concat(new string[]
						{
							"Rotation circle fit is unstable. Fit RMS=",
							tcp.CircleFitRmsPx.ToString("0.###"),
							" px, Radius=",
							tcp.CircleRadiusPx.ToString("0.###"),
							" px. Re-capture cleaner rotation points before exporting TCP calibration."
						});
						result = false;
					}
					else
					{
						bool flag4 = double.IsNaN(tcp.CircleCenterImageX) || double.IsNaN(tcp.CircleCenterImageY) || double.IsInfinity(tcp.CircleCenterImageX) || double.IsInfinity(tcp.CircleCenterImageY);
						if (flag4)
						{
							message = "TCP center is not finite.";
							result = false;
						}
						else
						{
							result = true;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001BCF RID: 7119 RVA: 0x0009B9B8 File Offset: 0x00099BB8
		private void ExportCalib_Click(object sender, RoutedEventArgs e)
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				Keyboard.ClearFocus();
				List<HandEyeSamplePoint> mappingSamples = viewModel.BuildMappingSamples();
				List<HandEyeSamplePoint> rotationSamples = viewModel.BuildRotationSamples();
				TcpCalibrationResult tcp = TcpCalibrationSolver.Solve(mappingSamples, rotationSamples, false);
				bool flag2 = tcp.IsSuccess && tcp.TcpAppliedToMapping;
				if (flag2)
				{
					viewModel.AddLog(0, "Calibrate", "tcp -> mapping", "Success", string.Format("TCP center computed from {0} rotation point(s), then mapping H re-fit from {1} point(s). ", rotationSamples.Count, mappingSamples.Count) + string.Format("Reprojection {0:0.###} -> {1:0.###} px.", tcp.MappingReprojectionBeforePx, tcp.MappingReprojectionAfterPx));
				}
				bool flag3 = !tcp.IsSuccess;
				if (flag3)
				{
					viewModel.AddLog(0, "Export", "tcp solve", "Fail", tcp.Message);
					DXMessageBox.Show(this, tcp.Message, "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				}
				else
				{
					string exportQualityMessage;
					bool flag4 = !Form_calib_handeye.IsTcpExportQualityAcceptable(tcp, out exportQualityMessage);
					if (flag4)
					{
						viewModel.AddLog(0, "Export", "tcp quality", "Fail", exportQualityMessage);
						DXMessageBox.Show(this, exportQualityMessage, "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					}
					else
					{
						this._lastTcpResult = tcp;
						viewModel.SetCalibrationResult(tcp.Mapping);
						SaveFileDialog dialog = new SaveFileDialog
						{
							Title = "Export Halcon Calibration",
							Filter = "Halcon tuple (*.dat)|*.dat|All files (*.*)|*.*",
							FileName = "calib_hand_eye.dat",
							AddExtension = true,
							DefaultExt = ".dat"
						};
						string defaultDir = Form_calib_handeye.GetDefaultExportDirectory();
						bool flag5 = !string.IsNullOrWhiteSpace(defaultDir);
						if (flag5)
						{
							bool flag6 = !Directory.Exists(defaultDir);
							if (flag6)
							{
								Directory.CreateDirectory(defaultDir);
							}
							dialog.InitialDirectory = defaultDir;
						}
						bool? dialogResult;
						try
						{
							dialogResult = dialog.ShowDialog();
						}
						catch (InvalidOperationException ex)
						{
							viewModel.AddLog(0, "Export", "save dialog", "Fail", ex.Message);
							DXMessageBox.Show(this, "Could not open the export file dialog.\n" + ex.Message, "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Hand);
							return;
						}
						bool flag7 = !dialogResult.GetValueOrDefault();
						if (!flag7)
						{
							try
							{
								CalibHandEyeExportService.Export(tcp, dialog.FileName);
								viewModel.AddLog(0, "Export", "halcon calib", "Success", string.Format("Exported to {0}. TCP offset = ({1:0.###}, {2:0.###}) mm.", dialog.FileName, tcp.TcpOffsetBaseX, tcp.TcpOffsetBaseY));
								DXMessageBox.Show(this, string.Concat(new string[]
								{
									tcp.Message,
									"\n\nExported files:\n",
									dialog.FileName,
									"\n",
									Path.ChangeExtension(dialog.FileName, ".txt")
								}), "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Asterisk);
							}
							catch (Exception ex2)
							{
								viewModel.AddLog(0, "Export", "halcon calib", "Fail", ex2.Message);
								DXMessageBox.Show(this, ex2.Message, "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Hand);
							}
						}
					}
				}
			}
		}

		// Token: 0x06001BD0 RID: 7120 RVA: 0x0009BCEC File Offset: 0x00099EEC
		private static string GetDefaultExportDirectory()
		{
			string path = CalibHandEyeResultStorageService.GetResultPath();
			bool flag = string.IsNullOrWhiteSpace(path);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				try
				{
					result = Path.GetFullPath(Path.GetDirectoryName(path));
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001BD1 RID: 7121 RVA: 0x0009BD38 File Offset: 0x00099F38
		private void ViewDetail_Click(object sender, RoutedEventArgs e)
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = this._lastTcpResult != null && this._lastTcpResult.IsSuccess;
			if (flag)
			{
				TcpCalibrationResult tcp = this._lastTcpResult;
				HandEyeCalibrationResult mapping = tcp.Mapping ?? HandEyeCalibrationResult.Failed("missing");
				string tcpDetail = string.Concat(new string[]
				{
					"[Step 1 - Mapping image->robot]\n",
					string.Format("Position points : {0}\n", mapping.PointCount),
					string.Format("Pixel size      : {0:0.#####} x {1:0.#####} mm/px\n", mapping.PixelSizeX, mapping.PixelSizeY),
					string.Format("Rotation        : {0:0.###} deg\n", mapping.RotationDeg),
					string.Format("Mapping RMS     : {0:0.####} mm\n", mapping.RmsErrorMm),
					string.Format("Reprojection    : {0:0.####} px\n\n", mapping.ReprojectionErrorPx),
					"[Step 2 - TCP from rotation circle]\n",
					string.Format("Rotation points : {0}\n", tcp.RotationPointCount),
					string.Format("Circle center px: ({0:0.##}, {1:0.##})\n", tcp.CircleCenterImageX, tcp.CircleCenterImageY),
					string.Format("Circle radius   : {0:0.##} px\n", tcp.CircleRadiusPx),
					string.Format("Circle fit RMS  : {0:0.###} px\n", tcp.CircleFitRmsPx),
					string.Format("Center (robot)  : ({0:0.###}, {1:0.###}) mm\n\n", tcp.CircleCenterRobotX, tcp.CircleCenterRobotY),
					"[Rotation robot mean]\n",
					string.Format("Flange mean     : ({0:0.###}, {1:0.###}) mm\n", tcp.FlangeMeanX, tcp.FlangeMeanY),
					string.Format("Observed mean   : ({0:0.###}, {1:0.###}) mm\n\n", tcp.ObservedMeanRobotX, tcp.ObservedMeanRobotY),
					"[TCP offset correction]\n",
					string.Format("Base frame      : ({0:0.####}, {1:0.####}) mm\n", tcp.TcpOffsetBaseX, tcp.TcpOffsetBaseY),
					string.Format("Tool frame      : ({0:0.####}, {1:0.####}) mm\n", tcp.TcpOffsetToolX, tcp.TcpOffsetToolY),
					string.Format("Magnitude       : {0:0.####} mm\n", tcp.TcpOffsetMagnitude),
					"Created         : ",
					tcp.CreatedAt
				});
				DXMessageBox.Show(this, tcpDetail, "TCP Calibration Detail", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				HandEyeCalibrationResult result = (viewModel != null) ? viewModel.LastResult : null;
				bool flag2 = result == null || !result.IsSuccess;
				if (flag2)
				{
					DXMessageBox.Show(this, "No valid calibration result is available yet. Run the calibration or press Save Result first.", "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					string detail = string.Concat(new string[]
					{
						string.Format("Points used: {0}\n", result.PointCount),
						string.Format("Pixel size X: {0:0.######} mm/px\n", result.PixelSizeX),
						string.Format("Pixel size Y: {0:0.######} mm/px\n", result.PixelSizeY),
						string.Format("Rotation: {0:0.####} deg\n", result.RotationDeg),
						string.Format("Slant: {0:0.####} deg\n", result.SlantDeg),
						string.Format("Offset X: {0:0.####} mm\n", result.TranslationX),
						string.Format("Offset Y: {0:0.####} mm\n", result.TranslationY),
						string.Format("Angle offset: {0:0.####} deg\n", result.AngleOffsetDeg),
						string.Format("RMS error: {0:0.######} mm\n", result.RmsErrorMm),
						string.Format("Max error: {0:0.######} mm\n", result.MaxErrorMm),
						string.Format("Reprojection error: {0:0.######} px\n", result.ReprojectionErrorPx),
						"Created: ",
						result.CreatedAt
					});
					DXMessageBox.Show(this, detail, "Calibration Result Detail", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
			}
		}

		// Token: 0x06001BD2 RID: 7122 RVA: 0x0009C134 File Offset: 0x0009A334
		private CalibHandEyeWorkflowService CreateWorkflowService(CalibHandEyeViewModel viewModel)
		{
			return new CalibHandEyeWorkflowService
			{
				ImageCaptured = delegate(HObject image)
				{
					this.Dispatcher.Invoke(delegate()
					{
						this.DisplayPreviewImage(image);
					});
				},
				RobotPoseRead = delegate(CalibHandEyeWorkflowPointResult result)
				{
					this.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this.ApplyRobotPoseRead(viewModel, result);
					}), Array.Empty<object>());
				},
				PointCompleted = delegate(CalibHandEyeWorkflowPointResult result)
				{
					this.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this.ApplyPointResult(viewModel, result);
					}), Array.Empty<object>());
				},
				Log = delegate(int point, string action, string command, string result, string message)
				{
					this.Dispatcher.BeginInvoke(new Action(delegate()
					{
						viewModel.AddLog(point, action, command, result, message);
						this.RebindLogGrid();
					}), Array.Empty<object>());
				},
				StatusChanged = delegate(string status)
				{
					this.Dispatcher.BeginInvoke(new Action(delegate()
					{
						viewModel.SetCalibrationStatus(status);
					}), Array.Empty<object>());
				},
				CalibrationCompleted = delegate(HandEyeCalibrationResult result)
				{
					this.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this.ApplyCalibrationResult(viewModel, result);
					}), Array.Empty<object>());
				}
			};
		}

		// Token: 0x06001BD3 RID: 7123 RVA: 0x0009C1D4 File Offset: 0x0009A3D4
		private void ApplyRobotPoseRead(CalibHandEyeViewModel viewModel, CalibHandEyeWorkflowPointResult result)
		{
			bool flag = viewModel == null || result == null;
			if (!flag)
			{
				viewModel.UpdateRobotPoint(result.Index, result.RobotX, result.RobotY, result.RobotRz, true);
				this.RebindPointGrids(viewModel);
				GridControl robotPointGrid = this.RobotPointGrid;
				if (robotPointGrid != null)
				{
					robotPointGrid.RefreshData();
				}
			}
		}

		// Token: 0x06001BD4 RID: 7124 RVA: 0x0009C22C File Offset: 0x0009A42C
		private void ApplyCalibrationResult(CalibHandEyeViewModel viewModel, HandEyeCalibrationResult result)
		{
			bool flag = viewModel == null || result == null;
			if (!flag)
			{
				viewModel.SetCalibrationResult(result);
				bool isSuccess = result.IsSuccess;
				if (isSuccess)
				{
					CalibHandEyeResultStorageService.Save(result);
					viewModel.AddLog(0, "Calibrate", "hand-eye result", "Success", string.Format("Pixel {0:0.#####} mm/px, rotation {1:0.###} deg, RMS {2:0.####} mm.", result.PixelSizeX, result.RotationDeg, result.RmsErrorMm));
				}
			}
		}

		// Token: 0x06001BD5 RID: 7125 RVA: 0x0009C2A8 File Offset: 0x0009A4A8
		private void ApplyPointResult(CalibHandEyeViewModel viewModel, CalibHandEyeWorkflowPointResult result)
		{
			bool flag = viewModel == null || result == null;
			if (!flag)
			{
				viewModel.UpdatePoint(result.Index, result.RobotX, result.RobotY, result.RobotRz, result.VisionX, result.VisionY, result.VisionAngle, result.Score, result.IsSuccess);
				this.RebindPointGrids(viewModel);
				GridControl robotPointGrid = this.RobotPointGrid;
				if (robotPointGrid != null)
				{
					robotPointGrid.RefreshData();
				}
				GridControl visionPointGrid = this.VisionPointGrid;
				if (visionPointGrid != null)
				{
					visionPointGrid.RefreshData();
				}
				viewModel.AddLog(result.Index, "Vision Coordinates", "master center", result.IsSuccess ? "Success" : "Fail", result.IsSuccess ? string.Format("X={0:0.###}, Y={1:0.###}, Angle={2:0.###}, Score={3:0.###}", new object[]
				{
					result.VisionX,
					result.VisionY,
					result.VisionAngle,
					result.Score
				}) : result.Message);
				this.StoreOverlayPoint(result);
				this.SchedulePreviewRedraw();
			}
		}

		// Token: 0x06001BD6 RID: 7126 RVA: 0x0009C3C4 File Offset: 0x0009A5C4
		private void RebindPointGrids(CalibHandEyeViewModel viewModel)
		{
			bool flag = viewModel == null;
			if (!flag)
			{
				bool flag2 = this.RobotPointGrid != null;
				if (flag2)
				{
					this.RobotPointGrid.ItemsSource = null;
					this.RobotPointGrid.ItemsSource = viewModel.RobotPoints;
				}
				bool flag3 = this.VisionPointGrid != null;
				if (flag3)
				{
					this.VisionPointGrid.ItemsSource = null;
					this.VisionPointGrid.ItemsSource = viewModel.VisionPoints;
				}
			}
		}

		// Token: 0x06001BD7 RID: 7127 RVA: 0x0009C438 File Offset: 0x0009A638
		private void RebindLogGrid()
		{
			bool flag = this.CalibrationLogGrid == null;
			if (!flag)
			{
				CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
				bool flag2 = viewModel == null;
				if (!flag2)
				{
					this.CalibrationLogGrid.ItemsSource = null;
					this.CalibrationLogGrid.ItemsSource = viewModel.LogRows;
				}
			}
		}

		// Token: 0x06001BD8 RID: 7128 RVA: 0x0009C48C File Offset: 0x0009A68C
		private void LogRows_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			bool flag = base.Dispatcher.CheckAccess();
			if (flag)
			{
				this.RebindLogGrid();
			}
			else
			{
				base.Dispatcher.BeginInvoke(new Action(this.RebindLogGrid), Array.Empty<object>());
			}
		}

		// Token: 0x06001BD9 RID: 7129 RVA: 0x0009C4D0 File Offset: 0x0009A6D0
		private void EnsureManualCaptureRows(CalibHandEyeViewModel viewModel)
		{
			bool flag = viewModel == null;
			if (!flag)
			{
				bool flag2 = this._manualCaptureRowsReady && viewModel.VisionPoints.Count == viewModel.CalibrationPointCount && viewModel.RobotPoints.Count == viewModel.CalibrationPointCount;
				if (!flag2)
				{
					viewModel.PrepareCalibrationRows();
					this._manualCaptureRowsReady = true;
					this._manualCaptureIndex = 1;
				}
			}
		}

		// Token: 0x06001BDA RID: 7130 RVA: 0x0009C538 File Offset: 0x0009A738
		private void StoreOverlayPoint(CalibHandEyeWorkflowPointResult result)
		{
			bool flag = result == null || !result.IsSuccess;
			if (!flag)
			{
				this._captureOverlayPoints.RemoveAll((CalibHandEyeWorkflowPointResult x) => x.Index == result.Index);
				this._captureOverlayPoints.Add(new CalibHandEyeWorkflowPointResult
				{
					Index = result.Index,
					VisionX = result.VisionX,
					VisionY = result.VisionY,
					VisionAngle = result.VisionAngle,
					Score = result.Score,
					IsSuccess = result.IsSuccess
				});
			}
		}

		// Token: 0x06001BDB RID: 7131 RVA: 0x0009C60C File Offset: 0x0009A80C
		private void RedrawPreview()
		{
			bool flag = this._previewImage == null || !this._previewImage.IsInitialized();
			if (!flag)
			{
				bool previewIsRedrawing = this._previewIsRedrawing;
				if (!previewIsRedrawing)
				{
					try
					{
						this._previewIsRedrawing = true;
						HWindow window = this.HWindowCalib.HalconWindow;
						window.ClearWindow();
						HOperatorSet.DispObj(this._previewImage, window);
						this.DrawCaptureOverlays();
						this.DrawGridPointsOverlay();
						this.DrawTcpOverlay();
					}
					catch
					{
					}
					finally
					{
						this._previewIsRedrawing = false;
					}
				}
			}
		}

		// Token: 0x06001BDC RID: 7132 RVA: 0x0009C6B8 File Offset: 0x0009A8B8
		private void SchedulePreviewRedraw()
		{
			HSmartWindowControlWPF hwindowCalib = this.HWindowCalib;
			bool flag = ((hwindowCalib != null) ? hwindowCalib.Dispatcher : null) == null;
			if (!flag)
			{
				bool previewRedrawQueued = this._previewRedrawQueued;
				if (!previewRedrawQueued)
				{
					this._previewRedrawQueued = true;
					this.HWindowCalib.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this._previewRedrawQueued = false;
						bool flag2 = this.HWindowCalib == null || !this.HWindowCalib.IsLoaded || this.HWindowCalib.ActualWidth <= 0.0 || this.HWindowCalib.ActualHeight <= 0.0;
						if (!flag2)
						{
							this.RedrawPreview();
						}
					}), DispatcherPriority.Background, Array.Empty<object>());
				}
			}
		}

		// Token: 0x06001BDD RID: 7133 RVA: 0x0009C718 File Offset: 0x0009A918
		private void DrawCaptureOverlays()
		{
			List<CalibHandEyeWorkflowPointResult> points = (from x in this._captureOverlayPoints
			where x.IsSuccess
			orderby x.Index
			select x).ToList<CalibHandEyeWorkflowPointResult>();
			bool flag = points.Count == 0;
			if (!flag)
			{
				this.HWindowCalib.HalconWindow.SetLineWidth(2.0);
				this.HWindowCalib.HalconWindow.SetColor("yellow");
				for (int i = 1; i < points.Count; i++)
				{
					this.DrawArrow(points[i - 1].VisionY, points[i - 1].VisionX, points[i].VisionY, points[i].VisionX);
				}
				this.HWindowCalib.HalconWindow.SetColor("green");
				foreach (CalibHandEyeWorkflowPointResult point in points)
				{
					HOperatorSet.DispCross(this.HWindowCalib.HalconWindow, point.VisionY, point.VisionX, 48, 0);
					this.HWindowCalib.HalconWindow.SetTposition(Convert.ToInt32(point.VisionY + 12.0), Convert.ToInt32(point.VisionX + 12.0));
					this.HWindowCalib.HalconWindow.WriteString(point.Index.ToString());
				}
			}
		}

		// Token: 0x06001BDE RID: 7134 RVA: 0x0009C904 File Offset: 0x0009AB04
		private void LoadImageFromFile_Click(object sender, RoutedEventArgs e)
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			OpenFileDialog dialog = new OpenFileDialog
			{
				Title = "Load Image For Calibration",
				Filter = "Image files (*.png;*.bmp;*.jpg;*.jpeg;*.tif;*.tiff)|*.png;*.bmp;*.jpg;*.jpeg;*.tif;*.tiff|All files (*.*)|*.*"
			};
			bool? dialogResult;
			try
			{
				dialogResult = dialog.ShowDialog();
			}
			catch (Exception ex)
			{
				if (viewModel != null)
				{
					viewModel.AddLog(0, "Load Image", "open dialog", "Fail", ex.Message);
				}
				DXMessageBox.Show("Could not open the file dialog.\n" + ex.Message, "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Hand);
				return;
			}
			bool flag = !dialogResult.GetValueOrDefault() || string.IsNullOrWhiteSpace(dialog.FileName);
			if (!flag)
			{
				HObject image = null;
				try
				{
					HOperatorSet.ReadImage(out image, dialog.FileName);
					this._captureOverlayPoints.Clear();
					this.DisplayPreviewImage(image);
					image = null;
					if (viewModel != null)
					{
						viewModel.AddLog(0, "Load Image", "read image", "Success", "Loaded image: " + dialog.FileName);
					}
				}
				catch (Exception ex2)
				{
					if (image != null)
					{
						image.Dispose();
					}
					if (viewModel != null)
					{
						viewModel.AddLog(0, "Load Image", "read image", "Fail", ex2.Message);
					}
					DXMessageBox.Show(this, "Failed to load the image.\n" + ex2.Message, "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				}
			}
		}

		// Token: 0x06001BDF RID: 7135 RVA: 0x0009CA80 File Offset: 0x0009AC80
		private void RebuildGridOverlayFromData(CalibHandEyeViewModel viewModel)
		{
			this._gridOverlayPoints.Clear();
			this._captureOverlayPoints.Clear();
			bool flag = viewModel == null;
			if (!flag)
			{
				foreach (HandEyeSamplePoint s in from x in viewModel.BuildMappingSamples()
				where x != null && x.IsValid
				select x)
				{
					this._gridOverlayPoints.Add(new Form_calib_handeye.CalibOverlayPoint
					{
						Row = s.ImageY,
						Col = s.ImageX,
						Index = s.Index,
						IsRotation = false
					});
				}
				foreach (HandEyeSamplePoint s2 in from x in viewModel.BuildRotationSamples()
				where x != null && x.IsValid
				select x)
				{
					this._gridOverlayPoints.Add(new Form_calib_handeye.CalibOverlayPoint
					{
						Row = s2.ImageY,
						Col = s2.ImageX,
						Index = s2.Index,
						IsRotation = true
					});
				}
			}
		}

		// Token: 0x06001BE0 RID: 7136 RVA: 0x0009CBEC File Offset: 0x0009ADEC
		private void DrawGridPointsOverlay()
		{
			bool flag;
			if (this._gridOverlayPoints.Count != 0)
			{
				HSmartWindowControlWPF hwindowCalib = this.HWindowCalib;
				flag = (((hwindowCalib != null) ? hwindowCalib.HalconWindow : null) == null);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (!flag2)
			{
				try
				{
					HWindow window = this.HWindowCalib.HalconWindow;
					window.SetLineWidth(2.0);
					foreach (Form_calib_handeye.CalibOverlayPoint p in this._gridOverlayPoints)
					{
						window.SetColor(p.IsRotation ? "orange" : "lime green");
						HOperatorSet.DispCross(window, p.Row, p.Col, 46, p.IsRotation ? 0.785 : 0.0);
						window.SetTposition(Convert.ToInt32(p.Row + 12.0), Convert.ToInt32(p.Col + 12.0));
						window.WriteString(p.Index.ToString());
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001BE1 RID: 7137 RVA: 0x0009CD64 File Offset: 0x0009AF64
		private void DrawTcpOverlay()
		{
			bool flag;
			if (this._hasTcpOverlay)
			{
				HSmartWindowControlWPF hwindowCalib = this.HWindowCalib;
				flag = (((hwindowCalib != null) ? hwindowCalib.HalconWindow : null) == null);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (!flag2)
			{
				try
				{
					HWindow window = this.HWindowCalib.HalconWindow;
					window.SetDraw("margin");
					window.SetLineWidth(2.0);
					window.SetColor("red");
					HOperatorSet.DispCircle(window, this._tcpCenterRow, this._tcpCenterCol, this._tcpRadiusPx);
					window.SetColor("cyan");
					HOperatorSet.DispCross(window, this._tcpCenterRow, this._tcpCenterCol, 50, 0);
					window.SetTposition(Convert.ToInt32(this._tcpCenterRow + 14.0), Convert.ToInt32(this._tcpCenterCol + 14.0));
					window.WriteString("TCP");
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001BE2 RID: 7138 RVA: 0x0009CE90 File Offset: 0x0009B090
		private void DrawTcpFromRotation(CalibHandEyeViewModel viewModel)
		{
			this._hasTcpOverlay = false;
			List<HandEyeSamplePoint> rotationSamples = (from x in viewModel.BuildRotationSamples() ?? new List<HandEyeSamplePoint>()
			where x != null && x.IsValid
			select x).ToList<HandEyeSamplePoint>();
			bool flag = rotationSamples.Count < 3;
			if (flag)
			{
				viewModel.AddLog(0, "Save Calib", "tcp circle", "Fail", "Need at least 3 rotation points to find the TCP center, got " + rotationSamples.Count.ToString() + ".");
				DXMessageBox.Show(this, "Not enough rotation points to find the TCP center (need at least 3 rotation-angle points).", "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				this.SchedulePreviewRedraw();
			}
			else
			{
				TcpCalibrationResult tcp = TcpCalibrationSolver.Solve(viewModel.BuildMappingSamples(), rotationSamples, false);
				bool flag2 = !tcp.IsSuccess;
				if (flag2)
				{
					viewModel.AddLog(0, "Save Calib", "tcp circle", "Fail", tcp.Message);
					DXMessageBox.Show(this, "Could not find the TCP center:\n" + tcp.Message + "\nThe rotation points may be collinear or too close together.", "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					this.SchedulePreviewRedraw();
				}
				else
				{
					bool flag3 = tcp.CircleRadiusPx < 5.0;
					if (flag3)
					{
						viewModel.AddLog(0, "Save Calib", "tcp circle", "Fail", "Rotation circle radius too small (" + tcp.CircleRadiusPx.ToString("0.##") + " px). The rotation points are too close together (insufficient resolution).");
						DXMessageBox.Show(this, "The rotation points are too close together (circle radius " + tcp.CircleRadiusPx.ToString("0.##") + " px).\nRotate the robot by a larger angle between points to increase resolution.", "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
						this.SchedulePreviewRedraw();
					}
					else
					{
						bool poorFit = tcp.CircleFitRmsPx > tcp.CircleRadiusPx * 0.25;
						this._tcpCenterCol = tcp.CircleCenterImageX;
						this._tcpCenterRow = tcp.CircleCenterImageY;
						this._tcpRadiusPx = tcp.CircleRadiusPx;
						this._hasTcpOverlay = true;
						viewModel.AddLog(0, "Save Calib", "tcp circle", poorFit ? "Warn" : "Success", string.Concat(new string[]
						{
							"TCP center at (row ",
							this._tcpCenterRow.ToString("0.#"),
							", col ",
							this._tcpCenterCol.ToString("0.#"),
							"), radius ",
							this._tcpRadiusPx.ToString("0.#"),
							" px, fit RMS ",
							tcp.CircleFitRmsPx.ToString("0.##"),
							" px."
						}));
						bool flag4 = poorFit;
						if (flag4)
						{
							DXMessageBox.Show(this, string.Concat(new string[]
							{
								"The rotation points do not lie on a clean circle (fit RMS ",
								tcp.CircleFitRmsPx.ToString("0.##"),
								" px vs radius ",
								tcp.CircleRadiusPx.ToString("0.##"),
								" px).\nThe TCP center is drawn but may be inaccurate - consider re-capturing the rotation points."
							}), "Calib Hand-Eye", MessageBoxButton.OK, MessageBoxImage.Exclamation);
						}
						this.SchedulePreviewRedraw();
					}
				}
			}
		}

		// Token: 0x06001BE3 RID: 7139 RVA: 0x0009D195 File Offset: 0x0009B395
		private void DrawArrow(double row1, double column1, double row2, double column2)
		{
			HOperatorSet.DispLine(this.HWindowCalib.HalconWindow, row1, column1, row2, column2);
			this.DrawArrowHead(row2, column2, row1, column1);
		}

		// Token: 0x06001BE4 RID: 7140 RVA: 0x0009D1D4 File Offset: 0x0009B3D4
		private void DrawArrowHead(double row, double column, double previousRow, double previousColumn)
		{
			double angle = Math.Atan2(row - previousRow, column - previousColumn);
			double headLength = 22.0;
			double headAngle = 0.4487989505128276;
			double rowA = row - headLength * Math.Sin(angle + headAngle);
			double colA = column - headLength * Math.Cos(angle + headAngle);
			double rowB = row - headLength * Math.Sin(angle - headAngle);
			double colB = column - headLength * Math.Cos(angle - headAngle);
			HOperatorSet.DispLine(this.HWindowCalib.HalconWindow, row, column, rowA, colA);
			HOperatorSet.DispLine(this.HWindowCalib.HalconWindow, row, column, rowB, colB);
		}

		// Token: 0x06001BE5 RID: 7141 RVA: 0x0009D29C File Offset: 0x0009B49C
		private void DisplayPreviewImage(HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			if (!flag)
			{
				bool flag2 = this._previewImage != null;
				if (flag2)
				{
					this._previewImage.Dispose();
				}
				this._previewImage = image;
				this._gridOverlayPoints.Clear();
				this._hasTcpOverlay = false;
				try
				{
					this.FitPreviewToWindow();
				}
				catch
				{
					this._previewImage.Dispose();
					this._previewImage = null;
				}
			}
		}

		// Token: 0x06001BE6 RID: 7142 RVA: 0x0009D328 File Offset: 0x0009B528
		private void FitPreviewToWindow()
		{
			bool flag = this._previewImage == null || !this._previewImage.IsInitialized();
			if (!flag)
			{
				HTuple width;
				HTuple height;
				HOperatorSet.GetImageSize(this._previewImage, out width, out height);
				this.HWindowCalib.HalconWindow.SetPart(0, 0, height.I - 1, width.I - 1);
				this.SchedulePreviewRedraw();
			}
		}

		// Token: 0x06001BE7 RID: 7143 RVA: 0x0009D390 File Offset: 0x0009B590
		private void EndPan()
		{
			bool flag = !this._isPanning;
			if (!flag)
			{
				this._isPanning = false;
				bool isMouseCaptured = this.HWindowCalib.IsMouseCaptured;
				if (isMouseCaptured)
				{
					this.HWindowCalib.ReleaseMouseCapture();
				}
				this.HWindowCalib.Cursor = Cursors.Arrow;
				this.SchedulePreviewRedraw();
			}
		}

		// Token: 0x06001BE8 RID: 7144 RVA: 0x0009D3E8 File Offset: 0x0009B5E8
		private void StopWorkflow()
		{
			bool flag = this._calibrationCancellation != null;
			if (flag)
			{
				this._calibrationCancellation.Cancel();
				this._calibrationCancellation.Dispose();
				this._calibrationCancellation = null;
			}
			bool flag2 = this._workflowService != null;
			if (flag2)
			{
				this._workflowService.Dispose();
				this._workflowService = null;
			}
		}

		// Token: 0x06001BE9 RID: 7145 RVA: 0x0009D448 File Offset: 0x0009B648
		private void Setting_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e.PropertyName != "CameraName";
			if (!flag)
			{
				bool flag2 = this.CalibrationSettingPropertyGrid == null;
				if (!flag2)
				{
					this.RefreshMasterToolOptionsForCurrentCamera();
				}
			}
		}

		// Token: 0x06001BEA RID: 7146 RVA: 0x0009D482 File Offset: 0x0009B682
		private void MasterToolEditor_RefreshRequested(object sender, RoutedEventArgs e)
		{
			this.RefreshMasterToolOptionsForCurrentCamera();
		}

		// Token: 0x06001BEB RID: 7147 RVA: 0x0009D48C File Offset: 0x0009B68C
		private void RefreshPropertyGrid()
		{
			bool flag = this.CalibrationSettingPropertyGrid == null;
			if (!flag)
			{
				CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
				object selectedObject = ((viewModel != null) ? viewModel.Setting : null) ?? this.CalibrationSettingPropertyGrid.SelectedObject;
				this.CalibrationSettingPropertyGrid.SelectedObject = null;
				this.CalibrationSettingPropertyGrid.SelectedObject = selectedObject;
			}
		}

		// Token: 0x06001BEC RID: 7148 RVA: 0x0009D4EC File Offset: 0x0009B6EC
		private void RefreshMasterToolOptionsForCurrentCamera()
		{
			CalibHandEyeViewModel viewModel = base.DataContext as CalibHandEyeViewModel;
			bool flag = viewModel == null;
			if (!flag)
			{
				CalibHandEyeOptionProvider.RefreshMasterToolsForCamera(viewModel.Setting.CameraName);
				bool flag2 = !CalibHandEyeOptionProvider.MasterToolOptions.Contains(viewModel.Setting.MasterToolName);
				if (flag2)
				{
					viewModel.Setting.MasterToolName = CalibHandEyeOptionProvider.GetDefaultMasterToolName();
				}
			}
		}

		// Token: 0x06001BED RID: 7149 RVA: 0x0009D550 File Offset: 0x0009B750
		private static void ApplySavedSetting(CalibHandEyeSetting setting)
		{
			bool flag = setting == null;
			if (!flag)
			{
				CalibHandEyeConfigData data = CalibHandEyeConfigStorageService.Load();
				setting.CameraName = data.CameraName;
				setting.MasterToolName = data.MasterToolName;
				setting.CommunicationName = data.CommunicationName;
				setting.CalibrationPoints = data.CalibrationPoints;
				setting.RotationPointCount = data.RotationPointCount;
			}
		}

		// Token: 0x06001BF0 RID: 7152 RVA: 0x0009D8E4 File Offset: 0x0009BAE4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 3)
			{
				((ComboBoxEdit)target).GotKeyboardFocus += new KeyboardFocusChangedEventHandler(this.MasterToolEditor_RefreshRequested);
				((ComboBoxEdit)target).MouseEnter += new MouseEventHandler(this.MasterToolEditor_RefreshRequested);
			}
		}

		// Token: 0x04000B9E RID: 2974
		private CancellationTokenSource _calibrationCancellation;

		// Token: 0x04000B9F RID: 2975
		private CalibHandEyeWorkflowService _workflowService;

		// Token: 0x04000BA0 RID: 2976
		private Task _workflowTask;

		// Token: 0x04000BA1 RID: 2977
		private HObject _previewImage;

		// Token: 0x04000BA2 RID: 2978
		private int _manualCaptureIndex = 1;

		// Token: 0x04000BA3 RID: 2979
		private bool _manualCaptureRowsReady;

		// Token: 0x04000BA4 RID: 2980
		private readonly List<CalibHandEyeWorkflowPointResult> _captureOverlayPoints = new List<CalibHandEyeWorkflowPointResult>();

		// Token: 0x04000BA5 RID: 2981
		private bool _isPanning;

		// Token: 0x04000BA6 RID: 2982
		private bool _previewRedrawQueued;

		// Token: 0x04000BA7 RID: 2983
		private bool _previewIsRedrawing;

		// Token: 0x04000BA8 RID: 2984
		private bool _hasTcpOverlay;

		// Token: 0x04000BA9 RID: 2985
		private double _tcpCenterRow;

		// Token: 0x04000BAA RID: 2986
		private double _tcpCenterCol;

		// Token: 0x04000BAB RID: 2987
		private double _tcpRadiusPx;

		// Token: 0x04000BAC RID: 2988
		private readonly List<Form_calib_handeye.CalibOverlayPoint> _gridOverlayPoints = new List<Form_calib_handeye.CalibOverlayPoint>();

		// Token: 0x04000BAD RID: 2989
		private DateTime _lastPreviewPixelInspectorUpdateUtc = DateTime.MinValue;

		// Token: 0x04000BAE RID: 2990
		private Point _lastPanPosition;

		// Token: 0x04000BAF RID: 2991
		private TcpCalibrationResult _lastTcpResult;

		// Token: 0x04000BB0 RID: 2992
		private readonly PlcCommunicationService _calibrationControlCommunicationService = SharedCommunicationService.Instance;

		// Token: 0x04000BB1 RID: 2993
		private const string CalibrationStartTagName = "calibration start";

		// Token: 0x0200041E RID: 1054
		private sealed class CalibOverlayPoint
		{
			// Token: 0x040014E0 RID: 5344
			public double Row;

			// Token: 0x040014E1 RID: 5345
			public double Col;

			// Token: 0x040014E2 RID: 5346
			public int Index;

			// Token: 0x040014E3 RID: 5347
			public bool IsRotation;
		}
	}
}
