﻿using System;
using System.ComponentModel;
using System.Linq;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001C9 RID: 457
	public class CalibCameraOptionConverter : StringConverter
	{
		// Token: 0x06001C3A RID: 7226 RVA: 0x0009F08C File Offset: 0x0009D28C
		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;
		}

		// Token: 0x06001C3B RID: 7227 RVA: 0x0009F08C File Offset: 0x0009D28C
		public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
		{
			return true;
		}

		// Token: 0x06001C3C RID: 7228 RVA: 0x0009F090 File Offset: 0x0009D290
		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			return new TypeConverter.StandardValuesCollection(CalibHandEyeOptionProvider.CameraOptions.ToList<string>());
		}
	}
}
