﻿using System;
using System.ComponentModel;
using System.Linq;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001CB RID: 459
	public class CalibCommunicationOptionConverter : StringConverter
	{
		// Token: 0x06001C42 RID: 7234 RVA: 0x0009F08C File Offset: 0x0009D28C
		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;
		}

		// Token: 0x06001C43 RID: 7235 RVA: 0x0009F08C File Offset: 0x0009D28C
		public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
		{
			return true;
		}

		// Token: 0x06001C44 RID: 7236 RVA: 0x0009F0E0 File Offset: 0x0009D2E0
		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			return new TypeConverter.StandardValuesCollection(CalibHandEyeOptionProvider.CommunicationOptions.ToList<string>());
		}
	}
}
