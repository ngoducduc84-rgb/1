﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Communication;
using VisionMachine.Models.Recipe;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Communication;
using VisionMachine.Services.Recipe;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Main;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001C8 RID: 456
	public static class CalibHandEyeOptionProvider
	{
		// Token: 0x1400002F RID: 47
		// (add) Token: 0x06001C2D RID: 7213 RVA: 0x0009E978 File Offset: 0x0009CB78
		// (remove) Token: 0x06001C2E RID: 7214 RVA: 0x0009E9AC File Offset: 0x0009CBAC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler OptionsSourceChanged;

		// Token: 0x170008F0 RID: 2288
		// (get) Token: 0x06001C2F RID: 7215 RVA: 0x0009E9DF File Offset: 0x0009CBDF
		// (set) Token: 0x06001C30 RID: 7216 RVA: 0x0009E9E6 File Offset: 0x0009CBE6
		public static Action ActiveRefreshRequest { get; set; }

		// Token: 0x06001C31 RID: 7217 RVA: 0x0009E9F0 File Offset: 0x0009CBF0
		public static void Refresh()
		{
			CalibHandEyeOptionProvider.CameraOptions.Clear();
			CalibHandEyeOptionProvider.CameraOptions.Add("None");
			MainWindow instance = MainWindow.instance;
			MainViewModel viewModel = (instance != null) ? instance.MainViewModel : null;
			bool flag = ((viewModel != null) ? viewModel.Cameras : null) != null;
			if (flag)
			{
				foreach (CameraNode camera in viewModel.Cameras)
				{
					string text;
					if (camera == null)
					{
						text = null;
					}
					else
					{
						CameraItem cameraInfo = camera.CameraInfo;
						text = ((cameraInfo != null) ? cameraInfo.CameraName : null);
					}
					string name = text;
					CalibHandEyeOptionProvider.AddOption(CalibHandEyeOptionProvider.CameraOptions, name);
				}
			}
			foreach (CameraItem camera2 in CameraRuntimeStore.Cameras)
			{
				CalibHandEyeOptionProvider.AddOption(CalibHandEyeOptionProvider.CameraOptions, (camera2 != null) ? camera2.CameraName : null);
			}
			RecipeConfig recipe = CalibHandEyeOptionProvider.LoadCurrentRecipe();
			bool flag2 = ((recipe != null) ? recipe.Cameras : null) != null;
			if (flag2)
			{
				foreach (CameraRecipeConfig camera3 in recipe.Cameras)
				{
					CalibHandEyeOptionProvider.AddOption(CalibHandEyeOptionProvider.CameraOptions, (camera3 != null) ? camera3.CameraName : null);
				}
			}
			CalibHandEyeOptionProvider.CommunicationOptions.Clear();
			CalibHandEyeOptionProvider.CommunicationOptions.Add("None");
			foreach (CommunicationConnection connection in CommunicationConfigStorageService.LoadConfig(null).Connections)
			{
				CalibHandEyeOptionProvider.AddOption(CalibHandEyeOptionProvider.CommunicationOptions, connection.Name);
			}
			CalibHandEyeOptionProvider.RefreshMasterToolsForCamera(CalibHandEyeOptionProvider.CameraOptions.FirstOrDefault<string>());
		}

		// Token: 0x06001C32 RID: 7218 RVA: 0x0009EBF4 File Offset: 0x0009CDF4
		public static void RefreshMasterToolsForCamera(string cameraName)
		{
			CalibHandEyeOptionProvider.MasterToolOptions.Clear();
			CalibHandEyeOptionProvider.MasterToolOptions.Add("None");
			MainWindow instance = MainWindow.instance;
			CameraNode cameraNode;
			if (instance == null)
			{
				cameraNode = null;
			}
			else
			{
				MainViewModel mainViewModel = instance.MainViewModel;
				if (mainViewModel == null)
				{
					cameraNode = null;
				}
				else
				{
					ObservableCollection<CameraNode> cameras = mainViewModel.Cameras;
					cameraNode = ((cameras != null) ? cameras.FirstOrDefault(delegate(CameraNode x)
					{
						string a;
						if (x == null)
						{
							a = null;
						}
						else
						{
							CameraItem cameraInfo = x.CameraInfo;
							a = ((cameraInfo != null) ? cameraInfo.CameraName : null);
						}
						return string.Equals(a, cameraName, StringComparison.OrdinalIgnoreCase);
					}) : null);
				}
			}
			CameraNode camera = cameraNode;
			bool flag = ((camera != null) ? camera.TurnSnaps : null) != null;
			if (flag)
			{
				foreach (TurnSnap turnSnap in from x in camera.TurnSnaps
				orderby x.Index
				select x)
				{
					IEnumerable<ToolVision> tools = turnSnap.Tools;
					foreach (ToolVision tool in (tools ?? Enumerable.Empty<ToolVision>()).OrderBy((ToolVision x) => x.Index))
					{
						CalibHandEyeOptionProvider.AddMasterToolOption(turnSnap.DisplayName, tool);
					}
				}
			}
			RecipeConfig recipe = CalibHandEyeOptionProvider.LoadCurrentRecipe();
			CameraRecipeConfig cameraRecipeConfig;
			if (recipe == null)
			{
				cameraRecipeConfig = null;
			}
			else
			{
				List<CameraRecipeConfig> cameras2 = recipe.Cameras;
				cameraRecipeConfig = ((cameras2 != null) ? cameras2.FirstOrDefault((CameraRecipeConfig x) => string.Equals(x.CameraName, cameraName, StringComparison.OrdinalIgnoreCase)) : null);
			}
			CameraRecipeConfig cameraRecipe = cameraRecipeConfig;
			bool flag2 = ((cameraRecipe != null) ? cameraRecipe.TurnSnaps : null) == null;
			if (!flag2)
			{
				foreach (TurnSnapRecipeConfig turnSnap2 in from x in cameraRecipe.TurnSnaps
				orderby x.Index
				select x)
				{
					IEnumerable<ToolRecipeConfig> tools2 = turnSnap2.Tools;
					foreach (ToolRecipeConfig tool2 in (tools2 ?? Enumerable.Empty<ToolRecipeConfig>()).OrderBy((ToolRecipeConfig x) => x.Index))
					{
						CalibHandEyeOptionProvider.AddMasterToolOption(string.Format("TurnSnap {0}", turnSnap2.Index), tool2);
					}
				}
			}
		}

		// Token: 0x06001C33 RID: 7219 RVA: 0x0009EEA4 File Offset: 0x0009D0A4
		public static string GetDefaultMasterToolName()
		{
			return CalibHandEyeOptionProvider.MasterToolOptions.FirstOrDefault((string x) => x != "None") ?? "None";
		}

		// Token: 0x06001C34 RID: 7220 RVA: 0x0009EEE8 File Offset: 0x0009D0E8
		public static void NotifyOptionsSourceChanged()
		{
			EventHandler handler = CalibHandEyeOptionProvider.OptionsSourceChanged;
			bool flag = handler != null;
			if (flag)
			{
				handler(null, EventArgs.Empty);
			}
			Action refreshRequest = CalibHandEyeOptionProvider.ActiveRefreshRequest;
			bool flag2 = refreshRequest != null;
			if (flag2)
			{
				refreshRequest();
			}
		}

		// Token: 0x06001C35 RID: 7221 RVA: 0x0009EF28 File Offset: 0x0009D128
		private static void AddMasterToolOption(string turnSnapName, ToolVision tool)
		{
			bool flag = tool == null;
			if (!flag)
			{
				bool flag2 = tool.ToolType != ToolType.Shape_model && tool.ToolType != ToolType.AnisoShapeModel && tool.ToolType != ToolType.OverlappingShapeModel && tool.ToolType != ToolType.BoundingBoxMaster && tool.ToolType != ToolType.MinAreaMaster;
				if (!flag2)
				{
					CalibHandEyeOptionProvider.AddOption(CalibHandEyeOptionProvider.MasterToolOptions, turnSnapName + " - " + tool.Name);
				}
			}
		}

		// Token: 0x06001C36 RID: 7222 RVA: 0x0009EF9C File Offset: 0x0009D19C
		private static void AddMasterToolOption(string turnSnapName, ToolRecipeConfig tool)
		{
			bool flag = tool == null;
			if (!flag)
			{
				ToolType toolType;
				bool flag2 = !Enum.TryParse<ToolType>(tool.ToolType, out toolType);
				if (!flag2)
				{
					bool flag3 = toolType != ToolType.Shape_model && toolType != ToolType.AnisoShapeModel && toolType != ToolType.OverlappingShapeModel && toolType != ToolType.BoundingBoxMaster && toolType != ToolType.MinAreaMaster;
					if (!flag3)
					{
						CalibHandEyeOptionProvider.AddOption(CalibHandEyeOptionProvider.MasterToolOptions, turnSnapName + " - " + tool.Name);
					}
				}
			}
		}

		// Token: 0x06001C37 RID: 7223 RVA: 0x0009F00C File Offset: 0x0009D20C
		private static void AddOption(ObservableCollection<string> options, string value)
		{
			bool flag = !string.IsNullOrWhiteSpace(value) && !options.Contains(value);
			if (flag)
			{
				options.Add(value);
			}
		}

		// Token: 0x06001C38 RID: 7224 RVA: 0x0009F040 File Offset: 0x0009D240
		private static RecipeConfig LoadCurrentRecipe()
		{
			string path = RecipePathService.GetCurrentModelRecipeJsonPath();
			bool flag = string.IsNullOrWhiteSpace(path);
			RecipeConfig result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = RecipeStorageService.Load(path);
			}
			return result;
		}

		// Token: 0x04000BCE RID: 3022
		public static readonly ObservableCollection<string> CameraOptions = new ObservableCollection<string>();

		// Token: 0x04000BCF RID: 3023
		public static readonly ObservableCollection<string> MasterToolOptions = new ObservableCollection<string>();

		// Token: 0x04000BD0 RID: 3024
		public static readonly ObservableCollection<string> CommunicationOptions = new ObservableCollection<string>();
	}
}
