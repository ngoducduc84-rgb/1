﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001C7 RID: 455
	public class CalibHandEyeSetting : INotifyPropertyChanged
	{
		// Token: 0x1400002E RID: 46
		// (add) Token: 0x06001C1B RID: 7195 RVA: 0x0009E67C File Offset: 0x0009C87C
		// (remove) Token: 0x06001C1C RID: 7196 RVA: 0x0009E6B4 File Offset: 0x0009C8B4
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x170008E9 RID: 2281
		// (get) Token: 0x06001C1D RID: 7197 RVA: 0x0009E6EC File Offset: 0x0009C8EC
		// (set) Token: 0x06001C1E RID: 7198 RVA: 0x0009E704 File Offset: 0x0009C904
		[Category("Source")]
		[DisplayName("Camera")]
		[TypeConverter(typeof(CalibCameraOptionConverter))]
		public string CameraName
		{
			get
			{
				return this._cameraName;
			}
			set
			{
				bool flag = this.SetValue<string>(ref this._cameraName, value, "CameraName");
				if (flag)
				{
					CalibHandEyeOptionProvider.RefreshMasterToolsForCamera(value);
					bool flag2 = this.MasterToolName == "None" || !CalibHandEyeOptionProvider.MasterToolOptions.Contains(this.MasterToolName);
					if (flag2)
					{
						this.MasterToolName = CalibHandEyeOptionProvider.GetDefaultMasterToolName();
					}
				}
			}
		}

		// Token: 0x170008EA RID: 2282
		// (get) Token: 0x06001C1F RID: 7199 RVA: 0x0009E76C File Offset: 0x0009C96C
		// (set) Token: 0x06001C20 RID: 7200 RVA: 0x0009E784 File Offset: 0x0009C984
		[Category("Source")]
		[DisplayName("Master Tool")]
		[Description("Shape Model, Bounding Box Master, or Min Area Master in TurnSnap of the selected camera.")]
		[TypeConverter(typeof(CalibMasterToolOptionConverter))]
		public string MasterToolName
		{
			get
			{
				return this._masterToolName;
			}
			set
			{
				this.SetValue<string>(ref this._masterToolName, value, "MasterToolName");
			}
		}

		// Token: 0x170008EB RID: 2283
		// (get) Token: 0x06001C21 RID: 7201 RVA: 0x0009E79C File Offset: 0x0009C99C
		// (set) Token: 0x06001C22 RID: 7202 RVA: 0x0009E7B4 File Offset: 0x0009C9B4
		[Category("Source")]
		[DisplayName("Communication")]
		[TypeConverter(typeof(CalibCommunicationOptionConverter))]
		public string CommunicationName
		{
			get
			{
				return this._communicationName;
			}
			set
			{
				this.SetValue<string>(ref this._communicationName, value, "CommunicationName");
			}
		}

		// Token: 0x170008EC RID: 2284
		// (get) Token: 0x06001C23 RID: 7203 RVA: 0x0009E7CC File Offset: 0x0009C9CC
		// (set) Token: 0x06001C24 RID: 7204 RVA: 0x0009E7E4 File Offset: 0x0009C9E4
		[Category("Calibration Points")]
		[DisplayName("Position Points")]
		public int CalibrationPoints
		{
			get
			{
				return this._calibrationPoints;
			}
			set
			{
				int normalizedValue = Math.Max(4, Math.Min(30, value));
				bool flag = this.SetValue<int>(ref this._calibrationPoints, normalizedValue, "CalibrationPoints");
				if (flag)
				{
					this.OnPropertyChanged("TotalPointCount");
				}
			}
		}

		// Token: 0x170008ED RID: 2285
		// (get) Token: 0x06001C25 RID: 7205 RVA: 0x0009E824 File Offset: 0x0009CA24
		// (set) Token: 0x06001C26 RID: 7206 RVA: 0x0009E83C File Offset: 0x0009CA3C
		[Category("Calibration Points")]
		[DisplayName("Rotation Points")]
		public int RotationPointCount
		{
			get
			{
				return this._rotationPointCount;
			}
			set
			{
				bool flag = this.SetValue<int>(ref this._rotationPointCount, Math.Max(0, Math.Min(360, value)), "RotationPointCount");
				if (flag)
				{
					this.OnPropertyChanged("TotalPointCount");
				}
			}
		}

		// Token: 0x170008EE RID: 2286
		// (get) Token: 0x06001C27 RID: 7207 RVA: 0x0009E87C File Offset: 0x0009CA7C
		[Browsable(false)]
		public int TotalPointCount
		{
			get
			{
				return this.CalibrationPoints + this.RotationPointCount;
			}
		}

		// Token: 0x170008EF RID: 2287
		// (get) Token: 0x06001C28 RID: 7208 RVA: 0x0009E89C File Offset: 0x0009CA9C
		// (set) Token: 0x06001C29 RID: 7209 RVA: 0x0009E8B4 File Offset: 0x0009CAB4
		[Category("Calibration Points")]
		[DisplayName("Apply TCP To Mapping")]
		[Description("Compute the TCP center from the rotation points first and remove it from the 9-point mapping H, so H does not carry the tool offset (keeps Delta X/Y/Angle accurate for large rotations).")]
		public bool ApplyTcpToMapping
		{
			get
			{
				return this._applyTcpToMapping;
			}
			set
			{
				this.SetValue<bool>(ref this._applyTcpToMapping, value, "ApplyTcpToMapping");
			}
		}

		// Token: 0x06001C2A RID: 7210 RVA: 0x0009E8CC File Offset: 0x0009CACC
		private bool SetValue<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
		{
			bool flag = object.Equals(field, value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				field = value;
				this.OnPropertyChanged(propertyName);
				result = true;
			}
			return result;
		}

		// Token: 0x06001C2B RID: 7211 RVA: 0x0009E90C File Offset: 0x0009CB0C
		private void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler handler = this.PropertyChanged;
			bool flag = handler != null;
			if (flag)
			{
				handler(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000BC5 RID: 3013
		private string _cameraName = "None";

		// Token: 0x04000BC6 RID: 3014
		private string _masterToolName = "None";

		// Token: 0x04000BC7 RID: 3015
		private string _communicationName = "None";

		// Token: 0x04000BC8 RID: 3016
		private int _calibrationPoints = 12;

		// Token: 0x04000BC9 RID: 3017
		private int _rotationPointCount = 0;

		// Token: 0x04000BCA RID: 3018
		private bool _applyTcpToMapping = true;
	}
}
