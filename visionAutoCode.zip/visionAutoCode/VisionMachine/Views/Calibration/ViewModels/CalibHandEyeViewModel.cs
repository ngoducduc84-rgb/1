﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using VisionMachine.Services.Calibration;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001C6 RID: 454
	public class CalibHandEyeViewModel : INotifyPropertyChanged
	{
		// Token: 0x170008DA RID: 2266
		// (get) Token: 0x06001BF3 RID: 7155 RVA: 0x0009D9A6 File Offset: 0x0009BBA6
		public CalibHandEyeSetting Setting { get; } = new CalibHandEyeSetting();

		// Token: 0x06001BF4 RID: 7156 RVA: 0x0009D9B0 File Offset: 0x0009BBB0
		public CalibHandEyeViewModel()
		{
			this.Setting.PropertyChanged += this.Setting_PropertyChanged;
		}

		// Token: 0x170008DB RID: 2267
		// (get) Token: 0x06001BF5 RID: 7157 RVA: 0x0009DA3C File Offset: 0x0009BC3C
		public ObservableCollection<string> CameraOptions
		{
			get
			{
				return CalibHandEyeOptionProvider.CameraOptions;
			}
		}

		// Token: 0x170008DC RID: 2268
		// (get) Token: 0x06001BF6 RID: 7158 RVA: 0x0009DA54 File Offset: 0x0009BC54
		public ObservableCollection<string> MasterToolOptions
		{
			get
			{
				return CalibHandEyeOptionProvider.MasterToolOptions;
			}
		}

		// Token: 0x170008DD RID: 2269
		// (get) Token: 0x06001BF7 RID: 7159 RVA: 0x0009DA6C File Offset: 0x0009BC6C
		public ObservableCollection<string> CommunicationOptions
		{
			get
			{
				return CalibHandEyeOptionProvider.CommunicationOptions;
			}
		}

		// Token: 0x170008DE RID: 2270
		// (get) Token: 0x06001BF8 RID: 7160 RVA: 0x0009DA83 File Offset: 0x0009BC83
		public ObservableCollection<RobotPoseRow> RobotPoints { get; } = new ObservableCollection<RobotPoseRow>();

		// Token: 0x170008DF RID: 2271
		// (get) Token: 0x06001BF9 RID: 7161 RVA: 0x0009DA8B File Offset: 0x0009BC8B
		public ObservableCollection<VisionPointRow> VisionPoints { get; } = new ObservableCollection<VisionPointRow>();

		// Token: 0x170008E0 RID: 2272
		// (get) Token: 0x06001BFA RID: 7162 RVA: 0x0009DA93 File Offset: 0x0009BC93
		public ObservableCollection<CalibrationLogRow> LogRows { get; } = new ObservableCollection<CalibrationLogRow>();

		// Token: 0x170008E1 RID: 2273
		// (get) Token: 0x06001BFB RID: 7163 RVA: 0x0009DA9C File Offset: 0x0009BC9C
		// (set) Token: 0x06001BFC RID: 7164 RVA: 0x0009DAB9 File Offset: 0x0009BCB9
		public int CalibrationPointCount
		{
			get
			{
				return this.Setting.TotalPointCount;
			}
			set
			{
				this.Setting.CalibrationPoints = value;
				this.OnPropertyChanged("CalibrationPointCount");
				this.OnPropertyChanged("SelectedPointText");
			}
		}

		// Token: 0x170008E2 RID: 2274
		// (get) Token: 0x06001BFD RID: 7165 RVA: 0x0009DAE1 File Offset: 0x0009BCE1
		// (set) Token: 0x06001BFE RID: 7166 RVA: 0x0009DAE9 File Offset: 0x0009BCE9
		public int CurrentPointIndex { get; private set; } = 1;

		// Token: 0x170008E3 RID: 2275
		// (get) Token: 0x06001BFF RID: 7167 RVA: 0x0009DAF4 File Offset: 0x0009BCF4
		public string SelectedPointText
		{
			get
			{
				return this.CurrentPointIndex.ToString() + " / " + this.CalibrationPointCount.ToString();
			}
		}

		// Token: 0x170008E4 RID: 2276
		// (get) Token: 0x06001C00 RID: 7168 RVA: 0x0009DB2C File Offset: 0x0009BD2C
		// (set) Token: 0x06001C01 RID: 7169 RVA: 0x0009DB34 File Offset: 0x0009BD34
		public string SelectedPointStatus { get; set; } = "Ready";

		// Token: 0x170008E5 RID: 2277
		// (get) Token: 0x06001C02 RID: 7170 RVA: 0x0009DB3D File Offset: 0x0009BD3D
		// (set) Token: 0x06001C03 RID: 7171 RVA: 0x0009DB45 File Offset: 0x0009BD45
		public string CalibrationStatus { get; set; } = "Idle";

		// Token: 0x170008E6 RID: 2278
		// (get) Token: 0x06001C04 RID: 7172 RVA: 0x0009DB4E File Offset: 0x0009BD4E
		// (set) Token: 0x06001C05 RID: 7173 RVA: 0x0009DB56 File Offset: 0x0009BD56
		public string RmsError { get; set; } = "-";

		// Token: 0x170008E7 RID: 2279
		// (get) Token: 0x06001C06 RID: 7174 RVA: 0x0009DB5F File Offset: 0x0009BD5F
		// (set) Token: 0x06001C07 RID: 7175 RVA: 0x0009DB67 File Offset: 0x0009BD67
		public string ReprojectionError { get; set; } = "-";

		// Token: 0x170008E8 RID: 2280
		// (get) Token: 0x06001C08 RID: 7176 RVA: 0x0009DB70 File Offset: 0x0009BD70
		// (set) Token: 0x06001C09 RID: 7177 RVA: 0x0009DB78 File Offset: 0x0009BD78
		public HandEyeCalibrationResult LastResult { get; private set; }

		// Token: 0x06001C0A RID: 7178 RVA: 0x0009DB84 File Offset: 0x0009BD84
		public void PrepareCalibrationRows()
		{
			this.RobotPoints.Clear();
			this.VisionPoints.Clear();
			for (int i = 1; i <= this.CalibrationPointCount; i++)
			{
				this.RobotPoints.Add(new RobotPoseRow
				{
					Index = i,
					Status = "Pending"
				});
				this.VisionPoints.Add(new VisionPointRow
				{
					Index = i,
					Status = "Pending"
				});
			}
			this.CurrentPointIndex = 1;
			this.SelectedPointStatus = "Ready";
			this.CalibrationStatus = "Running";
			this.OnPropertyChanged("CurrentPointIndex");
			this.OnPropertyChanged("SelectedPointStatus");
			this.OnPropertyChanged("CalibrationStatus");
			this.OnPropertyChanged("SelectedPointText");
		}

		// Token: 0x06001C0B RID: 7179 RVA: 0x0009DC5E File Offset: 0x0009BE5E
		public void SetCurrentPoint(int index)
		{
			this.CurrentPointIndex = Math.Max(1, Math.Min(this.CalibrationPointCount, index));
			this.OnPropertyChanged("CurrentPointIndex");
			this.OnPropertyChanged("SelectedPointText");
		}

		// Token: 0x06001C0C RID: 7180 RVA: 0x0009DC94 File Offset: 0x0009BE94
		public void UpdatePoint(int index, double robotX, double robotY, double robotRz, double imageX, double imageY, double angle, double score, bool isSuccess)
		{
			RobotPoseRow robot = this.RobotPoints.FirstOrDefault((RobotPoseRow x) => x.Index == index);
			bool flag = robot == null;
			if (flag)
			{
				robot = new RobotPoseRow
				{
					Index = index
				};
				this.RobotPoints.Add(robot);
			}
			robot.X = robotX;
			robot.Y = robotY;
			robot.Z = 0.0;
			robot.Rx = 0.0;
			robot.Ry = 0.0;
			robot.Rz = robotRz;
			robot.Status = (isSuccess ? "Ready" : "Fail");
			VisionPointRow vision = this.VisionPoints.FirstOrDefault((VisionPointRow x) => x.Index == index);
			bool flag2 = vision == null;
			if (flag2)
			{
				vision = new VisionPointRow
				{
					Index = index
				};
				this.VisionPoints.Add(vision);
			}
			vision.ImageX = imageX;
			vision.ImageY = imageY;
			vision.Angle = angle;
			vision.Score = score;
			vision.Status = (isSuccess ? "Success" : "Fail");
			this.SelectedPointStatus = (isSuccess ? "Success" : "Fail");
			this.CurrentPointIndex = Math.Max(1, Math.Min(this.CalibrationPointCount, index));
			this.OnPropertyChanged("CurrentPointIndex");
			this.OnPropertyChanged("SelectedPointStatus");
			this.OnPropertyChanged("SelectedPointText");
			this.RefreshGridBindings();
		}

		// Token: 0x06001C0D RID: 7181 RVA: 0x0009DE30 File Offset: 0x0009C030
		public void UpdateRobotPoint(int index, double robotX, double robotY, double robotRz, bool isSuccess)
		{
			RobotPoseRow robot = this.RobotPoints.FirstOrDefault((RobotPoseRow x) => x.Index == index);
			bool flag = robot == null;
			if (flag)
			{
				robot = new RobotPoseRow
				{
					Index = index
				};
				this.RobotPoints.Add(robot);
			}
			robot.X = robotX;
			robot.Y = robotY;
			robot.Z = 0.0;
			robot.Rx = 0.0;
			robot.Ry = 0.0;
			robot.Rz = robotRz;
			robot.Status = (isSuccess ? "Ready" : "Fail");
			this.CurrentPointIndex = Math.Max(1, Math.Min(this.CalibrationPointCount, index));
			this.OnPropertyChanged("CurrentPointIndex");
			this.OnPropertyChanged("SelectedPointText");
			this.RefreshGridBindings();
		}

		// Token: 0x06001C0E RID: 7182 RVA: 0x0009DF2A File Offset: 0x0009C12A
		public void SetCalibrationStatus(string status)
		{
			this.CalibrationStatus = status;
			this.OnPropertyChanged("CalibrationStatus");
		}

		// Token: 0x06001C0F RID: 7183 RVA: 0x0009DF44 File Offset: 0x0009C144
		public void SetCalibrationResult(HandEyeCalibrationResult result)
		{
			this.LastResult = result;
			bool flag = result != null && result.IsSuccess;
			if (flag)
			{
				this.RmsError = result.RmsErrorMm.ToString("0.####");
				this.ReprojectionError = result.ReprojectionErrorPx.ToString("0.####");
				this.CalibrationStatus = "Calibrated";
			}
			else
			{
				this.RmsError = "-";
				this.ReprojectionError = "-";
				this.CalibrationStatus = "Calibration failed";
			}
			this.OnPropertyChanged("RmsError");
			this.OnPropertyChanged("ReprojectionError");
			this.OnPropertyChanged("CalibrationStatus");
		}

		// Token: 0x06001C10 RID: 7184 RVA: 0x0009DFF8 File Offset: 0x0009C1F8
		public List<HandEyeSamplePoint> BuildSamplePoints()
		{
			List<HandEyeSamplePoint> samples = new List<HandEyeSamplePoint>();
			using (IEnumerator<VisionPointRow> enumerator = this.VisionPoints.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					VisionPointRow vision = enumerator.Current;
					RobotPoseRow robot = this.RobotPoints.FirstOrDefault((RobotPoseRow x) => x.Index == vision.Index);
					bool flag = robot == null;
					if (!flag)
					{
						bool isValid = !string.Equals(vision.Status, "Fail", StringComparison.OrdinalIgnoreCase) && !string.Equals(vision.Status, "Pending", StringComparison.OrdinalIgnoreCase);
						samples.Add(new HandEyeSamplePoint
						{
							Index = vision.Index,
							ImageX = vision.ImageX,
							ImageY = vision.ImageY,
							VisionAngle = vision.Angle,
							RobotX = robot.X,
							RobotY = robot.Y,
							RobotRz = robot.Rz,
							IsValid = isValid
						});
					}
				}
			}
			return samples;
		}

		// Token: 0x06001C11 RID: 7185 RVA: 0x0009E150 File Offset: 0x0009C350
		public List<HandEyeSamplePoint> BuildMappingSamples()
		{
			int positionCount = this.Setting.CalibrationPoints;
			return (from x in this.BuildSamplePoints()
			where x.Index <= positionCount
			select x).ToList<HandEyeSamplePoint>();
		}

		// Token: 0x06001C12 RID: 7186 RVA: 0x0009E198 File Offset: 0x0009C398
		public List<HandEyeSamplePoint> BuildRotationSamples()
		{
			int positionCount = this.Setting.CalibrationPoints;
			return (from x in this.BuildSamplePoints()
			where x.Index > positionCount
			select x).ToList<HandEyeSamplePoint>();
		}

		// Token: 0x06001C13 RID: 7187 RVA: 0x0009E1E0 File Offset: 0x0009C3E0
		public void LoadPoints(IEnumerable<RobotPoseRow> robotPoints, IEnumerable<VisionPointRow> visionPoints)
		{
			this.RobotPoints.Clear();
			foreach (RobotPoseRow robot in (robotPoints ?? Enumerable.Empty<RobotPoseRow>()))
			{
				bool flag = robot != null;
				if (flag)
				{
					this.RobotPoints.Add(robot);
				}
			}
			this.VisionPoints.Clear();
			foreach (VisionPointRow vision in (visionPoints ?? Enumerable.Empty<VisionPointRow>()))
			{
				bool flag2 = vision != null;
				if (flag2)
				{
					this.VisionPoints.Add(vision);
				}
			}
			this.CurrentPointIndex = 1;
			this.OnPropertyChanged("CurrentPointIndex");
			this.OnPropertyChanged("SelectedPointText");
			this.RefreshGridBindings();
		}

		// Token: 0x06001C14 RID: 7188 RVA: 0x0009E2DC File Offset: 0x0009C4DC
		public void AddLog(int point, string action, string robotCommand, string result, string message)
		{
			this.LogRows.Add(new CalibrationLogRow
			{
				Time = DateTime.Now.ToString("HH:mm:ss"),
				Point = point,
				Action = action,
				RobotCommand = robotCommand,
				Result = result,
				Message = message
			});
		}

		// Token: 0x06001C15 RID: 7189 RVA: 0x0009E340 File Offset: 0x0009C540
		public void LoadSampleData()
		{
			this.RobotPoints.Clear();
			this.VisionPoints.Clear();
			this.LogRows.Clear();
			for (int i = 1; i <= this.CalibrationPointCount; i++)
			{
				this.RobotPoints.Add(new RobotPoseRow
				{
					Index = i,
					X = 300.0 + (double)i * 2.5,
					Y = 150.0 + (double)i * 4.2,
					Z = 250.0,
					Rx = 180.0,
					Ry = 0.0,
					Rz = (double)((i - 1) * 30),
					Status = "Ready"
				});
				this.VisionPoints.Add(new VisionPointRow
				{
					Index = i,
					ImageX = 123.456 + (double)i * 0.12,
					ImageY = 78.912 + (double)i * 0.09,
					Score = 0.985,
					Status = "Pending"
				});
			}
			this.LogRows.Add(new CalibrationLogRow
			{
				Time = DateTime.Now.ToString("HH:mm:ss"),
				Point = 1,
				Action = "Move Robot",
				RobotCommand = "MOVJ P1",
				Result = "Success",
				Message = "Move to point 1"
			});
			this.LogRows.Add(new CalibrationLogRow
			{
				Time = DateTime.Now.ToString("HH:mm:ss"),
				Point = 1,
				Action = "Capture Image",
				RobotCommand = "Trigger Camera",
				Result = "Success",
				Message = "Image captured"
			});
		}

		// Token: 0x1400002D RID: 45
		// (add) Token: 0x06001C16 RID: 7190 RVA: 0x0009E564 File Offset: 0x0009C764
		// (remove) Token: 0x06001C17 RID: 7191 RVA: 0x0009E59C File Offset: 0x0009C79C
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06001C18 RID: 7192 RVA: 0x0009E5D1 File Offset: 0x0009C7D1
		private void RefreshGridBindings()
		{
			this.OnPropertyChanged("RobotPoints");
			this.OnPropertyChanged("VisionPoints");
		}

		// Token: 0x06001C19 RID: 7193 RVA: 0x0009E5EC File Offset: 0x0009C7EC
		private void Setting_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e.PropertyName != "CalibrationPoints" && e.PropertyName != "RotationPointCount" && e.PropertyName != "TotalPointCount";
			if (!flag)
			{
				this.OnPropertyChanged("CalibrationPointCount");
				this.OnPropertyChanged("SelectedPointText");
			}
		}

		// Token: 0x06001C1A RID: 7194 RVA: 0x0009E650 File Offset: 0x0009C850
		private void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler handler = this.PropertyChanged;
			bool flag = handler != null;
			if (flag)
			{
				handler(this, new PropertyChangedEventArgs(propertyName));
			}
		}
	}
}
