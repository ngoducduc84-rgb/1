﻿using System;
using System.ComponentModel;
using System.Linq;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001CA RID: 458
	public class CalibMasterToolOptionConverter : StringConverter
	{
		// Token: 0x06001C3E RID: 7230 RVA: 0x0009F08C File Offset: 0x0009D28C
		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;
		}

		// Token: 0x06001C3F RID: 7231 RVA: 0x0009F08C File Offset: 0x0009D28C
		public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
		{
			return true;
		}

		// Token: 0x06001C40 RID: 7232 RVA: 0x0009F0BC File Offset: 0x0009D2BC
		public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			return new TypeConverter.StandardValuesCollection(CalibHandEyeOptionProvider.MasterToolOptions.ToList<string>());
		}
	}
}
