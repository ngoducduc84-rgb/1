﻿using System;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001CF RID: 463
	public class CalibrationLogRow
	{
		// Token: 0x170008FF RID: 2303
		// (get) Token: 0x06001C68 RID: 7272 RVA: 0x0009F471 File Offset: 0x0009D671
		// (set) Token: 0x06001C69 RID: 7273 RVA: 0x0009F479 File Offset: 0x0009D679
		public string Time { get; set; }

		// Token: 0x17000900 RID: 2304
		// (get) Token: 0x06001C6A RID: 7274 RVA: 0x0009F482 File Offset: 0x0009D682
		// (set) Token: 0x06001C6B RID: 7275 RVA: 0x0009F48A File Offset: 0x0009D68A
		public int Point { get; set; }

		// Token: 0x17000901 RID: 2305
		// (get) Token: 0x06001C6C RID: 7276 RVA: 0x0009F493 File Offset: 0x0009D693
		// (set) Token: 0x06001C6D RID: 7277 RVA: 0x0009F49B File Offset: 0x0009D69B
		public string Action { get; set; }

		// Token: 0x17000902 RID: 2306
		// (get) Token: 0x06001C6E RID: 7278 RVA: 0x0009F4A4 File Offset: 0x0009D6A4
		// (set) Token: 0x06001C6F RID: 7279 RVA: 0x0009F4AC File Offset: 0x0009D6AC
		public string RobotCommand { get; set; }

		// Token: 0x17000903 RID: 2307
		// (get) Token: 0x06001C70 RID: 7280 RVA: 0x0009F4B5 File Offset: 0x0009D6B5
		// (set) Token: 0x06001C71 RID: 7281 RVA: 0x0009F4BD File Offset: 0x0009D6BD
		public string Result { get; set; }

		// Token: 0x17000904 RID: 2308
		// (get) Token: 0x06001C72 RID: 7282 RVA: 0x0009F4C6 File Offset: 0x0009D6C6
		// (set) Token: 0x06001C73 RID: 7283 RVA: 0x0009F4CE File Offset: 0x0009D6CE
		public string Message { get; set; }
	}
}
