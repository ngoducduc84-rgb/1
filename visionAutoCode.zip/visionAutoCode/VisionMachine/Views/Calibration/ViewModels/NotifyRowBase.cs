﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001CE RID: 462
	public abstract class NotifyRowBase : INotifyPropertyChanged
	{
		// Token: 0x14000030 RID: 48
		// (add) Token: 0x06001C64 RID: 7268 RVA: 0x0009F3AC File Offset: 0x0009D5AC
		// (remove) Token: 0x06001C65 RID: 7269 RVA: 0x0009F3E4 File Offset: 0x0009D5E4
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06001C66 RID: 7270 RVA: 0x0009F41C File Offset: 0x0009D61C
		protected bool SetValue<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
		{
			bool flag = object.Equals(field, value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				field = value;
				PropertyChangedEventHandler handler = this.PropertyChanged;
				bool flag2 = handler != null;
				if (flag2)
				{
					handler(this, new PropertyChangedEventArgs(propertyName));
				}
				result = true;
			}
			return result;
		}
	}
}
