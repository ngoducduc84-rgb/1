﻿using System;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001CC RID: 460
	public class RobotPoseRow : NotifyRowBase
	{
		// Token: 0x170008F1 RID: 2289
		// (get) Token: 0x06001C46 RID: 7238 RVA: 0x0009F104 File Offset: 0x0009D304
		// (set) Token: 0x06001C47 RID: 7239 RVA: 0x0009F11C File Offset: 0x0009D31C
		public int Index
		{
			get
			{
				return this._index;
			}
			set
			{
				base.SetValue<int>(ref this._index, value, "Index");
			}
		}

		// Token: 0x170008F2 RID: 2290
		// (get) Token: 0x06001C48 RID: 7240 RVA: 0x0009F134 File Offset: 0x0009D334
		// (set) Token: 0x06001C49 RID: 7241 RVA: 0x0009F14C File Offset: 0x0009D34C
		public double X
		{
			get
			{
				return this._x;
			}
			set
			{
				base.SetValue<double>(ref this._x, value, "X");
			}
		}

		// Token: 0x170008F3 RID: 2291
		// (get) Token: 0x06001C4A RID: 7242 RVA: 0x0009F164 File Offset: 0x0009D364
		// (set) Token: 0x06001C4B RID: 7243 RVA: 0x0009F17C File Offset: 0x0009D37C
		public double Y
		{
			get
			{
				return this._y;
			}
			set
			{
				base.SetValue<double>(ref this._y, value, "Y");
			}
		}

		// Token: 0x170008F4 RID: 2292
		// (get) Token: 0x06001C4C RID: 7244 RVA: 0x0009F194 File Offset: 0x0009D394
		// (set) Token: 0x06001C4D RID: 7245 RVA: 0x0009F1AC File Offset: 0x0009D3AC
		public double Z
		{
			get
			{
				return this._z;
			}
			set
			{
				base.SetValue<double>(ref this._z, value, "Z");
			}
		}

		// Token: 0x170008F5 RID: 2293
		// (get) Token: 0x06001C4E RID: 7246 RVA: 0x0009F1C4 File Offset: 0x0009D3C4
		// (set) Token: 0x06001C4F RID: 7247 RVA: 0x0009F1DC File Offset: 0x0009D3DC
		public double Rx
		{
			get
			{
				return this._rx;
			}
			set
			{
				base.SetValue<double>(ref this._rx, value, "Rx");
			}
		}

		// Token: 0x170008F6 RID: 2294
		// (get) Token: 0x06001C50 RID: 7248 RVA: 0x0009F1F4 File Offset: 0x0009D3F4
		// (set) Token: 0x06001C51 RID: 7249 RVA: 0x0009F20C File Offset: 0x0009D40C
		public double Ry
		{
			get
			{
				return this._ry;
			}
			set
			{
				base.SetValue<double>(ref this._ry, value, "Ry");
			}
		}

		// Token: 0x170008F7 RID: 2295
		// (get) Token: 0x06001C52 RID: 7250 RVA: 0x0009F224 File Offset: 0x0009D424
		// (set) Token: 0x06001C53 RID: 7251 RVA: 0x0009F23C File Offset: 0x0009D43C
		public double Rz
		{
			get
			{
				return this._rz;
			}
			set
			{
				base.SetValue<double>(ref this._rz, value, "Rz");
			}
		}

		// Token: 0x170008F8 RID: 2296
		// (get) Token: 0x06001C54 RID: 7252 RVA: 0x0009F254 File Offset: 0x0009D454
		// (set) Token: 0x06001C55 RID: 7253 RVA: 0x0009F26C File Offset: 0x0009D46C
		public string Status
		{
			get
			{
				return this._status;
			}
			set
			{
				base.SetValue<string>(ref this._status, value, "Status");
			}
		}

		// Token: 0x04000BD1 RID: 3025
		private int _index;

		// Token: 0x04000BD2 RID: 3026
		private double _x;

		// Token: 0x04000BD3 RID: 3027
		private double _y;

		// Token: 0x04000BD4 RID: 3028
		private double _z;

		// Token: 0x04000BD5 RID: 3029
		private double _rx;

		// Token: 0x04000BD6 RID: 3030
		private double _ry;

		// Token: 0x04000BD7 RID: 3031
		private double _rz;

		// Token: 0x04000BD8 RID: 3032
		private string _status;
	}
}
