﻿using System;

namespace VisionMachine.Views.Calibration.ViewModels
{
	// Token: 0x020001CD RID: 461
	public class VisionPointRow : NotifyRowBase
	{
		// Token: 0x170008F9 RID: 2297
		// (get) Token: 0x06001C57 RID: 7255 RVA: 0x0009F28C File Offset: 0x0009D48C
		// (set) Token: 0x06001C58 RID: 7256 RVA: 0x0009F2A4 File Offset: 0x0009D4A4
		public int Index
		{
			get
			{
				return this._index;
			}
			set
			{
				base.SetValue<int>(ref this._index, value, "Index");
			}
		}

		// Token: 0x170008FA RID: 2298
		// (get) Token: 0x06001C59 RID: 7257 RVA: 0x0009F2BC File Offset: 0x0009D4BC
		// (set) Token: 0x06001C5A RID: 7258 RVA: 0x0009F2D4 File Offset: 0x0009D4D4
		public double ImageX
		{
			get
			{
				return this._imageX;
			}
			set
			{
				base.SetValue<double>(ref this._imageX, value, "ImageX");
			}
		}

		// Token: 0x170008FB RID: 2299
		// (get) Token: 0x06001C5B RID: 7259 RVA: 0x0009F2EC File Offset: 0x0009D4EC
		// (set) Token: 0x06001C5C RID: 7260 RVA: 0x0009F304 File Offset: 0x0009D504
		public double ImageY
		{
			get
			{
				return this._imageY;
			}
			set
			{
				base.SetValue<double>(ref this._imageY, value, "ImageY");
			}
		}

		// Token: 0x170008FC RID: 2300
		// (get) Token: 0x06001C5D RID: 7261 RVA: 0x0009F31C File Offset: 0x0009D51C
		// (set) Token: 0x06001C5E RID: 7262 RVA: 0x0009F334 File Offset: 0x0009D534
		public double Angle
		{
			get
			{
				return this._angle;
			}
			set
			{
				base.SetValue<double>(ref this._angle, value, "Angle");
			}
		}

		// Token: 0x170008FD RID: 2301
		// (get) Token: 0x06001C5F RID: 7263 RVA: 0x0009F34C File Offset: 0x0009D54C
		// (set) Token: 0x06001C60 RID: 7264 RVA: 0x0009F364 File Offset: 0x0009D564
		public double Score
		{
			get
			{
				return this._score;
			}
			set
			{
				base.SetValue<double>(ref this._score, value, "Score");
			}
		}

		// Token: 0x170008FE RID: 2302
		// (get) Token: 0x06001C61 RID: 7265 RVA: 0x0009F37C File Offset: 0x0009D57C
		// (set) Token: 0x06001C62 RID: 7266 RVA: 0x0009F394 File Offset: 0x0009D594
		public string Status
		{
			get
			{
				return this._status;
			}
			set
			{
				base.SetValue<string>(ref this._status, value, "Status");
			}
		}

		// Token: 0x04000BD9 RID: 3033
		private int _index;

		// Token: 0x04000BDA RID: 3034
		private double _imageX;

		// Token: 0x04000BDB RID: 3035
		private double _imageY;

		// Token: 0x04000BDC RID: 3036
		private double _angle;

		// Token: 0x04000BDD RID: 3037
		private double _score;

		// Token: 0x04000BDE RID: 3038
		private string _status;
	}
}
