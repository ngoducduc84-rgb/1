﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Services.Camera;

namespace VisionMachine.Views.Camera
{
	// Token: 0x020001C3 RID: 451
	public partial class CameraSettingsWindow : ThemedWindow
	{
		// Token: 0x170008D8 RID: 2264
		// (get) Token: 0x06001B93 RID: 7059 RVA: 0x000997DC File Offset: 0x000979DC
		// (set) Token: 0x06001B94 RID: 7060 RVA: 0x000997E4 File Offset: 0x000979E4
		public CameraLayoutSettings CurrentSettings { get; private set; }

		// Token: 0x06001B95 RID: 7061 RVA: 0x000997ED File Offset: 0x000979ED
		public CameraSettingsWindow()
		{
			this.InitializeComponent();
			this._configPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CameraLayoutSettings.json");
			CameraDockFactory.Load_config_select_Camera();
			this.ShowSettings(CameraDockFactory.CurrentSettings);
		}

		// Token: 0x06001B96 RID: 7062 RVA: 0x0009982C File Offset: 0x00097A2C
		private void ShowSettings(CameraLayoutSettings settings)
		{
			this.txtCameraCount.Text = settings.CameraCount.ToString();
			this.txtMaxCamerasPerRow.Text = settings.MaxCamerasPerRow.ToString();
		}

		// Token: 0x06001B97 RID: 7063 RVA: 0x00099870 File Offset: 0x00097A70
		private bool TryGetSettingsFromUI(out CameraLayoutSettings settings)
		{
			settings = null;
			int cameraCount;
			bool flag = !int.TryParse(this.txtCameraCount.Text, out cameraCount) || cameraCount <= 0;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				int maxCamerasPerRow;
				bool flag2 = !int.TryParse(this.txtMaxCamerasPerRow.Text, out maxCamerasPerRow) || maxCamerasPerRow <= 0;
				if (flag2)
				{
					result = false;
				}
				else
				{
					settings = new CameraLayoutSettings
					{
						CameraCount = cameraCount,
						MaxCamerasPerRow = maxCamerasPerRow
					};
					result = true;
				}
			}
			return result;
		}

		// Token: 0x06001B98 RID: 7064 RVA: 0x000998EC File Offset: 0x00097AEC
		private void btnSave_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				CameraLayoutSettings settings;
				bool flag = !this.TryGetSettingsFromUI(out settings);
				if (!flag)
				{
					CameraLayoutSettings.SaveToFile(this._configPath, settings);
					this.CurrentSettings = settings;
				}
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Error saving settings: " + ex.Message);
			}
		}

		// Token: 0x06001B99 RID: 7065 RVA: 0x00099950 File Offset: 0x00097B50
		private void btnLoad_Click(object sender, RoutedEventArgs e)
		{
			CameraDockFactory.Load_config_select_Camera();
			this.ShowSettings(CameraDockFactory.CurrentSettings);
		}

		// Token: 0x06001B9A RID: 7066 RVA: 0x00099968 File Offset: 0x00097B68
		private void btnApply_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				CameraLayoutSettings settings;
				bool flag = !this.TryGetSettingsFromUI(out settings);
				if (!flag)
				{
					this.CurrentSettings = settings;
					base.DialogResult = new bool?(true);
					base.Close();
				}
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Error applying settings: " + ex.Message);
			}
		}

		// Token: 0x06001B9B RID: 7067 RVA: 0x0006553D File Offset: 0x0006373D
		private void btnClose_Click(object sender, RoutedEventArgs e)
		{
			base.Close();
		}

		// Token: 0x04000B8C RID: 2956
		private readonly string _configPath;
	}
}
