﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Docking;
using HalconDotNet;
using VisionMachine.Controls.Camera;
using VisionMachine.Models.Camera;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Light;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Main;

namespace VisionMachine.Views.Camera
{
	// Token: 0x020001C4 RID: 452
	public partial class Form_Camera : ThemedWindow
	{
		// Token: 0x170008D9 RID: 2265
		// (get) Token: 0x06001B9E RID: 7070 RVA: 0x00099B04 File Offset: 0x00097D04
		// (set) Token: 0x06001B9F RID: 7071 RVA: 0x00099B0B File Offset: 0x00097D0B
		public static Form_Camera Instance { get; private set; }

		// Token: 0x06001BA0 RID: 7072 RVA: 0x00099B14 File Offset: 0x00097D14
		public Form_Camera()
		{
			this.InitializeComponent();
			Form_Camera.Instance = this;
			MainWindow instance = MainWindow.instance;
			base.DataContext = ((instance != null) ? instance.MainViewModel : null);
			try
			{
				MainWindow instance2 = MainWindow.instance;
				if (instance2 != null)
				{
					MainViewModel mainViewModel = instance2.MainViewModel;
					if (mainViewModel != null)
					{
						mainViewModel.RefreshConnectedCameras();
					}
				}
				MainWindow instance3 = MainWindow.instance;
				if (instance3 != null)
				{
					MainViewModel mainViewModel2 = instance3.MainViewModel;
					if (mainViewModel2 != null)
					{
						mainViewModel2.RefreshConnectedLights();
					}
				}
			}
			catch
			{
			}
			try
			{
				MainWindow instance4 = MainWindow.instance;
				CameraModelConfigStorageService.LoadCurrentModelConfig((instance4 != null) ? instance4.MainViewModel : null);
				MainWindow instance5 = MainWindow.instance;
				LightModelConfigStorageService.LoadCurrentModelConfig((instance5 != null) ? instance5.MainViewModel : null);
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Loading camera model config failed:\n" + ex.Message, "Form Camera", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			try
			{
				this.load_layout_Camera();
			}
			catch (Exception ex2)
			{
				DXMessageBox.Show("Building camera layout failed:\n" + ex2.Message, "Form Camera", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}

		// Token: 0x06001BA1 RID: 7073 RVA: 0x00099C54 File Offset: 0x00097E54
		public void load_layout_Camera()
		{
			CameraDockFactory.CreateCameraDocksLive(this.rootGroup, this._cameraDocks);
			bool flag = CameraRuntimeStore.Cameras.Count <= 0;
			if (flag)
			{
			}
		}

		// Token: 0x06001BA2 RID: 7074 RVA: 0x00099C8B File Offset: 0x00097E8B
		public void RefreshCameraLayout()
		{
			this.StopAllLiveCameras();
			this.load_layout_Camera();
		}

		// Token: 0x06001BA3 RID: 7075 RVA: 0x00099C9C File Offset: 0x00097E9C
		public void RefreshCameraListBinding()
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			bool flag = vm == null;
			if (!flag)
			{
				base.DataContext = vm;
				Camera_Select_UI cameraSelectControl = this.CameraSelectControl;
				if (cameraSelectControl != null)
				{
					cameraSelectControl.RefreshCameraListBinding();
				}
			}
		}

		// Token: 0x06001BA4 RID: 7076 RVA: 0x00099CE0 File Offset: 0x00097EE0
		[DebuggerStepThrough]
		public void StartSelectedCameraLive()
		{
			Form_Camera.<StartSelectedCameraLive>d__10 <StartSelectedCameraLive>d__ = new Form_Camera.<StartSelectedCameraLive>d__10();
			<StartSelectedCameraLive>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<StartSelectedCameraLive>d__.<>4__this = this;
			<StartSelectedCameraLive>d__.<>1__state = -1;
			<StartSelectedCameraLive>d__.<>t__builder.Start<Form_Camera.<StartSelectedCameraLive>d__10>(ref <StartSelectedCameraLive>d__);
		}

		// Token: 0x06001BA5 RID: 7077 RVA: 0x00099D1C File Offset: 0x00097F1C
		private static bool IsLiveServiceConnected(IDisposable service)
		{
			bool result2;
			try
			{
				MethodInfo method = (service != null) ? service.GetType().GetMethod("IsCameraConnected", Type.EmptyTypes) : null;
				object result = (method != null) ? method.Invoke(service, null) : null;
				bool flag;
				if (result is bool)
				{
					bool b = (bool)result;
					flag = b;
				}
				else
				{
					flag = true;
				}
				result2 = flag;
			}
			catch
			{
				result2 = true;
			}
			return result2;
		}

		// Token: 0x06001BA6 RID: 7078 RVA: 0x00099D88 File Offset: 0x00097F88
		private static void ObserveInBackground(Task task)
		{
			bool flag = task == null;
			if (!flag)
			{
				task.ContinueWith(delegate(Task t)
				{
					AggregateException ignored = t.Exception;
				}, TaskContinuationOptions.OnlyOnFaulted);
			}
		}

		// Token: 0x06001BA7 RID: 7079 RVA: 0x00099DCC File Offset: 0x00097FCC
		public void StopSelectedCameraLive()
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			CameraNode selectedCamera = (vm != null) ? vm.SelectedCamera : null;
			bool flag = selectedCamera == null;
			if (!flag)
			{
				IDisposable service;
				bool flag2 = this._liveServices.TryGetValue(selectedCamera.Index, out service);
				if (flag2)
				{
					Form_Camera.StopLiveService(service);
				}
			}
		}

		// Token: 0x06001BA8 RID: 7080 RVA: 0x00099E28 File Offset: 0x00098028
		private void StopAllLiveCameras()
		{
			foreach (IDisposable service in this._liveServices.Values)
			{
				Form_Camera.StopLiveService(service);
			}
			this._liveServices.Clear();
		}

		// Token: 0x06001BA9 RID: 7081 RVA: 0x00099E94 File Offset: 0x00098094
		private static IDisposable CreateLiveService(CameraParameterConfig config)
		{
			bool flag = config == null;
			IDisposable result;
			if (flag)
			{
				result = null;
			}
			else
			{
				CameraVendor vendor = config.Vendor;
				CameraVendor cameraVendor = vendor;
				if (cameraVendor != CameraVendor.Basler)
				{
					if (cameraVendor != CameraVendor.Hikvision)
					{
						result = null;
					}
					else
					{
						result = new HikLiveCameraService();
					}
				}
				else
				{
					result = new BaslerLiveCameraService();
				}
			}
			return result;
		}

		// Token: 0x06001BAA RID: 7082 RVA: 0x0008976C File Offset: 0x0008796C
		private static void StartLiveService(IDisposable service, CameraParameterConfig config, HSmartWindowControlWPF display)
		{
			if (service != null)
			{
				MethodInfo method = service.GetType().GetMethod("Start");
				if (method != null)
				{
					method.Invoke(service, new object[]
					{
						config,
						display
					});
				}
			}
		}

		// Token: 0x06001BAB RID: 7083 RVA: 0x00099ED8 File Offset: 0x000980D8
		private static void StopLiveService(IDisposable service)
		{
			bool flag = service == null;
			if (!flag)
			{
				try
				{
					MethodInfo method = service.GetType().GetMethod("Stop");
					if (method != null)
					{
						method.Invoke(service, null);
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001BAC RID: 7084 RVA: 0x00099F28 File Offset: 0x00098128
		protected override void OnClosed(EventArgs e)
		{
			this.StopAllLiveCameras();
			MainWindow instance = MainWindow.instance;
			CameraModelConfigStorageService.SaveCurrentModelConfig((instance != null) ? instance.MainViewModel : null);
			MainWindow instance2 = MainWindow.instance;
			LightModelConfigStorageService.SaveCurrentModelConfig((instance2 != null) ? instance2.MainViewModel : null);
			LightControllerRuntimeService.Disconnect();
			base.OnClosed(e);
		}

		// Token: 0x04000B95 RID: 2965
		private readonly List<CameraDockItem_live> _cameraDocks = new List<CameraDockItem_live>();

		// Token: 0x04000B96 RID: 2966
		private readonly Dictionary<int, IDisposable> _liveServices = new Dictionary<int, IDisposable>();
	}
}
