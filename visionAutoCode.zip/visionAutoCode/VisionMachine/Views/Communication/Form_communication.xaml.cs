﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.Editors.Settings;
using DevExpress.Xpf.Grid;
using Microsoft.Win32;
using Newtonsoft.Json;
using VisionMachine.Controls.Common;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Communication;
using VisionMachine.Models.Recipe;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Calibration;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Communication;
using VisionMachine.Services.Runtime;
using VisionMachine.Views.Calibration.ViewModels;

namespace VisionMachine.Views.Communication
{
	// Token: 0x020001C2 RID: 450
	public partial class Form_communication : ThemedWindow, INotifyPropertyChanged, IStyleConnector
	{
		// Token: 0x06001A72 RID: 6770 RVA: 0x0008D938 File Offset: 0x0008BB38
		public Form_communication()
		{
			this.InitializeComponent();
			this._modbusMonitorService = new ModbusMonitorService(this._communicationService);
			this._cameraTagsRefreshTimer.Interval = TimeSpan.FromMilliseconds(150.0);
			this._cameraTagsRefreshTimer.Tick += this.CameraTagsRefreshTimer_Tick;
			CommunicationStartupService.ConnectionHealthChanged += this.CommunicationStartupService_ConnectionHealthChanged;
			base.IsVisibleChanged += this.Form_communication_IsVisibleChanged;
			CameraRuntimeStore.CamerasChanged -= this.CameraRuntimeStore_CamerasChanged;
			CameraRuntimeStore.CamerasChanged += this.CameraRuntimeStore_CamerasChanged;
			ModelRuntimeStore.CurrentModelChanged -= this.ModelRuntimeStore_CurrentModelChanged;
			ModelRuntimeStore.CurrentModelChanged += this.ModelRuntimeStore_CurrentModelChanged;
			this.EnsureInitialData(false);
		}

		// Token: 0x06001A73 RID: 6771 RVA: 0x0008DE3C File Offset: 0x0008C03C
		private void ModelRuntimeStore_CurrentModelChanged(object sender, EventArgs e)
		{
			Action reload = delegate()
			{
				string expectedPath = CommunicationConfigStorageService.GetConfigPath();
				bool flag = string.Equals(this._loadedConfigPath, expectedPath, StringComparison.OrdinalIgnoreCase);
				if (!flag)
				{
					this._lastAutoConnectRefreshPath = null;
					bool flag2 = !base.IsVisible;
					if (flag2)
					{
						this._pendingCurrentModelReload = true;
					}
					else
					{
						this._pendingCurrentModelReload = false;
						this.EnsureInitialData(true);
						GridControl initialValueGrid = this.InitialValueGrid;
						if (initialValueGrid != null)
						{
							initialValueGrid.RefreshData();
						}
						string level = "Info";
						string str = "Communication Initial Values reloaded for model '";
						ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
						this.AddLog(level, str + (((currentModel != null) ? currentModel.Model_name : null) ?? "None") + "'. Path=" + expectedPath);
					}
				}
			};
			base.Dispatcher.BeginInvoke(reload, DispatcherPriority.ContextIdle, Array.Empty<object>());
		}

		// Token: 0x06001A74 RID: 6772 RVA: 0x0008DE6C File Offset: 0x0008C06C
		private void HookToolOptionsSourceChanged()
		{
			CalibHandEyeOptionProvider.OptionsSourceChanged -= this.ToolOptionsSourceChanged;
			CalibHandEyeOptionProvider.OptionsSourceChanged += this.ToolOptionsSourceChanged;
			CameraRuntimeStore.Cameras.CollectionChanged -= this.Cameras_CollectionChanged;
			CameraRuntimeStore.Cameras.CollectionChanged += this.Cameras_CollectionChanged;
			CameraRuntimeStore.CamerasChanged -= this.CameraRuntimeStore_CamerasChanged;
			CameraRuntimeStore.CamerasChanged += this.CameraRuntimeStore_CamerasChanged;
		}

		// Token: 0x06001A75 RID: 6773 RVA: 0x0008DEF0 File Offset: 0x0008C0F0
		private void CameraRuntimeStore_CamerasChanged(object sender, EventArgs e)
		{
			bool flag = !this._initialDataReady;
			if (!flag)
			{
				bool flag2 = base.Dispatcher.CheckAccess();
				if (flag2)
				{
					this.ScheduleCameraTagsRefresh();
				}
				else
				{
					base.Dispatcher.BeginInvoke(new Action(this.ScheduleCameraTagsRefresh), Array.Empty<object>());
				}
			}
		}

		// Token: 0x06001A76 RID: 6774 RVA: 0x0008DF44 File Offset: 0x0008C144
		private void Cameras_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			bool flag = !this._initialDataReady;
			if (!flag)
			{
				bool flag2 = base.Dispatcher.CheckAccess();
				if (flag2)
				{
					this.ScheduleCameraTagsRefresh();
				}
				else
				{
					base.Dispatcher.BeginInvoke(new Action(this.ScheduleCameraTagsRefresh), Array.Empty<object>());
				}
			}
		}

		// Token: 0x06001A77 RID: 6775 RVA: 0x0008DF96 File Offset: 0x0008C196
		private void ScheduleCameraTagsRefresh()
		{
			this._cameraTagsRefreshTimer.Stop();
			this._cameraTagsRefreshTimer.Start();
		}

		// Token: 0x06001A78 RID: 6776 RVA: 0x0008DFB1 File Offset: 0x0008C1B1
		private void CameraTagsRefreshTimer_Tick(object sender, EventArgs e)
		{
			this._cameraTagsRefreshTimer.Stop();
			this.RefreshCameraTags();
		}

		// Token: 0x06001A79 RID: 6777 RVA: 0x0008DFC7 File Offset: 0x0008C1C7
		private void RefreshCameraTags()
		{
			this.SaveCurrentTagsForSelectedConnection();
			this.SyncCameraTagsForAllConnectionCaches();
			this.LoadTagsForConnection(this.SelectedConnection);
			this.RefreshResultLinkOptions();
			GridControl tagGrid = this.TagGrid;
			if (tagGrid != null)
			{
				tagGrid.RefreshData();
			}
			this.PersistSynchronizedCameraTags();
		}

		// Token: 0x06001A7A RID: 6778 RVA: 0x0008E008 File Offset: 0x0008C208
		private void PersistSynchronizedCameraTags()
		{
			try
			{
				CommunicationRuntimeSettings runtimeSettings = new CommunicationRuntimeSettings
				{
					CameraTriggerConnectionName = this.CameraTriggerConnectionName
				};
				CommunicationConfigStorageService.Save(this.Connections, this.BuildSerializableConnectionTags(), runtimeSettings, CommunicationConfigStorageService.GetConfigPath());
			}
			catch (Exception ex)
			{
				this.AddLog("Warning", "Camera tag synchronization could not be saved: " + ex.Message);
			}
		}

		// Token: 0x06001A7B RID: 6779 RVA: 0x0008E078 File Offset: 0x0008C278
		private void ToolOptionsSourceChanged(object sender, EventArgs e)
		{
			bool flag = !this._initialDataReady;
			if (!flag)
			{
				bool flag2 = base.Dispatcher.CheckAccess();
				if (flag2)
				{
					this.RefreshResultLinkOptions();
				}
				else
				{
					base.Dispatcher.BeginInvoke(new Action(this.RefreshResultLinkOptions), Array.Empty<object>());
				}
			}
		}

		// Token: 0x06001A7C RID: 6780 RVA: 0x0008E0CC File Offset: 0x0008C2CC
		private void Form_communication_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			bool visible;
			bool flag;
			if (this._initialDataReady)
			{
				object newValue = e.NewValue;
				if (newValue is bool)
				{
					visible = (bool)newValue;
					flag = true;
				}
				else
				{
					flag = false;
				}
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag && visible;
			if (flag2)
			{
				string expectedPath = CommunicationConfigStorageService.GetConfigPath();
				bool flag3 = this._pendingCurrentModelReload || !string.Equals(this._loadedConfigPath, expectedPath, StringComparison.OrdinalIgnoreCase);
				if (flag3)
				{
					this._pendingCurrentModelReload = false;
					this._lastAutoConnectRefreshPath = null;
					this.EnsureInitialData(true);
					GridControl initialValueGrid = this.InitialValueGrid;
					if (initialValueGrid != null)
					{
						initialValueGrid.RefreshData();
					}
				}
				else
				{
					this.RefreshCameraTags();
					this.RefreshResultLinkOptions();
				}
			}
		}

		// Token: 0x06001A7D RID: 6781 RVA: 0x0008E168 File Offset: 0x0008C368
		private void SearchConnection_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			this.ApplyConnectionFilter(Convert.ToString(e.NewValue));
			bool flag = !this.FilteredConnections.Contains(this.SelectedConnection);
			if (flag)
			{
				this.SelectedConnection = this.FilteredConnections.FirstOrDefault<CommunicationConnection>();
			}
		}

		// Token: 0x06001A7E RID: 6782 RVA: 0x0008E1B4 File Offset: 0x0008C3B4
		private void ConnectionList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ListBox connectionList = this.ConnectionList;
			CommunicationConnection connection = ((connectionList != null) ? connectionList.SelectedItem : null) as CommunicationConnection;
			bool flag = connection != null;
			if (flag)
			{
				this.SetSelectedConnection(connection, true);
			}
			this.RefreshProtocolInformation();
			this.ScheduleAutoBrowseOpcTagsForSelectedConnection();
		}

		// Token: 0x06001A7F RID: 6783 RVA: 0x0008E1FC File Offset: 0x0008C3FC
		private void ConnectionItem_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			FrameworkElement element = sender as FrameworkElement;
			CommunicationConnection connection;
			bool flag;
			if (element != null)
			{
				connection = (element.Tag as CommunicationConnection);
				flag = (connection != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				this.SelectConnection(connection);
				e.Handled = true;
			}
		}

		// Token: 0x06001A80 RID: 6784 RVA: 0x0008E240 File Offset: 0x0008C440
		private void SelectConnection(CommunicationConnection connection)
		{
			bool flag = connection == null;
			if (!flag)
			{
				this.SetSelectedConnection(connection, true);
				this.UpdateSelectedConnectionState();
				bool flag2 = this.ConnectionList != null;
				if (flag2)
				{
					this.ConnectionList.SelectedItem = connection;
				}
				this.RefreshProtocolInformation();
				this.ScheduleAutoBrowseOpcTagsForSelectedConnection();
			}
		}

		// Token: 0x06001A81 RID: 6785 RVA: 0x0008E290 File Offset: 0x0008C490
		private void UpdateSelectedConnectionState()
		{
			foreach (CommunicationConnection connection in this.Connections)
			{
				connection.IsSelected = (connection == this.SelectedConnection);
			}
		}

		// Token: 0x06001A82 RID: 6786 RVA: 0x0008E2EC File Offset: 0x0008C4EC
		private void DeleteConnection_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement element = sender as FrameworkElement;
			CommunicationConnection connection;
			bool flag;
			if (element != null)
			{
				connection = (element.Tag as CommunicationConnection);
				flag = (connection == null);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (!flag2)
			{
				MessageBoxResult result = DXMessageBox.Show("Delete connection '" + connection.Name + "'?", "Delete Communication Connection", MessageBoxButton.YesNo, MessageBoxImage.Question);
				bool flag3 = result != MessageBoxResult.Yes;
				if (!flag3)
				{
					this._communicationService.Disconnect(connection);
					this._tagsByConnection.Remove(Form_communication.GetConnectionTagKey(connection));
					this.Connections.Remove(connection);
					TextEdit searchConnectionEdit = this.SearchConnectionEdit;
					this.ApplyConnectionFilter(Convert.ToString((searchConnectionEdit != null) ? searchConnectionEdit.EditValue : null));
					this.SelectedConnection = this.FilteredConnections.FirstOrDefault<CommunicationConnection>();
					this.UpdateSelectedConnectionState();
					this.SaveConnections();
					bool flag4 = this.ConnectionList != null;
					if (flag4)
					{
						this.ConnectionList.SelectedItem = this.SelectedConnection;
					}
					this.AddLog("Info", connection.Name + " deleted.");
					e.Handled = true;
				}
			}
		}

		// Token: 0x06001A83 RID: 6787 RVA: 0x0008E408 File Offset: 0x0008C608
		private void Protocol_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool isPushingEditorValues = this._isPushingEditorValues;
			if (!isPushingEditorValues)
			{
				string protocol = Convert.ToString(e.NewValue);
				bool flag = !Form_communication.IsSupportedProtocol(protocol);
				if (!flag)
				{
					this.SelectedProtocol = protocol;
					this.ScheduleAutoBrowseOpcTagsForSelectedConnection();
				}
			}
		}

		// Token: 0x06001A84 RID: 6788 RVA: 0x0008E44C File Offset: 0x0008C64C
		private void CameraTriggerConnection_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool isRefreshingCameraTriggerOptions = this._isRefreshingCameraTriggerOptions;
			if (!isRefreshingCameraTriggerOptions)
			{
				string selectedName = Convert.ToString(e.NewValue);
				bool flag = string.IsNullOrWhiteSpace(selectedName);
				if (flag)
				{
					selectedName = "None";
				}
				this.CameraTriggerConnectionName = this.ResolveCameraTriggerConnectionName(selectedName);
				bool flag2 = this.CameraTriggerConnectionComboEdit != null && !string.Equals(Convert.ToString(this.CameraTriggerConnectionComboEdit.EditValue), this.CameraTriggerConnectionName, StringComparison.Ordinal);
				if (flag2)
				{
					this.CameraTriggerConnectionComboEdit.SelectedItem = this.CameraTriggerConnectionName;
					this.CameraTriggerConnectionComboEdit.EditValue = this.CameraTriggerConnectionName;
				}
			}
		}

		// Token: 0x06001A85 RID: 6789 RVA: 0x0008E4E4 File Offset: 0x0008C6E4
		private void AddNew_Click(object sender, RoutedEventArgs e)
		{
			this.UpdateEditorBindings();
			this.PullEditorValuesToEditingConnection();
			bool flag = this.IsMxComponentSelected() && !MxComponentRuntime.IsInstalled;
			if (flag)
			{
				this.AddLog("Error", MxComponentRuntime.DescribeInstallation());
				DXMessageBox.Show(MxComponentRuntime.DescribeInstallation(), "MX Component", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			else
			{
				TextEdit connectionNameEdit = this.ConnectionNameEdit;
				string requestedName = Convert.ToString((connectionNameEdit != null) ? connectionNameEdit.EditValue : null);
				bool flag2 = string.IsNullOrWhiteSpace(requestedName);
				if (flag2)
				{
					CommunicationConnection editingConnection = this.EditingConnection;
					requestedName = ((editingConnection != null) ? editingConnection.Name : null);
				}
				string name = this.GetUniqueConnectionName(string.IsNullOrWhiteSpace(requestedName) ? "PLC_New" : requestedName.Trim());
				string protocol = this.GetActiveProtocol();
				CommunicationConnection connection = Form_communication.CloneConnection(this.EditingConnection);
				connection.Name = name;
				connection.Protocol = protocol;
				connection.Status = "Disconnected";
				connection.ConnectedTime = "--";
				connection.LastUpdate = "--";
				connection.SendBytes = "0 B";
				connection.ReceiveBytes = "0 B";
				connection.ErrorCount = 0;
				CommunicationConnection connection2 = connection;
				CommunicationConnection editingConnection2 = this.EditingConnection;
				Form_communication.ResetProtocolSpecificSettings(connection2, (editingConnection2 != null) ? editingConnection2.Protocol : null);
				bool flag3 = connection.Protocol == "Modbus Server TCP/IP";
				if (flag3)
				{
					connection.IpAddress = "0.0.0.0";
				}
				bool flag4 = connection.Port <= 0;
				if (flag4)
				{
					connection.ApplyDefaultPort();
				}
				this.Connections.Add(connection);
				this._tagsByConnection[Form_communication.GetConnectionTagKey(connection)] = new List<CommunicationTagRow>();
				this.ApplyConnectionFilter(Convert.ToString(this.SearchConnectionEdit.EditValue));
				this.SelectConnection(connection);
				this.SaveConnections();
				this.AddLog("Info", name + " created.");
			}
		}

		// Token: 0x06001A86 RID: 6790 RVA: 0x0008E6B4 File Offset: 0x0008C8B4
		private static void ResetProtocolSpecificSettings(CommunicationConnection connection, string sourceProtocol)
		{
			bool flag = connection == null;
			if (!flag)
			{
				bool flag2 = string.Equals(connection.Protocol, sourceProtocol, StringComparison.OrdinalIgnoreCase);
				if (!flag2)
				{
					connection.ApplyDefaultPort();
					bool flag3 = string.Equals(connection.Protocol, "MX Component", StringComparison.OrdinalIgnoreCase);
					if (flag3)
					{
						connection.MonitorStartAddress = "D0";
						connection.MonitorEndAddress = "D10";
						connection.MonitorFunctionCode = string.Empty;
						connection.IpAddress = string.Empty;
					}
					else
					{
						connection.LogicalStationNumber = 0;
						bool flag4 = string.Equals(connection.Protocol, "OPC UA", StringComparison.OrdinalIgnoreCase);
						if (!flag4)
						{
							bool flag5 = !Form_communication.IsModbusRegisterAddress(connection.MonitorStartAddress);
							if (flag5)
							{
								connection.MonitorStartAddress = "40001";
							}
							bool flag6 = !Form_communication.IsModbusRegisterAddress(connection.MonitorEndAddress);
							if (flag6)
							{
								connection.MonitorEndAddress = "40010";
							}
							bool flag7 = string.IsNullOrWhiteSpace(connection.MonitorFunctionCode);
							if (flag7)
							{
								connection.MonitorFunctionCode = "03 Read Holding Registers";
							}
						}
					}
				}
			}
		}

		// Token: 0x06001A87 RID: 6791 RVA: 0x0008E7B0 File Offset: 0x0008C9B0
		private static bool IsModbusRegisterAddress(string address)
		{
			int parsed;
			return !string.IsNullOrWhiteSpace(address) && int.TryParse(address.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed);
		}

		// Token: 0x06001A88 RID: 6792 RVA: 0x0008E7E0 File Offset: 0x0008C9E0
		private void ChangeConnectionProtocol_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement frameworkElement = sender as FrameworkElement;
			CommunicationConnection connection = (((frameworkElement != null) ? frameworkElement.DataContext : null) as CommunicationConnection) ?? this.SelectedConnection;
			bool flag = connection == null;
			if (!flag)
			{
				string protocol = this.GetActiveProtocol();
				bool flag2 = string.Equals(connection.Protocol, protocol, StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					DXMessageBox.Show(string.Concat(new string[]
					{
						"'",
						connection.Name,
						"' already uses ",
						protocol,
						"."
					}), "Change Protocol", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					bool flag3 = string.Equals(protocol, "MX Component", StringComparison.OrdinalIgnoreCase) && !MxComponentRuntime.IsInstalled;
					if (flag3)
					{
						this.AddLog("Error", MxComponentRuntime.DescribeInstallation());
						DXMessageBox.Show(MxComponentRuntime.DescribeInstallation(), "MX Component", MessageBoxButton.OK, MessageBoxImage.Hand);
					}
					else
					{
						MessageBoxResult answer = DXMessageBox.Show(string.Concat(new string[]
						{
							"Change '",
							connection.Name,
							"' from ",
							connection.Protocol,
							" to ",
							protocol,
							"?",
							Environment.NewLine,
							Environment.NewLine,
							"Its port, monitor setup and every tag address written in the old protocol's notation will be rewritten for ",
							protocol,
							"."
						}), "Change Protocol", MessageBoxButton.OKCancel, MessageBoxImage.Question);
						bool flag4 = answer != MessageBoxResult.OK;
						if (!flag4)
						{
							string previousProtocol = connection.Protocol;
							this.SelectConnection(connection);
							connection.Protocol = protocol;
							Form_communication.ResetProtocolSpecificSettings(connection, previousProtocol);
							bool flag5 = protocol == "Modbus Server TCP/IP";
							if (flag5)
							{
								connection.IpAddress = "0.0.0.0";
							}
							bool flag6 = this.EditingConnection != null;
							if (flag6)
							{
								this.EditingConnection.Protocol = protocol;
								Form_communication.ResetProtocolSpecificSettings(this.EditingConnection, previousProtocol);
							}
							this.PushEditingConnectionToEditors();
							this.ReaddressTagsForSelectedProtocol();
							this.UpdateProtocolUi();
							this.RefreshProtocolInformation();
							this.SaveCurrentTagsForSelectedConnection();
							this.SaveConnections();
							this.AddLog("Info", string.Concat(new string[]
							{
								connection.Name,
								" protocol changed from ",
								previousProtocol,
								" to ",
								protocol,
								"."
							}));
						}
					}
				}
			}
		}

		// Token: 0x06001A89 RID: 6793 RVA: 0x0008EA20 File Offset: 0x0008CC20
		[DebuggerStepThrough]
		private void Connect_Click(object sender, RoutedEventArgs e)
		{
			Form_communication.<Connect_Click>d__23 <Connect_Click>d__ = new Form_communication.<Connect_Click>d__23();
			<Connect_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Connect_Click>d__.<>4__this = this;
			<Connect_Click>d__.sender = sender;
			<Connect_Click>d__.e = e;
			<Connect_Click>d__.<>1__state = -1;
			<Connect_Click>d__.<>t__builder.Start<Form_communication.<Connect_Click>d__23>(ref <Connect_Click>d__);
		}

		// Token: 0x06001A8A RID: 6794 RVA: 0x0008EA68 File Offset: 0x0008CC68
		[DebuggerStepThrough]
		private void Disconnect_Click(object sender, RoutedEventArgs e)
		{
			Form_communication.<Disconnect_Click>d__24 <Disconnect_Click>d__ = new Form_communication.<Disconnect_Click>d__24();
			<Disconnect_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Disconnect_Click>d__.<>4__this = this;
			<Disconnect_Click>d__.sender = sender;
			<Disconnect_Click>d__.e = e;
			<Disconnect_Click>d__.<>1__state = -1;
			<Disconnect_Click>d__.<>t__builder.Start<Form_communication.<Disconnect_Click>d__24>(ref <Disconnect_Click>d__);
		}

		// Token: 0x06001A8B RID: 6795 RVA: 0x0008EAB0 File Offset: 0x0008CCB0
		private void RunWithBusyOverlay(Action work, string detailMessage = null)
		{
			bool flag = work == null;
			if (!flag)
			{
				LoadingOverlay.RunOnUi(this, string.IsNullOrWhiteSpace(detailMessage) ? "Please wait..." : detailMessage, work);
			}
		}

		// Token: 0x06001A8C RID: 6796 RVA: 0x0008EAE0 File Offset: 0x0008CCE0
		private void Apply_Click(object sender, RoutedEventArgs e)
		{
			bool saved = false;
			this.RunWithBusyOverlay(delegate
			{
				bool flag = this.SelectedConnection != null;
				if (flag)
				{
					this.UpdateEditorBindings();
					this.PullEditorValuesToEditingConnection();
					this.PullMonitorSelectorValues();
					this.ApplyEditorToConnection(this.SelectedConnection);
					this.AddLog("Info", this.SelectedConnection.Name + " setting applied.");
				}
				saved = this.SaveConnections();
				Form_communication <>4__this = this;
				TextEdit searchConnectionEdit = this.SearchConnectionEdit;
				<>4__this.ApplyConnectionFilter(Convert.ToString((searchConnectionEdit != null) ? searchConnectionEdit.EditValue : null));
				bool flag2 = this.SelectedConnection != null;
				if (flag2)
				{
					this.SelectConnection(this.SelectedConnection);
				}
				bool saved2 = saved;
				if (saved2)
				{
					CalibHandEyeControlService.TryWritePointCounts();
				}
			}, "Saving communication configuration...");
			bool saved3 = saved;
			if (saved3)
			{
				DXMessageBox.Show(this, "Communication configuration saved successfully.", "Communication", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				DXMessageBox.Show(this, "Save failed. Tag Management has duplicate or overlapping addresses (remember FLOAT uses 2 registers and result lists reserve their Max Count). Please fix the highlighted tags and Apply again. See the log for details.", "Communication", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}

		// Token: 0x06001A8D RID: 6797 RVA: 0x0008EB54 File Offset: 0x0008CD54
		[DebuggerStepThrough]
		private void TestConnection_Click(object sender, RoutedEventArgs e)
		{
			Form_communication.<TestConnection_Click>d__27 <TestConnection_Click>d__ = new Form_communication.<TestConnection_Click>d__27();
			<TestConnection_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<TestConnection_Click>d__.<>4__this = this;
			<TestConnection_Click>d__.sender = sender;
			<TestConnection_Click>d__.e = e;
			<TestConnection_Click>d__.<>1__state = -1;
			<TestConnection_Click>d__.<>t__builder.Start<Form_communication.<TestConnection_Click>d__27>(ref <TestConnection_Click>d__);
		}

		// Token: 0x06001A8E RID: 6798 RVA: 0x0008EB9B File Offset: 0x0008CD9B
		private void ReadAll_Click(object sender, RoutedEventArgs e)
		{
			this.ReadConfiguredMonitorRange("read all");
		}

		// Token: 0x06001A8F RID: 6799 RVA: 0x0008EBAA File Offset: 0x0008CDAA
		private void ReadRange_Click(object sender, RoutedEventArgs e)
		{
			this.ReadConfiguredMonitorRange("read range");
		}

		// Token: 0x06001A90 RID: 6800 RVA: 0x0008EBBC File Offset: 0x0008CDBC
		[DebuggerStepThrough]
		private void BrowseOpcTags_Click(object sender, RoutedEventArgs e)
		{
			Form_communication.<BrowseOpcTags_Click>d__30 <BrowseOpcTags_Click>d__ = new Form_communication.<BrowseOpcTags_Click>d__30();
			<BrowseOpcTags_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<BrowseOpcTags_Click>d__.<>4__this = this;
			<BrowseOpcTags_Click>d__.sender = sender;
			<BrowseOpcTags_Click>d__.e = e;
			<BrowseOpcTags_Click>d__.<>1__state = -1;
			<BrowseOpcTags_Click>d__.<>t__builder.Start<Form_communication.<BrowseOpcTags_Click>d__30>(ref <BrowseOpcTags_Click>d__);
		}

		// Token: 0x06001A91 RID: 6801 RVA: 0x0008EC04 File Offset: 0x0008CE04
		private void ScheduleAutoBrowseOpcTagsForSelectedConnection()
		{
			Form_communication.<>c__DisplayClass31_0 CS$<>8__locals1 = new Form_communication.<>c__DisplayClass31_0();
			CS$<>8__locals1.<>4__this = this;
			CS$<>8__locals1.connection = this.SelectedConnection;
			bool flag = CS$<>8__locals1.connection == null || !string.Equals(CS$<>8__locals1.connection.Protocol, "OPC UA", StringComparison.OrdinalIgnoreCase) || string.IsNullOrWhiteSpace(CS$<>8__locals1.connection.Name) || this._isAutoBrowsingOpcTags;
			if (!flag)
			{
				CS$<>8__locals1.key = CS$<>8__locals1.connection.Name.Trim();
				bool flag2 = this._autoBrowsedOpcConnections.Contains(CS$<>8__locals1.key);
				if (!flag2)
				{
					base.Dispatcher.BeginInvoke(new Action(delegate()
					{
						Form_communication.<>c__DisplayClass31_0.<<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d <<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d = new Form_communication.<>c__DisplayClass31_0.<<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d();
						<<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
						<<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d.<>4__this = CS$<>8__locals1;
						<<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d.<>1__state = -1;
						<<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d.<>t__builder.Start<Form_communication.<>c__DisplayClass31_0.<<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d>(ref <<ScheduleAutoBrowseOpcTagsForSelectedConnection>b__0>d);
					}), DispatcherPriority.ContextIdle, Array.Empty<object>());
				}
			}
		}

		// Token: 0x06001A92 RID: 6802 RVA: 0x0008ECB8 File Offset: 0x0008CEB8
		[DebuggerStepThrough]
		private Task<bool> BrowseOpcTagsForConnectionAsync(CommunicationConnection connection, string actionName)
		{
			Form_communication.<BrowseOpcTagsForConnectionAsync>d__32 <BrowseOpcTagsForConnectionAsync>d__ = new Form_communication.<BrowseOpcTagsForConnectionAsync>d__32();
			<BrowseOpcTagsForConnectionAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<BrowseOpcTagsForConnectionAsync>d__.<>4__this = this;
			<BrowseOpcTagsForConnectionAsync>d__.connection = connection;
			<BrowseOpcTagsForConnectionAsync>d__.actionName = actionName;
			<BrowseOpcTagsForConnectionAsync>d__.<>1__state = -1;
			<BrowseOpcTagsForConnectionAsync>d__.<>t__builder.Start<Form_communication.<BrowseOpcTagsForConnectionAsync>d__32>(ref <BrowseOpcTagsForConnectionAsync>d__);
			return <BrowseOpcTagsForConnectionAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06001A93 RID: 6803 RVA: 0x0008ED0C File Offset: 0x0008CF0C
		private void AutoRead_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool enabled = false;
			object newValue = e.NewValue;
			bool boolValue;
			bool flag;
			if (newValue is bool)
			{
				boolValue = (bool)newValue;
				flag = true;
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				enabled = boolValue;
			}
			else
			{
				bool.TryParse(Convert.ToString(e.NewValue), out enabled);
			}
			this._autoRefresh = enabled;
			this.OnPropertyChanged("AutoRefresh");
			this.SyncMonitorAutoReadState();
		}

		// Token: 0x06001A94 RID: 6804 RVA: 0x0008ED70 File Offset: 0x0008CF70
		private void ReadCycle_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool flag = this._isPushingEditorValues || this.SelectedConnection == null;
			if (!flag)
			{
				int intervalMs;
				bool flag2 = !Form_communication.TryGetEditorInt32(e.NewValue, out intervalMs);
				if (!flag2)
				{
					bool flag3 = intervalMs < 10;
					if (!flag3)
					{
						bool flag4 = intervalMs > 60000;
						if (flag4)
						{
							intervalMs = 60000;
						}
						this.ReadCycleMs = intervalMs;
						this.SetReadCycleText(this.ReadCycleMs);
						string interval = Form_communication.FormatReadCycle(this.ReadCycleMs);
						bool flag5 = this.EditingConnection != null;
						if (flag5)
						{
							this.EditingConnection.ExchangeInterval = interval;
						}
						this.SelectedConnection.ExchangeInterval = interval;
						this.SaveConnections();
					}
				}
			}
		}

		// Token: 0x06001A95 RID: 6805 RVA: 0x0008EE23 File Offset: 0x0008D023
		private void ReadCycle_PreviewTextInput(object sender, TextCompositionEventArgs e)
		{
			e.Handled = !Form_communication.IsDigitsOnly(e.Text);
		}

		// Token: 0x06001A96 RID: 6806 RVA: 0x0008EE3C File Offset: 0x0008D03C
		private void ReadCycle_Pasting(object sender, DataObjectPastingEventArgs e)
		{
			bool flag = !e.DataObject.GetDataPresent(DataFormats.Text);
			if (flag)
			{
				e.CancelCommand();
			}
			else
			{
				string text = Convert.ToString(e.DataObject.GetData(DataFormats.Text));
				bool flag2 = !Form_communication.IsDigitsOnly(text);
				if (flag2)
				{
					e.CancelCommand();
				}
			}
		}

		// Token: 0x06001A97 RID: 6807 RVA: 0x0008EE98 File Offset: 0x0008D098
		private void ReadCycle_LostFocus(object sender, RoutedEventArgs e)
		{
			int value;
			bool flag = !Form_communication.TryGetEditorInt32(this.ReadCycleText, out value);
			if (flag)
			{
				value = this.ReadCycleMs;
			}
			this.ApplyReadCycleValue(value);
		}

		// Token: 0x06001A98 RID: 6808 RVA: 0x0008EEC9 File Offset: 0x0008D0C9
		private void ReadCycleIncrement_Click(object sender, RoutedEventArgs e)
		{
			this.ApplyReadCycleValue(this.ReadCycleMs + 10);
		}

		// Token: 0x06001A99 RID: 6809 RVA: 0x0008EEDC File Offset: 0x0008D0DC
		private void ReadCycleDecrement_Click(object sender, RoutedEventArgs e)
		{
			this.ApplyReadCycleValue(this.ReadCycleMs - 10);
		}

		// Token: 0x06001A9A RID: 6810 RVA: 0x0008EEF0 File Offset: 0x0008D0F0
		private void ApplyReadCycleValue(int intervalMs)
		{
			intervalMs = Math.Max(10, Math.Min(60000, intervalMs));
			this.ReadCycleMs = intervalMs;
			this.SetReadCycleText(this.ReadCycleMs);
			string interval = Form_communication.FormatReadCycle(this.ReadCycleMs);
			bool flag = this.EditingConnection != null;
			if (flag)
			{
				this.EditingConnection.ExchangeInterval = interval;
			}
			bool flag2 = this.SelectedConnection != null;
			if (flag2)
			{
				this.SelectedConnection.ExchangeInterval = interval;
			}
			this.SaveConnections();
		}

		// Token: 0x06001A9B RID: 6811 RVA: 0x0008EF70 File Offset: 0x0008D170
		private static bool IsDigitsOnly(string text)
		{
			return !string.IsNullOrEmpty(text) && text.All(new Func<char, bool>(char.IsDigit));
		}

		// Token: 0x06001A9C RID: 6812 RVA: 0x0008EFA0 File Offset: 0x0008D1A0
		[DebuggerStepThrough]
		private void ReadConfiguredMonitorRange(string actionName)
		{
			Form_communication.<ReadConfiguredMonitorRange>d__42 <ReadConfiguredMonitorRange>d__ = new Form_communication.<ReadConfiguredMonitorRange>d__42();
			<ReadConfiguredMonitorRange>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<ReadConfiguredMonitorRange>d__.<>4__this = this;
			<ReadConfiguredMonitorRange>d__.actionName = actionName;
			<ReadConfiguredMonitorRange>d__.<>1__state = -1;
			<ReadConfiguredMonitorRange>d__.<>t__builder.Start<Form_communication.<ReadConfiguredMonitorRange>d__42>(ref <ReadConfiguredMonitorRange>d__);
		}

		// Token: 0x06001A9D RID: 6813 RVA: 0x0008EFE0 File Offset: 0x0008D1E0
		private void ShowMonitorError(string address, string dataType, string message, string description)
		{
			this.SetMonitorRows(new CommunicationMonitorRow[]
			{
				new CommunicationMonitorRow(address, dataType, message, "Bad", DateTime.Now.ToString("HH:mm:ss.fff"), description)
			});
		}

		// Token: 0x06001A9E RID: 6814 RVA: 0x0008F020 File Offset: 0x0008D220
		private void ShowMonitorStatus(string address, string dataType, string message, string description)
		{
			this.SetMonitorRows(new CommunicationMonitorRow[]
			{
				new CommunicationMonitorRow(address, dataType, message, "Info", DateTime.Now.ToString("HH:mm:ss.fff"), description)
			});
		}

		// Token: 0x06001A9F RID: 6815 RVA: 0x0008F060 File Offset: 0x0008D260
		private void SendCommand_Click(object sender, RoutedEventArgs e)
		{
			string address = Convert.ToString(this.CommandAddressEdit.EditValue);
			string type = Convert.ToString(this.CommandTypeEdit.EditValue);
			string value = Convert.ToString(this.CommandValueEdit.EditValue);
			CommunicationOperationResult result = this._communicationService.Write(this.SelectedConnection, address, type, value);
			this.CommandRows.Insert(0, new CommunicationCommandRow
			{
				Time = DateTime.Now.ToString("HH:mm:ss.fff"),
				Command = "Write " + type,
				Address = address,
				Value = value,
				Result = result.Message
			});
			bool flag = this.SelectedConnection != null;
			if (flag)
			{
				this.SelectedConnection.LastUpdate = DateTime.Now.ToString("HH:mm:ss");
				this.SelectedConnection.AddTraffic(result.SentBytes, result.ReceivedBytes);
				bool flag2 = !result.Success;
				if (flag2)
				{
					CommunicationConnection selectedConnection = this.SelectedConnection;
					int errorCount = selectedConnection.ErrorCount;
					selectedConnection.ErrorCount = errorCount + 1;
				}
			}
			this.AddLog(result.Success ? "Command" : "Error", string.Concat(new string[]
			{
				"Write command. Address=",
				address,
				", Type=",
				type,
				", Value=",
				value,
				", Result=",
				result.Message
			}));
		}

		// Token: 0x06001AA0 RID: 6816 RVA: 0x0008F1DC File Offset: 0x0008D3DC
		private void ImportConfig_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog dialog = new OpenFileDialog
			{
				Filter = "Communication config (*.json)|*.json|All files (*.*)|*.*",
				Title = "Import Communication Config"
			};
			bool flag = !dialog.ShowDialog().GetValueOrDefault();
			if (!flag)
			{
				try
				{
					string json = File.ReadAllText(dialog.FileName);
					bool flag2 = json.TrimStart(Array.Empty<char>()).StartsWith("[", StringComparison.Ordinal);
					CommunicationConfigData importedConfig;
					if (flag2)
					{
						importedConfig = new CommunicationConfigData
						{
							Connections = (JsonConvert.DeserializeObject<List<CommunicationConnection>>(json) ?? new List<CommunicationConnection>())
						};
					}
					else
					{
						importedConfig = (JsonConvert.DeserializeObject<CommunicationConfigData>(json) ?? new CommunicationConfigData());
					}
					this.Connections.Clear();
					this.TagRows.Clear();
					this._tagsByConnection.Clear();
					this._lastBrowsedOpcTags.Clear();
					foreach (CommunicationConnection connection in importedConfig.Connections)
					{
						Form_communication.NormalizeConnection(connection);
						connection.Status = "Disconnected";
						this.Connections.Add(connection);
					}
					this.LoadConnectionTagCache(importedConfig);
					this.LoadInitialValueCache(importedConfig);
					CommunicationRuntimeSettings runtimeSettings = importedConfig.RuntimeSettings;
					this.CameraTriggerConnectionName = (string.IsNullOrWhiteSpace((runtimeSettings != null) ? runtimeSettings.CameraTriggerConnectionName : null) ? "None" : importedConfig.RuntimeSettings.CameraTriggerConnectionName);
					this.RefreshCameraTriggerConnectionOptions();
					this.ApplyConnectionFilter(Convert.ToString(this.SearchConnectionEdit.EditValue));
					this.SelectedConnection = this.FilteredConnections.FirstOrDefault<CommunicationConnection>();
					this.SaveConnections();
					this.AddLog("Info", string.Format("Imported {0} communication connection(s).", this.Connections.Count));
				}
				catch (Exception ex)
				{
					DXMessageBox.Show(ex.Message, "Import Communication Config");
					this.AddLog("Error", "Import config failed: " + ex.Message);
				}
			}
		}

		// Token: 0x06001AA1 RID: 6817 RVA: 0x0008F418 File Offset: 0x0008D618
		private void ExportConfig_Click(object sender, RoutedEventArgs e)
		{
			SaveFileDialog dialog = new SaveFileDialog
			{
				Filter = "Communication config (*.json)|*.json|All files (*.*)|*.*",
				FileName = "communication_config.json",
				Title = "Export Communication Config"
			};
			bool flag = !dialog.ShowDialog().GetValueOrDefault();
			if (!flag)
			{
				try
				{
					this.SaveCurrentTagsForSelectedConnection();
					Dictionary<string, List<CommunicationTagRow>> connectionTags = this.BuildSerializableConnectionTags();
					string json = JsonConvert.SerializeObject(new CommunicationConfigData
					{
						Connections = this.Connections.ToList<CommunicationConnection>(),
						Tags = Form_communication.BuildFlattenedConnectionTags(connectionTags),
						ConnectionTags = connectionTags,
						RuntimeSettings = new CommunicationRuntimeSettings
						{
							CameraTriggerConnectionName = this.CameraTriggerConnectionName
						}
					}, Formatting.Indented);
					File.WriteAllText(dialog.FileName, json);
					this.AddLog("Info", string.Format("Exported {0} communication connection(s).", this.Connections.Count));
				}
				catch (Exception ex)
				{
					DXMessageBox.Show(ex.Message, "Export Communication Config");
					this.AddLog("Error", "Export config failed: " + ex.Message);
				}
			}
		}

		// Token: 0x06001AA2 RID: 6818 RVA: 0x0008F544 File Offset: 0x0008D744
		private void AddLog(string level, string message)
		{
			bool flag = !base.Dispatcher.CheckAccess();
			if (flag)
			{
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					this.AddLog(level, message);
				}), Array.Empty<object>());
			}
			else
			{
				this.LogRows.Insert(0, new CommunicationLogRow
				{
					Time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"),
					Level = Form_communication.NormalizeCommunicationLogLevel(level),
					Message = message
				});
				while (this.LogRows.Count > 500)
				{
					this.LogRows.RemoveAt(this.LogRows.Count - 1);
				}
			}
		}

		// Token: 0x06001AA3 RID: 6819 RVA: 0x0008F61C File Offset: 0x0008D81C
		private static string NormalizeCommunicationLogLevel(string level)
		{
			string normalized = (level ?? string.Empty).Trim().ToUpperInvariant();
			string text = normalized;
			string text2 = text;
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
			if (num > 2323356657U)
			{
				if (num <= 3349793328U)
				{
					if (num != 2974687884U)
					{
						if (num != 3086655765U)
						{
							if (num != 3349793328U)
							{
								goto IL_1DE;
							}
							if (!(text2 == "SUCCESS"))
							{
								goto IL_1DE;
							}
							goto IL_1BA;
						}
						else
						{
							if (!(text2 == "INFORMATION"))
							{
								goto IL_1DE;
							}
							goto IL_1D5;
						}
					}
					else if (!(text2 == "ERR"))
					{
						goto IL_1DE;
					}
				}
				else if (num != 3743593777U)
				{
					if (num != 4009907663U)
					{
						if (num != 4220586723U)
						{
							goto IL_1DE;
						}
						if (!(text2 == "TRIGGER"))
						{
							goto IL_1DE;
						}
						return "TRIGGER";
					}
					else
					{
						if (!(text2 == "WARNING"))
						{
							goto IL_1DE;
						}
						goto IL_1B1;
					}
				}
				else if (!(text2 == "ERROR"))
				{
					goto IL_1DE;
				}
				return "ERROR";
			}
			if (num <= 2037175243U)
			{
				if (num != 218589765U)
				{
					if (num != 674452178U)
					{
						if (num != 2037175243U)
						{
							goto IL_1DE;
						}
						if (!(text2 == "CMD"))
						{
							goto IL_1DE;
						}
					}
					else if (!(text2 == "COMMAND"))
					{
						goto IL_1DE;
					}
					return "COMMAND";
				}
				if (!(text2 == "INFO"))
				{
					goto IL_1DE;
				}
				goto IL_1D5;
			}
			else if (num != 2166136261U)
			{
				if (num != 2246359087U)
				{
					if (num != 2323356657U)
					{
						goto IL_1DE;
					}
					if (!(text2 == "WARN"))
					{
						goto IL_1DE;
					}
				}
				else
				{
					if (!(text2 == "OK"))
					{
						goto IL_1DE;
					}
					goto IL_1BA;
				}
			}
			else
			{
				if (text2 == null || text2.Length != 0)
				{
					goto IL_1DE;
				}
				goto IL_1D5;
			}
			IL_1B1:
			return "WARN";
			IL_1BA:
			return "SUCCESS";
			IL_1D5:
			return "INFO";
			IL_1DE:
			return normalized;
		}

		// Token: 0x06001AA4 RID: 6820 RVA: 0x0008F80E File Offset: 0x0008DA0E
		private void ClearLog_Click(object sender, RoutedEventArgs e)
		{
			this.LogRows.Clear();
		}

		// Token: 0x06001AA5 RID: 6821 RVA: 0x0008F820 File Offset: 0x0008DA20
		private void LogGrid_PreviewKeyDown(object sender, KeyEventArgs e)
		{
			bool flag = e.Key == Key.C && Keyboard.Modifiers.HasFlag(ModifierKeys.Control);
			if (flag)
			{
				this.CopySelectedLogMessage();
				e.Handled = true;
			}
		}

		// Token: 0x06001AA6 RID: 6822 RVA: 0x0008F865 File Offset: 0x0008DA65
		private void CopyLogMessage_Click(object sender, RoutedEventArgs e)
		{
			this.CopySelectedLogMessage();
		}

		// Token: 0x06001AA7 RID: 6823 RVA: 0x0008F870 File Offset: 0x0008DA70
		private void CopyLogRow_Click(object sender, RoutedEventArgs e)
		{
			CommunicationLogRow row = this.GetSelectedLogRow();
			bool flag = row == null;
			if (!flag)
			{
				Clipboard.SetText(string.Concat(new string[]
				{
					row.Time,
					"\t",
					row.Level,
					"\t",
					row.Message
				}));
			}
		}

		// Token: 0x06001AA8 RID: 6824 RVA: 0x0008F8CC File Offset: 0x0008DACC
		private void CopyMonitorRow_Click(object sender, RoutedEventArgs e)
		{
			CommunicationMonitorRow row = this.GetSelectedMonitorRow();
			bool flag = row == null;
			if (!flag)
			{
				Clipboard.SetText(CommunicationClipboardTextService.BuildMonitorRowsText(new CommunicationMonitorRow[]
				{
					row
				}), TextDataFormat.UnicodeText);
			}
		}

		// Token: 0x06001AA9 RID: 6825 RVA: 0x0008F901 File Offset: 0x0008DB01
		private void CopyMonitorAll_Click(object sender, RoutedEventArgs e)
		{
			Clipboard.SetText(CommunicationClipboardTextService.BuildMonitorRowsText(this.MonitorRows), TextDataFormat.UnicodeText);
		}

		// Token: 0x06001AAA RID: 6826 RVA: 0x0008F918 File Offset: 0x0008DB18
		protected override void OnClosed(EventArgs e)
		{
			CommunicationStartupService.ConnectionHealthChanged -= this.CommunicationStartupService_ConnectionHealthChanged;
			CalibHandEyeOptionProvider.OptionsSourceChanged -= this.ToolOptionsSourceChanged;
			CameraRuntimeStore.Cameras.CollectionChanged -= this.Cameras_CollectionChanged;
			CameraRuntimeStore.CamerasChanged -= this.CameraRuntimeStore_CamerasChanged;
			this._cameraTagsRefreshTimer.Stop();
			this._cameraTagsRefreshTimer.Tick -= this.CameraTagsRefreshTimer_Tick;
			this.StopMonitorAutoRead(null);
			CancellationTokenSource opcHeartbeatReadCancellation = this._opcHeartbeatReadCancellation;
			if (opcHeartbeatReadCancellation != null)
			{
				opcHeartbeatReadCancellation.Cancel();
			}
			CancellationTokenSource opcHeartbeatReadCancellation2 = this._opcHeartbeatReadCancellation;
			if (opcHeartbeatReadCancellation2 != null)
			{
				opcHeartbeatReadCancellation2.Dispose();
			}
			this._opcHeartbeatReadCancellation = null;
			this._opcHeartbeatReadThread = null;
			this._connectionStatusTimer.Stop();
			this._connectionStatusTimer.Tick -= this.ConnectionStatusTimer_Tick;
			this._opcHeartbeatValueTimer.Stop();
			this._opcHeartbeatValueTimer.Tick -= this.OpcHeartbeatValueTimer_Tick;
			this.SaveConnections();
			base.OnClosed(e);
		}

		// Token: 0x06001AAB RID: 6827 RVA: 0x0008FA28 File Offset: 0x0008DC28
		private void StartOpcHeartbeatReadThread()
		{
			bool flag = this._opcHeartbeatReadThread != null && this._opcHeartbeatReadThread.IsAlive;
			if (!flag)
			{
				Form_communication.OpcHeartbeatMonitorSource source = Form_communication.ResolveOpcHeartbeatSourceFromConfig();
				string configError;
				bool flag2 = !Form_communication.IsValidOpcHeartbeatSource(source, out configError);
				if (flag2)
				{
					this.ShowOpcHeartbeatIdle(configError);
				}
				else
				{
					CommunicationConnection connection = Form_communication.CloneConnection(source.Connection);
					connection.TimeoutMs = Math.Max(3000, (connection.TimeoutMs <= 0) ? 3000 : connection.TimeoutMs);
					bool flag3 = !this._communicationService.IsConnected(connection);
					if (flag3)
					{
						base.Dispatcher.BeginInvoke(new Action(delegate()
						{
							this.ApplyOpcHeartbeatDisplay("--", Brushes.White, new SolidColorBrush(Color.FromRgb(76, 65, 24)), "OPC heartbeat waiting for connected OPC connection. Connection=" + connection.Name + ", Address=" + source.HeartbeatTag.Address);
						}), Array.Empty<object>());
					}
					else
					{
						CancellationTokenSource opcHeartbeatReadCancellation = this._opcHeartbeatReadCancellation;
						if (opcHeartbeatReadCancellation != null)
						{
							opcHeartbeatReadCancellation.Cancel();
						}
						CancellationTokenSource opcHeartbeatReadCancellation2 = this._opcHeartbeatReadCancellation;
						if (opcHeartbeatReadCancellation2 != null)
						{
							opcHeartbeatReadCancellation2.Dispose();
						}
						this._opcHeartbeatReadCancellation = new CancellationTokenSource();
						CancellationToken token = this._opcHeartbeatReadCancellation.Token;
						base.Dispatcher.BeginInvoke(new Action(delegate()
						{
							this.ApplyOpcHeartbeatDisplay("--", Brushes.LightSlateGray, new SolidColorBrush(Color.FromRgb(20, 33, 49)), null);
						}), Array.Empty<object>());
						this._opcHeartbeatReadThread = new Thread(delegate()
						{
							this.OpcHeartbeatReadLoop(token);
						})
						{
							IsBackground = true,
							Name = "OPC Heartbeat UI Reader"
						};
						this._opcHeartbeatReadThread.Start();
					}
				}
			}
		}

		// Token: 0x06001AAC RID: 6828 RVA: 0x0008FBB0 File Offset: 0x0008DDB0
		private void OpcHeartbeatReadLoop(CancellationToken cancellationToken)
		{
			while (!cancellationToken.IsCancellationRequested)
			{
				try
				{
					Form_communication.OpcHeartbeatMonitorSource source = Form_communication.ResolveOpcHeartbeatSourceFromConfig();
					string configError;
					bool flag = !Form_communication.IsValidOpcHeartbeatSource(source, out configError);
					if (flag)
					{
						this.ShowOpcHeartbeatIdle(configError);
					}
					else
					{
						bool flag2 = this.IsOpcHeartbeatConnected(source);
						if (flag2)
						{
							this.ReadAndDisplayOpcHeartbeat(source, cancellationToken);
						}
						else
						{
							this.ShowOpcHeartbeatError("OPC heartbeat waiting for reconnect. Connection=" + source.Connection.Name, source.Connection.Name);
							CommunicationStartupService.EnsureCurrentModelMonitorStarted(CommunicationConfigStorageService.GetConfigPath());
						}
					}
				}
				catch (OperationCanceledException)
				{
					break;
				}
				catch (Exception ex)
				{
					string str = "OPC heartbeat loop error: ";
					Exception baseException = ex.GetBaseException();
					this.ShowOpcHeartbeatError(str + (((baseException != null) ? baseException.Message : null) ?? ex.Message), null);
				}
				try
				{
					Task.Delay(200, cancellationToken).Wait(cancellationToken);
				}
				catch (OperationCanceledException)
				{
					break;
				}
			}
		}

		// Token: 0x06001AAD RID: 6829 RVA: 0x0008FCC8 File Offset: 0x0008DEC8
		private static bool IsValidOpcHeartbeatSource(Form_communication.OpcHeartbeatMonitorSource source, out string message)
		{
			message = null;
			bool flag = source == null;
			bool result;
			if (flag)
			{
				message = "OPC heartbeat tag is not configured.";
				result = false;
			}
			else
			{
				bool flag2 = source.Connection == null;
				if (flag2)
				{
					message = "OPC heartbeat connection is not configured.";
					result = false;
				}
				else
				{
					bool flag3 = source.HeartbeatTag == null;
					if (flag3)
					{
						message = "OPC heartbeat tag is not configured.";
						result = false;
					}
					else
					{
						bool flag4 = string.IsNullOrWhiteSpace(source.HeartbeatTag.Address);
						if (flag4)
						{
							message = "OPC heartbeat tag address is empty.";
							result = false;
						}
						else
						{
							bool flag5 = !Form_communication.IsHeartbeatAddressValid(source.Connection.Protocol, source.HeartbeatTag.Address);
							if (flag5)
							{
								message = (Form_communication.IsMitsubishiConnection(source.Connection) ? ("Heartbeat address is not an MX Component device: " + source.HeartbeatTag.Address) : ("OPC heartbeat address is not an OPC NodeId: " + source.HeartbeatTag.Address));
								result = false;
							}
							else
							{
								result = true;
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001AAE RID: 6830 RVA: 0x0008FDB4 File Offset: 0x0008DFB4
		private static bool IsHeartbeatAddressValid(string protocol, string address)
		{
			bool flag = string.IsNullOrWhiteSpace(address);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = string.Equals(protocol, "MX Component", StringComparison.OrdinalIgnoreCase) || string.Equals(protocol, "MC Protocol", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = !char.IsDigit(address.Trim()[0]);
				}
				else
				{
					result = Form_communication.LooksLikeOpcNodeId(address);
				}
			}
			return result;
		}

		// Token: 0x06001AAF RID: 6831 RVA: 0x0008FE14 File Offset: 0x0008E014
		private void StartOpcHeartbeatValueTimer()
		{
			bool isEnabled = this._opcHeartbeatValueTimer.IsEnabled;
			if (!isEnabled)
			{
				this._opcHeartbeatValueTimer.Interval = TimeSpan.FromMilliseconds(500.0);
				this._opcHeartbeatValueTimer.Tick += this.OpcHeartbeatValueTimer_Tick;
				this._opcHeartbeatValueTimer.Start();
			}
		}

		// Token: 0x06001AB0 RID: 6832 RVA: 0x0008FE71 File Offset: 0x0008E071
		private void OpcHeartbeatValueTimer_Tick(object sender, EventArgs e)
		{
			CommunicationStartupService.EnsureCurrentModelMonitorStarted(CommunicationConfigStorageService.GetConfigPath());
		}

		// Token: 0x06001AB1 RID: 6833 RVA: 0x0008FE80 File Offset: 0x0008E080
		private static Form_communication.OpcHeartbeatMonitorSource ResolveOpcHeartbeatSourceFromConfig()
		{
			CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(CommunicationConfigStorageService.GetConfigPath());
			IEnumerable<CommunicationConnection> connections = config.Connections;
			using (IEnumerator<CommunicationConnection> enumerator = (connections ?? Enumerable.Empty<CommunicationConnection>()).GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					CommunicationConnection connection = enumerator.Current;
					bool flag = connection == null || !Form_communication.HasTagDrivenHeartbeat(connection.Protocol);
					if (!flag)
					{
						CommunicationTagRow heartbeatTag = CommunicationConfigStorageService.GetTagsForConnection(config, connection.Name).FirstOrDefault((CommunicationTagRow x) => x != null && Form_communication.IsHeartbeatTagName(x.Name) && Form_communication.IsHeartbeatAddressValid(connection.Protocol, x.Address));
						bool flag2 = heartbeatTag == null;
						if (!flag2)
						{
							Form_communication.NormalizeConnection(connection);
							return new Form_communication.OpcHeartbeatMonitorSource
							{
								Connection = Form_communication.CloneConnection(connection),
								HeartbeatTag = Form_communication.CloneTagForRead(heartbeatTag)
							};
						}
					}
				}
			}
			return null;
		}

		// Token: 0x06001AB2 RID: 6834 RVA: 0x0008FF88 File Offset: 0x0008E188
		private bool IsOpcHeartbeatConnected(Form_communication.OpcHeartbeatMonitorSource source)
		{
			bool flag = ((source != null) ? source.Connection : null) == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				CommunicationConnection connection = Form_communication.CloneConnection(source.Connection);
				connection.TimeoutMs = Math.Max(3000, (connection.TimeoutMs <= 0) ? 3000 : connection.TimeoutMs);
				result = this._communicationService.IsConnected(connection);
			}
			return result;
		}

		// Token: 0x06001AB3 RID: 6835 RVA: 0x0008FFF0 File Offset: 0x0008E1F0
		private void ReadAndDisplayOpcHeartbeat(Form_communication.OpcHeartbeatMonitorSource source, CancellationToken cancellationToken)
		{
			try
			{
				Form_communication.<>c__DisplayClass65_0 CS$<>8__locals1 = new Form_communication.<>c__DisplayClass65_0();
				CS$<>8__locals1.<>4__this = this;
				CS$<>8__locals1.connection = Form_communication.CloneConnection(source.Connection);
				CS$<>8__locals1.connection.TimeoutMs = Math.Max(3000, (CS$<>8__locals1.connection.TimeoutMs <= 0) ? 3000 : CS$<>8__locals1.connection.TimeoutMs);
				Form_communication.<>c__DisplayClass65_0 CS$<>8__locals2 = CS$<>8__locals1;
				CommunicationTagRow communicationTagRow = new CommunicationTagRow();
				communicationTagRow.Name = source.HeartbeatTag.Name;
				string address = source.HeartbeatTag.Address;
				communicationTagRow.Address = ((address != null) ? address.Trim() : null);
				communicationTagRow.DataType = "BOOL";
				communicationTagRow.ReadWrite = "Read";
				communicationTagRow.Group = source.HeartbeatTag.Group;
				communicationTagRow.Description = source.HeartbeatTag.Description;
				CS$<>8__locals2.readTag = communicationTagRow;
				bool flag = !this._communicationService.IsConnected(CS$<>8__locals1.connection);
				if (flag)
				{
					this.ShowOpcHeartbeatError("OPC heartbeat read skipped because connection is not connected. Connection=" + CS$<>8__locals1.connection.Name + ", Address=" + CS$<>8__locals1.readTag.Address, CS$<>8__locals1.connection.Name);
				}
				else
				{
					cancellationToken.ThrowIfCancellationRequested();
					CommunicationReadResult result = this._communicationService.ReadAll(CS$<>8__locals1.connection, new CommunicationTagRow[]
					{
						CS$<>8__locals1.readTag
					});
					CommunicationMonitorRow row = result.Rows.FirstOrDefault<CommunicationMonitorRow>();
					bool flag2 = !result.Success || row == null || !string.Equals(row.Quality, "Good", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						this.ShowOpcHeartbeatError(string.Concat(new string[]
						{
							"OPC heartbeat read failed. Connection=",
							CS$<>8__locals1.connection.Name,
							", Address=",
							CS$<>8__locals1.readTag.Address,
							", Message=",
							((result != null) ? result.Message : null) ?? "No result",
							", Quality=",
							((row != null) ? row.Quality : null) ?? "No row",
							", Value=",
							((row != null) ? row.Value : null) ?? string.Empty
						}), CS$<>8__locals1.connection.Name);
					}
					else
					{
						CS$<>8__locals1.valueText = Form_communication.NormalizeHeartbeatDisplayValue(row.Value);
						CS$<>8__locals1.isOn = string.Equals(CS$<>8__locals1.valueText, "ON", StringComparison.OrdinalIgnoreCase);
						base.Dispatcher.BeginInvoke(new Action(delegate()
						{
							CS$<>8__locals1.<>4__this._lastOpcHeartbeatErrorMessage = null;
							CS$<>8__locals1.<>4__this.MarkConnectionConnectedByHeartbeat(CS$<>8__locals1.connection.Name, CS$<>8__locals1.isOn);
							CS$<>8__locals1.<>4__this.ApplyOpcHeartbeatDisplay(CS$<>8__locals1.valueText, Brushes.White, CS$<>8__locals1.isOn ? new SolidColorBrush(Color.FromRgb(20, 96, 62)) : new SolidColorBrush(Color.FromRgb(36, 86, 138)), "Connection=" + CS$<>8__locals1.connection.Name + ", Address=" + CS$<>8__locals1.readTag.Address);
						}), Array.Empty<object>());
					}
				}
			}
			catch (OperationCanceledException)
			{
				throw;
			}
			catch (Exception ex)
			{
				string str = "OPC heartbeat read exception: ";
				Exception baseException = ex.GetBaseException();
				string message = str + (((baseException != null) ? baseException.Message : null) ?? ex.Message);
				string connectionName;
				if (source == null)
				{
					connectionName = null;
				}
				else
				{
					CommunicationConnection connection = source.Connection;
					connectionName = ((connection != null) ? connection.Name : null);
				}
				this.ShowOpcHeartbeatError(message, connectionName);
			}
		}

		// Token: 0x06001AB4 RID: 6836 RVA: 0x00090300 File Offset: 0x0008E500
		private void MarkConnectionConnectedByHeartbeat(string connectionName, bool heartbeatValue)
		{
			bool flag = string.IsNullOrWhiteSpace(connectionName);
			if (!flag)
			{
				bool flag2 = !base.Dispatcher.CheckAccess();
				if (flag2)
				{
					base.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this.MarkConnectionConnectedByHeartbeat(connectionName, heartbeatValue);
					}), Array.Empty<object>());
				}
				else
				{
					CommunicationHealthState state = new CommunicationHealthState
					{
						ConnectionName = connectionName,
						IsConnected = true,
						Message = "Connected.",
						LastUpdate = DateTime.Now,
						IsHeartbeatPulse = true,
						HasHeartbeatValue = true,
						HeartbeatValue = heartbeatValue
					};
					this._latestConnectionHealthStates[connectionName] = state;
					CommunicationConnection connection = this.Connections.FirstOrDefault((CommunicationConnection x) => string.Equals(x.Name, connectionName, StringComparison.OrdinalIgnoreCase));
					bool flag3 = connection != null;
					if (flag3)
					{
						connection.Status = "Connected";
						connection.LastUpdate = state.LastUpdate.ToString("HH:mm:ss");
						bool flag4 = string.IsNullOrWhiteSpace(connection.ConnectedTime) || connection.ConnectedTime == "--";
						if (flag4)
						{
							connection.ConnectedTime = "00:00:00";
						}
					}
					this.ApplyCameraTriggerRuntimeState();
					this.RefreshConnectionListVisual();
					bool flag5 = this.SelectedConnection != null && string.Equals(this.SelectedConnection.Name, connectionName, StringComparison.OrdinalIgnoreCase) && this.ConnectionTestText != null;
					if (flag5)
					{
						this.ConnectionTestText.Text = "Connected";
						this.ConnectionTestText.Foreground = Brushes.LimeGreen;
					}
					CommunicationStartupService.ReportExternalConnectionHealth(connectionName, true, "Connected.", false);
				}
			}
		}

		// Token: 0x06001AB5 RID: 6837 RVA: 0x000904D0 File Offset: 0x0008E6D0
		private void ShowOpcHeartbeatIdle(string message)
		{
			string safeMessage = string.IsNullOrWhiteSpace(message) ? "OPC heartbeat tag is not configured." : message;
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				this.ApplyOpcHeartbeatDisplay("--", Brushes.LightSlateGray, new SolidColorBrush(Color.FromRgb(20, 33, 49)), safeMessage);
			}), Array.Empty<object>());
		}

		// Token: 0x06001AB6 RID: 6838 RVA: 0x00090520 File Offset: 0x0008E720
		private void ShowOpcHeartbeatError(string message, string connectionName = null)
		{
			string safeMessage = string.IsNullOrWhiteSpace(message) ? "OPC heartbeat error." : message;
			bool flag = !string.IsNullOrWhiteSpace(connectionName);
			if (flag)
			{
				this.MarkConnectionDisconnectedByHeartbeat(connectionName, safeMessage);
				CommunicationStartupService.ReportExternalConnectionHealth(connectionName, false, safeMessage, true);
			}
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				this.ApplyOpcHeartbeatDisplay("--", Brushes.White, new SolidColorBrush(Color.FromRgb(110, 38, 38)), safeMessage);
			}), Array.Empty<object>());
			DateTime now = DateTime.UtcNow;
			bool flag2 = string.Equals(this._lastOpcHeartbeatErrorMessage, safeMessage, StringComparison.Ordinal) && (now - this._lastOpcHeartbeatErrorLogUtc).TotalMilliseconds < 3000.0;
			if (!flag2)
			{
				this._lastOpcHeartbeatErrorMessage = safeMessage;
				this._lastOpcHeartbeatErrorLogUtc = now;
				this.AddLog("Error", safeMessage);
			}
		}

		// Token: 0x06001AB7 RID: 6839 RVA: 0x00090604 File Offset: 0x0008E804
		private void MarkConnectionDisconnectedByHeartbeat(string connectionName, string message)
		{
			bool flag = string.IsNullOrWhiteSpace(connectionName);
			if (!flag)
			{
				bool flag2 = !base.Dispatcher.CheckAccess();
				if (flag2)
				{
					base.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this.MarkConnectionDisconnectedByHeartbeat(connectionName, message);
					}), Array.Empty<object>());
				}
				else
				{
					CommunicationHealthState state = new CommunicationHealthState
					{
						ConnectionName = connectionName,
						IsConnected = false,
						Message = (string.IsNullOrWhiteSpace(message) ? "OPC heartbeat disconnected." : message),
						LastUpdate = DateTime.Now,
						IsHeartbeatPulse = false,
						HasHeartbeatValue = false,
						HeartbeatValue = false
					};
					this._latestConnectionHealthStates[connectionName] = state;
					CommunicationConnection connection = this.Connections.FirstOrDefault((CommunicationConnection x) => string.Equals(x.Name, connectionName, StringComparison.OrdinalIgnoreCase));
					bool flag3 = connection != null;
					if (flag3)
					{
						connection.Status = "Disconnected";
						connection.LastUpdate = state.LastUpdate.ToString("HH:mm:ss");
					}
					this.ApplyCameraTriggerRuntimeState();
					this.RefreshConnectionListVisual();
					bool flag4 = this.SelectedConnection != null && string.Equals(this.SelectedConnection.Name, connectionName, StringComparison.OrdinalIgnoreCase) && this.ConnectionTestText != null;
					if (flag4)
					{
						this.ConnectionTestText.Text = state.Message;
						this.ConnectionTestText.Foreground = Brushes.IndianRed;
					}
				}
			}
		}

		// Token: 0x06001AB8 RID: 6840 RVA: 0x0009079C File Offset: 0x0008E99C
		private void UpdateOpcHeartbeatStatus(CommunicationHealthState state = null)
		{
			bool flag = this.OpcHeartbeatStatusEdit == null;
			if (!flag)
			{
				CommunicationConnection connection = this.SelectedConnection;
				bool flag2 = connection == null || !Form_communication.HasTagDrivenHeartbeat(connection.Protocol);
				if (flag2)
				{
					this.ApplyOpcHeartbeatDisplay("--", Brushes.LightSlateGray, new SolidColorBrush(Color.FromRgb(20, 33, 49)), null);
					this._lastOpcHeartbeatDirectUpdateUtc = DateTime.MinValue;
				}
				else
				{
					bool flag3 = state == null || !string.Equals(state.ConnectionName, connection.Name, StringComparison.OrdinalIgnoreCase);
					if (flag3)
					{
						bool flag4 = !this._latestConnectionHealthStates.TryGetValue(connection.Name, out state);
						if (flag4)
						{
							CommunicationStartupService.TryGetConnectionHealth(connection.Name, out state);
						}
					}
					bool hasFreshDirectValue = (DateTime.UtcNow - this._lastOpcHeartbeatDirectUpdateUtc).TotalMilliseconds < 1500.0;
					bool flag5 = state == null;
					if (flag5)
					{
						bool flag6 = hasFreshDirectValue;
						if (!flag6)
						{
							this.ApplyOpcHeartbeatDisplay("--", Brushes.Gold, new SolidColorBrush(Color.FromRgb(45, 38, 18)), null);
						}
					}
					else
					{
						bool hasHeartbeatValue = state.HasHeartbeatValue;
						if (hasHeartbeatValue)
						{
							string valueText = state.HeartbeatValue ? "ON" : "OFF";
							this.ApplyOpcHeartbeatDisplay(valueText, Brushes.White, (!state.IsConnected) ? new SolidColorBrush(Color.FromRgb(110, 38, 38)) : (state.HeartbeatValue ? new SolidColorBrush(Color.FromRgb(20, 96, 62)) : new SolidColorBrush(Color.FromRgb(36, 86, 138))), null);
						}
						else
						{
							bool flag7 = !state.IsConnected;
							if (flag7)
							{
								bool flag8 = hasFreshDirectValue;
								if (!flag8)
								{
									this.ApplyOpcHeartbeatDisplay("--", Brushes.White, new SolidColorBrush(Color.FromRgb(110, 38, 38)), null);
								}
							}
							else
							{
								bool flag9 = hasFreshDirectValue;
								if (!flag9)
								{
									this.ApplyOpcHeartbeatDisplay("--", Brushes.Gold, new SolidColorBrush(Color.FromRgb(45, 38, 18)), null);
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001AB9 RID: 6841 RVA: 0x000909A4 File Offset: 0x0008EBA4
		private bool TryUpdateOpcHeartbeatFromMonitorRows()
		{
			Form_communication.<>c__DisplayClass71_0 CS$<>8__locals1 = new Form_communication.<>c__DisplayClass71_0();
			bool flag = this.OpcHeartbeatStatusEdit == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				CommunicationConnection connection = this.SelectedConnection;
				bool flag2 = connection == null || !Form_communication.HasTagDrivenHeartbeat(connection.Protocol);
				if (flag2)
				{
					result = false;
				}
				else
				{
					Form_communication.OpcHeartbeatMonitorSource source = this.ResolveOpcHeartbeatMonitorSource();
					CS$<>8__locals1.heartbeatTag = ((source != null) ? source.HeartbeatTag : null);
					Form_communication.<>c__DisplayClass71_0 CS$<>8__locals2 = CS$<>8__locals1;
					CommunicationTagRow heartbeatTag = CS$<>8__locals1.heartbeatTag;
					string heartbeatAddress;
					if (heartbeatTag == null)
					{
						heartbeatAddress = null;
					}
					else
					{
						string address = heartbeatTag.Address;
						heartbeatAddress = ((address != null) ? address.Trim() : null);
					}
					CS$<>8__locals2.heartbeatAddress = heartbeatAddress;
					CommunicationMonitorRow row = null;
					bool flag3 = !string.IsNullOrWhiteSpace(CS$<>8__locals1.heartbeatAddress);
					if (flag3)
					{
						row = this.MonitorRows.FirstOrDefault(delegate(CommunicationMonitorRow x)
						{
							bool result2;
							if (x != null)
							{
								string address2 = x.Address;
								result2 = string.Equals((address2 != null) ? address2.Trim() : null, CS$<>8__locals1.heartbeatAddress, StringComparison.OrdinalIgnoreCase);
							}
							else
							{
								result2 = false;
							}
							return result2;
						});
					}
					bool flag4 = row == null && CS$<>8__locals1.heartbeatTag != null;
					if (flag4)
					{
						row = this.MonitorRows.FirstOrDefault(delegate(CommunicationMonitorRow x)
						{
							bool result2;
							if (x != null)
							{
								string tagName = x.TagName;
								string a = (tagName != null) ? tagName.Trim() : null;
								string name = CS$<>8__locals1.heartbeatTag.Name;
								result2 = (string.Equals(a, (name != null) ? name.Trim() : null, StringComparison.OrdinalIgnoreCase) || Form_communication.IsHeartbeatTagName(x.TagName) || Form_communication.IsHeartbeatTagName(x.Description));
							}
							else
							{
								result2 = false;
							}
							return result2;
						});
					}
					bool flag5 = row == null || !string.Equals(row.Quality, "Good", StringComparison.OrdinalIgnoreCase);
					if (flag5)
					{
						result = false;
					}
					else
					{
						string valueText = Form_communication.NormalizeHeartbeatDisplayValue(row.Value);
						bool isOn = string.Equals(valueText, "ON", StringComparison.OrdinalIgnoreCase);
						this.ApplyOpcHeartbeatDisplay(valueText, Brushes.White, isOn ? new SolidColorBrush(Color.FromRgb(20, 96, 62)) : new SolidColorBrush(Color.FromRgb(36, 86, 138)), null);
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x06001ABA RID: 6842 RVA: 0x00090B18 File Offset: 0x0008ED18
		private static string NormalizeHeartbeatDisplayValue(string value)
		{
			string text = (value ?? string.Empty).Trim();
			bool flag = string.Equals(text, "ON", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "TRUE", StringComparison.OrdinalIgnoreCase) || text == "1";
			string result;
			if (flag)
			{
				result = "ON";
			}
			else
			{
				bool flag2 = string.Equals(text, "OFF", StringComparison.OrdinalIgnoreCase) || string.Equals(text, "FALSE", StringComparison.OrdinalIgnoreCase) || text == "0";
				if (flag2)
				{
					result = "OFF";
				}
				else
				{
					result = (string.IsNullOrWhiteSpace(text) ? "--" : text);
				}
			}
			return result;
		}

		// Token: 0x06001ABB RID: 6843 RVA: 0x00090BB8 File Offset: 0x0008EDB8
		[DebuggerStepThrough]
		private void RefreshSelectedOpcHeartbeatValueAsync()
		{
			Form_communication.<RefreshSelectedOpcHeartbeatValueAsync>d__73 <RefreshSelectedOpcHeartbeatValueAsync>d__ = new Form_communication.<RefreshSelectedOpcHeartbeatValueAsync>d__73();
			<RefreshSelectedOpcHeartbeatValueAsync>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<RefreshSelectedOpcHeartbeatValueAsync>d__.<>4__this = this;
			<RefreshSelectedOpcHeartbeatValueAsync>d__.<>1__state = -1;
			<RefreshSelectedOpcHeartbeatValueAsync>d__.<>t__builder.Start<Form_communication.<RefreshSelectedOpcHeartbeatValueAsync>d__73>(ref <RefreshSelectedOpcHeartbeatValueAsync>d__);
		}

		// Token: 0x06001ABC RID: 6844 RVA: 0x00090BF4 File Offset: 0x0008EDF4
		private Form_communication.OpcHeartbeatMonitorSource ResolveOpcHeartbeatMonitorSource()
		{
			CommunicationConnection connection = Form_communication.IsOpcUaConnection(this.SelectedConnection) ? this.SelectedConnection : this.Connections.FirstOrDefault(new Func<CommunicationConnection, bool>(Form_communication.IsOpcUaConnection));
			bool flag = connection == null;
			Form_communication.OpcHeartbeatMonitorSource result;
			if (flag)
			{
				result = null;
			}
			else
			{
				List<CommunicationTagRow> tags = (connection == this.SelectedConnection) ? this.TagRows.ToList<CommunicationTagRow>() : this.GetCachedTagsForConnection(connection);
				Form_communication.OpcHeartbeatMonitorSource opcHeartbeatMonitorSource = new Form_communication.OpcHeartbeatMonitorSource();
				opcHeartbeatMonitorSource.Connection = connection;
				IEnumerable<CommunicationTagRow> enumerable = tags;
				opcHeartbeatMonitorSource.HeartbeatTag = (enumerable ?? Enumerable.Empty<CommunicationTagRow>()).FirstOrDefault((CommunicationTagRow x) => Form_communication.IsHeartbeatTagName((x != null) ? x.Name : null));
				result = opcHeartbeatMonitorSource;
			}
			return result;
		}

		// Token: 0x06001ABD RID: 6845 RVA: 0x00090CA4 File Offset: 0x0008EEA4
		private List<CommunicationTagRow> GetCachedTagsForConnection(CommunicationConnection connection)
		{
			bool flag = connection == null;
			List<CommunicationTagRow> result;
			if (flag)
			{
				result = new List<CommunicationTagRow>();
			}
			else
			{
				string key = Form_communication.GetConnectionTagKey(connection);
				List<CommunicationTagRow> tags;
				bool flag2 = this._tagsByConnection.TryGetValue(key, out tags);
				if (flag2)
				{
					result = Form_communication.CloneTagRows(tags);
				}
				else
				{
					result = new List<CommunicationTagRow>();
				}
			}
			return result;
		}

		// Token: 0x06001ABE RID: 6846 RVA: 0x00090CF0 File Offset: 0x0008EEF0
		private void SetOpcHeartbeatText(string text, Brush foreground, Brush background)
		{
			bool flag = this.OpcHeartbeatStatusEdit != null;
			if (flag)
			{
				this.OpcHeartbeatStatusEdit.EditValue = text;
				this.OpcHeartbeatStatusEdit.Foreground = foreground;
				this.OpcHeartbeatStatusEdit.Background = background;
			}
			this._lastOpcHeartbeatDirectUpdateUtc = DateTime.UtcNow;
		}

		// Token: 0x06001ABF RID: 6847 RVA: 0x00090D44 File Offset: 0x0008EF44
		private static bool HasTagDrivenHeartbeat(string protocol)
		{
			return string.Equals(protocol, "OPC UA", StringComparison.OrdinalIgnoreCase) || string.Equals(protocol, "MX Component", StringComparison.OrdinalIgnoreCase) || string.Equals(protocol, "MC Protocol", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001AC0 RID: 6848 RVA: 0x00090D84 File Offset: 0x0008EF84
		private void ApplyOpcHeartbeatDisplay(string text, Brush foreground, Brush background, string tooltip = null)
		{
			bool flag = this.OpcHeartbeatStatusEdit != null;
			if (flag)
			{
				this.OpcHeartbeatStatusEdit.EditValue = text;
				this.OpcHeartbeatStatusEdit.Foreground = foreground;
				this.OpcHeartbeatStatusEdit.Background = background;
				this.OpcHeartbeatStatusEdit.ToolTip = tooltip;
			}
		}

		// Token: 0x06001AC1 RID: 6849 RVA: 0x00090DD8 File Offset: 0x0008EFD8
		private void SetMonitorRows(IEnumerable<CommunicationMonitorRow> rows)
		{
			bool flag = !base.Dispatcher.CheckAccess();
			if (flag)
			{
				List<CommunicationMonitorRow> bufferedRows = (rows ?? Enumerable.Empty<CommunicationMonitorRow>()).ToList<CommunicationMonitorRow>();
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					this.SetMonitorRows(bufferedRows);
				}), Array.Empty<object>());
			}
			else
			{
				List<CommunicationMonitorRow> monitorRows = (rows ?? Enumerable.Empty<CommunicationMonitorRow>()).ToList<CommunicationMonitorRow>();
				this.MonitorRows.Clear();
				foreach (CommunicationMonitorRow row in monitorRows)
				{
					this.MonitorRows.Add(row);
				}
				bool flag2 = this.MonitorGrid != null;
				if (flag2)
				{
					this.MonitorGrid.ItemsSource = null;
					this.MonitorGrid.ItemsSource = this.MonitorRows;
					this.MonitorGrid.RefreshData();
				}
				bool flag3 = this.CommunicationTabs != null && this.DataMonitorTab != null;
				if (flag3)
				{
					this.CommunicationTabs.SelectedItem = this.DataMonitorTab;
				}
			}
		}

		// Token: 0x06001AC2 RID: 6850 RVA: 0x00090F0C File Offset: 0x0008F10C
		private void SyncMonitorAutoReadState()
		{
			bool flag = !this.AutoRefresh || this.SelectedConnection == null;
			if (flag)
			{
				this.StopMonitorAutoRead(null);
			}
			else
			{
				this.StartMonitorAutoRead(this.SelectedConnection);
			}
		}

		// Token: 0x06001AC3 RID: 6851 RVA: 0x00090F4C File Offset: 0x0008F14C
		private void StartMonitorAutoRead(CommunicationConnection connection)
		{
			bool flag = connection == null || !this.AutoRefresh;
			if (!flag)
			{
				bool flag2 = this._monitorReadConnection != null && string.Equals(this._monitorReadConnection.Name, connection.Name, StringComparison.OrdinalIgnoreCase) && this._monitorReadTask != null && !this._monitorReadTask.IsCompleted;
				if (!flag2)
				{
					this.StopMonitorAutoRead(null);
					this._monitorReadConnection = connection;
					this._monitorReadCancellation = new CancellationTokenSource();
					CancellationToken token = this._monitorReadCancellation.Token;
					this._monitorReadTask = Task.Run(() => this.MonitorReadLoopAsync(connection, token), token);
					this.AddLog("Info", connection.Name + " auto monitor thread started.");
				}
			}
		}

		// Token: 0x06001AC4 RID: 6852 RVA: 0x00091040 File Offset: 0x0008F240
		private void StopMonitorAutoRead(CommunicationConnection connection = null)
		{
			bool flag = connection != null && this._monitorReadConnection != null && connection != this._monitorReadConnection && !string.Equals(connection.Name, this._monitorReadConnection.Name, StringComparison.OrdinalIgnoreCase);
			if (!flag)
			{
				CancellationTokenSource monitorReadCancellation = this._monitorReadCancellation;
				if (monitorReadCancellation != null)
				{
					monitorReadCancellation.Cancel();
				}
				this._monitorReadConnection = null;
				this._isMonitorReadBusy = false;
			}
		}

		// Token: 0x06001AC5 RID: 6853 RVA: 0x000910A8 File Offset: 0x0008F2A8
		[DebuggerStepThrough]
		private Task MonitorReadLoopAsync(CommunicationConnection connection, CancellationToken cancellationToken)
		{
			Form_communication.<MonitorReadLoopAsync>d__83 <MonitorReadLoopAsync>d__ = new Form_communication.<MonitorReadLoopAsync>d__83();
			<MonitorReadLoopAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<MonitorReadLoopAsync>d__.<>4__this = this;
			<MonitorReadLoopAsync>d__.connection = connection;
			<MonitorReadLoopAsync>d__.cancellationToken = cancellationToken;
			<MonitorReadLoopAsync>d__.<>1__state = -1;
			<MonitorReadLoopAsync>d__.<>t__builder.Start<Form_communication.<MonitorReadLoopAsync>d__83>(ref <MonitorReadLoopAsync>d__);
			return <MonitorReadLoopAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06001AC6 RID: 6854 RVA: 0x000910FC File Offset: 0x0008F2FC
		private int GetRefreshIntervalMs()
		{
			bool flag = this.ReadCycleMs > 0;
			int result;
			if (flag)
			{
				result = Math.Max(this.ReadCycleMs, 10);
			}
			else
			{
				CommunicationConnection selectedConnection = this.SelectedConnection;
				string intervalText = (selectedConnection != null) ? selectedConnection.ExchangeInterval : null;
				bool flag2 = string.IsNullOrWhiteSpace(intervalText);
				if (flag2)
				{
					CommunicationConnection editingConnection = this.EditingConnection;
					intervalText = ((editingConnection != null) ? editingConnection.ExchangeInterval : null);
				}
				bool flag3 = string.IsNullOrWhiteSpace(intervalText);
				if (flag3)
				{
					intervalText = this.RefreshInterval;
				}
				int intervalMs = Form_communication.ExtractFirstInteger(intervalText, 10);
				result = Math.Max(intervalMs, 10);
			}
			return result;
		}

		// Token: 0x06001AC7 RID: 6855 RVA: 0x00091184 File Offset: 0x0008F384
		private static int ExtractFirstInteger(string text, int fallback)
		{
			bool flag = string.IsNullOrWhiteSpace(text);
			int result;
			if (flag)
			{
				result = fallback;
			}
			else
			{
				string digits = new string(text.Where(new Func<char, bool>(char.IsDigit)).ToArray<char>());
				int value;
				result = (int.TryParse(digits, out value) ? value : fallback);
			}
			return result;
		}

		// Token: 0x06001AC8 RID: 6856 RVA: 0x000911D0 File Offset: 0x0008F3D0
		private static string FormatReadCycle(int readCycleMs)
		{
			return string.Format("{0} ms", Math.Max(readCycleMs, 10));
		}

		// Token: 0x06001AC9 RID: 6857 RVA: 0x000911FC File Offset: 0x0008F3FC
		private void SetReadCycleText(int readCycleMs)
		{
			string text = Math.Max(readCycleMs, 10).ToString(CultureInfo.InvariantCulture);
			bool flag = string.Equals(this._readCycleText, text, StringComparison.Ordinal);
			if (!flag)
			{
				this._readCycleText = text;
				this.OnPropertyChanged("ReadCycleText");
			}
		}

		// Token: 0x06001ACA RID: 6858 RVA: 0x00091248 File Offset: 0x0008F448
		private Form_communication.MonitorReadRequest CaptureMonitorReadRequest()
		{
			try
			{
				GridControl tagGrid = this.TagGrid;
				if (tagGrid != null)
				{
					DataViewBase view = tagGrid.View;
					if (view != null)
					{
						view.CommitEditing();
					}
				}
			}
			catch
			{
			}
			bool useOpcTags = this.IsOpcUaSelected();
			bool flag = !useOpcTags;
			if (flag)
			{
				this.PullMonitorSelectorValues();
			}
			return new Form_communication.MonitorReadRequest
			{
				UseOpcTags = useOpcTags,
				StartAddress = (useOpcTags ? "OPC Tags" : this.MonitorStartAddress),
				EndAddress = (useOpcTags ? string.Empty : this.MonitorEndAddress),
				DataType = (useOpcTags ? "OPC UA" : this.MonitorDataType),
				FunctionCode = (useOpcTags ? "Read OPC Tags" : this.MonitorFunctionCode),
				Tags = (useOpcTags ? this.CaptureOpcMonitorTags() : null)
			};
		}

		// Token: 0x06001ACB RID: 6859 RVA: 0x00091324 File Offset: 0x0008F524
		private Form_communication.MonitorReadExecution ReadMonitorRangeWithReconnect(CommunicationConnection connection, Form_communication.MonitorReadRequest request)
		{
			bool flag = request == null || !request.UseOpcTags;
			Form_communication.MonitorReadExecution result;
			if (flag)
			{
				ModbusMonitorReadExecution modbusExecution = this._modbusMonitorService.ReadRangeWithReconnect(connection, new ModbusMonitorReadRequest
				{
					StartAddress = ((request != null) ? request.StartAddress : null),
					EndAddress = ((request != null) ? request.EndAddress : null),
					DataType = ((request != null) ? request.DataType : null),
					FunctionCode = ((request != null) ? request.FunctionCode : null)
				}, 3000, 500);
				result = new Form_communication.MonitorReadExecution
				{
					ConnectResult = modbusExecution.ConnectResult,
					ReadResult = modbusExecution.ReadResult
				};
			}
			else
			{
				result = new Form_communication.MonitorReadExecution
				{
					ConnectResult = null,
					ReadResult = this.ReadMonitorRequest(connection, request)
				};
			}
			return result;
		}

		// Token: 0x06001ACC RID: 6860 RVA: 0x000913F4 File Offset: 0x0008F5F4
		private Form_communication.MonitorReadExecution BrowseOpcTagsWithReconnect(CommunicationConnection connection)
		{
			CommunicationReadResult readResult = this._communicationService.BrowseOpcTags(connection);
			CommunicationOperationResult connectResult = null;
			bool flag = !readResult.Success && string.Equals(readResult.Message, "Connection is not connected.", StringComparison.OrdinalIgnoreCase);
			if (flag)
			{
				connectResult = this._communicationService.Connect(Form_communication.CloneConnectionWithTimeout(connection, 500));
				readResult = (connectResult.Success ? this._communicationService.BrowseOpcTags(connection) : CommunicationReadResult.Fail(connectResult.Message));
			}
			return new Form_communication.MonitorReadExecution
			{
				ConnectResult = connectResult,
				ReadResult = readResult
			};
		}

		// Token: 0x06001ACD RID: 6861 RVA: 0x00091488 File Offset: 0x0008F688
		private CommunicationReadResult ReadMonitorRequest(CommunicationConnection connection, Form_communication.MonitorReadRequest request)
		{
			bool flag = request != null && request.UseOpcTags;
			CommunicationReadResult result;
			if (flag)
			{
				bool flag2 = request.Tags == null || request.Tags.Count == 0;
				if (flag2)
				{
					result = CommunicationReadResult.Fail("No readable OPC UA tags are configured. Add tags in Tag Management with R/W=Read and Address=OPC NodeId.");
				}
				else
				{
					result = this._communicationService.ReadAll(connection, request.Tags);
				}
			}
			else
			{
				result = CommunicationReadResult.Fail("Modbus monitor reads are handled by ModbusMonitorService.");
			}
			return result;
		}

		// Token: 0x06001ACE RID: 6862 RVA: 0x000914F8 File Offset: 0x0008F6F8
		private List<CommunicationTagRow> CaptureOpcMonitorTags()
		{
			bool flag = this._lastBrowsedOpcTags.Count > 0;
			List<CommunicationTagRow> result;
			if (flag)
			{
				result = this._lastBrowsedOpcTags.Select(new Func<CommunicationTagRow, CommunicationTagRow>(Form_communication.CloneTagForRead)).ToList<CommunicationTagRow>();
			}
			else
			{
				result = this.TagRows.Where(new Func<CommunicationTagRow, bool>(Form_communication.IsReadableOpcMonitorTag)).Select(new Func<CommunicationTagRow, CommunicationTagRow>(Form_communication.CloneTagForRead)).ToList<CommunicationTagRow>();
			}
			return result;
		}

		// Token: 0x06001ACF RID: 6863 RVA: 0x00091568 File Offset: 0x0008F768
		private static Form_communication.MonitorReadRequest CreateOpcBrowseRequest()
		{
			return new Form_communication.MonitorReadRequest
			{
				UseOpcTags = true,
				StartAddress = "OPC Browse",
				EndAddress = string.Empty,
				DataType = "OPC UA",
				FunctionCode = "Browse OPC Tags"
			};
		}

		// Token: 0x06001AD0 RID: 6864 RVA: 0x000915B8 File Offset: 0x0008F7B8
		private void UpdateLastBrowsedOpcTagsFromRows(IEnumerable<CommunicationMonitorRow> rows)
		{
			this._lastBrowsedOpcTags.Clear();
			foreach (CommunicationMonitorRow row in (rows ?? Enumerable.Empty<CommunicationMonitorRow>()))
			{
				bool flag = row == null || string.IsNullOrWhiteSpace(row.Address);
				if (!flag)
				{
					this._lastBrowsedOpcTags.Add(new CommunicationTagRow
					{
						Group = row.Group,
						Name = (string.IsNullOrWhiteSpace(row.TagName) ? row.Address : row.TagName),
						Address = row.Address,
						DataType = row.DataType,
						ReadWrite = "Read",
						Description = row.Description
					});
				}
			}
		}

		// Token: 0x06001AD1 RID: 6865 RVA: 0x000916A4 File Offset: 0x0008F8A4
		private void UpdateOpcAddressOptionsForTag(CommunicationTagRow tag)
		{
			bool flag = this.IsMxComponentSelected();
			if (flag)
			{
				this.ShowMxComponentAddressHints();
			}
			else
			{
				bool flag2 = !this.IsOpcUaSelected();
				if (flag2)
				{
					this.OpcTagAddressOptions.Clear();
				}
				else
				{
					string requestedType = (tag != null) ? tag.DataType : null;
					List<string> options = this.BuildOpcAddressOptions(requestedType).ToList<string>();
					this.OpcTagAddressOptions.Clear();
					foreach (string option in options)
					{
						this.OpcTagAddressOptions.Add(option);
					}
					bool flag3 = this.TagAddressEditSettings != null;
					if (flag3)
					{
						this.TagAddressEditSettings.ItemsSource = this.OpcTagAddressOptions;
					}
				}
			}
		}

		// Token: 0x06001AD2 RID: 6866 RVA: 0x0009177C File Offset: 0x0008F97C
		private void ShowMxComponentAddressHints()
		{
			this.OpcTagAddressOptions.Clear();
			this.OpcTagAddressOptions.Add("None");
			foreach (string hint in new string[]
			{
				"D0",
				"D100",
				"D200",
				"M0",
				"M100",
				"X0",
				"X1A",
				"Y0",
				"Y20",
				"R0",
				"W0",
				"B0",
				"L0"
			})
			{
				this.OpcTagAddressOptions.Add(hint);
			}
			bool flag = this.TagAddressEditSettings != null;
			if (flag)
			{
				this.TagAddressEditSettings.ItemsSource = this.OpcTagAddressOptions;
			}
		}

		// Token: 0x06001AD3 RID: 6867 RVA: 0x0009185C File Offset: 0x0008FA5C
		private IEnumerable<string> BuildOpcAddressOptions(string requestedType)
		{
			Form_communication.<BuildOpcAddressOptions>d__97 <BuildOpcAddressOptions>d__ = new Form_communication.<BuildOpcAddressOptions>d__97(-2);
			<BuildOpcAddressOptions>d__.<>4__this = this;
			<BuildOpcAddressOptions>d__.<>3__requestedType = requestedType;
			return <BuildOpcAddressOptions>d__;
		}

		// Token: 0x06001AD4 RID: 6868 RVA: 0x00091874 File Offset: 0x0008FA74
		private static bool IsOpcTypeCompatible(string requestedType, string opcDataType)
		{
			string requested = Form_communication.NormalizeOpcTypeName(requestedType);
			bool flag = string.IsNullOrWhiteSpace(requested);
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				string opc = Form_communication.NormalizeOpcTypeName(Form_communication.RemoveOpcArraySuffix(opcDataType));
				bool flag2 = string.IsNullOrWhiteSpace(opc);
				if (flag2)
				{
					result = true;
				}
				else
				{
					string text = requested;
					string text2 = text;
					uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
					if (num > 2214109151U)
					{
						if (num <= 2316881829U)
						{
							if (num != 2286151596U)
							{
								if (num != 2316881829U)
								{
									goto IL_2CC;
								}
								if (!(text2 == "FLOAT"))
								{
									goto IL_2CC;
								}
							}
							else
							{
								if (!(text2 == "UINT32"))
								{
									goto IL_2CC;
								}
								return opc == "UINT32" || opc == "UINT" || opc == "DWORD";
							}
						}
						else if (num != 2991499325U)
						{
							if (num != 3560013981U)
							{
								if (num != 4127814520U)
								{
									goto IL_2CC;
								}
								if (!(text2 == "STRING"))
								{
									goto IL_2CC;
								}
								return opc == "STRING";
							}
							else if (!(text2 == "REAL"))
							{
								goto IL_2CC;
							}
						}
						else
						{
							if (!(text2 == "BOOL"))
							{
								goto IL_2CC;
							}
							return opc == "BOOLEAN" || opc == "BOOL";
						}
						return opc == "SINGLE" || opc == "FLOAT" || opc == "REAL" || opc == "DOUBLE" || opc == "LREAL";
					}
					if (num > 268302705U)
					{
						if (num != 843930396U)
						{
							if (num != 2214109151U)
							{
								goto IL_2CC;
							}
							if (!(text2 == "INT32"))
							{
								goto IL_2CC;
							}
						}
						else if (!(text2 == "DINT"))
						{
							goto IL_2CC;
						}
						return opc == "INT32" || opc == "INT" || opc == "DINT";
					}
					if (num != 71211698U)
					{
						if (num == 268302705U)
						{
							if (text2 == "INT16")
							{
								return opc == "INT16" || opc == "SHORT";
							}
						}
					}
					else if (text2 == "UINT16")
					{
						return opc == "UINT16" || opc == "USHORT" || opc == "WORD";
					}
					IL_2CC:
					result = (requested == opc);
				}
			}
			return result;
		}

		// Token: 0x06001AD5 RID: 6869 RVA: 0x00091B58 File Offset: 0x0008FD58
		private static string NormalizeOpcTypeName(string value)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				result = value.Trim().ToUpperInvariant();
			}
			return result;
		}

		// Token: 0x06001AD6 RID: 6870 RVA: 0x00091B88 File Offset: 0x0008FD88
		private static string RemoveOpcArraySuffix(string dataType)
		{
			bool flag = string.IsNullOrWhiteSpace(dataType);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				int index = dataType.IndexOf('[');
				result = ((index > 0) ? dataType.Substring(0, index) : dataType);
			}
			return result;
		}

		// Token: 0x06001AD7 RID: 6871 RVA: 0x00091BC4 File Offset: 0x0008FDC4
		private static int TryGetOpcArrayLength(string dataType)
		{
			bool flag = string.IsNullOrWhiteSpace(dataType);
			int result;
			if (flag)
			{
				result = -1;
			}
			else
			{
				int start = dataType.IndexOf('[');
				int end = dataType.IndexOf(']', start + 1);
				bool flag2 = start < 0 || end <= start;
				if (flag2)
				{
					result = -1;
				}
				else
				{
					string lengthText = dataType.Substring(start + 1, end - start - 1);
					int length;
					result = (int.TryParse(lengthText, NumberStyles.Integer, CultureInfo.InvariantCulture, out length) ? length : -1);
				}
			}
			return result;
		}

		// Token: 0x06001AD8 RID: 6872 RVA: 0x00091C3C File Offset: 0x0008FE3C
		private static bool IsReadableOpcMonitorTag(CommunicationTagRow tag)
		{
			bool flag = tag == null || string.IsNullOrWhiteSpace(tag.Address);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string readWrite = tag.ReadWrite ?? string.Empty;
				result = (readWrite.IndexOf("Read", StringComparison.OrdinalIgnoreCase) >= 0);
			}
			return result;
		}

		// Token: 0x06001AD9 RID: 6873 RVA: 0x00091C8C File Offset: 0x0008FE8C
		private static CommunicationTagRow CloneTagForRead(CommunicationTagRow tag)
		{
			return new CommunicationTagRow
			{
				Group = tag.Group,
				Name = tag.Name,
				Address = tag.Address,
				DataType = tag.DataType,
				ReadWrite = tag.ReadWrite,
				LinkedToolName = tag.LinkedToolName,
				ResultField = tag.ResultField,
				MaxResultCount = tag.MaxResultCount,
				Description = tag.Description
			};
		}

		// Token: 0x06001ADA RID: 6874 RVA: 0x00091D18 File Offset: 0x0008FF18
		private static CommunicationConnection CloneConnectionWithTimeout(CommunicationConnection source, int timeoutMs)
		{
			bool flag = source == null;
			CommunicationConnection result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new CommunicationConnection
				{
					Name = source.Name,
					Protocol = source.Protocol,
					Description = source.Description,
					IpAddress = source.IpAddress,
					Port = source.Port,
					TimeoutMs = Math.Max(100, timeoutMs),
					ExchangeInterval = source.ExchangeInterval,
					ByteOrder = source.ByteOrder,
					WordOrder = source.WordOrder,
					FloatFormat = source.FloatFormat,
					KeepAlive = source.KeepAlive,
					AutoReconnect = source.AutoReconnect,
					MonitorStartAddress = source.MonitorStartAddress,
					MonitorEndAddress = source.MonitorEndAddress,
					MonitorDataType = source.MonitorDataType,
					MonitorFunctionCode = source.MonitorFunctionCode
				};
			}
			return result;
		}

		// Token: 0x06001ADB RID: 6875 RVA: 0x00091E10 File Offset: 0x00090010
		private void ApplyMonitorReadResult(CommunicationConnection connection, Form_communication.MonitorReadRequest request, Form_communication.MonitorReadExecution execution, string actionName)
		{
			CommunicationReadResult result = execution.ReadResult;
			bool flag = execution.ConnectResult != null;
			if (flag)
			{
				bool transportHealthy = execution.ConnectResult.Success && (result.Success || !PlcCommunicationService.IsRecoverableTransportFailure(result.Message));
				connection.Status = (transportHealthy ? "Connected" : "Disconnected");
				CommunicationStartupService.ReportExternalConnectionHealth(connection.Name, transportHealthy, transportHealthy ? "Connected." : (string.IsNullOrWhiteSpace(result.Message) ? execution.ConnectResult.Message : result.Message), true);
				connection.AddTraffic(execution.ConnectResult.SentBytes, execution.ConnectResult.ReceivedBytes);
				this.ApplyCameraTriggerRuntimeState();
				this.RefreshConnectionListVisual();
			}
			this.SetMonitorRows(result.Rows);
			bool flag2 = this.MonitorRows.Count == 0 && !result.Success;
			if (flag2)
			{
				this.ShowMonitorError(request.StartAddress, request.DataType, result.Message, actionName + " failed");
				int errorCount = connection.ErrorCount;
				connection.ErrorCount = errorCount + 1;
			}
			else
			{
				bool flag3 = this.MonitorRows.Count == 0;
				if (flag3)
				{
					this.ShowMonitorStatus(request.StartAddress, request.DataType, "Read completed but no row was returned.", actionName);
				}
			}
			connection.LastUpdate = DateTime.Now.ToString("HH:mm:ss");
			connection.AddTraffic(result.SentBytes, result.ReceivedBytes);
		}

		// Token: 0x06001ADC RID: 6876 RVA: 0x00091FA0 File Offset: 0x000901A0
		private void PullMonitorSelectorValues()
		{
			TextEdit monitorStartAddressTabEdit = this.MonitorStartAddressTabEdit;
			string startAddress = Convert.ToString((monitorStartAddressTabEdit != null) ? monitorStartAddressTabEdit.EditValue : null);
			bool flag = !string.IsNullOrWhiteSpace(startAddress);
			if (flag)
			{
				this.MonitorStartAddress = startAddress.Trim();
			}
			TextEdit monitorEndAddressTabEdit = this.MonitorEndAddressTabEdit;
			string endAddress = Convert.ToString((monitorEndAddressTabEdit != null) ? monitorEndAddressTabEdit.EditValue : null);
			bool flag2 = !string.IsNullOrWhiteSpace(endAddress);
			if (flag2)
			{
				this.MonitorEndAddress = endAddress.Trim();
			}
			ComboBoxEdit monitorDataTypeTabCombo = this.MonitorDataTypeTabCombo;
			string dataType = Convert.ToString((monitorDataTypeTabCombo != null) ? monitorDataTypeTabCombo.EditValue : null);
			bool flag3 = !string.IsNullOrWhiteSpace(dataType);
			if (flag3)
			{
				this.MonitorDataType = dataType;
			}
			ComboBoxEdit monitorFunctionCodeTabCombo = this.MonitorFunctionCodeTabCombo;
			string functionCode = Convert.ToString((monitorFunctionCodeTabCombo != null) ? monitorFunctionCodeTabCombo.EditValue : null);
			bool flag4 = !string.IsNullOrWhiteSpace(functionCode);
			if (flag4)
			{
				this.MonitorFunctionCode = functionCode;
			}
		}

		// Token: 0x06001ADD RID: 6877 RVA: 0x00092074 File Offset: 0x00090274
		private void LoadSampleMonitorRows()
		{
			this.MonitorRows.Clear();
			string timestamp = DateTime.Now.ToString("HH:mm:ss.fff");
			this.MonitorRows.Add(new CommunicationMonitorRow("40001", "INT16", "1234", "Good", timestamp, "Status Code"));
			this.MonitorRows.Add(new CommunicationMonitorRow("40002", "UINT16", "5678", "Good", timestamp, "Product Count"));
			this.MonitorRows.Add(new CommunicationMonitorRow("40010", "BOOL", "ON", "Good", timestamp, "Start Signal"));
			this.MonitorRows.Add(new CommunicationMonitorRow("40011", "BOOL", "OFF", "Good", timestamp, "Stop Signal"));
			this.MonitorRows.Add(new CommunicationMonitorRow("40020", "REAL", "25.67", "Good", timestamp, "Temperature"));
			this.MonitorRows.Add(new CommunicationMonitorRow("40030", "DINT", "123456789", "Good", timestamp, "Total Count"));
		}

		// Token: 0x06001ADE RID: 6878 RVA: 0x000921A4 File Offset: 0x000903A4
		private void CopySelectedLogMessage()
		{
			CommunicationLogRow row = this.GetSelectedLogRow();
			bool flag = row == null || string.IsNullOrEmpty(row.Message);
			if (!flag)
			{
				Clipboard.SetText(row.Message);
			}
		}

		// Token: 0x06001ADF RID: 6879 RVA: 0x000921DC File Offset: 0x000903DC
		private CommunicationLogRow GetSelectedLogRow()
		{
			ListBox logList = this.LogList;
			return ((logList != null) ? logList.SelectedItem : null) as CommunicationLogRow;
		}

		// Token: 0x06001AE0 RID: 6880 RVA: 0x00092208 File Offset: 0x00090408
		private CommunicationMonitorRow GetSelectedMonitorRow()
		{
			GridControl monitorGrid = this.MonitorGrid;
			CommunicationMonitorRow result;
			if ((result = (((monitorGrid != null) ? monitorGrid.CurrentItem : null) as CommunicationMonitorRow)) == null)
			{
				GridControl monitorGrid2 = this.MonitorGrid;
				result = (((monitorGrid2 != null) ? monitorGrid2.SelectedItem : null) as CommunicationMonitorRow);
			}
			return result;
		}

		// Token: 0x06001AE1 RID: 6881 RVA: 0x0009224C File Offset: 0x0009044C
		private void SetSelectedConnection(CommunicationConnection connection, bool forceRefresh)
		{
			bool flag = !forceRefresh && this._selectedConnection == connection;
			if (!flag)
			{
				bool flag2 = this._selectedConnection != connection;
				if (flag2)
				{
					this.SaveCurrentTagsForSelectedConnection();
					this.SaveCurrentInitialValuesForSelectedConnection();
					this._lastBrowsedOpcTags.Clear();
				}
				this._selectedConnection = connection;
				this.OnPropertyChanged("SelectedConnection");
				this.LoadTagsForConnection(connection);
				this.LoadInitialValuesForConnection(connection);
				this.LoadSelectedConnectionToEditor();
				this.UpdateSelectedConnectionState();
				this.UpdateProtocolUi();
				this.RefreshProtocolInformation();
				this.SyncMonitorAutoReadState();
			}
		}

		// Token: 0x06001AE2 RID: 6882 RVA: 0x000922E4 File Offset: 0x000904E4
		private void SaveCurrentTagsForSelectedConnection()
		{
			bool flag = this._isSwitchingConnectionTags || this._selectedConnection == null;
			if (!flag)
			{
				try
				{
					GridControl tagGrid = this.TagGrid;
					if (tagGrid != null)
					{
						DataViewBase view = tagGrid.View;
						if (view != null)
						{
							view.CommitEditing();
						}
					}
				}
				catch
				{
				}
				this._tagsByConnection[Form_communication.GetConnectionTagKey(this._selectedConnection)] = Form_communication.CloneTagRows(this.TagRows);
			}
		}

		// Token: 0x06001AE3 RID: 6883 RVA: 0x00092368 File Offset: 0x00090568
		private void LoadTagsForConnection(CommunicationConnection connection)
		{
			this._isSwitchingConnectionTags = true;
			try
			{
				this.TagRows.Clear();
				bool flag = connection == null;
				if (flag)
				{
					this.OpcTagAddressOptions.Clear();
				}
				else
				{
					string key = Form_communication.GetConnectionTagKey(connection);
					List<CommunicationTagRow> tags;
					bool flag2 = !this._tagsByConnection.TryGetValue(key, out tags);
					if (flag2)
					{
						tags = new List<CommunicationTagRow>();
						this._tagsByConnection[key] = tags;
					}
					foreach (CommunicationTagRow tag in Form_communication.CloneTagRows(tags))
					{
						this.TagRows.Add(tag);
					}
					this.EnsureDefaultTagsForSelectedConnection();
					this._tagsByConnection[key] = Form_communication.CloneTagRows(this.TagRows);
					GridControl tagGrid = this.TagGrid;
					this.UpdateOpcAddressOptionsForTag(((tagGrid != null) ? tagGrid.CurrentItem : null) as CommunicationTagRow);
				}
			}
			finally
			{
				this._isSwitchingConnectionTags = false;
			}
		}

		// Token: 0x06001AE4 RID: 6884 RVA: 0x00092480 File Offset: 0x00090680
		private Dictionary<string, List<CommunicationTagRow>> BuildSerializableConnectionTags()
		{
			this.SaveCurrentTagsForSelectedConnection();
			Dictionary<string, List<CommunicationTagRow>> result = new Dictionary<string, List<CommunicationTagRow>>(StringComparer.OrdinalIgnoreCase);
			foreach (CommunicationConnection connection in this.Connections)
			{
				bool flag = connection == null || string.IsNullOrWhiteSpace(connection.Name);
				if (!flag)
				{
					string key = Form_communication.GetConnectionTagKey(connection);
					List<CommunicationTagRow> tags;
					bool flag2 = this._tagsByConnection.TryGetValue(key, out tags);
					if (flag2)
					{
						result[key] = Form_communication.NormalizeTagsForConnection(connection, Form_communication.CloneTagRows(tags));
					}
					else
					{
						result[key] = new List<CommunicationTagRow>();
					}
				}
			}
			return result;
		}

		// Token: 0x06001AE5 RID: 6885 RVA: 0x0009253C File Offset: 0x0009073C
		private static List<CommunicationTagRow> BuildFlattenedConnectionTags(IDictionary<string, List<CommunicationTagRow>> connectionTags)
		{
			return (from x in connectionTags ?? new Dictionary<string, List<CommunicationTagRow>>()
			where x.Value != null
			select x).SelectMany((KeyValuePair<string, List<CommunicationTagRow>> x) => x.Value).Select(new Func<CommunicationTagRow, CommunicationTagRow>(Form_communication.CloneTagRow)).ToList<CommunicationTagRow>();
		}

		// Token: 0x06001AE6 RID: 6886 RVA: 0x000925B8 File Offset: 0x000907B8
		private static string GetConnectionTagKey(CommunicationConnection connection)
		{
			string name = (connection != null) ? connection.Name : null;
			return string.IsNullOrWhiteSpace(name) ? "Default" : name.Trim();
		}

		// Token: 0x06001AE7 RID: 6887 RVA: 0x000925EC File Offset: 0x000907EC
		private static List<CommunicationTagRow> CloneTagRows(IEnumerable<CommunicationTagRow> tags)
		{
			return (from x in tags ?? Enumerable.Empty<CommunicationTagRow>()
			where x != null
			select x).Select(new Func<CommunicationTagRow, CommunicationTagRow>(Form_communication.CloneTagRow)).ToList<CommunicationTagRow>();
		}

		// Token: 0x06001AE8 RID: 6888 RVA: 0x00092644 File Offset: 0x00090844
		private static CommunicationTagRow CloneTagRow(CommunicationTagRow source)
		{
			bool flag = source == null;
			CommunicationTagRow result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = new CommunicationTagRow
				{
					Group = source.Group,
					Name = source.Name,
					Address = source.Address,
					DataType = source.DataType,
					ReadWrite = source.ReadWrite,
					LinkedToolName = source.LinkedToolName,
					ResultField = source.ResultField,
					MaxResultCount = source.MaxResultCount,
					Description = source.Description
				};
			}
			return result;
		}

		// Token: 0x06001AE9 RID: 6889 RVA: 0x000926DC File Offset: 0x000908DC
		private static List<CommunicationTagRow> NormalizeTagsForConnection(CommunicationConnection connection, List<CommunicationTagRow> tags)
		{
			bool flag = tags == null;
			List<CommunicationTagRow> result;
			if (flag)
			{
				result = new List<CommunicationTagRow>();
			}
			else
			{
				bool isOpcConnection = Form_communication.IsOpcUaConnection(connection);
				bool hasTagDrivenHeartbeat = isOpcConnection || Form_communication.IsMitsubishiConnection(connection);
				foreach (CommunicationTagRow tag in from x in tags
				where x != null
				select x)
				{
					bool flag2 = Form_communication.IsHeartbeatTagName(tag.Name);
					if (flag2)
					{
						tag.DataType = "BOOL";
						tag.ReadWrite = "Read";
						bool flag3 = !hasTagDrivenHeartbeat;
						if (flag3)
						{
							tag.Address = string.Empty;
						}
					}
					bool flag4 = isOpcConnection && !string.IsNullOrWhiteSpace(tag.Address) && !Form_communication.LooksLikeOpcNodeId(tag.Address);
					if (flag4)
					{
						tag.Address = string.Empty;
					}
				}
				result = tags;
			}
			return result;
		}

		// Token: 0x06001AEA RID: 6890 RVA: 0x000927FC File Offset: 0x000909FC
		private void EnsureInitialSelectionLoaded()
		{
			ListBox connectionList = this.ConnectionList;
			CommunicationConnection connection = ((connectionList != null) ? connectionList.SelectedItem : null) as CommunicationConnection;
			bool flag = connection == null;
			if (flag)
			{
				connection = this.SelectedConnection;
			}
			bool flag2 = connection == null;
			if (flag2)
			{
				connection = (this.FilteredConnections.FirstOrDefault<CommunicationConnection>() ?? this.Connections.FirstOrDefault<CommunicationConnection>());
			}
			bool flag3 = connection == null;
			if (!flag3)
			{
				bool flag4 = this.ConnectionList != null;
				if (flag4)
				{
					this.ConnectionList.SelectedItem = connection;
				}
				this.SetSelectedConnection(connection, true);
				this.PushEditingConnectionToEditors();
			}
		}

		// Token: 0x06001AEB RID: 6891 RVA: 0x0009288C File Offset: 0x00090A8C
		private void ScheduleInitialSelectionRefresh()
		{
			base.Dispatcher.BeginInvoke(new Action(this.EnsureInitialSelectionLoaded), DispatcherPriority.Loaded, Array.Empty<object>());
			base.Dispatcher.BeginInvoke(new Action(this.EnsureInitialSelectionLoaded), DispatcherPriority.ContextIdle, Array.Empty<object>());
			base.Dispatcher.BeginInvoke(new Action(this.EnsureInitialSelectionLoaded), DispatcherPriority.ApplicationIdle, Array.Empty<object>());
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				this._ignoreNullSelectionWhileLoading = false;
			}), DispatcherPriority.ApplicationIdle, Array.Empty<object>());
		}

		// Token: 0x06001AEC RID: 6892 RVA: 0x00092914 File Offset: 0x00090B14
		private void LoadSelectedConnectionToEditor()
		{
			bool flag = this.SelectedConnection == null;
			if (flag)
			{
				this.EditingConnection = Form_communication.CreateDefaultEditingConnection();
				this.EditingConnection.Protocol = this.GetActiveProtocol();
				this.EditingConnection.ApplyDefaultPort();
			}
			else
			{
				this.EditingConnection = Form_communication.CloneConnection(this.SelectedConnection);
				this.LoadMonitorSettingsFromConnection(this.EditingConnection);
				this.PushEditingConnectionToEditors();
			}
		}

		// Token: 0x06001AED RID: 6893 RVA: 0x00092984 File Offset: 0x00090B84
		private void LoadMonitorSettingsFromConnection(CommunicationConnection connection)
		{
			bool flag = connection == null;
			if (!flag)
			{
				this.MonitorStartAddress = (string.IsNullOrWhiteSpace(connection.MonitorStartAddress) ? "40001" : connection.MonitorStartAddress);
				this.MonitorEndAddress = (string.IsNullOrWhiteSpace(connection.MonitorEndAddress) ? "40010" : connection.MonitorEndAddress);
				this.MonitorDataType = (string.IsNullOrWhiteSpace(connection.MonitorDataType) ? "UINT16" : connection.MonitorDataType);
				this.MonitorFunctionCode = (string.IsNullOrWhiteSpace(connection.MonitorFunctionCode) ? "03 Read Holding Registers" : connection.MonitorFunctionCode);
				this.ReadCycleMs = Form_communication.ExtractFirstInteger(connection.ExchangeInterval, 10);
				this.PushMonitorSettingsToEditors();
			}
		}

		// Token: 0x06001AEE RID: 6894 RVA: 0x00092A40 File Offset: 0x00090C40
		private void ApplySelectedProtocolToConnection()
		{
			bool flag = this.SelectedConnection != null;
			if (!flag)
			{
				bool flag2 = this.EditingConnection == null;
				if (flag2)
				{
					this.EditingConnection = Form_communication.CreateDefaultEditingConnection();
				}
				string previousProtocol = this.EditingConnection.Protocol;
				string protocol = this.GetActiveProtocol();
				this.EditingConnection.Protocol = protocol;
				Form_communication.ResetProtocolSpecificSettings(this.EditingConnection, previousProtocol);
				bool flag3 = this.EditingConnection.Protocol == "Modbus Server TCP/IP";
				if (flag3)
				{
					this.EditingConnection.IpAddress = "0.0.0.0";
				}
				this.PushEditingConnectionToEditors();
				this.UpdateProtocolUi();
				this.RefreshProtocolInformation();
			}
		}

		// Token: 0x06001AEF RID: 6895 RVA: 0x00092AE8 File Offset: 0x00090CE8
		private void ReaddressTagsForSelectedProtocol()
		{
			CommunicationAddressStyle style = CommunicationAddressStyles.FromProtocol(this.GetEditorProtocol());
			bool changed = false;
			foreach (CommunicationTagRow tag in this.TagRows)
			{
				bool flag = tag == null || CommunicationAddressStyles.Matches(tag.Address, style);
				if (!flag)
				{
					tag.Address = CommunicationAddressStyles.Format(tag.Address, style);
					changed = true;
				}
			}
			bool flag2 = !changed;
			if (!flag2)
			{
				this.UpdateDuplicateTagWarnings();
				GridControl tagGrid = this.TagGrid;
				if (tagGrid != null)
				{
					tagGrid.RefreshData();
				}
			}
		}

		// Token: 0x06001AF0 RID: 6896 RVA: 0x00092B98 File Offset: 0x00090D98
		private string GetEditorProtocol()
		{
			CommunicationConnection selectedConnection = this.SelectedConnection;
			string protocol = (selectedConnection != null) ? selectedConnection.Protocol : null;
			return Form_communication.IsSupportedProtocol(protocol) ? protocol : this.GetActiveProtocol();
		}

		// Token: 0x06001AF1 RID: 6897 RVA: 0x00092BD0 File Offset: 0x00090DD0
		private string GetActiveProtocol()
		{
			return Form_communication.IsSupportedProtocol(this.SelectedProtocol) ? this.SelectedProtocol : "Modbus Client TCP/IP";
		}

		// Token: 0x06001AF2 RID: 6898 RVA: 0x00092BFC File Offset: 0x00090DFC
		private static CommunicationConnection CreateDefaultEditingConnection()
		{
			return new CommunicationConnection
			{
				Name = "PLC_New",
				Protocol = "Modbus Client TCP/IP",
				Status = "Disconnected",
				Description = "New PLC connection",
				IpAddress = "192.168.1.100",
				Port = 502,
				TimeoutMs = 2000,
				ExchangeInterval = "10 ms",
				ByteOrder = "Big Endian (AB CD)",
				WordOrder = "Big Endian (AB CD)",
				FloatFormat = "IEEE 754",
				KeepAlive = true,
				AutoReconnect = true,
				MonitorStartAddress = "40001",
				MonitorEndAddress = "40010",
				MonitorDataType = "UINT16",
				MonitorFunctionCode = "03 Read Holding Registers"
			};
		}

		// Token: 0x06001AF3 RID: 6899 RVA: 0x00092CD8 File Offset: 0x00090ED8
		private static CommunicationConnection CloneConnection(CommunicationConnection source)
		{
			source = (source ?? Form_communication.CreateDefaultEditingConnection());
			return new CommunicationConnection
			{
				Name = source.Name,
				Protocol = source.Protocol,
				Status = source.Status,
				Description = source.Description,
				IpAddress = source.IpAddress,
				Port = source.Port,
				TimeoutMs = source.TimeoutMs,
				LogicalStationNumber = source.LogicalStationNumber,
				ExchangeInterval = source.ExchangeInterval,
				ByteOrder = source.ByteOrder,
				WordOrder = source.WordOrder,
				FloatFormat = source.FloatFormat,
				KeepAlive = source.KeepAlive,
				AutoReconnect = source.AutoReconnect,
				MonitorStartAddress = source.MonitorStartAddress,
				MonitorEndAddress = source.MonitorEndAddress,
				MonitorDataType = source.MonitorDataType,
				MonitorFunctionCode = source.MonitorFunctionCode,
				ConnectedTime = source.ConnectedTime,
				LastUpdate = source.LastUpdate,
				SendBytes = source.SendBytes,
				ReceiveBytes = source.ReceiveBytes,
				ErrorCount = source.ErrorCount
			};
		}

		// Token: 0x06001AF4 RID: 6900 RVA: 0x00092E28 File Offset: 0x00091028
		private void ApplyEditorToConnection(CommunicationConnection target)
		{
			bool flag = target == null || this.EditingConnection == null;
			if (!flag)
			{
				target.Name = this.GetUniqueConnectionNameForTarget(string.IsNullOrWhiteSpace(this.EditingConnection.Name) ? target.Name : this.EditingConnection.Name.Trim(), target);
				target.Description = this.EditingConnection.Description;
				target.IpAddress = ((target.Protocol == "Modbus Server TCP/IP") ? "0.0.0.0" : this.EditingConnection.IpAddress);
				target.Port = this.EditingConnection.Port;
				target.TimeoutMs = this.EditingConnection.TimeoutMs;
				target.LogicalStationNumber = this.EditingConnection.LogicalStationNumber;
				target.ExchangeInterval = this.EditingConnection.ExchangeInterval;
				target.ByteOrder = this.EditingConnection.ByteOrder;
				target.WordOrder = this.EditingConnection.WordOrder;
				target.FloatFormat = this.EditingConnection.FloatFormat;
				target.KeepAlive = this.EditingConnection.KeepAlive;
				target.AutoReconnect = this.EditingConnection.AutoReconnect;
				target.MonitorStartAddress = this.MonitorStartAddress;
				target.MonitorEndAddress = this.MonitorEndAddress;
				target.MonitorDataType = this.MonitorDataType;
				target.MonitorFunctionCode = this.MonitorFunctionCode;
			}
		}

		// Token: 0x06001AF5 RID: 6901 RVA: 0x00092F9C File Offset: 0x0009119C
		private static bool IsSupportedProtocol(string protocol)
		{
			return protocol == "Modbus Client TCP/IP" || protocol == "Modbus Server TCP/IP" || protocol == "OPC UA" || protocol == "MX Component" || protocol == "MC Protocol";
		}

		// Token: 0x06001AF6 RID: 6902 RVA: 0x00092FF0 File Offset: 0x000911F0
		private bool SaveConnections()
		{
			bool result;
			try
			{
				try
				{
					GridControl tagGrid = this.TagGrid;
					if (tagGrid != null)
					{
						DataViewBase view = tagGrid.View;
						if (view != null)
						{
							view.CommitEditing();
						}
					}
				}
				catch
				{
				}
				this.PullCameraTriggerConnectionValue();
				this.SaveCurrentInitialValuesForSelectedConnection();
				this.NormalizeTagOptions();
				this.NormalizeResultTagLinks();
				this.SaveCurrentTagsForSelectedConnection();
				bool flag = this.UpdateDuplicateTagWarnings();
				if (flag)
				{
					GridControl tagGrid2 = this.TagGrid;
					if (tagGrid2 != null)
					{
						tagGrid2.RefreshData();
					}
					this.AddLog("Warning", "Communication config was not saved because Tag Management has duplicate or overlapping values.");
					foreach (CommunicationTagRow bad in from x in this.TagRows
					where x != null && x.HasDuplicateValue
					select x)
					{
						this.AddLog("Warning", string.Concat(new string[]
						{
							"  - Tag '",
							bad.Name,
							"' @",
							bad.Address,
							" (",
							bad.DataType,
							", MaxCount=",
							Math.Max(1, bad.MaxResultCount).ToString(),
							"): ",
							(bad.ValidationMessage ?? "conflict").Replace(Environment.NewLine, " | ")
						}));
					}
					result = false;
				}
				else
				{
					string savePath = CommunicationConfigStorageService.GetConfigPath();
					CommunicationRuntimeSettings runtimeSettings = new CommunicationRuntimeSettings
					{
						CameraTriggerConnectionName = this.CameraTriggerConnectionName
					};
					CommunicationConfigStorageService.Save(this.Connections, this.BuildSerializableConnectionTags(), this.BuildSerializableInitialValues(), runtimeSettings, savePath);
					this._activeConfigPath = CommunicationConfigStorageService.LastSavePath;
					this._loadedConfigPath = this._activeConfigPath;
					string restartPath = this._activeConfigPath;
					CommunicationStartupService.AutoConnectCurrentModelAsync(true, restartPath, false);
					Task.Run(delegate()
					{
						CameraTriggerCommunicationService.StartCurrentModel(restartPath, true);
					});
					this.AddLog("Info", "Communication config saved. Camera trigger connection=" + this.CameraTriggerConnectionName + ". Path=" + this._activeConfigPath);
					result = true;
				}
			}
			catch (Exception ex)
			{
				this.AddLog("Error", "Save communication config failed: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06001AF7 RID: 6903 RVA: 0x00093294 File Offset: 0x00091494
		private void UpdateEditorBindings()
		{
			Form_communication.UpdateEditValueSource(this.ConnectionNameEdit);
			Form_communication.UpdateEditValueSource(this.ProtocolComboEdit);
			Form_communication.UpdateEditValueSource(this.DescriptionEdit);
			Form_communication.UpdateEditValueSource(this.IpAddressEdit);
			Form_communication.UpdateEditValueSource(this.PortSpinEdit);
			Form_communication.UpdateEditValueSource(this.TimeoutSpinEdit);
			Form_communication.UpdateEditValueSource(this.CameraTriggerConnectionComboEdit);
			Form_communication.UpdateEditValueSource(this.ReadCycleEdit);
			Form_communication.UpdateEditValueSource(this.OpcReadCycleEdit);
			Form_communication.UpdateEditValueSource(this.MonitorStartAddressTabEdit);
			Form_communication.UpdateEditValueSource(this.MonitorEndAddressTabEdit);
			Form_communication.UpdateEditValueSource(this.MonitorDataTypeTabCombo);
			Form_communication.UpdateEditValueSource(this.MonitorFunctionCodeTabCombo);
		}

		// Token: 0x06001AF8 RID: 6904 RVA: 0x00093340 File Offset: 0x00091540
		private void PullCameraTriggerConnectionValue()
		{
			ComboBoxEdit cameraTriggerConnectionComboEdit = this.CameraTriggerConnectionComboEdit;
			string selectedName = Convert.ToString((cameraTriggerConnectionComboEdit != null) ? cameraTriggerConnectionComboEdit.SelectedItem : null);
			bool flag = string.IsNullOrWhiteSpace(selectedName);
			if (flag)
			{
				ComboBoxEdit cameraTriggerConnectionComboEdit2 = this.CameraTriggerConnectionComboEdit;
				selectedName = Convert.ToString((cameraTriggerConnectionComboEdit2 != null) ? cameraTriggerConnectionComboEdit2.EditValue : null);
			}
			bool flag2 = string.IsNullOrWhiteSpace(selectedName);
			if (flag2)
			{
				selectedName = this.CameraTriggerConnectionName;
			}
			bool flag3 = string.IsNullOrWhiteSpace(selectedName);
			if (flag3)
			{
				selectedName = "None";
			}
			bool flag4 = !this.CameraTriggerConnectionOptions.Contains(selectedName);
			if (flag4)
			{
				this.RefreshCameraTriggerConnectionOptions();
			}
			this.CameraTriggerConnectionName = this.ResolveCameraTriggerConnectionName(selectedName);
			bool flag5 = this.CameraTriggerConnectionComboEdit != null;
			if (flag5)
			{
				this.CameraTriggerConnectionComboEdit.SelectedItem = this.CameraTriggerConnectionName;
				this.CameraTriggerConnectionComboEdit.EditValue = this.CameraTriggerConnectionName;
			}
		}

		// Token: 0x06001AF9 RID: 6905 RVA: 0x00093408 File Offset: 0x00091608
		private void PushEditingConnectionToEditors()
		{
			bool flag = this._isPushingEditorValues || this.EditingConnection == null || this.ConnectionNameEdit == null;
			if (!flag)
			{
				this._isPushingEditorValues = true;
				try
				{
					this.ConnectionNameEdit.EditValue = this.EditingConnection.Name;
					this.DescriptionEdit.EditValue = this.EditingConnection.Description;
					this.IpAddressEdit.EditValue = this.EditingConnection.IpAddress;
					this.PortSpinEdit.EditValue = this.EditingConnection.Port;
					this.TimeoutSpinEdit.EditValue = this.EditingConnection.TimeoutMs;
					this.WorkStationSpinEdit.EditValue = this.EditingConnection.LogicalStationNumber;
					this.ReadCycleMs = Form_communication.ExtractFirstInteger(this.EditingConnection.ExchangeInterval, 10);
					this.SetReadCycleText(this.ReadCycleMs);
					this.PushMonitorSettingsToEditors();
				}
				finally
				{
					this._isPushingEditorValues = false;
				}
			}
		}

		// Token: 0x06001AFA RID: 6906 RVA: 0x00093528 File Offset: 0x00091728
		private void PushMonitorSettingsToEditors()
		{
			bool flag = this.MonitorStartAddressTabEdit != null;
			if (flag)
			{
				this.MonitorStartAddressTabEdit.EditValue = this.MonitorStartAddress;
			}
			bool flag2 = this.MonitorEndAddressTabEdit != null;
			if (flag2)
			{
				this.MonitorEndAddressTabEdit.EditValue = this.MonitorEndAddress;
			}
			bool flag3 = this.MonitorDataTypeTabCombo != null;
			if (flag3)
			{
				this.MonitorDataTypeTabCombo.EditValue = this.MonitorDataType;
			}
			bool flag4 = this.MonitorFunctionCodeTabCombo != null;
			if (flag4)
			{
				this.MonitorFunctionCodeTabCombo.EditValue = this.MonitorFunctionCode;
			}
		}

		// Token: 0x06001AFB RID: 6907 RVA: 0x000935B4 File Offset: 0x000917B4
		private void PullEditorValuesToEditingConnection()
		{
			bool flag = this.EditingConnection == null;
			if (flag)
			{
				this.EditingConnection = Form_communication.CreateDefaultEditingConnection();
			}
			TextEdit connectionNameEdit = this.ConnectionNameEdit;
			string name = Convert.ToString((connectionNameEdit != null) ? connectionNameEdit.EditValue : null);
			bool flag2 = !string.IsNullOrWhiteSpace(name);
			if (flag2)
			{
				this.EditingConnection.Name = name.Trim();
			}
			ComboBoxEdit protocolComboEdit = this.ProtocolComboEdit;
			string protocol = Convert.ToString((protocolComboEdit != null) ? protocolComboEdit.EditValue : null);
			bool flag3 = Form_communication.IsSupportedProtocol(protocol);
			if (flag3)
			{
				this.SelectedProtocol = protocol;
				this.EditingConnection.Protocol = protocol;
			}
			CommunicationConnection editingConnection = this.EditingConnection;
			TextEdit descriptionEdit = this.DescriptionEdit;
			editingConnection.Description = Convert.ToString((descriptionEdit != null) ? descriptionEdit.EditValue : null);
			int readCycleMs;
			bool flag4 = Form_communication.TryGetEditorInt32(this.ReadCycleText, out readCycleMs);
			if (flag4)
			{
				this.ReadCycleMs = readCycleMs;
				this.EditingConnection.ExchangeInterval = Form_communication.FormatReadCycle(this.ReadCycleMs);
			}
			else
			{
				this.ReadCycleMs = Form_communication.ExtractFirstInteger(this.EditingConnection.ExchangeInterval, 10);
			}
			TextEdit ipAddressEdit = this.IpAddressEdit;
			string ipAddress = Convert.ToString((ipAddressEdit != null) ? ipAddressEdit.EditValue : null);
			bool flag5 = !string.IsNullOrWhiteSpace(ipAddress);
			if (flag5)
			{
				this.EditingConnection.IpAddress = ipAddress.Trim();
			}
			SpinEdit portSpinEdit = this.PortSpinEdit;
			int port;
			bool flag6 = Form_communication.TryGetEditorInt32((portSpinEdit != null) ? portSpinEdit.EditValue : null, out port);
			if (flag6)
			{
				this.EditingConnection.Port = port;
			}
			SpinEdit timeoutSpinEdit = this.TimeoutSpinEdit;
			int timeoutMs;
			bool flag7 = Form_communication.TryGetEditorInt32((timeoutSpinEdit != null) ? timeoutSpinEdit.EditValue : null, out timeoutMs);
			if (flag7)
			{
				this.EditingConnection.TimeoutMs = timeoutMs;
			}
			SpinEdit workStationSpinEdit = this.WorkStationSpinEdit;
			int workStation;
			bool flag8 = Form_communication.TryGetEditorInt32((workStationSpinEdit != null) ? workStationSpinEdit.EditValue : null, out workStation);
			if (flag8)
			{
				this.EditingConnection.LogicalStationNumber = workStation;
			}
		}

		// Token: 0x06001AFC RID: 6908 RVA: 0x00093788 File Offset: 0x00091988
		private static bool TryGetEditorInt32(object value, out int result)
		{
			int intValue;
			bool flag;
			if (value is int)
			{
				intValue = (int)value;
				flag = true;
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			bool result2;
			if (flag2)
			{
				result = intValue;
				result2 = true;
			}
			else
			{
				decimal decimalValue;
				bool flag3;
				if (value is decimal)
				{
					decimalValue = (decimal)value;
					flag3 = true;
				}
				else
				{
					flag3 = false;
				}
				bool flag4 = flag3;
				if (flag4)
				{
					result = decimal.ToInt32(decimalValue);
					result2 = true;
				}
				else
				{
					double doubleValue;
					bool flag5;
					if (value is double)
					{
						doubleValue = (double)value;
						flag5 = true;
					}
					else
					{
						flag5 = false;
					}
					bool flag6 = flag5;
					if (flag6)
					{
						result = Convert.ToInt32(doubleValue);
						result2 = true;
					}
					else
					{
						result2 = int.TryParse(Convert.ToString(value), out result);
					}
				}
			}
			return result2;
		}

		// Token: 0x06001AFD RID: 6909 RVA: 0x00093818 File Offset: 0x00091A18
		private static void UpdateEditValueSource(DependencyObject editor)
		{
			BindingExpression expression = (editor == null) ? null : BindingOperations.GetBindingExpression(editor, BaseEdit.EditValueProperty);
			if (expression != null)
			{
				expression.UpdateSource();
			}
		}

		// Token: 0x06001AFE RID: 6910 RVA: 0x00093844 File Offset: 0x00091A44
		private static void NormalizeConnection(CommunicationConnection connection)
		{
			bool flag = connection == null;
			if (!flag)
			{
				bool flag2 = string.Equals(connection.Protocol, "Modbus TCP", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					connection.Protocol = "Modbus Client TCP/IP";
				}
				bool flag3 = !Form_communication.IsSupportedProtocol(connection.Protocol);
				if (flag3)
				{
					connection.Protocol = "Modbus Client TCP/IP";
				}
				bool flag4 = string.IsNullOrWhiteSpace(connection.Name);
				if (flag4)
				{
					connection.Name = "PLC_New";
				}
				bool flag5 = string.IsNullOrWhiteSpace(connection.ExchangeInterval);
				if (flag5)
				{
					connection.ExchangeInterval = "10 ms";
				}
				bool flag6 = connection.TimeoutMs <= 0;
				if (flag6)
				{
					connection.TimeoutMs = 2000;
				}
				bool flag7 = connection.Port <= 0;
				if (flag7)
				{
					connection.ApplyDefaultPort();
				}
				bool flag8 = string.IsNullOrWhiteSpace(connection.MonitorStartAddress);
				if (flag8)
				{
					connection.MonitorStartAddress = "40001";
				}
				bool flag9 = string.IsNullOrWhiteSpace(connection.MonitorEndAddress);
				if (flag9)
				{
					connection.MonitorEndAddress = "40010";
				}
				bool flag10 = string.IsNullOrWhiteSpace(connection.MonitorDataType);
				if (flag10)
				{
					connection.MonitorDataType = "UINT16";
				}
				bool flag11 = string.IsNullOrWhiteSpace(connection.MonitorFunctionCode);
				if (flag11)
				{
					connection.MonitorFunctionCode = "03 Read Holding Registers";
				}
				bool flag12 = connection.Protocol == "Modbus Server TCP/IP";
				if (flag12)
				{
					connection.IpAddress = "0.0.0.0";
				}
			}
		}

		// Token: 0x06001AFF RID: 6911 RVA: 0x000939A4 File Offset: 0x00091BA4
		private string GetUniqueConnectionName(string baseName)
		{
			bool flag = string.IsNullOrWhiteSpace(baseName);
			if (flag)
			{
				baseName = "PLC_New";
			}
			string safeBaseName = baseName.Trim();
			string name = safeBaseName;
			int index = 1;
			Func<CommunicationConnection, bool> <>9__0;
			for (;;)
			{
				IEnumerable<CommunicationConnection> connections = this.Connections;
				Func<CommunicationConnection, bool> predicate;
				if ((predicate = <>9__0) == null)
				{
					predicate = (<>9__0 = ((CommunicationConnection x) => string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase)));
				}
				if (!connections.Any(predicate))
				{
					break;
				}
				name = string.Format("{0}_{1}", safeBaseName, index++);
			}
			return name;
		}

		// Token: 0x06001B00 RID: 6912 RVA: 0x00093A34 File Offset: 0x00091C34
		private string GetUniqueConnectionNameForTarget(string baseName, CommunicationConnection target)
		{
			bool flag = string.IsNullOrWhiteSpace(baseName);
			if (flag)
			{
				baseName = "PLC_New";
			}
			string safeBaseName = baseName.Trim();
			string name = safeBaseName;
			int index = 1;
			Func<CommunicationConnection, bool> <>9__0;
			for (;;)
			{
				IEnumerable<CommunicationConnection> connections = this.Connections;
				Func<CommunicationConnection, bool> predicate;
				if ((predicate = <>9__0) == null)
				{
					predicate = (<>9__0 = ((CommunicationConnection x) => x != target && string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase)));
				}
				if (!connections.Any(predicate))
				{
					break;
				}
				name = string.Format("{0}_{1}", safeBaseName, index++);
			}
			return name;
		}

		// Token: 0x06001B01 RID: 6913 RVA: 0x00093AD0 File Offset: 0x00091CD0
		private void UpdateProtocolUi()
		{
			bool isServer = this.GetEditorProtocol() == "Modbus Server TCP/IP";
			bool isOpcUa = this.IsOpcUaSelected();
			bool isMxComponent = this.IsMxComponentSelected();
			bool isMcProtocol = this.IsMcProtocolSelected();
			bool isMitsubishi = isMxComponent || isMcProtocol;
			Visibility visibility = (isServer || isMxComponent) ? Visibility.Collapsed : Visibility.Visible;
			bool flag = this.IpAddressLabel != null;
			if (flag)
			{
				this.IpAddressLabel.Visibility = visibility;
			}
			bool flag2 = this.IpAddressEdit != null;
			if (flag2)
			{
				this.IpAddressEdit.Visibility = visibility;
			}
			Visibility mxVisibility = isMxComponent ? Visibility.Visible : Visibility.Collapsed;
			Visibility networkVisibility = isMxComponent ? Visibility.Collapsed : Visibility.Visible;
			bool flag3 = this.PortLabel != null;
			if (flag3)
			{
				this.PortLabel.Visibility = networkVisibility;
			}
			bool flag4 = this.PortSpinEdit != null;
			if (flag4)
			{
				this.PortSpinEdit.Visibility = networkVisibility;
			}
			bool flag5 = this.WorkStationLabel != null;
			if (flag5)
			{
				this.WorkStationLabel.Visibility = mxVisibility;
			}
			bool flag6 = this.WorkStationSpinEdit != null;
			if (flag6)
			{
				this.WorkStationSpinEdit.Visibility = mxVisibility;
			}
			bool flag7 = this.MxComponentStatusText != null;
			if (flag7)
			{
				this.MxComponentStatusText.Visibility = mxVisibility;
				this.MxComponentStatusText.Text = (MxComponentRuntime.IsInstalled ? "MX Component runtime detected." : MxComponentRuntime.DescribeInstallation());
				this.MxComponentStatusText.Foreground = (MxComponentRuntime.IsInstalled ? new SolidColorBrush(Color.FromRgb(74, 222, 128)) : new SolidColorBrush(Color.FromRgb(248, 113, 113)));
			}
			bool tagDrivenMonitor = isOpcUa || isMitsubishi;
			bool flag8 = this.ModbusMonitorPanel != null;
			if (flag8)
			{
				this.ModbusMonitorPanel.Visibility = (tagDrivenMonitor ? Visibility.Collapsed : Visibility.Visible);
			}
			bool flag9 = this.OpcMonitorPanel != null;
			if (flag9)
			{
				this.OpcMonitorPanel.Visibility = (tagDrivenMonitor ? Visibility.Visible : Visibility.Collapsed);
			}
			bool flag10 = this.TagMonitorTitleText != null;
			if (flag10)
			{
				this.TagMonitorTitleText.Text = (isMcProtocol ? "MC Protocol Tag Monitor" : (isMxComponent ? "MX Component Tag Monitor" : "OPC Tag Monitor"));
			}
			bool flag11 = this.TagMonitorHintText != null;
			if (flag11)
			{
				this.TagMonitorHintText.Text = (isMitsubishi ? "Reads every tag marked as Read in Tag Management. Address is a Mitsubishi device such as D100, M0, X1A or Y20. A 32-bit value uses that device and the next one." : "Reads all OPC UA tags marked as Read in Tag Management. Address must be a NodeId such as ns=2;s=TagName or ns=2;i=1001.");
			}
			bool flag12 = this.BrowseOpcTagsButton != null;
			if (flag12)
			{
				this.BrowseOpcTagsButton.Visibility = (isMitsubishi ? Visibility.Collapsed : Visibility.Visible);
			}
			Visibility opcHeartbeatVisibility = (isOpcUa || isMitsubishi) ? Visibility.Visible : Visibility.Collapsed;
			bool flag13 = this.OpcHeartbeatLabel != null;
			if (flag13)
			{
				this.OpcHeartbeatLabel.Text = (isMcProtocol ? "MC Protocol Heartbeat" : (isMxComponent ? "MX Component Heartbeat" : "OPC Heartbeat"));
			}
			bool flag14 = this.OpcHeartbeatLabel != null;
			if (flag14)
			{
				this.OpcHeartbeatLabel.Visibility = opcHeartbeatVisibility;
			}
			bool flag15 = this.OpcHeartbeatStatusEdit != null;
			if (flag15)
			{
				this.OpcHeartbeatStatusEdit.Visibility = opcHeartbeatVisibility;
			}
			GridControl tagGrid = this.TagGrid;
			this.UpdateOpcAddressOptionsForTag(((tagGrid != null) ? tagGrid.CurrentItem : null) as CommunicationTagRow);
		}

		// Token: 0x06001B02 RID: 6914 RVA: 0x00093DC0 File Offset: 0x00091FC0
		private bool IsMxComponentSelected()
		{
			return string.Equals(this.GetEditorProtocol(), "MX Component", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001B03 RID: 6915 RVA: 0x00093DE4 File Offset: 0x00091FE4
		private static bool IsMxComponentConnection(CommunicationConnection connection)
		{
			return string.Equals((connection != null) ? connection.Protocol : null, "MX Component", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001B04 RID: 6916 RVA: 0x00093E10 File Offset: 0x00092010
		private bool IsMcProtocolSelected()
		{
			return string.Equals(this.GetEditorProtocol(), "MC Protocol", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001B05 RID: 6917 RVA: 0x00093E34 File Offset: 0x00092034
		private static bool IsMcProtocolConnection(CommunicationConnection connection)
		{
			return string.Equals((connection != null) ? connection.Protocol : null, "MC Protocol", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001B06 RID: 6918 RVA: 0x00093E60 File Offset: 0x00092060
		private static bool IsMitsubishiConnection(CommunicationConnection connection)
		{
			return Form_communication.IsMxComponentConnection(connection) || Form_communication.IsMcProtocolConnection(connection);
		}

		// Token: 0x06001B07 RID: 6919 RVA: 0x00093E84 File Offset: 0x00092084
		private bool IsOpcUaSelected()
		{
			return string.Equals(this.GetEditorProtocol(), "OPC UA", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001B08 RID: 6920 RVA: 0x00093EA8 File Offset: 0x000920A8
		private static bool IsOpcUaConnection(CommunicationConnection connection)
		{
			return string.Equals((connection != null) ? connection.Protocol : null, "OPC UA", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001B09 RID: 6921 RVA: 0x00093ED4 File Offset: 0x000920D4
		private static bool LooksLikeOpcNodeId(string address)
		{
			return !string.IsNullOrWhiteSpace(address) && address.TrimStart(Array.Empty<char>()).StartsWith("ns=", StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001B0A RID: 6922 RVA: 0x00093F08 File Offset: 0x00092108
		private void LoadConnectionsFromModel()
		{
			this._isSwitchingConnectionTags = true;
			this._selectedConnection = null;
			this.OnPropertyChanged("SelectedConnection");
			this.Connections.Clear();
			this.TagRows.Clear();
			this.InitialValueRows.Clear();
			this._tagsByConnection.Clear();
			this._initialValuesByConnection.Clear();
			this._lastBrowsedOpcTags.Clear();
			string requestedPath = CommunicationConfigStorageService.GetConfigPath();
			this._loadedConfigPath = requestedPath;
			CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(requestedPath);
			foreach (CommunicationConnection connection in config.Connections)
			{
				Form_communication.NormalizeConnection(connection);
				connection.Status = (this.ResolveConnectionRuntimeConnected(connection, null, false) ? "Connected" : "Disconnected");
				this.Connections.Add(connection);
			}
			this.LoadConnectionTagCache(config);
			this.LoadInitialValueCache(config);
			CommunicationRuntimeSettings runtimeSettings = config.RuntimeSettings;
			this.CameraTriggerConnectionName = (string.IsNullOrWhiteSpace((runtimeSettings != null) ? runtimeSettings.CameraTriggerConnectionName : null) ? "None" : config.RuntimeSettings.CameraTriggerConnectionName);
			this.RefreshCameraTriggerConnectionOptions();
			this._activeConfigPath = requestedPath;
			this._loadedConfigPath = requestedPath;
			bool flag = this.Connections.Count > 0;
			if (flag)
			{
				this._isSwitchingConnectionTags = false;
				this.SetSelectedConnection(this.Connections[0], true);
			}
			else
			{
				this._isSwitchingConnectionTags = false;
			}
			this.AddLog((this.Connections.Count > 0) ? "Info" : "Error", "Communication config load: " + CommunicationConfigStorageService.LastLoadMessage + " Path=" + CommunicationConfigStorageService.LastLoadPath);
			this.AddLog("Info", "Loaded camera trigger connection: " + this.CameraTriggerConnectionName);
			string level = "Info";
			string[] array = new string[6];
			array[0] = "Loaded Initial Values for model '";
			int num = 1;
			ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
			array[num] = (((currentModel != null) ? currentModel.Model_name : null) ?? "None");
			array[2] = "'. Rows=";
			array[3] = this.InitialValueRows.Count.ToString();
			array[4] = ", Path=";
			array[5] = requestedPath;
			this.AddLog(level, string.Concat(array));
		}

		// Token: 0x06001B0B RID: 6923 RVA: 0x00094154 File Offset: 0x00092354
		private void LoadRuntimeSettingsFromModel()
		{
			try
			{
				CommunicationConfigData config = CommunicationConfigStorageService.LoadConfig(CommunicationConfigStorageService.GetConfigPath());
				CommunicationRuntimeSettings runtimeSettings = config.RuntimeSettings;
				this.CameraTriggerConnectionName = (string.IsNullOrWhiteSpace((runtimeSettings != null) ? runtimeSettings.CameraTriggerConnectionName : null) ? "None" : config.RuntimeSettings.CameraTriggerConnectionName);
			}
			catch
			{
				this.CameraTriggerConnectionName = "None";
			}
		}

		// Token: 0x06001B0C RID: 6924 RVA: 0x000941C4 File Offset: 0x000923C4
		private void ScheduleCommunicationAutoConnect()
		{
			bool flag = this.Connections.Count == 0;
			if (!flag)
			{
				string path = CommunicationConfigStorageService.GetConfigPath();
				this._activeConfigPath = path;
				bool flag2 = string.Equals(this._lastAutoConnectRefreshPath, path, StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					this.RefreshConnectionRuntimeState();
					this.StartOpcHeartbeatReadThread();
				}
				else
				{
					this._lastAutoConnectRefreshPath = path;
					foreach (CommunicationConnection connection in this.Connections)
					{
						bool flag3 = !this._communicationService.IsConnected(connection);
						if (flag3)
						{
							connection.Status = "Connecting...";
						}
					}
					this.ApplyCameraTriggerRuntimeState();
					this.RefreshConnectionListVisual();
					CommunicationStartupService.AutoConnectCurrentModelAsync(false, path, false).ContinueWith(delegate(Task _)
					{
						base.Dispatcher.BeginInvoke(new Action(delegate()
						{
							this.RefreshConnectionRuntimeState();
							this.StartOpcHeartbeatReadThread();
							this.AddLog("Info", "Communication auto-connect completed.");
						}), Array.Empty<object>());
					});
				}
			}
		}

		// Token: 0x06001B0D RID: 6925 RVA: 0x000942AC File Offset: 0x000924AC
		private void RefreshConnectionRuntimeState()
		{
			foreach (CommunicationConnection connection in this.Connections)
			{
				CommunicationHealthState healthState;
				bool hasHealthState = this._latestConnectionHealthStates.TryGetValue(connection.Name, out healthState) || CommunicationStartupService.TryGetConnectionHealth(connection.Name, out healthState);
				this.ApplyRuntimeConnectionState(connection, healthState, hasHealthState);
			}
			this.ApplyCameraTriggerRuntimeState();
			this.RefreshConnectionListVisual();
			this.UpdateSelectedConnectionState();
			this.SyncMonitorAutoReadState();
			bool flag = this.ConnectionTestText != null && this.SelectedConnection != null;
			if (flag)
			{
				CommunicationHealthState healthState2;
				bool hasHealthState2 = this._latestConnectionHealthStates.TryGetValue(this.SelectedConnection.Name, out healthState2) || CommunicationStartupService.TryGetConnectionHealth(this.SelectedConnection.Name, out healthState2);
				this.ApplySelectedConnectionStatusText(this.SelectedConnection, healthState2, hasHealthState2);
			}
		}

		// Token: 0x06001B0E RID: 6926 RVA: 0x000943A4 File Offset: 0x000925A4
		private void RefreshConnectionListVisual()
		{
			bool flag = this.ConnectionList == null;
			if (!flag)
			{
				try
				{
					this.ConnectionList.Items.Refresh();
				}
				catch
				{
				}
			}
		}

		// Token: 0x06001B0F RID: 6927 RVA: 0x000943EC File Offset: 0x000925EC
		private bool ResolveConnectionRuntimeConnected(CommunicationConnection connection, CommunicationHealthState healthState, bool hasHealthState)
		{
			bool flag = connection == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else if (hasHealthState)
			{
				result = healthState.IsConnected;
			}
			else
			{
				string triggerConnectionName = this.GetCurrentCameraTriggerConnectionName();
				bool flag2 = !string.IsNullOrWhiteSpace(triggerConnectionName) && string.Equals(connection.Name, triggerConnectionName, StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = CameraTriggerCommunicationService.IsActiveConnectionConnected();
				}
				else
				{
					result = this._communicationService.IsConnected(connection);
				}
			}
			return result;
		}

		// Token: 0x06001B10 RID: 6928 RVA: 0x00094454 File Offset: 0x00092654
		private void ApplyRuntimeConnectionState(CommunicationConnection connection, CommunicationHealthState healthState, bool hasHealthState)
		{
			bool flag = connection == null;
			if (!flag)
			{
				bool isConnected = this.ResolveConnectionRuntimeConnected(connection, healthState, hasHealthState);
				connection.Status = (isConnected ? "Connected" : "Disconnected");
				connection.LastUpdate = (((healthState != null) ? healthState.LastUpdate.ToString("HH:mm:ss") : null) ?? DateTime.Now.ToString("HH:mm:ss"));
				bool flag2 = isConnected && (string.IsNullOrWhiteSpace(connection.ConnectedTime) || connection.ConnectedTime == "--");
				if (flag2)
				{
					connection.ConnectedTime = "00:00:00";
				}
			}
		}

		// Token: 0x06001B11 RID: 6929 RVA: 0x00094500 File Offset: 0x00092700
		private void ApplySelectedConnectionStatusText(CommunicationConnection connection, CommunicationHealthState healthState, bool hasHealthState)
		{
			bool flag = this.ConnectionTestText == null || connection == null;
			if (!flag)
			{
				bool selectedConnected = this.ResolveConnectionRuntimeConnected(connection, healthState, hasHealthState);
				this.ConnectionTestText.Text = (selectedConnected ? "Connected" : ((!string.IsNullOrWhiteSpace((healthState != null) ? healthState.Message : null)) ? healthState.Message : "Disconnected"));
				this.ConnectionTestText.Foreground = (selectedConnected ? Brushes.LimeGreen : Brushes.IndianRed);
			}
		}

		// Token: 0x06001B12 RID: 6930 RVA: 0x00094580 File Offset: 0x00092780
		private string GetCurrentCameraTriggerConnectionName()
		{
			ComboBoxEdit cameraTriggerConnectionComboEdit = this.CameraTriggerConnectionComboEdit;
			string triggerConnectionName = Convert.ToString((cameraTriggerConnectionComboEdit != null) ? cameraTriggerConnectionComboEdit.EditValue : null);
			bool flag = string.IsNullOrWhiteSpace(triggerConnectionName);
			if (flag)
			{
				ComboBoxEdit cameraTriggerConnectionComboEdit2 = this.CameraTriggerConnectionComboEdit;
				triggerConnectionName = Convert.ToString((cameraTriggerConnectionComboEdit2 != null) ? cameraTriggerConnectionComboEdit2.SelectedItem : null);
			}
			bool flag2 = string.IsNullOrWhiteSpace(triggerConnectionName);
			if (flag2)
			{
				triggerConnectionName = this.CameraTriggerConnectionName;
			}
			bool flag3 = string.IsNullOrWhiteSpace(triggerConnectionName) || string.Equals(triggerConnectionName, "None", StringComparison.OrdinalIgnoreCase);
			if (flag3)
			{
				triggerConnectionName = CameraTriggerCommunicationService.GetActiveConnectionName();
			}
			return triggerConnectionName;
		}

		// Token: 0x06001B13 RID: 6931 RVA: 0x00094604 File Offset: 0x00092804
		private void CommunicationStartupService_ConnectionHealthChanged(object sender, CommunicationHealthChangedEventArgs e)
		{
			CommunicationHealthChangedEventArgs e2 = e;
			bool flag = ((e2 != null) ? e2.State : null) == null;
			if (!flag)
			{
				bool flag2 = !base.Dispatcher.CheckAccess();
				if (flag2)
				{
					base.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this.CommunicationStartupService_ConnectionHealthChanged(sender, e);
					}), Array.Empty<object>());
				}
				else
				{
					bool flag3 = !string.IsNullOrWhiteSpace(e.State.ConnectionName);
					if (flag3)
					{
						this._latestConnectionHealthStates[e.State.ConnectionName] = e.State;
					}
					CommunicationConnection connection = this.Connections.FirstOrDefault((CommunicationConnection x) => string.Equals(x.Name, e.State.ConnectionName, StringComparison.OrdinalIgnoreCase));
					bool flag4 = connection != null;
					if (flag4)
					{
						this.ApplyRuntimeConnectionState(connection, e.State, true);
					}
					this.RefreshConnectionListVisual();
					this.ApplyCameraTriggerRuntimeState();
					this.RefreshConnectionListVisual();
					bool flag5 = this.SelectedConnection != null && string.Equals(this.SelectedConnection.Name, e.State.ConnectionName, StringComparison.OrdinalIgnoreCase) && this.ConnectionTestText != null;
					if (flag5)
					{
						this.ApplySelectedConnectionStatusText(this.SelectedConnection, e.State, true);
					}
					bool flag6 = !e.State.IsHeartbeatPulse;
					if (flag6)
					{
						this.AddLog(e.State.IsConnected ? "Info" : "Error", e.State.ConnectionName + ": " + e.State.Message);
					}
					bool isConnected = e.State.IsConnected;
					if (isConnected)
					{
						this.StartOpcHeartbeatReadThread();
					}
				}
			}
		}

		// Token: 0x06001B14 RID: 6932 RVA: 0x000947F4 File Offset: 0x000929F4
		private void ApplyCameraTriggerRuntimeState()
		{
			List<string> names = new List<string>();
			ICollection<string> names2 = names;
			ComboBoxEdit cameraTriggerConnectionComboEdit = this.CameraTriggerConnectionComboEdit;
			Form_communication.AddUniqueName(names2, Convert.ToString((cameraTriggerConnectionComboEdit != null) ? cameraTriggerConnectionComboEdit.EditValue : null));
			ICollection<string> names3 = names;
			ComboBoxEdit cameraTriggerConnectionComboEdit2 = this.CameraTriggerConnectionComboEdit;
			Form_communication.AddUniqueName(names3, Convert.ToString((cameraTriggerConnectionComboEdit2 != null) ? cameraTriggerConnectionComboEdit2.SelectedItem : null));
			Form_communication.AddUniqueName(names, this.CameraTriggerConnectionName);
			Form_communication.AddUniqueName(names, CameraTriggerCommunicationService.GetActiveConnectionName());
			bool flag = names.Count == 0;
			if (!flag)
			{
				using (List<string>.Enumerator enumerator = names.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string name = enumerator.Current;
						CommunicationHealthState monitoredState;
						bool hasMonitoredState = CommunicationStartupService.TryGetConnectionHealth(name, out monitoredState);
						bool isConnected = hasMonitoredState ? monitoredState.IsConnected : CameraTriggerCommunicationService.IsActiveConnectionConnected();
						string message = hasMonitoredState ? monitoredState.Message : (isConnected ? "Connected." : "Disconnected.");
						DateTime lastUpdate = hasMonitoredState ? monitoredState.LastUpdate : DateTime.Now;
						CommunicationHealthState state = new CommunicationHealthState
						{
							ConnectionName = name,
							IsConnected = isConnected,
							Message = message,
							LastUpdate = lastUpdate
						};
						this._latestConnectionHealthStates[name] = state;
						CommunicationConnection connection = this.Connections.FirstOrDefault((CommunicationConnection x) => string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase));
						bool flag2 = connection == null;
						if (!flag2)
						{
							connection.Status = (isConnected ? "Connected" : "Disconnected");
							connection.LastUpdate = lastUpdate.ToString("HH:mm:ss");
							bool flag3 = isConnected && (string.IsNullOrWhiteSpace(connection.ConnectedTime) || connection.ConnectedTime == "--");
							if (flag3)
							{
								connection.ConnectedTime = "00:00:00";
							}
							bool flag4 = this.SelectedConnection != null && string.Equals(this.SelectedConnection.Name, name, StringComparison.OrdinalIgnoreCase);
							if (flag4)
							{
								this.ApplySelectedConnectionStatusText(this.SelectedConnection, state, true);
							}
						}
					}
				}
			}
		}

		// Token: 0x06001B15 RID: 6933 RVA: 0x00094A30 File Offset: 0x00092C30
		private static void AddUniqueName(ICollection<string> names, string name)
		{
			bool flag = names == null || string.IsNullOrWhiteSpace(name) || string.Equals(name, "None", StringComparison.OrdinalIgnoreCase);
			if (!flag)
			{
				string normalizedName = name.Trim();
				bool flag2 = !names.Any((string x) => string.Equals(x, normalizedName, StringComparison.OrdinalIgnoreCase));
				if (flag2)
				{
					names.Add(normalizedName);
				}
			}
		}

		// Token: 0x06001B16 RID: 6934 RVA: 0x00094A98 File Offset: 0x00092C98
		private void ApplyConnectionFilter(string keyword)
		{
			this.FilteredConnections.Clear();
			ObservableCollection<CommunicationConnection> query = string.IsNullOrWhiteSpace(keyword) ? this.Connections : new ObservableCollection<CommunicationConnection>(from x in this.Connections
			where Form_communication.ContainsText(x.Name, keyword) || Form_communication.ContainsText(x.Protocol, keyword) || Form_communication.ContainsText(x.Status, keyword)
			select x);
			foreach (CommunicationConnection connection in query)
			{
				this.FilteredConnections.Add(connection);
			}
			this.RefreshCameraTriggerConnectionOptions();
		}

		// Token: 0x06001B17 RID: 6935 RVA: 0x00094B3C File Offset: 0x00092D3C
		private void RefreshCameraTriggerConnectionOptions()
		{
			string selectedName = this.CameraTriggerConnectionName;
			this._isRefreshingCameraTriggerOptions = true;
			try
			{
				this.CameraTriggerConnectionOptions.Clear();
				this.CameraTriggerConnectionOptions.Add("None");
				foreach (string connection in (from x in this.Connections
				where x != null && !string.IsNullOrWhiteSpace(x.Name)
				select x.Name.Trim()).Distinct(StringComparer.OrdinalIgnoreCase))
				{
					this.CameraTriggerConnectionOptions.Add(connection);
				}
				string resolvedName = this.ResolveCameraTriggerConnectionName(selectedName);
				this.CameraTriggerConnectionName = resolvedName;
				bool flag = this.CameraTriggerConnectionComboEdit != null;
				if (flag)
				{
					this.CameraTriggerConnectionComboEdit.ItemsSource = this.CameraTriggerConnectionOptions;
					this.CameraTriggerConnectionComboEdit.SelectedItem = resolvedName;
					this.CameraTriggerConnectionComboEdit.EditValue = resolvedName;
				}
			}
			finally
			{
				this._isRefreshingCameraTriggerOptions = false;
			}
		}

		// Token: 0x06001B18 RID: 6936 RVA: 0x00094C78 File Offset: 0x00092E78
		private string ResolveCameraTriggerConnectionName(string selectedName)
		{
			bool flag = string.IsNullOrWhiteSpace(selectedName);
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				string matched = this.CameraTriggerConnectionOptions.FirstOrDefault((string x) => string.Equals(x, selectedName, StringComparison.OrdinalIgnoreCase));
				result = (string.IsNullOrWhiteSpace(matched) ? "None" : matched);
			}
			return result;
		}

		// Token: 0x06001B19 RID: 6937 RVA: 0x00094CD8 File Offset: 0x00092ED8
		private static bool ContainsText(string value, string keyword)
		{
			return !string.IsNullOrEmpty(value) && value.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x06001B1A RID: 6938 RVA: 0x00094D04 File Offset: 0x00092F04
		private void RefreshProtocolInformation()
		{
			this.ProtocolFunctions.Clear();
			this.ProtocolSummary = string.Empty;
			string protocol = this.GetEditorProtocol();
			string text = protocol;
			string a = text;
			if (!(a == "Modbus Server TCP/IP"))
			{
				if (!(a == "OPC UA"))
				{
					if (!(a == "MX Component"))
					{
						if (!(a == "MC Protocol"))
						{
							this.ProtocolSummary = "Modbus Client TCP/IP connects to a PLC/server by IP address and port. Default Modbus TCP port is 502.";
							this.ProtocolFunctions.Add("01 Read Coil Status");
							this.ProtocolFunctions.Add("02 Read Discrete Inputs");
							this.ProtocolFunctions.Add("03 Read Holding Registers");
							this.ProtocolFunctions.Add("04 Read Input Registers");
							this.ProtocolFunctions.Add("05 Write Single Coil");
							this.ProtocolFunctions.Add("06 Write Single Register");
							this.ProtocolFunctions.Add("15 Write Multiple Coils");
							this.ProtocolFunctions.Add("16 Write Multiple Registers");
						}
						else
						{
							this.ProtocolSummary = "MC Protocol talks to the Mitsubishi PLC Ethernet module directly over the network, in 3E binary frames. Nothing has to be installed on this PC: the connection needs only the IP address and port set in the PLC parameters.";
							this.ProtocolFunctions.Add("IP address and port of the PLC Ethernet module");
							this.ProtocolFunctions.Add("Common default port 5007 (check the PLC Ethernet parameters)");
							this.ProtocolFunctions.Add("Tag Address format: device notation D100, M0, X1A, Y20, R0, W0");
							this.ProtocolFunctions.Add("X, Y, B, W, SB, SW and ZR device numbers are HEXADECIMAL");
							this.ProtocolFunctions.Add("32-bit values use the device and the next one (D100 + D101)");
							this.ProtocolFunctions.Add("Writing while the PLC is in RUN must be enabled in its Ethernet parameters");
							this.ProtocolFunctions.Add("Read/Write supported for BOOL, INT16, UINT16, INT32, UINT32, FLOAT, REAL, DINT");
						}
					}
					else
					{
						this.ProtocolSummary = "MX Component reaches a Mitsubishi PLC through the logical station set up in MX Component's Communication Setup Utility. That utility holds the route, the port and the PLC type, so this connection only needs the work station number.";
						this.ProtocolFunctions.Add("Work Station = Logical Station Number (0..1023)");
						this.ProtocolFunctions.Add("No IP or port here - configured in MX Component");
						this.ProtocolFunctions.Add("Tag Address format: device notation D100, M0, X1A, Y20, R0, W0");
						this.ProtocolFunctions.Add("32-bit values use the device and the next one (D100 + D101)");
						this.ProtocolFunctions.Add("Data Monitor reads Tag Management rows marked Read");
						this.ProtocolFunctions.Add("Read/Write supported for BOOL, INT16, UINT16, INT32, UINT32, FLOAT, REAL, DINT");
					}
				}
				else
				{
					this.ProtocolSummary = "OPC UA client connects to an OPC UA endpoint. Data Monitor reads all readable tags from Tag Management by NodeId.";
					this.ProtocolFunctions.Add("OPC UA endpoint setup");
					this.ProtocolFunctions.Add("Default endpoint port 4840");
					this.ProtocolFunctions.Add("Tag Address format: ns=2;s=TagName or ns=2;i=1001");
					this.ProtocolFunctions.Add("Data Monitor reads Tag Management rows marked Read");
					this.ProtocolFunctions.Add("Read/Write supported for BOOL, INT16, UINT16, INT32, UINT32, FLOAT, REAL, DINT, STRING");
				}
			}
			else
			{
				this.ProtocolSummary = "Modbus Server TCP/IP listens on the selected port. This mode stores the server configuration and opens a TCP listener for connection tests.";
				this.ProtocolFunctions.Add("TCP server/listener mode");
				this.ProtocolFunctions.Add("Port-only network setup");
				this.ProtocolFunctions.Add("Recipe-based configuration");
				this.ProtocolFunctions.Add("Future register map expansion");
			}
			bool flag = this.ProtocolSummaryText != null;
			if (flag)
			{
				this.ProtocolSummaryText.Text = this.ProtocolSummary;
			}
		}

		// Token: 0x06001B1B RID: 6939 RVA: 0x00094FE4 File Offset: 0x000931E4
		private void LoadInitialValueCache(CommunicationConfigData config)
		{
			this._initialValuesByConnection.Clear();
			foreach (KeyValuePair<string, List<CommunicationInitialValueRow>> entry in (((config != null) ? config.InitialValues : null) ?? new Dictionary<string, List<CommunicationInitialValueRow>>()))
			{
				bool flag = string.IsNullOrWhiteSpace(entry.Key);
				if (!flag)
				{
					this._initialValuesByConnection[entry.Key.Trim()] = Form_communication.CloneInitialValues(entry.Value);
				}
			}
			foreach (CommunicationConnection connection in this.Connections)
			{
				string key = Form_communication.GetConnectionTagKey(connection);
				bool flag2 = !this._initialValuesByConnection.ContainsKey(key);
				if (flag2)
				{
					this._initialValuesByConnection[key] = new List<CommunicationInitialValueRow>();
				}
			}
		}

		// Token: 0x06001B1C RID: 6940 RVA: 0x000950F4 File Offset: 0x000932F4
		private void LoadInitialValuesForConnection(CommunicationConnection connection)
		{
			this.InitialValueRows.Clear();
			bool flag = this.InitialValueModelText != null;
			if (flag)
			{
				TextBlock initialValueModelText = this.InitialValueModelText;
				string str = "Current Model: ";
				ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
				initialValueModelText.Text = str + (((currentModel != null) ? currentModel.Model_name : null) ?? "None");
			}
			bool flag2 = this.InitialValueConfigPathText != null;
			if (flag2)
			{
				this.InitialValueConfigPathText.Text = "Config: " + CommunicationConfigStorageService.GetConfigPath();
			}
			bool flag3 = connection == null;
			if (!flag3)
			{
				string key = Form_communication.GetConnectionTagKey(connection);
				List<CommunicationInitialValueRow> rows;
				bool flag4 = !this._initialValuesByConnection.TryGetValue(key, out rows);
				if (flag4)
				{
					rows = new List<CommunicationInitialValueRow>();
					this._initialValuesByConnection[key] = rows;
				}
				foreach (CommunicationInitialValueRow row in Form_communication.CloneInitialValues(rows))
				{
					this.InitialValueRows.Add(row);
				}
				this.RefreshInitialValueAddressOptions();
			}
		}

		// Token: 0x06001B1D RID: 6941 RVA: 0x00095210 File Offset: 0x00093410
		private void RefreshInitialValueAddressOptions()
		{
			this.InitialValueAddressOptions.Clear();
			this.InitialValueAddressOptions.Add("None");
			CommunicationConnection selectedConnection = this.SelectedConnection;
			CommunicationAddressStyle style = CommunicationAddressStyles.FromProtocol((selectedConnection != null) ? selectedConnection.Protocol : null);
			CommunicationAddressStyle communicationAddressStyle = style;
			CommunicationAddressStyle communicationAddressStyle2 = communicationAddressStyle;
			if (communicationAddressStyle2 != CommunicationAddressStyle.OpcNodeId)
			{
				if (communicationAddressStyle2 != CommunicationAddressStyle.MxDevice)
				{
					foreach (string hint in new string[]
					{
						"40001",
						"40002",
						"40010",
						"40020"
					})
					{
						this.InitialValueAddressOptions.Add(hint);
					}
				}
				else
				{
					foreach (string hint2 in new string[]
					{
						"D0",
						"D100",
						"D200",
						"M0",
						"M100",
						"R0",
						"W0",
						"B0"
					})
					{
						this.InitialValueAddressOptions.Add(hint2);
					}
				}
			}
			else
			{
				foreach (string address in this.OpcTagAddressOptions)
				{
					this.InitialValueAddressOptions.Add(address);
				}
			}
		}

		// Token: 0x06001B1E RID: 6942 RVA: 0x00095384 File Offset: 0x00093584
		private void SaveCurrentInitialValuesForSelectedConnection()
		{
			bool flag = this._selectedConnection == null;
			if (!flag)
			{
				try
				{
					GridControl initialValueGrid = this.InitialValueGrid;
					if (initialValueGrid != null)
					{
						DataViewBase view = initialValueGrid.View;
						if (view != null)
						{
							view.CommitEditing();
						}
					}
				}
				catch
				{
				}
				this._initialValuesByConnection[Form_communication.GetConnectionTagKey(this._selectedConnection)] = Form_communication.CloneInitialValues(this.InitialValueRows);
			}
		}

		// Token: 0x06001B1F RID: 6943 RVA: 0x000953FC File Offset: 0x000935FC
		private Dictionary<string, List<CommunicationInitialValueRow>> BuildSerializableInitialValues()
		{
			this.SaveCurrentInitialValuesForSelectedConnection();
			Dictionary<string, List<CommunicationInitialValueRow>> result = new Dictionary<string, List<CommunicationInitialValueRow>>(StringComparer.OrdinalIgnoreCase);
			foreach (CommunicationConnection connection in this.Connections)
			{
				bool flag = connection == null || string.IsNullOrWhiteSpace(connection.Name);
				if (!flag)
				{
					string key = Form_communication.GetConnectionTagKey(connection);
					List<CommunicationInitialValueRow> rows;
					result[key] = (this._initialValuesByConnection.TryGetValue(key, out rows) ? Form_communication.CloneInitialValues(rows) : new List<CommunicationInitialValueRow>());
				}
			}
			return result;
		}

		// Token: 0x06001B20 RID: 6944 RVA: 0x000954A8 File Offset: 0x000936A8
		private static List<CommunicationInitialValueRow> CloneInitialValues(IEnumerable<CommunicationInitialValueRow> rows)
		{
			return (from x in rows ?? Enumerable.Empty<CommunicationInitialValueRow>()
			where x != null
			select new CommunicationInitialValueRow
			{
				Name = x.Name,
				Address = x.Address,
				Value = x.Value,
				DataType = x.DataType
			}).ToList<CommunicationInitialValueRow>();
		}

		// Token: 0x06001B21 RID: 6945 RVA: 0x00095511 File Offset: 0x00093711
		private void ReloadInitialValues_Click(object sender, RoutedEventArgs e)
		{
			this.EnsureInitialData(true);
			GridControl initialValueGrid = this.InitialValueGrid;
			if (initialValueGrid != null)
			{
				initialValueGrid.RefreshData();
			}
		}

		// Token: 0x06001B22 RID: 6946 RVA: 0x0009552E File Offset: 0x0009372E
		private void AddInitialValue_Click(object sender, RoutedEventArgs e)
		{
			this.InsertInitialValueRow(this.InitialValueRows.Count, "added");
		}

		// Token: 0x06001B23 RID: 6947 RVA: 0x00095548 File Offset: 0x00093748
		private void InsertInitialValue_Click(object sender, RoutedEventArgs e)
		{
			GridControl initialValueGrid = this.InitialValueGrid;
			CommunicationInitialValueRow current = ((initialValueGrid != null) ? initialValueGrid.CurrentItem : null) as CommunicationInitialValueRow;
			int index = (current == null) ? 0 : Math.Max(0, this.InitialValueRows.IndexOf(current));
			this.InsertInitialValueRow(index, "inserted");
		}

		// Token: 0x06001B24 RID: 6948 RVA: 0x00095594 File Offset: 0x00093794
		private void InsertInitialValueRow(int index, string action)
		{
			bool flag = this.SelectedConnection == null;
			if (flag)
			{
				DXMessageBox.Show("Select a connection first - initial values belong to the connection they are written to.", "Initial Values", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				CommunicationInitialValueRow row = new CommunicationInitialValueRow
				{
					Name = this.GetUniqueInitialValueName("Initial value"),
					Address = "None",
					Value = "0",
					DataType = "INT16"
				};
				bool flag2 = index < 0;
				if (flag2)
				{
					index = 0;
				}
				bool flag3 = index > this.InitialValueRows.Count;
				if (flag3)
				{
					index = this.InitialValueRows.Count;
				}
				this.InitialValueRows.Insert(index, row);
				this.SaveCurrentInitialValuesForSelectedConnection();
				bool flag4 = this.InitialValueGrid != null;
				if (flag4)
				{
					this.InitialValueGrid.CurrentItem = row;
					this.InitialValueGrid.RefreshData();
				}
				this.AddLog("Info", "Initial value row " + action + ".");
			}
		}

		// Token: 0x06001B25 RID: 6949 RVA: 0x0009568C File Offset: 0x0009388C
		private void DeleteInitialValue_Click(object sender, RoutedEventArgs e)
		{
			GridControl initialValueGrid = this.InitialValueGrid;
			CommunicationInitialValueRow row = ((initialValueGrid != null) ? initialValueGrid.CurrentItem : null) as CommunicationInitialValueRow;
			bool flag = row == null;
			if (flag)
			{
				DXMessageBox.Show("Select the row to delete.", "Initial Values", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				MessageBoxResult answer = DXMessageBox.Show("Delete '" + (row.Name ?? row.Address) + "'?", "Initial Values", MessageBoxButton.OKCancel, MessageBoxImage.Question);
				bool flag2 = answer != MessageBoxResult.OK;
				if (!flag2)
				{
					this.InitialValueRows.Remove(row);
					this.SaveCurrentInitialValuesForSelectedConnection();
					GridControl initialValueGrid2 = this.InitialValueGrid;
					if (initialValueGrid2 != null)
					{
						initialValueGrid2.RefreshData();
					}
					this.AddLog("Info", "Initial value row deleted.");
				}
			}
		}

		// Token: 0x06001B26 RID: 6950 RVA: 0x00095744 File Offset: 0x00093944
		private void WriteInitialValues_Click(object sender, RoutedEventArgs e)
		{
			this.SaveCurrentInitialValuesForSelectedConnection();
			bool flag = !this.SaveConnections();
			if (!flag)
			{
				try
				{
					CommunicationInitialValueResult result = CommunicationInitialValueService.WriteCurrentModel(CommunicationConfigStorageService.GetConfigPath());
					foreach (string error in result.Errors)
					{
						this.AddLog("Warning", error);
					}
					this.AddLog("Info", string.Concat(new string[]
					{
						"Initial values written: ",
						result.WrittenCount.ToString(),
						" register(s)",
						(result.ParkedCount > 0) ? (", " + result.ParkedCount.ToString() + " parked (None)") : string.Empty,
						(result.SkippedCount > 0) ? (", " + result.SkippedCount.ToString() + " skipped") : string.Empty,
						"."
					}));
					DXMessageBox.Show((result.Errors.Count == 0) ? ("Wrote " + result.WrittenCount.ToString() + " register(s) to the PLC." + ((result.ParkedCount > 0) ? (Environment.NewLine + result.ParkedCount.ToString() + " row(s) are set to None and were not sent.") : string.Empty)) : string.Concat(new string[]
					{
						"Wrote ",
						result.WrittenCount.ToString(),
						" register(s). ",
						result.Errors.Count.ToString(),
						" problem(s):",
						Environment.NewLine,
						string.Join(Environment.NewLine, result.Errors)
					}), "Initial Values", MessageBoxButton.OK, (result.Errors.Count == 0) ? MessageBoxImage.Asterisk : MessageBoxImage.Exclamation);
				}
				catch (Exception ex)
				{
					this.AddLog("Error", "Writing initial values failed: " + ex.Message);
					DXMessageBox.Show("Writing initial values failed:" + Environment.NewLine + ex.Message, "Initial Values", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		// Token: 0x06001B27 RID: 6951 RVA: 0x000959B8 File Offset: 0x00093BB8
		private string GetUniqueInitialValueName(string baseName)
		{
			int index = 1;
			string candidate = baseName + " " + index.ToString();
			Func<CommunicationInitialValueRow, bool> <>9__0;
			for (;;)
			{
				IEnumerable<CommunicationInitialValueRow> initialValueRows = this.InitialValueRows;
				Func<CommunicationInitialValueRow, bool> predicate;
				if ((predicate = <>9__0) == null)
				{
					predicate = (<>9__0 = delegate(CommunicationInitialValueRow x)
					{
						string a;
						if (x == null)
						{
							a = null;
						}
						else
						{
							string name = x.Name;
							a = ((name != null) ? name.Trim() : null);
						}
						return string.Equals(a, candidate, StringComparison.OrdinalIgnoreCase);
					});
				}
				if (!initialValueRows.Any(predicate))
				{
					break;
				}
				index++;
				candidate = baseName + " " + index.ToString();
			}
			return candidate;
		}

		// Token: 0x06001B28 RID: 6952 RVA: 0x00095A40 File Offset: 0x00093C40
		public void RefreshFromCurrentModel()
		{
			this.EnsureInitialData(true);
		}

		// Token: 0x06001B29 RID: 6953 RVA: 0x00095A4B File Offset: 0x00093C4B
		private void FormCommunication_Loaded(object sender, RoutedEventArgs e)
		{
			this.HookToolOptionsSourceChanged();
			this.EnsureInitialData(false);
		}

		// Token: 0x06001B2A RID: 6954 RVA: 0x00095A60 File Offset: 0x00093C60
		private void EnsureInitialData(bool forceReload = false)
		{
			base.DataContext = this;
			this._ignoreNullSelectionWhileLoading = true;
			bool flag = this.ProtocolComboEdit != null;
			if (flag)
			{
				this.ProtocolComboEdit.ItemsSource = this.ProtocolOptions;
			}
			bool flag2 = this.ProtocolFunctionList != null;
			if (flag2)
			{
				this.ProtocolFunctionList.ItemsSource = this.ProtocolFunctions;
			}
			bool flag3 = this.MonitorDataTypeTabCombo != null;
			if (flag3)
			{
				this.MonitorDataTypeTabCombo.ItemsSource = this.MonitorDataTypes;
			}
			bool flag4 = this.MonitorFunctionCodeTabCombo != null;
			if (flag4)
			{
				this.MonitorFunctionCodeTabCombo.ItemsSource = this.MonitorFunctionCodes;
			}
			bool flag5 = this.TagDataTypeEditSettings != null;
			if (flag5)
			{
				this.TagDataTypeEditSettings.ItemsSource = this.TagDataTypes;
			}
			bool flag6 = this.TagAddressEditSettings != null;
			if (flag6)
			{
				this.TagAddressEditSettings.ItemsSource = this.OpcTagAddressOptions;
			}
			bool flag7 = this.TagReadWriteEditSettings != null;
			if (flag7)
			{
				this.TagReadWriteEditSettings.ItemsSource = this.TagReadWriteOptions;
			}
			bool flag8 = this.TagLinkedToolEditSettings != null;
			if (flag8)
			{
				this.TagLinkedToolEditSettings.ItemsSource = this.ResultToolLinkOptions;
			}
			bool flag9 = this.TagResultFieldEditSettings != null;
			if (flag9)
			{
				this.TagResultFieldEditSettings.ItemsSource = this.ResultFieldOptions;
			}
			bool flag10 = this.CameraTriggerConnectionComboEdit != null;
			if (flag10)
			{
				this.CameraTriggerConnectionComboEdit.ItemsSource = this.CameraTriggerConnectionOptions;
			}
			bool flag11 = this.MonitorGrid != null;
			if (flag11)
			{
				this.MonitorGrid.ItemsSource = this.MonitorRows;
			}
			bool flag12 = this.TagGrid != null;
			if (flag12)
			{
				this.TagGrid.ItemsSource = this.TagRows;
			}
			bool flag13 = this.InitialValueGrid != null;
			if (flag13)
			{
				this.InitialValueGrid.ItemsSource = this.InitialValueRows;
			}
			bool flag14 = this.InitialValueDataTypeEditSettings != null;
			if (flag14)
			{
				this.InitialValueDataTypeEditSettings.ItemsSource = this.TagDataTypes;
			}
			bool flag15 = this.InitialValueAddressEditSettings != null;
			if (flag15)
			{
				this.InitialValueAddressEditSettings.ItemsSource = this.InitialValueAddressOptions;
			}
			this.InitializeCommunicationLogFilter();
			bool flag16 = this.LogList != null;
			if (flag16)
			{
				this.LogList.ItemsSource = this._communicationLogView;
			}
			this.LoadRuntimeSettingsFromModel();
			bool flag17 = CameraRuntimeStore.Cameras.Count > 0;
			if (flag17)
			{
				try
				{
					CameraCommunicationTagSyncService.SynchronizeCurrentModel(from x in CameraRuntimeStore.Cameras
					select (x != null) ? x.CameraName : null);
				}
				catch (Exception ex)
				{
					Debug.WriteLine("Communication camera tag preload synchronization failed: " + ex.Message);
				}
			}
			string currentConfigPath = CommunicationConfigStorageService.GetConfigPath();
			bool configPathChanged = !string.Equals(this._loadedConfigPath, currentConfigPath, StringComparison.OrdinalIgnoreCase);
			bool flag18 = forceReload || !this._initialDataReady || configPathChanged;
			if (flag18)
			{
				this.LoadConnectionsFromModel();
			}
			this.RefreshResultLinkOptions();
			TextEdit searchConnectionEdit = this.SearchConnectionEdit;
			this.ApplyConnectionFilter(Convert.ToString((searchConnectionEdit != null) ? searchConnectionEdit.EditValue : null));
			bool flag19;
			if (this.FilteredConnections.Count == 0 && this.Connections.Count > 0)
			{
				TextEdit searchConnectionEdit2 = this.SearchConnectionEdit;
				flag19 = !string.IsNullOrWhiteSpace(Convert.ToString((searchConnectionEdit2 != null) ? searchConnectionEdit2.EditValue : null));
			}
			else
			{
				flag19 = false;
			}
			bool flag20 = flag19;
			if (flag20)
			{
				this.SearchConnectionEdit.EditValue = null;
				this.ApplyConnectionFilter(null);
			}
			bool flag21 = this.SelectedConnection == null;
			if (flag21)
			{
				this.SelectedConnection = this.FilteredConnections.FirstOrDefault<CommunicationConnection>();
			}
			this.UpdateSelectedConnectionState();
			this.UpdateProtocolUi();
			this.PushEditingConnectionToEditors();
			bool flag22 = this.MonitorRows.Count == 0;
			if (flag22)
			{
				this.LoadSampleMonitorRows();
			}
			this.EnsureDefaultTagsForSelectedConnection();
			this.SaveCurrentTagsForSelectedConnection();
			this.SyncCameraTagsForAllConnectionCaches();
			this.LoadTagsForConnection(this.SelectedConnection);
			this.LoadInitialValuesForConnection(this.SelectedConnection);
			this.PersistSynchronizedCameraTags();
			bool flag23 = this.ConnectionList != null;
			if (flag23)
			{
				this.ConnectionList.ItemsSource = this.FilteredConnections;
				bool flag24 = this.SelectedConnection != null;
				if (flag24)
				{
					this.ConnectionList.SelectedItem = this.SelectedConnection;
				}
			}
			this.ScheduleInitialSelectionRefresh();
			this.ScheduleCommunicationAutoConnect();
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				this.LoadRuntimeSettingsFromModel();
				this.RefreshCameraTriggerConnectionOptions();
			}), DispatcherPriority.ContextIdle, Array.Empty<object>());
			bool flag25 = !this._initialDataReady;
			if (flag25)
			{
				this.AddLog("Info", "Communication form initialized.");
				this._initialDataReady = true;
			}
			this.StartConnectionStatusTimer();
			this.StartOpcHeartbeatReadThread();
		}

		// Token: 0x06001B2B RID: 6955 RVA: 0x00095EF0 File Offset: 0x000940F0
		private void StartConnectionStatusTimer()
		{
			bool isEnabled = this._connectionStatusTimer.IsEnabled;
			if (!isEnabled)
			{
				this._connectionStatusTimer.Interval = TimeSpan.FromSeconds(1.0);
				this._connectionStatusTimer.Tick += this.ConnectionStatusTimer_Tick;
				this._connectionStatusTimer.Start();
			}
		}

		// Token: 0x06001B2C RID: 6956 RVA: 0x00095F4D File Offset: 0x0009414D
		private void ConnectionStatusTimer_Tick(object sender, EventArgs e)
		{
			this.StartOpcHeartbeatReadThread();
			this.RefreshConnectionRuntimeState();
		}

		// Token: 0x170008B1 RID: 2225
		// (get) Token: 0x06001B2D RID: 6957 RVA: 0x00095F5E File Offset: 0x0009415E
		public string[] CommunicationLogLevelOptions { get; } = new string[]
		{
			"All Levels",
			"Error",
			"Warning",
			"Info",
			"Success",
			"Trigger",
			"Command"
		};

		// Token: 0x170008B2 RID: 2226
		// (get) Token: 0x06001B2E RID: 6958 RVA: 0x00095F68 File Offset: 0x00094168
		// (set) Token: 0x06001B2F RID: 6959 RVA: 0x00095F80 File Offset: 0x00094180
		public string SelectedCommunicationLogLevel
		{
			get
			{
				return this._selectedCommunicationLogLevel;
			}
			set
			{
				string normalized = string.IsNullOrWhiteSpace(value) ? "All Levels" : value.Trim();
				bool flag = string.Equals(this._selectedCommunicationLogLevel, normalized, StringComparison.OrdinalIgnoreCase);
				if (!flag)
				{
					this._selectedCommunicationLogLevel = normalized;
					this.OnPropertyChanged("SelectedCommunicationLogLevel");
					ICollectionView communicationLogView = this._communicationLogView;
					if (communicationLogView != null)
					{
						communicationLogView.Refresh();
					}
				}
			}
		}

		// Token: 0x06001B30 RID: 6960 RVA: 0x00095FE0 File Offset: 0x000941E0
		private void InitializeCommunicationLogFilter()
		{
			bool flag = this._communicationLogView == null;
			if (flag)
			{
				this._communicationLogView = CollectionViewSource.GetDefaultView(this.LogRows);
				this._communicationLogView.Filter = new Predicate<object>(this.IsCommunicationLogVisible);
			}
			bool flag2 = this.CommunicationLogLevelEdit == null;
			if (!flag2)
			{
				this.CommunicationLogLevelEdit.ItemsSource = this.CommunicationLogLevelOptions;
				bool flag3 = this.CommunicationLogLevelEdit.SelectedIndex < 0;
				if (flag3)
				{
					this.CommunicationLogLevelEdit.SelectedIndex = 0;
				}
			}
		}

		// Token: 0x06001B31 RID: 6961 RVA: 0x00096068 File Offset: 0x00094268
		private void CommunicationLogLevelEdit_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ComboBox comboBox = sender as ComboBox;
			this.SelectedCommunicationLogLevel = ((((comboBox != null) ? comboBox.SelectedItem : null) as string) ?? "All Levels");
		}

		// Token: 0x06001B32 RID: 6962 RVA: 0x000960A0 File Offset: 0x000942A0
		private bool IsCommunicationLogVisible(object item)
		{
			CommunicationLogRow row = item as CommunicationLogRow;
			bool flag = row == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = string.Equals(this.SelectedCommunicationLogLevel, "All Levels", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = true;
				}
				else
				{
					string selectedLevel = Form_communication.NormalizeCommunicationLogLevel(this.SelectedCommunicationLogLevel);
					result = string.Equals(row.Level, selectedLevel, StringComparison.OrdinalIgnoreCase);
				}
			}
			return result;
		}

		// Token: 0x06001B33 RID: 6963 RVA: 0x000960FC File Offset: 0x000942FC
		private void LoadSampleTags()
		{
			Form_communication.<>c__DisplayClass200_0 CS$<>8__locals1 = new Form_communication.<>c__DisplayClass200_0();
			this.TagRows.Clear();
			Form_communication.<>c__DisplayClass200_0 CS$<>8__locals2 = CS$<>8__locals1;
			CommunicationConnection selectedConnection = this.SelectedConnection;
			CS$<>8__locals2.sampleStyle = CommunicationAddressStyles.FromProtocol((selectedConnection != null) ? selectedConnection.Protocol : null);
			Func<string, string> sample = (string x) => CommunicationAddressStyles.Format(x, CS$<>8__locals1.sampleStyle);
			this.TagRows.Add(new CommunicationTagRow("StatusCode", sample("40001"), "INT16", "Read", "Machine status"));
			this.TagRows.Add(new CommunicationTagRow("ProductCount", sample("40002"), "UINT16", "Read", "Counter from PLC"));
			this.TagRows.Add(new CommunicationTagRow("StartSignal", sample("40010"), "BOOL", "Read/Write", "Start trigger"));
			this.TagRows.Add(new CommunicationTagRow("StopSignal", sample("40011"), "BOOL", "Read/Write", "Stop trigger"));
			this.TagRows.Add(new CommunicationTagRow("Temperature", sample("40020"), "REAL", "Read", "Analog value"));
			this.EnsureDefaultCalibrationTags();
		}

		// Token: 0x06001B34 RID: 6964 RVA: 0x00096240 File Offset: 0x00094440
		private void LoadConnectionTagCache(CommunicationConfigData config)
		{
			foreach (KeyValuePair<string, List<CommunicationTagRow>> entry in (config.ConnectionTags ?? new Dictionary<string, List<CommunicationTagRow>>()))
			{
				bool flag = string.IsNullOrWhiteSpace(entry.Key);
				if (!flag)
				{
					this._tagsByConnection[entry.Key.Trim()] = Form_communication.CloneTagRows(entry.Value);
				}
			}
			bool flag2;
			if (this._tagsByConnection.Count == 0)
			{
				List<CommunicationTagRow> tags = config.Tags;
				flag2 = (((tags != null) ? tags.Count : 0) > 0);
			}
			else
			{
				flag2 = false;
			}
			bool flag3 = flag2;
			if (flag3)
			{
				string key = Form_communication.GetConnectionTagKey(this.Connections.FirstOrDefault<CommunicationConnection>());
				this._tagsByConnection[key] = Form_communication.CloneTagRows(config.Tags);
			}
			foreach (CommunicationConnection connection in this.Connections)
			{
				string key2 = Form_communication.GetConnectionTagKey(connection);
				bool flag4 = !this._tagsByConnection.ContainsKey(key2);
				if (flag4)
				{
					this._tagsByConnection[key2] = new List<CommunicationTagRow>();
				}
			}
		}

		// Token: 0x06001B35 RID: 6965 RVA: 0x00096398 File Offset: 0x00094598
		private void EnsureDefaultTagsForSelectedConnection()
		{
			bool flag = this.TagRows.Count == 0;
			if (flag)
			{
				this.LoadSampleTags();
			}
			else
			{
				this.EnsureDefaultCalibrationTags();
			}
		}

		// Token: 0x06001B36 RID: 6966 RVA: 0x000963CC File Offset: 0x000945CC
		private void EnsureDefaultCalibrationTags()
		{
			this.RemoveTagByName("calibration quality position");
			this.AddDefaultTagIfMissing("calibration snap", "40001", "INT16", "Read", "Robot trigger: capture image.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration robot x", "40002", "FLOAT", "Read", "Robot actual X position.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration robot y", "40004", "FLOAT", "Read", "Robot actual Y position.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration robot degree", "40006", "FLOAT", "Read", "Robot actual angle.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration position point", "40008", "INT16", "Write", "Number of position (mapping) calibration points, sent from the Calib Hand-Eye setting on Apply.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration rotation point", "40009", "INT16", "Write", "Number of rotation calibration points, sent from the Calib Hand-Eye setting on Apply.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration complete", "40010", "INT16", "Read", "Robot calibration complete bit.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration start", "40011", "INT16", "Write", "Calibration control command sent to robot: 1=start, 2=pause, 0=stop.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("vision busy", "40012", "INT16", "Write", "Vision is processing current calibration point.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("vision capture done", "40013", "INT16", "Write", "Vision capture and processing completed.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("vision result ok", "40014", "INT16", "Write", "Vision result status: 1=OK, 0=NG.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("vision x", "40015", "FLOAT", "Write", "Vision detected X/column in pixel.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("vision y", "40017", "FLOAT", "Write", "Vision detected Y/row in pixel.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("vision degree", "40019", "FLOAT", "Write", "Vision detected angle in degree.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("vision score", "40021", "FLOAT", "Write", "Vision detected score.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("robot next point", "40023", "INT16", "Write", "Vision command: robot can move to next calibration point.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("vision error code", "40024", "INT16", "Write", "Vision error code for robot.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration result valid", "40025", "INT16", "Write", "Calibration result valid: 1=OK, 0=NG.", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration scale x", "40026", "FLOAT", "Write", "Calibration pixel size X (mm/pixel).", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration scale y", "40028", "FLOAT", "Write", "Calibration pixel size Y (mm/pixel).", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration rotation", "40030", "FLOAT", "Write", "Calibration rotation angle (degree).", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration offset x", "40032", "FLOAT", "Write", "Calibration translation X (mm).", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration offset y", "40034", "FLOAT", "Write", "Calibration translation Y (mm).", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration angle offset", "40036", "FLOAT", "Write", "Calibration vision-to-robot angle offset (degree).", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing("calibration rms error", "40038", "FLOAT", "Write", "Calibration RMS position error (mm).", "Calib Hand-Eye");
			this.AddDefaultTagIfMissing(this.HeartbeatTagNameForSelectedProtocol(), string.Empty, "BOOL", "Read", "PLC heartbeat bit. PLC toggles this bit every 1 second; vision reads it for connection health.", "Connection Health");
			this.AddDefaultTagIfMissing("vision error status", "40040", "INT16", "Write", "Vision error code: 0=OK, N=camera N vision/disconnect error, 10=triggered but no result (other reason).", "Connection Health");
			this.EnsureCameraCommunicationTags();
			this.NormalizeTagOptions();
			this.NormalizeResultTagLinks();
			this.UpdateDuplicateTagWarnings();
			GridControl tagGrid = this.TagGrid;
			if (tagGrid != null)
			{
				tagGrid.RefreshData();
			}
		}

		// Token: 0x06001B37 RID: 6967 RVA: 0x000967FC File Offset: 0x000949FC
		private void RefreshResultLinkOptions()
		{
			this.ResultToolLinkOptions.Clear();
			this.ResultToolLinkOptions.Add("None");
			this.ResultToolLinkOptions.Add("Auto: Result Inspection of triggered TurnSnap");
			this.ResultToolLinkOptions.Add("Auto: Result Align of triggered TurnSnap");
			foreach (string option in this.EnumerateResultToolOptions())
			{
				bool flag = !this.ResultToolLinkOptions.Contains(option);
				if (flag)
				{
					this.ResultToolLinkOptions.Add(option);
				}
			}
			this.ResultFieldOptions.Clear();
			this.ResultFieldOptions.Add("None");
			this.ResultFieldOptions.Add("Align.ResultOk");
			this.ResultFieldOptions.Add("Align.Count");
			this.ResultFieldOptions.Add("Align.X");
			this.ResultFieldOptions.Add("Align.Y");
			this.ResultFieldOptions.Add("Align.Degree");
			this.ResultFieldOptions.Add("Align.Score");
			this.ResultFieldOptions.Add("Align.Complete");
			this.ResultFieldOptions.Add("Align.ErrorCode");
			this.ResultFieldOptions.Add("BoundingBox.CenterX");
			this.ResultFieldOptions.Add("BoundingBox.CenterY");
			this.ResultFieldOptions.Add("BoundingBox.AngleDegree");
			this.ResultFieldOptions.Add("Inspection.ResultOk");
			this.ResultFieldOptions.Add("Inspection.ResultNg");
			this.ResultFieldOptions.Add("Inspection.NgCode");
			this.ResultFieldOptions.Add("Inspection.Value");
			this.ResultFieldOptions.Add("Inspection.TotalOk");
			this.ResultFieldOptions.Add("Inspection.TotalNg");
			this.ResultFieldOptions.Add("Inspection.Complete");
			bool flag2 = this.TagLinkedToolEditSettings != null;
			if (flag2)
			{
				this.TagLinkedToolEditSettings.ItemsSource = null;
				this.TagLinkedToolEditSettings.ItemsSource = this.ResultToolLinkOptions;
			}
			bool flag3 = this.TagResultFieldEditSettings != null;
			if (flag3)
			{
				this.TagResultFieldEditSettings.ItemsSource = null;
				this.TagResultFieldEditSettings.ItemsSource = this.ResultFieldOptions;
			}
		}

		// Token: 0x06001B38 RID: 6968 RVA: 0x00096A54 File Offset: 0x00094C54
		private IEnumerable<string> EnumerateResultToolOptions()
		{
			Form_communication.<EnumerateResultToolOptions>d__205 <EnumerateResultToolOptions>d__ = new Form_communication.<EnumerateResultToolOptions>d__205(-2);
			<EnumerateResultToolOptions>d__.<>4__this = this;
			return <EnumerateResultToolOptions>d__;
		}

		// Token: 0x06001B39 RID: 6969 RVA: 0x00096A64 File Offset: 0x00094C64
		private static string FormatResultToolOption(string cameraName, int turnSnapIndex, string toolName, ToolType toolType)
		{
			string typeText = (toolType == ToolType.ResultAlign) ? "Result Align" : "Result Inspection";
			return string.Concat(new string[]
			{
				string.IsNullOrWhiteSpace(cameraName) ? "Camera" : cameraName,
				" / TurnSnap ",
				Math.Max(1, turnSnapIndex).ToString(),
				" / ",
				string.IsNullOrWhiteSpace(toolName) ? typeText : toolName,
				" [",
				typeText,
				"]"
			});
		}

		// Token: 0x06001B3A RID: 6970 RVA: 0x00096AEC File Offset: 0x00094CEC
		private void EnsureCameraCommunicationTags()
		{
			List<string> cameras = (from x in CameraRuntimeStore.Cameras
			where x != null && !string.IsNullOrWhiteSpace(x.CameraName)
			select x.CameraName.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList<string>();
			this.RemoveTagsOfMissingCameras(cameras);
			for (int i = 0; i < cameras.Count; i++)
			{
				string cameraName = cameras[i];
				int baseAddress = 41000 + i * 500;
				string prefix = "camera " + cameraName;
				string triggerGroup = cameraName + " - Trigger Camera";
				this.AddDefaultTagIfMissing(prefix + " trigger snap", Form_communication.Address(baseAddress), "INT16", "Read", "Robot trigger bit for camera snap.", triggerGroup);
				this.AddDefaultTagIfMissing(prefix + " trigger run", Form_communication.Address(baseAddress + 1), "INT16", "Read", "Robot trigger bit for running selected TurnSnap.", triggerGroup);
				this.AddDefaultTagIfMissing(prefix + " vision busy", Form_communication.Address(baseAddress + 2), "INT16", "Write", "Vision busy status for this camera.", triggerGroup);
				this.AddDefaultTagIfMissing(prefix + " snap complete", Form_communication.Address(baseAddress + 3), "INT16", "Write", "Vision snap completed bit for this camera.", triggerGroup);
				this.AddDefaultTagIfMissing(prefix + " run complete", Form_communication.Address(baseAddress + 4), "INT16", "Write", "Vision run completed bit for this camera.", triggerGroup);
				this.AddDefaultTagIfMissing(prefix + " error code", Form_communication.Address(baseAddress + 5), "INT16", "Write", "Vision camera trigger error code.", triggerGroup);
				this.AddDefaultTagIfMissing(prefix + " connected", Form_communication.Address(baseAddress + 6), "INT16", "Write", "Camera connection status written by vision: 1 = camera is connected, 0 = connection lost.", triggerGroup);
				string alignGroup = cameraName + " - Result Vision Align";
				int alignBaseAddress = baseAddress + 50;
				this.AddDefaultTagIfMissing(prefix + " align complete", Form_communication.Address(alignBaseAddress), "INT16", "Write", "Vision align processing completed.", alignGroup, "Align.Complete", 1);
				this.AddDefaultTagIfMissing(prefix + " align result ok", Form_communication.Address(alignBaseAddress + 1), "INT16", "Write", "Vision align result: 1=OK, 0=NG.", alignGroup, "Align.ResultOk", 1);
				this.AddDefaultTagIfMissing(prefix + " align object count", Form_communication.Address(alignBaseAddress + 2), "INT16", "Write", "Number of objects detected by vision for this align result.", alignGroup, "Align.Count", 1);
				this.AddDefaultTagIfMissing(prefix + " align x", Form_communication.Address(alignBaseAddress + 10), "FLOAT", "Write", "Vision align robot X result list. Address is the start register; reserve the next 100 registers for this list.", alignGroup, "Align.X", 100);
				this.AddDefaultTagIfMissing(prefix + " align y", Form_communication.Address(alignBaseAddress + 110), "FLOAT", "Write", "Vision align robot Y result list. Address is the start register; reserve the next 100 registers for this list.", alignGroup, "Align.Y", 100);
				this.AddDefaultTagIfMissing(prefix + " align degree", Form_communication.Address(alignBaseAddress + 210), "FLOAT", "Write", "Vision align angle result list. Address is the start register; reserve the next 100 registers for this list.", alignGroup, "Align.Degree", 100);
				this.AddDefaultTagIfMissing(prefix + " align score", Form_communication.Address(alignBaseAddress + 310), "FLOAT", "Write", "Vision align score result list. Address is the start register; reserve the next 100 registers for this list.", alignGroup, "Align.Score", 100);
				this.AddDefaultTagIfMissing(prefix + " align error code", Form_communication.Address(alignBaseAddress + 410), "INT16", "Write", "Vision align error code.", alignGroup, "Align.ErrorCode", 1);
				string inspectionGroup = cameraName + " - Result Vision Inspection";
				this.AddDefaultTagIfMissing(prefix + " inspection complete", Form_communication.Address(baseAddress + 30), "INT16", "Write", "Vision inspection processing completed.", inspectionGroup, "Inspection.Complete", 1);
				this.AddDefaultTagIfMissing(prefix + " inspection result ok", Form_communication.Address(baseAddress + 31), "INT16", "Write", "Vision inspection result: 1=OK, 0=NG.", inspectionGroup, "Inspection.ResultOk", 1);
				this.AddDefaultTagIfMissing(prefix + " inspection ng code", Form_communication.Address(baseAddress + 32), "INT16", "Write", "Vision inspection NG code.", inspectionGroup, "Inspection.NgCode", 1);
				this.AddDefaultTagIfMissing(prefix + " inspection value", Form_communication.Address(baseAddress + 33), "FLOAT", "Write", "Vision inspection measured value.", inspectionGroup, "Inspection.Value", 1);
				this.AddDefaultTagIfMissing(prefix + " inspection result ng", Form_communication.Address(baseAddress + 37), "INT16", "Write", "Vision inspection result: 1=NG, 0=OK.", inspectionGroup, "Inspection.ResultNg", 1);
				this.AddDefaultTagIfMissing(prefix + " inspection total ok", Form_communication.Address(baseAddress + 35), "INT16", "Write", "Vision inspection all tools OK bit.", inspectionGroup, "Inspection.TotalOk", 1);
				this.AddDefaultTagIfMissing(prefix + " inspection total ng", Form_communication.Address(baseAddress + 36), "INT16", "Write", "Vision inspection any tool NG bit.", inspectionGroup, "Inspection.TotalNg", 1);
			}
		}

		// Token: 0x06001B3B RID: 6971 RVA: 0x00097010 File Offset: 0x00095210
		private void SyncCameraTagsForAllConnectionCaches()
		{
			List<string> cameras = (from x in CameraRuntimeStore.Cameras
			where x != null && !string.IsNullOrWhiteSpace(x.CameraName)
			select x.CameraName.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).ToList<string>();
			HashSet<string> keys = new HashSet<string>(this._tagsByConnection.Keys, StringComparer.OrdinalIgnoreCase);
			foreach (CommunicationConnection connection in this.Connections)
			{
				keys.Add(Form_communication.GetConnectionTagKey(connection));
			}
			using (List<string>.Enumerator enumerator2 = keys.ToList<string>().GetEnumerator())
			{
				while (enumerator2.MoveNext())
				{
					string key = enumerator2.Current;
					CommunicationConnection connection2 = this.Connections.FirstOrDefault((CommunicationConnection x) => string.Equals(Form_communication.GetConnectionTagKey(x), key, StringComparison.OrdinalIgnoreCase));
					List<CommunicationTagRow> tags;
					bool flag = !this._tagsByConnection.TryGetValue(key, out tags) || tags == null;
					if (flag)
					{
						tags = new List<CommunicationTagRow>();
					}
					Form_communication.SynchronizeCameraTags(tags, cameras, Form_communication.IsOpcUaConnection(connection2));
					this._tagsByConnection[key] = Form_communication.NormalizeTagsForConnection(connection2, tags);
				}
			}
		}

		// Token: 0x06001B3C RID: 6972 RVA: 0x000971A0 File Offset: 0x000953A0
		private static void SynchronizeCameraTags(IList<CommunicationTagRow> tags, IList<string> cameras, bool isOpcConnection)
		{
			bool flag = tags == null;
			if (!flag)
			{
				Form_communication.RemoveTagsOfMissingCameras(tags, cameras);
				for (int i = 0; i < ((cameras != null) ? cameras.Count : 0); i++)
				{
					string cameraName = cameras[i];
					int baseAddress = 41000 + i * 500;
					string prefix = "camera " + cameraName;
					string triggerGroup = cameraName + " - Trigger Camera";
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " trigger snap", Form_communication.Address(baseAddress), "INT16", "Read", "Robot trigger bit for camera snap.", triggerGroup, null, 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " trigger run", Form_communication.Address(baseAddress + 1), "INT16", "Read", "Robot trigger bit for running selected TurnSnap.", triggerGroup, null, 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " vision busy", Form_communication.Address(baseAddress + 2), "INT16", "Write", "Vision busy status for this camera.", triggerGroup, null, 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " snap complete", Form_communication.Address(baseAddress + 3), "INT16", "Write", "Vision snap completed bit for this camera.", triggerGroup, null, 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " run complete", Form_communication.Address(baseAddress + 4), "INT16", "Write", "Vision run completed bit for this camera.", triggerGroup, null, 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " error code", Form_communication.Address(baseAddress + 5), "INT16", "Write", "Vision camera trigger error code.", triggerGroup, null, 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " connected", Form_communication.Address(baseAddress + 6), "INT16", "Write", "Camera connection status written by vision: 1 = camera is connected, 0 = connection lost.", triggerGroup, null, 1, isOpcConnection);
					string alignGroup = cameraName + " - Result Vision Align";
					int alignBaseAddress = baseAddress + 50;
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " align complete", Form_communication.Address(alignBaseAddress), "INT16", "Write", "Vision align processing completed.", alignGroup, "Align.Complete", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " align result ok", Form_communication.Address(alignBaseAddress + 1), "INT16", "Write", "Vision align result: 1=OK, 0=NG.", alignGroup, "Align.ResultOk", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " align object count", Form_communication.Address(alignBaseAddress + 2), "INT16", "Write", "Number of objects detected by vision for this align result.", alignGroup, "Align.Count", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " align x", Form_communication.Address(alignBaseAddress + 10), "FLOAT", "Write", "Vision align robot X result list. Address is the start register; reserve the next 100 registers for this list.", alignGroup, "Align.X", 100, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " align y", Form_communication.Address(alignBaseAddress + 110), "FLOAT", "Write", "Vision align robot Y result list. Address is the start register; reserve the next 100 registers for this list.", alignGroup, "Align.Y", 100, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " align degree", Form_communication.Address(alignBaseAddress + 210), "FLOAT", "Write", "Vision align angle result list. Address is the start register; reserve the next 100 registers for this list.", alignGroup, "Align.Degree", 100, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " align score", Form_communication.Address(alignBaseAddress + 310), "FLOAT", "Write", "Vision align score result list. Address is the start register; reserve the next 100 registers for this list.", alignGroup, "Align.Score", 100, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " align error code", Form_communication.Address(alignBaseAddress + 410), "INT16", "Write", "Vision align error code.", alignGroup, "Align.ErrorCode", 1, isOpcConnection);
					string inspectionGroup = cameraName + " - Result Vision Inspection";
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " inspection complete", Form_communication.Address(baseAddress + 30), "INT16", "Write", "Vision inspection processing completed.", inspectionGroup, "Inspection.Complete", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " inspection result ok", Form_communication.Address(baseAddress + 31), "INT16", "Write", "Vision inspection result: 1=OK, 0=NG.", inspectionGroup, "Inspection.ResultOk", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " inspection ng code", Form_communication.Address(baseAddress + 32), "INT16", "Write", "Vision inspection NG code.", inspectionGroup, "Inspection.NgCode", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " inspection value", Form_communication.Address(baseAddress + 33), "FLOAT", "Write", "Vision inspection measured value.", inspectionGroup, "Inspection.Value", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " inspection result ng", Form_communication.Address(baseAddress + 37), "INT16", "Write", "Vision inspection result: 1=NG, 0=OK.", inspectionGroup, "Inspection.ResultNg", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " inspection total ok", Form_communication.Address(baseAddress + 35), "INT16", "Write", "Vision inspection all tools OK bit.", inspectionGroup, "Inspection.TotalOk", 1, isOpcConnection);
					Form_communication.AddDefaultTagIfMissing(tags, prefix + " inspection total ng", Form_communication.Address(baseAddress + 36), "INT16", "Write", "Vision inspection any tool NG bit.", inspectionGroup, "Inspection.TotalNg", 1, isOpcConnection);
				}
			}
		}

		// Token: 0x06001B3D RID: 6973 RVA: 0x0009769B File Offset: 0x0009589B
		private void RemoveTagsOfMissingCameras(IList<string> currentCameras)
		{
			Form_communication.RemoveTagsOfMissingCameras(this.TagRows, currentCameras);
		}

		// Token: 0x06001B3E RID: 6974 RVA: 0x000976AC File Offset: 0x000958AC
		private static void RemoveTagsOfMissingCameras(IList<CommunicationTagRow> tags, IList<string> currentCameras)
		{
			bool flag = tags == null || tags.Count == 0;
			if (!flag)
			{
				HashSet<string> known = new HashSet<string>(currentCameras ?? new List<string>(), StringComparer.OrdinalIgnoreCase);
				List<CommunicationTagRow> doomed = new List<CommunicationTagRow>();
				foreach (CommunicationTagRow tag in tags)
				{
					bool flag2 = tag == null;
					if (!flag2)
					{
						string cameraName = Form_communication.ExtractCameraNameFromGroup(tag.Group);
						bool flag3 = string.IsNullOrWhiteSpace(cameraName);
						if (flag3)
						{
							cameraName = Form_communication.ExtractCameraNameFromGeneratedTag(tag.Name);
						}
						bool flag4 = string.IsNullOrWhiteSpace(cameraName) || known.Contains(cameraName);
						if (!flag4)
						{
							string tagCameraName = Form_communication.ExtractCameraNameFromGeneratedTag(tag.Name);
							bool flag5 = !string.Equals(tagCameraName, cameraName, StringComparison.OrdinalIgnoreCase);
							if (!flag5)
							{
								doomed.Add(tag);
							}
						}
					}
				}
				foreach (CommunicationTagRow tag2 in doomed)
				{
					tags.Remove(tag2);
				}
			}
		}

		// Token: 0x06001B3F RID: 6975 RVA: 0x000977F0 File Offset: 0x000959F0
		private static string ExtractCameraNameFromGroup(string group)
		{
			bool flag = string.IsNullOrWhiteSpace(group);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				foreach (string suffix in Form_communication.CameraTagGroupSuffixes)
				{
					bool flag2 = group.EndsWith(suffix, StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						return group.Substring(0, group.Length - suffix.Length).Trim();
					}
				}
				result = null;
			}
			return result;
		}

		// Token: 0x06001B40 RID: 6976 RVA: 0x0009785C File Offset: 0x00095A5C
		private static string ExtractCameraNameFromGeneratedTag(string tagName)
		{
			bool flag = string.IsNullOrWhiteSpace(tagName);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				string value = tagName.Trim();
				bool flag2 = !value.StartsWith("camera ", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = null;
				}
				else
				{
					foreach (string suffix in from x in Form_communication.GeneratedCameraTagNameSuffixes
					orderby x.Length descending
					select x)
					{
						bool flag3 = !value.EndsWith(suffix, StringComparison.OrdinalIgnoreCase);
						if (!flag3)
						{
							int cameraNameLength = value.Length - "camera ".Length - suffix.Length;
							bool flag4 = cameraNameLength <= 0;
							if (flag4)
							{
								return null;
							}
							return value.Substring("camera ".Length, cameraNameLength).Trim();
						}
					}
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001B41 RID: 6977 RVA: 0x00097964 File Offset: 0x00095B64
		private static string Address(int address)
		{
			return address.ToString();
		}

		// Token: 0x06001B42 RID: 6978 RVA: 0x00097980 File Offset: 0x00095B80
		private static void AddDefaultTagIfMissing(IList<CommunicationTagRow> tags, string name, string address, string dataType, string readWrite, string description, string group, string resultField, int maxResultCount, bool isOpcConnection)
		{
			bool flag = tags == null;
			if (!flag)
			{
				bool flag2 = isOpcConnection && !Form_communication.LooksLikeOpcNodeId(address);
				if (flag2)
				{
					address = string.Empty;
				}
				string normalizedName = Form_communication.NormalizeTagName(name);
				CommunicationTagRow existing = tags.FirstOrDefault((CommunicationTagRow x) => Form_communication.NormalizeTagName(x.Name) == normalizedName);
				bool flag3 = existing != null;
				if (flag3)
				{
					existing.Name = name;
					bool flag4 = isOpcConnection && !Form_communication.LooksLikeOpcNodeId(existing.Address);
					if (flag4)
					{
						existing.Address = string.Empty;
					}
					else
					{
						bool flag5 = string.IsNullOrWhiteSpace(existing.Address);
						if (flag5)
						{
							existing.Address = address;
						}
					}
					bool flag6 = string.IsNullOrWhiteSpace(existing.DataType);
					if (flag6)
					{
						existing.DataType = dataType;
					}
					bool flag7 = string.IsNullOrWhiteSpace(existing.ReadWrite);
					if (flag7)
					{
						existing.ReadWrite = readWrite;
					}
					bool flag8 = string.IsNullOrWhiteSpace(existing.Description);
					if (flag8)
					{
						existing.Description = description;
					}
					bool flag9 = string.IsNullOrWhiteSpace(existing.Group);
					if (flag9)
					{
						existing.Group = group;
					}
					bool flag10 = string.IsNullOrWhiteSpace(existing.ResultField);
					if (flag10)
					{
						existing.ResultField = resultField;
					}
					bool flag11 = existing.MaxResultCount <= 0;
					if (flag11)
					{
						existing.MaxResultCount = Math.Max(1, maxResultCount);
					}
				}
				else
				{
					tags.Add(new CommunicationTagRow(name, address, dataType, readWrite, description, group)
					{
						ResultField = resultField,
						MaxResultCount = Math.Max(1, maxResultCount)
					});
				}
			}
		}

		// Token: 0x06001B43 RID: 6979 RVA: 0x00097B04 File Offset: 0x00095D04
		private void AddDefaultTagIfMissing(string name, string address, string dataType, string readWrite, string description)
		{
			this.AddDefaultTagIfMissing(name, address, dataType, readWrite, description, "General");
		}

		// Token: 0x06001B44 RID: 6980 RVA: 0x00097B1C File Offset: 0x00095D1C
		private void AddDefaultTagIfMissing(string name, string address, string dataType, string readWrite, string description, string group)
		{
			this.AddDefaultTagIfMissing(name, address, dataType, readWrite, description, group, null, 1);
		}

		// Token: 0x06001B45 RID: 6981 RVA: 0x00097B3C File Offset: 0x00095D3C
		private string HeartbeatTagNameForSelectedProtocol()
		{
			CommunicationConnection selectedConnection = this.SelectedConnection;
			string protocol = (selectedConnection != null) ? selectedConnection.Protocol : null;
			bool flag = string.Equals(protocol, "MX Component", StringComparison.OrdinalIgnoreCase);
			string result;
			if (flag)
			{
				result = "mx component heartbeat";
			}
			else
			{
				bool flag2 = string.Equals(protocol, "MC Protocol", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = "mc protocol heartbeat";
				}
				else
				{
					bool flag3 = string.Equals(protocol, "OPC UA", StringComparison.OrdinalIgnoreCase);
					if (flag3)
					{
						result = "opc heartbeat";
					}
					else
					{
						result = "plc heartbeat";
					}
				}
			}
			return result;
		}

		// Token: 0x06001B46 RID: 6982 RVA: 0x00097BB0 File Offset: 0x00095DB0
		private void RemoveTagByName(string name)
		{
			string normalized = Form_communication.NormalizeTagName(name);
			List<CommunicationTagRow> stale = (from x in this.TagRows
			where x != null && Form_communication.NormalizeTagName(x.Name) == normalized
			select x).ToList<CommunicationTagRow>();
			foreach (CommunicationTagRow tag in stale)
			{
				this.TagRows.Remove(tag);
			}
		}

		// Token: 0x06001B47 RID: 6983 RVA: 0x00097C38 File Offset: 0x00095E38
		private void AddDefaultTagIfMissing(string name, string address, string dataType, string readWrite, string description, string group, string resultField, int maxResultCount)
		{
			CommunicationConnection selectedConnection = this.SelectedConnection;
			CommunicationAddressStyle addressStyle = CommunicationAddressStyles.FromProtocol((selectedConnection != null) ? selectedConnection.Protocol : null);
			address = CommunicationAddressStyles.Format(address, addressStyle);
			string normalizedName = Form_communication.NormalizeTagName(name);
			CommunicationTagRow communicationTagRow;
			if (!Form_communication.IsHeartbeatTagName(name))
			{
				communicationTagRow = this.TagRows.FirstOrDefault((CommunicationTagRow x) => Form_communication.NormalizeTagName(x.Name) == normalizedName);
			}
			else
			{
				communicationTagRow = this.TagRows.FirstOrDefault((CommunicationTagRow x) => x != null && Form_communication.IsHeartbeatTagName(x.Name));
			}
			CommunicationTagRow existing = communicationTagRow;
			bool flag = existing != null;
			if (flag)
			{
				existing.Name = name;
				bool flag2 = !CommunicationAddressStyles.Matches(existing.Address, addressStyle);
				if (flag2)
				{
					existing.Address = address;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(existing.Address);
					if (flag3)
					{
						existing.Address = address;
					}
				}
				bool flag4 = Form_communication.IsHeartbeatTagName(name);
				if (flag4)
				{
					existing.DataType = dataType;
					existing.ReadWrite = readWrite;
					bool flag5 = string.IsNullOrWhiteSpace(existing.Description) || existing.Description.IndexOf("Heartbeat", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag5)
					{
						existing.Description = description;
					}
				}
				else
				{
					bool flag6 = string.IsNullOrWhiteSpace(existing.DataType);
					if (flag6)
					{
						existing.DataType = dataType;
					}
				}
				bool flag7 = string.IsNullOrWhiteSpace(existing.ReadWrite);
				if (flag7)
				{
					existing.ReadWrite = readWrite;
				}
				bool flag8 = string.IsNullOrWhiteSpace(existing.Description);
				if (flag8)
				{
					existing.Description = description;
				}
				bool flag9 = string.IsNullOrWhiteSpace(existing.Group);
				if (flag9)
				{
					existing.Group = group;
				}
				bool flag10 = string.IsNullOrWhiteSpace(existing.ResultField);
				if (flag10)
				{
					existing.ResultField = resultField;
				}
				bool flag11 = existing.MaxResultCount <= 0;
				if (flag11)
				{
					existing.MaxResultCount = Math.Max(1, maxResultCount);
				}
			}
			else
			{
				CommunicationTagRow tag = new CommunicationTagRow(name, address, dataType, readWrite, description, group)
				{
					ResultField = resultField,
					MaxResultCount = Math.Max(1, maxResultCount)
				};
				this.TagRows.Add(tag);
			}
		}

		// Token: 0x06001B48 RID: 6984 RVA: 0x00097E48 File Offset: 0x00096048
		private void NormalizeTagOptions()
		{
			bool isOpcConnection = Form_communication.IsOpcUaConnection(this.SelectedConnection);
			bool hasTagDrivenHeartbeat = isOpcConnection || Form_communication.IsMitsubishiConnection(this.SelectedConnection);
			using (IEnumerator<CommunicationTagRow> enumerator = this.TagRows.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					CommunicationTagRow tag = enumerator.Current;
					bool flag = string.IsNullOrWhiteSpace(tag.DataType) || !this.TagDataTypes.Any((string x) => string.Equals(x, tag.DataType, StringComparison.OrdinalIgnoreCase));
					if (flag)
					{
						tag.DataType = "BOOL";
					}
					bool flag2 = string.IsNullOrWhiteSpace(tag.ReadWrite) || !this.TagReadWriteOptions.Any((string x) => string.Equals(x, tag.ReadWrite, StringComparison.OrdinalIgnoreCase));
					if (flag2)
					{
						tag.ReadWrite = (string.Equals(tag.Name, "calibration complete", StringComparison.OrdinalIgnoreCase) ? "Read" : "Write");
					}
					bool flag3 = string.IsNullOrWhiteSpace(tag.Group);
					if (flag3)
					{
						tag.Group = "General";
					}
					bool flag4 = tag.MaxResultCount <= 0;
					if (flag4)
					{
						tag.MaxResultCount = 1;
					}
					bool flag5 = Form_communication.IsHeartbeatTagName(tag.Name);
					if (flag5)
					{
						tag.DataType = "BOOL";
						tag.ReadWrite = "Read";
						bool flag6 = !hasTagDrivenHeartbeat;
						if (flag6)
						{
							tag.Address = string.Empty;
						}
					}
					bool flag7 = isOpcConnection && !string.IsNullOrWhiteSpace(tag.Address) && !Form_communication.LooksLikeOpcNodeId(tag.Address);
					if (flag7)
					{
						tag.Address = string.Empty;
					}
				}
			}
		}

		// Token: 0x06001B49 RID: 6985 RVA: 0x00098060 File Offset: 0x00096260
		private bool UpdateDuplicateTagWarnings()
		{
			return CommunicationTagValidationService.UpdateDuplicateWarnings(this.TagRows);
		}

		// Token: 0x06001B4A RID: 6986 RVA: 0x00098080 File Offset: 0x00096280
		private void NormalizeResultTagLinks()
		{
			foreach (CommunicationTagRow tag in this.TagRows)
			{
				bool flag = tag == null;
				if (!flag)
				{
					bool flag2 = !Form_communication.IsVisionResultTag(tag);
					if (flag2)
					{
						tag.LinkedToolName = "None";
						tag.ResultField = "None";
						tag.MaxResultCount = 1;
					}
					else
					{
						bool flag3 = string.IsNullOrWhiteSpace(tag.LinkedToolName);
						if (flag3)
						{
							tag.LinkedToolName = "None";
						}
						bool flag4 = string.IsNullOrWhiteSpace(tag.ResultField);
						if (flag4)
						{
							tag.ResultField = Form_communication.GetDefaultResultField(tag);
						}
						bool flag5 = !Form_communication.IsResultFieldAllowed(tag, tag.ResultField);
						if (flag5)
						{
							tag.ResultField = Form_communication.GetDefaultResultField(tag);
						}
						bool flag6 = tag.MaxResultCount <= 0;
						if (flag6)
						{
							tag.MaxResultCount = 1;
						}
					}
				}
			}
		}

		// Token: 0x06001B4B RID: 6987 RVA: 0x00098188 File Offset: 0x00096388
		private static bool IsVisionResultTag(CommunicationTagRow tag)
		{
			bool flag = tag == null || string.IsNullOrWhiteSpace(tag.Group);
			return !flag && (tag.Group.IndexOf("Result Vision Align", StringComparison.OrdinalIgnoreCase) >= 0 || tag.Group.IndexOf("Result Vision Inspection", StringComparison.OrdinalIgnoreCase) >= 0);
		}

		// Token: 0x06001B4C RID: 6988 RVA: 0x000981E4 File Offset: 0x000963E4
		private static bool IsAlignResultTag(CommunicationTagRow tag)
		{
			return tag != null && !string.IsNullOrWhiteSpace(tag.Group) && tag.Group.IndexOf("Result Vision Align", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x06001B4D RID: 6989 RVA: 0x00098220 File Offset: 0x00096420
		private static bool IsInspectionResultTag(CommunicationTagRow tag)
		{
			return tag != null && !string.IsNullOrWhiteSpace(tag.Group) && tag.Group.IndexOf("Result Vision Inspection", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x06001B4E RID: 6990 RVA: 0x0009825C File Offset: 0x0009645C
		private static bool IsResultFieldAllowed(CommunicationTagRow tag, string resultField)
		{
			bool flag = string.IsNullOrWhiteSpace(resultField) || string.Equals(resultField, "None", StringComparison.OrdinalIgnoreCase);
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = Form_communication.IsAlignResultTag(tag);
				if (flag2)
				{
					result = (resultField.StartsWith("Align.", StringComparison.OrdinalIgnoreCase) || resultField.StartsWith("BoundingBox.", StringComparison.OrdinalIgnoreCase));
				}
				else
				{
					bool flag3 = Form_communication.IsInspectionResultTag(tag);
					result = (flag3 && resultField.StartsWith("Inspection.", StringComparison.OrdinalIgnoreCase));
				}
			}
			return result;
		}

		// Token: 0x06001B4F RID: 6991 RVA: 0x000982D4 File Offset: 0x000964D4
		private static string GetDefaultResultField(CommunicationTagRow tag)
		{
			bool flag = tag == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				string name = tag.Name ?? string.Empty;
				bool flag2 = Form_communication.IsAlignResultTag(tag);
				if (flag2)
				{
					bool flag3 = name.IndexOf("object count", StringComparison.OrdinalIgnoreCase) >= 0 || name.IndexOf("count", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag3)
					{
						return "Align.Count";
					}
					bool flag4 = name.IndexOf(" result ok", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag4)
					{
						return "Align.ResultOk";
					}
					bool flag5 = name.IndexOf(" x", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag5)
					{
						return "Align.X";
					}
					bool flag6 = name.IndexOf(" y", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag6)
					{
						return "Align.Y";
					}
					bool flag7 = name.IndexOf("degree", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag7)
					{
						return "Align.Degree";
					}
					bool flag8 = name.IndexOf("score", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag8)
					{
						return "Align.Score";
					}
					bool flag9 = name.IndexOf("complete", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag9)
					{
						return "Align.Complete";
					}
					bool flag10 = name.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag10)
					{
						return "Align.ErrorCode";
					}
				}
				bool flag11 = Form_communication.IsInspectionResultTag(tag);
				if (flag11)
				{
					bool flag12 = name.IndexOf(" result ok", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag12)
					{
						return "Inspection.ResultOk";
					}
					bool flag13 = name.IndexOf(" result ng", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag13)
					{
						return "Inspection.ResultNg";
					}
					bool flag14 = name.IndexOf("ng code", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag14)
					{
						return "Inspection.NgCode";
					}
					bool flag15 = name.IndexOf("value", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag15)
					{
						return "Inspection.Value";
					}
					bool flag16 = name.IndexOf("total ok", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag16)
					{
						return "Inspection.TotalOk";
					}
					bool flag17 = name.IndexOf("total ng", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag17)
					{
						return "Inspection.TotalNg";
					}
					bool flag18 = name.IndexOf("complete", StringComparison.OrdinalIgnoreCase) >= 0;
					if (flag18)
					{
						return "Inspection.Complete";
					}
				}
				result = "None";
			}
			return result;
		}

		// Token: 0x06001B50 RID: 6992 RVA: 0x00098544 File Offset: 0x00096744
		private static string NormalizeTagName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				result = new string(name.Where(new Func<char, bool>(char.IsLetterOrDigit)).ToArray<char>()).ToLowerInvariant();
			}
			return result;
		}

		// Token: 0x06001B51 RID: 6993 RVA: 0x0009858C File Offset: 0x0009678C
		private static bool IsHeartbeatTagName(string name)
		{
			string normalized = Form_communication.NormalizeTagName(name);
			return normalized == "heartbeat" || normalized == "opcheartbeat" || normalized == "modbusheartbeat" || normalized == "mxheartbeat" || normalized == "mxcomponentheartbeat" || normalized == "plcheartbeat" || normalized == "connectionheartbeat";
		}

		// Token: 0x06001B52 RID: 6994 RVA: 0x00098604 File Offset: 0x00096804
		private void TagTableView_CellValueChanged(object sender, CellValueChangedEventArgs e)
		{
			GridColumn column = e.Column;
			bool flag;
			if (!string.Equals((column != null) ? column.FieldName : null, "DataType", StringComparison.OrdinalIgnoreCase))
			{
				GridColumn column2 = e.Column;
				flag = string.Equals((column2 != null) ? column2.FieldName : null, "Address", StringComparison.OrdinalIgnoreCase);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (flag2)
			{
				this.UpdateOpcAddressOptionsForTag(e.Row as CommunicationTagRow);
			}
			this.NormalizeTagOptions();
			this.NormalizeResultTagLinks();
			this.UpdateDuplicateTagWarnings();
			GridControl tagGrid = this.TagGrid;
			if (tagGrid != null)
			{
				tagGrid.RefreshData();
			}
			this.SaveConnections();
		}

		// Token: 0x06001B53 RID: 6995 RVA: 0x00098697 File Offset: 0x00096897
		private void TagTableView_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			this.UpdateOpcAddressOptionsForTag(e.NewRow as CommunicationTagRow);
		}

		// Token: 0x06001B54 RID: 6996 RVA: 0x000986AC File Offset: 0x000968AC
		private void ExportTagManagementExcel_Click(object sender, RoutedEventArgs e)
		{
			SaveFileDialog dialog = new SaveFileDialog
			{
				Title = "Export Tag Management",
				Filter = "Excel Workbook (*.xlsx)|*.xlsx|Excel 97-2003 Workbook (*.xls)|*.xls|CSV UTF-8 (*.csv)|*.csv|All files (*.*)|*.*",
				FileName = "tag_management.xlsx",
				AddExtension = true,
				DefaultExt = ".xlsx",
				OverwritePrompt = true
			};
			bool flag = !dialog.ShowDialog().GetValueOrDefault();
			if (!flag)
			{
				Exception exportError = null;
				this.RunWithBusyOverlay(delegate
				{
					try
					{
						this.NormalizeTagOptions();
						this.NormalizeResultTagLinks();
						GridControl tagGrid = this.TagGrid;
						if (tagGrid != null)
						{
							tagGrid.RefreshData();
						}
						CommunicationTagExportService.Export(this.TagRows, dialog.FileName, dialog.FilterIndex);
						this.AddLog("Info", "Exported tag management to " + dialog.FileName);
					}
					catch (Exception ex)
					{
						exportError = ex;
						this.AddLog("Error", "Export tag management failed: " + ex.Message);
					}
				}, "Exporting tag management to Excel...");
				bool flag2 = exportError == null;
				if (flag2)
				{
					DXMessageBox.Show(this, "Tag management exported successfully.", "Export Excel", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					DXMessageBox.Show(this, exportError.Message, "Export Excel", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		// Token: 0x170008B3 RID: 2227
		// (get) Token: 0x06001B55 RID: 6997 RVA: 0x0009878E File Offset: 0x0009698E
		public ObservableCollection<CommunicationConnection> Connections { get; } = new ObservableCollection<CommunicationConnection>();

		// Token: 0x170008B4 RID: 2228
		// (get) Token: 0x06001B56 RID: 6998 RVA: 0x00098796 File Offset: 0x00096996
		public ObservableCollection<CommunicationConnection> FilteredConnections { get; } = new ObservableCollection<CommunicationConnection>();

		// Token: 0x170008B5 RID: 2229
		// (get) Token: 0x06001B57 RID: 6999 RVA: 0x0009879E File Offset: 0x0009699E
		public ObservableCollection<CommunicationMonitorRow> MonitorRows { get; } = new ObservableCollection<CommunicationMonitorRow>();

		// Token: 0x170008B6 RID: 2230
		// (get) Token: 0x06001B58 RID: 7000 RVA: 0x000987A6 File Offset: 0x000969A6
		public ObservableCollection<CommunicationTagRow> TagRows { get; } = new ObservableCollection<CommunicationTagRow>();

		// Token: 0x170008B7 RID: 2231
		// (get) Token: 0x06001B59 RID: 7001 RVA: 0x000987AE File Offset: 0x000969AE
		public ObservableCollection<CommunicationInitialValueRow> InitialValueRows { get; } = new ObservableCollection<CommunicationInitialValueRow>();

		// Token: 0x170008B8 RID: 2232
		// (get) Token: 0x06001B5A RID: 7002 RVA: 0x000987B6 File Offset: 0x000969B6
		public ObservableCollection<string> InitialValueAddressOptions { get; } = new ObservableCollection<string>();

		// Token: 0x170008B9 RID: 2233
		// (get) Token: 0x06001B5B RID: 7003 RVA: 0x000987BE File Offset: 0x000969BE
		public ObservableCollection<CommunicationCommandRow> CommandRows { get; } = new ObservableCollection<CommunicationCommandRow>();

		// Token: 0x170008BA RID: 2234
		// (get) Token: 0x06001B5C RID: 7004 RVA: 0x000987C6 File Offset: 0x000969C6
		public ObservableCollection<CommunicationLogRow> LogRows { get; } = new ObservableCollection<CommunicationLogRow>();

		// Token: 0x170008BB RID: 2235
		// (get) Token: 0x06001B5D RID: 7005 RVA: 0x000987CE File Offset: 0x000969CE
		public ObservableCollection<string> ProtocolFunctions { get; } = new ObservableCollection<string>();

		// Token: 0x170008BC RID: 2236
		// (get) Token: 0x06001B5E RID: 7006 RVA: 0x000987D6 File Offset: 0x000969D6
		public ObservableCollection<string> ResultToolLinkOptions { get; } = new ObservableCollection<string>();

		// Token: 0x170008BD RID: 2237
		// (get) Token: 0x06001B5F RID: 7007 RVA: 0x000987DE File Offset: 0x000969DE
		public ObservableCollection<string> ResultFieldOptions { get; } = new ObservableCollection<string>();

		// Token: 0x170008BE RID: 2238
		// (get) Token: 0x06001B60 RID: 7008 RVA: 0x000987E6 File Offset: 0x000969E6
		public ObservableCollection<string> CameraTriggerConnectionOptions { get; } = new ObservableCollection<string>();

		// Token: 0x170008BF RID: 2239
		// (get) Token: 0x06001B61 RID: 7009 RVA: 0x000987EE File Offset: 0x000969EE
		public ObservableCollection<string> OpcTagAddressOptions { get; } = new ObservableCollection<string>();

		// Token: 0x170008C0 RID: 2240
		// (get) Token: 0x06001B62 RID: 7010 RVA: 0x000987F6 File Offset: 0x000969F6
		public string[] ProtocolOptions { get; } = new string[]
		{
			"Modbus Client TCP/IP",
			"Modbus Server TCP/IP",
			"OPC UA",
			"MX Component",
			"MC Protocol"
		};

		// Token: 0x170008C1 RID: 2241
		// (get) Token: 0x06001B63 RID: 7011 RVA: 0x000987FE File Offset: 0x000969FE
		public string[] ExchangeOptions { get; } = new string[]
		{
			"10 ms",
			"100 ms",
			"250 ms",
			"500 ms",
			"1000 ms",
			"1250 ms",
			"2000 ms",
			"5000 ms"
		};

		// Token: 0x170008C2 RID: 2242
		// (get) Token: 0x06001B64 RID: 7012 RVA: 0x00098806 File Offset: 0x00096A06
		public string[] RefreshOptions { get; } = new string[]
		{
			"250",
			"500",
			"1000",
			"2000",
			"5000"
		};

		// Token: 0x170008C3 RID: 2243
		// (get) Token: 0x06001B65 RID: 7013 RVA: 0x0009880E File Offset: 0x00096A0E
		public string[] FunctionCodes { get; } = new string[]
		{
			"01 Read Coil Status",
			"02 Read Discrete Inputs",
			"03 Read Holding Registers",
			"04 Read Input Registers",
			"05 Write Single Coil",
			"06 Write Single Register",
			"15 Write Multiple Coils",
			"16 Write Multiple Registers"
		};

		// Token: 0x170008C4 RID: 2244
		// (get) Token: 0x06001B66 RID: 7014 RVA: 0x00098816 File Offset: 0x00096A16
		public string[] ByteOrderOptions { get; } = new string[]
		{
			"Big Endian (AB CD)",
			"Little Endian (DC BA)",
			"Byte Swap (BA DC)",
			"Word Swap (CD AB)"
		};

		// Token: 0x170008C5 RID: 2245
		// (get) Token: 0x06001B67 RID: 7015 RVA: 0x0009881E File Offset: 0x00096A1E
		public string[] FloatFormatOptions { get; } = new string[]
		{
			"IEEE 754",
			"Fixed Point",
			"Signed Integer"
		};

		// Token: 0x170008C6 RID: 2246
		// (get) Token: 0x06001B68 RID: 7016 RVA: 0x00098826 File Offset: 0x00096A26
		public string[] CommandTypes { get; } = new string[]
		{
			"BOOL",
			"INT16",
			"UINT16",
			"DINT",
			"REAL",
			"STRING"
		};

		// Token: 0x170008C7 RID: 2247
		// (get) Token: 0x06001B69 RID: 7017 RVA: 0x0009882E File Offset: 0x00096A2E
		public string[] MonitorDataTypes { get; } = new string[]
		{
			"INT16",
			"UINT16",
			"INT32",
			"UINT32",
			"FLOAT"
		};

		// Token: 0x170008C8 RID: 2248
		// (get) Token: 0x06001B6A RID: 7018 RVA: 0x00098836 File Offset: 0x00096A36
		public string[] TagDataTypes { get; } = new string[]
		{
			"BOOL",
			"INT16",
			"UINT16",
			"INT32",
			"UINT32",
			"FLOAT",
			"REAL",
			"DINT",
			"STRING"
		};

		// Token: 0x170008C9 RID: 2249
		// (get) Token: 0x06001B6B RID: 7019 RVA: 0x0009883E File Offset: 0x00096A3E
		public string[] TagReadWriteOptions { get; } = new string[]
		{
			"Read",
			"Write"
		};

		// Token: 0x170008CA RID: 2250
		// (get) Token: 0x06001B6C RID: 7020 RVA: 0x00098846 File Offset: 0x00096A46
		public string[] MonitorFunctionCodes { get; } = new string[]
		{
			"03 Read Holding Registers",
			"04 Read Input Registers"
		};

		// Token: 0x1400002C RID: 44
		// (add) Token: 0x06001B6D RID: 7021 RVA: 0x00098850 File Offset: 0x00096A50
		// (remove) Token: 0x06001B6E RID: 7022 RVA: 0x00098888 File Offset: 0x00096A88
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x170008CB RID: 2251
		// (get) Token: 0x06001B6F RID: 7023 RVA: 0x000988BD File Offset: 0x00096ABD
		// (set) Token: 0x06001B70 RID: 7024 RVA: 0x000988C8 File Offset: 0x00096AC8
		public CommunicationConnection SelectedConnection
		{
			get
			{
				return this._selectedConnection;
			}
			set
			{
				bool flag = value == null && this._ignoreNullSelectionWhileLoading && this.Connections.Count > 0;
				if (!flag)
				{
					this.SetSelectedConnection(value, false);
				}
			}
		}

		// Token: 0x170008CC RID: 2252
		// (get) Token: 0x06001B71 RID: 7025 RVA: 0x00098902 File Offset: 0x00096B02
		// (set) Token: 0x06001B72 RID: 7026 RVA: 0x0009890A File Offset: 0x00096B0A
		public CommunicationConnection EditingConnection
		{
			get
			{
				return this._editingConnection;
			}
			set
			{
				this._editingConnection = (value ?? Form_communication.CreateDefaultEditingConnection());
				this.OnPropertyChanged("EditingConnection");
			}
		}

		// Token: 0x170008CD RID: 2253
		// (get) Token: 0x06001B73 RID: 7027 RVA: 0x00098929 File Offset: 0x00096B29
		// (set) Token: 0x06001B74 RID: 7028 RVA: 0x00098934 File Offset: 0x00096B34
		public string CameraTriggerConnectionName
		{
			get
			{
				return this._cameraTriggerConnectionName;
			}
			set
			{
				string normalizedValue = string.IsNullOrWhiteSpace(value) ? "None" : value;
				bool flag = this._cameraTriggerConnectionName == normalizedValue;
				if (!flag)
				{
					this._cameraTriggerConnectionName = normalizedValue;
					this.OnPropertyChanged("CameraTriggerConnectionName");
				}
			}
		}

		// Token: 0x170008CE RID: 2254
		// (get) Token: 0x06001B75 RID: 7029 RVA: 0x00098978 File Offset: 0x00096B78
		// (set) Token: 0x06001B76 RID: 7030 RVA: 0x00098980 File Offset: 0x00096B80
		public string SelectedProtocol
		{
			get
			{
				return this._selectedProtocol;
			}
			set
			{
				bool flag = string.IsNullOrWhiteSpace(value);
				if (flag)
				{
					value = "Modbus Client TCP/IP";
				}
				bool flag2 = this._selectedProtocol == value;
				if (!flag2)
				{
					this._selectedProtocol = value;
					this.OnPropertyChanged("SelectedProtocol");
					this.ApplySelectedProtocolToConnection();
				}
			}
		}

		// Token: 0x170008CF RID: 2255
		// (get) Token: 0x06001B77 RID: 7031 RVA: 0x000989CB File Offset: 0x00096BCB
		// (set) Token: 0x06001B78 RID: 7032 RVA: 0x000989D3 File Offset: 0x00096BD3
		public string ProtocolSummary
		{
			get
			{
				return this._protocolSummary;
			}
			set
			{
				this._protocolSummary = value;
				this.OnPropertyChanged("ProtocolSummary");
			}
		}

		// Token: 0x170008D0 RID: 2256
		// (get) Token: 0x06001B79 RID: 7033 RVA: 0x000989E9 File Offset: 0x00096BE9
		// (set) Token: 0x06001B7A RID: 7034 RVA: 0x000989F4 File Offset: 0x00096BF4
		public bool AutoRefresh
		{
			get
			{
				return this._autoRefresh;
			}
			set
			{
				bool flag = this._autoRefresh == value;
				if (flag)
				{
					this.SyncMonitorAutoReadState();
				}
				else
				{
					this._autoRefresh = value;
					this.OnPropertyChanged("AutoRefresh");
					this.SyncMonitorAutoReadState();
				}
			}
		}

		// Token: 0x170008D1 RID: 2257
		// (get) Token: 0x06001B7B RID: 7035 RVA: 0x00098A33 File Offset: 0x00096C33
		// (set) Token: 0x06001B7C RID: 7036 RVA: 0x00098A3B File Offset: 0x00096C3B
		public string RefreshInterval
		{
			get
			{
				return this._refreshInterval;
			}
			set
			{
				this._refreshInterval = value;
				this.OnPropertyChanged("RefreshInterval");
			}
		}

		// Token: 0x170008D2 RID: 2258
		// (get) Token: 0x06001B7D RID: 7037 RVA: 0x00098A51 File Offset: 0x00096C51
		// (set) Token: 0x06001B7E RID: 7038 RVA: 0x00098A5C File Offset: 0x00096C5C
		public int ReadCycleMs
		{
			get
			{
				return this._readCycleMs;
			}
			set
			{
				int normalizedValue = Math.Max(10, Math.Min(60000, value));
				bool flag = this._readCycleMs == normalizedValue;
				if (!flag)
				{
					this._readCycleMs = normalizedValue;
					this.OnPropertyChanged("ReadCycleMs");
					this.SetReadCycleText(normalizedValue);
				}
			}
		}

		// Token: 0x170008D3 RID: 2259
		// (get) Token: 0x06001B7F RID: 7039 RVA: 0x00098AA7 File Offset: 0x00096CA7
		// (set) Token: 0x06001B80 RID: 7040 RVA: 0x00098AB0 File Offset: 0x00096CB0
		public string ReadCycleText
		{
			get
			{
				return this._readCycleText;
			}
			set
			{
				bool flag = string.Equals(this._readCycleText, value, StringComparison.Ordinal);
				if (!flag)
				{
					this._readCycleText = value;
					this.OnPropertyChanged("ReadCycleText");
				}
			}
		}

		// Token: 0x170008D4 RID: 2260
		// (get) Token: 0x06001B81 RID: 7041 RVA: 0x00098AE4 File Offset: 0x00096CE4
		// (set) Token: 0x06001B82 RID: 7042 RVA: 0x00098AEC File Offset: 0x00096CEC
		public string MonitorStartAddress
		{
			get
			{
				return this._monitorStartAddress;
			}
			set
			{
				this._monitorStartAddress = value;
				this.OnPropertyChanged("MonitorStartAddress");
			}
		}

		// Token: 0x170008D5 RID: 2261
		// (get) Token: 0x06001B83 RID: 7043 RVA: 0x00098B02 File Offset: 0x00096D02
		// (set) Token: 0x06001B84 RID: 7044 RVA: 0x00098B0A File Offset: 0x00096D0A
		public string MonitorEndAddress
		{
			get
			{
				return this._monitorEndAddress;
			}
			set
			{
				this._monitorEndAddress = value;
				this.OnPropertyChanged("MonitorEndAddress");
			}
		}

		// Token: 0x170008D6 RID: 2262
		// (get) Token: 0x06001B85 RID: 7045 RVA: 0x00098B20 File Offset: 0x00096D20
		// (set) Token: 0x06001B86 RID: 7046 RVA: 0x00098B28 File Offset: 0x00096D28
		public string MonitorDataType
		{
			get
			{
				return this._monitorDataType;
			}
			set
			{
				this._monitorDataType = value;
				this.OnPropertyChanged("MonitorDataType");
			}
		}

		// Token: 0x170008D7 RID: 2263
		// (get) Token: 0x06001B87 RID: 7047 RVA: 0x00098B3E File Offset: 0x00096D3E
		// (set) Token: 0x06001B88 RID: 7048 RVA: 0x00098B46 File Offset: 0x00096D46
		public string MonitorFunctionCode
		{
			get
			{
				return this._monitorFunctionCode;
			}
			set
			{
				this._monitorFunctionCode = value;
				this.OnPropertyChanged("MonitorFunctionCode");
			}
		}

		// Token: 0x06001B89 RID: 7049 RVA: 0x00098B5C File Offset: 0x00096D5C
		private void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x06001B8C RID: 7052 RVA: 0x00099570 File Offset: 0x00097770
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 5:
				((Border)target).MouseLeftButtonDown += this.ConnectionItem_MouseLeftButtonDown;
				break;
			case 6:
				((MenuItem)target).Click += this.ChangeConnectionProtocol_Click;
				break;
			case 7:
				((SimpleButton)target).Click += this.DeleteConnection_Click;
				break;
			}
		}

		// Token: 0x04000B02 RID: 2818
		public const string NoneAddress = "None";

		// Token: 0x04000B03 RID: 2819
		private const string AllCommunicationLogLevels = "All Levels";

		// Token: 0x04000B04 RID: 2820
		private ICollectionView _communicationLogView;

		// Token: 0x04000B05 RID: 2821
		private string _selectedCommunicationLogLevel = "All Levels";

		// Token: 0x04000B07 RID: 2823
		private static readonly string[] CameraTagGroupSuffixes = new string[]
		{
			" - Trigger Camera",
			" - Result Vision Align",
			" - Result Vision Inspection"
		};

		// Token: 0x04000B08 RID: 2824
		private static readonly string[] GeneratedCameraTagNameSuffixes = new string[]
		{
			" trigger snap",
			" trigger run",
			" connected",
			" vision busy",
			" snap complete",
			" run complete",
			" error code",
			" align complete",
			" align result ok",
			" align object count",
			" align x",
			" align y",
			" align degree",
			" align score",
			" align error code",
			" inspection complete",
			" inspection result ok",
			" inspection result ng",
			" inspection ng code",
			" inspection value",
			" inspection total ok",
			" inspection total ng"
		};

		// Token: 0x04000B09 RID: 2825
		public const string ProtocolModbusClientTcp = "Modbus Client TCP/IP";

		// Token: 0x04000B0A RID: 2826
		public const string ProtocolModbusServerTcp = "Modbus Server TCP/IP";

		// Token: 0x04000B0B RID: 2827
		public const string ProtocolOpcUa = "OPC UA";

		// Token: 0x04000B0C RID: 2828
		public const string ProtocolMxComponent = "MX Component";

		// Token: 0x04000B0D RID: 2829
		public const string ProtocolMcProtocol = "MC Protocol";

		// Token: 0x04000B0E RID: 2830
		private readonly PlcCommunicationService _communicationService = SharedCommunicationService.Instance;

		// Token: 0x04000B0F RID: 2831
		private readonly ModbusMonitorService _modbusMonitorService;

		// Token: 0x04000B10 RID: 2832
		private const int MinReadCycleMs = 10;

		// Token: 0x04000B11 RID: 2833
		private const int MonitorReconnectBackoffMs = 3000;

		// Token: 0x04000B12 RID: 2834
		private const int MonitorReconnectTimeoutMs = 500;

		// Token: 0x04000B13 RID: 2835
		private const int OpcHeartbeatUiReadIntervalMs = 200;

		// Token: 0x04000B14 RID: 2836
		private const int OpcHeartbeatUiReadTimeoutMs = 3000;

		// Token: 0x04000B21 RID: 2849
		public const string UnusedTagAddress = "None";

		// Token: 0x04000B2E RID: 2862
		private CommunicationConnection _selectedConnection;

		// Token: 0x04000B2F RID: 2863
		private CommunicationConnection _editingConnection = Form_communication.CreateDefaultEditingConnection();

		// Token: 0x04000B30 RID: 2864
		private string _protocolSummary;

		// Token: 0x04000B31 RID: 2865
		private string _selectedProtocol = "Modbus Client TCP/IP";

		// Token: 0x04000B32 RID: 2866
		private bool _autoRefresh;

		// Token: 0x04000B33 RID: 2867
		private string _refreshInterval = "10";

		// Token: 0x04000B34 RID: 2868
		private int _readCycleMs = 10;

		// Token: 0x04000B35 RID: 2869
		private string _readCycleText = 10.ToString(CultureInfo.InvariantCulture);

		// Token: 0x04000B36 RID: 2870
		private string _monitorStartAddress = "40001";

		// Token: 0x04000B37 RID: 2871
		private string _monitorEndAddress = "40010";

		// Token: 0x04000B38 RID: 2872
		private string _monitorDataType = "UINT16";

		// Token: 0x04000B39 RID: 2873
		private string _monitorFunctionCode = "03 Read Holding Registers";

		// Token: 0x04000B3A RID: 2874
		private bool _initialDataReady;

		// Token: 0x04000B3B RID: 2875
		private bool _pendingCurrentModelReload;

		// Token: 0x04000B3C RID: 2876
		private bool _isPushingEditorValues;

		// Token: 0x04000B3D RID: 2877
		private bool _isRefreshingCameraTriggerOptions;

		// Token: 0x04000B3E RID: 2878
		private bool _ignoreNullSelectionWhileLoading;

		// Token: 0x04000B3F RID: 2879
		private bool _isMonitorReadBusy;

		// Token: 0x04000B40 RID: 2880
		private string _loadedConfigPath;

		// Token: 0x04000B41 RID: 2881
		private string _activeConfigPath;

		// Token: 0x04000B42 RID: 2882
		private string _lastAutoConnectRefreshPath;

		// Token: 0x04000B43 RID: 2883
		private string _cameraTriggerConnectionName = "None";

		// Token: 0x04000B44 RID: 2884
		private CommunicationConnection _monitorReadConnection;

		// Token: 0x04000B45 RID: 2885
		private CancellationTokenSource _monitorReadCancellation;

		// Token: 0x04000B46 RID: 2886
		private Task _monitorReadTask;

		// Token: 0x04000B47 RID: 2887
		private CancellationTokenSource _opcHeartbeatReadCancellation;

		// Token: 0x04000B48 RID: 2888
		private Thread _opcHeartbeatReadThread;

		// Token: 0x04000B49 RID: 2889
		private readonly DispatcherTimer _connectionStatusTimer = new DispatcherTimer();

		// Token: 0x04000B4A RID: 2890
		private readonly DispatcherTimer _opcHeartbeatValueTimer = new DispatcherTimer();

		// Token: 0x04000B4B RID: 2891
		private readonly DispatcherTimer _cameraTagsRefreshTimer = new DispatcherTimer();

		// Token: 0x04000B4C RID: 2892
		private readonly List<CommunicationTagRow> _lastBrowsedOpcTags = new List<CommunicationTagRow>();

		// Token: 0x04000B4D RID: 2893
		private readonly Dictionary<string, List<CommunicationTagRow>> _tagsByConnection = new Dictionary<string, List<CommunicationTagRow>>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000B4E RID: 2894
		private readonly Dictionary<string, List<CommunicationInitialValueRow>> _initialValuesByConnection = new Dictionary<string, List<CommunicationInitialValueRow>>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000B4F RID: 2895
		private readonly Dictionary<string, CommunicationHealthState> _latestConnectionHealthStates = new Dictionary<string, CommunicationHealthState>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000B50 RID: 2896
		private readonly HashSet<string> _autoBrowsedOpcConnections = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000B51 RID: 2897
		private bool _isSwitchingConnectionTags;

		// Token: 0x04000B52 RID: 2898
		private bool _isAutoBrowsingOpcTags;

		// Token: 0x04000B53 RID: 2899
		private bool _isOpcHeartbeatValueReadBusy;

		// Token: 0x04000B54 RID: 2900
		private DateTime _lastOpcHeartbeatDirectUpdateUtc = DateTime.MinValue;

		// Token: 0x04000B55 RID: 2901
		private string _lastOpcHeartbeatErrorMessage;

		// Token: 0x04000B56 RID: 2902
		private DateTime _lastOpcHeartbeatErrorLogUtc = DateTime.MinValue;

		// Token: 0x020003E5 RID: 997
		private sealed class OpcHeartbeatMonitorSource
		{
			// Token: 0x17000B6E RID: 2926
			// (get) Token: 0x06002A4C RID: 10828 RVA: 0x000E57B5 File Offset: 0x000E39B5
			// (set) Token: 0x06002A4D RID: 10829 RVA: 0x000E57BD File Offset: 0x000E39BD
			public CommunicationConnection Connection { get; set; }

			// Token: 0x17000B6F RID: 2927
			// (get) Token: 0x06002A4E RID: 10830 RVA: 0x000E57C6 File Offset: 0x000E39C6
			// (set) Token: 0x06002A4F RID: 10831 RVA: 0x000E57CE File Offset: 0x000E39CE
			public CommunicationTagRow HeartbeatTag { get; set; }
		}

		// Token: 0x020003E6 RID: 998
		private sealed class MonitorReadRequest
		{
			// Token: 0x17000B70 RID: 2928
			// (get) Token: 0x06002A51 RID: 10833 RVA: 0x000E57D7 File Offset: 0x000E39D7
			// (set) Token: 0x06002A52 RID: 10834 RVA: 0x000E57DF File Offset: 0x000E39DF
			public bool UseOpcTags { get; set; }

			// Token: 0x17000B71 RID: 2929
			// (get) Token: 0x06002A53 RID: 10835 RVA: 0x000E57E8 File Offset: 0x000E39E8
			// (set) Token: 0x06002A54 RID: 10836 RVA: 0x000E57F0 File Offset: 0x000E39F0
			public string StartAddress { get; set; }

			// Token: 0x17000B72 RID: 2930
			// (get) Token: 0x06002A55 RID: 10837 RVA: 0x000E57F9 File Offset: 0x000E39F9
			// (set) Token: 0x06002A56 RID: 10838 RVA: 0x000E5801 File Offset: 0x000E3A01
			public string EndAddress { get; set; }

			// Token: 0x17000B73 RID: 2931
			// (get) Token: 0x06002A57 RID: 10839 RVA: 0x000E580A File Offset: 0x000E3A0A
			// (set) Token: 0x06002A58 RID: 10840 RVA: 0x000E5812 File Offset: 0x000E3A12
			public string DataType { get; set; }

			// Token: 0x17000B74 RID: 2932
			// (get) Token: 0x06002A59 RID: 10841 RVA: 0x000E581B File Offset: 0x000E3A1B
			// (set) Token: 0x06002A5A RID: 10842 RVA: 0x000E5823 File Offset: 0x000E3A23
			public string FunctionCode { get; set; }

			// Token: 0x17000B75 RID: 2933
			// (get) Token: 0x06002A5B RID: 10843 RVA: 0x000E582C File Offset: 0x000E3A2C
			// (set) Token: 0x06002A5C RID: 10844 RVA: 0x000E5834 File Offset: 0x000E3A34
			public List<CommunicationTagRow> Tags { get; set; }
		}

		// Token: 0x020003E7 RID: 999
		private sealed class MonitorReadExecution
		{
			// Token: 0x17000B76 RID: 2934
			// (get) Token: 0x06002A5E RID: 10846 RVA: 0x000E583D File Offset: 0x000E3A3D
			// (set) Token: 0x06002A5F RID: 10847 RVA: 0x000E5845 File Offset: 0x000E3A45
			public CommunicationOperationResult ConnectResult { get; set; }

			// Token: 0x17000B77 RID: 2935
			// (get) Token: 0x06002A60 RID: 10848 RVA: 0x000E584E File Offset: 0x000E3A4E
			// (set) Token: 0x06002A61 RID: 10849 RVA: 0x000E5856 File Offset: 0x000E3A56
			public CommunicationReadResult ReadResult { get; set; }
		}
	}
}
