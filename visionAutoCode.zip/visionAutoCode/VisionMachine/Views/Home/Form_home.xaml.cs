﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Docking;
using DevExpress.Xpf.Editors;
using HalconDotNet;
using Microsoft.Win32;
using VisionMachine.Controls.Camera;
using VisionMachine.Controls.Common;
using VisionMachine.Controls.Home;
using VisionMachine.Helpers;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Light;
using VisionMachine.Models.Recipe;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.Services;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Communication;
using VisionMachine.Services.Light;
using VisionMachine.Services.Runtime;
using VisionMachine.Services.Storage;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Main;
using VisionMachine.Views.Model;
using VisionMachine.Views.Setting.Controllers;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.Blob;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CalibHandEye;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.CountBoundingBox;
using VisionMachine.VisionTools.DeformableInspection;
using VisionMachine.VisionTools.DistanceObject;
using VisionMachine.VisionTools.DLObjectInspection;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;
using VisionMachine.VisionTools.FindRedArrow;
using VisionMachine.VisionTools.Histogram;
using VisionMachine.VisionTools.HistogramColor;
using VisionMachine.VisionTools.ImageFilter;
using VisionMachine.VisionTools.ImageTransform;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MatrixCode;
using VisionMachine.VisionTools.MeasureCircle;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ProcedureInspection;
using VisionMachine.VisionTools.ProductCountInspection;
using VisionMachine.VisionTools.ResultAlign;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.Runtime;
using VisionMachine.VisionTools.SaveImage;
using VisionMachine.VisionTools.ShapeModel;
using VisionMachine.VisionTools.VariationChangeWD;
using VisionMachine.VisionTools.VariationModel;

namespace VisionMachine.Views.Home
{
	// Token: 0x020001C1 RID: 449
	public partial class Form_home : ThemedWindow, IStyleConnector
	{
		// Token: 0x170008B0 RID: 2224
		// (get) Token: 0x06001A20 RID: 6688 RVA: 0x00088E20 File Offset: 0x00087020
		// (set) Token: 0x06001A21 RID: 6689 RVA: 0x00088E55 File Offset: 0x00087055
		public static Form_home Instance
		{
			get
			{
				bool flag = Form_home._instance != null;
				Form_home instance;
				if (flag)
				{
					instance = Form_home._instance;
				}
				else
				{
					Form_home._instance = Form_home.ResolveHomeFromMainWindow();
					instance = Form_home._instance;
				}
				return instance;
			}
			private set
			{
				Form_home._instance = value;
			}
		}

		// Token: 0x06001A22 RID: 6690 RVA: 0x00088E60 File Offset: 0x00087060
		public Form_home()
		{
			this.InitializeComponent();
			Form_home.Instance = this;
			base.Loaded += this.FormHome_Loaded;
			base.DataContext = MainWindow.instance.MainViewModel;
			this._homeStatusTimer.Interval = TimeSpan.FromMilliseconds(500.0);
			this._homeStatusTimer.Tick += this.HomeStatusTimer_Tick;
			this.UpdateHomeConnectionStatus(null);
			this._homeStatusTimer.Start();
			this.load_layout_Camera();
			this.RefreshModelInfo();
			base.Dispatcher.BeginInvoke(new Action(this.StartCameraBadgeTimer), DispatcherPriority.Loaded, Array.Empty<object>());
		}

		// Token: 0x06001A23 RID: 6691 RVA: 0x00088FDC File Offset: 0x000871DC
		private static Form_home ResolveHomeFromMainWindow()
		{
			MainWindow main = MainWindow.instance;
			bool flag = main == null;
			Form_home result;
			if (flag)
			{
				result = null;
			}
			else
			{
				Dispatcher dispatcher2;
				if ((dispatcher2 = main.Dispatcher) == null)
				{
					Application application = Application.Current;
					dispatcher2 = ((application != null) ? application.Dispatcher : null);
				}
				Dispatcher dispatcher = dispatcher2;
				bool flag2 = dispatcher != null && !dispatcher.CheckAccess();
				if (flag2)
				{
					result = Form_home._instance;
				}
				else
				{
					result = Form_home.FindVisualOrLogicalChild<Form_home>(main);
				}
			}
			return result;
		}

		// Token: 0x06001A24 RID: 6692 RVA: 0x00089040 File Offset: 0x00087240
		private static T FindVisualOrLogicalChild<T>(DependencyObject parent) where T : DependencyObject
		{
			bool flag = parent == null;
			T result;
			if (flag)
			{
				result = default(T);
			}
			else
			{
				T target = parent as T;
				bool flag2 = target != null;
				if (flag2)
				{
					result = target;
				}
				else
				{
					int visualCount = 0;
					try
					{
						visualCount = VisualTreeHelper.GetChildrenCount(parent);
					}
					catch
					{
					}
					for (int i = 0; i < visualCount; i++)
					{
						DependencyObject child = VisualTreeHelper.GetChild(parent, i);
						T found = Form_home.FindVisualOrLogicalChild<T>(child);
						bool flag3 = found != null;
						if (flag3)
						{
							return found;
						}
					}
					foreach (object logicalChild in LogicalTreeHelper.GetChildren(parent))
					{
						DependencyObject child2 = logicalChild as DependencyObject;
						T found2 = Form_home.FindVisualOrLogicalChild<T>(child2);
						bool flag4 = found2 != null;
						if (flag4)
						{
							return found2;
						}
					}
					result = default(T);
				}
			}
			return result;
		}

		// Token: 0x06001A25 RID: 6693 RVA: 0x00089170 File Offset: 0x00087370
		private void FormHome_Loaded(object sender, RoutedEventArgs e)
		{
			Form_home.Instance = this;
			MainWindow instance = MainWindow.instance;
			base.DataContext = ((instance != null) ? instance.MainViewModel : null);
			this.RefreshModelInfo();
			this.EnsureCameraDisplaysInitialized();
			bool flag = !this._homeReadyLogged;
			if (flag)
			{
				this._homeReadyLogged = true;
			}
			this.UpdateHomeConnectionStatus(null);
			this._homeStatusTimer.Start();
			this.StartCameraBadgeTimer();
			this.FlushPendingCameraTriggerMessages();
		}

		// Token: 0x06001A26 RID: 6694 RVA: 0x000891EC File Offset: 0x000873EC
		private void StartCameraBadgeTimer()
		{
			bool flag = this._cameraBadgeTimer != null;
			if (!flag)
			{
				this._cameraBadgeTimer = new DispatcherTimer
				{
					Interval = TimeSpan.FromMilliseconds(500.0)
				};
				CameraConnectionMonitorService.EnsureStarted();
				this._cameraBadgeTimer.Tick += delegate(object s, EventArgs e)
				{
					this.UpdateCameraConnectionBadges();
				};
				this._cameraBadgeTimer.Start();
				this.UpdateCameraConnectionBadges();
			}
		}

		// Token: 0x06001A27 RID: 6695 RVA: 0x0008925A File Offset: 0x0008745A
		public void PrepareCameraTriggerRuntime()
		{
			Form_home.Instance = this;
			MainWindow instance = MainWindow.instance;
			base.DataContext = ((instance != null) ? instance.MainViewModel : null);
			this.RefreshModelInfo();
			this.EnsureCameraDisplaysInitialized();
			this.RefreshHardwareTriggerCameras();
			this.FlushPendingCameraTriggerMessages();
		}

		// Token: 0x06001A28 RID: 6696 RVA: 0x00089298 File Offset: 0x00087498
		public void RefreshHardwareTriggerCameras()
		{
			this.EnsureCameraDisplaysInitialized();
			HashSet<string> enabledCameraNames = new HashSet<string>(from name in this._cameraStates.Values.Where(delegate(Form_home.HomeCameraDockState state)
			{
				bool flag4;
				if (state == null)
				{
					flag4 = (null != null);
				}
				else
				{
					CameraNode camera2 = state.Camera;
					flag4 = (((camera2 != null) ? camera2.CameraConfig : null) != null);
				}
				return flag4 && state.Camera.CameraConfig.HardwareTrigger;
			}).Select(delegate(Form_home.HomeCameraDockState state)
			{
				string result;
				if ((result = state.CameraName) == null)
				{
					CameraNode camera2 = state.Camera;
					result = ((camera2 != null) ? camera2.Name : null);
				}
				return result;
			})
			where !string.IsNullOrWhiteSpace(name)
			select name, StringComparer.OrdinalIgnoreCase);
			foreach (string cameraName in this._hardwareTriggerServices.Keys.ToList<string>())
			{
				bool flag = enabledCameraNames.Contains(cameraName);
				if (!flag)
				{
					this.StopHardwareTriggerCamera(cameraName);
				}
			}
			foreach (Form_home.HomeCameraDockState state2 in this._cameraStates.Values.ToList<Form_home.HomeCameraDockState>())
			{
				bool flag2;
				if (state2 == null)
				{
					flag2 = (null != null);
				}
				else
				{
					CameraNode camera = state2.Camera;
					flag2 = (((camera != null) ? camera.CameraConfig : null) != null);
				}
				bool flag3 = !flag2 || !state2.Camera.CameraConfig.HardwareTrigger;
				if (!flag3)
				{
					this.StartHardwareTriggerCamera(state2);
				}
			}
		}

		// Token: 0x06001A29 RID: 6697 RVA: 0x00089424 File Offset: 0x00087624
		private void StartHardwareTriggerCamera(Form_home.HomeCameraDockState state)
		{
			Form_home.<>c__DisplayClass33_0 CS$<>8__locals1 = new Form_home.<>c__DisplayClass33_0();
			CS$<>8__locals1.<>4__this = this;
			Form_home.<>c__DisplayClass33_0 CS$<>8__locals2 = CS$<>8__locals1;
			string cameraName;
			if ((cameraName = ((state != null) ? state.CameraName : null)) == null)
			{
				if (state == null)
				{
					cameraName = null;
				}
				else
				{
					CameraNode camera = state.Camera;
					cameraName = ((camera != null) ? camera.Name : null);
				}
			}
			CS$<>8__locals2.cameraName = cameraName;
			Form_home.<>c__DisplayClass33_0 CS$<>8__locals3 = CS$<>8__locals1;
			CameraParameterConfig config;
			if (state == null)
			{
				config = null;
			}
			else
			{
				CameraNode camera2 = state.Camera;
				config = ((camera2 != null) ? camera2.CameraConfig : null);
			}
			CS$<>8__locals3.config = config;
			bool flag;
			if (!string.IsNullOrWhiteSpace(CS$<>8__locals1.cameraName) && CS$<>8__locals1.config != null && !string.IsNullOrWhiteSpace(CS$<>8__locals1.config.ConnectedCameraId))
			{
				CameraDockItem dock = state.Dock;
				flag = (((dock != null) ? dock.HWindowControl : null) == null);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (!flag2)
			{
				bool flag3 = this._hardwareTriggerServices.ContainsKey(CS$<>8__locals1.cameraName) || this._hardwareTriggerServiceStarting.Contains(CS$<>8__locals1.cameraName) || CameraHardwareRuntimeService.IsRegistered(CS$<>8__locals1.config.ConnectedCameraId);
				if (!flag3)
				{
					bool flag4 = !Form_home.IsCameraSerialConnected(CS$<>8__locals1.config.ConnectedCameraId);
					if (flag4)
					{
						this.AddHomeLog("Warn", string.Concat(new string[]
						{
							"Hardware trigger camera is not connected, skipped. Camera=",
							CS$<>8__locals1.cameraName,
							" (serial ",
							CS$<>8__locals1.config.ConnectedCameraId,
							")."
						}));
					}
					else
					{
						CS$<>8__locals1.service = Form_home.CreateLiveService(CS$<>8__locals1.config);
						bool flag5 = CS$<>8__locals1.service == null;
						if (!flag5)
						{
							this._hardwareTriggerServiceStarting.Add(CS$<>8__locals1.cameraName);
							CS$<>8__locals1.display = state.Dock.HWindowControl;
							Task.Run(delegate()
							{
								string error = null;
								try
								{
									Form_home.StartLiveService(CS$<>8__locals1.service, CS$<>8__locals1.config, CS$<>8__locals1.display);
								}
								catch (Exception ex)
								{
									error = ex.Message;
								}
								CS$<>8__locals1.<>4__this.Dispatcher.BeginInvoke(new Action(delegate()
								{
									CS$<>8__locals1.<>4__this._hardwareTriggerServiceStarting.Remove(CS$<>8__locals1.cameraName);
									bool flag6 = error != null;
									if (flag6)
									{
										try
										{
											CS$<>8__locals1.service.Dispose();
										}
										catch
										{
										}
										CS$<>8__locals1.<>4__this.AddHomeLog("Error", "Hardware trigger camera start failed. Camera=" + CS$<>8__locals1.cameraName + ", Error=" + error);
									}
									else
									{
										CS$<>8__locals1.<>4__this._hardwareTriggerServices[CS$<>8__locals1.cameraName] = CS$<>8__locals1.service;
										CS$<>8__locals1.<>4__this.AddHomeLog("Info", "Hardware trigger camera ready. Camera=" + CS$<>8__locals1.cameraName);
									}
								}), Array.Empty<object>());
							});
						}
					}
				}
			}
		}

		// Token: 0x06001A2A RID: 6698 RVA: 0x000895D0 File Offset: 0x000877D0
		private static bool IsCameraSerialConnected(string serial)
		{
			bool flag = string.IsNullOrWhiteSpace(serial);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				MainWindow instance = MainWindow.instance;
				ObservableCollection<ConnectedCameraInfo> observableCollection;
				if (instance == null)
				{
					observableCollection = null;
				}
				else
				{
					MainViewModel mainViewModel = instance.MainViewModel;
					observableCollection = ((mainViewModel != null) ? mainViewModel.ConnectedCameras : null);
				}
				ObservableCollection<ConnectedCameraInfo> connected = observableCollection;
				bool flag2 = connected == null || connected.Count == 0;
				result = (flag2 || connected.Any((ConnectedCameraInfo x) => x != null && x.Id == serial));
			}
			return result;
		}

		// Token: 0x06001A2B RID: 6699 RVA: 0x0008964C File Offset: 0x0008784C
		private void StopHardwareTriggerCamera(string cameraName)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraName);
			if (!flag)
			{
				IDisposable service;
				bool flag2 = !this._hardwareTriggerServices.TryGetValue(cameraName, out service);
				if (!flag2)
				{
					this._hardwareTriggerServices.Remove(cameraName);
					try
					{
						service.Dispose();
					}
					catch
					{
					}
					this.AddHomeLog("Info", "Hardware trigger camera stopped. Camera=" + cameraName);
				}
			}
		}

		// Token: 0x06001A2C RID: 6700 RVA: 0x000896C4 File Offset: 0x000878C4
		private void StopHardwareTriggerCameras()
		{
			foreach (string cameraName in this._hardwareTriggerServices.Keys.ToList<string>())
			{
				this.StopHardwareTriggerCamera(cameraName);
			}
		}

		// Token: 0x06001A2D RID: 6701 RVA: 0x00089728 File Offset: 0x00087928
		private static IDisposable CreateLiveService(CameraParameterConfig config)
		{
			bool flag = config == null;
			IDisposable result;
			if (flag)
			{
				result = null;
			}
			else
			{
				CameraVendor vendor = config.Vendor;
				CameraVendor cameraVendor = vendor;
				if (cameraVendor != CameraVendor.Basler)
				{
					if (cameraVendor != CameraVendor.Hikvision)
					{
						result = null;
					}
					else
					{
						result = new HikLiveCameraService();
					}
				}
				else
				{
					result = new BaslerLiveCameraService();
				}
			}
			return result;
		}

		// Token: 0x06001A2E RID: 6702 RVA: 0x0008976C File Offset: 0x0008796C
		private static void StartLiveService(IDisposable service, CameraParameterConfig config, HSmartWindowControlWPF display)
		{
			if (service != null)
			{
				MethodInfo method = service.GetType().GetMethod("Start");
				if (method != null)
				{
					method.Invoke(service, new object[]
					{
						config,
						display
					});
				}
			}
		}

		// Token: 0x06001A2F RID: 6703 RVA: 0x000897A0 File Offset: 0x000879A0
		private void EnsureCameraDisplaysInitialized()
		{
			ObservableCollection<CameraItem> cameras = CameraRuntimeStore.Cameras;
			int expectedCameraCount = (cameras != null) ? cameras.Count : 0;
			bool requiresInitialization = this._cameraDocks.Count != expectedCameraCount || this._cameraStates.Count != expectedCameraCount;
			bool flag = !requiresInitialization;
			if (flag)
			{
				using (IEnumerator<CameraItem> enumerator = CameraRuntimeStore.Cameras.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						CameraItem camera = enumerator.Current;
						bool flag2 = camera == null || !this._cameraStates.Values.Any((Form_home.HomeCameraDockState state) => state != null && Form_home.IsSameCameraName(state.CameraName, camera.CameraName));
						if (flag2)
						{
							requiresInitialization = true;
							break;
						}
					}
				}
			}
			bool flag3 = requiresInitialization;
			if (flag3)
			{
				this.load_layout_Camera();
			}
		}

		// Token: 0x06001A30 RID: 6704 RVA: 0x0008987C File Offset: 0x00087A7C
		private void HomeStatusTimer_Tick(object sender, EventArgs e)
		{
			this.UpdateHomeConnectionStatus(null);
			this.UpdateCameraConnectionBadges();
		}

		// Token: 0x06001A31 RID: 6705 RVA: 0x000898A4 File Offset: 0x00087AA4
		private void UpdateCameraConnectionBadges()
		{
			foreach (KeyValuePair<object, Form_home.HomeCameraDockState> pair in this._cameraStates)
			{
				CameraDockView view = pair.Key as CameraDockView;
				Form_home.HomeCameraDockState state = pair.Value;
				bool flag = view == null;
				if (!flag)
				{
					try
					{
						bool connected = Form_home.IsCameraDockConnected(state);
						view.SetConnectionState(connected);
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x06001A32 RID: 6706 RVA: 0x00089940 File Offset: 0x00087B40
		private static bool IsCameraDockConnected(Form_home.HomeCameraDockState state)
		{
			string text;
			if (state == null)
			{
				text = null;
			}
			else
			{
				CameraNode camera = state.Camera;
				if (camera == null)
				{
					text = null;
				}
				else
				{
					CameraParameterConfig cameraConfig = camera.CameraConfig;
					text = ((cameraConfig != null) ? cameraConfig.ConnectedCameraId : null);
				}
			}
			string serial = text;
			bool flag = string.IsNullOrWhiteSpace(serial);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool? live = CameraHardwareRuntimeService.TryGetLiveConnectionState(serial);
				bool valueOrDefault = live.GetValueOrDefault();
				if (valueOrDefault)
				{
					result = true;
				}
				else
				{
					bool monitored;
					bool flag2 = CameraConnectionMonitorService.TryGetConnected((state != null) ? state.CameraName : null, out monitored);
					if (flag2)
					{
						result = monitored;
					}
					else
					{
						bool flag3 = live != null;
						result = (flag3 && live.Value);
					}
				}
			}
			return result;
		}

		// Token: 0x06001A33 RID: 6707 RVA: 0x000899DC File Offset: 0x00087BDC
		public void UpdateHomeConnectionStatus(bool? plcConnectedOverride = null)
		{
			bool plcConnected = plcConnectedOverride ?? CameraTriggerCommunicationService.IsActiveConnectionConnected();
			string plcName = CameraTriggerCommunicationService.GetActiveConnectionName();
			bool hasCamera = CameraRuntimeStore.Cameras != null && CameraRuntimeStore.Cameras.Count > 0;
			string plcText = plcConnected ? ("PLC: Connected" + (string.IsNullOrWhiteSpace(plcName) ? string.Empty : (" (" + plcName + ")"))) : "PLC: Disconnected";
			bool flag = this.ConnectionStatusText != null;
			if (flag)
			{
				this.ConnectionStatusText.Text = plcText + " | CAM: " + (hasCamera ? "OK" : "None");
				this.ConnectionStatusText.Foreground = (plcConnected ? new SolidColorBrush(Color.FromRgb(148, 163, 184)) : new SolidColorBrush(Color.FromRgb(248, 113, 113)));
			}
			bool flag2 = this.SystemStatusText != null;
			if (flag2)
			{
				this.SystemStatusText.Text = (plcConnected ? "SYSTEM READY" : "SYSTEM NOT READY");
				this.SystemStatusText.Foreground = (plcConnected ? new SolidColorBrush(Color.FromRgb(34, 197, 94)) : new SolidColorBrush(Color.FromRgb(248, 113, 113)));
			}
			bool flag3 = this.SystemStatusIndicator != null;
			if (flag3)
			{
				this.SystemStatusIndicator.Fill = (plcConnected ? new SolidColorBrush(Color.FromRgb(34, 197, 94)) : new SolidColorBrush(Color.FromRgb(248, 113, 113)));
			}
		}

		// Token: 0x06001A34 RID: 6708 RVA: 0x00089B76 File Offset: 0x00087D76
		public void load_layout_Camera()
		{
			this.DisposeCameraStates();
			CameraDockFactory.CreateCameraDocks(this.rootGroup, this._cameraDocks);
			this.ConfigureCameraDocks();
		}

		// Token: 0x06001A35 RID: 6709 RVA: 0x00089B99 File Offset: 0x00087D99
		public void RefreshCameraLayout()
		{
			this.load_layout_Camera();
		}

		// Token: 0x06001A36 RID: 6710 RVA: 0x00089BA4 File Offset: 0x00087DA4
		public void RefreshModelInfo()
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			if (vm != null)
			{
				vm.SyncModelsFromRuntimeStore();
			}
		}

		// Token: 0x06001A37 RID: 6711 RVA: 0x00089BD0 File Offset: 0x00087DD0
		private void ModelListItem_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
		{
			FrameworkElement frameworkElement = sender as FrameworkElement;
			this._rightClickedModel = (((frameworkElement != null) ? frameworkElement.DataContext : null) as ModelConfig);
			bool flag = this._rightClickedModel == null;
			if (!flag)
			{
				ComboBoxEdit comboBoxEdit = this.cbModel;
				bool flag2 = ((comboBoxEdit != null) ? comboBoxEdit.ContextMenu : null) != null;
				if (flag2)
				{
					this.cbModel.ContextMenu.PlacementTarget = this.cbModel;
					this.cbModel.ContextMenu.IsOpen = true;
				}
				e.Handled = true;
			}
		}

		// Token: 0x06001A38 RID: 6712 RVA: 0x00089C58 File Offset: 0x00087E58
		private void RenameModel_Click(object sender, RoutedEventArgs e)
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			bool flag = vm == null;
			if (!flag)
			{
				ModelConfig model = this._rightClickedModel ?? vm.CurrentModel;
				this._rightClickedModel = null;
				bool flag2 = model == null;
				if (flag2)
				{
					DXMessageBox.Show("Please select a model to rename.", "Rename Model", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				}
				else
				{
					Window owner = Window.GetWindow(this);
					bool flag3 = !ModelRenameHelper.PromptAndRename(owner, model, ModelRuntimeStore.Models);
					if (!flag3)
					{
						ModelStorageService.Save(Manager_path._modelJsonPath, ModelRuntimeStore.Models, ModelRuntimeStore.CurrentModel);
						bool flag4 = model == ModelRuntimeStore.CurrentModel;
						if (flag4)
						{
							try
							{
								new SettingRecipeService().LoadCurrentModelRecipe();
							}
							catch (Exception ex)
							{
								this.AddHomeLog("Warn", "Recipe reload after rename failed: " + ex.Message);
							}
						}
						this.RefreshModelInfo();
					}
				}
			}
		}

		// Token: 0x06001A39 RID: 6713 RVA: 0x00089D4C File Offset: 0x00087F4C
		public void SwitchModel(ModelConfig model)
		{
			bool flag = model == null;
			if (!flag)
			{
				ModelConfig activeModel = ModelRuntimeStore.CurrentModel;
				bool flag2 = activeModel != null && activeModel.Id == model.Id;
				if (!flag2)
				{
					bool isSwitchingModel = this._isSwitchingModel;
					if (!isSwitchingModel)
					{
						MainWindow instance = MainWindow.instance;
						MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
						bool flag3 = vm == null;
						if (!flag3)
						{
							this._isSwitchingModel = true;
							try
							{
								ModelRuntimeStore.SetCurrentModel(model);
								ModelStorageService.Save(Manager_path._modelJsonPath, ModelRuntimeStore.Models.ToList<ModelConfig>(), model);
								CameraModelConfigStorageService.LoadCurrentModelConfig(vm);
								this.RefreshHardwareTriggerCameras();
								CameraStartupApplyService.ApplyCurrentModelAsync(vm, "Home model changed", 800);
								LightModelConfigStorageService.LoadCurrentModelConfig(vm);
								LightStartupApplyService.ApplyCurrentModelAsync(vm, "Home model changed", 500);
								this._recipeService.LoadCurrentModelRecipe();
								ToolRuntimePreloadService.PreloadFromCameras(vm.Cameras);
								vm.SyncCamerasFromRuntimeStorePreserveTurns();
								vm.RefreshConnectedCameras();
								vm.RefreshConnectedLights();
								vm.SyncModelsFromRuntimeStore();
								Task.Run(delegate()
								{
									CameraTriggerCommunicationService.StartCurrentModel(null, true);
								});
								this.AddHomeLog("Info", "Model changed to '" + model.Model_name + "'.");
							}
							catch (Exception ex)
							{
								this.AddHomeLog("Error", "Switch model failed: " + ex.Message);
								DXMessageBox.Show("Switch model failed: " + ex.Message, "Model");
							}
							finally
							{
								this._isSwitchingModel = false;
							}
						}
					}
				}
			}
		}

		// Token: 0x06001A3A RID: 6714 RVA: 0x00089F18 File Offset: 0x00088118
		private void ConfigureCameraDocks()
		{
			foreach (CameraDockItem dock in this._cameraDocks)
			{
				bool flag = ((dock != null) ? dock.View : null) == null || dock.HWindowControl == null;
				if (!flag)
				{
					LayoutPanel panel = dock.Panel;
					string cameraName = Convert.ToString((panel != null) ? panel.Caption : null);
					CameraNode camera = this.FindCameraNode(cameraName, dock.CameraIndex);
					Form_home.HomeCameraDockState state = new Form_home.HomeCameraDockState
					{
						Dock = dock,
						Camera = camera,
						CameraName = cameraName,
						DisplayController = new SettingDisplayController(dock.HWindowControl)
						{
							UseBufferedRedraw = true
						}
					};
					TurnSnap savedTurnSnap;
					bool flag2;
					if (!string.IsNullOrWhiteSpace(cameraName) && this._selectedTurnSnapByCamera.TryGetValue(cameraName, out savedTurnSnap))
					{
						if (camera == null)
						{
							flag2 = false;
						}
						else
						{
							ObservableCollection<TurnSnap> turnSnaps = camera.TurnSnaps;
							flag2 = ((turnSnaps != null) ? new bool?(turnSnaps.Contains(savedTurnSnap)) : null).GetValueOrDefault();
						}
					}
					else
					{
						flag2 = false;
					}
					bool flag3 = flag2;
					if (flag3)
					{
						state.SelectedTurnSnap = savedTurnSnap;
					}
					else
					{
						Form_home.HomeCameraDockState homeCameraDockState = state;
						object obj;
						if (camera == null)
						{
							obj = null;
						}
						else
						{
							ObservableCollection<TurnSnap> turnSnaps2 = camera.TurnSnaps;
							if (turnSnaps2 == null)
							{
								obj = null;
							}
							else
							{
								obj = turnSnaps2.FirstOrDefault((TurnSnap x) => x.IsSelected);
							}
						}
						object selectedTurnSnap;
						if ((selectedTurnSnap = obj) == null)
						{
							if (camera == null)
							{
								selectedTurnSnap = null;
							}
							else
							{
								ObservableCollection<TurnSnap> turnSnaps3 = camera.TurnSnaps;
								selectedTurnSnap = ((turnSnaps3 != null) ? turnSnaps3.FirstOrDefault<TurnSnap>() : null);
							}
						}
						homeCameraDockState.SelectedTurnSnap = selectedTurnSnap;
					}
					this._cameraStates[dock.View] = state;
					dock.HWindowControl.Tag = state;
					dock.View.HomeHost = this;
					dock.View.OpenRequested += this.CameraDock_OpenRequested;
					dock.View.RunRequested += this.CameraDock_RunRequested;
					dock.View.SettingRequested += this.CameraDock_SettingRequested;
					dock.HWindowControl.AddHandler(UIElement.PreviewMouseWheelEvent, new MouseWheelEventHandler(this.HomeHWindow_MouseWheel), true);
					dock.HWindowControl.AddHandler(UIElement.PreviewMouseMoveEvent, new MouseEventHandler(this.HomeHWindow_MouseMove), true);
					dock.HWindowControl.AddHandler(UIElement.PreviewMouseDownEvent, new MouseButtonEventHandler(this.HomeHWindow_MouseDown), true);
					dock.HWindowControl.AddHandler(UIElement.PreviewMouseUpEvent, new MouseButtonEventHandler(this.HomeHWindow_MouseUp), true);
					dock.HWindowControl.AddHandler(Control.PreviewMouseDoubleClickEvent, new MouseButtonEventHandler(this.HomeHWindow_MouseDoubleClick), true);
					dock.HWindowControl.AddHandler(UIElement.MouseLeaveEvent, new MouseEventHandler(this.HomeHWindow_MouseLeave), true);
					dock.HWindowControl.SizeChanged += this.HomeHWindow_SizeChanged;
				}
			}
		}

		// Token: 0x06001A3B RID: 6715 RVA: 0x0008A200 File Offset: 0x00088400
		private void CameraDock_OpenRequested(object sender, EventArgs e)
		{
			this.OpenImageFromCameraDock(sender);
		}

		// Token: 0x06001A3C RID: 6716 RVA: 0x0008A20B File Offset: 0x0008840B
		private void CameraDock_RunRequested(object sender, EventArgs e)
		{
			this.RunTurnSnapFromCameraDock(sender);
		}

		// Token: 0x06001A3D RID: 6717 RVA: 0x0008A216 File Offset: 0x00088416
		private void CameraDock_SettingRequested(object sender, EventArgs e)
		{
			this.ShowSettingFromCameraDock(sender);
		}

		// Token: 0x06001A3E RID: 6718 RVA: 0x0008A224 File Offset: 0x00088424
		private CameraNode FindCameraNode(string cameraName, int cameraIndex)
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			bool flag = ((vm != null) ? vm.Cameras : null) == null;
			CameraNode result;
			if (flag)
			{
				result = null;
			}
			else
			{
				CameraNode byName = string.IsNullOrWhiteSpace(cameraName) ? null : vm.Cameras.FirstOrDefault(delegate(CameraNode x)
				{
					bool result2;
					if (!string.Equals(x.Name, cameraName, StringComparison.OrdinalIgnoreCase))
					{
						CameraItem cameraInfo = x.CameraInfo;
						result2 = string.Equals((cameraInfo != null) ? cameraInfo.CameraName : null, cameraName, StringComparison.OrdinalIgnoreCase);
					}
					else
					{
						result2 = true;
					}
					return result2;
				});
				bool flag2 = byName != null;
				if (flag2)
				{
					result = byName;
				}
				else
				{
					result = vm.Cameras.FirstOrDefault((CameraNode x) => x.Index == cameraIndex);
				}
			}
			return result;
		}

		// Token: 0x06001A3F RID: 6719 RVA: 0x0008A2C4 File Offset: 0x000884C4
		private Form_home.HomeCameraDockState GetStateFromView(object sender)
		{
			FrameworkElement element = sender as FrameworkElement;
			Form_home.HomeCameraDockState taggedState;
			bool flag;
			if (element != null)
			{
				taggedState = (element.Tag as Form_home.HomeCameraDockState);
				flag = (taggedState != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			Form_home.HomeCameraDockState result;
			if (flag2)
			{
				bool flag3 = taggedState.Camera == null;
				if (flag3)
				{
					taggedState.Camera = this.FindCameraNode(taggedState.CameraName, (taggedState.Dock == null) ? 0 : taggedState.Dock.CameraIndex);
				}
				result = taggedState;
			}
			else
			{
				Form_home.HomeCameraDockState state;
				bool flag4 = sender != null && this._cameraStates.TryGetValue(sender, out state);
				if (flag4)
				{
					bool flag5 = state.Camera == null;
					if (flag5)
					{
						state.Camera = this.FindCameraNode(state.CameraName, (state.Dock == null) ? 0 : state.Dock.CameraIndex);
					}
					result = state;
				}
				else
				{
					CameraDockItem dock = this._cameraDocks.FirstOrDefault((CameraDockItem x) => x.View == sender);
					bool flag6 = dock != null;
					if (flag6)
					{
						Form_home.HomeCameraDockState homeCameraDockState = new Form_home.HomeCameraDockState();
						homeCameraDockState.Dock = dock;
						LayoutPanel panel = dock.Panel;
						homeCameraDockState.CameraName = Convert.ToString((panel != null) ? panel.Caption : null);
						LayoutPanel panel2 = dock.Panel;
						homeCameraDockState.Camera = this.FindCameraNode(Convert.ToString((panel2 != null) ? panel2.Caption : null), dock.CameraIndex);
						homeCameraDockState.DisplayController = new SettingDisplayController(dock.HWindowControl)
						{
							UseBufferedRedraw = true
						};
						Form_home.HomeCameraDockState fallbackState = homeCameraDockState;
						this._cameraStates[sender] = fallbackState;
						bool flag7 = dock.HWindowControl != null;
						if (flag7)
						{
							dock.HWindowControl.Tag = fallbackState;
						}
						result = fallbackState;
					}
					else
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x06001A40 RID: 6720 RVA: 0x0008A490 File Offset: 0x00088690
		private Form_home.HomeCameraDockState GetStateFromWindow(object sender)
		{
			FrameworkElement frameworkElement = sender as FrameworkElement;
			return ((frameworkElement != null) ? frameworkElement.Tag : null) as Form_home.HomeCameraDockState;
		}

		// Token: 0x06001A41 RID: 6721 RVA: 0x0008A4BC File Offset: 0x000886BC
		public void SaveCameraDockImage(object sender)
		{
			Form_home.HomeCameraDockState state = this.GetStateFromView(sender);
			bool flag = ((state != null) ? state.DisplayController : null) == null;
			if (flag)
			{
				DXMessageBox.Show("Could not resolve the selected camera display.", "Save Image");
			}
			else
			{
				bool flag2 = !state.DisplayController.HasImage;
				if (flag2)
				{
					DXMessageBox.Show("No image is available to save for this camera display.", "Save Image");
				}
				else
				{
					SaveFileDialog dialog = new SaveFileDialog
					{
						Title = "Save Displayed Image",
						Filter = "PNG (*.png)|*.png|JPEG (*.jpg)|*.jpg|Bitmap (*.bmp)|*.bmp|TIFF (*.tif)|*.tif|All files (*.*)|*.*",
						FileName = (state.CameraName ?? "image") + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png"
					};
					bool flag3 = !dialog.ShowDialog().GetValueOrDefault();
					if (!flag3)
					{
						HObject image = state.DisplayController.GetCurrentImage();
						bool flag4 = image == null || !image.IsInitialized();
						if (flag4)
						{
							HObject image2 = image;
							if (image2 != null)
							{
								image2.Dispose();
							}
							DXMessageBox.Show("No image is available to save for this camera display.", "Save Image");
						}
						else
						{
							string path = dialog.FileName;
							try
							{
								LoadingOverlay.Run(this, "Saving image...", delegate
								{
									SettingDisplayController.WriteImage(image, path);
								});
								this.AddHomeLog("Info", "Image saved: " + path);
							}
							catch (Exception ex)
							{
								this.AddHomeLog("Error", "Save image failed: " + ex.Message);
								DXMessageBox.Show(ex.Message, "Save Image");
							}
							finally
							{
								image.Dispose();
							}
						}
					}
				}
			}
		}

		// Token: 0x06001A42 RID: 6722 RVA: 0x0008A69C File Offset: 0x0008889C
		public void OpenImageFromCameraDock(object sender)
		{
			Form_home.HomeCameraDockState state = this.GetStateFromView(sender);
			bool flag = state == null;
			if (flag)
			{
				DXMessageBox.Show("Could not resolve the selected camera display.", "Open Image");
			}
			else
			{
				try
				{
					this.AddHomeLog("Info", "Open image requested. Camera=" + (state.CameraName ?? "Unknown"));
					state.DisplayController.OpenImageByDialog();
					state.DisplayController.RedrawAfterLayoutChanged();
					this.AddHomeLog("Info", "Image loaded to Home HWindow. Camera=" + (state.CameraName ?? "Unknown"));
				}
				catch (Exception ex)
				{
					this.AddHomeLog("Error", "Open image failed: " + ex.Message);
					DXMessageBox.Show(ex.Message, "Open Image");
				}
			}
		}

		// Token: 0x06001A43 RID: 6723 RVA: 0x0008A77C File Offset: 0x0008897C
		public void ShowSettingFromCameraDock(object sender)
		{
			Form_home.HomeCameraDockState state = this.GetStateFromView(sender);
			bool flag = state == null;
			if (flag)
			{
				DXMessageBox.Show("Could not resolve the selected camera display.", "Home Run Setting");
			}
			else
			{
				this.ShowTurnSnapSettingPopup(state);
			}
		}

		// Token: 0x06001A44 RID: 6724 RVA: 0x0008A7B8 File Offset: 0x000889B8
		public void RunTurnSnapFromCameraDock(object sender)
		{
			Form_home.HomeCameraDockState state = this.GetStateFromView(sender);
			bool flag = state == null;
			if (flag)
			{
				DXMessageBox.Show("Could not resolve the selected camera display.", "Run TurnSnap");
			}
			else
			{
				this.RunSelectedTurnSnap(state);
			}
		}

		// Token: 0x06001A45 RID: 6725 RVA: 0x0008A7F4 File Offset: 0x000889F4
		private void EnsureCameraTurnSnapsLoaded(Form_home.HomeCameraDockState state)
		{
			bool flag = ((state != null) ? state.Camera : null) == null;
			if (!flag)
			{
				bool flag2 = state.Camera.TurnSnaps != null && state.Camera.TurnSnaps.Count > 0;
				if (!flag2)
				{
					try
					{
						this._recipeService.LoadCurrentModelRecipe();
						MainWindow instance = MainWindow.instance;
						IEnumerable<CameraNode> cameras;
						if (instance == null)
						{
							cameras = null;
						}
						else
						{
							MainViewModel mainViewModel = instance.MainViewModel;
							cameras = ((mainViewModel != null) ? mainViewModel.Cameras : null);
						}
						ToolRuntimePreloadService.PreloadFromCameras(cameras);
					}
					catch
					{
					}
					state.Camera = (this.FindCameraNode(state.CameraName, (state.Dock == null) ? 0 : state.Dock.CameraIndex) ?? state.Camera);
				}
			}
		}

		// Token: 0x06001A46 RID: 6726 RVA: 0x0008A8C0 File Offset: 0x00088AC0
		private void RefreshHomeTurnSnapReference(Form_home.HomeCameraDockState state)
		{
			bool flag = state == null;
			if (!flag)
			{
				int selectedIndex = (state.SelectedTurnSnap == null) ? 0 : state.SelectedTurnSnap.Index;
				state.Camera = (this.FindCameraNode(state.CameraName, (state.Dock == null) ? 0 : state.Dock.CameraIndex) ?? state.Camera);
				this.EnsureCameraTurnSnapsLoaded(state);
				CameraNode camera = state.Camera;
				ObservableCollection<TurnSnap> turnSnaps = (camera != null) ? camera.TurnSnaps : null;
				bool flag2 = turnSnaps == null || turnSnaps.Count == 0;
				if (!flag2)
				{
					TurnSnap current = null;
					bool flag3 = selectedIndex > 0;
					if (flag3)
					{
						current = turnSnaps.FirstOrDefault((TurnSnap x) => x.Index == selectedIndex);
					}
					TurnSnap savedTurnSnap;
					bool flag4 = current == null && !string.IsNullOrWhiteSpace(state.CameraName) && this._selectedTurnSnapByCamera.TryGetValue(state.CameraName, out savedTurnSnap) && savedTurnSnap != null;
					if (flag4)
					{
						current = turnSnaps.FirstOrDefault((TurnSnap x) => x.Index == savedTurnSnap.Index);
					}
					bool flag5 = current == null;
					if (flag5)
					{
						current = (turnSnaps.FirstOrDefault((TurnSnap x) => x.IsSelected) ?? turnSnaps.FirstOrDefault<TurnSnap>());
					}
					state.SelectedTurnSnap = current;
					bool flag6 = !string.IsNullOrWhiteSpace(state.CameraName) && current != null;
					if (flag6)
					{
						this._selectedTurnSnapByCamera[state.CameraName] = current;
					}
				}
			}
		}

		// Token: 0x06001A47 RID: 6727 RVA: 0x0008AA4C File Offset: 0x00088C4C
		private void ShowTurnSnapSettingPopup(Form_home.HomeCameraDockState state)
		{
			state.Camera = this.FindCameraNode(state.CameraName, (state.Dock == null) ? 0 : state.Dock.CameraIndex);
			Form_home.HomeCameraDockState state2 = state;
			bool flag = ((state2 != null) ? state2.Camera : null) == null;
			if (flag)
			{
				DXMessageBox.Show("No camera configuration was found for this display.", "Home Run Setting");
			}
			else
			{
				this.EnsureCameraTurnSnapsLoaded(state);
				ObservableCollection<TurnSnap> turnSnaps2 = state.Camera.TurnSnaps;
				List<TurnSnap> turnSnaps = ((turnSnaps2 != null) ? turnSnaps2.ToList<TurnSnap>() : null) ?? new List<TurnSnap>();
				bool flag2 = turnSnaps.Count == 0;
				if (flag2)
				{
					DXMessageBox.Show("No TurnSnap is configured for this camera.", "Home Run Setting");
				}
				else
				{
					ComboBox combo = new ComboBox
					{
						ItemsSource = turnSnaps,
						DisplayMemberPath = "DisplayName",
						SelectedItem = (state.SelectedTurnSnap ?? turnSnaps.FirstOrDefault<TurnSnap>()),
						Margin = new Thickness(0.0, 6.0, 0.0, 10.0),
						Height = 32.0
					};
					CheckBox softwareOverrideCheck = new CheckBox
					{
						Content = "Use software TurnSnap selection",
						IsChecked = new bool?(this.IsSoftwareTurnSnapOverrideEnabled(state)),
						Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
					};
					combo.IsEnabled = softwareOverrideCheck.IsChecked.GetValueOrDefault();
					softwareOverrideCheck.Checked += delegate(object s, RoutedEventArgs e)
					{
						combo.IsEnabled = true;
					};
					softwareOverrideCheck.Unchecked += delegate(object s, RoutedEventArgs e)
					{
						combo.IsEnabled = false;
					};
					SimpleButton okButton = new SimpleButton
					{
						Content = "Apply",
						Width = 90.0,
						Height = 34.0,
						Margin = new Thickness(8.0, 0.0, 0.0, 0.0)
					};
					SimpleButton cancelButton = new SimpleButton
					{
						Content = "Cancel",
						Width = 90.0,
						Height = 34.0
					};
					Window owner = Window.GetWindow(this);
					bool flag3 = owner == null || !owner.IsLoaded;
					if (flag3)
					{
						Application application = Application.Current;
						owner = ((application != null) ? application.MainWindow : null);
					}
					bool flag4 = owner != null && !owner.IsLoaded;
					if (flag4)
					{
						owner = null;
					}
					ThemedWindow dialog = new ThemedWindow
					{
						Title = "Home Run Setting",
						Width = 360.0,
						Height = 250.0,
						ResizeMode = ResizeMode.NoResize,
						WindowStartupLocation = ((owner != null) ? WindowStartupLocation.CenterOwner : WindowStartupLocation.CenterScreen)
					};
					bool flag5 = owner != null;
					if (flag5)
					{
						dialog.Owner = owner;
					}
					okButton.Click += delegate(object s, RoutedEventArgs e)
					{
						state.SelectedTurnSnap = (combo.SelectedItem as TurnSnap);
						this.SetSoftwareTurnSnapOverride(state, softwareOverrideCheck.IsChecked.GetValueOrDefault());
						bool flag6 = !string.IsNullOrWhiteSpace(state.CameraName) && state.SelectedTurnSnap != null;
						if (flag6)
						{
							this._selectedTurnSnapByCamera[state.CameraName] = state.SelectedTurnSnap;
						}
						dialog.DialogResult = new bool?(true);
						dialog.Close();
					};
					cancelButton.Click += delegate(object s, RoutedEventArgs e)
					{
						dialog.DialogResult = new bool?(false);
						dialog.Close();
					};
					StackPanel buttonPanel = new StackPanel
					{
						Orientation = Orientation.Horizontal,
						HorizontalAlignment = HorizontalAlignment.Right
					};
					buttonPanel.Children.Add(cancelButton);
					buttonPanel.Children.Add(okButton);
					StackPanel panel = new StackPanel
					{
						Margin = new Thickness(16.0)
					};
					panel.Children.Add(new TextBlock
					{
						Text = state.Camera.DisplayName,
						FontWeight = FontWeights.SemiBold,
						Margin = new Thickness(0.0, 0.0, 0.0, 10.0)
					});
					panel.Children.Add(new TextBlock
					{
						Text = "TurnSnap",
						Margin = new Thickness(0.0, 0.0, 0.0, 2.0)
					});
					panel.Children.Add(combo);
					panel.Children.Add(softwareOverrideCheck);
					panel.Children.Add(buttonPanel);
					dialog.Content = panel;
					dialog.ShowDialog();
				}
			}
		}

		// Token: 0x06001A48 RID: 6728 RVA: 0x0008AF1C File Offset: 0x0008911C
		private bool IsSoftwareTurnSnapOverrideEnabled(Form_home.HomeCameraDockState state)
		{
			return state != null && !string.IsNullOrWhiteSpace(state.CameraName) && this._softwareTurnSnapOverrideCameras.Contains(state.CameraName);
		}

		// Token: 0x06001A49 RID: 6729 RVA: 0x0008AF54 File Offset: 0x00089154
		private void SetSoftwareTurnSnapOverride(Form_home.HomeCameraDockState state, bool enabled)
		{
			bool flag = state == null || string.IsNullOrWhiteSpace(state.CameraName);
			if (!flag)
			{
				if (enabled)
				{
					this._softwareTurnSnapOverrideCameras.Add(state.CameraName);
				}
				else
				{
					this._softwareTurnSnapOverrideCameras.Remove(state.CameraName);
				}
			}
		}

		// Token: 0x06001A4A RID: 6730 RVA: 0x0008AFA5 File Offset: 0x000891A5
		private void RunSelectedTurnSnap(Form_home.HomeCameraDockState state)
		{
			this.RunSelectedTurnSnap(state, true, null);
		}

		// Token: 0x06001A4B RID: 6731 RVA: 0x0008AFB2 File Offset: 0x000891B2
		private void RunSelectedTurnSnap(Form_home.HomeCameraDockState state, bool interactive)
		{
			this.RunSelectedTurnSnap(state, interactive, null);
		}

		// Token: 0x06001A4C RID: 6732 RVA: 0x0008AFC0 File Offset: 0x000891C0
		private void RunSelectedTurnSnap(Form_home.HomeCameraDockState state, bool interactive, HObject triggerImage)
		{
			bool flag = ((state != null) ? state.DisplayController : null) == null;
			if (!flag)
			{
				this.RefreshHomeTurnSnapReference(state);
				bool flag2 = (triggerImage == null || !triggerImage.IsInitialized()) && !state.DisplayController.HasImage;
				if (flag2)
				{
					if (interactive)
					{
						DXMessageBox.Show("No image is available. Open an image for this camera first.", "Run TurnSnap");
					}
					else
					{
						this.AddHomeLog("Warn", "TurnSnap not run: no image available.");
					}
				}
				else
				{
					bool flag3 = state.SelectedTurnSnap == null;
					if (flag3)
					{
						if (interactive)
						{
							this.ShowTurnSnapSettingPopup(state);
						}
					}
					TurnSnap turnSnap = state.SelectedTurnSnap;
					bool flag4 = turnSnap == null || turnSnap.Tools == null || turnSnap.Tools.Count == 0;
					if (flag4)
					{
						if (interactive)
						{
							DXMessageBox.Show("No TurnSnap is selected or the selected TurnSnap has no tools.", "Run TurnSnap");
						}
						else
						{
							this.AddHomeLog("Warn", "TurnSnap not run: no TurnSnap selected or it has no tools.");
						}
					}
					else
					{
						bool flag5 = !interactive;
						if (flag5)
						{
							int enabledTools = turnSnap.Tools.Count((ToolVision t) => t != null && t.IsEnabled);
							this.AddHomeLog("Info", string.Concat(new string[]
							{
								"Triggered run: camera '",
								state.CameraName ?? "?",
								"', TurnSnap ",
								turnSnap.Index.ToString(),
								", enabled tools=",
								enabledTools.ToString(),
								"/",
								turnSnap.Tools.Count.ToString()
							}));
						}
						HObject original = null;
						ImageBufferStore bufferStore = null;
						ToolProcessContext processContext = null;
						HomeRunOverlayState overlayState = null;
						bool overlayStateTransferred = false;
						bool previousPreserveOverlayState = state.DisplayController.PreserveOverlayRendererStateOnClear;
						ToolActionContext context = new ToolActionContext
						{
							DisplayController = state.DisplayController,
							RecipeService = this._recipeService,
							ResultReporter = delegate(ToolVision tool, object result)
							{
								bool flag14 = tool == null || result == null || overlayState == null;
								if (!flag14)
								{
									overlayState.Results.Add(new HomeRunToolOverlayResult
									{
										Tool = tool,
										Result = result
									});
								}
							},
							ErrorReporter = (interactive ? null : new Action<string>(delegate(string message)
							{
								this.AddHomeLog("Error", message);
							}))
						};
						Dictionary<ToolVision, double> toolTimes = new Dictionary<ToolVision, double>();
						try
						{
							bool flag6 = triggerImage != null && triggerImage.IsInitialized();
							if (flag6)
							{
								HOperatorSet.CopyImage(triggerImage, out original);
							}
							else
							{
								original = state.DisplayController.GetOriginalImage();
							}
							bool flag7 = original == null || !original.IsInitialized();
							if (flag7)
							{
								bool flag8 = !interactive;
								if (flag8)
								{
									this.AddHomeLog("Warn", "TurnSnap not run: no image available.");
								}
							}
							else
							{
								bufferStore = new ImageBufferStore();
								processContext = new ToolProcessContext
								{
									OriginalImage = original,
									InputImage = original,
									BufferStore = bufferStore,
									ResultStore = new ToolResultStore()
								};
								overlayState = new HomeRunOverlayState();
								state.DisplayController.PreserveOverlayRendererStateOnClear = true;
								foreach (ToolVision tool2 in turnSnap.Tools)
								{
									bool flag9 = tool2 == null || !tool2.IsEnabled;
									if (!flag9)
									{
										Stopwatch stopwatch = Stopwatch.StartNew();
										try
										{
											string processorMessage = null;
											bool flag10 = !this.TryRunToolProcessorForHome(processContext, tool2, overlayState, out processorMessage);
											if (flag10)
											{
												bool flag11 = !string.IsNullOrWhiteSpace(processorMessage);
												if (flag11)
												{
													Debug.WriteLine("[HomeRun] Processor fallback for " + (tool2.Name ?? tool2.ToolType.ToString()) + ": " + processorMessage);
												}
												this._toolActionDispatcher.TrialRun(context, tool2);
											}
										}
										catch (Exception ex)
										{
											if (interactive)
											{
												throw;
											}
											this.AddHomeLog("Error", "Tool '" + (tool2.Name ?? tool2.ToolType.ToString()) + "' failed during triggered run: " + ex.Message);
										}
										finally
										{
											stopwatch.Stop();
											toolTimes[tool2] = stopwatch.Elapsed.TotalMilliseconds;
										}
									}
								}
								bool flag12 = original != null && original.IsInitialized();
								if (flag12)
								{
									state.DisplayController.DisplayImage(original);
								}
								state.DisplayController.SetOverlayRenderer(delegate(HWindow window)
								{
									this.DrawHomeRunOverlays(window, overlayState);
								}, overlayState);
								overlayStateTransferred = true;
								this.UpdateHomeOutputResults(state, overlayState, toolTimes);
								this.WriteTurnSnapResultsToModbus(state, overlayState);
							}
						}
						finally
						{
							state.DisplayController.PreserveOverlayRendererStateOnClear = previousPreserveOverlayState;
							bool flag13 = !overlayStateTransferred;
							if (flag13)
							{
								HomeRunOverlayState overlayState2 = overlayState;
								if (overlayState2 != null)
								{
									overlayState2.Dispose();
								}
							}
							if (original != null)
							{
								original.Dispose();
							}
							if (bufferStore != null)
							{
								bufferStore.Clear();
							}
						}
					}
				}
			}
		}

		// Token: 0x06001A4D RID: 6733 RVA: 0x0008B4F8 File Offset: 0x000896F8
		private bool TryRunToolProcessorForHome(ToolProcessContext processContext, ToolVision tool, HomeRunOverlayState overlayState, out string message)
		{
			message = null;
			bool flag = processContext == null || tool == null || overlayState == null;
			bool result;
			if (flag)
			{
				message = "Invalid process context.";
				result = false;
			}
			else
			{
				IToolProcessor processor = Form_home.CreateHomeProcessor(tool);
				bool flag2 = processor == null;
				if (flag2)
				{
					message = "No processor registered.";
					result = false;
				}
				else
				{
					HObject input = null;
					HObject previousInput = processContext.InputImage;
					HObject output = null;
					try
					{
						input = this._homePipelineService.BuildInputImageForTool(processContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							message = "Input image was not built.";
							result = false;
						}
						else
						{
							processContext.InputImage = input;
							ToolProcessResult processResult = processor.Execute(processContext, tool);
							output = processContext.OutputImage;
							processContext.OutputImage = null;
							bool flag4 = output != null && output.IsInitialized();
							if (flag4)
							{
								ImageBufferStore bufferStore = processContext.BufferStore;
								if (bufferStore != null)
								{
									bufferStore.SetByToolName(tool.Name, output);
								}
							}
							object resultData = (processResult == null) ? null : processResult.Data;
							bool flag5 = tool.ToolType == ToolType.SaveImage && processResult != null && !string.IsNullOrWhiteSpace(processResult.Message);
							if (flag5)
							{
								this.AddHomeLog("Info", processResult.Message);
							}
							bool flag6 = resultData != null;
							if (flag6)
							{
								ToolResultStore resultStore = processContext.ResultStore;
								if (resultStore != null)
								{
									resultStore.Set(tool.Name, resultData);
								}
							}
							overlayState.Results.Add(new HomeRunToolOverlayResult
							{
								Tool = tool,
								Result = resultData
							});
							result = true;
						}
					}
					finally
					{
						processContext.InputImage = previousInput;
						if (input != null)
						{
							input.Dispose();
						}
						if (output != null)
						{
							output.Dispose();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001A4E RID: 6734 RVA: 0x0008B6B4 File Offset: 0x000898B4
		private static IToolProcessor CreateHomeProcessor(ToolVision tool)
		{
			bool flag = tool == null;
			IToolProcessor result;
			if (flag)
			{
				result = null;
			}
			else
			{
				switch (tool.ToolType)
				{
				case ToolType.Blob:
					return new BlobProcessor();
				case ToolType.Histogram:
					return new HistogramProcessor();
				case ToolType.HistogramColor:
					return new HistogramColorProcessor();
				case ToolType.FindCircle:
					return new FindCircleProcessor();
				case ToolType.FindLine:
					return new FindLineProcessor();
				case ToolType.Shape_model:
					return new ShapeModelProcessor();
				case ToolType.AnisoShapeModel:
					return new AnisoShapeModelProcessor();
				case ToolType.OverlappingShapeModel:
					return new OverlappingShapeModelProcessor();
				case ToolType.ImageFilter:
					return new ImageFilterProcessor();
				case ToolType.ImageTransform:
					return new ImageTransformProcessor();
				case ToolType.SaveImage:
					return new SaveImageProcessor();
				case ToolType.MatrixCode:
					return new MatrixCodeProcessor();
				case ToolType.MeasureCircle:
					return new MeasureCircleProcessor();
				case ToolType.CircleMaster:
					return new CircleMasterProcessor();
				case ToolType.BoundingBoxMaster:
					return new BoundingBoxMasterProcessor();
				case ToolType.MinAreaMaster:
					return new MinAreaMasterProcessor();
				case ToolType.IntersectingLines:
					return new IntersectingLinesProcessor();
				case ToolType.AngleSelector:
					return new AngleSelectorProcessor();
				case ToolType.FindBoundingBox:
					return new FindBoundingBoxProcessor();
				case ToolType.FindMinArea:
					return new FindMinAreaProcessor();
				case ToolType.CalibHandEye:
					return new CalibHandEyeProcessor();
				case ToolType.ResultAlign:
					return new CalibResultAlignProcessor();
				case ToolType.ResultInspection:
					return new CalibResultInspectionProcessor();
				case ToolType.DeformableInspection:
					return new DeformableInspectionProcessor();
				case ToolType.VariationModel:
					return new VariationModelProcessor();
				case ToolType.DLObjectInspection:
					return new DLObjectInspectionProcessor();
				case ToolType.VariationChangeWD:
					return new VariationChangeWDProcessor();
				case ToolType.ProductCountInspection:
					return new ProductCountInspectionProcessor();
				case ToolType.FindRedArrow:
					return new FindRedArrowProcessor();
				case ToolType.CountBoundingBox:
					return new CountBoundingBoxProcessor();
				case ToolType.ProcedureInspection:
					return new ProcedureInspectionProcessor();
				}
				result = null;
			}
			return result;
		}

		// Token: 0x06001A4F RID: 6735 RVA: 0x0008B898 File Offset: 0x00089A98
		private void UpdateHomeOutputResults(Form_home.HomeCameraDockState state, HomeRunOverlayState overlayState, Dictionary<ToolVision, double> toolTimes)
		{
			CameraOutputResultView cameraOutputResultView;
			if (state == null)
			{
				cameraOutputResultView = null;
			}
			else
			{
				CameraDockItem dock = state.Dock;
				cameraOutputResultView = ((dock != null) ? dock.OutputView : null);
			}
			CameraOutputResultView outputView = cameraOutputResultView;
			bool flag = outputView == null;
			if (!flag)
			{
				List<HomeOutputResultRow> rows = new List<HomeOutputResultRow>();
				bool flag2 = ((overlayState != null) ? overlayState.Results : null) != null;
				if (flag2)
				{
					foreach (HomeRunToolOverlayResult item in overlayState.Results)
					{
						bool flag3 = ((item != null) ? item.Tool : null) == null || item.Result == null;
						if (!flag3)
						{
							double time = 0.0;
							double elapsed;
							bool flag4 = toolTimes != null && toolTimes.TryGetValue(item.Tool, out elapsed);
							if (flag4)
							{
								time = elapsed;
							}
							rows.Add(HomeToolResultFormatter.Build(item.Tool, item.Result, time));
						}
					}
				}
				outputView.ShowOutputResults(rows);
			}
		}

		// Token: 0x06001A50 RID: 6736 RVA: 0x0008B9A4 File Offset: 0x00089BA4
		private void WriteTurnSnapResultsToModbus(Form_home.HomeCameraDockState state, HomeRunOverlayState overlayState)
		{
			bool flag = state == null || ((overlayState != null) ? overlayState.Results : null) == null || overlayState.Results.Count == 0;
			if (flag)
			{
				this.AddHomeLog("Warn", "Result -> Modbus: the run produced no tool results to send.");
			}
			else
			{
				string cameraName = state.CameraName;
				bool flag2 = string.IsNullOrWhiteSpace(cameraName);
				if (!flag2)
				{
					List<ToolResultEntry> entries = (from x in overlayState.Results
					where ((x != null) ? x.Tool : null) != null && x.Result != null
					select new ToolResultEntry
					{
						Tool = x.Tool,
						Result = x.Result
					}).ToList<ToolResultEntry>();
					bool flag3 = entries.Count == 0;
					if (flag3)
					{
						string ran = string.Join(", ", from x in overlayState.Results
						where ((x != null) ? x.Tool : null) != null
						select (x.Tool.Name ?? x.Tool.ToolType.ToString()) + ((x.Result == null) ? " (no result)" : string.Empty));
						this.AddHomeLog("Warn", "Result -> Modbus: no result-bearing tool ran for '" + cameraName + "'. Add a Result Align / Result Inspection tool to this TurnSnap. Tools: " + (string.IsNullOrWhiteSpace(ran) ? "(none)" : ran));
						VisionErrorCodeService.WriteAsync(10);
					}
					else
					{
						VisionErrorCodeService.WriteAsync(0);
						Action<string, string> <>9__5;
						Task.Run(delegate()
						{
							string cameraName = cameraName;
							IList<ToolResultEntry> entries = entries;
							Action<string, string> log;
							if ((log = <>9__5) == null)
							{
								log = (<>9__5 = delegate(string level, string message)
								{
									this.Dispatcher.BeginInvoke(new Action(delegate()
									{
										this.AddHomeLog(level, message);
									}), Array.Empty<object>());
								});
							}
							CommunicationResultWriteService.WriteCameraResults(cameraName, entries, log);
						});
					}
				}
			}
		}

		// Token: 0x06001A51 RID: 6737 RVA: 0x0008BB3C File Offset: 0x00089D3C
		private static string GetTextFlagDebug(ToolVision tool)
		{
			ToolConfigBase cfg = (tool != null) ? tool.Config : null;
			bool flag = cfg == null;
			string result;
			if (flag)
			{
				result = "config=null";
			}
			else
			{
				Type type = cfg.GetType();
				foreach (string name in new string[]
				{
					"ShowText",
					"show_text",
					"ShowLabel",
					"ShowResultText",
					"DisplayText",
					"ShowName",
					"ShowValue",
					"ShowInfo"
				})
				{
					PropertyInfo prop = type.GetProperty(name);
					bool flag2 = prop != null && prop.PropertyType == typeof(bool);
					if (flag2)
					{
						string str = name;
						string str2 = "=";
						object value = prop.GetValue(cfg);
						return str + str2 + ((value != null) ? value.ToString() : null);
					}
				}
				result = "no-text-flag";
			}
			return result;
		}

		// Token: 0x06001A52 RID: 6738 RVA: 0x0008BC38 File Offset: 0x00089E38
		private void DrawHomeRunOverlays(HWindow window, HomeRunOverlayState overlayState)
		{
			bool flag = window == null || overlayState == null;
			if (!flag)
			{
				ShapeModelResultDrawer shapeDrawer = new ShapeModelResultDrawer();
				OverlappingShapeModelResultDrawer overlappingDrawer = new OverlappingShapeModelResultDrawer();
				BlobResultDrawer blobDrawer = new BlobResultDrawer();
				HistogramResultDrawer histogramDrawer = new HistogramResultDrawer();
				HistogramColorResultDrawer histogramColorDrawer = new HistogramColorResultDrawer();
				FindCircleResultDrawer findCircleDrawer = new FindCircleResultDrawer();
				FindBoundingBoxResultDrawer findBoundingBoxDrawer = new FindBoundingBoxResultDrawer();
				FindMinAreaResultDrawer findMinAreaDrawer = new FindMinAreaResultDrawer();
				FindLineResultDrawer findLineDrawer = new FindLineResultDrawer();
				MeasureCircleResultDrawer measureCircleDrawer = new MeasureCircleResultDrawer();
				CircleMasterResultDrawer circleMasterDrawer = new CircleMasterResultDrawer();
				BoundingBoxMasterResultDrawer boundingBoxMasterDrawer = new BoundingBoxMasterResultDrawer();
				MinAreaMasterResultDrawer minAreaMasterDrawer = new MinAreaMasterResultDrawer();
				IntersectingLinesResultDrawer intersectingLinesDrawer = new IntersectingLinesResultDrawer();
				AngleSelectorResultDrawer angleSelectorDrawer = new AngleSelectorResultDrawer();
				CalibHandEyeResultDrawer calibHandEyeDrawer = new CalibHandEyeResultDrawer();
				CalibResultAlignResultDrawer resultAlignDrawer = new CalibResultAlignResultDrawer();
				CalibResultInspectionResultDrawer resultInspectionDrawer = new CalibResultInspectionResultDrawer();
				DeformableInspectionResultDrawer deformableInspectionDrawer = new DeformableInspectionResultDrawer();
				VariationModelResultDrawer variationModelDrawer = new VariationModelResultDrawer();
				VariationChangeWDResultDrawer variationChangeWdDrawer = new VariationChangeWDResultDrawer();
				ProductCountInspectionResultDrawer productCountDrawer = new ProductCountInspectionResultDrawer();
				FindRedArrowResultDrawer findRedArrowDrawer = new FindRedArrowResultDrawer();
				CountBoundingBoxResultDrawer countBoundingBoxDrawer = new CountBoundingBoxResultDrawer();
				DLObjectInspectionResultDrawer dlObjectInspectionDrawer = new DLObjectInspectionResultDrawer();
				MatrixCodeResultDrawer matrixCodeDrawer = new MatrixCodeResultDrawer();
				foreach (HomeRunToolOverlayResult item in overlayState.Results)
				{
					bool flag2 = ((item != null) ? item.Tool : null) == null || item.Result == null;
					if (!flag2)
					{
						MatrixCodeResult matrixCodeResult = item.Result as MatrixCodeResult;
						bool flag3 = matrixCodeResult != null;
						if (flag3)
						{
							matrixCodeDrawer.Draw(window, item.Tool, matrixCodeResult);
						}
						else
						{
							CalibHandEyeResult calibHandEyeResult = item.Result as CalibHandEyeResult;
							bool flag4 = calibHandEyeResult != null;
							if (flag4)
							{
								calibHandEyeDrawer.Draw(window, item.Tool, calibHandEyeResult);
							}
							else
							{
								CalibResultAlignResult resultAlignResult = item.Result as CalibResultAlignResult;
								bool flag5 = resultAlignResult != null;
								if (flag5)
								{
									resultAlignDrawer.Draw(window, item.Tool, resultAlignResult);
								}
								else
								{
									CalibResultInspectionResult resultInspectionResult = item.Result as CalibResultInspectionResult;
									bool flag6 = resultInspectionResult != null;
									if (flag6)
									{
										resultInspectionDrawer.Draw(window, item.Tool, resultInspectionResult);
									}
									else
									{
										DeformableInspectionResult deformableInspectionResult = item.Result as DeformableInspectionResult;
										bool flag7 = deformableInspectionResult != null;
										if (flag7)
										{
											deformableInspectionDrawer.Draw(window, item.Tool, deformableInspectionResult);
										}
										else
										{
											VariationModelResult variationModelResult = item.Result as VariationModelResult;
											bool flag8 = variationModelResult != null;
											if (flag8)
											{
												variationModelDrawer.Draw(window, item.Tool, variationModelResult);
											}
											else
											{
												VariationChangeWDResult variationChangeWdResult = item.Result as VariationChangeWDResult;
												bool flag9 = variationChangeWdResult != null;
												if (flag9)
												{
													variationChangeWdDrawer.Draw(window, item.Tool, variationChangeWdResult);
												}
												else
												{
													ProductCountInspectionResult productCountResult = item.Result as ProductCountInspectionResult;
													bool flag10 = productCountResult != null;
													if (flag10)
													{
														productCountDrawer.Draw(window, item.Tool, productCountResult);
													}
													else
													{
														FindRedArrowResult findRedArrowResult = item.Result as FindRedArrowResult;
														bool flag11 = findRedArrowResult != null;
														if (flag11)
														{
															findRedArrowDrawer.Draw(window, item.Tool, findRedArrowResult);
														}
														else
														{
															CountBoundingBoxResult countBoundingBoxResult = item.Result as CountBoundingBoxResult;
															bool flag12 = countBoundingBoxResult != null;
															if (flag12)
															{
																countBoundingBoxDrawer.Draw(window, item.Tool, countBoundingBoxResult);
															}
															else
															{
																DLObjectInspectionResult dlObjectInspectionResult = item.Result as DLObjectInspectionResult;
																bool flag13 = dlObjectInspectionResult != null;
																if (flag13)
																{
																	dlObjectInspectionDrawer.Draw(window, item.Tool, dlObjectInspectionResult);
																}
																else
																{
																	IntersectingLinesResult intersectingLinesResult = item.Result as IntersectingLinesResult;
																	bool flag14 = intersectingLinesResult != null;
																	if (flag14)
																	{
																		intersectingLinesDrawer.Draw(window, item.Tool, intersectingLinesResult);
																	}
																	else
																	{
																		CircleMasterResult circleMasterResult = item.Result as CircleMasterResult;
																		bool flag15 = circleMasterResult != null;
																		if (flag15)
																		{
																			circleMasterDrawer.Draw(window, item.Tool, circleMasterResult);
																		}
																		else
																		{
																			BoundingBoxMasterResult boundingBoxMasterResult = item.Result as BoundingBoxMasterResult;
																			bool flag16 = boundingBoxMasterResult != null;
																			if (flag16)
																			{
																				boundingBoxMasterDrawer.Draw(window, item.Tool, boundingBoxMasterResult, false);
																			}
																			else
																			{
																				MinAreaMasterResult minAreaMasterResult = item.Result as MinAreaMasterResult;
																				bool flag17 = minAreaMasterResult != null;
																				if (flag17)
																				{
																					minAreaMasterDrawer.Draw(window, item.Tool, minAreaMasterResult, false);
																				}
																				else
																				{
																					AngleSelectorResult angleSelectorResult = item.Result as AngleSelectorResult;
																					bool flag18 = angleSelectorResult != null;
																					if (flag18)
																					{
																						angleSelectorDrawer.Draw(window, item.Tool, angleSelectorResult);
																					}
																					else
																					{
																						OverlappingShapeModelResult overlappingResult = item.Result as OverlappingShapeModelResult;
																						bool flag19 = overlappingResult != null;
																						if (flag19)
																						{
																							overlappingDrawer.DrawRoiOverlays(window, item.Tool, overlappingResult);
																							overlappingDrawer.Draw(item.Tool, window, overlappingResult, false);
																						}
																						else
																						{
																							ShapeMatchResult shapeResult = item.Result as ShapeMatchResult;
																							bool flag20 = shapeResult != null;
																							if (flag20)
																							{
																								shapeDrawer.DrawRoiOverlays(window, item.Tool, shapeResult);
																								shapeDrawer.DrawMatchResult(item.Tool, window, shapeResult);
																							}
																							else
																							{
																								BlobProcessResult blobResult = item.Result as BlobProcessResult;
																								bool flag21 = blobResult != null;
																								if (flag21)
																								{
																									blobDrawer.Draw(window, item.Tool, blobResult, false, false);
																								}
																								else
																								{
																									HistogramProcessResult histogramResult = item.Result as HistogramProcessResult;
																									bool flag22 = histogramResult != null;
																									if (flag22)
																									{
																										histogramDrawer.Draw(window, item.Tool, histogramResult, false, false);
																									}
																									else
																									{
																										HistogramColorProcessResult histogramColorResult = item.Result as HistogramColorProcessResult;
																										bool flag23 = histogramColorResult != null;
																										if (flag23)
																										{
																											histogramColorDrawer.Draw(window, item.Tool, histogramColorResult, false, false);
																										}
																										else
																										{
																											FindLineResult findLineResult = item.Result as FindLineResult;
																											bool flag24 = findLineResult != null;
																											if (flag24)
																											{
																												findLineDrawer.Draw(window, item.Tool, findLineResult);
																											}
																											else
																											{
																												FindCircleResult findCircleResult = item.Result as FindCircleResult;
																												bool flag25 = findCircleResult != null;
																												if (flag25)
																												{
																													findCircleDrawer.Draw(window, item.Tool, findCircleResult);
																												}
																												else
																												{
																													FindMinAreaResult findMinAreaResult = item.Result as FindMinAreaResult;
																													bool flag26 = findMinAreaResult != null;
																													if (flag26)
																													{
																														findMinAreaDrawer.Draw(window, item.Tool, findMinAreaResult, false);
																													}
																													else
																													{
																														FindBoundingBoxResult findBoundingBoxResult = item.Result as FindBoundingBoxResult;
																														bool flag27 = findBoundingBoxResult != null;
																														if (flag27)
																														{
																															findBoundingBoxDrawer.Draw(window, item.Tool, findBoundingBoxResult, false);
																														}
																														else
																														{
																															DistanceObjectResult distanceResult = item.Result as DistanceObjectResult;
																															bool flag28 = distanceResult != null;
																															if (flag28)
																															{
																																new DistanceObjectResultDrawer().Draw(window, item.Tool, distanceResult);
																															}
																															else
																															{
																																MeasureCircleResult measureCircleResult = item.Result as MeasureCircleResult;
																																bool flag29 = measureCircleResult != null;
																																if (flag29)
																																{
																																	measureCircleDrawer.Draw(window, item.Tool, measureCircleResult);
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001A53 RID: 6739 RVA: 0x0008C2F4 File Offset: 0x0008A4F4
		public static void PostCameraTrigger(CameraTriggerEventArgs e)
		{
			Form_home form = Form_home.Instance;
			string[] array = new string[6];
			array[0] = "[Trigger] PostCameraTrigger: Instance=";
			array[1] = ((form == null) ? "NULL (queued)" : "ok");
			array[2] = ", Camera=";
			int num = 3;
			CameraTriggerEventArgs e2 = e;
			array[num] = (((e2 != null) ? e2.CameraName : null) ?? "<null>");
			array[4] = ", TurnSnapIndex=";
			array[5] = ((e == null) ? -1 : e.TurnSnapIndex).ToString();
			Debug.WriteLine(string.Concat(array));
			bool flag = form == null || e == null;
			if (flag)
			{
				bool flag2 = e != null;
				if (flag2)
				{
					object pendingTriggerSync = Form_home.PendingTriggerSync;
					lock (pendingTriggerSync)
					{
						Form_home.PendingCameraTriggers.Add(e);
					}
				}
			}
			else
			{
				form.Dispatcher.BeginInvoke(new Action(delegate()
				{
					try
					{
						form.HandleCameraTrigger(e);
					}
					catch (Exception ex)
					{
						string str = "[Trigger] HandleCameraTrigger threw: ";
						Exception ex2 = ex;
						Debug.WriteLine(str + ((ex2 != null) ? ex2.ToString() : null));
						form.AddHomeLog("Error", "Camera trigger handler failed: " + ex.Message);
					}
				}), Array.Empty<object>());
			}
		}

		// Token: 0x06001A54 RID: 6740 RVA: 0x0008C42C File Offset: 0x0008A62C
		public static void PostHardwareCameraTrigger(string cameraName, HObject image)
		{
			Form_home form = Form_home.Instance;
			bool flag = form == null || string.IsNullOrWhiteSpace(cameraName) || image == null || !image.IsInitialized();
			if (flag)
			{
				HObject image2 = image;
				if (image2 != null)
				{
					image2.Dispose();
				}
			}
			else
			{
				form.Dispatcher.BeginInvoke(new Action(delegate()
				{
					try
					{
						form.HandleHardwareCameraTrigger(cameraName, image);
					}
					catch (Exception ex)
					{
						form.AddHomeLog("Error", "Hardware camera trigger failed: " + ex.Message);
						HObject image3 = image;
						if (image3 != null)
						{
							image3.Dispose();
						}
					}
				}), Array.Empty<object>());
			}
		}

		// Token: 0x06001A55 RID: 6741 RVA: 0x0008C4C4 File Offset: 0x0008A6C4
		private void HandleHardwareCameraTrigger(string cameraName, HObject image)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraName) || image == null || !image.IsInitialized();
			if (flag)
			{
				if (image != null)
				{
					image.Dispose();
				}
			}
			else
			{
				Form_home.HomeCameraDockState state = this.FindHomeCameraState(cameraName);
				bool flag2 = state == null;
				if (flag2)
				{
					this.AddHomeLog("Error", "Hardware trigger display was not found. Camera=" + cameraName);
					image.Dispose();
				}
				else
				{
					CameraNode camera = state.Camera;
					CameraParameterConfig config = (camera != null) ? camera.CameraConfig : null;
					bool flag3 = config == null || !config.HardwareTrigger;
					if (flag3)
					{
						image.Dispose();
					}
					else
					{
						this.EnsureCameraTurnSnapsLoaded(state);
						bool flag4 = state.SelectedTurnSnap == null;
						if (flag4)
						{
							Form_home.HomeCameraDockState homeCameraDockState = state;
							CameraNode camera2 = state.Camera;
							object obj;
							if (camera2 == null)
							{
								obj = null;
							}
							else
							{
								ObservableCollection<TurnSnap> turnSnaps = camera2.TurnSnaps;
								if (turnSnaps == null)
								{
									obj = null;
								}
								else
								{
									obj = turnSnaps.FirstOrDefault((TurnSnap x) => x.IsSelected);
								}
							}
							object selectedTurnSnap;
							if ((selectedTurnSnap = obj) == null)
							{
								CameraNode camera3 = state.Camera;
								if (camera3 == null)
								{
									selectedTurnSnap = null;
								}
								else
								{
									ObservableCollection<TurnSnap> turnSnaps2 = camera3.TurnSnaps;
									selectedTurnSnap = ((turnSnaps2 != null) ? turnSnaps2.FirstOrDefault<TurnSnap>() : null);
								}
							}
							homeCameraDockState.SelectedTurnSnap = selectedTurnSnap;
						}
						this.AddHomeLog("Trigger", "Hardware Trigger " + cameraName + " -> TurnSnap " + ((state.SelectedTurnSnap == null) ? "?" : state.SelectedTurnSnap.Index.ToString()));
						try
						{
							this.RunSelectedTurnSnap(state, false, image);
						}
						finally
						{
							image.Dispose();
						}
					}
				}
			}
		}

		// Token: 0x06001A56 RID: 6742 RVA: 0x0008C650 File Offset: 0x0008A850
		public static void PostCameraTriggerDiagnostic(CameraTriggerDiagnosticEventArgs e)
		{
			bool flag = e != null && !string.Equals(e.Level, "Warn", StringComparison.OrdinalIgnoreCase) && !string.Equals(e.Level, "Warning", StringComparison.OrdinalIgnoreCase) && !string.Equals(e.Level, "Error", StringComparison.OrdinalIgnoreCase);
			if (!flag)
			{
				Form_home form = Form_home.Instance;
				bool flag2 = form == null || e == null;
				if (flag2)
				{
					bool flag3 = e != null;
					if (flag3)
					{
						object pendingTriggerSync = Form_home.PendingTriggerSync;
						lock (pendingTriggerSync)
						{
							Form_home.PendingTriggerDiagnostics.Add(e);
						}
					}
				}
				else
				{
					form.Dispatcher.BeginInvoke(new Action(delegate()
					{
						form.AddHomeLog(e.Level, e.Message);
					}), Array.Empty<object>());
				}
			}
		}

		// Token: 0x06001A57 RID: 6743 RVA: 0x0008C764 File Offset: 0x0008A964
		private void FlushPendingCameraTriggerMessages()
		{
			object pendingTriggerSync = Form_home.PendingTriggerSync;
			List<CameraTriggerDiagnosticEventArgs> diagnostics;
			List<CameraTriggerEventArgs> triggers;
			lock (pendingTriggerSync)
			{
				diagnostics = Form_home.PendingTriggerDiagnostics.ToList<CameraTriggerDiagnosticEventArgs>();
				triggers = Form_home.PendingCameraTriggers.ToList<CameraTriggerEventArgs>();
				Form_home.PendingTriggerDiagnostics.Clear();
				Form_home.PendingCameraTriggers.Clear();
			}
			foreach (CameraTriggerDiagnosticEventArgs diagnostic in diagnostics)
			{
				this.AddHomeLog(diagnostic.Level, diagnostic.Message);
			}
			foreach (CameraTriggerEventArgs trigger in triggers)
			{
				this.HandleCameraTrigger(trigger);
			}
		}

		// Token: 0x06001A58 RID: 6744 RVA: 0x0008C860 File Offset: 0x0008AA60
		private void HandleCameraTrigger(CameraTriggerEventArgs e)
		{
			Form_home.<>c__DisplayClass81_0 CS$<>8__locals1 = new Form_home.<>c__DisplayClass81_0();
			CS$<>8__locals1.<>4__this = this;
			Debug.WriteLine("[Trigger] HandleCameraTrigger ENTER. Camera=" + (((e != null) ? e.CameraName : null) ?? "<null>") + ", cameraStates=" + this._cameraStates.Count.ToString());
			bool flag = e == null || string.IsNullOrWhiteSpace(e.CameraName);
			if (!flag)
			{
				Form_home.HomeCameraDockState state = this.FindHomeCameraState(e.CameraName);
				Debug.WriteLine("[Trigger] FindHomeCameraState('" + e.CameraName + "') => " + ((state == null) ? "NOT FOUND" : string.Concat(new string[]
				{
					"found (DockCamera=",
					state.CameraName ?? "None",
					", HasDisplay=",
					(state.DisplayController != null).ToString(),
					")"
				})));
				bool flag2 = state == null;
				if (flag2)
				{
					bool flag3 = this.RetryCameraTriggerWhenDisplayIsReady(e);
					if (!flag3)
					{
						this.AddHomeLog("Error", "Camera display was not found for trigger after waiting for Home layout: " + e.CameraName + ". Please check the camera list and Home dock layout.");
					}
				}
				else
				{
					this.ClearCameraTriggerDisplayRetry(e);
					state.Camera = (this.FindCameraNode(e.CameraName, (state.Dock == null) ? 0 : state.Dock.CameraIndex) ?? state.Camera);
					state.CameraName = e.CameraName;
					Form_home.<>c__DisplayClass81_0 CS$<>8__locals2 = CS$<>8__locals1;
					CameraNode camera = state.Camera;
					CS$<>8__locals2.config = ((camera != null) ? camera.CameraConfig : null);
					bool flag4 = CS$<>8__locals1.config == null;
					if (flag4)
					{
						this.AddHomeLog("Error", "Camera configuration was not found for trigger: " + e.CameraName);
					}
					else
					{
						bool flag5 = !this.IsCameraTriggerDisplayRetryPending(e);
						if (flag5)
						{
							string turnSnapText = (this.IsSoftwareTurnSnapOverrideEnabled(state) && state.SelectedTurnSnap != null) ? (state.SelectedTurnSnap.Index.ToString() + " (software)") : ((e.TurnSnapIndex + 1).ToString() + " (communication)");
							this.AddHomeLog("Trigger", "Trigger " + e.CameraName + " -> TurnSnap " + turnSnapText);
						}
						object triggerCaptureSync = this._triggerCaptureSync;
						lock (triggerCaptureSync)
						{
							bool flag7 = !this._triggerCapturesInProgress.Add(e.CameraName);
							if (flag7)
							{
								this.AddHomeLog("Warn", "Previous trigger for '" + e.CameraName + "' is still capturing; this trigger was skipped.");
								return;
							}
						}
						CS$<>8__locals1.captureName = e.CameraName;
						CS$<>8__locals1.captureState = state;
						CS$<>8__locals1.captureArgs = e;
						Task.Run(delegate()
						{
							HObject image = null;
							string error = null;
							MainWindow instance = MainWindow.instance;
							LightControllerConfig lightControllerConfig;
							if (instance == null)
							{
								lightControllerConfig = null;
							}
							else
							{
								MainViewModel mainViewModel = instance.MainViewModel;
								lightControllerConfig = ((mainViewModel != null) ? mainViewModel.LightConfig : null);
							}
							LightControllerConfig lightConfig = lightControllerConfig;
							try
							{
								LightControllerRuntimeService.IlluminateForTrigger(lightConfig);
								image = CameraHardwareRuntimeService.CaptureImage(CS$<>8__locals1.config);
							}
							catch (Exception ex)
							{
								error = ex.Message;
								string str = "[Trigger] Capture failed: ";
								Exception ex2 = ex;
								Debug.WriteLine(str + ((ex2 != null) ? ex2.ToString() : null));
							}
							finally
							{
								LightControllerRuntimeService.EndTriggerIllumination(lightConfig);
							}
							CS$<>8__locals1.<>4__this.Dispatcher.BeginInvoke(new Action(delegate()
							{
								try
								{
									HObject image;
									bool flag8 = error != null || image == null || !image.IsInitialized();
									if (flag8)
									{
										CS$<>8__locals1.<>4__this.AddHomeLog("Error", "Triggered camera capture failed. Camera=" + CS$<>8__locals1.captureName + ((error != null) ? (", Error=" + error) : ", no image returned."));
										VisionErrorCodeService.WriteAsync(CS$<>8__locals1.<>4__this.GetCameraErrorCode(CS$<>8__locals1.captureName));
									}
									else
									{
										CS$<>8__locals1.<>4__this.CompleteCameraTriggerOnUi(CS$<>8__locals1.captureArgs, CS$<>8__locals1.captureState, image);
									}
								}
								catch (Exception ex3)
								{
									CS$<>8__locals1.<>4__this.AddHomeLog("Error", "Triggered processing failed. Camera=" + CS$<>8__locals1.captureName + ", Error=" + ex3.Message);
									string str2 = "[Trigger] CompleteCameraTriggerOnUi threw: ";
									Exception ex4 = ex3;
									Debug.WriteLine(str2 + ((ex4 != null) ? ex4.ToString() : null));
								}
								finally
								{
									HObject image = image;
									if (image != null)
									{
										image.Dispose();
									}
									object triggerCaptureSync2 = CS$<>8__locals1.<>4__this._triggerCaptureSync;
									lock (triggerCaptureSync2)
									{
										CS$<>8__locals1.<>4__this._triggerCapturesInProgress.Remove(CS$<>8__locals1.captureName);
									}
								}
							}), Array.Empty<object>());
						});
					}
				}
			}
		}

		// Token: 0x06001A59 RID: 6745 RVA: 0x0008CB44 File Offset: 0x0008AD44
		private bool RetryCameraTriggerWhenDisplayIsReady(CameraTriggerEventArgs e)
		{
			Form_home.<>c__DisplayClass82_0 CS$<>8__locals1 = new Form_home.<>c__DisplayClass82_0();
			CS$<>8__locals1.<>4__this = this;
			CS$<>8__locals1.e = e;
			bool flag = CS$<>8__locals1.e == null || string.IsNullOrWhiteSpace(CS$<>8__locals1.e.CameraName);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				string key = Form_home.GetCameraTriggerRetryKey(CS$<>8__locals1.e);
				int retryCount;
				bool flag2 = !this._triggerDisplayRetryCounts.TryGetValue(key, out retryCount);
				if (flag2)
				{
					retryCount = 0;
				}
				bool flag3 = retryCount >= 20;
				if (flag3)
				{
					this._triggerDisplayRetryCounts.Remove(key);
					result = false;
				}
				else
				{
					this._triggerDisplayRetryCounts[key] = retryCount + 1;
					bool flag4 = retryCount == 0;
					if (flag4)
					{
						this.AddHomeLog("Warn", "Home camera display is not ready yet. Waiting before running trigger. Camera=" + CS$<>8__locals1.e.CameraName);
					}
					bool flag5 = retryCount == 0 || this._cameraStates.Count == 0;
					if (flag5)
					{
						try
						{
							this.RefreshModelInfo();
							this._recipeService.LoadCurrentModelRecipe();
							MainWindow instance = MainWindow.instance;
							IEnumerable<CameraNode> cameras;
							if (instance == null)
							{
								cameras = null;
							}
							else
							{
								MainViewModel mainViewModel = instance.MainViewModel;
								cameras = ((mainViewModel != null) ? mainViewModel.Cameras : null);
							}
							ToolRuntimePreloadService.PreloadFromCameras(cameras);
							this.load_layout_Camera();
						}
						catch (Exception ex)
						{
							string str = "[Trigger] Preparing Home camera layout failed: ";
							Exception ex2 = ex;
							Debug.WriteLine(str + ((ex2 != null) ? ex2.ToString() : null));
						}
					}
					base.Dispatcher.BeginInvoke(new Action(delegate()
					{
						Form_home.<>c__DisplayClass82_0.<<RetryCameraTriggerWhenDisplayIsReady>b__0>d <<RetryCameraTriggerWhenDisplayIsReady>b__0>d = new Form_home.<>c__DisplayClass82_0.<<RetryCameraTriggerWhenDisplayIsReady>b__0>d();
						<<RetryCameraTriggerWhenDisplayIsReady>b__0>d.<>t__builder = AsyncVoidMethodBuilder.Create();
						<<RetryCameraTriggerWhenDisplayIsReady>b__0>d.<>4__this = CS$<>8__locals1;
						<<RetryCameraTriggerWhenDisplayIsReady>b__0>d.<>1__state = -1;
						<<RetryCameraTriggerWhenDisplayIsReady>b__0>d.<>t__builder.Start<Form_home.<>c__DisplayClass82_0.<<RetryCameraTriggerWhenDisplayIsReady>b__0>d>(ref <<RetryCameraTriggerWhenDisplayIsReady>b__0>d);
					}), Array.Empty<object>());
					result = true;
				}
			}
			return result;
		}

		// Token: 0x06001A5A RID: 6746 RVA: 0x0008CCC8 File Offset: 0x0008AEC8
		private void ClearCameraTriggerDisplayRetry(CameraTriggerEventArgs e)
		{
			bool flag = e == null;
			if (!flag)
			{
				this._triggerDisplayRetryCounts.Remove(Form_home.GetCameraTriggerRetryKey(e));
			}
		}

		// Token: 0x06001A5B RID: 6747 RVA: 0x0008CCF4 File Offset: 0x0008AEF4
		private bool IsCameraTriggerDisplayRetryPending(CameraTriggerEventArgs e)
		{
			return e != null && this._triggerDisplayRetryCounts.ContainsKey(Form_home.GetCameraTriggerRetryKey(e));
		}

		// Token: 0x06001A5C RID: 6748 RVA: 0x0008CD20 File Offset: 0x0008AF20
		private static string GetCameraTriggerRetryKey(CameraTriggerEventArgs e)
		{
			return (e.CameraName ?? string.Empty).Trim() + "|" + e.TurnSnapIndex.ToString();
		}

		// Token: 0x06001A5D RID: 6749 RVA: 0x0008CD60 File Offset: 0x0008AF60
		private void CompleteCameraTriggerOnUi(CameraTriggerEventArgs e, Form_home.HomeCameraDockState state, HObject image)
		{
			this.EnsureCameraTurnSnapsLoaded(state);
			state.Camera = (this.FindCameraNode(e.CameraName, (state.Dock == null) ? 0 : state.Dock.CameraIndex) ?? state.Camera);
			bool useSoftwareSelection = this.IsSoftwareTurnSnapOverrideEnabled(state);
			int turnSnapIndex = e.TurnSnapIndex + 1;
			TurnSnap turnSnap2;
			if (!useSoftwareSelection)
			{
				CameraNode camera = state.Camera;
				if (camera == null)
				{
					turnSnap2 = null;
				}
				else
				{
					ObservableCollection<TurnSnap> turnSnaps = camera.TurnSnaps;
					turnSnap2 = ((turnSnaps != null) ? turnSnaps.FirstOrDefault((TurnSnap x) => x.Index == turnSnapIndex) : null);
				}
			}
			else
			{
				turnSnap2 = state.SelectedTurnSnap;
			}
			TurnSnap turnSnap = turnSnap2;
			bool flag = turnSnap == null;
			if (flag)
			{
				string sourceText = useSoftwareSelection ? "software selected TurnSnap" : ("communication TurnSnap " + turnSnapIndex.ToString());
				this.AddHomeLog("Warn", "Trigger image was captured but " + sourceText + " was not found. Camera=" + e.CameraName);
			}
			else
			{
				state.SelectedTurnSnap = turnSnap;
				bool flag2 = !string.IsNullOrWhiteSpace(state.CameraName);
				if (flag2)
				{
					this._selectedTurnSnapByCamera[state.CameraName] = turnSnap;
				}
				this.RunSelectedTurnSnap(state, false, image);
			}
		}

		// Token: 0x06001A5E RID: 6750 RVA: 0x0008CE84 File Offset: 0x0008B084
		private void AddHomeLog(string level, string message)
		{
			Debug.WriteLine(string.Concat(new string[]
			{
				"[HomeLog] VisionLogControl=",
				(this.VisionLogControl == null) ? "NULL" : "ok",
				" | ",
				level,
				" | ",
				message
			}));
			try
			{
				VisionLogService.Log(level, message);
			}
			catch (Exception ex)
			{
				string str = "[HomeLog] AddLog threw: ";
				Exception ex2 = ex;
				Debug.WriteLine(str + ((ex2 != null) ? ex2.ToString() : null));
			}
		}

		// Token: 0x06001A5F RID: 6751 RVA: 0x0008CF18 File Offset: 0x0008B118
		private Form_home.HomeCameraDockState FindHomeCameraState(string cameraName)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraName);
			Form_home.HomeCameraDockState result;
			if (flag)
			{
				result = null;
			}
			else
			{
				foreach (Form_home.HomeCameraDockState state2 in this._cameraStates.Values)
				{
					bool flag2 = state2 == null;
					if (!flag2)
					{
						if (Form_home.IsSameCameraName(state2.CameraName, cameraName))
						{
							goto IL_94;
						}
						CameraNode camera4 = state2.Camera;
						if (Form_home.IsSameCameraName((camera4 != null) ? camera4.Name : null, cameraName))
						{
							goto IL_94;
						}
						CameraNode camera2 = state2.Camera;
						string left;
						if (camera2 == null)
						{
							left = null;
						}
						else
						{
							CameraItem cameraInfo = camera2.CameraInfo;
							left = ((cameraInfo != null) ? cameraInfo.CameraName : null);
						}
						bool flag3 = Form_home.IsSameCameraName(left, cameraName);
						IL_95:
						bool flag4 = flag3;
						if (flag4)
						{
							return state2;
						}
						continue;
						IL_94:
						flag3 = true;
						goto IL_95;
					}
				}
				CameraNode camera = this.FindCameraNode(cameraName, 0);
				bool flag5 = camera == null;
				if (flag5)
				{
					result = null;
				}
				else
				{
					result = this._cameraStates.Values.FirstOrDefault(delegate(Form_home.HomeCameraDockState state)
					{
						bool result2;
						if (((state != null) ? state.Camera : null) != null)
						{
							if (state.Camera != camera && state.Camera.Index != camera.Index)
							{
								CameraNode camera3 = state.Camera;
								string left2;
								if (camera3 == null)
								{
									left2 = null;
								}
								else
								{
									CameraItem cameraInfo2 = camera3.CameraInfo;
									left2 = ((cameraInfo2 != null) ? cameraInfo2.CameraName : null);
								}
								CameraItem cameraInfo3 = camera.CameraInfo;
								result2 = Form_home.IsSameCameraName(left2, (cameraInfo3 != null) ? cameraInfo3.CameraName : null);
							}
							else
							{
								result2 = true;
							}
						}
						else
						{
							result2 = false;
						}
						return result2;
					});
				}
			}
			return result;
		}

		// Token: 0x06001A60 RID: 6752 RVA: 0x0008D034 File Offset: 0x0008B234
		private static bool IsSameCameraName(string left, string right)
		{
			return !string.IsNullOrWhiteSpace(left) && !string.IsNullOrWhiteSpace(right) && string.Equals(left.Trim(), right.Trim(), StringComparison.OrdinalIgnoreCase);
		}

		// Token: 0x06001A61 RID: 6753 RVA: 0x0008D06C File Offset: 0x0008B26C
		private int GetCameraErrorCode(string cameraName)
		{
			bool flag = string.IsNullOrWhiteSpace(cameraName);
			int result;
			if (flag)
			{
				result = 1;
			}
			else
			{
				MainWindow instance = MainWindow.instance;
				ObservableCollection<CameraNode> observableCollection;
				if (instance == null)
				{
					observableCollection = null;
				}
				else
				{
					MainViewModel mainViewModel = instance.MainViewModel;
					observableCollection = ((mainViewModel != null) ? mainViewModel.Cameras : null);
				}
				ObservableCollection<CameraNode> cameras = observableCollection;
				bool flag2 = cameras != null;
				if (flag2)
				{
					foreach (CameraNode camera in cameras)
					{
						bool flag3 = camera == null;
						if (!flag3)
						{
							CameraItem cameraInfo = camera.CameraInfo;
							bool flag4 = Form_home.IsSameCameraName((cameraInfo != null) ? cameraInfo.CameraName : null, cameraName) || Form_home.IsSameCameraName(camera.Name, cameraName);
							if (flag4)
							{
								return (camera.Index > 0) ? camera.Index : 1;
							}
						}
					}
				}
				result = 1;
			}
			return result;
		}

		// Token: 0x06001A62 RID: 6754 RVA: 0x0008D150 File Offset: 0x0008B350
		private void HomeHWindow_MouseWheel(object sender, MouseWheelEventArgs e)
		{
			Form_home.HomeCameraDockState state = this.GetStateFromWindow(sender);
			if (state != null)
			{
				SettingDisplayController displayController = state.DisplayController;
				if (displayController != null)
				{
					displayController.MouseWheel(e);
				}
			}
		}

		// Token: 0x06001A63 RID: 6755 RVA: 0x0008D180 File Offset: 0x0008B380
		private void HomeHWindow_MouseDown(object sender, MouseButtonEventArgs e)
		{
			Form_home.HomeCameraDockState stateFromWindow = this.GetStateFromWindow(sender);
			SettingDisplayController controller = (stateFromWindow != null) ? stateFromWindow.DisplayController : null;
			bool flag = controller == null;
			if (!flag)
			{
				bool flag2 = e.ChangedButton == MouseButton.Left && e.ClickCount >= 2;
				if (flag2)
				{
					controller.MouseDoubleClick(e);
				}
				else
				{
					controller.MouseDown(e);
				}
			}
		}

		// Token: 0x06001A64 RID: 6756 RVA: 0x0008D1DC File Offset: 0x0008B3DC
		private void HomeHWindow_MouseMove(object sender, MouseEventArgs e)
		{
			Form_home.HomeCameraDockState state = this.GetStateFromWindow(sender);
			bool flag = ((state != null) ? state.DisplayController : null) == null;
			if (!flag)
			{
				state.DisplayController.MouseMove(e);
				bool flag2 = e.LeftButton == MouseButtonState.Pressed || e.MiddleButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed;
				if (!flag2)
				{
					this.UpdatePixelInspector(state, e);
				}
			}
		}

		// Token: 0x06001A65 RID: 6757 RVA: 0x0008D242 File Offset: 0x0008B442
		private void HomeHWindow_MouseLeave(object sender, MouseEventArgs e)
		{
			Form_home.HomeCameraDockState stateFromWindow = this.GetStateFromWindow(sender);
			if (stateFromWindow != null)
			{
				CameraDockItem dock = stateFromWindow.Dock;
				if (dock != null)
				{
					CameraDockView view = dock.View;
					if (view != null)
					{
						view.SetPixelInfo(null);
					}
				}
			}
		}

		// Token: 0x06001A66 RID: 6758 RVA: 0x0008D26F File Offset: 0x0008B46F
		private void HomeHWindow_MouseUp(object sender, MouseButtonEventArgs e)
		{
			Form_home.HomeCameraDockState stateFromWindow = this.GetStateFromWindow(sender);
			if (stateFromWindow != null)
			{
				SettingDisplayController displayController = stateFromWindow.DisplayController;
				if (displayController != null)
				{
					displayController.MouseUp(e);
				}
			}
		}

		// Token: 0x06001A67 RID: 6759 RVA: 0x0008D291 File Offset: 0x0008B491
		private void HomeHWindow_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			Form_home.HomeCameraDockState stateFromWindow = this.GetStateFromWindow(sender);
			if (stateFromWindow != null)
			{
				SettingDisplayController displayController = stateFromWindow.DisplayController;
				if (displayController != null)
				{
					displayController.MouseDoubleClick(e);
				}
			}
		}

		// Token: 0x06001A68 RID: 6760 RVA: 0x0008D2B3 File Offset: 0x0008B4B3
		private void HomeHWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			Form_home.HomeCameraDockState stateFromWindow = this.GetStateFromWindow(sender);
			if (stateFromWindow != null)
			{
				SettingDisplayController displayController = stateFromWindow.DisplayController;
				if (displayController != null)
				{
					displayController.RedrawAfterLayoutChanged();
				}
			}
		}

		// Token: 0x06001A69 RID: 6761 RVA: 0x0008D2D4 File Offset: 0x0008B4D4
		public void UpdatePixelInspectorFromCameraDock(object sender, MouseEventArgs e)
		{
			Form_home.HomeCameraDockState state = this.GetStateFromView(sender);
			bool flag = ((state != null) ? state.DisplayController : null) == null;
			if (!flag)
			{
				this.UpdatePixelInspector(state, e);
			}
		}

		// Token: 0x06001A6A RID: 6762 RVA: 0x0008D308 File Offset: 0x0008B508
		private void UpdatePixelInspector(Form_home.HomeCameraDockState state, MouseEventArgs e)
		{
			bool flag;
			if (state == null)
			{
				flag = (null != null);
			}
			else
			{
				CameraDockItem dock = state.Dock;
				flag = (((dock != null) ? dock.View : null) != null);
			}
			bool flag2 = !flag || state.DisplayController == null || state.Dock.HWindowControl == null;
			if (!flag2)
			{
				DateTime now = DateTime.UtcNow;
				bool flag3 = (now - this._lastPixelInspectorUpdateUtc).TotalMilliseconds < 33.0;
				if (!flag3)
				{
					this._lastPixelInspectorUpdateUtc = now;
					try
					{
						PixelInspectionResult pixel;
						bool flag4 = !state.DisplayController.TryInspectPixel(e.GetPosition(state.Dock.HWindowControl), out pixel);
						if (flag4)
						{
							state.Dock.View.SetPixelInfo(null);
						}
						else
						{
							string sizeText = "- x -";
							HObject image = state.DisplayController.CurrentImage;
							bool flag5 = image != null && image.IsInitialized();
							if (flag5)
							{
								HTuple width;
								HTuple height;
								HOperatorSet.GetImageSize(image, out width, out height);
								sizeText = string.Format("{0} x {1}", width.I, height.I);
							}
							string rgbText = (pixel.Red != null) ? string.Format("R:{0:0.#}, G:{1:0.#}, B:{2:0.#}", pixel.Red.Value, pixel.Green.Value, pixel.Blue.Value) : "-";
							state.Dock.View.SetPixelInfo(string.Format("Row: {0}, Col: {1}, Gray: {2:0.#}, RGB: {3}, Size: {4}", new object[]
							{
								pixel.Row,
								pixel.Column,
								pixel.Gray,
								rgbText,
								sizeText
							}));
						}
					}
					catch
					{
						state.Dock.View.SetPixelInfo(null);
					}
				}
			}
		}

		// Token: 0x06001A6B RID: 6763 RVA: 0x0008D514 File Offset: 0x0008B714
		private void DisposeCameraStates()
		{
			foreach (Form_home.HomeCameraDockState state in this._cameraStates.Values)
			{
				object obj;
				if (state == null)
				{
					obj = null;
				}
				else
				{
					CameraDockItem dock = state.Dock;
					obj = ((dock != null) ? dock.HWindowControl : null);
				}
				bool flag = obj != null;
				if (flag)
				{
					state.Dock.HWindowControl.RemoveHandler(UIElement.PreviewMouseWheelEvent, new MouseWheelEventHandler(this.HomeHWindow_MouseWheel));
					state.Dock.HWindowControl.RemoveHandler(UIElement.PreviewMouseMoveEvent, new MouseEventHandler(this.HomeHWindow_MouseMove));
					state.Dock.HWindowControl.RemoveHandler(UIElement.PreviewMouseDownEvent, new MouseButtonEventHandler(this.HomeHWindow_MouseDown));
					state.Dock.HWindowControl.RemoveHandler(UIElement.PreviewMouseUpEvent, new MouseButtonEventHandler(this.HomeHWindow_MouseUp));
					state.Dock.HWindowControl.RemoveHandler(Control.PreviewMouseDoubleClickEvent, new MouseButtonEventHandler(this.HomeHWindow_MouseDoubleClick));
					state.Dock.HWindowControl.RemoveHandler(UIElement.MouseLeaveEvent, new MouseEventHandler(this.HomeHWindow_MouseLeave));
					state.Dock.HWindowControl.SizeChanged -= this.HomeHWindow_SizeChanged;
				}
				object obj2;
				if (state == null)
				{
					obj2 = null;
				}
				else
				{
					CameraDockItem dock2 = state.Dock;
					obj2 = ((dock2 != null) ? dock2.View : null);
				}
				bool flag2 = obj2 != null;
				if (flag2)
				{
					state.Dock.View.OpenRequested -= this.CameraDock_OpenRequested;
					state.Dock.View.RunRequested -= this.CameraDock_RunRequested;
					state.Dock.View.SettingRequested -= this.CameraDock_SettingRequested;
					bool flag3 = state.Dock.View.HomeHost == this;
					if (flag3)
					{
						state.Dock.View.HomeHost = null;
					}
				}
				if (state != null)
				{
					SettingDisplayController displayController = state.DisplayController;
					if (displayController != null)
					{
						displayController.Dispose();
					}
				}
			}
			this._cameraStates.Clear();
		}

		// Token: 0x06001A6C RID: 6764 RVA: 0x0008D754 File Offset: 0x0008B954
		protected override void OnClosed(EventArgs e)
		{
			this._homeStatusTimer.Stop();
			this._homeStatusTimer.Tick -= this.HomeStatusTimer_Tick;
			bool flag = this._cameraBadgeTimer != null;
			if (flag)
			{
				this._cameraBadgeTimer.Stop();
				this._cameraBadgeTimer = null;
			}
			this.StopHardwareTriggerCameras();
			this.DisposeCameraStates();
			base.OnClosed(e);
		}

		// Token: 0x06001A6F RID: 6767 RVA: 0x0008D8BC File Offset: 0x0008BABC
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 2)
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = UIElement.PreviewMouseRightButtonUpEvent;
				eventSetter.Handler = new MouseButtonEventHandler(this.ModelListItem_PreviewMouseRightButtonUp);
				((Style)target).Setters.Add(eventSetter);
			}
		}

		// Token: 0x04000AE2 RID: 2786
		private readonly List<CameraDockItem> _cameraDocks = new List<CameraDockItem>();

		// Token: 0x04000AE3 RID: 2787
		private readonly Dictionary<object, Form_home.HomeCameraDockState> _cameraStates = new Dictionary<object, Form_home.HomeCameraDockState>();

		// Token: 0x04000AE4 RID: 2788
		private readonly Dictionary<string, TurnSnap> _selectedTurnSnapByCamera = new Dictionary<string, TurnSnap>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000AE5 RID: 2789
		private readonly HashSet<string> _softwareTurnSnapOverrideCameras = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000AE6 RID: 2790
		private readonly Dictionary<string, IDisposable> _hardwareTriggerServices = new Dictionary<string, IDisposable>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000AE7 RID: 2791
		private readonly HashSet<string> _hardwareTriggerServiceStarting = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000AE8 RID: 2792
		private readonly ToolActionDispatcher _toolActionDispatcher = new ToolActionDispatcher();

		// Token: 0x04000AE9 RID: 2793
		private readonly ToolTrialRunPipelineService _homePipelineService = new ToolTrialRunPipelineService();

		// Token: 0x04000AEA RID: 2794
		private readonly SettingRecipeService _recipeService = new SettingRecipeService();

		// Token: 0x04000AEB RID: 2795
		private readonly DispatcherTimer _homeStatusTimer = new DispatcherTimer();

		// Token: 0x04000AEC RID: 2796
		private DispatcherTimer _cameraBadgeTimer;

		// Token: 0x04000AED RID: 2797
		private bool _homeReadyLogged;

		// Token: 0x04000AEE RID: 2798
		private bool _isSwitchingModel;

		// Token: 0x04000AEF RID: 2799
		private DateTime _lastPixelInspectorUpdateUtc = DateTime.MinValue;

		// Token: 0x04000AF0 RID: 2800
		private readonly HashSet<string> _triggerCapturesInProgress = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000AF1 RID: 2801
		private readonly object _triggerCaptureSync = new object();

		// Token: 0x04000AF2 RID: 2802
		private readonly Dictionary<string, int> _triggerDisplayRetryCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x04000AF3 RID: 2803
		private const int MaxTriggerDisplayRetryCount = 20;

		// Token: 0x04000AF4 RID: 2804
		private const int TriggerDisplayRetryDelayMs = 250;

		// Token: 0x04000AF5 RID: 2805
		private static readonly object PendingTriggerSync = new object();

		// Token: 0x04000AF6 RID: 2806
		private static readonly List<CameraTriggerEventArgs> PendingCameraTriggers = new List<CameraTriggerEventArgs>();

		// Token: 0x04000AF7 RID: 2807
		private static readonly List<CameraTriggerDiagnosticEventArgs> PendingTriggerDiagnostics = new List<CameraTriggerDiagnosticEventArgs>();

		// Token: 0x04000AF8 RID: 2808
		private static Form_home _instance;

		// Token: 0x04000AF9 RID: 2809
		private ModelConfig _rightClickedModel;

		// Token: 0x020003CF RID: 975
		private sealed class HomeCameraDockState
		{
			// Token: 0x17000B69 RID: 2921
			// (get) Token: 0x06002A03 RID: 10755 RVA: 0x000E4D4D File Offset: 0x000E2F4D
			// (set) Token: 0x06002A04 RID: 10756 RVA: 0x000E4D55 File Offset: 0x000E2F55
			public CameraDockItem Dock { get; set; }

			// Token: 0x17000B6A RID: 2922
			// (get) Token: 0x06002A05 RID: 10757 RVA: 0x000E4D5E File Offset: 0x000E2F5E
			// (set) Token: 0x06002A06 RID: 10758 RVA: 0x000E4D66 File Offset: 0x000E2F66
			public CameraNode Camera { get; set; }

			// Token: 0x17000B6B RID: 2923
			// (get) Token: 0x06002A07 RID: 10759 RVA: 0x000E4D6F File Offset: 0x000E2F6F
			// (set) Token: 0x06002A08 RID: 10760 RVA: 0x000E4D77 File Offset: 0x000E2F77
			public string CameraName { get; set; }

			// Token: 0x17000B6C RID: 2924
			// (get) Token: 0x06002A09 RID: 10761 RVA: 0x000E4D80 File Offset: 0x000E2F80
			// (set) Token: 0x06002A0A RID: 10762 RVA: 0x000E4D88 File Offset: 0x000E2F88
			public TurnSnap SelectedTurnSnap { get; set; }

			// Token: 0x17000B6D RID: 2925
			// (get) Token: 0x06002A0B RID: 10763 RVA: 0x000E4D91 File Offset: 0x000E2F91
			// (set) Token: 0x06002A0C RID: 10764 RVA: 0x000E4D99 File Offset: 0x000E2F99
			public SettingDisplayController DisplayController { get; set; }
		}
	}
}
