﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Views.Home
{
	// Token: 0x020001C0 RID: 448
	internal sealed class HomeRunOverlayState : IDisposable
	{
		// Token: 0x170008AF RID: 2223
		// (get) Token: 0x06001A1D RID: 6685 RVA: 0x00088D85 File Offset: 0x00086F85
		public List<HomeRunToolOverlayResult> Results { get; } = new List<HomeRunToolOverlayResult>();

		// Token: 0x06001A1E RID: 6686 RVA: 0x00088D90 File Offset: 0x00086F90
		public void Dispose()
		{
			foreach (HomeRunToolOverlayResult item in this.Results)
			{
				IDisposable disposable = ((item != null) ? item.Result : null) as IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			this.Results.Clear();
		}
	}
}
