﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.Views.Home
{
	// Token: 0x020001BF RID: 447
	internal sealed class HomeRunToolOverlayResult
	{
		// Token: 0x170008AD RID: 2221
		// (get) Token: 0x06001A18 RID: 6680 RVA: 0x00088D63 File Offset: 0x00086F63
		// (set) Token: 0x06001A19 RID: 6681 RVA: 0x00088D6B File Offset: 0x00086F6B
		public ToolVision Tool { get; set; }

		// Token: 0x170008AE RID: 2222
		// (get) Token: 0x06001A1A RID: 6682 RVA: 0x00088D74 File Offset: 0x00086F74
		// (set) Token: 0x06001A1B RID: 6683 RVA: 0x00088D7C File Offset: 0x00086F7C
		public object Result { get; set; }
	}
}
