﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Services.Licensing;
using VisionMachine.Services.Localization;
using VisionMachine.Services.Security;
using VisionMachine.Views.Security;

namespace VisionMachine.Views.License
{
	// Token: 0x020001D4 RID: 468
	public partial class LicenseExpiredWindow : ThemedWindow
	{
		// Token: 0x17000906 RID: 2310
		// (get) Token: 0x06001C9D RID: 7325 RVA: 0x000A0D01 File Offset: 0x0009EF01
		// (set) Token: 0x06001C9E RID: 7326 RVA: 0x000A0D09 File Offset: 0x0009EF09
		public bool LicenseRenewed { get; private set; }

		// Token: 0x06001C9F RID: 7327 RVA: 0x000A0D14 File Offset: 0x0009EF14
		public static LicenseExpiredWindow ForMissingLicense()
		{
			return new LicenseExpiredWindow();
		}

		// Token: 0x06001CA0 RID: 7328 RVA: 0x000A0D2C File Offset: 0x0009EF2C
		private LicenseExpiredWindow()
		{
			this.InitializeComponent();
			this._licenseMissing = true;
			base.Title = LanguageService.GetString("LicenseMissing_Title");
			this.HeaderTitleText.Text = base.Title;
			this.LeadText.Text = LanguageService.GetString("LicenseMissing_Lead");
			this.BlockedText.Text = LanguageService.GetString("LicenseMissing_BlockedText");
			this.ExpiryRow.Height = new GridLength(0.0);
			this.EditionRow.Height = new GridLength(0.0);
			this.ExpiryDateLabel.Visibility = Visibility.Collapsed;
			this.ExpiryDateText.Visibility = Visibility.Collapsed;
			this.EditionLabel.Visibility = Visibility.Collapsed;
			this.EditionText.Visibility = Visibility.Collapsed;
			this.MachineIdText.Text = MachineIdService.GetMachineId();
		}

		// Token: 0x06001CA1 RID: 7329 RVA: 0x000A0E18 File Offset: 0x0009F018
		public LicenseExpiredWindow(LicenseState expiredLicense)
		{
			bool flag = expiredLicense == null;
			if (flag)
			{
				throw new ArgumentNullException("expiredLicense");
			}
			this.InitializeComponent();
			this.ExpiryDateText.Text = ((expiredLicense.ExpiresAt != null) ? expiredLicense.ExpiresAt.Value.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.CurrentCulture) : "-");
			this.EditionText.Text = (expiredLicense.Edition ?? "-");
			this.MachineIdText.Text = (expiredLicense.MachineId ?? "-");
		}

		// Token: 0x06001CA2 RID: 7330 RVA: 0x000A0EC0 File Offset: 0x0009F0C0
		private void CopyMachineId_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Clipboard.SetText(this.MachineIdText.Text ?? string.Empty);
				this.CopyMachineIdButton.Content = LanguageService.GetString("LicenseGate_Copied");
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06001CA3 RID: 7331 RVA: 0x000A0F18 File Offset: 0x0009F118
		private void LicenseKeyText_KeyDown(object sender, KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				this.Activate_Click(sender, e);
				e.Handled = true;
			}
		}

		// Token: 0x06001CA4 RID: 7332 RVA: 0x000A0F48 File Offset: 0x0009F148
		private void Activate_Click(object sender, RoutedEventArgs e)
		{
			LicenseCheckResult result = LicenseService.Activate(this.LicenseKeyText.Text);
			bool flag = !result.Success;
			if (flag)
			{
				this.ShowMessage(UiTranslator.Translate(result.Message));
			}
			else
			{
				this.LicenseRenewed = true;
				base.DialogResult = new bool?(true);
			}
		}

		// Token: 0x06001CA5 RID: 7333 RVA: 0x000A0FA0 File Offset: 0x0009F1A0
		private void AdminRenew_Click(object sender, RoutedEventArgs e)
		{
			bool flag = !AdminSessionService.IsSignedIn;
			if (flag)
			{
				AdminLoginWindow login = new AdminLoginWindow
				{
					Owner = this
				};
				login.ShowDialog();
				bool flag2 = !login.SignedIn || !AdminSessionService.IsSignedIn;
				if (flag2)
				{
					this.ShowStatus("LicenseExpired_AdminRequired");
					return;
				}
			}
			LicenseIssueWindow issue = new LicenseIssueWindow
			{
				Owner = this
			};
			issue.ShowDialog();
			LicenseState current = LicenseService.GetState();
			bool flag3 = current != null && current.IsActivated;
			if (flag3)
			{
				this.LicenseRenewed = true;
				base.DialogResult = new bool?(true);
			}
			else
			{
				this.ShowStatus(this._licenseMissing ? "LicenseMissing_ActivateStillRequired" : "LicenseExpired_RenewStillRequired");
			}
		}

		// Token: 0x06001CA6 RID: 7334 RVA: 0x000A1059 File Offset: 0x0009F259
		private void Exit_Click(object sender, RoutedEventArgs e)
		{
			this.LicenseRenewed = false;
			base.DialogResult = new bool?(false);
		}

		// Token: 0x06001CA7 RID: 7335 RVA: 0x000A1071 File Offset: 0x0009F271
		private void ShowStatus(string resourceKey)
		{
			this.ShowMessage(LanguageService.GetString(resourceKey));
		}

		// Token: 0x06001CA8 RID: 7336 RVA: 0x000A1081 File Offset: 0x0009F281
		private void ShowMessage(string message)
		{
			this.ActionStatusText.Text = message;
			this.ActionStatusText.Visibility = Visibility.Visible;
		}

		// Token: 0x04000C17 RID: 3095
		private readonly bool _licenseMissing;
	}
}
