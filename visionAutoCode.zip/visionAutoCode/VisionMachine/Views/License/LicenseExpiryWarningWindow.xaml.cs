﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Services.Licensing;
using VisionMachine.Services.Localization;

namespace VisionMachine.Views.License
{
	// Token: 0x020001D3 RID: 467
	public partial class LicenseExpiryWarningWindow : ThemedWindow
	{
		// Token: 0x17000905 RID: 2309
		// (get) Token: 0x06001C95 RID: 7317 RVA: 0x000A0A4B File Offset: 0x0009EC4B
		// (set) Token: 0x06001C96 RID: 7318 RVA: 0x000A0A53 File Offset: 0x0009EC53
		public bool RenewRequested { get; private set; }

		// Token: 0x06001C97 RID: 7319 RVA: 0x000A0A5C File Offset: 0x0009EC5C
		public LicenseExpiryWarningWindow(LicenseExpiryWarningInfo warning)
		{
			bool flag = warning == null || warning.License == null;
			if (flag)
			{
				throw new ArgumentNullException("warning");
			}
			this.InitializeComponent();
			this._warning = warning;
			this.ExpiryLeadText.Text = string.Format(CultureInfo.CurrentCulture, LanguageService.GetString("LicenseWarning_ExpiresInFormat"), warning.DaysRemaining);
			this.DaysText.Text = ((warning.DaysRemaining == 0) ? LanguageService.GetString("LicenseWarning_Today") : string.Format(CultureInfo.CurrentCulture, LanguageService.GetString("LicenseWarning_DaysFormat"), warning.DaysRemaining));
			this.ExpiryDateText.Text = ((warning.License.ExpiresAt != null) ? warning.License.ExpiresAt.Value.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.CurrentCulture) : "-");
			this.EditionText.Text = (warning.License.Edition ?? "-");
			this.MachineIdText.Text = (warning.License.MachineId ?? "-");
		}

		// Token: 0x06001C98 RID: 7320 RVA: 0x000A0B94 File Offset: 0x0009ED94
		private void RemindLater_Click(object sender, RoutedEventArgs e)
		{
			this.Snooze();
			base.DialogResult = new bool?(false);
		}

		// Token: 0x06001C99 RID: 7321 RVA: 0x000A0BAB File Offset: 0x0009EDAB
		private void RenewNow_Click(object sender, RoutedEventArgs e)
		{
			this.RenewRequested = true;
			base.DialogResult = new bool?(true);
		}

		// Token: 0x06001C9A RID: 7322 RVA: 0x000A0BC4 File Offset: 0x0009EDC4
		private void Snooze()
		{
			bool flag = this._warning.License.ExpiresAt != null;
			if (flag)
			{
				LicenseExpiryWarningService.SnoozeUntilTomorrow(this._warning.License.ExpiresAt.Value);
			}
		}

		// Token: 0x04000C0F RID: 3087
		private readonly LicenseExpiryWarningInfo _warning;
	}
}
