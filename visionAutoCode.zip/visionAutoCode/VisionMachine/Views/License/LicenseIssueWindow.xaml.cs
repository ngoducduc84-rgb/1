﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using Microsoft.Win32;
using VisionMachine.Services.Licensing;

namespace VisionMachine.Views.License
{
	// Token: 0x020001D1 RID: 465
	public partial class LicenseIssueWindow : ThemedWindow
	{
		// Token: 0x06001C7C RID: 7292 RVA: 0x0009FAE4 File Offset: 0x0009DCE4
		public LicenseIssueWindow()
		{
			this.InitializeComponent();
			this.PackageCombo.ItemsSource = (from x in LicenseService.GetEditions()
			select x.Value).ToList<string>();
			this.LoadDefaults();
			this._loading = false;
			this.Regenerate();
		}

		// Token: 0x06001C7D RID: 7293 RVA: 0x0009FB58 File Offset: 0x0009DD58
		private void LoadDefaults()
		{
			string machineId = MachineIdService.GetMachineId();
			this.MachineIdText.Text = ((machineId == "UNAVAILABLE") ? string.Empty : machineId);
			this.FixedPeriodOption.IsChecked = new bool?(true);
			this.ExpiryDate.DateTime = DateTime.Today.AddYears(1);
			this.PackageCombo.EditValue = "Professional";
		}

		// Token: 0x06001C7E RID: 7294 RVA: 0x0009FBCA File Offset: 0x0009DDCA
		private void MachineId_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.Regenerate();
		}

		// Token: 0x06001C7F RID: 7295 RVA: 0x0009FBCA File Offset: 0x0009DDCA
		private void Option_Checked(object sender, RoutedEventArgs e)
		{
			this.Regenerate();
		}

		// Token: 0x06001C80 RID: 7296 RVA: 0x0009FBCA File Offset: 0x0009DDCA
		private void Editor_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			this.Regenerate();
		}

		// Token: 0x06001C81 RID: 7297 RVA: 0x0009FBD4 File Offset: 0x0009DDD4
		private void Regenerate()
		{
			bool loading = this._loading;
			if (!loading)
			{
				bool perpetual = this.PerpetualOption.IsChecked.GetValueOrDefault();
				Visibility dateVisibility = perpetual ? Visibility.Collapsed : Visibility.Visible;
				this.ExpiryLabel.Visibility = dateVisibility;
				this.ExpiryDate.Visibility = dateVisibility;
				this.ExpiryHint.Visibility = dateVisibility;
				string machineId = MachineIdService.Normalize(this.MachineIdText.Text);
				bool flag = machineId == null;
				if (flag)
				{
					this.ShowNoKey("Enter the machine code of the device, for example 7F3C-9B21-5E8A-4D01-9C36-2A7B-8F11.");
				}
				else
				{
					bool flag2 = perpetual;
					DateTime expiry;
					if (flag2)
					{
						expiry = LicenseService.PerpetualDate;
					}
					else
					{
						bool flag3 = this.ExpiryDate.DateTime == DateTime.MinValue;
						if (flag3)
						{
							this.ShowNoKey("Choose the date the license expires.");
							return;
						}
						expiry = this.ExpiryDate.DateTime.Date;
						bool flag4 = expiry < DateTime.Today;
						if (flag4)
						{
							this.ShowNoKey("The expiry date is in the past. Choose today or later.");
							return;
						}
					}
					string package = Convert.ToString(this.PackageCombo.EditValue);
					char code = LicenseService.GetEditionCode(package);
					bool flag5 = code == '\0';
					if (flag5)
					{
						this.ShowNoKey("Choose the package this license grants.");
					}
					else
					{
						this.LicenseKeyText.Text = LicenseService.IssueKey(machineId, expiry, code);
						this.CopyButton.IsEnabled = true;
						this.ExportButton.IsEnabled = true;
						this.SummaryMachineText.Text = "Machine ID: " + machineId;
						this.SummaryPackageText.Text = "Package: " + package;
						this.SummaryExpiryText.Text = "Expires: " + (perpetual ? "never" : (expiry.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) + " 23:59:59"));
					}
				}
			}
		}

		// Token: 0x06001C82 RID: 7298 RVA: 0x0009FDB0 File Offset: 0x0009DFB0
		private void ShowNoKey(string reason)
		{
			this.LicenseKeyText.Text = string.Empty;
			this.CopyButton.IsEnabled = false;
			this.ExportButton.IsEnabled = false;
			this.SummaryMachineText.Text = reason;
			this.SummaryPackageText.Text = string.Empty;
			this.SummaryExpiryText.Text = string.Empty;
		}

		// Token: 0x06001C83 RID: 7299 RVA: 0x0009FE18 File Offset: 0x0009E018
		private void Paste_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				bool flag = Clipboard.ContainsText();
				if (flag)
				{
					this.MachineIdText.Text = Clipboard.GetText().Trim();
				}
			}
			catch (Exception ex)
			{
				this.Warn("The clipboard could not be read: " + ex.Message);
			}
		}

		// Token: 0x06001C84 RID: 7300 RVA: 0x0009FE78 File Offset: 0x0009E078
		private void Copy_Click(object sender, RoutedEventArgs e)
		{
			bool flag = string.IsNullOrWhiteSpace(this.LicenseKeyText.Text);
			if (!flag)
			{
				try
				{
					Clipboard.SetText(this.LicenseKeyText.Text);
					this.CopyButton.Content = "Copied";
				}
				catch (Exception ex)
				{
					this.Warn("The license could not be copied: " + ex.Message);
				}
			}
		}

		// Token: 0x06001C85 RID: 7301 RVA: 0x0009FEF0 File Offset: 0x0009E0F0
		private void Reset_Click(object sender, RoutedEventArgs e)
		{
			this._loading = true;
			this.LoadDefaults();
			this._loading = false;
			this.CopyButton.Content = "Copy";
			this.Regenerate();
		}

		// Token: 0x06001C86 RID: 7302 RVA: 0x0009FF20 File Offset: 0x0009E120
		private void Export_Click(object sender, RoutedEventArgs e)
		{
			bool flag = string.IsNullOrWhiteSpace(this.LicenseKeyText.Text);
			if (!flag)
			{
				string machineId = MachineIdService.Normalize(this.MachineIdText.Text) ?? "machine";
				SaveFileDialog dialog = new SaveFileDialog
				{
					Title = "Export license",
					Filter = "License file (*.txt)|*.txt|All files (*.*)|*.*",
					DefaultExt = ".txt",
					FileName = "license_" + machineId.Replace("-", string.Empty) + ".txt"
				};
				bool flag2 = !dialog.ShowDialog(this).GetValueOrDefault();
				if (!flag2)
				{
					StringBuilder text = new StringBuilder();
					text.AppendLine("VisionMachine license");
					text.AppendLine();
					text.AppendLine(this.SummaryMachineText.Text);
					text.AppendLine(this.SummaryPackageText.Text);
					text.AppendLine(this.SummaryExpiryText.Text);
					text.AppendLine("Issued: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture));
					text.AppendLine();
					text.AppendLine("License key:");
					text.AppendLine(this.LicenseKeyText.Text);
					try
					{
						File.WriteAllText(dialog.FileName, text.ToString());
						DXMessageBox.Show(this, "The license was saved to" + Environment.NewLine + dialog.FileName, "Issue License", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					}
					catch (Exception ex)
					{
						this.Warn("The license could not be saved: " + ex.Message);
					}
				}
			}
		}

		// Token: 0x06001C87 RID: 7303 RVA: 0x000A00D4 File Offset: 0x0009E2D4
		private void Warn(string message)
		{
			DXMessageBox.Show(this, message, "Issue License", MessageBoxButton.OK, MessageBoxImage.Exclamation);
		}

		// Token: 0x04000BE9 RID: 3049
		private bool _loading = true;
	}
}
