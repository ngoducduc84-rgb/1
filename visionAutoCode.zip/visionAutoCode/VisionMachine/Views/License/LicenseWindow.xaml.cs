﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using DevExpress.Xpf.Core;
using VisionMachine.Services.Licensing;
using VisionMachine.Services.Security;

namespace VisionMachine.Views.License
{
	// Token: 0x020001D2 RID: 466
	public partial class LicenseWindow : ThemedWindow
	{
		// Token: 0x06001C8A RID: 7306 RVA: 0x000A0348 File Offset: 0x0009E548
		public LicenseWindow()
		{
			this.InitializeComponent();
			this.MachineIdText.Text = MachineIdService.GetMachineId();
			this.ShowState(LicenseService.GetState(), null);
			this.IssueLicenseButton.Visibility = (AdminSessionService.IsSignedIn ? Visibility.Visible : Visibility.Collapsed);
		}

		// Token: 0x06001C8B RID: 7307 RVA: 0x000A039C File Offset: 0x0009E59C
		private void IssueLicense_Click(object sender, RoutedEventArgs e)
		{
			bool flag = !AdminSessionService.IsSignedIn;
			if (!flag)
			{
				LicenseIssueWindow window = new LicenseIssueWindow
				{
					Owner = this
				};
				window.ShowDialog();
			}
		}

		// Token: 0x06001C8C RID: 7308 RVA: 0x000A03D0 File Offset: 0x0009E5D0
		private void CopyMachineId_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Clipboard.SetText(this.MachineIdText.Text ?? string.Empty);
				this.CopyMachineIdButton.Content = "Copied";
			}
			catch (Exception ex)
			{
				DXMessageBox.Show(this, "The machine code could not be copied: " + ex.Message, "License", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}

		// Token: 0x06001C8D RID: 7309 RVA: 0x000A0444 File Offset: 0x0009E644
		private void LicenseKeyText_KeyDown(object sender, KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				this.Activate_Click(sender, e);
				e.Handled = true;
			}
		}

		// Token: 0x06001C8E RID: 7310 RVA: 0x000A0474 File Offset: 0x0009E674
		private void Activate_Click(object sender, RoutedEventArgs e)
		{
			LicenseCheckResult result = LicenseService.Activate(this.LicenseKeyText.Text);
			bool flag = !result.Success;
			if (flag)
			{
				this.ShowState(LicenseService.GetState(), result.Message);
				DXMessageBox.Show(this, result.Message, "License", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			else
			{
				this.LicenseKeyText.Text = string.Empty;
				this.ShowState(result.State, result.Message);
			}
		}

		// Token: 0x06001C8F RID: 7311 RVA: 0x000A04F0 File Offset: 0x0009E6F0
		private void Deactivate_Click(object sender, RoutedEventArgs e)
		{
			MessageBoxResult answer = DXMessageBox.Show(this, "Remove the activation from this computer?" + Environment.NewLine + Environment.NewLine + "The licence itself stays valid and can be activated again here or on another computer.", "License", MessageBoxButton.YesNo, MessageBoxImage.Question);
			bool flag = answer != MessageBoxResult.Yes;
			if (!flag)
			{
				LicenseService.Deactivate();
				this.ShowState(LicenseService.GetState(), null);
			}
		}

		// Token: 0x06001C90 RID: 7312 RVA: 0x0006553D File Offset: 0x0006373D
		private void Close_Click(object sender, RoutedEventArgs e)
		{
			base.Close();
		}

		// Token: 0x06001C91 RID: 7313 RVA: 0x000A0548 File Offset: 0x0009E748
		private void ShowState(LicenseState state, string message)
		{
			bool activated = state != null && state.IsActivated;
			Color colour = activated ? LicenseWindow.Green : LicenseWindow.Red;
			SolidColorBrush brush = new SolidColorBrush(colour);
			this.StatusIconHolder.Background = brush;
			this.StatusTitle.Foreground = brush;
			this.StatusTitle.Text = (activated ? "Activated" : "Not activated");
			this.StatusIcon.Data = Geometry.Parse(activated ? "M 3.6 12.4 L 0 16 L 9 25 L 26 8 L 22.4 4.4 L 9 17.8 Z" : "M 3 0 L 0 3 L 10 13 L 0 23 L 3 26 L 13 16 L 23 26 L 26 23 L 16 13 L 26 3 L 23 0 L 13 10 Z");
			this.StatusMessage.Text = (message ?? (activated ? "This software is activated on this computer." : "Enter a license to activate this software."));
			this.StatusDetails.Visibility = (activated ? Visibility.Visible : Visibility.Collapsed);
			this.DetailGrid.Visibility = (activated ? Visibility.Visible : Visibility.Collapsed);
			this.DeactivateButton.IsEnabled = activated;
			bool flag = !activated;
			if (!flag)
			{
				this.ExpiryValue.Text = (state.IsPerpetual ? "No expiry" : ((state.ExpiresAt != null) ? state.ExpiresAt.Value.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture) : "-"));
				this.ActivatedValue.Text = ((state.ActivatedAt != null) ? state.ActivatedAt.Value.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture) : "-");
				bool flag2 = state.ExpiresAt != null;
				if (flag2)
				{
					int days = (int)Math.Ceiling((state.ExpiresAt.Value - DateTime.Now).TotalDays);
					this.StateValue.Text = ((days > 0) ? ("Active (" + days.ToString() + " day(s) left)") : "Active (expires today)");
					this.ExpiryValue.Foreground = ((days <= 30) ? new SolidColorBrush(Color.FromRgb(251, 191, 36)) : new SolidColorBrush(LicenseWindow.Green));
				}
				else
				{
					this.StateValue.Text = "Active";
					this.ExpiryValue.Foreground = new SolidColorBrush(LicenseWindow.Green);
				}
				this.EditionValue.Text = (string.IsNullOrWhiteSpace(state.Edition) ? "-" : state.Edition);
			}
		}

		// Token: 0x04000BFA RID: 3066
		private static readonly Color Green = Color.FromRgb(74, 222, 128);

		// Token: 0x04000BFB RID: 3067
		private static readonly Color Red = Color.FromRgb(239, 68, 68);
	}
}
