﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using DevExpress.Xpf.Core;
using Microsoft.Win32;
using VisionMachine.Helpers;
using VisionMachine.Models.Config;
using VisionMachine.Services.Appearance;
using VisionMachine.Services.Runtime;
using VisionMachine.Services.Storage;
using VisionMachine.Views.Main;

namespace VisionMachine.Views.Logs
{
	// Token: 0x020001BE RID: 446
	public partial class Form_log : ThemedWindow, IStyleConnector
	{
		// Token: 0x170008AB RID: 2219
		// (get) Token: 0x060019D0 RID: 6608 RVA: 0x00086790 File Offset: 0x00084990
		public ObservableCollection<VisionLogEntry> VisibleLogs { get; } = new ObservableCollection<VisionLogEntry>();

		// Token: 0x170008AC RID: 2220
		// (get) Token: 0x060019D1 RID: 6609 RVA: 0x00086798 File Offset: 0x00084998
		public ObservableCollection<LogPageToken> PageTokens { get; } = new ObservableCollection<LogPageToken>();

		// Token: 0x060019D2 RID: 6610 RVA: 0x000867A0 File Offset: 0x000849A0
		public Form_log()
		{
			this.InitializeComponent();
			WpfThemeAdapter.SetPreserveColors(this, true);
			base.DataContext = this;
			this.EnsureInitialized();
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				this.RefreshFromStorage();
			}), DispatcherPriority.Loaded, Array.Empty<object>());
		}

		// Token: 0x060019D3 RID: 6611 RVA: 0x00086860 File Offset: 0x00084A60
		private void FormLog_Loaded(object sender, RoutedEventArgs e)
		{
			VisionLogService.EntryLogged -= this.VisionLogService_EntryLogged;
			VisionLogService.HistoryCleared -= this.VisionLogService_HistoryCleared;
			VisionLogService.EntryLogged += this.VisionLogService_EntryLogged;
			VisionLogService.HistoryCleared += this.VisionLogService_HistoryCleared;
			this.RefreshFromStorage();
		}

		// Token: 0x060019D4 RID: 6612 RVA: 0x000868BD File Offset: 0x00084ABD
		private void FormLog_Unloaded(object sender, RoutedEventArgs e)
		{
			VisionLogService.EntryLogged -= this.VisionLogService_EntryLogged;
			VisionLogService.HistoryCleared -= this.VisionLogService_HistoryCleared;
		}

		// Token: 0x060019D5 RID: 6613 RVA: 0x000868E4 File Offset: 0x00084AE4
		private void InitializeFilters()
		{
			this.LogList.ItemsSource = this.VisibleLogs;
			this.PageButtons.ItemsSource = this.PageTokens;
			this._fromDate = DateTime.Today;
			this._toDate = DateTime.Today.AddDays(1.0).AddSeconds(-1.0);
			this.WriteDateBoxes();
			LogSettingConfig logSettingConfig = LogSettingRuntimeStore.Current;
			string configuredPath = (logSettingConfig != null) ? logSettingConfig.SavePath : null;
			bool flag = string.IsNullOrWhiteSpace(configuredPath);
			if (flag)
			{
				configuredPath = Manager_path.path_vision_log;
			}
			VisionLogFileStore.Configure(configuredPath);
			this.LogPathEdit.Text = VisionLogFileStore.CurrentPath;
			this.LevelEdit.ItemsSource = new string[]
			{
				"All Levels",
				"Error",
				"Warning",
				"Info",
				"Success",
				"Trigger"
			};
			this.LevelEdit.SelectedIndex = 0;
			this.PageSizeEdit.ItemsSource = new int[]
			{
				25,
				50,
				100,
				200,
				500,
				1000
			};
			this.PageSizeEdit.SelectedItem = this._pageSize;
			this.UpdateKeywordWatermark();
		}

		// Token: 0x060019D6 RID: 6614 RVA: 0x00086A1C File Offset: 0x00084C1C
		private void EnsureInitialized()
		{
			bool initialized = this._initialized;
			if (!initialized)
			{
				this._suppressFilterEvents = true;
				try
				{
					this.InitializeFilters();
					this._initialized = true;
				}
				finally
				{
					this._suppressFilterEvents = false;
				}
			}
		}

		// Token: 0x060019D7 RID: 6615 RVA: 0x00086A6C File Offset: 0x00084C6C
		public void RefreshFromStorage()
		{
			bool flag = !base.Dispatcher.CheckAccess();
			if (flag)
			{
				base.Dispatcher.BeginInvoke(new Action(this.RefreshFromStorage), Array.Empty<object>());
			}
			else
			{
				this.EnsureInitialized();
				this.LoadStoredRange();
				this.RefreshData(true);
			}
		}

		// Token: 0x060019D8 RID: 6616 RVA: 0x00086AC4 File Offset: 0x00084CC4
		private void RefreshData(bool resetPage)
		{
			bool flag = !this._initialized;
			if (!flag)
			{
				bool valueOrDefault = this.FollowCurrentTimeEdit.IsChecked.GetValueOrDefault();
				if (valueOrDefault)
				{
					this._toDate = DateTime.Now;
					this.WriteDateBoxes();
				}
				IReadOnlyList<VisionLogEntry> snapshot = VisionLogService.GetSnapshot();
				this.RefreshSourceOptions(snapshot);
				string source = this.SourceEdit.SelectedItem as string;
				string keyword = (this.KeywordEdit.Text ?? string.Empty).Trim();
				IEnumerable<VisionLogEntry> baseQuery = from x in snapshot
				where x.Timestamp >= this._fromDate && x.Timestamp <= this._toDate && (string.IsNullOrWhiteSpace(source) || source == "All Modules" || string.Equals(x.Source, source, StringComparison.OrdinalIgnoreCase)) && Form_log.MatchesKeyword(x, keyword)
				select x;
				List<VisionLogEntry> summary = baseQuery.ToList<VisionLogEntry>();
				this.UpdateSummary(summary);
				string level = this.LevelEdit.SelectedItem as string;
				IEnumerable<VisionLogEntry> matching = from x in summary
				where Form_log.MatchesLevel(x.Level, level)
				select x;
				this._filteredLogs.Clear();
				List<VisionLogEntry> filteredLogs = this._filteredLogs;
				IEnumerable<VisionLogEntry> collection;
				if (!this._newestFirst)
				{
					collection = from x in matching
					orderby x.Timestamp
					select x;
				}
				else
				{
					collection = from x in matching
					orderby x.Timestamp descending
					select x;
				}
				filteredLogs.AddRange(collection);
				if (resetPage)
				{
					this._currentPage = 1;
				}
				int pageCount = Math.Max(1, (int)Math.Ceiling((double)this._filteredLogs.Count / (double)this._pageSize));
				this._currentPage = Math.Max(1, Math.Min(this._currentPage, pageCount));
				List<VisionLogEntry> page = this._filteredLogs.Skip((this._currentPage - 1) * this._pageSize).Take(this._pageSize).ToList<VisionLogEntry>();
				bool flag2 = !this.SamePage(page);
				if (flag2)
				{
					string selectedKey = Form_log.KeyOf(this.LogList.SelectedItem as VisionLogEntry);
					this.VisibleLogs.Clear();
					foreach (VisionLogEntry entry in page)
					{
						this.VisibleLogs.Add(entry);
					}
					this.RestoreSelection(selectedKey);
				}
				this.UpdateEmptyState(snapshot.Count, summary.Count);
				int first = (this._filteredLogs.Count == 0) ? 0 : ((this._currentPage - 1) * this._pageSize + 1);
				int last = Math.Min(this._currentPage * this._pageSize, this._filteredLogs.Count);
				this.PageInfoText.Text = string.Concat(new string[]
				{
					"Showing ",
					first.ToString(),
					" to ",
					last.ToString(),
					" of ",
					this._filteredLogs.Count.ToString(),
					" logs"
				});
				this.BuildPageTokens(pageCount);
				bool flag3 = this.VisibleLogs.Count == 0;
				if (flag3)
				{
					this.ShowDetails(null);
				}
			}
		}

		// Token: 0x060019D9 RID: 6617 RVA: 0x00086DFC File Offset: 0x00084FFC
		private static string KeyOf(VisionLogEntry entry)
		{
			return (entry == null) ? null : string.Concat(new string[]
			{
				entry.Timestamp.Ticks.ToString(),
				"|",
				entry.Level,
				"|",
				entry.Code,
				"|",
				entry.Message
			});
		}

		// Token: 0x060019DA RID: 6618 RVA: 0x00086E6C File Offset: 0x0008506C
		private bool SamePage(List<VisionLogEntry> page)
		{
			bool flag = page.Count != this.VisibleLogs.Count;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				for (int i = 0; i < page.Count; i++)
				{
					bool flag2 = !string.Equals(Form_log.KeyOf(page[i]), Form_log.KeyOf(this.VisibleLogs[i]), StringComparison.Ordinal);
					if (flag2)
					{
						return false;
					}
				}
				result = true;
			}
			return result;
		}

		// Token: 0x060019DB RID: 6619 RVA: 0x00086EE4 File Offset: 0x000850E4
		private void RestoreSelection(string selectedKey)
		{
			bool flag = this.VisibleLogs.Count == 0;
			if (flag)
			{
				this.ShowDetails(null);
			}
			else
			{
				bool flag2 = !string.IsNullOrEmpty(selectedKey);
				if (flag2)
				{
					foreach (VisionLogEntry entry in this.VisibleLogs)
					{
						bool flag3 = string.Equals(Form_log.KeyOf(entry), selectedKey, StringComparison.Ordinal);
						if (flag3)
						{
							this.LogList.SelectedItem = entry;
							this.ShowDetails(entry);
							return;
						}
					}
				}
				this.LogList.SelectedItem = this.VisibleLogs[0];
				this.ShowDetails(this.VisibleLogs[0]);
			}
		}

		// Token: 0x060019DC RID: 6620 RVA: 0x00086FB4 File Offset: 0x000851B4
		private void UpdateEmptyState(int loadedCount, int inRangeCount)
		{
			bool flag = this.VisibleLogs.Count > 0;
			if (flag)
			{
				this.EmptyText.Visibility = Visibility.Collapsed;
			}
			else
			{
				this.EmptyText.Visibility = Visibility.Visible;
				string range = this._fromDate.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture) + "  to  " + this._toDate.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
				bool flag2 = loadedCount == 0;
				if (flag2)
				{
					this.EmptyText.Text = string.Concat(new string[]
					{
						"No log has been loaded yet.",
						Environment.NewLine,
						Environment.NewLine,
						"Reading from: ",
						VisionLogFileStore.CurrentPath,
						Environment.NewLine,
						"If the folder is wrong, change it under the gear button."
					});
				}
				else
				{
					bool flag3 = inRangeCount == 0;
					if (flag3)
					{
						this.EmptyText.Text = string.Concat(new string[]
						{
							"No log falls inside",
							Environment.NewLine,
							range,
							Environment.NewLine,
							Environment.NewLine,
							"Entries from other days stay in their own daily files -",
							Environment.NewLine,
							"widen the time range to reach them."
						});
					}
					else
					{
						this.EmptyText.Text = inRangeCount.ToString() + " log(s) are in this time range, but none matches" + Environment.NewLine + "the selected level, module or keyword.";
					}
				}
			}
		}

		// Token: 0x060019DD RID: 6621 RVA: 0x0008710C File Offset: 0x0008530C
		private void BuildPageTokens(int pageCount)
		{
			this.PageTokens.Clear();
			List<int> pages = new List<int>();
			for (int page = 1; page <= pageCount; page++)
			{
				bool nearEdge = page <= 2 || page > pageCount - 1;
				bool nearCurrent = Math.Abs(page - this._currentPage) <= 1;
				bool flag = nearEdge || nearCurrent;
				if (flag)
				{
					pages.Add(page);
				}
			}
			int previous = 0;
			foreach (int page2 in pages)
			{
				bool flag2 = previous != 0 && page2 - previous > 1;
				if (flag2)
				{
					this.PageTokens.Add(new LogPageToken
					{
						Text = "...",
						IsGap = true
					});
				}
				this.PageTokens.Add(new LogPageToken
				{
					Text = page2.ToString(CultureInfo.InvariantCulture),
					Page = page2,
					IsCurrent = (page2 == this._currentPage)
				});
				previous = page2;
			}
		}

		// Token: 0x060019DE RID: 6622 RVA: 0x0008723C File Offset: 0x0008543C
		private void RefreshSourceOptions(IReadOnlyList<VisionLogEntry> snapshot)
		{
			string selected = this.SourceEdit.SelectedItem as string;
			List<string> values = (from x in (from x in snapshot
			select x.Source into x
			where !string.IsNullOrWhiteSpace(x)
			select x).Distinct(StringComparer.OrdinalIgnoreCase)
			orderby x
			select x).ToList<string>();
			bool previousSuppression = this._suppressFilterEvents;
			this._suppressFilterEvents = true;
			try
			{
				List<string> sourceItems = new List<string>
				{
					"All Modules"
				};
				sourceItems.AddRange(values);
				this.SourceEdit.ItemsSource = sourceItems;
				this.SourceEdit.SelectedItem = ((!string.IsNullOrWhiteSpace(selected) && sourceItems.Any((string x) => string.Equals(x, selected, StringComparison.OrdinalIgnoreCase))) ? selected : "All Modules");
			}
			finally
			{
				this._suppressFilterEvents = previousSuppression;
			}
		}

		// Token: 0x060019DF RID: 6623 RVA: 0x00087370 File Offset: 0x00085570
		private void UpdateSummary(IReadOnlyCollection<VisionLogEntry> entries)
		{
			this.AllCountText.Text = entries.Count.ToString(CultureInfo.InvariantCulture);
			this.ErrorCountText.Text = entries.Count((VisionLogEntry x) => x.Level == "ERROR").ToString(CultureInfo.InvariantCulture);
			this.WarningCountText.Text = entries.Count((VisionLogEntry x) => x.Level == "WARN").ToString(CultureInfo.InvariantCulture);
			this.InfoCountText.Text = entries.Count((VisionLogEntry x) => x.Level == "INFO" || x.Level == "TRIGGER").ToString(CultureInfo.InvariantCulture);
			this.SuccessCountText.Text = entries.Count((VisionLogEntry x) => x.Level == "SUCCESS").ToString(CultureInfo.InvariantCulture);
		}

		// Token: 0x060019E0 RID: 6624 RVA: 0x00087498 File Offset: 0x00085698
		private static bool MatchesKeyword(VisionLogEntry entry, string keyword)
		{
			bool flag = string.IsNullOrWhiteSpace(keyword);
			return flag || Form_log.Contains(entry.Message, keyword) || Form_log.Contains(entry.Source, keyword) || Form_log.Contains(entry.Code, keyword) || Form_log.Contains(entry.Details, keyword) || Form_log.Contains(entry.StackTrace, keyword);
		}

		// Token: 0x060019E1 RID: 6625 RVA: 0x00087500 File Offset: 0x00085700
		private static bool Contains(string text, string value)
		{
			return (text ?? string.Empty).IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x060019E2 RID: 6626 RVA: 0x0008752C File Offset: 0x0008572C
		private static bool MatchesLevel(string entryLevel, string filter)
		{
			bool flag = string.IsNullOrWhiteSpace(filter) || filter == "All Levels";
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				string level = (entryLevel ?? string.Empty).ToUpperInvariant();
				if (!(filter == "Error"))
				{
					if (!(filter == "Warning"))
					{
						if (!(filter == "Success"))
						{
							if (!(filter == "Trigger"))
							{
								result = (!(filter == "Info") || level == "INFO" || level == "TRIGGER");
							}
							else
							{
								result = (level == "TRIGGER");
							}
						}
						else
						{
							result = (level == "SUCCESS");
						}
					}
					else
					{
						result = (level == "WARN");
					}
				}
				else
				{
					result = (level == "ERROR");
				}
			}
			return result;
		}

		// Token: 0x060019E3 RID: 6627 RVA: 0x00087610 File Offset: 0x00085810
		private void VisionLogService_EntryLogged(VisionLogEntry entry)
		{
			bool flag = Interlocked.Exchange(ref this._refreshQueued, 1) != 0;
			if (!flag)
			{
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					Interlocked.Exchange(ref this._refreshQueued, 0);
					this.RefreshData(false);
				}), Array.Empty<object>());
			}
		}

		// Token: 0x060019E4 RID: 6628 RVA: 0x00087650 File Offset: 0x00085850
		private void VisionLogService_HistoryCleared()
		{
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				this.RefreshData(true);
			}), Array.Empty<object>());
		}

		// Token: 0x060019E5 RID: 6629 RVA: 0x00087670 File Offset: 0x00085870
		private void FilterChanged(object sender, SelectionChangedEventArgs e)
		{
			bool suppressFilterEvents = this._suppressFilterEvents;
			if (!suppressFilterEvents)
			{
				this.RefreshData(true);
			}
		}

		// Token: 0x060019E6 RID: 6630 RVA: 0x00087692 File Offset: 0x00085892
		private void KeywordEdit_TextChanged(object sender, TextChangedEventArgs e)
		{
			this.UpdateKeywordWatermark();
		}

		// Token: 0x060019E7 RID: 6631 RVA: 0x0008769C File Offset: 0x0008589C
		private void UpdateKeywordWatermark()
		{
			bool flag = this.KeywordWatermark == null || this.KeywordEdit == null;
			if (!flag)
			{
				this.KeywordWatermark.Visibility = (string.IsNullOrEmpty(this.KeywordEdit.Text) ? Visibility.Visible : Visibility.Collapsed);
			}
		}

		// Token: 0x060019E8 RID: 6632 RVA: 0x000876E8 File Offset: 0x000858E8
		private void KeywordEdit_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				this.RefreshData(true);
			}
		}

		// Token: 0x060019E9 RID: 6633 RVA: 0x0008770B File Offset: 0x0008590B
		private void TimeHeader_Click(object sender, MouseButtonEventArgs e)
		{
			this._newestFirst = !this._newestFirst;
			this.SortGlyph.Data = Geometry.Parse(this._newestFirst ? "M5,0 L9,5 L1,5 Z M5,11 L1,6 L9,6 Z" : "M5,11 L9,6 L1,6 Z M5,0 L1,5 L9,5 Z");
			this.RefreshData(true);
		}

		// Token: 0x060019EA RID: 6634 RVA: 0x0008774C File Offset: 0x0008594C
		private void WriteDateBoxes()
		{
			bool flag = this.FromDateEdit == null || this.ToDateEdit == null;
			if (!flag)
			{
				this.FromDateEdit.Text = this._fromDate.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
				this.ToDateEdit.Text = this._toDate.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
			}
		}

		// Token: 0x060019EB RID: 6635 RVA: 0x000877B8 File Offset: 0x000859B8
		private void CommitDateBoxes()
		{
			DateTime parsed;
			bool flag = Form_log.TryParseDate(this.FromDateEdit.Text, out parsed);
			if (flag)
			{
				this._fromDate = parsed;
			}
			bool flag2 = Form_log.TryParseDate(this.ToDateEdit.Text, out parsed);
			if (flag2)
			{
				this._toDate = parsed;
			}
			bool flag3 = this._toDate < this._fromDate;
			if (flag3)
			{
				DateTime swap = this._fromDate;
				this._fromDate = this._toDate;
				this._toDate = swap;
			}
			this.WriteDateBoxes();
		}

		// Token: 0x060019EC RID: 6636 RVA: 0x0008783C File Offset: 0x00085A3C
		private static bool TryParseDate(string text, out DateTime value)
		{
			return DateTime.TryParseExact((text ?? string.Empty).Trim(), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out value) || DateTime.TryParse((text ?? string.Empty).Trim(), CultureInfo.CurrentCulture, DateTimeStyles.None, out value);
		}

		// Token: 0x060019ED RID: 6637 RVA: 0x00087890 File Offset: 0x00085A90
		private void DateEdit_LostFocus(object sender, RoutedEventArgs e)
		{
			bool flag = !this._initialized;
			if (!flag)
			{
				this.CommitDateBoxes();
			}
		}

		// Token: 0x060019EE RID: 6638 RVA: 0x000878B4 File Offset: 0x00085AB4
		private void DateEdit_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			bool flag = e.Key != Key.Return;
			if (!flag)
			{
				this.CommitDateBoxes();
				this.LoadStoredRange();
				this.RefreshData(true);
			}
		}

		// Token: 0x060019EF RID: 6639 RVA: 0x000878EC File Offset: 0x00085AEC
		private void Calendar_Click(object sender, RoutedEventArgs e)
		{
			this.CommitDateBoxes();
			this.FromCalendar.SelectedDate = new DateTime?(this._fromDate.Date);
			this.FromCalendar.DisplayDate = this._fromDate.Date;
			this.ToCalendar.SelectedDate = new DateTime?(this._toDate.Date);
			this.ToCalendar.DisplayDate = this._toDate.Date;
			this.CalendarPopup.IsOpen = !this.CalendarPopup.IsOpen;
		}

		// Token: 0x060019F0 RID: 6640 RVA: 0x00087984 File Offset: 0x00085B84
		private void FromCalendar_Changed(object sender, SelectionChangedEventArgs e)
		{
			bool flag = this.FromCalendar.SelectedDate == null;
			if (!flag)
			{
				this._fromDate = this.FromCalendar.SelectedDate.Value.Date + this._fromDate.TimeOfDay;
				this.WriteDateBoxes();
				this.LoadStoredRange();
				this.RefreshData(true);
			}
		}

		// Token: 0x060019F1 RID: 6641 RVA: 0x000879F8 File Offset: 0x00085BF8
		private void ToCalendar_Changed(object sender, SelectionChangedEventArgs e)
		{
			bool flag = this.ToCalendar.SelectedDate == null;
			if (!flag)
			{
				this._toDate = this.ToCalendar.SelectedDate.Value.Date + this._toDate.TimeOfDay;
				this.WriteDateBoxes();
				this.LoadStoredRange();
				this.RefreshData(true);
			}
		}

		// Token: 0x060019F2 RID: 6642 RVA: 0x00087A69 File Offset: 0x00085C69
		private void Refresh_Click(object sender, RoutedEventArgs e)
		{
			this.CommitDateBoxes();
			this.LoadStoredRange();
			this.RefreshData(true);
		}

		// Token: 0x060019F3 RID: 6643 RVA: 0x00087A84 File Offset: 0x00085C84
		private void LoadStoredRange()
		{
			bool valueOrDefault = this.FollowCurrentTimeEdit.IsChecked.GetValueOrDefault();
			if (valueOrDefault)
			{
				this._toDate = DateTime.Now;
				this.WriteDateBoxes();
			}
			VisionLogService.MergeFromStorage(this._fromDate, this._toDate);
		}

		// Token: 0x060019F4 RID: 6644 RVA: 0x00087ACF File Offset: 0x00085CCF
		private void Settings_Click(object sender, RoutedEventArgs e)
		{
			this.SettingsPopup.IsOpen = !this.SettingsPopup.IsOpen;
		}

		// Token: 0x060019F5 RID: 6645 RVA: 0x00087AEC File Offset: 0x00085CEC
		private void BrowseLogPath_Click(object sender, RoutedEventArgs e)
		{
			using (FolderBrowserDialog dialog = new FolderBrowserDialog())
			{
				dialog.Description = "Select the Vision Log storage folder";
				dialog.SelectedPath = (Directory.Exists(this.LogPathEdit.Text) ? this.LogPathEdit.Text : VisionLogFileStore.CurrentPath);
				bool flag = dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK;
				if (flag)
				{
					this.LogPathEdit.Text = dialog.SelectedPath;
				}
			}
		}

		// Token: 0x060019F6 RID: 6646 RVA: 0x00087B78 File Offset: 0x00085D78
		private void SaveLogPath_Click(object sender, RoutedEventArgs e)
		{
			string path = (this.LogPathEdit.Text ?? string.Empty).Trim();
			bool flag = string.IsNullOrWhiteSpace(path);
			if (flag)
			{
				DXMessageBox.Show("Log storage path is empty.", "Log Vision");
			}
			else
			{
				try
				{
					Directory.CreateDirectory(path);
					LogSettingConfig config = LogSettingRuntimeStore.Current ?? new LogSettingConfig();
					config.SavePath = path;
					config.FileFormat = "JSONL";
					LogSettingStorageService.Save(Manager_path._logSettingJsonPath, config);
					this.LogPathEdit.Text = VisionLogFileStore.CurrentPath;
					VisionLogService.Log("SUCCESS", "Configuration", "LOG-PATH", "Vision Log storage path saved: " + path, null, null);
					this.LoadStoredRange();
					this.RefreshData(true);
					this.SettingsPopup.IsOpen = false;
					DXMessageBox.Show("Vision Log storage path was saved successfully.", "Log Vision");
				}
				catch (Exception ex)
				{
					DXMessageBox.Show("Could not save the Vision Log path: " + ex.Message, "Log Vision");
				}
			}
		}

		// Token: 0x060019F7 RID: 6647 RVA: 0x00087C8C File Offset: 0x00085E8C
		private void SetLevelFilter(string level)
		{
			this.LevelEdit.SelectedItem = level;
			this.RefreshData(true);
		}

		// Token: 0x060019F8 RID: 6648 RVA: 0x00087CA4 File Offset: 0x00085EA4
		private void AllCard_Click(object sender, MouseButtonEventArgs e)
		{
			this.SetLevelFilter("All Levels");
		}

		// Token: 0x060019F9 RID: 6649 RVA: 0x00087CB2 File Offset: 0x00085EB2
		private void ErrorCard_Click(object sender, MouseButtonEventArgs e)
		{
			this.SetLevelFilter("Error");
		}

		// Token: 0x060019FA RID: 6650 RVA: 0x00087CC0 File Offset: 0x00085EC0
		private void WarningCard_Click(object sender, MouseButtonEventArgs e)
		{
			this.SetLevelFilter("Warning");
		}

		// Token: 0x060019FB RID: 6651 RVA: 0x00087CCE File Offset: 0x00085ECE
		private void InfoCard_Click(object sender, MouseButtonEventArgs e)
		{
			this.SetLevelFilter("Info");
		}

		// Token: 0x060019FC RID: 6652 RVA: 0x00087CDC File Offset: 0x00085EDC
		private void SuccessCard_Click(object sender, MouseButtonEventArgs e)
		{
			this.SetLevelFilter("Success");
		}

		// Token: 0x060019FD RID: 6653 RVA: 0x00087CEC File Offset: 0x00085EEC
		private void PageSizeChanged(object sender, SelectionChangedEventArgs e)
		{
			bool suppressFilterEvents = this._suppressFilterEvents;
			if (!suppressFilterEvents)
			{
				int size;
				bool flag = int.TryParse(Convert.ToString(this.PageSizeEdit.SelectedItem), out size) && size > 0;
				if (flag)
				{
					this._pageSize = size;
				}
				this.RefreshData(true);
			}
		}

		// Token: 0x060019FE RID: 6654 RVA: 0x00087D3C File Offset: 0x00085F3C
		private void PreviousPage_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this._currentPage > 1;
			if (flag)
			{
				this._currentPage--;
				this.RefreshData(false);
			}
		}

		// Token: 0x060019FF RID: 6655 RVA: 0x00087D70 File Offset: 0x00085F70
		private void NextPage_Click(object sender, RoutedEventArgs e)
		{
			int pageCount = Math.Max(1, (int)Math.Ceiling((double)this._filteredLogs.Count / (double)this._pageSize));
			bool flag = this._currentPage < pageCount;
			if (flag)
			{
				this._currentPage++;
				this.RefreshData(false);
			}
		}

		// Token: 0x06001A00 RID: 6656 RVA: 0x00087DC4 File Offset: 0x00085FC4
		private void PageNumber_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Controls.Button button = sender as System.Windows.Controls.Button;
			bool flag = button == null;
			if (!flag)
			{
				int page;
				bool flag2 = !int.TryParse(Convert.ToString(button.Tag), out page) || page < 1;
				if (!flag2)
				{
					this._currentPage = page;
					this.RefreshData(false);
				}
			}
		}

		// Token: 0x06001A01 RID: 6657 RVA: 0x00087E13 File Offset: 0x00086013
		private void LogList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			this.ShowDetails(this.LogList.SelectedItem as VisionLogEntry);
		}

		// Token: 0x06001A02 RID: 6658 RVA: 0x00087E30 File Offset: 0x00086030
		private void RowDetails_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement button = sender as FrameworkElement;
			VisionLogEntry entry = ((button != null) ? button.DataContext : null) as VisionLogEntry;
			bool flag = entry == null;
			if (!flag)
			{
				this.LogList.SelectedItem = entry;
				this.ShowDetails(entry);
			}
		}

		// Token: 0x06001A03 RID: 6659 RVA: 0x00087E78 File Offset: 0x00086078
		private void ShowDetails(VisionLogEntry entry)
		{
			this.DetailLevelText.Text = (((entry != null) ? entry.Level : null) ?? "--");
			this.DetailTimeText.Text = (((entry != null) ? entry.TimeText : null) ?? string.Empty);
			this.DetailSourceText.Text = (((entry != null) ? entry.Source : null) ?? "--");
			this.DetailCodeText.Text = (((entry != null) ? entry.Code : null) ?? "--");
			this.DetailMessageText.Text = (((entry != null) ? entry.Message : null) ?? "Select a log row to view details.");
			this.DetailInfoText.Text = (string.IsNullOrWhiteSpace((entry != null) ? entry.Details : null) ? "--" : entry.Details);
			this.DetailStackText.Text = (string.IsNullOrWhiteSpace((entry != null) ? entry.StackTrace : null) ? "--" : entry.StackTrace);
			this.ApplyDetailLevelStyle((entry != null) ? entry.Level : null);
		}

		// Token: 0x06001A04 RID: 6660 RVA: 0x00087F98 File Offset: 0x00086198
		private void ApplyDetailLevelStyle(string level)
		{
			string backgroundKey = "InfoSurfaceBrush";
			string borderKey = "VmInfoTextBrush";
			string foregroundKey = "VmInfoTextBrush";
			string text = (level ?? string.Empty).ToUpperInvariant();
			string a = text;
			if (!(a == "ERROR"))
			{
				if (!(a == "WARN"))
				{
					if (!(a == "SUCCESS"))
					{
						if (a == "TRIGGER")
						{
							backgroundKey = "TriggerSurfaceBrush";
							borderKey = "VmTriggerTextBrush";
							foregroundKey = "VmTriggerTextBrush";
						}
					}
					else
					{
						backgroundKey = "SuccessSurfaceBrush";
						borderKey = "VmSuccessTextBrush";
						foregroundKey = "VmSuccessTextBrush";
					}
				}
				else
				{
					backgroundKey = "WarnSurfaceBrush";
					borderKey = "VmWarningTextBrush";
					foregroundKey = "VmWarningTextBrush";
				}
			}
			else
			{
				backgroundKey = "ErrorSurfaceBrush";
				borderKey = "VmErrorTextBrush";
				foregroundKey = "VmErrorTextBrush";
			}
			this.DetailLevelBorder.Background = ((base.TryFindResource(backgroundKey) as Brush) ?? Brushes.Transparent);
			this.DetailLevelBorder.BorderBrush = ((base.TryFindResource(borderKey) as Brush) ?? Brushes.Transparent);
			this.DetailLevelText.Foreground = ((base.TryFindResource(foregroundKey) as Brush) ?? SystemColors.ControlTextBrush);
		}

		// Token: 0x06001A05 RID: 6661 RVA: 0x000880B5 File Offset: 0x000862B5
		private void ClearSelection_Click(object sender, RoutedEventArgs e)
		{
			this.LogList.SelectedItem = null;
			this.ShowDetails(null);
		}

		// Token: 0x06001A06 RID: 6662 RVA: 0x000880D0 File Offset: 0x000862D0
		private void CopySelected_Click(object sender, RoutedEventArgs e)
		{
			VisionLogEntry entry = this.LogList.SelectedItem as VisionLogEntry;
			IEnumerable<VisionLogEntry> entries;
			if (entry != null)
			{
				IEnumerable<VisionLogEntry> enumerable = new VisionLogEntry[]
				{
					entry
				};
				entries = enumerable;
			}
			else
			{
				entries = Enumerable.Empty<VisionLogEntry>();
			}
			Form_log.CopyText(Form_log.BuildLogText(entries, false));
		}

		// Token: 0x06001A07 RID: 6663 RVA: 0x00088111 File Offset: 0x00086311
		private void CopyVisible_Click(object sender, RoutedEventArgs e)
		{
			this.ExportPopup.IsOpen = false;
			Form_log.CopyText(Form_log.BuildLogText(this.VisibleLogs, false));
		}

		// Token: 0x06001A08 RID: 6664 RVA: 0x00088134 File Offset: 0x00086334
		private void CopyDetails_Click(object sender, RoutedEventArgs e)
		{
			VisionLogEntry entry = this.LogList.SelectedItem as VisionLogEntry;
			bool flag = entry == null;
			if (!flag)
			{
				Form_log.CopyText(string.Concat(new string[]
				{
					Form_log.BuildLogText(new VisionLogEntry[]
					{
						entry
					}, false),
					Environment.NewLine,
					"Details: ",
					entry.Details,
					Environment.NewLine,
					"Stack Trace: ",
					entry.StackTrace
				}));
			}
		}

		// Token: 0x06001A09 RID: 6665 RVA: 0x000881B4 File Offset: 0x000863B4
		private static void CopyText(string text)
		{
			bool flag = string.IsNullOrWhiteSpace(text);
			if (!flag)
			{
				try
				{
					System.Windows.Clipboard.SetText(text);
				}
				catch (Exception ex)
				{
					DXMessageBox.Show("Could not copy log text: " + ex.Message, "Log Vision");
				}
			}
		}

		// Token: 0x06001A0A RID: 6666 RVA: 0x0008820C File Offset: 0x0008640C
		private void Export_Click(object sender, RoutedEventArgs e)
		{
			this.ExportPopup.IsOpen = !this.ExportPopup.IsOpen;
		}

		// Token: 0x06001A0B RID: 6667 RVA: 0x00088229 File Offset: 0x00086429
		private void ExportCsv_Click(object sender, RoutedEventArgs e)
		{
			this.ExportPopup.IsOpen = false;
			this.ExportTo("csv", "CSV file (*.csv)|*.csv");
		}

		// Token: 0x06001A0C RID: 6668 RVA: 0x0008824A File Offset: 0x0008644A
		private void ExportTxt_Click(object sender, RoutedEventArgs e)
		{
			this.ExportPopup.IsOpen = false;
			this.ExportTo("txt", "Text file (*.txt)|*.txt");
		}

		// Token: 0x06001A0D RID: 6669 RVA: 0x0008826C File Offset: 0x0008646C
		private void ExportTo(string extension, string filter)
		{
			bool flag = this._filteredLogs.Count == 0;
			if (flag)
			{
				DXMessageBox.Show("There are no filtered logs to export.", "Log Vision");
			}
			else
			{
				Microsoft.Win32.SaveFileDialog dialog = new Microsoft.Win32.SaveFileDialog
				{
					Title = "Export Vision Log",
					Filter = filter,
					FileName = "vision_log_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "." + extension,
					InitialDirectory = (Directory.Exists(VisionLogFileStore.CurrentPath) ? VisionLogFileStore.CurrentPath : null)
				};
				bool flag2 = !dialog.ShowDialog().GetValueOrDefault();
				if (!flag2)
				{
					try
					{
						File.WriteAllText(dialog.FileName, Form_log.BuildLogText(this._filteredLogs, extension == "csv"), Encoding.UTF8);
					}
					catch (Exception ex)
					{
						DXMessageBox.Show("Could not export logs: " + ex.Message, "Log Vision");
					}
				}
			}
		}

		// Token: 0x06001A0E RID: 6670 RVA: 0x00088378 File Offset: 0x00086578
		private static string BuildLogText(IEnumerable<VisionLogEntry> entries, bool csv = false)
		{
			StringBuilder builder = new StringBuilder();
			if (csv)
			{
				builder.AppendLine("Time,Level,Source,Code,Message,Details,StackTrace");
			}
			else
			{
				builder.AppendLine("Time\tLevel\tSource\tCode\tMessage");
			}
			foreach (VisionLogEntry entry in (entries ?? Enumerable.Empty<VisionLogEntry>()))
			{
				if (csv)
				{
					builder.AppendLine(string.Join(",", new string[]
					{
						Form_log.Csv(entry.TimeText),
						Form_log.Csv(entry.Level),
						Form_log.Csv(entry.Source),
						Form_log.Csv(entry.Code),
						Form_log.Csv(entry.Message),
						Form_log.Csv(entry.Details),
						Form_log.Csv(entry.StackTrace)
					}));
				}
				else
				{
					builder.AppendLine(string.Concat(new string[]
					{
						entry.TimeText,
						"\t",
						entry.Level,
						"\t",
						entry.Source,
						"\t",
						entry.Code,
						"\t",
						entry.Message
					}));
				}
			}
			return builder.ToString();
		}

		// Token: 0x06001A0F RID: 6671 RVA: 0x000884F0 File Offset: 0x000866F0
		private static string Csv(string value)
		{
			return "\"" + (value ?? string.Empty).Replace("\"", "\"\"") + "\"";
		}

		// Token: 0x06001A10 RID: 6672 RVA: 0x0008852A File Offset: 0x0008672A
		private void Clear_Click(object sender, RoutedEventArgs e)
		{
			VisionLogService.Clear();
		}

		// Token: 0x06001A11 RID: 6673 RVA: 0x00088533 File Offset: 0x00086733
		private void Close_Click(object sender, RoutedEventArgs e)
		{
			MainWindow instance = MainWindow.instance;
			if (instance != null)
			{
				instance.CloseLogVisionDocument();
			}
		}

		// Token: 0x06001A14 RID: 6676 RVA: 0x00088CE4 File Offset: 0x00086EE4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId != 41)
			{
				if (connectionId == 46)
				{
					((System.Windows.Controls.Button)target).Click += this.PageNumber_Click;
				}
			}
			else
			{
				((System.Windows.Controls.Button)target).Click += this.RowDetails_Click;
			}
		}

		// Token: 0x04000AAC RID: 2732
		private const string AllLevels = "All Levels";

		// Token: 0x04000AAD RID: 2733
		private const string AllSources = "All Modules";

		// Token: 0x04000AAE RID: 2734
		private const string DateFormat = "dd/MM/yyyy HH:mm:ss";

		// Token: 0x04000AAF RID: 2735
		private readonly List<VisionLogEntry> _filteredLogs = new List<VisionLogEntry>();

		// Token: 0x04000AB0 RID: 2736
		private bool _initialized;

		// Token: 0x04000AB1 RID: 2737
		private int _currentPage = 1;

		// Token: 0x04000AB2 RID: 2738
		private int _pageSize = 100;

		// Token: 0x04000AB3 RID: 2739
		private int _refreshQueued;

		// Token: 0x04000AB4 RID: 2740
		private bool _suppressFilterEvents;

		// Token: 0x04000AB5 RID: 2741
		private bool _newestFirst = true;

		// Token: 0x04000AB6 RID: 2742
		private DateTime _fromDate = DateTime.Today;

		// Token: 0x04000AB7 RID: 2743
		private DateTime _toDate = DateTime.Today.AddDays(1.0).AddSeconds(-1.0);
	}
}
