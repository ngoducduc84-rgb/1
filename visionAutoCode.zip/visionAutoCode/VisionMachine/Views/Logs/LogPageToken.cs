﻿using System;

namespace VisionMachine.Views.Logs
{
	// Token: 0x020001BD RID: 445
	public sealed class LogPageToken
	{
		// Token: 0x170008A7 RID: 2215
		// (get) Token: 0x060019C7 RID: 6599 RVA: 0x0008674C File Offset: 0x0008494C
		// (set) Token: 0x060019C8 RID: 6600 RVA: 0x00086754 File Offset: 0x00084954
		public string Text { get; set; }

		// Token: 0x170008A8 RID: 2216
		// (get) Token: 0x060019C9 RID: 6601 RVA: 0x0008675D File Offset: 0x0008495D
		// (set) Token: 0x060019CA RID: 6602 RVA: 0x00086765 File Offset: 0x00084965
		public int Page { get; set; }

		// Token: 0x170008A9 RID: 2217
		// (get) Token: 0x060019CB RID: 6603 RVA: 0x0008676E File Offset: 0x0008496E
		// (set) Token: 0x060019CC RID: 6604 RVA: 0x00086776 File Offset: 0x00084976
		public bool IsCurrent { get; set; }

		// Token: 0x170008AA RID: 2218
		// (get) Token: 0x060019CD RID: 6605 RVA: 0x0008677F File Offset: 0x0008497F
		// (set) Token: 0x060019CE RID: 6606 RVA: 0x00086787 File Offset: 0x00084987
		public bool IsGap { get; set; }
	}
}
