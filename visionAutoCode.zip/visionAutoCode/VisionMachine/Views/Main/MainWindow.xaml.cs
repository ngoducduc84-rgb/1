﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Docking;
using VisionMachine.Controls.Common;
using VisionMachine.Helpers;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Recipe;
using VisionMachine.Services;
using VisionMachine.Services.Appearance;
using VisionMachine.Services.Calibration;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Communication;
using VisionMachine.Services.Licensing;
using VisionMachine.Services.Light;
using VisionMachine.Services.Localization;
using VisionMachine.Services.Runtime;
using VisionMachine.Services.Security;
using VisionMachine.Services.Storage;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Calibration;
using VisionMachine.Views.Communication;
using VisionMachine.Views.Home;
using VisionMachine.Views.License;
using VisionMachine.Views.Logs;
using VisionMachine.Views.Security;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.DLObjectInspection;

namespace VisionMachine.Views.Main
{
	// Token: 0x02000199 RID: 409
	public partial class MainWindow : ThemedWindow
	{
		// Token: 0x06001539 RID: 5433 RVA: 0x00065424 File Offset: 0x00063624
		public MainWindow()
		{
			this.InitializeComponent();
			MaximizeWorkAreaService.Attach(this);
			this.PreserveTopMenuContrastColors();
			MainWindow.instance = this;
			base.DataContext = this.MainViewModel;
			base.Loaded += this.MainWindow_Loaded;
			base.ContentRendered += this.MainWindow_ContentRenderedForLicenseWarning;
			this.LoadAllRuntimeData();
			StartupDiag.Log("MainWindow ctor: opening Home document");
			this.OpenDocument("Home", "Form_home", "Views/Home/Form_home.xaml");
			StartupDiag.Log("MainWindow ctor: Home opened, starting clock");
			this.StartClock();
			this.UpdateLanguageMenu();
			this.UpdateAdminButton();
			LanguageService.LanguageChanged += delegate(object s, EventArgs e)
			{
				this.RelocalizeDocumentCaptions();
			};
			this.UpdateThemeButton();
			this.UpdateCaptionMaximizeGlyph();
			StartupDiag.Log("MainWindow ctor: done");
		}

		// Token: 0x0600153A RID: 5434 RVA: 0x0006551B File Offset: 0x0006371B
		private void CaptionMinimizeButton_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x0600153B RID: 5435 RVA: 0x00065526 File Offset: 0x00063726
		private void CaptionMaximizeRestoreButton_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = ((base.WindowState == WindowState.Maximized) ? WindowState.Normal : WindowState.Maximized);
		}

		// Token: 0x0600153C RID: 5436 RVA: 0x0006553D File Offset: 0x0006373D
		private void CaptionCloseButton_Click(object sender, RoutedEventArgs e)
		{
			base.Close();
		}

		// Token: 0x0600153D RID: 5437 RVA: 0x00065548 File Offset: 0x00063748
		private void CustomCaptionBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = e.ChangedButton != MouseButton.Left || MainWindow.IsCaptionButtonSource(e.OriginalSource as DependencyObject);
			if (!flag)
			{
				bool flag2 = e.ClickCount == 2;
				if (flag2)
				{
					base.WindowState = ((base.WindowState == WindowState.Maximized) ? WindowState.Normal : WindowState.Maximized);
				}
				else
				{
					bool flag3 = base.WindowState == WindowState.Maximized;
					if (flag3)
					{
						this.RestoreWindowUnderPointer(e);
					}
					try
					{
						base.DragMove();
					}
					catch (InvalidOperationException)
					{
					}
				}
			}
		}

		// Token: 0x0600153E RID: 5438 RVA: 0x000655D4 File Offset: 0x000637D4
		private void RestoreWindowUnderPointer(MouseButtonEventArgs e)
		{
			Point pointerInWindow = e.GetPosition(this);
			Point pointerOnScreen = base.PointToScreen(pointerInWindow);
			PresentationSource source = PresentationSource.FromVisual(this);
			bool flag = ((source != null) ? source.CompositionTarget : null) != null;
			if (flag)
			{
				pointerOnScreen = source.CompositionTarget.TransformFromDevice.Transform(pointerOnScreen);
			}
			double restoreWidth = base.RestoreBounds.Width;
			bool flag2 = double.IsNaN(restoreWidth) || restoreWidth <= 0.0;
			if (flag2)
			{
				restoreWidth = ((base.Width > 0.0) ? base.Width : 1200.0);
			}
			double horizontalRatio = (base.ActualWidth > 0.0) ? Math.Max(0.0, Math.Min(1.0, pointerInWindow.X / base.ActualWidth)) : 0.5;
			base.WindowState = WindowState.Normal;
			base.Left = pointerOnScreen.X - restoreWidth * horizontalRatio;
			base.Top = pointerOnScreen.Y - Math.Min(pointerInWindow.Y, 16.0);
		}

		// Token: 0x0600153F RID: 5439 RVA: 0x00065700 File Offset: 0x00063900
		private static bool IsCaptionButtonSource(DependencyObject source)
		{
			while (source != null)
			{
				bool flag = source is Button;
				if (flag)
				{
					return true;
				}
				source = VisualTreeHelper.GetParent(source);
			}
			return false;
		}

		// Token: 0x06001540 RID: 5440 RVA: 0x00065738 File Offset: 0x00063938
		private void MainWindow_StateChanged(object sender, EventArgs e)
		{
			this.UpdateCaptionMaximizeGlyph();
		}

		// Token: 0x06001541 RID: 5441 RVA: 0x00065744 File Offset: 0x00063944
		private void UpdateCaptionMaximizeGlyph()
		{
			bool flag = this.CaptionMaximizeGlyph == null;
			if (!flag)
			{
				this.CaptionMaximizeGlyph.Text = ((base.WindowState == WindowState.Maximized) ? "" : "");
			}
		}

		// Token: 0x06001542 RID: 5442 RVA: 0x00065784 File Offset: 0x00063984
		private void PreserveTopMenuContrastColors()
		{
			WpfThemeAdapter.SetPreserveColors(this.btnHome, true);
			WpfThemeAdapter.SetPreserveColors(this.btnSetting, true);
			WpfThemeAdapter.SetPreserveColors(this.btnCamera, true);
			WpfThemeAdapter.SetPreserveColors(this.btnModel, true);
			WpfThemeAdapter.SetPreserveColors(this.btnCommunication, true);
			WpfThemeAdapter.SetPreserveColors(this.btnCalib_Hand_Eye, true);
		}

		// Token: 0x06001543 RID: 5443 RVA: 0x000657E0 File Offset: 0x000639E0
		private void ThemeToggleButton_Click(object sender, RoutedEventArgs e)
		{
			AppColorTheme next = (ThemeService.Current == AppColorTheme.Dark) ? AppColorTheme.Light : AppColorTheme.Dark;
			ThemeService.SetTheme(next);
			this.UpdateThemeButton();
		}

		// Token: 0x06001544 RID: 5444 RVA: 0x00065808 File Offset: 0x00063A08
		private void UpdateThemeButton()
		{
			bool isDark = ThemeService.Current == AppColorTheme.Dark;
			bool flag = this.SwitchToLightIcon != null;
			if (flag)
			{
				this.SwitchToLightIcon.Visibility = (isDark ? Visibility.Visible : Visibility.Collapsed);
			}
			bool flag2 = this.SwitchToDarkIcon != null;
			if (flag2)
			{
				this.SwitchToDarkIcon.Visibility = (isDark ? Visibility.Collapsed : Visibility.Visible);
			}
			bool flag3 = this.ThemeToggleButton != null;
			if (flag3)
			{
				this.ThemeToggleButton.ToolTip = LanguageService.GetString(isDark ? "Theme_SwitchToLight" : "Theme_SwitchToDark");
			}
		}

		// Token: 0x06001545 RID: 5445 RVA: 0x00065890 File Offset: 0x00063A90
		private void LanguageButton_Click(object sender, RoutedEventArgs e)
		{
			Button languageButton = this.LanguageButton;
			bool flag = ((languageButton != null) ? languageButton.ContextMenu : null) == null;
			if (!flag)
			{
				this.LanguageButton.ContextMenu.PlacementTarget = this.LanguageButton;
				this.LanguageButton.ContextMenu.Placement = PlacementMode.Bottom;
				this.LanguageButton.ContextMenu.IsOpen = true;
			}
		}

		// Token: 0x06001546 RID: 5446 RVA: 0x000658F4 File Offset: 0x00063AF4
		private void SelectEnglish_Click(object sender, RoutedEventArgs e)
		{
			this.SetLanguage(AppLanguage.English);
		}

		// Token: 0x06001547 RID: 5447 RVA: 0x000658FF File Offset: 0x00063AFF
		private void SelectVietnamese_Click(object sender, RoutedEventArgs e)
		{
			this.SetLanguage(AppLanguage.Vietnamese);
		}

		// Token: 0x06001548 RID: 5448 RVA: 0x0006590C File Offset: 0x00063B0C
		private void LicenseButton_Click(object sender, RoutedEventArgs e)
		{
			LicenseWindow window = new LicenseWindow();
			bool flag = WindowOwnerHelper.IsUsable(this);
			if (flag)
			{
				window.Owner = this;
			}
			window.ShowDialog();
		}

		// Token: 0x06001549 RID: 5449 RVA: 0x0006593C File Offset: 0x00063B3C
		private void MainWindow_ContentRenderedForLicenseWarning(object sender, EventArgs e)
		{
			bool licenseWarningScheduled = this._licenseWarningScheduled;
			if (!licenseWarningScheduled)
			{
				this._licenseWarningScheduled = true;
				base.Dispatcher.BeginInvoke(new Action(this.ShowLicenseExpiryWarningIfNeeded), DispatcherPriority.ApplicationIdle, Array.Empty<object>());
			}
		}

		// Token: 0x0600154A RID: 5450 RVA: 0x0006597C File Offset: 0x00063B7C
		private void ShowLicenseExpiryWarningIfNeeded()
		{
			LicenseState expiredLicense;
			bool flag = LicenseExpiryWarningService.TryGetExpiredLicense(out expiredLicense);
			if (flag)
			{
				LicenseExpiredWindow expiredWindow = new LicenseExpiredWindow(expiredLicense);
				bool flag2 = WindowOwnerHelper.IsUsable(this);
				if (flag2)
				{
					expiredWindow.Owner = this;
				}
				expiredWindow.ShowDialog();
				bool flag3 = !expiredWindow.LicenseRenewed;
				if (flag3)
				{
					base.Dispatcher.BeginInvoke(new Action(base.Close), DispatcherPriority.Send, Array.Empty<object>());
				}
			}
			else
			{
				LicenseExpiryWarningInfo warning;
				bool flag4 = !LicenseExpiryWarningService.TryGetWarning(out warning);
				if (!flag4)
				{
					LicenseExpiryWarningWindow window = new LicenseExpiryWarningWindow(warning);
					bool flag5 = WindowOwnerHelper.IsUsable(this);
					if (flag5)
					{
						window.Owner = this;
					}
					window.ShowDialog();
					bool renewRequested = window.RenewRequested;
					if (renewRequested)
					{
						this.LicenseButton_Click(this, new RoutedEventArgs());
					}
				}
			}
		}

		// Token: 0x0600154B RID: 5451 RVA: 0x00065A3C File Offset: 0x00063C3C
		private void AdminButton_Click(object sender, RoutedEventArgs e)
		{
			bool isSignedIn = AdminSessionService.IsSignedIn;
			if (isSignedIn)
			{
				MessageBoxResult answer = DXMessageBox.Show(this, "Sign out of the administrator session?", "Administrator", MessageBoxButton.YesNo, MessageBoxImage.Question);
				bool flag = answer == MessageBoxResult.Yes;
				if (flag)
				{
					AdminSessionService.SignOut();
				}
				this.UpdateAdminButton();
			}
			else
			{
				AdminLoginWindow window = new AdminLoginWindow();
				bool flag2 = WindowOwnerHelper.IsUsable(this);
				if (flag2)
				{
					window.Owner = this;
				}
				window.ShowDialog();
				this.UpdateAdminButton();
			}
		}

		// Token: 0x0600154C RID: 5452 RVA: 0x00065AA8 File Offset: 0x00063CA8
		private void IssueLicenseButton_Click(object sender, RoutedEventArgs e)
		{
			bool flag = !AdminSessionService.IsSignedIn;
			if (flag)
			{
				DXMessageBox.Show(this, "Sign in as administrator to issue a license.", "Issue License", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			else
			{
				LicenseIssueWindow window = new LicenseIssueWindow();
				bool flag2 = WindowOwnerHelper.IsUsable(this);
				if (flag2)
				{
					window.Owner = this;
				}
				window.ShowDialog();
			}
		}

		// Token: 0x0600154D RID: 5453 RVA: 0x00065AF8 File Offset: 0x00063CF8
		private void UpdateAdminButton()
		{
			bool signedIn = AdminSessionService.IsSignedIn;
			bool flag = this.AdminLockedIcon != null;
			if (flag)
			{
				this.AdminLockedIcon.Visibility = (signedIn ? Visibility.Collapsed : Visibility.Visible);
			}
			bool flag2 = this.AdminSignedInIcon != null;
			if (flag2)
			{
				this.AdminSignedInIcon.Visibility = (signedIn ? Visibility.Visible : Visibility.Collapsed);
			}
			bool flag3 = this.AdminBorder != null;
			if (flag3)
			{
				this.AdminBorder.BorderBrush = (signedIn ? new SolidColorBrush(Color.FromRgb(34, 197, 94)) : ((Brush)base.FindResource("VmBorderBrush")));
			}
			bool flag4 = this.IssueLicenseBorder != null;
			if (flag4)
			{
				this.IssueLicenseBorder.Visibility = (signedIn ? Visibility.Visible : Visibility.Collapsed);
			}
			bool flag5 = this.AdminButton != null;
			if (flag5)
			{
				this.AdminButton.ToolTip = (signedIn ? ("Signed in as " + AdminSessionService.UserName + " - click to sign out") : UiTranslator.Translate("Administrator login"));
			}
		}

		// Token: 0x0600154E RID: 5454 RVA: 0x00065BF3 File Offset: 0x00063DF3
		private void SelectKorean_Click(object sender, RoutedEventArgs e)
		{
			this.SetLanguage(AppLanguage.Korean);
		}

		// Token: 0x0600154F RID: 5455 RVA: 0x00065BFE File Offset: 0x00063DFE
		private void SetLanguage(AppLanguage language)
		{
			LanguageService.SetLanguage(language);
			this.UpdateLanguageMenu();
			this.UpdateThemeButton();
		}

		// Token: 0x06001550 RID: 5456 RVA: 0x00065C18 File Offset: 0x00063E18
		private void UpdateLanguageMenu()
		{
			AppLanguage current = LanguageService.Current;
			bool flag = this.EnglishMenuItem != null;
			if (flag)
			{
				this.EnglishMenuItem.IsChecked = (current == AppLanguage.English);
			}
			bool flag2 = this.VietnameseMenuItem != null;
			if (flag2)
			{
				this.VietnameseMenuItem.IsChecked = (current == AppLanguage.Vietnamese);
			}
			bool flag3 = this.KoreanMenuItem != null;
			if (flag3)
			{
				this.KoreanMenuItem.IsChecked = (current == AppLanguage.Korean);
			}
			bool flag4 = this.CurrentLanguageText != null;
			if (flag4)
			{
				this.CurrentLanguageText.Text = MainWindow.GetLanguageName(current);
			}
		}

		// Token: 0x06001551 RID: 5457 RVA: 0x00065CA4 File Offset: 0x00063EA4
		private static string GetLanguageName(AppLanguage language)
		{
			string key;
			if (language != AppLanguage.Vietnamese)
			{
				if (language != AppLanguage.Korean)
				{
					key = "Language_English";
				}
				else
				{
					key = "Language_Korean";
				}
			}
			else
			{
				key = "Language_Vietnamese";
			}
			return LanguageService.GetString(key);
		}

		// Token: 0x06001552 RID: 5458 RVA: 0x00065CE4 File Offset: 0x00063EE4
		private void MainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			base.Dispatcher.BeginInvoke(new Action(this.InitializeCommunicationRuntimeFromMain), DispatcherPriority.ContextIdle, Array.Empty<object>());
		}

		// Token: 0x06001553 RID: 5459 RVA: 0x00065D08 File Offset: 0x00063F08
		[DebuggerStepThrough]
		private void InitializeCommunicationRuntimeFromMain()
		{
			MainWindow.<InitializeCommunicationRuntimeFromMain>d__34 <InitializeCommunicationRuntimeFromMain>d__ = new MainWindow.<InitializeCommunicationRuntimeFromMain>d__34();
			<InitializeCommunicationRuntimeFromMain>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<InitializeCommunicationRuntimeFromMain>d__.<>4__this = this;
			<InitializeCommunicationRuntimeFromMain>d__.<>1__state = -1;
			<InitializeCommunicationRuntimeFromMain>d__.<>t__builder.Start<MainWindow.<InitializeCommunicationRuntimeFromMain>d__34>(ref <InitializeCommunicationRuntimeFromMain>d__);
		}

		// Token: 0x06001554 RID: 5460 RVA: 0x00065D41 File Offset: 0x00063F41
		public void load_view_setting()
		{
			base.DataContext = this.MainViewModel;
		}

		// Token: 0x06001555 RID: 5461 RVA: 0x00065D51 File Offset: 0x00063F51
		private void Open_home(object sender, RoutedEventArgs e)
		{
			this.OpenDocument("Home", "Form_home", "Views/Home/Form_home.xaml");
			this.SetActiveMenu(this.btnHome);
		}

		// Token: 0x06001556 RID: 5462 RVA: 0x00065D77 File Offset: 0x00063F77
		private void Open_camera(object sender, RoutedEventArgs e)
		{
			this.OpenDocument("Camera", "Form_Camera", "Views/Camera/Form_Camera.xaml");
			this.SetActiveMenu(this.btnCamera);
		}

		// Token: 0x06001557 RID: 5463 RVA: 0x00065D9D File Offset: 0x00063F9D
		private void Open_setting(object sender, RoutedEventArgs e)
		{
			this.SetActiveMenu(this.btnSetting);
			this.OpenDocument("Setting", "Form_Setting", "Views/Setting/Form_setting.xaml");
		}

		// Token: 0x06001558 RID: 5464 RVA: 0x00065DC3 File Offset: 0x00063FC3
		private void Open_model(object sender, RoutedEventArgs e)
		{
			this.OpenDocument("Model", "Form_model", "Views/Model/Form_model.xaml");
			this.SetActiveMenu(this.btnModel);
		}

		// Token: 0x06001559 RID: 5465 RVA: 0x00065DEC File Offset: 0x00063FEC
		private void Open_communication(object sender, RoutedEventArgs e)
		{
			DocumentPanel panel = this.OpenDocument("Communication", "Form_communication", "Views/Communication/Form_communication.xaml");
			this.RefreshCommunicationDocument(panel);
			this.SetActiveMenu(this.btnCommunication);
		}

		// Token: 0x0600155A RID: 5466 RVA: 0x00065E28 File Offset: 0x00064028
		private void Open_Hand_Eye(object sender, RoutedEventArgs e)
		{
			DocumentPanel panel = this.OpenDocument("Calib Hand_Eye", "Form_calib_handeye", "Views/Calibration/Form_calib_handeye.xaml");
			this.RefreshCalibHandEyeDocument(panel);
			this.SetActiveMenu(this.btnCalib_Hand_Eye);
		}

		// Token: 0x0600155B RID: 5467 RVA: 0x00065E64 File Offset: 0x00064064
		public void OpenLogVisionDocument()
		{
			bool flag = !base.Dispatcher.CheckAccess();
			if (flag)
			{
				base.Dispatcher.BeginInvoke(new Action(this.OpenLogVisionDocument), Array.Empty<object>());
			}
			else
			{
				DocumentPanel panel = this.OpenDocument("Log Vision", "Form_log", "Views/Logs/Form_log.xaml");
				this.RefreshLogDocument(panel);
				this.ClearActiveMenuSelection();
			}
		}

		// Token: 0x0600155C RID: 5468 RVA: 0x00065ECC File Offset: 0x000640CC
		private void RefreshLogDocument(DocumentPanel panel)
		{
			bool flag = panel == null;
			if (!flag)
			{
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					Form_log logForm = panel.Content as Form_log;
					bool flag2 = logForm != null;
					if (flag2)
					{
						logForm.RefreshFromStorage();
					}
				}), DispatcherPriority.Loaded, Array.Empty<object>());
			}
		}

		// Token: 0x0600155D RID: 5469 RVA: 0x00065F14 File Offset: 0x00064114
		public void CloseLogVisionDocument()
		{
			bool flag = !base.Dispatcher.CheckAccess();
			if (flag)
			{
				base.Dispatcher.BeginInvoke(new Action(this.CloseLogVisionDocument), Array.Empty<object>());
			}
			else
			{
				DocumentPanel panel = this.documentGroup.Items.OfType<DocumentPanel>().FirstOrDefault((DocumentPanel x) => x.Name == "Form_log");
				bool flag2 = panel != null;
				if (flag2)
				{
					this.dockManager.DockController.Close(panel);
				}
			}
		}

		// Token: 0x0600155E RID: 5470 RVA: 0x00065FA4 File Offset: 0x000641A4
		private DocumentPanel OpenDocument(string caption, string id, string xamlPath)
		{
			DocumentPanel result2;
			try
			{
				bool flag = this.dockManager == null;
				if (flag)
				{
					throw new Exception("dockManager is null");
				}
				bool flag2 = this.documentGroup == null;
				if (flag2)
				{
					throw new Exception("documentGroup is null");
				}
				bool flag3 = string.IsNullOrWhiteSpace(id);
				if (flag3)
				{
					throw new Exception("id is null or empty");
				}
				bool flag4 = string.IsNullOrWhiteSpace(xamlPath);
				if (flag4)
				{
					throw new Exception("xamlPath is null or empty");
				}
				DocumentPanel existing = this.documentGroup.Items.OfType<DocumentPanel>().FirstOrDefault((DocumentPanel x) => x.Name == id);
				bool flag5 = existing != null;
				if (flag5)
				{
					this.TrackDocumentPanel(existing);
					existing.IsActive = true;
					this.UpdateActiveMenuFromDocument(existing);
					result2 = existing;
				}
				else
				{
					DocumentPanel result = null;
					LoadingOverlay.RunOnUi(this, "Opening " + caption + "...", delegate
					{
						result = this.CreateOrRestoreDocument(id, caption, xamlPath);
					});
					result2 = result;
				}
			}
			catch (Exception ex)
			{
				DXMessageBox.Show(ex.ToString(), "OpenDocument Error");
				result2 = null;
			}
			return result2;
		}

		// Token: 0x0600155F RID: 5471 RVA: 0x0006611C File Offset: 0x0006431C
		private DocumentPanel CreateOrRestoreDocument(string id, string caption, string xamlPath)
		{
			DocumentPanel closed = this.dockManager.ClosedPanels.OfType<DocumentPanel>().FirstOrDefault((DocumentPanel x) => x.Name == id);
			bool flag = closed != null;
			DocumentPanel result;
			if (flag)
			{
				this.dockManager.DockController.Restore(closed);
				this.TrackDocumentPanel(closed);
				closed.IsActive = true;
				this.UpdateActiveMenuFromDocument(closed);
				result = closed;
			}
			else
			{
				DocumentPanel panel = this.dockManager.DockController.AddDocumentPanel(this.documentGroup, new Uri(xamlPath, UriKind.Relative));
				bool flag2 = panel == null;
				if (flag2)
				{
					throw new Exception("AddDocumentPanel returned null");
				}
				panel.Name = id;
				this._documentCaptions[id] = caption;
				UiLocalizer.SetLocalizedCaption(panel, caption);
				this.TrackDocumentPanel(panel);
				panel.IsActive = true;
				this.UpdateActiveMenuFromDocument(panel);
				result = panel;
			}
			return result;
		}

		// Token: 0x06001560 RID: 5472 RVA: 0x0006620C File Offset: 0x0006440C
		private void RefreshCommunicationDocument(DocumentPanel panel)
		{
			bool flag = panel == null;
			if (!flag)
			{
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					Form_communication communicationForm = panel.Content as Form_communication;
					bool flag2 = communicationForm != null;
					if (flag2)
					{
						communicationForm.RefreshFromCurrentModel();
					}
				}), DispatcherPriority.Loaded, Array.Empty<object>());
			}
		}

		// Token: 0x06001561 RID: 5473 RVA: 0x00066254 File Offset: 0x00064454
		private void RefreshCalibHandEyeDocument(DocumentPanel panel)
		{
			bool flag = panel == null;
			if (!flag)
			{
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					Form_calib_handeye calibForm = panel.Content as Form_calib_handeye;
					bool flag2 = calibForm != null;
					if (flag2)
					{
						calibForm.RefreshSettingOptions(true);
					}
				}), DispatcherPriority.Loaded, Array.Empty<object>());
			}
		}

		// Token: 0x06001562 RID: 5474 RVA: 0x0006629C File Offset: 0x0006449C
		private void RelocalizeDocumentCaptions()
		{
			bool flag = this.dockManager == null;
			if (!flag)
			{
				foreach (DocumentPanel panel in this.EnumerateDocumentPanels())
				{
					string english;
					bool flag2 = panel.Name != null && this._documentCaptions.TryGetValue(panel.Name, out english);
					if (flag2)
					{
						UiLocalizer.SetLocalizedCaption(panel, english);
					}
				}
			}
		}

		// Token: 0x06001563 RID: 5475 RVA: 0x00066324 File Offset: 0x00064524
		private IEnumerable<DocumentPanel> EnumerateDocumentPanels()
		{
			List<DocumentPanel> panels = new List<DocumentPanel>();
			bool flag = this.documentGroup != null;
			if (flag)
			{
				panels.AddRange(this.documentGroup.Items.OfType<DocumentPanel>());
			}
			bool flag2 = this.dockManager.ClosedPanels != null;
			if (flag2)
			{
				panels.AddRange(this.dockManager.ClosedPanels.OfType<DocumentPanel>());
			}
			return panels;
		}

		// Token: 0x06001564 RID: 5476 RVA: 0x0006638C File Offset: 0x0006458C
		private void TrackDocumentPanel(DocumentPanel panel)
		{
			bool flag = panel == null || this._trackedDocumentPanels.Contains(panel);
			if (!flag)
			{
				this._trackedDocumentPanels.Add(panel);
				DependencyPropertyDescriptor descriptor = DependencyPropertyDescriptor.FromProperty(BaseLayoutItem.IsActiveProperty, typeof(DocumentPanel));
				if (descriptor != null)
				{
					descriptor.AddValueChanged(panel, new EventHandler(this.DocumentPanel_IsActiveChanged));
				}
			}
		}

		// Token: 0x06001565 RID: 5477 RVA: 0x000663F0 File Offset: 0x000645F0
		private void DocumentPanel_IsActiveChanged(object sender, EventArgs e)
		{
			DocumentPanel panel = sender as DocumentPanel;
			bool flag = panel == null || !panel.IsActive;
			if (!flag)
			{
				this.UpdateActiveMenuFromDocument(panel);
			}
		}

		// Token: 0x06001566 RID: 5478 RVA: 0x00066424 File Offset: 0x00064624
		private void UpdateActiveMenuFromDocument(DocumentPanel panel)
		{
			bool flag = panel == null;
			if (!flag)
			{
				string name = panel.Name;
				string text = name;
				uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
				if (num <= 2415108725U)
				{
					if (num != 95725060U)
					{
						if (num != 121903642U)
						{
							if (num == 2415108725U)
							{
								if (text == "Form_model")
								{
									this.SetActiveMenu(this.btnModel);
								}
							}
						}
						else if (text == "Form_log")
						{
							this.ClearActiveMenuSelection();
						}
					}
					else if (text == "Form_Setting")
					{
						this.SetActiveMenu(this.btnSetting);
					}
				}
				else if (num <= 3019917519U)
				{
					if (num != 2970768100U)
					{
						if (num == 3019917519U)
						{
							if (text == "Form_home")
							{
								this.SetActiveMenu(this.btnHome);
							}
						}
					}
					else if (text == "Form_communication")
					{
						this.SetActiveMenu(this.btnCommunication);
					}
				}
				else if (num != 3628874087U)
				{
					if (num == 3751040046U)
					{
						if (text == "Form_calib_handeye")
						{
							this.SetActiveMenu(this.btnCalib_Hand_Eye);
						}
					}
				}
				else if (text == "Form_Camera")
				{
					this.SetActiveMenu(this.btnCamera);
				}
			}
		}

		// Token: 0x06001567 RID: 5479 RVA: 0x0006658C File Offset: 0x0006478C
		private void SetActiveMenu(SimpleButton activeButton)
		{
			bool flag = activeButton == null;
			if (!flag)
			{
				this.ClearActiveMenuSelection();
				activeButton.Style = (Style)base.FindResource("ActiveTopMenuButtonStyle");
			}
		}

		// Token: 0x06001568 RID: 5480 RVA: 0x000665C4 File Offset: 0x000647C4
		private void ClearActiveMenuSelection()
		{
			this.btnHome.Style = (Style)base.FindResource("TopMenuButtonStyle");
			this.btnSetting.Style = (Style)base.FindResource("TopMenuButtonStyle");
			this.btnCamera.Style = (Style)base.FindResource("TopMenuButtonStyle");
			this.btnModel.Style = (Style)base.FindResource("TopMenuButtonStyle");
			this.btnCommunication.Style = (Style)base.FindResource("TopMenuButtonStyle");
			this.btnCalib_Hand_Eye.Style = (Style)base.FindResource("TopMenuButtonStyle");
		}

		// Token: 0x06001569 RID: 5481 RVA: 0x0006667C File Offset: 0x0006487C
		private void LoadAllRuntimeData()
		{
			StartupDiag.Log("LoadAllRuntimeData: begin");
			VisionLogService.Log("Info", "System starting...");
			CameraStorageService.Load(Manager_path.path_Camera_Qty);
			LogSettingStorageService.Load(Manager_path._logSettingJsonPath);
			ModelStorageService.Load(Manager_path._modelJsonPath);
			this.MainViewModel.SyncCamerasFromRuntimeStore();
			this.MainViewModel.SyncCamerasFromRuntimeStorePreserveTurns();
			StartupDiag.Log("LoadAllRuntimeData: refreshing cameras");
			this.MainViewModel.RefreshConnectedCameras(new Action(this.InitialCameraDiscoveryCompleted));
			CameraModelConfigStorageService.LoadCurrentModelConfig(this.MainViewModel);
			StartupDiag.Log("LoadAllRuntimeData: loading light config");
			try
			{
				LightModelConfigStorageService.LoadCurrentModelConfig(this.MainViewModel);
				LightStartupApplyService.ApplyCurrentModelAsync(this.MainViewModel, "Application startup", 0);
			}
			catch (Exception lightEx)
			{
				StartupDiag.Log("Light config load failed", lightEx);
			}
			StartupDiag.Log("LoadAllRuntimeData: light config done");
			try
			{
				new SettingRecipeService().LoadCurrentModelRecipe();
				ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
				string modelName = (currentModel != null) ? currentModel.Model_name : null;
				VisionLogService.Log("Info", string.IsNullOrWhiteSpace(modelName) ? "No model is selected." : ("Model '" + modelName + "' loaded."));
			}
			catch (Exception ex)
			{
				VisionLogService.Log("Error", "Model load failed: " + ex.Message);
			}
			this.PreloadRuntimeToolFiles();
			this.PreloadDLObjectModels();
			VisionLogService.Log("Info", "Connecting to PLC...");
			this._communicationStartupTask = CommunicationStartupService.AutoConnectCurrentModelAsync(false, null, false);
			Task communicationStartupTask = this._communicationStartupTask;
			if (communicationStartupTask != null)
			{
				communicationStartupTask.ContinueWith(delegate(Task _)
				{
					CalibHandEyeControlService.TryWriteStop();
					VisionErrorCodeService.Write(0);
				}, CancellationToken.None, TaskContinuationOptions.None, TaskScheduler.Default);
			}
		}

		// Token: 0x0600156A RID: 5482 RVA: 0x00066848 File Offset: 0x00064A48
		private void InitialCameraDiscoveryCompleted()
		{
			this.LogCameraConnectionStatus();
			CameraConnectionMonitorService.PublishDiscoverySnapshot(this.MainViewModel.Cameras, this.MainViewModel.ConnectedCameras);
			HashSet<string> connectedIds = new HashSet<string>(from camera in this.MainViewModel.ConnectedCameras ?? new ObservableCollection<ConnectedCameraInfo>()
			where camera != null && !string.IsNullOrWhiteSpace(camera.Id)
			select camera.Id.Trim(), StringComparer.OrdinalIgnoreCase);
			this.WarmupCameras(connectedIds);
		}

		// Token: 0x0600156B RID: 5483 RVA: 0x000668E8 File Offset: 0x00064AE8
		private void LogCameraConnectionStatus()
		{
			try
			{
				MainViewModel mainViewModel = this.MainViewModel;
				ObservableCollection<CameraNode> cameras = (mainViewModel != null) ? mainViewModel.Cameras : null;
				bool flag = cameras == null || cameras.Count == 0;
				if (flag)
				{
					VisionLogService.Log("Warn", "No cameras are configured.");
				}
				else
				{
					ObservableCollection<ConnectedCameraInfo> connected = this.MainViewModel.ConnectedCameras;
					foreach (CameraNode camera in cameras)
					{
						MainWindow.<>c__DisplayClass58_0 CS$<>8__locals1 = new MainWindow.<>c__DisplayClass58_0();
						string name = ((camera != null) ? camera.Name : null) ?? "Camera";
						MainWindow.<>c__DisplayClass58_0 CS$<>8__locals2 = CS$<>8__locals1;
						string serial;
						if (camera == null)
						{
							serial = null;
						}
						else
						{
							CameraParameterConfig cameraConfig = camera.CameraConfig;
							serial = ((cameraConfig != null) ? cameraConfig.ConnectedCameraId : null);
						}
						CS$<>8__locals2.serial = serial;
						bool flag2 = string.IsNullOrWhiteSpace(CS$<>8__locals1.serial);
						if (flag2)
						{
							VisionLogService.Log("Warn", "Camera '" + name + "': no serial assigned (not connected).");
						}
						else
						{
							bool isPresent = connected != null && connected.Any((ConnectedCameraInfo c) => c != null && string.Equals(c.Id, CS$<>8__locals1.serial, StringComparison.OrdinalIgnoreCase));
							bool flag3 = isPresent;
							if (flag3)
							{
								VisionLogService.Log("Info", string.Concat(new string[]
								{
									"Camera '",
									name,
									"' connected (serial ",
									CS$<>8__locals1.serial,
									")."
								}));
							}
							else
							{
								VisionLogService.Log("Warn", string.Concat(new string[]
								{
									"Camera '",
									name,
									"' NOT found (serial ",
									CS$<>8__locals1.serial,
									")."
								}));
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				VisionLogService.Log("Error", "Camera status check failed: " + ex.Message);
			}
		}

		// Token: 0x0600156C RID: 5484 RVA: 0x00066AE0 File Offset: 0x00064CE0
		private void PreloadRuntimeToolFiles()
		{
			try
			{
				ToolRuntimePreloadResult result = ToolRuntimePreloadService.PreloadFromCameras(this.MainViewModel.Cameras);
				VisionLogService.Log("Info", string.Concat(new string[]
				{
					"Tool data loaded: ",
					result.ShapeModelCount.ToString(),
					" shape, ",
					result.AnisoShapeModelCount.ToString(),
					" aniso, ",
					result.OverlappingShapeModelCount.ToString(),
					" overlapping, ",
					result.CalibHandEyeCount.ToString(),
					" calib, ",
					result.ProcedureModelCount.ToString(),
					" procedure."
				}));
				foreach (string error in result.Errors)
				{
					VisionLogService.Log("Warn", error);
				}
			}
			catch (Exception ex)
			{
				VisionLogService.Log("Error", "Tool data preload failed: " + ex.Message);
				Debug.WriteLine("Runtime tool preload failed: " + ex.Message);
			}
		}

		// Token: 0x0600156D RID: 5485 RVA: 0x00066C34 File Offset: 0x00064E34
		private void WarmupCameras(ISet<string> connectedCameraIds)
		{
			MainWindow.<>c__DisplayClass60_0 CS$<>8__locals1 = new MainWindow.<>c__DisplayClass60_0();
			MainWindow.<>c__DisplayClass60_0 CS$<>8__locals2 = CS$<>8__locals1;
			ObservableCollection<CameraNode> cameras = this.MainViewModel.Cameras;
			CS$<>8__locals2.cameras = (((cameras != null) ? cameras.ToList<CameraNode>() : null) ?? new List<CameraNode>());
			CS$<>8__locals1.availableIds = ((connectedCameraIds == null) ? null : new HashSet<string>(connectedCameraIds, StringComparer.OrdinalIgnoreCase));
			Task.Run(delegate()
			{
				try
				{
					CameraWarmupResult result = CameraSnapshotWarmupService.WarmupCameras(CS$<>8__locals1.cameras, CS$<>8__locals1.availableIds);
					bool flag = result.WarmedCount > 0;
					if (flag)
					{
						VisionLogService.Log("Info", "Camera", null, string.Concat(new string[]
						{
							"Cameras ready: ",
							result.WarmedCount.ToString(),
							" opened in ",
							result.ElapsedMs.ToString("0"),
							" ms",
							(result.SkippedCount > 0) ? (", " + result.SkippedCount.ToString() + " skipped") : string.Empty,
							"."
						}), null, null);
					}
					foreach (string error in result.Errors)
					{
						VisionLogService.Log("Warn", error);
					}
				}
				catch (Exception ex)
				{
					VisionLogService.Log("Warn", "Camera warm-up failed: " + ex.Message);
				}
			});
		}

		// Token: 0x0600156E RID: 5486 RVA: 0x00066C98 File Offset: 0x00064E98
		private void PreloadDLObjectModels()
		{
			try
			{
				DLObjectInspectionStartupLoader.PreloadAll(this.MainViewModel.Cameras, delegate(string level, string message)
				{
					VisionLogService.Log(level, message);
				});
			}
			catch (Exception ex)
			{
				Debug.WriteLine("DL model preload failed: " + ex.Message);
			}
		}

		// Token: 0x0600156F RID: 5487 RVA: 0x0000AB39 File Offset: 0x00008D39
		private void RefreshMainUI()
		{
		}

		// Token: 0x06001570 RID: 5488 RVA: 0x00066D08 File Offset: 0x00064F08
		private void StartClock()
		{
			this.UpdateDateTime();
			this.UpdateSystemStatus();
			this._clockTimer = new DispatcherTimer();
			this._clockTimer.Interval = TimeSpan.FromSeconds(1.0);
			this._clockTimer.Tick += delegate(object s, EventArgs e)
			{
				this.UpdateDateTime();
				this.UpdateSystemStatus();
			};
			this._clockTimer.Start();
		}

		// Token: 0x06001571 RID: 5489 RVA: 0x00066D70 File Offset: 0x00064F70
		private void UpdateDateTime()
		{
			this.txtTime.Text = DateTime.Now.ToString("HH:mm:ss");
			this.txtDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
		}

		// Token: 0x06001572 RID: 5490 RVA: 0x00066DBC File Offset: 0x00064FBC
		private void UpdateSystemStatus()
		{
			bool plcConnected = CameraTriggerCommunicationService.IsActiveConnectionConnected();
			bool flag = this.TopSystemStatusText != null;
			if (flag)
			{
				this.TopSystemStatusText.Text = (plcConnected ? "System Ready" : "System Not Ready");
				this.TopSystemStatusText.Foreground = (plcConnected ? new SolidColorBrush(Color.FromRgb(34, 197, 94)) : new SolidColorBrush(Color.FromRgb(248, 113, 113)));
			}
			bool flag2 = this.TopSystemStatusIndicator != null;
			if (flag2)
			{
				this.TopSystemStatusIndicator.Fill = (plcConnected ? new SolidColorBrush(Color.FromRgb(29, byte.MaxValue, 110)) : new SolidColorBrush(Color.FromRgb(248, 113, 113)));
			}
			this.UpdateHomeSystemStatus(plcConnected);
		}

		// Token: 0x06001573 RID: 5491 RVA: 0x00066E80 File Offset: 0x00065080
		private void UpdateHomeSystemStatus(bool plcConnected)
		{
			try
			{
				Form_home form_home = Form_home.Instance;
				if (form_home != null)
				{
					form_home.UpdateHomeConnectionStatus(new bool?(plcConnected));
				}
			}
			catch
			{
			}
			try
			{
				foreach (DocumentPanel panel in this.documentGroup.Items.OfType<DocumentPanel>())
				{
					Form_home home = panel.Content as Form_home;
					if (home != null)
					{
						home.UpdateHomeConnectionStatus(new bool?(plcConnected));
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x040008D6 RID: 2262
		public MainViewModel MainViewModel = new MainViewModel();

		// Token: 0x040008D7 RID: 2263
		public static MainWindow instance;

		// Token: 0x040008D8 RID: 2264
		private DispatcherTimer _clockTimer;

		// Token: 0x040008D9 RID: 2265
		private Task _communicationStartupTask;

		// Token: 0x040008DA RID: 2266
		private bool _communicationRuntimeInitialized;

		// Token: 0x040008DB RID: 2267
		private bool _licenseWarningScheduled;

		// Token: 0x040008DC RID: 2268
		private readonly HashSet<DocumentPanel> _trackedDocumentPanels = new HashSet<DocumentPanel>();

		// Token: 0x040008DD RID: 2269
		private readonly Dictionary<string, string> _documentCaptions = new Dictionary<string, string>();
	}
}
