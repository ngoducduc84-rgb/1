﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using VisionMachine.Helpers;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Camera;
using VisionMachine.Services.Communication;
using VisionMachine.Services.Model;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Runtime;
using VisionMachine.Services.Storage;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Camera;
using VisionMachine.Views.Home;
using VisionMachine.Views.Main;
using VisionMachine.Views.Setting;

namespace VisionMachine.Views.Model
{
	// Token: 0x020001BC RID: 444
	public partial class Form_model : ThemedWindow, IStyleConnector
	{
		// Token: 0x0600199D RID: 6557 RVA: 0x000850E8 File Offset: 0x000832E8
		public Form_model()
		{
			this.InitializeComponent();
			this.itemsCameraList.ItemsSource = this._cameraList;
			this.LoadDataToGrid();
			this.LoadFromRuntimeStore();
		}

		// Token: 0x0600199E RID: 6558 RVA: 0x00085148 File Offset: 0x00083348
		private void LoadFromRuntimeStore()
		{
			this.LoadCameraFromRuntimeStore();
			this.LoadModelFromRuntimeStore();
		}

		// Token: 0x0600199F RID: 6559 RVA: 0x0008515C File Offset: 0x0008335C
		private void LoadCameraFromRuntimeStore()
		{
			this._cameraList.Clear();
			foreach (CameraItem cam in CameraRuntimeStore.Cameras)
			{
				this._cameraList.Add(cam);
			}
			this.Count_per_row.Value = CameraRuntimeStore.Count_per_row;
		}

		// Token: 0x060019A0 RID: 6560 RVA: 0x000851D8 File Offset: 0x000833D8
		private void LoadModelFromRuntimeStore()
		{
			this._models.Clear();
			foreach (ModelConfig i in ModelRuntimeStore.Models)
			{
				this._models.Add(i);
			}
			this.grid.ItemsSource = this._models;
			this.ApplyModelSearch();
			bool flag = ModelRuntimeStore.CurrentModel != null;
			if (flag)
			{
				this.FillFormFromModel(ModelRuntimeStore.CurrentModel, true);
				this.Current_model.Text = ModelRuntimeStore.CurrentModel.Model_name;
			}
			this.UpdateDeleteButtonState();
		}

		// Token: 0x060019A1 RID: 6561 RVA: 0x0008528C File Offset: 0x0008348C
		private void LoadDataToGrid()
		{
			this.grid.ItemsSource = this._models;
			this.ApplyModelSearch();
		}

		// Token: 0x060019A2 RID: 6562 RVA: 0x000852A8 File Offset: 0x000834A8
		private void ModelSearchBox_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			this.ApplyModelSearch();
		}

		// Token: 0x060019A3 RID: 6563 RVA: 0x000852B2 File Offset: 0x000834B2
		private void ApplyModelSearch()
		{
			ModelSearchFilter.Apply(this.grid, (this.ModelSearchBox == null) ? null : this.ModelSearchBox.Text);
		}

		// Token: 0x060019A4 RID: 6564 RVA: 0x000852D8 File Offset: 0x000834D8
		private bool ValidateForm()
		{
			bool flag = string.IsNullOrWhiteSpace(this.txtModelName.Text);
			bool result;
			if (flag)
			{
				DXMessageBox.Show(this, "Please enter a model name.", "Notification", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				this.txtModelName.Focus();
				result = false;
			}
			else
			{
				result = true;
			}
			return result;
		}

		// Token: 0x060019A5 RID: 6565 RVA: 0x00085324 File Offset: 0x00083524
		private void btnSave_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				this.UpdateCurrentModelFromForm();
				ModelStorageService.Save(Manager_path._modelJsonPath, this._models, this._currentLoadedModel);
				int countPerRow = Convert.ToInt32(this.Count_per_row.Value);
				bool flag = countPerRow <= 0;
				if (flag)
				{
					countPerRow = 1;
				}
				CameraStorageService.Save(Manager_path.path_Camera_Qty, this._cameraList, countPerRow);
				this.SyncCameraRuntimeStore();
				CameraRuntimeStore.SetCountPerRow(countPerRow);
				this.RefreshCameraViews();
				MainWindow instance = MainWindow.instance;
				CameraModelConfigStorageService.SaveCurrentModelConfig((instance != null) ? instance.MainViewModel : null);
				this.SyncModelRuntimeStore();
				TextBlock current_model = this.Current_model;
				ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
				current_model.Text = (((currentModel != null) ? currentModel.Model_name : null) ?? "No model selected");
				string[] array = new string[6];
				array[0] = "Saved successfully.\n\nModels: ";
				array[1] = this._models.Count.ToString();
				array[2] = "\nCameras: ";
				array[3] = this._cameraList.Count.ToString();
				array[4] = "\nCurrent model: ";
				int num = 5;
				ModelConfig currentModel2 = ModelRuntimeStore.CurrentModel;
				array[num] = (((currentModel2 != null) ? currentModel2.Model_name : null) ?? "none");
				DXMessageBox.Show(this, string.Concat(array), "Notification", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			catch (Exception ex)
			{
				Exception root = ex;
				while (root.InnerException != null)
				{
					root = root.InnerException;
				}
				string detail = (root == ex) ? ex.Message : (ex.Message + "\n\nCause: " + root.Message);
				DXMessageBox.Show(this, "Failed to save data.\n\n" + detail, "Notification", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}

		// Token: 0x060019A6 RID: 6566 RVA: 0x000854D8 File Offset: 0x000836D8
		private void DeleteCamera_Click(object sender, RoutedEventArgs e)
		{
			Button btn = sender as Button;
			CameraItem item = ((btn != null) ? btn.Tag : null) as CameraItem;
			bool flag = item != null;
			if (flag)
			{
				MessageBoxResult result = DXMessageBox.Show(this, "Are you sure you want to delete camera '" + item.CameraName + "'?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
				bool flag2 = result == MessageBoxResult.Yes;
				if (flag2)
				{
					this._cameraList.Remove(item);
					bool flag3 = this._selectedCamera == item;
					if (flag3)
					{
						this._selectedCamera = null;
					}
					this.SyncCameraRuntimeStore();
					this.RefreshCameraViews();
					this.ClearForm();
				}
			}
		}

		// Token: 0x060019A7 RID: 6567 RVA: 0x00085574 File Offset: 0x00083774
		private void CameraItem_Click(object sender, MouseButtonEventArgs e)
		{
			Grid grid = sender as Grid;
			CameraItem item;
			bool flag;
			if (grid != null)
			{
				item = (grid.DataContext as CameraItem);
				flag = (item != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				this._selectedCamera = item;
				this.txtCameraName.Text = item.CameraName;
				this.txtCategory.Text = item.Category;
				this.txtCameraVersion.Text = item.Version;
				this.txtCameraTags.Text = item.Tags;
			}
		}

		// Token: 0x060019A8 RID: 6568 RVA: 0x000855F4 File Offset: 0x000837F4
		private void ClearForm()
		{
			this.txtCameraName.Text = string.Empty;
			this.txtCategory.Text = string.Empty;
			this.txtCameraVersion.Text = "1.0.0";
			this.txtCameraTags.Text = string.Empty;
			this._selectedCamera = null;
		}

		// Token: 0x060019A9 RID: 6569 RVA: 0x00085650 File Offset: 0x00083850
		private bool ValidateInput()
		{
			bool flag = string.IsNullOrWhiteSpace(this.txtCameraName.Text);
			bool result;
			if (flag)
			{
				DXMessageBox.Show(this, "Please enter a camera name.", "Notification", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				this.txtCameraName.Focus();
				result = false;
			}
			else
			{
				result = true;
			}
			return result;
		}

		// Token: 0x060019AA RID: 6570 RVA: 0x0008569C File Offset: 0x0008389C
		private void btnAddCamera_Click(object sender, RoutedEventArgs e)
		{
			bool flag = string.IsNullOrWhiteSpace(this.txtCameraName.Text);
			if (flag)
			{
				DXMessageBox.Show(this, "Please enter a camera name first.", "Notification", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				this.txtCameraName.Focus();
			}
			else
			{
				CameraItem cameraItem = new CameraItem();
				cameraItem.CameraName = this.txtCameraName.Text.Trim();
				string text = this.txtCategory.Text;
				cameraItem.Category = ((text != null) ? text.Trim() : null);
				string text2 = this.txtCameraVersion.Text;
				cameraItem.Version = ((text2 != null) ? text2.Trim() : null);
				string text3 = this.txtCameraTags.Text;
				cameraItem.Tags = ((text3 != null) ? text3.Trim() : null);
				CameraItem cam = cameraItem;
				this._cameraList.Add(cam);
				this.SyncCameraRuntimeStore();
				this.RefreshCameraViews();
				this.ClearCameraForm();
				DXMessageBox.Show(this, "Camera added.", "Notification", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
		}

		// Token: 0x060019AB RID: 6571 RVA: 0x00085794 File Offset: 0x00083994
		private void btnEditCamera_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this._selectedCamera == null;
			if (flag)
			{
				DXMessageBox.Show(this, "Please select a camera to edit.", "Notification", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			else
			{
				bool flag2 = string.IsNullOrWhiteSpace(this.txtCameraName.Text);
				if (flag2)
				{
					DXMessageBox.Show(this, "Please enter a camera name.", "Notification", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					this.txtCameraName.Focus();
				}
				else
				{
					this._selectedCamera.CameraName = this.txtCameraName.Text.Trim();
					CameraItem selectedCamera = this._selectedCamera;
					string text = this.txtCategory.Text;
					selectedCamera.Category = ((text != null) ? text.Trim() : null);
					CameraItem selectedCamera2 = this._selectedCamera;
					string text2 = this.txtCameraVersion.Text;
					selectedCamera2.Version = ((text2 != null) ? text2.Trim() : null);
					CameraItem selectedCamera3 = this._selectedCamera;
					string text3 = this.txtCameraTags.Text;
					selectedCamera3.Tags = ((text3 != null) ? text3.Trim() : null);
					this.itemsCameraList.Items.Refresh();
					this.SyncCameraRuntimeStore();
					this.RefreshCameraViews();
					this.ClearCameraForm();
					DXMessageBox.Show(this, "Camera updated.", "Notification", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
			}
		}

		// Token: 0x060019AC RID: 6572 RVA: 0x000858C4 File Offset: 0x00083AC4
		private void btnClearCamera_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this._cameraList.Count == 0;
			if (flag)
			{
				DXMessageBox.Show(this, "The camera list is empty.", "Notification", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				MessageBoxResult result = DXMessageBox.Show(this, "Are you sure you want to delete all cameras?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
				bool flag2 = result != MessageBoxResult.Yes;
				if (!flag2)
				{
					this._cameraList.Clear();
					this._selectedCamera = null;
					this.SyncCameraRuntimeStore();
					this.RefreshCameraViews();
					this.ClearCameraForm();
					DXMessageBox.Show(this, "All cameras were deleted.", "Notification", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
			}
		}

		// Token: 0x060019AD RID: 6573 RVA: 0x00085958 File Offset: 0x00083B58
		private void ClearCameraForm()
		{
			this.txtCameraName.Text = string.Empty;
			this.txtCameraVersion.Text = "1.0.0";
			this._selectedCamera = null;
		}

		// Token: 0x060019AE RID: 6574 RVA: 0x00085984 File Offset: 0x00083B84
		private void LoadCameraList(string filePath)
		{
			try
			{
				CameraStorageData data = CameraStorageService.Load(filePath);
				this._cameraList.Clear();
				foreach (CameraItem cam in data.Cameras)
				{
					this._cameraList.Add(cam);
				}
				this.Count_per_row.Value = data.Count_per_row;
			}
			catch (Exception ex)
			{
				DXMessageBox.Show(this, "Failed to load cameras.\n" + ex.Message, "Notification", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}

		// Token: 0x060019AF RID: 6575 RVA: 0x00085A40 File Offset: 0x00083C40
		private void SyncCameraRuntimeStore()
		{
			int countPerRow = Convert.ToInt32(this.Count_per_row.Value);
			bool flag = countPerRow <= 0;
			if (flag)
			{
				countPerRow = 1;
			}
			CameraRuntimeStore.SetList(this._cameraList);
			CameraRuntimeStore.SetCountPerRow(countPerRow);
			try
			{
				CameraCommunicationTagSyncService.SynchronizeCurrentModel(from x in this._cameraList
				select (x != null) ? x.CameraName : null);
			}
			catch (Exception ex)
			{
				Debug.WriteLine("Camera communication tag synchronization failed: " + ex.Message);
			}
		}

		// Token: 0x060019B0 RID: 6576 RVA: 0x00085AE0 File Offset: 0x00083CE0
		private void LoadModelList(string filePath)
		{
			try
			{
				List<ModelConfig> list = ModelStorageService.Load(filePath);
				this._models.Clear();
				foreach (ModelConfig i in list)
				{
					this._models.Add(i);
				}
				this.grid.ItemsSource = this._models;
				this.ApplyModelSearch();
				ModelConfig current = ModelRuntimeStore.CurrentModel;
				bool flag = current != null;
				if (flag)
				{
					this.FillFormFromModel(current, true);
				}
				bool flag2 = ModelRuntimeStore.CurrentModel != null;
				if (flag2)
				{
					this.Current_model.Text = ModelRuntimeStore.CurrentModel.Model_name;
				}
				this.grid.ItemsSource = this._models;
				this.ApplyModelSearch();
			}
			catch (Exception ex)
			{
				DXMessageBox.Show(this, "Failed to load models.\n" + ex.Message, "Notification", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}

		// Token: 0x060019B1 RID: 6577 RVA: 0x00085BF8 File Offset: 0x00083DF8
		private ModelConfig BuildModelFromForm()
		{
			string createdDate = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
			this.txtCreatedDate.Text = createdDate;
			ModelConfig modelConfig = new ModelConfig();
			modelConfig.Id = Guid.NewGuid();
			string text = this.txtModelName.Text;
			modelConfig.Model_name = ((text != null) ? text.Trim() : null);
			string text2 = this.txtCreatedBy.Text;
			modelConfig.Created_By = ((text2 != null) ? text2.Trim() : null);
			modelConfig.Created_Date = createdDate;
			return modelConfig;
		}

		// Token: 0x060019B2 RID: 6578 RVA: 0x00085C80 File Offset: 0x00083E80
		private void FillFormFromModel(ModelConfig model, bool setAsLoadedModel = true)
		{
			bool flag = model == null;
			if (!flag)
			{
				this.txtModelName.Text = model.Model_name;
				this.txtCreatedBy.Text = model.Created_By;
				this.txtCreatedDate.Text = model.Created_Date;
				if (setAsLoadedModel)
				{
					this._currentLoadedModel = model;
				}
			}
		}

		// Token: 0x060019B3 RID: 6579 RVA: 0x00085CDC File Offset: 0x00083EDC
		private void ClearModelForm()
		{
			this.txtModelName.Text = string.Empty;
			this.txtCreatedBy.Text = "Admin";
			this.txtCreatedDate.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
			this._currentLoadedModel = null;
			ModelRuntimeStore.ClearCurrentModel();
		}

		// Token: 0x060019B4 RID: 6580 RVA: 0x00085D37 File Offset: 0x00083F37
		private void SyncModelRuntimeStore()
		{
			ModelRuntimeStore.SetModels(this._models);
			ModelRuntimeStore.SetCurrentModel(this._currentLoadedModel);
			this.UpdateDeleteButtonState();
		}

		// Token: 0x060019B5 RID: 6581 RVA: 0x00085D5C File Offset: 0x00083F5C
		[DebuggerStepThrough]
		private Task ReloadCurrentModelRecipeAndRuntimeCacheAsync()
		{
			Form_model.<ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__30 <ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__ = new Form_model.<ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__30();
			<ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__.<>4__this = this;
			<ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__.<>1__state = -1;
			<ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__.<>t__builder.Start<Form_model.<ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__30>(ref <ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__);
			return <ReloadCurrentModelRecipeAndRuntimeCacheAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060019B6 RID: 6582 RVA: 0x00085DA0 File Offset: 0x00083FA0
		[DebuggerStepThrough]
		private void btnCreateModel_Click(object sender, RoutedEventArgs e)
		{
			Form_model.<btnCreateModel_Click>d__31 <btnCreateModel_Click>d__ = new Form_model.<btnCreateModel_Click>d__31();
			<btnCreateModel_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<btnCreateModel_Click>d__.<>4__this = this;
			<btnCreateModel_Click>d__.sender = sender;
			<btnCreateModel_Click>d__.e = e;
			<btnCreateModel_Click>d__.<>1__state = -1;
			<btnCreateModel_Click>d__.<>t__builder.Start<Form_model.<btnCreateModel_Click>d__31>(ref <btnCreateModel_Click>d__);
		}

		// Token: 0x060019B7 RID: 6583 RVA: 0x00085DE8 File Offset: 0x00083FE8
		private void CloneCurrentModelFolder(string newModelName)
		{
			ModelConfig current = ModelRuntimeStore.CurrentModel;
			bool flag = current == null || string.IsNullOrWhiteSpace(newModelName);
			if (!flag)
			{
				string sourceFolder = RecipePathService.GetModelFolder(current.Model_name);
				string destFolder = RecipePathService.GetModelFolder(newModelName);
				bool flag2 = string.IsNullOrWhiteSpace(sourceFolder) || !Directory.Exists(sourceFolder);
				if (!flag2)
				{
					bool flag3 = string.Equals(Path.GetFullPath(sourceFolder), Path.GetFullPath(destFolder), StringComparison.OrdinalIgnoreCase);
					if (!flag3)
					{
						Form_model.CopyDirectory(sourceFolder, destFolder);
						string currentRecipe = Path.Combine(destFolder, RecipePathService.MakeSafeFileName(current.Model_name) + ".json");
						string newRecipe = Path.Combine(destFolder, RecipePathService.MakeSafeFileName(newModelName) + ".json");
						bool flag4 = File.Exists(currentRecipe) && !string.Equals(currentRecipe, newRecipe, StringComparison.OrdinalIgnoreCase);
						if (flag4)
						{
							bool flag5 = File.Exists(newRecipe);
							if (flag5)
							{
								File.Delete(newRecipe);
							}
							File.Move(currentRecipe, newRecipe);
						}
					}
				}
			}
		}

		// Token: 0x060019B8 RID: 6584 RVA: 0x00085EDC File Offset: 0x000840DC
		private static void CopyDirectory(string sourceDir, string destDir)
		{
			Directory.CreateDirectory(destDir);
			foreach (string file in Directory.GetFiles(sourceDir))
			{
				string target = Path.Combine(destDir, Path.GetFileName(file));
				File.Copy(file, target, true);
			}
			foreach (string dir in Directory.GetDirectories(sourceDir))
			{
				Form_model.CopyDirectory(dir, Path.Combine(destDir, Path.GetFileName(dir)));
			}
		}

		// Token: 0x060019B9 RID: 6585 RVA: 0x00085F60 File Offset: 0x00084160
		[DebuggerStepThrough]
		private void btnLoadModel_Click(object sender, RoutedEventArgs e)
		{
			Form_model.<btnLoadModel_Click>d__34 <btnLoadModel_Click>d__ = new Form_model.<btnLoadModel_Click>d__34();
			<btnLoadModel_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<btnLoadModel_Click>d__.<>4__this = this;
			<btnLoadModel_Click>d__.sender = sender;
			<btnLoadModel_Click>d__.e = e;
			<btnLoadModel_Click>d__.<>1__state = -1;
			<btnLoadModel_Click>d__.<>t__builder.Start<Form_model.<btnLoadModel_Click>d__34>(ref <btnLoadModel_Click>d__);
		}

		// Token: 0x060019BA RID: 6586 RVA: 0x00085FA8 File Offset: 0x000841A8
		private bool IsCurrentModel(ModelConfig model)
		{
			bool flag = model == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = this._currentLoadedModel != null && this._currentLoadedModel.Id == model.Id;
				if (flag2)
				{
					result = true;
				}
				else
				{
					ModelConfig running = ModelRuntimeStore.CurrentModel;
					result = (running != null && running.Id == model.Id);
				}
			}
			return result;
		}

		// Token: 0x060019BB RID: 6587 RVA: 0x0008600C File Offset: 0x0008420C
		private void UpdateDeleteButtonState()
		{
			bool flag = this.btnDeleteModel == null;
			if (!flag)
			{
				this.btnDeleteModel.IsEnabled = !this.IsCurrentModel(this.grid.SelectedItem as ModelConfig);
			}
		}

		// Token: 0x060019BC RID: 6588 RVA: 0x00086050 File Offset: 0x00084250
		private void btnDeleteModel_Click(object sender, RoutedEventArgs e)
		{
			ModelConfig selected = this.grid.SelectedItem as ModelConfig;
			bool flag = selected == null;
			if (flag)
			{
				DXMessageBox.Show(this, "Please select a model to delete.", "Notification", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			else
			{
				bool flag2 = this.IsCurrentModel(selected);
				if (flag2)
				{
					DXMessageBox.Show(this, "Model '" + selected.Model_name + "' is the model in use and cannot be deleted.\n\nLoad a different model first, then delete this one.", "Notification", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					this.UpdateDeleteButtonState();
				}
				else
				{
					MessageBoxResult result = DXMessageBox.Show(this, "Are you sure you want to delete model '" + selected.Model_name + "'?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
					bool flag3 = result != MessageBoxResult.Yes;
					if (!flag3)
					{
						this._models.Remove(selected);
						ModelStorageService.Save(Manager_path._modelJsonPath, this._models, this._currentLoadedModel);
						this.SyncModelRuntimeStore();
						this.RefreshHomeModelInfo();
						this.grid.ItemsSource = null;
						this.grid.ItemsSource = this._models;
						this.ApplyModelSearch();
						DXMessageBox.Show(this, "Model deleted successfully.", "Notification", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					}
				}
			}
		}

		// Token: 0x060019BD RID: 6589 RVA: 0x0008616C File Offset: 0x0008436C
		private void UpdateCurrentModelFromForm()
		{
			bool flag = this._currentLoadedModel == null;
			if (!flag)
			{
				ModelConfig selected = this.grid.SelectedItem as ModelConfig;
				bool flag2 = selected != null && selected.Id != this._currentLoadedModel.Id;
				if (!flag2)
				{
					ModelConfig currentLoadedModel = this._currentLoadedModel;
					string text = this.txtModelName.Text;
					currentLoadedModel.Model_name = ((text != null) ? text.Trim() : null);
					ModelConfig currentLoadedModel2 = this._currentLoadedModel;
					string text2 = this.txtCreatedBy.Text;
					currentLoadedModel2.Created_By = ((text2 != null) ? text2.Trim() : null);
				}
			}
		}

		// Token: 0x060019BE RID: 6590 RVA: 0x00086204 File Offset: 0x00084404
		private void grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			this.UpdateDeleteButtonState();
			ModelConfig selected = this.grid.SelectedItem as ModelConfig;
			bool flag = selected == null;
			if (!flag)
			{
				this.FillFormFromModel(selected, false);
				this.UpdateDeleteButtonState();
			}
		}

		// Token: 0x060019BF RID: 6591 RVA: 0x00086244 File Offset: 0x00084444
		private void RefreshCameraViews()
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			bool flag = vm != null;
			if (flag)
			{
				Form_model.<>c__DisplayClass40_0 CS$<>8__locals1 = new Form_model.<>c__DisplayClass40_0();
				Form_model.<>c__DisplayClass40_0 CS$<>8__locals2 = CS$<>8__locals1;
				CameraNode selectedCamera2 = vm.SelectedCamera;
				string selectedCameraName;
				if (selectedCamera2 == null)
				{
					selectedCameraName = null;
				}
				else
				{
					CameraItem cameraInfo = selectedCamera2.CameraInfo;
					selectedCameraName = ((cameraInfo != null) ? cameraInfo.CameraName : null);
				}
				CS$<>8__locals2.selectedCameraName = selectedCameraName;
				vm.SyncCamerasFromRuntimeStorePreserveTurns();
				bool flag2 = !string.IsNullOrWhiteSpace(CS$<>8__locals1.selectedCameraName);
				if (flag2)
				{
					CameraNode selectedCamera = vm.Cameras.FirstOrDefault(delegate(CameraNode x)
					{
						CameraItem cameraInfo2 = x.CameraInfo;
						return ((cameraInfo2 != null) ? cameraInfo2.CameraName : null) == CS$<>8__locals1.selectedCameraName;
					});
					bool flag3 = selectedCamera != null;
					if (flag3)
					{
						vm.SelectedCamera = selectedCamera;
					}
				}
				bool flag4 = vm.SelectedCamera == null;
				if (flag4)
				{
					vm.SelectedCamera = vm.Cameras.FirstOrDefault<CameraNode>();
				}
			}
			Form_home instance2 = Form_home.Instance;
			if (instance2 != null)
			{
				instance2.RefreshCameraLayout();
			}
			Form_setting instance3 = Form_setting.Instance;
			if (instance3 != null)
			{
				instance3.RefreshCameraListBinding();
			}
			Form_Camera instance4 = Form_Camera.Instance;
			if (instance4 != null)
			{
				instance4.RefreshCameraListBinding();
			}
			Form_Camera instance5 = Form_Camera.Instance;
			if (instance5 != null)
			{
				instance5.RefreshCameraLayout();
			}
		}

		// Token: 0x060019C0 RID: 6592 RVA: 0x00086348 File Offset: 0x00084548
		private void RefreshHomeModelInfo()
		{
			Form_home instance = Form_home.Instance;
			if (instance != null)
			{
				instance.RefreshModelInfo();
			}
		}

		// Token: 0x060019C1 RID: 6593 RVA: 0x0008635C File Offset: 0x0008455C
		private void Grid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
		{
			DependencyObject source = e.OriginalSource as DependencyObject;
			while (source != null && !(source is ListBoxItem))
			{
				source = VisualTreeHelper.GetParent(source);
			}
			ListBoxItem item = source as ListBoxItem;
			ModelConfig model = ((item != null) ? item.DataContext : null) as ModelConfig;
			bool flag = model != null;
			if (flag)
			{
				this.grid.SelectedItem = model;
			}
		}

		// Token: 0x060019C2 RID: 6594 RVA: 0x000863C8 File Offset: 0x000845C8
		[DebuggerStepThrough]
		private void RenameModel_Click(object sender, RoutedEventArgs e)
		{
			Form_model.<RenameModel_Click>d__43 <RenameModel_Click>d__ = new Form_model.<RenameModel_Click>d__43();
			<RenameModel_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<RenameModel_Click>d__.<>4__this = this;
			<RenameModel_Click>d__.sender = sender;
			<RenameModel_Click>d__.e = e;
			<RenameModel_Click>d__.<>1__state = -1;
			<RenameModel_Click>d__.<>t__builder.Start<Form_model.<RenameModel_Click>d__43>(ref <RenameModel_Click>d__);
		}

		// Token: 0x060019C6 RID: 6598 RVA: 0x000866F8 File Offset: 0x000848F8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId != 16)
			{
				if (connectionId == 17)
				{
					((Button)target).Click += this.DeleteCamera_Click;
				}
			}
			else
			{
				((Grid)target).MouseLeftButtonUp += this.CameraItem_Click;
			}
		}

		// Token: 0x04000A92 RID: 2706
		private ObservableCollection<ModelConfig> _models = new ObservableCollection<ModelConfig>();

		// Token: 0x04000A93 RID: 2707
		private ModelConfig _currentLoadedModel;

		// Token: 0x04000A94 RID: 2708
		private bool _isModelOperationRunning;

		// Token: 0x04000A95 RID: 2709
		private ObservableCollection<CameraItem> _cameraList = new ObservableCollection<CameraItem>();

		// Token: 0x04000A96 RID: 2710
		private int _columnsPerRow = 3;

		// Token: 0x04000A97 RID: 2711
		private CameraItem _selectedCamera = null;
	}
}
