﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using DevExpress.Xpf.Core;

namespace VisionMachine.Views.Model
{
	// Token: 0x020001BB RID: 443
	public partial class Form_rename_model : ThemedWindow
	{
		// Token: 0x170008A6 RID: 2214
		// (get) Token: 0x06001994 RID: 6548 RVA: 0x00084EBE File Offset: 0x000830BE
		// (set) Token: 0x06001995 RID: 6549 RVA: 0x00084EC6 File Offset: 0x000830C6
		public string NewName { get; private set; }

		// Token: 0x06001996 RID: 6550 RVA: 0x00084ED0 File Offset: 0x000830D0
		public Form_rename_model(string currentName)
		{
			this.InitializeComponent();
			this.NewName = currentName;
			this.txtCurrentName.Text = "Current name: " + (currentName ?? string.Empty);
			this.txtNewName.Text = (currentName ?? string.Empty);
			base.Loaded += delegate(object s, RoutedEventArgs e)
			{
				this.txtNewName.Focus();
				this.txtNewName.SelectAll();
			};
		}

		// Token: 0x06001997 RID: 6551 RVA: 0x00084F40 File Offset: 0x00083140
		private void BtnConfirm_Click(object sender, RoutedEventArgs e)
		{
			string value = (this.txtNewName.Text ?? string.Empty).Trim();
			bool flag = string.IsNullOrWhiteSpace(value);
			if (flag)
			{
				DXMessageBox.Show(this, "Please enter a model name.", "Rename Model", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				this.txtNewName.Focus();
			}
			else
			{
				this.NewName = value;
				base.DialogResult = new bool?(true);
			}
		}

		// Token: 0x06001998 RID: 6552 RVA: 0x0008324B File Offset: 0x0008144B
		private void BtnCancel_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = new bool?(false);
		}

		// Token: 0x06001999 RID: 6553 RVA: 0x00084FAC File Offset: 0x000831AC
		private void TxtNewName_KeyDown(object sender, KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				this.BtnConfirm_Click(sender, e);
				e.Handled = true;
			}
		}
	}
}
