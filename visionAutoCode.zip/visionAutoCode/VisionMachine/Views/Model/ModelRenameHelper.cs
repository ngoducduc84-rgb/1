﻿using System;
using System.Collections.Generic;
using System.Windows;
using DevExpress.Xpf.Core;
using VisionMachine.Models.Recipe;
using VisionMachine.Services.Recipe;

namespace VisionMachine.Views.Model
{
	// Token: 0x020001BA RID: 442
	public static class ModelRenameHelper
	{
		// Token: 0x06001993 RID: 6547 RVA: 0x00084DF0 File Offset: 0x00082FF0
		public static bool PromptAndRename(Window owner, ModelConfig model, IEnumerable<ModelConfig> allModels)
		{
			bool flag = model == null;
			bool result2;
			if (flag)
			{
				result2 = false;
			}
			else
			{
				string originalName = model.Model_name;
				Form_rename_model dialog = new Form_rename_model(originalName);
				bool flag2 = owner != null && owner.IsLoaded;
				if (flag2)
				{
					dialog.Owner = owner;
				}
				bool flag3 = !dialog.ShowDialog().GetValueOrDefault();
				if (flag3)
				{
					result2 = false;
				}
				else
				{
					ModelRenameService.RenameResult result = ModelRenameService.Rename(model, dialog.NewName, allModels);
					bool flag4 = !result.IsSuccess;
					if (flag4)
					{
						DXMessageBox.Show(owner, result.Message, "Rename Model", MessageBoxButton.OK, MessageBoxImage.Exclamation);
						result2 = false;
					}
					else
					{
						bool flag5 = string.Equals(originalName, model.Model_name);
						if (flag5)
						{
							result2 = false;
						}
						else
						{
							DXMessageBox.Show(owner, result.Message, "Rename Model", MessageBoxButton.OK, MessageBoxImage.Asterisk);
							result2 = true;
						}
					}
				}
			}
			return result2;
		}
	}
}
