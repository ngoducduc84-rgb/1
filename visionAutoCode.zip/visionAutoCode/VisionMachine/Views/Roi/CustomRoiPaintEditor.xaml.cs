﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using DevExpress.Xpf.Core;
using HalconDotNet;

namespace VisionMachine.Views.Roi
{
	// Token: 0x020001B8 RID: 440
	public partial class CustomRoiPaintEditor : ThemedWindow
	{
		// Token: 0x17000897 RID: 2199
		// (get) Token: 0x06001942 RID: 6466 RVA: 0x00082D24 File Offset: 0x00080F24
		public HObject Region
		{
			get
			{
				return this._region;
			}
		}

		// Token: 0x06001943 RID: 6467 RVA: 0x00082D3C File Offset: 0x00080F3C
		public CustomRoiPaintEditor(HObject image, HObject initialRegion)
		{
			this.InitializeComponent();
			this._image = image;
			bool flag = initialRegion != null && initialRegion.IsInitialized();
			if (flag)
			{
				HOperatorSet.CopyObj(initialRegion, out this._region, 1, -1);
			}
			else
			{
				HOperatorSet.GenEmptyRegion(out this._region);
			}
			this.UpdateBrushPreview();
			base.Loaded += delegate(object s, RoutedEventArgs e)
			{
				this._windowReady = true;
				this.FitImage();
				this.Redraw();
			};
			base.Closed += delegate(object s, EventArgs e)
			{
				this.Cleanup();
			};
		}

		// Token: 0x17000898 RID: 2200
		// (get) Token: 0x06001944 RID: 6468 RVA: 0x00082DC4 File Offset: 0x00080FC4
		private bool IsEraser
		{
			get
			{
				return this.BtnEraser.IsChecked.GetValueOrDefault();
			}
		}

		// Token: 0x17000899 RID: 2201
		// (get) Token: 0x06001945 RID: 6469 RVA: 0x00082DEC File Offset: 0x00080FEC
		private double BrushRadius
		{
			get
			{
				return Math.Max(1.0, this.BrushSizeSlider.Value / 2.0);
			}
		}

		// Token: 0x06001946 RID: 6470 RVA: 0x00082E21 File Offset: 0x00081021
		private void BtnBrush_Click(object sender, RoutedEventArgs e)
		{
			this.BtnBrush.IsChecked = new bool?(true);
			this.BtnEraser.IsChecked = new bool?(false);
			this.UpdateToolHighlight();
		}

		// Token: 0x06001947 RID: 6471 RVA: 0x00082E4F File Offset: 0x0008104F
		private void BtnEraser_Click(object sender, RoutedEventArgs e)
		{
			this.BtnEraser.IsChecked = new bool?(true);
			this.BtnBrush.IsChecked = new bool?(false);
			this.UpdateToolHighlight();
		}

		// Token: 0x06001948 RID: 6472 RVA: 0x00082E80 File Offset: 0x00081080
		private void UpdateToolHighlight()
		{
			this.BtnBrush.BorderBrush = (this.BtnBrush.IsChecked.GetValueOrDefault() ? Brushes.DodgerBlue : new SolidColorBrush(Color.FromRgb(51, 65, 85)));
			this.BtnEraser.BorderBrush = (this.BtnEraser.IsChecked.GetValueOrDefault() ? Brushes.DodgerBlue : new SolidColorBrush(Color.FromRgb(51, 65, 85)));
			bool flag = this.BrushCursor != null && this.BrushCursor.Visibility == Visibility.Visible && this.PaintWindow != null && this.PaintWindow.IsMouseOver;
			if (flag)
			{
				this.UpdateBrushCursor(Mouse.GetPosition(this.PaintWindow));
			}
		}

		// Token: 0x06001949 RID: 6473 RVA: 0x00082F44 File Offset: 0x00081144
		private void BrushSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			this.UpdateBrushPreview();
			bool flag = this.BrushCursor != null && this.BrushCursor.Visibility == Visibility.Visible && this.PaintWindow != null && this.PaintWindow.IsMouseOver;
			if (flag)
			{
				this.UpdateBrushCursor(Mouse.GetPosition(this.PaintWindow));
			}
		}

		// Token: 0x0600194A RID: 6474 RVA: 0x00082F9C File Offset: 0x0008119C
		private void UpdateBrushCursor(Point controlPosition)
		{
			bool flag = this.BrushCursor == null;
			if (!flag)
			{
				double screenDiameter = this.BrushSizeSlider.Value * this.GetZoomFactor();
				screenDiameter = Math.Max(4.0, screenDiameter);
				this.BrushCursor.Width = screenDiameter;
				this.BrushCursor.Height = screenDiameter;
				this.BrushCursor.Stroke = ((this.IsEraser || this._paintWithRightButton) ? Brushes.OrangeRed : Brushes.White);
				Canvas.SetLeft(this.BrushCursor, controlPosition.X - screenDiameter / 2.0);
				Canvas.SetTop(this.BrushCursor, controlPosition.Y - screenDiameter / 2.0);
				this.BrushCursor.Visibility = Visibility.Visible;
				this.PaintWindow.Cursor = (this._isPanning ? Cursors.SizeAll : Cursors.None);
			}
		}

		// Token: 0x0600194B RID: 6475 RVA: 0x0008308C File Offset: 0x0008128C
		private void HideBrushCursor()
		{
			bool flag = this.BrushCursor != null;
			if (flag)
			{
				this.BrushCursor.Visibility = Visibility.Collapsed;
			}
			bool flag2 = this.PaintWindow != null;
			if (flag2)
			{
				this.PaintWindow.Cursor = Cursors.Arrow;
			}
		}

		// Token: 0x0600194C RID: 6476 RVA: 0x000830D4 File Offset: 0x000812D4
		private double GetZoomFactor()
		{
			HWindow window = this.GetWindow();
			double r;
			double c;
			double r2;
			double c2;
			bool flag = window == null || !CustomRoiPaintEditor.TryGetPart(window, out r, out c, out r2, out c2);
			double result;
			if (flag)
			{
				result = 1.0;
			}
			else
			{
				double partWidth = c2 - c + 1.0;
				bool flag2 = partWidth <= 0.0 || this.PaintWindow.ActualWidth <= 0.0;
				if (flag2)
				{
					result = 1.0;
				}
				else
				{
					result = this.PaintWindow.ActualWidth / partWidth;
				}
			}
			return result;
		}

		// Token: 0x0600194D RID: 6477 RVA: 0x00083174 File Offset: 0x00081374
		private void UpdateBrushPreview()
		{
			bool flag = this.BrushPreview == null || this.BrushSizeText == null;
			if (!flag)
			{
				double size = Math.Min(56.0, Math.Max(6.0, this.BrushSizeSlider.Value / 3.0));
				this.BrushPreview.Width = size;
				this.BrushPreview.Height = size;
				this.BrushSizeText.Text = ((int)this.BrushSizeSlider.Value).ToString() + " px";
			}
		}

		// Token: 0x0600194E RID: 6478 RVA: 0x00083212 File Offset: 0x00081412
		private void BtnClear_Click(object sender, RoutedEventArgs e)
		{
			HObject region = this._region;
			if (region != null)
			{
				region.Dispose();
			}
			HOperatorSet.GenEmptyRegion(out this._region);
			this.Redraw();
		}

		// Token: 0x0600194F RID: 6479 RVA: 0x0008323A File Offset: 0x0008143A
		private void BtnFit_Click(object sender, RoutedEventArgs e)
		{
			this.FitImage();
			this.Redraw();
		}

		// Token: 0x06001950 RID: 6480 RVA: 0x0008324B File Offset: 0x0008144B
		private void BtnCancel_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = new bool?(false);
		}

		// Token: 0x06001951 RID: 6481 RVA: 0x0008325C File Offset: 0x0008145C
		private void BtnSave_Click(object sender, RoutedEventArgs e)
		{
			bool flag = this.GetRegionArea() <= 0.0;
			if (flag)
			{
				MessageBoxResult answer = DXMessageBox.Show(this, "Nothing has been painted, so this ROI would select no pixels at all.\n\nSave the empty region anyway?", "Custom ROI", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
				bool flag2 = answer != MessageBoxResult.Yes;
				if (flag2)
				{
					return;
				}
			}
			base.DialogResult = new bool?(true);
		}

		// Token: 0x06001952 RID: 6482 RVA: 0x000832B4 File Offset: 0x000814B4
		private void PaintWindow_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = e.ChangedButton == MouseButton.Left && e.ClickCount >= 2;
			if (flag)
			{
				this.FitImage();
				this.Redraw();
				e.Handled = true;
			}
			else
			{
				bool flag2 = e.ChangedButton == MouseButton.Middle;
				if (flag2)
				{
					this._isPanning = true;
					this._lastPanPosition = e.GetPosition(this.PaintWindow);
					this.PaintWindow.CaptureMouse();
					this.PaintWindow.Cursor = Cursors.SizeAll;
					e.Handled = true;
				}
				else
				{
					bool flag3 = e.ChangedButton != MouseButton.Left && e.ChangedButton != MouseButton.Right;
					if (!flag3)
					{
						this._isPainting = true;
						this._paintWithRightButton = (e.ChangedButton == MouseButton.Right);
						this._hasLastImagePoint = false;
						this.PaintWindow.CaptureMouse();
						this.PaintAt(e.GetPosition(this.PaintWindow));
						e.Handled = true;
					}
				}
			}
		}

		// Token: 0x06001953 RID: 6483 RVA: 0x000833AC File Offset: 0x000815AC
		private void PaintWindow_MouseMove(object sender, MouseEventArgs e)
		{
			this.UpdateBrushCursor(e.GetPosition(this.PaintWindow));
			bool isPanning = this._isPanning;
			if (isPanning)
			{
				this.Pan(e.GetPosition(this.PaintWindow));
				e.Handled = true;
			}
			else
			{
				bool flag = e.RightButton == MouseButtonState.Pressed || e.LeftButton == MouseButtonState.Pressed;
				if (flag)
				{
					e.Handled = true;
				}
				bool flag2 = !this._isPainting;
				if (!flag2)
				{
					bool buttonHeld = this._paintWithRightButton ? (e.RightButton == MouseButtonState.Pressed) : (e.LeftButton == MouseButtonState.Pressed);
					bool flag3 = !buttonHeld;
					if (flag3)
					{
						this.EndPaint();
					}
					else
					{
						this.PaintAt(e.GetPosition(this.PaintWindow));
					}
				}
			}
		}

		// Token: 0x06001954 RID: 6484 RVA: 0x0008346C File Offset: 0x0008166C
		private void PaintWindow_MouseUp(object sender, MouseButtonEventArgs e)
		{
			bool flag = this._isPanning && e.ChangedButton == MouseButton.Middle;
			if (flag)
			{
				this.EndPan();
			}
			else
			{
				bool flag2 = e.ChangedButton == MouseButton.Left || e.ChangedButton == MouseButton.Right;
				if (flag2)
				{
					this.EndPaint();
					e.Handled = true;
				}
			}
		}

		// Token: 0x06001955 RID: 6485 RVA: 0x000834C8 File Offset: 0x000816C8
		private void PaintWindow_MouseLeave(object sender, MouseEventArgs e)
		{
			bool flag = Mouse.LeftButton != MouseButtonState.Pressed && Mouse.RightButton != MouseButtonState.Pressed;
			if (flag)
			{
				this.EndPaint();
				this.HideBrushCursor();
			}
		}

		// Token: 0x06001956 RID: 6486 RVA: 0x00083500 File Offset: 0x00081700
		private void EndPaint()
		{
			bool flag = !this._isPainting;
			if (!flag)
			{
				this._isPainting = false;
				this._hasLastImagePoint = false;
				bool isMouseCaptured = this.PaintWindow.IsMouseCaptured;
				if (isMouseCaptured)
				{
					this.PaintWindow.ReleaseMouseCapture();
				}
				this.Redraw();
				this.UpdateAreaText();
			}
		}

		// Token: 0x06001957 RID: 6487 RVA: 0x00083554 File Offset: 0x00081754
		private void EndPan()
		{
			this._isPanning = false;
			bool isMouseCaptured = this.PaintWindow.IsMouseCaptured;
			if (isMouseCaptured)
			{
				this.PaintWindow.ReleaseMouseCapture();
			}
			this.PaintWindow.Cursor = (this.PaintWindow.IsMouseOver ? Cursors.None : Cursors.Arrow);
		}

		// Token: 0x06001958 RID: 6488 RVA: 0x000835AC File Offset: 0x000817AC
		private void PaintAt(Point controlPosition)
		{
			double row;
			double column;
			bool flag = !this.TryToImagePoint(controlPosition, out row, out column);
			if (!flag)
			{
				HObject stroke = null;
				try
				{
					bool hasLastImagePoint = this._hasLastImagePoint;
					if (hasLastImagePoint)
					{
						HObject line;
						HOperatorSet.GenRegionLine(out line, this._lastImageRow, this._lastImageColumn, row, column);
						HOperatorSet.DilationCircle(line, out stroke, this.BrushRadius);
						line.Dispose();
					}
					else
					{
						HOperatorSet.GenCircle(out stroke, row, column, this.BrushRadius);
					}
					this.ApplyStroke(stroke);
					this.DrawStrokeIncremental(stroke);
				}
				catch
				{
				}
				finally
				{
					if (stroke != null)
					{
						stroke.Dispose();
					}
				}
				this._lastImageRow = row;
				this._lastImageColumn = column;
				this._hasLastImagePoint = true;
			}
		}

		// Token: 0x06001959 RID: 6489 RVA: 0x000836A8 File Offset: 0x000818A8
		private void DrawStrokeIncremental(HObject stroke)
		{
			HWindow window = this.GetWindow();
			bool flag = window == null || stroke == null || !stroke.IsInitialized();
			if (!flag)
			{
				bool erase = this._paintWithRightButton || this.IsEraser;
				try
				{
					bool flag2 = erase;
					if (flag2)
					{
						HObject original = null;
						HObject remaining = null;
						try
						{
							HOperatorSet.ReduceDomain(this._image, stroke, out original);
							HOperatorSet.DispObj(original, window);
							HOperatorSet.Intersection(this._region, stroke, out remaining);
							this.DrawBlendedRegion(window, remaining);
						}
						finally
						{
							if (original != null)
							{
								original.Dispose();
							}
							if (remaining != null)
							{
								remaining.Dispose();
							}
						}
					}
					else
					{
						this.DrawBlendedRegion(window, stroke);
					}
				}
				catch
				{
				}
			}
		}

		// Token: 0x0600195A RID: 6490 RVA: 0x00083784 File Offset: 0x00081984
		private void ApplyStroke(HObject stroke)
		{
			bool flag = stroke == null || !stroke.IsInitialized();
			if (!flag)
			{
				bool erase = this._paintWithRightButton || this.IsEraser;
				bool flag2 = erase;
				HObject updated;
				if (flag2)
				{
					HOperatorSet.Difference(this._region, stroke, out updated);
				}
				else
				{
					HOperatorSet.Union2(this._region, stroke, out updated);
				}
				this._region.Dispose();
				this._region = updated;
			}
		}

		// Token: 0x0600195B RID: 6491 RVA: 0x000837F4 File Offset: 0x000819F4
		private void PaintWindow_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
		{
			e.Handled = true;
			HWindow window = this.GetWindow();
			double r;
			double c;
			double r2;
			double c2;
			bool flag = window == null || !CustomRoiPaintEditor.TryGetPart(window, out r, out c, out r2, out c2);
			if (!flag)
			{
				double partHeight = r2 - r + 1.0;
				double partWidth = c2 - c + 1.0;
				bool flag2 = partHeight <= 2.0 || partWidth <= 2.0;
				if (!flag2)
				{
					double factor = (e.Delta > 0) ? 0.8 : 1.25;
					double newHeight = Math.Max(16.0, partHeight * factor);
					double newWidth = Math.Max(16.0, partWidth * factor);
					Point mouse = e.GetPosition(this.PaintWindow);
					double relativeY = mouse.Y / Math.Max(1.0, this.PaintWindow.ActualHeight);
					double relativeX = mouse.X / Math.Max(1.0, this.PaintWindow.ActualWidth);
					double mouseRow = r + relativeY * partHeight;
					double mouseColumn = c + relativeX * partWidth;
					double newRow = mouseRow - relativeY * newHeight;
					double newCol = mouseColumn - relativeX * newWidth;
					CustomRoiPaintEditor.TrySetPart(window, newRow, newCol, newRow + newHeight - 1.0, newCol + newWidth - 1.0);
					this.Redraw();
					this.UpdateBrushCursor(mouse);
				}
			}
		}

		// Token: 0x0600195C RID: 6492 RVA: 0x0008397C File Offset: 0x00081B7C
		private void Pan(Point current)
		{
			HWindow window = this.GetWindow();
			double r;
			double c;
			double r2;
			double c2;
			bool flag = window == null || !CustomRoiPaintEditor.TryGetPart(window, out r, out c, out r2, out c2);
			if (!flag)
			{
				double dx = current.X - this._lastPanPosition.X;
				double dy = current.Y - this._lastPanPosition.Y;
				this._lastPanPosition = current;
				double partWidth = c2 - c + 1.0;
				double partHeight = r2 - r + 1.0;
				double imageDx = dx * partWidth / Math.Max(1.0, this.PaintWindow.ActualWidth);
				double imageDy = dy * partHeight / Math.Max(1.0, this.PaintWindow.ActualHeight);
				CustomRoiPaintEditor.TrySetPart(window, r - imageDy, c - imageDx, r2 - imageDy, c2 - imageDx);
				this.Redraw();
			}
		}

		// Token: 0x0600195D RID: 6493 RVA: 0x00083A64 File Offset: 0x00081C64
		private void FitImage()
		{
			HWindow window = this.GetWindow();
			bool flag = window == null || this._image == null || !this._image.IsInitialized();
			if (!flag)
			{
				try
				{
					HTuple width;
					HTuple height;
					HOperatorSet.GetImageSize(this._image, out width, out height);
					window.SetPart(0, 0, height.I - 1, width.I - 1);
				}
				catch
				{
				}
			}
		}

		// Token: 0x0600195E RID: 6494 RVA: 0x00083AE0 File Offset: 0x00081CE0
		private bool TryToImagePoint(Point controlPosition, out double row, out double column)
		{
			row = 0.0;
			column = 0.0;
			HWindow window = this.GetWindow();
			double r;
			double c;
			double r2;
			double c2;
			bool flag = window == null || !CustomRoiPaintEditor.TryGetPart(window, out r, out c, out r2, out c2);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				double controlWidth = this.PaintWindow.ActualWidth;
				double controlHeight = this.PaintWindow.ActualHeight;
				bool flag2 = controlWidth <= 0.0 || controlHeight <= 0.0;
				if (flag2)
				{
					result = false;
				}
				else
				{
					row = r + controlPosition.Y * (r2 - r + 1.0) / controlHeight;
					column = c + controlPosition.X * (c2 - c + 1.0) / controlWidth;
					result = true;
				}
			}
			return result;
		}

		// Token: 0x0600195F RID: 6495 RVA: 0x00083BB5 File Offset: 0x00081DB5
		private void PaintWindow_Initialized(object sender, EventArgs e)
		{
			this._windowReady = true;
		}

		// Token: 0x06001960 RID: 6496 RVA: 0x00083BBF File Offset: 0x00081DBF
		private void PaintWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this.Redraw();
		}

		// Token: 0x06001961 RID: 6497 RVA: 0x00083BCC File Offset: 0x00081DCC
		private void Redraw()
		{
			HWindow window = this.GetWindow();
			bool flag = window == null;
			if (!flag)
			{
				bool buffered = CustomRoiPaintEditor.TrySetGraphicFlush(false);
				try
				{
					window.ClearWindow();
					bool flag2 = this._image != null && this._image.IsInitialized();
					if (flag2)
					{
						HOperatorSet.DispObj(this._image, window);
					}
					bool flag3 = this._region != null && this._region.IsInitialized();
					if (flag3)
					{
						this.DrawTranslucentOverlay(window);
						HOperatorSet.SetDraw(window, "margin");
						HOperatorSet.SetLineWidth(window, 2);
						HOperatorSet.SetColor(window, "yellow");
						HOperatorSet.DispObj(this._region, window);
					}
				}
				catch
				{
				}
				finally
				{
					bool flag4 = buffered;
					if (flag4)
					{
						CustomRoiPaintEditor.TrySetGraphicFlush(true);
						try
						{
							window.FlushBuffer();
						}
						catch
						{
						}
					}
				}
			}
		}

		// Token: 0x06001962 RID: 6498 RVA: 0x00083CF4 File Offset: 0x00081EF4
		private static bool TrySetGraphicFlush(bool enabled)
		{
			bool result;
			try
			{
				HOperatorSet.SetSystem("flush_graphic", enabled ? "true" : "false");
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06001963 RID: 6499 RVA: 0x00083D44 File Offset: 0x00081F44
		private void DrawTranslucentOverlay(HWindow window)
		{
			this.DrawBlendedRegion(window, this._region);
		}

		// Token: 0x06001964 RID: 6500 RVA: 0x00083D58 File Offset: 0x00081F58
		private void DrawBlendedRegion(HWindow window, HObject region)
		{
			bool flag = region == null || !region.IsInitialized();
			if (!flag)
			{
				HObject blended = this.GetBlendedImage();
				bool flag2 = blended == null;
				if (!flag2)
				{
					HObject reduced = null;
					try
					{
						HTuple area;
						HTuple htuple;
						HTuple htuple2;
						HOperatorSet.AreaCenter(region, out area, out htuple, out htuple2);
						bool flag3 = area.Length == 0 || area.D <= 0.0;
						if (!flag3)
						{
							HOperatorSet.ReduceDomain(blended, region, out reduced);
							HOperatorSet.DispObj(reduced, window);
						}
					}
					catch
					{
					}
					finally
					{
						if (reduced != null)
						{
							reduced.Dispose();
						}
					}
				}
			}
		}

		// Token: 0x06001965 RID: 6501 RVA: 0x00083E14 File Offset: 0x00082014
		private HObject GetBlendedImage()
		{
			bool flag = this._blendedImage != null && this._blendedImage.IsInitialized();
			HObject result;
			if (flag)
			{
				result = this._blendedImage;
			}
			else
			{
				bool flag2 = this._image == null || !this._image.IsInitialized();
				if (flag2)
				{
					result = null;
				}
				else
				{
					HObject red = null;
					HObject green = null;
					HObject blue = null;
					HObject redScaled = null;
					HObject greenScaled = null;
					HObject blueScaled = null;
					try
					{
						HTuple channels;
						HOperatorSet.CountChannels(this._image, out channels);
						bool flag3 = channels.Length > 0 && channels[0].I >= 3;
						if (flag3)
						{
							HOperatorSet.AccessChannel(this._image, out red, 1);
							HOperatorSet.AccessChannel(this._image, out green, 2);
							HOperatorSet.AccessChannel(this._image, out blue, 3);
						}
						else
						{
							HOperatorSet.CopyObj(this._image, out red, 1, -1);
							HOperatorSet.CopyObj(this._image, out green, 1, -1);
							HOperatorSet.CopyObj(this._image, out blue, 1, -1);
						}
						HOperatorSet.ScaleImage(red, out redScaled, 0.55, 114.75);
						HOperatorSet.ScaleImage(green, out greenScaled, 0.55, 0);
						HOperatorSet.ScaleImage(blue, out blueScaled, 0.55, 0);
						HOperatorSet.Compose3(redScaled, greenScaled, blueScaled, out this._blendedImage);
						result = this._blendedImage;
					}
					catch
					{
						this._blendedImage = null;
						result = null;
					}
					finally
					{
						if (red != null)
						{
							red.Dispose();
						}
						if (green != null)
						{
							green.Dispose();
						}
						if (blue != null)
						{
							blue.Dispose();
						}
						if (redScaled != null)
						{
							redScaled.Dispose();
						}
						if (greenScaled != null)
						{
							greenScaled.Dispose();
						}
						if (blueScaled != null)
						{
							blueScaled.Dispose();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001966 RID: 6502 RVA: 0x00084054 File Offset: 0x00082254
		private void UpdateAreaText()
		{
			bool flag = this.AreaText == null;
			if (!flag)
			{
				double area = this.GetRegionArea();
				this.AreaText.Text = ((area <= 0.0) ? "Painted area: empty" : ("Painted area: " + area.ToString("0") + " px"));
				bool flag2 = this.StatusText != null;
				if (flag2)
				{
					this.StatusText.Text = (this.IsEraser ? "Eraser" : "Brush") + " - size " + ((int)this.BrushSizeSlider.Value).ToString() + " px";
				}
			}
		}

		// Token: 0x06001967 RID: 6503 RVA: 0x00084108 File Offset: 0x00082308
		private double GetRegionArea()
		{
			double result;
			try
			{
				bool flag = this._region == null || !this._region.IsInitialized();
				if (flag)
				{
					result = 0.0;
				}
				else
				{
					HTuple area;
					HTuple htuple;
					HTuple htuple2;
					HOperatorSet.AreaCenter(this._region, out area, out htuple, out htuple2);
					result = ((area.Length > 0) ? area.D : 0.0);
				}
			}
			catch
			{
				result = 0.0;
			}
			return result;
		}

		// Token: 0x06001968 RID: 6504 RVA: 0x00084190 File Offset: 0x00082390
		private HWindow GetWindow()
		{
			bool flag = !this._windowReady || this.PaintWindow == null || this.PaintWindow.ActualWidth <= 0.0 || this.PaintWindow.ActualHeight <= 0.0;
			HWindow result;
			if (flag)
			{
				result = null;
			}
			else
			{
				try
				{
					result = this.PaintWindow.HalconWindow;
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x06001969 RID: 6505 RVA: 0x00084210 File Offset: 0x00082410
		private static bool TryGetPart(HWindow window, out double row1, out double col1, out double row2, out double col2)
		{
			row1 = (col1 = (row2 = (col2 = 0.0)));
			bool result;
			try
			{
				HTuple r;
				HTuple c;
				HTuple r2;
				HTuple c2;
				window.GetPart(out r, out c, out r2, out c2);
				row1 = r.D;
				col1 = c.D;
				row2 = r2.D;
				col2 = c2.D;
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600196A RID: 6506 RVA: 0x0008428C File Offset: 0x0008248C
		private static void TrySetPart(HWindow window, double row1, double col1, double row2, double col2)
		{
			try
			{
				window.SetPart((int)Math.Round(row1), (int)Math.Round(col1), (int)Math.Round(row2), (int)Math.Round(col2));
			}
			catch
			{
			}
		}

		// Token: 0x0600196B RID: 6507 RVA: 0x000842D8 File Offset: 0x000824D8
		private void Cleanup()
		{
			HObject blendedImage = this._blendedImage;
			if (blendedImage != null)
			{
				blendedImage.Dispose();
			}
			this._blendedImage = null;
			bool flag = !base.DialogResult.GetValueOrDefault();
			if (flag)
			{
				HObject region = this._region;
				if (region != null)
				{
					region.Dispose();
				}
				this._region = null;
			}
		}

		// Token: 0x04000A63 RID: 2659
		private readonly HObject _image;

		// Token: 0x04000A64 RID: 2660
		private HObject _region;

		// Token: 0x04000A65 RID: 2661
		private HObject _blendedImage;

		// Token: 0x04000A66 RID: 2662
		private bool _isPainting;

		// Token: 0x04000A67 RID: 2663
		private bool _paintWithRightButton;

		// Token: 0x04000A68 RID: 2664
		private bool _isPanning;

		// Token: 0x04000A69 RID: 2665
		private Point _lastPanPosition;

		// Token: 0x04000A6A RID: 2666
		private double _lastImageRow;

		// Token: 0x04000A6B RID: 2667
		private double _lastImageColumn;

		// Token: 0x04000A6C RID: 2668
		private bool _hasLastImagePoint;

		// Token: 0x04000A6D RID: 2669
		private bool _windowReady;
	}
}
