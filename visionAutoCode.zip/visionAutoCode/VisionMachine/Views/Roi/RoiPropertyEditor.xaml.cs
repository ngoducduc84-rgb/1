﻿using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using VisionMachine.Models.Roi;
using VisionMachine.Services.Localization;

namespace VisionMachine.Views.Roi
{
	// Token: 0x020001B9 RID: 441
	public partial class RoiPropertyEditor : ThemedWindow, INotifyPropertyChanged
	{
		// Token: 0x1700089A RID: 2202
		// (get) Token: 0x06001970 RID: 6512 RVA: 0x000845E3 File Offset: 0x000827E3
		// (set) Token: 0x06001971 RID: 6513 RVA: 0x000845EB File Offset: 0x000827EB
		public ObservableCollection<string> MasterToolOptions { get; set; } = new ObservableCollection<string>();

		// Token: 0x1700089B RID: 2203
		// (get) Token: 0x06001972 RID: 6514 RVA: 0x000845F4 File Offset: 0x000827F4
		// (set) Token: 0x06001973 RID: 6515 RVA: 0x000845FC File Offset: 0x000827FC
		public ObservableCollection<string> MasterPositionToolOptions { get; set; } = new ObservableCollection<string>();

		// Token: 0x1700089C RID: 2204
		// (get) Token: 0x06001974 RID: 6516 RVA: 0x00084605 File Offset: 0x00082805
		// (set) Token: 0x06001975 RID: 6517 RVA: 0x0008460D File Offset: 0x0008280D
		public ObservableCollection<string> MasterAngleToolOptions { get; set; } = new ObservableCollection<string>();

		// Token: 0x1700089D RID: 2205
		// (get) Token: 0x06001976 RID: 6518 RVA: 0x00084616 File Offset: 0x00082816
		public Array MaskModeOptions { get; } = Enum.GetValues(typeof(RoiMaskMode));

		// Token: 0x1700089E RID: 2206
		// (get) Token: 0x06001977 RID: 6519 RVA: 0x0008461E File Offset: 0x0008281E
		public Array PolarityOptions { get; } = Enum.GetValues(typeof(RoiPolarity));

		// Token: 0x1700089F RID: 2207
		// (get) Token: 0x06001978 RID: 6520 RVA: 0x00084626 File Offset: 0x00082826
		public Array CloneDirectionOptions { get; } = Enum.GetValues(typeof(RoiCloneDirection));

		// Token: 0x170008A0 RID: 2208
		// (get) Token: 0x06001979 RID: 6521 RVA: 0x00084630 File Offset: 0x00082830
		// (set) Token: 0x0600197A RID: 6522 RVA: 0x00084648 File Offset: 0x00082848
		public RoiCloneSettings CloneSettings
		{
			get
			{
				return this._cloneSettings;
			}
			set
			{
				this._cloneSettings = (value ?? new RoiCloneSettings());
				this.LoadCloneEditors();
				this.OnPropertyChanged("CloneSettings");
				this.OnPropertyChanged("CloneButtonText");
				this.OnPropertyChanged("CloneSummaryText");
			}
		}

		// Token: 0x170008A1 RID: 2209
		// (get) Token: 0x0600197B RID: 6523 RVA: 0x00084686 File Offset: 0x00082886
		// (set) Token: 0x0600197C RID: 6524 RVA: 0x0008468E File Offset: 0x0008288E
		public bool IsConfirmed { get; private set; }

		// Token: 0x170008A2 RID: 2210
		// (get) Token: 0x0600197D RID: 6525 RVA: 0x00084697 File Offset: 0x00082897
		// (set) Token: 0x0600197E RID: 6526 RVA: 0x0008469F File Offset: 0x0008289F
		public bool CloneRequested { get; private set; }

		// Token: 0x170008A3 RID: 2211
		// (get) Token: 0x0600197F RID: 6527 RVA: 0x000846A8 File Offset: 0x000828A8
		// (set) Token: 0x06001980 RID: 6528 RVA: 0x000846B0 File Offset: 0x000828B0
		public Action<RoiCloneSettings> PreviewRequested { get; set; }

		// Token: 0x170008A4 RID: 2212
		// (get) Token: 0x06001981 RID: 6529 RVA: 0x000846BC File Offset: 0x000828BC
		public string CloneButtonText
		{
			get
			{
				int count = this.CloneSettings.CloneCount;
				bool flag = count <= 0;
				string result;
				if (flag)
				{
					result = RoiPropertyEditor.Tr("Clone (nothing to add)");
				}
				else
				{
					result = string.Format(RoiPropertyEditor.Tr("Clone ({0})"), count);
				}
				return result;
			}
		}

		// Token: 0x170008A5 RID: 2213
		// (get) Token: 0x06001982 RID: 6530 RVA: 0x00084708 File Offset: 0x00082908
		public string CloneSummaryText
		{
			get
			{
				return string.Format(RoiPropertyEditor.Tr("Grid {0} x {1} = {2} ROIs, {3} added"), new object[]
				{
					this.CloneSettings.Rows,
					this.CloneSettings.Columns,
					this.CloneSettings.TotalCount,
					this.CloneSettings.CloneCount
				});
			}
		}

		// Token: 0x06001983 RID: 6531 RVA: 0x0008477C File Offset: 0x0008297C
		private static string Tr(string english)
		{
			return UiTranslator.Translate(english);
		}

		// Token: 0x06001984 RID: 6532 RVA: 0x00084794 File Offset: 0x00082994
		public RoiPropertyEditor()
		{
			this.InitializeComponent();
			this.LoadCloneEditors();
			this.RowsEdit.EditValueChanged += this.CloneEditor_EditValueChanged;
			this.ColumnsEdit.EditValueChanged += this.CloneEditor_EditValueChanged;
			this.OffsetRowEdit.EditValueChanged += this.CloneEditor_EditValueChanged;
			this.OffsetColumnEdit.EditValueChanged += this.CloneEditor_EditValueChanged;
			this.AngleEdit.EditValueChanged += this.CloneEditor_EditValueChanged;
			this.OnPropertyChanged("CloneButtonText");
			this.OnPropertyChanged("CloneSummaryText");
		}

		// Token: 0x06001985 RID: 6533 RVA: 0x000848B4 File Offset: 0x00082AB4
		private void LoadCloneEditors()
		{
			this._loadingCloneEditors = true;
			try
			{
				this.RowsEdit.Value = this.CloneSettings.Rows;
				this.ColumnsEdit.Value = this.CloneSettings.Columns;
				this.OffsetRowEdit.Value = (decimal)this.CloneSettings.OffsetRow;
				this.OffsetColumnEdit.Value = (decimal)this.CloneSettings.OffsetColumn;
				this.AngleEdit.Value = (decimal)this.CloneSettings.Angle;
			}
			finally
			{
				this._loadingCloneEditors = false;
			}
		}

		// Token: 0x06001986 RID: 6534 RVA: 0x00084974 File Offset: 0x00082B74
		private void CloneEditor_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			bool loadingCloneEditors = this._loadingCloneEditors;
			if (!loadingCloneEditors)
			{
				this.ReadCloneEditors();
			}
		}

		// Token: 0x06001987 RID: 6535 RVA: 0x00084998 File Offset: 0x00082B98
		private void ReadCloneEditors()
		{
			this.CloneSettings.Rows = (int)Math.Round(this.RowsEdit.Value);
			this.CloneSettings.Columns = (int)Math.Round(this.ColumnsEdit.Value);
			this.CloneSettings.OffsetRow = (double)this.OffsetRowEdit.Value;
			this.CloneSettings.OffsetColumn = (double)this.OffsetColumnEdit.Value;
			this.CloneSettings.Angle = (double)this.AngleEdit.Value;
			this.OnPropertyChanged("CloneButtonText");
			this.OnPropertyChanged("CloneSummaryText");
		}

		// Token: 0x06001988 RID: 6536 RVA: 0x00084A58 File Offset: 0x00082C58
		private void CommitCloneEditors()
		{
			foreach (BaseEdit editor in new BaseEdit[]
			{
				this.RowsEdit,
				this.ColumnsEdit,
				this.OffsetRowEdit,
				this.OffsetColumnEdit,
				this.AngleEdit
			})
			{
				try
				{
					if (editor != null)
					{
						editor.DoValidate();
					}
				}
				catch
				{
				}
			}
			this.ReadCloneEditors();
		}

		// Token: 0x06001989 RID: 6537 RVA: 0x00084ADC File Offset: 0x00082CDC
		private void TestShow_Click(object sender, RoutedEventArgs e)
		{
			this.CommitCloneEditors();
			bool flag = !this.ValidateCloneSettings();
			if (!flag)
			{
				Action<RoiCloneSettings> previewRequested = this.PreviewRequested;
				if (previewRequested != null)
				{
					previewRequested(this.CloneSettings);
				}
			}
		}

		// Token: 0x0600198A RID: 6538 RVA: 0x00084B18 File Offset: 0x00082D18
		private bool ValidateCloneSettings()
		{
			bool flag = this.CloneSettings.CloneCount <= 0;
			bool result;
			if (flag)
			{
				DXMessageBox.Show(RoiPropertyEditor.Tr("Rows and Columns describe the finished grid and the source already fills one position, so 1 x 1 adds nothing. Raise one of them."), "Clone ROI", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				result = false;
			}
			else
			{
				bool flag2 = Math.Abs(this.CloneSettings.OffsetRow) < 1E-09 && Math.Abs(this.CloneSettings.OffsetColumn) < 1E-09;
				if (flag2)
				{
					DXMessageBox.Show(RoiPropertyEditor.Tr("Both offsets are 0, so every copy would sit on top of the original. Set the distance between two ROIs first."), "Clone ROI", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					result = false;
				}
				else
				{
					result = true;
				}
			}
			return result;
		}

		// Token: 0x0600198B RID: 6539 RVA: 0x00084BB8 File Offset: 0x00082DB8
		private void Clone_Click(object sender, RoutedEventArgs e)
		{
			this.CommitCloneEditors();
			bool flag = !this.ValidateCloneSettings();
			if (!flag)
			{
				this.CloneRequested = true;
				this.IsConfirmed = true;
				base.Close();
			}
		}

		// Token: 0x0600198C RID: 6540 RVA: 0x00084BF3 File Offset: 0x00082DF3
		private void Ok_Click(object sender, RoutedEventArgs e)
		{
			this.IsConfirmed = true;
			base.Close();
		}

		// Token: 0x0600198D RID: 6541 RVA: 0x00084C05 File Offset: 0x00082E05
		private void Cancel_Click(object sender, RoutedEventArgs e)
		{
			this.IsConfirmed = false;
			base.Close();
		}

		// Token: 0x1400002B RID: 43
		// (add) Token: 0x0600198E RID: 6542 RVA: 0x00084C18 File Offset: 0x00082E18
		// (remove) Token: 0x0600198F RID: 6543 RVA: 0x00084C50 File Offset: 0x00082E50
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06001990 RID: 6544 RVA: 0x00084C85 File Offset: 0x00082E85
		private void OnPropertyChanged([CallerMemberName] string name = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		// Token: 0x04000A7F RID: 2687
		private RoiCloneSettings _cloneSettings = new RoiCloneSettings();

		// Token: 0x04000A83 RID: 2691
		private bool _loadingCloneEditors;
	}
}
