﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Services.Security;

namespace VisionMachine.Views.Security
{
	// Token: 0x020001D5 RID: 469
	public partial class AdminLoginWindow : ThemedWindow
	{
		// Token: 0x17000907 RID: 2311
		// (get) Token: 0x06001CAB RID: 7339 RVA: 0x000A12D5 File Offset: 0x0009F4D5
		// (set) Token: 0x06001CAC RID: 7340 RVA: 0x000A12DD File Offset: 0x0009F4DD
		public bool SignedIn { get; private set; }

		// Token: 0x06001CAD RID: 7341 RVA: 0x000A12E6 File Offset: 0x0009F4E6
		public AdminLoginWindow()
		{
			this.InitializeComponent();
			base.Loaded += delegate(object s, RoutedEventArgs e)
			{
				this.UserNameText.Focus();
			};
		}

		// Token: 0x06001CAE RID: 7342 RVA: 0x000A1318 File Offset: 0x0009F518
		private void Field_KeyDown(object sender, KeyEventArgs e)
		{
			bool flag = e.Key != Key.Return;
			if (!flag)
			{
				bool flag2 = sender == this.UserNameText;
				if (flag2)
				{
					this.PasswordText.Focus();
				}
				else
				{
					this.SignIn_Click(sender, e);
				}
				e.Handled = true;
			}
		}

		// Token: 0x06001CAF RID: 7343 RVA: 0x000A1364 File Offset: 0x0009F564
		private void SignIn_Click(object sender, RoutedEventArgs e)
		{
			bool flag = DateTime.Now < this._blockedUntil;
			if (!flag)
			{
				bool flag2 = AdminSessionService.SignIn(this.UserNameText.Text, this.PasswordText.Password);
				if (flag2)
				{
					this.SignedIn = true;
					base.DialogResult = new bool?(true);
					base.Close();
				}
				else
				{
					this._blockedUntil = DateTime.Now + AdminLoginWindow.RetryDelay;
					this.MessageText.Text = "The user name or password is not correct.";
					this.MessageText.Visibility = Visibility.Visible;
					this.PasswordText.Clear();
					this.PasswordText.Focus();
				}
			}
		}

		// Token: 0x06001CB0 RID: 7344 RVA: 0x00067BCC File Offset: 0x00065DCC
		private void Cancel_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = new bool?(false);
			base.Close();
		}

		// Token: 0x04000C2B RID: 3115
		private static readonly TimeSpan RetryDelay = TimeSpan.FromMilliseconds(600.0);

		// Token: 0x04000C2C RID: 3116
		private DateTime _blockedUntil = DateTime.MinValue;
	}
}
