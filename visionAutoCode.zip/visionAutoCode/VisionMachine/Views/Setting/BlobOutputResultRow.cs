﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x0200019D RID: 413
	public class BlobOutputResultRow
	{
		// Token: 0x17000795 RID: 1941
		// (get) Token: 0x06001597 RID: 5527 RVA: 0x00067CDE File Offset: 0x00065EDE
		// (set) Token: 0x06001598 RID: 5528 RVA: 0x00067CE6 File Offset: 0x00065EE6
		public string RoiName { get; set; }

		// Token: 0x17000796 RID: 1942
		// (get) Token: 0x06001599 RID: 5529 RVA: 0x00067CEF File Offset: 0x00065EEF
		// (set) Token: 0x0600159A RID: 5530 RVA: 0x00067CF7 File Offset: 0x00065EF7
		public double RoiValue { get; set; }

		// Token: 0x17000797 RID: 1943
		// (get) Token: 0x0600159B RID: 5531 RVA: 0x00067D00 File Offset: 0x00065F00
		// (set) Token: 0x0600159C RID: 5532 RVA: 0x00067D08 File Offset: 0x00065F08
		public double TotalValue { get; set; }

		// Token: 0x17000798 RID: 1944
		// (get) Token: 0x0600159D RID: 5533 RVA: 0x00067D11 File Offset: 0x00065F11
		// (set) Token: 0x0600159E RID: 5534 RVA: 0x00067D19 File Offset: 0x00065F19
		public double RoiProcessingTimeMs { get; set; }

		// Token: 0x17000799 RID: 1945
		// (get) Token: 0x0600159F RID: 5535 RVA: 0x00067D22 File Offset: 0x00065F22
		// (set) Token: 0x060015A0 RID: 5536 RVA: 0x00067D2A File Offset: 0x00065F2A
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x1700079A RID: 1946
		// (get) Token: 0x060015A1 RID: 5537 RVA: 0x00067D33 File Offset: 0x00065F33
		// (set) Token: 0x060015A2 RID: 5538 RVA: 0x00067D3B File Offset: 0x00065F3B
		public string Status { get; set; }

		// Token: 0x1700079B RID: 1947
		// (get) Token: 0x060015A3 RID: 5539 RVA: 0x00067D44 File Offset: 0x00065F44
		// (set) Token: 0x060015A4 RID: 5540 RVA: 0x00067D4C File Offset: 0x00065F4C
		public string MasterPositionToolName { get; set; }

		// Token: 0x1700079C RID: 1948
		// (get) Token: 0x060015A5 RID: 5541 RVA: 0x00067D55 File Offset: 0x00065F55
		// (set) Token: 0x060015A6 RID: 5542 RVA: 0x00067D5D File Offset: 0x00065F5D
		public string MasterAngleToolName { get; set; }

		// Token: 0x1700079D RID: 1949
		// (get) Token: 0x060015A7 RID: 5543 RVA: 0x00067D66 File Offset: 0x00065F66
		// (set) Token: 0x060015A8 RID: 5544 RVA: 0x00067D6E File Offset: 0x00065F6E
		public string MasterStatus { get; set; }

		// Token: 0x1700079E RID: 1950
		// (get) Token: 0x060015A9 RID: 5545 RVA: 0x00067D77 File Offset: 0x00065F77
		// (set) Token: 0x060015AA RID: 5546 RVA: 0x00067D7F File Offset: 0x00065F7F
		public Brush MasterStatusBrush { get; set; }

		// Token: 0x1700079F RID: 1951
		// (get) Token: 0x060015AB RID: 5547 RVA: 0x00067D88 File Offset: 0x00065F88
		// (set) Token: 0x060015AC RID: 5548 RVA: 0x00067D90 File Offset: 0x00065F90
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x170007A0 RID: 1952
		// (get) Token: 0x060015AD RID: 5549 RVA: 0x00067D99 File Offset: 0x00065F99
		// (set) Token: 0x060015AE RID: 5550 RVA: 0x00067DA1 File Offset: 0x00065FA1
		public string InputSourceToolName { get; set; }

		// Token: 0x170007A1 RID: 1953
		// (get) Token: 0x060015AF RID: 5551 RVA: 0x00067DAA File Offset: 0x00065FAA
		// (set) Token: 0x060015B0 RID: 5552 RVA: 0x00067DB2 File Offset: 0x00065FB2
		public double InputProcessingTimeMs { get; set; }
	}
}
