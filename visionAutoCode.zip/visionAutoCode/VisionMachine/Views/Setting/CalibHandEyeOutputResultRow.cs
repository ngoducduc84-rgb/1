﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A7 RID: 423
	public class CalibHandEyeOutputResultRow
	{
		// Token: 0x17000833 RID: 2099
		// (get) Token: 0x060016DB RID: 5851 RVA: 0x00068D02 File Offset: 0x00066F02
		// (set) Token: 0x060016DC RID: 5852 RVA: 0x00068D0A File Offset: 0x00066F0A
		public string ToolName { get; set; }

		// Token: 0x17000834 RID: 2100
		// (get) Token: 0x060016DD RID: 5853 RVA: 0x00068D13 File Offset: 0x00066F13
		// (set) Token: 0x060016DE RID: 5854 RVA: 0x00068D1B File Offset: 0x00066F1B
		public string MasterToolName { get; set; }

		// Token: 0x17000835 RID: 2101
		// (get) Token: 0x060016DF RID: 5855 RVA: 0x00068D24 File Offset: 0x00066F24
		// (set) Token: 0x060016E0 RID: 5856 RVA: 0x00068D2C File Offset: 0x00066F2C
		public double PixelRow { get; set; }

		// Token: 0x17000836 RID: 2102
		// (get) Token: 0x060016E1 RID: 5857 RVA: 0x00068D35 File Offset: 0x00066F35
		// (set) Token: 0x060016E2 RID: 5858 RVA: 0x00068D3D File Offset: 0x00066F3D
		public double PixelColumn { get; set; }

		// Token: 0x17000837 RID: 2103
		// (get) Token: 0x060016E3 RID: 5859 RVA: 0x00068D46 File Offset: 0x00066F46
		// (set) Token: 0x060016E4 RID: 5860 RVA: 0x00068D4E File Offset: 0x00066F4E
		public double RobotX { get; set; }

		// Token: 0x17000838 RID: 2104
		// (get) Token: 0x060016E5 RID: 5861 RVA: 0x00068D57 File Offset: 0x00066F57
		// (set) Token: 0x060016E6 RID: 5862 RVA: 0x00068D5F File Offset: 0x00066F5F
		public double RobotY { get; set; }

		// Token: 0x17000839 RID: 2105
		// (get) Token: 0x060016E7 RID: 5863 RVA: 0x00068D68 File Offset: 0x00066F68
		// (set) Token: 0x060016E8 RID: 5864 RVA: 0x00068D70 File Offset: 0x00066F70
		public double AngleDeg { get; set; }

		// Token: 0x1700083A RID: 2106
		// (get) Token: 0x060016E9 RID: 5865 RVA: 0x00068D79 File Offset: 0x00066F79
		// (set) Token: 0x060016EA RID: 5866 RVA: 0x00068D81 File Offset: 0x00066F81
		public double VisionAngleDeg { get; set; }

		// Token: 0x1700083B RID: 2107
		// (get) Token: 0x060016EB RID: 5867 RVA: 0x00068D8A File Offset: 0x00066F8A
		// (set) Token: 0x060016EC RID: 5868 RVA: 0x00068D92 File Offset: 0x00066F92
		public double MappedVisionAngleDeg { get; set; }

		// Token: 0x1700083C RID: 2108
		// (get) Token: 0x060016ED RID: 5869 RVA: 0x00068D9B File Offset: 0x00066F9B
		// (set) Token: 0x060016EE RID: 5870 RVA: 0x00068DA3 File Offset: 0x00066FA3
		public double AngleOffsetDeg { get; set; }

		// Token: 0x1700083D RID: 2109
		// (get) Token: 0x060016EF RID: 5871 RVA: 0x00068DAC File Offset: 0x00066FAC
		// (set) Token: 0x060016F0 RID: 5872 RVA: 0x00068DB4 File Offset: 0x00066FB4
		public bool UsedTcpOffset { get; set; }

		// Token: 0x1700083E RID: 2110
		// (get) Token: 0x060016F1 RID: 5873 RVA: 0x00068DBD File Offset: 0x00066FBD
		// (set) Token: 0x060016F2 RID: 5874 RVA: 0x00068DC5 File Offset: 0x00066FC5
		public double TcpPixelRow { get; set; }

		// Token: 0x1700083F RID: 2111
		// (get) Token: 0x060016F3 RID: 5875 RVA: 0x00068DCE File Offset: 0x00066FCE
		// (set) Token: 0x060016F4 RID: 5876 RVA: 0x00068DD6 File Offset: 0x00066FD6
		public double TcpPixelColumn { get; set; }

		// Token: 0x17000840 RID: 2112
		// (get) Token: 0x060016F5 RID: 5877 RVA: 0x00068DDF File Offset: 0x00066FDF
		// (set) Token: 0x060016F6 RID: 5878 RVA: 0x00068DE7 File Offset: 0x00066FE7
		public double MasterTcpPixelRow { get; set; }

		// Token: 0x17000841 RID: 2113
		// (get) Token: 0x060016F7 RID: 5879 RVA: 0x00068DF0 File Offset: 0x00066FF0
		// (set) Token: 0x060016F8 RID: 5880 RVA: 0x00068DF8 File Offset: 0x00066FF8
		public double MasterTcpPixelColumn { get; set; }

		// Token: 0x17000842 RID: 2114
		// (get) Token: 0x060016F9 RID: 5881 RVA: 0x00068E01 File Offset: 0x00067001
		// (set) Token: 0x060016FA RID: 5882 RVA: 0x00068E09 File Offset: 0x00067009
		public double MasterRobotX { get; set; }

		// Token: 0x17000843 RID: 2115
		// (get) Token: 0x060016FB RID: 5883 RVA: 0x00068E12 File Offset: 0x00067012
		// (set) Token: 0x060016FC RID: 5884 RVA: 0x00068E1A File Offset: 0x0006701A
		public double MasterRobotY { get; set; }

		// Token: 0x17000844 RID: 2116
		// (get) Token: 0x060016FD RID: 5885 RVA: 0x00068E23 File Offset: 0x00067023
		// (set) Token: 0x060016FE RID: 5886 RVA: 0x00068E2B File Offset: 0x0006702B
		public bool HasDelta { get; set; }

		// Token: 0x17000845 RID: 2117
		// (get) Token: 0x060016FF RID: 5887 RVA: 0x00068E34 File Offset: 0x00067034
		// (set) Token: 0x06001700 RID: 5888 RVA: 0x00068E3C File Offset: 0x0006703C
		public double DeltaRobotX { get; set; }

		// Token: 0x17000846 RID: 2118
		// (get) Token: 0x06001701 RID: 5889 RVA: 0x00068E45 File Offset: 0x00067045
		// (set) Token: 0x06001702 RID: 5890 RVA: 0x00068E4D File Offset: 0x0006704D
		public double DeltaRobotY { get; set; }

		// Token: 0x17000847 RID: 2119
		// (get) Token: 0x06001703 RID: 5891 RVA: 0x00068E56 File Offset: 0x00067056
		// (set) Token: 0x06001704 RID: 5892 RVA: 0x00068E5E File Offset: 0x0006705E
		public double DeltaAngleDeg { get; set; }

		// Token: 0x17000848 RID: 2120
		// (get) Token: 0x06001705 RID: 5893 RVA: 0x00068E67 File Offset: 0x00067067
		// (set) Token: 0x06001706 RID: 5894 RVA: 0x00068E6F File Offset: 0x0006706F
		public double Score { get; set; }

		// Token: 0x17000849 RID: 2121
		// (get) Token: 0x06001707 RID: 5895 RVA: 0x00068E78 File Offset: 0x00067078
		// (set) Token: 0x06001708 RID: 5896 RVA: 0x00068E80 File Offset: 0x00067080
		public string Status { get; set; }

		// Token: 0x1700084A RID: 2122
		// (get) Token: 0x06001709 RID: 5897 RVA: 0x00068E8C File Offset: 0x0006708C
		public Brush StatusBrush
		{
			get
			{
				return string.Equals(this.Status, "OK", StringComparison.OrdinalIgnoreCase) ? Brushes.LimeGreen : Brushes.Red;
			}
		}

		// Token: 0x1700084B RID: 2123
		// (get) Token: 0x0600170A RID: 5898 RVA: 0x00068EBD File Offset: 0x000670BD
		// (set) Token: 0x0600170B RID: 5899 RVA: 0x00068EC5 File Offset: 0x000670C5
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x1700084C RID: 2124
		// (get) Token: 0x0600170C RID: 5900 RVA: 0x00068ECE File Offset: 0x000670CE
		// (set) Token: 0x0600170D RID: 5901 RVA: 0x00068ED6 File Offset: 0x000670D6
		public double ProcessingTimeMs { get; set; }

		// Token: 0x1700084D RID: 2125
		// (get) Token: 0x0600170E RID: 5902 RVA: 0x00068EDF File Offset: 0x000670DF
		// (set) Token: 0x0600170F RID: 5903 RVA: 0x00068EE7 File Offset: 0x000670E7
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x1700084E RID: 2126
		// (get) Token: 0x06001710 RID: 5904 RVA: 0x00068EF0 File Offset: 0x000670F0
		// (set) Token: 0x06001711 RID: 5905 RVA: 0x00068EF8 File Offset: 0x000670F8
		public string CalibrationFilePath { get; set; }
	}
}
