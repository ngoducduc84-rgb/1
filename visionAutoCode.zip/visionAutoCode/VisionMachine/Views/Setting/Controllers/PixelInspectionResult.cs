﻿using System;

namespace VisionMachine.Views.Setting.Controllers
{
	// Token: 0x020001B6 RID: 438
	public class PixelInspectionResult
	{
		// Token: 0x1700088C RID: 2188
		// (get) Token: 0x060018FD RID: 6397 RVA: 0x00081554 File Offset: 0x0007F754
		// (set) Token: 0x060018FE RID: 6398 RVA: 0x0008155C File Offset: 0x0007F75C
		public int Row { get; set; }

		// Token: 0x1700088D RID: 2189
		// (get) Token: 0x060018FF RID: 6399 RVA: 0x00081565 File Offset: 0x0007F765
		// (set) Token: 0x06001900 RID: 6400 RVA: 0x0008156D File Offset: 0x0007F76D
		public int Column { get; set; }

		// Token: 0x1700088E RID: 2190
		// (get) Token: 0x06001901 RID: 6401 RVA: 0x00081576 File Offset: 0x0007F776
		// (set) Token: 0x06001902 RID: 6402 RVA: 0x0008157E File Offset: 0x0007F77E
		public double Gray { get; set; }

		// Token: 0x1700088F RID: 2191
		// (get) Token: 0x06001903 RID: 6403 RVA: 0x00081587 File Offset: 0x0007F787
		// (set) Token: 0x06001904 RID: 6404 RVA: 0x0008158F File Offset: 0x0007F78F
		public double? Red { get; set; }

		// Token: 0x17000890 RID: 2192
		// (get) Token: 0x06001905 RID: 6405 RVA: 0x00081598 File Offset: 0x0007F798
		// (set) Token: 0x06001906 RID: 6406 RVA: 0x000815A0 File Offset: 0x0007F7A0
		public double? Green { get; set; }

		// Token: 0x17000891 RID: 2193
		// (get) Token: 0x06001907 RID: 6407 RVA: 0x000815A9 File Offset: 0x0007F7A9
		// (set) Token: 0x06001908 RID: 6408 RVA: 0x000815B1 File Offset: 0x0007F7B1
		public double? Blue { get; set; }
	}
}
