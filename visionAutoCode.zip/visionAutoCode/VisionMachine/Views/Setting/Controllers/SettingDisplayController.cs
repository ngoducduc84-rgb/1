﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using HalconDotNet;
using Microsoft.Win32;

namespace VisionMachine.Views.Setting.Controllers
{
	// Token: 0x020001B7 RID: 439
	public class SettingDisplayController : IDisposable
	{
		// Token: 0x17000892 RID: 2194
		// (get) Token: 0x0600190A RID: 6410 RVA: 0x000815BA File Offset: 0x0007F7BA
		// (set) Token: 0x0600190B RID: 6411 RVA: 0x000815C2 File Offset: 0x0007F7C2
		public bool LastMouseActionWasClick { get; private set; }

		// Token: 0x17000893 RID: 2195
		// (get) Token: 0x0600190C RID: 6412 RVA: 0x000815CB File Offset: 0x0007F7CB
		// (set) Token: 0x0600190D RID: 6413 RVA: 0x000815D3 File Offset: 0x0007F7D3
		public bool PreserveOverlayRendererStateOnClear { get; set; }

		// Token: 0x17000894 RID: 2196
		// (get) Token: 0x0600190E RID: 6414 RVA: 0x000815DC File Offset: 0x0007F7DC
		// (set) Token: 0x0600190F RID: 6415 RVA: 0x000815E4 File Offset: 0x0007F7E4
		public bool UseBufferedRedraw { get; set; }

		// Token: 0x06001910 RID: 6416 RVA: 0x000815F0 File Offset: 0x0007F7F0
		private static bool IsPanButton(MouseButton button)
		{
			return button == MouseButton.Left || button == MouseButton.Middle;
		}

		// Token: 0x06001911 RID: 6417 RVA: 0x0008160C File Offset: 0x0007F80C
		private static bool IsButtonReleased(MouseEventArgs e, MouseButton button)
		{
			bool result;
			switch (button)
			{
			case MouseButton.Left:
				result = (e.LeftButton != MouseButtonState.Pressed);
				break;
			case MouseButton.Middle:
				result = (e.MiddleButton != MouseButtonState.Pressed);
				break;
			case MouseButton.Right:
				result = (e.RightButton != MouseButtonState.Pressed);
				break;
			default:
				result = true;
				break;
			}
			return result;
		}

		// Token: 0x17000895 RID: 2197
		// (get) Token: 0x06001912 RID: 6418 RVA: 0x00081664 File Offset: 0x0007F864
		public HObject CurrentImage
		{
			get
			{
				return this._image;
			}
		}

		// Token: 0x17000896 RID: 2198
		// (get) Token: 0x06001913 RID: 6419 RVA: 0x0008166C File Offset: 0x0007F86C
		public bool HasImage
		{
			get
			{
				return this._image != null && this._image.IsInitialized();
			}
		}

		// Token: 0x06001914 RID: 6420 RVA: 0x00081684 File Offset: 0x0007F884
		public SettingDisplayController(HSmartWindowControlWPF display)
		{
			this._display = display;
			bool flag = this._display == null;
			if (!flag)
			{
				this._display.Loaded += this.Display_Loaded;
				this._display.IsVisibleChanged += this.Display_IsVisibleChanged;
				this._display.SizeChanged += new SizeChangedEventHandler(this.Display_BecameDrawable);
			}
		}

		// Token: 0x06001915 RID: 6421 RVA: 0x0008170D File Offset: 0x0007F90D
		private void Display_Loaded(object sender, RoutedEventArgs e)
		{
			this.FitAndDisplayImage();
		}

		// Token: 0x06001916 RID: 6422 RVA: 0x00081717 File Offset: 0x0007F917
		private void Display_BecameDrawable(object sender, EventArgs e)
		{
			this.FlushPendingDisplay();
		}

		// Token: 0x06001917 RID: 6423 RVA: 0x00081717 File Offset: 0x0007F917
		private void Display_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			this.FlushPendingDisplay();
		}

		// Token: 0x06001918 RID: 6424 RVA: 0x00081724 File Offset: 0x0007F924
		private void FlushPendingDisplay()
		{
			bool flag = !this._displayPending;
			if (flag)
			{
				this.StopPendingRetry();
			}
			else
			{
				bool flag2 = this.GetWindowOrNull() == null;
				if (flag2)
				{
					this.StartPendingRetry();
				}
				else
				{
					bool hasImage = this.HasImage;
					if (hasImage)
					{
						this.FitAndDisplayImage();
					}
					else
					{
						bool flag3 = this.Redraw();
						if (flag3)
						{
							this._displayPending = false;
						}
					}
					bool displayPending = this._displayPending;
					if (displayPending)
					{
						this.StartPendingRetry();
					}
					else
					{
						this.StopPendingRetry();
					}
				}
			}
		}

		// Token: 0x06001919 RID: 6425 RVA: 0x000817A0 File Offset: 0x0007F9A0
		private void StartPendingRetry()
		{
			bool pendingRetryArmed = this._pendingRetryArmed;
			if (!pendingRetryArmed)
			{
				this._pendingRetryArmed = true;
				CompositionTarget.Rendering += this.PendingRetryTick;
			}
		}

		// Token: 0x0600191A RID: 6426 RVA: 0x000817D4 File Offset: 0x0007F9D4
		private void StopPendingRetry()
		{
			bool flag = !this._pendingRetryArmed;
			if (!flag)
			{
				this._pendingRetryArmed = false;
				CompositionTarget.Rendering -= this.PendingRetryTick;
			}
		}

		// Token: 0x0600191B RID: 6427 RVA: 0x00081717 File Offset: 0x0007F917
		private void PendingRetryTick(object sender, EventArgs e)
		{
			this.FlushPendingDisplay();
		}

		// Token: 0x0600191C RID: 6428 RVA: 0x0008180C File Offset: 0x0007FA0C
		public void MouseDown(MouseButtonEventArgs e)
		{
			bool flag = !SettingDisplayController.IsPanButton(e.ChangedButton);
			if (!flag)
			{
				this._isPanning = true;
				this._didPan = false;
				this._panButton = e.ChangedButton;
				this._lastMousePos = e.GetPosition(this._display);
				this._panStartPos = this._lastMousePos;
				this.LastMouseActionWasClick = false;
				this._display.CaptureMouse();
				this._display.Cursor = Cursors.SizeAll;
				e.Handled = true;
			}
		}

		// Token: 0x0600191D RID: 6429 RVA: 0x00081894 File Offset: 0x0007FA94
		public void MouseUp(MouseButtonEventArgs e)
		{
			bool flag = !this._isPanning;
			if (!flag)
			{
				bool flag2 = e.ChangedButton != this._panButton;
				if (!flag2)
				{
					this.LastMouseActionWasClick = (this._panButton == MouseButton.Left && !this._didPan);
					this._isPanning = false;
					bool isMouseCaptured = this._display.IsMouseCaptured;
					if (isMouseCaptured)
					{
						this._display.ReleaseMouseCapture();
					}
					this._display.Cursor = Cursors.Arrow;
					this.ScheduleRedrawAfterHalconMouseEvent();
					e.Handled = true;
				}
			}
		}

		// Token: 0x0600191E RID: 6430 RVA: 0x00081928 File Offset: 0x0007FB28
		public void MouseDoubleClick(MouseButtonEventArgs e)
		{
			bool flag = e == null || e.ChangedButton > MouseButton.Left;
			if (!flag)
			{
				e.Handled = true;
				bool flag2 = !this.HasImage;
				if (!flag2)
				{
					this.FitAndDisplayImage();
					this.ScheduleRedrawAfterHalconMouseEvent();
				}
			}
		}

		// Token: 0x0600191F RID: 6431 RVA: 0x00081970 File Offset: 0x0007FB70
		public void MouseMove(MouseEventArgs e)
		{
			bool flag = !this._isPanning;
			if (!flag)
			{
				bool flag2 = SettingDisplayController.IsButtonReleased(e, this._panButton);
				if (flag2)
				{
					this._isPanning = false;
					bool isMouseCaptured = this._display.IsMouseCaptured;
					if (isMouseCaptured)
					{
						this._display.ReleaseMouseCapture();
					}
					this._display.Cursor = Cursors.Arrow;
				}
				else
				{
					Point currentPos = e.GetPosition(this._display);
					double dx = currentPos.X - this._lastMousePos.X;
					double dy = currentPos.Y - this._lastMousePos.Y;
					this._lastMousePos = currentPos;
					bool flag3 = Math.Abs(currentPos.X - this._panStartPos.X) + Math.Abs(currentPos.Y - this._panStartPos.Y) > 3.0;
					if (flag3)
					{
						this._didPan = true;
					}
					bool flag4 = Math.Abs(dx) < 0.1 && Math.Abs(dy) < 0.1;
					if (flag4)
					{
						e.Handled = true;
					}
					else
					{
						HWindow window = this.GetWindowOrNull();
						bool flag5 = window == null;
						if (!flag5)
						{
							HTuple row;
							HTuple col;
							HTuple row2;
							HTuple col2;
							bool flag6 = !this.TryGetPart(window, out row, out col, out row2, out col2);
							if (!flag6)
							{
								double partWidth = col2.D - col.D + 1.0;
								double partHeight = row2.D - row.D + 1.0;
								double controlWidth = this._display.ActualWidth;
								double controlHeight = this._display.ActualHeight;
								bool flag7 = controlWidth <= 0.0 || controlHeight <= 0.0;
								if (!flag7)
								{
									double imageDx = dx * partWidth / controlWidth;
									double imageDy = dy * partHeight / controlHeight;
									bool flag8 = !this.TrySetPart(window, (int)(row.D - imageDy), (int)(col.D - imageDx), (int)(row2.D - imageDy), (int)(col2.D - imageDx));
									if (!flag8)
									{
										this.ScheduleRedrawAfterHalconMouseEvent();
										e.Handled = true;
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001920 RID: 6432 RVA: 0x00081BAC File Offset: 0x0007FDAC
		public void MouseWheel(MouseWheelEventArgs e)
		{
			bool flag = e == null;
			if (!flag)
			{
				e.Handled = true;
				bool flag2 = !this.HasImage;
				if (!flag2)
				{
					HWindow window = this.GetWindowOrNull();
					bool flag3 = window == null;
					if (!flag3)
					{
						double controlWidth = this._display.ActualWidth;
						double controlHeight = this._display.ActualHeight;
						bool flag4 = controlWidth <= 0.0 || controlHeight <= 0.0;
						if (!flag4)
						{
							HTuple row;
							HTuple col;
							HTuple row2;
							HTuple col2;
							bool flag5 = !this.TryGetPart(window, out row, out col, out row2, out col2);
							if (!flag5)
							{
								double partHeight = row2.D - row.D + 1.0;
								double partWidth = col2.D - col.D + 1.0;
								bool flag6 = partHeight <= 1.0 || partWidth <= 1.0;
								if (!flag6)
								{
									HTuple imageWidth;
									HTuple imageHeight;
									HOperatorSet.GetImageSize(this._image, out imageWidth, out imageHeight);
									double factor = (e.Delta > 0) ? 0.8 : 1.25;
									double newHeight = Math.Max(8.0, Math.Min(imageHeight.D * 20.0, partHeight * factor));
									double newWidth = Math.Max(8.0, Math.Min(imageWidth.D * 20.0, partWidth * factor));
									Point mouse = e.GetPosition(this._display);
									double mouseRow = row.D + mouse.Y * partHeight / controlHeight;
									double mouseColumn = col.D + mouse.X * partWidth / controlWidth;
									double relativeY = mouse.Y / controlHeight;
									double relativeX = mouse.X / controlWidth;
									double newRow = mouseRow - relativeY * newHeight;
									double newCol = mouseColumn - relativeX * newWidth;
									double newRow2 = newRow + newHeight - 1.0;
									double newCol2 = newCol + newWidth - 1.0;
									bool flag7 = !this.TrySetPart(window, (int)Math.Round(newRow), (int)Math.Round(newCol), (int)Math.Round(newRow2), (int)Math.Round(newCol2));
									if (!flag7)
									{
										this.ScheduleRedrawAfterHalconMouseEvent();
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001921 RID: 6433 RVA: 0x00081E00 File Offset: 0x00080000
		public void RedrawAfterLayoutChanged()
		{
			this.ScheduleRedrawAfterHalconMouseEvent();
			HSmartWindowControlWPF display = this._display;
			bool flag = ((display != null) ? display.Dispatcher : null) == null;
			if (!flag)
			{
				this._display.Dispatcher.BeginInvoke(new Action(delegate()
				{
					this.Redraw();
				}), DispatcherPriority.ContextIdle, Array.Empty<object>());
				this._display.Dispatcher.BeginInvoke(new Action(delegate()
				{
					this.Redraw();
				}), DispatcherPriority.ApplicationIdle, Array.Empty<object>());
			}
		}

		// Token: 0x06001922 RID: 6434 RVA: 0x00081E78 File Offset: 0x00080078
		public bool TryInspectPixel(Point controlPosition, out PixelInspectionResult result)
		{
			result = null;
			HWindow window = this.GetWindowOrNull();
			bool flag = window == null || !this.HasImage;
			bool result2;
			if (flag)
			{
				result2 = false;
			}
			else
			{
				double controlWidth = this._display.ActualWidth;
				double controlHeight = this._display.ActualHeight;
				bool flag2 = controlWidth <= 0.0 || controlHeight <= 0.0;
				if (flag2)
				{
					result2 = false;
				}
				else
				{
					HTuple row;
					HTuple col;
					HTuple row2;
					HTuple col2;
					bool flag3 = !this.TryGetPart(window, out row, out col, out row2, out col2);
					if (flag3)
					{
						result2 = false;
					}
					else
					{
						double imageRow = row.D + controlPosition.Y * (row2.D - row.D + 1.0) / controlHeight;
						double imageColumn = col.D + controlPosition.X * (col2.D - col.D + 1.0) / controlWidth;
						int row3 = (int)Math.Round(imageRow);
						int column = (int)Math.Round(imageColumn);
						HTuple width;
						HTuple height;
						HOperatorSet.GetImageSize(this._image, out width, out height);
						bool flag4 = row3 < 0 || column < 0 || row3 >= height.I || column >= width.I;
						if (flag4)
						{
							result2 = false;
						}
						else
						{
							HTuple channelCount;
							HOperatorSet.CountChannels(this._image, out channelCount);
							HTuple pixelValue;
							HOperatorSet.GetGrayval(this._image, row3, column, out pixelValue);
							result = new PixelInspectionResult
							{
								Row = row3,
								Column = column
							};
							bool flag5 = channelCount.Length > 0 && channelCount[0].I >= 3 && pixelValue.Length >= 3;
							if (flag5)
							{
								result.Red = new double?(pixelValue[0].D);
								result.Green = new double?(pixelValue[1].D);
								result.Blue = new double?(pixelValue[2].D);
								result.Gray = 0.299 * result.Red.Value + 0.587 * result.Green.Value + 0.114 * result.Blue.Value;
							}
							else
							{
								bool flag6 = pixelValue.Length > 0;
								if (flag6)
								{
									result.Gray = pixelValue[0].D;
								}
							}
							result2 = true;
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06001923 RID: 6435 RVA: 0x00082110 File Offset: 0x00080310
		public void OpenImageByDialog()
		{
			OpenFileDialog openFileDialog = new OpenFileDialog
			{
				Filter = "Image Files (*.jpg; *.jpeg; *.png; *.gif; *.bmp)|*.jpg; *.jpeg; *.png; *.gif; *.bmp|All files (*.*)|*.*",
				Title = "Select an Image File"
			};
			bool valueOrDefault = openFileDialog.ShowDialog().GetValueOrDefault();
			if (valueOrDefault)
			{
				this.LoadImage(openFileDialog.FileName);
			}
		}

		// Token: 0x06001924 RID: 6436 RVA: 0x0008215C File Offset: 0x0008035C
		public void LoadImage(string imagePath)
		{
			this.DisposeImage();
			HOperatorSet.ReadImage(out this._image, imagePath);
			this._image = SettingDisplayController.NormalizeChannelsForDisplay(this._image);
			HObject originalImage = this._originalImage;
			if (originalImage != null)
			{
				originalImage.Dispose();
			}
			HOperatorSet.CopyImage(this._image, out this._originalImage);
			this.FitAndDisplayImage();
		}

		// Token: 0x06001925 RID: 6437 RVA: 0x000821C0 File Offset: 0x000803C0
		public void LoadImage(HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			if (flag)
			{
				throw new InvalidOperationException("No image is available to load.");
			}
			this.DisposeImage();
			HObject copy;
			HOperatorSet.CopyImage(image, out copy);
			this._image = SettingDisplayController.NormalizeChannelsForDisplay(copy);
			HOperatorSet.CopyImage(this._image, out this._originalImage);
			this.FitAndDisplayImage();
		}

		// Token: 0x06001926 RID: 6438 RVA: 0x00082224 File Offset: 0x00080424
		private static HObject NormalizeChannelsForDisplay(HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			HObject result;
			if (flag)
			{
				result = image;
			}
			else
			{
				int channels;
				try
				{
					HTuple channelCount;
					HOperatorSet.CountChannels(image, out channelCount);
					channels = ((channelCount.Length > 0) ? channelCount[0].I : 1);
				}
				catch
				{
					return image;
				}
				bool flag2 = channels <= 3;
				if (flag2)
				{
					result = image;
				}
				else
				{
					HObject c = null;
					HObject c2 = null;
					HObject c3 = null;
					HObject rgb = null;
					try
					{
						HOperatorSet.AccessChannel(image, out c, 1);
						HOperatorSet.AccessChannel(image, out c2, 2);
						HOperatorSet.AccessChannel(image, out c3, 3);
						HOperatorSet.Compose3(c, c2, c3, out rgb);
						image.Dispose();
						result = rgb;
					}
					catch
					{
						if (rgb != null)
						{
							rgb.Dispose();
						}
						result = image;
					}
					finally
					{
						if (c != null)
						{
							c.Dispose();
						}
						if (c2 != null)
						{
							c2.Dispose();
						}
						if (c3 != null)
						{
							c3.Dispose();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001927 RID: 6439 RVA: 0x0008234C File Offset: 0x0008054C
		public void SaveCurrentImage(string savePath)
		{
			bool flag = !this.HasImage;
			if (flag)
			{
				throw new InvalidOperationException("No image is available to save. Please open an image first.");
			}
			string ext = Path.GetExtension(savePath).ToLower();
			string format = "bmp";
			bool flag2 = ext == ".jpg" || ext == ".jpeg";
			if (flag2)
			{
				format = "jpeg";
			}
			else
			{
				bool flag3 = ext == ".png";
				if (flag3)
				{
					format = "png";
				}
				else
				{
					bool flag4 = ext == ".bmp";
					if (flag4)
					{
						format = "bmp";
					}
					else
					{
						bool flag5 = ext == ".tif" || ext == ".tiff";
						if (flag5)
						{
							format = "tiff";
						}
					}
				}
			}
			HOperatorSet.WriteImage(this._image, format, 0, savePath);
		}

		// Token: 0x06001928 RID: 6440 RVA: 0x0008242C File Offset: 0x0008062C
		public static void WriteImage(HObject image, string savePath)
		{
			bool flag = image == null || !image.IsInitialized();
			if (flag)
			{
				throw new InvalidOperationException("No image is available to save.");
			}
			string ext = Path.GetExtension(savePath ?? string.Empty).ToLower();
			string format = "bmp";
			bool flag2 = ext == ".jpg" || ext == ".jpeg";
			if (flag2)
			{
				format = "jpeg";
			}
			else
			{
				bool flag3 = ext == ".png";
				if (flag3)
				{
					format = "png";
				}
				else
				{
					bool flag4 = ext == ".tif" || ext == ".tiff";
					if (flag4)
					{
						format = "tiff";
					}
				}
			}
			HOperatorSet.WriteImage(image, format, 0, savePath);
		}

		// Token: 0x06001929 RID: 6441 RVA: 0x000824F4 File Offset: 0x000806F4
		public void ClearImage()
		{
			HWindow window = this.GetWindowOrNull();
			bool flag = window != null;
			if (flag)
			{
				window.ClearWindow();
			}
			else
			{
				this._displayPending = true;
				this.StartPendingRetry();
			}
			this.DisposeImage();
		}

		// Token: 0x0600192A RID: 6442 RVA: 0x00082534 File Offset: 0x00080734
		public bool Redraw()
		{
			object redrawSync = this._redrawSync;
			bool result;
			lock (redrawSync)
			{
				bool isRedrawing = this._isRedrawing;
				if (isRedrawing)
				{
					result = false;
				}
				else
				{
					this._isRedrawing = true;
					try
					{
						result = this.RedrawCore();
					}
					finally
					{
						this._isRedrawing = false;
					}
				}
			}
			return result;
		}

		// Token: 0x0600192B RID: 6443 RVA: 0x000825A8 File Offset: 0x000807A8
		private bool RedrawCore()
		{
			HWindow window = this.GetWindowOrNull();
			bool flag = window == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool bufferedGraphic = false;
				try
				{
					bufferedGraphic = (this.UseBufferedRedraw && SettingDisplayController.TrySetGraphicFlush(false));
					try
					{
						window.ClearWindow();
						bool hasImage = this.HasImage;
						if (hasImage)
						{
							HOperatorSet.DispObj(this._image, window);
						}
					}
					catch (HOperatorException)
					{
						return false;
					}
					foreach (HObject overlay in this._overlayObjects)
					{
						bool flag2 = overlay == null;
						if (!flag2)
						{
							bool flag3 = !overlay.IsInitialized();
							if (!flag3)
							{
								try
								{
									window.SetColor("green");
									HOperatorSet.DispObj(overlay, window);
								}
								catch (HOperatorException)
								{
									return false;
								}
							}
						}
					}
					try
					{
						Action<HWindow> overlayRenderer = this._overlayRenderer;
						if (overlayRenderer != null)
						{
							overlayRenderer(window);
						}
					}
					catch (HOperatorException)
					{
						return false;
					}
				}
				finally
				{
					bool flag4 = bufferedGraphic;
					if (flag4)
					{
						SettingDisplayController.TrySetGraphicFlush(true);
						SettingDisplayController.TryFlushBuffer(window);
					}
				}
				result = true;
			}
			return result;
		}

		// Token: 0x0600192C RID: 6444 RVA: 0x0008270C File Offset: 0x0008090C
		private static void TryFlushBuffer(HWindow window)
		{
			bool flag = window == null;
			if (!flag)
			{
				try
				{
					window.FlushBuffer();
				}
				catch
				{
				}
			}
		}

		// Token: 0x0600192D RID: 6445 RVA: 0x00082748 File Offset: 0x00080948
		private static bool TrySetGraphicFlush(bool enabled)
		{
			bool result;
			try
			{
				HOperatorSet.SetSystem("flush_graphic", enabled ? "true" : "false");
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600192E RID: 6446 RVA: 0x00082798 File Offset: 0x00080998
		private void ScheduleRedrawAfterHalconMouseEvent()
		{
			HSmartWindowControlWPF display = this._display;
			bool flag = ((display != null) ? display.Dispatcher : null) == null;
			if (!flag)
			{
				bool redrawQueued = this._redrawQueued;
				if (!redrawQueued)
				{
					this._redrawQueued = true;
					this._display.Dispatcher.BeginInvoke(new Action(delegate()
					{
						this._redrawQueued = false;
						bool flag2 = this._display == null || !this._display.IsLoaded || this._display.ActualWidth <= 0.0 || this._display.ActualHeight <= 0.0;
						if (!flag2)
						{
							this.Redraw();
						}
					}), DispatcherPriority.Background, Array.Empty<object>());
				}
			}
		}

		// Token: 0x0600192F RID: 6447 RVA: 0x0008170D File Offset: 0x0007F90D
		public void ZoomToFit()
		{
			this.FitAndDisplayImage();
		}

		// Token: 0x06001930 RID: 6448 RVA: 0x000827F8 File Offset: 0x000809F8
		private void FitAndDisplayImage()
		{
			HWindow window = this.GetWindowOrNull();
			bool flag = window == null;
			if (flag)
			{
				this._displayPending = true;
				this.StartPendingRetry();
			}
			else
			{
				bool flag2 = !this.HasImage;
				if (!flag2)
				{
					HTuple width;
					HTuple height;
					HOperatorSet.GetImageSize(this._image, out width, out height);
					bool flag3 = !this.TrySetPart(window, 0, 0, height.I - 1, width.I - 1);
					if (flag3)
					{
						this._displayPending = true;
						this.StartPendingRetry();
					}
					else
					{
						this._displayPending = !this.Redraw();
						bool displayPending = this._displayPending;
						if (displayPending)
						{
							this.StartPendingRetry();
						}
					}
				}
			}
		}

		// Token: 0x06001931 RID: 6449 RVA: 0x0008289C File Offset: 0x00080A9C
		private void DisposeImage()
		{
			this.ClearOverlayRenderer();
			bool flag = this._image != null;
			if (flag)
			{
				this._image.Dispose();
				this._image = null;
			}
			bool flag2 = this._originalImage != null;
			if (flag2)
			{
				this._originalImage.Dispose();
				this._originalImage = null;
			}
		}

		// Token: 0x06001932 RID: 6450 RVA: 0x000828F8 File Offset: 0x00080AF8
		public void Dispose()
		{
			this.ClearOverlay();
			this.StopPendingRetry();
			bool flag = this._display != null;
			if (flag)
			{
				this._display.Loaded -= this.Display_Loaded;
				this._display.IsVisibleChanged -= this.Display_IsVisibleChanged;
				this._display.SizeChanged -= new SizeChangedEventHandler(this.Display_BecameDrawable);
			}
			this.DisposeImage();
		}

		// Token: 0x06001933 RID: 6451 RVA: 0x00082972 File Offset: 0x00080B72
		public void ClearOverlay()
		{
			this.ClearOverlayObjects();
			this.ClearOverlayRenderer();
		}

		// Token: 0x06001934 RID: 6452 RVA: 0x00082984 File Offset: 0x00080B84
		private void ClearOverlayObjects()
		{
			foreach (HObject obj in this._overlayObjects)
			{
				if (obj != null)
				{
					obj.Dispose();
				}
			}
			this._overlayObjects.Clear();
		}

		// Token: 0x06001935 RID: 6453 RVA: 0x000829EC File Offset: 0x00080BEC
		public void SetOverlayRenderer(Action<HWindow> renderer, IDisposable state)
		{
			this.ClearOverlayRenderer();
			this._overlayRenderer = renderer;
			this._overlayRendererState = state;
			this.Redraw();
		}

		// Token: 0x06001936 RID: 6454 RVA: 0x00082A0C File Offset: 0x00080C0C
		public void ClearOverlayRenderer()
		{
			this._overlayRenderer = null;
			bool flag = this._overlayRendererState != null && !this.PreserveOverlayRendererStateOnClear;
			if (flag)
			{
				this._overlayRendererState.Dispose();
			}
			this._overlayRendererState = null;
		}

		// Token: 0x06001937 RID: 6455 RVA: 0x00082A50 File Offset: 0x00080C50
		public void AddOverlay(HObject obj)
		{
			bool flag = obj == null;
			if (!flag)
			{
				bool flag2 = !obj.IsInitialized();
				if (!flag2)
				{
					this._overlayObjects.Add(obj);
				}
			}
		}

		// Token: 0x06001938 RID: 6456 RVA: 0x00082A84 File Offset: 0x00080C84
		public HObject GetCurrentImage()
		{
			bool flag = this._image == null || !this._image.IsInitialized();
			HObject result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HObject copy;
				HOperatorSet.CopyImage(this._image, out copy);
				result = copy;
			}
			return result;
		}

		// Token: 0x06001939 RID: 6457 RVA: 0x00082AC8 File Offset: 0x00080CC8
		public void DisplayImage(HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			if (!flag)
			{
				this.ClearOverlayObjects();
				this.ClearOverlayRenderer();
				bool flag2 = this._image != null;
				if (flag2)
				{
					this._image.Dispose();
					this._image = null;
				}
				HOperatorSet.CopyImage(image, out this._image);
				this.FitAndDisplayImage();
			}
		}

		// Token: 0x0600193A RID: 6458 RVA: 0x00082B30 File Offset: 0x00080D30
		public HObject GetOriginalImage()
		{
			bool flag = this._originalImage == null || !this._originalImage.IsInitialized();
			HObject result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HObject copy;
				HOperatorSet.CopyImage(this._originalImage, out copy);
				result = copy;
			}
			return result;
		}

		// Token: 0x0600193B RID: 6459 RVA: 0x00082B74 File Offset: 0x00080D74
		public HWindow GetHWindow()
		{
			return this._display.HalconWindow;
		}

		// Token: 0x0600193C RID: 6460 RVA: 0x00082B94 File Offset: 0x00080D94
		private HWindow GetWindowOrNull()
		{
			bool flag = this._display == null;
			HWindow result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool flag2 = !this._display.IsLoaded || this._display.ActualWidth <= 0.0 || this._display.ActualHeight <= 0.0;
				if (flag2)
				{
					result = null;
				}
				else
				{
					try
					{
						result = this._display.HalconWindow;
					}
					catch (HOperatorException)
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x0600193D RID: 6461 RVA: 0x00082C24 File Offset: 0x00080E24
		private bool TryGetPart(HWindow window, out HTuple row1, out HTuple col1, out HTuple row2, out HTuple col2)
		{
			HTuple htuple;
			col2 = (htuple = new HTuple());
			row2 = (htuple = htuple);
			col1 = (htuple = htuple);
			row1 = htuple;
			bool result;
			try
			{
				window.GetPart(out row1, out col1, out row2, out col2);
				result = true;
			}
			catch (HOperatorException)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600193E RID: 6462 RVA: 0x00082C74 File Offset: 0x00080E74
		private bool TrySetPart(HWindow window, int row1, int col1, int row2, int col2)
		{
			bool result;
			try
			{
				window.SetPart(row1, col1, row2, col2);
				result = true;
			}
			catch (HOperatorException)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x04000A50 RID: 2640
		private readonly HSmartWindowControlWPF _display;

		// Token: 0x04000A51 RID: 2641
		private HObject _image;

		// Token: 0x04000A52 RID: 2642
		private readonly List<HObject> _overlayObjects = new List<HObject>();

		// Token: 0x04000A53 RID: 2643
		private bool _isPanning;

		// Token: 0x04000A54 RID: 2644
		private bool _didPan;

		// Token: 0x04000A55 RID: 2645
		private MouseButton _panButton;

		// Token: 0x04000A56 RID: 2646
		private Point _panStartPos;

		// Token: 0x04000A57 RID: 2647
		private Point _lastMousePos;

		// Token: 0x04000A58 RID: 2648
		private HObject _originalImage;

		// Token: 0x04000A59 RID: 2649
		private Action<HWindow> _overlayRenderer;

		// Token: 0x04000A5A RID: 2650
		private IDisposable _overlayRendererState;

		// Token: 0x04000A5B RID: 2651
		private bool _redrawQueued;

		// Token: 0x04000A5C RID: 2652
		private bool _isRedrawing;

		// Token: 0x04000A5D RID: 2653
		private readonly object _redrawSync = new object();

		// Token: 0x04000A61 RID: 2657
		private bool _displayPending;

		// Token: 0x04000A62 RID: 2658
		private bool _pendingRetryArmed;
	}
}
