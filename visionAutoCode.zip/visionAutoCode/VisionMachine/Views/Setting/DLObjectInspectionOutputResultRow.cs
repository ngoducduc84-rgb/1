﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A6 RID: 422
	public class DLObjectInspectionOutputResultRow
	{
		// Token: 0x17000822 RID: 2082
		// (get) Token: 0x060016B9 RID: 5817 RVA: 0x00068B81 File Offset: 0x00066D81
		// (set) Token: 0x060016BA RID: 5818 RVA: 0x00068B89 File Offset: 0x00066D89
		public string ToolName { get; set; }

		// Token: 0x17000823 RID: 2083
		// (get) Token: 0x060016BB RID: 5819 RVA: 0x00068B92 File Offset: 0x00066D92
		// (set) Token: 0x060016BC RID: 5820 RVA: 0x00068B9A File Offset: 0x00066D9A
		public string ClassName { get; set; }

		// Token: 0x17000824 RID: 2084
		// (get) Token: 0x060016BD RID: 5821 RVA: 0x00068BA3 File Offset: 0x00066DA3
		// (set) Token: 0x060016BE RID: 5822 RVA: 0x00068BAB File Offset: 0x00066DAB
		public double Confidence { get; set; }

		// Token: 0x17000825 RID: 2085
		// (get) Token: 0x060016BF RID: 5823 RVA: 0x00068BB4 File Offset: 0x00066DB4
		// (set) Token: 0x060016C0 RID: 5824 RVA: 0x00068BBC File Offset: 0x00066DBC
		public int X1 { get; set; }

		// Token: 0x17000826 RID: 2086
		// (get) Token: 0x060016C1 RID: 5825 RVA: 0x00068BC5 File Offset: 0x00066DC5
		// (set) Token: 0x060016C2 RID: 5826 RVA: 0x00068BCD File Offset: 0x00066DCD
		public int Y1 { get; set; }

		// Token: 0x17000827 RID: 2087
		// (get) Token: 0x060016C3 RID: 5827 RVA: 0x00068BD6 File Offset: 0x00066DD6
		// (set) Token: 0x060016C4 RID: 5828 RVA: 0x00068BDE File Offset: 0x00066DDE
		public int X2 { get; set; }

		// Token: 0x17000828 RID: 2088
		// (get) Token: 0x060016C5 RID: 5829 RVA: 0x00068BE7 File Offset: 0x00066DE7
		// (set) Token: 0x060016C6 RID: 5830 RVA: 0x00068BEF File Offset: 0x00066DEF
		public int Y2 { get; set; }

		// Token: 0x17000829 RID: 2089
		// (get) Token: 0x060016C7 RID: 5831 RVA: 0x00068BF8 File Offset: 0x00066DF8
		// (set) Token: 0x060016C8 RID: 5832 RVA: 0x00068C00 File Offset: 0x00066E00
		public int ObjectCount { get; set; }

		// Token: 0x1700082A RID: 2090
		// (get) Token: 0x060016C9 RID: 5833 RVA: 0x00068C09 File Offset: 0x00066E09
		// (set) Token: 0x060016CA RID: 5834 RVA: 0x00068C11 File Offset: 0x00066E11
		public bool SpecEnabled { get; set; }

		// Token: 0x1700082B RID: 2091
		// (get) Token: 0x060016CB RID: 5835 RVA: 0x00068C1A File Offset: 0x00066E1A
		// (set) Token: 0x060016CC RID: 5836 RVA: 0x00068C22 File Offset: 0x00066E22
		public int SpecMin { get; set; }

		// Token: 0x1700082C RID: 2092
		// (get) Token: 0x060016CD RID: 5837 RVA: 0x00068C2B File Offset: 0x00066E2B
		// (set) Token: 0x060016CE RID: 5838 RVA: 0x00068C33 File Offset: 0x00066E33
		public int SpecMax { get; set; }

		// Token: 0x1700082D RID: 2093
		// (get) Token: 0x060016CF RID: 5839 RVA: 0x00068C3C File Offset: 0x00066E3C
		// (set) Token: 0x060016D0 RID: 5840 RVA: 0x00068C44 File Offset: 0x00066E44
		public string Status { get; set; }

		// Token: 0x1700082E RID: 2094
		// (get) Token: 0x060016D1 RID: 5841 RVA: 0x00068C50 File Offset: 0x00066E50
		public Brush StatusBrush
		{
			get
			{
				bool flag = string.Equals(this.Status, "OK", StringComparison.OrdinalIgnoreCase);
				Brush result;
				if (flag)
				{
					result = Brushes.LimeGreen;
				}
				else
				{
					bool flag2 = string.Equals(this.Status, "NG", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						result = Brushes.Red;
					}
					else
					{
						bool flag3 = string.Equals(this.Status, "Lost", StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							result = Brushes.Goldenrod;
						}
						else
						{
							result = Brushes.White;
						}
					}
				}
				return result;
			}
		}

		// Token: 0x1700082F RID: 2095
		// (get) Token: 0x060016D2 RID: 5842 RVA: 0x00068CBE File Offset: 0x00066EBE
		// (set) Token: 0x060016D3 RID: 5843 RVA: 0x00068CC6 File Offset: 0x00066EC6
		public string InputSourceToolName { get; set; }

		// Token: 0x17000830 RID: 2096
		// (get) Token: 0x060016D4 RID: 5844 RVA: 0x00068CCF File Offset: 0x00066ECF
		// (set) Token: 0x060016D5 RID: 5845 RVA: 0x00068CD7 File Offset: 0x00066ED7
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000831 RID: 2097
		// (get) Token: 0x060016D6 RID: 5846 RVA: 0x00068CE0 File Offset: 0x00066EE0
		// (set) Token: 0x060016D7 RID: 5847 RVA: 0x00068CE8 File Offset: 0x00066EE8
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x17000832 RID: 2098
		// (get) Token: 0x060016D8 RID: 5848 RVA: 0x00068CF1 File Offset: 0x00066EF1
		// (set) Token: 0x060016D9 RID: 5849 RVA: 0x00068CF9 File Offset: 0x00066EF9
		public string Message { get; set; }
	}
}
