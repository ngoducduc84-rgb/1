﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A5 RID: 421
	public class DeformableInspectionOutputResultRow
	{
		// Token: 0x1700080F RID: 2063
		// (get) Token: 0x06001693 RID: 5779 RVA: 0x000689DE File Offset: 0x00066BDE
		// (set) Token: 0x06001694 RID: 5780 RVA: 0x000689E6 File Offset: 0x00066BE6
		public string ToolName { get; set; }

		// Token: 0x17000810 RID: 2064
		// (get) Token: 0x06001695 RID: 5781 RVA: 0x000689EF File Offset: 0x00066BEF
		// (set) Token: 0x06001696 RID: 5782 RVA: 0x000689F7 File Offset: 0x00066BF7
		public string MetricName { get; set; }

		// Token: 0x17000811 RID: 2065
		// (get) Token: 0x06001697 RID: 5783 RVA: 0x00068A00 File Offset: 0x00066C00
		// (set) Token: 0x06001698 RID: 5784 RVA: 0x00068A08 File Offset: 0x00066C08
		public double Value { get; set; }

		// Token: 0x17000812 RID: 2066
		// (get) Token: 0x06001699 RID: 5785 RVA: 0x00068A11 File Offset: 0x00066C11
		// (set) Token: 0x0600169A RID: 5786 RVA: 0x00068A19 File Offset: 0x00066C19
		public bool SpecEnabled { get; set; }

		// Token: 0x17000813 RID: 2067
		// (get) Token: 0x0600169B RID: 5787 RVA: 0x00068A22 File Offset: 0x00066C22
		// (set) Token: 0x0600169C RID: 5788 RVA: 0x00068A2A File Offset: 0x00066C2A
		public double SpecMin { get; set; }

		// Token: 0x17000814 RID: 2068
		// (get) Token: 0x0600169D RID: 5789 RVA: 0x00068A33 File Offset: 0x00066C33
		// (set) Token: 0x0600169E RID: 5790 RVA: 0x00068A3B File Offset: 0x00066C3B
		public double SpecMax { get; set; }

		// Token: 0x17000815 RID: 2069
		// (get) Token: 0x0600169F RID: 5791 RVA: 0x00068A44 File Offset: 0x00066C44
		// (set) Token: 0x060016A0 RID: 5792 RVA: 0x00068A4C File Offset: 0x00066C4C
		public string Status { get; set; }

		// Token: 0x17000816 RID: 2070
		// (get) Token: 0x060016A1 RID: 5793 RVA: 0x00068A58 File Offset: 0x00066C58
		public Brush StatusBrush
		{
			get
			{
				bool flag = string.Equals(this.Status, "OK", StringComparison.OrdinalIgnoreCase);
				Brush result;
				if (flag)
				{
					result = Brushes.LimeGreen;
				}
				else
				{
					bool flag2 = string.Equals(this.Status, "NG", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						result = Brushes.Red;
					}
					else
					{
						bool flag3 = string.Equals(this.Status, "Lost", StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							result = Brushes.Goldenrod;
						}
						else
						{
							result = Brushes.White;
						}
					}
				}
				return result;
			}
		}

		// Token: 0x17000817 RID: 2071
		// (get) Token: 0x060016A2 RID: 5794 RVA: 0x00068AC6 File Offset: 0x00066CC6
		// (set) Token: 0x060016A3 RID: 5795 RVA: 0x00068ACE File Offset: 0x00066CCE
		public double Row { get; set; }

		// Token: 0x17000818 RID: 2072
		// (get) Token: 0x060016A4 RID: 5796 RVA: 0x00068AD7 File Offset: 0x00066CD7
		// (set) Token: 0x060016A5 RID: 5797 RVA: 0x00068ADF File Offset: 0x00066CDF
		public double Column { get; set; }

		// Token: 0x17000819 RID: 2073
		// (get) Token: 0x060016A6 RID: 5798 RVA: 0x00068AE8 File Offset: 0x00066CE8
		// (set) Token: 0x060016A7 RID: 5799 RVA: 0x00068AF0 File Offset: 0x00066CF0
		public double Score { get; set; }

		// Token: 0x1700081A RID: 2074
		// (get) Token: 0x060016A8 RID: 5800 RVA: 0x00068AF9 File Offset: 0x00066CF9
		// (set) Token: 0x060016A9 RID: 5801 RVA: 0x00068B01 File Offset: 0x00066D01
		public double MaxDeformation { get; set; }

		// Token: 0x1700081B RID: 2075
		// (get) Token: 0x060016AA RID: 5802 RVA: 0x00068B0A File Offset: 0x00066D0A
		// (set) Token: 0x060016AB RID: 5803 RVA: 0x00068B12 File Offset: 0x00066D12
		public double MeanDeformation { get; set; }

		// Token: 0x1700081C RID: 2076
		// (get) Token: 0x060016AC RID: 5804 RVA: 0x00068B1B File Offset: 0x00066D1B
		// (set) Token: 0x060016AD RID: 5805 RVA: 0x00068B23 File Offset: 0x00066D23
		public double DefectArea { get; set; }

		// Token: 0x1700081D RID: 2077
		// (get) Token: 0x060016AE RID: 5806 RVA: 0x00068B2C File Offset: 0x00066D2C
		// (set) Token: 0x060016AF RID: 5807 RVA: 0x00068B34 File Offset: 0x00066D34
		public string InputSourceToolName { get; set; }

		// Token: 0x1700081E RID: 2078
		// (get) Token: 0x060016B0 RID: 5808 RVA: 0x00068B3D File Offset: 0x00066D3D
		// (set) Token: 0x060016B1 RID: 5809 RVA: 0x00068B45 File Offset: 0x00066D45
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x1700081F RID: 2079
		// (get) Token: 0x060016B2 RID: 5810 RVA: 0x00068B4E File Offset: 0x00066D4E
		// (set) Token: 0x060016B3 RID: 5811 RVA: 0x00068B56 File Offset: 0x00066D56
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000820 RID: 2080
		// (get) Token: 0x060016B4 RID: 5812 RVA: 0x00068B5F File Offset: 0x00066D5F
		// (set) Token: 0x060016B5 RID: 5813 RVA: 0x00068B67 File Offset: 0x00066D67
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x17000821 RID: 2081
		// (get) Token: 0x060016B6 RID: 5814 RVA: 0x00068B70 File Offset: 0x00066D70
		// (set) Token: 0x060016B7 RID: 5815 RVA: 0x00068B78 File Offset: 0x00066D78
		public string Message { get; set; }
	}
}
