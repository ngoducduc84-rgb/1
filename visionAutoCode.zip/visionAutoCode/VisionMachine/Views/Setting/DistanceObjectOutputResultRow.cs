﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A3 RID: 419
	public class DistanceObjectOutputResultRow
	{
		// Token: 0x170007F2 RID: 2034
		// (get) Token: 0x06001659 RID: 5721 RVA: 0x00068734 File Offset: 0x00066934
		// (set) Token: 0x0600165A RID: 5722 RVA: 0x0006873C File Offset: 0x0006693C
		public string Object1ToolName { get; set; }

		// Token: 0x170007F3 RID: 2035
		// (get) Token: 0x0600165B RID: 5723 RVA: 0x00068745 File Offset: 0x00066945
		// (set) Token: 0x0600165C RID: 5724 RVA: 0x0006874D File Offset: 0x0006694D
		public string Object2ToolName { get; set; }

		// Token: 0x170007F4 RID: 2036
		// (get) Token: 0x0600165D RID: 5725 RVA: 0x00068756 File Offset: 0x00066956
		// (set) Token: 0x0600165E RID: 5726 RVA: 0x0006875E File Offset: 0x0006695E
		public string Object1Feature { get; set; }

		// Token: 0x170007F5 RID: 2037
		// (get) Token: 0x0600165F RID: 5727 RVA: 0x00068767 File Offset: 0x00066967
		// (set) Token: 0x06001660 RID: 5728 RVA: 0x0006876F File Offset: 0x0006696F
		public string Object2Feature { get; set; }

		// Token: 0x170007F6 RID: 2038
		// (get) Token: 0x06001661 RID: 5729 RVA: 0x00068778 File Offset: 0x00066978
		// (set) Token: 0x06001662 RID: 5730 RVA: 0x00068780 File Offset: 0x00066980
		public string MeasurementMode { get; set; }

		// Token: 0x170007F7 RID: 2039
		// (get) Token: 0x06001663 RID: 5731 RVA: 0x00068789 File Offset: 0x00066989
		// (set) Token: 0x06001664 RID: 5732 RVA: 0x00068791 File Offset: 0x00066991
		public double Distance { get; set; }

		// Token: 0x170007F8 RID: 2040
		// (get) Token: 0x06001665 RID: 5733 RVA: 0x0006879A File Offset: 0x0006699A
		// (set) Token: 0x06001666 RID: 5734 RVA: 0x000687A2 File Offset: 0x000669A2
		public double DistanceMm { get; set; }

		// Token: 0x170007F9 RID: 2041
		// (get) Token: 0x06001667 RID: 5735 RVA: 0x000687AB File Offset: 0x000669AB
		// (set) Token: 0x06001668 RID: 5736 RVA: 0x000687B3 File Offset: 0x000669B3
		public double MillimetersPerPixel { get; set; }

		// Token: 0x170007FA RID: 2042
		// (get) Token: 0x06001669 RID: 5737 RVA: 0x000687BC File Offset: 0x000669BC
		// (set) Token: 0x0600166A RID: 5738 RVA: 0x000687C4 File Offset: 0x000669C4
		public string SpecStatus { get; set; }

		// Token: 0x170007FB RID: 2043
		// (get) Token: 0x0600166B RID: 5739 RVA: 0x000687D0 File Offset: 0x000669D0
		public Brush SpecStatusBrush
		{
			get
			{
				bool flag = string.Equals(this.SpecStatus, "OK", StringComparison.OrdinalIgnoreCase);
				Brush result;
				if (flag)
				{
					result = Brushes.LimeGreen;
				}
				else
				{
					bool flag2 = string.Equals(this.SpecStatus, "NG", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						result = Brushes.Red;
					}
					else
					{
						bool flag3 = string.Equals(this.SpecStatus, "No Calib", StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							result = Brushes.Goldenrod;
						}
						else
						{
							result = Brushes.White;
						}
					}
				}
				return result;
			}
		}

		// Token: 0x170007FC RID: 2044
		// (get) Token: 0x0600166C RID: 5740 RVA: 0x0006883E File Offset: 0x00066A3E
		// (set) Token: 0x0600166D RID: 5741 RVA: 0x00068846 File Offset: 0x00066A46
		public double SpecMinimumMm { get; set; }

		// Token: 0x170007FD RID: 2045
		// (get) Token: 0x0600166E RID: 5742 RVA: 0x0006884F File Offset: 0x00066A4F
		// (set) Token: 0x0600166F RID: 5743 RVA: 0x00068857 File Offset: 0x00066A57
		public double SpecMaximumMm { get; set; }

		// Token: 0x170007FE RID: 2046
		// (get) Token: 0x06001670 RID: 5744 RVA: 0x00068860 File Offset: 0x00066A60
		// (set) Token: 0x06001671 RID: 5745 RVA: 0x00068868 File Offset: 0x00066A68
		public double Object1ProcessingTimeMs { get; set; }

		// Token: 0x170007FF RID: 2047
		// (get) Token: 0x06001672 RID: 5746 RVA: 0x00068871 File Offset: 0x00066A71
		// (set) Token: 0x06001673 RID: 5747 RVA: 0x00068879 File Offset: 0x00066A79
		public double Object2ProcessingTimeMs { get; set; }

		// Token: 0x17000800 RID: 2048
		// (get) Token: 0x06001674 RID: 5748 RVA: 0x00068882 File Offset: 0x00066A82
		// (set) Token: 0x06001675 RID: 5749 RVA: 0x0006888A File Offset: 0x00066A8A
		public double TotalProcessingTimeMs { get; set; }
	}
}
