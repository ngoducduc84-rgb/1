﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A1 RID: 417
	public class FindBoundingBoxOutputResultRow : INotifyPropertyChanged
	{
		// Token: 0x14000027 RID: 39
		// (add) Token: 0x0600160D RID: 5645 RVA: 0x00068174 File Offset: 0x00066374
		// (remove) Token: 0x0600160E RID: 5646 RVA: 0x000681AC File Offset: 0x000663AC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x170007CE RID: 1998
		// (get) Token: 0x0600160F RID: 5647 RVA: 0x000681E1 File Offset: 0x000663E1
		// (set) Token: 0x06001610 RID: 5648 RVA: 0x000681E9 File Offset: 0x000663E9
		public string ToolName { get; set; }

		// Token: 0x170007CF RID: 1999
		// (get) Token: 0x06001611 RID: 5649 RVA: 0x000681F2 File Offset: 0x000663F2
		// (set) Token: 0x06001612 RID: 5650 RVA: 0x000681FA File Offset: 0x000663FA
		public string RoiName { get; set; }

		// Token: 0x170007D0 RID: 2000
		// (get) Token: 0x06001613 RID: 5651 RVA: 0x00068203 File Offset: 0x00066403
		// (set) Token: 0x06001614 RID: 5652 RVA: 0x0006820B File Offset: 0x0006640B
		public bool IsSelected { get; set; }

		// Token: 0x170007D1 RID: 2001
		// (get) Token: 0x06001615 RID: 5653 RVA: 0x00068214 File Offset: 0x00066414
		// (set) Token: 0x06001616 RID: 5654 RVA: 0x0006822C File Offset: 0x0006642C
		public bool IsImageClicked
		{
			get
			{
				return this._isImageClicked;
			}
			set
			{
				bool flag = this._isImageClicked == value;
				if (!flag)
				{
					this._isImageClicked = value;
					this.OnPropertyChanged("IsImageClicked");
					this.OnPropertyChanged("Selection");
					this.OnPropertyChanged("RowBrush");
					this.OnPropertyChanged("TextBrush");
				}
			}
		}

		// Token: 0x170007D2 RID: 2002
		// (get) Token: 0x06001617 RID: 5655 RVA: 0x00068280 File Offset: 0x00066480
		public string Selection
		{
			get
			{
				bool isImageClicked = this.IsImageClicked;
				string result;
				if (isImageClicked)
				{
					result = "Clicked";
				}
				else
				{
					result = (this.IsSelected ? "Parameter" : string.Empty);
				}
				return result;
			}
		}

		// Token: 0x170007D3 RID: 2003
		// (get) Token: 0x06001618 RID: 5656 RVA: 0x000682B8 File Offset: 0x000664B8
		public Brush RowBrush
		{
			get
			{
				bool isImageClicked = this.IsImageClicked;
				Brush result;
				if (isImageClicked)
				{
					result = Brushes.Goldenrod;
				}
				else
				{
					result = (this.IsSelected ? Brushes.SeaGreen : Brushes.Transparent);
				}
				return result;
			}
		}

		// Token: 0x170007D4 RID: 2004
		// (get) Token: 0x06001619 RID: 5657 RVA: 0x000682F0 File Offset: 0x000664F0
		public Brush TextBrush
		{
			get
			{
				return Brushes.WhiteSmoke;
			}
		}

		// Token: 0x170007D5 RID: 2005
		// (get) Token: 0x0600161A RID: 5658 RVA: 0x00068307 File Offset: 0x00066507
		// (set) Token: 0x0600161B RID: 5659 RVA: 0x0006830F File Offset: 0x0006650F
		public int GridRow { get; set; }

		// Token: 0x170007D6 RID: 2006
		// (get) Token: 0x0600161C RID: 5660 RVA: 0x00068318 File Offset: 0x00066518
		// (set) Token: 0x0600161D RID: 5661 RVA: 0x00068320 File Offset: 0x00066520
		public int GridColumn { get; set; }

		// Token: 0x170007D7 RID: 2007
		// (get) Token: 0x0600161E RID: 5662 RVA: 0x00068329 File Offset: 0x00066529
		// (set) Token: 0x0600161F RID: 5663 RVA: 0x00068331 File Offset: 0x00066531
		public double CenterRow { get; set; }

		// Token: 0x170007D8 RID: 2008
		// (get) Token: 0x06001620 RID: 5664 RVA: 0x0006833A File Offset: 0x0006653A
		// (set) Token: 0x06001621 RID: 5665 RVA: 0x00068342 File Offset: 0x00066542
		public double CenterColumn { get; set; }

		// Token: 0x170007D9 RID: 2009
		// (get) Token: 0x06001622 RID: 5666 RVA: 0x0006834B File Offset: 0x0006654B
		// (set) Token: 0x06001623 RID: 5667 RVA: 0x00068353 File Offset: 0x00066553
		public double TopLeftRow { get; set; }

		// Token: 0x170007DA RID: 2010
		// (get) Token: 0x06001624 RID: 5668 RVA: 0x0006835C File Offset: 0x0006655C
		// (set) Token: 0x06001625 RID: 5669 RVA: 0x00068364 File Offset: 0x00066564
		public double TopLeftColumn { get; set; }

		// Token: 0x170007DB RID: 2011
		// (get) Token: 0x06001626 RID: 5670 RVA: 0x0006836D File Offset: 0x0006656D
		// (set) Token: 0x06001627 RID: 5671 RVA: 0x00068375 File Offset: 0x00066575
		public double TopRightRow { get; set; }

		// Token: 0x170007DC RID: 2012
		// (get) Token: 0x06001628 RID: 5672 RVA: 0x0006837E File Offset: 0x0006657E
		// (set) Token: 0x06001629 RID: 5673 RVA: 0x00068386 File Offset: 0x00066586
		public double TopRightColumn { get; set; }

		// Token: 0x170007DD RID: 2013
		// (get) Token: 0x0600162A RID: 5674 RVA: 0x0006838F File Offset: 0x0006658F
		// (set) Token: 0x0600162B RID: 5675 RVA: 0x00068397 File Offset: 0x00066597
		public double BottomRightRow { get; set; }

		// Token: 0x170007DE RID: 2014
		// (get) Token: 0x0600162C RID: 5676 RVA: 0x000683A0 File Offset: 0x000665A0
		// (set) Token: 0x0600162D RID: 5677 RVA: 0x000683A8 File Offset: 0x000665A8
		public double BottomRightColumn { get; set; }

		// Token: 0x170007DF RID: 2015
		// (get) Token: 0x0600162E RID: 5678 RVA: 0x000683B1 File Offset: 0x000665B1
		// (set) Token: 0x0600162F RID: 5679 RVA: 0x000683B9 File Offset: 0x000665B9
		public double BottomLeftRow { get; set; }

		// Token: 0x170007E0 RID: 2016
		// (get) Token: 0x06001630 RID: 5680 RVA: 0x000683C2 File Offset: 0x000665C2
		// (set) Token: 0x06001631 RID: 5681 RVA: 0x000683CA File Offset: 0x000665CA
		public double BottomLeftColumn { get; set; }

		// Token: 0x170007E1 RID: 2017
		// (get) Token: 0x06001632 RID: 5682 RVA: 0x000683D3 File Offset: 0x000665D3
		// (set) Token: 0x06001633 RID: 5683 RVA: 0x000683DB File Offset: 0x000665DB
		public double Angle { get; set; }

		// Token: 0x170007E2 RID: 2018
		// (get) Token: 0x06001634 RID: 5684 RVA: 0x000683E4 File Offset: 0x000665E4
		// (set) Token: 0x06001635 RID: 5685 RVA: 0x000683EC File Offset: 0x000665EC
		public double Width { get; set; }

		// Token: 0x170007E3 RID: 2019
		// (get) Token: 0x06001636 RID: 5686 RVA: 0x000683F5 File Offset: 0x000665F5
		// (set) Token: 0x06001637 RID: 5687 RVA: 0x000683FD File Offset: 0x000665FD
		public double Height { get; set; }

		// Token: 0x170007E4 RID: 2020
		// (get) Token: 0x06001638 RID: 5688 RVA: 0x00068406 File Offset: 0x00066606
		// (set) Token: 0x06001639 RID: 5689 RVA: 0x0006840E File Offset: 0x0006660E
		public double Area { get; set; }

		// Token: 0x170007E5 RID: 2021
		// (get) Token: 0x0600163A RID: 5690 RVA: 0x00068417 File Offset: 0x00066617
		// (set) Token: 0x0600163B RID: 5691 RVA: 0x0006841F File Offset: 0x0006661F
		public string InputSourceToolName { get; set; }

		// Token: 0x170007E6 RID: 2022
		// (get) Token: 0x0600163C RID: 5692 RVA: 0x00068428 File Offset: 0x00066628
		// (set) Token: 0x0600163D RID: 5693 RVA: 0x00068430 File Offset: 0x00066630
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x170007E7 RID: 2023
		// (get) Token: 0x0600163E RID: 5694 RVA: 0x00068439 File Offset: 0x00066639
		// (set) Token: 0x0600163F RID: 5695 RVA: 0x00068441 File Offset: 0x00066641
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170007E8 RID: 2024
		// (get) Token: 0x06001640 RID: 5696 RVA: 0x0006844A File Offset: 0x0006664A
		// (set) Token: 0x06001641 RID: 5697 RVA: 0x00068452 File Offset: 0x00066652
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x06001642 RID: 5698 RVA: 0x0006845C File Offset: 0x0006665C
		public bool ContainsImagePoint(double row, double column)
		{
			Tuple<double, double>[] polygon = new Tuple<double, double>[]
			{
				Tuple.Create<double, double>(this.TopLeftRow, this.TopLeftColumn),
				Tuple.Create<double, double>(this.TopRightRow, this.TopRightColumn),
				Tuple.Create<double, double>(this.BottomRightRow, this.BottomRightColumn),
				Tuple.Create<double, double>(this.BottomLeftRow, this.BottomLeftColumn)
			};
			bool inside = false;
			int i = polygon.Length - 1;
			for (int j = 0; j < polygon.Length; j++)
			{
				double rowI = polygon[j].Item1;
				double colI = polygon[j].Item2;
				double rowJ = polygon[i].Item1;
				double colJ = polygon[i].Item2;
				bool intersects = rowI > row != rowJ > row && column < (colJ - colI) * (row - rowI) / ((rowJ - rowI == 0.0) ? 1E-06 : (rowJ - rowI)) + colI;
				bool flag = intersects;
				if (flag)
				{
					inside = !inside;
				}
				i = j;
			}
			return inside;
		}

		// Token: 0x06001643 RID: 5699 RVA: 0x00068562 File Offset: 0x00066762
		private void OnPropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000942 RID: 2370
		private bool _isImageClicked;
	}
}
