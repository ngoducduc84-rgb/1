﻿using System;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A0 RID: 416
	public class FindCircleOutputResultRow
	{
		// Token: 0x170007C2 RID: 1986
		// (get) Token: 0x060015F4 RID: 5620 RVA: 0x000680A8 File Offset: 0x000662A8
		// (set) Token: 0x060015F5 RID: 5621 RVA: 0x000680B0 File Offset: 0x000662B0
		public string ToolName { get; set; }

		// Token: 0x170007C3 RID: 1987
		// (get) Token: 0x060015F6 RID: 5622 RVA: 0x000680B9 File Offset: 0x000662B9
		// (set) Token: 0x060015F7 RID: 5623 RVA: 0x000680C1 File Offset: 0x000662C1
		public string RoiName { get; set; }

		// Token: 0x170007C4 RID: 1988
		// (get) Token: 0x060015F8 RID: 5624 RVA: 0x000680CA File Offset: 0x000662CA
		// (set) Token: 0x060015F9 RID: 5625 RVA: 0x000680D2 File Offset: 0x000662D2
		public double Row { get; set; }

		// Token: 0x170007C5 RID: 1989
		// (get) Token: 0x060015FA RID: 5626 RVA: 0x000680DB File Offset: 0x000662DB
		// (set) Token: 0x060015FB RID: 5627 RVA: 0x000680E3 File Offset: 0x000662E3
		public double Column { get; set; }

		// Token: 0x170007C6 RID: 1990
		// (get) Token: 0x060015FC RID: 5628 RVA: 0x000680EC File Offset: 0x000662EC
		// (set) Token: 0x060015FD RID: 5629 RVA: 0x000680F4 File Offset: 0x000662F4
		public double Radius { get; set; }

		// Token: 0x170007C7 RID: 1991
		// (get) Token: 0x060015FE RID: 5630 RVA: 0x000680FD File Offset: 0x000662FD
		// (set) Token: 0x060015FF RID: 5631 RVA: 0x00068105 File Offset: 0x00066305
		public string MasterPositionToolName { get; set; }

		// Token: 0x170007C8 RID: 1992
		// (get) Token: 0x06001600 RID: 5632 RVA: 0x0006810E File Offset: 0x0006630E
		// (set) Token: 0x06001601 RID: 5633 RVA: 0x00068116 File Offset: 0x00066316
		public string MasterAngleToolName { get; set; }

		// Token: 0x170007C9 RID: 1993
		// (get) Token: 0x06001602 RID: 5634 RVA: 0x0006811F File Offset: 0x0006631F
		// (set) Token: 0x06001603 RID: 5635 RVA: 0x00068127 File Offset: 0x00066327
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x170007CA RID: 1994
		// (get) Token: 0x06001604 RID: 5636 RVA: 0x00068130 File Offset: 0x00066330
		// (set) Token: 0x06001605 RID: 5637 RVA: 0x00068138 File Offset: 0x00066338
		public string InputSourceToolName { get; set; }

		// Token: 0x170007CB RID: 1995
		// (get) Token: 0x06001606 RID: 5638 RVA: 0x00068141 File Offset: 0x00066341
		// (set) Token: 0x06001607 RID: 5639 RVA: 0x00068149 File Offset: 0x00066349
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x170007CC RID: 1996
		// (get) Token: 0x06001608 RID: 5640 RVA: 0x00068152 File Offset: 0x00066352
		// (set) Token: 0x06001609 RID: 5641 RVA: 0x0006815A File Offset: 0x0006635A
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170007CD RID: 1997
		// (get) Token: 0x0600160A RID: 5642 RVA: 0x00068163 File Offset: 0x00066363
		// (set) Token: 0x0600160B RID: 5643 RVA: 0x0006816B File Offset: 0x0006636B
		public double TotalProcessingTimeMs { get; set; }
	}
}
