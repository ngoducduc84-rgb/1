﻿using System;

namespace VisionMachine.Views.Setting
{
	// Token: 0x0200019F RID: 415
	public class FindLineOutputResultRow
	{
		// Token: 0x170007B6 RID: 1974
		// (get) Token: 0x060015DB RID: 5595 RVA: 0x00067FDC File Offset: 0x000661DC
		// (set) Token: 0x060015DC RID: 5596 RVA: 0x00067FE4 File Offset: 0x000661E4
		public string ToolName { get; set; }

		// Token: 0x170007B7 RID: 1975
		// (get) Token: 0x060015DD RID: 5597 RVA: 0x00067FED File Offset: 0x000661ED
		// (set) Token: 0x060015DE RID: 5598 RVA: 0x00067FF5 File Offset: 0x000661F5
		public double StartRow { get; set; }

		// Token: 0x170007B8 RID: 1976
		// (get) Token: 0x060015DF RID: 5599 RVA: 0x00067FFE File Offset: 0x000661FE
		// (set) Token: 0x060015E0 RID: 5600 RVA: 0x00068006 File Offset: 0x00066206
		public double StartColumn { get; set; }

		// Token: 0x170007B9 RID: 1977
		// (get) Token: 0x060015E1 RID: 5601 RVA: 0x0006800F File Offset: 0x0006620F
		// (set) Token: 0x060015E2 RID: 5602 RVA: 0x00068017 File Offset: 0x00066217
		public double EndRow { get; set; }

		// Token: 0x170007BA RID: 1978
		// (get) Token: 0x060015E3 RID: 5603 RVA: 0x00068020 File Offset: 0x00066220
		// (set) Token: 0x060015E4 RID: 5604 RVA: 0x00068028 File Offset: 0x00066228
		public double EndColumn { get; set; }

		// Token: 0x170007BB RID: 1979
		// (get) Token: 0x060015E5 RID: 5605 RVA: 0x00068031 File Offset: 0x00066231
		// (set) Token: 0x060015E6 RID: 5606 RVA: 0x00068039 File Offset: 0x00066239
		public string MasterPositionToolName { get; set; }

		// Token: 0x170007BC RID: 1980
		// (get) Token: 0x060015E7 RID: 5607 RVA: 0x00068042 File Offset: 0x00066242
		// (set) Token: 0x060015E8 RID: 5608 RVA: 0x0006804A File Offset: 0x0006624A
		public string MasterAngleToolName { get; set; }

		// Token: 0x170007BD RID: 1981
		// (get) Token: 0x060015E9 RID: 5609 RVA: 0x00068053 File Offset: 0x00066253
		// (set) Token: 0x060015EA RID: 5610 RVA: 0x0006805B File Offset: 0x0006625B
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x170007BE RID: 1982
		// (get) Token: 0x060015EB RID: 5611 RVA: 0x00068064 File Offset: 0x00066264
		// (set) Token: 0x060015EC RID: 5612 RVA: 0x0006806C File Offset: 0x0006626C
		public string InputSourceToolName { get; set; }

		// Token: 0x170007BF RID: 1983
		// (get) Token: 0x060015ED RID: 5613 RVA: 0x00068075 File Offset: 0x00066275
		// (set) Token: 0x060015EE RID: 5614 RVA: 0x0006807D File Offset: 0x0006627D
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x170007C0 RID: 1984
		// (get) Token: 0x060015EF RID: 5615 RVA: 0x00068086 File Offset: 0x00066286
		// (set) Token: 0x060015F0 RID: 5616 RVA: 0x0006808E File Offset: 0x0006628E
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170007C1 RID: 1985
		// (get) Token: 0x060015F1 RID: 5617 RVA: 0x00068097 File Offset: 0x00066297
		// (set) Token: 0x060015F2 RID: 5618 RVA: 0x0006809F File Offset: 0x0006629F
		public double TotalProcessingTimeMs { get; set; }
	}
}
