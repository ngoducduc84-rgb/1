﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Threading;
using DevExpress.Xpf.Bars;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Docking;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.Grid;
using HalconDotNet;
using Microsoft.Win32;
using VisionMachine.Controls.Common;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.Services;
using VisionMachine.Services.Dialogs;
using VisionMachine.Services.Runtime;
using VisionMachine.Services.Storage;
using VisionMachine.Services.Tool;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Main;
using VisionMachine.Views.Setting.Controllers;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.Blob;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CalibHandEye;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.CountBoundingBox;
using VisionMachine.VisionTools.DeformableInspection;
using VisionMachine.VisionTools.DistanceObject;
using VisionMachine.VisionTools.DLObjectInspection;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;
using VisionMachine.VisionTools.FindRedArrow;
using VisionMachine.VisionTools.Histogram;
using VisionMachine.VisionTools.HistogramColor;
using VisionMachine.VisionTools.ImageFilter;
using VisionMachine.VisionTools.ImageTransform;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MatrixCode;
using VisionMachine.VisionTools.MeasureCircle;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ProcedureInspection;
using VisionMachine.VisionTools.ProcedureModel;
using VisionMachine.VisionTools.ProductCountInspection;
using VisionMachine.VisionTools.ResultAlign;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.Runtime;
using VisionMachine.VisionTools.SaveImage;
using VisionMachine.VisionTools.ShapeModel;
using VisionMachine.VisionTools.VariationChangeWD;
using VisionMachine.VisionTools.VariationModel;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001AC RID: 428
	public partial class Form_setting : ThemedWindow, INotifyPropertyChanged, IStyleConnector
	{
		// Token: 0x1700086C RID: 2156
		// (get) Token: 0x0600174F RID: 5967 RVA: 0x000691D8 File Offset: 0x000673D8
		// (set) Token: 0x06001750 RID: 5968 RVA: 0x000691DF File Offset: 0x000673DF
		public static Form_setting Instance { get; private set; }

		// Token: 0x14000029 RID: 41
		// (add) Token: 0x06001751 RID: 5969 RVA: 0x000691E8 File Offset: 0x000673E8
		// (remove) Token: 0x06001752 RID: 5970 RVA: 0x00069220 File Offset: 0x00067420
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x1700086D RID: 2157
		// (get) Token: 0x06001753 RID: 5971 RVA: 0x00069255 File Offset: 0x00067455
		// (set) Token: 0x06001754 RID: 5972 RVA: 0x00069260 File Offset: 0x00067460
		public string PixelInspectorText
		{
			get
			{
				return this._pixelInspectorText;
			}
			set
			{
				bool flag = this._pixelInspectorText == value;
				if (!flag)
				{
					this._pixelInspectorText = value;
					this.OnFormPropertyChanged("PixelInspectorText");
				}
			}
		}

		// Token: 0x1700086E RID: 2158
		// (get) Token: 0x06001755 RID: 5973 RVA: 0x00069293 File Offset: 0x00067493
		public ObservableCollection<BlobOutputResultRow> BlobOutputResults { get; } = new ObservableCollection<BlobOutputResultRow>();

		// Token: 0x1700086F RID: 2159
		// (get) Token: 0x06001756 RID: 5974 RVA: 0x0006929B File Offset: 0x0006749B
		public ObservableCollection<ShapeModelOutputResultRow> ShapeModelOutputResults { get; } = new ObservableCollection<ShapeModelOutputResultRow>();

		// Token: 0x17000870 RID: 2160
		// (get) Token: 0x06001757 RID: 5975 RVA: 0x000692A3 File Offset: 0x000674A3
		public ObservableCollection<FindLineOutputResultRow> FindLineOutputResults { get; } = new ObservableCollection<FindLineOutputResultRow>();

		// Token: 0x17000871 RID: 2161
		// (get) Token: 0x06001758 RID: 5976 RVA: 0x000692AB File Offset: 0x000674AB
		public ObservableCollection<FindCircleOutputResultRow> FindCircleOutputResults { get; } = new ObservableCollection<FindCircleOutputResultRow>();

		// Token: 0x17000872 RID: 2162
		// (get) Token: 0x06001759 RID: 5977 RVA: 0x000692B3 File Offset: 0x000674B3
		public ObservableCollection<FindBoundingBoxOutputResultRow> FindBoundingBoxOutputResults { get; } = new ObservableCollection<FindBoundingBoxOutputResultRow>();

		// Token: 0x17000873 RID: 2163
		// (get) Token: 0x0600175A RID: 5978 RVA: 0x000692BB File Offset: 0x000674BB
		public ObservableCollection<RunAllOutputResultRow> RunAllOutputResults { get; } = new ObservableCollection<RunAllOutputResultRow>();

		// Token: 0x17000874 RID: 2164
		// (get) Token: 0x0600175B RID: 5979 RVA: 0x000692C3 File Offset: 0x000674C3
		public ObservableCollection<DistanceObjectOutputResultRow> DistanceObjectOutputResults { get; } = new ObservableCollection<DistanceObjectOutputResultRow>();

		// Token: 0x17000875 RID: 2165
		// (get) Token: 0x0600175C RID: 5980 RVA: 0x000692CB File Offset: 0x000674CB
		public ObservableCollection<MeasureCircleOutputResultRow> MeasureCircleOutputResults { get; } = new ObservableCollection<MeasureCircleOutputResultRow>();

		// Token: 0x17000876 RID: 2166
		// (get) Token: 0x0600175D RID: 5981 RVA: 0x000692D3 File Offset: 0x000674D3
		public ObservableCollection<DeformableInspectionOutputResultRow> DeformableInspectionOutputResults { get; } = new ObservableCollection<DeformableInspectionOutputResultRow>();

		// Token: 0x17000877 RID: 2167
		// (get) Token: 0x0600175E RID: 5982 RVA: 0x000692DB File Offset: 0x000674DB
		public ObservableCollection<DLObjectInspectionOutputResultRow> DLObjectInspectionOutputResults { get; } = new ObservableCollection<DLObjectInspectionOutputResultRow>();

		// Token: 0x17000878 RID: 2168
		// (get) Token: 0x0600175F RID: 5983 RVA: 0x000692E3 File Offset: 0x000674E3
		public ObservableCollection<CalibHandEyeOutputResultRow> CalibHandEyeOutputResults { get; } = new ObservableCollection<CalibHandEyeOutputResultRow>();

		// Token: 0x17000879 RID: 2169
		// (get) Token: 0x06001760 RID: 5984 RVA: 0x000692EB File Offset: 0x000674EB
		public ObservableCollection<ResultAlignOutputResultRow> ResultAlignOutputResults { get; } = new ObservableCollection<ResultAlignOutputResultRow>();

		// Token: 0x1700087A RID: 2170
		// (get) Token: 0x06001761 RID: 5985 RVA: 0x000692F3 File Offset: 0x000674F3
		public ObservableCollection<ResultInspectionOutputResultRow> ResultInspectionOutputResults { get; } = new ObservableCollection<ResultInspectionOutputResultRow>();

		// Token: 0x1700087B RID: 2171
		// (get) Token: 0x06001762 RID: 5986 RVA: 0x000692FB File Offset: 0x000674FB
		// (set) Token: 0x06001763 RID: 5987 RVA: 0x00069304 File Offset: 0x00067504
		public bool IsBlobOutputVisible
		{
			get
			{
				return this._isBlobOutputVisible;
			}
			set
			{
				bool flag = this._isBlobOutputVisible == value;
				if (!flag)
				{
					this._isBlobOutputVisible = value;
					this.OnFormPropertyChanged("IsBlobOutputVisible");
				}
			}
		}

		// Token: 0x1700087C RID: 2172
		// (get) Token: 0x06001764 RID: 5988 RVA: 0x00069334 File Offset: 0x00067534
		// (set) Token: 0x06001765 RID: 5989 RVA: 0x0006933C File Offset: 0x0006753C
		public bool IsShapeModelOutputVisible
		{
			get
			{
				return this._isShapeModelOutputVisible;
			}
			set
			{
				bool flag = this._isShapeModelOutputVisible == value;
				if (!flag)
				{
					this._isShapeModelOutputVisible = value;
					this.OnFormPropertyChanged("IsShapeModelOutputVisible");
				}
			}
		}

		// Token: 0x1700087D RID: 2173
		// (get) Token: 0x06001766 RID: 5990 RVA: 0x0006936C File Offset: 0x0006756C
		// (set) Token: 0x06001767 RID: 5991 RVA: 0x00069374 File Offset: 0x00067574
		public bool IsFindLineOutputVisible
		{
			get
			{
				return this._isFindLineOutputVisible;
			}
			set
			{
				bool flag = this._isFindLineOutputVisible == value;
				if (!flag)
				{
					this._isFindLineOutputVisible = value;
					this.OnFormPropertyChanged("IsFindLineOutputVisible");
				}
			}
		}

		// Token: 0x1700087E RID: 2174
		// (get) Token: 0x06001768 RID: 5992 RVA: 0x000693A4 File Offset: 0x000675A4
		// (set) Token: 0x06001769 RID: 5993 RVA: 0x000693AC File Offset: 0x000675AC
		public bool IsFindCircleOutputVisible
		{
			get
			{
				return this._isFindCircleOutputVisible;
			}
			set
			{
				bool flag = this._isFindCircleOutputVisible == value;
				if (!flag)
				{
					this._isFindCircleOutputVisible = value;
					this.OnFormPropertyChanged("IsFindCircleOutputVisible");
				}
			}
		}

		// Token: 0x1700087F RID: 2175
		// (get) Token: 0x0600176A RID: 5994 RVA: 0x000693DC File Offset: 0x000675DC
		// (set) Token: 0x0600176B RID: 5995 RVA: 0x000693E4 File Offset: 0x000675E4
		public bool IsFindBoundingBoxOutputVisible
		{
			get
			{
				return this._isFindBoundingBoxOutputVisible;
			}
			set
			{
				bool flag = this._isFindBoundingBoxOutputVisible == value;
				if (!flag)
				{
					this._isFindBoundingBoxOutputVisible = value;
					this.OnFormPropertyChanged("IsFindBoundingBoxOutputVisible");
				}
			}
		}

		// Token: 0x17000880 RID: 2176
		// (get) Token: 0x0600176C RID: 5996 RVA: 0x00069414 File Offset: 0x00067614
		// (set) Token: 0x0600176D RID: 5997 RVA: 0x0006941C File Offset: 0x0006761C
		public bool IsRunAllOutputVisible
		{
			get
			{
				return this._isRunAllOutputVisible;
			}
			set
			{
				bool flag = this._isRunAllOutputVisible == value;
				if (!flag)
				{
					this._isRunAllOutputVisible = value;
					this.OnFormPropertyChanged("IsRunAllOutputVisible");
				}
			}
		}

		// Token: 0x17000881 RID: 2177
		// (get) Token: 0x0600176E RID: 5998 RVA: 0x0006944C File Offset: 0x0006764C
		// (set) Token: 0x0600176F RID: 5999 RVA: 0x00069454 File Offset: 0x00067654
		public bool IsDistanceObjectOutputVisible
		{
			get
			{
				return this._isDistanceObjectOutputVisible;
			}
			set
			{
				bool flag = this._isDistanceObjectOutputVisible == value;
				if (!flag)
				{
					this._isDistanceObjectOutputVisible = value;
					this.OnFormPropertyChanged("IsDistanceObjectOutputVisible");
				}
			}
		}

		// Token: 0x17000882 RID: 2178
		// (get) Token: 0x06001770 RID: 6000 RVA: 0x00069484 File Offset: 0x00067684
		// (set) Token: 0x06001771 RID: 6001 RVA: 0x0006948C File Offset: 0x0006768C
		public bool IsMeasureCircleOutputVisible
		{
			get
			{
				return this._isMeasureCircleOutputVisible;
			}
			set
			{
				bool flag = this._isMeasureCircleOutputVisible == value;
				if (!flag)
				{
					this._isMeasureCircleOutputVisible = value;
					this.OnFormPropertyChanged("IsMeasureCircleOutputVisible");
				}
			}
		}

		// Token: 0x17000883 RID: 2179
		// (get) Token: 0x06001772 RID: 6002 RVA: 0x000694BC File Offset: 0x000676BC
		// (set) Token: 0x06001773 RID: 6003 RVA: 0x000694C4 File Offset: 0x000676C4
		public bool IsDeformableInspectionOutputVisible
		{
			get
			{
				return this._isDeformableInspectionOutputVisible;
			}
			set
			{
				bool flag = this._isDeformableInspectionOutputVisible == value;
				if (!flag)
				{
					this._isDeformableInspectionOutputVisible = value;
					this.OnFormPropertyChanged("IsDeformableInspectionOutputVisible");
				}
			}
		}

		// Token: 0x17000884 RID: 2180
		// (get) Token: 0x06001774 RID: 6004 RVA: 0x000694F4 File Offset: 0x000676F4
		// (set) Token: 0x06001775 RID: 6005 RVA: 0x000694FC File Offset: 0x000676FC
		public bool IsDLObjectInspectionOutputVisible
		{
			get
			{
				return this._isDLObjectInspectionOutputVisible;
			}
			set
			{
				bool flag = this._isDLObjectInspectionOutputVisible == value;
				if (!flag)
				{
					this._isDLObjectInspectionOutputVisible = value;
					this.OnFormPropertyChanged("IsDLObjectInspectionOutputVisible");
				}
			}
		}

		// Token: 0x17000885 RID: 2181
		// (get) Token: 0x06001776 RID: 6006 RVA: 0x0006952C File Offset: 0x0006772C
		// (set) Token: 0x06001777 RID: 6007 RVA: 0x00069534 File Offset: 0x00067734
		public bool IsCalibHandEyeOutputVisible
		{
			get
			{
				return this._isCalibHandEyeOutputVisible;
			}
			set
			{
				bool flag = this._isCalibHandEyeOutputVisible == value;
				if (!flag)
				{
					this._isCalibHandEyeOutputVisible = value;
					this.OnFormPropertyChanged("IsCalibHandEyeOutputVisible");
				}
			}
		}

		// Token: 0x17000886 RID: 2182
		// (get) Token: 0x06001778 RID: 6008 RVA: 0x00069564 File Offset: 0x00067764
		// (set) Token: 0x06001779 RID: 6009 RVA: 0x0006956C File Offset: 0x0006776C
		public bool IsResultAlignOutputVisible
		{
			get
			{
				return this._isResultAlignOutputVisible;
			}
			set
			{
				bool flag = this._isResultAlignOutputVisible == value;
				if (!flag)
				{
					this._isResultAlignOutputVisible = value;
					this.OnFormPropertyChanged("IsResultAlignOutputVisible");
				}
			}
		}

		// Token: 0x17000887 RID: 2183
		// (get) Token: 0x0600177A RID: 6010 RVA: 0x0006959C File Offset: 0x0006779C
		// (set) Token: 0x0600177B RID: 6011 RVA: 0x000695A4 File Offset: 0x000677A4
		public bool IsResultInspectionOutputVisible
		{
			get
			{
				return this._isResultInspectionOutputVisible;
			}
			set
			{
				bool flag = this._isResultInspectionOutputVisible == value;
				if (!flag)
				{
					this._isResultInspectionOutputVisible = value;
					this.OnFormPropertyChanged("IsResultInspectionOutputVisible");
				}
			}
		}

		// Token: 0x17000888 RID: 2184
		// (get) Token: 0x0600177C RID: 6012 RVA: 0x000695D4 File Offset: 0x000677D4
		// (set) Token: 0x0600177D RID: 6013 RVA: 0x000695DC File Offset: 0x000677DC
		public bool IsGridReorderMode { get; set; } = true;

		// Token: 0x17000889 RID: 2185
		// (get) Token: 0x0600177E RID: 6014 RVA: 0x000695E5 File Offset: 0x000677E5
		// (set) Token: 0x0600177F RID: 6015 RVA: 0x000695F0 File Offset: 0x000677F0
		public bool IsDraggingFromTree
		{
			get
			{
				return this._isDraggingFromTree;
			}
			set
			{
				bool flag = this._isDraggingFromTree == value;
				if (!flag)
				{
					this._isDraggingFromTree = value;
					this.OnFormPropertyChanged("IsDraggingFromTree");
				}
			}
		}

		// Token: 0x1700088A RID: 2186
		// (get) Token: 0x06001780 RID: 6016 RVA: 0x00069620 File Offset: 0x00067820
		// (set) Token: 0x06001781 RID: 6017 RVA: 0x00069628 File Offset: 0x00067828
		public bool IsSettingCameraLoading
		{
			get
			{
				return this._isSettingCameraLoading;
			}
			set
			{
				bool flag = this._isSettingCameraLoading == value;
				if (!flag)
				{
					this._isSettingCameraLoading = value;
					this.OnFormPropertyChanged("IsSettingCameraLoading");
				}
			}
		}

		// Token: 0x06001782 RID: 6018 RVA: 0x00069658 File Offset: 0x00067858
		public Form_setting()
		{
			this.InitializeComponent();
			Form_setting.Instance = this;
			this._displayController = new SettingDisplayController(this.Display_setting);
			this._toolSelectionService = new SettingToolSelectionService();
			this._turnSnapService = new SettingTurnSnapService();
			this._roiService = new SettingRoiService(new Func<ToolVision>(this.GetSelectedTool), delegate()
			{
				SettingDisplayController displayController = this._displayController;
				return (displayController != null) ? displayController.GetCurrentImage() : null;
			}, new Action<RoiData, IList<RoiData>>(this.ShowRoiClonePreview));
			this._masterImageService = new SettingMasterImageService();
			this._recipeService = new SettingRecipeService();
			this._shapeModelMatchingService = new SettingShapeModelMatchingService();
			this._toolActionDispatcher = new ToolActionDispatcher();
			this._toolActionContext = new ToolActionContext
			{
				DisplayController = this._displayController,
				RecipeService = this._recipeService,
				ResultReporter = new Action<ToolVision, object>(this.UpdateOutputResult)
			};
			this.LoadCurrentModelRecipe();
			SettingRecipeService.RecipeApplied -= this.SettingRecipeService_RecipeApplied;
			SettingRecipeService.RecipeApplied += this.SettingRecipeService_RecipeApplied;
			base.Dispatcher.BeginInvoke(new Action(this.RestoreImageList), DispatcherPriority.Loaded, Array.Empty<object>());
		}

		// Token: 0x06001783 RID: 6019 RVA: 0x00069860 File Offset: 0x00067A60
		private void SettingRecipeService_RecipeApplied(object sender, EventArgs e)
		{
			bool flag = Form_setting.Instance != this;
			if (!flag)
			{
				bool flag2 = base.Dispatcher.CheckAccess();
				if (flag2)
				{
					this.ReloadForCurrentModel();
				}
				else
				{
					base.Dispatcher.BeginInvoke(new Action(this.ReloadForCurrentModel), Array.Empty<object>());
				}
			}
		}

		// Token: 0x06001784 RID: 6020 RVA: 0x000698B4 File Offset: 0x00067AB4
		public void ReloadForCurrentModel()
		{
			StartupDiag.Log("SETTING ReloadForCurrentModel");
			try
			{
				this._isInitializingToolSelection = true;
				SettingDisplayController displayController = this._displayController;
				if (displayController != null)
				{
					displayController.ClearOverlayRenderer();
				}
				SettingDisplayController displayController2 = this._displayController;
				if (displayController2 != null)
				{
					displayController2.ClearOverlay();
				}
				this.ClearAllOutputResults();
				this.RefreshCameraListBinding();
				this.ResetSettingSelectionToFirstTurnSnap();
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					this.ResetSettingSelectionToFirstTurnSnap();
					this._isInitializingToolSelection = false;
				}), DispatcherPriority.Loaded, Array.Empty<object>());
			}
			catch (Exception ex)
			{
				this._isInitializingToolSelection = false;
				DXMessageBox.Show("Failed to refresh the Setting form for the new model:" + Environment.NewLine + ex.Message);
			}
		}

		// Token: 0x06001785 RID: 6021 RVA: 0x00069968 File Offset: 0x00067B68
		private void ClearAllOutputResults()
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			this.CalibHandEyeOutputResults.Clear();
			this.ResultAlignOutputResults.Clear();
			this.ResultInspectionOutputResults.Clear();
			this.DeformableInspectionOutputResults.Clear();
			this.DLObjectInspectionOutputResults.Clear();
		}

		// Token: 0x06001786 RID: 6022 RVA: 0x00069A7C File Offset: 0x00067C7C
		public void RefreshCameraListBinding()
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			bool flag = vm == null;
			if (!flag)
			{
				base.DataContext = vm;
				this.SettingCameraCombo.ItemsSource = null;
				this.SettingCameraCombo.ItemsSource = vm.Cameras;
				bool flag2 = vm.SelectedCamera == null || !vm.Cameras.Contains(vm.SelectedCamera);
				if (flag2)
				{
					vm.SelectedCamera = vm.Cameras.FirstOrDefault<CameraNode>();
				}
				this.SettingCameraCombo.SelectedItem = vm.SelectedCamera;
				this.SettingCameraCombo.EditValue = vm.SelectedCamera;
			}
		}

		// Token: 0x06001787 RID: 6023 RVA: 0x00069B2C File Offset: 0x00067D2C
		private void HalconSmartWindow_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = e.ChangedButton == MouseButton.Middle || e.ChangedButton == MouseButton.Right;
			if (flag)
			{
				SettingRoiService roiService = this._roiService;
				if (roiService != null)
				{
					roiService.SuspendRoiInteraction(this.Display_setting.HalconWindow);
				}
			}
			else
			{
				bool flag2 = e.ChangedButton == MouseButton.Left && this.IsPointInsertOnClosedContour(e);
				if (flag2)
				{
					SettingRoiService roiService2 = this._roiService;
					if (roiService2 != null)
					{
						roiService2.SuspendRoiInteraction(this.Display_setting.HalconWindow);
					}
				}
			}
		}

		// Token: 0x06001788 RID: 6024 RVA: 0x00069BA8 File Offset: 0x00067DA8
		private bool IsPointInsertOnClosedContour(MouseButtonEventArgs e)
		{
			bool flag = this._roiService == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				double imageRow;
				double imageColumn;
				double tolerance;
				bool flag2 = !this.TryGetImagePoint(e, out imageRow, out imageColumn, out tolerance);
				result = (!flag2 && this._roiService.IsClosedContourAwayFromCorner(imageRow, imageColumn, tolerance));
			}
			return result;
		}

		// Token: 0x06001789 RID: 6025 RVA: 0x00069BF8 File Offset: 0x00067DF8
		private void HalconSmartWindow_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = e.ChangedButton == MouseButton.Left && this.IsMouseOnActiveRoi(e);
			if (flag)
			{
				this._leftPressEditsRoi = true;
			}
			else
			{
				this._displayController.MouseDown(e);
			}
		}

		// Token: 0x0600178A RID: 6026 RVA: 0x00069C34 File Offset: 0x00067E34
		private void HalconSmartWindow_MouseUp(object sender, MouseButtonEventArgs e)
		{
			SettingRoiService roiService = this._roiService;
			if (roiService != null)
			{
				roiService.ResumeRoiInteraction(this.Display_setting.HalconWindow);
			}
			bool flag = this._leftPressEditsRoi && e.ChangedButton == MouseButton.Left;
			if (flag)
			{
				this._leftPressEditsRoi = false;
			}
			else
			{
				this._displayController.MouseUp(e);
				bool flag2 = !this._displayController.LastMouseActionWasClick;
				if (!flag2)
				{
					bool flag3 = e.ChangedButton == MouseButton.Left && this.SelectShownRoiFromHWindow(e);
					if (!flag3)
					{
						this.SelectFindBoundingBoxOutputRowFromHWindow(e);
					}
				}
			}
		}

		// Token: 0x0600178B RID: 6027 RVA: 0x00069CC4 File Offset: 0x00067EC4
		private bool SelectShownRoiFromHWindow(MouseButtonEventArgs e)
		{
			bool flag = this._showAllRoiPanels.Count == 0 || this._roiService == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				double imageRow;
				double imageColumn;
				double num;
				bool flag2 = !this.TryGetImagePoint(e, out imageRow, out imageColumn, out num);
				result = (!flag2 && this._roiService.SelectRoiAtPoint(this._showAllRoiPanels.ToList<RoiPanelType>(), imageRow, imageColumn, this.Display_setting.HalconWindow));
			}
			return result;
		}

		// Token: 0x0600178C RID: 6028 RVA: 0x00069D34 File Offset: 0x00067F34
		private bool IsMouseOnActiveRoi(MouseEventArgs e)
		{
			bool flag = this._roiService == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				double imageRow;
				double imageColumn;
				double tolerance;
				bool flag2 = !this.TryGetImagePoint(e, out imageRow, out imageColumn, out tolerance);
				result = (!flag2 && this._roiService.HitTestActiveRoi(imageRow, imageColumn, tolerance));
			}
			return result;
		}

		// Token: 0x0600178D RID: 6029 RVA: 0x00069D84 File Offset: 0x00067F84
		private bool TryGetImagePoint(MouseEventArgs e, out double imageRow, out double imageColumn, out double tolerance)
		{
			imageRow = 0.0;
			imageColumn = 0.0;
			tolerance = 0.0;
			bool result;
			try
			{
				HSmartWindowControlWPF display_setting = this.Display_setting;
				HWindow window = (display_setting != null) ? display_setting.HalconWindow : null;
				bool flag = window == null;
				if (flag)
				{
					result = false;
				}
				else
				{
					double controlWidth = this.Display_setting.ActualWidth;
					double controlHeight = this.Display_setting.ActualHeight;
					bool flag2 = controlWidth <= 0.0 || controlHeight <= 0.0;
					if (flag2)
					{
						result = false;
					}
					else
					{
						HTuple row;
						HTuple col;
						HTuple row2;
						HTuple col2;
						window.GetPart(out row, out col, out row2, out col2);
						double partWidth = col2.D - col.D + 1.0;
						double partHeight = row2.D - row.D + 1.0;
						bool flag3 = partWidth <= 0.0 || partHeight <= 0.0;
						if (flag3)
						{
							result = false;
						}
						else
						{
							Point pos = e.GetPosition(this.Display_setting);
							imageRow = row.D + pos.Y * partHeight / controlHeight;
							imageColumn = col.D + pos.X * partWidth / controlWidth;
							tolerance = 14.0 * Math.Max(partWidth / controlWidth, partHeight / controlHeight);
							result = true;
						}
					}
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600178E RID: 6030 RVA: 0x00069F0C File Offset: 0x0006810C
		private void HalconSmartWindow_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
		{
			SettingRoiService roiService = this._roiService;
			if (roiService != null)
			{
				roiService.ResumeRoiInteraction(this.Display_setting.HalconWindow);
			}
			bool flag = this.Display_setting.ContextMenu == null;
			if (!flag)
			{
				this.Display_setting.ContextMenu.PlacementTarget = this.Display_setting;
				this.Display_setting.ContextMenu.IsOpen = true;
				e.Handled = true;
			}
		}

		// Token: 0x0600178F RID: 6031 RVA: 0x00069F7C File Offset: 0x0006817C
		private void HalconSmartWindow_MouseMove(object sender, MouseEventArgs e)
		{
			this._displayController.MouseMove(e);
			bool flag = e.MiddleButton == MouseButtonState.Released && e.RightButton == MouseButtonState.Released && e.LeftButton == MouseButtonState.Released;
			if (flag)
			{
				SettingRoiService roiService = this._roiService;
				if (roiService != null)
				{
					roiService.ResumeRoiInteraction(this.Display_setting.HalconWindow);
				}
			}
			bool flag2 = e.LeftButton == MouseButtonState.Pressed || e.MiddleButton == MouseButtonState.Pressed || e.RightButton == MouseButtonState.Pressed;
			if (!flag2)
			{
				this.UpdatePixelInspector(e);
			}
		}

		// Token: 0x06001790 RID: 6032 RVA: 0x0006A003 File Offset: 0x00068203
		private void HalconSmartWindow_MouseWheel(object sender, MouseWheelEventArgs e)
		{
			this._displayController.MouseWheel(e);
		}

		// Token: 0x06001791 RID: 6033 RVA: 0x0006A013 File Offset: 0x00068213
		private void HalconSmartWindow_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			this._displayController.MouseDoubleClick(e);
		}

		// Token: 0x06001792 RID: 6034 RVA: 0x0006A023 File Offset: 0x00068223
		private void HalconSmartWindow_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			this._displayController.RedrawAfterLayoutChanged();
		}

		// Token: 0x06001793 RID: 6035 RVA: 0x0006A034 File Offset: 0x00068234
		private void HalconSmartWindow_Initialized(object sender, EventArgs e)
		{
			HSmartWindowControlWPF smartWindow = (sender as HSmartWindowControlWPF) ?? this.Display_setting;
			bool flag = smartWindow != null;
			if (flag)
			{
				smartWindow.HMoveContent = false;
				smartWindow.HZoomContent = HSmartWindowControlWPF.ZoomContent.Off;
				smartWindow.HDoubleClickToFitContent = false;
			}
		}

		// Token: 0x06001794 RID: 6036 RVA: 0x0006A078 File Offset: 0x00068278
		private void ToolButton_Click(object sender, RoutedEventArgs e)
		{
			Button button = sender as Button;
			bool flag = button == null;
			if (!flag)
			{
				ToolVision tool = button.Tag as ToolVision;
				bool flag2 = tool == null;
				if (!flag2)
				{
					this.OpenToolConfig(tool);
				}
			}
		}

		// Token: 0x06001795 RID: 6037 RVA: 0x0006A0BC File Offset: 0x000682BC
		private void DeleteTool_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement element = sender as FrameworkElement;
			bool flag = element == null;
			if (!flag)
			{
				ToolVision tool = element.Tag as ToolVision;
				bool flag2 = tool == null;
				if (!flag2)
				{
					TurnSnap turnSnap = tool.ParentTurnSnap;
					this._turnSnapService.DeleteTool(tool);
					base.Dispatcher.BeginInvoke(new Action(delegate()
					{
						for (DependencyObject parent = element; parent != null; parent = VisualTreeHelper.GetParent(parent))
						{
							GridControl grid = parent as GridControl;
							bool flag3 = grid != null;
							if (flag3)
							{
								this.RefreshToolGridHeight(grid);
								break;
							}
						}
					}), DispatcherPriority.Loaded, Array.Empty<object>());
				}
			}
		}

		// Token: 0x06001796 RID: 6038 RVA: 0x0006A148 File Offset: 0x00068348
		private void toolTreeView_PreviewMouseMove(object sender, MouseEventArgs e)
		{
			bool flag = e.LeftButton != MouseButtonState.Pressed;
			if (!flag)
			{
				ToolVision tool = null;
				ToolVision selectedTool = this.toolTreeView.SelectedItem as ToolVision;
				bool flag2 = selectedTool != null;
				if (flag2)
				{
					tool = selectedTool;
				}
				else
				{
					ToolVision currentTool = this.toolTreeView.CurrentItem as ToolVision;
					bool flag3 = currentTool != null;
					if (flag3)
					{
						tool = currentTool;
					}
				}
				bool flag4 = tool == null;
				if (!flag4)
				{
					bool flag5 = tool.Children != null && tool.Children.Count > 0;
					if (!flag5)
					{
						DataObject data = new DataObject();
						data.SetData("ToolVision", tool);
						data.SetData(typeof(ToolVision), tool);
						try
						{
							this.IsDraggingFromTree = true;
							DragDrop.DoDragDrop(this.toolTreeView, data, DragDropEffects.Copy);
						}
						finally
						{
							this.IsDraggingFromTree = false;
						}
					}
				}
			}
		}

		// Token: 0x06001797 RID: 6039 RVA: 0x0006A234 File Offset: 0x00068434
		private void TurnSnap_DragOver(object sender, DragEventArgs e)
		{
			bool flag = !e.Data.GetDataPresent("ToolVision");
			if (flag)
			{
				e.Effects = DragDropEffects.None;
				e.Handled = true;
			}
			else
			{
				e.Effects = DragDropEffects.Copy;
				e.Handled = true;
			}
		}

		// Token: 0x06001798 RID: 6040 RVA: 0x0006A27C File Offset: 0x0006847C
		private void TurnSnap_Drop(object sender, DragEventArgs e)
		{
			ToolVision draggedTool = null;
			bool dataPresent = e.Data.GetDataPresent("ToolVision");
			if (dataPresent)
			{
				draggedTool = (e.Data.GetData("ToolVision") as ToolVision);
			}
			bool flag = draggedTool == null && e.Data.GetDataPresent(typeof(ToolVision));
			if (flag)
			{
				draggedTool = (e.Data.GetData(typeof(ToolVision)) as ToolVision);
			}
			bool flag2 = draggedTool == null;
			if (!flag2)
			{
				bool flag3 = draggedTool.Children != null && draggedTool.Children.Count > 0;
				if (flag3)
				{
					e.Effects = DragDropEffects.None;
					e.Handled = true;
				}
				else
				{
					Border border = sender as Border;
					bool flag4 = border == null;
					if (!flag4)
					{
						TurnSnap turnSnap = border.DataContext as TurnSnap;
						bool flag5 = turnSnap == null;
						if (!flag5)
						{
							this._turnSnapService.AddToolToTurnSnap(draggedTool, turnSnap);
							base.Dispatcher.BeginInvoke(new Action(delegate()
							{
								this.RefreshToolGridHeight(border);
							}), DispatcherPriority.Loaded, Array.Empty<object>());
							e.Handled = true;
						}
					}
				}
			}
		}

		// Token: 0x06001799 RID: 6041 RVA: 0x0006A3B4 File Offset: 0x000685B4
		private void DeleteTurnSnap_Click(object sender, RoutedEventArgs e)
		{
			Button button = sender as Button;
			TurnSnap turnSnap;
			bool flag;
			if (button != null)
			{
				turnSnap = (button.Tag as TurnSnap);
				flag = (turnSnap != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				this._turnSnapService.DeleteTurnSnap(turnSnap);
			}
		}

		// Token: 0x0600179A RID: 6042 RVA: 0x0006A3F0 File Offset: 0x000685F0
		private void MoveTurnSnapUp_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement fe = sender as FrameworkElement;
			TurnSnap turnSnap;
			bool flag;
			if (fe != null)
			{
				turnSnap = (fe.Tag as TurnSnap);
				flag = (turnSnap == null);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (!flag2)
			{
				MainWindow instance = MainWindow.instance;
				ObservableCollection<TurnSnap> observableCollection;
				if (instance == null)
				{
					observableCollection = null;
				}
				else
				{
					MainViewModel mainViewModel = instance.MainViewModel;
					if (mainViewModel == null)
					{
						observableCollection = null;
					}
					else
					{
						CameraNode selectedCamera = mainViewModel.SelectedCamera;
						observableCollection = ((selectedCamera != null) ? selectedCamera.TurnSnaps : null);
					}
				}
				ObservableCollection<TurnSnap> turnSnaps = observableCollection;
				bool flag3 = turnSnaps == null;
				if (!flag3)
				{
					int index = turnSnaps.IndexOf(turnSnap);
					this._turnSnapService.MoveTurnSnap(turnSnap, index - 1);
					this.SaveAllConfigSilently();
				}
			}
		}

		// Token: 0x0600179B RID: 6043 RVA: 0x0006A47C File Offset: 0x0006867C
		private void MoveTurnSnapDown_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement fe = sender as FrameworkElement;
			TurnSnap turnSnap;
			bool flag;
			if (fe != null)
			{
				turnSnap = (fe.Tag as TurnSnap);
				flag = (turnSnap == null);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (!flag2)
			{
				MainWindow instance = MainWindow.instance;
				ObservableCollection<TurnSnap> observableCollection;
				if (instance == null)
				{
					observableCollection = null;
				}
				else
				{
					MainViewModel mainViewModel = instance.MainViewModel;
					if (mainViewModel == null)
					{
						observableCollection = null;
					}
					else
					{
						CameraNode selectedCamera = mainViewModel.SelectedCamera;
						observableCollection = ((selectedCamera != null) ? selectedCamera.TurnSnaps : null);
					}
				}
				ObservableCollection<TurnSnap> turnSnaps = observableCollection;
				bool flag3 = turnSnaps == null;
				if (!flag3)
				{
					int index = turnSnaps.IndexOf(turnSnap);
					this._turnSnapService.MoveTurnSnap(turnSnap, index + 1);
					this.SaveAllConfigSilently();
				}
			}
		}

		// Token: 0x0600179C RID: 6044 RVA: 0x0006A508 File Offset: 0x00068708
		private void SaveAllConfigSilently()
		{
			try
			{
				this._recipeService.SaveCurrentModelRecipe(false);
			}
			catch
			{
			}
		}

		// Token: 0x0600179D RID: 6045 RVA: 0x0006A53C File Offset: 0x0006873C
		private void TurnSnapButton_Click(object sender, RoutedEventArgs e)
		{
			Button button = sender as Button;
			TurnSnap selectedTurnSnap;
			bool flag;
			if (button != null)
			{
				selectedTurnSnap = (button.Tag as TurnSnap);
				flag = (selectedTurnSnap != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				this._turnSnapService.SelectTurnSnap(selectedTurnSnap);
				this.LoadMasterImageForTurnSnap(selectedTurnSnap);
			}
		}

		// Token: 0x0600179E RID: 6046 RVA: 0x0006A582 File Offset: 0x00068782
		private void AddTurnSnapFromTool_Click(object sender, RoutedEventArgs e)
		{
			this._turnSnapService.AddTurnSnap();
		}

		// Token: 0x0600179F RID: 6047 RVA: 0x0006A591 File Offset: 0x00068791
		private void RunAll_Click(object sender, RoutedEventArgs e)
		{
			this.RunSelectedTurnSnap();
		}

		// Token: 0x060017A0 RID: 6048 RVA: 0x0006A59C File Offset: 0x0006879C
		[DebuggerStepThrough]
		private void SettingCamera_PopupClosed(object sender, ClosePopupEventArgs e)
		{
			Form_setting.<SettingCamera_PopupClosed>d__161 <SettingCamera_PopupClosed>d__ = new Form_setting.<SettingCamera_PopupClosed>d__161();
			<SettingCamera_PopupClosed>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<SettingCamera_PopupClosed>d__.<>4__this = this;
			<SettingCamera_PopupClosed>d__.sender = sender;
			<SettingCamera_PopupClosed>d__.e = e;
			<SettingCamera_PopupClosed>d__.<>1__state = -1;
			<SettingCamera_PopupClosed>d__.<>t__builder.Start<Form_setting.<SettingCamera_PopupClosed>d__161>(ref <SettingCamera_PopupClosed>d__);
		}

		// Token: 0x060017A1 RID: 6049 RVA: 0x0006A5E4 File Offset: 0x000687E4
		[DebuggerStepThrough]
		private Task ReloadSelectedCameraWithWaitAsync()
		{
			Form_setting.<ReloadSelectedCameraWithWaitAsync>d__162 <ReloadSelectedCameraWithWaitAsync>d__ = new Form_setting.<ReloadSelectedCameraWithWaitAsync>d__162();
			<ReloadSelectedCameraWithWaitAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ReloadSelectedCameraWithWaitAsync>d__.<>4__this = this;
			<ReloadSelectedCameraWithWaitAsync>d__.<>1__state = -1;
			<ReloadSelectedCameraWithWaitAsync>d__.<>t__builder.Start<Form_setting.<ReloadSelectedCameraWithWaitAsync>d__162>(ref <ReloadSelectedCameraWithWaitAsync>d__);
			return <ReloadSelectedCameraWithWaitAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060017A2 RID: 6050 RVA: 0x0006A628 File Offset: 0x00068828
		private void ShowSettingCameraWaitWindow()
		{
			bool flag = this._settingCameraWaitWindow != null;
			if (!flag)
			{
				StackPanel panel = new StackPanel
				{
					Margin = new Thickness(18.0),
					VerticalAlignment = VerticalAlignment.Center
				};
				panel.Children.Add(new TextBlock
				{
					Text = "Loading camera data...",
					Foreground = Brushes.White,
					FontSize = 16.0,
					FontWeight = FontWeights.SemiBold,
					HorizontalAlignment = HorizontalAlignment.Center,
					Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
				});
				panel.Children.Add(new ProgressBar
				{
					IsIndeterminate = true,
					Height = 12.0
				});
				this._settingCameraWaitWindow = new Window
				{
					Owner = this,
					Width = 300.0,
					Height = 130.0,
					WindowStartupLocation = WindowStartupLocation.CenterOwner,
					WindowStyle = WindowStyle.None,
					ResizeMode = ResizeMode.NoResize,
					ShowInTaskbar = false,
					AllowsTransparency = true,
					Background = Brushes.Transparent,
					Content = new Border
					{
						CornerRadius = new CornerRadius(6.0),
						Background = new SolidColorBrush(Color.FromRgb(31, 42, 56)),
						BorderBrush = new SolidColorBrush(Color.FromRgb(61, 110, 168)),
						BorderThickness = new Thickness(1.0),
						Child = panel
					}
				};
				this._settingCameraWaitWindow.Show();
				this._settingCameraWaitWindow.Activate();
			}
		}

		// Token: 0x060017A3 RID: 6051 RVA: 0x0006A800 File Offset: 0x00068A00
		private void CloseSettingCameraWaitWindow()
		{
			try
			{
				Window settingCameraWaitWindow = this._settingCameraWaitWindow;
				if (settingCameraWaitWindow != null)
				{
					settingCameraWaitWindow.Close();
				}
			}
			catch
			{
			}
			finally
			{
				this._settingCameraWaitWindow = null;
			}
		}

		// Token: 0x060017A4 RID: 6052 RVA: 0x0006A854 File Offset: 0x00068A54
		[DebuggerStepThrough]
		private void SnapImage_Click(object sender, RoutedEventArgs e)
		{
			Form_setting.<SnapImage_Click>d__165 <SnapImage_Click>d__ = new Form_setting.<SnapImage_Click>d__165();
			<SnapImage_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<SnapImage_Click>d__.<>4__this = this;
			<SnapImage_Click>d__.sender = sender;
			<SnapImage_Click>d__.e = e;
			<SnapImage_Click>d__.<>1__state = -1;
			<SnapImage_Click>d__.<>t__builder.Start<Form_setting.<SnapImage_Click>d__165>(ref <SnapImage_Click>d__);
		}

		// Token: 0x060017A5 RID: 6053 RVA: 0x0006A89C File Offset: 0x00068A9C
		private void ShowSnapOutputResult(string cameraName, int width, int height, double acquisitionTimeMs)
		{
			this.ShowRunAllOutputResult();
			this.RunAllOutputResults.Add(new RunAllOutputResultRow
			{
				ToolName = "Snap",
				Result = string.Format("Width={0}, Height={1}", width, height),
				Status = "OK",
				ProcessingTimeMs = acquisitionTimeMs,
				TurnSnapProcessingTimeMs = acquisitionTimeMs,
				InputSourceToolName = this.NormalizeDisplayValue(cameraName),
				MasterPositionToolName = "None",
				MasterAngleToolName = "None"
			});
			this.OnFormPropertyChanged("RunAllOutputResults");
		}

		// Token: 0x060017A6 RID: 6054 RVA: 0x0006A93C File Offset: 0x00068B3C
		private void Open_image(object sender, RoutedEventArgs e)
		{
			try
			{
				OpenFileDialog dialog = new OpenFileDialog
				{
					Filter = "Image Files (*.jpg;*.jpeg;*.png;*.gif;*.bmp;*.tif;*.tiff)|*.jpg;*.jpeg;*.png;*.gif;*.bmp;*.tif;*.tiff|All files (*.*)|*.*",
					Title = "Select an Image File"
				};
				bool flag = !dialog.ShowDialog().GetValueOrDefault();
				if (!flag)
				{
					LoadingOverlay.RunOnUi(this, "Opening image...", delegate
					{
						this._displayController.LoadImage(dialog.FileName);
					});
				}
			}
			catch (Exception ex)
			{
				DXMessageBox.Show(ex.Message);
			}
		}

		// Token: 0x060017A7 RID: 6055 RVA: 0x0006A9D4 File Offset: 0x00068BD4
		private void BrowseImageFolder_Click(object sender, RoutedEventArgs e)
		{
			string folder = FolderPickerService.PickFolder("Select the folder that contains the images", this._imageListFolder, Form_setting.GetOwnerHandle());
			bool flag = string.IsNullOrWhiteSpace(folder);
			if (!flag)
			{
				this.LoadImageFolder(folder);
			}
		}

		// Token: 0x060017A8 RID: 6056 RVA: 0x0006AA0C File Offset: 0x00068C0C
		private static IntPtr GetOwnerHandle()
		{
			IntPtr result;
			try
			{
				MainWindow main = MainWindow.instance;
				bool flag = main == null;
				if (flag)
				{
					result = IntPtr.Zero;
				}
				else
				{
					result = new WindowInteropHelper(main).Handle;
				}
			}
			catch (Exception)
			{
				result = IntPtr.Zero;
			}
			return result;
		}

		// Token: 0x060017A9 RID: 6057 RVA: 0x0006AA5C File Offset: 0x00068C5C
		private void RestoreImageList()
		{
			bool imageListRestored = this._imageListRestored;
			if (!imageListRestored)
			{
				this._imageListRestored = true;
				ListImageSetting setting = ListImageSettingStorageService.Load();
				bool flag = setting == null || string.IsNullOrWhiteSpace(setting.Folder) || !Directory.Exists(setting.Folder);
				if (!flag)
				{
					this.LoadImageFolder(setting.Folder, setting.SelectedFileName, false, false);
				}
			}
		}

		// Token: 0x060017AA RID: 6058 RVA: 0x0006AAC0 File Offset: 0x00068CC0
		private void LoadImageFolder(string folder)
		{
			this.LoadImageFolder(folder, null, true, true);
		}

		// Token: 0x060017AB RID: 6059 RVA: 0x0006AAD0 File Offset: 0x00068CD0
		private void LoadImageFolder(string folder, string selectFileName, bool showEmptyWarning, bool loadSelectedImage)
		{
			try
			{
				this._isUpdatingImageList = true;
				this._allImageItems.Clear();
				this._imageListItems.Clear();
				this._imagePages.Clear();
				this._currentImagePage = 0;
				bool flag = this.ImageFileList != null;
				if (flag)
				{
					this.ImageFileList.ItemsSource = this._imageListItems;
				}
				bool flag2 = this.ImagePageTabs != null;
				if (flag2)
				{
					this.ImagePageTabs.ItemsSource = this._imagePages;
					this.ImagePageTabs.Visibility = Visibility.Collapsed;
				}
				bool flag3 = !Directory.Exists(folder);
				if (flag3)
				{
					DXMessageBox.Show("The selected folder no longer exists.");
					return;
				}
				List<string> files = (from x in Directory.GetFiles(folder)
				where Form_setting.ImageListExtensions.Contains(Path.GetExtension(x), StringComparer.OrdinalIgnoreCase)
				select x).OrderBy((string x) => Path.GetFileName(x), StringComparer.OrdinalIgnoreCase).ToList<string>();
				for (int i = 0; i < files.Count; i++)
				{
					this._allImageItems.Add(new Form_setting.ImageListItem
					{
						Index = i + 1,
						FileName = Path.GetFileName(files[i]),
						FullPath = files[i]
					});
				}
				this.BuildImagePages();
				this._imageListFolder = folder;
				bool flag4 = this.ImageFolderText != null;
				if (flag4)
				{
					this.ImageFolderText.Text = folder;
				}
			}
			finally
			{
				this._isUpdatingImageList = false;
			}
			this.SaveImageListSetting();
			bool flag5 = this._allImageItems.Count == 0;
			if (flag5)
			{
				this.UpdateImageListInfo();
				if (showEmptyWarning)
				{
					DXMessageBox.Show("No image file was found in that folder.");
				}
			}
			else
			{
				int target = 0;
				bool flag6 = !string.IsNullOrWhiteSpace(selectFileName);
				if (flag6)
				{
					for (int j = 0; j < this._allImageItems.Count; j++)
					{
						bool flag7 = string.Equals(this._allImageItems[j].FileName, selectFileName, StringComparison.OrdinalIgnoreCase);
						if (flag7)
						{
							target = j;
							break;
						}
					}
				}
				this.ShowImagePage(target / 100, target, loadSelectedImage);
			}
		}

		// Token: 0x060017AC RID: 6060 RVA: 0x0006AD28 File Offset: 0x00068F28
		private void BuildImagePages()
		{
			this._imagePages.Clear();
			bool flag = this._allImageItems.Count == 0;
			if (!flag)
			{
				int pageCount = (this._allImageItems.Count + 100 - 1) / 100;
				for (int page = 0; page < pageCount; page++)
				{
					int first = page * 100;
					int last = Math.Min(first + 100, this._allImageItems.Count) - 1;
					this._imagePages.Add(new Form_setting.ImagePageItem
					{
						PageIndex = page,
						FirstIndex = this._allImageItems[first].Index,
						LastIndex = this._allImageItems[last].Index
					});
				}
				bool flag2 = this.ImagePageTabs == null;
				if (!flag2)
				{
					this.ImagePageTabs.Visibility = ((pageCount > 1) ? Visibility.Visible : Visibility.Collapsed);
				}
			}
		}

		// Token: 0x060017AD RID: 6061 RVA: 0x0006AE10 File Offset: 0x00069010
		private void ShowImagePage(int pageIndex, int selectGlobalIndex, bool loadSelectedImage)
		{
			bool flag = this._allImageItems.Count == 0;
			if (!flag)
			{
				bool flag2 = pageIndex < 0;
				if (flag2)
				{
					pageIndex = 0;
				}
				bool flag3 = pageIndex >= this._imagePages.Count;
				if (flag3)
				{
					pageIndex = this._imagePages.Count - 1;
				}
				int first = pageIndex * 100;
				int count = Math.Min(100, this._allImageItems.Count - first);
				try
				{
					this._isUpdatingImageList = true;
					this._currentImagePage = pageIndex;
					this._imageListItems.Clear();
					for (int i = 0; i < count; i++)
					{
						this._imageListItems.Add(this._allImageItems[first + i]);
					}
					bool flag4 = this.ImagePageTabs != null && pageIndex < this._imagePages.Count;
					if (flag4)
					{
						this.ImagePageTabs.SelectedIndex = pageIndex;
					}
				}
				finally
				{
					this._isUpdatingImageList = false;
				}
				bool flag5 = this.ImageFileList == null;
				if (!flag5)
				{
					int rowIndex = selectGlobalIndex - first;
					bool flag6 = selectGlobalIndex < 0 || rowIndex < 0 || rowIndex >= this._imageListItems.Count;
					if (flag6)
					{
						this.UpdateImageListInfo();
					}
					else if (loadSelectedImage)
					{
						this.ImageFileList.SelectedIndex = rowIndex;
						this.ImageFileList.ScrollIntoView(this.ImageFileList.SelectedItem);
					}
					else
					{
						try
						{
							this._isUpdatingImageList = true;
							this.ImageFileList.SelectedIndex = rowIndex;
							this.ImageFileList.ScrollIntoView(this.ImageFileList.SelectedItem);
						}
						finally
						{
							this._isUpdatingImageList = false;
						}
						this.UpdateImageListInfo();
					}
				}
			}
		}

		// Token: 0x060017AE RID: 6062 RVA: 0x0006AFD8 File Offset: 0x000691D8
		private void ImagePageTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			bool flag = this._isUpdatingImageList || this.ImagePageTabs == null;
			if (!flag)
			{
				Form_setting.ImagePageItem page = this.ImagePageTabs.SelectedItem as Form_setting.ImagePageItem;
				bool flag2 = page == null || page.PageIndex == this._currentImagePage;
				if (!flag2)
				{
					this.ShowImagePage(page.PageIndex, -1, false);
				}
			}
		}

		// Token: 0x060017AF RID: 6063 RVA: 0x0006B03C File Offset: 0x0006923C
		private void SaveImageListSetting()
		{
			bool flag = string.IsNullOrWhiteSpace(this._imageListFolder);
			if (!flag)
			{
				ListBox imageFileList = this.ImageFileList;
				Form_setting.ImageListItem item = ((imageFileList != null) ? imageFileList.SelectedItem : null) as Form_setting.ImageListItem;
				ListImageSettingStorageService.Save(this._imageListFolder, (item != null) ? item.FileName : null);
			}
		}

		// Token: 0x060017B0 RID: 6064 RVA: 0x0006B08C File Offset: 0x0006928C
		private void ImageFileList_ContextMenuOpening(object sender, ContextMenuEventArgs e)
		{
			this._contextImageItem = Form_setting.FindImageItem(e.OriginalSource as DependencyObject);
			bool flag = this._contextImageItem == null;
			if (flag)
			{
				e.Handled = true;
			}
		}

		// Token: 0x060017B1 RID: 6065 RVA: 0x0006B0C8 File Offset: 0x000692C8
		private void CopyImagePath_Click(object sender, RoutedEventArgs e)
		{
			Form_setting.ImageListItem item = this._contextImageItem;
			bool flag = item == null || string.IsNullOrWhiteSpace(item.FullPath);
			if (!flag)
			{
				try
				{
					Clipboard.SetText(item.FullPath);
				}
				catch (Exception ex)
				{
					DXMessageBox.Show("The path could not be copied: " + ex.Message);
				}
			}
		}

		// Token: 0x060017B2 RID: 6066 RVA: 0x0006B130 File Offset: 0x00069330
		private static Form_setting.ImageListItem FindImageItem(DependencyObject source)
		{
			while (source != null)
			{
				ListBoxItem container = source as ListBoxItem;
				bool flag = container != null;
				if (flag)
				{
					return container.DataContext as Form_setting.ImageListItem;
				}
				source = ((source is Visual || source is Visual3D) ? VisualTreeHelper.GetParent(source) : LogicalTreeHelper.GetParent(source));
			}
			return null;
		}

		// Token: 0x060017B3 RID: 6067 RVA: 0x0006B18C File Offset: 0x0006938C
		private void ImageFileList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			bool isUpdatingImageList = this._isUpdatingImageList;
			if (!isUpdatingImageList)
			{
				this.LoadSelectedImage();
			}
		}

		// Token: 0x060017B4 RID: 6068 RVA: 0x0006B1AD File Offset: 0x000693AD
		private void PreviousImage_Click(object sender, RoutedEventArgs e)
		{
			this.StepImage(-1);
		}

		// Token: 0x060017B5 RID: 6069 RVA: 0x0006B1B8 File Offset: 0x000693B8
		private void NextImage_Click(object sender, RoutedEventArgs e)
		{
			this.StepImage(1);
		}

		// Token: 0x060017B6 RID: 6070 RVA: 0x0006B1C4 File Offset: 0x000693C4
		private void StepImage(int direction)
		{
			bool flag = this.ImageFileList == null || this._allImageItems.Count == 0;
			if (!flag)
			{
				Form_setting.ImageListItem current = this.ImageFileList.SelectedItem as Form_setting.ImageListItem;
				int globalIndex = (current != null) ? (current.Index - 1) : (this._currentImagePage * 100 + ((direction > 0) ? -1 : 0));
				int target = globalIndex + direction;
				bool flag2 = target < 0 || target >= this._allImageItems.Count;
				if (!flag2)
				{
					bool flag3 = target / 100 != this._currentImagePage;
					if (flag3)
					{
						this.ShowImagePage(target / 100, target, true);
					}
					else
					{
						this.ImageFileList.SelectedIndex = target - this._currentImagePage * 100;
						this.ImageFileList.ScrollIntoView(this.ImageFileList.SelectedItem);
					}
				}
			}
		}

		// Token: 0x060017B7 RID: 6071 RVA: 0x0006B29C File Offset: 0x0006949C
		private void LoadSelectedImage()
		{
			Form_setting.<>c__DisplayClass196_0 CS$<>8__locals1 = new Form_setting.<>c__DisplayClass196_0();
			CS$<>8__locals1.<>4__this = this;
			Form_setting.<>c__DisplayClass196_0 CS$<>8__locals2 = CS$<>8__locals1;
			ListBox imageFileList = this.ImageFileList;
			CS$<>8__locals2.item = (((imageFileList != null) ? imageFileList.SelectedItem : null) as Form_setting.ImageListItem);
			this.UpdateImageListInfo();
			this.SaveImageListSetting();
			bool flag = CS$<>8__locals1.item == null || !File.Exists(CS$<>8__locals1.item.FullPath);
			if (!flag)
			{
				try
				{
					LoadingOverlay.RunOnUi(this, "Opening image...", delegate
					{
						CS$<>8__locals1.<>4__this._displayController.LoadImage(CS$<>8__locals1.item.FullPath);
					});
				}
				catch (Exception ex)
				{
					DXMessageBox.Show("Failed to open the image:" + Environment.NewLine + ex.Message);
				}
			}
		}

		// Token: 0x060017B8 RID: 6072 RVA: 0x0006B354 File Offset: 0x00069554
		private void UpdateImageListInfo()
		{
			bool flag = this.ImageNameText == null || this.ImageCountText == null;
			if (!flag)
			{
				ListBox imageFileList = this.ImageFileList;
				Form_setting.ImageListItem item = ((imageFileList != null) ? imageFileList.SelectedItem : null) as Form_setting.ImageListItem;
				int total = this._allImageItems.Count;
				bool flag2 = item == null;
				if (flag2)
				{
					this.ImageNameText.Text = ((total > 0) ? "No image selected" : "-");
					this.ImageCountText.Text = "0 / " + total.ToString();
				}
				else
				{
					this.ImageNameText.Text = item.FileName;
					this.ImageCountText.Text = item.Index.ToString() + " / " + total.ToString();
				}
			}
		}

		// Token: 0x060017B9 RID: 6073 RVA: 0x0006B428 File Offset: 0x00069628
		private void SaveMasterImage_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				TurnSnap turnSnap = this._turnSnapService.GetSelectedTurnSnap();
				string savePath = this._masterImageService.GetMasterImagePath(turnSnap);
				bool flag = string.IsNullOrWhiteSpace(savePath);
				if (!flag)
				{
					this.SaveImageWithWaitOverlay(savePath, "Saving master image...");
					DXMessageBox.Show("Master image saved:\n" + savePath);
				}
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Failed to save master image:\n" + ex.Message);
			}
		}

		// Token: 0x060017BA RID: 6074 RVA: 0x0006B4A8 File Offset: 0x000696A8
		private void ZoomToFit_Click(object sender, RoutedEventArgs e)
		{
			SettingDisplayController displayController = this._displayController;
			if (displayController != null)
			{
				displayController.ZoomToFit();
			}
		}

		// Token: 0x060017BB RID: 6075 RVA: 0x0006B4C0 File Offset: 0x000696C0
		private void SaveDisplayedImageAs_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				SaveFileDialog dialog = new SaveFileDialog
				{
					Title = "Save Displayed Image",
					Filter = "PNG Image (*.png)|*.png|Bitmap Image (*.bmp)|*.bmp|JPEG Image (*.jpg)|*.jpg|TIFF Image (*.tif)|*.tif",
					DefaultExt = ".png",
					FileName = "setting_image_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png",
					AddExtension = true,
					OverwritePrompt = true
				};
				bool flag = !dialog.ShowDialog().GetValueOrDefault();
				if (!flag)
				{
					this.SaveImageWithWaitOverlay(dialog.FileName, "Saving image...");
					DXMessageBox.Show("Image saved:\n" + dialog.FileName);
				}
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Failed to save displayed image:\n" + ex.Message);
			}
		}

		// Token: 0x060017BC RID: 6076 RVA: 0x0006B5A0 File Offset: 0x000697A0
		private void HideDisplayedRoi_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				SettingRoiService roiService = this._roiService;
				HSmartWindowControlWPF display_setting = this.Display_setting;
				roiService.HideActiveRoi((display_setting != null) ? display_setting.HalconWindow : null);
				this._displayController.Redraw();
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Failed to hide ROI:\n" + ex.Message);
			}
		}

		// Token: 0x060017BD RID: 6077 RVA: 0x0006B608 File Offset: 0x00069808
		private void SaveImageWithWaitOverlay(string savePath, string message)
		{
			HObject image = this._displayController.GetCurrentImage();
			bool flag = image == null || !image.IsInitialized();
			if (flag)
			{
				throw new InvalidOperationException("No image is available to save. Please open an image first.");
			}
			try
			{
				LoadingOverlay.Run(this, message, delegate
				{
					SettingDisplayController.WriteImage(image, savePath);
				});
			}
			finally
			{
				try
				{
					image.Dispose();
				}
				catch
				{
				}
			}
		}

		// Token: 0x060017BE RID: 6078 RVA: 0x0006B6AC File Offset: 0x000698AC
		private void LoadMasterImageForTurnSnap(TurnSnap turnSnap)
		{
			try
			{
				string imagePath = this._masterImageService.GetMasterImagePath(turnSnap);
				StartupDiag.Log("SETTING master image -> " + (imagePath ?? "(null)"));
				bool flag = string.IsNullOrWhiteSpace(imagePath) || !File.Exists(imagePath);
				if (flag)
				{
					this._displayController.ClearImage();
				}
				else
				{
					this._displayController.LoadImage(imagePath);
				}
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Failed to load master image:\n" + ex.Message);
			}
		}

		// Token: 0x060017BF RID: 6079 RVA: 0x0006B744 File Offset: 0x00069944
		private void RoiButton_ItemClick(object sender, ItemClickEventArgs e)
		{
			BarButtonItem item = e.Item as BarButtonItem;
			bool flag = item == null;
			if (!flag)
			{
				bool flag2 = item.Tag == null;
				if (!flag2)
				{
					RoiShape shape;
					bool flag3 = !Enum.TryParse<RoiShape>(item.Tag.ToString(), out shape);
					if (!flag3)
					{
						string itemName = item.Name ?? "";
						bool flag4 = itemName.Contains("_limit");
						if (flag4)
						{
							this._roiService.CurrentPanelType = RoiPanelType.Limit;
						}
						else
						{
							bool flag5 = itemName.Contains("_mask_");
							if (flag5)
							{
								this._roiService.CurrentPanelType = RoiPanelType.Mask;
							}
							else
							{
								this._roiService.CurrentPanelType = RoiPanelType.Normal;
							}
						}
						this._roiService.ShowRoi(shape, this.Display_setting.HalconWindow);
					}
				}
			}
		}

		// Token: 0x060017C0 RID: 6080 RVA: 0x0006B814 File Offset: 0x00069A14
		private void CustomRoiButton_ItemClick(object sender, ItemClickEventArgs e)
		{
			BarButtonItem item = e.Item as BarButtonItem;
			bool flag = item == null;
			if (!flag)
			{
				string itemName = item.Name ?? string.Empty;
				bool flag2 = itemName.Contains("_limit");
				RoiPanelType panelType;
				if (flag2)
				{
					panelType = RoiPanelType.Limit;
				}
				else
				{
					bool flag3 = itemName.Contains("_mask_");
					if (flag3)
					{
						panelType = RoiPanelType.Mask;
					}
					else
					{
						panelType = RoiPanelType.Normal;
					}
				}
				this._roiService.AddCustomPaintRoi(panelType);
			}
		}

		// Token: 0x060017C1 RID: 6081 RVA: 0x0006B884 File Offset: 0x00069A84
		private void AddRoi_Click(object sender, RoutedEventArgs e)
		{
			this._roiService.AddRoi(RoiPanelType.Normal);
			this.RefreshRoiOverlay();
		}

		// Token: 0x060017C2 RID: 6082 RVA: 0x0006B89B File Offset: 0x00069A9B
		private void AddLimitRoi_Click(object sender, RoutedEventArgs e)
		{
			this._roiService.AddRoi(RoiPanelType.Limit);
			this.RefreshRoiOverlay();
		}

		// Token: 0x060017C3 RID: 6083 RVA: 0x0006B8B2 File Offset: 0x00069AB2
		private void AddMaskRoi_Click(object sender, RoutedEventArgs e)
		{
			this._roiService.AddRoi(RoiPanelType.Mask);
			this.RefreshRoiOverlay();
		}

		// Token: 0x060017C4 RID: 6084 RVA: 0x0006B8C9 File Offset: 0x00069AC9
		private void RoiItem_Click(object sender, RoutedEventArgs e)
		{
			this.SelectRoiFromList(sender, RoiPanelType.Normal);
		}

		// Token: 0x060017C5 RID: 6085 RVA: 0x0006B8D5 File Offset: 0x00069AD5
		private void LimitRoiItem_Click(object sender, RoutedEventArgs e)
		{
			this.SelectRoiFromList(sender, RoiPanelType.Limit);
		}

		// Token: 0x060017C6 RID: 6086 RVA: 0x0006B8E1 File Offset: 0x00069AE1
		private void MaskRoiItem_Click(object sender, RoutedEventArgs e)
		{
			this.SelectRoiFromList(sender, RoiPanelType.Mask);
		}

		// Token: 0x060017C7 RID: 6087 RVA: 0x0006B8F0 File Offset: 0x00069AF0
		private void SelectRoiFromList(object sender, RoiPanelType panelType)
		{
			Button button = sender as Button;
			RoiData roi;
			bool flag;
			if (button != null)
			{
				roi = (button.Tag as RoiData);
				flag = (roi != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				this._roiService.SelectRoiItem(roi, panelType, this.Display_setting.HalconWindow, Keyboard.Modifiers);
			}
		}

		// Token: 0x060017C8 RID: 6088 RVA: 0x0006B93F File Offset: 0x00069B3F
		private void SelectRoi_Click(object sender, RoutedEventArgs e)
		{
			this._roiService.UpdateSelectedRoi(RoiPanelType.Normal, this.Display_setting.HalconWindow);
			this.RefreshRoiOverlay();
		}

		// Token: 0x060017C9 RID: 6089 RVA: 0x0006B961 File Offset: 0x00069B61
		private void SelectLimitRoi_Click(object sender, RoutedEventArgs e)
		{
			this._roiService.UpdateSelectedRoi(RoiPanelType.Limit, this.Display_setting.HalconWindow);
			this.RefreshRoiOverlay();
		}

		// Token: 0x060017CA RID: 6090 RVA: 0x0006B983 File Offset: 0x00069B83
		private void SelectMaskRoi_Click(object sender, RoutedEventArgs e)
		{
			this._roiService.UpdateSelectedRoi(RoiPanelType.Mask, this.Display_setting.HalconWindow);
			this.RefreshRoiOverlay();
		}

		// Token: 0x060017CB RID: 6091 RVA: 0x0006B9A8 File Offset: 0x00069BA8
		private void DeleteRoi_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement element = sender as FrameworkElement;
			RoiData roi;
			bool flag;
			if (element != null)
			{
				roi = (element.Tag as RoiData);
				flag = (roi != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				bool flag3 = this._roiService.DeleteRoiOrSelection(roi) <= 0;
				if (!flag3)
				{
					this.AfterRoiDeleted();
				}
			}
		}

		// Token: 0x060017CC RID: 6092 RVA: 0x0006B9F8 File Offset: 0x00069BF8
		private void RoiList_KeyDown(object sender, KeyEventArgs e)
		{
			bool flag = e.Key != Key.Delete;
			if (!flag)
			{
				FrameworkElement element = sender as FrameworkElement;
				string panelName;
				bool flag2;
				if (element != null)
				{
					panelName = (element.Tag as string);
					flag2 = (panelName == null);
				}
				else
				{
					flag2 = true;
				}
				bool flag3 = flag2;
				if (!flag3)
				{
					e.Handled = true;
					bool flag4 = this._roiService.DeleteSelectedRois(Form_setting.ParseRoiPanelType(panelName)) <= 0;
					if (!flag4)
					{
						this.AfterRoiDeleted();
					}
				}
			}
		}

		// Token: 0x060017CD RID: 6093 RVA: 0x0006BA70 File Offset: 0x00069C70
		private void AfterRoiDeleted()
		{
			ToolVision selectedTool = this.GetSelectedTool();
			bool flag = ((selectedTool != null) ? selectedTool.SelectedRoi : null) == null;
			if (flag)
			{
				this._roiService.HideActiveRoi(this.Display_setting.HalconWindow);
			}
			this.RefreshRoiOverlay();
		}

		// Token: 0x060017CE RID: 6094 RVA: 0x0006BAB8 File Offset: 0x00069CB8
		private void ClearAllRoi_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement element = sender as FrameworkElement;
			string panelName;
			bool flag;
			if (element != null)
			{
				panelName = (element.Tag as string);
				flag = (panelName == null);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (!flag2)
			{
				RoiPanelType panelType = Form_setting.ParseRoiPanelType(panelName);
				bool flag3 = this._roiService.ClearRois(panelType) <= 0;
				if (!flag3)
				{
					this._roiService.HideActiveRoi(this.Display_setting.HalconWindow);
					this.RefreshRoiOverlay();
				}
			}
		}

		// Token: 0x060017CF RID: 6095 RVA: 0x0006BB2C File Offset: 0x00069D2C
		public void ShowRoiClonePreview(RoiData source, IList<RoiData> clones)
		{
			this._clonePreviewSource = ((clones == null || clones.Count == 0) ? null : source);
			this._clonePreviewClones = ((clones == null || clones.Count == 0) ? null : clones.ToList<RoiData>());
			this.RefreshRoiOverlay();
		}

		// Token: 0x060017D0 RID: 6096 RVA: 0x0006BB68 File Offset: 0x00069D68
		private void ShowAllRoi_Click(object sender, RoutedEventArgs e)
		{
			MenuItem item = sender as MenuItem;
			string panelName;
			bool flag;
			if (item != null)
			{
				panelName = (item.Tag as string);
				flag = (panelName == null);
			}
			else
			{
				flag = true;
			}
			bool flag2 = flag;
			if (!flag2)
			{
				RoiPanelType panelType = Form_setting.ParseRoiPanelType(panelName);
				bool isChecked = item.IsChecked;
				if (isChecked)
				{
					this._showAllRoiPanels.Add(panelType);
				}
				else
				{
					this._showAllRoiPanels.Remove(panelType);
				}
				this.RefreshRoiOverlay();
			}
		}

		// Token: 0x060017D1 RID: 6097 RVA: 0x0006BBD4 File Offset: 0x00069DD4
		private void RefreshRoiOverlay()
		{
			bool flag = this._displayController == null;
			if (!flag)
			{
				ToolVision tool = this.GetSelectedTool();
				List<RoiPanelType> panels = this._showAllRoiPanels.ToList<RoiPanelType>();
				RoiData previewSource = this._clonePreviewSource;
				List<RoiData> previewClones = this._clonePreviewClones;
				bool flag2 = tool == null || (panels.Count == 0 && previewClones == null);
				if (flag2)
				{
					this._displayController.ClearOverlayRenderer();
					this._displayController.Redraw();
				}
				else
				{
					this._displayController.SetOverlayRenderer(delegate(HWindow window)
					{
						foreach (RoiPanelType panel in panels)
						{
							ToolRoiOverlayDrawer.DrawRoiList(window, tool, Form_setting.GetRoiListForPanel(tool, panel), Form_setting.GetRoiPanelColor(panel), 2);
						}
						bool flag3 = previewClones == null;
						if (!flag3)
						{
							ToolRoiOverlayDrawer.DrawRoiList(window, tool, previewClones, "yellow", 2);
							bool flag4 = previewSource != null;
							if (flag4)
							{
								ToolRoiOverlayDrawer.DrawRoiList(window, tool, new RoiData[]
								{
									previewSource
								}, "green", 3);
							}
						}
					}, null);
				}
			}
		}

		// Token: 0x060017D2 RID: 6098 RVA: 0x0006BC8C File Offset: 0x00069E8C
		private static RoiPanelType ParseRoiPanelType(string panelName)
		{
			RoiPanelType result;
			if (!(panelName == "Limit"))
			{
				if (!(panelName == "Mask"))
				{
					result = RoiPanelType.Normal;
				}
				else
				{
					result = RoiPanelType.Mask;
				}
			}
			else
			{
				result = RoiPanelType.Limit;
			}
			return result;
		}

		// Token: 0x060017D3 RID: 6099 RVA: 0x0006BCC8 File Offset: 0x00069EC8
		private static IList<RoiData> GetRoiListForPanel(ToolVision tool, RoiPanelType panelType)
		{
			IList<RoiData> result;
			if (panelType != RoiPanelType.Limit)
			{
				if (panelType != RoiPanelType.Mask)
				{
					result = tool.RoiItems;
				}
				else
				{
					result = tool.MaskRoiItems;
				}
			}
			else
			{
				result = tool.LimitRoiItems;
			}
			return result;
		}

		// Token: 0x060017D4 RID: 6100 RVA: 0x0006BD04 File Offset: 0x00069F04
		private static string GetRoiPanelColor(RoiPanelType panelType)
		{
			string result;
			if (panelType != RoiPanelType.Limit)
			{
				if (panelType != RoiPanelType.Mask)
				{
					result = "green";
				}
				else
				{
					result = "magenta";
				}
			}
			else
			{
				result = "cyan";
			}
			return result;
		}

		// Token: 0x060017D5 RID: 6101 RVA: 0x0006BD3C File Offset: 0x00069F3C
		private void EditRoi_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement element = sender as FrameworkElement;
			RoiData roi;
			bool flag;
			if (element != null)
			{
				roi = (element.Tag as RoiData);
				flag = (roi != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				this._roiService.EditRoi(roi, Window.GetWindow(element));
			}
		}

		// Token: 0x060017D6 RID: 6102 RVA: 0x0006BD80 File Offset: 0x00069F80
		private void SaveAllConfig_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				this._recipeService.SaveCurrentModelRecipe();
			}
			catch (Exception ex)
			{
				DXMessageBox.Show("Failed to save configuration:\n" + ex.Message);
			}
		}

		// Token: 0x060017D7 RID: 6103 RVA: 0x0006BDCC File Offset: 0x00069FCC
		private void LoadCurrentModelRecipe()
		{
			try
			{
				this._isInitializingToolSelection = true;
				this._recipeService.LoadCurrentModelRecipe();
				this.ResetSettingSelectionToFirstTurnSnap();
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					this.ResetSettingSelectionToFirstTurnSnap();
					this._isInitializingToolSelection = false;
				}), DispatcherPriority.Loaded, Array.Empty<object>());
			}
			catch (Exception ex)
			{
				this._isInitializingToolSelection = false;
				DXMessageBox.Show("Failed to load model configuration:\n" + ex.Message);
			}
		}

		// Token: 0x060017D8 RID: 6104 RVA: 0x0006BE48 File Offset: 0x0006A048
		private void ResetSettingSelectionToFirstTurnSnap()
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			CameraNode camera = (vm != null) ? vm.SelectedCamera : null;
			StartupDiag.Log("SETTING reset selection camera=" + ((camera == null) ? "(null)" : camera.Name) + " turnSnaps=" + ((camera == null) ? -1 : camera.TurnSnaps.Count).ToString());
			bool flag = camera == null;
			if (flag)
			{
				SettingDisplayController displayController = this._displayController;
				if (displayController != null)
				{
					displayController.ClearImage();
				}
			}
			else
			{
				foreach (TurnSnap turnSnap in camera.TurnSnaps)
				{
					turnSnap.IsSelected = false;
					foreach (ToolVision tool in turnSnap.Tools)
					{
						tool.IsSelected = false;
					}
				}
				vm.SelectedTool = null;
				vm.CurrentParameterView = null;
				TurnSnap firstTurnSnap = (from x in camera.TurnSnaps
				orderby x.Index
				select x).FirstOrDefault<TurnSnap>();
				bool flag2 = firstTurnSnap == null;
				if (flag2)
				{
					SettingDisplayController displayController2 = this._displayController;
					if (displayController2 != null)
					{
						displayController2.ClearImage();
					}
				}
				else
				{
					firstTurnSnap.IsSelected = true;
					this.LoadMasterImageForTurnSnap(firstTurnSnap);
				}
			}
		}

		// Token: 0x060017D9 RID: 6105 RVA: 0x0006BFD8 File Offset: 0x0006A1D8
		private ToolVision GetSelectedTool()
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			return (vm != null) ? vm.SelectedTool : null;
		}

		// Token: 0x060017DA RID: 6106 RVA: 0x0006C004 File Offset: 0x0006A204
		private void UpdatePixelInspector(MouseEventArgs e)
		{
			bool flag = this._displayController == null || e == null;
			if (!flag)
			{
				DateTime now = DateTime.UtcNow;
				bool flag2 = (now - this._lastPixelInspectorUpdateUtc).TotalMilliseconds < 33.0;
				if (!flag2)
				{
					this._lastPixelInspectorUpdateUtc = now;
					PixelInspectionResult pixel;
					bool flag3 = !this._displayController.TryInspectPixel(e.GetPosition(this.Display_setting), out pixel);
					if (flag3)
					{
						this.PixelInspectorText = "Row: -  Col: -  Gray: -  R: -  G: -  B: -";
					}
					else
					{
						string red = (pixel.Red != null) ? pixel.Red.Value.ToString("0") : "-";
						string green = (pixel.Green != null) ? pixel.Green.Value.ToString("0") : "-";
						string blue = (pixel.Blue != null) ? pixel.Blue.Value.ToString("0") : "-";
						this.PixelInspectorText = string.Concat(new string[]
						{
							"Row: ",
							pixel.Row.ToString(),
							"  Col: ",
							pixel.Column.ToString(),
							"  Gray: ",
							pixel.Gray.ToString("0.##"),
							"  R: ",
							red,
							"  G: ",
							green,
							"  B: ",
							blue
						});
					}
				}
			}
		}

		// Token: 0x060017DB RID: 6107 RVA: 0x0006C1CC File Offset: 0x0006A3CC
		private void SelectFindBoundingBoxOutputRowFromHWindow(MouseButtonEventArgs e)
		{
			bool flag = e == null || e.ChangedButton != MouseButton.Left || !this.IsFindBoundingBoxOutputVisible || this.FindBoundingBoxOutputResults.Count == 0 || this._displayController == null;
			if (!flag)
			{
				PixelInspectionResult pixel;
				bool flag2 = !this._displayController.TryInspectPixel(e.GetPosition(this.Display_setting), out pixel);
				if (!flag2)
				{
					FindBoundingBoxOutputResultRow hit = (from x in this.FindBoundingBoxOutputResults
					where x.ContainsImagePoint((double)pixel.Row, (double)pixel.Column)
					orderby x.Width * x.Height
					select x).FirstOrDefault<FindBoundingBoxOutputResultRow>();
					foreach (FindBoundingBoxOutputResultRow row in this.FindBoundingBoxOutputResults)
					{
						row.IsImageClicked = (row == hit);
					}
					bool flag3 = hit != null;
					if (flag3)
					{
						e.Handled = true;
					}
				}
			}
		}

		// Token: 0x060017DC RID: 6108 RVA: 0x0006C2E4 File Offset: 0x0006A4E4
		private void UpdateOutputResult(ToolVision tool, object result)
		{
			bool flag = tool == null;
			if (!flag)
			{
				this.IsCalibHandEyeOutputVisible = false;
				this.IsResultAlignOutputVisible = false;
				this.IsResultInspectionOutputVisible = false;
				bool flag2 = !(result is DeformableInspectionResult);
				if (flag2)
				{
					this.IsDeformableInspectionOutputVisible = false;
				}
				bool flag3 = !(result is DLObjectInspectionResult);
				if (flag3)
				{
					this.IsDLObjectInspectionOutputVisible = false;
				}
				InspectionResultStore.Record(tool.Name, result);
				DLObjectInspectionResult dlObjectResult = result as DLObjectInspectionResult;
				bool flag4 = dlObjectResult != null;
				if (flag4)
				{
					this.UpdateDLObjectInspectionOutputResult(tool, dlObjectResult);
				}
				else
				{
					CalibHandEyeResult calibResult = result as CalibHandEyeResult;
					bool flag5 = calibResult != null;
					if (flag5)
					{
						this.UpdateCalibHandEyeOutputResult(calibResult);
					}
					else
					{
						CalibResultAlignResult alignResult = result as CalibResultAlignResult;
						bool flag6 = alignResult != null;
						if (flag6)
						{
							this.UpdateResultAlignOutputResult(alignResult);
						}
						else
						{
							CalibResultInspectionResult inspectionResult = result as CalibResultInspectionResult;
							bool flag7 = inspectionResult != null;
							if (flag7)
							{
								this.UpdateResultInspectionOutputResult(inspectionResult);
							}
							else
							{
								MatrixCodeResult matrixCodeResult = result as MatrixCodeResult;
								bool flag8 = matrixCodeResult != null;
								if (flag8)
								{
									this.UpdateMatrixCodeOutputResult(tool, matrixCodeResult);
								}
								else
								{
									BlobProcessResult blobResult = result as BlobProcessResult;
									bool flag9 = blobResult != null;
									if (flag9)
									{
										this.UpdateBlobOutputResult(tool, blobResult);
									}
									else
									{
										HistogramProcessResult histogramResult = result as HistogramProcessResult;
										bool flag10 = histogramResult != null;
										if (flag10)
										{
											this.UpdateHistogramOutputResult(tool, histogramResult);
										}
										else
										{
											HistogramColorProcessResult histogramColorResult = result as HistogramColorProcessResult;
											bool flag11 = histogramColorResult != null;
											if (flag11)
											{
												this.UpdateHistogramColorOutputResult(tool, histogramColorResult);
											}
											else
											{
												BoundingBoxMasterResult boundingBoxMasterResult = result as BoundingBoxMasterResult;
												bool flag12 = boundingBoxMasterResult != null;
												if (flag12)
												{
													this.UpdateFindBoundingBoxOutputResult(boundingBoxMasterResult.BoundingBoxResult);
												}
												else
												{
													MinAreaMasterResult minAreaMasterResult = result as MinAreaMasterResult;
													bool flag13 = minAreaMasterResult != null;
													if (flag13)
													{
														this.UpdateFindMinAreaOutputResult(minAreaMasterResult.MinAreaResult);
													}
													else
													{
														ShapeMatchResult shapeResult = result as ShapeMatchResult;
														bool flag14 = shapeResult != null;
														if (flag14)
														{
															this.UpdateShapeModelOutputResult(shapeResult);
														}
														else
														{
															FindLineResult findLineResult = result as FindLineResult;
															bool flag15 = findLineResult != null;
															if (flag15)
															{
																this.UpdateFindLineOutputResult(findLineResult);
															}
															else
															{
																FindCircleResult findCircleResult = result as FindCircleResult;
																bool flag16 = findCircleResult != null;
																if (flag16)
																{
																	this.UpdateFindCircleOutputResult(findCircleResult);
																}
																else
																{
																	FindBoundingBoxResult findBoundingBoxResult = result as FindBoundingBoxResult;
																	bool flag17 = findBoundingBoxResult != null;
																	if (flag17)
																	{
																		this.UpdateFindBoundingBoxOutputResult(findBoundingBoxResult);
																	}
																	else
																	{
																		FindMinAreaResult findMinAreaResult = result as FindMinAreaResult;
																		bool flag18 = findMinAreaResult != null;
																		if (flag18)
																		{
																			this.UpdateFindMinAreaOutputResult(findMinAreaResult);
																		}
																		else
																		{
																			DistanceObjectResult distanceResult = result as DistanceObjectResult;
																			bool flag19 = distanceResult != null;
																			if (flag19)
																			{
																				this.UpdateDistanceObjectOutputResult(distanceResult);
																			}
																			else
																			{
																				MeasureCircleResult measureCircleResult = result as MeasureCircleResult;
																				bool flag20 = measureCircleResult != null;
																				if (flag20)
																				{
																					this.UpdateMeasureCircleOutputResult(measureCircleResult);
																				}
																				else
																				{
																					DeformableInspectionResult deformableInspectionResult = result as DeformableInspectionResult;
																					bool flag21 = deformableInspectionResult != null;
																					if (flag21)
																					{
																						this.UpdateDeformableInspectionOutputResult(tool, deformableInspectionResult);
																					}
																					else
																					{
																						VariationModelResult variationModelResult = result as VariationModelResult;
																						bool flag22 = variationModelResult != null;
																						if (flag22)
																						{
																							this.UpdateVariationModelOutputResult(tool, variationModelResult);
																						}
																						else
																						{
																							VariationChangeWDResult changeWdResult = result as VariationChangeWDResult;
																							bool flag23 = changeWdResult != null;
																							if (flag23)
																							{
																								this.UpdateVariationChangeWDOutputResult(tool, changeWdResult);
																							}
																							else
																							{
																								ProductCountInspectionResult productCountResult = result as ProductCountInspectionResult;
																								bool flag24 = productCountResult != null;
																								if (flag24)
																								{
																									this.UpdateProductCountInspectionOutputResult(tool, productCountResult);
																								}
																								else
																								{
																									FindRedArrowResult redArrowResult = result as FindRedArrowResult;
																									bool flag25 = redArrowResult != null;
																									if (flag25)
																									{
																										this.UpdateFindRedArrowOutputResult(tool, redArrowResult);
																									}
																									else
																									{
																										CountBoundingBoxResult countBoxResult = result as CountBoundingBoxResult;
																										bool flag26 = countBoxResult != null;
																										if (flag26)
																										{
																											this.UpdateCountBoundingBoxOutputResult(tool, countBoxResult);
																										}
																										else
																										{
																											ProcedureInspectionResult procedureResult = result as ProcedureInspectionResult;
																											bool flag27 = procedureResult != null;
																											if (flag27)
																											{
																												this.UpdateProcedureInspectionOutputResult(tool, procedureResult);
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060017DD RID: 6109 RVA: 0x0006C688 File Offset: 0x0006A888
		private void UpdateProcedureInspectionOutputResult(ToolVision tool, ProcedureInspectionResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = false;
			this.IsRunAllOutputVisible = true;
			this.RunAllOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string source = this.NormalizeDisplayValue(result.InputSourceToolName);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				this.RunAllOutputResults.Add(new RunAllOutputResultRow
				{
					ToolName = toolName,
					Result = ((!result.IsSuccess) ? this.NormalizeDisplayValue(result.Message) : ((string.IsNullOrWhiteSpace(result.ValueName) ? "Value" : result.ValueName) + ": " + (result.HasValue ? result.ValueTextOrEmpty : "-") + ((result.SpecFailures.Count > 0) ? (" (" + string.Join("; ", result.SpecFailures) + ")") : string.Empty))),
					Status = status,
					ProcessingTimeMs = result.ProcessingTimeMs,
					InputSourceToolName = source,
					MasterPositionToolName = "None",
					MasterAngleToolName = "None"
				});
				bool flag2 = !result.IsSuccess;
				if (flag2)
				{
					bool flag3 = !string.IsNullOrWhiteSpace(result.SignatureText);
					if (flag3)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Signature",
							Result = result.SignatureText,
							Status = status,
							ProcessingTimeMs = 0.0,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
				}
				else
				{
					foreach (ProcedureInspectionOutputValue output in result.Outputs)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - " + output.Name,
							Result = output.Text,
							Status = status,
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
					foreach (ProcedureInspectionRoiResult roiResult in result.RoiResults)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - ROI " + roiResult.Index.ToString(),
							Result = ((!string.IsNullOrWhiteSpace(roiResult.Message)) ? roiResult.Message : (roiResult.HasValue ? roiResult.Value.ToString("0.###") : this.NormalizeDisplayValue(roiResult.ValueText))),
							Status = (roiResult.IsEvaluated ? (roiResult.IsOk ? "OK" : "NG") : status),
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
				}
			}
		}

		// Token: 0x060017DE RID: 6110 RVA: 0x0006CA9C File Offset: 0x0006AC9C
		private void UpdateCountBoundingBoxOutputResult(ToolVision tool, CountBoundingBoxResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = false;
			this.IsRunAllOutputVisible = true;
			this.RunAllOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string source = this.NormalizeDisplayValue(result.InputSourceToolName);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				this.RunAllOutputResults.Add(new RunAllOutputResultRow
				{
					ToolName = toolName,
					Result = ((!result.IsSuccess) ? this.NormalizeDisplayValue(result.Message) : ("Objects: " + result.ObjectCount.ToString())),
					Status = status,
					ProcessingTimeMs = result.ProcessingTimeMs,
					InputSourceToolName = source,
					MasterPositionToolName = "None",
					MasterAngleToolName = "None"
				});
				bool flag2 = !result.IsSuccess;
				if (!flag2)
				{
					this.RunAllOutputResults.Add(new RunAllOutputResultRow
					{
						ToolName = toolName + " - Threshold",
						Result = string.Concat(new string[]
						{
							result.CandidateCount.ToString(),
							" blob(s) over threshold, ",
							result.BoxesBeforeGrouping.ToString(),
							" box(es) measured, ",
							result.ObjectCount.ToString(),
							" passed the size filters, search area ",
							result.SearchArea.ToString("0"),
							" px",
							(result.RoiCount > 0) ? (" in " + result.RoiCount.ToString() + " ROI(s)") : " (no ROI - whole image)"
						}),
						Status = status,
						ProcessingTimeMs = result.ProcessingTimeMs,
						InputSourceToolName = source,
						MasterPositionToolName = "None",
						MasterAngleToolName = "None"
					});
					foreach (string failure in result.SpecFailures)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Spec",
							Result = failure,
							Status = "NG",
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
					foreach (CountBoundingBoxItem item in result.Objects)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Object " + item.Index.ToString(),
							Result = string.Concat(new string[]
							{
								"Size: ",
								item.Width.ToString("0"),
								" x ",
								item.Height.ToString("0"),
								", Box area: ",
								item.BoxArea.ToString("0"),
								" px, Blob area: ",
								item.BlobArea.ToString("0"),
								" px, Row: ",
								item.CenterRow.ToString("0"),
								", Col: ",
								item.CenterColumn.ToString("0"),
								(item.MemberCount > 1) ? (", grouped from " + item.MemberCount.ToString() + " boxes") : string.Empty
							}),
							Status = status,
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
				}
			}
		}

		// Token: 0x060017DF RID: 6111 RVA: 0x0006CFA4 File Offset: 0x0006B1A4
		private void UpdateFindRedArrowOutputResult(ToolVision tool, FindRedArrowResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = false;
			this.IsRunAllOutputVisible = true;
			this.RunAllOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string source = this.NormalizeDisplayValue(result.InputSourceToolName);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				this.RunAllOutputResults.Add(new RunAllOutputResultRow
				{
					ToolName = toolName,
					Result = ((!result.IsSuccess) ? this.NormalizeDisplayValue(result.Message) : string.Concat(new string[]
					{
						"Red arrows: ",
						result.ArrowCount.ToString(),
						", Largest: ",
						result.MaxArea.ToString("0"),
						" px, Total: ",
						result.TotalArea.ToString("0"),
						" px"
					})),
					Status = status,
					ProcessingTimeMs = result.ProcessingTimeMs,
					InputSourceToolName = source,
					MasterPositionToolName = "None",
					MasterAngleToolName = "None"
				});
				bool flag2 = !result.IsSuccess;
				if (!flag2)
				{
					this.RunAllOutputResults.Add(new RunAllOutputResultRow
					{
						ToolName = toolName + " - Threshold",
						Result = string.Concat(new string[]
						{
							result.CandidateCount.ToString(),
							" red patch(es) over threshold, ",
							result.ArrowCount.ToString(),
							" passed the filters, search area ",
							result.SearchArea.ToString("0"),
							" px"
						}),
						Status = status,
						ProcessingTimeMs = result.ProcessingTimeMs,
						InputSourceToolName = source,
						MasterPositionToolName = "None",
						MasterAngleToolName = "None"
					});
					foreach (string failure in result.SpecFailures)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Spec",
							Result = failure,
							Status = "NG",
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
					foreach (FindRedArrowItem arrow in result.Arrows)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Arrow " + arrow.Index.ToString(),
							Result = string.Concat(new string[]
							{
								"Area: ",
								arrow.Area.ToString("0"),
								" px, Row: ",
								arrow.Row.ToString("0"),
								", Col: ",
								arrow.Column.ToString("0"),
								", Mean redness: ",
								arrow.MeanRedness.ToString("0"),
								", Anisometry: ",
								arrow.Anisometry.ToString("0.##")
							}),
							Status = (arrow.IsAreaOutOfSpec ? "NG" : status),
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
				}
			}
		}

		// Token: 0x060017E0 RID: 6112 RVA: 0x0006D478 File Offset: 0x0006B678
		private void UpdateProductCountInspectionOutputResult(ToolVision tool, ProductCountInspectionResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = false;
			this.IsRunAllOutputVisible = true;
			this.RunAllOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string source = this.NormalizeDisplayValue(result.InputSourceToolName);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				this.RunAllOutputResults.Add(new RunAllOutputResultRow
				{
					ToolName = toolName,
					Result = ((!result.IsSuccess) ? this.NormalizeDisplayValue(result.Message) : string.Concat(new string[]
					{
						"Products: ",
						result.FoundCount.ToString(),
						", Foreign objects: ",
						result.DefectCount.ToString(),
						", Max blob: ",
						result.MaxBlobArea.ToString("0"),
						" px"
					})),
					Status = status,
					ProcessingTimeMs = result.ProcessingTimeMs,
					InputSourceToolName = source,
					MasterPositionToolName = "None",
					MasterAngleToolName = "None"
				});
				bool flag2 = !result.IsSuccess;
				if (!flag2)
				{
					this.RunAllOutputResults.Add(new RunAllOutputResultRow
					{
						ToolName = toolName + " - Product Count",
						Result = result.FoundCount.ToString(),
						Status = status,
						ProcessingTimeMs = result.ProcessingTimeMs,
						InputSourceToolName = source,
						MasterPositionToolName = "None",
						MasterAngleToolName = "None"
					});
					this.RunAllOutputResults.Add(new RunAllOutputResultRow
					{
						ToolName = toolName + " - Foreign Object Check",
						Result = ((!result.IsForeignObjectChecked) ? "Off" : string.Concat(new string[]
						{
							result.UsedVariationModel ? "Variation model" : "Golden compare",
							result.IsColorImage ? " + colour mark" : string.Empty,
							", total area ",
							result.TotalDefectArea.ToString("0"),
							" px"
						})),
						Status = status,
						ProcessingTimeMs = result.ProcessingTimeMs,
						InputSourceToolName = source,
						MasterPositionToolName = "None",
						MasterAngleToolName = "None"
					});
					bool flag3 = result.NgProductIndexes.Count > 0;
					if (flag3)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - NG Products",
							Result = string.Join<int>(", ", result.NgProductIndexes),
							Status = "NG",
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
					foreach (string failure in result.SpecFailures)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Spec",
							Result = failure,
							Status = "NG",
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
					foreach (ProductCountMatch match in result.Matches)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Product " + match.Index.ToString(),
							Result = string.Concat(new string[]
							{
								"Row: ",
								match.Row.ToString("0"),
								", Col: ",
								match.Column.ToString("0"),
								", Angle: ",
								match.AngleDeg.ToString("0.##"),
								" deg, Score: ",
								match.Score.ToString("0.###")
							}),
							Status = (match.HasForeignObject ? "NG" : status),
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
					for (int i = 0; i < result.ForeignObjects.Count; i++)
					{
						ProductCountForeignObject foreign = result.ForeignObjects[i];
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Foreign " + (i + 1).ToString(),
							Result = string.Concat(new string[]
							{
								"Area: ",
								foreign.Area.ToString("0"),
								" px, Row: ",
								foreign.Row.ToString("0"),
								", Col: ",
								foreign.Column.ToString("0"),
								(foreign.ProductIndex > 0) ? (", on product " + foreign.ProductIndex.ToString()) : string.Empty
							}),
							Status = "NG",
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
				}
			}
		}

		// Token: 0x060017E1 RID: 6113 RVA: 0x0006DB78 File Offset: 0x0006BD78
		private void UpdateVariationChangeWDOutputResult(ToolVision tool, VariationChangeWDResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = false;
			this.IsRunAllOutputVisible = true;
			this.RunAllOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string source = this.NormalizeDisplayValue(result.InputSourceToolName);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				string resultText = (!result.IsSuccess) ? this.NormalizeDisplayValue(result.Message) : string.Concat(new string[]
				{
					"Total Area: ",
					result.TotalDefectArea.ToString("0"),
					" px, Max Blob: ",
					result.MaxBlobArea.ToString("0"),
					" px, Defects: ",
					result.DefectCount.ToString()
				});
				this.RunAllOutputResults.Add(new RunAllOutputResultRow
				{
					ToolName = toolName,
					Result = resultText,
					Status = status,
					ProcessingTimeMs = result.ProcessingTimeMs,
					InputSourceToolName = source,
					MasterPositionToolName = "None",
					MasterAngleToolName = "None"
				});
				this.RunAllOutputResults.Add(new RunAllOutputResultRow
				{
					ToolName = toolName + " - Registration",
					Result = this.NormalizeDisplayValue(result.RegistrationMessage) + ((result.Scale > 0.0) ? string.Concat(new string[]
					{
						"  Die scale: ",
						result.Scale.ToString("0.0000"),
						" (",
						result.ScaleDeviationPercent.ToString("+0.00;-0.00;0.00"),
						"%)"
					}) : string.Empty),
					Status = (result.IsRegistered ? "OK" : "Lost"),
					ProcessingTimeMs = result.ProcessingTimeMs,
					InputSourceToolName = source,
					MasterPositionToolName = "None",
					MasterAngleToolName = "None"
				});
				this.RunAllOutputResults.Add(new RunAllOutputResultRow
				{
					ToolName = toolName + " - Inspect Area",
					Result = result.InspectArea.ToString("0") + " px",
					Status = status,
					ProcessingTimeMs = result.ProcessingTimeMs,
					InputSourceToolName = source,
					MasterPositionToolName = "None",
					MasterAngleToolName = "None"
				});
				foreach (string failure in result.SpecFailures)
				{
					this.RunAllOutputResults.Add(new RunAllOutputResultRow
					{
						ToolName = toolName + " - Spec",
						Result = failure,
						Status = "NG",
						ProcessingTimeMs = result.ProcessingTimeMs,
						InputSourceToolName = source,
						MasterPositionToolName = "None",
						MasterAngleToolName = "None"
					});
				}
				for (int i = 0; i < result.DefectAreas.Count; i++)
				{
					this.RunAllOutputResults.Add(new RunAllOutputResultRow
					{
						ToolName = toolName + " - Defect " + (i + 1).ToString(),
						Result = string.Concat(new string[]
						{
							"Area: ",
							result.DefectAreas[i].ToString("0"),
							" px, Row: ",
							result.DefectRows[i].ToString("0"),
							", Col: ",
							result.DefectColumns[i].ToString("0")
						}),
						Status = status,
						ProcessingTimeMs = result.ProcessingTimeMs,
						InputSourceToolName = source,
						MasterPositionToolName = "None",
						MasterAngleToolName = "None"
					});
				}
			}
		}

		// Token: 0x060017E2 RID: 6114 RVA: 0x0006E058 File Offset: 0x0006C258
		private void UpdateVariationModelOutputResult(ToolVision tool, VariationModelResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = false;
			this.IsRunAllOutputVisible = true;
			this.RunAllOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string source = this.NormalizeDisplayValue(result.InputSourceToolName);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				string resultText = (!result.IsSuccess) ? this.NormalizeDisplayValue(result.Message) : string.Concat(new string[]
				{
					"Total Area: ",
					result.TotalDefectArea.ToString("0"),
					" px, Defects: ",
					result.DefectCount.ToString(),
					" (Score ",
					result.Score.ToString("0.000"),
					")"
				});
				this.RunAllOutputResults.Add(new RunAllOutputResultRow
				{
					ToolName = toolName,
					Result = resultText,
					Status = status,
					ProcessingTimeMs = result.ProcessingTimeMs,
					InputSourceToolName = source,
					MasterPositionToolName = "None",
					MasterAngleToolName = "None"
				});
				bool flag2 = result.IsSuccess && result.DefectAreas != null && result.DefectAreas.Count > 0;
				if (flag2)
				{
					for (int i = 0; i < result.DefectAreas.Count; i++)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName + " - Defect " + (i + 1).ToString(),
							Result = "Area: " + result.DefectAreas[i].ToString("0.###") + " px",
							Status = status,
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
				}
			}
		}

		// Token: 0x060017E3 RID: 6115 RVA: 0x0006E2F0 File Offset: 0x0006C4F0
		private void UpdateDeformableInspectionOutputResult(ToolVision tool, DeformableInspectionResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = true;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			this.CalibHandEyeOutputResults.Clear();
			this.ResultAlignOutputResults.Clear();
			this.ResultInspectionOutputResults.Clear();
			this.DeformableInspectionOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				bool flag2 = result.Metrics != null && result.Metrics.Count > 0;
				if (flag2)
				{
					foreach (DeformableMetricResult metric in result.Metrics)
					{
						this.DeformableInspectionOutputResults.Add(this.CreateDeformableInspectionOutputRow(toolName, result, metric.Name, metric.Value, metric.SpecEnabled, metric.SpecMin, metric.SpecMax, metric.Status));
					}
				}
				else
				{
					this.DeformableInspectionOutputResults.Add(this.CreateDeformableInspectionOutputRow(toolName, result, result.IsSuccess ? "Score" : "Result", result.Score, false, 0.0, 0.0, status));
				}
			}
		}

		// Token: 0x060017E4 RID: 6116 RVA: 0x0006E51C File Offset: 0x0006C71C
		private DeformableInspectionOutputResultRow CreateDeformableInspectionOutputRow(string toolName, DeformableInspectionResult result, string metricName, double value, bool specEnabled, double specMin, double specMax, string status)
		{
			return new DeformableInspectionOutputResultRow
			{
				ToolName = toolName,
				MetricName = metricName,
				Value = value,
				SpecEnabled = specEnabled,
				SpecMin = specMin,
				SpecMax = specMax,
				Status = this.NormalizeDisplayValue(status),
				Row = result.Row,
				Column = result.Column,
				Score = result.Score,
				MaxDeformation = result.MaxDeformation,
				MeanDeformation = result.MeanDeformation,
				DefectArea = result.DefectArea,
				InputSourceToolName = this.NormalizeDisplayValue(result.InputSourceToolName),
				InputProcessingTimeMs = result.InputProcessingTimeMs,
				ProcessingTimeMs = result.ProcessingTimeMs,
				TotalProcessingTimeMs = result.TotalProcessingTimeMs,
				Message = this.NormalizeDisplayValue(result.Message)
			};
		}

		// Token: 0x060017E5 RID: 6117 RVA: 0x0006E614 File Offset: 0x0006C814
		private void UpdateMatrixCodeOutputResult(ToolVision tool, MatrixCodeResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = false;
			this.IsRunAllOutputVisible = true;
			this.RunAllOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string type = this.NormalizeDisplayValue(result.DetectedTypeName);
				string source = this.NormalizeDisplayValue(result.InputSourceToolName);
				bool flag2 = result.IsSuccess && result.Symbols.Count > 0;
				if (flag2)
				{
					foreach (MatrixCodeSymbol symbol in result.Symbols)
					{
						this.RunAllOutputResults.Add(new RunAllOutputResultRow
						{
							ToolName = toolName,
							Result = "[" + type + "] " + (((symbol != null) ? symbol.DecodedText : null) ?? string.Empty),
							Status = "OK",
							ProcessingTimeMs = result.ProcessingTimeMs,
							InputSourceToolName = source,
							MasterPositionToolName = "None",
							MasterAngleToolName = "None"
						});
					}
				}
				else
				{
					this.RunAllOutputResults.Add(new RunAllOutputResultRow
					{
						ToolName = toolName,
						Result = "No code found",
						Status = "NG",
						ProcessingTimeMs = result.ProcessingTimeMs,
						InputSourceToolName = source,
						MasterPositionToolName = "None",
						MasterAngleToolName = "None"
					});
				}
			}
		}

		// Token: 0x060017E6 RID: 6118 RVA: 0x0006E824 File Offset: 0x0006CA24
		private void UpdateDLObjectInspectionOutputResult(ToolVision tool, DLObjectInspectionResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.IsDeformableInspectionOutputVisible = false;
			this.IsDLObjectInspectionOutputVisible = true;
			this.DLObjectInspectionOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string toolName = this.NormalizeDisplayValue((tool != null) ? tool.Name : null);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				this.DLObjectInspectionOutputResults.Add(new DLObjectInspectionOutputResultRow
				{
					ToolName = toolName,
					ClassName = "TOTAL",
					ObjectCount = result.ObjectCount,
					SpecEnabled = result.IsSpecEnabled,
					SpecMin = result.SpecMin,
					SpecMax = result.SpecMax,
					Status = this.NormalizeDisplayValue(status),
					InputSourceToolName = this.NormalizeDisplayValue(result.InputSourceToolName),
					ProcessingTimeMs = result.ProcessingTimeMs,
					TotalProcessingTimeMs = result.TotalProcessingTimeMs,
					Message = this.NormalizeDisplayValue(result.Message)
				});
				foreach (DLDetectedObject obj in result.Objects)
				{
					this.DLObjectInspectionOutputResults.Add(new DLObjectInspectionOutputResultRow
					{
						ToolName = toolName,
						ClassName = this.NormalizeDisplayValue(obj.ClassName),
						Confidence = obj.Confidence,
						X1 = obj.X1,
						Y1 = obj.Y1,
						X2 = obj.X2,
						Y2 = obj.Y2,
						ObjectCount = result.ObjectCount,
						SpecEnabled = result.IsSpecEnabled,
						SpecMin = result.SpecMin,
						SpecMax = result.SpecMax,
						Status = "OK",
						InputSourceToolName = this.NormalizeDisplayValue(result.InputSourceToolName),
						ProcessingTimeMs = result.ProcessingTimeMs,
						TotalProcessingTimeMs = result.TotalProcessingTimeMs,
						Message = ""
					});
				}
			}
		}

		// Token: 0x060017E7 RID: 6119 RVA: 0x0006EAD4 File Offset: 0x0006CCD4
		private void UpdateCalibHandEyeOutputResult(CalibHandEyeResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = true;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			this.CalibHandEyeOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				bool flag2 = result.Objects != null && result.Objects.Count > 0;
				if (flag2)
				{
					foreach (CalibHandEyeObjectResult obj in result.Objects)
					{
						this.CalibHandEyeOutputResults.Add(new CalibHandEyeOutputResultRow
						{
							ToolName = this.NormalizeDisplayValue(result.ToolName) + ((result.ObjectMode == CalibHandEyeObjectMode.MultiObject) ? string.Concat(new string[]
							{
								" [",
								obj.GridRow.ToString(),
								",",
								obj.GridColumn.ToString(),
								"]",
								obj.Picked ? " *" : string.Empty
							}) : string.Empty),
							MasterToolName = this.NormalizeDisplayValue(result.MasterToolName),
							PixelRow = obj.PixelRow,
							PixelColumn = obj.PixelColumn,
							RobotX = obj.RobotX,
							RobotY = obj.RobotY,
							AngleDeg = obj.AngleDeg,
							VisionAngleDeg = obj.VisionAngleDeg,
							MappedVisionAngleDeg = obj.MappedVisionAngleDeg,
							AngleOffsetDeg = obj.AngleOffsetDeg,
							UsedTcpOffset = obj.UsedTcpOffset,
							TcpPixelRow = obj.TcpPixelRow,
							TcpPixelColumn = obj.TcpPixelColumn,
							MasterTcpPixelRow = obj.MasterTcpPixelRow,
							MasterTcpPixelColumn = obj.MasterTcpPixelColumn,
							MasterRobotX = obj.MasterRobotX,
							MasterRobotY = obj.MasterRobotY,
							HasDelta = obj.HasDelta,
							DeltaRobotX = obj.DeltaRobotX,
							DeltaRobotY = obj.DeltaRobotY,
							DeltaAngleDeg = obj.DeltaAngleDeg,
							Score = obj.Score,
							Status = (result.IsSuccess ? "OK" : "NG"),
							MasterProcessingTimeMs = result.MasterProcessingTimeMs,
							ProcessingTimeMs = result.ProcessingTimeMs,
							TotalProcessingTimeMs = result.TotalProcessingTimeMs,
							CalibrationFilePath = this.NormalizeDisplayValue(result.CalibrationFilePath)
						});
					}
				}
				else
				{
					this.CalibHandEyeOutputResults.Add(new CalibHandEyeOutputResultRow
					{
						ToolName = this.NormalizeDisplayValue(result.ToolName),
						MasterToolName = this.NormalizeDisplayValue(result.MasterToolName),
						PixelRow = result.PixelRow,
						PixelColumn = result.PixelColumn,
						RobotX = result.RobotX,
						RobotY = result.RobotY,
						AngleDeg = result.AngleDeg,
						VisionAngleDeg = result.VisionAngleDeg,
						MappedVisionAngleDeg = result.MappedVisionAngleDeg,
						AngleOffsetDeg = result.AngleOffsetDeg,
						UsedTcpOffset = result.UsedTcpOffset,
						TcpPixelRow = result.TcpPixelRow,
						TcpPixelColumn = result.TcpPixelColumn,
						MasterTcpPixelRow = result.MasterTcpPixelRow,
						MasterTcpPixelColumn = result.MasterTcpPixelColumn,
						MasterRobotX = result.MasterRobotX,
						MasterRobotY = result.MasterRobotY,
						HasDelta = result.HasDelta,
						DeltaRobotX = result.DeltaRobotX,
						DeltaRobotY = result.DeltaRobotY,
						DeltaAngleDeg = result.DeltaAngleDeg,
						Score = result.Score,
						Status = (result.IsSuccess ? "OK" : "NG"),
						MasterProcessingTimeMs = result.MasterProcessingTimeMs,
						ProcessingTimeMs = result.ProcessingTimeMs,
						TotalProcessingTimeMs = result.TotalProcessingTimeMs,
						CalibrationFilePath = this.NormalizeDisplayValue(result.CalibrationFilePath)
					});
				}
			}
		}

		// Token: 0x060017E8 RID: 6120 RVA: 0x0006EFD0 File Offset: 0x0006D1D0
		private void UpdateResultAlignOutputResult(CalibResultAlignResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = true;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			this.CalibHandEyeOutputResults.Clear();
			this.ResultAlignOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				string status = result.IsSuccess ? "OK" : "NG";
				foreach (CalibResultAlignItem item in result.Items)
				{
					this.ResultAlignOutputResults.Add(new ResultAlignOutputResultRow
					{
						AlignToolName = this.NormalizeDisplayValue(result.ToolName),
						SourceToolName = this.NormalizeDisplayValue(item.SourceToolName) + (item.Picked ? " *" : string.Empty),
						OutputOrder = item.Index,
						GridRow = item.GridRow,
						GridColumn = item.GridColumn,
						PixelRow = item.PixelRow,
						PixelColumn = item.PixelColumn,
						RobotX = item.RobotX,
						RobotY = item.RobotY,
						AngleDeg = item.AngleDeg,
						DeltaRobotX = item.DeltaRobotX,
						DeltaRobotY = item.DeltaRobotY,
						DeltaAngleDeg = item.DeltaAngleDeg,
						Score = item.Score,
						Status = status,
						ProcessingTimeMs = result.ProcessingTimeMs,
						TotalProcessingTimeMs = result.TotalProcessingTimeMs
					});
				}
				bool flag2 = this.ResultAlignOutputResults.Count == 0;
				if (flag2)
				{
					this.ResultAlignOutputResults.Add(new ResultAlignOutputResultRow
					{
						AlignToolName = this.NormalizeDisplayValue(result.ToolName),
						SourceToolName = this.NormalizeDisplayValue(result.Message),
						Status = status,
						ProcessingTimeMs = result.ProcessingTimeMs,
						TotalProcessingTimeMs = result.TotalProcessingTimeMs
					});
				}
			}
		}

		// Token: 0x060017E9 RID: 6121 RVA: 0x0006F29C File Offset: 0x0006D49C
		private void UpdateResultInspectionOutputResult(CalibResultInspectionResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = true;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			this.CalibHandEyeOutputResults.Clear();
			this.ResultAlignOutputResults.Clear();
			this.ResultInspectionOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				this.ResultInspectionOutputResults.Add(new ResultInspectionOutputResultRow
				{
					ToolName = this.NormalizeDisplayValue(result.ToolName),
					SourceToolName = "(Overall)",
					Value = string.Empty,
					Spec = string.Empty,
					Status = result.Overall,
					Detail = result.Message,
					TotalProcessingTimeMs = result.TotalProcessingTimeMs
				});
				foreach (CalibResultInspectionItem item in result.Items)
				{
					this.ResultInspectionOutputResults.Add(new ResultInspectionOutputResultRow
					{
						ToolName = this.NormalizeDisplayValue(result.ToolName),
						SourceToolName = this.NormalizeDisplayValue(item.SourceToolName),
						Value = (item.HasValue ? this.NormalizeDisplayValue(item.ValueText) : string.Empty),
						Spec = this.NormalizeDisplayValue(item.SpecText),
						Status = (item.Evaluated ? item.Status : (item.Status ?? "N/A")),
						Detail = item.Detail,
						TotalProcessingTimeMs = result.TotalProcessingTimeMs
					});
				}
			}
		}

		// Token: 0x060017EA RID: 6122 RVA: 0x0006F4F8 File Offset: 0x0006D6F8
		private void UpdateBlobOutputResult(ToolVision tool, BlobProcessResult blobResult)
		{
			this.IsBlobOutputVisible = true;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = blobResult.RoiResults == null;
			if (!flag)
			{
				int roiIndex = 1;
				foreach (BlobRoiResult roiResult in blobResult.RoiResults)
				{
					string roiName = null;
					bool flag2 = roiResult.Roi != null;
					if (flag2)
					{
						roiName = roiResult.Roi.DisplayName;
					}
					bool flag3 = string.IsNullOrWhiteSpace(roiName);
					if (flag3)
					{
						roiName = "ROI " + roiIndex.ToString();
					}
					this.BlobOutputResults.Add(new BlobOutputResultRow
					{
						RoiName = roiName,
						RoiValue = roiResult.Value,
						TotalValue = blobResult.TotalValue,
						RoiProcessingTimeMs = roiResult.ProcessingTimeMs,
						TotalProcessingTimeMs = blobResult.TotalProcessingTimeMs,
						Status = (roiResult.IsOk ? "OK" : "NG"),
						MasterPositionToolName = this.NormalizeDisplayValue(roiResult.MasterPositionToolName),
						MasterAngleToolName = this.NormalizeDisplayValue(roiResult.MasterAngleToolName),
						MasterStatus = roiResult.MasterStatus,
						MasterStatusBrush = this.GetMasterStatusBrush(roiResult.MasterStatus),
						MasterProcessingTimeMs = roiResult.MasterProcessingTimeMs,
						InputSourceToolName = this.NormalizeDisplayValue(blobResult.InputSourceToolName),
						InputProcessingTimeMs = blobResult.InputProcessingTimeMs
					});
					roiIndex++;
				}
			}
		}

		// Token: 0x060017EB RID: 6123 RVA: 0x0006F730 File Offset: 0x0006D930
		private void UpdateShapeModelOutputResult(ShapeMatchResult shapeResult)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = true;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = shapeResult == null;
			if (!flag)
			{
				IntersectingLinesResult intersectingResult = shapeResult as IntersectingLinesResult;
				bool showIntersectingLineDelta = intersectingResult != null && intersectingResult.DisplayDeltaFromMaster && intersectingResult.HasMasterDefined;
				bool flag2 = !showIntersectingLineDelta && shapeResult.Matches != null && shapeResult.Matches.Count > 0;
				if (flag2)
				{
					foreach (ShapeMatchCandidate match in from item in shapeResult.Matches
					orderby (item.Order > 0) ? item.Order : (item.Index + 1), item.GridRow, item.GridColumn
					select item)
					{
						bool isPicked = Form_setting.IsPickedShapeMatch(match, shapeResult);
						ProcedureModelMatchCandidate procedureMatch = match as ProcedureModelMatchCandidate;
						this.ShapeModelOutputResults.Add(new ShapeModelOutputResultRow
						{
							RoiName = this.NormalizeDisplayValue(shapeResult.RoiName),
							MatchIndex = ((match.Order > 0) ? match.Order : (match.Index + 1)),
							MatchRow = match.GridRow,
							MatchColumn = match.GridColumn,
							Picked = (isPicked ? "Picked" : string.Empty),
							Layer = (((procedureMatch != null) ? procedureMatch.LayerText : null) ?? string.Empty),
							Rank = ((procedureMatch != null) ? procedureMatch.Rank : 0),
							ContactCount = ((procedureMatch != null) ? procedureMatch.ContactCount : 0),
							Row = match.Row,
							Column = match.Column,
							Angle = Form_setting.RadiansToDegrees(match.Angle),
							DeltaRow = (match.HasDelta ? new double?(match.DeltaRow) : (isPicked ? new double?(shapeResult.DeltaRow) : null)),
							DeltaColumn = (match.HasDelta ? new double?(match.DeltaColumn) : (isPicked ? new double?(shapeResult.DeltaColumn) : null)),
							DeltaAngle = (match.HasDelta ? new double?(Form_setting.RadiansToDegrees(match.DeltaAngle)) : (isPicked ? new double?(Form_setting.RadiansToDegrees(shapeResult.DeltaAngle)) : null)),
							Score = match.Score,
							ProcessingTimeMs = shapeResult.ProcessingTimeMs,
							InputSourceToolName = this.NormalizeDisplayValue(shapeResult.InputSourceToolName),
							InputProcessingTimeMs = shapeResult.InputProcessingTimeMs,
							RowBrush = (isPicked ? new SolidColorBrush(Color.FromRgb(31, 92, 48)) : Brushes.Transparent),
							TextBrush = Brushes.White
						});
					}
				}
				else
				{
					this.ShapeModelOutputResults.Add(new ShapeModelOutputResultRow
					{
						RoiName = this.NormalizeDisplayValue(showIntersectingLineDelta ? (shapeResult.RoiName + " Delta") : shapeResult.RoiName),
						MatchIndex = (shapeResult.IsSuccess ? 1 : 0),
						MatchRow = shapeResult.GridRow,
						MatchColumn = shapeResult.GridColumn,
						Picked = (shapeResult.IsSuccess ? "Picked" : string.Empty),
						Row = (showIntersectingLineDelta ? shapeResult.DeltaRow : shapeResult.Row),
						Column = (showIntersectingLineDelta ? shapeResult.DeltaColumn : shapeResult.Column),
						Angle = (showIntersectingLineDelta ? Form_setting.RadiansToDegrees(shapeResult.DeltaAngle) : Form_setting.RadiansToDegrees(shapeResult.Angle)),
						DeltaRow = new double?(shapeResult.DeltaRow),
						DeltaColumn = new double?(shapeResult.DeltaColumn),
						DeltaAngle = new double?(Form_setting.RadiansToDegrees(shapeResult.DeltaAngle)),
						Score = shapeResult.Score,
						ProcessingTimeMs = shapeResult.ProcessingTimeMs,
						InputSourceToolName = this.NormalizeDisplayValue(shapeResult.InputSourceToolName),
						InputProcessingTimeMs = shapeResult.InputProcessingTimeMs,
						RowBrush = Brushes.Transparent,
						TextBrush = Brushes.White
					});
				}
			}
		}

		// Token: 0x060017EC RID: 6124 RVA: 0x0006FC74 File Offset: 0x0006DE74
		private static bool IsPickedShapeMatch(ShapeMatchCandidate match, ShapeMatchResult shapeResult)
		{
			bool flag = match == null || shapeResult == null;
			return !flag && (Math.Abs(match.Row - shapeResult.Row) <= 0.001 && Math.Abs(match.Column - shapeResult.Column) <= 0.001) && Math.Abs(match.Score - shapeResult.Score) <= 0.001;
		}

		// Token: 0x060017ED RID: 6125 RVA: 0x0006FCF8 File Offset: 0x0006DEF8
		private void UpdateHistogramOutputResult(ToolVision tool, HistogramProcessResult histogramResult)
		{
			this.IsBlobOutputVisible = true;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = histogramResult.RoiResults == null;
			if (!flag)
			{
				int roiIndex = 1;
				foreach (HistogramRoiResult roiResult in histogramResult.RoiResults)
				{
					string roiName = null;
					bool flag2 = roiResult.Roi != null;
					if (flag2)
					{
						roiName = roiResult.Roi.DisplayName;
					}
					bool flag3 = string.IsNullOrWhiteSpace(roiName);
					if (flag3)
					{
						roiName = "ROI " + roiIndex.ToString();
					}
					this.BlobOutputResults.Add(new BlobOutputResultRow
					{
						RoiName = roiName,
						RoiValue = roiResult.Value,
						TotalValue = histogramResult.TotalValue,
						RoiProcessingTimeMs = roiResult.ProcessingTimeMs,
						TotalProcessingTimeMs = histogramResult.TotalProcessingTimeMs,
						Status = (histogramResult.IsOk ? "OK" : "NG"),
						MasterPositionToolName = this.NormalizeDisplayValue(roiResult.MasterPositionToolName),
						MasterAngleToolName = this.NormalizeDisplayValue(roiResult.MasterAngleToolName),
						MasterStatus = roiResult.MasterStatus,
						MasterStatusBrush = this.GetMasterStatusBrush(roiResult.MasterStatus),
						MasterProcessingTimeMs = roiResult.MasterProcessingTimeMs,
						InputSourceToolName = this.NormalizeDisplayValue(histogramResult.InputSourceToolName),
						InputProcessingTimeMs = histogramResult.InputProcessingTimeMs
					});
					roiIndex++;
				}
			}
		}

		// Token: 0x060017EE RID: 6126 RVA: 0x0006FF30 File Offset: 0x0006E130
		private void UpdateHistogramColorOutputResult(ToolVision tool, HistogramColorProcessResult histogramResult)
		{
			this.IsBlobOutputVisible = true;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = histogramResult.RoiResults == null;
			if (!flag)
			{
				int roiIndex = 1;
				foreach (HistogramColorRoiResult roiResult in histogramResult.RoiResults)
				{
					string roiName = null;
					bool flag2 = roiResult.Roi != null;
					if (flag2)
					{
						roiName = roiResult.Roi.DisplayName;
					}
					bool flag3 = string.IsNullOrWhiteSpace(roiName);
					if (flag3)
					{
						roiName = "ROI " + roiIndex.ToString();
					}
					this.BlobOutputResults.Add(new BlobOutputResultRow
					{
						RoiName = roiName,
						RoiValue = roiResult.Value,
						TotalValue = histogramResult.TotalValue,
						RoiProcessingTimeMs = roiResult.ProcessingTimeMs,
						TotalProcessingTimeMs = histogramResult.TotalProcessingTimeMs,
						Status = (histogramResult.IsOk ? "OK" : "NG"),
						MasterPositionToolName = this.NormalizeDisplayValue(roiResult.MasterPositionToolName),
						MasterAngleToolName = this.NormalizeDisplayValue(roiResult.MasterAngleToolName),
						MasterStatus = roiResult.MasterStatus,
						MasterStatusBrush = this.GetMasterStatusBrush(roiResult.MasterStatus),
						MasterProcessingTimeMs = roiResult.MasterProcessingTimeMs,
						InputSourceToolName = this.NormalizeDisplayValue(histogramResult.InputSourceToolName),
						InputProcessingTimeMs = histogramResult.InputProcessingTimeMs
					});
					roiIndex++;
				}
			}
		}

		// Token: 0x060017EF RID: 6127 RVA: 0x00070168 File Offset: 0x0006E368
		private void UpdateFindLineOutputResult(FindLineResult findLineResult)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = true;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = findLineResult == null;
			if (!flag)
			{
				this.FindLineOutputResults.Add(new FindLineOutputResultRow
				{
					ToolName = this.NormalizeDisplayValue(findLineResult.ToolName),
					StartRow = findLineResult.StartRow,
					StartColumn = findLineResult.StartColumn,
					EndRow = findLineResult.EndRow,
					EndColumn = findLineResult.EndColumn,
					MasterPositionToolName = this.NormalizeDisplayValue(findLineResult.MasterPositionToolName),
					MasterAngleToolName = this.NormalizeDisplayValue(findLineResult.MasterAngleToolName),
					MasterProcessingTimeMs = findLineResult.MasterProcessingTimeMs,
					InputSourceToolName = this.NormalizeDisplayValue(findLineResult.InputSourceToolName),
					InputProcessingTimeMs = findLineResult.InputProcessingTimeMs,
					ProcessingTimeMs = findLineResult.ProcessingTimeMs,
					TotalProcessingTimeMs = findLineResult.TotalProcessingTimeMs
				});
			}
		}

		// Token: 0x060017F0 RID: 6128 RVA: 0x000702E8 File Offset: 0x0006E4E8
		private void UpdateFindCircleOutputResult(FindCircleResult findCircleResult)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = true;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = findCircleResult == null;
			if (!flag)
			{
				this.FindCircleOutputResults.Add(new FindCircleOutputResultRow
				{
					ToolName = this.NormalizeDisplayValue(findCircleResult.ToolName),
					RoiName = this.NormalizeDisplayValue(findCircleResult.RoiName),
					Row = findCircleResult.Row,
					Column = findCircleResult.Column,
					Radius = findCircleResult.Radius,
					MasterPositionToolName = this.NormalizeDisplayValue(findCircleResult.MasterPositionToolName),
					MasterAngleToolName = this.NormalizeDisplayValue(findCircleResult.MasterAngleToolName),
					MasterProcessingTimeMs = findCircleResult.MasterProcessingTimeMs,
					InputSourceToolName = this.NormalizeDisplayValue(findCircleResult.InputSourceToolName),
					InputProcessingTimeMs = findCircleResult.InputProcessingTimeMs,
					ProcessingTimeMs = findCircleResult.ProcessingTimeMs,
					TotalProcessingTimeMs = findCircleResult.TotalProcessingTimeMs
				});
			}
		}

		// Token: 0x060017F1 RID: 6129 RVA: 0x00070470 File Offset: 0x0006E670
		private void UpdateFindBoundingBoxOutputResult(FindBoundingBoxResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = true;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = result == null || result.Candidates == null;
			if (!flag)
			{
				foreach (FindBoundingBoxCandidate box in from x in result.Candidates
				orderby x.GridRow, x.GridColumn
				select x)
				{
					FindBoundingBoxPointSet points = box.Points;
					bool isSelected = box == result.SelectedBox;
					this.FindBoundingBoxOutputResults.Add(new FindBoundingBoxOutputResultRow
					{
						ToolName = this.NormalizeDisplayValue(result.ToolName),
						RoiName = this.NormalizeDisplayValue(result.RoiName),
						IsSelected = isSelected,
						GridRow = box.GridRow,
						GridColumn = box.GridColumn,
						CenterRow = points.CenterRow,
						CenterColumn = points.CenterColumn,
						TopLeftRow = points.TopLeftRow,
						TopLeftColumn = points.TopLeftColumn,
						TopRightRow = points.TopRightRow,
						TopRightColumn = points.TopRightColumn,
						BottomRightRow = points.BottomRightRow,
						BottomRightColumn = points.BottomRightColumn,
						BottomLeftRow = points.BottomLeftRow,
						BottomLeftColumn = points.BottomLeftColumn,
						Angle = 0.0,
						Width = box.Width,
						Height = box.Height,
						Area = box.Area,
						InputSourceToolName = this.NormalizeDisplayValue(result.InputSourceToolName),
						InputProcessingTimeMs = result.InputProcessingTimeMs,
						ProcessingTimeMs = result.ProcessingTimeMs,
						TotalProcessingTimeMs = result.TotalProcessingTimeMs
					});
				}
			}
		}

		// Token: 0x060017F2 RID: 6130 RVA: 0x0007072C File Offset: 0x0006E92C
		private void UpdateFindMinAreaOutputResult(FindMinAreaResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = true;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = result == null || result.Candidates == null;
			if (!flag)
			{
				foreach (FindMinAreaCandidate box in from x in result.Candidates
				orderby x.GridRow, x.GridColumn
				select x)
				{
					FindMinAreaPointSet points = box.Points;
					bool isSelected = box == result.SelectedBox;
					this.FindBoundingBoxOutputResults.Add(new FindBoundingBoxOutputResultRow
					{
						ToolName = this.NormalizeDisplayValue(result.ToolName),
						RoiName = this.NormalizeDisplayValue(result.RoiName),
						IsSelected = isSelected,
						GridRow = box.GridRow,
						GridColumn = box.GridColumn,
						CenterRow = points.CenterRow,
						CenterColumn = points.CenterColumn,
						TopLeftRow = points.TopLeftRow,
						TopLeftColumn = points.TopLeftColumn,
						TopRightRow = points.TopRightRow,
						TopRightColumn = points.TopRightColumn,
						BottomRightRow = points.BottomRightRow,
						BottomRightColumn = points.BottomRightColumn,
						BottomLeftRow = points.BottomLeftRow,
						BottomLeftColumn = points.BottomLeftColumn,
						Angle = box.AngleDegree,
						Width = box.Width,
						Height = box.Height,
						Area = box.Area,
						InputSourceToolName = this.NormalizeDisplayValue(result.InputSourceToolName),
						InputProcessingTimeMs = result.InputProcessingTimeMs,
						ProcessingTimeMs = result.ProcessingTimeMs,
						TotalProcessingTimeMs = result.TotalProcessingTimeMs
					});
				}
			}
		}

		// Token: 0x060017F3 RID: 6131 RVA: 0x000709E8 File Offset: 0x0006EBE8
		private string NormalizeDisplayValue(string value)
		{
			return string.IsNullOrWhiteSpace(value) ? "None" : value;
		}

		// Token: 0x060017F4 RID: 6132 RVA: 0x00070A0C File Offset: 0x0006EC0C
		private void OutputResultGridHost_Loaded(object sender, RoutedEventArgs e)
		{
			DependencyObject root = sender as DependencyObject;
			bool flag = root == null;
			if (!flag)
			{
				foreach (GridControl grid in this.FindVisualChildren<GridControl>(root))
				{
					bool flag2 = grid.ContextMenu != null;
					if (!flag2)
					{
						ContextMenu menu = new ContextMenu();
						MenuItem copyItem = new MenuItem
						{
							Header = "Copy"
						};
						copyItem.Click += this.CopyOutputResult_Click;
						menu.Items.Add(copyItem);
						grid.ContextMenu = menu;
					}
				}
			}
		}

		// Token: 0x060017F5 RID: 6133 RVA: 0x00070AC4 File Offset: 0x0006ECC4
		private IEnumerable<T> FindVisualChildren<T>(DependencyObject parent) where T : DependencyObject
		{
			Form_setting.<FindVisualChildren>d__258<T> <FindVisualChildren>d__ = new Form_setting.<FindVisualChildren>d__258<T>(-2);
			<FindVisualChildren>d__.<>4__this = this;
			<FindVisualChildren>d__.<>3__parent = parent;
			return <FindVisualChildren>d__;
		}

		// Token: 0x060017F6 RID: 6134 RVA: 0x00070ADC File Offset: 0x0006ECDC
		private void CopyOutputResult_Click(object sender, RoutedEventArgs e)
		{
			List<object> rows = this.GetVisibleOutputResultRows().ToList<object>();
			bool flag = rows.Count == 0;
			if (flag)
			{
				DXMessageBox.Show("No output result to copy.", "Copy Output Result", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				string text = this.BuildTabSeparatedOutput(rows);
				bool flag2 = string.IsNullOrWhiteSpace(text);
				if (flag2)
				{
					DXMessageBox.Show("No copyable output result was found.", "Copy Output Result", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					Clipboard.SetText(text, TextDataFormat.UnicodeText);
				}
			}
		}

		// Token: 0x060017F7 RID: 6135 RVA: 0x00070B4C File Offset: 0x0006ED4C
		private IEnumerable<object> GetVisibleOutputResultRows()
		{
			bool isBlobOutputVisible = this.IsBlobOutputVisible;
			IEnumerable<object> result;
			if (isBlobOutputVisible)
			{
				result = this.BlobOutputResults.Cast<object>();
			}
			else
			{
				bool isShapeModelOutputVisible = this.IsShapeModelOutputVisible;
				if (isShapeModelOutputVisible)
				{
					result = this.ShapeModelOutputResults.Cast<object>();
				}
				else
				{
					bool isFindLineOutputVisible = this.IsFindLineOutputVisible;
					if (isFindLineOutputVisible)
					{
						result = this.FindLineOutputResults.Cast<object>();
					}
					else
					{
						bool isFindCircleOutputVisible = this.IsFindCircleOutputVisible;
						if (isFindCircleOutputVisible)
						{
							result = this.FindCircleOutputResults.Cast<object>();
						}
						else
						{
							bool isFindBoundingBoxOutputVisible = this.IsFindBoundingBoxOutputVisible;
							if (isFindBoundingBoxOutputVisible)
							{
								result = this.FindBoundingBoxOutputResults.Cast<object>();
							}
							else
							{
								bool isRunAllOutputVisible = this.IsRunAllOutputVisible;
								if (isRunAllOutputVisible)
								{
									result = this.RunAllOutputResults.Cast<object>();
								}
								else
								{
									bool isDistanceObjectOutputVisible = this.IsDistanceObjectOutputVisible;
									if (isDistanceObjectOutputVisible)
									{
										result = this.DistanceObjectOutputResults.Cast<object>();
									}
									else
									{
										bool isMeasureCircleOutputVisible = this.IsMeasureCircleOutputVisible;
										if (isMeasureCircleOutputVisible)
										{
											result = this.MeasureCircleOutputResults.Cast<object>();
										}
										else
										{
											bool isDeformableInspectionOutputVisible = this.IsDeformableInspectionOutputVisible;
											if (isDeformableInspectionOutputVisible)
											{
												result = this.DeformableInspectionOutputResults.Cast<object>();
											}
											else
											{
												bool isCalibHandEyeOutputVisible = this.IsCalibHandEyeOutputVisible;
												if (isCalibHandEyeOutputVisible)
												{
													result = this.CalibHandEyeOutputResults.Cast<object>();
												}
												else
												{
													bool isResultAlignOutputVisible = this.IsResultAlignOutputVisible;
													if (isResultAlignOutputVisible)
													{
														result = this.ResultAlignOutputResults.Cast<object>();
													}
													else
													{
														bool isResultInspectionOutputVisible = this.IsResultInspectionOutputVisible;
														if (isResultInspectionOutputVisible)
														{
															result = this.ResultInspectionOutputResults.Cast<object>();
														}
														else
														{
															result = Enumerable.Empty<object>();
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060017F8 RID: 6136 RVA: 0x00070CAC File Offset: 0x0006EEAC
		private string BuildTabSeparatedOutput(IList<object> rows)
		{
			bool flag = rows == null || rows.Count == 0;
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				List<PropertyDescriptor> properties = TypeDescriptor.GetProperties(rows[0]).Cast<PropertyDescriptor>().Where(new Func<PropertyDescriptor, bool>(this.IsCopyableOutputProperty)).ToList<PropertyDescriptor>();
				bool flag2 = properties.Count == 0;
				if (flag2)
				{
					result = string.Empty;
				}
				else
				{
					StringBuilder builder = new StringBuilder();
					builder.AppendLine(string.Join("\t", from p in properties
					select p.DisplayName ?? p.Name));
					using (IEnumerator<object> enumerator = rows.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							object row = enumerator.Current;
							IEnumerable<string> values = from p in properties
							select this.FormatOutputCopyValue(p.GetValue(row));
							builder.AppendLine(string.Join("\t", values));
						}
					}
					result = builder.ToString();
				}
			}
			return result;
		}

		// Token: 0x060017F9 RID: 6137 RVA: 0x00070DDC File Offset: 0x0006EFDC
		private bool IsCopyableOutputProperty(PropertyDescriptor property)
		{
			bool flag = property == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = typeof(Brush).IsAssignableFrom(property.PropertyType);
				result = (!flag2 && (!string.Equals(property.Name, "RowBrush", StringComparison.OrdinalIgnoreCase) && !string.Equals(property.Name, "TextBrush", StringComparison.OrdinalIgnoreCase) && !string.Equals(property.Name, "StatusBrush", StringComparison.OrdinalIgnoreCase) && !string.Equals(property.Name, "SpecStatusBrush", StringComparison.OrdinalIgnoreCase)) && !string.Equals(property.Name, "MasterStatusBrush", StringComparison.OrdinalIgnoreCase));
			}
			return result;
		}

		// Token: 0x060017FA RID: 6138 RVA: 0x00070E80 File Offset: 0x0006F080
		private string FormatOutputCopyValue(object value)
		{
			bool flag = value == null;
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				IFormattable formattable = value as IFormattable;
				string text = (formattable != null) ? formattable.ToString(null, CultureInfo.InvariantCulture) : value.ToString();
				result = (text ?? string.Empty).Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
			}
			return result;
		}

		// Token: 0x060017FB RID: 6139 RVA: 0x00070EF8 File Offset: 0x0006F0F8
		private void UpdateDistanceObjectOutputResult(DistanceObjectResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = true;
			this.IsMeasureCircleOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				this.DistanceObjectOutputResults.Add(new DistanceObjectOutputResultRow
				{
					Object1ToolName = this.NormalizeDisplayValue(result.Object1ToolName),
					Object2ToolName = this.NormalizeDisplayValue(result.Object2ToolName),
					Object1Feature = result.Object1Feature.ToString(),
					Object2Feature = result.Object2Feature.ToString(),
					MeasurementMode = result.MeasurementMode.ToString(),
					Distance = result.Distance,
					DistanceMm = (result.IsCalibrationApplied ? result.CalibratedDistanceMm : 0.0),
					MillimetersPerPixel = result.MillimetersPerPixel,
					SpecStatus = this.NormalizeDisplayValue(result.SpecStatus),
					SpecMinimumMm = result.SpecMinimumMm,
					SpecMaximumMm = result.SpecMaximumMm,
					Object1ProcessingTimeMs = result.Object1ProcessingTimeMs,
					Object2ProcessingTimeMs = result.Object2ProcessingTimeMs,
					TotalProcessingTimeMs = result.TotalProcessingTimeMs
				});
			}
		}

		// Token: 0x060017FC RID: 6140 RVA: 0x000710CC File Offset: 0x0006F2CC
		private void UpdateMeasureCircleOutputResult(MeasureCircleResult result)
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = false;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = true;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			bool flag = result == null;
			if (!flag)
			{
				this.MeasureCircleOutputResults.Add(new MeasureCircleOutputResultRow
				{
					RoiName = this.NormalizeDisplayValue(result.RoiName),
					MeasureMode = result.MeasureMode.ToString(),
					Row = result.Row,
					Column = result.Column,
					Radius = result.Radius,
					Diameter = result.Diameter,
					PixelValue = result.MeasuredPixelValue,
					ValueMm = (result.IsCalibrationApplied ? result.MeasuredValueMm : 0.0),
					SpecStatus = this.NormalizeDisplayValue(result.SpecStatus),
					InputSourceToolName = this.NormalizeDisplayValue(result.InputSourceToolName),
					InputProcessingTimeMs = result.InputProcessingTimeMs,
					ProcessingTimeMs = result.ProcessingTimeMs,
					TotalProcessingTimeMs = result.TotalProcessingTimeMs
				});
			}
		}

		// Token: 0x060017FD RID: 6141 RVA: 0x00071274 File Offset: 0x0006F474
		private void RunSelectedTurnSnap()
		{
			TurnSnap turnSnap = this._turnSnapService.GetSelectedTurnSnap();
			bool flag = turnSnap == null || turnSnap.Tools == null || turnSnap.Tools.Count == 0;
			if (flag)
			{
				DXMessageBox.Show("No TurnSnap is selected or the selected TurnSnap has no tools.");
			}
			else
			{
				HObject original = null;
				ImageBufferStore bufferStore = null;
				RunAllOverlayState overlayState = null;
				bool overlayStateTransferred = false;
				try
				{
					original = this._displayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						DXMessageBox.Show("No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						overlayState = new RunAllOverlayState();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore,
							ResultStore = new ToolResultStore()
						};
						this.ShowRunAllOutputResult();
						Stopwatch turnSnapStopwatch = Stopwatch.StartNew();
						foreach (ToolVision tool in turnSnap.Tools)
						{
							bool flag3 = tool == null || !tool.IsEnabled;
							if (!flag3)
							{
								try
								{
									this.RunToolForRunAll(processContext, tool, overlayState);
								}
								catch (Exception ex)
								{
									this.AddRunAllOutputRow(tool.Name, ex.Message, "Error", 0.0, this.GetInputSourceToolName(tool), "None", "None");
								}
							}
						}
						turnSnapStopwatch.Stop();
						this.UpdateRunAllTurnSnapProcessingTime(turnSnapStopwatch.Elapsed.TotalMilliseconds);
						this._displayController.DisplayImage(original);
						this._displayController.SetOverlayRenderer(delegate(HWindow window)
						{
							this.DrawRunAllOverlays(window, overlayState);
						}, overlayState);
						overlayStateTransferred = true;
					}
				}
				finally
				{
					bool flag4 = !overlayStateTransferred;
					if (flag4)
					{
						RunAllOverlayState overlayState2 = overlayState;
						if (overlayState2 != null)
						{
							overlayState2.Dispose();
						}
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x060017FE RID: 6142 RVA: 0x000714CC File Offset: 0x0006F6CC
		private void ShowRunAllOutputResult()
		{
			this.IsBlobOutputVisible = false;
			this.IsShapeModelOutputVisible = false;
			this.IsFindLineOutputVisible = false;
			this.IsFindCircleOutputVisible = false;
			this.IsFindBoundingBoxOutputVisible = false;
			this.IsRunAllOutputVisible = true;
			this.IsDistanceObjectOutputVisible = false;
			this.IsMeasureCircleOutputVisible = false;
			this.IsCalibHandEyeOutputVisible = false;
			this.IsResultAlignOutputVisible = false;
			this.IsResultInspectionOutputVisible = false;
			this.BlobOutputResults.Clear();
			this.ShapeModelOutputResults.Clear();
			this.FindLineOutputResults.Clear();
			this.FindCircleOutputResults.Clear();
			this.FindBoundingBoxOutputResults.Clear();
			this.RunAllOutputResults.Clear();
			this.DistanceObjectOutputResults.Clear();
			this.MeasureCircleOutputResults.Clear();
			this.CalibHandEyeOutputResults.Clear();
			this.ResultAlignOutputResults.Clear();
			this.ResultInspectionOutputResults.Clear();
		}

		// Token: 0x060017FF RID: 6143 RVA: 0x000715B8 File Offset: 0x0006F7B8
		private static void PublishRunAllResultsToStore(ToolProcessContext processContext, RunAllOverlayState overlayState)
		{
			bool flag = ((processContext != null) ? processContext.ResultStore : null) == null || ((overlayState != null) ? overlayState.Results : null) == null;
			if (!flag)
			{
				foreach (RunAllToolOverlayResult prior in overlayState.Results)
				{
					bool flag2 = ((prior != null) ? prior.Tool : null) != null && prior.Result != null;
					if (flag2)
					{
						processContext.ResultStore.Set(prior.Tool.Name, prior.Result);
					}
				}
			}
		}

		// Token: 0x06001800 RID: 6144 RVA: 0x0007166C File Offset: 0x0006F86C
		private void RunToolForRunAll(ToolProcessContext processContext, ToolVision tool, RunAllOverlayState overlayState)
		{
			HObject input = null;
			string inputSourceToolName = this.GetInputSourceToolName(tool);
			Stopwatch stopwatch = Stopwatch.StartNew();
			Form_setting.PublishRunAllResultsToStore(processContext, overlayState);
			try
			{
				bool flag = tool.ToolType == ToolType.DistanceObject;
				if (flag)
				{
					stopwatch.Stop();
					this.RunDistanceObjectForRunAll(processContext, tool, overlayState);
				}
				else
				{
					bool flag2 = tool.ToolType == ToolType.CalibHandEye;
					if (flag2)
					{
						this.RunCalibHandEyeForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
					}
					else
					{
						bool flag3 = tool.ToolType == ToolType.ResultAlign;
						if (flag3)
						{
							this.RunResultAlignForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
						}
						else
						{
							bool flag4 = tool.ToolType == ToolType.ResultInspection;
							if (flag4)
							{
								this.RunResultInspectionForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
							}
							else
							{
								bool flag5 = tool.ToolType == ToolType.DeformableInspection;
								if (flag5)
								{
									this.RunDeformableInspectionForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
								}
								else
								{
									bool flag6 = tool.ToolType == ToolType.VariationModel;
									if (flag6)
									{
										this.RunVariationModelForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
									}
									else
									{
										bool flag7 = tool.ToolType == ToolType.VariationChangeWD;
										if (flag7)
										{
											this.RunVariationChangeWDForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
										}
										else
										{
											bool flag8 = tool.ToolType == ToolType.ProductCountInspection;
											if (flag8)
											{
												this.RunProductCountInspectionForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
											}
											else
											{
												bool flag9 = tool.ToolType == ToolType.FindRedArrow;
												if (flag9)
												{
													this.RunFindRedArrowForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
												}
												else
												{
													bool flag10 = tool.ToolType == ToolType.CountBoundingBox;
													if (flag10)
													{
														this.RunCountBoundingBoxForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
													}
													else
													{
														bool flag11 = tool.ToolType == ToolType.ProcedureInspection;
														if (flag11)
														{
															this.RunProcedureInspectionForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
														}
														else
														{
															bool flag12 = tool.ToolType == ToolType.DLObjectInspection;
															if (flag12)
															{
																this.RunDLObjectInspectionForRunAll(processContext, tool, stopwatch, inputSourceToolName, overlayState);
															}
															else
															{
																ToolTrialRunPipelineService pipelineService = new ToolTrialRunPipelineService();
																input = pipelineService.BuildInputImageForTool(processContext, tool);
																bool flag13 = input == null || !input.IsInitialized();
																if (flag13)
																{
																	HOperatorSet.CopyImage(processContext.OriginalImage, out input);
																}
																switch (tool.ToolType)
																{
																case ToolType.Blob:
																	this.RunBlobForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.Histogram:
																	this.RunHistogramForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.HistogramColor:
																	this.RunHistogramColorForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.FindCircle:
																	this.RunFindCircleForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.FindLine:
																	this.RunFindLineForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.Shape_model:
																case ToolType.AnisoShapeModel:
																case ToolType.OverlappingShapeModel:
																	this.RunShapeModelForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.ImageFilter:
																case ToolType.ImageTransform:
																case ToolType.SaveImage:
																	this.RunImageOutputToolForRunAll(processContext, tool, input, stopwatch, inputSourceToolName);
																	goto IL_396;
																case ToolType.MatrixCode:
																	this.RunMatrixCodeForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.MeasureCircle:
																	this.RunMeasureCircleForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.CircleMaster:
																	this.RunCircleMasterForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.BoundingBoxMaster:
																	this.RunBoundingBoxMasterForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.MinAreaMaster:
																	this.RunMinAreaMasterForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.IntersectingLines:
																	this.RunIntersectingLinesForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.AngleSelector:
																	this.RunAngleSelectorForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.FindBoundingBox:
																	this.RunFindBoundingBoxForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																case ToolType.FindMinArea:
																	this.RunFindMinAreaForRunAll(tool, input, stopwatch, inputSourceToolName, overlayState);
																	goto IL_396;
																}
																stopwatch.Stop();
																this.AddRunAllOutputRow(tool.Name, string.Empty, string.Empty, stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
																IL_396:;
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			finally
			{
				if (input != null)
				{
					input.Dispose();
				}
			}
		}

		// Token: 0x06001801 RID: 6145 RVA: 0x00071A40 File Offset: 0x0006FC40
		private void RunImageOutputToolForRunAll(ToolProcessContext processContext, ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName)
		{
			ToolProcessContext localContext = new ToolProcessContext
			{
				OriginalImage = processContext.OriginalImage,
				InputImage = input,
				BufferStore = processContext.BufferStore,
				ResultStore = processContext.ResultStore
			};
			ToolProcessResult result = null;
			bool flag = tool.ToolType == ToolType.ImageFilter;
			if (flag)
			{
				result = new ImageFilterProcessor().Execute(localContext, tool);
			}
			else
			{
				bool flag2 = tool.ToolType == ToolType.ImageTransform;
				if (flag2)
				{
					result = new ImageTransformProcessor().Execute(localContext, tool);
				}
				else
				{
					bool flag3 = tool.ToolType == ToolType.SaveImage;
					if (flag3)
					{
						result = new SaveImageProcessor().Execute(localContext, tool);
					}
				}
			}
			bool flag4 = localContext.OutputImage != null && localContext.OutputImage.IsInitialized();
			if (flag4)
			{
				ImageBufferStore bufferStore = processContext.BufferStore;
				if (bufferStore != null)
				{
					bufferStore.SetByToolName(tool.Name, localContext.OutputImage);
				}
				localContext.OutputImage.Dispose();
				localContext.OutputImage = null;
			}
			stopwatch.Stop();
			this.AddRunAllOutputRow(tool.Name, string.Empty, (result != null && result.IsSuccess) ? "OK" : string.Empty, stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
		}

		// Token: 0x06001802 RID: 6146 RVA: 0x00071B7C File Offset: 0x0006FD7C
		private void RunCalibHandEyeForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			CalibHandEyeResult result = new CalibHandEyeProcessor().TrialRun(processContext, tool);
			stopwatch.Stop();
			bool flag = result.TotalProcessingTimeMs <= 0.0;
			if (flag)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			string status = result.IsSuccess ? "OK" : "NG";
			string masterName = this.NormalizeDisplayValue(result.MasterToolName);
			bool flag2 = result.IsSuccess && result.Objects != null && result.Objects.Count > 0;
			if (flag2)
			{
				bool multi = result.ObjectMode == CalibHandEyeObjectMode.MultiObject;
				foreach (CalibHandEyeObjectResult obj in result.Objects)
				{
					string label = multi ? string.Concat(new string[]
					{
						tool.Name,
						" [",
						obj.GridRow.ToString(),
						",",
						obj.GridColumn.ToString(),
						"]",
						obj.Picked ? " *" : string.Empty
					}) : tool.Name;
					string value = obj.HasDelta ? string.Concat(new string[]
					{
						"dX=",
						obj.DeltaRobotX.ToString("0.000"),
						" dY=",
						obj.DeltaRobotY.ToString("0.000"),
						" dA=",
						obj.DeltaAngleDeg.ToString("0.000")
					}) : string.Concat(new string[]
					{
						"X=",
						obj.RobotX.ToString("0.000"),
						" Y=",
						obj.RobotY.ToString("0.000"),
						" A=",
						obj.AngleDeg.ToString("0.000")
					});
					value = Form_setting.AppendCalibHandEyeDebug(value, obj);
					this.AddRunAllOutputRow(label, value, status, result.TotalProcessingTimeMs, inputSourceToolName, masterName, "None");
				}
			}
			else
			{
				this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? ("X=" + result.RobotX.ToString("0.000") + " Y=" + result.RobotY.ToString("0.000")) : (result.Message ?? string.Empty), status, result.TotalProcessingTimeMs, inputSourceToolName, masterName, "None");
			}
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001803 RID: 6147 RVA: 0x00071E90 File Offset: 0x00070090
		private static string AppendCalibHandEyeDebug(string value, CalibHandEyeObjectResult obj)
		{
			bool flag = obj == null;
			string result;
			if (flag)
			{
				result = value;
			}
			else
			{
				string tcpText = obj.UsedTcpOffset ? string.Concat(new string[]
				{
					" TCP=ON tcp=(",
					obj.TcpPixelColumn.ToString("0.0"),
					",",
					obj.TcpPixelRow.ToString("0.0"),
					")"
				}) : " TCP=OFF";
				result = string.Concat(new string[]
				{
					value,
					tcpText,
					" Araw=",
					obj.VisionAngleDeg.ToString("0.000"),
					" Amap=",
					obj.MappedVisionAngleDeg.ToString("0.000"),
					" Aoff=",
					obj.AngleOffsetDeg.ToString("0.000")
				});
			}
			return result;
		}

		// Token: 0x06001804 RID: 6148 RVA: 0x00071F80 File Offset: 0x00070180
		private void RunResultAlignForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			CalibResultAlignResult result = new CalibResultAlignProcessor().TrialRun(processContext, tool);
			stopwatch.Stop();
			bool flag = result.TotalProcessingTimeMs <= 0.0;
			if (flag)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			string status = result.IsSuccess ? "OK" : "NG";
			bool flag2 = result.IsSuccess && result.Items != null && result.Items.Count > 0;
			if (flag2)
			{
				foreach (CalibResultAlignItem item in result.Items)
				{
					string value = item.HasDelta ? string.Concat(new string[]
					{
						"dX=",
						item.DeltaRobotX.ToString("0.000"),
						" dY=",
						item.DeltaRobotY.ToString("0.000"),
						" dA=",
						item.DeltaAngleDeg.ToString("0.000")
					}) : string.Concat(new string[]
					{
						"X=",
						item.RobotX.ToString("0.000"),
						" Y=",
						item.RobotY.ToString("0.000"),
						" A=",
						item.AngleDeg.ToString("0.000")
					});
					this.AddRunAllOutputRow(tool.Name + " <- " + item.SourceToolName, value, status, result.TotalProcessingTimeMs, inputSourceToolName, this.NormalizeDisplayValue(item.SourceToolName), "None");
				}
			}
			else
			{
				this.AddRunAllOutputRow(tool.Name, result.Message ?? string.Empty, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			}
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001805 RID: 6149 RVA: 0x000721DC File Offset: 0x000703DC
		private void RunDeformableInspectionForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject image = (processContext.InputImage != null && processContext.InputImage.IsInitialized()) ? processContext.InputImage : processContext.OriginalImage;
			DeformableInspectionResult result = new DeformableInspectionProcessor().Run(image, tool);
			stopwatch.Stop();
			bool flag = result.ProcessingTimeMs <= 0.0;
			if (flag)
			{
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			bool flag2 = result.TotalProcessingTimeMs <= 0.0;
			if (flag2)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			InspectionResultStore.Record(tool.Name, result);
			string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
			string resultText = result.IsSuccess ? string.Concat(new string[]
			{
				"Score=",
				result.Score.ToString("0.000"),
				" MaxDef=",
				result.MaxDeformation.ToString("0.00"),
				" MeanDef=",
				result.MeanDeformation.ToString("0.00"),
				" Area=",
				result.DefectArea.ToString("0")
			}) : (result.Message ?? string.Empty);
			this.AddRunAllOutputRow(tool.Name, resultText, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			foreach (DeformableMetricResult metric in result.Metrics)
			{
				string metricValue = "Value=" + metric.Value.ToString("0.###") + (metric.SpecEnabled ? string.Concat(new string[]
				{
					" Spec=[",
					metric.SpecMin.ToString("0.###"),
					" ~ ",
					metric.SpecMax.ToString("0.###"),
					"]"
				}) : string.Empty);
				this.AddRunAllOutputRow(tool.Name + " - " + metric.Name, metricValue, metric.Status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			}
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001806 RID: 6150 RVA: 0x000724A4 File Offset: 0x000706A4
		private void RunVariationModelForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject image = (processContext.InputImage != null && processContext.InputImage.IsInitialized()) ? processContext.InputImage : processContext.OriginalImage;
			VariationModelResult result = new VariationModelProcessor().Run(image, tool);
			stopwatch.Stop();
			bool flag = result.ProcessingTimeMs <= 0.0;
			if (flag)
			{
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			bool flag2 = result.TotalProcessingTimeMs <= 0.0;
			if (flag2)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			InspectionResultStore.Record(tool.Name, result);
			string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
			string resultText = result.IsSuccess ? string.Concat(new string[]
			{
				"TotalArea=",
				result.TotalDefectArea.ToString("0"),
				" Defects=",
				result.DefectCount.ToString(),
				" Score=",
				result.Score.ToString("0.000"),
				result.IsSpecEnabled ? string.Concat(new string[]
				{
					" Spec=[",
					result.SpecMin.ToString("0"),
					" ~ ",
					result.SpecMax.ToString("0"),
					"]"
				}) : string.Empty
			}) : (result.Message ?? string.Empty);
			this.AddRunAllOutputRow(tool.Name, resultText, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			bool flag3 = result.IsSuccess && result.DefectAreas != null && result.DefectAreas.Count > 0;
			if (flag3)
			{
				for (int i = 0; i < result.DefectAreas.Count; i++)
				{
					this.AddRunAllOutputRow(tool.Name + " - Defect " + (i + 1).ToString(), "Area=" + result.DefectAreas[i].ToString("0.###") + " px", status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
				}
			}
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001807 RID: 6151 RVA: 0x00072754 File Offset: 0x00070954
		private void RunVariationChangeWDForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject image = (processContext.InputImage != null && processContext.InputImage.IsInitialized()) ? processContext.InputImage : processContext.OriginalImage;
			VariationChangeWDResult result = new VariationChangeWDProcessor().Run(image, tool);
			stopwatch.Stop();
			bool flag = result.ProcessingTimeMs <= 0.0;
			if (flag)
			{
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			bool flag2 = result.TotalProcessingTimeMs <= 0.0;
			if (flag2)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			InspectionResultStore.Record(tool.Name, result);
			string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
			string resultText = result.IsSuccess ? string.Concat(new string[]
			{
				"TotalArea=",
				result.TotalDefectArea.ToString("0"),
				" MaxBlob=",
				result.MaxBlobArea.ToString("0"),
				" Defects=",
				result.DefectCount.ToString(),
				(result.Scale > 0.0) ? (" Scale=" + result.Scale.ToString("0.0000")) : string.Empty,
				(result.SpecFailures.Count > 0) ? (" (" + string.Join("; ", result.SpecFailures) + ")") : string.Empty
			}) : (result.Message ?? string.Empty);
			this.AddRunAllOutputRow(tool.Name, resultText, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			bool flag3 = result.IsSuccess && result.DefectAreas.Count > 0;
			if (flag3)
			{
				for (int i = 0; i < result.DefectAreas.Count; i++)
				{
					this.AddRunAllOutputRow(tool.Name + " - Defect " + (i + 1).ToString(), string.Concat(new string[]
					{
						"Area=",
						result.DefectAreas[i].ToString("0"),
						" px Row=",
						result.DefectRows[i].ToString("0"),
						" Col=",
						result.DefectColumns[i].ToString("0")
					}), status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
				}
			}
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001808 RID: 6152 RVA: 0x00072A60 File Offset: 0x00070C60
		private void RunProcedureInspectionForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject image = (processContext.InputImage != null && processContext.InputImage.IsInitialized()) ? processContext.InputImage : processContext.OriginalImage;
			HObject produced = null;
			try
			{
				ProcedureInspectionResult result = new ProcedureInspectionProcessor().Run(image, tool, out produced);
				stopwatch.Stop();
				bool flag = result.ProcessingTimeMs <= 0.0;
				if (flag)
				{
					result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				}
				bool flag2 = result.TotalProcessingTimeMs <= 0.0;
				if (flag2)
				{
					result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				}
				InspectionResultStore.Record(tool.Name, result);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				string resultText = result.IsSuccess ? string.Concat(new string[]
				{
					string.IsNullOrWhiteSpace(result.ValueName) ? "Value" : result.ValueName,
					"=",
					result.HasValue ? result.ValueTextOrEmpty : "-",
					(result.RoiResults.Count > 0) ? (" ROIs=" + result.RoiResults.Count.ToString()) : string.Empty,
					(result.SpecFailures.Count > 0) ? (" (" + string.Join("; ", result.SpecFailures) + ")") : string.Empty
				}) : (result.Message ?? string.Empty);
				this.AddRunAllOutputRow(tool.Name, resultText, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
				foreach (ProcedureInspectionRoiResult roiResult in result.RoiResults)
				{
					this.AddRunAllOutputRow(tool.Name + " - ROI " + roiResult.Index.ToString(), (!string.IsNullOrWhiteSpace(roiResult.Message)) ? roiResult.Message : (roiResult.HasValue ? roiResult.Value.ToString("0.###") : (roiResult.ValueText ?? "-")), roiResult.IsEvaluated ? (roiResult.IsOk ? "OK" : "NG") : status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
				}
				overlayState.Results.Add(new RunAllToolOverlayResult
				{
					Tool = tool,
					Result = result
				});
			}
			finally
			{
				if (produced != null)
				{
					produced.Dispose();
				}
			}
		}

		// Token: 0x06001809 RID: 6153 RVA: 0x00072D78 File Offset: 0x00070F78
		private void RunCountBoundingBoxForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject image = (processContext.InputImage != null && processContext.InputImage.IsInitialized()) ? processContext.InputImage : processContext.OriginalImage;
			CountBoundingBoxResult result = new CountBoundingBoxProcessor().Run(image, tool);
			stopwatch.Stop();
			bool flag = result.ProcessingTimeMs <= 0.0;
			if (flag)
			{
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			bool flag2 = result.TotalProcessingTimeMs <= 0.0;
			if (flag2)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			InspectionResultStore.Record(tool.Name, result);
			string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
			string resultText = result.IsSuccess ? string.Concat(new string[]
			{
				"Objects=",
				result.ObjectCount.ToString(),
				" Candidates=",
				result.CandidateCount.ToString(),
				" Boxes=",
				result.BoxesBeforeGrouping.ToString(),
				(result.SpecFailures.Count > 0) ? (" (" + string.Join("; ", result.SpecFailures) + ")") : string.Empty
			}) : (result.Message ?? string.Empty);
			this.AddRunAllOutputRow(tool.Name, resultText, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			foreach (CountBoundingBoxItem item in result.Objects)
			{
				this.AddRunAllOutputRow(tool.Name + " - Object " + item.Index.ToString(), string.Concat(new string[]
				{
					"Size=",
					item.Width.ToString("0"),
					"x",
					item.Height.ToString("0"),
					" BoxArea=",
					item.BoxArea.ToString("0"),
					" Row=",
					item.CenterRow.ToString("0"),
					" Col=",
					item.CenterColumn.ToString("0")
				}), status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			}
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600180A RID: 6154 RVA: 0x00073080 File Offset: 0x00071280
		private void RunFindRedArrowForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject image = (processContext.InputImage != null && processContext.InputImage.IsInitialized()) ? processContext.InputImage : processContext.OriginalImage;
			FindRedArrowResult result = new FindRedArrowProcessor().Run(image, tool);
			stopwatch.Stop();
			bool flag = result.ProcessingTimeMs <= 0.0;
			if (flag)
			{
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			bool flag2 = result.TotalProcessingTimeMs <= 0.0;
			if (flag2)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			InspectionResultStore.Record(tool.Name, result);
			string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
			string resultText = result.IsSuccess ? string.Concat(new string[]
			{
				"Arrows=",
				result.ArrowCount.ToString(),
				" MaxArea=",
				result.MaxArea.ToString("0"),
				" Candidates=",
				result.CandidateCount.ToString(),
				(result.SpecFailures.Count > 0) ? (" (" + string.Join("; ", result.SpecFailures) + ")") : string.Empty
			}) : (result.Message ?? string.Empty);
			this.AddRunAllOutputRow(tool.Name, resultText, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			foreach (FindRedArrowItem arrow in result.Arrows)
			{
				this.AddRunAllOutputRow(tool.Name + " - Arrow " + arrow.Index.ToString(), string.Concat(new string[]
				{
					"Area=",
					arrow.Area.ToString("0"),
					" px Row=",
					arrow.Row.ToString("0"),
					" Col=",
					arrow.Column.ToString("0"),
					" Mean=",
					arrow.MeanRedness.ToString("0")
				}), arrow.IsAreaOutOfSpec ? "NG" : status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			}
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600180B RID: 6155 RVA: 0x00073370 File Offset: 0x00071570
		private void RunProductCountInspectionForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject image = null;
			Stopwatch inputStopwatch = Stopwatch.StartNew();
			try
			{
				image = new ToolTrialRunPipelineService().BuildInputImageForTool(processContext, tool);
				bool flag = image == null || !image.IsInitialized();
				if (flag)
				{
					if (image != null)
					{
						image.Dispose();
					}
					HOperatorSet.CopyImage(processContext.OriginalImage, out image);
				}
				inputStopwatch.Stop();
				ProductCountInspectionResult result = new ProductCountInspectionProcessor().Run(image, tool);
				stopwatch.Stop();
				bool flag2 = result.ProcessingTimeMs <= 0.0;
				if (flag2)
				{
					result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				}
				result.InputSourceToolName = inputSourceToolName;
				result.InputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				InspectionResultStore.Record(tool.Name, result);
				string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
				string resultText = result.IsSuccess ? string.Concat(new string[]
				{
					"Count=",
					result.FoundCount.ToString(),
					" Foreign=",
					result.DefectCount.ToString(),
					" MaxBlob=",
					result.MaxBlobArea.ToString("0"),
					(result.NgProductIndexes.Count > 0) ? (" NG products=" + string.Join<int>(",", result.NgProductIndexes)) : string.Empty,
					(result.SpecFailures.Count > 0) ? (" (" + string.Join("; ", result.SpecFailures) + ")") : string.Empty
				}) : (result.Message ?? string.Empty);
				this.AddRunAllOutputRow(tool.Name, resultText, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
				for (int i = 0; i < result.ForeignObjects.Count; i++)
				{
					ProductCountForeignObject foreign = result.ForeignObjects[i];
					this.AddRunAllOutputRow(tool.Name + " - Foreign " + (i + 1).ToString(), string.Concat(new string[]
					{
						"Area=",
						foreign.Area.ToString("0"),
						" px Row=",
						foreign.Row.ToString("0"),
						" Col=",
						foreign.Column.ToString("0"),
						(foreign.ProductIndex > 0) ? (" Product=" + foreign.ProductIndex.ToString()) : string.Empty
					}), "NG", result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
				}
				overlayState.Results.Add(new RunAllToolOverlayResult
				{
					Tool = tool,
					Result = result
				});
			}
			finally
			{
				if (image != null)
				{
					image.Dispose();
				}
			}
		}

		// Token: 0x0600180C RID: 6156 RVA: 0x000736DC File Offset: 0x000718DC
		private void RunDLObjectInspectionForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject image = (processContext.InputImage != null && processContext.InputImage.IsInitialized()) ? processContext.InputImage : processContext.OriginalImage;
			DLObjectInspectionResult result = new DLObjectInspectionProcessor().Run(image, tool);
			stopwatch.Stop();
			bool flag = result.ProcessingTimeMs <= 0.0;
			if (flag)
			{
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			bool flag2 = result.TotalProcessingTimeMs <= 0.0;
			if (flag2)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			InspectionResultStore.Record(tool.Name, result);
			string status = (!result.IsSuccess) ? "Lost" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
			string resultText = result.IsSuccess ? ("Objects=" + result.ObjectCount.ToString() + (result.IsSpecEnabled ? string.Concat(new string[]
			{
				" Spec=[",
				result.SpecMin.ToString(),
				" ~ ",
				result.SpecMax.ToString(),
				"]"
			}) : string.Empty)) : (result.Message ?? string.Empty);
			this.AddRunAllOutputRow(tool.Name, resultText, status, result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600180D RID: 6157 RVA: 0x00073880 File Offset: 0x00071A80
		private void RunResultInspectionForRunAll(ToolProcessContext processContext, ToolVision tool, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			bool flag = overlayState != null;
			if (flag)
			{
				foreach (RunAllToolOverlayResult prior in overlayState.Results)
				{
					bool flag2 = ((prior != null) ? prior.Tool : null) != null && prior.Result != null;
					if (flag2)
					{
						InspectionResultStore.Record(prior.Tool.Name, prior.Result);
						if (processContext != null)
						{
							ToolResultStore resultStore = processContext.ResultStore;
							if (resultStore != null)
							{
								resultStore.Set(prior.Tool.Name, prior.Result);
							}
						}
					}
				}
			}
			CalibResultInspectionResult result = new CalibResultInspectionProcessor().TrialRun(processContext, tool);
			stopwatch.Stop();
			bool flag3 = result.TotalProcessingTimeMs <= 0.0;
			if (flag3)
			{
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			this.AddRunAllOutputRow(tool.Name, result.Message, result.IsOk ? "OK" : "NG", result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			foreach (CalibResultInspectionItem item in result.Items)
			{
				string itemValue = (item.HasValue && !string.IsNullOrWhiteSpace(item.ValueText)) ? ("Value=" + item.ValueText + (string.IsNullOrWhiteSpace(item.SpecText) ? string.Empty : (" Spec=" + item.SpecText))) : (item.Detail ?? string.Empty);
				this.AddRunAllOutputRow(tool.Name + " <- " + item.SourceToolName, itemValue, item.Evaluated ? item.Status : (item.Status ?? "N/A"), result.TotalProcessingTimeMs, inputSourceToolName, "None", "None");
			}
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600180E RID: 6158 RVA: 0x00073AE0 File Offset: 0x00071CE0
		private void AddOverlappingRunAllRows(ToolVision tool, OverlappingShapeModelResult result, string inputSourceToolName)
		{
			foreach (OverlappingMatchCandidate product in result.Products)
			{
				this.AddRunAllOutputRow(string.Concat(new string[]
				{
					tool.Name,
					" #",
					product.Order.ToString(),
					" ",
					product.LayerText
				}), string.Concat(new string[]
				{
					"R=",
					product.Row.ToString("0.000"),
					" C=",
					product.Column.ToString("0.000"),
					" A=",
					(product.Angle * 180.0 / 3.141592653589793).ToString("0.000"),
					" S=",
					product.Score.ToString("0.000"),
					" Vote=",
					product.Vote.ToString("0.#")
				}), (product.Layer == ProductLayer.Bottom) ? "BOTTOM" : "TOP", result.ProcessingTimeMs, inputSourceToolName, "None", "None");
			}
			foreach (string detail in result.VoteDetails)
			{
				this.AddRunAllOutputRow(tool.Name + " vote", detail, result.LayerResolved ? "OK" : "Undecided", result.ProcessingTimeMs, inputSourceToolName, "None", "None");
			}
			bool flag = !string.IsNullOrWhiteSpace(result.LayerMessage);
			if (flag)
			{
				this.AddRunAllOutputRow(tool.Name + " layer", result.LayerMessage, result.LayerResolved ? "OK" : "Undecided", result.ProcessingTimeMs, inputSourceToolName, "None", "None");
			}
		}

		// Token: 0x0600180F RID: 6159 RVA: 0x00073D48 File Offset: 0x00071F48
		private void RunShapeModelForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			bool flag = tool.ToolType == ToolType.AnisoShapeModel;
			ShapeMatchResult result;
			if (flag)
			{
				result = new AnisoShapeModelProcessor().Match(input, tool);
			}
			else
			{
				bool flag2 = tool.ToolType == ToolType.OverlappingShapeModel;
				if (flag2)
				{
					result = new OverlappingShapeModelProcessor().Match(input, tool);
				}
				else
				{
					result = new ShapeModelProcessor().Match(input, tool);
				}
			}
			stopwatch.Stop();
			result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			result.InputSourceToolName = inputSourceToolName;
			OverlappingShapeModelResult overlapping = result as OverlappingShapeModelResult;
			bool flag3 = overlapping != null;
			if (flag3)
			{
				this.AddOverlappingRunAllRows(tool, overlapping, inputSourceToolName);
			}
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? string.Concat(new string[]
			{
				"Score=",
				result.Score.ToString("0.000"),
				" Row=",
				result.Row.ToString("0.000"),
				" Col=",
				result.Column.ToString("0.000")
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", result.ProcessingTimeMs, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001810 RID: 6160 RVA: 0x00073EAC File Offset: 0x000720AC
		private void RunBlobForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject fullDomainInput = null;
			try
			{
				HOperatorSet.FullDomain(input, out fullDomainInput);
				BlobProcessResult result = new BlobProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(fullDomainInput, tool);
				stopwatch.Stop();
				result.InputSourceToolName = inputSourceToolName;
				result.InputProcessingTimeMs = 0.0;
				this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? ("Total=" + result.TotalValue.ToString("0")) : string.Empty, result.IsSuccess ? (result.IsOk ? "OK" : "NG") : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, this.GetDistinctMasterNames(from x in result.RoiResults
				select x.MasterPositionToolName), this.GetDistinctMasterNames(from x in result.RoiResults
				select x.MasterAngleToolName));
				overlayState.Results.Add(new RunAllToolOverlayResult
				{
					Tool = tool,
					Result = result
				});
			}
			finally
			{
				if (fullDomainInput != null)
				{
					fullDomainInput.Dispose();
				}
			}
		}

		// Token: 0x06001811 RID: 6161 RVA: 0x00074018 File Offset: 0x00072218
		private void RunMatrixCodeForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			MatrixCodeResult result = new MatrixCodeProcessor().Run(input, tool);
			stopwatch.Stop();
			result.InputSourceToolName = inputSourceToolName;
			string text;
			if (!result.IsSuccess)
			{
				text = string.Empty;
			}
			else
			{
				text = string.Join(" | ", from x in result.Symbols
				select x.DecodedText);
			}
			string value = text;
			this.AddRunAllOutputRow(tool.Name, value, result.IsSuccess ? "OK" : "NG", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001812 RID: 6162 RVA: 0x000740E8 File Offset: 0x000722E8
		private void RunHistogramForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject fullDomainInput = null;
			try
			{
				HOperatorSet.FullDomain(input, out fullDomainInput);
				HistogramProcessResult result = new HistogramProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(fullDomainInput, tool);
				stopwatch.Stop();
				result.InputSourceToolName = inputSourceToolName;
				result.InputProcessingTimeMs = 0.0;
				this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? ("Total=" + result.TotalValue.ToString("0.000") + "%") : string.Empty, result.IsSuccess ? (result.IsOk ? "OK" : "NG") : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, this.GetDistinctMasterNames(from x in result.RoiResults
				select x.MasterPositionToolName), this.GetDistinctMasterNames(from x in result.RoiResults
				select x.MasterAngleToolName));
				overlayState.Results.Add(new RunAllToolOverlayResult
				{
					Tool = tool,
					Result = result
				});
			}
			finally
			{
				if (fullDomainInput != null)
				{
					fullDomainInput.Dispose();
				}
			}
		}

		// Token: 0x06001813 RID: 6163 RVA: 0x00074258 File Offset: 0x00072458
		private void RunHistogramColorForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			HObject fullDomainInput = null;
			try
			{
				HOperatorSet.FullDomain(input, out fullDomainInput);
				HistogramColorProcessResult result = new HistogramColorProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(fullDomainInput, tool);
				stopwatch.Stop();
				result.InputSourceToolName = inputSourceToolName;
				result.InputProcessingTimeMs = 0.0;
				this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? ("Total=" + result.TotalValue.ToString("0.000") + "%") : string.Empty, result.IsSuccess ? (result.IsOk ? "OK" : "NG") : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, this.GetDistinctMasterNames(from x in result.RoiResults
				select x.MasterPositionToolName), this.GetDistinctMasterNames(from x in result.RoiResults
				select x.MasterAngleToolName));
				overlayState.Results.Add(new RunAllToolOverlayResult
				{
					Tool = tool,
					Result = result
				});
			}
			finally
			{
				if (fullDomainInput != null)
				{
					fullDomainInput.Dispose();
				}
			}
		}

		// Token: 0x06001814 RID: 6164 RVA: 0x000743C8 File Offset: 0x000725C8
		private void RunFindLineForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			FindLineResult result = new FindLineProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(input, tool);
			stopwatch.Stop();
			result.InputSourceToolName = inputSourceToolName;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? string.Concat(new string[]
			{
				"P1(",
				result.StartRow.ToString("0.000"),
				", ",
				result.StartColumn.ToString("0.000"),
				") P2(",
				result.EndRow.ToString("0.000"),
				", ",
				result.EndColumn.ToString("0.000"),
				")"
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, this.NormalizeDisplayValue(result.MasterPositionToolName), this.NormalizeDisplayValue(result.MasterAngleToolName));
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001815 RID: 6165 RVA: 0x0007451C File Offset: 0x0007271C
		private void RunFindCircleForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			FindCircleResult result = new FindCircleProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(input, tool);
			stopwatch.Stop();
			result.InputSourceToolName = inputSourceToolName;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? string.Concat(new string[]
			{
				"Center=(",
				result.Row.ToString("0.000"),
				", ",
				result.Column.ToString("0.000"),
				") R=",
				result.Radius.ToString("0.000")
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, this.NormalizeDisplayValue(result.MasterPositionToolName), this.NormalizeDisplayValue(result.MasterAngleToolName));
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001816 RID: 6166 RVA: 0x00074644 File Offset: 0x00072844
		private void RunCircleMasterForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			CircleMasterResult result = new CircleMasterProcessor(this.GetRunAllShapeMatchResults(overlayState)).Match(input, tool);
			stopwatch.Stop();
			result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			result.InputSourceToolName = inputSourceToolName;
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? string.Concat(new string[]
			{
				"Center=(",
				result.Row.ToString("0.000"),
				", ",
				result.Column.ToString("0.000"),
				")"
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001817 RID: 6167 RVA: 0x0007475C File Offset: 0x0007295C
		private void RunFindBoundingBoxForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			FindBoundingBoxResult result = new FindBoundingBoxProcessor().Run(input, tool);
			stopwatch.Stop();
			result.InputSourceToolName = inputSourceToolName;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			this.AddRunAllOutputRow(tool.Name, (result.IsSuccess && result.SelectedBox != null) ? string.Concat(new string[]
			{
				"Center=(",
				result.SelectedBox.Row.ToString("0.000"),
				", ",
				result.SelectedBox.Column.ToString("0.000"),
				") W=",
				result.SelectedBox.Width.ToString("0.000"),
				" H=",
				result.SelectedBox.Height.ToString("0.000")
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001818 RID: 6168 RVA: 0x000748AC File Offset: 0x00072AAC
		private void RunFindMinAreaForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			FindMinAreaResult result = new FindMinAreaProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(input, tool);
			stopwatch.Stop();
			result.InputSourceToolName = inputSourceToolName;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			this.AddRunAllOutputRow(tool.Name, (result.IsSuccess && result.SelectedBox != null) ? string.Concat(new string[]
			{
				"Center=(",
				result.SelectedBox.Row.ToString("0.000"),
				", ",
				result.SelectedBox.Column.ToString("0.000"),
				") W=",
				result.SelectedBox.Width.ToString("0.000"),
				" H=",
				result.SelectedBox.Height.ToString("0.000"),
				" A=",
				result.SelectedBox.AngleDegree.ToString("0.000")
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, this.NormalizeDisplayValue(result.MasterPositionToolName), this.NormalizeDisplayValue(result.MasterAngleToolName));
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x06001819 RID: 6169 RVA: 0x00074A38 File Offset: 0x00072C38
		private void RunBoundingBoxMasterForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			BoundingBoxMasterResult result = new BoundingBoxMasterProcessor(this.GetRunAllShapeMatchResults(overlayState)).Match(input, tool);
			stopwatch.Stop();
			result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			result.InputSourceToolName = inputSourceToolName;
			bool flag = result.BoundingBoxResult != null;
			if (flag)
			{
				result.BoundingBoxResult.InputSourceToolName = inputSourceToolName;
				result.BoundingBoxResult.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? string.Concat(new string[]
			{
				"Center=(",
				result.Row.ToString("0.000"),
				", ",
				result.Column.ToString("0.000"),
				")"
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600181A RID: 6170 RVA: 0x00074B88 File Offset: 0x00072D88
		private void RunMinAreaMasterForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			MinAreaMasterResult result = new MinAreaMasterProcessor(this.GetRunAllShapeMatchResults(overlayState)).Match(input, tool);
			stopwatch.Stop();
			result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			result.InputSourceToolName = inputSourceToolName;
			bool flag = result.MinAreaResult != null;
			if (flag)
			{
				result.MinAreaResult.InputSourceToolName = inputSourceToolName;
				result.MinAreaResult.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			}
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? string.Concat(new string[]
			{
				"Center=(",
				result.Row.ToString("0.000"),
				", ",
				result.Column.ToString("0.000"),
				") A=",
				(result.Angle * 180.0 / 3.141592653589793).ToString("0.000")
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600181B RID: 6171 RVA: 0x00074D04 File Offset: 0x00072F04
		private void RunMeasureCircleForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			MeasureCircleResult result = new MeasureCircleProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(input, tool);
			stopwatch.Stop();
			result.InputSourceToolName = inputSourceToolName;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? (((result.MeasureMode == MeasureCircleMode.Radius) ? "R=" : "D=") + (result.IsCalibrationApplied ? (result.MeasuredValueMm.ToString("0.000") + " mm") : (result.MeasuredPixelValue.ToString("0.000") + " px"))) : string.Empty, this.GetMeasureCircleRunAllStatus(result), stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600181C RID: 6172 RVA: 0x00074E08 File Offset: 0x00073008
		private void RunIntersectingLinesForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			IntersectingLinesProcessor processor = new IntersectingLinesProcessor(this.GetRunAllFindLineResults(overlayState), this.GetRunAllShapeMatchResults(overlayState));
			IntersectingLinesResult result = processor.TrialRun(input, tool);
			stopwatch.Stop();
			result.InputSourceToolName = inputSourceToolName;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? string.Concat(new string[]
			{
				"P=(",
				result.Row.ToString("0.000"),
				", ",
				result.Column.ToString("0.000"),
				")"
			}) : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600181D RID: 6173 RVA: 0x00074F18 File Offset: 0x00073118
		private void RunAngleSelectorForRunAll(ToolVision tool, HObject input, Stopwatch stopwatch, string inputSourceToolName, RunAllOverlayState overlayState)
		{
			AngleSelectorProcessor processor = new AngleSelectorProcessor(null, this.GetRunAllShapeMatchResults(overlayState));
			AngleSelectorResult result = processor.TrialRun(input, tool);
			stopwatch.Stop();
			result.InputSourceToolName = inputSourceToolName;
			result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
			this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? ("DeltaAngle=" + result.DeltaAngleDegrees.ToString("0.000") + " deg") : string.Empty, result.IsSuccess ? "OK" : "Lost", stopwatch.Elapsed.TotalMilliseconds, inputSourceToolName, "None", "None");
			overlayState.Results.Add(new RunAllToolOverlayResult
			{
				Tool = tool,
				Result = result
			});
		}

		// Token: 0x0600181E RID: 6174 RVA: 0x00074FF4 File Offset: 0x000731F4
		private void RunDistanceObjectForRunAll(ToolProcessContext processContext, ToolVision tool, RunAllOverlayState overlayState)
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			DistanceObjectToolConfig config = tool.Config as DistanceObjectToolConfig;
			bool flag = config == null;
			if (flag)
			{
				stopwatch.Stop();
				this.AddRunAllOutputRow(tool.Name, string.Empty, "Lost", stopwatch.Elapsed.TotalMilliseconds, "None", "None", "None");
			}
			else
			{
				try
				{
					Dictionary<string, DistanceObjectSourceResult> resultStore = new Dictionary<string, DistanceObjectSourceResult>();
					DistanceObjectSourceResult firstSourceResult = this.GetRunAllMeasureSourceResult(overlayState, config.Parameter.FirstLineToolName) ?? this.RunDistanceSourceMeasureObject(processContext, tool, config.Parameter.FirstLineToolName, resultStore, overlayState);
					DistanceObjectSourceResult secondSourceResult = this.GetRunAllMeasureSourceResult(overlayState, config.Parameter.SecondLineToolName) ?? this.RunDistanceSourceMeasureObject(processContext, tool, config.Parameter.SecondLineToolName, resultStore, overlayState);
					DistanceObjectResult result = new DistanceObjectProcessor().Run(tool, firstSourceResult, secondSourceResult);
					stopwatch.Stop();
					result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
					this.AddRunAllOutputRow(tool.Name, result.IsSuccess ? (result.IsCalibrationApplied ? ("Distance=" + result.CalibratedDistanceMm.ToString("0.000") + " mm") : ("Distance=" + result.Distance.ToString("0.000") + " px")) : string.Empty, this.GetDistanceObjectRunAllStatus(result), result.TotalProcessingTimeMs, "None", "None", "None");
					overlayState.Results.Add(new RunAllToolOverlayResult
					{
						Tool = tool,
						Result = result
					});
					foreach (DistanceObjectSourceResult item in resultStore.Values)
					{
						if (item != null)
						{
							FindLineResult lineResult = item.LineResult;
							if (lineResult != null)
							{
								lineResult.Dispose();
							}
						}
						if (item != null)
						{
							FindCircleResult circleResult = item.CircleResult;
							if (circleResult != null)
							{
								circleResult.Dispose();
							}
						}
						if (item != null)
						{
							FindBoundingBoxResult boundingBoxResult = item.BoundingBoxResult;
							if (boundingBoxResult != null)
							{
								boundingBoxResult.Dispose();
							}
						}
						if (item != null)
						{
							FindMinAreaResult minAreaResult = item.MinAreaResult;
							if (minAreaResult != null)
							{
								minAreaResult.Dispose();
							}
						}
					}
				}
				finally
				{
				}
			}
		}

		// Token: 0x0600181F RID: 6175 RVA: 0x0007527C File Offset: 0x0007347C
		private FindLineResult GetRunAllFindLineResult(RunAllOverlayState overlayState, string sourceToolName)
		{
			bool flag = overlayState == null || string.IsNullOrWhiteSpace(sourceToolName);
			FindLineResult result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = (from x in overlayState.Results
				where ((x != null) ? x.Tool : null) != null && x.Tool.ToolType == ToolType.FindLine && string.Equals(x.Tool.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)
				select x.Result as FindLineResult).FirstOrDefault((FindLineResult x) => x != null);
			}
			return result;
		}

		// Token: 0x06001820 RID: 6176 RVA: 0x00075314 File Offset: 0x00073514
		private Dictionary<string, FindLineResult> GetRunAllFindLineResults(RunAllOverlayState overlayState)
		{
			bool flag = overlayState == null;
			Dictionary<string, FindLineResult> result;
			if (flag)
			{
				result = null;
			}
			else
			{
				Dictionary<string, FindLineResult> results = new Dictionary<string, FindLineResult>(StringComparer.OrdinalIgnoreCase);
				foreach (RunAllToolOverlayResult item in overlayState.Results)
				{
					bool flag2 = ((item != null) ? item.Tool : null) == null || item.Tool.ToolType != ToolType.FindLine;
					if (!flag2)
					{
						FindLineResult lineResult = item.Result as FindLineResult;
						bool flag3 = lineResult == null;
						if (!flag3)
						{
							results[item.Tool.Name] = lineResult;
						}
					}
				}
				result = results;
			}
			return result;
		}

		// Token: 0x06001821 RID: 6177 RVA: 0x000753E4 File Offset: 0x000735E4
		private FindCircleResult GetRunAllFindCircleResult(RunAllOverlayState overlayState, string sourceToolName)
		{
			bool flag = overlayState == null || string.IsNullOrWhiteSpace(sourceToolName);
			FindCircleResult result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = (from x in overlayState.Results
				where ((x != null) ? x.Tool : null) != null && x.Tool.ToolType == ToolType.FindCircle && string.Equals(x.Tool.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)
				select x.Result as FindCircleResult).FirstOrDefault((FindCircleResult x) => x != null);
			}
			return result;
		}

		// Token: 0x06001822 RID: 6178 RVA: 0x0007547C File Offset: 0x0007367C
		private CircleMasterResult GetRunAllCircleMasterResult(RunAllOverlayState overlayState, string sourceToolName)
		{
			bool flag = overlayState == null || string.IsNullOrWhiteSpace(sourceToolName);
			CircleMasterResult result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = (from x in overlayState.Results
				where ((x != null) ? x.Tool : null) != null && x.Tool.ToolType == ToolType.CircleMaster && string.Equals(x.Tool.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)
				select x.Result as CircleMasterResult).FirstOrDefault((CircleMasterResult x) => x != null);
			}
			return result;
		}

		// Token: 0x06001823 RID: 6179 RVA: 0x00075514 File Offset: 0x00073714
		private DistanceObjectSourceResult GetRunAllMeasureSourceResult(RunAllOverlayState overlayState, string sourceToolName)
		{
			FindLineResult lineResult = this.GetRunAllFindLineResult(overlayState, sourceToolName);
			bool flag = lineResult != null;
			DistanceObjectSourceResult result;
			if (flag)
			{
				result = new DistanceObjectSourceResult
				{
					ToolName = sourceToolName,
					ToolType = ToolType.FindLine,
					LineResult = lineResult
				};
			}
			else
			{
				FindCircleResult circleResult = this.GetRunAllFindCircleResult(overlayState, sourceToolName);
				bool flag2 = circleResult != null;
				if (flag2)
				{
					result = new DistanceObjectSourceResult
					{
						ToolName = sourceToolName,
						ToolType = ToolType.FindCircle,
						CircleResult = circleResult
					};
				}
				else
				{
					CircleMasterResult circleMasterResult = this.GetRunAllCircleMasterResult(overlayState, sourceToolName);
					bool flag3 = ((circleMasterResult != null) ? circleMasterResult.CircleResult : null) != null;
					if (flag3)
					{
						result = new DistanceObjectSourceResult
						{
							ToolName = sourceToolName,
							ToolType = ToolType.CircleMaster,
							CircleResult = circleMasterResult.CircleResult
						};
					}
					else
					{
						FindBoundingBoxResult boundingBoxResult = this.GetRunAllFindBoundingBoxResult(overlayState, sourceToolName);
						bool flag4 = boundingBoxResult != null;
						if (flag4)
						{
							result = new DistanceObjectSourceResult
							{
								ToolName = sourceToolName,
								ToolType = ToolType.FindBoundingBox,
								BoundingBoxResult = boundingBoxResult
							};
						}
						else
						{
							FindMinAreaResult minAreaResult = this.GetRunAllFindMinAreaResult(overlayState, sourceToolName);
							bool flag5 = minAreaResult != null;
							if (flag5)
							{
								result = new DistanceObjectSourceResult
								{
									ToolName = sourceToolName,
									ToolType = ToolType.FindMinArea,
									MinAreaResult = minAreaResult
								};
							}
							else
							{
								result = null;
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06001824 RID: 6180 RVA: 0x00075650 File Offset: 0x00073850
		private FindBoundingBoxResult GetRunAllFindBoundingBoxResult(RunAllOverlayState overlayState, string sourceToolName)
		{
			bool flag = overlayState == null || string.IsNullOrWhiteSpace(sourceToolName);
			FindBoundingBoxResult result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = (from x in overlayState.Results
				where ((x != null) ? x.Tool : null) != null && x.Tool.ToolType == ToolType.FindBoundingBox && string.Equals(x.Tool.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)
				select x.Result as FindBoundingBoxResult).FirstOrDefault((FindBoundingBoxResult x) => x != null);
			}
			return result;
		}

		// Token: 0x06001825 RID: 6181 RVA: 0x000756E8 File Offset: 0x000738E8
		private FindMinAreaResult GetRunAllFindMinAreaResult(RunAllOverlayState overlayState, string sourceToolName)
		{
			bool flag = overlayState == null || string.IsNullOrWhiteSpace(sourceToolName);
			FindMinAreaResult result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = (from x in overlayState.Results
				where ((x != null) ? x.Tool : null) != null && x.Tool.ToolType == ToolType.FindMinArea && string.Equals(x.Tool.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)
				select x.Result as FindMinAreaResult).FirstOrDefault((FindMinAreaResult x) => x != null);
			}
			return result;
		}

		// Token: 0x06001826 RID: 6182 RVA: 0x00075780 File Offset: 0x00073980
		private string GetDistanceObjectRunAllStatus(DistanceObjectResult result)
		{
			bool flag = result == null || !result.IsSuccess;
			string result2;
			if (flag)
			{
				result2 = "Lost";
			}
			else
			{
				bool isSpecEnabled = result.IsSpecEnabled;
				if (isSpecEnabled)
				{
					result2 = this.NormalizeDisplayValue(result.SpecStatus);
				}
				else
				{
					result2 = "OK";
				}
			}
			return result2;
		}

		// Token: 0x06001827 RID: 6183 RVA: 0x000757CC File Offset: 0x000739CC
		private string GetMeasureCircleRunAllStatus(MeasureCircleResult result)
		{
			bool flag = result == null || !result.IsSuccess;
			string result2;
			if (flag)
			{
				result2 = "Lost";
			}
			else
			{
				bool isSpecEnabled = result.IsSpecEnabled;
				if (isSpecEnabled)
				{
					result2 = this.NormalizeDisplayValue(result.SpecStatus);
				}
				else
				{
					result2 = "OK";
				}
			}
			return result2;
		}

		// Token: 0x06001828 RID: 6184 RVA: 0x00075818 File Offset: 0x00073A18
		private DistanceObjectSourceResult RunDistanceSourceMeasureObject(ToolProcessContext context, ToolVision distanceTool, string sourceToolName, Dictionary<string, DistanceObjectSourceResult> resultStore, RunAllOverlayState overlayState)
		{
			bool flag = string.IsNullOrWhiteSpace(sourceToolName);
			DistanceObjectSourceResult result2;
			if (flag)
			{
				result2 = null;
			}
			else
			{
				bool flag2 = resultStore.ContainsKey(sourceToolName);
				if (flag2)
				{
					result2 = resultStore[sourceToolName];
				}
				else
				{
					TurnSnap parentTurnSnap = distanceTool.ParentTurnSnap;
					ToolVision sourceTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != distanceTool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.FindLine || x.ToolType == ToolType.FindCircle || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.FindBoundingBox || x.ToolType == ToolType.FindMinArea) && x.Name == sourceToolName) : null;
					bool flag3 = sourceTool == null;
					if (flag3)
					{
						result2 = null;
					}
					else
					{
						HObject input = null;
						try
						{
							ToolTrialRunPipelineService pipelineService = new ToolTrialRunPipelineService();
							input = pipelineService.BuildInputImageForTool(context, sourceTool);
							bool flag4 = input == null || !input.IsInitialized();
							if (flag4)
							{
								result2 = null;
							}
							else
							{
								DistanceObjectSourceResult result = null;
								bool flag5 = sourceTool.ToolType == ToolType.FindLine;
								if (flag5)
								{
									result = new DistanceObjectSourceResult
									{
										ToolName = sourceToolName,
										ToolType = ToolType.FindLine,
										LineResult = new FindLineProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(input, sourceTool)
									};
								}
								else
								{
									bool flag6 = sourceTool.ToolType == ToolType.FindCircle;
									if (flag6)
									{
										result = new DistanceObjectSourceResult
										{
											ToolName = sourceToolName,
											ToolType = ToolType.FindCircle,
											CircleResult = new FindCircleProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(input, sourceTool)
										};
									}
									else
									{
										bool flag7 = sourceTool.ToolType == ToolType.CircleMaster;
										if (flag7)
										{
											CircleMasterResult circleMaster = new CircleMasterProcessor(this.GetRunAllShapeMatchResults(overlayState)).Match(input, sourceTool);
											result = new DistanceObjectSourceResult
											{
												ToolName = sourceToolName,
												ToolType = ToolType.CircleMaster,
												CircleResult = circleMaster.CircleResult
											};
										}
										else
										{
											bool flag8 = sourceTool.ToolType == ToolType.FindBoundingBox;
											if (flag8)
											{
												result = new DistanceObjectSourceResult
												{
													ToolName = sourceToolName,
													ToolType = ToolType.FindBoundingBox,
													BoundingBoxResult = new FindBoundingBoxProcessor().Run(input, sourceTool)
												};
											}
											else
											{
												bool flag9 = sourceTool.ToolType == ToolType.FindMinArea;
												if (flag9)
												{
													result = new DistanceObjectSourceResult
													{
														ToolName = sourceToolName,
														ToolType = ToolType.FindMinArea,
														MinAreaResult = new FindMinAreaProcessor(this.GetRunAllShapeMatchResults(overlayState)).Run(input, sourceTool)
													};
												}
											}
										}
									}
								}
								resultStore[sourceToolName] = result;
								result2 = result;
							}
						}
						finally
						{
							if (input != null)
							{
								input.Dispose();
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06001829 RID: 6185 RVA: 0x00075ABC File Offset: 0x00073CBC
		private Dictionary<string, ShapeMatchResult> GetRunAllShapeMatchResults(RunAllOverlayState overlayState)
		{
			bool flag = overlayState == null;
			Dictionary<string, ShapeMatchResult> result;
			if (flag)
			{
				result = null;
			}
			else
			{
				Dictionary<string, ShapeMatchResult> results = new Dictionary<string, ShapeMatchResult>(StringComparer.OrdinalIgnoreCase);
				foreach (RunAllToolOverlayResult item in overlayState.Results)
				{
					bool flag2 = ((item != null) ? item.Tool : null) == null || (item.Tool.ToolType != ToolType.Shape_model && item.Tool.ToolType != ToolType.AnisoShapeModel && item.Tool.ToolType != ToolType.OverlappingShapeModel && item.Tool.ToolType != ToolType.CircleMaster && item.Tool.ToolType != ToolType.BoundingBoxMaster && item.Tool.ToolType != ToolType.MinAreaMaster && item.Tool.ToolType != ToolType.IntersectingLines && item.Tool.ToolType != ToolType.AngleSelector);
					if (!flag2)
					{
						ShapeMatchResult shapeResult = item.Result as ShapeMatchResult;
						bool flag3 = shapeResult == null;
						if (!flag3)
						{
							results[item.Tool.Name] = shapeResult;
						}
					}
				}
				result = results;
			}
			return result;
		}

		// Token: 0x0600182A RID: 6186 RVA: 0x00075C08 File Offset: 0x00073E08
		private void AddRunAllOutputRow(string toolName, string result, string status, double processingTimeMs, string inputSourceToolName, string masterPositionToolName, string masterAngleToolName)
		{
			this.RunAllOutputResults.Add(new RunAllOutputResultRow
			{
				ToolName = this.NormalizeDisplayValue(toolName),
				Result = (result ?? string.Empty),
				Status = (status ?? string.Empty),
				ProcessingTimeMs = processingTimeMs,
				TurnSnapProcessingTimeMs = 0.0,
				InputSourceToolName = this.NormalizeDisplayValue(inputSourceToolName),
				MasterPositionToolName = this.NormalizeDisplayValue(masterPositionToolName),
				MasterAngleToolName = this.NormalizeDisplayValue(masterAngleToolName)
			});
		}

		// Token: 0x0600182B RID: 6187 RVA: 0x00075CA0 File Offset: 0x00073EA0
		private void UpdateRunAllTurnSnapProcessingTime(double processingTimeMs)
		{
			foreach (RunAllOutputResultRow row in this.RunAllOutputResults)
			{
				row.TurnSnapProcessingTimeMs = processingTimeMs;
			}
			this.OnFormPropertyChanged("RunAllOutputResults");
		}

		// Token: 0x0600182C RID: 6188 RVA: 0x00075D00 File Offset: 0x00073F00
		private void DrawRunAllOverlays(HWindow window, RunAllOverlayState overlayState)
		{
			bool flag = window == null || overlayState == null;
			if (!flag)
			{
				ShapeModelResultDrawer shapeDrawer = new ShapeModelResultDrawer();
				OverlappingShapeModelResultDrawer overlappingDrawer = new OverlappingShapeModelResultDrawer();
				BlobResultDrawer blobDrawer = new BlobResultDrawer();
				HistogramResultDrawer histogramDrawer = new HistogramResultDrawer();
				HistogramColorResultDrawer histogramColorDrawer = new HistogramColorResultDrawer();
				FindCircleResultDrawer findCircleDrawer = new FindCircleResultDrawer();
				FindBoundingBoxResultDrawer findBoundingBoxDrawer = new FindBoundingBoxResultDrawer();
				FindMinAreaResultDrawer findMinAreaDrawer = new FindMinAreaResultDrawer();
				FindLineResultDrawer findLineDrawer = new FindLineResultDrawer();
				MeasureCircleResultDrawer measureCircleDrawer = new MeasureCircleResultDrawer();
				CircleMasterResultDrawer circleMasterDrawer = new CircleMasterResultDrawer();
				BoundingBoxMasterResultDrawer boundingBoxMasterDrawer = new BoundingBoxMasterResultDrawer();
				MinAreaMasterResultDrawer minAreaMasterDrawer = new MinAreaMasterResultDrawer();
				IntersectingLinesResultDrawer intersectingLinesDrawer = new IntersectingLinesResultDrawer();
				AngleSelectorResultDrawer angleSelectorDrawer = new AngleSelectorResultDrawer();
				CalibHandEyeResultDrawer calibHandEyeDrawer = new CalibHandEyeResultDrawer();
				CalibResultAlignResultDrawer resultAlignDrawer = new CalibResultAlignResultDrawer();
				CalibResultInspectionResultDrawer resultInspectionDrawer = new CalibResultInspectionResultDrawer();
				DeformableInspectionResultDrawer deformableInspectionDrawer = new DeformableInspectionResultDrawer();
				VariationModelResultDrawer variationModelDrawer = new VariationModelResultDrawer();
				DLObjectInspectionResultDrawer dlObjectInspectionDrawer = new DLObjectInspectionResultDrawer();
				MatrixCodeResultDrawer matrixCodeDrawer = new MatrixCodeResultDrawer();
				foreach (RunAllToolOverlayResult item in overlayState.Results)
				{
					bool flag2 = ((item != null) ? item.Tool : null) == null || item.Result == null;
					if (!flag2)
					{
						MatrixCodeResult matrixCodeResult = item.Result as MatrixCodeResult;
						bool flag3 = matrixCodeResult != null;
						if (flag3)
						{
							matrixCodeDrawer.Draw(window, item.Tool, matrixCodeResult);
						}
						else
						{
							DLObjectInspectionResult dlObjectInspectionResult = item.Result as DLObjectInspectionResult;
							bool flag4 = dlObjectInspectionResult != null;
							if (flag4)
							{
								dlObjectInspectionDrawer.Draw(window, item.Tool, dlObjectInspectionResult);
							}
							else
							{
								CalibHandEyeResult calibHandEyeResult = item.Result as CalibHandEyeResult;
								bool flag5 = calibHandEyeResult != null;
								if (flag5)
								{
									calibHandEyeDrawer.Draw(window, item.Tool, calibHandEyeResult);
								}
								else
								{
									CalibResultAlignResult resultAlignResult = item.Result as CalibResultAlignResult;
									bool flag6 = resultAlignResult != null;
									if (flag6)
									{
										resultAlignDrawer.Draw(window, item.Tool, resultAlignResult);
									}
									else
									{
										CalibResultInspectionResult resultInspectionResult = item.Result as CalibResultInspectionResult;
										bool flag7 = resultInspectionResult != null;
										if (flag7)
										{
											resultInspectionDrawer.Draw(window, item.Tool, resultInspectionResult);
										}
										else
										{
											DeformableInspectionResult deformableInspectionResult = item.Result as DeformableInspectionResult;
											bool flag8 = deformableInspectionResult != null;
											if (flag8)
											{
												deformableInspectionDrawer.Draw(window, item.Tool, deformableInspectionResult);
											}
											else
											{
												VariationModelResult variationModelResult = item.Result as VariationModelResult;
												bool flag9 = variationModelResult != null;
												if (flag9)
												{
													variationModelDrawer.Draw(window, item.Tool, variationModelResult);
												}
												else
												{
													IntersectingLinesResult intersectingLinesResult = item.Result as IntersectingLinesResult;
													bool flag10 = intersectingLinesResult != null;
													if (flag10)
													{
														intersectingLinesDrawer.Draw(window, item.Tool, intersectingLinesResult);
													}
													else
													{
														CircleMasterResult circleMasterResult = item.Result as CircleMasterResult;
														bool flag11 = circleMasterResult != null;
														if (flag11)
														{
															circleMasterDrawer.Draw(window, item.Tool, circleMasterResult);
														}
														else
														{
															BoundingBoxMasterResult boundingBoxMasterResult = item.Result as BoundingBoxMasterResult;
															bool flag12 = boundingBoxMasterResult != null;
															if (flag12)
															{
																boundingBoxMasterDrawer.Draw(window, item.Tool, boundingBoxMasterResult, false);
															}
															else
															{
																MinAreaMasterResult minAreaMasterResult = item.Result as MinAreaMasterResult;
																bool flag13 = minAreaMasterResult != null;
																if (flag13)
																{
																	minAreaMasterDrawer.Draw(window, item.Tool, minAreaMasterResult, false);
																}
																else
																{
																	AngleSelectorResult angleSelectorResult = item.Result as AngleSelectorResult;
																	bool flag14 = angleSelectorResult != null;
																	if (flag14)
																	{
																		angleSelectorDrawer.Draw(window, item.Tool, angleSelectorResult);
																	}
																	else
																	{
																		OverlappingShapeModelResult overlappingResult = item.Result as OverlappingShapeModelResult;
																		bool flag15 = overlappingResult != null;
																		if (flag15)
																		{
																			overlappingDrawer.DrawRoiOverlays(window, item.Tool, overlappingResult);
																			overlappingDrawer.Draw(item.Tool, window, overlappingResult, false);
																		}
																		else
																		{
																			ShapeMatchResult shapeResult = item.Result as ShapeMatchResult;
																			bool flag16 = shapeResult != null;
																			if (flag16)
																			{
																				shapeDrawer.DrawRoiOverlays(window, item.Tool, shapeResult);
																				shapeDrawer.DrawMatchResult(item.Tool, window, shapeResult);
																			}
																			else
																			{
																				BlobProcessResult blobResult = item.Result as BlobProcessResult;
																				bool flag17 = blobResult != null;
																				if (flag17)
																				{
																					blobDrawer.Draw(window, item.Tool, blobResult, false, false);
																				}
																				else
																				{
																					HistogramProcessResult histogramResult = item.Result as HistogramProcessResult;
																					bool flag18 = histogramResult != null;
																					if (flag18)
																					{
																						histogramDrawer.Draw(window, item.Tool, histogramResult, false, false);
																					}
																					else
																					{
																						HistogramColorProcessResult histogramColorResult = item.Result as HistogramColorProcessResult;
																						bool flag19 = histogramColorResult != null;
																						if (flag19)
																						{
																							histogramColorDrawer.Draw(window, item.Tool, histogramColorResult, false, false);
																						}
																						else
																						{
																							FindLineResult findLineResult = item.Result as FindLineResult;
																							bool flag20 = findLineResult != null;
																							if (flag20)
																							{
																								findLineDrawer.Draw(window, item.Tool, findLineResult);
																							}
																							else
																							{
																								FindCircleResult findCircleResult = item.Result as FindCircleResult;
																								bool flag21 = findCircleResult != null;
																								if (flag21)
																								{
																									findCircleDrawer.Draw(window, item.Tool, findCircleResult);
																								}
																								else
																								{
																									FindMinAreaResult findMinAreaResult = item.Result as FindMinAreaResult;
																									bool flag22 = findMinAreaResult != null;
																									if (flag22)
																									{
																										findMinAreaDrawer.Draw(window, item.Tool, findMinAreaResult, false);
																									}
																									else
																									{
																										FindBoundingBoxResult findBoundingBoxResult = item.Result as FindBoundingBoxResult;
																										bool flag23 = findBoundingBoxResult != null;
																										if (flag23)
																										{
																											findBoundingBoxDrawer.Draw(window, item.Tool, findBoundingBoxResult, false);
																										}
																										else
																										{
																											DistanceObjectResult distanceResult = item.Result as DistanceObjectResult;
																											bool flag24 = distanceResult != null;
																											if (flag24)
																											{
																												new DistanceObjectResultDrawer().Draw(window, item.Tool, distanceResult);
																											}
																											else
																											{
																												MeasureCircleResult measureCircleResult = item.Result as MeasureCircleResult;
																												bool flag25 = measureCircleResult != null;
																												if (flag25)
																												{
																													measureCircleDrawer.Draw(window, item.Tool, measureCircleResult);
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x0600182D RID: 6189 RVA: 0x000762DC File Offset: 0x000744DC
		private string GetInputSourceToolName(ToolVision tool)
		{
			ImageInputLink link = this.GetInputLink(tool);
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x0600182E RID: 6190 RVA: 0x000763B0 File Offset: 0x000745B0
		private ImageInputLink GetInputLink(ToolVision tool)
		{
			bool flag = tool == null;
			ImageInputLink result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool flag2 = tool.ToolType == ToolType.ImageFilter;
				if (flag2)
				{
					ImageFilterToolConfig imageFilterToolConfig = tool.Config as ImageFilterToolConfig;
					result = ((imageFilterToolConfig != null) ? imageFilterToolConfig.InputLink : null);
				}
				else
				{
					bool flag3 = tool.ToolType == ToolType.ImageTransform;
					if (flag3)
					{
						ImageTransformToolConfig imageTransformToolConfig = tool.Config as ImageTransformToolConfig;
						result = ((imageTransformToolConfig != null) ? imageTransformToolConfig.InputLink : null);
					}
					else
					{
						bool flag4 = tool.ToolType == ToolType.Shape_model;
						if (flag4)
						{
							ShapeModelToolConfig shapeModelToolConfig = tool.Config as ShapeModelToolConfig;
							result = ((shapeModelToolConfig != null) ? shapeModelToolConfig.InputLink : null);
						}
						else
						{
							bool flag5 = tool.ToolType == ToolType.Blob;
							if (flag5)
							{
								BlobToolConfig blobToolConfig = tool.Config as BlobToolConfig;
								result = ((blobToolConfig != null) ? blobToolConfig.InputLink : null);
							}
							else
							{
								bool flag6 = tool.ToolType == ToolType.Histogram;
								if (flag6)
								{
									HistogramToolConfig histogramToolConfig = tool.Config as HistogramToolConfig;
									result = ((histogramToolConfig != null) ? histogramToolConfig.InputLink : null);
								}
								else
								{
									bool flag7 = tool.ToolType == ToolType.HistogramColor;
									if (flag7)
									{
										HistogramColorToolConfig histogramColorToolConfig = tool.Config as HistogramColorToolConfig;
										result = ((histogramColorToolConfig != null) ? histogramColorToolConfig.InputLink : null);
									}
									else
									{
										bool flag8 = tool.ToolType == ToolType.FindLine;
										if (flag8)
										{
											FindLineToolConfig findLineToolConfig = tool.Config as FindLineToolConfig;
											result = ((findLineToolConfig != null) ? findLineToolConfig.InputLink : null);
										}
										else
										{
											bool flag9 = tool.ToolType == ToolType.FindCircle;
											if (flag9)
											{
												FindCircleToolConfig findCircleToolConfig = tool.Config as FindCircleToolConfig;
												result = ((findCircleToolConfig != null) ? findCircleToolConfig.InputLink : null);
											}
											else
											{
												bool flag10 = tool.ToolType == ToolType.CircleMaster;
												if (flag10)
												{
													CircleMasterToolConfig circleMasterToolConfig = tool.Config as CircleMasterToolConfig;
													result = ((circleMasterToolConfig != null) ? circleMasterToolConfig.InputLink : null);
												}
												else
												{
													bool flag11 = tool.ToolType == ToolType.BoundingBoxMaster;
													if (flag11)
													{
														BoundingBoxMasterToolConfig boundingBoxMasterToolConfig = tool.Config as BoundingBoxMasterToolConfig;
														result = ((boundingBoxMasterToolConfig != null) ? boundingBoxMasterToolConfig.InputLink : null);
													}
													else
													{
														bool flag12 = tool.ToolType == ToolType.MinAreaMaster;
														if (flag12)
														{
															MinAreaMasterToolConfig minAreaMasterToolConfig = tool.Config as MinAreaMasterToolConfig;
															result = ((minAreaMasterToolConfig != null) ? minAreaMasterToolConfig.InputLink : null);
														}
														else
														{
															bool flag13 = tool.ToolType == ToolType.FindBoundingBox;
															if (flag13)
															{
																FindBoundingBoxToolConfig findBoundingBoxToolConfig = tool.Config as FindBoundingBoxToolConfig;
																result = ((findBoundingBoxToolConfig != null) ? findBoundingBoxToolConfig.InputLink : null);
															}
															else
															{
																bool flag14 = tool.ToolType == ToolType.FindMinArea;
																if (flag14)
																{
																	FindMinAreaToolConfig findMinAreaToolConfig = tool.Config as FindMinAreaToolConfig;
																	result = ((findMinAreaToolConfig != null) ? findMinAreaToolConfig.InputLink : null);
																}
																else
																{
																	bool flag15 = tool.ToolType == ToolType.MeasureCircle;
																	if (flag15)
																	{
																		MeasureCircleToolConfig measureCircleToolConfig = tool.Config as MeasureCircleToolConfig;
																		result = ((measureCircleToolConfig != null) ? measureCircleToolConfig.InputLink : null);
																	}
																	else
																	{
																		bool flag16 = tool.ToolType == ToolType.ProductCountInspection;
																		if (flag16)
																		{
																			ProductCountInspectionToolConfig productCountInspectionToolConfig = tool.Config as ProductCountInspectionToolConfig;
																			result = ((productCountInspectionToolConfig != null) ? productCountInspectionToolConfig.InputLink : null);
																		}
																		else
																		{
																			result = null;
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x0600182F RID: 6191 RVA: 0x00076664 File Offset: 0x00074864
		private string GetDistinctMasterNames(IEnumerable<string> masterNames)
		{
			bool flag = masterNames == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				List<string> values = (from x in masterNames
				where !string.IsNullOrWhiteSpace(x) && x != "None"
				select x).Distinct<string>().ToList<string>();
				result = ((values.Count == 0) ? "None" : string.Join(", ", values));
			}
			return result;
		}

		// Token: 0x06001830 RID: 6192 RVA: 0x000766D0 File Offset: 0x000748D0
		private Brush GetMasterStatusBrush(string status)
		{
			bool flag = string.Equals(status, "OK", StringComparison.OrdinalIgnoreCase);
			Brush result;
			if (flag)
			{
				result = Brushes.LimeGreen;
			}
			else
			{
				bool flag2 = string.Equals(status, "Lost Master", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = Brushes.Gold;
				}
				else
				{
					result = Brushes.White;
				}
			}
			return result;
		}

		// Token: 0x06001831 RID: 6193 RVA: 0x00076717 File Offset: 0x00074917
		private void OnFormPropertyChanged(string propertyName)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x06001832 RID: 6194 RVA: 0x00076733 File Offset: 0x00074933
		protected override void OnClosed(EventArgs e)
		{
			this.SaveImageListSetting();
			SettingDisplayController displayController = this._displayController;
			if (displayController != null)
			{
				displayController.Dispose();
			}
			base.OnClosed(e);
		}

		// Token: 0x06001833 RID: 6195 RVA: 0x00076758 File Offset: 0x00074958
		private void ToggleToolList_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement fe = sender as FrameworkElement;
			TurnSnap turnSnap;
			bool flag;
			if (fe != null)
			{
				turnSnap = (fe.Tag as TurnSnap);
				flag = (turnSnap != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				turnSnap.IsToolListExpanded = !turnSnap.IsToolListExpanded;
			}
		}

		// Token: 0x06001834 RID: 6196 RVA: 0x0007679C File Offset: 0x0007499C
		public void RefreshShapeModelPreview(ToolVision tool)
		{
			bool flag = tool == null;
			if (!flag)
			{
				this._displayController.ClearOverlay();
				bool flag2 = tool.ShapeModelPreviewRegion != null;
				if (flag2)
				{
					this._displayController.AddOverlay(tool.ShapeModelPreviewRegion);
				}
				this._displayController.Redraw();
			}
		}

		// Token: 0x06001835 RID: 6197 RVA: 0x000767F0 File Offset: 0x000749F0
		public void RefreshVariationModelPreview(ToolVision tool)
		{
			bool flag = tool == null;
			if (!flag)
			{
				this._displayController.ClearOverlay();
				this._displayController.SetOverlayRenderer(delegate(HWindow window)
				{
					bool flag2 = window == null || tool.ShapeModelPreviewRegion == null || !tool.ShapeModelPreviewRegion.IsInitialized();
					if (!flag2)
					{
						try
						{
							HOperatorSet.SetDraw(window, "margin");
							HOperatorSet.SetColor(window, "yellow");
							HOperatorSet.SetLineWidth(window, 2);
							HOperatorSet.DispObj(tool.ShapeModelPreviewRegion, window);
						}
						catch
						{
						}
					}
				}, null);
			}
		}

		// Token: 0x06001836 RID: 6198 RVA: 0x00076840 File Offset: 0x00074A40
		private void DrawShapeMatchResult(ShapeMatchResult result)
		{
			HWindow window = this.Display_setting.HalconWindow;
			bool flag = window == null;
			if (!flag)
			{
				HOperatorSet.SetColor(window, "green");
				HOperatorSet.SetLineWidth(window, 2);
				HObject cross;
				HOperatorSet.GenCrossContourXld(out cross, result.Row, result.Column, 40, result.Angle);
				HOperatorSet.DispObj(cross, window);
				cross.Dispose();
				HOperatorSet.SetTposition(window, result.Row + 20.0, result.Column + 20.0);
				HOperatorSet.WriteString(window, "ShapeModel OK  Score=" + result.Score.ToString("0.000"));
			}
		}

		// Token: 0x06001837 RID: 6199 RVA: 0x00076938 File Offset: 0x00074B38
		private void DrawShapeTrialResult(ShapeMatchResult result)
		{
			HWindow window = this.Display_setting.HalconWindow;
			bool flag = window == null;
			if (!flag)
			{
				HOperatorSet.SetColor(window, "yellow");
				HOperatorSet.SetLineWidth(window, 2);
				HObject cross;
				HOperatorSet.GenCrossContourXld(out cross, result.Row, result.Column, 40, result.Angle);
				HOperatorSet.DispObj(cross, window);
				cross.Dispose();
				HOperatorSet.SetTposition(window, result.Row + 20.0, result.Column + 20.0);
				HOperatorSet.WriteString(window, string.Concat(new string[]
				{
					"dRow=",
					result.DeltaRow.ToString("0.000"),
					" dCol=",
					result.DeltaColumn.ToString("0.000"),
					" dAngle=",
					Form_setting.RadiansToDegrees(result.DeltaAngle).ToString("0.000"),
					" deg"
				}));
			}
		}

		// Token: 0x06001838 RID: 6200 RVA: 0x00076A84 File Offset: 0x00074C84
		private static double RadiansToDegrees(double radians)
		{
			return radians * 180.0 / 3.141592653589793;
		}

		// Token: 0x06001839 RID: 6201 RVA: 0x00076AAB File Offset: 0x00074CAB
		public void ImageFilterTrialRun()
		{
			this._toolActionDispatcher.TrialRun(this._toolActionContext, this.GetSelectedTool());
		}

		// Token: 0x0600183A RID: 6202 RVA: 0x00076AC8 File Offset: 0x00074CC8
		public void ImageTransformTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ImageTransform;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600183B RID: 6203 RVA: 0x00076B0C File Offset: 0x00074D0C
		public void SaveImageTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.SaveImage;
			if (!flag)
			{
				SaveImageToolConfig config = tool.Config as SaveImageToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					HObject original = null;
					HObject input = null;
					ImageBufferStore bufferStore = null;
					try
					{
						original = this._displayController.GetOriginalImage();
						bool flag3 = original == null || !original.IsInitialized();
						if (flag3)
						{
							DXMessageBox.Show("No image is available to save. Please open an image first.");
						}
						else
						{
							bufferStore = new ImageBufferStore();
							ToolProcessContext buildContext = new ToolProcessContext
							{
								OriginalImage = original,
								InputImage = original,
								BufferStore = bufferStore
							};
							input = new ToolTrialRunPipelineService().BuildInputImageForTool(buildContext, tool);
							bool flag4 = input == null || !input.IsInitialized();
							if (flag4)
							{
								HOperatorSet.CopyImage(original, out input);
							}
							this._displayController.DisplayImage(input);
							SaveImageProcessor processor = new SaveImageProcessor();
							HObject imageToSave = input;
							string savedPath = null;
							Exception saveError = null;
							LoadingOverlay.Run(this, "Saving image...", delegate
							{
								try
								{
									savedPath = processor.SaveImageToDisk(imageToSave, config);
								}
								catch (Exception ex2)
								{
									saveError = ex2;
								}
							});
							bool flag5 = saveError != null;
							if (flag5)
							{
								DXMessageBox.Show("Save Image failed: " + saveError.Message);
							}
							else
							{
								DXMessageBox.Show("Image saved successfully:\n" + savedPath);
							}
						}
					}
					catch (Exception ex)
					{
						DXMessageBox.Show("Save Image trial run failed: " + ex.Message);
					}
					finally
					{
						if (bufferStore != null)
						{
							bufferStore.Clear();
						}
						if (input != null)
						{
							input.Dispose();
						}
						if (original != null)
						{
							original.Dispose();
						}
					}
				}
			}
		}

		// Token: 0x0600183C RID: 6204 RVA: 0x00076D14 File Offset: 0x00074F14
		public void BlobTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.Blob;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600183D RID: 6205 RVA: 0x00076D54 File Offset: 0x00074F54
		public void MatrixCodeTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.MatrixCode;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600183E RID: 6206 RVA: 0x00076D98 File Offset: 0x00074F98
		public void HistogramTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.Histogram;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600183F RID: 6207 RVA: 0x00076DD8 File Offset: 0x00074FD8
		public void HistogramColorTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.HistogramColor;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001840 RID: 6208 RVA: 0x00076E18 File Offset: 0x00075018
		public void FindLineTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.FindLine;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001841 RID: 6209 RVA: 0x00076E58 File Offset: 0x00075058
		public void FindCircleTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.FindCircle;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001842 RID: 6210 RVA: 0x00076E98 File Offset: 0x00075098
		public void CircleMasterMatching()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.CircleMaster;
			if (!flag)
			{
				this._toolActionDispatcher.Matching(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001843 RID: 6211 RVA: 0x00076EDC File Offset: 0x000750DC
		public void CircleMasterDefineMaster()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.CircleMaster;
			if (!flag)
			{
				this._toolActionDispatcher.DefineMaster(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001844 RID: 6212 RVA: 0x00076F20 File Offset: 0x00075120
		public void CircleMasterTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.CircleMaster;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001845 RID: 6213 RVA: 0x00076F64 File Offset: 0x00075164
		public void BoundingBoxMasterMatching()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.BoundingBoxMaster;
			if (!flag)
			{
				this._toolActionDispatcher.Matching(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001846 RID: 6214 RVA: 0x00076FA8 File Offset: 0x000751A8
		public void BoundingBoxMasterDefineMaster()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.BoundingBoxMaster;
			if (!flag)
			{
				this._toolActionDispatcher.DefineMaster(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001847 RID: 6215 RVA: 0x00076FEC File Offset: 0x000751EC
		public void BoundingBoxMasterTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.BoundingBoxMaster;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001848 RID: 6216 RVA: 0x00077030 File Offset: 0x00075230
		public void MinAreaMasterMatching()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.MinAreaMaster;
			if (!flag)
			{
				this._toolActionDispatcher.Matching(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001849 RID: 6217 RVA: 0x00077074 File Offset: 0x00075274
		public void MinAreaMasterDefineMaster()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.MinAreaMaster;
			if (!flag)
			{
				this._toolActionDispatcher.DefineMaster(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600184A RID: 6218 RVA: 0x000770B8 File Offset: 0x000752B8
		public void MinAreaMasterTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.MinAreaMaster;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600184B RID: 6219 RVA: 0x000770FC File Offset: 0x000752FC
		public void FindBoundingBoxTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.FindBoundingBox;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600184C RID: 6220 RVA: 0x00077140 File Offset: 0x00075340
		public void FindMinAreaTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.FindMinArea;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600184D RID: 6221 RVA: 0x00077184 File Offset: 0x00075384
		public void DistanceObjectTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.DistanceObject;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600184E RID: 6222 RVA: 0x000771C8 File Offset: 0x000753C8
		public void MeasureCircleTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.MeasureCircle;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600184F RID: 6223 RVA: 0x0007720C File Offset: 0x0007540C
		public void CalibHandEyeTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.CalibHandEye;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001850 RID: 6224 RVA: 0x00077250 File Offset: 0x00075450
		public void ResultAlignTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ResultAlign;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001851 RID: 6225 RVA: 0x00077294 File Offset: 0x00075494
		public void ResultInspectionTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ResultInspection;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001852 RID: 6226 RVA: 0x000772D8 File Offset: 0x000754D8
		public void ShapeModelMatching()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || (tool.ToolType != ToolType.Shape_model && tool.ToolType != ToolType.AnisoShapeModel && tool.ToolType != ToolType.OverlappingShapeModel);
			if (!flag)
			{
				this._toolActionDispatcher.Matching(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001853 RID: 6227 RVA: 0x00077330 File Offset: 0x00075530
		public void ShapeModelDefineMaster()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || (tool.ToolType != ToolType.Shape_model && tool.ToolType != ToolType.AnisoShapeModel && tool.ToolType != ToolType.OverlappingShapeModel);
			if (!flag)
			{
				this._toolActionDispatcher.DefineMaster(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001854 RID: 6228 RVA: 0x00077388 File Offset: 0x00075588
		public void IntersectingLinesMatching()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.IntersectingLines;
			if (!flag)
			{
				this._toolActionDispatcher.Matching(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001855 RID: 6229 RVA: 0x000773CC File Offset: 0x000755CC
		public void IntersectingLinesDefineMaster()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.IntersectingLines;
			if (!flag)
			{
				this._toolActionDispatcher.DefineMaster(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001856 RID: 6230 RVA: 0x00077410 File Offset: 0x00075610
		public void IntersectingLinesTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.IntersectingLines;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001857 RID: 6231 RVA: 0x00077454 File Offset: 0x00075654
		public void AngleSelectorMatching()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.AngleSelector;
			if (!flag)
			{
				this._toolActionDispatcher.Matching(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001858 RID: 6232 RVA: 0x00077498 File Offset: 0x00075698
		public void AngleSelectorDefineMaster()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.AngleSelector;
			if (!flag)
			{
				this._toolActionDispatcher.DefineMaster(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001859 RID: 6233 RVA: 0x000774DC File Offset: 0x000756DC
		public void AngleSelectorTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.AngleSelector;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600185A RID: 6234 RVA: 0x00077520 File Offset: 0x00075720
		public void ShapeModelTrain(ToolVision tool)
		{
			bool flag = tool == null || (tool.ToolType != ToolType.Shape_model && tool.ToolType != ToolType.AnisoShapeModel && tool.ToolType != ToolType.OverlappingShapeModel);
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = this._displayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						this.TrainShapeModelWithCorrectService(tool, null);
						this.RefreshTrainPreview(tool);
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						ToolTrialRunPipelineService pipelineService = new ToolTrialRunPipelineService();
						input = pipelineService.BuildInputImageForTool(processContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							bool flag4 = input != null;
							if (flag4)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						this._displayController.DisplayImage(input);
						this.TrainShapeModelWithCorrectService(tool, input);
						this.RefreshTrainPreview(tool);
					}
				}
				finally
				{
					bool flag5 = input != null;
					if (flag5)
					{
						input.Dispose();
					}
					bool flag6 = bufferStore != null;
					if (flag6)
					{
						bufferStore.Clear();
					}
					bool flag7 = original != null;
					if (flag7)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x0600185B RID: 6235 RVA: 0x00077670 File Offset: 0x00075870
		public void ShapeModelTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || (tool.ToolType != ToolType.Shape_model && tool.ToolType != ToolType.AnisoShapeModel && tool.ToolType != ToolType.OverlappingShapeModel);
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600185C RID: 6236 RVA: 0x000776C8 File Offset: 0x000758C8
		public void DeformableInspectionTrain(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.DeformableInspection;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = this._displayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						DeformableInspectionTrainService fallbackService = new DeformableInspectionTrainService();
						fallbackService.TrainModel(tool, null);
						this.RefreshShapeModelPreview(tool);
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						ToolTrialRunPipelineService pipelineService = new ToolTrialRunPipelineService();
						input = pipelineService.BuildInputImageForTool(processContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							if (input != null)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						this._displayController.DisplayImage(input);
						DeformableInspectionTrainService service = new DeformableInspectionTrainService();
						service.TrainModel(tool, input);
						this.RefreshShapeModelPreview(tool);
					}
				}
				finally
				{
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					bool flag4 = original != null;
					if (flag4)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x0600185D RID: 6237 RVA: 0x00077804 File Offset: 0x00075A04
		public void DeformableInspectionTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.DeformableInspection;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600185E RID: 6238 RVA: 0x00077848 File Offset: 0x00075A48
		public void DLObjectInspectionTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.DLObjectInspection;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600185F RID: 6239 RVA: 0x0007788C File Offset: 0x00075A8C
		public void VariationModelTrain(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.VariationModel;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = this._displayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						LoadingOverlay.Run(this, "Training variation model...", delegate
						{
							VariationModelTrainService fallbackService = new VariationModelTrainService();
							fallbackService.TrainModel(tool, null);
						});
						this.RefreshVariationModelPreview(tool);
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						ToolTrialRunPipelineService pipelineService = new ToolTrialRunPipelineService();
						input = pipelineService.BuildInputImageForTool(processContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							HObject input3 = input;
							if (input3 != null)
							{
								input3.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						this._displayController.DisplayImage(input);
						LoadingOverlay.Run(this, "Training variation model...", delegate
						{
							VariationModelTrainService service = new VariationModelTrainService();
							service.TrainModel(tool, input);
						});
						this.RefreshVariationModelPreview(tool);
					}
				}
				catch (Exception ex)
				{
					string str = "Variation model training failed:\n";
					Exception baseException = ex.GetBaseException();
					DXMessageBox.Show(str + (((baseException != null) ? baseException.Message : null) ?? ex.Message), "Variation Model", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
				finally
				{
					HObject input2 = input;
					if (input2 != null)
					{
						input2.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					bool flag4 = original != null;
					if (flag4)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06001860 RID: 6240 RVA: 0x00077A84 File Offset: 0x00075C84
		public void VariationChangeWDAddSample(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.VariationChangeWD;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = this._displayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						DXMessageBox.Show("There is no image on screen to add as a sample.", "Variation Change WD", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						input = new ToolTrialRunPipelineService().BuildInputImageForTool(processContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							if (input != null)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						VariationChangeWDTrainService service = new VariationChangeWDTrainService();
						int count = service.AddSample(tool, input);
						DXMessageBox.Show(string.Concat(new string[]
						{
							"Sample added. There are now ",
							count.ToString(),
							" sample(s).",
							Environment.NewLine,
							Environment.NewLine,
							(count < 2) ? "Add at least one more before training - a variation model needs several images to learn how much each pixel may vary." : "Press \"Train Model\" when you have collected enough."
						}), "Variation Change WD", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					}
				}
				catch (Exception ex)
				{
					string str = "Adding the sample failed:";
					string newLine = Environment.NewLine;
					Exception baseException = ex.GetBaseException();
					DXMessageBox.Show(str + newLine + (((baseException != null) ? baseException.Message : null) ?? ex.Message), "Variation Change WD", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
				finally
				{
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06001861 RID: 6241 RVA: 0x00077C58 File Offset: 0x00075E58
		public void VariationChangeWDClearSamples(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.VariationChangeWD;
			if (!flag)
			{
				MessageBoxResult answer = DXMessageBox.Show("Delete every stored sample of this tool? The trained model stays on disk until you train again, but it can no longer be rebuilt from these samples.", "Variation Change WD", MessageBoxButton.OKCancel, MessageBoxImage.Question);
				bool flag2 = answer != MessageBoxResult.OK;
				if (!flag2)
				{
					try
					{
						new VariationChangeWDTrainService().ClearSamples(tool);
						DXMessageBox.Show("Samples cleared.", "Variation Change WD", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					}
					catch (Exception ex)
					{
						string str = "Clearing the samples failed:";
						string newLine = Environment.NewLine;
						Exception baseException = ex.GetBaseException();
						DXMessageBox.Show(str + newLine + (((baseException != null) ? baseException.Message : null) ?? ex.Message), "Variation Change WD", MessageBoxButton.OK, MessageBoxImage.Hand);
					}
				}
			}
		}

		// Token: 0x06001862 RID: 6242 RVA: 0x00077D14 File Offset: 0x00075F14
		public void VariationChangeWDTrain(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.VariationChangeWD;
			if (!flag)
			{
				try
				{
					VariationChangeWDTrainService service = new VariationChangeWDTrainService();
					VariationChangeWDTrainPreview preview = null;
					LoadingOverlay.Run(this, "Training Variation Change WD model...", delegate
					{
						preview = service.TrainModel(tool);
					});
					VariationChangeWDToolTrain train = tool.TrainModel as VariationChangeWDToolTrain;
					VariationChangeWDResultDrawer previewDrawer = new VariationChangeWDResultDrawer();
					this._displayController.ClearOverlay();
					this._displayController.SetOverlayRenderer(delegate(HWindow window)
					{
						previewDrawer.DrawTrainPreview(window, tool, preview);
					}, null);
					DXMessageBox.Show(((train != null) ? train.LastTrainMessage : null) ?? "Training completed.", "Variation Change WD", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				catch (Exception ex)
				{
					string str = "Variation Change WD training failed:";
					string newLine = Environment.NewLine;
					Exception baseException = ex.GetBaseException();
					DXMessageBox.Show(str + newLine + (((baseException != null) ? baseException.Message : null) ?? ex.Message), "Variation Change WD", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		// Token: 0x06001863 RID: 6243 RVA: 0x00077E4C File Offset: 0x0007604C
		public void VariationChangeWDTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.VariationChangeWD;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001864 RID: 6244 RVA: 0x00077E90 File Offset: 0x00076090
		public void ProductCountInspectionTrain(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.ProductCountInspection;
			if (!flag)
			{
				this.RunProductCountInspectionTraining(tool, Form_setting.ProductCountTrainingMode.Train);
			}
		}

		// Token: 0x06001865 RID: 6245 RVA: 0x00077EC0 File Offset: 0x000760C0
		public void ProductCountInspectionPredictTrain(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.ProductCountInspection;
			if (!flag)
			{
				this.RunProductCountInspectionTraining(tool, Form_setting.ProductCountTrainingMode.Predict);
			}
		}

		// Token: 0x06001866 RID: 6246 RVA: 0x00077EF0 File Offset: 0x000760F0
		public void ProductCountInspectionPretrain(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.ProductCountInspection;
			if (!flag)
			{
				this.RunProductCountInspectionTraining(tool, Form_setting.ProductCountTrainingMode.Pretrain);
			}
		}

		// Token: 0x06001867 RID: 6247 RVA: 0x00077F20 File Offset: 0x00076120
		public void ProductCountInspectionClearTraining(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.ProductCountInspection;
			if (!flag)
			{
				bool flag2 = DXMessageBox.Show("Clear every trained Product Count Inspection model and sample?", "Product Count Inspection", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) != MessageBoxResult.Yes;
				if (!flag2)
				{
					try
					{
						new ProductCountInspectionTrainService().ClearTraining(tool);
						this._displayController.ClearOverlay();
						this.SaveAllConfigSilently();
						DXMessageBox.Show("All Product Count Inspection training data was cleared.", "Product Count Inspection", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					}
					catch (Exception ex)
					{
						string str = "Product Count Inspection clear failed:";
						string newLine = Environment.NewLine;
						Exception baseException = ex.GetBaseException();
						DXMessageBox.Show(str + newLine + (((baseException != null) ? baseException.Message : null) ?? ex.Message), "Product Count Inspection", MessageBoxButton.OK, MessageBoxImage.Hand);
					}
				}
			}
		}

		// Token: 0x06001868 RID: 6248 RVA: 0x00077FF0 File Offset: 0x000761F0
		private void RunProductCountInspectionTraining(ToolVision tool, Form_setting.ProductCountTrainingMode mode)
		{
			HObject original = null;
			HObject input = null;
			ImageBufferStore bufferStore = null;
			try
			{
				original = this._displayController.GetOriginalImage();
				bufferStore = new ImageBufferStore();
				ProductCountInspectionTrainPreview preview = null;
				ProductCountInspectionTrainService service = new ProductCountInspectionTrainService();
				bool flag = original != null && original.IsInitialized();
				if (flag)
				{
					ToolProcessContext processContext = new ToolProcessContext
					{
						OriginalImage = original,
						InputImage = original,
						BufferStore = bufferStore
					};
					input = new ToolTrialRunPipelineService().BuildInputImageForTool(processContext, tool);
					bool flag2 = input == null || !input.IsInitialized();
					if (flag2)
					{
						if (input != null)
						{
							input.Dispose();
						}
						HOperatorSet.CopyImage(original, out input);
					}
					this._displayController.DisplayImage(input);
				}
				HObject trainImage = input;
				LoadingOverlay.Run(this, (mode == Form_setting.ProductCountTrainingMode.Train) ? "Training the first product..." : ((mode == Form_setting.ProductCountTrainingMode.Predict) ? "Predicting products in the current image..." : "Adding predicted products to the trained model..."), delegate
				{
					bool flag4 = mode == Form_setting.ProductCountTrainingMode.Train;
					if (flag4)
					{
						preview = service.TrainModel(tool, trainImage);
					}
					else
					{
						bool flag5 = mode == Form_setting.ProductCountTrainingMode.Predict;
						if (flag5)
						{
							preview = service.PredictTrainModel(tool, trainImage);
						}
						else
						{
							preview = service.PretrainModel(tool, trainImage);
						}
					}
				});
				ProductCountInspectionToolTrain train = tool.TrainModel as ProductCountInspectionToolTrain;
				ProductCountInspectionResultDrawer previewDrawer = new ProductCountInspectionResultDrawer();
				this._displayController.ClearOverlay();
				this._displayController.SetOverlayRenderer(delegate(HWindow window)
				{
					previewDrawer.DrawTrainPreview(window, tool, preview);
				}, null);
				bool flag3 = mode != Form_setting.ProductCountTrainingMode.Predict;
				if (flag3)
				{
					this.SaveAllConfigSilently();
				}
				DXMessageBox.Show(((train != null) ? train.LastTrainMessage : null) ?? "Training completed.", "Product Count Inspection", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			catch (Exception ex)
			{
				string str = (mode == Form_setting.ProductCountTrainingMode.Train) ? "Product Count Inspection training failed:" : ((mode == Form_setting.ProductCountTrainingMode.Predict) ? "Product Count Inspection predict failed:" : "Product Count Inspection pretrain failed:");
				string newLine = Environment.NewLine;
				Exception baseException = ex.GetBaseException();
				DXMessageBox.Show(str + newLine + (((baseException != null) ? baseException.Message : null) ?? ex.Message), "Product Count Inspection", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			finally
			{
				if (input != null)
				{
					input.Dispose();
				}
				if (bufferStore != null)
				{
					bufferStore.Clear();
				}
				if (original != null)
				{
					original.Dispose();
				}
			}
		}

		// Token: 0x06001869 RID: 6249 RVA: 0x00078270 File Offset: 0x00076470
		private void ToolboxCustomization_Click(object sender, RoutedEventArgs e)
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel viewModel = (instance != null) ? instance.MainViewModel : null;
			bool flag = viewModel == null;
			if (!flag)
			{
				ToolboxCustomizationWindow dialog = new ToolboxCustomizationWindow(viewModel.ToolCatalog)
				{
					Owner = WindowOwnerHelper.GetValidOwner(null)
				};
				bool flag2 = !dialog.ShowDialog().GetValueOrDefault();
				if (!flag2)
				{
					viewModel.ApplyToolboxVisibility();
				}
			}
		}

		// Token: 0x0600186A RID: 6250 RVA: 0x000782D4 File Offset: 0x000764D4
		public void ProcedureModelTrain()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ProcedureModel;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = this._displayController.GetOriginalImage();
					bool flag2 = original != null && original.IsInitialized();
					if (flag2)
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						input = new ToolTrialRunPipelineService().BuildInputImageForTool(processContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							if (input != null)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						this._displayController.DisplayImage(input);
					}
					new ProcedureModelTrainService().Train(tool, input);
					this.RefreshTrainPreview(tool);
				}
				finally
				{
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x0600186B RID: 6251 RVA: 0x000783EC File Offset: 0x000765EC
		public void ProcedureModelMatching()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ProcedureModel;
			if (!flag)
			{
				this._toolActionDispatcher.Matching(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600186C RID: 6252 RVA: 0x00078430 File Offset: 0x00076630
		public void ProcedureModelDefineMaster()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ProcedureModel;
			if (!flag)
			{
				this._toolActionDispatcher.DefineMaster(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600186D RID: 6253 RVA: 0x00078474 File Offset: 0x00076674
		public void ProcedureModelTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ProcedureModel;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600186E RID: 6254 RVA: 0x000784B8 File Offset: 0x000766B8
		public void ProcedureInspectionTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ProcedureInspection;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x0600186F RID: 6255 RVA: 0x000784FC File Offset: 0x000766FC
		public void CountBoundingBoxTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.CountBoundingBox;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001870 RID: 6256 RVA: 0x00078540 File Offset: 0x00076740
		public void FindRedArrowTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.FindRedArrow;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001871 RID: 6257 RVA: 0x00078584 File Offset: 0x00076784
		public void ProductCountInspectionTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.ProductCountInspection;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001872 RID: 6258 RVA: 0x000785C8 File Offset: 0x000767C8
		public void VariationModelTrialRun()
		{
			ToolVision tool = this.GetSelectedTool();
			bool flag = tool == null || tool.ToolType != ToolType.VariationModel;
			if (!flag)
			{
				this._toolActionDispatcher.TrialRun(this._toolActionContext, tool);
			}
		}

		// Token: 0x06001873 RID: 6259 RVA: 0x0007860C File Offset: 0x0007680C
		public void DLObjectInspectionLoadModel(ToolVision tool)
		{
			Form_setting.<>c__DisplayClass385_0 CS$<>8__locals1 = new Form_setting.<>c__DisplayClass385_0();
			CS$<>8__locals1.<>4__this = this;
			bool flag = tool == null || tool.ToolType != ToolType.DLObjectInspection;
			if (!flag)
			{
				Form_setting.<>c__DisplayClass385_0 CS$<>8__locals2 = CS$<>8__locals1;
				MainWindow instance = MainWindow.instance;
				ObservableCollection<CameraNode> cameras;
				if (instance == null)
				{
					cameras = null;
				}
				else
				{
					MainViewModel mainViewModel = instance.MainViewModel;
					cameras = ((mainViewModel != null) ? mainViewModel.Cameras : null);
				}
				CS$<>8__locals2.cameras = cameras;
				try
				{
					LoadingOverlay.Run(this, "Loading all DL models on Python server...", delegate
					{
						string message;
						bool ok = DLObjectInspectionLoadModelService.LoadAll(CS$<>8__locals1.cameras, out message, null);
						CS$<>8__locals1.<>4__this._dlLoadModelMessage = (string.IsNullOrWhiteSpace(message) ? "No DL model was loaded." : message);
						CS$<>8__locals1.<>4__this._dlLoadModelOk = ok;
					});
					DXMessageBox.Show(this._dlLoadModelMessage, "DL Object Inspection", MessageBoxButton.OK, this._dlLoadModelOk ? MessageBoxImage.Asterisk : MessageBoxImage.Exclamation);
				}
				catch (Exception ex)
				{
					DXMessageBox.Show("Load model failed:\n" + ex.Message, "DL Object Inspection", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		// Token: 0x06001874 RID: 6260 RVA: 0x000786D8 File Offset: 0x000768D8
		private void RefreshTrainPreview(ToolVision tool)
		{
			bool flag = tool == null;
			if (!flag)
			{
				bool flag2 = tool.ToolType != ToolType.OverlappingShapeModel;
				if (flag2)
				{
					this.RefreshShapeModelPreview(tool);
				}
				else
				{
					OverlappingShapeModelTrainPreview preview = OverlappingShapeModelTrainPreview.Load(tool);
					this._displayController.ClearOverlay();
					this._displayController.SetOverlayRenderer(delegate(HWindow window)
					{
						OverlappingShapeModelTrainPreview preview = preview;
						if (preview != null)
						{
							preview.Draw(window, tool);
						}
					}, preview);
				}
			}
		}

		// Token: 0x06001875 RID: 6261 RVA: 0x00078764 File Offset: 0x00076964
		private void TrainShapeModelWithCorrectService(ToolVision tool, HObject input = null)
		{
			bool flag = tool == null;
			if (!flag)
			{
				bool flag2 = tool.ToolType == ToolType.AnisoShapeModel;
				if (flag2)
				{
					AnisoShapeModelTrainService service = new AnisoShapeModelTrainService();
					service.TrainShapeModel(tool, input);
				}
				else
				{
					bool flag3 = tool.ToolType == ToolType.OverlappingShapeModel;
					if (flag3)
					{
						OverlappingShapeModelTrainService service2 = new OverlappingShapeModelTrainService();
						service2.TrainShapeModel(tool, input);
					}
					else
					{
						SettingShapeModelTrainService shapeService = new SettingShapeModelTrainService();
						shapeService.TrainShapeModel(tool, input);
					}
				}
			}
		}

		// Token: 0x06001876 RID: 6262 RVA: 0x000787D0 File Offset: 0x000769D0
		private void MoveToolUp_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement fe = sender as FrameworkElement;
			bool flag = fe == null;
			if (!flag)
			{
				ToolVision tool = fe.Tag as ToolVision;
				bool flag2 = tool == null;
				if (!flag2)
				{
					TurnSnap turnSnap = tool.ParentTurnSnap;
					bool flag3 = turnSnap == null;
					if (!flag3)
					{
						int index = turnSnap.Tools.IndexOf(tool);
						this._turnSnapService.MoveTool(turnSnap, tool, index - 1);
						this.RefreshCurrentToolConfig(turnSnap);
					}
				}
			}
		}

		// Token: 0x06001877 RID: 6263 RVA: 0x00078848 File Offset: 0x00076A48
		private void MoveToolDown_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement fe = sender as FrameworkElement;
			bool flag = fe == null;
			if (!flag)
			{
				ToolVision tool = fe.Tag as ToolVision;
				bool flag2 = tool == null;
				if (!flag2)
				{
					TurnSnap turnSnap = tool.ParentTurnSnap;
					bool flag3 = turnSnap == null;
					if (!flag3)
					{
						int index = turnSnap.Tools.IndexOf(tool);
						this._turnSnapService.MoveTool(turnSnap, tool, index + 1);
						this.RefreshCurrentToolConfig(turnSnap);
					}
				}
			}
		}

		// Token: 0x06001878 RID: 6264 RVA: 0x000788C0 File Offset: 0x00076AC0
		private void RefreshCurrentToolConfig(TurnSnap turnSnap)
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			ToolVision toolToRefresh = null;
			UserControl parameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
			ImageFilterParameterPanelViewModel filterVm;
			bool flag;
			if (parameterView != null)
			{
				filterVm = (parameterView.DataContext as ImageFilterParameterPanelViewModel);
				if (filterVm != null)
				{
					ToolVision tool = filterVm.Tool;
					flag = (((tool != null) ? tool.ParentTurnSnap : null) == turnSnap);
					goto IL_51;
				}
			}
			flag = false;
			IL_51:
			bool flag2 = flag;
			if (flag2)
			{
				toolToRefresh = filterVm.Tool;
			}
			else
			{
				UserControl shapeParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
				ShapeModelParameterPanelViewModel shapeVm;
				bool flag3;
				if (shapeParameterView != null)
				{
					shapeVm = (shapeParameterView.DataContext as ShapeModelParameterPanelViewModel);
					if (shapeVm != null)
					{
						ToolVision tool2 = shapeVm.Tool;
						flag3 = (((tool2 != null) ? tool2.ParentTurnSnap : null) == turnSnap);
						goto IL_A7;
					}
				}
				flag3 = false;
				IL_A7:
				bool flag4 = flag3;
				if (flag4)
				{
					toolToRefresh = shapeVm.Tool;
				}
				else
				{
					UserControl blobParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
					BlobParameterPanelViewModel blobVm;
					bool flag5;
					if (blobParameterView != null)
					{
						blobVm = (blobParameterView.DataContext as BlobParameterPanelViewModel);
						if (blobVm != null)
						{
							ToolVision tool3 = blobVm.Tool;
							flag5 = (((tool3 != null) ? tool3.ParentTurnSnap : null) == turnSnap);
							goto IL_FE;
						}
					}
					flag5 = false;
					IL_FE:
					bool flag6 = flag5;
					if (flag6)
					{
						toolToRefresh = blobVm.Tool;
					}
					else
					{
						UserControl histogramParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
						HistogramParameterPanelViewModel histogramVm;
						bool flag7;
						if (histogramParameterView != null)
						{
							histogramVm = (histogramParameterView.DataContext as HistogramParameterPanelViewModel);
							if (histogramVm != null)
							{
								ToolVision tool4 = histogramVm.Tool;
								flag7 = (((tool4 != null) ? tool4.ParentTurnSnap : null) == turnSnap);
								goto IL_155;
							}
						}
						flag7 = false;
						IL_155:
						bool flag8 = flag7;
						if (flag8)
						{
							toolToRefresh = histogramVm.Tool;
						}
						else
						{
							UserControl histogramColorParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
							HistogramColorParameterPanelViewModel histogramColorVm;
							bool flag9;
							if (histogramColorParameterView != null)
							{
								histogramColorVm = (histogramColorParameterView.DataContext as HistogramColorParameterPanelViewModel);
								if (histogramColorVm != null)
								{
									ToolVision tool5 = histogramColorVm.Tool;
									flag9 = (((tool5 != null) ? tool5.ParentTurnSnap : null) == turnSnap);
									goto IL_1AC;
								}
							}
							flag9 = false;
							IL_1AC:
							bool flag10 = flag9;
							if (flag10)
							{
								toolToRefresh = histogramColorVm.Tool;
							}
							else
							{
								UserControl findLineParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
								FindLineParameterPanelViewModel findLineVm;
								bool flag11;
								if (findLineParameterView != null)
								{
									findLineVm = (findLineParameterView.DataContext as FindLineParameterPanelViewModel);
									if (findLineVm != null)
									{
										ToolVision tool6 = findLineVm.Tool;
										flag11 = (((tool6 != null) ? tool6.ParentTurnSnap : null) == turnSnap);
										goto IL_203;
									}
								}
								flag11 = false;
								IL_203:
								bool flag12 = flag11;
								if (flag12)
								{
									toolToRefresh = findLineVm.Tool;
								}
								else
								{
									UserControl findCircleParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
									FindCircleParameterPanelViewModel findCircleVm;
									bool flag13;
									if (findCircleParameterView != null)
									{
										findCircleVm = (findCircleParameterView.DataContext as FindCircleParameterPanelViewModel);
										if (findCircleVm != null)
										{
											ToolVision tool7 = findCircleVm.Tool;
											flag13 = (((tool7 != null) ? tool7.ParentTurnSnap : null) == turnSnap);
											goto IL_25A;
										}
									}
									flag13 = false;
									IL_25A:
									bool flag14 = flag13;
									if (flag14)
									{
										toolToRefresh = findCircleVm.Tool;
									}
									else
									{
										UserControl circleMasterParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
										CircleMasterParameterPanelViewModel circleMasterVm;
										bool flag15;
										if (circleMasterParameterView != null)
										{
											circleMasterVm = (circleMasterParameterView.DataContext as CircleMasterParameterPanelViewModel);
											if (circleMasterVm != null)
											{
												ToolVision tool8 = circleMasterVm.Tool;
												flag15 = (((tool8 != null) ? tool8.ParentTurnSnap : null) == turnSnap);
												goto IL_2B1;
											}
										}
										flag15 = false;
										IL_2B1:
										bool flag16 = flag15;
										if (flag16)
										{
											toolToRefresh = circleMasterVm.Tool;
										}
										else
										{
											UserControl findBoundingBoxParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
											FindBoundingBoxParameterPanelViewModel findBoundingBoxVm;
											bool flag17;
											if (findBoundingBoxParameterView != null)
											{
												findBoundingBoxVm = (findBoundingBoxParameterView.DataContext as FindBoundingBoxParameterPanelViewModel);
												if (findBoundingBoxVm != null)
												{
													ToolVision tool9 = findBoundingBoxVm.Tool;
													flag17 = (((tool9 != null) ? tool9.ParentTurnSnap : null) == turnSnap);
													goto IL_308;
												}
											}
											flag17 = false;
											IL_308:
											bool flag18 = flag17;
											if (flag18)
											{
												toolToRefresh = findBoundingBoxVm.Tool;
											}
											else
											{
												UserControl findMinAreaParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
												FindMinAreaParameterPanelViewModel findMinAreaVm;
												bool flag19;
												if (findMinAreaParameterView != null)
												{
													findMinAreaVm = (findMinAreaParameterView.DataContext as FindMinAreaParameterPanelViewModel);
													if (findMinAreaVm != null)
													{
														ToolVision tool10 = findMinAreaVm.Tool;
														flag19 = (((tool10 != null) ? tool10.ParentTurnSnap : null) == turnSnap);
														goto IL_35F;
													}
												}
												flag19 = false;
												IL_35F:
												bool flag20 = flag19;
												if (flag20)
												{
													toolToRefresh = findMinAreaVm.Tool;
												}
												else
												{
													UserControl minAreaMasterParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
													MinAreaMasterParameterPanelViewModel minAreaMasterVm;
													bool flag21;
													if (minAreaMasterParameterView != null)
													{
														minAreaMasterVm = (minAreaMasterParameterView.DataContext as MinAreaMasterParameterPanelViewModel);
														if (minAreaMasterVm != null)
														{
															ToolVision tool11 = minAreaMasterVm.Tool;
															flag21 = (((tool11 != null) ? tool11.ParentTurnSnap : null) == turnSnap);
															goto IL_3B6;
														}
													}
													flag21 = false;
													IL_3B6:
													bool flag22 = flag21;
													if (flag22)
													{
														toolToRefresh = minAreaMasterVm.Tool;
													}
													else
													{
														UserControl distanceObjectParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
														DistanceObjectParameterPanelViewModel distanceVm;
														bool flag23;
														if (distanceObjectParameterView != null)
														{
															distanceVm = (distanceObjectParameterView.DataContext as DistanceObjectParameterPanelViewModel);
															if (distanceVm != null)
															{
																ToolVision tool12 = distanceVm.Tool;
																flag23 = (((tool12 != null) ? tool12.ParentTurnSnap : null) == turnSnap);
																goto IL_40D;
															}
														}
														flag23 = false;
														IL_40D:
														bool flag24 = flag23;
														if (flag24)
														{
															toolToRefresh = distanceVm.Tool;
														}
														else
														{
															UserControl measureCircleParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
															MeasureCircleParameterPanelViewModel measureCircleVm;
															bool flag25;
															if (measureCircleParameterView != null)
															{
																measureCircleVm = (measureCircleParameterView.DataContext as MeasureCircleParameterPanelViewModel);
																if (measureCircleVm != null)
																{
																	ToolVision tool13 = measureCircleVm.Tool;
																	flag25 = (((tool13 != null) ? tool13.ParentTurnSnap : null) == turnSnap);
																	goto IL_464;
																}
															}
															flag25 = false;
															IL_464:
															bool flag26 = flag25;
															if (flag26)
															{
																toolToRefresh = measureCircleVm.Tool;
															}
															else
															{
																UserControl angleSelectorParameterView = ((vm != null) ? vm.CurrentParameterView : null) as UserControl;
																AngleSelectorParameterPanelViewModel angleVm;
																bool flag27;
																if (angleSelectorParameterView != null)
																{
																	angleVm = (angleSelectorParameterView.DataContext as AngleSelectorParameterPanelViewModel);
																	if (angleVm != null)
																	{
																		ToolVision tool14 = angleVm.Tool;
																		flag27 = (((tool14 != null) ? tool14.ParentTurnSnap : null) == turnSnap);
																		goto IL_4B8;
																	}
																}
																flag27 = false;
																IL_4B8:
																bool flag28 = flag27;
																if (flag28)
																{
																	toolToRefresh = angleVm.Tool;
																}
																else
																{
																	TurnSnap turnSnap2;
																	if (vm == null)
																	{
																		turnSnap2 = null;
																	}
																	else
																	{
																		ToolVision selectedTool = vm.SelectedTool;
																		turnSnap2 = ((selectedTool != null) ? selectedTool.ParentTurnSnap : null);
																	}
																	bool flag29 = turnSnap2 == turnSnap;
																	if (flag29)
																	{
																		toolToRefresh = vm.SelectedTool;
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			bool flag30 = toolToRefresh == null;
			if (!flag30)
			{
				this._toolSelectionService.SelectTool(toolToRefresh);
			}
		}

		// Token: 0x06001879 RID: 6265 RVA: 0x00078DDC File Offset: 0x00076FDC
		private void ToolGrid_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			bool isInitializingToolSelection = this._isInitializingToolSelection;
			if (!isInitializingToolSelection)
			{
				ToolVision tool = e.NewRow as ToolVision;
				bool flag = tool != null;
				if (flag)
				{
					TableView view = sender as TableView;
					object obj;
					if (view == null)
					{
						obj = null;
					}
					else
					{
						GridControl grid = view.Grid;
						obj = ((grid != null) ? grid.DataContext : null);
					}
					TurnSnap turnSnap = obj as TurnSnap;
					bool flag2 = turnSnap == null || !turnSnap.Tools.Contains(tool);
					if (!flag2)
					{
						this.OpenToolConfig(tool);
					}
				}
			}
		}

		// Token: 0x0600187A RID: 6266 RVA: 0x00078E5C File Offset: 0x0007705C
		private void ToolGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			bool isInitializingToolSelection = this._isInitializingToolSelection;
			if (!isInitializingToolSelection)
			{
				bool flag = this.IsInteractiveGridElement(e.OriginalSource as DependencyObject);
				if (!flag)
				{
					GridControl grid = sender as GridControl;
					TurnSnap turnSnap = ((grid != null) ? grid.DataContext : null) as TurnSnap;
					bool flag2 = turnSnap == null;
					if (!flag2)
					{
						ToolVision tool = grid.CurrentItem as ToolVision;
						bool flag3 = tool == null;
						if (flag3)
						{
							tool = (grid.SelectedItem as ToolVision);
						}
						bool flag4 = tool == null || !turnSnap.Tools.Contains(tool);
						if (!flag4)
						{
							this.OpenToolConfig(tool);
						}
					}
				}
			}
		}

		// Token: 0x0600187B RID: 6267 RVA: 0x00078F00 File Offset: 0x00077100
		private bool IsInteractiveGridElement(DependencyObject source)
		{
			bool flag = source == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = Form_setting.FindVisualParent<ButtonBase>(source) != null;
				if (flag2)
				{
					result = true;
				}
				else
				{
					bool flag3 = Form_setting.FindVisualParent<ToggleSwitchEdit>(source) != null;
					result = flag3;
				}
			}
			return result;
		}

		// Token: 0x0600187C RID: 6268 RVA: 0x00078F44 File Offset: 0x00077144
		private void ToolGrid_RowDoubleClick(object sender, RowDoubleClickEventArgs e)
		{
			TableView view = sender as TableView;
			ToolVision tool;
			bool flag;
			if (view != null)
			{
				GridControl grid = view.Grid;
				tool = (((grid != null) ? grid.CurrentItem : null) as ToolVision);
				flag = (tool != null);
			}
			else
			{
				flag = false;
			}
			bool flag2 = flag;
			if (flag2)
			{
				this.OpenToolConfig(tool);
			}
		}

		// Token: 0x0600187D RID: 6269 RVA: 0x00078F8C File Offset: 0x0007718C
		private void OpenToolConfig(ToolVision tool)
		{
			bool flag = tool == null;
			if (!flag)
			{
				this.ResetShowAllRoi();
				this._toolSelectionService.SelectTool(tool);
				bool flag2 = tool.ParentTurnSnap != null;
				if (flag2)
				{
					this.LoadMasterImageForTurnSnap(tool.ParentTurnSnap);
				}
			}
		}

		// Token: 0x0600187E RID: 6270 RVA: 0x00078FD4 File Offset: 0x000771D4
		private void ResetShowAllRoi()
		{
			bool flag = this._showAllRoiPanels.Count == 0;
			if (!flag)
			{
				this._showAllRoiPanels.Clear();
				bool flag2 = this.ShowAllRoiMenuItem != null;
				if (flag2)
				{
					this.ShowAllRoiMenuItem.IsChecked = false;
				}
				bool flag3 = this.ShowAllLimitRoiMenuItem != null;
				if (flag3)
				{
					this.ShowAllLimitRoiMenuItem.IsChecked = false;
				}
				bool flag4 = this.ShowAllMaskRoiMenuItem != null;
				if (flag4)
				{
					this.ShowAllMaskRoiMenuItem.IsChecked = false;
				}
				this.RefreshRoiOverlay();
			}
		}

		// Token: 0x0600187F RID: 6271 RVA: 0x00079058 File Offset: 0x00077258
		private void ToolGrid_DragOver(object sender, DragEventArgs e)
		{
			e.Effects = ((e.Data.GetDataPresent("ToolVision") || e.Data.GetDataPresent(typeof(ToolVision))) ? DragDropEffects.Copy : DragDropEffects.None);
			e.Handled = true;
		}

		// Token: 0x06001880 RID: 6272 RVA: 0x000790A8 File Offset: 0x000772A8
		private void ToolGrid_Drop(object sender, DragEventArgs e)
		{
			ToolVision draggedTool = null;
			bool dataPresent = e.Data.GetDataPresent("ToolVision");
			if (dataPresent)
			{
				draggedTool = (e.Data.GetData("ToolVision") as ToolVision);
			}
			bool flag = draggedTool == null && e.Data.GetDataPresent(typeof(ToolVision));
			if (flag)
			{
				draggedTool = (e.Data.GetData(typeof(ToolVision)) as ToolVision);
			}
			bool flag2 = draggedTool == null;
			if (!flag2)
			{
				bool flag3 = draggedTool.Children != null && draggedTool.Children.Count > 0;
				if (flag3)
				{
					e.Effects = DragDropEffects.None;
					e.Handled = true;
				}
				else
				{
					GridControl grid = sender as GridControl;
					bool flag4 = grid == null;
					if (!flag4)
					{
						TurnSnap turnSnap = grid.DataContext as TurnSnap;
						bool flag5 = turnSnap == null;
						if (!flag5)
						{
							this._turnSnapService.AddToolToTurnSnap(draggedTool, turnSnap);
							base.Dispatcher.BeginInvoke(new Action(delegate()
							{
								this.RefreshToolGridHeight(grid);
							}), DispatcherPriority.Loaded, Array.Empty<object>());
							e.Handled = true;
						}
					}
				}
			}
		}

		// Token: 0x06001881 RID: 6273 RVA: 0x000791E0 File Offset: 0x000773E0
		private double CalculateToolGridHeight(TurnSnap turnSnap)
		{
			int? num;
			if (turnSnap == null)
			{
				num = null;
			}
			else
			{
				ObservableCollection<ToolVision> tools = turnSnap.Tools;
				num = ((tools != null) ? new int?(tools.Count) : null);
			}
			int? num2 = num;
			int count = num2.GetValueOrDefault();
			double rowHeight = 34.0;
			double headerHeight = 32.0;
			double minHeight = 70.0;
			double extraHeight = 16.0;
			double height = headerHeight + rowHeight * (double)Math.Max(count, 1) + extraHeight;
			return Math.Max(height, minHeight);
		}

		// Token: 0x06001882 RID: 6274 RVA: 0x00079270 File Offset: 0x00077470
		private GridControl FindToolGridForTurnSnap(TurnSnap turnSnap)
		{
			bool flag = turnSnap == null;
			GridControl result;
			if (flag)
			{
				result = null;
			}
			else
			{
				foreach (GridControl grid in this.FindVisualChildren<GridControl>(this))
				{
					bool flag2 = grid.DataContext == turnSnap;
					if (flag2)
					{
						return grid;
					}
				}
				result = null;
			}
			return result;
		}

		// Token: 0x06001883 RID: 6275 RVA: 0x000792E0 File Offset: 0x000774E0
		private DependencyObject FindAncestorContainingToolGrid(DependencyObject start)
		{
			for (DependencyObject node = start; node != null; node = VisualTreeHelper.GetParent(node))
			{
				bool flag = Form_setting.FindVisualChild<GridControl>(node) != null;
				if (flag)
				{
					return node;
				}
			}
			return null;
		}

		// Token: 0x06001884 RID: 6276 RVA: 0x0007931C File Offset: 0x0007751C
		private void RefreshToolGridHeightForTurnSnap(TurnSnap turnSnap, DependencyObject clickedElement)
		{
			base.Dispatcher.BeginInvoke(new Action(delegate()
			{
				DependencyObject container = this.FindAncestorContainingToolGrid(clickedElement);
				bool flag = container != null;
				if (flag)
				{
					this.RefreshToolGridHeight(container);
				}
				else
				{
					GridControl grid = this.FindToolGridForTurnSnap(turnSnap);
					bool flag2 = grid != null;
					if (flag2)
					{
						this.RefreshToolGridHeight(grid);
					}
				}
			}), DispatcherPriority.Loaded, Array.Empty<object>());
		}

		// Token: 0x06001885 RID: 6277 RVA: 0x00079364 File Offset: 0x00077564
		private void RefreshToolGridHeight(DependencyObject source)
		{
			GridControl grid = source as GridControl;
			bool flag = grid == null;
			if (flag)
			{
				grid = Form_setting.FindVisualChild<GridControl>(source);
			}
			bool flag2 = grid == null;
			if (!flag2)
			{
				TurnSnap turnSnap = grid.DataContext as TurnSnap;
				bool flag3 = turnSnap == null;
				if (!flag3)
				{
					grid.Height = this.CalculateToolGridHeight(turnSnap);
					grid.UpdateLayout();
				}
			}
		}

		// Token: 0x06001886 RID: 6278 RVA: 0x000793C4 File Offset: 0x000775C4
		private void ToolGrid_Loaded(object sender, RoutedEventArgs e)
		{
			this.RefreshToolGridHeight(sender as DependencyObject);
			GridControl grid = sender as GridControl;
			this.AttachToolGridCopyPasteMenu(grid);
			TurnSnap turnSnap = ((grid != null) ? grid.DataContext : null) as TurnSnap;
			bool flag = turnSnap == null;
			if (!flag)
			{
				turnSnap.Tools.CollectionChanged -= this.ToolCollection_Changed;
				turnSnap.Tools.CollectionChanged += this.ToolCollection_Changed;
			}
		}

		// Token: 0x06001887 RID: 6279 RVA: 0x0007943C File Offset: 0x0007763C
		private void AttachToolGridCopyPasteMenu(GridControl grid)
		{
			bool flag = grid == null || grid.ContextMenu != null;
			if (!flag)
			{
				ContextMenu menu = new ContextMenu();
				MenuItem copyItem = new MenuItem
				{
					Header = "Copy tool",
					Tag = "copy"
				};
				copyItem.Click += this.CopyTool_Click;
				MenuItem pasteItem = new MenuItem
				{
					Header = "Paste tool",
					Tag = "paste"
				};
				pasteItem.Click += this.PasteTool_Click;
				menu.Items.Add(copyItem);
				menu.Items.Add(pasteItem);
				menu.Opened += this.ToolGridContextMenu_Opened;
				grid.ContextMenu = menu;
				grid.PreviewMouseRightButtonDown += this.ToolGrid_PreviewMouseRightButtonDown;
			}
		}

		// Token: 0x06001888 RID: 6280 RVA: 0x00079514 File Offset: 0x00077714
		private void ToolGrid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
		{
			GridControl grid = sender as GridControl;
			TableView view = ((grid != null) ? grid.View : null) as TableView;
			bool flag = view == null;
			if (!flag)
			{
				TableViewHitInfo hitInfo = view.CalcHitInfo(e.OriginalSource as DependencyObject);
				bool flag2 = hitInfo != null && hitInfo.RowHandle >= 0;
				if (flag2)
				{
					view.FocusedRowHandle = hitInfo.RowHandle;
				}
			}
		}

		// Token: 0x06001889 RID: 6281 RVA: 0x0007957C File Offset: 0x0007777C
		private void ToolGridContextMenu_Opened(object sender, RoutedEventArgs e)
		{
			ContextMenu menu = sender as ContextMenu;
			GridControl grid = ((menu != null) ? menu.PlacementTarget : null) as GridControl;
			ToolVision tool = ((grid != null) ? grid.SelectedItem : null) as ToolVision;
			foreach (object item in ((IEnumerable)menu.Items))
			{
				MenuItem menuItem = item as MenuItem;
				bool flag = menuItem == null;
				if (!flag)
				{
					string tag = menuItem.Tag as string;
					bool flag2 = tag == "copy";
					if (flag2)
					{
						menuItem.IsEnabled = (tool != null);
					}
					else
					{
						bool flag3 = tag == "paste";
						if (flag3)
						{
							menuItem.IsEnabled = ToolClipboardService.CanPasteInto(tool);
							menuItem.Header = (ToolClipboardService.HasCopy ? string.Format("Paste tool ({0})", ToolClipboardService.Copied.ToolType) : "Paste tool");
						}
					}
				}
			}
		}

		// Token: 0x0600188A RID: 6282 RVA: 0x000796A0 File Offset: 0x000778A0
		private GridControl GetToolGridFromMenuItem(object sender)
		{
			MenuItem menuItem = sender as MenuItem;
			ContextMenu menu = ((menuItem != null) ? menuItem.Parent : null) as ContextMenu;
			return ((menu != null) ? menu.PlacementTarget : null) as GridControl;
		}

		// Token: 0x0600188B RID: 6283 RVA: 0x000796DC File Offset: 0x000778DC
		private void CopyTool_Click(object sender, RoutedEventArgs e)
		{
			GridControl grid = this.GetToolGridFromMenuItem(sender);
			ToolVision tool = ((grid != null) ? grid.SelectedItem : null) as ToolVision;
			bool flag = tool == null;
			if (!flag)
			{
				ToolClipboardService.Copy(tool);
			}
		}

		// Token: 0x0600188C RID: 6284 RVA: 0x00079718 File Offset: 0x00077918
		private void PasteTool_Click(object sender, RoutedEventArgs e)
		{
			GridControl grid = this.GetToolGridFromMenuItem(sender);
			ToolVision target = ((grid != null) ? grid.SelectedItem : null) as ToolVision;
			bool flag = target == null;
			if (!flag)
			{
				bool flag2 = !ToolClipboardService.HasCopy;
				if (flag2)
				{
					DXMessageBox.Show("No tool has been copied yet. Right-click a tool and choose \"Copy tool\" first.", "Paste Tool", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					ToolVision source = ToolClipboardService.Copied;
					bool flag3 = source.ToolType != target.ToolType;
					if (flag3)
					{
						DXMessageBox.Show(string.Format("Cannot paste: the copied tool is \"{0}\" but the selected tool is \"{1}\".\n", source.ToolType, target.ToolType) + "Copy and paste only work between tools of the same type.", "Paste Tool", MessageBoxButton.OK, MessageBoxImage.Exclamation);
					}
					else
					{
						bool flag4 = source == target;
						if (!flag4)
						{
							try
							{
								ToolClipboardService.PasteInto(target, source);
								this._recipeService.SaveCurrentModelRecipe(false);
								this.OpenToolConfig(target);
								DXMessageBox.Show(string.Concat(new string[]
								{
									"Pasted all data from \"",
									source.Name,
									"\" into \"",
									target.Name,
									"\"."
								}), "Paste Tool", MessageBoxButton.OK, MessageBoxImage.Asterisk);
							}
							catch (Exception ex)
							{
								DXMessageBox.Show("Failed to paste tool data:\n" + ex.Message, "Paste Tool", MessageBoxButton.OK, MessageBoxImage.Hand);
							}
						}
					}
				}
			}
		}

		// Token: 0x0600188D RID: 6285 RVA: 0x00079878 File Offset: 0x00077A78
		private TurnSnap GetTurnSnapFromMenuItem(object sender)
		{
			MenuItem menuItem = sender as MenuItem;
			ContextMenu menu = ((menuItem != null) ? menuItem.Parent : null) as ContextMenu;
			FrameworkElement target = ((menu != null) ? menu.PlacementTarget : null) as FrameworkElement;
			return ((target != null) ? target.DataContext : null) as TurnSnap;
		}

		// Token: 0x0600188E RID: 6286 RVA: 0x000798C8 File Offset: 0x00077AC8
		private void TurnSnapContextMenu_Opened(object sender, RoutedEventArgs e)
		{
			ContextMenu menu = sender as ContextMenu;
			FrameworkElement frameworkElement = ((menu != null) ? menu.PlacementTarget : null) as FrameworkElement;
			TurnSnap target = ((frameworkElement != null) ? frameworkElement.DataContext : null) as TurnSnap;
			foreach (object item in ((IEnumerable)menu.Items))
			{
				MenuItem menuItem = item as MenuItem;
				bool flag = menuItem == null;
				if (!flag)
				{
					string tag = menuItem.Tag as string;
					bool flag2 = tag == "copy";
					if (flag2)
					{
						menuItem.IsEnabled = (target != null);
					}
					else
					{
						bool flag3 = tag == "paste";
						if (flag3)
						{
							menuItem.IsEnabled = ToolClipboardService.CanPasteTurnSnapInto(target);
							menuItem.Header = (ToolClipboardService.HasCopiedTurnSnap ? ("Paste turnsnap (" + ToolClipboardService.CopiedTurnSnap.DisplayName + ")") : "Paste turnsnap");
						}
						else
						{
							bool flag4 = tag == "copyimage";
							if (flag4)
							{
								menuItem.IsEnabled = (target != null);
							}
							else
							{
								bool flag5 = tag == "pasteimage";
								if (flag5)
								{
									menuItem.IsEnabled = ToolClipboardService.CanPasteImageInto(target);
									menuItem.Header = (ToolClipboardService.HasCopiedImage ? ("Paste image (from " + ToolClipboardService.CopiedImageTurnSnap.DisplayName + ")") : "Paste image");
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x0600188F RID: 6287 RVA: 0x00079A70 File Offset: 0x00077C70
		private void CopyTurnSnapImage_Click(object sender, RoutedEventArgs e)
		{
			TurnSnap turnSnap = this.GetTurnSnapFromMenuItem(sender);
			bool flag = turnSnap == null;
			if (!flag)
			{
				ToolClipboardService.CopyImage(turnSnap);
			}
		}

		// Token: 0x06001890 RID: 6288 RVA: 0x00079A98 File Offset: 0x00077C98
		private void PasteTurnSnapImage_Click(object sender, RoutedEventArgs e)
		{
			TurnSnap target = this.GetTurnSnapFromMenuItem(sender);
			bool flag = target == null;
			if (!flag)
			{
				bool flag2 = !ToolClipboardService.HasCopiedImage;
				if (flag2)
				{
					DXMessageBox.Show("No image has been copied yet. Right-click a turnsnap header and choose \"Copy image\" first.", "Paste Image", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					TurnSnap source = ToolClipboardService.CopiedImageTurnSnap;
					bool flag3 = source == target;
					if (!flag3)
					{
						try
						{
							bool copied = ToolClipboardService.PasteImageInto(target, source);
							bool flag4 = !copied;
							if (flag4)
							{
								DXMessageBox.Show("The source turnsnap \"" + source.DisplayName + "\" has no saved image to copy.", "Paste Image", MessageBoxButton.OK, MessageBoxImage.Exclamation);
							}
							else
							{
								SettingTurnSnapService turnSnapService = this._turnSnapService;
								TurnSnap selected = (turnSnapService != null) ? turnSnapService.GetSelectedTurnSnap() : null;
								bool flag5 = selected != null && selected == target;
								if (flag5)
								{
									this.LoadMasterImageForTurnSnap(target);
								}
								DXMessageBox.Show(string.Concat(new string[]
								{
									"Pasted image from \"",
									source.DisplayName,
									"\" into \"",
									target.DisplayName,
									"\"."
								}), "Paste Image", MessageBoxButton.OK, MessageBoxImage.Asterisk);
							}
						}
						catch (Exception ex)
						{
							DXMessageBox.Show("Failed to paste image:\n" + ex.Message, "Paste Image", MessageBoxButton.OK, MessageBoxImage.Hand);
						}
					}
				}
			}
		}

		// Token: 0x06001891 RID: 6289 RVA: 0x00079BE0 File Offset: 0x00077DE0
		private void CopyTurnSnap_Click(object sender, RoutedEventArgs e)
		{
			TurnSnap turnSnap = this.GetTurnSnapFromMenuItem(sender);
			bool flag = turnSnap == null;
			if (!flag)
			{
				ToolClipboardService.CopyTurnSnap(turnSnap);
			}
		}

		// Token: 0x06001892 RID: 6290 RVA: 0x00079C08 File Offset: 0x00077E08
		private void PasteTurnSnap_Click(object sender, RoutedEventArgs e)
		{
			TurnSnap target = this.GetTurnSnapFromMenuItem(sender);
			bool flag = target == null;
			if (!flag)
			{
				bool flag2 = !ToolClipboardService.HasCopiedTurnSnap;
				if (flag2)
				{
					DXMessageBox.Show("No turnsnap has been copied yet. Right-click a turnsnap header and choose \"Copy turnsnap\" first.", "Paste TurnSnap", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					TurnSnap source = ToolClipboardService.CopiedTurnSnap;
					bool flag3 = source == target;
					if (!flag3)
					{
						bool flag4 = target.Tools.Count > 0;
						if (flag4)
						{
							MessageBoxResult confirm = DXMessageBox.Show(string.Format("This will replace all {0} tool(s) in \"{1}\" ", target.Tools.Count, target.DisplayName) + string.Format("with the {0} tool(s) copied from \"{1}\".\n\nContinue?", source.Tools.Count, source.DisplayName), "Paste TurnSnap", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
							bool flag5 = confirm != MessageBoxResult.Yes;
							if (flag5)
							{
								return;
							}
						}
						MenuItem menuItem = sender as MenuItem;
						ContextMenu contextMenu = ((menuItem != null) ? menuItem.Parent : null) as ContextMenu;
						DependencyObject clickedElement = (contextMenu != null) ? contextMenu.PlacementTarget : null;
						try
						{
							ToolClipboardService.PasteTurnSnapInto(target, source);
							this._turnSnapService.UpdateToolOrder(target);
							this._recipeService.SaveCurrentModelRecipe(false);
							DXMessageBox.Show(string.Format("Pasted {0} tool(s) from \"{1}\" into \"{2}\".", target.Tools.Count, source.DisplayName, target.DisplayName), "Paste TurnSnap", MessageBoxButton.OK, MessageBoxImage.Asterisk);
							this.RefreshToolGridHeightForTurnSnap(target, clickedElement);
						}
						catch (Exception ex)
						{
							DXMessageBox.Show("Failed to paste turnsnap:\n" + ex.Message, "Paste TurnSnap", MessageBoxButton.OK, MessageBoxImage.Hand);
						}
					}
				}
			}
		}

		// Token: 0x06001893 RID: 6291 RVA: 0x00079DA0 File Offset: 0x00077FA0
		private void ToolCollection_Changed(object sender, NotifyCollectionChangedEventArgs e)
		{
			TurnSnap turnSnap = this.FindTurnSnapByTools(sender);
			bool flag = turnSnap == null;
			if (!flag)
			{
				this._turnSnapService.UpdateToolOrder(turnSnap);
				base.Dispatcher.BeginInvoke(new Action(delegate()
				{
					this.RefreshCurrentToolConfig(turnSnap);
				}), DispatcherPriority.Loaded, Array.Empty<object>());
			}
		}

		// Token: 0x06001894 RID: 6292 RVA: 0x00079E08 File Offset: 0x00078008
		private TurnSnap FindTurnSnapByTools(object tools)
		{
			MainWindow instance = MainWindow.instance;
			MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
			bool flag = vm == null;
			TurnSnap result;
			if (flag)
			{
				result = null;
			}
			else
			{
				foreach (CameraNode camera in vm.Cameras)
				{
					foreach (TurnSnap turnSnap in camera.TurnSnaps)
					{
						bool flag2 = turnSnap.Tools == tools;
						if (flag2)
						{
							return turnSnap;
						}
					}
				}
				result = null;
			}
			return result;
		}

		// Token: 0x06001895 RID: 6293 RVA: 0x00079ECC File Offset: 0x000780CC
		private static T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
		{
			bool flag = parent == null;
			T result2;
			if (flag)
			{
				result2 = default(T);
			}
			else
			{
				int count = VisualTreeHelper.GetChildrenCount(parent);
				for (int i = 0; i < count; i++)
				{
					DependencyObject child = VisualTreeHelper.GetChild(parent, i);
					T result = child as T;
					bool flag2 = result != null;
					if (flag2)
					{
						return result;
					}
					T subChild = Form_setting.FindVisualChild<T>(child);
					bool flag3 = subChild != null;
					if (flag3)
					{
						return subChild;
					}
				}
				result2 = default(T);
			}
			return result2;
		}

		// Token: 0x06001896 RID: 6294 RVA: 0x00079F68 File Offset: 0x00078168
		private static T FindVisualParent<T>(DependencyObject child) where T : DependencyObject
		{
			while (child != null)
			{
				T result = child as T;
				bool flag = result != null;
				if (flag)
				{
					return result;
				}
				child = VisualTreeHelper.GetParent(child);
			}
			return default(T);
		}

		// Token: 0x0600189A RID: 6298 RVA: 0x0007AB10 File Offset: 0x00078D10
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId <= 56)
			{
				switch (connectionId)
				{
				case 6:
					((Border)target).DragOver += this.TurnSnap_DragOver;
					((Border)target).Drop += this.TurnSnap_Drop;
					break;
				case 7:
					((ContextMenu)target).Opened += this.TurnSnapContextMenu_Opened;
					break;
				case 8:
					((MenuItem)target).Click += this.CopyTurnSnap_Click;
					break;
				case 9:
					((MenuItem)target).Click += this.PasteTurnSnap_Click;
					break;
				case 10:
					((MenuItem)target).Click += this.CopyTurnSnapImage_Click;
					break;
				case 11:
					((MenuItem)target).Click += this.PasteTurnSnapImage_Click;
					break;
				case 12:
					((Button)target).Click += this.ToggleToolList_Click;
					break;
				case 13:
					((Button)target).Click += this.TurnSnapButton_Click;
					break;
				case 14:
					((SimpleButton)target).Click += this.MoveTurnSnapUp_Click;
					break;
				case 15:
					((SimpleButton)target).Click += this.MoveTurnSnapDown_Click;
					break;
				case 16:
					((SimpleButton)target).Click += this.DeleteTurnSnap_Click;
					break;
				case 17:
					((GridControl)target).DragOver += this.ToolGrid_DragOver;
					((GridControl)target).Drop += this.ToolGrid_Drop;
					((GridControl)target).MouseLeftButtonUp += this.ToolGrid_MouseLeftButtonUp;
					((GridControl)target).Loaded += this.ToolGrid_Loaded;
					break;
				case 18:
					((SimpleButton)target).Click += this.MoveToolUp_Click;
					break;
				case 19:
					((SimpleButton)target).Click += this.MoveToolDown_Click;
					break;
				case 20:
					((SimpleButton)target).Click += this.DeleteTool_Click;
					break;
				case 21:
					((TableView)target).RowDoubleClick += this.ToolGrid_RowDoubleClick;
					((TableView)target).FocusedRowChanged += this.ToolGrid_FocusedRowChanged;
					break;
				default:
					switch (connectionId)
					{
					case 54:
						((Button)target).Click += this.RoiItem_Click;
						break;
					case 55:
						((SimpleButton)target).Click += this.EditRoi_Click;
						break;
					case 56:
						((SimpleButton)target).Click += this.DeleteRoi_Click;
						break;
					}
					break;
				}
			}
			else
			{
				switch (connectionId)
				{
				case 70:
					((Button)target).Click += this.LimitRoiItem_Click;
					break;
				case 71:
					((SimpleButton)target).Click += this.EditRoi_Click;
					break;
				case 72:
					((SimpleButton)target).Click += this.DeleteRoi_Click;
					break;
				default:
					switch (connectionId)
					{
					case 86:
						((Button)target).Click += this.MaskRoiItem_Click;
						break;
					case 87:
						((SimpleButton)target).Click += this.EditRoi_Click;
						break;
					case 88:
						((SimpleButton)target).Click += this.DeleteRoi_Click;
						break;
					}
					break;
				}
			}
		}

		// Token: 0x040009D7 RID: 2519
		private SettingDisplayController _displayController;

		// Token: 0x040009D8 RID: 2520
		private SettingToolSelectionService _toolSelectionService;

		// Token: 0x040009D9 RID: 2521
		private SettingTurnSnapService _turnSnapService;

		// Token: 0x040009DA RID: 2522
		private SettingRoiService _roiService;

		// Token: 0x040009DB RID: 2523
		private readonly HashSet<RoiPanelType> _showAllRoiPanels = new HashSet<RoiPanelType>();

		// Token: 0x040009DC RID: 2524
		private RoiData _clonePreviewSource;

		// Token: 0x040009DD RID: 2525
		private List<RoiData> _clonePreviewClones;

		// Token: 0x040009DE RID: 2526
		private SettingMasterImageService _masterImageService;

		// Token: 0x040009DF RID: 2527
		private SettingRecipeService _recipeService;

		// Token: 0x040009E0 RID: 2528
		private ToolActionDispatcher _toolActionDispatcher;

		// Token: 0x040009E1 RID: 2529
		private ToolActionContext _toolActionContext;

		// Token: 0x040009E3 RID: 2531
		private readonly SettingShapeModelMatchingService _shapeModelMatchingService;

		// Token: 0x040009E5 RID: 2533
		private string _pixelInspectorText = "Row: -  Col: -  Gray: -  R: -  G: -  B: -";

		// Token: 0x040009E6 RID: 2534
		private DateTime _lastPixelInspectorUpdateUtc = DateTime.MinValue;

		// Token: 0x040009F4 RID: 2548
		private bool _isBlobOutputVisible = true;

		// Token: 0x040009F5 RID: 2549
		private bool _isShapeModelOutputVisible;

		// Token: 0x040009F6 RID: 2550
		private bool _isFindLineOutputVisible;

		// Token: 0x040009F7 RID: 2551
		private bool _isFindCircleOutputVisible;

		// Token: 0x040009F8 RID: 2552
		private bool _isFindBoundingBoxOutputVisible;

		// Token: 0x040009F9 RID: 2553
		private bool _isRunAllOutputVisible;

		// Token: 0x040009FA RID: 2554
		private bool _isDistanceObjectOutputVisible;

		// Token: 0x040009FB RID: 2555
		private bool _isMeasureCircleOutputVisible;

		// Token: 0x040009FC RID: 2556
		private bool _isDeformableInspectionOutputVisible;

		// Token: 0x040009FD RID: 2557
		private bool _isDLObjectInspectionOutputVisible;

		// Token: 0x040009FE RID: 2558
		private bool _isCalibHandEyeOutputVisible;

		// Token: 0x040009FF RID: 2559
		private bool _isResultAlignOutputVisible;

		// Token: 0x04000A00 RID: 2560
		private bool _isResultInspectionOutputVisible;

		// Token: 0x04000A02 RID: 2562
		private bool _isDraggingFromTree;

		// Token: 0x04000A03 RID: 2563
		private bool _isInitializingToolSelection;

		// Token: 0x04000A04 RID: 2564
		private bool _isSettingCameraLoading;

		// Token: 0x04000A05 RID: 2565
		private Window _settingCameraWaitWindow;

		// Token: 0x04000A06 RID: 2566
		private bool _isSettingCameraReloading;

		// Token: 0x04000A07 RID: 2567
		private bool _leftPressEditsRoi;

		// Token: 0x04000A08 RID: 2568
		private const int ImagePageSize = 100;

		// Token: 0x04000A09 RID: 2569
		private readonly List<Form_setting.ImageListItem> _allImageItems = new List<Form_setting.ImageListItem>();

		// Token: 0x04000A0A RID: 2570
		private readonly ObservableCollection<Form_setting.ImageListItem> _imageListItems = new ObservableCollection<Form_setting.ImageListItem>();

		// Token: 0x04000A0B RID: 2571
		private readonly ObservableCollection<Form_setting.ImagePageItem> _imagePages = new ObservableCollection<Form_setting.ImagePageItem>();

		// Token: 0x04000A0C RID: 2572
		private int _currentImagePage;

		// Token: 0x04000A0D RID: 2573
		private bool _isUpdatingImageList;

		// Token: 0x04000A0E RID: 2574
		private string _imageListFolder;

		// Token: 0x04000A0F RID: 2575
		private bool _imageListRestored;

		// Token: 0x04000A10 RID: 2576
		private static readonly string[] ImageListExtensions = new string[]
		{
			".png",
			".bmp",
			".jpg",
			".jpeg",
			".tif",
			".tiff",
			".gif"
		};

		// Token: 0x04000A11 RID: 2577
		private Form_setting.ImageListItem _contextImageItem;

		// Token: 0x04000A12 RID: 2578
		private string _dlLoadModelMessage;

		// Token: 0x04000A13 RID: 2579
		private bool _dlLoadModelOk;

		// Token: 0x02000394 RID: 916
		public class ImageListItem
		{
			// Token: 0x17000B60 RID: 2912
			// (get) Token: 0x06002942 RID: 10562 RVA: 0x000E2A83 File Offset: 0x000E0C83
			// (set) Token: 0x06002943 RID: 10563 RVA: 0x000E2A8B File Offset: 0x000E0C8B
			public int Index { get; set; }

			// Token: 0x17000B61 RID: 2913
			// (get) Token: 0x06002944 RID: 10564 RVA: 0x000E2A94 File Offset: 0x000E0C94
			// (set) Token: 0x06002945 RID: 10565 RVA: 0x000E2A9C File Offset: 0x000E0C9C
			public string FileName { get; set; }

			// Token: 0x17000B62 RID: 2914
			// (get) Token: 0x06002946 RID: 10566 RVA: 0x000E2AA5 File Offset: 0x000E0CA5
			// (set) Token: 0x06002947 RID: 10567 RVA: 0x000E2AAD File Offset: 0x000E0CAD
			public string FullPath { get; set; }
		}

		// Token: 0x02000395 RID: 917
		public class ImagePageItem
		{
			// Token: 0x17000B63 RID: 2915
			// (get) Token: 0x06002949 RID: 10569 RVA: 0x000E2AB6 File Offset: 0x000E0CB6
			// (set) Token: 0x0600294A RID: 10570 RVA: 0x000E2ABE File Offset: 0x000E0CBE
			public int PageIndex { get; set; }

			// Token: 0x17000B64 RID: 2916
			// (get) Token: 0x0600294B RID: 10571 RVA: 0x000E2AC7 File Offset: 0x000E0CC7
			// (set) Token: 0x0600294C RID: 10572 RVA: 0x000E2ACF File Offset: 0x000E0CCF
			public int FirstIndex { get; set; }

			// Token: 0x17000B65 RID: 2917
			// (get) Token: 0x0600294D RID: 10573 RVA: 0x000E2AD8 File Offset: 0x000E0CD8
			// (set) Token: 0x0600294E RID: 10574 RVA: 0x000E2AE0 File Offset: 0x000E0CE0
			public int LastIndex { get; set; }

			// Token: 0x17000B66 RID: 2918
			// (get) Token: 0x0600294F RID: 10575 RVA: 0x000E2AEC File Offset: 0x000E0CEC
			public string Header
			{
				get
				{
					return this.FirstIndex.ToString() + " - " + this.LastIndex.ToString();
				}
			}
		}

		// Token: 0x02000396 RID: 918
		private enum ProductCountTrainingMode
		{
			// Token: 0x040012D0 RID: 4816
			Train,
			// Token: 0x040012D1 RID: 4817
			Predict,
			// Token: 0x040012D2 RID: 4818
			Pretrain
		}
	}
}
