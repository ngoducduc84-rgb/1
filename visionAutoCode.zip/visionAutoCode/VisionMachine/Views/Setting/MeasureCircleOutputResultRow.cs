﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A4 RID: 420
	public class MeasureCircleOutputResultRow
	{
		// Token: 0x17000801 RID: 2049
		// (get) Token: 0x06001677 RID: 5751 RVA: 0x00068893 File Offset: 0x00066A93
		// (set) Token: 0x06001678 RID: 5752 RVA: 0x0006889B File Offset: 0x00066A9B
		public string RoiName { get; set; }

		// Token: 0x17000802 RID: 2050
		// (get) Token: 0x06001679 RID: 5753 RVA: 0x000688A4 File Offset: 0x00066AA4
		// (set) Token: 0x0600167A RID: 5754 RVA: 0x000688AC File Offset: 0x00066AAC
		public string MeasureMode { get; set; }

		// Token: 0x17000803 RID: 2051
		// (get) Token: 0x0600167B RID: 5755 RVA: 0x000688B5 File Offset: 0x00066AB5
		// (set) Token: 0x0600167C RID: 5756 RVA: 0x000688BD File Offset: 0x00066ABD
		public double Row { get; set; }

		// Token: 0x17000804 RID: 2052
		// (get) Token: 0x0600167D RID: 5757 RVA: 0x000688C6 File Offset: 0x00066AC6
		// (set) Token: 0x0600167E RID: 5758 RVA: 0x000688CE File Offset: 0x00066ACE
		public double Column { get; set; }

		// Token: 0x17000805 RID: 2053
		// (get) Token: 0x0600167F RID: 5759 RVA: 0x000688D7 File Offset: 0x00066AD7
		// (set) Token: 0x06001680 RID: 5760 RVA: 0x000688DF File Offset: 0x00066ADF
		public double Radius { get; set; }

		// Token: 0x17000806 RID: 2054
		// (get) Token: 0x06001681 RID: 5761 RVA: 0x000688E8 File Offset: 0x00066AE8
		// (set) Token: 0x06001682 RID: 5762 RVA: 0x000688F0 File Offset: 0x00066AF0
		public double Diameter { get; set; }

		// Token: 0x17000807 RID: 2055
		// (get) Token: 0x06001683 RID: 5763 RVA: 0x000688F9 File Offset: 0x00066AF9
		// (set) Token: 0x06001684 RID: 5764 RVA: 0x00068901 File Offset: 0x00066B01
		public double PixelValue { get; set; }

		// Token: 0x17000808 RID: 2056
		// (get) Token: 0x06001685 RID: 5765 RVA: 0x0006890A File Offset: 0x00066B0A
		// (set) Token: 0x06001686 RID: 5766 RVA: 0x00068912 File Offset: 0x00066B12
		public double ValueMm { get; set; }

		// Token: 0x17000809 RID: 2057
		// (get) Token: 0x06001687 RID: 5767 RVA: 0x0006891B File Offset: 0x00066B1B
		// (set) Token: 0x06001688 RID: 5768 RVA: 0x00068923 File Offset: 0x00066B23
		public string SpecStatus { get; set; }

		// Token: 0x1700080A RID: 2058
		// (get) Token: 0x06001689 RID: 5769 RVA: 0x0006892C File Offset: 0x00066B2C
		public Brush SpecStatusBrush
		{
			get
			{
				bool flag = string.Equals(this.SpecStatus, "OK", StringComparison.OrdinalIgnoreCase);
				Brush result;
				if (flag)
				{
					result = Brushes.LimeGreen;
				}
				else
				{
					bool flag2 = string.Equals(this.SpecStatus, "NG", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						result = Brushes.Red;
					}
					else
					{
						bool flag3 = string.Equals(this.SpecStatus, "No Calib", StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							result = Brushes.Goldenrod;
						}
						else
						{
							result = Brushes.White;
						}
					}
				}
				return result;
			}
		}

		// Token: 0x1700080B RID: 2059
		// (get) Token: 0x0600168A RID: 5770 RVA: 0x0006899A File Offset: 0x00066B9A
		// (set) Token: 0x0600168B RID: 5771 RVA: 0x000689A2 File Offset: 0x00066BA2
		public string InputSourceToolName { get; set; }

		// Token: 0x1700080C RID: 2060
		// (get) Token: 0x0600168C RID: 5772 RVA: 0x000689AB File Offset: 0x00066BAB
		// (set) Token: 0x0600168D RID: 5773 RVA: 0x000689B3 File Offset: 0x00066BB3
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x1700080D RID: 2061
		// (get) Token: 0x0600168E RID: 5774 RVA: 0x000689BC File Offset: 0x00066BBC
		// (set) Token: 0x0600168F RID: 5775 RVA: 0x000689C4 File Offset: 0x00066BC4
		public double ProcessingTimeMs { get; set; }

		// Token: 0x1700080E RID: 2062
		// (get) Token: 0x06001690 RID: 5776 RVA: 0x000689CD File Offset: 0x00066BCD
		// (set) Token: 0x06001691 RID: 5777 RVA: 0x000689D5 File Offset: 0x00066BD5
		public double TotalProcessingTimeMs { get; set; }
	}
}
