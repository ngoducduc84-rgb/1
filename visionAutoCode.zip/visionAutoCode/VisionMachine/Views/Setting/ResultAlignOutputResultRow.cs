﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A8 RID: 424
	public class ResultAlignOutputResultRow
	{
		// Token: 0x1700084F RID: 2127
		// (get) Token: 0x06001713 RID: 5907 RVA: 0x00068F01 File Offset: 0x00067101
		// (set) Token: 0x06001714 RID: 5908 RVA: 0x00068F09 File Offset: 0x00067109
		public string AlignToolName { get; set; }

		// Token: 0x17000850 RID: 2128
		// (get) Token: 0x06001715 RID: 5909 RVA: 0x00068F12 File Offset: 0x00067112
		// (set) Token: 0x06001716 RID: 5910 RVA: 0x00068F1A File Offset: 0x0006711A
		public string SourceToolName { get; set; }

		// Token: 0x17000851 RID: 2129
		// (get) Token: 0x06001717 RID: 5911 RVA: 0x00068F23 File Offset: 0x00067123
		// (set) Token: 0x06001718 RID: 5912 RVA: 0x00068F2B File Offset: 0x0006712B
		public int OutputOrder { get; set; }

		// Token: 0x17000852 RID: 2130
		// (get) Token: 0x06001719 RID: 5913 RVA: 0x00068F34 File Offset: 0x00067134
		// (set) Token: 0x0600171A RID: 5914 RVA: 0x00068F3C File Offset: 0x0006713C
		public int GridRow { get; set; }

		// Token: 0x17000853 RID: 2131
		// (get) Token: 0x0600171B RID: 5915 RVA: 0x00068F45 File Offset: 0x00067145
		// (set) Token: 0x0600171C RID: 5916 RVA: 0x00068F4D File Offset: 0x0006714D
		public int GridColumn { get; set; }

		// Token: 0x17000854 RID: 2132
		// (get) Token: 0x0600171D RID: 5917 RVA: 0x00068F56 File Offset: 0x00067156
		// (set) Token: 0x0600171E RID: 5918 RVA: 0x00068F5E File Offset: 0x0006715E
		public double PixelRow { get; set; }

		// Token: 0x17000855 RID: 2133
		// (get) Token: 0x0600171F RID: 5919 RVA: 0x00068F67 File Offset: 0x00067167
		// (set) Token: 0x06001720 RID: 5920 RVA: 0x00068F6F File Offset: 0x0006716F
		public double PixelColumn { get; set; }

		// Token: 0x17000856 RID: 2134
		// (get) Token: 0x06001721 RID: 5921 RVA: 0x00068F78 File Offset: 0x00067178
		// (set) Token: 0x06001722 RID: 5922 RVA: 0x00068F80 File Offset: 0x00067180
		public double RobotX { get; set; }

		// Token: 0x17000857 RID: 2135
		// (get) Token: 0x06001723 RID: 5923 RVA: 0x00068F89 File Offset: 0x00067189
		// (set) Token: 0x06001724 RID: 5924 RVA: 0x00068F91 File Offset: 0x00067191
		public double RobotY { get; set; }

		// Token: 0x17000858 RID: 2136
		// (get) Token: 0x06001725 RID: 5925 RVA: 0x00068F9A File Offset: 0x0006719A
		// (set) Token: 0x06001726 RID: 5926 RVA: 0x00068FA2 File Offset: 0x000671A2
		public double AngleDeg { get; set; }

		// Token: 0x17000859 RID: 2137
		// (get) Token: 0x06001727 RID: 5927 RVA: 0x00068FAB File Offset: 0x000671AB
		// (set) Token: 0x06001728 RID: 5928 RVA: 0x00068FB3 File Offset: 0x000671B3
		public double DeltaRobotX { get; set; }

		// Token: 0x1700085A RID: 2138
		// (get) Token: 0x06001729 RID: 5929 RVA: 0x00068FBC File Offset: 0x000671BC
		// (set) Token: 0x0600172A RID: 5930 RVA: 0x00068FC4 File Offset: 0x000671C4
		public double DeltaRobotY { get; set; }

		// Token: 0x1700085B RID: 2139
		// (get) Token: 0x0600172B RID: 5931 RVA: 0x00068FCD File Offset: 0x000671CD
		// (set) Token: 0x0600172C RID: 5932 RVA: 0x00068FD5 File Offset: 0x000671D5
		public double DeltaAngleDeg { get; set; }

		// Token: 0x1700085C RID: 2140
		// (get) Token: 0x0600172D RID: 5933 RVA: 0x00068FDE File Offset: 0x000671DE
		// (set) Token: 0x0600172E RID: 5934 RVA: 0x00068FE6 File Offset: 0x000671E6
		public double Score { get; set; }

		// Token: 0x1700085D RID: 2141
		// (get) Token: 0x0600172F RID: 5935 RVA: 0x00068FEF File Offset: 0x000671EF
		// (set) Token: 0x06001730 RID: 5936 RVA: 0x00068FF7 File Offset: 0x000671F7
		public string Status { get; set; }

		// Token: 0x1700085E RID: 2142
		// (get) Token: 0x06001731 RID: 5937 RVA: 0x00069000 File Offset: 0x00067200
		public Brush StatusBrush
		{
			get
			{
				return string.Equals(this.Status, "OK", StringComparison.OrdinalIgnoreCase) ? Brushes.LimeGreen : Brushes.Red;
			}
		}

		// Token: 0x1700085F RID: 2143
		// (get) Token: 0x06001732 RID: 5938 RVA: 0x00069031 File Offset: 0x00067231
		// (set) Token: 0x06001733 RID: 5939 RVA: 0x00069039 File Offset: 0x00067239
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000860 RID: 2144
		// (get) Token: 0x06001734 RID: 5940 RVA: 0x00069042 File Offset: 0x00067242
		// (set) Token: 0x06001735 RID: 5941 RVA: 0x0006904A File Offset: 0x0006724A
		public double TotalProcessingTimeMs { get; set; }
	}
}
