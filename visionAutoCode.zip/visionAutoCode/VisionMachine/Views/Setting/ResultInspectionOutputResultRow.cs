﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A9 RID: 425
	public class ResultInspectionOutputResultRow
	{
		// Token: 0x17000861 RID: 2145
		// (get) Token: 0x06001737 RID: 5943 RVA: 0x00069053 File Offset: 0x00067253
		// (set) Token: 0x06001738 RID: 5944 RVA: 0x0006905B File Offset: 0x0006725B
		public string ToolName { get; set; }

		// Token: 0x17000862 RID: 2146
		// (get) Token: 0x06001739 RID: 5945 RVA: 0x00069064 File Offset: 0x00067264
		// (set) Token: 0x0600173A RID: 5946 RVA: 0x0006906C File Offset: 0x0006726C
		public string SourceToolName { get; set; }

		// Token: 0x17000863 RID: 2147
		// (get) Token: 0x0600173B RID: 5947 RVA: 0x00069075 File Offset: 0x00067275
		// (set) Token: 0x0600173C RID: 5948 RVA: 0x0006907D File Offset: 0x0006727D
		public string Value { get; set; }

		// Token: 0x17000864 RID: 2148
		// (get) Token: 0x0600173D RID: 5949 RVA: 0x00069086 File Offset: 0x00067286
		// (set) Token: 0x0600173E RID: 5950 RVA: 0x0006908E File Offset: 0x0006728E
		public string Spec { get; set; }

		// Token: 0x17000865 RID: 2149
		// (get) Token: 0x0600173F RID: 5951 RVA: 0x00069097 File Offset: 0x00067297
		// (set) Token: 0x06001740 RID: 5952 RVA: 0x0006909F File Offset: 0x0006729F
		public string Status { get; set; }

		// Token: 0x17000866 RID: 2150
		// (get) Token: 0x06001741 RID: 5953 RVA: 0x000690A8 File Offset: 0x000672A8
		// (set) Token: 0x06001742 RID: 5954 RVA: 0x000690B0 File Offset: 0x000672B0
		public string Detail { get; set; }

		// Token: 0x17000867 RID: 2151
		// (get) Token: 0x06001743 RID: 5955 RVA: 0x000690BC File Offset: 0x000672BC
		public Brush StatusBrush
		{
			get
			{
				bool flag = string.Equals(this.Status, "OK", StringComparison.OrdinalIgnoreCase);
				Brush result;
				if (flag)
				{
					result = Brushes.LimeGreen;
				}
				else
				{
					bool flag2 = string.Equals(this.Status, "NG", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						result = Brushes.Red;
					}
					else
					{
						result = Brushes.Goldenrod;
					}
				}
				return result;
			}
		}

		// Token: 0x17000868 RID: 2152
		// (get) Token: 0x06001744 RID: 5956 RVA: 0x0006910D File Offset: 0x0006730D
		// (set) Token: 0x06001745 RID: 5957 RVA: 0x00069115 File Offset: 0x00067315
		public double TotalProcessingTimeMs { get; set; }
	}
}
