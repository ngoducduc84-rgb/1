﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001A2 RID: 418
	public class RunAllOutputResultRow : INotifyPropertyChanged
	{
		// Token: 0x14000028 RID: 40
		// (add) Token: 0x06001645 RID: 5701 RVA: 0x00068580 File Offset: 0x00066780
		// (remove) Token: 0x06001646 RID: 5702 RVA: 0x000685B8 File Offset: 0x000667B8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x170007E9 RID: 2025
		// (get) Token: 0x06001647 RID: 5703 RVA: 0x000685ED File Offset: 0x000667ED
		// (set) Token: 0x06001648 RID: 5704 RVA: 0x000685F5 File Offset: 0x000667F5
		public string ToolName { get; set; }

		// Token: 0x170007EA RID: 2026
		// (get) Token: 0x06001649 RID: 5705 RVA: 0x000685FE File Offset: 0x000667FE
		// (set) Token: 0x0600164A RID: 5706 RVA: 0x00068606 File Offset: 0x00066806
		public string Result { get; set; }

		// Token: 0x170007EB RID: 2027
		// (get) Token: 0x0600164B RID: 5707 RVA: 0x0006860F File Offset: 0x0006680F
		// (set) Token: 0x0600164C RID: 5708 RVA: 0x00068617 File Offset: 0x00066817
		public string Status { get; set; }

		// Token: 0x170007EC RID: 2028
		// (get) Token: 0x0600164D RID: 5709 RVA: 0x00068620 File Offset: 0x00066820
		public Brush StatusBrush
		{
			get
			{
				bool flag = string.Equals(this.Status, "OK", StringComparison.OrdinalIgnoreCase);
				Brush result;
				if (flag)
				{
					result = Brushes.LimeGreen;
				}
				else
				{
					bool flag2 = string.Equals(this.Status, "NG", StringComparison.OrdinalIgnoreCase);
					if (flag2)
					{
						result = Brushes.Red;
					}
					else
					{
						bool flag3 = string.Equals(this.Status, "Lost", StringComparison.OrdinalIgnoreCase) || string.Equals(this.Status, "No Calib", StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							result = Brushes.Goldenrod;
						}
						else
						{
							result = Brushes.Transparent;
						}
					}
				}
				return result;
			}
		}

		// Token: 0x170007ED RID: 2029
		// (get) Token: 0x0600164E RID: 5710 RVA: 0x000686A4 File Offset: 0x000668A4
		// (set) Token: 0x0600164F RID: 5711 RVA: 0x000686AC File Offset: 0x000668AC
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170007EE RID: 2030
		// (get) Token: 0x06001650 RID: 5712 RVA: 0x000686B5 File Offset: 0x000668B5
		// (set) Token: 0x06001651 RID: 5713 RVA: 0x000686C0 File Offset: 0x000668C0
		public double TurnSnapProcessingTimeMs
		{
			get
			{
				return this._turnSnapProcessingTimeMs;
			}
			set
			{
				bool flag = this._turnSnapProcessingTimeMs == value;
				if (!flag)
				{
					this._turnSnapProcessingTimeMs = value;
					PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
					if (propertyChanged != null)
					{
						propertyChanged(this, new PropertyChangedEventArgs("TurnSnapProcessingTimeMs"));
					}
				}
			}
		}

		// Token: 0x170007EF RID: 2031
		// (get) Token: 0x06001652 RID: 5714 RVA: 0x00068701 File Offset: 0x00066901
		// (set) Token: 0x06001653 RID: 5715 RVA: 0x00068709 File Offset: 0x00066909
		public string InputSourceToolName { get; set; }

		// Token: 0x170007F0 RID: 2032
		// (get) Token: 0x06001654 RID: 5716 RVA: 0x00068712 File Offset: 0x00066912
		// (set) Token: 0x06001655 RID: 5717 RVA: 0x0006871A File Offset: 0x0006691A
		public string MasterPositionToolName { get; set; }

		// Token: 0x170007F1 RID: 2033
		// (get) Token: 0x06001656 RID: 5718 RVA: 0x00068723 File Offset: 0x00066923
		// (set) Token: 0x06001657 RID: 5719 RVA: 0x0006872B File Offset: 0x0006692B
		public string MasterAngleToolName { get; set; }

		// Token: 0x0400095B RID: 2395
		private double _turnSnapProcessingTimeMs;
	}
}
