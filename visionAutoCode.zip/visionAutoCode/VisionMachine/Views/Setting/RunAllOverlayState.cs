﻿using System;
using System.Collections.Generic;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001AB RID: 427
	internal class RunAllOverlayState : IDisposable
	{
		// Token: 0x1700086B RID: 2155
		// (get) Token: 0x0600174C RID: 5964 RVA: 0x00069140 File Offset: 0x00067340
		public List<RunAllToolOverlayResult> Results { get; } = new List<RunAllToolOverlayResult>();

		// Token: 0x0600174D RID: 5965 RVA: 0x00069148 File Offset: 0x00067348
		public void Dispose()
		{
			foreach (RunAllToolOverlayResult item in this.Results)
			{
				IDisposable disposable = ((item != null) ? item.Result : null) as IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			this.Results.Clear();
		}
	}
}
