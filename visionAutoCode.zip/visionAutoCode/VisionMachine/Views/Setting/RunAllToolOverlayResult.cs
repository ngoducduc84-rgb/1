﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.Views.Setting
{
	// Token: 0x020001AA RID: 426
	internal class RunAllToolOverlayResult
	{
		// Token: 0x17000869 RID: 2153
		// (get) Token: 0x06001747 RID: 5959 RVA: 0x0006911E File Offset: 0x0006731E
		// (set) Token: 0x06001748 RID: 5960 RVA: 0x00069126 File Offset: 0x00067326
		public ToolVision Tool { get; set; }

		// Token: 0x1700086A RID: 2154
		// (get) Token: 0x06001749 RID: 5961 RVA: 0x0006912F File Offset: 0x0006732F
		// (set) Token: 0x0600174A RID: 5962 RVA: 0x00069137 File Offset: 0x00067337
		public object Result { get; set; }
	}
}
