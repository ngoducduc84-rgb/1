﻿using System;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001AF RID: 431
	public enum RoiPanelType
	{
		// Token: 0x04000A3D RID: 2621
		Normal,
		// Token: 0x04000A3E RID: 2622
		Limit,
		// Token: 0x04000A3F RID: 2623
		Mask
	}
}
