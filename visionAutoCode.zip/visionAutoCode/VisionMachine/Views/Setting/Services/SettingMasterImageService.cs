﻿using System;
using System.IO;
using DevExpress.Xpf.Core;
using VisionMachine.Helpers;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Runtime;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Main;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001AD RID: 429
	public class SettingMasterImageService
	{
		// Token: 0x0600189F RID: 6303 RVA: 0x0007AF74 File Offset: 0x00079174
		public string GetMasterImagePath(TurnSnap turnSnap)
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag = ModelRuntimeStore.CurrentModel == null;
			string result;
			if (flag)
			{
				DXMessageBox.Show("No current model is selected.");
				result = null;
			}
			else
			{
				bool flag2 = turnSnap == null;
				if (flag2)
				{
					DXMessageBox.Show("No TurnSnap is selected.");
					result = null;
				}
				else
				{
					CameraNode camera = turnSnap.ParentCamera ?? ((vm != null) ? vm.SelectedCamera : null);
					bool flag3 = camera == null;
					if (flag3)
					{
						DXMessageBox.Show("No camera is selected.");
						result = null;
					}
					else
					{
						string rootPath = Manager_path._dataPath;
						string modelName = this.MakeSafeFileName(ModelRuntimeStore.CurrentModel.Model_name);
						string cameraName = this.MakeSafeFileName(camera.Name);
						string turnSnapName = string.Format("TurnSnap_{0}", turnSnap.Index);
						string folder = Path.Combine(rootPath, modelName, cameraName, turnSnapName);
						Directory.CreateDirectory(folder);
						result = Path.Combine(folder, "master.bmp");
					}
				}
			}
			return result;
		}

		// Token: 0x060018A0 RID: 6304 RVA: 0x0007B064 File Offset: 0x00079264
		public string GetTurnSnapFolder(TurnSnap turnSnap)
		{
			string masterPath = this.GetMasterImagePath(turnSnap);
			bool flag = string.IsNullOrWhiteSpace(masterPath);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = Path.GetDirectoryName(masterPath);
			}
			return result;
		}

		// Token: 0x060018A1 RID: 6305 RVA: 0x0007B094 File Offset: 0x00079294
		public string BuildTurnSnapFolderPath(TurnSnap turnSnap)
		{
			bool flag = ModelRuntimeStore.CurrentModel == null || turnSnap == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				MainWindow instance = MainWindow.instance;
				MainViewModel vm = (instance != null) ? instance.MainViewModel : null;
				CameraNode camera = turnSnap.ParentCamera ?? ((vm != null) ? vm.SelectedCamera : null);
				bool flag2 = camera == null;
				if (flag2)
				{
					result = null;
				}
				else
				{
					string rootPath = Manager_path._dataPath;
					string modelName = this.MakeSafeFileName(ModelRuntimeStore.CurrentModel.Model_name);
					string cameraName = this.MakeSafeFileName(camera.Name);
					string turnSnapName = string.Format("TurnSnap_{0}", turnSnap.Index);
					result = Path.Combine(rootPath, modelName, cameraName, turnSnapName);
				}
			}
			return result;
		}

		// Token: 0x060018A2 RID: 6306 RVA: 0x0007B144 File Offset: 0x00079344
		private string MakeSafeFileName(string name)
		{
			bool flag = string.IsNullOrWhiteSpace(name);
			string result;
			if (flag)
			{
				result = "Unknown";
			}
			else
			{
				foreach (char c in Path.GetInvalidFileNameChars())
				{
					name = name.Replace(c, '_');
				}
				result = name.Trim();
			}
			return result;
		}
	}
}
