﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using DevExpress.Xpf.Core;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Recipe;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Recipe;
using VisionMachine.Services.Runtime;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Main;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001AE RID: 430
	public class SettingRecipeService
	{
		// Token: 0x060018A4 RID: 6308 RVA: 0x0007B194 File Offset: 0x00079394
		public RecipeConfig BuildRecipeFromCurrentViewModel()
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			RecipeConfig recipeConfig = new RecipeConfig();
			ModelConfig currentModel = ModelRuntimeStore.CurrentModel;
			recipeConfig.ModelName = ((currentModel != null) ? currentModel.Model_name : null);
			RecipeConfig recipe = recipeConfig;
			foreach (CameraNode camera in vm.Cameras)
			{
				CameraRecipeConfig cameraRecipeConfig = new CameraRecipeConfig();
				cameraRecipeConfig.CameraIndex = camera.Index;
				CameraItem cameraInfo = camera.CameraInfo;
				cameraRecipeConfig.CameraName = ((cameraInfo != null) ? cameraInfo.CameraName : null);
				CameraRecipeConfig cameraRecipe = cameraRecipeConfig;
				foreach (TurnSnap turnSnap in camera.TurnSnaps)
				{
					TurnSnapRecipeConfig turnSnapRecipe = new TurnSnapRecipeConfig
					{
						Index = turnSnap.Index
					};
					foreach (ToolVision tool in turnSnap.Tools)
					{
						turnSnapRecipe.Tools.Add(new ToolRecipeConfig
						{
							ToolId = tool.ToolId,
							Index = tool.Index,
							Name = tool.Name,
							ToolType = tool.ToolType.ToString(),
							Config = tool.Config,
							Spec = tool.Spec,
							TrainModel = tool.TrainModel,
							RoiItems = tool.RoiItems.ToList<RoiData>(),
							LimitRoiItems = tool.LimitRoiItems.ToList<RoiData>(),
							MaskRoiItems = tool.MaskRoiItems.ToList<RoiData>()
						});
					}
					cameraRecipe.TurnSnaps.Add(turnSnapRecipe);
				}
				recipe.Cameras.Add(cameraRecipe);
			}
			return recipe;
		}

		// Token: 0x060018A5 RID: 6309 RVA: 0x0007B3E0 File Offset: 0x000795E0
		public void SaveCurrentModelRecipe()
		{
			this.SaveCurrentModelRecipe(true);
		}

		// Token: 0x060018A6 RID: 6310 RVA: 0x0007B3EC File Offset: 0x000795EC
		public void SaveCurrentModelRecipe(bool showMessage)
		{
			bool flag = ModelRuntimeStore.CurrentModel == null;
			if (flag)
			{
				if (showMessage)
				{
					DXMessageBox.Show("No current model is selected.");
				}
			}
			else
			{
				RecipeConfig recipe = this.BuildRecipeFromCurrentViewModel();
				string path = RecipePathService.GetCurrentModelRecipeJsonPath();
				bool flag2 = string.IsNullOrWhiteSpace(path);
				if (flag2)
				{
					if (showMessage)
					{
						DXMessageBox.Show("Could not create the recipe save path.");
					}
				}
				else
				{
					RecipeStorageService.Save(path, recipe);
					if (showMessage)
					{
						DXMessageBox.Show("Configuration saved:\n" + path);
					}
				}
			}
		}

		// Token: 0x060018A7 RID: 6311 RVA: 0x0007B468 File Offset: 0x00079668
		public void LoadCurrentModelRecipe()
		{
			bool flag = ModelRuntimeStore.CurrentModel == null;
			if (!flag)
			{
				string path = RecipePathService.GetCurrentModelRecipeJsonPath();
				bool flag2 = string.IsNullOrWhiteSpace(path);
				if (!flag2)
				{
					this.ApplyRecipeToViewModel(RecipeStorageService.Load(path) ?? new RecipeConfig());
				}
			}
		}

		// Token: 0x1400002A RID: 42
		// (add) Token: 0x060018A8 RID: 6312 RVA: 0x0007B4AC File Offset: 0x000796AC
		// (remove) Token: 0x060018A9 RID: 6313 RVA: 0x0007B4E0 File Offset: 0x000796E0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event EventHandler RecipeApplied;

		// Token: 0x060018AA RID: 6314 RVA: 0x0007B514 File Offset: 0x00079714
		public void ApplyRecipeToViewModel(RecipeConfig recipe)
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag = vm == null || recipe == null;
			if (!flag)
			{
				foreach (CameraNode existing in vm.Cameras)
				{
					existing.TurnSnaps.Clear();
				}
				using (List<CameraRecipeConfig>.Enumerator enumerator2 = recipe.Cameras.GetEnumerator())
				{
					while (enumerator2.MoveNext())
					{
						CameraRecipeConfig cameraRecipe = enumerator2.Current;
						CameraNode camera = vm.Cameras.FirstOrDefault(delegate(CameraNode x)
						{
							CameraItem cameraInfo = x.CameraInfo;
							return ((cameraInfo != null) ? cameraInfo.CameraName : null) == cameraRecipe.CameraName;
						});
						bool flag2 = camera == null;
						if (!flag2)
						{
							foreach (TurnSnapRecipeConfig tsRecipe in cameraRecipe.TurnSnaps)
							{
								TurnSnap turnSnap = new TurnSnap
								{
									Index = tsRecipe.Index,
									ParentCamera = camera
								};
								foreach (ToolRecipeConfig toolRecipe in tsRecipe.Tools)
								{
									ToolVision tool = new ToolVision
									{
										ToolId = (string.IsNullOrWhiteSpace(toolRecipe.ToolId) ? Guid.NewGuid().ToString("N") : toolRecipe.ToolId),
										Index = toolRecipe.Index,
										Name = toolRecipe.Name,
										ParentTurnSnap = turnSnap
									};
									ToolType toolType;
									bool flag3 = Enum.TryParse<ToolType>(toolRecipe.ToolType, out toolType);
									if (flag3)
									{
										tool.ToolType = toolType;
									}
									tool.Config = (toolRecipe.Config as ToolConfigBase);
									tool.Spec = (toolRecipe.Spec as ToolSpecBase);
									tool.TrainModel = (toolRecipe.TrainModel as ToolTrainBase);
									this.LoadRoiList(toolRecipe.RoiItems, tool.RoiItems);
									this.LoadRoiList(toolRecipe.LimitRoiItems, tool.LimitRoiItems);
									this.LoadRoiList(toolRecipe.MaskRoiItems, tool.MaskRoiItems);
									tool.SelectedRoi = null;
									turnSnap.Tools.Add(tool);
								}
								camera.TurnSnaps.Add(turnSnap);
							}
						}
					}
				}
				EventHandler recipeApplied = SettingRecipeService.RecipeApplied;
				if (recipeApplied != null)
				{
					recipeApplied(this, EventArgs.Empty);
				}
			}
		}

		// Token: 0x060018AB RID: 6315 RVA: 0x0007B81C File Offset: 0x00079A1C
		private void LoadRoiList(IEnumerable<RoiData> source, ObservableCollection<RoiData> target)
		{
			target.Clear();
			bool flag = source == null;
			if (!flag)
			{
				foreach (RoiData roi in source)
				{
					roi.IsSelected = false;
					target.Add(roi);
				}
			}
		}
	}
}
