﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using DevExpress.Xpf.Core;
using HalconDotNet;
using VisionMachine.Controls.Common;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Roi;
using VisionMachine.Views.Roi;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001B0 RID: 432
	public class SettingRoiService
	{
		// Token: 0x1700088B RID: 2187
		// (get) Token: 0x060018AD RID: 6317 RVA: 0x0007B884 File Offset: 0x00079A84
		// (set) Token: 0x060018AE RID: 6318 RVA: 0x0007B88C File Offset: 0x00079A8C
		public RoiPanelType CurrentPanelType { get; set; } = RoiPanelType.Normal;

		// Token: 0x060018AF RID: 6319 RVA: 0x0007B895 File Offset: 0x00079A95
		public SettingRoiService(Func<ToolVision> getSelectedTool, Func<HObject> getCurrentImage = null, Action<RoiData, IList<RoiData>> showRoiPreview = null)
		{
			this._getSelectedTool = getSelectedTool;
			this._getCurrentImage = getCurrentImage;
			this._showRoiPreview = showRoiPreview;
		}

		// Token: 0x060018B0 RID: 6320 RVA: 0x0007B8D1 File Offset: 0x00079AD1
		public void ShowRoi(RoiShape shape, HWindow window)
		{
			this._roiController.ShowRoi(shape, window);
		}

		// Token: 0x060018B1 RID: 6321 RVA: 0x0007B8E2 File Offset: 0x00079AE2
		public void HideActiveRoi(HWindow window)
		{
			this._roiController.Clear(window);
		}

		// Token: 0x060018B2 RID: 6322 RVA: 0x0007B8F4 File Offset: 0x00079AF4
		public bool IsClosedContourAwayFromCorner(double row, double column, double tolerance)
		{
			return this._roiController.IsClosedContourAwayFromCorner(row, column, tolerance);
		}

		// Token: 0x060018B3 RID: 6323 RVA: 0x0007B914 File Offset: 0x00079B14
		public void SuspendRoiInteraction(HWindow window)
		{
			this._roiController.SuspendInteraction(window);
		}

		// Token: 0x060018B4 RID: 6324 RVA: 0x0007B924 File Offset: 0x00079B24
		public void ResumeRoiInteraction(HWindow window)
		{
			this._roiController.ResumeInteraction(window);
		}

		// Token: 0x060018B5 RID: 6325 RVA: 0x0007B934 File Offset: 0x00079B34
		public bool HitTestActiveRoi(double row, double col, double tolerance)
		{
			return this._roiController.HitTest(row, col, tolerance);
		}

		// Token: 0x060018B6 RID: 6326 RVA: 0x0007B954 File Offset: 0x00079B54
		public void AddRoi(RoiPanelType panelType)
		{
			this.CurrentPanelType = panelType;
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null;
			if (flag)
			{
				DXMessageBox.Show("Please select a tool first.");
			}
			else
			{
				ObservableCollection<RoiData> targetList = this.GetRoiList(tool, panelType);
				bool flag2 = targetList == null;
				if (!flag2)
				{
					RoiData roiData = this._roiController.GetRoiData();
					bool flag3 = roiData == null;
					if (flag3)
					{
						DXMessageBox.Show("No ROI is available on the HWindow to add.");
					}
					else
					{
						bool flag4 = panelType == RoiPanelType.Mask && roiData.RoiType == RoiType.Line;
						if (flag4)
						{
							DXMessageBox.Show("Mask ROI does not support Line ROI.");
						}
						else
						{
							bool flag5 = !this.ValidateFindLineRoi(tool, panelType, roiData.RoiType);
							if (!flag5)
							{
								bool flag6 = !this.ValidateFindCircleRoi(tool, panelType, roiData.RoiType);
								if (!flag6)
								{
									bool flag7 = !this.ValidateMeasureCircleRoi(tool, panelType, roiData.RoiType);
									if (!flag7)
									{
										bool flag8 = !this.ValidateFindBoundingBoxRoi(tool, panelType, roiData.RoiType, targetList.Count);
										if (!flag8)
										{
											bool flag9 = tool.ToolType == ToolType.FindLine && panelType == RoiPanelType.Normal && targetList.Count >= 1;
											if (flag9)
											{
												DXMessageBox.Show("Find Line supports only one Line ROI.");
											}
											else
											{
												bool flag10 = (tool.ToolType == ToolType.FindCircle || tool.ToolType == ToolType.CircleMaster) && panelType == RoiPanelType.Normal && targetList.Count >= 1;
												if (flag10)
												{
													DXMessageBox.Show("Find Circle supports only one Circle ROI.");
												}
												else
												{
													bool flag11 = tool.ToolType == ToolType.MeasureCircle && panelType == RoiPanelType.Normal && targetList.Count >= 1;
													if (flag11)
													{
														DXMessageBox.Show("Measure Circle supports only one Circle ROI.");
													}
													else
													{
														this.ClearAllRoiSelection(tool);
														roiData.Name = string.Format("{0} {1}", this.GetPrefixName(panelType), targetList.Count + 1);
														roiData.MaskMode = RoiMaskMode.Inside;
														roiData.Polarity = RoiPolarity.Negative;
														roiData.IsEnabled = true;
														roiData.Description = "";
														roiData.IsSelected = true;
														targetList.Add(roiData);
														tool.SelectedRoi = roiData;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060018B7 RID: 6327 RVA: 0x0007BB76 File Offset: 0x00079D76
		public void SelectRoiItem(RoiData roi, RoiPanelType panelType, HWindow window)
		{
			this.SelectRoiItem(roi, panelType, window, ModifierKeys.None);
		}

		// Token: 0x060018B8 RID: 6328 RVA: 0x0007BB84 File Offset: 0x00079D84
		public void SelectRoiItem(RoiData roi, RoiPanelType panelType, HWindow window, ModifierKeys modifiers)
		{
			bool flag = roi == null;
			if (!flag)
			{
				ToolVision tool = this._getSelectedTool();
				bool flag2 = tool == null;
				if (!flag2)
				{
					this.CurrentPanelType = panelType;
					ObservableCollection<RoiData> list = this.GetRoiList(tool, panelType);
					bool extend = list != null && (modifiers & (ModifierKeys.Control | ModifierKeys.Shift)) > ModifierKeys.None;
					bool flag3 = !extend;
					if (flag3)
					{
						this.ClearAllRoiSelection(tool);
						roi.IsSelected = true;
						tool.SelectedRoi = roi;
						this._selectionAnchor = roi;
						this._roiController.LoadRoi(roi, window);
					}
					else
					{
						SettingRoiService.ClearSelectionOutside(tool, list);
						bool flag4 = (modifiers & ModifierKeys.Shift) != ModifierKeys.None && this._selectionAnchor != null && list.Contains(this._selectionAnchor);
						if (flag4)
						{
							SettingRoiService.SelectRange(list, this._selectionAnchor, roi);
						}
						else
						{
							roi.IsSelected = !roi.IsSelected;
							this._selectionAnchor = roi;
						}
						this._roiController.Clear(window);
						tool.SelectedRoi = (roi.IsSelected ? roi : null);
					}
				}
			}
		}

		// Token: 0x060018B9 RID: 6329 RVA: 0x0007BC8C File Offset: 0x00079E8C
		private static void SelectRange(ObservableCollection<RoiData> list, RoiData from, RoiData to)
		{
			int start = list.IndexOf(from);
			int end = list.IndexOf(to);
			bool flag = start < 0 || end < 0;
			if (!flag)
			{
				bool flag2 = start > end;
				if (flag2)
				{
					int swap = start;
					start = end;
					end = swap;
				}
				for (int i = 0; i < list.Count; i++)
				{
					list[i].IsSelected = (i >= start && i <= end);
				}
			}
		}

		// Token: 0x060018BA RID: 6330 RVA: 0x0007BD08 File Offset: 0x00079F08
		private static void ClearSelectionOutside(ToolVision tool, ObservableCollection<RoiData> keep)
		{
			foreach (ObservableCollection<RoiData> list in new ObservableCollection<RoiData>[]
			{
				tool.RoiItems,
				tool.LimitRoiItems,
				tool.MaskRoiItems
			})
			{
				bool flag = list == null || list == keep;
				if (!flag)
				{
					foreach (RoiData roi in list)
					{
						roi.IsSelected = false;
					}
				}
			}
		}

		// Token: 0x060018BB RID: 6331 RVA: 0x0007BDA4 File Offset: 0x00079FA4
		public List<RoiData> GetSelectionOf(RoiData roi)
		{
			List<RoiData> selected = new List<RoiData>();
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null || roi == null;
			List<RoiData> result;
			if (flag)
			{
				result = selected;
			}
			else
			{
				ObservableCollection<RoiData> list = SettingRoiService.FindRoiList(tool, roi);
				bool flag2 = list == null;
				if (flag2)
				{
					result = selected;
				}
				else
				{
					foreach (RoiData item in list)
					{
						bool isSelected = item.IsSelected;
						if (isSelected)
						{
							selected.Add(item);
						}
					}
					result = selected;
				}
			}
			return result;
		}

		// Token: 0x060018BC RID: 6332 RVA: 0x0007BE4C File Offset: 0x0007A04C
		private static ObservableCollection<RoiData> FindRoiList(ToolVision tool, RoiData roi)
		{
			bool flag = tool.RoiItems != null && tool.RoiItems.Contains(roi);
			ObservableCollection<RoiData> result;
			if (flag)
			{
				result = tool.RoiItems;
			}
			else
			{
				bool flag2 = tool.LimitRoiItems != null && tool.LimitRoiItems.Contains(roi);
				if (flag2)
				{
					result = tool.LimitRoiItems;
				}
				else
				{
					bool flag3 = tool.MaskRoiItems != null && tool.MaskRoiItems.Contains(roi);
					if (flag3)
					{
						result = tool.MaskRoiItems;
					}
					else
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x060018BD RID: 6333 RVA: 0x0007BECC File Offset: 0x0007A0CC
		public int DeleteSelectedRois(RoiPanelType panelType)
		{
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				ObservableCollection<RoiData> list = this.GetRoiList(tool, panelType);
				bool flag2 = list == null;
				if (flag2)
				{
					result = 0;
				}
				else
				{
					RoiData first = null;
					foreach (RoiData roi in list)
					{
						bool isSelected = roi.IsSelected;
						if (isSelected)
						{
							first = roi;
							break;
						}
					}
					bool flag3 = first == null;
					if (flag3)
					{
						result = 0;
					}
					else
					{
						result = this.DeleteRoiOrSelection(first);
					}
				}
			}
			return result;
		}

		// Token: 0x060018BE RID: 6334 RVA: 0x0007BF7C File Offset: 0x0007A17C
		public int DeleteRoiOrSelection(RoiData roi)
		{
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null || roi == null;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				ObservableCollection<RoiData> list = SettingRoiService.FindRoiList(tool, roi);
				bool flag2 = list == null;
				if (flag2)
				{
					result = 0;
				}
				else
				{
					List<RoiData> selection = this.GetSelectionOf(roi);
					bool flag3 = !roi.IsSelected || selection.Count <= 1;
					if (flag3)
					{
						this.DeleteRoi(roi);
						result = 1;
					}
					else
					{
						MessageBoxResult answer = DXMessageBox.Show(string.Concat(new string[]
						{
							"Delete the ",
							selection.Count.ToString(),
							" selected ",
							this.GetPrefixName(SettingRoiService.GetPanelTypeOf(tool, list)),
							" items? This cannot be undone."
						}), "Delete ROI", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
						bool flag4 = answer != MessageBoxResult.Yes;
						if (flag4)
						{
							result = 0;
						}
						else
						{
							foreach (RoiData item in selection)
							{
								list.Remove(item);
							}
							bool flag5 = tool.SelectedRoi != null && selection.Contains(tool.SelectedRoi);
							if (flag5)
							{
								tool.SelectedRoi = null;
							}
							bool flag6 = this._selectionAnchor != null && selection.Contains(this._selectionAnchor);
							if (flag6)
							{
								this._selectionAnchor = null;
							}
							result = selection.Count;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060018BF RID: 6335 RVA: 0x0007C104 File Offset: 0x0007A304
		private static RoiPanelType GetPanelTypeOf(ToolVision tool, ObservableCollection<RoiData> list)
		{
			bool flag = list == tool.LimitRoiItems;
			RoiPanelType result;
			if (flag)
			{
				result = RoiPanelType.Limit;
			}
			else
			{
				bool flag2 = list == tool.MaskRoiItems;
				if (flag2)
				{
					result = RoiPanelType.Mask;
				}
				else
				{
					result = RoiPanelType.Normal;
				}
			}
			return result;
		}

		// Token: 0x060018C0 RID: 6336 RVA: 0x0007C13C File Offset: 0x0007A33C
		public bool SelectRoiAtPoint(IEnumerable<RoiPanelType> panelTypes, double row, double column, HWindow window)
		{
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null || panelTypes == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				Func<HObject> getCurrentImage = this._getCurrentImage;
				HObject image = (getCurrentImage != null) ? getCurrentImage() : null;
				RoiData bestRoi = null;
				RoiPanelType bestPanel = RoiPanelType.Normal;
				double bestArea = double.MaxValue;
				foreach (RoiPanelType panelType in panelTypes)
				{
					ObservableCollection<RoiData> list = this.GetRoiList(tool, panelType);
					bool flag2 = list == null;
					if (!flag2)
					{
						foreach (RoiData roi in list)
						{
							bool flag3 = roi == null || !roi.IsEnabled;
							if (!flag3)
							{
								double area;
								bool flag4 = !this.HitTestRoi(roi, tool, image, row, column, out area);
								if (!flag4)
								{
									bool flag5 = area >= bestArea;
									if (!flag5)
									{
										bestArea = area;
										bestRoi = roi;
										bestPanel = panelType;
									}
								}
							}
						}
					}
				}
				bool flag6 = bestRoi == null;
				if (flag6)
				{
					result = false;
				}
				else
				{
					this.SelectRoiItem(bestRoi, bestPanel, window);
					result = true;
				}
			}
			return result;
		}

		// Token: 0x060018C1 RID: 6337 RVA: 0x0007C298 File Offset: 0x0007A498
		private bool HitTestRoi(RoiData roi, ToolVision tool, HObject image, double row, double column, out double area)
		{
			area = 0.0;
			HObject region = null;
			bool result;
			try
			{
				region = this._roiImageService.BuildRoiRegion(roi, image, tool);
				bool flag = region == null || !region.IsInitialized();
				if (flag)
				{
					result = false;
				}
				else
				{
					HTuple isInside;
					HOperatorSet.TestRegionPoint(region, row, column, out isInside);
					bool flag2 = isInside.Length == 0 || isInside[0].I == 0;
					if (flag2)
					{
						result = false;
					}
					else
					{
						HTuple areas;
						HTuple htuple;
						HTuple __;
						HOperatorSet.AreaCenter(region, out areas, out htuple, out __);
						area = ((areas.Length > 0) ? areas.TupleSum().D : 0.0);
						result = true;
					}
				}
			}
			catch (HOperatorException)
			{
				result = false;
			}
			finally
			{
				if (region != null)
				{
					region.Dispose();
				}
			}
			return result;
		}

		// Token: 0x060018C2 RID: 6338 RVA: 0x0007C388 File Offset: 0x0007A588
		public void UpdateSelectedRoi(RoiPanelType panelType, HWindow window)
		{
			this.CurrentPanelType = panelType;
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null;
			if (flag)
			{
				DXMessageBox.Show("Please select a tool first.");
			}
			else
			{
				bool flag2 = tool.SelectedRoi == null;
				if (flag2)
				{
					DXMessageBox.Show("Please select an ROI from the list first.");
				}
				else
				{
					RoiData currentRoi = this._roiController.GetRoiData();
					bool flag3 = currentRoi == null;
					if (flag3)
					{
						DXMessageBox.Show("No current ROI is available on the HWindow.");
					}
					else
					{
						bool flag4 = panelType == RoiPanelType.Mask && currentRoi.RoiType == RoiType.Line;
						if (flag4)
						{
							DXMessageBox.Show("Mask ROI does not support Line ROI.");
						}
						else
						{
							bool flag5 = !this.ValidateFindLineRoi(tool, panelType, currentRoi.RoiType);
							if (!flag5)
							{
								bool flag6 = !this.ValidateFindCircleRoi(tool, panelType, currentRoi.RoiType);
								if (!flag6)
								{
									bool flag7 = !this.ValidateMeasureCircleRoi(tool, panelType, currentRoi.RoiType);
									if (!flag7)
									{
										bool flag8 = !this.ValidateFindBoundingBoxRoi(tool, panelType, currentRoi.RoiType, 0);
										if (!flag8)
										{
											this.CopyGeometryKeepProperties(currentRoi, tool.SelectedRoi);
											tool.SelectedRoi.Refresh();
											this._roiController.LoadRoi(tool.SelectedRoi, window);
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060018C3 RID: 6339 RVA: 0x0007C4C8 File Offset: 0x0007A6C8
		private bool ValidateFindLineRoi(ToolVision tool, RoiPanelType panelType, RoiType roiType)
		{
			bool flag = tool == null || tool.ToolType != ToolType.FindLine;
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = panelType > RoiPanelType.Normal;
				if (flag2)
				{
					DXMessageBox.Show("Find Line supports normal Line ROI only.");
					result = false;
				}
				else
				{
					bool flag3 = roiType != RoiType.Line;
					if (flag3)
					{
						DXMessageBox.Show("Find Line supports Line ROI only.");
						result = false;
					}
					else
					{
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x060018C4 RID: 6340 RVA: 0x0007C528 File Offset: 0x0007A728
		private bool ValidateFindCircleRoi(ToolVision tool, RoiPanelType panelType, RoiType roiType)
		{
			bool flag = tool == null || (tool.ToolType != ToolType.FindCircle && tool.ToolType != ToolType.CircleMaster);
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = panelType > RoiPanelType.Normal;
				if (flag2)
				{
					DXMessageBox.Show("Find Circle supports normal Circle ROI only.");
					result = false;
				}
				else
				{
					bool flag3 = roiType != RoiType.Circle;
					if (flag3)
					{
						DXMessageBox.Show("Find Circle supports Circle ROI only.");
						result = false;
					}
					else
					{
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x060018C5 RID: 6341 RVA: 0x0007C598 File Offset: 0x0007A798
		private bool ValidateMeasureCircleRoi(ToolVision tool, RoiPanelType panelType, RoiType roiType)
		{
			bool flag = tool == null || tool.ToolType != ToolType.MeasureCircle;
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = panelType > RoiPanelType.Normal;
				if (flag2)
				{
					DXMessageBox.Show("Measure Circle supports normal Circle ROI only.");
					result = false;
				}
				else
				{
					bool flag3 = roiType != RoiType.Circle;
					if (flag3)
					{
						DXMessageBox.Show("Measure Circle supports Circle ROI only.");
						result = false;
					}
					else
					{
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x060018C6 RID: 6342 RVA: 0x0007C5FC File Offset: 0x0007A7FC
		private bool ValidateFindBoundingBoxRoi(ToolVision tool, RoiPanelType panelType, RoiType roiType, int currentNormalRoiCount)
		{
			bool flag = tool == null || (tool.ToolType != ToolType.FindBoundingBox && tool.ToolType != ToolType.FindMinArea && tool.ToolType != ToolType.BoundingBoxMaster && tool.ToolType != ToolType.MinAreaMaster);
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = panelType > RoiPanelType.Normal;
				if (flag2)
				{
					DXMessageBox.Show("Find Bounding Box supports normal ROI only.");
					result = false;
				}
				else
				{
					bool flag3 = roiType == RoiType.Line;
					if (flag3)
					{
						DXMessageBox.Show("Find Bounding Box does not support Line ROI.");
						result = false;
					}
					else
					{
						bool flag4 = currentNormalRoiCount >= 1;
						if (flag4)
						{
							DXMessageBox.Show("Find Bounding Box supports only one ROI.");
							result = false;
						}
						else
						{
							result = true;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060018C7 RID: 6343 RVA: 0x0007C69C File Offset: 0x0007A89C
		public void DeleteRoi(RoiData roi)
		{
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null || roi == null;
			if (!flag)
			{
				bool flag2 = tool.RoiItems.Contains(roi);
				if (flag2)
				{
					tool.RoiItems.Remove(roi);
				}
				else
				{
					bool flag3 = tool.LimitRoiItems.Contains(roi);
					if (flag3)
					{
						tool.LimitRoiItems.Remove(roi);
					}
					else
					{
						bool flag4 = tool.MaskRoiItems.Contains(roi);
						if (flag4)
						{
							tool.MaskRoiItems.Remove(roi);
						}
					}
				}
				bool flag5 = tool.SelectedRoi == roi;
				if (flag5)
				{
					tool.SelectedRoi = null;
				}
			}
		}

		// Token: 0x060018C8 RID: 6344 RVA: 0x0007C73C File Offset: 0x0007A93C
		public int ClearRois(RoiPanelType panelType)
		{
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				ObservableCollection<RoiData> targetList = this.GetRoiList(tool, panelType);
				bool flag2 = targetList == null || targetList.Count == 0;
				if (flag2)
				{
					result = 0;
				}
				else
				{
					int count = targetList.Count;
					MessageBoxResult answer = DXMessageBox.Show(string.Concat(new string[]
					{
						"Delete all ",
						count.ToString(),
						" ",
						this.GetPrefixName(panelType),
						" items of ",
						string.IsNullOrWhiteSpace(tool.Name) ? "this tool" : tool.Name,
						"? This cannot be undone."
					}), "Clear ROI list", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
					bool flag3 = answer != MessageBoxResult.Yes;
					if (flag3)
					{
						result = 0;
					}
					else
					{
						bool flag4 = tool.SelectedRoi != null && targetList.Contains(tool.SelectedRoi);
						if (flag4)
						{
							tool.SelectedRoi = null;
						}
						targetList.Clear();
						result = count;
					}
				}
			}
			return result;
		}

		// Token: 0x060018C9 RID: 6345 RVA: 0x0007C844 File Offset: 0x0007AA44
		public void AddCustomPaintRoi(RoiPanelType panelType)
		{
			this.CurrentPanelType = panelType;
			ToolVision tool = this._getSelectedTool();
			bool flag = tool == null;
			if (flag)
			{
				DXMessageBox.Show("Please select a tool first.");
			}
			else
			{
				ObservableCollection<RoiData> targetList = this.GetRoiList(tool, panelType);
				bool flag2 = targetList == null;
				if (!flag2)
				{
					RoiData roi = new RoiData
					{
						RoiType = RoiType.CustomPaint,
						Name = this.GetPrefixName(panelType) + " " + (targetList.Count + 1).ToString(),
						MaskMode = RoiMaskMode.Inside,
						Polarity = RoiPolarity.Negative,
						IsEnabled = true,
						Description = string.Empty
					};
					this.ClearAllRoiSelection(tool);
					roi.IsSelected = true;
					targetList.Add(roi);
					tool.SelectedRoi = roi;
				}
			}
		}

		// Token: 0x060018CA RID: 6346 RVA: 0x0007C910 File Offset: 0x0007AB10
		public bool PaintCustomRoi(ToolVision tool, RoiData roi, Window ownerWindow)
		{
			bool flag = tool == null || roi == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				Func<HObject> getCurrentImage = this._getCurrentImage;
				HObject image = (getCurrentImage != null) ? getCurrentImage() : null;
				bool flag2 = image == null || !image.IsInitialized();
				if (flag2)
				{
					DXMessageBox.Show("No image is displayed for this TurnSnap. Snap or load an image first, then paint the Custom ROI on it.");
					result = false;
				}
				else
				{
					HObject existing = null;
					try
					{
						existing = CustomRoiRegionStore.Load(tool, roi);
						CustomRoiPaintEditor editor = new CustomRoiPaintEditor(image, existing);
						bool flag3 = ownerWindow != null && ownerWindow.IsLoaded;
						if (flag3)
						{
							editor.Owner = ownerWindow;
						}
						bool flag4 = !editor.ShowDialog().GetValueOrDefault();
						if (flag4)
						{
							result = false;
						}
						else
						{
							CustomRoiRegionStore.Save(tool, roi, editor.Region);
							HObject region = editor.Region;
							if (region != null)
							{
								region.Dispose();
							}
							roi.Refresh();
							result = true;
						}
					}
					catch (Exception ex)
					{
						DXMessageBox.Show("Failed to paint the Custom ROI: " + ex.Message);
						result = false;
					}
					finally
					{
						if (existing != null)
						{
							existing.Dispose();
						}
						image.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x060018CB RID: 6347 RVA: 0x0007CA38 File Offset: 0x0007AC38
		public void EditRoi(RoiData roi, Window ownerWindow)
		{
			bool flag = roi == null;
			if (!flag)
			{
				bool flag2 = roi.RoiType == RoiType.CustomPaint;
				if (flag2)
				{
					this.PaintCustomRoi(this._getSelectedTool(), roi, ownerWindow);
				}
				else
				{
					RoiPropertyEditor editor = new RoiPropertyEditor
					{
						DataContext = roi,
						CloneSettings = roi.CloneSettings
					};
					editor.MasterToolOptions.Add("None");
					editor.MasterPositionToolOptions.Add("None");
					editor.MasterAngleToolOptions.Add("None");
					ToolVision tool = this._getSelectedTool();
					ToolVision tool2 = tool;
					bool flag3 = ((tool2 != null) ? tool2.ParentTurnSnap : null) != null;
					if (flag3)
					{
						IEnumerable<ToolVision> tools = tool.ParentTurnSnap.Tools;
						Func<ToolVision, bool> <>9__2;
						Func<ToolVision, bool> predicate;
						if ((predicate = <>9__2) == null)
						{
							predicate = (<>9__2 = ((ToolVision x) => x != tool));
						}
						foreach (ToolVision item in from x in tools.TakeWhile(predicate)
						where x.ToolType == ToolType.Shape_model || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.BoundingBoxMaster || x.ToolType == ToolType.MinAreaMaster || x.ToolType == ToolType.IntersectingLines || x.ToolType == ToolType.AngleSelector || x.ToolType == ToolType.ProcedureModel
						select x)
						{
							editor.MasterToolOptions.Add(item.Name);
							bool flag4 = item.ToolType == ToolType.Shape_model || item.ToolType == ToolType.CircleMaster || item.ToolType == ToolType.BoundingBoxMaster || item.ToolType == ToolType.MinAreaMaster || item.ToolType == ToolType.IntersectingLines || item.ToolType == ToolType.ProcedureModel;
							if (flag4)
							{
								editor.MasterPositionToolOptions.Add(item.Name);
							}
							bool flag5 = item.ToolType == ToolType.Shape_model || item.ToolType == ToolType.MinAreaMaster || item.ToolType == ToolType.AngleSelector || item.ToolType == ToolType.ProcedureModel;
							if (flag5)
							{
								editor.MasterAngleToolOptions.Add(item.Name);
							}
						}
					}
					bool flag6 = string.IsNullOrWhiteSpace(roi.MasterToolName);
					if (flag6)
					{
						roi.MasterToolName = "None";
					}
					bool flag7 = string.IsNullOrWhiteSpace(roi.MasterPositionToolName);
					if (flag7)
					{
						roi.MasterPositionToolName = "None";
					}
					bool flag8 = string.IsNullOrWhiteSpace(roi.MasterAngleToolName);
					if (flag8)
					{
						roi.MasterAngleToolName = "None";
					}
					bool flag9 = roi.MasterToolName != "None" && roi.MasterPositionToolName == "None" && roi.MasterAngleToolName == "None";
					if (flag9)
					{
						roi.MasterPositionToolName = roi.MasterToolName;
						bool flag10 = editor.MasterAngleToolOptions.Contains(roi.MasterToolName);
						if (flag10)
						{
							roi.MasterAngleToolName = roi.MasterToolName;
						}
					}
					bool flag11 = !editor.MasterPositionToolOptions.Contains(roi.MasterPositionToolName);
					if (flag11)
					{
						roi.MasterPositionToolName = "None";
					}
					bool flag12 = !editor.MasterAngleToolOptions.Contains(roi.MasterAngleToolName);
					if (flag12)
					{
						roi.MasterAngleToolName = "None";
					}
					editor.Owner = WindowOwnerHelper.GetValidOwner(ownerWindow);
					editor.PreviewRequested = delegate(RoiCloneSettings settings)
					{
						Action<RoiData, IList<RoiData>> showRoiPreview = this._showRoiPreview;
						if (showRoiPreview != null)
						{
							showRoiPreview(roi, RoiCloneService.BuildClones(roi, settings));
						}
					};
					ToolVision ownerTool = tool;
					editor.Closed += delegate(object s, EventArgs e)
					{
						bool flag13 = this._activeRoiEditor == editor;
						if (flag13)
						{
							this._activeRoiEditor = null;
						}
						Action<RoiData, IList<RoiData>> showRoiPreview = this._showRoiPreview;
						if (showRoiPreview != null)
						{
							showRoiPreview(roi, null);
						}
						bool isConfirmed = editor.IsConfirmed;
						if (isConfirmed)
						{
							this.SyncLegacyMasterToolName(roi);
						}
						bool flag14 = editor.IsConfirmed && editor.CloneRequested;
						if (flag14)
						{
							this.CloneRoiInto(ownerTool, roi, editor.CloneSettings);
						}
						roi.Refresh();
					};
					this.CloseActiveRoiEditor();
					this._activeRoiEditor = editor;
					editor.Show();
				}
			}
		}

		// Token: 0x060018CC RID: 6348 RVA: 0x0007CE8C File Offset: 0x0007B08C
		private void CloseActiveRoiEditor()
		{
			RoiPropertyEditor open = this._activeRoiEditor;
			bool flag = open == null;
			if (!flag)
			{
				this._activeRoiEditor = null;
				try
				{
					open.Close();
				}
				catch (InvalidOperationException)
				{
				}
			}
		}

		// Token: 0x060018CD RID: 6349 RVA: 0x0007CED4 File Offset: 0x0007B0D4
		private void CloneRoiInto(ToolVision tool, RoiData source, RoiCloneSettings settings)
		{
			bool flag = tool == null || source == null || settings == null;
			if (!flag)
			{
				ObservableCollection<RoiData> targetList = null;
				RoiPanelType panelType = RoiPanelType.Normal;
				bool flag2 = tool.RoiItems.Contains(source);
				if (flag2)
				{
					targetList = tool.RoiItems;
					panelType = RoiPanelType.Normal;
				}
				else
				{
					bool flag3 = tool.LimitRoiItems.Contains(source);
					if (flag3)
					{
						targetList = tool.LimitRoiItems;
						panelType = RoiPanelType.Limit;
					}
					else
					{
						bool flag4 = tool.MaskRoiItems.Contains(source);
						if (flag4)
						{
							targetList = tool.MaskRoiItems;
							panelType = RoiPanelType.Mask;
						}
					}
				}
				bool flag5 = targetList == null;
				if (!flag5)
				{
					List<RoiData> clones = RoiCloneService.BuildClones(source, settings);
					bool flag6 = clones.Count == 0;
					if (flag6)
					{
						DXMessageBox.Show("This ROI cannot be cloned. A painted (Custom) ROI stores its pixels as a region file in image coordinates, so a copy has to be painted rather than offset.");
					}
					else
					{
						this.ClearAllRoiSelection(tool);
						string prefix = this.GetPrefixName(panelType);
						foreach (RoiData clone in clones)
						{
							clone.Name = prefix + " " + (targetList.Count + 1).ToString();
							targetList.Add(clone);
						}
						RoiData last = targetList[targetList.Count - 1];
						last.IsSelected = true;
						tool.SelectedRoi = last;
					}
				}
			}
		}

		// Token: 0x060018CE RID: 6350 RVA: 0x0007D030 File Offset: 0x0007B230
		private void SyncLegacyMasterToolName(RoiData roi)
		{
			bool flag = roi == null;
			if (!flag)
			{
				string positionMaster = string.IsNullOrWhiteSpace(roi.MasterPositionToolName) ? "None" : roi.MasterPositionToolName;
				string angleMaster = string.IsNullOrWhiteSpace(roi.MasterAngleToolName) ? "None" : roi.MasterAngleToolName;
				roi.MasterToolName = ((positionMaster == angleMaster) ? positionMaster : "None");
			}
		}

		// Token: 0x060018CF RID: 6351 RVA: 0x0007D098 File Offset: 0x0007B298
		private ObservableCollection<RoiData> GetRoiList(ToolVision tool, RoiPanelType panelType)
		{
			ObservableCollection<RoiData> result;
			if (panelType != RoiPanelType.Limit)
			{
				if (panelType != RoiPanelType.Mask)
				{
					result = tool.RoiItems;
				}
				else
				{
					result = tool.MaskRoiItems;
				}
			}
			else
			{
				result = tool.LimitRoiItems;
			}
			return result;
		}

		// Token: 0x060018D0 RID: 6352 RVA: 0x0007D0D4 File Offset: 0x0007B2D4
		private string GetPrefixName(RoiPanelType panelType)
		{
			string result;
			if (panelType != RoiPanelType.Limit)
			{
				if (panelType != RoiPanelType.Mask)
				{
					result = "ROI";
				}
				else
				{
					result = "Mask ROI";
				}
			}
			else
			{
				result = "Limit ROI";
			}
			return result;
		}

		// Token: 0x060018D1 RID: 6353 RVA: 0x0007D10C File Offset: 0x0007B30C
		private void ClearAllRoiSelection(ToolVision tool)
		{
			foreach (RoiData roi in tool.RoiItems)
			{
				roi.IsSelected = false;
			}
			foreach (RoiData roi2 in tool.LimitRoiItems)
			{
				roi2.IsSelected = false;
			}
			foreach (RoiData roi3 in tool.MaskRoiItems)
			{
				roi3.IsSelected = false;
			}
			tool.SelectedRoi = null;
		}

		// Token: 0x060018D2 RID: 6354 RVA: 0x0007D1EC File Offset: 0x0007B3EC
		private void CopyGeometryKeepProperties(RoiData source, RoiData target)
		{
			string oldName = target.Name;
			RoiMaskMode oldMaskMode = target.MaskMode;
			RoiPolarity oldPolarity = target.Polarity;
			bool oldEnabled = target.IsEnabled;
			string oldDescription = target.Description;
			string oldMasterToolName = target.MasterToolName;
			string oldMasterPositionToolName = target.MasterPositionToolName;
			string oldMasterAngleToolName = target.MasterAngleToolName;
			ObservableCollection<RoiExtraProperty> oldExtraProperties = target.ExtraProperties;
			bool oldIsSelected = target.IsSelected;
			target.RoiType = source.RoiType;
			target.Row1 = source.Row1;
			target.Col1 = source.Col1;
			target.Row2 = source.Row2;
			target.Col2 = source.Col2;
			target.CenterRow = source.CenterRow;
			target.CenterCol = source.CenterCol;
			target.Radius = source.Radius;
			target.Phi = source.Phi;
			target.Radius1 = source.Radius1;
			target.Radius2 = source.Radius2;
			target.Rows = ((source.Rows != null) ? new List<double>(source.Rows) : new List<double>());
			target.Cols = ((source.Cols != null) ? new List<double>(source.Cols) : new List<double>());
			target.Name = oldName;
			target.MaskMode = oldMaskMode;
			target.Polarity = oldPolarity;
			target.IsEnabled = oldEnabled;
			target.Description = oldDescription;
			target.MasterToolName = oldMasterToolName;
			target.MasterPositionToolName = oldMasterPositionToolName;
			target.MasterAngleToolName = oldMasterAngleToolName;
			target.ExtraProperties = oldExtraProperties;
			target.IsSelected = oldIsSelected;
		}

		// Token: 0x04000A40 RID: 2624
		private readonly RoiController _roiController = new RoiController();

		// Token: 0x04000A41 RID: 2625
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();

		// Token: 0x04000A42 RID: 2626
		private readonly Func<ToolVision> _getSelectedTool;

		// Token: 0x04000A43 RID: 2627
		private readonly Func<HObject> _getCurrentImage;

		// Token: 0x04000A45 RID: 2629
		private readonly Action<RoiData, IList<RoiData>> _showRoiPreview;

		// Token: 0x04000A46 RID: 2630
		private RoiPropertyEditor _activeRoiEditor;

		// Token: 0x04000A47 RID: 2631
		private RoiData _selectionAnchor;
	}
}
