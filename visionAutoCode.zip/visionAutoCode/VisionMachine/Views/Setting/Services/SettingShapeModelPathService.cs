﻿using System;
using System.IO;
using VisionMachine.Models.Tool;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001B1 RID: 433
	public class SettingShapeModelPathService
	{
		// Token: 0x060018D3 RID: 6355 RVA: 0x0007D370 File Offset: 0x0007B570
		public string GetShapeModelFolder(string turnSnapFolder)
		{
			string folder = Path.Combine(turnSnapFolder, "ShapeModels");
			Directory.CreateDirectory(folder);
			return folder;
		}

		// Token: 0x060018D4 RID: 6356 RVA: 0x0007D398 File Offset: 0x0007B598
		public string GetShapeModelFileName(ToolVision tool)
		{
			return "shape_model_" + tool.ToolId + ".shm";
		}

		// Token: 0x060018D5 RID: 6357 RVA: 0x0007D3C0 File Offset: 0x0007B5C0
		public string GetShapeModelFullPath(string turnSnapFolder, ToolVision tool)
		{
			return Path.Combine(this.GetShapeModelFolder(turnSnapFolder), this.GetShapeModelFileName(tool));
		}

		// Token: 0x060018D6 RID: 6358 RVA: 0x0007D3E8 File Offset: 0x0007B5E8
		public string GetShapeModelRelativePath(ToolVision tool)
		{
			return Path.Combine("ShapeModels", this.GetShapeModelFileName(tool));
		}
	}
}
