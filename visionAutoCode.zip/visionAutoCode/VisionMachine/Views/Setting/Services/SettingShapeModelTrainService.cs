﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Services;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001B2 RID: 434
	public class SettingShapeModelTrainService
	{
		// Token: 0x060018D8 RID: 6360 RVA: 0x0007D40C File Offset: 0x0007B60C
		public void TrainShapeModel(ToolVision tool, HObject inputImage = null)
		{
			bool flag = tool == null;
			if (!flag)
			{
				SettingMasterImageService masterService = new SettingMasterImageService();
				bool flag2 = tool.ParentTurnSnap == null;
				if (!flag2)
				{
					string turnSnapFolder = masterService.GetTurnSnapFolder(tool.ParentTurnSnap);
					string masterImagePath = masterService.GetMasterImagePath(tool.ParentTurnSnap);
					bool flag3 = string.IsNullOrWhiteSpace(turnSnapFolder);
					if (!flag3)
					{
						ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
						bool flag4 = train == null;
						if (!flag4)
						{
							bool flag5 = (inputImage == null || !inputImage.IsInitialized()) && (string.IsNullOrWhiteSpace(masterImagePath) || !File.Exists(masterImagePath));
							if (!flag5)
							{
								bool flag6 = tool.RoiItems == null || tool.RoiItems.Count == 0;
								if (!flag6)
								{
									List<RoiData> trainRois = (from r in tool.RoiItems
									where r.IsEnabled
									select r).ToList<RoiData>();
									bool flag7 = trainRois.Count == 0;
									if (!flag7)
									{
										HObject image = null;
										HObject grayImage = null;
										HObject maskedImage = null;
										HObject reduceImage = null;
										HTuple modelId = null;
										try
										{
											bool flag8 = inputImage != null && inputImage.IsInitialized();
											if (flag8)
											{
												HOperatorSet.CopyImage(inputImage, out image);
											}
											else
											{
												HOperatorSet.ReadImage(out image, masterImagePath);
											}
											grayImage = this.ConvertToGray(image);
											maskedImage = this._roiImageService.ApplyMaskRois(grayImage, tool);
											reduceImage = this._roiImageService.ReduceByRois(maskedImage, trainRois, tool);
											HObject shapeModelImage = null;
											HObject shapeModelRegion = null;
											HOperatorSet.InspectShapeModel(reduceImage, out shapeModelImage, out shapeModelRegion, 1, train.Threshold_Max);
											tool.ShapeModelPreviewRegion = shapeModelRegion;
											HOperatorSet.CreateShapeModel(reduceImage, "auto", 0, new HTuple(360).TupleRad(), "auto", "auto", "use_polarity", train.Threshold_Max, train.Threshold_Min, out modelId);
											string modelFullPath = this._pathService.GetShapeModelFullPath(turnSnapFolder, tool);
											HOperatorSet.WriteShapeModel(modelId, modelFullPath);
											ShapeModelRuntimeCache.ClearByTool(tool.ToolId.ToString());
											train.ShapeModelFileName = Path.GetFileName(modelFullPath);
											train.ShapeModelRelativePath = this._pathService.GetShapeModelRelativePath(tool);
											train.IsTrained = true;
										}
										catch
										{
										}
										finally
										{
											if (image != null)
											{
												image.Dispose();
											}
											if (grayImage != null)
											{
												grayImage.Dispose();
											}
											if (maskedImage != null)
											{
												maskedImage.Dispose();
											}
											if (reduceImage != null)
											{
												reduceImage.Dispose();
											}
											bool flag9 = modelId != null;
											if (flag9)
											{
												HOperatorSet.ClearShapeModel(modelId);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060018D9 RID: 6361 RVA: 0x0007D700 File Offset: 0x0007B900
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject grayImage;
			if (flag)
			{
				HOperatorSet.Rgb1ToGray(image, out grayImage);
			}
			else
			{
				HOperatorSet.CopyImage(image, out grayImage);
			}
			return grayImage;
		}

		// Token: 0x04000A48 RID: 2632
		private readonly SettingShapeModelPathService _pathService = new SettingShapeModelPathService();

		// Token: 0x04000A49 RID: 2633
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();
	}
}
