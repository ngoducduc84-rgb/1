﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.Blob;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CalibHandEye;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.CountBoundingBox;
using VisionMachine.VisionTools.DeformableInspection;
using VisionMachine.VisionTools.DistanceObject;
using VisionMachine.VisionTools.DLObjectInspection;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;
using VisionMachine.VisionTools.FindRedArrow;
using VisionMachine.VisionTools.Histogram;
using VisionMachine.VisionTools.HistogramColor;
using VisionMachine.VisionTools.ImageFilter;
using VisionMachine.VisionTools.ImageTransform;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MatrixCode;
using VisionMachine.VisionTools.MeasureCircle;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ProcedureInspection;
using VisionMachine.VisionTools.ProcedureModel;
using VisionMachine.VisionTools.ProductCountInspection;
using VisionMachine.VisionTools.ResultAlign;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.SaveImage;
using VisionMachine.VisionTools.ShapeModel;
using VisionMachine.VisionTools.VariationChangeWD;
using VisionMachine.VisionTools.VariationModel;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001B3 RID: 435
	public static class SettingToolFactory
	{
		// Token: 0x060018DB RID: 6363 RVA: 0x0007D778 File Offset: 0x0007B978
		public static ToolType GetToolTypeFromName(string toolName)
		{
			uint num = <PrivateImplementationDetails>.ComputeStringHash(toolName);
			if (num <= 1990689424U)
			{
				if (num <= 961282233U)
				{
					if (num <= 360648701U)
					{
						if (num <= 164165655U)
						{
							if (num != 66379620U)
							{
								if (num == 164165655U)
								{
									if (toolName == "Variation Model")
									{
										return ToolType.VariationModel;
									}
								}
							}
							else if (toolName == "Find Line")
							{
								return ToolType.FindLine;
							}
						}
						else if (num != 229498350U)
						{
							if (num != 303271089U)
							{
								if (num == 360648701U)
								{
									if (toolName == "Angle Selector")
									{
										return ToolType.AngleSelector;
									}
								}
							}
							else if (toolName == "Measure Circle")
							{
								return ToolType.MeasureCircle;
							}
						}
						else if (toolName == "Bounding Box Master")
						{
							return ToolType.BoundingBoxMaster;
						}
					}
					else if (num <= 800477719U)
					{
						if (num != 523322783U)
						{
							if (num == 800477719U)
							{
								if (toolName == "Product Count Inspection")
								{
									return ToolType.ProductCountInspection;
								}
							}
						}
						else if (toolName == "Boding box master")
						{
							return ToolType.BoundingBoxMaster;
						}
					}
					else if (num != 852613899U)
					{
						if (num != 881496793U)
						{
							if (num == 961282233U)
							{
								if (toolName == "Circle Master")
								{
									return ToolType.CircleMaster;
								}
							}
						}
						else if (toolName == "Image Loader")
						{
							return ToolType.ImageLoader;
						}
					}
					else if (toolName == "Find Min Area")
					{
						return ToolType.FindMinArea;
					}
				}
				else if (num <= 1820923482U)
				{
					if (num <= 1178730331U)
					{
						if (num != 1174169177U)
						{
							if (num == 1178730331U)
							{
								if (toolName == "Find Bounding Box")
								{
									return ToolType.FindBoundingBox;
								}
							}
						}
						else if (toolName == "Blob Detection")
						{
							return ToolType.Blob;
						}
					}
					else if (num != 1400648433U)
					{
						if (num != 1678708601U)
						{
							if (num == 1820923482U)
							{
								if (toolName == "Min Area Master")
								{
									return ToolType.MinAreaMaster;
								}
							}
						}
						else if (toolName == "Variation Change WD")
						{
							return ToolType.VariationChangeWD;
						}
					}
					else if (toolName == "Calib Hand-Eye")
					{
						return ToolType.CalibHandEye;
					}
				}
				else if (num <= 1881110770U)
				{
					if (num != 1875705702U)
					{
						if (num == 1881110770U)
						{
							if (toolName == "Histogram Color")
							{
								return ToolType.HistogramColor;
							}
						}
					}
					else if (toolName == "Result Inspection")
					{
						return ToolType.ResultInspection;
					}
				}
				else if (num != 1938830380U)
				{
					if (num != 1953382646U)
					{
						if (num == 1990689424U)
						{
							if (toolName == "Procedure Inspection")
							{
								return ToolType.ProcedureInspection;
							}
						}
					}
					else if (toolName == "Find Circle")
					{
						return ToolType.FindCircle;
					}
				}
				else if (toolName == "Overlapping Shape Model")
				{
					return ToolType.OverlappingShapeModel;
				}
			}
			else if (num <= 2730990024U)
			{
				if (num <= 2194735801U)
				{
					if (num <= 2066033061U)
					{
						if (num != 2057220327U)
						{
							if (num == 2066033061U)
							{
								if (toolName == "Distance object")
								{
									return ToolType.DistanceObject;
								}
							}
						}
						else if (toolName == "Procedure Model")
						{
							return ToolType.ProcedureModel;
						}
					}
					else if (num != 2137066969U)
					{
						if (num != 2190060865U)
						{
							if (num == 2194735801U)
							{
								if (toolName == "Result Align")
								{
									return ToolType.ResultAlign;
								}
							}
						}
						else if (toolName == "Histogram")
						{
							return ToolType.Histogram;
						}
					}
					else if (toolName == "Circle master")
					{
						return ToolType.CircleMaster;
					}
				}
				else if (num <= 2384678053U)
				{
					if (num != 2284850638U)
					{
						if (num == 2384678053U)
						{
							if (toolName == "Save Image")
							{
								return ToolType.SaveImage;
							}
						}
					}
					else if (toolName == "Deformable Inspection")
					{
						return ToolType.DeformableInspection;
					}
				}
				else if (num != 2463873556U)
				{
					if (num != 2532476581U)
					{
						if (num == 2730990024U)
						{
							if (toolName == "Image Filter")
							{
								return ToolType.ImageFilter;
							}
						}
					}
					else if (toolName == "Intersecting Lines")
					{
						return ToolType.IntersectingLines;
					}
				}
				else if (toolName == "Matrixcode Reader")
				{
					return ToolType.MatrixCode;
				}
			}
			else if (num <= 3820447675U)
			{
				if (num <= 3283291333U)
				{
					if (num != 3193565052U)
					{
						if (num == 3283291333U)
						{
							if (toolName == "Distance Object")
							{
								return ToolType.DistanceObject;
							}
						}
					}
					else if (toolName == "Find Red Arrow")
					{
						return ToolType.FindRedArrow;
					}
				}
				else if (num != 3309653487U)
				{
					if (num != 3619325830U)
					{
						if (num == 3820447675U)
						{
							if (toolName == "Find Bounding box")
							{
								return ToolType.FindBoundingBox;
							}
						}
					}
					else if (toolName == "Image Transform")
					{
						return ToolType.ImageTransform;
					}
				}
				else if (toolName == "Shape Model")
				{
					return ToolType.Shape_model;
				}
			}
			else if (num <= 4095833743U)
			{
				if (num != 3930029607U)
				{
					if (num == 4095833743U)
					{
						if (toolName == "OCR")
						{
							return ToolType.OCR;
						}
					}
				}
				else if (toolName == "Aniso Shape Model")
				{
					return ToolType.AnisoShapeModel;
				}
			}
			else if (num != 4180304524U)
			{
				if (num != 4201559766U)
				{
					if (num == 4225721261U)
					{
						if (toolName == "Count Bounding Box")
						{
							return ToolType.CountBoundingBox;
						}
					}
				}
				else if (toolName == "DL Object Inspection")
				{
					return ToolType.DLObjectInspection;
				}
			}
			else if (toolName == "Matrix Code Reader")
			{
				return ToolType.MatrixCode;
			}
			return ToolType.Unknown;
		}

		// Token: 0x060018DC RID: 6364 RVA: 0x0007DE84 File Offset: 0x0007C084
		public static ToolVision CreateToolFromTemplate(ToolVision draggedTool, TurnSnap turnSnap)
		{
			ToolType toolType = SettingToolFactory.GetToolTypeFromName(draggedTool.Name);
			string instanceName = SettingToolFactory.CreateUniqueInstanceName(draggedTool.Name, turnSnap);
			return new ToolVision
			{
				ToolId = instanceName,
				Name = instanceName,
				Icon = draggedTool.Icon,
				Index = turnSnap.Tools.Count + 1,
				ParentTurnSnap = turnSnap,
				ToolType = toolType,
				Config = SettingToolFactory.CreateDefaultConfig(toolType),
				Spec = SettingToolFactory.CreateDefaultSpec(toolType),
				TrainModel = SettingToolFactory.CreateDefaultTrain(toolType)
			};
		}

		// Token: 0x060018DD RID: 6365 RVA: 0x0007DF1C File Offset: 0x0007C11C
		private static string CreateUniqueInstanceName(string baseName, TurnSnap turnSnap)
		{
			bool flag = string.IsNullOrWhiteSpace(baseName);
			if (flag)
			{
				baseName = "Tool";
			}
			int number = SettingToolFactory.GetNextInstanceNumber(baseName, turnSnap);
			string instanceName = baseName + "_" + number.ToString();
			Func<ToolVision, bool> <>9__0;
			for (;;)
			{
				bool flag2;
				if (turnSnap == null)
				{
					flag2 = false;
				}
				else
				{
					ObservableCollection<ToolVision> tools = turnSnap.Tools;
					bool? flag3;
					if (tools == null)
					{
						flag3 = null;
					}
					else
					{
						Func<ToolVision, bool> predicate;
						if ((predicate = <>9__0) == null)
						{
							predicate = (<>9__0 = ((ToolVision x) => string.Equals(x.Name, instanceName, StringComparison.OrdinalIgnoreCase) || string.Equals(x.ToolId, instanceName, StringComparison.OrdinalIgnoreCase)));
						}
						flag3 = new bool?(tools.Any(predicate));
					}
					bool? flag4 = flag3;
					flag2 = flag4.GetValueOrDefault();
				}
				if (!flag2)
				{
					break;
				}
				number++;
				instanceName = baseName + "_" + number.ToString();
			}
			return instanceName;
		}

		// Token: 0x060018DE RID: 6366 RVA: 0x0007DFE4 File Offset: 0x0007C1E4
		private static int GetNextInstanceNumber(string baseName, TurnSnap turnSnap)
		{
			bool flag = ((turnSnap != null) ? turnSnap.Tools : null) == null;
			int result;
			if (flag)
			{
				result = 1;
			}
			else
			{
				int maxNumber = 0;
				foreach (ToolVision tool in turnSnap.Tools)
				{
					maxNumber = Math.Max(maxNumber, SettingToolFactory.GetInstanceNumber(tool.Name, baseName));
					maxNumber = Math.Max(maxNumber, SettingToolFactory.GetInstanceNumber(tool.ToolId, baseName));
				}
				result = maxNumber + 1;
			}
			return result;
		}

		// Token: 0x060018DF RID: 6367 RVA: 0x0007E078 File Offset: 0x0007C278
		private static int GetInstanceNumber(string value, string baseName)
		{
			bool flag = string.IsNullOrWhiteSpace(value);
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				string prefix = baseName + "_";
				bool flag2 = !value.StartsWith(prefix, StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result = 0;
				}
				else
				{
					int number;
					bool flag3 = !int.TryParse(value.Substring(prefix.Length), out number);
					if (flag3)
					{
						result = 0;
					}
					else
					{
						result = number;
					}
				}
			}
			return result;
		}

		// Token: 0x060018E0 RID: 6368 RVA: 0x0007E0DC File Offset: 0x0007C2DC
		public static ToolConfigBase CreateDefaultConfig(ToolType toolType)
		{
			switch (toolType)
			{
			case ToolType.Blob:
				return new BlobToolConfig
				{
					ThresholdPolarity = BlobThresholdPolarity.DarkToLight,
					ThresholdMin = 100.0,
					ThresholdMax = 255.0,
					MinArea = 10.0,
					MaxArea = 999999.0,
					ShowRoi = true,
					ShowThreshold = false,
					ShowInputImage = false
				};
			case ToolType.Histogram:
				return new HistogramToolConfig
				{
					GrayMin = 0.0,
					GrayMax = 255.0,
					ShowRoi = true,
					ShowThreshold = false,
					ShowText = true,
					ShowInputImage = false
				};
			case ToolType.HistogramColor:
				return new HistogramColorToolConfig
				{
					RedMin = 0.0,
					RedMax = 255.0,
					GreenMin = 0.0,
					GreenMax = 255.0,
					BlueMin = 0.0,
					BlueMax = 255.0,
					ShowRoi = true,
					ShowThreshold = false,
					ShowText = true,
					ShowInputImage = false
				};
			case ToolType.FindCircle:
				return new FindCircleToolConfig
				{
					Sigma = 2.0,
					MeasureThreshold = 10.0,
					Length1 = 30.0,
					Length2 = 5.0,
					StartPhi = 0.0,
					EndPhi = 360.0,
					MinScore = 0.3,
					NumInstances = 1,
					Transition = FindCircleTransition.DarkToLight,
					Selector = FindCircleSelector.All,
					ShowRoi = true,
					ShowFoundCircle = true,
					ShowSearchOutline = true,
					ShowText = true,
					TextSize = 14,
					DisplayColor = "yellow"
				};
			case ToolType.FindLine:
				return new FindLineToolConfig
				{
					Sigma = 5,
					MeasureThreshold = 10,
					ThresholdMin = 0,
					ThresholdMax = 255,
					Length1 = 70,
					Length2 = 50,
					EdgeTransition = FindLineEdgeTransition.DarkToLight,
					Selector = FindLineMeasureSelector.All,
					ShowRoi = true,
					ShowFoundLine = true,
					ShowSearchOutline = true,
					ShowCoordinateText = true,
					CoordinateTextSize = 14,
					CoordinateTextColor = "white"
				};
			case ToolType.Shape_model:
				return new ShapeModelToolConfig
				{
					Angle_Start = 0.0,
					Angle_extent = 360.0,
					Min_score = 0.2,
					Num_matched = 0.0,
					Max_overlap = 0.55,
					Num_level = 0.0,
					Greediness = 0.7,
					PickRow = 0,
					PickColumn = 0,
					RowSpacing = 20.0,
					ColumnSpacing = 20.0,
					show_roi = false,
					show_limit_roi = false,
					show_text = false,
					TextSize = 14,
					ShowAllMatches = false,
					ShowModelContour = false,
					ShowMultiRoi = false,
					MultiRoiColor = "gray",
					ShowMultiRoiCenter = false,
					MultiCenterColor = "orange",
					MultiObjectTextColor = "white",
					Use_lost_master = false
				};
			case ToolType.AnisoShapeModel:
				return new AnisoShapeModelToolConfig
				{
					ImageMode = AnisoShapeModelImageMode.MultiChannel,
					Angle_Start = -30.0,
					Angle_extent = 60.0,
					ScaleRowMin = 0.9,
					ScaleRowMax = 1.1,
					ScaleColumnMin = 0.9,
					ScaleColumnMax = 1.1,
					Min_score = 0.8,
					Num_matched = 0.0,
					Max_overlap = 0.55,
					Num_level = 0.0,
					Greediness = 0.7,
					PickRow = 0,
					PickColumn = 0,
					RowSpacing = 20.0,
					ColumnSpacing = 20.0,
					CoordinateSortMode = AnisoShapeModelCoordinateSortMode.TopToBottomLeftToRight,
					show_roi = true,
					show_limit_roi = true,
					show_text = true,
					TextSize = 14,
					ShowAllMatches = true,
					ShowModelContour = true,
					ShowMultiRoi = true,
					MultiRoiColor = "gray",
					ShowMultiRoiCenter = true,
					MultiCenterColor = "orange",
					MultiObjectTextColor = "white",
					Use_lost_master = false
				};
			case ToolType.OverlappingShapeModel:
				return new OverlappingShapeModelToolConfig
				{
					ImageMode = OverlappingShapeModelImageMode.Gray,
					Angle_Start = -180.0,
					Angle_extent = 360.0,
					Min_score = 0.3,
					Num_matched = 12.0,
					Max_overlap = 0.9,
					Num_level = 0.0,
					Greediness = 0.7,
					PickRow = 0,
					PickColumn = 0,
					RowSpacing = 20.0,
					ColumnSpacing = 20.0,
					SortMultiObjectOutput = true,
					CoordinateSortMode = AnisoShapeModelCoordinateSortMode.TopToBottomLeftToRight,
					ShowObjectOrder = true,
					show_roi = true,
					show_limit_roi = true,
					show_text = true,
					TextSize = 14,
					ShowMultiRoi = true
				};
			case ToolType.ImageFilter:
				return new ImageFilterToolConfig();
			case ToolType.ImageTransform:
				return new ImageTransformToolConfig();
			case ToolType.SaveImage:
				return new SaveImageToolConfig
				{
					ImageFormat = SaveImageFormat.Png,
					NamingMode = SaveImageNamingMode.DateTime
				};
			case ToolType.MatrixCode:
				return new MatrixCodeToolConfig
				{
					CodeType = MatrixCodeType.DataMatrixEcc200,
					AutoSearchType = false,
					ShowRoi = true,
					ShowResult = true,
					TextSize = 16,
					DisplayColor = "lime green"
				};
			case ToolType.DistanceObject:
				return new DistanceObjectToolConfig
				{
					Parameter = new DistanceObjectParameterConfig
					{
						FirstFeature = DistanceObjectFeature.MidPoint,
						SecondFeature = DistanceObjectFeature.Line,
						MeasurementMode = DistanceMeasurementMode.Auto,
						ShowArrow = true,
						ShowText = true,
						TextSize = 14,
						DisplayColor = "yellow"
					},
					Calibration = new DistanceObjectCalibrationConfig()
				};
			case ToolType.MeasureCircle:
				return new MeasureCircleToolConfig
				{
					Parameter = new MeasureCircleParameterConfig
					{
						MeasureMode = MeasureCircleMode.Diameter,
						Sigma = 2.0,
						MeasureThreshold = 10.0,
						Length1 = 30.0,
						Length2 = 5.0,
						StartPhi = 0.0,
						EndPhi = 360.0,
						MinScore = 0.3,
						NumInstances = 1,
						Transition = MeasureCircleTransition.DarkToLight,
						Selector = MeasureCircleSelector.All,
						ShowRoi = true,
						ShowFoundCircle = true,
						ShowSearchOutline = true,
						ShowText = true,
						TextSize = 14,
						DisplayColor = "yellow"
					},
					Calibration = new MeasureCircleCalibrationConfig()
				};
			case ToolType.CircleMaster:
				return new CircleMasterToolConfig
				{
					Sigma = 2.0,
					MeasureThreshold = 10.0,
					Length1 = 30.0,
					Length2 = 5.0,
					StartPhi = 0.0,
					EndPhi = 360.0,
					MinScore = 0.3,
					NumInstances = 1,
					Transition = FindCircleTransition.DarkToLight,
					Selector = FindCircleSelector.All,
					ShowRoi = true,
					ShowFoundCircle = true,
					ShowSearchOutline = true,
					ShowText = true,
					TextSize = 14,
					DisplayColor = "yellow"
				};
			case ToolType.BoundingBoxMaster:
				return new BoundingBoxMasterToolConfig
				{
					ThresholdPolarity = FindBoundingBoxPolarity.DarkToLight,
					ThresholdMin = 100.0,
					ThresholdMax = 255.0,
					MinArea = 10.0,
					MaxArea = 999999.0,
					MinWidth = 0.0,
					MaxWidth = 999999.0,
					MinHeight = 0.0,
					MaxHeight = 999999.0,
					PickRow = 0,
					PickColumn = 0,
					RowSpacing = 20.0,
					ColumnSpacing = 20.0,
					ShowRoi = true,
					ShowThreshold = false,
					ShowAllBoxes = false,
					ShowText = true,
					TextSize = 14,
					TextColor = "green",
					ShowInputImage = false
				};
			case ToolType.MinAreaMaster:
				return new MinAreaMasterToolConfig
				{
					ThresholdPolarity = FindMinAreaPolarity.DarkToLight,
					ThresholdMin = 100.0,
					ThresholdMax = 255.0,
					MinArea = 10.0,
					MaxArea = 999999.0,
					MinWidth = 0.0,
					MaxWidth = 999999.0,
					MinHeight = 0.0,
					MaxHeight = 999999.0,
					RowSpacing = 20.0,
					ColumnSpacing = 20.0,
					ShowRoi = true,
					ShowThreshold = false,
					ShowAllBoxes = true,
					ShowText = true,
					TextSize = 14,
					TextColor = "green",
					ShowInputImage = false
				};
			case ToolType.IntersectingLines:
				return new IntersectingLinesToolConfig
				{
					ShowSourceLines = true,
					ShowIntersectionPoint = true,
					ShowText = true,
					TextSize = 14,
					DisplayColor = "yellow"
				};
			case ToolType.AngleSelector:
				return new AngleSelectorToolConfig
				{
					FirstFeature = AngleSelectorFeature.MidPoint,
					SecondFeature = AngleSelectorFeature.CenterPoint,
					CompareAxis = AngleSelectorAxis.X,
					Quadrant = AngleSelectorQuadrant.Auto,
					ShowSourceObjects = true,
					ShowVector = true,
					ShowAngleGuide = true,
					ShowText = true,
					TextSize = 14,
					DisplayColor = "green"
				};
			case ToolType.FindBoundingBox:
				return new FindBoundingBoxToolConfig
				{
					ThresholdPolarity = FindBoundingBoxPolarity.DarkToLight,
					ThresholdMin = 100.0,
					ThresholdMax = 255.0,
					MinArea = 10.0,
					MaxArea = 999999.0,
					MinWidth = 0.0,
					MaxWidth = 999999.0,
					MinHeight = 0.0,
					MaxHeight = 999999.0,
					PickRow = 0,
					PickColumn = 0,
					RowSpacing = 20.0,
					ColumnSpacing = 20.0,
					ShowRoi = true,
					ShowThreshold = false,
					ShowAllBoxes = false,
					ShowText = true,
					TextSize = 14,
					TextColor = "green",
					ShowInputImage = false
				};
			case ToolType.FindMinArea:
				return new FindMinAreaToolConfig
				{
					ThresholdPolarity = FindMinAreaPolarity.DarkToLight,
					ThresholdMin = 100.0,
					ThresholdMax = 255.0,
					MinArea = 10.0,
					MaxArea = 999999.0,
					MinWidth = 0.0,
					MaxWidth = 999999.0,
					MinHeight = 0.0,
					MaxHeight = 999999.0,
					RowSpacing = 20.0,
					ColumnSpacing = 20.0,
					ShowRoi = true,
					ShowThreshold = false,
					ShowAllBoxes = true,
					ShowText = true,
					TextSize = 14,
					TextColor = "green"
				};
			case ToolType.CalibHandEye:
				return new CalibHandEyeToolConfig
				{
					MasterToolName = "None",
					ObjectMode = CalibHandEyeObjectMode.MultiObject,
					ShowText = true,
					TextColor = "green",
					TextSize = 14
				};
			case ToolType.ResultAlign:
				return new CalibResultAlignToolConfig
				{
					ShowText = true,
					TextColor = "cyan",
					TextSize = 14
				};
			case ToolType.ResultInspection:
				return new CalibResultInspectionToolConfig
				{
					ShowText = true,
					TextSize = 18
				};
			case ToolType.DeformableInspection:
				return new DeformableInspectionToolConfig();
			case ToolType.VariationModel:
				return new VariationModelToolConfig();
			case ToolType.DLObjectInspection:
				return new DLObjectInspectionToolConfig();
			case ToolType.VariationChangeWD:
				return new VariationChangeWDToolConfig();
			case ToolType.ProductCountInspection:
				return new ProductCountInspectionToolConfig();
			case ToolType.FindRedArrow:
				return new FindRedArrowToolConfig();
			case ToolType.CountBoundingBox:
				return new CountBoundingBoxToolConfig();
			case ToolType.ProcedureInspection:
				return new ProcedureInspectionToolConfig();
			case ToolType.ProcedureModel:
				return new ProcedureModelToolConfig();
			}
			return null;
		}

		// Token: 0x060018E1 RID: 6369 RVA: 0x0007EF40 File Offset: 0x0007D140
		public static ToolSpecBase CreateDefaultSpec(ToolType toolType)
		{
			switch (toolType)
			{
			case ToolType.Blob:
				return new BlobToolSpec
				{
					NormalSize = 100.0,
					UpperDeviation = 10.0,
					LowerDeviation = 10.0
				};
			case ToolType.Histogram:
				return new HistogramToolSpec
				{
					NormalSize = 100.0,
					UpperDeviation = 10.0,
					LowerDeviation = 10.0
				};
			case ToolType.HistogramColor:
				return new HistogramColorToolSpec
				{
					NormalSize = 100.0,
					UpperDeviation = 10.0,
					LowerDeviation = 10.0
				};
			case ToolType.FindLine:
				return new FindLineToolSpec();
			case ToolType.ImageTransform:
				return new ImageTransformToolSpec();
			case ToolType.DistanceObject:
				return new DistanceObjectToolSpec
				{
					NormalSize = 0.0,
					UpperDeviation = 1000000.0,
					LowerDeviation = 0.0
				};
			case ToolType.MeasureCircle:
				return new MeasureCircleToolSpec
				{
					NormalSize = 0.0,
					UpperDeviation = 1000000.0,
					LowerDeviation = 0.0
				};
			case ToolType.BoundingBoxMaster:
				return null;
			case ToolType.MinAreaMaster:
				return null;
			case ToolType.FindBoundingBox:
				return null;
			case ToolType.FindMinArea:
				return null;
			case ToolType.DeformableInspection:
				return new DeformableInspectionToolSpec();
			case ToolType.VariationModel:
				return new VariationModelToolSpec();
			case ToolType.DLObjectInspection:
				return new DLObjectInspectionToolSpec();
			case ToolType.VariationChangeWD:
				return new VariationChangeWDToolSpec();
			case ToolType.ProductCountInspection:
				return new ProductCountInspectionToolSpec();
			case ToolType.FindRedArrow:
				return new FindRedArrowToolSpec();
			case ToolType.CountBoundingBox:
				return new CountBoundingBoxToolSpec();
			case ToolType.ProcedureInspection:
				return new ProcedureInspectionToolSpec();
			}
			return null;
		}

		// Token: 0x060018E2 RID: 6370 RVA: 0x0007F174 File Offset: 0x0007D374
		public static ToolTrainBase CreateDefaultTrain(ToolType toolType)
		{
			switch (toolType)
			{
			case ToolType.Shape_model:
			case ToolType.AnisoShapeModel:
			case ToolType.CircleMaster:
			case ToolType.BoundingBoxMaster:
			case ToolType.MinAreaMaster:
			case ToolType.IntersectingLines:
			case ToolType.AngleSelector:
				return new ShapeModelToolTrain
				{
					Threshold_Min = 5.0,
					Threshold_Max = 30.0
				};
			case ToolType.OverlappingShapeModel:
				return new ShapeModelToolTrain
				{
					Threshold_Min = 20.0,
					Threshold_Max = 30.0
				};
			case ToolType.ImageFilter:
			case ToolType.ImageTransform:
			case ToolType.SaveImage:
			case ToolType.MatrixCode:
			case ToolType.DistanceObject:
			case ToolType.MeasureCircle:
			case ToolType.FindBoundingBox:
			case ToolType.FindMinArea:
			case ToolType.CalibHandEye:
			case ToolType.ResultAlign:
			case ToolType.ResultInspection:
				break;
			case ToolType.DeformableInspection:
				return new DeformableInspectionToolTrain();
			case ToolType.VariationModel:
				return new VariationModelToolTrain();
			case ToolType.DLObjectInspection:
				return new DLObjectInspectionToolTrain();
			case ToolType.VariationChangeWD:
				return new VariationChangeWDToolTrain();
			case ToolType.ProductCountInspection:
				return new ProductCountInspectionToolTrain();
			default:
				if (toolType == ToolType.ProcedureModel)
				{
					return new ProcedureModelToolTrain();
				}
				break;
			}
			return null;
		}
	}
}
