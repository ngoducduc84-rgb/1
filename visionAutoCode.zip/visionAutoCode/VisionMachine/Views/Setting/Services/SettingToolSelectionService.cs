﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Controls;
using VisionMachine.Models.Tool;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Main;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.AngleSelector.Views;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.AnisoShapeModel.Views;
using VisionMachine.VisionTools.Blob;
using VisionMachine.VisionTools.Blob.Views;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.BoundingBoxMaster.Views;
using VisionMachine.VisionTools.CalibHandEye;
using VisionMachine.VisionTools.CalibHandEye.Views;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.CircleMaster.Views;
using VisionMachine.VisionTools.CountBoundingBox;
using VisionMachine.VisionTools.CountBoundingBox.Views;
using VisionMachine.VisionTools.DeformableInspection;
using VisionMachine.VisionTools.DeformableInspection.Views;
using VisionMachine.VisionTools.DistanceObject;
using VisionMachine.VisionTools.DistanceObject.Views;
using VisionMachine.VisionTools.DLObjectInspection;
using VisionMachine.VisionTools.DLObjectInspection.Views;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindBoundingBox.Views;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindCircle.Views;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindLine.Views;
using VisionMachine.VisionTools.FindMinArea;
using VisionMachine.VisionTools.FindMinArea.Views;
using VisionMachine.VisionTools.FindRedArrow;
using VisionMachine.VisionTools.FindRedArrow.Views;
using VisionMachine.VisionTools.Histogram;
using VisionMachine.VisionTools.Histogram.Views;
using VisionMachine.VisionTools.HistogramColor;
using VisionMachine.VisionTools.HistogramColor.Views;
using VisionMachine.VisionTools.ImageFilter;
using VisionMachine.VisionTools.ImageFilter.Views;
using VisionMachine.VisionTools.ImageTransform;
using VisionMachine.VisionTools.ImageTransform.Views;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.IntersectingLines.Views;
using VisionMachine.VisionTools.MatrixCode;
using VisionMachine.VisionTools.MatrixCode.Views;
using VisionMachine.VisionTools.MeasureCircle;
using VisionMachine.VisionTools.MeasureCircle.Views;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.MinAreaMaster.Views;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.OverlappingShapeModel.Views;
using VisionMachine.VisionTools.ProcedureInspection;
using VisionMachine.VisionTools.ProcedureInspection.Views;
using VisionMachine.VisionTools.ProcedureModel;
using VisionMachine.VisionTools.ProcedureModel.Views;
using VisionMachine.VisionTools.ProductCountInspection;
using VisionMachine.VisionTools.ProductCountInspection.Views;
using VisionMachine.VisionTools.ResultAlign;
using VisionMachine.VisionTools.ResultAlign.Views;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.ResultInspection.Views;
using VisionMachine.VisionTools.SaveImage;
using VisionMachine.VisionTools.SaveImage.Views;
using VisionMachine.VisionTools.ShapeModel;
using VisionMachine.VisionTools.ShapeModel.Views;
using VisionMachine.VisionTools.VariationChangeWD;
using VisionMachine.VisionTools.VariationChangeWD.Views;
using VisionMachine.VisionTools.VariationModel;
using VisionMachine.VisionTools.VariationModel.Views;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001B4 RID: 436
	public class SettingToolSelectionService
	{
		// Token: 0x060018E3 RID: 6371 RVA: 0x0007F280 File Offset: 0x0007D480
		public void SelectTool(ToolVision tool)
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag = tool == null;
			if (flag)
			{
				vm.CurrentParameterView = null;
			}
			else
			{
				bool flag2 = ((vm != null) ? vm.SelectedCamera : null) == null;
				if (!flag2)
				{
					foreach (TurnSnap turnSnap in vm.SelectedCamera.TurnSnaps)
					{
						turnSnap.IsSelected = false;
						foreach (ToolVision item in turnSnap.Tools)
						{
							item.IsSelected = false;
						}
					}
					tool.IsSelected = true;
					vm.SelectedTool = tool;
					bool flag3 = Form_setting.Instance != null;
					if (flag3)
					{
						Form_setting.Instance.RefreshShapeModelPreview(tool);
					}
					TurnSnap parentTurnSnap = vm.SelectedCamera.TurnSnaps.FirstOrDefault((TurnSnap ts) => ts.Tools.Contains(tool));
					bool flag4 = parentTurnSnap != null;
					if (flag4)
					{
						parentTurnSnap.IsSelected = true;
					}
					vm.CurrentParameterView = this.CreateParameterView(tool);
				}
			}
		}

		// Token: 0x060018E4 RID: 6372 RVA: 0x0007F3F0 File Offset: 0x0007D5F0
		private ObservableCollection<ToolImageSourceOption> GetPreviousImageOutputTools(ToolVision currentTool)
		{
			ObservableCollection<ToolImageSourceOption> result = new ObservableCollection<ToolImageSourceOption>();
			bool flag = currentTool == null || currentTool.ParentTurnSnap == null;
			ObservableCollection<ToolImageSourceOption> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (ToolVision tool in currentTool.ParentTurnSnap.Tools)
				{
					bool flag2 = tool == currentTool;
					if (flag2)
					{
						break;
					}
					bool flag3 = this.IsImageOutputTool(tool);
					if (flag3)
					{
						result.Add(new ToolImageSourceOption
						{
							ToolId = tool.ToolId,
							ToolName = tool.Name,
							Index = tool.Index
						});
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x060018E5 RID: 6373 RVA: 0x0007F4BC File Offset: 0x0007D6BC
		private bool IsImageOutputTool(ToolVision tool)
		{
			bool flag = tool == null;
			return !flag && (tool.ToolType == ToolType.ImageFilter || tool.ToolType == ToolType.ImageTransform || tool.ToolType == ToolType.SaveImage);
		}

		// Token: 0x060018E6 RID: 6374 RVA: 0x0007F4FC File Offset: 0x0007D6FC
		private ObservableCollection<DistanceObjectLineOption> GetPreviousMeasureObjectTools(ToolVision currentTool)
		{
			ObservableCollection<DistanceObjectLineOption> result = new ObservableCollection<DistanceObjectLineOption>();
			bool flag = currentTool == null || currentTool.ParentTurnSnap == null;
			ObservableCollection<DistanceObjectLineOption> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (ToolVision tool in currentTool.ParentTurnSnap.Tools)
				{
					bool flag2 = tool == currentTool;
					if (flag2)
					{
						break;
					}
					bool flag3 = tool.ToolType == ToolType.FindLine || tool.ToolType == ToolType.FindCircle || tool.ToolType == ToolType.CircleMaster || tool.ToolType == ToolType.FindBoundingBox || tool.ToolType == ToolType.FindMinArea;
					if (flag3)
					{
						result.Add(new DistanceObjectLineOption
						{
							ToolName = tool.Name,
							Index = tool.Index,
							ToolType = tool.ToolType
						});
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x060018E7 RID: 6375 RVA: 0x0007F600 File Offset: 0x0007D800
		private ObservableCollection<IntersectingLinesLineOption> GetPreviousFindLineTools(ToolVision currentTool)
		{
			ObservableCollection<IntersectingLinesLineOption> result = new ObservableCollection<IntersectingLinesLineOption>();
			bool flag = currentTool == null || currentTool.ParentTurnSnap == null;
			ObservableCollection<IntersectingLinesLineOption> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (ToolVision tool in currentTool.ParentTurnSnap.Tools)
				{
					bool flag2 = tool == currentTool;
					if (flag2)
					{
						break;
					}
					bool flag3 = tool.ToolType == ToolType.FindLine;
					if (flag3)
					{
						result.Add(new IntersectingLinesLineOption
						{
							ToolName = tool.Name,
							Index = tool.Index
						});
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x060018E8 RID: 6376 RVA: 0x0007F6BC File Offset: 0x0007D8BC
		private ObservableCollection<AngleSelectorSourceOption> GetPreviousAngleObjectTools(ToolVision currentTool)
		{
			ObservableCollection<AngleSelectorSourceOption> result = new ObservableCollection<AngleSelectorSourceOption>();
			bool flag = currentTool == null || currentTool.ParentTurnSnap == null;
			ObservableCollection<AngleSelectorSourceOption> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (ToolVision tool in currentTool.ParentTurnSnap.Tools)
				{
					bool flag2 = tool == currentTool;
					if (flag2)
					{
						break;
					}
					bool flag3 = tool.ToolType == ToolType.FindLine || tool.ToolType == ToolType.FindCircle || tool.ToolType == ToolType.CircleMaster || tool.ToolType == ToolType.FindBoundingBox || tool.ToolType == ToolType.FindMinArea;
					if (flag3)
					{
						result.Add(new AngleSelectorSourceOption
						{
							ToolName = tool.Name,
							Index = tool.Index,
							ToolType = tool.ToolType
						});
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x060018E9 RID: 6377 RVA: 0x0007F7C0 File Offset: 0x0007D9C0
		private ObservableCollection<ResultInspectionSourceOption> GetPreviousInspectionTools(ToolVision currentTool)
		{
			ObservableCollection<ResultInspectionSourceOption> result = new ObservableCollection<ResultInspectionSourceOption>();
			bool flag = currentTool == null || currentTool.ParentTurnSnap == null;
			ObservableCollection<ResultInspectionSourceOption> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (ToolVision tool in currentTool.ParentTurnSnap.Tools)
				{
					bool flag2 = tool == currentTool;
					if (flag2)
					{
						break;
					}
					bool flag3 = tool.ToolType == ToolType.Blob || tool.ToolType == ToolType.Histogram || tool.ToolType == ToolType.HistogramColor || tool.ToolType == ToolType.DeformableInspection || tool.ToolType == ToolType.VariationModel || tool.ToolType == ToolType.VariationChangeWD || tool.ToolType == ToolType.ProductCountInspection || tool.ToolType == ToolType.FindRedArrow || tool.ToolType == ToolType.CountBoundingBox || tool.ToolType == ToolType.ProcedureInspection || tool.ToolType == ToolType.DLObjectInspection || tool.ToolType == ToolType.DistanceObject || tool.ToolType == ToolType.MeasureCircle;
					if (flag3)
					{
						result.Add(new ResultInspectionSourceOption
						{
							ToolName = tool.Name,
							ToolTypeText = tool.ToolType.ToString()
						});
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x060018EA RID: 6378 RVA: 0x0007F920 File Offset: 0x0007DB20
		private ObservableCollection<ResultAlignSourceOption> GetPreviousCalibHandEyeTools(ToolVision currentTool)
		{
			ObservableCollection<ResultAlignSourceOption> result = new ObservableCollection<ResultAlignSourceOption>();
			bool flag = currentTool == null || currentTool.ParentTurnSnap == null;
			ObservableCollection<ResultAlignSourceOption> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (ToolVision tool in currentTool.ParentTurnSnap.Tools)
				{
					bool flag2 = tool == currentTool;
					if (flag2)
					{
						break;
					}
					bool flag3 = tool.ToolType == ToolType.CalibHandEye;
					if (flag3)
					{
						result.Add(new ResultAlignSourceOption
						{
							ToolName = tool.Name
						});
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x060018EB RID: 6379 RVA: 0x0007F9D0 File Offset: 0x0007DBD0
		private ObservableCollection<CalibHandEyeMasterOption> GetPreviousCalibMasterTools(ToolVision currentTool)
		{
			ObservableCollection<CalibHandEyeMasterOption> result = new ObservableCollection<CalibHandEyeMasterOption>();
			bool flag = currentTool == null || currentTool.ParentTurnSnap == null;
			ObservableCollection<CalibHandEyeMasterOption> result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				foreach (ToolVision tool in currentTool.ParentTurnSnap.Tools)
				{
					bool flag2 = tool == currentTool;
					if (flag2)
					{
						break;
					}
					bool flag3 = tool.ToolType == ToolType.Shape_model || tool.ToolType == ToolType.AnisoShapeModel || tool.ToolType == ToolType.OverlappingShapeModel || tool.ToolType == ToolType.BoundingBoxMaster || tool.ToolType == ToolType.MinAreaMaster || tool.ToolType == ToolType.CircleMaster || tool.ToolType == ToolType.ProcedureModel;
					if (flag3)
					{
						result.Add(new CalibHandEyeMasterOption
						{
							ToolName = tool.Name,
							Index = tool.Index,
							ToolType = tool.ToolType
						});
					}
				}
				result2 = result;
			}
			return result2;
		}

		// Token: 0x060018EC RID: 6380 RVA: 0x0007FAEC File Offset: 0x0007DCEC
		public UserControl CreateParameterView(ToolVision tool)
		{
			bool flag = tool == null;
			UserControl result;
			if (flag)
			{
				result = null;
			}
			else
			{
				switch (tool.ToolType)
				{
				case ToolType.Blob:
				{
					BlobParameterPanelViewModel blobVm = new BlobParameterPanelViewModel
					{
						Tool = tool,
						BlobConfig = (tool.Config as BlobToolConfig),
						BlobSpec = (tool.Spec as BlobToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					blobVm.RestoreSelectedSourceTool();
					return new Blob_para
					{
						DataContext = blobVm
					};
				}
				case ToolType.Histogram:
				{
					bool flag2 = !(tool.Spec is HistogramToolSpec);
					if (flag2)
					{
						tool.Spec = SettingToolFactory.CreateDefaultSpec(ToolType.Histogram);
					}
					HistogramParameterPanelViewModel histogramVm = new HistogramParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as HistogramToolConfig),
						Spec = (tool.Spec as HistogramToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					histogramVm.RestoreSelectedSourceTool();
					return new Histogram_para
					{
						DataContext = histogramVm
					};
				}
				case ToolType.HistogramColor:
				{
					bool flag3 = !(tool.Spec is HistogramColorToolSpec);
					if (flag3)
					{
						tool.Spec = SettingToolFactory.CreateDefaultSpec(ToolType.HistogramColor);
					}
					HistogramColorParameterPanelViewModel histogramColorVm = new HistogramColorParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as HistogramColorToolConfig),
						Spec = (tool.Spec as HistogramColorToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					histogramColorVm.RestoreSelectedSourceTool();
					return new HistogramColor_para
					{
						DataContext = histogramColorVm
					};
				}
				case ToolType.FindCircle:
				{
					FindCircleParameterPanelViewModel findCircleVm = new FindCircleParameterPanelViewModel
					{
						Tool = tool,
						FindCircleConfig = (tool.Config as FindCircleToolConfig),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					findCircleVm.RestoreSelectedSourceTool();
					return new FindCircle_para
					{
						DataContext = findCircleVm
					};
				}
				case ToolType.FindLine:
				{
					FindLineParameterPanelViewModel findLineVm = new FindLineParameterPanelViewModel
					{
						Tool = tool,
						FindLineConfig = (tool.Config as FindLineToolConfig),
						FindLineSpec = (tool.Spec as FindLineToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					findLineVm.RestoreSelectedSourceTool();
					return new FindLine_para
					{
						DataContext = findLineVm
					};
				}
				case ToolType.Shape_model:
				{
					ShapeModelParameterPanelViewModel shapeModelVm = new ShapeModelParameterPanelViewModel
					{
						Tool = tool,
						ShapeModelConfig = (tool.Config as ShapeModelToolConfig),
						ShapeModelTrain = (tool.TrainModel as ShapeModelToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					shapeModelVm.RestoreSelectedSourceTool();
					return new Shape_model_para
					{
						DataContext = shapeModelVm
					};
				}
				case ToolType.AnisoShapeModel:
				{
					ShapeModelParameterPanelViewModel anisoShapeModelVm = new ShapeModelParameterPanelViewModel
					{
						Tool = tool,
						ShapeModelConfig = (tool.Config as AnisoShapeModelToolConfig),
						ShapeModelTrain = (tool.TrainModel as ShapeModelToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					anisoShapeModelVm.RestoreSelectedSourceTool();
					return new AnisoShape_model_para
					{
						DataContext = anisoShapeModelVm
					};
				}
				case ToolType.OverlappingShapeModel:
				{
					ShapeModelParameterPanelViewModel overlappingVm = new ShapeModelParameterPanelViewModel
					{
						Tool = tool,
						ShapeModelConfig = (tool.Config as OverlappingShapeModelToolConfig),
						ShapeModelTrain = (tool.TrainModel as ShapeModelToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					overlappingVm.RestoreSelectedSourceTool();
					return new Overlapping_shape_model_para
					{
						DataContext = overlappingVm
					};
				}
				case ToolType.ImageFilter:
				{
					ImageFilterParameterPanelViewModel filterVm = new ImageFilterParameterPanelViewModel
					{
						Tool = tool,
						FilterConfig = (tool.Config as ImageFilterToolConfig),
						FilterSpec = (tool.Spec as ImageFilterToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					filterVm.RestoreSelectedSourceTool();
					return new ImageFilter_para
					{
						DataContext = filterVm
					};
				}
				case ToolType.ImageTransform:
				{
					ImageTransformParameterPanelViewModel transformVm = new ImageTransformParameterPanelViewModel
					{
						Tool = tool,
						TransformConfig = (tool.Config as ImageTransformToolConfig),
						TransformSpec = (tool.Spec as ImageTransformToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					transformVm.RestoreSelectedSourceTool();
					return new ImageTransform_para
					{
						DataContext = transformVm
					};
				}
				case ToolType.SaveImage:
				{
					SaveImageParameterPanelViewModel saveImageVm = new SaveImageParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as SaveImageToolConfig),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					saveImageVm.RestoreSelectedSourceTool();
					saveImageVm.RefreshInspectionTools();
					return new SaveImage_para
					{
						DataContext = saveImageVm
					};
				}
				case ToolType.MatrixCode:
				{
					MatrixCodeParameterPanelViewModel matrixVm = new MatrixCodeParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as MatrixCodeToolConfig),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					matrixVm.RestoreSelectedSourceTool();
					return new MatrixCode_para
					{
						DataContext = matrixVm
					};
				}
				case ToolType.DistanceObject:
				{
					bool flag4 = !(tool.Spec is DistanceObjectToolSpec);
					if (flag4)
					{
						tool.Spec = SettingToolFactory.CreateDefaultSpec(ToolType.DistanceObject);
					}
					DistanceObjectParameterPanelViewModel distanceVm = new DistanceObjectParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as DistanceObjectToolConfig),
						Spec = (tool.Spec as DistanceObjectToolSpec),
						AvailableFindLineTools = this.GetPreviousMeasureObjectTools(tool)
					};
					distanceVm.RestoreSelections();
					return new DistanceObject_para
					{
						DataContext = distanceVm
					};
				}
				case ToolType.MeasureCircle:
				{
					bool flag5 = !(tool.Spec is MeasureCircleToolSpec);
					if (flag5)
					{
						tool.Spec = SettingToolFactory.CreateDefaultSpec(ToolType.MeasureCircle);
					}
					MeasureCircleParameterPanelViewModel measureCircleVm = new MeasureCircleParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as MeasureCircleToolConfig),
						Spec = (tool.Spec as MeasureCircleToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					measureCircleVm.RestoreSelectedSourceTool();
					return new MeasureCircle_para
					{
						DataContext = measureCircleVm
					};
				}
				case ToolType.CircleMaster:
				{
					CircleMasterParameterPanelViewModel circleMasterVm = new CircleMasterParameterPanelViewModel
					{
						Tool = tool,
						CircleMasterConfig = (tool.Config as CircleMasterToolConfig),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					circleMasterVm.RestoreSelectedSourceTool();
					return new CircleMaster_para
					{
						DataContext = circleMasterVm
					};
				}
				case ToolType.BoundingBoxMaster:
				{
					BoundingBoxMasterParameterPanelViewModel boundingBoxMasterVm = new BoundingBoxMasterParameterPanelViewModel
					{
						Tool = tool,
						BoundingBoxMasterConfig = (tool.Config as BoundingBoxMasterToolConfig),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					boundingBoxMasterVm.RestoreSelectedSourceTool();
					return new BoundingBoxMaster_para
					{
						DataContext = boundingBoxMasterVm
					};
				}
				case ToolType.MinAreaMaster:
				{
					MinAreaMasterParameterPanelViewModel minAreaMasterVm = new MinAreaMasterParameterPanelViewModel
					{
						Tool = tool,
						MinAreaMasterConfig = (tool.Config as MinAreaMasterToolConfig),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					minAreaMasterVm.RestoreSelectedSourceTool();
					return new MinAreaMaster_para
					{
						DataContext = minAreaMasterVm
					};
				}
				case ToolType.IntersectingLines:
				{
					IntersectingLinesParameterPanelViewModel intersectVm = new IntersectingLinesParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as IntersectingLinesToolConfig),
						AvailableFindLineTools = this.GetPreviousFindLineTools(tool)
					};
					intersectVm.RestoreSelections();
					return new IntersectingLines_para
					{
						DataContext = intersectVm
					};
				}
				case ToolType.AngleSelector:
				{
					AngleSelectorParameterPanelViewModel angleVm = new AngleSelectorParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as AngleSelectorToolConfig),
						AvailableObjectTools = this.GetPreviousAngleObjectTools(tool)
					};
					angleVm.RestoreSelections();
					return new AngleSelector_para
					{
						DataContext = angleVm
					};
				}
				case ToolType.FindBoundingBox:
				{
					FindBoundingBoxParameterPanelViewModel findBoundingBoxVm = new FindBoundingBoxParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as FindBoundingBoxToolConfig),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					findBoundingBoxVm.RestoreSelectedSourceTool();
					return new FindBoundingBox_para
					{
						DataContext = findBoundingBoxVm
					};
				}
				case ToolType.FindMinArea:
				{
					FindMinAreaParameterPanelViewModel findMinAreaVm = new FindMinAreaParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as FindMinAreaToolConfig),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					findMinAreaVm.RestoreSelectedSourceTool();
					return new FindMinArea_para
					{
						DataContext = findMinAreaVm
					};
				}
				case ToolType.CalibHandEye:
				{
					CalibHandEyeParameterPanelViewModel calibVm = new CalibHandEyeParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as CalibHandEyeToolConfig),
						AvailableMasterTools = this.GetPreviousCalibMasterTools(tool)
					};
					calibVm.RestoreSelection();
					return new CalibHandEye_para
					{
						DataContext = calibVm
					};
				}
				case ToolType.ResultAlign:
				{
					ResultAlignParameterPanelViewModel alignVm = new ResultAlignParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as CalibResultAlignToolConfig),
						AvailableCalibTools = this.GetPreviousCalibHandEyeTools(tool)
					};
					alignVm.Initialize();
					return new ResultAlign_para
					{
						DataContext = alignVm
					};
				}
				case ToolType.ResultInspection:
				{
					ResultInspectionParameterPanelViewModel inspectionVm = new ResultInspectionParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as CalibResultInspectionToolConfig),
						AvailableTools = this.GetPreviousInspectionTools(tool)
					};
					inspectionVm.Initialize();
					return new ResultInspection_para
					{
						DataContext = inspectionVm
					};
				}
				case ToolType.DeformableInspection:
				{
					DeformableInspectionParameterPanelViewModel deformableVm = new DeformableInspectionParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as DeformableInspectionToolConfig),
						Spec = (tool.Spec as DeformableInspectionToolSpec),
						Train = (tool.TrainModel as DeformableInspectionToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					deformableVm.RestoreSelectedSourceTool();
					return new DeformableInspection_para
					{
						DataContext = deformableVm
					};
				}
				case ToolType.VariationModel:
				{
					VariationModelParameterPanelViewModel variationVm = new VariationModelParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as VariationModelToolConfig),
						Spec = (tool.Spec as VariationModelToolSpec),
						Train = (tool.TrainModel as VariationModelToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					variationVm.RestoreSelectedSourceTool();
					return new VariationModel_para
					{
						DataContext = variationVm
					};
				}
				case ToolType.DLObjectInspection:
				{
					DLObjectInspectionParameterPanelViewModel dlVm = new DLObjectInspectionParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as DLObjectInspectionToolConfig),
						Spec = (tool.Spec as DLObjectInspectionToolSpec),
						Train = (tool.TrainModel as DLObjectInspectionToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					dlVm.RestoreSelectedSourceTool();
					return new DLObjectInspection_para
					{
						DataContext = dlVm
					};
				}
				case ToolType.VariationChangeWD:
				{
					VariationChangeWDParameterPanelViewModel changeWdVm = new VariationChangeWDParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as VariationChangeWDToolConfig),
						Spec = (tool.Spec as VariationChangeWDToolSpec),
						Train = (tool.TrainModel as VariationChangeWDToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					changeWdVm.RestoreSelectedSourceTool();
					return new VariationChangeWD_para
					{
						DataContext = changeWdVm
					};
				}
				case ToolType.ProductCountInspection:
				{
					ProductCountInspectionParameterPanelViewModel countVm = new ProductCountInspectionParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as ProductCountInspectionToolConfig),
						Spec = (tool.Spec as ProductCountInspectionToolSpec),
						Train = (tool.TrainModel as ProductCountInspectionToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					countVm.RestoreSelectedSourceTool();
					return new ProductCountInspection_para
					{
						DataContext = countVm
					};
				}
				case ToolType.FindRedArrow:
				{
					FindRedArrowParameterPanelViewModel redArrowVm = new FindRedArrowParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as FindRedArrowToolConfig),
						Spec = (tool.Spec as FindRedArrowToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					redArrowVm.RestoreSelectedSourceTool();
					return new FindRedArrow_para
					{
						DataContext = redArrowVm
					};
				}
				case ToolType.CountBoundingBox:
				{
					CountBoundingBoxParameterPanelViewModel countBoxVm = new CountBoundingBoxParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as CountBoundingBoxToolConfig),
						Spec = (tool.Spec as CountBoundingBoxToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					countBoxVm.RestoreSelectedSourceTool();
					return new CountBoundingBox_para
					{
						DataContext = countBoxVm
					};
				}
				case ToolType.ProcedureInspection:
				{
					ProcedureInspectionParameterPanelViewModel procedureVm = new ProcedureInspectionParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as ProcedureInspectionToolConfig),
						Spec = (tool.Spec as ProcedureInspectionToolSpec),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					procedureVm.RestoreSelectedSourceTool();
					return new ProcedureInspection_para
					{
						DataContext = procedureVm
					};
				}
				case ToolType.ProcedureModel:
				{
					ProcedureModelParameterPanelViewModel modelVm = new ProcedureModelParameterPanelViewModel
					{
						Tool = tool,
						Config = (tool.Config as ProcedureModelToolConfig),
						Train = (tool.TrainModel as ProcedureModelToolTrain),
						AvailableImageOutputTools = this.GetPreviousImageOutputTools(tool)
					};
					modelVm.RestoreSelectedSourceTool();
					return new ProcedureModel_para
					{
						DataContext = modelVm
					};
				}
				}
				result = null;
			}
			return result;
		}
	}
}
