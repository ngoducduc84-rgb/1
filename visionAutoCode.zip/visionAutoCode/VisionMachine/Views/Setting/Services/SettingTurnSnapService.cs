﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using DevExpress.Xpf.Core;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Tool;
using VisionMachine.Services;
using VisionMachine.ViewModels.Main;
using VisionMachine.Views.Calibration.ViewModels;
using VisionMachine.Views.Main;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.Blob;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindMinArea;
using VisionMachine.VisionTools.Histogram;
using VisionMachine.VisionTools.HistogramColor;
using VisionMachine.VisionTools.ImageFilter;
using VisionMachine.VisionTools.ImageTransform;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ProductCountInspection;
using VisionMachine.VisionTools.Runtime;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.Views.Setting.Services
{
	// Token: 0x020001B5 RID: 437
	public class SettingTurnSnapService
	{
		// Token: 0x060018EE RID: 6382 RVA: 0x000808D8 File Offset: 0x0007EAD8
		public TurnSnap GetSelectedTurnSnap()
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag = ((vm != null) ? vm.SelectedCamera : null) == null;
			TurnSnap result;
			if (flag)
			{
				result = null;
			}
			else
			{
				ToolVision selectedTool = vm.SelectedTool;
				bool flag2 = ((selectedTool != null) ? selectedTool.ParentTurnSnap : null) != null;
				if (flag2)
				{
					result = vm.SelectedTool.ParentTurnSnap;
				}
				else
				{
					result = vm.SelectedCamera.TurnSnaps.FirstOrDefault((TurnSnap x) => x.IsSelected);
				}
			}
			return result;
		}

		// Token: 0x060018EF RID: 6383 RVA: 0x00080964 File Offset: 0x0007EB64
		public void AddTurnSnap()
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag = ((vm != null) ? vm.SelectedCamera : null) == null;
			if (!flag)
			{
				vm.SelectedCamera.TurnSnaps.Add(new TurnSnap
				{
					Index = vm.SelectedCamera.TurnSnaps.Count + 1,
					ParentCamera = vm.SelectedCamera
				});
			}
		}

		// Token: 0x060018F0 RID: 6384 RVA: 0x000809D0 File Offset: 0x0007EBD0
		public void SelectTurnSnap(TurnSnap selectedTurnSnap)
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag = ((vm != null) ? vm.SelectedCamera : null) == null || selectedTurnSnap == null;
			if (!flag)
			{
				foreach (TurnSnap turnSnap in vm.SelectedCamera.TurnSnaps)
				{
					turnSnap.IsSelected = false;
					foreach (ToolVision tool in turnSnap.Tools)
					{
						tool.IsSelected = false;
					}
				}
				selectedTurnSnap.IsSelected = true;
				vm.SelectedTool = null;
				vm.CurrentParameterView = null;
			}
		}

		// Token: 0x060018F1 RID: 6385 RVA: 0x00080AB0 File Offset: 0x0007ECB0
		public void DeleteTurnSnap(TurnSnap turnSnap)
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag = ((vm != null) ? vm.SelectedCamera : null) == null || turnSnap == null;
			if (!flag)
			{
				vm.SelectedCamera.TurnSnaps.Remove(turnSnap);
				for (int i = 0; i < vm.SelectedCamera.TurnSnaps.Count; i++)
				{
					vm.SelectedCamera.TurnSnaps[i].Index = i + 1;
				}
				vm.SelectedTool = null;
				vm.CurrentParameterView = null;
				this.NotifyCalibHandEyeOptionsChanged();
			}
		}

		// Token: 0x060018F2 RID: 6386 RVA: 0x00080B48 File Offset: 0x0007ED48
		public void MoveTurnSnap(TurnSnap turnSnap, int newIndex)
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag;
			if (vm == null)
			{
				flag = (null != null);
			}
			else
			{
				CameraNode selectedCamera = vm.SelectedCamera;
				flag = (((selectedCamera != null) ? selectedCamera.TurnSnaps : null) != null);
			}
			bool flag2 = !flag || turnSnap == null;
			if (!flag2)
			{
				ObservableCollection<TurnSnap> turnSnaps = vm.SelectedCamera.TurnSnaps;
				int oldIndex = turnSnaps.IndexOf(turnSnap);
				bool flag3 = oldIndex < 0;
				if (!flag3)
				{
					bool flag4 = newIndex < 0;
					if (flag4)
					{
						newIndex = 0;
					}
					bool flag5 = newIndex >= turnSnaps.Count;
					if (flag5)
					{
						newIndex = turnSnaps.Count - 1;
					}
					bool flag6 = oldIndex == newIndex;
					if (!flag6)
					{
						SettingMasterImageService masterService = new SettingMasterImageService();
						Dictionary<TurnSnap, string> tempFolders = new Dictionary<TurnSnap, string>();
						foreach (TurnSnap ts in turnSnaps)
						{
							string oldFolder = masterService.BuildTurnSnapFolderPath(ts);
							bool flag7 = string.IsNullOrEmpty(oldFolder) || !Directory.Exists(oldFolder);
							if (!flag7)
							{
								string temp = oldFolder + "__reorder_" + Guid.NewGuid().ToString("N");
								try
								{
									Directory.Move(oldFolder, temp);
									tempFolders[ts] = temp;
								}
								catch
								{
								}
							}
						}
						turnSnaps.Move(oldIndex, newIndex);
						for (int i = 0; i < turnSnaps.Count; i++)
						{
							turnSnaps[i].Index = i + 1;
						}
						foreach (TurnSnap ts2 in turnSnaps)
						{
							string temp2;
							bool flag8 = !tempFolders.TryGetValue(ts2, out temp2);
							if (!flag8)
							{
								string newFolder = masterService.BuildTurnSnapFolderPath(ts2);
								try
								{
									bool flag9 = string.IsNullOrEmpty(newFolder);
									if (!flag9)
									{
										bool flag10 = Directory.Exists(newFolder);
										if (flag10)
										{
											Directory.Delete(newFolder, true);
										}
										string parent = Path.GetDirectoryName(newFolder);
										bool flag11 = !string.IsNullOrEmpty(parent);
										if (flag11)
										{
											Directory.CreateDirectory(parent);
										}
										Directory.Move(temp2, newFolder);
									}
								}
								catch
								{
								}
							}
						}
						this.NotifyCalibHandEyeOptionsChanged();
					}
				}
			}
		}

		// Token: 0x060018F3 RID: 6387 RVA: 0x00080DAC File Offset: 0x0007EFAC
		public void DeleteTool(ToolVision tool)
		{
			MainViewModel vm = MainWindow.instance.MainViewModel;
			bool flag = ((vm != null) ? vm.SelectedCamera : null) == null || tool == null;
			if (!flag)
			{
				TurnSnap turnSnap = vm.SelectedCamera.TurnSnaps.FirstOrDefault((TurnSnap ts) => ts.Tools.Contains(tool));
				bool flag2 = turnSnap == null;
				if (!flag2)
				{
					ToolDependencyService dependencyService = new ToolDependencyService();
					List<ToolVision> linkedTools = dependencyService.FindToolsUsingSource(turnSnap, tool);
					bool flag3 = linkedTools.Count > 0;
					if (flag3)
					{
						MessageBoxResult result = DXMessageBox.Show("This tool is currently used as an input source by another tool.\nIf you delete it, linked tools will be reset to OriginalImage.\n\nDo you want to continue?", "Delete Linked Tool", MessageBoxButton.YesNo, MessageBoxImage.Exclamation);
						bool flag4 = result != MessageBoxResult.Yes;
						if (flag4)
						{
							return;
						}
						dependencyService.ResetLinksToOriginalImage(turnSnap, tool);
					}
					this.DeleteShapeModelFile(tool);
					ShapeModelRuntimeCache.ClearByTool(tool.ToolId.ToString());
					turnSnap.Tools.Remove(tool);
					for (int i = 0; i < turnSnap.Tools.Count; i++)
					{
						turnSnap.Tools[i].Index = i + 1;
					}
					vm.SelectedTool = null;
					vm.CurrentParameterView = null;
					this.NotifyCalibHandEyeOptionsChanged();
				}
			}
		}

		// Token: 0x060018F4 RID: 6388 RVA: 0x00080F04 File Offset: 0x0007F104
		public void AddToolToTurnSnap(ToolVision draggedTool, TurnSnap turnSnap)
		{
			bool flag = draggedTool == null || turnSnap == null;
			if (!flag)
			{
				ToolVision newTool = SettingToolFactory.CreateToolFromTemplate(draggedTool, turnSnap);
				newTool.ParentTurnSnap = turnSnap;
				turnSnap.Tools.Add(newTool);
				this.UpdateToolOrder(turnSnap);
				this.NotifyCalibHandEyeOptionsChanged();
			}
		}

		// Token: 0x060018F5 RID: 6389 RVA: 0x00080F50 File Offset: 0x0007F150
		private void DeleteShapeModelFile(ToolVision tool)
		{
			bool flag = tool == null;
			if (!flag)
			{
				ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (!flag2)
				{
					bool flag3 = string.IsNullOrWhiteSpace(train.ShapeModelRelativePath);
					if (!flag3)
					{
						SettingMasterImageService masterService = new SettingMasterImageService();
						string turnSnapFolder = masterService.GetTurnSnapFolder(tool.ParentTurnSnap);
						string fullPath = Path.Combine(turnSnapFolder, train.ShapeModelRelativePath);
						bool flag4 = File.Exists(fullPath);
						if (flag4)
						{
							try
							{
								File.Delete(fullPath);
							}
							catch
							{
							}
						}
					}
				}
			}
		}

		// Token: 0x060018F6 RID: 6390 RVA: 0x00080FE4 File Offset: 0x0007F1E4
		public void MoveTool(TurnSnap turnSnap, ToolVision tool, int newIndex)
		{
			bool flag = turnSnap == null || tool == null;
			if (!flag)
			{
				ObservableCollection<ToolVision> tools = turnSnap.Tools;
				int oldIndex = tools.IndexOf(tool);
				bool flag2 = oldIndex < 0;
				if (!flag2)
				{
					bool flag3 = newIndex < 0;
					if (flag3)
					{
						newIndex = 0;
					}
					bool flag4 = newIndex >= tools.Count;
					if (flag4)
					{
						newIndex = tools.Count - 1;
					}
					bool flag5 = oldIndex == newIndex;
					if (!flag5)
					{
						tools.Move(oldIndex, newIndex);
						this.UpdateToolOrder(turnSnap);
						this.NotifyCalibHandEyeOptionsChanged();
					}
				}
			}
		}

		// Token: 0x060018F7 RID: 6391 RVA: 0x00081068 File Offset: 0x0007F268
		public void UpdateToolOrder(TurnSnap turnSnap)
		{
			bool flag = turnSnap == null || turnSnap.Tools == null;
			if (!flag)
			{
				for (int i = 0; i < turnSnap.Tools.Count; i++)
				{
					turnSnap.Tools[i].Index = i + 1;
					turnSnap.Tools[i].ParentTurnSnap = turnSnap;
				}
				this.NormalizeImageOutputSourceLinks(turnSnap);
			}
		}

		// Token: 0x060018F8 RID: 6392 RVA: 0x000810D7 File Offset: 0x0007F2D7
		private void NotifyCalibHandEyeOptionsChanged()
		{
			CalibHandEyeOptionProvider.NotifyOptionsSourceChanged();
		}

		// Token: 0x060018F9 RID: 6393 RVA: 0x000810E0 File Offset: 0x0007F2E0
		private void NormalizeImageOutputSourceLinks(TurnSnap turnSnap)
		{
			bool flag = turnSnap == null || turnSnap.Tools == null;
			if (!flag)
			{
				using (IEnumerator<ToolVision> enumerator = turnSnap.Tools.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						SettingTurnSnapService.<>c__DisplayClass11_0 CS$<>8__locals1 = new SettingTurnSnapService.<>c__DisplayClass11_0();
						CS$<>8__locals1.<>4__this = this;
						CS$<>8__locals1.tool = enumerator.Current;
						ImageInputLink link = this.GetInputLink(CS$<>8__locals1.tool);
						bool flag2 = link != null && string.IsNullOrWhiteSpace(link.SourceToolName) && !string.IsNullOrWhiteSpace(link.SourceToolId);
						if (flag2)
						{
							ToolVision legacySourceTool = turnSnap.Tools.FirstOrDefault((ToolVision x) => (x.ToolId == link.SourceToolId || x.Name == link.SourceToolId) && CS$<>8__locals1.<>4__this.IsImageOutputTool(x));
							bool flag3 = legacySourceTool != null;
							if (flag3)
							{
								link.SourceToolName = legacySourceTool.Name;
							}
						}
						bool flag4 = link == null || link.SourceType != ImageInputSourceType.ToolOutput || string.IsNullOrWhiteSpace(link.SourceToolName);
						if (!flag4)
						{
							ToolVision sourceTool = turnSnap.Tools.TakeWhile((ToolVision x) => x != CS$<>8__locals1.tool).FirstOrDefault((ToolVision x) => x.Name == link.SourceToolName && CS$<>8__locals1.<>4__this.IsImageOutputTool(x));
							bool flag5 = sourceTool == null;
							if (flag5)
							{
								link.SourceType = ImageInputSourceType.OriginalImage;
								link.SourceToolId = null;
								link.SourceToolName = null;
							}
							else
							{
								link.SourceToolId = null;
								link.SourceToolName = sourceTool.Name;
							}
						}
					}
				}
			}
		}

		// Token: 0x060018FA RID: 6394 RVA: 0x000812B4 File Offset: 0x0007F4B4
		private bool IsImageOutputTool(ToolVision tool)
		{
			bool flag = tool == null;
			return !flag && (tool.ToolType == ToolType.ImageFilter || tool.ToolType == ToolType.ImageTransform);
		}

		// Token: 0x060018FB RID: 6395 RVA: 0x000812EC File Offset: 0x0007F4EC
		private ImageInputLink GetInputLink(ToolVision tool)
		{
			bool flag = tool == null;
			ImageInputLink result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool flag2 = tool.ToolType == ToolType.ImageFilter;
				if (flag2)
				{
					ImageFilterToolConfig config = tool.Config as ImageFilterToolConfig;
					result = ((config != null) ? config.InputLink : null);
				}
				else
				{
					bool flag3 = tool.ToolType == ToolType.Shape_model;
					if (flag3)
					{
						ShapeModelToolConfig config2 = tool.Config as ShapeModelToolConfig;
						result = ((config2 != null) ? config2.InputLink : null);
					}
					else
					{
						bool flag4 = tool.ToolType == ToolType.AnisoShapeModel;
						if (flag4)
						{
							AnisoShapeModelToolConfig config3 = tool.Config as AnisoShapeModelToolConfig;
							result = ((config3 != null) ? config3.InputLink : null);
						}
						else
						{
							bool flag5 = tool.ToolType == ToolType.OverlappingShapeModel;
							if (flag5)
							{
								OverlappingShapeModelToolConfig config4 = tool.Config as OverlappingShapeModelToolConfig;
								result = ((config4 != null) ? config4.InputLink : null);
							}
							else
							{
								bool flag6 = tool.ToolType == ToolType.ImageTransform;
								if (flag6)
								{
									ImageTransformToolConfig config5 = tool.Config as ImageTransformToolConfig;
									result = ((config5 != null) ? config5.InputLink : null);
								}
								else
								{
									bool flag7 = tool.ToolType == ToolType.Blob;
									if (flag7)
									{
										BlobToolConfig config6 = tool.Config as BlobToolConfig;
										result = ((config6 != null) ? config6.InputLink : null);
									}
									else
									{
										bool flag8 = tool.ToolType == ToolType.Histogram;
										if (flag8)
										{
											HistogramToolConfig config7 = tool.Config as HistogramToolConfig;
											result = ((config7 != null) ? config7.InputLink : null);
										}
										else
										{
											bool flag9 = tool.ToolType == ToolType.HistogramColor;
											if (flag9)
											{
												HistogramColorToolConfig config8 = tool.Config as HistogramColorToolConfig;
												result = ((config8 != null) ? config8.InputLink : null);
											}
											else
											{
												bool flag10 = tool.ToolType == ToolType.FindBoundingBox;
												if (flag10)
												{
													FindBoundingBoxToolConfig config9 = tool.Config as FindBoundingBoxToolConfig;
													result = ((config9 != null) ? config9.InputLink : null);
												}
												else
												{
													bool flag11 = tool.ToolType == ToolType.FindMinArea;
													if (flag11)
													{
														FindMinAreaToolConfig config10 = tool.Config as FindMinAreaToolConfig;
														result = ((config10 != null) ? config10.InputLink : null);
													}
													else
													{
														bool flag12 = tool.ToolType == ToolType.MinAreaMaster;
														if (flag12)
														{
															MinAreaMasterToolConfig config11 = tool.Config as MinAreaMasterToolConfig;
															result = ((config11 != null) ? config11.InputLink : null);
														}
														else
														{
															bool flag13 = tool.ToolType == ToolType.ProductCountInspection;
															if (flag13)
															{
																ProductCountInspectionToolConfig config12 = tool.Config as ProductCountInspectionToolConfig;
																result = ((config12 != null) ? config12.InputLink : null);
															}
															else
															{
																result = null;
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			return result;
		}
	}
}
