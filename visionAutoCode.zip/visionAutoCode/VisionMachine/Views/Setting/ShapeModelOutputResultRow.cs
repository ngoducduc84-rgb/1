﻿using System;
using System.Windows.Media;

namespace VisionMachine.Views.Setting
{
	// Token: 0x0200019E RID: 414
	public class ShapeModelOutputResultRow
	{
		// Token: 0x170007A2 RID: 1954
		// (get) Token: 0x060015B2 RID: 5554 RVA: 0x00067DBB File Offset: 0x00065FBB
		// (set) Token: 0x060015B3 RID: 5555 RVA: 0x00067DC3 File Offset: 0x00065FC3
		public string RoiName { get; set; }

		// Token: 0x170007A3 RID: 1955
		// (get) Token: 0x060015B4 RID: 5556 RVA: 0x00067DCC File Offset: 0x00065FCC
		// (set) Token: 0x060015B5 RID: 5557 RVA: 0x00067DD4 File Offset: 0x00065FD4
		public int MatchIndex { get; set; }

		// Token: 0x170007A4 RID: 1956
		// (get) Token: 0x060015B6 RID: 5558 RVA: 0x00067DDD File Offset: 0x00065FDD
		// (set) Token: 0x060015B7 RID: 5559 RVA: 0x00067DE5 File Offset: 0x00065FE5
		public int MatchRow { get; set; }

		// Token: 0x170007A5 RID: 1957
		// (get) Token: 0x060015B8 RID: 5560 RVA: 0x00067DEE File Offset: 0x00065FEE
		// (set) Token: 0x060015B9 RID: 5561 RVA: 0x00067DF6 File Offset: 0x00065FF6
		public int MatchColumn { get; set; }

		// Token: 0x170007A6 RID: 1958
		// (get) Token: 0x060015BA RID: 5562 RVA: 0x00067DFF File Offset: 0x00065FFF
		// (set) Token: 0x060015BB RID: 5563 RVA: 0x00067E07 File Offset: 0x00066007
		public string Picked { get; set; }

		// Token: 0x170007A7 RID: 1959
		// (get) Token: 0x060015BC RID: 5564 RVA: 0x00067E10 File Offset: 0x00066010
		// (set) Token: 0x060015BD RID: 5565 RVA: 0x00067E18 File Offset: 0x00066018
		public string Layer { get; set; }

		// Token: 0x170007A8 RID: 1960
		// (get) Token: 0x060015BE RID: 5566 RVA: 0x00067E21 File Offset: 0x00066021
		// (set) Token: 0x060015BF RID: 5567 RVA: 0x00067E29 File Offset: 0x00066029
		public int Rank { get; set; }

		// Token: 0x170007A9 RID: 1961
		// (get) Token: 0x060015C0 RID: 5568 RVA: 0x00067E32 File Offset: 0x00066032
		// (set) Token: 0x060015C1 RID: 5569 RVA: 0x00067E3A File Offset: 0x0006603A
		public int ContactCount { get; set; }

		// Token: 0x170007AA RID: 1962
		// (get) Token: 0x060015C2 RID: 5570 RVA: 0x00067E43 File Offset: 0x00066043
		// (set) Token: 0x060015C3 RID: 5571 RVA: 0x00067E4B File Offset: 0x0006604B
		public double Row
		{
			get
			{
				return this._row;
			}
			set
			{
				this._row = Math.Round(value, 5);
			}
		}

		// Token: 0x170007AB RID: 1963
		// (get) Token: 0x060015C4 RID: 5572 RVA: 0x00067E5A File Offset: 0x0006605A
		// (set) Token: 0x060015C5 RID: 5573 RVA: 0x00067E62 File Offset: 0x00066062
		public double Column
		{
			get
			{
				return this._column;
			}
			set
			{
				this._column = Math.Round(value, 5);
			}
		}

		// Token: 0x170007AC RID: 1964
		// (get) Token: 0x060015C6 RID: 5574 RVA: 0x00067E71 File Offset: 0x00066071
		// (set) Token: 0x060015C7 RID: 5575 RVA: 0x00067E79 File Offset: 0x00066079
		public double Angle
		{
			get
			{
				return this._angle;
			}
			set
			{
				this._angle = Math.Round(value, 5);
			}
		}

		// Token: 0x170007AD RID: 1965
		// (get) Token: 0x060015C8 RID: 5576 RVA: 0x00067E88 File Offset: 0x00066088
		// (set) Token: 0x060015C9 RID: 5577 RVA: 0x00067E90 File Offset: 0x00066090
		public double? DeltaRow
		{
			get
			{
				return this._deltaRow;
			}
			set
			{
				this._deltaRow = ((value != null) ? new double?(Math.Round(value.Value, 5)) : null);
			}
		}

		// Token: 0x170007AE RID: 1966
		// (get) Token: 0x060015CA RID: 5578 RVA: 0x00067EC9 File Offset: 0x000660C9
		// (set) Token: 0x060015CB RID: 5579 RVA: 0x00067ED4 File Offset: 0x000660D4
		public double? DeltaColumn
		{
			get
			{
				return this._deltaColumn;
			}
			set
			{
				this._deltaColumn = ((value != null) ? new double?(Math.Round(value.Value, 5)) : null);
			}
		}

		// Token: 0x170007AF RID: 1967
		// (get) Token: 0x060015CC RID: 5580 RVA: 0x00067F0D File Offset: 0x0006610D
		// (set) Token: 0x060015CD RID: 5581 RVA: 0x00067F18 File Offset: 0x00066118
		public double? DeltaAngle
		{
			get
			{
				return this._deltaAngle;
			}
			set
			{
				this._deltaAngle = ((value != null) ? new double?(Math.Round(value.Value, 5)) : null);
			}
		}

		// Token: 0x170007B0 RID: 1968
		// (get) Token: 0x060015CE RID: 5582 RVA: 0x00067F51 File Offset: 0x00066151
		// (set) Token: 0x060015CF RID: 5583 RVA: 0x00067F59 File Offset: 0x00066159
		public double Score
		{
			get
			{
				return this._score;
			}
			set
			{
				this._score = Math.Round(value, 5);
			}
		}

		// Token: 0x170007B1 RID: 1969
		// (get) Token: 0x060015D0 RID: 5584 RVA: 0x00067F68 File Offset: 0x00066168
		// (set) Token: 0x060015D1 RID: 5585 RVA: 0x00067F70 File Offset: 0x00066170
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170007B2 RID: 1970
		// (get) Token: 0x060015D2 RID: 5586 RVA: 0x00067F79 File Offset: 0x00066179
		// (set) Token: 0x060015D3 RID: 5587 RVA: 0x00067F81 File Offset: 0x00066181
		public string InputSourceToolName { get; set; }

		// Token: 0x170007B3 RID: 1971
		// (get) Token: 0x060015D4 RID: 5588 RVA: 0x00067F8A File Offset: 0x0006618A
		// (set) Token: 0x060015D5 RID: 5589 RVA: 0x00067F92 File Offset: 0x00066192
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x170007B4 RID: 1972
		// (get) Token: 0x060015D6 RID: 5590 RVA: 0x00067F9B File Offset: 0x0006619B
		// (set) Token: 0x060015D7 RID: 5591 RVA: 0x00067FA3 File Offset: 0x000661A3
		public Brush RowBrush { get; set; } = Brushes.Transparent;

		// Token: 0x170007B5 RID: 1973
		// (get) Token: 0x060015D8 RID: 5592 RVA: 0x00067FAC File Offset: 0x000661AC
		// (set) Token: 0x060015D9 RID: 5593 RVA: 0x00067FB4 File Offset: 0x000661B4
		public Brush TextBrush { get; set; } = Brushes.White;

		// Token: 0x04000915 RID: 2325
		private const int DisplayDecimals = 5;

		// Token: 0x04000916 RID: 2326
		private double _row;

		// Token: 0x04000917 RID: 2327
		private double _column;

		// Token: 0x04000918 RID: 2328
		private double _angle;

		// Token: 0x04000919 RID: 2329
		private double? _deltaRow;

		// Token: 0x0400091A RID: 2330
		private double? _deltaColumn;

		// Token: 0x0400091B RID: 2331
		private double? _deltaAngle;

		// Token: 0x0400091C RID: 2332
		private double _score;
	}
}
