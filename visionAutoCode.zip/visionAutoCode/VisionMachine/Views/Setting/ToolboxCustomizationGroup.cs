﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;

namespace VisionMachine.Views.Setting
{
	// Token: 0x0200019B RID: 411
	public class ToolboxCustomizationGroup : INotifyPropertyChanged
	{
		// Token: 0x17000792 RID: 1938
		// (get) Token: 0x06001582 RID: 5506 RVA: 0x00067501 File Offset: 0x00065701
		// (set) Token: 0x06001583 RID: 5507 RVA: 0x00067509 File Offset: 0x00065709
		public string Name { get; set; }

		// Token: 0x17000793 RID: 1939
		// (get) Token: 0x06001584 RID: 5508 RVA: 0x00067512 File Offset: 0x00065712
		public ObservableCollection<ToolboxCustomizationItem> Tools { get; } = new ObservableCollection<ToolboxCustomizationItem>();

		// Token: 0x17000794 RID: 1940
		// (get) Token: 0x06001585 RID: 5509 RVA: 0x0006751C File Offset: 0x0006571C
		// (set) Token: 0x06001586 RID: 5510 RVA: 0x000675C4 File Offset: 0x000657C4
		public bool? IsChecked
		{
			get
			{
				bool flag = this.Tools.Count == 0;
				bool? result;
				if (flag)
				{
					result = new bool?(false);
				}
				else
				{
					bool flag2 = this.Tools.All((ToolboxCustomizationItem x) => x.IsVisible);
					if (flag2)
					{
						result = new bool?(true);
					}
					else
					{
						bool flag3 = this.Tools.All((ToolboxCustomizationItem x) => !x.IsVisible);
						if (flag3)
						{
							result = new bool?(false);
						}
						else
						{
							result = null;
						}
					}
				}
				return result;
			}
			set
			{
				bool flag = this._isUpdatingFromChildren || value == null;
				if (!flag)
				{
					foreach (ToolboxCustomizationItem tool in this.Tools)
					{
						tool.IsVisible = value.Value;
					}
					this.OnPropertyChanged("IsChecked");
				}
			}
		}

		// Token: 0x06001587 RID: 5511 RVA: 0x00067644 File Offset: 0x00065844
		public void RefreshCheckedFromChildren()
		{
			this._isUpdatingFromChildren = true;
			try
			{
				this.OnPropertyChanged("IsChecked");
			}
			finally
			{
				this._isUpdatingFromChildren = false;
			}
		}

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x06001588 RID: 5512 RVA: 0x00067684 File Offset: 0x00065884
		// (remove) Token: 0x06001589 RID: 5513 RVA: 0x000676BC File Offset: 0x000658BC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x0600158A RID: 5514 RVA: 0x000676F1 File Offset: 0x000658F1
		private void OnPropertyChanged([CallerMemberName] string name = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		// Token: 0x04000900 RID: 2304
		private bool _isUpdatingFromChildren;
	}
}
