﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.Views.Setting
{
	// Token: 0x0200019A RID: 410
	public class ToolboxCustomizationItem : INotifyPropertyChanged
	{
		// Token: 0x1700078F RID: 1935
		// (get) Token: 0x06001578 RID: 5496 RVA: 0x000673EB File Offset: 0x000655EB
		// (set) Token: 0x06001579 RID: 5497 RVA: 0x000673F3 File Offset: 0x000655F3
		public string Name { get; set; }

		// Token: 0x17000790 RID: 1936
		// (get) Token: 0x0600157A RID: 5498 RVA: 0x000673FC File Offset: 0x000655FC
		// (set) Token: 0x0600157B RID: 5499 RVA: 0x00067414 File Offset: 0x00065614
		public bool IsVisible
		{
			get
			{
				return this._isVisible;
			}
			set
			{
				bool flag = this._isVisible == value;
				if (!flag)
				{
					this._isVisible = value;
					this.OnPropertyChanged("IsVisible");
					Action visibilityChanged = this.VisibilityChanged;
					if (visibilityChanged != null)
					{
						visibilityChanged();
					}
				}
			}
		}

		// Token: 0x17000791 RID: 1937
		// (get) Token: 0x0600157C RID: 5500 RVA: 0x00067456 File Offset: 0x00065656
		// (set) Token: 0x0600157D RID: 5501 RVA: 0x0006745E File Offset: 0x0006565E
		public Action VisibilityChanged { get; set; }

		// Token: 0x14000025 RID: 37
		// (add) Token: 0x0600157E RID: 5502 RVA: 0x00067468 File Offset: 0x00065668
		// (remove) Token: 0x0600157F RID: 5503 RVA: 0x000674A0 File Offset: 0x000656A0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06001580 RID: 5504 RVA: 0x000674D5 File Offset: 0x000656D5
		private void OnPropertyChanged([CallerMemberName] string name = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(name));
			}
		}

		// Token: 0x040008FC RID: 2300
		private bool _isVisible = true;
	}
}
