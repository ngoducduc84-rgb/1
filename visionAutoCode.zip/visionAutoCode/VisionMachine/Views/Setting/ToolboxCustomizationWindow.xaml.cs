﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Tool;

namespace VisionMachine.Views.Setting
{
	// Token: 0x0200019C RID: 412
	public partial class ToolboxCustomizationWindow : ThemedWindow
	{
		// Token: 0x0600158C RID: 5516 RVA: 0x00067721 File Offset: 0x00065921
		public ToolboxCustomizationWindow(IEnumerable<ToolVision> catalog)
		{
			this.InitializeComponent();
			this.Build(catalog);
			this.GroupList.ItemsSource = this._groups;
			this.UpdateSummary();
		}

		// Token: 0x0600158D RID: 5517 RVA: 0x00067760 File Offset: 0x00065960
		private void Build(IEnumerable<ToolVision> catalog)
		{
			HashSet<string> hidden = ToolboxVisibilityService.GetHidden();
			foreach (ToolVision category in (catalog ?? Enumerable.Empty<ToolVision>()))
			{
				bool flag = category == null || string.IsNullOrWhiteSpace(category.Name);
				if (!flag)
				{
					ToolboxCustomizationGroup group = new ToolboxCustomizationGroup
					{
						Name = category.Name
					};
					List<ToolVision> children = new List<ToolVision>();
					ToolboxCustomizationWindow.CollectTools(category, children);
					Action <>9__0;
					foreach (ToolVision tool in children)
					{
						bool flag2 = tool == null || string.IsNullOrWhiteSpace(tool.Name);
						if (!flag2)
						{
							ToolboxCustomizationItem item = new ToolboxCustomizationItem
							{
								Name = tool.Name,
								IsVisible = !hidden.Contains(tool.Name)
							};
							ToolboxCustomizationItem toolboxCustomizationItem = item;
							Action visibilityChanged;
							if ((visibilityChanged = <>9__0) == null)
							{
								visibilityChanged = (<>9__0 = delegate()
								{
									group.RefreshCheckedFromChildren();
									this.UpdateSummary();
								});
							}
							toolboxCustomizationItem.VisibilityChanged = visibilityChanged;
							group.Tools.Add(item);
						}
					}
					bool flag3 = group.Tools.Count > 0;
					if (flag3)
					{
						this._groups.Add(group);
					}
				}
			}
		}

		// Token: 0x0600158E RID: 5518 RVA: 0x00067918 File Offset: 0x00065B18
		private static void CollectTools(ToolVision entry, List<ToolVision> target)
		{
			bool flag = entry == null;
			if (!flag)
			{
				bool flag2 = entry.Children == null || entry.Children.Count == 0;
				if (flag2)
				{
					target.Add(entry);
				}
				else
				{
					foreach (ToolVision child in entry.Children)
					{
						ToolboxCustomizationWindow.CollectTools(child, target);
					}
				}
			}
		}

		// Token: 0x0600158F RID: 5519 RVA: 0x0006799C File Offset: 0x00065B9C
		private void UpdateSummary()
		{
			int total = this._groups.Sum((ToolboxCustomizationGroup g) => g.Tools.Count);
			int visible = this._groups.Sum((ToolboxCustomizationGroup g) => g.Tools.Count((ToolboxCustomizationItem t) => t.IsVisible));
			this.SummaryText.Text = visible.ToString() + " of " + total.ToString() + " tools shown";
		}

		// Token: 0x06001590 RID: 5520 RVA: 0x00067A2C File Offset: 0x00065C2C
		private void SetAll(bool isVisible)
		{
			foreach (ToolboxCustomizationGroup group in this._groups)
			{
				foreach (ToolboxCustomizationItem tool in group.Tools)
				{
					tool.IsVisible = isVisible;
				}
				group.RefreshCheckedFromChildren();
			}
			this.UpdateSummary();
		}

		// Token: 0x06001591 RID: 5521 RVA: 0x00067AC4 File Offset: 0x00065CC4
		private void ShowAll_Click(object sender, RoutedEventArgs e)
		{
			this.SetAll(true);
		}

		// Token: 0x06001592 RID: 5522 RVA: 0x00067ACF File Offset: 0x00065CCF
		private void HideAll_Click(object sender, RoutedEventArgs e)
		{
			this.SetAll(false);
		}

		// Token: 0x06001593 RID: 5523 RVA: 0x00067ADC File Offset: 0x00065CDC
		private void Save_Click(object sender, RoutedEventArgs e)
		{
			List<string> hidden = (from t in this._groups.SelectMany((ToolboxCustomizationGroup g) => g.Tools)
			where !t.IsVisible
			select t.Name).ToList<string>();
			string error = ToolboxVisibilityService.Save(hidden);
			bool flag = error != null;
			if (flag)
			{
				DXMessageBox.Show(string.Concat(new string[]
				{
					"The toolbox layout could not be saved:",
					Environment.NewLine,
					error,
					Environment.NewLine,
					Environment.NewLine,
					"The toolbox will look right until the application is closed, but the change will be lost."
				}), "Toolbox Customization", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			base.DialogResult = new bool?(true);
			base.Close();
		}

		// Token: 0x06001594 RID: 5524 RVA: 0x00067BCC File Offset: 0x00065DCC
		private void Cancel_Click(object sender, RoutedEventArgs e)
		{
			base.DialogResult = new bool?(false);
			base.Close();
		}

		// Token: 0x04000904 RID: 2308
		private readonly ObservableCollection<ToolboxCustomizationGroup> _groups = new ObservableCollection<ToolboxCustomizationGroup>();
	}
}
