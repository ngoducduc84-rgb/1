﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace VisionMachine.Views.Startup
{
	// Token: 0x020001D0 RID: 464
	public sealed class StartupSplash
	{
		// Token: 0x06001C75 RID: 7285 RVA: 0x0009F4D8 File Offset: 0x0009D6D8
		public static StartupSplash Show()
		{
			StartupSplash splash = new StartupSplash();
			Thread thread = new Thread(new ThreadStart(splash.Run))
			{
				IsBackground = true,
				Name = "StartupSplash"
			};
			thread.SetApartmentState(ApartmentState.STA);
			thread.Start();
			splash._ready.Wait(3000);
			return splash;
		}

		// Token: 0x06001C76 RID: 7286 RVA: 0x0009F538 File Offset: 0x0009D738
		public void Close()
		{
			Dispatcher dispatcher = this._dispatcher;
			bool flag = dispatcher == null;
			if (!flag)
			{
				try
				{
					dispatcher.Invoke(delegate()
					{
						try
						{
							Window window = this._window;
							if (window != null)
							{
								window.Close();
							}
						}
						catch
						{
						}
					});
				}
				catch
				{
				}
				dispatcher.InvokeShutdown();
			}
		}

		// Token: 0x06001C77 RID: 7287 RVA: 0x0009F58C File Offset: 0x0009D78C
		private void Run()
		{
			this._dispatcher = Dispatcher.CurrentDispatcher;
			this._window = StartupSplash.BuildWindow();
			this._window.Loaded += delegate(object s, RoutedEventArgs e)
			{
				this._ready.Set();
			};
			this._window.Show();
			Dispatcher.Run();
		}

		// Token: 0x06001C78 RID: 7288 RVA: 0x0009F5DC File Offset: 0x0009D7DC
		private static Window BuildWindow()
		{
			Window window = new Window
			{
				Width = 430.0,
				Height = 300.0,
				WindowStyle = WindowStyle.None,
				ResizeMode = ResizeMode.NoResize,
				ShowInTaskbar = false,
				Topmost = true,
				WindowStartupLocation = WindowStartupLocation.CenterScreen,
				AllowsTransparency = false,
				Background = Brushes.White
			};
			Border rootBorder = new Border
			{
				BorderThickness = new Thickness(1.0),
				BorderBrush = new SolidColorBrush(Color.FromRgb(200, 208, 220))
			};
			Grid grid = new Grid
			{
				Background = new LinearGradientBrush(Color.FromRgb(byte.MaxValue, byte.MaxValue, byte.MaxValue), Color.FromRgb(236, 241, 247), new Point(0.0, 0.0), new Point(1.0, 1.0))
			};
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = new GridLength(1.0, GridUnitType.Star)
			});
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			Path swoosh = new Path
			{
				Fill = new SolidColorBrush(Color.FromArgb(34, 77, 124, byte.MaxValue)),
				Data = Geometry.Parse("M0,40 C140,120 300,0 430,70 L430,0 L0,0 Z"),
				Stretch = Stretch.Fill,
				Height = 150.0,
				VerticalAlignment = VerticalAlignment.Top
			};
			Grid.SetRow(swoosh, 0);
			grid.Children.Add(swoosh);
			TextBlock starting = new TextBlock
			{
				Text = "Starting...",
				FontSize = 14.0,
				Foreground = new SolidColorBrush(Color.FromRgb(51, 58, 69)),
				Margin = new Thickness(18.0, 0.0, 18.0, 6.0),
				VerticalAlignment = VerticalAlignment.Bottom
			};
			Grid.SetRow(starting, 1);
			grid.Children.Add(starting);
			ProgressBar progress = new ProgressBar
			{
				IsIndeterminate = true,
				Height = 16.0,
				Margin = new Thickness(18.0, 0.0, 18.0, 0.0),
				Foreground = new SolidColorBrush(Color.FromRgb(62, 111, 216)),
				Background = new SolidColorBrush(Color.FromRgb(221, 226, 234)),
				BorderThickness = new Thickness(0.0)
			};
			Grid.SetRow(progress, 2);
			grid.Children.Add(progress);
			Grid footer = new Grid
			{
				Margin = new Thickness(18.0, 14.0, 18.0, 16.0)
			};
			footer.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(1.0, GridUnitType.Star)
			});
			footer.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = GridLength.Auto
			});
			TextBlock copyright = new TextBlock
			{
				Text = "Copyright",
				FontSize = 12.0,
				Foreground = new SolidColorBrush(Color.FromRgb(85, 92, 102)),
				VerticalAlignment = VerticalAlignment.Center
			};
			Grid.SetColumn(copyright, 0);
			footer.Children.Add(copyright);
			TextBlock product = new TextBlock
			{
				Text = "VisionMachine",
				FontSize = 18.0,
				FontWeight = FontWeights.Bold,
				Foreground = new SolidColorBrush(Color.FromRgb(31, 92, 200)),
				VerticalAlignment = VerticalAlignment.Center
			};
			Grid.SetColumn(product, 1);
			footer.Children.Add(product);
			Grid.SetRow(footer, 3);
			grid.Children.Add(footer);
			rootBorder.Child = grid;
			window.Content = rootBorder;
			return window;
		}

		// Token: 0x04000BE6 RID: 3046
		private Window _window;

		// Token: 0x04000BE7 RID: 3047
		private Dispatcher _dispatcher;

		// Token: 0x04000BE8 RID: 3048
		private readonly ManualResetEventSlim _ready = new ManualResetEventSlim(false);
	}
}
