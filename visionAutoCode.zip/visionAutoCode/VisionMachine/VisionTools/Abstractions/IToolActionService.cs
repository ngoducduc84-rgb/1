﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x02000178 RID: 376
	public interface IToolActionService
	{
		// Token: 0x17000745 RID: 1861
		// (get) Token: 0x0600144F RID: 5199
		ToolType ToolType { get; }

		// Token: 0x06001450 RID: 5200
		void TrialRun(ToolActionContext context, ToolVision tool);
	}
}
