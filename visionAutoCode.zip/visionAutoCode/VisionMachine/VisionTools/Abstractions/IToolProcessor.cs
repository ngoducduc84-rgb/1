﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x02000179 RID: 377
	public interface IToolProcessor
	{
		// Token: 0x17000746 RID: 1862
		// (get) Token: 0x06001451 RID: 5201
		ToolType ToolType { get; }

		// Token: 0x06001452 RID: 5202
		ToolProcessResult Execute(ToolProcessContext context, ToolVision tool);
	}
}
