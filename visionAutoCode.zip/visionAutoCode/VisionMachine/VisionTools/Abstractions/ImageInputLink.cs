﻿using System;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x02000176 RID: 374
	public class ImageInputLink
	{
		// Token: 0x17000742 RID: 1858
		// (get) Token: 0x06001448 RID: 5192 RVA: 0x00060B96 File Offset: 0x0005ED96
		// (set) Token: 0x06001449 RID: 5193 RVA: 0x00060B9E File Offset: 0x0005ED9E
		public ImageInputSourceType SourceType { get; set; } = ImageInputSourceType.OriginalImage;

		// Token: 0x17000743 RID: 1859
		// (get) Token: 0x0600144A RID: 5194 RVA: 0x00060BA7 File Offset: 0x0005EDA7
		// (set) Token: 0x0600144B RID: 5195 RVA: 0x00060BAF File Offset: 0x0005EDAF
		public string SourceToolId { get; set; }

		// Token: 0x17000744 RID: 1860
		// (get) Token: 0x0600144C RID: 5196 RVA: 0x00060BB8 File Offset: 0x0005EDB8
		// (set) Token: 0x0600144D RID: 5197 RVA: 0x00060BC0 File Offset: 0x0005EDC0
		public string SourceToolName { get; set; }
	}
}
