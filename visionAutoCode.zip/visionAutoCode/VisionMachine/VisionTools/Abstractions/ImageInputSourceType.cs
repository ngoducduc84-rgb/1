﻿using System;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x02000177 RID: 375
	public enum ImageInputSourceType
	{
		// Token: 0x04000872 RID: 2162
		OriginalImage,
		// Token: 0x04000873 RID: 2163
		PreviousToolOutput,
		// Token: 0x04000874 RID: 2164
		ToolOutput
	}
}
