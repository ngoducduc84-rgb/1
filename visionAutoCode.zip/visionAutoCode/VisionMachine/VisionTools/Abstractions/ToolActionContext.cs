﻿using System;
using VisionMachine.Models.Tool;
using VisionMachine.Views.Setting.Controllers;
using VisionMachine.Views.Setting.Services;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x0200017A RID: 378
	public class ToolActionContext
	{
		// Token: 0x17000747 RID: 1863
		// (get) Token: 0x06001453 RID: 5203 RVA: 0x00060BD9 File Offset: 0x0005EDD9
		// (set) Token: 0x06001454 RID: 5204 RVA: 0x00060BE1 File Offset: 0x0005EDE1
		public SettingDisplayController DisplayController { get; set; }

		// Token: 0x17000748 RID: 1864
		// (get) Token: 0x06001455 RID: 5205 RVA: 0x00060BEA File Offset: 0x0005EDEA
		// (set) Token: 0x06001456 RID: 5206 RVA: 0x00060BF2 File Offset: 0x0005EDF2
		public SettingRecipeService RecipeService { get; set; }

		// Token: 0x17000749 RID: 1865
		// (get) Token: 0x06001457 RID: 5207 RVA: 0x00060BFB File Offset: 0x0005EDFB
		// (set) Token: 0x06001458 RID: 5208 RVA: 0x00060C03 File Offset: 0x0005EE03
		public Action<ToolVision, object> ResultReporter { get; set; }

		// Token: 0x1700074A RID: 1866
		// (get) Token: 0x06001459 RID: 5209 RVA: 0x00060C0C File Offset: 0x0005EE0C
		// (set) Token: 0x0600145A RID: 5210 RVA: 0x00060C14 File Offset: 0x0005EE14
		public Action<string> ErrorReporter { get; set; }
	}
}
