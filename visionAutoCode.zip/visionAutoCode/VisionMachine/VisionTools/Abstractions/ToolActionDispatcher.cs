﻿using System;
using System.Collections.Generic;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.Blob;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CalibHandEye;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.CountBoundingBox;
using VisionMachine.VisionTools.DeformableInspection;
using VisionMachine.VisionTools.DistanceObject;
using VisionMachine.VisionTools.DLObjectInspection;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;
using VisionMachine.VisionTools.FindRedArrow;
using VisionMachine.VisionTools.Histogram;
using VisionMachine.VisionTools.HistogramColor;
using VisionMachine.VisionTools.ImageFilter;
using VisionMachine.VisionTools.ImageTransform;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MatrixCode;
using VisionMachine.VisionTools.MeasureCircle;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ProcedureInspection;
using VisionMachine.VisionTools.ProcedureModel;
using VisionMachine.VisionTools.ProductCountInspection;
using VisionMachine.VisionTools.ResultAlign;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.SaveImage;
using VisionMachine.VisionTools.ShapeModel;
using VisionMachine.VisionTools.VariationChangeWD;
using VisionMachine.VisionTools.VariationModel;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x0200017C RID: 380
	public class ToolActionDispatcher
	{
		// Token: 0x0600145E RID: 5214 RVA: 0x00060F68 File Offset: 0x0005F168
		public ToolActionDispatcher()
		{
			this.Register(new ImageFilterActionService());
			this.Register(new ImageTransformActionService());
			this.Register(new SaveImageActionService());
			this.Register(new MatrixCodeActionService());
			this.Register(new ShapeModelActionService());
			this.Register(new AnisoShapeModelActionService());
			this.Register(new OverlappingShapeModelActionService());
			this.Register(new BlobActionService());
			this.Register(new CircleMasterActionService());
			this.Register(new BoundingBoxMasterActionService());
			this.Register(new MinAreaMasterActionService());
			this.Register(new FindCircleActionService());
			this.Register(new FindBoundingBoxActionService());
			this.Register(new FindMinAreaActionService());
			this.Register(new FindLineActionService());
			this.Register(new HistogramActionService());
			this.Register(new HistogramColorActionService());
			this.Register(new DistanceObjectActionService());
			this.Register(new MeasureCircleActionService());
			this.Register(new IntersectingLinesActionService());
			this.Register(new AngleSelectorActionService());
			this.Register(new CalibHandEyeActionService());
			this.Register(new CalibResultAlignActionService());
			this.Register(new CalibResultInspectionActionService());
			this.Register(new DeformableInspectionActionService());
			this.Register(new VariationModelActionService());
			this.Register(new VariationChangeWDActionService());
			this.Register(new ProductCountInspectionActionService());
			this.Register(new FindRedArrowActionService());
			this.Register(new CountBoundingBoxActionService());
			this.Register(new ProcedureInspectionActionService());
			this.Register(new ProcedureModelActionService());
			this.Register(new DLObjectInspectionActionService());
		}

		// Token: 0x0600145F RID: 5215 RVA: 0x00061114 File Offset: 0x0005F314
		public void Register(IToolActionService service)
		{
			bool flag = service == null;
			if (!flag)
			{
				this._services[service.ToolType] = service;
			}
		}

		// Token: 0x06001460 RID: 5216 RVA: 0x00061140 File Offset: 0x0005F340
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = tool == null;
			if (flag)
			{
				ToolActionFeedback.ReportError(context, "No tool is selected.");
			}
			else
			{
				bool flag2 = !this._services.ContainsKey(tool.ToolType);
				if (flag2)
				{
					ToolActionFeedback.ReportError(context, "Trial Run is not supported for this tool: " + tool.ToolType.ToString());
				}
				else
				{
					this._services[tool.ToolType].TrialRun(context, tool);
				}
			}
		}

		// Token: 0x06001461 RID: 5217 RVA: 0x000611C0 File Offset: 0x0005F3C0
		public void Matching(ToolActionContext context, ToolVision tool)
		{
			bool flag = tool != null && tool.ToolType == ToolType.IntersectingLines;
			if (flag)
			{
				IntersectingLinesActionService intersectingLinesActionService = this._services[ToolType.IntersectingLines] as IntersectingLinesActionService;
				if (intersectingLinesActionService != null)
				{
					intersectingLinesActionService.Matching(context, tool);
				}
			}
			else
			{
				bool flag2 = tool != null && tool.ToolType == ToolType.CircleMaster;
				if (flag2)
				{
					CircleMasterActionService circleMasterActionService = this._services[ToolType.CircleMaster] as CircleMasterActionService;
					if (circleMasterActionService != null)
					{
						circleMasterActionService.Matching(context, tool);
					}
				}
				else
				{
					bool flag3 = tool != null && tool.ToolType == ToolType.BoundingBoxMaster;
					if (flag3)
					{
						BoundingBoxMasterActionService boundingBoxMasterActionService = this._services[ToolType.BoundingBoxMaster] as BoundingBoxMasterActionService;
						if (boundingBoxMasterActionService != null)
						{
							boundingBoxMasterActionService.Matching(context, tool);
						}
					}
					else
					{
						bool flag4 = tool != null && tool.ToolType == ToolType.MinAreaMaster;
						if (flag4)
						{
							MinAreaMasterActionService minAreaMasterActionService = this._services[ToolType.MinAreaMaster] as MinAreaMasterActionService;
							if (minAreaMasterActionService != null)
							{
								minAreaMasterActionService.Matching(context, tool);
							}
						}
						else
						{
							bool flag5 = tool != null && tool.ToolType == ToolType.AngleSelector;
							if (flag5)
							{
								AngleSelectorActionService angleSelectorActionService = this._services[ToolType.AngleSelector] as AngleSelectorActionService;
								if (angleSelectorActionService != null)
								{
									angleSelectorActionService.Matching(context, tool);
								}
							}
							else
							{
								bool flag6 = tool != null && tool.ToolType == ToolType.AnisoShapeModel;
								if (flag6)
								{
									AnisoShapeModelActionService anisoShapeModelActionService = this._services[ToolType.AnisoShapeModel] as AnisoShapeModelActionService;
									if (anisoShapeModelActionService != null)
									{
										anisoShapeModelActionService.Matching(context, tool);
									}
								}
								else
								{
									bool flag7 = tool != null && tool.ToolType == ToolType.ProcedureModel;
									if (flag7)
									{
										ProcedureModelActionService procedureModelActionService = this._services[ToolType.ProcedureModel] as ProcedureModelActionService;
										if (procedureModelActionService != null)
										{
											procedureModelActionService.Matching(context, tool);
										}
									}
									else
									{
										bool flag8 = tool != null && tool.ToolType == ToolType.OverlappingShapeModel;
										if (flag8)
										{
											OverlappingShapeModelActionService overlappingShapeModelActionService = this._services[ToolType.OverlappingShapeModel] as OverlappingShapeModelActionService;
											if (overlappingShapeModelActionService != null)
											{
												overlappingShapeModelActionService.Matching(context, tool);
											}
										}
										else
										{
											ShapeModelActionService service = this.GetShapeModelService(tool);
											bool flag9 = service == null;
											if (!flag9)
											{
												service.Matching(context, tool);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001462 RID: 5218 RVA: 0x000613C0 File Offset: 0x0005F5C0
		public void DefineMaster(ToolActionContext context, ToolVision tool)
		{
			bool flag = tool != null && tool.ToolType == ToolType.IntersectingLines;
			if (flag)
			{
				IntersectingLinesActionService intersectingLinesActionService = this._services[ToolType.IntersectingLines] as IntersectingLinesActionService;
				if (intersectingLinesActionService != null)
				{
					intersectingLinesActionService.DefineMaster(context, tool);
				}
			}
			else
			{
				bool flag2 = tool != null && tool.ToolType == ToolType.CircleMaster;
				if (flag2)
				{
					CircleMasterActionService circleMasterActionService = this._services[ToolType.CircleMaster] as CircleMasterActionService;
					if (circleMasterActionService != null)
					{
						circleMasterActionService.DefineMaster(context, tool);
					}
				}
				else
				{
					bool flag3 = tool != null && tool.ToolType == ToolType.BoundingBoxMaster;
					if (flag3)
					{
						BoundingBoxMasterActionService boundingBoxMasterActionService = this._services[ToolType.BoundingBoxMaster] as BoundingBoxMasterActionService;
						if (boundingBoxMasterActionService != null)
						{
							boundingBoxMasterActionService.DefineMaster(context, tool);
						}
					}
					else
					{
						bool flag4 = tool != null && tool.ToolType == ToolType.MinAreaMaster;
						if (flag4)
						{
							MinAreaMasterActionService minAreaMasterActionService = this._services[ToolType.MinAreaMaster] as MinAreaMasterActionService;
							if (minAreaMasterActionService != null)
							{
								minAreaMasterActionService.DefineMaster(context, tool);
							}
						}
						else
						{
							bool flag5 = tool != null && tool.ToolType == ToolType.AngleSelector;
							if (flag5)
							{
								AngleSelectorActionService angleSelectorActionService = this._services[ToolType.AngleSelector] as AngleSelectorActionService;
								if (angleSelectorActionService != null)
								{
									angleSelectorActionService.DefineMaster(context, tool);
								}
							}
							else
							{
								bool flag6 = tool != null && tool.ToolType == ToolType.AnisoShapeModel;
								if (flag6)
								{
									AnisoShapeModelActionService anisoShapeModelActionService = this._services[ToolType.AnisoShapeModel] as AnisoShapeModelActionService;
									if (anisoShapeModelActionService != null)
									{
										anisoShapeModelActionService.DefineMaster(context, tool);
									}
								}
								else
								{
									bool flag7 = tool != null && tool.ToolType == ToolType.ProcedureModel;
									if (flag7)
									{
										ProcedureModelActionService procedureModelActionService = this._services[ToolType.ProcedureModel] as ProcedureModelActionService;
										if (procedureModelActionService != null)
										{
											procedureModelActionService.DefineMaster(context, tool);
										}
									}
									else
									{
										bool flag8 = tool != null && tool.ToolType == ToolType.OverlappingShapeModel;
										if (flag8)
										{
											OverlappingShapeModelActionService overlappingShapeModelActionService = this._services[ToolType.OverlappingShapeModel] as OverlappingShapeModelActionService;
											if (overlappingShapeModelActionService != null)
											{
												overlappingShapeModelActionService.DefineMaster(context, tool);
											}
										}
										else
										{
											ShapeModelActionService service = this.GetShapeModelService(tool);
											bool flag9 = service == null;
											if (!flag9)
											{
												service.DefineMaster(context, tool);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001463 RID: 5219 RVA: 0x000615C0 File Offset: 0x0005F7C0
		private ShapeModelActionService GetShapeModelService(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.Shape_model;
			ShapeModelActionService result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = (this._services[ToolType.Shape_model] as ShapeModelActionService);
			}
			return result;
		}

		// Token: 0x06001464 RID: 5220 RVA: 0x00061600 File Offset: 0x0005F800
		private AnisoShapeModelActionService GetAnisoShapeModelService(ToolVision tool)
		{
			bool flag = tool == null || tool.ToolType != ToolType.AnisoShapeModel;
			AnisoShapeModelActionService result;
			if (flag)
			{
				result = null;
			}
			else
			{
				result = (this._services[ToolType.AnisoShapeModel] as AnisoShapeModelActionService);
			}
			return result;
		}

		// Token: 0x04000879 RID: 2169
		private readonly Dictionary<ToolType, IToolActionService> _services = new Dictionary<ToolType, IToolActionService>();
	}
}
