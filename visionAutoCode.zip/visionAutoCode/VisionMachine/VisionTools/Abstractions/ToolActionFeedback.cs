﻿using System;
using DevExpress.Xpf.Core;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x0200017D RID: 381
	public static class ToolActionFeedback
	{
		// Token: 0x06001465 RID: 5221 RVA: 0x00061640 File Offset: 0x0005F840
		public static void ReportError(ToolActionContext context, string message)
		{
			bool flag = ((context != null) ? context.ErrorReporter : null) != null;
			if (flag)
			{
				context.ErrorReporter(message);
			}
			else
			{
				DXMessageBox.Show(message);
			}
		}
	}
}
