﻿using System;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x0200017E RID: 382
	public class ToolImageSourceOption
	{
		// Token: 0x1700074B RID: 1867
		// (get) Token: 0x06001466 RID: 5222 RVA: 0x00061677 File Offset: 0x0005F877
		// (set) Token: 0x06001467 RID: 5223 RVA: 0x0006167F File Offset: 0x0005F87F
		public string ToolId { get; set; }

		// Token: 0x1700074C RID: 1868
		// (get) Token: 0x06001468 RID: 5224 RVA: 0x00061688 File Offset: 0x0005F888
		// (set) Token: 0x06001469 RID: 5225 RVA: 0x00061690 File Offset: 0x0005F890
		public string ToolName { get; set; }

		// Token: 0x1700074D RID: 1869
		// (get) Token: 0x0600146A RID: 5226 RVA: 0x00061699 File Offset: 0x0005F899
		// (set) Token: 0x0600146B RID: 5227 RVA: 0x000616A1 File Offset: 0x0005F8A1
		public int Index { get; set; }

		// Token: 0x1700074E RID: 1870
		// (get) Token: 0x0600146C RID: 5228 RVA: 0x000616AC File Offset: 0x0005F8AC
		public string DisplayText
		{
			get
			{
				return this.ToolName;
			}
		}

		// Token: 0x1700074F RID: 1871
		// (get) Token: 0x0600146D RID: 5229 RVA: 0x000616C4 File Offset: 0x0005F8C4
		public string ShortId
		{
			get
			{
				bool flag = string.IsNullOrWhiteSpace(this.ToolId);
				string result;
				if (flag)
				{
					result = "";
				}
				else
				{
					bool flag2 = this.ToolId.Length <= 8;
					if (flag2)
					{
						result = this.ToolId;
					}
					else
					{
						result = this.ToolId.Substring(0, 8);
					}
				}
				return result;
			}
		}
	}
}
