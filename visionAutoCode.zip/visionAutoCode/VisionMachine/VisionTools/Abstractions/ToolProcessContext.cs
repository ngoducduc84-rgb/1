﻿using System;
using HalconDotNet;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x0200017F RID: 383
	public class ToolProcessContext
	{
		// Token: 0x17000750 RID: 1872
		// (get) Token: 0x0600146F RID: 5231 RVA: 0x00061718 File Offset: 0x0005F918
		// (set) Token: 0x06001470 RID: 5232 RVA: 0x00061720 File Offset: 0x0005F920
		public HObject OriginalImage { get; set; }

		// Token: 0x17000751 RID: 1873
		// (get) Token: 0x06001471 RID: 5233 RVA: 0x00061729 File Offset: 0x0005F929
		// (set) Token: 0x06001472 RID: 5234 RVA: 0x00061731 File Offset: 0x0005F931
		public HObject InputImage { get; set; }

		// Token: 0x17000752 RID: 1874
		// (get) Token: 0x06001473 RID: 5235 RVA: 0x0006173A File Offset: 0x0005F93A
		// (set) Token: 0x06001474 RID: 5236 RVA: 0x00061742 File Offset: 0x0005F942
		public HObject OutputImage { get; set; }

		// Token: 0x17000753 RID: 1875
		// (get) Token: 0x06001475 RID: 5237 RVA: 0x0006174B File Offset: 0x0005F94B
		// (set) Token: 0x06001476 RID: 5238 RVA: 0x00061753 File Offset: 0x0005F953
		public ImageBufferStore BufferStore { get; set; }

		// Token: 0x17000754 RID: 1876
		// (get) Token: 0x06001477 RID: 5239 RVA: 0x0006175C File Offset: 0x0005F95C
		// (set) Token: 0x06001478 RID: 5240 RVA: 0x00061764 File Offset: 0x0005F964
		public ToolResultStore ResultStore { get; set; }
	}
}
