﻿using System;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x02000180 RID: 384
	public class ToolProcessResult
	{
		// Token: 0x17000755 RID: 1877
		// (get) Token: 0x0600147A RID: 5242 RVA: 0x0006176D File Offset: 0x0005F96D
		// (set) Token: 0x0600147B RID: 5243 RVA: 0x00061775 File Offset: 0x0005F975
		public bool IsSuccess { get; set; }

		// Token: 0x17000756 RID: 1878
		// (get) Token: 0x0600147C RID: 5244 RVA: 0x0006177E File Offset: 0x0005F97E
		// (set) Token: 0x0600147D RID: 5245 RVA: 0x00061786 File Offset: 0x0005F986
		public string Message { get; set; }

		// Token: 0x17000757 RID: 1879
		// (get) Token: 0x0600147E RID: 5246 RVA: 0x0006178F File Offset: 0x0005F98F
		// (set) Token: 0x0600147F RID: 5247 RVA: 0x00061797 File Offset: 0x0005F997
		public object Data { get; set; }
	}
}
