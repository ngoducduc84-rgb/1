﻿using System;
using System.Collections.Generic;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Services.Roi;

namespace VisionMachine.VisionTools.Abstractions
{
	// Token: 0x0200017B RID: 379
	public static class ToolRoiOverlayDrawer
	{
		// Token: 0x0600145C RID: 5212 RVA: 0x00060C20 File Offset: 0x0005EE20
		public static void DrawRoiList(HWindow window, ToolVision tool, IEnumerable<RoiData> rois, string color, int lineWidth = 2)
		{
			bool flag = window == null || rois == null;
			if (!flag)
			{
				try
				{
					HOperatorSet.SetDraw(window, "margin");
					HOperatorSet.SetLineWidth(window, lineWidth);
					HOperatorSet.SetColor(window, string.IsNullOrWhiteSpace(color) ? "cyan" : color);
				}
				catch (HOperatorException)
				{
					return;
				}
				foreach (RoiData roi in rois)
				{
					bool flag2 = roi != null && roi.IsEnabled;
					if (flag2)
					{
						ToolRoiOverlayDrawer.DrawRoi(window, tool, roi);
					}
				}
			}
		}

		// Token: 0x0600145D RID: 5213 RVA: 0x00060CF4 File Offset: 0x0005EEF4
		public static void DrawRoi(HWindow window, ToolVision tool, RoiData roi)
		{
			bool flag = window == null || roi == null;
			if (!flag)
			{
				HObject obj = null;
				try
				{
					switch (roi.RoiType)
					{
					case RoiType.Rectangle1:
						HOperatorSet.GenRectangle1(out obj, roi.Row1, roi.Col1, roi.Row2, roi.Col2);
						break;
					case RoiType.Rectangle2:
						HOperatorSet.GenRectangle2(out obj, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
						break;
					case RoiType.Circle:
						HOperatorSet.GenCircle(out obj, roi.CenterRow, roi.CenterCol, roi.Radius);
						break;
					case RoiType.Ellipse:
						HOperatorSet.GenEllipse(out obj, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
						break;
					case RoiType.Line:
						HOperatorSet.DispLine(window, roi.Row1, roi.Col1, roi.Row2, roi.Col2);
						return;
					case RoiType.Polygon:
					case RoiType.FreeDraw:
					case RoiType.DrawRegion:
					{
						bool flag2 = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 2 || roi.Rows.Count != roi.Cols.Count;
						if (flag2)
						{
							return;
						}
						HOperatorSet.GenContourPolygonXld(out obj, new HTuple(roi.Rows.ToArray()), new HTuple(roi.Cols.ToArray()));
						break;
					}
					case RoiType.CustomPaint:
						obj = CustomRoiRegionStore.Load(tool, roi);
						break;
					}
					bool flag3 = obj != null && obj.IsInitialized();
					if (flag3)
					{
						HOperatorSet.DispObj(obj, window);
					}
				}
				catch (HOperatorException)
				{
				}
				finally
				{
					if (obj != null)
					{
						obj.Dispose();
					}
				}
			}
		}
	}
}
