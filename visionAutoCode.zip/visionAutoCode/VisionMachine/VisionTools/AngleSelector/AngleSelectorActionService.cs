﻿using System;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x02000025 RID: 37
	public class AngleSelectorActionService : IToolActionService
	{
		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060001DC RID: 476 RVA: 0x0000B1BC File Offset: 0x000093BC
		public ToolType ToolType
		{
			get
			{
				return ToolType.AngleSelector;
			}
		}

		// Token: 0x060001DD RID: 477 RVA: 0x0000B1D0 File Offset: 0x000093D0
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, AngleSelectorActionService.AngleSelectorRunMode.TrialRun);
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000B1DD File Offset: 0x000093DD
		public void Matching(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, AngleSelectorActionService.AngleSelectorRunMode.Matching);
		}

		// Token: 0x060001DF RID: 479 RVA: 0x0000B1EA File Offset: 0x000093EA
		public void DefineMaster(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, AngleSelectorActionService.AngleSelectorRunMode.DefineMaster);
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x0000B1F8 File Offset: 0x000093F8
		private void RunAndDisplay(ToolActionContext context, ToolVision tool, AngleSelectorActionService.AngleSelectorRunMode runMode)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (!flag2)
					{
						AngleSelectorProcessor processor = new AngleSelectorProcessor();
						AngleSelectorResult result;
						if (runMode != AngleSelectorActionService.AngleSelectorRunMode.DefineMaster)
						{
							if (runMode != AngleSelectorActionService.AngleSelectorRunMode.TrialRun)
							{
								result = processor.Match(original, tool);
							}
							else
							{
								result = processor.TrialRun(original, tool);
							}
						}
						else
						{
							result = processor.DefineMaster(original, tool);
						}
						Action<ToolVision, object> resultReporter = context.ResultReporter;
						if (resultReporter != null)
						{
							resultReporter(tool, result);
						}
						context.DisplayController.DisplayImage(original);
						AngleSelectorResult overlayResult = result;
						context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
						{
							this._drawer.Draw(window, tool, overlayResult);
						}, overlayResult);
					}
				}
				finally
				{
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x040000B5 RID: 181
		private readonly AngleSelectorResultDrawer _drawer = new AngleSelectorResultDrawer();

		// Token: 0x020002D3 RID: 723
		private enum AngleSelectorRunMode
		{
			// Token: 0x04001071 RID: 4209
			Matching,
			// Token: 0x04001072 RID: 4210
			DefineMaster,
			// Token: 0x04001073 RID: 4211
			TrialRun
		}
	}
}
