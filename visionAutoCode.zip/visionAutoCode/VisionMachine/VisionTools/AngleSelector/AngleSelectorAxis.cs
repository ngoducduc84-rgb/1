﻿using System;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x02000026 RID: 38
	public enum AngleSelectorAxis
	{
		// Token: 0x040000B7 RID: 183
		X,
		// Token: 0x040000B8 RID: 184
		Y
	}
}
