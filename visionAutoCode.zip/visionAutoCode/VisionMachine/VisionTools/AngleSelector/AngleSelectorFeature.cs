﻿using System;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x02000027 RID: 39
	public enum AngleSelectorFeature
	{
		// Token: 0x040000BA RID: 186
		StartPoint,
		// Token: 0x040000BB RID: 187
		EndPoint,
		// Token: 0x040000BC RID: 188
		MidPoint,
		// Token: 0x040000BD RID: 189
		CenterPoint,
		// Token: 0x040000BE RID: 190
		TopLeft,
		// Token: 0x040000BF RID: 191
		TopRight,
		// Token: 0x040000C0 RID: 192
		BottomRight,
		// Token: 0x040000C1 RID: 193
		BottomLeft
	}
}
