﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x02000028 RID: 40
	public class AngleSelectorParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060001E2 RID: 482 RVA: 0x0000B35C File Offset: 0x0000955C
		// (set) Token: 0x060001E3 RID: 483 RVA: 0x0000B364 File Offset: 0x00009564
		public ToolVision Tool { get; set; }

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060001E4 RID: 484 RVA: 0x0000B36D File Offset: 0x0000956D
		// (set) Token: 0x060001E5 RID: 485 RVA: 0x0000B375 File Offset: 0x00009575
		public ObservableCollection<AngleSelectorSourceOption> AvailableObjectTools { get; set; }

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x0000B37E File Offset: 0x0000957E
		public ObservableCollection<AngleSelectorFeature> FirstFeatureOptions { get; } = new ObservableCollection<AngleSelectorFeature>();

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060001E7 RID: 487 RVA: 0x0000B386 File Offset: 0x00009586
		public ObservableCollection<AngleSelectorFeature> SecondFeatureOptions { get; } = new ObservableCollection<AngleSelectorFeature>();

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x0000B390 File Offset: 0x00009590
		// (set) Token: 0x060001E9 RID: 489 RVA: 0x0000B3A8 File Offset: 0x000095A8
		public AngleSelectorToolConfig Config
		{
			get
			{
				return this._config;
			}
			set
			{
				bool flag = this._config == value;
				if (!flag)
				{
					this.DetachConfigEvents(this._config);
					this._config = value;
					this.AttachConfigEvents(this._config);
					this.UpdateFeatureOptions();
					this.OnPropertyChanged("Config");
				}
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060001EA RID: 490 RVA: 0x0000B3FC File Offset: 0x000095FC
		// (set) Token: 0x060001EB RID: 491 RVA: 0x0000B414 File Offset: 0x00009614
		public AngleSelectorSourceOption SelectedFirstObjectTool
		{
			get
			{
				return this._selectedFirstObjectTool;
			}
			set
			{
				bool flag = this._selectedFirstObjectTool == value;
				if (!flag)
				{
					this._selectedFirstObjectTool = value;
					bool flag2 = this.Config != null;
					if (flag2)
					{
						this.Config.FirstObjectToolName = ((value != null) ? value.ToolName : null);
					}
					this.UpdateFeatureOptions();
					this.OnPropertyChanged("SelectedFirstObjectTool");
				}
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060001EC RID: 492 RVA: 0x0000B470 File Offset: 0x00009670
		// (set) Token: 0x060001ED RID: 493 RVA: 0x0000B488 File Offset: 0x00009688
		public AngleSelectorSourceOption SelectedSecondObjectTool
		{
			get
			{
				return this._selectedSecondObjectTool;
			}
			set
			{
				bool flag = this._selectedSecondObjectTool == value;
				if (!flag)
				{
					this._selectedSecondObjectTool = value;
					bool flag2 = this.Config != null;
					if (flag2)
					{
						this.Config.SecondObjectToolName = ((value != null) ? value.ToolName : null);
					}
					this.UpdateFeatureOptions();
					this.OnPropertyChanged("SelectedSecondObjectTool");
				}
			}
		}

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x060001EE RID: 494 RVA: 0x0000B4E4 File Offset: 0x000096E4
		// (remove) Token: 0x060001EF RID: 495 RVA: 0x0000B51C File Offset: 0x0000971C
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060001F0 RID: 496 RVA: 0x0000B554 File Offset: 0x00009754
		public void RestoreSelections()
		{
			bool flag = this.Config == null || this.AvailableObjectTools == null;
			if (!flag)
			{
				this._selectedFirstObjectTool = this.AvailableObjectTools.FirstOrDefault((AngleSelectorSourceOption x) => x.ToolName == this.Config.FirstObjectToolName);
				this._selectedSecondObjectTool = this.AvailableObjectTools.FirstOrDefault((AngleSelectorSourceOption x) => x.ToolName == this.Config.SecondObjectToolName);
				this.OnPropertyChanged("SelectedFirstObjectTool");
				this.OnPropertyChanged("SelectedSecondObjectTool");
				this.UpdateFeatureOptions();
			}
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x0000B5D8 File Offset: 0x000097D8
		private void AttachConfigEvents(AngleSelectorToolConfig config)
		{
			bool flag = config != null;
			if (flag)
			{
				config.PropertyChanged += this.Config_PropertyChanged;
			}
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x0000B604 File Offset: 0x00009804
		private void DetachConfigEvents(AngleSelectorToolConfig config)
		{
			bool flag = config != null;
			if (flag)
			{
				config.PropertyChanged -= this.Config_PropertyChanged;
			}
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x0000B630 File Offset: 0x00009830
		private void Config_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e.PropertyName == "FirstObjectToolName" || e.PropertyName == "SecondObjectToolName";
			if (flag)
			{
				this.RestoreSelections();
			}
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000B670 File Offset: 0x00009870
		private void UpdateFeatureOptions()
		{
			bool flag = this.Config == null;
			if (!flag)
			{
				this.UpdateFeatureOptionList(this.FirstFeatureOptions, this.GetToolType(this.Config.FirstObjectToolName), true);
				this.UpdateFeatureOptionList(this.SecondFeatureOptions, this.GetToolType(this.Config.SecondObjectToolName), false);
				this.OnPropertyChanged("FirstFeatureOptions");
				this.OnPropertyChanged("SecondFeatureOptions");
			}
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x0000B6E4 File Offset: 0x000098E4
		private ToolType GetToolType(string toolName)
		{
			bool flag = this.AvailableObjectTools == null || string.IsNullOrWhiteSpace(toolName);
			ToolType result;
			if (flag)
			{
				result = ToolType.FindLine;
			}
			else
			{
				AngleSelectorSourceOption option = this.AvailableObjectTools.FirstOrDefault((AngleSelectorSourceOption x) => x.ToolName == toolName);
				result = ((option == null) ? ToolType.FindLine : option.ToolType);
			}
			return result;
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x0000B748 File Offset: 0x00009948
		private void UpdateFeatureOptionList(ObservableCollection<AngleSelectorFeature> target, ToolType toolType, bool isFirstObject)
		{
			target.Clear();
			bool flag = toolType == ToolType.FindCircle || toolType == ToolType.CircleMaster;
			AngleSelectorFeature[] options;
			AngleSelectorFeature fallback;
			if (flag)
			{
				options = new AngleSelectorFeature[]
				{
					AngleSelectorFeature.CenterPoint
				};
				fallback = AngleSelectorFeature.CenterPoint;
			}
			else
			{
				bool flag2 = toolType == ToolType.FindBoundingBox || toolType == ToolType.FindMinArea;
				if (flag2)
				{
					options = new AngleSelectorFeature[]
					{
						AngleSelectorFeature.CenterPoint,
						AngleSelectorFeature.TopLeft,
						AngleSelectorFeature.TopRight,
						AngleSelectorFeature.BottomRight,
						AngleSelectorFeature.BottomLeft
					};
					fallback = AngleSelectorFeature.CenterPoint;
				}
				else
				{
					options = new AngleSelectorFeature[]
					{
						AngleSelectorFeature.StartPoint,
						AngleSelectorFeature.EndPoint,
						AngleSelectorFeature.MidPoint
					};
					fallback = AngleSelectorFeature.MidPoint;
				}
			}
			foreach (AngleSelectorFeature option in options)
			{
				target.Add(option);
			}
			if (isFirstObject)
			{
				bool flag3 = !target.Contains(this.Config.FirstFeature);
				if (flag3)
				{
					this.Config.FirstFeature = fallback;
				}
			}
			else
			{
				bool flag4 = !target.Contains(this.Config.SecondFeature);
				if (flag4)
				{
					this.Config.SecondFeature = fallback;
				}
			}
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0000B83C File Offset: 0x00009A3C
		private void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x040000C2 RID: 194
		private AngleSelectorToolConfig _config;

		// Token: 0x040000C3 RID: 195
		private AngleSelectorSourceOption _selectedFirstObjectTool;

		// Token: 0x040000C4 RID: 196
		private AngleSelectorSourceOption _selectedSecondObjectTool;
	}
}
