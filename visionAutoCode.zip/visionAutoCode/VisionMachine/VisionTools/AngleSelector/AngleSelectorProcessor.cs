﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;
using VisionMachine.VisionTools.Runtime;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x02000029 RID: 41
	public class AngleSelectorProcessor : IToolProcessor
	{
		// Token: 0x060001FB RID: 507 RVA: 0x0000B8A7 File Offset: 0x00009AA7
		public AngleSelectorProcessor() : this(null, null)
		{
		}

		// Token: 0x060001FC RID: 508 RVA: 0x0000B8B3 File Offset: 0x00009AB3
		public AngleSelectorProcessor(IDictionary<string, AngleSelectorSourceResult> cachedSourceResults, IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedSourceResults = cachedSourceResults;
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060001FD RID: 509 RVA: 0x0000B8CC File Offset: 0x00009ACC
		public ToolType ToolType
		{
			get
			{
				return ToolType.AngleSelector;
			}
		}

		// Token: 0x060001FE RID: 510 RVA: 0x0000B8E0 File Offset: 0x00009AE0
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			AngleSelectorResult result = this.Match((context != null) ? context.InputImage : null, tool);
			return new ToolProcessResult
			{
				IsSuccess = result.IsSuccess,
				Message = result.Message,
				Data = result
			};
		}

		// Token: 0x060001FF RID: 511 RVA: 0x0000B930 File Offset: 0x00009B30
		public AngleSelectorResult Match(HObject image, ToolVision tool)
		{
			AngleSelectorResult result = new AngleSelectorResult();
			Stopwatch stopwatch = Stopwatch.StartNew();
			AngleSelectorResult result2;
			try
			{
				bool flag = image == null || !image.IsInitialized();
				if (flag)
				{
					result.Message = "Input image null.";
					result2 = result;
				}
				else
				{
					AngleSelectorToolConfig config = ((tool != null) ? tool.Config : null) as AngleSelectorToolConfig;
					bool flag2 = config == null;
					if (flag2)
					{
						result.Message = "Angle Selector config null.";
						result2 = result;
					}
					else
					{
						bool flag3 = !config.IsEnabled;
						if (flag3)
						{
							result.Message = "Angle Selector tool is disabled.";
							result2 = result;
						}
						else
						{
							result.ToolName = tool.Name;
							result.RoiName = tool.Name;
							result.FirstObjectToolName = config.FirstObjectToolName;
							result.SecondObjectToolName = config.SecondObjectToolName;
							result.FirstFeature = config.FirstFeature;
							result.SecondFeature = config.SecondFeature;
							AngleSelectorSourceResult firstSource = this.GetSourceResult(image, tool, config.FirstObjectToolName);
							AngleSelectorSourceResult secondSource = this.GetSourceResult(image, tool, config.SecondObjectToolName);
							result.FirstObjectProcessingTimeMs = ((firstSource == null) ? 0.0 : firstSource.ProcessingTimeMs);
							result.SecondObjectProcessingTimeMs = ((secondSource == null || firstSource == secondSource) ? 0.0 : secondSource.ProcessingTimeMs);
							this.CopySourceGeometry(result, firstSource, true);
							this.CopySourceGeometry(result, secondSource, false);
							bool flag4 = firstSource == null || !firstSource.IsSuccess;
							if (flag4)
							{
								result.Message = "Object 1 result is not available.";
								result2 = result;
							}
							else
							{
								bool flag5 = secondSource == null || !secondSource.IsSuccess;
								if (flag5)
								{
									result.Message = "Object 2 result is not available.";
									result2 = result;
								}
								else
								{
									double row;
									double column;
									string firstMessage;
									bool flag6 = !this.TryGetPoint(firstSource, config.FirstFeature, out row, out column, out firstMessage);
									if (flag6)
									{
										result.Message = firstMessage;
										result2 = result;
									}
									else
									{
										double row2;
										double column2;
										string secondMessage;
										bool flag7 = !this.TryGetPoint(secondSource, config.SecondFeature, out row2, out column2, out secondMessage);
										if (flag7)
										{
											result.Message = secondMessage;
											result2 = result;
										}
										else
										{
											bool flag8 = Math.Abs(row - row2) < 1E-06 && Math.Abs(column - column2) < 1E-06;
											if (flag8)
											{
												result.Message = "The selected points are identical.";
												result2 = result;
											}
											else
											{
												double angleRad = this.CalculateAngleRadians(row, column, row2, column2, config.CompareAxis, config.Quadrant);
												result.Point1Row = row;
												result.Point1Column = column;
												result.Point2Row = row2;
												result.Point2Column = column2;
												result.Row = (row + row2) / 2.0;
												result.Column = (column + column2) / 2.0;
												result.Angle = angleRad;
												result.AngleDegrees = angleRad * 180.0 / 3.141592653589793;
												result.Score = 1.0;
												this.ApplyDeltaToResult(tool, result);
												result.IsSuccess = true;
												result.Message = "Angle Selector OK.";
												result2 = result;
											}
										}
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				result.Message = "Angle Selector failed: " + ex.Message;
				result2 = result;
			}
			finally
			{
				stopwatch.Stop();
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				result.TotalProcessingTimeMs = result.FirstObjectProcessingTimeMs + result.SecondObjectProcessingTimeMs + result.ProcessingTimeMs;
			}
			return result2;
		}

		// Token: 0x06000200 RID: 512 RVA: 0x0000BCDC File Offset: 0x00009EDC
		public AngleSelectorResult DefineMaster(HObject image, ToolVision tool)
		{
			AngleSelectorResult result = this.Match(image, tool);
			bool flag = !result.IsSuccess;
			AngleSelectorResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeModelToolTrain train = this.EnsureTrain(tool);
				train.MasterRow = result.Row;
				train.MasterColumn = result.Column;
				train.MasterAngle = result.Angle;
				train.LastRow = result.Row;
				train.LastColumn = result.Column;
				train.LastAngle = result.Angle;
				train.LastScore = result.Score;
				train.HasMasterDefined = true;
				result.DeltaRow = 0.0;
				result.DeltaColumn = 0.0;
				result.DeltaAngle = 0.0;
				result.DeltaAngleDegrees = 0.0;
				result.HasMasterDefined = true;
				result.Message = "Angle Selector master defined.";
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06000201 RID: 513 RVA: 0x0000BDCC File Offset: 0x00009FCC
		public AngleSelectorResult TrialRun(HObject image, ToolVision tool)
		{
			AngleSelectorResult result = this.Match(image, tool);
			bool flag = !result.IsSuccess;
			AngleSelectorResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeModelToolTrain train = ((tool != null) ? tool.TrainModel : null) as ShapeModelToolTrain;
				bool flag2 = train == null || !train.HasMasterDefined;
				if (flag2)
				{
					result.IsSuccess = false;
					result.Message = "Master has not been defined.";
					result2 = result;
				}
				else
				{
					result.DeltaAngle = AngleSelectorProcessor.NormalizeToPi(result.Angle - train.MasterAngle);
					result.DeltaAngleDegrees = result.DeltaAngle * 180.0 / 3.141592653589793;
					result.HasMasterDefined = true;
					result.DisplayDeltaFromMaster = true;
					result.Message = "Trial Run OK. DeltaAngle=" + result.DeltaAngleDegrees.ToString("0.000") + " deg.";
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0000BEB0 File Offset: 0x0000A0B0
		private AngleSelectorSourceResult GetSourceResult(HObject image, ToolVision tool, string sourceToolName)
		{
			bool flag = string.IsNullOrWhiteSpace(sourceToolName);
			AngleSelectorSourceResult result;
			if (flag)
			{
				result = null;
			}
			else
			{
				AngleSelectorSourceResult cachedSource;
				bool flag2 = this._cachedSourceResults != null && this._cachedSourceResults.TryGetValue(sourceToolName, out cachedSource) && cachedSource != null;
				if (flag2)
				{
					result = cachedSource;
				}
				else
				{
					ToolVision tool2 = tool;
					ToolVision toolVision;
					if (tool2 == null)
					{
						toolVision = null;
					}
					else
					{
						TurnSnap parentTurnSnap = tool2.ParentTurnSnap;
						toolVision = ((parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.FindLine || x.ToolType == ToolType.FindCircle || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.FindBoundingBox || x.ToolType == ToolType.FindMinArea) && x.Name == sourceToolName) : null);
					}
					ToolVision sourceTool = toolVision;
					bool flag3 = sourceTool == null;
					if (flag3)
					{
						result = null;
					}
					else
					{
						HObject input = null;
						ImageBufferStore bufferStore = new ImageBufferStore();
						try
						{
							ToolProcessContext context = new ToolProcessContext
							{
								OriginalImage = image,
								InputImage = image,
								BufferStore = bufferStore
							};
							input = new ToolTrialRunPipelineService().BuildInputImageForTool(context, sourceTool);
							bool flag4 = input == null || !input.IsInitialized();
							if (flag4)
							{
								HOperatorSet.CopyImage(image, out input);
							}
							bool flag5 = sourceTool.ToolType == ToolType.FindLine;
							if (flag5)
							{
								FindLineResult line = new FindLineProcessor(this._cachedMasterResults).Run(input, sourceTool);
								result = new AngleSelectorSourceResult
								{
									ToolName = sourceTool.Name,
									ToolType = ToolType.FindLine,
									LineResult = line
								};
							}
							else
							{
								bool flag6 = sourceTool.ToolType == ToolType.FindCircle;
								if (flag6)
								{
									FindCircleResult circle = new FindCircleProcessor(this._cachedMasterResults).Run(input, sourceTool);
									result = new AngleSelectorSourceResult
									{
										ToolName = sourceTool.Name,
										ToolType = ToolType.FindCircle,
										CircleResult = circle
									};
								}
								else
								{
									bool flag7 = sourceTool.ToolType == ToolType.CircleMaster;
									if (flag7)
									{
										CircleMasterResult circleMaster = new CircleMasterProcessor(this._cachedMasterResults).Match(input, sourceTool);
										result = new AngleSelectorSourceResult
										{
											ToolName = sourceTool.Name,
											ToolType = ToolType.CircleMaster,
											CircleResult = circleMaster.CircleResult
										};
									}
									else
									{
										bool flag8 = sourceTool.ToolType == ToolType.FindMinArea;
										if (flag8)
										{
											FindMinAreaResult minArea = new FindMinAreaProcessor(this._cachedMasterResults).Run(input, sourceTool);
											result = new AngleSelectorSourceResult
											{
												ToolName = sourceTool.Name,
												ToolType = ToolType.FindMinArea,
												MinAreaResult = minArea
											};
										}
										else
										{
											FindBoundingBoxResult box = new FindBoundingBoxProcessor().Run(input, sourceTool);
											result = new AngleSelectorSourceResult
											{
												ToolName = sourceTool.Name,
												ToolType = ToolType.FindBoundingBox,
												BoundingBoxResult = box
											};
										}
									}
								}
							}
						}
						finally
						{
							if (input != null)
							{
								input.Dispose();
							}
							bufferStore.Clear();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000203 RID: 515 RVA: 0x0000C170 File Offset: 0x0000A370
		private void CopySourceGeometry(AngleSelectorResult result, AngleSelectorSourceResult source, bool isFirstObject)
		{
			bool flag = result == null || source == null || !source.IsSuccess;
			if (!flag)
			{
				bool flag2 = source.ToolType == ToolType.FindLine;
				if (flag2)
				{
					if (isFirstObject)
					{
						result.FirstLineResult = source.LineResult;
					}
					else
					{
						result.SecondLineResult = source.LineResult;
					}
				}
				else
				{
					bool flag3 = source.ToolType == ToolType.FindCircle || source.ToolType == ToolType.CircleMaster;
					if (flag3)
					{
						if (isFirstObject)
						{
							result.FirstCircleResult = source.CircleResult;
						}
						else
						{
							result.SecondCircleResult = source.CircleResult;
						}
					}
					else
					{
						bool flag4 = source.ToolType == ToolType.FindBoundingBox;
						if (flag4)
						{
							if (isFirstObject)
							{
								result.FirstBoundingBoxResult = source.BoundingBoxResult;
							}
							else
							{
								result.SecondBoundingBoxResult = source.BoundingBoxResult;
							}
						}
						else
						{
							bool flag5 = source.ToolType == ToolType.FindMinArea;
							if (flag5)
							{
								if (isFirstObject)
								{
									result.FirstMinAreaResult = source.MinAreaResult;
								}
								else
								{
									result.SecondMinAreaResult = source.MinAreaResult;
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06000204 RID: 516 RVA: 0x0000C27C File Offset: 0x0000A47C
		private bool TryGetPoint(AngleSelectorSourceResult source, AngleSelectorFeature feature, out double row, out double column, out string message)
		{
			row = 0.0;
			column = 0.0;
			message = null;
			bool flag = source == null || !source.IsSuccess;
			bool result;
			if (flag)
			{
				message = "Source result is not available.";
				result = false;
			}
			else
			{
				bool flag2 = source.ToolType == ToolType.FindCircle || source.ToolType == ToolType.CircleMaster;
				if (flag2)
				{
					row = source.CircleResult.Row;
					column = source.CircleResult.Column;
					result = true;
				}
				else
				{
					bool flag3 = source.ToolType == ToolType.FindBoundingBox;
					if (flag3)
					{
						result = this.TryGetBoundingBoxPoint(source.BoundingBoxResult, feature, out row, out column, out message);
					}
					else
					{
						bool flag4 = source.ToolType == ToolType.FindMinArea;
						if (flag4)
						{
							result = this.TryGetMinAreaPoint(source.MinAreaResult, feature, out row, out column, out message);
						}
						else
						{
							FindLineResult line = source.LineResult;
							switch (feature)
							{
							case AngleSelectorFeature.StartPoint:
								row = line.StartRow;
								column = line.StartColumn;
								return true;
							case AngleSelectorFeature.EndPoint:
								row = line.EndRow;
								column = line.EndColumn;
								return true;
							}
							row = (line.StartRow + line.EndRow) / 2.0;
							column = (line.StartColumn + line.EndColumn) / 2.0;
							result = true;
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000205 RID: 517 RVA: 0x0000C3DC File Offset: 0x0000A5DC
		private bool TryGetBoundingBoxPoint(FindBoundingBoxResult box, AngleSelectorFeature feature, out double row, out double column, out string message)
		{
			row = 0.0;
			column = 0.0;
			message = null;
			bool flag = box == null || !box.IsSuccess || box.SelectedBox == null;
			bool result;
			if (flag)
			{
				message = "Find Bounding Box result is not available.";
				result = false;
			}
			else
			{
				FindBoundingBoxPointSet points = box.SelectedBox.Points;
				switch (feature)
				{
				case AngleSelectorFeature.TopLeft:
					row = points.TopLeftRow;
					column = points.TopLeftColumn;
					return true;
				case AngleSelectorFeature.TopRight:
					row = points.TopRightRow;
					column = points.TopRightColumn;
					return true;
				case AngleSelectorFeature.BottomRight:
					row = points.BottomRightRow;
					column = points.BottomRightColumn;
					return true;
				case AngleSelectorFeature.BottomLeft:
					row = points.BottomLeftRow;
					column = points.BottomLeftColumn;
					return true;
				}
				row = points.CenterRow;
				column = points.CenterColumn;
				result = true;
			}
			return result;
		}

		// Token: 0x06000206 RID: 518 RVA: 0x0000C4D0 File Offset: 0x0000A6D0
		private bool TryGetMinAreaPoint(FindMinAreaResult minArea, AngleSelectorFeature feature, out double row, out double column, out string message)
		{
			row = 0.0;
			column = 0.0;
			message = null;
			bool flag = minArea == null || !minArea.IsSuccess || minArea.SelectedBox == null;
			bool result;
			if (flag)
			{
				message = "Find Min Area result is not available.";
				result = false;
			}
			else
			{
				FindMinAreaPointSet points = minArea.SelectedBox.Points;
				switch (feature)
				{
				case AngleSelectorFeature.TopLeft:
					row = points.TopLeftRow;
					column = points.TopLeftColumn;
					return true;
				case AngleSelectorFeature.TopRight:
					row = points.TopRightRow;
					column = points.TopRightColumn;
					return true;
				case AngleSelectorFeature.BottomRight:
					row = points.BottomRightRow;
					column = points.BottomRightColumn;
					return true;
				case AngleSelectorFeature.BottomLeft:
					row = points.BottomLeftRow;
					column = points.BottomLeftColumn;
					return true;
				}
				row = points.CenterRow;
				column = points.CenterColumn;
				result = true;
			}
			return result;
		}

		// Token: 0x06000207 RID: 519 RVA: 0x0000C5C4 File Offset: 0x0000A7C4
		private double CalculateAngleRadians(double row1, double column1, double row2, double column2, AngleSelectorAxis axis, AngleSelectorQuadrant quadrant)
		{
			double vectorAngle = AngleSelectorProcessor.Normalize0To2Pi(Math.Atan2(row2 - row1, column2 - column1));
			double axisAngle = (axis == AngleSelectorAxis.X) ? 0.0 : 1.5707963267948966;
			bool flag = quadrant == AngleSelectorQuadrant.Auto;
			double result;
			if (flag)
			{
				double angle = Math.Abs(AngleSelectorProcessor.NormalizeToPi(vectorAngle - axisAngle));
				result = angle;
			}
			else
			{
				List<double> bounds = new List<double>
				{
					AngleSelectorProcessor.Normalize0To2Pi(axisAngle),
					AngleSelectorProcessor.Normalize0To2Pi(axisAngle + 3.141592653589793),
					vectorAngle,
					AngleSelectorProcessor.Normalize0To2Pi(vectorAngle + 3.141592653589793)
				};
				bounds.Sort();
				List<Tuple<double, double>> sectors = new List<Tuple<double, double>>
				{
					Tuple.Create<double, double>(bounds[0], bounds[1]),
					Tuple.Create<double, double>(bounds[1], bounds[2]),
					Tuple.Create<double, double>(bounds[2], bounds[3]),
					Tuple.Create<double, double>(bounds[3], bounds[0] + 6.283185307179586)
				};
				int index = Math.Max(0, Math.Min(3, quadrant - AngleSelectorQuadrant.Quadrant1));
				double selected;
				for (selected = sectors[index].Item2 - sectors[index].Item1; selected > 6.283185307179586; selected -= 6.283185307179586)
				{
				}
				result = selected;
			}
			return result;
		}

		// Token: 0x06000208 RID: 520 RVA: 0x0000C744 File Offset: 0x0000A944
		private void ApplyDeltaToResult(ToolVision tool, AngleSelectorResult result)
		{
			ShapeModelToolTrain train = ((tool != null) ? tool.TrainModel : null) as ShapeModelToolTrain;
			bool flag = train == null;
			if (flag)
			{
				train = this.EnsureTrain(tool);
			}
			train.LastRow = result.Row;
			train.LastColumn = result.Column;
			train.LastAngle = result.Angle;
			train.LastScore = result.Score;
			result.HasMasterDefined = train.HasMasterDefined;
			bool flag2 = !train.HasMasterDefined;
			if (!flag2)
			{
				result.DeltaRow = result.Row - train.MasterRow;
				result.DeltaColumn = result.Column - train.MasterColumn;
				result.DeltaAngle = AngleSelectorProcessor.NormalizeToPi(result.Angle - train.MasterAngle);
				result.DeltaAngleDegrees = result.DeltaAngle * 180.0 / 3.141592653589793;
			}
		}

		// Token: 0x06000209 RID: 521 RVA: 0x0000C828 File Offset: 0x0000AA28
		private ShapeModelToolTrain EnsureTrain(ToolVision tool)
		{
			ShapeModelToolTrain train = ((tool != null) ? tool.TrainModel : null) as ShapeModelToolTrain;
			bool flag = train == null && tool != null;
			if (flag)
			{
				train = new ShapeModelToolTrain();
				tool.TrainModel = train;
			}
			return train;
		}

		// Token: 0x0600020A RID: 522 RVA: 0x0000C86C File Offset: 0x0000AA6C
		private static double Normalize0To2Pi(double angle)
		{
			angle %= 6.283185307179586;
			bool flag = angle < 0.0;
			if (flag)
			{
				angle += 6.283185307179586;
			}
			return angle;
		}

		// Token: 0x0600020B RID: 523 RVA: 0x0000C8AC File Offset: 0x0000AAAC
		private static double NormalizeToPi(double angle)
		{
			while (angle <= -3.141592653589793)
			{
				angle += 6.283185307179586;
			}
			while (angle > 3.141592653589793)
			{
				angle -= 6.283185307179586;
			}
			return angle;
		}

		// Token: 0x040000CA RID: 202
		private readonly IDictionary<string, AngleSelectorSourceResult> _cachedSourceResults;

		// Token: 0x040000CB RID: 203
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;
	}
}
