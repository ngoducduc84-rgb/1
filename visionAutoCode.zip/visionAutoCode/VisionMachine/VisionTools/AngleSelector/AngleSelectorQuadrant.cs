﻿using System;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x0200002B RID: 43
	public enum AngleSelectorQuadrant
	{
		// Token: 0x040000D3 RID: 211
		Auto,
		// Token: 0x040000D4 RID: 212
		Quadrant1,
		// Token: 0x040000D5 RID: 213
		Quadrant2,
		// Token: 0x040000D6 RID: 214
		Quadrant3,
		// Token: 0x040000D7 RID: 215
		Quadrant4
	}
}
