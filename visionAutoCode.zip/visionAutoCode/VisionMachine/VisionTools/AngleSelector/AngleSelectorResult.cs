﻿using System;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x0200002C RID: 44
	public class AngleSelectorResult : ShapeMatchResult, IDisposable
	{
		// Token: 0x170000AD RID: 173
		// (get) Token: 0x0600021B RID: 539 RVA: 0x0000CB7F File Offset: 0x0000AD7F
		// (set) Token: 0x0600021C RID: 540 RVA: 0x0000CB87 File Offset: 0x0000AD87
		public string ToolName { get; set; }

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x0600021D RID: 541 RVA: 0x0000CB90 File Offset: 0x0000AD90
		// (set) Token: 0x0600021E RID: 542 RVA: 0x0000CB98 File Offset: 0x0000AD98
		public string FirstObjectToolName { get; set; }

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x0600021F RID: 543 RVA: 0x0000CBA1 File Offset: 0x0000ADA1
		// (set) Token: 0x06000220 RID: 544 RVA: 0x0000CBA9 File Offset: 0x0000ADA9
		public string SecondObjectToolName { get; set; }

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000221 RID: 545 RVA: 0x0000CBB2 File Offset: 0x0000ADB2
		// (set) Token: 0x06000222 RID: 546 RVA: 0x0000CBBA File Offset: 0x0000ADBA
		public AngleSelectorFeature FirstFeature { get; set; }

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000223 RID: 547 RVA: 0x0000CBC3 File Offset: 0x0000ADC3
		// (set) Token: 0x06000224 RID: 548 RVA: 0x0000CBCB File Offset: 0x0000ADCB
		public AngleSelectorFeature SecondFeature { get; set; }

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000225 RID: 549 RVA: 0x0000CBD4 File Offset: 0x0000ADD4
		// (set) Token: 0x06000226 RID: 550 RVA: 0x0000CBDC File Offset: 0x0000ADDC
		public double Point1Row { get; set; }

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x06000227 RID: 551 RVA: 0x0000CBE5 File Offset: 0x0000ADE5
		// (set) Token: 0x06000228 RID: 552 RVA: 0x0000CBED File Offset: 0x0000ADED
		public double Point1Column { get; set; }

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x06000229 RID: 553 RVA: 0x0000CBF6 File Offset: 0x0000ADF6
		// (set) Token: 0x0600022A RID: 554 RVA: 0x0000CBFE File Offset: 0x0000ADFE
		public double Point2Row { get; set; }

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x0600022B RID: 555 RVA: 0x0000CC07 File Offset: 0x0000AE07
		// (set) Token: 0x0600022C RID: 556 RVA: 0x0000CC0F File Offset: 0x0000AE0F
		public double Point2Column { get; set; }

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x0600022D RID: 557 RVA: 0x0000CC18 File Offset: 0x0000AE18
		// (set) Token: 0x0600022E RID: 558 RVA: 0x0000CC20 File Offset: 0x0000AE20
		public double AngleDegrees { get; set; }

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x0600022F RID: 559 RVA: 0x0000CC29 File Offset: 0x0000AE29
		// (set) Token: 0x06000230 RID: 560 RVA: 0x0000CC31 File Offset: 0x0000AE31
		public double DeltaAngleDegrees { get; set; }

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000231 RID: 561 RVA: 0x0000CC3A File Offset: 0x0000AE3A
		// (set) Token: 0x06000232 RID: 562 RVA: 0x0000CC42 File Offset: 0x0000AE42
		public bool DisplayDeltaFromMaster { get; set; }

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000233 RID: 563 RVA: 0x0000CC4B File Offset: 0x0000AE4B
		// (set) Token: 0x06000234 RID: 564 RVA: 0x0000CC53 File Offset: 0x0000AE53
		public bool HasMasterDefined { get; set; }

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x06000235 RID: 565 RVA: 0x0000CC5C File Offset: 0x0000AE5C
		// (set) Token: 0x06000236 RID: 566 RVA: 0x0000CC64 File Offset: 0x0000AE64
		public FindLineResult FirstLineResult { get; set; }

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x06000237 RID: 567 RVA: 0x0000CC6D File Offset: 0x0000AE6D
		// (set) Token: 0x06000238 RID: 568 RVA: 0x0000CC75 File Offset: 0x0000AE75
		public FindLineResult SecondLineResult { get; set; }

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000239 RID: 569 RVA: 0x0000CC7E File Offset: 0x0000AE7E
		// (set) Token: 0x0600023A RID: 570 RVA: 0x0000CC86 File Offset: 0x0000AE86
		public FindCircleResult FirstCircleResult { get; set; }

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x0600023B RID: 571 RVA: 0x0000CC8F File Offset: 0x0000AE8F
		// (set) Token: 0x0600023C RID: 572 RVA: 0x0000CC97 File Offset: 0x0000AE97
		public FindCircleResult SecondCircleResult { get; set; }

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x0600023D RID: 573 RVA: 0x0000CCA0 File Offset: 0x0000AEA0
		// (set) Token: 0x0600023E RID: 574 RVA: 0x0000CCA8 File Offset: 0x0000AEA8
		public FindBoundingBoxResult FirstBoundingBoxResult { get; set; }

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x0600023F RID: 575 RVA: 0x0000CCB1 File Offset: 0x0000AEB1
		// (set) Token: 0x06000240 RID: 576 RVA: 0x0000CCB9 File Offset: 0x0000AEB9
		public FindBoundingBoxResult SecondBoundingBoxResult { get; set; }

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000241 RID: 577 RVA: 0x0000CCC2 File Offset: 0x0000AEC2
		// (set) Token: 0x06000242 RID: 578 RVA: 0x0000CCCA File Offset: 0x0000AECA
		public FindMinAreaResult FirstMinAreaResult { get; set; }

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000243 RID: 579 RVA: 0x0000CCD3 File Offset: 0x0000AED3
		// (set) Token: 0x06000244 RID: 580 RVA: 0x0000CCDB File Offset: 0x0000AEDB
		public FindMinAreaResult SecondMinAreaResult { get; set; }

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x06000245 RID: 581 RVA: 0x0000CCE4 File Offset: 0x0000AEE4
		// (set) Token: 0x06000246 RID: 582 RVA: 0x0000CCEC File Offset: 0x0000AEEC
		public double FirstObjectProcessingTimeMs { get; set; }

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x06000247 RID: 583 RVA: 0x0000CCF5 File Offset: 0x0000AEF5
		// (set) Token: 0x06000248 RID: 584 RVA: 0x0000CCFD File Offset: 0x0000AEFD
		public double SecondObjectProcessingTimeMs { get; set; }

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06000249 RID: 585 RVA: 0x0000CD06 File Offset: 0x0000AF06
		// (set) Token: 0x0600024A RID: 586 RVA: 0x0000CD0E File Offset: 0x0000AF0E
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x0600024B RID: 587 RVA: 0x0000CD18 File Offset: 0x0000AF18
		public void Dispose()
		{
			FindLineResult firstLineResult = this.FirstLineResult;
			if (firstLineResult != null)
			{
				firstLineResult.Dispose();
			}
			FindLineResult secondLineResult = this.SecondLineResult;
			if (secondLineResult != null)
			{
				secondLineResult.Dispose();
			}
			FindCircleResult firstCircleResult = this.FirstCircleResult;
			if (firstCircleResult != null)
			{
				firstCircleResult.Dispose();
			}
			FindCircleResult secondCircleResult = this.SecondCircleResult;
			if (secondCircleResult != null)
			{
				secondCircleResult.Dispose();
			}
			FindBoundingBoxResult firstBoundingBoxResult = this.FirstBoundingBoxResult;
			if (firstBoundingBoxResult != null)
			{
				firstBoundingBoxResult.Dispose();
			}
			FindMinAreaResult firstMinAreaResult = this.FirstMinAreaResult;
			if (firstMinAreaResult != null)
			{
				firstMinAreaResult.Dispose();
			}
			bool flag = this.FirstBoundingBoxResult != this.SecondBoundingBoxResult;
			if (flag)
			{
				FindBoundingBoxResult secondBoundingBoxResult = this.SecondBoundingBoxResult;
				if (secondBoundingBoxResult != null)
				{
					secondBoundingBoxResult.Dispose();
				}
			}
			bool flag2 = this.FirstMinAreaResult != this.SecondMinAreaResult;
			if (flag2)
			{
				FindMinAreaResult secondMinAreaResult = this.SecondMinAreaResult;
				if (secondMinAreaResult != null)
				{
					secondMinAreaResult.Dispose();
				}
			}
		}
	}
}
