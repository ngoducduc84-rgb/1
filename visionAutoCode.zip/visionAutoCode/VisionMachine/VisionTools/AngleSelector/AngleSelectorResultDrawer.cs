﻿using System;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x0200002D RID: 45
	public class AngleSelectorResultDrawer
	{
		// Token: 0x0600024D RID: 589 RVA: 0x0000CDE0 File Offset: 0x0000AFE0
		public void Draw(HWindow window, ToolVision tool, AngleSelectorResult result)
		{
			bool flag = window == null || tool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				AngleSelectorToolConfig config = tool.Config as AngleSelectorToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool showSourceObjects = config.ShowSourceObjects;
					if (showSourceObjects)
					{
						this.DrawSourceObjects(window, tool, result);
					}
					HOperatorSet.SetColor(window, config.DisplayColor);
					HOperatorSet.SetLineWidth(window, 2);
					bool showVector = config.ShowVector;
					if (showVector)
					{
						HOperatorSet.DispLine(window, result.Point1Row, result.Point1Column, result.Point2Row, result.Point2Column);
						HOperatorSet.DispCross(window, result.Point1Row, result.Point1Column, 16, 0);
						HOperatorSet.DispCross(window, result.Point2Row, result.Point2Column, 16, 0);
					}
					bool showAngleGuide = config.ShowAngleGuide;
					if (showAngleGuide)
					{
						this.DrawAngleGuide(window, config, result);
					}
					bool showText = config.ShowText;
					if (showText)
					{
						this.DrawText(window, tool, config, result);
					}
				}
			}
		}

		// Token: 0x0600024E RID: 590 RVA: 0x0000CF38 File Offset: 0x0000B138
		private void DrawSourceObjects(HWindow window, ToolVision tool, AngleSelectorResult result)
		{
			HOperatorSet.SetColor(window, "yellow");
			HOperatorSet.SetLineWidth(window, 2);
			this.DrawBoundingBox(window, tool, result.FirstObjectToolName, result.FirstBoundingBoxResult);
			this.DrawBoundingBox(window, tool, result.SecondObjectToolName, result.SecondBoundingBoxResult);
			this.DrawMinArea(window, tool, result.FirstObjectToolName, result.FirstMinAreaResult);
			this.DrawMinArea(window, tool, result.SecondObjectToolName, result.SecondMinAreaResult);
			HOperatorSet.SetColor(window, "yellow");
			HOperatorSet.SetLineWidth(window, 2);
			this.DrawLine(window, result.FirstLineResult);
			this.DrawLine(window, result.SecondLineResult);
			this.DrawCircle(window, result.FirstCircleResult);
			this.DrawCircle(window, result.SecondCircleResult);
		}

		// Token: 0x0600024F RID: 591 RVA: 0x0000D024 File Offset: 0x0000B224
		private void DrawBoundingBox(HWindow window, ToolVision angleTool, string sourceToolName, FindBoundingBoxResult boxResult)
		{
			bool flag = boxResult == null || !boxResult.IsSuccess || string.IsNullOrWhiteSpace(sourceToolName);
			if (!flag)
			{
				TurnSnap parentTurnSnap = angleTool.ParentTurnSnap;
				ToolVision sourceTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != angleTool).FirstOrDefault((ToolVision x) => x.ToolType == ToolType.FindBoundingBox && string.Equals(x.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)) : null;
				bool flag2 = sourceTool == null;
				if (!flag2)
				{
					new FindBoundingBoxResultDrawer().Draw(window, sourceTool, boxResult);
				}
			}
		}

		// Token: 0x06000250 RID: 592 RVA: 0x0000D0BC File Offset: 0x0000B2BC
		private void DrawMinArea(HWindow window, ToolVision angleTool, string sourceToolName, FindMinAreaResult minAreaResult)
		{
			bool flag = minAreaResult == null || !minAreaResult.IsSuccess || string.IsNullOrWhiteSpace(sourceToolName);
			if (!flag)
			{
				TurnSnap parentTurnSnap = angleTool.ParentTurnSnap;
				ToolVision sourceTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != angleTool).FirstOrDefault((ToolVision x) => x.ToolType == ToolType.FindMinArea && string.Equals(x.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)) : null;
				bool flag2 = sourceTool == null;
				if (!flag2)
				{
					new FindMinAreaResultDrawer().Draw(window, sourceTool, minAreaResult);
				}
			}
		}

		// Token: 0x06000251 RID: 593 RVA: 0x0000D154 File Offset: 0x0000B354
		private void DrawAngleGuide(HWindow window, AngleSelectorToolConfig config, AngleSelectorResult result)
		{
			double centerRow = result.Point1Row;
			double centerColumn = result.Point1Column;
			double vectorAngle = AngleSelectorResultDrawer.Normalize0To2Pi(Math.Atan2(result.Point2Row - result.Point1Row, result.Point2Column - result.Point1Column));
			double axisAngle = (config.CompareAxis == AngleSelectorAxis.X) ? 0.0 : 1.5707963267948966;
			double vectorLength = Math.Sqrt(Math.Pow(result.Point2Row - result.Point1Row, 2.0) + Math.Pow(result.Point2Column - result.Point1Column, 2.0));
			double axisLength = Math.Max(80.0, vectorLength * 1.25);
			double arcRadius = Math.Max(24.0, Math.Min(axisLength * 0.35, 120.0));
			this.DrawReferenceAxis(window, centerRow, centerColumn, axisAngle, axisLength, config.CompareAxis);
			this.DrawSelectedAngleArc(window, centerRow, centerColumn, axisAngle, vectorAngle, arcRadius, config);
		}

		// Token: 0x06000252 RID: 594 RVA: 0x0000D258 File Offset: 0x0000B458
		private void DrawReferenceAxis(HWindow window, double centerRow, double centerColumn, double axisAngle, double length, AngleSelectorAxis axis)
		{
			double rowDelta = Math.Sin(axisAngle) * length;
			double columnDelta = Math.Cos(axisAngle) * length;
			HOperatorSet.SetColor(window, "cyan");
			HOperatorSet.SetLineWidth(window, 1);
			HOperatorSet.DispLine(window, centerRow - rowDelta, centerColumn - columnDelta, centerRow + rowDelta, centerColumn + columnDelta);
			HOperatorSet.SetTposition(window, centerRow + rowDelta + 8.0, centerColumn + columnDelta + 8.0);
			HOperatorSet.WriteString(window, (axis == AngleSelectorAxis.X) ? "X" : "Y");
		}

		// Token: 0x06000253 RID: 595 RVA: 0x0000D324 File Offset: 0x0000B524
		private void DrawSelectedAngleArc(HWindow window, double centerRow, double centerColumn, double axisAngle, double vectorAngle, double radius, AngleSelectorToolConfig config)
		{
			bool flag = config.Quadrant == AngleSelectorQuadrant.Auto;
			double start;
			double end;
			if (flag)
			{
				start = AngleSelectorResultDrawer.Normalize0To2Pi(axisAngle);
				double signedDiff = AngleSelectorResultDrawer.NormalizeToPi(vectorAngle - start);
				end = start + signedDiff;
			}
			else
			{
				Tuple<double, double> sector = this.GetSelectedSector(axisAngle, vectorAngle, config.Quadrant);
				start = sector.Item1;
				end = sector.Item2;
			}
			HObject arc = this.CreateImageCoordinateArc(centerRow, centerColumn, radius, start, end);
			HOperatorSet.SetColor(window, config.DisplayColor);
			HOperatorSet.SetLineWidth(window, 3);
			HOperatorSet.DispObj(arc, window);
			arc.Dispose();
		}

		// Token: 0x06000254 RID: 596 RVA: 0x0000D3CC File Offset: 0x0000B5CC
		private HObject CreateImageCoordinateArc(double centerRow, double centerColumn, double radius, double start, double end)
		{
			double sweep = end - start;
			bool flag = Math.Abs(sweep) < 1E-06;
			if (flag)
			{
				sweep = 6.283185307179586;
			}
			int pointCount = Math.Max(16, (int)(Math.Abs(sweep) * radius / 4.0));
			HTuple rows = new HTuple();
			HTuple columns = new HTuple();
			for (int i = 0; i <= pointCount; i++)
			{
				double t = start + sweep * (double)i / (double)pointCount;
				rows = rows.TupleConcat(centerRow + radius * Math.Sin(t));
				columns = columns.TupleConcat(centerColumn + radius * Math.Cos(t));
			}
			HObject arc;
			HOperatorSet.GenContourPolygonXld(out arc, rows, columns);
			return arc;
		}

		// Token: 0x06000255 RID: 597 RVA: 0x0000D494 File Offset: 0x0000B694
		private Tuple<double, double> GetSelectedSector(double axisAngle, double vectorAngle, AngleSelectorQuadrant quadrant)
		{
			double[] bounds = new double[]
			{
				AngleSelectorResultDrawer.Normalize0To2Pi(axisAngle),
				AngleSelectorResultDrawer.Normalize0To2Pi(axisAngle + 3.141592653589793),
				AngleSelectorResultDrawer.Normalize0To2Pi(vectorAngle),
				AngleSelectorResultDrawer.Normalize0To2Pi(vectorAngle + 3.141592653589793)
			};
			Array.Sort<double>(bounds);
			Tuple<double, double>[] sectors = new Tuple<double, double>[]
			{
				Tuple.Create<double, double>(bounds[0], bounds[1]),
				Tuple.Create<double, double>(bounds[1], bounds[2]),
				Tuple.Create<double, double>(bounds[2], bounds[3]),
				Tuple.Create<double, double>(bounds[3], bounds[0] + 6.283185307179586)
			};
			int index = Math.Max(0, Math.Min(3, quadrant - AngleSelectorQuadrant.Quadrant1));
			return sectors[index];
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0000D548 File Offset: 0x0000B748
		private void DrawLine(HWindow window, FindLineResult line)
		{
			bool flag = line == null || !line.IsSuccess;
			if (!flag)
			{
				HOperatorSet.DispLine(window, line.StartRow, line.StartColumn, line.EndRow, line.EndColumn);
			}
		}

		// Token: 0x06000257 RID: 599 RVA: 0x0000D5A4 File Offset: 0x0000B7A4
		private void DrawCircle(HWindow window, FindCircleResult circle)
		{
			bool flag = circle == null || !circle.IsSuccess;
			if (!flag)
			{
				HOperatorSet.DispCircle(window, circle.Row, circle.Column, circle.Radius);
				HOperatorSet.DispCross(window, circle.Row, circle.Column, 14, 0);
			}
		}

		// Token: 0x06000258 RID: 600 RVA: 0x0000D624 File Offset: 0x0000B824
		private void DrawText(HWindow window, ToolVision tool, AngleSelectorToolConfig config, AngleSelectorResult result)
		{
			try
			{
				HOperatorSet.SetFont(window, "Arial-" + Math.Max(1, config.TextSize).ToString());
			}
			catch
			{
			}
			HOperatorSet.SetColor(window, config.DisplayColor);
			HOperatorSet.SetTposition(window, result.Row, result.Column);
			HOperatorSet.WriteString(window, this.CreateText(tool, result));
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0000D6D0 File Offset: 0x0000B8D0
		private string CreateText(ToolVision tool, AngleSelectorResult result)
		{
			string toolName = string.IsNullOrWhiteSpace((tool != null) ? tool.Name : null) ? "Angle Selector" : tool.Name;
			bool flag = result.DisplayDeltaFromMaster && result.HasMasterDefined;
			string result2;
			if (flag)
			{
				result2 = toolName + " dAngle=" + result.DeltaAngleDegrees.ToString("0.000") + " deg";
			}
			else
			{
				result2 = toolName + " Angle=" + result.AngleDegrees.ToString("0.000") + " deg";
			}
			return result2;
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0000D764 File Offset: 0x0000B964
		private static double Normalize0To2Pi(double angle)
		{
			angle %= 6.283185307179586;
			bool flag = angle < 0.0;
			if (flag)
			{
				angle += 6.283185307179586;
			}
			return angle;
		}

		// Token: 0x0600025B RID: 603 RVA: 0x0000D7A4 File Offset: 0x0000B9A4
		private static double NormalizeToPi(double angle)
		{
			while (angle <= -3.141592653589793)
			{
				angle += 6.283185307179586;
			}
			while (angle > 3.141592653589793)
			{
				angle -= 6.283185307179586;
			}
			return angle;
		}
	}
}
