﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x0200002E RID: 46
	public class AngleSelectorSourceOption
	{
		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x0600025D RID: 605 RVA: 0x0000D7F8 File Offset: 0x0000B9F8
		// (set) Token: 0x0600025E RID: 606 RVA: 0x0000D800 File Offset: 0x0000BA00
		public string ToolName { get; set; }

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x0600025F RID: 607 RVA: 0x0000D809 File Offset: 0x0000BA09
		// (set) Token: 0x06000260 RID: 608 RVA: 0x0000D811 File Offset: 0x0000BA11
		public int Index { get; set; }

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000261 RID: 609 RVA: 0x0000D81A File Offset: 0x0000BA1A
		// (set) Token: 0x06000262 RID: 610 RVA: 0x0000D822 File Offset: 0x0000BA22
		public ToolType ToolType { get; set; }

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000263 RID: 611 RVA: 0x0000D82C File Offset: 0x0000BA2C
		public string DisplayText
		{
			get
			{
				return string.Concat(new string[]
				{
					this.Index.ToString(),
					" - ",
					this.ToolName,
					" (",
					this.ToolType.ToString(),
					")"
				});
			}
		}
	}
}
