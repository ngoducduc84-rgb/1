﻿using System;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x0200002A RID: 42
	public class AngleSelectorSourceResult
	{
		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x0600020C RID: 524 RVA: 0x0000C900 File Offset: 0x0000AB00
		// (set) Token: 0x0600020D RID: 525 RVA: 0x0000C908 File Offset: 0x0000AB08
		public string ToolName { get; set; }

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x0600020E RID: 526 RVA: 0x0000C911 File Offset: 0x0000AB11
		// (set) Token: 0x0600020F RID: 527 RVA: 0x0000C919 File Offset: 0x0000AB19
		public ToolType ToolType { get; set; }

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06000210 RID: 528 RVA: 0x0000C922 File Offset: 0x0000AB22
		// (set) Token: 0x06000211 RID: 529 RVA: 0x0000C92A File Offset: 0x0000AB2A
		public FindLineResult LineResult { get; set; }

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x06000212 RID: 530 RVA: 0x0000C933 File Offset: 0x0000AB33
		// (set) Token: 0x06000213 RID: 531 RVA: 0x0000C93B File Offset: 0x0000AB3B
		public FindCircleResult CircleResult { get; set; }

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x06000214 RID: 532 RVA: 0x0000C944 File Offset: 0x0000AB44
		// (set) Token: 0x06000215 RID: 533 RVA: 0x0000C94C File Offset: 0x0000AB4C
		public FindBoundingBoxResult BoundingBoxResult { get; set; }

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x06000216 RID: 534 RVA: 0x0000C955 File Offset: 0x0000AB55
		// (set) Token: 0x06000217 RID: 535 RVA: 0x0000C95D File Offset: 0x0000AB5D
		public FindMinAreaResult MinAreaResult { get; set; }

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x06000218 RID: 536 RVA: 0x0000C968 File Offset: 0x0000AB68
		public bool IsSuccess
		{
			get
			{
				bool flag = this.ToolType == ToolType.FindLine;
				bool result;
				if (flag)
				{
					result = (this.LineResult != null && this.LineResult.IsSuccess);
				}
				else
				{
					bool flag2 = this.ToolType == ToolType.FindCircle || this.ToolType == ToolType.CircleMaster;
					if (flag2)
					{
						result = (this.CircleResult != null && this.CircleResult.IsSuccess);
					}
					else
					{
						bool flag3 = this.ToolType == ToolType.FindBoundingBox;
						if (flag3)
						{
							result = (this.BoundingBoxResult != null && this.BoundingBoxResult.IsSuccess);
						}
						else
						{
							bool flag4 = this.ToolType == ToolType.FindMinArea;
							result = (flag4 && this.MinAreaResult != null && this.MinAreaResult.IsSuccess);
						}
					}
				}
				return result;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x06000219 RID: 537 RVA: 0x0000CA28 File Offset: 0x0000AC28
		public double ProcessingTimeMs
		{
			get
			{
				bool flag = this.ToolType == ToolType.FindLine && this.LineResult != null;
				double result;
				if (flag)
				{
					result = ((this.LineResult.TotalProcessingTimeMs > 0.0) ? this.LineResult.TotalProcessingTimeMs : this.LineResult.ProcessingTimeMs);
				}
				else
				{
					bool flag2 = (this.ToolType == ToolType.FindCircle || this.ToolType == ToolType.CircleMaster) && this.CircleResult != null;
					if (flag2)
					{
						result = ((this.CircleResult.TotalProcessingTimeMs > 0.0) ? this.CircleResult.TotalProcessingTimeMs : this.CircleResult.ProcessingTimeMs);
					}
					else
					{
						bool flag3 = this.ToolType == ToolType.FindBoundingBox && this.BoundingBoxResult != null;
						if (flag3)
						{
							result = ((this.BoundingBoxResult.TotalProcessingTimeMs > 0.0) ? this.BoundingBoxResult.TotalProcessingTimeMs : this.BoundingBoxResult.ProcessingTimeMs);
						}
						else
						{
							bool flag4 = this.ToolType == ToolType.FindMinArea && this.MinAreaResult != null;
							if (flag4)
							{
								result = ((this.MinAreaResult.TotalProcessingTimeMs > 0.0) ? this.MinAreaResult.TotalProcessingTimeMs : this.MinAreaResult.ProcessingTimeMs);
							}
							else
							{
								result = 0.0;
							}
						}
					}
				}
				return result;
			}
		}
	}
}
