﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.AngleSelector
{
	// Token: 0x0200002F RID: 47
	public class AngleSelectorToolConfig : ToolConfigBase
	{
		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000265 RID: 613 RVA: 0x0000D892 File Offset: 0x0000BA92
		// (set) Token: 0x06000266 RID: 614 RVA: 0x0000D89A File Offset: 0x0000BA9A
		[Category("Object")]
		public string FirstObjectToolName { get; set; }

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000267 RID: 615 RVA: 0x0000D8A3 File Offset: 0x0000BAA3
		// (set) Token: 0x06000268 RID: 616 RVA: 0x0000D8AB File Offset: 0x0000BAAB
		[Category("Object")]
		public AngleSelectorFeature FirstFeature { get; set; } = AngleSelectorFeature.MidPoint;

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x06000269 RID: 617 RVA: 0x0000D8B4 File Offset: 0x0000BAB4
		// (set) Token: 0x0600026A RID: 618 RVA: 0x0000D8BC File Offset: 0x0000BABC
		[Category("Object")]
		public string SecondObjectToolName { get; set; }

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x0600026B RID: 619 RVA: 0x0000D8C5 File Offset: 0x0000BAC5
		// (set) Token: 0x0600026C RID: 620 RVA: 0x0000D8CD File Offset: 0x0000BACD
		[Category("Object")]
		public AngleSelectorFeature SecondFeature { get; set; } = AngleSelectorFeature.CenterPoint;

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x0600026D RID: 621 RVA: 0x0000D8D6 File Offset: 0x0000BAD6
		// (set) Token: 0x0600026E RID: 622 RVA: 0x0000D8DE File Offset: 0x0000BADE
		[Category("Angle")]
		public AngleSelectorAxis CompareAxis { get; set; } = AngleSelectorAxis.X;

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x0600026F RID: 623 RVA: 0x0000D8E7 File Offset: 0x0000BAE7
		// (set) Token: 0x06000270 RID: 624 RVA: 0x0000D8EF File Offset: 0x0000BAEF
		[Category("Angle")]
		public AngleSelectorQuadrant Quadrant { get; set; } = AngleSelectorQuadrant.Auto;

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06000271 RID: 625 RVA: 0x0000D8F8 File Offset: 0x0000BAF8
		// (set) Token: 0x06000272 RID: 626 RVA: 0x0000D900 File Offset: 0x0000BB00
		[Category("Display")]
		public bool ShowSourceObjects { get; set; } = true;

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x06000273 RID: 627 RVA: 0x0000D909 File Offset: 0x0000BB09
		// (set) Token: 0x06000274 RID: 628 RVA: 0x0000D911 File Offset: 0x0000BB11
		[Category("Display")]
		public bool ShowVector { get; set; } = true;

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x06000275 RID: 629 RVA: 0x0000D91A File Offset: 0x0000BB1A
		// (set) Token: 0x06000276 RID: 630 RVA: 0x0000D922 File Offset: 0x0000BB22
		[Category("Display")]
		[DisplayName("Show Angle Guide")]
		public bool ShowAngleGuide { get; set; } = true;

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x06000277 RID: 631 RVA: 0x0000D92B File Offset: 0x0000BB2B
		// (set) Token: 0x06000278 RID: 632 RVA: 0x0000D933 File Offset: 0x0000BB33
		[Category("Display")]
		public bool ShowText { get; set; } = true;

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x06000279 RID: 633 RVA: 0x0000D93C File Offset: 0x0000BB3C
		// (set) Token: 0x0600027A RID: 634 RVA: 0x0000D944 File Offset: 0x0000BB44
		[Category("Display")]
		public int TextSize { get; set; } = 16;

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x0600027B RID: 635 RVA: 0x0000D94D File Offset: 0x0000BB4D
		// (set) Token: 0x0600027C RID: 636 RVA: 0x0000D955 File Offset: 0x0000BB55
		[Category("Display")]
		public string DisplayColor { get; set; } = "green";
	}
}
