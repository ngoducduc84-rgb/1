﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.AngleSelector.Views
{
	// Token: 0x02000030 RID: 48
	public partial class AngleSelector_para : UserControl
	{
		// Token: 0x0600027E RID: 638 RVA: 0x0000D9BF File Offset: 0x0000BBBF
		public AngleSelector_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600027F RID: 639 RVA: 0x0000D9D0 File Offset: 0x0000BBD0
		private void BtnMatching_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.AngleSelectorMatching();
			}
		}

		// Token: 0x06000280 RID: 640 RVA: 0x0000D9E4 File Offset: 0x0000BBE4
		private void BtnMasterDefine_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.AngleSelectorDefineMaster();
			}
		}

		// Token: 0x06000281 RID: 641 RVA: 0x0000D9F8 File Offset: 0x0000BBF8
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.AngleSelectorTrialRun();
			}
		}
	}
}
