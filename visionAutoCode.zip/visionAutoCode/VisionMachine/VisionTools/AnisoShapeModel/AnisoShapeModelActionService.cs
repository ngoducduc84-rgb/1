﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Windows.Threading;
using DevExpress.Xpf.Core;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.AnisoShapeModel
{
	// Token: 0x0200016E RID: 366
	public class AnisoShapeModelActionService : IToolActionService
	{
		// Token: 0x1700073A RID: 1850
		// (get) Token: 0x0600140B RID: 5131 RVA: 0x0005EBEC File Offset: 0x0005CDEC
		public ToolType ToolType
		{
			get
			{
				return ToolType.AnisoShapeModel;
			}
		}

		// Token: 0x0600140C RID: 5132 RVA: 0x0005EC00 File Offset: 0x0005CE00
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			this.Run(context, tool, false, true);
		}

		// Token: 0x0600140D RID: 5133 RVA: 0x0005EC0E File Offset: 0x0005CE0E
		public void Matching(ToolActionContext context, ToolVision tool)
		{
			this.Run(context, tool, false, false);
		}

		// Token: 0x0600140E RID: 5134 RVA: 0x0005EC1C File Offset: 0x0005CE1C
		public void DefineMaster(ToolActionContext context, ToolVision tool)
		{
			this.Run(context, tool, true, false);
		}

		// Token: 0x0600140F RID: 5135 RVA: 0x0005EC2C File Offset: 0x0005CE2C
		private void Run(ToolActionContext context, ToolVision tool, bool defineMaster, bool trialRun)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				bool isRunning = this._isRunning;
				if (!isRunning)
				{
					this._isRunning = true;
					HObject original = null;
					HObject input = null;
					ImageBufferStore bufferStore = null;
					try
					{
						original = context.DisplayController.GetOriginalImage();
						bool flag2 = original == null || !original.IsInitialized();
						if (!flag2)
						{
							bufferStore = new ImageBufferStore();
							ToolProcessContext buildContext = new ToolProcessContext
							{
								OriginalImage = original,
								InputImage = original,
								BufferStore = bufferStore
							};
							string inputSourceToolName = this.GetInputSourceToolName(tool);
							Stopwatch inputStopwatch = Stopwatch.StartNew();
							input = this._pipelineService.BuildInputImageForTool(buildContext, tool);
							inputStopwatch.Stop();
							double inputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
							bool flag3 = input == null || !input.IsInitialized();
							if (flag3)
							{
								bool flag4 = input != null;
								if (flag4)
								{
									input.Dispose();
								}
								HOperatorSet.CopyImage(original, out input);
							}
							AnisoShapeModelToolConfig config = tool.Config as AnisoShapeModelToolConfig;
							ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
							string modelPath = this._processor.GetShapeModelFullPath(tool);
							HObject searchInput = input;
							Stopwatch processStopwatch = Stopwatch.StartNew();
							ShapeMatchResult result = AnisoShapeModelActionService.RunWithUiPump(() => defineMaster ? this._processor.DefineMasterCore(searchInput, tool, config, train, modelPath) : this._processor.MatchCore(searchInput, tool, config, train, modelPath));
							processStopwatch.Stop();
							this.PopulateRuntimeResult(result, tool, inputSourceToolName, inputProcessingTimeMs, processStopwatch.Elapsed.TotalMilliseconds);
							Action<ToolVision, object> resultReporter = context.ResultReporter;
							if (resultReporter != null)
							{
								resultReporter(tool, result);
							}
							context.DisplayController.DisplayImage(input);
							context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
							{
								this._drawer.DrawRoiOverlays(window, tool, result);
								bool flag11 = result != null;
								if (flag11)
								{
									bool trialRun2 = trialRun;
									if (trialRun2)
									{
										this._drawer.DrawTrialResult(tool, window, result);
									}
									else
									{
										this._drawer.DrawMatchResult(tool, window, result);
									}
								}
							}, null);
							bool flag5 = result == null || !result.IsSuccess;
							if (flag5)
							{
								ShapeMatchResult result2 = result;
								string info = ((result2 != null) ? result2.Message : null) ?? "Aniso Shape Model produced no result.";
								bool flag6 = context.ErrorReporter != null;
								if (flag6)
								{
									context.ErrorReporter(info);
								}
								else
								{
									DXMessageBox.Show(info, "Aniso Shape Model");
								}
							}
						}
					}
					catch (Exception ex)
					{
						string message = "Aniso Shape Model run failed: " + ex.Message;
						bool flag7 = context.ErrorReporter != null;
						if (flag7)
						{
							context.ErrorReporter(message);
						}
						else
						{
							DXMessageBox.Show(message, "Aniso Shape Model");
						}
					}
					finally
					{
						bool flag8 = input != null;
						if (flag8)
						{
							input.Dispose();
						}
						bool flag9 = bufferStore != null;
						if (flag9)
						{
							bufferStore.Clear();
						}
						bool flag10 = original != null;
						if (flag10)
						{
							original.Dispose();
						}
						this._isRunning = false;
					}
				}
			}
		}

		// Token: 0x06001410 RID: 5136 RVA: 0x0005EFB8 File Offset: 0x0005D1B8
		private static ShapeMatchResult RunWithUiPump(Func<ShapeMatchResult> work)
		{
			ShapeMatchResult result = null;
			Exception error = null;
			DispatcherFrame frame = new DispatcherFrame();
			Thread thread = new Thread(delegate()
			{
				try
				{
					result = work();
				}
				catch (Exception ex)
				{
					error = ex;
				}
				finally
				{
					frame.Continue = false;
				}
			})
			{
				IsBackground = true
			};
			thread.Start();
			Dispatcher.PushFrame(frame);
			bool flag = error != null;
			if (flag)
			{
				throw error;
			}
			return result;
		}

		// Token: 0x06001411 RID: 5137 RVA: 0x0005F038 File Offset: 0x0005D238
		private void PopulateRuntimeResult(ShapeMatchResult result, ToolVision tool, string inputSourceToolName, double inputProcessingTimeMs, double processingTimeMs)
		{
			bool flag = result == null;
			if (!flag)
			{
				result.InputSourceToolName = inputSourceToolName;
				result.InputProcessingTimeMs = inputProcessingTimeMs;
				result.ProcessingTimeMs = processingTimeMs;
				result.RoiName = this.GetShapeRoiName(tool);
			}
		}

		// Token: 0x06001412 RID: 5138 RVA: 0x0005F078 File Offset: 0x0005D278
		private string GetShapeRoiName(ToolVision tool)
		{
			RoiData roiData;
			if (tool == null)
			{
				roiData = null;
			}
			else
			{
				ObservableCollection<RoiData> roiItems = tool.RoiItems;
				if (roiItems == null)
				{
					roiData = null;
				}
				else
				{
					roiData = roiItems.FirstOrDefault((RoiData x) => x != null && x.IsEnabled);
				}
			}
			RoiData roi = roiData;
			return (roi == null) ? "None" : roi.DisplayName;
		}

		// Token: 0x06001413 RID: 5139 RVA: 0x0005F0D4 File Offset: 0x0005D2D4
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			AnisoShapeModelToolConfig config = ((tool2 != null) ? tool2.Config : null) as AnisoShapeModelToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = link.SourceType.ToString();
					}
				}
			}
			return result;
		}

		// Token: 0x04000856 RID: 2134
		private readonly AnisoShapeModelProcessor _processor = new AnisoShapeModelProcessor();

		// Token: 0x04000857 RID: 2135
		private readonly ShapeModelResultDrawer _drawer = new ShapeModelResultDrawer();

		// Token: 0x04000858 RID: 2136
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();

		// Token: 0x04000859 RID: 2137
		private bool _isRunning;
	}
}
