﻿using System;

namespace VisionMachine.VisionTools.AnisoShapeModel
{
	// Token: 0x02000172 RID: 370
	public enum AnisoShapeModelCoordinateSortMode
	{
		// Token: 0x04000860 RID: 2144
		DetectionOrder,
		// Token: 0x04000861 RID: 2145
		TopToBottomLeftToRight,
		// Token: 0x04000862 RID: 2146
		BottomToTopLeftToRight,
		// Token: 0x04000863 RID: 2147
		TopToBottomZigzag,
		// Token: 0x04000864 RID: 2148
		BottomToTopZigzag
	}
}
