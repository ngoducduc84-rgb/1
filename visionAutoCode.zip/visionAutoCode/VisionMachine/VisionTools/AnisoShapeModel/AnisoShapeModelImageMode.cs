﻿using System;

namespace VisionMachine.VisionTools.AnisoShapeModel
{
	// Token: 0x02000171 RID: 369
	public enum AnisoShapeModelImageMode
	{
		// Token: 0x0400085D RID: 2141
		MultiChannel,
		// Token: 0x0400085E RID: 2142
		Gray
	}
}
