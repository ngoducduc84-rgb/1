﻿using System;
using System.IO;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.AnisoShapeModel
{
	// Token: 0x0200016F RID: 367
	public class AnisoShapeModelPathService
	{
		// Token: 0x06001415 RID: 5141 RVA: 0x0005F1FC File Offset: 0x0005D3FC
		public string GetShapeModelFolder(string turnSnapFolder)
		{
			string folder = Path.Combine(turnSnapFolder, "AnisoShapeModels");
			Directory.CreateDirectory(folder);
			return folder;
		}

		// Token: 0x06001416 RID: 5142 RVA: 0x0005F224 File Offset: 0x0005D424
		public string GetShapeModelFileName(ToolVision tool)
		{
			return "aniso_shape_model_" + tool.ToolId + ".shm";
		}

		// Token: 0x06001417 RID: 5143 RVA: 0x0005F24C File Offset: 0x0005D44C
		public string GetShapeModelFullPath(string turnSnapFolder, ToolVision tool)
		{
			return Path.Combine(this.GetShapeModelFolder(turnSnapFolder), this.GetShapeModelFileName(tool));
		}

		// Token: 0x06001418 RID: 5144 RVA: 0x0005F274 File Offset: 0x0005D474
		public string GetShapeModelRelativePath(ToolVision tool)
		{
			return Path.Combine("AnisoShapeModels", this.GetShapeModelFileName(tool));
		}
	}
}
