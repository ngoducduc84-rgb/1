﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.Services;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.AnisoShapeModel
{
	// Token: 0x02000170 RID: 368
	public class AnisoShapeModelProcessor : IToolProcessor
	{
		// Token: 0x1700073B RID: 1851
		// (get) Token: 0x0600141A RID: 5146 RVA: 0x0005F298 File Offset: 0x0005D498
		public ToolType ToolType
		{
			get
			{
				return ToolType.AnisoShapeModel;
			}
		}

		// Token: 0x0600141B RID: 5147 RVA: 0x0005F2AC File Offset: 0x0005D4AC
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			ToolProcessResult processResult = new ToolProcessResult();
			bool flag = context == null || context.InputImage == null;
			ToolProcessResult result;
			if (flag)
			{
				processResult.IsSuccess = false;
				processResult.Message = "Input image null.";
				result = processResult;
			}
			else
			{
				ShapeMatchResult matchResult = this.Match(context.InputImage, tool);
				processResult.IsSuccess = matchResult.IsSuccess;
				processResult.Message = matchResult.Message;
				processResult.Data = matchResult;
				HObject copy;
				HOperatorSet.CopyImage(context.InputImage, out copy);
				context.OutputImage = copy;
				result = processResult;
			}
			return result;
		}

		// Token: 0x0600141C RID: 5148 RVA: 0x0005F33C File Offset: 0x0005D53C
		public ShapeMatchResult Match(HObject image, ToolVision tool)
		{
			ShapeMatchResult result = new ShapeMatchResult();
			bool flag = tool == null;
			ShapeMatchResult result2;
			if (flag)
			{
				result.Message = "Tool null.";
				result2 = result;
			}
			else
			{
				bool flag2 = image == null || !image.IsInitialized();
				if (flag2)
				{
					result.Message = "No image is available for matching.";
					result2 = result;
				}
				else
				{
					AnisoShapeModelToolConfig config = tool.Config as AnisoShapeModelToolConfig;
					ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
					bool flag3 = config == null || train == null;
					if (flag3)
					{
						result.Message = "The selected tool is not an Aniso Shape Model tool.";
						result2 = result;
					}
					else
					{
						bool flag4 = !train.IsTrained;
						if (flag4)
						{
							result.Message = "The Aniso Shape Model has not been trained.";
							result2 = result;
						}
						else
						{
							string modelPath = this.GetShapeModelFullPath(tool);
							result2 = this.MatchCore(image, tool, config, train, modelPath);
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x0600141D RID: 5149 RVA: 0x0005F40C File Offset: 0x0005D60C
		public ShapeMatchResult MatchCore(HObject image, ToolVision tool, AnisoShapeModelToolConfig config, ShapeModelToolTrain train, string modelPath)
		{
			ShapeMatchResult result = new ShapeMatchResult();
			bool flag = config == null || train == null;
			ShapeMatchResult result2;
			if (flag)
			{
				result.Message = "The selected tool is not an Aniso Shape Model tool.";
				result2 = result;
			}
			else
			{
				bool flag2 = string.IsNullOrWhiteSpace(modelPath) || !File.Exists(modelPath);
				if (flag2)
				{
					result.Message = "Aniso Shape Model file was not found:\n" + modelPath;
					result2 = result;
				}
				else
				{
					HObject preparedImage = null;
					HObject maskedImage = null;
					HObject searchImage = null;
					try
					{
						string cacheKey = tool.ToolId.ToString();
						HTuple modelId = ShapeModelRuntimeCache.GetOrLoad(cacheKey, modelPath);
						preparedImage = this.PrepareImage(image, config);
						maskedImage = this._roiImageService.ApplyMaskRois(preparedImage, tool);
						searchImage = this._roiImageService.ReduceByRois(maskedImage, tool.LimitRoiItems, tool);
						HTuple row;
						HTuple column;
						HTuple angle;
						HTuple scaleRow;
						HTuple scaleColumn;
						HTuple score;
						HOperatorSet.FindAnisoShapeModel(searchImage, modelId, this.NormalizeAngleParameter(config.Angle_Start), this.NormalizeAngleParameter(config.Angle_extent), config.ScaleRowMin, config.ScaleRowMax, config.ScaleColumnMin, config.ScaleColumnMax, config.Min_score, config.Num_matched, config.Max_overlap, "least_squares", config.Num_level, config.Greediness, out row, out column, out angle, out scaleRow, out scaleColumn, out score);
						bool flag3 = row.Length <= 0;
						if (flag3)
						{
							result.IsSuccess = false;
							result.Message = "Aniso Shape Model was not found.";
							result2 = result;
						}
						else
						{
							this.FillCandidates(row, column, angle, scaleRow, scaleColumn, score, result.Matches);
							this.AssignGrid(result.Matches, config.RowSpacing, config.ColumnSpacing);
							this.ApplyMasterDelta(result.Matches, train);
							this.SortAndOrderMatches(result.Matches, config.SortMultiObjectOutput, config.CoordinateSortMode);
							ShapeMatchCandidate selectedMatch = (from x in result.Matches
							where x.GridRow == config.PickRow && x.GridColumn == config.PickColumn
							orderby x.Score descending, x.Index
							select x).FirstOrDefault<ShapeMatchCandidate>();
							bool flag4 = selectedMatch == null;
							if (flag4)
							{
								result.IsSuccess = false;
								result.Message = string.Concat(new string[]
								{
									"Aniso Shape Model was found, but no object exists at Pick Row=",
									config.PickRow.ToString(),
									", Pick Column=",
									config.PickColumn.ToString(),
									"."
								});
								result2 = result;
							}
							else
							{
								result.IsSuccess = true;
								result.GridRow = selectedMatch.GridRow;
								result.GridColumn = selectedMatch.GridColumn;
								result.Row = selectedMatch.Row;
								result.Column = selectedMatch.Column;
								result.Angle = selectedMatch.Angle;
								result.ScaleRow = selectedMatch.ScaleRow;
								result.ScaleColumn = selectedMatch.ScaleColumn;
								result.Score = selectedMatch.Score;
								bool hasMasterDefined = train.HasMasterDefined;
								if (hasMasterDefined)
								{
									result.DeltaRow = result.Row - train.MasterRow;
									result.DeltaColumn = result.Column - train.MasterColumn;
									result.DeltaAngle = result.Angle - train.MasterAngle;
								}
								train.LastRow = result.Row;
								train.LastColumn = result.Column;
								train.LastAngle = result.Angle;
								train.LastScore = result.Score;
								result.Message = string.Concat(new string[]
								{
									"Aniso matching completed successfully. MatchCount=",
									result.MatchCount.ToString(),
									", PickRow=",
									result.GridRow.ToString(),
									", PickColumn=",
									result.GridColumn.ToString(),
									", SortMode=",
									config.CoordinateSortMode.ToString(),
									"."
								});
								result2 = result;
							}
						}
					}
					catch (Exception ex)
					{
						result.IsSuccess = false;
						result.Message = "Aniso matching failed: " + ex.Message;
						result2 = result;
					}
					finally
					{
						bool flag5 = searchImage != null;
						if (flag5)
						{
							searchImage.Dispose();
						}
						bool flag6 = maskedImage != null;
						if (flag6)
						{
							maskedImage.Dispose();
						}
						bool flag7 = preparedImage != null;
						if (flag7)
						{
							preparedImage.Dispose();
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x0600141E RID: 5150 RVA: 0x0005F95C File Offset: 0x0005DB5C
		public ShapeMatchResult TrialRun(HObject image, ToolVision tool)
		{
			return this.Match(image, tool);
		}

		// Token: 0x0600141F RID: 5151 RVA: 0x0005F978 File Offset: 0x0005DB78
		public ShapeMatchResult DefineMaster(HObject image, ToolVision tool)
		{
			return this.ApplyMaster(this.Match(image, tool), tool);
		}

		// Token: 0x06001420 RID: 5152 RVA: 0x0005F99C File Offset: 0x0005DB9C
		public ShapeMatchResult DefineMasterCore(HObject image, ToolVision tool, AnisoShapeModelToolConfig config, ShapeModelToolTrain train, string modelPath)
		{
			return this.ApplyMaster(this.MatchCore(image, tool, config, train, modelPath), tool);
		}

		// Token: 0x06001421 RID: 5153 RVA: 0x0005F9C4 File Offset: 0x0005DBC4
		private ShapeMatchResult ApplyMaster(ShapeMatchResult result, ToolVision tool)
		{
			bool flag = result == null || !result.IsSuccess;
			ShapeMatchResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (flag2)
				{
					result.IsSuccess = false;
					result.Message = "The selected tool does not have a TrainModel.";
					result2 = result;
				}
				else
				{
					train.MasterRow = result.Row;
					train.MasterColumn = result.Column;
					train.MasterAngle = result.Angle;
					train.HasMasterDefined = true;
					result.DeltaRow = 0.0;
					result.DeltaColumn = 0.0;
					result.DeltaAngle = 0.0;
					result.Message = "Aniso master was defined successfully.";
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x06001422 RID: 5154 RVA: 0x0005FA8C File Offset: 0x0005DC8C
		public string GetShapeModelFullPath(ToolVision tool)
		{
			bool flag = tool == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				SettingMasterImageService masterService = new SettingMasterImageService();
				string turnSnapFolder = masterService.GetTurnSnapFolder(tool.ParentTurnSnap);
				bool flag2 = string.IsNullOrWhiteSpace(turnSnapFolder);
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = this._pathService.GetShapeModelFullPath(turnSnapFolder, tool);
				}
			}
			return result;
		}

		// Token: 0x06001423 RID: 5155 RVA: 0x0005FADC File Offset: 0x0005DCDC
		private HObject PrepareImage(HObject image, AnisoShapeModelToolConfig config)
		{
			bool flag = config != null && config.ImageMode == AnisoShapeModelImageMode.Gray;
			HObject result;
			if (flag)
			{
				result = this.ConvertToGray(image);
			}
			else
			{
				HObject copy;
				HOperatorSet.CopyImage(image, out copy);
				result = copy;
			}
			return result;
		}

		// Token: 0x06001424 RID: 5156 RVA: 0x0005FB18 File Offset: 0x0005DD18
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject grayImage;
			if (flag)
			{
				HOperatorSet.Rgb1ToGray(image, out grayImage);
			}
			else
			{
				HOperatorSet.CopyImage(image, out grayImage);
			}
			return grayImage;
		}

		// Token: 0x06001425 RID: 5157 RVA: 0x0005FB70 File Offset: 0x0005DD70
		private double NormalizeAngleParameter(double value)
		{
			return (Math.Abs(value) > 6.283185307179586) ? (value * 3.141592653589793 / 180.0) : value;
		}

		// Token: 0x06001426 RID: 5158 RVA: 0x0005FBAC File Offset: 0x0005DDAC
		private void ApplyMasterDelta(List<ShapeMatchCandidate> candidates, ShapeModelToolTrain train)
		{
			bool flag = candidates == null || train == null || !train.HasMasterDefined;
			if (!flag)
			{
				foreach (ShapeMatchCandidate candidate in candidates)
				{
					candidate.DeltaRow = candidate.Row - train.MasterRow;
					candidate.DeltaColumn = candidate.Column - train.MasterColumn;
					candidate.DeltaAngle = candidate.Angle - train.MasterAngle;
					candidate.HasDelta = true;
				}
			}
		}

		// Token: 0x06001427 RID: 5159 RVA: 0x0005FC58 File Offset: 0x0005DE58
		private void FillCandidates(HTuple rows, HTuple columns, HTuple angles, HTuple scaleRows, HTuple scaleColumns, HTuple scores, List<ShapeMatchCandidate> candidates)
		{
			candidates.Clear();
			for (int i = 0; i < rows.Length; i++)
			{
				candidates.Add(new ShapeMatchCandidate
				{
					Index = i,
					Row = rows[i].D,
					Column = columns[i].D,
					Angle = angles[i].D,
					ScaleRow = scaleRows[i].D,
					ScaleColumn = scaleColumns[i].D,
					Score = scores[i].D
				});
			}
		}

		// Token: 0x06001428 RID: 5160 RVA: 0x0005FD18 File Offset: 0x0005DF18
		private void SortAndOrderMatches(List<ShapeMatchCandidate> candidates, bool sortEnabled, AnisoShapeModelCoordinateSortMode sortMode)
		{
			bool flag = candidates == null || candidates.Count == 0;
			if (!flag)
			{
				bool flag2 = !sortEnabled;
				if (flag2)
				{
					sortMode = AnisoShapeModelCoordinateSortMode.DetectionOrder;
				}
				bool flag3 = sortMode > AnisoShapeModelCoordinateSortMode.DetectionOrder;
				if (flag3)
				{
					bool bottomToTop = sortMode == AnisoShapeModelCoordinateSortMode.BottomToTopLeftToRight || sortMode == AnisoShapeModelCoordinateSortMode.BottomToTopZigzag;
					bool zigzag = sortMode == AnisoShapeModelCoordinateSortMode.TopToBottomZigzag || sortMode == AnisoShapeModelCoordinateSortMode.BottomToTopZigzag;
					List<IGrouping<int, ShapeMatchCandidate>> list;
					if (!bottomToTop)
					{
						list = (from x in candidates
						group x by x.GridRow into x
						orderby x.Key
						select x).ToList<IGrouping<int, ShapeMatchCandidate>>();
					}
					else
					{
						list = (from x in candidates
						group x by x.GridRow into x
						orderby x.Key descending
						select x).ToList<IGrouping<int, ShapeMatchCandidate>>();
					}
					List<IGrouping<int, ShapeMatchCandidate>> rowGroups = list;
					List<ShapeMatchCandidate> ordered = new List<ShapeMatchCandidate>();
					for (int rowIndex = 0; rowIndex < rowGroups.Count; rowIndex++)
					{
						List<ShapeMatchCandidate> list2;
						if (!zigzag || rowIndex % 2 != 1)
						{
							list2 = (from x in rowGroups[rowIndex]
							orderby x.GridColumn, x.Column, x.Row
							select x).ToList<ShapeMatchCandidate>();
						}
						else
						{
							list2 = (from x in rowGroups[rowIndex]
							orderby x.GridColumn descending, x.Column descending, x.Row
							select x).ToList<ShapeMatchCandidate>();
						}
						List<ShapeMatchCandidate> rowItems = list2;
						ordered.AddRange(rowItems);
					}
					candidates.Clear();
					candidates.AddRange(ordered);
				}
				for (int i = 0; i < candidates.Count; i++)
				{
					candidates[i].Order = i + 1;
				}
			}
		}

		// Token: 0x06001429 RID: 5161 RVA: 0x0005FF90 File Offset: 0x0005E190
		private void AssignGrid(List<ShapeMatchCandidate> candidates, double rowSpacing, double columnSpacing)
		{
			bool flag = candidates == null || candidates.Count == 0;
			if (!flag)
			{
				List<double> rowGroups = this.GroupBySpacing(from x in candidates
				select x.Row, rowSpacing);
				List<double> columnGroups = this.GroupBySpacing(from x in candidates
				select x.Column, columnSpacing);
				foreach (ShapeMatchCandidate candidate in candidates)
				{
					candidate.GridRow = this.FindGroupIndex(rowGroups, candidate.Row);
					candidate.GridColumn = this.FindGroupIndex(columnGroups, candidate.Column);
				}
			}
		}

		// Token: 0x0600142A RID: 5162 RVA: 0x0006007C File Offset: 0x0005E27C
		private List<double> GroupBySpacing(IEnumerable<double> values, double spacing)
		{
			List<double> sorted = (from x in values
			orderby x
			select x).ToList<double>();
			List<double> groups = new List<double>();
			foreach (double value in sorted)
			{
				bool flag = groups.Count == 0 || Math.Abs(value - groups[groups.Count - 1]) > spacing;
				if (flag)
				{
					groups.Add(value);
				}
				else
				{
					groups[groups.Count - 1] = (groups[groups.Count - 1] + value) / 2.0;
				}
			}
			return groups;
		}

		// Token: 0x0600142B RID: 5163 RVA: 0x00060160 File Offset: 0x0005E360
		private int FindGroupIndex(List<double> groups, double value)
		{
			bool flag = groups == null || groups.Count == 0;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				double minDistance = double.MaxValue;
				int index = 0;
				for (int i = 0; i < groups.Count; i++)
				{
					double distance = Math.Abs(groups[i] - value);
					bool flag2 = distance < minDistance;
					if (flag2)
					{
						minDistance = distance;
						index = i;
					}
				}
				result = index;
			}
			return result;
		}

		// Token: 0x0400085A RID: 2138
		private readonly AnisoShapeModelPathService _pathService = new AnisoShapeModelPathService();

		// Token: 0x0400085B RID: 2139
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();
	}
}
