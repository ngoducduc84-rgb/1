﻿using System;
using System.ComponentModel;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.AnisoShapeModel
{
	// Token: 0x02000173 RID: 371
	public class AnisoShapeModelToolConfig : ShapeModelToolConfig
	{
		// Token: 0x1700073C RID: 1852
		// (get) Token: 0x0600142D RID: 5165 RVA: 0x000601F8 File Offset: 0x0005E3F8
		// (set) Token: 0x0600142E RID: 5166 RVA: 0x00060210 File Offset: 0x0005E410
		[Category("Parameter")]
		[DisplayName("Image Mode")]
		public AnisoShapeModelImageMode ImageMode
		{
			get
			{
				return this._imageMode;
			}
			set
			{
				bool flag = this._imageMode != value;
				if (flag)
				{
					this._imageMode = value;
					base.OnPropertyChanged("ImageMode");
				}
			}
		}

		// Token: 0x1700073D RID: 1853
		// (get) Token: 0x0600142F RID: 5167 RVA: 0x00060244 File Offset: 0x0005E444
		// (set) Token: 0x06001430 RID: 5168 RVA: 0x0006025C File Offset: 0x0005E45C
		[Category("Parameter")]
		[DisplayName("Scale Row Min")]
		public double ScaleRowMin
		{
			get
			{
				return this._scaleRowMin;
			}
			set
			{
				bool flag = this._scaleRowMin != value;
				if (flag)
				{
					this._scaleRowMin = value;
					base.OnPropertyChanged("ScaleRowMin");
				}
			}
		}

		// Token: 0x1700073E RID: 1854
		// (get) Token: 0x06001431 RID: 5169 RVA: 0x00060290 File Offset: 0x0005E490
		// (set) Token: 0x06001432 RID: 5170 RVA: 0x000602A8 File Offset: 0x0005E4A8
		[Category("Parameter")]
		[DisplayName("Scale Row Max")]
		public double ScaleRowMax
		{
			get
			{
				return this._scaleRowMax;
			}
			set
			{
				bool flag = this._scaleRowMax != value;
				if (flag)
				{
					this._scaleRowMax = value;
					base.OnPropertyChanged("ScaleRowMax");
				}
			}
		}

		// Token: 0x1700073F RID: 1855
		// (get) Token: 0x06001433 RID: 5171 RVA: 0x000602DC File Offset: 0x0005E4DC
		// (set) Token: 0x06001434 RID: 5172 RVA: 0x000602F4 File Offset: 0x0005E4F4
		[Category("Parameter")]
		[DisplayName("Scale Column Min")]
		public double ScaleColumnMin
		{
			get
			{
				return this._scaleColumnMin;
			}
			set
			{
				bool flag = this._scaleColumnMin != value;
				if (flag)
				{
					this._scaleColumnMin = value;
					base.OnPropertyChanged("ScaleColumnMin");
				}
			}
		}

		// Token: 0x17000740 RID: 1856
		// (get) Token: 0x06001435 RID: 5173 RVA: 0x00060328 File Offset: 0x0005E528
		// (set) Token: 0x06001436 RID: 5174 RVA: 0x00060340 File Offset: 0x0005E540
		[Category("Parameter")]
		[DisplayName("Scale Column Max")]
		public double ScaleColumnMax
		{
			get
			{
				return this._scaleColumnMax;
			}
			set
			{
				bool flag = this._scaleColumnMax != value;
				if (flag)
				{
					this._scaleColumnMax = value;
					base.OnPropertyChanged("ScaleColumnMax");
				}
			}
		}

		// Token: 0x17000741 RID: 1857
		// (get) Token: 0x06001437 RID: 5175 RVA: 0x00060374 File Offset: 0x0005E574
		// (set) Token: 0x06001438 RID: 5176 RVA: 0x0006038C File Offset: 0x0005E58C
		[Category("Multi Object")]
		[DisplayName("Coordinate Sort Mode")]
		[Description("Controls the output order of detected multi objects after row/column grouping.")]
		public AnisoShapeModelCoordinateSortMode CoordinateSortMode
		{
			get
			{
				return this._coordinateSortMode;
			}
			set
			{
				bool flag = this._coordinateSortMode != value;
				if (flag)
				{
					this._coordinateSortMode = value;
					base.OnPropertyChanged("CoordinateSortMode");
				}
			}
		}

		// Token: 0x04000865 RID: 2149
		private AnisoShapeModelImageMode _imageMode = AnisoShapeModelImageMode.MultiChannel;

		// Token: 0x04000866 RID: 2150
		private double _scaleRowMin = 0.95;

		// Token: 0x04000867 RID: 2151
		private double _scaleRowMax = 1.05;

		// Token: 0x04000868 RID: 2152
		private double _scaleColumnMin = 0.95;

		// Token: 0x04000869 RID: 2153
		private double _scaleColumnMax = 1.05;

		// Token: 0x0400086A RID: 2154
		private AnisoShapeModelCoordinateSortMode _coordinateSortMode = AnisoShapeModelCoordinateSortMode.TopToBottomLeftToRight;
	}
}
