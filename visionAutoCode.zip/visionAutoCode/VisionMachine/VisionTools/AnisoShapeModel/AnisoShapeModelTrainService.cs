﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Services;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.AnisoShapeModel
{
	// Token: 0x02000174 RID: 372
	public class AnisoShapeModelTrainService
	{
		// Token: 0x0600143A RID: 5178 RVA: 0x00060420 File Offset: 0x0005E620
		public void TrainShapeModel(ToolVision tool, HObject inputImage = null)
		{
			bool flag = tool == null || tool.ParentTurnSnap == null;
			if (!flag)
			{
				AnisoShapeModelToolConfig config = tool.Config as AnisoShapeModelToolConfig;
				ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
				bool flag2 = config == null || train == null;
				if (!flag2)
				{
					SettingMasterImageService masterService = new SettingMasterImageService();
					string turnSnapFolder = masterService.GetTurnSnapFolder(tool.ParentTurnSnap);
					string masterImagePath = masterService.GetMasterImagePath(tool.ParentTurnSnap);
					bool flag3 = string.IsNullOrWhiteSpace(turnSnapFolder);
					if (!flag3)
					{
						bool flag4 = (inputImage == null || !inputImage.IsInitialized()) && (string.IsNullOrWhiteSpace(masterImagePath) || !File.Exists(masterImagePath));
						if (!flag4)
						{
							ObservableCollection<RoiData> roiItems = tool.RoiItems;
							List<RoiData> list;
							if (roiItems == null)
							{
								list = null;
							}
							else
							{
								list = (from r in roiItems
								where r.IsEnabled
								select r).ToList<RoiData>();
							}
							List<RoiData> trainRois = list;
							bool flag5 = trainRois == null || trainRois.Count == 0;
							if (!flag5)
							{
								HObject image = null;
								HObject preparedImage = null;
								HObject maskedImage = null;
								HObject reduceImage = null;
								HObject shapeModelImage = null;
								HObject shapeModelRegion = null;
								HTuple modelId = null;
								try
								{
									bool flag6 = inputImage != null && inputImage.IsInitialized();
									if (flag6)
									{
										HOperatorSet.CopyImage(inputImage, out image);
									}
									else
									{
										HOperatorSet.ReadImage(out image, masterImagePath);
									}
									preparedImage = this.PrepareImage(image, config);
									maskedImage = this._roiImageService.ApplyMaskRois(preparedImage, tool);
									reduceImage = this._roiImageService.ReduceByRois(maskedImage, trainRois, tool);
									try
									{
										HOperatorSet.InspectShapeModel(reduceImage, out shapeModelImage, out shapeModelRegion, 1, train.Threshold_Max);
										tool.ShapeModelPreviewRegion = shapeModelRegion;
										shapeModelRegion = null;
									}
									catch
									{
										if (shapeModelImage != null)
										{
											shapeModelImage.Dispose();
										}
										shapeModelImage = null;
										if (shapeModelRegion != null)
										{
											shapeModelRegion.Dispose();
										}
										shapeModelRegion = null;
									}
									HOperatorSet.CreateAnisoShapeModel(reduceImage, "auto", 0, new HTuple(360).TupleRad(), "auto", config.ScaleRowMin, config.ScaleRowMax, "auto", config.ScaleColumnMin, config.ScaleColumnMax, "auto", "auto", "ignore_color_polarity", train.Threshold_Max, train.Threshold_Min, out modelId);
									string modelFullPath = this._pathService.GetShapeModelFullPath(turnSnapFolder, tool);
									HOperatorSet.WriteShapeModel(modelId, modelFullPath);
									ShapeModelRuntimeCache.ClearByTool(tool.ToolId.ToString());
									train.ShapeModelFileName = Path.GetFileName(modelFullPath);
									train.ShapeModelRelativePath = this._pathService.GetShapeModelRelativePath(tool);
									train.IsTrained = true;
								}
								finally
								{
									if (image != null)
									{
										image.Dispose();
									}
									if (preparedImage != null)
									{
										preparedImage.Dispose();
									}
									if (maskedImage != null)
									{
										maskedImage.Dispose();
									}
									if (reduceImage != null)
									{
										reduceImage.Dispose();
									}
									if (shapeModelImage != null)
									{
										shapeModelImage.Dispose();
									}
									if (shapeModelRegion != null)
									{
										shapeModelRegion.Dispose();
									}
									bool flag7 = modelId != null;
									if (flag7)
									{
										HOperatorSet.ClearShapeModel(modelId);
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x0600143B RID: 5179 RVA: 0x00060788 File Offset: 0x0005E988
		private HObject PrepareImage(HObject image, AnisoShapeModelToolConfig config)
		{
			bool flag = config != null && config.ImageMode == AnisoShapeModelImageMode.Gray;
			HObject result;
			if (flag)
			{
				result = this.ConvertToGray(image);
			}
			else
			{
				HObject copy;
				HOperatorSet.CopyImage(image, out copy);
				result = copy;
			}
			return result;
		}

		// Token: 0x0600143C RID: 5180 RVA: 0x000607C4 File Offset: 0x0005E9C4
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject grayImage;
			if (flag)
			{
				HOperatorSet.Rgb1ToGray(image, out grayImage);
			}
			else
			{
				HOperatorSet.CopyImage(image, out grayImage);
			}
			return grayImage;
		}

		// Token: 0x0400086B RID: 2155
		private readonly AnisoShapeModelPathService _pathService = new AnisoShapeModelPathService();

		// Token: 0x0400086C RID: 2156
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();
	}
}
