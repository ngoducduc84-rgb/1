﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.AnisoShapeModel.Views
{
	// Token: 0x02000175 RID: 373
	public partial class AnisoShape_model_para : System.Windows.Controls.UserControl, IStyleConnector
	{
		// Token: 0x0600143E RID: 5182 RVA: 0x00060839 File Offset: 0x0005EA39
		public AnisoShape_model_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600143F RID: 5183 RVA: 0x0006084C File Offset: 0x0005EA4C
		private void TrainShapeModel_Click(object sender, RoutedEventArgs e)
		{
			ShapeModelParameterPanelViewModel vm = base.DataContext as ShapeModelParameterPanelViewModel;
			bool flag = vm != null;
			if (flag)
			{
				Form_setting instance = Form_setting.Instance;
				if (instance != null)
				{
					instance.ShapeModelTrain(vm.Tool);
				}
			}
		}

		// Token: 0x06001440 RID: 5184 RVA: 0x0005E89D File Offset: 0x0005CA9D
		private void BtnMatching_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.ShapeModelMatching();
			}
		}

		// Token: 0x06001441 RID: 5185 RVA: 0x0005E8B1 File Offset: 0x0005CAB1
		private void BtnMasterDefine_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.ShapeModelDefineMaster();
			}
		}

		// Token: 0x06001442 RID: 5186 RVA: 0x0005E8C5 File Offset: 0x0005CAC5
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.ShapeModelTrialRun();
			}
		}

		// Token: 0x06001443 RID: 5187 RVA: 0x00060888 File Offset: 0x0005EA88
		private void BtnMoreColor_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement button = sender as FrameworkElement;
			object valueSource = (button != null) ? button.Tag : null;
			PropertyInfo valueProperty = (valueSource != null) ? valueSource.GetType().GetProperty("Value") : null;
			bool flag = valueSource == null || valueProperty == null;
			if (!flag)
			{
				ColorDialog dialog = new ColorDialog
				{
					FullOpen = true
				};
				object currentColor = valueProperty.GetValue(valueSource, null);
				string colorText = currentColor as string;
				System.Windows.Media.Color currentMediaColor;
				bool flag2 = colorText != null && this.TryParseColor(colorText, out currentMediaColor);
				if (flag2)
				{
					dialog.Color = System.Drawing.Color.FromArgb((int)currentMediaColor.A, (int)currentMediaColor.R, (int)currentMediaColor.G, (int)currentMediaColor.B);
				}
				bool flag3 = dialog.ShowDialog() != DialogResult.OK;
				if (!flag3)
				{
					System.Windows.Media.Color selectedColor = System.Windows.Media.Color.FromArgb(dialog.Color.A, dialog.Color.R, dialog.Color.G, dialog.Color.B);
					valueProperty.SetValue(valueSource, "#" + selectedColor.R.ToString("X2") + selectedColor.G.ToString("X2") + selectedColor.B.ToString("X2"), null);
				}
			}
		}

		// Token: 0x06001444 RID: 5188 RVA: 0x000609E8 File Offset: 0x0005EBE8
		private bool TryParseColor(string colorText, out System.Windows.Media.Color color)
		{
			color = Colors.White;
			bool flag = string.IsNullOrWhiteSpace(colorText);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(colorText);
					result = true;
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06001447 RID: 5191 RVA: 0x00060B20 File Offset: 0x0005ED20
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((SimpleButton)target).Click += this.BtnMoreColor_Click;
				break;
			case 3:
				((SimpleButton)target).Click += this.BtnMoreColor_Click;
				break;
			case 4:
				((SimpleButton)target).Click += this.BtnMoreColor_Click;
				break;
			}
		}
	}
}
