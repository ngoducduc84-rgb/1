﻿using System;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000D5 RID: 213
	public class BlobActionService : IToolActionService
	{
		// Token: 0x170003AF RID: 943
		// (get) Token: 0x06000AB2 RID: 2738 RVA: 0x0003160C File Offset: 0x0002F80C
		public ToolType ToolType
		{
			get
			{
				return ToolType.Blob;
			}
		}

		// Token: 0x06000AB3 RID: 2739 RVA: 0x00031620 File Offset: 0x0002F820
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				BlobProcessResult blobResult = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (!flag2)
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						Stopwatch inputStopwatch = Stopwatch.StartNew();
						input = this._pipelineService.BuildInputImageForTool(processContext, tool);
						inputStopwatch.Stop();
						double inputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							bool flag4 = input != null;
							if (flag4)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						this.EnsureFullDomainImage(ref input);
						BlobToolConfig config = tool.Config as BlobToolConfig;
						bool flag5 = config != null && config.ShowInputImage;
						if (flag5)
						{
							context.DisplayController.DisplayImage(input);
						}
						else
						{
							blobResult = this._processor.Run(input, tool);
							blobResult.InputSourceToolName = inputSourceToolName;
							blobResult.InputProcessingTimeMs = inputProcessingTimeMs;
							bool flag6 = blobResult.SourceImage != null && blobResult.SourceImage.IsInitialized();
							if (flag6)
							{
								context.DisplayController.DisplayImage(blobResult.SourceImage);
							}
							else
							{
								context.DisplayController.DisplayImage(input);
							}
							bool flag7 = blobResult != null && blobResult.IsSuccess;
							if (flag7)
							{
								Action<ToolVision, object> resultReporter = context.ResultReporter;
								if (resultReporter != null)
								{
									resultReporter(tool, blobResult);
								}
								BlobProcessResult overlayResult = blobResult;
								blobResult = null;
								context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
								{
									this._drawer.Draw(window, tool, overlayResult);
								}, overlayResult);
							}
						}
					}
				}
				finally
				{
					if (blobResult != null)
					{
						blobResult.Dispose();
					}
					bool flag8 = input != null;
					if (flag8)
					{
						input.Dispose();
					}
					bool flag9 = bufferStore != null;
					if (flag9)
					{
						bufferStore.Clear();
					}
					bool flag10 = original != null;
					if (flag10)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06000AB4 RID: 2740 RVA: 0x000318C4 File Offset: 0x0002FAC4
		private void EnsureFullDomainImage(ref HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			if (!flag)
			{
				HObject fullDomainImage;
				HOperatorSet.FullDomain(image, out fullDomainImage);
				image.Dispose();
				image = fullDomainImage;
			}
		}

		// Token: 0x06000AB5 RID: 2741 RVA: 0x00031900 File Offset: 0x0002FB00
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			BlobToolConfig config = ((tool2 != null) ? tool2.Config : null) as BlobToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x04000452 RID: 1106
		private readonly BlobProcessor _processor = new BlobProcessor();

		// Token: 0x04000453 RID: 1107
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();

		// Token: 0x04000454 RID: 1108
		private readonly BlobResultDrawer _drawer = new BlobResultDrawer();
	}
}
