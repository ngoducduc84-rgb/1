﻿using System;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000D8 RID: 216
	public class BlobMasterRuntimeInfo
	{
		// Token: 0x170003C3 RID: 963
		// (get) Token: 0x06000AE2 RID: 2786 RVA: 0x00031DA5 File Offset: 0x0002FFA5
		// (set) Token: 0x06000AE3 RID: 2787 RVA: 0x00031DAD File Offset: 0x0002FFAD
		public string ToolName { get; set; }

		// Token: 0x170003C4 RID: 964
		// (get) Token: 0x06000AE4 RID: 2788 RVA: 0x00031DB6 File Offset: 0x0002FFB6
		// (set) Token: 0x06000AE5 RID: 2789 RVA: 0x00031DBE File Offset: 0x0002FFBE
		public bool IsLinked { get; set; }

		// Token: 0x170003C5 RID: 965
		// (get) Token: 0x06000AE6 RID: 2790 RVA: 0x00031DC7 File Offset: 0x0002FFC7
		// (set) Token: 0x06000AE7 RID: 2791 RVA: 0x00031DCF File Offset: 0x0002FFCF
		public bool IsFound { get; set; }

		// Token: 0x170003C6 RID: 966
		// (get) Token: 0x06000AE8 RID: 2792 RVA: 0x00031DD8 File Offset: 0x0002FFD8
		// (set) Token: 0x06000AE9 RID: 2793 RVA: 0x00031DE0 File Offset: 0x0002FFE0
		public double ProcessingTimeMs { get; set; }
	}
}
