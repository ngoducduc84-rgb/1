﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000D6 RID: 214
	public class BlobParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x170003B0 RID: 944
		// (get) Token: 0x06000AB7 RID: 2743 RVA: 0x00031A18 File Offset: 0x0002FC18
		// (set) Token: 0x06000AB8 RID: 2744 RVA: 0x00031A20 File Offset: 0x0002FC20
		public BlobToolConfig BlobConfig { get; set; }

		// Token: 0x170003B1 RID: 945
		// (get) Token: 0x06000AB9 RID: 2745 RVA: 0x00031A29 File Offset: 0x0002FC29
		// (set) Token: 0x06000ABA RID: 2746 RVA: 0x00031A31 File Offset: 0x0002FC31
		public BlobToolSpec BlobSpec { get; set; }

		// Token: 0x170003B2 RID: 946
		// (get) Token: 0x06000ABB RID: 2747 RVA: 0x00031A3A File Offset: 0x0002FC3A
		// (set) Token: 0x06000ABC RID: 2748 RVA: 0x00031A42 File Offset: 0x0002FC42
		public ToolVision Tool { get; set; }

		// Token: 0x170003B3 RID: 947
		// (get) Token: 0x06000ABD RID: 2749 RVA: 0x00031A4B File Offset: 0x0002FC4B
		// (set) Token: 0x06000ABE RID: 2750 RVA: 0x00031A53 File Offset: 0x0002FC53
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x170003B4 RID: 948
		// (get) Token: 0x06000ABF RID: 2751 RVA: 0x00031A5C File Offset: 0x0002FC5C
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x170003B5 RID: 949
		// (get) Token: 0x06000AC0 RID: 2752 RVA: 0x00031A78 File Offset: 0x0002FC78
		// (set) Token: 0x06000AC1 RID: 2753 RVA: 0x00031A90 File Offset: 0x0002FC90
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool != value;
				if (flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.BlobConfig != null && this.BlobConfig.InputLink != null;
					if (flag2)
					{
						bool flag3 = this._selectedSourceTool != null;
						if (flag3)
						{
							this.BlobConfig.InputLink.SourceToolId = null;
							this.BlobConfig.InputLink.SourceToolName = this._selectedSourceTool.ToolName;
						}
						else
						{
							this.BlobConfig.InputLink.SourceToolId = null;
							this.BlobConfig.InputLink.SourceToolName = null;
						}
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x06000AC2 RID: 2754 RVA: 0x00031B4C File Offset: 0x0002FD4C
		// (remove) Token: 0x06000AC3 RID: 2755 RVA: 0x00031B84 File Offset: 0x0002FD84
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000AC4 RID: 2756 RVA: 0x00031BB9 File Offset: 0x0002FDB9
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x06000AC5 RID: 2757 RVA: 0x00031BD8 File Offset: 0x0002FDD8
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.BlobConfig == null || this.BlobConfig.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.BlobConfig.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.BlobConfig.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.BlobConfig.InputLink.SourceToolId = null;
				this.BlobConfig.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x04000455 RID: 1109
		private ToolImageSourceOption _selectedSourceTool;
	}
}
