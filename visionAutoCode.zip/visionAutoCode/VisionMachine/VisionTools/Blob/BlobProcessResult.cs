﻿using System;
using System.Collections.Generic;
using HalconDotNet;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000D9 RID: 217
	public class BlobProcessResult : IDisposable
	{
		// Token: 0x170003C7 RID: 967
		// (get) Token: 0x06000AEB RID: 2795 RVA: 0x00031DE9 File Offset: 0x0002FFE9
		// (set) Token: 0x06000AEC RID: 2796 RVA: 0x00031DF1 File Offset: 0x0002FFF1
		public bool IsSuccess { get; set; }

		// Token: 0x170003C8 RID: 968
		// (get) Token: 0x06000AED RID: 2797 RVA: 0x00031DFA File Offset: 0x0002FFFA
		// (set) Token: 0x06000AEE RID: 2798 RVA: 0x00031E02 File Offset: 0x00030002
		public HObject SourceImage { get; set; }

		// Token: 0x170003C9 RID: 969
		// (get) Token: 0x06000AEF RID: 2799 RVA: 0x00031E0B File Offset: 0x0003000B
		// (set) Token: 0x06000AF0 RID: 2800 RVA: 0x00031E13 File Offset: 0x00030013
		public bool IsOk { get; set; }

		// Token: 0x170003CA RID: 970
		// (get) Token: 0x06000AF1 RID: 2801 RVA: 0x00031E1C File Offset: 0x0003001C
		// (set) Token: 0x06000AF2 RID: 2802 RVA: 0x00031E24 File Offset: 0x00030024
		public double TotalValue { get; set; }

		// Token: 0x170003CB RID: 971
		// (get) Token: 0x06000AF3 RID: 2803 RVA: 0x00031E2D File Offset: 0x0003002D
		// (set) Token: 0x06000AF4 RID: 2804 RVA: 0x00031E35 File Offset: 0x00030035
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x170003CC RID: 972
		// (get) Token: 0x06000AF5 RID: 2805 RVA: 0x00031E3E File Offset: 0x0003003E
		// (set) Token: 0x06000AF6 RID: 2806 RVA: 0x00031E46 File Offset: 0x00030046
		public string InputSourceToolName { get; set; }

		// Token: 0x170003CD RID: 973
		// (get) Token: 0x06000AF7 RID: 2807 RVA: 0x00031E4F File Offset: 0x0003004F
		// (set) Token: 0x06000AF8 RID: 2808 RVA: 0x00031E57 File Offset: 0x00030057
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x170003CE RID: 974
		// (get) Token: 0x06000AF9 RID: 2809 RVA: 0x00031E60 File Offset: 0x00030060
		// (set) Token: 0x06000AFA RID: 2810 RVA: 0x00031E68 File Offset: 0x00030068
		public string Message { get; set; }

		// Token: 0x170003CF RID: 975
		// (get) Token: 0x06000AFB RID: 2811 RVA: 0x00031E71 File Offset: 0x00030071
		// (set) Token: 0x06000AFC RID: 2812 RVA: 0x00031E79 File Offset: 0x00030079
		public List<BlobRoiResult> RoiResults { get; set; } = new List<BlobRoiResult>();

		// Token: 0x06000AFD RID: 2813 RVA: 0x00031E84 File Offset: 0x00030084
		public void Dispose()
		{
			HObject sourceImage = this.SourceImage;
			if (sourceImage != null)
			{
				sourceImage.Dispose();
			}
			foreach (BlobRoiResult item in this.RoiResults)
			{
				HObject roiObject = item.RoiObject;
				if (roiObject != null)
				{
					roiObject.Dispose();
				}
				HObject displayRoiObject = item.DisplayRoiObject;
				if (displayRoiObject != null)
				{
					displayRoiObject.Dispose();
				}
				HObject thresholdObject = item.ThresholdObject;
				if (thresholdObject != null)
				{
					thresholdObject.Dispose();
				}
			}
		}
	}
}
