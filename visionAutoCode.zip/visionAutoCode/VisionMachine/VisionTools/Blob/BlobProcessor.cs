﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000DA RID: 218
	public class BlobProcessor : IToolProcessor
	{
		// Token: 0x06000AFF RID: 2815 RVA: 0x00031F34 File Offset: 0x00030134
		public BlobProcessor() : this(null)
		{
		}

		// Token: 0x06000B00 RID: 2816 RVA: 0x00031F3F File Offset: 0x0003013F
		public BlobProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x170003D0 RID: 976
		// (get) Token: 0x06000B01 RID: 2817 RVA: 0x00031F50 File Offset: 0x00030150
		public ToolType ToolType
		{
			get
			{
				return ToolType.Blob;
			}
		}

		// Token: 0x06000B02 RID: 2818 RVA: 0x00031F64 File Offset: 0x00030164
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			ToolProcessResult processResult = new ToolProcessResult();
			bool flag = context == null || context.InputImage == null;
			ToolProcessResult result;
			if (flag)
			{
				processResult.IsSuccess = false;
				processResult.Message = "Input image null.";
				result = processResult;
			}
			else
			{
				BlobProcessResult blobResult = this.Run(context.InputImage, tool);
				processResult.IsSuccess = blobResult.IsSuccess;
				processResult.Message = blobResult.Message;
				processResult.Data = blobResult;
				HObject copy;
				HOperatorSet.CopyImage(context.InputImage, out copy);
				context.OutputImage = copy;
				result = processResult;
			}
			return result;
		}

		// Token: 0x06000B03 RID: 2819 RVA: 0x00031FF4 File Offset: 0x000301F4
		public BlobProcessResult Run(HObject image, ToolVision tool)
		{
			BlobProcessResult result = new BlobProcessResult();
			Stopwatch totalStopwatch = Stopwatch.StartNew();
			bool flag = image == null || !image.IsInitialized() || tool == null;
			BlobProcessResult result2;
			if (flag)
			{
				result.Message = "Blob input invalid.";
				result2 = result;
			}
			else
			{
				BlobToolConfig config = tool.Config as BlobToolConfig;
				BlobToolSpec spec = tool.Spec as BlobToolSpec;
				bool flag2 = config == null || spec == null;
				if (flag2)
				{
					result.Message = "Blob config/spec null.";
					result2 = result;
				}
				else
				{
					bool flag3 = tool.RoiItems == null || tool.RoiItems.Count == 0;
					if (flag3)
					{
						result.Message = "Blob has no ROI.";
						result2 = result;
					}
					else
					{
						this._currentMasterRuntimeInfo = this.UpdateMasterShapeModels(image, tool);
						HObject processImage = null;
						HObject thresholdSourceImage = null;
						try
						{
							processImage = this.CreateMaskAppliedImage(image, tool);
							HObject sourceCopy;
							HOperatorSet.CopyImage(processImage, out sourceCopy);
							result.SourceImage = sourceCopy;
							thresholdSourceImage = this.CreateGrayImage(processImage);
							foreach (RoiData roi in from x in tool.RoiItems
							where x.IsEnabled
							select x)
							{
								Stopwatch roiStopwatch = Stopwatch.StartNew();
								HObject roiObject = null;
								HObject displayRoiObject = null;
								HObject reduceImage = null;
								HObject thresholdRegion = null;
								HObject connected = null;
								HObject selected = null;
								try
								{
									roiObject = this.GenRegionFromRoi(roi, tool, thresholdSourceImage, true);
									displayRoiObject = this.GenRegionFromRoi(roi, tool, thresholdSourceImage, false);
									bool flag4 = roiObject == null || !roiObject.IsInitialized();
									if (!flag4)
									{
										HTuple roiCount;
										HOperatorSet.CountObj(roiObject, out roiCount);
										bool flag5 = roiCount.Length == 0 || roiCount[0].I <= 0;
										if (!flag5)
										{
											HTuple roiArea;
											HTuple roiCenterRow;
											HTuple roiCenterColumn;
											HOperatorSet.AreaCenter(roiObject, out roiArea, out roiCenterRow, out roiCenterColumn);
											HOperatorSet.ReduceDomain(thresholdSourceImage, roiObject, out reduceImage);
											thresholdRegion = this.CreateThresholdRegion(reduceImage, roiObject, config);
											HOperatorSet.Connection(thresholdRegion, out connected);
											HOperatorSet.SelectShape(connected, out selected, "area", "and", config.MinArea, config.MaxArea);
											HTuple area;
											HTuple row;
											HTuple column;
											HOperatorSet.AreaCenter(selected, out area, out row, out column);
											double value = (area.Length > 0) ? area.TupleSum().D : 0.0;
											double labelRow = (row.Length > 0) ? row.TupleMean().D : ((roiCenterRow.Length > 0) ? roiCenterRow.TupleMean().D : this.GetFallbackRow(roi));
											double labelColumn = (column.Length > 0) ? column.TupleMean().D : ((roiCenterColumn.Length > 0) ? roiCenterColumn.TupleMean().D : this.GetFallbackColumn(roi));
											HObject roiCopy;
											HOperatorSet.CopyObj(roiObject, out roiCopy, 1, -1);
											bool flag6 = displayRoiObject != null && displayRoiObject.IsInitialized();
											HObject displayRoiCopy;
											if (flag6)
											{
												HOperatorSet.CopyObj(displayRoiObject, out displayRoiCopy, 1, -1);
											}
											else
											{
												HOperatorSet.CopyObj(roiObject, out displayRoiCopy, 1, -1);
											}
											HObject thresholdCopy;
											HOperatorSet.CopyObj(thresholdRegion, out thresholdCopy, 1, -1);
											string masterPositionToolName = this.GetMasterPositionToolName(roi);
											string masterAngleToolName = this.GetMasterAngleToolName(roi);
											result.RoiResults.Add(new BlobRoiResult
											{
												Roi = roi,
												Value = value,
												LabelRow = labelRow,
												LabelColumn = labelColumn,
												RoiObject = roiCopy,
												DisplayRoiObject = displayRoiCopy,
												ThresholdObject = thresholdCopy,
												ProcessingTimeMs = roiStopwatch.Elapsed.TotalMilliseconds,
												MasterPositionToolName = masterPositionToolName,
												MasterAngleToolName = masterAngleToolName,
												MasterStatus = this.GetMasterStatus(masterPositionToolName, masterAngleToolName),
												MasterProcessingTimeMs = this.GetMasterProcessingTime(masterPositionToolName, masterAngleToolName)
											});
											result.TotalValue += value;
										}
									}
								}
								finally
								{
									roiStopwatch.Stop();
									if (roiObject != null)
									{
										roiObject.Dispose();
									}
									if (displayRoiObject != null)
									{
										displayRoiObject.Dispose();
									}
									if (reduceImage != null)
									{
										reduceImage.Dispose();
									}
									if (thresholdRegion != null)
									{
										thresholdRegion.Dispose();
									}
									if (connected != null)
									{
										connected.Dispose();
									}
									if (selected != null)
									{
										selected.Dispose();
									}
								}
							}
						}
						finally
						{
							if (thresholdSourceImage != null)
							{
								thresholdSourceImage.Dispose();
							}
							if (processImage != null)
							{
								processImage.Dispose();
							}
							this._currentMasterRuntimeInfo = null;
						}
						this.ApplySpec(result, spec);
						totalStopwatch.Stop();
						result.TotalProcessingTimeMs = totalStopwatch.Elapsed.TotalMilliseconds;
						result.IsSuccess = true;
						result.Message = this.BuildMessage(result, spec);
						result2 = result;
					}
				}
			}
			return result2;
		}

		// Token: 0x06000B04 RID: 2820 RVA: 0x00032524 File Offset: 0x00030724
		private void ApplySpec(BlobProcessResult result, BlobToolSpec spec)
		{
			bool flag = spec.SpecMode == BlobSpecMode.PerRoi;
			if (flag)
			{
				bool allOk = true;
				foreach (BlobRoiResult roiResult in result.RoiResults)
				{
					roiResult.IsOk = spec.IsWithinSpec(roiResult.Value);
					bool flag2 = !roiResult.IsOk;
					if (flag2)
					{
						allOk = false;
					}
				}
				result.IsOk = allOk;
			}
			else
			{
				result.IsOk = spec.IsWithinSpec(result.TotalValue);
				foreach (BlobRoiResult roiResult2 in result.RoiResults)
				{
					roiResult2.IsOk = result.IsOk;
				}
			}
		}

		// Token: 0x06000B05 RID: 2821 RVA: 0x00032614 File Offset: 0x00030814
		private string BuildMessage(BlobProcessResult result, BlobToolSpec spec)
		{
			bool isOk = result.IsOk;
			string result2;
			if (isOk)
			{
				result2 = "Blob OK.";
			}
			else
			{
				bool flag = spec.SpecMode != BlobSpecMode.PerRoi;
				if (flag)
				{
					result2 = "Blob NG.";
				}
				else
				{
					List<string> failed = (from x in result.RoiResults
					where !x.IsOk
					select x).Select(delegate(BlobRoiResult x)
					{
						RoiData roi = x.Roi;
						return string.IsNullOrWhiteSpace((roi != null) ? roi.Name : null) ? "ROI" : x.Roi.Name;
					}).ToList<string>();
					bool flag2 = failed.Count == 0;
					if (flag2)
					{
						result2 = "Blob NG.";
					}
					else
					{
						result2 = "Blob NG - out of spec: " + string.Join(", ", failed) + ".";
					}
				}
			}
			return result2;
		}

		// Token: 0x06000B06 RID: 2822 RVA: 0x000326DC File Offset: 0x000308DC
		private HObject CreateGrayImage(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject result;
			if (flag)
			{
				HObject grayImage;
				HOperatorSet.Rgb1ToGray(image, out grayImage);
				result = grayImage;
			}
			else
			{
				HObject grayImage;
				HOperatorSet.CopyImage(image, out grayImage);
				result = grayImage;
			}
			return result;
		}

		// Token: 0x06000B07 RID: 2823 RVA: 0x00032734 File Offset: 0x00030934
		private HObject CreateMaskAppliedImage(HObject image, ToolVision tool)
		{
			HObject current;
			HOperatorSet.CopyImage(image, out current);
			bool flag = ((tool != null) ? tool.MaskRoiItems : null) == null || tool.MaskRoiItems.Count == 0;
			HObject result;
			if (flag)
			{
				result = current;
			}
			else
			{
				foreach (RoiData maskRoi in from x in tool.MaskRoiItems
				where x.IsEnabled && x.RoiType != RoiType.Line
				select x)
				{
					HObject maskRegion = null;
					HObject painted = null;
					try
					{
						maskRegion = this.GenRegionFromRoi(maskRoi, tool, current, true);
						bool flag2 = maskRegion == null || !maskRegion.IsInitialized();
						if (!flag2)
						{
							HTuple count;
							HOperatorSet.CountObj(maskRegion, out count);
							bool flag3 = count.Length == 0 || count[0].I <= 0;
							if (!flag3)
							{
								double grayValue = (double)((maskRoi.Polarity == RoiPolarity.Positive) ? 255 : 0);
								painted = this.PaintRegionToImage(current, maskRegion, grayValue);
								current.Dispose();
								current = painted;
								painted = null;
							}
						}
					}
					finally
					{
						if (maskRegion != null)
						{
							maskRegion.Dispose();
						}
						if (painted != null)
						{
							painted.Dispose();
						}
					}
				}
				result = current;
			}
			return result;
		}

		// Token: 0x06000B08 RID: 2824 RVA: 0x000328A4 File Offset: 0x00030AA4
		private HObject PaintRegionToImage(HObject image, HObject region, double grayValue)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject result;
			if (flag)
			{
				result = this.PaintRegionToRgbImage(image, region, grayValue);
			}
			else
			{
				HObject painted;
				HOperatorSet.PaintRegion(region, image, out painted, grayValue, "fill");
				result = painted;
			}
			return result;
		}

		// Token: 0x06000B09 RID: 2825 RVA: 0x00032908 File Offset: 0x00030B08
		private HObject PaintRegionToRgbImage(HObject image, HObject region, double grayValue)
		{
			HObject red = null;
			HObject green = null;
			HObject blue = null;
			HObject paintedRed = null;
			HObject paintedGreen = null;
			HObject paintedBlue = null;
			HObject result = null;
			HObject result2;
			try
			{
				HOperatorSet.Decompose3(image, out red, out green, out blue);
				HOperatorSet.PaintRegion(region, red, out paintedRed, grayValue, "fill");
				HOperatorSet.PaintRegion(region, green, out paintedGreen, grayValue, "fill");
				HOperatorSet.PaintRegion(region, blue, out paintedBlue, grayValue, "fill");
				HOperatorSet.Compose3(paintedRed, paintedGreen, paintedBlue, out result);
				result2 = result;
			}
			finally
			{
				if (red != null)
				{
					red.Dispose();
				}
				if (green != null)
				{
					green.Dispose();
				}
				if (blue != null)
				{
					blue.Dispose();
				}
				if (paintedRed != null)
				{
					paintedRed.Dispose();
				}
				if (paintedGreen != null)
				{
					paintedGreen.Dispose();
				}
				if (paintedBlue != null)
				{
					paintedBlue.Dispose();
				}
			}
			return result2;
		}

		// Token: 0x06000B0A RID: 2826 RVA: 0x000329F8 File Offset: 0x00030BF8
		private HObject CreateThresholdRegion(HObject reduceImage, HObject roiObject, BlobToolConfig config)
		{
			HObject thresholdRegion = null;
			HObject polarityRegion = null;
			HObject fillRegion = null;
			HObject result;
			try
			{
				HOperatorSet.Threshold(reduceImage, out thresholdRegion, config.ThresholdMin, config.ThresholdMax);
				bool flag = config.ThresholdPolarity == BlobThresholdPolarity.LightToDark;
				if (flag)
				{
					HOperatorSet.Difference(roiObject, thresholdRegion, out polarityRegion);
				}
				else
				{
					HOperatorSet.CopyObj(thresholdRegion, out polarityRegion, 1, -1);
				}
				HOperatorSet.FillUp(polarityRegion, out fillRegion);
				HObject resultRegion;
				HOperatorSet.CopyObj(fillRegion, out resultRegion, 1, -1);
				result = resultRegion;
			}
			finally
			{
				if (thresholdRegion != null)
				{
					thresholdRegion.Dispose();
				}
				if (polarityRegion != null)
				{
					polarityRegion.Dispose();
				}
				if (fillRegion != null)
				{
					fillRegion.Dispose();
				}
			}
			return result;
		}

		// Token: 0x06000B0B RID: 2827 RVA: 0x00032ABC File Offset: 0x00030CBC
		private HObject GenRegionFromRoi(RoiData roi, ToolVision tool, HObject image, bool applyMaskMode)
		{
			BlobProcessor.MasterTransform transform = this.GetMasterTransform(roi, tool);
			HObject region;
			switch (roi.RoiType)
			{
			case RoiType.Rectangle1:
				region = this.GenRectangle1Region(roi, transform);
				break;
			case RoiType.Rectangle2:
				region = this.GenRectangle2Region(roi, transform);
				break;
			case RoiType.Circle:
				region = this.GenCircleRegion(roi, transform);
				break;
			case RoiType.Ellipse:
				region = this.GenEllipseRegion(roi, transform);
				break;
			case RoiType.Line:
				region = this.GenLineRegion(roi, transform);
				break;
			case RoiType.Polygon:
			case RoiType.FreeDraw:
			case RoiType.DrawRegion:
				region = this.GenContourRegion(roi, transform);
				break;
			default:
				HOperatorSet.GenEmptyObj(out region);
				break;
			}
			bool flag = !applyMaskMode;
			HObject result;
			if (flag)
			{
				result = region;
			}
			else
			{
				result = this.ApplyMaskMode(region, roi, image);
			}
			return result;
		}

		// Token: 0x06000B0C RID: 2828 RVA: 0x00032B74 File Offset: 0x00030D74
		private HObject GenRectangle1Region(RoiData roi, BlobProcessor.MasterTransform transform)
		{
			double row = Math.Min(roi.Row1, roi.Row2);
			double row2 = Math.Max(roi.Row1, roi.Row2);
			double col = Math.Min(roi.Col1, roi.Col2);
			double col2 = Math.Max(roi.Col1, roi.Col2);
			bool flag = Math.Abs(transform.Angle) < 1E-06;
			HObject region;
			if (flag)
			{
				HOperatorSet.GenRectangle1(out region, row + transform.Row, col + transform.Column, row2 + transform.Row, col2 + transform.Column);
			}
			else
			{
				Tuple<double, double> r1c = this.TransformPoint(row, col, transform);
				Tuple<double, double> r1c2 = this.TransformPoint(row, col2, transform);
				Tuple<double, double> r2c2 = this.TransformPoint(row2, col2, transform);
				Tuple<double, double> r2c3 = this.TransformPoint(row2, col, transform);
				region = this.GenContourRegion(new double[]
				{
					r1c.Item1,
					r1c2.Item1,
					r2c2.Item1,
					r2c3.Item1
				}, new double[]
				{
					r1c.Item2,
					r1c2.Item2,
					r2c2.Item2,
					r2c3.Item2
				}, true);
			}
			return region;
		}

		// Token: 0x06000B0D RID: 2829 RVA: 0x00032CC8 File Offset: 0x00030EC8
		private HObject GenRectangle2Region(RoiData roi, BlobProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenRectangle2(out region, center.Item1, center.Item2, roi.Phi + transform.Angle, roi.Radius1, roi.Radius2);
			return region;
		}

		// Token: 0x06000B0E RID: 2830 RVA: 0x00032D38 File Offset: 0x00030F38
		private HObject GenCircleRegion(RoiData roi, BlobProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenCircle(out region, center.Item1, center.Item2, roi.Radius);
			return region;
		}

		// Token: 0x06000B0F RID: 2831 RVA: 0x00032D88 File Offset: 0x00030F88
		private HObject GenEllipseRegion(RoiData roi, BlobProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenEllipse(out region, center.Item1, center.Item2, roi.Phi + transform.Angle, roi.Radius1, roi.Radius2);
			return region;
		}

		// Token: 0x06000B10 RID: 2832 RVA: 0x00032DF8 File Offset: 0x00030FF8
		private HObject GenLineRegion(RoiData roi, BlobProcessor.MasterTransform transform)
		{
			HObject line = null;
			HObject region = null;
			HObject result;
			try
			{
				Tuple<double, double> p = this.TransformPoint(roi.Row1, roi.Col1, transform);
				Tuple<double, double> p2 = this.TransformPoint(roi.Row2, roi.Col2, transform);
				HOperatorSet.GenRegionLine(out line, p.Item1, p.Item2, p2.Item1, p2.Item2);
				HOperatorSet.DilationCircle(line, out region, 1.5);
				result = region;
			}
			finally
			{
				if (line != null)
				{
					line.Dispose();
				}
			}
			return result;
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x00032EA4 File Offset: 0x000310A4
		private HObject GenContourRegion(RoiData roi, BlobProcessor.MasterTransform transform)
		{
			bool flag = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 3 || roi.Rows.Count != roi.Cols.Count;
			HObject result;
			if (flag)
			{
				HObject region;
				HOperatorSet.GenEmptyObj(out region);
				result = region;
			}
			else
			{
				double[] rows = new double[roi.Rows.Count];
				double[] cols = new double[roi.Cols.Count];
				for (int i = 0; i < roi.Rows.Count; i++)
				{
					Tuple<double, double> point = this.TransformPoint(roi.Rows[i], roi.Cols[i], transform);
					rows[i] = point.Item1;
					cols[i] = point.Item2;
				}
				result = this.GenContourRegion(rows, cols, false);
			}
			return result;
		}

		// Token: 0x06000B12 RID: 2834 RVA: 0x00032F90 File Offset: 0x00031190
		private HObject GenContourRegion(double[] rows, double[] cols, bool closeContour)
		{
			bool flag = rows == null || cols == null || rows.Length < 3 || rows.Length != cols.Length;
			HObject result;
			if (flag)
			{
				HObject region;
				HOperatorSet.GenEmptyObj(out region);
				result = region;
			}
			else
			{
				HObject contour = null;
				HObject region;
				try
				{
					HTuple contourRows = new HTuple(rows);
					HTuple contourCols = new HTuple(cols);
					if (closeContour)
					{
						contourRows = contourRows.TupleConcat(rows[0]);
						contourCols = contourCols.TupleConcat(cols[0]);
					}
					HOperatorSet.GenContourPolygonXld(out contour, contourRows, contourCols);
					HOperatorSet.GenRegionContourXld(contour, out region, "filled");
				}
				finally
				{
					if (contour != null)
					{
						contour.Dispose();
					}
				}
				result = region;
			}
			return result;
		}

		// Token: 0x06000B13 RID: 2835 RVA: 0x00033050 File Offset: 0x00031250
		private HObject ApplyMaskMode(HObject roiRegion, RoiData roi, HObject image)
		{
			bool flag = roiRegion == null || !roiRegion.IsInitialized() || roi == null || roi.MaskMode != RoiMaskMode.Outside || image == null || !image.IsInitialized();
			HObject result;
			if (flag)
			{
				result = roiRegion;
			}
			else
			{
				HObject fullRegion = null;
				HObject outsideRegion = null;
				try
				{
					HTuple width;
					HTuple height;
					HOperatorSet.GetImageSize(image, out width, out height);
					HOperatorSet.GenRectangle1(out fullRegion, 0, 0, height.D - 1.0, width.D - 1.0);
					HOperatorSet.Difference(fullRegion, roiRegion, out outsideRegion);
					roiRegion.Dispose();
					result = outsideRegion;
				}
				finally
				{
					if (fullRegion != null)
					{
						fullRegion.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x06000B14 RID: 2836 RVA: 0x00033114 File Offset: 0x00031314
		private BlobProcessor.MasterTransform GetMasterTransform(RoiData roi, ToolVision tool)
		{
			BlobProcessor.MasterTransform transform = new BlobProcessor.MasterTransform();
			bool flag = roi == null || ((tool != null) ? tool.ParentTurnSnap : null) == null;
			BlobProcessor.MasterTransform result;
			if (flag)
			{
				result = transform;
			}
			else
			{
				ShapeModelToolTrain positionTrain = this.GetMasterTrain(tool, this.GetMasterPositionToolName(roi), true);
				bool flag2 = positionTrain != null;
				if (flag2)
				{
					transform.Row = positionTrain.LastRow - positionTrain.MasterRow;
					transform.Column = positionTrain.LastColumn - positionTrain.MasterColumn;
				}
				ShapeModelToolTrain angleTrain = this.GetMasterTrain(tool, this.GetMasterAngleToolName(roi), false);
				bool flag3 = angleTrain != null;
				if (flag3)
				{
					transform.Angle = angleTrain.LastAngle - angleTrain.MasterAngle;
					transform.MasterRow = angleTrain.MasterRow;
					transform.MasterColumn = angleTrain.MasterColumn;
				}
				result = transform;
			}
			return result;
		}

		// Token: 0x06000B15 RID: 2837 RVA: 0x000331E0 File Offset: 0x000313E0
		private ShapeModelToolTrain GetMasterTrain(ToolVision tool, string masterToolName, bool isPositionMaster)
		{
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || string.IsNullOrWhiteSpace(masterToolName) || masterToolName == "None";
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				BlobMasterRuntimeInfo runtimeInfo;
				bool flag2 = this._currentMasterRuntimeInfo != null && this._currentMasterRuntimeInfo.TryGetValue(masterToolName, out runtimeInfo) && !runtimeInfo.IsFound;
				if (flag2)
				{
					result = null;
				}
				else
				{
					ToolVision masterTool = tool.ParentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || (isPositionMaster && x.ToolType == ToolType.CircleMaster) || (isPositionMaster && x.ToolType == ToolType.BoundingBoxMaster) || (x.ToolType == ToolType.MinAreaMaster || (isPositionMaster && x.ToolType == ToolType.IntersectingLines)) || (!isPositionMaster && x.ToolType == ToolType.AngleSelector)) && x.Name == masterToolName);
					ShapeModelToolTrain train = ((masterTool != null) ? masterTool.TrainModel : null) as ShapeModelToolTrain;
					bool flag3 = train == null || !train.HasMasterDefined;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = train;
					}
				}
			}
			return result;
		}

		// Token: 0x06000B16 RID: 2838 RVA: 0x000332E8 File Offset: 0x000314E8
		private string GetMasterPositionToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && roi.MasterPositionToolName != "None";
				if (flag2)
				{
					result = roi.MasterPositionToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x06000B17 RID: 2839 RVA: 0x00033378 File Offset: 0x00031578
		private string GetMasterAngleToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && roi.MasterAngleToolName != "None";
				if (flag2)
				{
					result = roi.MasterAngleToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x06000B18 RID: 2840 RVA: 0x00033408 File Offset: 0x00031608
		private string GetMasterStatus(string masterPositionToolName, string masterAngleToolName)
		{
			List<string> masterNames = this.GetDistinctMasterNames(masterPositionToolName, masterAngleToolName);
			bool flag = masterNames.Count == 0;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				foreach (string masterName in masterNames)
				{
					BlobMasterRuntimeInfo info;
					bool flag2 = this._currentMasterRuntimeInfo == null || !this._currentMasterRuntimeInfo.TryGetValue(masterName, out info) || !info.IsFound;
					if (flag2)
					{
						return "Lost Master";
					}
				}
				result = "OK";
			}
			return result;
		}

		// Token: 0x06000B19 RID: 2841 RVA: 0x000334B4 File Offset: 0x000316B4
		private double GetMasterProcessingTime(string masterPositionToolName, string masterAngleToolName)
		{
			double processingTime = 0.0;
			foreach (string masterName in this.GetDistinctMasterNames(masterPositionToolName, masterAngleToolName))
			{
				BlobMasterRuntimeInfo info;
				bool flag = this._currentMasterRuntimeInfo != null && this._currentMasterRuntimeInfo.TryGetValue(masterName, out info);
				if (flag)
				{
					processingTime += info.ProcessingTimeMs;
				}
			}
			return processingTime;
		}

		// Token: 0x06000B1A RID: 2842 RVA: 0x00033544 File Offset: 0x00031744
		private List<string> GetDistinctMasterNames(string masterPositionToolName, string masterAngleToolName)
		{
			return (from x in new string[]
			{
				masterPositionToolName,
				masterAngleToolName
			}
			where !string.IsNullOrWhiteSpace(x) && x != "None"
			select x).Distinct<string>().ToList<string>();
		}

		// Token: 0x06000B1B RID: 2843 RVA: 0x00033594 File Offset: 0x00031794
		private Tuple<double, double> TransformPoint(double row, double column, BlobProcessor.MasterTransform transform)
		{
			bool flag = transform == null;
			Tuple<double, double> result;
			if (flag)
			{
				result = Tuple.Create<double, double>(row, column);
			}
			else
			{
				double cos = Math.Cos(transform.Angle);
				double sin = Math.Sin(transform.Angle);
				double relRow = row - transform.MasterRow;
				double relColumn = column - transform.MasterColumn;
				double newRow = transform.MasterRow + transform.Row + relRow * cos - relColumn * sin;
				double newColumn = transform.MasterColumn + transform.Column + relRow * sin + relColumn * cos;
				result = Tuple.Create<double, double>(newRow, newColumn);
			}
			return result;
		}

		// Token: 0x06000B1C RID: 2844 RVA: 0x00033620 File Offset: 0x00031820
		private Dictionary<string, BlobMasterRuntimeInfo> UpdateMasterShapeModels(HObject image, ToolVision tool)
		{
			Dictionary<string, BlobMasterRuntimeInfo> runtimeInfo = new Dictionary<string, BlobMasterRuntimeInfo>();
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null;
			Dictionary<string, BlobMasterRuntimeInfo> result;
			if (flag)
			{
				result = runtimeInfo;
			}
			else
			{
				List<RoiData> roiItems = new List<RoiData>();
				bool flag2 = tool.RoiItems != null;
				if (flag2)
				{
					roiItems.AddRange(tool.RoiItems);
				}
				bool flag3 = tool.MaskRoiItems != null;
				if (flag3)
				{
					roiItems.AddRange(tool.MaskRoiItems);
				}
				List<string> masterNames = (from x in (from x in roiItems
				where x.IsEnabled
				select x).SelectMany((RoiData x) => new string[]
				{
					this.GetMasterPositionToolName(x),
					this.GetMasterAngleToolName(x)
				})
				where !string.IsNullOrWhiteSpace(x) && x != "None"
				select x).Distinct<string>().ToList<string>();
				bool flag4 = masterNames.Count == 0;
				if (flag4)
				{
					result = runtimeInfo;
				}
				else
				{
					ShapeModelProcessor shapeProcessor = new ShapeModelProcessor();
					using (List<string>.Enumerator enumerator = masterNames.GetEnumerator())
					{
						Func<ToolVision, bool> <>9__3;
						while (enumerator.MoveNext())
						{
							string masterName = enumerator.Current;
							BlobMasterRuntimeInfo info = new BlobMasterRuntimeInfo
							{
								ToolName = masterName,
								IsLinked = true
							};
							Stopwatch stopwatch = Stopwatch.StartNew();
							IEnumerable<ToolVision> tools = tool.ParentTurnSnap.Tools;
							Func<ToolVision, bool> predicate;
							if ((predicate = <>9__3) == null)
							{
								predicate = (<>9__3 = ((ToolVision x) => x != tool));
							}
							ToolVision masterTool = tools.TakeWhile(predicate).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.BoundingBoxMaster || x.ToolType == ToolType.MinAreaMaster || x.ToolType == ToolType.IntersectingLines || x.ToolType == ToolType.AngleSelector) && x.Name == masterName);
							bool flag5 = masterTool == null;
							if (flag5)
							{
								stopwatch.Stop();
								info.IsFound = false;
								info.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
								runtimeInfo[masterName] = info;
							}
							else
							{
								ShapeMatchResult matchResult;
								bool flag6 = this.TryGetCachedMasterResult(masterName, out matchResult);
								if (flag6)
								{
									this.ApplyMasterResultToTrain(masterTool, matchResult);
									stopwatch.Stop();
									info.IsFound = matchResult.IsSuccess;
									info.ProcessingTimeMs = Math.Max(0.0, matchResult.ProcessingTimeMs);
									runtimeInfo[masterName] = info;
								}
								else
								{
									bool flag7 = masterTool.ToolType == ToolType.CircleMaster;
									if (flag7)
									{
										matchResult = new CircleMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
									}
									else
									{
										bool flag8 = masterTool.ToolType == ToolType.BoundingBoxMaster;
										if (flag8)
										{
											matchResult = new BoundingBoxMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
										}
										else
										{
											bool flag9 = masterTool.ToolType == ToolType.MinAreaMaster;
											if (flag9)
											{
												matchResult = new MinAreaMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
											}
											else
											{
												bool flag10 = masterTool.ToolType == ToolType.IntersectingLines;
												if (flag10)
												{
													matchResult = new IntersectingLinesProcessor(null, this._cachedMasterResults).Match(image, masterTool);
												}
												else
												{
													bool flag11 = masterTool.ToolType == ToolType.AngleSelector;
													if (flag11)
													{
														matchResult = new AngleSelectorProcessor(null, this._cachedMasterResults).Match(image, masterTool);
													}
													else
													{
														matchResult = shapeProcessor.Match(image, masterTool);
													}
												}
											}
										}
									}
									stopwatch.Stop();
									info.IsFound = (matchResult != null && matchResult.IsSuccess);
									info.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
									runtimeInfo[masterName] = info;
								}
							}
						}
					}
					result = runtimeInfo;
				}
			}
			return result;
		}

		// Token: 0x06000B1D RID: 2845 RVA: 0x000339F8 File Offset: 0x00031BF8
		private bool TryGetCachedMasterResult(string masterName, out ShapeMatchResult result)
		{
			result = null;
			bool flag = this._cachedMasterResults == null || string.IsNullOrWhiteSpace(masterName);
			return !flag && this._cachedMasterResults.TryGetValue(masterName, out result) && result != null;
		}

		// Token: 0x06000B1E RID: 2846 RVA: 0x00033A40 File Offset: 0x00031C40
		private void ApplyMasterResultToTrain(ToolVision masterTool, ShapeMatchResult result)
		{
			bool flag = masterTool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				ShapeModelToolTrain train = masterTool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (!flag2)
				{
					train.LastRow = result.Row;
					train.LastColumn = result.Column;
					train.LastAngle = result.Angle;
					train.LastScore = result.Score;
				}
			}
		}

		// Token: 0x06000B1F RID: 2847 RVA: 0x00033AB4 File Offset: 0x00031CB4
		private double GetFallbackRow(RoiData roi)
		{
			bool flag = roi.RoiType == RoiType.Rectangle1;
			double result;
			if (flag)
			{
				result = Math.Min(roi.Row1, roi.Row2);
			}
			else
			{
				bool flag2 = roi.RoiType == RoiType.Polygon || roi.RoiType == RoiType.FreeDraw || roi.RoiType == RoiType.DrawRegion;
				if (flag2)
				{
					result = ((roi.Rows != null && roi.Rows.Count > 0) ? roi.Rows.Min() : 0.0);
				}
				else
				{
					result = roi.CenterRow;
				}
			}
			return result;
		}

		// Token: 0x06000B20 RID: 2848 RVA: 0x00033B40 File Offset: 0x00031D40
		private double GetFallbackColumn(RoiData roi)
		{
			bool flag = roi.RoiType == RoiType.Rectangle1;
			double result;
			if (flag)
			{
				result = Math.Min(roi.Col1, roi.Col2);
			}
			else
			{
				bool flag2 = roi.RoiType == RoiType.Polygon || roi.RoiType == RoiType.FreeDraw || roi.RoiType == RoiType.DrawRegion;
				if (flag2)
				{
					result = ((roi.Cols != null && roi.Cols.Count > 0) ? roi.Cols.Min() : 0.0);
				}
				else
				{
					result = roi.CenterCol;
				}
			}
			return result;
		}

		// Token: 0x04000475 RID: 1141
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;

		// Token: 0x04000476 RID: 1142
		private Dictionary<string, BlobMasterRuntimeInfo> _currentMasterRuntimeInfo;

		// Token: 0x02000336 RID: 822
		private class MasterTransform
		{
			// Token: 0x17000B5B RID: 2907
			// (get) Token: 0x06002821 RID: 10273 RVA: 0x000E0F49 File Offset: 0x000DF149
			// (set) Token: 0x06002822 RID: 10274 RVA: 0x000E0F51 File Offset: 0x000DF151
			public double Row { get; set; }

			// Token: 0x17000B5C RID: 2908
			// (get) Token: 0x06002823 RID: 10275 RVA: 0x000E0F5A File Offset: 0x000DF15A
			// (set) Token: 0x06002824 RID: 10276 RVA: 0x000E0F62 File Offset: 0x000DF162
			public double Column { get; set; }

			// Token: 0x17000B5D RID: 2909
			// (get) Token: 0x06002825 RID: 10277 RVA: 0x000E0F6B File Offset: 0x000DF16B
			// (set) Token: 0x06002826 RID: 10278 RVA: 0x000E0F73 File Offset: 0x000DF173
			public double Angle { get; set; }

			// Token: 0x17000B5E RID: 2910
			// (get) Token: 0x06002827 RID: 10279 RVA: 0x000E0F7C File Offset: 0x000DF17C
			// (set) Token: 0x06002828 RID: 10280 RVA: 0x000E0F84 File Offset: 0x000DF184
			public double MasterRow { get; set; }

			// Token: 0x17000B5F RID: 2911
			// (get) Token: 0x06002829 RID: 10281 RVA: 0x000E0F8D File Offset: 0x000DF18D
			// (set) Token: 0x0600282A RID: 10282 RVA: 0x000E0F95 File Offset: 0x000DF195
			public double MasterColumn { get; set; }
		}
	}
}
