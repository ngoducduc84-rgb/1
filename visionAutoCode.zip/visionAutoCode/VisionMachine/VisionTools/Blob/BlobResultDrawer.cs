﻿using System;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000DB RID: 219
	public class BlobResultDrawer
	{
		// Token: 0x06000B21 RID: 2849 RVA: 0x00033BCA File Offset: 0x00031DCA
		public void Draw(HWindow window, ToolVision tool, BlobProcessResult result)
		{
			this.Draw(window, tool, result, true);
		}

		// Token: 0x06000B22 RID: 2850 RVA: 0x00033BD8 File Offset: 0x00031DD8
		public void Draw(HWindow window, ToolVision tool, BlobProcessResult result, bool showTotalText)
		{
			this.Draw(window, tool, result, showTotalText, true);
		}

		// Token: 0x06000B23 RID: 2851 RVA: 0x00033BE8 File Offset: 0x00031DE8
		public void Draw(HWindow window, ToolVision tool, BlobProcessResult result, bool showTotalText, bool fillThreshold)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				BlobToolConfig config = tool.Config as BlobToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool showThreshold = config.ShowThreshold;
					if (showThreshold)
					{
						this.DrawThreshold(window, result, fillThreshold);
					}
					bool showRoi = config.ShowRoi;
					if (showRoi)
					{
						this.DrawRois(window, result);
					}
					bool showRoiIndex = config.ShowRoiIndex;
					if (showRoiIndex)
					{
						this.DrawRoiIndexes(window, result, config);
					}
					this.DrawResultText(window, tool, result, showTotalText, config.ShowValueText);
				}
			}
		}

		// Token: 0x06000B24 RID: 2852 RVA: 0x00033C74 File Offset: 0x00031E74
		private void DrawThreshold(HWindow window, BlobProcessResult result, bool fillThreshold)
		{
			bool flag = result.RoiResults == null || result.RoiResults.Count == 0;
			if (!flag)
			{
				HObject thresholdObjects = null;
				HObject thresholdRegion = null;
				try
				{
					HOperatorSet.GenEmptyObj(out thresholdObjects);
					foreach (BlobRoiResult roiResult in result.RoiResults)
					{
						bool flag2 = roiResult.ThresholdObject == null || !roiResult.ThresholdObject.IsInitialized();
						if (!flag2)
						{
							HObject concat;
							HOperatorSet.ConcatObj(thresholdObjects, roiResult.ThresholdObject, out concat);
							thresholdObjects.Dispose();
							thresholdObjects = concat;
						}
					}
					HTuple count;
					HOperatorSet.CountObj(thresholdObjects, out count);
					bool flag3 = count.Length == 0 || count[0].I <= 0;
					if (!flag3)
					{
						HOperatorSet.Union1(thresholdObjects, out thresholdRegion);
						HOperatorSet.SetDraw(window, fillThreshold ? "fill" : "margin");
						HOperatorSet.SetLineWidth(window, 1);
						HOperatorSet.SetColor(window, "orange");
						HOperatorSet.DispObj(thresholdRegion, window);
					}
				}
				finally
				{
					if (thresholdObjects != null)
					{
						thresholdObjects.Dispose();
					}
					if (thresholdRegion != null)
					{
						thresholdRegion.Dispose();
					}
				}
			}
		}

		// Token: 0x06000B25 RID: 2853 RVA: 0x00033E04 File Offset: 0x00032004
		private void DrawRois(HWindow window, BlobProcessResult result)
		{
			bool flag = result.RoiResults == null || result.RoiResults.Count == 0;
			if (!flag)
			{
				this.DrawRoiGroup(window, result, true, "green");
				this.DrawRoiGroup(window, result, false, "red");
			}
		}

		// Token: 0x06000B26 RID: 2854 RVA: 0x00033E50 File Offset: 0x00032050
		private void DrawRoiGroup(HWindow window, BlobProcessResult result, bool isOk, string color)
		{
			HObject roiBoundaries = null;
			HObject unionBoundary = null;
			try
			{
				HOperatorSet.GenEmptyObj(out roiBoundaries);
				foreach (BlobRoiResult roiResult in result.RoiResults)
				{
					bool flag = roiResult.IsOk != isOk;
					if (!flag)
					{
						HObject roiObject = roiResult.DisplayRoiObject;
						bool flag2 = roiObject == null || !roiObject.IsInitialized();
						if (flag2)
						{
							roiObject = roiResult.RoiObject;
						}
						bool flag3 = roiObject == null || !roiObject.IsInitialized();
						if (!flag3)
						{
							HObject boundary = null;
							HObject thickBoundary = null;
							try
							{
								HOperatorSet.Boundary(roiObject, out boundary, "outer");
								HOperatorSet.DilationCircle(boundary, out thickBoundary, 1.5);
								HObject concat;
								HOperatorSet.ConcatObj(roiBoundaries, thickBoundary, out concat);
								roiBoundaries.Dispose();
								roiBoundaries = concat;
							}
							finally
							{
								if (boundary != null)
								{
									boundary.Dispose();
								}
								if (thickBoundary != null)
								{
									thickBoundary.Dispose();
								}
							}
						}
					}
				}
				HTuple count;
				HOperatorSet.CountObj(roiBoundaries, out count);
				bool flag4 = count.Length == 0 || count[0].I <= 0;
				if (!flag4)
				{
					HOperatorSet.Union1(roiBoundaries, out unionBoundary);
					HOperatorSet.SetDraw(window, "fill");
					HOperatorSet.SetColor(window, color);
					HOperatorSet.SetLineWidth(window, 2);
					HOperatorSet.DispObj(unionBoundary, window);
				}
			}
			finally
			{
				if (roiBoundaries != null)
				{
					roiBoundaries.Dispose();
				}
				if (unionBoundary != null)
				{
					unionBoundary.Dispose();
				}
			}
		}

		// Token: 0x06000B27 RID: 2855 RVA: 0x00034054 File Offset: 0x00032254
		private void DrawRoiIndexes(HWindow window, BlobProcessResult result, BlobToolConfig config)
		{
			bool flag = result.RoiResults == null;
			if (!flag)
			{
				int textSize = (config.IndexTextSize < 8) ? 8 : config.IndexTextSize;
				HTuple previousFont = null;
				try
				{
					HOperatorSet.GetFont(window, out previousFont);
					HOperatorSet.SetFont(window, "Arial-" + textSize.ToString());
				}
				catch (HOperatorException)
				{
					previousFont = null;
				}
				int index = 0;
				foreach (BlobRoiResult roiResult in result.RoiResults)
				{
					index++;
					HObject roiObject = roiResult.DisplayRoiObject;
					bool flag2 = roiObject == null || !roiObject.IsInitialized();
					if (flag2)
					{
						roiObject = roiResult.RoiObject;
					}
					bool flag3 = roiObject == null || !roiObject.IsInitialized();
					if (!flag3)
					{
						try
						{
							HTuple row;
							HTuple column;
							HTuple row2;
							HTuple column2;
							HOperatorSet.SmallestRectangle1(roiObject, out row, out column, out row2, out column2);
							bool flag4 = row.Length == 0 || column.Length == 0;
							if (!flag4)
							{
								double top = row.TupleMin().D;
								double left = column.TupleMin().D;
								double labelRow = top - (double)textSize - 6.0 + config.IndexOffsetY;
								double labelColumn = left + config.IndexOffsetX;
								HOperatorSet.SetColor(window, roiResult.IsOk ? "green" : "red");
								HOperatorSet.SetTposition(window, Math.Max(labelRow, 0.0), Math.Max(labelColumn, 0.0));
								HOperatorSet.WriteString(window, index.ToString());
							}
						}
						catch (HOperatorException)
						{
						}
					}
				}
				bool flag5 = previousFont == null;
				if (!flag5)
				{
					try
					{
						HOperatorSet.SetFont(window, previousFont);
					}
					catch (HOperatorException)
					{
					}
				}
			}
		}

		// Token: 0x06000B28 RID: 2856 RVA: 0x000342C0 File Offset: 0x000324C0
		private void DrawResultText(HWindow window, ToolVision tool, BlobProcessResult result, bool showTotalText, bool showValueText)
		{
			bool flag = result == null;
			if (!flag)
			{
				string toolName = string.IsNullOrWhiteSpace((tool != null) ? tool.Name : null) ? "Blob" : tool.Name;
				string resultColor = result.IsOk ? "green" : "red";
				bool flag2 = showValueText && result.RoiResults != null;
				if (flag2)
				{
					foreach (BlobRoiResult roiResult in result.RoiResults)
					{
						string roiName = this.GetRoiName(roiResult);
						HOperatorSet.SetColor(window, roiResult.IsOk ? "green" : "red");
						HOperatorSet.SetTposition(window, roiResult.LabelRow, roiResult.LabelColumn);
						HOperatorSet.WriteString(window, string.Concat(new string[]
						{
							toolName,
							" ",
							roiName,
							"=",
							roiResult.Value.ToString("0")
						}));
					}
				}
				bool flag3 = !showTotalText;
				if (!flag3)
				{
					HOperatorSet.SetColor(window, resultColor);
					HOperatorSet.SetTposition(window, 20, 20);
					HOperatorSet.WriteString(window, toolName + " " + this.BuildSummaryText(tool, result) + (result.IsOk ? " OK" : " NG"));
				}
			}
		}

		// Token: 0x06000B29 RID: 2857 RVA: 0x00034488 File Offset: 0x00032688
		private string BuildSummaryText(ToolVision tool, BlobProcessResult result)
		{
			BlobToolSpec spec = ((tool != null) ? tool.Spec : null) as BlobToolSpec;
			bool flag = spec == null || spec.SpecMode != BlobSpecMode.PerRoi || result.RoiResults == null;
			string result2;
			if (flag)
			{
				result2 = "Total=" + result.TotalValue.ToString("0");
			}
			else
			{
				int okCount = 0;
				foreach (BlobRoiResult roiResult in result.RoiResults)
				{
					bool isOk = roiResult.IsOk;
					if (isOk)
					{
						okCount++;
					}
				}
				result2 = "ROI " + okCount.ToString() + "/" + result.RoiResults.Count.ToString();
			}
			return result2;
		}

		// Token: 0x06000B2A RID: 2858 RVA: 0x00034570 File Offset: 0x00032770
		private string GetRoiName(BlobRoiResult roiResult)
		{
			string value;
			if (roiResult == null)
			{
				value = null;
			}
			else
			{
				RoiData roi = roiResult.Roi;
				value = ((roi != null) ? roi.Name : null);
			}
			bool flag = !string.IsNullOrWhiteSpace(value);
			string result;
			if (flag)
			{
				result = roiResult.Roi.Name;
			}
			else
			{
				result = "ROI";
			}
			return result;
		}

		// Token: 0x04000477 RID: 1143
		private const double IndexGap = 6.0;
	}
}
