﻿using System;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000D7 RID: 215
	public class BlobRoiResult
	{
		// Token: 0x170003B6 RID: 950
		// (get) Token: 0x06000AC7 RID: 2759 RVA: 0x00031CB8 File Offset: 0x0002FEB8
		// (set) Token: 0x06000AC8 RID: 2760 RVA: 0x00031CC0 File Offset: 0x0002FEC0
		public RoiData Roi { get; set; }

		// Token: 0x170003B7 RID: 951
		// (get) Token: 0x06000AC9 RID: 2761 RVA: 0x00031CC9 File Offset: 0x0002FEC9
		// (set) Token: 0x06000ACA RID: 2762 RVA: 0x00031CD1 File Offset: 0x0002FED1
		public double Value { get; set; }

		// Token: 0x170003B8 RID: 952
		// (get) Token: 0x06000ACB RID: 2763 RVA: 0x00031CDA File Offset: 0x0002FEDA
		// (set) Token: 0x06000ACC RID: 2764 RVA: 0x00031CE2 File Offset: 0x0002FEE2
		public bool IsOk { get; set; } = true;

		// Token: 0x170003B9 RID: 953
		// (get) Token: 0x06000ACD RID: 2765 RVA: 0x00031CEB File Offset: 0x0002FEEB
		// (set) Token: 0x06000ACE RID: 2766 RVA: 0x00031CF3 File Offset: 0x0002FEF3
		public double LabelRow { get; set; }

		// Token: 0x170003BA RID: 954
		// (get) Token: 0x06000ACF RID: 2767 RVA: 0x00031CFC File Offset: 0x0002FEFC
		// (set) Token: 0x06000AD0 RID: 2768 RVA: 0x00031D04 File Offset: 0x0002FF04
		public double LabelColumn { get; set; }

		// Token: 0x170003BB RID: 955
		// (get) Token: 0x06000AD1 RID: 2769 RVA: 0x00031D0D File Offset: 0x0002FF0D
		// (set) Token: 0x06000AD2 RID: 2770 RVA: 0x00031D15 File Offset: 0x0002FF15
		public HObject RoiObject { get; set; }

		// Token: 0x170003BC RID: 956
		// (get) Token: 0x06000AD3 RID: 2771 RVA: 0x00031D1E File Offset: 0x0002FF1E
		// (set) Token: 0x06000AD4 RID: 2772 RVA: 0x00031D26 File Offset: 0x0002FF26
		public HObject DisplayRoiObject { get; set; }

		// Token: 0x170003BD RID: 957
		// (get) Token: 0x06000AD5 RID: 2773 RVA: 0x00031D2F File Offset: 0x0002FF2F
		// (set) Token: 0x06000AD6 RID: 2774 RVA: 0x00031D37 File Offset: 0x0002FF37
		public HObject ThresholdObject { get; set; }

		// Token: 0x170003BE RID: 958
		// (get) Token: 0x06000AD7 RID: 2775 RVA: 0x00031D40 File Offset: 0x0002FF40
		// (set) Token: 0x06000AD8 RID: 2776 RVA: 0x00031D48 File Offset: 0x0002FF48
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170003BF RID: 959
		// (get) Token: 0x06000AD9 RID: 2777 RVA: 0x00031D51 File Offset: 0x0002FF51
		// (set) Token: 0x06000ADA RID: 2778 RVA: 0x00031D59 File Offset: 0x0002FF59
		public string MasterPositionToolName { get; set; }

		// Token: 0x170003C0 RID: 960
		// (get) Token: 0x06000ADB RID: 2779 RVA: 0x00031D62 File Offset: 0x0002FF62
		// (set) Token: 0x06000ADC RID: 2780 RVA: 0x00031D6A File Offset: 0x0002FF6A
		public string MasterAngleToolName { get; set; }

		// Token: 0x170003C1 RID: 961
		// (get) Token: 0x06000ADD RID: 2781 RVA: 0x00031D73 File Offset: 0x0002FF73
		// (set) Token: 0x06000ADE RID: 2782 RVA: 0x00031D7B File Offset: 0x0002FF7B
		public string MasterStatus { get; set; }

		// Token: 0x170003C2 RID: 962
		// (get) Token: 0x06000ADF RID: 2783 RVA: 0x00031D84 File Offset: 0x0002FF84
		// (set) Token: 0x06000AE0 RID: 2784 RVA: 0x00031D8C File Offset: 0x0002FF8C
		public double MasterProcessingTimeMs { get; set; }
	}
}
