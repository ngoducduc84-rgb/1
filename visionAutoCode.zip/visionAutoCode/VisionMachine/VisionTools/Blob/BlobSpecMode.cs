﻿using System;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000DE RID: 222
	public enum BlobSpecMode
	{
		// Token: 0x0400048B RID: 1163
		Total,
		// Token: 0x0400048C RID: 1164
		PerRoi
	}
}
