﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000DC RID: 220
	public enum BlobThresholdPolarity
	{
		// Token: 0x04000479 RID: 1145
		[Description("Dark to Light")]
		DarkToLight,
		// Token: 0x0400047A RID: 1146
		[Description("Light to Dark")]
		LightToDark
	}
}
