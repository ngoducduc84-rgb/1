﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000DD RID: 221
	public class BlobToolConfig : ToolConfigBase
	{
		// Token: 0x170003D1 RID: 977
		// (get) Token: 0x06000B2C RID: 2860 RVA: 0x000345B9 File Offset: 0x000327B9
		// (set) Token: 0x06000B2D RID: 2861 RVA: 0x000345C1 File Offset: 0x000327C1
		public ImageInputLink InputLink { get; set; } = new ImageInputLink();

		// Token: 0x170003D2 RID: 978
		// (get) Token: 0x06000B2E RID: 2862 RVA: 0x000345CA File Offset: 0x000327CA
		// (set) Token: 0x06000B2F RID: 2863 RVA: 0x000345D4 File Offset: 0x000327D4
		[DisplayName("Threshold Polarity")]
		public BlobThresholdPolarity ThresholdPolarity
		{
			get
			{
				return this._thresholdPolarity;
			}
			set
			{
				bool flag = this._thresholdPolarity != value;
				if (flag)
				{
					this._thresholdPolarity = value;
					base.OnPropertyChanged("ThresholdPolarity");
				}
			}
		}

		// Token: 0x170003D3 RID: 979
		// (get) Token: 0x06000B30 RID: 2864 RVA: 0x00034607 File Offset: 0x00032807
		// (set) Token: 0x06000B31 RID: 2865 RVA: 0x00034610 File Offset: 0x00032810
		[DisplayName("Threshold Min")]
		public double ThresholdMin
		{
			get
			{
				return this._thresholdMin;
			}
			set
			{
				bool flag = this._thresholdMin != value;
				if (flag)
				{
					this._thresholdMin = value;
					base.OnPropertyChanged("ThresholdMin");
				}
			}
		}

		// Token: 0x170003D4 RID: 980
		// (get) Token: 0x06000B32 RID: 2866 RVA: 0x00034643 File Offset: 0x00032843
		// (set) Token: 0x06000B33 RID: 2867 RVA: 0x0003464C File Offset: 0x0003284C
		[DisplayName("Threshold Max")]
		public double ThresholdMax
		{
			get
			{
				return this._thresholdMax;
			}
			set
			{
				bool flag = this._thresholdMax != value;
				if (flag)
				{
					this._thresholdMax = value;
					base.OnPropertyChanged("ThresholdMax");
				}
			}
		}

		// Token: 0x170003D5 RID: 981
		// (get) Token: 0x06000B34 RID: 2868 RVA: 0x0003467F File Offset: 0x0003287F
		// (set) Token: 0x06000B35 RID: 2869 RVA: 0x00034688 File Offset: 0x00032888
		[DisplayName("Min Area")]
		public double MinArea
		{
			get
			{
				return this._minArea;
			}
			set
			{
				bool flag = this._minArea != value;
				if (flag)
				{
					this._minArea = value;
					base.OnPropertyChanged("MinArea");
				}
			}
		}

		// Token: 0x170003D6 RID: 982
		// (get) Token: 0x06000B36 RID: 2870 RVA: 0x000346BB File Offset: 0x000328BB
		// (set) Token: 0x06000B37 RID: 2871 RVA: 0x000346C4 File Offset: 0x000328C4
		[DisplayName("Max Area")]
		public double MaxArea
		{
			get
			{
				return this._maxArea;
			}
			set
			{
				bool flag = this._maxArea != value;
				if (flag)
				{
					this._maxArea = value;
					base.OnPropertyChanged("MaxArea");
				}
			}
		}

		// Token: 0x170003D7 RID: 983
		// (get) Token: 0x06000B38 RID: 2872 RVA: 0x000346F7 File Offset: 0x000328F7
		// (set) Token: 0x06000B39 RID: 2873 RVA: 0x00034700 File Offset: 0x00032900
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi != value;
				if (flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x170003D8 RID: 984
		// (get) Token: 0x06000B3A RID: 2874 RVA: 0x00034733 File Offset: 0x00032933
		// (set) Token: 0x06000B3B RID: 2875 RVA: 0x0003473C File Offset: 0x0003293C
		[DisplayName("Show Value Text")]
		public bool ShowValueText
		{
			get
			{
				return this._showValueText;
			}
			set
			{
				bool flag = this._showValueText != value;
				if (flag)
				{
					this._showValueText = value;
					base.OnPropertyChanged("ShowValueText");
				}
			}
		}

		// Token: 0x170003D9 RID: 985
		// (get) Token: 0x06000B3C RID: 2876 RVA: 0x0003476F File Offset: 0x0003296F
		// (set) Token: 0x06000B3D RID: 2877 RVA: 0x00034778 File Offset: 0x00032978
		[DisplayName("Show ROI Index")]
		public bool ShowRoiIndex
		{
			get
			{
				return this._showRoiIndex;
			}
			set
			{
				bool flag = this._showRoiIndex != value;
				if (flag)
				{
					this._showRoiIndex = value;
					base.OnPropertyChanged("ShowRoiIndex");
				}
			}
		}

		// Token: 0x170003DA RID: 986
		// (get) Token: 0x06000B3E RID: 2878 RVA: 0x000347AB File Offset: 0x000329AB
		// (set) Token: 0x06000B3F RID: 2879 RVA: 0x000347B4 File Offset: 0x000329B4
		[DisplayName("Index Text Size")]
		public int IndexTextSize
		{
			get
			{
				return this._indexTextSize;
			}
			set
			{
				int v = (value < 8) ? 8 : value;
				bool flag = this._indexTextSize != v;
				if (flag)
				{
					this._indexTextSize = v;
					base.OnPropertyChanged("IndexTextSize");
				}
			}
		}

		// Token: 0x170003DB RID: 987
		// (get) Token: 0x06000B40 RID: 2880 RVA: 0x000347F0 File Offset: 0x000329F0
		// (set) Token: 0x06000B41 RID: 2881 RVA: 0x000347F8 File Offset: 0x000329F8
		[DisplayName("Index Offset X (px)")]
		[Description("Moves the index sideways from the left edge of its ROI. Positive goes right. Use it when the index of one ROI sits on top of its neighbour.")]
		public double IndexOffsetX
		{
			get
			{
				return this._indexOffsetX;
			}
			set
			{
				bool flag = this._indexOffsetX != value;
				if (flag)
				{
					this._indexOffsetX = value;
					base.OnPropertyChanged("IndexOffsetX");
				}
			}
		}

		// Token: 0x170003DC RID: 988
		// (get) Token: 0x06000B42 RID: 2882 RVA: 0x0003482B File Offset: 0x00032A2B
		// (set) Token: 0x06000B43 RID: 2883 RVA: 0x00034834 File Offset: 0x00032A34
		[DisplayName("Index Offset Y (px)")]
		[Description("Moves the index up or down from its default place just above the ROI. Positive goes DOWN, matching image row order - a value around the ROI height puts the index inside the ROI instead of above it.")]
		public double IndexOffsetY
		{
			get
			{
				return this._indexOffsetY;
			}
			set
			{
				bool flag = this._indexOffsetY != value;
				if (flag)
				{
					this._indexOffsetY = value;
					base.OnPropertyChanged("IndexOffsetY");
				}
			}
		}

		// Token: 0x170003DD RID: 989
		// (get) Token: 0x06000B44 RID: 2884 RVA: 0x00034867 File Offset: 0x00032A67
		// (set) Token: 0x06000B45 RID: 2885 RVA: 0x00034870 File Offset: 0x00032A70
		[DisplayName("Show Threshold")]
		public bool ShowThreshold
		{
			get
			{
				return this._showThreshold;
			}
			set
			{
				bool flag = this._showThreshold != value;
				if (flag)
				{
					this._showThreshold = value;
					base.OnPropertyChanged("ShowThreshold");
				}
			}
		}

		// Token: 0x170003DE RID: 990
		// (get) Token: 0x06000B46 RID: 2886 RVA: 0x000348A3 File Offset: 0x00032AA3
		// (set) Token: 0x06000B47 RID: 2887 RVA: 0x000348AC File Offset: 0x00032AAC
		[DisplayName("Show Input Image")]
		public bool ShowInputImage
		{
			get
			{
				return this._showInputImage;
			}
			set
			{
				bool flag = this._showInputImage != value;
				if (flag)
				{
					this._showInputImage = value;
					base.OnPropertyChanged("ShowInputImage");
				}
			}
		}

		// Token: 0x170003DF RID: 991
		// (get) Token: 0x06000B48 RID: 2888 RVA: 0x000348DF File Offset: 0x00032ADF
		// (set) Token: 0x06000B49 RID: 2889 RVA: 0x000348E8 File Offset: 0x00032AE8
		[Browsable(false)]
		public RoiData ROI
		{
			get
			{
				return this._roi;
			}
			set
			{
				bool flag = this._roi != value;
				if (flag)
				{
					this._roi = value;
					base.OnPropertyChanged("ROI");
				}
			}
		}

		// Token: 0x0400047C RID: 1148
		private BlobThresholdPolarity _thresholdPolarity;

		// Token: 0x0400047D RID: 1149
		private double _thresholdMin;

		// Token: 0x0400047E RID: 1150
		private double _thresholdMax;

		// Token: 0x0400047F RID: 1151
		private double _minArea;

		// Token: 0x04000480 RID: 1152
		private double _maxArea;

		// Token: 0x04000481 RID: 1153
		private bool _showRoi;

		// Token: 0x04000482 RID: 1154
		private bool _showValueText = true;

		// Token: 0x04000483 RID: 1155
		private bool _showRoiIndex;

		// Token: 0x04000484 RID: 1156
		private int _indexTextSize = 16;

		// Token: 0x04000485 RID: 1157
		private double _indexOffsetX;

		// Token: 0x04000486 RID: 1158
		private double _indexOffsetY;

		// Token: 0x04000487 RID: 1159
		private bool _showThreshold;

		// Token: 0x04000488 RID: 1160
		private bool _showInputImage;

		// Token: 0x04000489 RID: 1161
		private RoiData _roi = new RoiData();
	}
}
