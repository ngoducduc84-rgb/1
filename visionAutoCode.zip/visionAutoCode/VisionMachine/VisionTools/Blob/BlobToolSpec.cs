﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.Blob
{
	// Token: 0x020000DF RID: 223
	public class BlobToolSpec : ToolSpecBase
	{
		// Token: 0x170003E0 RID: 992
		// (get) Token: 0x06000B4B RID: 2891 RVA: 0x00034949 File Offset: 0x00032B49
		// (set) Token: 0x06000B4C RID: 2892 RVA: 0x00034954 File Offset: 0x00032B54
		[DisplayName("Spec Mode")]
		public BlobSpecMode SpecMode
		{
			get
			{
				return this._specMode;
			}
			set
			{
				bool flag = this._specMode != value;
				if (flag)
				{
					this._specMode = value;
					base.OnPropertyChanged("SpecMode");
				}
			}
		}

		// Token: 0x170003E1 RID: 993
		// (get) Token: 0x06000B4D RID: 2893 RVA: 0x00034987 File Offset: 0x00032B87
		// (set) Token: 0x06000B4E RID: 2894 RVA: 0x00034990 File Offset: 0x00032B90
		[DisplayName("Normal Size")]
		public double NormalSize
		{
			get
			{
				return this._normalSize;
			}
			set
			{
				bool flag = this._normalSize != value;
				if (flag)
				{
					this._normalSize = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("NormalSize");
				}
			}
		}

		// Token: 0x170003E2 RID: 994
		// (get) Token: 0x06000B4F RID: 2895 RVA: 0x000349CA File Offset: 0x00032BCA
		// (set) Token: 0x06000B50 RID: 2896 RVA: 0x000349D4 File Offset: 0x00032BD4
		[DisplayName("Upper Deviation")]
		public double UpperDeviation
		{
			get
			{
				return this._upperDeviation;
			}
			set
			{
				bool flag = this._upperDeviation != value;
				if (flag)
				{
					this._upperDeviation = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("UpperDeviation");
				}
			}
		}

		// Token: 0x170003E3 RID: 995
		// (get) Token: 0x06000B51 RID: 2897 RVA: 0x00034A0E File Offset: 0x00032C0E
		// (set) Token: 0x06000B52 RID: 2898 RVA: 0x00034A18 File Offset: 0x00032C18
		[DisplayName("Lower Deviation")]
		public double LowerDeviation
		{
			get
			{
				return this._lowerDeviation;
			}
			set
			{
				bool flag = this._lowerDeviation != value;
				if (flag)
				{
					this._lowerDeviation = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("LowerDeviation");
				}
			}
		}

		// Token: 0x170003E4 RID: 996
		// (get) Token: 0x06000B53 RID: 2899 RVA: 0x00034A52 File Offset: 0x00032C52
		// (set) Token: 0x06000B54 RID: 2900 RVA: 0x00034A5C File Offset: 0x00032C5C
		[DisplayName("Maximum Size")]
		[ReadOnly(true)]
		public double MaximumSize
		{
			get
			{
				return this._maximumSize;
			}
			set
			{
				bool flag = this._maximumSize != value;
				if (flag)
				{
					this._maximumSize = value;
					base.OnPropertyChanged("MaximumSize");
				}
			}
		}

		// Token: 0x170003E5 RID: 997
		// (get) Token: 0x06000B55 RID: 2901 RVA: 0x00034A8F File Offset: 0x00032C8F
		// (set) Token: 0x06000B56 RID: 2902 RVA: 0x00034A98 File Offset: 0x00032C98
		[DisplayName("Minimum Size")]
		[ReadOnly(true)]
		public double MinimumSize
		{
			get
			{
				return this._minimumSize;
			}
			set
			{
				bool flag = this._minimumSize != value;
				if (flag)
				{
					this._minimumSize = value;
					base.OnPropertyChanged("MinimumSize");
				}
			}
		}

		// Token: 0x06000B57 RID: 2903 RVA: 0x00034ACB File Offset: 0x00032CCB
		private void RecalculateLimits()
		{
			this.MaximumSize = this.NormalSize + this.UpperDeviation;
			this.MinimumSize = this.NormalSize - this.LowerDeviation;
		}

		// Token: 0x06000B58 RID: 2904 RVA: 0x00034AF8 File Offset: 0x00032CF8
		public bool IsWithinSpec(double value)
		{
			return value >= this.MinimumSize && value <= this.MaximumSize;
		}

		// Token: 0x0400048D RID: 1165
		private BlobSpecMode _specMode = BlobSpecMode.Total;

		// Token: 0x0400048E RID: 1166
		private double _normalSize = 0.0;

		// Token: 0x0400048F RID: 1167
		private double _upperDeviation = 0.0;

		// Token: 0x04000490 RID: 1168
		private double _lowerDeviation = 0.0;

		// Token: 0x04000491 RID: 1169
		private double _maximumSize = 0.0;

		// Token: 0x04000492 RID: 1170
		private double _minimumSize = 0.0;
	}
}
