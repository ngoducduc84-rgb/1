﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.PropertyGrid;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.Blob.Views
{
	// Token: 0x020000E0 RID: 224
	public partial class Blob_para : UserControl, IStyleConnector
	{
		// Token: 0x06000B5A RID: 2906 RVA: 0x00034B8A File Offset: 0x00032D8A
		public Blob_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000B5B RID: 2907 RVA: 0x00034B9C File Offset: 0x00032D9C
		private void TrackBar_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			TrackBarEdit editor = sender as TrackBarEdit;
			object value = e.NewValue;
			object row = editor.DataContext;
			Console.WriteLine(string.Format("Changed: {0}", value));
		}

		// Token: 0x06000B5C RID: 2908 RVA: 0x00034BD0 File Offset: 0x00032DD0
		private void Threshold_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			BlobToolConfig config = this.propertyGrid.SelectedObject as BlobToolConfig;
			bool flag = config == null;
			if (!flag)
			{
				bool flag2 = config.ThresholdMin > config.ThresholdMax;
				if (flag2)
				{
					config.ThresholdMax = config.ThresholdMin;
				}
			}
		}

		// Token: 0x06000B5D RID: 2909 RVA: 0x00034C1C File Offset: 0x00032E1C
		private void Area_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			BlobToolConfig config = this.propertyGrid.SelectedObject as BlobToolConfig;
			bool flag = config == null;
			if (!flag)
			{
				bool flag2 = config.MinArea > config.MaxArea;
				if (flag2)
				{
					config.MaxArea = config.MinArea;
				}
			}
		}

		// Token: 0x06000B5E RID: 2910 RVA: 0x00034C66 File Offset: 0x00032E66
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.BlobTrialRun();
			}
		}

		// Token: 0x06000B61 RID: 2913 RVA: 0x00034D18 File Offset: 0x00032F18
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((TrackBarEdit)target).EditValueChanged += this.Threshold_EditValueChanged;
				break;
			case 3:
				((SpinEdit)target).EditValueChanged += this.Threshold_EditValueChanged;
				break;
			case 4:
				((TrackBarEdit)target).EditValueChanged += this.Threshold_EditValueChanged;
				break;
			case 5:
				((SpinEdit)target).EditValueChanged += this.Threshold_EditValueChanged;
				break;
			case 6:
				((SpinEdit)target).EditValueChanged += this.Area_EditValueChanged;
				break;
			case 7:
				((SpinEdit)target).EditValueChanged += this.Area_EditValueChanged;
				break;
			}
		}
	}
}
