﻿using System;
using System.Diagnostics;
using System.Linq;
using DevExpress.Xpf.Core;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.BoundingBoxMaster
{
	// Token: 0x020000CE RID: 206
	public class BoundingBoxMasterActionService : IToolActionService
	{
		// Token: 0x170003A7 RID: 935
		// (get) Token: 0x06000A86 RID: 2694 RVA: 0x00030740 File Offset: 0x0002E940
		public ToolType ToolType
		{
			get
			{
				return ToolType.BoundingBoxMaster;
			}
		}

		// Token: 0x06000A87 RID: 2695 RVA: 0x00030754 File Offset: 0x0002E954
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, BoundingBoxMasterActionService.BoundingBoxMasterRunMode.TrialRun);
		}

		// Token: 0x06000A88 RID: 2696 RVA: 0x00030761 File Offset: 0x0002E961
		public void Matching(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, BoundingBoxMasterActionService.BoundingBoxMasterRunMode.Matching);
		}

		// Token: 0x06000A89 RID: 2697 RVA: 0x0003076E File Offset: 0x0002E96E
		public void DefineMaster(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, BoundingBoxMasterActionService.BoundingBoxMasterRunMode.DefineMaster);
		}

		// Token: 0x06000A8A RID: 2698 RVA: 0x0003077C File Offset: 0x0002E97C
		private void RunAndDisplay(ToolActionContext context, ToolVision tool, BoundingBoxMasterActionService.BoundingBoxMasterRunMode runMode)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				BoundingBoxMasterResult result = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						Stopwatch inputStopwatch = Stopwatch.StartNew();
						input = this._pipelineService.BuildInputImageForTool(processContext, tool);
						inputStopwatch.Stop();
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							HOperatorSet.CopyImage(original, out input);
						}
						BoundingBoxMasterToolConfig config = tool.Config as BoundingBoxMasterToolConfig;
						bool flag4 = config != null && config.ShowInputImage;
						if (flag4)
						{
							context.DisplayController.DisplayImage(input);
						}
						else
						{
							BoundingBoxMasterProcessor processor = new BoundingBoxMasterProcessor();
							Stopwatch stopwatch = Stopwatch.StartNew();
							if (runMode != BoundingBoxMasterActionService.BoundingBoxMasterRunMode.DefineMaster)
							{
								if (runMode != BoundingBoxMasterActionService.BoundingBoxMasterRunMode.TrialRun)
								{
									result = processor.Match(input, tool);
								}
								else
								{
									result = processor.TrialRun(input, tool);
								}
							}
							else
							{
								result = processor.DefineMaster(input, tool);
							}
							stopwatch.Stop();
							bool flag5 = ((result != null) ? result.BoundingBoxResult : null) != null;
							if (flag5)
							{
								result.BoundingBoxResult.InputSourceToolName = inputSourceToolName;
								result.BoundingBoxResult.InputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
								result.BoundingBoxResult.TotalProcessingTimeMs = result.BoundingBoxResult.InputProcessingTimeMs + result.BoundingBoxResult.ProcessingTimeMs;
								result.TotalProcessingTimeMs = result.BoundingBoxResult.TotalProcessingTimeMs;
							}
							else
							{
								bool flag6 = result != null && result.TotalProcessingTimeMs <= 0.0;
								if (flag6)
								{
									result.TotalProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds + stopwatch.Elapsed.TotalMilliseconds;
								}
							}
							Action<ToolVision, object> resultReporter = context.ResultReporter;
							if (resultReporter != null)
							{
								resultReporter(tool, result);
							}
							bool flag7 = result != null && !result.IsSuccess;
							if (flag7)
							{
								DXMessageBox.Show(result.Message);
							}
							context.DisplayController.DisplayImage(input);
							BoundingBoxMasterResult overlayResult = result;
							result = null;
							context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
							{
								this._drawer.Draw(window, tool, overlayResult);
							}, overlayResult);
						}
					}
				}
				finally
				{
					if (result != null)
					{
						result.Dispose();
					}
					if (input != null)
					{
						input.Dispose();
					}
					if (original != null)
					{
						original.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
				}
			}
		}

		// Token: 0x06000A8B RID: 2699 RVA: 0x00030AE0 File Offset: 0x0002ECE0
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			BoundingBoxMasterToolConfig config = ((tool2 != null) ? tool2.Config : null) as BoundingBoxMasterToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x04000448 RID: 1096
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();

		// Token: 0x04000449 RID: 1097
		private readonly BoundingBoxMasterResultDrawer _drawer = new BoundingBoxMasterResultDrawer();

		// Token: 0x0200032F RID: 815
		private enum BoundingBoxMasterRunMode
		{
			// Token: 0x04001184 RID: 4484
			Matching,
			// Token: 0x04001185 RID: 4485
			DefineMaster,
			// Token: 0x04001186 RID: 4486
			TrialRun
		}
	}
}
