﻿using System;
using VisionMachine.VisionTools.FindBoundingBox;

namespace VisionMachine.VisionTools.BoundingBoxMaster
{
	// Token: 0x020000CF RID: 207
	public class BoundingBoxMasterParameterPanelViewModel : FindBoundingBoxParameterPanelViewModel
	{
		// Token: 0x170003A8 RID: 936
		// (get) Token: 0x06000A8D RID: 2701 RVA: 0x00030BF0 File Offset: 0x0002EDF0
		// (set) Token: 0x06000A8E RID: 2702 RVA: 0x00030C0D File Offset: 0x0002EE0D
		public BoundingBoxMasterToolConfig BoundingBoxMasterConfig
		{
			get
			{
				return base.Config as BoundingBoxMasterToolConfig;
			}
			set
			{
				base.Config = value;
			}
		}
	}
}
