﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.BoundingBoxMaster
{
	// Token: 0x020000D0 RID: 208
	public class BoundingBoxMasterProcessor : IToolProcessor
	{
		// Token: 0x06000A90 RID: 2704 RVA: 0x00030C21 File Offset: 0x0002EE21
		public BoundingBoxMasterProcessor() : this(null)
		{
		}

		// Token: 0x06000A91 RID: 2705 RVA: 0x00030C2C File Offset: 0x0002EE2C
		public BoundingBoxMasterProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x170003A9 RID: 937
		// (get) Token: 0x06000A92 RID: 2706 RVA: 0x00030C40 File Offset: 0x0002EE40
		public ToolType ToolType
		{
			get
			{
				return ToolType.BoundingBoxMaster;
			}
		}

		// Token: 0x06000A93 RID: 2707 RVA: 0x00030C54 File Offset: 0x0002EE54
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			BoundingBoxMasterResult result = this.Match((context != null) ? context.InputImage : null, tool);
			return new ToolProcessResult
			{
				IsSuccess = result.IsSuccess,
				Message = result.Message,
				Data = result
			};
		}

		// Token: 0x06000A94 RID: 2708 RVA: 0x00030CA4 File Offset: 0x0002EEA4
		public BoundingBoxMasterResult Match(HObject image, ToolVision tool)
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			BoundingBoxMasterResult result = new BoundingBoxMasterResult();
			BoundingBoxMasterResult result2;
			try
			{
				FindBoundingBoxResult box = new FindBoundingBoxProcessor(this._cachedMasterResults).Run(image, tool);
				result.BoundingBoxResult = box;
				result.ToolName = ((tool == null) ? null : tool.Name);
				result.RoiName = ((box == null) ? null : box.RoiName);
				result.ProcessingTimeMs = ((box == null) ? 0.0 : box.ProcessingTimeMs);
				result.TotalProcessingTimeMs = ((box == null) ? 0.0 : box.TotalProcessingTimeMs);
				bool flag = box == null || !box.IsSuccess || box.SelectedBox == null;
				if (flag)
				{
					result.Message = ((box == null) ? "Bounding Box Master result is not available." : box.Message);
					result2 = result;
				}
				else
				{
					result.Row = box.SelectedBox.Points.CenterRow;
					result.Column = box.SelectedBox.Points.CenterColumn;
					result.Angle = 0.0;
					result.Score = 1.0;
					this.ApplyDeltaToResult(tool, result);
					result.IsSuccess = true;
					result.Message = "Bounding Box Master OK.";
					result2 = result;
				}
			}
			catch (Exception ex)
			{
				result.Message = "Bounding Box Master failed: " + ex.Message;
				result2 = result;
			}
			finally
			{
				stopwatch.Stop();
				bool flag2 = result.ProcessingTimeMs <= 0.0;
				if (flag2)
				{
					result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				}
				bool flag3 = result.TotalProcessingTimeMs <= 0.0;
				if (flag3)
				{
					result.TotalProcessingTimeMs = result.ProcessingTimeMs;
				}
			}
			return result2;
		}

		// Token: 0x06000A95 RID: 2709 RVA: 0x00030E9C File Offset: 0x0002F09C
		public BoundingBoxMasterResult DefineMaster(HObject image, ToolVision tool)
		{
			BoundingBoxMasterResult result = this.Match(image, tool);
			bool flag = !result.IsSuccess;
			BoundingBoxMasterResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeModelToolTrain train = this.EnsureTrain(tool);
				train.MasterRow = result.Row;
				train.MasterColumn = result.Column;
				train.MasterAngle = 0.0;
				train.LastRow = result.Row;
				train.LastColumn = result.Column;
				train.LastAngle = 0.0;
				train.LastScore = result.Score;
				train.HasMasterDefined = true;
				result.DeltaRow = 0.0;
				result.DeltaColumn = 0.0;
				result.DeltaAngle = 0.0;
				result.HasMasterDefined = true;
				result.Message = "Bounding Box Master defined.";
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06000A96 RID: 2710 RVA: 0x00030F84 File Offset: 0x0002F184
		public BoundingBoxMasterResult TrialRun(HObject image, ToolVision tool)
		{
			BoundingBoxMasterResult result = this.Match(image, tool);
			bool flag = !result.IsSuccess;
			BoundingBoxMasterResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeModelToolTrain train = (tool == null) ? null : (tool.TrainModel as ShapeModelToolTrain);
				bool flag2 = train == null || !train.HasMasterDefined;
				if (flag2)
				{
					result.IsSuccess = false;
					result.Message = "Master has not been defined.";
					result2 = result;
				}
				else
				{
					result.DeltaRow = result.Row - train.MasterRow;
					result.DeltaColumn = result.Column - train.MasterColumn;
					result.DeltaAngle = 0.0;
					result.HasMasterDefined = true;
					result.DisplayDeltaFromMaster = true;
					result.Message = "Trial Run OK. DeltaY=" + result.DeltaRow.ToString("0.000") + ", DeltaX=" + result.DeltaColumn.ToString("0.000");
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x06000A97 RID: 2711 RVA: 0x00031080 File Offset: 0x0002F280
		private void ApplyDeltaToResult(ToolVision tool, BoundingBoxMasterResult result)
		{
			ShapeModelToolTrain train = (tool == null) ? null : (tool.TrainModel as ShapeModelToolTrain);
			bool flag = train == null;
			if (flag)
			{
				train = this.EnsureTrain(tool);
			}
			bool flag2 = train == null;
			if (!flag2)
			{
				train.LastRow = result.Row;
				train.LastColumn = result.Column;
				train.LastAngle = 0.0;
				train.LastScore = result.Score;
				result.HasMasterDefined = train.HasMasterDefined;
				bool flag3 = !train.HasMasterDefined;
				if (!flag3)
				{
					result.DeltaRow = result.Row - train.MasterRow;
					result.DeltaColumn = result.Column - train.MasterColumn;
					result.DeltaAngle = 0.0;
				}
			}
		}

		// Token: 0x06000A98 RID: 2712 RVA: 0x00031148 File Offset: 0x0002F348
		private ShapeModelToolTrain EnsureTrain(ToolVision tool)
		{
			bool flag = tool == null;
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (flag2)
				{
					train = new ShapeModelToolTrain();
					tool.TrainModel = train;
				}
				result = train;
			}
			return result;
		}

		// Token: 0x0400044A RID: 1098
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;
	}
}
