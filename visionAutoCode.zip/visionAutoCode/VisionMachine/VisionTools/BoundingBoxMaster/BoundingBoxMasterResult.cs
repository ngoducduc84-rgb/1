﻿using System;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.FindBoundingBox;

namespace VisionMachine.VisionTools.BoundingBoxMaster
{
	// Token: 0x020000D1 RID: 209
	public class BoundingBoxMasterResult : ShapeMatchResult, IDisposable
	{
		// Token: 0x170003AA RID: 938
		// (get) Token: 0x06000A99 RID: 2713 RVA: 0x0003118B File Offset: 0x0002F38B
		// (set) Token: 0x06000A9A RID: 2714 RVA: 0x00031193 File Offset: 0x0002F393
		public string ToolName { get; set; }

		// Token: 0x170003AB RID: 939
		// (get) Token: 0x06000A9B RID: 2715 RVA: 0x0003119C File Offset: 0x0002F39C
		// (set) Token: 0x06000A9C RID: 2716 RVA: 0x000311A4 File Offset: 0x0002F3A4
		public FindBoundingBoxResult BoundingBoxResult { get; set; }

		// Token: 0x170003AC RID: 940
		// (get) Token: 0x06000A9D RID: 2717 RVA: 0x000311AD File Offset: 0x0002F3AD
		// (set) Token: 0x06000A9E RID: 2718 RVA: 0x000311B5 File Offset: 0x0002F3B5
		public bool DisplayDeltaFromMaster { get; set; }

		// Token: 0x170003AD RID: 941
		// (get) Token: 0x06000A9F RID: 2719 RVA: 0x000311BE File Offset: 0x0002F3BE
		// (set) Token: 0x06000AA0 RID: 2720 RVA: 0x000311C6 File Offset: 0x0002F3C6
		public bool HasMasterDefined { get; set; }

		// Token: 0x170003AE RID: 942
		// (get) Token: 0x06000AA1 RID: 2721 RVA: 0x000311CF File Offset: 0x0002F3CF
		// (set) Token: 0x06000AA2 RID: 2722 RVA: 0x000311D7 File Offset: 0x0002F3D7
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x06000AA3 RID: 2723 RVA: 0x000311E0 File Offset: 0x0002F3E0
		public void Dispose()
		{
			FindBoundingBoxResult boundingBoxResult = this.BoundingBoxResult;
			if (boundingBoxResult != null)
			{
				boundingBoxResult.Dispose();
			}
		}
	}
}
