﻿using System;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.FindBoundingBox;

namespace VisionMachine.VisionTools.BoundingBoxMaster
{
	// Token: 0x020000D2 RID: 210
	public class BoundingBoxMasterResultDrawer
	{
		// Token: 0x06000AA5 RID: 2725 RVA: 0x000311F5 File Offset: 0x0002F3F5
		public void Draw(HWindow window, ToolVision tool, BoundingBoxMasterResult result)
		{
			this.Draw(window, tool, result, true);
		}

		// Token: 0x06000AA6 RID: 2726 RVA: 0x00031204 File Offset: 0x0002F404
		public void Draw(HWindow window, ToolVision tool, BoundingBoxMasterResult result, bool fillThreshold)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				this._boxDrawer.Draw(window, tool, result.BoundingBoxResult, fillThreshold);
				BoundingBoxMasterToolConfig config = tool.Config as BoundingBoxMasterToolConfig;
				bool flag2 = config == null || !config.ShowText || !result.IsSuccess || !result.DisplayDeltaFromMaster;
				if (!flag2)
				{
					HOperatorSet.SetColor(window, config.TextColor);
					HOperatorSet.SetTposition(window, result.Row + 18.0, result.Column);
					HOperatorSet.WriteString(window, "DeltaY=" + result.DeltaRow.ToString("0.000") + " DeltaX=" + result.DeltaColumn.ToString("0.000"));
				}
			}
		}

		// Token: 0x04000450 RID: 1104
		private readonly FindBoundingBoxResultDrawer _boxDrawer = new FindBoundingBoxResultDrawer();
	}
}
