﻿using System;
using VisionMachine.VisionTools.FindBoundingBox;

namespace VisionMachine.VisionTools.BoundingBoxMaster
{
	// Token: 0x020000D3 RID: 211
	public class BoundingBoxMasterToolConfig : FindBoundingBoxToolConfig
	{
	}
}
