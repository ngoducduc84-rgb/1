﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.BoundingBoxMaster.Views
{
	// Token: 0x020000D4 RID: 212
	public partial class BoundingBoxMaster_para : System.Windows.Controls.UserControl, IStyleConnector
	{
		// Token: 0x06000AA9 RID: 2729 RVA: 0x0003131A File Offset: 0x0002F51A
		public BoundingBoxMaster_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000AAA RID: 2730 RVA: 0x0003132B File Offset: 0x0002F52B
		private void BtnMatching_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.BoundingBoxMasterMatching();
			}
		}

		// Token: 0x06000AAB RID: 2731 RVA: 0x0003133F File Offset: 0x0002F53F
		private void BtnMasterDefine_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.BoundingBoxMasterDefineMaster();
			}
		}

		// Token: 0x06000AAC RID: 2732 RVA: 0x00031353 File Offset: 0x0002F553
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.BoundingBoxMasterTrialRun();
			}
		}

		// Token: 0x06000AAD RID: 2733 RVA: 0x00031368 File Offset: 0x0002F568
		private void BtnMoreColor_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement button = sender as FrameworkElement;
			object valueSource = (button != null) ? button.Tag : null;
			PropertyInfo valueProperty = (valueSource != null) ? valueSource.GetType().GetProperty("Value") : null;
			bool flag = valueSource == null || valueProperty == null;
			if (!flag)
			{
				ColorDialog dialog = new ColorDialog
				{
					FullOpen = true
				};
				object currentColor = valueProperty.GetValue(valueSource, null);
				string colorText = currentColor as string;
				System.Windows.Media.Color currentMediaColor;
				bool flag2 = colorText != null && this.TryParseColor(colorText, out currentMediaColor);
				if (flag2)
				{
					dialog.Color = System.Drawing.Color.FromArgb((int)currentMediaColor.A, (int)currentMediaColor.R, (int)currentMediaColor.G, (int)currentMediaColor.B);
				}
				bool flag3 = dialog.ShowDialog() != DialogResult.OK;
				if (!flag3)
				{
					System.Windows.Media.Color selectedColor = System.Windows.Media.Color.FromArgb(dialog.Color.A, dialog.Color.R, dialog.Color.G, dialog.Color.B);
					valueProperty.SetValue(valueSource, "#" + selectedColor.R.ToString("X2") + selectedColor.G.ToString("X2") + selectedColor.B.ToString("X2"), null);
				}
			}
		}

		// Token: 0x06000AAE RID: 2734 RVA: 0x000314C8 File Offset: 0x0002F6C8
		private bool TryParseColor(string colorText, out System.Windows.Media.Color color)
		{
			color = Colors.Lime;
			bool flag = string.IsNullOrWhiteSpace(colorText);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(colorText);
					result = true;
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06000AB1 RID: 2737 RVA: 0x000315D8 File Offset: 0x0002F7D8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((SimpleButton)target).Click += this.BtnMoreColor_Click;
			}
		}
	}
}
