﻿using System;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C1 RID: 193
	public class CalibHandEyeActionService : IToolActionService
	{
		// Token: 0x17000352 RID: 850
		// (get) Token: 0x060009A9 RID: 2473 RVA: 0x0002C63C File Offset: 0x0002A83C
		public ToolType ToolType
		{
			get
			{
				return ToolType.CalibHandEye;
			}
		}

		// Token: 0x060009AA RID: 2474 RVA: 0x0002C650 File Offset: 0x0002A850
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						Stopwatch stopwatch = Stopwatch.StartNew();
						CalibHandEyeResult result = this._processor.TrialRun(processContext, tool);
						stopwatch.Stop();
						bool flag3 = result.TotalProcessingTimeMs <= 0.0;
						if (flag3)
						{
							result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						Action<ToolVision, object> resultReporter = context.ResultReporter;
						if (resultReporter != null)
						{
							resultReporter(tool, result);
						}
						context.DisplayController.DisplayImage(original);
						context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
						{
							this.DrawMasterOverlay(window, result);
							this._drawer.Draw(window, tool, result);
						}, null);
					}
				}
				finally
				{
					bool flag4 = bufferStore != null;
					if (flag4)
					{
						bufferStore.Clear();
					}
					bool flag5 = original != null;
					if (flag5)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x060009AB RID: 2475 RVA: 0x0002C7FC File Offset: 0x0002A9FC
		private void DrawMasterOverlay(HWindow window, CalibHandEyeResult result)
		{
			bool flag = window == null || result == null || result.MasterTool == null || result.MasterMatchResult == null;
			if (!flag)
			{
				bool flag2 = result.MasterTool.ToolType != ToolType.Shape_model && result.MasterTool.ToolType != ToolType.AnisoShapeModel;
				if (!flag2)
				{
					ShapeMatchResult displayResult = CalibHandEyeActionService.CreateMasterDisplayResult(result);
					this._masterDrawer.DrawRoiOverlays(window, result.MasterTool, displayResult);
					this._masterDrawer.DrawTrialResult(result.MasterTool, window, displayResult);
				}
			}
		}

		// Token: 0x060009AC RID: 2476 RVA: 0x0002C884 File Offset: 0x0002AA84
		private static ShapeMatchResult CreateMasterDisplayResult(CalibHandEyeResult result)
		{
			bool flag = result == null || result.MasterMatchResult == null || result.ObjectMode != CalibHandEyeObjectMode.SingleSelected || result.MasterMatchResult.Matches == null || result.MasterMatchResult.Matches.Count <= 1;
			ShapeMatchResult result2;
			if (flag)
			{
				result2 = ((result == null) ? null : result.MasterMatchResult);
			}
			else
			{
				ShapeMatchCandidate selected = (from x in result.MasterMatchResult.Matches
				where x.GridRow == result.MasterMatchResult.GridRow && x.GridColumn == result.MasterMatchResult.GridColumn
				orderby x.Score descending, x.Index
				select x).FirstOrDefault<ShapeMatchCandidate>();
				bool flag2 = selected == null;
				if (flag2)
				{
					selected = (from x in result.MasterMatchResult.Matches
					orderby Math.Abs(x.Row - result.MasterMatchResult.Row) + Math.Abs(x.Column - result.MasterMatchResult.Column), x.Score descending
					select x).FirstOrDefault<ShapeMatchCandidate>();
				}
				bool flag3 = selected == null;
				if (flag3)
				{
					result2 = result.MasterMatchResult;
				}
				else
				{
					ShapeMatchResult displayResult = new ShapeMatchResult
					{
						IsSuccess = result.MasterMatchResult.IsSuccess,
						GridRow = selected.GridRow,
						GridColumn = selected.GridColumn,
						Row = selected.Row,
						Column = selected.Column,
						Angle = selected.Angle,
						Score = selected.Score,
						ScaleRow = selected.ScaleRow,
						ScaleColumn = selected.ScaleColumn,
						DeltaRow = selected.DeltaRow,
						DeltaColumn = selected.DeltaColumn,
						DeltaAngle = selected.DeltaAngle,
						ProcessingTimeMs = result.MasterMatchResult.ProcessingTimeMs,
						InputSourceToolName = result.MasterMatchResult.InputSourceToolName,
						InputProcessingTimeMs = result.MasterMatchResult.InputProcessingTimeMs,
						RoiName = result.MasterMatchResult.RoiName,
						Message = result.MasterMatchResult.Message
					};
					displayResult.Matches.Add(selected);
					result2 = displayResult;
				}
			}
			return result2;
		}

		// Token: 0x040003E5 RID: 997
		private readonly CalibHandEyeProcessor _processor = new CalibHandEyeProcessor();

		// Token: 0x040003E6 RID: 998
		private readonly CalibHandEyeResultDrawer _drawer = new CalibHandEyeResultDrawer();

		// Token: 0x040003E7 RID: 999
		private readonly ShapeModelResultDrawer _masterDrawer = new ShapeModelResultDrawer();
	}
}
