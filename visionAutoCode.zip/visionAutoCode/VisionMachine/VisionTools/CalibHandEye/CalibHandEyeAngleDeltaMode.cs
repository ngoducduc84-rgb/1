﻿using System;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000CA RID: 202
	public enum CalibHandEyeAngleDeltaMode
	{
		// Token: 0x04000435 RID: 1077
		ShortestRotation,
		// Token: 0x04000436 RID: 1078
		TargetInRange
	}
}
