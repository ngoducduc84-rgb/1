﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using HalconDotNet;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C2 RID: 194
	public static class CalibHandEyeCalibrationCache
	{
		// Token: 0x060009AE RID: 2478 RVA: 0x0002CB54 File Offset: 0x0002AD54
		public static HTuple GetHomMat2d(string path)
		{
			return CalibHandEyeCalibrationCache.GetCalibData(path).HomMat2d;
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x0002CB74 File Offset: 0x0002AD74
		public static CalibHandEyeCalibrationCache.CalibData GetCalibData(string path)
		{
			string normalizedPath = CalibHandEyeCalibrationCache.NormalizePath(path);
			DateTime lastWriteTimeUtc = File.GetLastWriteTimeUtc(normalizedPath);
			object syncRoot = CalibHandEyeCalibrationCache.SyncRoot;
			CalibHandEyeCalibrationCache.CalibData result;
			lock (syncRoot)
			{
				CalibHandEyeCalibrationCache.CacheEntry entry;
				bool flag2 = !CalibHandEyeCalibrationCache.Cache.TryGetValue(normalizedPath, out entry) || entry.LastWriteTimeUtc != lastWriteTimeUtc;
				if (flag2)
				{
					entry = CalibHandEyeCalibrationCache.LoadEntry(normalizedPath, lastWriteTimeUtc);
					CalibHandEyeCalibrationCache.Cache[normalizedPath] = entry;
				}
				result = new CalibHandEyeCalibrationCache.CalibData
				{
					FormatVersion = entry.FormatVersion,
					HomMat2d = new HTuple(entry.HomMat2dValues),
					TcpCenterCol = entry.TcpCenterCol,
					TcpCenterRow = entry.TcpCenterRow,
					TcpRadiusPx = entry.TcpRadiusPx,
					TcpCenterRobotX = entry.TcpCenterRobotX,
					TcpCenterRobotY = entry.TcpCenterRobotY,
					AngleOffsetDeg = entry.AngleOffsetDeg,
					TcpAppliedToMapping = entry.TcpAppliedToMapping,
					HasTcpReference = entry.HasTcpReference,
					ReferencePatternCol = entry.ReferencePatternCol,
					ReferencePatternRow = entry.ReferencePatternRow,
					ReferenceVisionAngleDeg = entry.ReferenceVisionAngleDeg,
					MappingVisionAngleDeg = entry.MappingVisionAngleDeg,
					HasMappingVisionAngle = entry.HasMappingVisionAngle,
					TcpValid = entry.TcpValid
				};
			}
			return result;
		}

		// Token: 0x060009B0 RID: 2480 RVA: 0x0002CCF8 File Offset: 0x0002AEF8
		public static int PreloadFromCameras(IEnumerable<CameraNode> cameras)
		{
			bool flag = cameras == null;
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				int count = 0;
				foreach (CameraNode camera in cameras)
				{
					bool flag2 = ((camera != null) ? camera.TurnSnaps : null) == null;
					if (!flag2)
					{
						foreach (TurnSnap turnSnap in camera.TurnSnaps)
						{
							bool flag3 = ((turnSnap != null) ? turnSnap.Tools : null) == null;
							if (!flag3)
							{
								foreach (ToolVision tool in turnSnap.Tools)
								{
									CalibHandEyeToolConfig config = ((tool != null) ? tool.Config : null) as CalibHandEyeToolConfig;
									bool flag4 = config == null || string.IsNullOrWhiteSpace(config.CalibrationFilePath) || !File.Exists(config.CalibrationFilePath);
									if (!flag4)
									{
										CalibHandEyeCalibrationCache.GetHomMat2d(config.CalibrationFilePath);
										count++;
									}
								}
							}
						}
					}
				}
				result = count;
			}
			return result;
		}

		// Token: 0x060009B1 RID: 2481 RVA: 0x0002CE90 File Offset: 0x0002B090
		private static CalibHandEyeCalibrationCache.CacheEntry LoadEntry(string normalizedPath, DateTime lastWriteTimeUtc)
		{
			HTuple tuple;
			HOperatorSet.ReadTuple(normalizedPath, out tuple);
			bool flag = tuple == null || tuple.Length < 6;
			if (flag)
			{
				throw new InvalidOperationException("Calibration tuple is invalid. Need at least 6 values (a hom_mat2d).");
			}
			bool visionMachineFormat = tuple.Length >= 9;
			int homStart = visionMachineFormat ? 3 : 0;
			bool flag2 = tuple.Length < homStart + 6;
			if (flag2)
			{
				throw new InvalidOperationException("Calibration tuple is too short for its detected format.");
			}
			int formatVersion = (visionMachineFormat && tuple.Length > 0) ? ((int)Math.Round(tuple[0].D)) : 0;
			double tcpCol = (visionMachineFormat && tuple.Length > 14) ? tuple[14].D : 0.0;
			double tcpRow = (visionMachineFormat && tuple.Length > 15) ? tuple[15].D : 0.0;
			double tcpRadius = (visionMachineFormat && tuple.Length > 16) ? tuple[16].D : 0.0;
			double tcpRobotX = (visionMachineFormat && tuple.Length > 18) ? tuple[18].D : 0.0;
			double tcpRobotY = (visionMachineFormat && tuple.Length > 19) ? tuple[19].D : 0.0;
			double angleOffsetDeg = (visionMachineFormat && tuple.Length > 31) ? tuple[31].D : 0.0;
			bool tcpAppliedToMapping = visionMachineFormat && tuple.Length > 32 && Math.Abs(tuple[32].D) > 0.5;
			double referencePatternCol = (visionMachineFormat && tuple.Length > 33) ? tuple[33].D : 0.0;
			double referencePatternRow = (visionMachineFormat && tuple.Length > 34) ? tuple[34].D : 0.0;
			double referenceVisionAngleDeg = (visionMachineFormat && tuple.Length > 35) ? tuple[35].D : 0.0;
			bool hasTcpReference = visionMachineFormat && tuple.Length > 35;
			double mappingVisionAngleDeg = (visionMachineFormat && tuple.Length > 36) ? tuple[36].D : 0.0;
			bool hasMappingVisionAngle = visionMachineFormat && tuple.Length > 36;
			bool tcpValid = tcpRadius > 0.0 && (tcpCol != 0.0 || tcpRow != 0.0);
			double txtCol;
			double txtRow;
			double txtRadius;
			double txtRobotX;
			double txtRobotY;
			double txtAngleOffsetDeg;
			bool txtHasAngleOffset;
			bool txtTcpAppliedToMapping;
			bool txtHasTcpAppliedToMapping;
			double txtReferencePatternCol;
			double txtReferencePatternRow;
			bool txtHasReferencePattern;
			double txtReferenceVisionAngleDeg;
			bool txtHasReferenceVisionAngle;
			double txtMappingVisionAngleDeg;
			bool txtHasMappingVisionAngle;
			bool flag3 = CalibHandEyeCalibrationCache.TryReadTcpFromTxt(normalizedPath, out txtCol, out txtRow, out txtRadius, out txtRobotX, out txtRobotY, out txtAngleOffsetDeg, out txtHasAngleOffset, out txtTcpAppliedToMapping, out txtHasTcpAppliedToMapping, out txtReferencePatternCol, out txtReferencePatternRow, out txtHasReferencePattern, out txtReferenceVisionAngleDeg, out txtHasReferenceVisionAngle, out txtMappingVisionAngleDeg, out txtHasMappingVisionAngle);
			if (flag3)
			{
				tcpCol = txtCol;
				tcpRow = txtRow;
				bool flag4 = txtRadius > 0.0;
				if (flag4)
				{
					tcpRadius = txtRadius;
				}
				bool flag5 = txtRobotX != 0.0 || txtRobotY != 0.0;
				if (flag5)
				{
					tcpRobotX = txtRobotX;
					tcpRobotY = txtRobotY;
				}
				bool flag6 = txtHasAngleOffset;
				if (flag6)
				{
					angleOffsetDeg = txtAngleOffsetDeg;
				}
				bool flag7 = txtHasTcpAppliedToMapping;
				if (flag7)
				{
					tcpAppliedToMapping = txtTcpAppliedToMapping;
				}
				bool flag8 = txtHasReferencePattern;
				if (flag8)
				{
					referencePatternCol = txtReferencePatternCol;
					referencePatternRow = txtReferencePatternRow;
					hasTcpReference = true;
				}
				bool flag9 = txtHasReferenceVisionAngle;
				if (flag9)
				{
					referenceVisionAngleDeg = txtReferenceVisionAngleDeg;
					hasTcpReference = true;
				}
				bool flag10 = txtHasMappingVisionAngle;
				if (flag10)
				{
					mappingVisionAngleDeg = txtMappingVisionAngleDeg;
					hasMappingVisionAngle = true;
				}
				tcpValid = true;
			}
			double[] homValues = (from index in Enumerable.Range(homStart, 6)
			select tuple[index].D).ToArray<double>();
			string[] array = new string[10];
			array[0] = "Loaded '";
			array[1] = Path.GetFileName(normalizedPath);
			array[2] = "' len=";
			array[3] = tuple.Length.ToString();
			array[4] = " format=";
			array[5] = (visionMachineFormat ? "VisionMachine(hom@3..8)" : "raw(hom@0..5)");
			array[6] = " hom=[";
			array[7] = string.Join(", ", from v in homValues
			select v.ToString("0.######", CultureInfo.InvariantCulture));
			array[8] = "] tcpValid=";
			array[9] = tcpValid.ToString();
			CalibHandEyeCalibrationCache.Log(string.Concat(array));
			return new CalibHandEyeCalibrationCache.CacheEntry
			{
				FormatVersion = formatVersion,
				LastWriteTimeUtc = lastWriteTimeUtc,
				HomMat2dValues = homValues,
				TcpCenterCol = tcpCol,
				TcpCenterRow = tcpRow,
				TcpRadiusPx = tcpRadius,
				TcpCenterRobotX = tcpRobotX,
				TcpCenterRobotY = tcpRobotY,
				AngleOffsetDeg = angleOffsetDeg,
				TcpAppliedToMapping = tcpAppliedToMapping,
				HasTcpReference = hasTcpReference,
				ReferencePatternCol = referencePatternCol,
				ReferencePatternRow = referencePatternRow,
				ReferenceVisionAngleDeg = referenceVisionAngleDeg,
				MappingVisionAngleDeg = mappingVisionAngleDeg,
				HasMappingVisionAngle = hasMappingVisionAngle,
				TcpValid = tcpValid
			};
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x0002D408 File Offset: 0x0002B608
		private static bool TryReadTcpFromTxt(string datPath, out double col, out double row, out double radius, out double robotX, out double robotY, out double angleOffsetDeg, out bool hasAngleOffset, out bool tcpAppliedToMapping, out bool hasTcpAppliedToMapping, out double referencePatternCol, out double referencePatternRow, out bool hasReferencePattern, out double referenceVisionAngleDeg, out bool hasReferenceVisionAngle, out double mappingVisionAngleDeg, out bool hasMappingVisionAngle)
		{
			col = (row = (radius = (robotX = (robotY = 0.0))));
			angleOffsetDeg = 0.0;
			hasAngleOffset = false;
			tcpAppliedToMapping = false;
			hasTcpAppliedToMapping = false;
			referencePatternCol = 0.0;
			referencePatternRow = 0.0;
			hasReferencePattern = false;
			referenceVisionAngleDeg = 0.0;
			hasReferenceVisionAngle = false;
			mappingVisionAngleDeg = 0.0;
			hasMappingVisionAngle = false;
			bool result;
			try
			{
				string txtPath = Path.ChangeExtension(datPath, ".txt");
				bool flag = !File.Exists(txtPath);
				if (flag)
				{
					result = false;
				}
				else
				{
					foreach (string rawLine in File.ReadAllLines(txtPath))
					{
						string line = rawLine.Trim();
						bool flag2 = line.Length == 0 || line.StartsWith("#");
						if (!flag2)
						{
							bool flag3 = line.StartsWith("CircleCenterImage", StringComparison.OrdinalIgnoreCase);
							if (flag3)
							{
								CalibHandEyeCalibrationCache.TryParsePair(line, out col, out row);
							}
							else
							{
								bool flag4 = line.StartsWith("CircleCenterRobot", StringComparison.OrdinalIgnoreCase);
								if (flag4)
								{
									CalibHandEyeCalibrationCache.TryParsePair(line, out robotX, out robotY);
								}
								else
								{
									bool flag5 = line.StartsWith("AngleOffset", StringComparison.OrdinalIgnoreCase);
									if (flag5)
									{
										bool flag6 = CalibHandEyeCalibrationCache.TryParseSingle(line, out angleOffsetDeg);
										if (flag6)
										{
											hasAngleOffset = true;
										}
									}
									else
									{
										bool flag7 = line.StartsWith("ReferencePattern", StringComparison.OrdinalIgnoreCase);
										if (flag7)
										{
											CalibHandEyeCalibrationCache.TryParsePair(line, out referencePatternCol, out referencePatternRow);
											hasReferencePattern = (referencePatternCol != 0.0 || referencePatternRow != 0.0);
										}
										else
										{
											bool flag8 = line.StartsWith("ReferenceVisionA", StringComparison.OrdinalIgnoreCase);
											if (flag8)
											{
												bool flag9 = CalibHandEyeCalibrationCache.TryParseSingle(line, out referenceVisionAngleDeg);
												if (flag9)
												{
													hasReferenceVisionAngle = true;
												}
											}
											else
											{
												bool flag10 = line.StartsWith("MappingVisionA", StringComparison.OrdinalIgnoreCase);
												if (flag10)
												{
													bool flag11 = CalibHandEyeCalibrationCache.TryParseSingle(line, out mappingVisionAngleDeg);
													if (flag11)
													{
														hasMappingVisionAngle = true;
													}
												}
												else
												{
													bool flag12 = line.StartsWith("TcpAppliedToMapping", StringComparison.OrdinalIgnoreCase);
													if (flag12)
													{
														string value = line.Substring(line.IndexOf('=') + 1).Trim();
														tcpAppliedToMapping = (value.Equals("true", StringComparison.OrdinalIgnoreCase) || value.Equals("1", StringComparison.OrdinalIgnoreCase));
														hasTcpAppliedToMapping = true;
													}
													else
													{
														bool flag13 = line.StartsWith("CircleRadius", StringComparison.OrdinalIgnoreCase);
														if (flag13)
														{
															CalibHandEyeCalibrationCache.TryParseSingle(line, out radius);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					result = (col != 0.0 || row != 0.0);
				}
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x0002D6D4 File Offset: 0x0002B8D4
		private static bool TryParseSingle(string line, out double value)
		{
			value = 0.0;
			Match i = Regex.Match(line, "=\\s*(-?[\\d.]+(?:[eE][+-]?\\d+)?)");
			return i.Success && double.TryParse(i.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out value);
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x0002D72C File Offset: 0x0002B92C
		private static void TryParsePair(string line, out double a, out double b)
		{
			a = 0.0;
			b = 0.0;
			Match i = Regex.Match(line, "\\(\\s*(-?[\\d.]+)\\s*,\\s*(-?[\\d.]+)\\s*\\)");
			bool flag = !i.Success;
			if (!flag)
			{
				double.TryParse(i.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out a);
				double.TryParse(i.Groups[2].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out b);
			}
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x0002D7B0 File Offset: 0x0002B9B0
		private static void Log(string message)
		{
			try
			{
				string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VisionMachine");
				Directory.CreateDirectory(folder);
				File.AppendAllText(Path.Combine(folder, "calib_tcp_log.txt"), string.Concat(new string[]
				{
					"[",
					DateTime.Now.ToString("HH:mm:ss"),
					"] CACHE ",
					message,
					Environment.NewLine
				}));
			}
			catch
			{
			}
		}

		// Token: 0x060009B6 RID: 2486 RVA: 0x0002D840 File Offset: 0x0002BA40
		private static string NormalizePath(string path)
		{
			bool flag = string.IsNullOrWhiteSpace(path);
			if (flag)
			{
				throw new InvalidOperationException("Calibration file path is empty.");
			}
			string fullPath = Path.GetFullPath(path);
			bool flag2 = !File.Exists(fullPath);
			if (flag2)
			{
				throw new FileNotFoundException("Calibration file was not found.", fullPath);
			}
			return fullPath;
		}

		// Token: 0x040003E8 RID: 1000
		private static readonly object SyncRoot = new object();

		// Token: 0x040003E9 RID: 1001
		private static readonly Dictionary<string, CalibHandEyeCalibrationCache.CacheEntry> Cache = new Dictionary<string, CalibHandEyeCalibrationCache.CacheEntry>(StringComparer.OrdinalIgnoreCase);

		// Token: 0x02000329 RID: 809
		private sealed class CacheEntry
		{
			// Token: 0x17000B3A RID: 2874
			// (get) Token: 0x060027C8 RID: 10184 RVA: 0x000E0C62 File Offset: 0x000DEE62
			// (set) Token: 0x060027C9 RID: 10185 RVA: 0x000E0C6A File Offset: 0x000DEE6A
			public int FormatVersion { get; set; }

			// Token: 0x17000B3B RID: 2875
			// (get) Token: 0x060027CA RID: 10186 RVA: 0x000E0C73 File Offset: 0x000DEE73
			// (set) Token: 0x060027CB RID: 10187 RVA: 0x000E0C7B File Offset: 0x000DEE7B
			public DateTime LastWriteTimeUtc { get; set; }

			// Token: 0x17000B3C RID: 2876
			// (get) Token: 0x060027CC RID: 10188 RVA: 0x000E0C84 File Offset: 0x000DEE84
			// (set) Token: 0x060027CD RID: 10189 RVA: 0x000E0C8C File Offset: 0x000DEE8C
			public double[] HomMat2dValues { get; set; }

			// Token: 0x17000B3D RID: 2877
			// (get) Token: 0x060027CE RID: 10190 RVA: 0x000E0C95 File Offset: 0x000DEE95
			// (set) Token: 0x060027CF RID: 10191 RVA: 0x000E0C9D File Offset: 0x000DEE9D
			public double TcpCenterCol { get; set; }

			// Token: 0x17000B3E RID: 2878
			// (get) Token: 0x060027D0 RID: 10192 RVA: 0x000E0CA6 File Offset: 0x000DEEA6
			// (set) Token: 0x060027D1 RID: 10193 RVA: 0x000E0CAE File Offset: 0x000DEEAE
			public double TcpCenterRow { get; set; }

			// Token: 0x17000B3F RID: 2879
			// (get) Token: 0x060027D2 RID: 10194 RVA: 0x000E0CB7 File Offset: 0x000DEEB7
			// (set) Token: 0x060027D3 RID: 10195 RVA: 0x000E0CBF File Offset: 0x000DEEBF
			public double TcpRadiusPx { get; set; }

			// Token: 0x17000B40 RID: 2880
			// (get) Token: 0x060027D4 RID: 10196 RVA: 0x000E0CC8 File Offset: 0x000DEEC8
			// (set) Token: 0x060027D5 RID: 10197 RVA: 0x000E0CD0 File Offset: 0x000DEED0
			public bool TcpValid { get; set; }

			// Token: 0x17000B41 RID: 2881
			// (get) Token: 0x060027D6 RID: 10198 RVA: 0x000E0CD9 File Offset: 0x000DEED9
			// (set) Token: 0x060027D7 RID: 10199 RVA: 0x000E0CE1 File Offset: 0x000DEEE1
			public double TcpCenterRobotX { get; set; }

			// Token: 0x17000B42 RID: 2882
			// (get) Token: 0x060027D8 RID: 10200 RVA: 0x000E0CEA File Offset: 0x000DEEEA
			// (set) Token: 0x060027D9 RID: 10201 RVA: 0x000E0CF2 File Offset: 0x000DEEF2
			public double TcpCenterRobotY { get; set; }

			// Token: 0x17000B43 RID: 2883
			// (get) Token: 0x060027DA RID: 10202 RVA: 0x000E0CFB File Offset: 0x000DEEFB
			// (set) Token: 0x060027DB RID: 10203 RVA: 0x000E0D03 File Offset: 0x000DEF03
			public double AngleOffsetDeg { get; set; }

			// Token: 0x17000B44 RID: 2884
			// (get) Token: 0x060027DC RID: 10204 RVA: 0x000E0D0C File Offset: 0x000DEF0C
			// (set) Token: 0x060027DD RID: 10205 RVA: 0x000E0D14 File Offset: 0x000DEF14
			public bool TcpAppliedToMapping { get; set; }

			// Token: 0x17000B45 RID: 2885
			// (get) Token: 0x060027DE RID: 10206 RVA: 0x000E0D1D File Offset: 0x000DEF1D
			// (set) Token: 0x060027DF RID: 10207 RVA: 0x000E0D25 File Offset: 0x000DEF25
			public bool HasTcpReference { get; set; }

			// Token: 0x17000B46 RID: 2886
			// (get) Token: 0x060027E0 RID: 10208 RVA: 0x000E0D2E File Offset: 0x000DEF2E
			// (set) Token: 0x060027E1 RID: 10209 RVA: 0x000E0D36 File Offset: 0x000DEF36
			public double ReferencePatternCol { get; set; }

			// Token: 0x17000B47 RID: 2887
			// (get) Token: 0x060027E2 RID: 10210 RVA: 0x000E0D3F File Offset: 0x000DEF3F
			// (set) Token: 0x060027E3 RID: 10211 RVA: 0x000E0D47 File Offset: 0x000DEF47
			public double ReferencePatternRow { get; set; }

			// Token: 0x17000B48 RID: 2888
			// (get) Token: 0x060027E4 RID: 10212 RVA: 0x000E0D50 File Offset: 0x000DEF50
			// (set) Token: 0x060027E5 RID: 10213 RVA: 0x000E0D58 File Offset: 0x000DEF58
			public double ReferenceVisionAngleDeg { get; set; }

			// Token: 0x17000B49 RID: 2889
			// (get) Token: 0x060027E6 RID: 10214 RVA: 0x000E0D61 File Offset: 0x000DEF61
			// (set) Token: 0x060027E7 RID: 10215 RVA: 0x000E0D69 File Offset: 0x000DEF69
			public double MappingVisionAngleDeg { get; set; }

			// Token: 0x17000B4A RID: 2890
			// (get) Token: 0x060027E8 RID: 10216 RVA: 0x000E0D72 File Offset: 0x000DEF72
			// (set) Token: 0x060027E9 RID: 10217 RVA: 0x000E0D7A File Offset: 0x000DEF7A
			public bool HasMappingVisionAngle { get; set; }
		}

		// Token: 0x0200032A RID: 810
		public sealed class CalibData
		{
			// Token: 0x17000B4B RID: 2891
			// (get) Token: 0x060027EB RID: 10219 RVA: 0x000E0D83 File Offset: 0x000DEF83
			// (set) Token: 0x060027EC RID: 10220 RVA: 0x000E0D8B File Offset: 0x000DEF8B
			public int FormatVersion { get; set; }

			// Token: 0x17000B4C RID: 2892
			// (get) Token: 0x060027ED RID: 10221 RVA: 0x000E0D94 File Offset: 0x000DEF94
			// (set) Token: 0x060027EE RID: 10222 RVA: 0x000E0D9C File Offset: 0x000DEF9C
			public HTuple HomMat2d { get; set; }

			// Token: 0x17000B4D RID: 2893
			// (get) Token: 0x060027EF RID: 10223 RVA: 0x000E0DA5 File Offset: 0x000DEFA5
			// (set) Token: 0x060027F0 RID: 10224 RVA: 0x000E0DAD File Offset: 0x000DEFAD
			public double TcpCenterCol { get; set; }

			// Token: 0x17000B4E RID: 2894
			// (get) Token: 0x060027F1 RID: 10225 RVA: 0x000E0DB6 File Offset: 0x000DEFB6
			// (set) Token: 0x060027F2 RID: 10226 RVA: 0x000E0DBE File Offset: 0x000DEFBE
			public double TcpCenterRow { get; set; }

			// Token: 0x17000B4F RID: 2895
			// (get) Token: 0x060027F3 RID: 10227 RVA: 0x000E0DC7 File Offset: 0x000DEFC7
			// (set) Token: 0x060027F4 RID: 10228 RVA: 0x000E0DCF File Offset: 0x000DEFCF
			public double TcpRadiusPx { get; set; }

			// Token: 0x17000B50 RID: 2896
			// (get) Token: 0x060027F5 RID: 10229 RVA: 0x000E0DD8 File Offset: 0x000DEFD8
			// (set) Token: 0x060027F6 RID: 10230 RVA: 0x000E0DE0 File Offset: 0x000DEFE0
			public double TcpCenterRobotX { get; set; }

			// Token: 0x17000B51 RID: 2897
			// (get) Token: 0x060027F7 RID: 10231 RVA: 0x000E0DE9 File Offset: 0x000DEFE9
			// (set) Token: 0x060027F8 RID: 10232 RVA: 0x000E0DF1 File Offset: 0x000DEFF1
			public double TcpCenterRobotY { get; set; }

			// Token: 0x17000B52 RID: 2898
			// (get) Token: 0x060027F9 RID: 10233 RVA: 0x000E0DFA File Offset: 0x000DEFFA
			// (set) Token: 0x060027FA RID: 10234 RVA: 0x000E0E02 File Offset: 0x000DF002
			public double AngleOffsetDeg { get; set; }

			// Token: 0x17000B53 RID: 2899
			// (get) Token: 0x060027FB RID: 10235 RVA: 0x000E0E0B File Offset: 0x000DF00B
			// (set) Token: 0x060027FC RID: 10236 RVA: 0x000E0E13 File Offset: 0x000DF013
			public bool TcpAppliedToMapping { get; set; }

			// Token: 0x17000B54 RID: 2900
			// (get) Token: 0x060027FD RID: 10237 RVA: 0x000E0E1C File Offset: 0x000DF01C
			// (set) Token: 0x060027FE RID: 10238 RVA: 0x000E0E24 File Offset: 0x000DF024
			public bool HasTcpReference { get; set; }

			// Token: 0x17000B55 RID: 2901
			// (get) Token: 0x060027FF RID: 10239 RVA: 0x000E0E2D File Offset: 0x000DF02D
			// (set) Token: 0x06002800 RID: 10240 RVA: 0x000E0E35 File Offset: 0x000DF035
			public double ReferencePatternCol { get; set; }

			// Token: 0x17000B56 RID: 2902
			// (get) Token: 0x06002801 RID: 10241 RVA: 0x000E0E3E File Offset: 0x000DF03E
			// (set) Token: 0x06002802 RID: 10242 RVA: 0x000E0E46 File Offset: 0x000DF046
			public double ReferencePatternRow { get; set; }

			// Token: 0x17000B57 RID: 2903
			// (get) Token: 0x06002803 RID: 10243 RVA: 0x000E0E4F File Offset: 0x000DF04F
			// (set) Token: 0x06002804 RID: 10244 RVA: 0x000E0E57 File Offset: 0x000DF057
			public double ReferenceVisionAngleDeg { get; set; }

			// Token: 0x17000B58 RID: 2904
			// (get) Token: 0x06002805 RID: 10245 RVA: 0x000E0E60 File Offset: 0x000DF060
			// (set) Token: 0x06002806 RID: 10246 RVA: 0x000E0E68 File Offset: 0x000DF068
			public double MappingVisionAngleDeg { get; set; }

			// Token: 0x17000B59 RID: 2905
			// (get) Token: 0x06002807 RID: 10247 RVA: 0x000E0E71 File Offset: 0x000DF071
			// (set) Token: 0x06002808 RID: 10248 RVA: 0x000E0E79 File Offset: 0x000DF079
			public bool HasMappingVisionAngle { get; set; }

			// Token: 0x17000B5A RID: 2906
			// (get) Token: 0x06002809 RID: 10249 RVA: 0x000E0E82 File Offset: 0x000DF082
			// (set) Token: 0x0600280A RID: 10250 RVA: 0x000E0E8A File Offset: 0x000DF08A
			public bool TcpValid { get; set; }
		}
	}
}
