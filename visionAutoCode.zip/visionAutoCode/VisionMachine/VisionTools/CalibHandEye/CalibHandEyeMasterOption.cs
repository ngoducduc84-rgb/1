﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C4 RID: 196
	public class CalibHandEyeMasterOption
	{
		// Token: 0x17000357 RID: 855
		// (get) Token: 0x060009C5 RID: 2501 RVA: 0x0002DA7C File Offset: 0x0002BC7C
		// (set) Token: 0x060009C6 RID: 2502 RVA: 0x0002DA84 File Offset: 0x0002BC84
		public string ToolName { get; set; }

		// Token: 0x17000358 RID: 856
		// (get) Token: 0x060009C7 RID: 2503 RVA: 0x0002DA8D File Offset: 0x0002BC8D
		// (set) Token: 0x060009C8 RID: 2504 RVA: 0x0002DA95 File Offset: 0x0002BC95
		public int Index { get; set; }

		// Token: 0x17000359 RID: 857
		// (get) Token: 0x060009C9 RID: 2505 RVA: 0x0002DA9E File Offset: 0x0002BC9E
		// (set) Token: 0x060009CA RID: 2506 RVA: 0x0002DAA6 File Offset: 0x0002BCA6
		public ToolType ToolType { get; set; }

		// Token: 0x1700035A RID: 858
		// (get) Token: 0x060009CB RID: 2507 RVA: 0x0002DAB0 File Offset: 0x0002BCB0
		public string DisplayText
		{
			get
			{
				return this.ToolName;
			}
		}
	}
}
