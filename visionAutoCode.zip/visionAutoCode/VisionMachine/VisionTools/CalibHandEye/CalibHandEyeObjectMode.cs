﻿using System;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C9 RID: 201
	public enum CalibHandEyeObjectMode
	{
		// Token: 0x04000432 RID: 1074
		SingleSelected,
		// Token: 0x04000433 RID: 1075
		MultiObject
	}
}
