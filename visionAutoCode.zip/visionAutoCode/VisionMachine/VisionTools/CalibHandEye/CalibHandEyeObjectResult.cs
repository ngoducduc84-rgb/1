﻿using System;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C7 RID: 199
	public class CalibHandEyeObjectResult
	{
		// Token: 0x1700037E RID: 894
		// (get) Token: 0x06000A28 RID: 2600 RVA: 0x0002FCCD File Offset: 0x0002DECD
		// (set) Token: 0x06000A29 RID: 2601 RVA: 0x0002FCD5 File Offset: 0x0002DED5
		public int Index { get; set; }

		// Token: 0x1700037F RID: 895
		// (get) Token: 0x06000A2A RID: 2602 RVA: 0x0002FCDE File Offset: 0x0002DEDE
		// (set) Token: 0x06000A2B RID: 2603 RVA: 0x0002FCE6 File Offset: 0x0002DEE6
		public int GridRow { get; set; }

		// Token: 0x17000380 RID: 896
		// (get) Token: 0x06000A2C RID: 2604 RVA: 0x0002FCEF File Offset: 0x0002DEEF
		// (set) Token: 0x06000A2D RID: 2605 RVA: 0x0002FCF7 File Offset: 0x0002DEF7
		public int GridColumn { get; set; }

		// Token: 0x17000381 RID: 897
		// (get) Token: 0x06000A2E RID: 2606 RVA: 0x0002FD00 File Offset: 0x0002DF00
		// (set) Token: 0x06000A2F RID: 2607 RVA: 0x0002FD08 File Offset: 0x0002DF08
		public bool Picked { get; set; }

		// Token: 0x17000382 RID: 898
		// (get) Token: 0x06000A30 RID: 2608 RVA: 0x0002FD11 File Offset: 0x0002DF11
		// (set) Token: 0x06000A31 RID: 2609 RVA: 0x0002FD19 File Offset: 0x0002DF19
		public double PixelRow { get; set; }

		// Token: 0x17000383 RID: 899
		// (get) Token: 0x06000A32 RID: 2610 RVA: 0x0002FD22 File Offset: 0x0002DF22
		// (set) Token: 0x06000A33 RID: 2611 RVA: 0x0002FD2A File Offset: 0x0002DF2A
		public double PixelColumn { get; set; }

		// Token: 0x17000384 RID: 900
		// (get) Token: 0x06000A34 RID: 2612 RVA: 0x0002FD33 File Offset: 0x0002DF33
		// (set) Token: 0x06000A35 RID: 2613 RVA: 0x0002FD3B File Offset: 0x0002DF3B
		public double RobotX { get; set; }

		// Token: 0x17000385 RID: 901
		// (get) Token: 0x06000A36 RID: 2614 RVA: 0x0002FD44 File Offset: 0x0002DF44
		// (set) Token: 0x06000A37 RID: 2615 RVA: 0x0002FD4C File Offset: 0x0002DF4C
		public double RobotY { get; set; }

		// Token: 0x17000386 RID: 902
		// (get) Token: 0x06000A38 RID: 2616 RVA: 0x0002FD55 File Offset: 0x0002DF55
		// (set) Token: 0x06000A39 RID: 2617 RVA: 0x0002FD5D File Offset: 0x0002DF5D
		public double AngleRad { get; set; }

		// Token: 0x17000387 RID: 903
		// (get) Token: 0x06000A3A RID: 2618 RVA: 0x0002FD66 File Offset: 0x0002DF66
		// (set) Token: 0x06000A3B RID: 2619 RVA: 0x0002FD6E File Offset: 0x0002DF6E
		public double VisionAngleDeg { get; set; }

		// Token: 0x17000388 RID: 904
		// (get) Token: 0x06000A3C RID: 2620 RVA: 0x0002FD77 File Offset: 0x0002DF77
		// (set) Token: 0x06000A3D RID: 2621 RVA: 0x0002FD7F File Offset: 0x0002DF7F
		public double MappedVisionAngleDeg { get; set; }

		// Token: 0x17000389 RID: 905
		// (get) Token: 0x06000A3E RID: 2622 RVA: 0x0002FD88 File Offset: 0x0002DF88
		// (set) Token: 0x06000A3F RID: 2623 RVA: 0x0002FD90 File Offset: 0x0002DF90
		public double AngleOffsetDeg { get; set; }

		// Token: 0x1700038A RID: 906
		// (get) Token: 0x06000A40 RID: 2624 RVA: 0x0002FD99 File Offset: 0x0002DF99
		// (set) Token: 0x06000A41 RID: 2625 RVA: 0x0002FDA1 File Offset: 0x0002DFA1
		public double AngleDeg { get; set; }

		// Token: 0x1700038B RID: 907
		// (get) Token: 0x06000A42 RID: 2626 RVA: 0x0002FDAA File Offset: 0x0002DFAA
		// (set) Token: 0x06000A43 RID: 2627 RVA: 0x0002FDB2 File Offset: 0x0002DFB2
		public double Score { get; set; }

		// Token: 0x1700038C RID: 908
		// (get) Token: 0x06000A44 RID: 2628 RVA: 0x0002FDBB File Offset: 0x0002DFBB
		// (set) Token: 0x06000A45 RID: 2629 RVA: 0x0002FDC3 File Offset: 0x0002DFC3
		public bool UsedTcpOffset { get; set; }

		// Token: 0x1700038D RID: 909
		// (get) Token: 0x06000A46 RID: 2630 RVA: 0x0002FDCC File Offset: 0x0002DFCC
		// (set) Token: 0x06000A47 RID: 2631 RVA: 0x0002FDD4 File Offset: 0x0002DFD4
		public double TcpPixelRow { get; set; }

		// Token: 0x1700038E RID: 910
		// (get) Token: 0x06000A48 RID: 2632 RVA: 0x0002FDDD File Offset: 0x0002DFDD
		// (set) Token: 0x06000A49 RID: 2633 RVA: 0x0002FDE5 File Offset: 0x0002DFE5
		public double TcpPixelColumn { get; set; }

		// Token: 0x1700038F RID: 911
		// (get) Token: 0x06000A4A RID: 2634 RVA: 0x0002FDEE File Offset: 0x0002DFEE
		// (set) Token: 0x06000A4B RID: 2635 RVA: 0x0002FDF6 File Offset: 0x0002DFF6
		public bool HasDelta { get; set; }

		// Token: 0x17000390 RID: 912
		// (get) Token: 0x06000A4C RID: 2636 RVA: 0x0002FDFF File Offset: 0x0002DFFF
		// (set) Token: 0x06000A4D RID: 2637 RVA: 0x0002FE07 File Offset: 0x0002E007
		public double MasterRobotX { get; set; }

		// Token: 0x17000391 RID: 913
		// (get) Token: 0x06000A4E RID: 2638 RVA: 0x0002FE10 File Offset: 0x0002E010
		// (set) Token: 0x06000A4F RID: 2639 RVA: 0x0002FE18 File Offset: 0x0002E018
		public double MasterRobotY { get; set; }

		// Token: 0x17000392 RID: 914
		// (get) Token: 0x06000A50 RID: 2640 RVA: 0x0002FE21 File Offset: 0x0002E021
		// (set) Token: 0x06000A51 RID: 2641 RVA: 0x0002FE29 File Offset: 0x0002E029
		public double MasterTcpPixelRow { get; set; }

		// Token: 0x17000393 RID: 915
		// (get) Token: 0x06000A52 RID: 2642 RVA: 0x0002FE32 File Offset: 0x0002E032
		// (set) Token: 0x06000A53 RID: 2643 RVA: 0x0002FE3A File Offset: 0x0002E03A
		public double MasterTcpPixelColumn { get; set; }

		// Token: 0x17000394 RID: 916
		// (get) Token: 0x06000A54 RID: 2644 RVA: 0x0002FE43 File Offset: 0x0002E043
		// (set) Token: 0x06000A55 RID: 2645 RVA: 0x0002FE4B File Offset: 0x0002E04B
		public double DeltaRobotX { get; set; }

		// Token: 0x17000395 RID: 917
		// (get) Token: 0x06000A56 RID: 2646 RVA: 0x0002FE54 File Offset: 0x0002E054
		// (set) Token: 0x06000A57 RID: 2647 RVA: 0x0002FE5C File Offset: 0x0002E05C
		public double DeltaRobotY { get; set; }

		// Token: 0x17000396 RID: 918
		// (get) Token: 0x06000A58 RID: 2648 RVA: 0x0002FE65 File Offset: 0x0002E065
		// (set) Token: 0x06000A59 RID: 2649 RVA: 0x0002FE6D File Offset: 0x0002E06D
		public double DeltaAngleDeg { get; set; }

		// Token: 0x17000397 RID: 919
		// (get) Token: 0x06000A5A RID: 2650 RVA: 0x0002FE76 File Offset: 0x0002E076
		// (set) Token: 0x06000A5B RID: 2651 RVA: 0x0002FE7E File Offset: 0x0002E07E
		public double MasterAngleDeg { get; set; }

		// Token: 0x17000398 RID: 920
		// (get) Token: 0x06000A5C RID: 2652 RVA: 0x0002FE87 File Offset: 0x0002E087
		// (set) Token: 0x06000A5D RID: 2653 RVA: 0x0002FE8F File Offset: 0x0002E08F
		public bool UsedManualTcp { get; set; }

		// Token: 0x17000399 RID: 921
		// (get) Token: 0x06000A5E RID: 2654 RVA: 0x0002FE98 File Offset: 0x0002E098
		// (set) Token: 0x06000A5F RID: 2655 RVA: 0x0002FEA0 File Offset: 0x0002E0A0
		public bool KeepTargetInRange { get; set; }
	}
}
