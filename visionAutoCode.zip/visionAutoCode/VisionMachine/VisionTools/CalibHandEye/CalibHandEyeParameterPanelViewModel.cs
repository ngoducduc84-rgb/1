﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C3 RID: 195
	public class CalibHandEyeParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x17000353 RID: 851
		// (get) Token: 0x060009B8 RID: 2488 RVA: 0x0002D8A3 File Offset: 0x0002BAA3
		// (set) Token: 0x060009B9 RID: 2489 RVA: 0x0002D8AB File Offset: 0x0002BAAB
		public ToolVision Tool { get; set; }

		// Token: 0x17000354 RID: 852
		// (get) Token: 0x060009BA RID: 2490 RVA: 0x0002D8B4 File Offset: 0x0002BAB4
		// (set) Token: 0x060009BB RID: 2491 RVA: 0x0002D8BC File Offset: 0x0002BABC
		public CalibHandEyeToolConfig Config { get; set; }

		// Token: 0x17000355 RID: 853
		// (get) Token: 0x060009BC RID: 2492 RVA: 0x0002D8C5 File Offset: 0x0002BAC5
		// (set) Token: 0x060009BD RID: 2493 RVA: 0x0002D8CD File Offset: 0x0002BACD
		public ObservableCollection<CalibHandEyeMasterOption> AvailableMasterTools { get; set; }

		// Token: 0x17000356 RID: 854
		// (get) Token: 0x060009BE RID: 2494 RVA: 0x0002D8D8 File Offset: 0x0002BAD8
		// (set) Token: 0x060009BF RID: 2495 RVA: 0x0002D8F0 File Offset: 0x0002BAF0
		public CalibHandEyeMasterOption SelectedMasterTool
		{
			get
			{
				return this._selectedMasterTool;
			}
			set
			{
				bool flag = this._selectedMasterTool == value;
				if (!flag)
				{
					this._selectedMasterTool = value;
					bool flag2 = this.Config != null;
					if (flag2)
					{
						this.Config.MasterToolName = ((value == null) ? "None" : value.ToolName);
					}
					this.OnPropertyChanged("SelectedMasterTool");
				}
			}
		}

		// Token: 0x14000017 RID: 23
		// (add) Token: 0x060009C0 RID: 2496 RVA: 0x0002D94C File Offset: 0x0002BB4C
		// (remove) Token: 0x060009C1 RID: 2497 RVA: 0x0002D984 File Offset: 0x0002BB84
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060009C2 RID: 2498 RVA: 0x0002D9BC File Offset: 0x0002BBBC
		public void RestoreSelection()
		{
			bool flag = this.Config == null || this.AvailableMasterTools == null;
			if (!flag)
			{
				foreach (CalibHandEyeMasterOption item in this.AvailableMasterTools)
				{
					bool flag2 = item.ToolName == this.Config.MasterToolName;
					if (flag2)
					{
						this.SelectedMasterTool = item;
						return;
					}
				}
				this.Config.MasterToolName = "None";
				this.SelectedMasterTool = null;
			}
		}

		// Token: 0x060009C3 RID: 2499 RVA: 0x0002DA60 File Offset: 0x0002BC60
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x040003EA RID: 1002
		private CalibHandEyeMasterOption _selectedMasterTool;
	}
}
