﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.Services.Calibration;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AnisoShapeModel;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.OverlappingShapeModel;
using VisionMachine.VisionTools.ProcedureModel;
using VisionMachine.VisionTools.Runtime;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C5 RID: 197
	public class CalibHandEyeProcessor : IToolProcessor
	{
		// Token: 0x1700035B RID: 859
		// (get) Token: 0x060009CD RID: 2509 RVA: 0x0002DAC8 File Offset: 0x0002BCC8
		public ToolType ToolType
		{
			get
			{
				return ToolType.CalibHandEye;
			}
		}

		// Token: 0x060009CE RID: 2510 RVA: 0x0002DADC File Offset: 0x0002BCDC
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			CalibHandEyeResult result = this.TrialRun(context, tool);
			return new ToolProcessResult
			{
				IsSuccess = result.IsSuccess,
				Message = result.Message,
				Data = result
			};
		}

		// Token: 0x060009CF RID: 2511 RVA: 0x0002DB20 File Offset: 0x0002BD20
		public CalibHandEyeResult TrialRun(ToolProcessContext context, ToolVision tool)
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			CalibHandEyeResult result = new CalibHandEyeResult
			{
				ToolName = ((tool == null) ? null : tool.Name)
			};
			HObject masterInput = null;
			CalibHandEyeResult result2;
			try
			{
				CalibHandEyeToolConfig config = (tool == null) ? null : (tool.Config as CalibHandEyeToolConfig);
				bool flag = config == null;
				if (flag)
				{
					result2 = CalibHandEyeProcessor.Fail(result, "Calib Hand-Eye config is not available.");
				}
				else
				{
					result.MasterToolName = config.MasterToolName;
					result.CalibrationFilePath = config.CalibrationFilePath;
					bool flag2 = string.IsNullOrWhiteSpace(config.CalibrationFilePath) || !File.Exists(config.CalibrationFilePath);
					if (flag2)
					{
						result2 = CalibHandEyeProcessor.Fail(result, "Calibration file path is not valid.");
					}
					else
					{
						ToolVision masterTool = CalibHandEyeProcessor.FindMasterTool(tool, config.MasterToolName);
						bool flag3 = masterTool == null;
						if (flag3)
						{
							result2 = CalibHandEyeProcessor.Fail(result, "Selected master tool was not found before this tool.");
						}
						else
						{
							bool flag4 = context == null;
							if (flag4)
							{
								result2 = CalibHandEyeProcessor.Fail(result, "Process context is not available.");
							}
							else
							{
								ShapeMatchResult masterResult = null;
								double masterElapsedMs = 0.0;
								bool masterResultIsShared = false;
								object storedMasterResult;
								bool flag5 = context.ResultStore != null && context.ResultStore.TryGet(masterTool.Name, out storedMasterResult);
								if (flag5)
								{
									masterResult = (storedMasterResult as ShapeMatchResult);
									masterResultIsShared = (masterResult != null);
								}
								bool flag6 = masterResult == null;
								if (flag6)
								{
									bool flag7 = context.OriginalImage == null || !context.OriginalImage.IsInitialized();
									if (flag7)
									{
										return CalibHandEyeProcessor.Fail(result, "Original image is not available.");
									}
									ToolProcessContext masterInputContext = new ToolProcessContext
									{
										OriginalImage = context.OriginalImage,
										InputImage = context.OriginalImage,
										BufferStore = context.BufferStore
									};
									masterInput = this._pipelineService.BuildInputImageForTool(masterInputContext, masterTool);
									bool flag8 = masterInput == null || !masterInput.IsInitialized();
									if (flag8)
									{
										HOperatorSet.CopyImage(context.OriginalImage, out masterInput);
									}
									Stopwatch masterStopwatch = Stopwatch.StartNew();
									masterResult = CalibHandEyeProcessor.RunMaster(masterInput, masterTool);
									masterStopwatch.Stop();
									masterElapsedMs = masterStopwatch.Elapsed.TotalMilliseconds;
								}
								bool flag9 = masterResultIsShared && CalibHandEyeProcessor.NeedsMasterNormalization(masterResult, masterTool);
								if (flag9)
								{
									masterResult = CalibHandEyeProcessor.CloneMasterResult(masterResult);
								}
								masterResult = CalibHandEyeProcessor.NormalizeMasterResult(masterResult, masterTool);
								result.MasterProcessingTimeMs = ((masterResult == null || masterResult.ProcessingTimeMs <= 0.0) ? masterElapsedMs : masterResult.ProcessingTimeMs);
								bool flag10 = masterResult == null;
								if (flag10)
								{
									result2 = CalibHandEyeProcessor.Fail(result, "Master tool did not return a result.");
								}
								else
								{
									result.MasterTool = masterTool;
									result.MasterMatchResult = masterResult;
									bool masterHasMatches = masterResult.Matches != null && masterResult.Matches.Count > 0;
									bool useMulti = config.ObjectMode == CalibHandEyeObjectMode.MultiObject && masterHasMatches;
									result.ObjectMode = (useMulti ? CalibHandEyeObjectMode.MultiObject : config.ObjectMode);
									bool flag11 = !useMulti && !masterResult.IsSuccess;
									if (flag11)
									{
										result2 = CalibHandEyeProcessor.Fail(result, string.IsNullOrWhiteSpace(masterResult.Message) ? "Master tool did not detect an object." : masterResult.Message);
									}
									else
									{
										CalibHandEyeCalibrationCache.CalibData calib = CalibHandEyeCalibrationCache.GetCalibData(config.CalibrationFilePath);
										bool tcpAppliedToMapping = calib.TcpAppliedToMapping;
										if (tcpAppliedToMapping)
										{
											result2 = CalibHandEyeProcessor.Fail(result, "Calibration file '" + Path.GetFileName(config.CalibrationFilePath) + "' was exported with TcpAppliedToMapping=true (old export). Re-run Save Calib to export a pure image->robot matrix.");
										}
										else
										{
											HTuple homMat2d = calib.HomMat2d;
											double imageWidth;
											double imageHeight;
											CalibHandEyeProcessor.TryGetImageSize(masterInput, out imageWidth, out imageHeight);
											result.ValueMode = config.ValueMode;
											bool deltaMode = config.ValueMode == CalibHandEyeValueMode.DeltaFromMaster;
											double masterPixelRow;
											double masterPixelColumn;
											double masterAngleRad;
											bool haveMasterPose = CalibHandEyeProcessor.TryGetMasterDefinePose(masterTool, out masterPixelRow, out masterPixelColumn, out masterAngleRad);
											bool useTcp = false;
											string tcpSkipReason = null;
											bool applyTcpOffset = config.ApplyTcpOffset;
											if (applyTcpOffset)
											{
												bool flag12 = !calib.TcpValid;
												if (flag12)
												{
													tcpSkipReason = "the calibration file/.txt has no valid 3-angle TCP center (Save Calib with 3 rotation points)";
												}
												else
												{
													bool flag13 = !calib.HasTcpReference;
													if (flag13)
													{
														tcpSkipReason = "the calibration .txt has no reference pattern pose (needed to rotate the offset); Save Calib again";
													}
													else
													{
														bool flag14 = !calib.HasMappingVisionAngle;
														if (flag14)
														{
															tcpSkipReason = "the calibration file has no mapping vision angle (needed to zero the offset at the calibration orientation); Save Calib again with this build";
														}
														else
														{
															string tcpValidationMessage;
															bool flag15 = !CalibHandEyeProcessor.IsTcpCalibrationReasonable(calib, calib.ReferencePatternRow, calib.ReferencePatternCol, imageWidth, imageHeight, out tcpValidationMessage);
															if (flag15)
															{
																tcpSkipReason = "TCP calibration not reasonable: " + tcpValidationMessage;
															}
															else
															{
																bool flag16 = config.UseManualTcp && !haveMasterPose;
																if (flag16)
																{
																	tcpSkipReason = "Manual Robot TCP needs a defined master pattern pose (run Define Master on the master tool first)";
																}
																else
																{
																	bool flag17 = config.UseManualTcp && (double.IsNaN(config.ManualTcpRobotX) || double.IsInfinity(config.ManualTcpRobotX) || double.IsNaN(config.ManualTcpRobotY) || double.IsInfinity(config.ManualTcpRobotY) || double.IsNaN(config.ManualTcpRobotRz) || double.IsInfinity(config.ManualTcpRobotRz));
																	if (flag17)
																	{
																		tcpSkipReason = "Manual Robot TCP X/Y/Rz is not a finite number";
																	}
																	else
																	{
																		useTcp = true;
																	}
																}
															}
														}
													}
												}
												bool flag18 = !useTcp;
												if (flag18)
												{
													CalibHandEyeProcessor.LogTcp("TCP requested but skipped (" + tcpSkipReason + "); using 9-point mapping.");
												}
											}
											result.UsedTcpOffset = useTcp;
											CalibHandEyeProcessor.LogTcp(string.Concat(new string[]
											{
												"Run '",
												(tool == null) ? "?" : tool.Name,
												"': ApplyTcpOffset=",
												config.ApplyTcpOffset.ToString(),
												", calibVersion=",
												calib.FormatVersion.ToString(),
												", TcpValid=",
												calib.TcpValid.ToString(),
												", tcpCenterPx(col,row)=(",
												calib.TcpCenterCol.ToString("0.0"),
												",",
												calib.TcpCenterRow.ToString("0.0"),
												"), tcpRadiusPx=",
												calib.TcpRadiusPx.ToString("0.0"),
												", image(w,h)=(",
												imageWidth.ToString("0"),
												",",
												imageHeight.ToString("0"),
												"), tcpAppliedToMapping=",
												calib.TcpAppliedToMapping.ToString(),
												", tcpRef(col,row,deg)=(",
												calib.ReferencePatternCol.ToString("0.0"),
												",",
												calib.ReferencePatternRow.ToString("0.0"),
												",",
												calib.ReferenceVisionAngleDeg.ToString("0.00"),
												"), haveMaster=",
												haveMasterPose.ToString(),
												", master(row,col,deg)=(",
												masterPixelRow.ToString("0.0"),
												",",
												masterPixelColumn.ToString("0.0"),
												",",
												(masterAngleRad * 180.0 / 3.141592653589793).ToString("0.00"),
												") -> useTcp=",
												useTcp.ToString(),
												", calib=",
												Path.GetFileName(config.CalibrationFilePath ?? "")
											}));
											CalibHandEyeProcessor.ManualTcpTransform manualTcp = null;
											bool flag19 = useTcp && config.UseManualTcp;
											if (flag19)
											{
												manualTcp = CalibHandEyeProcessor.ComputeManualTcpTransform(config, calib, homMat2d, masterPixelRow, masterPixelColumn, masterAngleRad);
												CalibHandEyeProcessor.LogTcp(string.Concat(new string[]
												{
													"Manual TCP: robot=(",
													config.ManualTcpRobotX.ToString("0.###"),
													",",
													config.ManualTcpRobotY.ToString("0.###"),
													") -> image offset from master (col,row)=(",
													manualTcp.OffsetCol.ToString("0.0"),
													",",
													manualTcp.OffsetRow.ToString("0.0"),
													"), |offset|=",
													Math.Sqrt(manualTcp.OffsetCol * manualTcp.OffsetCol + manualTcp.OffsetRow * manualTcp.OffsetRow).ToString("0.0"),
													" px"
												}));
											}
											double masterRobotX = 0.0;
											double masterRobotY = 0.0;
											double masterAngleDeg = 0.0;
											double masterTcpPixelRow = 0.0;
											double masterTcpPixelColumn = 0.0;
											bool flag20 = deltaMode;
											if (flag20)
											{
												bool flag21 = !haveMasterPose;
												if (flag21)
												{
													return CalibHandEyeProcessor.Fail(result, "Delta mode requires a defined master in the master tool. Please run Define Master first.");
												}
												double masterMapRow = masterPixelRow;
												double masterMapCol = masterPixelColumn;
												bool flag22 = useTcp;
												if (flag22)
												{
													CalibHandEyeProcessor.TransformPatternToTcpImage(masterPixelRow, masterPixelColumn, masterAngleRad, calib, manualTcp, out masterMapRow, out masterMapCol);
												}
												masterTcpPixelRow = masterMapRow;
												masterTcpPixelColumn = masterMapCol;
												HTuple masterX;
												HTuple masterY;
												HOperatorSet.AffineTransPoint2d(homMat2d, masterMapCol, masterMapRow, out masterX, out masterY);
												masterRobotX = masterX.D;
												masterRobotY = masterY.D;
												masterAngleDeg = ((manualTcp != null) ? CalibHandEyeProcessor.NormalizeSignedDegrees(manualTcp.RobotRz) : CalibHandEyeProcessor.ToRobotAngleDeg(masterAngleRad, homMat2d, calib.AngleOffsetDeg));
												result.HasDelta = true;
												result.MasterRobotX = masterRobotX;
												result.MasterRobotY = masterRobotY;
												result.MasterTcpPixelRow = masterTcpPixelRow;
												result.MasterTcpPixelColumn = masterTcpPixelColumn;
											}
											bool flag23 = useMulti;
											if (flag23)
											{
												foreach (ShapeMatchCandidate match in masterResult.Matches)
												{
													bool picked = match.GridRow == masterResult.GridRow && match.GridColumn == masterResult.GridColumn;
													int outputIndex = (match.Order > 0) ? match.Order : match.Index;
													result.Objects.Add(CalibHandEyeProcessor.MapObject(homMat2d, outputIndex, match.GridRow, match.GridColumn, match.Row, match.Column, match.Angle, match.Score, picked, useTcp, calib, calib.AngleOffsetDeg, manualTcp));
												}
											}
											else
											{
												result.Objects.Add(CalibHandEyeProcessor.MapObject(homMat2d, 0, masterResult.GridRow, masterResult.GridColumn, masterResult.Row, masterResult.Column, masterResult.Angle, masterResult.Score, true, useTcp, calib, calib.AngleOffsetDeg, manualTcp));
											}
											bool flag24 = deltaMode;
											if (flag24)
											{
												foreach (CalibHandEyeObjectResult obj in result.Objects)
												{
													obj.HasDelta = true;
													obj.MasterRobotX = masterRobotX;
													obj.MasterRobotY = masterRobotY;
													obj.MasterTcpPixelRow = masterTcpPixelRow;
													obj.MasterTcpPixelColumn = masterTcpPixelColumn;
													obj.DeltaRobotX = obj.RobotX - masterRobotX;
													obj.DeltaRobotY = obj.RobotY - masterRobotY;
													bool keepTargetInRange = manualTcp != null && config.AngleDeltaMode == CalibHandEyeAngleDeltaMode.TargetInRange;
													obj.DeltaAngleDeg = (keepTargetInRange ? (obj.AngleDeg - masterAngleDeg) : CalibHandEyeProcessor.NormalizeSignedDegrees(obj.AngleDeg - masterAngleDeg));
													obj.MasterAngleDeg = masterAngleDeg;
													obj.UsedManualTcp = (manualTcp != null);
													obj.KeepTargetInRange = keepTargetInRange;
												}
											}
											CalibHandEyeObjectResult primary = result.Objects.FirstOrDefault((CalibHandEyeObjectResult x) => x.Picked) ?? result.Objects.First<CalibHandEyeObjectResult>();
											result.PixelRow = primary.PixelRow;
											result.PixelColumn = primary.PixelColumn;
											result.AngleRad = primary.AngleRad;
											result.VisionAngleDeg = primary.VisionAngleDeg;
											result.MappedVisionAngleDeg = primary.MappedVisionAngleDeg;
											result.AngleOffsetDeg = primary.AngleOffsetDeg;
											result.AngleDeg = primary.AngleDeg;
											result.Score = primary.Score;
											result.RobotX = primary.RobotX;
											result.RobotY = primary.RobotY;
											result.TcpPixelRow = primary.TcpPixelRow;
											result.TcpPixelColumn = primary.TcpPixelColumn;
											CalibHandEyeProcessor.LogTcp(string.Concat(new string[]
											{
												"  primary: visionAngleDeg=",
												primary.VisionAngleDeg.ToString("0.00"),
												", mappedVisionAngleDeg=",
												primary.MappedVisionAngleDeg.ToString("0.00"),
												", angleOffsetDeg=",
												primary.AngleOffsetDeg.ToString("0.00"),
												", robotAngleDeg=",
												primary.AngleDeg.ToString("0.00"),
												", patternPx(col,row)=(",
												primary.PixelColumn.ToString("0.0"),
												",",
												primary.PixelRow.ToString("0.0"),
												"), tcpPx(col,row)=(",
												primary.TcpPixelColumn.ToString("0.0"),
												",",
												primary.TcpPixelRow.ToString("0.0"),
												"), robot=(",
												primary.RobotX.ToString("0.000"),
												",",
												primary.RobotY.ToString("0.000"),
												")",
												deltaMode ? string.Concat(new string[]
												{
													", masterTcpPx(col,row)=(",
													primary.MasterTcpPixelColumn.ToString("0.0"),
													",",
													primary.MasterTcpPixelRow.ToString("0.0"),
													"), masterRobot=(",
													primary.MasterRobotX.ToString("0.000"),
													",",
													primary.MasterRobotY.ToString("0.000"),
													"), delta=(",
													primary.DeltaRobotX.ToString("0.000"),
													",",
													primary.DeltaRobotY.ToString("0.000"),
													"), deltaAngle=",
													primary.DeltaAngleDeg.ToString("0.00")
												}) : ""
											}));
											bool flag25 = deltaMode;
											if (flag25)
											{
												result.DeltaRobotX = primary.DeltaRobotX;
												result.DeltaRobotY = primary.DeltaRobotY;
												result.DeltaAngleDeg = primary.DeltaAngleDeg;
											}
											result.IsSuccess = true;
											string tcpInfo = useTcp ? string.Concat(new string[]
											{
												" [TCP applied, center px=(",
												calib.TcpCenterCol.ToString("0.0"),
												", ",
												calib.TcpCenterRow.ToString("0.0"),
												")]"
											}) : (config.ApplyTcpOffset ? (" [TCP NOT applied: " + (tcpSkipReason ?? "unavailable") + "]") : " [TCP off]");
											bool flag26 = deltaMode;
											if (flag26)
											{
												result.Message = string.Concat(new string[]
												{
													"Calib Hand-Eye OK (delta). Objects=",
													result.Objects.Count.ToString(),
													", PickedDeltaX=",
													result.DeltaRobotX.ToString("0.000"),
													", PickedDeltaY=",
													result.DeltaRobotY.ToString("0.000"),
													", DeltaAngle=",
													result.DeltaAngleDeg.ToString("0.000"),
													tcpInfo
												});
											}
											else
											{
												result.Message = (useMulti ? string.Concat(new string[]
												{
													"Calib Hand-Eye OK. Objects=",
													result.Objects.Count.ToString(),
													", PickedRobotX=",
													result.RobotX.ToString("0.000"),
													", PickedRobotY=",
													result.RobotY.ToString("0.000")
												}) : ("Calib Hand-Eye OK. RobotX=" + result.RobotX.ToString("0.000") + ", RobotY=" + result.RobotY.ToString("0.000"))) + tcpInfo;
											}
											result2 = result;
										}
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				result2 = CalibHandEyeProcessor.Fail(result, "Calib Hand-Eye failed: " + ex.Message);
			}
			finally
			{
				stopwatch.Stop();
				result.ProcessingTimeMs = Math.Max(0.0, stopwatch.Elapsed.TotalMilliseconds - result.MasterProcessingTimeMs);
				result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				bool flag27 = masterInput != null;
				if (flag27)
				{
					masterInput.Dispose();
				}
			}
			return result2;
		}

		// Token: 0x060009D0 RID: 2512 RVA: 0x0002ECC8 File Offset: 0x0002CEC8
		private static void LogTcp(string line)
		{
			try
			{
				string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VisionMachine");
				Directory.CreateDirectory(folder);
				File.AppendAllText(Path.Combine(folder, "calib_tcp_log.txt"), string.Concat(new string[]
				{
					"[",
					DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
					"] ",
					line,
					Environment.NewLine
				}));
			}
			catch
			{
			}
		}

		// Token: 0x060009D1 RID: 2513 RVA: 0x0002ED58 File Offset: 0x0002CF58
		private static double NormalizeSignedDegrees(double degrees)
		{
			degrees %= 360.0;
			bool flag = degrees > 180.0;
			if (flag)
			{
				degrees -= 360.0;
			}
			else
			{
				bool flag2 = degrees <= -180.0;
				if (flag2)
				{
					degrees += 360.0;
				}
			}
			return degrees;
		}

		// Token: 0x060009D2 RID: 2514 RVA: 0x0002EDB8 File Offset: 0x0002CFB8
		private static CalibHandEyeObjectResult MapObject(HTuple homMat2d, int index, int gridRow, int gridColumn, double pixelRow, double pixelColumn, double angleRad, double score, bool picked, bool useTcp = false, CalibHandEyeCalibrationCache.CalibData calib = null, double angleOffsetDeg = 0.0, CalibHandEyeProcessor.ManualTcpTransform manualTcp = null)
		{
			double mapRow = pixelRow;
			double mapColumn = pixelColumn;
			if (useTcp)
			{
				CalibHandEyeProcessor.TransformPatternToTcpImage(pixelRow, pixelColumn, angleRad, calib, manualTcp, out mapRow, out mapColumn);
			}
			HTuple robotX;
			HTuple robotY;
			HOperatorSet.AffineTransPoint2d(homMat2d, mapColumn, mapRow, out robotX, out robotY);
			double visionAngleDeg = angleRad * 180.0 / 3.141592653589793;
			double mappedVisionAngleDeg = HandEyeCalibrationSolver.MapImageAngleToRobotAngleDeg(visionAngleDeg, homMat2d);
			double angleDeg = (manualTcp != null) ? CalibHandEyeProcessor.NormalizeSignedDegrees(manualTcp.RobotRz + CalibHandEyeProcessor.NormalizeSignedDegrees(mappedVisionAngleDeg - manualTcp.MasterMappedAngleDeg)) : CalibHandEyeProcessor.NormalizeSignedDegrees(mappedVisionAngleDeg + angleOffsetDeg);
			return new CalibHandEyeObjectResult
			{
				Index = index,
				GridRow = gridRow,
				GridColumn = gridColumn,
				Picked = picked,
				PixelRow = pixelRow,
				PixelColumn = pixelColumn,
				AngleRad = angleRad,
				VisionAngleDeg = visionAngleDeg,
				MappedVisionAngleDeg = mappedVisionAngleDeg,
				AngleOffsetDeg = angleOffsetDeg,
				AngleDeg = angleDeg,
				Score = score,
				UsedTcpOffset = useTcp,
				TcpPixelRow = mapRow,
				TcpPixelColumn = mapColumn,
				RobotX = robotX.D,
				RobotY = robotY.D
			};
		}

		// Token: 0x060009D3 RID: 2515 RVA: 0x0002EEF8 File Offset: 0x0002D0F8
		private static double ToRobotAngleDeg(double visionAngleRad, HTuple homMat2d, double angleOffsetDeg)
		{
			double mappedAngleDeg = HandEyeCalibrationSolver.MapImageAngleToRobotAngleDeg(visionAngleRad * 180.0 / 3.141592653589793, homMat2d);
			return CalibHandEyeProcessor.NormalizeSignedDegrees(mappedAngleDeg + angleOffsetDeg);
		}

		// Token: 0x060009D4 RID: 2516 RVA: 0x0002EF30 File Offset: 0x0002D130
		private static void TransformPatternToTcpImage(double patternRow, double patternColumn, double patternAngleRad, CalibHandEyeCalibrationCache.CalibData calib, CalibHandEyeProcessor.ManualTcpTransform manualTcp, out double tcpRow, out double tcpColumn)
		{
			tcpRow = patternRow;
			tcpColumn = patternColumn;
			bool flag = calib == null;
			if (!flag)
			{
				bool flag2 = manualTcp != null;
				double tcpImageX;
				double tcpImageY;
				if (flag2)
				{
					double delta = -(patternAngleRad - manualTcp.MasterAngleRad);
					double cos = Math.Cos(delta);
					double sin = Math.Sin(delta);
					tcpImageX = patternColumn + cos * manualTcp.OffsetCol - sin * manualTcp.OffsetRow;
					tcpImageY = patternRow + sin * manualTcp.OffsetCol + cos * manualTcp.OffsetRow;
				}
				else
				{
					TcpCalibrationSolver.TransformPatternToTcpImage(patternColumn, patternRow, patternAngleRad * 180.0 / 3.141592653589793, calib.ReferencePatternCol, calib.ReferencePatternRow, calib.ReferenceVisionAngleDeg, calib.TcpCenterCol, calib.TcpCenterRow, out tcpImageX, out tcpImageY);
				}
				double calOffsetCol;
				double calOffsetRow;
				CalibHandEyeProcessor.ComputeCalOrientationOffset(calib, out calOffsetCol, out calOffsetRow);
				tcpColumn = tcpImageX - calOffsetCol;
				tcpRow = tcpImageY - calOffsetRow;
			}
		}

		// Token: 0x060009D5 RID: 2517 RVA: 0x0002F00C File Offset: 0x0002D20C
		private static void ComputeCalOrientationOffset(CalibHandEyeCalibrationCache.CalibData calib, out double calOffsetCol, out double calOffsetRow)
		{
			double calDeltaRad = -(calib.MappingVisionAngleDeg - calib.ReferenceVisionAngleDeg) * 3.141592653589793 / 180.0;
			double offsetCol = calib.TcpCenterCol - calib.ReferencePatternCol;
			double offsetRow = calib.TcpCenterRow - calib.ReferencePatternRow;
			calOffsetCol = Math.Cos(calDeltaRad) * offsetCol - Math.Sin(calDeltaRad) * offsetRow;
			calOffsetRow = Math.Sin(calDeltaRad) * offsetCol + Math.Cos(calDeltaRad) * offsetRow;
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x0002F080 File Offset: 0x0002D280
		private static CalibHandEyeProcessor.ManualTcpTransform ComputeManualTcpTransform(CalibHandEyeToolConfig config, CalibHandEyeCalibrationCache.CalibData calib, HTuple homMat2d, double masterPixelRow, double masterPixelColumn, double masterAngleRad)
		{
			double calOffsetCol;
			double calOffsetRow;
			CalibHandEyeProcessor.ComputeCalOrientationOffset(calib, out calOffsetCol, out calOffsetRow);
			HTuple invHom;
			HOperatorSet.HomMat2dInvert(homMat2d, out invHom);
			HTuple tcpImageCol;
			HTuple tcpImageRow;
			HOperatorSet.AffineTransPoint2d(invHom, config.ManualTcpRobotX, config.ManualTcpRobotY, out tcpImageCol, out tcpImageRow);
			return new CalibHandEyeProcessor.ManualTcpTransform
			{
				MasterAngleRad = masterAngleRad,
				OffsetCol = tcpImageCol.D + calOffsetCol - masterPixelColumn,
				OffsetRow = tcpImageRow.D + calOffsetRow - masterPixelRow,
				RobotRz = config.ManualTcpRobotRz,
				MasterMappedAngleDeg = HandEyeCalibrationSolver.MapImageAngleToRobotAngleDeg(masterAngleRad * 180.0 / 3.141592653589793, homMat2d)
			};
		}

		// Token: 0x060009D7 RID: 2519 RVA: 0x0002F128 File Offset: 0x0002D328
		private static bool TryGetImageSize(HObject image, out double width, out double height)
		{
			width = 0.0;
			height = 0.0;
			bool result;
			try
			{
				bool flag = image == null || !image.IsInitialized();
				if (flag)
				{
					result = false;
				}
				else
				{
					HTuple w;
					HTuple h;
					HOperatorSet.GetImageSize(image, out w, out h);
					width = w.D;
					height = h.D;
					result = (width > 0.0 && height > 0.0);
				}
			}
			catch
			{
				width = 0.0;
				height = 0.0;
				result = false;
			}
			return result;
		}

		// Token: 0x060009D8 RID: 2520 RVA: 0x0002F1CC File Offset: 0x0002D3CC
		private static bool IsTcpCalibrationReasonable(CalibHandEyeCalibrationCache.CalibData calib, double masterRow, double masterColumn, double imageWidth, double imageHeight, out string message)
		{
			message = null;
			bool flag = calib == null || !calib.TcpValid;
			bool result;
			if (flag)
			{
				message = "the calibration file has no valid TCP center";
				result = false;
			}
			else
			{
				bool flag2 = !CalibHandEyeProcessor.IsFinite(calib.TcpCenterRow) || !CalibHandEyeProcessor.IsFinite(calib.TcpCenterCol) || !CalibHandEyeProcessor.IsFinite(calib.TcpRadiusPx);
				if (flag2)
				{
					message = "TCP center/radius is not finite";
					result = false;
				}
				else
				{
					bool flag3 = calib.TcpRadiusPx < 5.0;
					if (flag3)
					{
						message = "TCP rotation radius is too small (" + calib.TcpRadiusPx.ToString("0.###") + " px)";
						result = false;
					}
					else
					{
						bool flag4 = imageWidth > 0.0 && imageHeight > 0.0;
						if (flag4)
						{
							double diagonal = Math.Sqrt(imageWidth * imageWidth + imageHeight * imageHeight);
							double offsetRow = calib.TcpCenterRow - masterRow;
							double offsetColumn = calib.TcpCenterCol - masterColumn;
							double offsetDistance = Math.Sqrt(offsetRow * offsetRow + offsetColumn * offsetColumn);
							bool flag5 = offsetDistance > diagonal * 2.0;
							if (flag5)
							{
								message = string.Concat(new string[]
								{
									"TCP center is too far from master pose. Center(col,row)=(",
									calib.TcpCenterCol.ToString("0.###"),
									", ",
									calib.TcpCenterRow.ToString("0.###"),
									"), Master(col,row)=(",
									masterColumn.ToString("0.###"),
									", ",
									masterRow.ToString("0.###"),
									"), Distance=",
									offsetDistance.ToString("0.###"),
									" px, ImageDiagonal=",
									diagonal.ToString("0.###"),
									" px"
								});
								return false;
							}
							double maxAbsCol = Math.Max(imageWidth * 3.0, diagonal * 2.0);
							double maxAbsRow = Math.Max(imageHeight * 3.0, diagonal * 2.0);
							bool flag6 = Math.Abs(calib.TcpCenterCol) > maxAbsCol || Math.Abs(calib.TcpCenterRow) > maxAbsRow;
							if (flag6)
							{
								message = string.Concat(new string[]
								{
									"TCP center is outside the expected image range. Center(col,row)=(",
									calib.TcpCenterCol.ToString("0.###"),
									", ",
									calib.TcpCenterRow.ToString("0.###"),
									"), Image(w,h)=(",
									imageWidth.ToString("0"),
									", ",
									imageHeight.ToString("0"),
									")"
								});
								return false;
							}
						}
						result = true;
					}
				}
			}
			return result;
		}

		// Token: 0x060009D9 RID: 2521 RVA: 0x0002F4AC File Offset: 0x0002D6AC
		private static bool IsFinite(double value)
		{
			return !double.IsNaN(value) && !double.IsInfinity(value);
		}

		// Token: 0x060009DA RID: 2522 RVA: 0x0002F4D4 File Offset: 0x0002D6D4
		private static bool TryGetMasterDefinePose(ToolVision masterTool, out double pixelRow, out double pixelColumn, out double angleRad)
		{
			pixelRow = 0.0;
			pixelColumn = 0.0;
			angleRad = 0.0;
			ShapeModelToolTrain train = (masterTool == null) ? null : (masterTool.TrainModel as ShapeModelToolTrain);
			bool flag = train == null || !train.HasMasterDefined;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				pixelRow = train.MasterRow;
				pixelColumn = train.MasterColumn;
				angleRad = train.MasterAngle;
				result = true;
			}
			return result;
		}

		// Token: 0x060009DB RID: 2523 RVA: 0x0002F54C File Offset: 0x0002D74C
		private static CalibHandEyeResult Fail(CalibHandEyeResult result, string message)
		{
			result.IsSuccess = false;
			result.Message = message;
			return result;
		}

		// Token: 0x060009DC RID: 2524 RVA: 0x0002F570 File Offset: 0x0002D770
		private static ToolVision FindMasterTool(ToolVision currentTool, string masterToolName)
		{
			bool flag = currentTool == null || currentTool.ParentTurnSnap == null || string.IsNullOrWhiteSpace(masterToolName) || string.Equals(masterToolName, "None", StringComparison.OrdinalIgnoreCase);
			ToolVision result;
			if (flag)
			{
				result = null;
			}
			else
			{
				foreach (ToolVision tool in currentTool.ParentTurnSnap.Tools)
				{
					bool flag2 = tool == currentTool;
					if (flag2)
					{
						break;
					}
					bool flag3 = string.Equals(tool.Name, masterToolName, StringComparison.OrdinalIgnoreCase) && CalibHandEyeProcessor.IsSupportedMasterTool(tool);
					if (flag3)
					{
						return tool;
					}
				}
				result = null;
			}
			return result;
		}

		// Token: 0x060009DD RID: 2525 RVA: 0x0002F620 File Offset: 0x0002D820
		private static bool IsSupportedMasterTool(ToolVision tool)
		{
			return tool != null && (tool.ToolType == ToolType.Shape_model || tool.ToolType == ToolType.AnisoShapeModel || tool.ToolType == ToolType.OverlappingShapeModel || tool.ToolType == ToolType.BoundingBoxMaster || tool.ToolType == ToolType.MinAreaMaster || tool.ToolType == ToolType.CircleMaster || tool.ToolType == ToolType.ProcedureModel);
		}

		// Token: 0x060009DE RID: 2526 RVA: 0x0002F680 File Offset: 0x0002D880
		private static ShapeMatchResult RunMaster(HObject image, ToolVision masterTool)
		{
			bool flag = masterTool.ToolType == ToolType.Shape_model;
			ShapeMatchResult result;
			if (flag)
			{
				result = new ShapeModelProcessor().TrialRun(image, masterTool);
			}
			else
			{
				bool flag2 = masterTool.ToolType == ToolType.AnisoShapeModel;
				if (flag2)
				{
					result = new AnisoShapeModelProcessor().TrialRun(image, masterTool);
				}
				else
				{
					bool flag3 = masterTool.ToolType == ToolType.OverlappingShapeModel;
					if (flag3)
					{
						result = new OverlappingShapeModelProcessor().TrialRun(image, masterTool);
					}
					else
					{
						bool flag4 = masterTool.ToolType == ToolType.BoundingBoxMaster;
						if (flag4)
						{
							result = new BoundingBoxMasterProcessor().TrialRun(image, masterTool);
						}
						else
						{
							bool flag5 = masterTool.ToolType == ToolType.MinAreaMaster;
							if (flag5)
							{
								result = new MinAreaMasterProcessor().TrialRun(image, masterTool);
							}
							else
							{
								bool flag6 = masterTool.ToolType == ToolType.CircleMaster;
								if (flag6)
								{
									result = new CircleMasterProcessor().TrialRun(image, masterTool);
								}
								else
								{
									bool flag7 = masterTool.ToolType == ToolType.ProcedureModel;
									if (flag7)
									{
										using (ProcedureModelProcessor processor = new ProcedureModelProcessor())
										{
											return processor.TrialRun(image, masterTool);
										}
									}
									result = null;
								}
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x060009DF RID: 2527 RVA: 0x0002F794 File Offset: 0x0002D994
		private static bool NeedsMasterNormalization(ShapeMatchResult result, ToolVision masterTool)
		{
			return result != null && !result.IsSuccess && masterTool != null && masterTool.ToolType == ToolType.AnisoShapeModel && result.Matches != null && result.Matches.Count > 0;
		}

		// Token: 0x060009E0 RID: 2528 RVA: 0x0002F7D8 File Offset: 0x0002D9D8
		private static ShapeMatchResult CloneMasterResult(ShapeMatchResult source)
		{
			bool flag = source == null;
			ShapeMatchResult result;
			if (flag)
			{
				result = null;
			}
			else
			{
				ShapeMatchResult clone = new ShapeMatchResult
				{
					IsSuccess = source.IsSuccess,
					GridRow = source.GridRow,
					GridColumn = source.GridColumn,
					Row = source.Row,
					Column = source.Column,
					Angle = source.Angle,
					Score = source.Score,
					ScaleRow = source.ScaleRow,
					ScaleColumn = source.ScaleColumn,
					DeltaRow = source.DeltaRow,
					DeltaColumn = source.DeltaColumn,
					DeltaAngle = source.DeltaAngle,
					ProcessingTimeMs = source.ProcessingTimeMs,
					InputSourceToolName = source.InputSourceToolName,
					InputProcessingTimeMs = source.InputProcessingTimeMs,
					RoiName = source.RoiName,
					Message = source.Message
				};
				bool flag2 = source.Matches != null;
				if (flag2)
				{
					clone.Matches.AddRange(source.Matches);
				}
				result = clone;
			}
			return result;
		}

		// Token: 0x060009E1 RID: 2529 RVA: 0x0002F8FC File Offset: 0x0002DAFC
		private static ShapeMatchResult NormalizeMasterResult(ShapeMatchResult result, ToolVision masterTool)
		{
			bool flag = result == null || result.IsSuccess || masterTool == null || masterTool.ToolType != ToolType.AnisoShapeModel || result.Matches == null || result.Matches.Count == 0;
			ShapeMatchResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeMatchCandidate selected = (from x in result.Matches
				orderby x.Score descending, x.Index
				select x).FirstOrDefault<ShapeMatchCandidate>();
				bool flag2 = selected == null;
				if (flag2)
				{
					result2 = result;
				}
				else
				{
					result.IsSuccess = true;
					result.GridRow = selected.GridRow;
					result.GridColumn = selected.GridColumn;
					result.Row = selected.Row;
					result.Column = selected.Column;
					result.Angle = selected.Angle;
					result.ScaleRow = selected.ScaleRow;
					result.ScaleColumn = selected.ScaleColumn;
					result.Score = selected.Score;
					result.DeltaRow = selected.DeltaRow;
					result.DeltaColumn = selected.DeltaColumn;
					result.DeltaAngle = selected.DeltaAngle;
					result.Message = "Aniso Shape Model detected objects. Calibration used highest-score object because Pick Row/Column did not select a match.";
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x060009E2 RID: 2530 RVA: 0x0002FA54 File Offset: 0x0002DC54
		private static HTuple LoadHomMat2d(string path)
		{
			return CalibHandEyeCalibrationCache.GetHomMat2d(path);
		}

		// Token: 0x040003F2 RID: 1010
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();

		// Token: 0x0200032D RID: 813
		private sealed class ManualTcpTransform
		{
			// Token: 0x0400117A RID: 4474
			public double MasterAngleRad;

			// Token: 0x0400117B RID: 4475
			public double OffsetRow;

			// Token: 0x0400117C RID: 4476
			public double OffsetCol;

			// Token: 0x0400117D RID: 4477
			public double RobotRz;

			// Token: 0x0400117E RID: 4478
			public double MasterMappedAngleDeg;
		}
	}
}
