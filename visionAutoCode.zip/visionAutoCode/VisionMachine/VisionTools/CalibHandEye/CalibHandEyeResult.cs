﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C6 RID: 198
	public class CalibHandEyeResult
	{
		// Token: 0x1700035C RID: 860
		// (get) Token: 0x060009E4 RID: 2532 RVA: 0x0002FA80 File Offset: 0x0002DC80
		// (set) Token: 0x060009E5 RID: 2533 RVA: 0x0002FA88 File Offset: 0x0002DC88
		public bool IsSuccess { get; set; }

		// Token: 0x1700035D RID: 861
		// (get) Token: 0x060009E6 RID: 2534 RVA: 0x0002FA91 File Offset: 0x0002DC91
		// (set) Token: 0x060009E7 RID: 2535 RVA: 0x0002FA99 File Offset: 0x0002DC99
		public string ToolName { get; set; }

		// Token: 0x1700035E RID: 862
		// (get) Token: 0x060009E8 RID: 2536 RVA: 0x0002FAA2 File Offset: 0x0002DCA2
		// (set) Token: 0x060009E9 RID: 2537 RVA: 0x0002FAAA File Offset: 0x0002DCAA
		public string MasterToolName { get; set; }

		// Token: 0x1700035F RID: 863
		// (get) Token: 0x060009EA RID: 2538 RVA: 0x0002FAB3 File Offset: 0x0002DCB3
		// (set) Token: 0x060009EB RID: 2539 RVA: 0x0002FABB File Offset: 0x0002DCBB
		[JsonIgnore]
		public ToolVision MasterTool { get; set; }

		// Token: 0x17000360 RID: 864
		// (get) Token: 0x060009EC RID: 2540 RVA: 0x0002FAC4 File Offset: 0x0002DCC4
		// (set) Token: 0x060009ED RID: 2541 RVA: 0x0002FACC File Offset: 0x0002DCCC
		[JsonIgnore]
		public ShapeMatchResult MasterMatchResult { get; set; }

		// Token: 0x17000361 RID: 865
		// (get) Token: 0x060009EE RID: 2542 RVA: 0x0002FAD5 File Offset: 0x0002DCD5
		// (set) Token: 0x060009EF RID: 2543 RVA: 0x0002FADD File Offset: 0x0002DCDD
		public CalibHandEyeObjectMode ObjectMode { get; set; }

		// Token: 0x17000362 RID: 866
		// (get) Token: 0x060009F0 RID: 2544 RVA: 0x0002FAE6 File Offset: 0x0002DCE6
		// (set) Token: 0x060009F1 RID: 2545 RVA: 0x0002FAEE File Offset: 0x0002DCEE
		public CalibHandEyeValueMode ValueMode { get; set; }

		// Token: 0x17000363 RID: 867
		// (get) Token: 0x060009F2 RID: 2546 RVA: 0x0002FAF7 File Offset: 0x0002DCF7
		// (set) Token: 0x060009F3 RID: 2547 RVA: 0x0002FAFF File Offset: 0x0002DCFF
		public bool HasDelta { get; set; }

		// Token: 0x17000364 RID: 868
		// (get) Token: 0x060009F4 RID: 2548 RVA: 0x0002FB08 File Offset: 0x0002DD08
		// (set) Token: 0x060009F5 RID: 2549 RVA: 0x0002FB10 File Offset: 0x0002DD10
		public double MasterRobotX { get; set; }

		// Token: 0x17000365 RID: 869
		// (get) Token: 0x060009F6 RID: 2550 RVA: 0x0002FB19 File Offset: 0x0002DD19
		// (set) Token: 0x060009F7 RID: 2551 RVA: 0x0002FB21 File Offset: 0x0002DD21
		public double MasterRobotY { get; set; }

		// Token: 0x17000366 RID: 870
		// (get) Token: 0x060009F8 RID: 2552 RVA: 0x0002FB2A File Offset: 0x0002DD2A
		// (set) Token: 0x060009F9 RID: 2553 RVA: 0x0002FB32 File Offset: 0x0002DD32
		public double MasterTcpPixelRow { get; set; }

		// Token: 0x17000367 RID: 871
		// (get) Token: 0x060009FA RID: 2554 RVA: 0x0002FB3B File Offset: 0x0002DD3B
		// (set) Token: 0x060009FB RID: 2555 RVA: 0x0002FB43 File Offset: 0x0002DD43
		public double MasterTcpPixelColumn { get; set; }

		// Token: 0x17000368 RID: 872
		// (get) Token: 0x060009FC RID: 2556 RVA: 0x0002FB4C File Offset: 0x0002DD4C
		// (set) Token: 0x060009FD RID: 2557 RVA: 0x0002FB54 File Offset: 0x0002DD54
		public double DeltaRobotX { get; set; }

		// Token: 0x17000369 RID: 873
		// (get) Token: 0x060009FE RID: 2558 RVA: 0x0002FB5D File Offset: 0x0002DD5D
		// (set) Token: 0x060009FF RID: 2559 RVA: 0x0002FB65 File Offset: 0x0002DD65
		public double DeltaRobotY { get; set; }

		// Token: 0x1700036A RID: 874
		// (get) Token: 0x06000A00 RID: 2560 RVA: 0x0002FB6E File Offset: 0x0002DD6E
		// (set) Token: 0x06000A01 RID: 2561 RVA: 0x0002FB76 File Offset: 0x0002DD76
		public double DeltaAngleDeg { get; set; }

		// Token: 0x1700036B RID: 875
		// (get) Token: 0x06000A02 RID: 2562 RVA: 0x0002FB7F File Offset: 0x0002DD7F
		public List<CalibHandEyeObjectResult> Objects { get; } = new List<CalibHandEyeObjectResult>();

		// Token: 0x1700036C RID: 876
		// (get) Token: 0x06000A03 RID: 2563 RVA: 0x0002FB87 File Offset: 0x0002DD87
		// (set) Token: 0x06000A04 RID: 2564 RVA: 0x0002FB8F File Offset: 0x0002DD8F
		public double PixelRow { get; set; }

		// Token: 0x1700036D RID: 877
		// (get) Token: 0x06000A05 RID: 2565 RVA: 0x0002FB98 File Offset: 0x0002DD98
		// (set) Token: 0x06000A06 RID: 2566 RVA: 0x0002FBA0 File Offset: 0x0002DDA0
		public double PixelColumn { get; set; }

		// Token: 0x1700036E RID: 878
		// (get) Token: 0x06000A07 RID: 2567 RVA: 0x0002FBA9 File Offset: 0x0002DDA9
		// (set) Token: 0x06000A08 RID: 2568 RVA: 0x0002FBB1 File Offset: 0x0002DDB1
		public double RobotX { get; set; }

		// Token: 0x1700036F RID: 879
		// (get) Token: 0x06000A09 RID: 2569 RVA: 0x0002FBBA File Offset: 0x0002DDBA
		// (set) Token: 0x06000A0A RID: 2570 RVA: 0x0002FBC2 File Offset: 0x0002DDC2
		public double RobotY { get; set; }

		// Token: 0x17000370 RID: 880
		// (get) Token: 0x06000A0B RID: 2571 RVA: 0x0002FBCB File Offset: 0x0002DDCB
		// (set) Token: 0x06000A0C RID: 2572 RVA: 0x0002FBD3 File Offset: 0x0002DDD3
		public double AngleRad { get; set; }

		// Token: 0x17000371 RID: 881
		// (get) Token: 0x06000A0D RID: 2573 RVA: 0x0002FBDC File Offset: 0x0002DDDC
		// (set) Token: 0x06000A0E RID: 2574 RVA: 0x0002FBE4 File Offset: 0x0002DDE4
		public double VisionAngleDeg { get; set; }

		// Token: 0x17000372 RID: 882
		// (get) Token: 0x06000A0F RID: 2575 RVA: 0x0002FBED File Offset: 0x0002DDED
		// (set) Token: 0x06000A10 RID: 2576 RVA: 0x0002FBF5 File Offset: 0x0002DDF5
		public double MappedVisionAngleDeg { get; set; }

		// Token: 0x17000373 RID: 883
		// (get) Token: 0x06000A11 RID: 2577 RVA: 0x0002FBFE File Offset: 0x0002DDFE
		// (set) Token: 0x06000A12 RID: 2578 RVA: 0x0002FC06 File Offset: 0x0002DE06
		public double AngleOffsetDeg { get; set; }

		// Token: 0x17000374 RID: 884
		// (get) Token: 0x06000A13 RID: 2579 RVA: 0x0002FC0F File Offset: 0x0002DE0F
		// (set) Token: 0x06000A14 RID: 2580 RVA: 0x0002FC17 File Offset: 0x0002DE17
		public double AngleDeg { get; set; }

		// Token: 0x17000375 RID: 885
		// (get) Token: 0x06000A15 RID: 2581 RVA: 0x0002FC20 File Offset: 0x0002DE20
		// (set) Token: 0x06000A16 RID: 2582 RVA: 0x0002FC28 File Offset: 0x0002DE28
		public double Score { get; set; }

		// Token: 0x17000376 RID: 886
		// (get) Token: 0x06000A17 RID: 2583 RVA: 0x0002FC31 File Offset: 0x0002DE31
		// (set) Token: 0x06000A18 RID: 2584 RVA: 0x0002FC39 File Offset: 0x0002DE39
		public bool UsedTcpOffset { get; set; }

		// Token: 0x17000377 RID: 887
		// (get) Token: 0x06000A19 RID: 2585 RVA: 0x0002FC42 File Offset: 0x0002DE42
		// (set) Token: 0x06000A1A RID: 2586 RVA: 0x0002FC4A File Offset: 0x0002DE4A
		public double TcpPixelRow { get; set; }

		// Token: 0x17000378 RID: 888
		// (get) Token: 0x06000A1B RID: 2587 RVA: 0x0002FC53 File Offset: 0x0002DE53
		// (set) Token: 0x06000A1C RID: 2588 RVA: 0x0002FC5B File Offset: 0x0002DE5B
		public double TcpPixelColumn { get; set; }

		// Token: 0x17000379 RID: 889
		// (get) Token: 0x06000A1D RID: 2589 RVA: 0x0002FC64 File Offset: 0x0002DE64
		// (set) Token: 0x06000A1E RID: 2590 RVA: 0x0002FC6C File Offset: 0x0002DE6C
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x1700037A RID: 890
		// (get) Token: 0x06000A1F RID: 2591 RVA: 0x0002FC75 File Offset: 0x0002DE75
		// (set) Token: 0x06000A20 RID: 2592 RVA: 0x0002FC7D File Offset: 0x0002DE7D
		public double ProcessingTimeMs { get; set; }

		// Token: 0x1700037B RID: 891
		// (get) Token: 0x06000A21 RID: 2593 RVA: 0x0002FC86 File Offset: 0x0002DE86
		// (set) Token: 0x06000A22 RID: 2594 RVA: 0x0002FC8E File Offset: 0x0002DE8E
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x1700037C RID: 892
		// (get) Token: 0x06000A23 RID: 2595 RVA: 0x0002FC97 File Offset: 0x0002DE97
		// (set) Token: 0x06000A24 RID: 2596 RVA: 0x0002FC9F File Offset: 0x0002DE9F
		public string CalibrationFilePath { get; set; }

		// Token: 0x1700037D RID: 893
		// (get) Token: 0x06000A25 RID: 2597 RVA: 0x0002FCA8 File Offset: 0x0002DEA8
		// (set) Token: 0x06000A26 RID: 2598 RVA: 0x0002FCB0 File Offset: 0x0002DEB0
		public string Message { get; set; }
	}
}
