﻿using System;
using HalconDotNet;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000C8 RID: 200
	public class CalibHandEyeResultDrawer
	{
		// Token: 0x06000A61 RID: 2657 RVA: 0x0002FEAC File Offset: 0x0002E0AC
		public void Draw(HWindow window, ToolVision tool, CalibHandEyeResult result)
		{
			bool flag = window == null || tool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				CalibHandEyeToolConfig config = tool.Config as CalibHandEyeToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					string color = string.IsNullOrWhiteSpace(config.TextColor) ? "green" : config.TextColor;
					HOperatorSet.SetColor(window, color);
					HOperatorSet.SetLineWidth(window, 2);
					bool flag3 = result.Objects != null && result.Objects.Count > 0;
					if (flag3)
					{
						foreach (CalibHandEyeObjectResult obj in result.Objects)
						{
							this.DrawObject(window, tool, config, result, obj);
						}
					}
					else
					{
						HOperatorSet.DispCross(window, result.PixelRow, result.PixelColumn, 40, 0);
						bool showText = config.ShowText;
						if (showText)
						{
							this.WriteObjectText(window, tool.Name, result.MasterToolName, result.PixelRow, result.PixelColumn, result.RobotX, result.RobotY, null, false, 0.0, 0.0, 0.0);
						}
					}
				}
			}
		}

		// Token: 0x06000A62 RID: 2658 RVA: 0x00030038 File Offset: 0x0002E238
		private void DrawObject(HWindow window, ToolVision tool, CalibHandEyeToolConfig config, CalibHandEyeResult result, CalibHandEyeObjectResult obj)
		{
			string objectColor = obj.Picked ? (string.IsNullOrWhiteSpace(config.TextColor) ? "green" : config.TextColor) : "orange";
			HOperatorSet.SetColor(window, objectColor);
			HOperatorSet.DispCross(window, obj.PixelRow, obj.PixelColumn, 40, 0);
			bool flag = !config.ShowText;
			if (!flag)
			{
				string label = (result.ObjectMode == CalibHandEyeObjectMode.MultiObject) ? string.Concat(new string[]
				{
					"[",
					obj.GridRow.ToString(),
					",",
					obj.GridColumn.ToString(),
					"]",
					obj.Picked ? " *" : string.Empty
				}) : tool.Name;
				this.WriteObjectText(window, label, result.MasterToolName, obj.PixelRow, obj.PixelColumn, obj.RobotX, obj.RobotY, new double?(obj.Score), obj.HasDelta, obj.DeltaRobotX, obj.DeltaRobotY, obj.DeltaAngleDeg);
			}
		}

		// Token: 0x06000A63 RID: 2659 RVA: 0x0003018C File Offset: 0x0002E38C
		private void WriteObjectText(HWindow window, string title, string masterToolName, double pixelRow, double pixelColumn, double robotX, double robotY, double? score, bool hasDelta = false, double deltaRobotX = 0.0, double deltaRobotY = 0.0, double deltaAngleDeg = 0.0)
		{
			string text = string.Concat(new string[]
			{
				title,
				"\nMaster: ",
				masterToolName ?? "None",
				"\nRobot X: ",
				robotX.ToString("0.000"),
				" mm\nRobot Y: ",
				robotY.ToString("0.000"),
				" mm\nPixel R,C: ",
				pixelRow.ToString("0.000"),
				", ",
				pixelColumn.ToString("0.000")
			});
			if (hasDelta)
			{
				text = string.Concat(new string[]
				{
					text,
					"\nDelta X: ",
					deltaRobotX.ToString("0.000"),
					" mm\nDelta Y: ",
					deltaRobotY.ToString("0.000"),
					" mm\nDelta A: ",
					deltaAngleDeg.ToString("0.000"),
					" deg"
				});
			}
			bool flag = score != null;
			if (flag)
			{
				text = text + "\nScore: " + score.Value.ToString("0.000");
			}
			HOperatorSet.SetTposition(window, pixelRow + 18.0, pixelColumn + 18.0);
			HOperatorSet.WriteString(window, text);
		}
	}
}
