﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000CC RID: 204
	public class CalibHandEyeToolConfig : ToolConfigBase
	{
		// Token: 0x1700039A RID: 922
		// (get) Token: 0x06000A65 RID: 2661 RVA: 0x000302F0 File Offset: 0x0002E4F0
		// (set) Token: 0x06000A66 RID: 2662 RVA: 0x00030308 File Offset: 0x0002E508
		[DisplayName("Calibration File Path")]
		public string CalibrationFilePath
		{
			get
			{
				return this._calibrationFilePath;
			}
			set
			{
				this.SetValue<string>(ref this._calibrationFilePath, value, "CalibrationFilePath");
			}
		}

		// Token: 0x1700039B RID: 923
		// (get) Token: 0x06000A67 RID: 2663 RVA: 0x00030320 File Offset: 0x0002E520
		// (set) Token: 0x06000A68 RID: 2664 RVA: 0x00030338 File Offset: 0x0002E538
		[DisplayName("Object Mode")]
		[Description("SingleSelected: only the picked object from the master tool. MultiObject: every object found by the master tool.")]
		public CalibHandEyeObjectMode ObjectMode
		{
			get
			{
				return this._objectMode;
			}
			set
			{
				this.SetValue<CalibHandEyeObjectMode>(ref this._objectMode, value, "ObjectMode");
			}
		}

		// Token: 0x1700039C RID: 924
		// (get) Token: 0x06000A69 RID: 2665 RVA: 0x00030350 File Offset: 0x0002E550
		// (set) Token: 0x06000A6A RID: 2666 RVA: 0x00030368 File Offset: 0x0002E568
		[DisplayName("Value Mode")]
		[Description("Absolute: output the calibrated real-world coordinate of each object. DeltaFromMaster: calibrate both the object and the master-defined pose, then output the delta (object - master) after calibration.")]
		public CalibHandEyeValueMode ValueMode
		{
			get
			{
				return this._valueMode;
			}
			set
			{
				this.SetValue<CalibHandEyeValueMode>(ref this._valueMode, value, "ValueMode");
			}
		}

		// Token: 0x1700039D RID: 925
		// (get) Token: 0x06000A6B RID: 2667 RVA: 0x00030380 File Offset: 0x0002E580
		// (set) Token: 0x06000A6C RID: 2668 RVA: 0x00030398 File Offset: 0x0002E598
		[DisplayName("Master Tool")]
		public string MasterToolName
		{
			get
			{
				return this._masterToolName;
			}
			set
			{
				this.SetValue<string>(ref this._masterToolName, value, "MasterToolName");
			}
		}

		// Token: 0x1700039E RID: 926
		// (get) Token: 0x06000A6D RID: 2669 RVA: 0x000303B0 File Offset: 0x0002E5B0
		// (set) Token: 0x06000A6E RID: 2670 RVA: 0x000303C8 File Offset: 0x0002E5C8
		[DisplayName("Apply TCP Offset")]
		[Description("When enabled and the calibration file has a 3-angle TCP center plus TCP mapping reference, the tool reports the robot TCP position (pattern + rotation-correct offset) instead of the raw pattern position.")]
		public bool ApplyTcpOffset
		{
			get
			{
				return this._applyTcpOffset;
			}
			set
			{
				this.SetValue<bool>(ref this._applyTcpOffset, value, "ApplyTcpOffset");
			}
		}

		// Token: 0x1700039F RID: 927
		// (get) Token: 0x06000A6F RID: 2671 RVA: 0x000303E0 File Offset: 0x0002E5E0
		// (set) Token: 0x06000A70 RID: 2672 RVA: 0x000303F8 File Offset: 0x0002E5F8
		[DisplayName("Use Manual Robot TCP")]
		[Description("With Apply TCP Offset: derive the TCP offset from the real robot TCP entered below (the taught pick X/Y for the part at the MASTER pose) instead of the rotation-circle center. The calibration file is still used to convert between image and robot; the entered point is back-projected into the image and anchored at the master pattern pose, so it automatically includes any gripper eccentricity.")]
		public bool UseManualTcp
		{
			get
			{
				return this._useManualTcp;
			}
			set
			{
				this.SetValue<bool>(ref this._useManualTcp, value, "UseManualTcp");
			}
		}

		// Token: 0x170003A0 RID: 928
		// (get) Token: 0x06000A71 RID: 2673 RVA: 0x00030410 File Offset: 0x0002E610
		// (set) Token: 0x06000A72 RID: 2674 RVA: 0x00030428 File Offset: 0x0002E628
		[DisplayName("Manual TCP Robot X (mm)")]
		[Description("Robot X of the taught pick command when the gripper holds the part at the MASTER pose.")]
		public double ManualTcpRobotX
		{
			get
			{
				return this._manualTcpRobotX;
			}
			set
			{
				this.SetValue<double>(ref this._manualTcpRobotX, value, "ManualTcpRobotX");
			}
		}

		// Token: 0x170003A1 RID: 929
		// (get) Token: 0x06000A73 RID: 2675 RVA: 0x00030440 File Offset: 0x0002E640
		// (set) Token: 0x06000A74 RID: 2676 RVA: 0x00030458 File Offset: 0x0002E658
		[DisplayName("Manual TCP Robot Y (mm)")]
		[Description("Robot Y of the taught pick command when the gripper holds the part at the MASTER pose.")]
		public double ManualTcpRobotY
		{
			get
			{
				return this._manualTcpRobotY;
			}
			set
			{
				this.SetValue<double>(ref this._manualTcpRobotY, value, "ManualTcpRobotY");
			}
		}

		// Token: 0x170003A2 RID: 930
		// (get) Token: 0x06000A75 RID: 2677 RVA: 0x00030470 File Offset: 0x0002E670
		// (set) Token: 0x06000A76 RID: 2678 RVA: 0x00030488 File Offset: 0x0002E688
		[DisplayName("Angle Delta Mode")]
		[Description("Only used with Use Manual Robot TCP in DeltaFromMaster mode. ShortestRotation: the delta stays within +/-180 deg (the robot turns the short way, but the commanded Rz can leave -180..180). TargetInRange: Rz + delta always stays inside -180..180, at the cost of a delta up to +/-360 deg.")]
		public CalibHandEyeAngleDeltaMode AngleDeltaMode
		{
			get
			{
				return this._angleDeltaMode;
			}
			set
			{
				this.SetValue<CalibHandEyeAngleDeltaMode>(ref this._angleDeltaMode, value, "AngleDeltaMode");
			}
		}

		// Token: 0x170003A3 RID: 931
		// (get) Token: 0x06000A77 RID: 2679 RVA: 0x000304A0 File Offset: 0x0002E6A0
		// (set) Token: 0x06000A78 RID: 2680 RVA: 0x000304B8 File Offset: 0x0002E6B8
		[DisplayName("Manual TCP Robot Rz (deg)")]
		[Description("Robot Rz of the taught pick command when the gripper holds the part at the MASTER pose. With Use Manual Robot TCP the output angle is anchored to this value: a part at the master orientation reports exactly this Rz, and a rotated part reports this Rz plus the mapped angle difference.")]
		public double ManualTcpRobotRz
		{
			get
			{
				return this._manualTcpRobotRz;
			}
			set
			{
				this.SetValue<double>(ref this._manualTcpRobotRz, value, "ManualTcpRobotRz");
			}
		}

		// Token: 0x170003A4 RID: 932
		// (get) Token: 0x06000A79 RID: 2681 RVA: 0x000304D0 File Offset: 0x0002E6D0
		// (set) Token: 0x06000A7A RID: 2682 RVA: 0x000304E8 File Offset: 0x0002E6E8
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				this.SetValue<bool>(ref this._showText, value, "ShowText");
			}
		}

		// Token: 0x170003A5 RID: 933
		// (get) Token: 0x06000A7B RID: 2683 RVA: 0x00030500 File Offset: 0x0002E700
		// (set) Token: 0x06000A7C RID: 2684 RVA: 0x00030518 File Offset: 0x0002E718
		[DisplayName("Text Color")]
		public string TextColor
		{
			get
			{
				return this._textColor;
			}
			set
			{
				this.SetValue<string>(ref this._textColor, value, "TextColor");
			}
		}

		// Token: 0x170003A6 RID: 934
		// (get) Token: 0x06000A7D RID: 2685 RVA: 0x00030530 File Offset: 0x0002E730
		// (set) Token: 0x06000A7E RID: 2686 RVA: 0x00030548 File Offset: 0x0002E748
		[DisplayName("Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				this.SetValue<int>(ref this._textSize, (value < 8) ? 8 : value, "TextSize");
			}
		}

		// Token: 0x06000A7F RID: 2687 RVA: 0x00030568 File Offset: 0x0002E768
		protected bool SetValue<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
		{
			bool flag = object.Equals(field, value);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				field = value;
				base.OnPropertyChanged(propertyName);
				result = true;
			}
			return result;
		}

		// Token: 0x0400043A RID: 1082
		private string _calibrationFilePath;

		// Token: 0x0400043B RID: 1083
		private string _masterToolName = "None";

		// Token: 0x0400043C RID: 1084
		private CalibHandEyeObjectMode _objectMode = CalibHandEyeObjectMode.MultiObject;

		// Token: 0x0400043D RID: 1085
		private CalibHandEyeValueMode _valueMode = CalibHandEyeValueMode.Absolute;

		// Token: 0x0400043E RID: 1086
		private bool _applyTcpOffset = true;

		// Token: 0x0400043F RID: 1087
		private bool _useManualTcp;

		// Token: 0x04000440 RID: 1088
		private double _manualTcpRobotX;

		// Token: 0x04000441 RID: 1089
		private double _manualTcpRobotY;

		// Token: 0x04000442 RID: 1090
		private double _manualTcpRobotRz;

		// Token: 0x04000443 RID: 1091
		private CalibHandEyeAngleDeltaMode _angleDeltaMode = CalibHandEyeAngleDeltaMode.ShortestRotation;

		// Token: 0x04000444 RID: 1092
		private bool _showText = true;

		// Token: 0x04000445 RID: 1093
		private string _textColor = "green";

		// Token: 0x04000446 RID: 1094
		private int _textSize = 14;
	}
}
