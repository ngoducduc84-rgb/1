﻿using System;

namespace VisionMachine.VisionTools.CalibHandEye
{
	// Token: 0x020000CB RID: 203
	public enum CalibHandEyeValueMode
	{
		// Token: 0x04000438 RID: 1080
		Absolute,
		// Token: 0x04000439 RID: 1081
		DeltaFromMaster
	}
}
