﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using Microsoft.Win32;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.CalibHandEye.Views
{
	// Token: 0x020000CD RID: 205
	public partial class CalibHandEye_para : UserControl
	{
		// Token: 0x06000A81 RID: 2689 RVA: 0x000305FD File Offset: 0x0002E7FD
		public CalibHandEye_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000A82 RID: 2690 RVA: 0x00030610 File Offset: 0x0002E810
		private void BrowseCalibFile_Click(object sender, RoutedEventArgs e)
		{
			CalibHandEyeParameterPanelViewModel viewModel = base.DataContext as CalibHandEyeParameterPanelViewModel;
			bool flag = ((viewModel != null) ? viewModel.Config : null) == null;
			if (!flag)
			{
				OpenFileDialog dialog = new OpenFileDialog
				{
					Title = "Select Calibration File",
					Filter = "Halcon tuple (*.dat)|*.dat|All files (*.*)|*.*",
					CheckFileExists = true,
					Multiselect = false
				};
				bool flag2 = !dialog.ShowDialog().GetValueOrDefault();
				if (!flag2)
				{
					viewModel.Config.CalibrationFilePath = dialog.FileName;
				}
			}
		}

		// Token: 0x06000A83 RID: 2691 RVA: 0x00030697 File Offset: 0x0002E897
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.CalibHandEyeTrialRun();
			}
		}
	}
}
