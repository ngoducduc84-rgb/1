﻿using System;
using System.Diagnostics;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.CircleMaster
{
	// Token: 0x020000A3 RID: 163
	public class CircleMasterActionService : IToolActionService
	{
		// Token: 0x170002E9 RID: 745
		// (get) Token: 0x06000877 RID: 2167 RVA: 0x000271E0 File Offset: 0x000253E0
		public ToolType ToolType
		{
			get
			{
				return ToolType.CircleMaster;
			}
		}

		// Token: 0x06000878 RID: 2168 RVA: 0x000271F4 File Offset: 0x000253F4
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, CircleMasterActionService.CircleMasterRunMode.TrialRun);
		}

		// Token: 0x06000879 RID: 2169 RVA: 0x00027201 File Offset: 0x00025401
		public void Matching(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, CircleMasterActionService.CircleMasterRunMode.Matching);
		}

		// Token: 0x0600087A RID: 2170 RVA: 0x0002720E File Offset: 0x0002540E
		public void DefineMaster(ToolActionContext context, ToolVision tool)
		{
			this.RunAndDisplay(context, tool, CircleMasterActionService.CircleMasterRunMode.DefineMaster);
		}

		// Token: 0x0600087B RID: 2171 RVA: 0x0002721C File Offset: 0x0002541C
		private void RunAndDisplay(ToolActionContext context, ToolVision tool, CircleMasterActionService.CircleMasterRunMode runMode)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				CircleMasterResult result = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						input = this._pipelineService.BuildInputImageForTool(processContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							HOperatorSet.CopyImage(original, out input);
						}
						CircleMasterProcessor processor = new CircleMasterProcessor();
						Stopwatch stopwatch = Stopwatch.StartNew();
						if (runMode != CircleMasterActionService.CircleMasterRunMode.DefineMaster)
						{
							if (runMode != CircleMasterActionService.CircleMasterRunMode.TrialRun)
							{
								result = processor.Match(input, tool);
							}
							else
							{
								result = processor.TrialRun(input, tool);
							}
						}
						else
						{
							result = processor.DefineMaster(input, tool);
						}
						stopwatch.Stop();
						bool flag4 = result != null && result.TotalProcessingTimeMs <= 0.0;
						if (flag4)
						{
							result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						Action<ToolVision, object> resultReporter = context.ResultReporter;
						if (resultReporter != null)
						{
							resultReporter(tool, result);
						}
						bool flag5 = result != null && !result.IsSuccess;
						if (flag5)
						{
							ToolActionFeedback.ReportError(context, result.Message);
						}
						context.DisplayController.DisplayImage(input);
						CircleMasterResult overlayResult = result;
						result = null;
						context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
						{
							this._drawer.Draw(window, tool, overlayResult);
						}, overlayResult);
					}
				}
				finally
				{
					if (result != null)
					{
						result.Dispose();
					}
					if (input != null)
					{
						input.Dispose();
					}
					if (original != null)
					{
						original.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
				}
			}
		}

		// Token: 0x04000364 RID: 868
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();

		// Token: 0x04000365 RID: 869
		private readonly CircleMasterResultDrawer _drawer = new CircleMasterResultDrawer();

		// Token: 0x0200031A RID: 794
		private enum CircleMasterRunMode
		{
			// Token: 0x04001134 RID: 4404
			Matching,
			// Token: 0x04001135 RID: 4405
			DefineMaster,
			// Token: 0x04001136 RID: 4406
			TrialRun
		}
	}
}
