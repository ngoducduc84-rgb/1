﻿using System;
using VisionMachine.VisionTools.FindCircle;

namespace VisionMachine.VisionTools.CircleMaster
{
	// Token: 0x020000A4 RID: 164
	public class CircleMasterParameterPanelViewModel : FindCircleParameterPanelViewModel
	{
		// Token: 0x170002EA RID: 746
		// (get) Token: 0x0600087D RID: 2173 RVA: 0x000274AC File Offset: 0x000256AC
		// (set) Token: 0x0600087E RID: 2174 RVA: 0x000274C9 File Offset: 0x000256C9
		public CircleMasterToolConfig CircleMasterConfig
		{
			get
			{
				return base.FindCircleConfig as CircleMasterToolConfig;
			}
			set
			{
				base.FindCircleConfig = value;
			}
		}
	}
}
