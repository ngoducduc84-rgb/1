﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.CircleMaster
{
	// Token: 0x020000A5 RID: 165
	public class CircleMasterProcessor : IToolProcessor
	{
		// Token: 0x06000880 RID: 2176 RVA: 0x000274DD File Offset: 0x000256DD
		public CircleMasterProcessor() : this(null)
		{
		}

		// Token: 0x06000881 RID: 2177 RVA: 0x000274E8 File Offset: 0x000256E8
		public CircleMasterProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x170002EB RID: 747
		// (get) Token: 0x06000882 RID: 2178 RVA: 0x000274FC File Offset: 0x000256FC
		public ToolType ToolType
		{
			get
			{
				return ToolType.CircleMaster;
			}
		}

		// Token: 0x06000883 RID: 2179 RVA: 0x00027510 File Offset: 0x00025710
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			CircleMasterResult result = this.Match((context != null) ? context.InputImage : null, tool);
			return new ToolProcessResult
			{
				IsSuccess = result.IsSuccess,
				Message = result.Message,
				Data = result
			};
		}

		// Token: 0x06000884 RID: 2180 RVA: 0x00027560 File Offset: 0x00025760
		public CircleMasterResult Match(HObject image, ToolVision tool)
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			CircleMasterResult result = new CircleMasterResult();
			CircleMasterResult result2;
			try
			{
				FindCircleResult circle = new FindCircleProcessor(this._cachedMasterResults).Run(image, tool);
				result.CircleResult = circle;
				result.ToolName = ((tool == null) ? null : tool.Name);
				result.RoiName = ((circle == null) ? null : circle.RoiName);
				result.ProcessingTimeMs = ((circle == null) ? 0.0 : circle.ProcessingTimeMs);
				result.TotalProcessingTimeMs = ((circle == null) ? 0.0 : circle.TotalProcessingTimeMs);
				bool flag = circle == null || !circle.IsSuccess;
				if (flag)
				{
					result.Message = ((circle == null) ? "Circle Master result is not available." : circle.Message);
					result2 = result;
				}
				else
				{
					result.Row = circle.Row;
					result.Column = circle.Column;
					result.Angle = 0.0;
					result.Score = 1.0;
					this.ApplyDeltaToResult(tool, result);
					result.IsSuccess = true;
					result.Message = "Circle Master OK.";
					result2 = result;
				}
			}
			catch (Exception ex)
			{
				result.Message = "Circle Master failed: " + ex.Message;
				result2 = result;
			}
			finally
			{
				stopwatch.Stop();
				bool flag2 = result.ProcessingTimeMs <= 0.0;
				if (flag2)
				{
					result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				}
				bool flag3 = result.TotalProcessingTimeMs <= 0.0;
				if (flag3)
				{
					result.TotalProcessingTimeMs = result.ProcessingTimeMs;
				}
			}
			return result2;
		}

		// Token: 0x06000885 RID: 2181 RVA: 0x0002773C File Offset: 0x0002593C
		public CircleMasterResult DefineMaster(HObject image, ToolVision tool)
		{
			CircleMasterResult result = this.Match(image, tool);
			bool flag = !result.IsSuccess;
			CircleMasterResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeModelToolTrain train = this.EnsureTrain(tool);
				train.MasterRow = result.Row;
				train.MasterColumn = result.Column;
				train.MasterAngle = 0.0;
				train.LastRow = result.Row;
				train.LastColumn = result.Column;
				train.LastAngle = 0.0;
				train.LastScore = result.Score;
				train.HasMasterDefined = true;
				result.DeltaRow = 0.0;
				result.DeltaColumn = 0.0;
				result.DeltaAngle = 0.0;
				result.HasMasterDefined = true;
				result.Message = "Circle Master defined.";
				result2 = result;
			}
			return result2;
		}

		// Token: 0x06000886 RID: 2182 RVA: 0x00027824 File Offset: 0x00025A24
		public CircleMasterResult TrialRun(HObject image, ToolVision tool)
		{
			CircleMasterResult result = this.Match(image, tool);
			bool flag = !result.IsSuccess;
			CircleMasterResult result2;
			if (flag)
			{
				result2 = result;
			}
			else
			{
				ShapeModelToolTrain train = (tool == null) ? null : (tool.TrainModel as ShapeModelToolTrain);
				bool flag2 = train == null || !train.HasMasterDefined;
				if (flag2)
				{
					result.IsSuccess = false;
					result.Message = "Master has not been defined.";
					result2 = result;
				}
				else
				{
					result.DeltaRow = result.Row - train.MasterRow;
					result.DeltaColumn = result.Column - train.MasterColumn;
					result.DeltaAngle = 0.0;
					result.HasMasterDefined = true;
					result.DisplayDeltaFromMaster = true;
					result.Message = "Trial Run OK. DeltaY=" + result.DeltaRow.ToString("0.000") + ", DeltaX=" + result.DeltaColumn.ToString("0.000");
					result2 = result;
				}
			}
			return result2;
		}

		// Token: 0x06000887 RID: 2183 RVA: 0x00027920 File Offset: 0x00025B20
		private void ApplyDeltaToResult(ToolVision tool, CircleMasterResult result)
		{
			ShapeModelToolTrain train = (tool == null) ? null : (tool.TrainModel as ShapeModelToolTrain);
			bool flag = train == null;
			if (flag)
			{
				train = this.EnsureTrain(tool);
			}
			bool flag2 = train == null;
			if (!flag2)
			{
				train.LastRow = result.Row;
				train.LastColumn = result.Column;
				train.LastAngle = 0.0;
				train.LastScore = result.Score;
				result.HasMasterDefined = train.HasMasterDefined;
				bool flag3 = !train.HasMasterDefined;
				if (!flag3)
				{
					result.DeltaRow = result.Row - train.MasterRow;
					result.DeltaColumn = result.Column - train.MasterColumn;
					result.DeltaAngle = 0.0;
				}
			}
		}

		// Token: 0x06000888 RID: 2184 RVA: 0x000279E8 File Offset: 0x00025BE8
		private ShapeModelToolTrain EnsureTrain(ToolVision tool)
		{
			bool flag = tool == null;
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				ShapeModelToolTrain train = tool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (flag2)
				{
					train = new ShapeModelToolTrain();
					tool.TrainModel = train;
				}
				result = train;
			}
			return result;
		}

		// Token: 0x04000366 RID: 870
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;
	}
}
