﻿using System;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.FindCircle;

namespace VisionMachine.VisionTools.CircleMaster
{
	// Token: 0x020000A6 RID: 166
	public class CircleMasterResult : ShapeMatchResult, IDisposable
	{
		// Token: 0x170002EC RID: 748
		// (get) Token: 0x06000889 RID: 2185 RVA: 0x00027A2B File Offset: 0x00025C2B
		// (set) Token: 0x0600088A RID: 2186 RVA: 0x00027A33 File Offset: 0x00025C33
		public string ToolName { get; set; }

		// Token: 0x170002ED RID: 749
		// (get) Token: 0x0600088B RID: 2187 RVA: 0x00027A3C File Offset: 0x00025C3C
		// (set) Token: 0x0600088C RID: 2188 RVA: 0x00027A44 File Offset: 0x00025C44
		public FindCircleResult CircleResult { get; set; }

		// Token: 0x170002EE RID: 750
		// (get) Token: 0x0600088D RID: 2189 RVA: 0x00027A4D File Offset: 0x00025C4D
		// (set) Token: 0x0600088E RID: 2190 RVA: 0x00027A55 File Offset: 0x00025C55
		public bool DisplayDeltaFromMaster { get; set; }

		// Token: 0x170002EF RID: 751
		// (get) Token: 0x0600088F RID: 2191 RVA: 0x00027A5E File Offset: 0x00025C5E
		// (set) Token: 0x06000890 RID: 2192 RVA: 0x00027A66 File Offset: 0x00025C66
		public bool HasMasterDefined { get; set; }

		// Token: 0x170002F0 RID: 752
		// (get) Token: 0x06000891 RID: 2193 RVA: 0x00027A6F File Offset: 0x00025C6F
		// (set) Token: 0x06000892 RID: 2194 RVA: 0x00027A77 File Offset: 0x00025C77
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x06000893 RID: 2195 RVA: 0x00027A80 File Offset: 0x00025C80
		public void Dispose()
		{
			FindCircleResult circleResult = this.CircleResult;
			if (circleResult != null)
			{
				circleResult.Dispose();
			}
		}
	}
}
