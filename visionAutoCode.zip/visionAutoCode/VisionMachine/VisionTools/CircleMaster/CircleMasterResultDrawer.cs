﻿using System;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.FindCircle;

namespace VisionMachine.VisionTools.CircleMaster
{
	// Token: 0x020000A7 RID: 167
	public class CircleMasterResultDrawer
	{
		// Token: 0x06000895 RID: 2197 RVA: 0x00027A98 File Offset: 0x00025C98
		public void Draw(HWindow window, ToolVision tool, CircleMasterResult result)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				bool flag2 = result.CircleResult != null;
				if (flag2)
				{
					this._circleDrawer.Draw(window, tool, result.CircleResult);
				}
				CircleMasterToolConfig config = tool.Config as CircleMasterToolConfig;
				bool flag3 = config == null || !config.ShowText || !result.IsSuccess || !result.DisplayDeltaFromMaster;
				if (!flag3)
				{
					try
					{
						HOperatorSet.SetFont(window, "Arial-" + Math.Max(1, config.TextSize).ToString());
					}
					catch
					{
					}
					HOperatorSet.SetColor(window, config.DisplayColor);
					HOperatorSet.SetTposition(window, result.Row + 20.0, result.Column);
					HOperatorSet.WriteString(window, string.Concat(new string[]
					{
						tool.Name,
						" dY=",
						result.DeltaRow.ToString("0.000"),
						" dX=",
						result.DeltaColumn.ToString("0.000")
					}));
				}
			}
		}

		// Token: 0x0400036C RID: 876
		private readonly FindCircleResultDrawer _circleDrawer = new FindCircleResultDrawer();
	}
}
