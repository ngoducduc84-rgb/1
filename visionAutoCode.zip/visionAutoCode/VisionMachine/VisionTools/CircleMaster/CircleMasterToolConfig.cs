﻿using System;
using VisionMachine.VisionTools.FindCircle;

namespace VisionMachine.VisionTools.CircleMaster
{
	// Token: 0x020000A8 RID: 168
	public class CircleMasterToolConfig : FindCircleToolConfig
	{
	}
}
