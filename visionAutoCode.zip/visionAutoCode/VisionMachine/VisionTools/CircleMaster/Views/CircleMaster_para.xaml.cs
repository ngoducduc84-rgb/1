﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.CircleMaster.Views
{
	// Token: 0x020000A9 RID: 169
	public partial class CircleMaster_para : UserControl
	{
		// Token: 0x06000898 RID: 2200 RVA: 0x00027C25 File Offset: 0x00025E25
		public CircleMaster_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000899 RID: 2201 RVA: 0x00027C36 File Offset: 0x00025E36
		private void BtnMatching_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.CircleMasterMatching();
			}
		}

		// Token: 0x0600089A RID: 2202 RVA: 0x00027C4A File Offset: 0x00025E4A
		private void BtnMasterDefine_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.CircleMasterDefineMaster();
			}
		}

		// Token: 0x0600089B RID: 2203 RVA: 0x00027C5E File Offset: 0x00025E5E
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.CircleMasterTrialRun();
			}
		}
	}
}
