﻿using System;
using System.Diagnostics;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000111 RID: 273
	public class CountBoundingBoxActionService : IToolActionService
	{
		// Token: 0x170004FE RID: 1278
		// (get) Token: 0x06000E0E RID: 3598 RVA: 0x00040DD4 File Offset: 0x0003EFD4
		public ToolType ToolType
		{
			get
			{
				return ToolType.CountBoundingBox;
			}
		}

		// Token: 0x06000E0F RID: 3599 RVA: 0x00040DE8 File Offset: 0x0003EFE8
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext buildContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						input = this._pipelineService.BuildInputImageForTool(buildContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							if (input != null)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						Stopwatch stopwatch = Stopwatch.StartNew();
						CountBoundingBoxResult result = this._processor.Run(input, tool);
						stopwatch.Stop();
						bool flag4 = result.ProcessingTimeMs <= 0.0;
						if (flag4)
						{
							result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						bool flag5 = result.TotalProcessingTimeMs <= 0.0;
						if (flag5)
						{
							result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						result.InputSourceToolName = inputSourceToolName;
						InspectionResultStore.Record(tool.Name, result);
						Action<ToolVision, object> resultReporter = context.ResultReporter;
						if (resultReporter != null)
						{
							resultReporter(tool, result);
						}
						context.DisplayController.DisplayImage(input);
						context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
						{
							this._drawer.Draw(window, tool, result);
						}, result);
						bool flag6 = !result.IsSuccess && !string.IsNullOrWhiteSpace(result.Message);
						if (flag6)
						{
							ToolActionFeedback.ReportError(context, result.Message);
						}
					}
				}
				finally
				{
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06000E10 RID: 3600 RVA: 0x000410A0 File Offset: 0x0003F2A0
		private string GetInputSourceToolName(ToolVision tool)
		{
			CountBoundingBoxToolConfig config = ((tool != null) ? tool.Config : null) as CountBoundingBoxToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						result = "PreviousToolOutput";
					}
					else
					{
						result = "OriginalImage";
					}
				}
			}
			return result;
		}

		// Token: 0x040005BD RID: 1469
		private readonly CountBoundingBoxProcessor _processor = new CountBoundingBoxProcessor();

		// Token: 0x040005BE RID: 1470
		private readonly CountBoundingBoxResultDrawer _drawer = new CountBoundingBoxResultDrawer();

		// Token: 0x040005BF RID: 1471
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
