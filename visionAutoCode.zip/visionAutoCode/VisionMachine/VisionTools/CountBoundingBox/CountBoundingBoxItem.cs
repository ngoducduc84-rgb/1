﻿using System;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000114 RID: 276
	public class CountBoundingBoxItem
	{
		// Token: 0x17000506 RID: 1286
		// (get) Token: 0x06000E33 RID: 3635 RVA: 0x000427A4 File Offset: 0x000409A4
		// (set) Token: 0x06000E34 RID: 3636 RVA: 0x000427AC File Offset: 0x000409AC
		public int Index { get; set; }

		// Token: 0x17000507 RID: 1287
		// (get) Token: 0x06000E35 RID: 3637 RVA: 0x000427B5 File Offset: 0x000409B5
		// (set) Token: 0x06000E36 RID: 3638 RVA: 0x000427BD File Offset: 0x000409BD
		public double Row1 { get; set; }

		// Token: 0x17000508 RID: 1288
		// (get) Token: 0x06000E37 RID: 3639 RVA: 0x000427C6 File Offset: 0x000409C6
		// (set) Token: 0x06000E38 RID: 3640 RVA: 0x000427CE File Offset: 0x000409CE
		public double Column1 { get; set; }

		// Token: 0x17000509 RID: 1289
		// (get) Token: 0x06000E39 RID: 3641 RVA: 0x000427D7 File Offset: 0x000409D7
		// (set) Token: 0x06000E3A RID: 3642 RVA: 0x000427DF File Offset: 0x000409DF
		public double Row2 { get; set; }

		// Token: 0x1700050A RID: 1290
		// (get) Token: 0x06000E3B RID: 3643 RVA: 0x000427E8 File Offset: 0x000409E8
		// (set) Token: 0x06000E3C RID: 3644 RVA: 0x000427F0 File Offset: 0x000409F0
		public double Column2 { get; set; }

		// Token: 0x1700050B RID: 1291
		// (get) Token: 0x06000E3D RID: 3645 RVA: 0x000427FC File Offset: 0x000409FC
		public double Width
		{
			get
			{
				return this.Column2 - this.Column1 + 1.0;
			}
		}

		// Token: 0x1700050C RID: 1292
		// (get) Token: 0x06000E3E RID: 3646 RVA: 0x00042828 File Offset: 0x00040A28
		public double Height
		{
			get
			{
				return this.Row2 - this.Row1 + 1.0;
			}
		}

		// Token: 0x1700050D RID: 1293
		// (get) Token: 0x06000E3F RID: 3647 RVA: 0x00042854 File Offset: 0x00040A54
		public double BoxArea
		{
			get
			{
				return this.Width * this.Height;
			}
		}

		// Token: 0x1700050E RID: 1294
		// (get) Token: 0x06000E40 RID: 3648 RVA: 0x00042873 File Offset: 0x00040A73
		// (set) Token: 0x06000E41 RID: 3649 RVA: 0x0004287B File Offset: 0x00040A7B
		public double BlobArea { get; set; }

		// Token: 0x1700050F RID: 1295
		// (get) Token: 0x06000E42 RID: 3650 RVA: 0x00042884 File Offset: 0x00040A84
		// (set) Token: 0x06000E43 RID: 3651 RVA: 0x0004288C File Offset: 0x00040A8C
		public int MemberCount { get; set; } = 1;

		// Token: 0x17000510 RID: 1296
		// (get) Token: 0x06000E44 RID: 3652 RVA: 0x00042895 File Offset: 0x00040A95
		// (set) Token: 0x06000E45 RID: 3653 RVA: 0x0004289D File Offset: 0x00040A9D
		public double CenterRow { get; set; }

		// Token: 0x17000511 RID: 1297
		// (get) Token: 0x06000E46 RID: 3654 RVA: 0x000428A6 File Offset: 0x00040AA6
		// (set) Token: 0x06000E47 RID: 3655 RVA: 0x000428AE File Offset: 0x00040AAE
		public double CenterColumn { get; set; }

		// Token: 0x17000512 RID: 1298
		// (get) Token: 0x06000E48 RID: 3656 RVA: 0x000428B7 File Offset: 0x00040AB7
		// (set) Token: 0x06000E49 RID: 3657 RVA: 0x000428BF File Offset: 0x00040ABF
		public int RoiIndex { get; set; }
	}
}
