﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000112 RID: 274
	public class CountBoundingBoxParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x170004FF RID: 1279
		// (get) Token: 0x06000E12 RID: 3602 RVA: 0x0004115F File Offset: 0x0003F35F
		// (set) Token: 0x06000E13 RID: 3603 RVA: 0x00041167 File Offset: 0x0003F367
		public ToolVision Tool { get; set; }

		// Token: 0x17000500 RID: 1280
		// (get) Token: 0x06000E14 RID: 3604 RVA: 0x00041170 File Offset: 0x0003F370
		// (set) Token: 0x06000E15 RID: 3605 RVA: 0x00041178 File Offset: 0x0003F378
		public CountBoundingBoxToolConfig Config { get; set; }

		// Token: 0x17000501 RID: 1281
		// (get) Token: 0x06000E16 RID: 3606 RVA: 0x00041181 File Offset: 0x0003F381
		// (set) Token: 0x06000E17 RID: 3607 RVA: 0x00041189 File Offset: 0x0003F389
		public CountBoundingBoxToolSpec Spec { get; set; }

		// Token: 0x17000502 RID: 1282
		// (get) Token: 0x06000E18 RID: 3608 RVA: 0x00041192 File Offset: 0x0003F392
		// (set) Token: 0x06000E19 RID: 3609 RVA: 0x0004119A File Offset: 0x0003F39A
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x17000503 RID: 1283
		// (get) Token: 0x06000E1A RID: 3610 RVA: 0x000411A4 File Offset: 0x0003F3A4
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x17000504 RID: 1284
		// (get) Token: 0x06000E1B RID: 3611 RVA: 0x000411C0 File Offset: 0x0003F3C0
		// (set) Token: 0x06000E1C RID: 3612 RVA: 0x000411D8 File Offset: 0x0003F3D8
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.Config != null && this.Config.InputLink != null;
					if (flag2)
					{
						this.Config.InputLink.SourceToolId = null;
						this.Config.InputLink.SourceToolName = ((this._selectedSourceTool == null) ? null : this._selectedSourceTool.ToolName);
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x06000E1D RID: 3613 RVA: 0x00041260 File Offset: 0x0003F460
		// (remove) Token: 0x06000E1E RID: 3614 RVA: 0x00041298 File Offset: 0x0003F498
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000E1F RID: 3615 RVA: 0x000412CD File Offset: 0x0003F4CD
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x06000E20 RID: 3616 RVA: 0x000412EC File Offset: 0x0003F4EC
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.Config == null || this.Config.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.Config.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.Config.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.Config.InputLink.SourceToolId = null;
				this.Config.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x040005C0 RID: 1472
		private ToolImageSourceOption _selectedSourceTool;
	}
}
