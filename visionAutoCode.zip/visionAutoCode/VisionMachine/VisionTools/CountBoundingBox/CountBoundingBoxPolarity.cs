﻿using System;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000117 RID: 279
	public enum CountBoundingBoxPolarity
	{
		// Token: 0x040005E3 RID: 1507
		BrightObjects,
		// Token: 0x040005E4 RID: 1508
		DarkObjects
	}
}
