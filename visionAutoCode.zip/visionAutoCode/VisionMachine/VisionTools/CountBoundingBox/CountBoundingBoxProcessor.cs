﻿using System;
using System.Collections.Generic;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000113 RID: 275
	public class CountBoundingBoxProcessor : IToolProcessor
	{
		// Token: 0x17000505 RID: 1285
		// (get) Token: 0x06000E22 RID: 3618 RVA: 0x000413CC File Offset: 0x0003F5CC
		public ToolType ToolType
		{
			get
			{
				return ToolType.CountBoundingBox;
			}
		}

		// Token: 0x06000E23 RID: 3619 RVA: 0x000413E0 File Offset: 0x0003F5E0
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			ToolProcessResult processResult = new ToolProcessResult();
			bool flag = context == null || context.InputImage == null;
			ToolProcessResult result2;
			if (flag)
			{
				processResult.IsSuccess = false;
				processResult.Message = "Input image null.";
				result2 = processResult;
			}
			else
			{
				CountBoundingBoxResult result = this.Run(context.InputImage, tool);
				processResult.IsSuccess = result.IsSuccess;
				processResult.Message = result.Message;
				processResult.Data = result;
				HObject copy;
				HOperatorSet.CopyImage(context.InputImage, out copy);
				context.OutputImage = copy;
				result2 = processResult;
			}
			return result2;
		}

		// Token: 0x06000E24 RID: 3620 RVA: 0x00041470 File Offset: 0x0003F670
		public CountBoundingBoxResult Run(HObject image, ToolVision tool)
		{
			CountBoundingBoxResult result = new CountBoundingBoxResult();
			bool flag = tool == null;
			CountBoundingBoxResult result2;
			if (flag)
			{
				result.Message = "Tool null.";
				result2 = result;
			}
			else
			{
				bool flag2 = image == null || !image.IsInitialized();
				if (flag2)
				{
					result.Message = "No image is available for inspection.";
					result2 = result;
				}
				else
				{
					CountBoundingBoxToolConfig config = tool.Config as CountBoundingBoxToolConfig;
					CountBoundingBoxToolSpec spec = tool.Spec as CountBoundingBoxToolSpec;
					bool flag3 = config == null;
					if (flag3)
					{
						result.Message = "The selected tool is not a Count Bounding Box tool.";
						result2 = result;
					}
					else
					{
						HObject gray = null;
						HObject searchImage = null;
						HObject searchRegion = null;
						HObject reduced = null;
						HObject thresholded = null;
						HObject closed = null;
						HObject opened = null;
						HObject candidates = null;
						HObject byBlobArea = null;
						List<HObject> roiRegions = new List<HObject>();
						try
						{
							gray = CountBoundingBoxProcessor.ConvertToGray(image);
							bool flag4 = tool.RoiItems != null;
							if (flag4)
							{
								foreach (RoiData roi in tool.RoiItems)
								{
									bool flag5 = roi != null && roi.IsEnabled;
									if (flag5)
									{
										CountBoundingBoxResult countBoundingBoxResult = result;
										int roiCount = countBoundingBoxResult.RoiCount;
										countBoundingBoxResult.RoiCount = roiCount + 1;
										roiRegions.Add(this._roiImageService.BuildRoiRegion(roi, gray, tool));
									}
								}
							}
							searchImage = this._roiImageService.ReduceByRois(gray, tool.RoiItems, tool);
							HOperatorSet.GetDomain(searchImage, out searchRegion);
							HTuple searchArea;
							HTuple htuple;
							HTuple __;
							HOperatorSet.AreaCenter(searchRegion, out searchArea, out htuple, out __);
							result.SearchArea = ((searchArea.Length > 0) ? searchArea.TupleSum().D : 0.0);
							HOperatorSet.ReduceDomain(gray, searchRegion, out reduced);
							double low = Math.Min(config.ThresholdMin, config.ThresholdMax);
							double high = Math.Max(config.ThresholdMin, config.ThresholdMax);
							HOperatorSet.Threshold(reduced, out thresholded, low, high);
							bool flag6 = config.CloseRadius > 0.0;
							if (flag6)
							{
								HOperatorSet.ClosingCircle(thresholded, out closed, config.CloseRadius);
							}
							else
							{
								HOperatorSet.CopyObj(thresholded, out closed, 1, -1);
							}
							bool flag7 = config.OpenRadius > 0.0;
							if (flag7)
							{
								HOperatorSet.OpeningCircle(closed, out opened, config.OpenRadius);
							}
							else
							{
								HOperatorSet.CopyObj(closed, out opened, 1, -1);
							}
							HOperatorSet.Connection(opened, out candidates);
							HTuple candidateCount;
							HOperatorSet.CountObj(candidates, out candidateCount);
							result.CandidateCount = ((candidateCount.Length > 0) ? candidateCount.I : 0);
							bool showThreshold = config.ShowThreshold;
							if (showThreshold)
							{
								result.ThresholdRegion = CountBoundingBoxProcessor.BuildThresholdRegion(candidates);
							}
							HOperatorSet.SelectShape(candidates, out byBlobArea, "area", "and", config.MinBlobArea, (config.MaxBlobArea <= 0.0) ? 1000000000000.0 : config.MaxBlobArea);
							CountBoundingBoxProcessor.CollectObjects(byBlobArea, roiRegions, config, result);
							CountBoundingBoxProcessor.ApplySpecAndJudge(spec, result);
							result.IsSuccess = true;
							result.Message = string.Concat(new string[]
							{
								"Bounding box count completed. ",
								result.SpecStatus,
								", objects=",
								result.ObjectCount.ToString(),
								" (from ",
								result.CandidateCount.ToString(),
								" blob(s) over threshold",
								(result.RoiCount > 0) ? (" inside " + result.RoiCount.ToString() + " ROI(s))") : ", whole image - no ROI drawn)"
							});
							result2 = result;
						}
						catch (Exception ex)
						{
							result.IsSuccess = false;
							result.IsOk = false;
							result.SpecStatus = "NG";
							result.Message = "Count Bounding Box failed: " + ex.Message;
							result2 = result;
						}
						finally
						{
							if (gray != null)
							{
								gray.Dispose();
							}
							if (searchImage != null)
							{
								searchImage.Dispose();
							}
							if (searchRegion != null)
							{
								searchRegion.Dispose();
							}
							if (reduced != null)
							{
								reduced.Dispose();
							}
							if (thresholded != null)
							{
								thresholded.Dispose();
							}
							if (closed != null)
							{
								closed.Dispose();
							}
							if (opened != null)
							{
								opened.Dispose();
							}
							if (candidates != null)
							{
								candidates.Dispose();
							}
							if (byBlobArea != null)
							{
								byBlobArea.Dispose();
							}
							foreach (HObject region in roiRegions)
							{
								if (region != null)
								{
									region.Dispose();
								}
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06000E25 RID: 3621 RVA: 0x00041988 File Offset: 0x0003FB88
		private static void CollectObjects(HObject blobs, List<HObject> roiRegions, CountBoundingBoxToolConfig config, CountBoundingBoxResult result)
		{
			HTuple count;
			HOperatorSet.CountObj(blobs, out count);
			bool flag = count.Length == 0 || count.I <= 0;
			if (!flag)
			{
				HTuple row;
				HTuple column;
				HTuple row2;
				HTuple column2;
				HOperatorSet.SmallestRectangle1(blobs, out row, out column, out row2, out column2);
				HTuple areas;
				HTuple centerRows;
				HTuple centerColumns;
				HOperatorSet.AreaCenter(blobs, out areas, out centerRows, out centerColumns);
				List<CountBoundingBoxItem> boxes = new List<CountBoundingBoxItem>();
				int[] roiOfBlob = CountBoundingBoxProcessor.AssignRoiIndexes(blobs, roiRegions, row.Length);
				for (int i = 0; i < row.Length; i++)
				{
					boxes.Add(new CountBoundingBoxItem
					{
						Row1 = row[i].D,
						Column1 = column[i].D,
						Row2 = row2[i].D,
						Column2 = column2[i].D,
						BlobArea = ((i < areas.Length) ? areas[i].D : 0.0),
						CenterRow = ((i < centerRows.Length) ? centerRows[i].D : 0.0),
						CenterColumn = ((i < centerColumns.Length) ? centerColumns[i].D : 0.0),
						RoiIndex = roiOfBlob[i]
					});
				}
				result.BoxesBeforeGrouping = boxes.Count;
				bool enableGrouping = config.EnableGrouping;
				if (enableGrouping)
				{
					boxes = CountBoundingBoxProcessor.GroupBoxesPerRoi(boxes, config);
				}
				List<CountBoundingBoxItem> kept = new List<CountBoundingBoxItem>();
				foreach (CountBoundingBoxItem item in boxes)
				{
					bool flag2 = CountBoundingBoxProcessor.PassesBoxFilter(item, config);
					if (flag2)
					{
						kept.Add(item);
					}
				}
				foreach (CountBoundingBoxItem item2 in CountBoundingBoxProcessor.SortInReadingOrder(kept, config.RowPitch))
				{
					item2.Index = result.Objects.Count + 1;
					result.Objects.Add(item2);
				}
				result.ObjectCount = result.Objects.Count;
			}
		}

		// Token: 0x06000E26 RID: 3622 RVA: 0x00041C04 File Offset: 0x0003FE04
		private static int[] AssignRoiIndexes(HObject blobs, List<HObject> roiRegions, int blobCount)
		{
			int[] assigned = new int[blobCount];
			bool flag = roiRegions == null || roiRegions.Count <= 1;
			int[] result;
			if (flag)
			{
				result = assigned;
			}
			else
			{
				double[] bestOverlap = new double[blobCount];
				for (int i = 0; i < blobCount; i++)
				{
					assigned[i] = -1;
				}
				for (int r = 0; r < roiRegions.Count; r++)
				{
					HObject region = roiRegions[r];
					bool flag2 = region == null || !region.IsInitialized();
					if (!flag2)
					{
						HObject inside = null;
						try
						{
							HOperatorSet.Intersection(blobs, region, out inside);
							HTuple overlap;
							HTuple htuple;
							HTuple __;
							HOperatorSet.AreaCenter(inside, out overlap, out htuple, out __);
							int j = 0;
							while (j < blobCount && j < overlap.Length)
							{
								double area = overlap[j].D;
								bool flag3 = area <= 0.0 || area <= bestOverlap[j];
								if (!flag3)
								{
									bestOverlap[j] = area;
									assigned[j] = r;
								}
								j++;
							}
						}
						catch (HOperatorException)
						{
						}
						finally
						{
							if (inside != null)
							{
								inside.Dispose();
							}
						}
					}
				}
				result = assigned;
			}
			return result;
		}

		// Token: 0x06000E27 RID: 3623 RVA: 0x00041D60 File Offset: 0x0003FF60
		private static List<CountBoundingBoxItem> GroupBoxesPerRoi(List<CountBoundingBoxItem> boxes, CountBoundingBoxToolConfig config)
		{
			Dictionary<int, List<CountBoundingBoxItem>> byRoi = new Dictionary<int, List<CountBoundingBoxItem>>();
			List<int> order = new List<int>();
			foreach (CountBoundingBoxItem box in boxes)
			{
				List<CountBoundingBoxItem> members;
				bool flag = !byRoi.TryGetValue(box.RoiIndex, out members);
				if (flag)
				{
					members = new List<CountBoundingBoxItem>();
					byRoi[box.RoiIndex] = members;
					order.Add(box.RoiIndex);
				}
				members.Add(box);
			}
			List<CountBoundingBoxItem> grouped = new List<CountBoundingBoxItem>();
			foreach (int roiIndex in order)
			{
				grouped.AddRange(CountBoundingBoxProcessor.GroupNeighbouringBoxes(byRoi[roiIndex], config));
			}
			return grouped;
		}

		// Token: 0x06000E28 RID: 3624 RVA: 0x00041E60 File Offset: 0x00040060
		private static List<CountBoundingBoxItem> GroupNeighbouringBoxes(List<CountBoundingBoxItem> boxes, CountBoundingBoxToolConfig config)
		{
			int i = boxes.Count;
			bool flag = i < 2;
			List<CountBoundingBoxItem> result;
			if (flag)
			{
				result = boxes;
			}
			else
			{
				int[] parent = new int[i];
				for (int j = 0; j < i; j++)
				{
					parent[j] = j;
				}
				for (int k = 0; k < i; k++)
				{
					for (int l = k + 1; l < i; l++)
					{
						bool flag2 = CountBoundingBoxProcessor.IsNeighbour(boxes[k], boxes[l], config);
						if (flag2)
						{
							CountBoundingBoxProcessor.Union(parent, k, l);
						}
					}
				}
				Dictionary<int, List<CountBoundingBoxItem>> groups = new Dictionary<int, List<CountBoundingBoxItem>>();
				for (int m = 0; m < i; m++)
				{
					int root = CountBoundingBoxProcessor.Find(parent, m);
					List<CountBoundingBoxItem> members;
					bool flag3 = !groups.TryGetValue(root, out members);
					if (flag3)
					{
						members = new List<CountBoundingBoxItem>();
						groups[root] = members;
					}
					members.Add(boxes[m]);
				}
				List<CountBoundingBoxItem> merged = new List<CountBoundingBoxItem>(groups.Count);
				foreach (List<CountBoundingBoxItem> members2 in groups.Values)
				{
					merged.Add(CountBoundingBoxProcessor.MergeBoxes(members2));
				}
				result = merged;
			}
			return result;
		}

		// Token: 0x06000E29 RID: 3625 RVA: 0x00041FC8 File Offset: 0x000401C8
		private static bool IsNeighbour(CountBoundingBoxItem a, CountBoundingBoxItem b, CountBoundingBoxToolConfig config)
		{
			double gapX = Math.Max(0.0, Math.Max(a.Column1, b.Column1) - Math.Min(a.Column2, b.Column2));
			double gapY = Math.Max(0.0, Math.Max(a.Row1, b.Row1) - Math.Min(a.Row2, b.Row2));
			return gapX <= config.GroupGapX && gapY <= config.GroupGapY;
		}

		// Token: 0x06000E2A RID: 3626 RVA: 0x00042058 File Offset: 0x00040258
		private static CountBoundingBoxItem MergeBoxes(List<CountBoundingBoxItem> members)
		{
			bool flag = members.Count == 1;
			CountBoundingBoxItem result;
			if (flag)
			{
				result = members[0];
			}
			else
			{
				CountBoundingBoxItem merged = new CountBoundingBoxItem
				{
					Row1 = members[0].Row1,
					Column1 = members[0].Column1,
					Row2 = members[0].Row2,
					Column2 = members[0].Column2,
					MemberCount = members.Count,
					RoiIndex = members[0].RoiIndex
				};
				double totalArea = 0.0;
				double weightedRow = 0.0;
				double weightedColumn = 0.0;
				foreach (CountBoundingBoxItem member in members)
				{
					merged.Row1 = Math.Min(merged.Row1, member.Row1);
					merged.Column1 = Math.Min(merged.Column1, member.Column1);
					merged.Row2 = Math.Max(merged.Row2, member.Row2);
					merged.Column2 = Math.Max(merged.Column2, member.Column2);
					totalArea += member.BlobArea;
					weightedRow += member.CenterRow * member.BlobArea;
					weightedColumn += member.CenterColumn * member.BlobArea;
				}
				merged.BlobArea = totalArea;
				bool flag2 = totalArea > 0.0;
				if (flag2)
				{
					merged.CenterRow = weightedRow / totalArea;
					merged.CenterColumn = weightedColumn / totalArea;
				}
				else
				{
					merged.CenterRow = (merged.Row1 + merged.Row2) / 2.0;
					merged.CenterColumn = (merged.Column1 + merged.Column2) / 2.0;
				}
				result = merged;
			}
			return result;
		}

		// Token: 0x06000E2B RID: 3627 RVA: 0x00042264 File Offset: 0x00040464
		private static int Find(int[] parent, int index)
		{
			while (parent[index] != index)
			{
				parent[index] = parent[parent[index]];
				index = parent[index];
			}
			return index;
		}

		// Token: 0x06000E2C RID: 3628 RVA: 0x00042298 File Offset: 0x00040498
		private static void Union(int[] parent, int a, int b)
		{
			int rootA = CountBoundingBoxProcessor.Find(parent, a);
			int rootB = CountBoundingBoxProcessor.Find(parent, b);
			bool flag = rootA != rootB;
			if (flag)
			{
				parent[rootB] = rootA;
			}
		}

		// Token: 0x06000E2D RID: 3629 RVA: 0x000422C8 File Offset: 0x000404C8
		private static bool PassesBoxFilter(CountBoundingBoxItem item, CountBoundingBoxToolConfig config)
		{
			double area = item.BoxArea;
			bool flag = area < config.MinBoxArea;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				bool flag2 = config.MaxBoxArea > 0.0 && area > config.MaxBoxArea;
				if (flag2)
				{
					result = false;
				}
				else
				{
					bool flag3 = config.MinBoxWidth > 0.0 && item.Width < config.MinBoxWidth;
					if (flag3)
					{
						result = false;
					}
					else
					{
						bool flag4 = config.MaxBoxWidth > 0.0 && item.Width > config.MaxBoxWidth;
						if (flag4)
						{
							result = false;
						}
						else
						{
							bool flag5 = config.MinBoxHeight > 0.0 && item.Height < config.MinBoxHeight;
							if (flag5)
							{
								result = false;
							}
							else
							{
								bool flag6 = config.MaxBoxHeight > 0.0 && item.Height > config.MaxBoxHeight;
								result = !flag6;
							}
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000E2E RID: 3630 RVA: 0x000423D4 File Offset: 0x000405D4
		private static List<CountBoundingBoxItem> SortInReadingOrder(List<CountBoundingBoxItem> items, double rowPitch)
		{
			bool flag = items.Count < 2;
			List<CountBoundingBoxItem> result;
			if (flag)
			{
				result = items;
			}
			else
			{
				double minRow = items[0].CenterRow;
				foreach (CountBoundingBoxItem item in items)
				{
					minRow = Math.Min(minRow, item.CenterRow);
				}
				double pitch = (rowPitch < 1.0) ? 1.0 : rowPitch;
				double[] keys = new double[items.Count];
				int[] order = new int[items.Count];
				for (int i = 0; i < items.Count; i++)
				{
					int group = (int)Math.Floor((items[i].CenterRow - minRow) / pitch + 0.5);
					keys[i] = (double)group * 1000000.0 + items[i].CenterColumn;
					order[i] = i;
				}
				Array.Sort<double, int>(keys, order);
				List<CountBoundingBoxItem> sorted = new List<CountBoundingBoxItem>(items.Count);
				foreach (int index in order)
				{
					sorted.Add(items[index]);
				}
				result = sorted;
			}
			return result;
		}

		// Token: 0x06000E2F RID: 3631 RVA: 0x00042534 File Offset: 0x00040734
		private static HObject BuildThresholdRegion(HObject candidates)
		{
			HObject result;
			try
			{
				HTuple count;
				HOperatorSet.CountObj(candidates, out count);
				bool flag = count.Length == 0 || count.I <= 0;
				if (flag)
				{
					result = null;
				}
				else
				{
					HObject region;
					HOperatorSet.Union1(candidates, out region);
					result = region;
				}
			}
			catch (HOperatorException)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000E30 RID: 3632 RVA: 0x00042590 File Offset: 0x00040790
		private static void ApplySpecAndJudge(CountBoundingBoxToolSpec spec, CountBoundingBoxResult result)
		{
			bool flag = spec == null || !spec.IsEnabled;
			if (flag)
			{
				result.IsSpecEnabled = false;
				result.IsOk = true;
				result.SpecStatus = "OK";
			}
			else
			{
				result.IsSpecEnabled = true;
				bool flag2 = spec.CountEnabled && ((double)result.ObjectCount < spec.CountMin || (double)result.ObjectCount > spec.CountMax);
				if (flag2)
				{
					result.SpecFailures.Add(string.Concat(new string[]
					{
						"Object count ",
						result.ObjectCount.ToString(),
						" outside [",
						spec.CountMin.ToString("0"),
						", ",
						spec.CountMax.ToString("0"),
						"]"
					}));
				}
				result.IsOk = (result.SpecFailures.Count == 0);
				result.SpecStatus = (result.IsOk ? "OK" : "NG");
			}
		}

		// Token: 0x06000E31 RID: 3633 RVA: 0x000426B4 File Offset: 0x000408B4
		private static HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject grayImage;
			if (flag)
			{
				HOperatorSet.Rgb1ToGray(image, out grayImage);
			}
			else
			{
				HOperatorSet.CopyImage(image, out grayImage);
			}
			HTuple imageType;
			HOperatorSet.GetImageType(grayImage, out imageType);
			bool flag2 = imageType.Length > 0 && string.Equals(imageType[0].S, "byte", StringComparison.OrdinalIgnoreCase);
			HObject result;
			if (flag2)
			{
				result = grayImage;
			}
			else
			{
				HObject scaled = null;
				try
				{
					HOperatorSet.ScaleImageMax(grayImage, out scaled);
					HObject byteImage;
					HOperatorSet.ConvertImageType(scaled, out byteImage, "byte");
					result = byteImage;
				}
				finally
				{
					if (grayImage != null)
					{
						grayImage.Dispose();
					}
					if (scaled != null)
					{
						scaled.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x040005C6 RID: 1478
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();
	}
}
