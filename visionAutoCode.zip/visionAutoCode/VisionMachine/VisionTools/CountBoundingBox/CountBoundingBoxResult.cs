﻿using System;
using System.Collections.Generic;
using HalconDotNet;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000115 RID: 277
	public class CountBoundingBoxResult : IDisposable
	{
		// Token: 0x17000513 RID: 1299
		// (get) Token: 0x06000E4B RID: 3659 RVA: 0x000428D8 File Offset: 0x00040AD8
		// (set) Token: 0x06000E4C RID: 3660 RVA: 0x000428E0 File Offset: 0x00040AE0
		public bool IsSuccess { get; set; }

		// Token: 0x17000514 RID: 1300
		// (get) Token: 0x06000E4D RID: 3661 RVA: 0x000428E9 File Offset: 0x00040AE9
		// (set) Token: 0x06000E4E RID: 3662 RVA: 0x000428F1 File Offset: 0x00040AF1
		public string Message { get; set; }

		// Token: 0x17000515 RID: 1301
		// (get) Token: 0x06000E4F RID: 3663 RVA: 0x000428FA File Offset: 0x00040AFA
		// (set) Token: 0x06000E50 RID: 3664 RVA: 0x00042902 File Offset: 0x00040B02
		public int ObjectCount { get; set; }

		// Token: 0x17000516 RID: 1302
		// (get) Token: 0x06000E51 RID: 3665 RVA: 0x0004290B File Offset: 0x00040B0B
		public List<CountBoundingBoxItem> Objects { get; } = new List<CountBoundingBoxItem>();

		// Token: 0x17000517 RID: 1303
		// (get) Token: 0x06000E52 RID: 3666 RVA: 0x00042913 File Offset: 0x00040B13
		// (set) Token: 0x06000E53 RID: 3667 RVA: 0x0004291B File Offset: 0x00040B1B
		public int CandidateCount { get; set; }

		// Token: 0x17000518 RID: 1304
		// (get) Token: 0x06000E54 RID: 3668 RVA: 0x00042924 File Offset: 0x00040B24
		// (set) Token: 0x06000E55 RID: 3669 RVA: 0x0004292C File Offset: 0x00040B2C
		public int BoxesBeforeGrouping { get; set; }

		// Token: 0x17000519 RID: 1305
		// (get) Token: 0x06000E56 RID: 3670 RVA: 0x00042935 File Offset: 0x00040B35
		// (set) Token: 0x06000E57 RID: 3671 RVA: 0x0004293D File Offset: 0x00040B3D
		public double SearchArea { get; set; }

		// Token: 0x1700051A RID: 1306
		// (get) Token: 0x06000E58 RID: 3672 RVA: 0x00042946 File Offset: 0x00040B46
		// (set) Token: 0x06000E59 RID: 3673 RVA: 0x0004294E File Offset: 0x00040B4E
		public int RoiCount { get; set; }

		// Token: 0x1700051B RID: 1307
		// (get) Token: 0x06000E5A RID: 3674 RVA: 0x00042957 File Offset: 0x00040B57
		// (set) Token: 0x06000E5B RID: 3675 RVA: 0x0004295F File Offset: 0x00040B5F
		public bool IsSpecEnabled { get; set; }

		// Token: 0x1700051C RID: 1308
		// (get) Token: 0x06000E5C RID: 3676 RVA: 0x00042968 File Offset: 0x00040B68
		// (set) Token: 0x06000E5D RID: 3677 RVA: 0x00042970 File Offset: 0x00040B70
		public bool IsOk { get; set; } = true;

		// Token: 0x1700051D RID: 1309
		// (get) Token: 0x06000E5E RID: 3678 RVA: 0x00042979 File Offset: 0x00040B79
		// (set) Token: 0x06000E5F RID: 3679 RVA: 0x00042981 File Offset: 0x00040B81
		public string SpecStatus { get; set; } = "OK";

		// Token: 0x1700051E RID: 1310
		// (get) Token: 0x06000E60 RID: 3680 RVA: 0x0004298A File Offset: 0x00040B8A
		public List<string> SpecFailures { get; } = new List<string>();

		// Token: 0x1700051F RID: 1311
		// (get) Token: 0x06000E61 RID: 3681 RVA: 0x00042992 File Offset: 0x00040B92
		// (set) Token: 0x06000E62 RID: 3682 RVA: 0x0004299A File Offset: 0x00040B9A
		public HObject ThresholdRegion { get; set; }

		// Token: 0x06000E63 RID: 3683 RVA: 0x000429A3 File Offset: 0x00040BA3
		public void Dispose()
		{
			HObject thresholdRegion = this.ThresholdRegion;
			if (thresholdRegion != null)
			{
				thresholdRegion.Dispose();
			}
			this.ThresholdRegion = null;
		}

		// Token: 0x17000520 RID: 1312
		// (get) Token: 0x06000E64 RID: 3684 RVA: 0x000429C0 File Offset: 0x00040BC0
		// (set) Token: 0x06000E65 RID: 3685 RVA: 0x000429C8 File Offset: 0x00040BC8
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000521 RID: 1313
		// (get) Token: 0x06000E66 RID: 3686 RVA: 0x000429D1 File Offset: 0x00040BD1
		// (set) Token: 0x06000E67 RID: 3687 RVA: 0x000429D9 File Offset: 0x00040BD9
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x17000522 RID: 1314
		// (get) Token: 0x06000E68 RID: 3688 RVA: 0x000429E2 File Offset: 0x00040BE2
		// (set) Token: 0x06000E69 RID: 3689 RVA: 0x000429EA File Offset: 0x00040BEA
		public string InputSourceToolName { get; set; }

		// Token: 0x17000523 RID: 1315
		// (get) Token: 0x06000E6A RID: 3690 RVA: 0x000429F3 File Offset: 0x00040BF3
		// (set) Token: 0x06000E6B RID: 3691 RVA: 0x000429FB File Offset: 0x00040BFB
		public double InputProcessingTimeMs { get; set; }
	}
}
