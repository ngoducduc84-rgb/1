﻿using System;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000116 RID: 278
	public class CountBoundingBoxResultDrawer
	{
		// Token: 0x06000E6D RID: 3693 RVA: 0x00042A38 File Offset: 0x00040C38
		public void Draw(HWindow window, ToolVision tool, CountBoundingBoxResult result)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				CountBoundingBoxToolConfig config = tool.Config as CountBoundingBoxToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool showRoi = config.ShowRoi;
					if (showRoi)
					{
						ToolRoiOverlayDrawer.DrawRoiList(window, tool, tool.RoiItems, "cyan", 2);
					}
					bool showThreshold = config.ShowThreshold;
					if (showThreshold)
					{
						this.DrawThreshold(window, result, config);
					}
					bool flag3 = config.ShowBoxes || config.ShowIndex || config.ShowSize;
					if (flag3)
					{
						this.DrawBoxes(window, result, config);
					}
					bool showText = config.ShowText;
					if (showText)
					{
						this.DrawText(window, tool, result, config);
					}
				}
			}
		}

		// Token: 0x06000E6E RID: 3694 RVA: 0x00042AE8 File Offset: 0x00040CE8
		private void DrawThreshold(HWindow window, CountBoundingBoxResult result, CountBoundingBoxToolConfig config)
		{
			HObject region = result.ThresholdRegion;
			bool flag = region == null || !region.IsInitialized();
			if (!flag)
			{
				try
				{
					HOperatorSet.SetDraw(window, config.ThresholdFill ? "fill" : "margin");
					HOperatorSet.SetLineWidth(window, 1);
					HOperatorSet.SetColor(window, string.IsNullOrWhiteSpace(config.ThresholdColor) ? "orange" : config.ThresholdColor);
					HOperatorSet.DispObj(region, window);
				}
				catch (HOperatorException)
				{
				}
			}
		}

		// Token: 0x06000E6F RID: 3695 RVA: 0x00042B9C File Offset: 0x00040D9C
		private void DrawBoxes(HWindow window, CountBoundingBoxResult result, CountBoundingBoxToolConfig config)
		{
			bool flag = result.Objects.Count == 0;
			if (!flag)
			{
				string boxColor = string.IsNullOrWhiteSpace(config.BoxColor) ? "green" : config.BoxColor;
				string labelColor = string.IsNullOrWhiteSpace(config.IndexTextColor) ? "yellow" : config.IndexTextColor;
				int labelSize = Math.Max(8, config.IndexTextSize);
				try
				{
					HOperatorSet.SetDraw(window, "margin");
					HOperatorSet.SetLineWidth(window, 2);
					HOperatorSet.SetFont(window, "Arial-" + labelSize.ToString());
				}
				catch (HOperatorException)
				{
					return;
				}
				foreach (CountBoundingBoxItem item in result.Objects)
				{
					HObject box = null;
					try
					{
						bool showBoxes = config.ShowBoxes;
						if (showBoxes)
						{
							HOperatorSet.SetColor(window, boxColor);
							HOperatorSet.GenRectangle1(out box, item.Row1, item.Column1, item.Row2, item.Column2);
							HOperatorSet.DispObj(box, window);
						}
						string label = string.Empty;
						bool showIndex = config.ShowIndex;
						if (showIndex)
						{
							label = item.Index.ToString();
						}
						bool showSize = config.ShowSize;
						if (showSize)
						{
							bool flag2 = label.Length > 0;
							if (flag2)
							{
								label += "  ";
							}
							label = string.Concat(new string[]
							{
								label,
								item.Width.ToString("0"),
								"x",
								item.Height.ToString("0"),
								" (",
								item.BoxArea.ToString("0"),
								" px)"
							});
						}
						bool flag3 = item.MemberCount > 1;
						if (flag3)
						{
							bool flag4 = label.Length > 0;
							if (flag4)
							{
								label += "  ";
							}
							label = label + "[" + item.MemberCount.ToString() + "]";
						}
						bool flag5 = label.Length == 0;
						if (!flag5)
						{
							double labelRow = item.Row1 - (double)labelSize - 6.0 + config.IndexOffsetY;
							double labelColumn = item.Column1 + config.IndexOffsetX;
							HOperatorSet.SetColor(window, labelColor);
							HOperatorSet.SetTposition(window, Math.Max(labelRow, 0.0), Math.Max(labelColumn, 0.0));
							HOperatorSet.WriteString(window, label);
						}
					}
					catch (HOperatorException)
					{
					}
					finally
					{
						if (box != null)
						{
							box.Dispose();
						}
					}
				}
			}
		}

		// Token: 0x06000E70 RID: 3696 RVA: 0x00042F34 File Offset: 0x00041134
		private void DrawText(HWindow window, ToolVision tool, CountBoundingBoxResult result, CountBoundingBoxToolConfig config)
		{
			CountBoundingBoxToolSpec spec = tool.Spec as CountBoundingBoxToolSpec;
			string status = (!result.IsSuccess) ? "ERROR" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
			bool bad = !result.IsSuccess || string.Equals(status, "NG", StringComparison.OrdinalIgnoreCase);
			string expected = (spec != null && spec.IsEnabled && spec.CountEnabled) ? (" / " + ((Math.Abs(spec.CountMin - spec.CountMax) < 0.5) ? spec.CountMax.ToString("0") : (spec.CountMin.ToString("0") + "-" + spec.CountMax.ToString("0")))) : string.Empty;
			string text = string.Concat(new string[]
			{
				tool.Name ?? "Count Bounding Box",
				": ",
				status,
				"\nObjects: ",
				result.ObjectCount.ToString(),
				expected
			});
			bool enableGrouping = config.EnableGrouping;
			if (enableGrouping)
			{
				text = string.Concat(new string[]
				{
					text,
					"\nGrouped: ",
					result.BoxesBeforeGrouping.ToString(),
					" box(es) -> ",
					result.ObjectCount.ToString(),
					" object(s)"
				});
			}
			bool showThreshold = config.ShowThreshold;
			if (showThreshold)
			{
				text = string.Concat(new string[]
				{
					text,
					"\nBlobs over threshold: ",
					result.CandidateCount.ToString(),
					"\nSearch area: ",
					result.SearchArea.ToString("0"),
					" px",
					(result.RoiCount > 0) ? (" (" + result.RoiCount.ToString() + " ROI)") : " (no ROI - whole image)"
				});
			}
			foreach (string failure in result.SpecFailures)
			{
				text = text + "\n" + failure;
			}
			bool flag = !result.IsSuccess && !string.IsNullOrWhiteSpace(result.Message);
			if (flag)
			{
				text = text + "\n" + result.Message;
			}
			try
			{
				HOperatorSet.SetFont(window, "Arial-" + Math.Max(8, config.TextSize).ToString());
			}
			catch (HOperatorException)
			{
			}
			try
			{
				HOperatorSet.SetColor(window, bad ? "red" : (string.IsNullOrWhiteSpace(config.TextColor) ? "lime" : config.TextColor));
				HOperatorSet.SetTposition(window, 24, 24);
				HOperatorSet.WriteString(window, text);
			}
			catch (HOperatorException)
			{
			}
		}
	}
}
